* Signature: 0xebf9449c79d04f6a
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  onehot_3
 E  inventory_3
 E  ratio_3 
 G  R9      
 G  R10     
 G  R11     
 G  R12     
 G  R13     
 G  R14     
 G  hard_lower
 L  hard_upper
 G  bin_lower
 L  bin_upper
 L  surrogate_G
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       0.5
    x[1,0]    onehot_1  1
    x[1,1]    OBJ       -0.5625
    x[1,1]    onehot_1  1
    x[1,1]    inventory_1  -1
    x[1,2]    OBJ       0.375
    x[1,2]    onehot_1  1
    x[1,2]    inventory_1  -2
    x[2,0]    OBJ       -0.5
    x[2,0]    onehot_2  1
    x[2,2]    OBJ       -0.5
    x[2,2]    onehot_2  1
    x[2,2]    inventory_2  -2
    x[3,0]    OBJ       0.5
    x[3,0]    onehot_3  1
    x[3,1]    OBJ       -0.5
    x[3,1]    onehot_3  1
    x[3,1]    inventory_3  -1
    MARKER    'MARKER'                 'INTEND'
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -0.5
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -1
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    Y[3]      inventory_3  1
    Y[3]      ratio_3   -2
    Y[3]      hard_lower  1
    Y[3]      hard_upper  1
    r[1]      ratio_1   1
    r[1]      R9        -1
    r[1]      R10       1
    r[1]      R11       -1
    r[1]      R12       1
    r[1]      bin_lower  1
    r[1]      bin_upper  1
    r[1]      physical_G_upper  -1.9500000000000002e+00
    r[2]      ratio_2   1
    r[2]      R9        1
    r[2]      R10       -1
    r[2]      R13       -1
    r[2]      R14       1
    r[2]      bin_lower  1
    r[2]      bin_upper  1
    r[2]      physical_G_upper  -1.9500000000000002e+00
    r[3]      ratio_3   1
    r[3]      R11       1
    r[3]      R12       -1
    r[3]      R13       1
    r[3]      R14       -1
    r[3]      bin_lower  1
    r[3]      bin_upper  1
    r[3]      physical_G_upper  -1.9500000000000002e+00
    a[1,2]    R9        1
    a[1,2]    R10       1
    a[1,2]    surrogate_G  1
    a[1,2]    physical_G_upper  1
    a[1,3]    R11       1
    a[1,3]    R12       1
    a[1,3]    surrogate_G  1
    a[1,3]    physical_G_upper  1
    a[2,3]    R13       1
    a[2,3]    R14       1
    a[2,3]    surrogate_G  1
    a[2,3]    physical_G_upper  1
    q         OBJ       1
    q         surrogate_G  -4.3731778425655987e+00
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      hard_lower  1
    RHS1      hard_upper  4
    RHS1      bin_lower  1.0204081632653061e+00
    RHS1      bin_upper  1.4577259475218660e+00
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[2,0]  
 BV BND1      x[2,2]  
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 LO BND1      q         0.25
ENDATA
