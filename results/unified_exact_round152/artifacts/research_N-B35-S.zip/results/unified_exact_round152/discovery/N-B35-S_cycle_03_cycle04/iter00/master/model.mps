* Signature: 0xc33fe3b3a294d15d
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
 L  column_14
 L  column_15
 L  column_16
 L  column_17
 L  column_18
 L  column_19
 L  column_20
 L  column_21
 L  column_22
 L  column_23
 L  column_24
 L  column_25
 L  column_26
 L  column_27
 L  column_28
 L  column_29
 L  column_30
 L  column_31
 L  column_32
 L  column_33
 L  column_34
 L  column_35
 L  column_36
COLUMNS
    psi[1,5]  OBJ       1.0956978539262074e-01
    psi[1,5]  column_0  1
    psi[1,5]  column_1  1
    psi[1,5]  column_2  1
    psi[1,5]  column_3  1
    psi[1,5]  column_4  1
    psi[1,5]  column_5  1
    psi[1,5]  column_6  1
    psi[1,5]  column_7  1
    psi[1,5]  column_8  1
    psi[1,5]  column_9  1
    psi[1,9]  OBJ       8.9043021460737926e-01
    psi[1,9]  column_10  1
    psi[1,9]  column_11  1
    psi[1,9]  column_12  1
    psi[1,9]  column_13  1
    psi[1,9]  column_14  1
    psi[1,9]  column_15  1
    psi[1,9]  column_16  1
    psi[1,9]  column_17  1
    psi[1,9]  column_18  1
    psi[1,9]  column_19  1
    psi[1,9]  column_20  1
    psi[1,9]  column_21  1
    psi[1,9]  column_22  1
    psi[1,9]  column_23  1
    psi[1,9]  column_24  1
    psi[1,9]  column_25  1
    psi[1,9]  column_26  1
    psi[1,9]  column_27  1
    psi[1,9]  column_28  1
    psi[1,9]  column_29  1
    psi[1,9]  column_30  1
    psi[1,9]  column_31  1
    psi[1,9]  column_32  1
    psi[1,9]  column_33  1
    psi[1,9]  column_34  1
    psi[1,9]  column_35  1
    psi[1,9]  column_36  1
    psi[2,3]  OBJ       2.5169884977483425e-01
    psi[2,3]  column_0  1
    psi[2,3]  column_1  1
    psi[2,3]  column_2  1
    psi[2,3]  column_3  1
    psi[2,3]  column_4  1
    psi[2,3]  column_5  1
    psi[2,3]  column_6  1
    psi[2,3]  column_7  1
    psi[2,3]  column_8  1
    psi[2,3]  column_9  1
    psi[2,3]  column_10  1
    psi[2,3]  column_11  1
    psi[2,3]  column_12  1
    psi[2,3]  column_13  1
    psi[2,3]  column_14  1
    psi[2,3]  column_15  1
    psi[2,3]  column_16  1
    psi[2,3]  column_17  1
    psi[2,7]  OBJ       7.4830115022516575e-01
    psi[2,7]  column_18  1
    psi[2,7]  column_19  1
    psi[2,7]  column_20  1
    psi[2,7]  column_21  1
    psi[2,7]  column_22  1
    psi[2,7]  column_23  1
    psi[2,7]  column_24  1
    psi[2,7]  column_25  1
    psi[2,7]  column_26  1
    psi[2,7]  column_27  1
    psi[2,7]  column_28  1
    psi[2,7]  column_29  1
    psi[2,7]  column_30  1
    psi[2,7]  column_31  1
    psi[2,7]  column_32  1
    psi[2,7]  column_33  1
    psi[2,7]  column_34  1
    psi[2,7]  column_35  1
    psi[2,7]  column_36  1
    psi[3,4]  OBJ       2.8765582831409631e-01
    psi[3,4]  column_0  1
    psi[3,4]  column_1  1
    psi[3,4]  column_2  1
    psi[3,4]  column_3  1
    psi[3,4]  column_4  1
    psi[3,4]  column_5  1
    psi[3,4]  column_6  1
    psi[3,4]  column_7  1
    psi[3,4]  column_8  1
    psi[3,4]  column_9  1
    psi[3,4]  column_10  1
    psi[3,4]  column_11  1
    psi[3,4]  column_12  1
    psi[3,4]  column_13  1
    psi[3,4]  column_14  1
    psi[3,4]  column_15  1
    psi[3,4]  column_16  1
    psi[3,4]  column_17  1
    psi[3,4]  column_18  1
    psi[3,4]  column_19  1
    psi[3,8]  OBJ       7.1234417168590369e-01
    psi[3,8]  column_20  1
    psi[3,8]  column_21  1
    psi[3,8]  column_22  1
    psi[3,8]  column_23  1
    psi[3,8]  column_24  1
    psi[3,8]  column_25  1
    psi[3,8]  column_26  1
    psi[3,8]  column_27  1
    psi[3,8]  column_28  1
    psi[3,8]  column_29  1
    psi[3,8]  column_30  1
    psi[3,8]  column_31  1
    psi[3,8]  column_32  1
    psi[3,8]  column_33  1
    psi[3,8]  column_34  1
    psi[3,8]  column_35  1
    psi[3,8]  column_36  1
    psi[4,3]  OBJ       1.2729156036584758e-02
    psi[4,3]  column_10  1
    psi[4,6]  OBJ       9.5587877495333085e-01
    psi[4,6]  column_0  1
    psi[4,6]  column_1  1
    psi[4,6]  column_2  1
    psi[4,6]  column_3  1
    psi[4,6]  column_4  1
    psi[4,6]  column_5  1
    psi[4,6]  column_6  1
    psi[4,6]  column_7  1
    psi[4,6]  column_8  1
    psi[4,6]  column_9  1
    psi[4,6]  column_11  1
    psi[4,6]  column_12  1
    psi[4,6]  column_13  1
    psi[4,6]  column_14  1
    psi[4,6]  column_15  1
    psi[4,6]  column_16  1
    psi[4,6]  column_17  1
    psi[4,6]  column_18  1
    psi[4,6]  column_19  1
    psi[4,6]  column_20  1
    psi[4,6]  column_21  1
    psi[4,6]  column_22  1
    psi[4,6]  column_23  1
    psi[4,6]  column_24  1
    psi[4,6]  column_25  1
    psi[4,6]  column_26  1
    psi[4,6]  column_27  1
    psi[4,6]  column_28  1
    psi[4,6]  column_29  1
    psi[4,6]  column_30  1
    psi[4,6]  column_31  1
    psi[4,6]  column_32  1
    psi[4,6]  column_33  1
    psi[4,6]  column_34  1
    psi[4,6]  column_35  1
    psi[4,7]  OBJ       3.1392069010173149e-02
    psi[4,7]  column_36  1
    psi[5,2]  OBJ       1.9177055220939745e-01
    psi[5,2]  column_20  1
    psi[5,2]  column_21  1
    psi[5,2]  column_22  1
    psi[5,8]  OBJ       8.0822944779060257e-01
    psi[5,8]  column_0  1
    psi[5,8]  column_1  1
    psi[5,8]  column_2  1
    psi[5,8]  column_3  1
    psi[5,8]  column_4  1
    psi[5,8]  column_5  1
    psi[5,8]  column_6  1
    psi[5,8]  column_7  1
    psi[5,8]  column_8  1
    psi[5,8]  column_9  1
    psi[5,8]  column_10  1
    psi[5,8]  column_11  1
    psi[5,8]  column_12  1
    psi[5,8]  column_13  1
    psi[5,8]  column_14  1
    psi[5,8]  column_15  1
    psi[5,8]  column_16  1
    psi[5,8]  column_17  1
    psi[5,8]  column_18  1
    psi[5,8]  column_19  1
    psi[5,8]  column_23  1
    psi[5,8]  column_24  1
    psi[5,8]  column_25  1
    psi[5,8]  column_26  1
    psi[5,8]  column_27  1
    psi[5,8]  column_28  1
    psi[5,8]  column_29  1
    psi[5,8]  column_30  1
    psi[5,8]  column_31  1
    psi[5,8]  column_32  1
    psi[5,8]  column_33  1
    psi[5,8]  column_34  1
    psi[5,8]  column_35  1
    psi[5,8]  column_36  1
    psi[6,1]  OBJ       1.7978489269631012e-01
    psi[6,1]  column_11  1
    psi[6,1]  column_23  1
    psi[6,1]  column_24  1
    psi[6,5]  OBJ       8.2021510730368985e-01
    psi[6,5]  column_0  1
    psi[6,5]  column_1  1
    psi[6,5]  column_2  1
    psi[6,5]  column_3  1
    psi[6,5]  column_4  1
    psi[6,5]  column_5  1
    psi[6,5]  column_6  1
    psi[6,5]  column_7  1
    psi[6,5]  column_8  1
    psi[6,5]  column_9  1
    psi[6,5]  column_10  1
    psi[6,5]  column_12  1
    psi[6,5]  column_13  1
    psi[6,5]  column_14  1
    psi[6,5]  column_15  1
    psi[6,5]  column_16  1
    psi[6,5]  column_17  1
    psi[6,5]  column_18  1
    psi[6,5]  column_19  1
    psi[6,5]  column_20  1
    psi[6,5]  column_21  1
    psi[6,5]  column_22  1
    psi[6,5]  column_25  1
    psi[6,5]  column_26  1
    psi[6,5]  column_27  1
    psi[6,5]  column_28  1
    psi[6,5]  column_29  1
    psi[6,5]  column_30  1
    psi[6,5]  column_31  1
    psi[6,5]  column_32  1
    psi[6,5]  column_33  1
    psi[6,5]  column_34  1
    psi[6,5]  column_35  1
    psi[6,5]  column_36  1
    psi[7,4]  OBJ       5.0207771085461594e-02
    psi[7,4]  column_18  1
    psi[7,4]  column_23  1
    psi[7,7]  OBJ       9.4979222891453841e-01
    psi[7,7]  column_0  1
    psi[7,7]  column_1  1
    psi[7,7]  column_2  1
    psi[7,7]  column_3  1
    psi[7,7]  column_4  1
    psi[7,7]  column_5  1
    psi[7,7]  column_6  1
    psi[7,7]  column_7  1
    psi[7,7]  column_8  1
    psi[7,7]  column_9  1
    psi[7,7]  column_10  1
    psi[7,7]  column_11  1
    psi[7,7]  column_12  1
    psi[7,7]  column_13  1
    psi[7,7]  column_14  1
    psi[7,7]  column_15  1
    psi[7,7]  column_16  1
    psi[7,7]  column_17  1
    psi[7,7]  column_19  1
    psi[7,7]  column_20  1
    psi[7,7]  column_21  1
    psi[7,7]  column_22  1
    psi[7,7]  column_24  1
    psi[7,7]  column_25  1
    psi[7,7]  column_26  1
    psi[7,7]  column_27  1
    psi[7,7]  column_28  1
    psi[7,7]  column_29  1
    psi[7,7]  column_30  1
    psi[7,7]  column_31  1
    psi[7,7]  column_32  1
    psi[7,7]  column_33  1
    psi[7,7]  column_34  1
    psi[7,7]  column_35  1
    psi[7,7]  column_36  1
    psi[8,10]  OBJ       1
    psi[8,10]  column_0  1
    psi[8,10]  column_1  1
    psi[8,10]  column_2  1
    psi[8,10]  column_3  1
    psi[8,10]  column_4  1
    psi[8,10]  column_5  1
    psi[8,10]  column_6  1
    psi[8,10]  column_7  1
    psi[8,10]  column_8  1
    psi[8,10]  column_9  1
    psi[8,10]  column_10  1
    psi[8,10]  column_11  1
    psi[8,10]  column_12  1
    psi[8,10]  column_13  1
    psi[8,10]  column_14  1
    psi[8,10]  column_15  1
    psi[8,10]  column_16  1
    psi[8,10]  column_17  1
    psi[8,10]  column_18  1
    psi[8,10]  column_19  1
    psi[8,10]  column_20  1
    psi[8,10]  column_21  1
    psi[8,10]  column_22  1
    psi[8,10]  column_23  1
    psi[8,10]  column_24  1
    psi[8,10]  column_25  1
    psi[8,10]  column_26  1
    psi[8,10]  column_27  1
    psi[8,10]  column_28  1
    psi[8,10]  column_29  1
    psi[8,10]  column_30  1
    psi[8,10]  column_31  1
    psi[8,10]  column_32  1
    psi[8,10]  column_33  1
    psi[8,10]  column_34  1
    psi[8,10]  column_35  1
    psi[8,10]  column_36  1
    psi[9,3]  OBJ       3.5956978539262030e-01
    psi[9,3]  column_0  1
    psi[9,3]  column_20  1
    psi[9,3]  column_21  1
    psi[9,3]  column_22  1
    psi[9,3]  column_25  1
    psi[9,3]  column_26  1
    psi[9,3]  column_27  1
    psi[9,3]  column_28  1
    psi[9,3]  column_29  1
    psi[9,3]  column_30  1
    psi[9,3]  column_36  1
    psi[9,5]  OBJ       6.4043021460737970e-01
    psi[9,5]  column_1  1
    psi[9,5]  column_2  1
    psi[9,5]  column_3  1
    psi[9,5]  column_4  1
    psi[9,5]  column_5  1
    psi[9,5]  column_6  1
    psi[9,5]  column_7  1
    psi[9,5]  column_8  1
    psi[9,5]  column_9  1
    psi[9,5]  column_10  1
    psi[9,5]  column_11  1
    psi[9,5]  column_12  1
    psi[9,5]  column_13  1
    psi[9,5]  column_14  1
    psi[9,5]  column_15  1
    psi[9,5]  column_16  1
    psi[9,5]  column_17  1
    psi[9,5]  column_18  1
    psi[9,5]  column_19  1
    psi[9,5]  column_23  1
    psi[9,5]  column_24  1
    psi[9,5]  column_31  1
    psi[9,5]  column_32  1
    psi[9,5]  column_33  1
    psi[9,5]  column_34  1
    psi[9,5]  column_35  1
    psi[10,4]  OBJ       3.1392069010173149e-02
    psi[10,4]  column_19  1
    psi[10,7]  OBJ       2.2606051779923350e-01
    psi[10,7]  column_18  1
    psi[10,7]  column_23  1
    psi[10,7]  column_24  1
    psi[10,7]  column_25  1
    psi[10,7]  column_26  1
    psi[10,7]  column_27  1
    psi[10,7]  column_28  1
    psi[10,7]  column_29  1
    psi[10,7]  column_30  1
    psi[10,10]  OBJ       7.4254741319059336e-01
    psi[10,10]  column_0  1
    psi[10,10]  column_1  1
    psi[10,10]  column_2  1
    psi[10,10]  column_3  1
    psi[10,10]  column_4  1
    psi[10,10]  column_5  1
    psi[10,10]  column_6  1
    psi[10,10]  column_7  1
    psi[10,10]  column_8  1
    psi[10,10]  column_9  1
    psi[10,10]  column_10  1
    psi[10,10]  column_11  1
    psi[10,10]  column_12  1
    psi[10,10]  column_13  1
    psi[10,10]  column_14  1
    psi[10,10]  column_15  1
    psi[10,10]  column_16  1
    psi[10,10]  column_17  1
    psi[10,10]  column_20  1
    psi[10,10]  column_21  1
    psi[10,10]  column_22  1
    psi[10,10]  column_31  1
    psi[10,10]  column_32  1
    psi[10,10]  column_33  1
    psi[10,10]  column_34  1
    psi[10,10]  column_35  1
    psi[10,10]  column_36  1
    psi[11,3]  OBJ       3.5956978539262030e-01
    psi[11,3]  column_1  1
    psi[11,3]  column_2  1
    psi[11,3]  column_3  1
    psi[11,3]  column_4  1
    psi[11,3]  column_5  1
    psi[11,3]  column_6  1
    psi[11,3]  column_7  1
    psi[11,3]  column_11  1
    psi[11,3]  column_31  1
    psi[11,3]  column_32  1
    psi[11,3]  column_33  1
    psi[11,3]  column_34  1
    psi[11,5]  OBJ       6.4043021460737970e-01
    psi[11,5]  column_0  1
    psi[11,5]  column_8  1
    psi[11,5]  column_9  1
    psi[11,5]  column_10  1
    psi[11,5]  column_12  1
    psi[11,5]  column_13  1
    psi[11,5]  column_14  1
    psi[11,5]  column_15  1
    psi[11,5]  column_16  1
    psi[11,5]  column_17  1
    psi[11,5]  column_18  1
    psi[11,5]  column_19  1
    psi[11,5]  column_20  1
    psi[11,5]  column_21  1
    psi[11,5]  column_22  1
    psi[11,5]  column_23  1
    psi[11,5]  column_24  1
    psi[11,5]  column_25  1
    psi[11,5]  column_26  1
    psi[11,5]  column_27  1
    psi[11,5]  column_28  1
    psi[11,5]  column_29  1
    psi[11,5]  column_30  1
    psi[11,5]  column_35  1
    psi[11,5]  column_36  1
    psi[12,3]  OBJ       1.2729156036503396e-02
    psi[12,3]  column_10  1
    psi[12,6]  OBJ       9.5587877495332352e-01
    psi[12,6]  column_0  1
    psi[12,6]  column_1  1
    psi[12,6]  column_2  1
    psi[12,6]  column_3  1
    psi[12,6]  column_4  1
    psi[12,6]  column_5  1
    psi[12,6]  column_6  1
    psi[12,6]  column_7  1
    psi[12,6]  column_8  1
    psi[12,6]  column_9  1
    psi[12,6]  column_11  1
    psi[12,6]  column_12  1
    psi[12,6]  column_13  1
    psi[12,6]  column_14  1
    psi[12,6]  column_15  1
    psi[12,6]  column_16  1
    psi[12,6]  column_17  1
    psi[12,6]  column_18  1
    psi[12,6]  column_19  1
    psi[12,6]  column_20  1
    psi[12,6]  column_21  1
    psi[12,6]  column_22  1
    psi[12,6]  column_23  1
    psi[12,6]  column_24  1
    psi[12,6]  column_25  1
    psi[12,6]  column_26  1
    psi[12,6]  column_27  1
    psi[12,6]  column_28  1
    psi[12,6]  column_29  1
    psi[12,6]  column_30  1
    psi[12,6]  column_31  1
    psi[12,6]  column_32  1
    psi[12,6]  column_33  1
    psi[12,6]  column_36  1
    psi[12,7]  OBJ       3.1392069010173149e-02
    psi[12,7]  column_34  1
    psi[12,7]  column_35  1
    psi[13,5]  OBJ       7.5311656628192836e-02
    psi[13,5]  column_8  1
    psi[13,5]  column_9  1
    psi[13,7]  OBJ       9.2468834337180716e-01
    psi[13,7]  column_0  1
    psi[13,7]  column_1  1
    psi[13,7]  column_2  1
    psi[13,7]  column_3  1
    psi[13,7]  column_4  1
    psi[13,7]  column_5  1
    psi[13,7]  column_6  1
    psi[13,7]  column_7  1
    psi[13,7]  column_10  1
    psi[13,7]  column_11  1
    psi[13,7]  column_12  1
    psi[13,7]  column_13  1
    psi[13,7]  column_14  1
    psi[13,7]  column_15  1
    psi[13,7]  column_16  1
    psi[13,7]  column_17  1
    psi[13,7]  column_18  1
    psi[13,7]  column_19  1
    psi[13,7]  column_20  1
    psi[13,7]  column_21  1
    psi[13,7]  column_22  1
    psi[13,7]  column_23  1
    psi[13,7]  column_24  1
    psi[13,7]  column_25  1
    psi[13,7]  column_26  1
    psi[13,7]  column_27  1
    psi[13,7]  column_28  1
    psi[13,7]  column_29  1
    psi[13,7]  column_30  1
    psi[13,7]  column_31  1
    psi[13,7]  column_32  1
    psi[13,7]  column_33  1
    psi[13,7]  column_34  1
    psi[13,7]  column_35  1
    psi[13,7]  column_36  1
    psi[14,2]  OBJ       1.9177055220939762e-01
    psi[14,2]  column_18  1
    psi[14,2]  column_19  1
    psi[14,2]  column_23  1
    psi[14,2]  column_24  1
    psi[14,2]  column_25  1
    psi[14,2]  column_26  1
    psi[14,8]  OBJ       8.0822944779060235e-01
    psi[14,8]  column_0  1
    psi[14,8]  column_1  1
    psi[14,8]  column_2  1
    psi[14,8]  column_3  1
    psi[14,8]  column_4  1
    psi[14,8]  column_5  1
    psi[14,8]  column_6  1
    psi[14,8]  column_7  1
    psi[14,8]  column_8  1
    psi[14,8]  column_9  1
    psi[14,8]  column_10  1
    psi[14,8]  column_11  1
    psi[14,8]  column_12  1
    psi[14,8]  column_13  1
    psi[14,8]  column_14  1
    psi[14,8]  column_15  1
    psi[14,8]  column_16  1
    psi[14,8]  column_17  1
    psi[14,8]  column_20  1
    psi[14,8]  column_21  1
    psi[14,8]  column_22  1
    psi[14,8]  column_27  1
    psi[14,8]  column_28  1
    psi[14,8]  column_29  1
    psi[14,8]  column_30  1
    psi[14,8]  column_31  1
    psi[14,8]  column_32  1
    psi[14,8]  column_33  1
    psi[14,8]  column_34  1
    psi[14,8]  column_35  1
    psi[14,8]  column_36  1
    psi[15,3]  OBJ       2.1574187123557209e-01
    psi[15,3]  column_20  1
    psi[15,3]  column_24  1
    psi[15,9]  OBJ       7.8425812876442791e-01
    psi[15,9]  column_0  1
    psi[15,9]  column_1  1
    psi[15,9]  column_2  1
    psi[15,9]  column_3  1
    psi[15,9]  column_4  1
    psi[15,9]  column_5  1
    psi[15,9]  column_6  1
    psi[15,9]  column_7  1
    psi[15,9]  column_8  1
    psi[15,9]  column_9  1
    psi[15,9]  column_10  1
    psi[15,9]  column_11  1
    psi[15,9]  column_12  1
    psi[15,9]  column_13  1
    psi[15,9]  column_14  1
    psi[15,9]  column_15  1
    psi[15,9]  column_16  1
    psi[15,9]  column_17  1
    psi[15,9]  column_18  1
    psi[15,9]  column_19  1
    psi[15,9]  column_21  1
    psi[15,9]  column_22  1
    psi[15,9]  column_23  1
    psi[15,9]  column_25  1
    psi[15,9]  column_26  1
    psi[15,9]  column_27  1
    psi[15,9]  column_28  1
    psi[15,9]  column_29  1
    psi[15,9]  column_30  1
    psi[15,9]  column_31  1
    psi[15,9]  column_32  1
    psi[15,9]  column_33  1
    psi[15,9]  column_34  1
    psi[15,9]  column_35  1
    psi[15,9]  column_36  1
    psi[16,1]  OBJ       1.7259349698845750e-01
    psi[16,1]  column_0  1
    psi[16,1]  column_1  1
    psi[16,1]  column_2  1
    psi[16,1]  column_8  1
    psi[16,1]  column_25  1
    psi[16,1]  column_27  1
    psi[16,1]  column_28  1
    psi[16,1]  column_29  1
    psi[16,1]  column_30  1
    psi[16,6]  OBJ       8.2740650301154239e-01
    psi[16,6]  column_3  1
    psi[16,6]  column_4  1
    psi[16,6]  column_5  1
    psi[16,6]  column_6  1
    psi[16,6]  column_7  1
    psi[16,6]  column_9  1
    psi[16,6]  column_10  1
    psi[16,6]  column_11  1
    psi[16,6]  column_12  1
    psi[16,6]  column_13  1
    psi[16,6]  column_14  1
    psi[16,6]  column_15  1
    psi[16,6]  column_16  1
    psi[16,6]  column_17  1
    psi[16,6]  column_18  1
    psi[16,6]  column_19  1
    psi[16,6]  column_20  1
    psi[16,6]  column_21  1
    psi[16,6]  column_22  1
    psi[16,6]  column_23  1
    psi[16,6]  column_24  1
    psi[16,6]  column_26  1
    psi[16,6]  column_31  1
    psi[16,6]  column_32  1
    psi[16,6]  column_33  1
    psi[16,6]  column_34  1
    psi[16,6]  column_35  1
    psi[16,6]  column_36  1
    psi[17,3]  OBJ       2.1574187123557209e-01
    psi[17,3]  column_27  1
    psi[17,3]  column_31  1
    psi[17,3]  column_32  1
    psi[17,3]  column_34  1
    psi[17,3]  column_36  1
    psi[17,9]  OBJ       7.8425812876442769e-01
    psi[17,9]  column_0  1
    psi[17,9]  column_1  1
    psi[17,9]  column_2  1
    psi[17,9]  column_3  1
    psi[17,9]  column_4  1
    psi[17,9]  column_5  1
    psi[17,9]  column_6  1
    psi[17,9]  column_7  1
    psi[17,9]  column_8  1
    psi[17,9]  column_9  1
    psi[17,9]  column_10  1
    psi[17,9]  column_11  1
    psi[17,9]  column_12  1
    psi[17,9]  column_13  1
    psi[17,9]  column_14  1
    psi[17,9]  column_15  1
    psi[17,9]  column_16  1
    psi[17,9]  column_17  1
    psi[17,9]  column_18  1
    psi[17,9]  column_19  1
    psi[17,9]  column_20  1
    psi[17,9]  column_21  1
    psi[17,9]  column_22  1
    psi[17,9]  column_23  1
    psi[17,9]  column_24  1
    psi[17,9]  column_25  1
    psi[17,9]  column_26  1
    psi[17,9]  column_28  1
    psi[17,9]  column_29  1
    psi[17,9]  column_30  1
    psi[17,9]  column_33  1
    psi[17,9]  column_35  1
    psi[18,4]  OBJ       2.5889024548268674e-01
    psi[18,4]  column_3  1
    psi[18,4]  column_4  1
    psi[18,4]  column_9  1
    psi[18,4]  column_10  1
    psi[18,4]  column_12  1
    psi[18,4]  column_13  1
    psi[18,4]  column_14  1
    psi[18,4]  column_15  1
    psi[18,4]  column_16  1
    psi[18,4]  column_17  1
    psi[18,4]  column_21  1
    psi[18,4]  column_22  1
    psi[18,4]  column_31  1
    psi[18,4]  column_32  1
    psi[18,9]  OBJ       7.4110975451731331e-01
    psi[18,9]  column_0  1
    psi[18,9]  column_1  1
    psi[18,9]  column_2  1
    psi[18,9]  column_5  1
    psi[18,9]  column_6  1
    psi[18,9]  column_7  1
    psi[18,9]  column_8  1
    psi[18,9]  column_11  1
    psi[18,9]  column_18  1
    psi[18,9]  column_19  1
    psi[18,9]  column_20  1
    psi[18,9]  column_23  1
    psi[18,9]  column_24  1
    psi[18,9]  column_25  1
    psi[18,9]  column_26  1
    psi[18,9]  column_27  1
    psi[18,9]  column_28  1
    psi[18,9]  column_29  1
    psi[18,9]  column_30  1
    psi[18,9]  column_33  1
    psi[18,9]  column_34  1
    psi[18,9]  column_35  1
    psi[18,9]  column_36  1
    psi[19,2]  OBJ       0.559048733822161
    psi[19,2]  column_5  1
    psi[19,2]  column_6  1
    psi[19,2]  column_7  1
    psi[19,2]  column_11  1
    psi[19,2]  column_12  1
    psi[19,2]  column_13  1
    psi[19,2]  column_14  1
    psi[19,2]  column_20  1
    psi[19,2]  column_21  1
    psi[19,2]  column_22  1
    psi[19,2]  column_26  1
    psi[19,2]  column_31  1
    psi[19,2]  column_33  1
    psi[19,2]  column_34  1
    psi[19,2]  column_36  1
    psi[19,4]  OBJ       0.440951266177839
    psi[19,4]  column_0  1
    psi[19,4]  column_1  1
    psi[19,4]  column_2  1
    psi[19,4]  column_3  1
    psi[19,4]  column_4  1
    psi[19,4]  column_8  1
    psi[19,4]  column_9  1
    psi[19,4]  column_10  1
    psi[19,4]  column_15  1
    psi[19,4]  column_16  1
    psi[19,4]  column_17  1
    psi[19,4]  column_18  1
    psi[19,4]  column_19  1
    psi[19,4]  column_23  1
    psi[19,4]  column_24  1
    psi[19,4]  column_25  1
    psi[19,4]  column_27  1
    psi[19,4]  column_28  1
    psi[19,4]  column_29  1
    psi[19,4]  column_30  1
    psi[19,4]  column_32  1
    psi[19,4]  column_35  1
    psi[20,3]  OBJ       2.8765582831409614e-01
    psi[20,3]  column_0  1
    psi[20,3]  column_1  1
    psi[20,3]  column_2  1
    psi[20,3]  column_3  1
    psi[20,3]  column_4  1
    psi[20,3]  column_8  1
    psi[20,3]  column_9  1
    psi[20,3]  column_10  1
    psi[20,3]  column_12  1
    psi[20,3]  column_24  1
    psi[20,3]  column_28  1
    psi[20,3]  column_29  1
    psi[20,3]  column_31  1
    psi[20,6]  OBJ       7.1234417168590380e-01
    psi[20,6]  column_5  1
    psi[20,6]  column_6  1
    psi[20,6]  column_7  1
    psi[20,6]  column_11  1
    psi[20,6]  column_13  1
    psi[20,6]  column_14  1
    psi[20,6]  column_15  1
    psi[20,6]  column_16  1
    psi[20,6]  column_17  1
    psi[20,6]  column_18  1
    psi[20,6]  column_19  1
    psi[20,6]  column_20  1
    psi[20,6]  column_21  1
    psi[20,6]  column_22  1
    psi[20,6]  column_23  1
    psi[20,6]  column_25  1
    psi[20,6]  column_26  1
    psi[20,6]  column_27  1
    psi[20,6]  column_30  1
    psi[20,6]  column_32  1
    psi[20,6]  column_33  1
    psi[20,6]  column_34  1
    psi[20,6]  column_35  1
    psi[20,6]  column_36  1
    psi[21,4]  OBJ       2.9279725078819794e-02
    psi[21,4]  column_30  1
    psi[21,4]  column_35  1
    psi[21,5]  OBJ       0.0313920690099627
    psi[21,5]  column_12  1
    psi[21,5]  column_15  1
    psi[21,5]  column_28  1
    psi[21,7]  OBJ       9.3932820591121746e-01
    psi[21,7]  column_0  1
    psi[21,7]  column_1  1
    psi[21,7]  column_2  1
    psi[21,7]  column_3  1
    psi[21,7]  column_4  1
    psi[21,7]  column_5  1
    psi[21,7]  column_6  1
    psi[21,7]  column_7  1
    psi[21,7]  column_8  1
    psi[21,7]  column_9  1
    psi[21,7]  column_10  1
    psi[21,7]  column_11  1
    psi[21,7]  column_13  1
    psi[21,7]  column_14  1
    psi[21,7]  column_16  1
    psi[21,7]  column_17  1
    psi[21,7]  column_18  1
    psi[21,7]  column_19  1
    psi[21,7]  column_20  1
    psi[21,7]  column_21  1
    psi[21,7]  column_22  1
    psi[21,7]  column_23  1
    psi[21,7]  column_24  1
    psi[21,7]  column_25  1
    psi[21,7]  column_26  1
    psi[21,7]  column_27  1
    psi[21,7]  column_29  1
    psi[21,7]  column_31  1
    psi[21,7]  column_32  1
    psi[21,7]  column_33  1
    psi[21,7]  column_34  1
    psi[21,7]  column_36  1
    psi[22,5]  OBJ       8.6296748494228837e-01
    psi[22,5]  column_1  1
    psi[22,5]  column_3  1
    psi[22,5]  column_5  1
    psi[22,5]  column_6  1
    psi[22,5]  column_7  1
    psi[22,5]  column_9  1
    psi[22,5]  column_11  1
    psi[22,5]  column_12  1
    psi[22,5]  column_13  1
    psi[22,5]  column_14  1
    psi[22,5]  column_15  1
    psi[22,5]  column_16  1
    psi[22,5]  column_17  1
    psi[22,5]  column_18  1
    psi[22,5]  column_19  1
    psi[22,5]  column_20  1
    psi[22,5]  column_21  1
    psi[22,5]  column_22  1
    psi[22,5]  column_23  1
    psi[22,5]  column_25  1
    psi[22,5]  column_26  1
    psi[22,5]  column_27  1
    psi[22,5]  column_28  1
    psi[22,5]  column_29  1
    psi[22,5]  column_30  1
    psi[22,5]  column_31  1
    psi[22,5]  column_32  1
    psi[22,5]  column_33  1
    psi[22,5]  column_34  1
    psi[22,5]  column_35  1
    psi[22,5]  column_36  1
    psi[22,6]  OBJ       1.3703251505771163e-01
    psi[22,6]  column_0  1
    psi[22,6]  column_2  1
    psi[22,6]  column_4  1
    psi[22,6]  column_8  1
    psi[22,6]  column_10  1
    psi[22,6]  column_24  1
    psi[23,4]  OBJ       7.1913957078524149e-01
    psi[23,4]  column_1  1
    psi[23,4]  column_5  1
    psi[23,4]  column_6  1
    psi[23,4]  column_7  1
    psi[23,4]  column_11  1
    psi[23,4]  column_12  1
    psi[23,4]  column_16  1
    psi[23,4]  column_17  1
    psi[23,4]  column_18  1
    psi[23,4]  column_19  1
    psi[23,4]  column_20  1
    psi[23,4]  column_23  1
    psi[23,4]  column_25  1
    psi[23,4]  column_26  1
    psi[23,4]  column_27  1
    psi[23,4]  column_29  1
    psi[23,4]  column_30  1
    psi[23,4]  column_32  1
    psi[23,4]  column_33  1
    psi[23,4]  column_34  1
    psi[23,4]  column_35  1
    psi[23,4]  column_36  1
    psi[23,5]  OBJ       2.8086042921475851e-01
    psi[23,5]  column_0  1
    psi[23,5]  column_2  1
    psi[23,5]  column_3  1
    psi[23,5]  column_4  1
    psi[23,5]  column_8  1
    psi[23,5]  column_9  1
    psi[23,5]  column_10  1
    psi[23,5]  column_13  1
    psi[23,5]  column_14  1
    psi[23,5]  column_15  1
    psi[23,5]  column_21  1
    psi[23,5]  column_22  1
    psi[23,5]  column_24  1
    psi[23,5]  column_28  1
    psi[23,5]  column_31  1
    psi[24,5]  OBJ       7.5311656628191948e-02
    psi[24,5]  column_3  1
    psi[24,5]  column_9  1
    psi[24,5]  column_16  1
    psi[24,5]  column_26  1
    psi[24,7]  OBJ       0.924688343371808
    psi[24,7]  column_0  1
    psi[24,7]  column_1  1
    psi[24,7]  column_2  1
    psi[24,7]  column_4  1
    psi[24,7]  column_5  1
    psi[24,7]  column_6  1
    psi[24,7]  column_7  1
    psi[24,7]  column_8  1
    psi[24,7]  column_10  1
    psi[24,7]  column_11  1
    psi[24,7]  column_12  1
    psi[24,7]  column_13  1
    psi[24,7]  column_14  1
    psi[24,7]  column_15  1
    psi[24,7]  column_17  1
    psi[24,7]  column_18  1
    psi[24,7]  column_19  1
    psi[24,7]  column_20  1
    psi[24,7]  column_21  1
    psi[24,7]  column_22  1
    psi[24,7]  column_23  1
    psi[24,7]  column_24  1
    psi[24,7]  column_25  1
    psi[24,7]  column_27  1
    psi[24,7]  column_28  1
    psi[24,7]  column_29  1
    psi[24,7]  column_30  1
    psi[24,7]  column_31  1
    psi[24,7]  column_32  1
    psi[24,7]  column_33  1
    psi[24,7]  column_34  1
    psi[24,7]  column_35  1
    psi[24,7]  column_36  1
    psi[25,1]  OBJ       1.6779923318322285e-01
    psi[25,1]  column_33  1
    psi[25,1]  column_34  1
    psi[25,1]  column_35  1
    psi[25,1]  column_36  1
    psi[25,7]  OBJ       8.3220076681677713e-01
    psi[25,7]  column_0  1
    psi[25,7]  column_1  1
    psi[25,7]  column_2  1
    psi[25,7]  column_3  1
    psi[25,7]  column_4  1
    psi[25,7]  column_5  1
    psi[25,7]  column_6  1
    psi[25,7]  column_7  1
    psi[25,7]  column_8  1
    psi[25,7]  column_9  1
    psi[25,7]  column_10  1
    psi[25,7]  column_11  1
    psi[25,7]  column_12  1
    psi[25,7]  column_13  1
    psi[25,7]  column_14  1
    psi[25,7]  column_15  1
    psi[25,7]  column_16  1
    psi[25,7]  column_17  1
    psi[25,7]  column_18  1
    psi[25,7]  column_19  1
    psi[25,7]  column_20  1
    psi[25,7]  column_21  1
    psi[25,7]  column_22  1
    psi[25,7]  column_23  1
    psi[25,7]  column_24  1
    psi[25,7]  column_25  1
    psi[25,7]  column_26  1
    psi[25,7]  column_27  1
    psi[25,7]  column_28  1
    psi[25,7]  column_29  1
    psi[25,7]  column_30  1
    psi[25,7]  column_31  1
    psi[25,7]  column_32  1
    psi[26,2]  OBJ       0.559048733822161
    psi[26,2]  column_5  1
    psi[26,2]  column_6  1
    psi[26,2]  column_7  1
    psi[26,2]  column_8  1
    psi[26,2]  column_11  1
    psi[26,2]  column_12  1
    psi[26,2]  column_16  1
    psi[26,2]  column_18  1
    psi[26,2]  column_19  1
    psi[26,2]  column_20  1
    psi[26,2]  column_23  1
    psi[26,2]  column_25  1
    psi[26,2]  column_26  1
    psi[26,2]  column_27  1
    psi[26,2]  column_34  1
    psi[26,2]  column_35  1
    psi[26,2]  column_36  1
    psi[26,4]  OBJ       0.440951266177839
    psi[26,4]  column_0  1
    psi[26,4]  column_1  1
    psi[26,4]  column_2  1
    psi[26,4]  column_3  1
    psi[26,4]  column_4  1
    psi[26,4]  column_9  1
    psi[26,4]  column_10  1
    psi[26,4]  column_13  1
    psi[26,4]  column_14  1
    psi[26,4]  column_15  1
    psi[26,4]  column_17  1
    psi[26,4]  column_21  1
    psi[26,4]  column_22  1
    psi[26,4]  column_24  1
    psi[26,4]  column_28  1
    psi[26,4]  column_29  1
    psi[26,4]  column_30  1
    psi[26,4]  column_31  1
    psi[26,4]  column_32  1
    psi[26,4]  column_33  1
    psi[27,3]  OBJ       2.5169884977483425e-01
    psi[27,3]  column_5  1
    psi[27,3]  column_6  1
    psi[27,3]  column_18  1
    psi[27,3]  column_19  1
    psi[27,3]  column_20  1
    psi[27,3]  column_21  1
    psi[27,3]  column_25  1
    psi[27,7]  OBJ       7.4830115022516575e-01
    psi[27,7]  column_0  1
    psi[27,7]  column_1  1
    psi[27,7]  column_2  1
    psi[27,7]  column_3  1
    psi[27,7]  column_4  1
    psi[27,7]  column_7  1
    psi[27,7]  column_8  1
    psi[27,7]  column_9  1
    psi[27,7]  column_10  1
    psi[27,7]  column_11  1
    psi[27,7]  column_12  1
    psi[27,7]  column_13  1
    psi[27,7]  column_14  1
    psi[27,7]  column_15  1
    psi[27,7]  column_16  1
    psi[27,7]  column_17  1
    psi[27,7]  column_22  1
    psi[27,7]  column_23  1
    psi[27,7]  column_24  1
    psi[27,7]  column_26  1
    psi[27,7]  column_27  1
    psi[27,7]  column_28  1
    psi[27,7]  column_29  1
    psi[27,7]  column_30  1
    psi[27,7]  column_31  1
    psi[27,7]  column_32  1
    psi[27,7]  column_33  1
    psi[27,7]  column_34  1
    psi[27,7]  column_35  1
    psi[27,7]  column_36  1
    psi[28,5]  OBJ       3.8354110441879491e-01
    psi[28,5]  column_0  1
    psi[28,5]  column_2  1
    psi[28,5]  column_4  1
    psi[28,5]  column_7  1
    psi[28,5]  column_10  1
    psi[28,5]  column_11  1
    psi[28,5]  column_13  1
    psi[28,5]  column_14  1
    psi[28,5]  column_15  1
    psi[28,5]  column_17  1
    psi[28,5]  column_21  1
    psi[28,5]  column_22  1
    psi[28,5]  column_23  1
    psi[28,5]  column_24  1
    psi[28,5]  column_27  1
    psi[28,5]  column_28  1
    psi[28,5]  column_33  1
    psi[28,5]  column_35  1
    psi[28,8]  OBJ       6.1645889558120515e-01
    psi[28,8]  column_1  1
    psi[28,8]  column_3  1
    psi[28,8]  column_5  1
    psi[28,8]  column_6  1
    psi[28,8]  column_8  1
    psi[28,8]  column_9  1
    psi[28,8]  column_12  1
    psi[28,8]  column_16  1
    psi[28,8]  column_18  1
    psi[28,8]  column_19  1
    psi[28,8]  column_20  1
    psi[28,8]  column_25  1
    psi[28,8]  column_26  1
    psi[28,8]  column_29  1
    psi[28,8]  column_30  1
    psi[28,8]  column_31  1
    psi[28,8]  column_32  1
    psi[28,8]  column_34  1
    psi[28,8]  column_36  1
    psi[29,5]  OBJ       3.8354110441879491e-01
    psi[29,5]  column_13  1
    psi[29,5]  column_16  1
    psi[29,5]  column_17  1
    psi[29,5]  column_26  1
    psi[29,5]  column_29  1
    psi[29,5]  column_30  1
    psi[29,5]  column_31  1
    psi[29,5]  column_32  1
    psi[29,5]  column_33  1
    psi[29,5]  column_34  1
    psi[29,5]  column_35  1
    psi[29,5]  column_36  1
    psi[29,8]  OBJ       6.1645889558120515e-01
    psi[29,8]  column_0  1
    psi[29,8]  column_1  1
    psi[29,8]  column_2  1
    psi[29,8]  column_3  1
    psi[29,8]  column_4  1
    psi[29,8]  column_5  1
    psi[29,8]  column_6  1
    psi[29,8]  column_7  1
    psi[29,8]  column_8  1
    psi[29,8]  column_9  1
    psi[29,8]  column_10  1
    psi[29,8]  column_11  1
    psi[29,8]  column_12  1
    psi[29,8]  column_14  1
    psi[29,8]  column_15  1
    psi[29,8]  column_18  1
    psi[29,8]  column_19  1
    psi[29,8]  column_20  1
    psi[29,8]  column_21  1
    psi[29,8]  column_22  1
    psi[29,8]  column_23  1
    psi[29,8]  column_24  1
    psi[29,8]  column_25  1
    psi[29,8]  column_27  1
    psi[29,8]  column_28  1
    psi[30,2]  OBJ       1.4948953665449582e-01
    psi[30,2]  column_13  1
    psi[30,2]  column_16  1
    psi[30,2]  column_26  1
    psi[30,2]  column_31  1
    psi[30,2]  column_34  1
    psi[30,3]  OBJ       8.1911839433533107e-01
    psi[30,3]  column_0  1
    psi[30,3]  column_1  1
    psi[30,3]  column_2  1
    psi[30,3]  column_3  1
    psi[30,3]  column_4  1
    psi[30,3]  column_5  1
    psi[30,3]  column_6  1
    psi[30,3]  column_7  1
    psi[30,3]  column_8  1
    psi[30,3]  column_9  1
    psi[30,3]  column_10  1
    psi[30,3]  column_11  1
    psi[30,3]  column_12  1
    psi[30,3]  column_14  1
    psi[30,3]  column_15  1
    psi[30,3]  column_17  1
    psi[30,3]  column_18  1
    psi[30,3]  column_20  1
    psi[30,3]  column_21  1
    psi[30,3]  column_22  1
    psi[30,3]  column_23  1
    psi[30,3]  column_24  1
    psi[30,3]  column_25  1
    psi[30,3]  column_27  1
    psi[30,3]  column_28  1
    psi[30,3]  column_29  1
    psi[30,3]  column_30  1
    psi[30,3]  column_32  1
    psi[30,3]  column_33  1
    psi[30,3]  column_35  1
    psi[30,3]  column_36  1
    psi[30,4]  OBJ       3.1392069010173149e-02
    psi[30,4]  column_19  1
    psi[31,2]  OBJ       2.0135907981986736e-01
    psi[31,2]  column_29  1
    psi[31,2]  column_30  1
    psi[31,2]  column_32  1
    psi[31,2]  column_33  1
    psi[31,2]  column_35  1
    psi[31,7]  OBJ       7.9864092018013266e-01
    psi[31,7]  column_0  1
    psi[31,7]  column_1  1
    psi[31,7]  column_2  1
    psi[31,7]  column_3  1
    psi[31,7]  column_4  1
    psi[31,7]  column_5  1
    psi[31,7]  column_6  1
    psi[31,7]  column_7  1
    psi[31,7]  column_8  1
    psi[31,7]  column_9  1
    psi[31,7]  column_10  1
    psi[31,7]  column_11  1
    psi[31,7]  column_12  1
    psi[31,7]  column_13  1
    psi[31,7]  column_14  1
    psi[31,7]  column_15  1
    psi[31,7]  column_16  1
    psi[31,7]  column_17  1
    psi[31,7]  column_18  1
    psi[31,7]  column_19  1
    psi[31,7]  column_20  1
    psi[31,7]  column_21  1
    psi[31,7]  column_22  1
    psi[31,7]  column_23  1
    psi[31,7]  column_24  1
    psi[31,7]  column_25  1
    psi[31,7]  column_26  1
    psi[31,7]  column_27  1
    psi[31,7]  column_28  1
    psi[31,7]  column_31  1
    psi[31,7]  column_34  1
    psi[31,7]  column_36  1
    psi[32,4]  OBJ       7.1913957078524149e-01
    psi[32,4]  column_0  1
    psi[32,4]  column_2  1
    psi[32,4]  column_3  1
    psi[32,4]  column_4  1
    psi[32,4]  column_7  1
    psi[32,4]  column_9  1
    psi[32,4]  column_10  1
    psi[32,4]  column_11  1
    psi[32,4]  column_13  1
    psi[32,4]  column_14  1
    psi[32,4]  column_15  1
    psi[32,4]  column_16  1
    psi[32,4]  column_17  1
    psi[32,4]  column_19  1
    psi[32,4]  column_21  1
    psi[32,4]  column_22  1
    psi[32,4]  column_23  1
    psi[32,4]  column_24  1
    psi[32,4]  column_26  1
    psi[32,4]  column_27  1
    psi[32,4]  column_28  1
    psi[32,4]  column_29  1
    psi[32,4]  column_30  1
    psi[32,4]  column_31  1
    psi[32,4]  column_32  1
    psi[32,4]  column_33  1
    psi[32,4]  column_34  1
    psi[32,4]  column_35  1
    psi[32,4]  column_36  1
    psi[32,5]  OBJ       2.8086042921475851e-01
    psi[32,5]  column_1  1
    psi[32,5]  column_5  1
    psi[32,5]  column_6  1
    psi[32,5]  column_8  1
    psi[32,5]  column_12  1
    psi[32,5]  column_18  1
    psi[32,5]  column_20  1
    psi[32,5]  column_25  1
    psi[33,4]  OBJ       1.9093734054755451e-02
    psi[33,4]  column_14  1
    psi[33,4]  column_15  1
    psi[33,4]  column_22  1
    psi[33,4]  column_28  1
    psi[33,6]  OBJ       9.4951419693507144e-01
    psi[33,6]  column_0  1
    psi[33,6]  column_1  1
    psi[33,6]  column_2  1
    psi[33,6]  column_3  1
    psi[33,6]  column_4  1
    psi[33,6]  column_5  1
    psi[33,6]  column_6  1
    psi[33,6]  column_7  1
    psi[33,6]  column_8  1
    psi[33,6]  column_9  1
    psi[33,6]  column_10  1
    psi[33,6]  column_11  1
    psi[33,6]  column_12  1
    psi[33,6]  column_13  1
    psi[33,6]  column_16  1
    psi[33,6]  column_17  1
    psi[33,6]  column_18  1
    psi[33,6]  column_19  1
    psi[33,6]  column_20  1
    psi[33,6]  column_21  1
    psi[33,6]  column_23  1
    psi[33,6]  column_24  1
    psi[33,6]  column_25  1
    psi[33,6]  column_26  1
    psi[33,6]  column_27  1
    psi[33,6]  column_29  1
    psi[33,6]  column_30  1
    psi[33,6]  column_31  1
    psi[33,6]  column_32  1
    psi[33,6]  column_33  1
    psi[33,6]  column_34  1
    psi[33,6]  column_35  1
    psi[33,7]  OBJ       3.1392069010173149e-02
    psi[33,7]  column_36  1
    psi[34,3]  OBJ       3.5956978539262152e-01
    psi[34,3]  column_1  1
    psi[34,3]  column_5  1
    psi[34,3]  column_7  1
    psi[34,3]  column_11  1
    psi[34,3]  column_13  1
    psi[34,3]  column_14  1
    psi[34,3]  column_15  1
    psi[34,3]  column_17  1
    psi[34,3]  column_19  1
    psi[34,3]  column_22  1
    psi[34,3]  column_23  1
    psi[34,3]  column_26  1
    psi[34,3]  column_27  1
    psi[34,3]  column_28  1
    psi[34,3]  column_29  1
    psi[34,3]  column_32  1
    psi[34,3]  column_34  1
    psi[34,3]  column_35  1
    psi[34,3]  column_36  1
    psi[34,5]  OBJ       6.4043021460737881e-01
    psi[34,5]  column_0  1
    psi[34,5]  column_2  1
    psi[34,5]  column_3  1
    psi[34,5]  column_4  1
    psi[34,5]  column_6  1
    psi[34,5]  column_8  1
    psi[34,5]  column_9  1
    psi[34,5]  column_10  1
    psi[34,5]  column_12  1
    psi[34,5]  column_16  1
    psi[34,5]  column_18  1
    psi[34,5]  column_20  1
    psi[34,5]  column_21  1
    psi[34,5]  column_24  1
    psi[34,5]  column_25  1
    psi[34,5]  column_30  1
    psi[34,5]  column_31  1
    psi[34,5]  column_33  1
    psi[35,6]  OBJ       5.7531165662819250e-01
    psi[35,6]  column_6  1
    psi[35,6]  column_8  1
    psi[35,6]  column_12  1
    psi[35,6]  column_14  1
    psi[35,6]  column_15  1
    psi[35,6]  column_16  1
    psi[35,6]  column_17  1
    psi[35,6]  column_18  1
    psi[35,6]  column_20  1
    psi[35,6]  column_21  1
    psi[35,6]  column_22  1
    psi[35,6]  column_25  1
    psi[35,6]  column_28  1
    psi[35,6]  column_30  1
    psi[35,6]  column_31  1
    psi[35,6]  column_33  1
    psi[35,6]  column_36  1
    psi[35,8]  OBJ       4.2468834337180750e-01
    psi[35,8]  column_0  1
    psi[35,8]  column_1  1
    psi[35,8]  column_2  1
    psi[35,8]  column_3  1
    psi[35,8]  column_4  1
    psi[35,8]  column_5  1
    psi[35,8]  column_7  1
    psi[35,8]  column_9  1
    psi[35,8]  column_10  1
    psi[35,8]  column_11  1
    psi[35,8]  column_13  1
    psi[35,8]  column_19  1
    psi[35,8]  column_23  1
    psi[35,8]  column_24  1
    psi[35,8]  column_26  1
    psi[35,8]  column_27  1
    psi[35,8]  column_29  1
    psi[35,8]  column_32  1
    psi[35,8]  column_34  1
    psi[35,8]  column_35  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
    a         column_14  1
    a         column_15  1
    a         column_16  1
    a         column_17  1
    a         column_18  1
    a         column_19  1
    a         column_20  1
    a         column_21  1
    a         column_22  1
    a         column_23  1
    a         column_24  1
    a         column_25  1
    a         column_26  1
    a         column_27  1
    a         column_28  1
    a         column_29  1
    a         column_30  1
    a         column_31  1
    a         column_32  1
    a         column_33  1
    a         column_34  1
    a         column_35  1
    a         column_36  1
RHS
    RHS1      column_0  1.1886832105511284e-01
    RHS1      column_1  1.2093980449322587e-01
    RHS1      column_2  1.1886832105511284e-01
    RHS1      column_3  1.0955637041267172e-01
    RHS1      column_4  1.0887630353179972e-01
    RHS1      column_5  1.2037111738604277e-01
    RHS1      column_6  1.1687269224594639e-01
    RHS1      column_7  1.1595479197044535e-01
    RHS1      column_8  1.2164174862145417e-01
    RHS1      column_9  1.0797821235106977e-01
    RHS1      column_10  1.1428496249504290e-01
    RHS1      column_11  1.2702723230717997e-01
    RHS1      column_12  1.1559693210119033e-01
    RHS1      column_13  1.1347607770990685e-01
    RHS1      column_14  1.1066345547119116e-01
    RHS1      column_15  1.0653296927352782e-01
    RHS1      column_16  1.1119406239039974e-01
    RHS1      column_17  1.0182856841796281e-01
    RHS1      column_18  1.1135525342160114e-01
    RHS1      column_19  1.1353496523263046e-01
    RHS1      column_20  1.2016894250689621e-01
    RHS1      column_21  1.1280795356258057e-01
    RHS1      column_22  1.1414208389458746e-01
    RHS1      column_23  1.2151172793485118e-01
    RHS1      column_24  1.1702443512471568e-01
    RHS1      column_25  1.2051449151089008e-01
    RHS1      column_26  1.2002288395638180e-01
    RHS1      column_27  1.1704533082736926e-01
    RHS1      column_28  1.1464001417199546e-01
    RHS1      column_29  1.1870268657059065e-01
    RHS1      column_30  1.1441081806498574e-01
    RHS1      column_31  1.1406926694602298e-01
    RHS1      column_32  1.1059790966539175e-01
    RHS1      column_33  1.1759273052286609e-01
    RHS1      column_34  1.2962548748051528e-01
    RHS1      column_35  1.2349306871732621e-01
    RHS1      column_36  1.2512470373851717e-01
BOUNDS
 LO BND1      psi[1,5]  -0.05
 UP BND1      psi[1,5]  0.05
 FX BND1      psi[1,9]  0
 LO BND1      psi[2,3]  -0.05
 UP BND1      psi[2,3]  0.05
 FX BND1      psi[2,7]  0
 LO BND1      psi[3,4]  -0.05
 UP BND1      psi[3,4]  0.05
 FX BND1      psi[3,8]  0
 LO BND1      psi[4,3]  -0.05
 UP BND1      psi[4,3]  0.05
 FX BND1      psi[4,6]  0
 LO BND1      psi[4,7]  -0.05
 UP BND1      psi[4,7]  0.05
 LO BND1      psi[5,2]  -0.05
 UP BND1      psi[5,2]  0.05
 FX BND1      psi[5,8]  0
 LO BND1      psi[6,1]  -0.05
 UP BND1      psi[6,1]  0.05
 FX BND1      psi[6,5]  0
 LO BND1      psi[7,4]  -0.05
 UP BND1      psi[7,4]  0.05
 FX BND1      psi[7,7]  0
 FX BND1      psi[8,10]  0
 LO BND1      psi[9,3]  -0.05
 UP BND1      psi[9,3]  0.05
 FX BND1      psi[9,5]  0
 LO BND1      psi[10,4]  -0.05
 UP BND1      psi[10,4]  0.05
 LO BND1      psi[10,7]  -0.05
 UP BND1      psi[10,7]  0.05
 FX BND1      psi[10,10]  0
 LO BND1      psi[11,3]  -0.05
 UP BND1      psi[11,3]  0.05
 FX BND1      psi[11,5]  0
 LO BND1      psi[12,3]  -0.05
 UP BND1      psi[12,3]  0.05
 FX BND1      psi[12,6]  0
 LO BND1      psi[12,7]  -0.05
 UP BND1      psi[12,7]  0.05
 LO BND1      psi[13,5]  -0.05
 UP BND1      psi[13,5]  0.05
 FX BND1      psi[13,7]  0
 LO BND1      psi[14,2]  -0.05
 UP BND1      psi[14,2]  0.05
 FX BND1      psi[14,8]  0
 LO BND1      psi[15,3]  -0.05
 UP BND1      psi[15,3]  0.05
 FX BND1      psi[15,9]  0
 LO BND1      psi[16,1]  -0.05
 UP BND1      psi[16,1]  0.05
 FX BND1      psi[16,6]  0
 LO BND1      psi[17,3]  -0.05
 UP BND1      psi[17,3]  0.05
 FX BND1      psi[17,9]  0
 LO BND1      psi[18,4]  -0.05
 UP BND1      psi[18,4]  0.05
 FX BND1      psi[18,9]  0
 FX BND1      psi[19,2]  0
 LO BND1      psi[19,4]  -0.05
 UP BND1      psi[19,4]  0.05
 LO BND1      psi[20,3]  -0.05
 UP BND1      psi[20,3]  0.05
 FX BND1      psi[20,6]  0
 LO BND1      psi[21,4]  -0.05
 UP BND1      psi[21,4]  0.05
 LO BND1      psi[21,5]  -0.05
 UP BND1      psi[21,5]  0.05
 FX BND1      psi[21,7]  0
 FX BND1      psi[22,5]  0
 LO BND1      psi[22,6]  -0.05
 UP BND1      psi[22,6]  0.05
 FX BND1      psi[23,4]  0
 LO BND1      psi[23,5]  -0.05
 UP BND1      psi[23,5]  0.05
 LO BND1      psi[24,5]  -0.05
 UP BND1      psi[24,5]  0.05
 FX BND1      psi[24,7]  0
 LO BND1      psi[25,1]  -0.05
 UP BND1      psi[25,1]  0.05
 FX BND1      psi[25,7]  0
 FX BND1      psi[26,2]  0
 LO BND1      psi[26,4]  -0.05
 UP BND1      psi[26,4]  0.05
 LO BND1      psi[27,3]  -0.05
 UP BND1      psi[27,3]  0.05
 FX BND1      psi[27,7]  0
 LO BND1      psi[28,5]  -0.05
 UP BND1      psi[28,5]  0.05
 FX BND1      psi[28,8]  0
 LO BND1      psi[29,5]  -0.05
 UP BND1      psi[29,5]  0.05
 FX BND1      psi[29,8]  0
 LO BND1      psi[30,2]  -0.05
 UP BND1      psi[30,2]  0.05
 FX BND1      psi[30,3]  0
 LO BND1      psi[30,4]  -0.05
 UP BND1      psi[30,4]  0.05
 LO BND1      psi[31,2]  -0.05
 UP BND1      psi[31,2]  0.05
 FX BND1      psi[31,7]  0
 FX BND1      psi[32,4]  0
 LO BND1      psi[32,5]  -0.05
 UP BND1      psi[32,5]  0.05
 LO BND1      psi[33,4]  -0.05
 UP BND1      psi[33,4]  0.05
 FX BND1      psi[33,6]  0
 LO BND1      psi[33,7]  -0.05
 UP BND1      psi[33,7]  0.05
 LO BND1      psi[34,3]  -0.05
 UP BND1      psi[34,3]  0.05
 FX BND1      psi[34,5]  0
 FX BND1      psi[35,6]  0
 LO BND1      psi[35,8]  -0.05
 UP BND1      psi[35,8]  0.05
 FR BND1      a       
ENDATA
