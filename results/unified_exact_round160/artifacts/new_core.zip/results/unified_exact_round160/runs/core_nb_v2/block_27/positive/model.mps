* Signature: 0xc7ab578a35ebc6ed
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_20_26
 E  normalized_mass_20_27
 E  normalized_ratio_20_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 E  onehot_21_61
 E  normalized_mass_21_62
 E  normalized_ratio_21_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 E  onehot_31_90
 E  normalized_mass_31_91
 E  normalized_ratio_31_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 E  onehot_23_117
 E  normalized_mass_23_118
 E  normalized_ratio_23_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_32_146
 E  normalized_mass_32_147
 E  normalized_ratio_32_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 E  onehot_16_175
 E  normalized_mass_16_176
 E  normalized_ratio_16_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 E  onehot_19_196
 E  normalized_mass_19_197
 E  normalized_ratio_19_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 E  onehot_11_225
 E  normalized_mass_11_226
 E  normalized_ratio_11_227
 G  stock_lb_228
 L  stock_ub_229
 L  parent_nonstrict_scope_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 E  normalization_287
 G  full_original_Gini_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 E  depot_departure_or_bypass_722
 E  depot_return_or_bypass_723
 E  out_degree_724
 E  in_degree_725
 G  order_active_lb_726
 L  order_active_ub_727
 E  segment_load_conservation_728
 G  segment_prefix_lb_729
 L  segment_prefix_ub_730
 E  out_degree_731
 E  in_degree_732
 G  order_active_lb_733
 L  order_active_ub_734
 E  segment_load_conservation_735
 G  segment_prefix_lb_736
 L  segment_prefix_ub_737
 E  out_degree_738
 E  in_degree_739
 G  order_active_lb_740
 L  order_active_ub_741
 E  segment_load_conservation_742
 G  segment_prefix_lb_743
 L  segment_prefix_ub_744
 E  out_degree_745
 E  in_degree_746
 G  order_active_lb_747
 L  order_active_ub_748
 E  segment_load_conservation_749
 G  segment_prefix_lb_750
 L  segment_prefix_ub_751
 E  out_degree_752
 E  in_degree_753
 G  order_active_lb_754
 L  order_active_ub_755
 E  segment_load_conservation_756
 G  segment_prefix_lb_757
 L  segment_prefix_ub_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  service_visit_def_781
 E  free_load_conservation_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  service_visit_def_787
 E  free_load_conservation_788
 E  out_degree_789
 E  in_degree_790
 G  order_active_lb_791
 L  order_active_ub_792
 E  service_visit_def_793
 E  free_load_conservation_794
 E  out_degree_795
 E  in_degree_796
 G  order_active_lb_797
 L  order_active_ub_798
 E  service_visit_def_799
 E  free_load_conservation_800
 E  out_degree_801
 E  in_degree_802
 G  order_active_lb_803
 L  order_active_ub_804
 E  service_visit_def_805
 E  free_load_conservation_806
 G  fixed_segment_relative_order_807
 G  fixed_segment_relative_order_808
 G  fixed_segment_relative_order_809
 G  fixed_segment_relative_order_810
 L  original_T_including_depot_unload_811
 L  arc_capacity_812
 L  arc_capacity_813
 L  arc_capacity_814
 L  arc_capacity_815
 L  arc_capacity_816
 L  arc_capacity_817
 L  arc_capacity_818
 L  arc_capacity_819
 L  arc_capacity_820
 L  arc_capacity_821
 L  arc_capacity_822
 L  arc_capacity_823
 L  arc_capacity_824
 L  arc_capacity_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 E  depot_departure_or_bypass_1101
 E  depot_return_or_bypass_1102
 E  out_degree_1103
 E  in_degree_1104
 G  order_active_lb_1105
 L  order_active_ub_1106
 E  segment_load_conservation_1107
 G  segment_prefix_lb_1108
 L  segment_prefix_ub_1109
 E  out_degree_1110
 E  in_degree_1111
 G  order_active_lb_1112
 L  order_active_ub_1113
 E  segment_load_conservation_1114
 G  segment_prefix_lb_1115
 L  segment_prefix_ub_1116
 E  out_degree_1117
 E  in_degree_1118
 G  order_active_lb_1119
 L  order_active_ub_1120
 E  segment_load_conservation_1121
 G  segment_prefix_lb_1122
 L  segment_prefix_ub_1123
 E  out_degree_1124
 E  in_degree_1125
 G  order_active_lb_1126
 L  order_active_ub_1127
 E  segment_load_conservation_1128
 G  segment_prefix_lb_1129
 L  segment_prefix_ub_1130
 E  out_degree_1131
 E  in_degree_1132
 G  order_active_lb_1133
 L  order_active_ub_1134
 E  service_visit_def_1135
 E  free_load_conservation_1136
 E  out_degree_1137
 E  in_degree_1138
 G  order_active_lb_1139
 L  order_active_ub_1140
 E  service_visit_def_1141
 E  free_load_conservation_1142
 E  out_degree_1143
 E  in_degree_1144
 G  order_active_lb_1145
 L  order_active_ub_1146
 E  service_visit_def_1147
 E  free_load_conservation_1148
 E  out_degree_1149
 E  in_degree_1150
 G  order_active_lb_1151
 L  order_active_ub_1152
 E  service_visit_def_1153
 E  free_load_conservation_1154
 E  out_degree_1155
 E  in_degree_1156
 G  order_active_lb_1157
 L  order_active_ub_1158
 E  service_visit_def_1159
 E  free_load_conservation_1160
 E  out_degree_1161
 E  in_degree_1162
 G  order_active_lb_1163
 L  order_active_ub_1164
 E  service_visit_def_1165
 E  free_load_conservation_1166
 E  out_degree_1167
 E  in_degree_1168
 G  order_active_lb_1169
 L  order_active_ub_1170
 E  service_visit_def_1171
 E  free_load_conservation_1172
 E  out_degree_1173
 E  in_degree_1174
 G  order_active_lb_1175
 L  order_active_ub_1176
 E  service_visit_def_1177
 E  free_load_conservation_1178
 G  fixed_segment_relative_order_1179
 G  fixed_segment_relative_order_1180
 G  fixed_segment_relative_order_1181
 L  original_T_including_depot_unload_1182
 L  arc_capacity_1183
 L  arc_capacity_1184
 L  arc_capacity_1185
 L  arc_capacity_1186
 L  arc_capacity_1187
 L  arc_capacity_1188
 L  arc_capacity_1189
 L  arc_capacity_1190
 L  arc_capacity_1191
 L  arc_capacity_1192
 L  arc_capacity_1193
 L  arc_capacity_1194
 L  arc_capacity_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 G  connected_order_arc_1228
 L  arc_capacity_1229
 G  connected_order_arc_1230
 L  arc_capacity_1231
 G  connected_order_arc_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 E  depot_departure_or_bypass_1426
 E  depot_return_or_bypass_1427
 E  out_degree_1428
 E  in_degree_1429
 G  order_active_lb_1430
 L  order_active_ub_1431
 E  segment_load_conservation_1432
 G  segment_prefix_lb_1433
 L  segment_prefix_ub_1434
 E  out_degree_1435
 E  in_degree_1436
 G  order_active_lb_1437
 L  order_active_ub_1438
 E  segment_load_conservation_1439
 G  segment_prefix_lb_1440
 L  segment_prefix_ub_1441
 E  out_degree_1442
 E  in_degree_1443
 G  order_active_lb_1444
 L  order_active_ub_1445
 E  segment_load_conservation_1446
 G  segment_prefix_lb_1447
 L  segment_prefix_ub_1448
 E  out_degree_1449
 E  in_degree_1450
 G  order_active_lb_1451
 L  order_active_ub_1452
 E  service_visit_def_1453
 E  free_load_conservation_1454
 E  out_degree_1455
 E  in_degree_1456
 G  order_active_lb_1457
 L  order_active_ub_1458
 E  service_visit_def_1459
 E  free_load_conservation_1460
 E  out_degree_1461
 E  in_degree_1462
 G  order_active_lb_1463
 L  order_active_ub_1464
 E  service_visit_def_1465
 E  free_load_conservation_1466
 E  out_degree_1467
 E  in_degree_1468
 G  order_active_lb_1469
 L  order_active_ub_1470
 E  service_visit_def_1471
 E  free_load_conservation_1472
 E  out_degree_1473
 E  in_degree_1474
 G  order_active_lb_1475
 L  order_active_ub_1476
 E  service_visit_def_1477
 E  free_load_conservation_1478
 E  out_degree_1479
 E  in_degree_1480
 G  order_active_lb_1481
 L  order_active_ub_1482
 E  service_visit_def_1483
 E  free_load_conservation_1484
 E  out_degree_1485
 E  in_degree_1486
 G  order_active_lb_1487
 L  order_active_ub_1488
 E  service_visit_def_1489
 E  free_load_conservation_1490
 E  out_degree_1491
 E  in_degree_1492
 G  order_active_lb_1493
 L  order_active_ub_1494
 E  service_visit_def_1495
 E  free_load_conservation_1496
 G  fixed_segment_relative_order_1497
 G  fixed_segment_relative_order_1498
 L  original_T_including_depot_unload_1499
COLUMNS
    t         normalized_mass_20_27  -1
    t         normalized_mass_21_62  -1
    t         normalized_mass_31_91  -1
    t         normalized_mass_23_118  -1
    t         normalized_mass_32_147  -1
    t         normalized_mass_16_176  -1
    t         normalized_mass_19_197  -1
    t         normalized_mass_11_226  -1
    t         normalization_287  2.3642857142857142e+01
    t         full_original_Gini_288  -78.4428571428572
    q         OBJ       1
    q         parent_nonstrict_scope_230  1
    q         full_original_Gini_288  35
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       0.027
    x_20_0    product_lb_0  -0.0248557478916751
    x_20_0    product_ub_1  -4.2296072507595178e-02
    x_20_0    onehot_20_26  1
    x_20_0    parent_nonstrict_scope_230  0.054
    x_20_0    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_0  1
    w_20_0    product_ub_1  1
    w_20_0    normalized_mass_20_27  1
    w_20_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       0.018
    x_20_1    product_lb_2  -0.0248557478916751
    x_20_1    product_ub_3  -4.2296072507595178e-02
    x_20_1    onehot_20_26  1
    x_20_1    stock_lb_228  1
    x_20_1    stock_ub_229  1
    x_20_1    parent_nonstrict_scope_230  0.045
    x_20_1    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_2  1
    w_20_1    product_ub_3  1
    w_20_1    normalized_mass_20_27  1
    w_20_1    normalized_ratio_20_28  -1.6666666666666666e-01
    w_20_1    full_original_Gini_288  -1.9476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       9.0000000000000045e-03
    x_20_2    product_lb_4  -0.0248557478916751
    x_20_2    product_ub_5  -4.2296072507595178e-02
    x_20_2    onehot_20_26  1
    x_20_2    stock_lb_228  2
    x_20_2    stock_ub_229  2
    x_20_2    parent_nonstrict_scope_230  3.6000000000000004e-02
    x_20_2    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_4  1
    w_20_2    product_ub_5  1
    w_20_2    normalized_mass_20_27  1
    w_20_2    normalized_ratio_20_28  -3.3333333333333331e-01
    w_20_2    full_original_Gini_288  -1.5309523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_3    product_lb_6  -0.0248557478916751
    x_20_3    product_ub_7  -4.2296072507595178e-02
    x_20_3    onehot_20_26  1
    x_20_3    stock_lb_228  3
    x_20_3    stock_ub_229  3
    x_20_3    parent_nonstrict_scope_230  0.027
    x_20_3    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_6  1
    w_20_3    product_ub_7  1
    w_20_3    normalized_mass_20_27  1
    w_20_3    normalized_ratio_20_28  -0.5
    w_20_3    full_original_Gini_288  -1.1542857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_4    OBJ       -8.9999999999999976e-03
    x_20_4    product_lb_8  -0.0248557478916751
    x_20_4    product_ub_9  -4.2296072507595178e-02
    x_20_4    onehot_20_26  1
    x_20_4    stock_lb_228  4
    x_20_4    stock_ub_229  4
    x_20_4    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_20_4    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_8  1
    w_20_4    product_ub_9  1
    w_20_4    normalized_mass_20_27  1
    w_20_4    normalized_ratio_20_28  -6.6666666666666663e-01
    w_20_4    full_original_Gini_288  -8.0428571428571427e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.7999999999999995e-02
    x_20_5    product_lb_10  -0.0248557478916751
    x_20_5    product_ub_11  -4.2296072507595178e-02
    x_20_5    onehot_20_26  1
    x_20_5    stock_lb_228  5
    x_20_5    stock_ub_229  5
    x_20_5    parent_nonstrict_scope_230  9.0000000000000045e-03
    x_20_5    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_10  1
    w_20_5    product_ub_11  1
    w_20_5    normalized_mass_20_27  1
    w_20_5    normalized_ratio_20_28  -8.3333333333333326e-01
    w_20_5    full_original_Gini_288  -5.0190476190476225e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -0.027
    x_20_6    product_lb_12  -0.0248557478916751
    x_20_6    product_ub_13  -4.2296072507595178e-02
    x_20_6    onehot_20_26  1
    x_20_6    stock_lb_228  6
    x_20_6    stock_ub_229  6
    x_20_6    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_12  1
    w_20_6    product_ub_13  1
    w_20_6    normalized_mass_20_27  1
    w_20_6    normalized_ratio_20_28  -1
    w_20_6    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -1.8000000000000009e-02
    x_20_7    product_lb_14  -0.0248557478916751
    x_20_7    product_ub_15  -4.2296072507595178e-02
    x_20_7    onehot_20_26  1
    x_20_7    stock_lb_228  7
    x_20_7    stock_ub_229  7
    x_20_7    parent_nonstrict_scope_230  8.9999999999999924e-03
    x_20_7    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_14  1
    w_20_7    product_ub_15  1
    w_20_7    normalized_mass_20_27  1
    w_20_7    normalized_ratio_20_28  -1.1666666666666665e+00
    w_20_7    full_original_Gini_288  -7.9238095238095170e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -9.0000000000000045e-03
    x_20_8    product_lb_16  -0.0248557478916751
    x_20_8    product_ub_17  -4.2296072507595178e-02
    x_20_8    onehot_20_26  1
    x_20_8    stock_lb_228  8
    x_20_8    stock_ub_229  8
    x_20_8    parent_nonstrict_scope_230  1.7999999999999995e-02
    x_20_8    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_16  1
    w_20_8    product_ub_17  1
    w_20_8    normalized_mass_20_27  1
    w_20_8    normalized_ratio_20_28  -1.3333333333333333e+00
    w_20_8    full_original_Gini_288  -1.2357142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_9    product_lb_18  -0.0248557478916751
    x_20_9    product_ub_19  -4.2296072507595178e-02
    x_20_9    onehot_20_26  1
    x_20_9    stock_lb_228  9
    x_20_9    stock_ub_229  9
    x_20_9    parent_nonstrict_scope_230  0.027
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_18  1
    w_20_9    product_ub_19  1
    w_20_9    normalized_mass_20_27  1
    w_20_9    normalized_ratio_20_28  -1.5
    w_20_9    full_original_Gini_288  -1.6857142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       0.00899999999999999
    x_20_10   product_lb_20  -0.0248557478916751
    x_20_10   product_ub_21  -4.2296072507595178e-02
    x_20_10   onehot_20_26  1
    x_20_10   stock_lb_228  10
    x_20_10   stock_ub_229  10
    x_20_10   parent_nonstrict_scope_230  3.5999999999999990e-02
    x_20_10   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_20  1
    w_20_10   product_ub_21  1
    w_20_10   normalized_mass_20_27  1
    w_20_10   normalized_ratio_20_28  -1.6666666666666665e+00
    w_20_10   full_original_Gini_288  -2.1357142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       0.018
    x_20_11   product_lb_22  -0.0248557478916751
    x_20_11   product_ub_23  -4.2296072507595178e-02
    x_20_11   onehot_20_26  1
    x_20_11   stock_lb_228  11
    x_20_11   stock_ub_229  11
    x_20_11   parent_nonstrict_scope_230  0.045
    x_20_11   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_22  1
    w_20_11   product_ub_23  1
    w_20_11   normalized_mass_20_27  1
    w_20_11   normalized_ratio_20_28  -1.8333333333333333e+00
    w_20_11   full_original_Gini_288  -2.5857142857142847e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_12   OBJ       0.027
    x_20_12   product_lb_24  -0.0248557478916751
    x_20_12   product_ub_25  -4.2296072507595178e-02
    x_20_12   onehot_20_26  1
    x_20_12   stock_lb_228  12
    x_20_12   stock_ub_229  12
    x_20_12   parent_nonstrict_scope_230  0.054
    x_20_12   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_24  1
    w_20_12   product_ub_25  1
    w_20_12   normalized_mass_20_27  1
    w_20_12   normalized_ratio_20_28  -2
    w_20_12   full_original_Gini_288  -3.0357142857142861e+01
    rho_20    normalized_ratio_20_28  1
    rho_20    block_pair_pos_237  -1
    rho_20    block_pair_neg_238  1
    rho_20    block_pair_pos_239  -1
    rho_20    block_pair_neg_240  1
    rho_20    block_pair_pos_241  -1
    rho_20    block_pair_neg_242  1
    rho_20    block_pair_pos_243  -1
    rho_20    block_pair_neg_244  1
    rho_20    block_pair_pos_245  -1
    rho_20    block_pair_neg_246  1
    rho_20    block_pair_pos_247  -1
    rho_20    block_pair_neg_248  1
    rho_20    block_pair_pos_249  -1
    rho_20    block_pair_neg_250  1
    rho_20    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       0.048
    x_21_0    product_lb_29  -0.0248557478916751
    x_21_0    product_ub_30  -4.2296072507595178e-02
    x_21_0    onehot_21_61  1
    x_21_0    parent_nonstrict_scope_230  0.096
    x_21_0    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_29  1
    w_21_0    product_ub_30  1
    w_21_0    normalized_mass_21_62  1
    w_21_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       3.6000000000000004e-02
    x_21_1    product_lb_31  -0.0248557478916751
    x_21_1    product_ub_32  -4.2296072507595178e-02
    x_21_1    onehot_21_61  1
    x_21_1    stock_lb_228  1
    x_21_1    stock_ub_229  1
    x_21_1    parent_nonstrict_scope_230  0.084
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_31  1
    w_21_1    product_ub_32  1
    w_21_1    normalized_mass_21_62  1
    w_21_1    normalized_ratio_21_63  -0.125
    w_21_1    full_original_Gini_288  -2.0517857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       2.4000000000000007e-02
    x_21_2    product_lb_33  -0.0248557478916751
    x_21_2    product_ub_34  -4.2296072507595178e-02
    x_21_2    onehot_21_61  1
    x_21_2    stock_lb_228  2
    x_21_2    stock_ub_229  2
    x_21_2    parent_nonstrict_scope_230  7.2000000000000008e-02
    x_21_2    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_33  1
    w_21_2    product_ub_34  1
    w_21_2    normalized_mass_21_62  1
    w_21_2    normalized_ratio_21_63  -0.25
    w_21_2    full_original_Gini_288  -1.7392857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       1.1999999999999997e-02
    x_21_3    product_lb_35  -0.0248557478916751
    x_21_3    product_ub_36  -4.2296072507595178e-02
    x_21_3    onehot_21_61  1
    x_21_3    stock_lb_228  3
    x_21_3    stock_ub_229  3
    x_21_3    parent_nonstrict_scope_230  0.06
    x_21_3    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_35  1
    w_21_3    product_ub_36  1
    w_21_3    normalized_mass_21_62  1
    w_21_3    normalized_ratio_21_63  -0.375
    w_21_3    full_original_Gini_288  -1.4267857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_4    product_lb_37  -0.0248557478916751
    x_21_4    product_ub_38  -4.2296072507595178e-02
    x_21_4    onehot_21_61  1
    x_21_4    stock_lb_228  4
    x_21_4    stock_ub_229  4
    x_21_4    parent_nonstrict_scope_230  0.048
    x_21_4    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_37  1
    w_21_4    product_ub_38  1
    w_21_4    normalized_mass_21_62  1
    w_21_4    normalized_ratio_21_63  -0.5
    w_21_4    full_original_Gini_288  -1.1542857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       -1.1999999999999997e-02
    x_21_5    product_lb_39  -0.0248557478916751
    x_21_5    product_ub_40  -4.2296072507595178e-02
    x_21_5    onehot_21_61  1
    x_21_5    stock_lb_228  5
    x_21_5    stock_ub_229  5
    x_21_5    parent_nonstrict_scope_230  3.6000000000000004e-02
    x_21_5    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_39  1
    w_21_5    product_ub_40  1
    w_21_5    normalized_mass_21_62  1
    w_21_5    normalized_ratio_21_63  -0.625
    w_21_5    full_original_Gini_288  -8.9178571428571427e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       -0.024
    x_21_6    product_lb_41  -0.0248557478916751
    x_21_6    product_ub_42  -4.2296072507595178e-02
    x_21_6    onehot_21_61  1
    x_21_6    stock_lb_228  6
    x_21_6    stock_ub_229  6
    x_21_6    parent_nonstrict_scope_230  0.024
    x_21_6    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_41  1
    w_21_6    product_ub_42  1
    w_21_6    normalized_mass_21_62  1
    w_21_6    normalized_ratio_21_63  -0.75
    w_21_6    full_original_Gini_288  -6.4357142857142859e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_7    OBJ       -3.6000000000000004e-02
    x_21_7    product_lb_43  -0.0248557478916751
    x_21_7    product_ub_44  -4.2296072507595178e-02
    x_21_7    onehot_21_61  1
    x_21_7    stock_lb_228  7
    x_21_7    stock_ub_229  7
    x_21_7    parent_nonstrict_scope_230  0.012
    x_21_7    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_7    product_lb_43  1
    w_21_7    product_ub_44  1
    w_21_7    normalized_mass_21_62  1
    w_21_7    normalized_ratio_21_63  -0.875
    w_21_7    full_original_Gini_288  -4.3821428571428571e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_8    OBJ       -0.048
    x_21_8    product_lb_45  -0.0248557478916751
    x_21_8    product_ub_46  -4.2296072507595178e-02
    x_21_8    onehot_21_61  1
    x_21_8    stock_lb_228  8
    x_21_8    stock_ub_229  8
    x_21_8    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_8    product_lb_45  1
    w_21_8    product_ub_46  1
    w_21_8    normalized_mass_21_62  1
    w_21_8    normalized_ratio_21_63  -1
    w_21_8    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_9    OBJ       -3.6000000000000004e-02
    x_21_9    product_lb_47  -0.0248557478916751
    x_21_9    product_ub_48  -4.2296072507595178e-02
    x_21_9    onehot_21_61  1
    x_21_9    stock_lb_228  9
    x_21_9    stock_ub_229  9
    x_21_9    parent_nonstrict_scope_230  0.012
    x_21_9    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_9    product_lb_47  1
    w_21_9    product_ub_48  1
    w_21_9    normalized_mass_21_62  1
    w_21_9    normalized_ratio_21_63  -1.125
    w_21_9    full_original_Gini_288  -6.8821428571428580e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_10   OBJ       -0.024
    x_21_10   product_lb_49  -0.0248557478916751
    x_21_10   product_ub_50  -4.2296072507595178e-02
    x_21_10   onehot_21_61  1
    x_21_10   stock_lb_228  10
    x_21_10   stock_ub_229  10
    x_21_10   parent_nonstrict_scope_230  0.024
    x_21_10   unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_10   product_lb_49  1
    w_21_10   product_ub_50  1
    w_21_10   normalized_mass_21_62  1
    w_21_10   normalized_ratio_21_63  -1.25
    w_21_10   full_original_Gini_288  -1.0107142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_11   OBJ       -1.1999999999999997e-02
    x_21_11   product_lb_51  -0.0248557478916751
    x_21_11   product_ub_52  -4.2296072507595178e-02
    x_21_11   onehot_21_61  1
    x_21_11   stock_lb_228  11
    x_21_11   stock_ub_229  11
    x_21_11   parent_nonstrict_scope_230  3.6000000000000004e-02
    x_21_11   unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_11   product_lb_51  1
    w_21_11   product_ub_52  1
    w_21_11   normalized_mass_21_62  1
    w_21_11   normalized_ratio_21_63  -1.375
    w_21_11   full_original_Gini_288  -1.3482142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_12   product_lb_53  -0.0248557478916751
    x_21_12   product_ub_54  -4.2296072507595178e-02
    x_21_12   onehot_21_61  1
    x_21_12   stock_lb_228  12
    x_21_12   stock_ub_229  12
    x_21_12   parent_nonstrict_scope_230  0.048
    x_21_12   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_12   product_lb_53  1
    w_21_12   product_ub_54  1
    w_21_12   normalized_mass_21_62  1
    w_21_12   normalized_ratio_21_63  -1.5
    w_21_12   full_original_Gini_288  -1.6857142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_13   OBJ       1.1999999999999997e-02
    x_21_13   product_lb_55  -0.0248557478916751
    x_21_13   product_ub_56  -4.2296072507595178e-02
    x_21_13   onehot_21_61  1
    x_21_13   stock_lb_228  13
    x_21_13   stock_ub_229  13
    x_21_13   parent_nonstrict_scope_230  0.06
    x_21_13   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_13   product_lb_55  1
    w_21_13   product_ub_56  1
    w_21_13   normalized_mass_21_62  1
    w_21_13   normalized_ratio_21_63  -1.625
    w_21_13   full_original_Gini_288  -2.0232142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_14   OBJ       2.4000000000000007e-02
    x_21_14   product_lb_57  -0.0248557478916751
    x_21_14   product_ub_58  -4.2296072507595178e-02
    x_21_14   onehot_21_61  1
    x_21_14   stock_lb_228  14
    x_21_14   stock_ub_229  14
    x_21_14   parent_nonstrict_scope_230  7.2000000000000008e-02
    x_21_14   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_14   product_lb_57  1
    w_21_14   product_ub_58  1
    w_21_14   normalized_mass_21_62  1
    w_21_14   normalized_ratio_21_63  -1.75
    w_21_14   full_original_Gini_288  -2.3607142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_15   OBJ       3.6000000000000004e-02
    x_21_15   product_lb_59  -0.0248557478916751
    x_21_15   product_ub_60  -4.2296072507595178e-02
    x_21_15   onehot_21_61  1
    x_21_15   stock_lb_228  15
    x_21_15   stock_ub_229  15
    x_21_15   parent_nonstrict_scope_230  0.084
    x_21_15   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_15   product_lb_59  1
    w_21_15   product_ub_60  1
    w_21_15   normalized_mass_21_62  1
    w_21_15   normalized_ratio_21_63  -1.875
    w_21_15   full_original_Gini_288  -2.6982142857142861e+01
    rho_21    normalized_ratio_21_63  1
    rho_21    block_pair_pos_243  1
    rho_21    block_pair_neg_244  -1
    rho_21    block_pair_pos_251  -1
    rho_21    block_pair_neg_252  1
    rho_21    block_pair_pos_253  -1
    rho_21    block_pair_neg_254  1
    rho_21    block_pair_pos_255  -1
    rho_21    block_pair_neg_256  1
    rho_21    block_pair_pos_257  -1
    rho_21    block_pair_neg_258  1
    rho_21    block_pair_pos_259  -1
    rho_21    block_pair_neg_260  1
    rho_21    block_pair_pos_261  -1
    rho_21    block_pair_neg_262  1
    rho_21    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_64  -0.0248557478916751
    x_31_0    product_ub_65  -4.2296072507595178e-02
    x_31_0    onehot_31_90  1
    x_31_0    parent_nonstrict_scope_230  0.0735
    x_31_0    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_64  1
    w_31_0    product_ub_65  1
    w_31_0    normalized_mass_31_91  1
    w_31_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_66  -0.0248557478916751
    x_31_1    product_ub_67  -4.2296072507595178e-02
    x_31_1    onehot_31_90  1
    x_31_1    stock_lb_228  1
    x_31_1    stock_ub_229  1
    x_31_1    parent_nonstrict_scope_230  0.063
    x_31_1    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_66  1
    w_31_1    product_ub_67  1
    w_31_1    normalized_mass_31_91  1
    w_31_1    normalized_ratio_31_92  -1.4285714285714285e-01
    w_31_1    full_original_Gini_288  -2.0071428571428577e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_68  -0.0248557478916751
    x_31_2    product_ub_69  -4.2296072507595178e-02
    x_31_2    onehot_31_90  1
    x_31_2    stock_lb_228  2
    x_31_2    stock_ub_229  2
    x_31_2    parent_nonstrict_scope_230  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_68  1
    w_31_2    product_ub_69  1
    w_31_2    normalized_mass_31_91  1
    w_31_2    normalized_ratio_31_92  -2.8571428571428570e-01
    w_31_2    full_original_Gini_288  -1.6499999999999996e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_70  -0.0248557478916751
    x_31_3    product_ub_71  -4.2296072507595178e-02
    x_31_3    onehot_31_90  1
    x_31_3    stock_lb_228  3
    x_31_3    stock_ub_229  3
    x_31_3    parent_nonstrict_scope_230  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_70  1
    w_31_3    product_ub_71  1
    w_31_3    normalized_mass_31_91  1
    w_31_3    normalized_ratio_31_92  -4.2857142857142855e-01
    w_31_3    full_original_Gini_288  -1.3042857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_72  -0.0248557478916751
    x_31_4    product_ub_73  -4.2296072507595178e-02
    x_31_4    onehot_31_90  1
    x_31_4    stock_lb_228  4
    x_31_4    stock_ub_229  4
    x_31_4    parent_nonstrict_scope_230  0.0315
    x_31_4    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_72  1
    w_31_4    product_ub_73  1
    w_31_4    normalized_mass_31_91  1
    w_31_4    normalized_ratio_31_92  -5.7142857142857140e-01
    w_31_4    full_original_Gini_288  -1.0042857142857146e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_74  -0.0248557478916751
    x_31_5    product_ub_75  -4.2296072507595178e-02
    x_31_5    onehot_31_90  1
    x_31_5    stock_lb_228  5
    x_31_5    stock_ub_229  5
    x_31_5    parent_nonstrict_scope_230  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_74  1
    w_31_5    product_ub_75  1
    w_31_5    normalized_mass_31_91  1
    w_31_5    normalized_ratio_31_92  -7.1428571428571419e-01
    w_31_5    full_original_Gini_288  -7.0428571428571427e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_76  -0.0248557478916751
    x_31_6    product_ub_77  -4.2296072507595178e-02
    x_31_6    onehot_31_90  1
    x_31_6    stock_lb_228  6
    x_31_6    stock_ub_229  6
    x_31_6    parent_nonstrict_scope_230  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_76  1
    w_31_6    product_ub_77  1
    w_31_6    normalized_mass_31_91  1
    w_31_6    normalized_ratio_31_92  -8.5714285714285710e-01
    w_31_6    full_original_Gini_288  -4.6142857142857148e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_78  -0.0248557478916751
    x_31_7    product_ub_79  -4.2296072507595178e-02
    x_31_7    onehot_31_90  1
    x_31_7    stock_lb_228  7
    x_31_7    stock_ub_229  7
    x_31_7    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_78  1
    w_31_7    product_ub_79  1
    w_31_7    normalized_mass_31_91  1
    w_31_7    normalized_ratio_31_92  -1
    w_31_7    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_80  -0.0248557478916751
    x_31_8    product_ub_81  -4.2296072507595178e-02
    x_31_8    onehot_31_90  1
    x_31_8    stock_lb_228  8
    x_31_8    stock_ub_229  8
    x_31_8    parent_nonstrict_scope_230  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_80  1
    w_31_8    product_ub_81  1
    w_31_8    normalized_mass_31_91  1
    w_31_8    normalized_ratio_31_92  -1.1428571428571428e+00
    w_31_8    full_original_Gini_288  -7.3285714285714256e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_82  -0.0248557478916751
    x_31_9    product_ub_83  -4.2296072507595178e-02
    x_31_9    onehot_31_90  1
    x_31_9    stock_lb_228  9
    x_31_9    stock_ub_229  9
    x_31_9    parent_nonstrict_scope_230  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_82  1
    w_31_9    product_ub_83  1
    w_31_9    normalized_mass_31_91  1
    w_31_9    normalized_ratio_31_92  -1.2857142857142856e+00
    w_31_9    full_original_Gini_288  -1.1071428571428566e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_84  -0.0248557478916751
    x_31_10   product_ub_85  -4.2296072507595178e-02
    x_31_10   onehot_31_90  1
    x_31_10   stock_lb_228  10
    x_31_10   stock_ub_229  10
    x_31_10   parent_nonstrict_scope_230  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_84  1
    w_31_10   product_ub_85  1
    w_31_10   normalized_mass_31_91  1
    w_31_10   normalized_ratio_31_92  -1.4285714285714284e+00
    w_31_10   full_original_Gini_288  -1.4928571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_86  -0.0248557478916751
    x_31_11   product_ub_87  -4.2296072507595178e-02
    x_31_11   onehot_31_90  1
    x_31_11   stock_lb_228  11
    x_31_11   stock_ub_229  11
    x_31_11   parent_nonstrict_scope_230  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_86  1
    w_31_11   product_ub_87  1
    w_31_11   normalized_mass_31_91  1
    w_31_11   normalized_ratio_31_92  -1.5714285714285714e+00
    w_31_11   full_original_Gini_288  -1.8785714285714281e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_88  -0.0248557478916751
    x_31_12   product_ub_89  -4.2296072507595178e-02
    x_31_12   onehot_31_90  1
    x_31_12   stock_lb_228  12
    x_31_12   stock_ub_229  12
    x_31_12   parent_nonstrict_scope_230  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_88  1
    w_31_12   product_ub_89  1
    w_31_12   normalized_mass_31_91  1
    w_31_12   normalized_ratio_31_92  -1.7142857142857142e+00
    w_31_12   full_original_Gini_288  -2.2642857142857142e+01
    rho_31    normalized_ratio_31_92  1
    rho_31    block_pair_pos_247  1
    rho_31    block_pair_neg_248  -1
    rho_31    block_pair_pos_259  1
    rho_31    block_pair_neg_260  -1
    rho_31    block_pair_pos_271  -1
    rho_31    block_pair_neg_272  1
    rho_31    block_pair_pos_273  -1
    rho_31    block_pair_neg_274  1
    rho_31    block_pair_pos_275  -1
    rho_31    block_pair_neg_276  1
    rho_31    block_pair_pos_277  -1
    rho_31    block_pair_neg_278  1
    rho_31    block_pair_pos_279  -1
    rho_31    block_pair_neg_280  1
    rho_31    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_23_0    OBJ       1.4999999999999996e-02
    x_23_0    product_lb_93  -0.0248557478916751
    x_23_0    product_ub_94  -4.2296072507595178e-02
    x_23_0    onehot_23_117  1
    x_23_0    parent_nonstrict_scope_230  0.0375
    x_23_0    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_0    product_lb_93  1
    w_23_0    product_ub_94  1
    w_23_0    normalized_mass_23_118  1
    w_23_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_1    OBJ       7.4999999999999963e-03
    x_23_1    product_lb_95  -0.0248557478916751
    x_23_1    product_ub_96  -4.2296072507595178e-02
    x_23_1    onehot_23_117  1
    x_23_1    stock_lb_228  1
    x_23_1    stock_ub_229  1
    x_23_1    parent_nonstrict_scope_230  0.03
    x_23_1    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_1    product_lb_95  1
    w_23_1    product_ub_96  1
    w_23_1    normalized_mass_23_118  1
    w_23_1    normalized_ratio_23_119  -0.2
    w_23_1    full_original_Gini_288  -1.8642857142857149e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_2    OBJ       -3.4694469519536142e-18
    x_23_2    product_lb_97  -0.0248557478916751
    x_23_2    product_ub_98  -4.2296072507595178e-02
    x_23_2    onehot_23_117  1
    x_23_2    stock_lb_228  2
    x_23_2    stock_ub_229  2
    x_23_2    parent_nonstrict_scope_230  0.0225
    x_23_2    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_2    product_lb_97  1
    w_23_2    product_ub_98  1
    w_23_2    normalized_mass_23_118  1
    w_23_2    normalized_ratio_23_119  -0.4
    w_23_2    full_original_Gini_288  -1.3642857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_3    OBJ       -7.5000000000000067e-03
    x_23_3    product_lb_99  -0.0248557478916751
    x_23_3    product_ub_100  -4.2296072507595178e-02
    x_23_3    onehot_23_117  1
    x_23_3    stock_lb_228  3
    x_23_3    stock_ub_229  3
    x_23_3    parent_nonstrict_scope_230  1.4999999999999996e-02
    x_23_3    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_3    product_lb_99  1
    w_23_3    product_ub_100  1
    w_23_3    normalized_mass_23_118  1
    w_23_3    normalized_ratio_23_119  -6.0000000000000009e-01
    w_23_3    full_original_Gini_288  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_4    OBJ       -1.5000000000000005e-02
    x_23_4    product_lb_101  -0.0248557478916751
    x_23_4    product_ub_102  -4.2296072507595178e-02
    x_23_4    onehot_23_117  1
    x_23_4    stock_lb_228  4
    x_23_4    stock_ub_229  4
    x_23_4    parent_nonstrict_scope_230  7.4999999999999980e-03
    x_23_4    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_4    product_lb_101  1
    w_23_4    product_ub_102  1
    w_23_4    normalized_mass_23_118  1
    w_23_4    normalized_ratio_23_119  -0.8
    w_23_4    full_original_Gini_288  -5.5857142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_5    OBJ       -2.2500000000000003e-02
    x_23_5    product_lb_103  -0.0248557478916751
    x_23_5    product_ub_104  -4.2296072507595178e-02
    x_23_5    onehot_23_117  1
    x_23_5    stock_lb_228  5
    x_23_5    stock_ub_229  5
    x_23_5    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_5    product_lb_103  1
    w_23_5    product_ub_104  1
    w_23_5    normalized_mass_23_118  1
    w_23_5    normalized_ratio_23_119  -1
    w_23_5    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_6    OBJ       -1.4999999999999996e-02
    x_23_6    product_lb_105  -0.0248557478916751
    x_23_6    product_ub_106  -4.2296072507595178e-02
    x_23_6    onehot_23_117  1
    x_23_6    stock_lb_228  6
    x_23_6    stock_ub_229  6
    x_23_6    parent_nonstrict_scope_230  7.5000000000000067e-03
    x_23_6    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_6    product_lb_105  1
    w_23_6    product_ub_106  1
    w_23_6    normalized_mass_23_118  1
    w_23_6    normalized_ratio_23_119  -1.2000000000000002e+00
    w_23_6    full_original_Gini_288  -8.7571428571428633e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_7    OBJ       -7.4999999999999980e-03
    x_23_7    product_lb_107  -0.0248557478916751
    x_23_7    product_ub_108  -4.2296072507595178e-02
    x_23_7    onehot_23_117  1
    x_23_7    stock_lb_228  7
    x_23_7    stock_ub_229  7
    x_23_7    parent_nonstrict_scope_230  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_23_7    product_lb_107  1
    w_23_7    product_ub_108  1
    w_23_7    normalized_mass_23_118  1
    w_23_7    normalized_ratio_23_119  -1.4000000000000001e+00
    w_23_7    full_original_Gini_288  -1.4157142857142864e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_8    product_lb_109  -0.0248557478916751
    x_23_8    product_ub_110  -4.2296072507595178e-02
    x_23_8    onehot_23_117  1
    x_23_8    stock_lb_228  8
    x_23_8    stock_ub_229  8
    x_23_8    parent_nonstrict_scope_230  2.2500000000000003e-02
    x_23_8    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_8    product_lb_109  1
    w_23_8    product_ub_110  1
    w_23_8    normalized_mass_23_118  1
    w_23_8    normalized_ratio_23_119  -1.6
    w_23_8    full_original_Gini_288  -1.9557142857142860e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_9    OBJ       7.4999999999999963e-03
    x_23_9    product_lb_111  -0.0248557478916751
    x_23_9    product_ub_112  -4.2296072507595178e-02
    x_23_9    onehot_23_117  1
    x_23_9    stock_lb_228  9
    x_23_9    stock_ub_229  9
    x_23_9    parent_nonstrict_scope_230  0.03
    x_23_9    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_9    product_lb_111  1
    w_23_9    product_ub_112  1
    w_23_9    normalized_mass_23_118  1
    w_23_9    normalized_ratio_23_119  -1.8
    w_23_9    full_original_Gini_288  -2.4957142857142863e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_10   OBJ       1.4999999999999996e-02
    x_23_10   product_lb_113  -0.0248557478916751
    x_23_10   product_ub_114  -4.2296072507595178e-02
    x_23_10   onehot_23_117  1
    x_23_10   stock_lb_228  10
    x_23_10   stock_ub_229  10
    x_23_10   parent_nonstrict_scope_230  0.0375
    x_23_10   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_10   product_lb_113  1
    w_23_10   product_ub_114  1
    w_23_10   normalized_mass_23_118  1
    w_23_10   normalized_ratio_23_119  -2
    w_23_10   full_original_Gini_288  -3.0357142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_11   OBJ       2.2500000000000003e-02
    x_23_11   product_lb_115  -0.0248557478916751
    x_23_11   product_ub_116  -4.2296072507595178e-02
    x_23_11   onehot_23_117  1
    x_23_11   stock_lb_228  11
    x_23_11   stock_ub_229  11
    x_23_11   parent_nonstrict_scope_230  4.5000000000000005e-02
    x_23_11   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_11   product_lb_115  1
    w_23_11   product_ub_116  1
    w_23_11   normalized_mass_23_118  1
    w_23_11   normalized_ratio_23_119  -2.2
    w_23_11   full_original_Gini_288  -3.5757142857142853e+01
    rho_23    normalized_ratio_23_119  1
    rho_23    block_pair_pos_245  1
    rho_23    block_pair_neg_246  -1
    rho_23    block_pair_pos_257  1
    rho_23    block_pair_neg_258  -1
    rho_23    block_pair_pos_263  -1
    rho_23    block_pair_neg_264  1
    rho_23    block_pair_pos_265  -1
    rho_23    block_pair_neg_266  1
    rho_23    block_pair_pos_267  -1
    rho_23    block_pair_neg_268  1
    rho_23    block_pair_pos_269  -1
    rho_23    block_pair_neg_270  1
    rho_23    block_pair_pos_277  1
    rho_23    block_pair_neg_278  -1
    rho_23    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_120  -0.0248557478916751
    x_32_0    product_ub_121  -4.2296072507595178e-02
    x_32_0    onehot_32_146  1
    x_32_0    parent_nonstrict_scope_230  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_120  1
    w_32_0    product_ub_121  1
    w_32_0    normalized_mass_32_147  1
    w_32_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_122  -0.0248557478916751
    x_32_1    product_ub_123  -4.2296072507595178e-02
    x_32_1    onehot_32_146  1
    x_32_1    stock_lb_228  1
    x_32_1    stock_ub_229  1
    x_32_1    parent_nonstrict_scope_230  0.03
    x_32_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_122  1
    w_32_1    product_ub_123  1
    w_32_1    normalized_mass_32_147  1
    w_32_1    normalized_ratio_32_148  -0.2
    w_32_1    full_original_Gini_288  -1.8642857142857149e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_124  -0.0248557478916751
    x_32_2    product_ub_125  -4.2296072507595178e-02
    x_32_2    onehot_32_146  1
    x_32_2    stock_lb_228  2
    x_32_2    stock_ub_229  2
    x_32_2    parent_nonstrict_scope_230  0.0225
    x_32_2    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_124  1
    w_32_2    product_ub_125  1
    w_32_2    normalized_mass_32_147  1
    w_32_2    normalized_ratio_32_148  -0.4
    w_32_2    full_original_Gini_288  -1.3642857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_126  -0.0248557478916751
    x_32_3    product_ub_127  -4.2296072507595178e-02
    x_32_3    onehot_32_146  1
    x_32_3    stock_lb_228  3
    x_32_3    stock_ub_229  3
    x_32_3    parent_nonstrict_scope_230  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_126  1
    w_32_3    product_ub_127  1
    w_32_3    normalized_mass_32_147  1
    w_32_3    normalized_ratio_32_148  -6.0000000000000009e-01
    w_32_3    full_original_Gini_288  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_128  -0.0248557478916751
    x_32_4    product_ub_129  -4.2296072507595178e-02
    x_32_4    onehot_32_146  1
    x_32_4    stock_lb_228  4
    x_32_4    stock_ub_229  4
    x_32_4    parent_nonstrict_scope_230  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_128  1
    w_32_4    product_ub_129  1
    w_32_4    normalized_mass_32_147  1
    w_32_4    normalized_ratio_32_148  -0.8
    w_32_4    full_original_Gini_288  -5.5857142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_130  -0.0248557478916751
    x_32_5    product_ub_131  -4.2296072507595178e-02
    x_32_5    onehot_32_146  1
    x_32_5    stock_lb_228  5
    x_32_5    stock_ub_229  5
    x_32_5    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_130  1
    w_32_5    product_ub_131  1
    w_32_5    normalized_mass_32_147  1
    w_32_5    normalized_ratio_32_148  -1
    w_32_5    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_132  -0.0248557478916751
    x_32_6    product_ub_133  -4.2296072507595178e-02
    x_32_6    onehot_32_146  1
    x_32_6    stock_lb_228  6
    x_32_6    stock_ub_229  6
    x_32_6    parent_nonstrict_scope_230  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_132  1
    w_32_6    product_ub_133  1
    w_32_6    normalized_mass_32_147  1
    w_32_6    normalized_ratio_32_148  -1.2000000000000002e+00
    w_32_6    full_original_Gini_288  -8.7571428571428633e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_134  -0.0248557478916751
    x_32_7    product_ub_135  -4.2296072507595178e-02
    x_32_7    onehot_32_146  1
    x_32_7    stock_lb_228  7
    x_32_7    stock_ub_229  7
    x_32_7    parent_nonstrict_scope_230  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_134  1
    w_32_7    product_ub_135  1
    w_32_7    normalized_mass_32_147  1
    w_32_7    normalized_ratio_32_148  -1.4000000000000001e+00
    w_32_7    full_original_Gini_288  -1.4157142857142864e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_136  -0.0248557478916751
    x_32_8    product_ub_137  -4.2296072507595178e-02
    x_32_8    onehot_32_146  1
    x_32_8    stock_lb_228  8
    x_32_8    stock_ub_229  8
    x_32_8    parent_nonstrict_scope_230  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_136  1
    w_32_8    product_ub_137  1
    w_32_8    normalized_mass_32_147  1
    w_32_8    normalized_ratio_32_148  -1.6
    w_32_8    full_original_Gini_288  -1.9557142857142860e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_138  -0.0248557478916751
    x_32_9    product_ub_139  -4.2296072507595178e-02
    x_32_9    onehot_32_146  1
    x_32_9    stock_lb_228  9
    x_32_9    stock_ub_229  9
    x_32_9    parent_nonstrict_scope_230  0.03
    x_32_9    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_138  1
    w_32_9    product_ub_139  1
    w_32_9    normalized_mass_32_147  1
    w_32_9    normalized_ratio_32_148  -1.8
    w_32_9    full_original_Gini_288  -2.4957142857142863e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_140  -0.0248557478916751
    x_32_10   product_ub_141  -4.2296072507595178e-02
    x_32_10   onehot_32_146  1
    x_32_10   stock_lb_228  10
    x_32_10   stock_ub_229  10
    x_32_10   parent_nonstrict_scope_230  0.0375
    x_32_10   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_140  1
    w_32_10   product_ub_141  1
    w_32_10   normalized_mass_32_147  1
    w_32_10   normalized_ratio_32_148  -2
    w_32_10   full_original_Gini_288  -3.0357142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_142  -0.0248557478916751
    x_32_11   product_ub_143  -4.2296072507595178e-02
    x_32_11   onehot_32_146  1
    x_32_11   stock_lb_228  11
    x_32_11   stock_ub_229  11
    x_32_11   parent_nonstrict_scope_230  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_142  1
    w_32_11   product_ub_143  1
    w_32_11   normalized_mass_32_147  1
    w_32_11   normalized_ratio_32_148  -2.2
    w_32_11   full_original_Gini_288  -3.5757142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_144  -0.0248557478916751
    x_32_12   product_ub_145  -4.2296072507595178e-02
    x_32_12   onehot_32_146  1
    x_32_12   stock_lb_228  12
    x_32_12   stock_ub_229  12
    x_32_12   parent_nonstrict_scope_230  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_144  1
    w_32_12   product_ub_145  1
    w_32_12   normalized_mass_32_147  1
    w_32_12   normalized_ratio_32_148  -2.4000000000000004e+00
    w_32_12   full_original_Gini_288  -4.1157142857142844e+01
    rho_32    normalized_ratio_32_148  1
    rho_32    block_pair_pos_249  1
    rho_32    block_pair_neg_250  -1
    rho_32    block_pair_pos_261  1
    rho_32    block_pair_neg_262  -1
    rho_32    block_pair_pos_269  1
    rho_32    block_pair_neg_270  -1
    rho_32    block_pair_pos_279  1
    rho_32    block_pair_neg_280  -1
    rho_32    block_pair_pos_281  -1
    rho_32    block_pair_neg_282  1
    rho_32    block_pair_pos_283  -1
    rho_32    block_pair_neg_284  1
    rho_32    block_pair_pos_285  -1
    rho_32    block_pair_neg_286  1
    rho_32    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_149  -0.0248557478916751
    x_16_0    product_ub_150  -4.2296072507595178e-02
    x_16_0    onehot_16_175  1
    x_16_0    parent_nonstrict_scope_230  0.054
    x_16_0    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_149  1
    w_16_0    product_ub_150  1
    w_16_0    normalized_mass_16_176  1
    w_16_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_151  -0.0248557478916751
    x_16_1    product_ub_152  -4.2296072507595178e-02
    x_16_1    onehot_16_175  1
    x_16_1    stock_lb_228  1
    x_16_1    stock_ub_229  1
    x_16_1    parent_nonstrict_scope_230  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_151  1
    w_16_1    product_ub_152  1
    w_16_1    normalized_mass_16_176  1
    w_16_1    normalized_ratio_16_177  -1.6666666666666666e-01
    w_16_1    full_original_Gini_288  -1.9476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_153  -0.0248557478916751
    x_16_2    product_ub_154  -4.2296072507595178e-02
    x_16_2    onehot_16_175  1
    x_16_2    stock_lb_228  2
    x_16_2    stock_ub_229  2
    x_16_2    parent_nonstrict_scope_230  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_153  1
    w_16_2    product_ub_154  1
    w_16_2    normalized_mass_16_176  1
    w_16_2    normalized_ratio_16_177  -3.3333333333333331e-01
    w_16_2    full_original_Gini_288  -1.5309523809523807e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_155  -0.0248557478916751
    x_16_3    product_ub_156  -4.2296072507595178e-02
    x_16_3    onehot_16_175  1
    x_16_3    stock_lb_228  3
    x_16_3    stock_ub_229  3
    x_16_3    parent_nonstrict_scope_230  0.027
    x_16_3    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_155  1
    w_16_3    product_ub_156  1
    w_16_3    normalized_mass_16_176  1
    w_16_3    normalized_ratio_16_177  -0.5
    w_16_3    full_original_Gini_288  -1.1542857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_157  -0.0248557478916751
    x_16_4    product_ub_158  -4.2296072507595178e-02
    x_16_4    onehot_16_175  1
    x_16_4    stock_lb_228  4
    x_16_4    stock_ub_229  4
    x_16_4    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_157  1
    w_16_4    product_ub_158  1
    w_16_4    normalized_mass_16_176  1
    w_16_4    normalized_ratio_16_177  -6.6666666666666663e-01
    w_16_4    full_original_Gini_288  -8.0428571428571427e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_159  -0.0248557478916751
    x_16_5    product_ub_160  -4.2296072507595178e-02
    x_16_5    onehot_16_175  1
    x_16_5    stock_lb_228  5
    x_16_5    stock_ub_229  5
    x_16_5    parent_nonstrict_scope_230  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_159  1
    w_16_5    product_ub_160  1
    w_16_5    normalized_mass_16_176  1
    w_16_5    normalized_ratio_16_177  -8.3333333333333326e-01
    w_16_5    full_original_Gini_288  -5.0190476190476225e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_161  -0.0248557478916751
    x_16_6    product_ub_162  -4.2296072507595178e-02
    x_16_6    onehot_16_175  1
    x_16_6    stock_lb_228  6
    x_16_6    stock_ub_229  6
    x_16_6    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_161  1
    w_16_6    product_ub_162  1
    w_16_6    normalized_mass_16_176  1
    w_16_6    normalized_ratio_16_177  -1
    w_16_6    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_163  -0.0248557478916751
    x_16_7    product_ub_164  -4.2296072507595178e-02
    x_16_7    onehot_16_175  1
    x_16_7    stock_lb_228  7
    x_16_7    stock_ub_229  7
    x_16_7    parent_nonstrict_scope_230  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_163  1
    w_16_7    product_ub_164  1
    w_16_7    normalized_mass_16_176  1
    w_16_7    normalized_ratio_16_177  -1.1666666666666665e+00
    w_16_7    full_original_Gini_288  -7.9238095238095170e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_165  -0.0248557478916751
    x_16_8    product_ub_166  -4.2296072507595178e-02
    x_16_8    onehot_16_175  1
    x_16_8    stock_lb_228  8
    x_16_8    stock_ub_229  8
    x_16_8    parent_nonstrict_scope_230  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_165  1
    w_16_8    product_ub_166  1
    w_16_8    normalized_mass_16_176  1
    w_16_8    normalized_ratio_16_177  -1.3333333333333333e+00
    w_16_8    full_original_Gini_288  -1.2357142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_167  -0.0248557478916751
    x_16_9    product_ub_168  -4.2296072507595178e-02
    x_16_9    onehot_16_175  1
    x_16_9    stock_lb_228  9
    x_16_9    stock_ub_229  9
    x_16_9    parent_nonstrict_scope_230  0.027
    x_16_9    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_167  1
    w_16_9    product_ub_168  1
    w_16_9    normalized_mass_16_176  1
    w_16_9    normalized_ratio_16_177  -1.5
    w_16_9    full_original_Gini_288  -1.6857142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_169  -0.0248557478916751
    x_16_10   product_ub_170  -4.2296072507595178e-02
    x_16_10   onehot_16_175  1
    x_16_10   stock_lb_228  10
    x_16_10   stock_ub_229  10
    x_16_10   parent_nonstrict_scope_230  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_169  1
    w_16_10   product_ub_170  1
    w_16_10   normalized_mass_16_176  1
    w_16_10   normalized_ratio_16_177  -1.6666666666666665e+00
    w_16_10   full_original_Gini_288  -2.1357142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_171  -0.0248557478916751
    x_16_11   product_ub_172  -4.2296072507595178e-02
    x_16_11   onehot_16_175  1
    x_16_11   stock_lb_228  11
    x_16_11   stock_ub_229  11
    x_16_11   parent_nonstrict_scope_230  0.045
    x_16_11   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_171  1
    w_16_11   product_ub_172  1
    w_16_11   normalized_mass_16_176  1
    w_16_11   normalized_ratio_16_177  -1.8333333333333333e+00
    w_16_11   full_original_Gini_288  -2.5857142857142847e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_173  -0.0248557478916751
    x_16_12   product_ub_174  -4.2296072507595178e-02
    x_16_12   onehot_16_175  1
    x_16_12   stock_lb_228  12
    x_16_12   stock_ub_229  12
    x_16_12   parent_nonstrict_scope_230  0.054
    x_16_12   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_173  1
    w_16_12   product_ub_174  1
    w_16_12   normalized_mass_16_176  1
    w_16_12   normalized_ratio_16_177  -2
    w_16_12   full_original_Gini_288  -3.0357142857142861e+01
    rho_16    normalized_ratio_16_177  1
    rho_16    block_pair_pos_231  -1
    rho_16    block_pair_neg_232  1
    rho_16    block_pair_pos_233  -1
    rho_16    block_pair_neg_234  1
    rho_16    block_pair_pos_239  1
    rho_16    block_pair_neg_240  -1
    rho_16    block_pair_pos_253  1
    rho_16    block_pair_neg_254  -1
    rho_16    block_pair_pos_265  1
    rho_16    block_pair_neg_266  -1
    rho_16    block_pair_pos_273  1
    rho_16    block_pair_neg_274  -1
    rho_16    block_pair_pos_283  1
    rho_16    block_pair_neg_284  -1
    rho_16    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_178  -0.0248557478916751
    x_19_0    product_ub_179  -4.2296072507595178e-02
    x_19_0    onehot_19_196  1
    x_19_0    parent_nonstrict_scope_230  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_178  1
    w_19_0    product_ub_179  1
    w_19_0    normalized_mass_19_197  1
    w_19_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_180  -0.0248557478916751
    x_19_1    product_ub_181  -4.2296072507595178e-02
    x_19_1    onehot_19_196  1
    x_19_1    stock_lb_228  1
    x_19_1    stock_ub_229  1
    x_19_1    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_180  1
    w_19_1    product_ub_181  1
    w_19_1    normalized_mass_19_197  1
    w_19_1    normalized_ratio_19_198  -0.25
    w_19_1    full_original_Gini_288  -1.7392857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_182  -0.0248557478916751
    x_19_2    product_ub_183  -4.2296072507595178e-02
    x_19_2    onehot_19_196  1
    x_19_2    stock_lb_228  2
    x_19_2    stock_ub_229  2
    x_19_2    parent_nonstrict_scope_230  0.012
    x_19_2    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_182  1
    w_19_2    product_ub_183  1
    w_19_2    normalized_mass_19_197  1
    w_19_2    normalized_ratio_19_198  -0.5
    w_19_2    full_original_Gini_288  -1.1542857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_184  -0.0248557478916751
    x_19_3    product_ub_185  -4.2296072507595178e-02
    x_19_3    onehot_19_196  1
    x_19_3    stock_lb_228  3
    x_19_3    stock_ub_229  3
    x_19_3    parent_nonstrict_scope_230  0.006
    x_19_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_184  1
    w_19_3    product_ub_185  1
    w_19_3    normalized_mass_19_197  1
    w_19_3    normalized_ratio_19_198  -0.75
    w_19_3    full_original_Gini_288  -6.4357142857142859e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_186  -0.0248557478916751
    x_19_4    product_ub_187  -4.2296072507595178e-02
    x_19_4    onehot_19_196  1
    x_19_4    stock_lb_228  4
    x_19_4    stock_ub_229  4
    x_19_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_186  1
    w_19_4    product_ub_187  1
    w_19_4    normalized_mass_19_197  1
    w_19_4    normalized_ratio_19_198  -1
    w_19_4    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_188  -0.0248557478916751
    x_19_5    product_ub_189  -4.2296072507595178e-02
    x_19_5    onehot_19_196  1
    x_19_5    stock_lb_228  5
    x_19_5    stock_ub_229  5
    x_19_5    parent_nonstrict_scope_230  0.006
    x_19_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_188  1
    w_19_5    product_ub_189  1
    w_19_5    normalized_mass_19_197  1
    w_19_5    normalized_ratio_19_198  -1.25
    w_19_5    full_original_Gini_288  -1.0107142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_190  -0.0248557478916751
    x_19_6    product_ub_191  -4.2296072507595178e-02
    x_19_6    onehot_19_196  1
    x_19_6    stock_lb_228  6
    x_19_6    stock_ub_229  6
    x_19_6    parent_nonstrict_scope_230  0.012
    x_19_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_190  1
    w_19_6    product_ub_191  1
    w_19_6    normalized_mass_19_197  1
    w_19_6    normalized_ratio_19_198  -1.5
    w_19_6    full_original_Gini_288  -1.6857142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_192  -0.0248557478916751
    x_19_7    product_ub_193  -4.2296072507595178e-02
    x_19_7    onehot_19_196  1
    x_19_7    stock_lb_228  7
    x_19_7    stock_ub_229  7
    x_19_7    parent_nonstrict_scope_230  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_192  1
    w_19_7    product_ub_193  1
    w_19_7    normalized_mass_19_197  1
    w_19_7    normalized_ratio_19_198  -1.75
    w_19_7    full_original_Gini_288  -2.3607142857142858e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_194  -0.0248557478916751
    x_19_8    product_ub_195  -4.2296072507595178e-02
    x_19_8    onehot_19_196  1
    x_19_8    stock_lb_228  8
    x_19_8    stock_ub_229  8
    x_19_8    parent_nonstrict_scope_230  0.024
    x_19_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_194  1
    w_19_8    product_ub_195  1
    w_19_8    normalized_mass_19_197  1
    w_19_8    normalized_ratio_19_198  -2
    w_19_8    full_original_Gini_288  -3.0357142857142861e+01
    rho_19    normalized_ratio_19_198  1
    rho_19    block_pair_pos_233  1
    rho_19    block_pair_neg_234  -1
    rho_19    block_pair_pos_235  -1
    rho_19    block_pair_neg_236  1
    rho_19    block_pair_pos_241  1
    rho_19    block_pair_neg_242  -1
    rho_19    block_pair_pos_255  1
    rho_19    block_pair_neg_256  -1
    rho_19    block_pair_pos_267  1
    rho_19    block_pair_neg_268  -1
    rho_19    block_pair_pos_275  1
    rho_19    block_pair_neg_276  -1
    rho_19    block_pair_pos_285  1
    rho_19    block_pair_neg_286  -1
    rho_19    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1249999999999993e-02
    x_11_0    product_lb_199  -0.0248557478916751
    x_11_0    product_ub_200  -4.2296072507595178e-02
    x_11_0    onehot_11_225  1
    x_11_0    parent_nonstrict_scope_230  0.0375
    x_11_0    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_199  1
    w_11_0    product_ub_200  1
    w_11_0    normalized_mass_11_226  1
    w_11_0    full_original_Gini_288  -2.3642857142857142e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7499999999999929e-03
    x_11_1    product_lb_201  -0.0248557478916751
    x_11_1    product_ub_202  -4.2296072507595178e-02
    x_11_1    onehot_11_225  1
    x_11_1    stock_lb_228  1
    x_11_1    stock_ub_229  1
    x_11_1    parent_nonstrict_scope_230  0.03
    x_11_1    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_201  1
    w_11_1    product_ub_202  1
    w_11_1    normalized_mass_11_226  1
    w_11_1    normalized_ratio_11_227  -0.2
    w_11_1    full_original_Gini_288  -1.8642857142857149e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       -3.7500000000000068e-03
    x_11_2    product_lb_203  -0.0248557478916751
    x_11_2    product_ub_204  -4.2296072507595178e-02
    x_11_2    onehot_11_225  1
    x_11_2    stock_lb_228  2
    x_11_2    stock_ub_229  2
    x_11_2    parent_nonstrict_scope_230  0.0225
    x_11_2    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_203  1
    w_11_2    product_ub_204  1
    w_11_2    normalized_mass_11_226  1
    w_11_2    normalized_ratio_11_227  -0.4
    w_11_2    full_original_Gini_288  -1.3642857142857139e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -1.1250000000000010e-02
    x_11_3    product_lb_205  -0.0248557478916751
    x_11_3    product_ub_206  -4.2296072507595178e-02
    x_11_3    onehot_11_225  1
    x_11_3    stock_lb_228  3
    x_11_3    stock_ub_229  3
    x_11_3    parent_nonstrict_scope_230  1.4999999999999996e-02
    x_11_3    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_205  1
    w_11_3    product_ub_206  1
    w_11_3    normalized_mass_11_226  1
    w_11_3    normalized_ratio_11_227  -6.0000000000000009e-01
    w_11_3    full_original_Gini_288  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -1.8750000000000010e-02
    x_11_4    product_lb_207  -0.0248557478916751
    x_11_4    product_ub_208  -4.2296072507595178e-02
    x_11_4    onehot_11_225  1
    x_11_4    stock_lb_228  4
    x_11_4    stock_ub_229  4
    x_11_4    parent_nonstrict_scope_230  7.4999999999999980e-03
    x_11_4    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_207  1
    w_11_4    product_ub_208  1
    w_11_4    normalized_mass_11_226  1
    w_11_4    normalized_ratio_11_227  -0.8
    w_11_4    full_original_Gini_288  -5.5857142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -2.6250000000000006e-02
    x_11_5    product_lb_209  -0.0248557478916751
    x_11_5    product_ub_210  -4.2296072507595178e-02
    x_11_5    onehot_11_225  1
    x_11_5    stock_lb_228  5
    x_11_5    stock_ub_229  5
    x_11_5    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_209  1
    w_11_5    product_ub_210  1
    w_11_5    normalized_mass_11_226  1
    w_11_5    normalized_ratio_11_227  -1
    w_11_5    full_original_Gini_288  -3.7571428571428576e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -0.01875
    x_11_6    product_lb_211  -0.0248557478916751
    x_11_6    product_ub_212  -4.2296072507595178e-02
    x_11_6    onehot_11_225  1
    x_11_6    stock_lb_228  6
    x_11_6    stock_ub_229  6
    x_11_6    parent_nonstrict_scope_230  7.5000000000000067e-03
    x_11_6    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_211  1
    w_11_6    product_ub_212  1
    w_11_6    normalized_mass_11_226  1
    w_11_6    normalized_ratio_11_227  -1.2000000000000002e+00
    w_11_6    full_original_Gini_288  -8.7571428571428633e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -1.1250000000000001e-02
    x_11_7    product_lb_213  -0.0248557478916751
    x_11_7    product_ub_214  -4.2296072507595178e-02
    x_11_7    onehot_11_225  1
    x_11_7    stock_lb_228  7
    x_11_7    stock_ub_229  7
    x_11_7    parent_nonstrict_scope_230  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_213  1
    w_11_7    product_ub_214  1
    w_11_7    normalized_mass_11_226  1
    w_11_7    normalized_ratio_11_227  -1.4000000000000001e+00
    w_11_7    full_original_Gini_288  -1.4157142857142864e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -3.7500000000000033e-03
    x_11_8    product_lb_215  -0.0248557478916751
    x_11_8    product_ub_216  -4.2296072507595178e-02
    x_11_8    onehot_11_225  1
    x_11_8    stock_lb_228  8
    x_11_8    stock_ub_229  8
    x_11_8    parent_nonstrict_scope_230  2.2500000000000003e-02
    x_11_8    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_215  1
    w_11_8    product_ub_216  1
    w_11_8    normalized_mass_11_226  1
    w_11_8    normalized_ratio_11_227  -1.6
    w_11_8    full_original_Gini_288  -1.9557142857142860e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       3.7499999999999929e-03
    x_11_9    product_lb_217  -0.0248557478916751
    x_11_9    product_ub_218  -4.2296072507595178e-02
    x_11_9    onehot_11_225  1
    x_11_9    stock_lb_228  9
    x_11_9    stock_ub_229  9
    x_11_9    parent_nonstrict_scope_230  0.03
    x_11_9    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_217  1
    w_11_9    product_ub_218  1
    w_11_9    normalized_mass_11_226  1
    w_11_9    normalized_ratio_11_227  -1.8
    w_11_9    full_original_Gini_288  -2.4957142857142863e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1249999999999993e-02
    x_11_10   product_lb_219  -0.0248557478916751
    x_11_10   product_ub_220  -4.2296072507595178e-02
    x_11_10   onehot_11_225  1
    x_11_10   stock_lb_228  10
    x_11_10   stock_ub_229  10
    x_11_10   parent_nonstrict_scope_230  0.0375
    x_11_10   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_219  1
    w_11_10   product_ub_220  1
    w_11_10   normalized_mass_11_226  1
    w_11_10   normalized_ratio_11_227  -2
    w_11_10   full_original_Gini_288  -3.0357142857142861e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       0.01875
    x_11_11   product_lb_221  -0.0248557478916751
    x_11_11   product_ub_222  -4.2296072507595178e-02
    x_11_11   onehot_11_225  1
    x_11_11   stock_lb_228  11
    x_11_11   stock_ub_229  11
    x_11_11   parent_nonstrict_scope_230  4.5000000000000005e-02
    x_11_11   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_221  1
    w_11_11   product_ub_222  1
    w_11_11   normalized_mass_11_226  1
    w_11_11   normalized_ratio_11_227  -2.2
    w_11_11   full_original_Gini_288  -3.5757142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_12   OBJ       2.6250000000000006e-02
    x_11_12   product_lb_223  -0.0248557478916751
    x_11_12   product_ub_224  -4.2296072507595178e-02
    x_11_12   onehot_11_225  1
    x_11_12   stock_lb_228  12
    x_11_12   stock_ub_229  12
    x_11_12   parent_nonstrict_scope_230  5.2500000000000012e-02
    x_11_12   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_223  1
    w_11_12   product_ub_224  1
    w_11_12   normalized_mass_11_226  1
    w_11_12   normalized_ratio_11_227  -2.4000000000000004e+00
    w_11_12   full_original_Gini_288  -4.1157142857142844e+01
    rho_11    normalized_ratio_11_227  1
    rho_11    block_pair_pos_231  1
    rho_11    block_pair_neg_232  -1
    rho_11    block_pair_pos_235  1
    rho_11    block_pair_neg_236  -1
    rho_11    block_pair_pos_237  1
    rho_11    block_pair_neg_238  -1
    rho_11    block_pair_pos_251  1
    rho_11    block_pair_neg_252  -1
    rho_11    block_pair_pos_263  1
    rho_11    block_pair_neg_264  -1
    rho_11    block_pair_pos_271  1
    rho_11    block_pair_neg_272  -1
    rho_11    block_pair_pos_281  1
    rho_11    block_pair_neg_282  -1
    rho_11    normalization_287  1
    a_20_21   block_pair_pos_243  1
    a_20_21   block_pair_neg_244  1
    a_20_21   full_original_Gini_288  -1
    a_20_31   block_pair_pos_247  1
    a_20_31   block_pair_neg_248  1
    a_20_31   full_original_Gini_288  -1
    a_20_23   block_pair_pos_245  1
    a_20_23   block_pair_neg_246  1
    a_20_23   full_original_Gini_288  -1
    a_20_32   block_pair_pos_249  1
    a_20_32   block_pair_neg_250  1
    a_20_32   full_original_Gini_288  -1
    a_20_16   block_pair_pos_239  1
    a_20_16   block_pair_neg_240  1
    a_20_16   full_original_Gini_288  -1
    a_20_19   block_pair_pos_241  1
    a_20_19   block_pair_neg_242  1
    a_20_19   full_original_Gini_288  -1
    a_20_11   block_pair_pos_237  1
    a_20_11   block_pair_neg_238  1
    a_20_11   full_original_Gini_288  -1
    a_21_31   block_pair_pos_259  1
    a_21_31   block_pair_neg_260  1
    a_21_31   full_original_Gini_288  -1
    a_21_23   block_pair_pos_257  1
    a_21_23   block_pair_neg_258  1
    a_21_23   full_original_Gini_288  -1
    a_21_32   block_pair_pos_261  1
    a_21_32   block_pair_neg_262  1
    a_21_32   full_original_Gini_288  -1
    a_21_16   block_pair_pos_253  1
    a_21_16   block_pair_neg_254  1
    a_21_16   full_original_Gini_288  -1
    a_21_19   block_pair_pos_255  1
    a_21_19   block_pair_neg_256  1
    a_21_19   full_original_Gini_288  -1
    a_21_11   block_pair_pos_251  1
    a_21_11   block_pair_neg_252  1
    a_21_11   full_original_Gini_288  -1
    a_31_23   block_pair_pos_277  1
    a_31_23   block_pair_neg_278  1
    a_31_23   full_original_Gini_288  -1
    a_31_32   block_pair_pos_279  1
    a_31_32   block_pair_neg_280  1
    a_31_32   full_original_Gini_288  -1
    a_31_16   block_pair_pos_273  1
    a_31_16   block_pair_neg_274  1
    a_31_16   full_original_Gini_288  -1
    a_31_19   block_pair_pos_275  1
    a_31_19   block_pair_neg_276  1
    a_31_19   full_original_Gini_288  -1
    a_31_11   block_pair_pos_271  1
    a_31_11   block_pair_neg_272  1
    a_31_11   full_original_Gini_288  -1
    a_23_32   block_pair_pos_269  1
    a_23_32   block_pair_neg_270  1
    a_23_32   full_original_Gini_288  -1
    a_23_16   block_pair_pos_265  1
    a_23_16   block_pair_neg_266  1
    a_23_16   full_original_Gini_288  -1
    a_23_19   block_pair_pos_267  1
    a_23_19   block_pair_neg_268  1
    a_23_19   full_original_Gini_288  -1
    a_23_11   block_pair_pos_263  1
    a_23_11   block_pair_neg_264  1
    a_23_11   full_original_Gini_288  -1
    a_32_16   block_pair_pos_283  1
    a_32_16   block_pair_neg_284  1
    a_32_16   full_original_Gini_288  -1
    a_32_19   block_pair_pos_285  1
    a_32_19   block_pair_neg_286  1
    a_32_19   full_original_Gini_288  -1
    a_32_11   block_pair_pos_281  1
    a_32_11   block_pair_neg_282  1
    a_32_11   full_original_Gini_288  -1
    a_16_19   block_pair_pos_233  1
    a_16_19   block_pair_neg_234  1
    a_16_19   full_original_Gini_288  -1
    a_16_11   block_pair_pos_231  1
    a_16_11   block_pair_neg_232  1
    a_16_11   full_original_Gini_288  -1
    a_19_11   block_pair_pos_235  1
    a_19_11   block_pair_neg_236  1
    a_19_11   full_original_Gini_288  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_20_0  unique_nonzero_owner_289  1
    service_0_20_0  service_visit_def_763  1
    service_0_20_0  free_load_conservation_764  -9
    service_0_20_0  original_T_including_depot_unload_811  1080
    service_0_20_1  unique_nonzero_owner_290  1
    service_0_20_1  service_visit_def_763  1
    service_0_20_1  free_load_conservation_764  -8
    service_0_20_1  original_T_including_depot_unload_811  960
    service_0_20_2  unique_nonzero_owner_291  1
    service_0_20_2  service_visit_def_763  1
    service_0_20_2  free_load_conservation_764  -7
    service_0_20_2  original_T_including_depot_unload_811  840
    service_0_20_3  unique_nonzero_owner_292  1
    service_0_20_3  service_visit_def_763  1
    service_0_20_3  free_load_conservation_764  -6
    service_0_20_3  original_T_including_depot_unload_811  720
    service_0_20_4  unique_nonzero_owner_293  1
    service_0_20_4  service_visit_def_763  1
    service_0_20_4  free_load_conservation_764  -5
    service_0_20_4  original_T_including_depot_unload_811  600
    service_0_20_5  unique_nonzero_owner_294  1
    service_0_20_5  service_visit_def_763  1
    service_0_20_5  free_load_conservation_764  -4
    service_0_20_5  original_T_including_depot_unload_811  480
    service_0_20_6  unique_nonzero_owner_295  1
    service_0_20_6  service_visit_def_763  1
    service_0_20_6  free_load_conservation_764  -3
    service_0_20_6  original_T_including_depot_unload_811  360
    service_0_20_7  unique_nonzero_owner_296  1
    service_0_20_7  service_visit_def_763  1
    service_0_20_7  free_load_conservation_764  -2
    service_0_20_7  original_T_including_depot_unload_811  240
    service_0_20_8  unique_nonzero_owner_297  1
    service_0_20_8  service_visit_def_763  1
    service_0_20_8  free_load_conservation_764  -1
    service_0_20_8  original_T_including_depot_unload_811  120
    service_0_20_10  unique_nonzero_owner_298  1
    service_0_20_10  service_visit_def_763  1
    service_0_20_10  free_load_conservation_764  1
    service_0_20_11  unique_nonzero_owner_299  1
    service_0_20_11  service_visit_def_763  1
    service_0_20_11  free_load_conservation_764  2
    service_0_20_12  unique_nonzero_owner_300  1
    service_0_20_12  service_visit_def_763  1
    service_0_20_12  free_load_conservation_764  3
    service_1_20_0  unique_nonzero_owner_289  1
    service_1_20_0  service_visit_def_1135  1
    service_1_20_0  free_load_conservation_1136  -9
    service_1_20_0  original_T_including_depot_unload_1182  1080
    service_1_20_1  unique_nonzero_owner_290  1
    service_1_20_1  service_visit_def_1135  1
    service_1_20_1  free_load_conservation_1136  -8
    service_1_20_1  original_T_including_depot_unload_1182  960
    service_1_20_2  unique_nonzero_owner_291  1
    service_1_20_2  service_visit_def_1135  1
    service_1_20_2  free_load_conservation_1136  -7
    service_1_20_2  original_T_including_depot_unload_1182  840
    service_1_20_3  unique_nonzero_owner_292  1
    service_1_20_3  service_visit_def_1135  1
    service_1_20_3  free_load_conservation_1136  -6
    service_1_20_3  original_T_including_depot_unload_1182  720
    service_1_20_4  unique_nonzero_owner_293  1
    service_1_20_4  service_visit_def_1135  1
    service_1_20_4  free_load_conservation_1136  -5
    service_1_20_4  original_T_including_depot_unload_1182  600
    service_1_20_5  unique_nonzero_owner_294  1
    service_1_20_5  service_visit_def_1135  1
    service_1_20_5  free_load_conservation_1136  -4
    service_1_20_5  original_T_including_depot_unload_1182  480
    service_1_20_6  unique_nonzero_owner_295  1
    service_1_20_6  service_visit_def_1135  1
    service_1_20_6  free_load_conservation_1136  -3
    service_1_20_6  original_T_including_depot_unload_1182  360
    service_1_20_7  unique_nonzero_owner_296  1
    service_1_20_7  service_visit_def_1135  1
    service_1_20_7  free_load_conservation_1136  -2
    service_1_20_7  original_T_including_depot_unload_1182  240
    service_1_20_8  unique_nonzero_owner_297  1
    service_1_20_8  service_visit_def_1135  1
    service_1_20_8  free_load_conservation_1136  -1
    service_1_20_8  original_T_including_depot_unload_1182  120
    service_1_20_10  unique_nonzero_owner_298  1
    service_1_20_10  service_visit_def_1135  1
    service_1_20_10  free_load_conservation_1136  1
    service_1_20_11  unique_nonzero_owner_299  1
    service_1_20_11  service_visit_def_1135  1
    service_1_20_11  free_load_conservation_1136  2
    service_1_20_12  unique_nonzero_owner_300  1
    service_1_20_12  service_visit_def_1135  1
    service_1_20_12  free_load_conservation_1136  3
    service_2_20_0  unique_nonzero_owner_289  1
    service_2_20_0  service_visit_def_1453  1
    service_2_20_0  free_load_conservation_1454  -9
    service_2_20_0  original_T_including_depot_unload_1499  1080
    service_2_20_1  unique_nonzero_owner_290  1
    service_2_20_1  service_visit_def_1453  1
    service_2_20_1  free_load_conservation_1454  -8
    service_2_20_1  original_T_including_depot_unload_1499  960
    service_2_20_2  unique_nonzero_owner_291  1
    service_2_20_2  service_visit_def_1453  1
    service_2_20_2  free_load_conservation_1454  -7
    service_2_20_2  original_T_including_depot_unload_1499  840
    service_2_20_3  unique_nonzero_owner_292  1
    service_2_20_3  service_visit_def_1453  1
    service_2_20_3  free_load_conservation_1454  -6
    service_2_20_3  original_T_including_depot_unload_1499  720
    service_2_20_4  unique_nonzero_owner_293  1
    service_2_20_4  service_visit_def_1453  1
    service_2_20_4  free_load_conservation_1454  -5
    service_2_20_4  original_T_including_depot_unload_1499  600
    service_2_20_5  unique_nonzero_owner_294  1
    service_2_20_5  service_visit_def_1453  1
    service_2_20_5  free_load_conservation_1454  -4
    service_2_20_5  original_T_including_depot_unload_1499  480
    service_2_20_6  unique_nonzero_owner_295  1
    service_2_20_6  service_visit_def_1453  1
    service_2_20_6  free_load_conservation_1454  -3
    service_2_20_6  original_T_including_depot_unload_1499  360
    service_2_20_7  unique_nonzero_owner_296  1
    service_2_20_7  service_visit_def_1453  1
    service_2_20_7  free_load_conservation_1454  -2
    service_2_20_7  original_T_including_depot_unload_1499  240
    service_2_20_8  unique_nonzero_owner_297  1
    service_2_20_8  service_visit_def_1453  1
    service_2_20_8  free_load_conservation_1454  -1
    service_2_20_8  original_T_including_depot_unload_1499  120
    service_2_20_10  unique_nonzero_owner_298  1
    service_2_20_10  service_visit_def_1453  1
    service_2_20_10  free_load_conservation_1454  1
    service_2_20_11  unique_nonzero_owner_299  1
    service_2_20_11  service_visit_def_1453  1
    service_2_20_11  free_load_conservation_1454  2
    service_2_20_12  unique_nonzero_owner_300  1
    service_2_20_12  service_visit_def_1453  1
    service_2_20_12  free_load_conservation_1454  3
    service_0_21_0  unique_nonzero_owner_301  1
    service_0_21_0  service_visit_def_769  1
    service_0_21_0  free_load_conservation_770  -1
    service_0_21_0  original_T_including_depot_unload_811  120
    service_0_21_2  unique_nonzero_owner_302  1
    service_0_21_2  service_visit_def_769  1
    service_0_21_2  free_load_conservation_770  1
    service_0_21_3  unique_nonzero_owner_303  1
    service_0_21_3  service_visit_def_769  1
    service_0_21_3  free_load_conservation_770  2
    service_0_21_4  unique_nonzero_owner_304  1
    service_0_21_4  service_visit_def_769  1
    service_0_21_4  free_load_conservation_770  3
    service_0_21_5  unique_nonzero_owner_305  1
    service_0_21_5  service_visit_def_769  1
    service_0_21_5  free_load_conservation_770  4
    service_0_21_6  unique_nonzero_owner_306  1
    service_0_21_6  service_visit_def_769  1
    service_0_21_6  free_load_conservation_770  5
    service_0_21_7  unique_nonzero_owner_307  1
    service_0_21_7  service_visit_def_769  1
    service_0_21_7  free_load_conservation_770  6
    service_0_21_8  unique_nonzero_owner_308  1
    service_0_21_8  service_visit_def_769  1
    service_0_21_8  free_load_conservation_770  7
    service_0_21_9  unique_nonzero_owner_309  1
    service_0_21_9  service_visit_def_769  1
    service_0_21_9  free_load_conservation_770  8
    service_0_21_10  unique_nonzero_owner_310  1
    service_0_21_10  service_visit_def_769  1
    service_0_21_10  free_load_conservation_770  9
    service_0_21_11  unique_nonzero_owner_311  1
    service_0_21_11  service_visit_def_769  1
    service_0_21_11  free_load_conservation_770  10
    service_0_21_12  unique_nonzero_owner_312  1
    service_0_21_12  service_visit_def_769  1
    service_0_21_12  free_load_conservation_770  11
    service_0_21_13  unique_nonzero_owner_313  1
    service_0_21_13  service_visit_def_769  1
    service_0_21_13  free_load_conservation_770  12
    service_0_21_14  unique_nonzero_owner_314  1
    service_0_21_14  service_visit_def_769  1
    service_0_21_14  free_load_conservation_770  13
    service_0_21_15  unique_nonzero_owner_315  1
    service_0_21_15  service_visit_def_769  1
    service_0_21_15  free_load_conservation_770  14
    service_1_21_0  unique_nonzero_owner_301  1
    service_1_21_0  service_visit_def_1141  1
    service_1_21_0  free_load_conservation_1142  -1
    service_1_21_0  original_T_including_depot_unload_1182  120
    service_1_21_2  unique_nonzero_owner_302  1
    service_1_21_2  service_visit_def_1141  1
    service_1_21_2  free_load_conservation_1142  1
    service_1_21_3  unique_nonzero_owner_303  1
    service_1_21_3  service_visit_def_1141  1
    service_1_21_3  free_load_conservation_1142  2
    service_1_21_4  unique_nonzero_owner_304  1
    service_1_21_4  service_visit_def_1141  1
    service_1_21_4  free_load_conservation_1142  3
    service_1_21_5  unique_nonzero_owner_305  1
    service_1_21_5  service_visit_def_1141  1
    service_1_21_5  free_load_conservation_1142  4
    service_1_21_6  unique_nonzero_owner_306  1
    service_1_21_6  service_visit_def_1141  1
    service_1_21_6  free_load_conservation_1142  5
    service_1_21_7  unique_nonzero_owner_307  1
    service_1_21_7  service_visit_def_1141  1
    service_1_21_7  free_load_conservation_1142  6
    service_1_21_8  unique_nonzero_owner_308  1
    service_1_21_8  service_visit_def_1141  1
    service_1_21_8  free_load_conservation_1142  7
    service_1_21_9  unique_nonzero_owner_309  1
    service_1_21_9  service_visit_def_1141  1
    service_1_21_9  free_load_conservation_1142  8
    service_1_21_10  unique_nonzero_owner_310  1
    service_1_21_10  service_visit_def_1141  1
    service_1_21_10  free_load_conservation_1142  9
    service_1_21_11  unique_nonzero_owner_311  1
    service_1_21_11  service_visit_def_1141  1
    service_1_21_11  free_load_conservation_1142  10
    service_1_21_12  unique_nonzero_owner_312  1
    service_1_21_12  service_visit_def_1141  1
    service_1_21_12  free_load_conservation_1142  11
    service_1_21_13  unique_nonzero_owner_313  1
    service_1_21_13  service_visit_def_1141  1
    service_1_21_13  free_load_conservation_1142  12
    service_1_21_14  unique_nonzero_owner_314  1
    service_1_21_14  service_visit_def_1141  1
    service_1_21_14  free_load_conservation_1142  13
    service_1_21_15  unique_nonzero_owner_315  1
    service_1_21_15  service_visit_def_1141  1
    service_1_21_15  free_load_conservation_1142  14
    service_2_21_0  unique_nonzero_owner_301  1
    service_2_21_0  service_visit_def_1459  1
    service_2_21_0  free_load_conservation_1460  -1
    service_2_21_0  original_T_including_depot_unload_1499  120
    service_2_21_2  unique_nonzero_owner_302  1
    service_2_21_2  service_visit_def_1459  1
    service_2_21_2  free_load_conservation_1460  1
    service_2_21_3  unique_nonzero_owner_303  1
    service_2_21_3  service_visit_def_1459  1
    service_2_21_3  free_load_conservation_1460  2
    service_2_21_4  unique_nonzero_owner_304  1
    service_2_21_4  service_visit_def_1459  1
    service_2_21_4  free_load_conservation_1460  3
    service_2_21_5  unique_nonzero_owner_305  1
    service_2_21_5  service_visit_def_1459  1
    service_2_21_5  free_load_conservation_1460  4
    service_2_21_6  unique_nonzero_owner_306  1
    service_2_21_6  service_visit_def_1459  1
    service_2_21_6  free_load_conservation_1460  5
    service_2_21_7  unique_nonzero_owner_307  1
    service_2_21_7  service_visit_def_1459  1
    service_2_21_7  free_load_conservation_1460  6
    service_2_21_8  unique_nonzero_owner_308  1
    service_2_21_8  service_visit_def_1459  1
    service_2_21_8  free_load_conservation_1460  7
    service_2_21_9  unique_nonzero_owner_309  1
    service_2_21_9  service_visit_def_1459  1
    service_2_21_9  free_load_conservation_1460  8
    service_2_21_10  unique_nonzero_owner_310  1
    service_2_21_10  service_visit_def_1459  1
    service_2_21_10  free_load_conservation_1460  9
    service_2_21_11  unique_nonzero_owner_311  1
    service_2_21_11  service_visit_def_1459  1
    service_2_21_11  free_load_conservation_1460  10
    service_2_21_12  unique_nonzero_owner_312  1
    service_2_21_12  service_visit_def_1459  1
    service_2_21_12  free_load_conservation_1460  11
    service_2_21_13  unique_nonzero_owner_313  1
    service_2_21_13  service_visit_def_1459  1
    service_2_21_13  free_load_conservation_1460  12
    service_2_21_14  unique_nonzero_owner_314  1
    service_2_21_14  service_visit_def_1459  1
    service_2_21_14  free_load_conservation_1460  13
    service_2_21_15  unique_nonzero_owner_315  1
    service_2_21_15  service_visit_def_1459  1
    service_2_21_15  free_load_conservation_1460  14
    service_0_31_0  unique_nonzero_owner_316  1
    service_0_31_0  service_visit_def_775  1
    service_0_31_0  free_load_conservation_776  -2
    service_0_31_0  original_T_including_depot_unload_811  240
    service_0_31_1  unique_nonzero_owner_317  1
    service_0_31_1  service_visit_def_775  1
    service_0_31_1  free_load_conservation_776  -1
    service_0_31_1  original_T_including_depot_unload_811  120
    service_0_31_3  unique_nonzero_owner_318  1
    service_0_31_3  service_visit_def_775  1
    service_0_31_3  free_load_conservation_776  1
    service_0_31_4  unique_nonzero_owner_319  1
    service_0_31_4  service_visit_def_775  1
    service_0_31_4  free_load_conservation_776  2
    service_0_31_5  unique_nonzero_owner_320  1
    service_0_31_5  service_visit_def_775  1
    service_0_31_5  free_load_conservation_776  3
    service_0_31_6  unique_nonzero_owner_321  1
    service_0_31_6  service_visit_def_775  1
    service_0_31_6  free_load_conservation_776  4
    service_0_31_7  unique_nonzero_owner_322  1
    service_0_31_7  service_visit_def_775  1
    service_0_31_7  free_load_conservation_776  5
    service_0_31_8  unique_nonzero_owner_323  1
    service_0_31_8  service_visit_def_775  1
    service_0_31_8  free_load_conservation_776  6
    service_0_31_9  unique_nonzero_owner_324  1
    service_0_31_9  service_visit_def_775  1
    service_0_31_9  free_load_conservation_776  7
    service_0_31_10  unique_nonzero_owner_325  1
    service_0_31_10  service_visit_def_775  1
    service_0_31_10  free_load_conservation_776  8
    service_0_31_11  unique_nonzero_owner_326  1
    service_0_31_11  service_visit_def_775  1
    service_0_31_11  free_load_conservation_776  9
    service_0_31_12  unique_nonzero_owner_327  1
    service_0_31_12  service_visit_def_775  1
    service_0_31_12  free_load_conservation_776  10
    service_1_31_0  unique_nonzero_owner_316  1
    service_1_31_0  service_visit_def_1147  1
    service_1_31_0  free_load_conservation_1148  -2
    service_1_31_0  original_T_including_depot_unload_1182  240
    service_1_31_1  unique_nonzero_owner_317  1
    service_1_31_1  service_visit_def_1147  1
    service_1_31_1  free_load_conservation_1148  -1
    service_1_31_1  original_T_including_depot_unload_1182  120
    service_1_31_3  unique_nonzero_owner_318  1
    service_1_31_3  service_visit_def_1147  1
    service_1_31_3  free_load_conservation_1148  1
    service_1_31_4  unique_nonzero_owner_319  1
    service_1_31_4  service_visit_def_1147  1
    service_1_31_4  free_load_conservation_1148  2
    service_1_31_5  unique_nonzero_owner_320  1
    service_1_31_5  service_visit_def_1147  1
    service_1_31_5  free_load_conservation_1148  3
    service_1_31_6  unique_nonzero_owner_321  1
    service_1_31_6  service_visit_def_1147  1
    service_1_31_6  free_load_conservation_1148  4
    service_1_31_7  unique_nonzero_owner_322  1
    service_1_31_7  service_visit_def_1147  1
    service_1_31_7  free_load_conservation_1148  5
    service_1_31_8  unique_nonzero_owner_323  1
    service_1_31_8  service_visit_def_1147  1
    service_1_31_8  free_load_conservation_1148  6
    service_1_31_9  unique_nonzero_owner_324  1
    service_1_31_9  service_visit_def_1147  1
    service_1_31_9  free_load_conservation_1148  7
    service_1_31_10  unique_nonzero_owner_325  1
    service_1_31_10  service_visit_def_1147  1
    service_1_31_10  free_load_conservation_1148  8
    service_1_31_11  unique_nonzero_owner_326  1
    service_1_31_11  service_visit_def_1147  1
    service_1_31_11  free_load_conservation_1148  9
    service_1_31_12  unique_nonzero_owner_327  1
    service_1_31_12  service_visit_def_1147  1
    service_1_31_12  free_load_conservation_1148  10
    service_2_31_0  unique_nonzero_owner_316  1
    service_2_31_0  service_visit_def_1465  1
    service_2_31_0  free_load_conservation_1466  -2
    service_2_31_0  original_T_including_depot_unload_1499  240
    service_2_31_1  unique_nonzero_owner_317  1
    service_2_31_1  service_visit_def_1465  1
    service_2_31_1  free_load_conservation_1466  -1
    service_2_31_1  original_T_including_depot_unload_1499  120
    service_2_31_3  unique_nonzero_owner_318  1
    service_2_31_3  service_visit_def_1465  1
    service_2_31_3  free_load_conservation_1466  1
    service_2_31_4  unique_nonzero_owner_319  1
    service_2_31_4  service_visit_def_1465  1
    service_2_31_4  free_load_conservation_1466  2
    service_2_31_5  unique_nonzero_owner_320  1
    service_2_31_5  service_visit_def_1465  1
    service_2_31_5  free_load_conservation_1466  3
    service_2_31_6  unique_nonzero_owner_321  1
    service_2_31_6  service_visit_def_1465  1
    service_2_31_6  free_load_conservation_1466  4
    service_2_31_7  unique_nonzero_owner_322  1
    service_2_31_7  service_visit_def_1465  1
    service_2_31_7  free_load_conservation_1466  5
    service_2_31_8  unique_nonzero_owner_323  1
    service_2_31_8  service_visit_def_1465  1
    service_2_31_8  free_load_conservation_1466  6
    service_2_31_9  unique_nonzero_owner_324  1
    service_2_31_9  service_visit_def_1465  1
    service_2_31_9  free_load_conservation_1466  7
    service_2_31_10  unique_nonzero_owner_325  1
    service_2_31_10  service_visit_def_1465  1
    service_2_31_10  free_load_conservation_1466  8
    service_2_31_11  unique_nonzero_owner_326  1
    service_2_31_11  service_visit_def_1465  1
    service_2_31_11  free_load_conservation_1466  9
    service_2_31_12  unique_nonzero_owner_327  1
    service_2_31_12  service_visit_def_1465  1
    service_2_31_12  free_load_conservation_1466  10
    service_0_23_0  unique_nonzero_owner_328  1
    service_0_23_0  service_visit_def_781  1
    service_0_23_0  free_load_conservation_782  -7
    service_0_23_0  original_T_including_depot_unload_811  840
    service_0_23_1  unique_nonzero_owner_329  1
    service_0_23_1  service_visit_def_781  1
    service_0_23_1  free_load_conservation_782  -6
    service_0_23_1  original_T_including_depot_unload_811  720
    service_0_23_2  unique_nonzero_owner_330  1
    service_0_23_2  service_visit_def_781  1
    service_0_23_2  free_load_conservation_782  -5
    service_0_23_2  original_T_including_depot_unload_811  600
    service_0_23_3  unique_nonzero_owner_331  1
    service_0_23_3  service_visit_def_781  1
    service_0_23_3  free_load_conservation_782  -4
    service_0_23_3  original_T_including_depot_unload_811  480
    service_0_23_4  unique_nonzero_owner_332  1
    service_0_23_4  service_visit_def_781  1
    service_0_23_4  free_load_conservation_782  -3
    service_0_23_4  original_T_including_depot_unload_811  360
    service_0_23_5  unique_nonzero_owner_333  1
    service_0_23_5  service_visit_def_781  1
    service_0_23_5  free_load_conservation_782  -2
    service_0_23_5  original_T_including_depot_unload_811  240
    service_0_23_6  unique_nonzero_owner_334  1
    service_0_23_6  service_visit_def_781  1
    service_0_23_6  free_load_conservation_782  -1
    service_0_23_6  original_T_including_depot_unload_811  120
    service_0_23_8  unique_nonzero_owner_335  1
    service_0_23_8  service_visit_def_781  1
    service_0_23_8  free_load_conservation_782  1
    service_0_23_9  unique_nonzero_owner_336  1
    service_0_23_9  service_visit_def_781  1
    service_0_23_9  free_load_conservation_782  2
    service_0_23_10  unique_nonzero_owner_337  1
    service_0_23_10  service_visit_def_781  1
    service_0_23_10  free_load_conservation_782  3
    service_0_23_11  unique_nonzero_owner_338  1
    service_0_23_11  service_visit_def_781  1
    service_0_23_11  free_load_conservation_782  4
    service_1_23_0  unique_nonzero_owner_328  1
    service_1_23_0  service_visit_def_1153  1
    service_1_23_0  free_load_conservation_1154  -7
    service_1_23_0  original_T_including_depot_unload_1182  840
    service_1_23_1  unique_nonzero_owner_329  1
    service_1_23_1  service_visit_def_1153  1
    service_1_23_1  free_load_conservation_1154  -6
    service_1_23_1  original_T_including_depot_unload_1182  720
    service_1_23_2  unique_nonzero_owner_330  1
    service_1_23_2  service_visit_def_1153  1
    service_1_23_2  free_load_conservation_1154  -5
    service_1_23_2  original_T_including_depot_unload_1182  600
    service_1_23_3  unique_nonzero_owner_331  1
    service_1_23_3  service_visit_def_1153  1
    service_1_23_3  free_load_conservation_1154  -4
    service_1_23_3  original_T_including_depot_unload_1182  480
    service_1_23_4  unique_nonzero_owner_332  1
    service_1_23_4  service_visit_def_1153  1
    service_1_23_4  free_load_conservation_1154  -3
    service_1_23_4  original_T_including_depot_unload_1182  360
    service_1_23_5  unique_nonzero_owner_333  1
    service_1_23_5  service_visit_def_1153  1
    service_1_23_5  free_load_conservation_1154  -2
    service_1_23_5  original_T_including_depot_unload_1182  240
    service_1_23_6  unique_nonzero_owner_334  1
    service_1_23_6  service_visit_def_1153  1
    service_1_23_6  free_load_conservation_1154  -1
    service_1_23_6  original_T_including_depot_unload_1182  120
    service_1_23_8  unique_nonzero_owner_335  1
    service_1_23_8  service_visit_def_1153  1
    service_1_23_8  free_load_conservation_1154  1
    service_1_23_9  unique_nonzero_owner_336  1
    service_1_23_9  service_visit_def_1153  1
    service_1_23_9  free_load_conservation_1154  2
    service_1_23_10  unique_nonzero_owner_337  1
    service_1_23_10  service_visit_def_1153  1
    service_1_23_10  free_load_conservation_1154  3
    service_1_23_11  unique_nonzero_owner_338  1
    service_1_23_11  service_visit_def_1153  1
    service_1_23_11  free_load_conservation_1154  4
    service_2_23_0  unique_nonzero_owner_328  1
    service_2_23_0  service_visit_def_1471  1
    service_2_23_0  free_load_conservation_1472  -7
    service_2_23_0  original_T_including_depot_unload_1499  840
    service_2_23_1  unique_nonzero_owner_329  1
    service_2_23_1  service_visit_def_1471  1
    service_2_23_1  free_load_conservation_1472  -6
    service_2_23_1  original_T_including_depot_unload_1499  720
    service_2_23_2  unique_nonzero_owner_330  1
    service_2_23_2  service_visit_def_1471  1
    service_2_23_2  free_load_conservation_1472  -5
    service_2_23_2  original_T_including_depot_unload_1499  600
    service_2_23_3  unique_nonzero_owner_331  1
    service_2_23_3  service_visit_def_1471  1
    service_2_23_3  free_load_conservation_1472  -4
    service_2_23_3  original_T_including_depot_unload_1499  480
    service_2_23_4  unique_nonzero_owner_332  1
    service_2_23_4  service_visit_def_1471  1
    service_2_23_4  free_load_conservation_1472  -3
    service_2_23_4  original_T_including_depot_unload_1499  360
    service_2_23_5  unique_nonzero_owner_333  1
    service_2_23_5  service_visit_def_1471  1
    service_2_23_5  free_load_conservation_1472  -2
    service_2_23_5  original_T_including_depot_unload_1499  240
    service_2_23_6  unique_nonzero_owner_334  1
    service_2_23_6  service_visit_def_1471  1
    service_2_23_6  free_load_conservation_1472  -1
    service_2_23_6  original_T_including_depot_unload_1499  120
    service_2_23_8  unique_nonzero_owner_335  1
    service_2_23_8  service_visit_def_1471  1
    service_2_23_8  free_load_conservation_1472  1
    service_2_23_9  unique_nonzero_owner_336  1
    service_2_23_9  service_visit_def_1471  1
    service_2_23_9  free_load_conservation_1472  2
    service_2_23_10  unique_nonzero_owner_337  1
    service_2_23_10  service_visit_def_1471  1
    service_2_23_10  free_load_conservation_1472  3
    service_2_23_11  unique_nonzero_owner_338  1
    service_2_23_11  service_visit_def_1471  1
    service_2_23_11  free_load_conservation_1472  4
    service_0_32_1  unique_nonzero_owner_339  1
    service_0_32_1  service_visit_def_787  1
    service_0_32_1  free_load_conservation_788  1
    service_0_32_2  unique_nonzero_owner_340  1
    service_0_32_2  service_visit_def_787  1
    service_0_32_2  free_load_conservation_788  2
    service_0_32_3  unique_nonzero_owner_341  1
    service_0_32_3  service_visit_def_787  1
    service_0_32_3  free_load_conservation_788  3
    service_0_32_4  unique_nonzero_owner_342  1
    service_0_32_4  service_visit_def_787  1
    service_0_32_4  free_load_conservation_788  4
    service_0_32_5  unique_nonzero_owner_343  1
    service_0_32_5  service_visit_def_787  1
    service_0_32_5  free_load_conservation_788  5
    service_0_32_6  unique_nonzero_owner_344  1
    service_0_32_6  service_visit_def_787  1
    service_0_32_6  free_load_conservation_788  6
    service_0_32_7  unique_nonzero_owner_345  1
    service_0_32_7  service_visit_def_787  1
    service_0_32_7  free_load_conservation_788  7
    service_0_32_8  unique_nonzero_owner_346  1
    service_0_32_8  service_visit_def_787  1
    service_0_32_8  free_load_conservation_788  8
    service_0_32_9  unique_nonzero_owner_347  1
    service_0_32_9  service_visit_def_787  1
    service_0_32_9  free_load_conservation_788  9
    service_0_32_10  unique_nonzero_owner_348  1
    service_0_32_10  service_visit_def_787  1
    service_0_32_10  free_load_conservation_788  10
    service_0_32_11  unique_nonzero_owner_349  1
    service_0_32_11  service_visit_def_787  1
    service_0_32_11  free_load_conservation_788  11
    service_0_32_12  unique_nonzero_owner_350  1
    service_0_32_12  service_visit_def_787  1
    service_0_32_12  free_load_conservation_788  12
    service_1_32_1  unique_nonzero_owner_339  1
    service_1_32_1  service_visit_def_1159  1
    service_1_32_1  free_load_conservation_1160  1
    service_1_32_2  unique_nonzero_owner_340  1
    service_1_32_2  service_visit_def_1159  1
    service_1_32_2  free_load_conservation_1160  2
    service_1_32_3  unique_nonzero_owner_341  1
    service_1_32_3  service_visit_def_1159  1
    service_1_32_3  free_load_conservation_1160  3
    service_1_32_4  unique_nonzero_owner_342  1
    service_1_32_4  service_visit_def_1159  1
    service_1_32_4  free_load_conservation_1160  4
    service_1_32_5  unique_nonzero_owner_343  1
    service_1_32_5  service_visit_def_1159  1
    service_1_32_5  free_load_conservation_1160  5
    service_1_32_6  unique_nonzero_owner_344  1
    service_1_32_6  service_visit_def_1159  1
    service_1_32_6  free_load_conservation_1160  6
    service_1_32_7  unique_nonzero_owner_345  1
    service_1_32_7  service_visit_def_1159  1
    service_1_32_7  free_load_conservation_1160  7
    service_1_32_8  unique_nonzero_owner_346  1
    service_1_32_8  service_visit_def_1159  1
    service_1_32_8  free_load_conservation_1160  8
    service_1_32_9  unique_nonzero_owner_347  1
    service_1_32_9  service_visit_def_1159  1
    service_1_32_9  free_load_conservation_1160  9
    service_1_32_10  unique_nonzero_owner_348  1
    service_1_32_10  service_visit_def_1159  1
    service_1_32_10  free_load_conservation_1160  10
    service_1_32_11  unique_nonzero_owner_349  1
    service_1_32_11  service_visit_def_1159  1
    service_1_32_11  free_load_conservation_1160  11
    service_1_32_12  unique_nonzero_owner_350  1
    service_1_32_12  service_visit_def_1159  1
    service_1_32_12  free_load_conservation_1160  12
    service_2_32_1  unique_nonzero_owner_339  1
    service_2_32_1  service_visit_def_1477  1
    service_2_32_1  free_load_conservation_1478  1
    service_2_32_2  unique_nonzero_owner_340  1
    service_2_32_2  service_visit_def_1477  1
    service_2_32_2  free_load_conservation_1478  2
    service_2_32_3  unique_nonzero_owner_341  1
    service_2_32_3  service_visit_def_1477  1
    service_2_32_3  free_load_conservation_1478  3
    service_2_32_4  unique_nonzero_owner_342  1
    service_2_32_4  service_visit_def_1477  1
    service_2_32_4  free_load_conservation_1478  4
    service_2_32_5  unique_nonzero_owner_343  1
    service_2_32_5  service_visit_def_1477  1
    service_2_32_5  free_load_conservation_1478  5
    service_2_32_6  unique_nonzero_owner_344  1
    service_2_32_6  service_visit_def_1477  1
    service_2_32_6  free_load_conservation_1478  6
    service_2_32_7  unique_nonzero_owner_345  1
    service_2_32_7  service_visit_def_1477  1
    service_2_32_7  free_load_conservation_1478  7
    service_2_32_8  unique_nonzero_owner_346  1
    service_2_32_8  service_visit_def_1477  1
    service_2_32_8  free_load_conservation_1478  8
    service_2_32_9  unique_nonzero_owner_347  1
    service_2_32_9  service_visit_def_1477  1
    service_2_32_9  free_load_conservation_1478  9
    service_2_32_10  unique_nonzero_owner_348  1
    service_2_32_10  service_visit_def_1477  1
    service_2_32_10  free_load_conservation_1478  10
    service_2_32_11  unique_nonzero_owner_349  1
    service_2_32_11  service_visit_def_1477  1
    service_2_32_11  free_load_conservation_1478  11
    service_2_32_12  unique_nonzero_owner_350  1
    service_2_32_12  service_visit_def_1477  1
    service_2_32_12  free_load_conservation_1478  12
    service_0_16_0  unique_nonzero_owner_351  1
    service_0_16_0  service_visit_def_793  1
    service_0_16_0  free_load_conservation_794  -1
    service_0_16_0  original_T_including_depot_unload_811  120
    service_0_16_2  unique_nonzero_owner_352  1
    service_0_16_2  service_visit_def_793  1
    service_0_16_2  free_load_conservation_794  1
    service_0_16_3  unique_nonzero_owner_353  1
    service_0_16_3  service_visit_def_793  1
    service_0_16_3  free_load_conservation_794  2
    service_0_16_4  unique_nonzero_owner_354  1
    service_0_16_4  service_visit_def_793  1
    service_0_16_4  free_load_conservation_794  3
    service_0_16_5  unique_nonzero_owner_355  1
    service_0_16_5  service_visit_def_793  1
    service_0_16_5  free_load_conservation_794  4
    service_0_16_6  unique_nonzero_owner_356  1
    service_0_16_6  service_visit_def_793  1
    service_0_16_6  free_load_conservation_794  5
    service_0_16_7  unique_nonzero_owner_357  1
    service_0_16_7  service_visit_def_793  1
    service_0_16_7  free_load_conservation_794  6
    service_0_16_8  unique_nonzero_owner_358  1
    service_0_16_8  service_visit_def_793  1
    service_0_16_8  free_load_conservation_794  7
    service_0_16_9  unique_nonzero_owner_359  1
    service_0_16_9  service_visit_def_793  1
    service_0_16_9  free_load_conservation_794  8
    service_0_16_10  unique_nonzero_owner_360  1
    service_0_16_10  service_visit_def_793  1
    service_0_16_10  free_load_conservation_794  9
    service_0_16_11  unique_nonzero_owner_361  1
    service_0_16_11  service_visit_def_793  1
    service_0_16_11  free_load_conservation_794  10
    service_0_16_12  unique_nonzero_owner_362  1
    service_0_16_12  service_visit_def_793  1
    service_0_16_12  free_load_conservation_794  11
    service_1_16_0  unique_nonzero_owner_351  1
    service_1_16_0  service_visit_def_1165  1
    service_1_16_0  free_load_conservation_1166  -1
    service_1_16_0  original_T_including_depot_unload_1182  120
    service_1_16_2  unique_nonzero_owner_352  1
    service_1_16_2  service_visit_def_1165  1
    service_1_16_2  free_load_conservation_1166  1
    service_1_16_3  unique_nonzero_owner_353  1
    service_1_16_3  service_visit_def_1165  1
    service_1_16_3  free_load_conservation_1166  2
    service_1_16_4  unique_nonzero_owner_354  1
    service_1_16_4  service_visit_def_1165  1
    service_1_16_4  free_load_conservation_1166  3
    service_1_16_5  unique_nonzero_owner_355  1
    service_1_16_5  service_visit_def_1165  1
    service_1_16_5  free_load_conservation_1166  4
    service_1_16_6  unique_nonzero_owner_356  1
    service_1_16_6  service_visit_def_1165  1
    service_1_16_6  free_load_conservation_1166  5
    service_1_16_7  unique_nonzero_owner_357  1
    service_1_16_7  service_visit_def_1165  1
    service_1_16_7  free_load_conservation_1166  6
    service_1_16_8  unique_nonzero_owner_358  1
    service_1_16_8  service_visit_def_1165  1
    service_1_16_8  free_load_conservation_1166  7
    service_1_16_9  unique_nonzero_owner_359  1
    service_1_16_9  service_visit_def_1165  1
    service_1_16_9  free_load_conservation_1166  8
    service_1_16_10  unique_nonzero_owner_360  1
    service_1_16_10  service_visit_def_1165  1
    service_1_16_10  free_load_conservation_1166  9
    service_1_16_11  unique_nonzero_owner_361  1
    service_1_16_11  service_visit_def_1165  1
    service_1_16_11  free_load_conservation_1166  10
    service_1_16_12  unique_nonzero_owner_362  1
    service_1_16_12  service_visit_def_1165  1
    service_1_16_12  free_load_conservation_1166  11
    service_2_16_0  unique_nonzero_owner_351  1
    service_2_16_0  service_visit_def_1483  1
    service_2_16_0  free_load_conservation_1484  -1
    service_2_16_0  original_T_including_depot_unload_1499  120
    service_2_16_2  unique_nonzero_owner_352  1
    service_2_16_2  service_visit_def_1483  1
    service_2_16_2  free_load_conservation_1484  1
    service_2_16_3  unique_nonzero_owner_353  1
    service_2_16_3  service_visit_def_1483  1
    service_2_16_3  free_load_conservation_1484  2
    service_2_16_4  unique_nonzero_owner_354  1
    service_2_16_4  service_visit_def_1483  1
    service_2_16_4  free_load_conservation_1484  3
    service_2_16_5  unique_nonzero_owner_355  1
    service_2_16_5  service_visit_def_1483  1
    service_2_16_5  free_load_conservation_1484  4
    service_2_16_6  unique_nonzero_owner_356  1
    service_2_16_6  service_visit_def_1483  1
    service_2_16_6  free_load_conservation_1484  5
    service_2_16_7  unique_nonzero_owner_357  1
    service_2_16_7  service_visit_def_1483  1
    service_2_16_7  free_load_conservation_1484  6
    service_2_16_8  unique_nonzero_owner_358  1
    service_2_16_8  service_visit_def_1483  1
    service_2_16_8  free_load_conservation_1484  7
    service_2_16_9  unique_nonzero_owner_359  1
    service_2_16_9  service_visit_def_1483  1
    service_2_16_9  free_load_conservation_1484  8
    service_2_16_10  unique_nonzero_owner_360  1
    service_2_16_10  service_visit_def_1483  1
    service_2_16_10  free_load_conservation_1484  9
    service_2_16_11  unique_nonzero_owner_361  1
    service_2_16_11  service_visit_def_1483  1
    service_2_16_11  free_load_conservation_1484  10
    service_2_16_12  unique_nonzero_owner_362  1
    service_2_16_12  service_visit_def_1483  1
    service_2_16_12  free_load_conservation_1484  11
    service_0_19_1  unique_nonzero_owner_363  1
    service_0_19_1  service_visit_def_799  1
    service_0_19_1  free_load_conservation_800  1
    service_0_19_2  unique_nonzero_owner_364  1
    service_0_19_2  service_visit_def_799  1
    service_0_19_2  free_load_conservation_800  2
    service_0_19_3  unique_nonzero_owner_365  1
    service_0_19_3  service_visit_def_799  1
    service_0_19_3  free_load_conservation_800  3
    service_0_19_4  unique_nonzero_owner_366  1
    service_0_19_4  service_visit_def_799  1
    service_0_19_4  free_load_conservation_800  4
    service_0_19_5  unique_nonzero_owner_367  1
    service_0_19_5  service_visit_def_799  1
    service_0_19_5  free_load_conservation_800  5
    service_0_19_6  unique_nonzero_owner_368  1
    service_0_19_6  service_visit_def_799  1
    service_0_19_6  free_load_conservation_800  6
    service_0_19_7  unique_nonzero_owner_369  1
    service_0_19_7  service_visit_def_799  1
    service_0_19_7  free_load_conservation_800  7
    service_0_19_8  unique_nonzero_owner_370  1
    service_0_19_8  service_visit_def_799  1
    service_0_19_8  free_load_conservation_800  8
    service_1_19_1  unique_nonzero_owner_363  1
    service_1_19_1  service_visit_def_1171  1
    service_1_19_1  free_load_conservation_1172  1
    service_1_19_2  unique_nonzero_owner_364  1
    service_1_19_2  service_visit_def_1171  1
    service_1_19_2  free_load_conservation_1172  2
    service_1_19_3  unique_nonzero_owner_365  1
    service_1_19_3  service_visit_def_1171  1
    service_1_19_3  free_load_conservation_1172  3
    service_1_19_4  unique_nonzero_owner_366  1
    service_1_19_4  service_visit_def_1171  1
    service_1_19_4  free_load_conservation_1172  4
    service_1_19_5  unique_nonzero_owner_367  1
    service_1_19_5  service_visit_def_1171  1
    service_1_19_5  free_load_conservation_1172  5
    service_1_19_6  unique_nonzero_owner_368  1
    service_1_19_6  service_visit_def_1171  1
    service_1_19_6  free_load_conservation_1172  6
    service_1_19_7  unique_nonzero_owner_369  1
    service_1_19_7  service_visit_def_1171  1
    service_1_19_7  free_load_conservation_1172  7
    service_1_19_8  unique_nonzero_owner_370  1
    service_1_19_8  service_visit_def_1171  1
    service_1_19_8  free_load_conservation_1172  8
    service_2_19_1  unique_nonzero_owner_363  1
    service_2_19_1  service_visit_def_1489  1
    service_2_19_1  free_load_conservation_1490  1
    service_2_19_2  unique_nonzero_owner_364  1
    service_2_19_2  service_visit_def_1489  1
    service_2_19_2  free_load_conservation_1490  2
    service_2_19_3  unique_nonzero_owner_365  1
    service_2_19_3  service_visit_def_1489  1
    service_2_19_3  free_load_conservation_1490  3
    service_2_19_4  unique_nonzero_owner_366  1
    service_2_19_4  service_visit_def_1489  1
    service_2_19_4  free_load_conservation_1490  4
    service_2_19_5  unique_nonzero_owner_367  1
    service_2_19_5  service_visit_def_1489  1
    service_2_19_5  free_load_conservation_1490  5
    service_2_19_6  unique_nonzero_owner_368  1
    service_2_19_6  service_visit_def_1489  1
    service_2_19_6  free_load_conservation_1490  6
    service_2_19_7  unique_nonzero_owner_369  1
    service_2_19_7  service_visit_def_1489  1
    service_2_19_7  free_load_conservation_1490  7
    service_2_19_8  unique_nonzero_owner_370  1
    service_2_19_8  service_visit_def_1489  1
    service_2_19_8  free_load_conservation_1490  8
    service_0_11_0  unique_nonzero_owner_371  1
    service_0_11_0  service_visit_def_805  1
    service_0_11_0  free_load_conservation_806  -7
    service_0_11_0  original_T_including_depot_unload_811  840
    service_0_11_1  unique_nonzero_owner_372  1
    service_0_11_1  service_visit_def_805  1
    service_0_11_1  free_load_conservation_806  -6
    service_0_11_1  original_T_including_depot_unload_811  720
    service_0_11_2  unique_nonzero_owner_373  1
    service_0_11_2  service_visit_def_805  1
    service_0_11_2  free_load_conservation_806  -5
    service_0_11_2  original_T_including_depot_unload_811  600
    service_0_11_3  unique_nonzero_owner_374  1
    service_0_11_3  service_visit_def_805  1
    service_0_11_3  free_load_conservation_806  -4
    service_0_11_3  original_T_including_depot_unload_811  480
    service_0_11_4  unique_nonzero_owner_375  1
    service_0_11_4  service_visit_def_805  1
    service_0_11_4  free_load_conservation_806  -3
    service_0_11_4  original_T_including_depot_unload_811  360
    service_0_11_5  unique_nonzero_owner_376  1
    service_0_11_5  service_visit_def_805  1
    service_0_11_5  free_load_conservation_806  -2
    service_0_11_5  original_T_including_depot_unload_811  240
    service_0_11_6  unique_nonzero_owner_377  1
    service_0_11_6  service_visit_def_805  1
    service_0_11_6  free_load_conservation_806  -1
    service_0_11_6  original_T_including_depot_unload_811  120
    service_0_11_8  unique_nonzero_owner_378  1
    service_0_11_8  service_visit_def_805  1
    service_0_11_8  free_load_conservation_806  1
    service_0_11_9  unique_nonzero_owner_379  1
    service_0_11_9  service_visit_def_805  1
    service_0_11_9  free_load_conservation_806  2
    service_0_11_10  unique_nonzero_owner_380  1
    service_0_11_10  service_visit_def_805  1
    service_0_11_10  free_load_conservation_806  3
    service_0_11_11  unique_nonzero_owner_381  1
    service_0_11_11  service_visit_def_805  1
    service_0_11_11  free_load_conservation_806  4
    service_0_11_12  unique_nonzero_owner_382  1
    service_0_11_12  service_visit_def_805  1
    service_0_11_12  free_load_conservation_806  5
    service_1_11_0  unique_nonzero_owner_371  1
    service_1_11_0  service_visit_def_1177  1
    service_1_11_0  free_load_conservation_1178  -7
    service_1_11_0  original_T_including_depot_unload_1182  840
    service_1_11_1  unique_nonzero_owner_372  1
    service_1_11_1  service_visit_def_1177  1
    service_1_11_1  free_load_conservation_1178  -6
    service_1_11_1  original_T_including_depot_unload_1182  720
    service_1_11_2  unique_nonzero_owner_373  1
    service_1_11_2  service_visit_def_1177  1
    service_1_11_2  free_load_conservation_1178  -5
    service_1_11_2  original_T_including_depot_unload_1182  600
    service_1_11_3  unique_nonzero_owner_374  1
    service_1_11_3  service_visit_def_1177  1
    service_1_11_3  free_load_conservation_1178  -4
    service_1_11_3  original_T_including_depot_unload_1182  480
    service_1_11_4  unique_nonzero_owner_375  1
    service_1_11_4  service_visit_def_1177  1
    service_1_11_4  free_load_conservation_1178  -3
    service_1_11_4  original_T_including_depot_unload_1182  360
    service_1_11_5  unique_nonzero_owner_376  1
    service_1_11_5  service_visit_def_1177  1
    service_1_11_5  free_load_conservation_1178  -2
    service_1_11_5  original_T_including_depot_unload_1182  240
    service_1_11_6  unique_nonzero_owner_377  1
    service_1_11_6  service_visit_def_1177  1
    service_1_11_6  free_load_conservation_1178  -1
    service_1_11_6  original_T_including_depot_unload_1182  120
    service_1_11_8  unique_nonzero_owner_378  1
    service_1_11_8  service_visit_def_1177  1
    service_1_11_8  free_load_conservation_1178  1
    service_1_11_9  unique_nonzero_owner_379  1
    service_1_11_9  service_visit_def_1177  1
    service_1_11_9  free_load_conservation_1178  2
    service_1_11_10  unique_nonzero_owner_380  1
    service_1_11_10  service_visit_def_1177  1
    service_1_11_10  free_load_conservation_1178  3
    service_1_11_11  unique_nonzero_owner_381  1
    service_1_11_11  service_visit_def_1177  1
    service_1_11_11  free_load_conservation_1178  4
    service_1_11_12  unique_nonzero_owner_382  1
    service_1_11_12  service_visit_def_1177  1
    service_1_11_12  free_load_conservation_1178  5
    service_2_11_0  unique_nonzero_owner_371  1
    service_2_11_0  service_visit_def_1495  1
    service_2_11_0  free_load_conservation_1496  -7
    service_2_11_0  original_T_including_depot_unload_1499  840
    service_2_11_1  unique_nonzero_owner_372  1
    service_2_11_1  service_visit_def_1495  1
    service_2_11_1  free_load_conservation_1496  -6
    service_2_11_1  original_T_including_depot_unload_1499  720
    service_2_11_2  unique_nonzero_owner_373  1
    service_2_11_2  service_visit_def_1495  1
    service_2_11_2  free_load_conservation_1496  -5
    service_2_11_2  original_T_including_depot_unload_1499  600
    service_2_11_3  unique_nonzero_owner_374  1
    service_2_11_3  service_visit_def_1495  1
    service_2_11_3  free_load_conservation_1496  -4
    service_2_11_3  original_T_including_depot_unload_1499  480
    service_2_11_4  unique_nonzero_owner_375  1
    service_2_11_4  service_visit_def_1495  1
    service_2_11_4  free_load_conservation_1496  -3
    service_2_11_4  original_T_including_depot_unload_1499  360
    service_2_11_5  unique_nonzero_owner_376  1
    service_2_11_5  service_visit_def_1495  1
    service_2_11_5  free_load_conservation_1496  -2
    service_2_11_5  original_T_including_depot_unload_1499  240
    service_2_11_6  unique_nonzero_owner_377  1
    service_2_11_6  service_visit_def_1495  1
    service_2_11_6  free_load_conservation_1496  -1
    service_2_11_6  original_T_including_depot_unload_1499  120
    service_2_11_8  unique_nonzero_owner_378  1
    service_2_11_8  service_visit_def_1495  1
    service_2_11_8  free_load_conservation_1496  1
    service_2_11_9  unique_nonzero_owner_379  1
    service_2_11_9  service_visit_def_1495  1
    service_2_11_9  free_load_conservation_1496  2
    service_2_11_10  unique_nonzero_owner_380  1
    service_2_11_10  service_visit_def_1495  1
    service_2_11_10  free_load_conservation_1496  3
    service_2_11_11  unique_nonzero_owner_381  1
    service_2_11_11  service_visit_def_1495  1
    service_2_11_11  free_load_conservation_1496  4
    service_2_11_12  unique_nonzero_owner_382  1
    service_2_11_12  service_visit_def_1495  1
    service_2_11_12  free_load_conservation_1496  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_724  -1
    visit_0_1  in_degree_725  -1
    visit_0_1  order_active_lb_726  -1
    visit_0_1  order_active_ub_727  -13
    order_0_1  connected_order_arc_399  -1
    order_0_1  connected_order_arc_401  -1
    order_0_1  connected_order_arc_403  -1
    order_0_1  connected_order_arc_405  -1
    order_0_1  connected_order_arc_407  -1
    order_0_1  connected_order_arc_409  -1
    order_0_1  connected_order_arc_411  -1
    order_0_1  connected_order_arc_413  -1
    order_0_1  connected_order_arc_415  -1
    order_0_1  connected_order_arc_417  -1
    order_0_1  connected_order_arc_419  -1
    order_0_1  connected_order_arc_421  -1
    order_0_1  connected_order_arc_424  1
    order_0_1  connected_order_arc_449  1
    order_0_1  connected_order_arc_474  1
    order_0_1  connected_order_arc_499  1
    order_0_1  connected_order_arc_524  1
    order_0_1  connected_order_arc_549  1
    order_0_1  connected_order_arc_574  1
    order_0_1  connected_order_arc_599  1
    order_0_1  connected_order_arc_624  1
    order_0_1  connected_order_arc_649  1
    order_0_1  connected_order_arc_674  1
    order_0_1  connected_order_arc_699  1
    order_0_1  order_active_lb_726  1
    order_0_1  order_active_ub_727  1
    order_0_1  fixed_segment_relative_order_807  -1
    visit_0_2  out_degree_731  -1
    visit_0_2  in_degree_732  -1
    visit_0_2  order_active_lb_733  -1
    visit_0_2  order_active_ub_734  -13
    order_0_2  connected_order_arc_399  1
    order_0_2  connected_order_arc_424  -1
    order_0_2  connected_order_arc_426  -1
    order_0_2  connected_order_arc_428  -1
    order_0_2  connected_order_arc_430  -1
    order_0_2  connected_order_arc_432  -1
    order_0_2  connected_order_arc_434  -1
    order_0_2  connected_order_arc_436  -1
    order_0_2  connected_order_arc_438  -1
    order_0_2  connected_order_arc_440  -1
    order_0_2  connected_order_arc_442  -1
    order_0_2  connected_order_arc_444  -1
    order_0_2  connected_order_arc_446  -1
    order_0_2  connected_order_arc_451  1
    order_0_2  connected_order_arc_476  1
    order_0_2  connected_order_arc_501  1
    order_0_2  connected_order_arc_526  1
    order_0_2  connected_order_arc_551  1
    order_0_2  connected_order_arc_576  1
    order_0_2  connected_order_arc_601  1
    order_0_2  connected_order_arc_626  1
    order_0_2  connected_order_arc_651  1
    order_0_2  connected_order_arc_676  1
    order_0_2  connected_order_arc_701  1
    order_0_2  order_active_lb_733  1
    order_0_2  order_active_ub_734  1
    order_0_2  fixed_segment_relative_order_807  1
    order_0_2  fixed_segment_relative_order_808  -1
    visit_0_3  out_degree_738  -1
    visit_0_3  in_degree_739  -1
    visit_0_3  order_active_lb_740  -1
    visit_0_3  order_active_ub_741  -13
    order_0_3  connected_order_arc_401  1
    order_0_3  connected_order_arc_426  1
    order_0_3  connected_order_arc_449  -1
    order_0_3  connected_order_arc_451  -1
    order_0_3  connected_order_arc_453  -1
    order_0_3  connected_order_arc_455  -1
    order_0_3  connected_order_arc_457  -1
    order_0_3  connected_order_arc_459  -1
    order_0_3  connected_order_arc_461  -1
    order_0_3  connected_order_arc_463  -1
    order_0_3  connected_order_arc_465  -1
    order_0_3  connected_order_arc_467  -1
    order_0_3  connected_order_arc_469  -1
    order_0_3  connected_order_arc_471  -1
    order_0_3  connected_order_arc_478  1
    order_0_3  connected_order_arc_503  1
    order_0_3  connected_order_arc_528  1
    order_0_3  connected_order_arc_553  1
    order_0_3  connected_order_arc_578  1
    order_0_3  connected_order_arc_603  1
    order_0_3  connected_order_arc_628  1
    order_0_3  connected_order_arc_653  1
    order_0_3  connected_order_arc_678  1
    order_0_3  connected_order_arc_703  1
    order_0_3  order_active_lb_740  1
    order_0_3  order_active_ub_741  1
    order_0_3  fixed_segment_relative_order_808  1
    order_0_3  fixed_segment_relative_order_809  -1
    visit_0_4  out_degree_745  -1
    visit_0_4  in_degree_746  -1
    visit_0_4  order_active_lb_747  -1
    visit_0_4  order_active_ub_748  -13
    order_0_4  connected_order_arc_403  1
    order_0_4  connected_order_arc_428  1
    order_0_4  connected_order_arc_453  1
    order_0_4  connected_order_arc_474  -1
    order_0_4  connected_order_arc_476  -1
    order_0_4  connected_order_arc_478  -1
    order_0_4  connected_order_arc_480  -1
    order_0_4  connected_order_arc_482  -1
    order_0_4  connected_order_arc_484  -1
    order_0_4  connected_order_arc_486  -1
    order_0_4  connected_order_arc_488  -1
    order_0_4  connected_order_arc_490  -1
    order_0_4  connected_order_arc_492  -1
    order_0_4  connected_order_arc_494  -1
    order_0_4  connected_order_arc_496  -1
    order_0_4  connected_order_arc_505  1
    order_0_4  connected_order_arc_530  1
    order_0_4  connected_order_arc_555  1
    order_0_4  connected_order_arc_580  1
    order_0_4  connected_order_arc_605  1
    order_0_4  connected_order_arc_630  1
    order_0_4  connected_order_arc_655  1
    order_0_4  connected_order_arc_680  1
    order_0_4  connected_order_arc_705  1
    order_0_4  order_active_lb_747  1
    order_0_4  order_active_ub_748  1
    order_0_4  fixed_segment_relative_order_809  1
    order_0_4  fixed_segment_relative_order_810  -1
    visit_0_5  out_degree_752  -1
    visit_0_5  in_degree_753  -1
    visit_0_5  order_active_lb_754  -1
    visit_0_5  order_active_ub_755  -13
    order_0_5  connected_order_arc_405  1
    order_0_5  connected_order_arc_430  1
    order_0_5  connected_order_arc_455  1
    order_0_5  connected_order_arc_480  1
    order_0_5  connected_order_arc_499  -1
    order_0_5  connected_order_arc_501  -1
    order_0_5  connected_order_arc_503  -1
    order_0_5  connected_order_arc_505  -1
    order_0_5  connected_order_arc_507  -1
    order_0_5  connected_order_arc_509  -1
    order_0_5  connected_order_arc_511  -1
    order_0_5  connected_order_arc_513  -1
    order_0_5  connected_order_arc_515  -1
    order_0_5  connected_order_arc_517  -1
    order_0_5  connected_order_arc_519  -1
    order_0_5  connected_order_arc_521  -1
    order_0_5  connected_order_arc_532  1
    order_0_5  connected_order_arc_557  1
    order_0_5  connected_order_arc_582  1
    order_0_5  connected_order_arc_607  1
    order_0_5  connected_order_arc_632  1
    order_0_5  connected_order_arc_657  1
    order_0_5  connected_order_arc_682  1
    order_0_5  connected_order_arc_707  1
    order_0_5  order_active_lb_754  1
    order_0_5  order_active_ub_755  1
    order_0_5  fixed_segment_relative_order_810  1
    visit_0_13  out_degree_759  -1
    visit_0_13  in_degree_760  -1
    visit_0_13  order_active_lb_761  -1
    visit_0_13  order_active_ub_762  -13
    visit_0_13  service_visit_def_763  -1
    order_0_13  connected_order_arc_407  1
    order_0_13  connected_order_arc_432  1
    order_0_13  connected_order_arc_457  1
    order_0_13  connected_order_arc_482  1
    order_0_13  connected_order_arc_507  1
    order_0_13  connected_order_arc_524  -1
    order_0_13  connected_order_arc_526  -1
    order_0_13  connected_order_arc_528  -1
    order_0_13  connected_order_arc_530  -1
    order_0_13  connected_order_arc_532  -1
    order_0_13  connected_order_arc_534  -1
    order_0_13  connected_order_arc_536  -1
    order_0_13  connected_order_arc_538  -1
    order_0_13  connected_order_arc_540  -1
    order_0_13  connected_order_arc_542  -1
    order_0_13  connected_order_arc_544  -1
    order_0_13  connected_order_arc_546  -1
    order_0_13  connected_order_arc_559  1
    order_0_13  connected_order_arc_584  1
    order_0_13  connected_order_arc_609  1
    order_0_13  connected_order_arc_634  1
    order_0_13  connected_order_arc_659  1
    order_0_13  connected_order_arc_684  1
    order_0_13  connected_order_arc_709  1
    order_0_13  order_active_lb_761  1
    order_0_13  order_active_ub_762  1
    visit_0_14  out_degree_765  -1
    visit_0_14  in_degree_766  -1
    visit_0_14  order_active_lb_767  -1
    visit_0_14  order_active_ub_768  -13
    visit_0_14  service_visit_def_769  -1
    order_0_14  connected_order_arc_409  1
    order_0_14  connected_order_arc_434  1
    order_0_14  connected_order_arc_459  1
    order_0_14  connected_order_arc_484  1
    order_0_14  connected_order_arc_509  1
    order_0_14  connected_order_arc_534  1
    order_0_14  connected_order_arc_549  -1
    order_0_14  connected_order_arc_551  -1
    order_0_14  connected_order_arc_553  -1
    order_0_14  connected_order_arc_555  -1
    order_0_14  connected_order_arc_557  -1
    order_0_14  connected_order_arc_559  -1
    order_0_14  connected_order_arc_561  -1
    order_0_14  connected_order_arc_563  -1
    order_0_14  connected_order_arc_565  -1
    order_0_14  connected_order_arc_567  -1
    order_0_14  connected_order_arc_569  -1
    order_0_14  connected_order_arc_571  -1
    order_0_14  connected_order_arc_586  1
    order_0_14  connected_order_arc_611  1
    order_0_14  connected_order_arc_636  1
    order_0_14  connected_order_arc_661  1
    order_0_14  connected_order_arc_686  1
    order_0_14  connected_order_arc_711  1
    order_0_14  order_active_lb_767  1
    order_0_14  order_active_ub_768  1
    visit_0_15  out_degree_771  -1
    visit_0_15  in_degree_772  -1
    visit_0_15  order_active_lb_773  -1
    visit_0_15  order_active_ub_774  -13
    visit_0_15  service_visit_def_775  -1
    order_0_15  connected_order_arc_411  1
    order_0_15  connected_order_arc_436  1
    order_0_15  connected_order_arc_461  1
    order_0_15  connected_order_arc_486  1
    order_0_15  connected_order_arc_511  1
    order_0_15  connected_order_arc_536  1
    order_0_15  connected_order_arc_561  1
    order_0_15  connected_order_arc_574  -1
    order_0_15  connected_order_arc_576  -1
    order_0_15  connected_order_arc_578  -1
    order_0_15  connected_order_arc_580  -1
    order_0_15  connected_order_arc_582  -1
    order_0_15  connected_order_arc_584  -1
    order_0_15  connected_order_arc_586  -1
    order_0_15  connected_order_arc_588  -1
    order_0_15  connected_order_arc_590  -1
    order_0_15  connected_order_arc_592  -1
    order_0_15  connected_order_arc_594  -1
    order_0_15  connected_order_arc_596  -1
    order_0_15  connected_order_arc_613  1
    order_0_15  connected_order_arc_638  1
    order_0_15  connected_order_arc_663  1
    order_0_15  connected_order_arc_688  1
    order_0_15  connected_order_arc_713  1
    order_0_15  order_active_lb_773  1
    order_0_15  order_active_ub_774  1
    visit_0_16  out_degree_777  -1
    visit_0_16  in_degree_778  -1
    visit_0_16  order_active_lb_779  -1
    visit_0_16  order_active_ub_780  -13
    visit_0_16  service_visit_def_781  -1
    order_0_16  connected_order_arc_413  1
    order_0_16  connected_order_arc_438  1
    order_0_16  connected_order_arc_463  1
    order_0_16  connected_order_arc_488  1
    order_0_16  connected_order_arc_513  1
    order_0_16  connected_order_arc_538  1
    order_0_16  connected_order_arc_563  1
    order_0_16  connected_order_arc_588  1
    order_0_16  connected_order_arc_599  -1
    order_0_16  connected_order_arc_601  -1
    order_0_16  connected_order_arc_603  -1
    order_0_16  connected_order_arc_605  -1
    order_0_16  connected_order_arc_607  -1
    order_0_16  connected_order_arc_609  -1
    order_0_16  connected_order_arc_611  -1
    order_0_16  connected_order_arc_613  -1
    order_0_16  connected_order_arc_615  -1
    order_0_16  connected_order_arc_617  -1
    order_0_16  connected_order_arc_619  -1
    order_0_16  connected_order_arc_621  -1
    order_0_16  connected_order_arc_640  1
    order_0_16  connected_order_arc_665  1
    order_0_16  connected_order_arc_690  1
    order_0_16  connected_order_arc_715  1
    order_0_16  order_active_lb_779  1
    order_0_16  order_active_ub_780  1
    visit_0_17  out_degree_783  -1
    visit_0_17  in_degree_784  -1
    visit_0_17  order_active_lb_785  -1
    visit_0_17  order_active_ub_786  -13
    visit_0_17  service_visit_def_787  -1
    order_0_17  connected_order_arc_415  1
    order_0_17  connected_order_arc_440  1
    order_0_17  connected_order_arc_465  1
    order_0_17  connected_order_arc_490  1
    order_0_17  connected_order_arc_515  1
    order_0_17  connected_order_arc_540  1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_590  1
    order_0_17  connected_order_arc_615  1
    order_0_17  connected_order_arc_624  -1
    order_0_17  connected_order_arc_626  -1
    order_0_17  connected_order_arc_628  -1
    order_0_17  connected_order_arc_630  -1
    order_0_17  connected_order_arc_632  -1
    order_0_17  connected_order_arc_634  -1
    order_0_17  connected_order_arc_636  -1
    order_0_17  connected_order_arc_638  -1
    order_0_17  connected_order_arc_640  -1
    order_0_17  connected_order_arc_642  -1
    order_0_17  connected_order_arc_644  -1
    order_0_17  connected_order_arc_646  -1
    order_0_17  connected_order_arc_667  1
    order_0_17  connected_order_arc_692  1
    order_0_17  connected_order_arc_717  1
    order_0_17  order_active_lb_785  1
    order_0_17  order_active_ub_786  1
    visit_0_18  out_degree_789  -1
    visit_0_18  in_degree_790  -1
    visit_0_18  order_active_lb_791  -1
    visit_0_18  order_active_ub_792  -13
    visit_0_18  service_visit_def_793  -1
    order_0_18  connected_order_arc_417  1
    order_0_18  connected_order_arc_442  1
    order_0_18  connected_order_arc_467  1
    order_0_18  connected_order_arc_492  1
    order_0_18  connected_order_arc_517  1
    order_0_18  connected_order_arc_542  1
    order_0_18  connected_order_arc_567  1
    order_0_18  connected_order_arc_592  1
    order_0_18  connected_order_arc_617  1
    order_0_18  connected_order_arc_642  1
    order_0_18  connected_order_arc_649  -1
    order_0_18  connected_order_arc_651  -1
    order_0_18  connected_order_arc_653  -1
    order_0_18  connected_order_arc_655  -1
    order_0_18  connected_order_arc_657  -1
    order_0_18  connected_order_arc_659  -1
    order_0_18  connected_order_arc_661  -1
    order_0_18  connected_order_arc_663  -1
    order_0_18  connected_order_arc_665  -1
    order_0_18  connected_order_arc_667  -1
    order_0_18  connected_order_arc_669  -1
    order_0_18  connected_order_arc_671  -1
    order_0_18  connected_order_arc_694  1
    order_0_18  connected_order_arc_719  1
    order_0_18  order_active_lb_791  1
    order_0_18  order_active_ub_792  1
    visit_0_19  out_degree_795  -1
    visit_0_19  in_degree_796  -1
    visit_0_19  order_active_lb_797  -1
    visit_0_19  order_active_ub_798  -13
    visit_0_19  service_visit_def_799  -1
    order_0_19  connected_order_arc_419  1
    order_0_19  connected_order_arc_444  1
    order_0_19  connected_order_arc_469  1
    order_0_19  connected_order_arc_494  1
    order_0_19  connected_order_arc_519  1
    order_0_19  connected_order_arc_544  1
    order_0_19  connected_order_arc_569  1
    order_0_19  connected_order_arc_594  1
    order_0_19  connected_order_arc_619  1
    order_0_19  connected_order_arc_644  1
    order_0_19  connected_order_arc_669  1
    order_0_19  connected_order_arc_674  -1
    order_0_19  connected_order_arc_676  -1
    order_0_19  connected_order_arc_678  -1
    order_0_19  connected_order_arc_680  -1
    order_0_19  connected_order_arc_682  -1
    order_0_19  connected_order_arc_684  -1
    order_0_19  connected_order_arc_686  -1
    order_0_19  connected_order_arc_688  -1
    order_0_19  connected_order_arc_690  -1
    order_0_19  connected_order_arc_692  -1
    order_0_19  connected_order_arc_694  -1
    order_0_19  connected_order_arc_696  -1
    order_0_19  connected_order_arc_721  1
    order_0_19  order_active_lb_797  1
    order_0_19  order_active_ub_798  1
    visit_0_20  out_degree_801  -1
    visit_0_20  in_degree_802  -1
    visit_0_20  order_active_lb_803  -1
    visit_0_20  order_active_ub_804  -13
    visit_0_20  service_visit_def_805  -1
    order_0_20  connected_order_arc_421  1
    order_0_20  connected_order_arc_446  1
    order_0_20  connected_order_arc_471  1
    order_0_20  connected_order_arc_496  1
    order_0_20  connected_order_arc_521  1
    order_0_20  connected_order_arc_546  1
    order_0_20  connected_order_arc_571  1
    order_0_20  connected_order_arc_596  1
    order_0_20  connected_order_arc_621  1
    order_0_20  connected_order_arc_646  1
    order_0_20  connected_order_arc_671  1
    order_0_20  connected_order_arc_696  1
    order_0_20  connected_order_arc_699  -1
    order_0_20  connected_order_arc_701  -1
    order_0_20  connected_order_arc_703  -1
    order_0_20  connected_order_arc_705  -1
    order_0_20  connected_order_arc_707  -1
    order_0_20  connected_order_arc_709  -1
    order_0_20  connected_order_arc_711  -1
    order_0_20  connected_order_arc_713  -1
    order_0_20  connected_order_arc_715  -1
    order_0_20  connected_order_arc_717  -1
    order_0_20  connected_order_arc_719  -1
    order_0_20  connected_order_arc_721  -1
    order_0_20  order_active_lb_803  1
    order_0_20  order_active_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_383  -20
    arc_0_0_0  depot_departure_or_bypass_722  1
    arc_0_0_0  depot_return_or_bypass_723  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_383  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_384  -20
    arc_0_0_1  depot_departure_or_bypass_722  1
    arc_0_0_1  in_degree_725  1
    arc_0_0_1  original_T_including_depot_unload_811  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_384  1
    load_0_0_1  segment_load_conservation_728  -1
    load_0_0_1  segment_prefix_lb_729  1
    load_0_0_1  segment_prefix_ub_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_385  -20
    arc_0_0_2  depot_departure_or_bypass_722  1
    arc_0_0_2  in_degree_732  1
    arc_0_0_2  original_T_including_depot_unload_811  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_385  1
    load_0_0_2  segment_load_conservation_735  -1
    load_0_0_2  segment_prefix_lb_736  1
    load_0_0_2  segment_prefix_ub_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_386  -20
    arc_0_0_3  depot_departure_or_bypass_722  1
    arc_0_0_3  in_degree_739  1
    arc_0_0_3  original_T_including_depot_unload_811  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_386  1
    load_0_0_3  segment_load_conservation_742  -1
    load_0_0_3  segment_prefix_lb_743  1
    load_0_0_3  segment_prefix_ub_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_387  -20
    arc_0_0_4  depot_departure_or_bypass_722  1
    arc_0_0_4  in_degree_746  1
    arc_0_0_4  original_T_including_depot_unload_811  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_387  1
    load_0_0_4  segment_load_conservation_749  -1
    load_0_0_4  segment_prefix_lb_750  1
    load_0_0_4  segment_prefix_ub_751  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_388  -20
    arc_0_0_5  depot_departure_or_bypass_722  1
    arc_0_0_5  in_degree_753  1
    arc_0_0_5  original_T_including_depot_unload_811  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_388  1
    load_0_0_5  segment_load_conservation_756  -1
    load_0_0_5  segment_prefix_lb_757  1
    load_0_0_5  segment_prefix_ub_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_389  -20
    arc_0_0_13  depot_departure_or_bypass_722  1
    arc_0_0_13  in_degree_760  1
    arc_0_0_13  original_T_including_depot_unload_811  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_389  1
    load_0_0_13  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_390  -20
    arc_0_0_14  depot_departure_or_bypass_722  1
    arc_0_0_14  in_degree_766  1
    arc_0_0_14  original_T_including_depot_unload_811  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_390  1
    load_0_0_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_391  -20
    arc_0_0_15  depot_departure_or_bypass_722  1
    arc_0_0_15  in_degree_772  1
    arc_0_0_15  original_T_including_depot_unload_811  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_391  1
    load_0_0_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_392  -20
    arc_0_0_16  depot_departure_or_bypass_722  1
    arc_0_0_16  in_degree_778  1
    arc_0_0_16  original_T_including_depot_unload_811  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_392  1
    load_0_0_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_393  -20
    arc_0_0_17  depot_departure_or_bypass_722  1
    arc_0_0_17  in_degree_784  1
    arc_0_0_17  original_T_including_depot_unload_811  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_393  1
    load_0_0_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_394  -20
    arc_0_0_18  depot_departure_or_bypass_722  1
    arc_0_0_18  in_degree_790  1
    arc_0_0_18  original_T_including_depot_unload_811  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_394  1
    load_0_0_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_395  -20
    arc_0_0_19  depot_departure_or_bypass_722  1
    arc_0_0_19  in_degree_796  1
    arc_0_0_19  original_T_including_depot_unload_811  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_395  1
    load_0_0_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_396  -20
    arc_0_0_20  depot_departure_or_bypass_722  1
    arc_0_0_20  in_degree_802  1
    arc_0_0_20  original_T_including_depot_unload_811  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_396  1
    load_0_0_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_397  -20
    arc_0_1_0  depot_return_or_bypass_723  1
    arc_0_1_0  out_degree_724  1
    arc_0_1_0  original_T_including_depot_unload_811  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_397  1
    load_0_1_0  segment_load_conservation_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_398  -20
    arc_0_1_2  connected_order_arc_399  -14
    arc_0_1_2  out_degree_724  1
    arc_0_1_2  in_degree_732  1
    arc_0_1_2  original_T_including_depot_unload_811  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_398  1
    load_0_1_2  segment_load_conservation_728  1
    load_0_1_2  segment_load_conservation_735  -1
    load_0_1_2  segment_prefix_lb_736  1
    load_0_1_2  segment_prefix_ub_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_400  -20
    arc_0_1_3  connected_order_arc_401  -14
    arc_0_1_3  out_degree_724  1
    arc_0_1_3  in_degree_739  1
    arc_0_1_3  original_T_including_depot_unload_811  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_400  1
    load_0_1_3  segment_load_conservation_728  1
    load_0_1_3  segment_load_conservation_742  -1
    load_0_1_3  segment_prefix_lb_743  1
    load_0_1_3  segment_prefix_ub_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_402  -20
    arc_0_1_4  connected_order_arc_403  -14
    arc_0_1_4  out_degree_724  1
    arc_0_1_4  in_degree_746  1
    arc_0_1_4  original_T_including_depot_unload_811  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_402  1
    load_0_1_4  segment_load_conservation_728  1
    load_0_1_4  segment_load_conservation_749  -1
    load_0_1_4  segment_prefix_lb_750  1
    load_0_1_4  segment_prefix_ub_751  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_404  -20
    arc_0_1_5  connected_order_arc_405  -14
    arc_0_1_5  out_degree_724  1
    arc_0_1_5  in_degree_753  1
    arc_0_1_5  original_T_including_depot_unload_811  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_404  1
    load_0_1_5  segment_load_conservation_728  1
    load_0_1_5  segment_load_conservation_756  -1
    load_0_1_5  segment_prefix_lb_757  1
    load_0_1_5  segment_prefix_ub_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_406  -20
    arc_0_1_13  connected_order_arc_407  -14
    arc_0_1_13  out_degree_724  1
    arc_0_1_13  in_degree_760  1
    arc_0_1_13  original_T_including_depot_unload_811  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_406  1
    load_0_1_13  segment_load_conservation_728  1
    load_0_1_13  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_408  -20
    arc_0_1_14  connected_order_arc_409  -14
    arc_0_1_14  out_degree_724  1
    arc_0_1_14  in_degree_766  1
    arc_0_1_14  original_T_including_depot_unload_811  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_408  1
    load_0_1_14  segment_load_conservation_728  1
    load_0_1_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_410  -20
    arc_0_1_15  connected_order_arc_411  -14
    arc_0_1_15  out_degree_724  1
    arc_0_1_15  in_degree_772  1
    arc_0_1_15  original_T_including_depot_unload_811  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_410  1
    load_0_1_15  segment_load_conservation_728  1
    load_0_1_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_412  -20
    arc_0_1_16  connected_order_arc_413  -14
    arc_0_1_16  out_degree_724  1
    arc_0_1_16  in_degree_778  1
    arc_0_1_16  original_T_including_depot_unload_811  8.9144012844276767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_412  1
    load_0_1_16  segment_load_conservation_728  1
    load_0_1_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_414  -20
    arc_0_1_17  connected_order_arc_415  -14
    arc_0_1_17  out_degree_724  1
    arc_0_1_17  in_degree_784  1
    arc_0_1_17  original_T_including_depot_unload_811  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_414  1
    load_0_1_17  segment_load_conservation_728  1
    load_0_1_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_416  -20
    arc_0_1_18  connected_order_arc_417  -14
    arc_0_1_18  out_degree_724  1
    arc_0_1_18  in_degree_790  1
    arc_0_1_18  original_T_including_depot_unload_811  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_416  1
    load_0_1_18  segment_load_conservation_728  1
    load_0_1_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_418  -20
    arc_0_1_19  connected_order_arc_419  -14
    arc_0_1_19  out_degree_724  1
    arc_0_1_19  in_degree_796  1
    arc_0_1_19  original_T_including_depot_unload_811  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_418  1
    load_0_1_19  segment_load_conservation_728  1
    load_0_1_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_420  -20
    arc_0_1_20  connected_order_arc_421  -14
    arc_0_1_20  out_degree_724  1
    arc_0_1_20  in_degree_802  1
    arc_0_1_20  original_T_including_depot_unload_811  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_420  1
    load_0_1_20  segment_load_conservation_728  1
    load_0_1_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_422  -20
    arc_0_2_0  depot_return_or_bypass_723  1
    arc_0_2_0  out_degree_731  1
    arc_0_2_0  original_T_including_depot_unload_811  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_422  1
    load_0_2_0  segment_load_conservation_735  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_423  -20
    arc_0_2_1  connected_order_arc_424  -14
    arc_0_2_1  in_degree_725  1
    arc_0_2_1  out_degree_731  1
    arc_0_2_1  original_T_including_depot_unload_811  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_423  1
    load_0_2_1  segment_load_conservation_728  -1
    load_0_2_1  segment_prefix_lb_729  1
    load_0_2_1  segment_prefix_ub_730  1
    load_0_2_1  segment_load_conservation_735  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_425  -20
    arc_0_2_3  connected_order_arc_426  -14
    arc_0_2_3  out_degree_731  1
    arc_0_2_3  in_degree_739  1
    arc_0_2_3  original_T_including_depot_unload_811  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_425  1
    load_0_2_3  segment_load_conservation_735  1
    load_0_2_3  segment_load_conservation_742  -1
    load_0_2_3  segment_prefix_lb_743  1
    load_0_2_3  segment_prefix_ub_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_427  -20
    arc_0_2_4  connected_order_arc_428  -14
    arc_0_2_4  out_degree_731  1
    arc_0_2_4  in_degree_746  1
    arc_0_2_4  original_T_including_depot_unload_811  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_427  1
    load_0_2_4  segment_load_conservation_735  1
    load_0_2_4  segment_load_conservation_749  -1
    load_0_2_4  segment_prefix_lb_750  1
    load_0_2_4  segment_prefix_ub_751  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_429  -20
    arc_0_2_5  connected_order_arc_430  -14
    arc_0_2_5  out_degree_731  1
    arc_0_2_5  in_degree_753  1
    arc_0_2_5  original_T_including_depot_unload_811  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_429  1
    load_0_2_5  segment_load_conservation_735  1
    load_0_2_5  segment_load_conservation_756  -1
    load_0_2_5  segment_prefix_lb_757  1
    load_0_2_5  segment_prefix_ub_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_431  -20
    arc_0_2_13  connected_order_arc_432  -14
    arc_0_2_13  out_degree_731  1
    arc_0_2_13  in_degree_760  1
    arc_0_2_13  original_T_including_depot_unload_811  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_431  1
    load_0_2_13  segment_load_conservation_735  1
    load_0_2_13  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_433  -20
    arc_0_2_14  connected_order_arc_434  -14
    arc_0_2_14  out_degree_731  1
    arc_0_2_14  in_degree_766  1
    arc_0_2_14  original_T_including_depot_unload_811  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_433  1
    load_0_2_14  segment_load_conservation_735  1
    load_0_2_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_435  -20
    arc_0_2_15  connected_order_arc_436  -14
    arc_0_2_15  out_degree_731  1
    arc_0_2_15  in_degree_772  1
    arc_0_2_15  original_T_including_depot_unload_811  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_435  1
    load_0_2_15  segment_load_conservation_735  1
    load_0_2_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_437  -20
    arc_0_2_16  connected_order_arc_438  -14
    arc_0_2_16  out_degree_731  1
    arc_0_2_16  in_degree_778  1
    arc_0_2_16  original_T_including_depot_unload_811  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_437  1
    load_0_2_16  segment_load_conservation_735  1
    load_0_2_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_439  -20
    arc_0_2_17  connected_order_arc_440  -14
    arc_0_2_17  out_degree_731  1
    arc_0_2_17  in_degree_784  1
    arc_0_2_17  original_T_including_depot_unload_811  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_439  1
    load_0_2_17  segment_load_conservation_735  1
    load_0_2_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_441  -20
    arc_0_2_18  connected_order_arc_442  -14
    arc_0_2_18  out_degree_731  1
    arc_0_2_18  in_degree_790  1
    arc_0_2_18  original_T_including_depot_unload_811  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_441  1
    load_0_2_18  segment_load_conservation_735  1
    load_0_2_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_443  -20
    arc_0_2_19  connected_order_arc_444  -14
    arc_0_2_19  out_degree_731  1
    arc_0_2_19  in_degree_796  1
    arc_0_2_19  original_T_including_depot_unload_811  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_443  1
    load_0_2_19  segment_load_conservation_735  1
    load_0_2_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_445  -20
    arc_0_2_20  connected_order_arc_446  -14
    arc_0_2_20  out_degree_731  1
    arc_0_2_20  in_degree_802  1
    arc_0_2_20  original_T_including_depot_unload_811  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_445  1
    load_0_2_20  segment_load_conservation_735  1
    load_0_2_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_447  -20
    arc_0_3_0  depot_return_or_bypass_723  1
    arc_0_3_0  out_degree_738  1
    arc_0_3_0  original_T_including_depot_unload_811  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_447  1
    load_0_3_0  segment_load_conservation_742  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_448  -20
    arc_0_3_1  connected_order_arc_449  -14
    arc_0_3_1  in_degree_725  1
    arc_0_3_1  out_degree_738  1
    arc_0_3_1  original_T_including_depot_unload_811  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_448  1
    load_0_3_1  segment_load_conservation_728  -1
    load_0_3_1  segment_prefix_lb_729  1
    load_0_3_1  segment_prefix_ub_730  1
    load_0_3_1  segment_load_conservation_742  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_450  -20
    arc_0_3_2  connected_order_arc_451  -14
    arc_0_3_2  in_degree_732  1
    arc_0_3_2  out_degree_738  1
    arc_0_3_2  original_T_including_depot_unload_811  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_450  1
    load_0_3_2  segment_load_conservation_735  -1
    load_0_3_2  segment_prefix_lb_736  1
    load_0_3_2  segment_prefix_ub_737  1
    load_0_3_2  segment_load_conservation_742  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_452  -20
    arc_0_3_4  connected_order_arc_453  -14
    arc_0_3_4  out_degree_738  1
    arc_0_3_4  in_degree_746  1
    arc_0_3_4  original_T_including_depot_unload_811  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_452  1
    load_0_3_4  segment_load_conservation_742  1
    load_0_3_4  segment_load_conservation_749  -1
    load_0_3_4  segment_prefix_lb_750  1
    load_0_3_4  segment_prefix_ub_751  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_454  -20
    arc_0_3_5  connected_order_arc_455  -14
    arc_0_3_5  out_degree_738  1
    arc_0_3_5  in_degree_753  1
    arc_0_3_5  original_T_including_depot_unload_811  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_454  1
    load_0_3_5  segment_load_conservation_742  1
    load_0_3_5  segment_load_conservation_756  -1
    load_0_3_5  segment_prefix_lb_757  1
    load_0_3_5  segment_prefix_ub_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_456  -20
    arc_0_3_13  connected_order_arc_457  -14
    arc_0_3_13  out_degree_738  1
    arc_0_3_13  in_degree_760  1
    arc_0_3_13  original_T_including_depot_unload_811  1.3593311700505531e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_456  1
    load_0_3_13  segment_load_conservation_742  1
    load_0_3_13  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_458  -20
    arc_0_3_14  connected_order_arc_459  -14
    arc_0_3_14  out_degree_738  1
    arc_0_3_14  in_degree_766  1
    arc_0_3_14  original_T_including_depot_unload_811  1.4586590520122220e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_458  1
    load_0_3_14  segment_load_conservation_742  1
    load_0_3_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_460  -20
    arc_0_3_15  connected_order_arc_461  -14
    arc_0_3_15  out_degree_738  1
    arc_0_3_15  in_degree_772  1
    arc_0_3_15  original_T_including_depot_unload_811  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_460  1
    load_0_3_15  segment_load_conservation_742  1
    load_0_3_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_462  -20
    arc_0_3_16  connected_order_arc_463  -14
    arc_0_3_16  out_degree_738  1
    arc_0_3_16  in_degree_778  1
    arc_0_3_16  original_T_including_depot_unload_811  1.5632412652410792e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_462  1
    load_0_3_16  segment_load_conservation_742  1
    load_0_3_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_464  -20
    arc_0_3_17  connected_order_arc_465  -14
    arc_0_3_17  out_degree_738  1
    arc_0_3_17  in_degree_784  1
    arc_0_3_17  original_T_including_depot_unload_811  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_464  1
    load_0_3_17  segment_load_conservation_742  1
    load_0_3_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_466  -20
    arc_0_3_18  connected_order_arc_467  -14
    arc_0_3_18  out_degree_738  1
    arc_0_3_18  in_degree_790  1
    arc_0_3_18  original_T_including_depot_unload_811  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_466  1
    load_0_3_18  segment_load_conservation_742  1
    load_0_3_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_468  -20
    arc_0_3_19  connected_order_arc_469  -14
    arc_0_3_19  out_degree_738  1
    arc_0_3_19  in_degree_796  1
    arc_0_3_19  original_T_including_depot_unload_811  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_468  1
    load_0_3_19  segment_load_conservation_742  1
    load_0_3_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_470  -20
    arc_0_3_20  connected_order_arc_471  -14
    arc_0_3_20  out_degree_738  1
    arc_0_3_20  in_degree_802  1
    arc_0_3_20  original_T_including_depot_unload_811  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_470  1
    load_0_3_20  segment_load_conservation_742  1
    load_0_3_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_472  -20
    arc_0_4_0  depot_return_or_bypass_723  1
    arc_0_4_0  out_degree_745  1
    arc_0_4_0  original_T_including_depot_unload_811  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_472  1
    load_0_4_0  segment_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_473  -20
    arc_0_4_1  connected_order_arc_474  -14
    arc_0_4_1  in_degree_725  1
    arc_0_4_1  out_degree_745  1
    arc_0_4_1  original_T_including_depot_unload_811  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_473  1
    load_0_4_1  segment_load_conservation_728  -1
    load_0_4_1  segment_prefix_lb_729  1
    load_0_4_1  segment_prefix_ub_730  1
    load_0_4_1  segment_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_475  -20
    arc_0_4_2  connected_order_arc_476  -14
    arc_0_4_2  in_degree_732  1
    arc_0_4_2  out_degree_745  1
    arc_0_4_2  original_T_including_depot_unload_811  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_475  1
    load_0_4_2  segment_load_conservation_735  -1
    load_0_4_2  segment_prefix_lb_736  1
    load_0_4_2  segment_prefix_ub_737  1
    load_0_4_2  segment_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_477  -20
    arc_0_4_3  connected_order_arc_478  -14
    arc_0_4_3  in_degree_739  1
    arc_0_4_3  out_degree_745  1
    arc_0_4_3  original_T_including_depot_unload_811  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_477  1
    load_0_4_3  segment_load_conservation_742  -1
    load_0_4_3  segment_prefix_lb_743  1
    load_0_4_3  segment_prefix_ub_744  1
    load_0_4_3  segment_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_479  -20
    arc_0_4_5  connected_order_arc_480  -14
    arc_0_4_5  out_degree_745  1
    arc_0_4_5  in_degree_753  1
    arc_0_4_5  original_T_including_depot_unload_811  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_479  1
    load_0_4_5  segment_load_conservation_749  1
    load_0_4_5  segment_load_conservation_756  -1
    load_0_4_5  segment_prefix_lb_757  1
    load_0_4_5  segment_prefix_ub_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_481  -20
    arc_0_4_13  connected_order_arc_482  -14
    arc_0_4_13  out_degree_745  1
    arc_0_4_13  in_degree_760  1
    arc_0_4_13  original_T_including_depot_unload_811  1.5070416710648517e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_481  1
    load_0_4_13  segment_load_conservation_749  1
    load_0_4_13  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_483  -20
    arc_0_4_14  connected_order_arc_484  -14
    arc_0_4_14  out_degree_745  1
    arc_0_4_14  in_degree_766  1
    arc_0_4_14  original_T_including_depot_unload_811  1.6110158249463705e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_483  1
    load_0_4_14  segment_load_conservation_749  1
    load_0_4_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_485  -20
    arc_0_4_15  connected_order_arc_486  -14
    arc_0_4_15  out_degree_745  1
    arc_0_4_15  in_degree_772  1
    arc_0_4_15  original_T_including_depot_unload_811  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_485  1
    load_0_4_15  segment_load_conservation_749  1
    load_0_4_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_487  -20
    arc_0_4_16  connected_order_arc_488  -14
    arc_0_4_16  out_degree_745  1
    arc_0_4_16  in_degree_778  1
    arc_0_4_16  original_T_including_depot_unload_811  1.7131647154143354e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_487  1
    load_0_4_16  segment_load_conservation_749  1
    load_0_4_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_489  -20
    arc_0_4_17  connected_order_arc_490  -14
    arc_0_4_17  out_degree_745  1
    arc_0_4_17  in_degree_784  1
    arc_0_4_17  original_T_including_depot_unload_811  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_489  1
    load_0_4_17  segment_load_conservation_749  1
    load_0_4_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_491  -20
    arc_0_4_18  connected_order_arc_492  -14
    arc_0_4_18  out_degree_745  1
    arc_0_4_18  in_degree_790  1
    arc_0_4_18  original_T_including_depot_unload_811  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_491  1
    load_0_4_18  segment_load_conservation_749  1
    load_0_4_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_493  -20
    arc_0_4_19  connected_order_arc_494  -14
    arc_0_4_19  out_degree_745  1
    arc_0_4_19  in_degree_796  1
    arc_0_4_19  original_T_including_depot_unload_811  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_493  1
    load_0_4_19  segment_load_conservation_749  1
    load_0_4_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_495  -20
    arc_0_4_20  connected_order_arc_496  -14
    arc_0_4_20  out_degree_745  1
    arc_0_4_20  in_degree_802  1
    arc_0_4_20  original_T_including_depot_unload_811  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_495  1
    load_0_4_20  segment_load_conservation_749  1
    load_0_4_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_497  -20
    arc_0_5_0  depot_return_or_bypass_723  1
    arc_0_5_0  out_degree_752  1
    arc_0_5_0  original_T_including_depot_unload_811  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_497  1
    load_0_5_0  segment_load_conservation_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_498  -20
    arc_0_5_1  connected_order_arc_499  -14
    arc_0_5_1  in_degree_725  1
    arc_0_5_1  out_degree_752  1
    arc_0_5_1  original_T_including_depot_unload_811  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_498  1
    load_0_5_1  segment_load_conservation_728  -1
    load_0_5_1  segment_prefix_lb_729  1
    load_0_5_1  segment_prefix_ub_730  1
    load_0_5_1  segment_load_conservation_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_500  -20
    arc_0_5_2  connected_order_arc_501  -14
    arc_0_5_2  in_degree_732  1
    arc_0_5_2  out_degree_752  1
    arc_0_5_2  original_T_including_depot_unload_811  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_500  1
    load_0_5_2  segment_load_conservation_735  -1
    load_0_5_2  segment_prefix_lb_736  1
    load_0_5_2  segment_prefix_ub_737  1
    load_0_5_2  segment_load_conservation_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_502  -20
    arc_0_5_3  connected_order_arc_503  -14
    arc_0_5_3  in_degree_739  1
    arc_0_5_3  out_degree_752  1
    arc_0_5_3  original_T_including_depot_unload_811  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_502  1
    load_0_5_3  segment_load_conservation_742  -1
    load_0_5_3  segment_prefix_lb_743  1
    load_0_5_3  segment_prefix_ub_744  1
    load_0_5_3  segment_load_conservation_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_504  -20
    arc_0_5_4  connected_order_arc_505  -14
    arc_0_5_4  in_degree_746  1
    arc_0_5_4  out_degree_752  1
    arc_0_5_4  original_T_including_depot_unload_811  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_504  1
    load_0_5_4  segment_load_conservation_749  -1
    load_0_5_4  segment_prefix_lb_750  1
    load_0_5_4  segment_prefix_ub_751  1
    load_0_5_4  segment_load_conservation_756  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_506  -20
    arc_0_5_13  connected_order_arc_507  -14
    arc_0_5_13  out_degree_752  1
    arc_0_5_13  in_degree_760  1
    arc_0_5_13  original_T_including_depot_unload_811  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_506  1
    load_0_5_13  segment_load_conservation_756  1
    load_0_5_13  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_508  -20
    arc_0_5_14  connected_order_arc_509  -14
    arc_0_5_14  out_degree_752  1
    arc_0_5_14  in_degree_766  1
    arc_0_5_14  original_T_including_depot_unload_811  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_508  1
    load_0_5_14  segment_load_conservation_756  1
    load_0_5_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_510  -20
    arc_0_5_15  connected_order_arc_511  -14
    arc_0_5_15  out_degree_752  1
    arc_0_5_15  in_degree_772  1
    arc_0_5_15  original_T_including_depot_unload_811  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_510  1
    load_0_5_15  segment_load_conservation_756  1
    load_0_5_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_512  -20
    arc_0_5_16  connected_order_arc_513  -14
    arc_0_5_16  out_degree_752  1
    arc_0_5_16  in_degree_778  1
    arc_0_5_16  original_T_including_depot_unload_811  1.4462606207080505e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_512  1
    load_0_5_16  segment_load_conservation_756  1
    load_0_5_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_514  -20
    arc_0_5_17  connected_order_arc_515  -14
    arc_0_5_17  out_degree_752  1
    arc_0_5_17  in_degree_784  1
    arc_0_5_17  original_T_including_depot_unload_811  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_514  1
    load_0_5_17  segment_load_conservation_756  1
    load_0_5_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_516  -20
    arc_0_5_18  connected_order_arc_517  -14
    arc_0_5_18  out_degree_752  1
    arc_0_5_18  in_degree_790  1
    arc_0_5_18  original_T_including_depot_unload_811  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_516  1
    load_0_5_18  segment_load_conservation_756  1
    load_0_5_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_518  -20
    arc_0_5_19  connected_order_arc_519  -14
    arc_0_5_19  out_degree_752  1
    arc_0_5_19  in_degree_796  1
    arc_0_5_19  original_T_including_depot_unload_811  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_518  1
    load_0_5_19  segment_load_conservation_756  1
    load_0_5_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_520  -20
    arc_0_5_20  connected_order_arc_521  -14
    arc_0_5_20  out_degree_752  1
    arc_0_5_20  in_degree_802  1
    arc_0_5_20  original_T_including_depot_unload_811  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_520  1
    load_0_5_20  segment_load_conservation_756  1
    load_0_5_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_522  -20
    arc_0_13_0  depot_return_or_bypass_723  1
    arc_0_13_0  out_degree_759  1
    arc_0_13_0  original_T_including_depot_unload_811  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_522  1
    load_0_13_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_523  -20
    arc_0_13_1  connected_order_arc_524  -14
    arc_0_13_1  in_degree_725  1
    arc_0_13_1  out_degree_759  1
    arc_0_13_1  original_T_including_depot_unload_811  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_523  1
    load_0_13_1  segment_load_conservation_728  -1
    load_0_13_1  segment_prefix_lb_729  1
    load_0_13_1  segment_prefix_ub_730  1
    load_0_13_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_525  -20
    arc_0_13_2  connected_order_arc_526  -14
    arc_0_13_2  in_degree_732  1
    arc_0_13_2  out_degree_759  1
    arc_0_13_2  original_T_including_depot_unload_811  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_525  1
    load_0_13_2  segment_load_conservation_735  -1
    load_0_13_2  segment_prefix_lb_736  1
    load_0_13_2  segment_prefix_ub_737  1
    load_0_13_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_527  -20
    arc_0_13_3  connected_order_arc_528  -14
    arc_0_13_3  in_degree_739  1
    arc_0_13_3  out_degree_759  1
    arc_0_13_3  original_T_including_depot_unload_811  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_527  1
    load_0_13_3  segment_load_conservation_742  -1
    load_0_13_3  segment_prefix_lb_743  1
    load_0_13_3  segment_prefix_ub_744  1
    load_0_13_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_529  -20
    arc_0_13_4  connected_order_arc_530  -14
    arc_0_13_4  in_degree_746  1
    arc_0_13_4  out_degree_759  1
    arc_0_13_4  original_T_including_depot_unload_811  1.5070416710648517e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_529  1
    load_0_13_4  segment_load_conservation_749  -1
    load_0_13_4  segment_prefix_lb_750  1
    load_0_13_4  segment_prefix_ub_751  1
    load_0_13_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_531  -20
    arc_0_13_5  connected_order_arc_532  -14
    arc_0_13_5  in_degree_753  1
    arc_0_13_5  out_degree_759  1
    arc_0_13_5  original_T_including_depot_unload_811  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_531  1
    load_0_13_5  segment_load_conservation_756  -1
    load_0_13_5  segment_prefix_lb_757  1
    load_0_13_5  segment_prefix_ub_758  1
    load_0_13_5  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_533  -20
    arc_0_13_14  connected_order_arc_534  -14
    arc_0_13_14  out_degree_759  1
    arc_0_13_14  in_degree_766  1
    arc_0_13_14  original_T_including_depot_unload_811  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_533  1
    load_0_13_14  free_load_conservation_764  1
    load_0_13_14  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_535  -20
    arc_0_13_15  connected_order_arc_536  -14
    arc_0_13_15  out_degree_759  1
    arc_0_13_15  in_degree_772  1
    arc_0_13_15  original_T_including_depot_unload_811  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_535  1
    load_0_13_15  free_load_conservation_764  1
    load_0_13_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_537  -20
    arc_0_13_16  connected_order_arc_538  -14
    arc_0_13_16  out_degree_759  1
    arc_0_13_16  in_degree_778  1
    arc_0_13_16  original_T_including_depot_unload_811  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_537  1
    load_0_13_16  free_load_conservation_764  1
    load_0_13_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_539  -20
    arc_0_13_17  connected_order_arc_540  -14
    arc_0_13_17  out_degree_759  1
    arc_0_13_17  in_degree_784  1
    arc_0_13_17  original_T_including_depot_unload_811  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_539  1
    load_0_13_17  free_load_conservation_764  1
    load_0_13_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_541  -20
    arc_0_13_18  connected_order_arc_542  -14
    arc_0_13_18  out_degree_759  1
    arc_0_13_18  in_degree_790  1
    arc_0_13_18  original_T_including_depot_unload_811  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_541  1
    load_0_13_18  free_load_conservation_764  1
    load_0_13_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_543  -20
    arc_0_13_19  connected_order_arc_544  -14
    arc_0_13_19  out_degree_759  1
    arc_0_13_19  in_degree_796  1
    arc_0_13_19  original_T_including_depot_unload_811  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_543  1
    load_0_13_19  free_load_conservation_764  1
    load_0_13_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_545  -20
    arc_0_13_20  connected_order_arc_546  -14
    arc_0_13_20  out_degree_759  1
    arc_0_13_20  in_degree_802  1
    arc_0_13_20  original_T_including_depot_unload_811  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_545  1
    load_0_13_20  free_load_conservation_764  1
    load_0_13_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_547  -20
    arc_0_14_0  depot_return_or_bypass_723  1
    arc_0_14_0  out_degree_765  1
    arc_0_14_0  original_T_including_depot_unload_811  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_547  1
    load_0_14_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_548  -20
    arc_0_14_1  connected_order_arc_549  -14
    arc_0_14_1  in_degree_725  1
    arc_0_14_1  out_degree_765  1
    arc_0_14_1  original_T_including_depot_unload_811  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_548  1
    load_0_14_1  segment_load_conservation_728  -1
    load_0_14_1  segment_prefix_lb_729  1
    load_0_14_1  segment_prefix_ub_730  1
    load_0_14_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_550  -20
    arc_0_14_2  connected_order_arc_551  -14
    arc_0_14_2  in_degree_732  1
    arc_0_14_2  out_degree_765  1
    arc_0_14_2  original_T_including_depot_unload_811  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_550  1
    load_0_14_2  segment_load_conservation_735  -1
    load_0_14_2  segment_prefix_lb_736  1
    load_0_14_2  segment_prefix_ub_737  1
    load_0_14_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_552  -20
    arc_0_14_3  connected_order_arc_553  -14
    arc_0_14_3  in_degree_739  1
    arc_0_14_3  out_degree_765  1
    arc_0_14_3  original_T_including_depot_unload_811  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_552  1
    load_0_14_3  segment_load_conservation_742  -1
    load_0_14_3  segment_prefix_lb_743  1
    load_0_14_3  segment_prefix_ub_744  1
    load_0_14_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_554  -20
    arc_0_14_4  connected_order_arc_555  -14
    arc_0_14_4  in_degree_746  1
    arc_0_14_4  out_degree_765  1
    arc_0_14_4  original_T_including_depot_unload_811  1.6110158249463705e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_554  1
    load_0_14_4  segment_load_conservation_749  -1
    load_0_14_4  segment_prefix_lb_750  1
    load_0_14_4  segment_prefix_ub_751  1
    load_0_14_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_556  -20
    arc_0_14_5  connected_order_arc_557  -14
    arc_0_14_5  in_degree_753  1
    arc_0_14_5  out_degree_765  1
    arc_0_14_5  original_T_including_depot_unload_811  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_556  1
    load_0_14_5  segment_load_conservation_756  -1
    load_0_14_5  segment_prefix_lb_757  1
    load_0_14_5  segment_prefix_ub_758  1
    load_0_14_5  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_558  -20
    arc_0_14_13  connected_order_arc_559  -14
    arc_0_14_13  in_degree_760  1
    arc_0_14_13  out_degree_765  1
    arc_0_14_13  original_T_including_depot_unload_811  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_558  1
    load_0_14_13  free_load_conservation_764  -1
    load_0_14_13  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_560  -20
    arc_0_14_15  connected_order_arc_561  -14
    arc_0_14_15  out_degree_765  1
    arc_0_14_15  in_degree_772  1
    arc_0_14_15  original_T_including_depot_unload_811  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_560  1
    load_0_14_15  free_load_conservation_770  1
    load_0_14_15  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_562  -20
    arc_0_14_16  connected_order_arc_563  -14
    arc_0_14_16  out_degree_765  1
    arc_0_14_16  in_degree_778  1
    arc_0_14_16  original_T_including_depot_unload_811  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_562  1
    load_0_14_16  free_load_conservation_770  1
    load_0_14_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_564  -20
    arc_0_14_17  connected_order_arc_565  -14
    arc_0_14_17  out_degree_765  1
    arc_0_14_17  in_degree_784  1
    arc_0_14_17  original_T_including_depot_unload_811  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_564  1
    load_0_14_17  free_load_conservation_770  1
    load_0_14_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_566  -20
    arc_0_14_18  connected_order_arc_567  -14
    arc_0_14_18  out_degree_765  1
    arc_0_14_18  in_degree_790  1
    arc_0_14_18  original_T_including_depot_unload_811  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_566  1
    load_0_14_18  free_load_conservation_770  1
    load_0_14_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_568  -20
    arc_0_14_19  connected_order_arc_569  -14
    arc_0_14_19  out_degree_765  1
    arc_0_14_19  in_degree_796  1
    arc_0_14_19  original_T_including_depot_unload_811  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_568  1
    load_0_14_19  free_load_conservation_770  1
    load_0_14_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_570  -20
    arc_0_14_20  connected_order_arc_571  -14
    arc_0_14_20  out_degree_765  1
    arc_0_14_20  in_degree_802  1
    arc_0_14_20  original_T_including_depot_unload_811  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_570  1
    load_0_14_20  free_load_conservation_770  1
    load_0_14_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_572  -20
    arc_0_15_0  depot_return_or_bypass_723  1
    arc_0_15_0  out_degree_771  1
    arc_0_15_0  original_T_including_depot_unload_811  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_572  1
    load_0_15_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_573  -20
    arc_0_15_1  connected_order_arc_574  -14
    arc_0_15_1  in_degree_725  1
    arc_0_15_1  out_degree_771  1
    arc_0_15_1  original_T_including_depot_unload_811  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_573  1
    load_0_15_1  segment_load_conservation_728  -1
    load_0_15_1  segment_prefix_lb_729  1
    load_0_15_1  segment_prefix_ub_730  1
    load_0_15_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_575  -20
    arc_0_15_2  connected_order_arc_576  -14
    arc_0_15_2  in_degree_732  1
    arc_0_15_2  out_degree_771  1
    arc_0_15_2  original_T_including_depot_unload_811  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_575  1
    load_0_15_2  segment_load_conservation_735  -1
    load_0_15_2  segment_prefix_lb_736  1
    load_0_15_2  segment_prefix_ub_737  1
    load_0_15_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_577  -20
    arc_0_15_3  connected_order_arc_578  -14
    arc_0_15_3  in_degree_739  1
    arc_0_15_3  out_degree_771  1
    arc_0_15_3  original_T_including_depot_unload_811  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_577  1
    load_0_15_3  segment_load_conservation_742  -1
    load_0_15_3  segment_prefix_lb_743  1
    load_0_15_3  segment_prefix_ub_744  1
    load_0_15_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_579  -20
    arc_0_15_4  connected_order_arc_580  -14
    arc_0_15_4  in_degree_746  1
    arc_0_15_4  out_degree_771  1
    arc_0_15_4  original_T_including_depot_unload_811  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_579  1
    load_0_15_4  segment_load_conservation_749  -1
    load_0_15_4  segment_prefix_lb_750  1
    load_0_15_4  segment_prefix_ub_751  1
    load_0_15_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_581  -20
    arc_0_15_5  connected_order_arc_582  -14
    arc_0_15_5  in_degree_753  1
    arc_0_15_5  out_degree_771  1
    arc_0_15_5  original_T_including_depot_unload_811  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_581  1
    load_0_15_5  segment_load_conservation_756  -1
    load_0_15_5  segment_prefix_lb_757  1
    load_0_15_5  segment_prefix_ub_758  1
    load_0_15_5  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_583  -20
    arc_0_15_13  connected_order_arc_584  -14
    arc_0_15_13  in_degree_760  1
    arc_0_15_13  out_degree_771  1
    arc_0_15_13  original_T_including_depot_unload_811  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_583  1
    load_0_15_13  free_load_conservation_764  -1
    load_0_15_13  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_585  -20
    arc_0_15_14  connected_order_arc_586  -14
    arc_0_15_14  in_degree_766  1
    arc_0_15_14  out_degree_771  1
    arc_0_15_14  original_T_including_depot_unload_811  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_585  1
    load_0_15_14  free_load_conservation_770  -1
    load_0_15_14  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_587  -20
    arc_0_15_16  connected_order_arc_588  -14
    arc_0_15_16  out_degree_771  1
    arc_0_15_16  in_degree_778  1
    arc_0_15_16  original_T_including_depot_unload_811  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_587  1
    load_0_15_16  free_load_conservation_776  1
    load_0_15_16  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_589  -20
    arc_0_15_17  connected_order_arc_590  -14
    arc_0_15_17  out_degree_771  1
    arc_0_15_17  in_degree_784  1
    arc_0_15_17  original_T_including_depot_unload_811  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_589  1
    load_0_15_17  free_load_conservation_776  1
    load_0_15_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_591  -20
    arc_0_15_18  connected_order_arc_592  -14
    arc_0_15_18  out_degree_771  1
    arc_0_15_18  in_degree_790  1
    arc_0_15_18  original_T_including_depot_unload_811  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_591  1
    load_0_15_18  free_load_conservation_776  1
    load_0_15_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_593  -20
    arc_0_15_19  connected_order_arc_594  -14
    arc_0_15_19  out_degree_771  1
    arc_0_15_19  in_degree_796  1
    arc_0_15_19  original_T_including_depot_unload_811  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_593  1
    load_0_15_19  free_load_conservation_776  1
    load_0_15_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_595  -20
    arc_0_15_20  connected_order_arc_596  -14
    arc_0_15_20  out_degree_771  1
    arc_0_15_20  in_degree_802  1
    arc_0_15_20  original_T_including_depot_unload_811  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_595  1
    load_0_15_20  free_load_conservation_776  1
    load_0_15_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_597  -20
    arc_0_16_0  depot_return_or_bypass_723  1
    arc_0_16_0  out_degree_777  1
    arc_0_16_0  original_T_including_depot_unload_811  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_597  1
    load_0_16_0  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_598  -20
    arc_0_16_1  connected_order_arc_599  -14
    arc_0_16_1  in_degree_725  1
    arc_0_16_1  out_degree_777  1
    arc_0_16_1  original_T_including_depot_unload_811  8.9144012844276767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_598  1
    load_0_16_1  segment_load_conservation_728  -1
    load_0_16_1  segment_prefix_lb_729  1
    load_0_16_1  segment_prefix_ub_730  1
    load_0_16_1  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_600  -20
    arc_0_16_2  connected_order_arc_601  -14
    arc_0_16_2  in_degree_732  1
    arc_0_16_2  out_degree_777  1
    arc_0_16_2  original_T_including_depot_unload_811  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_600  1
    load_0_16_2  segment_load_conservation_735  -1
    load_0_16_2  segment_prefix_lb_736  1
    load_0_16_2  segment_prefix_ub_737  1
    load_0_16_2  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_602  -20
    arc_0_16_3  connected_order_arc_603  -14
    arc_0_16_3  in_degree_739  1
    arc_0_16_3  out_degree_777  1
    arc_0_16_3  original_T_including_depot_unload_811  8.0179544138113431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_602  1
    load_0_16_3  segment_load_conservation_742  -1
    load_0_16_3  segment_prefix_lb_743  1
    load_0_16_3  segment_prefix_ub_744  1
    load_0_16_3  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_604  -20
    arc_0_16_4  connected_order_arc_605  -14
    arc_0_16_4  in_degree_746  1
    arc_0_16_4  out_degree_777  1
    arc_0_16_4  original_T_including_depot_unload_811  1.7131647154143354e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_604  1
    load_0_16_4  segment_load_conservation_749  -1
    load_0_16_4  segment_prefix_lb_750  1
    load_0_16_4  segment_prefix_ub_751  1
    load_0_16_4  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_606  -20
    arc_0_16_5  connected_order_arc_607  -14
    arc_0_16_5  in_degree_753  1
    arc_0_16_5  out_degree_777  1
    arc_0_16_5  original_T_including_depot_unload_811  1.4462606207080505e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_606  1
    load_0_16_5  segment_load_conservation_756  -1
    load_0_16_5  segment_prefix_lb_757  1
    load_0_16_5  segment_prefix_ub_758  1
    load_0_16_5  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_608  -20
    arc_0_16_13  connected_order_arc_609  -14
    arc_0_16_13  in_degree_760  1
    arc_0_16_13  out_degree_777  1
    arc_0_16_13  original_T_including_depot_unload_811  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_608  1
    load_0_16_13  free_load_conservation_764  -1
    load_0_16_13  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_610  -20
    arc_0_16_14  connected_order_arc_611  -14
    arc_0_16_14  in_degree_766  1
    arc_0_16_14  out_degree_777  1
    arc_0_16_14  original_T_including_depot_unload_811  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_610  1
    load_0_16_14  free_load_conservation_770  -1
    load_0_16_14  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_612  -20
    arc_0_16_15  connected_order_arc_613  -14
    arc_0_16_15  in_degree_772  1
    arc_0_16_15  out_degree_777  1
    arc_0_16_15  original_T_including_depot_unload_811  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_612  1
    load_0_16_15  free_load_conservation_776  -1
    load_0_16_15  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_614  -20
    arc_0_16_17  connected_order_arc_615  -14
    arc_0_16_17  out_degree_777  1
    arc_0_16_17  in_degree_784  1
    arc_0_16_17  original_T_including_depot_unload_811  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_614  1
    load_0_16_17  free_load_conservation_782  1
    load_0_16_17  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_616  -20
    arc_0_16_18  connected_order_arc_617  -14
    arc_0_16_18  out_degree_777  1
    arc_0_16_18  in_degree_790  1
    arc_0_16_18  original_T_including_depot_unload_811  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_616  1
    load_0_16_18  free_load_conservation_782  1
    load_0_16_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_618  -20
    arc_0_16_19  connected_order_arc_619  -14
    arc_0_16_19  out_degree_777  1
    arc_0_16_19  in_degree_796  1
    arc_0_16_19  original_T_including_depot_unload_811  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_618  1
    load_0_16_19  free_load_conservation_782  1
    load_0_16_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_620  -20
    arc_0_16_20  connected_order_arc_621  -14
    arc_0_16_20  out_degree_777  1
    arc_0_16_20  in_degree_802  1
    arc_0_16_20  original_T_including_depot_unload_811  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_620  1
    load_0_16_20  free_load_conservation_782  1
    load_0_16_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_622  -20
    arc_0_17_0  depot_return_or_bypass_723  1
    arc_0_17_0  out_degree_783  1
    arc_0_17_0  original_T_including_depot_unload_811  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_622  1
    load_0_17_0  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_623  -20
    arc_0_17_1  connected_order_arc_624  -14
    arc_0_17_1  in_degree_725  1
    arc_0_17_1  out_degree_783  1
    arc_0_17_1  original_T_including_depot_unload_811  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_623  1
    load_0_17_1  segment_load_conservation_728  -1
    load_0_17_1  segment_prefix_lb_729  1
    load_0_17_1  segment_prefix_ub_730  1
    load_0_17_1  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_625  -20
    arc_0_17_2  connected_order_arc_626  -14
    arc_0_17_2  in_degree_732  1
    arc_0_17_2  out_degree_783  1
    arc_0_17_2  original_T_including_depot_unload_811  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_625  1
    load_0_17_2  segment_load_conservation_735  -1
    load_0_17_2  segment_prefix_lb_736  1
    load_0_17_2  segment_prefix_ub_737  1
    load_0_17_2  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_627  -20
    arc_0_17_3  connected_order_arc_628  -14
    arc_0_17_3  in_degree_739  1
    arc_0_17_3  out_degree_783  1
    arc_0_17_3  original_T_including_depot_unload_811  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_627  1
    load_0_17_3  segment_load_conservation_742  -1
    load_0_17_3  segment_prefix_lb_743  1
    load_0_17_3  segment_prefix_ub_744  1
    load_0_17_3  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_629  -20
    arc_0_17_4  connected_order_arc_630  -14
    arc_0_17_4  in_degree_746  1
    arc_0_17_4  out_degree_783  1
    arc_0_17_4  original_T_including_depot_unload_811  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_629  1
    load_0_17_4  segment_load_conservation_749  -1
    load_0_17_4  segment_prefix_lb_750  1
    load_0_17_4  segment_prefix_ub_751  1
    load_0_17_4  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_631  -20
    arc_0_17_5  connected_order_arc_632  -14
    arc_0_17_5  in_degree_753  1
    arc_0_17_5  out_degree_783  1
    arc_0_17_5  original_T_including_depot_unload_811  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_631  1
    load_0_17_5  segment_load_conservation_756  -1
    load_0_17_5  segment_prefix_lb_757  1
    load_0_17_5  segment_prefix_ub_758  1
    load_0_17_5  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_633  -20
    arc_0_17_13  connected_order_arc_634  -14
    arc_0_17_13  in_degree_760  1
    arc_0_17_13  out_degree_783  1
    arc_0_17_13  original_T_including_depot_unload_811  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_633  1
    load_0_17_13  free_load_conservation_764  -1
    load_0_17_13  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_635  -20
    arc_0_17_14  connected_order_arc_636  -14
    arc_0_17_14  in_degree_766  1
    arc_0_17_14  out_degree_783  1
    arc_0_17_14  original_T_including_depot_unload_811  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_635  1
    load_0_17_14  free_load_conservation_770  -1
    load_0_17_14  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_637  -20
    arc_0_17_15  connected_order_arc_638  -14
    arc_0_17_15  in_degree_772  1
    arc_0_17_15  out_degree_783  1
    arc_0_17_15  original_T_including_depot_unload_811  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_637  1
    load_0_17_15  free_load_conservation_776  -1
    load_0_17_15  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_639  -20
    arc_0_17_16  connected_order_arc_640  -14
    arc_0_17_16  in_degree_778  1
    arc_0_17_16  out_degree_783  1
    arc_0_17_16  original_T_including_depot_unload_811  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_639  1
    load_0_17_16  free_load_conservation_782  -1
    load_0_17_16  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_641  -20
    arc_0_17_18  connected_order_arc_642  -14
    arc_0_17_18  out_degree_783  1
    arc_0_17_18  in_degree_790  1
    arc_0_17_18  original_T_including_depot_unload_811  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_641  1
    load_0_17_18  free_load_conservation_788  1
    load_0_17_18  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_643  -20
    arc_0_17_19  connected_order_arc_644  -14
    arc_0_17_19  out_degree_783  1
    arc_0_17_19  in_degree_796  1
    arc_0_17_19  original_T_including_depot_unload_811  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_643  1
    load_0_17_19  free_load_conservation_788  1
    load_0_17_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_645  -20
    arc_0_17_20  connected_order_arc_646  -14
    arc_0_17_20  out_degree_783  1
    arc_0_17_20  in_degree_802  1
    arc_0_17_20  original_T_including_depot_unload_811  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_645  1
    load_0_17_20  free_load_conservation_788  1
    load_0_17_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_647  -20
    arc_0_18_0  depot_return_or_bypass_723  1
    arc_0_18_0  out_degree_789  1
    arc_0_18_0  original_T_including_depot_unload_811  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_647  1
    load_0_18_0  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_648  -20
    arc_0_18_1  connected_order_arc_649  -14
    arc_0_18_1  in_degree_725  1
    arc_0_18_1  out_degree_789  1
    arc_0_18_1  original_T_including_depot_unload_811  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_648  1
    load_0_18_1  segment_load_conservation_728  -1
    load_0_18_1  segment_prefix_lb_729  1
    load_0_18_1  segment_prefix_ub_730  1
    load_0_18_1  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_650  -20
    arc_0_18_2  connected_order_arc_651  -14
    arc_0_18_2  in_degree_732  1
    arc_0_18_2  out_degree_789  1
    arc_0_18_2  original_T_including_depot_unload_811  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_650  1
    load_0_18_2  segment_load_conservation_735  -1
    load_0_18_2  segment_prefix_lb_736  1
    load_0_18_2  segment_prefix_ub_737  1
    load_0_18_2  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_652  -20
    arc_0_18_3  connected_order_arc_653  -14
    arc_0_18_3  in_degree_739  1
    arc_0_18_3  out_degree_789  1
    arc_0_18_3  original_T_including_depot_unload_811  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_652  1
    load_0_18_3  segment_load_conservation_742  -1
    load_0_18_3  segment_prefix_lb_743  1
    load_0_18_3  segment_prefix_ub_744  1
    load_0_18_3  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_654  -20
    arc_0_18_4  connected_order_arc_655  -14
    arc_0_18_4  in_degree_746  1
    arc_0_18_4  out_degree_789  1
    arc_0_18_4  original_T_including_depot_unload_811  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_654  1
    load_0_18_4  segment_load_conservation_749  -1
    load_0_18_4  segment_prefix_lb_750  1
    load_0_18_4  segment_prefix_ub_751  1
    load_0_18_4  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_656  -20
    arc_0_18_5  connected_order_arc_657  -14
    arc_0_18_5  in_degree_753  1
    arc_0_18_5  out_degree_789  1
    arc_0_18_5  original_T_including_depot_unload_811  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_656  1
    load_0_18_5  segment_load_conservation_756  -1
    load_0_18_5  segment_prefix_lb_757  1
    load_0_18_5  segment_prefix_ub_758  1
    load_0_18_5  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_658  -20
    arc_0_18_13  connected_order_arc_659  -14
    arc_0_18_13  in_degree_760  1
    arc_0_18_13  out_degree_789  1
    arc_0_18_13  original_T_including_depot_unload_811  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_658  1
    load_0_18_13  free_load_conservation_764  -1
    load_0_18_13  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_660  -20
    arc_0_18_14  connected_order_arc_661  -14
    arc_0_18_14  in_degree_766  1
    arc_0_18_14  out_degree_789  1
    arc_0_18_14  original_T_including_depot_unload_811  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_660  1
    load_0_18_14  free_load_conservation_770  -1
    load_0_18_14  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_662  -20
    arc_0_18_15  connected_order_arc_663  -14
    arc_0_18_15  in_degree_772  1
    arc_0_18_15  out_degree_789  1
    arc_0_18_15  original_T_including_depot_unload_811  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_662  1
    load_0_18_15  free_load_conservation_776  -1
    load_0_18_15  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_664  -20
    arc_0_18_16  connected_order_arc_665  -14
    arc_0_18_16  in_degree_778  1
    arc_0_18_16  out_degree_789  1
    arc_0_18_16  original_T_including_depot_unload_811  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_664  1
    load_0_18_16  free_load_conservation_782  -1
    load_0_18_16  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_666  -20
    arc_0_18_17  connected_order_arc_667  -14
    arc_0_18_17  in_degree_784  1
    arc_0_18_17  out_degree_789  1
    arc_0_18_17  original_T_including_depot_unload_811  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_666  1
    load_0_18_17  free_load_conservation_788  -1
    load_0_18_17  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_668  -20
    arc_0_18_19  connected_order_arc_669  -14
    arc_0_18_19  out_degree_789  1
    arc_0_18_19  in_degree_796  1
    arc_0_18_19  original_T_including_depot_unload_811  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_668  1
    load_0_18_19  free_load_conservation_794  1
    load_0_18_19  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_670  -20
    arc_0_18_20  connected_order_arc_671  -14
    arc_0_18_20  out_degree_789  1
    arc_0_18_20  in_degree_802  1
    arc_0_18_20  original_T_including_depot_unload_811  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_670  1
    load_0_18_20  free_load_conservation_794  1
    load_0_18_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_672  -20
    arc_0_19_0  depot_return_or_bypass_723  1
    arc_0_19_0  out_degree_795  1
    arc_0_19_0  original_T_including_depot_unload_811  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_672  1
    load_0_19_0  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_673  -20
    arc_0_19_1  connected_order_arc_674  -14
    arc_0_19_1  in_degree_725  1
    arc_0_19_1  out_degree_795  1
    arc_0_19_1  original_T_including_depot_unload_811  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_673  1
    load_0_19_1  segment_load_conservation_728  -1
    load_0_19_1  segment_prefix_lb_729  1
    load_0_19_1  segment_prefix_ub_730  1
    load_0_19_1  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_675  -20
    arc_0_19_2  connected_order_arc_676  -14
    arc_0_19_2  in_degree_732  1
    arc_0_19_2  out_degree_795  1
    arc_0_19_2  original_T_including_depot_unload_811  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_675  1
    load_0_19_2  segment_load_conservation_735  -1
    load_0_19_2  segment_prefix_lb_736  1
    load_0_19_2  segment_prefix_ub_737  1
    load_0_19_2  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_677  -20
    arc_0_19_3  connected_order_arc_678  -14
    arc_0_19_3  in_degree_739  1
    arc_0_19_3  out_degree_795  1
    arc_0_19_3  original_T_including_depot_unload_811  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_677  1
    load_0_19_3  segment_load_conservation_742  -1
    load_0_19_3  segment_prefix_lb_743  1
    load_0_19_3  segment_prefix_ub_744  1
    load_0_19_3  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_679  -20
    arc_0_19_4  connected_order_arc_680  -14
    arc_0_19_4  in_degree_746  1
    arc_0_19_4  out_degree_795  1
    arc_0_19_4  original_T_including_depot_unload_811  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_679  1
    load_0_19_4  segment_load_conservation_749  -1
    load_0_19_4  segment_prefix_lb_750  1
    load_0_19_4  segment_prefix_ub_751  1
    load_0_19_4  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_681  -20
    arc_0_19_5  connected_order_arc_682  -14
    arc_0_19_5  in_degree_753  1
    arc_0_19_5  out_degree_795  1
    arc_0_19_5  original_T_including_depot_unload_811  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_681  1
    load_0_19_5  segment_load_conservation_756  -1
    load_0_19_5  segment_prefix_lb_757  1
    load_0_19_5  segment_prefix_ub_758  1
    load_0_19_5  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_683  -20
    arc_0_19_13  connected_order_arc_684  -14
    arc_0_19_13  in_degree_760  1
    arc_0_19_13  out_degree_795  1
    arc_0_19_13  original_T_including_depot_unload_811  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_683  1
    load_0_19_13  free_load_conservation_764  -1
    load_0_19_13  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_685  -20
    arc_0_19_14  connected_order_arc_686  -14
    arc_0_19_14  in_degree_766  1
    arc_0_19_14  out_degree_795  1
    arc_0_19_14  original_T_including_depot_unload_811  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_685  1
    load_0_19_14  free_load_conservation_770  -1
    load_0_19_14  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_687  -20
    arc_0_19_15  connected_order_arc_688  -14
    arc_0_19_15  in_degree_772  1
    arc_0_19_15  out_degree_795  1
    arc_0_19_15  original_T_including_depot_unload_811  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_687  1
    load_0_19_15  free_load_conservation_776  -1
    load_0_19_15  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_689  -20
    arc_0_19_16  connected_order_arc_690  -14
    arc_0_19_16  in_degree_778  1
    arc_0_19_16  out_degree_795  1
    arc_0_19_16  original_T_including_depot_unload_811  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_689  1
    load_0_19_16  free_load_conservation_782  -1
    load_0_19_16  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_691  -20
    arc_0_19_17  connected_order_arc_692  -14
    arc_0_19_17  in_degree_784  1
    arc_0_19_17  out_degree_795  1
    arc_0_19_17  original_T_including_depot_unload_811  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_691  1
    load_0_19_17  free_load_conservation_788  -1
    load_0_19_17  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_693  -20
    arc_0_19_18  connected_order_arc_694  -14
    arc_0_19_18  in_degree_790  1
    arc_0_19_18  out_degree_795  1
    arc_0_19_18  original_T_including_depot_unload_811  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_693  1
    load_0_19_18  free_load_conservation_794  -1
    load_0_19_18  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_695  -20
    arc_0_19_20  connected_order_arc_696  -14
    arc_0_19_20  out_degree_795  1
    arc_0_19_20  in_degree_802  1
    arc_0_19_20  original_T_including_depot_unload_811  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_695  1
    load_0_19_20  free_load_conservation_800  1
    load_0_19_20  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_697  -20
    arc_0_20_0  depot_return_or_bypass_723  1
    arc_0_20_0  out_degree_801  1
    arc_0_20_0  original_T_including_depot_unload_811  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_697  1
    load_0_20_0  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_698  -20
    arc_0_20_1  connected_order_arc_699  -14
    arc_0_20_1  in_degree_725  1
    arc_0_20_1  out_degree_801  1
    arc_0_20_1  original_T_including_depot_unload_811  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_698  1
    load_0_20_1  segment_load_conservation_728  -1
    load_0_20_1  segment_prefix_lb_729  1
    load_0_20_1  segment_prefix_ub_730  1
    load_0_20_1  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_700  -20
    arc_0_20_2  connected_order_arc_701  -14
    arc_0_20_2  in_degree_732  1
    arc_0_20_2  out_degree_801  1
    arc_0_20_2  original_T_including_depot_unload_811  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_700  1
    load_0_20_2  segment_load_conservation_735  -1
    load_0_20_2  segment_prefix_lb_736  1
    load_0_20_2  segment_prefix_ub_737  1
    load_0_20_2  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_702  -20
    arc_0_20_3  connected_order_arc_703  -14
    arc_0_20_3  in_degree_739  1
    arc_0_20_3  out_degree_801  1
    arc_0_20_3  original_T_including_depot_unload_811  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_702  1
    load_0_20_3  segment_load_conservation_742  -1
    load_0_20_3  segment_prefix_lb_743  1
    load_0_20_3  segment_prefix_ub_744  1
    load_0_20_3  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_704  -20
    arc_0_20_4  connected_order_arc_705  -14
    arc_0_20_4  in_degree_746  1
    arc_0_20_4  out_degree_801  1
    arc_0_20_4  original_T_including_depot_unload_811  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_704  1
    load_0_20_4  segment_load_conservation_749  -1
    load_0_20_4  segment_prefix_lb_750  1
    load_0_20_4  segment_prefix_ub_751  1
    load_0_20_4  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_706  -20
    arc_0_20_5  connected_order_arc_707  -14
    arc_0_20_5  in_degree_753  1
    arc_0_20_5  out_degree_801  1
    arc_0_20_5  original_T_including_depot_unload_811  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_706  1
    load_0_20_5  segment_load_conservation_756  -1
    load_0_20_5  segment_prefix_lb_757  1
    load_0_20_5  segment_prefix_ub_758  1
    load_0_20_5  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_708  -20
    arc_0_20_13  connected_order_arc_709  -14
    arc_0_20_13  in_degree_760  1
    arc_0_20_13  out_degree_801  1
    arc_0_20_13  original_T_including_depot_unload_811  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_708  1
    load_0_20_13  free_load_conservation_764  -1
    load_0_20_13  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_710  -20
    arc_0_20_14  connected_order_arc_711  -14
    arc_0_20_14  in_degree_766  1
    arc_0_20_14  out_degree_801  1
    arc_0_20_14  original_T_including_depot_unload_811  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_710  1
    load_0_20_14  free_load_conservation_770  -1
    load_0_20_14  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_712  -20
    arc_0_20_15  connected_order_arc_713  -14
    arc_0_20_15  in_degree_772  1
    arc_0_20_15  out_degree_801  1
    arc_0_20_15  original_T_including_depot_unload_811  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_712  1
    load_0_20_15  free_load_conservation_776  -1
    load_0_20_15  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_714  -20
    arc_0_20_16  connected_order_arc_715  -14
    arc_0_20_16  in_degree_778  1
    arc_0_20_16  out_degree_801  1
    arc_0_20_16  original_T_including_depot_unload_811  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_714  1
    load_0_20_16  free_load_conservation_782  -1
    load_0_20_16  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_716  -20
    arc_0_20_17  connected_order_arc_717  -14
    arc_0_20_17  in_degree_784  1
    arc_0_20_17  out_degree_801  1
    arc_0_20_17  original_T_including_depot_unload_811  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_716  1
    load_0_20_17  free_load_conservation_788  -1
    load_0_20_17  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_718  -20
    arc_0_20_18  connected_order_arc_719  -14
    arc_0_20_18  in_degree_790  1
    arc_0_20_18  out_degree_801  1
    arc_0_20_18  original_T_including_depot_unload_811  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_718  1
    load_0_20_18  free_load_conservation_794  -1
    load_0_20_18  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_720  -20
    arc_0_20_19  connected_order_arc_721  -14
    arc_0_20_19  in_degree_796  1
    arc_0_20_19  out_degree_801  1
    arc_0_20_19  original_T_including_depot_unload_811  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_720  1
    load_0_20_19  free_load_conservation_800  -1
    load_0_20_19  free_load_conservation_806  1
    visit_1_6  out_degree_1103  -1
    visit_1_6  in_degree_1104  -1
    visit_1_6  order_active_lb_1105  -1
    visit_1_6  order_active_ub_1106  -12
    order_1_6  connected_order_arc_827  -1
    order_1_6  connected_order_arc_829  -1
    order_1_6  connected_order_arc_831  -1
    order_1_6  connected_order_arc_833  -1
    order_1_6  connected_order_arc_835  -1
    order_1_6  connected_order_arc_837  -1
    order_1_6  connected_order_arc_839  -1
    order_1_6  connected_order_arc_841  -1
    order_1_6  connected_order_arc_843  -1
    order_1_6  connected_order_arc_845  -1
    order_1_6  connected_order_arc_847  -1
    order_1_6  connected_order_arc_850  1
    order_1_6  connected_order_arc_873  1
    order_1_6  connected_order_arc_896  1
    order_1_6  connected_order_arc_919  1
    order_1_6  connected_order_arc_942  1
    order_1_6  connected_order_arc_965  1
    order_1_6  connected_order_arc_988  1
    order_1_6  connected_order_arc_1011  1
    order_1_6  connected_order_arc_1034  1
    order_1_6  connected_order_arc_1057  1
    order_1_6  connected_order_arc_1080  1
    order_1_6  order_active_lb_1105  1
    order_1_6  order_active_ub_1106  1
    order_1_6  fixed_segment_relative_order_1179  -1
    visit_1_7  out_degree_1110  -1
    visit_1_7  in_degree_1111  -1
    visit_1_7  order_active_lb_1112  -1
    visit_1_7  order_active_ub_1113  -12
    order_1_7  connected_order_arc_827  1
    order_1_7  connected_order_arc_850  -1
    order_1_7  connected_order_arc_852  -1
    order_1_7  connected_order_arc_854  -1
    order_1_7  connected_order_arc_856  -1
    order_1_7  connected_order_arc_858  -1
    order_1_7  connected_order_arc_860  -1
    order_1_7  connected_order_arc_862  -1
    order_1_7  connected_order_arc_864  -1
    order_1_7  connected_order_arc_866  -1
    order_1_7  connected_order_arc_868  -1
    order_1_7  connected_order_arc_870  -1
    order_1_7  connected_order_arc_875  1
    order_1_7  connected_order_arc_898  1
    order_1_7  connected_order_arc_921  1
    order_1_7  connected_order_arc_944  1
    order_1_7  connected_order_arc_967  1
    order_1_7  connected_order_arc_990  1
    order_1_7  connected_order_arc_1013  1
    order_1_7  connected_order_arc_1036  1
    order_1_7  connected_order_arc_1059  1
    order_1_7  connected_order_arc_1082  1
    order_1_7  order_active_lb_1112  1
    order_1_7  order_active_ub_1113  1
    order_1_7  fixed_segment_relative_order_1179  1
    order_1_7  fixed_segment_relative_order_1180  -1
    visit_1_8  out_degree_1117  -1
    visit_1_8  in_degree_1118  -1
    visit_1_8  order_active_lb_1119  -1
    visit_1_8  order_active_ub_1120  -12
    order_1_8  connected_order_arc_829  1
    order_1_8  connected_order_arc_852  1
    order_1_8  connected_order_arc_873  -1
    order_1_8  connected_order_arc_875  -1
    order_1_8  connected_order_arc_877  -1
    order_1_8  connected_order_arc_879  -1
    order_1_8  connected_order_arc_881  -1
    order_1_8  connected_order_arc_883  -1
    order_1_8  connected_order_arc_885  -1
    order_1_8  connected_order_arc_887  -1
    order_1_8  connected_order_arc_889  -1
    order_1_8  connected_order_arc_891  -1
    order_1_8  connected_order_arc_893  -1
    order_1_8  connected_order_arc_900  1
    order_1_8  connected_order_arc_923  1
    order_1_8  connected_order_arc_946  1
    order_1_8  connected_order_arc_969  1
    order_1_8  connected_order_arc_992  1
    order_1_8  connected_order_arc_1015  1
    order_1_8  connected_order_arc_1038  1
    order_1_8  connected_order_arc_1061  1
    order_1_8  connected_order_arc_1084  1
    order_1_8  order_active_lb_1119  1
    order_1_8  order_active_ub_1120  1
    order_1_8  fixed_segment_relative_order_1180  1
    order_1_8  fixed_segment_relative_order_1181  -1
    visit_1_9  out_degree_1124  -1
    visit_1_9  in_degree_1125  -1
    visit_1_9  order_active_lb_1126  -1
    visit_1_9  order_active_ub_1127  -12
    order_1_9  connected_order_arc_831  1
    order_1_9  connected_order_arc_854  1
    order_1_9  connected_order_arc_877  1
    order_1_9  connected_order_arc_896  -1
    order_1_9  connected_order_arc_898  -1
    order_1_9  connected_order_arc_900  -1
    order_1_9  connected_order_arc_902  -1
    order_1_9  connected_order_arc_904  -1
    order_1_9  connected_order_arc_906  -1
    order_1_9  connected_order_arc_908  -1
    order_1_9  connected_order_arc_910  -1
    order_1_9  connected_order_arc_912  -1
    order_1_9  connected_order_arc_914  -1
    order_1_9  connected_order_arc_916  -1
    order_1_9  connected_order_arc_925  1
    order_1_9  connected_order_arc_948  1
    order_1_9  connected_order_arc_971  1
    order_1_9  connected_order_arc_994  1
    order_1_9  connected_order_arc_1017  1
    order_1_9  connected_order_arc_1040  1
    order_1_9  connected_order_arc_1063  1
    order_1_9  connected_order_arc_1086  1
    order_1_9  order_active_lb_1126  1
    order_1_9  order_active_ub_1127  1
    order_1_9  fixed_segment_relative_order_1181  1
    visit_1_13  out_degree_1131  -1
    visit_1_13  in_degree_1132  -1
    visit_1_13  order_active_lb_1133  -1
    visit_1_13  order_active_ub_1134  -12
    visit_1_13  service_visit_def_1135  -1
    order_1_13  connected_order_arc_833  1
    order_1_13  connected_order_arc_856  1
    order_1_13  connected_order_arc_879  1
    order_1_13  connected_order_arc_902  1
    order_1_13  connected_order_arc_919  -1
    order_1_13  connected_order_arc_921  -1
    order_1_13  connected_order_arc_923  -1
    order_1_13  connected_order_arc_925  -1
    order_1_13  connected_order_arc_927  -1
    order_1_13  connected_order_arc_929  -1
    order_1_13  connected_order_arc_931  -1
    order_1_13  connected_order_arc_933  -1
    order_1_13  connected_order_arc_935  -1
    order_1_13  connected_order_arc_937  -1
    order_1_13  connected_order_arc_939  -1
    order_1_13  connected_order_arc_950  1
    order_1_13  connected_order_arc_973  1
    order_1_13  connected_order_arc_996  1
    order_1_13  connected_order_arc_1019  1
    order_1_13  connected_order_arc_1042  1
    order_1_13  connected_order_arc_1065  1
    order_1_13  connected_order_arc_1088  1
    order_1_13  order_active_lb_1133  1
    order_1_13  order_active_ub_1134  1
    visit_1_14  out_degree_1137  -1
    visit_1_14  in_degree_1138  -1
    visit_1_14  order_active_lb_1139  -1
    visit_1_14  order_active_ub_1140  -12
    visit_1_14  service_visit_def_1141  -1
    order_1_14  connected_order_arc_835  1
    order_1_14  connected_order_arc_858  1
    order_1_14  connected_order_arc_881  1
    order_1_14  connected_order_arc_904  1
    order_1_14  connected_order_arc_927  1
    order_1_14  connected_order_arc_942  -1
    order_1_14  connected_order_arc_944  -1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_958  -1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_975  1
    order_1_14  connected_order_arc_998  1
    order_1_14  connected_order_arc_1021  1
    order_1_14  connected_order_arc_1044  1
    order_1_14  connected_order_arc_1067  1
    order_1_14  connected_order_arc_1090  1
    order_1_14  order_active_lb_1139  1
    order_1_14  order_active_ub_1140  1
    visit_1_15  out_degree_1143  -1
    visit_1_15  in_degree_1144  -1
    visit_1_15  order_active_lb_1145  -1
    visit_1_15  order_active_ub_1146  -12
    visit_1_15  service_visit_def_1147  -1
    order_1_15  connected_order_arc_837  1
    order_1_15  connected_order_arc_860  1
    order_1_15  connected_order_arc_883  1
    order_1_15  connected_order_arc_906  1
    order_1_15  connected_order_arc_929  1
    order_1_15  connected_order_arc_952  1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_1000  1
    order_1_15  connected_order_arc_1023  1
    order_1_15  connected_order_arc_1046  1
    order_1_15  connected_order_arc_1069  1
    order_1_15  connected_order_arc_1092  1
    order_1_15  order_active_lb_1145  1
    order_1_15  order_active_ub_1146  1
    visit_1_16  out_degree_1149  -1
    visit_1_16  in_degree_1150  -1
    visit_1_16  order_active_lb_1151  -1
    visit_1_16  order_active_ub_1152  -12
    visit_1_16  service_visit_def_1153  -1
    order_1_16  connected_order_arc_839  1
    order_1_16  connected_order_arc_862  1
    order_1_16  connected_order_arc_885  1
    order_1_16  connected_order_arc_908  1
    order_1_16  connected_order_arc_931  1
    order_1_16  connected_order_arc_954  1
    order_1_16  connected_order_arc_977  1
    order_1_16  connected_order_arc_988  -1
    order_1_16  connected_order_arc_990  -1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1025  1
    order_1_16  connected_order_arc_1048  1
    order_1_16  connected_order_arc_1071  1
    order_1_16  connected_order_arc_1094  1
    order_1_16  order_active_lb_1151  1
    order_1_16  order_active_ub_1152  1
    visit_1_17  out_degree_1155  -1
    visit_1_17  in_degree_1156  -1
    visit_1_17  order_active_lb_1157  -1
    visit_1_17  order_active_ub_1158  -12
    visit_1_17  service_visit_def_1159  -1
    order_1_17  connected_order_arc_841  1
    order_1_17  connected_order_arc_864  1
    order_1_17  connected_order_arc_887  1
    order_1_17  connected_order_arc_910  1
    order_1_17  connected_order_arc_933  1
    order_1_17  connected_order_arc_956  1
    order_1_17  connected_order_arc_979  1
    order_1_17  connected_order_arc_1002  1
    order_1_17  connected_order_arc_1011  -1
    order_1_17  connected_order_arc_1013  -1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1021  -1
    order_1_17  connected_order_arc_1023  -1
    order_1_17  connected_order_arc_1025  -1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1050  1
    order_1_17  connected_order_arc_1073  1
    order_1_17  connected_order_arc_1096  1
    order_1_17  order_active_lb_1157  1
    order_1_17  order_active_ub_1158  1
    visit_1_18  out_degree_1161  -1
    visit_1_18  in_degree_1162  -1
    visit_1_18  order_active_lb_1163  -1
    visit_1_18  order_active_ub_1164  -12
    visit_1_18  service_visit_def_1165  -1
    order_1_18  connected_order_arc_843  1
    order_1_18  connected_order_arc_866  1
    order_1_18  connected_order_arc_889  1
    order_1_18  connected_order_arc_912  1
    order_1_18  connected_order_arc_935  1
    order_1_18  connected_order_arc_958  1
    order_1_18  connected_order_arc_981  1
    order_1_18  connected_order_arc_1004  1
    order_1_18  connected_order_arc_1027  1
    order_1_18  connected_order_arc_1034  -1
    order_1_18  connected_order_arc_1036  -1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1040  -1
    order_1_18  connected_order_arc_1042  -1
    order_1_18  connected_order_arc_1044  -1
    order_1_18  connected_order_arc_1046  -1
    order_1_18  connected_order_arc_1048  -1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1075  1
    order_1_18  connected_order_arc_1098  1
    order_1_18  order_active_lb_1163  1
    order_1_18  order_active_ub_1164  1
    visit_1_19  out_degree_1167  -1
    visit_1_19  in_degree_1168  -1
    visit_1_19  order_active_lb_1169  -1
    visit_1_19  order_active_ub_1170  -12
    visit_1_19  service_visit_def_1171  -1
    order_1_19  connected_order_arc_845  1
    order_1_19  connected_order_arc_868  1
    order_1_19  connected_order_arc_891  1
    order_1_19  connected_order_arc_914  1
    order_1_19  connected_order_arc_937  1
    order_1_19  connected_order_arc_960  1
    order_1_19  connected_order_arc_983  1
    order_1_19  connected_order_arc_1006  1
    order_1_19  connected_order_arc_1029  1
    order_1_19  connected_order_arc_1052  1
    order_1_19  connected_order_arc_1057  -1
    order_1_19  connected_order_arc_1059  -1
    order_1_19  connected_order_arc_1061  -1
    order_1_19  connected_order_arc_1063  -1
    order_1_19  connected_order_arc_1065  -1
    order_1_19  connected_order_arc_1067  -1
    order_1_19  connected_order_arc_1069  -1
    order_1_19  connected_order_arc_1071  -1
    order_1_19  connected_order_arc_1073  -1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1100  1
    order_1_19  order_active_lb_1169  1
    order_1_19  order_active_ub_1170  1
    visit_1_20  out_degree_1173  -1
    visit_1_20  in_degree_1174  -1
    visit_1_20  order_active_lb_1175  -1
    visit_1_20  order_active_ub_1176  -12
    visit_1_20  service_visit_def_1177  -1
    order_1_20  connected_order_arc_847  1
    order_1_20  connected_order_arc_870  1
    order_1_20  connected_order_arc_893  1
    order_1_20  connected_order_arc_916  1
    order_1_20  connected_order_arc_939  1
    order_1_20  connected_order_arc_962  1
    order_1_20  connected_order_arc_985  1
    order_1_20  connected_order_arc_1008  1
    order_1_20  connected_order_arc_1031  1
    order_1_20  connected_order_arc_1054  1
    order_1_20  connected_order_arc_1077  1
    order_1_20  connected_order_arc_1080  -1
    order_1_20  connected_order_arc_1082  -1
    order_1_20  connected_order_arc_1084  -1
    order_1_20  connected_order_arc_1086  -1
    order_1_20  connected_order_arc_1088  -1
    order_1_20  connected_order_arc_1090  -1
    order_1_20  connected_order_arc_1092  -1
    order_1_20  connected_order_arc_1094  -1
    order_1_20  connected_order_arc_1096  -1
    order_1_20  connected_order_arc_1098  -1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  order_active_lb_1175  1
    order_1_20  order_active_ub_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_812  -25
    arc_1_0_0  depot_departure_or_bypass_1101  1
    arc_1_0_0  depot_return_or_bypass_1102  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_813  -25
    arc_1_0_6  depot_departure_or_bypass_1101  1
    arc_1_0_6  in_degree_1104  1
    arc_1_0_6  original_T_including_depot_unload_1182  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_813  1
    load_1_0_6  segment_load_conservation_1107  -1
    load_1_0_6  segment_prefix_lb_1108  1
    load_1_0_6  segment_prefix_ub_1109  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_814  -25
    arc_1_0_7  depot_departure_or_bypass_1101  1
    arc_1_0_7  in_degree_1111  1
    arc_1_0_7  original_T_including_depot_unload_1182  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_814  1
    load_1_0_7  segment_load_conservation_1114  -1
    load_1_0_7  segment_prefix_lb_1115  1
    load_1_0_7  segment_prefix_ub_1116  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_815  -25
    arc_1_0_8  depot_departure_or_bypass_1101  1
    arc_1_0_8  in_degree_1118  1
    arc_1_0_8  original_T_including_depot_unload_1182  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_815  1
    load_1_0_8  segment_load_conservation_1121  -1
    load_1_0_8  segment_prefix_lb_1122  1
    load_1_0_8  segment_prefix_ub_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_816  -25
    arc_1_0_9  depot_departure_or_bypass_1101  1
    arc_1_0_9  in_degree_1125  1
    arc_1_0_9  original_T_including_depot_unload_1182  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_816  1
    load_1_0_9  segment_load_conservation_1128  -1
    load_1_0_9  segment_prefix_lb_1129  1
    load_1_0_9  segment_prefix_ub_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_817  -25
    arc_1_0_13  depot_departure_or_bypass_1101  1
    arc_1_0_13  in_degree_1132  1
    arc_1_0_13  original_T_including_depot_unload_1182  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_817  1
    load_1_0_13  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_818  -25
    arc_1_0_14  depot_departure_or_bypass_1101  1
    arc_1_0_14  in_degree_1138  1
    arc_1_0_14  original_T_including_depot_unload_1182  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_818  1
    load_1_0_14  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_819  -25
    arc_1_0_15  depot_departure_or_bypass_1101  1
    arc_1_0_15  in_degree_1144  1
    arc_1_0_15  original_T_including_depot_unload_1182  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_819  1
    load_1_0_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_820  -25
    arc_1_0_16  depot_departure_or_bypass_1101  1
    arc_1_0_16  in_degree_1150  1
    arc_1_0_16  original_T_including_depot_unload_1182  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_820  1
    load_1_0_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_821  -25
    arc_1_0_17  depot_departure_or_bypass_1101  1
    arc_1_0_17  in_degree_1156  1
    arc_1_0_17  original_T_including_depot_unload_1182  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_821  1
    load_1_0_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_822  -25
    arc_1_0_18  depot_departure_or_bypass_1101  1
    arc_1_0_18  in_degree_1162  1
    arc_1_0_18  original_T_including_depot_unload_1182  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_822  1
    load_1_0_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_823  -25
    arc_1_0_19  depot_departure_or_bypass_1101  1
    arc_1_0_19  in_degree_1168  1
    arc_1_0_19  original_T_including_depot_unload_1182  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_823  1
    load_1_0_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_824  -25
    arc_1_0_20  depot_departure_or_bypass_1101  1
    arc_1_0_20  in_degree_1174  1
    arc_1_0_20  original_T_including_depot_unload_1182  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_824  1
    load_1_0_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_825  -25
    arc_1_6_0  depot_return_or_bypass_1102  1
    arc_1_6_0  out_degree_1103  1
    arc_1_6_0  original_T_including_depot_unload_1182  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_825  1
    load_1_6_0  segment_load_conservation_1107  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_826  -25
    arc_1_6_7  connected_order_arc_827  -13
    arc_1_6_7  out_degree_1103  1
    arc_1_6_7  in_degree_1111  1
    arc_1_6_7  original_T_including_depot_unload_1182  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_826  1
    load_1_6_7  segment_load_conservation_1107  1
    load_1_6_7  segment_load_conservation_1114  -1
    load_1_6_7  segment_prefix_lb_1115  1
    load_1_6_7  segment_prefix_ub_1116  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_828  -25
    arc_1_6_8  connected_order_arc_829  -13
    arc_1_6_8  out_degree_1103  1
    arc_1_6_8  in_degree_1118  1
    arc_1_6_8  original_T_including_depot_unload_1182  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_828  1
    load_1_6_8  segment_load_conservation_1107  1
    load_1_6_8  segment_load_conservation_1121  -1
    load_1_6_8  segment_prefix_lb_1122  1
    load_1_6_8  segment_prefix_ub_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_830  -25
    arc_1_6_9  connected_order_arc_831  -13
    arc_1_6_9  out_degree_1103  1
    arc_1_6_9  in_degree_1125  1
    arc_1_6_9  original_T_including_depot_unload_1182  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_830  1
    load_1_6_9  segment_load_conservation_1107  1
    load_1_6_9  segment_load_conservation_1128  -1
    load_1_6_9  segment_prefix_lb_1129  1
    load_1_6_9  segment_prefix_ub_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_832  -25
    arc_1_6_13  connected_order_arc_833  -13
    arc_1_6_13  out_degree_1103  1
    arc_1_6_13  in_degree_1132  1
    arc_1_6_13  original_T_including_depot_unload_1182  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_832  1
    load_1_6_13  segment_load_conservation_1107  1
    load_1_6_13  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_834  -25
    arc_1_6_14  connected_order_arc_835  -13
    arc_1_6_14  out_degree_1103  1
    arc_1_6_14  in_degree_1138  1
    arc_1_6_14  original_T_including_depot_unload_1182  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_834  1
    load_1_6_14  segment_load_conservation_1107  1
    load_1_6_14  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_836  -25
    arc_1_6_15  connected_order_arc_837  -13
    arc_1_6_15  out_degree_1103  1
    arc_1_6_15  in_degree_1144  1
    arc_1_6_15  original_T_including_depot_unload_1182  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_836  1
    load_1_6_15  segment_load_conservation_1107  1
    load_1_6_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_838  -25
    arc_1_6_16  connected_order_arc_839  -13
    arc_1_6_16  out_degree_1103  1
    arc_1_6_16  in_degree_1150  1
    arc_1_6_16  original_T_including_depot_unload_1182  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_838  1
    load_1_6_16  segment_load_conservation_1107  1
    load_1_6_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_840  -25
    arc_1_6_17  connected_order_arc_841  -13
    arc_1_6_17  out_degree_1103  1
    arc_1_6_17  in_degree_1156  1
    arc_1_6_17  original_T_including_depot_unload_1182  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_840  1
    load_1_6_17  segment_load_conservation_1107  1
    load_1_6_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_842  -25
    arc_1_6_18  connected_order_arc_843  -13
    arc_1_6_18  out_degree_1103  1
    arc_1_6_18  in_degree_1162  1
    arc_1_6_18  original_T_including_depot_unload_1182  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_842  1
    load_1_6_18  segment_load_conservation_1107  1
    load_1_6_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_844  -25
    arc_1_6_19  connected_order_arc_845  -13
    arc_1_6_19  out_degree_1103  1
    arc_1_6_19  in_degree_1168  1
    arc_1_6_19  original_T_including_depot_unload_1182  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_844  1
    load_1_6_19  segment_load_conservation_1107  1
    load_1_6_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_846  -25
    arc_1_6_20  connected_order_arc_847  -13
    arc_1_6_20  out_degree_1103  1
    arc_1_6_20  in_degree_1174  1
    arc_1_6_20  original_T_including_depot_unload_1182  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_846  1
    load_1_6_20  segment_load_conservation_1107  1
    load_1_6_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_848  -25
    arc_1_7_0  depot_return_or_bypass_1102  1
    arc_1_7_0  out_degree_1110  1
    arc_1_7_0  original_T_including_depot_unload_1182  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_848  1
    load_1_7_0  segment_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_849  -25
    arc_1_7_6  connected_order_arc_850  -13
    arc_1_7_6  in_degree_1104  1
    arc_1_7_6  out_degree_1110  1
    arc_1_7_6  original_T_including_depot_unload_1182  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_849  1
    load_1_7_6  segment_load_conservation_1107  -1
    load_1_7_6  segment_prefix_lb_1108  1
    load_1_7_6  segment_prefix_ub_1109  1
    load_1_7_6  segment_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_851  -25
    arc_1_7_8  connected_order_arc_852  -13
    arc_1_7_8  out_degree_1110  1
    arc_1_7_8  in_degree_1118  1
    arc_1_7_8  original_T_including_depot_unload_1182  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_851  1
    load_1_7_8  segment_load_conservation_1114  1
    load_1_7_8  segment_load_conservation_1121  -1
    load_1_7_8  segment_prefix_lb_1122  1
    load_1_7_8  segment_prefix_ub_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_853  -25
    arc_1_7_9  connected_order_arc_854  -13
    arc_1_7_9  out_degree_1110  1
    arc_1_7_9  in_degree_1125  1
    arc_1_7_9  original_T_including_depot_unload_1182  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_853  1
    load_1_7_9  segment_load_conservation_1114  1
    load_1_7_9  segment_load_conservation_1128  -1
    load_1_7_9  segment_prefix_lb_1129  1
    load_1_7_9  segment_prefix_ub_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_855  -25
    arc_1_7_13  connected_order_arc_856  -13
    arc_1_7_13  out_degree_1110  1
    arc_1_7_13  in_degree_1132  1
    arc_1_7_13  original_T_including_depot_unload_1182  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_855  1
    load_1_7_13  segment_load_conservation_1114  1
    load_1_7_13  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_857  -25
    arc_1_7_14  connected_order_arc_858  -13
    arc_1_7_14  out_degree_1110  1
    arc_1_7_14  in_degree_1138  1
    arc_1_7_14  original_T_including_depot_unload_1182  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_857  1
    load_1_7_14  segment_load_conservation_1114  1
    load_1_7_14  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_859  -25
    arc_1_7_15  connected_order_arc_860  -13
    arc_1_7_15  out_degree_1110  1
    arc_1_7_15  in_degree_1144  1
    arc_1_7_15  original_T_including_depot_unload_1182  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_859  1
    load_1_7_15  segment_load_conservation_1114  1
    load_1_7_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_861  -25
    arc_1_7_16  connected_order_arc_862  -13
    arc_1_7_16  out_degree_1110  1
    arc_1_7_16  in_degree_1150  1
    arc_1_7_16  original_T_including_depot_unload_1182  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_861  1
    load_1_7_16  segment_load_conservation_1114  1
    load_1_7_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_863  -25
    arc_1_7_17  connected_order_arc_864  -13
    arc_1_7_17  out_degree_1110  1
    arc_1_7_17  in_degree_1156  1
    arc_1_7_17  original_T_including_depot_unload_1182  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_863  1
    load_1_7_17  segment_load_conservation_1114  1
    load_1_7_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_865  -25
    arc_1_7_18  connected_order_arc_866  -13
    arc_1_7_18  out_degree_1110  1
    arc_1_7_18  in_degree_1162  1
    arc_1_7_18  original_T_including_depot_unload_1182  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_865  1
    load_1_7_18  segment_load_conservation_1114  1
    load_1_7_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_867  -25
    arc_1_7_19  connected_order_arc_868  -13
    arc_1_7_19  out_degree_1110  1
    arc_1_7_19  in_degree_1168  1
    arc_1_7_19  original_T_including_depot_unload_1182  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_867  1
    load_1_7_19  segment_load_conservation_1114  1
    load_1_7_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_869  -25
    arc_1_7_20  connected_order_arc_870  -13
    arc_1_7_20  out_degree_1110  1
    arc_1_7_20  in_degree_1174  1
    arc_1_7_20  original_T_including_depot_unload_1182  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_869  1
    load_1_7_20  segment_load_conservation_1114  1
    load_1_7_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_871  -25
    arc_1_8_0  depot_return_or_bypass_1102  1
    arc_1_8_0  out_degree_1117  1
    arc_1_8_0  original_T_including_depot_unload_1182  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_871  1
    load_1_8_0  segment_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_872  -25
    arc_1_8_6  connected_order_arc_873  -13
    arc_1_8_6  in_degree_1104  1
    arc_1_8_6  out_degree_1117  1
    arc_1_8_6  original_T_including_depot_unload_1182  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_872  1
    load_1_8_6  segment_load_conservation_1107  -1
    load_1_8_6  segment_prefix_lb_1108  1
    load_1_8_6  segment_prefix_ub_1109  1
    load_1_8_6  segment_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_874  -25
    arc_1_8_7  connected_order_arc_875  -13
    arc_1_8_7  in_degree_1111  1
    arc_1_8_7  out_degree_1117  1
    arc_1_8_7  original_T_including_depot_unload_1182  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_874  1
    load_1_8_7  segment_load_conservation_1114  -1
    load_1_8_7  segment_prefix_lb_1115  1
    load_1_8_7  segment_prefix_ub_1116  1
    load_1_8_7  segment_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_876  -25
    arc_1_8_9  connected_order_arc_877  -13
    arc_1_8_9  out_degree_1117  1
    arc_1_8_9  in_degree_1125  1
    arc_1_8_9  original_T_including_depot_unload_1182  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_876  1
    load_1_8_9  segment_load_conservation_1121  1
    load_1_8_9  segment_load_conservation_1128  -1
    load_1_8_9  segment_prefix_lb_1129  1
    load_1_8_9  segment_prefix_ub_1130  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_878  -25
    arc_1_8_13  connected_order_arc_879  -13
    arc_1_8_13  out_degree_1117  1
    arc_1_8_13  in_degree_1132  1
    arc_1_8_13  original_T_including_depot_unload_1182  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_878  1
    load_1_8_13  segment_load_conservation_1121  1
    load_1_8_13  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_880  -25
    arc_1_8_14  connected_order_arc_881  -13
    arc_1_8_14  out_degree_1117  1
    arc_1_8_14  in_degree_1138  1
    arc_1_8_14  original_T_including_depot_unload_1182  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_880  1
    load_1_8_14  segment_load_conservation_1121  1
    load_1_8_14  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_882  -25
    arc_1_8_15  connected_order_arc_883  -13
    arc_1_8_15  out_degree_1117  1
    arc_1_8_15  in_degree_1144  1
    arc_1_8_15  original_T_including_depot_unload_1182  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_882  1
    load_1_8_15  segment_load_conservation_1121  1
    load_1_8_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_884  -25
    arc_1_8_16  connected_order_arc_885  -13
    arc_1_8_16  out_degree_1117  1
    arc_1_8_16  in_degree_1150  1
    arc_1_8_16  original_T_including_depot_unload_1182  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_884  1
    load_1_8_16  segment_load_conservation_1121  1
    load_1_8_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_886  -25
    arc_1_8_17  connected_order_arc_887  -13
    arc_1_8_17  out_degree_1117  1
    arc_1_8_17  in_degree_1156  1
    arc_1_8_17  original_T_including_depot_unload_1182  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_886  1
    load_1_8_17  segment_load_conservation_1121  1
    load_1_8_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_888  -25
    arc_1_8_18  connected_order_arc_889  -13
    arc_1_8_18  out_degree_1117  1
    arc_1_8_18  in_degree_1162  1
    arc_1_8_18  original_T_including_depot_unload_1182  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_888  1
    load_1_8_18  segment_load_conservation_1121  1
    load_1_8_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_890  -25
    arc_1_8_19  connected_order_arc_891  -13
    arc_1_8_19  out_degree_1117  1
    arc_1_8_19  in_degree_1168  1
    arc_1_8_19  original_T_including_depot_unload_1182  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_890  1
    load_1_8_19  segment_load_conservation_1121  1
    load_1_8_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_892  -25
    arc_1_8_20  connected_order_arc_893  -13
    arc_1_8_20  out_degree_1117  1
    arc_1_8_20  in_degree_1174  1
    arc_1_8_20  original_T_including_depot_unload_1182  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_892  1
    load_1_8_20  segment_load_conservation_1121  1
    load_1_8_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_894  -25
    arc_1_9_0  depot_return_or_bypass_1102  1
    arc_1_9_0  out_degree_1124  1
    arc_1_9_0  original_T_including_depot_unload_1182  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_894  1
    load_1_9_0  segment_load_conservation_1128  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_895  -25
    arc_1_9_6  connected_order_arc_896  -13
    arc_1_9_6  in_degree_1104  1
    arc_1_9_6  out_degree_1124  1
    arc_1_9_6  original_T_including_depot_unload_1182  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_895  1
    load_1_9_6  segment_load_conservation_1107  -1
    load_1_9_6  segment_prefix_lb_1108  1
    load_1_9_6  segment_prefix_ub_1109  1
    load_1_9_6  segment_load_conservation_1128  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_897  -25
    arc_1_9_7  connected_order_arc_898  -13
    arc_1_9_7  in_degree_1111  1
    arc_1_9_7  out_degree_1124  1
    arc_1_9_7  original_T_including_depot_unload_1182  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_897  1
    load_1_9_7  segment_load_conservation_1114  -1
    load_1_9_7  segment_prefix_lb_1115  1
    load_1_9_7  segment_prefix_ub_1116  1
    load_1_9_7  segment_load_conservation_1128  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_899  -25
    arc_1_9_8  connected_order_arc_900  -13
    arc_1_9_8  in_degree_1118  1
    arc_1_9_8  out_degree_1124  1
    arc_1_9_8  original_T_including_depot_unload_1182  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_899  1
    load_1_9_8  segment_load_conservation_1121  -1
    load_1_9_8  segment_prefix_lb_1122  1
    load_1_9_8  segment_prefix_ub_1123  1
    load_1_9_8  segment_load_conservation_1128  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_901  -25
    arc_1_9_13  connected_order_arc_902  -13
    arc_1_9_13  out_degree_1124  1
    arc_1_9_13  in_degree_1132  1
    arc_1_9_13  original_T_including_depot_unload_1182  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_901  1
    load_1_9_13  segment_load_conservation_1128  1
    load_1_9_13  free_load_conservation_1136  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_903  -25
    arc_1_9_14  connected_order_arc_904  -13
    arc_1_9_14  out_degree_1124  1
    arc_1_9_14  in_degree_1138  1
    arc_1_9_14  original_T_including_depot_unload_1182  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_903  1
    load_1_9_14  segment_load_conservation_1128  1
    load_1_9_14  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_905  -25
    arc_1_9_15  connected_order_arc_906  -13
    arc_1_9_15  out_degree_1124  1
    arc_1_9_15  in_degree_1144  1
    arc_1_9_15  original_T_including_depot_unload_1182  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_905  1
    load_1_9_15  segment_load_conservation_1128  1
    load_1_9_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_907  -25
    arc_1_9_16  connected_order_arc_908  -13
    arc_1_9_16  out_degree_1124  1
    arc_1_9_16  in_degree_1150  1
    arc_1_9_16  original_T_including_depot_unload_1182  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_907  1
    load_1_9_16  segment_load_conservation_1128  1
    load_1_9_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_909  -25
    arc_1_9_17  connected_order_arc_910  -13
    arc_1_9_17  out_degree_1124  1
    arc_1_9_17  in_degree_1156  1
    arc_1_9_17  original_T_including_depot_unload_1182  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_909  1
    load_1_9_17  segment_load_conservation_1128  1
    load_1_9_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_911  -25
    arc_1_9_18  connected_order_arc_912  -13
    arc_1_9_18  out_degree_1124  1
    arc_1_9_18  in_degree_1162  1
    arc_1_9_18  original_T_including_depot_unload_1182  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_911  1
    load_1_9_18  segment_load_conservation_1128  1
    load_1_9_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_913  -25
    arc_1_9_19  connected_order_arc_914  -13
    arc_1_9_19  out_degree_1124  1
    arc_1_9_19  in_degree_1168  1
    arc_1_9_19  original_T_including_depot_unload_1182  1.9878052050440085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_913  1
    load_1_9_19  segment_load_conservation_1128  1
    load_1_9_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_915  -25
    arc_1_9_20  connected_order_arc_916  -13
    arc_1_9_20  out_degree_1124  1
    arc_1_9_20  in_degree_1174  1
    arc_1_9_20  original_T_including_depot_unload_1182  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_915  1
    load_1_9_20  segment_load_conservation_1128  1
    load_1_9_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_917  -25
    arc_1_13_0  depot_return_or_bypass_1102  1
    arc_1_13_0  out_degree_1131  1
    arc_1_13_0  original_T_including_depot_unload_1182  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_917  1
    load_1_13_0  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_918  -25
    arc_1_13_6  connected_order_arc_919  -13
    arc_1_13_6  in_degree_1104  1
    arc_1_13_6  out_degree_1131  1
    arc_1_13_6  original_T_including_depot_unload_1182  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_918  1
    load_1_13_6  segment_load_conservation_1107  -1
    load_1_13_6  segment_prefix_lb_1108  1
    load_1_13_6  segment_prefix_ub_1109  1
    load_1_13_6  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_920  -25
    arc_1_13_7  connected_order_arc_921  -13
    arc_1_13_7  in_degree_1111  1
    arc_1_13_7  out_degree_1131  1
    arc_1_13_7  original_T_including_depot_unload_1182  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_920  1
    load_1_13_7  segment_load_conservation_1114  -1
    load_1_13_7  segment_prefix_lb_1115  1
    load_1_13_7  segment_prefix_ub_1116  1
    load_1_13_7  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_922  -25
    arc_1_13_8  connected_order_arc_923  -13
    arc_1_13_8  in_degree_1118  1
    arc_1_13_8  out_degree_1131  1
    arc_1_13_8  original_T_including_depot_unload_1182  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_922  1
    load_1_13_8  segment_load_conservation_1121  -1
    load_1_13_8  segment_prefix_lb_1122  1
    load_1_13_8  segment_prefix_ub_1123  1
    load_1_13_8  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_924  -25
    arc_1_13_9  connected_order_arc_925  -13
    arc_1_13_9  in_degree_1125  1
    arc_1_13_9  out_degree_1131  1
    arc_1_13_9  original_T_including_depot_unload_1182  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_924  1
    load_1_13_9  segment_load_conservation_1128  -1
    load_1_13_9  segment_prefix_lb_1129  1
    load_1_13_9  segment_prefix_ub_1130  1
    load_1_13_9  free_load_conservation_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_926  -25
    arc_1_13_14  connected_order_arc_927  -13
    arc_1_13_14  out_degree_1131  1
    arc_1_13_14  in_degree_1138  1
    arc_1_13_14  original_T_including_depot_unload_1182  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_926  1
    load_1_13_14  free_load_conservation_1136  1
    load_1_13_14  free_load_conservation_1142  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_928  -25
    arc_1_13_15  connected_order_arc_929  -13
    arc_1_13_15  out_degree_1131  1
    arc_1_13_15  in_degree_1144  1
    arc_1_13_15  original_T_including_depot_unload_1182  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_928  1
    load_1_13_15  free_load_conservation_1136  1
    load_1_13_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_930  -25
    arc_1_13_16  connected_order_arc_931  -13
    arc_1_13_16  out_degree_1131  1
    arc_1_13_16  in_degree_1150  1
    arc_1_13_16  original_T_including_depot_unload_1182  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_930  1
    load_1_13_16  free_load_conservation_1136  1
    load_1_13_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_932  -25
    arc_1_13_17  connected_order_arc_933  -13
    arc_1_13_17  out_degree_1131  1
    arc_1_13_17  in_degree_1156  1
    arc_1_13_17  original_T_including_depot_unload_1182  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_932  1
    load_1_13_17  free_load_conservation_1136  1
    load_1_13_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_934  -25
    arc_1_13_18  connected_order_arc_935  -13
    arc_1_13_18  out_degree_1131  1
    arc_1_13_18  in_degree_1162  1
    arc_1_13_18  original_T_including_depot_unload_1182  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_934  1
    load_1_13_18  free_load_conservation_1136  1
    load_1_13_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_936  -25
    arc_1_13_19  connected_order_arc_937  -13
    arc_1_13_19  out_degree_1131  1
    arc_1_13_19  in_degree_1168  1
    arc_1_13_19  original_T_including_depot_unload_1182  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_936  1
    load_1_13_19  free_load_conservation_1136  1
    load_1_13_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_938  -25
    arc_1_13_20  connected_order_arc_939  -13
    arc_1_13_20  out_degree_1131  1
    arc_1_13_20  in_degree_1174  1
    arc_1_13_20  original_T_including_depot_unload_1182  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_938  1
    load_1_13_20  free_load_conservation_1136  1
    load_1_13_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_940  -25
    arc_1_14_0  depot_return_or_bypass_1102  1
    arc_1_14_0  out_degree_1137  1
    arc_1_14_0  original_T_including_depot_unload_1182  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_940  1
    load_1_14_0  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_941  -25
    arc_1_14_6  connected_order_arc_942  -13
    arc_1_14_6  in_degree_1104  1
    arc_1_14_6  out_degree_1137  1
    arc_1_14_6  original_T_including_depot_unload_1182  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_941  1
    load_1_14_6  segment_load_conservation_1107  -1
    load_1_14_6  segment_prefix_lb_1108  1
    load_1_14_6  segment_prefix_ub_1109  1
    load_1_14_6  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_943  -25
    arc_1_14_7  connected_order_arc_944  -13
    arc_1_14_7  in_degree_1111  1
    arc_1_14_7  out_degree_1137  1
    arc_1_14_7  original_T_including_depot_unload_1182  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_943  1
    load_1_14_7  segment_load_conservation_1114  -1
    load_1_14_7  segment_prefix_lb_1115  1
    load_1_14_7  segment_prefix_ub_1116  1
    load_1_14_7  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_945  -25
    arc_1_14_8  connected_order_arc_946  -13
    arc_1_14_8  in_degree_1118  1
    arc_1_14_8  out_degree_1137  1
    arc_1_14_8  original_T_including_depot_unload_1182  754.162661294669
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_945  1
    load_1_14_8  segment_load_conservation_1121  -1
    load_1_14_8  segment_prefix_lb_1122  1
    load_1_14_8  segment_prefix_ub_1123  1
    load_1_14_8  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_947  -25
    arc_1_14_9  connected_order_arc_948  -13
    arc_1_14_9  in_degree_1125  1
    arc_1_14_9  out_degree_1137  1
    arc_1_14_9  original_T_including_depot_unload_1182  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_947  1
    load_1_14_9  segment_load_conservation_1128  -1
    load_1_14_9  segment_prefix_lb_1129  1
    load_1_14_9  segment_prefix_ub_1130  1
    load_1_14_9  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_949  -25
    arc_1_14_13  connected_order_arc_950  -13
    arc_1_14_13  in_degree_1132  1
    arc_1_14_13  out_degree_1137  1
    arc_1_14_13  original_T_including_depot_unload_1182  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_949  1
    load_1_14_13  free_load_conservation_1136  -1
    load_1_14_13  free_load_conservation_1142  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_951  -25
    arc_1_14_15  connected_order_arc_952  -13
    arc_1_14_15  out_degree_1137  1
    arc_1_14_15  in_degree_1144  1
    arc_1_14_15  original_T_including_depot_unload_1182  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_951  1
    load_1_14_15  free_load_conservation_1142  1
    load_1_14_15  free_load_conservation_1148  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_953  -25
    arc_1_14_16  connected_order_arc_954  -13
    arc_1_14_16  out_degree_1137  1
    arc_1_14_16  in_degree_1150  1
    arc_1_14_16  original_T_including_depot_unload_1182  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_953  1
    load_1_14_16  free_load_conservation_1142  1
    load_1_14_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_955  -25
    arc_1_14_17  connected_order_arc_956  -13
    arc_1_14_17  out_degree_1137  1
    arc_1_14_17  in_degree_1156  1
    arc_1_14_17  original_T_including_depot_unload_1182  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_955  1
    load_1_14_17  free_load_conservation_1142  1
    load_1_14_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_957  -25
    arc_1_14_18  connected_order_arc_958  -13
    arc_1_14_18  out_degree_1137  1
    arc_1_14_18  in_degree_1162  1
    arc_1_14_18  original_T_including_depot_unload_1182  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_957  1
    load_1_14_18  free_load_conservation_1142  1
    load_1_14_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_959  -25
    arc_1_14_19  connected_order_arc_960  -13
    arc_1_14_19  out_degree_1137  1
    arc_1_14_19  in_degree_1168  1
    arc_1_14_19  original_T_including_depot_unload_1182  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_959  1
    load_1_14_19  free_load_conservation_1142  1
    load_1_14_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_961  -25
    arc_1_14_20  connected_order_arc_962  -13
    arc_1_14_20  out_degree_1137  1
    arc_1_14_20  in_degree_1174  1
    arc_1_14_20  original_T_including_depot_unload_1182  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_961  1
    load_1_14_20  free_load_conservation_1142  1
    load_1_14_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_963  -25
    arc_1_15_0  depot_return_or_bypass_1102  1
    arc_1_15_0  out_degree_1143  1
    arc_1_15_0  original_T_including_depot_unload_1182  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_963  1
    load_1_15_0  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_964  -25
    arc_1_15_6  connected_order_arc_965  -13
    arc_1_15_6  in_degree_1104  1
    arc_1_15_6  out_degree_1143  1
    arc_1_15_6  original_T_including_depot_unload_1182  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_964  1
    load_1_15_6  segment_load_conservation_1107  -1
    load_1_15_6  segment_prefix_lb_1108  1
    load_1_15_6  segment_prefix_ub_1109  1
    load_1_15_6  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_966  -25
    arc_1_15_7  connected_order_arc_967  -13
    arc_1_15_7  in_degree_1111  1
    arc_1_15_7  out_degree_1143  1
    arc_1_15_7  original_T_including_depot_unload_1182  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_966  1
    load_1_15_7  segment_load_conservation_1114  -1
    load_1_15_7  segment_prefix_lb_1115  1
    load_1_15_7  segment_prefix_ub_1116  1
    load_1_15_7  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_968  -25
    arc_1_15_8  connected_order_arc_969  -13
    arc_1_15_8  in_degree_1118  1
    arc_1_15_8  out_degree_1143  1
    arc_1_15_8  original_T_including_depot_unload_1182  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_968  1
    load_1_15_8  segment_load_conservation_1121  -1
    load_1_15_8  segment_prefix_lb_1122  1
    load_1_15_8  segment_prefix_ub_1123  1
    load_1_15_8  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_970  -25
    arc_1_15_9  connected_order_arc_971  -13
    arc_1_15_9  in_degree_1125  1
    arc_1_15_9  out_degree_1143  1
    arc_1_15_9  original_T_including_depot_unload_1182  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_970  1
    load_1_15_9  segment_load_conservation_1128  -1
    load_1_15_9  segment_prefix_lb_1129  1
    load_1_15_9  segment_prefix_ub_1130  1
    load_1_15_9  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_972  -25
    arc_1_15_13  connected_order_arc_973  -13
    arc_1_15_13  in_degree_1132  1
    arc_1_15_13  out_degree_1143  1
    arc_1_15_13  original_T_including_depot_unload_1182  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_972  1
    load_1_15_13  free_load_conservation_1136  -1
    load_1_15_13  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_974  -25
    arc_1_15_14  connected_order_arc_975  -13
    arc_1_15_14  in_degree_1138  1
    arc_1_15_14  out_degree_1143  1
    arc_1_15_14  original_T_including_depot_unload_1182  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_974  1
    load_1_15_14  free_load_conservation_1142  -1
    load_1_15_14  free_load_conservation_1148  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_976  -25
    arc_1_15_16  connected_order_arc_977  -13
    arc_1_15_16  out_degree_1143  1
    arc_1_15_16  in_degree_1150  1
    arc_1_15_16  original_T_including_depot_unload_1182  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_976  1
    load_1_15_16  free_load_conservation_1148  1
    load_1_15_16  free_load_conservation_1154  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_978  -25
    arc_1_15_17  connected_order_arc_979  -13
    arc_1_15_17  out_degree_1143  1
    arc_1_15_17  in_degree_1156  1
    arc_1_15_17  original_T_including_depot_unload_1182  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_978  1
    load_1_15_17  free_load_conservation_1148  1
    load_1_15_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_980  -25
    arc_1_15_18  connected_order_arc_981  -13
    arc_1_15_18  out_degree_1143  1
    arc_1_15_18  in_degree_1162  1
    arc_1_15_18  original_T_including_depot_unload_1182  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_980  1
    load_1_15_18  free_load_conservation_1148  1
    load_1_15_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_982  -25
    arc_1_15_19  connected_order_arc_983  -13
    arc_1_15_19  out_degree_1143  1
    arc_1_15_19  in_degree_1168  1
    arc_1_15_19  original_T_including_depot_unload_1182  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_982  1
    load_1_15_19  free_load_conservation_1148  1
    load_1_15_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_984  -25
    arc_1_15_20  connected_order_arc_985  -13
    arc_1_15_20  out_degree_1143  1
    arc_1_15_20  in_degree_1174  1
    arc_1_15_20  original_T_including_depot_unload_1182  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_984  1
    load_1_15_20  free_load_conservation_1148  1
    load_1_15_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_986  -25
    arc_1_16_0  depot_return_or_bypass_1102  1
    arc_1_16_0  out_degree_1149  1
    arc_1_16_0  original_T_including_depot_unload_1182  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_986  1
    load_1_16_0  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_987  -25
    arc_1_16_6  connected_order_arc_988  -13
    arc_1_16_6  in_degree_1104  1
    arc_1_16_6  out_degree_1149  1
    arc_1_16_6  original_T_including_depot_unload_1182  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_987  1
    load_1_16_6  segment_load_conservation_1107  -1
    load_1_16_6  segment_prefix_lb_1108  1
    load_1_16_6  segment_prefix_ub_1109  1
    load_1_16_6  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_989  -25
    arc_1_16_7  connected_order_arc_990  -13
    arc_1_16_7  in_degree_1111  1
    arc_1_16_7  out_degree_1149  1
    arc_1_16_7  original_T_including_depot_unload_1182  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_989  1
    load_1_16_7  segment_load_conservation_1114  -1
    load_1_16_7  segment_prefix_lb_1115  1
    load_1_16_7  segment_prefix_ub_1116  1
    load_1_16_7  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_991  -25
    arc_1_16_8  connected_order_arc_992  -13
    arc_1_16_8  in_degree_1118  1
    arc_1_16_8  out_degree_1149  1
    arc_1_16_8  original_T_including_depot_unload_1182  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_991  1
    load_1_16_8  segment_load_conservation_1121  -1
    load_1_16_8  segment_prefix_lb_1122  1
    load_1_16_8  segment_prefix_ub_1123  1
    load_1_16_8  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_993  -25
    arc_1_16_9  connected_order_arc_994  -13
    arc_1_16_9  in_degree_1125  1
    arc_1_16_9  out_degree_1149  1
    arc_1_16_9  original_T_including_depot_unload_1182  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_993  1
    load_1_16_9  segment_load_conservation_1128  -1
    load_1_16_9  segment_prefix_lb_1129  1
    load_1_16_9  segment_prefix_ub_1130  1
    load_1_16_9  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_995  -25
    arc_1_16_13  connected_order_arc_996  -13
    arc_1_16_13  in_degree_1132  1
    arc_1_16_13  out_degree_1149  1
    arc_1_16_13  original_T_including_depot_unload_1182  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_995  1
    load_1_16_13  free_load_conservation_1136  -1
    load_1_16_13  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_997  -25
    arc_1_16_14  connected_order_arc_998  -13
    arc_1_16_14  in_degree_1138  1
    arc_1_16_14  out_degree_1149  1
    arc_1_16_14  original_T_including_depot_unload_1182  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_997  1
    load_1_16_14  free_load_conservation_1142  -1
    load_1_16_14  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_999  -25
    arc_1_16_15  connected_order_arc_1000  -13
    arc_1_16_15  in_degree_1144  1
    arc_1_16_15  out_degree_1149  1
    arc_1_16_15  original_T_including_depot_unload_1182  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_999  1
    load_1_16_15  free_load_conservation_1148  -1
    load_1_16_15  free_load_conservation_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1001  -25
    arc_1_16_17  connected_order_arc_1002  -13
    arc_1_16_17  out_degree_1149  1
    arc_1_16_17  in_degree_1156  1
    arc_1_16_17  original_T_including_depot_unload_1182  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1001  1
    load_1_16_17  free_load_conservation_1154  1
    load_1_16_17  free_load_conservation_1160  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1003  -25
    arc_1_16_18  connected_order_arc_1004  -13
    arc_1_16_18  out_degree_1149  1
    arc_1_16_18  in_degree_1162  1
    arc_1_16_18  original_T_including_depot_unload_1182  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1003  1
    load_1_16_18  free_load_conservation_1154  1
    load_1_16_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1005  -25
    arc_1_16_19  connected_order_arc_1006  -13
    arc_1_16_19  out_degree_1149  1
    arc_1_16_19  in_degree_1168  1
    arc_1_16_19  original_T_including_depot_unload_1182  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1005  1
    load_1_16_19  free_load_conservation_1154  1
    load_1_16_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1007  -25
    arc_1_16_20  connected_order_arc_1008  -13
    arc_1_16_20  out_degree_1149  1
    arc_1_16_20  in_degree_1174  1
    arc_1_16_20  original_T_including_depot_unload_1182  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1007  1
    load_1_16_20  free_load_conservation_1154  1
    load_1_16_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1009  -25
    arc_1_17_0  depot_return_or_bypass_1102  1
    arc_1_17_0  out_degree_1155  1
    arc_1_17_0  original_T_including_depot_unload_1182  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1009  1
    load_1_17_0  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1010  -25
    arc_1_17_6  connected_order_arc_1011  -13
    arc_1_17_6  in_degree_1104  1
    arc_1_17_6  out_degree_1155  1
    arc_1_17_6  original_T_including_depot_unload_1182  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1010  1
    load_1_17_6  segment_load_conservation_1107  -1
    load_1_17_6  segment_prefix_lb_1108  1
    load_1_17_6  segment_prefix_ub_1109  1
    load_1_17_6  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1012  -25
    arc_1_17_7  connected_order_arc_1013  -13
    arc_1_17_7  in_degree_1111  1
    arc_1_17_7  out_degree_1155  1
    arc_1_17_7  original_T_including_depot_unload_1182  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1012  1
    load_1_17_7  segment_load_conservation_1114  -1
    load_1_17_7  segment_prefix_lb_1115  1
    load_1_17_7  segment_prefix_ub_1116  1
    load_1_17_7  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1014  -25
    arc_1_17_8  connected_order_arc_1015  -13
    arc_1_17_8  in_degree_1118  1
    arc_1_17_8  out_degree_1155  1
    arc_1_17_8  original_T_including_depot_unload_1182  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1014  1
    load_1_17_8  segment_load_conservation_1121  -1
    load_1_17_8  segment_prefix_lb_1122  1
    load_1_17_8  segment_prefix_ub_1123  1
    load_1_17_8  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1016  -25
    arc_1_17_9  connected_order_arc_1017  -13
    arc_1_17_9  in_degree_1125  1
    arc_1_17_9  out_degree_1155  1
    arc_1_17_9  original_T_including_depot_unload_1182  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1016  1
    load_1_17_9  segment_load_conservation_1128  -1
    load_1_17_9  segment_prefix_lb_1129  1
    load_1_17_9  segment_prefix_ub_1130  1
    load_1_17_9  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1018  -25
    arc_1_17_13  connected_order_arc_1019  -13
    arc_1_17_13  in_degree_1132  1
    arc_1_17_13  out_degree_1155  1
    arc_1_17_13  original_T_including_depot_unload_1182  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1018  1
    load_1_17_13  free_load_conservation_1136  -1
    load_1_17_13  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1020  -25
    arc_1_17_14  connected_order_arc_1021  -13
    arc_1_17_14  in_degree_1138  1
    arc_1_17_14  out_degree_1155  1
    arc_1_17_14  original_T_including_depot_unload_1182  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1020  1
    load_1_17_14  free_load_conservation_1142  -1
    load_1_17_14  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1022  -25
    arc_1_17_15  connected_order_arc_1023  -13
    arc_1_17_15  in_degree_1144  1
    arc_1_17_15  out_degree_1155  1
    arc_1_17_15  original_T_including_depot_unload_1182  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1022  1
    load_1_17_15  free_load_conservation_1148  -1
    load_1_17_15  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1024  -25
    arc_1_17_16  connected_order_arc_1025  -13
    arc_1_17_16  in_degree_1150  1
    arc_1_17_16  out_degree_1155  1
    arc_1_17_16  original_T_including_depot_unload_1182  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1024  1
    load_1_17_16  free_load_conservation_1154  -1
    load_1_17_16  free_load_conservation_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1026  -25
    arc_1_17_18  connected_order_arc_1027  -13
    arc_1_17_18  out_degree_1155  1
    arc_1_17_18  in_degree_1162  1
    arc_1_17_18  original_T_including_depot_unload_1182  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1026  1
    load_1_17_18  free_load_conservation_1160  1
    load_1_17_18  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1028  -25
    arc_1_17_19  connected_order_arc_1029  -13
    arc_1_17_19  out_degree_1155  1
    arc_1_17_19  in_degree_1168  1
    arc_1_17_19  original_T_including_depot_unload_1182  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1028  1
    load_1_17_19  free_load_conservation_1160  1
    load_1_17_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1030  -25
    arc_1_17_20  connected_order_arc_1031  -13
    arc_1_17_20  out_degree_1155  1
    arc_1_17_20  in_degree_1174  1
    arc_1_17_20  original_T_including_depot_unload_1182  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1030  1
    load_1_17_20  free_load_conservation_1160  1
    load_1_17_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1032  -25
    arc_1_18_0  depot_return_or_bypass_1102  1
    arc_1_18_0  out_degree_1161  1
    arc_1_18_0  original_T_including_depot_unload_1182  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1032  1
    load_1_18_0  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1033  -25
    arc_1_18_6  connected_order_arc_1034  -13
    arc_1_18_6  in_degree_1104  1
    arc_1_18_6  out_degree_1161  1
    arc_1_18_6  original_T_including_depot_unload_1182  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1033  1
    load_1_18_6  segment_load_conservation_1107  -1
    load_1_18_6  segment_prefix_lb_1108  1
    load_1_18_6  segment_prefix_ub_1109  1
    load_1_18_6  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1035  -25
    arc_1_18_7  connected_order_arc_1036  -13
    arc_1_18_7  in_degree_1111  1
    arc_1_18_7  out_degree_1161  1
    arc_1_18_7  original_T_including_depot_unload_1182  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1035  1
    load_1_18_7  segment_load_conservation_1114  -1
    load_1_18_7  segment_prefix_lb_1115  1
    load_1_18_7  segment_prefix_ub_1116  1
    load_1_18_7  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1037  -25
    arc_1_18_8  connected_order_arc_1038  -13
    arc_1_18_8  in_degree_1118  1
    arc_1_18_8  out_degree_1161  1
    arc_1_18_8  original_T_including_depot_unload_1182  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1037  1
    load_1_18_8  segment_load_conservation_1121  -1
    load_1_18_8  segment_prefix_lb_1122  1
    load_1_18_8  segment_prefix_ub_1123  1
    load_1_18_8  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1039  -25
    arc_1_18_9  connected_order_arc_1040  -13
    arc_1_18_9  in_degree_1125  1
    arc_1_18_9  out_degree_1161  1
    arc_1_18_9  original_T_including_depot_unload_1182  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1039  1
    load_1_18_9  segment_load_conservation_1128  -1
    load_1_18_9  segment_prefix_lb_1129  1
    load_1_18_9  segment_prefix_ub_1130  1
    load_1_18_9  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1041  -25
    arc_1_18_13  connected_order_arc_1042  -13
    arc_1_18_13  in_degree_1132  1
    arc_1_18_13  out_degree_1161  1
    arc_1_18_13  original_T_including_depot_unload_1182  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1041  1
    load_1_18_13  free_load_conservation_1136  -1
    load_1_18_13  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1043  -25
    arc_1_18_14  connected_order_arc_1044  -13
    arc_1_18_14  in_degree_1138  1
    arc_1_18_14  out_degree_1161  1
    arc_1_18_14  original_T_including_depot_unload_1182  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1043  1
    load_1_18_14  free_load_conservation_1142  -1
    load_1_18_14  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1045  -25
    arc_1_18_15  connected_order_arc_1046  -13
    arc_1_18_15  in_degree_1144  1
    arc_1_18_15  out_degree_1161  1
    arc_1_18_15  original_T_including_depot_unload_1182  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1045  1
    load_1_18_15  free_load_conservation_1148  -1
    load_1_18_15  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1047  -25
    arc_1_18_16  connected_order_arc_1048  -13
    arc_1_18_16  in_degree_1150  1
    arc_1_18_16  out_degree_1161  1
    arc_1_18_16  original_T_including_depot_unload_1182  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1047  1
    load_1_18_16  free_load_conservation_1154  -1
    load_1_18_16  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1049  -25
    arc_1_18_17  connected_order_arc_1050  -13
    arc_1_18_17  in_degree_1156  1
    arc_1_18_17  out_degree_1161  1
    arc_1_18_17  original_T_including_depot_unload_1182  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1049  1
    load_1_18_17  free_load_conservation_1160  -1
    load_1_18_17  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1051  -25
    arc_1_18_19  connected_order_arc_1052  -13
    arc_1_18_19  out_degree_1161  1
    arc_1_18_19  in_degree_1168  1
    arc_1_18_19  original_T_including_depot_unload_1182  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1051  1
    load_1_18_19  free_load_conservation_1166  1
    load_1_18_19  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1053  -25
    arc_1_18_20  connected_order_arc_1054  -13
    arc_1_18_20  out_degree_1161  1
    arc_1_18_20  in_degree_1174  1
    arc_1_18_20  original_T_including_depot_unload_1182  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1053  1
    load_1_18_20  free_load_conservation_1166  1
    load_1_18_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1055  -25
    arc_1_19_0  depot_return_or_bypass_1102  1
    arc_1_19_0  out_degree_1167  1
    arc_1_19_0  original_T_including_depot_unload_1182  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1055  1
    load_1_19_0  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1056  -25
    arc_1_19_6  connected_order_arc_1057  -13
    arc_1_19_6  in_degree_1104  1
    arc_1_19_6  out_degree_1167  1
    arc_1_19_6  original_T_including_depot_unload_1182  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1056  1
    load_1_19_6  segment_load_conservation_1107  -1
    load_1_19_6  segment_prefix_lb_1108  1
    load_1_19_6  segment_prefix_ub_1109  1
    load_1_19_6  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1058  -25
    arc_1_19_7  connected_order_arc_1059  -13
    arc_1_19_7  in_degree_1111  1
    arc_1_19_7  out_degree_1167  1
    arc_1_19_7  original_T_including_depot_unload_1182  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1058  1
    load_1_19_7  segment_load_conservation_1114  -1
    load_1_19_7  segment_prefix_lb_1115  1
    load_1_19_7  segment_prefix_ub_1116  1
    load_1_19_7  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1060  -25
    arc_1_19_8  connected_order_arc_1061  -13
    arc_1_19_8  in_degree_1118  1
    arc_1_19_8  out_degree_1167  1
    arc_1_19_8  original_T_including_depot_unload_1182  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1060  1
    load_1_19_8  segment_load_conservation_1121  -1
    load_1_19_8  segment_prefix_lb_1122  1
    load_1_19_8  segment_prefix_ub_1123  1
    load_1_19_8  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1062  -25
    arc_1_19_9  connected_order_arc_1063  -13
    arc_1_19_9  in_degree_1125  1
    arc_1_19_9  out_degree_1167  1
    arc_1_19_9  original_T_including_depot_unload_1182  1.9878052050440085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1062  1
    load_1_19_9  segment_load_conservation_1128  -1
    load_1_19_9  segment_prefix_lb_1129  1
    load_1_19_9  segment_prefix_ub_1130  1
    load_1_19_9  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1064  -25
    arc_1_19_13  connected_order_arc_1065  -13
    arc_1_19_13  in_degree_1132  1
    arc_1_19_13  out_degree_1167  1
    arc_1_19_13  original_T_including_depot_unload_1182  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1064  1
    load_1_19_13  free_load_conservation_1136  -1
    load_1_19_13  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1066  -25
    arc_1_19_14  connected_order_arc_1067  -13
    arc_1_19_14  in_degree_1138  1
    arc_1_19_14  out_degree_1167  1
    arc_1_19_14  original_T_including_depot_unload_1182  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1066  1
    load_1_19_14  free_load_conservation_1142  -1
    load_1_19_14  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1068  -25
    arc_1_19_15  connected_order_arc_1069  -13
    arc_1_19_15  in_degree_1144  1
    arc_1_19_15  out_degree_1167  1
    arc_1_19_15  original_T_including_depot_unload_1182  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1068  1
    load_1_19_15  free_load_conservation_1148  -1
    load_1_19_15  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1070  -25
    arc_1_19_16  connected_order_arc_1071  -13
    arc_1_19_16  in_degree_1150  1
    arc_1_19_16  out_degree_1167  1
    arc_1_19_16  original_T_including_depot_unload_1182  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1070  1
    load_1_19_16  free_load_conservation_1154  -1
    load_1_19_16  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1072  -25
    arc_1_19_17  connected_order_arc_1073  -13
    arc_1_19_17  in_degree_1156  1
    arc_1_19_17  out_degree_1167  1
    arc_1_19_17  original_T_including_depot_unload_1182  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1072  1
    load_1_19_17  free_load_conservation_1160  -1
    load_1_19_17  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1074  -25
    arc_1_19_18  connected_order_arc_1075  -13
    arc_1_19_18  in_degree_1162  1
    arc_1_19_18  out_degree_1167  1
    arc_1_19_18  original_T_including_depot_unload_1182  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1074  1
    load_1_19_18  free_load_conservation_1166  -1
    load_1_19_18  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1076  -25
    arc_1_19_20  connected_order_arc_1077  -13
    arc_1_19_20  out_degree_1167  1
    arc_1_19_20  in_degree_1174  1
    arc_1_19_20  original_T_including_depot_unload_1182  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1076  1
    load_1_19_20  free_load_conservation_1172  1
    load_1_19_20  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1078  -25
    arc_1_20_0  depot_return_or_bypass_1102  1
    arc_1_20_0  out_degree_1173  1
    arc_1_20_0  original_T_including_depot_unload_1182  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1078  1
    load_1_20_0  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1079  -25
    arc_1_20_6  connected_order_arc_1080  -13
    arc_1_20_6  in_degree_1104  1
    arc_1_20_6  out_degree_1173  1
    arc_1_20_6  original_T_including_depot_unload_1182  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1079  1
    load_1_20_6  segment_load_conservation_1107  -1
    load_1_20_6  segment_prefix_lb_1108  1
    load_1_20_6  segment_prefix_ub_1109  1
    load_1_20_6  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1081  -25
    arc_1_20_7  connected_order_arc_1082  -13
    arc_1_20_7  in_degree_1111  1
    arc_1_20_7  out_degree_1173  1
    arc_1_20_7  original_T_including_depot_unload_1182  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1081  1
    load_1_20_7  segment_load_conservation_1114  -1
    load_1_20_7  segment_prefix_lb_1115  1
    load_1_20_7  segment_prefix_ub_1116  1
    load_1_20_7  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1083  -25
    arc_1_20_8  connected_order_arc_1084  -13
    arc_1_20_8  in_degree_1118  1
    arc_1_20_8  out_degree_1173  1
    arc_1_20_8  original_T_including_depot_unload_1182  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1083  1
    load_1_20_8  segment_load_conservation_1121  -1
    load_1_20_8  segment_prefix_lb_1122  1
    load_1_20_8  segment_prefix_ub_1123  1
    load_1_20_8  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1085  -25
    arc_1_20_9  connected_order_arc_1086  -13
    arc_1_20_9  in_degree_1125  1
    arc_1_20_9  out_degree_1173  1
    arc_1_20_9  original_T_including_depot_unload_1182  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1085  1
    load_1_20_9  segment_load_conservation_1128  -1
    load_1_20_9  segment_prefix_lb_1129  1
    load_1_20_9  segment_prefix_ub_1130  1
    load_1_20_9  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1087  -25
    arc_1_20_13  connected_order_arc_1088  -13
    arc_1_20_13  in_degree_1132  1
    arc_1_20_13  out_degree_1173  1
    arc_1_20_13  original_T_including_depot_unload_1182  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1087  1
    load_1_20_13  free_load_conservation_1136  -1
    load_1_20_13  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1089  -25
    arc_1_20_14  connected_order_arc_1090  -13
    arc_1_20_14  in_degree_1138  1
    arc_1_20_14  out_degree_1173  1
    arc_1_20_14  original_T_including_depot_unload_1182  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1089  1
    load_1_20_14  free_load_conservation_1142  -1
    load_1_20_14  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1091  -25
    arc_1_20_15  connected_order_arc_1092  -13
    arc_1_20_15  in_degree_1144  1
    arc_1_20_15  out_degree_1173  1
    arc_1_20_15  original_T_including_depot_unload_1182  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1091  1
    load_1_20_15  free_load_conservation_1148  -1
    load_1_20_15  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1093  -25
    arc_1_20_16  connected_order_arc_1094  -13
    arc_1_20_16  in_degree_1150  1
    arc_1_20_16  out_degree_1173  1
    arc_1_20_16  original_T_including_depot_unload_1182  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1093  1
    load_1_20_16  free_load_conservation_1154  -1
    load_1_20_16  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1095  -25
    arc_1_20_17  connected_order_arc_1096  -13
    arc_1_20_17  in_degree_1156  1
    arc_1_20_17  out_degree_1173  1
    arc_1_20_17  original_T_including_depot_unload_1182  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1095  1
    load_1_20_17  free_load_conservation_1160  -1
    load_1_20_17  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1097  -25
    arc_1_20_18  connected_order_arc_1098  -13
    arc_1_20_18  in_degree_1162  1
    arc_1_20_18  out_degree_1173  1
    arc_1_20_18  original_T_including_depot_unload_1182  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1097  1
    load_1_20_18  free_load_conservation_1166  -1
    load_1_20_18  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1099  -25
    arc_1_20_19  connected_order_arc_1100  -13
    arc_1_20_19  in_degree_1168  1
    arc_1_20_19  out_degree_1173  1
    arc_1_20_19  original_T_including_depot_unload_1182  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1099  1
    load_1_20_19  free_load_conservation_1172  -1
    load_1_20_19  free_load_conservation_1178  1
    visit_2_10  out_degree_1428  -1
    visit_2_10  in_degree_1429  -1
    visit_2_10  order_active_lb_1430  -1
    visit_2_10  order_active_ub_1431  -11
    order_2_10  connected_order_arc_1197  -1
    order_2_10  connected_order_arc_1199  -1
    order_2_10  connected_order_arc_1201  -1
    order_2_10  connected_order_arc_1203  -1
    order_2_10  connected_order_arc_1205  -1
    order_2_10  connected_order_arc_1207  -1
    order_2_10  connected_order_arc_1209  -1
    order_2_10  connected_order_arc_1211  -1
    order_2_10  connected_order_arc_1213  -1
    order_2_10  connected_order_arc_1215  -1
    order_2_10  connected_order_arc_1218  1
    order_2_10  connected_order_arc_1239  1
    order_2_10  connected_order_arc_1260  1
    order_2_10  connected_order_arc_1281  1
    order_2_10  connected_order_arc_1302  1
    order_2_10  connected_order_arc_1323  1
    order_2_10  connected_order_arc_1344  1
    order_2_10  connected_order_arc_1365  1
    order_2_10  connected_order_arc_1386  1
    order_2_10  connected_order_arc_1407  1
    order_2_10  order_active_lb_1430  1
    order_2_10  order_active_ub_1431  1
    order_2_10  fixed_segment_relative_order_1497  -1
    visit_2_11  out_degree_1435  -1
    visit_2_11  in_degree_1436  -1
    visit_2_11  order_active_lb_1437  -1
    visit_2_11  order_active_ub_1438  -11
    order_2_11  connected_order_arc_1197  1
    order_2_11  connected_order_arc_1218  -1
    order_2_11  connected_order_arc_1220  -1
    order_2_11  connected_order_arc_1222  -1
    order_2_11  connected_order_arc_1224  -1
    order_2_11  connected_order_arc_1226  -1
    order_2_11  connected_order_arc_1228  -1
    order_2_11  connected_order_arc_1230  -1
    order_2_11  connected_order_arc_1232  -1
    order_2_11  connected_order_arc_1234  -1
    order_2_11  connected_order_arc_1236  -1
    order_2_11  connected_order_arc_1241  1
    order_2_11  connected_order_arc_1262  1
    order_2_11  connected_order_arc_1283  1
    order_2_11  connected_order_arc_1304  1
    order_2_11  connected_order_arc_1325  1
    order_2_11  connected_order_arc_1346  1
    order_2_11  connected_order_arc_1367  1
    order_2_11  connected_order_arc_1388  1
    order_2_11  connected_order_arc_1409  1
    order_2_11  order_active_lb_1437  1
    order_2_11  order_active_ub_1438  1
    order_2_11  fixed_segment_relative_order_1497  1
    order_2_11  fixed_segment_relative_order_1498  -1
    visit_2_12  out_degree_1442  -1
    visit_2_12  in_degree_1443  -1
    visit_2_12  order_active_lb_1444  -1
    visit_2_12  order_active_ub_1445  -11
    order_2_12  connected_order_arc_1199  1
    order_2_12  connected_order_arc_1220  1
    order_2_12  connected_order_arc_1239  -1
    order_2_12  connected_order_arc_1241  -1
    order_2_12  connected_order_arc_1243  -1
    order_2_12  connected_order_arc_1245  -1
    order_2_12  connected_order_arc_1247  -1
    order_2_12  connected_order_arc_1249  -1
    order_2_12  connected_order_arc_1251  -1
    order_2_12  connected_order_arc_1253  -1
    order_2_12  connected_order_arc_1255  -1
    order_2_12  connected_order_arc_1257  -1
    order_2_12  connected_order_arc_1264  1
    order_2_12  connected_order_arc_1285  1
    order_2_12  connected_order_arc_1306  1
    order_2_12  connected_order_arc_1327  1
    order_2_12  connected_order_arc_1348  1
    order_2_12  connected_order_arc_1369  1
    order_2_12  connected_order_arc_1390  1
    order_2_12  connected_order_arc_1411  1
    order_2_12  order_active_lb_1444  1
    order_2_12  order_active_ub_1445  1
    order_2_12  fixed_segment_relative_order_1498  1
    visit_2_13  out_degree_1449  -1
    visit_2_13  in_degree_1450  -1
    visit_2_13  order_active_lb_1451  -1
    visit_2_13  order_active_ub_1452  -11
    visit_2_13  service_visit_def_1453  -1
    order_2_13  connected_order_arc_1201  1
    order_2_13  connected_order_arc_1222  1
    order_2_13  connected_order_arc_1243  1
    order_2_13  connected_order_arc_1260  -1
    order_2_13  connected_order_arc_1262  -1
    order_2_13  connected_order_arc_1264  -1
    order_2_13  connected_order_arc_1266  -1
    order_2_13  connected_order_arc_1268  -1
    order_2_13  connected_order_arc_1270  -1
    order_2_13  connected_order_arc_1272  -1
    order_2_13  connected_order_arc_1274  -1
    order_2_13  connected_order_arc_1276  -1
    order_2_13  connected_order_arc_1278  -1
    order_2_13  connected_order_arc_1287  1
    order_2_13  connected_order_arc_1308  1
    order_2_13  connected_order_arc_1329  1
    order_2_13  connected_order_arc_1350  1
    order_2_13  connected_order_arc_1371  1
    order_2_13  connected_order_arc_1392  1
    order_2_13  connected_order_arc_1413  1
    order_2_13  order_active_lb_1451  1
    order_2_13  order_active_ub_1452  1
    visit_2_14  out_degree_1455  -1
    visit_2_14  in_degree_1456  -1
    visit_2_14  order_active_lb_1457  -1
    visit_2_14  order_active_ub_1458  -11
    visit_2_14  service_visit_def_1459  -1
    order_2_14  connected_order_arc_1203  1
    order_2_14  connected_order_arc_1224  1
    order_2_14  connected_order_arc_1245  1
    order_2_14  connected_order_arc_1266  1
    order_2_14  connected_order_arc_1281  -1
    order_2_14  connected_order_arc_1283  -1
    order_2_14  connected_order_arc_1285  -1
    order_2_14  connected_order_arc_1287  -1
    order_2_14  connected_order_arc_1289  -1
    order_2_14  connected_order_arc_1291  -1
    order_2_14  connected_order_arc_1293  -1
    order_2_14  connected_order_arc_1295  -1
    order_2_14  connected_order_arc_1297  -1
    order_2_14  connected_order_arc_1299  -1
    order_2_14  connected_order_arc_1310  1
    order_2_14  connected_order_arc_1331  1
    order_2_14  connected_order_arc_1352  1
    order_2_14  connected_order_arc_1373  1
    order_2_14  connected_order_arc_1394  1
    order_2_14  connected_order_arc_1415  1
    order_2_14  order_active_lb_1457  1
    order_2_14  order_active_ub_1458  1
    visit_2_15  out_degree_1461  -1
    visit_2_15  in_degree_1462  -1
    visit_2_15  order_active_lb_1463  -1
    visit_2_15  order_active_ub_1464  -11
    visit_2_15  service_visit_def_1465  -1
    order_2_15  connected_order_arc_1205  1
    order_2_15  connected_order_arc_1226  1
    order_2_15  connected_order_arc_1247  1
    order_2_15  connected_order_arc_1268  1
    order_2_15  connected_order_arc_1289  1
    order_2_15  connected_order_arc_1302  -1
    order_2_15  connected_order_arc_1304  -1
    order_2_15  connected_order_arc_1306  -1
    order_2_15  connected_order_arc_1308  -1
    order_2_15  connected_order_arc_1310  -1
    order_2_15  connected_order_arc_1312  -1
    order_2_15  connected_order_arc_1314  -1
    order_2_15  connected_order_arc_1316  -1
    order_2_15  connected_order_arc_1318  -1
    order_2_15  connected_order_arc_1320  -1
    order_2_15  connected_order_arc_1333  1
    order_2_15  connected_order_arc_1354  1
    order_2_15  connected_order_arc_1375  1
    order_2_15  connected_order_arc_1396  1
    order_2_15  connected_order_arc_1417  1
    order_2_15  order_active_lb_1463  1
    order_2_15  order_active_ub_1464  1
    visit_2_16  out_degree_1467  -1
    visit_2_16  in_degree_1468  -1
    visit_2_16  order_active_lb_1469  -1
    visit_2_16  order_active_ub_1470  -11
    visit_2_16  service_visit_def_1471  -1
    order_2_16  connected_order_arc_1207  1
    order_2_16  connected_order_arc_1228  1
    order_2_16  connected_order_arc_1249  1
    order_2_16  connected_order_arc_1270  1
    order_2_16  connected_order_arc_1291  1
    order_2_16  connected_order_arc_1312  1
    order_2_16  connected_order_arc_1323  -1
    order_2_16  connected_order_arc_1325  -1
    order_2_16  connected_order_arc_1327  -1
    order_2_16  connected_order_arc_1329  -1
    order_2_16  connected_order_arc_1331  -1
    order_2_16  connected_order_arc_1333  -1
    order_2_16  connected_order_arc_1335  -1
    order_2_16  connected_order_arc_1337  -1
    order_2_16  connected_order_arc_1339  -1
    order_2_16  connected_order_arc_1341  -1
    order_2_16  connected_order_arc_1356  1
    order_2_16  connected_order_arc_1377  1
    order_2_16  connected_order_arc_1398  1
    order_2_16  connected_order_arc_1419  1
    order_2_16  order_active_lb_1469  1
    order_2_16  order_active_ub_1470  1
    visit_2_17  out_degree_1473  -1
    visit_2_17  in_degree_1474  -1
    visit_2_17  order_active_lb_1475  -1
    visit_2_17  order_active_ub_1476  -11
    visit_2_17  service_visit_def_1477  -1
    order_2_17  connected_order_arc_1209  1
    order_2_17  connected_order_arc_1230  1
    order_2_17  connected_order_arc_1251  1
    order_2_17  connected_order_arc_1272  1
    order_2_17  connected_order_arc_1293  1
    order_2_17  connected_order_arc_1314  1
    order_2_17  connected_order_arc_1335  1
    order_2_17  connected_order_arc_1344  -1
    order_2_17  connected_order_arc_1346  -1
    order_2_17  connected_order_arc_1348  -1
    order_2_17  connected_order_arc_1350  -1
    order_2_17  connected_order_arc_1352  -1
    order_2_17  connected_order_arc_1354  -1
    order_2_17  connected_order_arc_1356  -1
    order_2_17  connected_order_arc_1358  -1
    order_2_17  connected_order_arc_1360  -1
    order_2_17  connected_order_arc_1362  -1
    order_2_17  connected_order_arc_1379  1
    order_2_17  connected_order_arc_1400  1
    order_2_17  connected_order_arc_1421  1
    order_2_17  order_active_lb_1475  1
    order_2_17  order_active_ub_1476  1
    visit_2_18  out_degree_1479  -1
    visit_2_18  in_degree_1480  -1
    visit_2_18  order_active_lb_1481  -1
    visit_2_18  order_active_ub_1482  -11
    visit_2_18  service_visit_def_1483  -1
    order_2_18  connected_order_arc_1211  1
    order_2_18  connected_order_arc_1232  1
    order_2_18  connected_order_arc_1253  1
    order_2_18  connected_order_arc_1274  1
    order_2_18  connected_order_arc_1295  1
    order_2_18  connected_order_arc_1316  1
    order_2_18  connected_order_arc_1337  1
    order_2_18  connected_order_arc_1358  1
    order_2_18  connected_order_arc_1365  -1
    order_2_18  connected_order_arc_1367  -1
    order_2_18  connected_order_arc_1369  -1
    order_2_18  connected_order_arc_1371  -1
    order_2_18  connected_order_arc_1373  -1
    order_2_18  connected_order_arc_1375  -1
    order_2_18  connected_order_arc_1377  -1
    order_2_18  connected_order_arc_1379  -1
    order_2_18  connected_order_arc_1381  -1
    order_2_18  connected_order_arc_1383  -1
    order_2_18  connected_order_arc_1402  1
    order_2_18  connected_order_arc_1423  1
    order_2_18  order_active_lb_1481  1
    order_2_18  order_active_ub_1482  1
    visit_2_19  out_degree_1485  -1
    visit_2_19  in_degree_1486  -1
    visit_2_19  order_active_lb_1487  -1
    visit_2_19  order_active_ub_1488  -11
    visit_2_19  service_visit_def_1489  -1
    order_2_19  connected_order_arc_1213  1
    order_2_19  connected_order_arc_1234  1
    order_2_19  connected_order_arc_1255  1
    order_2_19  connected_order_arc_1276  1
    order_2_19  connected_order_arc_1297  1
    order_2_19  connected_order_arc_1318  1
    order_2_19  connected_order_arc_1339  1
    order_2_19  connected_order_arc_1360  1
    order_2_19  connected_order_arc_1381  1
    order_2_19  connected_order_arc_1386  -1
    order_2_19  connected_order_arc_1388  -1
    order_2_19  connected_order_arc_1390  -1
    order_2_19  connected_order_arc_1392  -1
    order_2_19  connected_order_arc_1394  -1
    order_2_19  connected_order_arc_1396  -1
    order_2_19  connected_order_arc_1398  -1
    order_2_19  connected_order_arc_1400  -1
    order_2_19  connected_order_arc_1402  -1
    order_2_19  connected_order_arc_1404  -1
    order_2_19  connected_order_arc_1425  1
    order_2_19  order_active_lb_1487  1
    order_2_19  order_active_ub_1488  1
    visit_2_20  out_degree_1491  -1
    visit_2_20  in_degree_1492  -1
    visit_2_20  order_active_lb_1493  -1
    visit_2_20  order_active_ub_1494  -11
    visit_2_20  service_visit_def_1495  -1
    order_2_20  connected_order_arc_1215  1
    order_2_20  connected_order_arc_1236  1
    order_2_20  connected_order_arc_1257  1
    order_2_20  connected_order_arc_1278  1
    order_2_20  connected_order_arc_1299  1
    order_2_20  connected_order_arc_1320  1
    order_2_20  connected_order_arc_1341  1
    order_2_20  connected_order_arc_1362  1
    order_2_20  connected_order_arc_1383  1
    order_2_20  connected_order_arc_1404  1
    order_2_20  connected_order_arc_1407  -1
    order_2_20  connected_order_arc_1409  -1
    order_2_20  connected_order_arc_1411  -1
    order_2_20  connected_order_arc_1413  -1
    order_2_20  connected_order_arc_1415  -1
    order_2_20  connected_order_arc_1417  -1
    order_2_20  connected_order_arc_1419  -1
    order_2_20  connected_order_arc_1421  -1
    order_2_20  connected_order_arc_1423  -1
    order_2_20  connected_order_arc_1425  -1
    order_2_20  order_active_lb_1493  1
    order_2_20  order_active_ub_1494  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1183  -30
    arc_2_0_0  depot_departure_or_bypass_1426  1
    arc_2_0_0  depot_return_or_bypass_1427  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1184  -30
    arc_2_0_10  depot_departure_or_bypass_1426  1
    arc_2_0_10  in_degree_1429  1
    arc_2_0_10  original_T_including_depot_unload_1499  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1184  1
    load_2_0_10  segment_load_conservation_1432  -1
    load_2_0_10  segment_prefix_lb_1433  1
    load_2_0_10  segment_prefix_ub_1434  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1185  -30
    arc_2_0_11  depot_departure_or_bypass_1426  1
    arc_2_0_11  in_degree_1436  1
    arc_2_0_11  original_T_including_depot_unload_1499  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1185  1
    load_2_0_11  segment_load_conservation_1439  -1
    load_2_0_11  segment_prefix_lb_1440  1
    load_2_0_11  segment_prefix_ub_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1186  -30
    arc_2_0_12  depot_departure_or_bypass_1426  1
    arc_2_0_12  in_degree_1443  1
    arc_2_0_12  original_T_including_depot_unload_1499  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1186  1
    load_2_0_12  segment_load_conservation_1446  -1
    load_2_0_12  segment_prefix_lb_1447  1
    load_2_0_12  segment_prefix_ub_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1187  -30
    arc_2_0_13  depot_departure_or_bypass_1426  1
    arc_2_0_13  in_degree_1450  1
    arc_2_0_13  original_T_including_depot_unload_1499  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1187  1
    load_2_0_13  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1188  -30
    arc_2_0_14  depot_departure_or_bypass_1426  1
    arc_2_0_14  in_degree_1456  1
    arc_2_0_14  original_T_including_depot_unload_1499  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1188  1
    load_2_0_14  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1189  -30
    arc_2_0_15  depot_departure_or_bypass_1426  1
    arc_2_0_15  in_degree_1462  1
    arc_2_0_15  original_T_including_depot_unload_1499  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1189  1
    load_2_0_15  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1190  -30
    arc_2_0_16  depot_departure_or_bypass_1426  1
    arc_2_0_16  in_degree_1468  1
    arc_2_0_16  original_T_including_depot_unload_1499  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1190  1
    load_2_0_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1191  -30
    arc_2_0_17  depot_departure_or_bypass_1426  1
    arc_2_0_17  in_degree_1474  1
    arc_2_0_17  original_T_including_depot_unload_1499  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1191  1
    load_2_0_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1192  -30
    arc_2_0_18  depot_departure_or_bypass_1426  1
    arc_2_0_18  in_degree_1480  1
    arc_2_0_18  original_T_including_depot_unload_1499  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1192  1
    load_2_0_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1193  -30
    arc_2_0_19  depot_departure_or_bypass_1426  1
    arc_2_0_19  in_degree_1486  1
    arc_2_0_19  original_T_including_depot_unload_1499  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1193  1
    load_2_0_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1194  -30
    arc_2_0_20  depot_departure_or_bypass_1426  1
    arc_2_0_20  in_degree_1492  1
    arc_2_0_20  original_T_including_depot_unload_1499  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1194  1
    load_2_0_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1195  -30
    arc_2_10_0  depot_return_or_bypass_1427  1
    arc_2_10_0  out_degree_1428  1
    arc_2_10_0  original_T_including_depot_unload_1499  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1195  1
    load_2_10_0  segment_load_conservation_1432  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1196  -30
    arc_2_10_11  connected_order_arc_1197  -12
    arc_2_10_11  out_degree_1428  1
    arc_2_10_11  in_degree_1436  1
    arc_2_10_11  original_T_including_depot_unload_1499  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1196  1
    load_2_10_11  segment_load_conservation_1432  1
    load_2_10_11  segment_load_conservation_1439  -1
    load_2_10_11  segment_prefix_lb_1440  1
    load_2_10_11  segment_prefix_ub_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1198  -30
    arc_2_10_12  connected_order_arc_1199  -12
    arc_2_10_12  out_degree_1428  1
    arc_2_10_12  in_degree_1443  1
    arc_2_10_12  original_T_including_depot_unload_1499  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1198  1
    load_2_10_12  segment_load_conservation_1432  1
    load_2_10_12  segment_load_conservation_1446  -1
    load_2_10_12  segment_prefix_lb_1447  1
    load_2_10_12  segment_prefix_ub_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1200  -30
    arc_2_10_13  connected_order_arc_1201  -12
    arc_2_10_13  out_degree_1428  1
    arc_2_10_13  in_degree_1450  1
    arc_2_10_13  original_T_including_depot_unload_1499  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1200  1
    load_2_10_13  segment_load_conservation_1432  1
    load_2_10_13  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1202  -30
    arc_2_10_14  connected_order_arc_1203  -12
    arc_2_10_14  out_degree_1428  1
    arc_2_10_14  in_degree_1456  1
    arc_2_10_14  original_T_including_depot_unload_1499  1.5942479163822793e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1202  1
    load_2_10_14  segment_load_conservation_1432  1
    load_2_10_14  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1204  -30
    arc_2_10_15  connected_order_arc_1205  -12
    arc_2_10_15  out_degree_1428  1
    arc_2_10_15  in_degree_1462  1
    arc_2_10_15  original_T_including_depot_unload_1499  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1204  1
    load_2_10_15  segment_load_conservation_1432  1
    load_2_10_15  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1206  -30
    arc_2_10_16  connected_order_arc_1207  -12
    arc_2_10_16  out_degree_1428  1
    arc_2_10_16  in_degree_1468  1
    arc_2_10_16  original_T_including_depot_unload_1499  1.6987268512568291e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1206  1
    load_2_10_16  segment_load_conservation_1432  1
    load_2_10_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1208  -30
    arc_2_10_17  connected_order_arc_1209  -12
    arc_2_10_17  out_degree_1428  1
    arc_2_10_17  in_degree_1474  1
    arc_2_10_17  original_T_including_depot_unload_1499  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1208  1
    load_2_10_17  segment_load_conservation_1432  1
    load_2_10_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1210  -30
    arc_2_10_18  connected_order_arc_1211  -12
    arc_2_10_18  out_degree_1428  1
    arc_2_10_18  in_degree_1480  1
    arc_2_10_18  original_T_including_depot_unload_1499  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1210  1
    load_2_10_18  segment_load_conservation_1432  1
    load_2_10_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1212  -30
    arc_2_10_19  connected_order_arc_1213  -12
    arc_2_10_19  out_degree_1428  1
    arc_2_10_19  in_degree_1486  1
    arc_2_10_19  original_T_including_depot_unload_1499  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1212  1
    load_2_10_19  segment_load_conservation_1432  1
    load_2_10_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1214  -30
    arc_2_10_20  connected_order_arc_1215  -12
    arc_2_10_20  out_degree_1428  1
    arc_2_10_20  in_degree_1492  1
    arc_2_10_20  original_T_including_depot_unload_1499  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1214  1
    load_2_10_20  segment_load_conservation_1432  1
    load_2_10_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1216  -30
    arc_2_11_0  depot_return_or_bypass_1427  1
    arc_2_11_0  out_degree_1435  1
    arc_2_11_0  original_T_including_depot_unload_1499  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1216  1
    load_2_11_0  segment_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1217  -30
    arc_2_11_10  connected_order_arc_1218  -12
    arc_2_11_10  in_degree_1429  1
    arc_2_11_10  out_degree_1435  1
    arc_2_11_10  original_T_including_depot_unload_1499  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1217  1
    load_2_11_10  segment_load_conservation_1432  -1
    load_2_11_10  segment_prefix_lb_1433  1
    load_2_11_10  segment_prefix_ub_1434  1
    load_2_11_10  segment_load_conservation_1439  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1219  -30
    arc_2_11_12  connected_order_arc_1220  -12
    arc_2_11_12  out_degree_1435  1
    arc_2_11_12  in_degree_1443  1
    arc_2_11_12  original_T_including_depot_unload_1499  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1219  1
    load_2_11_12  segment_load_conservation_1439  1
    load_2_11_12  segment_load_conservation_1446  -1
    load_2_11_12  segment_prefix_lb_1447  1
    load_2_11_12  segment_prefix_ub_1448  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1221  -30
    arc_2_11_13  connected_order_arc_1222  -12
    arc_2_11_13  out_degree_1435  1
    arc_2_11_13  in_degree_1450  1
    arc_2_11_13  original_T_including_depot_unload_1499  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1221  1
    load_2_11_13  segment_load_conservation_1439  1
    load_2_11_13  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1223  -30
    arc_2_11_14  connected_order_arc_1224  -12
    arc_2_11_14  out_degree_1435  1
    arc_2_11_14  in_degree_1456  1
    arc_2_11_14  original_T_including_depot_unload_1499  2.2630748095713293e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1223  1
    load_2_11_14  segment_load_conservation_1439  1
    load_2_11_14  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1225  -30
    arc_2_11_15  connected_order_arc_1226  -12
    arc_2_11_15  out_degree_1435  1
    arc_2_11_15  in_degree_1462  1
    arc_2_11_15  original_T_including_depot_unload_1499  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1225  1
    load_2_11_15  segment_load_conservation_1439  1
    load_2_11_15  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1227  -30
    arc_2_11_16  connected_order_arc_1228  -12
    arc_2_11_16  out_degree_1435  1
    arc_2_11_16  in_degree_1468  1
    arc_2_11_16  original_T_including_depot_unload_1499  2.3467684203287868e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1227  1
    load_2_11_16  segment_load_conservation_1439  1
    load_2_11_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1229  -30
    arc_2_11_17  connected_order_arc_1230  -12
    arc_2_11_17  out_degree_1435  1
    arc_2_11_17  in_degree_1474  1
    arc_2_11_17  original_T_including_depot_unload_1499  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1229  1
    load_2_11_17  segment_load_conservation_1439  1
    load_2_11_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1231  -30
    arc_2_11_18  connected_order_arc_1232  -12
    arc_2_11_18  out_degree_1435  1
    arc_2_11_18  in_degree_1480  1
    arc_2_11_18  original_T_including_depot_unload_1499  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1231  1
    load_2_11_18  segment_load_conservation_1439  1
    load_2_11_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1233  -30
    arc_2_11_19  connected_order_arc_1234  -12
    arc_2_11_19  out_degree_1435  1
    arc_2_11_19  in_degree_1486  1
    arc_2_11_19  original_T_including_depot_unload_1499  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1233  1
    load_2_11_19  segment_load_conservation_1439  1
    load_2_11_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1235  -30
    arc_2_11_20  connected_order_arc_1236  -12
    arc_2_11_20  out_degree_1435  1
    arc_2_11_20  in_degree_1492  1
    arc_2_11_20  original_T_including_depot_unload_1499  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1235  1
    load_2_11_20  segment_load_conservation_1439  1
    load_2_11_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1237  -30
    arc_2_12_0  depot_return_or_bypass_1427  1
    arc_2_12_0  out_degree_1442  1
    arc_2_12_0  original_T_including_depot_unload_1499  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1237  1
    load_2_12_0  segment_load_conservation_1446  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1238  -30
    arc_2_12_10  connected_order_arc_1239  -12
    arc_2_12_10  in_degree_1429  1
    arc_2_12_10  out_degree_1442  1
    arc_2_12_10  original_T_including_depot_unload_1499  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1238  1
    load_2_12_10  segment_load_conservation_1432  -1
    load_2_12_10  segment_prefix_lb_1433  1
    load_2_12_10  segment_prefix_ub_1434  1
    load_2_12_10  segment_load_conservation_1446  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1240  -30
    arc_2_12_11  connected_order_arc_1241  -12
    arc_2_12_11  in_degree_1436  1
    arc_2_12_11  out_degree_1442  1
    arc_2_12_11  original_T_including_depot_unload_1499  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1240  1
    load_2_12_11  segment_load_conservation_1439  -1
    load_2_12_11  segment_prefix_lb_1440  1
    load_2_12_11  segment_prefix_ub_1441  1
    load_2_12_11  segment_load_conservation_1446  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1242  -30
    arc_2_12_13  connected_order_arc_1243  -12
    arc_2_12_13  out_degree_1442  1
    arc_2_12_13  in_degree_1450  1
    arc_2_12_13  original_T_including_depot_unload_1499  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1242  1
    load_2_12_13  segment_load_conservation_1446  1
    load_2_12_13  free_load_conservation_1454  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1244  -30
    arc_2_12_14  connected_order_arc_1245  -12
    arc_2_12_14  out_degree_1442  1
    arc_2_12_14  in_degree_1456  1
    arc_2_12_14  original_T_including_depot_unload_1499  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1244  1
    load_2_12_14  segment_load_conservation_1446  1
    load_2_12_14  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1246  -30
    arc_2_12_15  connected_order_arc_1247  -12
    arc_2_12_15  out_degree_1442  1
    arc_2_12_15  in_degree_1462  1
    arc_2_12_15  original_T_including_depot_unload_1499  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1246  1
    load_2_12_15  segment_load_conservation_1446  1
    load_2_12_15  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1248  -30
    arc_2_12_16  connected_order_arc_1249  -12
    arc_2_12_16  out_degree_1442  1
    arc_2_12_16  in_degree_1468  1
    arc_2_12_16  original_T_including_depot_unload_1499  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1248  1
    load_2_12_16  segment_load_conservation_1446  1
    load_2_12_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1250  -30
    arc_2_12_17  connected_order_arc_1251  -12
    arc_2_12_17  out_degree_1442  1
    arc_2_12_17  in_degree_1474  1
    arc_2_12_17  original_T_including_depot_unload_1499  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1250  1
    load_2_12_17  segment_load_conservation_1446  1
    load_2_12_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1252  -30
    arc_2_12_18  connected_order_arc_1253  -12
    arc_2_12_18  out_degree_1442  1
    arc_2_12_18  in_degree_1480  1
    arc_2_12_18  original_T_including_depot_unload_1499  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1252  1
    load_2_12_18  segment_load_conservation_1446  1
    load_2_12_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1254  -30
    arc_2_12_19  connected_order_arc_1255  -12
    arc_2_12_19  out_degree_1442  1
    arc_2_12_19  in_degree_1486  1
    arc_2_12_19  original_T_including_depot_unload_1499  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1254  1
    load_2_12_19  segment_load_conservation_1446  1
    load_2_12_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1256  -30
    arc_2_12_20  connected_order_arc_1257  -12
    arc_2_12_20  out_degree_1442  1
    arc_2_12_20  in_degree_1492  1
    arc_2_12_20  original_T_including_depot_unload_1499  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1256  1
    load_2_12_20  segment_load_conservation_1446  1
    load_2_12_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1258  -30
    arc_2_13_0  depot_return_or_bypass_1427  1
    arc_2_13_0  out_degree_1449  1
    arc_2_13_0  original_T_including_depot_unload_1499  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1258  1
    load_2_13_0  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1259  -30
    arc_2_13_10  connected_order_arc_1260  -12
    arc_2_13_10  in_degree_1429  1
    arc_2_13_10  out_degree_1449  1
    arc_2_13_10  original_T_including_depot_unload_1499  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1259  1
    load_2_13_10  segment_load_conservation_1432  -1
    load_2_13_10  segment_prefix_lb_1433  1
    load_2_13_10  segment_prefix_ub_1434  1
    load_2_13_10  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1261  -30
    arc_2_13_11  connected_order_arc_1262  -12
    arc_2_13_11  in_degree_1436  1
    arc_2_13_11  out_degree_1449  1
    arc_2_13_11  original_T_including_depot_unload_1499  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1261  1
    load_2_13_11  segment_load_conservation_1439  -1
    load_2_13_11  segment_prefix_lb_1440  1
    load_2_13_11  segment_prefix_ub_1441  1
    load_2_13_11  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1263  -30
    arc_2_13_12  connected_order_arc_1264  -12
    arc_2_13_12  in_degree_1443  1
    arc_2_13_12  out_degree_1449  1
    arc_2_13_12  original_T_including_depot_unload_1499  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1263  1
    load_2_13_12  segment_load_conservation_1446  -1
    load_2_13_12  segment_prefix_lb_1447  1
    load_2_13_12  segment_prefix_ub_1448  1
    load_2_13_12  free_load_conservation_1454  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1265  -30
    arc_2_13_14  connected_order_arc_1266  -12
    arc_2_13_14  out_degree_1449  1
    arc_2_13_14  in_degree_1456  1
    arc_2_13_14  original_T_including_depot_unload_1499  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1265  1
    load_2_13_14  free_load_conservation_1454  1
    load_2_13_14  free_load_conservation_1460  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1267  -30
    arc_2_13_15  connected_order_arc_1268  -12
    arc_2_13_15  out_degree_1449  1
    arc_2_13_15  in_degree_1462  1
    arc_2_13_15  original_T_including_depot_unload_1499  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1267  1
    load_2_13_15  free_load_conservation_1454  1
    load_2_13_15  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1269  -30
    arc_2_13_16  connected_order_arc_1270  -12
    arc_2_13_16  out_degree_1449  1
    arc_2_13_16  in_degree_1468  1
    arc_2_13_16  original_T_including_depot_unload_1499  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1269  1
    load_2_13_16  free_load_conservation_1454  1
    load_2_13_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1271  -30
    arc_2_13_17  connected_order_arc_1272  -12
    arc_2_13_17  out_degree_1449  1
    arc_2_13_17  in_degree_1474  1
    arc_2_13_17  original_T_including_depot_unload_1499  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1271  1
    load_2_13_17  free_load_conservation_1454  1
    load_2_13_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1273  -30
    arc_2_13_18  connected_order_arc_1274  -12
    arc_2_13_18  out_degree_1449  1
    arc_2_13_18  in_degree_1480  1
    arc_2_13_18  original_T_including_depot_unload_1499  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1273  1
    load_2_13_18  free_load_conservation_1454  1
    load_2_13_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1275  -30
    arc_2_13_19  connected_order_arc_1276  -12
    arc_2_13_19  out_degree_1449  1
    arc_2_13_19  in_degree_1486  1
    arc_2_13_19  original_T_including_depot_unload_1499  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1275  1
    load_2_13_19  free_load_conservation_1454  1
    load_2_13_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1277  -30
    arc_2_13_20  connected_order_arc_1278  -12
    arc_2_13_20  out_degree_1449  1
    arc_2_13_20  in_degree_1492  1
    arc_2_13_20  original_T_including_depot_unload_1499  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1277  1
    load_2_13_20  free_load_conservation_1454  1
    load_2_13_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1279  -30
    arc_2_14_0  depot_return_or_bypass_1427  1
    arc_2_14_0  out_degree_1455  1
    arc_2_14_0  original_T_including_depot_unload_1499  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1279  1
    load_2_14_0  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1280  -30
    arc_2_14_10  connected_order_arc_1281  -12
    arc_2_14_10  in_degree_1429  1
    arc_2_14_10  out_degree_1455  1
    arc_2_14_10  original_T_including_depot_unload_1499  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1280  1
    load_2_14_10  segment_load_conservation_1432  -1
    load_2_14_10  segment_prefix_lb_1433  1
    load_2_14_10  segment_prefix_ub_1434  1
    load_2_14_10  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1282  -30
    arc_2_14_11  connected_order_arc_1283  -12
    arc_2_14_11  in_degree_1436  1
    arc_2_14_11  out_degree_1455  1
    arc_2_14_11  original_T_including_depot_unload_1499  2.1139218026901112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1282  1
    load_2_14_11  segment_load_conservation_1439  -1
    load_2_14_11  segment_prefix_lb_1440  1
    load_2_14_11  segment_prefix_ub_1441  1
    load_2_14_11  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1284  -30
    arc_2_14_12  connected_order_arc_1285  -12
    arc_2_14_12  in_degree_1443  1
    arc_2_14_12  out_degree_1455  1
    arc_2_14_12  original_T_including_depot_unload_1499  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1284  1
    load_2_14_12  segment_load_conservation_1446  -1
    load_2_14_12  segment_prefix_lb_1447  1
    load_2_14_12  segment_prefix_ub_1448  1
    load_2_14_12  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1286  -30
    arc_2_14_13  connected_order_arc_1287  -12
    arc_2_14_13  in_degree_1450  1
    arc_2_14_13  out_degree_1455  1
    arc_2_14_13  original_T_including_depot_unload_1499  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1286  1
    load_2_14_13  free_load_conservation_1454  -1
    load_2_14_13  free_load_conservation_1460  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1288  -30
    arc_2_14_15  connected_order_arc_1289  -12
    arc_2_14_15  out_degree_1455  1
    arc_2_14_15  in_degree_1462  1
    arc_2_14_15  original_T_including_depot_unload_1499  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1288  1
    load_2_14_15  free_load_conservation_1460  1
    load_2_14_15  free_load_conservation_1466  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1290  -30
    arc_2_14_16  connected_order_arc_1291  -12
    arc_2_14_16  out_degree_1455  1
    arc_2_14_16  in_degree_1468  1
    arc_2_14_16  original_T_including_depot_unload_1499  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1290  1
    load_2_14_16  free_load_conservation_1460  1
    load_2_14_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1292  -30
    arc_2_14_17  connected_order_arc_1293  -12
    arc_2_14_17  out_degree_1455  1
    arc_2_14_17  in_degree_1474  1
    arc_2_14_17  original_T_including_depot_unload_1499  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1292  1
    load_2_14_17  free_load_conservation_1460  1
    load_2_14_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1294  -30
    arc_2_14_18  connected_order_arc_1295  -12
    arc_2_14_18  out_degree_1455  1
    arc_2_14_18  in_degree_1480  1
    arc_2_14_18  original_T_including_depot_unload_1499  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1294  1
    load_2_14_18  free_load_conservation_1460  1
    load_2_14_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1296  -30
    arc_2_14_19  connected_order_arc_1297  -12
    arc_2_14_19  out_degree_1455  1
    arc_2_14_19  in_degree_1486  1
    arc_2_14_19  original_T_including_depot_unload_1499  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1296  1
    load_2_14_19  free_load_conservation_1460  1
    load_2_14_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1298  -30
    arc_2_14_20  connected_order_arc_1299  -12
    arc_2_14_20  out_degree_1455  1
    arc_2_14_20  in_degree_1492  1
    arc_2_14_20  original_T_including_depot_unload_1499  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1298  1
    load_2_14_20  free_load_conservation_1460  1
    load_2_14_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1300  -30
    arc_2_15_0  depot_return_or_bypass_1427  1
    arc_2_15_0  out_degree_1461  1
    arc_2_15_0  original_T_including_depot_unload_1499  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1300  1
    load_2_15_0  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1301  -30
    arc_2_15_10  connected_order_arc_1302  -12
    arc_2_15_10  in_degree_1429  1
    arc_2_15_10  out_degree_1461  1
    arc_2_15_10  original_T_including_depot_unload_1499  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1301  1
    load_2_15_10  segment_load_conservation_1432  -1
    load_2_15_10  segment_prefix_lb_1433  1
    load_2_15_10  segment_prefix_ub_1434  1
    load_2_15_10  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1303  -30
    arc_2_15_11  connected_order_arc_1304  -12
    arc_2_15_11  in_degree_1436  1
    arc_2_15_11  out_degree_1461  1
    arc_2_15_11  original_T_including_depot_unload_1499  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1303  1
    load_2_15_11  segment_load_conservation_1439  -1
    load_2_15_11  segment_prefix_lb_1440  1
    load_2_15_11  segment_prefix_ub_1441  1
    load_2_15_11  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1305  -30
    arc_2_15_12  connected_order_arc_1306  -12
    arc_2_15_12  in_degree_1443  1
    arc_2_15_12  out_degree_1461  1
    arc_2_15_12  original_T_including_depot_unload_1499  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1305  1
    load_2_15_12  segment_load_conservation_1446  -1
    load_2_15_12  segment_prefix_lb_1447  1
    load_2_15_12  segment_prefix_ub_1448  1
    load_2_15_12  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1307  -30
    arc_2_15_13  connected_order_arc_1308  -12
    arc_2_15_13  in_degree_1450  1
    arc_2_15_13  out_degree_1461  1
    arc_2_15_13  original_T_including_depot_unload_1499  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1307  1
    load_2_15_13  free_load_conservation_1454  -1
    load_2_15_13  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1309  -30
    arc_2_15_14  connected_order_arc_1310  -12
    arc_2_15_14  in_degree_1456  1
    arc_2_15_14  out_degree_1461  1
    arc_2_15_14  original_T_including_depot_unload_1499  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1309  1
    load_2_15_14  free_load_conservation_1460  -1
    load_2_15_14  free_load_conservation_1466  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1311  -30
    arc_2_15_16  connected_order_arc_1312  -12
    arc_2_15_16  out_degree_1461  1
    arc_2_15_16  in_degree_1468  1
    arc_2_15_16  original_T_including_depot_unload_1499  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1311  1
    load_2_15_16  free_load_conservation_1466  1
    load_2_15_16  free_load_conservation_1472  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1313  -30
    arc_2_15_17  connected_order_arc_1314  -12
    arc_2_15_17  out_degree_1461  1
    arc_2_15_17  in_degree_1474  1
    arc_2_15_17  original_T_including_depot_unload_1499  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1313  1
    load_2_15_17  free_load_conservation_1466  1
    load_2_15_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1315  -30
    arc_2_15_18  connected_order_arc_1316  -12
    arc_2_15_18  out_degree_1461  1
    arc_2_15_18  in_degree_1480  1
    arc_2_15_18  original_T_including_depot_unload_1499  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1315  1
    load_2_15_18  free_load_conservation_1466  1
    load_2_15_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1317  -30
    arc_2_15_19  connected_order_arc_1318  -12
    arc_2_15_19  out_degree_1461  1
    arc_2_15_19  in_degree_1486  1
    arc_2_15_19  original_T_including_depot_unload_1499  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1317  1
    load_2_15_19  free_load_conservation_1466  1
    load_2_15_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1319  -30
    arc_2_15_20  connected_order_arc_1320  -12
    arc_2_15_20  out_degree_1461  1
    arc_2_15_20  in_degree_1492  1
    arc_2_15_20  original_T_including_depot_unload_1499  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1319  1
    load_2_15_20  free_load_conservation_1466  1
    load_2_15_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1321  -30
    arc_2_16_0  depot_return_or_bypass_1427  1
    arc_2_16_0  out_degree_1467  1
    arc_2_16_0  original_T_including_depot_unload_1499  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1321  1
    load_2_16_0  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1322  -30
    arc_2_16_10  connected_order_arc_1323  -12
    arc_2_16_10  in_degree_1429  1
    arc_2_16_10  out_degree_1467  1
    arc_2_16_10  original_T_including_depot_unload_1499  1.2512000734124169e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1322  1
    load_2_16_10  segment_load_conservation_1432  -1
    load_2_16_10  segment_prefix_lb_1433  1
    load_2_16_10  segment_prefix_ub_1434  1
    load_2_16_10  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1324  -30
    arc_2_16_11  connected_order_arc_1325  -12
    arc_2_16_11  in_degree_1436  1
    arc_2_16_11  out_degree_1467  1
    arc_2_16_11  original_T_including_depot_unload_1499  2.2006293522349906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1324  1
    load_2_16_11  segment_load_conservation_1439  -1
    load_2_16_11  segment_prefix_lb_1440  1
    load_2_16_11  segment_prefix_ub_1441  1
    load_2_16_11  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1326  -30
    arc_2_16_12  connected_order_arc_1327  -12
    arc_2_16_12  in_degree_1443  1
    arc_2_16_12  out_degree_1467  1
    arc_2_16_12  original_T_including_depot_unload_1499  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1326  1
    load_2_16_12  segment_load_conservation_1446  -1
    load_2_16_12  segment_prefix_lb_1447  1
    load_2_16_12  segment_prefix_ub_1448  1
    load_2_16_12  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1328  -30
    arc_2_16_13  connected_order_arc_1329  -12
    arc_2_16_13  in_degree_1450  1
    arc_2_16_13  out_degree_1467  1
    arc_2_16_13  original_T_including_depot_unload_1499  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1328  1
    load_2_16_13  free_load_conservation_1454  -1
    load_2_16_13  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1330  -30
    arc_2_16_14  connected_order_arc_1331  -12
    arc_2_16_14  in_degree_1456  1
    arc_2_16_14  out_degree_1467  1
    arc_2_16_14  original_T_including_depot_unload_1499  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1330  1
    load_2_16_14  free_load_conservation_1460  -1
    load_2_16_14  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1332  -30
    arc_2_16_15  connected_order_arc_1333  -12
    arc_2_16_15  in_degree_1462  1
    arc_2_16_15  out_degree_1467  1
    arc_2_16_15  original_T_including_depot_unload_1499  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1332  1
    load_2_16_15  free_load_conservation_1466  -1
    load_2_16_15  free_load_conservation_1472  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1334  -30
    arc_2_16_17  connected_order_arc_1335  -12
    arc_2_16_17  out_degree_1467  1
    arc_2_16_17  in_degree_1474  1
    arc_2_16_17  original_T_including_depot_unload_1499  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1334  1
    load_2_16_17  free_load_conservation_1472  1
    load_2_16_17  free_load_conservation_1478  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1336  -30
    arc_2_16_18  connected_order_arc_1337  -12
    arc_2_16_18  out_degree_1467  1
    arc_2_16_18  in_degree_1480  1
    arc_2_16_18  original_T_including_depot_unload_1499  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1336  1
    load_2_16_18  free_load_conservation_1472  1
    load_2_16_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1338  -30
    arc_2_16_19  connected_order_arc_1339  -12
    arc_2_16_19  out_degree_1467  1
    arc_2_16_19  in_degree_1486  1
    arc_2_16_19  original_T_including_depot_unload_1499  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1338  1
    load_2_16_19  free_load_conservation_1472  1
    load_2_16_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1340  -30
    arc_2_16_20  connected_order_arc_1341  -12
    arc_2_16_20  out_degree_1467  1
    arc_2_16_20  in_degree_1492  1
    arc_2_16_20  original_T_including_depot_unload_1499  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1340  1
    load_2_16_20  free_load_conservation_1472  1
    load_2_16_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1342  -30
    arc_2_17_0  depot_return_or_bypass_1427  1
    arc_2_17_0  out_degree_1473  1
    arc_2_17_0  original_T_including_depot_unload_1499  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1342  1
    load_2_17_0  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1343  -30
    arc_2_17_10  connected_order_arc_1344  -12
    arc_2_17_10  in_degree_1429  1
    arc_2_17_10  out_degree_1473  1
    arc_2_17_10  original_T_including_depot_unload_1499  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1343  1
    load_2_17_10  segment_load_conservation_1432  -1
    load_2_17_10  segment_prefix_lb_1433  1
    load_2_17_10  segment_prefix_ub_1434  1
    load_2_17_10  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1345  -30
    arc_2_17_11  connected_order_arc_1346  -12
    arc_2_17_11  in_degree_1436  1
    arc_2_17_11  out_degree_1473  1
    arc_2_17_11  original_T_including_depot_unload_1499  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1345  1
    load_2_17_11  segment_load_conservation_1439  -1
    load_2_17_11  segment_prefix_lb_1440  1
    load_2_17_11  segment_prefix_ub_1441  1
    load_2_17_11  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1347  -30
    arc_2_17_12  connected_order_arc_1348  -12
    arc_2_17_12  in_degree_1443  1
    arc_2_17_12  out_degree_1473  1
    arc_2_17_12  original_T_including_depot_unload_1499  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1347  1
    load_2_17_12  segment_load_conservation_1446  -1
    load_2_17_12  segment_prefix_lb_1447  1
    load_2_17_12  segment_prefix_ub_1448  1
    load_2_17_12  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1349  -30
    arc_2_17_13  connected_order_arc_1350  -12
    arc_2_17_13  in_degree_1450  1
    arc_2_17_13  out_degree_1473  1
    arc_2_17_13  original_T_including_depot_unload_1499  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1349  1
    load_2_17_13  free_load_conservation_1454  -1
    load_2_17_13  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1351  -30
    arc_2_17_14  connected_order_arc_1352  -12
    arc_2_17_14  in_degree_1456  1
    arc_2_17_14  out_degree_1473  1
    arc_2_17_14  original_T_including_depot_unload_1499  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1351  1
    load_2_17_14  free_load_conservation_1460  -1
    load_2_17_14  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1353  -30
    arc_2_17_15  connected_order_arc_1354  -12
    arc_2_17_15  in_degree_1462  1
    arc_2_17_15  out_degree_1473  1
    arc_2_17_15  original_T_including_depot_unload_1499  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1353  1
    load_2_17_15  free_load_conservation_1466  -1
    load_2_17_15  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1355  -30
    arc_2_17_16  connected_order_arc_1356  -12
    arc_2_17_16  in_degree_1468  1
    arc_2_17_16  out_degree_1473  1
    arc_2_17_16  original_T_including_depot_unload_1499  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1355  1
    load_2_17_16  free_load_conservation_1472  -1
    load_2_17_16  free_load_conservation_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1357  -30
    arc_2_17_18  connected_order_arc_1358  -12
    arc_2_17_18  out_degree_1473  1
    arc_2_17_18  in_degree_1480  1
    arc_2_17_18  original_T_including_depot_unload_1499  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1357  1
    load_2_17_18  free_load_conservation_1478  1
    load_2_17_18  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1359  -30
    arc_2_17_19  connected_order_arc_1360  -12
    arc_2_17_19  out_degree_1473  1
    arc_2_17_19  in_degree_1486  1
    arc_2_17_19  original_T_including_depot_unload_1499  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1359  1
    load_2_17_19  free_load_conservation_1478  1
    load_2_17_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1361  -30
    arc_2_17_20  connected_order_arc_1362  -12
    arc_2_17_20  out_degree_1473  1
    arc_2_17_20  in_degree_1492  1
    arc_2_17_20  original_T_including_depot_unload_1499  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1361  1
    load_2_17_20  free_load_conservation_1478  1
    load_2_17_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1363  -30
    arc_2_18_0  depot_return_or_bypass_1427  1
    arc_2_18_0  out_degree_1479  1
    arc_2_18_0  original_T_including_depot_unload_1499  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1363  1
    load_2_18_0  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1364  -30
    arc_2_18_10  connected_order_arc_1365  -12
    arc_2_18_10  in_degree_1429  1
    arc_2_18_10  out_degree_1479  1
    arc_2_18_10  original_T_including_depot_unload_1499  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1364  1
    load_2_18_10  segment_load_conservation_1432  -1
    load_2_18_10  segment_prefix_lb_1433  1
    load_2_18_10  segment_prefix_ub_1434  1
    load_2_18_10  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1366  -30
    arc_2_18_11  connected_order_arc_1367  -12
    arc_2_18_11  in_degree_1436  1
    arc_2_18_11  out_degree_1479  1
    arc_2_18_11  original_T_including_depot_unload_1499  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1366  1
    load_2_18_11  segment_load_conservation_1439  -1
    load_2_18_11  segment_prefix_lb_1440  1
    load_2_18_11  segment_prefix_ub_1441  1
    load_2_18_11  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1368  -30
    arc_2_18_12  connected_order_arc_1369  -12
    arc_2_18_12  in_degree_1443  1
    arc_2_18_12  out_degree_1479  1
    arc_2_18_12  original_T_including_depot_unload_1499  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1368  1
    load_2_18_12  segment_load_conservation_1446  -1
    load_2_18_12  segment_prefix_lb_1447  1
    load_2_18_12  segment_prefix_ub_1448  1
    load_2_18_12  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1370  -30
    arc_2_18_13  connected_order_arc_1371  -12
    arc_2_18_13  in_degree_1450  1
    arc_2_18_13  out_degree_1479  1
    arc_2_18_13  original_T_including_depot_unload_1499  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1370  1
    load_2_18_13  free_load_conservation_1454  -1
    load_2_18_13  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1372  -30
    arc_2_18_14  connected_order_arc_1373  -12
    arc_2_18_14  in_degree_1456  1
    arc_2_18_14  out_degree_1479  1
    arc_2_18_14  original_T_including_depot_unload_1499  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1372  1
    load_2_18_14  free_load_conservation_1460  -1
    load_2_18_14  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1374  -30
    arc_2_18_15  connected_order_arc_1375  -12
    arc_2_18_15  in_degree_1462  1
    arc_2_18_15  out_degree_1479  1
    arc_2_18_15  original_T_including_depot_unload_1499  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1374  1
    load_2_18_15  free_load_conservation_1466  -1
    load_2_18_15  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1376  -30
    arc_2_18_16  connected_order_arc_1377  -12
    arc_2_18_16  in_degree_1468  1
    arc_2_18_16  out_degree_1479  1
    arc_2_18_16  original_T_including_depot_unload_1499  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1376  1
    load_2_18_16  free_load_conservation_1472  -1
    load_2_18_16  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1378  -30
    arc_2_18_17  connected_order_arc_1379  -12
    arc_2_18_17  in_degree_1474  1
    arc_2_18_17  out_degree_1479  1
    arc_2_18_17  original_T_including_depot_unload_1499  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1378  1
    load_2_18_17  free_load_conservation_1478  -1
    load_2_18_17  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1380  -30
    arc_2_18_19  connected_order_arc_1381  -12
    arc_2_18_19  out_degree_1479  1
    arc_2_18_19  in_degree_1486  1
    arc_2_18_19  original_T_including_depot_unload_1499  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1380  1
    load_2_18_19  free_load_conservation_1484  1
    load_2_18_19  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1382  -30
    arc_2_18_20  connected_order_arc_1383  -12
    arc_2_18_20  out_degree_1479  1
    arc_2_18_20  in_degree_1492  1
    arc_2_18_20  original_T_including_depot_unload_1499  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1382  1
    load_2_18_20  free_load_conservation_1484  1
    load_2_18_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1384  -30
    arc_2_19_0  depot_return_or_bypass_1427  1
    arc_2_19_0  out_degree_1485  1
    arc_2_19_0  original_T_including_depot_unload_1499  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1384  1
    load_2_19_0  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1385  -30
    arc_2_19_10  connected_order_arc_1386  -12
    arc_2_19_10  in_degree_1429  1
    arc_2_19_10  out_degree_1485  1
    arc_2_19_10  original_T_including_depot_unload_1499  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1385  1
    load_2_19_10  segment_load_conservation_1432  -1
    load_2_19_10  segment_prefix_lb_1433  1
    load_2_19_10  segment_prefix_ub_1434  1
    load_2_19_10  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1387  -30
    arc_2_19_11  connected_order_arc_1388  -12
    arc_2_19_11  in_degree_1436  1
    arc_2_19_11  out_degree_1485  1
    arc_2_19_11  original_T_including_depot_unload_1499  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1387  1
    load_2_19_11  segment_load_conservation_1439  -1
    load_2_19_11  segment_prefix_lb_1440  1
    load_2_19_11  segment_prefix_ub_1441  1
    load_2_19_11  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1389  -30
    arc_2_19_12  connected_order_arc_1390  -12
    arc_2_19_12  in_degree_1443  1
    arc_2_19_12  out_degree_1485  1
    arc_2_19_12  original_T_including_depot_unload_1499  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1389  1
    load_2_19_12  segment_load_conservation_1446  -1
    load_2_19_12  segment_prefix_lb_1447  1
    load_2_19_12  segment_prefix_ub_1448  1
    load_2_19_12  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1391  -30
    arc_2_19_13  connected_order_arc_1392  -12
    arc_2_19_13  in_degree_1450  1
    arc_2_19_13  out_degree_1485  1
    arc_2_19_13  original_T_including_depot_unload_1499  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1391  1
    load_2_19_13  free_load_conservation_1454  -1
    load_2_19_13  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1393  -30
    arc_2_19_14  connected_order_arc_1394  -12
    arc_2_19_14  in_degree_1456  1
    arc_2_19_14  out_degree_1485  1
    arc_2_19_14  original_T_including_depot_unload_1499  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1393  1
    load_2_19_14  free_load_conservation_1460  -1
    load_2_19_14  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1395  -30
    arc_2_19_15  connected_order_arc_1396  -12
    arc_2_19_15  in_degree_1462  1
    arc_2_19_15  out_degree_1485  1
    arc_2_19_15  original_T_including_depot_unload_1499  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1395  1
    load_2_19_15  free_load_conservation_1466  -1
    load_2_19_15  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1397  -30
    arc_2_19_16  connected_order_arc_1398  -12
    arc_2_19_16  in_degree_1468  1
    arc_2_19_16  out_degree_1485  1
    arc_2_19_16  original_T_including_depot_unload_1499  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1397  1
    load_2_19_16  free_load_conservation_1472  -1
    load_2_19_16  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1399  -30
    arc_2_19_17  connected_order_arc_1400  -12
    arc_2_19_17  in_degree_1474  1
    arc_2_19_17  out_degree_1485  1
    arc_2_19_17  original_T_including_depot_unload_1499  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1399  1
    load_2_19_17  free_load_conservation_1478  -1
    load_2_19_17  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1401  -30
    arc_2_19_18  connected_order_arc_1402  -12
    arc_2_19_18  in_degree_1480  1
    arc_2_19_18  out_degree_1485  1
    arc_2_19_18  original_T_including_depot_unload_1499  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1401  1
    load_2_19_18  free_load_conservation_1484  -1
    load_2_19_18  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1403  -30
    arc_2_19_20  connected_order_arc_1404  -12
    arc_2_19_20  out_degree_1485  1
    arc_2_19_20  in_degree_1492  1
    arc_2_19_20  original_T_including_depot_unload_1499  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1403  1
    load_2_19_20  free_load_conservation_1490  1
    load_2_19_20  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1405  -30
    arc_2_20_0  depot_return_or_bypass_1427  1
    arc_2_20_0  out_degree_1491  1
    arc_2_20_0  original_T_including_depot_unload_1499  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1405  1
    load_2_20_0  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1406  -30
    arc_2_20_10  connected_order_arc_1407  -12
    arc_2_20_10  in_degree_1429  1
    arc_2_20_10  out_degree_1491  1
    arc_2_20_10  original_T_including_depot_unload_1499  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1406  1
    load_2_20_10  segment_load_conservation_1432  -1
    load_2_20_10  segment_prefix_lb_1433  1
    load_2_20_10  segment_prefix_ub_1434  1
    load_2_20_10  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1408  -30
    arc_2_20_11  connected_order_arc_1409  -12
    arc_2_20_11  in_degree_1436  1
    arc_2_20_11  out_degree_1491  1
    arc_2_20_11  original_T_including_depot_unload_1499  1.7644788835951622e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1408  1
    load_2_20_11  segment_load_conservation_1439  -1
    load_2_20_11  segment_prefix_lb_1440  1
    load_2_20_11  segment_prefix_ub_1441  1
    load_2_20_11  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1410  -30
    arc_2_20_12  connected_order_arc_1411  -12
    arc_2_20_12  in_degree_1443  1
    arc_2_20_12  out_degree_1491  1
    arc_2_20_12  original_T_including_depot_unload_1499  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1410  1
    load_2_20_12  segment_load_conservation_1446  -1
    load_2_20_12  segment_prefix_lb_1447  1
    load_2_20_12  segment_prefix_ub_1448  1
    load_2_20_12  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1412  -30
    arc_2_20_13  connected_order_arc_1413  -12
    arc_2_20_13  in_degree_1450  1
    arc_2_20_13  out_degree_1491  1
    arc_2_20_13  original_T_including_depot_unload_1499  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1412  1
    load_2_20_13  free_load_conservation_1454  -1
    load_2_20_13  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1414  -30
    arc_2_20_14  connected_order_arc_1415  -12
    arc_2_20_14  in_degree_1456  1
    arc_2_20_14  out_degree_1491  1
    arc_2_20_14  original_T_including_depot_unload_1499  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1414  1
    load_2_20_14  free_load_conservation_1460  -1
    load_2_20_14  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1416  -30
    arc_2_20_15  connected_order_arc_1417  -12
    arc_2_20_15  in_degree_1462  1
    arc_2_20_15  out_degree_1491  1
    arc_2_20_15  original_T_including_depot_unload_1499  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1416  1
    load_2_20_15  free_load_conservation_1466  -1
    load_2_20_15  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1418  -30
    arc_2_20_16  connected_order_arc_1419  -12
    arc_2_20_16  in_degree_1468  1
    arc_2_20_16  out_degree_1491  1
    arc_2_20_16  original_T_including_depot_unload_1499  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1418  1
    load_2_20_16  free_load_conservation_1472  -1
    load_2_20_16  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1420  -30
    arc_2_20_17  connected_order_arc_1421  -12
    arc_2_20_17  in_degree_1474  1
    arc_2_20_17  out_degree_1491  1
    arc_2_20_17  original_T_including_depot_unload_1499  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1420  1
    load_2_20_17  free_load_conservation_1478  -1
    load_2_20_17  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1422  -30
    arc_2_20_18  connected_order_arc_1423  -12
    arc_2_20_18  in_degree_1480  1
    arc_2_20_18  out_degree_1491  1
    arc_2_20_18  original_T_including_depot_unload_1499  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1422  1
    load_2_20_18  free_load_conservation_1484  -1
    load_2_20_18  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1424  -30
    arc_2_20_19  connected_order_arc_1425  -12
    arc_2_20_19  in_degree_1486  1
    arc_2_20_19  out_degree_1491  1
    arc_2_20_19  original_T_including_depot_unload_1499  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1424  1
    load_2_20_19  free_load_conservation_1490  -1
    load_2_20_19  free_load_conservation_1496  1
RHS
    RHS1      OBJ       -4.1325000000000006e-01
    RHS1      onehot_20_26  1
    RHS1      onehot_21_61  1
    RHS1      onehot_31_90  1
    RHS1      onehot_23_117  1
    RHS1      onehot_32_146  1
    RHS1      onehot_16_175  1
    RHS1      onehot_19_196  1
    RHS1      onehot_11_225  1
    RHS1      stock_ub_229  30
    RHS1      parent_nonstrict_scope_230  3.0884040918067934e-01
    RHS1      normalization_287  1
    RHS1      connected_order_arc_399  -13
    RHS1      connected_order_arc_401  -13
    RHS1      connected_order_arc_403  -13
    RHS1      connected_order_arc_405  -13
    RHS1      connected_order_arc_407  -13
    RHS1      connected_order_arc_409  -13
    RHS1      connected_order_arc_411  -13
    RHS1      connected_order_arc_413  -13
    RHS1      connected_order_arc_415  -13
    RHS1      connected_order_arc_417  -13
    RHS1      connected_order_arc_419  -13
    RHS1      connected_order_arc_421  -13
    RHS1      connected_order_arc_424  -13
    RHS1      connected_order_arc_426  -13
    RHS1      connected_order_arc_428  -13
    RHS1      connected_order_arc_430  -13
    RHS1      connected_order_arc_432  -13
    RHS1      connected_order_arc_434  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_705  -13
    RHS1      connected_order_arc_707  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      depot_departure_or_bypass_722  1
    RHS1      depot_return_or_bypass_723  1
    RHS1      segment_load_conservation_728  4
    RHS1      segment_prefix_ub_730  16
    RHS1      segment_load_conservation_735  4
    RHS1      segment_prefix_ub_737  16
    RHS1      segment_load_conservation_742  2
    RHS1      segment_prefix_lb_743  9
    RHS1      segment_prefix_ub_744  11
    RHS1      segment_load_conservation_749  -6
    RHS1      segment_prefix_lb_750  6
    RHS1      segment_prefix_ub_751  20
    RHS1      segment_load_conservation_756  -6
    RHS1      segment_prefix_lb_757  6
    RHS1      segment_prefix_ub_758  20
    RHS1      fixed_segment_relative_order_807  1
    RHS1      fixed_segment_relative_order_808  1
    RHS1      fixed_segment_relative_order_809  1
    RHS1      fixed_segment_relative_order_810  1
    RHS1      original_T_including_depot_unload_811  2.2895240507079898e+03
    RHS1      connected_order_arc_827  -12
    RHS1      connected_order_arc_829  -12
    RHS1      connected_order_arc_831  -12
    RHS1      connected_order_arc_833  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_850  -12
    RHS1      connected_order_arc_852  -12
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1086  -12
    RHS1      connected_order_arc_1088  -12
    RHS1      connected_order_arc_1090  -12
    RHS1      connected_order_arc_1092  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      depot_departure_or_bypass_1101  1
    RHS1      depot_return_or_bypass_1102  1
    RHS1      segment_load_conservation_1107  7
    RHS1      segment_prefix_ub_1109  18
    RHS1      segment_load_conservation_1114  -5
    RHS1      segment_prefix_lb_1115  5
    RHS1      segment_prefix_ub_1116  25
    RHS1      segment_load_conservation_1121  -2
    RHS1      segment_prefix_lb_1122  2
    RHS1      segment_prefix_ub_1123  21
    RHS1      segment_load_conservation_1128  5
    RHS1      segment_prefix_ub_1130  20
    RHS1      fixed_segment_relative_order_1179  1
    RHS1      fixed_segment_relative_order_1180  1
    RHS1      fixed_segment_relative_order_1181  1
    RHS1      original_T_including_depot_unload_1182  4.4717963953262370e+03
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1207  -11
    RHS1      connected_order_arc_1209  -11
    RHS1      connected_order_arc_1211  -11
    RHS1      connected_order_arc_1213  -11
    RHS1      connected_order_arc_1215  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1228  -11
    RHS1      connected_order_arc_1230  -11
    RHS1      connected_order_arc_1232  -11
    RHS1      connected_order_arc_1234  -11
    RHS1      connected_order_arc_1236  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1249  -11
    RHS1      connected_order_arc_1251  -11
    RHS1      connected_order_arc_1253  -11
    RHS1      connected_order_arc_1255  -11
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1270  -11
    RHS1      connected_order_arc_1272  -11
    RHS1      connected_order_arc_1274  -11
    RHS1      connected_order_arc_1276  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1375  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1396  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1417  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      depot_departure_or_bypass_1426  1
    RHS1      depot_return_or_bypass_1427  1
    RHS1      segment_load_conservation_1432  1
    RHS1      segment_prefix_ub_1434  24
    RHS1      segment_load_conservation_1439  4
    RHS1      segment_prefix_ub_1441  26
    RHS1      segment_load_conservation_1446  -5
    RHS1      segment_prefix_lb_1447  5
    RHS1      segment_prefix_ub_1448  30
    RHS1      fixed_segment_relative_order_1497  1
    RHS1      fixed_segment_relative_order_1498  1
    RHS1      original_T_including_depot_unload_1499  3.4285204222867415e+03
BOUNDS
 LO BND1      t         0.0248557478916751
 UP BND1      t         4.2296072507595178e-02
 UP BND1      q         4.9634040918067934e-01
 BV BND1      x_20_0  
 UP BND1      w_20_0    4.2296072507595178e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    4.2296072507595178e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    4.2296072507595178e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    4.2296072507595178e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    4.2296072507595178e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    4.2296072507595178e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    4.2296072507595178e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    4.2296072507595178e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    4.2296072507595178e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    4.2296072507595178e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   4.2296072507595178e-02
 BV BND1      x_20_11 
 UP BND1      w_20_11   4.2296072507595178e-02
 BV BND1      x_20_12 
 UP BND1      w_20_12   4.2296072507595178e-02
 UP BND1      rho_20    1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.2296072507595178e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.2296072507595178e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.2296072507595178e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.2296072507595178e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.2296072507595178e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.2296072507595178e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.2296072507595178e-02
 BV BND1      x_21_7  
 UP BND1      w_21_7    4.2296072507595178e-02
 BV BND1      x_21_8  
 UP BND1      w_21_8    4.2296072507595178e-02
 BV BND1      x_21_9  
 UP BND1      w_21_9    4.2296072507595178e-02
 BV BND1      x_21_10 
 UP BND1      w_21_10   4.2296072507595178e-02
 BV BND1      x_21_11 
 UP BND1      w_21_11   4.2296072507595178e-02
 BV BND1      x_21_12 
 UP BND1      w_21_12   4.2296072507595178e-02
 BV BND1      x_21_13 
 UP BND1      w_21_13   4.2296072507595178e-02
 BV BND1      x_21_14 
 UP BND1      w_21_14   4.2296072507595178e-02
 BV BND1      x_21_15 
 UP BND1      w_21_15   4.2296072507595178e-02
 UP BND1      rho_21    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2296072507595178e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2296072507595178e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2296072507595178e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2296072507595178e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2296072507595178e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2296072507595178e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2296072507595178e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2296072507595178e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2296072507595178e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2296072507595178e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2296072507595178e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2296072507595178e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2296072507595178e-02
 UP BND1      rho_31    1
 BV BND1      x_23_0  
 UP BND1      w_23_0    4.2296072507595178e-02
 BV BND1      x_23_1  
 UP BND1      w_23_1    4.2296072507595178e-02
 BV BND1      x_23_2  
 UP BND1      w_23_2    4.2296072507595178e-02
 BV BND1      x_23_3  
 UP BND1      w_23_3    4.2296072507595178e-02
 BV BND1      x_23_4  
 UP BND1      w_23_4    4.2296072507595178e-02
 BV BND1      x_23_5  
 UP BND1      w_23_5    4.2296072507595178e-02
 BV BND1      x_23_6  
 UP BND1      w_23_6    4.2296072507595178e-02
 BV BND1      x_23_7  
 UP BND1      w_23_7    4.2296072507595178e-02
 BV BND1      x_23_8  
 UP BND1      w_23_8    4.2296072507595178e-02
 BV BND1      x_23_9  
 UP BND1      w_23_9    4.2296072507595178e-02
 BV BND1      x_23_10 
 UP BND1      w_23_10   4.2296072507595178e-02
 BV BND1      x_23_11 
 UP BND1      w_23_11   4.2296072507595178e-02
 UP BND1      rho_23    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.2296072507595178e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.2296072507595178e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.2296072507595178e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.2296072507595178e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.2296072507595178e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.2296072507595178e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.2296072507595178e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.2296072507595178e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.2296072507595178e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.2296072507595178e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.2296072507595178e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.2296072507595178e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.2296072507595178e-02
 UP BND1      rho_32    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.2296072507595178e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.2296072507595178e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.2296072507595178e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.2296072507595178e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.2296072507595178e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.2296072507595178e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.2296072507595178e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.2296072507595178e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.2296072507595178e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.2296072507595178e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.2296072507595178e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.2296072507595178e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.2296072507595178e-02
 UP BND1      rho_16    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.2296072507595178e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.2296072507595178e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.2296072507595178e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.2296072507595178e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.2296072507595178e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.2296072507595178e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.2296072507595178e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.2296072507595178e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.2296072507595178e-02
 UP BND1      rho_19    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.2296072507595178e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.2296072507595178e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.2296072507595178e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.2296072507595178e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.2296072507595178e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.2296072507595178e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.2296072507595178e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.2296072507595178e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.2296072507595178e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.2296072507595178e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.2296072507595178e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   4.2296072507595178e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   4.2296072507595178e-02
 UP BND1      rho_11    1
 UP BND1      a_20_21   1
 UP BND1      a_20_31   1
 UP BND1      a_20_23   1
 UP BND1      a_20_32   1
 UP BND1      a_20_16   1
 UP BND1      a_20_19   1
 UP BND1      a_20_11   1
 UP BND1      a_21_31   1
 UP BND1      a_21_23   1
 UP BND1      a_21_32   1
 UP BND1      a_21_16   1
 UP BND1      a_21_19   1
 UP BND1      a_21_11   1
 UP BND1      a_31_23   1
 UP BND1      a_31_32   1
 UP BND1      a_31_16   1
 UP BND1      a_31_19   1
 UP BND1      a_31_11   1
 UP BND1      a_23_32   1
 UP BND1      a_23_16   1
 UP BND1      a_23_19   1
 UP BND1      a_23_11   1
 UP BND1      a_32_16   1
 UP BND1      a_32_19   1
 UP BND1      a_32_11   1
 UP BND1      a_16_19   1
 UP BND1      a_16_11   1
 UP BND1      a_19_11   1
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_12
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_12
 BV BND1      service_2_20_0
 BV BND1      service_2_20_1
 BV BND1      service_2_20_2
 BV BND1      service_2_20_3
 BV BND1      service_2_20_4
 BV BND1      service_2_20_5
 BV BND1      service_2_20_6
 BV BND1      service_2_20_7
 BV BND1      service_2_20_8
 BV BND1      service_2_20_10
 BV BND1      service_2_20_11
 BV BND1      service_2_20_12
 BV BND1      service_0_21_0
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_0_21_7
 BV BND1      service_0_21_8
 BV BND1      service_0_21_9
 BV BND1      service_0_21_10
 BV BND1      service_0_21_11
 BV BND1      service_0_21_12
 BV BND1      service_0_21_13
 BV BND1      service_0_21_14
 BV BND1      service_0_21_15
 BV BND1      service_1_21_0
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_1_21_7
 BV BND1      service_1_21_8
 BV BND1      service_1_21_9
 BV BND1      service_1_21_10
 BV BND1      service_1_21_11
 BV BND1      service_1_21_12
 BV BND1      service_1_21_13
 BV BND1      service_1_21_14
 BV BND1      service_1_21_15
 BV BND1      service_2_21_0
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_2_21_7
 BV BND1      service_2_21_8
 BV BND1      service_2_21_9
 BV BND1      service_2_21_10
 BV BND1      service_2_21_11
 BV BND1      service_2_21_12
 BV BND1      service_2_21_13
 BV BND1      service_2_21_14
 BV BND1      service_2_21_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_23_0
 BV BND1      service_0_23_1
 BV BND1      service_0_23_2
 BV BND1      service_0_23_3
 BV BND1      service_0_23_4
 BV BND1      service_0_23_5
 BV BND1      service_0_23_6
 BV BND1      service_0_23_8
 BV BND1      service_0_23_9
 BV BND1      service_0_23_10
 BV BND1      service_0_23_11
 BV BND1      service_1_23_0
 BV BND1      service_1_23_1
 BV BND1      service_1_23_2
 BV BND1      service_1_23_3
 BV BND1      service_1_23_4
 BV BND1      service_1_23_5
 BV BND1      service_1_23_6
 BV BND1      service_1_23_8
 BV BND1      service_1_23_9
 BV BND1      service_1_23_10
 BV BND1      service_1_23_11
 BV BND1      service_2_23_0
 BV BND1      service_2_23_1
 BV BND1      service_2_23_2
 BV BND1      service_2_23_3
 BV BND1      service_2_23_4
 BV BND1      service_2_23_5
 BV BND1      service_2_23_6
 BV BND1      service_2_23_8
 BV BND1      service_2_23_9
 BV BND1      service_2_23_10
 BV BND1      service_2_23_11
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_8
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_2_11_11
 BV BND1      service_2_11_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
