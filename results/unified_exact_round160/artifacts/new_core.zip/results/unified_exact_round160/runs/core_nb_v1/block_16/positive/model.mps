* Signature: 0xc0ac35f3f8036a09
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_30_18
 E  normalized_mass_30_19
 E  normalized_ratio_30_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_35_53
 E  normalized_mass_35_54
 E  normalized_ratio_35_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_31_82
 E  normalized_mass_31_83
 E  normalized_ratio_31_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_32_111
 E  normalized_mass_32_112
 E  normalized_ratio_32_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_2_146
 E  normalized_mass_2_147
 E  normalized_ratio_2_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 E  onehot_26_167
 E  normalized_mass_26_168
 E  normalized_ratio_26_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 E  onehot_16_196
 E  normalized_mass_16_197
 E  normalized_ratio_16_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 E  onehot_19_217
 E  normalized_mass_19_218
 E  normalized_ratio_19_219
 G  stock_lb_220
 L  stock_ub_221
 L  parent_nonstrict_scope_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 E  normalization_279
 G  full_original_Gini_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 L  arc_capacity_371
 L  arc_capacity_372
 L  arc_capacity_373
 L  arc_capacity_374
 L  arc_capacity_375
 L  arc_capacity_376
 L  arc_capacity_377
 L  arc_capacity_378
 L  arc_capacity_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 G  connected_order_arc_387
 L  arc_capacity_388
 G  connected_order_arc_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 E  depot_departure_or_bypass_710
 E  depot_return_or_bypass_711
 E  out_degree_712
 E  in_degree_713
 G  order_active_lb_714
 L  order_active_ub_715
 E  segment_load_conservation_716
 G  segment_prefix_lb_717
 L  segment_prefix_ub_718
 E  out_degree_719
 E  in_degree_720
 G  order_active_lb_721
 L  order_active_ub_722
 E  segment_load_conservation_723
 G  segment_prefix_lb_724
 L  segment_prefix_ub_725
 E  out_degree_726
 E  in_degree_727
 G  order_active_lb_728
 L  order_active_ub_729
 E  segment_load_conservation_730
 G  segment_prefix_lb_731
 L  segment_prefix_ub_732
 E  out_degree_733
 E  in_degree_734
 G  order_active_lb_735
 L  order_active_ub_736
 E  segment_load_conservation_737
 G  segment_prefix_lb_738
 L  segment_prefix_ub_739
 E  out_degree_740
 E  in_degree_741
 G  order_active_lb_742
 L  order_active_ub_743
 E  segment_load_conservation_744
 G  segment_prefix_lb_745
 L  segment_prefix_ub_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  service_visit_def_757
 E  free_load_conservation_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  service_visit_def_781
 E  free_load_conservation_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  service_visit_def_787
 E  free_load_conservation_788
 E  out_degree_789
 E  in_degree_790
 G  order_active_lb_791
 L  order_active_ub_792
 E  service_visit_def_793
 E  free_load_conservation_794
 G  fixed_segment_relative_order_795
 G  fixed_segment_relative_order_796
 G  fixed_segment_relative_order_797
 G  fixed_segment_relative_order_798
 L  original_T_including_depot_unload_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 L  arc_capacity_803
 L  arc_capacity_804
 L  arc_capacity_805
 L  arc_capacity_806
 L  arc_capacity_807
 L  arc_capacity_808
 L  arc_capacity_809
 L  arc_capacity_810
 L  arc_capacity_811
 L  arc_capacity_812
 L  arc_capacity_813
 L  arc_capacity_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 E  depot_departure_or_bypass_1139
 E  depot_return_or_bypass_1140
 E  out_degree_1141
 E  in_degree_1142
 G  order_active_lb_1143
 L  order_active_ub_1144
 E  segment_load_conservation_1145
 G  segment_prefix_lb_1146
 L  segment_prefix_ub_1147
 E  out_degree_1148
 E  in_degree_1149
 G  order_active_lb_1150
 L  order_active_ub_1151
 E  segment_load_conservation_1152
 G  segment_prefix_lb_1153
 L  segment_prefix_ub_1154
 E  out_degree_1155
 E  in_degree_1156
 G  order_active_lb_1157
 L  order_active_ub_1158
 E  segment_load_conservation_1159
 G  segment_prefix_lb_1160
 L  segment_prefix_ub_1161
 E  out_degree_1162
 E  in_degree_1163
 G  order_active_lb_1164
 L  order_active_ub_1165
 E  segment_load_conservation_1166
 G  segment_prefix_lb_1167
 L  segment_prefix_ub_1168
 E  out_degree_1169
 E  in_degree_1170
 G  order_active_lb_1171
 L  order_active_ub_1172
 E  segment_load_conservation_1173
 G  segment_prefix_lb_1174
 L  segment_prefix_ub_1175
 E  out_degree_1176
 E  in_degree_1177
 G  order_active_lb_1178
 L  order_active_ub_1179
 E  service_visit_def_1180
 E  free_load_conservation_1181
 E  out_degree_1182
 E  in_degree_1183
 G  order_active_lb_1184
 L  order_active_ub_1185
 E  service_visit_def_1186
 E  free_load_conservation_1187
 E  out_degree_1188
 E  in_degree_1189
 G  order_active_lb_1190
 L  order_active_ub_1191
 E  service_visit_def_1192
 E  free_load_conservation_1193
 E  out_degree_1194
 E  in_degree_1195
 G  order_active_lb_1196
 L  order_active_ub_1197
 E  service_visit_def_1198
 E  free_load_conservation_1199
 E  out_degree_1200
 E  in_degree_1201
 G  order_active_lb_1202
 L  order_active_ub_1203
 E  service_visit_def_1204
 E  free_load_conservation_1205
 E  out_degree_1206
 E  in_degree_1207
 G  order_active_lb_1208
 L  order_active_ub_1209
 E  service_visit_def_1210
 E  free_load_conservation_1211
 E  out_degree_1212
 E  in_degree_1213
 G  order_active_lb_1214
 L  order_active_ub_1215
 E  service_visit_def_1216
 E  free_load_conservation_1217
 E  out_degree_1218
 E  in_degree_1219
 G  order_active_lb_1220
 L  order_active_ub_1221
 E  service_visit_def_1222
 E  free_load_conservation_1223
 G  fixed_segment_relative_order_1224
 G  fixed_segment_relative_order_1225
 G  fixed_segment_relative_order_1226
 G  fixed_segment_relative_order_1227
 L  original_T_including_depot_unload_1228
 L  arc_capacity_1229
 L  arc_capacity_1230
 L  arc_capacity_1231
 L  arc_capacity_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 L  arc_capacity_1235
 L  arc_capacity_1236
 L  arc_capacity_1237
 L  arc_capacity_1238
 L  arc_capacity_1239
 L  arc_capacity_1240
 L  arc_capacity_1241
 L  arc_capacity_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 G  connected_order_arc_1515
 L  arc_capacity_1516
 G  connected_order_arc_1517
 E  depot_departure_or_bypass_1518
 E  depot_return_or_bypass_1519
 E  out_degree_1520
 E  in_degree_1521
 G  order_active_lb_1522
 L  order_active_ub_1523
 E  segment_load_conservation_1524
 G  segment_prefix_lb_1525
 L  segment_prefix_ub_1526
 E  out_degree_1527
 E  in_degree_1528
 G  order_active_lb_1529
 L  order_active_ub_1530
 E  segment_load_conservation_1531
 G  segment_prefix_lb_1532
 L  segment_prefix_ub_1533
 E  out_degree_1534
 E  in_degree_1535
 G  order_active_lb_1536
 L  order_active_ub_1537
 E  segment_load_conservation_1538
 G  segment_prefix_lb_1539
 L  segment_prefix_ub_1540
 E  out_degree_1541
 E  in_degree_1542
 G  order_active_lb_1543
 L  order_active_ub_1544
 E  segment_load_conservation_1545
 G  segment_prefix_lb_1546
 L  segment_prefix_ub_1547
 E  out_degree_1548
 E  in_degree_1549
 G  order_active_lb_1550
 L  order_active_ub_1551
 E  service_visit_def_1552
 E  free_load_conservation_1553
 E  out_degree_1554
 E  in_degree_1555
 G  order_active_lb_1556
 L  order_active_ub_1557
 E  service_visit_def_1558
 E  free_load_conservation_1559
 E  out_degree_1560
 E  in_degree_1561
 G  order_active_lb_1562
 L  order_active_ub_1563
 E  service_visit_def_1564
 E  free_load_conservation_1565
 E  out_degree_1566
 E  in_degree_1567
 G  order_active_lb_1568
 L  order_active_ub_1569
 E  service_visit_def_1570
 E  free_load_conservation_1571
 E  out_degree_1572
 E  in_degree_1573
 G  order_active_lb_1574
 L  order_active_ub_1575
 E  service_visit_def_1576
 E  free_load_conservation_1577
 E  out_degree_1578
 E  in_degree_1579
 G  order_active_lb_1580
 L  order_active_ub_1581
 E  service_visit_def_1582
 E  free_load_conservation_1583
 E  out_degree_1584
 E  in_degree_1585
 G  order_active_lb_1586
 L  order_active_ub_1587
 E  service_visit_def_1588
 E  free_load_conservation_1589
 E  out_degree_1590
 E  in_degree_1591
 G  order_active_lb_1592
 L  order_active_ub_1593
 E  service_visit_def_1594
 E  free_load_conservation_1595
 G  fixed_segment_relative_order_1596
 G  fixed_segment_relative_order_1597
 G  fixed_segment_relative_order_1598
 L  original_T_including_depot_unload_1599
COLUMNS
    t         normalized_mass_30_19  -1
    t         normalized_mass_35_54  -1
    t         normalized_mass_31_83  -1
    t         normalized_mass_32_112  -1
    t         normalized_mass_2_147  -1
    t         normalized_mass_26_168  -1
    t         normalized_mass_16_197  -1
    t         normalized_mass_19_218  -1
    t         normalization_279  2.4626190476190480e+01
    t         full_original_Gini_280  -6.0976190476190460e+01
    q         OBJ       1
    q         parent_nonstrict_scope_222  1
    q         full_original_Gini_280  35
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       0.012
    x_30_0    product_lb_0  -2.4534859946816593e-02
    x_30_0    product_ub_1  -0.0406071739341023
    x_30_0    onehot_30_18  1
    x_30_0    parent_nonstrict_scope_222  0.024
    x_30_0    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_0  1
    w_30_0    product_ub_1  1
    w_30_0    normalized_mass_30_19  1
    w_30_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       6.0000000000000019e-03
    x_30_1    product_lb_2  -2.4534859946816593e-02
    x_30_1    product_ub_3  -0.0406071739341023
    x_30_1    onehot_30_18  1
    x_30_1    stock_lb_220  1
    x_30_1    stock_ub_221  1
    x_30_1    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_30_1    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_2  1
    w_30_1    product_ub_3  1
    w_30_1    normalized_mass_30_19  1
    w_30_1    normalized_ratio_30_20  -0.25
    w_30_1    full_original_Gini_280  -1.7876190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_4  -2.4534859946816593e-02
    x_30_2    product_ub_5  -0.0406071739341023
    x_30_2    onehot_30_18  1
    x_30_2    stock_lb_220  2
    x_30_2    stock_ub_221  2
    x_30_2    parent_nonstrict_scope_222  0.012
    x_30_2    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_4  1
    w_30_2    product_ub_5  1
    w_30_2    normalized_mass_30_19  1
    w_30_2    normalized_ratio_30_20  -0.5
    w_30_2    full_original_Gini_280  -1.1126190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -0.006
    x_30_3    product_lb_6  -2.4534859946816593e-02
    x_30_3    product_ub_7  -0.0406071739341023
    x_30_3    onehot_30_18  1
    x_30_3    stock_lb_220  3
    x_30_3    stock_ub_221  3
    x_30_3    parent_nonstrict_scope_222  0.006
    x_30_3    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_6  1
    w_30_3    product_ub_7  1
    w_30_3    normalized_mass_30_19  1
    w_30_3    normalized_ratio_30_20  -0.75
    w_30_3    full_original_Gini_280  -5.19047619047619
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -0.012
    x_30_4    product_lb_8  -2.4534859946816593e-02
    x_30_4    product_ub_9  -0.0406071739341023
    x_30_4    onehot_30_18  1
    x_30_4    stock_lb_220  4
    x_30_4    stock_ub_221  4
    x_30_4    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_8  1
    w_30_4    product_ub_9  1
    w_30_4    normalized_mass_30_19  1
    w_30_4    normalized_ratio_30_20  -1
    w_30_4    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -0.006
    x_30_5    product_lb_10  -2.4534859946816593e-02
    x_30_5    product_ub_11  -0.0406071739341023
    x_30_5    onehot_30_18  1
    x_30_5    stock_lb_220  5
    x_30_5    stock_ub_221  5
    x_30_5    parent_nonstrict_scope_222  0.006
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_10  1
    w_30_5    product_ub_11  1
    w_30_5    normalized_mass_30_19  1
    w_30_5    normalized_ratio_30_20  -1.25
    w_30_5    full_original_Gini_280  -9.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_12  -2.4534859946816593e-02
    x_30_6    product_ub_13  -0.0406071739341023
    x_30_6    onehot_30_18  1
    x_30_6    stock_lb_220  6
    x_30_6    stock_ub_221  6
    x_30_6    parent_nonstrict_scope_222  0.012
    x_30_6    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_12  1
    w_30_6    product_ub_13  1
    w_30_6    normalized_mass_30_19  1
    w_30_6    normalized_ratio_30_20  -1.5
    w_30_6    full_original_Gini_280  -1.5873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       6.0000000000000019e-03
    x_30_7    product_lb_14  -2.4534859946816593e-02
    x_30_7    product_ub_15  -0.0406071739341023
    x_30_7    onehot_30_18  1
    x_30_7    stock_lb_220  7
    x_30_7    stock_ub_221  7
    x_30_7    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_30_7    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_14  1
    w_30_7    product_ub_15  1
    w_30_7    normalized_mass_30_19  1
    w_30_7    normalized_ratio_30_20  -1.75
    w_30_7    full_original_Gini_280  -2.2623809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       0.012
    x_30_8    product_lb_16  -2.4534859946816593e-02
    x_30_8    product_ub_17  -0.0406071739341023
    x_30_8    onehot_30_18  1
    x_30_8    stock_lb_220  8
    x_30_8    stock_ub_221  8
    x_30_8    parent_nonstrict_scope_222  0.024
    x_30_8    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_16  1
    w_30_8    product_ub_17  1
    w_30_8    normalized_mass_30_19  1
    w_30_8    normalized_ratio_30_20  -2
    w_30_8    full_original_Gini_280  -2.9373809523809520e+01
    rho_30    normalized_ratio_30_20  1
    rho_30    block_pair_pos_235  -1
    rho_30    block_pair_neg_236  1
    rho_30    block_pair_pos_237  -1
    rho_30    block_pair_neg_238  1
    rho_30    block_pair_pos_239  -1
    rho_30    block_pair_neg_240  1
    rho_30    block_pair_pos_241  -1
    rho_30    block_pair_neg_242  1
    rho_30    block_pair_pos_243  -1
    rho_30    block_pair_neg_244  1
    rho_30    block_pair_pos_245  -1
    rho_30    block_pair_neg_246  1
    rho_30    block_pair_pos_247  -1
    rho_30    block_pair_neg_248  1
    rho_30    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       0.048
    x_35_0    product_lb_21  -2.4534859946816593e-02
    x_35_0    product_ub_22  -0.0406071739341023
    x_35_0    onehot_35_53  1
    x_35_0    parent_nonstrict_scope_222  0.096
    x_35_0    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_21  1
    w_35_0    product_ub_22  1
    w_35_0    normalized_mass_35_54  1
    w_35_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       3.6000000000000004e-02
    x_35_1    product_lb_23  -2.4534859946816593e-02
    x_35_1    product_ub_24  -0.0406071739341023
    x_35_1    onehot_35_53  1
    x_35_1    stock_lb_220  1
    x_35_1    stock_ub_221  1
    x_35_1    parent_nonstrict_scope_222  0.084
    x_35_1    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_23  1
    w_35_1    product_ub_24  1
    w_35_1    normalized_mass_35_54  1
    w_35_1    normalized_ratio_35_55  -0.125
    w_35_1    full_original_Gini_280  -2.1251190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       2.4000000000000007e-02
    x_35_2    product_lb_25  -2.4534859946816593e-02
    x_35_2    product_ub_26  -0.0406071739341023
    x_35_2    onehot_35_53  1
    x_35_2    stock_lb_220  2
    x_35_2    stock_ub_221  2
    x_35_2    parent_nonstrict_scope_222  7.2000000000000008e-02
    x_35_2    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_25  1
    w_35_2    product_ub_26  1
    w_35_2    normalized_mass_35_54  1
    w_35_2    normalized_ratio_35_55  -0.25
    w_35_2    full_original_Gini_280  -1.7876190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       1.1999999999999997e-02
    x_35_3    product_lb_27  -2.4534859946816593e-02
    x_35_3    product_ub_28  -0.0406071739341023
    x_35_3    onehot_35_53  1
    x_35_3    stock_lb_220  3
    x_35_3    stock_ub_221  3
    x_35_3    parent_nonstrict_scope_222  0.06
    x_35_3    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_27  1
    w_35_3    product_ub_28  1
    w_35_3    normalized_mass_35_54  1
    w_35_3    normalized_ratio_35_55  -0.375
    w_35_3    full_original_Gini_280  -1.4501190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_29  -2.4534859946816593e-02
    x_35_4    product_ub_30  -0.0406071739341023
    x_35_4    onehot_35_53  1
    x_35_4    stock_lb_220  4
    x_35_4    stock_ub_221  4
    x_35_4    parent_nonstrict_scope_222  0.048
    x_35_4    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_29  1
    w_35_4    product_ub_30  1
    w_35_4    normalized_mass_35_54  1
    w_35_4    normalized_ratio_35_55  -0.5
    w_35_4    full_original_Gini_280  -1.1126190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -1.1999999999999997e-02
    x_35_5    product_lb_31  -2.4534859946816593e-02
    x_35_5    product_ub_32  -0.0406071739341023
    x_35_5    onehot_35_53  1
    x_35_5    stock_lb_220  5
    x_35_5    stock_ub_221  5
    x_35_5    parent_nonstrict_scope_222  3.6000000000000004e-02
    x_35_5    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_31  1
    w_35_5    product_ub_32  1
    w_35_5    normalized_mass_35_54  1
    w_35_5    normalized_ratio_35_55  -0.625
    w_35_5    full_original_Gini_280  -7.8511904761904763e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -0.024
    x_35_6    product_lb_33  -2.4534859946816593e-02
    x_35_6    product_ub_34  -0.0406071739341023
    x_35_6    onehot_35_53  1
    x_35_6    stock_lb_220  6
    x_35_6    stock_ub_221  6
    x_35_6    parent_nonstrict_scope_222  0.024
    x_35_6    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_33  1
    w_35_6    product_ub_34  1
    w_35_6    normalized_mass_35_54  1
    w_35_6    normalized_ratio_35_55  -0.75
    w_35_6    full_original_Gini_280  -5.19047619047619
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -3.6000000000000004e-02
    x_35_7    product_lb_35  -2.4534859946816593e-02
    x_35_7    product_ub_36  -0.0406071739341023
    x_35_7    onehot_35_53  1
    x_35_7    stock_lb_220  7
    x_35_7    stock_ub_221  7
    x_35_7    parent_nonstrict_scope_222  0.012
    x_35_7    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_35  1
    w_35_7    product_ub_36  1
    w_35_7    normalized_mass_35_54  1
    w_35_7    normalized_ratio_35_55  -0.875
    w_35_7    full_original_Gini_280  -4.0488095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -0.048
    x_35_8    product_lb_37  -2.4534859946816593e-02
    x_35_8    product_ub_38  -0.0406071739341023
    x_35_8    onehot_35_53  1
    x_35_8    stock_lb_220  8
    x_35_8    stock_ub_221  8
    x_35_8    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_37  1
    w_35_8    product_ub_38  1
    w_35_8    normalized_mass_35_54  1
    w_35_8    normalized_ratio_35_55  -1
    w_35_8    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -3.6000000000000004e-02
    x_35_9    product_lb_39  -2.4534859946816593e-02
    x_35_9    product_ub_40  -0.0406071739341023
    x_35_9    onehot_35_53  1
    x_35_9    stock_lb_220  9
    x_35_9    stock_ub_221  9
    x_35_9    parent_nonstrict_scope_222  0.012
    x_35_9    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_39  1
    w_35_9    product_ub_40  1
    w_35_9    normalized_mass_35_54  1
    w_35_9    normalized_ratio_35_55  -1.125
    w_35_9    full_original_Gini_280  -6.0488095238095241e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -0.024
    x_35_10   product_lb_41  -2.4534859946816593e-02
    x_35_10   product_ub_42  -0.0406071739341023
    x_35_10   onehot_35_53  1
    x_35_10   stock_lb_220  10
    x_35_10   stock_ub_221  10
    x_35_10   parent_nonstrict_scope_222  0.024
    x_35_10   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_41  1
    w_35_10   product_ub_42  1
    w_35_10   normalized_mass_35_54  1
    w_35_10   normalized_ratio_35_55  -1.25
    w_35_10   full_original_Gini_280  -9.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -1.1999999999999997e-02
    x_35_11   product_lb_43  -2.4534859946816593e-02
    x_35_11   product_ub_44  -0.0406071739341023
    x_35_11   onehot_35_53  1
    x_35_11   stock_lb_220  11
    x_35_11   stock_ub_221  11
    x_35_11   parent_nonstrict_scope_222  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_43  1
    w_35_11   product_ub_44  1
    w_35_11   normalized_mass_35_54  1
    w_35_11   normalized_ratio_35_55  -1.375
    w_35_11   full_original_Gini_280  -1.2498809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_45  -2.4534859946816593e-02
    x_35_12   product_ub_46  -0.0406071739341023
    x_35_12   onehot_35_53  1
    x_35_12   stock_lb_220  12
    x_35_12   stock_ub_221  12
    x_35_12   parent_nonstrict_scope_222  0.048
    x_35_12   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_45  1
    w_35_12   product_ub_46  1
    w_35_12   normalized_mass_35_54  1
    w_35_12   normalized_ratio_35_55  -1.5
    w_35_12   full_original_Gini_280  -1.5873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       1.1999999999999997e-02
    x_35_13   product_lb_47  -2.4534859946816593e-02
    x_35_13   product_ub_48  -0.0406071739341023
    x_35_13   onehot_35_53  1
    x_35_13   stock_lb_220  13
    x_35_13   stock_ub_221  13
    x_35_13   parent_nonstrict_scope_222  0.06
    x_35_13   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_47  1
    w_35_13   product_ub_48  1
    w_35_13   normalized_mass_35_54  1
    w_35_13   normalized_ratio_35_55  -1.625
    w_35_13   full_original_Gini_280  -1.9248809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       2.4000000000000007e-02
    x_35_14   product_lb_49  -2.4534859946816593e-02
    x_35_14   product_ub_50  -0.0406071739341023
    x_35_14   onehot_35_53  1
    x_35_14   stock_lb_220  14
    x_35_14   stock_ub_221  14
    x_35_14   parent_nonstrict_scope_222  7.2000000000000008e-02
    x_35_14   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_49  1
    w_35_14   product_ub_50  1
    w_35_14   normalized_mass_35_54  1
    w_35_14   normalized_ratio_35_55  -1.75
    w_35_14   full_original_Gini_280  -2.2623809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       3.6000000000000004e-02
    x_35_15   product_lb_51  -2.4534859946816593e-02
    x_35_15   product_ub_52  -0.0406071739341023
    x_35_15   onehot_35_53  1
    x_35_15   stock_lb_220  15
    x_35_15   stock_ub_221  15
    x_35_15   parent_nonstrict_scope_222  0.084
    x_35_15   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_51  1
    w_35_15   product_ub_52  1
    w_35_15   normalized_mass_35_54  1
    w_35_15   normalized_ratio_35_55  -1.875
    w_35_15   full_original_Gini_280  -2.5998809523809520e+01
    rho_35    normalized_ratio_35_55  1
    rho_35    block_pair_pos_247  1
    rho_35    block_pair_neg_248  -1
    rho_35    block_pair_pos_267  -1
    rho_35    block_pair_neg_268  1
    rho_35    block_pair_pos_269  -1
    rho_35    block_pair_neg_270  1
    rho_35    block_pair_pos_271  -1
    rho_35    block_pair_neg_272  1
    rho_35    block_pair_pos_273  -1
    rho_35    block_pair_neg_274  1
    rho_35    block_pair_pos_275  -1
    rho_35    block_pair_neg_276  1
    rho_35    block_pair_pos_277  -1
    rho_35    block_pair_neg_278  1
    rho_35    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_56  -2.4534859946816593e-02
    x_31_0    product_ub_57  -0.0406071739341023
    x_31_0    onehot_31_82  1
    x_31_0    parent_nonstrict_scope_222  0.0735
    x_31_0    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_56  1
    w_31_0    product_ub_57  1
    w_31_0    normalized_mass_31_83  1
    w_31_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_58  -2.4534859946816593e-02
    x_31_1    product_ub_59  -0.0406071739341023
    x_31_1    onehot_31_82  1
    x_31_1    stock_lb_220  1
    x_31_1    stock_ub_221  1
    x_31_1    parent_nonstrict_scope_222  0.063
    x_31_1    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_58  1
    w_31_1    product_ub_59  1
    w_31_1    normalized_mass_31_83  1
    w_31_1    normalized_ratio_31_84  -1.4285714285714285e-01
    w_31_1    full_original_Gini_280  -2.0769047619047626e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_60  -2.4534859946816593e-02
    x_31_2    product_ub_61  -0.0406071739341023
    x_31_2    onehot_31_82  1
    x_31_2    stock_lb_220  2
    x_31_2    stock_ub_221  2
    x_31_2    parent_nonstrict_scope_222  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_60  1
    w_31_2    product_ub_61  1
    w_31_2    normalized_mass_31_83  1
    w_31_2    normalized_ratio_31_84  -2.8571428571428570e-01
    w_31_2    full_original_Gini_280  -1.6911904761904754e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_62  -2.4534859946816593e-02
    x_31_3    product_ub_63  -0.0406071739341023
    x_31_3    onehot_31_82  1
    x_31_3    stock_lb_220  3
    x_31_3    stock_ub_221  3
    x_31_3    parent_nonstrict_scope_222  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_62  1
    w_31_3    product_ub_63  1
    w_31_3    normalized_mass_31_83  1
    w_31_3    normalized_ratio_31_84  -4.2857142857142855e-01
    w_31_3    full_original_Gini_280  -1.3054761904761904e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_64  -2.4534859946816593e-02
    x_31_4    product_ub_65  -0.0406071739341023
    x_31_4    onehot_31_82  1
    x_31_4    stock_lb_220  4
    x_31_4    stock_ub_221  4
    x_31_4    parent_nonstrict_scope_222  0.0315
    x_31_4    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_64  1
    w_31_4    product_ub_65  1
    w_31_4    normalized_mass_31_83  1
    w_31_4    normalized_ratio_31_84  -5.7142857142857140e-01
    w_31_4    full_original_Gini_280  -9.1976190476190514e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_66  -2.4534859946816593e-02
    x_31_5    product_ub_67  -0.0406071739341023
    x_31_5    onehot_31_82  1
    x_31_5    stock_lb_220  5
    x_31_5    stock_ub_221  5
    x_31_5    parent_nonstrict_scope_222  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_66  1
    w_31_5    product_ub_67  1
    w_31_5    normalized_mass_31_83  1
    w_31_5    normalized_ratio_31_84  -7.1428571428571419e-01
    w_31_5    full_original_Gini_280  -5.7976190476190474e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_68  -2.4534859946816593e-02
    x_31_6    product_ub_69  -0.0406071739341023
    x_31_6    onehot_31_82  1
    x_31_6    stock_lb_220  6
    x_31_6    stock_ub_221  6
    x_31_6    parent_nonstrict_scope_222  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_68  1
    w_31_6    product_ub_69  1
    w_31_6    normalized_mass_31_83  1
    w_31_6    normalized_ratio_31_84  -8.5714285714285710e-01
    w_31_6    full_original_Gini_280  -4.1738095238095232e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_70  -2.4534859946816593e-02
    x_31_7    product_ub_71  -0.0406071739341023
    x_31_7    onehot_31_82  1
    x_31_7    stock_lb_220  7
    x_31_7    stock_ub_221  7
    x_31_7    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_70  1
    w_31_7    product_ub_71  1
    w_31_7    normalized_mass_31_83  1
    w_31_7    normalized_ratio_31_84  -1
    w_31_7    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_72  -2.4534859946816593e-02
    x_31_8    product_ub_73  -0.0406071739341023
    x_31_8    onehot_31_82  1
    x_31_8    stock_lb_220  8
    x_31_8    stock_ub_221  8
    x_31_8    parent_nonstrict_scope_222  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_72  1
    w_31_8    product_ub_73  1
    w_31_8    normalized_mass_31_83  1
    w_31_8    normalized_ratio_31_84  -1.1428571428571428e+00
    w_31_8    full_original_Gini_280  -6.4595238095238070e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_74  -2.4534859946816593e-02
    x_31_9    product_ub_75  -0.0406071739341023
    x_31_9    onehot_31_82  1
    x_31_9    stock_lb_220  9
    x_31_9    stock_ub_221  9
    x_31_9    parent_nonstrict_scope_222  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_74  1
    w_31_9    product_ub_75  1
    w_31_9    normalized_mass_31_83  1
    w_31_9    normalized_ratio_31_84  -1.2857142857142856e+00
    w_31_9    full_original_Gini_280  -1.0088095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_76  -2.4534859946816593e-02
    x_31_10   product_ub_77  -0.0406071739341023
    x_31_10   onehot_31_82  1
    x_31_10   stock_lb_220  10
    x_31_10   stock_ub_221  10
    x_31_10   parent_nonstrict_scope_222  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_76  1
    w_31_10   product_ub_77  1
    w_31_10   normalized_mass_31_83  1
    w_31_10   normalized_ratio_31_84  -1.4285714285714284e+00
    w_31_10   full_original_Gini_280  -1.3945238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_78  -2.4534859946816593e-02
    x_31_11   product_ub_79  -0.0406071739341023
    x_31_11   onehot_31_82  1
    x_31_11   stock_lb_220  11
    x_31_11   stock_ub_221  11
    x_31_11   parent_nonstrict_scope_222  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_78  1
    w_31_11   product_ub_79  1
    w_31_11   normalized_mass_31_83  1
    w_31_11   normalized_ratio_31_84  -1.5714285714285714e+00
    w_31_11   full_original_Gini_280  -1.7802380952380947e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_80  -2.4534859946816593e-02
    x_31_12   product_ub_81  -0.0406071739341023
    x_31_12   onehot_31_82  1
    x_31_12   stock_lb_220  12
    x_31_12   stock_ub_221  12
    x_31_12   parent_nonstrict_scope_222  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_80  1
    w_31_12   product_ub_81  1
    w_31_12   normalized_mass_31_83  1
    w_31_12   normalized_ratio_31_84  -1.7142857142857142e+00
    w_31_12   full_original_Gini_280  -2.1659523809523808e+01
    rho_31    normalized_ratio_31_84  1
    rho_31    block_pair_pos_243  1
    rho_31    block_pair_neg_244  -1
    rho_31    block_pair_pos_249  -1
    rho_31    block_pair_neg_250  1
    rho_31    block_pair_pos_251  -1
    rho_31    block_pair_neg_252  1
    rho_31    block_pair_pos_253  -1
    rho_31    block_pair_neg_254  1
    rho_31    block_pair_pos_255  -1
    rho_31    block_pair_neg_256  1
    rho_31    block_pair_pos_257  -1
    rho_31    block_pair_neg_258  1
    rho_31    block_pair_pos_275  1
    rho_31    block_pair_neg_276  -1
    rho_31    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_85  -2.4534859946816593e-02
    x_32_0    product_ub_86  -0.0406071739341023
    x_32_0    onehot_32_111  1
    x_32_0    parent_nonstrict_scope_222  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_85  1
    w_32_0    product_ub_86  1
    w_32_0    normalized_mass_32_112  1
    w_32_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_87  -2.4534859946816593e-02
    x_32_1    product_ub_88  -0.0406071739341023
    x_32_1    onehot_32_111  1
    x_32_1    stock_lb_220  1
    x_32_1    stock_ub_221  1
    x_32_1    parent_nonstrict_scope_222  0.03
    x_32_1    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_87  1
    w_32_1    product_ub_88  1
    w_32_1    normalized_mass_32_112  1
    w_32_1    normalized_ratio_32_113  -0.2
    w_32_1    full_original_Gini_280  -1.9226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_89  -2.4534859946816593e-02
    x_32_2    product_ub_90  -0.0406071739341023
    x_32_2    onehot_32_111  1
    x_32_2    stock_lb_220  2
    x_32_2    stock_ub_221  2
    x_32_2    parent_nonstrict_scope_222  0.0225
    x_32_2    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_89  1
    w_32_2    product_ub_90  1
    w_32_2    normalized_mass_32_112  1
    w_32_2    normalized_ratio_32_113  -0.4
    w_32_2    full_original_Gini_280  -1.3826190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_91  -2.4534859946816593e-02
    x_32_3    product_ub_92  -0.0406071739341023
    x_32_3    onehot_32_111  1
    x_32_3    stock_lb_220  3
    x_32_3    stock_ub_221  3
    x_32_3    parent_nonstrict_scope_222  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_91  1
    w_32_3    product_ub_92  1
    w_32_3    normalized_mass_32_112  1
    w_32_3    normalized_ratio_32_113  -6.0000000000000009e-01
    w_32_3    full_original_Gini_280  -8.4261904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_93  -2.4534859946816593e-02
    x_32_4    product_ub_94  -0.0406071739341023
    x_32_4    onehot_32_111  1
    x_32_4    stock_lb_220  4
    x_32_4    stock_ub_221  4
    x_32_4    parent_nonstrict_scope_222  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_93  1
    w_32_4    product_ub_94  1
    w_32_4    normalized_mass_32_112  1
    w_32_4    normalized_ratio_32_113  -0.8
    w_32_4    full_original_Gini_280  -4.6404761904761918e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_95  -2.4534859946816593e-02
    x_32_5    product_ub_96  -0.0406071739341023
    x_32_5    onehot_32_111  1
    x_32_5    stock_lb_220  5
    x_32_5    stock_ub_221  5
    x_32_5    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_95  1
    w_32_5    product_ub_96  1
    w_32_5    normalized_mass_32_112  1
    w_32_5    normalized_ratio_32_113  -1
    w_32_5    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_97  -2.4534859946816593e-02
    x_32_6    product_ub_98  -0.0406071739341023
    x_32_6    onehot_32_111  1
    x_32_6    stock_lb_220  6
    x_32_6    stock_ub_221  6
    x_32_6    parent_nonstrict_scope_222  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_97  1
    w_32_6    product_ub_98  1
    w_32_6    normalized_mass_32_112  1
    w_32_6    normalized_ratio_32_113  -1.2000000000000002e+00
    w_32_6    full_original_Gini_280  -7.7738095238095273e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_99  -2.4534859946816593e-02
    x_32_7    product_ub_100  -0.0406071739341023
    x_32_7    onehot_32_111  1
    x_32_7    stock_lb_220  7
    x_32_7    stock_ub_221  7
    x_32_7    parent_nonstrict_scope_222  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_99  1
    w_32_7    product_ub_100  1
    w_32_7    normalized_mass_32_112  1
    w_32_7    normalized_ratio_32_113  -1.4000000000000001e+00
    w_32_7    full_original_Gini_280  -1.3173809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_101  -2.4534859946816593e-02
    x_32_8    product_ub_102  -0.0406071739341023
    x_32_8    onehot_32_111  1
    x_32_8    stock_lb_220  8
    x_32_8    stock_ub_221  8
    x_32_8    parent_nonstrict_scope_222  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_101  1
    w_32_8    product_ub_102  1
    w_32_8    normalized_mass_32_112  1
    w_32_8    normalized_ratio_32_113  -1.6
    w_32_8    full_original_Gini_280  -1.8573809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_103  -2.4534859946816593e-02
    x_32_9    product_ub_104  -0.0406071739341023
    x_32_9    onehot_32_111  1
    x_32_9    stock_lb_220  9
    x_32_9    stock_ub_221  9
    x_32_9    parent_nonstrict_scope_222  0.03
    x_32_9    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_103  1
    w_32_9    product_ub_104  1
    w_32_9    normalized_mass_32_112  1
    w_32_9    normalized_ratio_32_113  -1.8
    w_32_9    full_original_Gini_280  -2.3973809523809532e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_105  -2.4534859946816593e-02
    x_32_10   product_ub_106  -0.0406071739341023
    x_32_10   onehot_32_111  1
    x_32_10   stock_lb_220  10
    x_32_10   stock_ub_221  10
    x_32_10   parent_nonstrict_scope_222  0.0375
    x_32_10   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_105  1
    w_32_10   product_ub_106  1
    w_32_10   normalized_mass_32_112  1
    w_32_10   normalized_ratio_32_113  -2
    w_32_10   full_original_Gini_280  -2.9373809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_107  -2.4534859946816593e-02
    x_32_11   product_ub_108  -0.0406071739341023
    x_32_11   onehot_32_111  1
    x_32_11   stock_lb_220  11
    x_32_11   stock_ub_221  11
    x_32_11   parent_nonstrict_scope_222  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_107  1
    w_32_11   product_ub_108  1
    w_32_11   normalized_mass_32_112  1
    w_32_11   normalized_ratio_32_113  -2.2
    w_32_11   full_original_Gini_280  -3.4773809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_109  -2.4534859946816593e-02
    x_32_12   product_ub_110  -0.0406071739341023
    x_32_12   onehot_32_111  1
    x_32_12   stock_lb_220  12
    x_32_12   stock_ub_221  12
    x_32_12   parent_nonstrict_scope_222  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_109  1
    w_32_12   product_ub_110  1
    w_32_12   normalized_mass_32_112  1
    w_32_12   normalized_ratio_32_113  -2.4000000000000004e+00
    w_32_12   full_original_Gini_280  -40.1738095238095
    rho_32    normalized_ratio_32_113  1
    rho_32    block_pair_pos_245  1
    rho_32    block_pair_neg_246  -1
    rho_32    block_pair_pos_257  1
    rho_32    block_pair_neg_258  -1
    rho_32    block_pair_pos_259  -1
    rho_32    block_pair_neg_260  1
    rho_32    block_pair_pos_261  -1
    rho_32    block_pair_neg_262  1
    rho_32    block_pair_pos_263  -1
    rho_32    block_pair_neg_264  1
    rho_32    block_pair_pos_265  -1
    rho_32    block_pair_neg_266  1
    rho_32    block_pair_pos_277  1
    rho_32    block_pair_neg_278  -1
    rho_32    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_114  -2.4534859946816593e-02
    x_2_0     product_ub_115  -0.0406071739341023
    x_2_0     onehot_2_146  1
    x_2_0     parent_nonstrict_scope_222  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_114  1
    w_2_0     product_ub_115  1
    w_2_0     normalized_mass_2_147  1
    w_2_0     full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_116  -2.4534859946816593e-02
    x_2_1     product_ub_117  -0.0406071739341023
    x_2_1     onehot_2_146  1
    x_2_1     stock_lb_220  1
    x_2_1     stock_ub_221  1
    x_2_1     parent_nonstrict_scope_222  0.063
    x_2_1     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_116  1
    w_2_1     product_ub_117  1
    w_2_1     normalized_mass_2_147  1
    w_2_1     normalized_ratio_2_148  -1.4285714285714285e-01
    w_2_1     full_original_Gini_280  -2.0769047619047626e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_118  -2.4534859946816593e-02
    x_2_2     product_ub_119  -0.0406071739341023
    x_2_2     onehot_2_146  1
    x_2_2     stock_lb_220  2
    x_2_2     stock_ub_221  2
    x_2_2     parent_nonstrict_scope_222  0.0525
    x_2_2     unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_118  1
    w_2_2     product_ub_119  1
    w_2_2     normalized_mass_2_147  1
    w_2_2     normalized_ratio_2_148  -2.8571428571428570e-01
    w_2_2     full_original_Gini_280  -1.6911904761904754e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_120  -2.4534859946816593e-02
    x_2_3     product_ub_121  -0.0406071739341023
    x_2_3     onehot_2_146  1
    x_2_3     stock_lb_220  3
    x_2_3     stock_ub_221  3
    x_2_3     parent_nonstrict_scope_222  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_120  1
    w_2_3     product_ub_121  1
    w_2_3     normalized_mass_2_147  1
    w_2_3     normalized_ratio_2_148  -4.2857142857142855e-01
    w_2_3     full_original_Gini_280  -1.3054761904761904e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_122  -2.4534859946816593e-02
    x_2_4     product_ub_123  -0.0406071739341023
    x_2_4     onehot_2_146  1
    x_2_4     stock_lb_220  4
    x_2_4     stock_ub_221  4
    x_2_4     parent_nonstrict_scope_222  0.0315
    x_2_4     unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_122  1
    w_2_4     product_ub_123  1
    w_2_4     normalized_mass_2_147  1
    w_2_4     normalized_ratio_2_148  -5.7142857142857140e-01
    w_2_4     full_original_Gini_280  -9.1976190476190514e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_124  -2.4534859946816593e-02
    x_2_5     product_ub_125  -0.0406071739341023
    x_2_5     onehot_2_146  1
    x_2_5     stock_lb_220  5
    x_2_5     stock_ub_221  5
    x_2_5     parent_nonstrict_scope_222  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_124  1
    w_2_5     product_ub_125  1
    w_2_5     normalized_mass_2_147  1
    w_2_5     normalized_ratio_2_148  -7.1428571428571419e-01
    w_2_5     full_original_Gini_280  -5.7976190476190474e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_126  -2.4534859946816593e-02
    x_2_6     product_ub_127  -0.0406071739341023
    x_2_6     onehot_2_146  1
    x_2_6     stock_lb_220  6
    x_2_6     stock_ub_221  6
    x_2_6     parent_nonstrict_scope_222  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_126  1
    w_2_6     product_ub_127  1
    w_2_6     normalized_mass_2_147  1
    w_2_6     normalized_ratio_2_148  -8.5714285714285710e-01
    w_2_6     full_original_Gini_280  -4.1738095238095232e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_128  -2.4534859946816593e-02
    x_2_7     product_ub_129  -0.0406071739341023
    x_2_7     onehot_2_146  1
    x_2_7     stock_lb_220  7
    x_2_7     stock_ub_221  7
    x_2_7     unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_128  1
    w_2_7     product_ub_129  1
    w_2_7     normalized_mass_2_147  1
    w_2_7     normalized_ratio_2_148  -1
    w_2_7     full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_130  -2.4534859946816593e-02
    x_2_8     product_ub_131  -0.0406071739341023
    x_2_8     onehot_2_146  1
    x_2_8     stock_lb_220  8
    x_2_8     stock_ub_221  8
    x_2_8     parent_nonstrict_scope_222  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_130  1
    w_2_8     product_ub_131  1
    w_2_8     normalized_mass_2_147  1
    w_2_8     normalized_ratio_2_148  -1.1428571428571428e+00
    w_2_8     full_original_Gini_280  -6.4595238095238070e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_132  -2.4534859946816593e-02
    x_2_9     product_ub_133  -0.0406071739341023
    x_2_9     onehot_2_146  1
    x_2_9     stock_lb_220  9
    x_2_9     stock_ub_221  9
    x_2_9     parent_nonstrict_scope_222  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_132  1
    w_2_9     product_ub_133  1
    w_2_9     normalized_mass_2_147  1
    w_2_9     normalized_ratio_2_148  -1.2857142857142856e+00
    w_2_9     full_original_Gini_280  -1.0088095238095232e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_134  -2.4534859946816593e-02
    x_2_10    product_ub_135  -0.0406071739341023
    x_2_10    onehot_2_146  1
    x_2_10    stock_lb_220  10
    x_2_10    stock_ub_221  10
    x_2_10    parent_nonstrict_scope_222  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_134  1
    w_2_10    product_ub_135  1
    w_2_10    normalized_mass_2_147  1
    w_2_10    normalized_ratio_2_148  -1.4285714285714284e+00
    w_2_10    full_original_Gini_280  -1.3945238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_136  -2.4534859946816593e-02
    x_2_11    product_ub_137  -0.0406071739341023
    x_2_11    onehot_2_146  1
    x_2_11    stock_lb_220  11
    x_2_11    stock_ub_221  11
    x_2_11    parent_nonstrict_scope_222  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_136  1
    w_2_11    product_ub_137  1
    w_2_11    normalized_mass_2_147  1
    w_2_11    normalized_ratio_2_148  -1.5714285714285714e+00
    w_2_11    full_original_Gini_280  -1.7802380952380947e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_138  -2.4534859946816593e-02
    x_2_12    product_ub_139  -0.0406071739341023
    x_2_12    onehot_2_146  1
    x_2_12    stock_lb_220  12
    x_2_12    stock_ub_221  12
    x_2_12    parent_nonstrict_scope_222  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_138  1
    w_2_12    product_ub_139  1
    w_2_12    normalized_mass_2_147  1
    w_2_12    normalized_ratio_2_148  -1.7142857142857142e+00
    w_2_12    full_original_Gini_280  -2.1659523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_140  -2.4534859946816593e-02
    x_2_13    product_ub_141  -0.0406071739341023
    x_2_13    onehot_2_146  1
    x_2_13    stock_lb_220  13
    x_2_13    stock_ub_221  13
    x_2_13    parent_nonstrict_scope_222  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_140  1
    w_2_13    product_ub_141  1
    w_2_13    normalized_mass_2_147  1
    w_2_13    normalized_ratio_2_148  -1.8571428571428570e+00
    w_2_13    full_original_Gini_280  -2.5516666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_142  -2.4534859946816593e-02
    x_2_14    product_ub_143  -0.0406071739341023
    x_2_14    onehot_2_146  1
    x_2_14    stock_lb_220  14
    x_2_14    stock_ub_221  14
    x_2_14    parent_nonstrict_scope_222  0.0735
    x_2_14    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_142  1
    w_2_14    product_ub_143  1
    w_2_14    normalized_mass_2_147  1
    w_2_14    normalized_ratio_2_148  -2
    w_2_14    full_original_Gini_280  -2.9373809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_144  -2.4534859946816593e-02
    x_2_15    product_ub_145  -0.0406071739341023
    x_2_15    onehot_2_146  1
    x_2_15    stock_lb_220  15
    x_2_15    stock_ub_221  15
    x_2_15    parent_nonstrict_scope_222  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_144  1
    w_2_15    product_ub_145  1
    w_2_15    normalized_mass_2_147  1
    w_2_15    normalized_ratio_2_148  -2.1428571428571428e+00
    w_2_15    full_original_Gini_280  -3.3230952380952374e+01
    rho_2     normalized_ratio_2_148  1
    rho_2     block_pair_pos_223  -1
    rho_2     block_pair_neg_224  1
    rho_2     block_pair_pos_225  -1
    rho_2     block_pair_neg_226  1
    rho_2     block_pair_pos_227  -1
    rho_2     block_pair_neg_228  1
    rho_2     block_pair_pos_235  1
    rho_2     block_pair_neg_236  -1
    rho_2     block_pair_pos_249  1
    rho_2     block_pair_neg_250  -1
    rho_2     block_pair_pos_259  1
    rho_2     block_pair_neg_260  -1
    rho_2     block_pair_pos_267  1
    rho_2     block_pair_neg_268  -1
    rho_2     normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       0.012
    x_26_0    product_lb_149  -2.4534859946816593e-02
    x_26_0    product_ub_150  -0.0406071739341023
    x_26_0    onehot_26_167  1
    x_26_0    parent_nonstrict_scope_222  0.024
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_149  1
    w_26_0    product_ub_150  1
    w_26_0    normalized_mass_26_168  1
    w_26_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       6.0000000000000019e-03
    x_26_1    product_lb_151  -2.4534859946816593e-02
    x_26_1    product_ub_152  -0.0406071739341023
    x_26_1    onehot_26_167  1
    x_26_1    stock_lb_220  1
    x_26_1    stock_ub_221  1
    x_26_1    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_26_1    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_151  1
    w_26_1    product_ub_152  1
    w_26_1    normalized_mass_26_168  1
    w_26_1    normalized_ratio_26_169  -0.25
    w_26_1    full_original_Gini_280  -1.7876190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_153  -2.4534859946816593e-02
    x_26_2    product_ub_154  -0.0406071739341023
    x_26_2    onehot_26_167  1
    x_26_2    stock_lb_220  2
    x_26_2    stock_ub_221  2
    x_26_2    parent_nonstrict_scope_222  0.012
    x_26_2    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_153  1
    w_26_2    product_ub_154  1
    w_26_2    normalized_mass_26_168  1
    w_26_2    normalized_ratio_26_169  -0.5
    w_26_2    full_original_Gini_280  -1.1126190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -0.006
    x_26_3    product_lb_155  -2.4534859946816593e-02
    x_26_3    product_ub_156  -0.0406071739341023
    x_26_3    onehot_26_167  1
    x_26_3    stock_lb_220  3
    x_26_3    stock_ub_221  3
    x_26_3    parent_nonstrict_scope_222  0.006
    x_26_3    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_155  1
    w_26_3    product_ub_156  1
    w_26_3    normalized_mass_26_168  1
    w_26_3    normalized_ratio_26_169  -0.75
    w_26_3    full_original_Gini_280  -5.19047619047619
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -0.012
    x_26_4    product_lb_157  -2.4534859946816593e-02
    x_26_4    product_ub_158  -0.0406071739341023
    x_26_4    onehot_26_167  1
    x_26_4    stock_lb_220  4
    x_26_4    stock_ub_221  4
    x_26_4    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_157  1
    w_26_4    product_ub_158  1
    w_26_4    normalized_mass_26_168  1
    w_26_4    normalized_ratio_26_169  -1
    w_26_4    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -0.006
    x_26_5    product_lb_159  -2.4534859946816593e-02
    x_26_5    product_ub_160  -0.0406071739341023
    x_26_5    onehot_26_167  1
    x_26_5    stock_lb_220  5
    x_26_5    stock_ub_221  5
    x_26_5    parent_nonstrict_scope_222  0.006
    x_26_5    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_159  1
    w_26_5    product_ub_160  1
    w_26_5    normalized_mass_26_168  1
    w_26_5    normalized_ratio_26_169  -1.25
    w_26_5    full_original_Gini_280  -9.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_161  -2.4534859946816593e-02
    x_26_6    product_ub_162  -0.0406071739341023
    x_26_6    onehot_26_167  1
    x_26_6    stock_lb_220  6
    x_26_6    stock_ub_221  6
    x_26_6    parent_nonstrict_scope_222  0.012
    x_26_6    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_161  1
    w_26_6    product_ub_162  1
    w_26_6    normalized_mass_26_168  1
    w_26_6    normalized_ratio_26_169  -1.5
    w_26_6    full_original_Gini_280  -1.5873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       6.0000000000000019e-03
    x_26_7    product_lb_163  -2.4534859946816593e-02
    x_26_7    product_ub_164  -0.0406071739341023
    x_26_7    onehot_26_167  1
    x_26_7    stock_lb_220  7
    x_26_7    stock_ub_221  7
    x_26_7    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_26_7    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_163  1
    w_26_7    product_ub_164  1
    w_26_7    normalized_mass_26_168  1
    w_26_7    normalized_ratio_26_169  -1.75
    w_26_7    full_original_Gini_280  -2.2623809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       0.012
    x_26_8    product_lb_165  -2.4534859946816593e-02
    x_26_8    product_ub_166  -0.0406071739341023
    x_26_8    onehot_26_167  1
    x_26_8    stock_lb_220  8
    x_26_8    stock_ub_221  8
    x_26_8    parent_nonstrict_scope_222  0.024
    x_26_8    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_165  1
    w_26_8    product_ub_166  1
    w_26_8    normalized_mass_26_168  1
    w_26_8    normalized_ratio_26_169  -2
    w_26_8    full_original_Gini_280  -2.9373809523809520e+01
    rho_26    normalized_ratio_26_169  1
    rho_26    block_pair_pos_227  1
    rho_26    block_pair_neg_228  -1
    rho_26    block_pair_pos_231  -1
    rho_26    block_pair_neg_232  1
    rho_26    block_pair_pos_233  -1
    rho_26    block_pair_neg_234  1
    rho_26    block_pair_pos_241  1
    rho_26    block_pair_neg_242  -1
    rho_26    block_pair_pos_255  1
    rho_26    block_pair_neg_256  -1
    rho_26    block_pair_pos_265  1
    rho_26    block_pair_neg_266  -1
    rho_26    block_pair_pos_273  1
    rho_26    block_pair_neg_274  -1
    rho_26    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_170  -2.4534859946816593e-02
    x_16_0    product_ub_171  -0.0406071739341023
    x_16_0    onehot_16_196  1
    x_16_0    parent_nonstrict_scope_222  0.054
    x_16_0    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_170  1
    w_16_0    product_ub_171  1
    w_16_0    normalized_mass_16_197  1
    w_16_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_172  -2.4534859946816593e-02
    x_16_1    product_ub_173  -0.0406071739341023
    x_16_1    onehot_16_196  1
    x_16_1    stock_lb_220  1
    x_16_1    stock_ub_221  1
    x_16_1    parent_nonstrict_scope_222  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_172  1
    w_16_1    product_ub_173  1
    w_16_1    normalized_mass_16_197  1
    w_16_1    normalized_ratio_16_198  -1.6666666666666666e-01
    w_16_1    full_original_Gini_280  -2.0126190476190477e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_174  -2.4534859946816593e-02
    x_16_2    product_ub_175  -0.0406071739341023
    x_16_2    onehot_16_196  1
    x_16_2    stock_lb_220  2
    x_16_2    stock_ub_221  2
    x_16_2    parent_nonstrict_scope_222  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_174  1
    w_16_2    product_ub_175  1
    w_16_2    normalized_mass_16_197  1
    w_16_2    normalized_ratio_16_198  -3.3333333333333331e-01
    w_16_2    full_original_Gini_280  -1.5626190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_176  -2.4534859946816593e-02
    x_16_3    product_ub_177  -0.0406071739341023
    x_16_3    onehot_16_196  1
    x_16_3    stock_lb_220  3
    x_16_3    stock_ub_221  3
    x_16_3    parent_nonstrict_scope_222  0.027
    x_16_3    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_176  1
    w_16_3    product_ub_177  1
    w_16_3    normalized_mass_16_197  1
    w_16_3    normalized_ratio_16_198  -0.5
    w_16_3    full_original_Gini_280  -1.1126190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_178  -2.4534859946816593e-02
    x_16_4    product_ub_179  -0.0406071739341023
    x_16_4    onehot_16_196  1
    x_16_4    stock_lb_220  4
    x_16_4    stock_ub_221  4
    x_16_4    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_178  1
    w_16_4    product_ub_179  1
    w_16_4    normalized_mass_16_197  1
    w_16_4    normalized_ratio_16_198  -6.6666666666666663e-01
    w_16_4    full_original_Gini_280  -6.8928571428571415e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_180  -2.4534859946816593e-02
    x_16_5    product_ub_181  -0.0406071739341023
    x_16_5    onehot_16_196  1
    x_16_5    stock_lb_220  5
    x_16_5    stock_ub_221  5
    x_16_5    parent_nonstrict_scope_222  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_180  1
    w_16_5    product_ub_181  1
    w_16_5    normalized_mass_16_197  1
    w_16_5    normalized_ratio_16_198  -8.3333333333333326e-01
    w_16_5    full_original_Gini_280  -4.3404761904761928e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_182  -2.4534859946816593e-02
    x_16_6    product_ub_183  -0.0406071739341023
    x_16_6    onehot_16_196  1
    x_16_6    stock_lb_220  6
    x_16_6    stock_ub_221  6
    x_16_6    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_182  1
    w_16_6    product_ub_183  1
    w_16_6    normalized_mass_16_197  1
    w_16_6    normalized_ratio_16_198  -1
    w_16_6    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_184  -2.4534859946816593e-02
    x_16_7    product_ub_185  -0.0406071739341023
    x_16_7    onehot_16_196  1
    x_16_7    stock_lb_220  7
    x_16_7    stock_ub_221  7
    x_16_7    parent_nonstrict_scope_222  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_184  1
    w_16_7    product_ub_185  1
    w_16_7    normalized_mass_16_197  1
    w_16_7    normalized_ratio_16_198  -1.1666666666666665e+00
    w_16_7    full_original_Gini_280  -7.0071428571428527e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_186  -2.4534859946816593e-02
    x_16_8    product_ub_187  -0.0406071739341023
    x_16_8    onehot_16_196  1
    x_16_8    stock_lb_220  8
    x_16_8    stock_ub_221  8
    x_16_8    parent_nonstrict_scope_222  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_186  1
    w_16_8    product_ub_187  1
    w_16_8    normalized_mass_16_197  1
    w_16_8    normalized_ratio_16_198  -1.3333333333333333e+00
    w_16_8    full_original_Gini_280  -1.1373809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_188  -2.4534859946816593e-02
    x_16_9    product_ub_189  -0.0406071739341023
    x_16_9    onehot_16_196  1
    x_16_9    stock_lb_220  9
    x_16_9    stock_ub_221  9
    x_16_9    parent_nonstrict_scope_222  0.027
    x_16_9    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_188  1
    w_16_9    product_ub_189  1
    w_16_9    normalized_mass_16_197  1
    w_16_9    normalized_ratio_16_198  -1.5
    w_16_9    full_original_Gini_280  -1.5873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_190  -2.4534859946816593e-02
    x_16_10   product_ub_191  -0.0406071739341023
    x_16_10   onehot_16_196  1
    x_16_10   stock_lb_220  10
    x_16_10   stock_ub_221  10
    x_16_10   parent_nonstrict_scope_222  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_190  1
    w_16_10   product_ub_191  1
    w_16_10   normalized_mass_16_197  1
    w_16_10   normalized_ratio_16_198  -1.6666666666666665e+00
    w_16_10   full_original_Gini_280  -2.0373809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_192  -2.4534859946816593e-02
    x_16_11   product_ub_193  -0.0406071739341023
    x_16_11   onehot_16_196  1
    x_16_11   stock_lb_220  11
    x_16_11   stock_ub_221  11
    x_16_11   parent_nonstrict_scope_222  0.045
    x_16_11   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_192  1
    w_16_11   product_ub_193  1
    w_16_11   normalized_mass_16_197  1
    w_16_11   normalized_ratio_16_198  -1.8333333333333333e+00
    w_16_11   full_original_Gini_280  -2.4873809523809523e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_194  -2.4534859946816593e-02
    x_16_12   product_ub_195  -0.0406071739341023
    x_16_12   onehot_16_196  1
    x_16_12   stock_lb_220  12
    x_16_12   stock_ub_221  12
    x_16_12   parent_nonstrict_scope_222  0.054
    x_16_12   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_194  1
    w_16_12   product_ub_195  1
    w_16_12   normalized_mass_16_197  1
    w_16_12   normalized_ratio_16_198  -2
    w_16_12   full_original_Gini_280  -2.9373809523809520e+01
    rho_16    normalized_ratio_16_198  1
    rho_16    block_pair_pos_223  1
    rho_16    block_pair_neg_224  -1
    rho_16    block_pair_pos_229  -1
    rho_16    block_pair_neg_230  1
    rho_16    block_pair_pos_231  1
    rho_16    block_pair_neg_232  -1
    rho_16    block_pair_pos_237  1
    rho_16    block_pair_neg_238  -1
    rho_16    block_pair_pos_251  1
    rho_16    block_pair_neg_252  -1
    rho_16    block_pair_pos_261  1
    rho_16    block_pair_neg_262  -1
    rho_16    block_pair_pos_269  1
    rho_16    block_pair_neg_270  -1
    rho_16    normalization_279  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_199  -2.4534859946816593e-02
    x_19_0    product_ub_200  -0.0406071739341023
    x_19_0    onehot_19_217  1
    x_19_0    parent_nonstrict_scope_222  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_199  1
    w_19_0    product_ub_200  1
    w_19_0    normalized_mass_19_218  1
    w_19_0    full_original_Gini_280  -2.4626190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_201  -2.4534859946816593e-02
    x_19_1    product_ub_202  -0.0406071739341023
    x_19_1    onehot_19_217  1
    x_19_1    stock_lb_220  1
    x_19_1    stock_ub_221  1
    x_19_1    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_201  1
    w_19_1    product_ub_202  1
    w_19_1    normalized_mass_19_218  1
    w_19_1    normalized_ratio_19_219  -0.25
    w_19_1    full_original_Gini_280  -1.7876190476190480e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_203  -2.4534859946816593e-02
    x_19_2    product_ub_204  -0.0406071739341023
    x_19_2    onehot_19_217  1
    x_19_2    stock_lb_220  2
    x_19_2    stock_ub_221  2
    x_19_2    parent_nonstrict_scope_222  0.012
    x_19_2    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_203  1
    w_19_2    product_ub_204  1
    w_19_2    normalized_mass_19_218  1
    w_19_2    normalized_ratio_19_219  -0.5
    w_19_2    full_original_Gini_280  -1.1126190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_205  -2.4534859946816593e-02
    x_19_3    product_ub_206  -0.0406071739341023
    x_19_3    onehot_19_217  1
    x_19_3    stock_lb_220  3
    x_19_3    stock_ub_221  3
    x_19_3    parent_nonstrict_scope_222  0.006
    x_19_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_205  1
    w_19_3    product_ub_206  1
    w_19_3    normalized_mass_19_218  1
    w_19_3    normalized_ratio_19_219  -0.75
    w_19_3    full_original_Gini_280  -5.19047619047619
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_207  -2.4534859946816593e-02
    x_19_4    product_ub_208  -0.0406071739341023
    x_19_4    onehot_19_217  1
    x_19_4    stock_lb_220  4
    x_19_4    stock_ub_221  4
    x_19_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_207  1
    w_19_4    product_ub_208  1
    w_19_4    normalized_mass_19_218  1
    w_19_4    normalized_ratio_19_219  -1
    w_19_4    full_original_Gini_280  -3.1738095238095236e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_209  -2.4534859946816593e-02
    x_19_5    product_ub_210  -0.0406071739341023
    x_19_5    onehot_19_217  1
    x_19_5    stock_lb_220  5
    x_19_5    stock_ub_221  5
    x_19_5    parent_nonstrict_scope_222  0.006
    x_19_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_209  1
    w_19_5    product_ub_210  1
    w_19_5    normalized_mass_19_218  1
    w_19_5    normalized_ratio_19_219  -1.25
    w_19_5    full_original_Gini_280  -9.1238095238095234e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_211  -2.4534859946816593e-02
    x_19_6    product_ub_212  -0.0406071739341023
    x_19_6    onehot_19_217  1
    x_19_6    stock_lb_220  6
    x_19_6    stock_ub_221  6
    x_19_6    parent_nonstrict_scope_222  0.012
    x_19_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_211  1
    w_19_6    product_ub_212  1
    w_19_6    normalized_mass_19_218  1
    w_19_6    normalized_ratio_19_219  -1.5
    w_19_6    full_original_Gini_280  -1.5873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_213  -2.4534859946816593e-02
    x_19_7    product_ub_214  -0.0406071739341023
    x_19_7    onehot_19_217  1
    x_19_7    stock_lb_220  7
    x_19_7    stock_ub_221  7
    x_19_7    parent_nonstrict_scope_222  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_213  1
    w_19_7    product_ub_214  1
    w_19_7    normalized_mass_19_218  1
    w_19_7    normalized_ratio_19_219  -1.75
    w_19_7    full_original_Gini_280  -2.2623809523809520e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_215  -2.4534859946816593e-02
    x_19_8    product_ub_216  -0.0406071739341023
    x_19_8    onehot_19_217  1
    x_19_8    stock_lb_220  8
    x_19_8    stock_ub_221  8
    x_19_8    parent_nonstrict_scope_222  0.024
    x_19_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_215  1
    w_19_8    product_ub_216  1
    w_19_8    normalized_mass_19_218  1
    w_19_8    normalized_ratio_19_219  -2
    w_19_8    full_original_Gini_280  -2.9373809523809520e+01
    rho_19    normalized_ratio_19_219  1
    rho_19    block_pair_pos_225  1
    rho_19    block_pair_neg_226  -1
    rho_19    block_pair_pos_229  1
    rho_19    block_pair_neg_230  -1
    rho_19    block_pair_pos_233  1
    rho_19    block_pair_neg_234  -1
    rho_19    block_pair_pos_239  1
    rho_19    block_pair_neg_240  -1
    rho_19    block_pair_pos_253  1
    rho_19    block_pair_neg_254  -1
    rho_19    block_pair_pos_263  1
    rho_19    block_pair_neg_264  -1
    rho_19    block_pair_pos_271  1
    rho_19    block_pair_neg_272  -1
    rho_19    normalization_279  1
    a_30_35   block_pair_pos_247  1
    a_30_35   block_pair_neg_248  1
    a_30_35   full_original_Gini_280  -1
    a_30_31   block_pair_pos_243  1
    a_30_31   block_pair_neg_244  1
    a_30_31   full_original_Gini_280  -1
    a_30_32   block_pair_pos_245  1
    a_30_32   block_pair_neg_246  1
    a_30_32   full_original_Gini_280  -1
    a_30_2    block_pair_pos_235  1
    a_30_2    block_pair_neg_236  1
    a_30_2    full_original_Gini_280  -1
    a_30_26   block_pair_pos_241  1
    a_30_26   block_pair_neg_242  1
    a_30_26   full_original_Gini_280  -1
    a_30_16   block_pair_pos_237  1
    a_30_16   block_pair_neg_238  1
    a_30_16   full_original_Gini_280  -1
    a_30_19   block_pair_pos_239  1
    a_30_19   block_pair_neg_240  1
    a_30_19   full_original_Gini_280  -1
    a_35_31   block_pair_pos_275  1
    a_35_31   block_pair_neg_276  1
    a_35_31   full_original_Gini_280  -1
    a_35_32   block_pair_pos_277  1
    a_35_32   block_pair_neg_278  1
    a_35_32   full_original_Gini_280  -1
    a_35_2    block_pair_pos_267  1
    a_35_2    block_pair_neg_268  1
    a_35_2    full_original_Gini_280  -1
    a_35_26   block_pair_pos_273  1
    a_35_26   block_pair_neg_274  1
    a_35_26   full_original_Gini_280  -1
    a_35_16   block_pair_pos_269  1
    a_35_16   block_pair_neg_270  1
    a_35_16   full_original_Gini_280  -1
    a_35_19   block_pair_pos_271  1
    a_35_19   block_pair_neg_272  1
    a_35_19   full_original_Gini_280  -1
    a_31_32   block_pair_pos_257  1
    a_31_32   block_pair_neg_258  1
    a_31_32   full_original_Gini_280  -1
    a_31_2    block_pair_pos_249  1
    a_31_2    block_pair_neg_250  1
    a_31_2    full_original_Gini_280  -1
    a_31_26   block_pair_pos_255  1
    a_31_26   block_pair_neg_256  1
    a_31_26   full_original_Gini_280  -1
    a_31_16   block_pair_pos_251  1
    a_31_16   block_pair_neg_252  1
    a_31_16   full_original_Gini_280  -1
    a_31_19   block_pair_pos_253  1
    a_31_19   block_pair_neg_254  1
    a_31_19   full_original_Gini_280  -1
    a_32_2    block_pair_pos_259  1
    a_32_2    block_pair_neg_260  1
    a_32_2    full_original_Gini_280  -1
    a_32_26   block_pair_pos_265  1
    a_32_26   block_pair_neg_266  1
    a_32_26   full_original_Gini_280  -1
    a_32_16   block_pair_pos_261  1
    a_32_16   block_pair_neg_262  1
    a_32_16   full_original_Gini_280  -1
    a_32_19   block_pair_pos_263  1
    a_32_19   block_pair_neg_264  1
    a_32_19   full_original_Gini_280  -1
    a_2_26    block_pair_pos_227  1
    a_2_26    block_pair_neg_228  1
    a_2_26    full_original_Gini_280  -1
    a_2_16    block_pair_pos_223  1
    a_2_16    block_pair_neg_224  1
    a_2_16    full_original_Gini_280  -1
    a_2_19    block_pair_pos_225  1
    a_2_19    block_pair_neg_226  1
    a_2_19    full_original_Gini_280  -1
    a_26_16   block_pair_pos_231  1
    a_26_16   block_pair_neg_232  1
    a_26_16   full_original_Gini_280  -1
    a_26_19   block_pair_pos_233  1
    a_26_19   block_pair_neg_234  1
    a_26_19   full_original_Gini_280  -1
    a_16_19   block_pair_pos_229  1
    a_16_19   block_pair_neg_230  1
    a_16_19   full_original_Gini_280  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_30_0  unique_nonzero_owner_281  1
    service_0_30_0  service_visit_def_751  1
    service_0_30_0  free_load_conservation_752  -5
    service_0_30_0  original_T_including_depot_unload_799  600
    service_0_30_1  unique_nonzero_owner_282  1
    service_0_30_1  service_visit_def_751  1
    service_0_30_1  free_load_conservation_752  -4
    service_0_30_1  original_T_including_depot_unload_799  480
    service_0_30_2  unique_nonzero_owner_283  1
    service_0_30_2  service_visit_def_751  1
    service_0_30_2  free_load_conservation_752  -3
    service_0_30_2  original_T_including_depot_unload_799  360
    service_0_30_3  unique_nonzero_owner_284  1
    service_0_30_3  service_visit_def_751  1
    service_0_30_3  free_load_conservation_752  -2
    service_0_30_3  original_T_including_depot_unload_799  240
    service_0_30_4  unique_nonzero_owner_285  1
    service_0_30_4  service_visit_def_751  1
    service_0_30_4  free_load_conservation_752  -1
    service_0_30_4  original_T_including_depot_unload_799  120
    service_0_30_6  unique_nonzero_owner_286  1
    service_0_30_6  service_visit_def_751  1
    service_0_30_6  free_load_conservation_752  1
    service_0_30_7  unique_nonzero_owner_287  1
    service_0_30_7  service_visit_def_751  1
    service_0_30_7  free_load_conservation_752  2
    service_0_30_8  unique_nonzero_owner_288  1
    service_0_30_8  service_visit_def_751  1
    service_0_30_8  free_load_conservation_752  3
    service_1_30_0  unique_nonzero_owner_281  1
    service_1_30_0  service_visit_def_1180  1
    service_1_30_0  free_load_conservation_1181  -5
    service_1_30_0  original_T_including_depot_unload_1228  600
    service_1_30_1  unique_nonzero_owner_282  1
    service_1_30_1  service_visit_def_1180  1
    service_1_30_1  free_load_conservation_1181  -4
    service_1_30_1  original_T_including_depot_unload_1228  480
    service_1_30_2  unique_nonzero_owner_283  1
    service_1_30_2  service_visit_def_1180  1
    service_1_30_2  free_load_conservation_1181  -3
    service_1_30_2  original_T_including_depot_unload_1228  360
    service_1_30_3  unique_nonzero_owner_284  1
    service_1_30_3  service_visit_def_1180  1
    service_1_30_3  free_load_conservation_1181  -2
    service_1_30_3  original_T_including_depot_unload_1228  240
    service_1_30_4  unique_nonzero_owner_285  1
    service_1_30_4  service_visit_def_1180  1
    service_1_30_4  free_load_conservation_1181  -1
    service_1_30_4  original_T_including_depot_unload_1228  120
    service_1_30_6  unique_nonzero_owner_286  1
    service_1_30_6  service_visit_def_1180  1
    service_1_30_6  free_load_conservation_1181  1
    service_1_30_7  unique_nonzero_owner_287  1
    service_1_30_7  service_visit_def_1180  1
    service_1_30_7  free_load_conservation_1181  2
    service_1_30_8  unique_nonzero_owner_288  1
    service_1_30_8  service_visit_def_1180  1
    service_1_30_8  free_load_conservation_1181  3
    service_2_30_0  unique_nonzero_owner_281  1
    service_2_30_0  service_visit_def_1552  1
    service_2_30_0  free_load_conservation_1553  -5
    service_2_30_0  original_T_including_depot_unload_1599  600
    service_2_30_1  unique_nonzero_owner_282  1
    service_2_30_1  service_visit_def_1552  1
    service_2_30_1  free_load_conservation_1553  -4
    service_2_30_1  original_T_including_depot_unload_1599  480
    service_2_30_2  unique_nonzero_owner_283  1
    service_2_30_2  service_visit_def_1552  1
    service_2_30_2  free_load_conservation_1553  -3
    service_2_30_2  original_T_including_depot_unload_1599  360
    service_2_30_3  unique_nonzero_owner_284  1
    service_2_30_3  service_visit_def_1552  1
    service_2_30_3  free_load_conservation_1553  -2
    service_2_30_3  original_T_including_depot_unload_1599  240
    service_2_30_4  unique_nonzero_owner_285  1
    service_2_30_4  service_visit_def_1552  1
    service_2_30_4  free_load_conservation_1553  -1
    service_2_30_4  original_T_including_depot_unload_1599  120
    service_2_30_6  unique_nonzero_owner_286  1
    service_2_30_6  service_visit_def_1552  1
    service_2_30_6  free_load_conservation_1553  1
    service_2_30_7  unique_nonzero_owner_287  1
    service_2_30_7  service_visit_def_1552  1
    service_2_30_7  free_load_conservation_1553  2
    service_2_30_8  unique_nonzero_owner_288  1
    service_2_30_8  service_visit_def_1552  1
    service_2_30_8  free_load_conservation_1553  3
    service_0_35_0  unique_nonzero_owner_289  1
    service_0_35_0  service_visit_def_757  1
    service_0_35_0  free_load_conservation_758  -11
    service_0_35_0  original_T_including_depot_unload_799  1320
    service_0_35_1  unique_nonzero_owner_290  1
    service_0_35_1  service_visit_def_757  1
    service_0_35_1  free_load_conservation_758  -10
    service_0_35_1  original_T_including_depot_unload_799  1200
    service_0_35_2  unique_nonzero_owner_291  1
    service_0_35_2  service_visit_def_757  1
    service_0_35_2  free_load_conservation_758  -9
    service_0_35_2  original_T_including_depot_unload_799  1080
    service_0_35_3  unique_nonzero_owner_292  1
    service_0_35_3  service_visit_def_757  1
    service_0_35_3  free_load_conservation_758  -8
    service_0_35_3  original_T_including_depot_unload_799  960
    service_0_35_4  unique_nonzero_owner_293  1
    service_0_35_4  service_visit_def_757  1
    service_0_35_4  free_load_conservation_758  -7
    service_0_35_4  original_T_including_depot_unload_799  840
    service_0_35_5  unique_nonzero_owner_294  1
    service_0_35_5  service_visit_def_757  1
    service_0_35_5  free_load_conservation_758  -6
    service_0_35_5  original_T_including_depot_unload_799  720
    service_0_35_6  unique_nonzero_owner_295  1
    service_0_35_6  service_visit_def_757  1
    service_0_35_6  free_load_conservation_758  -5
    service_0_35_6  original_T_including_depot_unload_799  600
    service_0_35_7  unique_nonzero_owner_296  1
    service_0_35_7  service_visit_def_757  1
    service_0_35_7  free_load_conservation_758  -4
    service_0_35_7  original_T_including_depot_unload_799  480
    service_0_35_8  unique_nonzero_owner_297  1
    service_0_35_8  service_visit_def_757  1
    service_0_35_8  free_load_conservation_758  -3
    service_0_35_8  original_T_including_depot_unload_799  360
    service_0_35_9  unique_nonzero_owner_298  1
    service_0_35_9  service_visit_def_757  1
    service_0_35_9  free_load_conservation_758  -2
    service_0_35_9  original_T_including_depot_unload_799  240
    service_0_35_10  unique_nonzero_owner_299  1
    service_0_35_10  service_visit_def_757  1
    service_0_35_10  free_load_conservation_758  -1
    service_0_35_10  original_T_including_depot_unload_799  120
    service_0_35_12  unique_nonzero_owner_300  1
    service_0_35_12  service_visit_def_757  1
    service_0_35_12  free_load_conservation_758  1
    service_0_35_13  unique_nonzero_owner_301  1
    service_0_35_13  service_visit_def_757  1
    service_0_35_13  free_load_conservation_758  2
    service_0_35_14  unique_nonzero_owner_302  1
    service_0_35_14  service_visit_def_757  1
    service_0_35_14  free_load_conservation_758  3
    service_0_35_15  unique_nonzero_owner_303  1
    service_0_35_15  service_visit_def_757  1
    service_0_35_15  free_load_conservation_758  4
    service_1_35_0  unique_nonzero_owner_289  1
    service_1_35_0  service_visit_def_1186  1
    service_1_35_0  free_load_conservation_1187  -11
    service_1_35_0  original_T_including_depot_unload_1228  1320
    service_1_35_1  unique_nonzero_owner_290  1
    service_1_35_1  service_visit_def_1186  1
    service_1_35_1  free_load_conservation_1187  -10
    service_1_35_1  original_T_including_depot_unload_1228  1200
    service_1_35_2  unique_nonzero_owner_291  1
    service_1_35_2  service_visit_def_1186  1
    service_1_35_2  free_load_conservation_1187  -9
    service_1_35_2  original_T_including_depot_unload_1228  1080
    service_1_35_3  unique_nonzero_owner_292  1
    service_1_35_3  service_visit_def_1186  1
    service_1_35_3  free_load_conservation_1187  -8
    service_1_35_3  original_T_including_depot_unload_1228  960
    service_1_35_4  unique_nonzero_owner_293  1
    service_1_35_4  service_visit_def_1186  1
    service_1_35_4  free_load_conservation_1187  -7
    service_1_35_4  original_T_including_depot_unload_1228  840
    service_1_35_5  unique_nonzero_owner_294  1
    service_1_35_5  service_visit_def_1186  1
    service_1_35_5  free_load_conservation_1187  -6
    service_1_35_5  original_T_including_depot_unload_1228  720
    service_1_35_6  unique_nonzero_owner_295  1
    service_1_35_6  service_visit_def_1186  1
    service_1_35_6  free_load_conservation_1187  -5
    service_1_35_6  original_T_including_depot_unload_1228  600
    service_1_35_7  unique_nonzero_owner_296  1
    service_1_35_7  service_visit_def_1186  1
    service_1_35_7  free_load_conservation_1187  -4
    service_1_35_7  original_T_including_depot_unload_1228  480
    service_1_35_8  unique_nonzero_owner_297  1
    service_1_35_8  service_visit_def_1186  1
    service_1_35_8  free_load_conservation_1187  -3
    service_1_35_8  original_T_including_depot_unload_1228  360
    service_1_35_9  unique_nonzero_owner_298  1
    service_1_35_9  service_visit_def_1186  1
    service_1_35_9  free_load_conservation_1187  -2
    service_1_35_9  original_T_including_depot_unload_1228  240
    service_1_35_10  unique_nonzero_owner_299  1
    service_1_35_10  service_visit_def_1186  1
    service_1_35_10  free_load_conservation_1187  -1
    service_1_35_10  original_T_including_depot_unload_1228  120
    service_1_35_12  unique_nonzero_owner_300  1
    service_1_35_12  service_visit_def_1186  1
    service_1_35_12  free_load_conservation_1187  1
    service_1_35_13  unique_nonzero_owner_301  1
    service_1_35_13  service_visit_def_1186  1
    service_1_35_13  free_load_conservation_1187  2
    service_1_35_14  unique_nonzero_owner_302  1
    service_1_35_14  service_visit_def_1186  1
    service_1_35_14  free_load_conservation_1187  3
    service_1_35_15  unique_nonzero_owner_303  1
    service_1_35_15  service_visit_def_1186  1
    service_1_35_15  free_load_conservation_1187  4
    service_2_35_0  unique_nonzero_owner_289  1
    service_2_35_0  service_visit_def_1558  1
    service_2_35_0  free_load_conservation_1559  -11
    service_2_35_0  original_T_including_depot_unload_1599  1320
    service_2_35_1  unique_nonzero_owner_290  1
    service_2_35_1  service_visit_def_1558  1
    service_2_35_1  free_load_conservation_1559  -10
    service_2_35_1  original_T_including_depot_unload_1599  1200
    service_2_35_2  unique_nonzero_owner_291  1
    service_2_35_2  service_visit_def_1558  1
    service_2_35_2  free_load_conservation_1559  -9
    service_2_35_2  original_T_including_depot_unload_1599  1080
    service_2_35_3  unique_nonzero_owner_292  1
    service_2_35_3  service_visit_def_1558  1
    service_2_35_3  free_load_conservation_1559  -8
    service_2_35_3  original_T_including_depot_unload_1599  960
    service_2_35_4  unique_nonzero_owner_293  1
    service_2_35_4  service_visit_def_1558  1
    service_2_35_4  free_load_conservation_1559  -7
    service_2_35_4  original_T_including_depot_unload_1599  840
    service_2_35_5  unique_nonzero_owner_294  1
    service_2_35_5  service_visit_def_1558  1
    service_2_35_5  free_load_conservation_1559  -6
    service_2_35_5  original_T_including_depot_unload_1599  720
    service_2_35_6  unique_nonzero_owner_295  1
    service_2_35_6  service_visit_def_1558  1
    service_2_35_6  free_load_conservation_1559  -5
    service_2_35_6  original_T_including_depot_unload_1599  600
    service_2_35_7  unique_nonzero_owner_296  1
    service_2_35_7  service_visit_def_1558  1
    service_2_35_7  free_load_conservation_1559  -4
    service_2_35_7  original_T_including_depot_unload_1599  480
    service_2_35_8  unique_nonzero_owner_297  1
    service_2_35_8  service_visit_def_1558  1
    service_2_35_8  free_load_conservation_1559  -3
    service_2_35_8  original_T_including_depot_unload_1599  360
    service_2_35_9  unique_nonzero_owner_298  1
    service_2_35_9  service_visit_def_1558  1
    service_2_35_9  free_load_conservation_1559  -2
    service_2_35_9  original_T_including_depot_unload_1599  240
    service_2_35_10  unique_nonzero_owner_299  1
    service_2_35_10  service_visit_def_1558  1
    service_2_35_10  free_load_conservation_1559  -1
    service_2_35_10  original_T_including_depot_unload_1599  120
    service_2_35_12  unique_nonzero_owner_300  1
    service_2_35_12  service_visit_def_1558  1
    service_2_35_12  free_load_conservation_1559  1
    service_2_35_13  unique_nonzero_owner_301  1
    service_2_35_13  service_visit_def_1558  1
    service_2_35_13  free_load_conservation_1559  2
    service_2_35_14  unique_nonzero_owner_302  1
    service_2_35_14  service_visit_def_1558  1
    service_2_35_14  free_load_conservation_1559  3
    service_2_35_15  unique_nonzero_owner_303  1
    service_2_35_15  service_visit_def_1558  1
    service_2_35_15  free_load_conservation_1559  4
    service_0_31_0  unique_nonzero_owner_304  1
    service_0_31_0  service_visit_def_763  1
    service_0_31_0  free_load_conservation_764  -2
    service_0_31_0  original_T_including_depot_unload_799  240
    service_0_31_1  unique_nonzero_owner_305  1
    service_0_31_1  service_visit_def_763  1
    service_0_31_1  free_load_conservation_764  -1
    service_0_31_1  original_T_including_depot_unload_799  120
    service_0_31_3  unique_nonzero_owner_306  1
    service_0_31_3  service_visit_def_763  1
    service_0_31_3  free_load_conservation_764  1
    service_0_31_4  unique_nonzero_owner_307  1
    service_0_31_4  service_visit_def_763  1
    service_0_31_4  free_load_conservation_764  2
    service_0_31_5  unique_nonzero_owner_308  1
    service_0_31_5  service_visit_def_763  1
    service_0_31_5  free_load_conservation_764  3
    service_0_31_6  unique_nonzero_owner_309  1
    service_0_31_6  service_visit_def_763  1
    service_0_31_6  free_load_conservation_764  4
    service_0_31_7  unique_nonzero_owner_310  1
    service_0_31_7  service_visit_def_763  1
    service_0_31_7  free_load_conservation_764  5
    service_0_31_8  unique_nonzero_owner_311  1
    service_0_31_8  service_visit_def_763  1
    service_0_31_8  free_load_conservation_764  6
    service_0_31_9  unique_nonzero_owner_312  1
    service_0_31_9  service_visit_def_763  1
    service_0_31_9  free_load_conservation_764  7
    service_0_31_10  unique_nonzero_owner_313  1
    service_0_31_10  service_visit_def_763  1
    service_0_31_10  free_load_conservation_764  8
    service_0_31_11  unique_nonzero_owner_314  1
    service_0_31_11  service_visit_def_763  1
    service_0_31_11  free_load_conservation_764  9
    service_0_31_12  unique_nonzero_owner_315  1
    service_0_31_12  service_visit_def_763  1
    service_0_31_12  free_load_conservation_764  10
    service_1_31_0  unique_nonzero_owner_304  1
    service_1_31_0  service_visit_def_1192  1
    service_1_31_0  free_load_conservation_1193  -2
    service_1_31_0  original_T_including_depot_unload_1228  240
    service_1_31_1  unique_nonzero_owner_305  1
    service_1_31_1  service_visit_def_1192  1
    service_1_31_1  free_load_conservation_1193  -1
    service_1_31_1  original_T_including_depot_unload_1228  120
    service_1_31_3  unique_nonzero_owner_306  1
    service_1_31_3  service_visit_def_1192  1
    service_1_31_3  free_load_conservation_1193  1
    service_1_31_4  unique_nonzero_owner_307  1
    service_1_31_4  service_visit_def_1192  1
    service_1_31_4  free_load_conservation_1193  2
    service_1_31_5  unique_nonzero_owner_308  1
    service_1_31_5  service_visit_def_1192  1
    service_1_31_5  free_load_conservation_1193  3
    service_1_31_6  unique_nonzero_owner_309  1
    service_1_31_6  service_visit_def_1192  1
    service_1_31_6  free_load_conservation_1193  4
    service_1_31_7  unique_nonzero_owner_310  1
    service_1_31_7  service_visit_def_1192  1
    service_1_31_7  free_load_conservation_1193  5
    service_1_31_8  unique_nonzero_owner_311  1
    service_1_31_8  service_visit_def_1192  1
    service_1_31_8  free_load_conservation_1193  6
    service_1_31_9  unique_nonzero_owner_312  1
    service_1_31_9  service_visit_def_1192  1
    service_1_31_9  free_load_conservation_1193  7
    service_1_31_10  unique_nonzero_owner_313  1
    service_1_31_10  service_visit_def_1192  1
    service_1_31_10  free_load_conservation_1193  8
    service_1_31_11  unique_nonzero_owner_314  1
    service_1_31_11  service_visit_def_1192  1
    service_1_31_11  free_load_conservation_1193  9
    service_1_31_12  unique_nonzero_owner_315  1
    service_1_31_12  service_visit_def_1192  1
    service_1_31_12  free_load_conservation_1193  10
    service_2_31_0  unique_nonzero_owner_304  1
    service_2_31_0  service_visit_def_1564  1
    service_2_31_0  free_load_conservation_1565  -2
    service_2_31_0  original_T_including_depot_unload_1599  240
    service_2_31_1  unique_nonzero_owner_305  1
    service_2_31_1  service_visit_def_1564  1
    service_2_31_1  free_load_conservation_1565  -1
    service_2_31_1  original_T_including_depot_unload_1599  120
    service_2_31_3  unique_nonzero_owner_306  1
    service_2_31_3  service_visit_def_1564  1
    service_2_31_3  free_load_conservation_1565  1
    service_2_31_4  unique_nonzero_owner_307  1
    service_2_31_4  service_visit_def_1564  1
    service_2_31_4  free_load_conservation_1565  2
    service_2_31_5  unique_nonzero_owner_308  1
    service_2_31_5  service_visit_def_1564  1
    service_2_31_5  free_load_conservation_1565  3
    service_2_31_6  unique_nonzero_owner_309  1
    service_2_31_6  service_visit_def_1564  1
    service_2_31_6  free_load_conservation_1565  4
    service_2_31_7  unique_nonzero_owner_310  1
    service_2_31_7  service_visit_def_1564  1
    service_2_31_7  free_load_conservation_1565  5
    service_2_31_8  unique_nonzero_owner_311  1
    service_2_31_8  service_visit_def_1564  1
    service_2_31_8  free_load_conservation_1565  6
    service_2_31_9  unique_nonzero_owner_312  1
    service_2_31_9  service_visit_def_1564  1
    service_2_31_9  free_load_conservation_1565  7
    service_2_31_10  unique_nonzero_owner_313  1
    service_2_31_10  service_visit_def_1564  1
    service_2_31_10  free_load_conservation_1565  8
    service_2_31_11  unique_nonzero_owner_314  1
    service_2_31_11  service_visit_def_1564  1
    service_2_31_11  free_load_conservation_1565  9
    service_2_31_12  unique_nonzero_owner_315  1
    service_2_31_12  service_visit_def_1564  1
    service_2_31_12  free_load_conservation_1565  10
    service_0_32_1  unique_nonzero_owner_316  1
    service_0_32_1  service_visit_def_769  1
    service_0_32_1  free_load_conservation_770  1
    service_0_32_2  unique_nonzero_owner_317  1
    service_0_32_2  service_visit_def_769  1
    service_0_32_2  free_load_conservation_770  2
    service_0_32_3  unique_nonzero_owner_318  1
    service_0_32_3  service_visit_def_769  1
    service_0_32_3  free_load_conservation_770  3
    service_0_32_4  unique_nonzero_owner_319  1
    service_0_32_4  service_visit_def_769  1
    service_0_32_4  free_load_conservation_770  4
    service_0_32_5  unique_nonzero_owner_320  1
    service_0_32_5  service_visit_def_769  1
    service_0_32_5  free_load_conservation_770  5
    service_0_32_6  unique_nonzero_owner_321  1
    service_0_32_6  service_visit_def_769  1
    service_0_32_6  free_load_conservation_770  6
    service_0_32_7  unique_nonzero_owner_322  1
    service_0_32_7  service_visit_def_769  1
    service_0_32_7  free_load_conservation_770  7
    service_0_32_8  unique_nonzero_owner_323  1
    service_0_32_8  service_visit_def_769  1
    service_0_32_8  free_load_conservation_770  8
    service_0_32_9  unique_nonzero_owner_324  1
    service_0_32_9  service_visit_def_769  1
    service_0_32_9  free_load_conservation_770  9
    service_0_32_10  unique_nonzero_owner_325  1
    service_0_32_10  service_visit_def_769  1
    service_0_32_10  free_load_conservation_770  10
    service_0_32_11  unique_nonzero_owner_326  1
    service_0_32_11  service_visit_def_769  1
    service_0_32_11  free_load_conservation_770  11
    service_0_32_12  unique_nonzero_owner_327  1
    service_0_32_12  service_visit_def_769  1
    service_0_32_12  free_load_conservation_770  12
    service_1_32_1  unique_nonzero_owner_316  1
    service_1_32_1  service_visit_def_1198  1
    service_1_32_1  free_load_conservation_1199  1
    service_1_32_2  unique_nonzero_owner_317  1
    service_1_32_2  service_visit_def_1198  1
    service_1_32_2  free_load_conservation_1199  2
    service_1_32_3  unique_nonzero_owner_318  1
    service_1_32_3  service_visit_def_1198  1
    service_1_32_3  free_load_conservation_1199  3
    service_1_32_4  unique_nonzero_owner_319  1
    service_1_32_4  service_visit_def_1198  1
    service_1_32_4  free_load_conservation_1199  4
    service_1_32_5  unique_nonzero_owner_320  1
    service_1_32_5  service_visit_def_1198  1
    service_1_32_5  free_load_conservation_1199  5
    service_1_32_6  unique_nonzero_owner_321  1
    service_1_32_6  service_visit_def_1198  1
    service_1_32_6  free_load_conservation_1199  6
    service_1_32_7  unique_nonzero_owner_322  1
    service_1_32_7  service_visit_def_1198  1
    service_1_32_7  free_load_conservation_1199  7
    service_1_32_8  unique_nonzero_owner_323  1
    service_1_32_8  service_visit_def_1198  1
    service_1_32_8  free_load_conservation_1199  8
    service_1_32_9  unique_nonzero_owner_324  1
    service_1_32_9  service_visit_def_1198  1
    service_1_32_9  free_load_conservation_1199  9
    service_1_32_10  unique_nonzero_owner_325  1
    service_1_32_10  service_visit_def_1198  1
    service_1_32_10  free_load_conservation_1199  10
    service_1_32_11  unique_nonzero_owner_326  1
    service_1_32_11  service_visit_def_1198  1
    service_1_32_11  free_load_conservation_1199  11
    service_1_32_12  unique_nonzero_owner_327  1
    service_1_32_12  service_visit_def_1198  1
    service_1_32_12  free_load_conservation_1199  12
    service_2_32_1  unique_nonzero_owner_316  1
    service_2_32_1  service_visit_def_1570  1
    service_2_32_1  free_load_conservation_1571  1
    service_2_32_2  unique_nonzero_owner_317  1
    service_2_32_2  service_visit_def_1570  1
    service_2_32_2  free_load_conservation_1571  2
    service_2_32_3  unique_nonzero_owner_318  1
    service_2_32_3  service_visit_def_1570  1
    service_2_32_3  free_load_conservation_1571  3
    service_2_32_4  unique_nonzero_owner_319  1
    service_2_32_4  service_visit_def_1570  1
    service_2_32_4  free_load_conservation_1571  4
    service_2_32_5  unique_nonzero_owner_320  1
    service_2_32_5  service_visit_def_1570  1
    service_2_32_5  free_load_conservation_1571  5
    service_2_32_6  unique_nonzero_owner_321  1
    service_2_32_6  service_visit_def_1570  1
    service_2_32_6  free_load_conservation_1571  6
    service_2_32_7  unique_nonzero_owner_322  1
    service_2_32_7  service_visit_def_1570  1
    service_2_32_7  free_load_conservation_1571  7
    service_2_32_8  unique_nonzero_owner_323  1
    service_2_32_8  service_visit_def_1570  1
    service_2_32_8  free_load_conservation_1571  8
    service_2_32_9  unique_nonzero_owner_324  1
    service_2_32_9  service_visit_def_1570  1
    service_2_32_9  free_load_conservation_1571  9
    service_2_32_10  unique_nonzero_owner_325  1
    service_2_32_10  service_visit_def_1570  1
    service_2_32_10  free_load_conservation_1571  10
    service_2_32_11  unique_nonzero_owner_326  1
    service_2_32_11  service_visit_def_1570  1
    service_2_32_11  free_load_conservation_1571  11
    service_2_32_12  unique_nonzero_owner_327  1
    service_2_32_12  service_visit_def_1570  1
    service_2_32_12  free_load_conservation_1571  12
    service_0_2_1  unique_nonzero_owner_328  1
    service_0_2_1  service_visit_def_775  1
    service_0_2_1  free_load_conservation_776  1
    service_0_2_2  unique_nonzero_owner_329  1
    service_0_2_2  service_visit_def_775  1
    service_0_2_2  free_load_conservation_776  2
    service_0_2_3  unique_nonzero_owner_330  1
    service_0_2_3  service_visit_def_775  1
    service_0_2_3  free_load_conservation_776  3
    service_0_2_4  unique_nonzero_owner_331  1
    service_0_2_4  service_visit_def_775  1
    service_0_2_4  free_load_conservation_776  4
    service_0_2_5  unique_nonzero_owner_332  1
    service_0_2_5  service_visit_def_775  1
    service_0_2_5  free_load_conservation_776  5
    service_0_2_6  unique_nonzero_owner_333  1
    service_0_2_6  service_visit_def_775  1
    service_0_2_6  free_load_conservation_776  6
    service_0_2_7  unique_nonzero_owner_334  1
    service_0_2_7  service_visit_def_775  1
    service_0_2_7  free_load_conservation_776  7
    service_0_2_8  unique_nonzero_owner_335  1
    service_0_2_8  service_visit_def_775  1
    service_0_2_8  free_load_conservation_776  8
    service_0_2_9  unique_nonzero_owner_336  1
    service_0_2_9  service_visit_def_775  1
    service_0_2_9  free_load_conservation_776  9
    service_0_2_10  unique_nonzero_owner_337  1
    service_0_2_10  service_visit_def_775  1
    service_0_2_10  free_load_conservation_776  10
    service_0_2_11  unique_nonzero_owner_338  1
    service_0_2_11  service_visit_def_775  1
    service_0_2_11  free_load_conservation_776  11
    service_0_2_12  unique_nonzero_owner_339  1
    service_0_2_12  service_visit_def_775  1
    service_0_2_12  free_load_conservation_776  12
    service_0_2_13  unique_nonzero_owner_340  1
    service_0_2_13  service_visit_def_775  1
    service_0_2_13  free_load_conservation_776  13
    service_0_2_14  unique_nonzero_owner_341  1
    service_0_2_14  service_visit_def_775  1
    service_0_2_14  free_load_conservation_776  14
    service_0_2_15  unique_nonzero_owner_342  1
    service_0_2_15  service_visit_def_775  1
    service_0_2_15  free_load_conservation_776  15
    service_1_2_1  unique_nonzero_owner_328  1
    service_1_2_1  service_visit_def_1204  1
    service_1_2_1  free_load_conservation_1205  1
    service_1_2_2  unique_nonzero_owner_329  1
    service_1_2_2  service_visit_def_1204  1
    service_1_2_2  free_load_conservation_1205  2
    service_1_2_3  unique_nonzero_owner_330  1
    service_1_2_3  service_visit_def_1204  1
    service_1_2_3  free_load_conservation_1205  3
    service_1_2_4  unique_nonzero_owner_331  1
    service_1_2_4  service_visit_def_1204  1
    service_1_2_4  free_load_conservation_1205  4
    service_1_2_5  unique_nonzero_owner_332  1
    service_1_2_5  service_visit_def_1204  1
    service_1_2_5  free_load_conservation_1205  5
    service_1_2_6  unique_nonzero_owner_333  1
    service_1_2_6  service_visit_def_1204  1
    service_1_2_6  free_load_conservation_1205  6
    service_1_2_7  unique_nonzero_owner_334  1
    service_1_2_7  service_visit_def_1204  1
    service_1_2_7  free_load_conservation_1205  7
    service_1_2_8  unique_nonzero_owner_335  1
    service_1_2_8  service_visit_def_1204  1
    service_1_2_8  free_load_conservation_1205  8
    service_1_2_9  unique_nonzero_owner_336  1
    service_1_2_9  service_visit_def_1204  1
    service_1_2_9  free_load_conservation_1205  9
    service_1_2_10  unique_nonzero_owner_337  1
    service_1_2_10  service_visit_def_1204  1
    service_1_2_10  free_load_conservation_1205  10
    service_1_2_11  unique_nonzero_owner_338  1
    service_1_2_11  service_visit_def_1204  1
    service_1_2_11  free_load_conservation_1205  11
    service_1_2_12  unique_nonzero_owner_339  1
    service_1_2_12  service_visit_def_1204  1
    service_1_2_12  free_load_conservation_1205  12
    service_1_2_13  unique_nonzero_owner_340  1
    service_1_2_13  service_visit_def_1204  1
    service_1_2_13  free_load_conservation_1205  13
    service_1_2_14  unique_nonzero_owner_341  1
    service_1_2_14  service_visit_def_1204  1
    service_1_2_14  free_load_conservation_1205  14
    service_1_2_15  unique_nonzero_owner_342  1
    service_1_2_15  service_visit_def_1204  1
    service_1_2_15  free_load_conservation_1205  15
    service_2_2_1  unique_nonzero_owner_328  1
    service_2_2_1  service_visit_def_1576  1
    service_2_2_1  free_load_conservation_1577  1
    service_2_2_2  unique_nonzero_owner_329  1
    service_2_2_2  service_visit_def_1576  1
    service_2_2_2  free_load_conservation_1577  2
    service_2_2_3  unique_nonzero_owner_330  1
    service_2_2_3  service_visit_def_1576  1
    service_2_2_3  free_load_conservation_1577  3
    service_2_2_4  unique_nonzero_owner_331  1
    service_2_2_4  service_visit_def_1576  1
    service_2_2_4  free_load_conservation_1577  4
    service_2_2_5  unique_nonzero_owner_332  1
    service_2_2_5  service_visit_def_1576  1
    service_2_2_5  free_load_conservation_1577  5
    service_2_2_6  unique_nonzero_owner_333  1
    service_2_2_6  service_visit_def_1576  1
    service_2_2_6  free_load_conservation_1577  6
    service_2_2_7  unique_nonzero_owner_334  1
    service_2_2_7  service_visit_def_1576  1
    service_2_2_7  free_load_conservation_1577  7
    service_2_2_8  unique_nonzero_owner_335  1
    service_2_2_8  service_visit_def_1576  1
    service_2_2_8  free_load_conservation_1577  8
    service_2_2_9  unique_nonzero_owner_336  1
    service_2_2_9  service_visit_def_1576  1
    service_2_2_9  free_load_conservation_1577  9
    service_2_2_10  unique_nonzero_owner_337  1
    service_2_2_10  service_visit_def_1576  1
    service_2_2_10  free_load_conservation_1577  10
    service_2_2_11  unique_nonzero_owner_338  1
    service_2_2_11  service_visit_def_1576  1
    service_2_2_11  free_load_conservation_1577  11
    service_2_2_12  unique_nonzero_owner_339  1
    service_2_2_12  service_visit_def_1576  1
    service_2_2_12  free_load_conservation_1577  12
    service_2_2_13  unique_nonzero_owner_340  1
    service_2_2_13  service_visit_def_1576  1
    service_2_2_13  free_load_conservation_1577  13
    service_2_2_14  unique_nonzero_owner_341  1
    service_2_2_14  service_visit_def_1576  1
    service_2_2_14  free_load_conservation_1577  14
    service_2_2_15  unique_nonzero_owner_342  1
    service_2_2_15  service_visit_def_1576  1
    service_2_2_15  free_load_conservation_1577  15
    service_0_26_1  unique_nonzero_owner_343  1
    service_0_26_1  service_visit_def_781  1
    service_0_26_1  free_load_conservation_782  1
    service_0_26_2  unique_nonzero_owner_344  1
    service_0_26_2  service_visit_def_781  1
    service_0_26_2  free_load_conservation_782  2
    service_0_26_3  unique_nonzero_owner_345  1
    service_0_26_3  service_visit_def_781  1
    service_0_26_3  free_load_conservation_782  3
    service_0_26_4  unique_nonzero_owner_346  1
    service_0_26_4  service_visit_def_781  1
    service_0_26_4  free_load_conservation_782  4
    service_0_26_5  unique_nonzero_owner_347  1
    service_0_26_5  service_visit_def_781  1
    service_0_26_5  free_load_conservation_782  5
    service_0_26_6  unique_nonzero_owner_348  1
    service_0_26_6  service_visit_def_781  1
    service_0_26_6  free_load_conservation_782  6
    service_0_26_7  unique_nonzero_owner_349  1
    service_0_26_7  service_visit_def_781  1
    service_0_26_7  free_load_conservation_782  7
    service_0_26_8  unique_nonzero_owner_350  1
    service_0_26_8  service_visit_def_781  1
    service_0_26_8  free_load_conservation_782  8
    service_1_26_1  unique_nonzero_owner_343  1
    service_1_26_1  service_visit_def_1210  1
    service_1_26_1  free_load_conservation_1211  1
    service_1_26_2  unique_nonzero_owner_344  1
    service_1_26_2  service_visit_def_1210  1
    service_1_26_2  free_load_conservation_1211  2
    service_1_26_3  unique_nonzero_owner_345  1
    service_1_26_3  service_visit_def_1210  1
    service_1_26_3  free_load_conservation_1211  3
    service_1_26_4  unique_nonzero_owner_346  1
    service_1_26_4  service_visit_def_1210  1
    service_1_26_4  free_load_conservation_1211  4
    service_1_26_5  unique_nonzero_owner_347  1
    service_1_26_5  service_visit_def_1210  1
    service_1_26_5  free_load_conservation_1211  5
    service_1_26_6  unique_nonzero_owner_348  1
    service_1_26_6  service_visit_def_1210  1
    service_1_26_6  free_load_conservation_1211  6
    service_1_26_7  unique_nonzero_owner_349  1
    service_1_26_7  service_visit_def_1210  1
    service_1_26_7  free_load_conservation_1211  7
    service_1_26_8  unique_nonzero_owner_350  1
    service_1_26_8  service_visit_def_1210  1
    service_1_26_8  free_load_conservation_1211  8
    service_2_26_1  unique_nonzero_owner_343  1
    service_2_26_1  service_visit_def_1582  1
    service_2_26_1  free_load_conservation_1583  1
    service_2_26_2  unique_nonzero_owner_344  1
    service_2_26_2  service_visit_def_1582  1
    service_2_26_2  free_load_conservation_1583  2
    service_2_26_3  unique_nonzero_owner_345  1
    service_2_26_3  service_visit_def_1582  1
    service_2_26_3  free_load_conservation_1583  3
    service_2_26_4  unique_nonzero_owner_346  1
    service_2_26_4  service_visit_def_1582  1
    service_2_26_4  free_load_conservation_1583  4
    service_2_26_5  unique_nonzero_owner_347  1
    service_2_26_5  service_visit_def_1582  1
    service_2_26_5  free_load_conservation_1583  5
    service_2_26_6  unique_nonzero_owner_348  1
    service_2_26_6  service_visit_def_1582  1
    service_2_26_6  free_load_conservation_1583  6
    service_2_26_7  unique_nonzero_owner_349  1
    service_2_26_7  service_visit_def_1582  1
    service_2_26_7  free_load_conservation_1583  7
    service_2_26_8  unique_nonzero_owner_350  1
    service_2_26_8  service_visit_def_1582  1
    service_2_26_8  free_load_conservation_1583  8
    service_0_16_0  unique_nonzero_owner_351  1
    service_0_16_0  service_visit_def_787  1
    service_0_16_0  free_load_conservation_788  -1
    service_0_16_0  original_T_including_depot_unload_799  120
    service_0_16_2  unique_nonzero_owner_352  1
    service_0_16_2  service_visit_def_787  1
    service_0_16_2  free_load_conservation_788  1
    service_0_16_3  unique_nonzero_owner_353  1
    service_0_16_3  service_visit_def_787  1
    service_0_16_3  free_load_conservation_788  2
    service_0_16_4  unique_nonzero_owner_354  1
    service_0_16_4  service_visit_def_787  1
    service_0_16_4  free_load_conservation_788  3
    service_0_16_5  unique_nonzero_owner_355  1
    service_0_16_5  service_visit_def_787  1
    service_0_16_5  free_load_conservation_788  4
    service_0_16_6  unique_nonzero_owner_356  1
    service_0_16_6  service_visit_def_787  1
    service_0_16_6  free_load_conservation_788  5
    service_0_16_7  unique_nonzero_owner_357  1
    service_0_16_7  service_visit_def_787  1
    service_0_16_7  free_load_conservation_788  6
    service_0_16_8  unique_nonzero_owner_358  1
    service_0_16_8  service_visit_def_787  1
    service_0_16_8  free_load_conservation_788  7
    service_0_16_9  unique_nonzero_owner_359  1
    service_0_16_9  service_visit_def_787  1
    service_0_16_9  free_load_conservation_788  8
    service_0_16_10  unique_nonzero_owner_360  1
    service_0_16_10  service_visit_def_787  1
    service_0_16_10  free_load_conservation_788  9
    service_0_16_11  unique_nonzero_owner_361  1
    service_0_16_11  service_visit_def_787  1
    service_0_16_11  free_load_conservation_788  10
    service_0_16_12  unique_nonzero_owner_362  1
    service_0_16_12  service_visit_def_787  1
    service_0_16_12  free_load_conservation_788  11
    service_1_16_0  unique_nonzero_owner_351  1
    service_1_16_0  service_visit_def_1216  1
    service_1_16_0  free_load_conservation_1217  -1
    service_1_16_0  original_T_including_depot_unload_1228  120
    service_1_16_2  unique_nonzero_owner_352  1
    service_1_16_2  service_visit_def_1216  1
    service_1_16_2  free_load_conservation_1217  1
    service_1_16_3  unique_nonzero_owner_353  1
    service_1_16_3  service_visit_def_1216  1
    service_1_16_3  free_load_conservation_1217  2
    service_1_16_4  unique_nonzero_owner_354  1
    service_1_16_4  service_visit_def_1216  1
    service_1_16_4  free_load_conservation_1217  3
    service_1_16_5  unique_nonzero_owner_355  1
    service_1_16_5  service_visit_def_1216  1
    service_1_16_5  free_load_conservation_1217  4
    service_1_16_6  unique_nonzero_owner_356  1
    service_1_16_6  service_visit_def_1216  1
    service_1_16_6  free_load_conservation_1217  5
    service_1_16_7  unique_nonzero_owner_357  1
    service_1_16_7  service_visit_def_1216  1
    service_1_16_7  free_load_conservation_1217  6
    service_1_16_8  unique_nonzero_owner_358  1
    service_1_16_8  service_visit_def_1216  1
    service_1_16_8  free_load_conservation_1217  7
    service_1_16_9  unique_nonzero_owner_359  1
    service_1_16_9  service_visit_def_1216  1
    service_1_16_9  free_load_conservation_1217  8
    service_1_16_10  unique_nonzero_owner_360  1
    service_1_16_10  service_visit_def_1216  1
    service_1_16_10  free_load_conservation_1217  9
    service_1_16_11  unique_nonzero_owner_361  1
    service_1_16_11  service_visit_def_1216  1
    service_1_16_11  free_load_conservation_1217  10
    service_1_16_12  unique_nonzero_owner_362  1
    service_1_16_12  service_visit_def_1216  1
    service_1_16_12  free_load_conservation_1217  11
    service_2_16_0  unique_nonzero_owner_351  1
    service_2_16_0  service_visit_def_1588  1
    service_2_16_0  free_load_conservation_1589  -1
    service_2_16_0  original_T_including_depot_unload_1599  120
    service_2_16_2  unique_nonzero_owner_352  1
    service_2_16_2  service_visit_def_1588  1
    service_2_16_2  free_load_conservation_1589  1
    service_2_16_3  unique_nonzero_owner_353  1
    service_2_16_3  service_visit_def_1588  1
    service_2_16_3  free_load_conservation_1589  2
    service_2_16_4  unique_nonzero_owner_354  1
    service_2_16_4  service_visit_def_1588  1
    service_2_16_4  free_load_conservation_1589  3
    service_2_16_5  unique_nonzero_owner_355  1
    service_2_16_5  service_visit_def_1588  1
    service_2_16_5  free_load_conservation_1589  4
    service_2_16_6  unique_nonzero_owner_356  1
    service_2_16_6  service_visit_def_1588  1
    service_2_16_6  free_load_conservation_1589  5
    service_2_16_7  unique_nonzero_owner_357  1
    service_2_16_7  service_visit_def_1588  1
    service_2_16_7  free_load_conservation_1589  6
    service_2_16_8  unique_nonzero_owner_358  1
    service_2_16_8  service_visit_def_1588  1
    service_2_16_8  free_load_conservation_1589  7
    service_2_16_9  unique_nonzero_owner_359  1
    service_2_16_9  service_visit_def_1588  1
    service_2_16_9  free_load_conservation_1589  8
    service_2_16_10  unique_nonzero_owner_360  1
    service_2_16_10  service_visit_def_1588  1
    service_2_16_10  free_load_conservation_1589  9
    service_2_16_11  unique_nonzero_owner_361  1
    service_2_16_11  service_visit_def_1588  1
    service_2_16_11  free_load_conservation_1589  10
    service_2_16_12  unique_nonzero_owner_362  1
    service_2_16_12  service_visit_def_1588  1
    service_2_16_12  free_load_conservation_1589  11
    service_0_19_1  unique_nonzero_owner_363  1
    service_0_19_1  service_visit_def_793  1
    service_0_19_1  free_load_conservation_794  1
    service_0_19_2  unique_nonzero_owner_364  1
    service_0_19_2  service_visit_def_793  1
    service_0_19_2  free_load_conservation_794  2
    service_0_19_3  unique_nonzero_owner_365  1
    service_0_19_3  service_visit_def_793  1
    service_0_19_3  free_load_conservation_794  3
    service_0_19_4  unique_nonzero_owner_366  1
    service_0_19_4  service_visit_def_793  1
    service_0_19_4  free_load_conservation_794  4
    service_0_19_5  unique_nonzero_owner_367  1
    service_0_19_5  service_visit_def_793  1
    service_0_19_5  free_load_conservation_794  5
    service_0_19_6  unique_nonzero_owner_368  1
    service_0_19_6  service_visit_def_793  1
    service_0_19_6  free_load_conservation_794  6
    service_0_19_7  unique_nonzero_owner_369  1
    service_0_19_7  service_visit_def_793  1
    service_0_19_7  free_load_conservation_794  7
    service_0_19_8  unique_nonzero_owner_370  1
    service_0_19_8  service_visit_def_793  1
    service_0_19_8  free_load_conservation_794  8
    service_1_19_1  unique_nonzero_owner_363  1
    service_1_19_1  service_visit_def_1222  1
    service_1_19_1  free_load_conservation_1223  1
    service_1_19_2  unique_nonzero_owner_364  1
    service_1_19_2  service_visit_def_1222  1
    service_1_19_2  free_load_conservation_1223  2
    service_1_19_3  unique_nonzero_owner_365  1
    service_1_19_3  service_visit_def_1222  1
    service_1_19_3  free_load_conservation_1223  3
    service_1_19_4  unique_nonzero_owner_366  1
    service_1_19_4  service_visit_def_1222  1
    service_1_19_4  free_load_conservation_1223  4
    service_1_19_5  unique_nonzero_owner_367  1
    service_1_19_5  service_visit_def_1222  1
    service_1_19_5  free_load_conservation_1223  5
    service_1_19_6  unique_nonzero_owner_368  1
    service_1_19_6  service_visit_def_1222  1
    service_1_19_6  free_load_conservation_1223  6
    service_1_19_7  unique_nonzero_owner_369  1
    service_1_19_7  service_visit_def_1222  1
    service_1_19_7  free_load_conservation_1223  7
    service_1_19_8  unique_nonzero_owner_370  1
    service_1_19_8  service_visit_def_1222  1
    service_1_19_8  free_load_conservation_1223  8
    service_2_19_1  unique_nonzero_owner_363  1
    service_2_19_1  service_visit_def_1594  1
    service_2_19_1  free_load_conservation_1595  1
    service_2_19_2  unique_nonzero_owner_364  1
    service_2_19_2  service_visit_def_1594  1
    service_2_19_2  free_load_conservation_1595  2
    service_2_19_3  unique_nonzero_owner_365  1
    service_2_19_3  service_visit_def_1594  1
    service_2_19_3  free_load_conservation_1595  3
    service_2_19_4  unique_nonzero_owner_366  1
    service_2_19_4  service_visit_def_1594  1
    service_2_19_4  free_load_conservation_1595  4
    service_2_19_5  unique_nonzero_owner_367  1
    service_2_19_5  service_visit_def_1594  1
    service_2_19_5  free_load_conservation_1595  5
    service_2_19_6  unique_nonzero_owner_368  1
    service_2_19_6  service_visit_def_1594  1
    service_2_19_6  free_load_conservation_1595  6
    service_2_19_7  unique_nonzero_owner_369  1
    service_2_19_7  service_visit_def_1594  1
    service_2_19_7  free_load_conservation_1595  7
    service_2_19_8  unique_nonzero_owner_370  1
    service_2_19_8  service_visit_def_1594  1
    service_2_19_8  free_load_conservation_1595  8
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_712  -1
    visit_0_1  in_degree_713  -1
    visit_0_1  order_active_lb_714  -1
    visit_0_1  order_active_ub_715  -13
    order_0_1  connected_order_arc_387  -1
    order_0_1  connected_order_arc_389  -1
    order_0_1  connected_order_arc_391  -1
    order_0_1  connected_order_arc_393  -1
    order_0_1  connected_order_arc_395  -1
    order_0_1  connected_order_arc_397  -1
    order_0_1  connected_order_arc_399  -1
    order_0_1  connected_order_arc_401  -1
    order_0_1  connected_order_arc_403  -1
    order_0_1  connected_order_arc_405  -1
    order_0_1  connected_order_arc_407  -1
    order_0_1  connected_order_arc_409  -1
    order_0_1  connected_order_arc_412  1
    order_0_1  connected_order_arc_437  1
    order_0_1  connected_order_arc_462  1
    order_0_1  connected_order_arc_487  1
    order_0_1  connected_order_arc_512  1
    order_0_1  connected_order_arc_537  1
    order_0_1  connected_order_arc_562  1
    order_0_1  connected_order_arc_587  1
    order_0_1  connected_order_arc_612  1
    order_0_1  connected_order_arc_637  1
    order_0_1  connected_order_arc_662  1
    order_0_1  connected_order_arc_687  1
    order_0_1  order_active_lb_714  1
    order_0_1  order_active_ub_715  1
    order_0_1  fixed_segment_relative_order_795  -1
    visit_0_2  out_degree_719  -1
    visit_0_2  in_degree_720  -1
    visit_0_2  order_active_lb_721  -1
    visit_0_2  order_active_ub_722  -13
    order_0_2  connected_order_arc_387  1
    order_0_2  connected_order_arc_412  -1
    order_0_2  connected_order_arc_414  -1
    order_0_2  connected_order_arc_416  -1
    order_0_2  connected_order_arc_418  -1
    order_0_2  connected_order_arc_420  -1
    order_0_2  connected_order_arc_422  -1
    order_0_2  connected_order_arc_424  -1
    order_0_2  connected_order_arc_426  -1
    order_0_2  connected_order_arc_428  -1
    order_0_2  connected_order_arc_430  -1
    order_0_2  connected_order_arc_432  -1
    order_0_2  connected_order_arc_434  -1
    order_0_2  connected_order_arc_439  1
    order_0_2  connected_order_arc_464  1
    order_0_2  connected_order_arc_489  1
    order_0_2  connected_order_arc_514  1
    order_0_2  connected_order_arc_539  1
    order_0_2  connected_order_arc_564  1
    order_0_2  connected_order_arc_589  1
    order_0_2  connected_order_arc_614  1
    order_0_2  connected_order_arc_639  1
    order_0_2  connected_order_arc_664  1
    order_0_2  connected_order_arc_689  1
    order_0_2  order_active_lb_721  1
    order_0_2  order_active_ub_722  1
    order_0_2  fixed_segment_relative_order_795  1
    order_0_2  fixed_segment_relative_order_796  -1
    visit_0_3  out_degree_726  -1
    visit_0_3  in_degree_727  -1
    visit_0_3  order_active_lb_728  -1
    visit_0_3  order_active_ub_729  -13
    order_0_3  connected_order_arc_389  1
    order_0_3  connected_order_arc_414  1
    order_0_3  connected_order_arc_437  -1
    order_0_3  connected_order_arc_439  -1
    order_0_3  connected_order_arc_441  -1
    order_0_3  connected_order_arc_443  -1
    order_0_3  connected_order_arc_445  -1
    order_0_3  connected_order_arc_447  -1
    order_0_3  connected_order_arc_449  -1
    order_0_3  connected_order_arc_451  -1
    order_0_3  connected_order_arc_453  -1
    order_0_3  connected_order_arc_455  -1
    order_0_3  connected_order_arc_457  -1
    order_0_3  connected_order_arc_459  -1
    order_0_3  connected_order_arc_466  1
    order_0_3  connected_order_arc_491  1
    order_0_3  connected_order_arc_516  1
    order_0_3  connected_order_arc_541  1
    order_0_3  connected_order_arc_566  1
    order_0_3  connected_order_arc_591  1
    order_0_3  connected_order_arc_616  1
    order_0_3  connected_order_arc_641  1
    order_0_3  connected_order_arc_666  1
    order_0_3  connected_order_arc_691  1
    order_0_3  order_active_lb_728  1
    order_0_3  order_active_ub_729  1
    order_0_3  fixed_segment_relative_order_796  1
    order_0_3  fixed_segment_relative_order_797  -1
    visit_0_4  out_degree_733  -1
    visit_0_4  in_degree_734  -1
    visit_0_4  order_active_lb_735  -1
    visit_0_4  order_active_ub_736  -13
    order_0_4  connected_order_arc_391  1
    order_0_4  connected_order_arc_416  1
    order_0_4  connected_order_arc_441  1
    order_0_4  connected_order_arc_462  -1
    order_0_4  connected_order_arc_464  -1
    order_0_4  connected_order_arc_466  -1
    order_0_4  connected_order_arc_468  -1
    order_0_4  connected_order_arc_470  -1
    order_0_4  connected_order_arc_472  -1
    order_0_4  connected_order_arc_474  -1
    order_0_4  connected_order_arc_476  -1
    order_0_4  connected_order_arc_478  -1
    order_0_4  connected_order_arc_480  -1
    order_0_4  connected_order_arc_482  -1
    order_0_4  connected_order_arc_484  -1
    order_0_4  connected_order_arc_493  1
    order_0_4  connected_order_arc_518  1
    order_0_4  connected_order_arc_543  1
    order_0_4  connected_order_arc_568  1
    order_0_4  connected_order_arc_593  1
    order_0_4  connected_order_arc_618  1
    order_0_4  connected_order_arc_643  1
    order_0_4  connected_order_arc_668  1
    order_0_4  connected_order_arc_693  1
    order_0_4  order_active_lb_735  1
    order_0_4  order_active_ub_736  1
    order_0_4  fixed_segment_relative_order_797  1
    order_0_4  fixed_segment_relative_order_798  -1
    visit_0_5  out_degree_740  -1
    visit_0_5  in_degree_741  -1
    visit_0_5  order_active_lb_742  -1
    visit_0_5  order_active_ub_743  -13
    order_0_5  connected_order_arc_393  1
    order_0_5  connected_order_arc_418  1
    order_0_5  connected_order_arc_443  1
    order_0_5  connected_order_arc_468  1
    order_0_5  connected_order_arc_487  -1
    order_0_5  connected_order_arc_489  -1
    order_0_5  connected_order_arc_491  -1
    order_0_5  connected_order_arc_493  -1
    order_0_5  connected_order_arc_495  -1
    order_0_5  connected_order_arc_497  -1
    order_0_5  connected_order_arc_499  -1
    order_0_5  connected_order_arc_501  -1
    order_0_5  connected_order_arc_503  -1
    order_0_5  connected_order_arc_505  -1
    order_0_5  connected_order_arc_507  -1
    order_0_5  connected_order_arc_509  -1
    order_0_5  connected_order_arc_520  1
    order_0_5  connected_order_arc_545  1
    order_0_5  connected_order_arc_570  1
    order_0_5  connected_order_arc_595  1
    order_0_5  connected_order_arc_620  1
    order_0_5  connected_order_arc_645  1
    order_0_5  connected_order_arc_670  1
    order_0_5  connected_order_arc_695  1
    order_0_5  order_active_lb_742  1
    order_0_5  order_active_ub_743  1
    order_0_5  fixed_segment_relative_order_798  1
    visit_0_15  out_degree_747  -1
    visit_0_15  in_degree_748  -1
    visit_0_15  order_active_lb_749  -1
    visit_0_15  order_active_ub_750  -13
    visit_0_15  service_visit_def_751  -1
    order_0_15  connected_order_arc_395  1
    order_0_15  connected_order_arc_420  1
    order_0_15  connected_order_arc_445  1
    order_0_15  connected_order_arc_470  1
    order_0_15  connected_order_arc_495  1
    order_0_15  connected_order_arc_512  -1
    order_0_15  connected_order_arc_514  -1
    order_0_15  connected_order_arc_516  -1
    order_0_15  connected_order_arc_518  -1
    order_0_15  connected_order_arc_520  -1
    order_0_15  connected_order_arc_522  -1
    order_0_15  connected_order_arc_524  -1
    order_0_15  connected_order_arc_526  -1
    order_0_15  connected_order_arc_528  -1
    order_0_15  connected_order_arc_530  -1
    order_0_15  connected_order_arc_532  -1
    order_0_15  connected_order_arc_534  -1
    order_0_15  connected_order_arc_547  1
    order_0_15  connected_order_arc_572  1
    order_0_15  connected_order_arc_597  1
    order_0_15  connected_order_arc_622  1
    order_0_15  connected_order_arc_647  1
    order_0_15  connected_order_arc_672  1
    order_0_15  connected_order_arc_697  1
    order_0_15  order_active_lb_749  1
    order_0_15  order_active_ub_750  1
    visit_0_16  out_degree_753  -1
    visit_0_16  in_degree_754  -1
    visit_0_16  order_active_lb_755  -1
    visit_0_16  order_active_ub_756  -13
    visit_0_16  service_visit_def_757  -1
    order_0_16  connected_order_arc_397  1
    order_0_16  connected_order_arc_422  1
    order_0_16  connected_order_arc_447  1
    order_0_16  connected_order_arc_472  1
    order_0_16  connected_order_arc_497  1
    order_0_16  connected_order_arc_522  1
    order_0_16  connected_order_arc_537  -1
    order_0_16  connected_order_arc_539  -1
    order_0_16  connected_order_arc_541  -1
    order_0_16  connected_order_arc_543  -1
    order_0_16  connected_order_arc_545  -1
    order_0_16  connected_order_arc_547  -1
    order_0_16  connected_order_arc_549  -1
    order_0_16  connected_order_arc_551  -1
    order_0_16  connected_order_arc_553  -1
    order_0_16  connected_order_arc_555  -1
    order_0_16  connected_order_arc_557  -1
    order_0_16  connected_order_arc_559  -1
    order_0_16  connected_order_arc_574  1
    order_0_16  connected_order_arc_599  1
    order_0_16  connected_order_arc_624  1
    order_0_16  connected_order_arc_649  1
    order_0_16  connected_order_arc_674  1
    order_0_16  connected_order_arc_699  1
    order_0_16  order_active_lb_755  1
    order_0_16  order_active_ub_756  1
    visit_0_17  out_degree_759  -1
    visit_0_17  in_degree_760  -1
    visit_0_17  order_active_lb_761  -1
    visit_0_17  order_active_ub_762  -13
    visit_0_17  service_visit_def_763  -1
    order_0_17  connected_order_arc_399  1
    order_0_17  connected_order_arc_424  1
    order_0_17  connected_order_arc_449  1
    order_0_17  connected_order_arc_474  1
    order_0_17  connected_order_arc_499  1
    order_0_17  connected_order_arc_524  1
    order_0_17  connected_order_arc_549  1
    order_0_17  connected_order_arc_562  -1
    order_0_17  connected_order_arc_564  -1
    order_0_17  connected_order_arc_566  -1
    order_0_17  connected_order_arc_568  -1
    order_0_17  connected_order_arc_570  -1
    order_0_17  connected_order_arc_572  -1
    order_0_17  connected_order_arc_574  -1
    order_0_17  connected_order_arc_576  -1
    order_0_17  connected_order_arc_578  -1
    order_0_17  connected_order_arc_580  -1
    order_0_17  connected_order_arc_582  -1
    order_0_17  connected_order_arc_584  -1
    order_0_17  connected_order_arc_601  1
    order_0_17  connected_order_arc_626  1
    order_0_17  connected_order_arc_651  1
    order_0_17  connected_order_arc_676  1
    order_0_17  connected_order_arc_701  1
    order_0_17  order_active_lb_761  1
    order_0_17  order_active_ub_762  1
    visit_0_18  out_degree_765  -1
    visit_0_18  in_degree_766  -1
    visit_0_18  order_active_lb_767  -1
    visit_0_18  order_active_ub_768  -13
    visit_0_18  service_visit_def_769  -1
    order_0_18  connected_order_arc_401  1
    order_0_18  connected_order_arc_426  1
    order_0_18  connected_order_arc_451  1
    order_0_18  connected_order_arc_476  1
    order_0_18  connected_order_arc_501  1
    order_0_18  connected_order_arc_526  1
    order_0_18  connected_order_arc_551  1
    order_0_18  connected_order_arc_576  1
    order_0_18  connected_order_arc_587  -1
    order_0_18  connected_order_arc_589  -1
    order_0_18  connected_order_arc_591  -1
    order_0_18  connected_order_arc_593  -1
    order_0_18  connected_order_arc_595  -1
    order_0_18  connected_order_arc_597  -1
    order_0_18  connected_order_arc_599  -1
    order_0_18  connected_order_arc_601  -1
    order_0_18  connected_order_arc_603  -1
    order_0_18  connected_order_arc_605  -1
    order_0_18  connected_order_arc_607  -1
    order_0_18  connected_order_arc_609  -1
    order_0_18  connected_order_arc_628  1
    order_0_18  connected_order_arc_653  1
    order_0_18  connected_order_arc_678  1
    order_0_18  connected_order_arc_703  1
    order_0_18  order_active_lb_767  1
    order_0_18  order_active_ub_768  1
    visit_0_19  out_degree_771  -1
    visit_0_19  in_degree_772  -1
    visit_0_19  order_active_lb_773  -1
    visit_0_19  order_active_ub_774  -13
    visit_0_19  service_visit_def_775  -1
    order_0_19  connected_order_arc_403  1
    order_0_19  connected_order_arc_428  1
    order_0_19  connected_order_arc_453  1
    order_0_19  connected_order_arc_478  1
    order_0_19  connected_order_arc_503  1
    order_0_19  connected_order_arc_528  1
    order_0_19  connected_order_arc_553  1
    order_0_19  connected_order_arc_578  1
    order_0_19  connected_order_arc_603  1
    order_0_19  connected_order_arc_612  -1
    order_0_19  connected_order_arc_614  -1
    order_0_19  connected_order_arc_616  -1
    order_0_19  connected_order_arc_618  -1
    order_0_19  connected_order_arc_620  -1
    order_0_19  connected_order_arc_622  -1
    order_0_19  connected_order_arc_624  -1
    order_0_19  connected_order_arc_626  -1
    order_0_19  connected_order_arc_628  -1
    order_0_19  connected_order_arc_630  -1
    order_0_19  connected_order_arc_632  -1
    order_0_19  connected_order_arc_634  -1
    order_0_19  connected_order_arc_655  1
    order_0_19  connected_order_arc_680  1
    order_0_19  connected_order_arc_705  1
    order_0_19  order_active_lb_773  1
    order_0_19  order_active_ub_774  1
    visit_0_20  out_degree_777  -1
    visit_0_20  in_degree_778  -1
    visit_0_20  order_active_lb_779  -1
    visit_0_20  order_active_ub_780  -13
    visit_0_20  service_visit_def_781  -1
    order_0_20  connected_order_arc_405  1
    order_0_20  connected_order_arc_430  1
    order_0_20  connected_order_arc_455  1
    order_0_20  connected_order_arc_480  1
    order_0_20  connected_order_arc_505  1
    order_0_20  connected_order_arc_530  1
    order_0_20  connected_order_arc_555  1
    order_0_20  connected_order_arc_580  1
    order_0_20  connected_order_arc_605  1
    order_0_20  connected_order_arc_630  1
    order_0_20  connected_order_arc_637  -1
    order_0_20  connected_order_arc_639  -1
    order_0_20  connected_order_arc_641  -1
    order_0_20  connected_order_arc_643  -1
    order_0_20  connected_order_arc_645  -1
    order_0_20  connected_order_arc_647  -1
    order_0_20  connected_order_arc_649  -1
    order_0_20  connected_order_arc_651  -1
    order_0_20  connected_order_arc_653  -1
    order_0_20  connected_order_arc_655  -1
    order_0_20  connected_order_arc_657  -1
    order_0_20  connected_order_arc_659  -1
    order_0_20  connected_order_arc_682  1
    order_0_20  connected_order_arc_707  1
    order_0_20  order_active_lb_779  1
    order_0_20  order_active_ub_780  1
    visit_0_21  out_degree_783  -1
    visit_0_21  in_degree_784  -1
    visit_0_21  order_active_lb_785  -1
    visit_0_21  order_active_ub_786  -13
    visit_0_21  service_visit_def_787  -1
    order_0_21  connected_order_arc_407  1
    order_0_21  connected_order_arc_432  1
    order_0_21  connected_order_arc_457  1
    order_0_21  connected_order_arc_482  1
    order_0_21  connected_order_arc_507  1
    order_0_21  connected_order_arc_532  1
    order_0_21  connected_order_arc_557  1
    order_0_21  connected_order_arc_582  1
    order_0_21  connected_order_arc_607  1
    order_0_21  connected_order_arc_632  1
    order_0_21  connected_order_arc_657  1
    order_0_21  connected_order_arc_662  -1
    order_0_21  connected_order_arc_664  -1
    order_0_21  connected_order_arc_666  -1
    order_0_21  connected_order_arc_668  -1
    order_0_21  connected_order_arc_670  -1
    order_0_21  connected_order_arc_672  -1
    order_0_21  connected_order_arc_674  -1
    order_0_21  connected_order_arc_676  -1
    order_0_21  connected_order_arc_678  -1
    order_0_21  connected_order_arc_680  -1
    order_0_21  connected_order_arc_682  -1
    order_0_21  connected_order_arc_684  -1
    order_0_21  connected_order_arc_709  1
    order_0_21  order_active_lb_785  1
    order_0_21  order_active_ub_786  1
    visit_0_22  out_degree_789  -1
    visit_0_22  in_degree_790  -1
    visit_0_22  order_active_lb_791  -1
    visit_0_22  order_active_ub_792  -13
    visit_0_22  service_visit_def_793  -1
    order_0_22  connected_order_arc_409  1
    order_0_22  connected_order_arc_434  1
    order_0_22  connected_order_arc_459  1
    order_0_22  connected_order_arc_484  1
    order_0_22  connected_order_arc_509  1
    order_0_22  connected_order_arc_534  1
    order_0_22  connected_order_arc_559  1
    order_0_22  connected_order_arc_584  1
    order_0_22  connected_order_arc_609  1
    order_0_22  connected_order_arc_634  1
    order_0_22  connected_order_arc_659  1
    order_0_22  connected_order_arc_684  1
    order_0_22  connected_order_arc_687  -1
    order_0_22  connected_order_arc_689  -1
    order_0_22  connected_order_arc_691  -1
    order_0_22  connected_order_arc_693  -1
    order_0_22  connected_order_arc_695  -1
    order_0_22  connected_order_arc_697  -1
    order_0_22  connected_order_arc_699  -1
    order_0_22  connected_order_arc_701  -1
    order_0_22  connected_order_arc_703  -1
    order_0_22  connected_order_arc_705  -1
    order_0_22  connected_order_arc_707  -1
    order_0_22  connected_order_arc_709  -1
    order_0_22  order_active_lb_791  1
    order_0_22  order_active_ub_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_371  -20
    arc_0_0_0  depot_departure_or_bypass_710  1
    arc_0_0_0  depot_return_or_bypass_711  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_371  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_372  -20
    arc_0_0_1  depot_departure_or_bypass_710  1
    arc_0_0_1  in_degree_713  1
    arc_0_0_1  original_T_including_depot_unload_799  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_372  1
    load_0_0_1  segment_load_conservation_716  -1
    load_0_0_1  segment_prefix_lb_717  1
    load_0_0_1  segment_prefix_ub_718  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_373  -20
    arc_0_0_2  depot_departure_or_bypass_710  1
    arc_0_0_2  in_degree_720  1
    arc_0_0_2  original_T_including_depot_unload_799  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_373  1
    load_0_0_2  segment_load_conservation_723  -1
    load_0_0_2  segment_prefix_lb_724  1
    load_0_0_2  segment_prefix_ub_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_374  -20
    arc_0_0_3  depot_departure_or_bypass_710  1
    arc_0_0_3  in_degree_727  1
    arc_0_0_3  original_T_including_depot_unload_799  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_374  1
    load_0_0_3  segment_load_conservation_730  -1
    load_0_0_3  segment_prefix_lb_731  1
    load_0_0_3  segment_prefix_ub_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_375  -20
    arc_0_0_4  depot_departure_or_bypass_710  1
    arc_0_0_4  in_degree_734  1
    arc_0_0_4  original_T_including_depot_unload_799  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_375  1
    load_0_0_4  segment_load_conservation_737  -1
    load_0_0_4  segment_prefix_lb_738  1
    load_0_0_4  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_376  -20
    arc_0_0_5  depot_departure_or_bypass_710  1
    arc_0_0_5  in_degree_741  1
    arc_0_0_5  original_T_including_depot_unload_799  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_376  1
    load_0_0_5  segment_load_conservation_744  -1
    load_0_0_5  segment_prefix_lb_745  1
    load_0_0_5  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_377  -20
    arc_0_0_15  depot_departure_or_bypass_710  1
    arc_0_0_15  in_degree_748  1
    arc_0_0_15  original_T_including_depot_unload_799  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_377  1
    load_0_0_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_378  -20
    arc_0_0_16  depot_departure_or_bypass_710  1
    arc_0_0_16  in_degree_754  1
    arc_0_0_16  original_T_including_depot_unload_799  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_378  1
    load_0_0_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_379  -20
    arc_0_0_17  depot_departure_or_bypass_710  1
    arc_0_0_17  in_degree_760  1
    arc_0_0_17  original_T_including_depot_unload_799  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_379  1
    load_0_0_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_380  -20
    arc_0_0_18  depot_departure_or_bypass_710  1
    arc_0_0_18  in_degree_766  1
    arc_0_0_18  original_T_including_depot_unload_799  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_380  1
    load_0_0_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_381  -20
    arc_0_0_19  depot_departure_or_bypass_710  1
    arc_0_0_19  in_degree_772  1
    arc_0_0_19  original_T_including_depot_unload_799  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_381  1
    load_0_0_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_382  -20
    arc_0_0_20  depot_departure_or_bypass_710  1
    arc_0_0_20  in_degree_778  1
    arc_0_0_20  original_T_including_depot_unload_799  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_382  1
    load_0_0_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_383  -20
    arc_0_0_21  depot_departure_or_bypass_710  1
    arc_0_0_21  in_degree_784  1
    arc_0_0_21  original_T_including_depot_unload_799  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_383  1
    load_0_0_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_384  -20
    arc_0_0_22  depot_departure_or_bypass_710  1
    arc_0_0_22  in_degree_790  1
    arc_0_0_22  original_T_including_depot_unload_799  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_384  1
    load_0_0_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_385  -20
    arc_0_1_0  depot_return_or_bypass_711  1
    arc_0_1_0  out_degree_712  1
    arc_0_1_0  original_T_including_depot_unload_799  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_385  1
    load_0_1_0  segment_load_conservation_716  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_386  -20
    arc_0_1_2  connected_order_arc_387  -14
    arc_0_1_2  out_degree_712  1
    arc_0_1_2  in_degree_720  1
    arc_0_1_2  original_T_including_depot_unload_799  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_386  1
    load_0_1_2  segment_load_conservation_716  1
    load_0_1_2  segment_load_conservation_723  -1
    load_0_1_2  segment_prefix_lb_724  1
    load_0_1_2  segment_prefix_ub_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_388  -20
    arc_0_1_3  connected_order_arc_389  -14
    arc_0_1_3  out_degree_712  1
    arc_0_1_3  in_degree_727  1
    arc_0_1_3  original_T_including_depot_unload_799  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_388  1
    load_0_1_3  segment_load_conservation_716  1
    load_0_1_3  segment_load_conservation_730  -1
    load_0_1_3  segment_prefix_lb_731  1
    load_0_1_3  segment_prefix_ub_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_390  -20
    arc_0_1_4  connected_order_arc_391  -14
    arc_0_1_4  out_degree_712  1
    arc_0_1_4  in_degree_734  1
    arc_0_1_4  original_T_including_depot_unload_799  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_390  1
    load_0_1_4  segment_load_conservation_716  1
    load_0_1_4  segment_load_conservation_737  -1
    load_0_1_4  segment_prefix_lb_738  1
    load_0_1_4  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_392  -20
    arc_0_1_5  connected_order_arc_393  -14
    arc_0_1_5  out_degree_712  1
    arc_0_1_5  in_degree_741  1
    arc_0_1_5  original_T_including_depot_unload_799  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_392  1
    load_0_1_5  segment_load_conservation_716  1
    load_0_1_5  segment_load_conservation_744  -1
    load_0_1_5  segment_prefix_lb_745  1
    load_0_1_5  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_394  -20
    arc_0_1_15  connected_order_arc_395  -14
    arc_0_1_15  out_degree_712  1
    arc_0_1_15  in_degree_748  1
    arc_0_1_15  original_T_including_depot_unload_799  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_394  1
    load_0_1_15  segment_load_conservation_716  1
    load_0_1_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_396  -20
    arc_0_1_16  connected_order_arc_397  -14
    arc_0_1_16  out_degree_712  1
    arc_0_1_16  in_degree_754  1
    arc_0_1_16  original_T_including_depot_unload_799  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_396  1
    load_0_1_16  segment_load_conservation_716  1
    load_0_1_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_398  -20
    arc_0_1_17  connected_order_arc_399  -14
    arc_0_1_17  out_degree_712  1
    arc_0_1_17  in_degree_760  1
    arc_0_1_17  original_T_including_depot_unload_799  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_398  1
    load_0_1_17  segment_load_conservation_716  1
    load_0_1_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_400  -20
    arc_0_1_18  connected_order_arc_401  -14
    arc_0_1_18  out_degree_712  1
    arc_0_1_18  in_degree_766  1
    arc_0_1_18  original_T_including_depot_unload_799  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_400  1
    load_0_1_18  segment_load_conservation_716  1
    load_0_1_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_402  -20
    arc_0_1_19  connected_order_arc_403  -14
    arc_0_1_19  out_degree_712  1
    arc_0_1_19  in_degree_772  1
    arc_0_1_19  original_T_including_depot_unload_799  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_402  1
    load_0_1_19  segment_load_conservation_716  1
    load_0_1_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_404  -20
    arc_0_1_20  connected_order_arc_405  -14
    arc_0_1_20  out_degree_712  1
    arc_0_1_20  in_degree_778  1
    arc_0_1_20  original_T_including_depot_unload_799  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_404  1
    load_0_1_20  segment_load_conservation_716  1
    load_0_1_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_406  -20
    arc_0_1_21  connected_order_arc_407  -14
    arc_0_1_21  out_degree_712  1
    arc_0_1_21  in_degree_784  1
    arc_0_1_21  original_T_including_depot_unload_799  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_406  1
    load_0_1_21  segment_load_conservation_716  1
    load_0_1_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_408  -20
    arc_0_1_22  connected_order_arc_409  -14
    arc_0_1_22  out_degree_712  1
    arc_0_1_22  in_degree_790  1
    arc_0_1_22  original_T_including_depot_unload_799  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_408  1
    load_0_1_22  segment_load_conservation_716  1
    load_0_1_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_410  -20
    arc_0_2_0  depot_return_or_bypass_711  1
    arc_0_2_0  out_degree_719  1
    arc_0_2_0  original_T_including_depot_unload_799  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_410  1
    load_0_2_0  segment_load_conservation_723  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_411  -20
    arc_0_2_1  connected_order_arc_412  -14
    arc_0_2_1  in_degree_713  1
    arc_0_2_1  out_degree_719  1
    arc_0_2_1  original_T_including_depot_unload_799  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_411  1
    load_0_2_1  segment_load_conservation_716  -1
    load_0_2_1  segment_prefix_lb_717  1
    load_0_2_1  segment_prefix_ub_718  1
    load_0_2_1  segment_load_conservation_723  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_413  -20
    arc_0_2_3  connected_order_arc_414  -14
    arc_0_2_3  out_degree_719  1
    arc_0_2_3  in_degree_727  1
    arc_0_2_3  original_T_including_depot_unload_799  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_413  1
    load_0_2_3  segment_load_conservation_723  1
    load_0_2_3  segment_load_conservation_730  -1
    load_0_2_3  segment_prefix_lb_731  1
    load_0_2_3  segment_prefix_ub_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_415  -20
    arc_0_2_4  connected_order_arc_416  -14
    arc_0_2_4  out_degree_719  1
    arc_0_2_4  in_degree_734  1
    arc_0_2_4  original_T_including_depot_unload_799  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_415  1
    load_0_2_4  segment_load_conservation_723  1
    load_0_2_4  segment_load_conservation_737  -1
    load_0_2_4  segment_prefix_lb_738  1
    load_0_2_4  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_417  -20
    arc_0_2_5  connected_order_arc_418  -14
    arc_0_2_5  out_degree_719  1
    arc_0_2_5  in_degree_741  1
    arc_0_2_5  original_T_including_depot_unload_799  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_417  1
    load_0_2_5  segment_load_conservation_723  1
    load_0_2_5  segment_load_conservation_744  -1
    load_0_2_5  segment_prefix_lb_745  1
    load_0_2_5  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_419  -20
    arc_0_2_15  connected_order_arc_420  -14
    arc_0_2_15  out_degree_719  1
    arc_0_2_15  in_degree_748  1
    arc_0_2_15  original_T_including_depot_unload_799  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_419  1
    load_0_2_15  segment_load_conservation_723  1
    load_0_2_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_421  -20
    arc_0_2_16  connected_order_arc_422  -14
    arc_0_2_16  out_degree_719  1
    arc_0_2_16  in_degree_754  1
    arc_0_2_16  original_T_including_depot_unload_799  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_421  1
    load_0_2_16  segment_load_conservation_723  1
    load_0_2_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_423  -20
    arc_0_2_17  connected_order_arc_424  -14
    arc_0_2_17  out_degree_719  1
    arc_0_2_17  in_degree_760  1
    arc_0_2_17  original_T_including_depot_unload_799  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_423  1
    load_0_2_17  segment_load_conservation_723  1
    load_0_2_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_425  -20
    arc_0_2_18  connected_order_arc_426  -14
    arc_0_2_18  out_degree_719  1
    arc_0_2_18  in_degree_766  1
    arc_0_2_18  original_T_including_depot_unload_799  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_425  1
    load_0_2_18  segment_load_conservation_723  1
    load_0_2_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_427  -20
    arc_0_2_19  connected_order_arc_428  -14
    arc_0_2_19  out_degree_719  1
    arc_0_2_19  in_degree_772  1
    arc_0_2_19  original_T_including_depot_unload_799  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_427  1
    load_0_2_19  segment_load_conservation_723  1
    load_0_2_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_429  -20
    arc_0_2_20  connected_order_arc_430  -14
    arc_0_2_20  out_degree_719  1
    arc_0_2_20  in_degree_778  1
    arc_0_2_20  original_T_including_depot_unload_799  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_429  1
    load_0_2_20  segment_load_conservation_723  1
    load_0_2_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_431  -20
    arc_0_2_21  connected_order_arc_432  -14
    arc_0_2_21  out_degree_719  1
    arc_0_2_21  in_degree_784  1
    arc_0_2_21  original_T_including_depot_unload_799  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_431  1
    load_0_2_21  segment_load_conservation_723  1
    load_0_2_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_433  -20
    arc_0_2_22  connected_order_arc_434  -14
    arc_0_2_22  out_degree_719  1
    arc_0_2_22  in_degree_790  1
    arc_0_2_22  original_T_including_depot_unload_799  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_433  1
    load_0_2_22  segment_load_conservation_723  1
    load_0_2_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_435  -20
    arc_0_3_0  depot_return_or_bypass_711  1
    arc_0_3_0  out_degree_726  1
    arc_0_3_0  original_T_including_depot_unload_799  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_435  1
    load_0_3_0  segment_load_conservation_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_436  -20
    arc_0_3_1  connected_order_arc_437  -14
    arc_0_3_1  in_degree_713  1
    arc_0_3_1  out_degree_726  1
    arc_0_3_1  original_T_including_depot_unload_799  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_436  1
    load_0_3_1  segment_load_conservation_716  -1
    load_0_3_1  segment_prefix_lb_717  1
    load_0_3_1  segment_prefix_ub_718  1
    load_0_3_1  segment_load_conservation_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_438  -20
    arc_0_3_2  connected_order_arc_439  -14
    arc_0_3_2  in_degree_720  1
    arc_0_3_2  out_degree_726  1
    arc_0_3_2  original_T_including_depot_unload_799  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_438  1
    load_0_3_2  segment_load_conservation_723  -1
    load_0_3_2  segment_prefix_lb_724  1
    load_0_3_2  segment_prefix_ub_725  1
    load_0_3_2  segment_load_conservation_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_440  -20
    arc_0_3_4  connected_order_arc_441  -14
    arc_0_3_4  out_degree_726  1
    arc_0_3_4  in_degree_734  1
    arc_0_3_4  original_T_including_depot_unload_799  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_440  1
    load_0_3_4  segment_load_conservation_730  1
    load_0_3_4  segment_load_conservation_737  -1
    load_0_3_4  segment_prefix_lb_738  1
    load_0_3_4  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_442  -20
    arc_0_3_5  connected_order_arc_443  -14
    arc_0_3_5  out_degree_726  1
    arc_0_3_5  in_degree_741  1
    arc_0_3_5  original_T_including_depot_unload_799  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_442  1
    load_0_3_5  segment_load_conservation_730  1
    load_0_3_5  segment_load_conservation_744  -1
    load_0_3_5  segment_prefix_lb_745  1
    load_0_3_5  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_444  -20
    arc_0_3_15  connected_order_arc_445  -14
    arc_0_3_15  out_degree_726  1
    arc_0_3_15  in_degree_748  1
    arc_0_3_15  original_T_including_depot_unload_799  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_444  1
    load_0_3_15  segment_load_conservation_730  1
    load_0_3_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_446  -20
    arc_0_3_16  connected_order_arc_447  -14
    arc_0_3_16  out_degree_726  1
    arc_0_3_16  in_degree_754  1
    arc_0_3_16  original_T_including_depot_unload_799  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_446  1
    load_0_3_16  segment_load_conservation_730  1
    load_0_3_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_448  -20
    arc_0_3_17  connected_order_arc_449  -14
    arc_0_3_17  out_degree_726  1
    arc_0_3_17  in_degree_760  1
    arc_0_3_17  original_T_including_depot_unload_799  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_448  1
    load_0_3_17  segment_load_conservation_730  1
    load_0_3_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_450  -20
    arc_0_3_18  connected_order_arc_451  -14
    arc_0_3_18  out_degree_726  1
    arc_0_3_18  in_degree_766  1
    arc_0_3_18  original_T_including_depot_unload_799  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_450  1
    load_0_3_18  segment_load_conservation_730  1
    load_0_3_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_452  -20
    arc_0_3_19  connected_order_arc_453  -14
    arc_0_3_19  out_degree_726  1
    arc_0_3_19  in_degree_772  1
    arc_0_3_19  original_T_including_depot_unload_799  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_452  1
    load_0_3_19  segment_load_conservation_730  1
    load_0_3_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_454  -20
    arc_0_3_20  connected_order_arc_455  -14
    arc_0_3_20  out_degree_726  1
    arc_0_3_20  in_degree_778  1
    arc_0_3_20  original_T_including_depot_unload_799  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_454  1
    load_0_3_20  segment_load_conservation_730  1
    load_0_3_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_456  -20
    arc_0_3_21  connected_order_arc_457  -14
    arc_0_3_21  out_degree_726  1
    arc_0_3_21  in_degree_784  1
    arc_0_3_21  original_T_including_depot_unload_799  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_456  1
    load_0_3_21  segment_load_conservation_730  1
    load_0_3_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_458  -20
    arc_0_3_22  connected_order_arc_459  -14
    arc_0_3_22  out_degree_726  1
    arc_0_3_22  in_degree_790  1
    arc_0_3_22  original_T_including_depot_unload_799  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_458  1
    load_0_3_22  segment_load_conservation_730  1
    load_0_3_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_460  -20
    arc_0_4_0  depot_return_or_bypass_711  1
    arc_0_4_0  out_degree_733  1
    arc_0_4_0  original_T_including_depot_unload_799  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_460  1
    load_0_4_0  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_461  -20
    arc_0_4_1  connected_order_arc_462  -14
    arc_0_4_1  in_degree_713  1
    arc_0_4_1  out_degree_733  1
    arc_0_4_1  original_T_including_depot_unload_799  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_461  1
    load_0_4_1  segment_load_conservation_716  -1
    load_0_4_1  segment_prefix_lb_717  1
    load_0_4_1  segment_prefix_ub_718  1
    load_0_4_1  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_463  -20
    arc_0_4_2  connected_order_arc_464  -14
    arc_0_4_2  in_degree_720  1
    arc_0_4_2  out_degree_733  1
    arc_0_4_2  original_T_including_depot_unload_799  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_463  1
    load_0_4_2  segment_load_conservation_723  -1
    load_0_4_2  segment_prefix_lb_724  1
    load_0_4_2  segment_prefix_ub_725  1
    load_0_4_2  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_465  -20
    arc_0_4_3  connected_order_arc_466  -14
    arc_0_4_3  in_degree_727  1
    arc_0_4_3  out_degree_733  1
    arc_0_4_3  original_T_including_depot_unload_799  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_465  1
    load_0_4_3  segment_load_conservation_730  -1
    load_0_4_3  segment_prefix_lb_731  1
    load_0_4_3  segment_prefix_ub_732  1
    load_0_4_3  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_467  -20
    arc_0_4_5  connected_order_arc_468  -14
    arc_0_4_5  out_degree_733  1
    arc_0_4_5  in_degree_741  1
    arc_0_4_5  original_T_including_depot_unload_799  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_467  1
    load_0_4_5  segment_load_conservation_737  1
    load_0_4_5  segment_load_conservation_744  -1
    load_0_4_5  segment_prefix_lb_745  1
    load_0_4_5  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_469  -20
    arc_0_4_15  connected_order_arc_470  -14
    arc_0_4_15  out_degree_733  1
    arc_0_4_15  in_degree_748  1
    arc_0_4_15  original_T_including_depot_unload_799  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_469  1
    load_0_4_15  segment_load_conservation_737  1
    load_0_4_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_471  -20
    arc_0_4_16  connected_order_arc_472  -14
    arc_0_4_16  out_degree_733  1
    arc_0_4_16  in_degree_754  1
    arc_0_4_16  original_T_including_depot_unload_799  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_471  1
    load_0_4_16  segment_load_conservation_737  1
    load_0_4_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_473  -20
    arc_0_4_17  connected_order_arc_474  -14
    arc_0_4_17  out_degree_733  1
    arc_0_4_17  in_degree_760  1
    arc_0_4_17  original_T_including_depot_unload_799  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_473  1
    load_0_4_17  segment_load_conservation_737  1
    load_0_4_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_475  -20
    arc_0_4_18  connected_order_arc_476  -14
    arc_0_4_18  out_degree_733  1
    arc_0_4_18  in_degree_766  1
    arc_0_4_18  original_T_including_depot_unload_799  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_475  1
    load_0_4_18  segment_load_conservation_737  1
    load_0_4_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_477  -20
    arc_0_4_19  connected_order_arc_478  -14
    arc_0_4_19  out_degree_733  1
    arc_0_4_19  in_degree_772  1
    arc_0_4_19  original_T_including_depot_unload_799  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_477  1
    load_0_4_19  segment_load_conservation_737  1
    load_0_4_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_479  -20
    arc_0_4_20  connected_order_arc_480  -14
    arc_0_4_20  out_degree_733  1
    arc_0_4_20  in_degree_778  1
    arc_0_4_20  original_T_including_depot_unload_799  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_479  1
    load_0_4_20  segment_load_conservation_737  1
    load_0_4_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_481  -20
    arc_0_4_21  connected_order_arc_482  -14
    arc_0_4_21  out_degree_733  1
    arc_0_4_21  in_degree_784  1
    arc_0_4_21  original_T_including_depot_unload_799  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_481  1
    load_0_4_21  segment_load_conservation_737  1
    load_0_4_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_483  -20
    arc_0_4_22  connected_order_arc_484  -14
    arc_0_4_22  out_degree_733  1
    arc_0_4_22  in_degree_790  1
    arc_0_4_22  original_T_including_depot_unload_799  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_483  1
    load_0_4_22  segment_load_conservation_737  1
    load_0_4_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_485  -20
    arc_0_5_0  depot_return_or_bypass_711  1
    arc_0_5_0  out_degree_740  1
    arc_0_5_0  original_T_including_depot_unload_799  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_485  1
    load_0_5_0  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_486  -20
    arc_0_5_1  connected_order_arc_487  -14
    arc_0_5_1  in_degree_713  1
    arc_0_5_1  out_degree_740  1
    arc_0_5_1  original_T_including_depot_unload_799  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_486  1
    load_0_5_1  segment_load_conservation_716  -1
    load_0_5_1  segment_prefix_lb_717  1
    load_0_5_1  segment_prefix_ub_718  1
    load_0_5_1  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_488  -20
    arc_0_5_2  connected_order_arc_489  -14
    arc_0_5_2  in_degree_720  1
    arc_0_5_2  out_degree_740  1
    arc_0_5_2  original_T_including_depot_unload_799  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_488  1
    load_0_5_2  segment_load_conservation_723  -1
    load_0_5_2  segment_prefix_lb_724  1
    load_0_5_2  segment_prefix_ub_725  1
    load_0_5_2  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_490  -20
    arc_0_5_3  connected_order_arc_491  -14
    arc_0_5_3  in_degree_727  1
    arc_0_5_3  out_degree_740  1
    arc_0_5_3  original_T_including_depot_unload_799  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_490  1
    load_0_5_3  segment_load_conservation_730  -1
    load_0_5_3  segment_prefix_lb_731  1
    load_0_5_3  segment_prefix_ub_732  1
    load_0_5_3  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_492  -20
    arc_0_5_4  connected_order_arc_493  -14
    arc_0_5_4  in_degree_734  1
    arc_0_5_4  out_degree_740  1
    arc_0_5_4  original_T_including_depot_unload_799  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_492  1
    load_0_5_4  segment_load_conservation_737  -1
    load_0_5_4  segment_prefix_lb_738  1
    load_0_5_4  segment_prefix_ub_739  1
    load_0_5_4  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_494  -20
    arc_0_5_15  connected_order_arc_495  -14
    arc_0_5_15  out_degree_740  1
    arc_0_5_15  in_degree_748  1
    arc_0_5_15  original_T_including_depot_unload_799  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_494  1
    load_0_5_15  segment_load_conservation_744  1
    load_0_5_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_496  -20
    arc_0_5_16  connected_order_arc_497  -14
    arc_0_5_16  out_degree_740  1
    arc_0_5_16  in_degree_754  1
    arc_0_5_16  original_T_including_depot_unload_799  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_496  1
    load_0_5_16  segment_load_conservation_744  1
    load_0_5_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_498  -20
    arc_0_5_17  connected_order_arc_499  -14
    arc_0_5_17  out_degree_740  1
    arc_0_5_17  in_degree_760  1
    arc_0_5_17  original_T_including_depot_unload_799  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_498  1
    load_0_5_17  segment_load_conservation_744  1
    load_0_5_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_500  -20
    arc_0_5_18  connected_order_arc_501  -14
    arc_0_5_18  out_degree_740  1
    arc_0_5_18  in_degree_766  1
    arc_0_5_18  original_T_including_depot_unload_799  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_500  1
    load_0_5_18  segment_load_conservation_744  1
    load_0_5_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_502  -20
    arc_0_5_19  connected_order_arc_503  -14
    arc_0_5_19  out_degree_740  1
    arc_0_5_19  in_degree_772  1
    arc_0_5_19  original_T_including_depot_unload_799  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_502  1
    load_0_5_19  segment_load_conservation_744  1
    load_0_5_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_504  -20
    arc_0_5_20  connected_order_arc_505  -14
    arc_0_5_20  out_degree_740  1
    arc_0_5_20  in_degree_778  1
    arc_0_5_20  original_T_including_depot_unload_799  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_504  1
    load_0_5_20  segment_load_conservation_744  1
    load_0_5_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_506  -20
    arc_0_5_21  connected_order_arc_507  -14
    arc_0_5_21  out_degree_740  1
    arc_0_5_21  in_degree_784  1
    arc_0_5_21  original_T_including_depot_unload_799  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_506  1
    load_0_5_21  segment_load_conservation_744  1
    load_0_5_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_508  -20
    arc_0_5_22  connected_order_arc_509  -14
    arc_0_5_22  out_degree_740  1
    arc_0_5_22  in_degree_790  1
    arc_0_5_22  original_T_including_depot_unload_799  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_508  1
    load_0_5_22  segment_load_conservation_744  1
    load_0_5_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_510  -20
    arc_0_15_0  depot_return_or_bypass_711  1
    arc_0_15_0  out_degree_747  1
    arc_0_15_0  original_T_including_depot_unload_799  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_510  1
    load_0_15_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_511  -20
    arc_0_15_1  connected_order_arc_512  -14
    arc_0_15_1  in_degree_713  1
    arc_0_15_1  out_degree_747  1
    arc_0_15_1  original_T_including_depot_unload_799  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_511  1
    load_0_15_1  segment_load_conservation_716  -1
    load_0_15_1  segment_prefix_lb_717  1
    load_0_15_1  segment_prefix_ub_718  1
    load_0_15_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_513  -20
    arc_0_15_2  connected_order_arc_514  -14
    arc_0_15_2  in_degree_720  1
    arc_0_15_2  out_degree_747  1
    arc_0_15_2  original_T_including_depot_unload_799  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_513  1
    load_0_15_2  segment_load_conservation_723  -1
    load_0_15_2  segment_prefix_lb_724  1
    load_0_15_2  segment_prefix_ub_725  1
    load_0_15_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_515  -20
    arc_0_15_3  connected_order_arc_516  -14
    arc_0_15_3  in_degree_727  1
    arc_0_15_3  out_degree_747  1
    arc_0_15_3  original_T_including_depot_unload_799  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_515  1
    load_0_15_3  segment_load_conservation_730  -1
    load_0_15_3  segment_prefix_lb_731  1
    load_0_15_3  segment_prefix_ub_732  1
    load_0_15_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_517  -20
    arc_0_15_4  connected_order_arc_518  -14
    arc_0_15_4  in_degree_734  1
    arc_0_15_4  out_degree_747  1
    arc_0_15_4  original_T_including_depot_unload_799  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_517  1
    load_0_15_4  segment_load_conservation_737  -1
    load_0_15_4  segment_prefix_lb_738  1
    load_0_15_4  segment_prefix_ub_739  1
    load_0_15_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_519  -20
    arc_0_15_5  connected_order_arc_520  -14
    arc_0_15_5  in_degree_741  1
    arc_0_15_5  out_degree_747  1
    arc_0_15_5  original_T_including_depot_unload_799  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_519  1
    load_0_15_5  segment_load_conservation_744  -1
    load_0_15_5  segment_prefix_lb_745  1
    load_0_15_5  segment_prefix_ub_746  1
    load_0_15_5  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_521  -20
    arc_0_15_16  connected_order_arc_522  -14
    arc_0_15_16  out_degree_747  1
    arc_0_15_16  in_degree_754  1
    arc_0_15_16  original_T_including_depot_unload_799  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_521  1
    load_0_15_16  free_load_conservation_752  1
    load_0_15_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_523  -20
    arc_0_15_17  connected_order_arc_524  -14
    arc_0_15_17  out_degree_747  1
    arc_0_15_17  in_degree_760  1
    arc_0_15_17  original_T_including_depot_unload_799  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_523  1
    load_0_15_17  free_load_conservation_752  1
    load_0_15_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_525  -20
    arc_0_15_18  connected_order_arc_526  -14
    arc_0_15_18  out_degree_747  1
    arc_0_15_18  in_degree_766  1
    arc_0_15_18  original_T_including_depot_unload_799  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_525  1
    load_0_15_18  free_load_conservation_752  1
    load_0_15_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_527  -20
    arc_0_15_19  connected_order_arc_528  -14
    arc_0_15_19  out_degree_747  1
    arc_0_15_19  in_degree_772  1
    arc_0_15_19  original_T_including_depot_unload_799  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_527  1
    load_0_15_19  free_load_conservation_752  1
    load_0_15_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_529  -20
    arc_0_15_20  connected_order_arc_530  -14
    arc_0_15_20  out_degree_747  1
    arc_0_15_20  in_degree_778  1
    arc_0_15_20  original_T_including_depot_unload_799  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_529  1
    load_0_15_20  free_load_conservation_752  1
    load_0_15_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_531  -20
    arc_0_15_21  connected_order_arc_532  -14
    arc_0_15_21  out_degree_747  1
    arc_0_15_21  in_degree_784  1
    arc_0_15_21  original_T_including_depot_unload_799  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_531  1
    load_0_15_21  free_load_conservation_752  1
    load_0_15_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_533  -20
    arc_0_15_22  connected_order_arc_534  -14
    arc_0_15_22  out_degree_747  1
    arc_0_15_22  in_degree_790  1
    arc_0_15_22  original_T_including_depot_unload_799  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_533  1
    load_0_15_22  free_load_conservation_752  1
    load_0_15_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_535  -20
    arc_0_16_0  depot_return_or_bypass_711  1
    arc_0_16_0  out_degree_753  1
    arc_0_16_0  original_T_including_depot_unload_799  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_535  1
    load_0_16_0  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_536  -20
    arc_0_16_1  connected_order_arc_537  -14
    arc_0_16_1  in_degree_713  1
    arc_0_16_1  out_degree_753  1
    arc_0_16_1  original_T_including_depot_unload_799  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_536  1
    load_0_16_1  segment_load_conservation_716  -1
    load_0_16_1  segment_prefix_lb_717  1
    load_0_16_1  segment_prefix_ub_718  1
    load_0_16_1  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_538  -20
    arc_0_16_2  connected_order_arc_539  -14
    arc_0_16_2  in_degree_720  1
    arc_0_16_2  out_degree_753  1
    arc_0_16_2  original_T_including_depot_unload_799  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_538  1
    load_0_16_2  segment_load_conservation_723  -1
    load_0_16_2  segment_prefix_lb_724  1
    load_0_16_2  segment_prefix_ub_725  1
    load_0_16_2  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_540  -20
    arc_0_16_3  connected_order_arc_541  -14
    arc_0_16_3  in_degree_727  1
    arc_0_16_3  out_degree_753  1
    arc_0_16_3  original_T_including_depot_unload_799  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_540  1
    load_0_16_3  segment_load_conservation_730  -1
    load_0_16_3  segment_prefix_lb_731  1
    load_0_16_3  segment_prefix_ub_732  1
    load_0_16_3  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_542  -20
    arc_0_16_4  connected_order_arc_543  -14
    arc_0_16_4  in_degree_734  1
    arc_0_16_4  out_degree_753  1
    arc_0_16_4  original_T_including_depot_unload_799  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_542  1
    load_0_16_4  segment_load_conservation_737  -1
    load_0_16_4  segment_prefix_lb_738  1
    load_0_16_4  segment_prefix_ub_739  1
    load_0_16_4  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_544  -20
    arc_0_16_5  connected_order_arc_545  -14
    arc_0_16_5  in_degree_741  1
    arc_0_16_5  out_degree_753  1
    arc_0_16_5  original_T_including_depot_unload_799  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_544  1
    load_0_16_5  segment_load_conservation_744  -1
    load_0_16_5  segment_prefix_lb_745  1
    load_0_16_5  segment_prefix_ub_746  1
    load_0_16_5  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_546  -20
    arc_0_16_15  connected_order_arc_547  -14
    arc_0_16_15  in_degree_748  1
    arc_0_16_15  out_degree_753  1
    arc_0_16_15  original_T_including_depot_unload_799  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_546  1
    load_0_16_15  free_load_conservation_752  -1
    load_0_16_15  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_548  -20
    arc_0_16_17  connected_order_arc_549  -14
    arc_0_16_17  out_degree_753  1
    arc_0_16_17  in_degree_760  1
    arc_0_16_17  original_T_including_depot_unload_799  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_548  1
    load_0_16_17  free_load_conservation_758  1
    load_0_16_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_550  -20
    arc_0_16_18  connected_order_arc_551  -14
    arc_0_16_18  out_degree_753  1
    arc_0_16_18  in_degree_766  1
    arc_0_16_18  original_T_including_depot_unload_799  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_550  1
    load_0_16_18  free_load_conservation_758  1
    load_0_16_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_552  -20
    arc_0_16_19  connected_order_arc_553  -14
    arc_0_16_19  out_degree_753  1
    arc_0_16_19  in_degree_772  1
    arc_0_16_19  original_T_including_depot_unload_799  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_552  1
    load_0_16_19  free_load_conservation_758  1
    load_0_16_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_554  -20
    arc_0_16_20  connected_order_arc_555  -14
    arc_0_16_20  out_degree_753  1
    arc_0_16_20  in_degree_778  1
    arc_0_16_20  original_T_including_depot_unload_799  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_554  1
    load_0_16_20  free_load_conservation_758  1
    load_0_16_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_556  -20
    arc_0_16_21  connected_order_arc_557  -14
    arc_0_16_21  out_degree_753  1
    arc_0_16_21  in_degree_784  1
    arc_0_16_21  original_T_including_depot_unload_799  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_556  1
    load_0_16_21  free_load_conservation_758  1
    load_0_16_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_558  -20
    arc_0_16_22  connected_order_arc_559  -14
    arc_0_16_22  out_degree_753  1
    arc_0_16_22  in_degree_790  1
    arc_0_16_22  original_T_including_depot_unload_799  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_558  1
    load_0_16_22  free_load_conservation_758  1
    load_0_16_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_560  -20
    arc_0_17_0  depot_return_or_bypass_711  1
    arc_0_17_0  out_degree_759  1
    arc_0_17_0  original_T_including_depot_unload_799  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_560  1
    load_0_17_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_561  -20
    arc_0_17_1  connected_order_arc_562  -14
    arc_0_17_1  in_degree_713  1
    arc_0_17_1  out_degree_759  1
    arc_0_17_1  original_T_including_depot_unload_799  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_561  1
    load_0_17_1  segment_load_conservation_716  -1
    load_0_17_1  segment_prefix_lb_717  1
    load_0_17_1  segment_prefix_ub_718  1
    load_0_17_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_563  -20
    arc_0_17_2  connected_order_arc_564  -14
    arc_0_17_2  in_degree_720  1
    arc_0_17_2  out_degree_759  1
    arc_0_17_2  original_T_including_depot_unload_799  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_563  1
    load_0_17_2  segment_load_conservation_723  -1
    load_0_17_2  segment_prefix_lb_724  1
    load_0_17_2  segment_prefix_ub_725  1
    load_0_17_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_565  -20
    arc_0_17_3  connected_order_arc_566  -14
    arc_0_17_3  in_degree_727  1
    arc_0_17_3  out_degree_759  1
    arc_0_17_3  original_T_including_depot_unload_799  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_565  1
    load_0_17_3  segment_load_conservation_730  -1
    load_0_17_3  segment_prefix_lb_731  1
    load_0_17_3  segment_prefix_ub_732  1
    load_0_17_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_567  -20
    arc_0_17_4  connected_order_arc_568  -14
    arc_0_17_4  in_degree_734  1
    arc_0_17_4  out_degree_759  1
    arc_0_17_4  original_T_including_depot_unload_799  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_567  1
    load_0_17_4  segment_load_conservation_737  -1
    load_0_17_4  segment_prefix_lb_738  1
    load_0_17_4  segment_prefix_ub_739  1
    load_0_17_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_569  -20
    arc_0_17_5  connected_order_arc_570  -14
    arc_0_17_5  in_degree_741  1
    arc_0_17_5  out_degree_759  1
    arc_0_17_5  original_T_including_depot_unload_799  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_569  1
    load_0_17_5  segment_load_conservation_744  -1
    load_0_17_5  segment_prefix_lb_745  1
    load_0_17_5  segment_prefix_ub_746  1
    load_0_17_5  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_571  -20
    arc_0_17_15  connected_order_arc_572  -14
    arc_0_17_15  in_degree_748  1
    arc_0_17_15  out_degree_759  1
    arc_0_17_15  original_T_including_depot_unload_799  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_571  1
    load_0_17_15  free_load_conservation_752  -1
    load_0_17_15  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_573  -20
    arc_0_17_16  connected_order_arc_574  -14
    arc_0_17_16  in_degree_754  1
    arc_0_17_16  out_degree_759  1
    arc_0_17_16  original_T_including_depot_unload_799  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_573  1
    load_0_17_16  free_load_conservation_758  -1
    load_0_17_16  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_575  -20
    arc_0_17_18  connected_order_arc_576  -14
    arc_0_17_18  out_degree_759  1
    arc_0_17_18  in_degree_766  1
    arc_0_17_18  original_T_including_depot_unload_799  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_575  1
    load_0_17_18  free_load_conservation_764  1
    load_0_17_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_577  -20
    arc_0_17_19  connected_order_arc_578  -14
    arc_0_17_19  out_degree_759  1
    arc_0_17_19  in_degree_772  1
    arc_0_17_19  original_T_including_depot_unload_799  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_577  1
    load_0_17_19  free_load_conservation_764  1
    load_0_17_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_579  -20
    arc_0_17_20  connected_order_arc_580  -14
    arc_0_17_20  out_degree_759  1
    arc_0_17_20  in_degree_778  1
    arc_0_17_20  original_T_including_depot_unload_799  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_579  1
    load_0_17_20  free_load_conservation_764  1
    load_0_17_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_581  -20
    arc_0_17_21  connected_order_arc_582  -14
    arc_0_17_21  out_degree_759  1
    arc_0_17_21  in_degree_784  1
    arc_0_17_21  original_T_including_depot_unload_799  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_581  1
    load_0_17_21  free_load_conservation_764  1
    load_0_17_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_583  -20
    arc_0_17_22  connected_order_arc_584  -14
    arc_0_17_22  out_degree_759  1
    arc_0_17_22  in_degree_790  1
    arc_0_17_22  original_T_including_depot_unload_799  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_583  1
    load_0_17_22  free_load_conservation_764  1
    load_0_17_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_585  -20
    arc_0_18_0  depot_return_or_bypass_711  1
    arc_0_18_0  out_degree_765  1
    arc_0_18_0  original_T_including_depot_unload_799  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_585  1
    load_0_18_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_586  -20
    arc_0_18_1  connected_order_arc_587  -14
    arc_0_18_1  in_degree_713  1
    arc_0_18_1  out_degree_765  1
    arc_0_18_1  original_T_including_depot_unload_799  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_586  1
    load_0_18_1  segment_load_conservation_716  -1
    load_0_18_1  segment_prefix_lb_717  1
    load_0_18_1  segment_prefix_ub_718  1
    load_0_18_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_588  -20
    arc_0_18_2  connected_order_arc_589  -14
    arc_0_18_2  in_degree_720  1
    arc_0_18_2  out_degree_765  1
    arc_0_18_2  original_T_including_depot_unload_799  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_588  1
    load_0_18_2  segment_load_conservation_723  -1
    load_0_18_2  segment_prefix_lb_724  1
    load_0_18_2  segment_prefix_ub_725  1
    load_0_18_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_590  -20
    arc_0_18_3  connected_order_arc_591  -14
    arc_0_18_3  in_degree_727  1
    arc_0_18_3  out_degree_765  1
    arc_0_18_3  original_T_including_depot_unload_799  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_590  1
    load_0_18_3  segment_load_conservation_730  -1
    load_0_18_3  segment_prefix_lb_731  1
    load_0_18_3  segment_prefix_ub_732  1
    load_0_18_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_592  -20
    arc_0_18_4  connected_order_arc_593  -14
    arc_0_18_4  in_degree_734  1
    arc_0_18_4  out_degree_765  1
    arc_0_18_4  original_T_including_depot_unload_799  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_592  1
    load_0_18_4  segment_load_conservation_737  -1
    load_0_18_4  segment_prefix_lb_738  1
    load_0_18_4  segment_prefix_ub_739  1
    load_0_18_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_594  -20
    arc_0_18_5  connected_order_arc_595  -14
    arc_0_18_5  in_degree_741  1
    arc_0_18_5  out_degree_765  1
    arc_0_18_5  original_T_including_depot_unload_799  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_594  1
    load_0_18_5  segment_load_conservation_744  -1
    load_0_18_5  segment_prefix_lb_745  1
    load_0_18_5  segment_prefix_ub_746  1
    load_0_18_5  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_596  -20
    arc_0_18_15  connected_order_arc_597  -14
    arc_0_18_15  in_degree_748  1
    arc_0_18_15  out_degree_765  1
    arc_0_18_15  original_T_including_depot_unload_799  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_596  1
    load_0_18_15  free_load_conservation_752  -1
    load_0_18_15  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_598  -20
    arc_0_18_16  connected_order_arc_599  -14
    arc_0_18_16  in_degree_754  1
    arc_0_18_16  out_degree_765  1
    arc_0_18_16  original_T_including_depot_unload_799  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_598  1
    load_0_18_16  free_load_conservation_758  -1
    load_0_18_16  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_600  -20
    arc_0_18_17  connected_order_arc_601  -14
    arc_0_18_17  in_degree_760  1
    arc_0_18_17  out_degree_765  1
    arc_0_18_17  original_T_including_depot_unload_799  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_600  1
    load_0_18_17  free_load_conservation_764  -1
    load_0_18_17  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_602  -20
    arc_0_18_19  connected_order_arc_603  -14
    arc_0_18_19  out_degree_765  1
    arc_0_18_19  in_degree_772  1
    arc_0_18_19  original_T_including_depot_unload_799  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_602  1
    load_0_18_19  free_load_conservation_770  1
    load_0_18_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_604  -20
    arc_0_18_20  connected_order_arc_605  -14
    arc_0_18_20  out_degree_765  1
    arc_0_18_20  in_degree_778  1
    arc_0_18_20  original_T_including_depot_unload_799  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_604  1
    load_0_18_20  free_load_conservation_770  1
    load_0_18_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_606  -20
    arc_0_18_21  connected_order_arc_607  -14
    arc_0_18_21  out_degree_765  1
    arc_0_18_21  in_degree_784  1
    arc_0_18_21  original_T_including_depot_unload_799  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_606  1
    load_0_18_21  free_load_conservation_770  1
    load_0_18_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_608  -20
    arc_0_18_22  connected_order_arc_609  -14
    arc_0_18_22  out_degree_765  1
    arc_0_18_22  in_degree_790  1
    arc_0_18_22  original_T_including_depot_unload_799  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_608  1
    load_0_18_22  free_load_conservation_770  1
    load_0_18_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_610  -20
    arc_0_19_0  depot_return_or_bypass_711  1
    arc_0_19_0  out_degree_771  1
    arc_0_19_0  original_T_including_depot_unload_799  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_610  1
    load_0_19_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_611  -20
    arc_0_19_1  connected_order_arc_612  -14
    arc_0_19_1  in_degree_713  1
    arc_0_19_1  out_degree_771  1
    arc_0_19_1  original_T_including_depot_unload_799  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_611  1
    load_0_19_1  segment_load_conservation_716  -1
    load_0_19_1  segment_prefix_lb_717  1
    load_0_19_1  segment_prefix_ub_718  1
    load_0_19_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_613  -20
    arc_0_19_2  connected_order_arc_614  -14
    arc_0_19_2  in_degree_720  1
    arc_0_19_2  out_degree_771  1
    arc_0_19_2  original_T_including_depot_unload_799  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_613  1
    load_0_19_2  segment_load_conservation_723  -1
    load_0_19_2  segment_prefix_lb_724  1
    load_0_19_2  segment_prefix_ub_725  1
    load_0_19_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_615  -20
    arc_0_19_3  connected_order_arc_616  -14
    arc_0_19_3  in_degree_727  1
    arc_0_19_3  out_degree_771  1
    arc_0_19_3  original_T_including_depot_unload_799  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_615  1
    load_0_19_3  segment_load_conservation_730  -1
    load_0_19_3  segment_prefix_lb_731  1
    load_0_19_3  segment_prefix_ub_732  1
    load_0_19_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_617  -20
    arc_0_19_4  connected_order_arc_618  -14
    arc_0_19_4  in_degree_734  1
    arc_0_19_4  out_degree_771  1
    arc_0_19_4  original_T_including_depot_unload_799  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_617  1
    load_0_19_4  segment_load_conservation_737  -1
    load_0_19_4  segment_prefix_lb_738  1
    load_0_19_4  segment_prefix_ub_739  1
    load_0_19_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_619  -20
    arc_0_19_5  connected_order_arc_620  -14
    arc_0_19_5  in_degree_741  1
    arc_0_19_5  out_degree_771  1
    arc_0_19_5  original_T_including_depot_unload_799  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_619  1
    load_0_19_5  segment_load_conservation_744  -1
    load_0_19_5  segment_prefix_lb_745  1
    load_0_19_5  segment_prefix_ub_746  1
    load_0_19_5  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_621  -20
    arc_0_19_15  connected_order_arc_622  -14
    arc_0_19_15  in_degree_748  1
    arc_0_19_15  out_degree_771  1
    arc_0_19_15  original_T_including_depot_unload_799  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_621  1
    load_0_19_15  free_load_conservation_752  -1
    load_0_19_15  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_623  -20
    arc_0_19_16  connected_order_arc_624  -14
    arc_0_19_16  in_degree_754  1
    arc_0_19_16  out_degree_771  1
    arc_0_19_16  original_T_including_depot_unload_799  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_623  1
    load_0_19_16  free_load_conservation_758  -1
    load_0_19_16  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_625  -20
    arc_0_19_17  connected_order_arc_626  -14
    arc_0_19_17  in_degree_760  1
    arc_0_19_17  out_degree_771  1
    arc_0_19_17  original_T_including_depot_unload_799  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_625  1
    load_0_19_17  free_load_conservation_764  -1
    load_0_19_17  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_627  -20
    arc_0_19_18  connected_order_arc_628  -14
    arc_0_19_18  in_degree_766  1
    arc_0_19_18  out_degree_771  1
    arc_0_19_18  original_T_including_depot_unload_799  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_627  1
    load_0_19_18  free_load_conservation_770  -1
    load_0_19_18  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_629  -20
    arc_0_19_20  connected_order_arc_630  -14
    arc_0_19_20  out_degree_771  1
    arc_0_19_20  in_degree_778  1
    arc_0_19_20  original_T_including_depot_unload_799  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_629  1
    load_0_19_20  free_load_conservation_776  1
    load_0_19_20  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_631  -20
    arc_0_19_21  connected_order_arc_632  -14
    arc_0_19_21  out_degree_771  1
    arc_0_19_21  in_degree_784  1
    arc_0_19_21  original_T_including_depot_unload_799  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_631  1
    load_0_19_21  free_load_conservation_776  1
    load_0_19_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_633  -20
    arc_0_19_22  connected_order_arc_634  -14
    arc_0_19_22  out_degree_771  1
    arc_0_19_22  in_degree_790  1
    arc_0_19_22  original_T_including_depot_unload_799  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_633  1
    load_0_19_22  free_load_conservation_776  1
    load_0_19_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_635  -20
    arc_0_20_0  depot_return_or_bypass_711  1
    arc_0_20_0  out_degree_777  1
    arc_0_20_0  original_T_including_depot_unload_799  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_635  1
    load_0_20_0  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_636  -20
    arc_0_20_1  connected_order_arc_637  -14
    arc_0_20_1  in_degree_713  1
    arc_0_20_1  out_degree_777  1
    arc_0_20_1  original_T_including_depot_unload_799  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_636  1
    load_0_20_1  segment_load_conservation_716  -1
    load_0_20_1  segment_prefix_lb_717  1
    load_0_20_1  segment_prefix_ub_718  1
    load_0_20_1  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_638  -20
    arc_0_20_2  connected_order_arc_639  -14
    arc_0_20_2  in_degree_720  1
    arc_0_20_2  out_degree_777  1
    arc_0_20_2  original_T_including_depot_unload_799  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_638  1
    load_0_20_2  segment_load_conservation_723  -1
    load_0_20_2  segment_prefix_lb_724  1
    load_0_20_2  segment_prefix_ub_725  1
    load_0_20_2  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_640  -20
    arc_0_20_3  connected_order_arc_641  -14
    arc_0_20_3  in_degree_727  1
    arc_0_20_3  out_degree_777  1
    arc_0_20_3  original_T_including_depot_unload_799  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_640  1
    load_0_20_3  segment_load_conservation_730  -1
    load_0_20_3  segment_prefix_lb_731  1
    load_0_20_3  segment_prefix_ub_732  1
    load_0_20_3  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_642  -20
    arc_0_20_4  connected_order_arc_643  -14
    arc_0_20_4  in_degree_734  1
    arc_0_20_4  out_degree_777  1
    arc_0_20_4  original_T_including_depot_unload_799  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_642  1
    load_0_20_4  segment_load_conservation_737  -1
    load_0_20_4  segment_prefix_lb_738  1
    load_0_20_4  segment_prefix_ub_739  1
    load_0_20_4  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_644  -20
    arc_0_20_5  connected_order_arc_645  -14
    arc_0_20_5  in_degree_741  1
    arc_0_20_5  out_degree_777  1
    arc_0_20_5  original_T_including_depot_unload_799  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_644  1
    load_0_20_5  segment_load_conservation_744  -1
    load_0_20_5  segment_prefix_lb_745  1
    load_0_20_5  segment_prefix_ub_746  1
    load_0_20_5  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_646  -20
    arc_0_20_15  connected_order_arc_647  -14
    arc_0_20_15  in_degree_748  1
    arc_0_20_15  out_degree_777  1
    arc_0_20_15  original_T_including_depot_unload_799  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_646  1
    load_0_20_15  free_load_conservation_752  -1
    load_0_20_15  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_648  -20
    arc_0_20_16  connected_order_arc_649  -14
    arc_0_20_16  in_degree_754  1
    arc_0_20_16  out_degree_777  1
    arc_0_20_16  original_T_including_depot_unload_799  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_648  1
    load_0_20_16  free_load_conservation_758  -1
    load_0_20_16  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_650  -20
    arc_0_20_17  connected_order_arc_651  -14
    arc_0_20_17  in_degree_760  1
    arc_0_20_17  out_degree_777  1
    arc_0_20_17  original_T_including_depot_unload_799  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_650  1
    load_0_20_17  free_load_conservation_764  -1
    load_0_20_17  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_652  -20
    arc_0_20_18  connected_order_arc_653  -14
    arc_0_20_18  in_degree_766  1
    arc_0_20_18  out_degree_777  1
    arc_0_20_18  original_T_including_depot_unload_799  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_652  1
    load_0_20_18  free_load_conservation_770  -1
    load_0_20_18  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_654  -20
    arc_0_20_19  connected_order_arc_655  -14
    arc_0_20_19  in_degree_772  1
    arc_0_20_19  out_degree_777  1
    arc_0_20_19  original_T_including_depot_unload_799  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_654  1
    load_0_20_19  free_load_conservation_776  -1
    load_0_20_19  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_656  -20
    arc_0_20_21  connected_order_arc_657  -14
    arc_0_20_21  out_degree_777  1
    arc_0_20_21  in_degree_784  1
    arc_0_20_21  original_T_including_depot_unload_799  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_656  1
    load_0_20_21  free_load_conservation_782  1
    load_0_20_21  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_658  -20
    arc_0_20_22  connected_order_arc_659  -14
    arc_0_20_22  out_degree_777  1
    arc_0_20_22  in_degree_790  1
    arc_0_20_22  original_T_including_depot_unload_799  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_658  1
    load_0_20_22  free_load_conservation_782  1
    load_0_20_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_660  -20
    arc_0_21_0  depot_return_or_bypass_711  1
    arc_0_21_0  out_degree_783  1
    arc_0_21_0  original_T_including_depot_unload_799  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_660  1
    load_0_21_0  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_661  -20
    arc_0_21_1  connected_order_arc_662  -14
    arc_0_21_1  in_degree_713  1
    arc_0_21_1  out_degree_783  1
    arc_0_21_1  original_T_including_depot_unload_799  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_661  1
    load_0_21_1  segment_load_conservation_716  -1
    load_0_21_1  segment_prefix_lb_717  1
    load_0_21_1  segment_prefix_ub_718  1
    load_0_21_1  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_663  -20
    arc_0_21_2  connected_order_arc_664  -14
    arc_0_21_2  in_degree_720  1
    arc_0_21_2  out_degree_783  1
    arc_0_21_2  original_T_including_depot_unload_799  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_663  1
    load_0_21_2  segment_load_conservation_723  -1
    load_0_21_2  segment_prefix_lb_724  1
    load_0_21_2  segment_prefix_ub_725  1
    load_0_21_2  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_665  -20
    arc_0_21_3  connected_order_arc_666  -14
    arc_0_21_3  in_degree_727  1
    arc_0_21_3  out_degree_783  1
    arc_0_21_3  original_T_including_depot_unload_799  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_665  1
    load_0_21_3  segment_load_conservation_730  -1
    load_0_21_3  segment_prefix_lb_731  1
    load_0_21_3  segment_prefix_ub_732  1
    load_0_21_3  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_667  -20
    arc_0_21_4  connected_order_arc_668  -14
    arc_0_21_4  in_degree_734  1
    arc_0_21_4  out_degree_783  1
    arc_0_21_4  original_T_including_depot_unload_799  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_667  1
    load_0_21_4  segment_load_conservation_737  -1
    load_0_21_4  segment_prefix_lb_738  1
    load_0_21_4  segment_prefix_ub_739  1
    load_0_21_4  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_669  -20
    arc_0_21_5  connected_order_arc_670  -14
    arc_0_21_5  in_degree_741  1
    arc_0_21_5  out_degree_783  1
    arc_0_21_5  original_T_including_depot_unload_799  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_669  1
    load_0_21_5  segment_load_conservation_744  -1
    load_0_21_5  segment_prefix_lb_745  1
    load_0_21_5  segment_prefix_ub_746  1
    load_0_21_5  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_671  -20
    arc_0_21_15  connected_order_arc_672  -14
    arc_0_21_15  in_degree_748  1
    arc_0_21_15  out_degree_783  1
    arc_0_21_15  original_T_including_depot_unload_799  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_671  1
    load_0_21_15  free_load_conservation_752  -1
    load_0_21_15  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_673  -20
    arc_0_21_16  connected_order_arc_674  -14
    arc_0_21_16  in_degree_754  1
    arc_0_21_16  out_degree_783  1
    arc_0_21_16  original_T_including_depot_unload_799  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_673  1
    load_0_21_16  free_load_conservation_758  -1
    load_0_21_16  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_675  -20
    arc_0_21_17  connected_order_arc_676  -14
    arc_0_21_17  in_degree_760  1
    arc_0_21_17  out_degree_783  1
    arc_0_21_17  original_T_including_depot_unload_799  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_675  1
    load_0_21_17  free_load_conservation_764  -1
    load_0_21_17  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_677  -20
    arc_0_21_18  connected_order_arc_678  -14
    arc_0_21_18  in_degree_766  1
    arc_0_21_18  out_degree_783  1
    arc_0_21_18  original_T_including_depot_unload_799  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_677  1
    load_0_21_18  free_load_conservation_770  -1
    load_0_21_18  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_679  -20
    arc_0_21_19  connected_order_arc_680  -14
    arc_0_21_19  in_degree_772  1
    arc_0_21_19  out_degree_783  1
    arc_0_21_19  original_T_including_depot_unload_799  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_679  1
    load_0_21_19  free_load_conservation_776  -1
    load_0_21_19  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_681  -20
    arc_0_21_20  connected_order_arc_682  -14
    arc_0_21_20  in_degree_778  1
    arc_0_21_20  out_degree_783  1
    arc_0_21_20  original_T_including_depot_unload_799  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_681  1
    load_0_21_20  free_load_conservation_782  -1
    load_0_21_20  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_683  -20
    arc_0_21_22  connected_order_arc_684  -14
    arc_0_21_22  out_degree_783  1
    arc_0_21_22  in_degree_790  1
    arc_0_21_22  original_T_including_depot_unload_799  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_683  1
    load_0_21_22  free_load_conservation_788  1
    load_0_21_22  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_685  -20
    arc_0_22_0  depot_return_or_bypass_711  1
    arc_0_22_0  out_degree_789  1
    arc_0_22_0  original_T_including_depot_unload_799  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_685  1
    load_0_22_0  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_686  -20
    arc_0_22_1  connected_order_arc_687  -14
    arc_0_22_1  in_degree_713  1
    arc_0_22_1  out_degree_789  1
    arc_0_22_1  original_T_including_depot_unload_799  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_686  1
    load_0_22_1  segment_load_conservation_716  -1
    load_0_22_1  segment_prefix_lb_717  1
    load_0_22_1  segment_prefix_ub_718  1
    load_0_22_1  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_688  -20
    arc_0_22_2  connected_order_arc_689  -14
    arc_0_22_2  in_degree_720  1
    arc_0_22_2  out_degree_789  1
    arc_0_22_2  original_T_including_depot_unload_799  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_688  1
    load_0_22_2  segment_load_conservation_723  -1
    load_0_22_2  segment_prefix_lb_724  1
    load_0_22_2  segment_prefix_ub_725  1
    load_0_22_2  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_690  -20
    arc_0_22_3  connected_order_arc_691  -14
    arc_0_22_3  in_degree_727  1
    arc_0_22_3  out_degree_789  1
    arc_0_22_3  original_T_including_depot_unload_799  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_690  1
    load_0_22_3  segment_load_conservation_730  -1
    load_0_22_3  segment_prefix_lb_731  1
    load_0_22_3  segment_prefix_ub_732  1
    load_0_22_3  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_692  -20
    arc_0_22_4  connected_order_arc_693  -14
    arc_0_22_4  in_degree_734  1
    arc_0_22_4  out_degree_789  1
    arc_0_22_4  original_T_including_depot_unload_799  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_692  1
    load_0_22_4  segment_load_conservation_737  -1
    load_0_22_4  segment_prefix_lb_738  1
    load_0_22_4  segment_prefix_ub_739  1
    load_0_22_4  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_694  -20
    arc_0_22_5  connected_order_arc_695  -14
    arc_0_22_5  in_degree_741  1
    arc_0_22_5  out_degree_789  1
    arc_0_22_5  original_T_including_depot_unload_799  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_694  1
    load_0_22_5  segment_load_conservation_744  -1
    load_0_22_5  segment_prefix_lb_745  1
    load_0_22_5  segment_prefix_ub_746  1
    load_0_22_5  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_696  -20
    arc_0_22_15  connected_order_arc_697  -14
    arc_0_22_15  in_degree_748  1
    arc_0_22_15  out_degree_789  1
    arc_0_22_15  original_T_including_depot_unload_799  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_696  1
    load_0_22_15  free_load_conservation_752  -1
    load_0_22_15  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_698  -20
    arc_0_22_16  connected_order_arc_699  -14
    arc_0_22_16  in_degree_754  1
    arc_0_22_16  out_degree_789  1
    arc_0_22_16  original_T_including_depot_unload_799  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_698  1
    load_0_22_16  free_load_conservation_758  -1
    load_0_22_16  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_700  -20
    arc_0_22_17  connected_order_arc_701  -14
    arc_0_22_17  in_degree_760  1
    arc_0_22_17  out_degree_789  1
    arc_0_22_17  original_T_including_depot_unload_799  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_700  1
    load_0_22_17  free_load_conservation_764  -1
    load_0_22_17  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_702  -20
    arc_0_22_18  connected_order_arc_703  -14
    arc_0_22_18  in_degree_766  1
    arc_0_22_18  out_degree_789  1
    arc_0_22_18  original_T_including_depot_unload_799  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_702  1
    load_0_22_18  free_load_conservation_770  -1
    load_0_22_18  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_704  -20
    arc_0_22_19  connected_order_arc_705  -14
    arc_0_22_19  in_degree_772  1
    arc_0_22_19  out_degree_789  1
    arc_0_22_19  original_T_including_depot_unload_799  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_704  1
    load_0_22_19  free_load_conservation_776  -1
    load_0_22_19  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_706  -20
    arc_0_22_20  connected_order_arc_707  -14
    arc_0_22_20  in_degree_778  1
    arc_0_22_20  out_degree_789  1
    arc_0_22_20  original_T_including_depot_unload_799  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_706  1
    load_0_22_20  free_load_conservation_782  -1
    load_0_22_20  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_708  -20
    arc_0_22_21  connected_order_arc_709  -14
    arc_0_22_21  in_degree_784  1
    arc_0_22_21  out_degree_789  1
    arc_0_22_21  original_T_including_depot_unload_799  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_708  1
    load_0_22_21  free_load_conservation_788  -1
    load_0_22_21  free_load_conservation_794  1
    visit_1_6  out_degree_1141  -1
    visit_1_6  in_degree_1142  -1
    visit_1_6  order_active_lb_1143  -1
    visit_1_6  order_active_ub_1144  -13
    order_1_6  connected_order_arc_816  -1
    order_1_6  connected_order_arc_818  -1
    order_1_6  connected_order_arc_820  -1
    order_1_6  connected_order_arc_822  -1
    order_1_6  connected_order_arc_824  -1
    order_1_6  connected_order_arc_826  -1
    order_1_6  connected_order_arc_828  -1
    order_1_6  connected_order_arc_830  -1
    order_1_6  connected_order_arc_832  -1
    order_1_6  connected_order_arc_834  -1
    order_1_6  connected_order_arc_836  -1
    order_1_6  connected_order_arc_838  -1
    order_1_6  connected_order_arc_841  1
    order_1_6  connected_order_arc_866  1
    order_1_6  connected_order_arc_891  1
    order_1_6  connected_order_arc_916  1
    order_1_6  connected_order_arc_941  1
    order_1_6  connected_order_arc_966  1
    order_1_6  connected_order_arc_991  1
    order_1_6  connected_order_arc_1016  1
    order_1_6  connected_order_arc_1041  1
    order_1_6  connected_order_arc_1066  1
    order_1_6  connected_order_arc_1091  1
    order_1_6  connected_order_arc_1116  1
    order_1_6  order_active_lb_1143  1
    order_1_6  order_active_ub_1144  1
    order_1_6  fixed_segment_relative_order_1224  -1
    visit_1_7  out_degree_1148  -1
    visit_1_7  in_degree_1149  -1
    visit_1_7  order_active_lb_1150  -1
    visit_1_7  order_active_ub_1151  -13
    order_1_7  connected_order_arc_816  1
    order_1_7  connected_order_arc_841  -1
    order_1_7  connected_order_arc_843  -1
    order_1_7  connected_order_arc_845  -1
    order_1_7  connected_order_arc_847  -1
    order_1_7  connected_order_arc_849  -1
    order_1_7  connected_order_arc_851  -1
    order_1_7  connected_order_arc_853  -1
    order_1_7  connected_order_arc_855  -1
    order_1_7  connected_order_arc_857  -1
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_868  1
    order_1_7  connected_order_arc_893  1
    order_1_7  connected_order_arc_918  1
    order_1_7  connected_order_arc_943  1
    order_1_7  connected_order_arc_968  1
    order_1_7  connected_order_arc_993  1
    order_1_7  connected_order_arc_1018  1
    order_1_7  connected_order_arc_1043  1
    order_1_7  connected_order_arc_1068  1
    order_1_7  connected_order_arc_1093  1
    order_1_7  connected_order_arc_1118  1
    order_1_7  order_active_lb_1150  1
    order_1_7  order_active_ub_1151  1
    order_1_7  fixed_segment_relative_order_1224  1
    order_1_7  fixed_segment_relative_order_1225  -1
    visit_1_8  out_degree_1155  -1
    visit_1_8  in_degree_1156  -1
    visit_1_8  order_active_lb_1157  -1
    visit_1_8  order_active_ub_1158  -13
    order_1_8  connected_order_arc_818  1
    order_1_8  connected_order_arc_843  1
    order_1_8  connected_order_arc_866  -1
    order_1_8  connected_order_arc_868  -1
    order_1_8  connected_order_arc_870  -1
    order_1_8  connected_order_arc_872  -1
    order_1_8  connected_order_arc_874  -1
    order_1_8  connected_order_arc_876  -1
    order_1_8  connected_order_arc_878  -1
    order_1_8  connected_order_arc_880  -1
    order_1_8  connected_order_arc_882  -1
    order_1_8  connected_order_arc_884  -1
    order_1_8  connected_order_arc_886  -1
    order_1_8  connected_order_arc_888  -1
    order_1_8  connected_order_arc_895  1
    order_1_8  connected_order_arc_920  1
    order_1_8  connected_order_arc_945  1
    order_1_8  connected_order_arc_970  1
    order_1_8  connected_order_arc_995  1
    order_1_8  connected_order_arc_1020  1
    order_1_8  connected_order_arc_1045  1
    order_1_8  connected_order_arc_1070  1
    order_1_8  connected_order_arc_1095  1
    order_1_8  connected_order_arc_1120  1
    order_1_8  order_active_lb_1157  1
    order_1_8  order_active_ub_1158  1
    order_1_8  fixed_segment_relative_order_1225  1
    order_1_8  fixed_segment_relative_order_1226  -1
    visit_1_9  out_degree_1162  -1
    visit_1_9  in_degree_1163  -1
    visit_1_9  order_active_lb_1164  -1
    visit_1_9  order_active_ub_1165  -13
    order_1_9  connected_order_arc_820  1
    order_1_9  connected_order_arc_845  1
    order_1_9  connected_order_arc_870  1
    order_1_9  connected_order_arc_891  -1
    order_1_9  connected_order_arc_893  -1
    order_1_9  connected_order_arc_895  -1
    order_1_9  connected_order_arc_897  -1
    order_1_9  connected_order_arc_899  -1
    order_1_9  connected_order_arc_901  -1
    order_1_9  connected_order_arc_903  -1
    order_1_9  connected_order_arc_905  -1
    order_1_9  connected_order_arc_907  -1
    order_1_9  connected_order_arc_909  -1
    order_1_9  connected_order_arc_911  -1
    order_1_9  connected_order_arc_913  -1
    order_1_9  connected_order_arc_922  1
    order_1_9  connected_order_arc_947  1
    order_1_9  connected_order_arc_972  1
    order_1_9  connected_order_arc_997  1
    order_1_9  connected_order_arc_1022  1
    order_1_9  connected_order_arc_1047  1
    order_1_9  connected_order_arc_1072  1
    order_1_9  connected_order_arc_1097  1
    order_1_9  connected_order_arc_1122  1
    order_1_9  order_active_lb_1164  1
    order_1_9  order_active_ub_1165  1
    order_1_9  fixed_segment_relative_order_1226  1
    order_1_9  fixed_segment_relative_order_1227  -1
    visit_1_10  out_degree_1169  -1
    visit_1_10  in_degree_1170  -1
    visit_1_10  order_active_lb_1171  -1
    visit_1_10  order_active_ub_1172  -13
    order_1_10  connected_order_arc_822  1
    order_1_10  connected_order_arc_847  1
    order_1_10  connected_order_arc_872  1
    order_1_10  connected_order_arc_897  1
    order_1_10  connected_order_arc_916  -1
    order_1_10  connected_order_arc_918  -1
    order_1_10  connected_order_arc_920  -1
    order_1_10  connected_order_arc_922  -1
    order_1_10  connected_order_arc_924  -1
    order_1_10  connected_order_arc_926  -1
    order_1_10  connected_order_arc_928  -1
    order_1_10  connected_order_arc_930  -1
    order_1_10  connected_order_arc_932  -1
    order_1_10  connected_order_arc_934  -1
    order_1_10  connected_order_arc_936  -1
    order_1_10  connected_order_arc_938  -1
    order_1_10  connected_order_arc_949  1
    order_1_10  connected_order_arc_974  1
    order_1_10  connected_order_arc_999  1
    order_1_10  connected_order_arc_1024  1
    order_1_10  connected_order_arc_1049  1
    order_1_10  connected_order_arc_1074  1
    order_1_10  connected_order_arc_1099  1
    order_1_10  connected_order_arc_1124  1
    order_1_10  order_active_lb_1171  1
    order_1_10  order_active_ub_1172  1
    order_1_10  fixed_segment_relative_order_1227  1
    visit_1_15  out_degree_1176  -1
    visit_1_15  in_degree_1177  -1
    visit_1_15  order_active_lb_1178  -1
    visit_1_15  order_active_ub_1179  -13
    visit_1_15  service_visit_def_1180  -1
    order_1_15  connected_order_arc_824  1
    order_1_15  connected_order_arc_849  1
    order_1_15  connected_order_arc_874  1
    order_1_15  connected_order_arc_899  1
    order_1_15  connected_order_arc_924  1
    order_1_15  connected_order_arc_941  -1
    order_1_15  connected_order_arc_943  -1
    order_1_15  connected_order_arc_945  -1
    order_1_15  connected_order_arc_947  -1
    order_1_15  connected_order_arc_949  -1
    order_1_15  connected_order_arc_951  -1
    order_1_15  connected_order_arc_953  -1
    order_1_15  connected_order_arc_955  -1
    order_1_15  connected_order_arc_957  -1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_961  -1
    order_1_15  connected_order_arc_963  -1
    order_1_15  connected_order_arc_976  1
    order_1_15  connected_order_arc_1001  1
    order_1_15  connected_order_arc_1026  1
    order_1_15  connected_order_arc_1051  1
    order_1_15  connected_order_arc_1076  1
    order_1_15  connected_order_arc_1101  1
    order_1_15  connected_order_arc_1126  1
    order_1_15  order_active_lb_1178  1
    order_1_15  order_active_ub_1179  1
    visit_1_16  out_degree_1182  -1
    visit_1_16  in_degree_1183  -1
    visit_1_16  order_active_lb_1184  -1
    visit_1_16  order_active_ub_1185  -13
    visit_1_16  service_visit_def_1186  -1
    order_1_16  connected_order_arc_826  1
    order_1_16  connected_order_arc_851  1
    order_1_16  connected_order_arc_876  1
    order_1_16  connected_order_arc_901  1
    order_1_16  connected_order_arc_926  1
    order_1_16  connected_order_arc_951  1
    order_1_16  connected_order_arc_966  -1
    order_1_16  connected_order_arc_968  -1
    order_1_16  connected_order_arc_970  -1
    order_1_16  connected_order_arc_972  -1
    order_1_16  connected_order_arc_974  -1
    order_1_16  connected_order_arc_976  -1
    order_1_16  connected_order_arc_978  -1
    order_1_16  connected_order_arc_980  -1
    order_1_16  connected_order_arc_982  -1
    order_1_16  connected_order_arc_984  -1
    order_1_16  connected_order_arc_986  -1
    order_1_16  connected_order_arc_988  -1
    order_1_16  connected_order_arc_1003  1
    order_1_16  connected_order_arc_1028  1
    order_1_16  connected_order_arc_1053  1
    order_1_16  connected_order_arc_1078  1
    order_1_16  connected_order_arc_1103  1
    order_1_16  connected_order_arc_1128  1
    order_1_16  order_active_lb_1184  1
    order_1_16  order_active_ub_1185  1
    visit_1_17  out_degree_1188  -1
    visit_1_17  in_degree_1189  -1
    visit_1_17  order_active_lb_1190  -1
    visit_1_17  order_active_ub_1191  -13
    visit_1_17  service_visit_def_1192  -1
    order_1_17  connected_order_arc_828  1
    order_1_17  connected_order_arc_853  1
    order_1_17  connected_order_arc_878  1
    order_1_17  connected_order_arc_903  1
    order_1_17  connected_order_arc_928  1
    order_1_17  connected_order_arc_953  1
    order_1_17  connected_order_arc_978  1
    order_1_17  connected_order_arc_991  -1
    order_1_17  connected_order_arc_993  -1
    order_1_17  connected_order_arc_995  -1
    order_1_17  connected_order_arc_997  -1
    order_1_17  connected_order_arc_999  -1
    order_1_17  connected_order_arc_1001  -1
    order_1_17  connected_order_arc_1003  -1
    order_1_17  connected_order_arc_1005  -1
    order_1_17  connected_order_arc_1007  -1
    order_1_17  connected_order_arc_1009  -1
    order_1_17  connected_order_arc_1011  -1
    order_1_17  connected_order_arc_1013  -1
    order_1_17  connected_order_arc_1030  1
    order_1_17  connected_order_arc_1055  1
    order_1_17  connected_order_arc_1080  1
    order_1_17  connected_order_arc_1105  1
    order_1_17  connected_order_arc_1130  1
    order_1_17  order_active_lb_1190  1
    order_1_17  order_active_ub_1191  1
    visit_1_18  out_degree_1194  -1
    visit_1_18  in_degree_1195  -1
    visit_1_18  order_active_lb_1196  -1
    visit_1_18  order_active_ub_1197  -13
    visit_1_18  service_visit_def_1198  -1
    order_1_18  connected_order_arc_830  1
    order_1_18  connected_order_arc_855  1
    order_1_18  connected_order_arc_880  1
    order_1_18  connected_order_arc_905  1
    order_1_18  connected_order_arc_930  1
    order_1_18  connected_order_arc_955  1
    order_1_18  connected_order_arc_980  1
    order_1_18  connected_order_arc_1005  1
    order_1_18  connected_order_arc_1016  -1
    order_1_18  connected_order_arc_1018  -1
    order_1_18  connected_order_arc_1020  -1
    order_1_18  connected_order_arc_1022  -1
    order_1_18  connected_order_arc_1024  -1
    order_1_18  connected_order_arc_1026  -1
    order_1_18  connected_order_arc_1028  -1
    order_1_18  connected_order_arc_1030  -1
    order_1_18  connected_order_arc_1032  -1
    order_1_18  connected_order_arc_1034  -1
    order_1_18  connected_order_arc_1036  -1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1057  1
    order_1_18  connected_order_arc_1082  1
    order_1_18  connected_order_arc_1107  1
    order_1_18  connected_order_arc_1132  1
    order_1_18  order_active_lb_1196  1
    order_1_18  order_active_ub_1197  1
    visit_1_19  out_degree_1200  -1
    visit_1_19  in_degree_1201  -1
    visit_1_19  order_active_lb_1202  -1
    visit_1_19  order_active_ub_1203  -13
    visit_1_19  service_visit_def_1204  -1
    order_1_19  connected_order_arc_832  1
    order_1_19  connected_order_arc_857  1
    order_1_19  connected_order_arc_882  1
    order_1_19  connected_order_arc_907  1
    order_1_19  connected_order_arc_932  1
    order_1_19  connected_order_arc_957  1
    order_1_19  connected_order_arc_982  1
    order_1_19  connected_order_arc_1007  1
    order_1_19  connected_order_arc_1032  1
    order_1_19  connected_order_arc_1041  -1
    order_1_19  connected_order_arc_1043  -1
    order_1_19  connected_order_arc_1045  -1
    order_1_19  connected_order_arc_1047  -1
    order_1_19  connected_order_arc_1049  -1
    order_1_19  connected_order_arc_1051  -1
    order_1_19  connected_order_arc_1053  -1
    order_1_19  connected_order_arc_1055  -1
    order_1_19  connected_order_arc_1057  -1
    order_1_19  connected_order_arc_1059  -1
    order_1_19  connected_order_arc_1061  -1
    order_1_19  connected_order_arc_1063  -1
    order_1_19  connected_order_arc_1084  1
    order_1_19  connected_order_arc_1109  1
    order_1_19  connected_order_arc_1134  1
    order_1_19  order_active_lb_1202  1
    order_1_19  order_active_ub_1203  1
    visit_1_20  out_degree_1206  -1
    visit_1_20  in_degree_1207  -1
    visit_1_20  order_active_lb_1208  -1
    visit_1_20  order_active_ub_1209  -13
    visit_1_20  service_visit_def_1210  -1
    order_1_20  connected_order_arc_834  1
    order_1_20  connected_order_arc_859  1
    order_1_20  connected_order_arc_884  1
    order_1_20  connected_order_arc_909  1
    order_1_20  connected_order_arc_934  1
    order_1_20  connected_order_arc_959  1
    order_1_20  connected_order_arc_984  1
    order_1_20  connected_order_arc_1009  1
    order_1_20  connected_order_arc_1034  1
    order_1_20  connected_order_arc_1059  1
    order_1_20  connected_order_arc_1066  -1
    order_1_20  connected_order_arc_1068  -1
    order_1_20  connected_order_arc_1070  -1
    order_1_20  connected_order_arc_1072  -1
    order_1_20  connected_order_arc_1074  -1
    order_1_20  connected_order_arc_1076  -1
    order_1_20  connected_order_arc_1078  -1
    order_1_20  connected_order_arc_1080  -1
    order_1_20  connected_order_arc_1082  -1
    order_1_20  connected_order_arc_1084  -1
    order_1_20  connected_order_arc_1086  -1
    order_1_20  connected_order_arc_1088  -1
    order_1_20  connected_order_arc_1111  1
    order_1_20  connected_order_arc_1136  1
    order_1_20  order_active_lb_1208  1
    order_1_20  order_active_ub_1209  1
    visit_1_21  out_degree_1212  -1
    visit_1_21  in_degree_1213  -1
    visit_1_21  order_active_lb_1214  -1
    visit_1_21  order_active_ub_1215  -13
    visit_1_21  service_visit_def_1216  -1
    order_1_21  connected_order_arc_836  1
    order_1_21  connected_order_arc_861  1
    order_1_21  connected_order_arc_886  1
    order_1_21  connected_order_arc_911  1
    order_1_21  connected_order_arc_936  1
    order_1_21  connected_order_arc_961  1
    order_1_21  connected_order_arc_986  1
    order_1_21  connected_order_arc_1011  1
    order_1_21  connected_order_arc_1036  1
    order_1_21  connected_order_arc_1061  1
    order_1_21  connected_order_arc_1086  1
    order_1_21  connected_order_arc_1091  -1
    order_1_21  connected_order_arc_1093  -1
    order_1_21  connected_order_arc_1095  -1
    order_1_21  connected_order_arc_1097  -1
    order_1_21  connected_order_arc_1099  -1
    order_1_21  connected_order_arc_1101  -1
    order_1_21  connected_order_arc_1103  -1
    order_1_21  connected_order_arc_1105  -1
    order_1_21  connected_order_arc_1107  -1
    order_1_21  connected_order_arc_1109  -1
    order_1_21  connected_order_arc_1111  -1
    order_1_21  connected_order_arc_1113  -1
    order_1_21  connected_order_arc_1138  1
    order_1_21  order_active_lb_1214  1
    order_1_21  order_active_ub_1215  1
    visit_1_22  out_degree_1218  -1
    visit_1_22  in_degree_1219  -1
    visit_1_22  order_active_lb_1220  -1
    visit_1_22  order_active_ub_1221  -13
    visit_1_22  service_visit_def_1222  -1
    order_1_22  connected_order_arc_838  1
    order_1_22  connected_order_arc_863  1
    order_1_22  connected_order_arc_888  1
    order_1_22  connected_order_arc_913  1
    order_1_22  connected_order_arc_938  1
    order_1_22  connected_order_arc_963  1
    order_1_22  connected_order_arc_988  1
    order_1_22  connected_order_arc_1013  1
    order_1_22  connected_order_arc_1038  1
    order_1_22  connected_order_arc_1063  1
    order_1_22  connected_order_arc_1088  1
    order_1_22  connected_order_arc_1113  1
    order_1_22  connected_order_arc_1116  -1
    order_1_22  connected_order_arc_1118  -1
    order_1_22  connected_order_arc_1120  -1
    order_1_22  connected_order_arc_1122  -1
    order_1_22  connected_order_arc_1124  -1
    order_1_22  connected_order_arc_1126  -1
    order_1_22  connected_order_arc_1128  -1
    order_1_22  connected_order_arc_1130  -1
    order_1_22  connected_order_arc_1132  -1
    order_1_22  connected_order_arc_1134  -1
    order_1_22  connected_order_arc_1136  -1
    order_1_22  connected_order_arc_1138  -1
    order_1_22  order_active_lb_1220  1
    order_1_22  order_active_ub_1221  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_800  -25
    arc_1_0_0  depot_departure_or_bypass_1139  1
    arc_1_0_0  depot_return_or_bypass_1140  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_801  -25
    arc_1_0_6  depot_departure_or_bypass_1139  1
    arc_1_0_6  in_degree_1142  1
    arc_1_0_6  original_T_including_depot_unload_1228  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_801  1
    load_1_0_6  segment_load_conservation_1145  -1
    load_1_0_6  segment_prefix_lb_1146  1
    load_1_0_6  segment_prefix_ub_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_802  -25
    arc_1_0_7  depot_departure_or_bypass_1139  1
    arc_1_0_7  in_degree_1149  1
    arc_1_0_7  original_T_including_depot_unload_1228  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_802  1
    load_1_0_7  segment_load_conservation_1152  -1
    load_1_0_7  segment_prefix_lb_1153  1
    load_1_0_7  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_803  -25
    arc_1_0_8  depot_departure_or_bypass_1139  1
    arc_1_0_8  in_degree_1156  1
    arc_1_0_8  original_T_including_depot_unload_1228  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_803  1
    load_1_0_8  segment_load_conservation_1159  -1
    load_1_0_8  segment_prefix_lb_1160  1
    load_1_0_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_804  -25
    arc_1_0_9  depot_departure_or_bypass_1139  1
    arc_1_0_9  in_degree_1163  1
    arc_1_0_9  original_T_including_depot_unload_1228  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_804  1
    load_1_0_9  segment_load_conservation_1166  -1
    load_1_0_9  segment_prefix_lb_1167  1
    load_1_0_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_805  -25
    arc_1_0_10  depot_departure_or_bypass_1139  1
    arc_1_0_10  in_degree_1170  1
    arc_1_0_10  original_T_including_depot_unload_1228  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_805  1
    load_1_0_10  segment_load_conservation_1173  -1
    load_1_0_10  segment_prefix_lb_1174  1
    load_1_0_10  segment_prefix_ub_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_806  -25
    arc_1_0_15  depot_departure_or_bypass_1139  1
    arc_1_0_15  in_degree_1177  1
    arc_1_0_15  original_T_including_depot_unload_1228  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_806  1
    load_1_0_15  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_807  -25
    arc_1_0_16  depot_departure_or_bypass_1139  1
    arc_1_0_16  in_degree_1183  1
    arc_1_0_16  original_T_including_depot_unload_1228  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_807  1
    load_1_0_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_808  -25
    arc_1_0_17  depot_departure_or_bypass_1139  1
    arc_1_0_17  in_degree_1189  1
    arc_1_0_17  original_T_including_depot_unload_1228  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_808  1
    load_1_0_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_809  -25
    arc_1_0_18  depot_departure_or_bypass_1139  1
    arc_1_0_18  in_degree_1195  1
    arc_1_0_18  original_T_including_depot_unload_1228  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_809  1
    load_1_0_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_810  -25
    arc_1_0_19  depot_departure_or_bypass_1139  1
    arc_1_0_19  in_degree_1201  1
    arc_1_0_19  original_T_including_depot_unload_1228  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_810  1
    load_1_0_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_811  -25
    arc_1_0_20  depot_departure_or_bypass_1139  1
    arc_1_0_20  in_degree_1207  1
    arc_1_0_20  original_T_including_depot_unload_1228  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_811  1
    load_1_0_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_812  -25
    arc_1_0_21  depot_departure_or_bypass_1139  1
    arc_1_0_21  in_degree_1213  1
    arc_1_0_21  original_T_including_depot_unload_1228  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_812  1
    load_1_0_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_813  -25
    arc_1_0_22  depot_departure_or_bypass_1139  1
    arc_1_0_22  in_degree_1219  1
    arc_1_0_22  original_T_including_depot_unload_1228  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_813  1
    load_1_0_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_814  -25
    arc_1_6_0  depot_return_or_bypass_1140  1
    arc_1_6_0  out_degree_1141  1
    arc_1_6_0  original_T_including_depot_unload_1228  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_814  1
    load_1_6_0  segment_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_815  -25
    arc_1_6_7  connected_order_arc_816  -14
    arc_1_6_7  out_degree_1141  1
    arc_1_6_7  in_degree_1149  1
    arc_1_6_7  original_T_including_depot_unload_1228  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_815  1
    load_1_6_7  segment_load_conservation_1145  1
    load_1_6_7  segment_load_conservation_1152  -1
    load_1_6_7  segment_prefix_lb_1153  1
    load_1_6_7  segment_prefix_ub_1154  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_817  -25
    arc_1_6_8  connected_order_arc_818  -14
    arc_1_6_8  out_degree_1141  1
    arc_1_6_8  in_degree_1156  1
    arc_1_6_8  original_T_including_depot_unload_1228  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_817  1
    load_1_6_8  segment_load_conservation_1145  1
    load_1_6_8  segment_load_conservation_1159  -1
    load_1_6_8  segment_prefix_lb_1160  1
    load_1_6_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_819  -25
    arc_1_6_9  connected_order_arc_820  -14
    arc_1_6_9  out_degree_1141  1
    arc_1_6_9  in_degree_1163  1
    arc_1_6_9  original_T_including_depot_unload_1228  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_819  1
    load_1_6_9  segment_load_conservation_1145  1
    load_1_6_9  segment_load_conservation_1166  -1
    load_1_6_9  segment_prefix_lb_1167  1
    load_1_6_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_821  -25
    arc_1_6_10  connected_order_arc_822  -14
    arc_1_6_10  out_degree_1141  1
    arc_1_6_10  in_degree_1170  1
    arc_1_6_10  original_T_including_depot_unload_1228  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_821  1
    load_1_6_10  segment_load_conservation_1145  1
    load_1_6_10  segment_load_conservation_1173  -1
    load_1_6_10  segment_prefix_lb_1174  1
    load_1_6_10  segment_prefix_ub_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_823  -25
    arc_1_6_15  connected_order_arc_824  -14
    arc_1_6_15  out_degree_1141  1
    arc_1_6_15  in_degree_1177  1
    arc_1_6_15  original_T_including_depot_unload_1228  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_823  1
    load_1_6_15  segment_load_conservation_1145  1
    load_1_6_15  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_825  -25
    arc_1_6_16  connected_order_arc_826  -14
    arc_1_6_16  out_degree_1141  1
    arc_1_6_16  in_degree_1183  1
    arc_1_6_16  original_T_including_depot_unload_1228  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_825  1
    load_1_6_16  segment_load_conservation_1145  1
    load_1_6_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_827  -25
    arc_1_6_17  connected_order_arc_828  -14
    arc_1_6_17  out_degree_1141  1
    arc_1_6_17  in_degree_1189  1
    arc_1_6_17  original_T_including_depot_unload_1228  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_827  1
    load_1_6_17  segment_load_conservation_1145  1
    load_1_6_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_829  -25
    arc_1_6_18  connected_order_arc_830  -14
    arc_1_6_18  out_degree_1141  1
    arc_1_6_18  in_degree_1195  1
    arc_1_6_18  original_T_including_depot_unload_1228  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_829  1
    load_1_6_18  segment_load_conservation_1145  1
    load_1_6_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_831  -25
    arc_1_6_19  connected_order_arc_832  -14
    arc_1_6_19  out_degree_1141  1
    arc_1_6_19  in_degree_1201  1
    arc_1_6_19  original_T_including_depot_unload_1228  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_831  1
    load_1_6_19  segment_load_conservation_1145  1
    load_1_6_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_833  -25
    arc_1_6_20  connected_order_arc_834  -14
    arc_1_6_20  out_degree_1141  1
    arc_1_6_20  in_degree_1207  1
    arc_1_6_20  original_T_including_depot_unload_1228  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_833  1
    load_1_6_20  segment_load_conservation_1145  1
    load_1_6_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_835  -25
    arc_1_6_21  connected_order_arc_836  -14
    arc_1_6_21  out_degree_1141  1
    arc_1_6_21  in_degree_1213  1
    arc_1_6_21  original_T_including_depot_unload_1228  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_835  1
    load_1_6_21  segment_load_conservation_1145  1
    load_1_6_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_22  arc_capacity_837  -25
    arc_1_6_22  connected_order_arc_838  -14
    arc_1_6_22  out_degree_1141  1
    arc_1_6_22  in_degree_1219  1
    arc_1_6_22  original_T_including_depot_unload_1228  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_22  arc_capacity_837  1
    load_1_6_22  segment_load_conservation_1145  1
    load_1_6_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_839  -25
    arc_1_7_0  depot_return_or_bypass_1140  1
    arc_1_7_0  out_degree_1148  1
    arc_1_7_0  original_T_including_depot_unload_1228  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_839  1
    load_1_7_0  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_840  -25
    arc_1_7_6  connected_order_arc_841  -14
    arc_1_7_6  in_degree_1142  1
    arc_1_7_6  out_degree_1148  1
    arc_1_7_6  original_T_including_depot_unload_1228  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_840  1
    load_1_7_6  segment_load_conservation_1145  -1
    load_1_7_6  segment_prefix_lb_1146  1
    load_1_7_6  segment_prefix_ub_1147  1
    load_1_7_6  segment_load_conservation_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_842  -25
    arc_1_7_8  connected_order_arc_843  -14
    arc_1_7_8  out_degree_1148  1
    arc_1_7_8  in_degree_1156  1
    arc_1_7_8  original_T_including_depot_unload_1228  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_842  1
    load_1_7_8  segment_load_conservation_1152  1
    load_1_7_8  segment_load_conservation_1159  -1
    load_1_7_8  segment_prefix_lb_1160  1
    load_1_7_8  segment_prefix_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_844  -25
    arc_1_7_9  connected_order_arc_845  -14
    arc_1_7_9  out_degree_1148  1
    arc_1_7_9  in_degree_1163  1
    arc_1_7_9  original_T_including_depot_unload_1228  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_844  1
    load_1_7_9  segment_load_conservation_1152  1
    load_1_7_9  segment_load_conservation_1166  -1
    load_1_7_9  segment_prefix_lb_1167  1
    load_1_7_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_846  -25
    arc_1_7_10  connected_order_arc_847  -14
    arc_1_7_10  out_degree_1148  1
    arc_1_7_10  in_degree_1170  1
    arc_1_7_10  original_T_including_depot_unload_1228  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_846  1
    load_1_7_10  segment_load_conservation_1152  1
    load_1_7_10  segment_load_conservation_1173  -1
    load_1_7_10  segment_prefix_lb_1174  1
    load_1_7_10  segment_prefix_ub_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_848  -25
    arc_1_7_15  connected_order_arc_849  -14
    arc_1_7_15  out_degree_1148  1
    arc_1_7_15  in_degree_1177  1
    arc_1_7_15  original_T_including_depot_unload_1228  2.1139218026901112e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_848  1
    load_1_7_15  segment_load_conservation_1152  1
    load_1_7_15  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_850  -25
    arc_1_7_16  connected_order_arc_851  -14
    arc_1_7_16  out_degree_1148  1
    arc_1_7_16  in_degree_1183  1
    arc_1_7_16  original_T_including_depot_unload_1228  2.2630748095713293e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_850  1
    load_1_7_16  segment_load_conservation_1152  1
    load_1_7_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_852  -25
    arc_1_7_17  connected_order_arc_853  -14
    arc_1_7_17  out_degree_1148  1
    arc_1_7_17  in_degree_1189  1
    arc_1_7_17  original_T_including_depot_unload_1228  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_852  1
    load_1_7_17  segment_load_conservation_1152  1
    load_1_7_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_854  -25
    arc_1_7_18  connected_order_arc_855  -14
    arc_1_7_18  out_degree_1148  1
    arc_1_7_18  in_degree_1195  1
    arc_1_7_18  original_T_including_depot_unload_1228  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_854  1
    load_1_7_18  segment_load_conservation_1152  1
    load_1_7_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_856  -25
    arc_1_7_19  connected_order_arc_857  -14
    arc_1_7_19  out_degree_1148  1
    arc_1_7_19  in_degree_1201  1
    arc_1_7_19  original_T_including_depot_unload_1228  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_856  1
    load_1_7_19  segment_load_conservation_1152  1
    load_1_7_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_858  -25
    arc_1_7_20  connected_order_arc_859  -14
    arc_1_7_20  out_degree_1148  1
    arc_1_7_20  in_degree_1207  1
    arc_1_7_20  original_T_including_depot_unload_1228  2.1293186465553604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_858  1
    load_1_7_20  segment_load_conservation_1152  1
    load_1_7_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_860  -25
    arc_1_7_21  connected_order_arc_861  -14
    arc_1_7_21  out_degree_1148  1
    arc_1_7_21  in_degree_1213  1
    arc_1_7_21  original_T_including_depot_unload_1228  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_860  1
    load_1_7_21  segment_load_conservation_1152  1
    load_1_7_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_862  -25
    arc_1_7_22  connected_order_arc_863  -14
    arc_1_7_22  out_degree_1148  1
    arc_1_7_22  in_degree_1219  1
    arc_1_7_22  original_T_including_depot_unload_1228  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_862  1
    load_1_7_22  segment_load_conservation_1152  1
    load_1_7_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_864  -25
    arc_1_8_0  depot_return_or_bypass_1140  1
    arc_1_8_0  out_degree_1155  1
    arc_1_8_0  original_T_including_depot_unload_1228  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_864  1
    load_1_8_0  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_865  -25
    arc_1_8_6  connected_order_arc_866  -14
    arc_1_8_6  in_degree_1142  1
    arc_1_8_6  out_degree_1155  1
    arc_1_8_6  original_T_including_depot_unload_1228  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_865  1
    load_1_8_6  segment_load_conservation_1145  -1
    load_1_8_6  segment_prefix_lb_1146  1
    load_1_8_6  segment_prefix_ub_1147  1
    load_1_8_6  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_867  -25
    arc_1_8_7  connected_order_arc_868  -14
    arc_1_8_7  in_degree_1149  1
    arc_1_8_7  out_degree_1155  1
    arc_1_8_7  original_T_including_depot_unload_1228  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_867  1
    load_1_8_7  segment_load_conservation_1152  -1
    load_1_8_7  segment_prefix_lb_1153  1
    load_1_8_7  segment_prefix_ub_1154  1
    load_1_8_7  segment_load_conservation_1159  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_869  -25
    arc_1_8_9  connected_order_arc_870  -14
    arc_1_8_9  out_degree_1155  1
    arc_1_8_9  in_degree_1163  1
    arc_1_8_9  original_T_including_depot_unload_1228  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_869  1
    load_1_8_9  segment_load_conservation_1159  1
    load_1_8_9  segment_load_conservation_1166  -1
    load_1_8_9  segment_prefix_lb_1167  1
    load_1_8_9  segment_prefix_ub_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_871  -25
    arc_1_8_10  connected_order_arc_872  -14
    arc_1_8_10  out_degree_1155  1
    arc_1_8_10  in_degree_1170  1
    arc_1_8_10  original_T_including_depot_unload_1228  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_871  1
    load_1_8_10  segment_load_conservation_1159  1
    load_1_8_10  segment_load_conservation_1173  -1
    load_1_8_10  segment_prefix_lb_1174  1
    load_1_8_10  segment_prefix_ub_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_873  -25
    arc_1_8_15  connected_order_arc_874  -14
    arc_1_8_15  out_degree_1155  1
    arc_1_8_15  in_degree_1177  1
    arc_1_8_15  original_T_including_depot_unload_1228  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_873  1
    load_1_8_15  segment_load_conservation_1159  1
    load_1_8_15  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_875  -25
    arc_1_8_16  connected_order_arc_876  -14
    arc_1_8_16  out_degree_1155  1
    arc_1_8_16  in_degree_1183  1
    arc_1_8_16  original_T_including_depot_unload_1228  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_875  1
    load_1_8_16  segment_load_conservation_1159  1
    load_1_8_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_877  -25
    arc_1_8_17  connected_order_arc_878  -14
    arc_1_8_17  out_degree_1155  1
    arc_1_8_17  in_degree_1189  1
    arc_1_8_17  original_T_including_depot_unload_1228  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_877  1
    load_1_8_17  segment_load_conservation_1159  1
    load_1_8_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_879  -25
    arc_1_8_18  connected_order_arc_880  -14
    arc_1_8_18  out_degree_1155  1
    arc_1_8_18  in_degree_1195  1
    arc_1_8_18  original_T_including_depot_unload_1228  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_879  1
    load_1_8_18  segment_load_conservation_1159  1
    load_1_8_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_881  -25
    arc_1_8_19  connected_order_arc_882  -14
    arc_1_8_19  out_degree_1155  1
    arc_1_8_19  in_degree_1201  1
    arc_1_8_19  original_T_including_depot_unload_1228  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_881  1
    load_1_8_19  segment_load_conservation_1159  1
    load_1_8_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_883  -25
    arc_1_8_20  connected_order_arc_884  -14
    arc_1_8_20  out_degree_1155  1
    arc_1_8_20  in_degree_1207  1
    arc_1_8_20  original_T_including_depot_unload_1228  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_883  1
    load_1_8_20  segment_load_conservation_1159  1
    load_1_8_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_885  -25
    arc_1_8_21  connected_order_arc_886  -14
    arc_1_8_21  out_degree_1155  1
    arc_1_8_21  in_degree_1213  1
    arc_1_8_21  original_T_including_depot_unload_1228  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_885  1
    load_1_8_21  segment_load_conservation_1159  1
    load_1_8_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_887  -25
    arc_1_8_22  connected_order_arc_888  -14
    arc_1_8_22  out_degree_1155  1
    arc_1_8_22  in_degree_1219  1
    arc_1_8_22  original_T_including_depot_unload_1228  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_887  1
    load_1_8_22  segment_load_conservation_1159  1
    load_1_8_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_889  -25
    arc_1_9_0  depot_return_or_bypass_1140  1
    arc_1_9_0  out_degree_1162  1
    arc_1_9_0  original_T_including_depot_unload_1228  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_889  1
    load_1_9_0  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_890  -25
    arc_1_9_6  connected_order_arc_891  -14
    arc_1_9_6  in_degree_1142  1
    arc_1_9_6  out_degree_1162  1
    arc_1_9_6  original_T_including_depot_unload_1228  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_890  1
    load_1_9_6  segment_load_conservation_1145  -1
    load_1_9_6  segment_prefix_lb_1146  1
    load_1_9_6  segment_prefix_ub_1147  1
    load_1_9_6  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_892  -25
    arc_1_9_7  connected_order_arc_893  -14
    arc_1_9_7  in_degree_1149  1
    arc_1_9_7  out_degree_1162  1
    arc_1_9_7  original_T_including_depot_unload_1228  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_892  1
    load_1_9_7  segment_load_conservation_1152  -1
    load_1_9_7  segment_prefix_lb_1153  1
    load_1_9_7  segment_prefix_ub_1154  1
    load_1_9_7  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_894  -25
    arc_1_9_8  connected_order_arc_895  -14
    arc_1_9_8  in_degree_1156  1
    arc_1_9_8  out_degree_1162  1
    arc_1_9_8  original_T_including_depot_unload_1228  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_894  1
    load_1_9_8  segment_load_conservation_1159  -1
    load_1_9_8  segment_prefix_lb_1160  1
    load_1_9_8  segment_prefix_ub_1161  1
    load_1_9_8  segment_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_896  -25
    arc_1_9_10  connected_order_arc_897  -14
    arc_1_9_10  out_degree_1162  1
    arc_1_9_10  in_degree_1170  1
    arc_1_9_10  original_T_including_depot_unload_1228  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_896  1
    load_1_9_10  segment_load_conservation_1166  1
    load_1_9_10  segment_load_conservation_1173  -1
    load_1_9_10  segment_prefix_lb_1174  1
    load_1_9_10  segment_prefix_ub_1175  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_898  -25
    arc_1_9_15  connected_order_arc_899  -14
    arc_1_9_15  out_degree_1162  1
    arc_1_9_15  in_degree_1177  1
    arc_1_9_15  original_T_including_depot_unload_1228  1.7644788835951622e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_898  1
    load_1_9_15  segment_load_conservation_1166  1
    load_1_9_15  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_900  -25
    arc_1_9_16  connected_order_arc_901  -14
    arc_1_9_16  out_degree_1162  1
    arc_1_9_16  in_degree_1183  1
    arc_1_9_16  original_T_including_depot_unload_1228  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_900  1
    load_1_9_16  segment_load_conservation_1166  1
    load_1_9_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_902  -25
    arc_1_9_17  connected_order_arc_903  -14
    arc_1_9_17  out_degree_1162  1
    arc_1_9_17  in_degree_1189  1
    arc_1_9_17  original_T_including_depot_unload_1228  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_902  1
    load_1_9_17  segment_load_conservation_1166  1
    load_1_9_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_904  -25
    arc_1_9_18  connected_order_arc_905  -14
    arc_1_9_18  out_degree_1162  1
    arc_1_9_18  in_degree_1195  1
    arc_1_9_18  original_T_including_depot_unload_1228  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_904  1
    load_1_9_18  segment_load_conservation_1166  1
    load_1_9_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_906  -25
    arc_1_9_19  connected_order_arc_907  -14
    arc_1_9_19  out_degree_1162  1
    arc_1_9_19  in_degree_1201  1
    arc_1_9_19  original_T_including_depot_unload_1228  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_906  1
    load_1_9_19  segment_load_conservation_1166  1
    load_1_9_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_908  -25
    arc_1_9_20  connected_order_arc_909  -14
    arc_1_9_20  out_degree_1162  1
    arc_1_9_20  in_degree_1207  1
    arc_1_9_20  original_T_including_depot_unload_1228  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_908  1
    load_1_9_20  segment_load_conservation_1166  1
    load_1_9_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_910  -25
    arc_1_9_21  connected_order_arc_911  -14
    arc_1_9_21  out_degree_1162  1
    arc_1_9_21  in_degree_1213  1
    arc_1_9_21  original_T_including_depot_unload_1228  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_910  1
    load_1_9_21  segment_load_conservation_1166  1
    load_1_9_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_912  -25
    arc_1_9_22  connected_order_arc_913  -14
    arc_1_9_22  out_degree_1162  1
    arc_1_9_22  in_degree_1219  1
    arc_1_9_22  original_T_including_depot_unload_1228  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_912  1
    load_1_9_22  segment_load_conservation_1166  1
    load_1_9_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_914  -25
    arc_1_10_0  depot_return_or_bypass_1140  1
    arc_1_10_0  out_degree_1169  1
    arc_1_10_0  original_T_including_depot_unload_1228  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_914  1
    load_1_10_0  segment_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_915  -25
    arc_1_10_6  connected_order_arc_916  -14
    arc_1_10_6  in_degree_1142  1
    arc_1_10_6  out_degree_1169  1
    arc_1_10_6  original_T_including_depot_unload_1228  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_915  1
    load_1_10_6  segment_load_conservation_1145  -1
    load_1_10_6  segment_prefix_lb_1146  1
    load_1_10_6  segment_prefix_ub_1147  1
    load_1_10_6  segment_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_917  -25
    arc_1_10_7  connected_order_arc_918  -14
    arc_1_10_7  in_degree_1149  1
    arc_1_10_7  out_degree_1169  1
    arc_1_10_7  original_T_including_depot_unload_1228  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_917  1
    load_1_10_7  segment_load_conservation_1152  -1
    load_1_10_7  segment_prefix_lb_1153  1
    load_1_10_7  segment_prefix_ub_1154  1
    load_1_10_7  segment_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_919  -25
    arc_1_10_8  connected_order_arc_920  -14
    arc_1_10_8  in_degree_1156  1
    arc_1_10_8  out_degree_1169  1
    arc_1_10_8  original_T_including_depot_unload_1228  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_919  1
    load_1_10_8  segment_load_conservation_1159  -1
    load_1_10_8  segment_prefix_lb_1160  1
    load_1_10_8  segment_prefix_ub_1161  1
    load_1_10_8  segment_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_921  -25
    arc_1_10_9  connected_order_arc_922  -14
    arc_1_10_9  in_degree_1163  1
    arc_1_10_9  out_degree_1169  1
    arc_1_10_9  original_T_including_depot_unload_1228  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_921  1
    load_1_10_9  segment_load_conservation_1166  -1
    load_1_10_9  segment_prefix_lb_1167  1
    load_1_10_9  segment_prefix_ub_1168  1
    load_1_10_9  segment_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_923  -25
    arc_1_10_15  connected_order_arc_924  -14
    arc_1_10_15  out_degree_1169  1
    arc_1_10_15  in_degree_1177  1
    arc_1_10_15  original_T_including_depot_unload_1228  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_923  1
    load_1_10_15  segment_load_conservation_1173  1
    load_1_10_15  free_load_conservation_1181  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_925  -25
    arc_1_10_16  connected_order_arc_926  -14
    arc_1_10_16  out_degree_1169  1
    arc_1_10_16  in_degree_1183  1
    arc_1_10_16  original_T_including_depot_unload_1228  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_925  1
    load_1_10_16  segment_load_conservation_1173  1
    load_1_10_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_927  -25
    arc_1_10_17  connected_order_arc_928  -14
    arc_1_10_17  out_degree_1169  1
    arc_1_10_17  in_degree_1189  1
    arc_1_10_17  original_T_including_depot_unload_1228  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_927  1
    load_1_10_17  segment_load_conservation_1173  1
    load_1_10_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_929  -25
    arc_1_10_18  connected_order_arc_930  -14
    arc_1_10_18  out_degree_1169  1
    arc_1_10_18  in_degree_1195  1
    arc_1_10_18  original_T_including_depot_unload_1228  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_929  1
    load_1_10_18  segment_load_conservation_1173  1
    load_1_10_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_931  -25
    arc_1_10_19  connected_order_arc_932  -14
    arc_1_10_19  out_degree_1169  1
    arc_1_10_19  in_degree_1201  1
    arc_1_10_19  original_T_including_depot_unload_1228  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_931  1
    load_1_10_19  segment_load_conservation_1173  1
    load_1_10_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_933  -25
    arc_1_10_20  connected_order_arc_934  -14
    arc_1_10_20  out_degree_1169  1
    arc_1_10_20  in_degree_1207  1
    arc_1_10_20  original_T_including_depot_unload_1228  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_933  1
    load_1_10_20  segment_load_conservation_1173  1
    load_1_10_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_935  -25
    arc_1_10_21  connected_order_arc_936  -14
    arc_1_10_21  out_degree_1169  1
    arc_1_10_21  in_degree_1213  1
    arc_1_10_21  original_T_including_depot_unload_1228  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_935  1
    load_1_10_21  segment_load_conservation_1173  1
    load_1_10_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_937  -25
    arc_1_10_22  connected_order_arc_938  -14
    arc_1_10_22  out_degree_1169  1
    arc_1_10_22  in_degree_1219  1
    arc_1_10_22  original_T_including_depot_unload_1228  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_937  1
    load_1_10_22  segment_load_conservation_1173  1
    load_1_10_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_939  -25
    arc_1_15_0  depot_return_or_bypass_1140  1
    arc_1_15_0  out_degree_1176  1
    arc_1_15_0  original_T_including_depot_unload_1228  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_939  1
    load_1_15_0  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_940  -25
    arc_1_15_6  connected_order_arc_941  -14
    arc_1_15_6  in_degree_1142  1
    arc_1_15_6  out_degree_1176  1
    arc_1_15_6  original_T_including_depot_unload_1228  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_940  1
    load_1_15_6  segment_load_conservation_1145  -1
    load_1_15_6  segment_prefix_lb_1146  1
    load_1_15_6  segment_prefix_ub_1147  1
    load_1_15_6  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_942  -25
    arc_1_15_7  connected_order_arc_943  -14
    arc_1_15_7  in_degree_1149  1
    arc_1_15_7  out_degree_1176  1
    arc_1_15_7  original_T_including_depot_unload_1228  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_942  1
    load_1_15_7  segment_load_conservation_1152  -1
    load_1_15_7  segment_prefix_lb_1153  1
    load_1_15_7  segment_prefix_ub_1154  1
    load_1_15_7  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_944  -25
    arc_1_15_8  connected_order_arc_945  -14
    arc_1_15_8  in_degree_1156  1
    arc_1_15_8  out_degree_1176  1
    arc_1_15_8  original_T_including_depot_unload_1228  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_944  1
    load_1_15_8  segment_load_conservation_1159  -1
    load_1_15_8  segment_prefix_lb_1160  1
    load_1_15_8  segment_prefix_ub_1161  1
    load_1_15_8  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_946  -25
    arc_1_15_9  connected_order_arc_947  -14
    arc_1_15_9  in_degree_1163  1
    arc_1_15_9  out_degree_1176  1
    arc_1_15_9  original_T_including_depot_unload_1228  1.7644788835951622e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_946  1
    load_1_15_9  segment_load_conservation_1166  -1
    load_1_15_9  segment_prefix_lb_1167  1
    load_1_15_9  segment_prefix_ub_1168  1
    load_1_15_9  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_948  -25
    arc_1_15_10  connected_order_arc_949  -14
    arc_1_15_10  in_degree_1170  1
    arc_1_15_10  out_degree_1176  1
    arc_1_15_10  original_T_including_depot_unload_1228  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_948  1
    load_1_15_10  segment_load_conservation_1173  -1
    load_1_15_10  segment_prefix_lb_1174  1
    load_1_15_10  segment_prefix_ub_1175  1
    load_1_15_10  free_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_950  -25
    arc_1_15_16  connected_order_arc_951  -14
    arc_1_15_16  out_degree_1176  1
    arc_1_15_16  in_degree_1183  1
    arc_1_15_16  original_T_including_depot_unload_1228  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_950  1
    load_1_15_16  free_load_conservation_1181  1
    load_1_15_16  free_load_conservation_1187  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_952  -25
    arc_1_15_17  connected_order_arc_953  -14
    arc_1_15_17  out_degree_1176  1
    arc_1_15_17  in_degree_1189  1
    arc_1_15_17  original_T_including_depot_unload_1228  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_952  1
    load_1_15_17  free_load_conservation_1181  1
    load_1_15_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_954  -25
    arc_1_15_18  connected_order_arc_955  -14
    arc_1_15_18  out_degree_1176  1
    arc_1_15_18  in_degree_1195  1
    arc_1_15_18  original_T_including_depot_unload_1228  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_954  1
    load_1_15_18  free_load_conservation_1181  1
    load_1_15_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_956  -25
    arc_1_15_19  connected_order_arc_957  -14
    arc_1_15_19  out_degree_1176  1
    arc_1_15_19  in_degree_1201  1
    arc_1_15_19  original_T_including_depot_unload_1228  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_956  1
    load_1_15_19  free_load_conservation_1181  1
    load_1_15_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_958  -25
    arc_1_15_20  connected_order_arc_959  -14
    arc_1_15_20  out_degree_1176  1
    arc_1_15_20  in_degree_1207  1
    arc_1_15_20  original_T_including_depot_unload_1228  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_958  1
    load_1_15_20  free_load_conservation_1181  1
    load_1_15_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_960  -25
    arc_1_15_21  connected_order_arc_961  -14
    arc_1_15_21  out_degree_1176  1
    arc_1_15_21  in_degree_1213  1
    arc_1_15_21  original_T_including_depot_unload_1228  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_960  1
    load_1_15_21  free_load_conservation_1181  1
    load_1_15_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_962  -25
    arc_1_15_22  connected_order_arc_963  -14
    arc_1_15_22  out_degree_1176  1
    arc_1_15_22  in_degree_1219  1
    arc_1_15_22  original_T_including_depot_unload_1228  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_962  1
    load_1_15_22  free_load_conservation_1181  1
    load_1_15_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_964  -25
    arc_1_16_0  depot_return_or_bypass_1140  1
    arc_1_16_0  out_degree_1182  1
    arc_1_16_0  original_T_including_depot_unload_1228  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_964  1
    load_1_16_0  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_965  -25
    arc_1_16_6  connected_order_arc_966  -14
    arc_1_16_6  in_degree_1142  1
    arc_1_16_6  out_degree_1182  1
    arc_1_16_6  original_T_including_depot_unload_1228  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_965  1
    load_1_16_6  segment_load_conservation_1145  -1
    load_1_16_6  segment_prefix_lb_1146  1
    load_1_16_6  segment_prefix_ub_1147  1
    load_1_16_6  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_967  -25
    arc_1_16_7  connected_order_arc_968  -14
    arc_1_16_7  in_degree_1149  1
    arc_1_16_7  out_degree_1182  1
    arc_1_16_7  original_T_including_depot_unload_1228  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_967  1
    load_1_16_7  segment_load_conservation_1152  -1
    load_1_16_7  segment_prefix_lb_1153  1
    load_1_16_7  segment_prefix_ub_1154  1
    load_1_16_7  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_969  -25
    arc_1_16_8  connected_order_arc_970  -14
    arc_1_16_8  in_degree_1156  1
    arc_1_16_8  out_degree_1182  1
    arc_1_16_8  original_T_including_depot_unload_1228  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_969  1
    load_1_16_8  segment_load_conservation_1159  -1
    load_1_16_8  segment_prefix_lb_1160  1
    load_1_16_8  segment_prefix_ub_1161  1
    load_1_16_8  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_971  -25
    arc_1_16_9  connected_order_arc_972  -14
    arc_1_16_9  in_degree_1163  1
    arc_1_16_9  out_degree_1182  1
    arc_1_16_9  original_T_including_depot_unload_1228  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_971  1
    load_1_16_9  segment_load_conservation_1166  -1
    load_1_16_9  segment_prefix_lb_1167  1
    load_1_16_9  segment_prefix_ub_1168  1
    load_1_16_9  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_973  -25
    arc_1_16_10  connected_order_arc_974  -14
    arc_1_16_10  in_degree_1170  1
    arc_1_16_10  out_degree_1182  1
    arc_1_16_10  original_T_including_depot_unload_1228  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_973  1
    load_1_16_10  segment_load_conservation_1173  -1
    load_1_16_10  segment_prefix_lb_1174  1
    load_1_16_10  segment_prefix_ub_1175  1
    load_1_16_10  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_975  -25
    arc_1_16_15  connected_order_arc_976  -14
    arc_1_16_15  in_degree_1177  1
    arc_1_16_15  out_degree_1182  1
    arc_1_16_15  original_T_including_depot_unload_1228  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_975  1
    load_1_16_15  free_load_conservation_1181  -1
    load_1_16_15  free_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_977  -25
    arc_1_16_17  connected_order_arc_978  -14
    arc_1_16_17  out_degree_1182  1
    arc_1_16_17  in_degree_1189  1
    arc_1_16_17  original_T_including_depot_unload_1228  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_977  1
    load_1_16_17  free_load_conservation_1187  1
    load_1_16_17  free_load_conservation_1193  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_979  -25
    arc_1_16_18  connected_order_arc_980  -14
    arc_1_16_18  out_degree_1182  1
    arc_1_16_18  in_degree_1195  1
    arc_1_16_18  original_T_including_depot_unload_1228  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_979  1
    load_1_16_18  free_load_conservation_1187  1
    load_1_16_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_981  -25
    arc_1_16_19  connected_order_arc_982  -14
    arc_1_16_19  out_degree_1182  1
    arc_1_16_19  in_degree_1201  1
    arc_1_16_19  original_T_including_depot_unload_1228  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_981  1
    load_1_16_19  free_load_conservation_1187  1
    load_1_16_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_983  -25
    arc_1_16_20  connected_order_arc_984  -14
    arc_1_16_20  out_degree_1182  1
    arc_1_16_20  in_degree_1207  1
    arc_1_16_20  original_T_including_depot_unload_1228  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_983  1
    load_1_16_20  free_load_conservation_1187  1
    load_1_16_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_985  -25
    arc_1_16_21  connected_order_arc_986  -14
    arc_1_16_21  out_degree_1182  1
    arc_1_16_21  in_degree_1213  1
    arc_1_16_21  original_T_including_depot_unload_1228  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_985  1
    load_1_16_21  free_load_conservation_1187  1
    load_1_16_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_987  -25
    arc_1_16_22  connected_order_arc_988  -14
    arc_1_16_22  out_degree_1182  1
    arc_1_16_22  in_degree_1219  1
    arc_1_16_22  original_T_including_depot_unload_1228  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_987  1
    load_1_16_22  free_load_conservation_1187  1
    load_1_16_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_989  -25
    arc_1_17_0  depot_return_or_bypass_1140  1
    arc_1_17_0  out_degree_1188  1
    arc_1_17_0  original_T_including_depot_unload_1228  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_989  1
    load_1_17_0  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_990  -25
    arc_1_17_6  connected_order_arc_991  -14
    arc_1_17_6  in_degree_1142  1
    arc_1_17_6  out_degree_1188  1
    arc_1_17_6  original_T_including_depot_unload_1228  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_990  1
    load_1_17_6  segment_load_conservation_1145  -1
    load_1_17_6  segment_prefix_lb_1146  1
    load_1_17_6  segment_prefix_ub_1147  1
    load_1_17_6  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_992  -25
    arc_1_17_7  connected_order_arc_993  -14
    arc_1_17_7  in_degree_1149  1
    arc_1_17_7  out_degree_1188  1
    arc_1_17_7  original_T_including_depot_unload_1228  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_992  1
    load_1_17_7  segment_load_conservation_1152  -1
    load_1_17_7  segment_prefix_lb_1153  1
    load_1_17_7  segment_prefix_ub_1154  1
    load_1_17_7  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_994  -25
    arc_1_17_8  connected_order_arc_995  -14
    arc_1_17_8  in_degree_1156  1
    arc_1_17_8  out_degree_1188  1
    arc_1_17_8  original_T_including_depot_unload_1228  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_994  1
    load_1_17_8  segment_load_conservation_1159  -1
    load_1_17_8  segment_prefix_lb_1160  1
    load_1_17_8  segment_prefix_ub_1161  1
    load_1_17_8  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_996  -25
    arc_1_17_9  connected_order_arc_997  -14
    arc_1_17_9  in_degree_1163  1
    arc_1_17_9  out_degree_1188  1
    arc_1_17_9  original_T_including_depot_unload_1228  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_996  1
    load_1_17_9  segment_load_conservation_1166  -1
    load_1_17_9  segment_prefix_lb_1167  1
    load_1_17_9  segment_prefix_ub_1168  1
    load_1_17_9  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_998  -25
    arc_1_17_10  connected_order_arc_999  -14
    arc_1_17_10  in_degree_1170  1
    arc_1_17_10  out_degree_1188  1
    arc_1_17_10  original_T_including_depot_unload_1228  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_998  1
    load_1_17_10  segment_load_conservation_1173  -1
    load_1_17_10  segment_prefix_lb_1174  1
    load_1_17_10  segment_prefix_ub_1175  1
    load_1_17_10  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1000  -25
    arc_1_17_15  connected_order_arc_1001  -14
    arc_1_17_15  in_degree_1177  1
    arc_1_17_15  out_degree_1188  1
    arc_1_17_15  original_T_including_depot_unload_1228  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1000  1
    load_1_17_15  free_load_conservation_1181  -1
    load_1_17_15  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1002  -25
    arc_1_17_16  connected_order_arc_1003  -14
    arc_1_17_16  in_degree_1183  1
    arc_1_17_16  out_degree_1188  1
    arc_1_17_16  original_T_including_depot_unload_1228  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1002  1
    load_1_17_16  free_load_conservation_1187  -1
    load_1_17_16  free_load_conservation_1193  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1004  -25
    arc_1_17_18  connected_order_arc_1005  -14
    arc_1_17_18  out_degree_1188  1
    arc_1_17_18  in_degree_1195  1
    arc_1_17_18  original_T_including_depot_unload_1228  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1004  1
    load_1_17_18  free_load_conservation_1193  1
    load_1_17_18  free_load_conservation_1199  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1006  -25
    arc_1_17_19  connected_order_arc_1007  -14
    arc_1_17_19  out_degree_1188  1
    arc_1_17_19  in_degree_1201  1
    arc_1_17_19  original_T_including_depot_unload_1228  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1006  1
    load_1_17_19  free_load_conservation_1193  1
    load_1_17_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1008  -25
    arc_1_17_20  connected_order_arc_1009  -14
    arc_1_17_20  out_degree_1188  1
    arc_1_17_20  in_degree_1207  1
    arc_1_17_20  original_T_including_depot_unload_1228  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1008  1
    load_1_17_20  free_load_conservation_1193  1
    load_1_17_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1010  -25
    arc_1_17_21  connected_order_arc_1011  -14
    arc_1_17_21  out_degree_1188  1
    arc_1_17_21  in_degree_1213  1
    arc_1_17_21  original_T_including_depot_unload_1228  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1010  1
    load_1_17_21  free_load_conservation_1193  1
    load_1_17_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1012  -25
    arc_1_17_22  connected_order_arc_1013  -14
    arc_1_17_22  out_degree_1188  1
    arc_1_17_22  in_degree_1219  1
    arc_1_17_22  original_T_including_depot_unload_1228  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1012  1
    load_1_17_22  free_load_conservation_1193  1
    load_1_17_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1014  -25
    arc_1_18_0  depot_return_or_bypass_1140  1
    arc_1_18_0  out_degree_1194  1
    arc_1_18_0  original_T_including_depot_unload_1228  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1014  1
    load_1_18_0  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1015  -25
    arc_1_18_6  connected_order_arc_1016  -14
    arc_1_18_6  in_degree_1142  1
    arc_1_18_6  out_degree_1194  1
    arc_1_18_6  original_T_including_depot_unload_1228  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1015  1
    load_1_18_6  segment_load_conservation_1145  -1
    load_1_18_6  segment_prefix_lb_1146  1
    load_1_18_6  segment_prefix_ub_1147  1
    load_1_18_6  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1017  -25
    arc_1_18_7  connected_order_arc_1018  -14
    arc_1_18_7  in_degree_1149  1
    arc_1_18_7  out_degree_1194  1
    arc_1_18_7  original_T_including_depot_unload_1228  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1017  1
    load_1_18_7  segment_load_conservation_1152  -1
    load_1_18_7  segment_prefix_lb_1153  1
    load_1_18_7  segment_prefix_ub_1154  1
    load_1_18_7  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1019  -25
    arc_1_18_8  connected_order_arc_1020  -14
    arc_1_18_8  in_degree_1156  1
    arc_1_18_8  out_degree_1194  1
    arc_1_18_8  original_T_including_depot_unload_1228  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1019  1
    load_1_18_8  segment_load_conservation_1159  -1
    load_1_18_8  segment_prefix_lb_1160  1
    load_1_18_8  segment_prefix_ub_1161  1
    load_1_18_8  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1021  -25
    arc_1_18_9  connected_order_arc_1022  -14
    arc_1_18_9  in_degree_1163  1
    arc_1_18_9  out_degree_1194  1
    arc_1_18_9  original_T_including_depot_unload_1228  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1021  1
    load_1_18_9  segment_load_conservation_1166  -1
    load_1_18_9  segment_prefix_lb_1167  1
    load_1_18_9  segment_prefix_ub_1168  1
    load_1_18_9  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1023  -25
    arc_1_18_10  connected_order_arc_1024  -14
    arc_1_18_10  in_degree_1170  1
    arc_1_18_10  out_degree_1194  1
    arc_1_18_10  original_T_including_depot_unload_1228  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1023  1
    load_1_18_10  segment_load_conservation_1173  -1
    load_1_18_10  segment_prefix_lb_1174  1
    load_1_18_10  segment_prefix_ub_1175  1
    load_1_18_10  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1025  -25
    arc_1_18_15  connected_order_arc_1026  -14
    arc_1_18_15  in_degree_1177  1
    arc_1_18_15  out_degree_1194  1
    arc_1_18_15  original_T_including_depot_unload_1228  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1025  1
    load_1_18_15  free_load_conservation_1181  -1
    load_1_18_15  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1027  -25
    arc_1_18_16  connected_order_arc_1028  -14
    arc_1_18_16  in_degree_1183  1
    arc_1_18_16  out_degree_1194  1
    arc_1_18_16  original_T_including_depot_unload_1228  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1027  1
    load_1_18_16  free_load_conservation_1187  -1
    load_1_18_16  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1029  -25
    arc_1_18_17  connected_order_arc_1030  -14
    arc_1_18_17  in_degree_1189  1
    arc_1_18_17  out_degree_1194  1
    arc_1_18_17  original_T_including_depot_unload_1228  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1029  1
    load_1_18_17  free_load_conservation_1193  -1
    load_1_18_17  free_load_conservation_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1031  -25
    arc_1_18_19  connected_order_arc_1032  -14
    arc_1_18_19  out_degree_1194  1
    arc_1_18_19  in_degree_1201  1
    arc_1_18_19  original_T_including_depot_unload_1228  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1031  1
    load_1_18_19  free_load_conservation_1199  1
    load_1_18_19  free_load_conservation_1205  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1033  -25
    arc_1_18_20  connected_order_arc_1034  -14
    arc_1_18_20  out_degree_1194  1
    arc_1_18_20  in_degree_1207  1
    arc_1_18_20  original_T_including_depot_unload_1228  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1033  1
    load_1_18_20  free_load_conservation_1199  1
    load_1_18_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1035  -25
    arc_1_18_21  connected_order_arc_1036  -14
    arc_1_18_21  out_degree_1194  1
    arc_1_18_21  in_degree_1213  1
    arc_1_18_21  original_T_including_depot_unload_1228  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1035  1
    load_1_18_21  free_load_conservation_1199  1
    load_1_18_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1037  -25
    arc_1_18_22  connected_order_arc_1038  -14
    arc_1_18_22  out_degree_1194  1
    arc_1_18_22  in_degree_1219  1
    arc_1_18_22  original_T_including_depot_unload_1228  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1037  1
    load_1_18_22  free_load_conservation_1199  1
    load_1_18_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1039  -25
    arc_1_19_0  depot_return_or_bypass_1140  1
    arc_1_19_0  out_degree_1200  1
    arc_1_19_0  original_T_including_depot_unload_1228  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1039  1
    load_1_19_0  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1040  -25
    arc_1_19_6  connected_order_arc_1041  -14
    arc_1_19_6  in_degree_1142  1
    arc_1_19_6  out_degree_1200  1
    arc_1_19_6  original_T_including_depot_unload_1228  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1040  1
    load_1_19_6  segment_load_conservation_1145  -1
    load_1_19_6  segment_prefix_lb_1146  1
    load_1_19_6  segment_prefix_ub_1147  1
    load_1_19_6  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1042  -25
    arc_1_19_7  connected_order_arc_1043  -14
    arc_1_19_7  in_degree_1149  1
    arc_1_19_7  out_degree_1200  1
    arc_1_19_7  original_T_including_depot_unload_1228  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1042  1
    load_1_19_7  segment_load_conservation_1152  -1
    load_1_19_7  segment_prefix_lb_1153  1
    load_1_19_7  segment_prefix_ub_1154  1
    load_1_19_7  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1044  -25
    arc_1_19_8  connected_order_arc_1045  -14
    arc_1_19_8  in_degree_1156  1
    arc_1_19_8  out_degree_1200  1
    arc_1_19_8  original_T_including_depot_unload_1228  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1044  1
    load_1_19_8  segment_load_conservation_1159  -1
    load_1_19_8  segment_prefix_lb_1160  1
    load_1_19_8  segment_prefix_ub_1161  1
    load_1_19_8  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1046  -25
    arc_1_19_9  connected_order_arc_1047  -14
    arc_1_19_9  in_degree_1163  1
    arc_1_19_9  out_degree_1200  1
    arc_1_19_9  original_T_including_depot_unload_1228  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1046  1
    load_1_19_9  segment_load_conservation_1166  -1
    load_1_19_9  segment_prefix_lb_1167  1
    load_1_19_9  segment_prefix_ub_1168  1
    load_1_19_9  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1048  -25
    arc_1_19_10  connected_order_arc_1049  -14
    arc_1_19_10  in_degree_1170  1
    arc_1_19_10  out_degree_1200  1
    arc_1_19_10  original_T_including_depot_unload_1228  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1048  1
    load_1_19_10  segment_load_conservation_1173  -1
    load_1_19_10  segment_prefix_lb_1174  1
    load_1_19_10  segment_prefix_ub_1175  1
    load_1_19_10  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1050  -25
    arc_1_19_15  connected_order_arc_1051  -14
    arc_1_19_15  in_degree_1177  1
    arc_1_19_15  out_degree_1200  1
    arc_1_19_15  original_T_including_depot_unload_1228  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1050  1
    load_1_19_15  free_load_conservation_1181  -1
    load_1_19_15  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1052  -25
    arc_1_19_16  connected_order_arc_1053  -14
    arc_1_19_16  in_degree_1183  1
    arc_1_19_16  out_degree_1200  1
    arc_1_19_16  original_T_including_depot_unload_1228  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1052  1
    load_1_19_16  free_load_conservation_1187  -1
    load_1_19_16  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1054  -25
    arc_1_19_17  connected_order_arc_1055  -14
    arc_1_19_17  in_degree_1189  1
    arc_1_19_17  out_degree_1200  1
    arc_1_19_17  original_T_including_depot_unload_1228  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1054  1
    load_1_19_17  free_load_conservation_1193  -1
    load_1_19_17  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1056  -25
    arc_1_19_18  connected_order_arc_1057  -14
    arc_1_19_18  in_degree_1195  1
    arc_1_19_18  out_degree_1200  1
    arc_1_19_18  original_T_including_depot_unload_1228  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1056  1
    load_1_19_18  free_load_conservation_1199  -1
    load_1_19_18  free_load_conservation_1205  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1058  -25
    arc_1_19_20  connected_order_arc_1059  -14
    arc_1_19_20  out_degree_1200  1
    arc_1_19_20  in_degree_1207  1
    arc_1_19_20  original_T_including_depot_unload_1228  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1058  1
    load_1_19_20  free_load_conservation_1205  1
    load_1_19_20  free_load_conservation_1211  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1060  -25
    arc_1_19_21  connected_order_arc_1061  -14
    arc_1_19_21  out_degree_1200  1
    arc_1_19_21  in_degree_1213  1
    arc_1_19_21  original_T_including_depot_unload_1228  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1060  1
    load_1_19_21  free_load_conservation_1205  1
    load_1_19_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1062  -25
    arc_1_19_22  connected_order_arc_1063  -14
    arc_1_19_22  out_degree_1200  1
    arc_1_19_22  in_degree_1219  1
    arc_1_19_22  original_T_including_depot_unload_1228  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1062  1
    load_1_19_22  free_load_conservation_1205  1
    load_1_19_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1064  -25
    arc_1_20_0  depot_return_or_bypass_1140  1
    arc_1_20_0  out_degree_1206  1
    arc_1_20_0  original_T_including_depot_unload_1228  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1064  1
    load_1_20_0  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1065  -25
    arc_1_20_6  connected_order_arc_1066  -14
    arc_1_20_6  in_degree_1142  1
    arc_1_20_6  out_degree_1206  1
    arc_1_20_6  original_T_including_depot_unload_1228  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1065  1
    load_1_20_6  segment_load_conservation_1145  -1
    load_1_20_6  segment_prefix_lb_1146  1
    load_1_20_6  segment_prefix_ub_1147  1
    load_1_20_6  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1067  -25
    arc_1_20_7  connected_order_arc_1068  -14
    arc_1_20_7  in_degree_1149  1
    arc_1_20_7  out_degree_1206  1
    arc_1_20_7  original_T_including_depot_unload_1228  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1067  1
    load_1_20_7  segment_load_conservation_1152  -1
    load_1_20_7  segment_prefix_lb_1153  1
    load_1_20_7  segment_prefix_ub_1154  1
    load_1_20_7  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1069  -25
    arc_1_20_8  connected_order_arc_1070  -14
    arc_1_20_8  in_degree_1156  1
    arc_1_20_8  out_degree_1206  1
    arc_1_20_8  original_T_including_depot_unload_1228  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1069  1
    load_1_20_8  segment_load_conservation_1159  -1
    load_1_20_8  segment_prefix_lb_1160  1
    load_1_20_8  segment_prefix_ub_1161  1
    load_1_20_8  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1071  -25
    arc_1_20_9  connected_order_arc_1072  -14
    arc_1_20_9  in_degree_1163  1
    arc_1_20_9  out_degree_1206  1
    arc_1_20_9  original_T_including_depot_unload_1228  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1071  1
    load_1_20_9  segment_load_conservation_1166  -1
    load_1_20_9  segment_prefix_lb_1167  1
    load_1_20_9  segment_prefix_ub_1168  1
    load_1_20_9  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1073  -25
    arc_1_20_10  connected_order_arc_1074  -14
    arc_1_20_10  in_degree_1170  1
    arc_1_20_10  out_degree_1206  1
    arc_1_20_10  original_T_including_depot_unload_1228  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1073  1
    load_1_20_10  segment_load_conservation_1173  -1
    load_1_20_10  segment_prefix_lb_1174  1
    load_1_20_10  segment_prefix_ub_1175  1
    load_1_20_10  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1075  -25
    arc_1_20_15  connected_order_arc_1076  -14
    arc_1_20_15  in_degree_1177  1
    arc_1_20_15  out_degree_1206  1
    arc_1_20_15  original_T_including_depot_unload_1228  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1075  1
    load_1_20_15  free_load_conservation_1181  -1
    load_1_20_15  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1077  -25
    arc_1_20_16  connected_order_arc_1078  -14
    arc_1_20_16  in_degree_1183  1
    arc_1_20_16  out_degree_1206  1
    arc_1_20_16  original_T_including_depot_unload_1228  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1077  1
    load_1_20_16  free_load_conservation_1187  -1
    load_1_20_16  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1079  -25
    arc_1_20_17  connected_order_arc_1080  -14
    arc_1_20_17  in_degree_1189  1
    arc_1_20_17  out_degree_1206  1
    arc_1_20_17  original_T_including_depot_unload_1228  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1079  1
    load_1_20_17  free_load_conservation_1193  -1
    load_1_20_17  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1081  -25
    arc_1_20_18  connected_order_arc_1082  -14
    arc_1_20_18  in_degree_1195  1
    arc_1_20_18  out_degree_1206  1
    arc_1_20_18  original_T_including_depot_unload_1228  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1081  1
    load_1_20_18  free_load_conservation_1199  -1
    load_1_20_18  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1083  -25
    arc_1_20_19  connected_order_arc_1084  -14
    arc_1_20_19  in_degree_1201  1
    arc_1_20_19  out_degree_1206  1
    arc_1_20_19  original_T_including_depot_unload_1228  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1083  1
    load_1_20_19  free_load_conservation_1205  -1
    load_1_20_19  free_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1085  -25
    arc_1_20_21  connected_order_arc_1086  -14
    arc_1_20_21  out_degree_1206  1
    arc_1_20_21  in_degree_1213  1
    arc_1_20_21  original_T_including_depot_unload_1228  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1085  1
    load_1_20_21  free_load_conservation_1211  1
    load_1_20_21  free_load_conservation_1217  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1087  -25
    arc_1_20_22  connected_order_arc_1088  -14
    arc_1_20_22  out_degree_1206  1
    arc_1_20_22  in_degree_1219  1
    arc_1_20_22  original_T_including_depot_unload_1228  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1087  1
    load_1_20_22  free_load_conservation_1211  1
    load_1_20_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1089  -25
    arc_1_21_0  depot_return_or_bypass_1140  1
    arc_1_21_0  out_degree_1212  1
    arc_1_21_0  original_T_including_depot_unload_1228  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1089  1
    load_1_21_0  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1090  -25
    arc_1_21_6  connected_order_arc_1091  -14
    arc_1_21_6  in_degree_1142  1
    arc_1_21_6  out_degree_1212  1
    arc_1_21_6  original_T_including_depot_unload_1228  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1090  1
    load_1_21_6  segment_load_conservation_1145  -1
    load_1_21_6  segment_prefix_lb_1146  1
    load_1_21_6  segment_prefix_ub_1147  1
    load_1_21_6  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1092  -25
    arc_1_21_7  connected_order_arc_1093  -14
    arc_1_21_7  in_degree_1149  1
    arc_1_21_7  out_degree_1212  1
    arc_1_21_7  original_T_including_depot_unload_1228  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1092  1
    load_1_21_7  segment_load_conservation_1152  -1
    load_1_21_7  segment_prefix_lb_1153  1
    load_1_21_7  segment_prefix_ub_1154  1
    load_1_21_7  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1094  -25
    arc_1_21_8  connected_order_arc_1095  -14
    arc_1_21_8  in_degree_1156  1
    arc_1_21_8  out_degree_1212  1
    arc_1_21_8  original_T_including_depot_unload_1228  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1094  1
    load_1_21_8  segment_load_conservation_1159  -1
    load_1_21_8  segment_prefix_lb_1160  1
    load_1_21_8  segment_prefix_ub_1161  1
    load_1_21_8  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1096  -25
    arc_1_21_9  connected_order_arc_1097  -14
    arc_1_21_9  in_degree_1163  1
    arc_1_21_9  out_degree_1212  1
    arc_1_21_9  original_T_including_depot_unload_1228  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1096  1
    load_1_21_9  segment_load_conservation_1166  -1
    load_1_21_9  segment_prefix_lb_1167  1
    load_1_21_9  segment_prefix_ub_1168  1
    load_1_21_9  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1098  -25
    arc_1_21_10  connected_order_arc_1099  -14
    arc_1_21_10  in_degree_1170  1
    arc_1_21_10  out_degree_1212  1
    arc_1_21_10  original_T_including_depot_unload_1228  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1098  1
    load_1_21_10  segment_load_conservation_1173  -1
    load_1_21_10  segment_prefix_lb_1174  1
    load_1_21_10  segment_prefix_ub_1175  1
    load_1_21_10  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1100  -25
    arc_1_21_15  connected_order_arc_1101  -14
    arc_1_21_15  in_degree_1177  1
    arc_1_21_15  out_degree_1212  1
    arc_1_21_15  original_T_including_depot_unload_1228  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1100  1
    load_1_21_15  free_load_conservation_1181  -1
    load_1_21_15  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1102  -25
    arc_1_21_16  connected_order_arc_1103  -14
    arc_1_21_16  in_degree_1183  1
    arc_1_21_16  out_degree_1212  1
    arc_1_21_16  original_T_including_depot_unload_1228  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1102  1
    load_1_21_16  free_load_conservation_1187  -1
    load_1_21_16  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1104  -25
    arc_1_21_17  connected_order_arc_1105  -14
    arc_1_21_17  in_degree_1189  1
    arc_1_21_17  out_degree_1212  1
    arc_1_21_17  original_T_including_depot_unload_1228  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1104  1
    load_1_21_17  free_load_conservation_1193  -1
    load_1_21_17  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1106  -25
    arc_1_21_18  connected_order_arc_1107  -14
    arc_1_21_18  in_degree_1195  1
    arc_1_21_18  out_degree_1212  1
    arc_1_21_18  original_T_including_depot_unload_1228  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1106  1
    load_1_21_18  free_load_conservation_1199  -1
    load_1_21_18  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1108  -25
    arc_1_21_19  connected_order_arc_1109  -14
    arc_1_21_19  in_degree_1201  1
    arc_1_21_19  out_degree_1212  1
    arc_1_21_19  original_T_including_depot_unload_1228  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1108  1
    load_1_21_19  free_load_conservation_1205  -1
    load_1_21_19  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1110  -25
    arc_1_21_20  connected_order_arc_1111  -14
    arc_1_21_20  in_degree_1207  1
    arc_1_21_20  out_degree_1212  1
    arc_1_21_20  original_T_including_depot_unload_1228  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1110  1
    load_1_21_20  free_load_conservation_1211  -1
    load_1_21_20  free_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1112  -25
    arc_1_21_22  connected_order_arc_1113  -14
    arc_1_21_22  out_degree_1212  1
    arc_1_21_22  in_degree_1219  1
    arc_1_21_22  original_T_including_depot_unload_1228  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1112  1
    load_1_21_22  free_load_conservation_1217  1
    load_1_21_22  free_load_conservation_1223  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1114  -25
    arc_1_22_0  depot_return_or_bypass_1140  1
    arc_1_22_0  out_degree_1218  1
    arc_1_22_0  original_T_including_depot_unload_1228  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1114  1
    load_1_22_0  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_6  arc_capacity_1115  -25
    arc_1_22_6  connected_order_arc_1116  -14
    arc_1_22_6  in_degree_1142  1
    arc_1_22_6  out_degree_1218  1
    arc_1_22_6  original_T_including_depot_unload_1228  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_6  arc_capacity_1115  1
    load_1_22_6  segment_load_conservation_1145  -1
    load_1_22_6  segment_prefix_lb_1146  1
    load_1_22_6  segment_prefix_ub_1147  1
    load_1_22_6  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1117  -25
    arc_1_22_7  connected_order_arc_1118  -14
    arc_1_22_7  in_degree_1149  1
    arc_1_22_7  out_degree_1218  1
    arc_1_22_7  original_T_including_depot_unload_1228  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1117  1
    load_1_22_7  segment_load_conservation_1152  -1
    load_1_22_7  segment_prefix_lb_1153  1
    load_1_22_7  segment_prefix_ub_1154  1
    load_1_22_7  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1119  -25
    arc_1_22_8  connected_order_arc_1120  -14
    arc_1_22_8  in_degree_1156  1
    arc_1_22_8  out_degree_1218  1
    arc_1_22_8  original_T_including_depot_unload_1228  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1119  1
    load_1_22_8  segment_load_conservation_1159  -1
    load_1_22_8  segment_prefix_lb_1160  1
    load_1_22_8  segment_prefix_ub_1161  1
    load_1_22_8  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1121  -25
    arc_1_22_9  connected_order_arc_1122  -14
    arc_1_22_9  in_degree_1163  1
    arc_1_22_9  out_degree_1218  1
    arc_1_22_9  original_T_including_depot_unload_1228  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1121  1
    load_1_22_9  segment_load_conservation_1166  -1
    load_1_22_9  segment_prefix_lb_1167  1
    load_1_22_9  segment_prefix_ub_1168  1
    load_1_22_9  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1123  -25
    arc_1_22_10  connected_order_arc_1124  -14
    arc_1_22_10  in_degree_1170  1
    arc_1_22_10  out_degree_1218  1
    arc_1_22_10  original_T_including_depot_unload_1228  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1123  1
    load_1_22_10  segment_load_conservation_1173  -1
    load_1_22_10  segment_prefix_lb_1174  1
    load_1_22_10  segment_prefix_ub_1175  1
    load_1_22_10  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1125  -25
    arc_1_22_15  connected_order_arc_1126  -14
    arc_1_22_15  in_degree_1177  1
    arc_1_22_15  out_degree_1218  1
    arc_1_22_15  original_T_including_depot_unload_1228  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1125  1
    load_1_22_15  free_load_conservation_1181  -1
    load_1_22_15  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1127  -25
    arc_1_22_16  connected_order_arc_1128  -14
    arc_1_22_16  in_degree_1183  1
    arc_1_22_16  out_degree_1218  1
    arc_1_22_16  original_T_including_depot_unload_1228  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1127  1
    load_1_22_16  free_load_conservation_1187  -1
    load_1_22_16  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1129  -25
    arc_1_22_17  connected_order_arc_1130  -14
    arc_1_22_17  in_degree_1189  1
    arc_1_22_17  out_degree_1218  1
    arc_1_22_17  original_T_including_depot_unload_1228  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1129  1
    load_1_22_17  free_load_conservation_1193  -1
    load_1_22_17  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1131  -25
    arc_1_22_18  connected_order_arc_1132  -14
    arc_1_22_18  in_degree_1195  1
    arc_1_22_18  out_degree_1218  1
    arc_1_22_18  original_T_including_depot_unload_1228  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1131  1
    load_1_22_18  free_load_conservation_1199  -1
    load_1_22_18  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1133  -25
    arc_1_22_19  connected_order_arc_1134  -14
    arc_1_22_19  in_degree_1201  1
    arc_1_22_19  out_degree_1218  1
    arc_1_22_19  original_T_including_depot_unload_1228  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1133  1
    load_1_22_19  free_load_conservation_1205  -1
    load_1_22_19  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1135  -25
    arc_1_22_20  connected_order_arc_1136  -14
    arc_1_22_20  in_degree_1207  1
    arc_1_22_20  out_degree_1218  1
    arc_1_22_20  original_T_including_depot_unload_1228  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1135  1
    load_1_22_20  free_load_conservation_1211  -1
    load_1_22_20  free_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1137  -25
    arc_1_22_21  connected_order_arc_1138  -14
    arc_1_22_21  in_degree_1213  1
    arc_1_22_21  out_degree_1218  1
    arc_1_22_21  original_T_including_depot_unload_1228  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1137  1
    load_1_22_21  free_load_conservation_1217  -1
    load_1_22_21  free_load_conservation_1223  1
    visit_2_11  out_degree_1520  -1
    visit_2_11  in_degree_1521  -1
    visit_2_11  order_active_lb_1522  -1
    visit_2_11  order_active_ub_1523  -12
    order_2_11  connected_order_arc_1244  -1
    order_2_11  connected_order_arc_1246  -1
    order_2_11  connected_order_arc_1248  -1
    order_2_11  connected_order_arc_1250  -1
    order_2_11  connected_order_arc_1252  -1
    order_2_11  connected_order_arc_1254  -1
    order_2_11  connected_order_arc_1256  -1
    order_2_11  connected_order_arc_1258  -1
    order_2_11  connected_order_arc_1260  -1
    order_2_11  connected_order_arc_1262  -1
    order_2_11  connected_order_arc_1264  -1
    order_2_11  connected_order_arc_1267  1
    order_2_11  connected_order_arc_1290  1
    order_2_11  connected_order_arc_1313  1
    order_2_11  connected_order_arc_1336  1
    order_2_11  connected_order_arc_1359  1
    order_2_11  connected_order_arc_1382  1
    order_2_11  connected_order_arc_1405  1
    order_2_11  connected_order_arc_1428  1
    order_2_11  connected_order_arc_1451  1
    order_2_11  connected_order_arc_1474  1
    order_2_11  connected_order_arc_1497  1
    order_2_11  order_active_lb_1522  1
    order_2_11  order_active_ub_1523  1
    order_2_11  fixed_segment_relative_order_1596  -1
    visit_2_12  out_degree_1527  -1
    visit_2_12  in_degree_1528  -1
    visit_2_12  order_active_lb_1529  -1
    visit_2_12  order_active_ub_1530  -12
    order_2_12  connected_order_arc_1244  1
    order_2_12  connected_order_arc_1267  -1
    order_2_12  connected_order_arc_1269  -1
    order_2_12  connected_order_arc_1271  -1
    order_2_12  connected_order_arc_1273  -1
    order_2_12  connected_order_arc_1275  -1
    order_2_12  connected_order_arc_1277  -1
    order_2_12  connected_order_arc_1279  -1
    order_2_12  connected_order_arc_1281  -1
    order_2_12  connected_order_arc_1283  -1
    order_2_12  connected_order_arc_1285  -1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1292  1
    order_2_12  connected_order_arc_1315  1
    order_2_12  connected_order_arc_1338  1
    order_2_12  connected_order_arc_1361  1
    order_2_12  connected_order_arc_1384  1
    order_2_12  connected_order_arc_1407  1
    order_2_12  connected_order_arc_1430  1
    order_2_12  connected_order_arc_1453  1
    order_2_12  connected_order_arc_1476  1
    order_2_12  connected_order_arc_1499  1
    order_2_12  order_active_lb_1529  1
    order_2_12  order_active_ub_1530  1
    order_2_12  fixed_segment_relative_order_1596  1
    order_2_12  fixed_segment_relative_order_1597  -1
    visit_2_13  out_degree_1534  -1
    visit_2_13  in_degree_1535  -1
    visit_2_13  order_active_lb_1536  -1
    visit_2_13  order_active_ub_1537  -12
    order_2_13  connected_order_arc_1246  1
    order_2_13  connected_order_arc_1269  1
    order_2_13  connected_order_arc_1290  -1
    order_2_13  connected_order_arc_1292  -1
    order_2_13  connected_order_arc_1294  -1
    order_2_13  connected_order_arc_1296  -1
    order_2_13  connected_order_arc_1298  -1
    order_2_13  connected_order_arc_1300  -1
    order_2_13  connected_order_arc_1302  -1
    order_2_13  connected_order_arc_1304  -1
    order_2_13  connected_order_arc_1306  -1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1310  -1
    order_2_13  connected_order_arc_1317  1
    order_2_13  connected_order_arc_1340  1
    order_2_13  connected_order_arc_1363  1
    order_2_13  connected_order_arc_1386  1
    order_2_13  connected_order_arc_1409  1
    order_2_13  connected_order_arc_1432  1
    order_2_13  connected_order_arc_1455  1
    order_2_13  connected_order_arc_1478  1
    order_2_13  connected_order_arc_1501  1
    order_2_13  order_active_lb_1536  1
    order_2_13  order_active_ub_1537  1
    order_2_13  fixed_segment_relative_order_1597  1
    order_2_13  fixed_segment_relative_order_1598  -1
    visit_2_14  out_degree_1541  -1
    visit_2_14  in_degree_1542  -1
    visit_2_14  order_active_lb_1543  -1
    visit_2_14  order_active_ub_1544  -12
    order_2_14  connected_order_arc_1248  1
    order_2_14  connected_order_arc_1271  1
    order_2_14  connected_order_arc_1294  1
    order_2_14  connected_order_arc_1313  -1
    order_2_14  connected_order_arc_1315  -1
    order_2_14  connected_order_arc_1317  -1
    order_2_14  connected_order_arc_1319  -1
    order_2_14  connected_order_arc_1321  -1
    order_2_14  connected_order_arc_1323  -1
    order_2_14  connected_order_arc_1325  -1
    order_2_14  connected_order_arc_1327  -1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1331  -1
    order_2_14  connected_order_arc_1333  -1
    order_2_14  connected_order_arc_1342  1
    order_2_14  connected_order_arc_1365  1
    order_2_14  connected_order_arc_1388  1
    order_2_14  connected_order_arc_1411  1
    order_2_14  connected_order_arc_1434  1
    order_2_14  connected_order_arc_1457  1
    order_2_14  connected_order_arc_1480  1
    order_2_14  connected_order_arc_1503  1
    order_2_14  order_active_lb_1543  1
    order_2_14  order_active_ub_1544  1
    order_2_14  fixed_segment_relative_order_1598  1
    visit_2_15  out_degree_1548  -1
    visit_2_15  in_degree_1549  -1
    visit_2_15  order_active_lb_1550  -1
    visit_2_15  order_active_ub_1551  -12
    visit_2_15  service_visit_def_1552  -1
    order_2_15  connected_order_arc_1250  1
    order_2_15  connected_order_arc_1273  1
    order_2_15  connected_order_arc_1296  1
    order_2_15  connected_order_arc_1319  1
    order_2_15  connected_order_arc_1336  -1
    order_2_15  connected_order_arc_1338  -1
    order_2_15  connected_order_arc_1340  -1
    order_2_15  connected_order_arc_1342  -1
    order_2_15  connected_order_arc_1344  -1
    order_2_15  connected_order_arc_1346  -1
    order_2_15  connected_order_arc_1348  -1
    order_2_15  connected_order_arc_1350  -1
    order_2_15  connected_order_arc_1352  -1
    order_2_15  connected_order_arc_1354  -1
    order_2_15  connected_order_arc_1356  -1
    order_2_15  connected_order_arc_1367  1
    order_2_15  connected_order_arc_1390  1
    order_2_15  connected_order_arc_1413  1
    order_2_15  connected_order_arc_1436  1
    order_2_15  connected_order_arc_1459  1
    order_2_15  connected_order_arc_1482  1
    order_2_15  connected_order_arc_1505  1
    order_2_15  order_active_lb_1550  1
    order_2_15  order_active_ub_1551  1
    visit_2_16  out_degree_1554  -1
    visit_2_16  in_degree_1555  -1
    visit_2_16  order_active_lb_1556  -1
    visit_2_16  order_active_ub_1557  -12
    visit_2_16  service_visit_def_1558  -1
    order_2_16  connected_order_arc_1252  1
    order_2_16  connected_order_arc_1275  1
    order_2_16  connected_order_arc_1298  1
    order_2_16  connected_order_arc_1321  1
    order_2_16  connected_order_arc_1344  1
    order_2_16  connected_order_arc_1359  -1
    order_2_16  connected_order_arc_1361  -1
    order_2_16  connected_order_arc_1363  -1
    order_2_16  connected_order_arc_1365  -1
    order_2_16  connected_order_arc_1367  -1
    order_2_16  connected_order_arc_1369  -1
    order_2_16  connected_order_arc_1371  -1
    order_2_16  connected_order_arc_1373  -1
    order_2_16  connected_order_arc_1375  -1
    order_2_16  connected_order_arc_1377  -1
    order_2_16  connected_order_arc_1379  -1
    order_2_16  connected_order_arc_1392  1
    order_2_16  connected_order_arc_1415  1
    order_2_16  connected_order_arc_1438  1
    order_2_16  connected_order_arc_1461  1
    order_2_16  connected_order_arc_1484  1
    order_2_16  connected_order_arc_1507  1
    order_2_16  order_active_lb_1556  1
    order_2_16  order_active_ub_1557  1
    visit_2_17  out_degree_1560  -1
    visit_2_17  in_degree_1561  -1
    visit_2_17  order_active_lb_1562  -1
    visit_2_17  order_active_ub_1563  -12
    visit_2_17  service_visit_def_1564  -1
    order_2_17  connected_order_arc_1254  1
    order_2_17  connected_order_arc_1277  1
    order_2_17  connected_order_arc_1300  1
    order_2_17  connected_order_arc_1323  1
    order_2_17  connected_order_arc_1346  1
    order_2_17  connected_order_arc_1369  1
    order_2_17  connected_order_arc_1382  -1
    order_2_17  connected_order_arc_1384  -1
    order_2_17  connected_order_arc_1386  -1
    order_2_17  connected_order_arc_1388  -1
    order_2_17  connected_order_arc_1390  -1
    order_2_17  connected_order_arc_1392  -1
    order_2_17  connected_order_arc_1394  -1
    order_2_17  connected_order_arc_1396  -1
    order_2_17  connected_order_arc_1398  -1
    order_2_17  connected_order_arc_1400  -1
    order_2_17  connected_order_arc_1402  -1
    order_2_17  connected_order_arc_1417  1
    order_2_17  connected_order_arc_1440  1
    order_2_17  connected_order_arc_1463  1
    order_2_17  connected_order_arc_1486  1
    order_2_17  connected_order_arc_1509  1
    order_2_17  order_active_lb_1562  1
    order_2_17  order_active_ub_1563  1
    visit_2_18  out_degree_1566  -1
    visit_2_18  in_degree_1567  -1
    visit_2_18  order_active_lb_1568  -1
    visit_2_18  order_active_ub_1569  -12
    visit_2_18  service_visit_def_1570  -1
    order_2_18  connected_order_arc_1256  1
    order_2_18  connected_order_arc_1279  1
    order_2_18  connected_order_arc_1302  1
    order_2_18  connected_order_arc_1325  1
    order_2_18  connected_order_arc_1348  1
    order_2_18  connected_order_arc_1371  1
    order_2_18  connected_order_arc_1394  1
    order_2_18  connected_order_arc_1405  -1
    order_2_18  connected_order_arc_1407  -1
    order_2_18  connected_order_arc_1409  -1
    order_2_18  connected_order_arc_1411  -1
    order_2_18  connected_order_arc_1413  -1
    order_2_18  connected_order_arc_1415  -1
    order_2_18  connected_order_arc_1417  -1
    order_2_18  connected_order_arc_1419  -1
    order_2_18  connected_order_arc_1421  -1
    order_2_18  connected_order_arc_1423  -1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1442  1
    order_2_18  connected_order_arc_1465  1
    order_2_18  connected_order_arc_1488  1
    order_2_18  connected_order_arc_1511  1
    order_2_18  order_active_lb_1568  1
    order_2_18  order_active_ub_1569  1
    visit_2_19  out_degree_1572  -1
    visit_2_19  in_degree_1573  -1
    visit_2_19  order_active_lb_1574  -1
    visit_2_19  order_active_ub_1575  -12
    visit_2_19  service_visit_def_1576  -1
    order_2_19  connected_order_arc_1258  1
    order_2_19  connected_order_arc_1281  1
    order_2_19  connected_order_arc_1304  1
    order_2_19  connected_order_arc_1327  1
    order_2_19  connected_order_arc_1350  1
    order_2_19  connected_order_arc_1373  1
    order_2_19  connected_order_arc_1396  1
    order_2_19  connected_order_arc_1419  1
    order_2_19  connected_order_arc_1428  -1
    order_2_19  connected_order_arc_1430  -1
    order_2_19  connected_order_arc_1432  -1
    order_2_19  connected_order_arc_1434  -1
    order_2_19  connected_order_arc_1436  -1
    order_2_19  connected_order_arc_1438  -1
    order_2_19  connected_order_arc_1440  -1
    order_2_19  connected_order_arc_1442  -1
    order_2_19  connected_order_arc_1444  -1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1467  1
    order_2_19  connected_order_arc_1490  1
    order_2_19  connected_order_arc_1513  1
    order_2_19  order_active_lb_1574  1
    order_2_19  order_active_ub_1575  1
    visit_2_20  out_degree_1578  -1
    visit_2_20  in_degree_1579  -1
    visit_2_20  order_active_lb_1580  -1
    visit_2_20  order_active_ub_1581  -12
    visit_2_20  service_visit_def_1582  -1
    order_2_20  connected_order_arc_1260  1
    order_2_20  connected_order_arc_1283  1
    order_2_20  connected_order_arc_1306  1
    order_2_20  connected_order_arc_1329  1
    order_2_20  connected_order_arc_1352  1
    order_2_20  connected_order_arc_1375  1
    order_2_20  connected_order_arc_1398  1
    order_2_20  connected_order_arc_1421  1
    order_2_20  connected_order_arc_1444  1
    order_2_20  connected_order_arc_1451  -1
    order_2_20  connected_order_arc_1453  -1
    order_2_20  connected_order_arc_1455  -1
    order_2_20  connected_order_arc_1457  -1
    order_2_20  connected_order_arc_1459  -1
    order_2_20  connected_order_arc_1461  -1
    order_2_20  connected_order_arc_1463  -1
    order_2_20  connected_order_arc_1465  -1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1492  1
    order_2_20  connected_order_arc_1515  1
    order_2_20  order_active_lb_1580  1
    order_2_20  order_active_ub_1581  1
    visit_2_21  out_degree_1584  -1
    visit_2_21  in_degree_1585  -1
    visit_2_21  order_active_lb_1586  -1
    visit_2_21  order_active_ub_1587  -12
    visit_2_21  service_visit_def_1588  -1
    order_2_21  connected_order_arc_1262  1
    order_2_21  connected_order_arc_1285  1
    order_2_21  connected_order_arc_1308  1
    order_2_21  connected_order_arc_1331  1
    order_2_21  connected_order_arc_1354  1
    order_2_21  connected_order_arc_1377  1
    order_2_21  connected_order_arc_1400  1
    order_2_21  connected_order_arc_1423  1
    order_2_21  connected_order_arc_1446  1
    order_2_21  connected_order_arc_1469  1
    order_2_21  connected_order_arc_1474  -1
    order_2_21  connected_order_arc_1476  -1
    order_2_21  connected_order_arc_1478  -1
    order_2_21  connected_order_arc_1480  -1
    order_2_21  connected_order_arc_1482  -1
    order_2_21  connected_order_arc_1484  -1
    order_2_21  connected_order_arc_1486  -1
    order_2_21  connected_order_arc_1488  -1
    order_2_21  connected_order_arc_1490  -1
    order_2_21  connected_order_arc_1492  -1
    order_2_21  connected_order_arc_1494  -1
    order_2_21  connected_order_arc_1517  1
    order_2_21  order_active_lb_1586  1
    order_2_21  order_active_ub_1587  1
    visit_2_22  out_degree_1590  -1
    visit_2_22  in_degree_1591  -1
    visit_2_22  order_active_lb_1592  -1
    visit_2_22  order_active_ub_1593  -12
    visit_2_22  service_visit_def_1594  -1
    order_2_22  connected_order_arc_1264  1
    order_2_22  connected_order_arc_1287  1
    order_2_22  connected_order_arc_1310  1
    order_2_22  connected_order_arc_1333  1
    order_2_22  connected_order_arc_1356  1
    order_2_22  connected_order_arc_1379  1
    order_2_22  connected_order_arc_1402  1
    order_2_22  connected_order_arc_1425  1
    order_2_22  connected_order_arc_1448  1
    order_2_22  connected_order_arc_1471  1
    order_2_22  connected_order_arc_1494  1
    order_2_22  connected_order_arc_1497  -1
    order_2_22  connected_order_arc_1499  -1
    order_2_22  connected_order_arc_1501  -1
    order_2_22  connected_order_arc_1503  -1
    order_2_22  connected_order_arc_1505  -1
    order_2_22  connected_order_arc_1507  -1
    order_2_22  connected_order_arc_1509  -1
    order_2_22  connected_order_arc_1511  -1
    order_2_22  connected_order_arc_1513  -1
    order_2_22  connected_order_arc_1515  -1
    order_2_22  connected_order_arc_1517  -1
    order_2_22  order_active_lb_1592  1
    order_2_22  order_active_ub_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1229  -30
    arc_2_0_0  depot_departure_or_bypass_1518  1
    arc_2_0_0  depot_return_or_bypass_1519  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1229  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1230  -30
    arc_2_0_11  depot_departure_or_bypass_1518  1
    arc_2_0_11  in_degree_1521  1
    arc_2_0_11  original_T_including_depot_unload_1599  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1230  1
    load_2_0_11  segment_load_conservation_1524  -1
    load_2_0_11  segment_prefix_lb_1525  1
    load_2_0_11  segment_prefix_ub_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1231  -30
    arc_2_0_12  depot_departure_or_bypass_1518  1
    arc_2_0_12  in_degree_1528  1
    arc_2_0_12  original_T_including_depot_unload_1599  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1231  1
    load_2_0_12  segment_load_conservation_1531  -1
    load_2_0_12  segment_prefix_lb_1532  1
    load_2_0_12  segment_prefix_ub_1533  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1232  -30
    arc_2_0_13  depot_departure_or_bypass_1518  1
    arc_2_0_13  in_degree_1535  1
    arc_2_0_13  original_T_including_depot_unload_1599  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1232  1
    load_2_0_13  segment_load_conservation_1538  -1
    load_2_0_13  segment_prefix_lb_1539  1
    load_2_0_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1233  -30
    arc_2_0_14  depot_departure_or_bypass_1518  1
    arc_2_0_14  in_degree_1542  1
    arc_2_0_14  original_T_including_depot_unload_1599  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1233  1
    load_2_0_14  segment_load_conservation_1545  -1
    load_2_0_14  segment_prefix_lb_1546  1
    load_2_0_14  segment_prefix_ub_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1234  -30
    arc_2_0_15  depot_departure_or_bypass_1518  1
    arc_2_0_15  in_degree_1549  1
    arc_2_0_15  original_T_including_depot_unload_1599  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1234  1
    load_2_0_15  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1235  -30
    arc_2_0_16  depot_departure_or_bypass_1518  1
    arc_2_0_16  in_degree_1555  1
    arc_2_0_16  original_T_including_depot_unload_1599  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1235  1
    load_2_0_16  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1236  -30
    arc_2_0_17  depot_departure_or_bypass_1518  1
    arc_2_0_17  in_degree_1561  1
    arc_2_0_17  original_T_including_depot_unload_1599  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1236  1
    load_2_0_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1237  -30
    arc_2_0_18  depot_departure_or_bypass_1518  1
    arc_2_0_18  in_degree_1567  1
    arc_2_0_18  original_T_including_depot_unload_1599  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1237  1
    load_2_0_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1238  -30
    arc_2_0_19  depot_departure_or_bypass_1518  1
    arc_2_0_19  in_degree_1573  1
    arc_2_0_19  original_T_including_depot_unload_1599  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1238  1
    load_2_0_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1239  -30
    arc_2_0_20  depot_departure_or_bypass_1518  1
    arc_2_0_20  in_degree_1579  1
    arc_2_0_20  original_T_including_depot_unload_1599  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1239  1
    load_2_0_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1240  -30
    arc_2_0_21  depot_departure_or_bypass_1518  1
    arc_2_0_21  in_degree_1585  1
    arc_2_0_21  original_T_including_depot_unload_1599  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1240  1
    load_2_0_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1241  -30
    arc_2_0_22  depot_departure_or_bypass_1518  1
    arc_2_0_22  in_degree_1591  1
    arc_2_0_22  original_T_including_depot_unload_1599  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1241  1
    load_2_0_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1242  -30
    arc_2_11_0  depot_return_or_bypass_1519  1
    arc_2_11_0  out_degree_1520  1
    arc_2_11_0  original_T_including_depot_unload_1599  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1242  1
    load_2_11_0  segment_load_conservation_1524  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1243  -30
    arc_2_11_12  connected_order_arc_1244  -13
    arc_2_11_12  out_degree_1520  1
    arc_2_11_12  in_degree_1528  1
    arc_2_11_12  original_T_including_depot_unload_1599  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1243  1
    load_2_11_12  segment_load_conservation_1524  1
    load_2_11_12  segment_load_conservation_1531  -1
    load_2_11_12  segment_prefix_lb_1532  1
    load_2_11_12  segment_prefix_ub_1533  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1245  -30
    arc_2_11_13  connected_order_arc_1246  -13
    arc_2_11_13  out_degree_1520  1
    arc_2_11_13  in_degree_1535  1
    arc_2_11_13  original_T_including_depot_unload_1599  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1245  1
    load_2_11_13  segment_load_conservation_1524  1
    load_2_11_13  segment_load_conservation_1538  -1
    load_2_11_13  segment_prefix_lb_1539  1
    load_2_11_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1247  -30
    arc_2_11_14  connected_order_arc_1248  -13
    arc_2_11_14  out_degree_1520  1
    arc_2_11_14  in_degree_1542  1
    arc_2_11_14  original_T_including_depot_unload_1599  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1247  1
    load_2_11_14  segment_load_conservation_1524  1
    load_2_11_14  segment_load_conservation_1545  -1
    load_2_11_14  segment_prefix_lb_1546  1
    load_2_11_14  segment_prefix_ub_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1249  -30
    arc_2_11_15  connected_order_arc_1250  -13
    arc_2_11_15  out_degree_1520  1
    arc_2_11_15  in_degree_1549  1
    arc_2_11_15  original_T_including_depot_unload_1599  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1249  1
    load_2_11_15  segment_load_conservation_1524  1
    load_2_11_15  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1251  -30
    arc_2_11_16  connected_order_arc_1252  -13
    arc_2_11_16  out_degree_1520  1
    arc_2_11_16  in_degree_1555  1
    arc_2_11_16  original_T_including_depot_unload_1599  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1251  1
    load_2_11_16  segment_load_conservation_1524  1
    load_2_11_16  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1253  -30
    arc_2_11_17  connected_order_arc_1254  -13
    arc_2_11_17  out_degree_1520  1
    arc_2_11_17  in_degree_1561  1
    arc_2_11_17  original_T_including_depot_unload_1599  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1253  1
    load_2_11_17  segment_load_conservation_1524  1
    load_2_11_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1255  -30
    arc_2_11_18  connected_order_arc_1256  -13
    arc_2_11_18  out_degree_1520  1
    arc_2_11_18  in_degree_1567  1
    arc_2_11_18  original_T_including_depot_unload_1599  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1255  1
    load_2_11_18  segment_load_conservation_1524  1
    load_2_11_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1257  -30
    arc_2_11_19  connected_order_arc_1258  -13
    arc_2_11_19  out_degree_1520  1
    arc_2_11_19  in_degree_1573  1
    arc_2_11_19  original_T_including_depot_unload_1599  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1257  1
    load_2_11_19  segment_load_conservation_1524  1
    load_2_11_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1259  -30
    arc_2_11_20  connected_order_arc_1260  -13
    arc_2_11_20  out_degree_1520  1
    arc_2_11_20  in_degree_1579  1
    arc_2_11_20  original_T_including_depot_unload_1599  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1259  1
    load_2_11_20  segment_load_conservation_1524  1
    load_2_11_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1261  -30
    arc_2_11_21  connected_order_arc_1262  -13
    arc_2_11_21  out_degree_1520  1
    arc_2_11_21  in_degree_1585  1
    arc_2_11_21  original_T_including_depot_unload_1599  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1261  1
    load_2_11_21  segment_load_conservation_1524  1
    load_2_11_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1263  -30
    arc_2_11_22  connected_order_arc_1264  -13
    arc_2_11_22  out_degree_1520  1
    arc_2_11_22  in_degree_1591  1
    arc_2_11_22  original_T_including_depot_unload_1599  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1263  1
    load_2_11_22  segment_load_conservation_1524  1
    load_2_11_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1265  -30
    arc_2_12_0  depot_return_or_bypass_1519  1
    arc_2_12_0  out_degree_1527  1
    arc_2_12_0  original_T_including_depot_unload_1599  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1265  1
    load_2_12_0  segment_load_conservation_1531  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1266  -30
    arc_2_12_11  connected_order_arc_1267  -13
    arc_2_12_11  in_degree_1521  1
    arc_2_12_11  out_degree_1527  1
    arc_2_12_11  original_T_including_depot_unload_1599  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1266  1
    load_2_12_11  segment_load_conservation_1524  -1
    load_2_12_11  segment_prefix_lb_1525  1
    load_2_12_11  segment_prefix_ub_1526  1
    load_2_12_11  segment_load_conservation_1531  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1268  -30
    arc_2_12_13  connected_order_arc_1269  -13
    arc_2_12_13  out_degree_1527  1
    arc_2_12_13  in_degree_1535  1
    arc_2_12_13  original_T_including_depot_unload_1599  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1268  1
    load_2_12_13  segment_load_conservation_1531  1
    load_2_12_13  segment_load_conservation_1538  -1
    load_2_12_13  segment_prefix_lb_1539  1
    load_2_12_13  segment_prefix_ub_1540  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1270  -30
    arc_2_12_14  connected_order_arc_1271  -13
    arc_2_12_14  out_degree_1527  1
    arc_2_12_14  in_degree_1542  1
    arc_2_12_14  original_T_including_depot_unload_1599  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1270  1
    load_2_12_14  segment_load_conservation_1531  1
    load_2_12_14  segment_load_conservation_1545  -1
    load_2_12_14  segment_prefix_lb_1546  1
    load_2_12_14  segment_prefix_ub_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1272  -30
    arc_2_12_15  connected_order_arc_1273  -13
    arc_2_12_15  out_degree_1527  1
    arc_2_12_15  in_degree_1549  1
    arc_2_12_15  original_T_including_depot_unload_1599  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1272  1
    load_2_12_15  segment_load_conservation_1531  1
    load_2_12_15  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1274  -30
    arc_2_12_16  connected_order_arc_1275  -13
    arc_2_12_16  out_degree_1527  1
    arc_2_12_16  in_degree_1555  1
    arc_2_12_16  original_T_including_depot_unload_1599  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1274  1
    load_2_12_16  segment_load_conservation_1531  1
    load_2_12_16  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1276  -30
    arc_2_12_17  connected_order_arc_1277  -13
    arc_2_12_17  out_degree_1527  1
    arc_2_12_17  in_degree_1561  1
    arc_2_12_17  original_T_including_depot_unload_1599  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1276  1
    load_2_12_17  segment_load_conservation_1531  1
    load_2_12_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1278  -30
    arc_2_12_18  connected_order_arc_1279  -13
    arc_2_12_18  out_degree_1527  1
    arc_2_12_18  in_degree_1567  1
    arc_2_12_18  original_T_including_depot_unload_1599  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1278  1
    load_2_12_18  segment_load_conservation_1531  1
    load_2_12_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1280  -30
    arc_2_12_19  connected_order_arc_1281  -13
    arc_2_12_19  out_degree_1527  1
    arc_2_12_19  in_degree_1573  1
    arc_2_12_19  original_T_including_depot_unload_1599  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1280  1
    load_2_12_19  segment_load_conservation_1531  1
    load_2_12_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1282  -30
    arc_2_12_20  connected_order_arc_1283  -13
    arc_2_12_20  out_degree_1527  1
    arc_2_12_20  in_degree_1579  1
    arc_2_12_20  original_T_including_depot_unload_1599  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1282  1
    load_2_12_20  segment_load_conservation_1531  1
    load_2_12_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1284  -30
    arc_2_12_21  connected_order_arc_1285  -13
    arc_2_12_21  out_degree_1527  1
    arc_2_12_21  in_degree_1585  1
    arc_2_12_21  original_T_including_depot_unload_1599  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1284  1
    load_2_12_21  segment_load_conservation_1531  1
    load_2_12_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1286  -30
    arc_2_12_22  connected_order_arc_1287  -13
    arc_2_12_22  out_degree_1527  1
    arc_2_12_22  in_degree_1591  1
    arc_2_12_22  original_T_including_depot_unload_1599  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1286  1
    load_2_12_22  segment_load_conservation_1531  1
    load_2_12_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1288  -30
    arc_2_13_0  depot_return_or_bypass_1519  1
    arc_2_13_0  out_degree_1534  1
    arc_2_13_0  original_T_including_depot_unload_1599  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1288  1
    load_2_13_0  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1289  -30
    arc_2_13_11  connected_order_arc_1290  -13
    arc_2_13_11  in_degree_1521  1
    arc_2_13_11  out_degree_1534  1
    arc_2_13_11  original_T_including_depot_unload_1599  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1289  1
    load_2_13_11  segment_load_conservation_1524  -1
    load_2_13_11  segment_prefix_lb_1525  1
    load_2_13_11  segment_prefix_ub_1526  1
    load_2_13_11  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1291  -30
    arc_2_13_12  connected_order_arc_1292  -13
    arc_2_13_12  in_degree_1528  1
    arc_2_13_12  out_degree_1534  1
    arc_2_13_12  original_T_including_depot_unload_1599  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1291  1
    load_2_13_12  segment_load_conservation_1531  -1
    load_2_13_12  segment_prefix_lb_1532  1
    load_2_13_12  segment_prefix_ub_1533  1
    load_2_13_12  segment_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1293  -30
    arc_2_13_14  connected_order_arc_1294  -13
    arc_2_13_14  out_degree_1534  1
    arc_2_13_14  in_degree_1542  1
    arc_2_13_14  original_T_including_depot_unload_1599  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1293  1
    load_2_13_14  segment_load_conservation_1538  1
    load_2_13_14  segment_load_conservation_1545  -1
    load_2_13_14  segment_prefix_lb_1546  1
    load_2_13_14  segment_prefix_ub_1547  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1295  -30
    arc_2_13_15  connected_order_arc_1296  -13
    arc_2_13_15  out_degree_1534  1
    arc_2_13_15  in_degree_1549  1
    arc_2_13_15  original_T_including_depot_unload_1599  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1295  1
    load_2_13_15  segment_load_conservation_1538  1
    load_2_13_15  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1297  -30
    arc_2_13_16  connected_order_arc_1298  -13
    arc_2_13_16  out_degree_1534  1
    arc_2_13_16  in_degree_1555  1
    arc_2_13_16  original_T_including_depot_unload_1599  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1297  1
    load_2_13_16  segment_load_conservation_1538  1
    load_2_13_16  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1299  -30
    arc_2_13_17  connected_order_arc_1300  -13
    arc_2_13_17  out_degree_1534  1
    arc_2_13_17  in_degree_1561  1
    arc_2_13_17  original_T_including_depot_unload_1599  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1299  1
    load_2_13_17  segment_load_conservation_1538  1
    load_2_13_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1301  -30
    arc_2_13_18  connected_order_arc_1302  -13
    arc_2_13_18  out_degree_1534  1
    arc_2_13_18  in_degree_1567  1
    arc_2_13_18  original_T_including_depot_unload_1599  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1301  1
    load_2_13_18  segment_load_conservation_1538  1
    load_2_13_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1303  -30
    arc_2_13_19  connected_order_arc_1304  -13
    arc_2_13_19  out_degree_1534  1
    arc_2_13_19  in_degree_1573  1
    arc_2_13_19  original_T_including_depot_unload_1599  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1303  1
    load_2_13_19  segment_load_conservation_1538  1
    load_2_13_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1305  -30
    arc_2_13_20  connected_order_arc_1306  -13
    arc_2_13_20  out_degree_1534  1
    arc_2_13_20  in_degree_1579  1
    arc_2_13_20  original_T_including_depot_unload_1599  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1305  1
    load_2_13_20  segment_load_conservation_1538  1
    load_2_13_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1307  -30
    arc_2_13_21  connected_order_arc_1308  -13
    arc_2_13_21  out_degree_1534  1
    arc_2_13_21  in_degree_1585  1
    arc_2_13_21  original_T_including_depot_unload_1599  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1307  1
    load_2_13_21  segment_load_conservation_1538  1
    load_2_13_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1309  -30
    arc_2_13_22  connected_order_arc_1310  -13
    arc_2_13_22  out_degree_1534  1
    arc_2_13_22  in_degree_1591  1
    arc_2_13_22  original_T_including_depot_unload_1599  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1309  1
    load_2_13_22  segment_load_conservation_1538  1
    load_2_13_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1311  -30
    arc_2_14_0  depot_return_or_bypass_1519  1
    arc_2_14_0  out_degree_1541  1
    arc_2_14_0  original_T_including_depot_unload_1599  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1311  1
    load_2_14_0  segment_load_conservation_1545  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1312  -30
    arc_2_14_11  connected_order_arc_1313  -13
    arc_2_14_11  in_degree_1521  1
    arc_2_14_11  out_degree_1541  1
    arc_2_14_11  original_T_including_depot_unload_1599  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1312  1
    load_2_14_11  segment_load_conservation_1524  -1
    load_2_14_11  segment_prefix_lb_1525  1
    load_2_14_11  segment_prefix_ub_1526  1
    load_2_14_11  segment_load_conservation_1545  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1314  -30
    arc_2_14_12  connected_order_arc_1315  -13
    arc_2_14_12  in_degree_1528  1
    arc_2_14_12  out_degree_1541  1
    arc_2_14_12  original_T_including_depot_unload_1599  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1314  1
    load_2_14_12  segment_load_conservation_1531  -1
    load_2_14_12  segment_prefix_lb_1532  1
    load_2_14_12  segment_prefix_ub_1533  1
    load_2_14_12  segment_load_conservation_1545  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1316  -30
    arc_2_14_13  connected_order_arc_1317  -13
    arc_2_14_13  in_degree_1535  1
    arc_2_14_13  out_degree_1541  1
    arc_2_14_13  original_T_including_depot_unload_1599  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1316  1
    load_2_14_13  segment_load_conservation_1538  -1
    load_2_14_13  segment_prefix_lb_1539  1
    load_2_14_13  segment_prefix_ub_1540  1
    load_2_14_13  segment_load_conservation_1545  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1318  -30
    arc_2_14_15  connected_order_arc_1319  -13
    arc_2_14_15  out_degree_1541  1
    arc_2_14_15  in_degree_1549  1
    arc_2_14_15  original_T_including_depot_unload_1599  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1318  1
    load_2_14_15  segment_load_conservation_1545  1
    load_2_14_15  free_load_conservation_1553  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1320  -30
    arc_2_14_16  connected_order_arc_1321  -13
    arc_2_14_16  out_degree_1541  1
    arc_2_14_16  in_degree_1555  1
    arc_2_14_16  original_T_including_depot_unload_1599  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1320  1
    load_2_14_16  segment_load_conservation_1545  1
    load_2_14_16  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1322  -30
    arc_2_14_17  connected_order_arc_1323  -13
    arc_2_14_17  out_degree_1541  1
    arc_2_14_17  in_degree_1561  1
    arc_2_14_17  original_T_including_depot_unload_1599  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1322  1
    load_2_14_17  segment_load_conservation_1545  1
    load_2_14_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1324  -30
    arc_2_14_18  connected_order_arc_1325  -13
    arc_2_14_18  out_degree_1541  1
    arc_2_14_18  in_degree_1567  1
    arc_2_14_18  original_T_including_depot_unload_1599  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1324  1
    load_2_14_18  segment_load_conservation_1545  1
    load_2_14_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1326  -30
    arc_2_14_19  connected_order_arc_1327  -13
    arc_2_14_19  out_degree_1541  1
    arc_2_14_19  in_degree_1573  1
    arc_2_14_19  original_T_including_depot_unload_1599  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1326  1
    load_2_14_19  segment_load_conservation_1545  1
    load_2_14_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1328  -30
    arc_2_14_20  connected_order_arc_1329  -13
    arc_2_14_20  out_degree_1541  1
    arc_2_14_20  in_degree_1579  1
    arc_2_14_20  original_T_including_depot_unload_1599  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1328  1
    load_2_14_20  segment_load_conservation_1545  1
    load_2_14_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1330  -30
    arc_2_14_21  connected_order_arc_1331  -13
    arc_2_14_21  out_degree_1541  1
    arc_2_14_21  in_degree_1585  1
    arc_2_14_21  original_T_including_depot_unload_1599  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1330  1
    load_2_14_21  segment_load_conservation_1545  1
    load_2_14_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1332  -30
    arc_2_14_22  connected_order_arc_1333  -13
    arc_2_14_22  out_degree_1541  1
    arc_2_14_22  in_degree_1591  1
    arc_2_14_22  original_T_including_depot_unload_1599  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1332  1
    load_2_14_22  segment_load_conservation_1545  1
    load_2_14_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1334  -30
    arc_2_15_0  depot_return_or_bypass_1519  1
    arc_2_15_0  out_degree_1548  1
    arc_2_15_0  original_T_including_depot_unload_1599  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1334  1
    load_2_15_0  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1335  -30
    arc_2_15_11  connected_order_arc_1336  -13
    arc_2_15_11  in_degree_1521  1
    arc_2_15_11  out_degree_1548  1
    arc_2_15_11  original_T_including_depot_unload_1599  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1335  1
    load_2_15_11  segment_load_conservation_1524  -1
    load_2_15_11  segment_prefix_lb_1525  1
    load_2_15_11  segment_prefix_ub_1526  1
    load_2_15_11  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1337  -30
    arc_2_15_12  connected_order_arc_1338  -13
    arc_2_15_12  in_degree_1528  1
    arc_2_15_12  out_degree_1548  1
    arc_2_15_12  original_T_including_depot_unload_1599  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1337  1
    load_2_15_12  segment_load_conservation_1531  -1
    load_2_15_12  segment_prefix_lb_1532  1
    load_2_15_12  segment_prefix_ub_1533  1
    load_2_15_12  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1339  -30
    arc_2_15_13  connected_order_arc_1340  -13
    arc_2_15_13  in_degree_1535  1
    arc_2_15_13  out_degree_1548  1
    arc_2_15_13  original_T_including_depot_unload_1599  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1339  1
    load_2_15_13  segment_load_conservation_1538  -1
    load_2_15_13  segment_prefix_lb_1539  1
    load_2_15_13  segment_prefix_ub_1540  1
    load_2_15_13  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1341  -30
    arc_2_15_14  connected_order_arc_1342  -13
    arc_2_15_14  in_degree_1542  1
    arc_2_15_14  out_degree_1548  1
    arc_2_15_14  original_T_including_depot_unload_1599  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1341  1
    load_2_15_14  segment_load_conservation_1545  -1
    load_2_15_14  segment_prefix_lb_1546  1
    load_2_15_14  segment_prefix_ub_1547  1
    load_2_15_14  free_load_conservation_1553  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1343  -30
    arc_2_15_16  connected_order_arc_1344  -13
    arc_2_15_16  out_degree_1548  1
    arc_2_15_16  in_degree_1555  1
    arc_2_15_16  original_T_including_depot_unload_1599  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1343  1
    load_2_15_16  free_load_conservation_1553  1
    load_2_15_16  free_load_conservation_1559  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1345  -30
    arc_2_15_17  connected_order_arc_1346  -13
    arc_2_15_17  out_degree_1548  1
    arc_2_15_17  in_degree_1561  1
    arc_2_15_17  original_T_including_depot_unload_1599  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1345  1
    load_2_15_17  free_load_conservation_1553  1
    load_2_15_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1347  -30
    arc_2_15_18  connected_order_arc_1348  -13
    arc_2_15_18  out_degree_1548  1
    arc_2_15_18  in_degree_1567  1
    arc_2_15_18  original_T_including_depot_unload_1599  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1347  1
    load_2_15_18  free_load_conservation_1553  1
    load_2_15_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1349  -30
    arc_2_15_19  connected_order_arc_1350  -13
    arc_2_15_19  out_degree_1548  1
    arc_2_15_19  in_degree_1573  1
    arc_2_15_19  original_T_including_depot_unload_1599  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1349  1
    load_2_15_19  free_load_conservation_1553  1
    load_2_15_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1351  -30
    arc_2_15_20  connected_order_arc_1352  -13
    arc_2_15_20  out_degree_1548  1
    arc_2_15_20  in_degree_1579  1
    arc_2_15_20  original_T_including_depot_unload_1599  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1351  1
    load_2_15_20  free_load_conservation_1553  1
    load_2_15_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1353  -30
    arc_2_15_21  connected_order_arc_1354  -13
    arc_2_15_21  out_degree_1548  1
    arc_2_15_21  in_degree_1585  1
    arc_2_15_21  original_T_including_depot_unload_1599  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1353  1
    load_2_15_21  free_load_conservation_1553  1
    load_2_15_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1355  -30
    arc_2_15_22  connected_order_arc_1356  -13
    arc_2_15_22  out_degree_1548  1
    arc_2_15_22  in_degree_1591  1
    arc_2_15_22  original_T_including_depot_unload_1599  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1355  1
    load_2_15_22  free_load_conservation_1553  1
    load_2_15_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1357  -30
    arc_2_16_0  depot_return_or_bypass_1519  1
    arc_2_16_0  out_degree_1554  1
    arc_2_16_0  original_T_including_depot_unload_1599  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1357  1
    load_2_16_0  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1358  -30
    arc_2_16_11  connected_order_arc_1359  -13
    arc_2_16_11  in_degree_1521  1
    arc_2_16_11  out_degree_1554  1
    arc_2_16_11  original_T_including_depot_unload_1599  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1358  1
    load_2_16_11  segment_load_conservation_1524  -1
    load_2_16_11  segment_prefix_lb_1525  1
    load_2_16_11  segment_prefix_ub_1526  1
    load_2_16_11  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1360  -30
    arc_2_16_12  connected_order_arc_1361  -13
    arc_2_16_12  in_degree_1528  1
    arc_2_16_12  out_degree_1554  1
    arc_2_16_12  original_T_including_depot_unload_1599  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1360  1
    load_2_16_12  segment_load_conservation_1531  -1
    load_2_16_12  segment_prefix_lb_1532  1
    load_2_16_12  segment_prefix_ub_1533  1
    load_2_16_12  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1362  -30
    arc_2_16_13  connected_order_arc_1363  -13
    arc_2_16_13  in_degree_1535  1
    arc_2_16_13  out_degree_1554  1
    arc_2_16_13  original_T_including_depot_unload_1599  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1362  1
    load_2_16_13  segment_load_conservation_1538  -1
    load_2_16_13  segment_prefix_lb_1539  1
    load_2_16_13  segment_prefix_ub_1540  1
    load_2_16_13  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1364  -30
    arc_2_16_14  connected_order_arc_1365  -13
    arc_2_16_14  in_degree_1542  1
    arc_2_16_14  out_degree_1554  1
    arc_2_16_14  original_T_including_depot_unload_1599  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1364  1
    load_2_16_14  segment_load_conservation_1545  -1
    load_2_16_14  segment_prefix_lb_1546  1
    load_2_16_14  segment_prefix_ub_1547  1
    load_2_16_14  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1366  -30
    arc_2_16_15  connected_order_arc_1367  -13
    arc_2_16_15  in_degree_1549  1
    arc_2_16_15  out_degree_1554  1
    arc_2_16_15  original_T_including_depot_unload_1599  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1366  1
    load_2_16_15  free_load_conservation_1553  -1
    load_2_16_15  free_load_conservation_1559  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1368  -30
    arc_2_16_17  connected_order_arc_1369  -13
    arc_2_16_17  out_degree_1554  1
    arc_2_16_17  in_degree_1561  1
    arc_2_16_17  original_T_including_depot_unload_1599  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1368  1
    load_2_16_17  free_load_conservation_1559  1
    load_2_16_17  free_load_conservation_1565  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1370  -30
    arc_2_16_18  connected_order_arc_1371  -13
    arc_2_16_18  out_degree_1554  1
    arc_2_16_18  in_degree_1567  1
    arc_2_16_18  original_T_including_depot_unload_1599  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1370  1
    load_2_16_18  free_load_conservation_1559  1
    load_2_16_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1372  -30
    arc_2_16_19  connected_order_arc_1373  -13
    arc_2_16_19  out_degree_1554  1
    arc_2_16_19  in_degree_1573  1
    arc_2_16_19  original_T_including_depot_unload_1599  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1372  1
    load_2_16_19  free_load_conservation_1559  1
    load_2_16_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1374  -30
    arc_2_16_20  connected_order_arc_1375  -13
    arc_2_16_20  out_degree_1554  1
    arc_2_16_20  in_degree_1579  1
    arc_2_16_20  original_T_including_depot_unload_1599  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1374  1
    load_2_16_20  free_load_conservation_1559  1
    load_2_16_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1376  -30
    arc_2_16_21  connected_order_arc_1377  -13
    arc_2_16_21  out_degree_1554  1
    arc_2_16_21  in_degree_1585  1
    arc_2_16_21  original_T_including_depot_unload_1599  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1376  1
    load_2_16_21  free_load_conservation_1559  1
    load_2_16_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1378  -30
    arc_2_16_22  connected_order_arc_1379  -13
    arc_2_16_22  out_degree_1554  1
    arc_2_16_22  in_degree_1591  1
    arc_2_16_22  original_T_including_depot_unload_1599  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1378  1
    load_2_16_22  free_load_conservation_1559  1
    load_2_16_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1380  -30
    arc_2_17_0  depot_return_or_bypass_1519  1
    arc_2_17_0  out_degree_1560  1
    arc_2_17_0  original_T_including_depot_unload_1599  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1380  1
    load_2_17_0  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1381  -30
    arc_2_17_11  connected_order_arc_1382  -13
    arc_2_17_11  in_degree_1521  1
    arc_2_17_11  out_degree_1560  1
    arc_2_17_11  original_T_including_depot_unload_1599  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1381  1
    load_2_17_11  segment_load_conservation_1524  -1
    load_2_17_11  segment_prefix_lb_1525  1
    load_2_17_11  segment_prefix_ub_1526  1
    load_2_17_11  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1383  -30
    arc_2_17_12  connected_order_arc_1384  -13
    arc_2_17_12  in_degree_1528  1
    arc_2_17_12  out_degree_1560  1
    arc_2_17_12  original_T_including_depot_unload_1599  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1383  1
    load_2_17_12  segment_load_conservation_1531  -1
    load_2_17_12  segment_prefix_lb_1532  1
    load_2_17_12  segment_prefix_ub_1533  1
    load_2_17_12  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1385  -30
    arc_2_17_13  connected_order_arc_1386  -13
    arc_2_17_13  in_degree_1535  1
    arc_2_17_13  out_degree_1560  1
    arc_2_17_13  original_T_including_depot_unload_1599  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1385  1
    load_2_17_13  segment_load_conservation_1538  -1
    load_2_17_13  segment_prefix_lb_1539  1
    load_2_17_13  segment_prefix_ub_1540  1
    load_2_17_13  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1387  -30
    arc_2_17_14  connected_order_arc_1388  -13
    arc_2_17_14  in_degree_1542  1
    arc_2_17_14  out_degree_1560  1
    arc_2_17_14  original_T_including_depot_unload_1599  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1387  1
    load_2_17_14  segment_load_conservation_1545  -1
    load_2_17_14  segment_prefix_lb_1546  1
    load_2_17_14  segment_prefix_ub_1547  1
    load_2_17_14  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1389  -30
    arc_2_17_15  connected_order_arc_1390  -13
    arc_2_17_15  in_degree_1549  1
    arc_2_17_15  out_degree_1560  1
    arc_2_17_15  original_T_including_depot_unload_1599  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1389  1
    load_2_17_15  free_load_conservation_1553  -1
    load_2_17_15  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1391  -30
    arc_2_17_16  connected_order_arc_1392  -13
    arc_2_17_16  in_degree_1555  1
    arc_2_17_16  out_degree_1560  1
    arc_2_17_16  original_T_including_depot_unload_1599  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1391  1
    load_2_17_16  free_load_conservation_1559  -1
    load_2_17_16  free_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1393  -30
    arc_2_17_18  connected_order_arc_1394  -13
    arc_2_17_18  out_degree_1560  1
    arc_2_17_18  in_degree_1567  1
    arc_2_17_18  original_T_including_depot_unload_1599  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1393  1
    load_2_17_18  free_load_conservation_1565  1
    load_2_17_18  free_load_conservation_1571  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1395  -30
    arc_2_17_19  connected_order_arc_1396  -13
    arc_2_17_19  out_degree_1560  1
    arc_2_17_19  in_degree_1573  1
    arc_2_17_19  original_T_including_depot_unload_1599  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1395  1
    load_2_17_19  free_load_conservation_1565  1
    load_2_17_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1397  -30
    arc_2_17_20  connected_order_arc_1398  -13
    arc_2_17_20  out_degree_1560  1
    arc_2_17_20  in_degree_1579  1
    arc_2_17_20  original_T_including_depot_unload_1599  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1397  1
    load_2_17_20  free_load_conservation_1565  1
    load_2_17_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1399  -30
    arc_2_17_21  connected_order_arc_1400  -13
    arc_2_17_21  out_degree_1560  1
    arc_2_17_21  in_degree_1585  1
    arc_2_17_21  original_T_including_depot_unload_1599  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1399  1
    load_2_17_21  free_load_conservation_1565  1
    load_2_17_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1401  -30
    arc_2_17_22  connected_order_arc_1402  -13
    arc_2_17_22  out_degree_1560  1
    arc_2_17_22  in_degree_1591  1
    arc_2_17_22  original_T_including_depot_unload_1599  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1401  1
    load_2_17_22  free_load_conservation_1565  1
    load_2_17_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1403  -30
    arc_2_18_0  depot_return_or_bypass_1519  1
    arc_2_18_0  out_degree_1566  1
    arc_2_18_0  original_T_including_depot_unload_1599  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1403  1
    load_2_18_0  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1404  -30
    arc_2_18_11  connected_order_arc_1405  -13
    arc_2_18_11  in_degree_1521  1
    arc_2_18_11  out_degree_1566  1
    arc_2_18_11  original_T_including_depot_unload_1599  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1404  1
    load_2_18_11  segment_load_conservation_1524  -1
    load_2_18_11  segment_prefix_lb_1525  1
    load_2_18_11  segment_prefix_ub_1526  1
    load_2_18_11  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1406  -30
    arc_2_18_12  connected_order_arc_1407  -13
    arc_2_18_12  in_degree_1528  1
    arc_2_18_12  out_degree_1566  1
    arc_2_18_12  original_T_including_depot_unload_1599  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1406  1
    load_2_18_12  segment_load_conservation_1531  -1
    load_2_18_12  segment_prefix_lb_1532  1
    load_2_18_12  segment_prefix_ub_1533  1
    load_2_18_12  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1408  -30
    arc_2_18_13  connected_order_arc_1409  -13
    arc_2_18_13  in_degree_1535  1
    arc_2_18_13  out_degree_1566  1
    arc_2_18_13  original_T_including_depot_unload_1599  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1408  1
    load_2_18_13  segment_load_conservation_1538  -1
    load_2_18_13  segment_prefix_lb_1539  1
    load_2_18_13  segment_prefix_ub_1540  1
    load_2_18_13  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1410  -30
    arc_2_18_14  connected_order_arc_1411  -13
    arc_2_18_14  in_degree_1542  1
    arc_2_18_14  out_degree_1566  1
    arc_2_18_14  original_T_including_depot_unload_1599  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1410  1
    load_2_18_14  segment_load_conservation_1545  -1
    load_2_18_14  segment_prefix_lb_1546  1
    load_2_18_14  segment_prefix_ub_1547  1
    load_2_18_14  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1412  -30
    arc_2_18_15  connected_order_arc_1413  -13
    arc_2_18_15  in_degree_1549  1
    arc_2_18_15  out_degree_1566  1
    arc_2_18_15  original_T_including_depot_unload_1599  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1412  1
    load_2_18_15  free_load_conservation_1553  -1
    load_2_18_15  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1414  -30
    arc_2_18_16  connected_order_arc_1415  -13
    arc_2_18_16  in_degree_1555  1
    arc_2_18_16  out_degree_1566  1
    arc_2_18_16  original_T_including_depot_unload_1599  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1414  1
    load_2_18_16  free_load_conservation_1559  -1
    load_2_18_16  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1416  -30
    arc_2_18_17  connected_order_arc_1417  -13
    arc_2_18_17  in_degree_1561  1
    arc_2_18_17  out_degree_1566  1
    arc_2_18_17  original_T_including_depot_unload_1599  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1416  1
    load_2_18_17  free_load_conservation_1565  -1
    load_2_18_17  free_load_conservation_1571  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1418  -30
    arc_2_18_19  connected_order_arc_1419  -13
    arc_2_18_19  out_degree_1566  1
    arc_2_18_19  in_degree_1573  1
    arc_2_18_19  original_T_including_depot_unload_1599  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1418  1
    load_2_18_19  free_load_conservation_1571  1
    load_2_18_19  free_load_conservation_1577  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1420  -30
    arc_2_18_20  connected_order_arc_1421  -13
    arc_2_18_20  out_degree_1566  1
    arc_2_18_20  in_degree_1579  1
    arc_2_18_20  original_T_including_depot_unload_1599  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1420  1
    load_2_18_20  free_load_conservation_1571  1
    load_2_18_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1422  -30
    arc_2_18_21  connected_order_arc_1423  -13
    arc_2_18_21  out_degree_1566  1
    arc_2_18_21  in_degree_1585  1
    arc_2_18_21  original_T_including_depot_unload_1599  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1422  1
    load_2_18_21  free_load_conservation_1571  1
    load_2_18_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1424  -30
    arc_2_18_22  connected_order_arc_1425  -13
    arc_2_18_22  out_degree_1566  1
    arc_2_18_22  in_degree_1591  1
    arc_2_18_22  original_T_including_depot_unload_1599  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1424  1
    load_2_18_22  free_load_conservation_1571  1
    load_2_18_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1426  -30
    arc_2_19_0  depot_return_or_bypass_1519  1
    arc_2_19_0  out_degree_1572  1
    arc_2_19_0  original_T_including_depot_unload_1599  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1426  1
    load_2_19_0  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1427  -30
    arc_2_19_11  connected_order_arc_1428  -13
    arc_2_19_11  in_degree_1521  1
    arc_2_19_11  out_degree_1572  1
    arc_2_19_11  original_T_including_depot_unload_1599  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1427  1
    load_2_19_11  segment_load_conservation_1524  -1
    load_2_19_11  segment_prefix_lb_1525  1
    load_2_19_11  segment_prefix_ub_1526  1
    load_2_19_11  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1429  -30
    arc_2_19_12  connected_order_arc_1430  -13
    arc_2_19_12  in_degree_1528  1
    arc_2_19_12  out_degree_1572  1
    arc_2_19_12  original_T_including_depot_unload_1599  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1429  1
    load_2_19_12  segment_load_conservation_1531  -1
    load_2_19_12  segment_prefix_lb_1532  1
    load_2_19_12  segment_prefix_ub_1533  1
    load_2_19_12  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1431  -30
    arc_2_19_13  connected_order_arc_1432  -13
    arc_2_19_13  in_degree_1535  1
    arc_2_19_13  out_degree_1572  1
    arc_2_19_13  original_T_including_depot_unload_1599  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1431  1
    load_2_19_13  segment_load_conservation_1538  -1
    load_2_19_13  segment_prefix_lb_1539  1
    load_2_19_13  segment_prefix_ub_1540  1
    load_2_19_13  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1433  -30
    arc_2_19_14  connected_order_arc_1434  -13
    arc_2_19_14  in_degree_1542  1
    arc_2_19_14  out_degree_1572  1
    arc_2_19_14  original_T_including_depot_unload_1599  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1433  1
    load_2_19_14  segment_load_conservation_1545  -1
    load_2_19_14  segment_prefix_lb_1546  1
    load_2_19_14  segment_prefix_ub_1547  1
    load_2_19_14  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1435  -30
    arc_2_19_15  connected_order_arc_1436  -13
    arc_2_19_15  in_degree_1549  1
    arc_2_19_15  out_degree_1572  1
    arc_2_19_15  original_T_including_depot_unload_1599  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1435  1
    load_2_19_15  free_load_conservation_1553  -1
    load_2_19_15  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1437  -30
    arc_2_19_16  connected_order_arc_1438  -13
    arc_2_19_16  in_degree_1555  1
    arc_2_19_16  out_degree_1572  1
    arc_2_19_16  original_T_including_depot_unload_1599  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1437  1
    load_2_19_16  free_load_conservation_1559  -1
    load_2_19_16  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1439  -30
    arc_2_19_17  connected_order_arc_1440  -13
    arc_2_19_17  in_degree_1561  1
    arc_2_19_17  out_degree_1572  1
    arc_2_19_17  original_T_including_depot_unload_1599  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1439  1
    load_2_19_17  free_load_conservation_1565  -1
    load_2_19_17  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1441  -30
    arc_2_19_18  connected_order_arc_1442  -13
    arc_2_19_18  in_degree_1567  1
    arc_2_19_18  out_degree_1572  1
    arc_2_19_18  original_T_including_depot_unload_1599  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1441  1
    load_2_19_18  free_load_conservation_1571  -1
    load_2_19_18  free_load_conservation_1577  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1443  -30
    arc_2_19_20  connected_order_arc_1444  -13
    arc_2_19_20  out_degree_1572  1
    arc_2_19_20  in_degree_1579  1
    arc_2_19_20  original_T_including_depot_unload_1599  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1443  1
    load_2_19_20  free_load_conservation_1577  1
    load_2_19_20  free_load_conservation_1583  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1445  -30
    arc_2_19_21  connected_order_arc_1446  -13
    arc_2_19_21  out_degree_1572  1
    arc_2_19_21  in_degree_1585  1
    arc_2_19_21  original_T_including_depot_unload_1599  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1445  1
    load_2_19_21  free_load_conservation_1577  1
    load_2_19_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1447  -30
    arc_2_19_22  connected_order_arc_1448  -13
    arc_2_19_22  out_degree_1572  1
    arc_2_19_22  in_degree_1591  1
    arc_2_19_22  original_T_including_depot_unload_1599  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1447  1
    load_2_19_22  free_load_conservation_1577  1
    load_2_19_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1449  -30
    arc_2_20_0  depot_return_or_bypass_1519  1
    arc_2_20_0  out_degree_1578  1
    arc_2_20_0  original_T_including_depot_unload_1599  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1449  1
    load_2_20_0  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1450  -30
    arc_2_20_11  connected_order_arc_1451  -13
    arc_2_20_11  in_degree_1521  1
    arc_2_20_11  out_degree_1578  1
    arc_2_20_11  original_T_including_depot_unload_1599  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1450  1
    load_2_20_11  segment_load_conservation_1524  -1
    load_2_20_11  segment_prefix_lb_1525  1
    load_2_20_11  segment_prefix_ub_1526  1
    load_2_20_11  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1452  -30
    arc_2_20_12  connected_order_arc_1453  -13
    arc_2_20_12  in_degree_1528  1
    arc_2_20_12  out_degree_1578  1
    arc_2_20_12  original_T_including_depot_unload_1599  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1452  1
    load_2_20_12  segment_load_conservation_1531  -1
    load_2_20_12  segment_prefix_lb_1532  1
    load_2_20_12  segment_prefix_ub_1533  1
    load_2_20_12  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1454  -30
    arc_2_20_13  connected_order_arc_1455  -13
    arc_2_20_13  in_degree_1535  1
    arc_2_20_13  out_degree_1578  1
    arc_2_20_13  original_T_including_depot_unload_1599  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1454  1
    load_2_20_13  segment_load_conservation_1538  -1
    load_2_20_13  segment_prefix_lb_1539  1
    load_2_20_13  segment_prefix_ub_1540  1
    load_2_20_13  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1456  -30
    arc_2_20_14  connected_order_arc_1457  -13
    arc_2_20_14  in_degree_1542  1
    arc_2_20_14  out_degree_1578  1
    arc_2_20_14  original_T_including_depot_unload_1599  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1456  1
    load_2_20_14  segment_load_conservation_1545  -1
    load_2_20_14  segment_prefix_lb_1546  1
    load_2_20_14  segment_prefix_ub_1547  1
    load_2_20_14  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1458  -30
    arc_2_20_15  connected_order_arc_1459  -13
    arc_2_20_15  in_degree_1549  1
    arc_2_20_15  out_degree_1578  1
    arc_2_20_15  original_T_including_depot_unload_1599  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1458  1
    load_2_20_15  free_load_conservation_1553  -1
    load_2_20_15  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1460  -30
    arc_2_20_16  connected_order_arc_1461  -13
    arc_2_20_16  in_degree_1555  1
    arc_2_20_16  out_degree_1578  1
    arc_2_20_16  original_T_including_depot_unload_1599  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1460  1
    load_2_20_16  free_load_conservation_1559  -1
    load_2_20_16  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1462  -30
    arc_2_20_17  connected_order_arc_1463  -13
    arc_2_20_17  in_degree_1561  1
    arc_2_20_17  out_degree_1578  1
    arc_2_20_17  original_T_including_depot_unload_1599  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1462  1
    load_2_20_17  free_load_conservation_1565  -1
    load_2_20_17  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1464  -30
    arc_2_20_18  connected_order_arc_1465  -13
    arc_2_20_18  in_degree_1567  1
    arc_2_20_18  out_degree_1578  1
    arc_2_20_18  original_T_including_depot_unload_1599  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1464  1
    load_2_20_18  free_load_conservation_1571  -1
    load_2_20_18  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1466  -30
    arc_2_20_19  connected_order_arc_1467  -13
    arc_2_20_19  in_degree_1573  1
    arc_2_20_19  out_degree_1578  1
    arc_2_20_19  original_T_including_depot_unload_1599  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1466  1
    load_2_20_19  free_load_conservation_1577  -1
    load_2_20_19  free_load_conservation_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1468  -30
    arc_2_20_21  connected_order_arc_1469  -13
    arc_2_20_21  out_degree_1578  1
    arc_2_20_21  in_degree_1585  1
    arc_2_20_21  original_T_including_depot_unload_1599  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1468  1
    load_2_20_21  free_load_conservation_1583  1
    load_2_20_21  free_load_conservation_1589  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1470  -30
    arc_2_20_22  connected_order_arc_1471  -13
    arc_2_20_22  out_degree_1578  1
    arc_2_20_22  in_degree_1591  1
    arc_2_20_22  original_T_including_depot_unload_1599  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1470  1
    load_2_20_22  free_load_conservation_1583  1
    load_2_20_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1472  -30
    arc_2_21_0  depot_return_or_bypass_1519  1
    arc_2_21_0  out_degree_1584  1
    arc_2_21_0  original_T_including_depot_unload_1599  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1472  1
    load_2_21_0  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1473  -30
    arc_2_21_11  connected_order_arc_1474  -13
    arc_2_21_11  in_degree_1521  1
    arc_2_21_11  out_degree_1584  1
    arc_2_21_11  original_T_including_depot_unload_1599  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1473  1
    load_2_21_11  segment_load_conservation_1524  -1
    load_2_21_11  segment_prefix_lb_1525  1
    load_2_21_11  segment_prefix_ub_1526  1
    load_2_21_11  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1475  -30
    arc_2_21_12  connected_order_arc_1476  -13
    arc_2_21_12  in_degree_1528  1
    arc_2_21_12  out_degree_1584  1
    arc_2_21_12  original_T_including_depot_unload_1599  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1475  1
    load_2_21_12  segment_load_conservation_1531  -1
    load_2_21_12  segment_prefix_lb_1532  1
    load_2_21_12  segment_prefix_ub_1533  1
    load_2_21_12  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1477  -30
    arc_2_21_13  connected_order_arc_1478  -13
    arc_2_21_13  in_degree_1535  1
    arc_2_21_13  out_degree_1584  1
    arc_2_21_13  original_T_including_depot_unload_1599  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1477  1
    load_2_21_13  segment_load_conservation_1538  -1
    load_2_21_13  segment_prefix_lb_1539  1
    load_2_21_13  segment_prefix_ub_1540  1
    load_2_21_13  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1479  -30
    arc_2_21_14  connected_order_arc_1480  -13
    arc_2_21_14  in_degree_1542  1
    arc_2_21_14  out_degree_1584  1
    arc_2_21_14  original_T_including_depot_unload_1599  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1479  1
    load_2_21_14  segment_load_conservation_1545  -1
    load_2_21_14  segment_prefix_lb_1546  1
    load_2_21_14  segment_prefix_ub_1547  1
    load_2_21_14  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1481  -30
    arc_2_21_15  connected_order_arc_1482  -13
    arc_2_21_15  in_degree_1549  1
    arc_2_21_15  out_degree_1584  1
    arc_2_21_15  original_T_including_depot_unload_1599  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1481  1
    load_2_21_15  free_load_conservation_1553  -1
    load_2_21_15  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1483  -30
    arc_2_21_16  connected_order_arc_1484  -13
    arc_2_21_16  in_degree_1555  1
    arc_2_21_16  out_degree_1584  1
    arc_2_21_16  original_T_including_depot_unload_1599  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1483  1
    load_2_21_16  free_load_conservation_1559  -1
    load_2_21_16  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1485  -30
    arc_2_21_17  connected_order_arc_1486  -13
    arc_2_21_17  in_degree_1561  1
    arc_2_21_17  out_degree_1584  1
    arc_2_21_17  original_T_including_depot_unload_1599  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1485  1
    load_2_21_17  free_load_conservation_1565  -1
    load_2_21_17  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1487  -30
    arc_2_21_18  connected_order_arc_1488  -13
    arc_2_21_18  in_degree_1567  1
    arc_2_21_18  out_degree_1584  1
    arc_2_21_18  original_T_including_depot_unload_1599  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1487  1
    load_2_21_18  free_load_conservation_1571  -1
    load_2_21_18  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1489  -30
    arc_2_21_19  connected_order_arc_1490  -13
    arc_2_21_19  in_degree_1573  1
    arc_2_21_19  out_degree_1584  1
    arc_2_21_19  original_T_including_depot_unload_1599  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1489  1
    load_2_21_19  free_load_conservation_1577  -1
    load_2_21_19  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1491  -30
    arc_2_21_20  connected_order_arc_1492  -13
    arc_2_21_20  in_degree_1579  1
    arc_2_21_20  out_degree_1584  1
    arc_2_21_20  original_T_including_depot_unload_1599  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1491  1
    load_2_21_20  free_load_conservation_1583  -1
    load_2_21_20  free_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1493  -30
    arc_2_21_22  connected_order_arc_1494  -13
    arc_2_21_22  out_degree_1584  1
    arc_2_21_22  in_degree_1591  1
    arc_2_21_22  original_T_including_depot_unload_1599  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1493  1
    load_2_21_22  free_load_conservation_1589  1
    load_2_21_22  free_load_conservation_1595  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1495  -30
    arc_2_22_0  depot_return_or_bypass_1519  1
    arc_2_22_0  out_degree_1590  1
    arc_2_22_0  original_T_including_depot_unload_1599  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1495  1
    load_2_22_0  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1496  -30
    arc_2_22_11  connected_order_arc_1497  -13
    arc_2_22_11  in_degree_1521  1
    arc_2_22_11  out_degree_1590  1
    arc_2_22_11  original_T_including_depot_unload_1599  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1496  1
    load_2_22_11  segment_load_conservation_1524  -1
    load_2_22_11  segment_prefix_lb_1525  1
    load_2_22_11  segment_prefix_ub_1526  1
    load_2_22_11  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1498  -30
    arc_2_22_12  connected_order_arc_1499  -13
    arc_2_22_12  in_degree_1528  1
    arc_2_22_12  out_degree_1590  1
    arc_2_22_12  original_T_including_depot_unload_1599  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1498  1
    load_2_22_12  segment_load_conservation_1531  -1
    load_2_22_12  segment_prefix_lb_1532  1
    load_2_22_12  segment_prefix_ub_1533  1
    load_2_22_12  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1500  -30
    arc_2_22_13  connected_order_arc_1501  -13
    arc_2_22_13  in_degree_1535  1
    arc_2_22_13  out_degree_1590  1
    arc_2_22_13  original_T_including_depot_unload_1599  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1500  1
    load_2_22_13  segment_load_conservation_1538  -1
    load_2_22_13  segment_prefix_lb_1539  1
    load_2_22_13  segment_prefix_ub_1540  1
    load_2_22_13  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1502  -30
    arc_2_22_14  connected_order_arc_1503  -13
    arc_2_22_14  in_degree_1542  1
    arc_2_22_14  out_degree_1590  1
    arc_2_22_14  original_T_including_depot_unload_1599  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1502  1
    load_2_22_14  segment_load_conservation_1545  -1
    load_2_22_14  segment_prefix_lb_1546  1
    load_2_22_14  segment_prefix_ub_1547  1
    load_2_22_14  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1504  -30
    arc_2_22_15  connected_order_arc_1505  -13
    arc_2_22_15  in_degree_1549  1
    arc_2_22_15  out_degree_1590  1
    arc_2_22_15  original_T_including_depot_unload_1599  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1504  1
    load_2_22_15  free_load_conservation_1553  -1
    load_2_22_15  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1506  -30
    arc_2_22_16  connected_order_arc_1507  -13
    arc_2_22_16  in_degree_1555  1
    arc_2_22_16  out_degree_1590  1
    arc_2_22_16  original_T_including_depot_unload_1599  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1506  1
    load_2_22_16  free_load_conservation_1559  -1
    load_2_22_16  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1508  -30
    arc_2_22_17  connected_order_arc_1509  -13
    arc_2_22_17  in_degree_1561  1
    arc_2_22_17  out_degree_1590  1
    arc_2_22_17  original_T_including_depot_unload_1599  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1508  1
    load_2_22_17  free_load_conservation_1565  -1
    load_2_22_17  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1510  -30
    arc_2_22_18  connected_order_arc_1511  -13
    arc_2_22_18  in_degree_1567  1
    arc_2_22_18  out_degree_1590  1
    arc_2_22_18  original_T_including_depot_unload_1599  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1510  1
    load_2_22_18  free_load_conservation_1571  -1
    load_2_22_18  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1512  -30
    arc_2_22_19  connected_order_arc_1513  -13
    arc_2_22_19  in_degree_1573  1
    arc_2_22_19  out_degree_1590  1
    arc_2_22_19  original_T_including_depot_unload_1599  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1512  1
    load_2_22_19  free_load_conservation_1577  -1
    load_2_22_19  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1514  -30
    arc_2_22_20  connected_order_arc_1515  -13
    arc_2_22_20  in_degree_1579  1
    arc_2_22_20  out_degree_1590  1
    arc_2_22_20  original_T_including_depot_unload_1599  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1514  1
    load_2_22_20  free_load_conservation_1583  -1
    load_2_22_20  free_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1516  -30
    arc_2_22_21  connected_order_arc_1517  -13
    arc_2_22_21  in_degree_1585  1
    arc_2_22_21  out_degree_1590  1
    arc_2_22_21  original_T_including_depot_unload_1599  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1516  1
    load_2_22_21  free_load_conservation_1589  -1
    load_2_22_21  free_load_conservation_1595  1
RHS
    RHS1      OBJ       -4.1250000000000009e-01
    RHS1      onehot_30_18  1
    RHS1      onehot_35_53  1
    RHS1      onehot_31_82  1
    RHS1      onehot_32_111  1
    RHS1      onehot_2_146  1
    RHS1      onehot_26_167  1
    RHS1      onehot_16_196  1
    RHS1      onehot_19_217  1
    RHS1      stock_ub_221  26
    RHS1      parent_nonstrict_scope_222  3.4398177341474812e-01
    RHS1      normalization_279  1
    RHS1      connected_order_arc_387  -13
    RHS1      connected_order_arc_389  -13
    RHS1      connected_order_arc_391  -13
    RHS1      connected_order_arc_393  -13
    RHS1      connected_order_arc_395  -13
    RHS1      connected_order_arc_397  -13
    RHS1      connected_order_arc_399  -13
    RHS1      connected_order_arc_401  -13
    RHS1      connected_order_arc_403  -13
    RHS1      connected_order_arc_405  -13
    RHS1      connected_order_arc_407  -13
    RHS1      connected_order_arc_409  -13
    RHS1      connected_order_arc_412  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_422  -13
    RHS1      connected_order_arc_424  -13
    RHS1      connected_order_arc_426  -13
    RHS1      connected_order_arc_428  -13
    RHS1      connected_order_arc_430  -13
    RHS1      connected_order_arc_432  -13
    RHS1      connected_order_arc_434  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_453  -13
    RHS1      connected_order_arc_455  -13
    RHS1      connected_order_arc_457  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_695  -13
    RHS1      connected_order_arc_697  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_705  -13
    RHS1      connected_order_arc_707  -13
    RHS1      connected_order_arc_709  -13
    RHS1      depot_departure_or_bypass_710  1
    RHS1      depot_return_or_bypass_711  1
    RHS1      segment_load_conservation_716  9
    RHS1      segment_prefix_ub_718  3
    RHS1      segment_load_conservation_723  -4
    RHS1      segment_prefix_lb_724  4
    RHS1      segment_prefix_ub_725  20
    RHS1      segment_load_conservation_730  -2
    RHS1      segment_prefix_lb_731  2
    RHS1      segment_prefix_ub_732  20
    RHS1      segment_load_conservation_737  4
    RHS1      segment_prefix_ub_739  10
    RHS1      segment_load_conservation_744  -6
    RHS1      segment_prefix_lb_745  6
    RHS1      segment_prefix_ub_746  20
    RHS1      fixed_segment_relative_order_795  1
    RHS1      fixed_segment_relative_order_796  1
    RHS1      fixed_segment_relative_order_797  1
    RHS1      fixed_segment_relative_order_798  1
    RHS1      original_T_including_depot_unload_799  2.3344914879440339e+03
    RHS1      connected_order_arc_816  -13
    RHS1      connected_order_arc_818  -13
    RHS1      connected_order_arc_820  -13
    RHS1      connected_order_arc_822  -13
    RHS1      connected_order_arc_824  -13
    RHS1      connected_order_arc_826  -13
    RHS1      connected_order_arc_828  -13
    RHS1      connected_order_arc_830  -13
    RHS1      connected_order_arc_832  -13
    RHS1      connected_order_arc_834  -13
    RHS1      connected_order_arc_836  -13
    RHS1      connected_order_arc_838  -13
    RHS1      connected_order_arc_841  -13
    RHS1      connected_order_arc_843  -13
    RHS1      connected_order_arc_845  -13
    RHS1      connected_order_arc_847  -13
    RHS1      connected_order_arc_849  -13
    RHS1      connected_order_arc_851  -13
    RHS1      connected_order_arc_853  -13
    RHS1      connected_order_arc_855  -13
    RHS1      connected_order_arc_857  -13
    RHS1      connected_order_arc_859  -13
    RHS1      connected_order_arc_861  -13
    RHS1      connected_order_arc_863  -13
    RHS1      connected_order_arc_866  -13
    RHS1      connected_order_arc_868  -13
    RHS1      connected_order_arc_870  -13
    RHS1      connected_order_arc_872  -13
    RHS1      connected_order_arc_874  -13
    RHS1      connected_order_arc_876  -13
    RHS1      connected_order_arc_878  -13
    RHS1      connected_order_arc_880  -13
    RHS1      connected_order_arc_882  -13
    RHS1      connected_order_arc_884  -13
    RHS1      connected_order_arc_886  -13
    RHS1      connected_order_arc_888  -13
    RHS1      connected_order_arc_891  -13
    RHS1      connected_order_arc_893  -13
    RHS1      connected_order_arc_895  -13
    RHS1      connected_order_arc_897  -13
    RHS1      connected_order_arc_899  -13
    RHS1      connected_order_arc_901  -13
    RHS1      connected_order_arc_903  -13
    RHS1      connected_order_arc_905  -13
    RHS1      connected_order_arc_907  -13
    RHS1      connected_order_arc_909  -13
    RHS1      connected_order_arc_911  -13
    RHS1      connected_order_arc_913  -13
    RHS1      connected_order_arc_916  -13
    RHS1      connected_order_arc_918  -13
    RHS1      connected_order_arc_920  -13
    RHS1      connected_order_arc_922  -13
    RHS1      connected_order_arc_924  -13
    RHS1      connected_order_arc_926  -13
    RHS1      connected_order_arc_928  -13
    RHS1      connected_order_arc_930  -13
    RHS1      connected_order_arc_932  -13
    RHS1      connected_order_arc_934  -13
    RHS1      connected_order_arc_936  -13
    RHS1      connected_order_arc_938  -13
    RHS1      connected_order_arc_941  -13
    RHS1      connected_order_arc_943  -13
    RHS1      connected_order_arc_945  -13
    RHS1      connected_order_arc_947  -13
    RHS1      connected_order_arc_949  -13
    RHS1      connected_order_arc_951  -13
    RHS1      connected_order_arc_953  -13
    RHS1      connected_order_arc_955  -13
    RHS1      connected_order_arc_957  -13
    RHS1      connected_order_arc_959  -13
    RHS1      connected_order_arc_961  -13
    RHS1      connected_order_arc_963  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_974  -13
    RHS1      connected_order_arc_976  -13
    RHS1      connected_order_arc_978  -13
    RHS1      connected_order_arc_980  -13
    RHS1      connected_order_arc_982  -13
    RHS1      connected_order_arc_984  -13
    RHS1      connected_order_arc_986  -13
    RHS1      connected_order_arc_988  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_999  -13
    RHS1      connected_order_arc_1001  -13
    RHS1      connected_order_arc_1003  -13
    RHS1      connected_order_arc_1005  -13
    RHS1      connected_order_arc_1007  -13
    RHS1      connected_order_arc_1009  -13
    RHS1      connected_order_arc_1011  -13
    RHS1      connected_order_arc_1013  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1024  -13
    RHS1      connected_order_arc_1026  -13
    RHS1      connected_order_arc_1028  -13
    RHS1      connected_order_arc_1030  -13
    RHS1      connected_order_arc_1032  -13
    RHS1      connected_order_arc_1034  -13
    RHS1      connected_order_arc_1036  -13
    RHS1      connected_order_arc_1038  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1049  -13
    RHS1      connected_order_arc_1051  -13
    RHS1      connected_order_arc_1053  -13
    RHS1      connected_order_arc_1055  -13
    RHS1      connected_order_arc_1057  -13
    RHS1      connected_order_arc_1059  -13
    RHS1      connected_order_arc_1061  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1074  -13
    RHS1      connected_order_arc_1076  -13
    RHS1      connected_order_arc_1078  -13
    RHS1      connected_order_arc_1080  -13
    RHS1      connected_order_arc_1082  -13
    RHS1      connected_order_arc_1084  -13
    RHS1      connected_order_arc_1086  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1099  -13
    RHS1      connected_order_arc_1101  -13
    RHS1      connected_order_arc_1103  -13
    RHS1      connected_order_arc_1105  -13
    RHS1      connected_order_arc_1107  -13
    RHS1      connected_order_arc_1109  -13
    RHS1      connected_order_arc_1111  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      connected_order_arc_1124  -13
    RHS1      connected_order_arc_1126  -13
    RHS1      connected_order_arc_1128  -13
    RHS1      connected_order_arc_1130  -13
    RHS1      connected_order_arc_1132  -13
    RHS1      connected_order_arc_1134  -13
    RHS1      connected_order_arc_1136  -13
    RHS1      connected_order_arc_1138  -13
    RHS1      depot_departure_or_bypass_1139  1
    RHS1      depot_return_or_bypass_1140  1
    RHS1      segment_load_conservation_1145  6
    RHS1      segment_prefix_ub_1147  19
    RHS1      segment_load_conservation_1152  -5
    RHS1      segment_prefix_lb_1153  6
    RHS1      segment_prefix_ub_1154  25
    RHS1      segment_load_conservation_1159  3
    RHS1      segment_prefix_ub_1161  22
    RHS1      segment_load_conservation_1166  3
    RHS1      segment_prefix_ub_1168  22
    RHS1      segment_load_conservation_1173  -5
    RHS1      segment_prefix_lb_1174  5
    RHS1      segment_prefix_ub_1175  25
    RHS1      fixed_segment_relative_order_1224  1
    RHS1      fixed_segment_relative_order_1225  1
    RHS1      fixed_segment_relative_order_1226  1
    RHS1      fixed_segment_relative_order_1227  1
    RHS1      original_T_including_depot_unload_1228  2.2933958320926176e+03
    RHS1      connected_order_arc_1244  -12
    RHS1      connected_order_arc_1246  -12
    RHS1      connected_order_arc_1248  -12
    RHS1      connected_order_arc_1250  -12
    RHS1      connected_order_arc_1252  -12
    RHS1      connected_order_arc_1254  -12
    RHS1      connected_order_arc_1256  -12
    RHS1      connected_order_arc_1258  -12
    RHS1      connected_order_arc_1260  -12
    RHS1      connected_order_arc_1262  -12
    RHS1      connected_order_arc_1264  -12
    RHS1      connected_order_arc_1267  -12
    RHS1      connected_order_arc_1269  -12
    RHS1      connected_order_arc_1271  -12
    RHS1      connected_order_arc_1273  -12
    RHS1      connected_order_arc_1275  -12
    RHS1      connected_order_arc_1277  -12
    RHS1      connected_order_arc_1279  -12
    RHS1      connected_order_arc_1281  -12
    RHS1      connected_order_arc_1283  -12
    RHS1      connected_order_arc_1285  -12
    RHS1      connected_order_arc_1287  -12
    RHS1      connected_order_arc_1290  -12
    RHS1      connected_order_arc_1292  -12
    RHS1      connected_order_arc_1294  -12
    RHS1      connected_order_arc_1296  -12
    RHS1      connected_order_arc_1298  -12
    RHS1      connected_order_arc_1300  -12
    RHS1      connected_order_arc_1302  -12
    RHS1      connected_order_arc_1304  -12
    RHS1      connected_order_arc_1306  -12
    RHS1      connected_order_arc_1308  -12
    RHS1      connected_order_arc_1310  -12
    RHS1      connected_order_arc_1313  -12
    RHS1      connected_order_arc_1315  -12
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1321  -12
    RHS1      connected_order_arc_1323  -12
    RHS1      connected_order_arc_1325  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1331  -12
    RHS1      connected_order_arc_1333  -12
    RHS1      connected_order_arc_1336  -12
    RHS1      connected_order_arc_1338  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1344  -12
    RHS1      connected_order_arc_1346  -12
    RHS1      connected_order_arc_1348  -12
    RHS1      connected_order_arc_1350  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1354  -12
    RHS1      connected_order_arc_1356  -12
    RHS1      connected_order_arc_1359  -12
    RHS1      connected_order_arc_1361  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1367  -12
    RHS1      connected_order_arc_1369  -12
    RHS1      connected_order_arc_1371  -12
    RHS1      connected_order_arc_1373  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1377  -12
    RHS1      connected_order_arc_1379  -12
    RHS1      connected_order_arc_1382  -12
    RHS1      connected_order_arc_1384  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1390  -12
    RHS1      connected_order_arc_1392  -12
    RHS1      connected_order_arc_1394  -12
    RHS1      connected_order_arc_1396  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1400  -12
    RHS1      connected_order_arc_1402  -12
    RHS1      connected_order_arc_1405  -12
    RHS1      connected_order_arc_1407  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1413  -12
    RHS1      connected_order_arc_1415  -12
    RHS1      connected_order_arc_1417  -12
    RHS1      connected_order_arc_1419  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1423  -12
    RHS1      connected_order_arc_1425  -12
    RHS1      connected_order_arc_1428  -12
    RHS1      connected_order_arc_1430  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1436  -12
    RHS1      connected_order_arc_1438  -12
    RHS1      connected_order_arc_1440  -12
    RHS1      connected_order_arc_1442  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1446  -12
    RHS1      connected_order_arc_1448  -12
    RHS1      connected_order_arc_1451  -12
    RHS1      connected_order_arc_1453  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1459  -12
    RHS1      connected_order_arc_1461  -12
    RHS1      connected_order_arc_1463  -12
    RHS1      connected_order_arc_1465  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1469  -12
    RHS1      connected_order_arc_1471  -12
    RHS1      connected_order_arc_1474  -12
    RHS1      connected_order_arc_1476  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1482  -12
    RHS1      connected_order_arc_1484  -12
    RHS1      connected_order_arc_1486  -12
    RHS1      connected_order_arc_1488  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1492  -12
    RHS1      connected_order_arc_1494  -12
    RHS1      connected_order_arc_1497  -12
    RHS1      connected_order_arc_1499  -12
    RHS1      connected_order_arc_1501  -12
    RHS1      connected_order_arc_1503  -12
    RHS1      connected_order_arc_1505  -12
    RHS1      connected_order_arc_1507  -12
    RHS1      connected_order_arc_1509  -12
    RHS1      connected_order_arc_1511  -12
    RHS1      connected_order_arc_1513  -12
    RHS1      connected_order_arc_1515  -12
    RHS1      connected_order_arc_1517  -12
    RHS1      depot_departure_or_bypass_1518  1
    RHS1      depot_return_or_bypass_1519  1
    RHS1      segment_load_conservation_1524  2
    RHS1      segment_prefix_ub_1526  28
    RHS1      segment_load_conservation_1531  3
    RHS1      segment_prefix_ub_1533  27
    RHS1      segment_load_conservation_1538  3
    RHS1      segment_prefix_ub_1540  27
    RHS1      segment_load_conservation_1545  -4
    RHS1      segment_prefix_lb_1546  4
    RHS1      segment_prefix_ub_1547  30
    RHS1      fixed_segment_relative_order_1596  1
    RHS1      fixed_segment_relative_order_1597  1
    RHS1      fixed_segment_relative_order_1598  1
    RHS1      original_T_including_depot_unload_1599  6240
BOUNDS
 LO BND1      t         2.4534859946816593e-02
 UP BND1      t         0.0406071739341023
 UP BND1      q         5.4048177341474812e-01
 BV BND1      x_30_0  
 UP BND1      w_30_0    0.0406071739341023
 BV BND1      x_30_1  
 UP BND1      w_30_1    0.0406071739341023
 BV BND1      x_30_2  
 UP BND1      w_30_2    0.0406071739341023
 BV BND1      x_30_3  
 UP BND1      w_30_3    0.0406071739341023
 BV BND1      x_30_4  
 UP BND1      w_30_4    0.0406071739341023
 BV BND1      x_30_5  
 UP BND1      w_30_5    0.0406071739341023
 BV BND1      x_30_6  
 UP BND1      w_30_6    0.0406071739341023
 BV BND1      x_30_7  
 UP BND1      w_30_7    0.0406071739341023
 BV BND1      x_30_8  
 UP BND1      w_30_8    0.0406071739341023
 UP BND1      rho_30    1
 BV BND1      x_35_0  
 UP BND1      w_35_0    0.0406071739341023
 BV BND1      x_35_1  
 UP BND1      w_35_1    0.0406071739341023
 BV BND1      x_35_2  
 UP BND1      w_35_2    0.0406071739341023
 BV BND1      x_35_3  
 UP BND1      w_35_3    0.0406071739341023
 BV BND1      x_35_4  
 UP BND1      w_35_4    0.0406071739341023
 BV BND1      x_35_5  
 UP BND1      w_35_5    0.0406071739341023
 BV BND1      x_35_6  
 UP BND1      w_35_6    0.0406071739341023
 BV BND1      x_35_7  
 UP BND1      w_35_7    0.0406071739341023
 BV BND1      x_35_8  
 UP BND1      w_35_8    0.0406071739341023
 BV BND1      x_35_9  
 UP BND1      w_35_9    0.0406071739341023
 BV BND1      x_35_10 
 UP BND1      w_35_10   0.0406071739341023
 BV BND1      x_35_11 
 UP BND1      w_35_11   0.0406071739341023
 BV BND1      x_35_12 
 UP BND1      w_35_12   0.0406071739341023
 BV BND1      x_35_13 
 UP BND1      w_35_13   0.0406071739341023
 BV BND1      x_35_14 
 UP BND1      w_35_14   0.0406071739341023
 BV BND1      x_35_15 
 UP BND1      w_35_15   0.0406071739341023
 UP BND1      rho_35    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    0.0406071739341023
 BV BND1      x_31_1  
 UP BND1      w_31_1    0.0406071739341023
 BV BND1      x_31_2  
 UP BND1      w_31_2    0.0406071739341023
 BV BND1      x_31_3  
 UP BND1      w_31_3    0.0406071739341023
 BV BND1      x_31_4  
 UP BND1      w_31_4    0.0406071739341023
 BV BND1      x_31_5  
 UP BND1      w_31_5    0.0406071739341023
 BV BND1      x_31_6  
 UP BND1      w_31_6    0.0406071739341023
 BV BND1      x_31_7  
 UP BND1      w_31_7    0.0406071739341023
 BV BND1      x_31_8  
 UP BND1      w_31_8    0.0406071739341023
 BV BND1      x_31_9  
 UP BND1      w_31_9    0.0406071739341023
 BV BND1      x_31_10 
 UP BND1      w_31_10   0.0406071739341023
 BV BND1      x_31_11 
 UP BND1      w_31_11   0.0406071739341023
 BV BND1      x_31_12 
 UP BND1      w_31_12   0.0406071739341023
 UP BND1      rho_31    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    0.0406071739341023
 BV BND1      x_32_1  
 UP BND1      w_32_1    0.0406071739341023
 BV BND1      x_32_2  
 UP BND1      w_32_2    0.0406071739341023
 BV BND1      x_32_3  
 UP BND1      w_32_3    0.0406071739341023
 BV BND1      x_32_4  
 UP BND1      w_32_4    0.0406071739341023
 BV BND1      x_32_5  
 UP BND1      w_32_5    0.0406071739341023
 BV BND1      x_32_6  
 UP BND1      w_32_6    0.0406071739341023
 BV BND1      x_32_7  
 UP BND1      w_32_7    0.0406071739341023
 BV BND1      x_32_8  
 UP BND1      w_32_8    0.0406071739341023
 BV BND1      x_32_9  
 UP BND1      w_32_9    0.0406071739341023
 BV BND1      x_32_10 
 UP BND1      w_32_10   0.0406071739341023
 BV BND1      x_32_11 
 UP BND1      w_32_11   0.0406071739341023
 BV BND1      x_32_12 
 UP BND1      w_32_12   0.0406071739341023
 UP BND1      rho_32    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     0.0406071739341023
 BV BND1      x_2_1   
 UP BND1      w_2_1     0.0406071739341023
 BV BND1      x_2_2   
 UP BND1      w_2_2     0.0406071739341023
 BV BND1      x_2_3   
 UP BND1      w_2_3     0.0406071739341023
 BV BND1      x_2_4   
 UP BND1      w_2_4     0.0406071739341023
 BV BND1      x_2_5   
 UP BND1      w_2_5     0.0406071739341023
 BV BND1      x_2_6   
 UP BND1      w_2_6     0.0406071739341023
 BV BND1      x_2_7   
 UP BND1      w_2_7     0.0406071739341023
 BV BND1      x_2_8   
 UP BND1      w_2_8     0.0406071739341023
 BV BND1      x_2_9   
 UP BND1      w_2_9     0.0406071739341023
 BV BND1      x_2_10  
 UP BND1      w_2_10    0.0406071739341023
 BV BND1      x_2_11  
 UP BND1      w_2_11    0.0406071739341023
 BV BND1      x_2_12  
 UP BND1      w_2_12    0.0406071739341023
 BV BND1      x_2_13  
 UP BND1      w_2_13    0.0406071739341023
 BV BND1      x_2_14  
 UP BND1      w_2_14    0.0406071739341023
 BV BND1      x_2_15  
 UP BND1      w_2_15    0.0406071739341023
 UP BND1      rho_2     1
 BV BND1      x_26_0  
 UP BND1      w_26_0    0.0406071739341023
 BV BND1      x_26_1  
 UP BND1      w_26_1    0.0406071739341023
 BV BND1      x_26_2  
 UP BND1      w_26_2    0.0406071739341023
 BV BND1      x_26_3  
 UP BND1      w_26_3    0.0406071739341023
 BV BND1      x_26_4  
 UP BND1      w_26_4    0.0406071739341023
 BV BND1      x_26_5  
 UP BND1      w_26_5    0.0406071739341023
 BV BND1      x_26_6  
 UP BND1      w_26_6    0.0406071739341023
 BV BND1      x_26_7  
 UP BND1      w_26_7    0.0406071739341023
 BV BND1      x_26_8  
 UP BND1      w_26_8    0.0406071739341023
 UP BND1      rho_26    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    0.0406071739341023
 BV BND1      x_16_1  
 UP BND1      w_16_1    0.0406071739341023
 BV BND1      x_16_2  
 UP BND1      w_16_2    0.0406071739341023
 BV BND1      x_16_3  
 UP BND1      w_16_3    0.0406071739341023
 BV BND1      x_16_4  
 UP BND1      w_16_4    0.0406071739341023
 BV BND1      x_16_5  
 UP BND1      w_16_5    0.0406071739341023
 BV BND1      x_16_6  
 UP BND1      w_16_6    0.0406071739341023
 BV BND1      x_16_7  
 UP BND1      w_16_7    0.0406071739341023
 BV BND1      x_16_8  
 UP BND1      w_16_8    0.0406071739341023
 BV BND1      x_16_9  
 UP BND1      w_16_9    0.0406071739341023
 BV BND1      x_16_10 
 UP BND1      w_16_10   0.0406071739341023
 BV BND1      x_16_11 
 UP BND1      w_16_11   0.0406071739341023
 BV BND1      x_16_12 
 UP BND1      w_16_12   0.0406071739341023
 UP BND1      rho_16    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    0.0406071739341023
 BV BND1      x_19_1  
 UP BND1      w_19_1    0.0406071739341023
 BV BND1      x_19_2  
 UP BND1      w_19_2    0.0406071739341023
 BV BND1      x_19_3  
 UP BND1      w_19_3    0.0406071739341023
 BV BND1      x_19_4  
 UP BND1      w_19_4    0.0406071739341023
 BV BND1      x_19_5  
 UP BND1      w_19_5    0.0406071739341023
 BV BND1      x_19_6  
 UP BND1      w_19_6    0.0406071739341023
 BV BND1      x_19_7  
 UP BND1      w_19_7    0.0406071739341023
 BV BND1      x_19_8  
 UP BND1      w_19_8    0.0406071739341023
 UP BND1      rho_19    1
 UP BND1      a_30_35   1
 UP BND1      a_30_31   1
 UP BND1      a_30_32   1
 UP BND1      a_30_2    1
 UP BND1      a_30_26   1
 UP BND1      a_30_16   1
 UP BND1      a_30_19   1
 UP BND1      a_35_31   1
 UP BND1      a_35_32   1
 UP BND1      a_35_2    1
 UP BND1      a_35_26   1
 UP BND1      a_35_16   1
 UP BND1      a_35_19   1
 UP BND1      a_31_32   1
 UP BND1      a_31_2    1
 UP BND1      a_31_26   1
 UP BND1      a_31_16   1
 UP BND1      a_31_19   1
 UP BND1      a_32_2    1
 UP BND1      a_32_26   1
 UP BND1      a_32_16   1
 UP BND1      a_32_19   1
 UP BND1      a_2_26    1
 UP BND1      a_2_16    1
 UP BND1      a_2_19    1
 UP BND1      a_26_16   1
 UP BND1      a_26_19   1
 UP BND1      a_16_19   1
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_3
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_3
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_3
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_5
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_5
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_5
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_6_22
 UP BND1      load_1_6_22  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_6
 UP BND1      load_1_22_6  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
