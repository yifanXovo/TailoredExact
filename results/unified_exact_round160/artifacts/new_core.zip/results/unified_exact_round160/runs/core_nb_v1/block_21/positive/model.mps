* Signature: 0x2aff1dd40e80480e
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 G  product_lb_40
 L  product_ub_41
 G  product_lb_42
 L  product_ub_43
 E  onehot_8_44
 E  normalized_mass_8_45
 E  normalized_ratio_8_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 G  product_lb_77
 L  product_ub_78
 E  onehot_2_79
 E  normalized_mass_2_80
 E  normalized_ratio_2_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 E  onehot_31_108
 E  normalized_mass_31_109
 E  normalized_ratio_31_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 E  onehot_6_133
 E  normalized_mass_6_134
 E  normalized_ratio_6_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 E  onehot_16_162
 E  normalized_mass_16_163
 E  normalized_ratio_16_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 E  onehot_5_199
 E  normalized_mass_5_200
 E  normalized_ratio_5_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 E  onehot_26_220
 E  normalized_mass_26_221
 E  normalized_ratio_26_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 E  onehot_14_255
 E  normalized_mass_14_256
 E  normalized_ratio_14_257
 G  stock_lb_258
 L  stock_ub_259
 L  parent_nonstrict_scope_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 E  normalization_317
 G  full_original_Gini_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 L  arc_capacity_428
 L  arc_capacity_429
 L  arc_capacity_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 E  depot_departure_or_bypass_767
 E  depot_return_or_bypass_768
 E  out_degree_769
 E  in_degree_770
 G  order_active_lb_771
 L  order_active_ub_772
 E  segment_load_conservation_773
 G  segment_prefix_lb_774
 L  segment_prefix_ub_775
 E  out_degree_776
 E  in_degree_777
 G  order_active_lb_778
 L  order_active_ub_779
 E  segment_load_conservation_780
 G  segment_prefix_lb_781
 L  segment_prefix_ub_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  segment_load_conservation_787
 G  segment_prefix_lb_788
 L  segment_prefix_ub_789
 E  out_degree_790
 E  in_degree_791
 G  order_active_lb_792
 L  order_active_ub_793
 E  segment_load_conservation_794
 G  segment_prefix_lb_795
 L  segment_prefix_ub_796
 E  out_degree_797
 E  in_degree_798
 G  order_active_lb_799
 L  order_active_ub_800
 E  segment_load_conservation_801
 G  segment_prefix_lb_802
 L  segment_prefix_ub_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  service_visit_def_808
 E  free_load_conservation_809
 E  out_degree_810
 E  in_degree_811
 G  order_active_lb_812
 L  order_active_ub_813
 E  service_visit_def_814
 E  free_load_conservation_815
 E  out_degree_816
 E  in_degree_817
 G  order_active_lb_818
 L  order_active_ub_819
 E  service_visit_def_820
 E  free_load_conservation_821
 E  out_degree_822
 E  in_degree_823
 G  order_active_lb_824
 L  order_active_ub_825
 E  service_visit_def_826
 E  free_load_conservation_827
 E  out_degree_828
 E  in_degree_829
 G  order_active_lb_830
 L  order_active_ub_831
 E  service_visit_def_832
 E  free_load_conservation_833
 E  out_degree_834
 E  in_degree_835
 G  order_active_lb_836
 L  order_active_ub_837
 E  service_visit_def_838
 E  free_load_conservation_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  service_visit_def_844
 E  free_load_conservation_845
 E  out_degree_846
 E  in_degree_847
 G  order_active_lb_848
 L  order_active_ub_849
 E  service_visit_def_850
 E  free_load_conservation_851
 G  fixed_segment_relative_order_852
 G  fixed_segment_relative_order_853
 G  fixed_segment_relative_order_854
 G  fixed_segment_relative_order_855
 L  original_T_including_depot_unload_856
 L  arc_capacity_857
 L  arc_capacity_858
 L  arc_capacity_859
 L  arc_capacity_860
 L  arc_capacity_861
 L  arc_capacity_862
 L  arc_capacity_863
 L  arc_capacity_864
 L  arc_capacity_865
 L  arc_capacity_866
 L  arc_capacity_867
 L  arc_capacity_868
 L  arc_capacity_869
 L  arc_capacity_870
 L  arc_capacity_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 G  connected_order_arc_1177
 L  arc_capacity_1178
 G  connected_order_arc_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 E  depot_departure_or_bypass_1196
 E  depot_return_or_bypass_1197
 E  out_degree_1198
 E  in_degree_1199
 G  order_active_lb_1200
 L  order_active_ub_1201
 E  segment_load_conservation_1202
 G  segment_prefix_lb_1203
 L  segment_prefix_ub_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  segment_load_conservation_1209
 G  segment_prefix_lb_1210
 L  segment_prefix_ub_1211
 E  out_degree_1212
 E  in_degree_1213
 G  order_active_lb_1214
 L  order_active_ub_1215
 E  segment_load_conservation_1216
 G  segment_prefix_lb_1217
 L  segment_prefix_ub_1218
 E  out_degree_1219
 E  in_degree_1220
 G  order_active_lb_1221
 L  order_active_ub_1222
 E  segment_load_conservation_1223
 G  segment_prefix_lb_1224
 L  segment_prefix_ub_1225
 E  out_degree_1226
 E  in_degree_1227
 G  order_active_lb_1228
 L  order_active_ub_1229
 E  segment_load_conservation_1230
 G  segment_prefix_lb_1231
 L  segment_prefix_ub_1232
 E  out_degree_1233
 E  in_degree_1234
 G  order_active_lb_1235
 L  order_active_ub_1236
 E  service_visit_def_1237
 E  free_load_conservation_1238
 E  out_degree_1239
 E  in_degree_1240
 G  order_active_lb_1241
 L  order_active_ub_1242
 E  service_visit_def_1243
 E  free_load_conservation_1244
 E  out_degree_1245
 E  in_degree_1246
 G  order_active_lb_1247
 L  order_active_ub_1248
 E  service_visit_def_1249
 E  free_load_conservation_1250
 E  out_degree_1251
 E  in_degree_1252
 G  order_active_lb_1253
 L  order_active_ub_1254
 E  service_visit_def_1255
 E  free_load_conservation_1256
 E  out_degree_1257
 E  in_degree_1258
 G  order_active_lb_1259
 L  order_active_ub_1260
 E  service_visit_def_1261
 E  free_load_conservation_1262
 E  out_degree_1263
 E  in_degree_1264
 G  order_active_lb_1265
 L  order_active_ub_1266
 E  service_visit_def_1267
 E  free_load_conservation_1268
 E  out_degree_1269
 E  in_degree_1270
 G  order_active_lb_1271
 L  order_active_ub_1272
 E  service_visit_def_1273
 E  free_load_conservation_1274
 E  out_degree_1275
 E  in_degree_1276
 G  order_active_lb_1277
 L  order_active_ub_1278
 E  service_visit_def_1279
 E  free_load_conservation_1280
 G  fixed_segment_relative_order_1281
 G  fixed_segment_relative_order_1282
 G  fixed_segment_relative_order_1283
 G  fixed_segment_relative_order_1284
 L  original_T_including_depot_unload_1285
 L  arc_capacity_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 L  arc_capacity_1292
 L  arc_capacity_1293
 L  arc_capacity_1294
 L  arc_capacity_1295
 L  arc_capacity_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 L  arc_capacity_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 G  connected_order_arc_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 G  connected_order_arc_1528
 L  arc_capacity_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 L  arc_capacity_1534
 G  connected_order_arc_1535
 L  arc_capacity_1536
 G  connected_order_arc_1537
 L  arc_capacity_1538
 G  connected_order_arc_1539
 L  arc_capacity_1540
 G  connected_order_arc_1541
 L  arc_capacity_1542
 G  connected_order_arc_1543
 L  arc_capacity_1544
 G  connected_order_arc_1545
 L  arc_capacity_1546
 G  connected_order_arc_1547
 L  arc_capacity_1548
 G  connected_order_arc_1549
 L  arc_capacity_1550
 G  connected_order_arc_1551
 L  arc_capacity_1552
 L  arc_capacity_1553
 G  connected_order_arc_1554
 L  arc_capacity_1555
 G  connected_order_arc_1556
 L  arc_capacity_1557
 G  connected_order_arc_1558
 L  arc_capacity_1559
 G  connected_order_arc_1560
 L  arc_capacity_1561
 G  connected_order_arc_1562
 L  arc_capacity_1563
 G  connected_order_arc_1564
 L  arc_capacity_1565
 G  connected_order_arc_1566
 L  arc_capacity_1567
 G  connected_order_arc_1568
 L  arc_capacity_1569
 G  connected_order_arc_1570
 L  arc_capacity_1571
 G  connected_order_arc_1572
 L  arc_capacity_1573
 G  connected_order_arc_1574
 E  depot_departure_or_bypass_1575
 E  depot_return_or_bypass_1576
 E  out_degree_1577
 E  in_degree_1578
 G  order_active_lb_1579
 L  order_active_ub_1580
 E  segment_load_conservation_1581
 G  segment_prefix_lb_1582
 L  segment_prefix_ub_1583
 E  out_degree_1584
 E  in_degree_1585
 G  order_active_lb_1586
 L  order_active_ub_1587
 E  segment_load_conservation_1588
 G  segment_prefix_lb_1589
 L  segment_prefix_ub_1590
 E  out_degree_1591
 E  in_degree_1592
 G  order_active_lb_1593
 L  order_active_ub_1594
 E  segment_load_conservation_1595
 G  segment_prefix_lb_1596
 L  segment_prefix_ub_1597
 E  out_degree_1598
 E  in_degree_1599
 G  order_active_lb_1600
 L  order_active_ub_1601
 E  segment_load_conservation_1602
 G  segment_prefix_lb_1603
 L  segment_prefix_ub_1604
 E  out_degree_1605
 E  in_degree_1606
 G  order_active_lb_1607
 L  order_active_ub_1608
 E  service_visit_def_1609
 E  free_load_conservation_1610
 E  out_degree_1611
 E  in_degree_1612
 G  order_active_lb_1613
 L  order_active_ub_1614
 E  service_visit_def_1615
 E  free_load_conservation_1616
 E  out_degree_1617
 E  in_degree_1618
 G  order_active_lb_1619
 L  order_active_ub_1620
 E  service_visit_def_1621
 E  free_load_conservation_1622
 E  out_degree_1623
 E  in_degree_1624
 G  order_active_lb_1625
 L  order_active_ub_1626
 E  service_visit_def_1627
 E  free_load_conservation_1628
 E  out_degree_1629
 E  in_degree_1630
 G  order_active_lb_1631
 L  order_active_ub_1632
 E  service_visit_def_1633
 E  free_load_conservation_1634
 E  out_degree_1635
 E  in_degree_1636
 G  order_active_lb_1637
 L  order_active_ub_1638
 E  service_visit_def_1639
 E  free_load_conservation_1640
 E  out_degree_1641
 E  in_degree_1642
 G  order_active_lb_1643
 L  order_active_ub_1644
 E  service_visit_def_1645
 E  free_load_conservation_1646
 E  out_degree_1647
 E  in_degree_1648
 G  order_active_lb_1649
 L  order_active_ub_1650
 E  service_visit_def_1651
 E  free_load_conservation_1652
 G  fixed_segment_relative_order_1653
 G  fixed_segment_relative_order_1654
 G  fixed_segment_relative_order_1655
 L  original_T_including_depot_unload_1656
COLUMNS
    t         normalized_mass_8_45  -1
    t         normalized_mass_2_80  -1
    t         normalized_mass_31_109  -1
    t         normalized_mass_6_134  -1
    t         normalized_mass_16_163  -1
    t         normalized_mass_5_200  -1
    t         normalized_mass_26_221  -1
    t         normalized_mass_14_256  -1
    t         normalization_317  2.4533333333333335e+01
    t         full_original_Gini_318  -7.6238095238095283e+01
    q         OBJ       1
    q         parent_nonstrict_scope_260  1
    q         full_original_Gini_318  35
    MARKER    'MARKER'                 'INTORG'
    x_8_0     OBJ       6.7499999999999991e-02
    x_8_0     product_lb_0  -2.4773645559889104e-02
    x_8_0     product_ub_1  -4.0760869565258165e-02
    x_8_0     onehot_8_44  1
    x_8_0     parent_nonstrict_scope_260  0.15
    x_8_0     unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_0     product_lb_0  1
    w_8_0     product_ub_1  1
    w_8_0     normalized_mass_8_45  1
    w_8_0     full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_1     OBJ       5.2500000000000005e-02
    x_8_1     product_lb_2  -2.4773645559889104e-02
    x_8_1     product_ub_3  -4.0760869565258165e-02
    x_8_1     onehot_8_44  1
    x_8_1     stock_lb_258  1
    x_8_1     stock_ub_259  1
    x_8_1     parent_nonstrict_scope_260  0.135
    x_8_1     unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_1     product_lb_2  1
    w_8_1     product_ub_3  1
    w_8_1     normalized_mass_8_45  1
    w_8_1     normalized_ratio_8_46  -0.1
    w_8_1     full_original_Gini_318  -2.1833333333333329e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_2     OBJ       3.7499999999999992e-02
    x_8_2     product_lb_4  -2.4773645559889104e-02
    x_8_2     product_ub_5  -4.0760869565258165e-02
    x_8_2     onehot_8_44  1
    x_8_2     stock_lb_258  2
    x_8_2     stock_ub_259  2
    x_8_2     parent_nonstrict_scope_260  0.12
    x_8_2     unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_2     product_lb_4  1
    w_8_2     product_ub_5  1
    w_8_2     normalized_mass_8_45  1
    w_8_2     normalized_ratio_8_46  -0.2
    w_8_2     full_original_Gini_318  -1.9133333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_3     OBJ       2.2499999999999992e-02
    x_8_3     product_lb_6  -2.4773645559889104e-02
    x_8_3     product_ub_7  -4.0760869565258165e-02
    x_8_3     onehot_8_44  1
    x_8_3     stock_lb_258  3
    x_8_3     stock_ub_259  3
    x_8_3     parent_nonstrict_scope_260  0.105
    x_8_3     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_3     product_lb_6  1
    w_8_3     product_ub_7  1
    w_8_3     normalized_mass_8_45  1
    w_8_3     normalized_ratio_8_46  -3.0000000000000004e-01
    w_8_3     full_original_Gini_318  -1.6433333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_4     OBJ       7.4999999999999928e-03
    x_8_4     product_lb_8  -2.4773645559889104e-02
    x_8_4     product_ub_9  -4.0760869565258165e-02
    x_8_4     onehot_8_44  1
    x_8_4     stock_lb_258  4
    x_8_4     stock_ub_259  4
    x_8_4     parent_nonstrict_scope_260  0.09
    x_8_4     unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_4     product_lb_8  1
    w_8_4     product_ub_9  1
    w_8_4     normalized_mass_8_45  1
    w_8_4     normalized_ratio_8_46  -0.4
    w_8_4     full_original_Gini_318  -1.3733333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_5     OBJ       -7.5000000000000067e-03
    x_8_5     product_lb_10  -2.4773645559889104e-02
    x_8_5     product_ub_11  -4.0760869565258165e-02
    x_8_5     onehot_8_44  1
    x_8_5     stock_lb_258  5
    x_8_5     stock_ub_259  5
    x_8_5     parent_nonstrict_scope_260  0.075
    x_8_5     unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_5     product_lb_10  1
    w_8_5     product_ub_11  1
    w_8_5     normalized_mass_8_45  1
    w_8_5     normalized_ratio_8_46  -0.5
    w_8_5     full_original_Gini_318  -1.1233333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_6     OBJ       -2.2500000000000020e-02
    x_8_6     product_lb_12  -2.4773645559889104e-02
    x_8_6     product_ub_13  -4.0760869565258165e-02
    x_8_6     onehot_8_44  1
    x_8_6     stock_lb_258  6
    x_8_6     stock_ub_259  6
    x_8_6     parent_nonstrict_scope_260  5.9999999999999984e-02
    x_8_6     unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_6     product_lb_12  1
    w_8_6     product_ub_13  1
    w_8_6     normalized_mass_8_45  1
    w_8_6     normalized_ratio_8_46  -6.0000000000000009e-01
    w_8_6     full_original_Gini_318  -8.9333333333333336e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_7     OBJ       -3.7500000000000012e-02
    x_8_7     product_lb_14  -2.4773645559889104e-02
    x_8_7     product_ub_15  -4.0760869565258165e-02
    x_8_7     onehot_8_44  1
    x_8_7     stock_lb_258  7
    x_8_7     stock_ub_259  7
    x_8_7     parent_nonstrict_scope_260  4.4999999999999991e-02
    x_8_7     unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_7     product_lb_14  1
    w_8_7     product_ub_15  1
    w_8_7     normalized_mass_8_45  1
    w_8_7     normalized_ratio_8_46  -7.0000000000000007e-01
    w_8_7     full_original_Gini_318  -6.83333333333333
    MARKER    'MARKER'                 'INTORG'
    x_8_8     OBJ       -5.2500000000000012e-02
    x_8_8     product_lb_16  -2.4773645559889104e-02
    x_8_8     product_ub_17  -4.0760869565258165e-02
    x_8_8     onehot_8_44  1
    x_8_8     stock_lb_258  8
    x_8_8     stock_ub_259  8
    x_8_8     parent_nonstrict_scope_260  2.9999999999999992e-02
    x_8_8     unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_8     product_lb_16  1
    w_8_8     product_ub_17  1
    w_8_8     normalized_mass_8_45  1
    w_8_8     normalized_ratio_8_46  -0.8
    w_8_8     full_original_Gini_318  -5.3476190476190482e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_9     OBJ       -0.0675
    x_8_9     product_lb_18  -2.4773645559889104e-02
    x_8_9     product_ub_19  -4.0760869565258165e-02
    x_8_9     onehot_8_44  1
    x_8_9     stock_lb_258  9
    x_8_9     stock_ub_259  9
    x_8_9     parent_nonstrict_scope_260  1.4999999999999996e-02
    x_8_9     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_9     product_lb_18  1
    w_8_9     product_ub_19  1
    w_8_9     normalized_mass_8_45  1
    w_8_9     normalized_ratio_8_46  -0.9
    w_8_9     full_original_Gini_318  -4.4666666666666677e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_10    OBJ       -0.0825
    x_8_10    product_lb_20  -2.4773645559889104e-02
    x_8_10    product_ub_21  -4.0760869565258165e-02
    x_8_10    onehot_8_44  1
    x_8_10    stock_lb_258  10
    x_8_10    stock_ub_259  10
    x_8_10    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_10    product_lb_20  1
    w_8_10    product_ub_21  1
    w_8_10    normalized_mass_8_45  1
    w_8_10    normalized_ratio_8_46  -1
    w_8_10    full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_11    OBJ       -6.7499999999999991e-02
    x_8_11    product_lb_22  -2.4773645559889104e-02
    x_8_11    product_ub_23  -4.0760869565258165e-02
    x_8_11    onehot_8_44  1
    x_8_11    stock_lb_258  11
    x_8_11    stock_ub_259  11
    x_8_11    parent_nonstrict_scope_260  1.5000000000000013e-02
    x_8_11    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_11    product_lb_22  1
    w_8_11    product_ub_23  1
    w_8_11    normalized_mass_8_45  1
    w_8_11    normalized_ratio_8_46  -1.1
    w_8_11    full_original_Gini_318  -5.8666666666666707e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_12    OBJ       -5.2499999999999977e-02
    x_8_12    product_lb_24  -2.4773645559889104e-02
    x_8_12    product_ub_25  -4.0760869565258165e-02
    x_8_12    onehot_8_44  1
    x_8_12    stock_lb_258  12
    x_8_12    stock_ub_259  12
    x_8_12    parent_nonstrict_scope_260  3.0000000000000027e-02
    x_8_12    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_12    product_lb_24  1
    w_8_12    product_ub_25  1
    w_8_12    normalized_mass_8_45  1
    w_8_12    normalized_ratio_8_46  -1.2000000000000002e+00
    w_8_12    full_original_Gini_318  -7.9666666666666694e+00
    MARKER    'MARKER'                 'INTORG'
    x_8_13    OBJ       -0.0375
    x_8_13    product_lb_26  -2.4773645559889104e-02
    x_8_13    product_ub_27  -4.0760869565258165e-02
    x_8_13    onehot_8_44  1
    x_8_13    stock_lb_258  13
    x_8_13    stock_ub_259  13
    x_8_13    parent_nonstrict_scope_260  4.5000000000000005e-02
    x_8_13    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_13    product_lb_26  1
    w_8_13    product_ub_27  1
    w_8_13    normalized_mass_8_45  1
    w_8_13    normalized_ratio_8_46  -1.3
    w_8_13    full_original_Gini_318  -1.0566666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_14    OBJ       -2.2499999999999985e-02
    x_8_14    product_lb_28  -2.4773645559889104e-02
    x_8_14    product_ub_29  -4.0760869565258165e-02
    x_8_14    onehot_8_44  1
    x_8_14    stock_lb_258  14
    x_8_14    stock_ub_259  14
    x_8_14    parent_nonstrict_scope_260  6.0000000000000019e-02
    x_8_14    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_14    product_lb_28  1
    w_8_14    product_ub_29  1
    w_8_14    normalized_mass_8_45  1
    w_8_14    normalized_ratio_8_46  -1.4000000000000001e+00
    w_8_14    full_original_Gini_318  -1.3266666666666675e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_15    OBJ       -7.5000000000000067e-03
    x_8_15    product_lb_30  -2.4773645559889104e-02
    x_8_15    product_ub_31  -4.0760869565258165e-02
    x_8_15    onehot_8_44  1
    x_8_15    stock_lb_258  15
    x_8_15    stock_ub_259  15
    x_8_15    parent_nonstrict_scope_260  0.075
    MARKER    'MARKER'                 'INTEND'
    w_8_15    product_lb_30  1
    w_8_15    product_ub_31  1
    w_8_15    normalized_mass_8_45  1
    w_8_15    normalized_ratio_8_46  -1.5
    w_8_15    full_original_Gini_318  -1.5966666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_16    OBJ       7.5000000000000067e-03
    x_8_16    product_lb_32  -2.4773645559889104e-02
    x_8_16    product_ub_33  -4.0760869565258165e-02
    x_8_16    onehot_8_44  1
    x_8_16    stock_lb_258  16
    x_8_16    stock_ub_259  16
    x_8_16    parent_nonstrict_scope_260  9.0000000000000011e-02
    x_8_16    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_16    product_lb_32  1
    w_8_16    product_ub_33  1
    w_8_16    normalized_mass_8_45  1
    w_8_16    normalized_ratio_8_46  -1.6
    w_8_16    full_original_Gini_318  -1.8666666666666668e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_17    OBJ       2.2500000000000020e-02
    x_8_17    product_lb_34  -2.4773645559889104e-02
    x_8_17    product_ub_35  -4.0760869565258165e-02
    x_8_17    onehot_8_44  1
    x_8_17    stock_lb_258  17
    x_8_17    stock_ub_259  17
    x_8_17    parent_nonstrict_scope_260  1.0500000000000002e-01
    x_8_17    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_17    product_lb_34  1
    w_8_17    product_ub_35  1
    w_8_17    normalized_mass_8_45  1
    w_8_17    normalized_ratio_8_46  -1.7000000000000002e+00
    w_8_17    full_original_Gini_318  -2.1366666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_18    OBJ       3.7499999999999992e-02
    x_8_18    product_lb_36  -2.4773645559889104e-02
    x_8_18    product_ub_37  -4.0760869565258165e-02
    x_8_18    onehot_8_44  1
    x_8_18    stock_lb_258  18
    x_8_18    stock_ub_259  18
    x_8_18    parent_nonstrict_scope_260  0.12
    x_8_18    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_18    product_lb_36  1
    w_8_18    product_ub_37  1
    w_8_18    normalized_mass_8_45  1
    w_8_18    normalized_ratio_8_46  -1.8
    w_8_18    full_original_Gini_318  -2.4066666666666674e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_19    OBJ       5.2500000000000005e-02
    x_8_19    product_lb_38  -2.4773645559889104e-02
    x_8_19    product_ub_39  -4.0760869565258165e-02
    x_8_19    onehot_8_44  1
    x_8_19    stock_lb_258  19
    x_8_19    stock_ub_259  19
    x_8_19    parent_nonstrict_scope_260  0.135
    x_8_19    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_19    product_lb_38  1
    w_8_19    product_ub_39  1
    w_8_19    normalized_mass_8_45  1
    w_8_19    normalized_ratio_8_46  -1.9000000000000001e+00
    w_8_19    full_original_Gini_318  -2.6766666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_20    OBJ       6.7499999999999991e-02
    x_8_20    product_lb_40  -2.4773645559889104e-02
    x_8_20    product_ub_41  -4.0760869565258165e-02
    x_8_20    onehot_8_44  1
    x_8_20    stock_lb_258  20
    x_8_20    stock_ub_259  20
    x_8_20    parent_nonstrict_scope_260  0.15
    x_8_20    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_20    product_lb_40  1
    w_8_20    product_ub_41  1
    w_8_20    normalized_mass_8_45  1
    w_8_20    normalized_ratio_8_46  -2
    w_8_20    full_original_Gini_318  -2.9466666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_8_21    OBJ       0.0825
    x_8_21    product_lb_42  -2.4773645559889104e-02
    x_8_21    product_ub_43  -4.0760869565258165e-02
    x_8_21    onehot_8_44  1
    x_8_21    stock_lb_258  21
    x_8_21    stock_ub_259  21
    x_8_21    parent_nonstrict_scope_260  0.165
    x_8_21    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_8_21    product_lb_42  1
    w_8_21    product_ub_43  1
    w_8_21    normalized_mass_8_45  1
    w_8_21    normalized_ratio_8_46  -2.1
    w_8_21    full_original_Gini_318  -3.2166666666666671e+01
    rho_8     normalized_ratio_8_46  1
    rho_8     block_pair_pos_285  -1
    rho_8     block_pair_neg_286  1
    rho_8     block_pair_pos_287  -1
    rho_8     block_pair_neg_288  1
    rho_8     block_pair_pos_289  -1
    rho_8     block_pair_neg_290  1
    rho_8     block_pair_pos_291  -1
    rho_8     block_pair_neg_292  1
    rho_8     block_pair_pos_293  -1
    rho_8     block_pair_neg_294  1
    rho_8     block_pair_pos_295  -1
    rho_8     block_pair_neg_296  1
    rho_8     block_pair_pos_297  -1
    rho_8     block_pair_neg_298  1
    rho_8     normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_47  -2.4773645559889104e-02
    x_2_0     product_ub_48  -4.0760869565258165e-02
    x_2_0     onehot_2_79  1
    x_2_0     parent_nonstrict_scope_260  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_47  1
    w_2_0     product_ub_48  1
    w_2_0     normalized_mass_2_80  1
    w_2_0     full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_49  -2.4773645559889104e-02
    x_2_1     product_ub_50  -4.0760869565258165e-02
    x_2_1     onehot_2_79  1
    x_2_1     stock_lb_258  1
    x_2_1     stock_ub_259  1
    x_2_1     parent_nonstrict_scope_260  0.063
    x_2_1     unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_49  1
    w_2_1     product_ub_50  1
    w_2_1     normalized_mass_2_80  1
    w_2_1     normalized_ratio_2_81  -1.4285714285714285e-01
    w_2_1     full_original_Gini_318  -2.0676190476190481e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_51  -2.4773645559889104e-02
    x_2_2     product_ub_52  -4.0760869565258165e-02
    x_2_2     onehot_2_79  1
    x_2_2     stock_lb_258  2
    x_2_2     stock_ub_259  2
    x_2_2     parent_nonstrict_scope_260  0.0525
    x_2_2     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_51  1
    w_2_2     product_ub_52  1
    w_2_2     normalized_mass_2_80  1
    w_2_2     normalized_ratio_2_81  -2.8571428571428570e-01
    w_2_2     full_original_Gini_318  -1.6819047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_53  -2.4773645559889104e-02
    x_2_3     product_ub_54  -4.0760869565258165e-02
    x_2_3     onehot_2_79  1
    x_2_3     stock_lb_258  3
    x_2_3     stock_ub_259  3
    x_2_3     parent_nonstrict_scope_260  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_53  1
    w_2_3     product_ub_54  1
    w_2_3     normalized_mass_2_80  1
    w_2_3     normalized_ratio_2_81  -4.2857142857142855e-01
    w_2_3     full_original_Gini_318  -1.3019047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_55  -2.4773645559889104e-02
    x_2_4     product_ub_56  -4.0760869565258165e-02
    x_2_4     onehot_2_79  1
    x_2_4     stock_lb_258  4
    x_2_4     stock_ub_259  4
    x_2_4     parent_nonstrict_scope_260  0.0315
    x_2_4     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_55  1
    w_2_4     product_ub_56  1
    w_2_4     normalized_mass_2_80  1
    w_2_4     normalized_ratio_2_81  -5.7142857142857140e-01
    w_2_4     full_original_Gini_318  -9.5904761904761919e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_57  -2.4773645559889104e-02
    x_2_5     product_ub_58  -4.0760869565258165e-02
    x_2_5     onehot_2_79  1
    x_2_5     stock_lb_258  5
    x_2_5     stock_ub_259  5
    x_2_5     parent_nonstrict_scope_260  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_57  1
    w_2_5     product_ub_58  1
    w_2_5     normalized_mass_2_80  1
    w_2_5     normalized_ratio_2_81  -7.1428571428571419e-01
    w_2_5     full_original_Gini_318  -6.5333333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_59  -2.4773645559889104e-02
    x_2_6     product_ub_60  -4.0760869565258165e-02
    x_2_6     onehot_2_79  1
    x_2_6     stock_lb_258  6
    x_2_6     stock_ub_259  6
    x_2_6     parent_nonstrict_scope_260  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_59  1
    w_2_6     product_ub_60  1
    w_2_6     normalized_mass_2_80  1
    w_2_6     normalized_ratio_2_81  -8.5714285714285710e-01
    w_2_6     full_original_Gini_318  -4.7666666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_61  -2.4773645559889104e-02
    x_2_7     product_ub_62  -4.0760869565258165e-02
    x_2_7     onehot_2_79  1
    x_2_7     stock_lb_258  7
    x_2_7     stock_ub_259  7
    x_2_7     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_61  1
    w_2_7     product_ub_62  1
    w_2_7     normalized_mass_2_80  1
    w_2_7     normalized_ratio_2_81  -1
    w_2_7     full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_63  -2.4773645559889104e-02
    x_2_8     product_ub_64  -4.0760869565258165e-02
    x_2_8     onehot_2_79  1
    x_2_8     stock_lb_258  8
    x_2_8     stock_ub_259  8
    x_2_8     parent_nonstrict_scope_260  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_63  1
    w_2_8     product_ub_64  1
    w_2_8     normalized_mass_2_80  1
    w_2_8     normalized_ratio_2_81  -1.1428571428571428e+00
    w_2_8     full_original_Gini_318  -6.7666666666666657e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_65  -2.4773645559889104e-02
    x_2_9     product_ub_66  -4.0760869565258165e-02
    x_2_9     onehot_2_79  1
    x_2_9     stock_lb_258  9
    x_2_9     stock_ub_259  9
    x_2_9     parent_nonstrict_scope_260  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_65  1
    w_2_9     product_ub_66  1
    w_2_9     normalized_mass_2_80  1
    w_2_9     normalized_ratio_2_81  -1.2857142857142856e+00
    w_2_9     full_original_Gini_318  -1.0180952380952377e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_67  -2.4773645559889104e-02
    x_2_10    product_ub_68  -4.0760869565258165e-02
    x_2_10    onehot_2_79  1
    x_2_10    stock_lb_258  10
    x_2_10    stock_ub_259  10
    x_2_10    parent_nonstrict_scope_260  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_67  1
    w_2_10    product_ub_68  1
    w_2_10    normalized_mass_2_80  1
    w_2_10    normalized_ratio_2_81  -1.4285714285714284e+00
    w_2_10    full_original_Gini_318  -1.4038095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_69  -2.4773645559889104e-02
    x_2_11    product_ub_70  -4.0760869565258165e-02
    x_2_11    onehot_2_79  1
    x_2_11    stock_lb_258  11
    x_2_11    stock_ub_259  11
    x_2_11    parent_nonstrict_scope_260  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_69  1
    w_2_11    product_ub_70  1
    w_2_11    normalized_mass_2_80  1
    w_2_11    normalized_ratio_2_81  -1.5714285714285714e+00
    w_2_11    full_original_Gini_318  -1.7895238095238096e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_71  -2.4773645559889104e-02
    x_2_12    product_ub_72  -4.0760869565258165e-02
    x_2_12    onehot_2_79  1
    x_2_12    stock_lb_258  12
    x_2_12    stock_ub_259  12
    x_2_12    parent_nonstrict_scope_260  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_71  1
    w_2_12    product_ub_72  1
    w_2_12    normalized_mass_2_80  1
    w_2_12    normalized_ratio_2_81  -1.7142857142857142e+00
    w_2_12    full_original_Gini_318  -2.1752380952380950e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_73  -2.4773645559889104e-02
    x_2_13    product_ub_74  -4.0760869565258165e-02
    x_2_13    onehot_2_79  1
    x_2_13    stock_lb_258  13
    x_2_13    stock_ub_259  13
    x_2_13    parent_nonstrict_scope_260  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_73  1
    w_2_13    product_ub_74  1
    w_2_13    normalized_mass_2_80  1
    w_2_13    normalized_ratio_2_81  -1.8571428571428570e+00
    w_2_13    full_original_Gini_318  -2.5609523809523811e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_75  -2.4773645559889104e-02
    x_2_14    product_ub_76  -4.0760869565258165e-02
    x_2_14    onehot_2_79  1
    x_2_14    stock_lb_258  14
    x_2_14    stock_ub_259  14
    x_2_14    parent_nonstrict_scope_260  0.0735
    x_2_14    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_75  1
    w_2_14    product_ub_76  1
    w_2_14    normalized_mass_2_80  1
    w_2_14    normalized_ratio_2_81  -2
    w_2_14    full_original_Gini_318  -2.9466666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_77  -2.4773645559889104e-02
    x_2_15    product_ub_78  -4.0760869565258165e-02
    x_2_15    onehot_2_79  1
    x_2_15    stock_lb_258  15
    x_2_15    stock_ub_259  15
    x_2_15    parent_nonstrict_scope_260  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_77  1
    w_2_15    product_ub_78  1
    w_2_15    normalized_mass_2_80  1
    w_2_15    normalized_ratio_2_81  -2.1428571428571428e+00
    w_2_15    full_original_Gini_318  -3.3323809523809523e+01
    rho_2     normalized_ratio_2_81  1
    rho_2     block_pair_pos_261  -1
    rho_2     block_pair_neg_262  1
    rho_2     block_pair_pos_263  -1
    rho_2     block_pair_neg_264  1
    rho_2     block_pair_pos_265  -1
    rho_2     block_pair_neg_266  1
    rho_2     block_pair_pos_267  -1
    rho_2     block_pair_neg_268  1
    rho_2     block_pair_pos_269  -1
    rho_2     block_pair_neg_270  1
    rho_2     block_pair_pos_271  -1
    rho_2     block_pair_neg_272  1
    rho_2     block_pair_pos_285  1
    rho_2     block_pair_neg_286  -1
    rho_2     normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_82  -2.4773645559889104e-02
    x_31_0    product_ub_83  -4.0760869565258165e-02
    x_31_0    onehot_31_108  1
    x_31_0    parent_nonstrict_scope_260  0.0735
    x_31_0    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_82  1
    w_31_0    product_ub_83  1
    w_31_0    normalized_mass_31_109  1
    w_31_0    full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_84  -2.4773645559889104e-02
    x_31_1    product_ub_85  -4.0760869565258165e-02
    x_31_1    onehot_31_108  1
    x_31_1    stock_lb_258  1
    x_31_1    stock_ub_259  1
    x_31_1    parent_nonstrict_scope_260  0.063
    x_31_1    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_84  1
    w_31_1    product_ub_85  1
    w_31_1    normalized_mass_31_109  1
    w_31_1    normalized_ratio_31_110  -1.4285714285714285e-01
    w_31_1    full_original_Gini_318  -2.0676190476190481e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_86  -2.4773645559889104e-02
    x_31_2    product_ub_87  -4.0760869565258165e-02
    x_31_2    onehot_31_108  1
    x_31_2    stock_lb_258  2
    x_31_2    stock_ub_259  2
    x_31_2    parent_nonstrict_scope_260  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_86  1
    w_31_2    product_ub_87  1
    w_31_2    normalized_mass_31_109  1
    w_31_2    normalized_ratio_31_110  -2.8571428571428570e-01
    w_31_2    full_original_Gini_318  -1.6819047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_88  -2.4773645559889104e-02
    x_31_3    product_ub_89  -4.0760869565258165e-02
    x_31_3    onehot_31_108  1
    x_31_3    stock_lb_258  3
    x_31_3    stock_ub_259  3
    x_31_3    parent_nonstrict_scope_260  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_88  1
    w_31_3    product_ub_89  1
    w_31_3    normalized_mass_31_109  1
    w_31_3    normalized_ratio_31_110  -4.2857142857142855e-01
    w_31_3    full_original_Gini_318  -1.3019047619047617e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_90  -2.4773645559889104e-02
    x_31_4    product_ub_91  -4.0760869565258165e-02
    x_31_4    onehot_31_108  1
    x_31_4    stock_lb_258  4
    x_31_4    stock_ub_259  4
    x_31_4    parent_nonstrict_scope_260  0.0315
    x_31_4    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_90  1
    w_31_4    product_ub_91  1
    w_31_4    normalized_mass_31_109  1
    w_31_4    normalized_ratio_31_110  -5.7142857142857140e-01
    w_31_4    full_original_Gini_318  -9.5904761904761919e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_92  -2.4773645559889104e-02
    x_31_5    product_ub_93  -4.0760869565258165e-02
    x_31_5    onehot_31_108  1
    x_31_5    stock_lb_258  5
    x_31_5    stock_ub_259  5
    x_31_5    parent_nonstrict_scope_260  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_92  1
    w_31_5    product_ub_93  1
    w_31_5    normalized_mass_31_109  1
    w_31_5    normalized_ratio_31_110  -7.1428571428571419e-01
    w_31_5    full_original_Gini_318  -6.5333333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_94  -2.4773645559889104e-02
    x_31_6    product_ub_95  -4.0760869565258165e-02
    x_31_6    onehot_31_108  1
    x_31_6    stock_lb_258  6
    x_31_6    stock_ub_259  6
    x_31_6    parent_nonstrict_scope_260  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_94  1
    w_31_6    product_ub_95  1
    w_31_6    normalized_mass_31_109  1
    w_31_6    normalized_ratio_31_110  -8.5714285714285710e-01
    w_31_6    full_original_Gini_318  -4.7666666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_96  -2.4773645559889104e-02
    x_31_7    product_ub_97  -4.0760869565258165e-02
    x_31_7    onehot_31_108  1
    x_31_7    stock_lb_258  7
    x_31_7    stock_ub_259  7
    x_31_7    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_96  1
    w_31_7    product_ub_97  1
    w_31_7    normalized_mass_31_109  1
    w_31_7    normalized_ratio_31_110  -1
    w_31_7    full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_98  -2.4773645559889104e-02
    x_31_8    product_ub_99  -4.0760869565258165e-02
    x_31_8    onehot_31_108  1
    x_31_8    stock_lb_258  8
    x_31_8    stock_ub_259  8
    x_31_8    parent_nonstrict_scope_260  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_98  1
    w_31_8    product_ub_99  1
    w_31_8    normalized_mass_31_109  1
    w_31_8    normalized_ratio_31_110  -1.1428571428571428e+00
    w_31_8    full_original_Gini_318  -6.7666666666666657e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_100  -2.4773645559889104e-02
    x_31_9    product_ub_101  -4.0760869565258165e-02
    x_31_9    onehot_31_108  1
    x_31_9    stock_lb_258  9
    x_31_9    stock_ub_259  9
    x_31_9    parent_nonstrict_scope_260  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_100  1
    w_31_9    product_ub_101  1
    w_31_9    normalized_mass_31_109  1
    w_31_9    normalized_ratio_31_110  -1.2857142857142856e+00
    w_31_9    full_original_Gini_318  -1.0180952380952377e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_102  -2.4773645559889104e-02
    x_31_10   product_ub_103  -4.0760869565258165e-02
    x_31_10   onehot_31_108  1
    x_31_10   stock_lb_258  10
    x_31_10   stock_ub_259  10
    x_31_10   parent_nonstrict_scope_260  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_102  1
    w_31_10   product_ub_103  1
    w_31_10   normalized_mass_31_109  1
    w_31_10   normalized_ratio_31_110  -1.4285714285714284e+00
    w_31_10   full_original_Gini_318  -1.4038095238095236e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_104  -2.4773645559889104e-02
    x_31_11   product_ub_105  -4.0760869565258165e-02
    x_31_11   onehot_31_108  1
    x_31_11   stock_lb_258  11
    x_31_11   stock_ub_259  11
    x_31_11   parent_nonstrict_scope_260  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_104  1
    w_31_11   product_ub_105  1
    w_31_11   normalized_mass_31_109  1
    w_31_11   normalized_ratio_31_110  -1.5714285714285714e+00
    w_31_11   full_original_Gini_318  -1.7895238095238096e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_106  -2.4773645559889104e-02
    x_31_12   product_ub_107  -4.0760869565258165e-02
    x_31_12   onehot_31_108  1
    x_31_12   stock_lb_258  12
    x_31_12   stock_ub_259  12
    x_31_12   parent_nonstrict_scope_260  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_106  1
    w_31_12   product_ub_107  1
    w_31_12   normalized_mass_31_109  1
    w_31_12   normalized_ratio_31_110  -1.7142857142857142e+00
    w_31_12   full_original_Gini_318  -2.1752380952380950e+01
    rho_31    normalized_ratio_31_110  1
    rho_31    block_pair_pos_271  1
    rho_31    block_pair_neg_272  -1
    rho_31    block_pair_pos_297  1
    rho_31    block_pair_neg_298  -1
    rho_31    block_pair_pos_307  -1
    rho_31    block_pair_neg_308  1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_111  -2.4773645559889104e-02
    x_6_0     product_ub_112  -4.0760869565258165e-02
    x_6_0     onehot_6_133  1
    x_6_0     parent_nonstrict_scope_260  0.0375
    x_6_0     unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_111  1
    w_6_0     product_ub_112  1
    w_6_0     normalized_mass_6_134  1
    w_6_0     full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_113  -2.4773645559889104e-02
    x_6_1     product_ub_114  -4.0760869565258165e-02
    x_6_1     onehot_6_133  1
    x_6_1     stock_lb_258  1
    x_6_1     stock_ub_259  1
    x_6_1     parent_nonstrict_scope_260  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_113  1
    w_6_1     product_ub_114  1
    w_6_1     normalized_mass_6_134  1
    w_6_1     normalized_ratio_6_135  -0.2
    w_6_1     full_original_Gini_318  -1.9133333333333336e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_115  -2.4773645559889104e-02
    x_6_2     product_ub_116  -4.0760869565258165e-02
    x_6_2     onehot_6_133  1
    x_6_2     stock_lb_258  2
    x_6_2     stock_ub_259  2
    x_6_2     parent_nonstrict_scope_260  0.0225
    x_6_2     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_115  1
    w_6_2     product_ub_116  1
    w_6_2     normalized_mass_6_134  1
    w_6_2     normalized_ratio_6_135  -0.4
    w_6_2     full_original_Gini_318  -1.3733333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_117  -2.4773645559889104e-02
    x_6_3     product_ub_118  -4.0760869565258165e-02
    x_6_3     onehot_6_133  1
    x_6_3     stock_lb_258  3
    x_6_3     stock_ub_259  3
    x_6_3     parent_nonstrict_scope_260  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_117  1
    w_6_3     product_ub_118  1
    w_6_3     normalized_mass_6_134  1
    w_6_3     normalized_ratio_6_135  -6.0000000000000009e-01
    w_6_3     full_original_Gini_318  -8.9333333333333336e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_119  -2.4773645559889104e-02
    x_6_4     product_ub_120  -4.0760869565258165e-02
    x_6_4     onehot_6_133  1
    x_6_4     stock_lb_258  4
    x_6_4     stock_ub_259  4
    x_6_4     parent_nonstrict_scope_260  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_119  1
    w_6_4     product_ub_120  1
    w_6_4     normalized_mass_6_134  1
    w_6_4     normalized_ratio_6_135  -0.8
    w_6_4     full_original_Gini_318  -5.3476190476190482e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_121  -2.4773645559889104e-02
    x_6_5     product_ub_122  -4.0760869565258165e-02
    x_6_5     onehot_6_133  1
    x_6_5     stock_lb_258  5
    x_6_5     stock_ub_259  5
    x_6_5     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_121  1
    w_6_5     product_ub_122  1
    w_6_5     normalized_mass_6_134  1
    w_6_5     normalized_ratio_6_135  -1
    w_6_5     full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_123  -2.4773645559889104e-02
    x_6_6     product_ub_124  -4.0760869565258165e-02
    x_6_6     onehot_6_133  1
    x_6_6     stock_lb_258  6
    x_6_6     stock_ub_259  6
    x_6_6     parent_nonstrict_scope_260  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_123  1
    w_6_6     product_ub_124  1
    w_6_6     normalized_mass_6_134  1
    w_6_6     normalized_ratio_6_135  -1.2000000000000002e+00
    w_6_6     full_original_Gini_318  -7.9666666666666694e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_125  -2.4773645559889104e-02
    x_6_7     product_ub_126  -4.0760869565258165e-02
    x_6_7     onehot_6_133  1
    x_6_7     stock_lb_258  7
    x_6_7     stock_ub_259  7
    x_6_7     parent_nonstrict_scope_260  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_125  1
    w_6_7     product_ub_126  1
    w_6_7     normalized_mass_6_134  1
    w_6_7     normalized_ratio_6_135  -1.4000000000000001e+00
    w_6_7     full_original_Gini_318  -1.3266666666666675e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_127  -2.4773645559889104e-02
    x_6_8     product_ub_128  -4.0760869565258165e-02
    x_6_8     onehot_6_133  1
    x_6_8     stock_lb_258  8
    x_6_8     stock_ub_259  8
    x_6_8     parent_nonstrict_scope_260  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_127  1
    w_6_8     product_ub_128  1
    w_6_8     normalized_mass_6_134  1
    w_6_8     normalized_ratio_6_135  -1.6
    w_6_8     full_original_Gini_318  -1.8666666666666668e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_129  -2.4773645559889104e-02
    x_6_9     product_ub_130  -4.0760869565258165e-02
    x_6_9     onehot_6_133  1
    x_6_9     stock_lb_258  9
    x_6_9     stock_ub_259  9
    x_6_9     parent_nonstrict_scope_260  0.03
    x_6_9     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_129  1
    w_6_9     product_ub_130  1
    w_6_9     normalized_mass_6_134  1
    w_6_9     normalized_ratio_6_135  -1.8
    w_6_9     full_original_Gini_318  -2.4066666666666674e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_131  -2.4773645559889104e-02
    x_6_10    product_ub_132  -4.0760869565258165e-02
    x_6_10    onehot_6_133  1
    x_6_10    stock_lb_258  10
    x_6_10    stock_ub_259  10
    x_6_10    parent_nonstrict_scope_260  0.0375
    x_6_10    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_131  1
    w_6_10    product_ub_132  1
    w_6_10    normalized_mass_6_134  1
    w_6_10    normalized_ratio_6_135  -2
    w_6_10    full_original_Gini_318  -2.9466666666666669e+01
    rho_6     normalized_ratio_6_135  1
    rho_6     block_pair_pos_263  1
    rho_6     block_pair_neg_264  -1
    rho_6     block_pair_pos_277  -1
    rho_6     block_pair_neg_278  1
    rho_6     block_pair_pos_279  -1
    rho_6     block_pair_neg_280  1
    rho_6     block_pair_pos_281  -1
    rho_6     block_pair_neg_282  1
    rho_6     block_pair_pos_283  -1
    rho_6     block_pair_neg_284  1
    rho_6     block_pair_pos_289  1
    rho_6     block_pair_neg_290  -1
    rho_6     block_pair_pos_309  1
    rho_6     block_pair_neg_310  -1
    rho_6     normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_136  -2.4773645559889104e-02
    x_16_0    product_ub_137  -4.0760869565258165e-02
    x_16_0    onehot_16_162  1
    x_16_0    parent_nonstrict_scope_260  0.054
    x_16_0    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_136  1
    w_16_0    product_ub_137  1
    w_16_0    normalized_mass_16_163  1
    w_16_0    full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_138  -2.4773645559889104e-02
    x_16_1    product_ub_139  -4.0760869565258165e-02
    x_16_1    onehot_16_162  1
    x_16_1    stock_lb_258  1
    x_16_1    stock_ub_259  1
    x_16_1    parent_nonstrict_scope_260  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_138  1
    w_16_1    product_ub_139  1
    w_16_1    normalized_mass_16_163  1
    w_16_1    normalized_ratio_16_164  -1.6666666666666666e-01
    w_16_1    full_original_Gini_318  -2.0033333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_140  -2.4773645559889104e-02
    x_16_2    product_ub_141  -4.0760869565258165e-02
    x_16_2    onehot_16_162  1
    x_16_2    stock_lb_258  2
    x_16_2    stock_ub_259  2
    x_16_2    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_140  1
    w_16_2    product_ub_141  1
    w_16_2    normalized_mass_16_163  1
    w_16_2    normalized_ratio_16_164  -3.3333333333333331e-01
    w_16_2    full_original_Gini_318  -1.5533333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_142  -2.4773645559889104e-02
    x_16_3    product_ub_143  -4.0760869565258165e-02
    x_16_3    onehot_16_162  1
    x_16_3    stock_lb_258  3
    x_16_3    stock_ub_259  3
    x_16_3    parent_nonstrict_scope_260  0.027
    x_16_3    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_142  1
    w_16_3    product_ub_143  1
    w_16_3    normalized_mass_16_163  1
    w_16_3    normalized_ratio_16_164  -0.5
    w_16_3    full_original_Gini_318  -1.1233333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_144  -2.4773645559889104e-02
    x_16_4    product_ub_145  -4.0760869565258165e-02
    x_16_4    onehot_16_162  1
    x_16_4    stock_lb_258  4
    x_16_4    stock_ub_259  4
    x_16_4    parent_nonstrict_scope_260  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_144  1
    w_16_4    product_ub_145  1
    w_16_4    normalized_mass_16_163  1
    w_16_4    normalized_ratio_16_164  -6.6666666666666663e-01
    w_16_4    full_original_Gini_318  -7.5333333333333314e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_146  -2.4773645559889104e-02
    x_16_5    product_ub_147  -4.0760869565258165e-02
    x_16_5    onehot_16_162  1
    x_16_5    stock_lb_258  5
    x_16_5    stock_ub_259  5
    x_16_5    parent_nonstrict_scope_260  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_146  1
    w_16_5    product_ub_147  1
    w_16_5    normalized_mass_16_163  1
    w_16_5    normalized_ratio_16_164  -8.3333333333333326e-01
    w_16_5    full_original_Gini_318  -4.9809523809523846e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_148  -2.4773645559889104e-02
    x_16_6    product_ub_149  -4.0760869565258165e-02
    x_16_6    onehot_16_162  1
    x_16_6    stock_lb_258  6
    x_16_6    stock_ub_259  6
    x_16_6    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_148  1
    w_16_6    product_ub_149  1
    w_16_6    normalized_mass_16_163  1
    w_16_6    normalized_ratio_16_164  -1
    w_16_6    full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_150  -2.4773645559889104e-02
    x_16_7    product_ub_151  -4.0760869565258165e-02
    x_16_7    onehot_16_162  1
    x_16_7    stock_lb_258  7
    x_16_7    stock_ub_259  7
    x_16_7    parent_nonstrict_scope_260  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_150  1
    w_16_7    product_ub_151  1
    w_16_7    normalized_mass_16_163  1
    w_16_7    normalized_ratio_16_164  -1.1666666666666665e+00
    w_16_7    full_original_Gini_318  -7.2666666666666639e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_152  -2.4773645559889104e-02
    x_16_8    product_ub_153  -4.0760869565258165e-02
    x_16_8    onehot_16_162  1
    x_16_8    stock_lb_258  8
    x_16_8    stock_ub_259  8
    x_16_8    parent_nonstrict_scope_260  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_152  1
    w_16_8    product_ub_153  1
    w_16_8    normalized_mass_16_163  1
    w_16_8    normalized_ratio_16_164  -1.3333333333333333e+00
    w_16_8    full_original_Gini_318  -1.1466666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_154  -2.4773645559889104e-02
    x_16_9    product_ub_155  -4.0760869565258165e-02
    x_16_9    onehot_16_162  1
    x_16_9    stock_lb_258  9
    x_16_9    stock_ub_259  9
    x_16_9    parent_nonstrict_scope_260  0.027
    x_16_9    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_154  1
    w_16_9    product_ub_155  1
    w_16_9    normalized_mass_16_163  1
    w_16_9    normalized_ratio_16_164  -1.5
    w_16_9    full_original_Gini_318  -1.5966666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_156  -2.4773645559889104e-02
    x_16_10   product_ub_157  -4.0760869565258165e-02
    x_16_10   onehot_16_162  1
    x_16_10   stock_lb_258  10
    x_16_10   stock_ub_259  10
    x_16_10   parent_nonstrict_scope_260  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_156  1
    w_16_10   product_ub_157  1
    w_16_10   normalized_mass_16_163  1
    w_16_10   normalized_ratio_16_164  -1.6666666666666665e+00
    w_16_10   full_original_Gini_318  -2.0466666666666661e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_158  -2.4773645559889104e-02
    x_16_11   product_ub_159  -4.0760869565258165e-02
    x_16_11   onehot_16_162  1
    x_16_11   stock_lb_258  11
    x_16_11   stock_ub_259  11
    x_16_11   parent_nonstrict_scope_260  0.045
    x_16_11   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_158  1
    w_16_11   product_ub_159  1
    w_16_11   normalized_mass_16_163  1
    w_16_11   normalized_ratio_16_164  -1.8333333333333333e+00
    w_16_11   full_original_Gini_318  -2.4966666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_160  -2.4773645559889104e-02
    x_16_12   product_ub_161  -4.0760869565258165e-02
    x_16_12   onehot_16_162  1
    x_16_12   stock_lb_258  12
    x_16_12   stock_ub_259  12
    x_16_12   parent_nonstrict_scope_260  0.054
    x_16_12   unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_160  1
    w_16_12   product_ub_161  1
    w_16_12   normalized_mass_16_163  1
    w_16_12   normalized_ratio_16_164  -2
    w_16_12   full_original_Gini_318  -2.9466666666666669e+01
    rho_16    normalized_ratio_16_164  1
    rho_16    block_pair_pos_267  1
    rho_16    block_pair_neg_268  -1
    rho_16    block_pair_pos_281  1
    rho_16    block_pair_neg_282  -1
    rho_16    block_pair_pos_293  1
    rho_16    block_pair_neg_294  -1
    rho_16    block_pair_pos_299  -1
    rho_16    block_pair_neg_300  1
    rho_16    block_pair_pos_301  -1
    rho_16    block_pair_neg_302  1
    rho_16    block_pair_pos_303  -1
    rho_16    block_pair_neg_304  1
    rho_16    block_pair_pos_313  1
    rho_16    block_pair_neg_314  -1
    rho_16    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_165  -2.4773645559889104e-02
    x_5_0     product_ub_166  -4.0760869565258165e-02
    x_5_0     onehot_5_199  1
    x_5_0     parent_nonstrict_scope_260  0.096
    x_5_0     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_165  1
    w_5_0     product_ub_166  1
    w_5_0     normalized_mass_5_200  1
    w_5_0     full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_167  -2.4773645559889104e-02
    x_5_1     product_ub_168  -4.0760869565258165e-02
    x_5_1     onehot_5_199  1
    x_5_1     stock_lb_258  1
    x_5_1     stock_ub_259  1
    x_5_1     parent_nonstrict_scope_260  0.084
    x_5_1     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_167  1
    w_5_1     product_ub_168  1
    w_5_1     normalized_mass_5_200  1
    w_5_1     normalized_ratio_5_201  -0.125
    w_5_1     full_original_Gini_318  -2.1158333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_169  -2.4773645559889104e-02
    x_5_2     product_ub_170  -4.0760869565258165e-02
    x_5_2     onehot_5_199  1
    x_5_2     stock_lb_258  2
    x_5_2     stock_ub_259  2
    x_5_2     parent_nonstrict_scope_260  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_169  1
    w_5_2     product_ub_170  1
    w_5_2     normalized_mass_5_200  1
    w_5_2     normalized_ratio_5_201  -0.25
    w_5_2     full_original_Gini_318  -1.7783333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_171  -2.4773645559889104e-02
    x_5_3     product_ub_172  -4.0760869565258165e-02
    x_5_3     onehot_5_199  1
    x_5_3     stock_lb_258  3
    x_5_3     stock_ub_259  3
    x_5_3     parent_nonstrict_scope_260  0.06
    x_5_3     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_171  1
    w_5_3     product_ub_172  1
    w_5_3     normalized_mass_5_200  1
    w_5_3     normalized_ratio_5_201  -0.375
    w_5_3     full_original_Gini_318  -1.4408333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_173  -2.4773645559889104e-02
    x_5_4     product_ub_174  -4.0760869565258165e-02
    x_5_4     onehot_5_199  1
    x_5_4     stock_lb_258  4
    x_5_4     stock_ub_259  4
    x_5_4     parent_nonstrict_scope_260  0.048
    x_5_4     unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_173  1
    w_5_4     product_ub_174  1
    w_5_4     normalized_mass_5_200  1
    w_5_4     normalized_ratio_5_201  -0.5
    w_5_4     full_original_Gini_318  -1.1233333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_175  -2.4773645559889104e-02
    x_5_5     product_ub_176  -4.0760869565258165e-02
    x_5_5     onehot_5_199  1
    x_5_5     stock_lb_258  5
    x_5_5     stock_ub_259  5
    x_5_5     parent_nonstrict_scope_260  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_175  1
    w_5_5     product_ub_176  1
    w_5_5     normalized_mass_5_200  1
    w_5_5     normalized_ratio_5_201  -0.625
    w_5_5     full_original_Gini_318  -8.4083333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_177  -2.4773645559889104e-02
    x_5_6     product_ub_178  -4.0760869565258165e-02
    x_5_6     onehot_5_199  1
    x_5_6     stock_lb_258  6
    x_5_6     stock_ub_259  6
    x_5_6     parent_nonstrict_scope_260  0.024
    x_5_6     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_177  1
    w_5_6     product_ub_178  1
    w_5_6     normalized_mass_5_200  1
    w_5_6     normalized_ratio_5_201  -0.75
    w_5_6     full_original_Gini_318  -5.9976190476190467e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_179  -2.4773645559889104e-02
    x_5_7     product_ub_180  -4.0760869565258165e-02
    x_5_7     onehot_5_199  1
    x_5_7     stock_lb_258  7
    x_5_7     stock_ub_259  7
    x_5_7     parent_nonstrict_scope_260  0.012
    x_5_7     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_179  1
    w_5_7     product_ub_180  1
    w_5_7     normalized_mass_5_200  1
    w_5_7     normalized_ratio_5_201  -0.875
    w_5_7     full_original_Gini_318  -4.6416666666666657e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_181  -2.4773645559889104e-02
    x_5_8     product_ub_182  -4.0760869565258165e-02
    x_5_8     onehot_5_199  1
    x_5_8     stock_lb_258  8
    x_5_8     stock_ub_259  8
    x_5_8     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_181  1
    w_5_8     product_ub_182  1
    w_5_8     normalized_mass_5_200  1
    w_5_8     normalized_ratio_5_201  -1
    w_5_8     full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_183  -2.4773645559889104e-02
    x_5_9     product_ub_184  -4.0760869565258165e-02
    x_5_9     onehot_5_199  1
    x_5_9     stock_lb_258  9
    x_5_9     stock_ub_259  9
    x_5_9     parent_nonstrict_scope_260  0.012
    x_5_9     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_183  1
    w_5_9     product_ub_184  1
    w_5_9     normalized_mass_5_200  1
    w_5_9     normalized_ratio_5_201  -1.125
    w_5_9     full_original_Gini_318  -6.3916666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_185  -2.4773645559889104e-02
    x_5_10    product_ub_186  -4.0760869565258165e-02
    x_5_10    onehot_5_199  1
    x_5_10    stock_lb_258  10
    x_5_10    stock_ub_259  10
    x_5_10    parent_nonstrict_scope_260  0.024
    x_5_10    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_185  1
    w_5_10    product_ub_186  1
    w_5_10    normalized_mass_5_200  1
    w_5_10    normalized_ratio_5_201  -1.25
    w_5_10    full_original_Gini_318  -9.2166666666666668e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_187  -2.4773645559889104e-02
    x_5_11    product_ub_188  -4.0760869565258165e-02
    x_5_11    onehot_5_199  1
    x_5_11    stock_lb_258  11
    x_5_11    stock_ub_259  11
    x_5_11    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_187  1
    w_5_11    product_ub_188  1
    w_5_11    normalized_mass_5_200  1
    w_5_11    normalized_ratio_5_201  -1.375
    w_5_11    full_original_Gini_318  -1.2591666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_189  -2.4773645559889104e-02
    x_5_12    product_ub_190  -4.0760869565258165e-02
    x_5_12    onehot_5_199  1
    x_5_12    stock_lb_258  12
    x_5_12    stock_ub_259  12
    x_5_12    parent_nonstrict_scope_260  0.048
    x_5_12    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_189  1
    w_5_12    product_ub_190  1
    w_5_12    normalized_mass_5_200  1
    w_5_12    normalized_ratio_5_201  -1.5
    w_5_12    full_original_Gini_318  -1.5966666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_191  -2.4773645559889104e-02
    x_5_13    product_ub_192  -4.0760869565258165e-02
    x_5_13    onehot_5_199  1
    x_5_13    stock_lb_258  13
    x_5_13    stock_ub_259  13
    x_5_13    parent_nonstrict_scope_260  0.06
    x_5_13    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_191  1
    w_5_13    product_ub_192  1
    w_5_13    normalized_mass_5_200  1
    w_5_13    normalized_ratio_5_201  -1.625
    w_5_13    full_original_Gini_318  -1.9341666666666661e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_193  -2.4773645559889104e-02
    x_5_14    product_ub_194  -4.0760869565258165e-02
    x_5_14    onehot_5_199  1
    x_5_14    stock_lb_258  14
    x_5_14    stock_ub_259  14
    x_5_14    parent_nonstrict_scope_260  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_193  1
    w_5_14    product_ub_194  1
    w_5_14    normalized_mass_5_200  1
    w_5_14    normalized_ratio_5_201  -1.75
    w_5_14    full_original_Gini_318  -2.2716666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_195  -2.4773645559889104e-02
    x_5_15    product_ub_196  -4.0760869565258165e-02
    x_5_15    onehot_5_199  1
    x_5_15    stock_lb_258  15
    x_5_15    stock_ub_259  15
    x_5_15    parent_nonstrict_scope_260  0.084
    x_5_15    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_195  1
    w_5_15    product_ub_196  1
    w_5_15    normalized_mass_5_200  1
    w_5_15    normalized_ratio_5_201  -1.875
    w_5_15    full_original_Gini_318  -2.6091666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_197  -2.4773645559889104e-02
    x_5_16    product_ub_198  -4.0760869565258165e-02
    x_5_16    onehot_5_199  1
    x_5_16    stock_lb_258  16
    x_5_16    stock_ub_259  16
    x_5_16    parent_nonstrict_scope_260  0.096
    x_5_16    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_197  1
    w_5_16    product_ub_198  1
    w_5_16    normalized_mass_5_200  1
    w_5_16    normalized_ratio_5_201  -2
    w_5_16    full_original_Gini_318  -2.9466666666666669e+01
    rho_5     normalized_ratio_5_201  1
    rho_5     block_pair_pos_261  1
    rho_5     block_pair_neg_262  -1
    rho_5     block_pair_pos_273  -1
    rho_5     block_pair_neg_274  1
    rho_5     block_pair_pos_275  -1
    rho_5     block_pair_neg_276  1
    rho_5     block_pair_pos_277  1
    rho_5     block_pair_neg_278  -1
    rho_5     block_pair_pos_287  1
    rho_5     block_pair_neg_288  -1
    rho_5     block_pair_pos_299  1
    rho_5     block_pair_neg_300  -1
    rho_5     block_pair_pos_307  1
    rho_5     block_pair_neg_308  -1
    rho_5     normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       0.012
    x_26_0    product_lb_202  -2.4773645559889104e-02
    x_26_0    product_ub_203  -4.0760869565258165e-02
    x_26_0    onehot_26_220  1
    x_26_0    parent_nonstrict_scope_260  0.024
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_202  1
    w_26_0    product_ub_203  1
    w_26_0    normalized_mass_26_221  1
    w_26_0    full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       6.0000000000000019e-03
    x_26_1    product_lb_204  -2.4773645559889104e-02
    x_26_1    product_ub_205  -4.0760869565258165e-02
    x_26_1    onehot_26_220  1
    x_26_1    stock_lb_258  1
    x_26_1    stock_ub_259  1
    x_26_1    parent_nonstrict_scope_260  1.8000000000000002e-02
    x_26_1    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_204  1
    w_26_1    product_ub_205  1
    w_26_1    normalized_mass_26_221  1
    w_26_1    normalized_ratio_26_222  -0.25
    w_26_1    full_original_Gini_318  -1.7783333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_206  -2.4773645559889104e-02
    x_26_2    product_ub_207  -4.0760869565258165e-02
    x_26_2    onehot_26_220  1
    x_26_2    stock_lb_258  2
    x_26_2    stock_ub_259  2
    x_26_2    parent_nonstrict_scope_260  0.012
    x_26_2    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_206  1
    w_26_2    product_ub_207  1
    w_26_2    normalized_mass_26_221  1
    w_26_2    normalized_ratio_26_222  -0.5
    w_26_2    full_original_Gini_318  -1.1233333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -0.006
    x_26_3    product_lb_208  -2.4773645559889104e-02
    x_26_3    product_ub_209  -4.0760869565258165e-02
    x_26_3    onehot_26_220  1
    x_26_3    stock_lb_258  3
    x_26_3    stock_ub_259  3
    x_26_3    parent_nonstrict_scope_260  0.006
    x_26_3    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_208  1
    w_26_3    product_ub_209  1
    w_26_3    normalized_mass_26_221  1
    w_26_3    normalized_ratio_26_222  -0.75
    w_26_3    full_original_Gini_318  -5.9976190476190467e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -0.012
    x_26_4    product_lb_210  -2.4773645559889104e-02
    x_26_4    product_ub_211  -4.0760869565258165e-02
    x_26_4    onehot_26_220  1
    x_26_4    stock_lb_258  4
    x_26_4    stock_ub_259  4
    x_26_4    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_210  1
    w_26_4    product_ub_211  1
    w_26_4    normalized_mass_26_221  1
    w_26_4    normalized_ratio_26_222  -1
    w_26_4    full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -0.006
    x_26_5    product_lb_212  -2.4773645559889104e-02
    x_26_5    product_ub_213  -4.0760869565258165e-02
    x_26_5    onehot_26_220  1
    x_26_5    stock_lb_258  5
    x_26_5    stock_ub_259  5
    x_26_5    parent_nonstrict_scope_260  0.006
    x_26_5    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_212  1
    w_26_5    product_ub_213  1
    w_26_5    normalized_mass_26_221  1
    w_26_5    normalized_ratio_26_222  -1.25
    w_26_5    full_original_Gini_318  -9.2166666666666668e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_214  -2.4773645559889104e-02
    x_26_6    product_ub_215  -4.0760869565258165e-02
    x_26_6    onehot_26_220  1
    x_26_6    stock_lb_258  6
    x_26_6    stock_ub_259  6
    x_26_6    parent_nonstrict_scope_260  0.012
    x_26_6    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_214  1
    w_26_6    product_ub_215  1
    w_26_6    normalized_mass_26_221  1
    w_26_6    normalized_ratio_26_222  -1.5
    w_26_6    full_original_Gini_318  -1.5966666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       6.0000000000000019e-03
    x_26_7    product_lb_216  -2.4773645559889104e-02
    x_26_7    product_ub_217  -4.0760869565258165e-02
    x_26_7    onehot_26_220  1
    x_26_7    stock_lb_258  7
    x_26_7    stock_ub_259  7
    x_26_7    parent_nonstrict_scope_260  1.8000000000000002e-02
    x_26_7    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_216  1
    w_26_7    product_ub_217  1
    w_26_7    normalized_mass_26_221  1
    w_26_7    normalized_ratio_26_222  -1.75
    w_26_7    full_original_Gini_318  -2.2716666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       0.012
    x_26_8    product_lb_218  -2.4773645559889104e-02
    x_26_8    product_ub_219  -4.0760869565258165e-02
    x_26_8    onehot_26_220  1
    x_26_8    stock_lb_258  8
    x_26_8    stock_ub_259  8
    x_26_8    parent_nonstrict_scope_260  0.024
    x_26_8    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_218  1
    w_26_8    product_ub_219  1
    w_26_8    normalized_mass_26_221  1
    w_26_8    normalized_ratio_26_222  -2
    w_26_8    full_original_Gini_318  -2.9466666666666669e+01
    rho_26    normalized_ratio_26_222  1
    rho_26    block_pair_pos_269  1
    rho_26    block_pair_neg_270  -1
    rho_26    block_pair_pos_275  1
    rho_26    block_pair_neg_276  -1
    rho_26    block_pair_pos_283  1
    rho_26    block_pair_neg_284  -1
    rho_26    block_pair_pos_295  1
    rho_26    block_pair_neg_296  -1
    rho_26    block_pair_pos_303  1
    rho_26    block_pair_neg_304  -1
    rho_26    block_pair_pos_305  -1
    rho_26    block_pair_neg_306  1
    rho_26    block_pair_pos_315  1
    rho_26    block_pair_neg_316  -1
    rho_26    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       0.048
    x_14_0    product_lb_223  -2.4773645559889104e-02
    x_14_0    product_ub_224  -4.0760869565258165e-02
    x_14_0    onehot_14_255  1
    x_14_0    parent_nonstrict_scope_260  0.096
    x_14_0    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_223  1
    w_14_0    product_ub_224  1
    w_14_0    normalized_mass_14_256  1
    w_14_0    full_original_Gini_318  -2.4533333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.6000000000000004e-02
    x_14_1    product_lb_225  -2.4773645559889104e-02
    x_14_1    product_ub_226  -4.0760869565258165e-02
    x_14_1    onehot_14_255  1
    x_14_1    stock_lb_258  1
    x_14_1    stock_ub_259  1
    x_14_1    parent_nonstrict_scope_260  0.084
    x_14_1    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_225  1
    w_14_1    product_ub_226  1
    w_14_1    normalized_mass_14_256  1
    w_14_1    normalized_ratio_14_257  -0.125
    w_14_1    full_original_Gini_318  -2.1158333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       2.4000000000000007e-02
    x_14_2    product_lb_227  -2.4773645559889104e-02
    x_14_2    product_ub_228  -4.0760869565258165e-02
    x_14_2    onehot_14_255  1
    x_14_2    stock_lb_258  2
    x_14_2    stock_ub_259  2
    x_14_2    parent_nonstrict_scope_260  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_227  1
    w_14_2    product_ub_228  1
    w_14_2    normalized_mass_14_256  1
    w_14_2    normalized_ratio_14_257  -0.25
    w_14_2    full_original_Gini_318  -1.7783333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       1.1999999999999997e-02
    x_14_3    product_lb_229  -2.4773645559889104e-02
    x_14_3    product_ub_230  -4.0760869565258165e-02
    x_14_3    onehot_14_255  1
    x_14_3    stock_lb_258  3
    x_14_3    stock_ub_259  3
    x_14_3    parent_nonstrict_scope_260  0.06
    x_14_3    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_229  1
    w_14_3    product_ub_230  1
    w_14_3    normalized_mass_14_256  1
    w_14_3    normalized_ratio_14_257  -0.375
    w_14_3    full_original_Gini_318  -1.4408333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_4    product_lb_231  -2.4773645559889104e-02
    x_14_4    product_ub_232  -4.0760869565258165e-02
    x_14_4    onehot_14_255  1
    x_14_4    stock_lb_258  4
    x_14_4    stock_ub_259  4
    x_14_4    parent_nonstrict_scope_260  0.048
    x_14_4    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_231  1
    w_14_4    product_ub_232  1
    w_14_4    normalized_mass_14_256  1
    w_14_4    normalized_ratio_14_257  -0.5
    w_14_4    full_original_Gini_318  -1.1233333333333333e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -1.1999999999999997e-02
    x_14_5    product_lb_233  -2.4773645559889104e-02
    x_14_5    product_ub_234  -4.0760869565258165e-02
    x_14_5    onehot_14_255  1
    x_14_5    stock_lb_258  5
    x_14_5    stock_ub_259  5
    x_14_5    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_14_5    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_233  1
    w_14_5    product_ub_234  1
    w_14_5    normalized_mass_14_256  1
    w_14_5    normalized_ratio_14_257  -0.625
    w_14_5    full_original_Gini_318  -8.4083333333333332e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -0.024
    x_14_6    product_lb_235  -2.4773645559889104e-02
    x_14_6    product_ub_236  -4.0760869565258165e-02
    x_14_6    onehot_14_255  1
    x_14_6    stock_lb_258  6
    x_14_6    stock_ub_259  6
    x_14_6    parent_nonstrict_scope_260  0.024
    x_14_6    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_235  1
    w_14_6    product_ub_236  1
    w_14_6    normalized_mass_14_256  1
    w_14_6    normalized_ratio_14_257  -0.75
    w_14_6    full_original_Gini_318  -5.9976190476190467e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -3.6000000000000004e-02
    x_14_7    product_lb_237  -2.4773645559889104e-02
    x_14_7    product_ub_238  -4.0760869565258165e-02
    x_14_7    onehot_14_255  1
    x_14_7    stock_lb_258  7
    x_14_7    stock_ub_259  7
    x_14_7    parent_nonstrict_scope_260  0.012
    x_14_7    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_237  1
    w_14_7    product_ub_238  1
    w_14_7    normalized_mass_14_256  1
    w_14_7    normalized_ratio_14_257  -0.875
    w_14_7    full_original_Gini_318  -4.6416666666666657e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -0.048
    x_14_8    product_lb_239  -2.4773645559889104e-02
    x_14_8    product_ub_240  -4.0760869565258165e-02
    x_14_8    onehot_14_255  1
    x_14_8    stock_lb_258  8
    x_14_8    stock_ub_259  8
    x_14_8    unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_239  1
    w_14_8    product_ub_240  1
    w_14_8    normalized_mass_14_256  1
    w_14_8    normalized_ratio_14_257  -1
    w_14_8    full_original_Gini_318  -3.7666666666666671e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -3.6000000000000004e-02
    x_14_9    product_lb_241  -2.4773645559889104e-02
    x_14_9    product_ub_242  -4.0760869565258165e-02
    x_14_9    onehot_14_255  1
    x_14_9    stock_lb_258  9
    x_14_9    stock_ub_259  9
    x_14_9    parent_nonstrict_scope_260  0.012
    x_14_9    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_241  1
    w_14_9    product_ub_242  1
    w_14_9    normalized_mass_14_256  1
    w_14_9    normalized_ratio_14_257  -1.125
    w_14_9    full_original_Gini_318  -6.3916666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -0.024
    x_14_10   product_lb_243  -2.4773645559889104e-02
    x_14_10   product_ub_244  -4.0760869565258165e-02
    x_14_10   onehot_14_255  1
    x_14_10   stock_lb_258  10
    x_14_10   stock_ub_259  10
    x_14_10   parent_nonstrict_scope_260  0.024
    x_14_10   unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_243  1
    w_14_10   product_ub_244  1
    w_14_10   normalized_mass_14_256  1
    w_14_10   normalized_ratio_14_257  -1.25
    w_14_10   full_original_Gini_318  -9.2166666666666668e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_11   OBJ       -1.1999999999999997e-02
    x_14_11   product_lb_245  -2.4773645559889104e-02
    x_14_11   product_ub_246  -4.0760869565258165e-02
    x_14_11   onehot_14_255  1
    x_14_11   stock_lb_258  11
    x_14_11   stock_ub_259  11
    x_14_11   parent_nonstrict_scope_260  3.6000000000000004e-02
    x_14_11   unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_245  1
    w_14_11   product_ub_246  1
    w_14_11   normalized_mass_14_256  1
    w_14_11   normalized_ratio_14_257  -1.375
    w_14_11   full_original_Gini_318  -1.2591666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   product_lb_247  -2.4773645559889104e-02
    x_14_12   product_ub_248  -4.0760869565258165e-02
    x_14_12   onehot_14_255  1
    x_14_12   stock_lb_258  12
    x_14_12   stock_ub_259  12
    x_14_12   parent_nonstrict_scope_260  0.048
    x_14_12   unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_247  1
    w_14_12   product_ub_248  1
    w_14_12   normalized_mass_14_256  1
    w_14_12   normalized_ratio_14_257  -1.5
    w_14_12   full_original_Gini_318  -1.5966666666666665e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       1.1999999999999997e-02
    x_14_13   product_lb_249  -2.4773645559889104e-02
    x_14_13   product_ub_250  -4.0760869565258165e-02
    x_14_13   onehot_14_255  1
    x_14_13   stock_lb_258  13
    x_14_13   stock_ub_259  13
    x_14_13   parent_nonstrict_scope_260  0.06
    x_14_13   unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_249  1
    w_14_13   product_ub_250  1
    w_14_13   normalized_mass_14_256  1
    w_14_13   normalized_ratio_14_257  -1.625
    w_14_13   full_original_Gini_318  -1.9341666666666661e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       2.4000000000000007e-02
    x_14_14   product_lb_251  -2.4773645559889104e-02
    x_14_14   product_ub_252  -4.0760869565258165e-02
    x_14_14   onehot_14_255  1
    x_14_14   stock_lb_258  14
    x_14_14   stock_ub_259  14
    x_14_14   parent_nonstrict_scope_260  7.2000000000000008e-02
    x_14_14   unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_251  1
    w_14_14   product_ub_252  1
    w_14_14   normalized_mass_14_256  1
    w_14_14   normalized_ratio_14_257  -1.75
    w_14_14   full_original_Gini_318  -2.2716666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       3.6000000000000004e-02
    x_14_15   product_lb_253  -2.4773645559889104e-02
    x_14_15   product_ub_254  -4.0760869565258165e-02
    x_14_15   onehot_14_255  1
    x_14_15   stock_lb_258  15
    x_14_15   stock_ub_259  15
    x_14_15   parent_nonstrict_scope_260  0.084
    x_14_15   unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_253  1
    w_14_15   product_ub_254  1
    w_14_15   normalized_mass_14_256  1
    w_14_15   normalized_ratio_14_257  -1.875
    w_14_15   full_original_Gini_318  -2.6091666666666665e+01
    rho_14    normalized_ratio_14_257  1
    rho_14    block_pair_pos_265  1
    rho_14    block_pair_neg_266  -1
    rho_14    block_pair_pos_273  1
    rho_14    block_pair_neg_274  -1
    rho_14    block_pair_pos_279  1
    rho_14    block_pair_neg_280  -1
    rho_14    block_pair_pos_291  1
    rho_14    block_pair_neg_292  -1
    rho_14    block_pair_pos_301  1
    rho_14    block_pair_neg_302  -1
    rho_14    block_pair_pos_305  1
    rho_14    block_pair_neg_306  -1
    rho_14    block_pair_pos_311  1
    rho_14    block_pair_neg_312  -1
    rho_14    normalization_317  1
    a_8_2     block_pair_pos_285  1
    a_8_2     block_pair_neg_286  1
    a_8_2     full_original_Gini_318  -1
    a_8_31    block_pair_pos_297  1
    a_8_31    block_pair_neg_298  1
    a_8_31    full_original_Gini_318  -1
    a_8_6     block_pair_pos_289  1
    a_8_6     block_pair_neg_290  1
    a_8_6     full_original_Gini_318  -1
    a_8_16    block_pair_pos_293  1
    a_8_16    block_pair_neg_294  1
    a_8_16    full_original_Gini_318  -1
    a_8_5     block_pair_pos_287  1
    a_8_5     block_pair_neg_288  1
    a_8_5     full_original_Gini_318  -1
    a_8_26    block_pair_pos_295  1
    a_8_26    block_pair_neg_296  1
    a_8_26    full_original_Gini_318  -1
    a_8_14    block_pair_pos_291  1
    a_8_14    block_pair_neg_292  1
    a_8_14    full_original_Gini_318  -1
    a_2_31    block_pair_pos_271  1
    a_2_31    block_pair_neg_272  1
    a_2_31    full_original_Gini_318  -1
    a_2_6     block_pair_pos_263  1
    a_2_6     block_pair_neg_264  1
    a_2_6     full_original_Gini_318  -1
    a_2_16    block_pair_pos_267  1
    a_2_16    block_pair_neg_268  1
    a_2_16    full_original_Gini_318  -1
    a_2_5     block_pair_pos_261  1
    a_2_5     block_pair_neg_262  1
    a_2_5     full_original_Gini_318  -1
    a_2_26    block_pair_pos_269  1
    a_2_26    block_pair_neg_270  1
    a_2_26    full_original_Gini_318  -1
    a_2_14    block_pair_pos_265  1
    a_2_14    block_pair_neg_266  1
    a_2_14    full_original_Gini_318  -1
    a_31_6    block_pair_pos_309  1
    a_31_6    block_pair_neg_310  1
    a_31_6    full_original_Gini_318  -1
    a_31_16   block_pair_pos_313  1
    a_31_16   block_pair_neg_314  1
    a_31_16   full_original_Gini_318  -1
    a_31_5    block_pair_pos_307  1
    a_31_5    block_pair_neg_308  1
    a_31_5    full_original_Gini_318  -1
    a_31_26   block_pair_pos_315  1
    a_31_26   block_pair_neg_316  1
    a_31_26   full_original_Gini_318  -1
    a_31_14   block_pair_pos_311  1
    a_31_14   block_pair_neg_312  1
    a_31_14   full_original_Gini_318  -1
    a_6_16    block_pair_pos_281  1
    a_6_16    block_pair_neg_282  1
    a_6_16    full_original_Gini_318  -1
    a_6_5     block_pair_pos_277  1
    a_6_5     block_pair_neg_278  1
    a_6_5     full_original_Gini_318  -1
    a_6_26    block_pair_pos_283  1
    a_6_26    block_pair_neg_284  1
    a_6_26    full_original_Gini_318  -1
    a_6_14    block_pair_pos_279  1
    a_6_14    block_pair_neg_280  1
    a_6_14    full_original_Gini_318  -1
    a_16_5    block_pair_pos_299  1
    a_16_5    block_pair_neg_300  1
    a_16_5    full_original_Gini_318  -1
    a_16_26   block_pair_pos_303  1
    a_16_26   block_pair_neg_304  1
    a_16_26   full_original_Gini_318  -1
    a_16_14   block_pair_pos_301  1
    a_16_14   block_pair_neg_302  1
    a_16_14   full_original_Gini_318  -1
    a_5_26    block_pair_pos_275  1
    a_5_26    block_pair_neg_276  1
    a_5_26    full_original_Gini_318  -1
    a_5_14    block_pair_pos_273  1
    a_5_14    block_pair_neg_274  1
    a_5_14    full_original_Gini_318  -1
    a_26_14   block_pair_pos_305  1
    a_26_14   block_pair_neg_306  1
    a_26_14   full_original_Gini_318  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_8_0  unique_nonzero_owner_319  1
    service_0_8_0  service_visit_def_808  1
    service_0_8_0  free_load_conservation_809  -15
    service_0_8_0  original_T_including_depot_unload_856  1800
    service_0_8_1  unique_nonzero_owner_320  1
    service_0_8_1  service_visit_def_808  1
    service_0_8_1  free_load_conservation_809  -14
    service_0_8_1  original_T_including_depot_unload_856  1680
    service_0_8_2  unique_nonzero_owner_321  1
    service_0_8_2  service_visit_def_808  1
    service_0_8_2  free_load_conservation_809  -13
    service_0_8_2  original_T_including_depot_unload_856  1560
    service_0_8_3  unique_nonzero_owner_322  1
    service_0_8_3  service_visit_def_808  1
    service_0_8_3  free_load_conservation_809  -12
    service_0_8_3  original_T_including_depot_unload_856  1440
    service_0_8_4  unique_nonzero_owner_323  1
    service_0_8_4  service_visit_def_808  1
    service_0_8_4  free_load_conservation_809  -11
    service_0_8_4  original_T_including_depot_unload_856  1320
    service_0_8_5  unique_nonzero_owner_324  1
    service_0_8_5  service_visit_def_808  1
    service_0_8_5  free_load_conservation_809  -10
    service_0_8_5  original_T_including_depot_unload_856  1200
    service_0_8_6  unique_nonzero_owner_325  1
    service_0_8_6  service_visit_def_808  1
    service_0_8_6  free_load_conservation_809  -9
    service_0_8_6  original_T_including_depot_unload_856  1080
    service_0_8_7  unique_nonzero_owner_326  1
    service_0_8_7  service_visit_def_808  1
    service_0_8_7  free_load_conservation_809  -8
    service_0_8_7  original_T_including_depot_unload_856  960
    service_0_8_8  unique_nonzero_owner_327  1
    service_0_8_8  service_visit_def_808  1
    service_0_8_8  free_load_conservation_809  -7
    service_0_8_8  original_T_including_depot_unload_856  840
    service_0_8_9  unique_nonzero_owner_328  1
    service_0_8_9  service_visit_def_808  1
    service_0_8_9  free_load_conservation_809  -6
    service_0_8_9  original_T_including_depot_unload_856  720
    service_0_8_10  unique_nonzero_owner_329  1
    service_0_8_10  service_visit_def_808  1
    service_0_8_10  free_load_conservation_809  -5
    service_0_8_10  original_T_including_depot_unload_856  600
    service_0_8_11  unique_nonzero_owner_330  1
    service_0_8_11  service_visit_def_808  1
    service_0_8_11  free_load_conservation_809  -4
    service_0_8_11  original_T_including_depot_unload_856  480
    service_0_8_12  unique_nonzero_owner_331  1
    service_0_8_12  service_visit_def_808  1
    service_0_8_12  free_load_conservation_809  -3
    service_0_8_12  original_T_including_depot_unload_856  360
    service_0_8_13  unique_nonzero_owner_332  1
    service_0_8_13  service_visit_def_808  1
    service_0_8_13  free_load_conservation_809  -2
    service_0_8_13  original_T_including_depot_unload_856  240
    service_0_8_14  unique_nonzero_owner_333  1
    service_0_8_14  service_visit_def_808  1
    service_0_8_14  free_load_conservation_809  -1
    service_0_8_14  original_T_including_depot_unload_856  120
    service_0_8_16  unique_nonzero_owner_334  1
    service_0_8_16  service_visit_def_808  1
    service_0_8_16  free_load_conservation_809  1
    service_0_8_17  unique_nonzero_owner_335  1
    service_0_8_17  service_visit_def_808  1
    service_0_8_17  free_load_conservation_809  2
    service_0_8_18  unique_nonzero_owner_336  1
    service_0_8_18  service_visit_def_808  1
    service_0_8_18  free_load_conservation_809  3
    service_0_8_19  unique_nonzero_owner_337  1
    service_0_8_19  service_visit_def_808  1
    service_0_8_19  free_load_conservation_809  4
    service_0_8_20  unique_nonzero_owner_338  1
    service_0_8_20  service_visit_def_808  1
    service_0_8_20  free_load_conservation_809  5
    service_0_8_21  unique_nonzero_owner_339  1
    service_0_8_21  service_visit_def_808  1
    service_0_8_21  free_load_conservation_809  6
    service_1_8_0  unique_nonzero_owner_319  1
    service_1_8_0  service_visit_def_1237  1
    service_1_8_0  free_load_conservation_1238  -15
    service_1_8_0  original_T_including_depot_unload_1285  1800
    service_1_8_1  unique_nonzero_owner_320  1
    service_1_8_1  service_visit_def_1237  1
    service_1_8_1  free_load_conservation_1238  -14
    service_1_8_1  original_T_including_depot_unload_1285  1680
    service_1_8_2  unique_nonzero_owner_321  1
    service_1_8_2  service_visit_def_1237  1
    service_1_8_2  free_load_conservation_1238  -13
    service_1_8_2  original_T_including_depot_unload_1285  1560
    service_1_8_3  unique_nonzero_owner_322  1
    service_1_8_3  service_visit_def_1237  1
    service_1_8_3  free_load_conservation_1238  -12
    service_1_8_3  original_T_including_depot_unload_1285  1440
    service_1_8_4  unique_nonzero_owner_323  1
    service_1_8_4  service_visit_def_1237  1
    service_1_8_4  free_load_conservation_1238  -11
    service_1_8_4  original_T_including_depot_unload_1285  1320
    service_1_8_5  unique_nonzero_owner_324  1
    service_1_8_5  service_visit_def_1237  1
    service_1_8_5  free_load_conservation_1238  -10
    service_1_8_5  original_T_including_depot_unload_1285  1200
    service_1_8_6  unique_nonzero_owner_325  1
    service_1_8_6  service_visit_def_1237  1
    service_1_8_6  free_load_conservation_1238  -9
    service_1_8_6  original_T_including_depot_unload_1285  1080
    service_1_8_7  unique_nonzero_owner_326  1
    service_1_8_7  service_visit_def_1237  1
    service_1_8_7  free_load_conservation_1238  -8
    service_1_8_7  original_T_including_depot_unload_1285  960
    service_1_8_8  unique_nonzero_owner_327  1
    service_1_8_8  service_visit_def_1237  1
    service_1_8_8  free_load_conservation_1238  -7
    service_1_8_8  original_T_including_depot_unload_1285  840
    service_1_8_9  unique_nonzero_owner_328  1
    service_1_8_9  service_visit_def_1237  1
    service_1_8_9  free_load_conservation_1238  -6
    service_1_8_9  original_T_including_depot_unload_1285  720
    service_1_8_10  unique_nonzero_owner_329  1
    service_1_8_10  service_visit_def_1237  1
    service_1_8_10  free_load_conservation_1238  -5
    service_1_8_10  original_T_including_depot_unload_1285  600
    service_1_8_11  unique_nonzero_owner_330  1
    service_1_8_11  service_visit_def_1237  1
    service_1_8_11  free_load_conservation_1238  -4
    service_1_8_11  original_T_including_depot_unload_1285  480
    service_1_8_12  unique_nonzero_owner_331  1
    service_1_8_12  service_visit_def_1237  1
    service_1_8_12  free_load_conservation_1238  -3
    service_1_8_12  original_T_including_depot_unload_1285  360
    service_1_8_13  unique_nonzero_owner_332  1
    service_1_8_13  service_visit_def_1237  1
    service_1_8_13  free_load_conservation_1238  -2
    service_1_8_13  original_T_including_depot_unload_1285  240
    service_1_8_14  unique_nonzero_owner_333  1
    service_1_8_14  service_visit_def_1237  1
    service_1_8_14  free_load_conservation_1238  -1
    service_1_8_14  original_T_including_depot_unload_1285  120
    service_1_8_16  unique_nonzero_owner_334  1
    service_1_8_16  service_visit_def_1237  1
    service_1_8_16  free_load_conservation_1238  1
    service_1_8_17  unique_nonzero_owner_335  1
    service_1_8_17  service_visit_def_1237  1
    service_1_8_17  free_load_conservation_1238  2
    service_1_8_18  unique_nonzero_owner_336  1
    service_1_8_18  service_visit_def_1237  1
    service_1_8_18  free_load_conservation_1238  3
    service_1_8_19  unique_nonzero_owner_337  1
    service_1_8_19  service_visit_def_1237  1
    service_1_8_19  free_load_conservation_1238  4
    service_1_8_20  unique_nonzero_owner_338  1
    service_1_8_20  service_visit_def_1237  1
    service_1_8_20  free_load_conservation_1238  5
    service_1_8_21  unique_nonzero_owner_339  1
    service_1_8_21  service_visit_def_1237  1
    service_1_8_21  free_load_conservation_1238  6
    service_2_8_0  unique_nonzero_owner_319  1
    service_2_8_0  service_visit_def_1609  1
    service_2_8_0  free_load_conservation_1610  -15
    service_2_8_0  original_T_including_depot_unload_1656  1800
    service_2_8_1  unique_nonzero_owner_320  1
    service_2_8_1  service_visit_def_1609  1
    service_2_8_1  free_load_conservation_1610  -14
    service_2_8_1  original_T_including_depot_unload_1656  1680
    service_2_8_2  unique_nonzero_owner_321  1
    service_2_8_2  service_visit_def_1609  1
    service_2_8_2  free_load_conservation_1610  -13
    service_2_8_2  original_T_including_depot_unload_1656  1560
    service_2_8_3  unique_nonzero_owner_322  1
    service_2_8_3  service_visit_def_1609  1
    service_2_8_3  free_load_conservation_1610  -12
    service_2_8_3  original_T_including_depot_unload_1656  1440
    service_2_8_4  unique_nonzero_owner_323  1
    service_2_8_4  service_visit_def_1609  1
    service_2_8_4  free_load_conservation_1610  -11
    service_2_8_4  original_T_including_depot_unload_1656  1320
    service_2_8_5  unique_nonzero_owner_324  1
    service_2_8_5  service_visit_def_1609  1
    service_2_8_5  free_load_conservation_1610  -10
    service_2_8_5  original_T_including_depot_unload_1656  1200
    service_2_8_6  unique_nonzero_owner_325  1
    service_2_8_6  service_visit_def_1609  1
    service_2_8_6  free_load_conservation_1610  -9
    service_2_8_6  original_T_including_depot_unload_1656  1080
    service_2_8_7  unique_nonzero_owner_326  1
    service_2_8_7  service_visit_def_1609  1
    service_2_8_7  free_load_conservation_1610  -8
    service_2_8_7  original_T_including_depot_unload_1656  960
    service_2_8_8  unique_nonzero_owner_327  1
    service_2_8_8  service_visit_def_1609  1
    service_2_8_8  free_load_conservation_1610  -7
    service_2_8_8  original_T_including_depot_unload_1656  840
    service_2_8_9  unique_nonzero_owner_328  1
    service_2_8_9  service_visit_def_1609  1
    service_2_8_9  free_load_conservation_1610  -6
    service_2_8_9  original_T_including_depot_unload_1656  720
    service_2_8_10  unique_nonzero_owner_329  1
    service_2_8_10  service_visit_def_1609  1
    service_2_8_10  free_load_conservation_1610  -5
    service_2_8_10  original_T_including_depot_unload_1656  600
    service_2_8_11  unique_nonzero_owner_330  1
    service_2_8_11  service_visit_def_1609  1
    service_2_8_11  free_load_conservation_1610  -4
    service_2_8_11  original_T_including_depot_unload_1656  480
    service_2_8_12  unique_nonzero_owner_331  1
    service_2_8_12  service_visit_def_1609  1
    service_2_8_12  free_load_conservation_1610  -3
    service_2_8_12  original_T_including_depot_unload_1656  360
    service_2_8_13  unique_nonzero_owner_332  1
    service_2_8_13  service_visit_def_1609  1
    service_2_8_13  free_load_conservation_1610  -2
    service_2_8_13  original_T_including_depot_unload_1656  240
    service_2_8_14  unique_nonzero_owner_333  1
    service_2_8_14  service_visit_def_1609  1
    service_2_8_14  free_load_conservation_1610  -1
    service_2_8_14  original_T_including_depot_unload_1656  120
    service_2_8_16  unique_nonzero_owner_334  1
    service_2_8_16  service_visit_def_1609  1
    service_2_8_16  free_load_conservation_1610  1
    service_2_8_17  unique_nonzero_owner_335  1
    service_2_8_17  service_visit_def_1609  1
    service_2_8_17  free_load_conservation_1610  2
    service_2_8_18  unique_nonzero_owner_336  1
    service_2_8_18  service_visit_def_1609  1
    service_2_8_18  free_load_conservation_1610  3
    service_2_8_19  unique_nonzero_owner_337  1
    service_2_8_19  service_visit_def_1609  1
    service_2_8_19  free_load_conservation_1610  4
    service_2_8_20  unique_nonzero_owner_338  1
    service_2_8_20  service_visit_def_1609  1
    service_2_8_20  free_load_conservation_1610  5
    service_2_8_21  unique_nonzero_owner_339  1
    service_2_8_21  service_visit_def_1609  1
    service_2_8_21  free_load_conservation_1610  6
    service_0_2_1  unique_nonzero_owner_340  1
    service_0_2_1  service_visit_def_814  1
    service_0_2_1  free_load_conservation_815  1
    service_0_2_2  unique_nonzero_owner_341  1
    service_0_2_2  service_visit_def_814  1
    service_0_2_2  free_load_conservation_815  2
    service_0_2_3  unique_nonzero_owner_342  1
    service_0_2_3  service_visit_def_814  1
    service_0_2_3  free_load_conservation_815  3
    service_0_2_4  unique_nonzero_owner_343  1
    service_0_2_4  service_visit_def_814  1
    service_0_2_4  free_load_conservation_815  4
    service_0_2_5  unique_nonzero_owner_344  1
    service_0_2_5  service_visit_def_814  1
    service_0_2_5  free_load_conservation_815  5
    service_0_2_6  unique_nonzero_owner_345  1
    service_0_2_6  service_visit_def_814  1
    service_0_2_6  free_load_conservation_815  6
    service_0_2_7  unique_nonzero_owner_346  1
    service_0_2_7  service_visit_def_814  1
    service_0_2_7  free_load_conservation_815  7
    service_0_2_8  unique_nonzero_owner_347  1
    service_0_2_8  service_visit_def_814  1
    service_0_2_8  free_load_conservation_815  8
    service_0_2_9  unique_nonzero_owner_348  1
    service_0_2_9  service_visit_def_814  1
    service_0_2_9  free_load_conservation_815  9
    service_0_2_10  unique_nonzero_owner_349  1
    service_0_2_10  service_visit_def_814  1
    service_0_2_10  free_load_conservation_815  10
    service_0_2_11  unique_nonzero_owner_350  1
    service_0_2_11  service_visit_def_814  1
    service_0_2_11  free_load_conservation_815  11
    service_0_2_12  unique_nonzero_owner_351  1
    service_0_2_12  service_visit_def_814  1
    service_0_2_12  free_load_conservation_815  12
    service_0_2_13  unique_nonzero_owner_352  1
    service_0_2_13  service_visit_def_814  1
    service_0_2_13  free_load_conservation_815  13
    service_0_2_14  unique_nonzero_owner_353  1
    service_0_2_14  service_visit_def_814  1
    service_0_2_14  free_load_conservation_815  14
    service_0_2_15  unique_nonzero_owner_354  1
    service_0_2_15  service_visit_def_814  1
    service_0_2_15  free_load_conservation_815  15
    service_1_2_1  unique_nonzero_owner_340  1
    service_1_2_1  service_visit_def_1243  1
    service_1_2_1  free_load_conservation_1244  1
    service_1_2_2  unique_nonzero_owner_341  1
    service_1_2_2  service_visit_def_1243  1
    service_1_2_2  free_load_conservation_1244  2
    service_1_2_3  unique_nonzero_owner_342  1
    service_1_2_3  service_visit_def_1243  1
    service_1_2_3  free_load_conservation_1244  3
    service_1_2_4  unique_nonzero_owner_343  1
    service_1_2_4  service_visit_def_1243  1
    service_1_2_4  free_load_conservation_1244  4
    service_1_2_5  unique_nonzero_owner_344  1
    service_1_2_5  service_visit_def_1243  1
    service_1_2_5  free_load_conservation_1244  5
    service_1_2_6  unique_nonzero_owner_345  1
    service_1_2_6  service_visit_def_1243  1
    service_1_2_6  free_load_conservation_1244  6
    service_1_2_7  unique_nonzero_owner_346  1
    service_1_2_7  service_visit_def_1243  1
    service_1_2_7  free_load_conservation_1244  7
    service_1_2_8  unique_nonzero_owner_347  1
    service_1_2_8  service_visit_def_1243  1
    service_1_2_8  free_load_conservation_1244  8
    service_1_2_9  unique_nonzero_owner_348  1
    service_1_2_9  service_visit_def_1243  1
    service_1_2_9  free_load_conservation_1244  9
    service_1_2_10  unique_nonzero_owner_349  1
    service_1_2_10  service_visit_def_1243  1
    service_1_2_10  free_load_conservation_1244  10
    service_1_2_11  unique_nonzero_owner_350  1
    service_1_2_11  service_visit_def_1243  1
    service_1_2_11  free_load_conservation_1244  11
    service_1_2_12  unique_nonzero_owner_351  1
    service_1_2_12  service_visit_def_1243  1
    service_1_2_12  free_load_conservation_1244  12
    service_1_2_13  unique_nonzero_owner_352  1
    service_1_2_13  service_visit_def_1243  1
    service_1_2_13  free_load_conservation_1244  13
    service_1_2_14  unique_nonzero_owner_353  1
    service_1_2_14  service_visit_def_1243  1
    service_1_2_14  free_load_conservation_1244  14
    service_1_2_15  unique_nonzero_owner_354  1
    service_1_2_15  service_visit_def_1243  1
    service_1_2_15  free_load_conservation_1244  15
    service_2_2_1  unique_nonzero_owner_340  1
    service_2_2_1  service_visit_def_1615  1
    service_2_2_1  free_load_conservation_1616  1
    service_2_2_2  unique_nonzero_owner_341  1
    service_2_2_2  service_visit_def_1615  1
    service_2_2_2  free_load_conservation_1616  2
    service_2_2_3  unique_nonzero_owner_342  1
    service_2_2_3  service_visit_def_1615  1
    service_2_2_3  free_load_conservation_1616  3
    service_2_2_4  unique_nonzero_owner_343  1
    service_2_2_4  service_visit_def_1615  1
    service_2_2_4  free_load_conservation_1616  4
    service_2_2_5  unique_nonzero_owner_344  1
    service_2_2_5  service_visit_def_1615  1
    service_2_2_5  free_load_conservation_1616  5
    service_2_2_6  unique_nonzero_owner_345  1
    service_2_2_6  service_visit_def_1615  1
    service_2_2_6  free_load_conservation_1616  6
    service_2_2_7  unique_nonzero_owner_346  1
    service_2_2_7  service_visit_def_1615  1
    service_2_2_7  free_load_conservation_1616  7
    service_2_2_8  unique_nonzero_owner_347  1
    service_2_2_8  service_visit_def_1615  1
    service_2_2_8  free_load_conservation_1616  8
    service_2_2_9  unique_nonzero_owner_348  1
    service_2_2_9  service_visit_def_1615  1
    service_2_2_9  free_load_conservation_1616  9
    service_2_2_10  unique_nonzero_owner_349  1
    service_2_2_10  service_visit_def_1615  1
    service_2_2_10  free_load_conservation_1616  10
    service_2_2_11  unique_nonzero_owner_350  1
    service_2_2_11  service_visit_def_1615  1
    service_2_2_11  free_load_conservation_1616  11
    service_2_2_12  unique_nonzero_owner_351  1
    service_2_2_12  service_visit_def_1615  1
    service_2_2_12  free_load_conservation_1616  12
    service_2_2_13  unique_nonzero_owner_352  1
    service_2_2_13  service_visit_def_1615  1
    service_2_2_13  free_load_conservation_1616  13
    service_2_2_14  unique_nonzero_owner_353  1
    service_2_2_14  service_visit_def_1615  1
    service_2_2_14  free_load_conservation_1616  14
    service_2_2_15  unique_nonzero_owner_354  1
    service_2_2_15  service_visit_def_1615  1
    service_2_2_15  free_load_conservation_1616  15
    service_0_31_0  unique_nonzero_owner_355  1
    service_0_31_0  service_visit_def_820  1
    service_0_31_0  free_load_conservation_821  -2
    service_0_31_0  original_T_including_depot_unload_856  240
    service_0_31_1  unique_nonzero_owner_356  1
    service_0_31_1  service_visit_def_820  1
    service_0_31_1  free_load_conservation_821  -1
    service_0_31_1  original_T_including_depot_unload_856  120
    service_0_31_3  unique_nonzero_owner_357  1
    service_0_31_3  service_visit_def_820  1
    service_0_31_3  free_load_conservation_821  1
    service_0_31_4  unique_nonzero_owner_358  1
    service_0_31_4  service_visit_def_820  1
    service_0_31_4  free_load_conservation_821  2
    service_0_31_5  unique_nonzero_owner_359  1
    service_0_31_5  service_visit_def_820  1
    service_0_31_5  free_load_conservation_821  3
    service_0_31_6  unique_nonzero_owner_360  1
    service_0_31_6  service_visit_def_820  1
    service_0_31_6  free_load_conservation_821  4
    service_0_31_7  unique_nonzero_owner_361  1
    service_0_31_7  service_visit_def_820  1
    service_0_31_7  free_load_conservation_821  5
    service_0_31_8  unique_nonzero_owner_362  1
    service_0_31_8  service_visit_def_820  1
    service_0_31_8  free_load_conservation_821  6
    service_0_31_9  unique_nonzero_owner_363  1
    service_0_31_9  service_visit_def_820  1
    service_0_31_9  free_load_conservation_821  7
    service_0_31_10  unique_nonzero_owner_364  1
    service_0_31_10  service_visit_def_820  1
    service_0_31_10  free_load_conservation_821  8
    service_0_31_11  unique_nonzero_owner_365  1
    service_0_31_11  service_visit_def_820  1
    service_0_31_11  free_load_conservation_821  9
    service_0_31_12  unique_nonzero_owner_366  1
    service_0_31_12  service_visit_def_820  1
    service_0_31_12  free_load_conservation_821  10
    service_1_31_0  unique_nonzero_owner_355  1
    service_1_31_0  service_visit_def_1249  1
    service_1_31_0  free_load_conservation_1250  -2
    service_1_31_0  original_T_including_depot_unload_1285  240
    service_1_31_1  unique_nonzero_owner_356  1
    service_1_31_1  service_visit_def_1249  1
    service_1_31_1  free_load_conservation_1250  -1
    service_1_31_1  original_T_including_depot_unload_1285  120
    service_1_31_3  unique_nonzero_owner_357  1
    service_1_31_3  service_visit_def_1249  1
    service_1_31_3  free_load_conservation_1250  1
    service_1_31_4  unique_nonzero_owner_358  1
    service_1_31_4  service_visit_def_1249  1
    service_1_31_4  free_load_conservation_1250  2
    service_1_31_5  unique_nonzero_owner_359  1
    service_1_31_5  service_visit_def_1249  1
    service_1_31_5  free_load_conservation_1250  3
    service_1_31_6  unique_nonzero_owner_360  1
    service_1_31_6  service_visit_def_1249  1
    service_1_31_6  free_load_conservation_1250  4
    service_1_31_7  unique_nonzero_owner_361  1
    service_1_31_7  service_visit_def_1249  1
    service_1_31_7  free_load_conservation_1250  5
    service_1_31_8  unique_nonzero_owner_362  1
    service_1_31_8  service_visit_def_1249  1
    service_1_31_8  free_load_conservation_1250  6
    service_1_31_9  unique_nonzero_owner_363  1
    service_1_31_9  service_visit_def_1249  1
    service_1_31_9  free_load_conservation_1250  7
    service_1_31_10  unique_nonzero_owner_364  1
    service_1_31_10  service_visit_def_1249  1
    service_1_31_10  free_load_conservation_1250  8
    service_1_31_11  unique_nonzero_owner_365  1
    service_1_31_11  service_visit_def_1249  1
    service_1_31_11  free_load_conservation_1250  9
    service_1_31_12  unique_nonzero_owner_366  1
    service_1_31_12  service_visit_def_1249  1
    service_1_31_12  free_load_conservation_1250  10
    service_2_31_0  unique_nonzero_owner_355  1
    service_2_31_0  service_visit_def_1621  1
    service_2_31_0  free_load_conservation_1622  -2
    service_2_31_0  original_T_including_depot_unload_1656  240
    service_2_31_1  unique_nonzero_owner_356  1
    service_2_31_1  service_visit_def_1621  1
    service_2_31_1  free_load_conservation_1622  -1
    service_2_31_1  original_T_including_depot_unload_1656  120
    service_2_31_3  unique_nonzero_owner_357  1
    service_2_31_3  service_visit_def_1621  1
    service_2_31_3  free_load_conservation_1622  1
    service_2_31_4  unique_nonzero_owner_358  1
    service_2_31_4  service_visit_def_1621  1
    service_2_31_4  free_load_conservation_1622  2
    service_2_31_5  unique_nonzero_owner_359  1
    service_2_31_5  service_visit_def_1621  1
    service_2_31_5  free_load_conservation_1622  3
    service_2_31_6  unique_nonzero_owner_360  1
    service_2_31_6  service_visit_def_1621  1
    service_2_31_6  free_load_conservation_1622  4
    service_2_31_7  unique_nonzero_owner_361  1
    service_2_31_7  service_visit_def_1621  1
    service_2_31_7  free_load_conservation_1622  5
    service_2_31_8  unique_nonzero_owner_362  1
    service_2_31_8  service_visit_def_1621  1
    service_2_31_8  free_load_conservation_1622  6
    service_2_31_9  unique_nonzero_owner_363  1
    service_2_31_9  service_visit_def_1621  1
    service_2_31_9  free_load_conservation_1622  7
    service_2_31_10  unique_nonzero_owner_364  1
    service_2_31_10  service_visit_def_1621  1
    service_2_31_10  free_load_conservation_1622  8
    service_2_31_11  unique_nonzero_owner_365  1
    service_2_31_11  service_visit_def_1621  1
    service_2_31_11  free_load_conservation_1622  9
    service_2_31_12  unique_nonzero_owner_366  1
    service_2_31_12  service_visit_def_1621  1
    service_2_31_12  free_load_conservation_1622  10
    service_0_6_0  unique_nonzero_owner_367  1
    service_0_6_0  service_visit_def_826  1
    service_0_6_0  free_load_conservation_827  -1
    service_0_6_0  original_T_including_depot_unload_856  120
    service_0_6_2  unique_nonzero_owner_368  1
    service_0_6_2  service_visit_def_826  1
    service_0_6_2  free_load_conservation_827  1
    service_0_6_3  unique_nonzero_owner_369  1
    service_0_6_3  service_visit_def_826  1
    service_0_6_3  free_load_conservation_827  2
    service_0_6_4  unique_nonzero_owner_370  1
    service_0_6_4  service_visit_def_826  1
    service_0_6_4  free_load_conservation_827  3
    service_0_6_5  unique_nonzero_owner_371  1
    service_0_6_5  service_visit_def_826  1
    service_0_6_5  free_load_conservation_827  4
    service_0_6_6  unique_nonzero_owner_372  1
    service_0_6_6  service_visit_def_826  1
    service_0_6_6  free_load_conservation_827  5
    service_0_6_7  unique_nonzero_owner_373  1
    service_0_6_7  service_visit_def_826  1
    service_0_6_7  free_load_conservation_827  6
    service_0_6_8  unique_nonzero_owner_374  1
    service_0_6_8  service_visit_def_826  1
    service_0_6_8  free_load_conservation_827  7
    service_0_6_9  unique_nonzero_owner_375  1
    service_0_6_9  service_visit_def_826  1
    service_0_6_9  free_load_conservation_827  8
    service_0_6_10  unique_nonzero_owner_376  1
    service_0_6_10  service_visit_def_826  1
    service_0_6_10  free_load_conservation_827  9
    service_1_6_0  unique_nonzero_owner_367  1
    service_1_6_0  service_visit_def_1255  1
    service_1_6_0  free_load_conservation_1256  -1
    service_1_6_0  original_T_including_depot_unload_1285  120
    service_1_6_2  unique_nonzero_owner_368  1
    service_1_6_2  service_visit_def_1255  1
    service_1_6_2  free_load_conservation_1256  1
    service_1_6_3  unique_nonzero_owner_369  1
    service_1_6_3  service_visit_def_1255  1
    service_1_6_3  free_load_conservation_1256  2
    service_1_6_4  unique_nonzero_owner_370  1
    service_1_6_4  service_visit_def_1255  1
    service_1_6_4  free_load_conservation_1256  3
    service_1_6_5  unique_nonzero_owner_371  1
    service_1_6_5  service_visit_def_1255  1
    service_1_6_5  free_load_conservation_1256  4
    service_1_6_6  unique_nonzero_owner_372  1
    service_1_6_6  service_visit_def_1255  1
    service_1_6_6  free_load_conservation_1256  5
    service_1_6_7  unique_nonzero_owner_373  1
    service_1_6_7  service_visit_def_1255  1
    service_1_6_7  free_load_conservation_1256  6
    service_1_6_8  unique_nonzero_owner_374  1
    service_1_6_8  service_visit_def_1255  1
    service_1_6_8  free_load_conservation_1256  7
    service_1_6_9  unique_nonzero_owner_375  1
    service_1_6_9  service_visit_def_1255  1
    service_1_6_9  free_load_conservation_1256  8
    service_1_6_10  unique_nonzero_owner_376  1
    service_1_6_10  service_visit_def_1255  1
    service_1_6_10  free_load_conservation_1256  9
    service_2_6_0  unique_nonzero_owner_367  1
    service_2_6_0  service_visit_def_1627  1
    service_2_6_0  free_load_conservation_1628  -1
    service_2_6_0  original_T_including_depot_unload_1656  120
    service_2_6_2  unique_nonzero_owner_368  1
    service_2_6_2  service_visit_def_1627  1
    service_2_6_2  free_load_conservation_1628  1
    service_2_6_3  unique_nonzero_owner_369  1
    service_2_6_3  service_visit_def_1627  1
    service_2_6_3  free_load_conservation_1628  2
    service_2_6_4  unique_nonzero_owner_370  1
    service_2_6_4  service_visit_def_1627  1
    service_2_6_4  free_load_conservation_1628  3
    service_2_6_5  unique_nonzero_owner_371  1
    service_2_6_5  service_visit_def_1627  1
    service_2_6_5  free_load_conservation_1628  4
    service_2_6_6  unique_nonzero_owner_372  1
    service_2_6_6  service_visit_def_1627  1
    service_2_6_6  free_load_conservation_1628  5
    service_2_6_7  unique_nonzero_owner_373  1
    service_2_6_7  service_visit_def_1627  1
    service_2_6_7  free_load_conservation_1628  6
    service_2_6_8  unique_nonzero_owner_374  1
    service_2_6_8  service_visit_def_1627  1
    service_2_6_8  free_load_conservation_1628  7
    service_2_6_9  unique_nonzero_owner_375  1
    service_2_6_9  service_visit_def_1627  1
    service_2_6_9  free_load_conservation_1628  8
    service_2_6_10  unique_nonzero_owner_376  1
    service_2_6_10  service_visit_def_1627  1
    service_2_6_10  free_load_conservation_1628  9
    service_0_16_0  unique_nonzero_owner_377  1
    service_0_16_0  service_visit_def_832  1
    service_0_16_0  free_load_conservation_833  -1
    service_0_16_0  original_T_including_depot_unload_856  120
    service_0_16_2  unique_nonzero_owner_378  1
    service_0_16_2  service_visit_def_832  1
    service_0_16_2  free_load_conservation_833  1
    service_0_16_3  unique_nonzero_owner_379  1
    service_0_16_3  service_visit_def_832  1
    service_0_16_3  free_load_conservation_833  2
    service_0_16_4  unique_nonzero_owner_380  1
    service_0_16_4  service_visit_def_832  1
    service_0_16_4  free_load_conservation_833  3
    service_0_16_5  unique_nonzero_owner_381  1
    service_0_16_5  service_visit_def_832  1
    service_0_16_5  free_load_conservation_833  4
    service_0_16_6  unique_nonzero_owner_382  1
    service_0_16_6  service_visit_def_832  1
    service_0_16_6  free_load_conservation_833  5
    service_0_16_7  unique_nonzero_owner_383  1
    service_0_16_7  service_visit_def_832  1
    service_0_16_7  free_load_conservation_833  6
    service_0_16_8  unique_nonzero_owner_384  1
    service_0_16_8  service_visit_def_832  1
    service_0_16_8  free_load_conservation_833  7
    service_0_16_9  unique_nonzero_owner_385  1
    service_0_16_9  service_visit_def_832  1
    service_0_16_9  free_load_conservation_833  8
    service_0_16_10  unique_nonzero_owner_386  1
    service_0_16_10  service_visit_def_832  1
    service_0_16_10  free_load_conservation_833  9
    service_0_16_11  unique_nonzero_owner_387  1
    service_0_16_11  service_visit_def_832  1
    service_0_16_11  free_load_conservation_833  10
    service_0_16_12  unique_nonzero_owner_388  1
    service_0_16_12  service_visit_def_832  1
    service_0_16_12  free_load_conservation_833  11
    service_1_16_0  unique_nonzero_owner_377  1
    service_1_16_0  service_visit_def_1261  1
    service_1_16_0  free_load_conservation_1262  -1
    service_1_16_0  original_T_including_depot_unload_1285  120
    service_1_16_2  unique_nonzero_owner_378  1
    service_1_16_2  service_visit_def_1261  1
    service_1_16_2  free_load_conservation_1262  1
    service_1_16_3  unique_nonzero_owner_379  1
    service_1_16_3  service_visit_def_1261  1
    service_1_16_3  free_load_conservation_1262  2
    service_1_16_4  unique_nonzero_owner_380  1
    service_1_16_4  service_visit_def_1261  1
    service_1_16_4  free_load_conservation_1262  3
    service_1_16_5  unique_nonzero_owner_381  1
    service_1_16_5  service_visit_def_1261  1
    service_1_16_5  free_load_conservation_1262  4
    service_1_16_6  unique_nonzero_owner_382  1
    service_1_16_6  service_visit_def_1261  1
    service_1_16_6  free_load_conservation_1262  5
    service_1_16_7  unique_nonzero_owner_383  1
    service_1_16_7  service_visit_def_1261  1
    service_1_16_7  free_load_conservation_1262  6
    service_1_16_8  unique_nonzero_owner_384  1
    service_1_16_8  service_visit_def_1261  1
    service_1_16_8  free_load_conservation_1262  7
    service_1_16_9  unique_nonzero_owner_385  1
    service_1_16_9  service_visit_def_1261  1
    service_1_16_9  free_load_conservation_1262  8
    service_1_16_10  unique_nonzero_owner_386  1
    service_1_16_10  service_visit_def_1261  1
    service_1_16_10  free_load_conservation_1262  9
    service_1_16_11  unique_nonzero_owner_387  1
    service_1_16_11  service_visit_def_1261  1
    service_1_16_11  free_load_conservation_1262  10
    service_1_16_12  unique_nonzero_owner_388  1
    service_1_16_12  service_visit_def_1261  1
    service_1_16_12  free_load_conservation_1262  11
    service_2_16_0  unique_nonzero_owner_377  1
    service_2_16_0  service_visit_def_1633  1
    service_2_16_0  free_load_conservation_1634  -1
    service_2_16_0  original_T_including_depot_unload_1656  120
    service_2_16_2  unique_nonzero_owner_378  1
    service_2_16_2  service_visit_def_1633  1
    service_2_16_2  free_load_conservation_1634  1
    service_2_16_3  unique_nonzero_owner_379  1
    service_2_16_3  service_visit_def_1633  1
    service_2_16_3  free_load_conservation_1634  2
    service_2_16_4  unique_nonzero_owner_380  1
    service_2_16_4  service_visit_def_1633  1
    service_2_16_4  free_load_conservation_1634  3
    service_2_16_5  unique_nonzero_owner_381  1
    service_2_16_5  service_visit_def_1633  1
    service_2_16_5  free_load_conservation_1634  4
    service_2_16_6  unique_nonzero_owner_382  1
    service_2_16_6  service_visit_def_1633  1
    service_2_16_6  free_load_conservation_1634  5
    service_2_16_7  unique_nonzero_owner_383  1
    service_2_16_7  service_visit_def_1633  1
    service_2_16_7  free_load_conservation_1634  6
    service_2_16_8  unique_nonzero_owner_384  1
    service_2_16_8  service_visit_def_1633  1
    service_2_16_8  free_load_conservation_1634  7
    service_2_16_9  unique_nonzero_owner_385  1
    service_2_16_9  service_visit_def_1633  1
    service_2_16_9  free_load_conservation_1634  8
    service_2_16_10  unique_nonzero_owner_386  1
    service_2_16_10  service_visit_def_1633  1
    service_2_16_10  free_load_conservation_1634  9
    service_2_16_11  unique_nonzero_owner_387  1
    service_2_16_11  service_visit_def_1633  1
    service_2_16_11  free_load_conservation_1634  10
    service_2_16_12  unique_nonzero_owner_388  1
    service_2_16_12  service_visit_def_1633  1
    service_2_16_12  free_load_conservation_1634  11
    service_0_5_0  unique_nonzero_owner_389  1
    service_0_5_0  service_visit_def_838  1
    service_0_5_0  free_load_conservation_839  -2
    service_0_5_0  original_T_including_depot_unload_856  240
    service_0_5_1  unique_nonzero_owner_390  1
    service_0_5_1  service_visit_def_838  1
    service_0_5_1  free_load_conservation_839  -1
    service_0_5_1  original_T_including_depot_unload_856  120
    service_0_5_3  unique_nonzero_owner_391  1
    service_0_5_3  service_visit_def_838  1
    service_0_5_3  free_load_conservation_839  1
    service_0_5_4  unique_nonzero_owner_392  1
    service_0_5_4  service_visit_def_838  1
    service_0_5_4  free_load_conservation_839  2
    service_0_5_5  unique_nonzero_owner_393  1
    service_0_5_5  service_visit_def_838  1
    service_0_5_5  free_load_conservation_839  3
    service_0_5_6  unique_nonzero_owner_394  1
    service_0_5_6  service_visit_def_838  1
    service_0_5_6  free_load_conservation_839  4
    service_0_5_7  unique_nonzero_owner_395  1
    service_0_5_7  service_visit_def_838  1
    service_0_5_7  free_load_conservation_839  5
    service_0_5_8  unique_nonzero_owner_396  1
    service_0_5_8  service_visit_def_838  1
    service_0_5_8  free_load_conservation_839  6
    service_0_5_9  unique_nonzero_owner_397  1
    service_0_5_9  service_visit_def_838  1
    service_0_5_9  free_load_conservation_839  7
    service_0_5_10  unique_nonzero_owner_398  1
    service_0_5_10  service_visit_def_838  1
    service_0_5_10  free_load_conservation_839  8
    service_0_5_11  unique_nonzero_owner_399  1
    service_0_5_11  service_visit_def_838  1
    service_0_5_11  free_load_conservation_839  9
    service_0_5_12  unique_nonzero_owner_400  1
    service_0_5_12  service_visit_def_838  1
    service_0_5_12  free_load_conservation_839  10
    service_0_5_13  unique_nonzero_owner_401  1
    service_0_5_13  service_visit_def_838  1
    service_0_5_13  free_load_conservation_839  11
    service_0_5_14  unique_nonzero_owner_402  1
    service_0_5_14  service_visit_def_838  1
    service_0_5_14  free_load_conservation_839  12
    service_0_5_15  unique_nonzero_owner_403  1
    service_0_5_15  service_visit_def_838  1
    service_0_5_15  free_load_conservation_839  13
    service_0_5_16  unique_nonzero_owner_404  1
    service_0_5_16  service_visit_def_838  1
    service_0_5_16  free_load_conservation_839  14
    service_1_5_0  unique_nonzero_owner_389  1
    service_1_5_0  service_visit_def_1267  1
    service_1_5_0  free_load_conservation_1268  -2
    service_1_5_0  original_T_including_depot_unload_1285  240
    service_1_5_1  unique_nonzero_owner_390  1
    service_1_5_1  service_visit_def_1267  1
    service_1_5_1  free_load_conservation_1268  -1
    service_1_5_1  original_T_including_depot_unload_1285  120
    service_1_5_3  unique_nonzero_owner_391  1
    service_1_5_3  service_visit_def_1267  1
    service_1_5_3  free_load_conservation_1268  1
    service_1_5_4  unique_nonzero_owner_392  1
    service_1_5_4  service_visit_def_1267  1
    service_1_5_4  free_load_conservation_1268  2
    service_1_5_5  unique_nonzero_owner_393  1
    service_1_5_5  service_visit_def_1267  1
    service_1_5_5  free_load_conservation_1268  3
    service_1_5_6  unique_nonzero_owner_394  1
    service_1_5_6  service_visit_def_1267  1
    service_1_5_6  free_load_conservation_1268  4
    service_1_5_7  unique_nonzero_owner_395  1
    service_1_5_7  service_visit_def_1267  1
    service_1_5_7  free_load_conservation_1268  5
    service_1_5_8  unique_nonzero_owner_396  1
    service_1_5_8  service_visit_def_1267  1
    service_1_5_8  free_load_conservation_1268  6
    service_1_5_9  unique_nonzero_owner_397  1
    service_1_5_9  service_visit_def_1267  1
    service_1_5_9  free_load_conservation_1268  7
    service_1_5_10  unique_nonzero_owner_398  1
    service_1_5_10  service_visit_def_1267  1
    service_1_5_10  free_load_conservation_1268  8
    service_1_5_11  unique_nonzero_owner_399  1
    service_1_5_11  service_visit_def_1267  1
    service_1_5_11  free_load_conservation_1268  9
    service_1_5_12  unique_nonzero_owner_400  1
    service_1_5_12  service_visit_def_1267  1
    service_1_5_12  free_load_conservation_1268  10
    service_1_5_13  unique_nonzero_owner_401  1
    service_1_5_13  service_visit_def_1267  1
    service_1_5_13  free_load_conservation_1268  11
    service_1_5_14  unique_nonzero_owner_402  1
    service_1_5_14  service_visit_def_1267  1
    service_1_5_14  free_load_conservation_1268  12
    service_1_5_15  unique_nonzero_owner_403  1
    service_1_5_15  service_visit_def_1267  1
    service_1_5_15  free_load_conservation_1268  13
    service_1_5_16  unique_nonzero_owner_404  1
    service_1_5_16  service_visit_def_1267  1
    service_1_5_16  free_load_conservation_1268  14
    service_2_5_0  unique_nonzero_owner_389  1
    service_2_5_0  service_visit_def_1639  1
    service_2_5_0  free_load_conservation_1640  -2
    service_2_5_0  original_T_including_depot_unload_1656  240
    service_2_5_1  unique_nonzero_owner_390  1
    service_2_5_1  service_visit_def_1639  1
    service_2_5_1  free_load_conservation_1640  -1
    service_2_5_1  original_T_including_depot_unload_1656  120
    service_2_5_3  unique_nonzero_owner_391  1
    service_2_5_3  service_visit_def_1639  1
    service_2_5_3  free_load_conservation_1640  1
    service_2_5_4  unique_nonzero_owner_392  1
    service_2_5_4  service_visit_def_1639  1
    service_2_5_4  free_load_conservation_1640  2
    service_2_5_5  unique_nonzero_owner_393  1
    service_2_5_5  service_visit_def_1639  1
    service_2_5_5  free_load_conservation_1640  3
    service_2_5_6  unique_nonzero_owner_394  1
    service_2_5_6  service_visit_def_1639  1
    service_2_5_6  free_load_conservation_1640  4
    service_2_5_7  unique_nonzero_owner_395  1
    service_2_5_7  service_visit_def_1639  1
    service_2_5_7  free_load_conservation_1640  5
    service_2_5_8  unique_nonzero_owner_396  1
    service_2_5_8  service_visit_def_1639  1
    service_2_5_8  free_load_conservation_1640  6
    service_2_5_9  unique_nonzero_owner_397  1
    service_2_5_9  service_visit_def_1639  1
    service_2_5_9  free_load_conservation_1640  7
    service_2_5_10  unique_nonzero_owner_398  1
    service_2_5_10  service_visit_def_1639  1
    service_2_5_10  free_load_conservation_1640  8
    service_2_5_11  unique_nonzero_owner_399  1
    service_2_5_11  service_visit_def_1639  1
    service_2_5_11  free_load_conservation_1640  9
    service_2_5_12  unique_nonzero_owner_400  1
    service_2_5_12  service_visit_def_1639  1
    service_2_5_12  free_load_conservation_1640  10
    service_2_5_13  unique_nonzero_owner_401  1
    service_2_5_13  service_visit_def_1639  1
    service_2_5_13  free_load_conservation_1640  11
    service_2_5_14  unique_nonzero_owner_402  1
    service_2_5_14  service_visit_def_1639  1
    service_2_5_14  free_load_conservation_1640  12
    service_2_5_15  unique_nonzero_owner_403  1
    service_2_5_15  service_visit_def_1639  1
    service_2_5_15  free_load_conservation_1640  13
    service_2_5_16  unique_nonzero_owner_404  1
    service_2_5_16  service_visit_def_1639  1
    service_2_5_16  free_load_conservation_1640  14
    service_0_26_1  unique_nonzero_owner_405  1
    service_0_26_1  service_visit_def_844  1
    service_0_26_1  free_load_conservation_845  1
    service_0_26_2  unique_nonzero_owner_406  1
    service_0_26_2  service_visit_def_844  1
    service_0_26_2  free_load_conservation_845  2
    service_0_26_3  unique_nonzero_owner_407  1
    service_0_26_3  service_visit_def_844  1
    service_0_26_3  free_load_conservation_845  3
    service_0_26_4  unique_nonzero_owner_408  1
    service_0_26_4  service_visit_def_844  1
    service_0_26_4  free_load_conservation_845  4
    service_0_26_5  unique_nonzero_owner_409  1
    service_0_26_5  service_visit_def_844  1
    service_0_26_5  free_load_conservation_845  5
    service_0_26_6  unique_nonzero_owner_410  1
    service_0_26_6  service_visit_def_844  1
    service_0_26_6  free_load_conservation_845  6
    service_0_26_7  unique_nonzero_owner_411  1
    service_0_26_7  service_visit_def_844  1
    service_0_26_7  free_load_conservation_845  7
    service_0_26_8  unique_nonzero_owner_412  1
    service_0_26_8  service_visit_def_844  1
    service_0_26_8  free_load_conservation_845  8
    service_1_26_1  unique_nonzero_owner_405  1
    service_1_26_1  service_visit_def_1273  1
    service_1_26_1  free_load_conservation_1274  1
    service_1_26_2  unique_nonzero_owner_406  1
    service_1_26_2  service_visit_def_1273  1
    service_1_26_2  free_load_conservation_1274  2
    service_1_26_3  unique_nonzero_owner_407  1
    service_1_26_3  service_visit_def_1273  1
    service_1_26_3  free_load_conservation_1274  3
    service_1_26_4  unique_nonzero_owner_408  1
    service_1_26_4  service_visit_def_1273  1
    service_1_26_4  free_load_conservation_1274  4
    service_1_26_5  unique_nonzero_owner_409  1
    service_1_26_5  service_visit_def_1273  1
    service_1_26_5  free_load_conservation_1274  5
    service_1_26_6  unique_nonzero_owner_410  1
    service_1_26_6  service_visit_def_1273  1
    service_1_26_6  free_load_conservation_1274  6
    service_1_26_7  unique_nonzero_owner_411  1
    service_1_26_7  service_visit_def_1273  1
    service_1_26_7  free_load_conservation_1274  7
    service_1_26_8  unique_nonzero_owner_412  1
    service_1_26_8  service_visit_def_1273  1
    service_1_26_8  free_load_conservation_1274  8
    service_2_26_1  unique_nonzero_owner_405  1
    service_2_26_1  service_visit_def_1645  1
    service_2_26_1  free_load_conservation_1646  1
    service_2_26_2  unique_nonzero_owner_406  1
    service_2_26_2  service_visit_def_1645  1
    service_2_26_2  free_load_conservation_1646  2
    service_2_26_3  unique_nonzero_owner_407  1
    service_2_26_3  service_visit_def_1645  1
    service_2_26_3  free_load_conservation_1646  3
    service_2_26_4  unique_nonzero_owner_408  1
    service_2_26_4  service_visit_def_1645  1
    service_2_26_4  free_load_conservation_1646  4
    service_2_26_5  unique_nonzero_owner_409  1
    service_2_26_5  service_visit_def_1645  1
    service_2_26_5  free_load_conservation_1646  5
    service_2_26_6  unique_nonzero_owner_410  1
    service_2_26_6  service_visit_def_1645  1
    service_2_26_6  free_load_conservation_1646  6
    service_2_26_7  unique_nonzero_owner_411  1
    service_2_26_7  service_visit_def_1645  1
    service_2_26_7  free_load_conservation_1646  7
    service_2_26_8  unique_nonzero_owner_412  1
    service_2_26_8  service_visit_def_1645  1
    service_2_26_8  free_load_conservation_1646  8
    service_0_14_0  unique_nonzero_owner_413  1
    service_0_14_0  service_visit_def_850  1
    service_0_14_0  free_load_conservation_851  -2
    service_0_14_0  original_T_including_depot_unload_856  240
    service_0_14_1  unique_nonzero_owner_414  1
    service_0_14_1  service_visit_def_850  1
    service_0_14_1  free_load_conservation_851  -1
    service_0_14_1  original_T_including_depot_unload_856  120
    service_0_14_3  unique_nonzero_owner_415  1
    service_0_14_3  service_visit_def_850  1
    service_0_14_3  free_load_conservation_851  1
    service_0_14_4  unique_nonzero_owner_416  1
    service_0_14_4  service_visit_def_850  1
    service_0_14_4  free_load_conservation_851  2
    service_0_14_5  unique_nonzero_owner_417  1
    service_0_14_5  service_visit_def_850  1
    service_0_14_5  free_load_conservation_851  3
    service_0_14_6  unique_nonzero_owner_418  1
    service_0_14_6  service_visit_def_850  1
    service_0_14_6  free_load_conservation_851  4
    service_0_14_7  unique_nonzero_owner_419  1
    service_0_14_7  service_visit_def_850  1
    service_0_14_7  free_load_conservation_851  5
    service_0_14_8  unique_nonzero_owner_420  1
    service_0_14_8  service_visit_def_850  1
    service_0_14_8  free_load_conservation_851  6
    service_0_14_9  unique_nonzero_owner_421  1
    service_0_14_9  service_visit_def_850  1
    service_0_14_9  free_load_conservation_851  7
    service_0_14_10  unique_nonzero_owner_422  1
    service_0_14_10  service_visit_def_850  1
    service_0_14_10  free_load_conservation_851  8
    service_0_14_11  unique_nonzero_owner_423  1
    service_0_14_11  service_visit_def_850  1
    service_0_14_11  free_load_conservation_851  9
    service_0_14_12  unique_nonzero_owner_424  1
    service_0_14_12  service_visit_def_850  1
    service_0_14_12  free_load_conservation_851  10
    service_0_14_13  unique_nonzero_owner_425  1
    service_0_14_13  service_visit_def_850  1
    service_0_14_13  free_load_conservation_851  11
    service_0_14_14  unique_nonzero_owner_426  1
    service_0_14_14  service_visit_def_850  1
    service_0_14_14  free_load_conservation_851  12
    service_0_14_15  unique_nonzero_owner_427  1
    service_0_14_15  service_visit_def_850  1
    service_0_14_15  free_load_conservation_851  13
    service_1_14_0  unique_nonzero_owner_413  1
    service_1_14_0  service_visit_def_1279  1
    service_1_14_0  free_load_conservation_1280  -2
    service_1_14_0  original_T_including_depot_unload_1285  240
    service_1_14_1  unique_nonzero_owner_414  1
    service_1_14_1  service_visit_def_1279  1
    service_1_14_1  free_load_conservation_1280  -1
    service_1_14_1  original_T_including_depot_unload_1285  120
    service_1_14_3  unique_nonzero_owner_415  1
    service_1_14_3  service_visit_def_1279  1
    service_1_14_3  free_load_conservation_1280  1
    service_1_14_4  unique_nonzero_owner_416  1
    service_1_14_4  service_visit_def_1279  1
    service_1_14_4  free_load_conservation_1280  2
    service_1_14_5  unique_nonzero_owner_417  1
    service_1_14_5  service_visit_def_1279  1
    service_1_14_5  free_load_conservation_1280  3
    service_1_14_6  unique_nonzero_owner_418  1
    service_1_14_6  service_visit_def_1279  1
    service_1_14_6  free_load_conservation_1280  4
    service_1_14_7  unique_nonzero_owner_419  1
    service_1_14_7  service_visit_def_1279  1
    service_1_14_7  free_load_conservation_1280  5
    service_1_14_8  unique_nonzero_owner_420  1
    service_1_14_8  service_visit_def_1279  1
    service_1_14_8  free_load_conservation_1280  6
    service_1_14_9  unique_nonzero_owner_421  1
    service_1_14_9  service_visit_def_1279  1
    service_1_14_9  free_load_conservation_1280  7
    service_1_14_10  unique_nonzero_owner_422  1
    service_1_14_10  service_visit_def_1279  1
    service_1_14_10  free_load_conservation_1280  8
    service_1_14_11  unique_nonzero_owner_423  1
    service_1_14_11  service_visit_def_1279  1
    service_1_14_11  free_load_conservation_1280  9
    service_1_14_12  unique_nonzero_owner_424  1
    service_1_14_12  service_visit_def_1279  1
    service_1_14_12  free_load_conservation_1280  10
    service_1_14_13  unique_nonzero_owner_425  1
    service_1_14_13  service_visit_def_1279  1
    service_1_14_13  free_load_conservation_1280  11
    service_1_14_14  unique_nonzero_owner_426  1
    service_1_14_14  service_visit_def_1279  1
    service_1_14_14  free_load_conservation_1280  12
    service_1_14_15  unique_nonzero_owner_427  1
    service_1_14_15  service_visit_def_1279  1
    service_1_14_15  free_load_conservation_1280  13
    service_2_14_0  unique_nonzero_owner_413  1
    service_2_14_0  service_visit_def_1651  1
    service_2_14_0  free_load_conservation_1652  -2
    service_2_14_0  original_T_including_depot_unload_1656  240
    service_2_14_1  unique_nonzero_owner_414  1
    service_2_14_1  service_visit_def_1651  1
    service_2_14_1  free_load_conservation_1652  -1
    service_2_14_1  original_T_including_depot_unload_1656  120
    service_2_14_3  unique_nonzero_owner_415  1
    service_2_14_3  service_visit_def_1651  1
    service_2_14_3  free_load_conservation_1652  1
    service_2_14_4  unique_nonzero_owner_416  1
    service_2_14_4  service_visit_def_1651  1
    service_2_14_4  free_load_conservation_1652  2
    service_2_14_5  unique_nonzero_owner_417  1
    service_2_14_5  service_visit_def_1651  1
    service_2_14_5  free_load_conservation_1652  3
    service_2_14_6  unique_nonzero_owner_418  1
    service_2_14_6  service_visit_def_1651  1
    service_2_14_6  free_load_conservation_1652  4
    service_2_14_7  unique_nonzero_owner_419  1
    service_2_14_7  service_visit_def_1651  1
    service_2_14_7  free_load_conservation_1652  5
    service_2_14_8  unique_nonzero_owner_420  1
    service_2_14_8  service_visit_def_1651  1
    service_2_14_8  free_load_conservation_1652  6
    service_2_14_9  unique_nonzero_owner_421  1
    service_2_14_9  service_visit_def_1651  1
    service_2_14_9  free_load_conservation_1652  7
    service_2_14_10  unique_nonzero_owner_422  1
    service_2_14_10  service_visit_def_1651  1
    service_2_14_10  free_load_conservation_1652  8
    service_2_14_11  unique_nonzero_owner_423  1
    service_2_14_11  service_visit_def_1651  1
    service_2_14_11  free_load_conservation_1652  9
    service_2_14_12  unique_nonzero_owner_424  1
    service_2_14_12  service_visit_def_1651  1
    service_2_14_12  free_load_conservation_1652  10
    service_2_14_13  unique_nonzero_owner_425  1
    service_2_14_13  service_visit_def_1651  1
    service_2_14_13  free_load_conservation_1652  11
    service_2_14_14  unique_nonzero_owner_426  1
    service_2_14_14  service_visit_def_1651  1
    service_2_14_14  free_load_conservation_1652  12
    service_2_14_15  unique_nonzero_owner_427  1
    service_2_14_15  service_visit_def_1651  1
    service_2_14_15  free_load_conservation_1652  13
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_769  -1
    visit_0_1  in_degree_770  -1
    visit_0_1  order_active_lb_771  -1
    visit_0_1  order_active_ub_772  -13
    order_0_1  connected_order_arc_444  -1
    order_0_1  connected_order_arc_446  -1
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_450  -1
    order_0_1  connected_order_arc_452  -1
    order_0_1  connected_order_arc_454  -1
    order_0_1  connected_order_arc_456  -1
    order_0_1  connected_order_arc_458  -1
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_462  -1
    order_0_1  connected_order_arc_464  -1
    order_0_1  connected_order_arc_466  -1
    order_0_1  connected_order_arc_469  1
    order_0_1  connected_order_arc_494  1
    order_0_1  connected_order_arc_519  1
    order_0_1  connected_order_arc_544  1
    order_0_1  connected_order_arc_569  1
    order_0_1  connected_order_arc_594  1
    order_0_1  connected_order_arc_619  1
    order_0_1  connected_order_arc_644  1
    order_0_1  connected_order_arc_669  1
    order_0_1  connected_order_arc_694  1
    order_0_1  connected_order_arc_719  1
    order_0_1  connected_order_arc_744  1
    order_0_1  order_active_lb_771  1
    order_0_1  order_active_ub_772  1
    order_0_1  fixed_segment_relative_order_852  -1
    visit_0_2  out_degree_776  -1
    visit_0_2  in_degree_777  -1
    visit_0_2  order_active_lb_778  -1
    visit_0_2  order_active_ub_779  -13
    order_0_2  connected_order_arc_444  1
    order_0_2  connected_order_arc_469  -1
    order_0_2  connected_order_arc_471  -1
    order_0_2  connected_order_arc_473  -1
    order_0_2  connected_order_arc_475  -1
    order_0_2  connected_order_arc_477  -1
    order_0_2  connected_order_arc_479  -1
    order_0_2  connected_order_arc_481  -1
    order_0_2  connected_order_arc_483  -1
    order_0_2  connected_order_arc_485  -1
    order_0_2  connected_order_arc_487  -1
    order_0_2  connected_order_arc_489  -1
    order_0_2  connected_order_arc_491  -1
    order_0_2  connected_order_arc_496  1
    order_0_2  connected_order_arc_521  1
    order_0_2  connected_order_arc_546  1
    order_0_2  connected_order_arc_571  1
    order_0_2  connected_order_arc_596  1
    order_0_2  connected_order_arc_621  1
    order_0_2  connected_order_arc_646  1
    order_0_2  connected_order_arc_671  1
    order_0_2  connected_order_arc_696  1
    order_0_2  connected_order_arc_721  1
    order_0_2  connected_order_arc_746  1
    order_0_2  order_active_lb_778  1
    order_0_2  order_active_ub_779  1
    order_0_2  fixed_segment_relative_order_852  1
    order_0_2  fixed_segment_relative_order_853  -1
    visit_0_3  out_degree_783  -1
    visit_0_3  in_degree_784  -1
    visit_0_3  order_active_lb_785  -1
    visit_0_3  order_active_ub_786  -13
    order_0_3  connected_order_arc_446  1
    order_0_3  connected_order_arc_471  1
    order_0_3  connected_order_arc_494  -1
    order_0_3  connected_order_arc_496  -1
    order_0_3  connected_order_arc_498  -1
    order_0_3  connected_order_arc_500  -1
    order_0_3  connected_order_arc_502  -1
    order_0_3  connected_order_arc_504  -1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_508  -1
    order_0_3  connected_order_arc_510  -1
    order_0_3  connected_order_arc_512  -1
    order_0_3  connected_order_arc_514  -1
    order_0_3  connected_order_arc_516  -1
    order_0_3  connected_order_arc_523  1
    order_0_3  connected_order_arc_548  1
    order_0_3  connected_order_arc_573  1
    order_0_3  connected_order_arc_598  1
    order_0_3  connected_order_arc_623  1
    order_0_3  connected_order_arc_648  1
    order_0_3  connected_order_arc_673  1
    order_0_3  connected_order_arc_698  1
    order_0_3  connected_order_arc_723  1
    order_0_3  connected_order_arc_748  1
    order_0_3  order_active_lb_785  1
    order_0_3  order_active_ub_786  1
    order_0_3  fixed_segment_relative_order_853  1
    order_0_3  fixed_segment_relative_order_854  -1
    visit_0_4  out_degree_790  -1
    visit_0_4  in_degree_791  -1
    visit_0_4  order_active_lb_792  -1
    visit_0_4  order_active_ub_793  -13
    order_0_4  connected_order_arc_448  1
    order_0_4  connected_order_arc_473  1
    order_0_4  connected_order_arc_498  1
    order_0_4  connected_order_arc_519  -1
    order_0_4  connected_order_arc_521  -1
    order_0_4  connected_order_arc_523  -1
    order_0_4  connected_order_arc_525  -1
    order_0_4  connected_order_arc_527  -1
    order_0_4  connected_order_arc_529  -1
    order_0_4  connected_order_arc_531  -1
    order_0_4  connected_order_arc_533  -1
    order_0_4  connected_order_arc_535  -1
    order_0_4  connected_order_arc_537  -1
    order_0_4  connected_order_arc_539  -1
    order_0_4  connected_order_arc_541  -1
    order_0_4  connected_order_arc_550  1
    order_0_4  connected_order_arc_575  1
    order_0_4  connected_order_arc_600  1
    order_0_4  connected_order_arc_625  1
    order_0_4  connected_order_arc_650  1
    order_0_4  connected_order_arc_675  1
    order_0_4  connected_order_arc_700  1
    order_0_4  connected_order_arc_725  1
    order_0_4  connected_order_arc_750  1
    order_0_4  order_active_lb_792  1
    order_0_4  order_active_ub_793  1
    order_0_4  fixed_segment_relative_order_854  1
    order_0_4  fixed_segment_relative_order_855  -1
    visit_0_5  out_degree_797  -1
    visit_0_5  in_degree_798  -1
    visit_0_5  order_active_lb_799  -1
    visit_0_5  order_active_ub_800  -13
    order_0_5  connected_order_arc_450  1
    order_0_5  connected_order_arc_475  1
    order_0_5  connected_order_arc_500  1
    order_0_5  connected_order_arc_525  1
    order_0_5  connected_order_arc_544  -1
    order_0_5  connected_order_arc_546  -1
    order_0_5  connected_order_arc_548  -1
    order_0_5  connected_order_arc_550  -1
    order_0_5  connected_order_arc_552  -1
    order_0_5  connected_order_arc_554  -1
    order_0_5  connected_order_arc_556  -1
    order_0_5  connected_order_arc_558  -1
    order_0_5  connected_order_arc_560  -1
    order_0_5  connected_order_arc_562  -1
    order_0_5  connected_order_arc_564  -1
    order_0_5  connected_order_arc_566  -1
    order_0_5  connected_order_arc_577  1
    order_0_5  connected_order_arc_602  1
    order_0_5  connected_order_arc_627  1
    order_0_5  connected_order_arc_652  1
    order_0_5  connected_order_arc_677  1
    order_0_5  connected_order_arc_702  1
    order_0_5  connected_order_arc_727  1
    order_0_5  connected_order_arc_752  1
    order_0_5  order_active_lb_799  1
    order_0_5  order_active_ub_800  1
    order_0_5  fixed_segment_relative_order_855  1
    visit_0_15  out_degree_804  -1
    visit_0_15  in_degree_805  -1
    visit_0_15  order_active_lb_806  -1
    visit_0_15  order_active_ub_807  -13
    visit_0_15  service_visit_def_808  -1
    order_0_15  connected_order_arc_452  1
    order_0_15  connected_order_arc_477  1
    order_0_15  connected_order_arc_502  1
    order_0_15  connected_order_arc_527  1
    order_0_15  connected_order_arc_552  1
    order_0_15  connected_order_arc_569  -1
    order_0_15  connected_order_arc_571  -1
    order_0_15  connected_order_arc_573  -1
    order_0_15  connected_order_arc_575  -1
    order_0_15  connected_order_arc_577  -1
    order_0_15  connected_order_arc_579  -1
    order_0_15  connected_order_arc_581  -1
    order_0_15  connected_order_arc_583  -1
    order_0_15  connected_order_arc_585  -1
    order_0_15  connected_order_arc_587  -1
    order_0_15  connected_order_arc_589  -1
    order_0_15  connected_order_arc_591  -1
    order_0_15  connected_order_arc_604  1
    order_0_15  connected_order_arc_629  1
    order_0_15  connected_order_arc_654  1
    order_0_15  connected_order_arc_679  1
    order_0_15  connected_order_arc_704  1
    order_0_15  connected_order_arc_729  1
    order_0_15  connected_order_arc_754  1
    order_0_15  order_active_lb_806  1
    order_0_15  order_active_ub_807  1
    visit_0_16  out_degree_810  -1
    visit_0_16  in_degree_811  -1
    visit_0_16  order_active_lb_812  -1
    visit_0_16  order_active_ub_813  -13
    visit_0_16  service_visit_def_814  -1
    order_0_16  connected_order_arc_454  1
    order_0_16  connected_order_arc_479  1
    order_0_16  connected_order_arc_504  1
    order_0_16  connected_order_arc_529  1
    order_0_16  connected_order_arc_554  1
    order_0_16  connected_order_arc_579  1
    order_0_16  connected_order_arc_594  -1
    order_0_16  connected_order_arc_596  -1
    order_0_16  connected_order_arc_598  -1
    order_0_16  connected_order_arc_600  -1
    order_0_16  connected_order_arc_602  -1
    order_0_16  connected_order_arc_604  -1
    order_0_16  connected_order_arc_606  -1
    order_0_16  connected_order_arc_608  -1
    order_0_16  connected_order_arc_610  -1
    order_0_16  connected_order_arc_612  -1
    order_0_16  connected_order_arc_614  -1
    order_0_16  connected_order_arc_616  -1
    order_0_16  connected_order_arc_631  1
    order_0_16  connected_order_arc_656  1
    order_0_16  connected_order_arc_681  1
    order_0_16  connected_order_arc_706  1
    order_0_16  connected_order_arc_731  1
    order_0_16  connected_order_arc_756  1
    order_0_16  order_active_lb_812  1
    order_0_16  order_active_ub_813  1
    visit_0_17  out_degree_816  -1
    visit_0_17  in_degree_817  -1
    visit_0_17  order_active_lb_818  -1
    visit_0_17  order_active_ub_819  -13
    visit_0_17  service_visit_def_820  -1
    order_0_17  connected_order_arc_456  1
    order_0_17  connected_order_arc_481  1
    order_0_17  connected_order_arc_506  1
    order_0_17  connected_order_arc_531  1
    order_0_17  connected_order_arc_556  1
    order_0_17  connected_order_arc_581  1
    order_0_17  connected_order_arc_606  1
    order_0_17  connected_order_arc_619  -1
    order_0_17  connected_order_arc_621  -1
    order_0_17  connected_order_arc_623  -1
    order_0_17  connected_order_arc_625  -1
    order_0_17  connected_order_arc_627  -1
    order_0_17  connected_order_arc_629  -1
    order_0_17  connected_order_arc_631  -1
    order_0_17  connected_order_arc_633  -1
    order_0_17  connected_order_arc_635  -1
    order_0_17  connected_order_arc_637  -1
    order_0_17  connected_order_arc_639  -1
    order_0_17  connected_order_arc_641  -1
    order_0_17  connected_order_arc_658  1
    order_0_17  connected_order_arc_683  1
    order_0_17  connected_order_arc_708  1
    order_0_17  connected_order_arc_733  1
    order_0_17  connected_order_arc_758  1
    order_0_17  order_active_lb_818  1
    order_0_17  order_active_ub_819  1
    visit_0_18  out_degree_822  -1
    visit_0_18  in_degree_823  -1
    visit_0_18  order_active_lb_824  -1
    visit_0_18  order_active_ub_825  -13
    visit_0_18  service_visit_def_826  -1
    order_0_18  connected_order_arc_458  1
    order_0_18  connected_order_arc_483  1
    order_0_18  connected_order_arc_508  1
    order_0_18  connected_order_arc_533  1
    order_0_18  connected_order_arc_558  1
    order_0_18  connected_order_arc_583  1
    order_0_18  connected_order_arc_608  1
    order_0_18  connected_order_arc_633  1
    order_0_18  connected_order_arc_644  -1
    order_0_18  connected_order_arc_646  -1
    order_0_18  connected_order_arc_648  -1
    order_0_18  connected_order_arc_650  -1
    order_0_18  connected_order_arc_652  -1
    order_0_18  connected_order_arc_654  -1
    order_0_18  connected_order_arc_656  -1
    order_0_18  connected_order_arc_658  -1
    order_0_18  connected_order_arc_660  -1
    order_0_18  connected_order_arc_662  -1
    order_0_18  connected_order_arc_664  -1
    order_0_18  connected_order_arc_666  -1
    order_0_18  connected_order_arc_685  1
    order_0_18  connected_order_arc_710  1
    order_0_18  connected_order_arc_735  1
    order_0_18  connected_order_arc_760  1
    order_0_18  order_active_lb_824  1
    order_0_18  order_active_ub_825  1
    visit_0_19  out_degree_828  -1
    visit_0_19  in_degree_829  -1
    visit_0_19  order_active_lb_830  -1
    visit_0_19  order_active_ub_831  -13
    visit_0_19  service_visit_def_832  -1
    order_0_19  connected_order_arc_460  1
    order_0_19  connected_order_arc_485  1
    order_0_19  connected_order_arc_510  1
    order_0_19  connected_order_arc_535  1
    order_0_19  connected_order_arc_560  1
    order_0_19  connected_order_arc_585  1
    order_0_19  connected_order_arc_610  1
    order_0_19  connected_order_arc_635  1
    order_0_19  connected_order_arc_660  1
    order_0_19  connected_order_arc_669  -1
    order_0_19  connected_order_arc_671  -1
    order_0_19  connected_order_arc_673  -1
    order_0_19  connected_order_arc_675  -1
    order_0_19  connected_order_arc_677  -1
    order_0_19  connected_order_arc_679  -1
    order_0_19  connected_order_arc_681  -1
    order_0_19  connected_order_arc_683  -1
    order_0_19  connected_order_arc_685  -1
    order_0_19  connected_order_arc_687  -1
    order_0_19  connected_order_arc_689  -1
    order_0_19  connected_order_arc_691  -1
    order_0_19  connected_order_arc_712  1
    order_0_19  connected_order_arc_737  1
    order_0_19  connected_order_arc_762  1
    order_0_19  order_active_lb_830  1
    order_0_19  order_active_ub_831  1
    visit_0_20  out_degree_834  -1
    visit_0_20  in_degree_835  -1
    visit_0_20  order_active_lb_836  -1
    visit_0_20  order_active_ub_837  -13
    visit_0_20  service_visit_def_838  -1
    order_0_20  connected_order_arc_462  1
    order_0_20  connected_order_arc_487  1
    order_0_20  connected_order_arc_512  1
    order_0_20  connected_order_arc_537  1
    order_0_20  connected_order_arc_562  1
    order_0_20  connected_order_arc_587  1
    order_0_20  connected_order_arc_612  1
    order_0_20  connected_order_arc_637  1
    order_0_20  connected_order_arc_662  1
    order_0_20  connected_order_arc_687  1
    order_0_20  connected_order_arc_694  -1
    order_0_20  connected_order_arc_696  -1
    order_0_20  connected_order_arc_698  -1
    order_0_20  connected_order_arc_700  -1
    order_0_20  connected_order_arc_702  -1
    order_0_20  connected_order_arc_704  -1
    order_0_20  connected_order_arc_706  -1
    order_0_20  connected_order_arc_708  -1
    order_0_20  connected_order_arc_710  -1
    order_0_20  connected_order_arc_712  -1
    order_0_20  connected_order_arc_714  -1
    order_0_20  connected_order_arc_716  -1
    order_0_20  connected_order_arc_739  1
    order_0_20  connected_order_arc_764  1
    order_0_20  order_active_lb_836  1
    order_0_20  order_active_ub_837  1
    visit_0_21  out_degree_840  -1
    visit_0_21  in_degree_841  -1
    visit_0_21  order_active_lb_842  -1
    visit_0_21  order_active_ub_843  -13
    visit_0_21  service_visit_def_844  -1
    order_0_21  connected_order_arc_464  1
    order_0_21  connected_order_arc_489  1
    order_0_21  connected_order_arc_514  1
    order_0_21  connected_order_arc_539  1
    order_0_21  connected_order_arc_564  1
    order_0_21  connected_order_arc_589  1
    order_0_21  connected_order_arc_614  1
    order_0_21  connected_order_arc_639  1
    order_0_21  connected_order_arc_664  1
    order_0_21  connected_order_arc_689  1
    order_0_21  connected_order_arc_714  1
    order_0_21  connected_order_arc_719  -1
    order_0_21  connected_order_arc_721  -1
    order_0_21  connected_order_arc_723  -1
    order_0_21  connected_order_arc_725  -1
    order_0_21  connected_order_arc_727  -1
    order_0_21  connected_order_arc_729  -1
    order_0_21  connected_order_arc_731  -1
    order_0_21  connected_order_arc_733  -1
    order_0_21  connected_order_arc_735  -1
    order_0_21  connected_order_arc_737  -1
    order_0_21  connected_order_arc_739  -1
    order_0_21  connected_order_arc_741  -1
    order_0_21  connected_order_arc_766  1
    order_0_21  order_active_lb_842  1
    order_0_21  order_active_ub_843  1
    visit_0_22  out_degree_846  -1
    visit_0_22  in_degree_847  -1
    visit_0_22  order_active_lb_848  -1
    visit_0_22  order_active_ub_849  -13
    visit_0_22  service_visit_def_850  -1
    order_0_22  connected_order_arc_466  1
    order_0_22  connected_order_arc_491  1
    order_0_22  connected_order_arc_516  1
    order_0_22  connected_order_arc_541  1
    order_0_22  connected_order_arc_566  1
    order_0_22  connected_order_arc_591  1
    order_0_22  connected_order_arc_616  1
    order_0_22  connected_order_arc_641  1
    order_0_22  connected_order_arc_666  1
    order_0_22  connected_order_arc_691  1
    order_0_22  connected_order_arc_716  1
    order_0_22  connected_order_arc_741  1
    order_0_22  connected_order_arc_744  -1
    order_0_22  connected_order_arc_746  -1
    order_0_22  connected_order_arc_748  -1
    order_0_22  connected_order_arc_750  -1
    order_0_22  connected_order_arc_752  -1
    order_0_22  connected_order_arc_754  -1
    order_0_22  connected_order_arc_756  -1
    order_0_22  connected_order_arc_758  -1
    order_0_22  connected_order_arc_760  -1
    order_0_22  connected_order_arc_762  -1
    order_0_22  connected_order_arc_764  -1
    order_0_22  connected_order_arc_766  -1
    order_0_22  order_active_lb_848  1
    order_0_22  order_active_ub_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_428  -20
    arc_0_0_0  depot_departure_or_bypass_767  1
    arc_0_0_0  depot_return_or_bypass_768  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_428  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_429  -20
    arc_0_0_1  depot_departure_or_bypass_767  1
    arc_0_0_1  in_degree_770  1
    arc_0_0_1  original_T_including_depot_unload_856  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_429  1
    load_0_0_1  segment_load_conservation_773  -1
    load_0_0_1  segment_prefix_lb_774  1
    load_0_0_1  segment_prefix_ub_775  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_430  -20
    arc_0_0_2  depot_departure_or_bypass_767  1
    arc_0_0_2  in_degree_777  1
    arc_0_0_2  original_T_including_depot_unload_856  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_430  1
    load_0_0_2  segment_load_conservation_780  -1
    load_0_0_2  segment_prefix_lb_781  1
    load_0_0_2  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_431  -20
    arc_0_0_3  depot_departure_or_bypass_767  1
    arc_0_0_3  in_degree_784  1
    arc_0_0_3  original_T_including_depot_unload_856  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_431  1
    load_0_0_3  segment_load_conservation_787  -1
    load_0_0_3  segment_prefix_lb_788  1
    load_0_0_3  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_432  -20
    arc_0_0_4  depot_departure_or_bypass_767  1
    arc_0_0_4  in_degree_791  1
    arc_0_0_4  original_T_including_depot_unload_856  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_432  1
    load_0_0_4  segment_load_conservation_794  -1
    load_0_0_4  segment_prefix_lb_795  1
    load_0_0_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_433  -20
    arc_0_0_5  depot_departure_or_bypass_767  1
    arc_0_0_5  in_degree_798  1
    arc_0_0_5  original_T_including_depot_unload_856  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_433  1
    load_0_0_5  segment_load_conservation_801  -1
    load_0_0_5  segment_prefix_lb_802  1
    load_0_0_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_434  -20
    arc_0_0_15  depot_departure_or_bypass_767  1
    arc_0_0_15  in_degree_805  1
    arc_0_0_15  original_T_including_depot_unload_856  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_434  1
    load_0_0_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_435  -20
    arc_0_0_16  depot_departure_or_bypass_767  1
    arc_0_0_16  in_degree_811  1
    arc_0_0_16  original_T_including_depot_unload_856  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_435  1
    load_0_0_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_436  -20
    arc_0_0_17  depot_departure_or_bypass_767  1
    arc_0_0_17  in_degree_817  1
    arc_0_0_17  original_T_including_depot_unload_856  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_436  1
    load_0_0_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_437  -20
    arc_0_0_18  depot_departure_or_bypass_767  1
    arc_0_0_18  in_degree_823  1
    arc_0_0_18  original_T_including_depot_unload_856  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_437  1
    load_0_0_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_438  -20
    arc_0_0_19  depot_departure_or_bypass_767  1
    arc_0_0_19  in_degree_829  1
    arc_0_0_19  original_T_including_depot_unload_856  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_438  1
    load_0_0_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_439  -20
    arc_0_0_20  depot_departure_or_bypass_767  1
    arc_0_0_20  in_degree_835  1
    arc_0_0_20  original_T_including_depot_unload_856  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_439  1
    load_0_0_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_440  -20
    arc_0_0_21  depot_departure_or_bypass_767  1
    arc_0_0_21  in_degree_841  1
    arc_0_0_21  original_T_including_depot_unload_856  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_440  1
    load_0_0_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_441  -20
    arc_0_0_22  depot_departure_or_bypass_767  1
    arc_0_0_22  in_degree_847  1
    arc_0_0_22  original_T_including_depot_unload_856  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_441  1
    load_0_0_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_442  -20
    arc_0_1_0  depot_return_or_bypass_768  1
    arc_0_1_0  out_degree_769  1
    arc_0_1_0  original_T_including_depot_unload_856  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_442  1
    load_0_1_0  segment_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_443  -20
    arc_0_1_2  connected_order_arc_444  -14
    arc_0_1_2  out_degree_769  1
    arc_0_1_2  in_degree_777  1
    arc_0_1_2  original_T_including_depot_unload_856  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_443  1
    load_0_1_2  segment_load_conservation_773  1
    load_0_1_2  segment_load_conservation_780  -1
    load_0_1_2  segment_prefix_lb_781  1
    load_0_1_2  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_445  -20
    arc_0_1_3  connected_order_arc_446  -14
    arc_0_1_3  out_degree_769  1
    arc_0_1_3  in_degree_784  1
    arc_0_1_3  original_T_including_depot_unload_856  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_445  1
    load_0_1_3  segment_load_conservation_773  1
    load_0_1_3  segment_load_conservation_787  -1
    load_0_1_3  segment_prefix_lb_788  1
    load_0_1_3  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_447  -20
    arc_0_1_4  connected_order_arc_448  -14
    arc_0_1_4  out_degree_769  1
    arc_0_1_4  in_degree_791  1
    arc_0_1_4  original_T_including_depot_unload_856  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_447  1
    load_0_1_4  segment_load_conservation_773  1
    load_0_1_4  segment_load_conservation_794  -1
    load_0_1_4  segment_prefix_lb_795  1
    load_0_1_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_449  -20
    arc_0_1_5  connected_order_arc_450  -14
    arc_0_1_5  out_degree_769  1
    arc_0_1_5  in_degree_798  1
    arc_0_1_5  original_T_including_depot_unload_856  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_449  1
    load_0_1_5  segment_load_conservation_773  1
    load_0_1_5  segment_load_conservation_801  -1
    load_0_1_5  segment_prefix_lb_802  1
    load_0_1_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_451  -20
    arc_0_1_15  connected_order_arc_452  -14
    arc_0_1_15  out_degree_769  1
    arc_0_1_15  in_degree_805  1
    arc_0_1_15  original_T_including_depot_unload_856  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_451  1
    load_0_1_15  segment_load_conservation_773  1
    load_0_1_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_453  -20
    arc_0_1_16  connected_order_arc_454  -14
    arc_0_1_16  out_degree_769  1
    arc_0_1_16  in_degree_811  1
    arc_0_1_16  original_T_including_depot_unload_856  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_453  1
    load_0_1_16  segment_load_conservation_773  1
    load_0_1_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_455  -20
    arc_0_1_17  connected_order_arc_456  -14
    arc_0_1_17  out_degree_769  1
    arc_0_1_17  in_degree_817  1
    arc_0_1_17  original_T_including_depot_unload_856  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_455  1
    load_0_1_17  segment_load_conservation_773  1
    load_0_1_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_457  -20
    arc_0_1_18  connected_order_arc_458  -14
    arc_0_1_18  out_degree_769  1
    arc_0_1_18  in_degree_823  1
    arc_0_1_18  original_T_including_depot_unload_856  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_457  1
    load_0_1_18  segment_load_conservation_773  1
    load_0_1_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_459  -20
    arc_0_1_19  connected_order_arc_460  -14
    arc_0_1_19  out_degree_769  1
    arc_0_1_19  in_degree_829  1
    arc_0_1_19  original_T_including_depot_unload_856  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_459  1
    load_0_1_19  segment_load_conservation_773  1
    load_0_1_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_461  -20
    arc_0_1_20  connected_order_arc_462  -14
    arc_0_1_20  out_degree_769  1
    arc_0_1_20  in_degree_835  1
    arc_0_1_20  original_T_including_depot_unload_856  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_461  1
    load_0_1_20  segment_load_conservation_773  1
    load_0_1_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_463  -20
    arc_0_1_21  connected_order_arc_464  -14
    arc_0_1_21  out_degree_769  1
    arc_0_1_21  in_degree_841  1
    arc_0_1_21  original_T_including_depot_unload_856  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_463  1
    load_0_1_21  segment_load_conservation_773  1
    load_0_1_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_465  -20
    arc_0_1_22  connected_order_arc_466  -14
    arc_0_1_22  out_degree_769  1
    arc_0_1_22  in_degree_847  1
    arc_0_1_22  original_T_including_depot_unload_856  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_465  1
    load_0_1_22  segment_load_conservation_773  1
    load_0_1_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_467  -20
    arc_0_2_0  depot_return_or_bypass_768  1
    arc_0_2_0  out_degree_776  1
    arc_0_2_0  original_T_including_depot_unload_856  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_467  1
    load_0_2_0  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_468  -20
    arc_0_2_1  connected_order_arc_469  -14
    arc_0_2_1  in_degree_770  1
    arc_0_2_1  out_degree_776  1
    arc_0_2_1  original_T_including_depot_unload_856  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_468  1
    load_0_2_1  segment_load_conservation_773  -1
    load_0_2_1  segment_prefix_lb_774  1
    load_0_2_1  segment_prefix_ub_775  1
    load_0_2_1  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_470  -20
    arc_0_2_3  connected_order_arc_471  -14
    arc_0_2_3  out_degree_776  1
    arc_0_2_3  in_degree_784  1
    arc_0_2_3  original_T_including_depot_unload_856  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_470  1
    load_0_2_3  segment_load_conservation_780  1
    load_0_2_3  segment_load_conservation_787  -1
    load_0_2_3  segment_prefix_lb_788  1
    load_0_2_3  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_472  -20
    arc_0_2_4  connected_order_arc_473  -14
    arc_0_2_4  out_degree_776  1
    arc_0_2_4  in_degree_791  1
    arc_0_2_4  original_T_including_depot_unload_856  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_472  1
    load_0_2_4  segment_load_conservation_780  1
    load_0_2_4  segment_load_conservation_794  -1
    load_0_2_4  segment_prefix_lb_795  1
    load_0_2_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_474  -20
    arc_0_2_5  connected_order_arc_475  -14
    arc_0_2_5  out_degree_776  1
    arc_0_2_5  in_degree_798  1
    arc_0_2_5  original_T_including_depot_unload_856  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_474  1
    load_0_2_5  segment_load_conservation_780  1
    load_0_2_5  segment_load_conservation_801  -1
    load_0_2_5  segment_prefix_lb_802  1
    load_0_2_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_476  -20
    arc_0_2_15  connected_order_arc_477  -14
    arc_0_2_15  out_degree_776  1
    arc_0_2_15  in_degree_805  1
    arc_0_2_15  original_T_including_depot_unload_856  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_476  1
    load_0_2_15  segment_load_conservation_780  1
    load_0_2_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_478  -20
    arc_0_2_16  connected_order_arc_479  -14
    arc_0_2_16  out_degree_776  1
    arc_0_2_16  in_degree_811  1
    arc_0_2_16  original_T_including_depot_unload_856  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_478  1
    load_0_2_16  segment_load_conservation_780  1
    load_0_2_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_480  -20
    arc_0_2_17  connected_order_arc_481  -14
    arc_0_2_17  out_degree_776  1
    arc_0_2_17  in_degree_817  1
    arc_0_2_17  original_T_including_depot_unload_856  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_480  1
    load_0_2_17  segment_load_conservation_780  1
    load_0_2_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_482  -20
    arc_0_2_18  connected_order_arc_483  -14
    arc_0_2_18  out_degree_776  1
    arc_0_2_18  in_degree_823  1
    arc_0_2_18  original_T_including_depot_unload_856  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_482  1
    load_0_2_18  segment_load_conservation_780  1
    load_0_2_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_484  -20
    arc_0_2_19  connected_order_arc_485  -14
    arc_0_2_19  out_degree_776  1
    arc_0_2_19  in_degree_829  1
    arc_0_2_19  original_T_including_depot_unload_856  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_484  1
    load_0_2_19  segment_load_conservation_780  1
    load_0_2_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_486  -20
    arc_0_2_20  connected_order_arc_487  -14
    arc_0_2_20  out_degree_776  1
    arc_0_2_20  in_degree_835  1
    arc_0_2_20  original_T_including_depot_unload_856  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_486  1
    load_0_2_20  segment_load_conservation_780  1
    load_0_2_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_488  -20
    arc_0_2_21  connected_order_arc_489  -14
    arc_0_2_21  out_degree_776  1
    arc_0_2_21  in_degree_841  1
    arc_0_2_21  original_T_including_depot_unload_856  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_488  1
    load_0_2_21  segment_load_conservation_780  1
    load_0_2_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_490  -20
    arc_0_2_22  connected_order_arc_491  -14
    arc_0_2_22  out_degree_776  1
    arc_0_2_22  in_degree_847  1
    arc_0_2_22  original_T_including_depot_unload_856  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_490  1
    load_0_2_22  segment_load_conservation_780  1
    load_0_2_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_492  -20
    arc_0_3_0  depot_return_or_bypass_768  1
    arc_0_3_0  out_degree_783  1
    arc_0_3_0  original_T_including_depot_unload_856  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_492  1
    load_0_3_0  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_493  -20
    arc_0_3_1  connected_order_arc_494  -14
    arc_0_3_1  in_degree_770  1
    arc_0_3_1  out_degree_783  1
    arc_0_3_1  original_T_including_depot_unload_856  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_493  1
    load_0_3_1  segment_load_conservation_773  -1
    load_0_3_1  segment_prefix_lb_774  1
    load_0_3_1  segment_prefix_ub_775  1
    load_0_3_1  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_495  -20
    arc_0_3_2  connected_order_arc_496  -14
    arc_0_3_2  in_degree_777  1
    arc_0_3_2  out_degree_783  1
    arc_0_3_2  original_T_including_depot_unload_856  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_495  1
    load_0_3_2  segment_load_conservation_780  -1
    load_0_3_2  segment_prefix_lb_781  1
    load_0_3_2  segment_prefix_ub_782  1
    load_0_3_2  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_497  -20
    arc_0_3_4  connected_order_arc_498  -14
    arc_0_3_4  out_degree_783  1
    arc_0_3_4  in_degree_791  1
    arc_0_3_4  original_T_including_depot_unload_856  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_497  1
    load_0_3_4  segment_load_conservation_787  1
    load_0_3_4  segment_load_conservation_794  -1
    load_0_3_4  segment_prefix_lb_795  1
    load_0_3_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_499  -20
    arc_0_3_5  connected_order_arc_500  -14
    arc_0_3_5  out_degree_783  1
    arc_0_3_5  in_degree_798  1
    arc_0_3_5  original_T_including_depot_unload_856  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_499  1
    load_0_3_5  segment_load_conservation_787  1
    load_0_3_5  segment_load_conservation_801  -1
    load_0_3_5  segment_prefix_lb_802  1
    load_0_3_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_501  -20
    arc_0_3_15  connected_order_arc_502  -14
    arc_0_3_15  out_degree_783  1
    arc_0_3_15  in_degree_805  1
    arc_0_3_15  original_T_including_depot_unload_856  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_501  1
    load_0_3_15  segment_load_conservation_787  1
    load_0_3_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_503  -20
    arc_0_3_16  connected_order_arc_504  -14
    arc_0_3_16  out_degree_783  1
    arc_0_3_16  in_degree_811  1
    arc_0_3_16  original_T_including_depot_unload_856  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_503  1
    load_0_3_16  segment_load_conservation_787  1
    load_0_3_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_505  -20
    arc_0_3_17  connected_order_arc_506  -14
    arc_0_3_17  out_degree_783  1
    arc_0_3_17  in_degree_817  1
    arc_0_3_17  original_T_including_depot_unload_856  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_505  1
    load_0_3_17  segment_load_conservation_787  1
    load_0_3_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_507  -20
    arc_0_3_18  connected_order_arc_508  -14
    arc_0_3_18  out_degree_783  1
    arc_0_3_18  in_degree_823  1
    arc_0_3_18  original_T_including_depot_unload_856  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_507  1
    load_0_3_18  segment_load_conservation_787  1
    load_0_3_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_509  -20
    arc_0_3_19  connected_order_arc_510  -14
    arc_0_3_19  out_degree_783  1
    arc_0_3_19  in_degree_829  1
    arc_0_3_19  original_T_including_depot_unload_856  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_509  1
    load_0_3_19  segment_load_conservation_787  1
    load_0_3_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_511  -20
    arc_0_3_20  connected_order_arc_512  -14
    arc_0_3_20  out_degree_783  1
    arc_0_3_20  in_degree_835  1
    arc_0_3_20  original_T_including_depot_unload_856  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_511  1
    load_0_3_20  segment_load_conservation_787  1
    load_0_3_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_513  -20
    arc_0_3_21  connected_order_arc_514  -14
    arc_0_3_21  out_degree_783  1
    arc_0_3_21  in_degree_841  1
    arc_0_3_21  original_T_including_depot_unload_856  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_513  1
    load_0_3_21  segment_load_conservation_787  1
    load_0_3_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_515  -20
    arc_0_3_22  connected_order_arc_516  -14
    arc_0_3_22  out_degree_783  1
    arc_0_3_22  in_degree_847  1
    arc_0_3_22  original_T_including_depot_unload_856  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_515  1
    load_0_3_22  segment_load_conservation_787  1
    load_0_3_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_517  -20
    arc_0_4_0  depot_return_or_bypass_768  1
    arc_0_4_0  out_degree_790  1
    arc_0_4_0  original_T_including_depot_unload_856  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_517  1
    load_0_4_0  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_518  -20
    arc_0_4_1  connected_order_arc_519  -14
    arc_0_4_1  in_degree_770  1
    arc_0_4_1  out_degree_790  1
    arc_0_4_1  original_T_including_depot_unload_856  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_518  1
    load_0_4_1  segment_load_conservation_773  -1
    load_0_4_1  segment_prefix_lb_774  1
    load_0_4_1  segment_prefix_ub_775  1
    load_0_4_1  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_520  -20
    arc_0_4_2  connected_order_arc_521  -14
    arc_0_4_2  in_degree_777  1
    arc_0_4_2  out_degree_790  1
    arc_0_4_2  original_T_including_depot_unload_856  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_520  1
    load_0_4_2  segment_load_conservation_780  -1
    load_0_4_2  segment_prefix_lb_781  1
    load_0_4_2  segment_prefix_ub_782  1
    load_0_4_2  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_522  -20
    arc_0_4_3  connected_order_arc_523  -14
    arc_0_4_3  in_degree_784  1
    arc_0_4_3  out_degree_790  1
    arc_0_4_3  original_T_including_depot_unload_856  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_522  1
    load_0_4_3  segment_load_conservation_787  -1
    load_0_4_3  segment_prefix_lb_788  1
    load_0_4_3  segment_prefix_ub_789  1
    load_0_4_3  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_524  -20
    arc_0_4_5  connected_order_arc_525  -14
    arc_0_4_5  out_degree_790  1
    arc_0_4_5  in_degree_798  1
    arc_0_4_5  original_T_including_depot_unload_856  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_524  1
    load_0_4_5  segment_load_conservation_794  1
    load_0_4_5  segment_load_conservation_801  -1
    load_0_4_5  segment_prefix_lb_802  1
    load_0_4_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_526  -20
    arc_0_4_15  connected_order_arc_527  -14
    arc_0_4_15  out_degree_790  1
    arc_0_4_15  in_degree_805  1
    arc_0_4_15  original_T_including_depot_unload_856  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_526  1
    load_0_4_15  segment_load_conservation_794  1
    load_0_4_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_528  -20
    arc_0_4_16  connected_order_arc_529  -14
    arc_0_4_16  out_degree_790  1
    arc_0_4_16  in_degree_811  1
    arc_0_4_16  original_T_including_depot_unload_856  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_528  1
    load_0_4_16  segment_load_conservation_794  1
    load_0_4_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_530  -20
    arc_0_4_17  connected_order_arc_531  -14
    arc_0_4_17  out_degree_790  1
    arc_0_4_17  in_degree_817  1
    arc_0_4_17  original_T_including_depot_unload_856  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_530  1
    load_0_4_17  segment_load_conservation_794  1
    load_0_4_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_532  -20
    arc_0_4_18  connected_order_arc_533  -14
    arc_0_4_18  out_degree_790  1
    arc_0_4_18  in_degree_823  1
    arc_0_4_18  original_T_including_depot_unload_856  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_532  1
    load_0_4_18  segment_load_conservation_794  1
    load_0_4_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_534  -20
    arc_0_4_19  connected_order_arc_535  -14
    arc_0_4_19  out_degree_790  1
    arc_0_4_19  in_degree_829  1
    arc_0_4_19  original_T_including_depot_unload_856  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_534  1
    load_0_4_19  segment_load_conservation_794  1
    load_0_4_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_536  -20
    arc_0_4_20  connected_order_arc_537  -14
    arc_0_4_20  out_degree_790  1
    arc_0_4_20  in_degree_835  1
    arc_0_4_20  original_T_including_depot_unload_856  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_536  1
    load_0_4_20  segment_load_conservation_794  1
    load_0_4_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_538  -20
    arc_0_4_21  connected_order_arc_539  -14
    arc_0_4_21  out_degree_790  1
    arc_0_4_21  in_degree_841  1
    arc_0_4_21  original_T_including_depot_unload_856  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_538  1
    load_0_4_21  segment_load_conservation_794  1
    load_0_4_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_540  -20
    arc_0_4_22  connected_order_arc_541  -14
    arc_0_4_22  out_degree_790  1
    arc_0_4_22  in_degree_847  1
    arc_0_4_22  original_T_including_depot_unload_856  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_540  1
    load_0_4_22  segment_load_conservation_794  1
    load_0_4_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_542  -20
    arc_0_5_0  depot_return_or_bypass_768  1
    arc_0_5_0  out_degree_797  1
    arc_0_5_0  original_T_including_depot_unload_856  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_542  1
    load_0_5_0  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_543  -20
    arc_0_5_1  connected_order_arc_544  -14
    arc_0_5_1  in_degree_770  1
    arc_0_5_1  out_degree_797  1
    arc_0_5_1  original_T_including_depot_unload_856  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_543  1
    load_0_5_1  segment_load_conservation_773  -1
    load_0_5_1  segment_prefix_lb_774  1
    load_0_5_1  segment_prefix_ub_775  1
    load_0_5_1  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_545  -20
    arc_0_5_2  connected_order_arc_546  -14
    arc_0_5_2  in_degree_777  1
    arc_0_5_2  out_degree_797  1
    arc_0_5_2  original_T_including_depot_unload_856  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_545  1
    load_0_5_2  segment_load_conservation_780  -1
    load_0_5_2  segment_prefix_lb_781  1
    load_0_5_2  segment_prefix_ub_782  1
    load_0_5_2  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_547  -20
    arc_0_5_3  connected_order_arc_548  -14
    arc_0_5_3  in_degree_784  1
    arc_0_5_3  out_degree_797  1
    arc_0_5_3  original_T_including_depot_unload_856  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_547  1
    load_0_5_3  segment_load_conservation_787  -1
    load_0_5_3  segment_prefix_lb_788  1
    load_0_5_3  segment_prefix_ub_789  1
    load_0_5_3  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_549  -20
    arc_0_5_4  connected_order_arc_550  -14
    arc_0_5_4  in_degree_791  1
    arc_0_5_4  out_degree_797  1
    arc_0_5_4  original_T_including_depot_unload_856  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_549  1
    load_0_5_4  segment_load_conservation_794  -1
    load_0_5_4  segment_prefix_lb_795  1
    load_0_5_4  segment_prefix_ub_796  1
    load_0_5_4  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_551  -20
    arc_0_5_15  connected_order_arc_552  -14
    arc_0_5_15  out_degree_797  1
    arc_0_5_15  in_degree_805  1
    arc_0_5_15  original_T_including_depot_unload_856  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_551  1
    load_0_5_15  segment_load_conservation_801  1
    load_0_5_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_553  -20
    arc_0_5_16  connected_order_arc_554  -14
    arc_0_5_16  out_degree_797  1
    arc_0_5_16  in_degree_811  1
    arc_0_5_16  original_T_including_depot_unload_856  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_553  1
    load_0_5_16  segment_load_conservation_801  1
    load_0_5_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_555  -20
    arc_0_5_17  connected_order_arc_556  -14
    arc_0_5_17  out_degree_797  1
    arc_0_5_17  in_degree_817  1
    arc_0_5_17  original_T_including_depot_unload_856  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_555  1
    load_0_5_17  segment_load_conservation_801  1
    load_0_5_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_557  -20
    arc_0_5_18  connected_order_arc_558  -14
    arc_0_5_18  out_degree_797  1
    arc_0_5_18  in_degree_823  1
    arc_0_5_18  original_T_including_depot_unload_856  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_557  1
    load_0_5_18  segment_load_conservation_801  1
    load_0_5_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_559  -20
    arc_0_5_19  connected_order_arc_560  -14
    arc_0_5_19  out_degree_797  1
    arc_0_5_19  in_degree_829  1
    arc_0_5_19  original_T_including_depot_unload_856  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_559  1
    load_0_5_19  segment_load_conservation_801  1
    load_0_5_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_561  -20
    arc_0_5_20  connected_order_arc_562  -14
    arc_0_5_20  out_degree_797  1
    arc_0_5_20  in_degree_835  1
    arc_0_5_20  original_T_including_depot_unload_856  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_561  1
    load_0_5_20  segment_load_conservation_801  1
    load_0_5_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_563  -20
    arc_0_5_21  connected_order_arc_564  -14
    arc_0_5_21  out_degree_797  1
    arc_0_5_21  in_degree_841  1
    arc_0_5_21  original_T_including_depot_unload_856  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_563  1
    load_0_5_21  segment_load_conservation_801  1
    load_0_5_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_565  -20
    arc_0_5_22  connected_order_arc_566  -14
    arc_0_5_22  out_degree_797  1
    arc_0_5_22  in_degree_847  1
    arc_0_5_22  original_T_including_depot_unload_856  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_565  1
    load_0_5_22  segment_load_conservation_801  1
    load_0_5_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_567  -20
    arc_0_15_0  depot_return_or_bypass_768  1
    arc_0_15_0  out_degree_804  1
    arc_0_15_0  original_T_including_depot_unload_856  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_567  1
    load_0_15_0  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_568  -20
    arc_0_15_1  connected_order_arc_569  -14
    arc_0_15_1  in_degree_770  1
    arc_0_15_1  out_degree_804  1
    arc_0_15_1  original_T_including_depot_unload_856  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_568  1
    load_0_15_1  segment_load_conservation_773  -1
    load_0_15_1  segment_prefix_lb_774  1
    load_0_15_1  segment_prefix_ub_775  1
    load_0_15_1  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_570  -20
    arc_0_15_2  connected_order_arc_571  -14
    arc_0_15_2  in_degree_777  1
    arc_0_15_2  out_degree_804  1
    arc_0_15_2  original_T_including_depot_unload_856  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_570  1
    load_0_15_2  segment_load_conservation_780  -1
    load_0_15_2  segment_prefix_lb_781  1
    load_0_15_2  segment_prefix_ub_782  1
    load_0_15_2  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_572  -20
    arc_0_15_3  connected_order_arc_573  -14
    arc_0_15_3  in_degree_784  1
    arc_0_15_3  out_degree_804  1
    arc_0_15_3  original_T_including_depot_unload_856  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_572  1
    load_0_15_3  segment_load_conservation_787  -1
    load_0_15_3  segment_prefix_lb_788  1
    load_0_15_3  segment_prefix_ub_789  1
    load_0_15_3  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_574  -20
    arc_0_15_4  connected_order_arc_575  -14
    arc_0_15_4  in_degree_791  1
    arc_0_15_4  out_degree_804  1
    arc_0_15_4  original_T_including_depot_unload_856  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_574  1
    load_0_15_4  segment_load_conservation_794  -1
    load_0_15_4  segment_prefix_lb_795  1
    load_0_15_4  segment_prefix_ub_796  1
    load_0_15_4  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_576  -20
    arc_0_15_5  connected_order_arc_577  -14
    arc_0_15_5  in_degree_798  1
    arc_0_15_5  out_degree_804  1
    arc_0_15_5  original_T_including_depot_unload_856  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_576  1
    load_0_15_5  segment_load_conservation_801  -1
    load_0_15_5  segment_prefix_lb_802  1
    load_0_15_5  segment_prefix_ub_803  1
    load_0_15_5  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_578  -20
    arc_0_15_16  connected_order_arc_579  -14
    arc_0_15_16  out_degree_804  1
    arc_0_15_16  in_degree_811  1
    arc_0_15_16  original_T_including_depot_unload_856  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_578  1
    load_0_15_16  free_load_conservation_809  1
    load_0_15_16  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_580  -20
    arc_0_15_17  connected_order_arc_581  -14
    arc_0_15_17  out_degree_804  1
    arc_0_15_17  in_degree_817  1
    arc_0_15_17  original_T_including_depot_unload_856  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_580  1
    load_0_15_17  free_load_conservation_809  1
    load_0_15_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_582  -20
    arc_0_15_18  connected_order_arc_583  -14
    arc_0_15_18  out_degree_804  1
    arc_0_15_18  in_degree_823  1
    arc_0_15_18  original_T_including_depot_unload_856  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_582  1
    load_0_15_18  free_load_conservation_809  1
    load_0_15_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_584  -20
    arc_0_15_19  connected_order_arc_585  -14
    arc_0_15_19  out_degree_804  1
    arc_0_15_19  in_degree_829  1
    arc_0_15_19  original_T_including_depot_unload_856  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_584  1
    load_0_15_19  free_load_conservation_809  1
    load_0_15_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_586  -20
    arc_0_15_20  connected_order_arc_587  -14
    arc_0_15_20  out_degree_804  1
    arc_0_15_20  in_degree_835  1
    arc_0_15_20  original_T_including_depot_unload_856  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_586  1
    load_0_15_20  free_load_conservation_809  1
    load_0_15_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_588  -20
    arc_0_15_21  connected_order_arc_589  -14
    arc_0_15_21  out_degree_804  1
    arc_0_15_21  in_degree_841  1
    arc_0_15_21  original_T_including_depot_unload_856  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_588  1
    load_0_15_21  free_load_conservation_809  1
    load_0_15_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_590  -20
    arc_0_15_22  connected_order_arc_591  -14
    arc_0_15_22  out_degree_804  1
    arc_0_15_22  in_degree_847  1
    arc_0_15_22  original_T_including_depot_unload_856  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_590  1
    load_0_15_22  free_load_conservation_809  1
    load_0_15_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_592  -20
    arc_0_16_0  depot_return_or_bypass_768  1
    arc_0_16_0  out_degree_810  1
    arc_0_16_0  original_T_including_depot_unload_856  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_592  1
    load_0_16_0  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_593  -20
    arc_0_16_1  connected_order_arc_594  -14
    arc_0_16_1  in_degree_770  1
    arc_0_16_1  out_degree_810  1
    arc_0_16_1  original_T_including_depot_unload_856  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_593  1
    load_0_16_1  segment_load_conservation_773  -1
    load_0_16_1  segment_prefix_lb_774  1
    load_0_16_1  segment_prefix_ub_775  1
    load_0_16_1  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_595  -20
    arc_0_16_2  connected_order_arc_596  -14
    arc_0_16_2  in_degree_777  1
    arc_0_16_2  out_degree_810  1
    arc_0_16_2  original_T_including_depot_unload_856  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_595  1
    load_0_16_2  segment_load_conservation_780  -1
    load_0_16_2  segment_prefix_lb_781  1
    load_0_16_2  segment_prefix_ub_782  1
    load_0_16_2  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_597  -20
    arc_0_16_3  connected_order_arc_598  -14
    arc_0_16_3  in_degree_784  1
    arc_0_16_3  out_degree_810  1
    arc_0_16_3  original_T_including_depot_unload_856  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_597  1
    load_0_16_3  segment_load_conservation_787  -1
    load_0_16_3  segment_prefix_lb_788  1
    load_0_16_3  segment_prefix_ub_789  1
    load_0_16_3  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_599  -20
    arc_0_16_4  connected_order_arc_600  -14
    arc_0_16_4  in_degree_791  1
    arc_0_16_4  out_degree_810  1
    arc_0_16_4  original_T_including_depot_unload_856  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_599  1
    load_0_16_4  segment_load_conservation_794  -1
    load_0_16_4  segment_prefix_lb_795  1
    load_0_16_4  segment_prefix_ub_796  1
    load_0_16_4  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_601  -20
    arc_0_16_5  connected_order_arc_602  -14
    arc_0_16_5  in_degree_798  1
    arc_0_16_5  out_degree_810  1
    arc_0_16_5  original_T_including_depot_unload_856  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_601  1
    load_0_16_5  segment_load_conservation_801  -1
    load_0_16_5  segment_prefix_lb_802  1
    load_0_16_5  segment_prefix_ub_803  1
    load_0_16_5  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_603  -20
    arc_0_16_15  connected_order_arc_604  -14
    arc_0_16_15  in_degree_805  1
    arc_0_16_15  out_degree_810  1
    arc_0_16_15  original_T_including_depot_unload_856  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_603  1
    load_0_16_15  free_load_conservation_809  -1
    load_0_16_15  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_605  -20
    arc_0_16_17  connected_order_arc_606  -14
    arc_0_16_17  out_degree_810  1
    arc_0_16_17  in_degree_817  1
    arc_0_16_17  original_T_including_depot_unload_856  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_605  1
    load_0_16_17  free_load_conservation_815  1
    load_0_16_17  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_607  -20
    arc_0_16_18  connected_order_arc_608  -14
    arc_0_16_18  out_degree_810  1
    arc_0_16_18  in_degree_823  1
    arc_0_16_18  original_T_including_depot_unload_856  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_607  1
    load_0_16_18  free_load_conservation_815  1
    load_0_16_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_609  -20
    arc_0_16_19  connected_order_arc_610  -14
    arc_0_16_19  out_degree_810  1
    arc_0_16_19  in_degree_829  1
    arc_0_16_19  original_T_including_depot_unload_856  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_609  1
    load_0_16_19  free_load_conservation_815  1
    load_0_16_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_611  -20
    arc_0_16_20  connected_order_arc_612  -14
    arc_0_16_20  out_degree_810  1
    arc_0_16_20  in_degree_835  1
    arc_0_16_20  original_T_including_depot_unload_856  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_611  1
    load_0_16_20  free_load_conservation_815  1
    load_0_16_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_613  -20
    arc_0_16_21  connected_order_arc_614  -14
    arc_0_16_21  out_degree_810  1
    arc_0_16_21  in_degree_841  1
    arc_0_16_21  original_T_including_depot_unload_856  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_613  1
    load_0_16_21  free_load_conservation_815  1
    load_0_16_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_615  -20
    arc_0_16_22  connected_order_arc_616  -14
    arc_0_16_22  out_degree_810  1
    arc_0_16_22  in_degree_847  1
    arc_0_16_22  original_T_including_depot_unload_856  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_615  1
    load_0_16_22  free_load_conservation_815  1
    load_0_16_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_617  -20
    arc_0_17_0  depot_return_or_bypass_768  1
    arc_0_17_0  out_degree_816  1
    arc_0_17_0  original_T_including_depot_unload_856  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_617  1
    load_0_17_0  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_618  -20
    arc_0_17_1  connected_order_arc_619  -14
    arc_0_17_1  in_degree_770  1
    arc_0_17_1  out_degree_816  1
    arc_0_17_1  original_T_including_depot_unload_856  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_618  1
    load_0_17_1  segment_load_conservation_773  -1
    load_0_17_1  segment_prefix_lb_774  1
    load_0_17_1  segment_prefix_ub_775  1
    load_0_17_1  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_620  -20
    arc_0_17_2  connected_order_arc_621  -14
    arc_0_17_2  in_degree_777  1
    arc_0_17_2  out_degree_816  1
    arc_0_17_2  original_T_including_depot_unload_856  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_620  1
    load_0_17_2  segment_load_conservation_780  -1
    load_0_17_2  segment_prefix_lb_781  1
    load_0_17_2  segment_prefix_ub_782  1
    load_0_17_2  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_622  -20
    arc_0_17_3  connected_order_arc_623  -14
    arc_0_17_3  in_degree_784  1
    arc_0_17_3  out_degree_816  1
    arc_0_17_3  original_T_including_depot_unload_856  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_622  1
    load_0_17_3  segment_load_conservation_787  -1
    load_0_17_3  segment_prefix_lb_788  1
    load_0_17_3  segment_prefix_ub_789  1
    load_0_17_3  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_624  -20
    arc_0_17_4  connected_order_arc_625  -14
    arc_0_17_4  in_degree_791  1
    arc_0_17_4  out_degree_816  1
    arc_0_17_4  original_T_including_depot_unload_856  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_624  1
    load_0_17_4  segment_load_conservation_794  -1
    load_0_17_4  segment_prefix_lb_795  1
    load_0_17_4  segment_prefix_ub_796  1
    load_0_17_4  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_626  -20
    arc_0_17_5  connected_order_arc_627  -14
    arc_0_17_5  in_degree_798  1
    arc_0_17_5  out_degree_816  1
    arc_0_17_5  original_T_including_depot_unload_856  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_626  1
    load_0_17_5  segment_load_conservation_801  -1
    load_0_17_5  segment_prefix_lb_802  1
    load_0_17_5  segment_prefix_ub_803  1
    load_0_17_5  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_628  -20
    arc_0_17_15  connected_order_arc_629  -14
    arc_0_17_15  in_degree_805  1
    arc_0_17_15  out_degree_816  1
    arc_0_17_15  original_T_including_depot_unload_856  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_628  1
    load_0_17_15  free_load_conservation_809  -1
    load_0_17_15  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_630  -20
    arc_0_17_16  connected_order_arc_631  -14
    arc_0_17_16  in_degree_811  1
    arc_0_17_16  out_degree_816  1
    arc_0_17_16  original_T_including_depot_unload_856  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_630  1
    load_0_17_16  free_load_conservation_815  -1
    load_0_17_16  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_632  -20
    arc_0_17_18  connected_order_arc_633  -14
    arc_0_17_18  out_degree_816  1
    arc_0_17_18  in_degree_823  1
    arc_0_17_18  original_T_including_depot_unload_856  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_632  1
    load_0_17_18  free_load_conservation_821  1
    load_0_17_18  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_634  -20
    arc_0_17_19  connected_order_arc_635  -14
    arc_0_17_19  out_degree_816  1
    arc_0_17_19  in_degree_829  1
    arc_0_17_19  original_T_including_depot_unload_856  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_634  1
    load_0_17_19  free_load_conservation_821  1
    load_0_17_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_636  -20
    arc_0_17_20  connected_order_arc_637  -14
    arc_0_17_20  out_degree_816  1
    arc_0_17_20  in_degree_835  1
    arc_0_17_20  original_T_including_depot_unload_856  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_636  1
    load_0_17_20  free_load_conservation_821  1
    load_0_17_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_638  -20
    arc_0_17_21  connected_order_arc_639  -14
    arc_0_17_21  out_degree_816  1
    arc_0_17_21  in_degree_841  1
    arc_0_17_21  original_T_including_depot_unload_856  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_638  1
    load_0_17_21  free_load_conservation_821  1
    load_0_17_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_640  -20
    arc_0_17_22  connected_order_arc_641  -14
    arc_0_17_22  out_degree_816  1
    arc_0_17_22  in_degree_847  1
    arc_0_17_22  original_T_including_depot_unload_856  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_640  1
    load_0_17_22  free_load_conservation_821  1
    load_0_17_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_642  -20
    arc_0_18_0  depot_return_or_bypass_768  1
    arc_0_18_0  out_degree_822  1
    arc_0_18_0  original_T_including_depot_unload_856  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_642  1
    load_0_18_0  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_643  -20
    arc_0_18_1  connected_order_arc_644  -14
    arc_0_18_1  in_degree_770  1
    arc_0_18_1  out_degree_822  1
    arc_0_18_1  original_T_including_depot_unload_856  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_643  1
    load_0_18_1  segment_load_conservation_773  -1
    load_0_18_1  segment_prefix_lb_774  1
    load_0_18_1  segment_prefix_ub_775  1
    load_0_18_1  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_645  -20
    arc_0_18_2  connected_order_arc_646  -14
    arc_0_18_2  in_degree_777  1
    arc_0_18_2  out_degree_822  1
    arc_0_18_2  original_T_including_depot_unload_856  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_645  1
    load_0_18_2  segment_load_conservation_780  -1
    load_0_18_2  segment_prefix_lb_781  1
    load_0_18_2  segment_prefix_ub_782  1
    load_0_18_2  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_647  -20
    arc_0_18_3  connected_order_arc_648  -14
    arc_0_18_3  in_degree_784  1
    arc_0_18_3  out_degree_822  1
    arc_0_18_3  original_T_including_depot_unload_856  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_647  1
    load_0_18_3  segment_load_conservation_787  -1
    load_0_18_3  segment_prefix_lb_788  1
    load_0_18_3  segment_prefix_ub_789  1
    load_0_18_3  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_649  -20
    arc_0_18_4  connected_order_arc_650  -14
    arc_0_18_4  in_degree_791  1
    arc_0_18_4  out_degree_822  1
    arc_0_18_4  original_T_including_depot_unload_856  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_649  1
    load_0_18_4  segment_load_conservation_794  -1
    load_0_18_4  segment_prefix_lb_795  1
    load_0_18_4  segment_prefix_ub_796  1
    load_0_18_4  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_651  -20
    arc_0_18_5  connected_order_arc_652  -14
    arc_0_18_5  in_degree_798  1
    arc_0_18_5  out_degree_822  1
    arc_0_18_5  original_T_including_depot_unload_856  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_651  1
    load_0_18_5  segment_load_conservation_801  -1
    load_0_18_5  segment_prefix_lb_802  1
    load_0_18_5  segment_prefix_ub_803  1
    load_0_18_5  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_653  -20
    arc_0_18_15  connected_order_arc_654  -14
    arc_0_18_15  in_degree_805  1
    arc_0_18_15  out_degree_822  1
    arc_0_18_15  original_T_including_depot_unload_856  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_653  1
    load_0_18_15  free_load_conservation_809  -1
    load_0_18_15  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_655  -20
    arc_0_18_16  connected_order_arc_656  -14
    arc_0_18_16  in_degree_811  1
    arc_0_18_16  out_degree_822  1
    arc_0_18_16  original_T_including_depot_unload_856  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_655  1
    load_0_18_16  free_load_conservation_815  -1
    load_0_18_16  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_657  -20
    arc_0_18_17  connected_order_arc_658  -14
    arc_0_18_17  in_degree_817  1
    arc_0_18_17  out_degree_822  1
    arc_0_18_17  original_T_including_depot_unload_856  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_657  1
    load_0_18_17  free_load_conservation_821  -1
    load_0_18_17  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_659  -20
    arc_0_18_19  connected_order_arc_660  -14
    arc_0_18_19  out_degree_822  1
    arc_0_18_19  in_degree_829  1
    arc_0_18_19  original_T_including_depot_unload_856  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_659  1
    load_0_18_19  free_load_conservation_827  1
    load_0_18_19  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_661  -20
    arc_0_18_20  connected_order_arc_662  -14
    arc_0_18_20  out_degree_822  1
    arc_0_18_20  in_degree_835  1
    arc_0_18_20  original_T_including_depot_unload_856  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_661  1
    load_0_18_20  free_load_conservation_827  1
    load_0_18_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_663  -20
    arc_0_18_21  connected_order_arc_664  -14
    arc_0_18_21  out_degree_822  1
    arc_0_18_21  in_degree_841  1
    arc_0_18_21  original_T_including_depot_unload_856  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_663  1
    load_0_18_21  free_load_conservation_827  1
    load_0_18_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_665  -20
    arc_0_18_22  connected_order_arc_666  -14
    arc_0_18_22  out_degree_822  1
    arc_0_18_22  in_degree_847  1
    arc_0_18_22  original_T_including_depot_unload_856  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_665  1
    load_0_18_22  free_load_conservation_827  1
    load_0_18_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_667  -20
    arc_0_19_0  depot_return_or_bypass_768  1
    arc_0_19_0  out_degree_828  1
    arc_0_19_0  original_T_including_depot_unload_856  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_667  1
    load_0_19_0  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_668  -20
    arc_0_19_1  connected_order_arc_669  -14
    arc_0_19_1  in_degree_770  1
    arc_0_19_1  out_degree_828  1
    arc_0_19_1  original_T_including_depot_unload_856  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_668  1
    load_0_19_1  segment_load_conservation_773  -1
    load_0_19_1  segment_prefix_lb_774  1
    load_0_19_1  segment_prefix_ub_775  1
    load_0_19_1  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_670  -20
    arc_0_19_2  connected_order_arc_671  -14
    arc_0_19_2  in_degree_777  1
    arc_0_19_2  out_degree_828  1
    arc_0_19_2  original_T_including_depot_unload_856  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_670  1
    load_0_19_2  segment_load_conservation_780  -1
    load_0_19_2  segment_prefix_lb_781  1
    load_0_19_2  segment_prefix_ub_782  1
    load_0_19_2  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_672  -20
    arc_0_19_3  connected_order_arc_673  -14
    arc_0_19_3  in_degree_784  1
    arc_0_19_3  out_degree_828  1
    arc_0_19_3  original_T_including_depot_unload_856  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_672  1
    load_0_19_3  segment_load_conservation_787  -1
    load_0_19_3  segment_prefix_lb_788  1
    load_0_19_3  segment_prefix_ub_789  1
    load_0_19_3  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_674  -20
    arc_0_19_4  connected_order_arc_675  -14
    arc_0_19_4  in_degree_791  1
    arc_0_19_4  out_degree_828  1
    arc_0_19_4  original_T_including_depot_unload_856  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_674  1
    load_0_19_4  segment_load_conservation_794  -1
    load_0_19_4  segment_prefix_lb_795  1
    load_0_19_4  segment_prefix_ub_796  1
    load_0_19_4  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_676  -20
    arc_0_19_5  connected_order_arc_677  -14
    arc_0_19_5  in_degree_798  1
    arc_0_19_5  out_degree_828  1
    arc_0_19_5  original_T_including_depot_unload_856  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_676  1
    load_0_19_5  segment_load_conservation_801  -1
    load_0_19_5  segment_prefix_lb_802  1
    load_0_19_5  segment_prefix_ub_803  1
    load_0_19_5  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_678  -20
    arc_0_19_15  connected_order_arc_679  -14
    arc_0_19_15  in_degree_805  1
    arc_0_19_15  out_degree_828  1
    arc_0_19_15  original_T_including_depot_unload_856  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_678  1
    load_0_19_15  free_load_conservation_809  -1
    load_0_19_15  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_680  -20
    arc_0_19_16  connected_order_arc_681  -14
    arc_0_19_16  in_degree_811  1
    arc_0_19_16  out_degree_828  1
    arc_0_19_16  original_T_including_depot_unload_856  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_680  1
    load_0_19_16  free_load_conservation_815  -1
    load_0_19_16  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_682  -20
    arc_0_19_17  connected_order_arc_683  -14
    arc_0_19_17  in_degree_817  1
    arc_0_19_17  out_degree_828  1
    arc_0_19_17  original_T_including_depot_unload_856  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_682  1
    load_0_19_17  free_load_conservation_821  -1
    load_0_19_17  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_684  -20
    arc_0_19_18  connected_order_arc_685  -14
    arc_0_19_18  in_degree_823  1
    arc_0_19_18  out_degree_828  1
    arc_0_19_18  original_T_including_depot_unload_856  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_684  1
    load_0_19_18  free_load_conservation_827  -1
    load_0_19_18  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_686  -20
    arc_0_19_20  connected_order_arc_687  -14
    arc_0_19_20  out_degree_828  1
    arc_0_19_20  in_degree_835  1
    arc_0_19_20  original_T_including_depot_unload_856  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_686  1
    load_0_19_20  free_load_conservation_833  1
    load_0_19_20  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_688  -20
    arc_0_19_21  connected_order_arc_689  -14
    arc_0_19_21  out_degree_828  1
    arc_0_19_21  in_degree_841  1
    arc_0_19_21  original_T_including_depot_unload_856  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_688  1
    load_0_19_21  free_load_conservation_833  1
    load_0_19_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_690  -20
    arc_0_19_22  connected_order_arc_691  -14
    arc_0_19_22  out_degree_828  1
    arc_0_19_22  in_degree_847  1
    arc_0_19_22  original_T_including_depot_unload_856  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_690  1
    load_0_19_22  free_load_conservation_833  1
    load_0_19_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_692  -20
    arc_0_20_0  depot_return_or_bypass_768  1
    arc_0_20_0  out_degree_834  1
    arc_0_20_0  original_T_including_depot_unload_856  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_692  1
    load_0_20_0  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_693  -20
    arc_0_20_1  connected_order_arc_694  -14
    arc_0_20_1  in_degree_770  1
    arc_0_20_1  out_degree_834  1
    arc_0_20_1  original_T_including_depot_unload_856  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_693  1
    load_0_20_1  segment_load_conservation_773  -1
    load_0_20_1  segment_prefix_lb_774  1
    load_0_20_1  segment_prefix_ub_775  1
    load_0_20_1  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_695  -20
    arc_0_20_2  connected_order_arc_696  -14
    arc_0_20_2  in_degree_777  1
    arc_0_20_2  out_degree_834  1
    arc_0_20_2  original_T_including_depot_unload_856  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_695  1
    load_0_20_2  segment_load_conservation_780  -1
    load_0_20_2  segment_prefix_lb_781  1
    load_0_20_2  segment_prefix_ub_782  1
    load_0_20_2  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_697  -20
    arc_0_20_3  connected_order_arc_698  -14
    arc_0_20_3  in_degree_784  1
    arc_0_20_3  out_degree_834  1
    arc_0_20_3  original_T_including_depot_unload_856  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_697  1
    load_0_20_3  segment_load_conservation_787  -1
    load_0_20_3  segment_prefix_lb_788  1
    load_0_20_3  segment_prefix_ub_789  1
    load_0_20_3  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_699  -20
    arc_0_20_4  connected_order_arc_700  -14
    arc_0_20_4  in_degree_791  1
    arc_0_20_4  out_degree_834  1
    arc_0_20_4  original_T_including_depot_unload_856  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_699  1
    load_0_20_4  segment_load_conservation_794  -1
    load_0_20_4  segment_prefix_lb_795  1
    load_0_20_4  segment_prefix_ub_796  1
    load_0_20_4  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_701  -20
    arc_0_20_5  connected_order_arc_702  -14
    arc_0_20_5  in_degree_798  1
    arc_0_20_5  out_degree_834  1
    arc_0_20_5  original_T_including_depot_unload_856  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_701  1
    load_0_20_5  segment_load_conservation_801  -1
    load_0_20_5  segment_prefix_lb_802  1
    load_0_20_5  segment_prefix_ub_803  1
    load_0_20_5  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_703  -20
    arc_0_20_15  connected_order_arc_704  -14
    arc_0_20_15  in_degree_805  1
    arc_0_20_15  out_degree_834  1
    arc_0_20_15  original_T_including_depot_unload_856  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_703  1
    load_0_20_15  free_load_conservation_809  -1
    load_0_20_15  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_705  -20
    arc_0_20_16  connected_order_arc_706  -14
    arc_0_20_16  in_degree_811  1
    arc_0_20_16  out_degree_834  1
    arc_0_20_16  original_T_including_depot_unload_856  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_705  1
    load_0_20_16  free_load_conservation_815  -1
    load_0_20_16  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_707  -20
    arc_0_20_17  connected_order_arc_708  -14
    arc_0_20_17  in_degree_817  1
    arc_0_20_17  out_degree_834  1
    arc_0_20_17  original_T_including_depot_unload_856  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_707  1
    load_0_20_17  free_load_conservation_821  -1
    load_0_20_17  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_709  -20
    arc_0_20_18  connected_order_arc_710  -14
    arc_0_20_18  in_degree_823  1
    arc_0_20_18  out_degree_834  1
    arc_0_20_18  original_T_including_depot_unload_856  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_709  1
    load_0_20_18  free_load_conservation_827  -1
    load_0_20_18  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_711  -20
    arc_0_20_19  connected_order_arc_712  -14
    arc_0_20_19  in_degree_829  1
    arc_0_20_19  out_degree_834  1
    arc_0_20_19  original_T_including_depot_unload_856  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_711  1
    load_0_20_19  free_load_conservation_833  -1
    load_0_20_19  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_713  -20
    arc_0_20_21  connected_order_arc_714  -14
    arc_0_20_21  out_degree_834  1
    arc_0_20_21  in_degree_841  1
    arc_0_20_21  original_T_including_depot_unload_856  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_713  1
    load_0_20_21  free_load_conservation_839  1
    load_0_20_21  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_715  -20
    arc_0_20_22  connected_order_arc_716  -14
    arc_0_20_22  out_degree_834  1
    arc_0_20_22  in_degree_847  1
    arc_0_20_22  original_T_including_depot_unload_856  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_715  1
    load_0_20_22  free_load_conservation_839  1
    load_0_20_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_717  -20
    arc_0_21_0  depot_return_or_bypass_768  1
    arc_0_21_0  out_degree_840  1
    arc_0_21_0  original_T_including_depot_unload_856  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_717  1
    load_0_21_0  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_718  -20
    arc_0_21_1  connected_order_arc_719  -14
    arc_0_21_1  in_degree_770  1
    arc_0_21_1  out_degree_840  1
    arc_0_21_1  original_T_including_depot_unload_856  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_718  1
    load_0_21_1  segment_load_conservation_773  -1
    load_0_21_1  segment_prefix_lb_774  1
    load_0_21_1  segment_prefix_ub_775  1
    load_0_21_1  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_720  -20
    arc_0_21_2  connected_order_arc_721  -14
    arc_0_21_2  in_degree_777  1
    arc_0_21_2  out_degree_840  1
    arc_0_21_2  original_T_including_depot_unload_856  1.8580343290482886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_720  1
    load_0_21_2  segment_load_conservation_780  -1
    load_0_21_2  segment_prefix_lb_781  1
    load_0_21_2  segment_prefix_ub_782  1
    load_0_21_2  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_722  -20
    arc_0_21_3  connected_order_arc_723  -14
    arc_0_21_3  in_degree_784  1
    arc_0_21_3  out_degree_840  1
    arc_0_21_3  original_T_including_depot_unload_856  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_722  1
    load_0_21_3  segment_load_conservation_787  -1
    load_0_21_3  segment_prefix_lb_788  1
    load_0_21_3  segment_prefix_ub_789  1
    load_0_21_3  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_724  -20
    arc_0_21_4  connected_order_arc_725  -14
    arc_0_21_4  in_degree_791  1
    arc_0_21_4  out_degree_840  1
    arc_0_21_4  original_T_including_depot_unload_856  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_724  1
    load_0_21_4  segment_load_conservation_794  -1
    load_0_21_4  segment_prefix_lb_795  1
    load_0_21_4  segment_prefix_ub_796  1
    load_0_21_4  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_726  -20
    arc_0_21_5  connected_order_arc_727  -14
    arc_0_21_5  in_degree_798  1
    arc_0_21_5  out_degree_840  1
    arc_0_21_5  original_T_including_depot_unload_856  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_726  1
    load_0_21_5  segment_load_conservation_801  -1
    load_0_21_5  segment_prefix_lb_802  1
    load_0_21_5  segment_prefix_ub_803  1
    load_0_21_5  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_728  -20
    arc_0_21_15  connected_order_arc_729  -14
    arc_0_21_15  in_degree_805  1
    arc_0_21_15  out_degree_840  1
    arc_0_21_15  original_T_including_depot_unload_856  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_728  1
    load_0_21_15  free_load_conservation_809  -1
    load_0_21_15  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_730  -20
    arc_0_21_16  connected_order_arc_731  -14
    arc_0_21_16  in_degree_811  1
    arc_0_21_16  out_degree_840  1
    arc_0_21_16  original_T_including_depot_unload_856  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_730  1
    load_0_21_16  free_load_conservation_815  -1
    load_0_21_16  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_732  -20
    arc_0_21_17  connected_order_arc_733  -14
    arc_0_21_17  in_degree_817  1
    arc_0_21_17  out_degree_840  1
    arc_0_21_17  original_T_including_depot_unload_856  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_732  1
    load_0_21_17  free_load_conservation_821  -1
    load_0_21_17  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_734  -20
    arc_0_21_18  connected_order_arc_735  -14
    arc_0_21_18  in_degree_823  1
    arc_0_21_18  out_degree_840  1
    arc_0_21_18  original_T_including_depot_unload_856  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_734  1
    load_0_21_18  free_load_conservation_827  -1
    load_0_21_18  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_736  -20
    arc_0_21_19  connected_order_arc_737  -14
    arc_0_21_19  in_degree_829  1
    arc_0_21_19  out_degree_840  1
    arc_0_21_19  original_T_including_depot_unload_856  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_736  1
    load_0_21_19  free_load_conservation_833  -1
    load_0_21_19  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_738  -20
    arc_0_21_20  connected_order_arc_739  -14
    arc_0_21_20  in_degree_835  1
    arc_0_21_20  out_degree_840  1
    arc_0_21_20  original_T_including_depot_unload_856  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_738  1
    load_0_21_20  free_load_conservation_839  -1
    load_0_21_20  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_740  -20
    arc_0_21_22  connected_order_arc_741  -14
    arc_0_21_22  out_degree_840  1
    arc_0_21_22  in_degree_847  1
    arc_0_21_22  original_T_including_depot_unload_856  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_740  1
    load_0_21_22  free_load_conservation_845  1
    load_0_21_22  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_742  -20
    arc_0_22_0  depot_return_or_bypass_768  1
    arc_0_22_0  out_degree_846  1
    arc_0_22_0  original_T_including_depot_unload_856  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_742  1
    load_0_22_0  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_743  -20
    arc_0_22_1  connected_order_arc_744  -14
    arc_0_22_1  in_degree_770  1
    arc_0_22_1  out_degree_846  1
    arc_0_22_1  original_T_including_depot_unload_856  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_743  1
    load_0_22_1  segment_load_conservation_773  -1
    load_0_22_1  segment_prefix_lb_774  1
    load_0_22_1  segment_prefix_ub_775  1
    load_0_22_1  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_745  -20
    arc_0_22_2  connected_order_arc_746  -14
    arc_0_22_2  in_degree_777  1
    arc_0_22_2  out_degree_846  1
    arc_0_22_2  original_T_including_depot_unload_856  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_745  1
    load_0_22_2  segment_load_conservation_780  -1
    load_0_22_2  segment_prefix_lb_781  1
    load_0_22_2  segment_prefix_ub_782  1
    load_0_22_2  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_747  -20
    arc_0_22_3  connected_order_arc_748  -14
    arc_0_22_3  in_degree_784  1
    arc_0_22_3  out_degree_846  1
    arc_0_22_3  original_T_including_depot_unload_856  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_747  1
    load_0_22_3  segment_load_conservation_787  -1
    load_0_22_3  segment_prefix_lb_788  1
    load_0_22_3  segment_prefix_ub_789  1
    load_0_22_3  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_749  -20
    arc_0_22_4  connected_order_arc_750  -14
    arc_0_22_4  in_degree_791  1
    arc_0_22_4  out_degree_846  1
    arc_0_22_4  original_T_including_depot_unload_856  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_749  1
    load_0_22_4  segment_load_conservation_794  -1
    load_0_22_4  segment_prefix_lb_795  1
    load_0_22_4  segment_prefix_ub_796  1
    load_0_22_4  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_751  -20
    arc_0_22_5  connected_order_arc_752  -14
    arc_0_22_5  in_degree_798  1
    arc_0_22_5  out_degree_846  1
    arc_0_22_5  original_T_including_depot_unload_856  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_751  1
    load_0_22_5  segment_load_conservation_801  -1
    load_0_22_5  segment_prefix_lb_802  1
    load_0_22_5  segment_prefix_ub_803  1
    load_0_22_5  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_753  -20
    arc_0_22_15  connected_order_arc_754  -14
    arc_0_22_15  in_degree_805  1
    arc_0_22_15  out_degree_846  1
    arc_0_22_15  original_T_including_depot_unload_856  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_753  1
    load_0_22_15  free_load_conservation_809  -1
    load_0_22_15  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_755  -20
    arc_0_22_16  connected_order_arc_756  -14
    arc_0_22_16  in_degree_811  1
    arc_0_22_16  out_degree_846  1
    arc_0_22_16  original_T_including_depot_unload_856  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_755  1
    load_0_22_16  free_load_conservation_815  -1
    load_0_22_16  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_757  -20
    arc_0_22_17  connected_order_arc_758  -14
    arc_0_22_17  in_degree_817  1
    arc_0_22_17  out_degree_846  1
    arc_0_22_17  original_T_including_depot_unload_856  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_757  1
    load_0_22_17  free_load_conservation_821  -1
    load_0_22_17  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_759  -20
    arc_0_22_18  connected_order_arc_760  -14
    arc_0_22_18  in_degree_823  1
    arc_0_22_18  out_degree_846  1
    arc_0_22_18  original_T_including_depot_unload_856  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_759  1
    load_0_22_18  free_load_conservation_827  -1
    load_0_22_18  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_761  -20
    arc_0_22_19  connected_order_arc_762  -14
    arc_0_22_19  in_degree_829  1
    arc_0_22_19  out_degree_846  1
    arc_0_22_19  original_T_including_depot_unload_856  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_761  1
    load_0_22_19  free_load_conservation_833  -1
    load_0_22_19  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_763  -20
    arc_0_22_20  connected_order_arc_764  -14
    arc_0_22_20  in_degree_835  1
    arc_0_22_20  out_degree_846  1
    arc_0_22_20  original_T_including_depot_unload_856  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_763  1
    load_0_22_20  free_load_conservation_839  -1
    load_0_22_20  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_765  -20
    arc_0_22_21  connected_order_arc_766  -14
    arc_0_22_21  in_degree_841  1
    arc_0_22_21  out_degree_846  1
    arc_0_22_21  original_T_including_depot_unload_856  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_765  1
    load_0_22_21  free_load_conservation_845  -1
    load_0_22_21  free_load_conservation_851  1
    visit_1_6  out_degree_1198  -1
    visit_1_6  in_degree_1199  -1
    visit_1_6  order_active_lb_1200  -1
    visit_1_6  order_active_ub_1201  -13
    order_1_6  connected_order_arc_873  -1
    order_1_6  connected_order_arc_875  -1
    order_1_6  connected_order_arc_877  -1
    order_1_6  connected_order_arc_879  -1
    order_1_6  connected_order_arc_881  -1
    order_1_6  connected_order_arc_883  -1
    order_1_6  connected_order_arc_885  -1
    order_1_6  connected_order_arc_887  -1
    order_1_6  connected_order_arc_889  -1
    order_1_6  connected_order_arc_891  -1
    order_1_6  connected_order_arc_893  -1
    order_1_6  connected_order_arc_895  -1
    order_1_6  connected_order_arc_898  1
    order_1_6  connected_order_arc_923  1
    order_1_6  connected_order_arc_948  1
    order_1_6  connected_order_arc_973  1
    order_1_6  connected_order_arc_998  1
    order_1_6  connected_order_arc_1023  1
    order_1_6  connected_order_arc_1048  1
    order_1_6  connected_order_arc_1073  1
    order_1_6  connected_order_arc_1098  1
    order_1_6  connected_order_arc_1123  1
    order_1_6  connected_order_arc_1148  1
    order_1_6  connected_order_arc_1173  1
    order_1_6  order_active_lb_1200  1
    order_1_6  order_active_ub_1201  1
    order_1_6  fixed_segment_relative_order_1281  -1
    visit_1_7  out_degree_1205  -1
    visit_1_7  in_degree_1206  -1
    visit_1_7  order_active_lb_1207  -1
    visit_1_7  order_active_ub_1208  -13
    order_1_7  connected_order_arc_873  1
    order_1_7  connected_order_arc_898  -1
    order_1_7  connected_order_arc_900  -1
    order_1_7  connected_order_arc_902  -1
    order_1_7  connected_order_arc_904  -1
    order_1_7  connected_order_arc_906  -1
    order_1_7  connected_order_arc_908  -1
    order_1_7  connected_order_arc_910  -1
    order_1_7  connected_order_arc_912  -1
    order_1_7  connected_order_arc_914  -1
    order_1_7  connected_order_arc_916  -1
    order_1_7  connected_order_arc_918  -1
    order_1_7  connected_order_arc_920  -1
    order_1_7  connected_order_arc_925  1
    order_1_7  connected_order_arc_950  1
    order_1_7  connected_order_arc_975  1
    order_1_7  connected_order_arc_1000  1
    order_1_7  connected_order_arc_1025  1
    order_1_7  connected_order_arc_1050  1
    order_1_7  connected_order_arc_1075  1
    order_1_7  connected_order_arc_1100  1
    order_1_7  connected_order_arc_1125  1
    order_1_7  connected_order_arc_1150  1
    order_1_7  connected_order_arc_1175  1
    order_1_7  order_active_lb_1207  1
    order_1_7  order_active_ub_1208  1
    order_1_7  fixed_segment_relative_order_1281  1
    order_1_7  fixed_segment_relative_order_1282  -1
    visit_1_8  out_degree_1212  -1
    visit_1_8  in_degree_1213  -1
    visit_1_8  order_active_lb_1214  -1
    visit_1_8  order_active_ub_1215  -13
    order_1_8  connected_order_arc_875  1
    order_1_8  connected_order_arc_900  1
    order_1_8  connected_order_arc_923  -1
    order_1_8  connected_order_arc_925  -1
    order_1_8  connected_order_arc_927  -1
    order_1_8  connected_order_arc_929  -1
    order_1_8  connected_order_arc_931  -1
    order_1_8  connected_order_arc_933  -1
    order_1_8  connected_order_arc_935  -1
    order_1_8  connected_order_arc_937  -1
    order_1_8  connected_order_arc_939  -1
    order_1_8  connected_order_arc_941  -1
    order_1_8  connected_order_arc_943  -1
    order_1_8  connected_order_arc_945  -1
    order_1_8  connected_order_arc_952  1
    order_1_8  connected_order_arc_977  1
    order_1_8  connected_order_arc_1002  1
    order_1_8  connected_order_arc_1027  1
    order_1_8  connected_order_arc_1052  1
    order_1_8  connected_order_arc_1077  1
    order_1_8  connected_order_arc_1102  1
    order_1_8  connected_order_arc_1127  1
    order_1_8  connected_order_arc_1152  1
    order_1_8  connected_order_arc_1177  1
    order_1_8  order_active_lb_1214  1
    order_1_8  order_active_ub_1215  1
    order_1_8  fixed_segment_relative_order_1282  1
    order_1_8  fixed_segment_relative_order_1283  -1
    visit_1_9  out_degree_1219  -1
    visit_1_9  in_degree_1220  -1
    visit_1_9  order_active_lb_1221  -1
    visit_1_9  order_active_ub_1222  -13
    order_1_9  connected_order_arc_877  1
    order_1_9  connected_order_arc_902  1
    order_1_9  connected_order_arc_927  1
    order_1_9  connected_order_arc_948  -1
    order_1_9  connected_order_arc_950  -1
    order_1_9  connected_order_arc_952  -1
    order_1_9  connected_order_arc_954  -1
    order_1_9  connected_order_arc_956  -1
    order_1_9  connected_order_arc_958  -1
    order_1_9  connected_order_arc_960  -1
    order_1_9  connected_order_arc_962  -1
    order_1_9  connected_order_arc_964  -1
    order_1_9  connected_order_arc_966  -1
    order_1_9  connected_order_arc_968  -1
    order_1_9  connected_order_arc_970  -1
    order_1_9  connected_order_arc_979  1
    order_1_9  connected_order_arc_1004  1
    order_1_9  connected_order_arc_1029  1
    order_1_9  connected_order_arc_1054  1
    order_1_9  connected_order_arc_1079  1
    order_1_9  connected_order_arc_1104  1
    order_1_9  connected_order_arc_1129  1
    order_1_9  connected_order_arc_1154  1
    order_1_9  connected_order_arc_1179  1
    order_1_9  order_active_lb_1221  1
    order_1_9  order_active_ub_1222  1
    order_1_9  fixed_segment_relative_order_1283  1
    order_1_9  fixed_segment_relative_order_1284  -1
    visit_1_10  out_degree_1226  -1
    visit_1_10  in_degree_1227  -1
    visit_1_10  order_active_lb_1228  -1
    visit_1_10  order_active_ub_1229  -13
    order_1_10  connected_order_arc_879  1
    order_1_10  connected_order_arc_904  1
    order_1_10  connected_order_arc_929  1
    order_1_10  connected_order_arc_954  1
    order_1_10  connected_order_arc_973  -1
    order_1_10  connected_order_arc_975  -1
    order_1_10  connected_order_arc_977  -1
    order_1_10  connected_order_arc_979  -1
    order_1_10  connected_order_arc_981  -1
    order_1_10  connected_order_arc_983  -1
    order_1_10  connected_order_arc_985  -1
    order_1_10  connected_order_arc_987  -1
    order_1_10  connected_order_arc_989  -1
    order_1_10  connected_order_arc_991  -1
    order_1_10  connected_order_arc_993  -1
    order_1_10  connected_order_arc_995  -1
    order_1_10  connected_order_arc_1006  1
    order_1_10  connected_order_arc_1031  1
    order_1_10  connected_order_arc_1056  1
    order_1_10  connected_order_arc_1081  1
    order_1_10  connected_order_arc_1106  1
    order_1_10  connected_order_arc_1131  1
    order_1_10  connected_order_arc_1156  1
    order_1_10  connected_order_arc_1181  1
    order_1_10  order_active_lb_1228  1
    order_1_10  order_active_ub_1229  1
    order_1_10  fixed_segment_relative_order_1284  1
    visit_1_15  out_degree_1233  -1
    visit_1_15  in_degree_1234  -1
    visit_1_15  order_active_lb_1235  -1
    visit_1_15  order_active_ub_1236  -13
    visit_1_15  service_visit_def_1237  -1
    order_1_15  connected_order_arc_881  1
    order_1_15  connected_order_arc_906  1
    order_1_15  connected_order_arc_931  1
    order_1_15  connected_order_arc_956  1
    order_1_15  connected_order_arc_981  1
    order_1_15  connected_order_arc_998  -1
    order_1_15  connected_order_arc_1000  -1
    order_1_15  connected_order_arc_1002  -1
    order_1_15  connected_order_arc_1004  -1
    order_1_15  connected_order_arc_1006  -1
    order_1_15  connected_order_arc_1008  -1
    order_1_15  connected_order_arc_1010  -1
    order_1_15  connected_order_arc_1012  -1
    order_1_15  connected_order_arc_1014  -1
    order_1_15  connected_order_arc_1016  -1
    order_1_15  connected_order_arc_1018  -1
    order_1_15  connected_order_arc_1020  -1
    order_1_15  connected_order_arc_1033  1
    order_1_15  connected_order_arc_1058  1
    order_1_15  connected_order_arc_1083  1
    order_1_15  connected_order_arc_1108  1
    order_1_15  connected_order_arc_1133  1
    order_1_15  connected_order_arc_1158  1
    order_1_15  connected_order_arc_1183  1
    order_1_15  order_active_lb_1235  1
    order_1_15  order_active_ub_1236  1
    visit_1_16  out_degree_1239  -1
    visit_1_16  in_degree_1240  -1
    visit_1_16  order_active_lb_1241  -1
    visit_1_16  order_active_ub_1242  -13
    visit_1_16  service_visit_def_1243  -1
    order_1_16  connected_order_arc_883  1
    order_1_16  connected_order_arc_908  1
    order_1_16  connected_order_arc_933  1
    order_1_16  connected_order_arc_958  1
    order_1_16  connected_order_arc_983  1
    order_1_16  connected_order_arc_1008  1
    order_1_16  connected_order_arc_1023  -1
    order_1_16  connected_order_arc_1025  -1
    order_1_16  connected_order_arc_1027  -1
    order_1_16  connected_order_arc_1029  -1
    order_1_16  connected_order_arc_1031  -1
    order_1_16  connected_order_arc_1033  -1
    order_1_16  connected_order_arc_1035  -1
    order_1_16  connected_order_arc_1037  -1
    order_1_16  connected_order_arc_1039  -1
    order_1_16  connected_order_arc_1041  -1
    order_1_16  connected_order_arc_1043  -1
    order_1_16  connected_order_arc_1045  -1
    order_1_16  connected_order_arc_1060  1
    order_1_16  connected_order_arc_1085  1
    order_1_16  connected_order_arc_1110  1
    order_1_16  connected_order_arc_1135  1
    order_1_16  connected_order_arc_1160  1
    order_1_16  connected_order_arc_1185  1
    order_1_16  order_active_lb_1241  1
    order_1_16  order_active_ub_1242  1
    visit_1_17  out_degree_1245  -1
    visit_1_17  in_degree_1246  -1
    visit_1_17  order_active_lb_1247  -1
    visit_1_17  order_active_ub_1248  -13
    visit_1_17  service_visit_def_1249  -1
    order_1_17  connected_order_arc_885  1
    order_1_17  connected_order_arc_910  1
    order_1_17  connected_order_arc_935  1
    order_1_17  connected_order_arc_960  1
    order_1_17  connected_order_arc_985  1
    order_1_17  connected_order_arc_1010  1
    order_1_17  connected_order_arc_1035  1
    order_1_17  connected_order_arc_1048  -1
    order_1_17  connected_order_arc_1050  -1
    order_1_17  connected_order_arc_1052  -1
    order_1_17  connected_order_arc_1054  -1
    order_1_17  connected_order_arc_1056  -1
    order_1_17  connected_order_arc_1058  -1
    order_1_17  connected_order_arc_1060  -1
    order_1_17  connected_order_arc_1062  -1
    order_1_17  connected_order_arc_1064  -1
    order_1_17  connected_order_arc_1066  -1
    order_1_17  connected_order_arc_1068  -1
    order_1_17  connected_order_arc_1070  -1
    order_1_17  connected_order_arc_1087  1
    order_1_17  connected_order_arc_1112  1
    order_1_17  connected_order_arc_1137  1
    order_1_17  connected_order_arc_1162  1
    order_1_17  connected_order_arc_1187  1
    order_1_17  order_active_lb_1247  1
    order_1_17  order_active_ub_1248  1
    visit_1_18  out_degree_1251  -1
    visit_1_18  in_degree_1252  -1
    visit_1_18  order_active_lb_1253  -1
    visit_1_18  order_active_ub_1254  -13
    visit_1_18  service_visit_def_1255  -1
    order_1_18  connected_order_arc_887  1
    order_1_18  connected_order_arc_912  1
    order_1_18  connected_order_arc_937  1
    order_1_18  connected_order_arc_962  1
    order_1_18  connected_order_arc_987  1
    order_1_18  connected_order_arc_1012  1
    order_1_18  connected_order_arc_1037  1
    order_1_18  connected_order_arc_1062  1
    order_1_18  connected_order_arc_1073  -1
    order_1_18  connected_order_arc_1075  -1
    order_1_18  connected_order_arc_1077  -1
    order_1_18  connected_order_arc_1079  -1
    order_1_18  connected_order_arc_1081  -1
    order_1_18  connected_order_arc_1083  -1
    order_1_18  connected_order_arc_1085  -1
    order_1_18  connected_order_arc_1087  -1
    order_1_18  connected_order_arc_1089  -1
    order_1_18  connected_order_arc_1091  -1
    order_1_18  connected_order_arc_1093  -1
    order_1_18  connected_order_arc_1095  -1
    order_1_18  connected_order_arc_1114  1
    order_1_18  connected_order_arc_1139  1
    order_1_18  connected_order_arc_1164  1
    order_1_18  connected_order_arc_1189  1
    order_1_18  order_active_lb_1253  1
    order_1_18  order_active_ub_1254  1
    visit_1_19  out_degree_1257  -1
    visit_1_19  in_degree_1258  -1
    visit_1_19  order_active_lb_1259  -1
    visit_1_19  order_active_ub_1260  -13
    visit_1_19  service_visit_def_1261  -1
    order_1_19  connected_order_arc_889  1
    order_1_19  connected_order_arc_914  1
    order_1_19  connected_order_arc_939  1
    order_1_19  connected_order_arc_964  1
    order_1_19  connected_order_arc_989  1
    order_1_19  connected_order_arc_1014  1
    order_1_19  connected_order_arc_1039  1
    order_1_19  connected_order_arc_1064  1
    order_1_19  connected_order_arc_1089  1
    order_1_19  connected_order_arc_1098  -1
    order_1_19  connected_order_arc_1100  -1
    order_1_19  connected_order_arc_1102  -1
    order_1_19  connected_order_arc_1104  -1
    order_1_19  connected_order_arc_1106  -1
    order_1_19  connected_order_arc_1108  -1
    order_1_19  connected_order_arc_1110  -1
    order_1_19  connected_order_arc_1112  -1
    order_1_19  connected_order_arc_1114  -1
    order_1_19  connected_order_arc_1116  -1
    order_1_19  connected_order_arc_1118  -1
    order_1_19  connected_order_arc_1120  -1
    order_1_19  connected_order_arc_1141  1
    order_1_19  connected_order_arc_1166  1
    order_1_19  connected_order_arc_1191  1
    order_1_19  order_active_lb_1259  1
    order_1_19  order_active_ub_1260  1
    visit_1_20  out_degree_1263  -1
    visit_1_20  in_degree_1264  -1
    visit_1_20  order_active_lb_1265  -1
    visit_1_20  order_active_ub_1266  -13
    visit_1_20  service_visit_def_1267  -1
    order_1_20  connected_order_arc_891  1
    order_1_20  connected_order_arc_916  1
    order_1_20  connected_order_arc_941  1
    order_1_20  connected_order_arc_966  1
    order_1_20  connected_order_arc_991  1
    order_1_20  connected_order_arc_1016  1
    order_1_20  connected_order_arc_1041  1
    order_1_20  connected_order_arc_1066  1
    order_1_20  connected_order_arc_1091  1
    order_1_20  connected_order_arc_1116  1
    order_1_20  connected_order_arc_1123  -1
    order_1_20  connected_order_arc_1125  -1
    order_1_20  connected_order_arc_1127  -1
    order_1_20  connected_order_arc_1129  -1
    order_1_20  connected_order_arc_1131  -1
    order_1_20  connected_order_arc_1133  -1
    order_1_20  connected_order_arc_1135  -1
    order_1_20  connected_order_arc_1137  -1
    order_1_20  connected_order_arc_1139  -1
    order_1_20  connected_order_arc_1141  -1
    order_1_20  connected_order_arc_1143  -1
    order_1_20  connected_order_arc_1145  -1
    order_1_20  connected_order_arc_1168  1
    order_1_20  connected_order_arc_1193  1
    order_1_20  order_active_lb_1265  1
    order_1_20  order_active_ub_1266  1
    visit_1_21  out_degree_1269  -1
    visit_1_21  in_degree_1270  -1
    visit_1_21  order_active_lb_1271  -1
    visit_1_21  order_active_ub_1272  -13
    visit_1_21  service_visit_def_1273  -1
    order_1_21  connected_order_arc_893  1
    order_1_21  connected_order_arc_918  1
    order_1_21  connected_order_arc_943  1
    order_1_21  connected_order_arc_968  1
    order_1_21  connected_order_arc_993  1
    order_1_21  connected_order_arc_1018  1
    order_1_21  connected_order_arc_1043  1
    order_1_21  connected_order_arc_1068  1
    order_1_21  connected_order_arc_1093  1
    order_1_21  connected_order_arc_1118  1
    order_1_21  connected_order_arc_1143  1
    order_1_21  connected_order_arc_1148  -1
    order_1_21  connected_order_arc_1150  -1
    order_1_21  connected_order_arc_1152  -1
    order_1_21  connected_order_arc_1154  -1
    order_1_21  connected_order_arc_1156  -1
    order_1_21  connected_order_arc_1158  -1
    order_1_21  connected_order_arc_1160  -1
    order_1_21  connected_order_arc_1162  -1
    order_1_21  connected_order_arc_1164  -1
    order_1_21  connected_order_arc_1166  -1
    order_1_21  connected_order_arc_1168  -1
    order_1_21  connected_order_arc_1170  -1
    order_1_21  connected_order_arc_1195  1
    order_1_21  order_active_lb_1271  1
    order_1_21  order_active_ub_1272  1
    visit_1_22  out_degree_1275  -1
    visit_1_22  in_degree_1276  -1
    visit_1_22  order_active_lb_1277  -1
    visit_1_22  order_active_ub_1278  -13
    visit_1_22  service_visit_def_1279  -1
    order_1_22  connected_order_arc_895  1
    order_1_22  connected_order_arc_920  1
    order_1_22  connected_order_arc_945  1
    order_1_22  connected_order_arc_970  1
    order_1_22  connected_order_arc_995  1
    order_1_22  connected_order_arc_1020  1
    order_1_22  connected_order_arc_1045  1
    order_1_22  connected_order_arc_1070  1
    order_1_22  connected_order_arc_1095  1
    order_1_22  connected_order_arc_1120  1
    order_1_22  connected_order_arc_1145  1
    order_1_22  connected_order_arc_1170  1
    order_1_22  connected_order_arc_1173  -1
    order_1_22  connected_order_arc_1175  -1
    order_1_22  connected_order_arc_1177  -1
    order_1_22  connected_order_arc_1179  -1
    order_1_22  connected_order_arc_1181  -1
    order_1_22  connected_order_arc_1183  -1
    order_1_22  connected_order_arc_1185  -1
    order_1_22  connected_order_arc_1187  -1
    order_1_22  connected_order_arc_1189  -1
    order_1_22  connected_order_arc_1191  -1
    order_1_22  connected_order_arc_1193  -1
    order_1_22  connected_order_arc_1195  -1
    order_1_22  order_active_lb_1277  1
    order_1_22  order_active_ub_1278  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_857  -25
    arc_1_0_0  depot_departure_or_bypass_1196  1
    arc_1_0_0  depot_return_or_bypass_1197  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_858  -25
    arc_1_0_6  depot_departure_or_bypass_1196  1
    arc_1_0_6  in_degree_1199  1
    arc_1_0_6  original_T_including_depot_unload_1285  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_858  1
    load_1_0_6  segment_load_conservation_1202  -1
    load_1_0_6  segment_prefix_lb_1203  1
    load_1_0_6  segment_prefix_ub_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_859  -25
    arc_1_0_7  depot_departure_or_bypass_1196  1
    arc_1_0_7  in_degree_1206  1
    arc_1_0_7  original_T_including_depot_unload_1285  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_859  1
    load_1_0_7  segment_load_conservation_1209  -1
    load_1_0_7  segment_prefix_lb_1210  1
    load_1_0_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_860  -25
    arc_1_0_8  depot_departure_or_bypass_1196  1
    arc_1_0_8  in_degree_1213  1
    arc_1_0_8  original_T_including_depot_unload_1285  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_860  1
    load_1_0_8  segment_load_conservation_1216  -1
    load_1_0_8  segment_prefix_lb_1217  1
    load_1_0_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_861  -25
    arc_1_0_9  depot_departure_or_bypass_1196  1
    arc_1_0_9  in_degree_1220  1
    arc_1_0_9  original_T_including_depot_unload_1285  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_861  1
    load_1_0_9  segment_load_conservation_1223  -1
    load_1_0_9  segment_prefix_lb_1224  1
    load_1_0_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_862  -25
    arc_1_0_10  depot_departure_or_bypass_1196  1
    arc_1_0_10  in_degree_1227  1
    arc_1_0_10  original_T_including_depot_unload_1285  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_862  1
    load_1_0_10  segment_load_conservation_1230  -1
    load_1_0_10  segment_prefix_lb_1231  1
    load_1_0_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_863  -25
    arc_1_0_15  depot_departure_or_bypass_1196  1
    arc_1_0_15  in_degree_1234  1
    arc_1_0_15  original_T_including_depot_unload_1285  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_863  1
    load_1_0_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_864  -25
    arc_1_0_16  depot_departure_or_bypass_1196  1
    arc_1_0_16  in_degree_1240  1
    arc_1_0_16  original_T_including_depot_unload_1285  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_864  1
    load_1_0_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_865  -25
    arc_1_0_17  depot_departure_or_bypass_1196  1
    arc_1_0_17  in_degree_1246  1
    arc_1_0_17  original_T_including_depot_unload_1285  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_865  1
    load_1_0_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_866  -25
    arc_1_0_18  depot_departure_or_bypass_1196  1
    arc_1_0_18  in_degree_1252  1
    arc_1_0_18  original_T_including_depot_unload_1285  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_866  1
    load_1_0_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_867  -25
    arc_1_0_19  depot_departure_or_bypass_1196  1
    arc_1_0_19  in_degree_1258  1
    arc_1_0_19  original_T_including_depot_unload_1285  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_867  1
    load_1_0_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_868  -25
    arc_1_0_20  depot_departure_or_bypass_1196  1
    arc_1_0_20  in_degree_1264  1
    arc_1_0_20  original_T_including_depot_unload_1285  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_868  1
    load_1_0_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_869  -25
    arc_1_0_21  depot_departure_or_bypass_1196  1
    arc_1_0_21  in_degree_1270  1
    arc_1_0_21  original_T_including_depot_unload_1285  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_869  1
    load_1_0_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_870  -25
    arc_1_0_22  depot_departure_or_bypass_1196  1
    arc_1_0_22  in_degree_1276  1
    arc_1_0_22  original_T_including_depot_unload_1285  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_870  1
    load_1_0_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_871  -25
    arc_1_6_0  depot_return_or_bypass_1197  1
    arc_1_6_0  out_degree_1198  1
    arc_1_6_0  original_T_including_depot_unload_1285  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_871  1
    load_1_6_0  segment_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_872  -25
    arc_1_6_7  connected_order_arc_873  -14
    arc_1_6_7  out_degree_1198  1
    arc_1_6_7  in_degree_1206  1
    arc_1_6_7  original_T_including_depot_unload_1285  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_872  1
    load_1_6_7  segment_load_conservation_1202  1
    load_1_6_7  segment_load_conservation_1209  -1
    load_1_6_7  segment_prefix_lb_1210  1
    load_1_6_7  segment_prefix_ub_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_874  -25
    arc_1_6_8  connected_order_arc_875  -14
    arc_1_6_8  out_degree_1198  1
    arc_1_6_8  in_degree_1213  1
    arc_1_6_8  original_T_including_depot_unload_1285  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_874  1
    load_1_6_8  segment_load_conservation_1202  1
    load_1_6_8  segment_load_conservation_1216  -1
    load_1_6_8  segment_prefix_lb_1217  1
    load_1_6_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_876  -25
    arc_1_6_9  connected_order_arc_877  -14
    arc_1_6_9  out_degree_1198  1
    arc_1_6_9  in_degree_1220  1
    arc_1_6_9  original_T_including_depot_unload_1285  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_876  1
    load_1_6_9  segment_load_conservation_1202  1
    load_1_6_9  segment_load_conservation_1223  -1
    load_1_6_9  segment_prefix_lb_1224  1
    load_1_6_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_878  -25
    arc_1_6_10  connected_order_arc_879  -14
    arc_1_6_10  out_degree_1198  1
    arc_1_6_10  in_degree_1227  1
    arc_1_6_10  original_T_including_depot_unload_1285  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_878  1
    load_1_6_10  segment_load_conservation_1202  1
    load_1_6_10  segment_load_conservation_1230  -1
    load_1_6_10  segment_prefix_lb_1231  1
    load_1_6_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_880  -25
    arc_1_6_15  connected_order_arc_881  -14
    arc_1_6_15  out_degree_1198  1
    arc_1_6_15  in_degree_1234  1
    arc_1_6_15  original_T_including_depot_unload_1285  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_880  1
    load_1_6_15  segment_load_conservation_1202  1
    load_1_6_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_882  -25
    arc_1_6_16  connected_order_arc_883  -14
    arc_1_6_16  out_degree_1198  1
    arc_1_6_16  in_degree_1240  1
    arc_1_6_16  original_T_including_depot_unload_1285  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_882  1
    load_1_6_16  segment_load_conservation_1202  1
    load_1_6_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_884  -25
    arc_1_6_17  connected_order_arc_885  -14
    arc_1_6_17  out_degree_1198  1
    arc_1_6_17  in_degree_1246  1
    arc_1_6_17  original_T_including_depot_unload_1285  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_884  1
    load_1_6_17  segment_load_conservation_1202  1
    load_1_6_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_886  -25
    arc_1_6_18  connected_order_arc_887  -14
    arc_1_6_18  out_degree_1198  1
    arc_1_6_18  in_degree_1252  1
    arc_1_6_18  original_T_including_depot_unload_1285  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_886  1
    load_1_6_18  segment_load_conservation_1202  1
    load_1_6_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_888  -25
    arc_1_6_19  connected_order_arc_889  -14
    arc_1_6_19  out_degree_1198  1
    arc_1_6_19  in_degree_1258  1
    arc_1_6_19  original_T_including_depot_unload_1285  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_888  1
    load_1_6_19  segment_load_conservation_1202  1
    load_1_6_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_890  -25
    arc_1_6_20  connected_order_arc_891  -14
    arc_1_6_20  out_degree_1198  1
    arc_1_6_20  in_degree_1264  1
    arc_1_6_20  original_T_including_depot_unload_1285  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_890  1
    load_1_6_20  segment_load_conservation_1202  1
    load_1_6_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_892  -25
    arc_1_6_21  connected_order_arc_893  -14
    arc_1_6_21  out_degree_1198  1
    arc_1_6_21  in_degree_1270  1
    arc_1_6_21  original_T_including_depot_unload_1285  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_892  1
    load_1_6_21  segment_load_conservation_1202  1
    load_1_6_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_22  arc_capacity_894  -25
    arc_1_6_22  connected_order_arc_895  -14
    arc_1_6_22  out_degree_1198  1
    arc_1_6_22  in_degree_1276  1
    arc_1_6_22  original_T_including_depot_unload_1285  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_22  arc_capacity_894  1
    load_1_6_22  segment_load_conservation_1202  1
    load_1_6_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_896  -25
    arc_1_7_0  depot_return_or_bypass_1197  1
    arc_1_7_0  out_degree_1205  1
    arc_1_7_0  original_T_including_depot_unload_1285  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_896  1
    load_1_7_0  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_897  -25
    arc_1_7_6  connected_order_arc_898  -14
    arc_1_7_6  in_degree_1199  1
    arc_1_7_6  out_degree_1205  1
    arc_1_7_6  original_T_including_depot_unload_1285  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_897  1
    load_1_7_6  segment_load_conservation_1202  -1
    load_1_7_6  segment_prefix_lb_1203  1
    load_1_7_6  segment_prefix_ub_1204  1
    load_1_7_6  segment_load_conservation_1209  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_899  -25
    arc_1_7_8  connected_order_arc_900  -14
    arc_1_7_8  out_degree_1205  1
    arc_1_7_8  in_degree_1213  1
    arc_1_7_8  original_T_including_depot_unload_1285  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_899  1
    load_1_7_8  segment_load_conservation_1209  1
    load_1_7_8  segment_load_conservation_1216  -1
    load_1_7_8  segment_prefix_lb_1217  1
    load_1_7_8  segment_prefix_ub_1218  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_901  -25
    arc_1_7_9  connected_order_arc_902  -14
    arc_1_7_9  out_degree_1205  1
    arc_1_7_9  in_degree_1220  1
    arc_1_7_9  original_T_including_depot_unload_1285  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_901  1
    load_1_7_9  segment_load_conservation_1209  1
    load_1_7_9  segment_load_conservation_1223  -1
    load_1_7_9  segment_prefix_lb_1224  1
    load_1_7_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_903  -25
    arc_1_7_10  connected_order_arc_904  -14
    arc_1_7_10  out_degree_1205  1
    arc_1_7_10  in_degree_1227  1
    arc_1_7_10  original_T_including_depot_unload_1285  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_903  1
    load_1_7_10  segment_load_conservation_1209  1
    load_1_7_10  segment_load_conservation_1230  -1
    load_1_7_10  segment_prefix_lb_1231  1
    load_1_7_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_905  -25
    arc_1_7_15  connected_order_arc_906  -14
    arc_1_7_15  out_degree_1205  1
    arc_1_7_15  in_degree_1234  1
    arc_1_7_15  original_T_including_depot_unload_1285  1.4099802576911704e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_905  1
    load_1_7_15  segment_load_conservation_1209  1
    load_1_7_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_907  -25
    arc_1_7_16  connected_order_arc_908  -14
    arc_1_7_16  out_degree_1205  1
    arc_1_7_16  in_degree_1240  1
    arc_1_7_16  original_T_including_depot_unload_1285  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_907  1
    load_1_7_16  segment_load_conservation_1209  1
    load_1_7_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_909  -25
    arc_1_7_17  connected_order_arc_910  -14
    arc_1_7_17  out_degree_1205  1
    arc_1_7_17  in_degree_1246  1
    arc_1_7_17  original_T_including_depot_unload_1285  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_909  1
    load_1_7_17  segment_load_conservation_1209  1
    load_1_7_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_911  -25
    arc_1_7_18  connected_order_arc_912  -14
    arc_1_7_18  out_degree_1205  1
    arc_1_7_18  in_degree_1252  1
    arc_1_7_18  original_T_including_depot_unload_1285  1.2087821033682005e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_911  1
    load_1_7_18  segment_load_conservation_1209  1
    load_1_7_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_913  -25
    arc_1_7_19  connected_order_arc_914  -14
    arc_1_7_19  out_degree_1205  1
    arc_1_7_19  in_degree_1258  1
    arc_1_7_19  original_T_including_depot_unload_1285  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_913  1
    load_1_7_19  segment_load_conservation_1209  1
    load_1_7_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_915  -25
    arc_1_7_20  connected_order_arc_916  -14
    arc_1_7_20  out_degree_1205  1
    arc_1_7_20  in_degree_1264  1
    arc_1_7_20  original_T_including_depot_unload_1285  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_915  1
    load_1_7_20  segment_load_conservation_1209  1
    load_1_7_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_917  -25
    arc_1_7_21  connected_order_arc_918  -14
    arc_1_7_21  out_degree_1205  1
    arc_1_7_21  in_degree_1270  1
    arc_1_7_21  original_T_including_depot_unload_1285  2.1293186465553604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_917  1
    load_1_7_21  segment_load_conservation_1209  1
    load_1_7_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_919  -25
    arc_1_7_22  connected_order_arc_920  -14
    arc_1_7_22  out_degree_1205  1
    arc_1_7_22  in_degree_1276  1
    arc_1_7_22  original_T_including_depot_unload_1285  1.5942479163822793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_919  1
    load_1_7_22  segment_load_conservation_1209  1
    load_1_7_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_921  -25
    arc_1_8_0  depot_return_or_bypass_1197  1
    arc_1_8_0  out_degree_1212  1
    arc_1_8_0  original_T_including_depot_unload_1285  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_921  1
    load_1_8_0  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_922  -25
    arc_1_8_6  connected_order_arc_923  -14
    arc_1_8_6  in_degree_1199  1
    arc_1_8_6  out_degree_1212  1
    arc_1_8_6  original_T_including_depot_unload_1285  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_922  1
    load_1_8_6  segment_load_conservation_1202  -1
    load_1_8_6  segment_prefix_lb_1203  1
    load_1_8_6  segment_prefix_ub_1204  1
    load_1_8_6  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_924  -25
    arc_1_8_7  connected_order_arc_925  -14
    arc_1_8_7  in_degree_1206  1
    arc_1_8_7  out_degree_1212  1
    arc_1_8_7  original_T_including_depot_unload_1285  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_924  1
    load_1_8_7  segment_load_conservation_1209  -1
    load_1_8_7  segment_prefix_lb_1210  1
    load_1_8_7  segment_prefix_ub_1211  1
    load_1_8_7  segment_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_926  -25
    arc_1_8_9  connected_order_arc_927  -14
    arc_1_8_9  out_degree_1212  1
    arc_1_8_9  in_degree_1220  1
    arc_1_8_9  original_T_including_depot_unload_1285  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_926  1
    load_1_8_9  segment_load_conservation_1216  1
    load_1_8_9  segment_load_conservation_1223  -1
    load_1_8_9  segment_prefix_lb_1224  1
    load_1_8_9  segment_prefix_ub_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_928  -25
    arc_1_8_10  connected_order_arc_929  -14
    arc_1_8_10  out_degree_1212  1
    arc_1_8_10  in_degree_1227  1
    arc_1_8_10  original_T_including_depot_unload_1285  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_928  1
    load_1_8_10  segment_load_conservation_1216  1
    load_1_8_10  segment_load_conservation_1230  -1
    load_1_8_10  segment_prefix_lb_1231  1
    load_1_8_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_930  -25
    arc_1_8_15  connected_order_arc_931  -14
    arc_1_8_15  out_degree_1212  1
    arc_1_8_15  in_degree_1234  1
    arc_1_8_15  original_T_including_depot_unload_1285  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_930  1
    load_1_8_15  segment_load_conservation_1216  1
    load_1_8_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_932  -25
    arc_1_8_16  connected_order_arc_933  -14
    arc_1_8_16  out_degree_1212  1
    arc_1_8_16  in_degree_1240  1
    arc_1_8_16  original_T_including_depot_unload_1285  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_932  1
    load_1_8_16  segment_load_conservation_1216  1
    load_1_8_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_934  -25
    arc_1_8_17  connected_order_arc_935  -14
    arc_1_8_17  out_degree_1212  1
    arc_1_8_17  in_degree_1246  1
    arc_1_8_17  original_T_including_depot_unload_1285  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_934  1
    load_1_8_17  segment_load_conservation_1216  1
    load_1_8_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_936  -25
    arc_1_8_18  connected_order_arc_937  -14
    arc_1_8_18  out_degree_1212  1
    arc_1_8_18  in_degree_1252  1
    arc_1_8_18  original_T_including_depot_unload_1285  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_936  1
    load_1_8_18  segment_load_conservation_1216  1
    load_1_8_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_938  -25
    arc_1_8_19  connected_order_arc_939  -14
    arc_1_8_19  out_degree_1212  1
    arc_1_8_19  in_degree_1258  1
    arc_1_8_19  original_T_including_depot_unload_1285  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_938  1
    load_1_8_19  segment_load_conservation_1216  1
    load_1_8_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_940  -25
    arc_1_8_20  connected_order_arc_941  -14
    arc_1_8_20  out_degree_1212  1
    arc_1_8_20  in_degree_1264  1
    arc_1_8_20  original_T_including_depot_unload_1285  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_940  1
    load_1_8_20  segment_load_conservation_1216  1
    load_1_8_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_942  -25
    arc_1_8_21  connected_order_arc_943  -14
    arc_1_8_21  out_degree_1212  1
    arc_1_8_21  in_degree_1270  1
    arc_1_8_21  original_T_including_depot_unload_1285  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_942  1
    load_1_8_21  segment_load_conservation_1216  1
    load_1_8_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_944  -25
    arc_1_8_22  connected_order_arc_945  -14
    arc_1_8_22  out_degree_1212  1
    arc_1_8_22  in_degree_1276  1
    arc_1_8_22  original_T_including_depot_unload_1285  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_944  1
    load_1_8_22  segment_load_conservation_1216  1
    load_1_8_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_946  -25
    arc_1_9_0  depot_return_or_bypass_1197  1
    arc_1_9_0  out_degree_1219  1
    arc_1_9_0  original_T_including_depot_unload_1285  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_946  1
    load_1_9_0  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_947  -25
    arc_1_9_6  connected_order_arc_948  -14
    arc_1_9_6  in_degree_1199  1
    arc_1_9_6  out_degree_1219  1
    arc_1_9_6  original_T_including_depot_unload_1285  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_947  1
    load_1_9_6  segment_load_conservation_1202  -1
    load_1_9_6  segment_prefix_lb_1203  1
    load_1_9_6  segment_prefix_ub_1204  1
    load_1_9_6  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_949  -25
    arc_1_9_7  connected_order_arc_950  -14
    arc_1_9_7  in_degree_1206  1
    arc_1_9_7  out_degree_1219  1
    arc_1_9_7  original_T_including_depot_unload_1285  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_949  1
    load_1_9_7  segment_load_conservation_1209  -1
    load_1_9_7  segment_prefix_lb_1210  1
    load_1_9_7  segment_prefix_ub_1211  1
    load_1_9_7  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_951  -25
    arc_1_9_8  connected_order_arc_952  -14
    arc_1_9_8  in_degree_1213  1
    arc_1_9_8  out_degree_1219  1
    arc_1_9_8  original_T_including_depot_unload_1285  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_951  1
    load_1_9_8  segment_load_conservation_1216  -1
    load_1_9_8  segment_prefix_lb_1217  1
    load_1_9_8  segment_prefix_ub_1218  1
    load_1_9_8  segment_load_conservation_1223  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_953  -25
    arc_1_9_10  connected_order_arc_954  -14
    arc_1_9_10  out_degree_1219  1
    arc_1_9_10  in_degree_1227  1
    arc_1_9_10  original_T_including_depot_unload_1285  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_953  1
    load_1_9_10  segment_load_conservation_1223  1
    load_1_9_10  segment_load_conservation_1230  -1
    load_1_9_10  segment_prefix_lb_1231  1
    load_1_9_10  segment_prefix_ub_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_955  -25
    arc_1_9_15  connected_order_arc_956  -14
    arc_1_9_15  out_degree_1219  1
    arc_1_9_15  in_degree_1234  1
    arc_1_9_15  original_T_including_depot_unload_1285  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_955  1
    load_1_9_15  segment_load_conservation_1223  1
    load_1_9_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_957  -25
    arc_1_9_16  connected_order_arc_958  -14
    arc_1_9_16  out_degree_1219  1
    arc_1_9_16  in_degree_1240  1
    arc_1_9_16  original_T_including_depot_unload_1285  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_957  1
    load_1_9_16  segment_load_conservation_1223  1
    load_1_9_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_959  -25
    arc_1_9_17  connected_order_arc_960  -14
    arc_1_9_17  out_degree_1219  1
    arc_1_9_17  in_degree_1246  1
    arc_1_9_17  original_T_including_depot_unload_1285  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_959  1
    load_1_9_17  segment_load_conservation_1223  1
    load_1_9_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_961  -25
    arc_1_9_18  connected_order_arc_962  -14
    arc_1_9_18  out_degree_1219  1
    arc_1_9_18  in_degree_1252  1
    arc_1_9_18  original_T_including_depot_unload_1285  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_961  1
    load_1_9_18  segment_load_conservation_1223  1
    load_1_9_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_963  -25
    arc_1_9_19  connected_order_arc_964  -14
    arc_1_9_19  out_degree_1219  1
    arc_1_9_19  in_degree_1258  1
    arc_1_9_19  original_T_including_depot_unload_1285  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_963  1
    load_1_9_19  segment_load_conservation_1223  1
    load_1_9_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_965  -25
    arc_1_9_20  connected_order_arc_966  -14
    arc_1_9_20  out_degree_1219  1
    arc_1_9_20  in_degree_1264  1
    arc_1_9_20  original_T_including_depot_unload_1285  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_965  1
    load_1_9_20  segment_load_conservation_1223  1
    load_1_9_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_967  -25
    arc_1_9_21  connected_order_arc_968  -14
    arc_1_9_21  out_degree_1219  1
    arc_1_9_21  in_degree_1270  1
    arc_1_9_21  original_T_including_depot_unload_1285  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_967  1
    load_1_9_21  segment_load_conservation_1223  1
    load_1_9_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_969  -25
    arc_1_9_22  connected_order_arc_970  -14
    arc_1_9_22  out_degree_1219  1
    arc_1_9_22  in_degree_1276  1
    arc_1_9_22  original_T_including_depot_unload_1285  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_969  1
    load_1_9_22  segment_load_conservation_1223  1
    load_1_9_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_971  -25
    arc_1_10_0  depot_return_or_bypass_1197  1
    arc_1_10_0  out_degree_1226  1
    arc_1_10_0  original_T_including_depot_unload_1285  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_971  1
    load_1_10_0  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_972  -25
    arc_1_10_6  connected_order_arc_973  -14
    arc_1_10_6  in_degree_1199  1
    arc_1_10_6  out_degree_1226  1
    arc_1_10_6  original_T_including_depot_unload_1285  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_972  1
    load_1_10_6  segment_load_conservation_1202  -1
    load_1_10_6  segment_prefix_lb_1203  1
    load_1_10_6  segment_prefix_ub_1204  1
    load_1_10_6  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_974  -25
    arc_1_10_7  connected_order_arc_975  -14
    arc_1_10_7  in_degree_1206  1
    arc_1_10_7  out_degree_1226  1
    arc_1_10_7  original_T_including_depot_unload_1285  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_974  1
    load_1_10_7  segment_load_conservation_1209  -1
    load_1_10_7  segment_prefix_lb_1210  1
    load_1_10_7  segment_prefix_ub_1211  1
    load_1_10_7  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_976  -25
    arc_1_10_8  connected_order_arc_977  -14
    arc_1_10_8  in_degree_1213  1
    arc_1_10_8  out_degree_1226  1
    arc_1_10_8  original_T_including_depot_unload_1285  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_976  1
    load_1_10_8  segment_load_conservation_1216  -1
    load_1_10_8  segment_prefix_lb_1217  1
    load_1_10_8  segment_prefix_ub_1218  1
    load_1_10_8  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_978  -25
    arc_1_10_9  connected_order_arc_979  -14
    arc_1_10_9  in_degree_1220  1
    arc_1_10_9  out_degree_1226  1
    arc_1_10_9  original_T_including_depot_unload_1285  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_978  1
    load_1_10_9  segment_load_conservation_1223  -1
    load_1_10_9  segment_prefix_lb_1224  1
    load_1_10_9  segment_prefix_ub_1225  1
    load_1_10_9  segment_load_conservation_1230  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_980  -25
    arc_1_10_15  connected_order_arc_981  -14
    arc_1_10_15  out_degree_1226  1
    arc_1_10_15  in_degree_1234  1
    arc_1_10_15  original_T_including_depot_unload_1285  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_980  1
    load_1_10_15  segment_load_conservation_1230  1
    load_1_10_15  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_982  -25
    arc_1_10_16  connected_order_arc_983  -14
    arc_1_10_16  out_degree_1226  1
    arc_1_10_16  in_degree_1240  1
    arc_1_10_16  original_T_including_depot_unload_1285  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_982  1
    load_1_10_16  segment_load_conservation_1230  1
    load_1_10_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_984  -25
    arc_1_10_17  connected_order_arc_985  -14
    arc_1_10_17  out_degree_1226  1
    arc_1_10_17  in_degree_1246  1
    arc_1_10_17  original_T_including_depot_unload_1285  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_984  1
    load_1_10_17  segment_load_conservation_1230  1
    load_1_10_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_986  -25
    arc_1_10_18  connected_order_arc_987  -14
    arc_1_10_18  out_degree_1226  1
    arc_1_10_18  in_degree_1252  1
    arc_1_10_18  original_T_including_depot_unload_1285  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_986  1
    load_1_10_18  segment_load_conservation_1230  1
    load_1_10_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_988  -25
    arc_1_10_19  connected_order_arc_989  -14
    arc_1_10_19  out_degree_1226  1
    arc_1_10_19  in_degree_1258  1
    arc_1_10_19  original_T_including_depot_unload_1285  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_988  1
    load_1_10_19  segment_load_conservation_1230  1
    load_1_10_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_990  -25
    arc_1_10_20  connected_order_arc_991  -14
    arc_1_10_20  out_degree_1226  1
    arc_1_10_20  in_degree_1264  1
    arc_1_10_20  original_T_including_depot_unload_1285  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_990  1
    load_1_10_20  segment_load_conservation_1230  1
    load_1_10_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_992  -25
    arc_1_10_21  connected_order_arc_993  -14
    arc_1_10_21  out_degree_1226  1
    arc_1_10_21  in_degree_1270  1
    arc_1_10_21  original_T_including_depot_unload_1285  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_992  1
    load_1_10_21  segment_load_conservation_1230  1
    load_1_10_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_994  -25
    arc_1_10_22  connected_order_arc_995  -14
    arc_1_10_22  out_degree_1226  1
    arc_1_10_22  in_degree_1276  1
    arc_1_10_22  original_T_including_depot_unload_1285  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_994  1
    load_1_10_22  segment_load_conservation_1230  1
    load_1_10_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_996  -25
    arc_1_15_0  depot_return_or_bypass_1197  1
    arc_1_15_0  out_degree_1233  1
    arc_1_15_0  original_T_including_depot_unload_1285  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_996  1
    load_1_15_0  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_997  -25
    arc_1_15_6  connected_order_arc_998  -14
    arc_1_15_6  in_degree_1199  1
    arc_1_15_6  out_degree_1233  1
    arc_1_15_6  original_T_including_depot_unload_1285  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_997  1
    load_1_15_6  segment_load_conservation_1202  -1
    load_1_15_6  segment_prefix_lb_1203  1
    load_1_15_6  segment_prefix_ub_1204  1
    load_1_15_6  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_999  -25
    arc_1_15_7  connected_order_arc_1000  -14
    arc_1_15_7  in_degree_1206  1
    arc_1_15_7  out_degree_1233  1
    arc_1_15_7  original_T_including_depot_unload_1285  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_999  1
    load_1_15_7  segment_load_conservation_1209  -1
    load_1_15_7  segment_prefix_lb_1210  1
    load_1_15_7  segment_prefix_ub_1211  1
    load_1_15_7  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1001  -25
    arc_1_15_8  connected_order_arc_1002  -14
    arc_1_15_8  in_degree_1213  1
    arc_1_15_8  out_degree_1233  1
    arc_1_15_8  original_T_including_depot_unload_1285  1.3251252487627862e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1001  1
    load_1_15_8  segment_load_conservation_1216  -1
    load_1_15_8  segment_prefix_lb_1217  1
    load_1_15_8  segment_prefix_ub_1218  1
    load_1_15_8  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1003  -25
    arc_1_15_9  connected_order_arc_1004  -14
    arc_1_15_9  in_degree_1220  1
    arc_1_15_9  out_degree_1233  1
    arc_1_15_9  original_T_including_depot_unload_1285  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1003  1
    load_1_15_9  segment_load_conservation_1223  -1
    load_1_15_9  segment_prefix_lb_1224  1
    load_1_15_9  segment_prefix_ub_1225  1
    load_1_15_9  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1005  -25
    arc_1_15_10  connected_order_arc_1006  -14
    arc_1_15_10  in_degree_1227  1
    arc_1_15_10  out_degree_1233  1
    arc_1_15_10  original_T_including_depot_unload_1285  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1005  1
    load_1_15_10  segment_load_conservation_1230  -1
    load_1_15_10  segment_prefix_lb_1231  1
    load_1_15_10  segment_prefix_ub_1232  1
    load_1_15_10  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1007  -25
    arc_1_15_16  connected_order_arc_1008  -14
    arc_1_15_16  out_degree_1233  1
    arc_1_15_16  in_degree_1240  1
    arc_1_15_16  original_T_including_depot_unload_1285  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1007  1
    load_1_15_16  free_load_conservation_1238  1
    load_1_15_16  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1009  -25
    arc_1_15_17  connected_order_arc_1010  -14
    arc_1_15_17  out_degree_1233  1
    arc_1_15_17  in_degree_1246  1
    arc_1_15_17  original_T_including_depot_unload_1285  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1009  1
    load_1_15_17  free_load_conservation_1238  1
    load_1_15_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1011  -25
    arc_1_15_18  connected_order_arc_1012  -14
    arc_1_15_18  out_degree_1233  1
    arc_1_15_18  in_degree_1252  1
    arc_1_15_18  original_T_including_depot_unload_1285  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1011  1
    load_1_15_18  free_load_conservation_1238  1
    load_1_15_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1013  -25
    arc_1_15_19  connected_order_arc_1014  -14
    arc_1_15_19  out_degree_1233  1
    arc_1_15_19  in_degree_1258  1
    arc_1_15_19  original_T_including_depot_unload_1285  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1013  1
    load_1_15_19  free_load_conservation_1238  1
    load_1_15_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1015  -25
    arc_1_15_20  connected_order_arc_1016  -14
    arc_1_15_20  out_degree_1233  1
    arc_1_15_20  in_degree_1264  1
    arc_1_15_20  original_T_including_depot_unload_1285  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1015  1
    load_1_15_20  free_load_conservation_1238  1
    load_1_15_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1017  -25
    arc_1_15_21  connected_order_arc_1018  -14
    arc_1_15_21  out_degree_1233  1
    arc_1_15_21  in_degree_1270  1
    arc_1_15_21  original_T_including_depot_unload_1285  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1017  1
    load_1_15_21  free_load_conservation_1238  1
    load_1_15_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_1019  -25
    arc_1_15_22  connected_order_arc_1020  -14
    arc_1_15_22  out_degree_1233  1
    arc_1_15_22  in_degree_1276  1
    arc_1_15_22  original_T_including_depot_unload_1285  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_1019  1
    load_1_15_22  free_load_conservation_1238  1
    load_1_15_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1021  -25
    arc_1_16_0  depot_return_or_bypass_1197  1
    arc_1_16_0  out_degree_1239  1
    arc_1_16_0  original_T_including_depot_unload_1285  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1021  1
    load_1_16_0  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1022  -25
    arc_1_16_6  connected_order_arc_1023  -14
    arc_1_16_6  in_degree_1199  1
    arc_1_16_6  out_degree_1239  1
    arc_1_16_6  original_T_including_depot_unload_1285  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1022  1
    load_1_16_6  segment_load_conservation_1202  -1
    load_1_16_6  segment_prefix_lb_1203  1
    load_1_16_6  segment_prefix_ub_1204  1
    load_1_16_6  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1024  -25
    arc_1_16_7  connected_order_arc_1025  -14
    arc_1_16_7  in_degree_1206  1
    arc_1_16_7  out_degree_1239  1
    arc_1_16_7  original_T_including_depot_unload_1285  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1024  1
    load_1_16_7  segment_load_conservation_1209  -1
    load_1_16_7  segment_prefix_lb_1210  1
    load_1_16_7  segment_prefix_ub_1211  1
    load_1_16_7  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1026  -25
    arc_1_16_8  connected_order_arc_1027  -14
    arc_1_16_8  in_degree_1213  1
    arc_1_16_8  out_degree_1239  1
    arc_1_16_8  original_T_including_depot_unload_1285  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1026  1
    load_1_16_8  segment_load_conservation_1216  -1
    load_1_16_8  segment_prefix_lb_1217  1
    load_1_16_8  segment_prefix_ub_1218  1
    load_1_16_8  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1028  -25
    arc_1_16_9  connected_order_arc_1029  -14
    arc_1_16_9  in_degree_1220  1
    arc_1_16_9  out_degree_1239  1
    arc_1_16_9  original_T_including_depot_unload_1285  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1028  1
    load_1_16_9  segment_load_conservation_1223  -1
    load_1_16_9  segment_prefix_lb_1224  1
    load_1_16_9  segment_prefix_ub_1225  1
    load_1_16_9  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1030  -25
    arc_1_16_10  connected_order_arc_1031  -14
    arc_1_16_10  in_degree_1227  1
    arc_1_16_10  out_degree_1239  1
    arc_1_16_10  original_T_including_depot_unload_1285  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1030  1
    load_1_16_10  segment_load_conservation_1230  -1
    load_1_16_10  segment_prefix_lb_1231  1
    load_1_16_10  segment_prefix_ub_1232  1
    load_1_16_10  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1032  -25
    arc_1_16_15  connected_order_arc_1033  -14
    arc_1_16_15  in_degree_1234  1
    arc_1_16_15  out_degree_1239  1
    arc_1_16_15  original_T_including_depot_unload_1285  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1032  1
    load_1_16_15  free_load_conservation_1238  -1
    load_1_16_15  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1034  -25
    arc_1_16_17  connected_order_arc_1035  -14
    arc_1_16_17  out_degree_1239  1
    arc_1_16_17  in_degree_1246  1
    arc_1_16_17  original_T_including_depot_unload_1285  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1034  1
    load_1_16_17  free_load_conservation_1244  1
    load_1_16_17  free_load_conservation_1250  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1036  -25
    arc_1_16_18  connected_order_arc_1037  -14
    arc_1_16_18  out_degree_1239  1
    arc_1_16_18  in_degree_1252  1
    arc_1_16_18  original_T_including_depot_unload_1285  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1036  1
    load_1_16_18  free_load_conservation_1244  1
    load_1_16_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1038  -25
    arc_1_16_19  connected_order_arc_1039  -14
    arc_1_16_19  out_degree_1239  1
    arc_1_16_19  in_degree_1258  1
    arc_1_16_19  original_T_including_depot_unload_1285  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1038  1
    load_1_16_19  free_load_conservation_1244  1
    load_1_16_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1040  -25
    arc_1_16_20  connected_order_arc_1041  -14
    arc_1_16_20  out_degree_1239  1
    arc_1_16_20  in_degree_1264  1
    arc_1_16_20  original_T_including_depot_unload_1285  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1040  1
    load_1_16_20  free_load_conservation_1244  1
    load_1_16_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1042  -25
    arc_1_16_21  connected_order_arc_1043  -14
    arc_1_16_21  out_degree_1239  1
    arc_1_16_21  in_degree_1270  1
    arc_1_16_21  original_T_including_depot_unload_1285  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1042  1
    load_1_16_21  free_load_conservation_1244  1
    load_1_16_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1044  -25
    arc_1_16_22  connected_order_arc_1045  -14
    arc_1_16_22  out_degree_1239  1
    arc_1_16_22  in_degree_1276  1
    arc_1_16_22  original_T_including_depot_unload_1285  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1044  1
    load_1_16_22  free_load_conservation_1244  1
    load_1_16_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1046  -25
    arc_1_17_0  depot_return_or_bypass_1197  1
    arc_1_17_0  out_degree_1245  1
    arc_1_17_0  original_T_including_depot_unload_1285  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1046  1
    load_1_17_0  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1047  -25
    arc_1_17_6  connected_order_arc_1048  -14
    arc_1_17_6  in_degree_1199  1
    arc_1_17_6  out_degree_1245  1
    arc_1_17_6  original_T_including_depot_unload_1285  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1047  1
    load_1_17_6  segment_load_conservation_1202  -1
    load_1_17_6  segment_prefix_lb_1203  1
    load_1_17_6  segment_prefix_ub_1204  1
    load_1_17_6  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1049  -25
    arc_1_17_7  connected_order_arc_1050  -14
    arc_1_17_7  in_degree_1206  1
    arc_1_17_7  out_degree_1245  1
    arc_1_17_7  original_T_including_depot_unload_1285  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1049  1
    load_1_17_7  segment_load_conservation_1209  -1
    load_1_17_7  segment_prefix_lb_1210  1
    load_1_17_7  segment_prefix_ub_1211  1
    load_1_17_7  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1051  -25
    arc_1_17_8  connected_order_arc_1052  -14
    arc_1_17_8  in_degree_1213  1
    arc_1_17_8  out_degree_1245  1
    arc_1_17_8  original_T_including_depot_unload_1285  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1051  1
    load_1_17_8  segment_load_conservation_1216  -1
    load_1_17_8  segment_prefix_lb_1217  1
    load_1_17_8  segment_prefix_ub_1218  1
    load_1_17_8  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1053  -25
    arc_1_17_9  connected_order_arc_1054  -14
    arc_1_17_9  in_degree_1220  1
    arc_1_17_9  out_degree_1245  1
    arc_1_17_9  original_T_including_depot_unload_1285  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1053  1
    load_1_17_9  segment_load_conservation_1223  -1
    load_1_17_9  segment_prefix_lb_1224  1
    load_1_17_9  segment_prefix_ub_1225  1
    load_1_17_9  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1055  -25
    arc_1_17_10  connected_order_arc_1056  -14
    arc_1_17_10  in_degree_1227  1
    arc_1_17_10  out_degree_1245  1
    arc_1_17_10  original_T_including_depot_unload_1285  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1055  1
    load_1_17_10  segment_load_conservation_1230  -1
    load_1_17_10  segment_prefix_lb_1231  1
    load_1_17_10  segment_prefix_ub_1232  1
    load_1_17_10  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1057  -25
    arc_1_17_15  connected_order_arc_1058  -14
    arc_1_17_15  in_degree_1234  1
    arc_1_17_15  out_degree_1245  1
    arc_1_17_15  original_T_including_depot_unload_1285  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1057  1
    load_1_17_15  free_load_conservation_1238  -1
    load_1_17_15  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1059  -25
    arc_1_17_16  connected_order_arc_1060  -14
    arc_1_17_16  in_degree_1240  1
    arc_1_17_16  out_degree_1245  1
    arc_1_17_16  original_T_including_depot_unload_1285  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1059  1
    load_1_17_16  free_load_conservation_1244  -1
    load_1_17_16  free_load_conservation_1250  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1061  -25
    arc_1_17_18  connected_order_arc_1062  -14
    arc_1_17_18  out_degree_1245  1
    arc_1_17_18  in_degree_1252  1
    arc_1_17_18  original_T_including_depot_unload_1285  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1061  1
    load_1_17_18  free_load_conservation_1250  1
    load_1_17_18  free_load_conservation_1256  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1063  -25
    arc_1_17_19  connected_order_arc_1064  -14
    arc_1_17_19  out_degree_1245  1
    arc_1_17_19  in_degree_1258  1
    arc_1_17_19  original_T_including_depot_unload_1285  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1063  1
    load_1_17_19  free_load_conservation_1250  1
    load_1_17_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1065  -25
    arc_1_17_20  connected_order_arc_1066  -14
    arc_1_17_20  out_degree_1245  1
    arc_1_17_20  in_degree_1264  1
    arc_1_17_20  original_T_including_depot_unload_1285  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1065  1
    load_1_17_20  free_load_conservation_1250  1
    load_1_17_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1067  -25
    arc_1_17_21  connected_order_arc_1068  -14
    arc_1_17_21  out_degree_1245  1
    arc_1_17_21  in_degree_1270  1
    arc_1_17_21  original_T_including_depot_unload_1285  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1067  1
    load_1_17_21  free_load_conservation_1250  1
    load_1_17_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1069  -25
    arc_1_17_22  connected_order_arc_1070  -14
    arc_1_17_22  out_degree_1245  1
    arc_1_17_22  in_degree_1276  1
    arc_1_17_22  original_T_including_depot_unload_1285  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1069  1
    load_1_17_22  free_load_conservation_1250  1
    load_1_17_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1071  -25
    arc_1_18_0  depot_return_or_bypass_1197  1
    arc_1_18_0  out_degree_1251  1
    arc_1_18_0  original_T_including_depot_unload_1285  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1071  1
    load_1_18_0  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1072  -25
    arc_1_18_6  connected_order_arc_1073  -14
    arc_1_18_6  in_degree_1199  1
    arc_1_18_6  out_degree_1251  1
    arc_1_18_6  original_T_including_depot_unload_1285  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1072  1
    load_1_18_6  segment_load_conservation_1202  -1
    load_1_18_6  segment_prefix_lb_1203  1
    load_1_18_6  segment_prefix_ub_1204  1
    load_1_18_6  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1074  -25
    arc_1_18_7  connected_order_arc_1075  -14
    arc_1_18_7  in_degree_1206  1
    arc_1_18_7  out_degree_1251  1
    arc_1_18_7  original_T_including_depot_unload_1285  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1074  1
    load_1_18_7  segment_load_conservation_1209  -1
    load_1_18_7  segment_prefix_lb_1210  1
    load_1_18_7  segment_prefix_ub_1211  1
    load_1_18_7  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1076  -25
    arc_1_18_8  connected_order_arc_1077  -14
    arc_1_18_8  in_degree_1213  1
    arc_1_18_8  out_degree_1251  1
    arc_1_18_8  original_T_including_depot_unload_1285  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1076  1
    load_1_18_8  segment_load_conservation_1216  -1
    load_1_18_8  segment_prefix_lb_1217  1
    load_1_18_8  segment_prefix_ub_1218  1
    load_1_18_8  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1078  -25
    arc_1_18_9  connected_order_arc_1079  -14
    arc_1_18_9  in_degree_1220  1
    arc_1_18_9  out_degree_1251  1
    arc_1_18_9  original_T_including_depot_unload_1285  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1078  1
    load_1_18_9  segment_load_conservation_1223  -1
    load_1_18_9  segment_prefix_lb_1224  1
    load_1_18_9  segment_prefix_ub_1225  1
    load_1_18_9  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1080  -25
    arc_1_18_10  connected_order_arc_1081  -14
    arc_1_18_10  in_degree_1227  1
    arc_1_18_10  out_degree_1251  1
    arc_1_18_10  original_T_including_depot_unload_1285  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1080  1
    load_1_18_10  segment_load_conservation_1230  -1
    load_1_18_10  segment_prefix_lb_1231  1
    load_1_18_10  segment_prefix_ub_1232  1
    load_1_18_10  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1082  -25
    arc_1_18_15  connected_order_arc_1083  -14
    arc_1_18_15  in_degree_1234  1
    arc_1_18_15  out_degree_1251  1
    arc_1_18_15  original_T_including_depot_unload_1285  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1082  1
    load_1_18_15  free_load_conservation_1238  -1
    load_1_18_15  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1084  -25
    arc_1_18_16  connected_order_arc_1085  -14
    arc_1_18_16  in_degree_1240  1
    arc_1_18_16  out_degree_1251  1
    arc_1_18_16  original_T_including_depot_unload_1285  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1084  1
    load_1_18_16  free_load_conservation_1244  -1
    load_1_18_16  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1086  -25
    arc_1_18_17  connected_order_arc_1087  -14
    arc_1_18_17  in_degree_1246  1
    arc_1_18_17  out_degree_1251  1
    arc_1_18_17  original_T_including_depot_unload_1285  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1086  1
    load_1_18_17  free_load_conservation_1250  -1
    load_1_18_17  free_load_conservation_1256  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1088  -25
    arc_1_18_19  connected_order_arc_1089  -14
    arc_1_18_19  out_degree_1251  1
    arc_1_18_19  in_degree_1258  1
    arc_1_18_19  original_T_including_depot_unload_1285  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1088  1
    load_1_18_19  free_load_conservation_1256  1
    load_1_18_19  free_load_conservation_1262  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1090  -25
    arc_1_18_20  connected_order_arc_1091  -14
    arc_1_18_20  out_degree_1251  1
    arc_1_18_20  in_degree_1264  1
    arc_1_18_20  original_T_including_depot_unload_1285  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1090  1
    load_1_18_20  free_load_conservation_1256  1
    load_1_18_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1092  -25
    arc_1_18_21  connected_order_arc_1093  -14
    arc_1_18_21  out_degree_1251  1
    arc_1_18_21  in_degree_1270  1
    arc_1_18_21  original_T_including_depot_unload_1285  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1092  1
    load_1_18_21  free_load_conservation_1256  1
    load_1_18_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1094  -25
    arc_1_18_22  connected_order_arc_1095  -14
    arc_1_18_22  out_degree_1251  1
    arc_1_18_22  in_degree_1276  1
    arc_1_18_22  original_T_including_depot_unload_1285  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1094  1
    load_1_18_22  free_load_conservation_1256  1
    load_1_18_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1096  -25
    arc_1_19_0  depot_return_or_bypass_1197  1
    arc_1_19_0  out_degree_1257  1
    arc_1_19_0  original_T_including_depot_unload_1285  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1096  1
    load_1_19_0  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1097  -25
    arc_1_19_6  connected_order_arc_1098  -14
    arc_1_19_6  in_degree_1199  1
    arc_1_19_6  out_degree_1257  1
    arc_1_19_6  original_T_including_depot_unload_1285  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1097  1
    load_1_19_6  segment_load_conservation_1202  -1
    load_1_19_6  segment_prefix_lb_1203  1
    load_1_19_6  segment_prefix_ub_1204  1
    load_1_19_6  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1099  -25
    arc_1_19_7  connected_order_arc_1100  -14
    arc_1_19_7  in_degree_1206  1
    arc_1_19_7  out_degree_1257  1
    arc_1_19_7  original_T_including_depot_unload_1285  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1099  1
    load_1_19_7  segment_load_conservation_1209  -1
    load_1_19_7  segment_prefix_lb_1210  1
    load_1_19_7  segment_prefix_ub_1211  1
    load_1_19_7  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1101  -25
    arc_1_19_8  connected_order_arc_1102  -14
    arc_1_19_8  in_degree_1213  1
    arc_1_19_8  out_degree_1257  1
    arc_1_19_8  original_T_including_depot_unload_1285  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1101  1
    load_1_19_8  segment_load_conservation_1216  -1
    load_1_19_8  segment_prefix_lb_1217  1
    load_1_19_8  segment_prefix_ub_1218  1
    load_1_19_8  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1103  -25
    arc_1_19_9  connected_order_arc_1104  -14
    arc_1_19_9  in_degree_1220  1
    arc_1_19_9  out_degree_1257  1
    arc_1_19_9  original_T_including_depot_unload_1285  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1103  1
    load_1_19_9  segment_load_conservation_1223  -1
    load_1_19_9  segment_prefix_lb_1224  1
    load_1_19_9  segment_prefix_ub_1225  1
    load_1_19_9  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1105  -25
    arc_1_19_10  connected_order_arc_1106  -14
    arc_1_19_10  in_degree_1227  1
    arc_1_19_10  out_degree_1257  1
    arc_1_19_10  original_T_including_depot_unload_1285  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1105  1
    load_1_19_10  segment_load_conservation_1230  -1
    load_1_19_10  segment_prefix_lb_1231  1
    load_1_19_10  segment_prefix_ub_1232  1
    load_1_19_10  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1107  -25
    arc_1_19_15  connected_order_arc_1108  -14
    arc_1_19_15  in_degree_1234  1
    arc_1_19_15  out_degree_1257  1
    arc_1_19_15  original_T_including_depot_unload_1285  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1107  1
    load_1_19_15  free_load_conservation_1238  -1
    load_1_19_15  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1109  -25
    arc_1_19_16  connected_order_arc_1110  -14
    arc_1_19_16  in_degree_1240  1
    arc_1_19_16  out_degree_1257  1
    arc_1_19_16  original_T_including_depot_unload_1285  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1109  1
    load_1_19_16  free_load_conservation_1244  -1
    load_1_19_16  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1111  -25
    arc_1_19_17  connected_order_arc_1112  -14
    arc_1_19_17  in_degree_1246  1
    arc_1_19_17  out_degree_1257  1
    arc_1_19_17  original_T_including_depot_unload_1285  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1111  1
    load_1_19_17  free_load_conservation_1250  -1
    load_1_19_17  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1113  -25
    arc_1_19_18  connected_order_arc_1114  -14
    arc_1_19_18  in_degree_1252  1
    arc_1_19_18  out_degree_1257  1
    arc_1_19_18  original_T_including_depot_unload_1285  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1113  1
    load_1_19_18  free_load_conservation_1256  -1
    load_1_19_18  free_load_conservation_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1115  -25
    arc_1_19_20  connected_order_arc_1116  -14
    arc_1_19_20  out_degree_1257  1
    arc_1_19_20  in_degree_1264  1
    arc_1_19_20  original_T_including_depot_unload_1285  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1115  1
    load_1_19_20  free_load_conservation_1262  1
    load_1_19_20  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1117  -25
    arc_1_19_21  connected_order_arc_1118  -14
    arc_1_19_21  out_degree_1257  1
    arc_1_19_21  in_degree_1270  1
    arc_1_19_21  original_T_including_depot_unload_1285  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1117  1
    load_1_19_21  free_load_conservation_1262  1
    load_1_19_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1119  -25
    arc_1_19_22  connected_order_arc_1120  -14
    arc_1_19_22  out_degree_1257  1
    arc_1_19_22  in_degree_1276  1
    arc_1_19_22  original_T_including_depot_unload_1285  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1119  1
    load_1_19_22  free_load_conservation_1262  1
    load_1_19_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1121  -25
    arc_1_20_0  depot_return_or_bypass_1197  1
    arc_1_20_0  out_degree_1263  1
    arc_1_20_0  original_T_including_depot_unload_1285  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1121  1
    load_1_20_0  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1122  -25
    arc_1_20_6  connected_order_arc_1123  -14
    arc_1_20_6  in_degree_1199  1
    arc_1_20_6  out_degree_1263  1
    arc_1_20_6  original_T_including_depot_unload_1285  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1122  1
    load_1_20_6  segment_load_conservation_1202  -1
    load_1_20_6  segment_prefix_lb_1203  1
    load_1_20_6  segment_prefix_ub_1204  1
    load_1_20_6  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1124  -25
    arc_1_20_7  connected_order_arc_1125  -14
    arc_1_20_7  in_degree_1206  1
    arc_1_20_7  out_degree_1263  1
    arc_1_20_7  original_T_including_depot_unload_1285  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1124  1
    load_1_20_7  segment_load_conservation_1209  -1
    load_1_20_7  segment_prefix_lb_1210  1
    load_1_20_7  segment_prefix_ub_1211  1
    load_1_20_7  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1126  -25
    arc_1_20_8  connected_order_arc_1127  -14
    arc_1_20_8  in_degree_1213  1
    arc_1_20_8  out_degree_1263  1
    arc_1_20_8  original_T_including_depot_unload_1285  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1126  1
    load_1_20_8  segment_load_conservation_1216  -1
    load_1_20_8  segment_prefix_lb_1217  1
    load_1_20_8  segment_prefix_ub_1218  1
    load_1_20_8  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1128  -25
    arc_1_20_9  connected_order_arc_1129  -14
    arc_1_20_9  in_degree_1220  1
    arc_1_20_9  out_degree_1263  1
    arc_1_20_9  original_T_including_depot_unload_1285  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1128  1
    load_1_20_9  segment_load_conservation_1223  -1
    load_1_20_9  segment_prefix_lb_1224  1
    load_1_20_9  segment_prefix_ub_1225  1
    load_1_20_9  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1130  -25
    arc_1_20_10  connected_order_arc_1131  -14
    arc_1_20_10  in_degree_1227  1
    arc_1_20_10  out_degree_1263  1
    arc_1_20_10  original_T_including_depot_unload_1285  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1130  1
    load_1_20_10  segment_load_conservation_1230  -1
    load_1_20_10  segment_prefix_lb_1231  1
    load_1_20_10  segment_prefix_ub_1232  1
    load_1_20_10  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1132  -25
    arc_1_20_15  connected_order_arc_1133  -14
    arc_1_20_15  in_degree_1234  1
    arc_1_20_15  out_degree_1263  1
    arc_1_20_15  original_T_including_depot_unload_1285  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1132  1
    load_1_20_15  free_load_conservation_1238  -1
    load_1_20_15  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1134  -25
    arc_1_20_16  connected_order_arc_1135  -14
    arc_1_20_16  in_degree_1240  1
    arc_1_20_16  out_degree_1263  1
    arc_1_20_16  original_T_including_depot_unload_1285  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1134  1
    load_1_20_16  free_load_conservation_1244  -1
    load_1_20_16  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1136  -25
    arc_1_20_17  connected_order_arc_1137  -14
    arc_1_20_17  in_degree_1246  1
    arc_1_20_17  out_degree_1263  1
    arc_1_20_17  original_T_including_depot_unload_1285  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1136  1
    load_1_20_17  free_load_conservation_1250  -1
    load_1_20_17  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1138  -25
    arc_1_20_18  connected_order_arc_1139  -14
    arc_1_20_18  in_degree_1252  1
    arc_1_20_18  out_degree_1263  1
    arc_1_20_18  original_T_including_depot_unload_1285  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1138  1
    load_1_20_18  free_load_conservation_1256  -1
    load_1_20_18  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1140  -25
    arc_1_20_19  connected_order_arc_1141  -14
    arc_1_20_19  in_degree_1258  1
    arc_1_20_19  out_degree_1263  1
    arc_1_20_19  original_T_including_depot_unload_1285  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1140  1
    load_1_20_19  free_load_conservation_1262  -1
    load_1_20_19  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1142  -25
    arc_1_20_21  connected_order_arc_1143  -14
    arc_1_20_21  out_degree_1263  1
    arc_1_20_21  in_degree_1270  1
    arc_1_20_21  original_T_including_depot_unload_1285  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1142  1
    load_1_20_21  free_load_conservation_1268  1
    load_1_20_21  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1144  -25
    arc_1_20_22  connected_order_arc_1145  -14
    arc_1_20_22  out_degree_1263  1
    arc_1_20_22  in_degree_1276  1
    arc_1_20_22  original_T_including_depot_unload_1285  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1144  1
    load_1_20_22  free_load_conservation_1268  1
    load_1_20_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1146  -25
    arc_1_21_0  depot_return_or_bypass_1197  1
    arc_1_21_0  out_degree_1269  1
    arc_1_21_0  original_T_including_depot_unload_1285  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1146  1
    load_1_21_0  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1147  -25
    arc_1_21_6  connected_order_arc_1148  -14
    arc_1_21_6  in_degree_1199  1
    arc_1_21_6  out_degree_1269  1
    arc_1_21_6  original_T_including_depot_unload_1285  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1147  1
    load_1_21_6  segment_load_conservation_1202  -1
    load_1_21_6  segment_prefix_lb_1203  1
    load_1_21_6  segment_prefix_ub_1204  1
    load_1_21_6  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1149  -25
    arc_1_21_7  connected_order_arc_1150  -14
    arc_1_21_7  in_degree_1206  1
    arc_1_21_7  out_degree_1269  1
    arc_1_21_7  original_T_including_depot_unload_1285  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1149  1
    load_1_21_7  segment_load_conservation_1209  -1
    load_1_21_7  segment_prefix_lb_1210  1
    load_1_21_7  segment_prefix_ub_1211  1
    load_1_21_7  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1151  -25
    arc_1_21_8  connected_order_arc_1152  -14
    arc_1_21_8  in_degree_1213  1
    arc_1_21_8  out_degree_1269  1
    arc_1_21_8  original_T_including_depot_unload_1285  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1151  1
    load_1_21_8  segment_load_conservation_1216  -1
    load_1_21_8  segment_prefix_lb_1217  1
    load_1_21_8  segment_prefix_ub_1218  1
    load_1_21_8  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1153  -25
    arc_1_21_9  connected_order_arc_1154  -14
    arc_1_21_9  in_degree_1220  1
    arc_1_21_9  out_degree_1269  1
    arc_1_21_9  original_T_including_depot_unload_1285  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1153  1
    load_1_21_9  segment_load_conservation_1223  -1
    load_1_21_9  segment_prefix_lb_1224  1
    load_1_21_9  segment_prefix_ub_1225  1
    load_1_21_9  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1155  -25
    arc_1_21_10  connected_order_arc_1156  -14
    arc_1_21_10  in_degree_1227  1
    arc_1_21_10  out_degree_1269  1
    arc_1_21_10  original_T_including_depot_unload_1285  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1155  1
    load_1_21_10  segment_load_conservation_1230  -1
    load_1_21_10  segment_prefix_lb_1231  1
    load_1_21_10  segment_prefix_ub_1232  1
    load_1_21_10  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1157  -25
    arc_1_21_15  connected_order_arc_1158  -14
    arc_1_21_15  in_degree_1234  1
    arc_1_21_15  out_degree_1269  1
    arc_1_21_15  original_T_including_depot_unload_1285  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1157  1
    load_1_21_15  free_load_conservation_1238  -1
    load_1_21_15  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1159  -25
    arc_1_21_16  connected_order_arc_1160  -14
    arc_1_21_16  in_degree_1240  1
    arc_1_21_16  out_degree_1269  1
    arc_1_21_16  original_T_including_depot_unload_1285  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1159  1
    load_1_21_16  free_load_conservation_1244  -1
    load_1_21_16  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1161  -25
    arc_1_21_17  connected_order_arc_1162  -14
    arc_1_21_17  in_degree_1246  1
    arc_1_21_17  out_degree_1269  1
    arc_1_21_17  original_T_including_depot_unload_1285  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1161  1
    load_1_21_17  free_load_conservation_1250  -1
    load_1_21_17  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1163  -25
    arc_1_21_18  connected_order_arc_1164  -14
    arc_1_21_18  in_degree_1252  1
    arc_1_21_18  out_degree_1269  1
    arc_1_21_18  original_T_including_depot_unload_1285  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1163  1
    load_1_21_18  free_load_conservation_1256  -1
    load_1_21_18  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1165  -25
    arc_1_21_19  connected_order_arc_1166  -14
    arc_1_21_19  in_degree_1258  1
    arc_1_21_19  out_degree_1269  1
    arc_1_21_19  original_T_including_depot_unload_1285  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1165  1
    load_1_21_19  free_load_conservation_1262  -1
    load_1_21_19  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1167  -25
    arc_1_21_20  connected_order_arc_1168  -14
    arc_1_21_20  in_degree_1264  1
    arc_1_21_20  out_degree_1269  1
    arc_1_21_20  original_T_including_depot_unload_1285  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1167  1
    load_1_21_20  free_load_conservation_1268  -1
    load_1_21_20  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1169  -25
    arc_1_21_22  connected_order_arc_1170  -14
    arc_1_21_22  out_degree_1269  1
    arc_1_21_22  in_degree_1276  1
    arc_1_21_22  original_T_including_depot_unload_1285  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1169  1
    load_1_21_22  free_load_conservation_1274  1
    load_1_21_22  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1171  -25
    arc_1_22_0  depot_return_or_bypass_1197  1
    arc_1_22_0  out_degree_1275  1
    arc_1_22_0  original_T_including_depot_unload_1285  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1171  1
    load_1_22_0  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_6  arc_capacity_1172  -25
    arc_1_22_6  connected_order_arc_1173  -14
    arc_1_22_6  in_degree_1199  1
    arc_1_22_6  out_degree_1275  1
    arc_1_22_6  original_T_including_depot_unload_1285  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_6  arc_capacity_1172  1
    load_1_22_6  segment_load_conservation_1202  -1
    load_1_22_6  segment_prefix_lb_1203  1
    load_1_22_6  segment_prefix_ub_1204  1
    load_1_22_6  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1174  -25
    arc_1_22_7  connected_order_arc_1175  -14
    arc_1_22_7  in_degree_1206  1
    arc_1_22_7  out_degree_1275  1
    arc_1_22_7  original_T_including_depot_unload_1285  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1174  1
    load_1_22_7  segment_load_conservation_1209  -1
    load_1_22_7  segment_prefix_lb_1210  1
    load_1_22_7  segment_prefix_ub_1211  1
    load_1_22_7  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1176  -25
    arc_1_22_8  connected_order_arc_1177  -14
    arc_1_22_8  in_degree_1213  1
    arc_1_22_8  out_degree_1275  1
    arc_1_22_8  original_T_including_depot_unload_1285  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1176  1
    load_1_22_8  segment_load_conservation_1216  -1
    load_1_22_8  segment_prefix_lb_1217  1
    load_1_22_8  segment_prefix_ub_1218  1
    load_1_22_8  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1178  -25
    arc_1_22_9  connected_order_arc_1179  -14
    arc_1_22_9  in_degree_1220  1
    arc_1_22_9  out_degree_1275  1
    arc_1_22_9  original_T_including_depot_unload_1285  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1178  1
    load_1_22_9  segment_load_conservation_1223  -1
    load_1_22_9  segment_prefix_lb_1224  1
    load_1_22_9  segment_prefix_ub_1225  1
    load_1_22_9  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1180  -25
    arc_1_22_10  connected_order_arc_1181  -14
    arc_1_22_10  in_degree_1227  1
    arc_1_22_10  out_degree_1275  1
    arc_1_22_10  original_T_including_depot_unload_1285  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1180  1
    load_1_22_10  segment_load_conservation_1230  -1
    load_1_22_10  segment_prefix_lb_1231  1
    load_1_22_10  segment_prefix_ub_1232  1
    load_1_22_10  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1182  -25
    arc_1_22_15  connected_order_arc_1183  -14
    arc_1_22_15  in_degree_1234  1
    arc_1_22_15  out_degree_1275  1
    arc_1_22_15  original_T_including_depot_unload_1285  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1182  1
    load_1_22_15  free_load_conservation_1238  -1
    load_1_22_15  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1184  -25
    arc_1_22_16  connected_order_arc_1185  -14
    arc_1_22_16  in_degree_1240  1
    arc_1_22_16  out_degree_1275  1
    arc_1_22_16  original_T_including_depot_unload_1285  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1184  1
    load_1_22_16  free_load_conservation_1244  -1
    load_1_22_16  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1186  -25
    arc_1_22_17  connected_order_arc_1187  -14
    arc_1_22_17  in_degree_1246  1
    arc_1_22_17  out_degree_1275  1
    arc_1_22_17  original_T_including_depot_unload_1285  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1186  1
    load_1_22_17  free_load_conservation_1250  -1
    load_1_22_17  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1188  -25
    arc_1_22_18  connected_order_arc_1189  -14
    arc_1_22_18  in_degree_1252  1
    arc_1_22_18  out_degree_1275  1
    arc_1_22_18  original_T_including_depot_unload_1285  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1188  1
    load_1_22_18  free_load_conservation_1256  -1
    load_1_22_18  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1190  -25
    arc_1_22_19  connected_order_arc_1191  -14
    arc_1_22_19  in_degree_1258  1
    arc_1_22_19  out_degree_1275  1
    arc_1_22_19  original_T_including_depot_unload_1285  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1190  1
    load_1_22_19  free_load_conservation_1262  -1
    load_1_22_19  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1192  -25
    arc_1_22_20  connected_order_arc_1193  -14
    arc_1_22_20  in_degree_1264  1
    arc_1_22_20  out_degree_1275  1
    arc_1_22_20  original_T_including_depot_unload_1285  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1192  1
    load_1_22_20  free_load_conservation_1268  -1
    load_1_22_20  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1194  -25
    arc_1_22_21  connected_order_arc_1195  -14
    arc_1_22_21  in_degree_1270  1
    arc_1_22_21  out_degree_1275  1
    arc_1_22_21  original_T_including_depot_unload_1285  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1194  1
    load_1_22_21  free_load_conservation_1274  -1
    load_1_22_21  free_load_conservation_1280  1
    visit_2_11  out_degree_1577  -1
    visit_2_11  in_degree_1578  -1
    visit_2_11  order_active_lb_1579  -1
    visit_2_11  order_active_ub_1580  -12
    order_2_11  connected_order_arc_1301  -1
    order_2_11  connected_order_arc_1303  -1
    order_2_11  connected_order_arc_1305  -1
    order_2_11  connected_order_arc_1307  -1
    order_2_11  connected_order_arc_1309  -1
    order_2_11  connected_order_arc_1311  -1
    order_2_11  connected_order_arc_1313  -1
    order_2_11  connected_order_arc_1315  -1
    order_2_11  connected_order_arc_1317  -1
    order_2_11  connected_order_arc_1319  -1
    order_2_11  connected_order_arc_1321  -1
    order_2_11  connected_order_arc_1324  1
    order_2_11  connected_order_arc_1347  1
    order_2_11  connected_order_arc_1370  1
    order_2_11  connected_order_arc_1393  1
    order_2_11  connected_order_arc_1416  1
    order_2_11  connected_order_arc_1439  1
    order_2_11  connected_order_arc_1462  1
    order_2_11  connected_order_arc_1485  1
    order_2_11  connected_order_arc_1508  1
    order_2_11  connected_order_arc_1531  1
    order_2_11  connected_order_arc_1554  1
    order_2_11  order_active_lb_1579  1
    order_2_11  order_active_ub_1580  1
    order_2_11  fixed_segment_relative_order_1653  -1
    visit_2_12  out_degree_1584  -1
    visit_2_12  in_degree_1585  -1
    visit_2_12  order_active_lb_1586  -1
    visit_2_12  order_active_ub_1587  -12
    order_2_12  connected_order_arc_1301  1
    order_2_12  connected_order_arc_1324  -1
    order_2_12  connected_order_arc_1326  -1
    order_2_12  connected_order_arc_1328  -1
    order_2_12  connected_order_arc_1330  -1
    order_2_12  connected_order_arc_1332  -1
    order_2_12  connected_order_arc_1334  -1
    order_2_12  connected_order_arc_1336  -1
    order_2_12  connected_order_arc_1338  -1
    order_2_12  connected_order_arc_1340  -1
    order_2_12  connected_order_arc_1342  -1
    order_2_12  connected_order_arc_1344  -1
    order_2_12  connected_order_arc_1349  1
    order_2_12  connected_order_arc_1372  1
    order_2_12  connected_order_arc_1395  1
    order_2_12  connected_order_arc_1418  1
    order_2_12  connected_order_arc_1441  1
    order_2_12  connected_order_arc_1464  1
    order_2_12  connected_order_arc_1487  1
    order_2_12  connected_order_arc_1510  1
    order_2_12  connected_order_arc_1533  1
    order_2_12  connected_order_arc_1556  1
    order_2_12  order_active_lb_1586  1
    order_2_12  order_active_ub_1587  1
    order_2_12  fixed_segment_relative_order_1653  1
    order_2_12  fixed_segment_relative_order_1654  -1
    visit_2_13  out_degree_1591  -1
    visit_2_13  in_degree_1592  -1
    visit_2_13  order_active_lb_1593  -1
    visit_2_13  order_active_ub_1594  -12
    order_2_13  connected_order_arc_1303  1
    order_2_13  connected_order_arc_1326  1
    order_2_13  connected_order_arc_1347  -1
    order_2_13  connected_order_arc_1349  -1
    order_2_13  connected_order_arc_1351  -1
    order_2_13  connected_order_arc_1353  -1
    order_2_13  connected_order_arc_1355  -1
    order_2_13  connected_order_arc_1357  -1
    order_2_13  connected_order_arc_1359  -1
    order_2_13  connected_order_arc_1361  -1
    order_2_13  connected_order_arc_1363  -1
    order_2_13  connected_order_arc_1365  -1
    order_2_13  connected_order_arc_1367  -1
    order_2_13  connected_order_arc_1374  1
    order_2_13  connected_order_arc_1397  1
    order_2_13  connected_order_arc_1420  1
    order_2_13  connected_order_arc_1443  1
    order_2_13  connected_order_arc_1466  1
    order_2_13  connected_order_arc_1489  1
    order_2_13  connected_order_arc_1512  1
    order_2_13  connected_order_arc_1535  1
    order_2_13  connected_order_arc_1558  1
    order_2_13  order_active_lb_1593  1
    order_2_13  order_active_ub_1594  1
    order_2_13  fixed_segment_relative_order_1654  1
    order_2_13  fixed_segment_relative_order_1655  -1
    visit_2_14  out_degree_1598  -1
    visit_2_14  in_degree_1599  -1
    visit_2_14  order_active_lb_1600  -1
    visit_2_14  order_active_ub_1601  -12
    order_2_14  connected_order_arc_1305  1
    order_2_14  connected_order_arc_1328  1
    order_2_14  connected_order_arc_1351  1
    order_2_14  connected_order_arc_1370  -1
    order_2_14  connected_order_arc_1372  -1
    order_2_14  connected_order_arc_1374  -1
    order_2_14  connected_order_arc_1376  -1
    order_2_14  connected_order_arc_1378  -1
    order_2_14  connected_order_arc_1380  -1
    order_2_14  connected_order_arc_1382  -1
    order_2_14  connected_order_arc_1384  -1
    order_2_14  connected_order_arc_1386  -1
    order_2_14  connected_order_arc_1388  -1
    order_2_14  connected_order_arc_1390  -1
    order_2_14  connected_order_arc_1399  1
    order_2_14  connected_order_arc_1422  1
    order_2_14  connected_order_arc_1445  1
    order_2_14  connected_order_arc_1468  1
    order_2_14  connected_order_arc_1491  1
    order_2_14  connected_order_arc_1514  1
    order_2_14  connected_order_arc_1537  1
    order_2_14  connected_order_arc_1560  1
    order_2_14  order_active_lb_1600  1
    order_2_14  order_active_ub_1601  1
    order_2_14  fixed_segment_relative_order_1655  1
    visit_2_15  out_degree_1605  -1
    visit_2_15  in_degree_1606  -1
    visit_2_15  order_active_lb_1607  -1
    visit_2_15  order_active_ub_1608  -12
    visit_2_15  service_visit_def_1609  -1
    order_2_15  connected_order_arc_1307  1
    order_2_15  connected_order_arc_1330  1
    order_2_15  connected_order_arc_1353  1
    order_2_15  connected_order_arc_1376  1
    order_2_15  connected_order_arc_1393  -1
    order_2_15  connected_order_arc_1395  -1
    order_2_15  connected_order_arc_1397  -1
    order_2_15  connected_order_arc_1399  -1
    order_2_15  connected_order_arc_1401  -1
    order_2_15  connected_order_arc_1403  -1
    order_2_15  connected_order_arc_1405  -1
    order_2_15  connected_order_arc_1407  -1
    order_2_15  connected_order_arc_1409  -1
    order_2_15  connected_order_arc_1411  -1
    order_2_15  connected_order_arc_1413  -1
    order_2_15  connected_order_arc_1424  1
    order_2_15  connected_order_arc_1447  1
    order_2_15  connected_order_arc_1470  1
    order_2_15  connected_order_arc_1493  1
    order_2_15  connected_order_arc_1516  1
    order_2_15  connected_order_arc_1539  1
    order_2_15  connected_order_arc_1562  1
    order_2_15  order_active_lb_1607  1
    order_2_15  order_active_ub_1608  1
    visit_2_16  out_degree_1611  -1
    visit_2_16  in_degree_1612  -1
    visit_2_16  order_active_lb_1613  -1
    visit_2_16  order_active_ub_1614  -12
    visit_2_16  service_visit_def_1615  -1
    order_2_16  connected_order_arc_1309  1
    order_2_16  connected_order_arc_1332  1
    order_2_16  connected_order_arc_1355  1
    order_2_16  connected_order_arc_1378  1
    order_2_16  connected_order_arc_1401  1
    order_2_16  connected_order_arc_1416  -1
    order_2_16  connected_order_arc_1418  -1
    order_2_16  connected_order_arc_1420  -1
    order_2_16  connected_order_arc_1422  -1
    order_2_16  connected_order_arc_1424  -1
    order_2_16  connected_order_arc_1426  -1
    order_2_16  connected_order_arc_1428  -1
    order_2_16  connected_order_arc_1430  -1
    order_2_16  connected_order_arc_1432  -1
    order_2_16  connected_order_arc_1434  -1
    order_2_16  connected_order_arc_1436  -1
    order_2_16  connected_order_arc_1449  1
    order_2_16  connected_order_arc_1472  1
    order_2_16  connected_order_arc_1495  1
    order_2_16  connected_order_arc_1518  1
    order_2_16  connected_order_arc_1541  1
    order_2_16  connected_order_arc_1564  1
    order_2_16  order_active_lb_1613  1
    order_2_16  order_active_ub_1614  1
    visit_2_17  out_degree_1617  -1
    visit_2_17  in_degree_1618  -1
    visit_2_17  order_active_lb_1619  -1
    visit_2_17  order_active_ub_1620  -12
    visit_2_17  service_visit_def_1621  -1
    order_2_17  connected_order_arc_1311  1
    order_2_17  connected_order_arc_1334  1
    order_2_17  connected_order_arc_1357  1
    order_2_17  connected_order_arc_1380  1
    order_2_17  connected_order_arc_1403  1
    order_2_17  connected_order_arc_1426  1
    order_2_17  connected_order_arc_1439  -1
    order_2_17  connected_order_arc_1441  -1
    order_2_17  connected_order_arc_1443  -1
    order_2_17  connected_order_arc_1445  -1
    order_2_17  connected_order_arc_1447  -1
    order_2_17  connected_order_arc_1449  -1
    order_2_17  connected_order_arc_1451  -1
    order_2_17  connected_order_arc_1453  -1
    order_2_17  connected_order_arc_1455  -1
    order_2_17  connected_order_arc_1457  -1
    order_2_17  connected_order_arc_1459  -1
    order_2_17  connected_order_arc_1474  1
    order_2_17  connected_order_arc_1497  1
    order_2_17  connected_order_arc_1520  1
    order_2_17  connected_order_arc_1543  1
    order_2_17  connected_order_arc_1566  1
    order_2_17  order_active_lb_1619  1
    order_2_17  order_active_ub_1620  1
    visit_2_18  out_degree_1623  -1
    visit_2_18  in_degree_1624  -1
    visit_2_18  order_active_lb_1625  -1
    visit_2_18  order_active_ub_1626  -12
    visit_2_18  service_visit_def_1627  -1
    order_2_18  connected_order_arc_1313  1
    order_2_18  connected_order_arc_1336  1
    order_2_18  connected_order_arc_1359  1
    order_2_18  connected_order_arc_1382  1
    order_2_18  connected_order_arc_1405  1
    order_2_18  connected_order_arc_1428  1
    order_2_18  connected_order_arc_1451  1
    order_2_18  connected_order_arc_1462  -1
    order_2_18  connected_order_arc_1464  -1
    order_2_18  connected_order_arc_1466  -1
    order_2_18  connected_order_arc_1468  -1
    order_2_18  connected_order_arc_1470  -1
    order_2_18  connected_order_arc_1472  -1
    order_2_18  connected_order_arc_1474  -1
    order_2_18  connected_order_arc_1476  -1
    order_2_18  connected_order_arc_1478  -1
    order_2_18  connected_order_arc_1480  -1
    order_2_18  connected_order_arc_1482  -1
    order_2_18  connected_order_arc_1499  1
    order_2_18  connected_order_arc_1522  1
    order_2_18  connected_order_arc_1545  1
    order_2_18  connected_order_arc_1568  1
    order_2_18  order_active_lb_1625  1
    order_2_18  order_active_ub_1626  1
    visit_2_19  out_degree_1629  -1
    visit_2_19  in_degree_1630  -1
    visit_2_19  order_active_lb_1631  -1
    visit_2_19  order_active_ub_1632  -12
    visit_2_19  service_visit_def_1633  -1
    order_2_19  connected_order_arc_1315  1
    order_2_19  connected_order_arc_1338  1
    order_2_19  connected_order_arc_1361  1
    order_2_19  connected_order_arc_1384  1
    order_2_19  connected_order_arc_1407  1
    order_2_19  connected_order_arc_1430  1
    order_2_19  connected_order_arc_1453  1
    order_2_19  connected_order_arc_1476  1
    order_2_19  connected_order_arc_1485  -1
    order_2_19  connected_order_arc_1487  -1
    order_2_19  connected_order_arc_1489  -1
    order_2_19  connected_order_arc_1491  -1
    order_2_19  connected_order_arc_1493  -1
    order_2_19  connected_order_arc_1495  -1
    order_2_19  connected_order_arc_1497  -1
    order_2_19  connected_order_arc_1499  -1
    order_2_19  connected_order_arc_1501  -1
    order_2_19  connected_order_arc_1503  -1
    order_2_19  connected_order_arc_1505  -1
    order_2_19  connected_order_arc_1524  1
    order_2_19  connected_order_arc_1547  1
    order_2_19  connected_order_arc_1570  1
    order_2_19  order_active_lb_1631  1
    order_2_19  order_active_ub_1632  1
    visit_2_20  out_degree_1635  -1
    visit_2_20  in_degree_1636  -1
    visit_2_20  order_active_lb_1637  -1
    visit_2_20  order_active_ub_1638  -12
    visit_2_20  service_visit_def_1639  -1
    order_2_20  connected_order_arc_1317  1
    order_2_20  connected_order_arc_1340  1
    order_2_20  connected_order_arc_1363  1
    order_2_20  connected_order_arc_1386  1
    order_2_20  connected_order_arc_1409  1
    order_2_20  connected_order_arc_1432  1
    order_2_20  connected_order_arc_1455  1
    order_2_20  connected_order_arc_1478  1
    order_2_20  connected_order_arc_1501  1
    order_2_20  connected_order_arc_1508  -1
    order_2_20  connected_order_arc_1510  -1
    order_2_20  connected_order_arc_1512  -1
    order_2_20  connected_order_arc_1514  -1
    order_2_20  connected_order_arc_1516  -1
    order_2_20  connected_order_arc_1518  -1
    order_2_20  connected_order_arc_1520  -1
    order_2_20  connected_order_arc_1522  -1
    order_2_20  connected_order_arc_1524  -1
    order_2_20  connected_order_arc_1526  -1
    order_2_20  connected_order_arc_1528  -1
    order_2_20  connected_order_arc_1549  1
    order_2_20  connected_order_arc_1572  1
    order_2_20  order_active_lb_1637  1
    order_2_20  order_active_ub_1638  1
    visit_2_21  out_degree_1641  -1
    visit_2_21  in_degree_1642  -1
    visit_2_21  order_active_lb_1643  -1
    visit_2_21  order_active_ub_1644  -12
    visit_2_21  service_visit_def_1645  -1
    order_2_21  connected_order_arc_1319  1
    order_2_21  connected_order_arc_1342  1
    order_2_21  connected_order_arc_1365  1
    order_2_21  connected_order_arc_1388  1
    order_2_21  connected_order_arc_1411  1
    order_2_21  connected_order_arc_1434  1
    order_2_21  connected_order_arc_1457  1
    order_2_21  connected_order_arc_1480  1
    order_2_21  connected_order_arc_1503  1
    order_2_21  connected_order_arc_1526  1
    order_2_21  connected_order_arc_1531  -1
    order_2_21  connected_order_arc_1533  -1
    order_2_21  connected_order_arc_1535  -1
    order_2_21  connected_order_arc_1537  -1
    order_2_21  connected_order_arc_1539  -1
    order_2_21  connected_order_arc_1541  -1
    order_2_21  connected_order_arc_1543  -1
    order_2_21  connected_order_arc_1545  -1
    order_2_21  connected_order_arc_1547  -1
    order_2_21  connected_order_arc_1549  -1
    order_2_21  connected_order_arc_1551  -1
    order_2_21  connected_order_arc_1574  1
    order_2_21  order_active_lb_1643  1
    order_2_21  order_active_ub_1644  1
    visit_2_22  out_degree_1647  -1
    visit_2_22  in_degree_1648  -1
    visit_2_22  order_active_lb_1649  -1
    visit_2_22  order_active_ub_1650  -12
    visit_2_22  service_visit_def_1651  -1
    order_2_22  connected_order_arc_1321  1
    order_2_22  connected_order_arc_1344  1
    order_2_22  connected_order_arc_1367  1
    order_2_22  connected_order_arc_1390  1
    order_2_22  connected_order_arc_1413  1
    order_2_22  connected_order_arc_1436  1
    order_2_22  connected_order_arc_1459  1
    order_2_22  connected_order_arc_1482  1
    order_2_22  connected_order_arc_1505  1
    order_2_22  connected_order_arc_1528  1
    order_2_22  connected_order_arc_1551  1
    order_2_22  connected_order_arc_1554  -1
    order_2_22  connected_order_arc_1556  -1
    order_2_22  connected_order_arc_1558  -1
    order_2_22  connected_order_arc_1560  -1
    order_2_22  connected_order_arc_1562  -1
    order_2_22  connected_order_arc_1564  -1
    order_2_22  connected_order_arc_1566  -1
    order_2_22  connected_order_arc_1568  -1
    order_2_22  connected_order_arc_1570  -1
    order_2_22  connected_order_arc_1572  -1
    order_2_22  connected_order_arc_1574  -1
    order_2_22  order_active_lb_1649  1
    order_2_22  order_active_ub_1650  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1286  -30
    arc_2_0_0  depot_departure_or_bypass_1575  1
    arc_2_0_0  depot_return_or_bypass_1576  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1287  -30
    arc_2_0_11  depot_departure_or_bypass_1575  1
    arc_2_0_11  in_degree_1578  1
    arc_2_0_11  original_T_including_depot_unload_1656  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1287  1
    load_2_0_11  segment_load_conservation_1581  -1
    load_2_0_11  segment_prefix_lb_1582  1
    load_2_0_11  segment_prefix_ub_1583  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1288  -30
    arc_2_0_12  depot_departure_or_bypass_1575  1
    arc_2_0_12  in_degree_1585  1
    arc_2_0_12  original_T_including_depot_unload_1656  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1288  1
    load_2_0_12  segment_load_conservation_1588  -1
    load_2_0_12  segment_prefix_lb_1589  1
    load_2_0_12  segment_prefix_ub_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1289  -30
    arc_2_0_13  depot_departure_or_bypass_1575  1
    arc_2_0_13  in_degree_1592  1
    arc_2_0_13  original_T_including_depot_unload_1656  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1289  1
    load_2_0_13  segment_load_conservation_1595  -1
    load_2_0_13  segment_prefix_lb_1596  1
    load_2_0_13  segment_prefix_ub_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1290  -30
    arc_2_0_14  depot_departure_or_bypass_1575  1
    arc_2_0_14  in_degree_1599  1
    arc_2_0_14  original_T_including_depot_unload_1656  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1290  1
    load_2_0_14  segment_load_conservation_1602  -1
    load_2_0_14  segment_prefix_lb_1603  1
    load_2_0_14  segment_prefix_ub_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1291  -30
    arc_2_0_15  depot_departure_or_bypass_1575  1
    arc_2_0_15  in_degree_1606  1
    arc_2_0_15  original_T_including_depot_unload_1656  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1291  1
    load_2_0_15  free_load_conservation_1610  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1292  -30
    arc_2_0_16  depot_departure_or_bypass_1575  1
    arc_2_0_16  in_degree_1612  1
    arc_2_0_16  original_T_including_depot_unload_1656  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1292  1
    load_2_0_16  free_load_conservation_1616  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1293  -30
    arc_2_0_17  depot_departure_or_bypass_1575  1
    arc_2_0_17  in_degree_1618  1
    arc_2_0_17  original_T_including_depot_unload_1656  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1293  1
    load_2_0_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1294  -30
    arc_2_0_18  depot_departure_or_bypass_1575  1
    arc_2_0_18  in_degree_1624  1
    arc_2_0_18  original_T_including_depot_unload_1656  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1294  1
    load_2_0_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1295  -30
    arc_2_0_19  depot_departure_or_bypass_1575  1
    arc_2_0_19  in_degree_1630  1
    arc_2_0_19  original_T_including_depot_unload_1656  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1295  1
    load_2_0_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1296  -30
    arc_2_0_20  depot_departure_or_bypass_1575  1
    arc_2_0_20  in_degree_1636  1
    arc_2_0_20  original_T_including_depot_unload_1656  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1296  1
    load_2_0_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1297  -30
    arc_2_0_21  depot_departure_or_bypass_1575  1
    arc_2_0_21  in_degree_1642  1
    arc_2_0_21  original_T_including_depot_unload_1656  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1297  1
    load_2_0_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1298  -30
    arc_2_0_22  depot_departure_or_bypass_1575  1
    arc_2_0_22  in_degree_1648  1
    arc_2_0_22  original_T_including_depot_unload_1656  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1298  1
    load_2_0_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1299  -30
    arc_2_11_0  depot_return_or_bypass_1576  1
    arc_2_11_0  out_degree_1577  1
    arc_2_11_0  original_T_including_depot_unload_1656  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1299  1
    load_2_11_0  segment_load_conservation_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1300  -30
    arc_2_11_12  connected_order_arc_1301  -13
    arc_2_11_12  out_degree_1577  1
    arc_2_11_12  in_degree_1585  1
    arc_2_11_12  original_T_including_depot_unload_1656  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1300  1
    load_2_11_12  segment_load_conservation_1581  1
    load_2_11_12  segment_load_conservation_1588  -1
    load_2_11_12  segment_prefix_lb_1589  1
    load_2_11_12  segment_prefix_ub_1590  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1302  -30
    arc_2_11_13  connected_order_arc_1303  -13
    arc_2_11_13  out_degree_1577  1
    arc_2_11_13  in_degree_1592  1
    arc_2_11_13  original_T_including_depot_unload_1656  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1302  1
    load_2_11_13  segment_load_conservation_1581  1
    load_2_11_13  segment_load_conservation_1595  -1
    load_2_11_13  segment_prefix_lb_1596  1
    load_2_11_13  segment_prefix_ub_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1304  -30
    arc_2_11_14  connected_order_arc_1305  -13
    arc_2_11_14  out_degree_1577  1
    arc_2_11_14  in_degree_1599  1
    arc_2_11_14  original_T_including_depot_unload_1656  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1304  1
    load_2_11_14  segment_load_conservation_1581  1
    load_2_11_14  segment_load_conservation_1602  -1
    load_2_11_14  segment_prefix_lb_1603  1
    load_2_11_14  segment_prefix_ub_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1306  -30
    arc_2_11_15  connected_order_arc_1307  -13
    arc_2_11_15  out_degree_1577  1
    arc_2_11_15  in_degree_1606  1
    arc_2_11_15  original_T_including_depot_unload_1656  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1306  1
    load_2_11_15  segment_load_conservation_1581  1
    load_2_11_15  free_load_conservation_1610  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1308  -30
    arc_2_11_16  connected_order_arc_1309  -13
    arc_2_11_16  out_degree_1577  1
    arc_2_11_16  in_degree_1612  1
    arc_2_11_16  original_T_including_depot_unload_1656  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1308  1
    load_2_11_16  segment_load_conservation_1581  1
    load_2_11_16  free_load_conservation_1616  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1310  -30
    arc_2_11_17  connected_order_arc_1311  -13
    arc_2_11_17  out_degree_1577  1
    arc_2_11_17  in_degree_1618  1
    arc_2_11_17  original_T_including_depot_unload_1656  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1310  1
    load_2_11_17  segment_load_conservation_1581  1
    load_2_11_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1312  -30
    arc_2_11_18  connected_order_arc_1313  -13
    arc_2_11_18  out_degree_1577  1
    arc_2_11_18  in_degree_1624  1
    arc_2_11_18  original_T_including_depot_unload_1656  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1312  1
    load_2_11_18  segment_load_conservation_1581  1
    load_2_11_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1314  -30
    arc_2_11_19  connected_order_arc_1315  -13
    arc_2_11_19  out_degree_1577  1
    arc_2_11_19  in_degree_1630  1
    arc_2_11_19  original_T_including_depot_unload_1656  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1314  1
    load_2_11_19  segment_load_conservation_1581  1
    load_2_11_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1316  -30
    arc_2_11_20  connected_order_arc_1317  -13
    arc_2_11_20  out_degree_1577  1
    arc_2_11_20  in_degree_1636  1
    arc_2_11_20  original_T_including_depot_unload_1656  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1316  1
    load_2_11_20  segment_load_conservation_1581  1
    load_2_11_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1318  -30
    arc_2_11_21  connected_order_arc_1319  -13
    arc_2_11_21  out_degree_1577  1
    arc_2_11_21  in_degree_1642  1
    arc_2_11_21  original_T_including_depot_unload_1656  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1318  1
    load_2_11_21  segment_load_conservation_1581  1
    load_2_11_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1320  -30
    arc_2_11_22  connected_order_arc_1321  -13
    arc_2_11_22  out_degree_1577  1
    arc_2_11_22  in_degree_1648  1
    arc_2_11_22  original_T_including_depot_unload_1656  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1320  1
    load_2_11_22  segment_load_conservation_1581  1
    load_2_11_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1322  -30
    arc_2_12_0  depot_return_or_bypass_1576  1
    arc_2_12_0  out_degree_1584  1
    arc_2_12_0  original_T_including_depot_unload_1656  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1322  1
    load_2_12_0  segment_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1323  -30
    arc_2_12_11  connected_order_arc_1324  -13
    arc_2_12_11  in_degree_1578  1
    arc_2_12_11  out_degree_1584  1
    arc_2_12_11  original_T_including_depot_unload_1656  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1323  1
    load_2_12_11  segment_load_conservation_1581  -1
    load_2_12_11  segment_prefix_lb_1582  1
    load_2_12_11  segment_prefix_ub_1583  1
    load_2_12_11  segment_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1325  -30
    arc_2_12_13  connected_order_arc_1326  -13
    arc_2_12_13  out_degree_1584  1
    arc_2_12_13  in_degree_1592  1
    arc_2_12_13  original_T_including_depot_unload_1656  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1325  1
    load_2_12_13  segment_load_conservation_1588  1
    load_2_12_13  segment_load_conservation_1595  -1
    load_2_12_13  segment_prefix_lb_1596  1
    load_2_12_13  segment_prefix_ub_1597  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1327  -30
    arc_2_12_14  connected_order_arc_1328  -13
    arc_2_12_14  out_degree_1584  1
    arc_2_12_14  in_degree_1599  1
    arc_2_12_14  original_T_including_depot_unload_1656  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1327  1
    load_2_12_14  segment_load_conservation_1588  1
    load_2_12_14  segment_load_conservation_1602  -1
    load_2_12_14  segment_prefix_lb_1603  1
    load_2_12_14  segment_prefix_ub_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1329  -30
    arc_2_12_15  connected_order_arc_1330  -13
    arc_2_12_15  out_degree_1584  1
    arc_2_12_15  in_degree_1606  1
    arc_2_12_15  original_T_including_depot_unload_1656  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1329  1
    load_2_12_15  segment_load_conservation_1588  1
    load_2_12_15  free_load_conservation_1610  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1331  -30
    arc_2_12_16  connected_order_arc_1332  -13
    arc_2_12_16  out_degree_1584  1
    arc_2_12_16  in_degree_1612  1
    arc_2_12_16  original_T_including_depot_unload_1656  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1331  1
    load_2_12_16  segment_load_conservation_1588  1
    load_2_12_16  free_load_conservation_1616  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1333  -30
    arc_2_12_17  connected_order_arc_1334  -13
    arc_2_12_17  out_degree_1584  1
    arc_2_12_17  in_degree_1618  1
    arc_2_12_17  original_T_including_depot_unload_1656  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1333  1
    load_2_12_17  segment_load_conservation_1588  1
    load_2_12_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1335  -30
    arc_2_12_18  connected_order_arc_1336  -13
    arc_2_12_18  out_degree_1584  1
    arc_2_12_18  in_degree_1624  1
    arc_2_12_18  original_T_including_depot_unload_1656  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1335  1
    load_2_12_18  segment_load_conservation_1588  1
    load_2_12_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1337  -30
    arc_2_12_19  connected_order_arc_1338  -13
    arc_2_12_19  out_degree_1584  1
    arc_2_12_19  in_degree_1630  1
    arc_2_12_19  original_T_including_depot_unload_1656  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1337  1
    load_2_12_19  segment_load_conservation_1588  1
    load_2_12_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1339  -30
    arc_2_12_20  connected_order_arc_1340  -13
    arc_2_12_20  out_degree_1584  1
    arc_2_12_20  in_degree_1636  1
    arc_2_12_20  original_T_including_depot_unload_1656  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1339  1
    load_2_12_20  segment_load_conservation_1588  1
    load_2_12_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1341  -30
    arc_2_12_21  connected_order_arc_1342  -13
    arc_2_12_21  out_degree_1584  1
    arc_2_12_21  in_degree_1642  1
    arc_2_12_21  original_T_including_depot_unload_1656  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1341  1
    load_2_12_21  segment_load_conservation_1588  1
    load_2_12_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1343  -30
    arc_2_12_22  connected_order_arc_1344  -13
    arc_2_12_22  out_degree_1584  1
    arc_2_12_22  in_degree_1648  1
    arc_2_12_22  original_T_including_depot_unload_1656  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1343  1
    load_2_12_22  segment_load_conservation_1588  1
    load_2_12_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1345  -30
    arc_2_13_0  depot_return_or_bypass_1576  1
    arc_2_13_0  out_degree_1591  1
    arc_2_13_0  original_T_including_depot_unload_1656  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1345  1
    load_2_13_0  segment_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1346  -30
    arc_2_13_11  connected_order_arc_1347  -13
    arc_2_13_11  in_degree_1578  1
    arc_2_13_11  out_degree_1591  1
    arc_2_13_11  original_T_including_depot_unload_1656  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1346  1
    load_2_13_11  segment_load_conservation_1581  -1
    load_2_13_11  segment_prefix_lb_1582  1
    load_2_13_11  segment_prefix_ub_1583  1
    load_2_13_11  segment_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1348  -30
    arc_2_13_12  connected_order_arc_1349  -13
    arc_2_13_12  in_degree_1585  1
    arc_2_13_12  out_degree_1591  1
    arc_2_13_12  original_T_including_depot_unload_1656  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1348  1
    load_2_13_12  segment_load_conservation_1588  -1
    load_2_13_12  segment_prefix_lb_1589  1
    load_2_13_12  segment_prefix_ub_1590  1
    load_2_13_12  segment_load_conservation_1595  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1350  -30
    arc_2_13_14  connected_order_arc_1351  -13
    arc_2_13_14  out_degree_1591  1
    arc_2_13_14  in_degree_1599  1
    arc_2_13_14  original_T_including_depot_unload_1656  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1350  1
    load_2_13_14  segment_load_conservation_1595  1
    load_2_13_14  segment_load_conservation_1602  -1
    load_2_13_14  segment_prefix_lb_1603  1
    load_2_13_14  segment_prefix_ub_1604  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1352  -30
    arc_2_13_15  connected_order_arc_1353  -13
    arc_2_13_15  out_degree_1591  1
    arc_2_13_15  in_degree_1606  1
    arc_2_13_15  original_T_including_depot_unload_1656  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1352  1
    load_2_13_15  segment_load_conservation_1595  1
    load_2_13_15  free_load_conservation_1610  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1354  -30
    arc_2_13_16  connected_order_arc_1355  -13
    arc_2_13_16  out_degree_1591  1
    arc_2_13_16  in_degree_1612  1
    arc_2_13_16  original_T_including_depot_unload_1656  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1354  1
    load_2_13_16  segment_load_conservation_1595  1
    load_2_13_16  free_load_conservation_1616  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1356  -30
    arc_2_13_17  connected_order_arc_1357  -13
    arc_2_13_17  out_degree_1591  1
    arc_2_13_17  in_degree_1618  1
    arc_2_13_17  original_T_including_depot_unload_1656  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1356  1
    load_2_13_17  segment_load_conservation_1595  1
    load_2_13_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1358  -30
    arc_2_13_18  connected_order_arc_1359  -13
    arc_2_13_18  out_degree_1591  1
    arc_2_13_18  in_degree_1624  1
    arc_2_13_18  original_T_including_depot_unload_1656  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1358  1
    load_2_13_18  segment_load_conservation_1595  1
    load_2_13_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1360  -30
    arc_2_13_19  connected_order_arc_1361  -13
    arc_2_13_19  out_degree_1591  1
    arc_2_13_19  in_degree_1630  1
    arc_2_13_19  original_T_including_depot_unload_1656  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1360  1
    load_2_13_19  segment_load_conservation_1595  1
    load_2_13_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1362  -30
    arc_2_13_20  connected_order_arc_1363  -13
    arc_2_13_20  out_degree_1591  1
    arc_2_13_20  in_degree_1636  1
    arc_2_13_20  original_T_including_depot_unload_1656  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1362  1
    load_2_13_20  segment_load_conservation_1595  1
    load_2_13_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1364  -30
    arc_2_13_21  connected_order_arc_1365  -13
    arc_2_13_21  out_degree_1591  1
    arc_2_13_21  in_degree_1642  1
    arc_2_13_21  original_T_including_depot_unload_1656  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1364  1
    load_2_13_21  segment_load_conservation_1595  1
    load_2_13_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1366  -30
    arc_2_13_22  connected_order_arc_1367  -13
    arc_2_13_22  out_degree_1591  1
    arc_2_13_22  in_degree_1648  1
    arc_2_13_22  original_T_including_depot_unload_1656  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1366  1
    load_2_13_22  segment_load_conservation_1595  1
    load_2_13_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1368  -30
    arc_2_14_0  depot_return_or_bypass_1576  1
    arc_2_14_0  out_degree_1598  1
    arc_2_14_0  original_T_including_depot_unload_1656  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1368  1
    load_2_14_0  segment_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1369  -30
    arc_2_14_11  connected_order_arc_1370  -13
    arc_2_14_11  in_degree_1578  1
    arc_2_14_11  out_degree_1598  1
    arc_2_14_11  original_T_including_depot_unload_1656  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1369  1
    load_2_14_11  segment_load_conservation_1581  -1
    load_2_14_11  segment_prefix_lb_1582  1
    load_2_14_11  segment_prefix_ub_1583  1
    load_2_14_11  segment_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1371  -30
    arc_2_14_12  connected_order_arc_1372  -13
    arc_2_14_12  in_degree_1585  1
    arc_2_14_12  out_degree_1598  1
    arc_2_14_12  original_T_including_depot_unload_1656  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1371  1
    load_2_14_12  segment_load_conservation_1588  -1
    load_2_14_12  segment_prefix_lb_1589  1
    load_2_14_12  segment_prefix_ub_1590  1
    load_2_14_12  segment_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1373  -30
    arc_2_14_13  connected_order_arc_1374  -13
    arc_2_14_13  in_degree_1592  1
    arc_2_14_13  out_degree_1598  1
    arc_2_14_13  original_T_including_depot_unload_1656  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1373  1
    load_2_14_13  segment_load_conservation_1595  -1
    load_2_14_13  segment_prefix_lb_1596  1
    load_2_14_13  segment_prefix_ub_1597  1
    load_2_14_13  segment_load_conservation_1602  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1375  -30
    arc_2_14_15  connected_order_arc_1376  -13
    arc_2_14_15  out_degree_1598  1
    arc_2_14_15  in_degree_1606  1
    arc_2_14_15  original_T_including_depot_unload_1656  8.6958069185371107e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1375  1
    load_2_14_15  segment_load_conservation_1602  1
    load_2_14_15  free_load_conservation_1610  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1377  -30
    arc_2_14_16  connected_order_arc_1378  -13
    arc_2_14_16  out_degree_1598  1
    arc_2_14_16  in_degree_1612  1
    arc_2_14_16  original_T_including_depot_unload_1656  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1377  1
    load_2_14_16  segment_load_conservation_1602  1
    load_2_14_16  free_load_conservation_1616  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1379  -30
    arc_2_14_17  connected_order_arc_1380  -13
    arc_2_14_17  out_degree_1598  1
    arc_2_14_17  in_degree_1618  1
    arc_2_14_17  original_T_including_depot_unload_1656  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1379  1
    load_2_14_17  segment_load_conservation_1602  1
    load_2_14_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1381  -30
    arc_2_14_18  connected_order_arc_1382  -13
    arc_2_14_18  out_degree_1598  1
    arc_2_14_18  in_degree_1624  1
    arc_2_14_18  original_T_including_depot_unload_1656  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1381  1
    load_2_14_18  segment_load_conservation_1602  1
    load_2_14_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1383  -30
    arc_2_14_19  connected_order_arc_1384  -13
    arc_2_14_19  out_degree_1598  1
    arc_2_14_19  in_degree_1630  1
    arc_2_14_19  original_T_including_depot_unload_1656  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1383  1
    load_2_14_19  segment_load_conservation_1602  1
    load_2_14_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1385  -30
    arc_2_14_20  connected_order_arc_1386  -13
    arc_2_14_20  out_degree_1598  1
    arc_2_14_20  in_degree_1636  1
    arc_2_14_20  original_T_including_depot_unload_1656  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1385  1
    load_2_14_20  segment_load_conservation_1602  1
    load_2_14_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1387  -30
    arc_2_14_21  connected_order_arc_1388  -13
    arc_2_14_21  out_degree_1598  1
    arc_2_14_21  in_degree_1642  1
    arc_2_14_21  original_T_including_depot_unload_1656  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1387  1
    load_2_14_21  segment_load_conservation_1602  1
    load_2_14_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1389  -30
    arc_2_14_22  connected_order_arc_1390  -13
    arc_2_14_22  out_degree_1598  1
    arc_2_14_22  in_degree_1648  1
    arc_2_14_22  original_T_including_depot_unload_1656  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1389  1
    load_2_14_22  segment_load_conservation_1602  1
    load_2_14_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1391  -30
    arc_2_15_0  depot_return_or_bypass_1576  1
    arc_2_15_0  out_degree_1605  1
    arc_2_15_0  original_T_including_depot_unload_1656  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1391  1
    load_2_15_0  free_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1392  -30
    arc_2_15_11  connected_order_arc_1393  -13
    arc_2_15_11  in_degree_1578  1
    arc_2_15_11  out_degree_1605  1
    arc_2_15_11  original_T_including_depot_unload_1656  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1392  1
    load_2_15_11  segment_load_conservation_1581  -1
    load_2_15_11  segment_prefix_lb_1582  1
    load_2_15_11  segment_prefix_ub_1583  1
    load_2_15_11  free_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1394  -30
    arc_2_15_12  connected_order_arc_1395  -13
    arc_2_15_12  in_degree_1585  1
    arc_2_15_12  out_degree_1605  1
    arc_2_15_12  original_T_including_depot_unload_1656  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1394  1
    load_2_15_12  segment_load_conservation_1588  -1
    load_2_15_12  segment_prefix_lb_1589  1
    load_2_15_12  segment_prefix_ub_1590  1
    load_2_15_12  free_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1396  -30
    arc_2_15_13  connected_order_arc_1397  -13
    arc_2_15_13  in_degree_1592  1
    arc_2_15_13  out_degree_1605  1
    arc_2_15_13  original_T_including_depot_unload_1656  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1396  1
    load_2_15_13  segment_load_conservation_1595  -1
    load_2_15_13  segment_prefix_lb_1596  1
    load_2_15_13  segment_prefix_ub_1597  1
    load_2_15_13  free_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1398  -30
    arc_2_15_14  connected_order_arc_1399  -13
    arc_2_15_14  in_degree_1599  1
    arc_2_15_14  out_degree_1605  1
    arc_2_15_14  original_T_including_depot_unload_1656  8.2066682484686987e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1398  1
    load_2_15_14  segment_load_conservation_1602  -1
    load_2_15_14  segment_prefix_lb_1603  1
    load_2_15_14  segment_prefix_ub_1604  1
    load_2_15_14  free_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1400  -30
    arc_2_15_16  connected_order_arc_1401  -13
    arc_2_15_16  out_degree_1605  1
    arc_2_15_16  in_degree_1612  1
    arc_2_15_16  original_T_including_depot_unload_1656  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1400  1
    load_2_15_16  free_load_conservation_1610  1
    load_2_15_16  free_load_conservation_1616  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1402  -30
    arc_2_15_17  connected_order_arc_1403  -13
    arc_2_15_17  out_degree_1605  1
    arc_2_15_17  in_degree_1618  1
    arc_2_15_17  original_T_including_depot_unload_1656  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1402  1
    load_2_15_17  free_load_conservation_1610  1
    load_2_15_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1404  -30
    arc_2_15_18  connected_order_arc_1405  -13
    arc_2_15_18  out_degree_1605  1
    arc_2_15_18  in_degree_1624  1
    arc_2_15_18  original_T_including_depot_unload_1656  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1404  1
    load_2_15_18  free_load_conservation_1610  1
    load_2_15_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1406  -30
    arc_2_15_19  connected_order_arc_1407  -13
    arc_2_15_19  out_degree_1605  1
    arc_2_15_19  in_degree_1630  1
    arc_2_15_19  original_T_including_depot_unload_1656  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1406  1
    load_2_15_19  free_load_conservation_1610  1
    load_2_15_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1408  -30
    arc_2_15_20  connected_order_arc_1409  -13
    arc_2_15_20  out_degree_1605  1
    arc_2_15_20  in_degree_1636  1
    arc_2_15_20  original_T_including_depot_unload_1656  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1408  1
    load_2_15_20  free_load_conservation_1610  1
    load_2_15_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1410  -30
    arc_2_15_21  connected_order_arc_1411  -13
    arc_2_15_21  out_degree_1605  1
    arc_2_15_21  in_degree_1642  1
    arc_2_15_21  original_T_including_depot_unload_1656  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1410  1
    load_2_15_21  free_load_conservation_1610  1
    load_2_15_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1412  -30
    arc_2_15_22  connected_order_arc_1413  -13
    arc_2_15_22  out_degree_1605  1
    arc_2_15_22  in_degree_1648  1
    arc_2_15_22  original_T_including_depot_unload_1656  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1412  1
    load_2_15_22  free_load_conservation_1610  1
    load_2_15_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1414  -30
    arc_2_16_0  depot_return_or_bypass_1576  1
    arc_2_16_0  out_degree_1611  1
    arc_2_16_0  original_T_including_depot_unload_1656  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1414  1
    load_2_16_0  free_load_conservation_1616  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1415  -30
    arc_2_16_11  connected_order_arc_1416  -13
    arc_2_16_11  in_degree_1578  1
    arc_2_16_11  out_degree_1611  1
    arc_2_16_11  original_T_including_depot_unload_1656  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1415  1
    load_2_16_11  segment_load_conservation_1581  -1
    load_2_16_11  segment_prefix_lb_1582  1
    load_2_16_11  segment_prefix_ub_1583  1
    load_2_16_11  free_load_conservation_1616  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1417  -30
    arc_2_16_12  connected_order_arc_1418  -13
    arc_2_16_12  in_degree_1585  1
    arc_2_16_12  out_degree_1611  1
    arc_2_16_12  original_T_including_depot_unload_1656  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1417  1
    load_2_16_12  segment_load_conservation_1588  -1
    load_2_16_12  segment_prefix_lb_1589  1
    load_2_16_12  segment_prefix_ub_1590  1
    load_2_16_12  free_load_conservation_1616  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1419  -30
    arc_2_16_13  connected_order_arc_1420  -13
    arc_2_16_13  in_degree_1592  1
    arc_2_16_13  out_degree_1611  1
    arc_2_16_13  original_T_including_depot_unload_1656  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1419  1
    load_2_16_13  segment_load_conservation_1595  -1
    load_2_16_13  segment_prefix_lb_1596  1
    load_2_16_13  segment_prefix_ub_1597  1
    load_2_16_13  free_load_conservation_1616  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1421  -30
    arc_2_16_14  connected_order_arc_1422  -13
    arc_2_16_14  in_degree_1599  1
    arc_2_16_14  out_degree_1611  1
    arc_2_16_14  original_T_including_depot_unload_1656  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1421  1
    load_2_16_14  segment_load_conservation_1602  -1
    load_2_16_14  segment_prefix_lb_1603  1
    load_2_16_14  segment_prefix_ub_1604  1
    load_2_16_14  free_load_conservation_1616  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1423  -30
    arc_2_16_15  connected_order_arc_1424  -13
    arc_2_16_15  in_degree_1606  1
    arc_2_16_15  out_degree_1611  1
    arc_2_16_15  original_T_including_depot_unload_1656  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1423  1
    load_2_16_15  free_load_conservation_1610  -1
    load_2_16_15  free_load_conservation_1616  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1425  -30
    arc_2_16_17  connected_order_arc_1426  -13
    arc_2_16_17  out_degree_1611  1
    arc_2_16_17  in_degree_1618  1
    arc_2_16_17  original_T_including_depot_unload_1656  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1425  1
    load_2_16_17  free_load_conservation_1616  1
    load_2_16_17  free_load_conservation_1622  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1427  -30
    arc_2_16_18  connected_order_arc_1428  -13
    arc_2_16_18  out_degree_1611  1
    arc_2_16_18  in_degree_1624  1
    arc_2_16_18  original_T_including_depot_unload_1656  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1427  1
    load_2_16_18  free_load_conservation_1616  1
    load_2_16_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1429  -30
    arc_2_16_19  connected_order_arc_1430  -13
    arc_2_16_19  out_degree_1611  1
    arc_2_16_19  in_degree_1630  1
    arc_2_16_19  original_T_including_depot_unload_1656  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1429  1
    load_2_16_19  free_load_conservation_1616  1
    load_2_16_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1431  -30
    arc_2_16_20  connected_order_arc_1432  -13
    arc_2_16_20  out_degree_1611  1
    arc_2_16_20  in_degree_1636  1
    arc_2_16_20  original_T_including_depot_unload_1656  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1431  1
    load_2_16_20  free_load_conservation_1616  1
    load_2_16_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1433  -30
    arc_2_16_21  connected_order_arc_1434  -13
    arc_2_16_21  out_degree_1611  1
    arc_2_16_21  in_degree_1642  1
    arc_2_16_21  original_T_including_depot_unload_1656  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1433  1
    load_2_16_21  free_load_conservation_1616  1
    load_2_16_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1435  -30
    arc_2_16_22  connected_order_arc_1436  -13
    arc_2_16_22  out_degree_1611  1
    arc_2_16_22  in_degree_1648  1
    arc_2_16_22  original_T_including_depot_unload_1656  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1435  1
    load_2_16_22  free_load_conservation_1616  1
    load_2_16_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1437  -30
    arc_2_17_0  depot_return_or_bypass_1576  1
    arc_2_17_0  out_degree_1617  1
    arc_2_17_0  original_T_including_depot_unload_1656  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1437  1
    load_2_17_0  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1438  -30
    arc_2_17_11  connected_order_arc_1439  -13
    arc_2_17_11  in_degree_1578  1
    arc_2_17_11  out_degree_1617  1
    arc_2_17_11  original_T_including_depot_unload_1656  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1438  1
    load_2_17_11  segment_load_conservation_1581  -1
    load_2_17_11  segment_prefix_lb_1582  1
    load_2_17_11  segment_prefix_ub_1583  1
    load_2_17_11  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1440  -30
    arc_2_17_12  connected_order_arc_1441  -13
    arc_2_17_12  in_degree_1585  1
    arc_2_17_12  out_degree_1617  1
    arc_2_17_12  original_T_including_depot_unload_1656  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1440  1
    load_2_17_12  segment_load_conservation_1588  -1
    load_2_17_12  segment_prefix_lb_1589  1
    load_2_17_12  segment_prefix_ub_1590  1
    load_2_17_12  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1442  -30
    arc_2_17_13  connected_order_arc_1443  -13
    arc_2_17_13  in_degree_1592  1
    arc_2_17_13  out_degree_1617  1
    arc_2_17_13  original_T_including_depot_unload_1656  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1442  1
    load_2_17_13  segment_load_conservation_1595  -1
    load_2_17_13  segment_prefix_lb_1596  1
    load_2_17_13  segment_prefix_ub_1597  1
    load_2_17_13  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1444  -30
    arc_2_17_14  connected_order_arc_1445  -13
    arc_2_17_14  in_degree_1599  1
    arc_2_17_14  out_degree_1617  1
    arc_2_17_14  original_T_including_depot_unload_1656  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1444  1
    load_2_17_14  segment_load_conservation_1602  -1
    load_2_17_14  segment_prefix_lb_1603  1
    load_2_17_14  segment_prefix_ub_1604  1
    load_2_17_14  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1446  -30
    arc_2_17_15  connected_order_arc_1447  -13
    arc_2_17_15  in_degree_1606  1
    arc_2_17_15  out_degree_1617  1
    arc_2_17_15  original_T_including_depot_unload_1656  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1446  1
    load_2_17_15  free_load_conservation_1610  -1
    load_2_17_15  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1448  -30
    arc_2_17_16  connected_order_arc_1449  -13
    arc_2_17_16  in_degree_1612  1
    arc_2_17_16  out_degree_1617  1
    arc_2_17_16  original_T_including_depot_unload_1656  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1448  1
    load_2_17_16  free_load_conservation_1616  -1
    load_2_17_16  free_load_conservation_1622  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1450  -30
    arc_2_17_18  connected_order_arc_1451  -13
    arc_2_17_18  out_degree_1617  1
    arc_2_17_18  in_degree_1624  1
    arc_2_17_18  original_T_including_depot_unload_1656  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1450  1
    load_2_17_18  free_load_conservation_1622  1
    load_2_17_18  free_load_conservation_1628  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1452  -30
    arc_2_17_19  connected_order_arc_1453  -13
    arc_2_17_19  out_degree_1617  1
    arc_2_17_19  in_degree_1630  1
    arc_2_17_19  original_T_including_depot_unload_1656  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1452  1
    load_2_17_19  free_load_conservation_1622  1
    load_2_17_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1454  -30
    arc_2_17_20  connected_order_arc_1455  -13
    arc_2_17_20  out_degree_1617  1
    arc_2_17_20  in_degree_1636  1
    arc_2_17_20  original_T_including_depot_unload_1656  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1454  1
    load_2_17_20  free_load_conservation_1622  1
    load_2_17_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1456  -30
    arc_2_17_21  connected_order_arc_1457  -13
    arc_2_17_21  out_degree_1617  1
    arc_2_17_21  in_degree_1642  1
    arc_2_17_21  original_T_including_depot_unload_1656  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1456  1
    load_2_17_21  free_load_conservation_1622  1
    load_2_17_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1458  -30
    arc_2_17_22  connected_order_arc_1459  -13
    arc_2_17_22  out_degree_1617  1
    arc_2_17_22  in_degree_1648  1
    arc_2_17_22  original_T_including_depot_unload_1656  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1458  1
    load_2_17_22  free_load_conservation_1622  1
    load_2_17_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1460  -30
    arc_2_18_0  depot_return_or_bypass_1576  1
    arc_2_18_0  out_degree_1623  1
    arc_2_18_0  original_T_including_depot_unload_1656  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1460  1
    load_2_18_0  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1461  -30
    arc_2_18_11  connected_order_arc_1462  -13
    arc_2_18_11  in_degree_1578  1
    arc_2_18_11  out_degree_1623  1
    arc_2_18_11  original_T_including_depot_unload_1656  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1461  1
    load_2_18_11  segment_load_conservation_1581  -1
    load_2_18_11  segment_prefix_lb_1582  1
    load_2_18_11  segment_prefix_ub_1583  1
    load_2_18_11  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1463  -30
    arc_2_18_12  connected_order_arc_1464  -13
    arc_2_18_12  in_degree_1585  1
    arc_2_18_12  out_degree_1623  1
    arc_2_18_12  original_T_including_depot_unload_1656  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1463  1
    load_2_18_12  segment_load_conservation_1588  -1
    load_2_18_12  segment_prefix_lb_1589  1
    load_2_18_12  segment_prefix_ub_1590  1
    load_2_18_12  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1465  -30
    arc_2_18_13  connected_order_arc_1466  -13
    arc_2_18_13  in_degree_1592  1
    arc_2_18_13  out_degree_1623  1
    arc_2_18_13  original_T_including_depot_unload_1656  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1465  1
    load_2_18_13  segment_load_conservation_1595  -1
    load_2_18_13  segment_prefix_lb_1596  1
    load_2_18_13  segment_prefix_ub_1597  1
    load_2_18_13  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1467  -30
    arc_2_18_14  connected_order_arc_1468  -13
    arc_2_18_14  in_degree_1599  1
    arc_2_18_14  out_degree_1623  1
    arc_2_18_14  original_T_including_depot_unload_1656  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1467  1
    load_2_18_14  segment_load_conservation_1602  -1
    load_2_18_14  segment_prefix_lb_1603  1
    load_2_18_14  segment_prefix_ub_1604  1
    load_2_18_14  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1469  -30
    arc_2_18_15  connected_order_arc_1470  -13
    arc_2_18_15  in_degree_1606  1
    arc_2_18_15  out_degree_1623  1
    arc_2_18_15  original_T_including_depot_unload_1656  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1469  1
    load_2_18_15  free_load_conservation_1610  -1
    load_2_18_15  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1471  -30
    arc_2_18_16  connected_order_arc_1472  -13
    arc_2_18_16  in_degree_1612  1
    arc_2_18_16  out_degree_1623  1
    arc_2_18_16  original_T_including_depot_unload_1656  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1471  1
    load_2_18_16  free_load_conservation_1616  -1
    load_2_18_16  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1473  -30
    arc_2_18_17  connected_order_arc_1474  -13
    arc_2_18_17  in_degree_1618  1
    arc_2_18_17  out_degree_1623  1
    arc_2_18_17  original_T_including_depot_unload_1656  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1473  1
    load_2_18_17  free_load_conservation_1622  -1
    load_2_18_17  free_load_conservation_1628  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1475  -30
    arc_2_18_19  connected_order_arc_1476  -13
    arc_2_18_19  out_degree_1623  1
    arc_2_18_19  in_degree_1630  1
    arc_2_18_19  original_T_including_depot_unload_1656  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1475  1
    load_2_18_19  free_load_conservation_1628  1
    load_2_18_19  free_load_conservation_1634  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1477  -30
    arc_2_18_20  connected_order_arc_1478  -13
    arc_2_18_20  out_degree_1623  1
    arc_2_18_20  in_degree_1636  1
    arc_2_18_20  original_T_including_depot_unload_1656  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1477  1
    load_2_18_20  free_load_conservation_1628  1
    load_2_18_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1479  -30
    arc_2_18_21  connected_order_arc_1480  -13
    arc_2_18_21  out_degree_1623  1
    arc_2_18_21  in_degree_1642  1
    arc_2_18_21  original_T_including_depot_unload_1656  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1479  1
    load_2_18_21  free_load_conservation_1628  1
    load_2_18_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1481  -30
    arc_2_18_22  connected_order_arc_1482  -13
    arc_2_18_22  out_degree_1623  1
    arc_2_18_22  in_degree_1648  1
    arc_2_18_22  original_T_including_depot_unload_1656  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1481  1
    load_2_18_22  free_load_conservation_1628  1
    load_2_18_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1483  -30
    arc_2_19_0  depot_return_or_bypass_1576  1
    arc_2_19_0  out_degree_1629  1
    arc_2_19_0  original_T_including_depot_unload_1656  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1483  1
    load_2_19_0  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1484  -30
    arc_2_19_11  connected_order_arc_1485  -13
    arc_2_19_11  in_degree_1578  1
    arc_2_19_11  out_degree_1629  1
    arc_2_19_11  original_T_including_depot_unload_1656  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1484  1
    load_2_19_11  segment_load_conservation_1581  -1
    load_2_19_11  segment_prefix_lb_1582  1
    load_2_19_11  segment_prefix_ub_1583  1
    load_2_19_11  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1486  -30
    arc_2_19_12  connected_order_arc_1487  -13
    arc_2_19_12  in_degree_1585  1
    arc_2_19_12  out_degree_1629  1
    arc_2_19_12  original_T_including_depot_unload_1656  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1486  1
    load_2_19_12  segment_load_conservation_1588  -1
    load_2_19_12  segment_prefix_lb_1589  1
    load_2_19_12  segment_prefix_ub_1590  1
    load_2_19_12  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1488  -30
    arc_2_19_13  connected_order_arc_1489  -13
    arc_2_19_13  in_degree_1592  1
    arc_2_19_13  out_degree_1629  1
    arc_2_19_13  original_T_including_depot_unload_1656  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1488  1
    load_2_19_13  segment_load_conservation_1595  -1
    load_2_19_13  segment_prefix_lb_1596  1
    load_2_19_13  segment_prefix_ub_1597  1
    load_2_19_13  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1490  -30
    arc_2_19_14  connected_order_arc_1491  -13
    arc_2_19_14  in_degree_1599  1
    arc_2_19_14  out_degree_1629  1
    arc_2_19_14  original_T_including_depot_unload_1656  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1490  1
    load_2_19_14  segment_load_conservation_1602  -1
    load_2_19_14  segment_prefix_lb_1603  1
    load_2_19_14  segment_prefix_ub_1604  1
    load_2_19_14  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1492  -30
    arc_2_19_15  connected_order_arc_1493  -13
    arc_2_19_15  in_degree_1606  1
    arc_2_19_15  out_degree_1629  1
    arc_2_19_15  original_T_including_depot_unload_1656  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1492  1
    load_2_19_15  free_load_conservation_1610  -1
    load_2_19_15  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1494  -30
    arc_2_19_16  connected_order_arc_1495  -13
    arc_2_19_16  in_degree_1612  1
    arc_2_19_16  out_degree_1629  1
    arc_2_19_16  original_T_including_depot_unload_1656  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1494  1
    load_2_19_16  free_load_conservation_1616  -1
    load_2_19_16  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1496  -30
    arc_2_19_17  connected_order_arc_1497  -13
    arc_2_19_17  in_degree_1618  1
    arc_2_19_17  out_degree_1629  1
    arc_2_19_17  original_T_including_depot_unload_1656  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1496  1
    load_2_19_17  free_load_conservation_1622  -1
    load_2_19_17  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1498  -30
    arc_2_19_18  connected_order_arc_1499  -13
    arc_2_19_18  in_degree_1624  1
    arc_2_19_18  out_degree_1629  1
    arc_2_19_18  original_T_including_depot_unload_1656  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1498  1
    load_2_19_18  free_load_conservation_1628  -1
    load_2_19_18  free_load_conservation_1634  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1500  -30
    arc_2_19_20  connected_order_arc_1501  -13
    arc_2_19_20  out_degree_1629  1
    arc_2_19_20  in_degree_1636  1
    arc_2_19_20  original_T_including_depot_unload_1656  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1500  1
    load_2_19_20  free_load_conservation_1634  1
    load_2_19_20  free_load_conservation_1640  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1502  -30
    arc_2_19_21  connected_order_arc_1503  -13
    arc_2_19_21  out_degree_1629  1
    arc_2_19_21  in_degree_1642  1
    arc_2_19_21  original_T_including_depot_unload_1656  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1502  1
    load_2_19_21  free_load_conservation_1634  1
    load_2_19_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1504  -30
    arc_2_19_22  connected_order_arc_1505  -13
    arc_2_19_22  out_degree_1629  1
    arc_2_19_22  in_degree_1648  1
    arc_2_19_22  original_T_including_depot_unload_1656  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1504  1
    load_2_19_22  free_load_conservation_1634  1
    load_2_19_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1506  -30
    arc_2_20_0  depot_return_or_bypass_1576  1
    arc_2_20_0  out_degree_1635  1
    arc_2_20_0  original_T_including_depot_unload_1656  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1506  1
    load_2_20_0  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1507  -30
    arc_2_20_11  connected_order_arc_1508  -13
    arc_2_20_11  in_degree_1578  1
    arc_2_20_11  out_degree_1635  1
    arc_2_20_11  original_T_including_depot_unload_1656  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1507  1
    load_2_20_11  segment_load_conservation_1581  -1
    load_2_20_11  segment_prefix_lb_1582  1
    load_2_20_11  segment_prefix_ub_1583  1
    load_2_20_11  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1509  -30
    arc_2_20_12  connected_order_arc_1510  -13
    arc_2_20_12  in_degree_1585  1
    arc_2_20_12  out_degree_1635  1
    arc_2_20_12  original_T_including_depot_unload_1656  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1509  1
    load_2_20_12  segment_load_conservation_1588  -1
    load_2_20_12  segment_prefix_lb_1589  1
    load_2_20_12  segment_prefix_ub_1590  1
    load_2_20_12  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1511  -30
    arc_2_20_13  connected_order_arc_1512  -13
    arc_2_20_13  in_degree_1592  1
    arc_2_20_13  out_degree_1635  1
    arc_2_20_13  original_T_including_depot_unload_1656  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1511  1
    load_2_20_13  segment_load_conservation_1595  -1
    load_2_20_13  segment_prefix_lb_1596  1
    load_2_20_13  segment_prefix_ub_1597  1
    load_2_20_13  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1513  -30
    arc_2_20_14  connected_order_arc_1514  -13
    arc_2_20_14  in_degree_1599  1
    arc_2_20_14  out_degree_1635  1
    arc_2_20_14  original_T_including_depot_unload_1656  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1513  1
    load_2_20_14  segment_load_conservation_1602  -1
    load_2_20_14  segment_prefix_lb_1603  1
    load_2_20_14  segment_prefix_ub_1604  1
    load_2_20_14  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1515  -30
    arc_2_20_15  connected_order_arc_1516  -13
    arc_2_20_15  in_degree_1606  1
    arc_2_20_15  out_degree_1635  1
    arc_2_20_15  original_T_including_depot_unload_1656  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1515  1
    load_2_20_15  free_load_conservation_1610  -1
    load_2_20_15  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1517  -30
    arc_2_20_16  connected_order_arc_1518  -13
    arc_2_20_16  in_degree_1612  1
    arc_2_20_16  out_degree_1635  1
    arc_2_20_16  original_T_including_depot_unload_1656  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1517  1
    load_2_20_16  free_load_conservation_1616  -1
    load_2_20_16  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1519  -30
    arc_2_20_17  connected_order_arc_1520  -13
    arc_2_20_17  in_degree_1618  1
    arc_2_20_17  out_degree_1635  1
    arc_2_20_17  original_T_including_depot_unload_1656  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1519  1
    load_2_20_17  free_load_conservation_1622  -1
    load_2_20_17  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1521  -30
    arc_2_20_18  connected_order_arc_1522  -13
    arc_2_20_18  in_degree_1624  1
    arc_2_20_18  out_degree_1635  1
    arc_2_20_18  original_T_including_depot_unload_1656  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1521  1
    load_2_20_18  free_load_conservation_1628  -1
    load_2_20_18  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1523  -30
    arc_2_20_19  connected_order_arc_1524  -13
    arc_2_20_19  in_degree_1630  1
    arc_2_20_19  out_degree_1635  1
    arc_2_20_19  original_T_including_depot_unload_1656  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1523  1
    load_2_20_19  free_load_conservation_1634  -1
    load_2_20_19  free_load_conservation_1640  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1525  -30
    arc_2_20_21  connected_order_arc_1526  -13
    arc_2_20_21  out_degree_1635  1
    arc_2_20_21  in_degree_1642  1
    arc_2_20_21  original_T_including_depot_unload_1656  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1525  1
    load_2_20_21  free_load_conservation_1640  1
    load_2_20_21  free_load_conservation_1646  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1527  -30
    arc_2_20_22  connected_order_arc_1528  -13
    arc_2_20_22  out_degree_1635  1
    arc_2_20_22  in_degree_1648  1
    arc_2_20_22  original_T_including_depot_unload_1656  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1527  1
    load_2_20_22  free_load_conservation_1640  1
    load_2_20_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1529  -30
    arc_2_21_0  depot_return_or_bypass_1576  1
    arc_2_21_0  out_degree_1641  1
    arc_2_21_0  original_T_including_depot_unload_1656  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1529  1
    load_2_21_0  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1530  -30
    arc_2_21_11  connected_order_arc_1531  -13
    arc_2_21_11  in_degree_1578  1
    arc_2_21_11  out_degree_1641  1
    arc_2_21_11  original_T_including_depot_unload_1656  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1530  1
    load_2_21_11  segment_load_conservation_1581  -1
    load_2_21_11  segment_prefix_lb_1582  1
    load_2_21_11  segment_prefix_ub_1583  1
    load_2_21_11  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1532  -30
    arc_2_21_12  connected_order_arc_1533  -13
    arc_2_21_12  in_degree_1585  1
    arc_2_21_12  out_degree_1641  1
    arc_2_21_12  original_T_including_depot_unload_1656  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1532  1
    load_2_21_12  segment_load_conservation_1588  -1
    load_2_21_12  segment_prefix_lb_1589  1
    load_2_21_12  segment_prefix_ub_1590  1
    load_2_21_12  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1534  -30
    arc_2_21_13  connected_order_arc_1535  -13
    arc_2_21_13  in_degree_1592  1
    arc_2_21_13  out_degree_1641  1
    arc_2_21_13  original_T_including_depot_unload_1656  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1534  1
    load_2_21_13  segment_load_conservation_1595  -1
    load_2_21_13  segment_prefix_lb_1596  1
    load_2_21_13  segment_prefix_ub_1597  1
    load_2_21_13  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1536  -30
    arc_2_21_14  connected_order_arc_1537  -13
    arc_2_21_14  in_degree_1599  1
    arc_2_21_14  out_degree_1641  1
    arc_2_21_14  original_T_including_depot_unload_1656  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1536  1
    load_2_21_14  segment_load_conservation_1602  -1
    load_2_21_14  segment_prefix_lb_1603  1
    load_2_21_14  segment_prefix_ub_1604  1
    load_2_21_14  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1538  -30
    arc_2_21_15  connected_order_arc_1539  -13
    arc_2_21_15  in_degree_1606  1
    arc_2_21_15  out_degree_1641  1
    arc_2_21_15  original_T_including_depot_unload_1656  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1538  1
    load_2_21_15  free_load_conservation_1610  -1
    load_2_21_15  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1540  -30
    arc_2_21_16  connected_order_arc_1541  -13
    arc_2_21_16  in_degree_1612  1
    arc_2_21_16  out_degree_1641  1
    arc_2_21_16  original_T_including_depot_unload_1656  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1540  1
    load_2_21_16  free_load_conservation_1616  -1
    load_2_21_16  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1542  -30
    arc_2_21_17  connected_order_arc_1543  -13
    arc_2_21_17  in_degree_1618  1
    arc_2_21_17  out_degree_1641  1
    arc_2_21_17  original_T_including_depot_unload_1656  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1542  1
    load_2_21_17  free_load_conservation_1622  -1
    load_2_21_17  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1544  -30
    arc_2_21_18  connected_order_arc_1545  -13
    arc_2_21_18  in_degree_1624  1
    arc_2_21_18  out_degree_1641  1
    arc_2_21_18  original_T_including_depot_unload_1656  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1544  1
    load_2_21_18  free_load_conservation_1628  -1
    load_2_21_18  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1546  -30
    arc_2_21_19  connected_order_arc_1547  -13
    arc_2_21_19  in_degree_1630  1
    arc_2_21_19  out_degree_1641  1
    arc_2_21_19  original_T_including_depot_unload_1656  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1546  1
    load_2_21_19  free_load_conservation_1634  -1
    load_2_21_19  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1548  -30
    arc_2_21_20  connected_order_arc_1549  -13
    arc_2_21_20  in_degree_1636  1
    arc_2_21_20  out_degree_1641  1
    arc_2_21_20  original_T_including_depot_unload_1656  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1548  1
    load_2_21_20  free_load_conservation_1640  -1
    load_2_21_20  free_load_conservation_1646  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1550  -30
    arc_2_21_22  connected_order_arc_1551  -13
    arc_2_21_22  out_degree_1641  1
    arc_2_21_22  in_degree_1648  1
    arc_2_21_22  original_T_including_depot_unload_1656  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1550  1
    load_2_21_22  free_load_conservation_1646  1
    load_2_21_22  free_load_conservation_1652  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1552  -30
    arc_2_22_0  depot_return_or_bypass_1576  1
    arc_2_22_0  out_degree_1647  1
    arc_2_22_0  original_T_including_depot_unload_1656  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1552  1
    load_2_22_0  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1553  -30
    arc_2_22_11  connected_order_arc_1554  -13
    arc_2_22_11  in_degree_1578  1
    arc_2_22_11  out_degree_1647  1
    arc_2_22_11  original_T_including_depot_unload_1656  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1553  1
    load_2_22_11  segment_load_conservation_1581  -1
    load_2_22_11  segment_prefix_lb_1582  1
    load_2_22_11  segment_prefix_ub_1583  1
    load_2_22_11  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1555  -30
    arc_2_22_12  connected_order_arc_1556  -13
    arc_2_22_12  in_degree_1585  1
    arc_2_22_12  out_degree_1647  1
    arc_2_22_12  original_T_including_depot_unload_1656  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1555  1
    load_2_22_12  segment_load_conservation_1588  -1
    load_2_22_12  segment_prefix_lb_1589  1
    load_2_22_12  segment_prefix_ub_1590  1
    load_2_22_12  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1557  -30
    arc_2_22_13  connected_order_arc_1558  -13
    arc_2_22_13  in_degree_1592  1
    arc_2_22_13  out_degree_1647  1
    arc_2_22_13  original_T_including_depot_unload_1656  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1557  1
    load_2_22_13  segment_load_conservation_1595  -1
    load_2_22_13  segment_prefix_lb_1596  1
    load_2_22_13  segment_prefix_ub_1597  1
    load_2_22_13  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1559  -30
    arc_2_22_14  connected_order_arc_1560  -13
    arc_2_22_14  in_degree_1599  1
    arc_2_22_14  out_degree_1647  1
    arc_2_22_14  original_T_including_depot_unload_1656  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1559  1
    load_2_22_14  segment_load_conservation_1602  -1
    load_2_22_14  segment_prefix_lb_1603  1
    load_2_22_14  segment_prefix_ub_1604  1
    load_2_22_14  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1561  -30
    arc_2_22_15  connected_order_arc_1562  -13
    arc_2_22_15  in_degree_1606  1
    arc_2_22_15  out_degree_1647  1
    arc_2_22_15  original_T_including_depot_unload_1656  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1561  1
    load_2_22_15  free_load_conservation_1610  -1
    load_2_22_15  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1563  -30
    arc_2_22_16  connected_order_arc_1564  -13
    arc_2_22_16  in_degree_1612  1
    arc_2_22_16  out_degree_1647  1
    arc_2_22_16  original_T_including_depot_unload_1656  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1563  1
    load_2_22_16  free_load_conservation_1616  -1
    load_2_22_16  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1565  -30
    arc_2_22_17  connected_order_arc_1566  -13
    arc_2_22_17  in_degree_1618  1
    arc_2_22_17  out_degree_1647  1
    arc_2_22_17  original_T_including_depot_unload_1656  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1565  1
    load_2_22_17  free_load_conservation_1622  -1
    load_2_22_17  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1567  -30
    arc_2_22_18  connected_order_arc_1568  -13
    arc_2_22_18  in_degree_1624  1
    arc_2_22_18  out_degree_1647  1
    arc_2_22_18  original_T_including_depot_unload_1656  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1567  1
    load_2_22_18  free_load_conservation_1628  -1
    load_2_22_18  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1569  -30
    arc_2_22_19  connected_order_arc_1570  -13
    arc_2_22_19  in_degree_1630  1
    arc_2_22_19  out_degree_1647  1
    arc_2_22_19  original_T_including_depot_unload_1656  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1569  1
    load_2_22_19  free_load_conservation_1634  -1
    load_2_22_19  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1571  -30
    arc_2_22_20  connected_order_arc_1572  -13
    arc_2_22_20  in_degree_1636  1
    arc_2_22_20  out_degree_1647  1
    arc_2_22_20  original_T_including_depot_unload_1656  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1571  1
    load_2_22_20  free_load_conservation_1640  -1
    load_2_22_20  free_load_conservation_1652  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1573  -30
    arc_2_22_21  connected_order_arc_1574  -13
    arc_2_22_21  in_degree_1642  1
    arc_2_22_21  out_degree_1647  1
    arc_2_22_21  original_T_including_depot_unload_1656  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1573  1
    load_2_22_21  free_load_conservation_1646  -1
    load_2_22_21  free_load_conservation_1652  1
RHS
    RHS1      OBJ       -0.4995
    RHS1      onehot_8_44  1
    RHS1      onehot_2_79  1
    RHS1      onehot_31_108  1
    RHS1      onehot_6_133  1
    RHS1      onehot_16_162  1
    RHS1      onehot_5_199  1
    RHS1      onehot_26_220  1
    RHS1      onehot_14_255  1
    RHS1      stock_ub_259  35
    RHS1      parent_nonstrict_scope_260  3.5294083613095739e-01
    RHS1      normalization_317  1
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_700  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_710  -13
    RHS1      connected_order_arc_712  -13
    RHS1      connected_order_arc_714  -13
    RHS1      connected_order_arc_716  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_723  -13
    RHS1      connected_order_arc_725  -13
    RHS1      connected_order_arc_727  -13
    RHS1      connected_order_arc_729  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_733  -13
    RHS1      connected_order_arc_735  -13
    RHS1      connected_order_arc_737  -13
    RHS1      connected_order_arc_739  -13
    RHS1      connected_order_arc_741  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_746  -13
    RHS1      connected_order_arc_748  -13
    RHS1      connected_order_arc_750  -13
    RHS1      connected_order_arc_752  -13
    RHS1      connected_order_arc_754  -13
    RHS1      connected_order_arc_756  -13
    RHS1      connected_order_arc_758  -13
    RHS1      connected_order_arc_760  -13
    RHS1      connected_order_arc_762  -13
    RHS1      connected_order_arc_764  -13
    RHS1      connected_order_arc_766  -13
    RHS1      depot_departure_or_bypass_767  1
    RHS1      depot_return_or_bypass_768  1
    RHS1      segment_load_conservation_773  5
    RHS1      segment_prefix_ub_775  15
    RHS1      segment_load_conservation_780  13
    RHS1      segment_prefix_ub_782  7
    RHS1      segment_load_conservation_787  -8
    RHS1      segment_prefix_lb_788  8
    RHS1      segment_prefix_ub_789  20
    RHS1      segment_load_conservation_794  5
    RHS1      segment_prefix_ub_796  15
    RHS1      segment_load_conservation_801  -14
    RHS1      segment_prefix_lb_802  14
    RHS1      segment_prefix_ub_803  20
    RHS1      fixed_segment_relative_order_852  1
    RHS1      fixed_segment_relative_order_853  1
    RHS1      fixed_segment_relative_order_854  1
    RHS1      fixed_segment_relative_order_855  1
    RHS1      original_T_including_depot_unload_856  3.4844750655449343e+03
    RHS1      connected_order_arc_873  -13
    RHS1      connected_order_arc_875  -13
    RHS1      connected_order_arc_877  -13
    RHS1      connected_order_arc_879  -13
    RHS1      connected_order_arc_881  -13
    RHS1      connected_order_arc_883  -13
    RHS1      connected_order_arc_885  -13
    RHS1      connected_order_arc_887  -13
    RHS1      connected_order_arc_889  -13
    RHS1      connected_order_arc_891  -13
    RHS1      connected_order_arc_893  -13
    RHS1      connected_order_arc_895  -13
    RHS1      connected_order_arc_898  -13
    RHS1      connected_order_arc_900  -13
    RHS1      connected_order_arc_902  -13
    RHS1      connected_order_arc_904  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_908  -13
    RHS1      connected_order_arc_910  -13
    RHS1      connected_order_arc_912  -13
    RHS1      connected_order_arc_914  -13
    RHS1      connected_order_arc_916  -13
    RHS1      connected_order_arc_918  -13
    RHS1      connected_order_arc_920  -13
    RHS1      connected_order_arc_923  -13
    RHS1      connected_order_arc_925  -13
    RHS1      connected_order_arc_927  -13
    RHS1      connected_order_arc_929  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_933  -13
    RHS1      connected_order_arc_935  -13
    RHS1      connected_order_arc_937  -13
    RHS1      connected_order_arc_939  -13
    RHS1      connected_order_arc_941  -13
    RHS1      connected_order_arc_943  -13
    RHS1      connected_order_arc_945  -13
    RHS1      connected_order_arc_948  -13
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_952  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_962  -13
    RHS1      connected_order_arc_964  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_973  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_977  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_987  -13
    RHS1      connected_order_arc_989  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_998  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1002  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1012  -13
    RHS1      connected_order_arc_1014  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1023  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1027  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1037  -13
    RHS1      connected_order_arc_1039  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1048  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1052  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1062  -13
    RHS1      connected_order_arc_1064  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1073  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1087  -13
    RHS1      connected_order_arc_1089  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1098  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1112  -13
    RHS1      connected_order_arc_1114  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1123  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1127  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1133  -13
    RHS1      connected_order_arc_1135  -13
    RHS1      connected_order_arc_1137  -13
    RHS1      connected_order_arc_1139  -13
    RHS1      connected_order_arc_1141  -13
    RHS1      connected_order_arc_1143  -13
    RHS1      connected_order_arc_1145  -13
    RHS1      connected_order_arc_1148  -13
    RHS1      connected_order_arc_1150  -13
    RHS1      connected_order_arc_1152  -13
    RHS1      connected_order_arc_1154  -13
    RHS1      connected_order_arc_1156  -13
    RHS1      connected_order_arc_1158  -13
    RHS1      connected_order_arc_1160  -13
    RHS1      connected_order_arc_1162  -13
    RHS1      connected_order_arc_1164  -13
    RHS1      connected_order_arc_1166  -13
    RHS1      connected_order_arc_1168  -13
    RHS1      connected_order_arc_1170  -13
    RHS1      connected_order_arc_1173  -13
    RHS1      connected_order_arc_1175  -13
    RHS1      connected_order_arc_1177  -13
    RHS1      connected_order_arc_1179  -13
    RHS1      connected_order_arc_1181  -13
    RHS1      connected_order_arc_1183  -13
    RHS1      connected_order_arc_1185  -13
    RHS1      connected_order_arc_1187  -13
    RHS1      connected_order_arc_1189  -13
    RHS1      connected_order_arc_1191  -13
    RHS1      connected_order_arc_1193  -13
    RHS1      connected_order_arc_1195  -13
    RHS1      depot_departure_or_bypass_1196  1
    RHS1      depot_return_or_bypass_1197  1
    RHS1      segment_load_conservation_1202  6
    RHS1      segment_prefix_ub_1204  19
    RHS1      segment_load_conservation_1209  -5
    RHS1      segment_prefix_lb_1210  6
    RHS1      segment_prefix_ub_1211  25
    RHS1      segment_load_conservation_1216  3
    RHS1      segment_prefix_ub_1218  22
    RHS1      segment_load_conservation_1223  3
    RHS1      segment_prefix_ub_1225  22
    RHS1      segment_load_conservation_1230  -5
    RHS1      segment_prefix_lb_1231  5
    RHS1      segment_prefix_ub_1232  25
    RHS1      fixed_segment_relative_order_1281  1
    RHS1      fixed_segment_relative_order_1282  1
    RHS1      fixed_segment_relative_order_1283  1
    RHS1      fixed_segment_relative_order_1284  1
    RHS1      original_T_including_depot_unload_1285  2.2933958320926176e+03
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1305  -12
    RHS1      connected_order_arc_1307  -12
    RHS1      connected_order_arc_1309  -12
    RHS1      connected_order_arc_1311  -12
    RHS1      connected_order_arc_1313  -12
    RHS1      connected_order_arc_1315  -12
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1321  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1328  -12
    RHS1      connected_order_arc_1330  -12
    RHS1      connected_order_arc_1332  -12
    RHS1      connected_order_arc_1334  -12
    RHS1      connected_order_arc_1336  -12
    RHS1      connected_order_arc_1338  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1344  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1351  -12
    RHS1      connected_order_arc_1353  -12
    RHS1      connected_order_arc_1355  -12
    RHS1      connected_order_arc_1357  -12
    RHS1      connected_order_arc_1359  -12
    RHS1      connected_order_arc_1361  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1367  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1374  -12
    RHS1      connected_order_arc_1376  -12
    RHS1      connected_order_arc_1378  -12
    RHS1      connected_order_arc_1380  -12
    RHS1      connected_order_arc_1382  -12
    RHS1      connected_order_arc_1384  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1390  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1397  -12
    RHS1      connected_order_arc_1399  -12
    RHS1      connected_order_arc_1401  -12
    RHS1      connected_order_arc_1403  -12
    RHS1      connected_order_arc_1405  -12
    RHS1      connected_order_arc_1407  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1413  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1420  -12
    RHS1      connected_order_arc_1422  -12
    RHS1      connected_order_arc_1424  -12
    RHS1      connected_order_arc_1426  -12
    RHS1      connected_order_arc_1428  -12
    RHS1      connected_order_arc_1430  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1436  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1443  -12
    RHS1      connected_order_arc_1445  -12
    RHS1      connected_order_arc_1447  -12
    RHS1      connected_order_arc_1449  -12
    RHS1      connected_order_arc_1451  -12
    RHS1      connected_order_arc_1453  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1459  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1466  -12
    RHS1      connected_order_arc_1468  -12
    RHS1      connected_order_arc_1470  -12
    RHS1      connected_order_arc_1472  -12
    RHS1      connected_order_arc_1474  -12
    RHS1      connected_order_arc_1476  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1482  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1489  -12
    RHS1      connected_order_arc_1491  -12
    RHS1      connected_order_arc_1493  -12
    RHS1      connected_order_arc_1495  -12
    RHS1      connected_order_arc_1497  -12
    RHS1      connected_order_arc_1499  -12
    RHS1      connected_order_arc_1501  -12
    RHS1      connected_order_arc_1503  -12
    RHS1      connected_order_arc_1505  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      connected_order_arc_1512  -12
    RHS1      connected_order_arc_1514  -12
    RHS1      connected_order_arc_1516  -12
    RHS1      connected_order_arc_1518  -12
    RHS1      connected_order_arc_1520  -12
    RHS1      connected_order_arc_1522  -12
    RHS1      connected_order_arc_1524  -12
    RHS1      connected_order_arc_1526  -12
    RHS1      connected_order_arc_1528  -12
    RHS1      connected_order_arc_1531  -12
    RHS1      connected_order_arc_1533  -12
    RHS1      connected_order_arc_1535  -12
    RHS1      connected_order_arc_1537  -12
    RHS1      connected_order_arc_1539  -12
    RHS1      connected_order_arc_1541  -12
    RHS1      connected_order_arc_1543  -12
    RHS1      connected_order_arc_1545  -12
    RHS1      connected_order_arc_1547  -12
    RHS1      connected_order_arc_1549  -12
    RHS1      connected_order_arc_1551  -12
    RHS1      connected_order_arc_1554  -12
    RHS1      connected_order_arc_1556  -12
    RHS1      connected_order_arc_1558  -12
    RHS1      connected_order_arc_1560  -12
    RHS1      connected_order_arc_1562  -12
    RHS1      connected_order_arc_1564  -12
    RHS1      connected_order_arc_1566  -12
    RHS1      connected_order_arc_1568  -12
    RHS1      connected_order_arc_1570  -12
    RHS1      connected_order_arc_1572  -12
    RHS1      connected_order_arc_1574  -12
    RHS1      depot_departure_or_bypass_1575  1
    RHS1      depot_return_or_bypass_1576  1
    RHS1      segment_load_conservation_1581  2
    RHS1      segment_prefix_ub_1583  28
    RHS1      segment_load_conservation_1588  3
    RHS1      segment_prefix_ub_1590  27
    RHS1      segment_load_conservation_1595  -2
    RHS1      segment_prefix_lb_1596  2
    RHS1      segment_prefix_ub_1597  30
    RHS1      segment_load_conservation_1602  6
    RHS1      segment_prefix_ub_1604  24
    RHS1      fixed_segment_relative_order_1653  1
    RHS1      fixed_segment_relative_order_1654  1
    RHS1      fixed_segment_relative_order_1655  1
    RHS1      original_T_including_depot_unload_1656  5392.18965781578
BOUNDS
 LO BND1      t         2.4773645559889104e-02
 UP BND1      t         4.0760869565258165e-02
 UP BND1      q         5.3744083613095739e-01
 BV BND1      x_8_0   
 UP BND1      w_8_0     4.0760869565258165e-02
 BV BND1      x_8_1   
 UP BND1      w_8_1     4.0760869565258165e-02
 BV BND1      x_8_2   
 UP BND1      w_8_2     4.0760869565258165e-02
 BV BND1      x_8_3   
 UP BND1      w_8_3     4.0760869565258165e-02
 BV BND1      x_8_4   
 UP BND1      w_8_4     4.0760869565258165e-02
 BV BND1      x_8_5   
 UP BND1      w_8_5     4.0760869565258165e-02
 BV BND1      x_8_6   
 UP BND1      w_8_6     4.0760869565258165e-02
 BV BND1      x_8_7   
 UP BND1      w_8_7     4.0760869565258165e-02
 BV BND1      x_8_8   
 UP BND1      w_8_8     4.0760869565258165e-02
 BV BND1      x_8_9   
 UP BND1      w_8_9     4.0760869565258165e-02
 BV BND1      x_8_10  
 UP BND1      w_8_10    4.0760869565258165e-02
 BV BND1      x_8_11  
 UP BND1      w_8_11    4.0760869565258165e-02
 BV BND1      x_8_12  
 UP BND1      w_8_12    4.0760869565258165e-02
 BV BND1      x_8_13  
 UP BND1      w_8_13    4.0760869565258165e-02
 BV BND1      x_8_14  
 UP BND1      w_8_14    4.0760869565258165e-02
 BV BND1      x_8_15  
 UP BND1      w_8_15    4.0760869565258165e-02
 BV BND1      x_8_16  
 UP BND1      w_8_16    4.0760869565258165e-02
 BV BND1      x_8_17  
 UP BND1      w_8_17    4.0760869565258165e-02
 BV BND1      x_8_18  
 UP BND1      w_8_18    4.0760869565258165e-02
 BV BND1      x_8_19  
 UP BND1      w_8_19    4.0760869565258165e-02
 BV BND1      x_8_20  
 UP BND1      w_8_20    4.0760869565258165e-02
 BV BND1      x_8_21  
 UP BND1      w_8_21    4.0760869565258165e-02
 UP BND1      rho_8     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.0760869565258165e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.0760869565258165e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.0760869565258165e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.0760869565258165e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.0760869565258165e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.0760869565258165e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.0760869565258165e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.0760869565258165e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.0760869565258165e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.0760869565258165e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.0760869565258165e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.0760869565258165e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.0760869565258165e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.0760869565258165e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.0760869565258165e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.0760869565258165e-02
 UP BND1      rho_2     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.0760869565258165e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.0760869565258165e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.0760869565258165e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.0760869565258165e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.0760869565258165e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.0760869565258165e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.0760869565258165e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.0760869565258165e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.0760869565258165e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.0760869565258165e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.0760869565258165e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.0760869565258165e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.0760869565258165e-02
 UP BND1      rho_31    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.0760869565258165e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.0760869565258165e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.0760869565258165e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.0760869565258165e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.0760869565258165e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.0760869565258165e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.0760869565258165e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.0760869565258165e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.0760869565258165e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.0760869565258165e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.0760869565258165e-02
 UP BND1      rho_6     1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.0760869565258165e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.0760869565258165e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.0760869565258165e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.0760869565258165e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.0760869565258165e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.0760869565258165e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.0760869565258165e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.0760869565258165e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.0760869565258165e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.0760869565258165e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.0760869565258165e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.0760869565258165e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.0760869565258165e-02
 UP BND1      rho_16    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.0760869565258165e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.0760869565258165e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.0760869565258165e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.0760869565258165e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.0760869565258165e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.0760869565258165e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.0760869565258165e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.0760869565258165e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.0760869565258165e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.0760869565258165e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.0760869565258165e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.0760869565258165e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.0760869565258165e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.0760869565258165e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.0760869565258165e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.0760869565258165e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.0760869565258165e-02
 UP BND1      rho_5     1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.0760869565258165e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.0760869565258165e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.0760869565258165e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.0760869565258165e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.0760869565258165e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.0760869565258165e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.0760869565258165e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.0760869565258165e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.0760869565258165e-02
 UP BND1      rho_26    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.0760869565258165e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.0760869565258165e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.0760869565258165e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.0760869565258165e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.0760869565258165e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.0760869565258165e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.0760869565258165e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.0760869565258165e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.0760869565258165e-02
 BV BND1      x_14_9  
 UP BND1      w_14_9    4.0760869565258165e-02
 BV BND1      x_14_10 
 UP BND1      w_14_10   4.0760869565258165e-02
 BV BND1      x_14_11 
 UP BND1      w_14_11   4.0760869565258165e-02
 BV BND1      x_14_12 
 UP BND1      w_14_12   4.0760869565258165e-02
 BV BND1      x_14_13 
 UP BND1      w_14_13   4.0760869565258165e-02
 BV BND1      x_14_14 
 UP BND1      w_14_14   4.0760869565258165e-02
 BV BND1      x_14_15 
 UP BND1      w_14_15   4.0760869565258165e-02
 UP BND1      rho_14    1
 UP BND1      a_8_2     1
 UP BND1      a_8_31    1
 UP BND1      a_8_6     1
 UP BND1      a_8_16    1
 UP BND1      a_8_5     1
 UP BND1      a_8_26    1
 UP BND1      a_8_14    1
 UP BND1      a_2_31    1
 UP BND1      a_2_6     1
 UP BND1      a_2_16    1
 UP BND1      a_2_5     1
 UP BND1      a_2_26    1
 UP BND1      a_2_14    1
 UP BND1      a_31_6    1
 UP BND1      a_31_16   1
 UP BND1      a_31_5    1
 UP BND1      a_31_26   1
 UP BND1      a_31_14   1
 UP BND1      a_6_16    1
 UP BND1      a_6_5     1
 UP BND1      a_6_26    1
 UP BND1      a_6_14    1
 UP BND1      a_16_5    1
 UP BND1      a_16_26   1
 UP BND1      a_16_14   1
 UP BND1      a_5_26    1
 UP BND1      a_5_14    1
 UP BND1      a_26_14   1
 BV BND1      service_0_8_0
 BV BND1      service_0_8_1
 BV BND1      service_0_8_2
 BV BND1      service_0_8_3
 BV BND1      service_0_8_4
 BV BND1      service_0_8_5
 BV BND1      service_0_8_6
 BV BND1      service_0_8_7
 BV BND1      service_0_8_8
 BV BND1      service_0_8_9
 BV BND1      service_0_8_10
 BV BND1      service_0_8_11
 BV BND1      service_0_8_12
 BV BND1      service_0_8_13
 BV BND1      service_0_8_14
 BV BND1      service_0_8_16
 BV BND1      service_0_8_17
 BV BND1      service_0_8_18
 BV BND1      service_0_8_19
 BV BND1      service_0_8_20
 BV BND1      service_0_8_21
 BV BND1      service_1_8_0
 BV BND1      service_1_8_1
 BV BND1      service_1_8_2
 BV BND1      service_1_8_3
 BV BND1      service_1_8_4
 BV BND1      service_1_8_5
 BV BND1      service_1_8_6
 BV BND1      service_1_8_7
 BV BND1      service_1_8_8
 BV BND1      service_1_8_9
 BV BND1      service_1_8_10
 BV BND1      service_1_8_11
 BV BND1      service_1_8_12
 BV BND1      service_1_8_13
 BV BND1      service_1_8_14
 BV BND1      service_1_8_16
 BV BND1      service_1_8_17
 BV BND1      service_1_8_18
 BV BND1      service_1_8_19
 BV BND1      service_1_8_20
 BV BND1      service_1_8_21
 BV BND1      service_2_8_0
 BV BND1      service_2_8_1
 BV BND1      service_2_8_2
 BV BND1      service_2_8_3
 BV BND1      service_2_8_4
 BV BND1      service_2_8_5
 BV BND1      service_2_8_6
 BV BND1      service_2_8_7
 BV BND1      service_2_8_8
 BV BND1      service_2_8_9
 BV BND1      service_2_8_10
 BV BND1      service_2_8_11
 BV BND1      service_2_8_12
 BV BND1      service_2_8_13
 BV BND1      service_2_8_14
 BV BND1      service_2_8_16
 BV BND1      service_2_8_17
 BV BND1      service_2_8_18
 BV BND1      service_2_8_19
 BV BND1      service_2_8_20
 BV BND1      service_2_8_21
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_5
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_5
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_5
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_11
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_11
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_2_14_9
 BV BND1      service_2_14_10
 BV BND1      service_2_14_11
 BV BND1      service_2_14_12
 BV BND1      service_2_14_13
 BV BND1      service_2_14_14
 BV BND1      service_2_14_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_6_22
 UP BND1      load_1_6_22  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_6
 UP BND1      load_1_22_6  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
