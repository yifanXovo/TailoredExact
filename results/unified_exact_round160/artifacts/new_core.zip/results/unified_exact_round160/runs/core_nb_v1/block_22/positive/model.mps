* Signature: 0x164228b26aaae257
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 E  onehot_10_40
 E  normalized_mass_10_41
 E  normalized_ratio_10_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 G  product_lb_75
 L  product_ub_76
 G  product_lb_77
 L  product_ub_78
 E  onehot_7_79
 E  normalized_mass_7_80
 E  normalized_ratio_7_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 E  onehot_31_108
 E  normalized_mass_31_109
 E  normalized_ratio_31_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 E  onehot_3_147
 E  normalized_mass_3_148
 E  normalized_ratio_3_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 E  onehot_14_182
 E  normalized_mass_14_183
 E  normalized_ratio_14_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 E  onehot_11_211
 E  normalized_mass_11_212
 E  normalized_ratio_11_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 G  product_lb_230
 L  product_ub_231
 G  product_lb_232
 L  product_ub_233
 G  product_lb_234
 L  product_ub_235
 G  product_lb_236
 L  product_ub_237
 G  product_lb_238
 L  product_ub_239
 G  product_lb_240
 L  product_ub_241
 G  product_lb_242
 L  product_ub_243
 G  product_lb_244
 L  product_ub_245
 E  onehot_2_246
 E  normalized_mass_2_247
 E  normalized_ratio_2_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 G  product_lb_265
 L  product_ub_266
 G  product_lb_267
 L  product_ub_268
 G  product_lb_269
 L  product_ub_270
 G  product_lb_271
 L  product_ub_272
 G  product_lb_273
 L  product_ub_274
 G  product_lb_275
 L  product_ub_276
 G  product_lb_277
 L  product_ub_278
 G  product_lb_279
 L  product_ub_280
 E  onehot_4_281
 E  normalized_mass_4_282
 E  normalized_ratio_4_283
 G  stock_lb_284
 L  stock_ub_285
 L  parent_nonstrict_scope_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 G  block_pair_pos_327
 G  block_pair_neg_328
 G  block_pair_pos_329
 G  block_pair_neg_330
 G  block_pair_pos_331
 G  block_pair_neg_332
 G  block_pair_pos_333
 G  block_pair_neg_334
 G  block_pair_pos_335
 G  block_pair_neg_336
 G  block_pair_pos_337
 G  block_pair_neg_338
 G  block_pair_pos_339
 G  block_pair_neg_340
 G  block_pair_pos_341
 G  block_pair_neg_342
 E  normalization_343
 G  full_original_Gini_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 E  unique_nonzero_owner_443
 E  unique_nonzero_owner_444
 E  unique_nonzero_owner_445
 E  unique_nonzero_owner_446
 E  unique_nonzero_owner_447
 E  unique_nonzero_owner_448
 E  unique_nonzero_owner_449
 E  unique_nonzero_owner_450
 E  unique_nonzero_owner_451
 E  unique_nonzero_owner_452
 E  unique_nonzero_owner_453
 E  unique_nonzero_owner_454
 E  unique_nonzero_owner_455
 E  unique_nonzero_owner_456
 E  unique_nonzero_owner_457
 E  unique_nonzero_owner_458
 E  unique_nonzero_owner_459
 E  unique_nonzero_owner_460
 E  unique_nonzero_owner_461
 E  unique_nonzero_owner_462
 E  unique_nonzero_owner_463
 E  unique_nonzero_owner_464
 E  unique_nonzero_owner_465
 E  unique_nonzero_owner_466
 L  arc_capacity_467
 L  arc_capacity_468
 L  arc_capacity_469
 L  arc_capacity_470
 L  arc_capacity_471
 L  arc_capacity_472
 L  arc_capacity_473
 L  arc_capacity_474
 L  arc_capacity_475
 L  arc_capacity_476
 L  arc_capacity_477
 L  arc_capacity_478
 L  arc_capacity_479
 L  arc_capacity_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 E  depot_departure_or_bypass_756
 E  depot_return_or_bypass_757
 E  out_degree_758
 E  in_degree_759
 G  order_active_lb_760
 L  order_active_ub_761
 E  segment_load_conservation_762
 G  segment_prefix_lb_763
 L  segment_prefix_ub_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  segment_load_conservation_769
 G  segment_prefix_lb_770
 L  segment_prefix_ub_771
 E  out_degree_772
 E  in_degree_773
 G  order_active_lb_774
 L  order_active_ub_775
 E  segment_load_conservation_776
 G  segment_prefix_lb_777
 L  segment_prefix_ub_778
 E  out_degree_779
 E  in_degree_780
 G  order_active_lb_781
 L  order_active_ub_782
 E  segment_load_conservation_783
 G  segment_prefix_lb_784
 L  segment_prefix_ub_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  service_visit_def_796
 E  free_load_conservation_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  service_visit_def_802
 E  free_load_conservation_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  service_visit_def_808
 E  free_load_conservation_809
 E  out_degree_810
 E  in_degree_811
 G  order_active_lb_812
 L  order_active_ub_813
 E  service_visit_def_814
 E  free_load_conservation_815
 E  out_degree_816
 E  in_degree_817
 G  order_active_lb_818
 L  order_active_ub_819
 E  service_visit_def_820
 E  free_load_conservation_821
 E  out_degree_822
 E  in_degree_823
 G  order_active_lb_824
 L  order_active_ub_825
 E  service_visit_def_826
 E  free_load_conservation_827
 E  out_degree_828
 E  in_degree_829
 G  order_active_lb_830
 L  order_active_ub_831
 E  service_visit_def_832
 E  free_load_conservation_833
 G  fixed_segment_relative_order_834
 G  fixed_segment_relative_order_835
 G  fixed_segment_relative_order_836
 L  original_T_including_depot_unload_837
 L  arc_capacity_838
 L  arc_capacity_839
 L  arc_capacity_840
 L  arc_capacity_841
 L  arc_capacity_842
 L  arc_capacity_843
 L  arc_capacity_844
 L  arc_capacity_845
 L  arc_capacity_846
 L  arc_capacity_847
 L  arc_capacity_848
 L  arc_capacity_849
 L  arc_capacity_850
 L  arc_capacity_851
 L  arc_capacity_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 E  depot_departure_or_bypass_1177
 E  depot_return_or_bypass_1178
 E  out_degree_1179
 E  in_degree_1180
 G  order_active_lb_1181
 L  order_active_ub_1182
 E  segment_load_conservation_1183
 G  segment_prefix_lb_1184
 L  segment_prefix_ub_1185
 E  out_degree_1186
 E  in_degree_1187
 G  order_active_lb_1188
 L  order_active_ub_1189
 E  segment_load_conservation_1190
 G  segment_prefix_lb_1191
 L  segment_prefix_ub_1192
 E  out_degree_1193
 E  in_degree_1194
 G  order_active_lb_1195
 L  order_active_ub_1196
 E  segment_load_conservation_1197
 G  segment_prefix_lb_1198
 L  segment_prefix_ub_1199
 E  out_degree_1200
 E  in_degree_1201
 G  order_active_lb_1202
 L  order_active_ub_1203
 E  segment_load_conservation_1204
 G  segment_prefix_lb_1205
 L  segment_prefix_ub_1206
 E  out_degree_1207
 E  in_degree_1208
 G  order_active_lb_1209
 L  order_active_ub_1210
 E  segment_load_conservation_1211
 G  segment_prefix_lb_1212
 L  segment_prefix_ub_1213
 E  out_degree_1214
 E  in_degree_1215
 G  order_active_lb_1216
 L  order_active_ub_1217
 E  service_visit_def_1218
 E  free_load_conservation_1219
 E  out_degree_1220
 E  in_degree_1221
 G  order_active_lb_1222
 L  order_active_ub_1223
 E  service_visit_def_1224
 E  free_load_conservation_1225
 E  out_degree_1226
 E  in_degree_1227
 G  order_active_lb_1228
 L  order_active_ub_1229
 E  service_visit_def_1230
 E  free_load_conservation_1231
 E  out_degree_1232
 E  in_degree_1233
 G  order_active_lb_1234
 L  order_active_ub_1235
 E  service_visit_def_1236
 E  free_load_conservation_1237
 E  out_degree_1238
 E  in_degree_1239
 G  order_active_lb_1240
 L  order_active_ub_1241
 E  service_visit_def_1242
 E  free_load_conservation_1243
 E  out_degree_1244
 E  in_degree_1245
 G  order_active_lb_1246
 L  order_active_ub_1247
 E  service_visit_def_1248
 E  free_load_conservation_1249
 E  out_degree_1250
 E  in_degree_1251
 G  order_active_lb_1252
 L  order_active_ub_1253
 E  service_visit_def_1254
 E  free_load_conservation_1255
 E  out_degree_1256
 E  in_degree_1257
 G  order_active_lb_1258
 L  order_active_ub_1259
 E  service_visit_def_1260
 E  free_load_conservation_1261
 G  fixed_segment_relative_order_1262
 G  fixed_segment_relative_order_1263
 G  fixed_segment_relative_order_1264
 G  fixed_segment_relative_order_1265
 L  original_T_including_depot_unload_1266
 L  arc_capacity_1267
 L  arc_capacity_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 L  arc_capacity_1271
 L  arc_capacity_1272
 L  arc_capacity_1273
 L  arc_capacity_1274
 L  arc_capacity_1275
 L  arc_capacity_1276
 L  arc_capacity_1277
 L  arc_capacity_1278
 L  arc_capacity_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 G  connected_order_arc_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 E  depot_departure_or_bypass_1510
 E  depot_return_or_bypass_1511
 E  out_degree_1512
 E  in_degree_1513
 G  order_active_lb_1514
 L  order_active_ub_1515
 E  segment_load_conservation_1516
 G  segment_prefix_lb_1517
 L  segment_prefix_ub_1518
 E  out_degree_1519
 E  in_degree_1520
 G  order_active_lb_1521
 L  order_active_ub_1522
 E  segment_load_conservation_1523
 G  segment_prefix_lb_1524
 L  segment_prefix_ub_1525
 E  out_degree_1526
 E  in_degree_1527
 G  order_active_lb_1528
 L  order_active_ub_1529
 E  segment_load_conservation_1530
 G  segment_prefix_lb_1531
 L  segment_prefix_ub_1532
 E  out_degree_1533
 E  in_degree_1534
 G  order_active_lb_1535
 L  order_active_ub_1536
 E  service_visit_def_1537
 E  free_load_conservation_1538
 E  out_degree_1539
 E  in_degree_1540
 G  order_active_lb_1541
 L  order_active_ub_1542
 E  service_visit_def_1543
 E  free_load_conservation_1544
 E  out_degree_1545
 E  in_degree_1546
 G  order_active_lb_1547
 L  order_active_ub_1548
 E  service_visit_def_1549
 E  free_load_conservation_1550
 E  out_degree_1551
 E  in_degree_1552
 G  order_active_lb_1553
 L  order_active_ub_1554
 E  service_visit_def_1555
 E  free_load_conservation_1556
 E  out_degree_1557
 E  in_degree_1558
 G  order_active_lb_1559
 L  order_active_ub_1560
 E  service_visit_def_1561
 E  free_load_conservation_1562
 E  out_degree_1563
 E  in_degree_1564
 G  order_active_lb_1565
 L  order_active_ub_1566
 E  service_visit_def_1567
 E  free_load_conservation_1568
 E  out_degree_1569
 E  in_degree_1570
 G  order_active_lb_1571
 L  order_active_ub_1572
 E  service_visit_def_1573
 E  free_load_conservation_1574
 E  out_degree_1575
 E  in_degree_1576
 G  order_active_lb_1577
 L  order_active_ub_1578
 E  service_visit_def_1579
 E  free_load_conservation_1580
 G  fixed_segment_relative_order_1581
 G  fixed_segment_relative_order_1582
 L  original_T_including_depot_unload_1583
COLUMNS
    t         normalized_mass_10_41  -1
    t         normalized_mass_7_80  -1
    t         normalized_mass_31_109  -1
    t         normalized_mass_3_148  -1
    t         normalized_mass_14_183  -1
    t         normalized_mass_11_212  -1
    t         normalized_mass_2_247  -1
    t         normalized_mass_4_282  -1
    t         normalization_343  2.3226190476190482e+01
    t         full_original_Gini_344  -9.2352380952381040e+01
    q         OBJ       1
    q         parent_nonstrict_scope_286  1
    q         full_original_Gini_344  35
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       0.075
    x_10_0    product_lb_0  -2.5219923739729182e-02
    x_10_0    product_ub_1  -4.3054843669955919e-02
    x_10_0    onehot_10_40  1
    x_10_0    parent_nonstrict_scope_286  0.15
    x_10_0    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_0  1
    w_10_0    product_ub_1  1
    w_10_0    normalized_mass_10_41  1
    w_10_0    full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       6.0000000000000012e-02
    x_10_1    product_lb_2  -2.5219923739729182e-02
    x_10_1    product_ub_3  -4.3054843669955919e-02
    x_10_1    onehot_10_40  1
    x_10_1    stock_lb_284  1
    x_10_1    stock_ub_285  1
    x_10_1    parent_nonstrict_scope_286  0.135
    x_10_1    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_2  1
    w_10_1    product_ub_3  1
    w_10_1    normalized_mass_10_41  1
    w_10_1    normalized_ratio_10_42  -0.1
    w_10_1    full_original_Gini_344  -2.0526190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_2    OBJ       0.045
    x_10_2    product_lb_4  -2.5219923739729182e-02
    x_10_2    product_ub_5  -4.3054843669955919e-02
    x_10_2    onehot_10_40  1
    x_10_2    stock_lb_284  2
    x_10_2    stock_ub_285  2
    x_10_2    parent_nonstrict_scope_286  0.12
    x_10_2    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_2    product_lb_4  1
    w_10_2    product_ub_5  1
    w_10_2    normalized_mass_10_41  1
    w_10_2    normalized_ratio_10_42  -0.2
    w_10_2    full_original_Gini_344  -1.7826190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_3    OBJ       0.03
    x_10_3    product_lb_6  -2.5219923739729182e-02
    x_10_3    product_ub_7  -4.3054843669955919e-02
    x_10_3    onehot_10_40  1
    x_10_3    stock_lb_284  3
    x_10_3    stock_ub_285  3
    x_10_3    parent_nonstrict_scope_286  0.105
    x_10_3    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_3    product_lb_6  1
    w_10_3    product_ub_7  1
    w_10_3    normalized_mass_10_41  1
    w_10_3    normalized_ratio_10_42  -3.0000000000000004e-01
    w_10_3    full_original_Gini_344  -1.5126190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_4    OBJ       0.015
    x_10_4    product_lb_8  -2.5219923739729182e-02
    x_10_4    product_ub_9  -4.3054843669955919e-02
    x_10_4    onehot_10_40  1
    x_10_4    stock_lb_284  4
    x_10_4    stock_ub_285  4
    x_10_4    parent_nonstrict_scope_286  0.09
    x_10_4    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_4    product_lb_8  1
    w_10_4    product_ub_9  1
    w_10_4    normalized_mass_10_41  1
    w_10_4    normalized_ratio_10_42  -0.4
    w_10_4    full_original_Gini_344  -1.2426190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_5    product_lb_10  -2.5219923739729182e-02
    x_10_5    product_ub_11  -4.3054843669955919e-02
    x_10_5    onehot_10_40  1
    x_10_5    stock_lb_284  5
    x_10_5    stock_ub_285  5
    x_10_5    parent_nonstrict_scope_286  0.075
    x_10_5    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_5    product_lb_10  1
    w_10_5    product_ub_11  1
    w_10_5    normalized_mass_10_41  1
    w_10_5    normalized_ratio_10_42  -0.5
    w_10_5    full_original_Gini_344  -9.9261904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_6    OBJ       -1.5000000000000013e-02
    x_10_6    product_lb_12  -2.5219923739729182e-02
    x_10_6    product_ub_13  -4.3054843669955919e-02
    x_10_6    onehot_10_40  1
    x_10_6    stock_lb_284  6
    x_10_6    stock_ub_285  6
    x_10_6    parent_nonstrict_scope_286  5.9999999999999984e-02
    x_10_6    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_6    product_lb_12  1
    w_10_6    product_ub_13  1
    w_10_6    normalized_mass_10_41  1
    w_10_6    normalized_ratio_10_42  -6.0000000000000009e-01
    w_10_6    full_original_Gini_344  -8.0261904761904770e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_7    OBJ       -3.0000000000000006e-02
    x_10_7    product_lb_14  -2.5219923739729182e-02
    x_10_7    product_ub_15  -4.3054843669955919e-02
    x_10_7    onehot_10_40  1
    x_10_7    stock_lb_284  7
    x_10_7    stock_ub_285  7
    x_10_7    parent_nonstrict_scope_286  4.4999999999999991e-02
    x_10_7    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_7    product_lb_14  1
    w_10_7    product_ub_15  1
    w_10_7    normalized_mass_10_41  1
    w_10_7    normalized_ratio_10_42  -7.0000000000000007e-01
    w_10_7    full_original_Gini_344  -6.5261904761904743e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_8    OBJ       -4.5000000000000005e-02
    x_10_8    product_lb_16  -2.5219923739729182e-02
    x_10_8    product_ub_17  -4.3054843669955919e-02
    x_10_8    onehot_10_40  1
    x_10_8    stock_lb_284  8
    x_10_8    stock_ub_285  8
    x_10_8    parent_nonstrict_scope_286  2.9999999999999992e-02
    x_10_8    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_8    product_lb_16  1
    w_10_8    product_ub_17  1
    w_10_8    normalized_mass_10_41  1
    w_10_8    normalized_ratio_10_42  -0.8
    w_10_8    full_original_Gini_344  -5.7404761904761923e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_9    OBJ       -0.06
    x_10_9    product_lb_18  -2.5219923739729182e-02
    x_10_9    product_ub_19  -4.3054843669955919e-02
    x_10_9    onehot_10_40  1
    x_10_9    stock_lb_284  9
    x_10_9    stock_ub_285  9
    x_10_9    parent_nonstrict_scope_286  1.4999999999999996e-02
    x_10_9    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_9    product_lb_18  1
    w_10_9    product_ub_19  1
    w_10_9    normalized_mass_10_41  1
    w_10_9    normalized_ratio_10_42  -0.9
    w_10_9    full_original_Gini_344  -5.3738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_10   OBJ       -0.075
    x_10_10   product_lb_20  -2.5219923739729182e-02
    x_10_10   product_ub_21  -4.3054843669955919e-02
    x_10_10   onehot_10_40  1
    x_10_10   stock_lb_284  10
    x_10_10   stock_ub_285  10
    x_10_10   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_10   product_lb_20  1
    w_10_10   product_ub_21  1
    w_10_10   normalized_mass_10_41  1
    w_10_10   normalized_ratio_10_42  -1
    w_10_10   full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_11   OBJ       -5.9999999999999984e-02
    x_10_11   product_lb_22  -2.5219923739729182e-02
    x_10_11   product_ub_23  -4.3054843669955919e-02
    x_10_11   onehot_10_40  1
    x_10_11   stock_lb_284  11
    x_10_11   stock_ub_285  11
    x_10_11   parent_nonstrict_scope_286  1.5000000000000013e-02
    x_10_11   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_11   product_lb_22  1
    w_10_11   product_ub_23  1
    w_10_11   normalized_mass_10_41  1
    w_10_11   normalized_ratio_10_42  -1.1
    w_10_11   full_original_Gini_344  -7.1738095238095259e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_12   OBJ       -4.4999999999999971e-02
    x_10_12   product_lb_24  -2.5219923739729182e-02
    x_10_12   product_ub_25  -4.3054843669955919e-02
    x_10_12   onehot_10_40  1
    x_10_12   stock_lb_284  12
    x_10_12   stock_ub_285  12
    x_10_12   parent_nonstrict_scope_286  3.0000000000000027e-02
    x_10_12   unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_12   product_lb_24  1
    w_10_12   product_ub_25  1
    w_10_12   normalized_mass_10_41  1
    w_10_12   normalized_ratio_10_42  -1.2000000000000002e+00
    w_10_12   full_original_Gini_344  -9.2738095238095291e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_13   OBJ       -2.9999999999999992e-02
    x_10_13   product_lb_26  -2.5219923739729182e-02
    x_10_13   product_ub_27  -4.3054843669955919e-02
    x_10_13   onehot_10_40  1
    x_10_13   stock_lb_284  13
    x_10_13   stock_ub_285  13
    x_10_13   parent_nonstrict_scope_286  4.5000000000000005e-02
    x_10_13   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_13   product_lb_26  1
    w_10_13   product_ub_27  1
    w_10_13   normalized_mass_10_41  1
    w_10_13   normalized_ratio_10_42  -1.3
    w_10_13   full_original_Gini_344  -1.1873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_14   OBJ       -1.4999999999999979e-02
    x_10_14   product_lb_28  -2.5219923739729182e-02
    x_10_14   product_ub_29  -4.3054843669955919e-02
    x_10_14   onehot_10_40  1
    x_10_14   stock_lb_284  14
    x_10_14   stock_ub_285  14
    x_10_14   parent_nonstrict_scope_286  6.0000000000000019e-02
    x_10_14   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_14   product_lb_28  1
    w_10_14   product_ub_29  1
    w_10_14   normalized_mass_10_41  1
    w_10_14   normalized_ratio_10_42  -1.4000000000000001e+00
    w_10_14   full_original_Gini_344  -1.4573809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_15   product_lb_30  -2.5219923739729182e-02
    x_10_15   product_ub_31  -4.3054843669955919e-02
    x_10_15   onehot_10_40  1
    x_10_15   stock_lb_284  15
    x_10_15   stock_ub_285  15
    x_10_15   parent_nonstrict_scope_286  0.075
    MARKER    'MARKER'                 'INTEND'
    w_10_15   product_lb_30  1
    w_10_15   product_ub_31  1
    w_10_15   normalized_mass_10_41  1
    w_10_15   normalized_ratio_10_42  -1.5
    w_10_15   full_original_Gini_344  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_16   OBJ       1.5000000000000013e-02
    x_10_16   product_lb_32  -2.5219923739729182e-02
    x_10_16   product_ub_33  -4.3054843669955919e-02
    x_10_16   onehot_10_40  1
    x_10_16   stock_lb_284  16
    x_10_16   stock_ub_285  16
    x_10_16   parent_nonstrict_scope_286  9.0000000000000011e-02
    x_10_16   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_16   product_lb_32  1
    w_10_16   product_ub_33  1
    w_10_16   normalized_mass_10_41  1
    w_10_16   normalized_ratio_10_42  -1.6
    w_10_16   full_original_Gini_344  -1.9973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_17   OBJ       3.0000000000000027e-02
    x_10_17   product_lb_34  -2.5219923739729182e-02
    x_10_17   product_ub_35  -4.3054843669955919e-02
    x_10_17   onehot_10_40  1
    x_10_17   stock_lb_284  17
    x_10_17   stock_ub_285  17
    x_10_17   parent_nonstrict_scope_286  1.0500000000000002e-01
    x_10_17   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_17   product_lb_34  1
    w_10_17   product_ub_35  1
    w_10_17   normalized_mass_10_41  1
    w_10_17   normalized_ratio_10_42  -1.7000000000000002e+00
    w_10_17   full_original_Gini_344  -2.2673809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_18   OBJ       0.045
    x_10_18   product_lb_36  -2.5219923739729182e-02
    x_10_18   product_ub_37  -4.3054843669955919e-02
    x_10_18   onehot_10_40  1
    x_10_18   stock_lb_284  18
    x_10_18   stock_ub_285  18
    x_10_18   parent_nonstrict_scope_286  0.12
    x_10_18   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_18   product_lb_36  1
    w_10_18   product_ub_37  1
    w_10_18   normalized_mass_10_41  1
    w_10_18   normalized_ratio_10_42  -1.8
    w_10_18   full_original_Gini_344  -2.5373809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_10_19   OBJ       6.0000000000000012e-02
    x_10_19   product_lb_38  -2.5219923739729182e-02
    x_10_19   product_ub_39  -4.3054843669955919e-02
    x_10_19   onehot_10_40  1
    x_10_19   stock_lb_284  19
    x_10_19   stock_ub_285  19
    x_10_19   parent_nonstrict_scope_286  0.135
    x_10_19   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_19   product_lb_38  1
    w_10_19   product_ub_39  1
    w_10_19   normalized_mass_10_41  1
    w_10_19   normalized_ratio_10_42  -1.9000000000000001e+00
    w_10_19   full_original_Gini_344  -2.8073809523809519e+01
    rho_10    normalized_ratio_10_42  1
    rho_10    block_pair_pos_309  -1
    rho_10    block_pair_neg_310  1
    rho_10    block_pair_pos_311  -1
    rho_10    block_pair_neg_312  1
    rho_10    block_pair_pos_313  -1
    rho_10    block_pair_neg_314  1
    rho_10    block_pair_pos_315  -1
    rho_10    block_pair_neg_316  1
    rho_10    block_pair_pos_317  -1
    rho_10    block_pair_neg_318  1
    rho_10    block_pair_pos_319  -1
    rho_10    block_pair_neg_320  1
    rho_10    block_pair_pos_321  -1
    rho_10    block_pair_neg_322  1
    rho_10    normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_43  -2.5219923739729182e-02
    x_7_0     product_ub_44  -4.3054843669955919e-02
    x_7_0     onehot_7_79  1
    x_7_0     parent_nonstrict_scope_286  0.096
    x_7_0     unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_43  1
    w_7_0     product_ub_44  1
    w_7_0     normalized_mass_7_80  1
    w_7_0     full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_45  -2.5219923739729182e-02
    x_7_1     product_ub_46  -4.3054843669955919e-02
    x_7_1     onehot_7_79  1
    x_7_1     stock_lb_284  1
    x_7_1     stock_ub_285  1
    x_7_1     parent_nonstrict_scope_286  0.084
    x_7_1     unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_45  1
    w_7_1     product_ub_46  1
    w_7_1     normalized_mass_7_80  1
    w_7_1     normalized_ratio_7_81  -0.125
    w_7_1     full_original_Gini_344  -1.9851190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_47  -2.5219923739729182e-02
    x_7_2     product_ub_48  -4.3054843669955919e-02
    x_7_2     onehot_7_79  1
    x_7_2     stock_lb_284  2
    x_7_2     stock_ub_285  2
    x_7_2     parent_nonstrict_scope_286  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_47  1
    w_7_2     product_ub_48  1
    w_7_2     normalized_mass_7_80  1
    w_7_2     normalized_ratio_7_81  -0.25
    w_7_2     full_original_Gini_344  -1.6476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_49  -2.5219923739729182e-02
    x_7_3     product_ub_50  -4.3054843669955919e-02
    x_7_3     onehot_7_79  1
    x_7_3     stock_lb_284  3
    x_7_3     stock_ub_285  3
    x_7_3     parent_nonstrict_scope_286  0.06
    x_7_3     unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_49  1
    w_7_3     product_ub_50  1
    w_7_3     normalized_mass_7_80  1
    w_7_3     normalized_ratio_7_81  -0.375
    w_7_3     full_original_Gini_344  -1.3101190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_51  -2.5219923739729182e-02
    x_7_4     product_ub_52  -4.3054843669955919e-02
    x_7_4     onehot_7_79  1
    x_7_4     stock_lb_284  4
    x_7_4     stock_ub_285  4
    x_7_4     parent_nonstrict_scope_286  0.048
    x_7_4     unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_51  1
    w_7_4     product_ub_52  1
    w_7_4     normalized_mass_7_80  1
    w_7_4     normalized_ratio_7_81  -0.5
    w_7_4     full_original_Gini_344  -9.9261904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_53  -2.5219923739729182e-02
    x_7_5     product_ub_54  -4.3054843669955919e-02
    x_7_5     onehot_7_79  1
    x_7_5     stock_lb_284  5
    x_7_5     stock_ub_285  5
    x_7_5     parent_nonstrict_scope_286  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_53  1
    w_7_5     product_ub_54  1
    w_7_5     normalized_mass_7_80  1
    w_7_5     normalized_ratio_7_81  -0.625
    w_7_5     full_original_Gini_344  -7.6511904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_55  -2.5219923739729182e-02
    x_7_6     product_ub_56  -4.3054843669955919e-02
    x_7_6     onehot_7_79  1
    x_7_6     stock_lb_284  6
    x_7_6     stock_ub_285  6
    x_7_6     parent_nonstrict_scope_286  0.024
    x_7_6     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_55  1
    w_7_6     product_ub_56  1
    w_7_6     normalized_mass_7_80  1
    w_7_6     normalized_ratio_7_81  -0.75
    w_7_6     full_original_Gini_344  -5.9904761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_57  -2.5219923739729182e-02
    x_7_7     product_ub_58  -4.3054843669955919e-02
    x_7_7     onehot_7_79  1
    x_7_7     stock_lb_284  7
    x_7_7     stock_ub_285  7
    x_7_7     parent_nonstrict_scope_286  0.012
    x_7_7     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_57  1
    w_7_7     product_ub_58  1
    w_7_7     normalized_mass_7_80  1
    w_7_7     normalized_ratio_7_81  -0.875
    w_7_7     full_original_Gini_344  -5.4488095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_59  -2.5219923739729182e-02
    x_7_8     product_ub_60  -4.3054843669955919e-02
    x_7_8     onehot_7_79  1
    x_7_8     stock_lb_284  8
    x_7_8     stock_ub_285  8
    x_7_8     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_59  1
    w_7_8     product_ub_60  1
    w_7_8     normalized_mass_7_80  1
    w_7_8     normalized_ratio_7_81  -1
    w_7_8     full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_61  -2.5219923739729182e-02
    x_7_9     product_ub_62  -4.3054843669955919e-02
    x_7_9     onehot_7_79  1
    x_7_9     stock_lb_284  9
    x_7_9     stock_ub_285  9
    x_7_9     parent_nonstrict_scope_286  0.012
    x_7_9     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_61  1
    w_7_9     product_ub_62  1
    w_7_9     normalized_mass_7_80  1
    w_7_9     normalized_ratio_7_81  -1.125
    w_7_9     full_original_Gini_344  -7.6988095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_63  -2.5219923739729182e-02
    x_7_10    product_ub_64  -4.3054843669955919e-02
    x_7_10    onehot_7_79  1
    x_7_10    stock_lb_284  10
    x_7_10    stock_ub_285  10
    x_7_10    parent_nonstrict_scope_286  0.024
    x_7_10    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_63  1
    w_7_10    product_ub_64  1
    w_7_10    normalized_mass_7_80  1
    w_7_10    normalized_ratio_7_81  -1.25
    w_7_10    full_original_Gini_344  -1.0523809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_65  -2.5219923739729182e-02
    x_7_11    product_ub_66  -4.3054843669955919e-02
    x_7_11    onehot_7_79  1
    x_7_11    stock_lb_284  11
    x_7_11    stock_ub_285  11
    x_7_11    parent_nonstrict_scope_286  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_65  1
    w_7_11    product_ub_66  1
    w_7_11    normalized_mass_7_80  1
    w_7_11    normalized_ratio_7_81  -1.375
    w_7_11    full_original_Gini_344  -1.3898809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_67  -2.5219923739729182e-02
    x_7_12    product_ub_68  -4.3054843669955919e-02
    x_7_12    onehot_7_79  1
    x_7_12    stock_lb_284  12
    x_7_12    stock_ub_285  12
    x_7_12    parent_nonstrict_scope_286  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_67  1
    w_7_12    product_ub_68  1
    w_7_12    normalized_mass_7_80  1
    w_7_12    normalized_ratio_7_81  -1.5
    w_7_12    full_original_Gini_344  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_69  -2.5219923739729182e-02
    x_7_13    product_ub_70  -4.3054843669955919e-02
    x_7_13    onehot_7_79  1
    x_7_13    stock_lb_284  13
    x_7_13    stock_ub_285  13
    x_7_13    parent_nonstrict_scope_286  0.06
    x_7_13    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_69  1
    w_7_13    product_ub_70  1
    w_7_13    normalized_mass_7_80  1
    w_7_13    normalized_ratio_7_81  -1.625
    w_7_13    full_original_Gini_344  -2.0648809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_71  -2.5219923739729182e-02
    x_7_14    product_ub_72  -4.3054843669955919e-02
    x_7_14    onehot_7_79  1
    x_7_14    stock_lb_284  14
    x_7_14    stock_ub_285  14
    x_7_14    parent_nonstrict_scope_286  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_71  1
    w_7_14    product_ub_72  1
    w_7_14    normalized_mass_7_80  1
    w_7_14    normalized_ratio_7_81  -1.75
    w_7_14    full_original_Gini_344  -2.4023809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_73  -2.5219923739729182e-02
    x_7_15    product_ub_74  -4.3054843669955919e-02
    x_7_15    onehot_7_79  1
    x_7_15    stock_lb_284  15
    x_7_15    stock_ub_285  15
    x_7_15    parent_nonstrict_scope_286  0.084
    x_7_15    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_73  1
    w_7_15    product_ub_74  1
    w_7_15    normalized_mass_7_80  1
    w_7_15    normalized_ratio_7_81  -1.875
    w_7_15    full_original_Gini_344  -2.7398809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_75  -2.5219923739729182e-02
    x_7_16    product_ub_76  -4.3054843669955919e-02
    x_7_16    onehot_7_79  1
    x_7_16    stock_lb_284  16
    x_7_16    stock_ub_285  16
    x_7_16    parent_nonstrict_scope_286  0.096
    x_7_16    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_75  1
    w_7_16    product_ub_76  1
    w_7_16    normalized_mass_7_80  1
    w_7_16    normalized_ratio_7_81  -2
    w_7_16    full_original_Gini_344  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_77  -2.5219923739729182e-02
    x_7_17    product_ub_78  -4.3054843669955919e-02
    x_7_17    onehot_7_79  1
    x_7_17    stock_lb_284  17
    x_7_17    stock_ub_285  17
    x_7_17    parent_nonstrict_scope_286  0.108
    x_7_17    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_77  1
    w_7_17    product_ub_78  1
    w_7_17    normalized_mass_7_80  1
    w_7_17    normalized_ratio_7_81  -2.125
    w_7_17    full_original_Gini_344  -3.4148809523809526e+01
    rho_7     normalized_ratio_7_81  1
    rho_7     block_pair_pos_297  -1
    rho_7     block_pair_neg_298  1
    rho_7     block_pair_pos_299  -1
    rho_7     block_pair_neg_300  1
    rho_7     block_pair_pos_301  -1
    rho_7     block_pair_neg_302  1
    rho_7     block_pair_pos_303  -1
    rho_7     block_pair_neg_304  1
    rho_7     block_pair_pos_305  -1
    rho_7     block_pair_neg_306  1
    rho_7     block_pair_pos_307  -1
    rho_7     block_pair_neg_308  1
    rho_7     block_pair_pos_315  1
    rho_7     block_pair_neg_316  -1
    rho_7     normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_82  -2.5219923739729182e-02
    x_31_0    product_ub_83  -4.3054843669955919e-02
    x_31_0    onehot_31_108  1
    x_31_0    parent_nonstrict_scope_286  0.0735
    x_31_0    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_82  1
    w_31_0    product_ub_83  1
    w_31_0    normalized_mass_31_109  1
    w_31_0    full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_84  -2.5219923739729182e-02
    x_31_1    product_ub_85  -4.3054843669955919e-02
    x_31_1    onehot_31_108  1
    x_31_1    stock_lb_284  1
    x_31_1    stock_ub_285  1
    x_31_1    parent_nonstrict_scope_286  0.063
    x_31_1    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_84  1
    w_31_1    product_ub_85  1
    w_31_1    normalized_mass_31_109  1
    w_31_1    normalized_ratio_31_110  -1.4285714285714285e-01
    w_31_1    full_original_Gini_344  -1.9369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_86  -2.5219923739729182e-02
    x_31_2    product_ub_87  -4.3054843669955919e-02
    x_31_2    onehot_31_108  1
    x_31_2    stock_lb_284  2
    x_31_2    stock_ub_285  2
    x_31_2    parent_nonstrict_scope_286  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_86  1
    w_31_2    product_ub_87  1
    w_31_2    normalized_mass_31_109  1
    w_31_2    normalized_ratio_31_110  -2.8571428571428570e-01
    w_31_2    full_original_Gini_344  -1.5511904761904757e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_88  -2.5219923739729182e-02
    x_31_3    product_ub_89  -4.3054843669955919e-02
    x_31_3    onehot_31_108  1
    x_31_3    stock_lb_284  3
    x_31_3    stock_ub_285  3
    x_31_3    parent_nonstrict_scope_286  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_88  1
    w_31_3    product_ub_89  1
    w_31_3    normalized_mass_31_109  1
    w_31_3    normalized_ratio_31_110  -4.2857142857142855e-01
    w_31_3    full_original_Gini_344  -1.1711904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_90  -2.5219923739729182e-02
    x_31_4    product_ub_91  -4.3054843669955919e-02
    x_31_4    onehot_31_108  1
    x_31_4    stock_lb_284  4
    x_31_4    stock_ub_285  4
    x_31_4    parent_nonstrict_scope_286  0.0315
    x_31_4    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_90  1
    w_31_4    product_ub_91  1
    w_31_4    normalized_mass_31_109  1
    w_31_4    normalized_ratio_31_110  -5.7142857142857140e-01
    w_31_4    full_original_Gini_344  -8.5690476190476215e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_92  -2.5219923739729182e-02
    x_31_5    product_ub_93  -4.3054843669955919e-02
    x_31_5    onehot_31_108  1
    x_31_5    stock_lb_284  5
    x_31_5    stock_ub_285  5
    x_31_5    parent_nonstrict_scope_286  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_92  1
    w_31_5    product_ub_93  1
    w_31_5    normalized_mass_31_109  1
    w_31_5    normalized_ratio_31_110  -7.1428571428571419e-01
    w_31_5    full_original_Gini_344  -6.3119047619047617e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_94  -2.5219923739729182e-02
    x_31_6    product_ub_95  -4.3054843669955919e-02
    x_31_6    onehot_31_108  1
    x_31_6    stock_lb_284  6
    x_31_6    stock_ub_285  6
    x_31_6    parent_nonstrict_scope_286  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_94  1
    w_31_6    product_ub_95  1
    w_31_6    normalized_mass_31_109  1
    w_31_6    normalized_ratio_31_110  -8.5714285714285710e-01
    w_31_6    full_original_Gini_344  -5.5023809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_96  -2.5219923739729182e-02
    x_31_7    product_ub_97  -4.3054843669955919e-02
    x_31_7    onehot_31_108  1
    x_31_7    stock_lb_284  7
    x_31_7    stock_ub_285  7
    x_31_7    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_96  1
    w_31_7    product_ub_97  1
    w_31_7    normalized_mass_31_109  1
    w_31_7    normalized_ratio_31_110  -1
    w_31_7    full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_98  -2.5219923739729182e-02
    x_31_8    product_ub_99  -4.3054843669955919e-02
    x_31_8    onehot_31_108  1
    x_31_8    stock_lb_284  8
    x_31_8    stock_ub_285  8
    x_31_8    parent_nonstrict_scope_286  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_98  1
    w_31_8    product_ub_99  1
    w_31_8    normalized_mass_31_109  1
    w_31_8    normalized_ratio_31_110  -1.1428571428571428e+00
    w_31_8    full_original_Gini_344  -8.0738095238095227e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_100  -2.5219923739729182e-02
    x_31_9    product_ub_101  -4.3054843669955919e-02
    x_31_9    onehot_31_108  1
    x_31_9    stock_lb_284  9
    x_31_9    stock_ub_285  9
    x_31_9    parent_nonstrict_scope_286  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_100  1
    w_31_9    product_ub_101  1
    w_31_9    normalized_mass_31_109  1
    w_31_9    normalized_ratio_31_110  -1.2857142857142856e+00
    w_31_9    full_original_Gini_344  -1.1488095238095230e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_102  -2.5219923739729182e-02
    x_31_10   product_ub_103  -4.3054843669955919e-02
    x_31_10   onehot_31_108  1
    x_31_10   stock_lb_284  10
    x_31_10   stock_ub_285  10
    x_31_10   parent_nonstrict_scope_286  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_102  1
    w_31_10   product_ub_103  1
    w_31_10   normalized_mass_31_109  1
    w_31_10   normalized_ratio_31_110  -1.4285714285714284e+00
    w_31_10   full_original_Gini_344  -1.5345238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_104  -2.5219923739729182e-02
    x_31_11   product_ub_105  -4.3054843669955919e-02
    x_31_11   onehot_31_108  1
    x_31_11   stock_lb_284  11
    x_31_11   stock_ub_285  11
    x_31_11   parent_nonstrict_scope_286  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_104  1
    w_31_11   product_ub_105  1
    w_31_11   normalized_mass_31_109  1
    w_31_11   normalized_ratio_31_110  -1.5714285714285714e+00
    w_31_11   full_original_Gini_344  -1.9202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_106  -2.5219923739729182e-02
    x_31_12   product_ub_107  -4.3054843669955919e-02
    x_31_12   onehot_31_108  1
    x_31_12   stock_lb_284  12
    x_31_12   stock_ub_285  12
    x_31_12   parent_nonstrict_scope_286  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_106  1
    w_31_12   product_ub_107  1
    w_31_12   normalized_mass_31_109  1
    w_31_12   normalized_ratio_31_110  -1.7142857142857142e+00
    w_31_12   full_original_Gini_344  -2.3059523809523810e+01
    rho_31    normalized_ratio_31_110  1
    rho_31    block_pair_pos_307  1
    rho_31    block_pair_neg_308  -1
    rho_31    block_pair_pos_321  1
    rho_31    block_pair_neg_322  -1
    rho_31    block_pair_pos_333  -1
    rho_31    block_pair_neg_334  1
    rho_31    block_pair_pos_335  -1
    rho_31    block_pair_neg_336  1
    rho_31    block_pair_pos_337  -1
    rho_31    block_pair_neg_338  1
    rho_31    block_pair_pos_339  -1
    rho_31    block_pair_neg_340  1
    rho_31    block_pair_pos_341  -1
    rho_31    block_pair_neg_342  1
    rho_31    normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_111  -2.5219923739729182e-02
    x_3_0     product_ub_112  -4.3054843669955919e-02
    x_3_0     onehot_3_147  1
    x_3_0     parent_nonstrict_scope_286  0.096
    x_3_0     unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_111  1
    w_3_0     product_ub_112  1
    w_3_0     normalized_mass_3_148  1
    w_3_0     full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_113  -2.5219923739729182e-02
    x_3_1     product_ub_114  -4.3054843669955919e-02
    x_3_1     onehot_3_147  1
    x_3_1     stock_lb_284  1
    x_3_1     stock_ub_285  1
    x_3_1     parent_nonstrict_scope_286  0.084
    x_3_1     unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_113  1
    w_3_1     product_ub_114  1
    w_3_1     normalized_mass_3_148  1
    w_3_1     normalized_ratio_3_149  -0.125
    w_3_1     full_original_Gini_344  -1.9851190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_115  -2.5219923739729182e-02
    x_3_2     product_ub_116  -4.3054843669955919e-02
    x_3_2     onehot_3_147  1
    x_3_2     stock_lb_284  2
    x_3_2     stock_ub_285  2
    x_3_2     parent_nonstrict_scope_286  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_115  1
    w_3_2     product_ub_116  1
    w_3_2     normalized_mass_3_148  1
    w_3_2     normalized_ratio_3_149  -0.25
    w_3_2     full_original_Gini_344  -1.6476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_117  -2.5219923739729182e-02
    x_3_3     product_ub_118  -4.3054843669955919e-02
    x_3_3     onehot_3_147  1
    x_3_3     stock_lb_284  3
    x_3_3     stock_ub_285  3
    x_3_3     parent_nonstrict_scope_286  0.06
    x_3_3     unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_117  1
    w_3_3     product_ub_118  1
    w_3_3     normalized_mass_3_148  1
    w_3_3     normalized_ratio_3_149  -0.375
    w_3_3     full_original_Gini_344  -1.3101190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_119  -2.5219923739729182e-02
    x_3_4     product_ub_120  -4.3054843669955919e-02
    x_3_4     onehot_3_147  1
    x_3_4     stock_lb_284  4
    x_3_4     stock_ub_285  4
    x_3_4     parent_nonstrict_scope_286  0.048
    x_3_4     unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_119  1
    w_3_4     product_ub_120  1
    w_3_4     normalized_mass_3_148  1
    w_3_4     normalized_ratio_3_149  -0.5
    w_3_4     full_original_Gini_344  -9.9261904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_121  -2.5219923739729182e-02
    x_3_5     product_ub_122  -4.3054843669955919e-02
    x_3_5     onehot_3_147  1
    x_3_5     stock_lb_284  5
    x_3_5     stock_ub_285  5
    x_3_5     parent_nonstrict_scope_286  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_121  1
    w_3_5     product_ub_122  1
    w_3_5     normalized_mass_3_148  1
    w_3_5     normalized_ratio_3_149  -0.625
    w_3_5     full_original_Gini_344  -7.6511904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_123  -2.5219923739729182e-02
    x_3_6     product_ub_124  -4.3054843669955919e-02
    x_3_6     onehot_3_147  1
    x_3_6     stock_lb_284  6
    x_3_6     stock_ub_285  6
    x_3_6     parent_nonstrict_scope_286  0.024
    x_3_6     unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_123  1
    w_3_6     product_ub_124  1
    w_3_6     normalized_mass_3_148  1
    w_3_6     normalized_ratio_3_149  -0.75
    w_3_6     full_original_Gini_344  -5.9904761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_125  -2.5219923739729182e-02
    x_3_7     product_ub_126  -4.3054843669955919e-02
    x_3_7     onehot_3_147  1
    x_3_7     stock_lb_284  7
    x_3_7     stock_ub_285  7
    x_3_7     parent_nonstrict_scope_286  0.012
    x_3_7     unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_125  1
    w_3_7     product_ub_126  1
    w_3_7     normalized_mass_3_148  1
    w_3_7     normalized_ratio_3_149  -0.875
    w_3_7     full_original_Gini_344  -5.4488095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_127  -2.5219923739729182e-02
    x_3_8     product_ub_128  -4.3054843669955919e-02
    x_3_8     onehot_3_147  1
    x_3_8     stock_lb_284  8
    x_3_8     stock_ub_285  8
    x_3_8     unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_127  1
    w_3_8     product_ub_128  1
    w_3_8     normalized_mass_3_148  1
    w_3_8     normalized_ratio_3_149  -1
    w_3_8     full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_129  -2.5219923739729182e-02
    x_3_9     product_ub_130  -4.3054843669955919e-02
    x_3_9     onehot_3_147  1
    x_3_9     stock_lb_284  9
    x_3_9     stock_ub_285  9
    x_3_9     parent_nonstrict_scope_286  0.012
    x_3_9     unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_129  1
    w_3_9     product_ub_130  1
    w_3_9     normalized_mass_3_148  1
    w_3_9     normalized_ratio_3_149  -1.125
    w_3_9     full_original_Gini_344  -7.6988095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_131  -2.5219923739729182e-02
    x_3_10    product_ub_132  -4.3054843669955919e-02
    x_3_10    onehot_3_147  1
    x_3_10    stock_lb_284  10
    x_3_10    stock_ub_285  10
    x_3_10    parent_nonstrict_scope_286  0.024
    x_3_10    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_131  1
    w_3_10    product_ub_132  1
    w_3_10    normalized_mass_3_148  1
    w_3_10    normalized_ratio_3_149  -1.25
    w_3_10    full_original_Gini_344  -1.0523809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_133  -2.5219923739729182e-02
    x_3_11    product_ub_134  -4.3054843669955919e-02
    x_3_11    onehot_3_147  1
    x_3_11    stock_lb_284  11
    x_3_11    stock_ub_285  11
    x_3_11    parent_nonstrict_scope_286  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_133  1
    w_3_11    product_ub_134  1
    w_3_11    normalized_mass_3_148  1
    w_3_11    normalized_ratio_3_149  -1.375
    w_3_11    full_original_Gini_344  -1.3898809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_135  -2.5219923739729182e-02
    x_3_12    product_ub_136  -4.3054843669955919e-02
    x_3_12    onehot_3_147  1
    x_3_12    stock_lb_284  12
    x_3_12    stock_ub_285  12
    x_3_12    parent_nonstrict_scope_286  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_135  1
    w_3_12    product_ub_136  1
    w_3_12    normalized_mass_3_148  1
    w_3_12    normalized_ratio_3_149  -1.5
    w_3_12    full_original_Gini_344  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_137  -2.5219923739729182e-02
    x_3_13    product_ub_138  -4.3054843669955919e-02
    x_3_13    onehot_3_147  1
    x_3_13    stock_lb_284  13
    x_3_13    stock_ub_285  13
    x_3_13    parent_nonstrict_scope_286  0.06
    x_3_13    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_137  1
    w_3_13    product_ub_138  1
    w_3_13    normalized_mass_3_148  1
    w_3_13    normalized_ratio_3_149  -1.625
    w_3_13    full_original_Gini_344  -2.0648809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_139  -2.5219923739729182e-02
    x_3_14    product_ub_140  -4.3054843669955919e-02
    x_3_14    onehot_3_147  1
    x_3_14    stock_lb_284  14
    x_3_14    stock_ub_285  14
    x_3_14    parent_nonstrict_scope_286  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_139  1
    w_3_14    product_ub_140  1
    w_3_14    normalized_mass_3_148  1
    w_3_14    normalized_ratio_3_149  -1.75
    w_3_14    full_original_Gini_344  -2.4023809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_141  -2.5219923739729182e-02
    x_3_15    product_ub_142  -4.3054843669955919e-02
    x_3_15    onehot_3_147  1
    x_3_15    stock_lb_284  15
    x_3_15    stock_ub_285  15
    x_3_15    parent_nonstrict_scope_286  0.084
    x_3_15    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_141  1
    w_3_15    product_ub_142  1
    w_3_15    normalized_mass_3_148  1
    w_3_15    normalized_ratio_3_149  -1.875
    w_3_15    full_original_Gini_344  -2.7398809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_143  -2.5219923739729182e-02
    x_3_16    product_ub_144  -4.3054843669955919e-02
    x_3_16    onehot_3_147  1
    x_3_16    stock_lb_284  16
    x_3_16    stock_ub_285  16
    x_3_16    parent_nonstrict_scope_286  0.096
    x_3_16    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_143  1
    w_3_16    product_ub_144  1
    w_3_16    normalized_mass_3_148  1
    w_3_16    normalized_ratio_3_149  -2
    w_3_16    full_original_Gini_344  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_145  -2.5219923739729182e-02
    x_3_17    product_ub_146  -4.3054843669955919e-02
    x_3_17    onehot_3_147  1
    x_3_17    stock_lb_284  17
    x_3_17    stock_ub_285  17
    x_3_17    parent_nonstrict_scope_286  0.108
    x_3_17    unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_145  1
    w_3_17    product_ub_146  1
    w_3_17    normalized_mass_3_148  1
    w_3_17    normalized_ratio_3_149  -2.125
    w_3_17    full_original_Gini_344  -3.4148809523809526e+01
    rho_3     normalized_ratio_3_149  1
    rho_3     block_pair_pos_289  -1
    rho_3     block_pair_neg_290  1
    rho_3     block_pair_pos_291  -1
    rho_3     block_pair_neg_292  1
    rho_3     block_pair_pos_293  -1
    rho_3     block_pair_neg_294  1
    rho_3     block_pair_pos_295  -1
    rho_3     block_pair_neg_296  1
    rho_3     block_pair_pos_299  1
    rho_3     block_pair_neg_300  -1
    rho_3     block_pair_pos_311  1
    rho_3     block_pair_neg_312  -1
    rho_3     block_pair_pos_335  1
    rho_3     block_pair_neg_336  -1
    rho_3     normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       0.048
    x_14_0    product_lb_150  -2.5219923739729182e-02
    x_14_0    product_ub_151  -4.3054843669955919e-02
    x_14_0    onehot_14_182  1
    x_14_0    parent_nonstrict_scope_286  0.096
    x_14_0    unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_150  1
    w_14_0    product_ub_151  1
    w_14_0    normalized_mass_14_183  1
    w_14_0    full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       3.6000000000000004e-02
    x_14_1    product_lb_152  -2.5219923739729182e-02
    x_14_1    product_ub_153  -4.3054843669955919e-02
    x_14_1    onehot_14_182  1
    x_14_1    stock_lb_284  1
    x_14_1    stock_ub_285  1
    x_14_1    parent_nonstrict_scope_286  0.084
    x_14_1    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_152  1
    w_14_1    product_ub_153  1
    w_14_1    normalized_mass_14_183  1
    w_14_1    normalized_ratio_14_184  -0.125
    w_14_1    full_original_Gini_344  -1.9851190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       2.4000000000000007e-02
    x_14_2    product_lb_154  -2.5219923739729182e-02
    x_14_2    product_ub_155  -4.3054843669955919e-02
    x_14_2    onehot_14_182  1
    x_14_2    stock_lb_284  2
    x_14_2    stock_ub_285  2
    x_14_2    parent_nonstrict_scope_286  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_154  1
    w_14_2    product_ub_155  1
    w_14_2    normalized_mass_14_183  1
    w_14_2    normalized_ratio_14_184  -0.25
    w_14_2    full_original_Gini_344  -1.6476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_3    OBJ       1.1999999999999997e-02
    x_14_3    product_lb_156  -2.5219923739729182e-02
    x_14_3    product_ub_157  -4.3054843669955919e-02
    x_14_3    onehot_14_182  1
    x_14_3    stock_lb_284  3
    x_14_3    stock_ub_285  3
    x_14_3    parent_nonstrict_scope_286  0.06
    x_14_3    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_156  1
    w_14_3    product_ub_157  1
    w_14_3    normalized_mass_14_183  1
    w_14_3    normalized_ratio_14_184  -0.375
    w_14_3    full_original_Gini_344  -1.3101190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_4    product_lb_158  -2.5219923739729182e-02
    x_14_4    product_ub_159  -4.3054843669955919e-02
    x_14_4    onehot_14_182  1
    x_14_4    stock_lb_284  4
    x_14_4    stock_ub_285  4
    x_14_4    parent_nonstrict_scope_286  0.048
    x_14_4    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_158  1
    w_14_4    product_ub_159  1
    w_14_4    normalized_mass_14_183  1
    w_14_4    normalized_ratio_14_184  -0.5
    w_14_4    full_original_Gini_344  -9.9261904761904756e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -1.1999999999999997e-02
    x_14_5    product_lb_160  -2.5219923739729182e-02
    x_14_5    product_ub_161  -4.3054843669955919e-02
    x_14_5    onehot_14_182  1
    x_14_5    stock_lb_284  5
    x_14_5    stock_ub_285  5
    x_14_5    parent_nonstrict_scope_286  3.6000000000000004e-02
    x_14_5    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_160  1
    w_14_5    product_ub_161  1
    w_14_5    normalized_mass_14_183  1
    w_14_5    normalized_ratio_14_184  -0.625
    w_14_5    full_original_Gini_344  -7.6511904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -0.024
    x_14_6    product_lb_162  -2.5219923739729182e-02
    x_14_6    product_ub_163  -4.3054843669955919e-02
    x_14_6    onehot_14_182  1
    x_14_6    stock_lb_284  6
    x_14_6    stock_ub_285  6
    x_14_6    parent_nonstrict_scope_286  0.024
    x_14_6    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_162  1
    w_14_6    product_ub_163  1
    w_14_6    normalized_mass_14_183  1
    w_14_6    normalized_ratio_14_184  -0.75
    w_14_6    full_original_Gini_344  -5.9904761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -3.6000000000000004e-02
    x_14_7    product_lb_164  -2.5219923739729182e-02
    x_14_7    product_ub_165  -4.3054843669955919e-02
    x_14_7    onehot_14_182  1
    x_14_7    stock_lb_284  7
    x_14_7    stock_ub_285  7
    x_14_7    parent_nonstrict_scope_286  0.012
    x_14_7    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_164  1
    w_14_7    product_ub_165  1
    w_14_7    normalized_mass_14_183  1
    w_14_7    normalized_ratio_14_184  -0.875
    w_14_7    full_original_Gini_344  -5.4488095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -0.048
    x_14_8    product_lb_166  -2.5219923739729182e-02
    x_14_8    product_ub_167  -4.3054843669955919e-02
    x_14_8    onehot_14_182  1
    x_14_8    stock_lb_284  8
    x_14_8    stock_ub_285  8
    x_14_8    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_166  1
    w_14_8    product_ub_167  1
    w_14_8    normalized_mass_14_183  1
    w_14_8    normalized_ratio_14_184  -1
    w_14_8    full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -3.6000000000000004e-02
    x_14_9    product_lb_168  -2.5219923739729182e-02
    x_14_9    product_ub_169  -4.3054843669955919e-02
    x_14_9    onehot_14_182  1
    x_14_9    stock_lb_284  9
    x_14_9    stock_ub_285  9
    x_14_9    parent_nonstrict_scope_286  0.012
    x_14_9    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_168  1
    w_14_9    product_ub_169  1
    w_14_9    normalized_mass_14_183  1
    w_14_9    normalized_ratio_14_184  -1.125
    w_14_9    full_original_Gini_344  -7.6988095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -0.024
    x_14_10   product_lb_170  -2.5219923739729182e-02
    x_14_10   product_ub_171  -4.3054843669955919e-02
    x_14_10   onehot_14_182  1
    x_14_10   stock_lb_284  10
    x_14_10   stock_ub_285  10
    x_14_10   parent_nonstrict_scope_286  0.024
    x_14_10   unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_170  1
    w_14_10   product_ub_171  1
    w_14_10   normalized_mass_14_183  1
    w_14_10   normalized_ratio_14_184  -1.25
    w_14_10   full_original_Gini_344  -1.0523809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_11   OBJ       -1.1999999999999997e-02
    x_14_11   product_lb_172  -2.5219923739729182e-02
    x_14_11   product_ub_173  -4.3054843669955919e-02
    x_14_11   onehot_14_182  1
    x_14_11   stock_lb_284  11
    x_14_11   stock_ub_285  11
    x_14_11   parent_nonstrict_scope_286  3.6000000000000004e-02
    x_14_11   unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_172  1
    w_14_11   product_ub_173  1
    w_14_11   normalized_mass_14_183  1
    w_14_11   normalized_ratio_14_184  -1.375
    w_14_11   full_original_Gini_344  -1.3898809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   product_lb_174  -2.5219923739729182e-02
    x_14_12   product_ub_175  -4.3054843669955919e-02
    x_14_12   onehot_14_182  1
    x_14_12   stock_lb_284  12
    x_14_12   stock_ub_285  12
    x_14_12   parent_nonstrict_scope_286  0.048
    x_14_12   unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_174  1
    w_14_12   product_ub_175  1
    w_14_12   normalized_mass_14_183  1
    w_14_12   normalized_ratio_14_184  -1.5
    w_14_12   full_original_Gini_344  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       1.1999999999999997e-02
    x_14_13   product_lb_176  -2.5219923739729182e-02
    x_14_13   product_ub_177  -4.3054843669955919e-02
    x_14_13   onehot_14_182  1
    x_14_13   stock_lb_284  13
    x_14_13   stock_ub_285  13
    x_14_13   parent_nonstrict_scope_286  0.06
    x_14_13   unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_176  1
    w_14_13   product_ub_177  1
    w_14_13   normalized_mass_14_183  1
    w_14_13   normalized_ratio_14_184  -1.625
    w_14_13   full_original_Gini_344  -2.0648809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       2.4000000000000007e-02
    x_14_14   product_lb_178  -2.5219923739729182e-02
    x_14_14   product_ub_179  -4.3054843669955919e-02
    x_14_14   onehot_14_182  1
    x_14_14   stock_lb_284  14
    x_14_14   stock_ub_285  14
    x_14_14   parent_nonstrict_scope_286  7.2000000000000008e-02
    x_14_14   unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_178  1
    w_14_14   product_ub_179  1
    w_14_14   normalized_mass_14_183  1
    w_14_14   normalized_ratio_14_184  -1.75
    w_14_14   full_original_Gini_344  -2.4023809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       3.6000000000000004e-02
    x_14_15   product_lb_180  -2.5219923739729182e-02
    x_14_15   product_ub_181  -4.3054843669955919e-02
    x_14_15   onehot_14_182  1
    x_14_15   stock_lb_284  15
    x_14_15   stock_ub_285  15
    x_14_15   parent_nonstrict_scope_286  0.084
    x_14_15   unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_180  1
    w_14_15   product_ub_181  1
    w_14_15   normalized_mass_14_183  1
    w_14_15   normalized_ratio_14_184  -1.875
    w_14_15   full_original_Gini_344  -2.7398809523809522e+01
    rho_14    normalized_ratio_14_184  1
    rho_14    block_pair_pos_295  1
    rho_14    block_pair_neg_296  -1
    rho_14    block_pair_pos_305  1
    rho_14    block_pair_neg_306  -1
    rho_14    block_pair_pos_319  1
    rho_14    block_pair_neg_320  -1
    rho_14    block_pair_pos_327  -1
    rho_14    block_pair_neg_328  1
    rho_14    block_pair_pos_329  -1
    rho_14    block_pair_neg_330  1
    rho_14    block_pair_pos_331  -1
    rho_14    block_pair_neg_332  1
    rho_14    block_pair_pos_341  1
    rho_14    block_pair_neg_342  -1
    rho_14    normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1249999999999993e-02
    x_11_0    product_lb_185  -2.5219923739729182e-02
    x_11_0    product_ub_186  -4.3054843669955919e-02
    x_11_0    onehot_11_211  1
    x_11_0    parent_nonstrict_scope_286  0.0375
    x_11_0    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_185  1
    w_11_0    product_ub_186  1
    w_11_0    normalized_mass_11_212  1
    w_11_0    full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7499999999999929e-03
    x_11_1    product_lb_187  -2.5219923739729182e-02
    x_11_1    product_ub_188  -4.3054843669955919e-02
    x_11_1    onehot_11_211  1
    x_11_1    stock_lb_284  1
    x_11_1    stock_ub_285  1
    x_11_1    parent_nonstrict_scope_286  0.03
    x_11_1    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_187  1
    w_11_1    product_ub_188  1
    w_11_1    normalized_mass_11_212  1
    w_11_1    normalized_ratio_11_213  -0.2
    w_11_1    full_original_Gini_344  -1.7826190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       -3.7500000000000068e-03
    x_11_2    product_lb_189  -2.5219923739729182e-02
    x_11_2    product_ub_190  -4.3054843669955919e-02
    x_11_2    onehot_11_211  1
    x_11_2    stock_lb_284  2
    x_11_2    stock_ub_285  2
    x_11_2    parent_nonstrict_scope_286  0.0225
    x_11_2    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_189  1
    w_11_2    product_ub_190  1
    w_11_2    normalized_mass_11_212  1
    w_11_2    normalized_ratio_11_213  -0.4
    w_11_2    full_original_Gini_344  -1.2426190476190472e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -1.1250000000000010e-02
    x_11_3    product_lb_191  -2.5219923739729182e-02
    x_11_3    product_ub_192  -4.3054843669955919e-02
    x_11_3    onehot_11_211  1
    x_11_3    stock_lb_284  3
    x_11_3    stock_ub_285  3
    x_11_3    parent_nonstrict_scope_286  1.4999999999999996e-02
    x_11_3    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_191  1
    w_11_3    product_ub_192  1
    w_11_3    normalized_mass_11_212  1
    w_11_3    normalized_ratio_11_213  -6.0000000000000009e-01
    w_11_3    full_original_Gini_344  -8.0261904761904770e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -1.8750000000000010e-02
    x_11_4    product_lb_193  -2.5219923739729182e-02
    x_11_4    product_ub_194  -4.3054843669955919e-02
    x_11_4    onehot_11_211  1
    x_11_4    stock_lb_284  4
    x_11_4    stock_ub_285  4
    x_11_4    parent_nonstrict_scope_286  7.4999999999999980e-03
    x_11_4    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_193  1
    w_11_4    product_ub_194  1
    w_11_4    normalized_mass_11_212  1
    w_11_4    normalized_ratio_11_213  -0.8
    w_11_4    full_original_Gini_344  -5.7404761904761923e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -2.6250000000000006e-02
    x_11_5    product_lb_195  -2.5219923739729182e-02
    x_11_5    product_ub_196  -4.3054843669955919e-02
    x_11_5    onehot_11_211  1
    x_11_5    stock_lb_284  5
    x_11_5    stock_ub_285  5
    x_11_5    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_195  1
    w_11_5    product_ub_196  1
    w_11_5    normalized_mass_11_212  1
    w_11_5    normalized_ratio_11_213  -1
    w_11_5    full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -0.01875
    x_11_6    product_lb_197  -2.5219923739729182e-02
    x_11_6    product_ub_198  -4.3054843669955919e-02
    x_11_6    onehot_11_211  1
    x_11_6    stock_lb_284  6
    x_11_6    stock_ub_285  6
    x_11_6    parent_nonstrict_scope_286  7.5000000000000067e-03
    x_11_6    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_197  1
    w_11_6    product_ub_198  1
    w_11_6    normalized_mass_11_212  1
    w_11_6    normalized_ratio_11_213  -1.2000000000000002e+00
    w_11_6    full_original_Gini_344  -9.2738095238095291e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -1.1250000000000001e-02
    x_11_7    product_lb_199  -2.5219923739729182e-02
    x_11_7    product_ub_200  -4.3054843669955919e-02
    x_11_7    onehot_11_211  1
    x_11_7    stock_lb_284  7
    x_11_7    stock_ub_285  7
    x_11_7    parent_nonstrict_scope_286  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_199  1
    w_11_7    product_ub_200  1
    w_11_7    normalized_mass_11_212  1
    w_11_7    normalized_ratio_11_213  -1.4000000000000001e+00
    w_11_7    full_original_Gini_344  -1.4573809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -3.7500000000000033e-03
    x_11_8    product_lb_201  -2.5219923739729182e-02
    x_11_8    product_ub_202  -4.3054843669955919e-02
    x_11_8    onehot_11_211  1
    x_11_8    stock_lb_284  8
    x_11_8    stock_ub_285  8
    x_11_8    parent_nonstrict_scope_286  2.2500000000000003e-02
    x_11_8    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_201  1
    w_11_8    product_ub_202  1
    w_11_8    normalized_mass_11_212  1
    w_11_8    normalized_ratio_11_213  -1.6
    w_11_8    full_original_Gini_344  -1.9973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       3.7499999999999929e-03
    x_11_9    product_lb_203  -2.5219923739729182e-02
    x_11_9    product_ub_204  -4.3054843669955919e-02
    x_11_9    onehot_11_211  1
    x_11_9    stock_lb_284  9
    x_11_9    stock_ub_285  9
    x_11_9    parent_nonstrict_scope_286  0.03
    x_11_9    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_203  1
    w_11_9    product_ub_204  1
    w_11_9    normalized_mass_11_212  1
    w_11_9    normalized_ratio_11_213  -1.8
    w_11_9    full_original_Gini_344  -2.5373809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1249999999999993e-02
    x_11_10   product_lb_205  -2.5219923739729182e-02
    x_11_10   product_ub_206  -4.3054843669955919e-02
    x_11_10   onehot_11_211  1
    x_11_10   stock_lb_284  10
    x_11_10   stock_ub_285  10
    x_11_10   parent_nonstrict_scope_286  0.0375
    x_11_10   unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_205  1
    w_11_10   product_ub_206  1
    w_11_10   normalized_mass_11_212  1
    w_11_10   normalized_ratio_11_213  -2
    w_11_10   full_original_Gini_344  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       0.01875
    x_11_11   product_lb_207  -2.5219923739729182e-02
    x_11_11   product_ub_208  -4.3054843669955919e-02
    x_11_11   onehot_11_211  1
    x_11_11   stock_lb_284  11
    x_11_11   stock_ub_285  11
    x_11_11   parent_nonstrict_scope_286  4.5000000000000005e-02
    x_11_11   unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_207  1
    w_11_11   product_ub_208  1
    w_11_11   normalized_mass_11_212  1
    w_11_11   normalized_ratio_11_213  -2.2
    w_11_11   full_original_Gini_344  -3.6173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_12   OBJ       2.6250000000000006e-02
    x_11_12   product_lb_209  -2.5219923739729182e-02
    x_11_12   product_ub_210  -4.3054843669955919e-02
    x_11_12   onehot_11_211  1
    x_11_12   stock_lb_284  12
    x_11_12   stock_ub_285  12
    x_11_12   parent_nonstrict_scope_286  5.2500000000000012e-02
    x_11_12   unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_209  1
    w_11_12   product_ub_210  1
    w_11_12   normalized_mass_11_212  1
    w_11_12   normalized_ratio_11_213  -2.4000000000000004e+00
    w_11_12   full_original_Gini_344  -4.1573809523809516e+01
    rho_11    normalized_ratio_11_213  1
    rho_11    block_pair_pos_293  1
    rho_11    block_pair_neg_294  -1
    rho_11    block_pair_pos_303  1
    rho_11    block_pair_neg_304  -1
    rho_11    block_pair_pos_317  1
    rho_11    block_pair_neg_318  -1
    rho_11    block_pair_pos_323  -1
    rho_11    block_pair_neg_324  1
    rho_11    block_pair_pos_325  -1
    rho_11    block_pair_neg_326  1
    rho_11    block_pair_pos_331  1
    rho_11    block_pair_neg_332  -1
    rho_11    block_pair_pos_339  1
    rho_11    block_pair_neg_340  -1
    rho_11    normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_214  -2.5219923739729182e-02
    x_2_0     product_ub_215  -4.3054843669955919e-02
    x_2_0     onehot_2_246  1
    x_2_0     parent_nonstrict_scope_286  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_214  1
    w_2_0     product_ub_215  1
    w_2_0     normalized_mass_2_247  1
    w_2_0     full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_216  -2.5219923739729182e-02
    x_2_1     product_ub_217  -4.3054843669955919e-02
    x_2_1     onehot_2_246  1
    x_2_1     stock_lb_284  1
    x_2_1     stock_ub_285  1
    x_2_1     parent_nonstrict_scope_286  0.063
    x_2_1     unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_216  1
    w_2_1     product_ub_217  1
    w_2_1     normalized_mass_2_247  1
    w_2_1     normalized_ratio_2_248  -1.4285714285714285e-01
    w_2_1     full_original_Gini_344  -1.9369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_218  -2.5219923739729182e-02
    x_2_2     product_ub_219  -4.3054843669955919e-02
    x_2_2     onehot_2_246  1
    x_2_2     stock_lb_284  2
    x_2_2     stock_ub_285  2
    x_2_2     parent_nonstrict_scope_286  0.0525
    x_2_2     unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_218  1
    w_2_2     product_ub_219  1
    w_2_2     normalized_mass_2_247  1
    w_2_2     normalized_ratio_2_248  -2.8571428571428570e-01
    w_2_2     full_original_Gini_344  -1.5511904761904757e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_220  -2.5219923739729182e-02
    x_2_3     product_ub_221  -4.3054843669955919e-02
    x_2_3     onehot_2_246  1
    x_2_3     stock_lb_284  3
    x_2_3     stock_ub_285  3
    x_2_3     parent_nonstrict_scope_286  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_220  1
    w_2_3     product_ub_221  1
    w_2_3     normalized_mass_2_247  1
    w_2_3     normalized_ratio_2_248  -4.2857142857142855e-01
    w_2_3     full_original_Gini_344  -1.1711904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_222  -2.5219923739729182e-02
    x_2_4     product_ub_223  -4.3054843669955919e-02
    x_2_4     onehot_2_246  1
    x_2_4     stock_lb_284  4
    x_2_4     stock_ub_285  4
    x_2_4     parent_nonstrict_scope_286  0.0315
    x_2_4     unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_222  1
    w_2_4     product_ub_223  1
    w_2_4     normalized_mass_2_247  1
    w_2_4     normalized_ratio_2_248  -5.7142857142857140e-01
    w_2_4     full_original_Gini_344  -8.5690476190476215e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_224  -2.5219923739729182e-02
    x_2_5     product_ub_225  -4.3054843669955919e-02
    x_2_5     onehot_2_246  1
    x_2_5     stock_lb_284  5
    x_2_5     stock_ub_285  5
    x_2_5     parent_nonstrict_scope_286  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_224  1
    w_2_5     product_ub_225  1
    w_2_5     normalized_mass_2_247  1
    w_2_5     normalized_ratio_2_248  -7.1428571428571419e-01
    w_2_5     full_original_Gini_344  -6.3119047619047617e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_226  -2.5219923739729182e-02
    x_2_6     product_ub_227  -4.3054843669955919e-02
    x_2_6     onehot_2_246  1
    x_2_6     stock_lb_284  6
    x_2_6     stock_ub_285  6
    x_2_6     parent_nonstrict_scope_286  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_226  1
    w_2_6     product_ub_227  1
    w_2_6     normalized_mass_2_247  1
    w_2_6     normalized_ratio_2_248  -8.5714285714285710e-01
    w_2_6     full_original_Gini_344  -5.5023809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_228  -2.5219923739729182e-02
    x_2_7     product_ub_229  -4.3054843669955919e-02
    x_2_7     onehot_2_246  1
    x_2_7     stock_lb_284  7
    x_2_7     stock_ub_285  7
    x_2_7     unique_nonzero_owner_443  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_228  1
    w_2_7     product_ub_229  1
    w_2_7     normalized_mass_2_247  1
    w_2_7     normalized_ratio_2_248  -1
    w_2_7     full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_230  -2.5219923739729182e-02
    x_2_8     product_ub_231  -4.3054843669955919e-02
    x_2_8     onehot_2_246  1
    x_2_8     stock_lb_284  8
    x_2_8     stock_ub_285  8
    x_2_8     parent_nonstrict_scope_286  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_444  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_230  1
    w_2_8     product_ub_231  1
    w_2_8     normalized_mass_2_247  1
    w_2_8     normalized_ratio_2_248  -1.1428571428571428e+00
    w_2_8     full_original_Gini_344  -8.0738095238095227e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_232  -2.5219923739729182e-02
    x_2_9     product_ub_233  -4.3054843669955919e-02
    x_2_9     onehot_2_246  1
    x_2_9     stock_lb_284  9
    x_2_9     stock_ub_285  9
    x_2_9     parent_nonstrict_scope_286  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_445  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_232  1
    w_2_9     product_ub_233  1
    w_2_9     normalized_mass_2_247  1
    w_2_9     normalized_ratio_2_248  -1.2857142857142856e+00
    w_2_9     full_original_Gini_344  -1.1488095238095230e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_234  -2.5219923739729182e-02
    x_2_10    product_ub_235  -4.3054843669955919e-02
    x_2_10    onehot_2_246  1
    x_2_10    stock_lb_284  10
    x_2_10    stock_ub_285  10
    x_2_10    parent_nonstrict_scope_286  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_446  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_234  1
    w_2_10    product_ub_235  1
    w_2_10    normalized_mass_2_247  1
    w_2_10    normalized_ratio_2_248  -1.4285714285714284e+00
    w_2_10    full_original_Gini_344  -1.5345238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_236  -2.5219923739729182e-02
    x_2_11    product_ub_237  -4.3054843669955919e-02
    x_2_11    onehot_2_246  1
    x_2_11    stock_lb_284  11
    x_2_11    stock_ub_285  11
    x_2_11    parent_nonstrict_scope_286  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_447  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_236  1
    w_2_11    product_ub_237  1
    w_2_11    normalized_mass_2_247  1
    w_2_11    normalized_ratio_2_248  -1.5714285714285714e+00
    w_2_11    full_original_Gini_344  -1.9202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_238  -2.5219923739729182e-02
    x_2_12    product_ub_239  -4.3054843669955919e-02
    x_2_12    onehot_2_246  1
    x_2_12    stock_lb_284  12
    x_2_12    stock_ub_285  12
    x_2_12    parent_nonstrict_scope_286  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_448  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_238  1
    w_2_12    product_ub_239  1
    w_2_12    normalized_mass_2_247  1
    w_2_12    normalized_ratio_2_248  -1.7142857142857142e+00
    w_2_12    full_original_Gini_344  -2.3059523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_240  -2.5219923739729182e-02
    x_2_13    product_ub_241  -4.3054843669955919e-02
    x_2_13    onehot_2_246  1
    x_2_13    stock_lb_284  13
    x_2_13    stock_ub_285  13
    x_2_13    parent_nonstrict_scope_286  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_449  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_240  1
    w_2_13    product_ub_241  1
    w_2_13    normalized_mass_2_247  1
    w_2_13    normalized_ratio_2_248  -1.8571428571428570e+00
    w_2_13    full_original_Gini_344  -2.6916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_242  -2.5219923739729182e-02
    x_2_14    product_ub_243  -4.3054843669955919e-02
    x_2_14    onehot_2_246  1
    x_2_14    stock_lb_284  14
    x_2_14    stock_ub_285  14
    x_2_14    parent_nonstrict_scope_286  0.0735
    x_2_14    unique_nonzero_owner_450  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_242  1
    w_2_14    product_ub_243  1
    w_2_14    normalized_mass_2_247  1
    w_2_14    normalized_ratio_2_248  -2
    w_2_14    full_original_Gini_344  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_244  -2.5219923739729182e-02
    x_2_15    product_ub_245  -4.3054843669955919e-02
    x_2_15    onehot_2_246  1
    x_2_15    stock_lb_284  15
    x_2_15    stock_ub_285  15
    x_2_15    parent_nonstrict_scope_286  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_451  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_244  1
    w_2_15    product_ub_245  1
    w_2_15    normalized_mass_2_247  1
    w_2_15    normalized_ratio_2_248  -2.1428571428571428e+00
    w_2_15    full_original_Gini_344  -3.4630952380952380e+01
    rho_2     normalized_ratio_2_248  1
    rho_2     block_pair_pos_287  -1
    rho_2     block_pair_neg_288  1
    rho_2     block_pair_pos_289  1
    rho_2     block_pair_neg_290  -1
    rho_2     block_pair_pos_297  1
    rho_2     block_pair_neg_298  -1
    rho_2     block_pair_pos_309  1
    rho_2     block_pair_neg_310  -1
    rho_2     block_pair_pos_323  1
    rho_2     block_pair_neg_324  -1
    rho_2     block_pair_pos_327  1
    rho_2     block_pair_neg_328  -1
    rho_2     block_pair_pos_333  1
    rho_2     block_pair_neg_334  -1
    rho_2     normalization_343  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       0.0315
    x_4_0     product_lb_249  -2.5219923739729182e-02
    x_4_0     product_ub_250  -4.3054843669955919e-02
    x_4_0     onehot_4_281  1
    x_4_0     parent_nonstrict_scope_286  0.0735
    x_4_0     unique_nonzero_owner_452  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_249  1
    w_4_0     product_ub_250  1
    w_4_0     normalized_mass_4_282  1
    w_4_0     full_original_Gini_344  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       2.1000000000000005e-02
    x_4_1     product_lb_251  -2.5219923739729182e-02
    x_4_1     product_ub_252  -4.3054843669955919e-02
    x_4_1     onehot_4_281  1
    x_4_1     stock_lb_284  1
    x_4_1     stock_ub_285  1
    x_4_1     parent_nonstrict_scope_286  0.063
    x_4_1     unique_nonzero_owner_453  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_251  1
    w_4_1     product_ub_252  1
    w_4_1     normalized_mass_4_282  1
    w_4_1     normalized_ratio_4_283  -1.4285714285714285e-01
    w_4_1     full_original_Gini_344  -1.9369047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       1.0500000000000002e-02
    x_4_2     product_lb_253  -2.5219923739729182e-02
    x_4_2     product_ub_254  -4.3054843669955919e-02
    x_4_2     onehot_4_281  1
    x_4_2     stock_lb_284  2
    x_4_2     stock_ub_285  2
    x_4_2     parent_nonstrict_scope_286  0.0525
    x_4_2     unique_nonzero_owner_454  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_253  1
    w_4_2     product_ub_254  1
    w_4_2     normalized_mass_4_282  1
    w_4_2     normalized_ratio_4_283  -2.8571428571428570e-01
    w_4_2     full_original_Gini_344  -1.5511904761904757e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_255  -2.5219923739729182e-02
    x_4_3     product_ub_256  -4.3054843669955919e-02
    x_4_3     onehot_4_281  1
    x_4_3     stock_lb_284  3
    x_4_3     stock_ub_285  3
    x_4_3     parent_nonstrict_scope_286  4.1999999999999996e-02
    x_4_3     unique_nonzero_owner_455  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_255  1
    w_4_3     product_ub_256  1
    w_4_3     normalized_mass_4_282  1
    w_4_3     normalized_ratio_4_283  -4.2857142857142855e-01
    w_4_3     full_original_Gini_344  -1.1711904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -1.0499999999999995e-02
    x_4_4     product_lb_257  -2.5219923739729182e-02
    x_4_4     product_ub_258  -4.3054843669955919e-02
    x_4_4     onehot_4_281  1
    x_4_4     stock_lb_284  4
    x_4_4     stock_ub_285  4
    x_4_4     parent_nonstrict_scope_286  0.0315
    x_4_4     unique_nonzero_owner_456  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_257  1
    w_4_4     product_ub_258  1
    w_4_4     normalized_mass_4_282  1
    w_4_4     normalized_ratio_4_283  -5.7142857142857140e-01
    w_4_4     full_original_Gini_344  -8.5690476190476215e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -2.0999999999999991e-02
    x_4_5     product_lb_259  -2.5219923739729182e-02
    x_4_5     product_ub_260  -4.3054843669955919e-02
    x_4_5     onehot_4_281  1
    x_4_5     stock_lb_284  5
    x_4_5     stock_ub_285  5
    x_4_5     parent_nonstrict_scope_286  2.1000000000000005e-02
    x_4_5     unique_nonzero_owner_457  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_259  1
    w_4_5     product_ub_260  1
    w_4_5     normalized_mass_4_282  1
    w_4_5     normalized_ratio_4_283  -7.1428571428571419e-01
    w_4_5     full_original_Gini_344  -6.3119047619047617e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -3.1499999999999993e-02
    x_4_6     product_lb_261  -2.5219923739729182e-02
    x_4_6     product_ub_262  -4.3054843669955919e-02
    x_4_6     onehot_4_281  1
    x_4_6     stock_lb_284  6
    x_4_6     stock_ub_285  6
    x_4_6     parent_nonstrict_scope_286  1.0500000000000002e-02
    x_4_6     unique_nonzero_owner_458  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_261  1
    w_4_6     product_ub_262  1
    w_4_6     normalized_mass_4_282  1
    w_4_6     normalized_ratio_4_283  -8.5714285714285710e-01
    w_4_6     full_original_Gini_344  -5.5023809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -4.1999999999999996e-02
    x_4_7     product_lb_263  -2.5219923739729182e-02
    x_4_7     product_ub_264  -4.3054843669955919e-02
    x_4_7     onehot_4_281  1
    x_4_7     stock_lb_284  7
    x_4_7     stock_ub_285  7
    x_4_7     unique_nonzero_owner_459  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_263  1
    w_4_7     product_ub_264  1
    w_4_7     normalized_mass_4_282  1
    w_4_7     normalized_ratio_4_283  -1
    w_4_7     full_original_Gini_344  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -0.0315
    x_4_8     product_lb_265  -2.5219923739729182e-02
    x_4_8     product_ub_266  -4.3054843669955919e-02
    x_4_8     onehot_4_281  1
    x_4_8     stock_lb_284  8
    x_4_8     stock_ub_285  8
    x_4_8     parent_nonstrict_scope_286  1.0499999999999995e-02
    x_4_8     unique_nonzero_owner_460  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_265  1
    w_4_8     product_ub_266  1
    w_4_8     normalized_mass_4_282  1
    w_4_8     normalized_ratio_4_283  -1.1428571428571428e+00
    w_4_8     full_original_Gini_344  -8.0738095238095227e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -2.1000000000000005e-02
    x_4_9     product_lb_267  -2.5219923739729182e-02
    x_4_9     product_ub_268  -4.3054843669955919e-02
    x_4_9     onehot_4_281  1
    x_4_9     stock_lb_284  9
    x_4_9     stock_ub_285  9
    x_4_9     parent_nonstrict_scope_286  2.0999999999999991e-02
    x_4_9     unique_nonzero_owner_461  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_267  1
    w_4_9     product_ub_268  1
    w_4_9     normalized_mass_4_282  1
    w_4_9     normalized_ratio_4_283  -1.2857142857142856e+00
    w_4_9     full_original_Gini_344  -1.1488095238095230e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -1.0500000000000009e-02
    x_4_10    product_lb_269  -2.5219923739729182e-02
    x_4_10    product_ub_270  -4.3054843669955919e-02
    x_4_10    onehot_4_281  1
    x_4_10    stock_lb_284  10
    x_4_10    stock_ub_285  10
    x_4_10    parent_nonstrict_scope_286  3.1499999999999986e-02
    x_4_10    unique_nonzero_owner_462  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_269  1
    w_4_10    product_ub_270  1
    w_4_10    normalized_mass_4_282  1
    w_4_10    normalized_ratio_4_283  -1.4285714285714284e+00
    w_4_10    full_original_Gini_344  -1.5345238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_271  -2.5219923739729182e-02
    x_4_11    product_ub_272  -4.3054843669955919e-02
    x_4_11    onehot_4_281  1
    x_4_11    stock_lb_284  11
    x_4_11    stock_ub_285  11
    x_4_11    parent_nonstrict_scope_286  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_271  1
    w_4_11    product_ub_272  1
    w_4_11    normalized_mass_4_282  1
    w_4_11    normalized_ratio_4_283  -1.5714285714285714e+00
    w_4_11    full_original_Gini_344  -1.9202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       1.0499999999999995e-02
    x_4_12    product_lb_273  -2.5219923739729182e-02
    x_4_12    product_ub_274  -4.3054843669955919e-02
    x_4_12    onehot_4_281  1
    x_4_12    stock_lb_284  12
    x_4_12    stock_ub_285  12
    x_4_12    parent_nonstrict_scope_286  5.2499999999999991e-02
    x_4_12    unique_nonzero_owner_463  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_273  1
    w_4_12    product_ub_274  1
    w_4_12    normalized_mass_4_282  1
    w_4_12    normalized_ratio_4_283  -1.7142857142857142e+00
    w_4_12    full_original_Gini_344  -2.3059523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       2.0999999999999991e-02
    x_4_13    product_lb_275  -2.5219923739729182e-02
    x_4_13    product_ub_276  -4.3054843669955919e-02
    x_4_13    onehot_4_281  1
    x_4_13    stock_lb_284  13
    x_4_13    stock_ub_285  13
    x_4_13    parent_nonstrict_scope_286  6.2999999999999987e-02
    x_4_13    unique_nonzero_owner_464  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_275  1
    w_4_13    product_ub_276  1
    w_4_13    normalized_mass_4_282  1
    w_4_13    normalized_ratio_4_283  -1.8571428571428570e+00
    w_4_13    full_original_Gini_344  -2.6916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       0.0315
    x_4_14    product_lb_277  -2.5219923739729182e-02
    x_4_14    product_ub_278  -4.3054843669955919e-02
    x_4_14    onehot_4_281  1
    x_4_14    stock_lb_284  14
    x_4_14    stock_ub_285  14
    x_4_14    parent_nonstrict_scope_286  0.0735
    x_4_14    unique_nonzero_owner_465  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_277  1
    w_4_14    product_ub_278  1
    w_4_14    normalized_mass_4_282  1
    w_4_14    normalized_ratio_4_283  -2
    w_4_14    full_original_Gini_344  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       4.1999999999999996e-02
    x_4_15    product_lb_279  -2.5219923739729182e-02
    x_4_15    product_ub_280  -4.3054843669955919e-02
    x_4_15    onehot_4_281  1
    x_4_15    stock_lb_284  15
    x_4_15    stock_ub_285  15
    x_4_15    parent_nonstrict_scope_286  8.3999999999999991e-02
    x_4_15    unique_nonzero_owner_466  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_279  1
    w_4_15    product_ub_280  1
    w_4_15    normalized_mass_4_282  1
    w_4_15    normalized_ratio_4_283  -2.1428571428571428e+00
    w_4_15    full_original_Gini_344  -3.4630952380952380e+01
    rho_4     normalized_ratio_4_283  1
    rho_4     block_pair_pos_287  1
    rho_4     block_pair_neg_288  -1
    rho_4     block_pair_pos_291  1
    rho_4     block_pair_neg_292  -1
    rho_4     block_pair_pos_301  1
    rho_4     block_pair_neg_302  -1
    rho_4     block_pair_pos_313  1
    rho_4     block_pair_neg_314  -1
    rho_4     block_pair_pos_325  1
    rho_4     block_pair_neg_326  -1
    rho_4     block_pair_pos_329  1
    rho_4     block_pair_neg_330  -1
    rho_4     block_pair_pos_337  1
    rho_4     block_pair_neg_338  -1
    rho_4     normalization_343  1
    a_10_7    block_pair_pos_315  1
    a_10_7    block_pair_neg_316  1
    a_10_7    full_original_Gini_344  -1
    a_10_31   block_pair_pos_321  1
    a_10_31   block_pair_neg_322  1
    a_10_31   full_original_Gini_344  -1
    a_10_3    block_pair_pos_311  1
    a_10_3    block_pair_neg_312  1
    a_10_3    full_original_Gini_344  -1
    a_10_14   block_pair_pos_319  1
    a_10_14   block_pair_neg_320  1
    a_10_14   full_original_Gini_344  -1
    a_10_11   block_pair_pos_317  1
    a_10_11   block_pair_neg_318  1
    a_10_11   full_original_Gini_344  -1
    a_10_2    block_pair_pos_309  1
    a_10_2    block_pair_neg_310  1
    a_10_2    full_original_Gini_344  -1
    a_10_4    block_pair_pos_313  1
    a_10_4    block_pair_neg_314  1
    a_10_4    full_original_Gini_344  -1
    a_7_31    block_pair_pos_307  1
    a_7_31    block_pair_neg_308  1
    a_7_31    full_original_Gini_344  -1
    a_7_3     block_pair_pos_299  1
    a_7_3     block_pair_neg_300  1
    a_7_3     full_original_Gini_344  -1
    a_7_14    block_pair_pos_305  1
    a_7_14    block_pair_neg_306  1
    a_7_14    full_original_Gini_344  -1
    a_7_11    block_pair_pos_303  1
    a_7_11    block_pair_neg_304  1
    a_7_11    full_original_Gini_344  -1
    a_7_2     block_pair_pos_297  1
    a_7_2     block_pair_neg_298  1
    a_7_2     full_original_Gini_344  -1
    a_7_4     block_pair_pos_301  1
    a_7_4     block_pair_neg_302  1
    a_7_4     full_original_Gini_344  -1
    a_31_3    block_pair_pos_335  1
    a_31_3    block_pair_neg_336  1
    a_31_3    full_original_Gini_344  -1
    a_31_14   block_pair_pos_341  1
    a_31_14   block_pair_neg_342  1
    a_31_14   full_original_Gini_344  -1
    a_31_11   block_pair_pos_339  1
    a_31_11   block_pair_neg_340  1
    a_31_11   full_original_Gini_344  -1
    a_31_2    block_pair_pos_333  1
    a_31_2    block_pair_neg_334  1
    a_31_2    full_original_Gini_344  -1
    a_31_4    block_pair_pos_337  1
    a_31_4    block_pair_neg_338  1
    a_31_4    full_original_Gini_344  -1
    a_3_14    block_pair_pos_295  1
    a_3_14    block_pair_neg_296  1
    a_3_14    full_original_Gini_344  -1
    a_3_11    block_pair_pos_293  1
    a_3_11    block_pair_neg_294  1
    a_3_11    full_original_Gini_344  -1
    a_3_2     block_pair_pos_289  1
    a_3_2     block_pair_neg_290  1
    a_3_2     full_original_Gini_344  -1
    a_3_4     block_pair_pos_291  1
    a_3_4     block_pair_neg_292  1
    a_3_4     full_original_Gini_344  -1
    a_14_11   block_pair_pos_331  1
    a_14_11   block_pair_neg_332  1
    a_14_11   full_original_Gini_344  -1
    a_14_2    block_pair_pos_327  1
    a_14_2    block_pair_neg_328  1
    a_14_2    full_original_Gini_344  -1
    a_14_4    block_pair_pos_329  1
    a_14_4    block_pair_neg_330  1
    a_14_4    full_original_Gini_344  -1
    a_11_2    block_pair_pos_323  1
    a_11_2    block_pair_neg_324  1
    a_11_2    full_original_Gini_344  -1
    a_11_4    block_pair_pos_325  1
    a_11_4    block_pair_neg_326  1
    a_11_4    full_original_Gini_344  -1
    a_2_4     block_pair_pos_287  1
    a_2_4     block_pair_neg_288  1
    a_2_4     full_original_Gini_344  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_10_0  unique_nonzero_owner_345  1
    service_0_10_0  service_visit_def_790  1
    service_0_10_0  free_load_conservation_791  -15
    service_0_10_0  original_T_including_depot_unload_837  1800
    service_0_10_1  unique_nonzero_owner_346  1
    service_0_10_1  service_visit_def_790  1
    service_0_10_1  free_load_conservation_791  -14
    service_0_10_1  original_T_including_depot_unload_837  1680
    service_0_10_2  unique_nonzero_owner_347  1
    service_0_10_2  service_visit_def_790  1
    service_0_10_2  free_load_conservation_791  -13
    service_0_10_2  original_T_including_depot_unload_837  1560
    service_0_10_3  unique_nonzero_owner_348  1
    service_0_10_3  service_visit_def_790  1
    service_0_10_3  free_load_conservation_791  -12
    service_0_10_3  original_T_including_depot_unload_837  1440
    service_0_10_4  unique_nonzero_owner_349  1
    service_0_10_4  service_visit_def_790  1
    service_0_10_4  free_load_conservation_791  -11
    service_0_10_4  original_T_including_depot_unload_837  1320
    service_0_10_5  unique_nonzero_owner_350  1
    service_0_10_5  service_visit_def_790  1
    service_0_10_5  free_load_conservation_791  -10
    service_0_10_5  original_T_including_depot_unload_837  1200
    service_0_10_6  unique_nonzero_owner_351  1
    service_0_10_6  service_visit_def_790  1
    service_0_10_6  free_load_conservation_791  -9
    service_0_10_6  original_T_including_depot_unload_837  1080
    service_0_10_7  unique_nonzero_owner_352  1
    service_0_10_7  service_visit_def_790  1
    service_0_10_7  free_load_conservation_791  -8
    service_0_10_7  original_T_including_depot_unload_837  960
    service_0_10_8  unique_nonzero_owner_353  1
    service_0_10_8  service_visit_def_790  1
    service_0_10_8  free_load_conservation_791  -7
    service_0_10_8  original_T_including_depot_unload_837  840
    service_0_10_9  unique_nonzero_owner_354  1
    service_0_10_9  service_visit_def_790  1
    service_0_10_9  free_load_conservation_791  -6
    service_0_10_9  original_T_including_depot_unload_837  720
    service_0_10_10  unique_nonzero_owner_355  1
    service_0_10_10  service_visit_def_790  1
    service_0_10_10  free_load_conservation_791  -5
    service_0_10_10  original_T_including_depot_unload_837  600
    service_0_10_11  unique_nonzero_owner_356  1
    service_0_10_11  service_visit_def_790  1
    service_0_10_11  free_load_conservation_791  -4
    service_0_10_11  original_T_including_depot_unload_837  480
    service_0_10_12  unique_nonzero_owner_357  1
    service_0_10_12  service_visit_def_790  1
    service_0_10_12  free_load_conservation_791  -3
    service_0_10_12  original_T_including_depot_unload_837  360
    service_0_10_13  unique_nonzero_owner_358  1
    service_0_10_13  service_visit_def_790  1
    service_0_10_13  free_load_conservation_791  -2
    service_0_10_13  original_T_including_depot_unload_837  240
    service_0_10_14  unique_nonzero_owner_359  1
    service_0_10_14  service_visit_def_790  1
    service_0_10_14  free_load_conservation_791  -1
    service_0_10_14  original_T_including_depot_unload_837  120
    service_0_10_16  unique_nonzero_owner_360  1
    service_0_10_16  service_visit_def_790  1
    service_0_10_16  free_load_conservation_791  1
    service_0_10_17  unique_nonzero_owner_361  1
    service_0_10_17  service_visit_def_790  1
    service_0_10_17  free_load_conservation_791  2
    service_0_10_18  unique_nonzero_owner_362  1
    service_0_10_18  service_visit_def_790  1
    service_0_10_18  free_load_conservation_791  3
    service_0_10_19  unique_nonzero_owner_363  1
    service_0_10_19  service_visit_def_790  1
    service_0_10_19  free_load_conservation_791  4
    service_1_10_0  unique_nonzero_owner_345  1
    service_1_10_0  service_visit_def_1218  1
    service_1_10_0  free_load_conservation_1219  -15
    service_1_10_0  original_T_including_depot_unload_1266  1800
    service_1_10_1  unique_nonzero_owner_346  1
    service_1_10_1  service_visit_def_1218  1
    service_1_10_1  free_load_conservation_1219  -14
    service_1_10_1  original_T_including_depot_unload_1266  1680
    service_1_10_2  unique_nonzero_owner_347  1
    service_1_10_2  service_visit_def_1218  1
    service_1_10_2  free_load_conservation_1219  -13
    service_1_10_2  original_T_including_depot_unload_1266  1560
    service_1_10_3  unique_nonzero_owner_348  1
    service_1_10_3  service_visit_def_1218  1
    service_1_10_3  free_load_conservation_1219  -12
    service_1_10_3  original_T_including_depot_unload_1266  1440
    service_1_10_4  unique_nonzero_owner_349  1
    service_1_10_4  service_visit_def_1218  1
    service_1_10_4  free_load_conservation_1219  -11
    service_1_10_4  original_T_including_depot_unload_1266  1320
    service_1_10_5  unique_nonzero_owner_350  1
    service_1_10_5  service_visit_def_1218  1
    service_1_10_5  free_load_conservation_1219  -10
    service_1_10_5  original_T_including_depot_unload_1266  1200
    service_1_10_6  unique_nonzero_owner_351  1
    service_1_10_6  service_visit_def_1218  1
    service_1_10_6  free_load_conservation_1219  -9
    service_1_10_6  original_T_including_depot_unload_1266  1080
    service_1_10_7  unique_nonzero_owner_352  1
    service_1_10_7  service_visit_def_1218  1
    service_1_10_7  free_load_conservation_1219  -8
    service_1_10_7  original_T_including_depot_unload_1266  960
    service_1_10_8  unique_nonzero_owner_353  1
    service_1_10_8  service_visit_def_1218  1
    service_1_10_8  free_load_conservation_1219  -7
    service_1_10_8  original_T_including_depot_unload_1266  840
    service_1_10_9  unique_nonzero_owner_354  1
    service_1_10_9  service_visit_def_1218  1
    service_1_10_9  free_load_conservation_1219  -6
    service_1_10_9  original_T_including_depot_unload_1266  720
    service_1_10_10  unique_nonzero_owner_355  1
    service_1_10_10  service_visit_def_1218  1
    service_1_10_10  free_load_conservation_1219  -5
    service_1_10_10  original_T_including_depot_unload_1266  600
    service_1_10_11  unique_nonzero_owner_356  1
    service_1_10_11  service_visit_def_1218  1
    service_1_10_11  free_load_conservation_1219  -4
    service_1_10_11  original_T_including_depot_unload_1266  480
    service_1_10_12  unique_nonzero_owner_357  1
    service_1_10_12  service_visit_def_1218  1
    service_1_10_12  free_load_conservation_1219  -3
    service_1_10_12  original_T_including_depot_unload_1266  360
    service_1_10_13  unique_nonzero_owner_358  1
    service_1_10_13  service_visit_def_1218  1
    service_1_10_13  free_load_conservation_1219  -2
    service_1_10_13  original_T_including_depot_unload_1266  240
    service_1_10_14  unique_nonzero_owner_359  1
    service_1_10_14  service_visit_def_1218  1
    service_1_10_14  free_load_conservation_1219  -1
    service_1_10_14  original_T_including_depot_unload_1266  120
    service_1_10_16  unique_nonzero_owner_360  1
    service_1_10_16  service_visit_def_1218  1
    service_1_10_16  free_load_conservation_1219  1
    service_1_10_17  unique_nonzero_owner_361  1
    service_1_10_17  service_visit_def_1218  1
    service_1_10_17  free_load_conservation_1219  2
    service_1_10_18  unique_nonzero_owner_362  1
    service_1_10_18  service_visit_def_1218  1
    service_1_10_18  free_load_conservation_1219  3
    service_1_10_19  unique_nonzero_owner_363  1
    service_1_10_19  service_visit_def_1218  1
    service_1_10_19  free_load_conservation_1219  4
    service_2_10_0  unique_nonzero_owner_345  1
    service_2_10_0  service_visit_def_1537  1
    service_2_10_0  free_load_conservation_1538  -15
    service_2_10_0  original_T_including_depot_unload_1583  1800
    service_2_10_1  unique_nonzero_owner_346  1
    service_2_10_1  service_visit_def_1537  1
    service_2_10_1  free_load_conservation_1538  -14
    service_2_10_1  original_T_including_depot_unload_1583  1680
    service_2_10_2  unique_nonzero_owner_347  1
    service_2_10_2  service_visit_def_1537  1
    service_2_10_2  free_load_conservation_1538  -13
    service_2_10_2  original_T_including_depot_unload_1583  1560
    service_2_10_3  unique_nonzero_owner_348  1
    service_2_10_3  service_visit_def_1537  1
    service_2_10_3  free_load_conservation_1538  -12
    service_2_10_3  original_T_including_depot_unload_1583  1440
    service_2_10_4  unique_nonzero_owner_349  1
    service_2_10_4  service_visit_def_1537  1
    service_2_10_4  free_load_conservation_1538  -11
    service_2_10_4  original_T_including_depot_unload_1583  1320
    service_2_10_5  unique_nonzero_owner_350  1
    service_2_10_5  service_visit_def_1537  1
    service_2_10_5  free_load_conservation_1538  -10
    service_2_10_5  original_T_including_depot_unload_1583  1200
    service_2_10_6  unique_nonzero_owner_351  1
    service_2_10_6  service_visit_def_1537  1
    service_2_10_6  free_load_conservation_1538  -9
    service_2_10_6  original_T_including_depot_unload_1583  1080
    service_2_10_7  unique_nonzero_owner_352  1
    service_2_10_7  service_visit_def_1537  1
    service_2_10_7  free_load_conservation_1538  -8
    service_2_10_7  original_T_including_depot_unload_1583  960
    service_2_10_8  unique_nonzero_owner_353  1
    service_2_10_8  service_visit_def_1537  1
    service_2_10_8  free_load_conservation_1538  -7
    service_2_10_8  original_T_including_depot_unload_1583  840
    service_2_10_9  unique_nonzero_owner_354  1
    service_2_10_9  service_visit_def_1537  1
    service_2_10_9  free_load_conservation_1538  -6
    service_2_10_9  original_T_including_depot_unload_1583  720
    service_2_10_10  unique_nonzero_owner_355  1
    service_2_10_10  service_visit_def_1537  1
    service_2_10_10  free_load_conservation_1538  -5
    service_2_10_10  original_T_including_depot_unload_1583  600
    service_2_10_11  unique_nonzero_owner_356  1
    service_2_10_11  service_visit_def_1537  1
    service_2_10_11  free_load_conservation_1538  -4
    service_2_10_11  original_T_including_depot_unload_1583  480
    service_2_10_12  unique_nonzero_owner_357  1
    service_2_10_12  service_visit_def_1537  1
    service_2_10_12  free_load_conservation_1538  -3
    service_2_10_12  original_T_including_depot_unload_1583  360
    service_2_10_13  unique_nonzero_owner_358  1
    service_2_10_13  service_visit_def_1537  1
    service_2_10_13  free_load_conservation_1538  -2
    service_2_10_13  original_T_including_depot_unload_1583  240
    service_2_10_14  unique_nonzero_owner_359  1
    service_2_10_14  service_visit_def_1537  1
    service_2_10_14  free_load_conservation_1538  -1
    service_2_10_14  original_T_including_depot_unload_1583  120
    service_2_10_16  unique_nonzero_owner_360  1
    service_2_10_16  service_visit_def_1537  1
    service_2_10_16  free_load_conservation_1538  1
    service_2_10_17  unique_nonzero_owner_361  1
    service_2_10_17  service_visit_def_1537  1
    service_2_10_17  free_load_conservation_1538  2
    service_2_10_18  unique_nonzero_owner_362  1
    service_2_10_18  service_visit_def_1537  1
    service_2_10_18  free_load_conservation_1538  3
    service_2_10_19  unique_nonzero_owner_363  1
    service_2_10_19  service_visit_def_1537  1
    service_2_10_19  free_load_conservation_1538  4
    service_0_7_0  unique_nonzero_owner_364  1
    service_0_7_0  service_visit_def_796  1
    service_0_7_0  free_load_conservation_797  -12
    service_0_7_0  original_T_including_depot_unload_837  1440
    service_0_7_1  unique_nonzero_owner_365  1
    service_0_7_1  service_visit_def_796  1
    service_0_7_1  free_load_conservation_797  -11
    service_0_7_1  original_T_including_depot_unload_837  1320
    service_0_7_2  unique_nonzero_owner_366  1
    service_0_7_2  service_visit_def_796  1
    service_0_7_2  free_load_conservation_797  -10
    service_0_7_2  original_T_including_depot_unload_837  1200
    service_0_7_3  unique_nonzero_owner_367  1
    service_0_7_3  service_visit_def_796  1
    service_0_7_3  free_load_conservation_797  -9
    service_0_7_3  original_T_including_depot_unload_837  1080
    service_0_7_4  unique_nonzero_owner_368  1
    service_0_7_4  service_visit_def_796  1
    service_0_7_4  free_load_conservation_797  -8
    service_0_7_4  original_T_including_depot_unload_837  960
    service_0_7_5  unique_nonzero_owner_369  1
    service_0_7_5  service_visit_def_796  1
    service_0_7_5  free_load_conservation_797  -7
    service_0_7_5  original_T_including_depot_unload_837  840
    service_0_7_6  unique_nonzero_owner_370  1
    service_0_7_6  service_visit_def_796  1
    service_0_7_6  free_load_conservation_797  -6
    service_0_7_6  original_T_including_depot_unload_837  720
    service_0_7_7  unique_nonzero_owner_371  1
    service_0_7_7  service_visit_def_796  1
    service_0_7_7  free_load_conservation_797  -5
    service_0_7_7  original_T_including_depot_unload_837  600
    service_0_7_8  unique_nonzero_owner_372  1
    service_0_7_8  service_visit_def_796  1
    service_0_7_8  free_load_conservation_797  -4
    service_0_7_8  original_T_including_depot_unload_837  480
    service_0_7_9  unique_nonzero_owner_373  1
    service_0_7_9  service_visit_def_796  1
    service_0_7_9  free_load_conservation_797  -3
    service_0_7_9  original_T_including_depot_unload_837  360
    service_0_7_10  unique_nonzero_owner_374  1
    service_0_7_10  service_visit_def_796  1
    service_0_7_10  free_load_conservation_797  -2
    service_0_7_10  original_T_including_depot_unload_837  240
    service_0_7_11  unique_nonzero_owner_375  1
    service_0_7_11  service_visit_def_796  1
    service_0_7_11  free_load_conservation_797  -1
    service_0_7_11  original_T_including_depot_unload_837  120
    service_0_7_13  unique_nonzero_owner_376  1
    service_0_7_13  service_visit_def_796  1
    service_0_7_13  free_load_conservation_797  1
    service_0_7_14  unique_nonzero_owner_377  1
    service_0_7_14  service_visit_def_796  1
    service_0_7_14  free_load_conservation_797  2
    service_0_7_15  unique_nonzero_owner_378  1
    service_0_7_15  service_visit_def_796  1
    service_0_7_15  free_load_conservation_797  3
    service_0_7_16  unique_nonzero_owner_379  1
    service_0_7_16  service_visit_def_796  1
    service_0_7_16  free_load_conservation_797  4
    service_0_7_17  unique_nonzero_owner_380  1
    service_0_7_17  service_visit_def_796  1
    service_0_7_17  free_load_conservation_797  5
    service_1_7_0  unique_nonzero_owner_364  1
    service_1_7_0  service_visit_def_1224  1
    service_1_7_0  free_load_conservation_1225  -12
    service_1_7_0  original_T_including_depot_unload_1266  1440
    service_1_7_1  unique_nonzero_owner_365  1
    service_1_7_1  service_visit_def_1224  1
    service_1_7_1  free_load_conservation_1225  -11
    service_1_7_1  original_T_including_depot_unload_1266  1320
    service_1_7_2  unique_nonzero_owner_366  1
    service_1_7_2  service_visit_def_1224  1
    service_1_7_2  free_load_conservation_1225  -10
    service_1_7_2  original_T_including_depot_unload_1266  1200
    service_1_7_3  unique_nonzero_owner_367  1
    service_1_7_3  service_visit_def_1224  1
    service_1_7_3  free_load_conservation_1225  -9
    service_1_7_3  original_T_including_depot_unload_1266  1080
    service_1_7_4  unique_nonzero_owner_368  1
    service_1_7_4  service_visit_def_1224  1
    service_1_7_4  free_load_conservation_1225  -8
    service_1_7_4  original_T_including_depot_unload_1266  960
    service_1_7_5  unique_nonzero_owner_369  1
    service_1_7_5  service_visit_def_1224  1
    service_1_7_5  free_load_conservation_1225  -7
    service_1_7_5  original_T_including_depot_unload_1266  840
    service_1_7_6  unique_nonzero_owner_370  1
    service_1_7_6  service_visit_def_1224  1
    service_1_7_6  free_load_conservation_1225  -6
    service_1_7_6  original_T_including_depot_unload_1266  720
    service_1_7_7  unique_nonzero_owner_371  1
    service_1_7_7  service_visit_def_1224  1
    service_1_7_7  free_load_conservation_1225  -5
    service_1_7_7  original_T_including_depot_unload_1266  600
    service_1_7_8  unique_nonzero_owner_372  1
    service_1_7_8  service_visit_def_1224  1
    service_1_7_8  free_load_conservation_1225  -4
    service_1_7_8  original_T_including_depot_unload_1266  480
    service_1_7_9  unique_nonzero_owner_373  1
    service_1_7_9  service_visit_def_1224  1
    service_1_7_9  free_load_conservation_1225  -3
    service_1_7_9  original_T_including_depot_unload_1266  360
    service_1_7_10  unique_nonzero_owner_374  1
    service_1_7_10  service_visit_def_1224  1
    service_1_7_10  free_load_conservation_1225  -2
    service_1_7_10  original_T_including_depot_unload_1266  240
    service_1_7_11  unique_nonzero_owner_375  1
    service_1_7_11  service_visit_def_1224  1
    service_1_7_11  free_load_conservation_1225  -1
    service_1_7_11  original_T_including_depot_unload_1266  120
    service_1_7_13  unique_nonzero_owner_376  1
    service_1_7_13  service_visit_def_1224  1
    service_1_7_13  free_load_conservation_1225  1
    service_1_7_14  unique_nonzero_owner_377  1
    service_1_7_14  service_visit_def_1224  1
    service_1_7_14  free_load_conservation_1225  2
    service_1_7_15  unique_nonzero_owner_378  1
    service_1_7_15  service_visit_def_1224  1
    service_1_7_15  free_load_conservation_1225  3
    service_1_7_16  unique_nonzero_owner_379  1
    service_1_7_16  service_visit_def_1224  1
    service_1_7_16  free_load_conservation_1225  4
    service_1_7_17  unique_nonzero_owner_380  1
    service_1_7_17  service_visit_def_1224  1
    service_1_7_17  free_load_conservation_1225  5
    service_2_7_0  unique_nonzero_owner_364  1
    service_2_7_0  service_visit_def_1543  1
    service_2_7_0  free_load_conservation_1544  -12
    service_2_7_0  original_T_including_depot_unload_1583  1440
    service_2_7_1  unique_nonzero_owner_365  1
    service_2_7_1  service_visit_def_1543  1
    service_2_7_1  free_load_conservation_1544  -11
    service_2_7_1  original_T_including_depot_unload_1583  1320
    service_2_7_2  unique_nonzero_owner_366  1
    service_2_7_2  service_visit_def_1543  1
    service_2_7_2  free_load_conservation_1544  -10
    service_2_7_2  original_T_including_depot_unload_1583  1200
    service_2_7_3  unique_nonzero_owner_367  1
    service_2_7_3  service_visit_def_1543  1
    service_2_7_3  free_load_conservation_1544  -9
    service_2_7_3  original_T_including_depot_unload_1583  1080
    service_2_7_4  unique_nonzero_owner_368  1
    service_2_7_4  service_visit_def_1543  1
    service_2_7_4  free_load_conservation_1544  -8
    service_2_7_4  original_T_including_depot_unload_1583  960
    service_2_7_5  unique_nonzero_owner_369  1
    service_2_7_5  service_visit_def_1543  1
    service_2_7_5  free_load_conservation_1544  -7
    service_2_7_5  original_T_including_depot_unload_1583  840
    service_2_7_6  unique_nonzero_owner_370  1
    service_2_7_6  service_visit_def_1543  1
    service_2_7_6  free_load_conservation_1544  -6
    service_2_7_6  original_T_including_depot_unload_1583  720
    service_2_7_7  unique_nonzero_owner_371  1
    service_2_7_7  service_visit_def_1543  1
    service_2_7_7  free_load_conservation_1544  -5
    service_2_7_7  original_T_including_depot_unload_1583  600
    service_2_7_8  unique_nonzero_owner_372  1
    service_2_7_8  service_visit_def_1543  1
    service_2_7_8  free_load_conservation_1544  -4
    service_2_7_8  original_T_including_depot_unload_1583  480
    service_2_7_9  unique_nonzero_owner_373  1
    service_2_7_9  service_visit_def_1543  1
    service_2_7_9  free_load_conservation_1544  -3
    service_2_7_9  original_T_including_depot_unload_1583  360
    service_2_7_10  unique_nonzero_owner_374  1
    service_2_7_10  service_visit_def_1543  1
    service_2_7_10  free_load_conservation_1544  -2
    service_2_7_10  original_T_including_depot_unload_1583  240
    service_2_7_11  unique_nonzero_owner_375  1
    service_2_7_11  service_visit_def_1543  1
    service_2_7_11  free_load_conservation_1544  -1
    service_2_7_11  original_T_including_depot_unload_1583  120
    service_2_7_13  unique_nonzero_owner_376  1
    service_2_7_13  service_visit_def_1543  1
    service_2_7_13  free_load_conservation_1544  1
    service_2_7_14  unique_nonzero_owner_377  1
    service_2_7_14  service_visit_def_1543  1
    service_2_7_14  free_load_conservation_1544  2
    service_2_7_15  unique_nonzero_owner_378  1
    service_2_7_15  service_visit_def_1543  1
    service_2_7_15  free_load_conservation_1544  3
    service_2_7_16  unique_nonzero_owner_379  1
    service_2_7_16  service_visit_def_1543  1
    service_2_7_16  free_load_conservation_1544  4
    service_2_7_17  unique_nonzero_owner_380  1
    service_2_7_17  service_visit_def_1543  1
    service_2_7_17  free_load_conservation_1544  5
    service_0_31_0  unique_nonzero_owner_381  1
    service_0_31_0  service_visit_def_802  1
    service_0_31_0  free_load_conservation_803  -2
    service_0_31_0  original_T_including_depot_unload_837  240
    service_0_31_1  unique_nonzero_owner_382  1
    service_0_31_1  service_visit_def_802  1
    service_0_31_1  free_load_conservation_803  -1
    service_0_31_1  original_T_including_depot_unload_837  120
    service_0_31_3  unique_nonzero_owner_383  1
    service_0_31_3  service_visit_def_802  1
    service_0_31_3  free_load_conservation_803  1
    service_0_31_4  unique_nonzero_owner_384  1
    service_0_31_4  service_visit_def_802  1
    service_0_31_4  free_load_conservation_803  2
    service_0_31_5  unique_nonzero_owner_385  1
    service_0_31_5  service_visit_def_802  1
    service_0_31_5  free_load_conservation_803  3
    service_0_31_6  unique_nonzero_owner_386  1
    service_0_31_6  service_visit_def_802  1
    service_0_31_6  free_load_conservation_803  4
    service_0_31_7  unique_nonzero_owner_387  1
    service_0_31_7  service_visit_def_802  1
    service_0_31_7  free_load_conservation_803  5
    service_0_31_8  unique_nonzero_owner_388  1
    service_0_31_8  service_visit_def_802  1
    service_0_31_8  free_load_conservation_803  6
    service_0_31_9  unique_nonzero_owner_389  1
    service_0_31_9  service_visit_def_802  1
    service_0_31_9  free_load_conservation_803  7
    service_0_31_10  unique_nonzero_owner_390  1
    service_0_31_10  service_visit_def_802  1
    service_0_31_10  free_load_conservation_803  8
    service_0_31_11  unique_nonzero_owner_391  1
    service_0_31_11  service_visit_def_802  1
    service_0_31_11  free_load_conservation_803  9
    service_0_31_12  unique_nonzero_owner_392  1
    service_0_31_12  service_visit_def_802  1
    service_0_31_12  free_load_conservation_803  10
    service_1_31_0  unique_nonzero_owner_381  1
    service_1_31_0  service_visit_def_1230  1
    service_1_31_0  free_load_conservation_1231  -2
    service_1_31_0  original_T_including_depot_unload_1266  240
    service_1_31_1  unique_nonzero_owner_382  1
    service_1_31_1  service_visit_def_1230  1
    service_1_31_1  free_load_conservation_1231  -1
    service_1_31_1  original_T_including_depot_unload_1266  120
    service_1_31_3  unique_nonzero_owner_383  1
    service_1_31_3  service_visit_def_1230  1
    service_1_31_3  free_load_conservation_1231  1
    service_1_31_4  unique_nonzero_owner_384  1
    service_1_31_4  service_visit_def_1230  1
    service_1_31_4  free_load_conservation_1231  2
    service_1_31_5  unique_nonzero_owner_385  1
    service_1_31_5  service_visit_def_1230  1
    service_1_31_5  free_load_conservation_1231  3
    service_1_31_6  unique_nonzero_owner_386  1
    service_1_31_6  service_visit_def_1230  1
    service_1_31_6  free_load_conservation_1231  4
    service_1_31_7  unique_nonzero_owner_387  1
    service_1_31_7  service_visit_def_1230  1
    service_1_31_7  free_load_conservation_1231  5
    service_1_31_8  unique_nonzero_owner_388  1
    service_1_31_8  service_visit_def_1230  1
    service_1_31_8  free_load_conservation_1231  6
    service_1_31_9  unique_nonzero_owner_389  1
    service_1_31_9  service_visit_def_1230  1
    service_1_31_9  free_load_conservation_1231  7
    service_1_31_10  unique_nonzero_owner_390  1
    service_1_31_10  service_visit_def_1230  1
    service_1_31_10  free_load_conservation_1231  8
    service_1_31_11  unique_nonzero_owner_391  1
    service_1_31_11  service_visit_def_1230  1
    service_1_31_11  free_load_conservation_1231  9
    service_1_31_12  unique_nonzero_owner_392  1
    service_1_31_12  service_visit_def_1230  1
    service_1_31_12  free_load_conservation_1231  10
    service_2_31_0  unique_nonzero_owner_381  1
    service_2_31_0  service_visit_def_1549  1
    service_2_31_0  free_load_conservation_1550  -2
    service_2_31_0  original_T_including_depot_unload_1583  240
    service_2_31_1  unique_nonzero_owner_382  1
    service_2_31_1  service_visit_def_1549  1
    service_2_31_1  free_load_conservation_1550  -1
    service_2_31_1  original_T_including_depot_unload_1583  120
    service_2_31_3  unique_nonzero_owner_383  1
    service_2_31_3  service_visit_def_1549  1
    service_2_31_3  free_load_conservation_1550  1
    service_2_31_4  unique_nonzero_owner_384  1
    service_2_31_4  service_visit_def_1549  1
    service_2_31_4  free_load_conservation_1550  2
    service_2_31_5  unique_nonzero_owner_385  1
    service_2_31_5  service_visit_def_1549  1
    service_2_31_5  free_load_conservation_1550  3
    service_2_31_6  unique_nonzero_owner_386  1
    service_2_31_6  service_visit_def_1549  1
    service_2_31_6  free_load_conservation_1550  4
    service_2_31_7  unique_nonzero_owner_387  1
    service_2_31_7  service_visit_def_1549  1
    service_2_31_7  free_load_conservation_1550  5
    service_2_31_8  unique_nonzero_owner_388  1
    service_2_31_8  service_visit_def_1549  1
    service_2_31_8  free_load_conservation_1550  6
    service_2_31_9  unique_nonzero_owner_389  1
    service_2_31_9  service_visit_def_1549  1
    service_2_31_9  free_load_conservation_1550  7
    service_2_31_10  unique_nonzero_owner_390  1
    service_2_31_10  service_visit_def_1549  1
    service_2_31_10  free_load_conservation_1550  8
    service_2_31_11  unique_nonzero_owner_391  1
    service_2_31_11  service_visit_def_1549  1
    service_2_31_11  free_load_conservation_1550  9
    service_2_31_12  unique_nonzero_owner_392  1
    service_2_31_12  service_visit_def_1549  1
    service_2_31_12  free_load_conservation_1550  10
    service_0_3_0  unique_nonzero_owner_393  1
    service_0_3_0  service_visit_def_808  1
    service_0_3_0  free_load_conservation_809  -12
    service_0_3_0  original_T_including_depot_unload_837  1440
    service_0_3_1  unique_nonzero_owner_394  1
    service_0_3_1  service_visit_def_808  1
    service_0_3_1  free_load_conservation_809  -11
    service_0_3_1  original_T_including_depot_unload_837  1320
    service_0_3_2  unique_nonzero_owner_395  1
    service_0_3_2  service_visit_def_808  1
    service_0_3_2  free_load_conservation_809  -10
    service_0_3_2  original_T_including_depot_unload_837  1200
    service_0_3_3  unique_nonzero_owner_396  1
    service_0_3_3  service_visit_def_808  1
    service_0_3_3  free_load_conservation_809  -9
    service_0_3_3  original_T_including_depot_unload_837  1080
    service_0_3_4  unique_nonzero_owner_397  1
    service_0_3_4  service_visit_def_808  1
    service_0_3_4  free_load_conservation_809  -8
    service_0_3_4  original_T_including_depot_unload_837  960
    service_0_3_5  unique_nonzero_owner_398  1
    service_0_3_5  service_visit_def_808  1
    service_0_3_5  free_load_conservation_809  -7
    service_0_3_5  original_T_including_depot_unload_837  840
    service_0_3_6  unique_nonzero_owner_399  1
    service_0_3_6  service_visit_def_808  1
    service_0_3_6  free_load_conservation_809  -6
    service_0_3_6  original_T_including_depot_unload_837  720
    service_0_3_7  unique_nonzero_owner_400  1
    service_0_3_7  service_visit_def_808  1
    service_0_3_7  free_load_conservation_809  -5
    service_0_3_7  original_T_including_depot_unload_837  600
    service_0_3_8  unique_nonzero_owner_401  1
    service_0_3_8  service_visit_def_808  1
    service_0_3_8  free_load_conservation_809  -4
    service_0_3_8  original_T_including_depot_unload_837  480
    service_0_3_9  unique_nonzero_owner_402  1
    service_0_3_9  service_visit_def_808  1
    service_0_3_9  free_load_conservation_809  -3
    service_0_3_9  original_T_including_depot_unload_837  360
    service_0_3_10  unique_nonzero_owner_403  1
    service_0_3_10  service_visit_def_808  1
    service_0_3_10  free_load_conservation_809  -2
    service_0_3_10  original_T_including_depot_unload_837  240
    service_0_3_11  unique_nonzero_owner_404  1
    service_0_3_11  service_visit_def_808  1
    service_0_3_11  free_load_conservation_809  -1
    service_0_3_11  original_T_including_depot_unload_837  120
    service_0_3_13  unique_nonzero_owner_405  1
    service_0_3_13  service_visit_def_808  1
    service_0_3_13  free_load_conservation_809  1
    service_0_3_14  unique_nonzero_owner_406  1
    service_0_3_14  service_visit_def_808  1
    service_0_3_14  free_load_conservation_809  2
    service_0_3_15  unique_nonzero_owner_407  1
    service_0_3_15  service_visit_def_808  1
    service_0_3_15  free_load_conservation_809  3
    service_0_3_16  unique_nonzero_owner_408  1
    service_0_3_16  service_visit_def_808  1
    service_0_3_16  free_load_conservation_809  4
    service_0_3_17  unique_nonzero_owner_409  1
    service_0_3_17  service_visit_def_808  1
    service_0_3_17  free_load_conservation_809  5
    service_1_3_0  unique_nonzero_owner_393  1
    service_1_3_0  service_visit_def_1236  1
    service_1_3_0  free_load_conservation_1237  -12
    service_1_3_0  original_T_including_depot_unload_1266  1440
    service_1_3_1  unique_nonzero_owner_394  1
    service_1_3_1  service_visit_def_1236  1
    service_1_3_1  free_load_conservation_1237  -11
    service_1_3_1  original_T_including_depot_unload_1266  1320
    service_1_3_2  unique_nonzero_owner_395  1
    service_1_3_2  service_visit_def_1236  1
    service_1_3_2  free_load_conservation_1237  -10
    service_1_3_2  original_T_including_depot_unload_1266  1200
    service_1_3_3  unique_nonzero_owner_396  1
    service_1_3_3  service_visit_def_1236  1
    service_1_3_3  free_load_conservation_1237  -9
    service_1_3_3  original_T_including_depot_unload_1266  1080
    service_1_3_4  unique_nonzero_owner_397  1
    service_1_3_4  service_visit_def_1236  1
    service_1_3_4  free_load_conservation_1237  -8
    service_1_3_4  original_T_including_depot_unload_1266  960
    service_1_3_5  unique_nonzero_owner_398  1
    service_1_3_5  service_visit_def_1236  1
    service_1_3_5  free_load_conservation_1237  -7
    service_1_3_5  original_T_including_depot_unload_1266  840
    service_1_3_6  unique_nonzero_owner_399  1
    service_1_3_6  service_visit_def_1236  1
    service_1_3_6  free_load_conservation_1237  -6
    service_1_3_6  original_T_including_depot_unload_1266  720
    service_1_3_7  unique_nonzero_owner_400  1
    service_1_3_7  service_visit_def_1236  1
    service_1_3_7  free_load_conservation_1237  -5
    service_1_3_7  original_T_including_depot_unload_1266  600
    service_1_3_8  unique_nonzero_owner_401  1
    service_1_3_8  service_visit_def_1236  1
    service_1_3_8  free_load_conservation_1237  -4
    service_1_3_8  original_T_including_depot_unload_1266  480
    service_1_3_9  unique_nonzero_owner_402  1
    service_1_3_9  service_visit_def_1236  1
    service_1_3_9  free_load_conservation_1237  -3
    service_1_3_9  original_T_including_depot_unload_1266  360
    service_1_3_10  unique_nonzero_owner_403  1
    service_1_3_10  service_visit_def_1236  1
    service_1_3_10  free_load_conservation_1237  -2
    service_1_3_10  original_T_including_depot_unload_1266  240
    service_1_3_11  unique_nonzero_owner_404  1
    service_1_3_11  service_visit_def_1236  1
    service_1_3_11  free_load_conservation_1237  -1
    service_1_3_11  original_T_including_depot_unload_1266  120
    service_1_3_13  unique_nonzero_owner_405  1
    service_1_3_13  service_visit_def_1236  1
    service_1_3_13  free_load_conservation_1237  1
    service_1_3_14  unique_nonzero_owner_406  1
    service_1_3_14  service_visit_def_1236  1
    service_1_3_14  free_load_conservation_1237  2
    service_1_3_15  unique_nonzero_owner_407  1
    service_1_3_15  service_visit_def_1236  1
    service_1_3_15  free_load_conservation_1237  3
    service_1_3_16  unique_nonzero_owner_408  1
    service_1_3_16  service_visit_def_1236  1
    service_1_3_16  free_load_conservation_1237  4
    service_1_3_17  unique_nonzero_owner_409  1
    service_1_3_17  service_visit_def_1236  1
    service_1_3_17  free_load_conservation_1237  5
    service_2_3_0  unique_nonzero_owner_393  1
    service_2_3_0  service_visit_def_1555  1
    service_2_3_0  free_load_conservation_1556  -12
    service_2_3_0  original_T_including_depot_unload_1583  1440
    service_2_3_1  unique_nonzero_owner_394  1
    service_2_3_1  service_visit_def_1555  1
    service_2_3_1  free_load_conservation_1556  -11
    service_2_3_1  original_T_including_depot_unload_1583  1320
    service_2_3_2  unique_nonzero_owner_395  1
    service_2_3_2  service_visit_def_1555  1
    service_2_3_2  free_load_conservation_1556  -10
    service_2_3_2  original_T_including_depot_unload_1583  1200
    service_2_3_3  unique_nonzero_owner_396  1
    service_2_3_3  service_visit_def_1555  1
    service_2_3_3  free_load_conservation_1556  -9
    service_2_3_3  original_T_including_depot_unload_1583  1080
    service_2_3_4  unique_nonzero_owner_397  1
    service_2_3_4  service_visit_def_1555  1
    service_2_3_4  free_load_conservation_1556  -8
    service_2_3_4  original_T_including_depot_unload_1583  960
    service_2_3_5  unique_nonzero_owner_398  1
    service_2_3_5  service_visit_def_1555  1
    service_2_3_5  free_load_conservation_1556  -7
    service_2_3_5  original_T_including_depot_unload_1583  840
    service_2_3_6  unique_nonzero_owner_399  1
    service_2_3_6  service_visit_def_1555  1
    service_2_3_6  free_load_conservation_1556  -6
    service_2_3_6  original_T_including_depot_unload_1583  720
    service_2_3_7  unique_nonzero_owner_400  1
    service_2_3_7  service_visit_def_1555  1
    service_2_3_7  free_load_conservation_1556  -5
    service_2_3_7  original_T_including_depot_unload_1583  600
    service_2_3_8  unique_nonzero_owner_401  1
    service_2_3_8  service_visit_def_1555  1
    service_2_3_8  free_load_conservation_1556  -4
    service_2_3_8  original_T_including_depot_unload_1583  480
    service_2_3_9  unique_nonzero_owner_402  1
    service_2_3_9  service_visit_def_1555  1
    service_2_3_9  free_load_conservation_1556  -3
    service_2_3_9  original_T_including_depot_unload_1583  360
    service_2_3_10  unique_nonzero_owner_403  1
    service_2_3_10  service_visit_def_1555  1
    service_2_3_10  free_load_conservation_1556  -2
    service_2_3_10  original_T_including_depot_unload_1583  240
    service_2_3_11  unique_nonzero_owner_404  1
    service_2_3_11  service_visit_def_1555  1
    service_2_3_11  free_load_conservation_1556  -1
    service_2_3_11  original_T_including_depot_unload_1583  120
    service_2_3_13  unique_nonzero_owner_405  1
    service_2_3_13  service_visit_def_1555  1
    service_2_3_13  free_load_conservation_1556  1
    service_2_3_14  unique_nonzero_owner_406  1
    service_2_3_14  service_visit_def_1555  1
    service_2_3_14  free_load_conservation_1556  2
    service_2_3_15  unique_nonzero_owner_407  1
    service_2_3_15  service_visit_def_1555  1
    service_2_3_15  free_load_conservation_1556  3
    service_2_3_16  unique_nonzero_owner_408  1
    service_2_3_16  service_visit_def_1555  1
    service_2_3_16  free_load_conservation_1556  4
    service_2_3_17  unique_nonzero_owner_409  1
    service_2_3_17  service_visit_def_1555  1
    service_2_3_17  free_load_conservation_1556  5
    service_0_14_0  unique_nonzero_owner_410  1
    service_0_14_0  service_visit_def_814  1
    service_0_14_0  free_load_conservation_815  -2
    service_0_14_0  original_T_including_depot_unload_837  240
    service_0_14_1  unique_nonzero_owner_411  1
    service_0_14_1  service_visit_def_814  1
    service_0_14_1  free_load_conservation_815  -1
    service_0_14_1  original_T_including_depot_unload_837  120
    service_0_14_3  unique_nonzero_owner_412  1
    service_0_14_3  service_visit_def_814  1
    service_0_14_3  free_load_conservation_815  1
    service_0_14_4  unique_nonzero_owner_413  1
    service_0_14_4  service_visit_def_814  1
    service_0_14_4  free_load_conservation_815  2
    service_0_14_5  unique_nonzero_owner_414  1
    service_0_14_5  service_visit_def_814  1
    service_0_14_5  free_load_conservation_815  3
    service_0_14_6  unique_nonzero_owner_415  1
    service_0_14_6  service_visit_def_814  1
    service_0_14_6  free_load_conservation_815  4
    service_0_14_7  unique_nonzero_owner_416  1
    service_0_14_7  service_visit_def_814  1
    service_0_14_7  free_load_conservation_815  5
    service_0_14_8  unique_nonzero_owner_417  1
    service_0_14_8  service_visit_def_814  1
    service_0_14_8  free_load_conservation_815  6
    service_0_14_9  unique_nonzero_owner_418  1
    service_0_14_9  service_visit_def_814  1
    service_0_14_9  free_load_conservation_815  7
    service_0_14_10  unique_nonzero_owner_419  1
    service_0_14_10  service_visit_def_814  1
    service_0_14_10  free_load_conservation_815  8
    service_0_14_11  unique_nonzero_owner_420  1
    service_0_14_11  service_visit_def_814  1
    service_0_14_11  free_load_conservation_815  9
    service_0_14_12  unique_nonzero_owner_421  1
    service_0_14_12  service_visit_def_814  1
    service_0_14_12  free_load_conservation_815  10
    service_0_14_13  unique_nonzero_owner_422  1
    service_0_14_13  service_visit_def_814  1
    service_0_14_13  free_load_conservation_815  11
    service_0_14_14  unique_nonzero_owner_423  1
    service_0_14_14  service_visit_def_814  1
    service_0_14_14  free_load_conservation_815  12
    service_0_14_15  unique_nonzero_owner_424  1
    service_0_14_15  service_visit_def_814  1
    service_0_14_15  free_load_conservation_815  13
    service_1_14_0  unique_nonzero_owner_410  1
    service_1_14_0  service_visit_def_1242  1
    service_1_14_0  free_load_conservation_1243  -2
    service_1_14_0  original_T_including_depot_unload_1266  240
    service_1_14_1  unique_nonzero_owner_411  1
    service_1_14_1  service_visit_def_1242  1
    service_1_14_1  free_load_conservation_1243  -1
    service_1_14_1  original_T_including_depot_unload_1266  120
    service_1_14_3  unique_nonzero_owner_412  1
    service_1_14_3  service_visit_def_1242  1
    service_1_14_3  free_load_conservation_1243  1
    service_1_14_4  unique_nonzero_owner_413  1
    service_1_14_4  service_visit_def_1242  1
    service_1_14_4  free_load_conservation_1243  2
    service_1_14_5  unique_nonzero_owner_414  1
    service_1_14_5  service_visit_def_1242  1
    service_1_14_5  free_load_conservation_1243  3
    service_1_14_6  unique_nonzero_owner_415  1
    service_1_14_6  service_visit_def_1242  1
    service_1_14_6  free_load_conservation_1243  4
    service_1_14_7  unique_nonzero_owner_416  1
    service_1_14_7  service_visit_def_1242  1
    service_1_14_7  free_load_conservation_1243  5
    service_1_14_8  unique_nonzero_owner_417  1
    service_1_14_8  service_visit_def_1242  1
    service_1_14_8  free_load_conservation_1243  6
    service_1_14_9  unique_nonzero_owner_418  1
    service_1_14_9  service_visit_def_1242  1
    service_1_14_9  free_load_conservation_1243  7
    service_1_14_10  unique_nonzero_owner_419  1
    service_1_14_10  service_visit_def_1242  1
    service_1_14_10  free_load_conservation_1243  8
    service_1_14_11  unique_nonzero_owner_420  1
    service_1_14_11  service_visit_def_1242  1
    service_1_14_11  free_load_conservation_1243  9
    service_1_14_12  unique_nonzero_owner_421  1
    service_1_14_12  service_visit_def_1242  1
    service_1_14_12  free_load_conservation_1243  10
    service_1_14_13  unique_nonzero_owner_422  1
    service_1_14_13  service_visit_def_1242  1
    service_1_14_13  free_load_conservation_1243  11
    service_1_14_14  unique_nonzero_owner_423  1
    service_1_14_14  service_visit_def_1242  1
    service_1_14_14  free_load_conservation_1243  12
    service_1_14_15  unique_nonzero_owner_424  1
    service_1_14_15  service_visit_def_1242  1
    service_1_14_15  free_load_conservation_1243  13
    service_2_14_0  unique_nonzero_owner_410  1
    service_2_14_0  service_visit_def_1561  1
    service_2_14_0  free_load_conservation_1562  -2
    service_2_14_0  original_T_including_depot_unload_1583  240
    service_2_14_1  unique_nonzero_owner_411  1
    service_2_14_1  service_visit_def_1561  1
    service_2_14_1  free_load_conservation_1562  -1
    service_2_14_1  original_T_including_depot_unload_1583  120
    service_2_14_3  unique_nonzero_owner_412  1
    service_2_14_3  service_visit_def_1561  1
    service_2_14_3  free_load_conservation_1562  1
    service_2_14_4  unique_nonzero_owner_413  1
    service_2_14_4  service_visit_def_1561  1
    service_2_14_4  free_load_conservation_1562  2
    service_2_14_5  unique_nonzero_owner_414  1
    service_2_14_5  service_visit_def_1561  1
    service_2_14_5  free_load_conservation_1562  3
    service_2_14_6  unique_nonzero_owner_415  1
    service_2_14_6  service_visit_def_1561  1
    service_2_14_6  free_load_conservation_1562  4
    service_2_14_7  unique_nonzero_owner_416  1
    service_2_14_7  service_visit_def_1561  1
    service_2_14_7  free_load_conservation_1562  5
    service_2_14_8  unique_nonzero_owner_417  1
    service_2_14_8  service_visit_def_1561  1
    service_2_14_8  free_load_conservation_1562  6
    service_2_14_9  unique_nonzero_owner_418  1
    service_2_14_9  service_visit_def_1561  1
    service_2_14_9  free_load_conservation_1562  7
    service_2_14_10  unique_nonzero_owner_419  1
    service_2_14_10  service_visit_def_1561  1
    service_2_14_10  free_load_conservation_1562  8
    service_2_14_11  unique_nonzero_owner_420  1
    service_2_14_11  service_visit_def_1561  1
    service_2_14_11  free_load_conservation_1562  9
    service_2_14_12  unique_nonzero_owner_421  1
    service_2_14_12  service_visit_def_1561  1
    service_2_14_12  free_load_conservation_1562  10
    service_2_14_13  unique_nonzero_owner_422  1
    service_2_14_13  service_visit_def_1561  1
    service_2_14_13  free_load_conservation_1562  11
    service_2_14_14  unique_nonzero_owner_423  1
    service_2_14_14  service_visit_def_1561  1
    service_2_14_14  free_load_conservation_1562  12
    service_2_14_15  unique_nonzero_owner_424  1
    service_2_14_15  service_visit_def_1561  1
    service_2_14_15  free_load_conservation_1562  13
    service_0_11_0  unique_nonzero_owner_425  1
    service_0_11_0  service_visit_def_820  1
    service_0_11_0  free_load_conservation_821  -7
    service_0_11_0  original_T_including_depot_unload_837  840
    service_0_11_1  unique_nonzero_owner_426  1
    service_0_11_1  service_visit_def_820  1
    service_0_11_1  free_load_conservation_821  -6
    service_0_11_1  original_T_including_depot_unload_837  720
    service_0_11_2  unique_nonzero_owner_427  1
    service_0_11_2  service_visit_def_820  1
    service_0_11_2  free_load_conservation_821  -5
    service_0_11_2  original_T_including_depot_unload_837  600
    service_0_11_3  unique_nonzero_owner_428  1
    service_0_11_3  service_visit_def_820  1
    service_0_11_3  free_load_conservation_821  -4
    service_0_11_3  original_T_including_depot_unload_837  480
    service_0_11_4  unique_nonzero_owner_429  1
    service_0_11_4  service_visit_def_820  1
    service_0_11_4  free_load_conservation_821  -3
    service_0_11_4  original_T_including_depot_unload_837  360
    service_0_11_5  unique_nonzero_owner_430  1
    service_0_11_5  service_visit_def_820  1
    service_0_11_5  free_load_conservation_821  -2
    service_0_11_5  original_T_including_depot_unload_837  240
    service_0_11_6  unique_nonzero_owner_431  1
    service_0_11_6  service_visit_def_820  1
    service_0_11_6  free_load_conservation_821  -1
    service_0_11_6  original_T_including_depot_unload_837  120
    service_0_11_8  unique_nonzero_owner_432  1
    service_0_11_8  service_visit_def_820  1
    service_0_11_8  free_load_conservation_821  1
    service_0_11_9  unique_nonzero_owner_433  1
    service_0_11_9  service_visit_def_820  1
    service_0_11_9  free_load_conservation_821  2
    service_0_11_10  unique_nonzero_owner_434  1
    service_0_11_10  service_visit_def_820  1
    service_0_11_10  free_load_conservation_821  3
    service_0_11_11  unique_nonzero_owner_435  1
    service_0_11_11  service_visit_def_820  1
    service_0_11_11  free_load_conservation_821  4
    service_0_11_12  unique_nonzero_owner_436  1
    service_0_11_12  service_visit_def_820  1
    service_0_11_12  free_load_conservation_821  5
    service_1_11_0  unique_nonzero_owner_425  1
    service_1_11_0  service_visit_def_1248  1
    service_1_11_0  free_load_conservation_1249  -7
    service_1_11_0  original_T_including_depot_unload_1266  840
    service_1_11_1  unique_nonzero_owner_426  1
    service_1_11_1  service_visit_def_1248  1
    service_1_11_1  free_load_conservation_1249  -6
    service_1_11_1  original_T_including_depot_unload_1266  720
    service_1_11_2  unique_nonzero_owner_427  1
    service_1_11_2  service_visit_def_1248  1
    service_1_11_2  free_load_conservation_1249  -5
    service_1_11_2  original_T_including_depot_unload_1266  600
    service_1_11_3  unique_nonzero_owner_428  1
    service_1_11_3  service_visit_def_1248  1
    service_1_11_3  free_load_conservation_1249  -4
    service_1_11_3  original_T_including_depot_unload_1266  480
    service_1_11_4  unique_nonzero_owner_429  1
    service_1_11_4  service_visit_def_1248  1
    service_1_11_4  free_load_conservation_1249  -3
    service_1_11_4  original_T_including_depot_unload_1266  360
    service_1_11_5  unique_nonzero_owner_430  1
    service_1_11_5  service_visit_def_1248  1
    service_1_11_5  free_load_conservation_1249  -2
    service_1_11_5  original_T_including_depot_unload_1266  240
    service_1_11_6  unique_nonzero_owner_431  1
    service_1_11_6  service_visit_def_1248  1
    service_1_11_6  free_load_conservation_1249  -1
    service_1_11_6  original_T_including_depot_unload_1266  120
    service_1_11_8  unique_nonzero_owner_432  1
    service_1_11_8  service_visit_def_1248  1
    service_1_11_8  free_load_conservation_1249  1
    service_1_11_9  unique_nonzero_owner_433  1
    service_1_11_9  service_visit_def_1248  1
    service_1_11_9  free_load_conservation_1249  2
    service_1_11_10  unique_nonzero_owner_434  1
    service_1_11_10  service_visit_def_1248  1
    service_1_11_10  free_load_conservation_1249  3
    service_1_11_11  unique_nonzero_owner_435  1
    service_1_11_11  service_visit_def_1248  1
    service_1_11_11  free_load_conservation_1249  4
    service_1_11_12  unique_nonzero_owner_436  1
    service_1_11_12  service_visit_def_1248  1
    service_1_11_12  free_load_conservation_1249  5
    service_2_11_0  unique_nonzero_owner_425  1
    service_2_11_0  service_visit_def_1567  1
    service_2_11_0  free_load_conservation_1568  -7
    service_2_11_0  original_T_including_depot_unload_1583  840
    service_2_11_1  unique_nonzero_owner_426  1
    service_2_11_1  service_visit_def_1567  1
    service_2_11_1  free_load_conservation_1568  -6
    service_2_11_1  original_T_including_depot_unload_1583  720
    service_2_11_2  unique_nonzero_owner_427  1
    service_2_11_2  service_visit_def_1567  1
    service_2_11_2  free_load_conservation_1568  -5
    service_2_11_2  original_T_including_depot_unload_1583  600
    service_2_11_3  unique_nonzero_owner_428  1
    service_2_11_3  service_visit_def_1567  1
    service_2_11_3  free_load_conservation_1568  -4
    service_2_11_3  original_T_including_depot_unload_1583  480
    service_2_11_4  unique_nonzero_owner_429  1
    service_2_11_4  service_visit_def_1567  1
    service_2_11_4  free_load_conservation_1568  -3
    service_2_11_4  original_T_including_depot_unload_1583  360
    service_2_11_5  unique_nonzero_owner_430  1
    service_2_11_5  service_visit_def_1567  1
    service_2_11_5  free_load_conservation_1568  -2
    service_2_11_5  original_T_including_depot_unload_1583  240
    service_2_11_6  unique_nonzero_owner_431  1
    service_2_11_6  service_visit_def_1567  1
    service_2_11_6  free_load_conservation_1568  -1
    service_2_11_6  original_T_including_depot_unload_1583  120
    service_2_11_8  unique_nonzero_owner_432  1
    service_2_11_8  service_visit_def_1567  1
    service_2_11_8  free_load_conservation_1568  1
    service_2_11_9  unique_nonzero_owner_433  1
    service_2_11_9  service_visit_def_1567  1
    service_2_11_9  free_load_conservation_1568  2
    service_2_11_10  unique_nonzero_owner_434  1
    service_2_11_10  service_visit_def_1567  1
    service_2_11_10  free_load_conservation_1568  3
    service_2_11_11  unique_nonzero_owner_435  1
    service_2_11_11  service_visit_def_1567  1
    service_2_11_11  free_load_conservation_1568  4
    service_2_11_12  unique_nonzero_owner_436  1
    service_2_11_12  service_visit_def_1567  1
    service_2_11_12  free_load_conservation_1568  5
    service_0_2_1  unique_nonzero_owner_437  1
    service_0_2_1  service_visit_def_826  1
    service_0_2_1  free_load_conservation_827  1
    service_0_2_2  unique_nonzero_owner_438  1
    service_0_2_2  service_visit_def_826  1
    service_0_2_2  free_load_conservation_827  2
    service_0_2_3  unique_nonzero_owner_439  1
    service_0_2_3  service_visit_def_826  1
    service_0_2_3  free_load_conservation_827  3
    service_0_2_4  unique_nonzero_owner_440  1
    service_0_2_4  service_visit_def_826  1
    service_0_2_4  free_load_conservation_827  4
    service_0_2_5  unique_nonzero_owner_441  1
    service_0_2_5  service_visit_def_826  1
    service_0_2_5  free_load_conservation_827  5
    service_0_2_6  unique_nonzero_owner_442  1
    service_0_2_6  service_visit_def_826  1
    service_0_2_6  free_load_conservation_827  6
    service_0_2_7  unique_nonzero_owner_443  1
    service_0_2_7  service_visit_def_826  1
    service_0_2_7  free_load_conservation_827  7
    service_0_2_8  unique_nonzero_owner_444  1
    service_0_2_8  service_visit_def_826  1
    service_0_2_8  free_load_conservation_827  8
    service_0_2_9  unique_nonzero_owner_445  1
    service_0_2_9  service_visit_def_826  1
    service_0_2_9  free_load_conservation_827  9
    service_0_2_10  unique_nonzero_owner_446  1
    service_0_2_10  service_visit_def_826  1
    service_0_2_10  free_load_conservation_827  10
    service_0_2_11  unique_nonzero_owner_447  1
    service_0_2_11  service_visit_def_826  1
    service_0_2_11  free_load_conservation_827  11
    service_0_2_12  unique_nonzero_owner_448  1
    service_0_2_12  service_visit_def_826  1
    service_0_2_12  free_load_conservation_827  12
    service_0_2_13  unique_nonzero_owner_449  1
    service_0_2_13  service_visit_def_826  1
    service_0_2_13  free_load_conservation_827  13
    service_0_2_14  unique_nonzero_owner_450  1
    service_0_2_14  service_visit_def_826  1
    service_0_2_14  free_load_conservation_827  14
    service_0_2_15  unique_nonzero_owner_451  1
    service_0_2_15  service_visit_def_826  1
    service_0_2_15  free_load_conservation_827  15
    service_1_2_1  unique_nonzero_owner_437  1
    service_1_2_1  service_visit_def_1254  1
    service_1_2_1  free_load_conservation_1255  1
    service_1_2_2  unique_nonzero_owner_438  1
    service_1_2_2  service_visit_def_1254  1
    service_1_2_2  free_load_conservation_1255  2
    service_1_2_3  unique_nonzero_owner_439  1
    service_1_2_3  service_visit_def_1254  1
    service_1_2_3  free_load_conservation_1255  3
    service_1_2_4  unique_nonzero_owner_440  1
    service_1_2_4  service_visit_def_1254  1
    service_1_2_4  free_load_conservation_1255  4
    service_1_2_5  unique_nonzero_owner_441  1
    service_1_2_5  service_visit_def_1254  1
    service_1_2_5  free_load_conservation_1255  5
    service_1_2_6  unique_nonzero_owner_442  1
    service_1_2_6  service_visit_def_1254  1
    service_1_2_6  free_load_conservation_1255  6
    service_1_2_7  unique_nonzero_owner_443  1
    service_1_2_7  service_visit_def_1254  1
    service_1_2_7  free_load_conservation_1255  7
    service_1_2_8  unique_nonzero_owner_444  1
    service_1_2_8  service_visit_def_1254  1
    service_1_2_8  free_load_conservation_1255  8
    service_1_2_9  unique_nonzero_owner_445  1
    service_1_2_9  service_visit_def_1254  1
    service_1_2_9  free_load_conservation_1255  9
    service_1_2_10  unique_nonzero_owner_446  1
    service_1_2_10  service_visit_def_1254  1
    service_1_2_10  free_load_conservation_1255  10
    service_1_2_11  unique_nonzero_owner_447  1
    service_1_2_11  service_visit_def_1254  1
    service_1_2_11  free_load_conservation_1255  11
    service_1_2_12  unique_nonzero_owner_448  1
    service_1_2_12  service_visit_def_1254  1
    service_1_2_12  free_load_conservation_1255  12
    service_1_2_13  unique_nonzero_owner_449  1
    service_1_2_13  service_visit_def_1254  1
    service_1_2_13  free_load_conservation_1255  13
    service_1_2_14  unique_nonzero_owner_450  1
    service_1_2_14  service_visit_def_1254  1
    service_1_2_14  free_load_conservation_1255  14
    service_1_2_15  unique_nonzero_owner_451  1
    service_1_2_15  service_visit_def_1254  1
    service_1_2_15  free_load_conservation_1255  15
    service_2_2_1  unique_nonzero_owner_437  1
    service_2_2_1  service_visit_def_1573  1
    service_2_2_1  free_load_conservation_1574  1
    service_2_2_2  unique_nonzero_owner_438  1
    service_2_2_2  service_visit_def_1573  1
    service_2_2_2  free_load_conservation_1574  2
    service_2_2_3  unique_nonzero_owner_439  1
    service_2_2_3  service_visit_def_1573  1
    service_2_2_3  free_load_conservation_1574  3
    service_2_2_4  unique_nonzero_owner_440  1
    service_2_2_4  service_visit_def_1573  1
    service_2_2_4  free_load_conservation_1574  4
    service_2_2_5  unique_nonzero_owner_441  1
    service_2_2_5  service_visit_def_1573  1
    service_2_2_5  free_load_conservation_1574  5
    service_2_2_6  unique_nonzero_owner_442  1
    service_2_2_6  service_visit_def_1573  1
    service_2_2_6  free_load_conservation_1574  6
    service_2_2_7  unique_nonzero_owner_443  1
    service_2_2_7  service_visit_def_1573  1
    service_2_2_7  free_load_conservation_1574  7
    service_2_2_8  unique_nonzero_owner_444  1
    service_2_2_8  service_visit_def_1573  1
    service_2_2_8  free_load_conservation_1574  8
    service_2_2_9  unique_nonzero_owner_445  1
    service_2_2_9  service_visit_def_1573  1
    service_2_2_9  free_load_conservation_1574  9
    service_2_2_10  unique_nonzero_owner_446  1
    service_2_2_10  service_visit_def_1573  1
    service_2_2_10  free_load_conservation_1574  10
    service_2_2_11  unique_nonzero_owner_447  1
    service_2_2_11  service_visit_def_1573  1
    service_2_2_11  free_load_conservation_1574  11
    service_2_2_12  unique_nonzero_owner_448  1
    service_2_2_12  service_visit_def_1573  1
    service_2_2_12  free_load_conservation_1574  12
    service_2_2_13  unique_nonzero_owner_449  1
    service_2_2_13  service_visit_def_1573  1
    service_2_2_13  free_load_conservation_1574  13
    service_2_2_14  unique_nonzero_owner_450  1
    service_2_2_14  service_visit_def_1573  1
    service_2_2_14  free_load_conservation_1574  14
    service_2_2_15  unique_nonzero_owner_451  1
    service_2_2_15  service_visit_def_1573  1
    service_2_2_15  free_load_conservation_1574  15
    service_0_4_0  unique_nonzero_owner_452  1
    service_0_4_0  service_visit_def_832  1
    service_0_4_0  free_load_conservation_833  -11
    service_0_4_0  original_T_including_depot_unload_837  1320
    service_0_4_1  unique_nonzero_owner_453  1
    service_0_4_1  service_visit_def_832  1
    service_0_4_1  free_load_conservation_833  -10
    service_0_4_1  original_T_including_depot_unload_837  1200
    service_0_4_2  unique_nonzero_owner_454  1
    service_0_4_2  service_visit_def_832  1
    service_0_4_2  free_load_conservation_833  -9
    service_0_4_2  original_T_including_depot_unload_837  1080
    service_0_4_3  unique_nonzero_owner_455  1
    service_0_4_3  service_visit_def_832  1
    service_0_4_3  free_load_conservation_833  -8
    service_0_4_3  original_T_including_depot_unload_837  960
    service_0_4_4  unique_nonzero_owner_456  1
    service_0_4_4  service_visit_def_832  1
    service_0_4_4  free_load_conservation_833  -7
    service_0_4_4  original_T_including_depot_unload_837  840
    service_0_4_5  unique_nonzero_owner_457  1
    service_0_4_5  service_visit_def_832  1
    service_0_4_5  free_load_conservation_833  -6
    service_0_4_5  original_T_including_depot_unload_837  720
    service_0_4_6  unique_nonzero_owner_458  1
    service_0_4_6  service_visit_def_832  1
    service_0_4_6  free_load_conservation_833  -5
    service_0_4_6  original_T_including_depot_unload_837  600
    service_0_4_7  unique_nonzero_owner_459  1
    service_0_4_7  service_visit_def_832  1
    service_0_4_7  free_load_conservation_833  -4
    service_0_4_7  original_T_including_depot_unload_837  480
    service_0_4_8  unique_nonzero_owner_460  1
    service_0_4_8  service_visit_def_832  1
    service_0_4_8  free_load_conservation_833  -3
    service_0_4_8  original_T_including_depot_unload_837  360
    service_0_4_9  unique_nonzero_owner_461  1
    service_0_4_9  service_visit_def_832  1
    service_0_4_9  free_load_conservation_833  -2
    service_0_4_9  original_T_including_depot_unload_837  240
    service_0_4_10  unique_nonzero_owner_462  1
    service_0_4_10  service_visit_def_832  1
    service_0_4_10  free_load_conservation_833  -1
    service_0_4_10  original_T_including_depot_unload_837  120
    service_0_4_12  unique_nonzero_owner_463  1
    service_0_4_12  service_visit_def_832  1
    service_0_4_12  free_load_conservation_833  1
    service_0_4_13  unique_nonzero_owner_464  1
    service_0_4_13  service_visit_def_832  1
    service_0_4_13  free_load_conservation_833  2
    service_0_4_14  unique_nonzero_owner_465  1
    service_0_4_14  service_visit_def_832  1
    service_0_4_14  free_load_conservation_833  3
    service_0_4_15  unique_nonzero_owner_466  1
    service_0_4_15  service_visit_def_832  1
    service_0_4_15  free_load_conservation_833  4
    service_1_4_0  unique_nonzero_owner_452  1
    service_1_4_0  service_visit_def_1260  1
    service_1_4_0  free_load_conservation_1261  -11
    service_1_4_0  original_T_including_depot_unload_1266  1320
    service_1_4_1  unique_nonzero_owner_453  1
    service_1_4_1  service_visit_def_1260  1
    service_1_4_1  free_load_conservation_1261  -10
    service_1_4_1  original_T_including_depot_unload_1266  1200
    service_1_4_2  unique_nonzero_owner_454  1
    service_1_4_2  service_visit_def_1260  1
    service_1_4_2  free_load_conservation_1261  -9
    service_1_4_2  original_T_including_depot_unload_1266  1080
    service_1_4_3  unique_nonzero_owner_455  1
    service_1_4_3  service_visit_def_1260  1
    service_1_4_3  free_load_conservation_1261  -8
    service_1_4_3  original_T_including_depot_unload_1266  960
    service_1_4_4  unique_nonzero_owner_456  1
    service_1_4_4  service_visit_def_1260  1
    service_1_4_4  free_load_conservation_1261  -7
    service_1_4_4  original_T_including_depot_unload_1266  840
    service_1_4_5  unique_nonzero_owner_457  1
    service_1_4_5  service_visit_def_1260  1
    service_1_4_5  free_load_conservation_1261  -6
    service_1_4_5  original_T_including_depot_unload_1266  720
    service_1_4_6  unique_nonzero_owner_458  1
    service_1_4_6  service_visit_def_1260  1
    service_1_4_6  free_load_conservation_1261  -5
    service_1_4_6  original_T_including_depot_unload_1266  600
    service_1_4_7  unique_nonzero_owner_459  1
    service_1_4_7  service_visit_def_1260  1
    service_1_4_7  free_load_conservation_1261  -4
    service_1_4_7  original_T_including_depot_unload_1266  480
    service_1_4_8  unique_nonzero_owner_460  1
    service_1_4_8  service_visit_def_1260  1
    service_1_4_8  free_load_conservation_1261  -3
    service_1_4_8  original_T_including_depot_unload_1266  360
    service_1_4_9  unique_nonzero_owner_461  1
    service_1_4_9  service_visit_def_1260  1
    service_1_4_9  free_load_conservation_1261  -2
    service_1_4_9  original_T_including_depot_unload_1266  240
    service_1_4_10  unique_nonzero_owner_462  1
    service_1_4_10  service_visit_def_1260  1
    service_1_4_10  free_load_conservation_1261  -1
    service_1_4_10  original_T_including_depot_unload_1266  120
    service_1_4_12  unique_nonzero_owner_463  1
    service_1_4_12  service_visit_def_1260  1
    service_1_4_12  free_load_conservation_1261  1
    service_1_4_13  unique_nonzero_owner_464  1
    service_1_4_13  service_visit_def_1260  1
    service_1_4_13  free_load_conservation_1261  2
    service_1_4_14  unique_nonzero_owner_465  1
    service_1_4_14  service_visit_def_1260  1
    service_1_4_14  free_load_conservation_1261  3
    service_1_4_15  unique_nonzero_owner_466  1
    service_1_4_15  service_visit_def_1260  1
    service_1_4_15  free_load_conservation_1261  4
    service_2_4_0  unique_nonzero_owner_452  1
    service_2_4_0  service_visit_def_1579  1
    service_2_4_0  free_load_conservation_1580  -11
    service_2_4_0  original_T_including_depot_unload_1583  1320
    service_2_4_1  unique_nonzero_owner_453  1
    service_2_4_1  service_visit_def_1579  1
    service_2_4_1  free_load_conservation_1580  -10
    service_2_4_1  original_T_including_depot_unload_1583  1200
    service_2_4_2  unique_nonzero_owner_454  1
    service_2_4_2  service_visit_def_1579  1
    service_2_4_2  free_load_conservation_1580  -9
    service_2_4_2  original_T_including_depot_unload_1583  1080
    service_2_4_3  unique_nonzero_owner_455  1
    service_2_4_3  service_visit_def_1579  1
    service_2_4_3  free_load_conservation_1580  -8
    service_2_4_3  original_T_including_depot_unload_1583  960
    service_2_4_4  unique_nonzero_owner_456  1
    service_2_4_4  service_visit_def_1579  1
    service_2_4_4  free_load_conservation_1580  -7
    service_2_4_4  original_T_including_depot_unload_1583  840
    service_2_4_5  unique_nonzero_owner_457  1
    service_2_4_5  service_visit_def_1579  1
    service_2_4_5  free_load_conservation_1580  -6
    service_2_4_5  original_T_including_depot_unload_1583  720
    service_2_4_6  unique_nonzero_owner_458  1
    service_2_4_6  service_visit_def_1579  1
    service_2_4_6  free_load_conservation_1580  -5
    service_2_4_6  original_T_including_depot_unload_1583  600
    service_2_4_7  unique_nonzero_owner_459  1
    service_2_4_7  service_visit_def_1579  1
    service_2_4_7  free_load_conservation_1580  -4
    service_2_4_7  original_T_including_depot_unload_1583  480
    service_2_4_8  unique_nonzero_owner_460  1
    service_2_4_8  service_visit_def_1579  1
    service_2_4_8  free_load_conservation_1580  -3
    service_2_4_8  original_T_including_depot_unload_1583  360
    service_2_4_9  unique_nonzero_owner_461  1
    service_2_4_9  service_visit_def_1579  1
    service_2_4_9  free_load_conservation_1580  -2
    service_2_4_9  original_T_including_depot_unload_1583  240
    service_2_4_10  unique_nonzero_owner_462  1
    service_2_4_10  service_visit_def_1579  1
    service_2_4_10  free_load_conservation_1580  -1
    service_2_4_10  original_T_including_depot_unload_1583  120
    service_2_4_12  unique_nonzero_owner_463  1
    service_2_4_12  service_visit_def_1579  1
    service_2_4_12  free_load_conservation_1580  1
    service_2_4_13  unique_nonzero_owner_464  1
    service_2_4_13  service_visit_def_1579  1
    service_2_4_13  free_load_conservation_1580  2
    service_2_4_14  unique_nonzero_owner_465  1
    service_2_4_14  service_visit_def_1579  1
    service_2_4_14  free_load_conservation_1580  3
    service_2_4_15  unique_nonzero_owner_466  1
    service_2_4_15  service_visit_def_1579  1
    service_2_4_15  free_load_conservation_1580  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_758  -1
    visit_0_1  in_degree_759  -1
    visit_0_1  order_active_lb_760  -1
    visit_0_1  order_active_ub_761  -12
    order_0_1  connected_order_arc_482  -1
    order_0_1  connected_order_arc_484  -1
    order_0_1  connected_order_arc_486  -1
    order_0_1  connected_order_arc_488  -1
    order_0_1  connected_order_arc_490  -1
    order_0_1  connected_order_arc_492  -1
    order_0_1  connected_order_arc_494  -1
    order_0_1  connected_order_arc_496  -1
    order_0_1  connected_order_arc_498  -1
    order_0_1  connected_order_arc_500  -1
    order_0_1  connected_order_arc_502  -1
    order_0_1  connected_order_arc_505  1
    order_0_1  connected_order_arc_528  1
    order_0_1  connected_order_arc_551  1
    order_0_1  connected_order_arc_574  1
    order_0_1  connected_order_arc_597  1
    order_0_1  connected_order_arc_620  1
    order_0_1  connected_order_arc_643  1
    order_0_1  connected_order_arc_666  1
    order_0_1  connected_order_arc_689  1
    order_0_1  connected_order_arc_712  1
    order_0_1  connected_order_arc_735  1
    order_0_1  order_active_lb_760  1
    order_0_1  order_active_ub_761  1
    order_0_1  fixed_segment_relative_order_834  -1
    visit_0_2  out_degree_765  -1
    visit_0_2  in_degree_766  -1
    visit_0_2  order_active_lb_767  -1
    visit_0_2  order_active_ub_768  -12
    order_0_2  connected_order_arc_482  1
    order_0_2  connected_order_arc_505  -1
    order_0_2  connected_order_arc_507  -1
    order_0_2  connected_order_arc_509  -1
    order_0_2  connected_order_arc_511  -1
    order_0_2  connected_order_arc_513  -1
    order_0_2  connected_order_arc_515  -1
    order_0_2  connected_order_arc_517  -1
    order_0_2  connected_order_arc_519  -1
    order_0_2  connected_order_arc_521  -1
    order_0_2  connected_order_arc_523  -1
    order_0_2  connected_order_arc_525  -1
    order_0_2  connected_order_arc_530  1
    order_0_2  connected_order_arc_553  1
    order_0_2  connected_order_arc_576  1
    order_0_2  connected_order_arc_599  1
    order_0_2  connected_order_arc_622  1
    order_0_2  connected_order_arc_645  1
    order_0_2  connected_order_arc_668  1
    order_0_2  connected_order_arc_691  1
    order_0_2  connected_order_arc_714  1
    order_0_2  connected_order_arc_737  1
    order_0_2  order_active_lb_767  1
    order_0_2  order_active_ub_768  1
    order_0_2  fixed_segment_relative_order_834  1
    order_0_2  fixed_segment_relative_order_835  -1
    visit_0_3  out_degree_772  -1
    visit_0_3  in_degree_773  -1
    visit_0_3  order_active_lb_774  -1
    visit_0_3  order_active_ub_775  -12
    order_0_3  connected_order_arc_484  1
    order_0_3  connected_order_arc_507  1
    order_0_3  connected_order_arc_528  -1
    order_0_3  connected_order_arc_530  -1
    order_0_3  connected_order_arc_532  -1
    order_0_3  connected_order_arc_534  -1
    order_0_3  connected_order_arc_536  -1
    order_0_3  connected_order_arc_538  -1
    order_0_3  connected_order_arc_540  -1
    order_0_3  connected_order_arc_542  -1
    order_0_3  connected_order_arc_544  -1
    order_0_3  connected_order_arc_546  -1
    order_0_3  connected_order_arc_548  -1
    order_0_3  connected_order_arc_555  1
    order_0_3  connected_order_arc_578  1
    order_0_3  connected_order_arc_601  1
    order_0_3  connected_order_arc_624  1
    order_0_3  connected_order_arc_647  1
    order_0_3  connected_order_arc_670  1
    order_0_3  connected_order_arc_693  1
    order_0_3  connected_order_arc_716  1
    order_0_3  connected_order_arc_739  1
    order_0_3  order_active_lb_774  1
    order_0_3  order_active_ub_775  1
    order_0_3  fixed_segment_relative_order_835  1
    order_0_3  fixed_segment_relative_order_836  -1
    visit_0_4  out_degree_779  -1
    visit_0_4  in_degree_780  -1
    visit_0_4  order_active_lb_781  -1
    visit_0_4  order_active_ub_782  -12
    order_0_4  connected_order_arc_486  1
    order_0_4  connected_order_arc_509  1
    order_0_4  connected_order_arc_532  1
    order_0_4  connected_order_arc_551  -1
    order_0_4  connected_order_arc_553  -1
    order_0_4  connected_order_arc_555  -1
    order_0_4  connected_order_arc_557  -1
    order_0_4  connected_order_arc_559  -1
    order_0_4  connected_order_arc_561  -1
    order_0_4  connected_order_arc_563  -1
    order_0_4  connected_order_arc_565  -1
    order_0_4  connected_order_arc_567  -1
    order_0_4  connected_order_arc_569  -1
    order_0_4  connected_order_arc_571  -1
    order_0_4  connected_order_arc_580  1
    order_0_4  connected_order_arc_603  1
    order_0_4  connected_order_arc_626  1
    order_0_4  connected_order_arc_649  1
    order_0_4  connected_order_arc_672  1
    order_0_4  connected_order_arc_695  1
    order_0_4  connected_order_arc_718  1
    order_0_4  connected_order_arc_741  1
    order_0_4  order_active_lb_781  1
    order_0_4  order_active_ub_782  1
    order_0_4  fixed_segment_relative_order_836  1
    visit_0_13  out_degree_786  -1
    visit_0_13  in_degree_787  -1
    visit_0_13  order_active_lb_788  -1
    visit_0_13  order_active_ub_789  -12
    visit_0_13  service_visit_def_790  -1
    order_0_13  connected_order_arc_488  1
    order_0_13  connected_order_arc_511  1
    order_0_13  connected_order_arc_534  1
    order_0_13  connected_order_arc_557  1
    order_0_13  connected_order_arc_574  -1
    order_0_13  connected_order_arc_576  -1
    order_0_13  connected_order_arc_578  -1
    order_0_13  connected_order_arc_580  -1
    order_0_13  connected_order_arc_582  -1
    order_0_13  connected_order_arc_584  -1
    order_0_13  connected_order_arc_586  -1
    order_0_13  connected_order_arc_588  -1
    order_0_13  connected_order_arc_590  -1
    order_0_13  connected_order_arc_592  -1
    order_0_13  connected_order_arc_594  -1
    order_0_13  connected_order_arc_605  1
    order_0_13  connected_order_arc_628  1
    order_0_13  connected_order_arc_651  1
    order_0_13  connected_order_arc_674  1
    order_0_13  connected_order_arc_697  1
    order_0_13  connected_order_arc_720  1
    order_0_13  connected_order_arc_743  1
    order_0_13  order_active_lb_788  1
    order_0_13  order_active_ub_789  1
    visit_0_14  out_degree_792  -1
    visit_0_14  in_degree_793  -1
    visit_0_14  order_active_lb_794  -1
    visit_0_14  order_active_ub_795  -12
    visit_0_14  service_visit_def_796  -1
    order_0_14  connected_order_arc_490  1
    order_0_14  connected_order_arc_513  1
    order_0_14  connected_order_arc_536  1
    order_0_14  connected_order_arc_559  1
    order_0_14  connected_order_arc_582  1
    order_0_14  connected_order_arc_597  -1
    order_0_14  connected_order_arc_599  -1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_603  -1
    order_0_14  connected_order_arc_605  -1
    order_0_14  connected_order_arc_607  -1
    order_0_14  connected_order_arc_609  -1
    order_0_14  connected_order_arc_611  -1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_630  1
    order_0_14  connected_order_arc_653  1
    order_0_14  connected_order_arc_676  1
    order_0_14  connected_order_arc_699  1
    order_0_14  connected_order_arc_722  1
    order_0_14  connected_order_arc_745  1
    order_0_14  order_active_lb_794  1
    order_0_14  order_active_ub_795  1
    visit_0_15  out_degree_798  -1
    visit_0_15  in_degree_799  -1
    visit_0_15  order_active_lb_800  -1
    visit_0_15  order_active_ub_801  -12
    visit_0_15  service_visit_def_802  -1
    order_0_15  connected_order_arc_492  1
    order_0_15  connected_order_arc_515  1
    order_0_15  connected_order_arc_538  1
    order_0_15  connected_order_arc_561  1
    order_0_15  connected_order_arc_584  1
    order_0_15  connected_order_arc_607  1
    order_0_15  connected_order_arc_620  -1
    order_0_15  connected_order_arc_622  -1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_630  -1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_655  1
    order_0_15  connected_order_arc_678  1
    order_0_15  connected_order_arc_701  1
    order_0_15  connected_order_arc_724  1
    order_0_15  connected_order_arc_747  1
    order_0_15  order_active_lb_800  1
    order_0_15  order_active_ub_801  1
    visit_0_16  out_degree_804  -1
    visit_0_16  in_degree_805  -1
    visit_0_16  order_active_lb_806  -1
    visit_0_16  order_active_ub_807  -12
    visit_0_16  service_visit_def_808  -1
    order_0_16  connected_order_arc_494  1
    order_0_16  connected_order_arc_517  1
    order_0_16  connected_order_arc_540  1
    order_0_16  connected_order_arc_563  1
    order_0_16  connected_order_arc_586  1
    order_0_16  connected_order_arc_609  1
    order_0_16  connected_order_arc_632  1
    order_0_16  connected_order_arc_643  -1
    order_0_16  connected_order_arc_645  -1
    order_0_16  connected_order_arc_647  -1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_653  -1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_680  1
    order_0_16  connected_order_arc_703  1
    order_0_16  connected_order_arc_726  1
    order_0_16  connected_order_arc_749  1
    order_0_16  order_active_lb_806  1
    order_0_16  order_active_ub_807  1
    visit_0_17  out_degree_810  -1
    visit_0_17  in_degree_811  -1
    visit_0_17  order_active_lb_812  -1
    visit_0_17  order_active_ub_813  -12
    visit_0_17  service_visit_def_814  -1
    order_0_17  connected_order_arc_496  1
    order_0_17  connected_order_arc_519  1
    order_0_17  connected_order_arc_542  1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_588  1
    order_0_17  connected_order_arc_611  1
    order_0_17  connected_order_arc_634  1
    order_0_17  connected_order_arc_657  1
    order_0_17  connected_order_arc_666  -1
    order_0_17  connected_order_arc_668  -1
    order_0_17  connected_order_arc_670  -1
    order_0_17  connected_order_arc_672  -1
    order_0_17  connected_order_arc_674  -1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_680  -1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_705  1
    order_0_17  connected_order_arc_728  1
    order_0_17  connected_order_arc_751  1
    order_0_17  order_active_lb_812  1
    order_0_17  order_active_ub_813  1
    visit_0_18  out_degree_816  -1
    visit_0_18  in_degree_817  -1
    visit_0_18  order_active_lb_818  -1
    visit_0_18  order_active_ub_819  -12
    visit_0_18  service_visit_def_820  -1
    order_0_18  connected_order_arc_498  1
    order_0_18  connected_order_arc_521  1
    order_0_18  connected_order_arc_544  1
    order_0_18  connected_order_arc_567  1
    order_0_18  connected_order_arc_590  1
    order_0_18  connected_order_arc_613  1
    order_0_18  connected_order_arc_636  1
    order_0_18  connected_order_arc_659  1
    order_0_18  connected_order_arc_682  1
    order_0_18  connected_order_arc_689  -1
    order_0_18  connected_order_arc_691  -1
    order_0_18  connected_order_arc_693  -1
    order_0_18  connected_order_arc_695  -1
    order_0_18  connected_order_arc_697  -1
    order_0_18  connected_order_arc_699  -1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_705  -1
    order_0_18  connected_order_arc_707  -1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_730  1
    order_0_18  connected_order_arc_753  1
    order_0_18  order_active_lb_818  1
    order_0_18  order_active_ub_819  1
    visit_0_19  out_degree_822  -1
    visit_0_19  in_degree_823  -1
    visit_0_19  order_active_lb_824  -1
    visit_0_19  order_active_ub_825  -12
    visit_0_19  service_visit_def_826  -1
    order_0_19  connected_order_arc_500  1
    order_0_19  connected_order_arc_523  1
    order_0_19  connected_order_arc_546  1
    order_0_19  connected_order_arc_569  1
    order_0_19  connected_order_arc_592  1
    order_0_19  connected_order_arc_615  1
    order_0_19  connected_order_arc_638  1
    order_0_19  connected_order_arc_661  1
    order_0_19  connected_order_arc_684  1
    order_0_19  connected_order_arc_707  1
    order_0_19  connected_order_arc_712  -1
    order_0_19  connected_order_arc_714  -1
    order_0_19  connected_order_arc_716  -1
    order_0_19  connected_order_arc_718  -1
    order_0_19  connected_order_arc_720  -1
    order_0_19  connected_order_arc_722  -1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_728  -1
    order_0_19  connected_order_arc_730  -1
    order_0_19  connected_order_arc_732  -1
    order_0_19  connected_order_arc_755  1
    order_0_19  order_active_lb_824  1
    order_0_19  order_active_ub_825  1
    visit_0_20  out_degree_828  -1
    visit_0_20  in_degree_829  -1
    visit_0_20  order_active_lb_830  -1
    visit_0_20  order_active_ub_831  -12
    visit_0_20  service_visit_def_832  -1
    order_0_20  connected_order_arc_502  1
    order_0_20  connected_order_arc_525  1
    order_0_20  connected_order_arc_548  1
    order_0_20  connected_order_arc_571  1
    order_0_20  connected_order_arc_594  1
    order_0_20  connected_order_arc_617  1
    order_0_20  connected_order_arc_640  1
    order_0_20  connected_order_arc_663  1
    order_0_20  connected_order_arc_686  1
    order_0_20  connected_order_arc_709  1
    order_0_20  connected_order_arc_732  1
    order_0_20  connected_order_arc_735  -1
    order_0_20  connected_order_arc_737  -1
    order_0_20  connected_order_arc_739  -1
    order_0_20  connected_order_arc_741  -1
    order_0_20  connected_order_arc_743  -1
    order_0_20  connected_order_arc_745  -1
    order_0_20  connected_order_arc_747  -1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  connected_order_arc_753  -1
    order_0_20  connected_order_arc_755  -1
    order_0_20  order_active_lb_830  1
    order_0_20  order_active_ub_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_467  -20
    arc_0_0_0  depot_departure_or_bypass_756  1
    arc_0_0_0  depot_return_or_bypass_757  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_467  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_468  -20
    arc_0_0_1  depot_departure_or_bypass_756  1
    arc_0_0_1  in_degree_759  1
    arc_0_0_1  original_T_including_depot_unload_837  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_468  1
    load_0_0_1  segment_load_conservation_762  -1
    load_0_0_1  segment_prefix_lb_763  1
    load_0_0_1  segment_prefix_ub_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_469  -20
    arc_0_0_2  depot_departure_or_bypass_756  1
    arc_0_0_2  in_degree_766  1
    arc_0_0_2  original_T_including_depot_unload_837  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_469  1
    load_0_0_2  segment_load_conservation_769  -1
    load_0_0_2  segment_prefix_lb_770  1
    load_0_0_2  segment_prefix_ub_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_470  -20
    arc_0_0_3  depot_departure_or_bypass_756  1
    arc_0_0_3  in_degree_773  1
    arc_0_0_3  original_T_including_depot_unload_837  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_470  1
    load_0_0_3  segment_load_conservation_776  -1
    load_0_0_3  segment_prefix_lb_777  1
    load_0_0_3  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_471  -20
    arc_0_0_4  depot_departure_or_bypass_756  1
    arc_0_0_4  in_degree_780  1
    arc_0_0_4  original_T_including_depot_unload_837  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_471  1
    load_0_0_4  segment_load_conservation_783  -1
    load_0_0_4  segment_prefix_lb_784  1
    load_0_0_4  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_472  -20
    arc_0_0_13  depot_departure_or_bypass_756  1
    arc_0_0_13  in_degree_787  1
    arc_0_0_13  original_T_including_depot_unload_837  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_472  1
    load_0_0_13  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_473  -20
    arc_0_0_14  depot_departure_or_bypass_756  1
    arc_0_0_14  in_degree_793  1
    arc_0_0_14  original_T_including_depot_unload_837  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_473  1
    load_0_0_14  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_474  -20
    arc_0_0_15  depot_departure_or_bypass_756  1
    arc_0_0_15  in_degree_799  1
    arc_0_0_15  original_T_including_depot_unload_837  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_474  1
    load_0_0_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_475  -20
    arc_0_0_16  depot_departure_or_bypass_756  1
    arc_0_0_16  in_degree_805  1
    arc_0_0_16  original_T_including_depot_unload_837  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_475  1
    load_0_0_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_476  -20
    arc_0_0_17  depot_departure_or_bypass_756  1
    arc_0_0_17  in_degree_811  1
    arc_0_0_17  original_T_including_depot_unload_837  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_476  1
    load_0_0_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_477  -20
    arc_0_0_18  depot_departure_or_bypass_756  1
    arc_0_0_18  in_degree_817  1
    arc_0_0_18  original_T_including_depot_unload_837  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_477  1
    load_0_0_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_478  -20
    arc_0_0_19  depot_departure_or_bypass_756  1
    arc_0_0_19  in_degree_823  1
    arc_0_0_19  original_T_including_depot_unload_837  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_478  1
    load_0_0_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_479  -20
    arc_0_0_20  depot_departure_or_bypass_756  1
    arc_0_0_20  in_degree_829  1
    arc_0_0_20  original_T_including_depot_unload_837  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_479  1
    load_0_0_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_480  -20
    arc_0_1_0  depot_return_or_bypass_757  1
    arc_0_1_0  out_degree_758  1
    arc_0_1_0  original_T_including_depot_unload_837  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_480  1
    load_0_1_0  segment_load_conservation_762  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_481  -20
    arc_0_1_2  connected_order_arc_482  -13
    arc_0_1_2  out_degree_758  1
    arc_0_1_2  in_degree_766  1
    arc_0_1_2  original_T_including_depot_unload_837  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_481  1
    load_0_1_2  segment_load_conservation_762  1
    load_0_1_2  segment_load_conservation_769  -1
    load_0_1_2  segment_prefix_lb_770  1
    load_0_1_2  segment_prefix_ub_771  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_483  -20
    arc_0_1_3  connected_order_arc_484  -13
    arc_0_1_3  out_degree_758  1
    arc_0_1_3  in_degree_773  1
    arc_0_1_3  original_T_including_depot_unload_837  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_483  1
    load_0_1_3  segment_load_conservation_762  1
    load_0_1_3  segment_load_conservation_776  -1
    load_0_1_3  segment_prefix_lb_777  1
    load_0_1_3  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_485  -20
    arc_0_1_4  connected_order_arc_486  -13
    arc_0_1_4  out_degree_758  1
    arc_0_1_4  in_degree_780  1
    arc_0_1_4  original_T_including_depot_unload_837  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_485  1
    load_0_1_4  segment_load_conservation_762  1
    load_0_1_4  segment_load_conservation_783  -1
    load_0_1_4  segment_prefix_lb_784  1
    load_0_1_4  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_487  -20
    arc_0_1_13  connected_order_arc_488  -13
    arc_0_1_13  out_degree_758  1
    arc_0_1_13  in_degree_787  1
    arc_0_1_13  original_T_including_depot_unload_837  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_487  1
    load_0_1_13  segment_load_conservation_762  1
    load_0_1_13  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_489  -20
    arc_0_1_14  connected_order_arc_490  -13
    arc_0_1_14  out_degree_758  1
    arc_0_1_14  in_degree_793  1
    arc_0_1_14  original_T_including_depot_unload_837  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_489  1
    load_0_1_14  segment_load_conservation_762  1
    load_0_1_14  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_491  -20
    arc_0_1_15  connected_order_arc_492  -13
    arc_0_1_15  out_degree_758  1
    arc_0_1_15  in_degree_799  1
    arc_0_1_15  original_T_including_depot_unload_837  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_491  1
    load_0_1_15  segment_load_conservation_762  1
    load_0_1_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_493  -20
    arc_0_1_16  connected_order_arc_494  -13
    arc_0_1_16  out_degree_758  1
    arc_0_1_16  in_degree_805  1
    arc_0_1_16  original_T_including_depot_unload_837  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_493  1
    load_0_1_16  segment_load_conservation_762  1
    load_0_1_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_495  -20
    arc_0_1_17  connected_order_arc_496  -13
    arc_0_1_17  out_degree_758  1
    arc_0_1_17  in_degree_811  1
    arc_0_1_17  original_T_including_depot_unload_837  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_495  1
    load_0_1_17  segment_load_conservation_762  1
    load_0_1_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_497  -20
    arc_0_1_18  connected_order_arc_498  -13
    arc_0_1_18  out_degree_758  1
    arc_0_1_18  in_degree_817  1
    arc_0_1_18  original_T_including_depot_unload_837  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_497  1
    load_0_1_18  segment_load_conservation_762  1
    load_0_1_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_499  -20
    arc_0_1_19  connected_order_arc_500  -13
    arc_0_1_19  out_degree_758  1
    arc_0_1_19  in_degree_823  1
    arc_0_1_19  original_T_including_depot_unload_837  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_499  1
    load_0_1_19  segment_load_conservation_762  1
    load_0_1_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_501  -20
    arc_0_1_20  connected_order_arc_502  -13
    arc_0_1_20  out_degree_758  1
    arc_0_1_20  in_degree_829  1
    arc_0_1_20  original_T_including_depot_unload_837  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_501  1
    load_0_1_20  segment_load_conservation_762  1
    load_0_1_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_503  -20
    arc_0_2_0  depot_return_or_bypass_757  1
    arc_0_2_0  out_degree_765  1
    arc_0_2_0  original_T_including_depot_unload_837  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_503  1
    load_0_2_0  segment_load_conservation_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_504  -20
    arc_0_2_1  connected_order_arc_505  -13
    arc_0_2_1  in_degree_759  1
    arc_0_2_1  out_degree_765  1
    arc_0_2_1  original_T_including_depot_unload_837  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_504  1
    load_0_2_1  segment_load_conservation_762  -1
    load_0_2_1  segment_prefix_lb_763  1
    load_0_2_1  segment_prefix_ub_764  1
    load_0_2_1  segment_load_conservation_769  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_506  -20
    arc_0_2_3  connected_order_arc_507  -13
    arc_0_2_3  out_degree_765  1
    arc_0_2_3  in_degree_773  1
    arc_0_2_3  original_T_including_depot_unload_837  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_506  1
    load_0_2_3  segment_load_conservation_769  1
    load_0_2_3  segment_load_conservation_776  -1
    load_0_2_3  segment_prefix_lb_777  1
    load_0_2_3  segment_prefix_ub_778  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_508  -20
    arc_0_2_4  connected_order_arc_509  -13
    arc_0_2_4  out_degree_765  1
    arc_0_2_4  in_degree_780  1
    arc_0_2_4  original_T_including_depot_unload_837  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_508  1
    load_0_2_4  segment_load_conservation_769  1
    load_0_2_4  segment_load_conservation_783  -1
    load_0_2_4  segment_prefix_lb_784  1
    load_0_2_4  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_510  -20
    arc_0_2_13  connected_order_arc_511  -13
    arc_0_2_13  out_degree_765  1
    arc_0_2_13  in_degree_787  1
    arc_0_2_13  original_T_including_depot_unload_837  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_510  1
    load_0_2_13  segment_load_conservation_769  1
    load_0_2_13  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_512  -20
    arc_0_2_14  connected_order_arc_513  -13
    arc_0_2_14  out_degree_765  1
    arc_0_2_14  in_degree_793  1
    arc_0_2_14  original_T_including_depot_unload_837  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_512  1
    load_0_2_14  segment_load_conservation_769  1
    load_0_2_14  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_514  -20
    arc_0_2_15  connected_order_arc_515  -13
    arc_0_2_15  out_degree_765  1
    arc_0_2_15  in_degree_799  1
    arc_0_2_15  original_T_including_depot_unload_837  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_514  1
    load_0_2_15  segment_load_conservation_769  1
    load_0_2_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_516  -20
    arc_0_2_16  connected_order_arc_517  -13
    arc_0_2_16  out_degree_765  1
    arc_0_2_16  in_degree_805  1
    arc_0_2_16  original_T_including_depot_unload_837  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_516  1
    load_0_2_16  segment_load_conservation_769  1
    load_0_2_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_518  -20
    arc_0_2_17  connected_order_arc_519  -13
    arc_0_2_17  out_degree_765  1
    arc_0_2_17  in_degree_811  1
    arc_0_2_17  original_T_including_depot_unload_837  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_518  1
    load_0_2_17  segment_load_conservation_769  1
    load_0_2_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_520  -20
    arc_0_2_18  connected_order_arc_521  -13
    arc_0_2_18  out_degree_765  1
    arc_0_2_18  in_degree_817  1
    arc_0_2_18  original_T_including_depot_unload_837  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_520  1
    load_0_2_18  segment_load_conservation_769  1
    load_0_2_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_522  -20
    arc_0_2_19  connected_order_arc_523  -13
    arc_0_2_19  out_degree_765  1
    arc_0_2_19  in_degree_823  1
    arc_0_2_19  original_T_including_depot_unload_837  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_522  1
    load_0_2_19  segment_load_conservation_769  1
    load_0_2_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_524  -20
    arc_0_2_20  connected_order_arc_525  -13
    arc_0_2_20  out_degree_765  1
    arc_0_2_20  in_degree_829  1
    arc_0_2_20  original_T_including_depot_unload_837  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_524  1
    load_0_2_20  segment_load_conservation_769  1
    load_0_2_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_526  -20
    arc_0_3_0  depot_return_or_bypass_757  1
    arc_0_3_0  out_degree_772  1
    arc_0_3_0  original_T_including_depot_unload_837  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_526  1
    load_0_3_0  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_527  -20
    arc_0_3_1  connected_order_arc_528  -13
    arc_0_3_1  in_degree_759  1
    arc_0_3_1  out_degree_772  1
    arc_0_3_1  original_T_including_depot_unload_837  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_527  1
    load_0_3_1  segment_load_conservation_762  -1
    load_0_3_1  segment_prefix_lb_763  1
    load_0_3_1  segment_prefix_ub_764  1
    load_0_3_1  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_529  -20
    arc_0_3_2  connected_order_arc_530  -13
    arc_0_3_2  in_degree_766  1
    arc_0_3_2  out_degree_772  1
    arc_0_3_2  original_T_including_depot_unload_837  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_529  1
    load_0_3_2  segment_load_conservation_769  -1
    load_0_3_2  segment_prefix_lb_770  1
    load_0_3_2  segment_prefix_ub_771  1
    load_0_3_2  segment_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_531  -20
    arc_0_3_4  connected_order_arc_532  -13
    arc_0_3_4  out_degree_772  1
    arc_0_3_4  in_degree_780  1
    arc_0_3_4  original_T_including_depot_unload_837  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_531  1
    load_0_3_4  segment_load_conservation_776  1
    load_0_3_4  segment_load_conservation_783  -1
    load_0_3_4  segment_prefix_lb_784  1
    load_0_3_4  segment_prefix_ub_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_533  -20
    arc_0_3_13  connected_order_arc_534  -13
    arc_0_3_13  out_degree_772  1
    arc_0_3_13  in_degree_787  1
    arc_0_3_13  original_T_including_depot_unload_837  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_533  1
    load_0_3_13  segment_load_conservation_776  1
    load_0_3_13  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_535  -20
    arc_0_3_14  connected_order_arc_536  -13
    arc_0_3_14  out_degree_772  1
    arc_0_3_14  in_degree_793  1
    arc_0_3_14  original_T_including_depot_unload_837  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_535  1
    load_0_3_14  segment_load_conservation_776  1
    load_0_3_14  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_537  -20
    arc_0_3_15  connected_order_arc_538  -13
    arc_0_3_15  out_degree_772  1
    arc_0_3_15  in_degree_799  1
    arc_0_3_15  original_T_including_depot_unload_837  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_537  1
    load_0_3_15  segment_load_conservation_776  1
    load_0_3_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_539  -20
    arc_0_3_16  connected_order_arc_540  -13
    arc_0_3_16  out_degree_772  1
    arc_0_3_16  in_degree_805  1
    arc_0_3_16  original_T_including_depot_unload_837  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_539  1
    load_0_3_16  segment_load_conservation_776  1
    load_0_3_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_541  -20
    arc_0_3_17  connected_order_arc_542  -13
    arc_0_3_17  out_degree_772  1
    arc_0_3_17  in_degree_811  1
    arc_0_3_17  original_T_including_depot_unload_837  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_541  1
    load_0_3_17  segment_load_conservation_776  1
    load_0_3_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_543  -20
    arc_0_3_18  connected_order_arc_544  -13
    arc_0_3_18  out_degree_772  1
    arc_0_3_18  in_degree_817  1
    arc_0_3_18  original_T_including_depot_unload_837  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_543  1
    load_0_3_18  segment_load_conservation_776  1
    load_0_3_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_545  -20
    arc_0_3_19  connected_order_arc_546  -13
    arc_0_3_19  out_degree_772  1
    arc_0_3_19  in_degree_823  1
    arc_0_3_19  original_T_including_depot_unload_837  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_545  1
    load_0_3_19  segment_load_conservation_776  1
    load_0_3_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_547  -20
    arc_0_3_20  connected_order_arc_548  -13
    arc_0_3_20  out_degree_772  1
    arc_0_3_20  in_degree_829  1
    arc_0_3_20  original_T_including_depot_unload_837  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_547  1
    load_0_3_20  segment_load_conservation_776  1
    load_0_3_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_549  -20
    arc_0_4_0  depot_return_or_bypass_757  1
    arc_0_4_0  out_degree_779  1
    arc_0_4_0  original_T_including_depot_unload_837  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_549  1
    load_0_4_0  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_550  -20
    arc_0_4_1  connected_order_arc_551  -13
    arc_0_4_1  in_degree_759  1
    arc_0_4_1  out_degree_779  1
    arc_0_4_1  original_T_including_depot_unload_837  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_550  1
    load_0_4_1  segment_load_conservation_762  -1
    load_0_4_1  segment_prefix_lb_763  1
    load_0_4_1  segment_prefix_ub_764  1
    load_0_4_1  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_552  -20
    arc_0_4_2  connected_order_arc_553  -13
    arc_0_4_2  in_degree_766  1
    arc_0_4_2  out_degree_779  1
    arc_0_4_2  original_T_including_depot_unload_837  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_552  1
    load_0_4_2  segment_load_conservation_769  -1
    load_0_4_2  segment_prefix_lb_770  1
    load_0_4_2  segment_prefix_ub_771  1
    load_0_4_2  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_554  -20
    arc_0_4_3  connected_order_arc_555  -13
    arc_0_4_3  in_degree_773  1
    arc_0_4_3  out_degree_779  1
    arc_0_4_3  original_T_including_depot_unload_837  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_554  1
    load_0_4_3  segment_load_conservation_776  -1
    load_0_4_3  segment_prefix_lb_777  1
    load_0_4_3  segment_prefix_ub_778  1
    load_0_4_3  segment_load_conservation_783  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_556  -20
    arc_0_4_13  connected_order_arc_557  -13
    arc_0_4_13  out_degree_779  1
    arc_0_4_13  in_degree_787  1
    arc_0_4_13  original_T_including_depot_unload_837  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_556  1
    load_0_4_13  segment_load_conservation_783  1
    load_0_4_13  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_558  -20
    arc_0_4_14  connected_order_arc_559  -13
    arc_0_4_14  out_degree_779  1
    arc_0_4_14  in_degree_793  1
    arc_0_4_14  original_T_including_depot_unload_837  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_558  1
    load_0_4_14  segment_load_conservation_783  1
    load_0_4_14  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_560  -20
    arc_0_4_15  connected_order_arc_561  -13
    arc_0_4_15  out_degree_779  1
    arc_0_4_15  in_degree_799  1
    arc_0_4_15  original_T_including_depot_unload_837  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_560  1
    load_0_4_15  segment_load_conservation_783  1
    load_0_4_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_562  -20
    arc_0_4_16  connected_order_arc_563  -13
    arc_0_4_16  out_degree_779  1
    arc_0_4_16  in_degree_805  1
    arc_0_4_16  original_T_including_depot_unload_837  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_562  1
    load_0_4_16  segment_load_conservation_783  1
    load_0_4_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_564  -20
    arc_0_4_17  connected_order_arc_565  -13
    arc_0_4_17  out_degree_779  1
    arc_0_4_17  in_degree_811  1
    arc_0_4_17  original_T_including_depot_unload_837  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_564  1
    load_0_4_17  segment_load_conservation_783  1
    load_0_4_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_566  -20
    arc_0_4_18  connected_order_arc_567  -13
    arc_0_4_18  out_degree_779  1
    arc_0_4_18  in_degree_817  1
    arc_0_4_18  original_T_including_depot_unload_837  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_566  1
    load_0_4_18  segment_load_conservation_783  1
    load_0_4_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_568  -20
    arc_0_4_19  connected_order_arc_569  -13
    arc_0_4_19  out_degree_779  1
    arc_0_4_19  in_degree_823  1
    arc_0_4_19  original_T_including_depot_unload_837  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_568  1
    load_0_4_19  segment_load_conservation_783  1
    load_0_4_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_570  -20
    arc_0_4_20  connected_order_arc_571  -13
    arc_0_4_20  out_degree_779  1
    arc_0_4_20  in_degree_829  1
    arc_0_4_20  original_T_including_depot_unload_837  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_570  1
    load_0_4_20  segment_load_conservation_783  1
    load_0_4_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_572  -20
    arc_0_13_0  depot_return_or_bypass_757  1
    arc_0_13_0  out_degree_786  1
    arc_0_13_0  original_T_including_depot_unload_837  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_572  1
    load_0_13_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_573  -20
    arc_0_13_1  connected_order_arc_574  -13
    arc_0_13_1  in_degree_759  1
    arc_0_13_1  out_degree_786  1
    arc_0_13_1  original_T_including_depot_unload_837  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_573  1
    load_0_13_1  segment_load_conservation_762  -1
    load_0_13_1  segment_prefix_lb_763  1
    load_0_13_1  segment_prefix_ub_764  1
    load_0_13_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_575  -20
    arc_0_13_2  connected_order_arc_576  -13
    arc_0_13_2  in_degree_766  1
    arc_0_13_2  out_degree_786  1
    arc_0_13_2  original_T_including_depot_unload_837  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_575  1
    load_0_13_2  segment_load_conservation_769  -1
    load_0_13_2  segment_prefix_lb_770  1
    load_0_13_2  segment_prefix_ub_771  1
    load_0_13_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_577  -20
    arc_0_13_3  connected_order_arc_578  -13
    arc_0_13_3  in_degree_773  1
    arc_0_13_3  out_degree_786  1
    arc_0_13_3  original_T_including_depot_unload_837  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_577  1
    load_0_13_3  segment_load_conservation_776  -1
    load_0_13_3  segment_prefix_lb_777  1
    load_0_13_3  segment_prefix_ub_778  1
    load_0_13_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_579  -20
    arc_0_13_4  connected_order_arc_580  -13
    arc_0_13_4  in_degree_780  1
    arc_0_13_4  out_degree_786  1
    arc_0_13_4  original_T_including_depot_unload_837  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_579  1
    load_0_13_4  segment_load_conservation_783  -1
    load_0_13_4  segment_prefix_lb_784  1
    load_0_13_4  segment_prefix_ub_785  1
    load_0_13_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_581  -20
    arc_0_13_14  connected_order_arc_582  -13
    arc_0_13_14  out_degree_786  1
    arc_0_13_14  in_degree_793  1
    arc_0_13_14  original_T_including_depot_unload_837  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_581  1
    load_0_13_14  free_load_conservation_791  1
    load_0_13_14  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_583  -20
    arc_0_13_15  connected_order_arc_584  -13
    arc_0_13_15  out_degree_786  1
    arc_0_13_15  in_degree_799  1
    arc_0_13_15  original_T_including_depot_unload_837  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_583  1
    load_0_13_15  free_load_conservation_791  1
    load_0_13_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_585  -20
    arc_0_13_16  connected_order_arc_586  -13
    arc_0_13_16  out_degree_786  1
    arc_0_13_16  in_degree_805  1
    arc_0_13_16  original_T_including_depot_unload_837  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_585  1
    load_0_13_16  free_load_conservation_791  1
    load_0_13_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_587  -20
    arc_0_13_17  connected_order_arc_588  -13
    arc_0_13_17  out_degree_786  1
    arc_0_13_17  in_degree_811  1
    arc_0_13_17  original_T_including_depot_unload_837  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_587  1
    load_0_13_17  free_load_conservation_791  1
    load_0_13_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_589  -20
    arc_0_13_18  connected_order_arc_590  -13
    arc_0_13_18  out_degree_786  1
    arc_0_13_18  in_degree_817  1
    arc_0_13_18  original_T_including_depot_unload_837  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_589  1
    load_0_13_18  free_load_conservation_791  1
    load_0_13_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_591  -20
    arc_0_13_19  connected_order_arc_592  -13
    arc_0_13_19  out_degree_786  1
    arc_0_13_19  in_degree_823  1
    arc_0_13_19  original_T_including_depot_unload_837  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_591  1
    load_0_13_19  free_load_conservation_791  1
    load_0_13_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_593  -20
    arc_0_13_20  connected_order_arc_594  -13
    arc_0_13_20  out_degree_786  1
    arc_0_13_20  in_degree_829  1
    arc_0_13_20  original_T_including_depot_unload_837  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_593  1
    load_0_13_20  free_load_conservation_791  1
    load_0_13_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_595  -20
    arc_0_14_0  depot_return_or_bypass_757  1
    arc_0_14_0  out_degree_792  1
    arc_0_14_0  original_T_including_depot_unload_837  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_595  1
    load_0_14_0  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_596  -20
    arc_0_14_1  connected_order_arc_597  -13
    arc_0_14_1  in_degree_759  1
    arc_0_14_1  out_degree_792  1
    arc_0_14_1  original_T_including_depot_unload_837  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_596  1
    load_0_14_1  segment_load_conservation_762  -1
    load_0_14_1  segment_prefix_lb_763  1
    load_0_14_1  segment_prefix_ub_764  1
    load_0_14_1  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_598  -20
    arc_0_14_2  connected_order_arc_599  -13
    arc_0_14_2  in_degree_766  1
    arc_0_14_2  out_degree_792  1
    arc_0_14_2  original_T_including_depot_unload_837  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_598  1
    load_0_14_2  segment_load_conservation_769  -1
    load_0_14_2  segment_prefix_lb_770  1
    load_0_14_2  segment_prefix_ub_771  1
    load_0_14_2  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_600  -20
    arc_0_14_3  connected_order_arc_601  -13
    arc_0_14_3  in_degree_773  1
    arc_0_14_3  out_degree_792  1
    arc_0_14_3  original_T_including_depot_unload_837  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_600  1
    load_0_14_3  segment_load_conservation_776  -1
    load_0_14_3  segment_prefix_lb_777  1
    load_0_14_3  segment_prefix_ub_778  1
    load_0_14_3  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_602  -20
    arc_0_14_4  connected_order_arc_603  -13
    arc_0_14_4  in_degree_780  1
    arc_0_14_4  out_degree_792  1
    arc_0_14_4  original_T_including_depot_unload_837  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_602  1
    load_0_14_4  segment_load_conservation_783  -1
    load_0_14_4  segment_prefix_lb_784  1
    load_0_14_4  segment_prefix_ub_785  1
    load_0_14_4  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_604  -20
    arc_0_14_13  connected_order_arc_605  -13
    arc_0_14_13  in_degree_787  1
    arc_0_14_13  out_degree_792  1
    arc_0_14_13  original_T_including_depot_unload_837  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_604  1
    load_0_14_13  free_load_conservation_791  -1
    load_0_14_13  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_606  -20
    arc_0_14_15  connected_order_arc_607  -13
    arc_0_14_15  out_degree_792  1
    arc_0_14_15  in_degree_799  1
    arc_0_14_15  original_T_including_depot_unload_837  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_606  1
    load_0_14_15  free_load_conservation_797  1
    load_0_14_15  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_608  -20
    arc_0_14_16  connected_order_arc_609  -13
    arc_0_14_16  out_degree_792  1
    arc_0_14_16  in_degree_805  1
    arc_0_14_16  original_T_including_depot_unload_837  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_608  1
    load_0_14_16  free_load_conservation_797  1
    load_0_14_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_610  -20
    arc_0_14_17  connected_order_arc_611  -13
    arc_0_14_17  out_degree_792  1
    arc_0_14_17  in_degree_811  1
    arc_0_14_17  original_T_including_depot_unload_837  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_610  1
    load_0_14_17  free_load_conservation_797  1
    load_0_14_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_612  -20
    arc_0_14_18  connected_order_arc_613  -13
    arc_0_14_18  out_degree_792  1
    arc_0_14_18  in_degree_817  1
    arc_0_14_18  original_T_including_depot_unload_837  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_612  1
    load_0_14_18  free_load_conservation_797  1
    load_0_14_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_614  -20
    arc_0_14_19  connected_order_arc_615  -13
    arc_0_14_19  out_degree_792  1
    arc_0_14_19  in_degree_823  1
    arc_0_14_19  original_T_including_depot_unload_837  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_614  1
    load_0_14_19  free_load_conservation_797  1
    load_0_14_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_616  -20
    arc_0_14_20  connected_order_arc_617  -13
    arc_0_14_20  out_degree_792  1
    arc_0_14_20  in_degree_829  1
    arc_0_14_20  original_T_including_depot_unload_837  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_616  1
    load_0_14_20  free_load_conservation_797  1
    load_0_14_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_618  -20
    arc_0_15_0  depot_return_or_bypass_757  1
    arc_0_15_0  out_degree_798  1
    arc_0_15_0  original_T_including_depot_unload_837  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_618  1
    load_0_15_0  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_619  -20
    arc_0_15_1  connected_order_arc_620  -13
    arc_0_15_1  in_degree_759  1
    arc_0_15_1  out_degree_798  1
    arc_0_15_1  original_T_including_depot_unload_837  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_619  1
    load_0_15_1  segment_load_conservation_762  -1
    load_0_15_1  segment_prefix_lb_763  1
    load_0_15_1  segment_prefix_ub_764  1
    load_0_15_1  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_621  -20
    arc_0_15_2  connected_order_arc_622  -13
    arc_0_15_2  in_degree_766  1
    arc_0_15_2  out_degree_798  1
    arc_0_15_2  original_T_including_depot_unload_837  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_621  1
    load_0_15_2  segment_load_conservation_769  -1
    load_0_15_2  segment_prefix_lb_770  1
    load_0_15_2  segment_prefix_ub_771  1
    load_0_15_2  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_623  -20
    arc_0_15_3  connected_order_arc_624  -13
    arc_0_15_3  in_degree_773  1
    arc_0_15_3  out_degree_798  1
    arc_0_15_3  original_T_including_depot_unload_837  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_623  1
    load_0_15_3  segment_load_conservation_776  -1
    load_0_15_3  segment_prefix_lb_777  1
    load_0_15_3  segment_prefix_ub_778  1
    load_0_15_3  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_625  -20
    arc_0_15_4  connected_order_arc_626  -13
    arc_0_15_4  in_degree_780  1
    arc_0_15_4  out_degree_798  1
    arc_0_15_4  original_T_including_depot_unload_837  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_625  1
    load_0_15_4  segment_load_conservation_783  -1
    load_0_15_4  segment_prefix_lb_784  1
    load_0_15_4  segment_prefix_ub_785  1
    load_0_15_4  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_627  -20
    arc_0_15_13  connected_order_arc_628  -13
    arc_0_15_13  in_degree_787  1
    arc_0_15_13  out_degree_798  1
    arc_0_15_13  original_T_including_depot_unload_837  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_627  1
    load_0_15_13  free_load_conservation_791  -1
    load_0_15_13  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_629  -20
    arc_0_15_14  connected_order_arc_630  -13
    arc_0_15_14  in_degree_793  1
    arc_0_15_14  out_degree_798  1
    arc_0_15_14  original_T_including_depot_unload_837  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_629  1
    load_0_15_14  free_load_conservation_797  -1
    load_0_15_14  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_631  -20
    arc_0_15_16  connected_order_arc_632  -13
    arc_0_15_16  out_degree_798  1
    arc_0_15_16  in_degree_805  1
    arc_0_15_16  original_T_including_depot_unload_837  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_631  1
    load_0_15_16  free_load_conservation_803  1
    load_0_15_16  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_633  -20
    arc_0_15_17  connected_order_arc_634  -13
    arc_0_15_17  out_degree_798  1
    arc_0_15_17  in_degree_811  1
    arc_0_15_17  original_T_including_depot_unload_837  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_633  1
    load_0_15_17  free_load_conservation_803  1
    load_0_15_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_635  -20
    arc_0_15_18  connected_order_arc_636  -13
    arc_0_15_18  out_degree_798  1
    arc_0_15_18  in_degree_817  1
    arc_0_15_18  original_T_including_depot_unload_837  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_635  1
    load_0_15_18  free_load_conservation_803  1
    load_0_15_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_637  -20
    arc_0_15_19  connected_order_arc_638  -13
    arc_0_15_19  out_degree_798  1
    arc_0_15_19  in_degree_823  1
    arc_0_15_19  original_T_including_depot_unload_837  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_637  1
    load_0_15_19  free_load_conservation_803  1
    load_0_15_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_639  -20
    arc_0_15_20  connected_order_arc_640  -13
    arc_0_15_20  out_degree_798  1
    arc_0_15_20  in_degree_829  1
    arc_0_15_20  original_T_including_depot_unload_837  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_639  1
    load_0_15_20  free_load_conservation_803  1
    load_0_15_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_641  -20
    arc_0_16_0  depot_return_or_bypass_757  1
    arc_0_16_0  out_degree_804  1
    arc_0_16_0  original_T_including_depot_unload_837  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_641  1
    load_0_16_0  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_642  -20
    arc_0_16_1  connected_order_arc_643  -13
    arc_0_16_1  in_degree_759  1
    arc_0_16_1  out_degree_804  1
    arc_0_16_1  original_T_including_depot_unload_837  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_642  1
    load_0_16_1  segment_load_conservation_762  -1
    load_0_16_1  segment_prefix_lb_763  1
    load_0_16_1  segment_prefix_ub_764  1
    load_0_16_1  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_644  -20
    arc_0_16_2  connected_order_arc_645  -13
    arc_0_16_2  in_degree_766  1
    arc_0_16_2  out_degree_804  1
    arc_0_16_2  original_T_including_depot_unload_837  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_644  1
    load_0_16_2  segment_load_conservation_769  -1
    load_0_16_2  segment_prefix_lb_770  1
    load_0_16_2  segment_prefix_ub_771  1
    load_0_16_2  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_646  -20
    arc_0_16_3  connected_order_arc_647  -13
    arc_0_16_3  in_degree_773  1
    arc_0_16_3  out_degree_804  1
    arc_0_16_3  original_T_including_depot_unload_837  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_646  1
    load_0_16_3  segment_load_conservation_776  -1
    load_0_16_3  segment_prefix_lb_777  1
    load_0_16_3  segment_prefix_ub_778  1
    load_0_16_3  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_648  -20
    arc_0_16_4  connected_order_arc_649  -13
    arc_0_16_4  in_degree_780  1
    arc_0_16_4  out_degree_804  1
    arc_0_16_4  original_T_including_depot_unload_837  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_648  1
    load_0_16_4  segment_load_conservation_783  -1
    load_0_16_4  segment_prefix_lb_784  1
    load_0_16_4  segment_prefix_ub_785  1
    load_0_16_4  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_650  -20
    arc_0_16_13  connected_order_arc_651  -13
    arc_0_16_13  in_degree_787  1
    arc_0_16_13  out_degree_804  1
    arc_0_16_13  original_T_including_depot_unload_837  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_650  1
    load_0_16_13  free_load_conservation_791  -1
    load_0_16_13  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_652  -20
    arc_0_16_14  connected_order_arc_653  -13
    arc_0_16_14  in_degree_793  1
    arc_0_16_14  out_degree_804  1
    arc_0_16_14  original_T_including_depot_unload_837  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_652  1
    load_0_16_14  free_load_conservation_797  -1
    load_0_16_14  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_654  -20
    arc_0_16_15  connected_order_arc_655  -13
    arc_0_16_15  in_degree_799  1
    arc_0_16_15  out_degree_804  1
    arc_0_16_15  original_T_including_depot_unload_837  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_654  1
    load_0_16_15  free_load_conservation_803  -1
    load_0_16_15  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_656  -20
    arc_0_16_17  connected_order_arc_657  -13
    arc_0_16_17  out_degree_804  1
    arc_0_16_17  in_degree_811  1
    arc_0_16_17  original_T_including_depot_unload_837  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_656  1
    load_0_16_17  free_load_conservation_809  1
    load_0_16_17  free_load_conservation_815  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_658  -20
    arc_0_16_18  connected_order_arc_659  -13
    arc_0_16_18  out_degree_804  1
    arc_0_16_18  in_degree_817  1
    arc_0_16_18  original_T_including_depot_unload_837  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_658  1
    load_0_16_18  free_load_conservation_809  1
    load_0_16_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_660  -20
    arc_0_16_19  connected_order_arc_661  -13
    arc_0_16_19  out_degree_804  1
    arc_0_16_19  in_degree_823  1
    arc_0_16_19  original_T_including_depot_unload_837  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_660  1
    load_0_16_19  free_load_conservation_809  1
    load_0_16_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_662  -20
    arc_0_16_20  connected_order_arc_663  -13
    arc_0_16_20  out_degree_804  1
    arc_0_16_20  in_degree_829  1
    arc_0_16_20  original_T_including_depot_unload_837  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_662  1
    load_0_16_20  free_load_conservation_809  1
    load_0_16_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_664  -20
    arc_0_17_0  depot_return_or_bypass_757  1
    arc_0_17_0  out_degree_810  1
    arc_0_17_0  original_T_including_depot_unload_837  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_664  1
    load_0_17_0  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_665  -20
    arc_0_17_1  connected_order_arc_666  -13
    arc_0_17_1  in_degree_759  1
    arc_0_17_1  out_degree_810  1
    arc_0_17_1  original_T_including_depot_unload_837  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_665  1
    load_0_17_1  segment_load_conservation_762  -1
    load_0_17_1  segment_prefix_lb_763  1
    load_0_17_1  segment_prefix_ub_764  1
    load_0_17_1  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_667  -20
    arc_0_17_2  connected_order_arc_668  -13
    arc_0_17_2  in_degree_766  1
    arc_0_17_2  out_degree_810  1
    arc_0_17_2  original_T_including_depot_unload_837  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_667  1
    load_0_17_2  segment_load_conservation_769  -1
    load_0_17_2  segment_prefix_lb_770  1
    load_0_17_2  segment_prefix_ub_771  1
    load_0_17_2  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_669  -20
    arc_0_17_3  connected_order_arc_670  -13
    arc_0_17_3  in_degree_773  1
    arc_0_17_3  out_degree_810  1
    arc_0_17_3  original_T_including_depot_unload_837  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_669  1
    load_0_17_3  segment_load_conservation_776  -1
    load_0_17_3  segment_prefix_lb_777  1
    load_0_17_3  segment_prefix_ub_778  1
    load_0_17_3  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_671  -20
    arc_0_17_4  connected_order_arc_672  -13
    arc_0_17_4  in_degree_780  1
    arc_0_17_4  out_degree_810  1
    arc_0_17_4  original_T_including_depot_unload_837  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_671  1
    load_0_17_4  segment_load_conservation_783  -1
    load_0_17_4  segment_prefix_lb_784  1
    load_0_17_4  segment_prefix_ub_785  1
    load_0_17_4  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_673  -20
    arc_0_17_13  connected_order_arc_674  -13
    arc_0_17_13  in_degree_787  1
    arc_0_17_13  out_degree_810  1
    arc_0_17_13  original_T_including_depot_unload_837  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_673  1
    load_0_17_13  free_load_conservation_791  -1
    load_0_17_13  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_675  -20
    arc_0_17_14  connected_order_arc_676  -13
    arc_0_17_14  in_degree_793  1
    arc_0_17_14  out_degree_810  1
    arc_0_17_14  original_T_including_depot_unload_837  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_675  1
    load_0_17_14  free_load_conservation_797  -1
    load_0_17_14  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_677  -20
    arc_0_17_15  connected_order_arc_678  -13
    arc_0_17_15  in_degree_799  1
    arc_0_17_15  out_degree_810  1
    arc_0_17_15  original_T_including_depot_unload_837  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_677  1
    load_0_17_15  free_load_conservation_803  -1
    load_0_17_15  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_679  -20
    arc_0_17_16  connected_order_arc_680  -13
    arc_0_17_16  in_degree_805  1
    arc_0_17_16  out_degree_810  1
    arc_0_17_16  original_T_including_depot_unload_837  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_679  1
    load_0_17_16  free_load_conservation_809  -1
    load_0_17_16  free_load_conservation_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_681  -20
    arc_0_17_18  connected_order_arc_682  -13
    arc_0_17_18  out_degree_810  1
    arc_0_17_18  in_degree_817  1
    arc_0_17_18  original_T_including_depot_unload_837  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_681  1
    load_0_17_18  free_load_conservation_815  1
    load_0_17_18  free_load_conservation_821  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_683  -20
    arc_0_17_19  connected_order_arc_684  -13
    arc_0_17_19  out_degree_810  1
    arc_0_17_19  in_degree_823  1
    arc_0_17_19  original_T_including_depot_unload_837  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_683  1
    load_0_17_19  free_load_conservation_815  1
    load_0_17_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_685  -20
    arc_0_17_20  connected_order_arc_686  -13
    arc_0_17_20  out_degree_810  1
    arc_0_17_20  in_degree_829  1
    arc_0_17_20  original_T_including_depot_unload_837  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_685  1
    load_0_17_20  free_load_conservation_815  1
    load_0_17_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_687  -20
    arc_0_18_0  depot_return_or_bypass_757  1
    arc_0_18_0  out_degree_816  1
    arc_0_18_0  original_T_including_depot_unload_837  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_687  1
    load_0_18_0  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_688  -20
    arc_0_18_1  connected_order_arc_689  -13
    arc_0_18_1  in_degree_759  1
    arc_0_18_1  out_degree_816  1
    arc_0_18_1  original_T_including_depot_unload_837  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_688  1
    load_0_18_1  segment_load_conservation_762  -1
    load_0_18_1  segment_prefix_lb_763  1
    load_0_18_1  segment_prefix_ub_764  1
    load_0_18_1  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_690  -20
    arc_0_18_2  connected_order_arc_691  -13
    arc_0_18_2  in_degree_766  1
    arc_0_18_2  out_degree_816  1
    arc_0_18_2  original_T_including_depot_unload_837  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_690  1
    load_0_18_2  segment_load_conservation_769  -1
    load_0_18_2  segment_prefix_lb_770  1
    load_0_18_2  segment_prefix_ub_771  1
    load_0_18_2  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_692  -20
    arc_0_18_3  connected_order_arc_693  -13
    arc_0_18_3  in_degree_773  1
    arc_0_18_3  out_degree_816  1
    arc_0_18_3  original_T_including_depot_unload_837  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_692  1
    load_0_18_3  segment_load_conservation_776  -1
    load_0_18_3  segment_prefix_lb_777  1
    load_0_18_3  segment_prefix_ub_778  1
    load_0_18_3  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_694  -20
    arc_0_18_4  connected_order_arc_695  -13
    arc_0_18_4  in_degree_780  1
    arc_0_18_4  out_degree_816  1
    arc_0_18_4  original_T_including_depot_unload_837  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_694  1
    load_0_18_4  segment_load_conservation_783  -1
    load_0_18_4  segment_prefix_lb_784  1
    load_0_18_4  segment_prefix_ub_785  1
    load_0_18_4  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_696  -20
    arc_0_18_13  connected_order_arc_697  -13
    arc_0_18_13  in_degree_787  1
    arc_0_18_13  out_degree_816  1
    arc_0_18_13  original_T_including_depot_unload_837  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_696  1
    load_0_18_13  free_load_conservation_791  -1
    load_0_18_13  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_698  -20
    arc_0_18_14  connected_order_arc_699  -13
    arc_0_18_14  in_degree_793  1
    arc_0_18_14  out_degree_816  1
    arc_0_18_14  original_T_including_depot_unload_837  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_698  1
    load_0_18_14  free_load_conservation_797  -1
    load_0_18_14  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_700  -20
    arc_0_18_15  connected_order_arc_701  -13
    arc_0_18_15  in_degree_799  1
    arc_0_18_15  out_degree_816  1
    arc_0_18_15  original_T_including_depot_unload_837  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_700  1
    load_0_18_15  free_load_conservation_803  -1
    load_0_18_15  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_702  -20
    arc_0_18_16  connected_order_arc_703  -13
    arc_0_18_16  in_degree_805  1
    arc_0_18_16  out_degree_816  1
    arc_0_18_16  original_T_including_depot_unload_837  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_702  1
    load_0_18_16  free_load_conservation_809  -1
    load_0_18_16  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_704  -20
    arc_0_18_17  connected_order_arc_705  -13
    arc_0_18_17  in_degree_811  1
    arc_0_18_17  out_degree_816  1
    arc_0_18_17  original_T_including_depot_unload_837  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_704  1
    load_0_18_17  free_load_conservation_815  -1
    load_0_18_17  free_load_conservation_821  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_706  -20
    arc_0_18_19  connected_order_arc_707  -13
    arc_0_18_19  out_degree_816  1
    arc_0_18_19  in_degree_823  1
    arc_0_18_19  original_T_including_depot_unload_837  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_706  1
    load_0_18_19  free_load_conservation_821  1
    load_0_18_19  free_load_conservation_827  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_708  -20
    arc_0_18_20  connected_order_arc_709  -13
    arc_0_18_20  out_degree_816  1
    arc_0_18_20  in_degree_829  1
    arc_0_18_20  original_T_including_depot_unload_837  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_708  1
    load_0_18_20  free_load_conservation_821  1
    load_0_18_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_710  -20
    arc_0_19_0  depot_return_or_bypass_757  1
    arc_0_19_0  out_degree_822  1
    arc_0_19_0  original_T_including_depot_unload_837  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_710  1
    load_0_19_0  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_711  -20
    arc_0_19_1  connected_order_arc_712  -13
    arc_0_19_1  in_degree_759  1
    arc_0_19_1  out_degree_822  1
    arc_0_19_1  original_T_including_depot_unload_837  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_711  1
    load_0_19_1  segment_load_conservation_762  -1
    load_0_19_1  segment_prefix_lb_763  1
    load_0_19_1  segment_prefix_ub_764  1
    load_0_19_1  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_713  -20
    arc_0_19_2  connected_order_arc_714  -13
    arc_0_19_2  in_degree_766  1
    arc_0_19_2  out_degree_822  1
    arc_0_19_2  original_T_including_depot_unload_837  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_713  1
    load_0_19_2  segment_load_conservation_769  -1
    load_0_19_2  segment_prefix_lb_770  1
    load_0_19_2  segment_prefix_ub_771  1
    load_0_19_2  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_715  -20
    arc_0_19_3  connected_order_arc_716  -13
    arc_0_19_3  in_degree_773  1
    arc_0_19_3  out_degree_822  1
    arc_0_19_3  original_T_including_depot_unload_837  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_715  1
    load_0_19_3  segment_load_conservation_776  -1
    load_0_19_3  segment_prefix_lb_777  1
    load_0_19_3  segment_prefix_ub_778  1
    load_0_19_3  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_717  -20
    arc_0_19_4  connected_order_arc_718  -13
    arc_0_19_4  in_degree_780  1
    arc_0_19_4  out_degree_822  1
    arc_0_19_4  original_T_including_depot_unload_837  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_717  1
    load_0_19_4  segment_load_conservation_783  -1
    load_0_19_4  segment_prefix_lb_784  1
    load_0_19_4  segment_prefix_ub_785  1
    load_0_19_4  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_719  -20
    arc_0_19_13  connected_order_arc_720  -13
    arc_0_19_13  in_degree_787  1
    arc_0_19_13  out_degree_822  1
    arc_0_19_13  original_T_including_depot_unload_837  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_719  1
    load_0_19_13  free_load_conservation_791  -1
    load_0_19_13  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_721  -20
    arc_0_19_14  connected_order_arc_722  -13
    arc_0_19_14  in_degree_793  1
    arc_0_19_14  out_degree_822  1
    arc_0_19_14  original_T_including_depot_unload_837  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_721  1
    load_0_19_14  free_load_conservation_797  -1
    load_0_19_14  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_723  -20
    arc_0_19_15  connected_order_arc_724  -13
    arc_0_19_15  in_degree_799  1
    arc_0_19_15  out_degree_822  1
    arc_0_19_15  original_T_including_depot_unload_837  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_723  1
    load_0_19_15  free_load_conservation_803  -1
    load_0_19_15  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_725  -20
    arc_0_19_16  connected_order_arc_726  -13
    arc_0_19_16  in_degree_805  1
    arc_0_19_16  out_degree_822  1
    arc_0_19_16  original_T_including_depot_unload_837  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_725  1
    load_0_19_16  free_load_conservation_809  -1
    load_0_19_16  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_727  -20
    arc_0_19_17  connected_order_arc_728  -13
    arc_0_19_17  in_degree_811  1
    arc_0_19_17  out_degree_822  1
    arc_0_19_17  original_T_including_depot_unload_837  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_727  1
    load_0_19_17  free_load_conservation_815  -1
    load_0_19_17  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_729  -20
    arc_0_19_18  connected_order_arc_730  -13
    arc_0_19_18  in_degree_817  1
    arc_0_19_18  out_degree_822  1
    arc_0_19_18  original_T_including_depot_unload_837  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_729  1
    load_0_19_18  free_load_conservation_821  -1
    load_0_19_18  free_load_conservation_827  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_731  -20
    arc_0_19_20  connected_order_arc_732  -13
    arc_0_19_20  out_degree_822  1
    arc_0_19_20  in_degree_829  1
    arc_0_19_20  original_T_including_depot_unload_837  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_731  1
    load_0_19_20  free_load_conservation_827  1
    load_0_19_20  free_load_conservation_833  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_733  -20
    arc_0_20_0  depot_return_or_bypass_757  1
    arc_0_20_0  out_degree_828  1
    arc_0_20_0  original_T_including_depot_unload_837  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_733  1
    load_0_20_0  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_734  -20
    arc_0_20_1  connected_order_arc_735  -13
    arc_0_20_1  in_degree_759  1
    arc_0_20_1  out_degree_828  1
    arc_0_20_1  original_T_including_depot_unload_837  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_734  1
    load_0_20_1  segment_load_conservation_762  -1
    load_0_20_1  segment_prefix_lb_763  1
    load_0_20_1  segment_prefix_ub_764  1
    load_0_20_1  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_736  -20
    arc_0_20_2  connected_order_arc_737  -13
    arc_0_20_2  in_degree_766  1
    arc_0_20_2  out_degree_828  1
    arc_0_20_2  original_T_including_depot_unload_837  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_736  1
    load_0_20_2  segment_load_conservation_769  -1
    load_0_20_2  segment_prefix_lb_770  1
    load_0_20_2  segment_prefix_ub_771  1
    load_0_20_2  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_738  -20
    arc_0_20_3  connected_order_arc_739  -13
    arc_0_20_3  in_degree_773  1
    arc_0_20_3  out_degree_828  1
    arc_0_20_3  original_T_including_depot_unload_837  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_738  1
    load_0_20_3  segment_load_conservation_776  -1
    load_0_20_3  segment_prefix_lb_777  1
    load_0_20_3  segment_prefix_ub_778  1
    load_0_20_3  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_740  -20
    arc_0_20_4  connected_order_arc_741  -13
    arc_0_20_4  in_degree_780  1
    arc_0_20_4  out_degree_828  1
    arc_0_20_4  original_T_including_depot_unload_837  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_740  1
    load_0_20_4  segment_load_conservation_783  -1
    load_0_20_4  segment_prefix_lb_784  1
    load_0_20_4  segment_prefix_ub_785  1
    load_0_20_4  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_742  -20
    arc_0_20_13  connected_order_arc_743  -13
    arc_0_20_13  in_degree_787  1
    arc_0_20_13  out_degree_828  1
    arc_0_20_13  original_T_including_depot_unload_837  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_742  1
    load_0_20_13  free_load_conservation_791  -1
    load_0_20_13  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_744  -20
    arc_0_20_14  connected_order_arc_745  -13
    arc_0_20_14  in_degree_793  1
    arc_0_20_14  out_degree_828  1
    arc_0_20_14  original_T_including_depot_unload_837  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_744  1
    load_0_20_14  free_load_conservation_797  -1
    load_0_20_14  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_746  -20
    arc_0_20_15  connected_order_arc_747  -13
    arc_0_20_15  in_degree_799  1
    arc_0_20_15  out_degree_828  1
    arc_0_20_15  original_T_including_depot_unload_837  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_746  1
    load_0_20_15  free_load_conservation_803  -1
    load_0_20_15  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_748  -20
    arc_0_20_16  connected_order_arc_749  -13
    arc_0_20_16  in_degree_805  1
    arc_0_20_16  out_degree_828  1
    arc_0_20_16  original_T_including_depot_unload_837  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_748  1
    load_0_20_16  free_load_conservation_809  -1
    load_0_20_16  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_750  -20
    arc_0_20_17  connected_order_arc_751  -13
    arc_0_20_17  in_degree_811  1
    arc_0_20_17  out_degree_828  1
    arc_0_20_17  original_T_including_depot_unload_837  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_750  1
    load_0_20_17  free_load_conservation_815  -1
    load_0_20_17  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_752  -20
    arc_0_20_18  connected_order_arc_753  -13
    arc_0_20_18  in_degree_817  1
    arc_0_20_18  out_degree_828  1
    arc_0_20_18  original_T_including_depot_unload_837  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_752  1
    load_0_20_18  free_load_conservation_821  -1
    load_0_20_18  free_load_conservation_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_754  -20
    arc_0_20_19  connected_order_arc_755  -13
    arc_0_20_19  in_degree_823  1
    arc_0_20_19  out_degree_828  1
    arc_0_20_19  original_T_including_depot_unload_837  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_754  1
    load_0_20_19  free_load_conservation_827  -1
    load_0_20_19  free_load_conservation_833  1
    visit_1_5  out_degree_1179  -1
    visit_1_5  in_degree_1180  -1
    visit_1_5  order_active_lb_1181  -1
    visit_1_5  order_active_ub_1182  -13
    order_1_5  connected_order_arc_854  -1
    order_1_5  connected_order_arc_856  -1
    order_1_5  connected_order_arc_858  -1
    order_1_5  connected_order_arc_860  -1
    order_1_5  connected_order_arc_862  -1
    order_1_5  connected_order_arc_864  -1
    order_1_5  connected_order_arc_866  -1
    order_1_5  connected_order_arc_868  -1
    order_1_5  connected_order_arc_870  -1
    order_1_5  connected_order_arc_872  -1
    order_1_5  connected_order_arc_874  -1
    order_1_5  connected_order_arc_876  -1
    order_1_5  connected_order_arc_879  1
    order_1_5  connected_order_arc_904  1
    order_1_5  connected_order_arc_929  1
    order_1_5  connected_order_arc_954  1
    order_1_5  connected_order_arc_979  1
    order_1_5  connected_order_arc_1004  1
    order_1_5  connected_order_arc_1029  1
    order_1_5  connected_order_arc_1054  1
    order_1_5  connected_order_arc_1079  1
    order_1_5  connected_order_arc_1104  1
    order_1_5  connected_order_arc_1129  1
    order_1_5  connected_order_arc_1154  1
    order_1_5  order_active_lb_1181  1
    order_1_5  order_active_ub_1182  1
    order_1_5  fixed_segment_relative_order_1262  -1
    visit_1_6  out_degree_1186  -1
    visit_1_6  in_degree_1187  -1
    visit_1_6  order_active_lb_1188  -1
    visit_1_6  order_active_ub_1189  -13
    order_1_6  connected_order_arc_854  1
    order_1_6  connected_order_arc_879  -1
    order_1_6  connected_order_arc_881  -1
    order_1_6  connected_order_arc_883  -1
    order_1_6  connected_order_arc_885  -1
    order_1_6  connected_order_arc_887  -1
    order_1_6  connected_order_arc_889  -1
    order_1_6  connected_order_arc_891  -1
    order_1_6  connected_order_arc_893  -1
    order_1_6  connected_order_arc_895  -1
    order_1_6  connected_order_arc_897  -1
    order_1_6  connected_order_arc_899  -1
    order_1_6  connected_order_arc_901  -1
    order_1_6  connected_order_arc_906  1
    order_1_6  connected_order_arc_931  1
    order_1_6  connected_order_arc_956  1
    order_1_6  connected_order_arc_981  1
    order_1_6  connected_order_arc_1006  1
    order_1_6  connected_order_arc_1031  1
    order_1_6  connected_order_arc_1056  1
    order_1_6  connected_order_arc_1081  1
    order_1_6  connected_order_arc_1106  1
    order_1_6  connected_order_arc_1131  1
    order_1_6  connected_order_arc_1156  1
    order_1_6  order_active_lb_1188  1
    order_1_6  order_active_ub_1189  1
    order_1_6  fixed_segment_relative_order_1262  1
    order_1_6  fixed_segment_relative_order_1263  -1
    visit_1_7  out_degree_1193  -1
    visit_1_7  in_degree_1194  -1
    visit_1_7  order_active_lb_1195  -1
    visit_1_7  order_active_ub_1196  -13
    order_1_7  connected_order_arc_856  1
    order_1_7  connected_order_arc_881  1
    order_1_7  connected_order_arc_904  -1
    order_1_7  connected_order_arc_906  -1
    order_1_7  connected_order_arc_908  -1
    order_1_7  connected_order_arc_910  -1
    order_1_7  connected_order_arc_912  -1
    order_1_7  connected_order_arc_914  -1
    order_1_7  connected_order_arc_916  -1
    order_1_7  connected_order_arc_918  -1
    order_1_7  connected_order_arc_920  -1
    order_1_7  connected_order_arc_922  -1
    order_1_7  connected_order_arc_924  -1
    order_1_7  connected_order_arc_926  -1
    order_1_7  connected_order_arc_933  1
    order_1_7  connected_order_arc_958  1
    order_1_7  connected_order_arc_983  1
    order_1_7  connected_order_arc_1008  1
    order_1_7  connected_order_arc_1033  1
    order_1_7  connected_order_arc_1058  1
    order_1_7  connected_order_arc_1083  1
    order_1_7  connected_order_arc_1108  1
    order_1_7  connected_order_arc_1133  1
    order_1_7  connected_order_arc_1158  1
    order_1_7  order_active_lb_1195  1
    order_1_7  order_active_ub_1196  1
    order_1_7  fixed_segment_relative_order_1263  1
    order_1_7  fixed_segment_relative_order_1264  -1
    visit_1_8  out_degree_1200  -1
    visit_1_8  in_degree_1201  -1
    visit_1_8  order_active_lb_1202  -1
    visit_1_8  order_active_ub_1203  -13
    order_1_8  connected_order_arc_858  1
    order_1_8  connected_order_arc_883  1
    order_1_8  connected_order_arc_908  1
    order_1_8  connected_order_arc_929  -1
    order_1_8  connected_order_arc_931  -1
    order_1_8  connected_order_arc_933  -1
    order_1_8  connected_order_arc_935  -1
    order_1_8  connected_order_arc_937  -1
    order_1_8  connected_order_arc_939  -1
    order_1_8  connected_order_arc_941  -1
    order_1_8  connected_order_arc_943  -1
    order_1_8  connected_order_arc_945  -1
    order_1_8  connected_order_arc_947  -1
    order_1_8  connected_order_arc_949  -1
    order_1_8  connected_order_arc_951  -1
    order_1_8  connected_order_arc_960  1
    order_1_8  connected_order_arc_985  1
    order_1_8  connected_order_arc_1010  1
    order_1_8  connected_order_arc_1035  1
    order_1_8  connected_order_arc_1060  1
    order_1_8  connected_order_arc_1085  1
    order_1_8  connected_order_arc_1110  1
    order_1_8  connected_order_arc_1135  1
    order_1_8  connected_order_arc_1160  1
    order_1_8  order_active_lb_1202  1
    order_1_8  order_active_ub_1203  1
    order_1_8  fixed_segment_relative_order_1264  1
    order_1_8  fixed_segment_relative_order_1265  -1
    visit_1_9  out_degree_1207  -1
    visit_1_9  in_degree_1208  -1
    visit_1_9  order_active_lb_1209  -1
    visit_1_9  order_active_ub_1210  -13
    order_1_9  connected_order_arc_860  1
    order_1_9  connected_order_arc_885  1
    order_1_9  connected_order_arc_910  1
    order_1_9  connected_order_arc_935  1
    order_1_9  connected_order_arc_954  -1
    order_1_9  connected_order_arc_956  -1
    order_1_9  connected_order_arc_958  -1
    order_1_9  connected_order_arc_960  -1
    order_1_9  connected_order_arc_962  -1
    order_1_9  connected_order_arc_964  -1
    order_1_9  connected_order_arc_966  -1
    order_1_9  connected_order_arc_968  -1
    order_1_9  connected_order_arc_970  -1
    order_1_9  connected_order_arc_972  -1
    order_1_9  connected_order_arc_974  -1
    order_1_9  connected_order_arc_976  -1
    order_1_9  connected_order_arc_987  1
    order_1_9  connected_order_arc_1012  1
    order_1_9  connected_order_arc_1037  1
    order_1_9  connected_order_arc_1062  1
    order_1_9  connected_order_arc_1087  1
    order_1_9  connected_order_arc_1112  1
    order_1_9  connected_order_arc_1137  1
    order_1_9  connected_order_arc_1162  1
    order_1_9  order_active_lb_1209  1
    order_1_9  order_active_ub_1210  1
    order_1_9  fixed_segment_relative_order_1265  1
    visit_1_13  out_degree_1214  -1
    visit_1_13  in_degree_1215  -1
    visit_1_13  order_active_lb_1216  -1
    visit_1_13  order_active_ub_1217  -13
    visit_1_13  service_visit_def_1218  -1
    order_1_13  connected_order_arc_862  1
    order_1_13  connected_order_arc_887  1
    order_1_13  connected_order_arc_912  1
    order_1_13  connected_order_arc_937  1
    order_1_13  connected_order_arc_962  1
    order_1_13  connected_order_arc_979  -1
    order_1_13  connected_order_arc_981  -1
    order_1_13  connected_order_arc_983  -1
    order_1_13  connected_order_arc_985  -1
    order_1_13  connected_order_arc_987  -1
    order_1_13  connected_order_arc_989  -1
    order_1_13  connected_order_arc_991  -1
    order_1_13  connected_order_arc_993  -1
    order_1_13  connected_order_arc_995  -1
    order_1_13  connected_order_arc_997  -1
    order_1_13  connected_order_arc_999  -1
    order_1_13  connected_order_arc_1001  -1
    order_1_13  connected_order_arc_1014  1
    order_1_13  connected_order_arc_1039  1
    order_1_13  connected_order_arc_1064  1
    order_1_13  connected_order_arc_1089  1
    order_1_13  connected_order_arc_1114  1
    order_1_13  connected_order_arc_1139  1
    order_1_13  connected_order_arc_1164  1
    order_1_13  order_active_lb_1216  1
    order_1_13  order_active_ub_1217  1
    visit_1_14  out_degree_1220  -1
    visit_1_14  in_degree_1221  -1
    visit_1_14  order_active_lb_1222  -1
    visit_1_14  order_active_ub_1223  -13
    visit_1_14  service_visit_def_1224  -1
    order_1_14  connected_order_arc_864  1
    order_1_14  connected_order_arc_889  1
    order_1_14  connected_order_arc_914  1
    order_1_14  connected_order_arc_939  1
    order_1_14  connected_order_arc_964  1
    order_1_14  connected_order_arc_989  1
    order_1_14  connected_order_arc_1004  -1
    order_1_14  connected_order_arc_1006  -1
    order_1_14  connected_order_arc_1008  -1
    order_1_14  connected_order_arc_1010  -1
    order_1_14  connected_order_arc_1012  -1
    order_1_14  connected_order_arc_1014  -1
    order_1_14  connected_order_arc_1016  -1
    order_1_14  connected_order_arc_1018  -1
    order_1_14  connected_order_arc_1020  -1
    order_1_14  connected_order_arc_1022  -1
    order_1_14  connected_order_arc_1024  -1
    order_1_14  connected_order_arc_1026  -1
    order_1_14  connected_order_arc_1041  1
    order_1_14  connected_order_arc_1066  1
    order_1_14  connected_order_arc_1091  1
    order_1_14  connected_order_arc_1116  1
    order_1_14  connected_order_arc_1141  1
    order_1_14  connected_order_arc_1166  1
    order_1_14  order_active_lb_1222  1
    order_1_14  order_active_ub_1223  1
    visit_1_15  out_degree_1226  -1
    visit_1_15  in_degree_1227  -1
    visit_1_15  order_active_lb_1228  -1
    visit_1_15  order_active_ub_1229  -13
    visit_1_15  service_visit_def_1230  -1
    order_1_15  connected_order_arc_866  1
    order_1_15  connected_order_arc_891  1
    order_1_15  connected_order_arc_916  1
    order_1_15  connected_order_arc_941  1
    order_1_15  connected_order_arc_966  1
    order_1_15  connected_order_arc_991  1
    order_1_15  connected_order_arc_1016  1
    order_1_15  connected_order_arc_1029  -1
    order_1_15  connected_order_arc_1031  -1
    order_1_15  connected_order_arc_1033  -1
    order_1_15  connected_order_arc_1035  -1
    order_1_15  connected_order_arc_1037  -1
    order_1_15  connected_order_arc_1039  -1
    order_1_15  connected_order_arc_1041  -1
    order_1_15  connected_order_arc_1043  -1
    order_1_15  connected_order_arc_1045  -1
    order_1_15  connected_order_arc_1047  -1
    order_1_15  connected_order_arc_1049  -1
    order_1_15  connected_order_arc_1051  -1
    order_1_15  connected_order_arc_1068  1
    order_1_15  connected_order_arc_1093  1
    order_1_15  connected_order_arc_1118  1
    order_1_15  connected_order_arc_1143  1
    order_1_15  connected_order_arc_1168  1
    order_1_15  order_active_lb_1228  1
    order_1_15  order_active_ub_1229  1
    visit_1_16  out_degree_1232  -1
    visit_1_16  in_degree_1233  -1
    visit_1_16  order_active_lb_1234  -1
    visit_1_16  order_active_ub_1235  -13
    visit_1_16  service_visit_def_1236  -1
    order_1_16  connected_order_arc_868  1
    order_1_16  connected_order_arc_893  1
    order_1_16  connected_order_arc_918  1
    order_1_16  connected_order_arc_943  1
    order_1_16  connected_order_arc_968  1
    order_1_16  connected_order_arc_993  1
    order_1_16  connected_order_arc_1018  1
    order_1_16  connected_order_arc_1043  1
    order_1_16  connected_order_arc_1054  -1
    order_1_16  connected_order_arc_1056  -1
    order_1_16  connected_order_arc_1058  -1
    order_1_16  connected_order_arc_1060  -1
    order_1_16  connected_order_arc_1062  -1
    order_1_16  connected_order_arc_1064  -1
    order_1_16  connected_order_arc_1066  -1
    order_1_16  connected_order_arc_1068  -1
    order_1_16  connected_order_arc_1070  -1
    order_1_16  connected_order_arc_1072  -1
    order_1_16  connected_order_arc_1074  -1
    order_1_16  connected_order_arc_1076  -1
    order_1_16  connected_order_arc_1095  1
    order_1_16  connected_order_arc_1120  1
    order_1_16  connected_order_arc_1145  1
    order_1_16  connected_order_arc_1170  1
    order_1_16  order_active_lb_1234  1
    order_1_16  order_active_ub_1235  1
    visit_1_17  out_degree_1238  -1
    visit_1_17  in_degree_1239  -1
    visit_1_17  order_active_lb_1240  -1
    visit_1_17  order_active_ub_1241  -13
    visit_1_17  service_visit_def_1242  -1
    order_1_17  connected_order_arc_870  1
    order_1_17  connected_order_arc_895  1
    order_1_17  connected_order_arc_920  1
    order_1_17  connected_order_arc_945  1
    order_1_17  connected_order_arc_970  1
    order_1_17  connected_order_arc_995  1
    order_1_17  connected_order_arc_1020  1
    order_1_17  connected_order_arc_1045  1
    order_1_17  connected_order_arc_1070  1
    order_1_17  connected_order_arc_1079  -1
    order_1_17  connected_order_arc_1081  -1
    order_1_17  connected_order_arc_1083  -1
    order_1_17  connected_order_arc_1085  -1
    order_1_17  connected_order_arc_1087  -1
    order_1_17  connected_order_arc_1089  -1
    order_1_17  connected_order_arc_1091  -1
    order_1_17  connected_order_arc_1093  -1
    order_1_17  connected_order_arc_1095  -1
    order_1_17  connected_order_arc_1097  -1
    order_1_17  connected_order_arc_1099  -1
    order_1_17  connected_order_arc_1101  -1
    order_1_17  connected_order_arc_1122  1
    order_1_17  connected_order_arc_1147  1
    order_1_17  connected_order_arc_1172  1
    order_1_17  order_active_lb_1240  1
    order_1_17  order_active_ub_1241  1
    visit_1_18  out_degree_1244  -1
    visit_1_18  in_degree_1245  -1
    visit_1_18  order_active_lb_1246  -1
    visit_1_18  order_active_ub_1247  -13
    visit_1_18  service_visit_def_1248  -1
    order_1_18  connected_order_arc_872  1
    order_1_18  connected_order_arc_897  1
    order_1_18  connected_order_arc_922  1
    order_1_18  connected_order_arc_947  1
    order_1_18  connected_order_arc_972  1
    order_1_18  connected_order_arc_997  1
    order_1_18  connected_order_arc_1022  1
    order_1_18  connected_order_arc_1047  1
    order_1_18  connected_order_arc_1072  1
    order_1_18  connected_order_arc_1097  1
    order_1_18  connected_order_arc_1104  -1
    order_1_18  connected_order_arc_1106  -1
    order_1_18  connected_order_arc_1108  -1
    order_1_18  connected_order_arc_1110  -1
    order_1_18  connected_order_arc_1112  -1
    order_1_18  connected_order_arc_1114  -1
    order_1_18  connected_order_arc_1116  -1
    order_1_18  connected_order_arc_1118  -1
    order_1_18  connected_order_arc_1120  -1
    order_1_18  connected_order_arc_1122  -1
    order_1_18  connected_order_arc_1124  -1
    order_1_18  connected_order_arc_1126  -1
    order_1_18  connected_order_arc_1149  1
    order_1_18  connected_order_arc_1174  1
    order_1_18  order_active_lb_1246  1
    order_1_18  order_active_ub_1247  1
    visit_1_19  out_degree_1250  -1
    visit_1_19  in_degree_1251  -1
    visit_1_19  order_active_lb_1252  -1
    visit_1_19  order_active_ub_1253  -13
    visit_1_19  service_visit_def_1254  -1
    order_1_19  connected_order_arc_874  1
    order_1_19  connected_order_arc_899  1
    order_1_19  connected_order_arc_924  1
    order_1_19  connected_order_arc_949  1
    order_1_19  connected_order_arc_974  1
    order_1_19  connected_order_arc_999  1
    order_1_19  connected_order_arc_1024  1
    order_1_19  connected_order_arc_1049  1
    order_1_19  connected_order_arc_1074  1
    order_1_19  connected_order_arc_1099  1
    order_1_19  connected_order_arc_1124  1
    order_1_19  connected_order_arc_1129  -1
    order_1_19  connected_order_arc_1131  -1
    order_1_19  connected_order_arc_1133  -1
    order_1_19  connected_order_arc_1135  -1
    order_1_19  connected_order_arc_1137  -1
    order_1_19  connected_order_arc_1139  -1
    order_1_19  connected_order_arc_1141  -1
    order_1_19  connected_order_arc_1143  -1
    order_1_19  connected_order_arc_1145  -1
    order_1_19  connected_order_arc_1147  -1
    order_1_19  connected_order_arc_1149  -1
    order_1_19  connected_order_arc_1151  -1
    order_1_19  connected_order_arc_1176  1
    order_1_19  order_active_lb_1252  1
    order_1_19  order_active_ub_1253  1
    visit_1_20  out_degree_1256  -1
    visit_1_20  in_degree_1257  -1
    visit_1_20  order_active_lb_1258  -1
    visit_1_20  order_active_ub_1259  -13
    visit_1_20  service_visit_def_1260  -1
    order_1_20  connected_order_arc_876  1
    order_1_20  connected_order_arc_901  1
    order_1_20  connected_order_arc_926  1
    order_1_20  connected_order_arc_951  1
    order_1_20  connected_order_arc_976  1
    order_1_20  connected_order_arc_1001  1
    order_1_20  connected_order_arc_1026  1
    order_1_20  connected_order_arc_1051  1
    order_1_20  connected_order_arc_1076  1
    order_1_20  connected_order_arc_1101  1
    order_1_20  connected_order_arc_1126  1
    order_1_20  connected_order_arc_1151  1
    order_1_20  connected_order_arc_1154  -1
    order_1_20  connected_order_arc_1156  -1
    order_1_20  connected_order_arc_1158  -1
    order_1_20  connected_order_arc_1160  -1
    order_1_20  connected_order_arc_1162  -1
    order_1_20  connected_order_arc_1164  -1
    order_1_20  connected_order_arc_1166  -1
    order_1_20  connected_order_arc_1168  -1
    order_1_20  connected_order_arc_1170  -1
    order_1_20  connected_order_arc_1172  -1
    order_1_20  connected_order_arc_1174  -1
    order_1_20  connected_order_arc_1176  -1
    order_1_20  order_active_lb_1258  1
    order_1_20  order_active_ub_1259  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_838  -25
    arc_1_0_0  depot_departure_or_bypass_1177  1
    arc_1_0_0  depot_return_or_bypass_1178  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_838  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_839  -25
    arc_1_0_5  depot_departure_or_bypass_1177  1
    arc_1_0_5  in_degree_1180  1
    arc_1_0_5  original_T_including_depot_unload_1266  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_839  1
    load_1_0_5  segment_load_conservation_1183  -1
    load_1_0_5  segment_prefix_lb_1184  1
    load_1_0_5  segment_prefix_ub_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_840  -25
    arc_1_0_6  depot_departure_or_bypass_1177  1
    arc_1_0_6  in_degree_1187  1
    arc_1_0_6  original_T_including_depot_unload_1266  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_840  1
    load_1_0_6  segment_load_conservation_1190  -1
    load_1_0_6  segment_prefix_lb_1191  1
    load_1_0_6  segment_prefix_ub_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_841  -25
    arc_1_0_7  depot_departure_or_bypass_1177  1
    arc_1_0_7  in_degree_1194  1
    arc_1_0_7  original_T_including_depot_unload_1266  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_841  1
    load_1_0_7  segment_load_conservation_1197  -1
    load_1_0_7  segment_prefix_lb_1198  1
    load_1_0_7  segment_prefix_ub_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_842  -25
    arc_1_0_8  depot_departure_or_bypass_1177  1
    arc_1_0_8  in_degree_1201  1
    arc_1_0_8  original_T_including_depot_unload_1266  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_842  1
    load_1_0_8  segment_load_conservation_1204  -1
    load_1_0_8  segment_prefix_lb_1205  1
    load_1_0_8  segment_prefix_ub_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_843  -25
    arc_1_0_9  depot_departure_or_bypass_1177  1
    arc_1_0_9  in_degree_1208  1
    arc_1_0_9  original_T_including_depot_unload_1266  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_843  1
    load_1_0_9  segment_load_conservation_1211  -1
    load_1_0_9  segment_prefix_lb_1212  1
    load_1_0_9  segment_prefix_ub_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_844  -25
    arc_1_0_13  depot_departure_or_bypass_1177  1
    arc_1_0_13  in_degree_1215  1
    arc_1_0_13  original_T_including_depot_unload_1266  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_844  1
    load_1_0_13  free_load_conservation_1219  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_845  -25
    arc_1_0_14  depot_departure_or_bypass_1177  1
    arc_1_0_14  in_degree_1221  1
    arc_1_0_14  original_T_including_depot_unload_1266  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_845  1
    load_1_0_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_846  -25
    arc_1_0_15  depot_departure_or_bypass_1177  1
    arc_1_0_15  in_degree_1227  1
    arc_1_0_15  original_T_including_depot_unload_1266  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_846  1
    load_1_0_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_847  -25
    arc_1_0_16  depot_departure_or_bypass_1177  1
    arc_1_0_16  in_degree_1233  1
    arc_1_0_16  original_T_including_depot_unload_1266  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_847  1
    load_1_0_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_848  -25
    arc_1_0_17  depot_departure_or_bypass_1177  1
    arc_1_0_17  in_degree_1239  1
    arc_1_0_17  original_T_including_depot_unload_1266  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_848  1
    load_1_0_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_849  -25
    arc_1_0_18  depot_departure_or_bypass_1177  1
    arc_1_0_18  in_degree_1245  1
    arc_1_0_18  original_T_including_depot_unload_1266  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_849  1
    load_1_0_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_850  -25
    arc_1_0_19  depot_departure_or_bypass_1177  1
    arc_1_0_19  in_degree_1251  1
    arc_1_0_19  original_T_including_depot_unload_1266  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_850  1
    load_1_0_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_851  -25
    arc_1_0_20  depot_departure_or_bypass_1177  1
    arc_1_0_20  in_degree_1257  1
    arc_1_0_20  original_T_including_depot_unload_1266  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_851  1
    load_1_0_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_852  -25
    arc_1_5_0  depot_return_or_bypass_1178  1
    arc_1_5_0  out_degree_1179  1
    arc_1_5_0  original_T_including_depot_unload_1266  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_852  1
    load_1_5_0  segment_load_conservation_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_853  -25
    arc_1_5_6  connected_order_arc_854  -14
    arc_1_5_6  out_degree_1179  1
    arc_1_5_6  in_degree_1187  1
    arc_1_5_6  original_T_including_depot_unload_1266  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_853  1
    load_1_5_6  segment_load_conservation_1183  1
    load_1_5_6  segment_load_conservation_1190  -1
    load_1_5_6  segment_prefix_lb_1191  1
    load_1_5_6  segment_prefix_ub_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_855  -25
    arc_1_5_7  connected_order_arc_856  -14
    arc_1_5_7  out_degree_1179  1
    arc_1_5_7  in_degree_1194  1
    arc_1_5_7  original_T_including_depot_unload_1266  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_855  1
    load_1_5_7  segment_load_conservation_1183  1
    load_1_5_7  segment_load_conservation_1197  -1
    load_1_5_7  segment_prefix_lb_1198  1
    load_1_5_7  segment_prefix_ub_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_857  -25
    arc_1_5_8  connected_order_arc_858  -14
    arc_1_5_8  out_degree_1179  1
    arc_1_5_8  in_degree_1201  1
    arc_1_5_8  original_T_including_depot_unload_1266  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_857  1
    load_1_5_8  segment_load_conservation_1183  1
    load_1_5_8  segment_load_conservation_1204  -1
    load_1_5_8  segment_prefix_lb_1205  1
    load_1_5_8  segment_prefix_ub_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_9  arc_capacity_859  -25
    arc_1_5_9  connected_order_arc_860  -14
    arc_1_5_9  out_degree_1179  1
    arc_1_5_9  in_degree_1208  1
    arc_1_5_9  original_T_including_depot_unload_1266  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_9  arc_capacity_859  1
    load_1_5_9  segment_load_conservation_1183  1
    load_1_5_9  segment_load_conservation_1211  -1
    load_1_5_9  segment_prefix_lb_1212  1
    load_1_5_9  segment_prefix_ub_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_861  -25
    arc_1_5_13  connected_order_arc_862  -14
    arc_1_5_13  out_degree_1179  1
    arc_1_5_13  in_degree_1215  1
    arc_1_5_13  original_T_including_depot_unload_1266  1.5223381412470410e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_861  1
    load_1_5_13  segment_load_conservation_1183  1
    load_1_5_13  free_load_conservation_1219  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_863  -25
    arc_1_5_14  connected_order_arc_864  -14
    arc_1_5_14  out_degree_1179  1
    arc_1_5_14  in_degree_1221  1
    arc_1_5_14  original_T_including_depot_unload_1266  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_863  1
    load_1_5_14  segment_load_conservation_1183  1
    load_1_5_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_865  -25
    arc_1_5_15  connected_order_arc_866  -14
    arc_1_5_15  out_degree_1179  1
    arc_1_5_15  in_degree_1227  1
    arc_1_5_15  original_T_including_depot_unload_1266  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_865  1
    load_1_5_15  segment_load_conservation_1183  1
    load_1_5_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_867  -25
    arc_1_5_16  connected_order_arc_868  -14
    arc_1_5_16  out_degree_1179  1
    arc_1_5_16  in_degree_1233  1
    arc_1_5_16  original_T_including_depot_unload_1266  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_867  1
    load_1_5_16  segment_load_conservation_1183  1
    load_1_5_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_869  -25
    arc_1_5_17  connected_order_arc_870  -14
    arc_1_5_17  out_degree_1179  1
    arc_1_5_17  in_degree_1239  1
    arc_1_5_17  original_T_including_depot_unload_1266  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_869  1
    load_1_5_17  segment_load_conservation_1183  1
    load_1_5_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_871  -25
    arc_1_5_18  connected_order_arc_872  -14
    arc_1_5_18  out_degree_1179  1
    arc_1_5_18  in_degree_1245  1
    arc_1_5_18  original_T_including_depot_unload_1266  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_871  1
    load_1_5_18  segment_load_conservation_1183  1
    load_1_5_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_873  -25
    arc_1_5_19  connected_order_arc_874  -14
    arc_1_5_19  out_degree_1179  1
    arc_1_5_19  in_degree_1251  1
    arc_1_5_19  original_T_including_depot_unload_1266  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_873  1
    load_1_5_19  segment_load_conservation_1183  1
    load_1_5_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_875  -25
    arc_1_5_20  connected_order_arc_876  -14
    arc_1_5_20  out_degree_1179  1
    arc_1_5_20  in_degree_1257  1
    arc_1_5_20  original_T_including_depot_unload_1266  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_875  1
    load_1_5_20  segment_load_conservation_1183  1
    load_1_5_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_877  -25
    arc_1_6_0  depot_return_or_bypass_1178  1
    arc_1_6_0  out_degree_1186  1
    arc_1_6_0  original_T_including_depot_unload_1266  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_877  1
    load_1_6_0  segment_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_878  -25
    arc_1_6_5  connected_order_arc_879  -14
    arc_1_6_5  in_degree_1180  1
    arc_1_6_5  out_degree_1186  1
    arc_1_6_5  original_T_including_depot_unload_1266  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_878  1
    load_1_6_5  segment_load_conservation_1183  -1
    load_1_6_5  segment_prefix_lb_1184  1
    load_1_6_5  segment_prefix_ub_1185  1
    load_1_6_5  segment_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_880  -25
    arc_1_6_7  connected_order_arc_881  -14
    arc_1_6_7  out_degree_1186  1
    arc_1_6_7  in_degree_1194  1
    arc_1_6_7  original_T_including_depot_unload_1266  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_880  1
    load_1_6_7  segment_load_conservation_1190  1
    load_1_6_7  segment_load_conservation_1197  -1
    load_1_6_7  segment_prefix_lb_1198  1
    load_1_6_7  segment_prefix_ub_1199  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_882  -25
    arc_1_6_8  connected_order_arc_883  -14
    arc_1_6_8  out_degree_1186  1
    arc_1_6_8  in_degree_1201  1
    arc_1_6_8  original_T_including_depot_unload_1266  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_882  1
    load_1_6_8  segment_load_conservation_1190  1
    load_1_6_8  segment_load_conservation_1204  -1
    load_1_6_8  segment_prefix_lb_1205  1
    load_1_6_8  segment_prefix_ub_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_884  -25
    arc_1_6_9  connected_order_arc_885  -14
    arc_1_6_9  out_degree_1186  1
    arc_1_6_9  in_degree_1208  1
    arc_1_6_9  original_T_including_depot_unload_1266  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_884  1
    load_1_6_9  segment_load_conservation_1190  1
    load_1_6_9  segment_load_conservation_1211  -1
    load_1_6_9  segment_prefix_lb_1212  1
    load_1_6_9  segment_prefix_ub_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_886  -25
    arc_1_6_13  connected_order_arc_887  -14
    arc_1_6_13  out_degree_1186  1
    arc_1_6_13  in_degree_1215  1
    arc_1_6_13  original_T_including_depot_unload_1266  1.4394323281782954e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_886  1
    load_1_6_13  segment_load_conservation_1190  1
    load_1_6_13  free_load_conservation_1219  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_888  -25
    arc_1_6_14  connected_order_arc_889  -14
    arc_1_6_14  out_degree_1186  1
    arc_1_6_14  in_degree_1221  1
    arc_1_6_14  original_T_including_depot_unload_1266  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_888  1
    load_1_6_14  segment_load_conservation_1190  1
    load_1_6_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_890  -25
    arc_1_6_15  connected_order_arc_891  -14
    arc_1_6_15  out_degree_1186  1
    arc_1_6_15  in_degree_1227  1
    arc_1_6_15  original_T_including_depot_unload_1266  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_890  1
    load_1_6_15  segment_load_conservation_1190  1
    load_1_6_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_892  -25
    arc_1_6_16  connected_order_arc_893  -14
    arc_1_6_16  out_degree_1186  1
    arc_1_6_16  in_degree_1233  1
    arc_1_6_16  original_T_including_depot_unload_1266  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_892  1
    load_1_6_16  segment_load_conservation_1190  1
    load_1_6_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_894  -25
    arc_1_6_17  connected_order_arc_895  -14
    arc_1_6_17  out_degree_1186  1
    arc_1_6_17  in_degree_1239  1
    arc_1_6_17  original_T_including_depot_unload_1266  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_894  1
    load_1_6_17  segment_load_conservation_1190  1
    load_1_6_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_896  -25
    arc_1_6_18  connected_order_arc_897  -14
    arc_1_6_18  out_degree_1186  1
    arc_1_6_18  in_degree_1245  1
    arc_1_6_18  original_T_including_depot_unload_1266  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_896  1
    load_1_6_18  segment_load_conservation_1190  1
    load_1_6_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_898  -25
    arc_1_6_19  connected_order_arc_899  -14
    arc_1_6_19  out_degree_1186  1
    arc_1_6_19  in_degree_1251  1
    arc_1_6_19  original_T_including_depot_unload_1266  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_898  1
    load_1_6_19  segment_load_conservation_1190  1
    load_1_6_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_900  -25
    arc_1_6_20  connected_order_arc_901  -14
    arc_1_6_20  out_degree_1186  1
    arc_1_6_20  in_degree_1257  1
    arc_1_6_20  original_T_including_depot_unload_1266  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_900  1
    load_1_6_20  segment_load_conservation_1190  1
    load_1_6_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_902  -25
    arc_1_7_0  depot_return_or_bypass_1178  1
    arc_1_7_0  out_degree_1193  1
    arc_1_7_0  original_T_including_depot_unload_1266  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_902  1
    load_1_7_0  segment_load_conservation_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_903  -25
    arc_1_7_5  connected_order_arc_904  -14
    arc_1_7_5  in_degree_1180  1
    arc_1_7_5  out_degree_1193  1
    arc_1_7_5  original_T_including_depot_unload_1266  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_903  1
    load_1_7_5  segment_load_conservation_1183  -1
    load_1_7_5  segment_prefix_lb_1184  1
    load_1_7_5  segment_prefix_ub_1185  1
    load_1_7_5  segment_load_conservation_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_905  -25
    arc_1_7_6  connected_order_arc_906  -14
    arc_1_7_6  in_degree_1187  1
    arc_1_7_6  out_degree_1193  1
    arc_1_7_6  original_T_including_depot_unload_1266  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_905  1
    load_1_7_6  segment_load_conservation_1190  -1
    load_1_7_6  segment_prefix_lb_1191  1
    load_1_7_6  segment_prefix_ub_1192  1
    load_1_7_6  segment_load_conservation_1197  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_907  -25
    arc_1_7_8  connected_order_arc_908  -14
    arc_1_7_8  out_degree_1193  1
    arc_1_7_8  in_degree_1201  1
    arc_1_7_8  original_T_including_depot_unload_1266  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_907  1
    load_1_7_8  segment_load_conservation_1197  1
    load_1_7_8  segment_load_conservation_1204  -1
    load_1_7_8  segment_prefix_lb_1205  1
    load_1_7_8  segment_prefix_ub_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_909  -25
    arc_1_7_9  connected_order_arc_910  -14
    arc_1_7_9  out_degree_1193  1
    arc_1_7_9  in_degree_1208  1
    arc_1_7_9  original_T_including_depot_unload_1266  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_909  1
    load_1_7_9  segment_load_conservation_1197  1
    load_1_7_9  segment_load_conservation_1211  -1
    load_1_7_9  segment_prefix_lb_1212  1
    load_1_7_9  segment_prefix_ub_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_911  -25
    arc_1_7_13  connected_order_arc_912  -14
    arc_1_7_13  out_degree_1193  1
    arc_1_7_13  in_degree_1215  1
    arc_1_7_13  original_T_including_depot_unload_1266  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_911  1
    load_1_7_13  segment_load_conservation_1197  1
    load_1_7_13  free_load_conservation_1219  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_913  -25
    arc_1_7_14  connected_order_arc_914  -14
    arc_1_7_14  out_degree_1193  1
    arc_1_7_14  in_degree_1221  1
    arc_1_7_14  original_T_including_depot_unload_1266  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_913  1
    load_1_7_14  segment_load_conservation_1197  1
    load_1_7_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_915  -25
    arc_1_7_15  connected_order_arc_916  -14
    arc_1_7_15  out_degree_1193  1
    arc_1_7_15  in_degree_1227  1
    arc_1_7_15  original_T_including_depot_unload_1266  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_915  1
    load_1_7_15  segment_load_conservation_1197  1
    load_1_7_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_917  -25
    arc_1_7_16  connected_order_arc_918  -14
    arc_1_7_16  out_degree_1193  1
    arc_1_7_16  in_degree_1233  1
    arc_1_7_16  original_T_including_depot_unload_1266  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_917  1
    load_1_7_16  segment_load_conservation_1197  1
    load_1_7_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_919  -25
    arc_1_7_17  connected_order_arc_920  -14
    arc_1_7_17  out_degree_1193  1
    arc_1_7_17  in_degree_1239  1
    arc_1_7_17  original_T_including_depot_unload_1266  1.5230919127946252e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_919  1
    load_1_7_17  segment_load_conservation_1197  1
    load_1_7_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_921  -25
    arc_1_7_18  connected_order_arc_922  -14
    arc_1_7_18  out_degree_1193  1
    arc_1_7_18  in_degree_1245  1
    arc_1_7_18  original_T_including_depot_unload_1266  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_921  1
    load_1_7_18  segment_load_conservation_1197  1
    load_1_7_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_923  -25
    arc_1_7_19  connected_order_arc_924  -14
    arc_1_7_19  out_degree_1193  1
    arc_1_7_19  in_degree_1251  1
    arc_1_7_19  original_T_including_depot_unload_1266  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_923  1
    load_1_7_19  segment_load_conservation_1197  1
    load_1_7_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_925  -25
    arc_1_7_20  connected_order_arc_926  -14
    arc_1_7_20  out_degree_1193  1
    arc_1_7_20  in_degree_1257  1
    arc_1_7_20  original_T_including_depot_unload_1266  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_925  1
    load_1_7_20  segment_load_conservation_1197  1
    load_1_7_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_927  -25
    arc_1_8_0  depot_return_or_bypass_1178  1
    arc_1_8_0  out_degree_1200  1
    arc_1_8_0  original_T_including_depot_unload_1266  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_927  1
    load_1_8_0  segment_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_928  -25
    arc_1_8_5  connected_order_arc_929  -14
    arc_1_8_5  in_degree_1180  1
    arc_1_8_5  out_degree_1200  1
    arc_1_8_5  original_T_including_depot_unload_1266  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_928  1
    load_1_8_5  segment_load_conservation_1183  -1
    load_1_8_5  segment_prefix_lb_1184  1
    load_1_8_5  segment_prefix_ub_1185  1
    load_1_8_5  segment_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_930  -25
    arc_1_8_6  connected_order_arc_931  -14
    arc_1_8_6  in_degree_1187  1
    arc_1_8_6  out_degree_1200  1
    arc_1_8_6  original_T_including_depot_unload_1266  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_930  1
    load_1_8_6  segment_load_conservation_1190  -1
    load_1_8_6  segment_prefix_lb_1191  1
    load_1_8_6  segment_prefix_ub_1192  1
    load_1_8_6  segment_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_932  -25
    arc_1_8_7  connected_order_arc_933  -14
    arc_1_8_7  in_degree_1194  1
    arc_1_8_7  out_degree_1200  1
    arc_1_8_7  original_T_including_depot_unload_1266  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_932  1
    load_1_8_7  segment_load_conservation_1197  -1
    load_1_8_7  segment_prefix_lb_1198  1
    load_1_8_7  segment_prefix_ub_1199  1
    load_1_8_7  segment_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_934  -25
    arc_1_8_9  connected_order_arc_935  -14
    arc_1_8_9  out_degree_1200  1
    arc_1_8_9  in_degree_1208  1
    arc_1_8_9  original_T_including_depot_unload_1266  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_934  1
    load_1_8_9  segment_load_conservation_1204  1
    load_1_8_9  segment_load_conservation_1211  -1
    load_1_8_9  segment_prefix_lb_1212  1
    load_1_8_9  segment_prefix_ub_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_936  -25
    arc_1_8_13  connected_order_arc_937  -14
    arc_1_8_13  out_degree_1200  1
    arc_1_8_13  in_degree_1215  1
    arc_1_8_13  original_T_including_depot_unload_1266  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_936  1
    load_1_8_13  segment_load_conservation_1204  1
    load_1_8_13  free_load_conservation_1219  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_938  -25
    arc_1_8_14  connected_order_arc_939  -14
    arc_1_8_14  out_degree_1200  1
    arc_1_8_14  in_degree_1221  1
    arc_1_8_14  original_T_including_depot_unload_1266  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_938  1
    load_1_8_14  segment_load_conservation_1204  1
    load_1_8_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_940  -25
    arc_1_8_15  connected_order_arc_941  -14
    arc_1_8_15  out_degree_1200  1
    arc_1_8_15  in_degree_1227  1
    arc_1_8_15  original_T_including_depot_unload_1266  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_940  1
    load_1_8_15  segment_load_conservation_1204  1
    load_1_8_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_942  -25
    arc_1_8_16  connected_order_arc_943  -14
    arc_1_8_16  out_degree_1200  1
    arc_1_8_16  in_degree_1233  1
    arc_1_8_16  original_T_including_depot_unload_1266  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_942  1
    load_1_8_16  segment_load_conservation_1204  1
    load_1_8_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_944  -25
    arc_1_8_17  connected_order_arc_945  -14
    arc_1_8_17  out_degree_1200  1
    arc_1_8_17  in_degree_1239  1
    arc_1_8_17  original_T_including_depot_unload_1266  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_944  1
    load_1_8_17  segment_load_conservation_1204  1
    load_1_8_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_946  -25
    arc_1_8_18  connected_order_arc_947  -14
    arc_1_8_18  out_degree_1200  1
    arc_1_8_18  in_degree_1245  1
    arc_1_8_18  original_T_including_depot_unload_1266  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_946  1
    load_1_8_18  segment_load_conservation_1204  1
    load_1_8_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_948  -25
    arc_1_8_19  connected_order_arc_949  -14
    arc_1_8_19  out_degree_1200  1
    arc_1_8_19  in_degree_1251  1
    arc_1_8_19  original_T_including_depot_unload_1266  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_948  1
    load_1_8_19  segment_load_conservation_1204  1
    load_1_8_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_950  -25
    arc_1_8_20  connected_order_arc_951  -14
    arc_1_8_20  out_degree_1200  1
    arc_1_8_20  in_degree_1257  1
    arc_1_8_20  original_T_including_depot_unload_1266  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_950  1
    load_1_8_20  segment_load_conservation_1204  1
    load_1_8_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_952  -25
    arc_1_9_0  depot_return_or_bypass_1178  1
    arc_1_9_0  out_degree_1207  1
    arc_1_9_0  original_T_including_depot_unload_1266  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_952  1
    load_1_9_0  segment_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_5  arc_capacity_953  -25
    arc_1_9_5  connected_order_arc_954  -14
    arc_1_9_5  in_degree_1180  1
    arc_1_9_5  out_degree_1207  1
    arc_1_9_5  original_T_including_depot_unload_1266  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_5  arc_capacity_953  1
    load_1_9_5  segment_load_conservation_1183  -1
    load_1_9_5  segment_prefix_lb_1184  1
    load_1_9_5  segment_prefix_ub_1185  1
    load_1_9_5  segment_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_955  -25
    arc_1_9_6  connected_order_arc_956  -14
    arc_1_9_6  in_degree_1187  1
    arc_1_9_6  out_degree_1207  1
    arc_1_9_6  original_T_including_depot_unload_1266  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_955  1
    load_1_9_6  segment_load_conservation_1190  -1
    load_1_9_6  segment_prefix_lb_1191  1
    load_1_9_6  segment_prefix_ub_1192  1
    load_1_9_6  segment_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_957  -25
    arc_1_9_7  connected_order_arc_958  -14
    arc_1_9_7  in_degree_1194  1
    arc_1_9_7  out_degree_1207  1
    arc_1_9_7  original_T_including_depot_unload_1266  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_957  1
    load_1_9_7  segment_load_conservation_1197  -1
    load_1_9_7  segment_prefix_lb_1198  1
    load_1_9_7  segment_prefix_ub_1199  1
    load_1_9_7  segment_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_959  -25
    arc_1_9_8  connected_order_arc_960  -14
    arc_1_9_8  in_degree_1201  1
    arc_1_9_8  out_degree_1207  1
    arc_1_9_8  original_T_including_depot_unload_1266  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_959  1
    load_1_9_8  segment_load_conservation_1204  -1
    load_1_9_8  segment_prefix_lb_1205  1
    load_1_9_8  segment_prefix_ub_1206  1
    load_1_9_8  segment_load_conservation_1211  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_961  -25
    arc_1_9_13  connected_order_arc_962  -14
    arc_1_9_13  out_degree_1207  1
    arc_1_9_13  in_degree_1215  1
    arc_1_9_13  original_T_including_depot_unload_1266  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_961  1
    load_1_9_13  segment_load_conservation_1211  1
    load_1_9_13  free_load_conservation_1219  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_963  -25
    arc_1_9_14  connected_order_arc_964  -14
    arc_1_9_14  out_degree_1207  1
    arc_1_9_14  in_degree_1221  1
    arc_1_9_14  original_T_including_depot_unload_1266  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_963  1
    load_1_9_14  segment_load_conservation_1211  1
    load_1_9_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_965  -25
    arc_1_9_15  connected_order_arc_966  -14
    arc_1_9_15  out_degree_1207  1
    arc_1_9_15  in_degree_1227  1
    arc_1_9_15  original_T_including_depot_unload_1266  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_965  1
    load_1_9_15  segment_load_conservation_1211  1
    load_1_9_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_967  -25
    arc_1_9_16  connected_order_arc_968  -14
    arc_1_9_16  out_degree_1207  1
    arc_1_9_16  in_degree_1233  1
    arc_1_9_16  original_T_including_depot_unload_1266  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_967  1
    load_1_9_16  segment_load_conservation_1211  1
    load_1_9_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_969  -25
    arc_1_9_17  connected_order_arc_970  -14
    arc_1_9_17  out_degree_1207  1
    arc_1_9_17  in_degree_1239  1
    arc_1_9_17  original_T_including_depot_unload_1266  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_969  1
    load_1_9_17  segment_load_conservation_1211  1
    load_1_9_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_971  -25
    arc_1_9_18  connected_order_arc_972  -14
    arc_1_9_18  out_degree_1207  1
    arc_1_9_18  in_degree_1245  1
    arc_1_9_18  original_T_including_depot_unload_1266  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_971  1
    load_1_9_18  segment_load_conservation_1211  1
    load_1_9_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_973  -25
    arc_1_9_19  connected_order_arc_974  -14
    arc_1_9_19  out_degree_1207  1
    arc_1_9_19  in_degree_1251  1
    arc_1_9_19  original_T_including_depot_unload_1266  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_973  1
    load_1_9_19  segment_load_conservation_1211  1
    load_1_9_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_975  -25
    arc_1_9_20  connected_order_arc_976  -14
    arc_1_9_20  out_degree_1207  1
    arc_1_9_20  in_degree_1257  1
    arc_1_9_20  original_T_including_depot_unload_1266  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_975  1
    load_1_9_20  segment_load_conservation_1211  1
    load_1_9_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_977  -25
    arc_1_13_0  depot_return_or_bypass_1178  1
    arc_1_13_0  out_degree_1214  1
    arc_1_13_0  original_T_including_depot_unload_1266  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_977  1
    load_1_13_0  free_load_conservation_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_978  -25
    arc_1_13_5  connected_order_arc_979  -14
    arc_1_13_5  in_degree_1180  1
    arc_1_13_5  out_degree_1214  1
    arc_1_13_5  original_T_including_depot_unload_1266  1.2608023164150941e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_978  1
    load_1_13_5  segment_load_conservation_1183  -1
    load_1_13_5  segment_prefix_lb_1184  1
    load_1_13_5  segment_prefix_ub_1185  1
    load_1_13_5  free_load_conservation_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_980  -25
    arc_1_13_6  connected_order_arc_981  -14
    arc_1_13_6  in_degree_1187  1
    arc_1_13_6  out_degree_1214  1
    arc_1_13_6  original_T_including_depot_unload_1266  1.4394323281782954e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_980  1
    load_1_13_6  segment_load_conservation_1190  -1
    load_1_13_6  segment_prefix_lb_1191  1
    load_1_13_6  segment_prefix_ub_1192  1
    load_1_13_6  free_load_conservation_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_982  -25
    arc_1_13_7  connected_order_arc_983  -14
    arc_1_13_7  in_degree_1194  1
    arc_1_13_7  out_degree_1214  1
    arc_1_13_7  original_T_including_depot_unload_1266  1.3140724694688972e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_982  1
    load_1_13_7  segment_load_conservation_1197  -1
    load_1_13_7  segment_prefix_lb_1198  1
    load_1_13_7  segment_prefix_ub_1199  1
    load_1_13_7  free_load_conservation_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_984  -25
    arc_1_13_8  connected_order_arc_985  -14
    arc_1_13_8  in_degree_1201  1
    arc_1_13_8  out_degree_1214  1
    arc_1_13_8  original_T_including_depot_unload_1266  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_984  1
    load_1_13_8  segment_load_conservation_1204  -1
    load_1_13_8  segment_prefix_lb_1205  1
    load_1_13_8  segment_prefix_ub_1206  1
    load_1_13_8  free_load_conservation_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_986  -25
    arc_1_13_9  connected_order_arc_987  -14
    arc_1_13_9  in_degree_1208  1
    arc_1_13_9  out_degree_1214  1
    arc_1_13_9  original_T_including_depot_unload_1266  7.8590541298812059e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_986  1
    load_1_13_9  segment_load_conservation_1211  -1
    load_1_13_9  segment_prefix_lb_1212  1
    load_1_13_9  segment_prefix_ub_1213  1
    load_1_13_9  free_load_conservation_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_988  -25
    arc_1_13_14  connected_order_arc_989  -14
    arc_1_13_14  out_degree_1214  1
    arc_1_13_14  in_degree_1221  1
    arc_1_13_14  original_T_including_depot_unload_1266  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_988  1
    load_1_13_14  free_load_conservation_1219  1
    load_1_13_14  free_load_conservation_1225  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_990  -25
    arc_1_13_15  connected_order_arc_991  -14
    arc_1_13_15  out_degree_1214  1
    arc_1_13_15  in_degree_1227  1
    arc_1_13_15  original_T_including_depot_unload_1266  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_990  1
    load_1_13_15  free_load_conservation_1219  1
    load_1_13_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_992  -25
    arc_1_13_16  connected_order_arc_993  -14
    arc_1_13_16  out_degree_1214  1
    arc_1_13_16  in_degree_1233  1
    arc_1_13_16  original_T_including_depot_unload_1266  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_992  1
    load_1_13_16  free_load_conservation_1219  1
    load_1_13_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_994  -25
    arc_1_13_17  connected_order_arc_995  -14
    arc_1_13_17  out_degree_1214  1
    arc_1_13_17  in_degree_1239  1
    arc_1_13_17  original_T_including_depot_unload_1266  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_994  1
    load_1_13_17  free_load_conservation_1219  1
    load_1_13_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_996  -25
    arc_1_13_18  connected_order_arc_997  -14
    arc_1_13_18  out_degree_1214  1
    arc_1_13_18  in_degree_1245  1
    arc_1_13_18  original_T_including_depot_unload_1266  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_996  1
    load_1_13_18  free_load_conservation_1219  1
    load_1_13_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_998  -25
    arc_1_13_19  connected_order_arc_999  -14
    arc_1_13_19  out_degree_1214  1
    arc_1_13_19  in_degree_1251  1
    arc_1_13_19  original_T_including_depot_unload_1266  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_998  1
    load_1_13_19  free_load_conservation_1219  1
    load_1_13_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_1000  -25
    arc_1_13_20  connected_order_arc_1001  -14
    arc_1_13_20  out_degree_1214  1
    arc_1_13_20  in_degree_1257  1
    arc_1_13_20  original_T_including_depot_unload_1266  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_1000  1
    load_1_13_20  free_load_conservation_1219  1
    load_1_13_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1002  -25
    arc_1_14_0  depot_return_or_bypass_1178  1
    arc_1_14_0  out_degree_1220  1
    arc_1_14_0  original_T_including_depot_unload_1266  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1002  1
    load_1_14_0  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_1003  -25
    arc_1_14_5  connected_order_arc_1004  -14
    arc_1_14_5  in_degree_1180  1
    arc_1_14_5  out_degree_1220  1
    arc_1_14_5  original_T_including_depot_unload_1266  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_1003  1
    load_1_14_5  segment_load_conservation_1183  -1
    load_1_14_5  segment_prefix_lb_1184  1
    load_1_14_5  segment_prefix_ub_1185  1
    load_1_14_5  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_1005  -25
    arc_1_14_6  connected_order_arc_1006  -14
    arc_1_14_6  in_degree_1187  1
    arc_1_14_6  out_degree_1220  1
    arc_1_14_6  original_T_including_depot_unload_1266  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_1005  1
    load_1_14_6  segment_load_conservation_1190  -1
    load_1_14_6  segment_prefix_lb_1191  1
    load_1_14_6  segment_prefix_ub_1192  1
    load_1_14_6  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1007  -25
    arc_1_14_7  connected_order_arc_1008  -14
    arc_1_14_7  in_degree_1194  1
    arc_1_14_7  out_degree_1220  1
    arc_1_14_7  original_T_including_depot_unload_1266  1.1768203711166027e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1007  1
    load_1_14_7  segment_load_conservation_1197  -1
    load_1_14_7  segment_prefix_lb_1198  1
    load_1_14_7  segment_prefix_ub_1199  1
    load_1_14_7  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1009  -25
    arc_1_14_8  connected_order_arc_1010  -14
    arc_1_14_8  in_degree_1201  1
    arc_1_14_8  out_degree_1220  1
    arc_1_14_8  original_T_including_depot_unload_1266  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1009  1
    load_1_14_8  segment_load_conservation_1204  -1
    load_1_14_8  segment_prefix_lb_1205  1
    load_1_14_8  segment_prefix_ub_1206  1
    load_1_14_8  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1011  -25
    arc_1_14_9  connected_order_arc_1012  -14
    arc_1_14_9  in_degree_1208  1
    arc_1_14_9  out_degree_1220  1
    arc_1_14_9  original_T_including_depot_unload_1266  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1011  1
    load_1_14_9  segment_load_conservation_1211  -1
    load_1_14_9  segment_prefix_lb_1212  1
    load_1_14_9  segment_prefix_ub_1213  1
    load_1_14_9  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1013  -25
    arc_1_14_13  connected_order_arc_1014  -14
    arc_1_14_13  in_degree_1215  1
    arc_1_14_13  out_degree_1220  1
    arc_1_14_13  original_T_including_depot_unload_1266  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1013  1
    load_1_14_13  free_load_conservation_1219  -1
    load_1_14_13  free_load_conservation_1225  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1015  -25
    arc_1_14_15  connected_order_arc_1016  -14
    arc_1_14_15  out_degree_1220  1
    arc_1_14_15  in_degree_1227  1
    arc_1_14_15  original_T_including_depot_unload_1266  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1015  1
    load_1_14_15  free_load_conservation_1225  1
    load_1_14_15  free_load_conservation_1231  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1017  -25
    arc_1_14_16  connected_order_arc_1018  -14
    arc_1_14_16  out_degree_1220  1
    arc_1_14_16  in_degree_1233  1
    arc_1_14_16  original_T_including_depot_unload_1266  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1017  1
    load_1_14_16  free_load_conservation_1225  1
    load_1_14_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1019  -25
    arc_1_14_17  connected_order_arc_1020  -14
    arc_1_14_17  out_degree_1220  1
    arc_1_14_17  in_degree_1239  1
    arc_1_14_17  original_T_including_depot_unload_1266  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1019  1
    load_1_14_17  free_load_conservation_1225  1
    load_1_14_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1021  -25
    arc_1_14_18  connected_order_arc_1022  -14
    arc_1_14_18  out_degree_1220  1
    arc_1_14_18  in_degree_1245  1
    arc_1_14_18  original_T_including_depot_unload_1266  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1021  1
    load_1_14_18  free_load_conservation_1225  1
    load_1_14_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1023  -25
    arc_1_14_19  connected_order_arc_1024  -14
    arc_1_14_19  out_degree_1220  1
    arc_1_14_19  in_degree_1251  1
    arc_1_14_19  original_T_including_depot_unload_1266  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1023  1
    load_1_14_19  free_load_conservation_1225  1
    load_1_14_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1025  -25
    arc_1_14_20  connected_order_arc_1026  -14
    arc_1_14_20  out_degree_1220  1
    arc_1_14_20  in_degree_1257  1
    arc_1_14_20  original_T_including_depot_unload_1266  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1025  1
    load_1_14_20  free_load_conservation_1225  1
    load_1_14_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1027  -25
    arc_1_15_0  depot_return_or_bypass_1178  1
    arc_1_15_0  out_degree_1226  1
    arc_1_15_0  original_T_including_depot_unload_1266  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1027  1
    load_1_15_0  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_1028  -25
    arc_1_15_5  connected_order_arc_1029  -14
    arc_1_15_5  in_degree_1180  1
    arc_1_15_5  out_degree_1226  1
    arc_1_15_5  original_T_including_depot_unload_1266  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_1028  1
    load_1_15_5  segment_load_conservation_1183  -1
    load_1_15_5  segment_prefix_lb_1184  1
    load_1_15_5  segment_prefix_ub_1185  1
    load_1_15_5  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1030  -25
    arc_1_15_6  connected_order_arc_1031  -14
    arc_1_15_6  in_degree_1187  1
    arc_1_15_6  out_degree_1226  1
    arc_1_15_6  original_T_including_depot_unload_1266  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1030  1
    load_1_15_6  segment_load_conservation_1190  -1
    load_1_15_6  segment_prefix_lb_1191  1
    load_1_15_6  segment_prefix_ub_1192  1
    load_1_15_6  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1032  -25
    arc_1_15_7  connected_order_arc_1033  -14
    arc_1_15_7  in_degree_1194  1
    arc_1_15_7  out_degree_1226  1
    arc_1_15_7  original_T_including_depot_unload_1266  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1032  1
    load_1_15_7  segment_load_conservation_1197  -1
    load_1_15_7  segment_prefix_lb_1198  1
    load_1_15_7  segment_prefix_ub_1199  1
    load_1_15_7  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1034  -25
    arc_1_15_8  connected_order_arc_1035  -14
    arc_1_15_8  in_degree_1201  1
    arc_1_15_8  out_degree_1226  1
    arc_1_15_8  original_T_including_depot_unload_1266  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1034  1
    load_1_15_8  segment_load_conservation_1204  -1
    load_1_15_8  segment_prefix_lb_1205  1
    load_1_15_8  segment_prefix_ub_1206  1
    load_1_15_8  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1036  -25
    arc_1_15_9  connected_order_arc_1037  -14
    arc_1_15_9  in_degree_1208  1
    arc_1_15_9  out_degree_1226  1
    arc_1_15_9  original_T_including_depot_unload_1266  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1036  1
    load_1_15_9  segment_load_conservation_1211  -1
    load_1_15_9  segment_prefix_lb_1212  1
    load_1_15_9  segment_prefix_ub_1213  1
    load_1_15_9  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1038  -25
    arc_1_15_13  connected_order_arc_1039  -14
    arc_1_15_13  in_degree_1215  1
    arc_1_15_13  out_degree_1226  1
    arc_1_15_13  original_T_including_depot_unload_1266  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1038  1
    load_1_15_13  free_load_conservation_1219  -1
    load_1_15_13  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1040  -25
    arc_1_15_14  connected_order_arc_1041  -14
    arc_1_15_14  in_degree_1221  1
    arc_1_15_14  out_degree_1226  1
    arc_1_15_14  original_T_including_depot_unload_1266  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1040  1
    load_1_15_14  free_load_conservation_1225  -1
    load_1_15_14  free_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1042  -25
    arc_1_15_16  connected_order_arc_1043  -14
    arc_1_15_16  out_degree_1226  1
    arc_1_15_16  in_degree_1233  1
    arc_1_15_16  original_T_including_depot_unload_1266  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1042  1
    load_1_15_16  free_load_conservation_1231  1
    load_1_15_16  free_load_conservation_1237  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1044  -25
    arc_1_15_17  connected_order_arc_1045  -14
    arc_1_15_17  out_degree_1226  1
    arc_1_15_17  in_degree_1239  1
    arc_1_15_17  original_T_including_depot_unload_1266  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1044  1
    load_1_15_17  free_load_conservation_1231  1
    load_1_15_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1046  -25
    arc_1_15_18  connected_order_arc_1047  -14
    arc_1_15_18  out_degree_1226  1
    arc_1_15_18  in_degree_1245  1
    arc_1_15_18  original_T_including_depot_unload_1266  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1046  1
    load_1_15_18  free_load_conservation_1231  1
    load_1_15_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1048  -25
    arc_1_15_19  connected_order_arc_1049  -14
    arc_1_15_19  out_degree_1226  1
    arc_1_15_19  in_degree_1251  1
    arc_1_15_19  original_T_including_depot_unload_1266  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1048  1
    load_1_15_19  free_load_conservation_1231  1
    load_1_15_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1050  -25
    arc_1_15_20  connected_order_arc_1051  -14
    arc_1_15_20  out_degree_1226  1
    arc_1_15_20  in_degree_1257  1
    arc_1_15_20  original_T_including_depot_unload_1266  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1050  1
    load_1_15_20  free_load_conservation_1231  1
    load_1_15_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1052  -25
    arc_1_16_0  depot_return_or_bypass_1178  1
    arc_1_16_0  out_degree_1232  1
    arc_1_16_0  original_T_including_depot_unload_1266  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1052  1
    load_1_16_0  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_1053  -25
    arc_1_16_5  connected_order_arc_1054  -14
    arc_1_16_5  in_degree_1180  1
    arc_1_16_5  out_degree_1232  1
    arc_1_16_5  original_T_including_depot_unload_1266  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_1053  1
    load_1_16_5  segment_load_conservation_1183  -1
    load_1_16_5  segment_prefix_lb_1184  1
    load_1_16_5  segment_prefix_ub_1185  1
    load_1_16_5  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1055  -25
    arc_1_16_6  connected_order_arc_1056  -14
    arc_1_16_6  in_degree_1187  1
    arc_1_16_6  out_degree_1232  1
    arc_1_16_6  original_T_including_depot_unload_1266  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1055  1
    load_1_16_6  segment_load_conservation_1190  -1
    load_1_16_6  segment_prefix_lb_1191  1
    load_1_16_6  segment_prefix_ub_1192  1
    load_1_16_6  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1057  -25
    arc_1_16_7  connected_order_arc_1058  -14
    arc_1_16_7  in_degree_1194  1
    arc_1_16_7  out_degree_1232  1
    arc_1_16_7  original_T_including_depot_unload_1266  1.3776676659817167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1057  1
    load_1_16_7  segment_load_conservation_1197  -1
    load_1_16_7  segment_prefix_lb_1198  1
    load_1_16_7  segment_prefix_ub_1199  1
    load_1_16_7  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1059  -25
    arc_1_16_8  connected_order_arc_1060  -14
    arc_1_16_8  in_degree_1201  1
    arc_1_16_8  out_degree_1232  1
    arc_1_16_8  original_T_including_depot_unload_1266  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1059  1
    load_1_16_8  segment_load_conservation_1204  -1
    load_1_16_8  segment_prefix_lb_1205  1
    load_1_16_8  segment_prefix_ub_1206  1
    load_1_16_8  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1061  -25
    arc_1_16_9  connected_order_arc_1062  -14
    arc_1_16_9  in_degree_1208  1
    arc_1_16_9  out_degree_1232  1
    arc_1_16_9  original_T_including_depot_unload_1266  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1061  1
    load_1_16_9  segment_load_conservation_1211  -1
    load_1_16_9  segment_prefix_lb_1212  1
    load_1_16_9  segment_prefix_ub_1213  1
    load_1_16_9  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1063  -25
    arc_1_16_13  connected_order_arc_1064  -14
    arc_1_16_13  in_degree_1215  1
    arc_1_16_13  out_degree_1232  1
    arc_1_16_13  original_T_including_depot_unload_1266  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1063  1
    load_1_16_13  free_load_conservation_1219  -1
    load_1_16_13  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1065  -25
    arc_1_16_14  connected_order_arc_1066  -14
    arc_1_16_14  in_degree_1221  1
    arc_1_16_14  out_degree_1232  1
    arc_1_16_14  original_T_including_depot_unload_1266  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1065  1
    load_1_16_14  free_load_conservation_1225  -1
    load_1_16_14  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1067  -25
    arc_1_16_15  connected_order_arc_1068  -14
    arc_1_16_15  in_degree_1227  1
    arc_1_16_15  out_degree_1232  1
    arc_1_16_15  original_T_including_depot_unload_1266  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1067  1
    load_1_16_15  free_load_conservation_1231  -1
    load_1_16_15  free_load_conservation_1237  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1069  -25
    arc_1_16_17  connected_order_arc_1070  -14
    arc_1_16_17  out_degree_1232  1
    arc_1_16_17  in_degree_1239  1
    arc_1_16_17  original_T_including_depot_unload_1266  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1069  1
    load_1_16_17  free_load_conservation_1237  1
    load_1_16_17  free_load_conservation_1243  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1071  -25
    arc_1_16_18  connected_order_arc_1072  -14
    arc_1_16_18  out_degree_1232  1
    arc_1_16_18  in_degree_1245  1
    arc_1_16_18  original_T_including_depot_unload_1266  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1071  1
    load_1_16_18  free_load_conservation_1237  1
    load_1_16_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1073  -25
    arc_1_16_19  connected_order_arc_1074  -14
    arc_1_16_19  out_degree_1232  1
    arc_1_16_19  in_degree_1251  1
    arc_1_16_19  original_T_including_depot_unload_1266  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1073  1
    load_1_16_19  free_load_conservation_1237  1
    load_1_16_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1075  -25
    arc_1_16_20  connected_order_arc_1076  -14
    arc_1_16_20  out_degree_1232  1
    arc_1_16_20  in_degree_1257  1
    arc_1_16_20  original_T_including_depot_unload_1266  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1075  1
    load_1_16_20  free_load_conservation_1237  1
    load_1_16_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1077  -25
    arc_1_17_0  depot_return_or_bypass_1178  1
    arc_1_17_0  out_degree_1238  1
    arc_1_17_0  original_T_including_depot_unload_1266  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1077  1
    load_1_17_0  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1078  -25
    arc_1_17_5  connected_order_arc_1079  -14
    arc_1_17_5  in_degree_1180  1
    arc_1_17_5  out_degree_1238  1
    arc_1_17_5  original_T_including_depot_unload_1266  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1078  1
    load_1_17_5  segment_load_conservation_1183  -1
    load_1_17_5  segment_prefix_lb_1184  1
    load_1_17_5  segment_prefix_ub_1185  1
    load_1_17_5  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1080  -25
    arc_1_17_6  connected_order_arc_1081  -14
    arc_1_17_6  in_degree_1187  1
    arc_1_17_6  out_degree_1238  1
    arc_1_17_6  original_T_including_depot_unload_1266  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1080  1
    load_1_17_6  segment_load_conservation_1190  -1
    load_1_17_6  segment_prefix_lb_1191  1
    load_1_17_6  segment_prefix_ub_1192  1
    load_1_17_6  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1082  -25
    arc_1_17_7  connected_order_arc_1083  -14
    arc_1_17_7  in_degree_1194  1
    arc_1_17_7  out_degree_1238  1
    arc_1_17_7  original_T_including_depot_unload_1266  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1082  1
    load_1_17_7  segment_load_conservation_1197  -1
    load_1_17_7  segment_prefix_lb_1198  1
    load_1_17_7  segment_prefix_ub_1199  1
    load_1_17_7  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1084  -25
    arc_1_17_8  connected_order_arc_1085  -14
    arc_1_17_8  in_degree_1201  1
    arc_1_17_8  out_degree_1238  1
    arc_1_17_8  original_T_including_depot_unload_1266  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1084  1
    load_1_17_8  segment_load_conservation_1204  -1
    load_1_17_8  segment_prefix_lb_1205  1
    load_1_17_8  segment_prefix_ub_1206  1
    load_1_17_8  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1086  -25
    arc_1_17_9  connected_order_arc_1087  -14
    arc_1_17_9  in_degree_1208  1
    arc_1_17_9  out_degree_1238  1
    arc_1_17_9  original_T_including_depot_unload_1266  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1086  1
    load_1_17_9  segment_load_conservation_1211  -1
    load_1_17_9  segment_prefix_lb_1212  1
    load_1_17_9  segment_prefix_ub_1213  1
    load_1_17_9  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1088  -25
    arc_1_17_13  connected_order_arc_1089  -14
    arc_1_17_13  in_degree_1215  1
    arc_1_17_13  out_degree_1238  1
    arc_1_17_13  original_T_including_depot_unload_1266  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1088  1
    load_1_17_13  free_load_conservation_1219  -1
    load_1_17_13  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1090  -25
    arc_1_17_14  connected_order_arc_1091  -14
    arc_1_17_14  in_degree_1221  1
    arc_1_17_14  out_degree_1238  1
    arc_1_17_14  original_T_including_depot_unload_1266  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1090  1
    load_1_17_14  free_load_conservation_1225  -1
    load_1_17_14  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1092  -25
    arc_1_17_15  connected_order_arc_1093  -14
    arc_1_17_15  in_degree_1227  1
    arc_1_17_15  out_degree_1238  1
    arc_1_17_15  original_T_including_depot_unload_1266  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1092  1
    load_1_17_15  free_load_conservation_1231  -1
    load_1_17_15  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1094  -25
    arc_1_17_16  connected_order_arc_1095  -14
    arc_1_17_16  in_degree_1233  1
    arc_1_17_16  out_degree_1238  1
    arc_1_17_16  original_T_including_depot_unload_1266  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1094  1
    load_1_17_16  free_load_conservation_1237  -1
    load_1_17_16  free_load_conservation_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1096  -25
    arc_1_17_18  connected_order_arc_1097  -14
    arc_1_17_18  out_degree_1238  1
    arc_1_17_18  in_degree_1245  1
    arc_1_17_18  original_T_including_depot_unload_1266  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1096  1
    load_1_17_18  free_load_conservation_1243  1
    load_1_17_18  free_load_conservation_1249  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1098  -25
    arc_1_17_19  connected_order_arc_1099  -14
    arc_1_17_19  out_degree_1238  1
    arc_1_17_19  in_degree_1251  1
    arc_1_17_19  original_T_including_depot_unload_1266  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1098  1
    load_1_17_19  free_load_conservation_1243  1
    load_1_17_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1100  -25
    arc_1_17_20  connected_order_arc_1101  -14
    arc_1_17_20  out_degree_1238  1
    arc_1_17_20  in_degree_1257  1
    arc_1_17_20  original_T_including_depot_unload_1266  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1100  1
    load_1_17_20  free_load_conservation_1243  1
    load_1_17_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1102  -25
    arc_1_18_0  depot_return_or_bypass_1178  1
    arc_1_18_0  out_degree_1244  1
    arc_1_18_0  original_T_including_depot_unload_1266  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1102  1
    load_1_18_0  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1103  -25
    arc_1_18_5  connected_order_arc_1104  -14
    arc_1_18_5  in_degree_1180  1
    arc_1_18_5  out_degree_1244  1
    arc_1_18_5  original_T_including_depot_unload_1266  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1103  1
    load_1_18_5  segment_load_conservation_1183  -1
    load_1_18_5  segment_prefix_lb_1184  1
    load_1_18_5  segment_prefix_ub_1185  1
    load_1_18_5  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1105  -25
    arc_1_18_6  connected_order_arc_1106  -14
    arc_1_18_6  in_degree_1187  1
    arc_1_18_6  out_degree_1244  1
    arc_1_18_6  original_T_including_depot_unload_1266  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1105  1
    load_1_18_6  segment_load_conservation_1190  -1
    load_1_18_6  segment_prefix_lb_1191  1
    load_1_18_6  segment_prefix_ub_1192  1
    load_1_18_6  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1107  -25
    arc_1_18_7  connected_order_arc_1108  -14
    arc_1_18_7  in_degree_1194  1
    arc_1_18_7  out_degree_1244  1
    arc_1_18_7  original_T_including_depot_unload_1266  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1107  1
    load_1_18_7  segment_load_conservation_1197  -1
    load_1_18_7  segment_prefix_lb_1198  1
    load_1_18_7  segment_prefix_ub_1199  1
    load_1_18_7  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1109  -25
    arc_1_18_8  connected_order_arc_1110  -14
    arc_1_18_8  in_degree_1201  1
    arc_1_18_8  out_degree_1244  1
    arc_1_18_8  original_T_including_depot_unload_1266  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1109  1
    load_1_18_8  segment_load_conservation_1204  -1
    load_1_18_8  segment_prefix_lb_1205  1
    load_1_18_8  segment_prefix_ub_1206  1
    load_1_18_8  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1111  -25
    arc_1_18_9  connected_order_arc_1112  -14
    arc_1_18_9  in_degree_1208  1
    arc_1_18_9  out_degree_1244  1
    arc_1_18_9  original_T_including_depot_unload_1266  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1111  1
    load_1_18_9  segment_load_conservation_1211  -1
    load_1_18_9  segment_prefix_lb_1212  1
    load_1_18_9  segment_prefix_ub_1213  1
    load_1_18_9  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1113  -25
    arc_1_18_13  connected_order_arc_1114  -14
    arc_1_18_13  in_degree_1215  1
    arc_1_18_13  out_degree_1244  1
    arc_1_18_13  original_T_including_depot_unload_1266  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1113  1
    load_1_18_13  free_load_conservation_1219  -1
    load_1_18_13  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1115  -25
    arc_1_18_14  connected_order_arc_1116  -14
    arc_1_18_14  in_degree_1221  1
    arc_1_18_14  out_degree_1244  1
    arc_1_18_14  original_T_including_depot_unload_1266  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1115  1
    load_1_18_14  free_load_conservation_1225  -1
    load_1_18_14  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1117  -25
    arc_1_18_15  connected_order_arc_1118  -14
    arc_1_18_15  in_degree_1227  1
    arc_1_18_15  out_degree_1244  1
    arc_1_18_15  original_T_including_depot_unload_1266  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1117  1
    load_1_18_15  free_load_conservation_1231  -1
    load_1_18_15  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1119  -25
    arc_1_18_16  connected_order_arc_1120  -14
    arc_1_18_16  in_degree_1233  1
    arc_1_18_16  out_degree_1244  1
    arc_1_18_16  original_T_including_depot_unload_1266  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1119  1
    load_1_18_16  free_load_conservation_1237  -1
    load_1_18_16  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1121  -25
    arc_1_18_17  connected_order_arc_1122  -14
    arc_1_18_17  in_degree_1239  1
    arc_1_18_17  out_degree_1244  1
    arc_1_18_17  original_T_including_depot_unload_1266  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1121  1
    load_1_18_17  free_load_conservation_1243  -1
    load_1_18_17  free_load_conservation_1249  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1123  -25
    arc_1_18_19  connected_order_arc_1124  -14
    arc_1_18_19  out_degree_1244  1
    arc_1_18_19  in_degree_1251  1
    arc_1_18_19  original_T_including_depot_unload_1266  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1123  1
    load_1_18_19  free_load_conservation_1249  1
    load_1_18_19  free_load_conservation_1255  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1125  -25
    arc_1_18_20  connected_order_arc_1126  -14
    arc_1_18_20  out_degree_1244  1
    arc_1_18_20  in_degree_1257  1
    arc_1_18_20  original_T_including_depot_unload_1266  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1125  1
    load_1_18_20  free_load_conservation_1249  1
    load_1_18_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1127  -25
    arc_1_19_0  depot_return_or_bypass_1178  1
    arc_1_19_0  out_degree_1250  1
    arc_1_19_0  original_T_including_depot_unload_1266  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1127  1
    load_1_19_0  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1128  -25
    arc_1_19_5  connected_order_arc_1129  -14
    arc_1_19_5  in_degree_1180  1
    arc_1_19_5  out_degree_1250  1
    arc_1_19_5  original_T_including_depot_unload_1266  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1128  1
    load_1_19_5  segment_load_conservation_1183  -1
    load_1_19_5  segment_prefix_lb_1184  1
    load_1_19_5  segment_prefix_ub_1185  1
    load_1_19_5  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1130  -25
    arc_1_19_6  connected_order_arc_1131  -14
    arc_1_19_6  in_degree_1187  1
    arc_1_19_6  out_degree_1250  1
    arc_1_19_6  original_T_including_depot_unload_1266  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1130  1
    load_1_19_6  segment_load_conservation_1190  -1
    load_1_19_6  segment_prefix_lb_1191  1
    load_1_19_6  segment_prefix_ub_1192  1
    load_1_19_6  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1132  -25
    arc_1_19_7  connected_order_arc_1133  -14
    arc_1_19_7  in_degree_1194  1
    arc_1_19_7  out_degree_1250  1
    arc_1_19_7  original_T_including_depot_unload_1266  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1132  1
    load_1_19_7  segment_load_conservation_1197  -1
    load_1_19_7  segment_prefix_lb_1198  1
    load_1_19_7  segment_prefix_ub_1199  1
    load_1_19_7  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1134  -25
    arc_1_19_8  connected_order_arc_1135  -14
    arc_1_19_8  in_degree_1201  1
    arc_1_19_8  out_degree_1250  1
    arc_1_19_8  original_T_including_depot_unload_1266  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1134  1
    load_1_19_8  segment_load_conservation_1204  -1
    load_1_19_8  segment_prefix_lb_1205  1
    load_1_19_8  segment_prefix_ub_1206  1
    load_1_19_8  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1136  -25
    arc_1_19_9  connected_order_arc_1137  -14
    arc_1_19_9  in_degree_1208  1
    arc_1_19_9  out_degree_1250  1
    arc_1_19_9  original_T_including_depot_unload_1266  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1136  1
    load_1_19_9  segment_load_conservation_1211  -1
    load_1_19_9  segment_prefix_lb_1212  1
    load_1_19_9  segment_prefix_ub_1213  1
    load_1_19_9  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1138  -25
    arc_1_19_13  connected_order_arc_1139  -14
    arc_1_19_13  in_degree_1215  1
    arc_1_19_13  out_degree_1250  1
    arc_1_19_13  original_T_including_depot_unload_1266  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1138  1
    load_1_19_13  free_load_conservation_1219  -1
    load_1_19_13  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1140  -25
    arc_1_19_14  connected_order_arc_1141  -14
    arc_1_19_14  in_degree_1221  1
    arc_1_19_14  out_degree_1250  1
    arc_1_19_14  original_T_including_depot_unload_1266  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1140  1
    load_1_19_14  free_load_conservation_1225  -1
    load_1_19_14  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1142  -25
    arc_1_19_15  connected_order_arc_1143  -14
    arc_1_19_15  in_degree_1227  1
    arc_1_19_15  out_degree_1250  1
    arc_1_19_15  original_T_including_depot_unload_1266  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1142  1
    load_1_19_15  free_load_conservation_1231  -1
    load_1_19_15  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1144  -25
    arc_1_19_16  connected_order_arc_1145  -14
    arc_1_19_16  in_degree_1233  1
    arc_1_19_16  out_degree_1250  1
    arc_1_19_16  original_T_including_depot_unload_1266  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1144  1
    load_1_19_16  free_load_conservation_1237  -1
    load_1_19_16  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1146  -25
    arc_1_19_17  connected_order_arc_1147  -14
    arc_1_19_17  in_degree_1239  1
    arc_1_19_17  out_degree_1250  1
    arc_1_19_17  original_T_including_depot_unload_1266  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1146  1
    load_1_19_17  free_load_conservation_1243  -1
    load_1_19_17  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1148  -25
    arc_1_19_18  connected_order_arc_1149  -14
    arc_1_19_18  in_degree_1245  1
    arc_1_19_18  out_degree_1250  1
    arc_1_19_18  original_T_including_depot_unload_1266  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1148  1
    load_1_19_18  free_load_conservation_1249  -1
    load_1_19_18  free_load_conservation_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1150  -25
    arc_1_19_20  connected_order_arc_1151  -14
    arc_1_19_20  out_degree_1250  1
    arc_1_19_20  in_degree_1257  1
    arc_1_19_20  original_T_including_depot_unload_1266  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1150  1
    load_1_19_20  free_load_conservation_1255  1
    load_1_19_20  free_load_conservation_1261  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1152  -25
    arc_1_20_0  depot_return_or_bypass_1178  1
    arc_1_20_0  out_degree_1256  1
    arc_1_20_0  original_T_including_depot_unload_1266  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1152  1
    load_1_20_0  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_1153  -25
    arc_1_20_5  connected_order_arc_1154  -14
    arc_1_20_5  in_degree_1180  1
    arc_1_20_5  out_degree_1256  1
    arc_1_20_5  original_T_including_depot_unload_1266  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_1153  1
    load_1_20_5  segment_load_conservation_1183  -1
    load_1_20_5  segment_prefix_lb_1184  1
    load_1_20_5  segment_prefix_ub_1185  1
    load_1_20_5  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1155  -25
    arc_1_20_6  connected_order_arc_1156  -14
    arc_1_20_6  in_degree_1187  1
    arc_1_20_6  out_degree_1256  1
    arc_1_20_6  original_T_including_depot_unload_1266  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1155  1
    load_1_20_6  segment_load_conservation_1190  -1
    load_1_20_6  segment_prefix_lb_1191  1
    load_1_20_6  segment_prefix_ub_1192  1
    load_1_20_6  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1157  -25
    arc_1_20_7  connected_order_arc_1158  -14
    arc_1_20_7  in_degree_1194  1
    arc_1_20_7  out_degree_1256  1
    arc_1_20_7  original_T_including_depot_unload_1266  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1157  1
    load_1_20_7  segment_load_conservation_1197  -1
    load_1_20_7  segment_prefix_lb_1198  1
    load_1_20_7  segment_prefix_ub_1199  1
    load_1_20_7  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1159  -25
    arc_1_20_8  connected_order_arc_1160  -14
    arc_1_20_8  in_degree_1201  1
    arc_1_20_8  out_degree_1256  1
    arc_1_20_8  original_T_including_depot_unload_1266  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1159  1
    load_1_20_8  segment_load_conservation_1204  -1
    load_1_20_8  segment_prefix_lb_1205  1
    load_1_20_8  segment_prefix_ub_1206  1
    load_1_20_8  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1161  -25
    arc_1_20_9  connected_order_arc_1162  -14
    arc_1_20_9  in_degree_1208  1
    arc_1_20_9  out_degree_1256  1
    arc_1_20_9  original_T_including_depot_unload_1266  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1161  1
    load_1_20_9  segment_load_conservation_1211  -1
    load_1_20_9  segment_prefix_lb_1212  1
    load_1_20_9  segment_prefix_ub_1213  1
    load_1_20_9  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1163  -25
    arc_1_20_13  connected_order_arc_1164  -14
    arc_1_20_13  in_degree_1215  1
    arc_1_20_13  out_degree_1256  1
    arc_1_20_13  original_T_including_depot_unload_1266  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1163  1
    load_1_20_13  free_load_conservation_1219  -1
    load_1_20_13  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1165  -25
    arc_1_20_14  connected_order_arc_1166  -14
    arc_1_20_14  in_degree_1221  1
    arc_1_20_14  out_degree_1256  1
    arc_1_20_14  original_T_including_depot_unload_1266  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1165  1
    load_1_20_14  free_load_conservation_1225  -1
    load_1_20_14  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1167  -25
    arc_1_20_15  connected_order_arc_1168  -14
    arc_1_20_15  in_degree_1227  1
    arc_1_20_15  out_degree_1256  1
    arc_1_20_15  original_T_including_depot_unload_1266  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1167  1
    load_1_20_15  free_load_conservation_1231  -1
    load_1_20_15  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1169  -25
    arc_1_20_16  connected_order_arc_1170  -14
    arc_1_20_16  in_degree_1233  1
    arc_1_20_16  out_degree_1256  1
    arc_1_20_16  original_T_including_depot_unload_1266  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1169  1
    load_1_20_16  free_load_conservation_1237  -1
    load_1_20_16  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1171  -25
    arc_1_20_17  connected_order_arc_1172  -14
    arc_1_20_17  in_degree_1239  1
    arc_1_20_17  out_degree_1256  1
    arc_1_20_17  original_T_including_depot_unload_1266  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1171  1
    load_1_20_17  free_load_conservation_1243  -1
    load_1_20_17  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1173  -25
    arc_1_20_18  connected_order_arc_1174  -14
    arc_1_20_18  in_degree_1245  1
    arc_1_20_18  out_degree_1256  1
    arc_1_20_18  original_T_including_depot_unload_1266  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1173  1
    load_1_20_18  free_load_conservation_1249  -1
    load_1_20_18  free_load_conservation_1261  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1175  -25
    arc_1_20_19  connected_order_arc_1176  -14
    arc_1_20_19  in_degree_1251  1
    arc_1_20_19  out_degree_1256  1
    arc_1_20_19  original_T_including_depot_unload_1266  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1175  1
    load_1_20_19  free_load_conservation_1255  -1
    load_1_20_19  free_load_conservation_1261  1
    visit_2_10  out_degree_1512  -1
    visit_2_10  in_degree_1513  -1
    visit_2_10  order_active_lb_1514  -1
    visit_2_10  order_active_ub_1515  -11
    order_2_10  connected_order_arc_1281  -1
    order_2_10  connected_order_arc_1283  -1
    order_2_10  connected_order_arc_1285  -1
    order_2_10  connected_order_arc_1287  -1
    order_2_10  connected_order_arc_1289  -1
    order_2_10  connected_order_arc_1291  -1
    order_2_10  connected_order_arc_1293  -1
    order_2_10  connected_order_arc_1295  -1
    order_2_10  connected_order_arc_1297  -1
    order_2_10  connected_order_arc_1299  -1
    order_2_10  connected_order_arc_1302  1
    order_2_10  connected_order_arc_1323  1
    order_2_10  connected_order_arc_1344  1
    order_2_10  connected_order_arc_1365  1
    order_2_10  connected_order_arc_1386  1
    order_2_10  connected_order_arc_1407  1
    order_2_10  connected_order_arc_1428  1
    order_2_10  connected_order_arc_1449  1
    order_2_10  connected_order_arc_1470  1
    order_2_10  connected_order_arc_1491  1
    order_2_10  order_active_lb_1514  1
    order_2_10  order_active_ub_1515  1
    order_2_10  fixed_segment_relative_order_1581  -1
    visit_2_11  out_degree_1519  -1
    visit_2_11  in_degree_1520  -1
    visit_2_11  order_active_lb_1521  -1
    visit_2_11  order_active_ub_1522  -11
    order_2_11  connected_order_arc_1281  1
    order_2_11  connected_order_arc_1302  -1
    order_2_11  connected_order_arc_1304  -1
    order_2_11  connected_order_arc_1306  -1
    order_2_11  connected_order_arc_1308  -1
    order_2_11  connected_order_arc_1310  -1
    order_2_11  connected_order_arc_1312  -1
    order_2_11  connected_order_arc_1314  -1
    order_2_11  connected_order_arc_1316  -1
    order_2_11  connected_order_arc_1318  -1
    order_2_11  connected_order_arc_1320  -1
    order_2_11  connected_order_arc_1325  1
    order_2_11  connected_order_arc_1346  1
    order_2_11  connected_order_arc_1367  1
    order_2_11  connected_order_arc_1388  1
    order_2_11  connected_order_arc_1409  1
    order_2_11  connected_order_arc_1430  1
    order_2_11  connected_order_arc_1451  1
    order_2_11  connected_order_arc_1472  1
    order_2_11  connected_order_arc_1493  1
    order_2_11  order_active_lb_1521  1
    order_2_11  order_active_ub_1522  1
    order_2_11  fixed_segment_relative_order_1581  1
    order_2_11  fixed_segment_relative_order_1582  -1
    visit_2_12  out_degree_1526  -1
    visit_2_12  in_degree_1527  -1
    visit_2_12  order_active_lb_1528  -1
    visit_2_12  order_active_ub_1529  -11
    order_2_12  connected_order_arc_1283  1
    order_2_12  connected_order_arc_1304  1
    order_2_12  connected_order_arc_1323  -1
    order_2_12  connected_order_arc_1325  -1
    order_2_12  connected_order_arc_1327  -1
    order_2_12  connected_order_arc_1329  -1
    order_2_12  connected_order_arc_1331  -1
    order_2_12  connected_order_arc_1333  -1
    order_2_12  connected_order_arc_1335  -1
    order_2_12  connected_order_arc_1337  -1
    order_2_12  connected_order_arc_1339  -1
    order_2_12  connected_order_arc_1341  -1
    order_2_12  connected_order_arc_1348  1
    order_2_12  connected_order_arc_1369  1
    order_2_12  connected_order_arc_1390  1
    order_2_12  connected_order_arc_1411  1
    order_2_12  connected_order_arc_1432  1
    order_2_12  connected_order_arc_1453  1
    order_2_12  connected_order_arc_1474  1
    order_2_12  connected_order_arc_1495  1
    order_2_12  order_active_lb_1528  1
    order_2_12  order_active_ub_1529  1
    order_2_12  fixed_segment_relative_order_1582  1
    visit_2_13  out_degree_1533  -1
    visit_2_13  in_degree_1534  -1
    visit_2_13  order_active_lb_1535  -1
    visit_2_13  order_active_ub_1536  -11
    visit_2_13  service_visit_def_1537  -1
    order_2_13  connected_order_arc_1285  1
    order_2_13  connected_order_arc_1306  1
    order_2_13  connected_order_arc_1327  1
    order_2_13  connected_order_arc_1344  -1
    order_2_13  connected_order_arc_1346  -1
    order_2_13  connected_order_arc_1348  -1
    order_2_13  connected_order_arc_1350  -1
    order_2_13  connected_order_arc_1352  -1
    order_2_13  connected_order_arc_1354  -1
    order_2_13  connected_order_arc_1356  -1
    order_2_13  connected_order_arc_1358  -1
    order_2_13  connected_order_arc_1360  -1
    order_2_13  connected_order_arc_1362  -1
    order_2_13  connected_order_arc_1371  1
    order_2_13  connected_order_arc_1392  1
    order_2_13  connected_order_arc_1413  1
    order_2_13  connected_order_arc_1434  1
    order_2_13  connected_order_arc_1455  1
    order_2_13  connected_order_arc_1476  1
    order_2_13  connected_order_arc_1497  1
    order_2_13  order_active_lb_1535  1
    order_2_13  order_active_ub_1536  1
    visit_2_14  out_degree_1539  -1
    visit_2_14  in_degree_1540  -1
    visit_2_14  order_active_lb_1541  -1
    visit_2_14  order_active_ub_1542  -11
    visit_2_14  service_visit_def_1543  -1
    order_2_14  connected_order_arc_1287  1
    order_2_14  connected_order_arc_1308  1
    order_2_14  connected_order_arc_1329  1
    order_2_14  connected_order_arc_1350  1
    order_2_14  connected_order_arc_1365  -1
    order_2_14  connected_order_arc_1367  -1
    order_2_14  connected_order_arc_1369  -1
    order_2_14  connected_order_arc_1371  -1
    order_2_14  connected_order_arc_1373  -1
    order_2_14  connected_order_arc_1375  -1
    order_2_14  connected_order_arc_1377  -1
    order_2_14  connected_order_arc_1379  -1
    order_2_14  connected_order_arc_1381  -1
    order_2_14  connected_order_arc_1383  -1
    order_2_14  connected_order_arc_1394  1
    order_2_14  connected_order_arc_1415  1
    order_2_14  connected_order_arc_1436  1
    order_2_14  connected_order_arc_1457  1
    order_2_14  connected_order_arc_1478  1
    order_2_14  connected_order_arc_1499  1
    order_2_14  order_active_lb_1541  1
    order_2_14  order_active_ub_1542  1
    visit_2_15  out_degree_1545  -1
    visit_2_15  in_degree_1546  -1
    visit_2_15  order_active_lb_1547  -1
    visit_2_15  order_active_ub_1548  -11
    visit_2_15  service_visit_def_1549  -1
    order_2_15  connected_order_arc_1289  1
    order_2_15  connected_order_arc_1310  1
    order_2_15  connected_order_arc_1331  1
    order_2_15  connected_order_arc_1352  1
    order_2_15  connected_order_arc_1373  1
    order_2_15  connected_order_arc_1386  -1
    order_2_15  connected_order_arc_1388  -1
    order_2_15  connected_order_arc_1390  -1
    order_2_15  connected_order_arc_1392  -1
    order_2_15  connected_order_arc_1394  -1
    order_2_15  connected_order_arc_1396  -1
    order_2_15  connected_order_arc_1398  -1
    order_2_15  connected_order_arc_1400  -1
    order_2_15  connected_order_arc_1402  -1
    order_2_15  connected_order_arc_1404  -1
    order_2_15  connected_order_arc_1417  1
    order_2_15  connected_order_arc_1438  1
    order_2_15  connected_order_arc_1459  1
    order_2_15  connected_order_arc_1480  1
    order_2_15  connected_order_arc_1501  1
    order_2_15  order_active_lb_1547  1
    order_2_15  order_active_ub_1548  1
    visit_2_16  out_degree_1551  -1
    visit_2_16  in_degree_1552  -1
    visit_2_16  order_active_lb_1553  -1
    visit_2_16  order_active_ub_1554  -11
    visit_2_16  service_visit_def_1555  -1
    order_2_16  connected_order_arc_1291  1
    order_2_16  connected_order_arc_1312  1
    order_2_16  connected_order_arc_1333  1
    order_2_16  connected_order_arc_1354  1
    order_2_16  connected_order_arc_1375  1
    order_2_16  connected_order_arc_1396  1
    order_2_16  connected_order_arc_1407  -1
    order_2_16  connected_order_arc_1409  -1
    order_2_16  connected_order_arc_1411  -1
    order_2_16  connected_order_arc_1413  -1
    order_2_16  connected_order_arc_1415  -1
    order_2_16  connected_order_arc_1417  -1
    order_2_16  connected_order_arc_1419  -1
    order_2_16  connected_order_arc_1421  -1
    order_2_16  connected_order_arc_1423  -1
    order_2_16  connected_order_arc_1425  -1
    order_2_16  connected_order_arc_1440  1
    order_2_16  connected_order_arc_1461  1
    order_2_16  connected_order_arc_1482  1
    order_2_16  connected_order_arc_1503  1
    order_2_16  order_active_lb_1553  1
    order_2_16  order_active_ub_1554  1
    visit_2_17  out_degree_1557  -1
    visit_2_17  in_degree_1558  -1
    visit_2_17  order_active_lb_1559  -1
    visit_2_17  order_active_ub_1560  -11
    visit_2_17  service_visit_def_1561  -1
    order_2_17  connected_order_arc_1293  1
    order_2_17  connected_order_arc_1314  1
    order_2_17  connected_order_arc_1335  1
    order_2_17  connected_order_arc_1356  1
    order_2_17  connected_order_arc_1377  1
    order_2_17  connected_order_arc_1398  1
    order_2_17  connected_order_arc_1419  1
    order_2_17  connected_order_arc_1428  -1
    order_2_17  connected_order_arc_1430  -1
    order_2_17  connected_order_arc_1432  -1
    order_2_17  connected_order_arc_1434  -1
    order_2_17  connected_order_arc_1436  -1
    order_2_17  connected_order_arc_1438  -1
    order_2_17  connected_order_arc_1440  -1
    order_2_17  connected_order_arc_1442  -1
    order_2_17  connected_order_arc_1444  -1
    order_2_17  connected_order_arc_1446  -1
    order_2_17  connected_order_arc_1463  1
    order_2_17  connected_order_arc_1484  1
    order_2_17  connected_order_arc_1505  1
    order_2_17  order_active_lb_1559  1
    order_2_17  order_active_ub_1560  1
    visit_2_18  out_degree_1563  -1
    visit_2_18  in_degree_1564  -1
    visit_2_18  order_active_lb_1565  -1
    visit_2_18  order_active_ub_1566  -11
    visit_2_18  service_visit_def_1567  -1
    order_2_18  connected_order_arc_1295  1
    order_2_18  connected_order_arc_1316  1
    order_2_18  connected_order_arc_1337  1
    order_2_18  connected_order_arc_1358  1
    order_2_18  connected_order_arc_1379  1
    order_2_18  connected_order_arc_1400  1
    order_2_18  connected_order_arc_1421  1
    order_2_18  connected_order_arc_1442  1
    order_2_18  connected_order_arc_1449  -1
    order_2_18  connected_order_arc_1451  -1
    order_2_18  connected_order_arc_1453  -1
    order_2_18  connected_order_arc_1455  -1
    order_2_18  connected_order_arc_1457  -1
    order_2_18  connected_order_arc_1459  -1
    order_2_18  connected_order_arc_1461  -1
    order_2_18  connected_order_arc_1463  -1
    order_2_18  connected_order_arc_1465  -1
    order_2_18  connected_order_arc_1467  -1
    order_2_18  connected_order_arc_1486  1
    order_2_18  connected_order_arc_1507  1
    order_2_18  order_active_lb_1565  1
    order_2_18  order_active_ub_1566  1
    visit_2_19  out_degree_1569  -1
    visit_2_19  in_degree_1570  -1
    visit_2_19  order_active_lb_1571  -1
    visit_2_19  order_active_ub_1572  -11
    visit_2_19  service_visit_def_1573  -1
    order_2_19  connected_order_arc_1297  1
    order_2_19  connected_order_arc_1318  1
    order_2_19  connected_order_arc_1339  1
    order_2_19  connected_order_arc_1360  1
    order_2_19  connected_order_arc_1381  1
    order_2_19  connected_order_arc_1402  1
    order_2_19  connected_order_arc_1423  1
    order_2_19  connected_order_arc_1444  1
    order_2_19  connected_order_arc_1465  1
    order_2_19  connected_order_arc_1470  -1
    order_2_19  connected_order_arc_1472  -1
    order_2_19  connected_order_arc_1474  -1
    order_2_19  connected_order_arc_1476  -1
    order_2_19  connected_order_arc_1478  -1
    order_2_19  connected_order_arc_1480  -1
    order_2_19  connected_order_arc_1482  -1
    order_2_19  connected_order_arc_1484  -1
    order_2_19  connected_order_arc_1486  -1
    order_2_19  connected_order_arc_1488  -1
    order_2_19  connected_order_arc_1509  1
    order_2_19  order_active_lb_1571  1
    order_2_19  order_active_ub_1572  1
    visit_2_20  out_degree_1575  -1
    visit_2_20  in_degree_1576  -1
    visit_2_20  order_active_lb_1577  -1
    visit_2_20  order_active_ub_1578  -11
    visit_2_20  service_visit_def_1579  -1
    order_2_20  connected_order_arc_1299  1
    order_2_20  connected_order_arc_1320  1
    order_2_20  connected_order_arc_1341  1
    order_2_20  connected_order_arc_1362  1
    order_2_20  connected_order_arc_1383  1
    order_2_20  connected_order_arc_1404  1
    order_2_20  connected_order_arc_1425  1
    order_2_20  connected_order_arc_1446  1
    order_2_20  connected_order_arc_1467  1
    order_2_20  connected_order_arc_1488  1
    order_2_20  connected_order_arc_1491  -1
    order_2_20  connected_order_arc_1493  -1
    order_2_20  connected_order_arc_1495  -1
    order_2_20  connected_order_arc_1497  -1
    order_2_20  connected_order_arc_1499  -1
    order_2_20  connected_order_arc_1501  -1
    order_2_20  connected_order_arc_1503  -1
    order_2_20  connected_order_arc_1505  -1
    order_2_20  connected_order_arc_1507  -1
    order_2_20  connected_order_arc_1509  -1
    order_2_20  order_active_lb_1577  1
    order_2_20  order_active_ub_1578  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1267  -30
    arc_2_0_0  depot_departure_or_bypass_1510  1
    arc_2_0_0  depot_return_or_bypass_1511  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1267  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1268  -30
    arc_2_0_10  depot_departure_or_bypass_1510  1
    arc_2_0_10  in_degree_1513  1
    arc_2_0_10  original_T_including_depot_unload_1583  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1268  1
    load_2_0_10  segment_load_conservation_1516  -1
    load_2_0_10  segment_prefix_lb_1517  1
    load_2_0_10  segment_prefix_ub_1518  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1269  -30
    arc_2_0_11  depot_departure_or_bypass_1510  1
    arc_2_0_11  in_degree_1520  1
    arc_2_0_11  original_T_including_depot_unload_1583  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1269  1
    load_2_0_11  segment_load_conservation_1523  -1
    load_2_0_11  segment_prefix_lb_1524  1
    load_2_0_11  segment_prefix_ub_1525  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1270  -30
    arc_2_0_12  depot_departure_or_bypass_1510  1
    arc_2_0_12  in_degree_1527  1
    arc_2_0_12  original_T_including_depot_unload_1583  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1270  1
    load_2_0_12  segment_load_conservation_1530  -1
    load_2_0_12  segment_prefix_lb_1531  1
    load_2_0_12  segment_prefix_ub_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1271  -30
    arc_2_0_13  depot_departure_or_bypass_1510  1
    arc_2_0_13  in_degree_1534  1
    arc_2_0_13  original_T_including_depot_unload_1583  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1271  1
    load_2_0_13  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1272  -30
    arc_2_0_14  depot_departure_or_bypass_1510  1
    arc_2_0_14  in_degree_1540  1
    arc_2_0_14  original_T_including_depot_unload_1583  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1272  1
    load_2_0_14  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1273  -30
    arc_2_0_15  depot_departure_or_bypass_1510  1
    arc_2_0_15  in_degree_1546  1
    arc_2_0_15  original_T_including_depot_unload_1583  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1273  1
    load_2_0_15  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1274  -30
    arc_2_0_16  depot_departure_or_bypass_1510  1
    arc_2_0_16  in_degree_1552  1
    arc_2_0_16  original_T_including_depot_unload_1583  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1274  1
    load_2_0_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1275  -30
    arc_2_0_17  depot_departure_or_bypass_1510  1
    arc_2_0_17  in_degree_1558  1
    arc_2_0_17  original_T_including_depot_unload_1583  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1275  1
    load_2_0_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1276  -30
    arc_2_0_18  depot_departure_or_bypass_1510  1
    arc_2_0_18  in_degree_1564  1
    arc_2_0_18  original_T_including_depot_unload_1583  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1276  1
    load_2_0_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1277  -30
    arc_2_0_19  depot_departure_or_bypass_1510  1
    arc_2_0_19  in_degree_1570  1
    arc_2_0_19  original_T_including_depot_unload_1583  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1277  1
    load_2_0_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1278  -30
    arc_2_0_20  depot_departure_or_bypass_1510  1
    arc_2_0_20  in_degree_1576  1
    arc_2_0_20  original_T_including_depot_unload_1583  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1278  1
    load_2_0_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1279  -30
    arc_2_10_0  depot_return_or_bypass_1511  1
    arc_2_10_0  out_degree_1512  1
    arc_2_10_0  original_T_including_depot_unload_1583  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1279  1
    load_2_10_0  segment_load_conservation_1516  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1280  -30
    arc_2_10_11  connected_order_arc_1281  -12
    arc_2_10_11  out_degree_1512  1
    arc_2_10_11  in_degree_1520  1
    arc_2_10_11  original_T_including_depot_unload_1583  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1280  1
    load_2_10_11  segment_load_conservation_1516  1
    load_2_10_11  segment_load_conservation_1523  -1
    load_2_10_11  segment_prefix_lb_1524  1
    load_2_10_11  segment_prefix_ub_1525  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1282  -30
    arc_2_10_12  connected_order_arc_1283  -12
    arc_2_10_12  out_degree_1512  1
    arc_2_10_12  in_degree_1527  1
    arc_2_10_12  original_T_including_depot_unload_1583  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1282  1
    load_2_10_12  segment_load_conservation_1516  1
    load_2_10_12  segment_load_conservation_1530  -1
    load_2_10_12  segment_prefix_lb_1531  1
    load_2_10_12  segment_prefix_ub_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1284  -30
    arc_2_10_13  connected_order_arc_1285  -12
    arc_2_10_13  out_degree_1512  1
    arc_2_10_13  in_degree_1534  1
    arc_2_10_13  original_T_including_depot_unload_1583  1.8580343290482886e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1284  1
    load_2_10_13  segment_load_conservation_1516  1
    load_2_10_13  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1286  -30
    arc_2_10_14  connected_order_arc_1287  -12
    arc_2_10_14  out_degree_1512  1
    arc_2_10_14  in_degree_1540  1
    arc_2_10_14  original_T_including_depot_unload_1583  1.6583475127728254e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1286  1
    load_2_10_14  segment_load_conservation_1516  1
    load_2_10_14  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1288  -30
    arc_2_10_15  connected_order_arc_1289  -12
    arc_2_10_15  out_degree_1512  1
    arc_2_10_15  in_degree_1546  1
    arc_2_10_15  original_T_including_depot_unload_1583  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1288  1
    load_2_10_15  segment_load_conservation_1516  1
    load_2_10_15  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1290  -30
    arc_2_10_16  connected_order_arc_1291  -12
    arc_2_10_16  out_degree_1512  1
    arc_2_10_16  in_degree_1552  1
    arc_2_10_16  original_T_including_depot_unload_1583  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1290  1
    load_2_10_16  segment_load_conservation_1516  1
    load_2_10_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1292  -30
    arc_2_10_17  connected_order_arc_1293  -12
    arc_2_10_17  out_degree_1512  1
    arc_2_10_17  in_degree_1558  1
    arc_2_10_17  original_T_including_depot_unload_1583  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1292  1
    load_2_10_17  segment_load_conservation_1516  1
    load_2_10_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1294  -30
    arc_2_10_18  connected_order_arc_1295  -12
    arc_2_10_18  out_degree_1512  1
    arc_2_10_18  in_degree_1564  1
    arc_2_10_18  original_T_including_depot_unload_1583  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1294  1
    load_2_10_18  segment_load_conservation_1516  1
    load_2_10_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1296  -30
    arc_2_10_19  connected_order_arc_1297  -12
    arc_2_10_19  out_degree_1512  1
    arc_2_10_19  in_degree_1570  1
    arc_2_10_19  original_T_including_depot_unload_1583  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1296  1
    load_2_10_19  segment_load_conservation_1516  1
    load_2_10_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1298  -30
    arc_2_10_20  connected_order_arc_1299  -12
    arc_2_10_20  out_degree_1512  1
    arc_2_10_20  in_degree_1576  1
    arc_2_10_20  original_T_including_depot_unload_1583  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1298  1
    load_2_10_20  segment_load_conservation_1516  1
    load_2_10_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1300  -30
    arc_2_11_0  depot_return_or_bypass_1511  1
    arc_2_11_0  out_degree_1519  1
    arc_2_11_0  original_T_including_depot_unload_1583  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1300  1
    load_2_11_0  segment_load_conservation_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1301  -30
    arc_2_11_10  connected_order_arc_1302  -12
    arc_2_11_10  in_degree_1513  1
    arc_2_11_10  out_degree_1519  1
    arc_2_11_10  original_T_including_depot_unload_1583  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1301  1
    load_2_11_10  segment_load_conservation_1516  -1
    load_2_11_10  segment_prefix_lb_1517  1
    load_2_11_10  segment_prefix_ub_1518  1
    load_2_11_10  segment_load_conservation_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1303  -30
    arc_2_11_12  connected_order_arc_1304  -12
    arc_2_11_12  out_degree_1519  1
    arc_2_11_12  in_degree_1527  1
    arc_2_11_12  original_T_including_depot_unload_1583  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1303  1
    load_2_11_12  segment_load_conservation_1523  1
    load_2_11_12  segment_load_conservation_1530  -1
    load_2_11_12  segment_prefix_lb_1531  1
    load_2_11_12  segment_prefix_ub_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1305  -30
    arc_2_11_13  connected_order_arc_1306  -12
    arc_2_11_13  out_degree_1519  1
    arc_2_11_13  in_degree_1534  1
    arc_2_11_13  original_T_including_depot_unload_1583  1.3110718450902477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1305  1
    load_2_11_13  segment_load_conservation_1523  1
    load_2_11_13  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1307  -30
    arc_2_11_14  connected_order_arc_1308  -12
    arc_2_11_14  out_degree_1519  1
    arc_2_11_14  in_degree_1540  1
    arc_2_11_14  original_T_including_depot_unload_1583  1.3174943724568802e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1307  1
    load_2_11_14  segment_load_conservation_1523  1
    load_2_11_14  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1309  -30
    arc_2_11_15  connected_order_arc_1310  -12
    arc_2_11_15  out_degree_1519  1
    arc_2_11_15  in_degree_1546  1
    arc_2_11_15  original_T_including_depot_unload_1583  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1309  1
    load_2_11_15  segment_load_conservation_1523  1
    load_2_11_15  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1311  -30
    arc_2_11_16  connected_order_arc_1312  -12
    arc_2_11_16  out_degree_1519  1
    arc_2_11_16  in_degree_1552  1
    arc_2_11_16  original_T_including_depot_unload_1583  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1311  1
    load_2_11_16  segment_load_conservation_1523  1
    load_2_11_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1313  -30
    arc_2_11_17  connected_order_arc_1314  -12
    arc_2_11_17  out_degree_1519  1
    arc_2_11_17  in_degree_1558  1
    arc_2_11_17  original_T_including_depot_unload_1583  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1313  1
    load_2_11_17  segment_load_conservation_1523  1
    load_2_11_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1315  -30
    arc_2_11_18  connected_order_arc_1316  -12
    arc_2_11_18  out_degree_1519  1
    arc_2_11_18  in_degree_1564  1
    arc_2_11_18  original_T_including_depot_unload_1583  1.5322275462532455e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1315  1
    load_2_11_18  segment_load_conservation_1523  1
    load_2_11_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1317  -30
    arc_2_11_19  connected_order_arc_1318  -12
    arc_2_11_19  out_degree_1519  1
    arc_2_11_19  in_degree_1570  1
    arc_2_11_19  original_T_including_depot_unload_1583  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1317  1
    load_2_11_19  segment_load_conservation_1523  1
    load_2_11_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1319  -30
    arc_2_11_20  connected_order_arc_1320  -12
    arc_2_11_20  out_degree_1519  1
    arc_2_11_20  in_degree_1576  1
    arc_2_11_20  original_T_including_depot_unload_1583  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1319  1
    load_2_11_20  segment_load_conservation_1523  1
    load_2_11_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1321  -30
    arc_2_12_0  depot_return_or_bypass_1511  1
    arc_2_12_0  out_degree_1526  1
    arc_2_12_0  original_T_including_depot_unload_1583  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1321  1
    load_2_12_0  segment_load_conservation_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1322  -30
    arc_2_12_10  connected_order_arc_1323  -12
    arc_2_12_10  in_degree_1513  1
    arc_2_12_10  out_degree_1526  1
    arc_2_12_10  original_T_including_depot_unload_1583  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1322  1
    load_2_12_10  segment_load_conservation_1516  -1
    load_2_12_10  segment_prefix_lb_1517  1
    load_2_12_10  segment_prefix_ub_1518  1
    load_2_12_10  segment_load_conservation_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1324  -30
    arc_2_12_11  connected_order_arc_1325  -12
    arc_2_12_11  in_degree_1520  1
    arc_2_12_11  out_degree_1526  1
    arc_2_12_11  original_T_including_depot_unload_1583  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1324  1
    load_2_12_11  segment_load_conservation_1523  -1
    load_2_12_11  segment_prefix_lb_1524  1
    load_2_12_11  segment_prefix_ub_1525  1
    load_2_12_11  segment_load_conservation_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1326  -30
    arc_2_12_13  connected_order_arc_1327  -12
    arc_2_12_13  out_degree_1526  1
    arc_2_12_13  in_degree_1534  1
    arc_2_12_13  original_T_including_depot_unload_1583  9.7093568976197776e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1326  1
    load_2_12_13  segment_load_conservation_1530  1
    load_2_12_13  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1328  -30
    arc_2_12_14  connected_order_arc_1329  -12
    arc_2_12_14  out_degree_1526  1
    arc_2_12_14  in_degree_1540  1
    arc_2_12_14  original_T_including_depot_unload_1583  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1328  1
    load_2_12_14  segment_load_conservation_1530  1
    load_2_12_14  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1330  -30
    arc_2_12_15  connected_order_arc_1331  -12
    arc_2_12_15  out_degree_1526  1
    arc_2_12_15  in_degree_1546  1
    arc_2_12_15  original_T_including_depot_unload_1583  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1330  1
    load_2_12_15  segment_load_conservation_1530  1
    load_2_12_15  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1332  -30
    arc_2_12_16  connected_order_arc_1333  -12
    arc_2_12_16  out_degree_1526  1
    arc_2_12_16  in_degree_1552  1
    arc_2_12_16  original_T_including_depot_unload_1583  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1332  1
    load_2_12_16  segment_load_conservation_1530  1
    load_2_12_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1334  -30
    arc_2_12_17  connected_order_arc_1335  -12
    arc_2_12_17  out_degree_1526  1
    arc_2_12_17  in_degree_1558  1
    arc_2_12_17  original_T_including_depot_unload_1583  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1334  1
    load_2_12_17  segment_load_conservation_1530  1
    load_2_12_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1336  -30
    arc_2_12_18  connected_order_arc_1337  -12
    arc_2_12_18  out_degree_1526  1
    arc_2_12_18  in_degree_1564  1
    arc_2_12_18  original_T_including_depot_unload_1583  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1336  1
    load_2_12_18  segment_load_conservation_1530  1
    load_2_12_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1338  -30
    arc_2_12_19  connected_order_arc_1339  -12
    arc_2_12_19  out_degree_1526  1
    arc_2_12_19  in_degree_1570  1
    arc_2_12_19  original_T_including_depot_unload_1583  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1338  1
    load_2_12_19  segment_load_conservation_1530  1
    load_2_12_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1340  -30
    arc_2_12_20  connected_order_arc_1341  -12
    arc_2_12_20  out_degree_1526  1
    arc_2_12_20  in_degree_1576  1
    arc_2_12_20  original_T_including_depot_unload_1583  1.1260666281343611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1340  1
    load_2_12_20  segment_load_conservation_1530  1
    load_2_12_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1342  -30
    arc_2_13_0  depot_return_or_bypass_1511  1
    arc_2_13_0  out_degree_1533  1
    arc_2_13_0  original_T_including_depot_unload_1583  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1342  1
    load_2_13_0  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1343  -30
    arc_2_13_10  connected_order_arc_1344  -12
    arc_2_13_10  in_degree_1513  1
    arc_2_13_10  out_degree_1533  1
    arc_2_13_10  original_T_including_depot_unload_1583  8.6713096341893186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1343  1
    load_2_13_10  segment_load_conservation_1516  -1
    load_2_13_10  segment_prefix_lb_1517  1
    load_2_13_10  segment_prefix_ub_1518  1
    load_2_13_10  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1345  -30
    arc_2_13_11  connected_order_arc_1346  -12
    arc_2_13_11  in_degree_1520  1
    arc_2_13_11  out_degree_1533  1
    arc_2_13_11  original_T_including_depot_unload_1583  1.3110718450902477e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1345  1
    load_2_13_11  segment_load_conservation_1523  -1
    load_2_13_11  segment_prefix_lb_1524  1
    load_2_13_11  segment_prefix_ub_1525  1
    load_2_13_11  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1347  -30
    arc_2_13_12  connected_order_arc_1348  -12
    arc_2_13_12  in_degree_1527  1
    arc_2_13_12  out_degree_1533  1
    arc_2_13_12  original_T_including_depot_unload_1583  9.7093568976197776e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1347  1
    load_2_13_12  segment_load_conservation_1530  -1
    load_2_13_12  segment_prefix_lb_1531  1
    load_2_13_12  segment_prefix_ub_1532  1
    load_2_13_12  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1349  -30
    arc_2_13_14  connected_order_arc_1350  -12
    arc_2_13_14  out_degree_1533  1
    arc_2_13_14  in_degree_1540  1
    arc_2_13_14  original_T_including_depot_unload_1583  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1349  1
    load_2_13_14  free_load_conservation_1538  1
    load_2_13_14  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1351  -30
    arc_2_13_15  connected_order_arc_1352  -12
    arc_2_13_15  out_degree_1533  1
    arc_2_13_15  in_degree_1546  1
    arc_2_13_15  original_T_including_depot_unload_1583  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1351  1
    load_2_13_15  free_load_conservation_1538  1
    load_2_13_15  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1353  -30
    arc_2_13_16  connected_order_arc_1354  -12
    arc_2_13_16  out_degree_1533  1
    arc_2_13_16  in_degree_1552  1
    arc_2_13_16  original_T_including_depot_unload_1583  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1353  1
    load_2_13_16  free_load_conservation_1538  1
    load_2_13_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1355  -30
    arc_2_13_17  connected_order_arc_1356  -12
    arc_2_13_17  out_degree_1533  1
    arc_2_13_17  in_degree_1558  1
    arc_2_13_17  original_T_including_depot_unload_1583  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1355  1
    load_2_13_17  free_load_conservation_1538  1
    load_2_13_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1357  -30
    arc_2_13_18  connected_order_arc_1358  -12
    arc_2_13_18  out_degree_1533  1
    arc_2_13_18  in_degree_1564  1
    arc_2_13_18  original_T_including_depot_unload_1583  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1357  1
    load_2_13_18  free_load_conservation_1538  1
    load_2_13_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1359  -30
    arc_2_13_19  connected_order_arc_1360  -12
    arc_2_13_19  out_degree_1533  1
    arc_2_13_19  in_degree_1570  1
    arc_2_13_19  original_T_including_depot_unload_1583  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1359  1
    load_2_13_19  free_load_conservation_1538  1
    load_2_13_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1361  -30
    arc_2_13_20  connected_order_arc_1362  -12
    arc_2_13_20  out_degree_1533  1
    arc_2_13_20  in_degree_1576  1
    arc_2_13_20  original_T_including_depot_unload_1583  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1361  1
    load_2_13_20  free_load_conservation_1538  1
    load_2_13_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1363  -30
    arc_2_14_0  depot_return_or_bypass_1511  1
    arc_2_14_0  out_degree_1539  1
    arc_2_14_0  original_T_including_depot_unload_1583  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1363  1
    load_2_14_0  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1364  -30
    arc_2_14_10  connected_order_arc_1365  -12
    arc_2_14_10  in_degree_1513  1
    arc_2_14_10  out_degree_1539  1
    arc_2_14_10  original_T_including_depot_unload_1583  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1364  1
    load_2_14_10  segment_load_conservation_1516  -1
    load_2_14_10  segment_prefix_lb_1517  1
    load_2_14_10  segment_prefix_ub_1518  1
    load_2_14_10  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1366  -30
    arc_2_14_11  connected_order_arc_1367  -12
    arc_2_14_11  in_degree_1520  1
    arc_2_14_11  out_degree_1539  1
    arc_2_14_11  original_T_including_depot_unload_1583  1.3174943724568802e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1366  1
    load_2_14_11  segment_load_conservation_1523  -1
    load_2_14_11  segment_prefix_lb_1524  1
    load_2_14_11  segment_prefix_ub_1525  1
    load_2_14_11  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1368  -30
    arc_2_14_12  connected_order_arc_1369  -12
    arc_2_14_12  in_degree_1527  1
    arc_2_14_12  out_degree_1539  1
    arc_2_14_12  original_T_including_depot_unload_1583  1.0510800781097112e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1368  1
    load_2_14_12  segment_load_conservation_1530  -1
    load_2_14_12  segment_prefix_lb_1531  1
    load_2_14_12  segment_prefix_ub_1532  1
    load_2_14_12  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1370  -30
    arc_2_14_13  connected_order_arc_1371  -12
    arc_2_14_13  in_degree_1534  1
    arc_2_14_13  out_degree_1539  1
    arc_2_14_13  original_T_including_depot_unload_1583  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1370  1
    load_2_14_13  free_load_conservation_1538  -1
    load_2_14_13  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1372  -30
    arc_2_14_15  connected_order_arc_1373  -12
    arc_2_14_15  out_degree_1539  1
    arc_2_14_15  in_degree_1546  1
    arc_2_14_15  original_T_including_depot_unload_1583  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1372  1
    load_2_14_15  free_load_conservation_1544  1
    load_2_14_15  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1374  -30
    arc_2_14_16  connected_order_arc_1375  -12
    arc_2_14_16  out_degree_1539  1
    arc_2_14_16  in_degree_1552  1
    arc_2_14_16  original_T_including_depot_unload_1583  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1374  1
    load_2_14_16  free_load_conservation_1544  1
    load_2_14_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1376  -30
    arc_2_14_17  connected_order_arc_1377  -12
    arc_2_14_17  out_degree_1539  1
    arc_2_14_17  in_degree_1558  1
    arc_2_14_17  original_T_including_depot_unload_1583  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1376  1
    load_2_14_17  free_load_conservation_1544  1
    load_2_14_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1378  -30
    arc_2_14_18  connected_order_arc_1379  -12
    arc_2_14_18  out_degree_1539  1
    arc_2_14_18  in_degree_1564  1
    arc_2_14_18  original_T_including_depot_unload_1583  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1378  1
    load_2_14_18  free_load_conservation_1544  1
    load_2_14_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1380  -30
    arc_2_14_19  connected_order_arc_1381  -12
    arc_2_14_19  out_degree_1539  1
    arc_2_14_19  in_degree_1570  1
    arc_2_14_19  original_T_including_depot_unload_1583  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1380  1
    load_2_14_19  free_load_conservation_1544  1
    load_2_14_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1382  -30
    arc_2_14_20  connected_order_arc_1383  -12
    arc_2_14_20  out_degree_1539  1
    arc_2_14_20  in_degree_1576  1
    arc_2_14_20  original_T_including_depot_unload_1583  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1382  1
    load_2_14_20  free_load_conservation_1544  1
    load_2_14_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1384  -30
    arc_2_15_0  depot_return_or_bypass_1511  1
    arc_2_15_0  out_degree_1545  1
    arc_2_15_0  original_T_including_depot_unload_1583  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1384  1
    load_2_15_0  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1385  -30
    arc_2_15_10  connected_order_arc_1386  -12
    arc_2_15_10  in_degree_1513  1
    arc_2_15_10  out_degree_1545  1
    arc_2_15_10  original_T_including_depot_unload_1583  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1385  1
    load_2_15_10  segment_load_conservation_1516  -1
    load_2_15_10  segment_prefix_lb_1517  1
    load_2_15_10  segment_prefix_ub_1518  1
    load_2_15_10  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1387  -30
    arc_2_15_11  connected_order_arc_1388  -12
    arc_2_15_11  in_degree_1520  1
    arc_2_15_11  out_degree_1545  1
    arc_2_15_11  original_T_including_depot_unload_1583  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1387  1
    load_2_15_11  segment_load_conservation_1523  -1
    load_2_15_11  segment_prefix_lb_1524  1
    load_2_15_11  segment_prefix_ub_1525  1
    load_2_15_11  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1389  -30
    arc_2_15_12  connected_order_arc_1390  -12
    arc_2_15_12  in_degree_1527  1
    arc_2_15_12  out_degree_1545  1
    arc_2_15_12  original_T_including_depot_unload_1583  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1389  1
    load_2_15_12  segment_load_conservation_1530  -1
    load_2_15_12  segment_prefix_lb_1531  1
    load_2_15_12  segment_prefix_ub_1532  1
    load_2_15_12  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1391  -30
    arc_2_15_13  connected_order_arc_1392  -12
    arc_2_15_13  in_degree_1534  1
    arc_2_15_13  out_degree_1545  1
    arc_2_15_13  original_T_including_depot_unload_1583  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1391  1
    load_2_15_13  free_load_conservation_1538  -1
    load_2_15_13  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1393  -30
    arc_2_15_14  connected_order_arc_1394  -12
    arc_2_15_14  in_degree_1540  1
    arc_2_15_14  out_degree_1545  1
    arc_2_15_14  original_T_including_depot_unload_1583  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1393  1
    load_2_15_14  free_load_conservation_1544  -1
    load_2_15_14  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1395  -30
    arc_2_15_16  connected_order_arc_1396  -12
    arc_2_15_16  out_degree_1545  1
    arc_2_15_16  in_degree_1552  1
    arc_2_15_16  original_T_including_depot_unload_1583  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1395  1
    load_2_15_16  free_load_conservation_1550  1
    load_2_15_16  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1397  -30
    arc_2_15_17  connected_order_arc_1398  -12
    arc_2_15_17  out_degree_1545  1
    arc_2_15_17  in_degree_1558  1
    arc_2_15_17  original_T_including_depot_unload_1583  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1397  1
    load_2_15_17  free_load_conservation_1550  1
    load_2_15_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1399  -30
    arc_2_15_18  connected_order_arc_1400  -12
    arc_2_15_18  out_degree_1545  1
    arc_2_15_18  in_degree_1564  1
    arc_2_15_18  original_T_including_depot_unload_1583  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1399  1
    load_2_15_18  free_load_conservation_1550  1
    load_2_15_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1401  -30
    arc_2_15_19  connected_order_arc_1402  -12
    arc_2_15_19  out_degree_1545  1
    arc_2_15_19  in_degree_1570  1
    arc_2_15_19  original_T_including_depot_unload_1583  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1401  1
    load_2_15_19  free_load_conservation_1550  1
    load_2_15_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1403  -30
    arc_2_15_20  connected_order_arc_1404  -12
    arc_2_15_20  out_degree_1545  1
    arc_2_15_20  in_degree_1576  1
    arc_2_15_20  original_T_including_depot_unload_1583  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1403  1
    load_2_15_20  free_load_conservation_1550  1
    load_2_15_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1405  -30
    arc_2_16_0  depot_return_or_bypass_1511  1
    arc_2_16_0  out_degree_1551  1
    arc_2_16_0  original_T_including_depot_unload_1583  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1405  1
    load_2_16_0  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1406  -30
    arc_2_16_10  connected_order_arc_1407  -12
    arc_2_16_10  in_degree_1513  1
    arc_2_16_10  out_degree_1551  1
    arc_2_16_10  original_T_including_depot_unload_1583  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1406  1
    load_2_16_10  segment_load_conservation_1516  -1
    load_2_16_10  segment_prefix_lb_1517  1
    load_2_16_10  segment_prefix_ub_1518  1
    load_2_16_10  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1408  -30
    arc_2_16_11  connected_order_arc_1409  -12
    arc_2_16_11  in_degree_1520  1
    arc_2_16_11  out_degree_1551  1
    arc_2_16_11  original_T_including_depot_unload_1583  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1408  1
    load_2_16_11  segment_load_conservation_1523  -1
    load_2_16_11  segment_prefix_lb_1524  1
    load_2_16_11  segment_prefix_ub_1525  1
    load_2_16_11  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1410  -30
    arc_2_16_12  connected_order_arc_1411  -12
    arc_2_16_12  in_degree_1527  1
    arc_2_16_12  out_degree_1551  1
    arc_2_16_12  original_T_including_depot_unload_1583  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1410  1
    load_2_16_12  segment_load_conservation_1530  -1
    load_2_16_12  segment_prefix_lb_1531  1
    load_2_16_12  segment_prefix_ub_1532  1
    load_2_16_12  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1412  -30
    arc_2_16_13  connected_order_arc_1413  -12
    arc_2_16_13  in_degree_1534  1
    arc_2_16_13  out_degree_1551  1
    arc_2_16_13  original_T_including_depot_unload_1583  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1412  1
    load_2_16_13  free_load_conservation_1538  -1
    load_2_16_13  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1414  -30
    arc_2_16_14  connected_order_arc_1415  -12
    arc_2_16_14  in_degree_1540  1
    arc_2_16_14  out_degree_1551  1
    arc_2_16_14  original_T_including_depot_unload_1583  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1414  1
    load_2_16_14  free_load_conservation_1544  -1
    load_2_16_14  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1416  -30
    arc_2_16_15  connected_order_arc_1417  -12
    arc_2_16_15  in_degree_1546  1
    arc_2_16_15  out_degree_1551  1
    arc_2_16_15  original_T_including_depot_unload_1583  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1416  1
    load_2_16_15  free_load_conservation_1550  -1
    load_2_16_15  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1418  -30
    arc_2_16_17  connected_order_arc_1419  -12
    arc_2_16_17  out_degree_1551  1
    arc_2_16_17  in_degree_1558  1
    arc_2_16_17  original_T_including_depot_unload_1583  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1418  1
    load_2_16_17  free_load_conservation_1556  1
    load_2_16_17  free_load_conservation_1562  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1420  -30
    arc_2_16_18  connected_order_arc_1421  -12
    arc_2_16_18  out_degree_1551  1
    arc_2_16_18  in_degree_1564  1
    arc_2_16_18  original_T_including_depot_unload_1583  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1420  1
    load_2_16_18  free_load_conservation_1556  1
    load_2_16_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1422  -30
    arc_2_16_19  connected_order_arc_1423  -12
    arc_2_16_19  out_degree_1551  1
    arc_2_16_19  in_degree_1570  1
    arc_2_16_19  original_T_including_depot_unload_1583  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1422  1
    load_2_16_19  free_load_conservation_1556  1
    load_2_16_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1424  -30
    arc_2_16_20  connected_order_arc_1425  -12
    arc_2_16_20  out_degree_1551  1
    arc_2_16_20  in_degree_1576  1
    arc_2_16_20  original_T_including_depot_unload_1583  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1424  1
    load_2_16_20  free_load_conservation_1556  1
    load_2_16_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1426  -30
    arc_2_17_0  depot_return_or_bypass_1511  1
    arc_2_17_0  out_degree_1557  1
    arc_2_17_0  original_T_including_depot_unload_1583  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1426  1
    load_2_17_0  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1427  -30
    arc_2_17_10  connected_order_arc_1428  -12
    arc_2_17_10  in_degree_1513  1
    arc_2_17_10  out_degree_1557  1
    arc_2_17_10  original_T_including_depot_unload_1583  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1427  1
    load_2_17_10  segment_load_conservation_1516  -1
    load_2_17_10  segment_prefix_lb_1517  1
    load_2_17_10  segment_prefix_ub_1518  1
    load_2_17_10  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1429  -30
    arc_2_17_11  connected_order_arc_1430  -12
    arc_2_17_11  in_degree_1520  1
    arc_2_17_11  out_degree_1557  1
    arc_2_17_11  original_T_including_depot_unload_1583  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1429  1
    load_2_17_11  segment_load_conservation_1523  -1
    load_2_17_11  segment_prefix_lb_1524  1
    load_2_17_11  segment_prefix_ub_1525  1
    load_2_17_11  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1431  -30
    arc_2_17_12  connected_order_arc_1432  -12
    arc_2_17_12  in_degree_1527  1
    arc_2_17_12  out_degree_1557  1
    arc_2_17_12  original_T_including_depot_unload_1583  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1431  1
    load_2_17_12  segment_load_conservation_1530  -1
    load_2_17_12  segment_prefix_lb_1531  1
    load_2_17_12  segment_prefix_ub_1532  1
    load_2_17_12  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1433  -30
    arc_2_17_13  connected_order_arc_1434  -12
    arc_2_17_13  in_degree_1534  1
    arc_2_17_13  out_degree_1557  1
    arc_2_17_13  original_T_including_depot_unload_1583  9.6598937061987863e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1433  1
    load_2_17_13  free_load_conservation_1538  -1
    load_2_17_13  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1435  -30
    arc_2_17_14  connected_order_arc_1436  -12
    arc_2_17_14  in_degree_1540  1
    arc_2_17_14  out_degree_1557  1
    arc_2_17_14  original_T_including_depot_unload_1583  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1435  1
    load_2_17_14  free_load_conservation_1544  -1
    load_2_17_14  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1437  -30
    arc_2_17_15  connected_order_arc_1438  -12
    arc_2_17_15  in_degree_1546  1
    arc_2_17_15  out_degree_1557  1
    arc_2_17_15  original_T_including_depot_unload_1583  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1437  1
    load_2_17_15  free_load_conservation_1550  -1
    load_2_17_15  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1439  -30
    arc_2_17_16  connected_order_arc_1440  -12
    arc_2_17_16  in_degree_1552  1
    arc_2_17_16  out_degree_1557  1
    arc_2_17_16  original_T_including_depot_unload_1583  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1439  1
    load_2_17_16  free_load_conservation_1556  -1
    load_2_17_16  free_load_conservation_1562  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1441  -30
    arc_2_17_18  connected_order_arc_1442  -12
    arc_2_17_18  out_degree_1557  1
    arc_2_17_18  in_degree_1564  1
    arc_2_17_18  original_T_including_depot_unload_1583  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1441  1
    load_2_17_18  free_load_conservation_1562  1
    load_2_17_18  free_load_conservation_1568  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1443  -30
    arc_2_17_19  connected_order_arc_1444  -12
    arc_2_17_19  out_degree_1557  1
    arc_2_17_19  in_degree_1570  1
    arc_2_17_19  original_T_including_depot_unload_1583  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1443  1
    load_2_17_19  free_load_conservation_1562  1
    load_2_17_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1445  -30
    arc_2_17_20  connected_order_arc_1446  -12
    arc_2_17_20  out_degree_1557  1
    arc_2_17_20  in_degree_1576  1
    arc_2_17_20  original_T_including_depot_unload_1583  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1445  1
    load_2_17_20  free_load_conservation_1562  1
    load_2_17_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1447  -30
    arc_2_18_0  depot_return_or_bypass_1511  1
    arc_2_18_0  out_degree_1563  1
    arc_2_18_0  original_T_including_depot_unload_1583  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1447  1
    load_2_18_0  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1448  -30
    arc_2_18_10  connected_order_arc_1449  -12
    arc_2_18_10  in_degree_1513  1
    arc_2_18_10  out_degree_1563  1
    arc_2_18_10  original_T_including_depot_unload_1583  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1448  1
    load_2_18_10  segment_load_conservation_1516  -1
    load_2_18_10  segment_prefix_lb_1517  1
    load_2_18_10  segment_prefix_ub_1518  1
    load_2_18_10  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1450  -30
    arc_2_18_11  connected_order_arc_1451  -12
    arc_2_18_11  in_degree_1520  1
    arc_2_18_11  out_degree_1563  1
    arc_2_18_11  original_T_including_depot_unload_1583  1.5322275462532455e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1450  1
    load_2_18_11  segment_load_conservation_1523  -1
    load_2_18_11  segment_prefix_lb_1524  1
    load_2_18_11  segment_prefix_ub_1525  1
    load_2_18_11  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1452  -30
    arc_2_18_12  connected_order_arc_1453  -12
    arc_2_18_12  in_degree_1527  1
    arc_2_18_12  out_degree_1563  1
    arc_2_18_12  original_T_including_depot_unload_1583  1.2686001679750689e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1452  1
    load_2_18_12  segment_load_conservation_1530  -1
    load_2_18_12  segment_prefix_lb_1531  1
    load_2_18_12  segment_prefix_ub_1532  1
    load_2_18_12  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1454  -30
    arc_2_18_13  connected_order_arc_1455  -12
    arc_2_18_13  in_degree_1534  1
    arc_2_18_13  out_degree_1563  1
    arc_2_18_13  original_T_including_depot_unload_1583  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1454  1
    load_2_18_13  free_load_conservation_1538  -1
    load_2_18_13  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1456  -30
    arc_2_18_14  connected_order_arc_1457  -12
    arc_2_18_14  in_degree_1540  1
    arc_2_18_14  out_degree_1563  1
    arc_2_18_14  original_T_including_depot_unload_1583  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1456  1
    load_2_18_14  free_load_conservation_1544  -1
    load_2_18_14  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1458  -30
    arc_2_18_15  connected_order_arc_1459  -12
    arc_2_18_15  in_degree_1546  1
    arc_2_18_15  out_degree_1563  1
    arc_2_18_15  original_T_including_depot_unload_1583  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1458  1
    load_2_18_15  free_load_conservation_1550  -1
    load_2_18_15  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1460  -30
    arc_2_18_16  connected_order_arc_1461  -12
    arc_2_18_16  in_degree_1552  1
    arc_2_18_16  out_degree_1563  1
    arc_2_18_16  original_T_including_depot_unload_1583  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1460  1
    load_2_18_16  free_load_conservation_1556  -1
    load_2_18_16  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1462  -30
    arc_2_18_17  connected_order_arc_1463  -12
    arc_2_18_17  in_degree_1558  1
    arc_2_18_17  out_degree_1563  1
    arc_2_18_17  original_T_including_depot_unload_1583  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1462  1
    load_2_18_17  free_load_conservation_1562  -1
    load_2_18_17  free_load_conservation_1568  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1464  -30
    arc_2_18_19  connected_order_arc_1465  -12
    arc_2_18_19  out_degree_1563  1
    arc_2_18_19  in_degree_1570  1
    arc_2_18_19  original_T_including_depot_unload_1583  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1464  1
    load_2_18_19  free_load_conservation_1568  1
    load_2_18_19  free_load_conservation_1574  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1466  -30
    arc_2_18_20  connected_order_arc_1467  -12
    arc_2_18_20  out_degree_1563  1
    arc_2_18_20  in_degree_1576  1
    arc_2_18_20  original_T_including_depot_unload_1583  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1466  1
    load_2_18_20  free_load_conservation_1568  1
    load_2_18_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1468  -30
    arc_2_19_0  depot_return_or_bypass_1511  1
    arc_2_19_0  out_degree_1569  1
    arc_2_19_0  original_T_including_depot_unload_1583  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1468  1
    load_2_19_0  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1469  -30
    arc_2_19_10  connected_order_arc_1470  -12
    arc_2_19_10  in_degree_1513  1
    arc_2_19_10  out_degree_1569  1
    arc_2_19_10  original_T_including_depot_unload_1583  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1469  1
    load_2_19_10  segment_load_conservation_1516  -1
    load_2_19_10  segment_prefix_lb_1517  1
    load_2_19_10  segment_prefix_ub_1518  1
    load_2_19_10  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1471  -30
    arc_2_19_11  connected_order_arc_1472  -12
    arc_2_19_11  in_degree_1520  1
    arc_2_19_11  out_degree_1569  1
    arc_2_19_11  original_T_including_depot_unload_1583  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1471  1
    load_2_19_11  segment_load_conservation_1523  -1
    load_2_19_11  segment_prefix_lb_1524  1
    load_2_19_11  segment_prefix_ub_1525  1
    load_2_19_11  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1473  -30
    arc_2_19_12  connected_order_arc_1474  -12
    arc_2_19_12  in_degree_1527  1
    arc_2_19_12  out_degree_1569  1
    arc_2_19_12  original_T_including_depot_unload_1583  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1473  1
    load_2_19_12  segment_load_conservation_1530  -1
    load_2_19_12  segment_prefix_lb_1531  1
    load_2_19_12  segment_prefix_ub_1532  1
    load_2_19_12  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1475  -30
    arc_2_19_13  connected_order_arc_1476  -12
    arc_2_19_13  in_degree_1534  1
    arc_2_19_13  out_degree_1569  1
    arc_2_19_13  original_T_including_depot_unload_1583  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1475  1
    load_2_19_13  free_load_conservation_1538  -1
    load_2_19_13  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1477  -30
    arc_2_19_14  connected_order_arc_1478  -12
    arc_2_19_14  in_degree_1540  1
    arc_2_19_14  out_degree_1569  1
    arc_2_19_14  original_T_including_depot_unload_1583  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1477  1
    load_2_19_14  free_load_conservation_1544  -1
    load_2_19_14  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1479  -30
    arc_2_19_15  connected_order_arc_1480  -12
    arc_2_19_15  in_degree_1546  1
    arc_2_19_15  out_degree_1569  1
    arc_2_19_15  original_T_including_depot_unload_1583  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1479  1
    load_2_19_15  free_load_conservation_1550  -1
    load_2_19_15  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1481  -30
    arc_2_19_16  connected_order_arc_1482  -12
    arc_2_19_16  in_degree_1552  1
    arc_2_19_16  out_degree_1569  1
    arc_2_19_16  original_T_including_depot_unload_1583  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1481  1
    load_2_19_16  free_load_conservation_1556  -1
    load_2_19_16  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1483  -30
    arc_2_19_17  connected_order_arc_1484  -12
    arc_2_19_17  in_degree_1558  1
    arc_2_19_17  out_degree_1569  1
    arc_2_19_17  original_T_including_depot_unload_1583  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1483  1
    load_2_19_17  free_load_conservation_1562  -1
    load_2_19_17  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1485  -30
    arc_2_19_18  connected_order_arc_1486  -12
    arc_2_19_18  in_degree_1564  1
    arc_2_19_18  out_degree_1569  1
    arc_2_19_18  original_T_including_depot_unload_1583  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1485  1
    load_2_19_18  free_load_conservation_1568  -1
    load_2_19_18  free_load_conservation_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1487  -30
    arc_2_19_20  connected_order_arc_1488  -12
    arc_2_19_20  out_degree_1569  1
    arc_2_19_20  in_degree_1576  1
    arc_2_19_20  original_T_including_depot_unload_1583  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1487  1
    load_2_19_20  free_load_conservation_1574  1
    load_2_19_20  free_load_conservation_1580  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1489  -30
    arc_2_20_0  depot_return_or_bypass_1511  1
    arc_2_20_0  out_degree_1575  1
    arc_2_20_0  original_T_including_depot_unload_1583  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1489  1
    load_2_20_0  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1490  -30
    arc_2_20_10  connected_order_arc_1491  -12
    arc_2_20_10  in_degree_1513  1
    arc_2_20_10  out_degree_1575  1
    arc_2_20_10  original_T_including_depot_unload_1583  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1490  1
    load_2_20_10  segment_load_conservation_1516  -1
    load_2_20_10  segment_prefix_lb_1517  1
    load_2_20_10  segment_prefix_ub_1518  1
    load_2_20_10  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1492  -30
    arc_2_20_11  connected_order_arc_1493  -12
    arc_2_20_11  in_degree_1520  1
    arc_2_20_11  out_degree_1575  1
    arc_2_20_11  original_T_including_depot_unload_1583  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1492  1
    load_2_20_11  segment_load_conservation_1523  -1
    load_2_20_11  segment_prefix_lb_1524  1
    load_2_20_11  segment_prefix_ub_1525  1
    load_2_20_11  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1494  -30
    arc_2_20_12  connected_order_arc_1495  -12
    arc_2_20_12  in_degree_1527  1
    arc_2_20_12  out_degree_1575  1
    arc_2_20_12  original_T_including_depot_unload_1583  1.1260666281343611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1494  1
    load_2_20_12  segment_load_conservation_1530  -1
    load_2_20_12  segment_prefix_lb_1531  1
    load_2_20_12  segment_prefix_ub_1532  1
    load_2_20_12  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1496  -30
    arc_2_20_13  connected_order_arc_1497  -12
    arc_2_20_13  in_degree_1534  1
    arc_2_20_13  out_degree_1575  1
    arc_2_20_13  original_T_including_depot_unload_1583  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1496  1
    load_2_20_13  free_load_conservation_1538  -1
    load_2_20_13  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1498  -30
    arc_2_20_14  connected_order_arc_1499  -12
    arc_2_20_14  in_degree_1540  1
    arc_2_20_14  out_degree_1575  1
    arc_2_20_14  original_T_including_depot_unload_1583  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1498  1
    load_2_20_14  free_load_conservation_1544  -1
    load_2_20_14  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1500  -30
    arc_2_20_15  connected_order_arc_1501  -12
    arc_2_20_15  in_degree_1546  1
    arc_2_20_15  out_degree_1575  1
    arc_2_20_15  original_T_including_depot_unload_1583  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1500  1
    load_2_20_15  free_load_conservation_1550  -1
    load_2_20_15  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1502  -30
    arc_2_20_16  connected_order_arc_1503  -12
    arc_2_20_16  in_degree_1552  1
    arc_2_20_16  out_degree_1575  1
    arc_2_20_16  original_T_including_depot_unload_1583  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1502  1
    load_2_20_16  free_load_conservation_1556  -1
    load_2_20_16  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1504  -30
    arc_2_20_17  connected_order_arc_1505  -12
    arc_2_20_17  in_degree_1558  1
    arc_2_20_17  out_degree_1575  1
    arc_2_20_17  original_T_including_depot_unload_1583  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1504  1
    load_2_20_17  free_load_conservation_1562  -1
    load_2_20_17  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1506  -30
    arc_2_20_18  connected_order_arc_1507  -12
    arc_2_20_18  in_degree_1564  1
    arc_2_20_18  out_degree_1575  1
    arc_2_20_18  original_T_including_depot_unload_1583  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1506  1
    load_2_20_18  free_load_conservation_1568  -1
    load_2_20_18  free_load_conservation_1580  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1508  -30
    arc_2_20_19  connected_order_arc_1509  -12
    arc_2_20_19  in_degree_1570  1
    arc_2_20_19  out_degree_1575  1
    arc_2_20_19  original_T_including_depot_unload_1583  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1508  1
    load_2_20_19  free_load_conservation_1574  -1
    load_2_20_19  free_load_conservation_1580  1
RHS
    RHS1      OBJ       -0.6225
    RHS1      onehot_10_40  1
    RHS1      onehot_7_79  1
    RHS1      onehot_31_108  1
    RHS1      onehot_3_147  1
    RHS1      onehot_14_182  1
    RHS1      onehot_11_211  1
    RHS1      onehot_2_246  1
    RHS1      onehot_4_281  1
    RHS1      stock_ub_285  47
    RHS1      parent_nonstrict_scope_286  2.9257784389027564e-01
    RHS1      normalization_343  1
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_603  -12
    RHS1      connected_order_arc_605  -12
    RHS1      connected_order_arc_607  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_611  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_615  -12
    RHS1      connected_order_arc_617  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_626  -12
    RHS1      connected_order_arc_628  -12
    RHS1      connected_order_arc_630  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_634  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_638  -12
    RHS1      connected_order_arc_640  -12
    RHS1      connected_order_arc_643  -12
    RHS1      connected_order_arc_645  -12
    RHS1      connected_order_arc_647  -12
    RHS1      connected_order_arc_649  -12
    RHS1      connected_order_arc_651  -12
    RHS1      connected_order_arc_653  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_657  -12
    RHS1      connected_order_arc_659  -12
    RHS1      connected_order_arc_661  -12
    RHS1      connected_order_arc_663  -12
    RHS1      connected_order_arc_666  -12
    RHS1      connected_order_arc_668  -12
    RHS1      connected_order_arc_670  -12
    RHS1      connected_order_arc_672  -12
    RHS1      connected_order_arc_674  -12
    RHS1      connected_order_arc_676  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_680  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_689  -12
    RHS1      connected_order_arc_691  -12
    RHS1      connected_order_arc_693  -12
    RHS1      connected_order_arc_695  -12
    RHS1      connected_order_arc_697  -12
    RHS1      connected_order_arc_699  -12
    RHS1      connected_order_arc_701  -12
    RHS1      connected_order_arc_703  -12
    RHS1      connected_order_arc_705  -12
    RHS1      connected_order_arc_707  -12
    RHS1      connected_order_arc_709  -12
    RHS1      connected_order_arc_712  -12
    RHS1      connected_order_arc_714  -12
    RHS1      connected_order_arc_716  -12
    RHS1      connected_order_arc_718  -12
    RHS1      connected_order_arc_720  -12
    RHS1      connected_order_arc_722  -12
    RHS1      connected_order_arc_724  -12
    RHS1      connected_order_arc_726  -12
    RHS1      connected_order_arc_728  -12
    RHS1      connected_order_arc_730  -12
    RHS1      connected_order_arc_732  -12
    RHS1      connected_order_arc_735  -12
    RHS1      connected_order_arc_737  -12
    RHS1      connected_order_arc_739  -12
    RHS1      connected_order_arc_741  -12
    RHS1      connected_order_arc_743  -12
    RHS1      connected_order_arc_745  -12
    RHS1      connected_order_arc_747  -12
    RHS1      connected_order_arc_749  -12
    RHS1      connected_order_arc_751  -12
    RHS1      connected_order_arc_753  -12
    RHS1      connected_order_arc_755  -12
    RHS1      depot_departure_or_bypass_756  1
    RHS1      depot_return_or_bypass_757  1
    RHS1      segment_load_conservation_762  -8
    RHS1      segment_prefix_lb_763  8
    RHS1      segment_prefix_ub_764  20
    RHS1      segment_load_conservation_769  -4
    RHS1      segment_prefix_lb_770  4
    RHS1      segment_prefix_ub_771  20
    RHS1      segment_load_conservation_776  -2
    RHS1      segment_prefix_lb_777  2
    RHS1      segment_prefix_ub_778  20
    RHS1      segment_load_conservation_783  -4
    RHS1      segment_prefix_lb_784  4
    RHS1      segment_prefix_ub_785  10
    RHS1      fixed_segment_relative_order_834  1
    RHS1      fixed_segment_relative_order_835  1
    RHS1      fixed_segment_relative_order_836  1
    RHS1      original_T_including_depot_unload_837  4.9587045443215020e+03
    RHS1      connected_order_arc_854  -13
    RHS1      connected_order_arc_856  -13
    RHS1      connected_order_arc_858  -13
    RHS1      connected_order_arc_860  -13
    RHS1      connected_order_arc_862  -13
    RHS1      connected_order_arc_864  -13
    RHS1      connected_order_arc_866  -13
    RHS1      connected_order_arc_868  -13
    RHS1      connected_order_arc_870  -13
    RHS1      connected_order_arc_872  -13
    RHS1      connected_order_arc_874  -13
    RHS1      connected_order_arc_876  -13
    RHS1      connected_order_arc_879  -13
    RHS1      connected_order_arc_881  -13
    RHS1      connected_order_arc_883  -13
    RHS1      connected_order_arc_885  -13
    RHS1      connected_order_arc_887  -13
    RHS1      connected_order_arc_889  -13
    RHS1      connected_order_arc_891  -13
    RHS1      connected_order_arc_893  -13
    RHS1      connected_order_arc_895  -13
    RHS1      connected_order_arc_897  -13
    RHS1      connected_order_arc_899  -13
    RHS1      connected_order_arc_901  -13
    RHS1      connected_order_arc_904  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_908  -13
    RHS1      connected_order_arc_910  -13
    RHS1      connected_order_arc_912  -13
    RHS1      connected_order_arc_914  -13
    RHS1      connected_order_arc_916  -13
    RHS1      connected_order_arc_918  -13
    RHS1      connected_order_arc_920  -13
    RHS1      connected_order_arc_922  -13
    RHS1      connected_order_arc_924  -13
    RHS1      connected_order_arc_926  -13
    RHS1      connected_order_arc_929  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_933  -13
    RHS1      connected_order_arc_935  -13
    RHS1      connected_order_arc_937  -13
    RHS1      connected_order_arc_939  -13
    RHS1      connected_order_arc_941  -13
    RHS1      connected_order_arc_943  -13
    RHS1      connected_order_arc_945  -13
    RHS1      connected_order_arc_947  -13
    RHS1      connected_order_arc_949  -13
    RHS1      connected_order_arc_951  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_962  -13
    RHS1      connected_order_arc_964  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_974  -13
    RHS1      connected_order_arc_976  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_987  -13
    RHS1      connected_order_arc_989  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_999  -13
    RHS1      connected_order_arc_1001  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1012  -13
    RHS1      connected_order_arc_1014  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1024  -13
    RHS1      connected_order_arc_1026  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1037  -13
    RHS1      connected_order_arc_1039  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1049  -13
    RHS1      connected_order_arc_1051  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1062  -13
    RHS1      connected_order_arc_1064  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1074  -13
    RHS1      connected_order_arc_1076  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1087  -13
    RHS1      connected_order_arc_1089  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1099  -13
    RHS1      connected_order_arc_1101  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1112  -13
    RHS1      connected_order_arc_1114  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      connected_order_arc_1124  -13
    RHS1      connected_order_arc_1126  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1133  -13
    RHS1      connected_order_arc_1135  -13
    RHS1      connected_order_arc_1137  -13
    RHS1      connected_order_arc_1139  -13
    RHS1      connected_order_arc_1141  -13
    RHS1      connected_order_arc_1143  -13
    RHS1      connected_order_arc_1145  -13
    RHS1      connected_order_arc_1147  -13
    RHS1      connected_order_arc_1149  -13
    RHS1      connected_order_arc_1151  -13
    RHS1      connected_order_arc_1154  -13
    RHS1      connected_order_arc_1156  -13
    RHS1      connected_order_arc_1158  -13
    RHS1      connected_order_arc_1160  -13
    RHS1      connected_order_arc_1162  -13
    RHS1      connected_order_arc_1164  -13
    RHS1      connected_order_arc_1166  -13
    RHS1      connected_order_arc_1168  -13
    RHS1      connected_order_arc_1170  -13
    RHS1      connected_order_arc_1172  -13
    RHS1      connected_order_arc_1174  -13
    RHS1      connected_order_arc_1176  -13
    RHS1      depot_departure_or_bypass_1177  1
    RHS1      depot_return_or_bypass_1178  1
    RHS1      segment_load_conservation_1183  6
    RHS1      segment_prefix_ub_1185  19
    RHS1      segment_load_conservation_1190  -4
    RHS1      segment_prefix_lb_1191  4
    RHS1      segment_prefix_ub_1192  25
    RHS1      segment_load_conservation_1197  2
    RHS1      segment_prefix_lb_1198  2
    RHS1      segment_prefix_ub_1199  21
    RHS1      segment_load_conservation_1204  -2
    RHS1      segment_prefix_lb_1205  2
    RHS1      segment_prefix_ub_1206  25
    RHS1      segment_load_conservation_1211  -5
    RHS1      segment_prefix_lb_1212  5
    RHS1      segment_prefix_ub_1213  25
    RHS1      fixed_segment_relative_order_1262  1
    RHS1      fixed_segment_relative_order_1263  1
    RHS1      fixed_segment_relative_order_1264  1
    RHS1      fixed_segment_relative_order_1265  1
    RHS1      original_T_including_depot_unload_1266  3.0532706585097294e+03
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1291  -11
    RHS1      connected_order_arc_1293  -11
    RHS1      connected_order_arc_1295  -11
    RHS1      connected_order_arc_1297  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1312  -11
    RHS1      connected_order_arc_1314  -11
    RHS1      connected_order_arc_1316  -11
    RHS1      connected_order_arc_1318  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1333  -11
    RHS1      connected_order_arc_1335  -11
    RHS1      connected_order_arc_1337  -11
    RHS1      connected_order_arc_1339  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1354  -11
    RHS1      connected_order_arc_1356  -11
    RHS1      connected_order_arc_1358  -11
    RHS1      connected_order_arc_1360  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1375  -11
    RHS1      connected_order_arc_1377  -11
    RHS1      connected_order_arc_1379  -11
    RHS1      connected_order_arc_1381  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      connected_order_arc_1396  -11
    RHS1      connected_order_arc_1398  -11
    RHS1      connected_order_arc_1400  -11
    RHS1      connected_order_arc_1402  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1415  -11
    RHS1      connected_order_arc_1417  -11
    RHS1      connected_order_arc_1419  -11
    RHS1      connected_order_arc_1421  -11
    RHS1      connected_order_arc_1423  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1436  -11
    RHS1      connected_order_arc_1438  -11
    RHS1      connected_order_arc_1440  -11
    RHS1      connected_order_arc_1442  -11
    RHS1      connected_order_arc_1444  -11
    RHS1      connected_order_arc_1446  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      connected_order_arc_1457  -11
    RHS1      connected_order_arc_1459  -11
    RHS1      connected_order_arc_1461  -11
    RHS1      connected_order_arc_1463  -11
    RHS1      connected_order_arc_1465  -11
    RHS1      connected_order_arc_1467  -11
    RHS1      connected_order_arc_1470  -11
    RHS1      connected_order_arc_1472  -11
    RHS1      connected_order_arc_1474  -11
    RHS1      connected_order_arc_1476  -11
    RHS1      connected_order_arc_1478  -11
    RHS1      connected_order_arc_1480  -11
    RHS1      connected_order_arc_1482  -11
    RHS1      connected_order_arc_1484  -11
    RHS1      connected_order_arc_1486  -11
    RHS1      connected_order_arc_1488  -11
    RHS1      connected_order_arc_1491  -11
    RHS1      connected_order_arc_1493  -11
    RHS1      connected_order_arc_1495  -11
    RHS1      connected_order_arc_1497  -11
    RHS1      connected_order_arc_1499  -11
    RHS1      connected_order_arc_1501  -11
    RHS1      connected_order_arc_1503  -11
    RHS1      connected_order_arc_1505  -11
    RHS1      connected_order_arc_1507  -11
    RHS1      connected_order_arc_1509  -11
    RHS1      depot_departure_or_bypass_1510  1
    RHS1      depot_return_or_bypass_1511  1
    RHS1      segment_load_conservation_1516  1
    RHS1      segment_prefix_ub_1518  25
    RHS1      segment_load_conservation_1523  3
    RHS1      segment_prefix_ub_1525  27
    RHS1      segment_load_conservation_1530  3
    RHS1      segment_prefix_ub_1532  27
    RHS1      fixed_segment_relative_order_1581  1
    RHS1      fixed_segment_relative_order_1582  1
    RHS1      original_T_including_depot_unload_1583  4.0565627028631952e+03
BOUNDS
 LO BND1      t         2.5219923739729182e-02
 UP BND1      t         4.3054843669955919e-02
 UP BND1      q         5.3707784389027569e-01
 BV BND1      x_10_0  
 UP BND1      w_10_0    4.3054843669955919e-02
 BV BND1      x_10_1  
 UP BND1      w_10_1    4.3054843669955919e-02
 BV BND1      x_10_2  
 UP BND1      w_10_2    4.3054843669955919e-02
 BV BND1      x_10_3  
 UP BND1      w_10_3    4.3054843669955919e-02
 BV BND1      x_10_4  
 UP BND1      w_10_4    4.3054843669955919e-02
 BV BND1      x_10_5  
 UP BND1      w_10_5    4.3054843669955919e-02
 BV BND1      x_10_6  
 UP BND1      w_10_6    4.3054843669955919e-02
 BV BND1      x_10_7  
 UP BND1      w_10_7    4.3054843669955919e-02
 BV BND1      x_10_8  
 UP BND1      w_10_8    4.3054843669955919e-02
 BV BND1      x_10_9  
 UP BND1      w_10_9    4.3054843669955919e-02
 BV BND1      x_10_10 
 UP BND1      w_10_10   4.3054843669955919e-02
 BV BND1      x_10_11 
 UP BND1      w_10_11   4.3054843669955919e-02
 BV BND1      x_10_12 
 UP BND1      w_10_12   4.3054843669955919e-02
 BV BND1      x_10_13 
 UP BND1      w_10_13   4.3054843669955919e-02
 BV BND1      x_10_14 
 UP BND1      w_10_14   4.3054843669955919e-02
 BV BND1      x_10_15 
 UP BND1      w_10_15   4.3054843669955919e-02
 BV BND1      x_10_16 
 UP BND1      w_10_16   4.3054843669955919e-02
 BV BND1      x_10_17 
 UP BND1      w_10_17   4.3054843669955919e-02
 BV BND1      x_10_18 
 UP BND1      w_10_18   4.3054843669955919e-02
 BV BND1      x_10_19 
 UP BND1      w_10_19   4.3054843669955919e-02
 UP BND1      rho_10    1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.3054843669955919e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.3054843669955919e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.3054843669955919e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.3054843669955919e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.3054843669955919e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.3054843669955919e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.3054843669955919e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.3054843669955919e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.3054843669955919e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.3054843669955919e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.3054843669955919e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.3054843669955919e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.3054843669955919e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.3054843669955919e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.3054843669955919e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.3054843669955919e-02
 BV BND1      x_7_16  
 UP BND1      w_7_16    4.3054843669955919e-02
 BV BND1      x_7_17  
 UP BND1      w_7_17    4.3054843669955919e-02
 UP BND1      rho_7     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.3054843669955919e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.3054843669955919e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.3054843669955919e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.3054843669955919e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.3054843669955919e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.3054843669955919e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.3054843669955919e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.3054843669955919e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.3054843669955919e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.3054843669955919e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.3054843669955919e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.3054843669955919e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.3054843669955919e-02
 UP BND1      rho_31    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.3054843669955919e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.3054843669955919e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.3054843669955919e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.3054843669955919e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.3054843669955919e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.3054843669955919e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.3054843669955919e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.3054843669955919e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.3054843669955919e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.3054843669955919e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.3054843669955919e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.3054843669955919e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.3054843669955919e-02
 BV BND1      x_3_13  
 UP BND1      w_3_13    4.3054843669955919e-02
 BV BND1      x_3_14  
 UP BND1      w_3_14    4.3054843669955919e-02
 BV BND1      x_3_15  
 UP BND1      w_3_15    4.3054843669955919e-02
 BV BND1      x_3_16  
 UP BND1      w_3_16    4.3054843669955919e-02
 BV BND1      x_3_17  
 UP BND1      w_3_17    4.3054843669955919e-02
 UP BND1      rho_3     1
 BV BND1      x_14_0  
 UP BND1      w_14_0    4.3054843669955919e-02
 BV BND1      x_14_1  
 UP BND1      w_14_1    4.3054843669955919e-02
 BV BND1      x_14_2  
 UP BND1      w_14_2    4.3054843669955919e-02
 BV BND1      x_14_3  
 UP BND1      w_14_3    4.3054843669955919e-02
 BV BND1      x_14_4  
 UP BND1      w_14_4    4.3054843669955919e-02
 BV BND1      x_14_5  
 UP BND1      w_14_5    4.3054843669955919e-02
 BV BND1      x_14_6  
 UP BND1      w_14_6    4.3054843669955919e-02
 BV BND1      x_14_7  
 UP BND1      w_14_7    4.3054843669955919e-02
 BV BND1      x_14_8  
 UP BND1      w_14_8    4.3054843669955919e-02
 BV BND1      x_14_9  
 UP BND1      w_14_9    4.3054843669955919e-02
 BV BND1      x_14_10 
 UP BND1      w_14_10   4.3054843669955919e-02
 BV BND1      x_14_11 
 UP BND1      w_14_11   4.3054843669955919e-02
 BV BND1      x_14_12 
 UP BND1      w_14_12   4.3054843669955919e-02
 BV BND1      x_14_13 
 UP BND1      w_14_13   4.3054843669955919e-02
 BV BND1      x_14_14 
 UP BND1      w_14_14   4.3054843669955919e-02
 BV BND1      x_14_15 
 UP BND1      w_14_15   4.3054843669955919e-02
 UP BND1      rho_14    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.3054843669955919e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.3054843669955919e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.3054843669955919e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.3054843669955919e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.3054843669955919e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.3054843669955919e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.3054843669955919e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.3054843669955919e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.3054843669955919e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.3054843669955919e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.3054843669955919e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   4.3054843669955919e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   4.3054843669955919e-02
 UP BND1      rho_11    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.3054843669955919e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.3054843669955919e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.3054843669955919e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.3054843669955919e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.3054843669955919e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.3054843669955919e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.3054843669955919e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.3054843669955919e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.3054843669955919e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.3054843669955919e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.3054843669955919e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.3054843669955919e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.3054843669955919e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.3054843669955919e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.3054843669955919e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.3054843669955919e-02
 UP BND1      rho_2     1
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.3054843669955919e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.3054843669955919e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.3054843669955919e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.3054843669955919e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.3054843669955919e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.3054843669955919e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.3054843669955919e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.3054843669955919e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.3054843669955919e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.3054843669955919e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.3054843669955919e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.3054843669955919e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.3054843669955919e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.3054843669955919e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.3054843669955919e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.3054843669955919e-02
 UP BND1      rho_4     1
 UP BND1      a_10_7    1
 UP BND1      a_10_31   1
 UP BND1      a_10_3    1
 UP BND1      a_10_14   1
 UP BND1      a_10_11   1
 UP BND1      a_10_2    1
 UP BND1      a_10_4    1
 UP BND1      a_7_31    1
 UP BND1      a_7_3     1
 UP BND1      a_7_14    1
 UP BND1      a_7_11    1
 UP BND1      a_7_2     1
 UP BND1      a_7_4     1
 UP BND1      a_31_3    1
 UP BND1      a_31_14   1
 UP BND1      a_31_11   1
 UP BND1      a_31_2    1
 UP BND1      a_31_4    1
 UP BND1      a_3_14    1
 UP BND1      a_3_11    1
 UP BND1      a_3_2     1
 UP BND1      a_3_4     1
 UP BND1      a_14_11   1
 UP BND1      a_14_2    1
 UP BND1      a_14_4    1
 UP BND1      a_11_2    1
 UP BND1      a_11_4    1
 UP BND1      a_2_4     1
 BV BND1      service_0_10_0
 BV BND1      service_0_10_1
 BV BND1      service_0_10_2
 BV BND1      service_0_10_3
 BV BND1      service_0_10_4
 BV BND1      service_0_10_5
 BV BND1      service_0_10_6
 BV BND1      service_0_10_7
 BV BND1      service_0_10_8
 BV BND1      service_0_10_9
 BV BND1      service_0_10_10
 BV BND1      service_0_10_11
 BV BND1      service_0_10_12
 BV BND1      service_0_10_13
 BV BND1      service_0_10_14
 BV BND1      service_0_10_16
 BV BND1      service_0_10_17
 BV BND1      service_0_10_18
 BV BND1      service_0_10_19
 BV BND1      service_1_10_0
 BV BND1      service_1_10_1
 BV BND1      service_1_10_2
 BV BND1      service_1_10_3
 BV BND1      service_1_10_4
 BV BND1      service_1_10_5
 BV BND1      service_1_10_6
 BV BND1      service_1_10_7
 BV BND1      service_1_10_8
 BV BND1      service_1_10_9
 BV BND1      service_1_10_10
 BV BND1      service_1_10_11
 BV BND1      service_1_10_12
 BV BND1      service_1_10_13
 BV BND1      service_1_10_14
 BV BND1      service_1_10_16
 BV BND1      service_1_10_17
 BV BND1      service_1_10_18
 BV BND1      service_1_10_19
 BV BND1      service_2_10_0
 BV BND1      service_2_10_1
 BV BND1      service_2_10_2
 BV BND1      service_2_10_3
 BV BND1      service_2_10_4
 BV BND1      service_2_10_5
 BV BND1      service_2_10_6
 BV BND1      service_2_10_7
 BV BND1      service_2_10_8
 BV BND1      service_2_10_9
 BV BND1      service_2_10_10
 BV BND1      service_2_10_11
 BV BND1      service_2_10_12
 BV BND1      service_2_10_13
 BV BND1      service_2_10_14
 BV BND1      service_2_10_16
 BV BND1      service_2_10_17
 BV BND1      service_2_10_18
 BV BND1      service_2_10_19
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_11
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_11
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_2_14_0
 BV BND1      service_2_14_1
 BV BND1      service_2_14_3
 BV BND1      service_2_14_4
 BV BND1      service_2_14_5
 BV BND1      service_2_14_6
 BV BND1      service_2_14_7
 BV BND1      service_2_14_8
 BV BND1      service_2_14_9
 BV BND1      service_2_14_10
 BV BND1      service_2_14_11
 BV BND1      service_2_14_12
 BV BND1      service_2_14_13
 BV BND1      service_2_14_14
 BV BND1      service_2_14_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_8
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_2_11_11
 BV BND1      service_2_11_12
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_2
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  13
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_9
 UP BND1      load_1_5_9  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_5
 UP BND1      load_1_9_5  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
