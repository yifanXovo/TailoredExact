* Signature: 0x6d1dae03292ca63
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_20_32
 E  normalized_mass_20_33
 E  normalized_ratio_20_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_12_67
 E  normalized_mass_12_68
 E  normalized_ratio_12_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 E  onehot_18_102
 E  normalized_mass_18_103
 E  normalized_ratio_18_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 E  onehot_13_109
 E  normalized_mass_13_110
 E  normalized_ratio_13_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_17_146
 E  normalized_mass_17_147
 E  normalized_ratio_17_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 E  onehot_14_181
 E  normalized_mass_14_182
 E  normalized_ratio_14_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_11_216
 E  normalized_mass_11_217
 E  normalized_ratio_11_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 E  onehot_16_225
 E  normalized_mass_16_226
 E  normalized_ratio_16_227
 G  stock_lb_228
 L  stock_ub_229
 L  parent_nonstrict_scope_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 E  normalization_287
 G  full_original_Gini_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 E  depot_departure_or_bypass_776
 E  depot_return_or_bypass_777
 E  out_degree_778
 E  in_degree_779
 G  order_active_lb_780
 L  order_active_ub_781
 E  segment_load_conservation_782
 G  segment_prefix_lb_783
 L  segment_prefix_ub_784
 E  out_degree_785
 E  in_degree_786
 G  order_active_lb_787
 L  order_active_ub_788
 E  segment_load_conservation_789
 G  segment_prefix_lb_790
 L  segment_prefix_ub_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  segment_load_conservation_796
 G  segment_prefix_lb_797
 L  segment_prefix_ub_798
 E  out_degree_799
 E  in_degree_800
 G  order_active_lb_801
 L  order_active_ub_802
 E  segment_load_conservation_803
 G  segment_prefix_lb_804
 L  segment_prefix_ub_805
 E  out_degree_806
 E  in_degree_807
 G  order_active_lb_808
 L  order_active_ub_809
 E  segment_load_conservation_810
 G  segment_prefix_lb_811
 L  segment_prefix_ub_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  segment_load_conservation_817
 G  segment_prefix_lb_818
 L  segment_prefix_ub_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  service_visit_def_824
 E  free_load_conservation_825
 E  out_degree_826
 E  in_degree_827
 G  order_active_lb_828
 L  order_active_ub_829
 E  service_visit_def_830
 E  free_load_conservation_831
 E  out_degree_832
 E  in_degree_833
 G  order_active_lb_834
 L  order_active_ub_835
 E  service_visit_def_836
 E  free_load_conservation_837
 E  out_degree_838
 E  in_degree_839
 G  order_active_lb_840
 L  order_active_ub_841
 E  service_visit_def_842
 E  free_load_conservation_843
 E  out_degree_844
 E  in_degree_845
 G  order_active_lb_846
 L  order_active_ub_847
 E  service_visit_def_848
 E  free_load_conservation_849
 E  out_degree_850
 E  in_degree_851
 G  order_active_lb_852
 L  order_active_ub_853
 E  service_visit_def_854
 E  free_load_conservation_855
 E  out_degree_856
 E  in_degree_857
 G  order_active_lb_858
 L  order_active_ub_859
 E  service_visit_def_860
 E  free_load_conservation_861
 E  out_degree_862
 E  in_degree_863
 G  order_active_lb_864
 L  order_active_ub_865
 E  service_visit_def_866
 E  free_load_conservation_867
 G  fixed_segment_relative_order_868
 G  fixed_segment_relative_order_869
 G  fixed_segment_relative_order_870
 G  fixed_segment_relative_order_871
 G  fixed_segment_relative_order_872
 L  original_T_including_depot_unload_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 L  arc_capacity_881
 L  arc_capacity_882
 L  arc_capacity_883
 L  arc_capacity_884
 L  arc_capacity_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 E  depot_departure_or_bypass_1075
 E  depot_return_or_bypass_1076
 E  out_degree_1077
 E  in_degree_1078
 G  order_active_lb_1079
 L  order_active_ub_1080
 E  segment_load_conservation_1081
 G  segment_prefix_lb_1082
 L  segment_prefix_ub_1083
 E  out_degree_1084
 E  in_degree_1085
 G  order_active_lb_1086
 L  order_active_ub_1087
 E  segment_load_conservation_1088
 G  segment_prefix_lb_1089
 L  segment_prefix_ub_1090
 E  out_degree_1091
 E  in_degree_1092
 G  order_active_lb_1093
 L  order_active_ub_1094
 E  service_visit_def_1095
 E  free_load_conservation_1096
 E  out_degree_1097
 E  in_degree_1098
 G  order_active_lb_1099
 L  order_active_ub_1100
 E  service_visit_def_1101
 E  free_load_conservation_1102
 E  out_degree_1103
 E  in_degree_1104
 G  order_active_lb_1105
 L  order_active_ub_1106
 E  service_visit_def_1107
 E  free_load_conservation_1108
 E  out_degree_1109
 E  in_degree_1110
 G  order_active_lb_1111
 L  order_active_ub_1112
 E  service_visit_def_1113
 E  free_load_conservation_1114
 E  out_degree_1115
 E  in_degree_1116
 G  order_active_lb_1117
 L  order_active_ub_1118
 E  service_visit_def_1119
 E  free_load_conservation_1120
 E  out_degree_1121
 E  in_degree_1122
 G  order_active_lb_1123
 L  order_active_ub_1124
 E  service_visit_def_1125
 E  free_load_conservation_1126
 E  out_degree_1127
 E  in_degree_1128
 G  order_active_lb_1129
 L  order_active_ub_1130
 E  service_visit_def_1131
 E  free_load_conservation_1132
 E  out_degree_1133
 E  in_degree_1134
 G  order_active_lb_1135
 L  order_active_ub_1136
 E  service_visit_def_1137
 E  free_load_conservation_1138
 G  fixed_segment_relative_order_1139
 L  original_T_including_depot_unload_1140
COLUMNS
    t         normalized_mass_20_33  -1
    t         normalized_mass_12_68  -1
    t         normalized_mass_18_103  -1
    t         normalized_mass_13_110  -1
    t         normalized_mass_17_147  -1
    t         normalized_mass_14_182  -1
    t         normalized_mass_11_217  -1
    t         normalized_mass_16_226  -1
    t         normalization_287  7.2964285714285708e+00
    t         full_original_Gini_288  -3.5060714285714283e+01
    q         OBJ       1
    q         parent_nonstrict_scope_230  1
    q         full_original_Gini_288  20
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_0  -4.4938209961258267e-02
    x_20_0    product_ub_1  -1.3705335291252085e-01
    x_20_0    onehot_20_32  1
    x_20_0    parent_nonstrict_scope_230  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_0  1
    w_20_0    product_ub_1  1
    w_20_0    normalized_mass_20_33  1
    w_20_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_2  -4.4938209961258267e-02
    x_20_1    product_ub_3  -1.3705335291252085e-01
    x_20_1    onehot_20_32  1
    x_20_1    stock_lb_228  1
    x_20_1    stock_ub_229  1
    x_20_1    parent_nonstrict_scope_230  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_2  1
    w_20_1    product_ub_3  1
    w_20_1    normalized_mass_20_33  1
    w_20_1    normalized_ratio_20_34  -0.125
    w_20_1    full_original_Gini_288  -6.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_4  -4.4938209961258267e-02
    x_20_2    product_ub_5  -1.3705335291252085e-01
    x_20_2    onehot_20_32  1
    x_20_2    stock_lb_228  2
    x_20_2    stock_ub_229  2
    x_20_2    parent_nonstrict_scope_230  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_4  1
    w_20_2    product_ub_5  1
    w_20_2    normalized_mass_20_33  1
    w_20_2    normalized_ratio_20_34  -0.25
    w_20_2    full_original_Gini_288  -6.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_6  -4.4938209961258267e-02
    x_20_3    product_ub_7  -1.3705335291252085e-01
    x_20_3    onehot_20_32  1
    x_20_3    stock_lb_228  3
    x_20_3    stock_ub_229  3
    x_20_3    parent_nonstrict_scope_230  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_6  1
    w_20_3    product_ub_7  1
    w_20_3    normalized_mass_20_33  1
    w_20_3    normalized_ratio_20_34  -0.375
    w_20_3    full_original_Gini_288  -5.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_8  -4.4938209961258267e-02
    x_20_4    product_ub_9  -1.3705335291252085e-01
    x_20_4    onehot_20_32  1
    x_20_4    stock_lb_228  4
    x_20_4    stock_ub_229  4
    x_20_4    parent_nonstrict_scope_230  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_8  1
    w_20_4    product_ub_9  1
    w_20_4    normalized_mass_20_33  1
    w_20_4    normalized_ratio_20_34  -0.5
    w_20_4    full_original_Gini_288  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_10  -4.4938209961258267e-02
    x_20_5    product_ub_11  -1.3705335291252085e-01
    x_20_5    onehot_20_32  1
    x_20_5    stock_lb_228  5
    x_20_5    stock_ub_229  5
    x_20_5    parent_nonstrict_scope_230  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_10  1
    w_20_5    product_ub_11  1
    w_20_5    normalized_mass_20_33  1
    w_20_5    normalized_ratio_20_34  -0.625
    w_20_5    full_original_Gini_288  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_12  -4.4938209961258267e-02
    x_20_6    product_ub_13  -1.3705335291252085e-01
    x_20_6    onehot_20_32  1
    x_20_6    stock_lb_228  6
    x_20_6    stock_ub_229  6
    x_20_6    parent_nonstrict_scope_230  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_12  1
    w_20_6    product_ub_13  1
    w_20_6    normalized_mass_20_33  1
    w_20_6    normalized_ratio_20_34  -0.75
    w_20_6    full_original_Gini_288  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_14  -4.4938209961258267e-02
    x_20_7    product_ub_15  -1.3705335291252085e-01
    x_20_7    onehot_20_32  1
    x_20_7    stock_lb_228  7
    x_20_7    stock_ub_229  7
    x_20_7    parent_nonstrict_scope_230  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_14  1
    w_20_7    product_ub_15  1
    w_20_7    normalized_mass_20_33  1
    w_20_7    normalized_ratio_20_34  -0.875
    w_20_7    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_16  -4.4938209961258267e-02
    x_20_8    product_ub_17  -1.3705335291252085e-01
    x_20_8    onehot_20_32  1
    x_20_8    stock_lb_228  8
    x_20_8    stock_ub_229  8
    x_20_8    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_16  1
    w_20_8    product_ub_17  1
    w_20_8    normalized_mass_20_33  1
    w_20_8    normalized_ratio_20_34  -1
    w_20_8    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_18  -4.4938209961258267e-02
    x_20_9    product_ub_19  -1.3705335291252085e-01
    x_20_9    onehot_20_32  1
    x_20_9    stock_lb_228  9
    x_20_9    stock_ub_229  9
    x_20_9    parent_nonstrict_scope_230  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_18  1
    w_20_9    product_ub_19  1
    w_20_9    normalized_mass_20_33  1
    w_20_9    normalized_ratio_20_34  -1.125
    w_20_9    full_original_Gini_288  -6.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_20  -4.4938209961258267e-02
    x_20_10   product_ub_21  -1.3705335291252085e-01
    x_20_10   onehot_20_32  1
    x_20_10   stock_lb_228  10
    x_20_10   stock_ub_229  10
    x_20_10   parent_nonstrict_scope_230  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_20  1
    w_20_10   product_ub_21  1
    w_20_10   normalized_mass_20_33  1
    w_20_10   normalized_ratio_20_34  -1.25
    w_20_10   full_original_Gini_288  -7.7035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_22  -4.4938209961258267e-02
    x_20_11   product_ub_23  -1.3705335291252085e-01
    x_20_11   onehot_20_32  1
    x_20_11   stock_lb_228  11
    x_20_11   stock_ub_229  11
    x_20_11   parent_nonstrict_scope_230  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_22  1
    w_20_11   product_ub_23  1
    w_20_11   normalized_mass_20_33  1
    w_20_11   normalized_ratio_20_34  -1.375
    w_20_11   full_original_Gini_288  -9.20357142857143
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_24  -4.4938209961258267e-02
    x_20_12   product_ub_25  -1.3705335291252085e-01
    x_20_12   onehot_20_32  1
    x_20_12   stock_lb_228  12
    x_20_12   stock_ub_229  12
    x_20_12   parent_nonstrict_scope_230  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_24  1
    w_20_12   product_ub_25  1
    w_20_12   normalized_mass_20_33  1
    w_20_12   normalized_ratio_20_34  -1.5
    w_20_12   full_original_Gini_288  -1.0703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_26  -4.4938209961258267e-02
    x_20_13   product_ub_27  -1.3705335291252085e-01
    x_20_13   onehot_20_32  1
    x_20_13   stock_lb_228  13
    x_20_13   stock_ub_229  13
    x_20_13   parent_nonstrict_scope_230  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_26  1
    w_20_13   product_ub_27  1
    w_20_13   normalized_mass_20_33  1
    w_20_13   normalized_ratio_20_34  -1.625
    w_20_13   full_original_Gini_288  -1.2203571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_28  -4.4938209961258267e-02
    x_20_14   product_ub_29  -1.3705335291252085e-01
    x_20_14   onehot_20_32  1
    x_20_14   stock_lb_228  14
    x_20_14   stock_ub_229  14
    x_20_14   parent_nonstrict_scope_230  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_28  1
    w_20_14   product_ub_29  1
    w_20_14   normalized_mass_20_33  1
    w_20_14   normalized_ratio_20_34  -1.75
    w_20_14   full_original_Gini_288  -1.3703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_30  -4.4938209961258267e-02
    x_20_15   product_ub_31  -1.3705335291252085e-01
    x_20_15   onehot_20_32  1
    x_20_15   stock_lb_228  15
    x_20_15   stock_ub_229  15
    x_20_15   parent_nonstrict_scope_230  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_30  1
    w_20_15   product_ub_31  1
    w_20_15   normalized_mass_20_33  1
    w_20_15   normalized_ratio_20_34  -1.875
    w_20_15   full_original_Gini_288  -1.5203571428571429e+01
    rho_20    normalized_ratio_20_34  1
    rho_20    block_pair_pos_273  -1
    rho_20    block_pair_neg_274  1
    rho_20    block_pair_pos_275  -1
    rho_20    block_pair_neg_276  1
    rho_20    block_pair_pos_277  -1
    rho_20    block_pair_neg_278  1
    rho_20    block_pair_pos_279  -1
    rho_20    block_pair_neg_280  1
    rho_20    block_pair_pos_281  -1
    rho_20    block_pair_neg_282  1
    rho_20    block_pair_pos_283  -1
    rho_20    block_pair_neg_284  1
    rho_20    block_pair_pos_285  -1
    rho_20    block_pair_neg_286  1
    rho_20    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_35  -4.4938209961258267e-02
    x_12_0    product_ub_36  -1.3705335291252085e-01
    x_12_0    onehot_12_67  1
    x_12_0    parent_nonstrict_scope_230  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_35  1
    w_12_0    product_ub_36  1
    w_12_0    normalized_mass_12_68  1
    w_12_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_37  -4.4938209961258267e-02
    x_12_1    product_ub_38  -1.3705335291252085e-01
    x_12_1    onehot_12_67  1
    x_12_1    stock_lb_228  1
    x_12_1    stock_ub_229  1
    x_12_1    parent_nonstrict_scope_230  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_37  1
    w_12_1    product_ub_38  1
    w_12_1    normalized_mass_12_68  1
    w_12_1    normalized_ratio_12_69  -1.4285714285714285e-01
    w_12_1    full_original_Gini_288  -6.7250000000000014e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_39  -4.4938209961258267e-02
    x_12_2    product_ub_40  -1.3705335291252085e-01
    x_12_2    onehot_12_67  1
    x_12_2    stock_lb_228  2
    x_12_2    stock_ub_229  2
    x_12_2    parent_nonstrict_scope_230  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_39  1
    w_12_2    product_ub_40  1
    w_12_2    normalized_mass_12_68  1
    w_12_2    normalized_ratio_12_69  -2.8571428571428570e-01
    w_12_2    full_original_Gini_288  -6.1535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_41  -4.4938209961258267e-02
    x_12_3    product_ub_42  -1.3705335291252085e-01
    x_12_3    onehot_12_67  1
    x_12_3    stock_lb_228  3
    x_12_3    stock_ub_229  3
    x_12_3    parent_nonstrict_scope_230  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_41  1
    w_12_3    product_ub_42  1
    w_12_3    normalized_mass_12_68  1
    w_12_3    normalized_ratio_12_69  -4.2857142857142855e-01
    w_12_3    full_original_Gini_288  -5.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_43  -4.4938209961258267e-02
    x_12_4    product_ub_44  -1.3705335291252085e-01
    x_12_4    onehot_12_67  1
    x_12_4    stock_lb_228  4
    x_12_4    stock_ub_229  4
    x_12_4    parent_nonstrict_scope_230  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_43  1
    w_12_4    product_ub_44  1
    w_12_4    normalized_mass_12_68  1
    w_12_4    normalized_ratio_12_69  -5.7142857142857140e-01
    w_12_4    full_original_Gini_288  -5.0107142857142852e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_45  -4.4938209961258267e-02
    x_12_5    product_ub_46  -1.3705335291252085e-01
    x_12_5    onehot_12_67  1
    x_12_5    stock_lb_228  5
    x_12_5    stock_ub_229  5
    x_12_5    parent_nonstrict_scope_230  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_45  1
    w_12_5    product_ub_46  1
    w_12_5    normalized_mass_12_68  1
    w_12_5    normalized_ratio_12_69  -7.1428571428571419e-01
    w_12_5    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_47  -4.4938209961258267e-02
    x_12_6    product_ub_48  -1.3705335291252085e-01
    x_12_6    onehot_12_67  1
    x_12_6    stock_lb_228  6
    x_12_6    stock_ub_229  6
    x_12_6    parent_nonstrict_scope_230  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_47  1
    w_12_6    product_ub_48  1
    w_12_6    normalized_mass_12_68  1
    w_12_6    normalized_ratio_12_69  -8.5714285714285710e-01
    w_12_6    full_original_Gini_288  -4.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_49  -4.4938209961258267e-02
    x_12_7    product_ub_50  -1.3705335291252085e-01
    x_12_7    onehot_12_67  1
    x_12_7    stock_lb_228  7
    x_12_7    stock_ub_229  7
    x_12_7    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_49  1
    w_12_7    product_ub_50  1
    w_12_7    normalized_mass_12_68  1
    w_12_7    normalized_ratio_12_69  -1
    w_12_7    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_51  -4.4938209961258267e-02
    x_12_8    product_ub_52  -1.3705335291252085e-01
    x_12_8    onehot_12_67  1
    x_12_8    stock_lb_228  8
    x_12_8    stock_ub_229  8
    x_12_8    parent_nonstrict_scope_230  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_51  1
    w_12_8    product_ub_52  1
    w_12_8    normalized_mass_12_68  1
    w_12_8    normalized_ratio_12_69  -1.1428571428571428e+00
    w_12_8    full_original_Gini_288  -6.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_53  -4.4938209961258267e-02
    x_12_9    product_ub_54  -1.3705335291252085e-01
    x_12_9    onehot_12_67  1
    x_12_9    stock_lb_228  9
    x_12_9    stock_ub_229  9
    x_12_9    parent_nonstrict_scope_230  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_53  1
    w_12_9    product_ub_54  1
    w_12_9    normalized_mass_12_68  1
    w_12_9    normalized_ratio_12_69  -1.2857142857142856e+00
    w_12_9    full_original_Gini_288  -8.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_55  -4.4938209961258267e-02
    x_12_10   product_ub_56  -1.3705335291252085e-01
    x_12_10   onehot_12_67  1
    x_12_10   stock_lb_228  10
    x_12_10   stock_ub_229  10
    x_12_10   parent_nonstrict_scope_230  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_55  1
    w_12_10   product_ub_56  1
    w_12_10   normalized_mass_12_68  1
    w_12_10   normalized_ratio_12_69  -1.4285714285714284e+00
    w_12_10   full_original_Gini_288  -9.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_57  -4.4938209961258267e-02
    x_12_11   product_ub_58  -1.3705335291252085e-01
    x_12_11   onehot_12_67  1
    x_12_11   stock_lb_228  11
    x_12_11   stock_ub_229  11
    x_12_11   parent_nonstrict_scope_230  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_57  1
    w_12_11   product_ub_58  1
    w_12_11   normalized_mass_12_68  1
    w_12_11   normalized_ratio_12_69  -1.5714285714285714e+00
    w_12_11   full_original_Gini_288  -1.1560714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_59  -4.4938209961258267e-02
    x_12_12   product_ub_60  -1.3705335291252085e-01
    x_12_12   onehot_12_67  1
    x_12_12   stock_lb_228  12
    x_12_12   stock_ub_229  12
    x_12_12   parent_nonstrict_scope_230  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_59  1
    w_12_12   product_ub_60  1
    w_12_12   normalized_mass_12_68  1
    w_12_12   normalized_ratio_12_69  -1.7142857142857142e+00
    w_12_12   full_original_Gini_288  -1.3274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_61  -4.4938209961258267e-02
    x_12_13   product_ub_62  -1.3705335291252085e-01
    x_12_13   onehot_12_67  1
    x_12_13   stock_lb_228  13
    x_12_13   stock_ub_229  13
    x_12_13   parent_nonstrict_scope_230  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_61  1
    w_12_13   product_ub_62  1
    w_12_13   normalized_mass_12_68  1
    w_12_13   normalized_ratio_12_69  -1.8571428571428570e+00
    w_12_13   full_original_Gini_288  -1.4989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_63  -4.4938209961258267e-02
    x_12_14   product_ub_64  -1.3705335291252085e-01
    x_12_14   onehot_12_67  1
    x_12_14   stock_lb_228  14
    x_12_14   stock_ub_229  14
    x_12_14   parent_nonstrict_scope_230  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_63  1
    w_12_14   product_ub_64  1
    w_12_14   normalized_mass_12_68  1
    w_12_14   normalized_ratio_12_69  -2
    w_12_14   full_original_Gini_288  -1.6703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_65  -4.4938209961258267e-02
    x_12_15   product_ub_66  -1.3705335291252085e-01
    x_12_15   onehot_12_67  1
    x_12_15   stock_lb_228  15
    x_12_15   stock_ub_229  15
    x_12_15   parent_nonstrict_scope_230  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_65  1
    w_12_15   product_ub_66  1
    w_12_15   normalized_mass_12_68  1
    w_12_15   normalized_ratio_12_69  -2.1428571428571428e+00
    w_12_15   full_original_Gini_288  -1.8417857142857141e+01
    rho_12    normalized_ratio_12_69  1
    rho_12    block_pair_pos_233  -1
    rho_12    block_pair_neg_234  1
    rho_12    block_pair_pos_235  -1
    rho_12    block_pair_neg_236  1
    rho_12    block_pair_pos_237  -1
    rho_12    block_pair_neg_238  1
    rho_12    block_pair_pos_239  -1
    rho_12    block_pair_neg_240  1
    rho_12    block_pair_pos_241  -1
    rho_12    block_pair_neg_242  1
    rho_12    block_pair_pos_243  -1
    rho_12    block_pair_neg_244  1
    rho_12    block_pair_pos_275  1
    rho_12    block_pair_neg_276  -1
    rho_12    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_70  -4.4938209961258267e-02
    x_18_0    product_ub_71  -1.3705335291252085e-01
    x_18_0    onehot_18_102  1
    x_18_0    parent_nonstrict_scope_230  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_70  1
    w_18_0    product_ub_71  1
    w_18_0    normalized_mass_18_103  1
    w_18_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_72  -4.4938209961258267e-02
    x_18_1    product_ub_73  -1.3705335291252085e-01
    x_18_1    onehot_18_102  1
    x_18_1    stock_lb_228  1
    x_18_1    stock_ub_229  1
    x_18_1    parent_nonstrict_scope_230  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_72  1
    w_18_1    product_ub_73  1
    w_18_1    normalized_mass_18_103  1
    w_18_1    normalized_ratio_18_104  -1.4285714285714285e-01
    w_18_1    full_original_Gini_288  -6.7250000000000014e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_74  -4.4938209961258267e-02
    x_18_2    product_ub_75  -1.3705335291252085e-01
    x_18_2    onehot_18_102  1
    x_18_2    stock_lb_228  2
    x_18_2    stock_ub_229  2
    x_18_2    parent_nonstrict_scope_230  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_74  1
    w_18_2    product_ub_75  1
    w_18_2    normalized_mass_18_103  1
    w_18_2    normalized_ratio_18_104  -2.8571428571428570e-01
    w_18_2    full_original_Gini_288  -6.1535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_76  -4.4938209961258267e-02
    x_18_3    product_ub_77  -1.3705335291252085e-01
    x_18_3    onehot_18_102  1
    x_18_3    stock_lb_228  3
    x_18_3    stock_ub_229  3
    x_18_3    parent_nonstrict_scope_230  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_76  1
    w_18_3    product_ub_77  1
    w_18_3    normalized_mass_18_103  1
    w_18_3    normalized_ratio_18_104  -4.2857142857142855e-01
    w_18_3    full_original_Gini_288  -5.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_78  -4.4938209961258267e-02
    x_18_4    product_ub_79  -1.3705335291252085e-01
    x_18_4    onehot_18_102  1
    x_18_4    stock_lb_228  4
    x_18_4    stock_ub_229  4
    x_18_4    parent_nonstrict_scope_230  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_78  1
    w_18_4    product_ub_79  1
    w_18_4    normalized_mass_18_103  1
    w_18_4    normalized_ratio_18_104  -5.7142857142857140e-01
    w_18_4    full_original_Gini_288  -5.0107142857142852e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_80  -4.4938209961258267e-02
    x_18_5    product_ub_81  -1.3705335291252085e-01
    x_18_5    onehot_18_102  1
    x_18_5    stock_lb_228  5
    x_18_5    stock_ub_229  5
    x_18_5    parent_nonstrict_scope_230  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_80  1
    w_18_5    product_ub_81  1
    w_18_5    normalized_mass_18_103  1
    w_18_5    normalized_ratio_18_104  -7.1428571428571419e-01
    w_18_5    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_82  -4.4938209961258267e-02
    x_18_6    product_ub_83  -1.3705335291252085e-01
    x_18_6    onehot_18_102  1
    x_18_6    stock_lb_228  6
    x_18_6    stock_ub_229  6
    x_18_6    parent_nonstrict_scope_230  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_82  1
    w_18_6    product_ub_83  1
    w_18_6    normalized_mass_18_103  1
    w_18_6    normalized_ratio_18_104  -8.5714285714285710e-01
    w_18_6    full_original_Gini_288  -4.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_84  -4.4938209961258267e-02
    x_18_7    product_ub_85  -1.3705335291252085e-01
    x_18_7    onehot_18_102  1
    x_18_7    stock_lb_228  7
    x_18_7    stock_ub_229  7
    x_18_7    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_84  1
    w_18_7    product_ub_85  1
    w_18_7    normalized_mass_18_103  1
    w_18_7    normalized_ratio_18_104  -1
    w_18_7    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_86  -4.4938209961258267e-02
    x_18_8    product_ub_87  -1.3705335291252085e-01
    x_18_8    onehot_18_102  1
    x_18_8    stock_lb_228  8
    x_18_8    stock_ub_229  8
    x_18_8    parent_nonstrict_scope_230  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_86  1
    w_18_8    product_ub_87  1
    w_18_8    normalized_mass_18_103  1
    w_18_8    normalized_ratio_18_104  -1.1428571428571428e+00
    w_18_8    full_original_Gini_288  -6.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_88  -4.4938209961258267e-02
    x_18_9    product_ub_89  -1.3705335291252085e-01
    x_18_9    onehot_18_102  1
    x_18_9    stock_lb_228  9
    x_18_9    stock_ub_229  9
    x_18_9    parent_nonstrict_scope_230  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_88  1
    w_18_9    product_ub_89  1
    w_18_9    normalized_mass_18_103  1
    w_18_9    normalized_ratio_18_104  -1.2857142857142856e+00
    w_18_9    full_original_Gini_288  -8.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_90  -4.4938209961258267e-02
    x_18_10   product_ub_91  -1.3705335291252085e-01
    x_18_10   onehot_18_102  1
    x_18_10   stock_lb_228  10
    x_18_10   stock_ub_229  10
    x_18_10   parent_nonstrict_scope_230  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_90  1
    w_18_10   product_ub_91  1
    w_18_10   normalized_mass_18_103  1
    w_18_10   normalized_ratio_18_104  -1.4285714285714284e+00
    w_18_10   full_original_Gini_288  -9.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_92  -4.4938209961258267e-02
    x_18_11   product_ub_93  -1.3705335291252085e-01
    x_18_11   onehot_18_102  1
    x_18_11   stock_lb_228  11
    x_18_11   stock_ub_229  11
    x_18_11   parent_nonstrict_scope_230  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_92  1
    w_18_11   product_ub_93  1
    w_18_11   normalized_mass_18_103  1
    w_18_11   normalized_ratio_18_104  -1.5714285714285714e+00
    w_18_11   full_original_Gini_288  -1.1560714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_94  -4.4938209961258267e-02
    x_18_12   product_ub_95  -1.3705335291252085e-01
    x_18_12   onehot_18_102  1
    x_18_12   stock_lb_228  12
    x_18_12   stock_ub_229  12
    x_18_12   parent_nonstrict_scope_230  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_94  1
    w_18_12   product_ub_95  1
    w_18_12   normalized_mass_18_103  1
    w_18_12   normalized_ratio_18_104  -1.7142857142857142e+00
    w_18_12   full_original_Gini_288  -1.3274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_96  -4.4938209961258267e-02
    x_18_13   product_ub_97  -1.3705335291252085e-01
    x_18_13   onehot_18_102  1
    x_18_13   stock_lb_228  13
    x_18_13   stock_ub_229  13
    x_18_13   parent_nonstrict_scope_230  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_96  1
    w_18_13   product_ub_97  1
    w_18_13   normalized_mass_18_103  1
    w_18_13   normalized_ratio_18_104  -1.8571428571428570e+00
    w_18_13   full_original_Gini_288  -1.4989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_98  -4.4938209961258267e-02
    x_18_14   product_ub_99  -1.3705335291252085e-01
    x_18_14   onehot_18_102  1
    x_18_14   stock_lb_228  14
    x_18_14   stock_ub_229  14
    x_18_14   parent_nonstrict_scope_230  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_98  1
    w_18_14   product_ub_99  1
    w_18_14   normalized_mass_18_103  1
    w_18_14   normalized_ratio_18_104  -2
    w_18_14   full_original_Gini_288  -1.6703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_100  -4.4938209961258267e-02
    x_18_15   product_ub_101  -1.3705335291252085e-01
    x_18_15   onehot_18_102  1
    x_18_15   stock_lb_228  15
    x_18_15   stock_ub_229  15
    x_18_15   parent_nonstrict_scope_230  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_100  1
    w_18_15   product_ub_101  1
    w_18_15   normalized_mass_18_103  1
    w_18_15   normalized_ratio_18_104  -2.1428571428571428e+00
    w_18_15   full_original_Gini_288  -1.8417857142857141e+01
    rho_18    normalized_ratio_18_104  1
    rho_18    block_pair_pos_243  1
    rho_18    block_pair_neg_244  -1
    rho_18    block_pair_pos_263  -1
    rho_18    block_pair_neg_264  1
    rho_18    block_pair_pos_265  -1
    rho_18    block_pair_neg_266  1
    rho_18    block_pair_pos_267  -1
    rho_18    block_pair_neg_268  1
    rho_18    block_pair_pos_269  -1
    rho_18    block_pair_neg_270  1
    rho_18    block_pair_pos_271  -1
    rho_18    block_pair_neg_272  1
    rho_18    block_pair_pos_285  1
    rho_18    block_pair_neg_286  -1
    rho_18    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       6.3380304899829966e-03
    x_13_0    product_lb_105  -4.4938209961258267e-02
    x_13_0    product_ub_106  -1.3705335291252085e-01
    x_13_0    onehot_13_109  1
    x_13_0    parent_nonstrict_scope_230  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_105  1
    w_13_0    product_ub_106  1
    w_13_0    normalized_mass_13_110  1
    w_13_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       -6.3380304899829966e-03
    x_13_1    product_lb_107  -4.4938209961258267e-02
    x_13_1    product_ub_108  -1.3705335291252085e-01
    x_13_1    onehot_13_109  1
    x_13_1    stock_lb_228  1
    x_13_1    stock_ub_229  1
    x_13_1    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_107  1
    w_13_1    product_ub_108  1
    w_13_1    normalized_mass_13_110  1
    w_13_1    normalized_ratio_13_111  -1
    w_13_1    full_original_Gini_288  -4.9535714285714283e+00
    rho_13    normalized_ratio_13_111  1
    rho_13    block_pair_pos_235  1
    rho_13    block_pair_neg_236  -1
    rho_13    block_pair_pos_245  -1
    rho_13    block_pair_neg_246  1
    rho_13    block_pair_pos_247  -1
    rho_13    block_pair_neg_248  1
    rho_13    block_pair_pos_249  -1
    rho_13    block_pair_neg_250  1
    rho_13    block_pair_pos_251  -1
    rho_13    block_pair_neg_252  1
    rho_13    block_pair_pos_265  1
    rho_13    block_pair_neg_266  -1
    rho_13    block_pair_pos_277  1
    rho_13    block_pair_neg_278  -1
    rho_13    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_112  -4.4938209961258267e-02
    x_17_0    product_ub_113  -1.3705335291252085e-01
    x_17_0    onehot_17_146  1
    x_17_0    parent_nonstrict_scope_230  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_112  1
    w_17_0    product_ub_113  1
    w_17_0    normalized_mass_17_147  1
    w_17_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_114  -4.4938209961258267e-02
    x_17_1    product_ub_115  -1.3705335291252085e-01
    x_17_1    onehot_17_146  1
    x_17_1    stock_lb_228  1
    x_17_1    stock_ub_229  1
    x_17_1    parent_nonstrict_scope_230  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_114  1
    w_17_1    product_ub_115  1
    w_17_1    normalized_mass_17_147  1
    w_17_1    normalized_ratio_17_148  -1.1111111111111110e-01
    w_17_1    full_original_Gini_288  -6.8519841269841262e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_116  -4.4938209961258267e-02
    x_17_2    product_ub_117  -1.3705335291252085e-01
    x_17_2    onehot_17_146  1
    x_17_2    stock_lb_228  2
    x_17_2    stock_ub_229  2
    x_17_2    parent_nonstrict_scope_230  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_116  1
    w_17_2    product_ub_117  1
    w_17_2    normalized_mass_17_147  1
    w_17_2    normalized_ratio_17_148  -2.2222222222222221e-01
    w_17_2    full_original_Gini_288  -6.4075396825396824e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_118  -4.4938209961258267e-02
    x_17_3    product_ub_119  -1.3705335291252085e-01
    x_17_3    onehot_17_146  1
    x_17_3    stock_lb_228  3
    x_17_3    stock_ub_229  3
    x_17_3    parent_nonstrict_scope_230  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_118  1
    w_17_3    product_ub_119  1
    w_17_3    normalized_mass_17_147  1
    w_17_3    normalized_ratio_17_148  -3.3333333333333331e-01
    w_17_3    full_original_Gini_288  -5.9630952380952387e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_120  -4.4938209961258267e-02
    x_17_4    product_ub_121  -1.3705335291252085e-01
    x_17_4    onehot_17_146  1
    x_17_4    stock_lb_228  4
    x_17_4    stock_ub_229  4
    x_17_4    parent_nonstrict_scope_230  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_120  1
    w_17_4    product_ub_121  1
    w_17_4    normalized_mass_17_147  1
    w_17_4    normalized_ratio_17_148  -4.4444444444444442e-01
    w_17_4    full_original_Gini_288  -5.5186507936507940e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_122  -4.4938209961258267e-02
    x_17_5    product_ub_123  -1.3705335291252085e-01
    x_17_5    onehot_17_146  1
    x_17_5    stock_lb_228  5
    x_17_5    stock_ub_229  5
    x_17_5    parent_nonstrict_scope_230  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_122  1
    w_17_5    product_ub_123  1
    w_17_5    normalized_mass_17_147  1
    w_17_5    normalized_ratio_17_148  -5.5555555555555558e-01
    w_17_5    full_original_Gini_288  -5.0742063492063485e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_124  -4.4938209961258267e-02
    x_17_6    product_ub_125  -1.3705335291252085e-01
    x_17_6    onehot_17_146  1
    x_17_6    stock_lb_228  6
    x_17_6    stock_ub_229  6
    x_17_6    parent_nonstrict_scope_230  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_124  1
    w_17_6    product_ub_125  1
    w_17_6    normalized_mass_17_147  1
    w_17_6    normalized_ratio_17_148  -6.6666666666666663e-01
    w_17_6    full_original_Gini_288  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_126  -4.4938209961258267e-02
    x_17_7    product_ub_127  -1.3705335291252085e-01
    x_17_7    onehot_17_146  1
    x_17_7    stock_lb_228  7
    x_17_7    stock_ub_229  7
    x_17_7    parent_nonstrict_scope_230  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_126  1
    w_17_7    product_ub_127  1
    w_17_7    normalized_mass_17_147  1
    w_17_7    normalized_ratio_17_148  -7.7777777777777768e-01
    w_17_7    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_128  -4.4938209961258267e-02
    x_17_8    product_ub_129  -1.3705335291252085e-01
    x_17_8    onehot_17_146  1
    x_17_8    stock_lb_228  8
    x_17_8    stock_ub_229  8
    x_17_8    parent_nonstrict_scope_230  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_128  1
    w_17_8    product_ub_129  1
    w_17_8    normalized_mass_17_147  1
    w_17_8    normalized_ratio_17_148  -8.8888888888888884e-01
    w_17_8    full_original_Gini_288  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_130  -4.4938209961258267e-02
    x_17_9    product_ub_131  -1.3705335291252085e-01
    x_17_9    onehot_17_146  1
    x_17_9    stock_lb_228  9
    x_17_9    stock_ub_229  9
    x_17_9    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_130  1
    w_17_9    product_ub_131  1
    w_17_9    normalized_mass_17_147  1
    w_17_9    normalized_ratio_17_148  -1
    w_17_9    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_132  -4.4938209961258267e-02
    x_17_10   product_ub_133  -1.3705335291252085e-01
    x_17_10   onehot_17_146  1
    x_17_10   stock_lb_228  10
    x_17_10   stock_ub_229  10
    x_17_10   parent_nonstrict_scope_230  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_132  1
    w_17_10   product_ub_133  1
    w_17_10   normalized_mass_17_147  1
    w_17_10   normalized_ratio_17_148  -1.1111111111111112e+00
    w_17_10   full_original_Gini_288  -6.06468253968254
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_134  -4.4938209961258267e-02
    x_17_11   product_ub_135  -1.3705335291252085e-01
    x_17_11   onehot_17_146  1
    x_17_11   stock_lb_228  11
    x_17_11   stock_ub_229  11
    x_17_11   parent_nonstrict_scope_230  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_134  1
    w_17_11   product_ub_135  1
    w_17_11   normalized_mass_17_147  1
    w_17_11   normalized_ratio_17_148  -1.2222222222222221e+00
    w_17_11   full_original_Gini_288  -7.3702380952380953e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_136  -4.4938209961258267e-02
    x_17_12   product_ub_137  -1.3705335291252085e-01
    x_17_12   onehot_17_146  1
    x_17_12   stock_lb_228  12
    x_17_12   stock_ub_229  12
    x_17_12   parent_nonstrict_scope_230  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_136  1
    w_17_12   product_ub_137  1
    w_17_12   normalized_mass_17_147  1
    w_17_12   normalized_ratio_17_148  -1.3333333333333333e+00
    w_17_12   full_original_Gini_288  -8.7035714285714256e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_138  -4.4938209961258267e-02
    x_17_13   product_ub_139  -1.3705335291252085e-01
    x_17_13   onehot_17_146  1
    x_17_13   stock_lb_228  13
    x_17_13   stock_ub_229  13
    x_17_13   parent_nonstrict_scope_230  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_138  1
    w_17_13   product_ub_139  1
    w_17_13   normalized_mass_17_147  1
    w_17_13   normalized_ratio_17_148  -1.4444444444444444e+00
    w_17_13   full_original_Gini_288  -1.0036904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_140  -4.4938209961258267e-02
    x_17_14   product_ub_141  -1.3705335291252085e-01
    x_17_14   onehot_17_146  1
    x_17_14   stock_lb_228  14
    x_17_14   stock_ub_229  14
    x_17_14   parent_nonstrict_scope_230  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_140  1
    w_17_14   product_ub_141  1
    w_17_14   normalized_mass_17_147  1
    w_17_14   normalized_ratio_17_148  -1.5555555555555554e+00
    w_17_14   full_original_Gini_288  -1.1370238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_142  -4.4938209961258267e-02
    x_17_15   product_ub_143  -1.3705335291252085e-01
    x_17_15   onehot_17_146  1
    x_17_15   stock_lb_228  15
    x_17_15   stock_ub_229  15
    x_17_15   parent_nonstrict_scope_230  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_142  1
    w_17_15   product_ub_143  1
    w_17_15   normalized_mass_17_147  1
    w_17_15   normalized_ratio_17_148  -1.6666666666666665e+00
    w_17_15   full_original_Gini_288  -1.2703571428571424e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_144  -4.4938209961258267e-02
    x_17_16   product_ub_145  -1.3705335291252085e-01
    x_17_16   onehot_17_146  1
    x_17_16   stock_lb_228  16
    x_17_16   stock_ub_229  16
    x_17_16   parent_nonstrict_scope_230  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_144  1
    w_17_16   product_ub_145  1
    w_17_16   normalized_mass_17_147  1
    w_17_16   normalized_ratio_17_148  -1.7777777777777777e+00
    w_17_16   full_original_Gini_288  -1.4036904761904765e+01
    rho_17    normalized_ratio_17_148  1
    rho_17    block_pair_pos_241  1
    rho_17    block_pair_neg_242  -1
    rho_17    block_pair_pos_251  1
    rho_17    block_pair_neg_252  -1
    rho_17    block_pair_pos_257  -1
    rho_17    block_pair_neg_258  1
    rho_17    block_pair_pos_259  -1
    rho_17    block_pair_neg_260  1
    rho_17    block_pair_pos_261  -1
    rho_17    block_pair_neg_262  1
    rho_17    block_pair_pos_271  1
    rho_17    block_pair_neg_272  -1
    rho_17    block_pair_pos_283  1
    rho_17    block_pair_neg_284  -1
    rho_17    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       3.2863847044708572e-02
    x_14_0    product_lb_149  -4.4938209961258267e-02
    x_14_0    product_ub_150  -1.3705335291252085e-01
    x_14_0    onehot_14_181  1
    x_14_0    parent_nonstrict_scope_230  7.6682309770986667e-02
    x_14_0    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_149  1
    w_14_0    product_ub_150  1
    w_14_0    normalized_mass_14_182  1
    w_14_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       2.1909231363139048e-02
    x_14_1    product_lb_151  -4.4938209961258267e-02
    x_14_1    product_ub_152  -1.3705335291252085e-01
    x_14_1    onehot_14_181  1
    x_14_1    stock_lb_228  1
    x_14_1    stock_ub_229  1
    x_14_1    parent_nonstrict_scope_230  6.5727694089417144e-02
    x_14_1    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_151  1
    w_14_1    product_ub_152  1
    w_14_1    normalized_mass_14_182  1
    w_14_1    normalized_ratio_14_183  -1.4285714285714285e-01
    w_14_1    full_original_Gini_288  -6.7250000000000014e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       1.0954615681569524e-02
    x_14_2    product_lb_153  -4.4938209961258267e-02
    x_14_2    product_ub_154  -1.3705335291252085e-01
    x_14_2    onehot_14_181  1
    x_14_2    stock_lb_228  2
    x_14_2    stock_ub_229  2
    x_14_2    parent_nonstrict_scope_230  5.4773078407847620e-02
    x_14_2    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_153  1
    w_14_2    product_ub_154  1
    w_14_2    normalized_mass_14_182  1
    w_14_2    normalized_ratio_14_183  -2.8571428571428570e-01
    w_14_2    full_original_Gini_288  -6.1535714285714294e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_3    product_lb_155  -4.4938209961258267e-02
    x_14_3    product_ub_156  -1.3705335291252085e-01
    x_14_3    onehot_14_181  1
    x_14_3    stock_lb_228  3
    x_14_3    stock_ub_229  3
    x_14_3    parent_nonstrict_scope_230  4.3818462726278096e-02
    x_14_3    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_155  1
    w_14_3    product_ub_156  1
    w_14_3    normalized_mass_14_182  1
    w_14_3    normalized_ratio_14_183  -4.2857142857142855e-01
    w_14_3    full_original_Gini_288  -5.5821428571428573e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_4    OBJ       -1.0954615681569524e-02
    x_14_4    product_lb_157  -4.4938209961258267e-02
    x_14_4    product_ub_158  -1.3705335291252085e-01
    x_14_4    onehot_14_181  1
    x_14_4    stock_lb_228  4
    x_14_4    stock_ub_229  4
    x_14_4    parent_nonstrict_scope_230  3.2863847044708572e-02
    x_14_4    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_157  1
    w_14_4    product_ub_158  1
    w_14_4    normalized_mass_14_182  1
    w_14_4    normalized_ratio_14_183  -5.7142857142857140e-01
    w_14_4    full_original_Gini_288  -5.0107142857142852e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -2.1909231363139041e-02
    x_14_5    product_lb_159  -4.4938209961258267e-02
    x_14_5    product_ub_160  -1.3705335291252085e-01
    x_14_5    onehot_14_181  1
    x_14_5    stock_lb_228  5
    x_14_5    stock_ub_229  5
    x_14_5    parent_nonstrict_scope_230  2.1909231363139055e-02
    x_14_5    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_159  1
    w_14_5    product_ub_160  1
    w_14_5    normalized_mass_14_182  1
    w_14_5    normalized_ratio_14_183  -7.1428571428571419e-01
    w_14_5    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -3.2863847044708572e-02
    x_14_6    product_lb_161  -4.4938209961258267e-02
    x_14_6    product_ub_162  -1.3705335291252085e-01
    x_14_6    onehot_14_181  1
    x_14_6    stock_lb_228  6
    x_14_6    stock_ub_229  6
    x_14_6    parent_nonstrict_scope_230  1.0954615681569527e-02
    x_14_6    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_161  1
    w_14_6    product_ub_162  1
    w_14_6    normalized_mass_14_182  1
    w_14_6    normalized_ratio_14_183  -8.5714285714285710e-01
    w_14_6    full_original_Gini_288  -4.9535714285714274e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -4.3818462726278096e-02
    x_14_7    product_lb_163  -4.4938209961258267e-02
    x_14_7    product_ub_164  -1.3705335291252085e-01
    x_14_7    onehot_14_181  1
    x_14_7    stock_lb_228  7
    x_14_7    stock_ub_229  7
    x_14_7    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_163  1
    w_14_7    product_ub_164  1
    w_14_7    normalized_mass_14_182  1
    w_14_7    normalized_ratio_14_183  -1
    w_14_7    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -3.2863847044708579e-02
    x_14_8    product_lb_165  -4.4938209961258267e-02
    x_14_8    product_ub_166  -1.3705335291252085e-01
    x_14_8    onehot_14_181  1
    x_14_8    stock_lb_228  8
    x_14_8    stock_ub_229  8
    x_14_8    parent_nonstrict_scope_230  1.0954615681569519e-02
    x_14_8    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_165  1
    w_14_8    product_ub_166  1
    w_14_8    normalized_mass_14_182  1
    w_14_8    normalized_ratio_14_183  -1.1428571428571428e+00
    w_14_8    full_original_Gini_288  -6.4178571428571409e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -2.1909231363139058e-02
    x_14_9    product_lb_167  -4.4938209961258267e-02
    x_14_9    product_ub_168  -1.3705335291252085e-01
    x_14_9    onehot_14_181  1
    x_14_9    stock_lb_228  9
    x_14_9    stock_ub_229  9
    x_14_9    parent_nonstrict_scope_230  2.1909231363139037e-02
    x_14_9    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_167  1
    w_14_9    product_ub_168  1
    w_14_9    normalized_mass_14_182  1
    w_14_9    normalized_ratio_14_183  -1.2857142857142856e+00
    w_14_9    full_original_Gini_288  -8.1321428571428562e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -1.0954615681569538e-02
    x_14_10   product_lb_169  -4.4938209961258267e-02
    x_14_10   product_ub_170  -1.3705335291252085e-01
    x_14_10   onehot_14_181  1
    x_14_10   stock_lb_228  10
    x_14_10   stock_ub_229  10
    x_14_10   parent_nonstrict_scope_230  3.2863847044708558e-02
    x_14_10   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_169  1
    w_14_10   product_ub_170  1
    w_14_10   normalized_mass_14_182  1
    w_14_10   normalized_ratio_14_183  -1.4285714285714284e+00
    w_14_10   full_original_Gini_288  -9.8464285714285715e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_11   product_lb_171  -4.4938209961258267e-02
    x_14_11   product_ub_172  -1.3705335291252085e-01
    x_14_11   onehot_14_181  1
    x_14_11   stock_lb_228  11
    x_14_11   stock_ub_229  11
    x_14_11   parent_nonstrict_scope_230  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_171  1
    w_14_11   product_ub_172  1
    w_14_11   normalized_mass_14_182  1
    w_14_11   normalized_ratio_14_183  -1.5714285714285714e+00
    w_14_11   full_original_Gini_288  -1.1560714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   OBJ       1.0954615681569517e-02
    x_14_12   product_lb_173  -4.4938209961258267e-02
    x_14_12   product_ub_174  -1.3705335291252085e-01
    x_14_12   onehot_14_181  1
    x_14_12   stock_lb_228  12
    x_14_12   stock_ub_229  12
    x_14_12   parent_nonstrict_scope_230  5.4773078407847613e-02
    x_14_12   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_173  1
    w_14_12   product_ub_174  1
    w_14_12   normalized_mass_14_182  1
    w_14_12   normalized_ratio_14_183  -1.7142857142857142e+00
    w_14_12   full_original_Gini_288  -1.3274999999999997e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       2.1909231363139034e-02
    x_14_13   product_lb_175  -4.4938209961258267e-02
    x_14_13   product_ub_176  -1.3705335291252085e-01
    x_14_13   onehot_14_181  1
    x_14_13   stock_lb_228  13
    x_14_13   stock_ub_229  13
    x_14_13   parent_nonstrict_scope_230  6.5727694089417130e-02
    x_14_13   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_175  1
    w_14_13   product_ub_176  1
    w_14_13   normalized_mass_14_182  1
    w_14_13   normalized_ratio_14_183  -1.8571428571428570e+00
    w_14_13   full_original_Gini_288  -1.4989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       3.2863847044708572e-02
    x_14_14   product_lb_177  -4.4938209961258267e-02
    x_14_14   product_ub_178  -1.3705335291252085e-01
    x_14_14   onehot_14_181  1
    x_14_14   stock_lb_228  14
    x_14_14   stock_ub_229  14
    x_14_14   parent_nonstrict_scope_230  7.6682309770986667e-02
    x_14_14   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_177  1
    w_14_14   product_ub_178  1
    w_14_14   normalized_mass_14_182  1
    w_14_14   normalized_ratio_14_183  -2
    w_14_14   full_original_Gini_288  -1.6703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       4.3818462726278096e-02
    x_14_15   product_lb_179  -4.4938209961258267e-02
    x_14_15   product_ub_180  -1.3705335291252085e-01
    x_14_15   onehot_14_181  1
    x_14_15   stock_lb_228  15
    x_14_15   stock_ub_229  15
    x_14_15   parent_nonstrict_scope_230  8.7636925452556191e-02
    x_14_15   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_179  1
    w_14_15   product_ub_180  1
    w_14_15   normalized_mass_14_182  1
    w_14_15   normalized_ratio_14_183  -2.1428571428571428e+00
    w_14_15   full_original_Gini_288  -1.8417857142857141e+01
    rho_14    normalized_ratio_14_183  1
    rho_14    block_pair_pos_237  1
    rho_14    block_pair_neg_238  -1
    rho_14    block_pair_pos_247  1
    rho_14    block_pair_neg_248  -1
    rho_14    block_pair_pos_253  -1
    rho_14    block_pair_neg_254  1
    rho_14    block_pair_pos_255  -1
    rho_14    block_pair_neg_256  1
    rho_14    block_pair_pos_259  1
    rho_14    block_pair_neg_260  -1
    rho_14    block_pair_pos_267  1
    rho_14    block_pair_neg_268  -1
    rho_14    block_pair_pos_279  1
    rho_14    block_pair_neg_280  -1
    rho_14    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_184  -4.4938209961258267e-02
    x_11_0    product_ub_185  -1.3705335291252085e-01
    x_11_0    onehot_11_216  1
    x_11_0    parent_nonstrict_scope_230  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_184  1
    w_11_0    product_ub_185  1
    w_11_0    normalized_mass_11_217  1
    w_11_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_186  -4.4938209961258267e-02
    x_11_1    product_ub_187  -1.3705335291252085e-01
    x_11_1    onehot_11_216  1
    x_11_1    stock_lb_228  1
    x_11_1    stock_ub_229  1
    x_11_1    parent_nonstrict_scope_230  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_186  1
    w_11_1    product_ub_187  1
    w_11_1    normalized_mass_11_217  1
    w_11_1    normalized_ratio_11_218  -0.125
    w_11_1    full_original_Gini_288  -6.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_188  -4.4938209961258267e-02
    x_11_2    product_ub_189  -1.3705335291252085e-01
    x_11_2    onehot_11_216  1
    x_11_2    stock_lb_228  2
    x_11_2    stock_ub_229  2
    x_11_2    parent_nonstrict_scope_230  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_188  1
    w_11_2    product_ub_189  1
    w_11_2    normalized_mass_11_217  1
    w_11_2    normalized_ratio_11_218  -0.25
    w_11_2    full_original_Gini_288  -6.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_190  -4.4938209961258267e-02
    x_11_3    product_ub_191  -1.3705335291252085e-01
    x_11_3    onehot_11_216  1
    x_11_3    stock_lb_228  3
    x_11_3    stock_ub_229  3
    x_11_3    parent_nonstrict_scope_230  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_190  1
    w_11_3    product_ub_191  1
    w_11_3    normalized_mass_11_217  1
    w_11_3    normalized_ratio_11_218  -0.375
    w_11_3    full_original_Gini_288  -5.7964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_192  -4.4938209961258267e-02
    x_11_4    product_ub_193  -1.3705335291252085e-01
    x_11_4    onehot_11_216  1
    x_11_4    stock_lb_228  4
    x_11_4    stock_ub_229  4
    x_11_4    parent_nonstrict_scope_230  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_192  1
    w_11_4    product_ub_193  1
    w_11_4    normalized_mass_11_217  1
    w_11_4    normalized_ratio_11_218  -0.5
    w_11_4    full_original_Gini_288  -5.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_194  -4.4938209961258267e-02
    x_11_5    product_ub_195  -1.3705335291252085e-01
    x_11_5    onehot_11_216  1
    x_11_5    stock_lb_228  5
    x_11_5    stock_ub_229  5
    x_11_5    parent_nonstrict_scope_230  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_194  1
    w_11_5    product_ub_195  1
    w_11_5    normalized_mass_11_217  1
    w_11_5    normalized_ratio_11_218  -0.625
    w_11_5    full_original_Gini_288  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_196  -4.4938209961258267e-02
    x_11_6    product_ub_197  -1.3705335291252085e-01
    x_11_6    onehot_11_216  1
    x_11_6    stock_lb_228  6
    x_11_6    stock_ub_229  6
    x_11_6    parent_nonstrict_scope_230  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_196  1
    w_11_6    product_ub_197  1
    w_11_6    normalized_mass_11_217  1
    w_11_6    normalized_ratio_11_218  -0.75
    w_11_6    full_original_Gini_288  -4.9535714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_198  -4.4938209961258267e-02
    x_11_7    product_ub_199  -1.3705335291252085e-01
    x_11_7    onehot_11_216  1
    x_11_7    stock_lb_228  7
    x_11_7    stock_ub_229  7
    x_11_7    parent_nonstrict_scope_230  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_198  1
    w_11_7    product_ub_199  1
    w_11_7    normalized_mass_11_217  1
    w_11_7    normalized_ratio_11_218  -0.875
    w_11_7    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_200  -4.4938209961258267e-02
    x_11_8    product_ub_201  -1.3705335291252085e-01
    x_11_8    onehot_11_216  1
    x_11_8    stock_lb_228  8
    x_11_8    stock_ub_229  8
    x_11_8    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_200  1
    w_11_8    product_ub_201  1
    w_11_8    normalized_mass_11_217  1
    w_11_8    normalized_ratio_11_218  -1
    w_11_8    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_202  -4.4938209961258267e-02
    x_11_9    product_ub_203  -1.3705335291252085e-01
    x_11_9    onehot_11_216  1
    x_11_9    stock_lb_228  9
    x_11_9    stock_ub_229  9
    x_11_9    parent_nonstrict_scope_230  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_202  1
    w_11_9    product_ub_203  1
    w_11_9    normalized_mass_11_217  1
    w_11_9    normalized_ratio_11_218  -1.125
    w_11_9    full_original_Gini_288  -6.2035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_204  -4.4938209961258267e-02
    x_11_10   product_ub_205  -1.3705335291252085e-01
    x_11_10   onehot_11_216  1
    x_11_10   stock_lb_228  10
    x_11_10   stock_ub_229  10
    x_11_10   parent_nonstrict_scope_230  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_204  1
    w_11_10   product_ub_205  1
    w_11_10   normalized_mass_11_217  1
    w_11_10   normalized_ratio_11_218  -1.25
    w_11_10   full_original_Gini_288  -7.7035714285714292e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_206  -4.4938209961258267e-02
    x_11_11   product_ub_207  -1.3705335291252085e-01
    x_11_11   onehot_11_216  1
    x_11_11   stock_lb_228  11
    x_11_11   stock_ub_229  11
    x_11_11   parent_nonstrict_scope_230  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_206  1
    w_11_11   product_ub_207  1
    w_11_11   normalized_mass_11_217  1
    w_11_11   normalized_ratio_11_218  -1.375
    w_11_11   full_original_Gini_288  -9.20357142857143
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_208  -4.4938209961258267e-02
    x_11_12   product_ub_209  -1.3705335291252085e-01
    x_11_12   onehot_11_216  1
    x_11_12   stock_lb_228  12
    x_11_12   stock_ub_229  12
    x_11_12   parent_nonstrict_scope_230  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_208  1
    w_11_12   product_ub_209  1
    w_11_12   normalized_mass_11_217  1
    w_11_12   normalized_ratio_11_218  -1.5
    w_11_12   full_original_Gini_288  -1.0703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_210  -4.4938209961258267e-02
    x_11_13   product_ub_211  -1.3705335291252085e-01
    x_11_13   onehot_11_216  1
    x_11_13   stock_lb_228  13
    x_11_13   stock_ub_229  13
    x_11_13   parent_nonstrict_scope_230  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_210  1
    w_11_13   product_ub_211  1
    w_11_13   normalized_mass_11_217  1
    w_11_13   normalized_ratio_11_218  -1.625
    w_11_13   full_original_Gini_288  -1.2203571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_212  -4.4938209961258267e-02
    x_11_14   product_ub_213  -1.3705335291252085e-01
    x_11_14   onehot_11_216  1
    x_11_14   stock_lb_228  14
    x_11_14   stock_ub_229  14
    x_11_14   parent_nonstrict_scope_230  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_212  1
    w_11_14   product_ub_213  1
    w_11_14   normalized_mass_11_217  1
    w_11_14   normalized_ratio_11_218  -1.75
    w_11_14   full_original_Gini_288  -1.3703571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_214  -4.4938209961258267e-02
    x_11_15   product_ub_215  -1.3705335291252085e-01
    x_11_15   onehot_11_216  1
    x_11_15   stock_lb_228  15
    x_11_15   stock_ub_229  15
    x_11_15   parent_nonstrict_scope_230  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_214  1
    w_11_15   product_ub_215  1
    w_11_15   normalized_mass_11_217  1
    w_11_15   normalized_ratio_11_218  -1.875
    w_11_15   full_original_Gini_288  -1.5203571428571429e+01
    rho_11    normalized_ratio_11_218  1
    rho_11    block_pair_pos_231  -1
    rho_11    block_pair_neg_232  1
    rho_11    block_pair_pos_233  1
    rho_11    block_pair_neg_234  -1
    rho_11    block_pair_pos_245  1
    rho_11    block_pair_neg_246  -1
    rho_11    block_pair_pos_253  1
    rho_11    block_pair_neg_254  -1
    rho_11    block_pair_pos_257  1
    rho_11    block_pair_neg_258  -1
    rho_11    block_pair_pos_263  1
    rho_11    block_pair_neg_264  -1
    rho_11    block_pair_pos_273  1
    rho_11    block_pair_neg_274  -1
    rho_11    normalization_287  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       6.3380304899829966e-03
    x_16_0    product_lb_219  -4.4938209961258267e-02
    x_16_0    product_ub_220  -1.3705335291252085e-01
    x_16_0    onehot_16_225  1
    x_16_0    parent_nonstrict_scope_230  1.2676060979965993e-02
    x_16_0    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_219  1
    w_16_0    product_ub_220  1
    w_16_0    normalized_mass_16_226  1
    w_16_0    full_original_Gini_288  -7.2964285714285708e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       -6.3380304899829966e-03
    x_16_1    product_lb_221  -4.4938209961258267e-02
    x_16_1    product_ub_222  -1.3705335291252085e-01
    x_16_1    onehot_16_225  1
    x_16_1    stock_lb_228  1
    x_16_1    stock_ub_229  1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_221  1
    w_16_1    product_ub_222  1
    w_16_1    normalized_mass_16_226  1
    w_16_1    normalized_ratio_16_227  -1
    w_16_1    full_original_Gini_288  -4.9535714285714283e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       6.3380304899829966e-03
    x_16_2    product_lb_223  -4.4938209961258267e-02
    x_16_2    product_ub_224  -1.3705335291252085e-01
    x_16_2    onehot_16_225  1
    x_16_2    stock_lb_228  2
    x_16_2    stock_ub_229  2
    x_16_2    parent_nonstrict_scope_230  1.2676060979965993e-02
    x_16_2    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_223  1
    w_16_2    product_ub_224  1
    w_16_2    normalized_mass_16_226  1
    w_16_2    normalized_ratio_16_227  -2
    w_16_2    full_original_Gini_288  -1.6703571428571429e+01
    rho_16    normalized_ratio_16_227  1
    rho_16    block_pair_pos_231  1
    rho_16    block_pair_neg_232  -1
    rho_16    block_pair_pos_239  1
    rho_16    block_pair_neg_240  -1
    rho_16    block_pair_pos_249  1
    rho_16    block_pair_neg_250  -1
    rho_16    block_pair_pos_255  1
    rho_16    block_pair_neg_256  -1
    rho_16    block_pair_pos_261  1
    rho_16    block_pair_neg_262  -1
    rho_16    block_pair_pos_269  1
    rho_16    block_pair_neg_270  -1
    rho_16    block_pair_pos_281  1
    rho_16    block_pair_neg_282  -1
    rho_16    normalization_287  1
    a_20_12   block_pair_pos_275  1
    a_20_12   block_pair_neg_276  1
    a_20_12   full_original_Gini_288  -1
    a_20_18   block_pair_pos_285  1
    a_20_18   block_pair_neg_286  1
    a_20_18   full_original_Gini_288  -1
    a_20_13   block_pair_pos_277  1
    a_20_13   block_pair_neg_278  1
    a_20_13   full_original_Gini_288  -1
    a_20_17   block_pair_pos_283  1
    a_20_17   block_pair_neg_284  1
    a_20_17   full_original_Gini_288  -1
    a_20_14   block_pair_pos_279  1
    a_20_14   block_pair_neg_280  1
    a_20_14   full_original_Gini_288  -1
    a_20_11   block_pair_pos_273  1
    a_20_11   block_pair_neg_274  1
    a_20_11   full_original_Gini_288  -1
    a_20_16   block_pair_pos_281  1
    a_20_16   block_pair_neg_282  1
    a_20_16   full_original_Gini_288  -1
    a_12_18   block_pair_pos_243  1
    a_12_18   block_pair_neg_244  1
    a_12_18   full_original_Gini_288  -1
    a_12_13   block_pair_pos_235  1
    a_12_13   block_pair_neg_236  1
    a_12_13   full_original_Gini_288  -1
    a_12_17   block_pair_pos_241  1
    a_12_17   block_pair_neg_242  1
    a_12_17   full_original_Gini_288  -1
    a_12_14   block_pair_pos_237  1
    a_12_14   block_pair_neg_238  1
    a_12_14   full_original_Gini_288  -1
    a_12_11   block_pair_pos_233  1
    a_12_11   block_pair_neg_234  1
    a_12_11   full_original_Gini_288  -1
    a_12_16   block_pair_pos_239  1
    a_12_16   block_pair_neg_240  1
    a_12_16   full_original_Gini_288  -1
    a_18_13   block_pair_pos_265  1
    a_18_13   block_pair_neg_266  1
    a_18_13   full_original_Gini_288  -1
    a_18_17   block_pair_pos_271  1
    a_18_17   block_pair_neg_272  1
    a_18_17   full_original_Gini_288  -1
    a_18_14   block_pair_pos_267  1
    a_18_14   block_pair_neg_268  1
    a_18_14   full_original_Gini_288  -1
    a_18_11   block_pair_pos_263  1
    a_18_11   block_pair_neg_264  1
    a_18_11   full_original_Gini_288  -1
    a_18_16   block_pair_pos_269  1
    a_18_16   block_pair_neg_270  1
    a_18_16   full_original_Gini_288  -1
    a_13_17   block_pair_pos_251  1
    a_13_17   block_pair_neg_252  1
    a_13_17   full_original_Gini_288  -1
    a_13_14   block_pair_pos_247  1
    a_13_14   block_pair_neg_248  1
    a_13_14   full_original_Gini_288  -1
    a_13_11   block_pair_pos_245  1
    a_13_11   block_pair_neg_246  1
    a_13_11   full_original_Gini_288  -1
    a_13_16   block_pair_pos_249  1
    a_13_16   block_pair_neg_250  1
    a_13_16   full_original_Gini_288  -1
    a_17_14   block_pair_pos_259  1
    a_17_14   block_pair_neg_260  1
    a_17_14   full_original_Gini_288  -1
    a_17_11   block_pair_pos_257  1
    a_17_11   block_pair_neg_258  1
    a_17_11   full_original_Gini_288  -1
    a_17_16   block_pair_pos_261  1
    a_17_16   block_pair_neg_262  1
    a_17_16   full_original_Gini_288  -1
    a_14_11   block_pair_pos_253  1
    a_14_11   block_pair_neg_254  1
    a_14_11   full_original_Gini_288  -1
    a_14_16   block_pair_pos_255  1
    a_14_16   block_pair_neg_256  1
    a_14_16   full_original_Gini_288  -1
    a_11_16   block_pair_pos_231  1
    a_11_16   block_pair_neg_232  1
    a_11_16   full_original_Gini_288  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_20_0  unique_nonzero_owner_289  1
    service_0_20_0  service_visit_def_824  1
    service_0_20_0  free_load_conservation_825  -12
    service_0_20_0  original_T_including_depot_unload_873  1440
    service_0_20_1  unique_nonzero_owner_290  1
    service_0_20_1  service_visit_def_824  1
    service_0_20_1  free_load_conservation_825  -11
    service_0_20_1  original_T_including_depot_unload_873  1320
    service_0_20_2  unique_nonzero_owner_291  1
    service_0_20_2  service_visit_def_824  1
    service_0_20_2  free_load_conservation_825  -10
    service_0_20_2  original_T_including_depot_unload_873  1200
    service_0_20_3  unique_nonzero_owner_292  1
    service_0_20_3  service_visit_def_824  1
    service_0_20_3  free_load_conservation_825  -9
    service_0_20_3  original_T_including_depot_unload_873  1080
    service_0_20_4  unique_nonzero_owner_293  1
    service_0_20_4  service_visit_def_824  1
    service_0_20_4  free_load_conservation_825  -8
    service_0_20_4  original_T_including_depot_unload_873  960
    service_0_20_5  unique_nonzero_owner_294  1
    service_0_20_5  service_visit_def_824  1
    service_0_20_5  free_load_conservation_825  -7
    service_0_20_5  original_T_including_depot_unload_873  840
    service_0_20_6  unique_nonzero_owner_295  1
    service_0_20_6  service_visit_def_824  1
    service_0_20_6  free_load_conservation_825  -6
    service_0_20_6  original_T_including_depot_unload_873  720
    service_0_20_7  unique_nonzero_owner_296  1
    service_0_20_7  service_visit_def_824  1
    service_0_20_7  free_load_conservation_825  -5
    service_0_20_7  original_T_including_depot_unload_873  600
    service_0_20_8  unique_nonzero_owner_297  1
    service_0_20_8  service_visit_def_824  1
    service_0_20_8  free_load_conservation_825  -4
    service_0_20_8  original_T_including_depot_unload_873  480
    service_0_20_9  unique_nonzero_owner_298  1
    service_0_20_9  service_visit_def_824  1
    service_0_20_9  free_load_conservation_825  -3
    service_0_20_9  original_T_including_depot_unload_873  360
    service_0_20_10  unique_nonzero_owner_299  1
    service_0_20_10  service_visit_def_824  1
    service_0_20_10  free_load_conservation_825  -2
    service_0_20_10  original_T_including_depot_unload_873  240
    service_0_20_11  unique_nonzero_owner_300  1
    service_0_20_11  service_visit_def_824  1
    service_0_20_11  free_load_conservation_825  -1
    service_0_20_11  original_T_including_depot_unload_873  120
    service_0_20_13  unique_nonzero_owner_301  1
    service_0_20_13  service_visit_def_824  1
    service_0_20_13  free_load_conservation_825  1
    service_0_20_14  unique_nonzero_owner_302  1
    service_0_20_14  service_visit_def_824  1
    service_0_20_14  free_load_conservation_825  2
    service_0_20_15  unique_nonzero_owner_303  1
    service_0_20_15  service_visit_def_824  1
    service_0_20_15  free_load_conservation_825  3
    service_1_20_0  unique_nonzero_owner_289  1
    service_1_20_0  service_visit_def_1095  1
    service_1_20_0  free_load_conservation_1096  -12
    service_1_20_0  original_T_including_depot_unload_1140  1440
    service_1_20_1  unique_nonzero_owner_290  1
    service_1_20_1  service_visit_def_1095  1
    service_1_20_1  free_load_conservation_1096  -11
    service_1_20_1  original_T_including_depot_unload_1140  1320
    service_1_20_2  unique_nonzero_owner_291  1
    service_1_20_2  service_visit_def_1095  1
    service_1_20_2  free_load_conservation_1096  -10
    service_1_20_2  original_T_including_depot_unload_1140  1200
    service_1_20_3  unique_nonzero_owner_292  1
    service_1_20_3  service_visit_def_1095  1
    service_1_20_3  free_load_conservation_1096  -9
    service_1_20_3  original_T_including_depot_unload_1140  1080
    service_1_20_4  unique_nonzero_owner_293  1
    service_1_20_4  service_visit_def_1095  1
    service_1_20_4  free_load_conservation_1096  -8
    service_1_20_4  original_T_including_depot_unload_1140  960
    service_1_20_5  unique_nonzero_owner_294  1
    service_1_20_5  service_visit_def_1095  1
    service_1_20_5  free_load_conservation_1096  -7
    service_1_20_5  original_T_including_depot_unload_1140  840
    service_1_20_6  unique_nonzero_owner_295  1
    service_1_20_6  service_visit_def_1095  1
    service_1_20_6  free_load_conservation_1096  -6
    service_1_20_6  original_T_including_depot_unload_1140  720
    service_1_20_7  unique_nonzero_owner_296  1
    service_1_20_7  service_visit_def_1095  1
    service_1_20_7  free_load_conservation_1096  -5
    service_1_20_7  original_T_including_depot_unload_1140  600
    service_1_20_8  unique_nonzero_owner_297  1
    service_1_20_8  service_visit_def_1095  1
    service_1_20_8  free_load_conservation_1096  -4
    service_1_20_8  original_T_including_depot_unload_1140  480
    service_1_20_9  unique_nonzero_owner_298  1
    service_1_20_9  service_visit_def_1095  1
    service_1_20_9  free_load_conservation_1096  -3
    service_1_20_9  original_T_including_depot_unload_1140  360
    service_1_20_10  unique_nonzero_owner_299  1
    service_1_20_10  service_visit_def_1095  1
    service_1_20_10  free_load_conservation_1096  -2
    service_1_20_10  original_T_including_depot_unload_1140  240
    service_1_20_11  unique_nonzero_owner_300  1
    service_1_20_11  service_visit_def_1095  1
    service_1_20_11  free_load_conservation_1096  -1
    service_1_20_11  original_T_including_depot_unload_1140  120
    service_1_20_13  unique_nonzero_owner_301  1
    service_1_20_13  service_visit_def_1095  1
    service_1_20_13  free_load_conservation_1096  1
    service_1_20_14  unique_nonzero_owner_302  1
    service_1_20_14  service_visit_def_1095  1
    service_1_20_14  free_load_conservation_1096  2
    service_1_20_15  unique_nonzero_owner_303  1
    service_1_20_15  service_visit_def_1095  1
    service_1_20_15  free_load_conservation_1096  3
    service_0_12_0  unique_nonzero_owner_304  1
    service_0_12_0  service_visit_def_830  1
    service_0_12_0  free_load_conservation_831  -11
    service_0_12_0  original_T_including_depot_unload_873  1320
    service_0_12_1  unique_nonzero_owner_305  1
    service_0_12_1  service_visit_def_830  1
    service_0_12_1  free_load_conservation_831  -10
    service_0_12_1  original_T_including_depot_unload_873  1200
    service_0_12_2  unique_nonzero_owner_306  1
    service_0_12_2  service_visit_def_830  1
    service_0_12_2  free_load_conservation_831  -9
    service_0_12_2  original_T_including_depot_unload_873  1080
    service_0_12_3  unique_nonzero_owner_307  1
    service_0_12_3  service_visit_def_830  1
    service_0_12_3  free_load_conservation_831  -8
    service_0_12_3  original_T_including_depot_unload_873  960
    service_0_12_4  unique_nonzero_owner_308  1
    service_0_12_4  service_visit_def_830  1
    service_0_12_4  free_load_conservation_831  -7
    service_0_12_4  original_T_including_depot_unload_873  840
    service_0_12_5  unique_nonzero_owner_309  1
    service_0_12_5  service_visit_def_830  1
    service_0_12_5  free_load_conservation_831  -6
    service_0_12_5  original_T_including_depot_unload_873  720
    service_0_12_6  unique_nonzero_owner_310  1
    service_0_12_6  service_visit_def_830  1
    service_0_12_6  free_load_conservation_831  -5
    service_0_12_6  original_T_including_depot_unload_873  600
    service_0_12_7  unique_nonzero_owner_311  1
    service_0_12_7  service_visit_def_830  1
    service_0_12_7  free_load_conservation_831  -4
    service_0_12_7  original_T_including_depot_unload_873  480
    service_0_12_8  unique_nonzero_owner_312  1
    service_0_12_8  service_visit_def_830  1
    service_0_12_8  free_load_conservation_831  -3
    service_0_12_8  original_T_including_depot_unload_873  360
    service_0_12_9  unique_nonzero_owner_313  1
    service_0_12_9  service_visit_def_830  1
    service_0_12_9  free_load_conservation_831  -2
    service_0_12_9  original_T_including_depot_unload_873  240
    service_0_12_10  unique_nonzero_owner_314  1
    service_0_12_10  service_visit_def_830  1
    service_0_12_10  free_load_conservation_831  -1
    service_0_12_10  original_T_including_depot_unload_873  120
    service_0_12_12  unique_nonzero_owner_315  1
    service_0_12_12  service_visit_def_830  1
    service_0_12_12  free_load_conservation_831  1
    service_0_12_13  unique_nonzero_owner_316  1
    service_0_12_13  service_visit_def_830  1
    service_0_12_13  free_load_conservation_831  2
    service_0_12_14  unique_nonzero_owner_317  1
    service_0_12_14  service_visit_def_830  1
    service_0_12_14  free_load_conservation_831  3
    service_0_12_15  unique_nonzero_owner_318  1
    service_0_12_15  service_visit_def_830  1
    service_0_12_15  free_load_conservation_831  4
    service_1_12_0  unique_nonzero_owner_304  1
    service_1_12_0  service_visit_def_1101  1
    service_1_12_0  free_load_conservation_1102  -11
    service_1_12_0  original_T_including_depot_unload_1140  1320
    service_1_12_1  unique_nonzero_owner_305  1
    service_1_12_1  service_visit_def_1101  1
    service_1_12_1  free_load_conservation_1102  -10
    service_1_12_1  original_T_including_depot_unload_1140  1200
    service_1_12_2  unique_nonzero_owner_306  1
    service_1_12_2  service_visit_def_1101  1
    service_1_12_2  free_load_conservation_1102  -9
    service_1_12_2  original_T_including_depot_unload_1140  1080
    service_1_12_3  unique_nonzero_owner_307  1
    service_1_12_3  service_visit_def_1101  1
    service_1_12_3  free_load_conservation_1102  -8
    service_1_12_3  original_T_including_depot_unload_1140  960
    service_1_12_4  unique_nonzero_owner_308  1
    service_1_12_4  service_visit_def_1101  1
    service_1_12_4  free_load_conservation_1102  -7
    service_1_12_4  original_T_including_depot_unload_1140  840
    service_1_12_5  unique_nonzero_owner_309  1
    service_1_12_5  service_visit_def_1101  1
    service_1_12_5  free_load_conservation_1102  -6
    service_1_12_5  original_T_including_depot_unload_1140  720
    service_1_12_6  unique_nonzero_owner_310  1
    service_1_12_6  service_visit_def_1101  1
    service_1_12_6  free_load_conservation_1102  -5
    service_1_12_6  original_T_including_depot_unload_1140  600
    service_1_12_7  unique_nonzero_owner_311  1
    service_1_12_7  service_visit_def_1101  1
    service_1_12_7  free_load_conservation_1102  -4
    service_1_12_7  original_T_including_depot_unload_1140  480
    service_1_12_8  unique_nonzero_owner_312  1
    service_1_12_8  service_visit_def_1101  1
    service_1_12_8  free_load_conservation_1102  -3
    service_1_12_8  original_T_including_depot_unload_1140  360
    service_1_12_9  unique_nonzero_owner_313  1
    service_1_12_9  service_visit_def_1101  1
    service_1_12_9  free_load_conservation_1102  -2
    service_1_12_9  original_T_including_depot_unload_1140  240
    service_1_12_10  unique_nonzero_owner_314  1
    service_1_12_10  service_visit_def_1101  1
    service_1_12_10  free_load_conservation_1102  -1
    service_1_12_10  original_T_including_depot_unload_1140  120
    service_1_12_12  unique_nonzero_owner_315  1
    service_1_12_12  service_visit_def_1101  1
    service_1_12_12  free_load_conservation_1102  1
    service_1_12_13  unique_nonzero_owner_316  1
    service_1_12_13  service_visit_def_1101  1
    service_1_12_13  free_load_conservation_1102  2
    service_1_12_14  unique_nonzero_owner_317  1
    service_1_12_14  service_visit_def_1101  1
    service_1_12_14  free_load_conservation_1102  3
    service_1_12_15  unique_nonzero_owner_318  1
    service_1_12_15  service_visit_def_1101  1
    service_1_12_15  free_load_conservation_1102  4
    service_0_18_1  unique_nonzero_owner_319  1
    service_0_18_1  service_visit_def_836  1
    service_0_18_1  free_load_conservation_837  1
    service_0_18_2  unique_nonzero_owner_320  1
    service_0_18_2  service_visit_def_836  1
    service_0_18_2  free_load_conservation_837  2
    service_0_18_3  unique_nonzero_owner_321  1
    service_0_18_3  service_visit_def_836  1
    service_0_18_3  free_load_conservation_837  3
    service_0_18_4  unique_nonzero_owner_322  1
    service_0_18_4  service_visit_def_836  1
    service_0_18_4  free_load_conservation_837  4
    service_0_18_5  unique_nonzero_owner_323  1
    service_0_18_5  service_visit_def_836  1
    service_0_18_5  free_load_conservation_837  5
    service_0_18_6  unique_nonzero_owner_324  1
    service_0_18_6  service_visit_def_836  1
    service_0_18_6  free_load_conservation_837  6
    service_0_18_7  unique_nonzero_owner_325  1
    service_0_18_7  service_visit_def_836  1
    service_0_18_7  free_load_conservation_837  7
    service_0_18_8  unique_nonzero_owner_326  1
    service_0_18_8  service_visit_def_836  1
    service_0_18_8  free_load_conservation_837  8
    service_0_18_9  unique_nonzero_owner_327  1
    service_0_18_9  service_visit_def_836  1
    service_0_18_9  free_load_conservation_837  9
    service_0_18_10  unique_nonzero_owner_328  1
    service_0_18_10  service_visit_def_836  1
    service_0_18_10  free_load_conservation_837  10
    service_0_18_11  unique_nonzero_owner_329  1
    service_0_18_11  service_visit_def_836  1
    service_0_18_11  free_load_conservation_837  11
    service_0_18_12  unique_nonzero_owner_330  1
    service_0_18_12  service_visit_def_836  1
    service_0_18_12  free_load_conservation_837  12
    service_0_18_13  unique_nonzero_owner_331  1
    service_0_18_13  service_visit_def_836  1
    service_0_18_13  free_load_conservation_837  13
    service_0_18_14  unique_nonzero_owner_332  1
    service_0_18_14  service_visit_def_836  1
    service_0_18_14  free_load_conservation_837  14
    service_0_18_15  unique_nonzero_owner_333  1
    service_0_18_15  service_visit_def_836  1
    service_0_18_15  free_load_conservation_837  15
    service_1_18_1  unique_nonzero_owner_319  1
    service_1_18_1  service_visit_def_1107  1
    service_1_18_1  free_load_conservation_1108  1
    service_1_18_2  unique_nonzero_owner_320  1
    service_1_18_2  service_visit_def_1107  1
    service_1_18_2  free_load_conservation_1108  2
    service_1_18_3  unique_nonzero_owner_321  1
    service_1_18_3  service_visit_def_1107  1
    service_1_18_3  free_load_conservation_1108  3
    service_1_18_4  unique_nonzero_owner_322  1
    service_1_18_4  service_visit_def_1107  1
    service_1_18_4  free_load_conservation_1108  4
    service_1_18_5  unique_nonzero_owner_323  1
    service_1_18_5  service_visit_def_1107  1
    service_1_18_5  free_load_conservation_1108  5
    service_1_18_6  unique_nonzero_owner_324  1
    service_1_18_6  service_visit_def_1107  1
    service_1_18_6  free_load_conservation_1108  6
    service_1_18_7  unique_nonzero_owner_325  1
    service_1_18_7  service_visit_def_1107  1
    service_1_18_7  free_load_conservation_1108  7
    service_1_18_8  unique_nonzero_owner_326  1
    service_1_18_8  service_visit_def_1107  1
    service_1_18_8  free_load_conservation_1108  8
    service_1_18_9  unique_nonzero_owner_327  1
    service_1_18_9  service_visit_def_1107  1
    service_1_18_9  free_load_conservation_1108  9
    service_1_18_10  unique_nonzero_owner_328  1
    service_1_18_10  service_visit_def_1107  1
    service_1_18_10  free_load_conservation_1108  10
    service_1_18_11  unique_nonzero_owner_329  1
    service_1_18_11  service_visit_def_1107  1
    service_1_18_11  free_load_conservation_1108  11
    service_1_18_12  unique_nonzero_owner_330  1
    service_1_18_12  service_visit_def_1107  1
    service_1_18_12  free_load_conservation_1108  12
    service_1_18_13  unique_nonzero_owner_331  1
    service_1_18_13  service_visit_def_1107  1
    service_1_18_13  free_load_conservation_1108  13
    service_1_18_14  unique_nonzero_owner_332  1
    service_1_18_14  service_visit_def_1107  1
    service_1_18_14  free_load_conservation_1108  14
    service_1_18_15  unique_nonzero_owner_333  1
    service_1_18_15  service_visit_def_1107  1
    service_1_18_15  free_load_conservation_1108  15
    service_0_13_1  unique_nonzero_owner_334  1
    service_0_13_1  service_visit_def_842  1
    service_0_13_1  free_load_conservation_843  1
    service_1_13_1  unique_nonzero_owner_334  1
    service_1_13_1  service_visit_def_1113  1
    service_1_13_1  free_load_conservation_1114  1
    service_0_17_0  unique_nonzero_owner_335  1
    service_0_17_0  service_visit_def_848  1
    service_0_17_0  free_load_conservation_849  -3
    service_0_17_0  original_T_including_depot_unload_873  360
    service_0_17_1  unique_nonzero_owner_336  1
    service_0_17_1  service_visit_def_848  1
    service_0_17_1  free_load_conservation_849  -2
    service_0_17_1  original_T_including_depot_unload_873  240
    service_0_17_2  unique_nonzero_owner_337  1
    service_0_17_2  service_visit_def_848  1
    service_0_17_2  free_load_conservation_849  -1
    service_0_17_2  original_T_including_depot_unload_873  120
    service_0_17_4  unique_nonzero_owner_338  1
    service_0_17_4  service_visit_def_848  1
    service_0_17_4  free_load_conservation_849  1
    service_0_17_5  unique_nonzero_owner_339  1
    service_0_17_5  service_visit_def_848  1
    service_0_17_5  free_load_conservation_849  2
    service_0_17_6  unique_nonzero_owner_340  1
    service_0_17_6  service_visit_def_848  1
    service_0_17_6  free_load_conservation_849  3
    service_0_17_7  unique_nonzero_owner_341  1
    service_0_17_7  service_visit_def_848  1
    service_0_17_7  free_load_conservation_849  4
    service_0_17_8  unique_nonzero_owner_342  1
    service_0_17_8  service_visit_def_848  1
    service_0_17_8  free_load_conservation_849  5
    service_0_17_9  unique_nonzero_owner_343  1
    service_0_17_9  service_visit_def_848  1
    service_0_17_9  free_load_conservation_849  6
    service_0_17_10  unique_nonzero_owner_344  1
    service_0_17_10  service_visit_def_848  1
    service_0_17_10  free_load_conservation_849  7
    service_0_17_11  unique_nonzero_owner_345  1
    service_0_17_11  service_visit_def_848  1
    service_0_17_11  free_load_conservation_849  8
    service_0_17_12  unique_nonzero_owner_346  1
    service_0_17_12  service_visit_def_848  1
    service_0_17_12  free_load_conservation_849  9
    service_0_17_13  unique_nonzero_owner_347  1
    service_0_17_13  service_visit_def_848  1
    service_0_17_13  free_load_conservation_849  10
    service_0_17_14  unique_nonzero_owner_348  1
    service_0_17_14  service_visit_def_848  1
    service_0_17_14  free_load_conservation_849  11
    service_0_17_15  unique_nonzero_owner_349  1
    service_0_17_15  service_visit_def_848  1
    service_0_17_15  free_load_conservation_849  12
    service_0_17_16  unique_nonzero_owner_350  1
    service_0_17_16  service_visit_def_848  1
    service_0_17_16  free_load_conservation_849  13
    service_1_17_0  unique_nonzero_owner_335  1
    service_1_17_0  service_visit_def_1119  1
    service_1_17_0  free_load_conservation_1120  -3
    service_1_17_0  original_T_including_depot_unload_1140  360
    service_1_17_1  unique_nonzero_owner_336  1
    service_1_17_1  service_visit_def_1119  1
    service_1_17_1  free_load_conservation_1120  -2
    service_1_17_1  original_T_including_depot_unload_1140  240
    service_1_17_2  unique_nonzero_owner_337  1
    service_1_17_2  service_visit_def_1119  1
    service_1_17_2  free_load_conservation_1120  -1
    service_1_17_2  original_T_including_depot_unload_1140  120
    service_1_17_4  unique_nonzero_owner_338  1
    service_1_17_4  service_visit_def_1119  1
    service_1_17_4  free_load_conservation_1120  1
    service_1_17_5  unique_nonzero_owner_339  1
    service_1_17_5  service_visit_def_1119  1
    service_1_17_5  free_load_conservation_1120  2
    service_1_17_6  unique_nonzero_owner_340  1
    service_1_17_6  service_visit_def_1119  1
    service_1_17_6  free_load_conservation_1120  3
    service_1_17_7  unique_nonzero_owner_341  1
    service_1_17_7  service_visit_def_1119  1
    service_1_17_7  free_load_conservation_1120  4
    service_1_17_8  unique_nonzero_owner_342  1
    service_1_17_8  service_visit_def_1119  1
    service_1_17_8  free_load_conservation_1120  5
    service_1_17_9  unique_nonzero_owner_343  1
    service_1_17_9  service_visit_def_1119  1
    service_1_17_9  free_load_conservation_1120  6
    service_1_17_10  unique_nonzero_owner_344  1
    service_1_17_10  service_visit_def_1119  1
    service_1_17_10  free_load_conservation_1120  7
    service_1_17_11  unique_nonzero_owner_345  1
    service_1_17_11  service_visit_def_1119  1
    service_1_17_11  free_load_conservation_1120  8
    service_1_17_12  unique_nonzero_owner_346  1
    service_1_17_12  service_visit_def_1119  1
    service_1_17_12  free_load_conservation_1120  9
    service_1_17_13  unique_nonzero_owner_347  1
    service_1_17_13  service_visit_def_1119  1
    service_1_17_13  free_load_conservation_1120  10
    service_1_17_14  unique_nonzero_owner_348  1
    service_1_17_14  service_visit_def_1119  1
    service_1_17_14  free_load_conservation_1120  11
    service_1_17_15  unique_nonzero_owner_349  1
    service_1_17_15  service_visit_def_1119  1
    service_1_17_15  free_load_conservation_1120  12
    service_1_17_16  unique_nonzero_owner_350  1
    service_1_17_16  service_visit_def_1119  1
    service_1_17_16  free_load_conservation_1120  13
    service_0_14_0  unique_nonzero_owner_351  1
    service_0_14_0  service_visit_def_854  1
    service_0_14_0  free_load_conservation_855  -11
    service_0_14_0  original_T_including_depot_unload_873  1320
    service_0_14_1  unique_nonzero_owner_352  1
    service_0_14_1  service_visit_def_854  1
    service_0_14_1  free_load_conservation_855  -10
    service_0_14_1  original_T_including_depot_unload_873  1200
    service_0_14_2  unique_nonzero_owner_353  1
    service_0_14_2  service_visit_def_854  1
    service_0_14_2  free_load_conservation_855  -9
    service_0_14_2  original_T_including_depot_unload_873  1080
    service_0_14_3  unique_nonzero_owner_354  1
    service_0_14_3  service_visit_def_854  1
    service_0_14_3  free_load_conservation_855  -8
    service_0_14_3  original_T_including_depot_unload_873  960
    service_0_14_4  unique_nonzero_owner_355  1
    service_0_14_4  service_visit_def_854  1
    service_0_14_4  free_load_conservation_855  -7
    service_0_14_4  original_T_including_depot_unload_873  840
    service_0_14_5  unique_nonzero_owner_356  1
    service_0_14_5  service_visit_def_854  1
    service_0_14_5  free_load_conservation_855  -6
    service_0_14_5  original_T_including_depot_unload_873  720
    service_0_14_6  unique_nonzero_owner_357  1
    service_0_14_6  service_visit_def_854  1
    service_0_14_6  free_load_conservation_855  -5
    service_0_14_6  original_T_including_depot_unload_873  600
    service_0_14_7  unique_nonzero_owner_358  1
    service_0_14_7  service_visit_def_854  1
    service_0_14_7  free_load_conservation_855  -4
    service_0_14_7  original_T_including_depot_unload_873  480
    service_0_14_8  unique_nonzero_owner_359  1
    service_0_14_8  service_visit_def_854  1
    service_0_14_8  free_load_conservation_855  -3
    service_0_14_8  original_T_including_depot_unload_873  360
    service_0_14_9  unique_nonzero_owner_360  1
    service_0_14_9  service_visit_def_854  1
    service_0_14_9  free_load_conservation_855  -2
    service_0_14_9  original_T_including_depot_unload_873  240
    service_0_14_10  unique_nonzero_owner_361  1
    service_0_14_10  service_visit_def_854  1
    service_0_14_10  free_load_conservation_855  -1
    service_0_14_10  original_T_including_depot_unload_873  120
    service_0_14_12  unique_nonzero_owner_362  1
    service_0_14_12  service_visit_def_854  1
    service_0_14_12  free_load_conservation_855  1
    service_0_14_13  unique_nonzero_owner_363  1
    service_0_14_13  service_visit_def_854  1
    service_0_14_13  free_load_conservation_855  2
    service_0_14_14  unique_nonzero_owner_364  1
    service_0_14_14  service_visit_def_854  1
    service_0_14_14  free_load_conservation_855  3
    service_0_14_15  unique_nonzero_owner_365  1
    service_0_14_15  service_visit_def_854  1
    service_0_14_15  free_load_conservation_855  4
    service_1_14_0  unique_nonzero_owner_351  1
    service_1_14_0  service_visit_def_1125  1
    service_1_14_0  free_load_conservation_1126  -11
    service_1_14_0  original_T_including_depot_unload_1140  1320
    service_1_14_1  unique_nonzero_owner_352  1
    service_1_14_1  service_visit_def_1125  1
    service_1_14_1  free_load_conservation_1126  -10
    service_1_14_1  original_T_including_depot_unload_1140  1200
    service_1_14_2  unique_nonzero_owner_353  1
    service_1_14_2  service_visit_def_1125  1
    service_1_14_2  free_load_conservation_1126  -9
    service_1_14_2  original_T_including_depot_unload_1140  1080
    service_1_14_3  unique_nonzero_owner_354  1
    service_1_14_3  service_visit_def_1125  1
    service_1_14_3  free_load_conservation_1126  -8
    service_1_14_3  original_T_including_depot_unload_1140  960
    service_1_14_4  unique_nonzero_owner_355  1
    service_1_14_4  service_visit_def_1125  1
    service_1_14_4  free_load_conservation_1126  -7
    service_1_14_4  original_T_including_depot_unload_1140  840
    service_1_14_5  unique_nonzero_owner_356  1
    service_1_14_5  service_visit_def_1125  1
    service_1_14_5  free_load_conservation_1126  -6
    service_1_14_5  original_T_including_depot_unload_1140  720
    service_1_14_6  unique_nonzero_owner_357  1
    service_1_14_6  service_visit_def_1125  1
    service_1_14_6  free_load_conservation_1126  -5
    service_1_14_6  original_T_including_depot_unload_1140  600
    service_1_14_7  unique_nonzero_owner_358  1
    service_1_14_7  service_visit_def_1125  1
    service_1_14_7  free_load_conservation_1126  -4
    service_1_14_7  original_T_including_depot_unload_1140  480
    service_1_14_8  unique_nonzero_owner_359  1
    service_1_14_8  service_visit_def_1125  1
    service_1_14_8  free_load_conservation_1126  -3
    service_1_14_8  original_T_including_depot_unload_1140  360
    service_1_14_9  unique_nonzero_owner_360  1
    service_1_14_9  service_visit_def_1125  1
    service_1_14_9  free_load_conservation_1126  -2
    service_1_14_9  original_T_including_depot_unload_1140  240
    service_1_14_10  unique_nonzero_owner_361  1
    service_1_14_10  service_visit_def_1125  1
    service_1_14_10  free_load_conservation_1126  -1
    service_1_14_10  original_T_including_depot_unload_1140  120
    service_1_14_12  unique_nonzero_owner_362  1
    service_1_14_12  service_visit_def_1125  1
    service_1_14_12  free_load_conservation_1126  1
    service_1_14_13  unique_nonzero_owner_363  1
    service_1_14_13  service_visit_def_1125  1
    service_1_14_13  free_load_conservation_1126  2
    service_1_14_14  unique_nonzero_owner_364  1
    service_1_14_14  service_visit_def_1125  1
    service_1_14_14  free_load_conservation_1126  3
    service_1_14_15  unique_nonzero_owner_365  1
    service_1_14_15  service_visit_def_1125  1
    service_1_14_15  free_load_conservation_1126  4
    service_0_11_0  unique_nonzero_owner_366  1
    service_0_11_0  service_visit_def_860  1
    service_0_11_0  free_load_conservation_861  -1
    service_0_11_0  original_T_including_depot_unload_873  120
    service_0_11_2  unique_nonzero_owner_367  1
    service_0_11_2  service_visit_def_860  1
    service_0_11_2  free_load_conservation_861  1
    service_0_11_3  unique_nonzero_owner_368  1
    service_0_11_3  service_visit_def_860  1
    service_0_11_3  free_load_conservation_861  2
    service_0_11_4  unique_nonzero_owner_369  1
    service_0_11_4  service_visit_def_860  1
    service_0_11_4  free_load_conservation_861  3
    service_0_11_5  unique_nonzero_owner_370  1
    service_0_11_5  service_visit_def_860  1
    service_0_11_5  free_load_conservation_861  4
    service_0_11_6  unique_nonzero_owner_371  1
    service_0_11_6  service_visit_def_860  1
    service_0_11_6  free_load_conservation_861  5
    service_0_11_7  unique_nonzero_owner_372  1
    service_0_11_7  service_visit_def_860  1
    service_0_11_7  free_load_conservation_861  6
    service_0_11_8  unique_nonzero_owner_373  1
    service_0_11_8  service_visit_def_860  1
    service_0_11_8  free_load_conservation_861  7
    service_0_11_9  unique_nonzero_owner_374  1
    service_0_11_9  service_visit_def_860  1
    service_0_11_9  free_load_conservation_861  8
    service_0_11_10  unique_nonzero_owner_375  1
    service_0_11_10  service_visit_def_860  1
    service_0_11_10  free_load_conservation_861  9
    service_0_11_11  unique_nonzero_owner_376  1
    service_0_11_11  service_visit_def_860  1
    service_0_11_11  free_load_conservation_861  10
    service_0_11_12  unique_nonzero_owner_377  1
    service_0_11_12  service_visit_def_860  1
    service_0_11_12  free_load_conservation_861  11
    service_0_11_13  unique_nonzero_owner_378  1
    service_0_11_13  service_visit_def_860  1
    service_0_11_13  free_load_conservation_861  12
    service_0_11_14  unique_nonzero_owner_379  1
    service_0_11_14  service_visit_def_860  1
    service_0_11_14  free_load_conservation_861  13
    service_0_11_15  unique_nonzero_owner_380  1
    service_0_11_15  service_visit_def_860  1
    service_0_11_15  free_load_conservation_861  14
    service_1_11_0  unique_nonzero_owner_366  1
    service_1_11_0  service_visit_def_1131  1
    service_1_11_0  free_load_conservation_1132  -1
    service_1_11_0  original_T_including_depot_unload_1140  120
    service_1_11_2  unique_nonzero_owner_367  1
    service_1_11_2  service_visit_def_1131  1
    service_1_11_2  free_load_conservation_1132  1
    service_1_11_3  unique_nonzero_owner_368  1
    service_1_11_3  service_visit_def_1131  1
    service_1_11_3  free_load_conservation_1132  2
    service_1_11_4  unique_nonzero_owner_369  1
    service_1_11_4  service_visit_def_1131  1
    service_1_11_4  free_load_conservation_1132  3
    service_1_11_5  unique_nonzero_owner_370  1
    service_1_11_5  service_visit_def_1131  1
    service_1_11_5  free_load_conservation_1132  4
    service_1_11_6  unique_nonzero_owner_371  1
    service_1_11_6  service_visit_def_1131  1
    service_1_11_6  free_load_conservation_1132  5
    service_1_11_7  unique_nonzero_owner_372  1
    service_1_11_7  service_visit_def_1131  1
    service_1_11_7  free_load_conservation_1132  6
    service_1_11_8  unique_nonzero_owner_373  1
    service_1_11_8  service_visit_def_1131  1
    service_1_11_8  free_load_conservation_1132  7
    service_1_11_9  unique_nonzero_owner_374  1
    service_1_11_9  service_visit_def_1131  1
    service_1_11_9  free_load_conservation_1132  8
    service_1_11_10  unique_nonzero_owner_375  1
    service_1_11_10  service_visit_def_1131  1
    service_1_11_10  free_load_conservation_1132  9
    service_1_11_11  unique_nonzero_owner_376  1
    service_1_11_11  service_visit_def_1131  1
    service_1_11_11  free_load_conservation_1132  10
    service_1_11_12  unique_nonzero_owner_377  1
    service_1_11_12  service_visit_def_1131  1
    service_1_11_12  free_load_conservation_1132  11
    service_1_11_13  unique_nonzero_owner_378  1
    service_1_11_13  service_visit_def_1131  1
    service_1_11_13  free_load_conservation_1132  12
    service_1_11_14  unique_nonzero_owner_379  1
    service_1_11_14  service_visit_def_1131  1
    service_1_11_14  free_load_conservation_1132  13
    service_1_11_15  unique_nonzero_owner_380  1
    service_1_11_15  service_visit_def_1131  1
    service_1_11_15  free_load_conservation_1132  14
    service_0_16_0  unique_nonzero_owner_381  1
    service_0_16_0  service_visit_def_866  1
    service_0_16_0  free_load_conservation_867  -1
    service_0_16_0  original_T_including_depot_unload_873  120
    service_0_16_2  unique_nonzero_owner_382  1
    service_0_16_2  service_visit_def_866  1
    service_0_16_2  free_load_conservation_867  1
    service_1_16_0  unique_nonzero_owner_381  1
    service_1_16_0  service_visit_def_1137  1
    service_1_16_0  free_load_conservation_1138  -1
    service_1_16_0  original_T_including_depot_unload_1140  120
    service_1_16_2  unique_nonzero_owner_382  1
    service_1_16_2  service_visit_def_1137  1
    service_1_16_2  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_778  -1
    visit_0_1  in_degree_779  -1
    visit_0_1  order_active_lb_780  -1
    visit_0_1  order_active_ub_781  -14
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_408  -1
    order_0_1  connected_order_arc_410  -1
    order_0_1  connected_order_arc_412  -1
    order_0_1  connected_order_arc_414  -1
    order_0_1  connected_order_arc_416  -1
    order_0_1  connected_order_arc_418  -1
    order_0_1  connected_order_arc_420  -1
    order_0_1  connected_order_arc_422  -1
    order_0_1  connected_order_arc_424  -1
    order_0_1  connected_order_arc_427  1
    order_0_1  connected_order_arc_454  1
    order_0_1  connected_order_arc_481  1
    order_0_1  connected_order_arc_508  1
    order_0_1  connected_order_arc_535  1
    order_0_1  connected_order_arc_562  1
    order_0_1  connected_order_arc_589  1
    order_0_1  connected_order_arc_616  1
    order_0_1  connected_order_arc_643  1
    order_0_1  connected_order_arc_670  1
    order_0_1  connected_order_arc_697  1
    order_0_1  connected_order_arc_724  1
    order_0_1  connected_order_arc_751  1
    order_0_1  order_active_lb_780  1
    order_0_1  order_active_ub_781  1
    order_0_1  fixed_segment_relative_order_868  -1
    visit_0_2  out_degree_785  -1
    visit_0_2  in_degree_786  -1
    visit_0_2  order_active_lb_787  -1
    visit_0_2  order_active_ub_788  -14
    order_0_2  connected_order_arc_400  1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_433  -1
    order_0_2  connected_order_arc_435  -1
    order_0_2  connected_order_arc_437  -1
    order_0_2  connected_order_arc_439  -1
    order_0_2  connected_order_arc_441  -1
    order_0_2  connected_order_arc_443  -1
    order_0_2  connected_order_arc_445  -1
    order_0_2  connected_order_arc_447  -1
    order_0_2  connected_order_arc_449  -1
    order_0_2  connected_order_arc_451  -1
    order_0_2  connected_order_arc_456  1
    order_0_2  connected_order_arc_483  1
    order_0_2  connected_order_arc_510  1
    order_0_2  connected_order_arc_537  1
    order_0_2  connected_order_arc_564  1
    order_0_2  connected_order_arc_591  1
    order_0_2  connected_order_arc_618  1
    order_0_2  connected_order_arc_645  1
    order_0_2  connected_order_arc_672  1
    order_0_2  connected_order_arc_699  1
    order_0_2  connected_order_arc_726  1
    order_0_2  connected_order_arc_753  1
    order_0_2  order_active_lb_787  1
    order_0_2  order_active_ub_788  1
    order_0_2  fixed_segment_relative_order_868  1
    order_0_2  fixed_segment_relative_order_869  -1
    visit_0_3  out_degree_792  -1
    visit_0_3  in_degree_793  -1
    visit_0_3  order_active_lb_794  -1
    visit_0_3  order_active_ub_795  -14
    order_0_3  connected_order_arc_402  1
    order_0_3  connected_order_arc_429  1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_462  -1
    order_0_3  connected_order_arc_464  -1
    order_0_3  connected_order_arc_466  -1
    order_0_3  connected_order_arc_468  -1
    order_0_3  connected_order_arc_470  -1
    order_0_3  connected_order_arc_472  -1
    order_0_3  connected_order_arc_474  -1
    order_0_3  connected_order_arc_476  -1
    order_0_3  connected_order_arc_478  -1
    order_0_3  connected_order_arc_485  1
    order_0_3  connected_order_arc_512  1
    order_0_3  connected_order_arc_539  1
    order_0_3  connected_order_arc_566  1
    order_0_3  connected_order_arc_593  1
    order_0_3  connected_order_arc_620  1
    order_0_3  connected_order_arc_647  1
    order_0_3  connected_order_arc_674  1
    order_0_3  connected_order_arc_701  1
    order_0_3  connected_order_arc_728  1
    order_0_3  connected_order_arc_755  1
    order_0_3  order_active_lb_794  1
    order_0_3  order_active_ub_795  1
    order_0_3  fixed_segment_relative_order_869  1
    order_0_3  fixed_segment_relative_order_870  -1
    visit_0_4  out_degree_799  -1
    visit_0_4  in_degree_800  -1
    visit_0_4  order_active_lb_801  -1
    visit_0_4  order_active_ub_802  -14
    order_0_4  connected_order_arc_404  1
    order_0_4  connected_order_arc_431  1
    order_0_4  connected_order_arc_458  1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_483  -1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_489  -1
    order_0_4  connected_order_arc_491  -1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_495  -1
    order_0_4  connected_order_arc_497  -1
    order_0_4  connected_order_arc_499  -1
    order_0_4  connected_order_arc_501  -1
    order_0_4  connected_order_arc_503  -1
    order_0_4  connected_order_arc_505  -1
    order_0_4  connected_order_arc_514  1
    order_0_4  connected_order_arc_541  1
    order_0_4  connected_order_arc_568  1
    order_0_4  connected_order_arc_595  1
    order_0_4  connected_order_arc_622  1
    order_0_4  connected_order_arc_649  1
    order_0_4  connected_order_arc_676  1
    order_0_4  connected_order_arc_703  1
    order_0_4  connected_order_arc_730  1
    order_0_4  connected_order_arc_757  1
    order_0_4  order_active_lb_801  1
    order_0_4  order_active_ub_802  1
    order_0_4  fixed_segment_relative_order_870  1
    order_0_4  fixed_segment_relative_order_871  -1
    visit_0_5  out_degree_806  -1
    visit_0_5  in_degree_807  -1
    visit_0_5  order_active_lb_808  -1
    visit_0_5  order_active_ub_809  -14
    order_0_5  connected_order_arc_406  1
    order_0_5  connected_order_arc_433  1
    order_0_5  connected_order_arc_460  1
    order_0_5  connected_order_arc_487  1
    order_0_5  connected_order_arc_508  -1
    order_0_5  connected_order_arc_510  -1
    order_0_5  connected_order_arc_512  -1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_516  -1
    order_0_5  connected_order_arc_518  -1
    order_0_5  connected_order_arc_520  -1
    order_0_5  connected_order_arc_522  -1
    order_0_5  connected_order_arc_524  -1
    order_0_5  connected_order_arc_526  -1
    order_0_5  connected_order_arc_528  -1
    order_0_5  connected_order_arc_530  -1
    order_0_5  connected_order_arc_532  -1
    order_0_5  connected_order_arc_543  1
    order_0_5  connected_order_arc_570  1
    order_0_5  connected_order_arc_597  1
    order_0_5  connected_order_arc_624  1
    order_0_5  connected_order_arc_651  1
    order_0_5  connected_order_arc_678  1
    order_0_5  connected_order_arc_705  1
    order_0_5  connected_order_arc_732  1
    order_0_5  connected_order_arc_759  1
    order_0_5  order_active_lb_808  1
    order_0_5  order_active_ub_809  1
    order_0_5  fixed_segment_relative_order_871  1
    order_0_5  fixed_segment_relative_order_872  -1
    visit_0_6  out_degree_813  -1
    visit_0_6  in_degree_814  -1
    visit_0_6  order_active_lb_815  -1
    visit_0_6  order_active_ub_816  -14
    order_0_6  connected_order_arc_408  1
    order_0_6  connected_order_arc_435  1
    order_0_6  connected_order_arc_462  1
    order_0_6  connected_order_arc_489  1
    order_0_6  connected_order_arc_516  1
    order_0_6  connected_order_arc_535  -1
    order_0_6  connected_order_arc_537  -1
    order_0_6  connected_order_arc_539  -1
    order_0_6  connected_order_arc_541  -1
    order_0_6  connected_order_arc_543  -1
    order_0_6  connected_order_arc_545  -1
    order_0_6  connected_order_arc_547  -1
    order_0_6  connected_order_arc_549  -1
    order_0_6  connected_order_arc_551  -1
    order_0_6  connected_order_arc_553  -1
    order_0_6  connected_order_arc_555  -1
    order_0_6  connected_order_arc_557  -1
    order_0_6  connected_order_arc_559  -1
    order_0_6  connected_order_arc_572  1
    order_0_6  connected_order_arc_599  1
    order_0_6  connected_order_arc_626  1
    order_0_6  connected_order_arc_653  1
    order_0_6  connected_order_arc_680  1
    order_0_6  connected_order_arc_707  1
    order_0_6  connected_order_arc_734  1
    order_0_6  connected_order_arc_761  1
    order_0_6  order_active_lb_815  1
    order_0_6  order_active_ub_816  1
    order_0_6  fixed_segment_relative_order_872  1
    visit_0_9  out_degree_820  -1
    visit_0_9  in_degree_821  -1
    visit_0_9  order_active_lb_822  -1
    visit_0_9  order_active_ub_823  -14
    visit_0_9  service_visit_def_824  -1
    order_0_9  connected_order_arc_410  1
    order_0_9  connected_order_arc_437  1
    order_0_9  connected_order_arc_464  1
    order_0_9  connected_order_arc_491  1
    order_0_9  connected_order_arc_518  1
    order_0_9  connected_order_arc_545  1
    order_0_9  connected_order_arc_562  -1
    order_0_9  connected_order_arc_564  -1
    order_0_9  connected_order_arc_566  -1
    order_0_9  connected_order_arc_568  -1
    order_0_9  connected_order_arc_570  -1
    order_0_9  connected_order_arc_572  -1
    order_0_9  connected_order_arc_574  -1
    order_0_9  connected_order_arc_576  -1
    order_0_9  connected_order_arc_578  -1
    order_0_9  connected_order_arc_580  -1
    order_0_9  connected_order_arc_582  -1
    order_0_9  connected_order_arc_584  -1
    order_0_9  connected_order_arc_586  -1
    order_0_9  connected_order_arc_601  1
    order_0_9  connected_order_arc_628  1
    order_0_9  connected_order_arc_655  1
    order_0_9  connected_order_arc_682  1
    order_0_9  connected_order_arc_709  1
    order_0_9  connected_order_arc_736  1
    order_0_9  connected_order_arc_763  1
    order_0_9  order_active_lb_822  1
    order_0_9  order_active_ub_823  1
    visit_0_10  out_degree_826  -1
    visit_0_10  in_degree_827  -1
    visit_0_10  order_active_lb_828  -1
    visit_0_10  order_active_ub_829  -14
    visit_0_10  service_visit_def_830  -1
    order_0_10  connected_order_arc_412  1
    order_0_10  connected_order_arc_439  1
    order_0_10  connected_order_arc_466  1
    order_0_10  connected_order_arc_493  1
    order_0_10  connected_order_arc_520  1
    order_0_10  connected_order_arc_547  1
    order_0_10  connected_order_arc_574  1
    order_0_10  connected_order_arc_589  -1
    order_0_10  connected_order_arc_591  -1
    order_0_10  connected_order_arc_593  -1
    order_0_10  connected_order_arc_595  -1
    order_0_10  connected_order_arc_597  -1
    order_0_10  connected_order_arc_599  -1
    order_0_10  connected_order_arc_601  -1
    order_0_10  connected_order_arc_603  -1
    order_0_10  connected_order_arc_605  -1
    order_0_10  connected_order_arc_607  -1
    order_0_10  connected_order_arc_609  -1
    order_0_10  connected_order_arc_611  -1
    order_0_10  connected_order_arc_613  -1
    order_0_10  connected_order_arc_630  1
    order_0_10  connected_order_arc_657  1
    order_0_10  connected_order_arc_684  1
    order_0_10  connected_order_arc_711  1
    order_0_10  connected_order_arc_738  1
    order_0_10  connected_order_arc_765  1
    order_0_10  order_active_lb_828  1
    order_0_10  order_active_ub_829  1
    visit_0_11  out_degree_832  -1
    visit_0_11  in_degree_833  -1
    visit_0_11  order_active_lb_834  -1
    visit_0_11  order_active_ub_835  -14
    visit_0_11  service_visit_def_836  -1
    order_0_11  connected_order_arc_414  1
    order_0_11  connected_order_arc_441  1
    order_0_11  connected_order_arc_468  1
    order_0_11  connected_order_arc_495  1
    order_0_11  connected_order_arc_522  1
    order_0_11  connected_order_arc_549  1
    order_0_11  connected_order_arc_576  1
    order_0_11  connected_order_arc_603  1
    order_0_11  connected_order_arc_616  -1
    order_0_11  connected_order_arc_618  -1
    order_0_11  connected_order_arc_620  -1
    order_0_11  connected_order_arc_622  -1
    order_0_11  connected_order_arc_624  -1
    order_0_11  connected_order_arc_626  -1
    order_0_11  connected_order_arc_628  -1
    order_0_11  connected_order_arc_630  -1
    order_0_11  connected_order_arc_632  -1
    order_0_11  connected_order_arc_634  -1
    order_0_11  connected_order_arc_636  -1
    order_0_11  connected_order_arc_638  -1
    order_0_11  connected_order_arc_640  -1
    order_0_11  connected_order_arc_659  1
    order_0_11  connected_order_arc_686  1
    order_0_11  connected_order_arc_713  1
    order_0_11  connected_order_arc_740  1
    order_0_11  connected_order_arc_767  1
    order_0_11  order_active_lb_834  1
    order_0_11  order_active_ub_835  1
    visit_0_12  out_degree_838  -1
    visit_0_12  in_degree_839  -1
    visit_0_12  order_active_lb_840  -1
    visit_0_12  order_active_ub_841  -14
    visit_0_12  service_visit_def_842  -1
    order_0_12  connected_order_arc_416  1
    order_0_12  connected_order_arc_443  1
    order_0_12  connected_order_arc_470  1
    order_0_12  connected_order_arc_497  1
    order_0_12  connected_order_arc_524  1
    order_0_12  connected_order_arc_551  1
    order_0_12  connected_order_arc_578  1
    order_0_12  connected_order_arc_605  1
    order_0_12  connected_order_arc_632  1
    order_0_12  connected_order_arc_643  -1
    order_0_12  connected_order_arc_645  -1
    order_0_12  connected_order_arc_647  -1
    order_0_12  connected_order_arc_649  -1
    order_0_12  connected_order_arc_651  -1
    order_0_12  connected_order_arc_653  -1
    order_0_12  connected_order_arc_655  -1
    order_0_12  connected_order_arc_657  -1
    order_0_12  connected_order_arc_659  -1
    order_0_12  connected_order_arc_661  -1
    order_0_12  connected_order_arc_663  -1
    order_0_12  connected_order_arc_665  -1
    order_0_12  connected_order_arc_667  -1
    order_0_12  connected_order_arc_688  1
    order_0_12  connected_order_arc_715  1
    order_0_12  connected_order_arc_742  1
    order_0_12  connected_order_arc_769  1
    order_0_12  order_active_lb_840  1
    order_0_12  order_active_ub_841  1
    visit_0_13  out_degree_844  -1
    visit_0_13  in_degree_845  -1
    visit_0_13  order_active_lb_846  -1
    visit_0_13  order_active_ub_847  -14
    visit_0_13  service_visit_def_848  -1
    order_0_13  connected_order_arc_418  1
    order_0_13  connected_order_arc_445  1
    order_0_13  connected_order_arc_472  1
    order_0_13  connected_order_arc_499  1
    order_0_13  connected_order_arc_526  1
    order_0_13  connected_order_arc_553  1
    order_0_13  connected_order_arc_580  1
    order_0_13  connected_order_arc_607  1
    order_0_13  connected_order_arc_634  1
    order_0_13  connected_order_arc_661  1
    order_0_13  connected_order_arc_670  -1
    order_0_13  connected_order_arc_672  -1
    order_0_13  connected_order_arc_674  -1
    order_0_13  connected_order_arc_676  -1
    order_0_13  connected_order_arc_678  -1
    order_0_13  connected_order_arc_680  -1
    order_0_13  connected_order_arc_682  -1
    order_0_13  connected_order_arc_684  -1
    order_0_13  connected_order_arc_686  -1
    order_0_13  connected_order_arc_688  -1
    order_0_13  connected_order_arc_690  -1
    order_0_13  connected_order_arc_692  -1
    order_0_13  connected_order_arc_694  -1
    order_0_13  connected_order_arc_717  1
    order_0_13  connected_order_arc_744  1
    order_0_13  connected_order_arc_771  1
    order_0_13  order_active_lb_846  1
    order_0_13  order_active_ub_847  1
    visit_0_14  out_degree_850  -1
    visit_0_14  in_degree_851  -1
    visit_0_14  order_active_lb_852  -1
    visit_0_14  order_active_ub_853  -14
    visit_0_14  service_visit_def_854  -1
    order_0_14  connected_order_arc_420  1
    order_0_14  connected_order_arc_447  1
    order_0_14  connected_order_arc_474  1
    order_0_14  connected_order_arc_501  1
    order_0_14  connected_order_arc_528  1
    order_0_14  connected_order_arc_555  1
    order_0_14  connected_order_arc_582  1
    order_0_14  connected_order_arc_609  1
    order_0_14  connected_order_arc_636  1
    order_0_14  connected_order_arc_663  1
    order_0_14  connected_order_arc_690  1
    order_0_14  connected_order_arc_697  -1
    order_0_14  connected_order_arc_699  -1
    order_0_14  connected_order_arc_701  -1
    order_0_14  connected_order_arc_703  -1
    order_0_14  connected_order_arc_705  -1
    order_0_14  connected_order_arc_707  -1
    order_0_14  connected_order_arc_709  -1
    order_0_14  connected_order_arc_711  -1
    order_0_14  connected_order_arc_713  -1
    order_0_14  connected_order_arc_715  -1
    order_0_14  connected_order_arc_717  -1
    order_0_14  connected_order_arc_719  -1
    order_0_14  connected_order_arc_721  -1
    order_0_14  connected_order_arc_746  1
    order_0_14  connected_order_arc_773  1
    order_0_14  order_active_lb_852  1
    order_0_14  order_active_ub_853  1
    visit_0_15  out_degree_856  -1
    visit_0_15  in_degree_857  -1
    visit_0_15  order_active_lb_858  -1
    visit_0_15  order_active_ub_859  -14
    visit_0_15  service_visit_def_860  -1
    order_0_15  connected_order_arc_422  1
    order_0_15  connected_order_arc_449  1
    order_0_15  connected_order_arc_476  1
    order_0_15  connected_order_arc_503  1
    order_0_15  connected_order_arc_530  1
    order_0_15  connected_order_arc_557  1
    order_0_15  connected_order_arc_584  1
    order_0_15  connected_order_arc_611  1
    order_0_15  connected_order_arc_638  1
    order_0_15  connected_order_arc_665  1
    order_0_15  connected_order_arc_692  1
    order_0_15  connected_order_arc_719  1
    order_0_15  connected_order_arc_724  -1
    order_0_15  connected_order_arc_726  -1
    order_0_15  connected_order_arc_728  -1
    order_0_15  connected_order_arc_730  -1
    order_0_15  connected_order_arc_732  -1
    order_0_15  connected_order_arc_734  -1
    order_0_15  connected_order_arc_736  -1
    order_0_15  connected_order_arc_738  -1
    order_0_15  connected_order_arc_740  -1
    order_0_15  connected_order_arc_742  -1
    order_0_15  connected_order_arc_744  -1
    order_0_15  connected_order_arc_746  -1
    order_0_15  connected_order_arc_748  -1
    order_0_15  connected_order_arc_775  1
    order_0_15  order_active_lb_858  1
    order_0_15  order_active_ub_859  1
    visit_0_16  out_degree_862  -1
    visit_0_16  in_degree_863  -1
    visit_0_16  order_active_lb_864  -1
    visit_0_16  order_active_ub_865  -14
    visit_0_16  service_visit_def_866  -1
    order_0_16  connected_order_arc_424  1
    order_0_16  connected_order_arc_451  1
    order_0_16  connected_order_arc_478  1
    order_0_16  connected_order_arc_505  1
    order_0_16  connected_order_arc_532  1
    order_0_16  connected_order_arc_559  1
    order_0_16  connected_order_arc_586  1
    order_0_16  connected_order_arc_613  1
    order_0_16  connected_order_arc_640  1
    order_0_16  connected_order_arc_667  1
    order_0_16  connected_order_arc_694  1
    order_0_16  connected_order_arc_721  1
    order_0_16  connected_order_arc_748  1
    order_0_16  connected_order_arc_751  -1
    order_0_16  connected_order_arc_753  -1
    order_0_16  connected_order_arc_755  -1
    order_0_16  connected_order_arc_757  -1
    order_0_16  connected_order_arc_759  -1
    order_0_16  connected_order_arc_761  -1
    order_0_16  connected_order_arc_763  -1
    order_0_16  connected_order_arc_765  -1
    order_0_16  connected_order_arc_767  -1
    order_0_16  connected_order_arc_769  -1
    order_0_16  connected_order_arc_771  -1
    order_0_16  connected_order_arc_773  -1
    order_0_16  connected_order_arc_775  -1
    order_0_16  order_active_lb_864  1
    order_0_16  order_active_ub_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_383  -30
    arc_0_0_0  depot_departure_or_bypass_776  1
    arc_0_0_0  depot_return_or_bypass_777  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_383  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_384  -30
    arc_0_0_1  depot_departure_or_bypass_776  1
    arc_0_0_1  in_degree_779  1
    arc_0_0_1  original_T_including_depot_unload_873  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_384  1
    load_0_0_1  segment_load_conservation_782  -1
    load_0_0_1  segment_prefix_lb_783  1
    load_0_0_1  segment_prefix_ub_784  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_385  -30
    arc_0_0_2  depot_departure_or_bypass_776  1
    arc_0_0_2  in_degree_786  1
    arc_0_0_2  original_T_including_depot_unload_873  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_385  1
    load_0_0_2  segment_load_conservation_789  -1
    load_0_0_2  segment_prefix_lb_790  1
    load_0_0_2  segment_prefix_ub_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_386  -30
    arc_0_0_3  depot_departure_or_bypass_776  1
    arc_0_0_3  in_degree_793  1
    arc_0_0_3  original_T_including_depot_unload_873  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_386  1
    load_0_0_3  segment_load_conservation_796  -1
    load_0_0_3  segment_prefix_lb_797  1
    load_0_0_3  segment_prefix_ub_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_387  -30
    arc_0_0_4  depot_departure_or_bypass_776  1
    arc_0_0_4  in_degree_800  1
    arc_0_0_4  original_T_including_depot_unload_873  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_387  1
    load_0_0_4  segment_load_conservation_803  -1
    load_0_0_4  segment_prefix_lb_804  1
    load_0_0_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_388  -30
    arc_0_0_5  depot_departure_or_bypass_776  1
    arc_0_0_5  in_degree_807  1
    arc_0_0_5  original_T_including_depot_unload_873  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_388  1
    load_0_0_5  segment_load_conservation_810  -1
    load_0_0_5  segment_prefix_lb_811  1
    load_0_0_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_389  -30
    arc_0_0_6  depot_departure_or_bypass_776  1
    arc_0_0_6  in_degree_814  1
    arc_0_0_6  original_T_including_depot_unload_873  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_389  1
    load_0_0_6  segment_load_conservation_817  -1
    load_0_0_6  segment_prefix_lb_818  1
    load_0_0_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_390  -30
    arc_0_0_9  depot_departure_or_bypass_776  1
    arc_0_0_9  in_degree_821  1
    arc_0_0_9  original_T_including_depot_unload_873  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_390  1
    load_0_0_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_391  -30
    arc_0_0_10  depot_departure_or_bypass_776  1
    arc_0_0_10  in_degree_827  1
    arc_0_0_10  original_T_including_depot_unload_873  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_391  1
    load_0_0_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_392  -30
    arc_0_0_11  depot_departure_or_bypass_776  1
    arc_0_0_11  in_degree_833  1
    arc_0_0_11  original_T_including_depot_unload_873  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_392  1
    load_0_0_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_393  -30
    arc_0_0_12  depot_departure_or_bypass_776  1
    arc_0_0_12  in_degree_839  1
    arc_0_0_12  original_T_including_depot_unload_873  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_393  1
    load_0_0_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_394  -30
    arc_0_0_13  depot_departure_or_bypass_776  1
    arc_0_0_13  in_degree_845  1
    arc_0_0_13  original_T_including_depot_unload_873  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_394  1
    load_0_0_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_395  -30
    arc_0_0_14  depot_departure_or_bypass_776  1
    arc_0_0_14  in_degree_851  1
    arc_0_0_14  original_T_including_depot_unload_873  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_395  1
    load_0_0_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_396  -30
    arc_0_0_15  depot_departure_or_bypass_776  1
    arc_0_0_15  in_degree_857  1
    arc_0_0_15  original_T_including_depot_unload_873  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_396  1
    load_0_0_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_397  -30
    arc_0_0_16  depot_departure_or_bypass_776  1
    arc_0_0_16  in_degree_863  1
    arc_0_0_16  original_T_including_depot_unload_873  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_397  1
    load_0_0_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_398  -30
    arc_0_1_0  depot_return_or_bypass_777  1
    arc_0_1_0  out_degree_778  1
    arc_0_1_0  original_T_including_depot_unload_873  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_398  1
    load_0_1_0  segment_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_399  -30
    arc_0_1_2  connected_order_arc_400  -15
    arc_0_1_2  out_degree_778  1
    arc_0_1_2  in_degree_786  1
    arc_0_1_2  original_T_including_depot_unload_873  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_399  1
    load_0_1_2  segment_load_conservation_782  1
    load_0_1_2  segment_load_conservation_789  -1
    load_0_1_2  segment_prefix_lb_790  1
    load_0_1_2  segment_prefix_ub_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_401  -30
    arc_0_1_3  connected_order_arc_402  -15
    arc_0_1_3  out_degree_778  1
    arc_0_1_3  in_degree_793  1
    arc_0_1_3  original_T_including_depot_unload_873  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_401  1
    load_0_1_3  segment_load_conservation_782  1
    load_0_1_3  segment_load_conservation_796  -1
    load_0_1_3  segment_prefix_lb_797  1
    load_0_1_3  segment_prefix_ub_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_403  -30
    arc_0_1_4  connected_order_arc_404  -15
    arc_0_1_4  out_degree_778  1
    arc_0_1_4  in_degree_800  1
    arc_0_1_4  original_T_including_depot_unload_873  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_403  1
    load_0_1_4  segment_load_conservation_782  1
    load_0_1_4  segment_load_conservation_803  -1
    load_0_1_4  segment_prefix_lb_804  1
    load_0_1_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_405  -30
    arc_0_1_5  connected_order_arc_406  -15
    arc_0_1_5  out_degree_778  1
    arc_0_1_5  in_degree_807  1
    arc_0_1_5  original_T_including_depot_unload_873  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_405  1
    load_0_1_5  segment_load_conservation_782  1
    load_0_1_5  segment_load_conservation_810  -1
    load_0_1_5  segment_prefix_lb_811  1
    load_0_1_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_407  -30
    arc_0_1_6  connected_order_arc_408  -15
    arc_0_1_6  out_degree_778  1
    arc_0_1_6  in_degree_814  1
    arc_0_1_6  original_T_including_depot_unload_873  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_407  1
    load_0_1_6  segment_load_conservation_782  1
    load_0_1_6  segment_load_conservation_817  -1
    load_0_1_6  segment_prefix_lb_818  1
    load_0_1_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_409  -30
    arc_0_1_9  connected_order_arc_410  -15
    arc_0_1_9  out_degree_778  1
    arc_0_1_9  in_degree_821  1
    arc_0_1_9  original_T_including_depot_unload_873  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_409  1
    load_0_1_9  segment_load_conservation_782  1
    load_0_1_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_411  -30
    arc_0_1_10  connected_order_arc_412  -15
    arc_0_1_10  out_degree_778  1
    arc_0_1_10  in_degree_827  1
    arc_0_1_10  original_T_including_depot_unload_873  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_411  1
    load_0_1_10  segment_load_conservation_782  1
    load_0_1_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_413  -30
    arc_0_1_11  connected_order_arc_414  -15
    arc_0_1_11  out_degree_778  1
    arc_0_1_11  in_degree_833  1
    arc_0_1_11  original_T_including_depot_unload_873  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_413  1
    load_0_1_11  segment_load_conservation_782  1
    load_0_1_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_415  -30
    arc_0_1_12  connected_order_arc_416  -15
    arc_0_1_12  out_degree_778  1
    arc_0_1_12  in_degree_839  1
    arc_0_1_12  original_T_including_depot_unload_873  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_415  1
    load_0_1_12  segment_load_conservation_782  1
    load_0_1_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_417  -30
    arc_0_1_13  connected_order_arc_418  -15
    arc_0_1_13  out_degree_778  1
    arc_0_1_13  in_degree_845  1
    arc_0_1_13  original_T_including_depot_unload_873  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_417  1
    load_0_1_13  segment_load_conservation_782  1
    load_0_1_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_419  -30
    arc_0_1_14  connected_order_arc_420  -15
    arc_0_1_14  out_degree_778  1
    arc_0_1_14  in_degree_851  1
    arc_0_1_14  original_T_including_depot_unload_873  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_419  1
    load_0_1_14  segment_load_conservation_782  1
    load_0_1_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_421  -30
    arc_0_1_15  connected_order_arc_422  -15
    arc_0_1_15  out_degree_778  1
    arc_0_1_15  in_degree_857  1
    arc_0_1_15  original_T_including_depot_unload_873  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_421  1
    load_0_1_15  segment_load_conservation_782  1
    load_0_1_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_423  -30
    arc_0_1_16  connected_order_arc_424  -15
    arc_0_1_16  out_degree_778  1
    arc_0_1_16  in_degree_863  1
    arc_0_1_16  original_T_including_depot_unload_873  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_423  1
    load_0_1_16  segment_load_conservation_782  1
    load_0_1_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_425  -30
    arc_0_2_0  depot_return_or_bypass_777  1
    arc_0_2_0  out_degree_785  1
    arc_0_2_0  original_T_including_depot_unload_873  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_425  1
    load_0_2_0  segment_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_426  -30
    arc_0_2_1  connected_order_arc_427  -15
    arc_0_2_1  in_degree_779  1
    arc_0_2_1  out_degree_785  1
    arc_0_2_1  original_T_including_depot_unload_873  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_426  1
    load_0_2_1  segment_load_conservation_782  -1
    load_0_2_1  segment_prefix_lb_783  1
    load_0_2_1  segment_prefix_ub_784  1
    load_0_2_1  segment_load_conservation_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_428  -30
    arc_0_2_3  connected_order_arc_429  -15
    arc_0_2_3  out_degree_785  1
    arc_0_2_3  in_degree_793  1
    arc_0_2_3  original_T_including_depot_unload_873  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_428  1
    load_0_2_3  segment_load_conservation_789  1
    load_0_2_3  segment_load_conservation_796  -1
    load_0_2_3  segment_prefix_lb_797  1
    load_0_2_3  segment_prefix_ub_798  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_430  -30
    arc_0_2_4  connected_order_arc_431  -15
    arc_0_2_4  out_degree_785  1
    arc_0_2_4  in_degree_800  1
    arc_0_2_4  original_T_including_depot_unload_873  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_430  1
    load_0_2_4  segment_load_conservation_789  1
    load_0_2_4  segment_load_conservation_803  -1
    load_0_2_4  segment_prefix_lb_804  1
    load_0_2_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_432  -30
    arc_0_2_5  connected_order_arc_433  -15
    arc_0_2_5  out_degree_785  1
    arc_0_2_5  in_degree_807  1
    arc_0_2_5  original_T_including_depot_unload_873  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_432  1
    load_0_2_5  segment_load_conservation_789  1
    load_0_2_5  segment_load_conservation_810  -1
    load_0_2_5  segment_prefix_lb_811  1
    load_0_2_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_434  -30
    arc_0_2_6  connected_order_arc_435  -15
    arc_0_2_6  out_degree_785  1
    arc_0_2_6  in_degree_814  1
    arc_0_2_6  original_T_including_depot_unload_873  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_434  1
    load_0_2_6  segment_load_conservation_789  1
    load_0_2_6  segment_load_conservation_817  -1
    load_0_2_6  segment_prefix_lb_818  1
    load_0_2_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_436  -30
    arc_0_2_9  connected_order_arc_437  -15
    arc_0_2_9  out_degree_785  1
    arc_0_2_9  in_degree_821  1
    arc_0_2_9  original_T_including_depot_unload_873  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_436  1
    load_0_2_9  segment_load_conservation_789  1
    load_0_2_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_438  -30
    arc_0_2_10  connected_order_arc_439  -15
    arc_0_2_10  out_degree_785  1
    arc_0_2_10  in_degree_827  1
    arc_0_2_10  original_T_including_depot_unload_873  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_438  1
    load_0_2_10  segment_load_conservation_789  1
    load_0_2_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_440  -30
    arc_0_2_11  connected_order_arc_441  -15
    arc_0_2_11  out_degree_785  1
    arc_0_2_11  in_degree_833  1
    arc_0_2_11  original_T_including_depot_unload_873  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_440  1
    load_0_2_11  segment_load_conservation_789  1
    load_0_2_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_442  -30
    arc_0_2_12  connected_order_arc_443  -15
    arc_0_2_12  out_degree_785  1
    arc_0_2_12  in_degree_839  1
    arc_0_2_12  original_T_including_depot_unload_873  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_442  1
    load_0_2_12  segment_load_conservation_789  1
    load_0_2_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_444  -30
    arc_0_2_13  connected_order_arc_445  -15
    arc_0_2_13  out_degree_785  1
    arc_0_2_13  in_degree_845  1
    arc_0_2_13  original_T_including_depot_unload_873  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_444  1
    load_0_2_13  segment_load_conservation_789  1
    load_0_2_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_446  -30
    arc_0_2_14  connected_order_arc_447  -15
    arc_0_2_14  out_degree_785  1
    arc_0_2_14  in_degree_851  1
    arc_0_2_14  original_T_including_depot_unload_873  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_446  1
    load_0_2_14  segment_load_conservation_789  1
    load_0_2_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_448  -30
    arc_0_2_15  connected_order_arc_449  -15
    arc_0_2_15  out_degree_785  1
    arc_0_2_15  in_degree_857  1
    arc_0_2_15  original_T_including_depot_unload_873  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_448  1
    load_0_2_15  segment_load_conservation_789  1
    load_0_2_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_450  -30
    arc_0_2_16  connected_order_arc_451  -15
    arc_0_2_16  out_degree_785  1
    arc_0_2_16  in_degree_863  1
    arc_0_2_16  original_T_including_depot_unload_873  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_450  1
    load_0_2_16  segment_load_conservation_789  1
    load_0_2_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_452  -30
    arc_0_3_0  depot_return_or_bypass_777  1
    arc_0_3_0  out_degree_792  1
    arc_0_3_0  original_T_including_depot_unload_873  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_452  1
    load_0_3_0  segment_load_conservation_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_453  -30
    arc_0_3_1  connected_order_arc_454  -15
    arc_0_3_1  in_degree_779  1
    arc_0_3_1  out_degree_792  1
    arc_0_3_1  original_T_including_depot_unload_873  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_453  1
    load_0_3_1  segment_load_conservation_782  -1
    load_0_3_1  segment_prefix_lb_783  1
    load_0_3_1  segment_prefix_ub_784  1
    load_0_3_1  segment_load_conservation_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_455  -30
    arc_0_3_2  connected_order_arc_456  -15
    arc_0_3_2  in_degree_786  1
    arc_0_3_2  out_degree_792  1
    arc_0_3_2  original_T_including_depot_unload_873  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_455  1
    load_0_3_2  segment_load_conservation_789  -1
    load_0_3_2  segment_prefix_lb_790  1
    load_0_3_2  segment_prefix_ub_791  1
    load_0_3_2  segment_load_conservation_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_457  -30
    arc_0_3_4  connected_order_arc_458  -15
    arc_0_3_4  out_degree_792  1
    arc_0_3_4  in_degree_800  1
    arc_0_3_4  original_T_including_depot_unload_873  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_457  1
    load_0_3_4  segment_load_conservation_796  1
    load_0_3_4  segment_load_conservation_803  -1
    load_0_3_4  segment_prefix_lb_804  1
    load_0_3_4  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_459  -30
    arc_0_3_5  connected_order_arc_460  -15
    arc_0_3_5  out_degree_792  1
    arc_0_3_5  in_degree_807  1
    arc_0_3_5  original_T_including_depot_unload_873  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_459  1
    load_0_3_5  segment_load_conservation_796  1
    load_0_3_5  segment_load_conservation_810  -1
    load_0_3_5  segment_prefix_lb_811  1
    load_0_3_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_461  -30
    arc_0_3_6  connected_order_arc_462  -15
    arc_0_3_6  out_degree_792  1
    arc_0_3_6  in_degree_814  1
    arc_0_3_6  original_T_including_depot_unload_873  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_461  1
    load_0_3_6  segment_load_conservation_796  1
    load_0_3_6  segment_load_conservation_817  -1
    load_0_3_6  segment_prefix_lb_818  1
    load_0_3_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_463  -30
    arc_0_3_9  connected_order_arc_464  -15
    arc_0_3_9  out_degree_792  1
    arc_0_3_9  in_degree_821  1
    arc_0_3_9  original_T_including_depot_unload_873  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_463  1
    load_0_3_9  segment_load_conservation_796  1
    load_0_3_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_465  -30
    arc_0_3_10  connected_order_arc_466  -15
    arc_0_3_10  out_degree_792  1
    arc_0_3_10  in_degree_827  1
    arc_0_3_10  original_T_including_depot_unload_873  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_465  1
    load_0_3_10  segment_load_conservation_796  1
    load_0_3_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_467  -30
    arc_0_3_11  connected_order_arc_468  -15
    arc_0_3_11  out_degree_792  1
    arc_0_3_11  in_degree_833  1
    arc_0_3_11  original_T_including_depot_unload_873  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_467  1
    load_0_3_11  segment_load_conservation_796  1
    load_0_3_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_469  -30
    arc_0_3_12  connected_order_arc_470  -15
    arc_0_3_12  out_degree_792  1
    arc_0_3_12  in_degree_839  1
    arc_0_3_12  original_T_including_depot_unload_873  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_469  1
    load_0_3_12  segment_load_conservation_796  1
    load_0_3_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_471  -30
    arc_0_3_13  connected_order_arc_472  -15
    arc_0_3_13  out_degree_792  1
    arc_0_3_13  in_degree_845  1
    arc_0_3_13  original_T_including_depot_unload_873  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_471  1
    load_0_3_13  segment_load_conservation_796  1
    load_0_3_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_473  -30
    arc_0_3_14  connected_order_arc_474  -15
    arc_0_3_14  out_degree_792  1
    arc_0_3_14  in_degree_851  1
    arc_0_3_14  original_T_including_depot_unload_873  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_473  1
    load_0_3_14  segment_load_conservation_796  1
    load_0_3_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_475  -30
    arc_0_3_15  connected_order_arc_476  -15
    arc_0_3_15  out_degree_792  1
    arc_0_3_15  in_degree_857  1
    arc_0_3_15  original_T_including_depot_unload_873  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_475  1
    load_0_3_15  segment_load_conservation_796  1
    load_0_3_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_477  -30
    arc_0_3_16  connected_order_arc_478  -15
    arc_0_3_16  out_degree_792  1
    arc_0_3_16  in_degree_863  1
    arc_0_3_16  original_T_including_depot_unload_873  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_477  1
    load_0_3_16  segment_load_conservation_796  1
    load_0_3_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_479  -30
    arc_0_4_0  depot_return_or_bypass_777  1
    arc_0_4_0  out_degree_799  1
    arc_0_4_0  original_T_including_depot_unload_873  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_479  1
    load_0_4_0  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_480  -30
    arc_0_4_1  connected_order_arc_481  -15
    arc_0_4_1  in_degree_779  1
    arc_0_4_1  out_degree_799  1
    arc_0_4_1  original_T_including_depot_unload_873  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_480  1
    load_0_4_1  segment_load_conservation_782  -1
    load_0_4_1  segment_prefix_lb_783  1
    load_0_4_1  segment_prefix_ub_784  1
    load_0_4_1  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_482  -30
    arc_0_4_2  connected_order_arc_483  -15
    arc_0_4_2  in_degree_786  1
    arc_0_4_2  out_degree_799  1
    arc_0_4_2  original_T_including_depot_unload_873  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_482  1
    load_0_4_2  segment_load_conservation_789  -1
    load_0_4_2  segment_prefix_lb_790  1
    load_0_4_2  segment_prefix_ub_791  1
    load_0_4_2  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_484  -30
    arc_0_4_3  connected_order_arc_485  -15
    arc_0_4_3  in_degree_793  1
    arc_0_4_3  out_degree_799  1
    arc_0_4_3  original_T_including_depot_unload_873  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_484  1
    load_0_4_3  segment_load_conservation_796  -1
    load_0_4_3  segment_prefix_lb_797  1
    load_0_4_3  segment_prefix_ub_798  1
    load_0_4_3  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_486  -30
    arc_0_4_5  connected_order_arc_487  -15
    arc_0_4_5  out_degree_799  1
    arc_0_4_5  in_degree_807  1
    arc_0_4_5  original_T_including_depot_unload_873  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_486  1
    load_0_4_5  segment_load_conservation_803  1
    load_0_4_5  segment_load_conservation_810  -1
    load_0_4_5  segment_prefix_lb_811  1
    load_0_4_5  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_488  -30
    arc_0_4_6  connected_order_arc_489  -15
    arc_0_4_6  out_degree_799  1
    arc_0_4_6  in_degree_814  1
    arc_0_4_6  original_T_including_depot_unload_873  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_488  1
    load_0_4_6  segment_load_conservation_803  1
    load_0_4_6  segment_load_conservation_817  -1
    load_0_4_6  segment_prefix_lb_818  1
    load_0_4_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_490  -30
    arc_0_4_9  connected_order_arc_491  -15
    arc_0_4_9  out_degree_799  1
    arc_0_4_9  in_degree_821  1
    arc_0_4_9  original_T_including_depot_unload_873  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_490  1
    load_0_4_9  segment_load_conservation_803  1
    load_0_4_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_492  -30
    arc_0_4_10  connected_order_arc_493  -15
    arc_0_4_10  out_degree_799  1
    arc_0_4_10  in_degree_827  1
    arc_0_4_10  original_T_including_depot_unload_873  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_492  1
    load_0_4_10  segment_load_conservation_803  1
    load_0_4_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_494  -30
    arc_0_4_11  connected_order_arc_495  -15
    arc_0_4_11  out_degree_799  1
    arc_0_4_11  in_degree_833  1
    arc_0_4_11  original_T_including_depot_unload_873  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_494  1
    load_0_4_11  segment_load_conservation_803  1
    load_0_4_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_496  -30
    arc_0_4_12  connected_order_arc_497  -15
    arc_0_4_12  out_degree_799  1
    arc_0_4_12  in_degree_839  1
    arc_0_4_12  original_T_including_depot_unload_873  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_496  1
    load_0_4_12  segment_load_conservation_803  1
    load_0_4_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_498  -30
    arc_0_4_13  connected_order_arc_499  -15
    arc_0_4_13  out_degree_799  1
    arc_0_4_13  in_degree_845  1
    arc_0_4_13  original_T_including_depot_unload_873  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_498  1
    load_0_4_13  segment_load_conservation_803  1
    load_0_4_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_500  -30
    arc_0_4_14  connected_order_arc_501  -15
    arc_0_4_14  out_degree_799  1
    arc_0_4_14  in_degree_851  1
    arc_0_4_14  original_T_including_depot_unload_873  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_500  1
    load_0_4_14  segment_load_conservation_803  1
    load_0_4_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_502  -30
    arc_0_4_15  connected_order_arc_503  -15
    arc_0_4_15  out_degree_799  1
    arc_0_4_15  in_degree_857  1
    arc_0_4_15  original_T_including_depot_unload_873  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_502  1
    load_0_4_15  segment_load_conservation_803  1
    load_0_4_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_504  -30
    arc_0_4_16  connected_order_arc_505  -15
    arc_0_4_16  out_degree_799  1
    arc_0_4_16  in_degree_863  1
    arc_0_4_16  original_T_including_depot_unload_873  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_504  1
    load_0_4_16  segment_load_conservation_803  1
    load_0_4_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_506  -30
    arc_0_5_0  depot_return_or_bypass_777  1
    arc_0_5_0  out_degree_806  1
    arc_0_5_0  original_T_including_depot_unload_873  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_506  1
    load_0_5_0  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_507  -30
    arc_0_5_1  connected_order_arc_508  -15
    arc_0_5_1  in_degree_779  1
    arc_0_5_1  out_degree_806  1
    arc_0_5_1  original_T_including_depot_unload_873  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_507  1
    load_0_5_1  segment_load_conservation_782  -1
    load_0_5_1  segment_prefix_lb_783  1
    load_0_5_1  segment_prefix_ub_784  1
    load_0_5_1  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_509  -30
    arc_0_5_2  connected_order_arc_510  -15
    arc_0_5_2  in_degree_786  1
    arc_0_5_2  out_degree_806  1
    arc_0_5_2  original_T_including_depot_unload_873  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_509  1
    load_0_5_2  segment_load_conservation_789  -1
    load_0_5_2  segment_prefix_lb_790  1
    load_0_5_2  segment_prefix_ub_791  1
    load_0_5_2  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_511  -30
    arc_0_5_3  connected_order_arc_512  -15
    arc_0_5_3  in_degree_793  1
    arc_0_5_3  out_degree_806  1
    arc_0_5_3  original_T_including_depot_unload_873  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_511  1
    load_0_5_3  segment_load_conservation_796  -1
    load_0_5_3  segment_prefix_lb_797  1
    load_0_5_3  segment_prefix_ub_798  1
    load_0_5_3  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_513  -30
    arc_0_5_4  connected_order_arc_514  -15
    arc_0_5_4  in_degree_800  1
    arc_0_5_4  out_degree_806  1
    arc_0_5_4  original_T_including_depot_unload_873  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_513  1
    load_0_5_4  segment_load_conservation_803  -1
    load_0_5_4  segment_prefix_lb_804  1
    load_0_5_4  segment_prefix_ub_805  1
    load_0_5_4  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_515  -30
    arc_0_5_6  connected_order_arc_516  -15
    arc_0_5_6  out_degree_806  1
    arc_0_5_6  in_degree_814  1
    arc_0_5_6  original_T_including_depot_unload_873  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_515  1
    load_0_5_6  segment_load_conservation_810  1
    load_0_5_6  segment_load_conservation_817  -1
    load_0_5_6  segment_prefix_lb_818  1
    load_0_5_6  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_517  -30
    arc_0_5_9  connected_order_arc_518  -15
    arc_0_5_9  out_degree_806  1
    arc_0_5_9  in_degree_821  1
    arc_0_5_9  original_T_including_depot_unload_873  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_517  1
    load_0_5_9  segment_load_conservation_810  1
    load_0_5_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_519  -30
    arc_0_5_10  connected_order_arc_520  -15
    arc_0_5_10  out_degree_806  1
    arc_0_5_10  in_degree_827  1
    arc_0_5_10  original_T_including_depot_unload_873  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_519  1
    load_0_5_10  segment_load_conservation_810  1
    load_0_5_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_521  -30
    arc_0_5_11  connected_order_arc_522  -15
    arc_0_5_11  out_degree_806  1
    arc_0_5_11  in_degree_833  1
    arc_0_5_11  original_T_including_depot_unload_873  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_521  1
    load_0_5_11  segment_load_conservation_810  1
    load_0_5_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_523  -30
    arc_0_5_12  connected_order_arc_524  -15
    arc_0_5_12  out_degree_806  1
    arc_0_5_12  in_degree_839  1
    arc_0_5_12  original_T_including_depot_unload_873  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_523  1
    load_0_5_12  segment_load_conservation_810  1
    load_0_5_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_525  -30
    arc_0_5_13  connected_order_arc_526  -15
    arc_0_5_13  out_degree_806  1
    arc_0_5_13  in_degree_845  1
    arc_0_5_13  original_T_including_depot_unload_873  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_525  1
    load_0_5_13  segment_load_conservation_810  1
    load_0_5_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_527  -30
    arc_0_5_14  connected_order_arc_528  -15
    arc_0_5_14  out_degree_806  1
    arc_0_5_14  in_degree_851  1
    arc_0_5_14  original_T_including_depot_unload_873  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_527  1
    load_0_5_14  segment_load_conservation_810  1
    load_0_5_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_529  -30
    arc_0_5_15  connected_order_arc_530  -15
    arc_0_5_15  out_degree_806  1
    arc_0_5_15  in_degree_857  1
    arc_0_5_15  original_T_including_depot_unload_873  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_529  1
    load_0_5_15  segment_load_conservation_810  1
    load_0_5_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_531  -30
    arc_0_5_16  connected_order_arc_532  -15
    arc_0_5_16  out_degree_806  1
    arc_0_5_16  in_degree_863  1
    arc_0_5_16  original_T_including_depot_unload_873  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_531  1
    load_0_5_16  segment_load_conservation_810  1
    load_0_5_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_533  -30
    arc_0_6_0  depot_return_or_bypass_777  1
    arc_0_6_0  out_degree_813  1
    arc_0_6_0  original_T_including_depot_unload_873  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_533  1
    load_0_6_0  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_534  -30
    arc_0_6_1  connected_order_arc_535  -15
    arc_0_6_1  in_degree_779  1
    arc_0_6_1  out_degree_813  1
    arc_0_6_1  original_T_including_depot_unload_873  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_534  1
    load_0_6_1  segment_load_conservation_782  -1
    load_0_6_1  segment_prefix_lb_783  1
    load_0_6_1  segment_prefix_ub_784  1
    load_0_6_1  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_536  -30
    arc_0_6_2  connected_order_arc_537  -15
    arc_0_6_2  in_degree_786  1
    arc_0_6_2  out_degree_813  1
    arc_0_6_2  original_T_including_depot_unload_873  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_536  1
    load_0_6_2  segment_load_conservation_789  -1
    load_0_6_2  segment_prefix_lb_790  1
    load_0_6_2  segment_prefix_ub_791  1
    load_0_6_2  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_538  -30
    arc_0_6_3  connected_order_arc_539  -15
    arc_0_6_3  in_degree_793  1
    arc_0_6_3  out_degree_813  1
    arc_0_6_3  original_T_including_depot_unload_873  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_538  1
    load_0_6_3  segment_load_conservation_796  -1
    load_0_6_3  segment_prefix_lb_797  1
    load_0_6_3  segment_prefix_ub_798  1
    load_0_6_3  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_540  -30
    arc_0_6_4  connected_order_arc_541  -15
    arc_0_6_4  in_degree_800  1
    arc_0_6_4  out_degree_813  1
    arc_0_6_4  original_T_including_depot_unload_873  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_540  1
    load_0_6_4  segment_load_conservation_803  -1
    load_0_6_4  segment_prefix_lb_804  1
    load_0_6_4  segment_prefix_ub_805  1
    load_0_6_4  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_542  -30
    arc_0_6_5  connected_order_arc_543  -15
    arc_0_6_5  in_degree_807  1
    arc_0_6_5  out_degree_813  1
    arc_0_6_5  original_T_including_depot_unload_873  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_542  1
    load_0_6_5  segment_load_conservation_810  -1
    load_0_6_5  segment_prefix_lb_811  1
    load_0_6_5  segment_prefix_ub_812  1
    load_0_6_5  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_544  -30
    arc_0_6_9  connected_order_arc_545  -15
    arc_0_6_9  out_degree_813  1
    arc_0_6_9  in_degree_821  1
    arc_0_6_9  original_T_including_depot_unload_873  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_544  1
    load_0_6_9  segment_load_conservation_817  1
    load_0_6_9  free_load_conservation_825  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_546  -30
    arc_0_6_10  connected_order_arc_547  -15
    arc_0_6_10  out_degree_813  1
    arc_0_6_10  in_degree_827  1
    arc_0_6_10  original_T_including_depot_unload_873  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_546  1
    load_0_6_10  segment_load_conservation_817  1
    load_0_6_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_548  -30
    arc_0_6_11  connected_order_arc_549  -15
    arc_0_6_11  out_degree_813  1
    arc_0_6_11  in_degree_833  1
    arc_0_6_11  original_T_including_depot_unload_873  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_548  1
    load_0_6_11  segment_load_conservation_817  1
    load_0_6_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_550  -30
    arc_0_6_12  connected_order_arc_551  -15
    arc_0_6_12  out_degree_813  1
    arc_0_6_12  in_degree_839  1
    arc_0_6_12  original_T_including_depot_unload_873  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_550  1
    load_0_6_12  segment_load_conservation_817  1
    load_0_6_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_552  -30
    arc_0_6_13  connected_order_arc_553  -15
    arc_0_6_13  out_degree_813  1
    arc_0_6_13  in_degree_845  1
    arc_0_6_13  original_T_including_depot_unload_873  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_552  1
    load_0_6_13  segment_load_conservation_817  1
    load_0_6_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_554  -30
    arc_0_6_14  connected_order_arc_555  -15
    arc_0_6_14  out_degree_813  1
    arc_0_6_14  in_degree_851  1
    arc_0_6_14  original_T_including_depot_unload_873  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_554  1
    load_0_6_14  segment_load_conservation_817  1
    load_0_6_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_556  -30
    arc_0_6_15  connected_order_arc_557  -15
    arc_0_6_15  out_degree_813  1
    arc_0_6_15  in_degree_857  1
    arc_0_6_15  original_T_including_depot_unload_873  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_556  1
    load_0_6_15  segment_load_conservation_817  1
    load_0_6_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_558  -30
    arc_0_6_16  connected_order_arc_559  -15
    arc_0_6_16  out_degree_813  1
    arc_0_6_16  in_degree_863  1
    arc_0_6_16  original_T_including_depot_unload_873  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_558  1
    load_0_6_16  segment_load_conservation_817  1
    load_0_6_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_560  -30
    arc_0_9_0  depot_return_or_bypass_777  1
    arc_0_9_0  out_degree_820  1
    arc_0_9_0  original_T_including_depot_unload_873  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_560  1
    load_0_9_0  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_561  -30
    arc_0_9_1  connected_order_arc_562  -15
    arc_0_9_1  in_degree_779  1
    arc_0_9_1  out_degree_820  1
    arc_0_9_1  original_T_including_depot_unload_873  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_561  1
    load_0_9_1  segment_load_conservation_782  -1
    load_0_9_1  segment_prefix_lb_783  1
    load_0_9_1  segment_prefix_ub_784  1
    load_0_9_1  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_563  -30
    arc_0_9_2  connected_order_arc_564  -15
    arc_0_9_2  in_degree_786  1
    arc_0_9_2  out_degree_820  1
    arc_0_9_2  original_T_including_depot_unload_873  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_563  1
    load_0_9_2  segment_load_conservation_789  -1
    load_0_9_2  segment_prefix_lb_790  1
    load_0_9_2  segment_prefix_ub_791  1
    load_0_9_2  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_565  -30
    arc_0_9_3  connected_order_arc_566  -15
    arc_0_9_3  in_degree_793  1
    arc_0_9_3  out_degree_820  1
    arc_0_9_3  original_T_including_depot_unload_873  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_565  1
    load_0_9_3  segment_load_conservation_796  -1
    load_0_9_3  segment_prefix_lb_797  1
    load_0_9_3  segment_prefix_ub_798  1
    load_0_9_3  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_567  -30
    arc_0_9_4  connected_order_arc_568  -15
    arc_0_9_4  in_degree_800  1
    arc_0_9_4  out_degree_820  1
    arc_0_9_4  original_T_including_depot_unload_873  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_567  1
    load_0_9_4  segment_load_conservation_803  -1
    load_0_9_4  segment_prefix_lb_804  1
    load_0_9_4  segment_prefix_ub_805  1
    load_0_9_4  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_569  -30
    arc_0_9_5  connected_order_arc_570  -15
    arc_0_9_5  in_degree_807  1
    arc_0_9_5  out_degree_820  1
    arc_0_9_5  original_T_including_depot_unload_873  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_569  1
    load_0_9_5  segment_load_conservation_810  -1
    load_0_9_5  segment_prefix_lb_811  1
    load_0_9_5  segment_prefix_ub_812  1
    load_0_9_5  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_571  -30
    arc_0_9_6  connected_order_arc_572  -15
    arc_0_9_6  in_degree_814  1
    arc_0_9_6  out_degree_820  1
    arc_0_9_6  original_T_including_depot_unload_873  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_571  1
    load_0_9_6  segment_load_conservation_817  -1
    load_0_9_6  segment_prefix_lb_818  1
    load_0_9_6  segment_prefix_ub_819  1
    load_0_9_6  free_load_conservation_825  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_573  -30
    arc_0_9_10  connected_order_arc_574  -15
    arc_0_9_10  out_degree_820  1
    arc_0_9_10  in_degree_827  1
    arc_0_9_10  original_T_including_depot_unload_873  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_573  1
    load_0_9_10  free_load_conservation_825  1
    load_0_9_10  free_load_conservation_831  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_575  -30
    arc_0_9_11  connected_order_arc_576  -15
    arc_0_9_11  out_degree_820  1
    arc_0_9_11  in_degree_833  1
    arc_0_9_11  original_T_including_depot_unload_873  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_575  1
    load_0_9_11  free_load_conservation_825  1
    load_0_9_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_577  -30
    arc_0_9_12  connected_order_arc_578  -15
    arc_0_9_12  out_degree_820  1
    arc_0_9_12  in_degree_839  1
    arc_0_9_12  original_T_including_depot_unload_873  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_577  1
    load_0_9_12  free_load_conservation_825  1
    load_0_9_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_579  -30
    arc_0_9_13  connected_order_arc_580  -15
    arc_0_9_13  out_degree_820  1
    arc_0_9_13  in_degree_845  1
    arc_0_9_13  original_T_including_depot_unload_873  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_579  1
    load_0_9_13  free_load_conservation_825  1
    load_0_9_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_581  -30
    arc_0_9_14  connected_order_arc_582  -15
    arc_0_9_14  out_degree_820  1
    arc_0_9_14  in_degree_851  1
    arc_0_9_14  original_T_including_depot_unload_873  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_581  1
    load_0_9_14  free_load_conservation_825  1
    load_0_9_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_583  -30
    arc_0_9_15  connected_order_arc_584  -15
    arc_0_9_15  out_degree_820  1
    arc_0_9_15  in_degree_857  1
    arc_0_9_15  original_T_including_depot_unload_873  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_583  1
    load_0_9_15  free_load_conservation_825  1
    load_0_9_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_16  arc_capacity_585  -30
    arc_0_9_16  connected_order_arc_586  -15
    arc_0_9_16  out_degree_820  1
    arc_0_9_16  in_degree_863  1
    arc_0_9_16  original_T_including_depot_unload_873  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_16  arc_capacity_585  1
    load_0_9_16  free_load_conservation_825  1
    load_0_9_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_587  -30
    arc_0_10_0  depot_return_or_bypass_777  1
    arc_0_10_0  out_degree_826  1
    arc_0_10_0  original_T_including_depot_unload_873  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_587  1
    load_0_10_0  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_588  -30
    arc_0_10_1  connected_order_arc_589  -15
    arc_0_10_1  in_degree_779  1
    arc_0_10_1  out_degree_826  1
    arc_0_10_1  original_T_including_depot_unload_873  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_588  1
    load_0_10_1  segment_load_conservation_782  -1
    load_0_10_1  segment_prefix_lb_783  1
    load_0_10_1  segment_prefix_ub_784  1
    load_0_10_1  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_590  -30
    arc_0_10_2  connected_order_arc_591  -15
    arc_0_10_2  in_degree_786  1
    arc_0_10_2  out_degree_826  1
    arc_0_10_2  original_T_including_depot_unload_873  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_590  1
    load_0_10_2  segment_load_conservation_789  -1
    load_0_10_2  segment_prefix_lb_790  1
    load_0_10_2  segment_prefix_ub_791  1
    load_0_10_2  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_592  -30
    arc_0_10_3  connected_order_arc_593  -15
    arc_0_10_3  in_degree_793  1
    arc_0_10_3  out_degree_826  1
    arc_0_10_3  original_T_including_depot_unload_873  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_592  1
    load_0_10_3  segment_load_conservation_796  -1
    load_0_10_3  segment_prefix_lb_797  1
    load_0_10_3  segment_prefix_ub_798  1
    load_0_10_3  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_594  -30
    arc_0_10_4  connected_order_arc_595  -15
    arc_0_10_4  in_degree_800  1
    arc_0_10_4  out_degree_826  1
    arc_0_10_4  original_T_including_depot_unload_873  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_594  1
    load_0_10_4  segment_load_conservation_803  -1
    load_0_10_4  segment_prefix_lb_804  1
    load_0_10_4  segment_prefix_ub_805  1
    load_0_10_4  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_596  -30
    arc_0_10_5  connected_order_arc_597  -15
    arc_0_10_5  in_degree_807  1
    arc_0_10_5  out_degree_826  1
    arc_0_10_5  original_T_including_depot_unload_873  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_596  1
    load_0_10_5  segment_load_conservation_810  -1
    load_0_10_5  segment_prefix_lb_811  1
    load_0_10_5  segment_prefix_ub_812  1
    load_0_10_5  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_598  -30
    arc_0_10_6  connected_order_arc_599  -15
    arc_0_10_6  in_degree_814  1
    arc_0_10_6  out_degree_826  1
    arc_0_10_6  original_T_including_depot_unload_873  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_598  1
    load_0_10_6  segment_load_conservation_817  -1
    load_0_10_6  segment_prefix_lb_818  1
    load_0_10_6  segment_prefix_ub_819  1
    load_0_10_6  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_600  -30
    arc_0_10_9  connected_order_arc_601  -15
    arc_0_10_9  in_degree_821  1
    arc_0_10_9  out_degree_826  1
    arc_0_10_9  original_T_including_depot_unload_873  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_600  1
    load_0_10_9  free_load_conservation_825  -1
    load_0_10_9  free_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_602  -30
    arc_0_10_11  connected_order_arc_603  -15
    arc_0_10_11  out_degree_826  1
    arc_0_10_11  in_degree_833  1
    arc_0_10_11  original_T_including_depot_unload_873  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_602  1
    load_0_10_11  free_load_conservation_831  1
    load_0_10_11  free_load_conservation_837  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_604  -30
    arc_0_10_12  connected_order_arc_605  -15
    arc_0_10_12  out_degree_826  1
    arc_0_10_12  in_degree_839  1
    arc_0_10_12  original_T_including_depot_unload_873  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_604  1
    load_0_10_12  free_load_conservation_831  1
    load_0_10_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_606  -30
    arc_0_10_13  connected_order_arc_607  -15
    arc_0_10_13  out_degree_826  1
    arc_0_10_13  in_degree_845  1
    arc_0_10_13  original_T_including_depot_unload_873  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_606  1
    load_0_10_13  free_load_conservation_831  1
    load_0_10_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_608  -30
    arc_0_10_14  connected_order_arc_609  -15
    arc_0_10_14  out_degree_826  1
    arc_0_10_14  in_degree_851  1
    arc_0_10_14  original_T_including_depot_unload_873  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_608  1
    load_0_10_14  free_load_conservation_831  1
    load_0_10_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_610  -30
    arc_0_10_15  connected_order_arc_611  -15
    arc_0_10_15  out_degree_826  1
    arc_0_10_15  in_degree_857  1
    arc_0_10_15  original_T_including_depot_unload_873  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_610  1
    load_0_10_15  free_load_conservation_831  1
    load_0_10_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_16  arc_capacity_612  -30
    arc_0_10_16  connected_order_arc_613  -15
    arc_0_10_16  out_degree_826  1
    arc_0_10_16  in_degree_863  1
    arc_0_10_16  original_T_including_depot_unload_873  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_16  arc_capacity_612  1
    load_0_10_16  free_load_conservation_831  1
    load_0_10_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_614  -30
    arc_0_11_0  depot_return_or_bypass_777  1
    arc_0_11_0  out_degree_832  1
    arc_0_11_0  original_T_including_depot_unload_873  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_614  1
    load_0_11_0  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_615  -30
    arc_0_11_1  connected_order_arc_616  -15
    arc_0_11_1  in_degree_779  1
    arc_0_11_1  out_degree_832  1
    arc_0_11_1  original_T_including_depot_unload_873  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_615  1
    load_0_11_1  segment_load_conservation_782  -1
    load_0_11_1  segment_prefix_lb_783  1
    load_0_11_1  segment_prefix_ub_784  1
    load_0_11_1  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_617  -30
    arc_0_11_2  connected_order_arc_618  -15
    arc_0_11_2  in_degree_786  1
    arc_0_11_2  out_degree_832  1
    arc_0_11_2  original_T_including_depot_unload_873  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_617  1
    load_0_11_2  segment_load_conservation_789  -1
    load_0_11_2  segment_prefix_lb_790  1
    load_0_11_2  segment_prefix_ub_791  1
    load_0_11_2  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_619  -30
    arc_0_11_3  connected_order_arc_620  -15
    arc_0_11_3  in_degree_793  1
    arc_0_11_3  out_degree_832  1
    arc_0_11_3  original_T_including_depot_unload_873  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_619  1
    load_0_11_3  segment_load_conservation_796  -1
    load_0_11_3  segment_prefix_lb_797  1
    load_0_11_3  segment_prefix_ub_798  1
    load_0_11_3  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_621  -30
    arc_0_11_4  connected_order_arc_622  -15
    arc_0_11_4  in_degree_800  1
    arc_0_11_4  out_degree_832  1
    arc_0_11_4  original_T_including_depot_unload_873  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_621  1
    load_0_11_4  segment_load_conservation_803  -1
    load_0_11_4  segment_prefix_lb_804  1
    load_0_11_4  segment_prefix_ub_805  1
    load_0_11_4  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_623  -30
    arc_0_11_5  connected_order_arc_624  -15
    arc_0_11_5  in_degree_807  1
    arc_0_11_5  out_degree_832  1
    arc_0_11_5  original_T_including_depot_unload_873  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_623  1
    load_0_11_5  segment_load_conservation_810  -1
    load_0_11_5  segment_prefix_lb_811  1
    load_0_11_5  segment_prefix_ub_812  1
    load_0_11_5  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_625  -30
    arc_0_11_6  connected_order_arc_626  -15
    arc_0_11_6  in_degree_814  1
    arc_0_11_6  out_degree_832  1
    arc_0_11_6  original_T_including_depot_unload_873  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_625  1
    load_0_11_6  segment_load_conservation_817  -1
    load_0_11_6  segment_prefix_lb_818  1
    load_0_11_6  segment_prefix_ub_819  1
    load_0_11_6  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_627  -30
    arc_0_11_9  connected_order_arc_628  -15
    arc_0_11_9  in_degree_821  1
    arc_0_11_9  out_degree_832  1
    arc_0_11_9  original_T_including_depot_unload_873  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_627  1
    load_0_11_9  free_load_conservation_825  -1
    load_0_11_9  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_629  -30
    arc_0_11_10  connected_order_arc_630  -15
    arc_0_11_10  in_degree_827  1
    arc_0_11_10  out_degree_832  1
    arc_0_11_10  original_T_including_depot_unload_873  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_629  1
    load_0_11_10  free_load_conservation_831  -1
    load_0_11_10  free_load_conservation_837  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_631  -30
    arc_0_11_12  connected_order_arc_632  -15
    arc_0_11_12  out_degree_832  1
    arc_0_11_12  in_degree_839  1
    arc_0_11_12  original_T_including_depot_unload_873  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_631  1
    load_0_11_12  free_load_conservation_837  1
    load_0_11_12  free_load_conservation_843  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_633  -30
    arc_0_11_13  connected_order_arc_634  -15
    arc_0_11_13  out_degree_832  1
    arc_0_11_13  in_degree_845  1
    arc_0_11_13  original_T_including_depot_unload_873  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_633  1
    load_0_11_13  free_load_conservation_837  1
    load_0_11_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_635  -30
    arc_0_11_14  connected_order_arc_636  -15
    arc_0_11_14  out_degree_832  1
    arc_0_11_14  in_degree_851  1
    arc_0_11_14  original_T_including_depot_unload_873  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_635  1
    load_0_11_14  free_load_conservation_837  1
    load_0_11_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_637  -30
    arc_0_11_15  connected_order_arc_638  -15
    arc_0_11_15  out_degree_832  1
    arc_0_11_15  in_degree_857  1
    arc_0_11_15  original_T_including_depot_unload_873  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_637  1
    load_0_11_15  free_load_conservation_837  1
    load_0_11_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_639  -30
    arc_0_11_16  connected_order_arc_640  -15
    arc_0_11_16  out_degree_832  1
    arc_0_11_16  in_degree_863  1
    arc_0_11_16  original_T_including_depot_unload_873  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_639  1
    load_0_11_16  free_load_conservation_837  1
    load_0_11_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_641  -30
    arc_0_12_0  depot_return_or_bypass_777  1
    arc_0_12_0  out_degree_838  1
    arc_0_12_0  original_T_including_depot_unload_873  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_641  1
    load_0_12_0  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_642  -30
    arc_0_12_1  connected_order_arc_643  -15
    arc_0_12_1  in_degree_779  1
    arc_0_12_1  out_degree_838  1
    arc_0_12_1  original_T_including_depot_unload_873  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_642  1
    load_0_12_1  segment_load_conservation_782  -1
    load_0_12_1  segment_prefix_lb_783  1
    load_0_12_1  segment_prefix_ub_784  1
    load_0_12_1  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_644  -30
    arc_0_12_2  connected_order_arc_645  -15
    arc_0_12_2  in_degree_786  1
    arc_0_12_2  out_degree_838  1
    arc_0_12_2  original_T_including_depot_unload_873  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_644  1
    load_0_12_2  segment_load_conservation_789  -1
    load_0_12_2  segment_prefix_lb_790  1
    load_0_12_2  segment_prefix_ub_791  1
    load_0_12_2  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_646  -30
    arc_0_12_3  connected_order_arc_647  -15
    arc_0_12_3  in_degree_793  1
    arc_0_12_3  out_degree_838  1
    arc_0_12_3  original_T_including_depot_unload_873  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_646  1
    load_0_12_3  segment_load_conservation_796  -1
    load_0_12_3  segment_prefix_lb_797  1
    load_0_12_3  segment_prefix_ub_798  1
    load_0_12_3  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_648  -30
    arc_0_12_4  connected_order_arc_649  -15
    arc_0_12_4  in_degree_800  1
    arc_0_12_4  out_degree_838  1
    arc_0_12_4  original_T_including_depot_unload_873  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_648  1
    load_0_12_4  segment_load_conservation_803  -1
    load_0_12_4  segment_prefix_lb_804  1
    load_0_12_4  segment_prefix_ub_805  1
    load_0_12_4  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_650  -30
    arc_0_12_5  connected_order_arc_651  -15
    arc_0_12_5  in_degree_807  1
    arc_0_12_5  out_degree_838  1
    arc_0_12_5  original_T_including_depot_unload_873  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_650  1
    load_0_12_5  segment_load_conservation_810  -1
    load_0_12_5  segment_prefix_lb_811  1
    load_0_12_5  segment_prefix_ub_812  1
    load_0_12_5  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_652  -30
    arc_0_12_6  connected_order_arc_653  -15
    arc_0_12_6  in_degree_814  1
    arc_0_12_6  out_degree_838  1
    arc_0_12_6  original_T_including_depot_unload_873  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_652  1
    load_0_12_6  segment_load_conservation_817  -1
    load_0_12_6  segment_prefix_lb_818  1
    load_0_12_6  segment_prefix_ub_819  1
    load_0_12_6  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_654  -30
    arc_0_12_9  connected_order_arc_655  -15
    arc_0_12_9  in_degree_821  1
    arc_0_12_9  out_degree_838  1
    arc_0_12_9  original_T_including_depot_unload_873  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_654  1
    load_0_12_9  free_load_conservation_825  -1
    load_0_12_9  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_656  -30
    arc_0_12_10  connected_order_arc_657  -15
    arc_0_12_10  in_degree_827  1
    arc_0_12_10  out_degree_838  1
    arc_0_12_10  original_T_including_depot_unload_873  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_656  1
    load_0_12_10  free_load_conservation_831  -1
    load_0_12_10  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_658  -30
    arc_0_12_11  connected_order_arc_659  -15
    arc_0_12_11  in_degree_833  1
    arc_0_12_11  out_degree_838  1
    arc_0_12_11  original_T_including_depot_unload_873  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_658  1
    load_0_12_11  free_load_conservation_837  -1
    load_0_12_11  free_load_conservation_843  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_660  -30
    arc_0_12_13  connected_order_arc_661  -15
    arc_0_12_13  out_degree_838  1
    arc_0_12_13  in_degree_845  1
    arc_0_12_13  original_T_including_depot_unload_873  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_660  1
    load_0_12_13  free_load_conservation_843  1
    load_0_12_13  free_load_conservation_849  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_662  -30
    arc_0_12_14  connected_order_arc_663  -15
    arc_0_12_14  out_degree_838  1
    arc_0_12_14  in_degree_851  1
    arc_0_12_14  original_T_including_depot_unload_873  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_662  1
    load_0_12_14  free_load_conservation_843  1
    load_0_12_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_664  -30
    arc_0_12_15  connected_order_arc_665  -15
    arc_0_12_15  out_degree_838  1
    arc_0_12_15  in_degree_857  1
    arc_0_12_15  original_T_including_depot_unload_873  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_664  1
    load_0_12_15  free_load_conservation_843  1
    load_0_12_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_666  -30
    arc_0_12_16  connected_order_arc_667  -15
    arc_0_12_16  out_degree_838  1
    arc_0_12_16  in_degree_863  1
    arc_0_12_16  original_T_including_depot_unload_873  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_666  1
    load_0_12_16  free_load_conservation_843  1
    load_0_12_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_668  -30
    arc_0_13_0  depot_return_or_bypass_777  1
    arc_0_13_0  out_degree_844  1
    arc_0_13_0  original_T_including_depot_unload_873  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_668  1
    load_0_13_0  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_669  -30
    arc_0_13_1  connected_order_arc_670  -15
    arc_0_13_1  in_degree_779  1
    arc_0_13_1  out_degree_844  1
    arc_0_13_1  original_T_including_depot_unload_873  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_669  1
    load_0_13_1  segment_load_conservation_782  -1
    load_0_13_1  segment_prefix_lb_783  1
    load_0_13_1  segment_prefix_ub_784  1
    load_0_13_1  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_671  -30
    arc_0_13_2  connected_order_arc_672  -15
    arc_0_13_2  in_degree_786  1
    arc_0_13_2  out_degree_844  1
    arc_0_13_2  original_T_including_depot_unload_873  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_671  1
    load_0_13_2  segment_load_conservation_789  -1
    load_0_13_2  segment_prefix_lb_790  1
    load_0_13_2  segment_prefix_ub_791  1
    load_0_13_2  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_673  -30
    arc_0_13_3  connected_order_arc_674  -15
    arc_0_13_3  in_degree_793  1
    arc_0_13_3  out_degree_844  1
    arc_0_13_3  original_T_including_depot_unload_873  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_673  1
    load_0_13_3  segment_load_conservation_796  -1
    load_0_13_3  segment_prefix_lb_797  1
    load_0_13_3  segment_prefix_ub_798  1
    load_0_13_3  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_675  -30
    arc_0_13_4  connected_order_arc_676  -15
    arc_0_13_4  in_degree_800  1
    arc_0_13_4  out_degree_844  1
    arc_0_13_4  original_T_including_depot_unload_873  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_675  1
    load_0_13_4  segment_load_conservation_803  -1
    load_0_13_4  segment_prefix_lb_804  1
    load_0_13_4  segment_prefix_ub_805  1
    load_0_13_4  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_677  -30
    arc_0_13_5  connected_order_arc_678  -15
    arc_0_13_5  in_degree_807  1
    arc_0_13_5  out_degree_844  1
    arc_0_13_5  original_T_including_depot_unload_873  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_677  1
    load_0_13_5  segment_load_conservation_810  -1
    load_0_13_5  segment_prefix_lb_811  1
    load_0_13_5  segment_prefix_ub_812  1
    load_0_13_5  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_679  -30
    arc_0_13_6  connected_order_arc_680  -15
    arc_0_13_6  in_degree_814  1
    arc_0_13_6  out_degree_844  1
    arc_0_13_6  original_T_including_depot_unload_873  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_679  1
    load_0_13_6  segment_load_conservation_817  -1
    load_0_13_6  segment_prefix_lb_818  1
    load_0_13_6  segment_prefix_ub_819  1
    load_0_13_6  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_681  -30
    arc_0_13_9  connected_order_arc_682  -15
    arc_0_13_9  in_degree_821  1
    arc_0_13_9  out_degree_844  1
    arc_0_13_9  original_T_including_depot_unload_873  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_681  1
    load_0_13_9  free_load_conservation_825  -1
    load_0_13_9  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_683  -30
    arc_0_13_10  connected_order_arc_684  -15
    arc_0_13_10  in_degree_827  1
    arc_0_13_10  out_degree_844  1
    arc_0_13_10  original_T_including_depot_unload_873  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_683  1
    load_0_13_10  free_load_conservation_831  -1
    load_0_13_10  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_685  -30
    arc_0_13_11  connected_order_arc_686  -15
    arc_0_13_11  in_degree_833  1
    arc_0_13_11  out_degree_844  1
    arc_0_13_11  original_T_including_depot_unload_873  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_685  1
    load_0_13_11  free_load_conservation_837  -1
    load_0_13_11  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_687  -30
    arc_0_13_12  connected_order_arc_688  -15
    arc_0_13_12  in_degree_839  1
    arc_0_13_12  out_degree_844  1
    arc_0_13_12  original_T_including_depot_unload_873  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_687  1
    load_0_13_12  free_load_conservation_843  -1
    load_0_13_12  free_load_conservation_849  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_689  -30
    arc_0_13_14  connected_order_arc_690  -15
    arc_0_13_14  out_degree_844  1
    arc_0_13_14  in_degree_851  1
    arc_0_13_14  original_T_including_depot_unload_873  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_689  1
    load_0_13_14  free_load_conservation_849  1
    load_0_13_14  free_load_conservation_855  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_691  -30
    arc_0_13_15  connected_order_arc_692  -15
    arc_0_13_15  out_degree_844  1
    arc_0_13_15  in_degree_857  1
    arc_0_13_15  original_T_including_depot_unload_873  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_691  1
    load_0_13_15  free_load_conservation_849  1
    load_0_13_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_693  -30
    arc_0_13_16  connected_order_arc_694  -15
    arc_0_13_16  out_degree_844  1
    arc_0_13_16  in_degree_863  1
    arc_0_13_16  original_T_including_depot_unload_873  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_693  1
    load_0_13_16  free_load_conservation_849  1
    load_0_13_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_695  -30
    arc_0_14_0  depot_return_or_bypass_777  1
    arc_0_14_0  out_degree_850  1
    arc_0_14_0  original_T_including_depot_unload_873  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_695  1
    load_0_14_0  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_696  -30
    arc_0_14_1  connected_order_arc_697  -15
    arc_0_14_1  in_degree_779  1
    arc_0_14_1  out_degree_850  1
    arc_0_14_1  original_T_including_depot_unload_873  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_696  1
    load_0_14_1  segment_load_conservation_782  -1
    load_0_14_1  segment_prefix_lb_783  1
    load_0_14_1  segment_prefix_ub_784  1
    load_0_14_1  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_698  -30
    arc_0_14_2  connected_order_arc_699  -15
    arc_0_14_2  in_degree_786  1
    arc_0_14_2  out_degree_850  1
    arc_0_14_2  original_T_including_depot_unload_873  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_698  1
    load_0_14_2  segment_load_conservation_789  -1
    load_0_14_2  segment_prefix_lb_790  1
    load_0_14_2  segment_prefix_ub_791  1
    load_0_14_2  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_700  -30
    arc_0_14_3  connected_order_arc_701  -15
    arc_0_14_3  in_degree_793  1
    arc_0_14_3  out_degree_850  1
    arc_0_14_3  original_T_including_depot_unload_873  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_700  1
    load_0_14_3  segment_load_conservation_796  -1
    load_0_14_3  segment_prefix_lb_797  1
    load_0_14_3  segment_prefix_ub_798  1
    load_0_14_3  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_702  -30
    arc_0_14_4  connected_order_arc_703  -15
    arc_0_14_4  in_degree_800  1
    arc_0_14_4  out_degree_850  1
    arc_0_14_4  original_T_including_depot_unload_873  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_702  1
    load_0_14_4  segment_load_conservation_803  -1
    load_0_14_4  segment_prefix_lb_804  1
    load_0_14_4  segment_prefix_ub_805  1
    load_0_14_4  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_704  -30
    arc_0_14_5  connected_order_arc_705  -15
    arc_0_14_5  in_degree_807  1
    arc_0_14_5  out_degree_850  1
    arc_0_14_5  original_T_including_depot_unload_873  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_704  1
    load_0_14_5  segment_load_conservation_810  -1
    load_0_14_5  segment_prefix_lb_811  1
    load_0_14_5  segment_prefix_ub_812  1
    load_0_14_5  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_706  -30
    arc_0_14_6  connected_order_arc_707  -15
    arc_0_14_6  in_degree_814  1
    arc_0_14_6  out_degree_850  1
    arc_0_14_6  original_T_including_depot_unload_873  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_706  1
    load_0_14_6  segment_load_conservation_817  -1
    load_0_14_6  segment_prefix_lb_818  1
    load_0_14_6  segment_prefix_ub_819  1
    load_0_14_6  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_708  -30
    arc_0_14_9  connected_order_arc_709  -15
    arc_0_14_9  in_degree_821  1
    arc_0_14_9  out_degree_850  1
    arc_0_14_9  original_T_including_depot_unload_873  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_708  1
    load_0_14_9  free_load_conservation_825  -1
    load_0_14_9  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_710  -30
    arc_0_14_10  connected_order_arc_711  -15
    arc_0_14_10  in_degree_827  1
    arc_0_14_10  out_degree_850  1
    arc_0_14_10  original_T_including_depot_unload_873  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_710  1
    load_0_14_10  free_load_conservation_831  -1
    load_0_14_10  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_712  -30
    arc_0_14_11  connected_order_arc_713  -15
    arc_0_14_11  in_degree_833  1
    arc_0_14_11  out_degree_850  1
    arc_0_14_11  original_T_including_depot_unload_873  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_712  1
    load_0_14_11  free_load_conservation_837  -1
    load_0_14_11  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_714  -30
    arc_0_14_12  connected_order_arc_715  -15
    arc_0_14_12  in_degree_839  1
    arc_0_14_12  out_degree_850  1
    arc_0_14_12  original_T_including_depot_unload_873  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_714  1
    load_0_14_12  free_load_conservation_843  -1
    load_0_14_12  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_716  -30
    arc_0_14_13  connected_order_arc_717  -15
    arc_0_14_13  in_degree_845  1
    arc_0_14_13  out_degree_850  1
    arc_0_14_13  original_T_including_depot_unload_873  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_716  1
    load_0_14_13  free_load_conservation_849  -1
    load_0_14_13  free_load_conservation_855  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_718  -30
    arc_0_14_15  connected_order_arc_719  -15
    arc_0_14_15  out_degree_850  1
    arc_0_14_15  in_degree_857  1
    arc_0_14_15  original_T_including_depot_unload_873  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_718  1
    load_0_14_15  free_load_conservation_855  1
    load_0_14_15  free_load_conservation_861  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_720  -30
    arc_0_14_16  connected_order_arc_721  -15
    arc_0_14_16  out_degree_850  1
    arc_0_14_16  in_degree_863  1
    arc_0_14_16  original_T_including_depot_unload_873  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_720  1
    load_0_14_16  free_load_conservation_855  1
    load_0_14_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_722  -30
    arc_0_15_0  depot_return_or_bypass_777  1
    arc_0_15_0  out_degree_856  1
    arc_0_15_0  original_T_including_depot_unload_873  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_722  1
    load_0_15_0  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_723  -30
    arc_0_15_1  connected_order_arc_724  -15
    arc_0_15_1  in_degree_779  1
    arc_0_15_1  out_degree_856  1
    arc_0_15_1  original_T_including_depot_unload_873  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_723  1
    load_0_15_1  segment_load_conservation_782  -1
    load_0_15_1  segment_prefix_lb_783  1
    load_0_15_1  segment_prefix_ub_784  1
    load_0_15_1  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_725  -30
    arc_0_15_2  connected_order_arc_726  -15
    arc_0_15_2  in_degree_786  1
    arc_0_15_2  out_degree_856  1
    arc_0_15_2  original_T_including_depot_unload_873  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_725  1
    load_0_15_2  segment_load_conservation_789  -1
    load_0_15_2  segment_prefix_lb_790  1
    load_0_15_2  segment_prefix_ub_791  1
    load_0_15_2  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_727  -30
    arc_0_15_3  connected_order_arc_728  -15
    arc_0_15_3  in_degree_793  1
    arc_0_15_3  out_degree_856  1
    arc_0_15_3  original_T_including_depot_unload_873  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_727  1
    load_0_15_3  segment_load_conservation_796  -1
    load_0_15_3  segment_prefix_lb_797  1
    load_0_15_3  segment_prefix_ub_798  1
    load_0_15_3  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_729  -30
    arc_0_15_4  connected_order_arc_730  -15
    arc_0_15_4  in_degree_800  1
    arc_0_15_4  out_degree_856  1
    arc_0_15_4  original_T_including_depot_unload_873  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_729  1
    load_0_15_4  segment_load_conservation_803  -1
    load_0_15_4  segment_prefix_lb_804  1
    load_0_15_4  segment_prefix_ub_805  1
    load_0_15_4  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_731  -30
    arc_0_15_5  connected_order_arc_732  -15
    arc_0_15_5  in_degree_807  1
    arc_0_15_5  out_degree_856  1
    arc_0_15_5  original_T_including_depot_unload_873  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_731  1
    load_0_15_5  segment_load_conservation_810  -1
    load_0_15_5  segment_prefix_lb_811  1
    load_0_15_5  segment_prefix_ub_812  1
    load_0_15_5  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_733  -30
    arc_0_15_6  connected_order_arc_734  -15
    arc_0_15_6  in_degree_814  1
    arc_0_15_6  out_degree_856  1
    arc_0_15_6  original_T_including_depot_unload_873  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_733  1
    load_0_15_6  segment_load_conservation_817  -1
    load_0_15_6  segment_prefix_lb_818  1
    load_0_15_6  segment_prefix_ub_819  1
    load_0_15_6  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_735  -30
    arc_0_15_9  connected_order_arc_736  -15
    arc_0_15_9  in_degree_821  1
    arc_0_15_9  out_degree_856  1
    arc_0_15_9  original_T_including_depot_unload_873  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_735  1
    load_0_15_9  free_load_conservation_825  -1
    load_0_15_9  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_737  -30
    arc_0_15_10  connected_order_arc_738  -15
    arc_0_15_10  in_degree_827  1
    arc_0_15_10  out_degree_856  1
    arc_0_15_10  original_T_including_depot_unload_873  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_737  1
    load_0_15_10  free_load_conservation_831  -1
    load_0_15_10  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_739  -30
    arc_0_15_11  connected_order_arc_740  -15
    arc_0_15_11  in_degree_833  1
    arc_0_15_11  out_degree_856  1
    arc_0_15_11  original_T_including_depot_unload_873  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_739  1
    load_0_15_11  free_load_conservation_837  -1
    load_0_15_11  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_741  -30
    arc_0_15_12  connected_order_arc_742  -15
    arc_0_15_12  in_degree_839  1
    arc_0_15_12  out_degree_856  1
    arc_0_15_12  original_T_including_depot_unload_873  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_741  1
    load_0_15_12  free_load_conservation_843  -1
    load_0_15_12  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_743  -30
    arc_0_15_13  connected_order_arc_744  -15
    arc_0_15_13  in_degree_845  1
    arc_0_15_13  out_degree_856  1
    arc_0_15_13  original_T_including_depot_unload_873  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_743  1
    load_0_15_13  free_load_conservation_849  -1
    load_0_15_13  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_745  -30
    arc_0_15_14  connected_order_arc_746  -15
    arc_0_15_14  in_degree_851  1
    arc_0_15_14  out_degree_856  1
    arc_0_15_14  original_T_including_depot_unload_873  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_745  1
    load_0_15_14  free_load_conservation_855  -1
    load_0_15_14  free_load_conservation_861  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_747  -30
    arc_0_15_16  connected_order_arc_748  -15
    arc_0_15_16  out_degree_856  1
    arc_0_15_16  in_degree_863  1
    arc_0_15_16  original_T_including_depot_unload_873  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_747  1
    load_0_15_16  free_load_conservation_861  1
    load_0_15_16  free_load_conservation_867  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_749  -30
    arc_0_16_0  depot_return_or_bypass_777  1
    arc_0_16_0  out_degree_862  1
    arc_0_16_0  original_T_including_depot_unload_873  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_749  1
    load_0_16_0  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_750  -30
    arc_0_16_1  connected_order_arc_751  -15
    arc_0_16_1  in_degree_779  1
    arc_0_16_1  out_degree_862  1
    arc_0_16_1  original_T_including_depot_unload_873  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_750  1
    load_0_16_1  segment_load_conservation_782  -1
    load_0_16_1  segment_prefix_lb_783  1
    load_0_16_1  segment_prefix_ub_784  1
    load_0_16_1  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_752  -30
    arc_0_16_2  connected_order_arc_753  -15
    arc_0_16_2  in_degree_786  1
    arc_0_16_2  out_degree_862  1
    arc_0_16_2  original_T_including_depot_unload_873  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_752  1
    load_0_16_2  segment_load_conservation_789  -1
    load_0_16_2  segment_prefix_lb_790  1
    load_0_16_2  segment_prefix_ub_791  1
    load_0_16_2  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_754  -30
    arc_0_16_3  connected_order_arc_755  -15
    arc_0_16_3  in_degree_793  1
    arc_0_16_3  out_degree_862  1
    arc_0_16_3  original_T_including_depot_unload_873  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_754  1
    load_0_16_3  segment_load_conservation_796  -1
    load_0_16_3  segment_prefix_lb_797  1
    load_0_16_3  segment_prefix_ub_798  1
    load_0_16_3  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_756  -30
    arc_0_16_4  connected_order_arc_757  -15
    arc_0_16_4  in_degree_800  1
    arc_0_16_4  out_degree_862  1
    arc_0_16_4  original_T_including_depot_unload_873  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_756  1
    load_0_16_4  segment_load_conservation_803  -1
    load_0_16_4  segment_prefix_lb_804  1
    load_0_16_4  segment_prefix_ub_805  1
    load_0_16_4  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_758  -30
    arc_0_16_5  connected_order_arc_759  -15
    arc_0_16_5  in_degree_807  1
    arc_0_16_5  out_degree_862  1
    arc_0_16_5  original_T_including_depot_unload_873  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_758  1
    load_0_16_5  segment_load_conservation_810  -1
    load_0_16_5  segment_prefix_lb_811  1
    load_0_16_5  segment_prefix_ub_812  1
    load_0_16_5  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_760  -30
    arc_0_16_6  connected_order_arc_761  -15
    arc_0_16_6  in_degree_814  1
    arc_0_16_6  out_degree_862  1
    arc_0_16_6  original_T_including_depot_unload_873  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_760  1
    load_0_16_6  segment_load_conservation_817  -1
    load_0_16_6  segment_prefix_lb_818  1
    load_0_16_6  segment_prefix_ub_819  1
    load_0_16_6  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_9  arc_capacity_762  -30
    arc_0_16_9  connected_order_arc_763  -15
    arc_0_16_9  in_degree_821  1
    arc_0_16_9  out_degree_862  1
    arc_0_16_9  original_T_including_depot_unload_873  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_9  arc_capacity_762  1
    load_0_16_9  free_load_conservation_825  -1
    load_0_16_9  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_10  arc_capacity_764  -30
    arc_0_16_10  connected_order_arc_765  -15
    arc_0_16_10  in_degree_827  1
    arc_0_16_10  out_degree_862  1
    arc_0_16_10  original_T_including_depot_unload_873  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_10  arc_capacity_764  1
    load_0_16_10  free_load_conservation_831  -1
    load_0_16_10  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_766  -30
    arc_0_16_11  connected_order_arc_767  -15
    arc_0_16_11  in_degree_833  1
    arc_0_16_11  out_degree_862  1
    arc_0_16_11  original_T_including_depot_unload_873  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_766  1
    load_0_16_11  free_load_conservation_837  -1
    load_0_16_11  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_768  -30
    arc_0_16_12  connected_order_arc_769  -15
    arc_0_16_12  in_degree_839  1
    arc_0_16_12  out_degree_862  1
    arc_0_16_12  original_T_including_depot_unload_873  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_768  1
    load_0_16_12  free_load_conservation_843  -1
    load_0_16_12  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_770  -30
    arc_0_16_13  connected_order_arc_771  -15
    arc_0_16_13  in_degree_845  1
    arc_0_16_13  out_degree_862  1
    arc_0_16_13  original_T_including_depot_unload_873  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_770  1
    load_0_16_13  free_load_conservation_849  -1
    load_0_16_13  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_772  -30
    arc_0_16_14  connected_order_arc_773  -15
    arc_0_16_14  in_degree_851  1
    arc_0_16_14  out_degree_862  1
    arc_0_16_14  original_T_including_depot_unload_873  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_772  1
    load_0_16_14  free_load_conservation_855  -1
    load_0_16_14  free_load_conservation_867  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_774  -30
    arc_0_16_15  connected_order_arc_775  -15
    arc_0_16_15  in_degree_857  1
    arc_0_16_15  out_degree_862  1
    arc_0_16_15  original_T_including_depot_unload_873  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_774  1
    load_0_16_15  free_load_conservation_861  -1
    load_0_16_15  free_load_conservation_867  1
    visit_1_7  out_degree_1077  -1
    visit_1_7  in_degree_1078  -1
    visit_1_7  order_active_lb_1079  -1
    visit_1_7  order_active_ub_1080  -10
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_891  -1
    order_1_7  connected_order_arc_893  -1
    order_1_7  connected_order_arc_895  -1
    order_1_7  connected_order_arc_897  -1
    order_1_7  connected_order_arc_899  -1
    order_1_7  connected_order_arc_901  -1
    order_1_7  connected_order_arc_903  -1
    order_1_7  connected_order_arc_906  1
    order_1_7  connected_order_arc_925  1
    order_1_7  connected_order_arc_944  1
    order_1_7  connected_order_arc_963  1
    order_1_7  connected_order_arc_982  1
    order_1_7  connected_order_arc_1001  1
    order_1_7  connected_order_arc_1020  1
    order_1_7  connected_order_arc_1039  1
    order_1_7  connected_order_arc_1058  1
    order_1_7  order_active_lb_1079  1
    order_1_7  order_active_ub_1080  1
    order_1_7  fixed_segment_relative_order_1139  -1
    visit_1_8  out_degree_1084  -1
    visit_1_8  in_degree_1085  -1
    visit_1_8  order_active_lb_1086  -1
    visit_1_8  order_active_ub_1087  -10
    order_1_8  connected_order_arc_887  1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_914  -1
    order_1_8  connected_order_arc_916  -1
    order_1_8  connected_order_arc_918  -1
    order_1_8  connected_order_arc_920  -1
    order_1_8  connected_order_arc_922  -1
    order_1_8  connected_order_arc_927  1
    order_1_8  connected_order_arc_946  1
    order_1_8  connected_order_arc_965  1
    order_1_8  connected_order_arc_984  1
    order_1_8  connected_order_arc_1003  1
    order_1_8  connected_order_arc_1022  1
    order_1_8  connected_order_arc_1041  1
    order_1_8  connected_order_arc_1060  1
    order_1_8  order_active_lb_1086  1
    order_1_8  order_active_ub_1087  1
    order_1_8  fixed_segment_relative_order_1139  1
    visit_1_9  out_degree_1091  -1
    visit_1_9  in_degree_1092  -1
    visit_1_9  order_active_lb_1093  -1
    visit_1_9  order_active_ub_1094  -10
    visit_1_9  service_visit_def_1095  -1
    order_1_9  connected_order_arc_889  1
    order_1_9  connected_order_arc_908  1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_927  -1
    order_1_9  connected_order_arc_929  -1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_933  -1
    order_1_9  connected_order_arc_935  -1
    order_1_9  connected_order_arc_937  -1
    order_1_9  connected_order_arc_939  -1
    order_1_9  connected_order_arc_941  -1
    order_1_9  connected_order_arc_948  1
    order_1_9  connected_order_arc_967  1
    order_1_9  connected_order_arc_986  1
    order_1_9  connected_order_arc_1005  1
    order_1_9  connected_order_arc_1024  1
    order_1_9  connected_order_arc_1043  1
    order_1_9  connected_order_arc_1062  1
    order_1_9  order_active_lb_1093  1
    order_1_9  order_active_ub_1094  1
    visit_1_10  out_degree_1097  -1
    visit_1_10  in_degree_1098  -1
    visit_1_10  order_active_lb_1099  -1
    visit_1_10  order_active_ub_1100  -10
    visit_1_10  service_visit_def_1101  -1
    order_1_10  connected_order_arc_891  1
    order_1_10  connected_order_arc_910  1
    order_1_10  connected_order_arc_929  1
    order_1_10  connected_order_arc_944  -1
    order_1_10  connected_order_arc_946  -1
    order_1_10  connected_order_arc_948  -1
    order_1_10  connected_order_arc_950  -1
    order_1_10  connected_order_arc_952  -1
    order_1_10  connected_order_arc_954  -1
    order_1_10  connected_order_arc_956  -1
    order_1_10  connected_order_arc_958  -1
    order_1_10  connected_order_arc_960  -1
    order_1_10  connected_order_arc_969  1
    order_1_10  connected_order_arc_988  1
    order_1_10  connected_order_arc_1007  1
    order_1_10  connected_order_arc_1026  1
    order_1_10  connected_order_arc_1045  1
    order_1_10  connected_order_arc_1064  1
    order_1_10  order_active_lb_1099  1
    order_1_10  order_active_ub_1100  1
    visit_1_11  out_degree_1103  -1
    visit_1_11  in_degree_1104  -1
    visit_1_11  order_active_lb_1105  -1
    visit_1_11  order_active_ub_1106  -10
    visit_1_11  service_visit_def_1107  -1
    order_1_11  connected_order_arc_893  1
    order_1_11  connected_order_arc_912  1
    order_1_11  connected_order_arc_931  1
    order_1_11  connected_order_arc_950  1
    order_1_11  connected_order_arc_963  -1
    order_1_11  connected_order_arc_965  -1
    order_1_11  connected_order_arc_967  -1
    order_1_11  connected_order_arc_969  -1
    order_1_11  connected_order_arc_971  -1
    order_1_11  connected_order_arc_973  -1
    order_1_11  connected_order_arc_975  -1
    order_1_11  connected_order_arc_977  -1
    order_1_11  connected_order_arc_979  -1
    order_1_11  connected_order_arc_990  1
    order_1_11  connected_order_arc_1009  1
    order_1_11  connected_order_arc_1028  1
    order_1_11  connected_order_arc_1047  1
    order_1_11  connected_order_arc_1066  1
    order_1_11  order_active_lb_1105  1
    order_1_11  order_active_ub_1106  1
    visit_1_12  out_degree_1109  -1
    visit_1_12  in_degree_1110  -1
    visit_1_12  order_active_lb_1111  -1
    visit_1_12  order_active_ub_1112  -10
    visit_1_12  service_visit_def_1113  -1
    order_1_12  connected_order_arc_895  1
    order_1_12  connected_order_arc_914  1
    order_1_12  connected_order_arc_933  1
    order_1_12  connected_order_arc_952  1
    order_1_12  connected_order_arc_971  1
    order_1_12  connected_order_arc_982  -1
    order_1_12  connected_order_arc_984  -1
    order_1_12  connected_order_arc_986  -1
    order_1_12  connected_order_arc_988  -1
    order_1_12  connected_order_arc_990  -1
    order_1_12  connected_order_arc_992  -1
    order_1_12  connected_order_arc_994  -1
    order_1_12  connected_order_arc_996  -1
    order_1_12  connected_order_arc_998  -1
    order_1_12  connected_order_arc_1011  1
    order_1_12  connected_order_arc_1030  1
    order_1_12  connected_order_arc_1049  1
    order_1_12  connected_order_arc_1068  1
    order_1_12  order_active_lb_1111  1
    order_1_12  order_active_ub_1112  1
    visit_1_13  out_degree_1115  -1
    visit_1_13  in_degree_1116  -1
    visit_1_13  order_active_lb_1117  -1
    visit_1_13  order_active_ub_1118  -10
    visit_1_13  service_visit_def_1119  -1
    order_1_13  connected_order_arc_897  1
    order_1_13  connected_order_arc_916  1
    order_1_13  connected_order_arc_935  1
    order_1_13  connected_order_arc_954  1
    order_1_13  connected_order_arc_973  1
    order_1_13  connected_order_arc_992  1
    order_1_13  connected_order_arc_1001  -1
    order_1_13  connected_order_arc_1003  -1
    order_1_13  connected_order_arc_1005  -1
    order_1_13  connected_order_arc_1007  -1
    order_1_13  connected_order_arc_1009  -1
    order_1_13  connected_order_arc_1011  -1
    order_1_13  connected_order_arc_1013  -1
    order_1_13  connected_order_arc_1015  -1
    order_1_13  connected_order_arc_1017  -1
    order_1_13  connected_order_arc_1032  1
    order_1_13  connected_order_arc_1051  1
    order_1_13  connected_order_arc_1070  1
    order_1_13  order_active_lb_1117  1
    order_1_13  order_active_ub_1118  1
    visit_1_14  out_degree_1121  -1
    visit_1_14  in_degree_1122  -1
    visit_1_14  order_active_lb_1123  -1
    visit_1_14  order_active_ub_1124  -10
    visit_1_14  service_visit_def_1125  -1
    order_1_14  connected_order_arc_899  1
    order_1_14  connected_order_arc_918  1
    order_1_14  connected_order_arc_937  1
    order_1_14  connected_order_arc_956  1
    order_1_14  connected_order_arc_975  1
    order_1_14  connected_order_arc_994  1
    order_1_14  connected_order_arc_1013  1
    order_1_14  connected_order_arc_1020  -1
    order_1_14  connected_order_arc_1022  -1
    order_1_14  connected_order_arc_1024  -1
    order_1_14  connected_order_arc_1026  -1
    order_1_14  connected_order_arc_1028  -1
    order_1_14  connected_order_arc_1030  -1
    order_1_14  connected_order_arc_1032  -1
    order_1_14  connected_order_arc_1034  -1
    order_1_14  connected_order_arc_1036  -1
    order_1_14  connected_order_arc_1053  1
    order_1_14  connected_order_arc_1072  1
    order_1_14  order_active_lb_1123  1
    order_1_14  order_active_ub_1124  1
    visit_1_15  out_degree_1127  -1
    visit_1_15  in_degree_1128  -1
    visit_1_15  order_active_lb_1129  -1
    visit_1_15  order_active_ub_1130  -10
    visit_1_15  service_visit_def_1131  -1
    order_1_15  connected_order_arc_901  1
    order_1_15  connected_order_arc_920  1
    order_1_15  connected_order_arc_939  1
    order_1_15  connected_order_arc_958  1
    order_1_15  connected_order_arc_977  1
    order_1_15  connected_order_arc_996  1
    order_1_15  connected_order_arc_1015  1
    order_1_15  connected_order_arc_1034  1
    order_1_15  connected_order_arc_1039  -1
    order_1_15  connected_order_arc_1041  -1
    order_1_15  connected_order_arc_1043  -1
    order_1_15  connected_order_arc_1045  -1
    order_1_15  connected_order_arc_1047  -1
    order_1_15  connected_order_arc_1049  -1
    order_1_15  connected_order_arc_1051  -1
    order_1_15  connected_order_arc_1053  -1
    order_1_15  connected_order_arc_1055  -1
    order_1_15  connected_order_arc_1074  1
    order_1_15  order_active_lb_1129  1
    order_1_15  order_active_ub_1130  1
    visit_1_16  out_degree_1133  -1
    visit_1_16  in_degree_1134  -1
    visit_1_16  order_active_lb_1135  -1
    visit_1_16  order_active_ub_1136  -10
    visit_1_16  service_visit_def_1137  -1
    order_1_16  connected_order_arc_903  1
    order_1_16  connected_order_arc_922  1
    order_1_16  connected_order_arc_941  1
    order_1_16  connected_order_arc_960  1
    order_1_16  connected_order_arc_979  1
    order_1_16  connected_order_arc_998  1
    order_1_16  connected_order_arc_1017  1
    order_1_16  connected_order_arc_1036  1
    order_1_16  connected_order_arc_1055  1
    order_1_16  connected_order_arc_1058  -1
    order_1_16  connected_order_arc_1060  -1
    order_1_16  connected_order_arc_1062  -1
    order_1_16  connected_order_arc_1064  -1
    order_1_16  connected_order_arc_1066  -1
    order_1_16  connected_order_arc_1068  -1
    order_1_16  connected_order_arc_1070  -1
    order_1_16  connected_order_arc_1072  -1
    order_1_16  connected_order_arc_1074  -1
    order_1_16  order_active_lb_1135  1
    order_1_16  order_active_ub_1136  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_874  -30
    arc_1_0_0  depot_departure_or_bypass_1075  1
    arc_1_0_0  depot_return_or_bypass_1076  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_875  -30
    arc_1_0_7  depot_departure_or_bypass_1075  1
    arc_1_0_7  in_degree_1078  1
    arc_1_0_7  original_T_including_depot_unload_1140  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_875  1
    load_1_0_7  segment_load_conservation_1081  -1
    load_1_0_7  segment_prefix_lb_1082  1
    load_1_0_7  segment_prefix_ub_1083  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_876  -30
    arc_1_0_8  depot_departure_or_bypass_1075  1
    arc_1_0_8  in_degree_1085  1
    arc_1_0_8  original_T_including_depot_unload_1140  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_876  1
    load_1_0_8  segment_load_conservation_1088  -1
    load_1_0_8  segment_prefix_lb_1089  1
    load_1_0_8  segment_prefix_ub_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_877  -30
    arc_1_0_9  depot_departure_or_bypass_1075  1
    arc_1_0_9  in_degree_1092  1
    arc_1_0_9  original_T_including_depot_unload_1140  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_877  1
    load_1_0_9  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_878  -30
    arc_1_0_10  depot_departure_or_bypass_1075  1
    arc_1_0_10  in_degree_1098  1
    arc_1_0_10  original_T_including_depot_unload_1140  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_878  1
    load_1_0_10  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_879  -30
    arc_1_0_11  depot_departure_or_bypass_1075  1
    arc_1_0_11  in_degree_1104  1
    arc_1_0_11  original_T_including_depot_unload_1140  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_879  1
    load_1_0_11  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_880  -30
    arc_1_0_12  depot_departure_or_bypass_1075  1
    arc_1_0_12  in_degree_1110  1
    arc_1_0_12  original_T_including_depot_unload_1140  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_880  1
    load_1_0_12  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_881  -30
    arc_1_0_13  depot_departure_or_bypass_1075  1
    arc_1_0_13  in_degree_1116  1
    arc_1_0_13  original_T_including_depot_unload_1140  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_881  1
    load_1_0_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_882  -30
    arc_1_0_14  depot_departure_or_bypass_1075  1
    arc_1_0_14  in_degree_1122  1
    arc_1_0_14  original_T_including_depot_unload_1140  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_882  1
    load_1_0_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_883  -30
    arc_1_0_15  depot_departure_or_bypass_1075  1
    arc_1_0_15  in_degree_1128  1
    arc_1_0_15  original_T_including_depot_unload_1140  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_883  1
    load_1_0_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_884  -30
    arc_1_0_16  depot_departure_or_bypass_1075  1
    arc_1_0_16  in_degree_1134  1
    arc_1_0_16  original_T_including_depot_unload_1140  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_884  1
    load_1_0_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_885  -30
    arc_1_7_0  depot_return_or_bypass_1076  1
    arc_1_7_0  out_degree_1077  1
    arc_1_7_0  original_T_including_depot_unload_1140  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_885  1
    load_1_7_0  segment_load_conservation_1081  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_886  -30
    arc_1_7_8  connected_order_arc_887  -11
    arc_1_7_8  out_degree_1077  1
    arc_1_7_8  in_degree_1085  1
    arc_1_7_8  original_T_including_depot_unload_1140  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_886  1
    load_1_7_8  segment_load_conservation_1081  1
    load_1_7_8  segment_load_conservation_1088  -1
    load_1_7_8  segment_prefix_lb_1089  1
    load_1_7_8  segment_prefix_ub_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_888  -30
    arc_1_7_9  connected_order_arc_889  -11
    arc_1_7_9  out_degree_1077  1
    arc_1_7_9  in_degree_1092  1
    arc_1_7_9  original_T_including_depot_unload_1140  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_888  1
    load_1_7_9  segment_load_conservation_1081  1
    load_1_7_9  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_890  -30
    arc_1_7_10  connected_order_arc_891  -11
    arc_1_7_10  out_degree_1077  1
    arc_1_7_10  in_degree_1098  1
    arc_1_7_10  original_T_including_depot_unload_1140  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_890  1
    load_1_7_10  segment_load_conservation_1081  1
    load_1_7_10  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_892  -30
    arc_1_7_11  connected_order_arc_893  -11
    arc_1_7_11  out_degree_1077  1
    arc_1_7_11  in_degree_1104  1
    arc_1_7_11  original_T_including_depot_unload_1140  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_892  1
    load_1_7_11  segment_load_conservation_1081  1
    load_1_7_11  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_894  -30
    arc_1_7_12  connected_order_arc_895  -11
    arc_1_7_12  out_degree_1077  1
    arc_1_7_12  in_degree_1110  1
    arc_1_7_12  original_T_including_depot_unload_1140  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_894  1
    load_1_7_12  segment_load_conservation_1081  1
    load_1_7_12  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_896  -30
    arc_1_7_13  connected_order_arc_897  -11
    arc_1_7_13  out_degree_1077  1
    arc_1_7_13  in_degree_1116  1
    arc_1_7_13  original_T_including_depot_unload_1140  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_896  1
    load_1_7_13  segment_load_conservation_1081  1
    load_1_7_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_898  -30
    arc_1_7_14  connected_order_arc_899  -11
    arc_1_7_14  out_degree_1077  1
    arc_1_7_14  in_degree_1122  1
    arc_1_7_14  original_T_including_depot_unload_1140  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_898  1
    load_1_7_14  segment_load_conservation_1081  1
    load_1_7_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_900  -30
    arc_1_7_15  connected_order_arc_901  -11
    arc_1_7_15  out_degree_1077  1
    arc_1_7_15  in_degree_1128  1
    arc_1_7_15  original_T_including_depot_unload_1140  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_900  1
    load_1_7_15  segment_load_conservation_1081  1
    load_1_7_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_902  -30
    arc_1_7_16  connected_order_arc_903  -11
    arc_1_7_16  out_degree_1077  1
    arc_1_7_16  in_degree_1134  1
    arc_1_7_16  original_T_including_depot_unload_1140  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_902  1
    load_1_7_16  segment_load_conservation_1081  1
    load_1_7_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_904  -30
    arc_1_8_0  depot_return_or_bypass_1076  1
    arc_1_8_0  out_degree_1084  1
    arc_1_8_0  original_T_including_depot_unload_1140  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_904  1
    load_1_8_0  segment_load_conservation_1088  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_905  -30
    arc_1_8_7  connected_order_arc_906  -11
    arc_1_8_7  in_degree_1078  1
    arc_1_8_7  out_degree_1084  1
    arc_1_8_7  original_T_including_depot_unload_1140  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_905  1
    load_1_8_7  segment_load_conservation_1081  -1
    load_1_8_7  segment_prefix_lb_1082  1
    load_1_8_7  segment_prefix_ub_1083  1
    load_1_8_7  segment_load_conservation_1088  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_907  -30
    arc_1_8_9  connected_order_arc_908  -11
    arc_1_8_9  out_degree_1084  1
    arc_1_8_9  in_degree_1092  1
    arc_1_8_9  original_T_including_depot_unload_1140  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_907  1
    load_1_8_9  segment_load_conservation_1088  1
    load_1_8_9  free_load_conservation_1096  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_909  -30
    arc_1_8_10  connected_order_arc_910  -11
    arc_1_8_10  out_degree_1084  1
    arc_1_8_10  in_degree_1098  1
    arc_1_8_10  original_T_including_depot_unload_1140  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_909  1
    load_1_8_10  segment_load_conservation_1088  1
    load_1_8_10  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_911  -30
    arc_1_8_11  connected_order_arc_912  -11
    arc_1_8_11  out_degree_1084  1
    arc_1_8_11  in_degree_1104  1
    arc_1_8_11  original_T_including_depot_unload_1140  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_911  1
    load_1_8_11  segment_load_conservation_1088  1
    load_1_8_11  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_913  -30
    arc_1_8_12  connected_order_arc_914  -11
    arc_1_8_12  out_degree_1084  1
    arc_1_8_12  in_degree_1110  1
    arc_1_8_12  original_T_including_depot_unload_1140  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_913  1
    load_1_8_12  segment_load_conservation_1088  1
    load_1_8_12  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_915  -30
    arc_1_8_13  connected_order_arc_916  -11
    arc_1_8_13  out_degree_1084  1
    arc_1_8_13  in_degree_1116  1
    arc_1_8_13  original_T_including_depot_unload_1140  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_915  1
    load_1_8_13  segment_load_conservation_1088  1
    load_1_8_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_917  -30
    arc_1_8_14  connected_order_arc_918  -11
    arc_1_8_14  out_degree_1084  1
    arc_1_8_14  in_degree_1122  1
    arc_1_8_14  original_T_including_depot_unload_1140  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_917  1
    load_1_8_14  segment_load_conservation_1088  1
    load_1_8_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_919  -30
    arc_1_8_15  connected_order_arc_920  -11
    arc_1_8_15  out_degree_1084  1
    arc_1_8_15  in_degree_1128  1
    arc_1_8_15  original_T_including_depot_unload_1140  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_919  1
    load_1_8_15  segment_load_conservation_1088  1
    load_1_8_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_921  -30
    arc_1_8_16  connected_order_arc_922  -11
    arc_1_8_16  out_degree_1084  1
    arc_1_8_16  in_degree_1134  1
    arc_1_8_16  original_T_including_depot_unload_1140  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_921  1
    load_1_8_16  segment_load_conservation_1088  1
    load_1_8_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_923  -30
    arc_1_9_0  depot_return_or_bypass_1076  1
    arc_1_9_0  out_degree_1091  1
    arc_1_9_0  original_T_including_depot_unload_1140  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_923  1
    load_1_9_0  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_924  -30
    arc_1_9_7  connected_order_arc_925  -11
    arc_1_9_7  in_degree_1078  1
    arc_1_9_7  out_degree_1091  1
    arc_1_9_7  original_T_including_depot_unload_1140  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_924  1
    load_1_9_7  segment_load_conservation_1081  -1
    load_1_9_7  segment_prefix_lb_1082  1
    load_1_9_7  segment_prefix_ub_1083  1
    load_1_9_7  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_926  -30
    arc_1_9_8  connected_order_arc_927  -11
    arc_1_9_8  in_degree_1085  1
    arc_1_9_8  out_degree_1091  1
    arc_1_9_8  original_T_including_depot_unload_1140  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_926  1
    load_1_9_8  segment_load_conservation_1088  -1
    load_1_9_8  segment_prefix_lb_1089  1
    load_1_9_8  segment_prefix_ub_1090  1
    load_1_9_8  free_load_conservation_1096  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_928  -30
    arc_1_9_10  connected_order_arc_929  -11
    arc_1_9_10  out_degree_1091  1
    arc_1_9_10  in_degree_1098  1
    arc_1_9_10  original_T_including_depot_unload_1140  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_928  1
    load_1_9_10  free_load_conservation_1096  1
    load_1_9_10  free_load_conservation_1102  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_930  -30
    arc_1_9_11  connected_order_arc_931  -11
    arc_1_9_11  out_degree_1091  1
    arc_1_9_11  in_degree_1104  1
    arc_1_9_11  original_T_including_depot_unload_1140  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_930  1
    load_1_9_11  free_load_conservation_1096  1
    load_1_9_11  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_932  -30
    arc_1_9_12  connected_order_arc_933  -11
    arc_1_9_12  out_degree_1091  1
    arc_1_9_12  in_degree_1110  1
    arc_1_9_12  original_T_including_depot_unload_1140  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_932  1
    load_1_9_12  free_load_conservation_1096  1
    load_1_9_12  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_934  -30
    arc_1_9_13  connected_order_arc_935  -11
    arc_1_9_13  out_degree_1091  1
    arc_1_9_13  in_degree_1116  1
    arc_1_9_13  original_T_including_depot_unload_1140  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_934  1
    load_1_9_13  free_load_conservation_1096  1
    load_1_9_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_936  -30
    arc_1_9_14  connected_order_arc_937  -11
    arc_1_9_14  out_degree_1091  1
    arc_1_9_14  in_degree_1122  1
    arc_1_9_14  original_T_including_depot_unload_1140  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_936  1
    load_1_9_14  free_load_conservation_1096  1
    load_1_9_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_938  -30
    arc_1_9_15  connected_order_arc_939  -11
    arc_1_9_15  out_degree_1091  1
    arc_1_9_15  in_degree_1128  1
    arc_1_9_15  original_T_including_depot_unload_1140  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_938  1
    load_1_9_15  free_load_conservation_1096  1
    load_1_9_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_940  -30
    arc_1_9_16  connected_order_arc_941  -11
    arc_1_9_16  out_degree_1091  1
    arc_1_9_16  in_degree_1134  1
    arc_1_9_16  original_T_including_depot_unload_1140  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_940  1
    load_1_9_16  free_load_conservation_1096  1
    load_1_9_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_942  -30
    arc_1_10_0  depot_return_or_bypass_1076  1
    arc_1_10_0  out_degree_1097  1
    arc_1_10_0  original_T_including_depot_unload_1140  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_942  1
    load_1_10_0  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_943  -30
    arc_1_10_7  connected_order_arc_944  -11
    arc_1_10_7  in_degree_1078  1
    arc_1_10_7  out_degree_1097  1
    arc_1_10_7  original_T_including_depot_unload_1140  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_943  1
    load_1_10_7  segment_load_conservation_1081  -1
    load_1_10_7  segment_prefix_lb_1082  1
    load_1_10_7  segment_prefix_ub_1083  1
    load_1_10_7  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_945  -30
    arc_1_10_8  connected_order_arc_946  -11
    arc_1_10_8  in_degree_1085  1
    arc_1_10_8  out_degree_1097  1
    arc_1_10_8  original_T_including_depot_unload_1140  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_945  1
    load_1_10_8  segment_load_conservation_1088  -1
    load_1_10_8  segment_prefix_lb_1089  1
    load_1_10_8  segment_prefix_ub_1090  1
    load_1_10_8  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_947  -30
    arc_1_10_9  connected_order_arc_948  -11
    arc_1_10_9  in_degree_1092  1
    arc_1_10_9  out_degree_1097  1
    arc_1_10_9  original_T_including_depot_unload_1140  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_947  1
    load_1_10_9  free_load_conservation_1096  -1
    load_1_10_9  free_load_conservation_1102  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_949  -30
    arc_1_10_11  connected_order_arc_950  -11
    arc_1_10_11  out_degree_1097  1
    arc_1_10_11  in_degree_1104  1
    arc_1_10_11  original_T_including_depot_unload_1140  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_949  1
    load_1_10_11  free_load_conservation_1102  1
    load_1_10_11  free_load_conservation_1108  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_951  -30
    arc_1_10_12  connected_order_arc_952  -11
    arc_1_10_12  out_degree_1097  1
    arc_1_10_12  in_degree_1110  1
    arc_1_10_12  original_T_including_depot_unload_1140  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_951  1
    load_1_10_12  free_load_conservation_1102  1
    load_1_10_12  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_953  -30
    arc_1_10_13  connected_order_arc_954  -11
    arc_1_10_13  out_degree_1097  1
    arc_1_10_13  in_degree_1116  1
    arc_1_10_13  original_T_including_depot_unload_1140  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_953  1
    load_1_10_13  free_load_conservation_1102  1
    load_1_10_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_955  -30
    arc_1_10_14  connected_order_arc_956  -11
    arc_1_10_14  out_degree_1097  1
    arc_1_10_14  in_degree_1122  1
    arc_1_10_14  original_T_including_depot_unload_1140  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_955  1
    load_1_10_14  free_load_conservation_1102  1
    load_1_10_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_957  -30
    arc_1_10_15  connected_order_arc_958  -11
    arc_1_10_15  out_degree_1097  1
    arc_1_10_15  in_degree_1128  1
    arc_1_10_15  original_T_including_depot_unload_1140  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_957  1
    load_1_10_15  free_load_conservation_1102  1
    load_1_10_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_959  -30
    arc_1_10_16  connected_order_arc_960  -11
    arc_1_10_16  out_degree_1097  1
    arc_1_10_16  in_degree_1134  1
    arc_1_10_16  original_T_including_depot_unload_1140  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_959  1
    load_1_10_16  free_load_conservation_1102  1
    load_1_10_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_961  -30
    arc_1_11_0  depot_return_or_bypass_1076  1
    arc_1_11_0  out_degree_1103  1
    arc_1_11_0  original_T_including_depot_unload_1140  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_961  1
    load_1_11_0  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_962  -30
    arc_1_11_7  connected_order_arc_963  -11
    arc_1_11_7  in_degree_1078  1
    arc_1_11_7  out_degree_1103  1
    arc_1_11_7  original_T_including_depot_unload_1140  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_962  1
    load_1_11_7  segment_load_conservation_1081  -1
    load_1_11_7  segment_prefix_lb_1082  1
    load_1_11_7  segment_prefix_ub_1083  1
    load_1_11_7  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_964  -30
    arc_1_11_8  connected_order_arc_965  -11
    arc_1_11_8  in_degree_1085  1
    arc_1_11_8  out_degree_1103  1
    arc_1_11_8  original_T_including_depot_unload_1140  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_964  1
    load_1_11_8  segment_load_conservation_1088  -1
    load_1_11_8  segment_prefix_lb_1089  1
    load_1_11_8  segment_prefix_ub_1090  1
    load_1_11_8  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_966  -30
    arc_1_11_9  connected_order_arc_967  -11
    arc_1_11_9  in_degree_1092  1
    arc_1_11_9  out_degree_1103  1
    arc_1_11_9  original_T_including_depot_unload_1140  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_966  1
    load_1_11_9  free_load_conservation_1096  -1
    load_1_11_9  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_968  -30
    arc_1_11_10  connected_order_arc_969  -11
    arc_1_11_10  in_degree_1098  1
    arc_1_11_10  out_degree_1103  1
    arc_1_11_10  original_T_including_depot_unload_1140  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_968  1
    load_1_11_10  free_load_conservation_1102  -1
    load_1_11_10  free_load_conservation_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_970  -30
    arc_1_11_12  connected_order_arc_971  -11
    arc_1_11_12  out_degree_1103  1
    arc_1_11_12  in_degree_1110  1
    arc_1_11_12  original_T_including_depot_unload_1140  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_970  1
    load_1_11_12  free_load_conservation_1108  1
    load_1_11_12  free_load_conservation_1114  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_972  -30
    arc_1_11_13  connected_order_arc_973  -11
    arc_1_11_13  out_degree_1103  1
    arc_1_11_13  in_degree_1116  1
    arc_1_11_13  original_T_including_depot_unload_1140  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_972  1
    load_1_11_13  free_load_conservation_1108  1
    load_1_11_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_974  -30
    arc_1_11_14  connected_order_arc_975  -11
    arc_1_11_14  out_degree_1103  1
    arc_1_11_14  in_degree_1122  1
    arc_1_11_14  original_T_including_depot_unload_1140  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_974  1
    load_1_11_14  free_load_conservation_1108  1
    load_1_11_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_976  -30
    arc_1_11_15  connected_order_arc_977  -11
    arc_1_11_15  out_degree_1103  1
    arc_1_11_15  in_degree_1128  1
    arc_1_11_15  original_T_including_depot_unload_1140  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_976  1
    load_1_11_15  free_load_conservation_1108  1
    load_1_11_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_978  -30
    arc_1_11_16  connected_order_arc_979  -11
    arc_1_11_16  out_degree_1103  1
    arc_1_11_16  in_degree_1134  1
    arc_1_11_16  original_T_including_depot_unload_1140  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_978  1
    load_1_11_16  free_load_conservation_1108  1
    load_1_11_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_980  -30
    arc_1_12_0  depot_return_or_bypass_1076  1
    arc_1_12_0  out_degree_1109  1
    arc_1_12_0  original_T_including_depot_unload_1140  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_980  1
    load_1_12_0  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_981  -30
    arc_1_12_7  connected_order_arc_982  -11
    arc_1_12_7  in_degree_1078  1
    arc_1_12_7  out_degree_1109  1
    arc_1_12_7  original_T_including_depot_unload_1140  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_981  1
    load_1_12_7  segment_load_conservation_1081  -1
    load_1_12_7  segment_prefix_lb_1082  1
    load_1_12_7  segment_prefix_ub_1083  1
    load_1_12_7  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_983  -30
    arc_1_12_8  connected_order_arc_984  -11
    arc_1_12_8  in_degree_1085  1
    arc_1_12_8  out_degree_1109  1
    arc_1_12_8  original_T_including_depot_unload_1140  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_983  1
    load_1_12_8  segment_load_conservation_1088  -1
    load_1_12_8  segment_prefix_lb_1089  1
    load_1_12_8  segment_prefix_ub_1090  1
    load_1_12_8  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_985  -30
    arc_1_12_9  connected_order_arc_986  -11
    arc_1_12_9  in_degree_1092  1
    arc_1_12_9  out_degree_1109  1
    arc_1_12_9  original_T_including_depot_unload_1140  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_985  1
    load_1_12_9  free_load_conservation_1096  -1
    load_1_12_9  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_987  -30
    arc_1_12_10  connected_order_arc_988  -11
    arc_1_12_10  in_degree_1098  1
    arc_1_12_10  out_degree_1109  1
    arc_1_12_10  original_T_including_depot_unload_1140  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_987  1
    load_1_12_10  free_load_conservation_1102  -1
    load_1_12_10  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_989  -30
    arc_1_12_11  connected_order_arc_990  -11
    arc_1_12_11  in_degree_1104  1
    arc_1_12_11  out_degree_1109  1
    arc_1_12_11  original_T_including_depot_unload_1140  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_989  1
    load_1_12_11  free_load_conservation_1108  -1
    load_1_12_11  free_load_conservation_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_991  -30
    arc_1_12_13  connected_order_arc_992  -11
    arc_1_12_13  out_degree_1109  1
    arc_1_12_13  in_degree_1116  1
    arc_1_12_13  original_T_including_depot_unload_1140  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_991  1
    load_1_12_13  free_load_conservation_1114  1
    load_1_12_13  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_993  -30
    arc_1_12_14  connected_order_arc_994  -11
    arc_1_12_14  out_degree_1109  1
    arc_1_12_14  in_degree_1122  1
    arc_1_12_14  original_T_including_depot_unload_1140  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_993  1
    load_1_12_14  free_load_conservation_1114  1
    load_1_12_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_995  -30
    arc_1_12_15  connected_order_arc_996  -11
    arc_1_12_15  out_degree_1109  1
    arc_1_12_15  in_degree_1128  1
    arc_1_12_15  original_T_including_depot_unload_1140  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_995  1
    load_1_12_15  free_load_conservation_1114  1
    load_1_12_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_997  -30
    arc_1_12_16  connected_order_arc_998  -11
    arc_1_12_16  out_degree_1109  1
    arc_1_12_16  in_degree_1134  1
    arc_1_12_16  original_T_including_depot_unload_1140  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_997  1
    load_1_12_16  free_load_conservation_1114  1
    load_1_12_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_999  -30
    arc_1_13_0  depot_return_or_bypass_1076  1
    arc_1_13_0  out_degree_1115  1
    arc_1_13_0  original_T_including_depot_unload_1140  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_999  1
    load_1_13_0  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_1000  -30
    arc_1_13_7  connected_order_arc_1001  -11
    arc_1_13_7  in_degree_1078  1
    arc_1_13_7  out_degree_1115  1
    arc_1_13_7  original_T_including_depot_unload_1140  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_1000  1
    load_1_13_7  segment_load_conservation_1081  -1
    load_1_13_7  segment_prefix_lb_1082  1
    load_1_13_7  segment_prefix_ub_1083  1
    load_1_13_7  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_1002  -30
    arc_1_13_8  connected_order_arc_1003  -11
    arc_1_13_8  in_degree_1085  1
    arc_1_13_8  out_degree_1115  1
    arc_1_13_8  original_T_including_depot_unload_1140  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_1002  1
    load_1_13_8  segment_load_conservation_1088  -1
    load_1_13_8  segment_prefix_lb_1089  1
    load_1_13_8  segment_prefix_ub_1090  1
    load_1_13_8  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_1004  -30
    arc_1_13_9  connected_order_arc_1005  -11
    arc_1_13_9  in_degree_1092  1
    arc_1_13_9  out_degree_1115  1
    arc_1_13_9  original_T_including_depot_unload_1140  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_1004  1
    load_1_13_9  free_load_conservation_1096  -1
    load_1_13_9  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_1006  -30
    arc_1_13_10  connected_order_arc_1007  -11
    arc_1_13_10  in_degree_1098  1
    arc_1_13_10  out_degree_1115  1
    arc_1_13_10  original_T_including_depot_unload_1140  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_1006  1
    load_1_13_10  free_load_conservation_1102  -1
    load_1_13_10  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_1008  -30
    arc_1_13_11  connected_order_arc_1009  -11
    arc_1_13_11  in_degree_1104  1
    arc_1_13_11  out_degree_1115  1
    arc_1_13_11  original_T_including_depot_unload_1140  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_1008  1
    load_1_13_11  free_load_conservation_1108  -1
    load_1_13_11  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_1010  -30
    arc_1_13_12  connected_order_arc_1011  -11
    arc_1_13_12  in_degree_1110  1
    arc_1_13_12  out_degree_1115  1
    arc_1_13_12  original_T_including_depot_unload_1140  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_1010  1
    load_1_13_12  free_load_conservation_1114  -1
    load_1_13_12  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1012  -30
    arc_1_13_14  connected_order_arc_1013  -11
    arc_1_13_14  out_degree_1115  1
    arc_1_13_14  in_degree_1122  1
    arc_1_13_14  original_T_including_depot_unload_1140  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1012  1
    load_1_13_14  free_load_conservation_1120  1
    load_1_13_14  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1014  -30
    arc_1_13_15  connected_order_arc_1015  -11
    arc_1_13_15  out_degree_1115  1
    arc_1_13_15  in_degree_1128  1
    arc_1_13_15  original_T_including_depot_unload_1140  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1014  1
    load_1_13_15  free_load_conservation_1120  1
    load_1_13_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1016  -30
    arc_1_13_16  connected_order_arc_1017  -11
    arc_1_13_16  out_degree_1115  1
    arc_1_13_16  in_degree_1134  1
    arc_1_13_16  original_T_including_depot_unload_1140  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1016  1
    load_1_13_16  free_load_conservation_1120  1
    load_1_13_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1018  -30
    arc_1_14_0  depot_return_or_bypass_1076  1
    arc_1_14_0  out_degree_1121  1
    arc_1_14_0  original_T_including_depot_unload_1140  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1018  1
    load_1_14_0  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1019  -30
    arc_1_14_7  connected_order_arc_1020  -11
    arc_1_14_7  in_degree_1078  1
    arc_1_14_7  out_degree_1121  1
    arc_1_14_7  original_T_including_depot_unload_1140  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1019  1
    load_1_14_7  segment_load_conservation_1081  -1
    load_1_14_7  segment_prefix_lb_1082  1
    load_1_14_7  segment_prefix_ub_1083  1
    load_1_14_7  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1021  -30
    arc_1_14_8  connected_order_arc_1022  -11
    arc_1_14_8  in_degree_1085  1
    arc_1_14_8  out_degree_1121  1
    arc_1_14_8  original_T_including_depot_unload_1140  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1021  1
    load_1_14_8  segment_load_conservation_1088  -1
    load_1_14_8  segment_prefix_lb_1089  1
    load_1_14_8  segment_prefix_ub_1090  1
    load_1_14_8  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1023  -30
    arc_1_14_9  connected_order_arc_1024  -11
    arc_1_14_9  in_degree_1092  1
    arc_1_14_9  out_degree_1121  1
    arc_1_14_9  original_T_including_depot_unload_1140  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1023  1
    load_1_14_9  free_load_conservation_1096  -1
    load_1_14_9  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1025  -30
    arc_1_14_10  connected_order_arc_1026  -11
    arc_1_14_10  in_degree_1098  1
    arc_1_14_10  out_degree_1121  1
    arc_1_14_10  original_T_including_depot_unload_1140  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1025  1
    load_1_14_10  free_load_conservation_1102  -1
    load_1_14_10  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1027  -30
    arc_1_14_11  connected_order_arc_1028  -11
    arc_1_14_11  in_degree_1104  1
    arc_1_14_11  out_degree_1121  1
    arc_1_14_11  original_T_including_depot_unload_1140  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1027  1
    load_1_14_11  free_load_conservation_1108  -1
    load_1_14_11  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1029  -30
    arc_1_14_12  connected_order_arc_1030  -11
    arc_1_14_12  in_degree_1110  1
    arc_1_14_12  out_degree_1121  1
    arc_1_14_12  original_T_including_depot_unload_1140  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1029  1
    load_1_14_12  free_load_conservation_1114  -1
    load_1_14_12  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1031  -30
    arc_1_14_13  connected_order_arc_1032  -11
    arc_1_14_13  in_degree_1116  1
    arc_1_14_13  out_degree_1121  1
    arc_1_14_13  original_T_including_depot_unload_1140  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1031  1
    load_1_14_13  free_load_conservation_1120  -1
    load_1_14_13  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1033  -30
    arc_1_14_15  connected_order_arc_1034  -11
    arc_1_14_15  out_degree_1121  1
    arc_1_14_15  in_degree_1128  1
    arc_1_14_15  original_T_including_depot_unload_1140  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1033  1
    load_1_14_15  free_load_conservation_1126  1
    load_1_14_15  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1035  -30
    arc_1_14_16  connected_order_arc_1036  -11
    arc_1_14_16  out_degree_1121  1
    arc_1_14_16  in_degree_1134  1
    arc_1_14_16  original_T_including_depot_unload_1140  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1035  1
    load_1_14_16  free_load_conservation_1126  1
    load_1_14_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1037  -30
    arc_1_15_0  depot_return_or_bypass_1076  1
    arc_1_15_0  out_degree_1127  1
    arc_1_15_0  original_T_including_depot_unload_1140  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1037  1
    load_1_15_0  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1038  -30
    arc_1_15_7  connected_order_arc_1039  -11
    arc_1_15_7  in_degree_1078  1
    arc_1_15_7  out_degree_1127  1
    arc_1_15_7  original_T_including_depot_unload_1140  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1038  1
    load_1_15_7  segment_load_conservation_1081  -1
    load_1_15_7  segment_prefix_lb_1082  1
    load_1_15_7  segment_prefix_ub_1083  1
    load_1_15_7  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1040  -30
    arc_1_15_8  connected_order_arc_1041  -11
    arc_1_15_8  in_degree_1085  1
    arc_1_15_8  out_degree_1127  1
    arc_1_15_8  original_T_including_depot_unload_1140  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1040  1
    load_1_15_8  segment_load_conservation_1088  -1
    load_1_15_8  segment_prefix_lb_1089  1
    load_1_15_8  segment_prefix_ub_1090  1
    load_1_15_8  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1042  -30
    arc_1_15_9  connected_order_arc_1043  -11
    arc_1_15_9  in_degree_1092  1
    arc_1_15_9  out_degree_1127  1
    arc_1_15_9  original_T_including_depot_unload_1140  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1042  1
    load_1_15_9  free_load_conservation_1096  -1
    load_1_15_9  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1044  -30
    arc_1_15_10  connected_order_arc_1045  -11
    arc_1_15_10  in_degree_1098  1
    arc_1_15_10  out_degree_1127  1
    arc_1_15_10  original_T_including_depot_unload_1140  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1044  1
    load_1_15_10  free_load_conservation_1102  -1
    load_1_15_10  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1046  -30
    arc_1_15_11  connected_order_arc_1047  -11
    arc_1_15_11  in_degree_1104  1
    arc_1_15_11  out_degree_1127  1
    arc_1_15_11  original_T_including_depot_unload_1140  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1046  1
    load_1_15_11  free_load_conservation_1108  -1
    load_1_15_11  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1048  -30
    arc_1_15_12  connected_order_arc_1049  -11
    arc_1_15_12  in_degree_1110  1
    arc_1_15_12  out_degree_1127  1
    arc_1_15_12  original_T_including_depot_unload_1140  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1048  1
    load_1_15_12  free_load_conservation_1114  -1
    load_1_15_12  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1050  -30
    arc_1_15_13  connected_order_arc_1051  -11
    arc_1_15_13  in_degree_1116  1
    arc_1_15_13  out_degree_1127  1
    arc_1_15_13  original_T_including_depot_unload_1140  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1050  1
    load_1_15_13  free_load_conservation_1120  -1
    load_1_15_13  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1052  -30
    arc_1_15_14  connected_order_arc_1053  -11
    arc_1_15_14  in_degree_1122  1
    arc_1_15_14  out_degree_1127  1
    arc_1_15_14  original_T_including_depot_unload_1140  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1052  1
    load_1_15_14  free_load_conservation_1126  -1
    load_1_15_14  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1054  -30
    arc_1_15_16  connected_order_arc_1055  -11
    arc_1_15_16  out_degree_1127  1
    arc_1_15_16  in_degree_1134  1
    arc_1_15_16  original_T_including_depot_unload_1140  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1054  1
    load_1_15_16  free_load_conservation_1132  1
    load_1_15_16  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1056  -30
    arc_1_16_0  depot_return_or_bypass_1076  1
    arc_1_16_0  out_degree_1133  1
    arc_1_16_0  original_T_including_depot_unload_1140  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1056  1
    load_1_16_0  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1057  -30
    arc_1_16_7  connected_order_arc_1058  -11
    arc_1_16_7  in_degree_1078  1
    arc_1_16_7  out_degree_1133  1
    arc_1_16_7  original_T_including_depot_unload_1140  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1057  1
    load_1_16_7  segment_load_conservation_1081  -1
    load_1_16_7  segment_prefix_lb_1082  1
    load_1_16_7  segment_prefix_ub_1083  1
    load_1_16_7  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1059  -30
    arc_1_16_8  connected_order_arc_1060  -11
    arc_1_16_8  in_degree_1085  1
    arc_1_16_8  out_degree_1133  1
    arc_1_16_8  original_T_including_depot_unload_1140  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1059  1
    load_1_16_8  segment_load_conservation_1088  -1
    load_1_16_8  segment_prefix_lb_1089  1
    load_1_16_8  segment_prefix_ub_1090  1
    load_1_16_8  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1061  -30
    arc_1_16_9  connected_order_arc_1062  -11
    arc_1_16_9  in_degree_1092  1
    arc_1_16_9  out_degree_1133  1
    arc_1_16_9  original_T_including_depot_unload_1140  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1061  1
    load_1_16_9  free_load_conservation_1096  -1
    load_1_16_9  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1063  -30
    arc_1_16_10  connected_order_arc_1064  -11
    arc_1_16_10  in_degree_1098  1
    arc_1_16_10  out_degree_1133  1
    arc_1_16_10  original_T_including_depot_unload_1140  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1063  1
    load_1_16_10  free_load_conservation_1102  -1
    load_1_16_10  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1065  -30
    arc_1_16_11  connected_order_arc_1066  -11
    arc_1_16_11  in_degree_1104  1
    arc_1_16_11  out_degree_1133  1
    arc_1_16_11  original_T_including_depot_unload_1140  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1065  1
    load_1_16_11  free_load_conservation_1108  -1
    load_1_16_11  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1067  -30
    arc_1_16_12  connected_order_arc_1068  -11
    arc_1_16_12  in_degree_1110  1
    arc_1_16_12  out_degree_1133  1
    arc_1_16_12  original_T_including_depot_unload_1140  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1067  1
    load_1_16_12  free_load_conservation_1114  -1
    load_1_16_12  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1069  -30
    arc_1_16_13  connected_order_arc_1070  -11
    arc_1_16_13  in_degree_1116  1
    arc_1_16_13  out_degree_1133  1
    arc_1_16_13  original_T_including_depot_unload_1140  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1069  1
    load_1_16_13  free_load_conservation_1120  -1
    load_1_16_13  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1071  -30
    arc_1_16_14  connected_order_arc_1072  -11
    arc_1_16_14  in_degree_1122  1
    arc_1_16_14  out_degree_1133  1
    arc_1_16_14  original_T_including_depot_unload_1140  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1071  1
    load_1_16_14  free_load_conservation_1126  -1
    load_1_16_14  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1073  -30
    arc_1_16_15  connected_order_arc_1074  -11
    arc_1_16_15  in_degree_1128  1
    arc_1_16_15  out_degree_1133  1
    arc_1_16_15  original_T_including_depot_unload_1140  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1073  1
    load_1_16_15  free_load_conservation_1132  -1
    load_1_16_15  free_load_conservation_1138  1
RHS
    RHS1      OBJ       -4.1940533673394620e-01
    RHS1      onehot_20_32  1
    RHS1      onehot_12_67  1
    RHS1      onehot_18_102  1
    RHS1      onehot_13_109  1
    RHS1      onehot_17_146  1
    RHS1      onehot_14_181  1
    RHS1      onehot_11_216  1
    RHS1      onehot_16_225  1
    RHS1      stock_ub_229  37
    RHS1      parent_nonstrict_scope_230  6.4131681871110269e-01
    RHS1      normalization_287  1
    RHS1      connected_order_arc_400  -14
    RHS1      connected_order_arc_402  -14
    RHS1      connected_order_arc_404  -14
    RHS1      connected_order_arc_406  -14
    RHS1      connected_order_arc_408  -14
    RHS1      connected_order_arc_410  -14
    RHS1      connected_order_arc_412  -14
    RHS1      connected_order_arc_414  -14
    RHS1      connected_order_arc_416  -14
    RHS1      connected_order_arc_418  -14
    RHS1      connected_order_arc_420  -14
    RHS1      connected_order_arc_422  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_427  -14
    RHS1      connected_order_arc_429  -14
    RHS1      connected_order_arc_431  -14
    RHS1      connected_order_arc_433  -14
    RHS1      connected_order_arc_435  -14
    RHS1      connected_order_arc_437  -14
    RHS1      connected_order_arc_439  -14
    RHS1      connected_order_arc_441  -14
    RHS1      connected_order_arc_443  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_447  -14
    RHS1      connected_order_arc_449  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_454  -14
    RHS1      connected_order_arc_456  -14
    RHS1      connected_order_arc_458  -14
    RHS1      connected_order_arc_460  -14
    RHS1      connected_order_arc_462  -14
    RHS1      connected_order_arc_464  -14
    RHS1      connected_order_arc_466  -14
    RHS1      connected_order_arc_468  -14
    RHS1      connected_order_arc_470  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_481  -14
    RHS1      connected_order_arc_483  -14
    RHS1      connected_order_arc_485  -14
    RHS1      connected_order_arc_487  -14
    RHS1      connected_order_arc_489  -14
    RHS1      connected_order_arc_491  -14
    RHS1      connected_order_arc_493  -14
    RHS1      connected_order_arc_495  -14
    RHS1      connected_order_arc_497  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_508  -14
    RHS1      connected_order_arc_510  -14
    RHS1      connected_order_arc_512  -14
    RHS1      connected_order_arc_514  -14
    RHS1      connected_order_arc_516  -14
    RHS1      connected_order_arc_518  -14
    RHS1      connected_order_arc_520  -14
    RHS1      connected_order_arc_522  -14
    RHS1      connected_order_arc_524  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_535  -14
    RHS1      connected_order_arc_537  -14
    RHS1      connected_order_arc_539  -14
    RHS1      connected_order_arc_541  -14
    RHS1      connected_order_arc_543  -14
    RHS1      connected_order_arc_545  -14
    RHS1      connected_order_arc_547  -14
    RHS1      connected_order_arc_549  -14
    RHS1      connected_order_arc_551  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_562  -14
    RHS1      connected_order_arc_564  -14
    RHS1      connected_order_arc_566  -14
    RHS1      connected_order_arc_568  -14
    RHS1      connected_order_arc_570  -14
    RHS1      connected_order_arc_572  -14
    RHS1      connected_order_arc_574  -14
    RHS1      connected_order_arc_576  -14
    RHS1      connected_order_arc_578  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_589  -14
    RHS1      connected_order_arc_591  -14
    RHS1      connected_order_arc_593  -14
    RHS1      connected_order_arc_595  -14
    RHS1      connected_order_arc_597  -14
    RHS1      connected_order_arc_599  -14
    RHS1      connected_order_arc_601  -14
    RHS1      connected_order_arc_603  -14
    RHS1      connected_order_arc_605  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_616  -14
    RHS1      connected_order_arc_618  -14
    RHS1      connected_order_arc_620  -14
    RHS1      connected_order_arc_622  -14
    RHS1      connected_order_arc_624  -14
    RHS1      connected_order_arc_626  -14
    RHS1      connected_order_arc_628  -14
    RHS1      connected_order_arc_630  -14
    RHS1      connected_order_arc_632  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_643  -14
    RHS1      connected_order_arc_645  -14
    RHS1      connected_order_arc_647  -14
    RHS1      connected_order_arc_649  -14
    RHS1      connected_order_arc_651  -14
    RHS1      connected_order_arc_653  -14
    RHS1      connected_order_arc_655  -14
    RHS1      connected_order_arc_657  -14
    RHS1      connected_order_arc_659  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_670  -14
    RHS1      connected_order_arc_672  -14
    RHS1      connected_order_arc_674  -14
    RHS1      connected_order_arc_676  -14
    RHS1      connected_order_arc_678  -14
    RHS1      connected_order_arc_680  -14
    RHS1      connected_order_arc_682  -14
    RHS1      connected_order_arc_684  -14
    RHS1      connected_order_arc_686  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_697  -14
    RHS1      connected_order_arc_699  -14
    RHS1      connected_order_arc_701  -14
    RHS1      connected_order_arc_703  -14
    RHS1      connected_order_arc_705  -14
    RHS1      connected_order_arc_707  -14
    RHS1      connected_order_arc_709  -14
    RHS1      connected_order_arc_711  -14
    RHS1      connected_order_arc_713  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_724  -14
    RHS1      connected_order_arc_726  -14
    RHS1      connected_order_arc_728  -14
    RHS1      connected_order_arc_730  -14
    RHS1      connected_order_arc_732  -14
    RHS1      connected_order_arc_734  -14
    RHS1      connected_order_arc_736  -14
    RHS1      connected_order_arc_738  -14
    RHS1      connected_order_arc_740  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_744  -14
    RHS1      connected_order_arc_746  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_751  -14
    RHS1      connected_order_arc_753  -14
    RHS1      connected_order_arc_755  -14
    RHS1      connected_order_arc_757  -14
    RHS1      connected_order_arc_759  -14
    RHS1      connected_order_arc_761  -14
    RHS1      connected_order_arc_763  -14
    RHS1      connected_order_arc_765  -14
    RHS1      connected_order_arc_767  -14
    RHS1      connected_order_arc_769  -14
    RHS1      connected_order_arc_771  -14
    RHS1      connected_order_arc_773  -14
    RHS1      connected_order_arc_775  -14
    RHS1      depot_departure_or_bypass_776  1
    RHS1      depot_return_or_bypass_777  1
    RHS1      segment_load_conservation_782  3
    RHS1      segment_prefix_ub_784  27
    RHS1      segment_load_conservation_789  -3
    RHS1      segment_prefix_lb_790  3
    RHS1      segment_prefix_ub_791  30
    RHS1      segment_load_conservation_796  4
    RHS1      segment_prefix_ub_798  26
    RHS1      segment_load_conservation_803  -1
    RHS1      segment_prefix_lb_804  1
    RHS1      segment_prefix_ub_805  30
    RHS1      segment_load_conservation_810  -1
    RHS1      segment_prefix_lb_811  1
    RHS1      segment_prefix_ub_812  30
    RHS1      segment_load_conservation_817  -2
    RHS1      segment_prefix_lb_818  2
    RHS1      segment_prefix_ub_819  30
    RHS1      fixed_segment_relative_order_868  1
    RHS1      fixed_segment_relative_order_869  1
    RHS1      fixed_segment_relative_order_870  1
    RHS1      fixed_segment_relative_order_871  1
    RHS1      fixed_segment_relative_order_872  1
    RHS1      original_T_including_depot_unload_873  3960
    RHS1      connected_order_arc_887  -10
    RHS1      connected_order_arc_889  -10
    RHS1      connected_order_arc_891  -10
    RHS1      connected_order_arc_893  -10
    RHS1      connected_order_arc_895  -10
    RHS1      connected_order_arc_897  -10
    RHS1      connected_order_arc_899  -10
    RHS1      connected_order_arc_901  -10
    RHS1      connected_order_arc_903  -10
    RHS1      connected_order_arc_906  -10
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_916  -10
    RHS1      connected_order_arc_918  -10
    RHS1      connected_order_arc_920  -10
    RHS1      connected_order_arc_922  -10
    RHS1      connected_order_arc_925  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_935  -10
    RHS1      connected_order_arc_937  -10
    RHS1      connected_order_arc_939  -10
    RHS1      connected_order_arc_941  -10
    RHS1      connected_order_arc_944  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      connected_order_arc_954  -10
    RHS1      connected_order_arc_956  -10
    RHS1      connected_order_arc_958  -10
    RHS1      connected_order_arc_960  -10
    RHS1      connected_order_arc_963  -10
    RHS1      connected_order_arc_965  -10
    RHS1      connected_order_arc_967  -10
    RHS1      connected_order_arc_969  -10
    RHS1      connected_order_arc_971  -10
    RHS1      connected_order_arc_973  -10
    RHS1      connected_order_arc_975  -10
    RHS1      connected_order_arc_977  -10
    RHS1      connected_order_arc_979  -10
    RHS1      connected_order_arc_982  -10
    RHS1      connected_order_arc_984  -10
    RHS1      connected_order_arc_986  -10
    RHS1      connected_order_arc_988  -10
    RHS1      connected_order_arc_990  -10
    RHS1      connected_order_arc_992  -10
    RHS1      connected_order_arc_994  -10
    RHS1      connected_order_arc_996  -10
    RHS1      connected_order_arc_998  -10
    RHS1      connected_order_arc_1001  -10
    RHS1      connected_order_arc_1003  -10
    RHS1      connected_order_arc_1005  -10
    RHS1      connected_order_arc_1007  -10
    RHS1      connected_order_arc_1009  -10
    RHS1      connected_order_arc_1011  -10
    RHS1      connected_order_arc_1013  -10
    RHS1      connected_order_arc_1015  -10
    RHS1      connected_order_arc_1017  -10
    RHS1      connected_order_arc_1020  -10
    RHS1      connected_order_arc_1022  -10
    RHS1      connected_order_arc_1024  -10
    RHS1      connected_order_arc_1026  -10
    RHS1      connected_order_arc_1028  -10
    RHS1      connected_order_arc_1030  -10
    RHS1      connected_order_arc_1032  -10
    RHS1      connected_order_arc_1034  -10
    RHS1      connected_order_arc_1036  -10
    RHS1      connected_order_arc_1039  -10
    RHS1      connected_order_arc_1041  -10
    RHS1      connected_order_arc_1043  -10
    RHS1      connected_order_arc_1045  -10
    RHS1      connected_order_arc_1047  -10
    RHS1      connected_order_arc_1049  -10
    RHS1      connected_order_arc_1051  -10
    RHS1      connected_order_arc_1053  -10
    RHS1      connected_order_arc_1055  -10
    RHS1      connected_order_arc_1058  -10
    RHS1      connected_order_arc_1060  -10
    RHS1      connected_order_arc_1062  -10
    RHS1      connected_order_arc_1064  -10
    RHS1      connected_order_arc_1066  -10
    RHS1      connected_order_arc_1068  -10
    RHS1      connected_order_arc_1070  -10
    RHS1      connected_order_arc_1072  -10
    RHS1      connected_order_arc_1074  -10
    RHS1      depot_departure_or_bypass_1075  1
    RHS1      depot_return_or_bypass_1076  1
    RHS1      segment_load_conservation_1081  -1
    RHS1      segment_prefix_lb_1082  1
    RHS1      segment_prefix_ub_1083  30
    RHS1      segment_load_conservation_1088  -1
    RHS1      segment_prefix_lb_1089  1
    RHS1      segment_prefix_ub_1090  30
    RHS1      fixed_segment_relative_order_1139  1
    RHS1      original_T_including_depot_unload_1140  4800
BOUNDS
 LO BND1      t         4.4938209961258267e-02
 UP BND1      t         1.3705335291252085e-01
 UP BND1      q         0.753053928089682
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.3705335291252085e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.3705335291252085e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.3705335291252085e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.3705335291252085e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.3705335291252085e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.3705335291252085e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.3705335291252085e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.3705335291252085e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.3705335291252085e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.3705335291252085e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.3705335291252085e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.3705335291252085e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.3705335291252085e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.3705335291252085e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.3705335291252085e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.3705335291252085e-01
 UP BND1      rho_20    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    1.3705335291252085e-01
 BV BND1      x_12_1  
 UP BND1      w_12_1    1.3705335291252085e-01
 BV BND1      x_12_2  
 UP BND1      w_12_2    1.3705335291252085e-01
 BV BND1      x_12_3  
 UP BND1      w_12_3    1.3705335291252085e-01
 BV BND1      x_12_4  
 UP BND1      w_12_4    1.3705335291252085e-01
 BV BND1      x_12_5  
 UP BND1      w_12_5    1.3705335291252085e-01
 BV BND1      x_12_6  
 UP BND1      w_12_6    1.3705335291252085e-01
 BV BND1      x_12_7  
 UP BND1      w_12_7    1.3705335291252085e-01
 BV BND1      x_12_8  
 UP BND1      w_12_8    1.3705335291252085e-01
 BV BND1      x_12_9  
 UP BND1      w_12_9    1.3705335291252085e-01
 BV BND1      x_12_10 
 UP BND1      w_12_10   1.3705335291252085e-01
 BV BND1      x_12_11 
 UP BND1      w_12_11   1.3705335291252085e-01
 BV BND1      x_12_12 
 UP BND1      w_12_12   1.3705335291252085e-01
 BV BND1      x_12_13 
 UP BND1      w_12_13   1.3705335291252085e-01
 BV BND1      x_12_14 
 UP BND1      w_12_14   1.3705335291252085e-01
 BV BND1      x_12_15 
 UP BND1      w_12_15   1.3705335291252085e-01
 UP BND1      rho_12    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.3705335291252085e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.3705335291252085e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.3705335291252085e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.3705335291252085e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.3705335291252085e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.3705335291252085e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.3705335291252085e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.3705335291252085e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.3705335291252085e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.3705335291252085e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.3705335291252085e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.3705335291252085e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.3705335291252085e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.3705335291252085e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.3705335291252085e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.3705335291252085e-01
 UP BND1      rho_18    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    1.3705335291252085e-01
 BV BND1      x_13_1  
 UP BND1      w_13_1    1.3705335291252085e-01
 UP BND1      rho_13    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.3705335291252085e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.3705335291252085e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.3705335291252085e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.3705335291252085e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.3705335291252085e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.3705335291252085e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.3705335291252085e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.3705335291252085e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.3705335291252085e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.3705335291252085e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.3705335291252085e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.3705335291252085e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.3705335291252085e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.3705335291252085e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.3705335291252085e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.3705335291252085e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.3705335291252085e-01
 UP BND1      rho_17    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    1.3705335291252085e-01
 BV BND1      x_14_1  
 UP BND1      w_14_1    1.3705335291252085e-01
 BV BND1      x_14_2  
 UP BND1      w_14_2    1.3705335291252085e-01
 BV BND1      x_14_3  
 UP BND1      w_14_3    1.3705335291252085e-01
 BV BND1      x_14_4  
 UP BND1      w_14_4    1.3705335291252085e-01
 BV BND1      x_14_5  
 UP BND1      w_14_5    1.3705335291252085e-01
 BV BND1      x_14_6  
 UP BND1      w_14_6    1.3705335291252085e-01
 BV BND1      x_14_7  
 UP BND1      w_14_7    1.3705335291252085e-01
 BV BND1      x_14_8  
 UP BND1      w_14_8    1.3705335291252085e-01
 BV BND1      x_14_9  
 UP BND1      w_14_9    1.3705335291252085e-01
 BV BND1      x_14_10 
 UP BND1      w_14_10   1.3705335291252085e-01
 BV BND1      x_14_11 
 UP BND1      w_14_11   1.3705335291252085e-01
 BV BND1      x_14_12 
 UP BND1      w_14_12   1.3705335291252085e-01
 BV BND1      x_14_13 
 UP BND1      w_14_13   1.3705335291252085e-01
 BV BND1      x_14_14 
 UP BND1      w_14_14   1.3705335291252085e-01
 BV BND1      x_14_15 
 UP BND1      w_14_15   1.3705335291252085e-01
 UP BND1      rho_14    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.3705335291252085e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.3705335291252085e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.3705335291252085e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.3705335291252085e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.3705335291252085e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.3705335291252085e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.3705335291252085e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.3705335291252085e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.3705335291252085e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.3705335291252085e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.3705335291252085e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.3705335291252085e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.3705335291252085e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.3705335291252085e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.3705335291252085e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.3705335291252085e-01
 UP BND1      rho_11    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    1.3705335291252085e-01
 BV BND1      x_16_1  
 UP BND1      w_16_1    1.3705335291252085e-01
 BV BND1      x_16_2  
 UP BND1      w_16_2    1.3705335291252085e-01
 UP BND1      rho_16    1
 UP BND1      a_20_12   1
 UP BND1      a_20_18   1
 UP BND1      a_20_13   1
 UP BND1      a_20_17   1
 UP BND1      a_20_14   1
 UP BND1      a_20_11   1
 UP BND1      a_20_16   1
 UP BND1      a_12_18   1
 UP BND1      a_12_13   1
 UP BND1      a_12_17   1
 UP BND1      a_12_14   1
 UP BND1      a_12_11   1
 UP BND1      a_12_16   1
 UP BND1      a_18_13   1
 UP BND1      a_18_17   1
 UP BND1      a_18_14   1
 UP BND1      a_18_11   1
 UP BND1      a_18_16   1
 UP BND1      a_13_17   1
 UP BND1      a_13_14   1
 UP BND1      a_13_11   1
 UP BND1      a_13_16   1
 UP BND1      a_17_14   1
 UP BND1      a_17_11   1
 UP BND1      a_17_16   1
 UP BND1      a_14_11   1
 UP BND1      a_14_16   1
 UP BND1      a_11_16   1
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_13_1
 BV BND1      service_1_13_1
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_2
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_2
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  14
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  14
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  14
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  14
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  14
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  14
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_9_16
 UP BND1      load_0_9_16  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_10_16
 UP BND1      load_0_10_16  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_9
 UP BND1      load_0_16_9  30
 BV BND1      arc_0_16_10
 UP BND1      load_0_16_10  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  30
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
ENDATA
