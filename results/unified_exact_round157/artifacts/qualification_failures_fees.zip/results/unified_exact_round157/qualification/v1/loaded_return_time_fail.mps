* Signature: 0xb5e2151589fc143e
NAME R157_free_fleet_original_T
ROWS
 N  OBJ
 E  select_one_1
 E  assign_service_1_1
 L  arc_capacity_0_0_1
 L  arc_capacity_0_1_0
 L  depart_once_0
 E  return_once_0
 E  out_degree_0_1
 E  in_degree_0_1
 E  load_conservation_0_1
 G  order_lb_0_1
 L  order_ub_0_1
 L  original_time_0
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    select[1,1]  select_one_1  1
    select[1,1]  assign_service_1_1  -1
    service[0,1,1]  assign_service_1_1  1
    service[0,1,1]  out_degree_0_1  -1
    service[0,1,1]  in_degree_0_1  -1
    service[0,1,1]  load_conservation_0_1  -2
    service[0,1,1]  order_lb_0_1  -1
    service[0,1,1]  order_ub_0_1  -1
    service[0,1,1]  original_time_0  2
    arc[0,0,1]  arc_capacity_0_0_1  -2
    arc[0,0,1]  depart_once_0  1
    arc[0,0,1]  return_once_0  1
    arc[0,0,1]  in_degree_0_1  1
    arc[0,0,1]  original_time_0  1
    arc[0,1,0]  arc_capacity_0_1_0  -2
    arc[0,1,0]  return_once_0  -1
    arc[0,1,0]  out_degree_0_1  1
    arc[0,1,0]  original_time_0  1
    MARKER    'MARKER'                 'INTEND'
    load[0,0,1]  arc_capacity_0_0_1  1
    load[0,0,1]  load_conservation_0_1  -1
    load[0,1,0]  arc_capacity_0_1_0  1
    load[0,1,0]  load_conservation_0_1  1
    order[0,1]  order_lb_0_1  1
    order[0,1]  order_ub_0_1  1
RHS
    RHS1      select_one_1  1
    RHS1      depart_once_0  1
    RHS1      original_time_0  3
BOUNDS
 BV BND1      select[1,1]
 BV BND1      service[0,1,1]
 BV BND1      arc[0,0,1]
 BV BND1      arc[0,1,0]
 FX BND1      load[0,0,1]  0
 UP BND1      order[0,1]  1
ENDATA
