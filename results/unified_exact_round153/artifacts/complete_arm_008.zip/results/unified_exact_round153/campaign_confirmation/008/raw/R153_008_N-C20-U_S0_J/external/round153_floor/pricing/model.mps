* Signature: 0xc9e037df674c788b
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  w_lb_1_0
 L  w_ub_1_0
 G  w_lb_1_1
 L  w_ub_1_1
 G  w_lb_1_2
 L  w_ub_1_2
 G  w_lb_1_3
 L  w_ub_1_3
 G  w_lb_1_4
 L  w_ub_1_4
 G  w_lb_1_5
 L  w_ub_1_5
 G  w_lb_1_6
 L  w_ub_1_6
 G  w_lb_1_7
 L  w_ub_1_7
 G  w_lb_1_8
 L  w_ub_1_8
 G  w_lb_1_9
 L  w_ub_1_9
 G  w_lb_1_10
 L  w_ub_1_10
 G  w_lb_1_11
 L  w_ub_1_11
 G  w_lb_1_12
 L  w_ub_1_12
 G  w_lb_1_13
 L  w_ub_1_13
 G  w_lb_1_14
 L  w_ub_1_14
 G  w_lb_1_15
 L  w_ub_1_15
 G  w_lb_1_16
 L  w_ub_1_16
 G  w_lb_1_17
 L  w_ub_1_17
 G  w_lb_1_18
 L  w_ub_1_18
 G  w_lb_1_19
 L  w_ub_1_19
 G  w_lb_1_20
 L  w_ub_1_20
 G  w_lb_1_21
 L  w_ub_1_21
 G  w_lb_1_22
 L  w_ub_1_22
 G  w_lb_1_23
 L  w_ub_1_23
 G  w_lb_1_24
 L  w_ub_1_24
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  w_lb_2_0
 L  w_ub_2_0
 G  w_lb_2_1
 L  w_ub_2_1
 G  w_lb_2_2
 L  w_ub_2_2
 G  w_lb_2_3
 L  w_ub_2_3
 G  w_lb_2_4
 L  w_ub_2_4
 G  w_lb_2_5
 L  w_ub_2_5
 G  w_lb_2_6
 L  w_ub_2_6
 G  w_lb_2_7
 L  w_ub_2_7
 G  w_lb_2_8
 L  w_ub_2_8
 G  w_lb_2_9
 L  w_ub_2_9
 G  w_lb_2_10
 L  w_ub_2_10
 G  w_lb_2_11
 L  w_ub_2_11
 G  w_lb_2_12
 L  w_ub_2_12
 G  w_lb_2_13
 L  w_ub_2_13
 G  w_lb_2_14
 L  w_ub_2_14
 G  w_lb_2_15
 L  w_ub_2_15
 G  w_lb_2_16
 L  w_ub_2_16
 G  w_lb_2_17
 L  w_ub_2_17
 G  w_lb_2_18
 L  w_ub_2_18
 G  w_lb_2_19
 L  w_ub_2_19
 G  w_lb_2_20
 L  w_ub_2_20
 G  w_lb_2_21
 L  w_ub_2_21
 G  w_lb_2_22
 L  w_ub_2_22
 G  w_lb_2_23
 L  w_ub_2_23
 G  w_lb_2_24
 L  w_ub_2_24
 G  w_lb_2_25
 L  w_ub_2_25
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  w_lb_3_0
 L  w_ub_3_0
 G  w_lb_3_1
 L  w_ub_3_1
 G  w_lb_3_2
 L  w_ub_3_2
 G  w_lb_3_3
 L  w_ub_3_3
 G  w_lb_3_4
 L  w_ub_3_4
 G  w_lb_3_5
 L  w_ub_3_5
 G  w_lb_3_6
 L  w_ub_3_6
 G  w_lb_3_7
 L  w_ub_3_7
 G  w_lb_3_8
 L  w_ub_3_8
 G  w_lb_3_9
 L  w_ub_3_9
 G  w_lb_3_10
 L  w_ub_3_10
 G  w_lb_3_11
 L  w_ub_3_11
 G  w_lb_3_12
 L  w_ub_3_12
 G  w_lb_3_13
 L  w_ub_3_13
 G  w_lb_3_14
 L  w_ub_3_14
 G  w_lb_3_15
 L  w_ub_3_15
 G  w_lb_3_16
 L  w_ub_3_16
 G  w_lb_3_17
 L  w_ub_3_17
 G  w_lb_3_18
 L  w_ub_3_18
 G  w_lb_3_19
 L  w_ub_3_19
 G  w_lb_3_20
 L  w_ub_3_20
 G  w_lb_3_21
 L  w_ub_3_21
 G  w_lb_3_22
 L  w_ub_3_22
 G  w_lb_3_23
 L  w_ub_3_23
 G  w_lb_3_24
 L  w_ub_3_24
 G  w_lb_3_25
 L  w_ub_3_25
 G  w_lb_3_26
 L  w_ub_3_26
 G  w_lb_3_27
 L  w_ub_3_27
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  w_lb_4_0
 L  w_ub_4_0
 G  w_lb_4_1
 L  w_ub_4_1
 G  w_lb_4_2
 L  w_ub_4_2
 G  w_lb_4_3
 L  w_ub_4_3
 G  w_lb_4_4
 L  w_ub_4_4
 G  w_lb_4_5
 L  w_ub_4_5
 G  w_lb_4_6
 L  w_ub_4_6
 G  w_lb_4_7
 L  w_ub_4_7
 G  w_lb_4_8
 L  w_ub_4_8
 G  w_lb_4_9
 L  w_ub_4_9
 G  w_lb_4_10
 L  w_ub_4_10
 G  w_lb_4_11
 L  w_ub_4_11
 G  w_lb_4_12
 L  w_ub_4_12
 G  w_lb_4_13
 L  w_ub_4_13
 G  w_lb_4_14
 L  w_ub_4_14
 G  w_lb_4_15
 L  w_ub_4_15
 G  w_lb_4_16
 L  w_ub_4_16
 G  w_lb_4_17
 L  w_ub_4_17
 G  w_lb_4_18
 L  w_ub_4_18
 G  w_lb_4_19
 L  w_ub_4_19
 G  w_lb_4_20
 L  w_ub_4_20
 G  w_lb_4_21
 L  w_ub_4_21
 G  w_lb_4_22
 L  w_ub_4_22
 G  w_lb_4_23
 L  w_ub_4_23
 G  w_lb_4_24
 L  w_ub_4_24
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  w_lb_5_0
 L  w_ub_5_0
 G  w_lb_5_1
 L  w_ub_5_1
 G  w_lb_5_2
 L  w_ub_5_2
 G  w_lb_5_3
 L  w_ub_5_3
 G  w_lb_5_4
 L  w_ub_5_4
 G  w_lb_5_5
 L  w_ub_5_5
 G  w_lb_5_6
 L  w_ub_5_6
 G  w_lb_5_7
 L  w_ub_5_7
 G  w_lb_5_8
 L  w_ub_5_8
 G  w_lb_5_9
 L  w_ub_5_9
 G  w_lb_5_10
 L  w_ub_5_10
 G  w_lb_5_11
 L  w_ub_5_11
 G  w_lb_5_12
 L  w_ub_5_12
 G  w_lb_5_13
 L  w_ub_5_13
 G  w_lb_5_14
 L  w_ub_5_14
 G  w_lb_5_15
 L  w_ub_5_15
 G  w_lb_5_16
 L  w_ub_5_16
 G  w_lb_5_17
 L  w_ub_5_17
 G  w_lb_5_18
 L  w_ub_5_18
 G  w_lb_5_19
 L  w_ub_5_19
 G  w_lb_5_20
 L  w_ub_5_20
 G  w_lb_5_21
 L  w_ub_5_21
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  w_lb_6_0
 L  w_ub_6_0
 G  w_lb_6_1
 L  w_ub_6_1
 G  w_lb_6_2
 L  w_ub_6_2
 G  w_lb_6_3
 L  w_ub_6_3
 G  w_lb_6_4
 L  w_ub_6_4
 G  w_lb_6_5
 L  w_ub_6_5
 G  w_lb_6_6
 L  w_ub_6_6
 G  w_lb_6_7
 L  w_ub_6_7
 G  w_lb_6_8
 L  w_ub_6_8
 G  w_lb_6_9
 L  w_ub_6_9
 G  w_lb_6_10
 L  w_ub_6_10
 G  w_lb_6_11
 L  w_ub_6_11
 G  w_lb_6_12
 L  w_ub_6_12
 G  w_lb_6_13
 L  w_ub_6_13
 G  w_lb_6_14
 L  w_ub_6_14
 G  w_lb_6_15
 L  w_ub_6_15
 G  w_lb_6_16
 L  w_ub_6_16
 G  w_lb_6_17
 L  w_ub_6_17
 G  w_lb_6_18
 L  w_ub_6_18
 G  w_lb_6_19
 L  w_ub_6_19
 G  w_lb_6_20
 L  w_ub_6_20
 G  w_lb_6_21
 L  w_ub_6_21
 G  w_lb_6_22
 L  w_ub_6_22
 G  w_lb_6_23
 L  w_ub_6_23
 G  w_lb_6_24
 L  w_ub_6_24
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  w_lb_7_0
 L  w_ub_7_0
 G  w_lb_7_1
 L  w_ub_7_1
 G  w_lb_7_2
 L  w_ub_7_2
 G  w_lb_7_3
 L  w_ub_7_3
 G  w_lb_7_4
 L  w_ub_7_4
 G  w_lb_7_5
 L  w_ub_7_5
 G  w_lb_7_6
 L  w_ub_7_6
 G  w_lb_7_7
 L  w_ub_7_7
 G  w_lb_7_8
 L  w_ub_7_8
 G  w_lb_7_9
 L  w_ub_7_9
 G  w_lb_7_10
 L  w_ub_7_10
 G  w_lb_7_11
 L  w_ub_7_11
 G  w_lb_7_12
 L  w_ub_7_12
 G  w_lb_7_13
 L  w_ub_7_13
 G  w_lb_7_14
 L  w_ub_7_14
 G  w_lb_7_15
 L  w_ub_7_15
 G  w_lb_7_16
 L  w_ub_7_16
 G  w_lb_7_17
 L  w_ub_7_17
 G  w_lb_7_18
 L  w_ub_7_18
 G  w_lb_7_19
 L  w_ub_7_19
 G  w_lb_7_20
 L  w_ub_7_20
 G  w_lb_7_21
 L  w_ub_7_21
 G  w_lb_7_22
 L  w_ub_7_22
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  w_lb_8_0
 L  w_ub_8_0
 G  w_lb_8_1
 L  w_ub_8_1
 G  w_lb_8_2
 L  w_ub_8_2
 G  w_lb_8_3
 L  w_ub_8_3
 G  w_lb_8_4
 L  w_ub_8_4
 G  w_lb_8_5
 L  w_ub_8_5
 G  w_lb_8_6
 L  w_ub_8_6
 G  w_lb_8_7
 L  w_ub_8_7
 G  w_lb_8_8
 L  w_ub_8_8
 G  w_lb_8_9
 L  w_ub_8_9
 G  w_lb_8_10
 L  w_ub_8_10
 G  w_lb_8_11
 L  w_ub_8_11
 G  w_lb_8_12
 L  w_ub_8_12
 G  w_lb_8_13
 L  w_ub_8_13
 G  w_lb_8_14
 L  w_ub_8_14
 G  w_lb_8_15
 L  w_ub_8_15
 G  w_lb_8_16
 L  w_ub_8_16
 G  w_lb_8_17
 L  w_ub_8_17
 G  w_lb_8_18
 L  w_ub_8_18
 G  w_lb_8_19
 L  w_ub_8_19
 G  w_lb_8_20
 L  w_ub_8_20
 G  w_lb_8_21
 L  w_ub_8_21
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  w_lb_9_0
 L  w_ub_9_0
 G  w_lb_9_1
 L  w_ub_9_1
 G  w_lb_9_2
 L  w_ub_9_2
 G  w_lb_9_3
 L  w_ub_9_3
 G  w_lb_9_4
 L  w_ub_9_4
 G  w_lb_9_5
 L  w_ub_9_5
 G  w_lb_9_6
 L  w_ub_9_6
 G  w_lb_9_7
 L  w_ub_9_7
 G  w_lb_9_8
 L  w_ub_9_8
 G  w_lb_9_9
 L  w_ub_9_9
 G  w_lb_9_10
 L  w_ub_9_10
 G  w_lb_9_11
 L  w_ub_9_11
 G  w_lb_9_12
 L  w_ub_9_12
 G  w_lb_9_13
 L  w_ub_9_13
 G  w_lb_9_14
 L  w_ub_9_14
 G  w_lb_9_15
 L  w_ub_9_15
 G  w_lb_9_16
 L  w_ub_9_16
 G  w_lb_9_17
 L  w_ub_9_17
 G  w_lb_9_18
 L  w_ub_9_18
 G  w_lb_9_19
 L  w_ub_9_19
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  w_lb_10_0
 L  w_ub_10_0
 G  w_lb_10_1
 L  w_ub_10_1
 G  w_lb_10_2
 L  w_ub_10_2
 G  w_lb_10_3
 L  w_ub_10_3
 G  w_lb_10_4
 L  w_ub_10_4
 G  w_lb_10_5
 L  w_ub_10_5
 G  w_lb_10_6
 L  w_ub_10_6
 G  w_lb_10_7
 L  w_ub_10_7
 G  w_lb_10_8
 L  w_ub_10_8
 G  w_lb_10_9
 L  w_ub_10_9
 G  w_lb_10_10
 L  w_ub_10_10
 G  w_lb_10_11
 L  w_ub_10_11
 G  w_lb_10_12
 L  w_ub_10_12
 G  w_lb_10_13
 L  w_ub_10_13
 G  w_lb_10_14
 L  w_ub_10_14
 G  w_lb_10_15
 L  w_ub_10_15
 G  w_lb_10_16
 L  w_ub_10_16
 G  w_lb_10_17
 L  w_ub_10_17
 G  w_lb_10_18
 L  w_ub_10_18
 G  w_lb_10_19
 L  w_ub_10_19
 G  w_lb_10_20
 L  w_ub_10_20
 G  w_lb_10_21
 L  w_ub_10_21
 G  w_lb_10_22
 L  w_ub_10_22
 G  w_lb_10_23
 L  w_ub_10_23
 G  w_lb_10_24
 L  w_ub_10_24
 G  w_lb_10_25
 L  w_ub_10_25
 G  w_lb_10_26
 L  w_ub_10_26
 G  w_lb_10_27
 L  w_ub_10_27
 G  w_lb_10_28
 L  w_ub_10_28
 G  w_lb_10_29
 L  w_ub_10_29
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  w_lb_11_0
 L  w_ub_11_0
 G  w_lb_11_1
 L  w_ub_11_1
 G  w_lb_11_2
 L  w_ub_11_2
 G  w_lb_11_3
 L  w_ub_11_3
 G  w_lb_11_4
 L  w_ub_11_4
 G  w_lb_11_5
 L  w_ub_11_5
 G  w_lb_11_6
 L  w_ub_11_6
 G  w_lb_11_7
 L  w_ub_11_7
 G  w_lb_11_8
 L  w_ub_11_8
 G  w_lb_11_9
 L  w_ub_11_9
 G  w_lb_11_10
 L  w_ub_11_10
 G  w_lb_11_11
 L  w_ub_11_11
 G  w_lb_11_12
 L  w_ub_11_12
 G  w_lb_11_13
 L  w_ub_11_13
 G  w_lb_11_14
 L  w_ub_11_14
 G  w_lb_11_15
 L  w_ub_11_15
 G  w_lb_11_16
 L  w_ub_11_16
 G  w_lb_11_17
 L  w_ub_11_17
 G  w_lb_11_18
 L  w_ub_11_18
 G  w_lb_11_19
 L  w_ub_11_19
 G  w_lb_11_20
 L  w_ub_11_20
 G  w_lb_11_21
 L  w_ub_11_21
 G  w_lb_11_22
 L  w_ub_11_22
 G  w_lb_11_23
 L  w_ub_11_23
 G  w_lb_11_24
 L  w_ub_11_24
 G  w_lb_11_25
 L  w_ub_11_25
 G  w_lb_11_26
 L  w_ub_11_26
 G  w_lb_11_27
 L  w_ub_11_27
 G  w_lb_11_28
 L  w_ub_11_28
 G  w_lb_11_29
 L  w_ub_11_29
 G  w_lb_11_30
 L  w_ub_11_30
 G  w_lb_11_31
 L  w_ub_11_31
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  w_lb_12_0
 L  w_ub_12_0
 G  w_lb_12_1
 L  w_ub_12_1
 G  w_lb_12_2
 L  w_ub_12_2
 G  w_lb_12_3
 L  w_ub_12_3
 G  w_lb_12_4
 L  w_ub_12_4
 G  w_lb_12_5
 L  w_ub_12_5
 G  w_lb_12_6
 L  w_ub_12_6
 G  w_lb_12_7
 L  w_ub_12_7
 G  w_lb_12_8
 L  w_ub_12_8
 G  w_lb_12_9
 L  w_ub_12_9
 G  w_lb_12_10
 L  w_ub_12_10
 G  w_lb_12_11
 L  w_ub_12_11
 G  w_lb_12_12
 L  w_ub_12_12
 G  w_lb_12_13
 L  w_ub_12_13
 G  w_lb_12_14
 L  w_ub_12_14
 G  w_lb_12_15
 L  w_ub_12_15
 G  w_lb_12_16
 L  w_ub_12_16
 G  w_lb_12_17
 L  w_ub_12_17
 G  w_lb_12_18
 L  w_ub_12_18
 G  w_lb_12_19
 L  w_ub_12_19
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  w_lb_13_0
 L  w_ub_13_0
 G  w_lb_13_1
 L  w_ub_13_1
 G  w_lb_13_2
 L  w_ub_13_2
 G  w_lb_13_3
 L  w_ub_13_3
 G  w_lb_13_4
 L  w_ub_13_4
 G  w_lb_13_5
 L  w_ub_13_5
 G  w_lb_13_6
 L  w_ub_13_6
 G  w_lb_13_7
 L  w_ub_13_7
 G  w_lb_13_8
 L  w_ub_13_8
 G  w_lb_13_9
 L  w_ub_13_9
 G  w_lb_13_10
 L  w_ub_13_10
 G  w_lb_13_11
 L  w_ub_13_11
 G  w_lb_13_12
 L  w_ub_13_12
 G  w_lb_13_13
 L  w_ub_13_13
 G  w_lb_13_14
 L  w_ub_13_14
 G  w_lb_13_15
 L  w_ub_13_15
 G  w_lb_13_16
 L  w_ub_13_16
 G  w_lb_13_17
 L  w_ub_13_17
 G  w_lb_13_18
 L  w_ub_13_18
 G  w_lb_13_19
 L  w_ub_13_19
 G  w_lb_13_20
 L  w_ub_13_20
 G  w_lb_13_21
 L  w_ub_13_21
 G  w_lb_13_22
 L  w_ub_13_22
 G  w_lb_13_23
 L  w_ub_13_23
 G  w_lb_13_24
 L  w_ub_13_24
 G  w_lb_13_25
 L  w_ub_13_25
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  w_lb_14_0
 L  w_ub_14_0
 G  w_lb_14_1
 L  w_ub_14_1
 G  w_lb_14_2
 L  w_ub_14_2
 G  w_lb_14_3
 L  w_ub_14_3
 G  w_lb_14_4
 L  w_ub_14_4
 G  w_lb_14_5
 L  w_ub_14_5
 G  w_lb_14_6
 L  w_ub_14_6
 G  w_lb_14_7
 L  w_ub_14_7
 G  w_lb_14_8
 L  w_ub_14_8
 G  w_lb_14_9
 L  w_ub_14_9
 G  w_lb_14_10
 L  w_ub_14_10
 G  w_lb_14_11
 L  w_ub_14_11
 G  w_lb_14_12
 L  w_ub_14_12
 G  w_lb_14_13
 L  w_ub_14_13
 G  w_lb_14_14
 L  w_ub_14_14
 G  w_lb_14_15
 L  w_ub_14_15
 G  w_lb_14_16
 L  w_ub_14_16
 G  w_lb_14_17
 L  w_ub_14_17
 G  w_lb_14_18
 L  w_ub_14_18
 G  w_lb_14_19
 L  w_ub_14_19
 G  w_lb_14_20
 L  w_ub_14_20
 G  w_lb_14_21
 L  w_ub_14_21
 G  w_lb_14_22
 L  w_ub_14_22
 G  w_lb_14_23
 L  w_ub_14_23
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  w_lb_15_0
 L  w_ub_15_0
 G  w_lb_15_1
 L  w_ub_15_1
 G  w_lb_15_2
 L  w_ub_15_2
 G  w_lb_15_3
 L  w_ub_15_3
 G  w_lb_15_4
 L  w_ub_15_4
 G  w_lb_15_5
 L  w_ub_15_5
 G  w_lb_15_6
 L  w_ub_15_6
 G  w_lb_15_7
 L  w_ub_15_7
 G  w_lb_15_8
 L  w_ub_15_8
 G  w_lb_15_9
 L  w_ub_15_9
 G  w_lb_15_10
 L  w_ub_15_10
 G  w_lb_15_11
 L  w_ub_15_11
 G  w_lb_15_12
 L  w_ub_15_12
 G  w_lb_15_13
 L  w_ub_15_13
 G  w_lb_15_14
 L  w_ub_15_14
 G  w_lb_15_15
 L  w_ub_15_15
 G  w_lb_15_16
 L  w_ub_15_16
 G  w_lb_15_17
 L  w_ub_15_17
 G  w_lb_15_18
 L  w_ub_15_18
 G  w_lb_15_19
 L  w_ub_15_19
 G  w_lb_15_20
 L  w_ub_15_20
 G  w_lb_15_21
 L  w_ub_15_21
 G  w_lb_15_22
 L  w_ub_15_22
 G  w_lb_15_23
 L  w_ub_15_23
 G  w_lb_15_24
 L  w_ub_15_24
 G  w_lb_15_25
 L  w_ub_15_25
 G  w_lb_15_26
 L  w_ub_15_26
 G  w_lb_15_27
 L  w_ub_15_27
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  w_lb_16_0
 L  w_ub_16_0
 G  w_lb_16_1
 L  w_ub_16_1
 G  w_lb_16_2
 L  w_ub_16_2
 G  w_lb_16_3
 L  w_ub_16_3
 G  w_lb_16_4
 L  w_ub_16_4
 G  w_lb_16_5
 L  w_ub_16_5
 G  w_lb_16_6
 L  w_ub_16_6
 G  w_lb_16_7
 L  w_ub_16_7
 G  w_lb_16_8
 L  w_ub_16_8
 G  w_lb_16_9
 L  w_ub_16_9
 G  w_lb_16_10
 L  w_ub_16_10
 G  w_lb_16_11
 L  w_ub_16_11
 G  w_lb_16_12
 L  w_ub_16_12
 G  w_lb_16_13
 L  w_ub_16_13
 G  w_lb_16_14
 L  w_ub_16_14
 G  w_lb_16_15
 L  w_ub_16_15
 G  w_lb_16_16
 L  w_ub_16_16
 G  w_lb_16_17
 L  w_ub_16_17
 G  w_lb_16_18
 L  w_ub_16_18
 G  w_lb_16_19
 L  w_ub_16_19
 G  w_lb_16_20
 L  w_ub_16_20
 G  w_lb_16_21
 L  w_ub_16_21
 G  w_lb_16_22
 L  w_ub_16_22
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  w_lb_17_0
 L  w_ub_17_0
 G  w_lb_17_1
 L  w_ub_17_1
 G  w_lb_17_2
 L  w_ub_17_2
 G  w_lb_17_3
 L  w_ub_17_3
 G  w_lb_17_4
 L  w_ub_17_4
 G  w_lb_17_5
 L  w_ub_17_5
 G  w_lb_17_6
 L  w_ub_17_6
 G  w_lb_17_7
 L  w_ub_17_7
 G  w_lb_17_8
 L  w_ub_17_8
 G  w_lb_17_9
 L  w_ub_17_9
 G  w_lb_17_10
 L  w_ub_17_10
 G  w_lb_17_11
 L  w_ub_17_11
 G  w_lb_17_12
 L  w_ub_17_12
 G  w_lb_17_13
 L  w_ub_17_13
 G  w_lb_17_14
 L  w_ub_17_14
 G  w_lb_17_15
 L  w_ub_17_15
 G  w_lb_17_16
 L  w_ub_17_16
 G  w_lb_17_17
 L  w_ub_17_17
 G  w_lb_17_18
 L  w_ub_17_18
 G  w_lb_17_19
 L  w_ub_17_19
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  w_lb_18_0
 L  w_ub_18_0
 G  w_lb_18_1
 L  w_ub_18_1
 G  w_lb_18_2
 L  w_ub_18_2
 G  w_lb_18_3
 L  w_ub_18_3
 G  w_lb_18_4
 L  w_ub_18_4
 G  w_lb_18_5
 L  w_ub_18_5
 G  w_lb_18_6
 L  w_ub_18_6
 G  w_lb_18_7
 L  w_ub_18_7
 G  w_lb_18_8
 L  w_ub_18_8
 G  w_lb_18_9
 L  w_ub_18_9
 G  w_lb_18_10
 L  w_ub_18_10
 G  w_lb_18_11
 L  w_ub_18_11
 G  w_lb_18_12
 L  w_ub_18_12
 G  w_lb_18_13
 L  w_ub_18_13
 G  w_lb_18_14
 L  w_ub_18_14
 G  w_lb_18_15
 L  w_ub_18_15
 G  w_lb_18_16
 L  w_ub_18_16
 G  w_lb_18_17
 L  w_ub_18_17
 G  w_lb_18_18
 L  w_ub_18_18
 G  w_lb_18_19
 L  w_ub_18_19
 G  w_lb_18_20
 L  w_ub_18_20
 G  w_lb_18_21
 L  w_ub_18_21
 G  w_lb_18_22
 L  w_ub_18_22
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  w_lb_19_0
 L  w_ub_19_0
 G  w_lb_19_1
 L  w_ub_19_1
 G  w_lb_19_2
 L  w_ub_19_2
 G  w_lb_19_3
 L  w_ub_19_3
 G  w_lb_19_4
 L  w_ub_19_4
 G  w_lb_19_5
 L  w_ub_19_5
 G  w_lb_19_6
 L  w_ub_19_6
 G  w_lb_19_7
 L  w_ub_19_7
 G  w_lb_19_8
 L  w_ub_19_8
 G  w_lb_19_9
 L  w_ub_19_9
 G  w_lb_19_10
 L  w_ub_19_10
 G  w_lb_19_11
 L  w_ub_19_11
 G  w_lb_19_12
 L  w_ub_19_12
 G  w_lb_19_13
 L  w_ub_19_13
 G  w_lb_19_14
 L  w_ub_19_14
 G  w_lb_19_15
 L  w_ub_19_15
 G  w_lb_19_16
 L  w_ub_19_16
 G  w_lb_19_17
 L  w_ub_19_17
 G  w_lb_19_18
 L  w_ub_19_18
 G  w_lb_19_19
 L  w_ub_19_19
 G  w_lb_19_20
 L  w_ub_19_20
 G  w_lb_19_21
 L  w_ub_19_21
 G  w_lb_19_22
 L  w_ub_19_22
 G  w_lb_19_23
 L  w_ub_19_23
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  w_lb_20_0
 L  w_ub_20_0
 G  w_lb_20_1
 L  w_ub_20_1
 G  w_lb_20_2
 L  w_ub_20_2
 G  w_lb_20_3
 L  w_ub_20_3
 G  w_lb_20_4
 L  w_ub_20_4
 G  w_lb_20_5
 L  w_ub_20_5
 G  w_lb_20_6
 L  w_ub_20_6
 G  w_lb_20_7
 L  w_ub_20_7
 G  w_lb_20_8
 L  w_ub_20_8
 G  w_lb_20_9
 L  w_ub_20_9
 G  w_lb_20_10
 L  w_ub_20_10
 G  w_lb_20_11
 L  w_ub_20_11
 G  w_lb_20_12
 L  w_ub_20_12
 G  w_lb_20_13
 L  w_ub_20_13
 G  w_lb_20_14
 L  w_ub_20_14
 G  w_lb_20_15
 L  w_ub_20_15
 G  w_lb_20_16
 L  w_ub_20_16
 G  w_lb_20_17
 L  w_ub_20_17
 G  w_lb_20_18
 L  w_ub_20_18
 G  w_lb_20_19
 L  w_ub_20_19
 G  w_lb_20_20
 L  w_ub_20_20
 G  w_lb_20_21
 L  w_ub_20_21
 G  w_lb_20_22
 L  w_ub_20_22
 G  w_lb_20_23
 L  w_ub_20_23
 E  normalized_inventory_20
 E  normalized_ratio_20
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_1_4
 G  abs_m_1_4
 G  abs_p_1_5
 G  abs_m_1_5
 G  abs_p_1_6
 G  abs_m_1_6
 G  abs_p_1_7
 G  abs_m_1_7
 G  abs_p_1_8
 G  abs_m_1_8
 G  abs_p_1_9
 G  abs_m_1_9
 G  abs_p_1_10
 G  abs_m_1_10
 G  abs_p_1_11
 G  abs_m_1_11
 G  abs_p_1_12
 G  abs_m_1_12
 G  abs_p_1_13
 G  abs_m_1_13
 G  abs_p_1_14
 G  abs_m_1_14
 G  abs_p_1_15
 G  abs_m_1_15
 G  abs_p_1_16
 G  abs_m_1_16
 G  abs_p_1_17
 G  abs_m_1_17
 G  abs_p_1_18
 G  abs_m_1_18
 G  abs_p_1_19
 G  abs_m_1_19
 G  abs_p_1_20
 G  abs_m_1_20
 G  abs_p_2_3
 G  abs_m_2_3
 G  abs_p_2_4
 G  abs_m_2_4
 G  abs_p_2_5
 G  abs_m_2_5
 G  abs_p_2_6
 G  abs_m_2_6
 G  abs_p_2_7
 G  abs_m_2_7
 G  abs_p_2_8
 G  abs_m_2_8
 G  abs_p_2_9
 G  abs_m_2_9
 G  abs_p_2_10
 G  abs_m_2_10
 G  abs_p_2_11
 G  abs_m_2_11
 G  abs_p_2_12
 G  abs_m_2_12
 G  abs_p_2_13
 G  abs_m_2_13
 G  abs_p_2_14
 G  abs_m_2_14
 G  abs_p_2_15
 G  abs_m_2_15
 G  abs_p_2_16
 G  abs_m_2_16
 G  abs_p_2_17
 G  abs_m_2_17
 G  abs_p_2_18
 G  abs_m_2_18
 G  abs_p_2_19
 G  abs_m_2_19
 G  abs_p_2_20
 G  abs_m_2_20
 G  abs_p_3_4
 G  abs_m_3_4
 G  abs_p_3_5
 G  abs_m_3_5
 G  abs_p_3_6
 G  abs_m_3_6
 G  abs_p_3_7
 G  abs_m_3_7
 G  abs_p_3_8
 G  abs_m_3_8
 G  abs_p_3_9
 G  abs_m_3_9
 G  abs_p_3_10
 G  abs_m_3_10
 G  abs_p_3_11
 G  abs_m_3_11
 G  abs_p_3_12
 G  abs_m_3_12
 G  abs_p_3_13
 G  abs_m_3_13
 G  abs_p_3_14
 G  abs_m_3_14
 G  abs_p_3_15
 G  abs_m_3_15
 G  abs_p_3_16
 G  abs_m_3_16
 G  abs_p_3_17
 G  abs_m_3_17
 G  abs_p_3_18
 G  abs_m_3_18
 G  abs_p_3_19
 G  abs_m_3_19
 G  abs_p_3_20
 G  abs_m_3_20
 G  abs_p_4_5
 G  abs_m_4_5
 G  abs_p_4_6
 G  abs_m_4_6
 G  abs_p_4_7
 G  abs_m_4_7
 G  abs_p_4_8
 G  abs_m_4_8
 G  abs_p_4_9
 G  abs_m_4_9
 G  abs_p_4_10
 G  abs_m_4_10
 G  abs_p_4_11
 G  abs_m_4_11
 G  abs_p_4_12
 G  abs_m_4_12
 G  abs_p_4_13
 G  abs_m_4_13
 G  abs_p_4_14
 G  abs_m_4_14
 G  abs_p_4_15
 G  abs_m_4_15
 G  abs_p_4_16
 G  abs_m_4_16
 G  abs_p_4_17
 G  abs_m_4_17
 G  abs_p_4_18
 G  abs_m_4_18
 G  abs_p_4_19
 G  abs_m_4_19
 G  abs_p_4_20
 G  abs_m_4_20
 G  abs_p_5_6
 G  abs_m_5_6
 G  abs_p_5_7
 G  abs_m_5_7
 G  abs_p_5_8
 G  abs_m_5_8
 G  abs_p_5_9
 G  abs_m_5_9
 G  abs_p_5_10
 G  abs_m_5_10
 G  abs_p_5_11
 G  abs_m_5_11
 G  abs_p_5_12
 G  abs_m_5_12
 G  abs_p_5_13
 G  abs_m_5_13
 G  abs_p_5_14
 G  abs_m_5_14
 G  abs_p_5_15
 G  abs_m_5_15
 G  abs_p_5_16
 G  abs_m_5_16
 G  abs_p_5_17
 G  abs_m_5_17
 G  abs_p_5_18
 G  abs_m_5_18
 G  abs_p_5_19
 G  abs_m_5_19
 G  abs_p_5_20
 G  abs_m_5_20
 G  abs_p_6_7
 G  abs_m_6_7
 G  abs_p_6_8
 G  abs_m_6_8
 G  abs_p_6_9
 G  abs_m_6_9
 G  abs_p_6_10
 G  abs_m_6_10
 G  abs_p_6_11
 G  abs_m_6_11
 G  abs_p_6_12
 G  abs_m_6_12
 G  abs_p_6_13
 G  abs_m_6_13
 G  abs_p_6_14
 G  abs_m_6_14
 G  abs_p_6_15
 G  abs_m_6_15
 G  abs_p_6_16
 G  abs_m_6_16
 G  abs_p_6_17
 G  abs_m_6_17
 G  abs_p_6_18
 G  abs_m_6_18
 G  abs_p_6_19
 G  abs_m_6_19
 G  abs_p_6_20
 G  abs_m_6_20
 G  abs_p_7_8
 G  abs_m_7_8
 G  abs_p_7_9
 G  abs_m_7_9
 G  abs_p_7_10
 G  abs_m_7_10
 G  abs_p_7_11
 G  abs_m_7_11
 G  abs_p_7_12
 G  abs_m_7_12
 G  abs_p_7_13
 G  abs_m_7_13
 G  abs_p_7_14
 G  abs_m_7_14
 G  abs_p_7_15
 G  abs_m_7_15
 G  abs_p_7_16
 G  abs_m_7_16
 G  abs_p_7_17
 G  abs_m_7_17
 G  abs_p_7_18
 G  abs_m_7_18
 G  abs_p_7_19
 G  abs_m_7_19
 G  abs_p_7_20
 G  abs_m_7_20
 G  abs_p_8_9
 G  abs_m_8_9
 G  abs_p_8_10
 G  abs_m_8_10
 G  abs_p_8_11
 G  abs_m_8_11
 G  abs_p_8_12
 G  abs_m_8_12
 G  abs_p_8_13
 G  abs_m_8_13
 G  abs_p_8_14
 G  abs_m_8_14
 G  abs_p_8_15
 G  abs_m_8_15
 G  abs_p_8_16
 G  abs_m_8_16
 G  abs_p_8_17
 G  abs_m_8_17
 G  abs_p_8_18
 G  abs_m_8_18
 G  abs_p_8_19
 G  abs_m_8_19
 G  abs_p_8_20
 G  abs_m_8_20
 G  abs_p_9_10
 G  abs_m_9_10
 G  abs_p_9_11
 G  abs_m_9_11
 G  abs_p_9_12
 G  abs_m_9_12
 G  abs_p_9_13
 G  abs_m_9_13
 G  abs_p_9_14
 G  abs_m_9_14
 G  abs_p_9_15
 G  abs_m_9_15
 G  abs_p_9_16
 G  abs_m_9_16
 G  abs_p_9_17
 G  abs_m_9_17
 G  abs_p_9_18
 G  abs_m_9_18
 G  abs_p_9_19
 G  abs_m_9_19
 G  abs_p_9_20
 G  abs_m_9_20
 G  abs_p_10_11
 G  abs_m_10_11
 G  abs_p_10_12
 G  abs_m_10_12
 G  abs_p_10_13
 G  abs_m_10_13
 G  abs_p_10_14
 G  abs_m_10_14
 G  abs_p_10_15
 G  abs_m_10_15
 G  abs_p_10_16
 G  abs_m_10_16
 G  abs_p_10_17
 G  abs_m_10_17
 G  abs_p_10_18
 G  abs_m_10_18
 G  abs_p_10_19
 G  abs_m_10_19
 G  abs_p_10_20
 G  abs_m_10_20
 G  abs_p_11_12
 G  abs_m_11_12
 G  abs_p_11_13
 G  abs_m_11_13
 G  abs_p_11_14
 G  abs_m_11_14
 G  abs_p_11_15
 G  abs_m_11_15
 G  abs_p_11_16
 G  abs_m_11_16
 G  abs_p_11_17
 G  abs_m_11_17
 G  abs_p_11_18
 G  abs_m_11_18
 G  abs_p_11_19
 G  abs_m_11_19
 G  abs_p_11_20
 G  abs_m_11_20
 G  abs_p_12_13
 G  abs_m_12_13
 G  abs_p_12_14
 G  abs_m_12_14
 G  abs_p_12_15
 G  abs_m_12_15
 G  abs_p_12_16
 G  abs_m_12_16
 G  abs_p_12_17
 G  abs_m_12_17
 G  abs_p_12_18
 G  abs_m_12_18
 G  abs_p_12_19
 G  abs_m_12_19
 G  abs_p_12_20
 G  abs_m_12_20
 G  abs_p_13_14
 G  abs_m_13_14
 G  abs_p_13_15
 G  abs_m_13_15
 G  abs_p_13_16
 G  abs_m_13_16
 G  abs_p_13_17
 G  abs_m_13_17
 G  abs_p_13_18
 G  abs_m_13_18
 G  abs_p_13_19
 G  abs_m_13_19
 G  abs_p_13_20
 G  abs_m_13_20
 G  abs_p_14_15
 G  abs_m_14_15
 G  abs_p_14_16
 G  abs_m_14_16
 G  abs_p_14_17
 G  abs_m_14_17
 G  abs_p_14_18
 G  abs_m_14_18
 G  abs_p_14_19
 G  abs_m_14_19
 G  abs_p_14_20
 G  abs_m_14_20
 G  abs_p_15_16
 G  abs_m_15_16
 G  abs_p_15_17
 G  abs_m_15_17
 G  abs_p_15_18
 G  abs_m_15_18
 G  abs_p_15_19
 G  abs_m_15_19
 G  abs_p_15_20
 G  abs_m_15_20
 G  abs_p_16_17
 G  abs_m_16_17
 G  abs_p_16_18
 G  abs_m_16_18
 G  abs_p_16_19
 G  abs_m_16_19
 G  abs_p_16_20
 G  abs_m_16_20
 G  abs_p_17_18
 G  abs_m_17_18
 G  abs_p_17_19
 G  abs_m_17_19
 G  abs_p_17_20
 G  abs_m_17_20
 G  abs_p_18_19
 G  abs_m_18_19
 G  abs_p_18_20
 G  abs_m_18_20
 G  abs_p_19_20
 G  abs_m_19_20
 L  true_G_epigraph
 L  physical_G_upper
 G  old_normalized_TC
 G  old_normalized_TC2
 G  old_TS1 
 G  old_TS2 
 L  old_TS3 
 L  old_TS4 
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       2.5692034090909081e-02
    x[1,0]    onehot_1  1
    x[1,0]    w_lb_1_0  -3.9145222845663033e-02
    x[1,0]    w_ub_1_0  -0.0680494916724233
    x[1,1]    OBJ       1.9982693181818174e-02
    x[1,1]    onehot_1  1
    x[1,1]    w_lb_1_1  -3.9145222845663033e-02
    x[1,1]    w_ub_1_1  -0.0680494916724233
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,1]    old_TS1   -3.9145222845663033e-02
    x[1,1]    old_TS2   -0.0680494916724233
    x[1,1]    old_TS3   -0.0680494916724233
    x[1,1]    old_TS4   -3.9145222845663033e-02
    x[1,2]    OBJ       1.4273352272727267e-02
    x[1,2]    onehot_1  1
    x[1,2]    w_lb_1_2  -3.9145222845663033e-02
    x[1,2]    w_ub_1_2  -0.0680494916724233
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,2]    old_TS1   -7.8290445691326066e-02
    x[1,2]    old_TS2   -1.3609898334484660e-01
    x[1,2]    old_TS3   -1.3609898334484660e-01
    x[1,2]    old_TS4   -7.8290445691326066e-02
    x[1,3]    OBJ       8.5640113636363587e-03
    x[1,3]    onehot_1  1
    x[1,3]    w_lb_1_3  -3.9145222845663033e-02
    x[1,3]    w_ub_1_3  -0.0680494916724233
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,3]    old_TS1   -1.1743566853698910e-01
    x[1,3]    old_TS2   -2.0414847501726990e-01
    x[1,3]    old_TS3   -2.0414847501726990e-01
    x[1,3]    old_TS4   -1.1743566853698910e-01
    x[1,4]    OBJ       2.8546704545454504e-03
    x[1,4]    onehot_1  1
    x[1,4]    w_lb_1_4  -3.9145222845663033e-02
    x[1,4]    w_ub_1_4  -0.0680494916724233
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,4]    old_TS1   -1.5658089138265213e-01
    x[1,4]    old_TS2   -2.7219796668969320e-01
    x[1,4]    old_TS3   -2.7219796668969320e-01
    x[1,4]    old_TS4   -1.5658089138265213e-01
    x[1,5]    OBJ       -2.8546704545454578e-03
    x[1,5]    onehot_1  1
    x[1,5]    w_lb_1_5  -3.9145222845663033e-02
    x[1,5]    w_ub_1_5  -0.0680494916724233
    x[1,5]    hard_lower  5
    x[1,5]    hard_upper  5
    x[1,5]    old_TS1   -1.9572611422831515e-01
    x[1,5]    old_TS2   -3.4024745836211651e-01
    x[1,5]    old_TS3   -3.4024745836211651e-01
    x[1,5]    old_TS4   -1.9572611422831515e-01
    x[1,6]    OBJ       -8.5640113636363674e-03
    x[1,6]    onehot_1  1
    x[1,6]    w_lb_1_6  -3.9145222845663033e-02
    x[1,6]    w_ub_1_6  -0.0680494916724233
    x[1,6]    hard_lower  6
    x[1,6]    hard_upper  6
    x[1,6]    old_TS1   -2.3487133707397820e-01
    x[1,6]    old_TS2   -4.0829695003453981e-01
    x[1,6]    old_TS3   -4.0829695003453981e-01
    x[1,6]    old_TS4   -2.3487133707397820e-01
    x[1,7]    OBJ       -1.4273352272727276e-02
    x[1,7]    onehot_1  1
    x[1,7]    w_lb_1_7  -3.9145222845663033e-02
    x[1,7]    w_ub_1_7  -0.0680494916724233
    x[1,7]    hard_lower  7
    x[1,7]    hard_upper  7
    x[1,7]    old_TS1   -2.7401655991964124e-01
    x[1,7]    old_TS2   -4.7634644170696311e-01
    x[1,7]    old_TS3   -4.7634644170696311e-01
    x[1,7]    old_TS4   -2.7401655991964124e-01
    x[1,8]    OBJ       -1.9982693181818185e-02
    x[1,8]    onehot_1  1
    x[1,8]    w_lb_1_8  -3.9145222845663033e-02
    x[1,8]    w_ub_1_8  -0.0680494916724233
    x[1,8]    hard_lower  8
    x[1,8]    hard_upper  8
    x[1,8]    old_TS1   -3.1316178276530426e-01
    x[1,8]    old_TS2   -5.4439593337938641e-01
    x[1,8]    old_TS3   -5.4439593337938641e-01
    x[1,8]    old_TS4   -3.1316178276530426e-01
    x[1,9]    OBJ       -2.5692034090909092e-02
    x[1,9]    onehot_1  1
    x[1,9]    w_lb_1_9  -3.9145222845663033e-02
    x[1,9]    w_ub_1_9  -0.0680494916724233
    x[1,9]    hard_lower  9
    x[1,9]    hard_upper  9
    x[1,9]    old_TS1   -3.5230700561096728e-01
    x[1,9]    old_TS2   -6.1244542505180966e-01
    x[1,9]    old_TS3   -6.1244542505180966e-01
    x[1,9]    old_TS4   -3.5230700561096728e-01
    x[1,10]   OBJ       -0.031401375
    x[1,10]   onehot_1  1
    x[1,10]   w_lb_1_10  -3.9145222845663033e-02
    x[1,10]   w_ub_1_10  -0.0680494916724233
    x[1,10]   hard_lower  10
    x[1,10]   hard_upper  10
    x[1,10]   old_TS1   -3.9145222845663030e-01
    x[1,10]   old_TS2   -0.680494916724233
    x[1,10]   old_TS3   -0.680494916724233
    x[1,10]   old_TS4   -3.9145222845663030e-01
    x[1,11]   OBJ       -3.7110715909090909e-02
    x[1,11]   onehot_1  1
    x[1,11]   w_lb_1_11  -3.9145222845663033e-02
    x[1,11]   w_ub_1_11  -0.0680494916724233
    x[1,11]   hard_lower  11
    x[1,11]   hard_upper  11
    x[1,11]   old_TS1   -4.3059745130229338e-01
    x[1,11]   old_TS2   -7.4854440839665637e-01
    x[1,11]   old_TS3   -7.4854440839665637e-01
    x[1,11]   old_TS4   -4.3059745130229338e-01
    x[1,12]   OBJ       -0.031401375
    x[1,12]   onehot_1  1
    x[1,12]   w_lb_1_12  -3.9145222845663033e-02
    x[1,12]   w_ub_1_12  -0.0680494916724233
    x[1,12]   hard_lower  12
    x[1,12]   hard_upper  12
    x[1,12]   old_TS1   -4.6974267414795640e-01
    x[1,12]   old_TS2   -8.1659390006907961e-01
    x[1,12]   old_TS3   -8.1659390006907961e-01
    x[1,12]   old_TS4   -4.6974267414795640e-01
    x[1,13]   OBJ       -2.5692034090909088e-02
    x[1,13]   onehot_1  1
    x[1,13]   w_lb_1_13  -3.9145222845663033e-02
    x[1,13]   w_ub_1_13  -0.0680494916724233
    x[1,13]   hard_lower  13
    x[1,13]   hard_upper  13
    x[1,13]   old_TS1   -5.0888789699361947e-01
    x[1,13]   old_TS2   -8.8464339174150286e-01
    x[1,13]   old_TS3   -8.8464339174150286e-01
    x[1,13]   old_TS4   -5.0888789699361947e-01
    x[1,14]   OBJ       -1.9982693181818181e-02
    x[1,14]   onehot_1  1
    x[1,14]   w_lb_1_14  -3.9145222845663033e-02
    x[1,14]   w_ub_1_14  -0.0680494916724233
    x[1,14]   hard_lower  14
    x[1,14]   hard_upper  14
    x[1,14]   old_TS1   -5.4803311983928249e-01
    x[1,14]   old_TS2   -9.5269288341392622e-01
    x[1,14]   old_TS3   -9.5269288341392622e-01
    x[1,14]   old_TS4   -5.4803311983928249e-01
    x[1,15]   OBJ       -1.4273352272727273e-02
    x[1,15]   onehot_1  1
    x[1,15]   w_lb_1_15  -3.9145222845663033e-02
    x[1,15]   w_ub_1_15  -0.0680494916724233
    x[1,15]   hard_lower  15
    x[1,15]   hard_upper  15
    x[1,15]   old_TS1   -5.8717834268494551e-01
    x[1,15]   old_TS2   -1.0207423750863496e+00
    x[1,15]   old_TS3   -1.0207423750863496e+00
    x[1,15]   old_TS4   -5.8717834268494551e-01
    x[1,16]   OBJ       -8.5640113636363639e-03
    x[1,16]   onehot_1  1
    x[1,16]   w_lb_1_16  -3.9145222845663033e-02
    x[1,16]   w_ub_1_16  -0.0680494916724233
    x[1,16]   hard_lower  16
    x[1,16]   hard_upper  16
    x[1,16]   old_TS1   -6.2632356553060853e-01
    x[1,16]   old_TS2   -1.0887918667587728e+00
    x[1,16]   old_TS3   -1.0887918667587728e+00
    x[1,16]   old_TS4   -6.2632356553060853e-01
    x[1,17]   OBJ       -2.8546704545454544e-03
    x[1,17]   onehot_1  1
    x[1,17]   w_lb_1_17  -3.9145222845663033e-02
    x[1,17]   w_ub_1_17  -0.0680494916724233
    x[1,17]   hard_lower  17
    x[1,17]   hard_upper  17
    x[1,17]   old_TS1   -6.6546878837627155e-01
    x[1,17]   old_TS2   -1.1568413584311961e+00
    x[1,17]   old_TS3   -1.1568413584311961e+00
    x[1,17]   old_TS4   -6.6546878837627155e-01
    x[1,18]   OBJ       2.8546704545454539e-03
    x[1,18]   onehot_1  1
    x[1,18]   w_lb_1_18  -3.9145222845663033e-02
    x[1,18]   w_ub_1_18  -0.0680494916724233
    x[1,18]   hard_lower  18
    x[1,18]   hard_upper  18
    x[1,18]   old_TS1   -7.0461401122193457e-01
    x[1,18]   old_TS2   -1.2248908501036193e+00
    x[1,18]   old_TS3   -1.2248908501036193e+00
    x[1,18]   old_TS4   -7.0461401122193457e-01
    x[1,19]   OBJ       8.5640113636363622e-03
    x[1,19]   onehot_1  1
    x[1,19]   w_lb_1_19  -3.9145222845663033e-02
    x[1,19]   w_ub_1_19  -0.0680494916724233
    x[1,19]   hard_lower  19
    x[1,19]   hard_upper  19
    x[1,19]   old_TS1   -7.4375923406759759e-01
    x[1,19]   old_TS2   -1.2929403417760428e+00
    x[1,19]   old_TS3   -1.2929403417760428e+00
    x[1,19]   old_TS4   -7.4375923406759759e-01
    x[1,20]   OBJ       1.4273352272727271e-02
    x[1,20]   onehot_1  1
    x[1,20]   w_lb_1_20  -3.9145222845663033e-02
    x[1,20]   w_ub_1_20  -0.0680494916724233
    x[1,20]   hard_lower  20
    x[1,20]   hard_upper  20
    x[1,20]   old_TS1   -7.8290445691326060e-01
    x[1,20]   old_TS2   -1.3609898334484660e+00
    x[1,20]   old_TS3   -1.3609898334484660e+00
    x[1,20]   old_TS4   -7.8290445691326060e-01
    x[1,21]   OBJ       1.9982693181818178e-02
    x[1,21]   onehot_1  1
    x[1,21]   w_lb_1_21  -3.9145222845663033e-02
    x[1,21]   w_ub_1_21  -0.0680494916724233
    x[1,21]   hard_lower  21
    x[1,21]   hard_upper  21
    x[1,21]   old_TS1   -8.2204967975892373e-01
    x[1,21]   old_TS2   -1.4290393251208893e+00
    x[1,21]   old_TS3   -1.4290393251208893e+00
    x[1,21]   old_TS4   -8.2204967975892373e-01
    x[1,22]   OBJ       2.5692034090909085e-02
    x[1,22]   onehot_1  1
    x[1,22]   w_lb_1_22  -3.9145222845663033e-02
    x[1,22]   w_ub_1_22  -0.0680494916724233
    x[1,22]   hard_lower  22
    x[1,22]   hard_upper  22
    x[1,22]   old_TS1   -8.6119490260458675e-01
    x[1,22]   old_TS2   -1.4970888167933127e+00
    x[1,22]   old_TS3   -1.4970888167933127e+00
    x[1,22]   old_TS4   -8.6119490260458675e-01
    x[1,23]   OBJ       3.1401374999999995e-02
    x[1,23]   onehot_1  1
    x[1,23]   w_lb_1_23  -3.9145222845663033e-02
    x[1,23]   w_ub_1_23  -0.0680494916724233
    x[1,23]   hard_lower  23
    x[1,23]   hard_upper  23
    x[1,23]   old_TS1   -9.0034012545024977e-01
    x[1,23]   old_TS2   -1.5651383084657360e+00
    x[1,23]   old_TS3   -1.5651383084657360e+00
    x[1,23]   old_TS4   -9.0034012545024977e-01
    x[1,24]   OBJ       0.0371107159090909
    x[1,24]   onehot_1  1
    x[1,24]   w_lb_1_24  -3.9145222845663033e-02
    x[1,24]   w_ub_1_24  -0.0680494916724233
    x[1,24]   hard_lower  24
    x[1,24]   hard_upper  24
    x[1,24]   old_TS1   -9.3948534829591279e-01
    x[1,24]   old_TS2   -1.6331878001381592e+00
    x[1,24]   old_TS3   -1.6331878001381592e+00
    x[1,24]   old_TS4   -9.3948534829591279e-01
    x[2,0]    OBJ       5.0865074999999996e-02
    x[2,0]    onehot_2  1
    x[2,0]    w_lb_2_0  -3.9145222845663033e-02
    x[2,0]    w_ub_2_0  -0.0680494916724233
    x[2,1]    OBJ       4.3598635714285711e-02
    x[2,1]    onehot_2  1
    x[2,1]    w_lb_2_1  -3.9145222845663033e-02
    x[2,1]    w_ub_2_1  -0.0680494916724233
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,1]    old_TS1   -3.9145222845663033e-02
    x[2,1]    old_TS2   -0.0680494916724233
    x[2,1]    old_TS3   -0.0680494916724233
    x[2,1]    old_TS4   -3.9145222845663033e-02
    x[2,2]    OBJ       3.6332196428571426e-02
    x[2,2]    onehot_2  1
    x[2,2]    w_lb_2_2  -3.9145222845663033e-02
    x[2,2]    w_ub_2_2  -0.0680494916724233
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,2]    old_TS1   -7.8290445691326066e-02
    x[2,2]    old_TS2   -1.3609898334484660e-01
    x[2,2]    old_TS3   -1.3609898334484660e-01
    x[2,2]    old_TS4   -7.8290445691326066e-02
    x[2,3]    OBJ       2.9065757142857140e-02
    x[2,3]    onehot_2  1
    x[2,3]    w_lb_2_3  -3.9145222845663033e-02
    x[2,3]    w_ub_2_3  -0.0680494916724233
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,3]    old_TS1   -1.1743566853698910e-01
    x[2,3]    old_TS2   -2.0414847501726990e-01
    x[2,3]    old_TS3   -2.0414847501726990e-01
    x[2,3]    old_TS4   -1.1743566853698910e-01
    x[2,4]    OBJ       2.1799317857142855e-02
    x[2,4]    onehot_2  1
    x[2,4]    w_lb_2_4  -3.9145222845663033e-02
    x[2,4]    w_ub_2_4  -0.0680494916724233
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,4]    old_TS1   -1.5658089138265213e-01
    x[2,4]    old_TS2   -2.7219796668969320e-01
    x[2,4]    old_TS3   -2.7219796668969320e-01
    x[2,4]    old_TS4   -1.5658089138265213e-01
    x[2,5]    OBJ       1.4532878571428570e-02
    x[2,5]    onehot_2  1
    x[2,5]    w_lb_2_5  -3.9145222845663033e-02
    x[2,5]    w_ub_2_5  -0.0680494916724233
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,5]    old_TS1   -1.9572611422831515e-01
    x[2,5]    old_TS2   -3.4024745836211651e-01
    x[2,5]    old_TS3   -3.4024745836211651e-01
    x[2,5]    old_TS4   -1.9572611422831515e-01
    x[2,6]    OBJ       7.2664392857142851e-03
    x[2,6]    onehot_2  1
    x[2,6]    w_lb_2_6  -3.9145222845663033e-02
    x[2,6]    w_ub_2_6  -0.0680494916724233
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,6]    old_TS1   -2.3487133707397820e-01
    x[2,6]    old_TS2   -4.0829695003453981e-01
    x[2,6]    old_TS3   -4.0829695003453981e-01
    x[2,6]    old_TS4   -2.3487133707397820e-01
    x[2,7]    onehot_2  1
    x[2,7]    w_lb_2_7  -3.9145222845663033e-02
    x[2,7]    w_ub_2_7  -0.0680494916724233
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,7]    old_TS1   -2.7401655991964124e-01
    x[2,7]    old_TS2   -4.7634644170696311e-01
    x[2,7]    old_TS3   -4.7634644170696311e-01
    x[2,7]    old_TS4   -2.7401655991964124e-01
    x[2,8]    OBJ       -7.2664392857142860e-03
    x[2,8]    onehot_2  1
    x[2,8]    w_lb_2_8  -3.9145222845663033e-02
    x[2,8]    w_ub_2_8  -0.0680494916724233
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,8]    old_TS1   -3.1316178276530426e-01
    x[2,8]    old_TS2   -5.4439593337938641e-01
    x[2,8]    old_TS3   -5.4439593337938641e-01
    x[2,8]    old_TS4   -3.1316178276530426e-01
    x[2,9]    OBJ       -1.4532878571428572e-02
    x[2,9]    onehot_2  1
    x[2,9]    w_lb_2_9  -3.9145222845663033e-02
    x[2,9]    w_ub_2_9  -0.0680494916724233
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,9]    old_TS1   -3.5230700561096728e-01
    x[2,9]    old_TS2   -6.1244542505180966e-01
    x[2,9]    old_TS3   -6.1244542505180966e-01
    x[2,9]    old_TS4   -3.5230700561096728e-01
    x[2,10]   OBJ       -2.1799317857142859e-02
    x[2,10]   onehot_2  1
    x[2,10]   w_lb_2_10  -3.9145222845663033e-02
    x[2,10]   w_ub_2_10  -0.0680494916724233
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,10]   old_TS1   -3.9145222845663030e-01
    x[2,10]   old_TS2   -0.680494916724233
    x[2,10]   old_TS3   -0.680494916724233
    x[2,10]   old_TS4   -3.9145222845663030e-01
    x[2,11]   OBJ       -2.9065757142857144e-02
    x[2,11]   onehot_2  1
    x[2,11]   w_lb_2_11  -3.9145222845663033e-02
    x[2,11]   w_ub_2_11  -0.0680494916724233
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,11]   old_TS1   -4.3059745130229338e-01
    x[2,11]   old_TS2   -7.4854440839665637e-01
    x[2,11]   old_TS3   -7.4854440839665637e-01
    x[2,11]   old_TS4   -4.3059745130229338e-01
    x[2,12]   OBJ       -3.6332196428571432e-02
    x[2,12]   onehot_2  1
    x[2,12]   w_lb_2_12  -3.9145222845663033e-02
    x[2,12]   w_ub_2_12  -0.0680494916724233
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,12]   old_TS1   -4.6974267414795640e-01
    x[2,12]   old_TS2   -8.1659390006907961e-01
    x[2,12]   old_TS3   -8.1659390006907961e-01
    x[2,12]   old_TS4   -4.6974267414795640e-01
    x[2,13]   OBJ       -4.3598635714285718e-02
    x[2,13]   onehot_2  1
    x[2,13]   w_lb_2_13  -3.9145222845663033e-02
    x[2,13]   w_ub_2_13  -0.0680494916724233
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,13]   old_TS1   -5.0888789699361947e-01
    x[2,13]   old_TS2   -8.8464339174150286e-01
    x[2,13]   old_TS3   -8.8464339174150286e-01
    x[2,13]   old_TS4   -5.0888789699361947e-01
    x[2,14]   OBJ       -0.050865075
    x[2,14]   onehot_2  1
    x[2,14]   w_lb_2_14  -3.9145222845663033e-02
    x[2,14]   w_ub_2_14  -0.0680494916724233
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,14]   old_TS1   -5.4803311983928249e-01
    x[2,14]   old_TS2   -9.5269288341392622e-01
    x[2,14]   old_TS3   -9.5269288341392622e-01
    x[2,14]   old_TS4   -5.4803311983928249e-01
    x[2,15]   OBJ       -4.3598635714285731e-02
    x[2,15]   onehot_2  1
    x[2,15]   w_lb_2_15  -3.9145222845663033e-02
    x[2,15]   w_ub_2_15  -0.0680494916724233
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[2,15]   old_TS1   -5.8717834268494551e-01
    x[2,15]   old_TS2   -1.0207423750863496e+00
    x[2,15]   old_TS3   -1.0207423750863496e+00
    x[2,15]   old_TS4   -5.8717834268494551e-01
    x[2,16]   OBJ       -3.6332196428571446e-02
    x[2,16]   onehot_2  1
    x[2,16]   w_lb_2_16  -3.9145222845663033e-02
    x[2,16]   w_ub_2_16  -0.0680494916724233
    x[2,16]   hard_lower  16
    x[2,16]   hard_upper  16
    x[2,16]   old_TS1   -6.2632356553060853e-01
    x[2,16]   old_TS2   -1.0887918667587728e+00
    x[2,16]   old_TS3   -1.0887918667587728e+00
    x[2,16]   old_TS4   -6.2632356553060853e-01
    x[2,17]   OBJ       -2.9065757142857154e-02
    x[2,17]   onehot_2  1
    x[2,17]   w_lb_2_17  -3.9145222845663033e-02
    x[2,17]   w_ub_2_17  -0.0680494916724233
    x[2,17]   hard_lower  17
    x[2,17]   hard_upper  17
    x[2,17]   old_TS1   -6.6546878837627155e-01
    x[2,17]   old_TS2   -1.1568413584311961e+00
    x[2,17]   old_TS3   -1.1568413584311961e+00
    x[2,17]   old_TS4   -6.6546878837627155e-01
    x[2,18]   OBJ       -2.1799317857142869e-02
    x[2,18]   onehot_2  1
    x[2,18]   w_lb_2_18  -3.9145222845663033e-02
    x[2,18]   w_ub_2_18  -0.0680494916724233
    x[2,18]   hard_lower  18
    x[2,18]   hard_upper  18
    x[2,18]   old_TS1   -7.0461401122193457e-01
    x[2,18]   old_TS2   -1.2248908501036193e+00
    x[2,18]   old_TS3   -1.2248908501036193e+00
    x[2,18]   old_TS4   -7.0461401122193457e-01
    x[2,19]   OBJ       -1.4532878571428584e-02
    x[2,19]   onehot_2  1
    x[2,19]   w_lb_2_19  -3.9145222845663033e-02
    x[2,19]   w_ub_2_19  -0.0680494916724233
    x[2,19]   hard_lower  19
    x[2,19]   hard_upper  19
    x[2,19]   old_TS1   -7.4375923406759759e-01
    x[2,19]   old_TS2   -1.2929403417760428e+00
    x[2,19]   old_TS3   -1.2929403417760428e+00
    x[2,19]   old_TS4   -7.4375923406759759e-01
    x[2,20]   OBJ       -7.2664392857142972e-03
    x[2,20]   onehot_2  1
    x[2,20]   w_lb_2_20  -3.9145222845663033e-02
    x[2,20]   w_ub_2_20  -0.0680494916724233
    x[2,20]   hard_lower  20
    x[2,20]   hard_upper  20
    x[2,20]   old_TS1   -7.8290445691326060e-01
    x[2,20]   old_TS2   -1.3609898334484660e+00
    x[2,20]   old_TS3   -1.3609898334484660e+00
    x[2,20]   old_TS4   -7.8290445691326060e-01
    x[2,21]   OBJ       -1.1294315482857087e-17
    x[2,21]   onehot_2  1
    x[2,21]   w_lb_2_21  -3.9145222845663033e-02
    x[2,21]   w_ub_2_21  -0.0680494916724233
    x[2,21]   hard_lower  21
    x[2,21]   hard_upper  21
    x[2,21]   old_TS1   -8.2204967975892373e-01
    x[2,21]   old_TS2   -1.4290393251208893e+00
    x[2,21]   old_TS3   -1.4290393251208893e+00
    x[2,21]   old_TS4   -8.2204967975892373e-01
    x[2,22]   OBJ       7.2664392857142738e-03
    x[2,22]   onehot_2  1
    x[2,22]   w_lb_2_22  -3.9145222845663033e-02
    x[2,22]   w_ub_2_22  -0.0680494916724233
    x[2,22]   hard_lower  22
    x[2,22]   hard_upper  22
    x[2,22]   old_TS1   -8.6119490260458675e-01
    x[2,22]   old_TS2   -1.4970888167933127e+00
    x[2,22]   old_TS3   -1.4970888167933127e+00
    x[2,22]   old_TS4   -8.6119490260458675e-01
    x[2,23]   OBJ       1.4532878571428560e-02
    x[2,23]   onehot_2  1
    x[2,23]   w_lb_2_23  -3.9145222845663033e-02
    x[2,23]   w_ub_2_23  -0.0680494916724233
    x[2,23]   hard_lower  23
    x[2,23]   hard_upper  23
    x[2,23]   old_TS1   -9.0034012545024977e-01
    x[2,23]   old_TS2   -1.5651383084657360e+00
    x[2,23]   old_TS3   -1.5651383084657360e+00
    x[2,23]   old_TS4   -9.0034012545024977e-01
    x[2,24]   OBJ       2.1799317857142845e-02
    x[2,24]   onehot_2  1
    x[2,24]   w_lb_2_24  -3.9145222845663033e-02
    x[2,24]   w_ub_2_24  -0.0680494916724233
    x[2,24]   hard_lower  24
    x[2,24]   hard_upper  24
    x[2,24]   old_TS1   -9.3948534829591279e-01
    x[2,24]   old_TS2   -1.6331878001381592e+00
    x[2,24]   old_TS3   -1.6331878001381592e+00
    x[2,24]   old_TS4   -9.3948534829591279e-01
    x[2,25]   OBJ       2.9065757142857130e-02
    x[2,25]   onehot_2  1
    x[2,25]   w_lb_2_25  -3.9145222845663033e-02
    x[2,25]   w_ub_2_25  -0.0680494916724233
    x[2,25]   hard_lower  25
    x[2,25]   hard_upper  25
    x[2,25]   old_TS1   -9.7863057114157581e-01
    x[2,25]   old_TS2   -1.7012372918105825e+00
    x[2,25]   old_TS3   -1.7012372918105825e+00
    x[2,25]   old_TS4   -9.7863057114157581e-01
    x[3,0]    OBJ       5.8391024999999992e-02
    x[3,0]    onehot_3  1
    x[3,0]    w_lb_3_0  -3.9145222845663033e-02
    x[3,0]    w_ub_3_0  -0.0680494916724233
    x[3,1]    OBJ       5.0605554999999997e-02
    x[3,1]    onehot_3  1
    x[3,1]    w_lb_3_1  -3.9145222845663033e-02
    x[3,1]    w_ub_3_1  -0.0680494916724233
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,1]    old_TS1   -3.9145222845663033e-02
    x[3,1]    old_TS2   -0.0680494916724233
    x[3,1]    old_TS3   -0.0680494916724233
    x[3,1]    old_TS4   -3.9145222845663033e-02
    x[3,2]    OBJ       4.2820084999999994e-02
    x[3,2]    onehot_3  1
    x[3,2]    w_lb_3_2  -3.9145222845663033e-02
    x[3,2]    w_ub_3_2  -0.0680494916724233
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,2]    old_TS1   -7.8290445691326066e-02
    x[3,2]    old_TS2   -1.3609898334484660e-01
    x[3,2]    old_TS3   -1.3609898334484660e-01
    x[3,2]    old_TS4   -7.8290445691326066e-02
    x[3,3]    OBJ       0.035034615
    x[3,3]    onehot_3  1
    x[3,3]    w_lb_3_3  -3.9145222845663033e-02
    x[3,3]    w_ub_3_3  -0.0680494916724233
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,3]    old_TS1   -1.1743566853698910e-01
    x[3,3]    old_TS2   -2.0414847501726990e-01
    x[3,3]    old_TS3   -2.0414847501726990e-01
    x[3,3]    old_TS4   -1.1743566853698910e-01
    x[3,4]    OBJ       0.027249145
    x[3,4]    onehot_3  1
    x[3,4]    w_lb_3_4  -3.9145222845663033e-02
    x[3,4]    w_ub_3_4  -0.0680494916724233
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    x[3,4]    old_TS1   -1.5658089138265213e-01
    x[3,4]    old_TS2   -2.7219796668969320e-01
    x[3,4]    old_TS3   -2.7219796668969320e-01
    x[3,4]    old_TS4   -1.5658089138265213e-01
    x[3,5]    OBJ       1.9463674999999996e-02
    x[3,5]    onehot_3  1
    x[3,5]    w_lb_3_5  -3.9145222845663033e-02
    x[3,5]    w_ub_3_5  -0.0680494916724233
    x[3,5]    hard_lower  5
    x[3,5]    hard_upper  5
    x[3,5]    old_TS1   -1.9572611422831515e-01
    x[3,5]    old_TS2   -3.4024745836211651e-01
    x[3,5]    old_TS3   -3.4024745836211651e-01
    x[3,5]    old_TS4   -1.9572611422831515e-01
    x[3,6]    OBJ       1.1678204999999999e-02
    x[3,6]    onehot_3  1
    x[3,6]    w_lb_3_6  -3.9145222845663033e-02
    x[3,6]    w_ub_3_6  -0.0680494916724233
    x[3,6]    hard_lower  6
    x[3,6]    hard_upper  6
    x[3,6]    old_TS1   -2.3487133707397820e-01
    x[3,6]    old_TS2   -4.0829695003453981e-01
    x[3,6]    old_TS3   -4.0829695003453981e-01
    x[3,6]    old_TS4   -2.3487133707397820e-01
    x[3,7]    OBJ       3.8927349999999996e-03
    x[3,7]    onehot_3  1
    x[3,7]    w_lb_3_7  -3.9145222845663033e-02
    x[3,7]    w_ub_3_7  -0.0680494916724233
    x[3,7]    hard_lower  7
    x[3,7]    hard_upper  7
    x[3,7]    old_TS1   -2.7401655991964124e-01
    x[3,7]    old_TS2   -4.7634644170696311e-01
    x[3,7]    old_TS3   -4.7634644170696311e-01
    x[3,7]    old_TS4   -2.7401655991964124e-01
    x[3,8]    OBJ       -0.003892735
    x[3,8]    onehot_3  1
    x[3,8]    w_lb_3_8  -3.9145222845663033e-02
    x[3,8]    w_ub_3_8  -0.0680494916724233
    x[3,8]    hard_lower  8
    x[3,8]    hard_upper  8
    x[3,8]    old_TS1   -3.1316178276530426e-01
    x[3,8]    old_TS2   -5.4439593337938641e-01
    x[3,8]    old_TS3   -5.4439593337938641e-01
    x[3,8]    old_TS4   -3.1316178276530426e-01
    x[3,9]    OBJ       -0.011678205
    x[3,9]    onehot_3  1
    x[3,9]    w_lb_3_9  -3.9145222845663033e-02
    x[3,9]    w_ub_3_9  -0.0680494916724233
    x[3,9]    hard_lower  9
    x[3,9]    hard_upper  9
    x[3,9]    old_TS1   -3.5230700561096728e-01
    x[3,9]    old_TS2   -6.1244542505180966e-01
    x[3,9]    old_TS3   -6.1244542505180966e-01
    x[3,9]    old_TS4   -3.5230700561096728e-01
    x[3,10]   OBJ       -0.019463675
    x[3,10]   onehot_3  1
    x[3,10]   w_lb_3_10  -3.9145222845663033e-02
    x[3,10]   w_ub_3_10  -0.0680494916724233
    x[3,10]   hard_lower  10
    x[3,10]   hard_upper  10
    x[3,10]   old_TS1   -3.9145222845663030e-01
    x[3,10]   old_TS2   -0.680494916724233
    x[3,10]   old_TS3   -0.680494916724233
    x[3,10]   old_TS4   -3.9145222845663030e-01
    x[3,11]   OBJ       -2.7249145000000002e-02
    x[3,11]   onehot_3  1
    x[3,11]   w_lb_3_11  -3.9145222845663033e-02
    x[3,11]   w_ub_3_11  -0.0680494916724233
    x[3,11]   hard_lower  11
    x[3,11]   hard_upper  11
    x[3,11]   old_TS1   -4.3059745130229338e-01
    x[3,11]   old_TS2   -7.4854440839665637e-01
    x[3,11]   old_TS3   -7.4854440839665637e-01
    x[3,11]   old_TS4   -4.3059745130229338e-01
    x[3,12]   OBJ       -3.5034615000000005e-02
    x[3,12]   onehot_3  1
    x[3,12]   w_lb_3_12  -3.9145222845663033e-02
    x[3,12]   w_ub_3_12  -0.0680494916724233
    x[3,12]   hard_lower  12
    x[3,12]   hard_upper  12
    x[3,12]   old_TS1   -4.6974267414795640e-01
    x[3,12]   old_TS2   -8.1659390006907961e-01
    x[3,12]   old_TS3   -8.1659390006907961e-01
    x[3,12]   old_TS4   -4.6974267414795640e-01
    x[3,13]   OBJ       -0.042820085
    x[3,13]   onehot_3  1
    x[3,13]   w_lb_3_13  -3.9145222845663033e-02
    x[3,13]   w_ub_3_13  -0.0680494916724233
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,13]   old_TS1   -5.0888789699361947e-01
    x[3,13]   old_TS2   -8.8464339174150286e-01
    x[3,13]   old_TS3   -8.8464339174150286e-01
    x[3,13]   old_TS4   -5.0888789699361947e-01
    x[3,14]   OBJ       -0.050605555
    x[3,14]   onehot_3  1
    x[3,14]   w_lb_3_14  -3.9145222845663033e-02
    x[3,14]   w_ub_3_14  -0.0680494916724233
    x[3,14]   hard_lower  14
    x[3,14]   hard_upper  14
    x[3,14]   old_TS1   -5.4803311983928249e-01
    x[3,14]   old_TS2   -9.5269288341392622e-01
    x[3,14]   old_TS3   -9.5269288341392622e-01
    x[3,14]   old_TS4   -5.4803311983928249e-01
    x[3,15]   OBJ       -0.058391025
    x[3,15]   onehot_3  1
    x[3,15]   w_lb_3_15  -3.9145222845663033e-02
    x[3,15]   w_ub_3_15  -0.0680494916724233
    x[3,15]   hard_lower  15
    x[3,15]   hard_upper  15
    x[3,15]   old_TS1   -5.8717834268494551e-01
    x[3,15]   old_TS2   -1.0207423750863496e+00
    x[3,15]   old_TS3   -1.0207423750863496e+00
    x[3,15]   old_TS4   -5.8717834268494551e-01
    x[3,16]   OBJ       -0.050605555
    x[3,16]   onehot_3  1
    x[3,16]   w_lb_3_16  -3.9145222845663033e-02
    x[3,16]   w_ub_3_16  -0.0680494916724233
    x[3,16]   hard_lower  16
    x[3,16]   hard_upper  16
    x[3,16]   old_TS1   -6.2632356553060853e-01
    x[3,16]   old_TS2   -1.0887918667587728e+00
    x[3,16]   old_TS3   -1.0887918667587728e+00
    x[3,16]   old_TS4   -6.2632356553060853e-01
    x[3,17]   OBJ       -4.2820085000000008e-02
    x[3,17]   onehot_3  1
    x[3,17]   w_lb_3_17  -3.9145222845663033e-02
    x[3,17]   w_ub_3_17  -0.0680494916724233
    x[3,17]   hard_lower  17
    x[3,17]   hard_upper  17
    x[3,17]   old_TS1   -6.6546878837627155e-01
    x[3,17]   old_TS2   -1.1568413584311961e+00
    x[3,17]   old_TS3   -1.1568413584311961e+00
    x[3,17]   old_TS4   -6.6546878837627155e-01
    x[3,18]   OBJ       -3.5034615000000005e-02
    x[3,18]   onehot_3  1
    x[3,18]   w_lb_3_18  -3.9145222845663033e-02
    x[3,18]   w_ub_3_18  -0.0680494916724233
    x[3,18]   hard_lower  18
    x[3,18]   hard_upper  18
    x[3,18]   old_TS1   -7.0461401122193457e-01
    x[3,18]   old_TS2   -1.2248908501036193e+00
    x[3,18]   old_TS3   -1.2248908501036193e+00
    x[3,18]   old_TS4   -7.0461401122193457e-01
    x[3,19]   OBJ       -2.7249145000000006e-02
    x[3,19]   onehot_3  1
    x[3,19]   w_lb_3_19  -3.9145222845663033e-02
    x[3,19]   w_ub_3_19  -0.0680494916724233
    x[3,19]   hard_lower  19
    x[3,19]   hard_upper  19
    x[3,19]   old_TS1   -7.4375923406759759e-01
    x[3,19]   old_TS2   -1.2929403417760428e+00
    x[3,19]   old_TS3   -1.2929403417760428e+00
    x[3,19]   old_TS4   -7.4375923406759759e-01
    x[3,20]   OBJ       -1.9463675000000003e-02
    x[3,20]   onehot_3  1
    x[3,20]   w_lb_3_20  -3.9145222845663033e-02
    x[3,20]   w_ub_3_20  -0.0680494916724233
    x[3,20]   hard_lower  20
    x[3,20]   hard_upper  20
    x[3,20]   old_TS1   -7.8290445691326060e-01
    x[3,20]   old_TS2   -1.3609898334484660e+00
    x[3,20]   old_TS3   -1.3609898334484660e+00
    x[3,20]   old_TS4   -7.8290445691326060e-01
    x[3,21]   OBJ       -1.1678205000000004e-02
    x[3,21]   onehot_3  1
    x[3,21]   w_lb_3_21  -3.9145222845663033e-02
    x[3,21]   w_ub_3_21  -0.0680494916724233
    x[3,21]   hard_lower  21
    x[3,21]   hard_upper  21
    x[3,21]   old_TS1   -8.2204967975892373e-01
    x[3,21]   old_TS2   -1.4290393251208893e+00
    x[3,21]   old_TS3   -1.4290393251208893e+00
    x[3,21]   old_TS4   -8.2204967975892373e-01
    x[3,22]   OBJ       -3.8927350000000035e-03
    x[3,22]   onehot_3  1
    x[3,22]   w_lb_3_22  -3.9145222845663033e-02
    x[3,22]   w_ub_3_22  -0.0680494916724233
    x[3,22]   hard_lower  22
    x[3,22]   hard_upper  22
    x[3,22]   old_TS1   -8.6119490260458675e-01
    x[3,22]   old_TS2   -1.4970888167933127e+00
    x[3,22]   old_TS3   -1.4970888167933127e+00
    x[3,22]   old_TS4   -8.6119490260458675e-01
    x[3,23]   OBJ       3.8927349999999966e-03
    x[3,23]   onehot_3  1
    x[3,23]   w_lb_3_23  -3.9145222845663033e-02
    x[3,23]   w_ub_3_23  -0.0680494916724233
    x[3,23]   hard_lower  23
    x[3,23]   hard_upper  23
    x[3,23]   old_TS1   -9.0034012545024977e-01
    x[3,23]   old_TS2   -1.5651383084657360e+00
    x[3,23]   old_TS3   -1.5651383084657360e+00
    x[3,23]   old_TS4   -9.0034012545024977e-01
    x[3,24]   OBJ       1.1678204999999995e-02
    x[3,24]   onehot_3  1
    x[3,24]   w_lb_3_24  -3.9145222845663033e-02
    x[3,24]   w_ub_3_24  -0.0680494916724233
    x[3,24]   hard_lower  24
    x[3,24]   hard_upper  24
    x[3,24]   old_TS1   -9.3948534829591279e-01
    x[3,24]   old_TS2   -1.6331878001381592e+00
    x[3,24]   old_TS3   -1.6331878001381592e+00
    x[3,24]   old_TS4   -9.3948534829591279e-01
    x[3,25]   OBJ       1.9463674999999993e-02
    x[3,25]   onehot_3  1
    x[3,25]   w_lb_3_25  -3.9145222845663033e-02
    x[3,25]   w_ub_3_25  -0.0680494916724233
    x[3,25]   hard_lower  25
    x[3,25]   hard_upper  25
    x[3,25]   old_TS1   -9.7863057114157581e-01
    x[3,25]   old_TS2   -1.7012372918105825e+00
    x[3,25]   old_TS3   -1.7012372918105825e+00
    x[3,25]   old_TS4   -9.7863057114157581e-01
    x[3,26]   OBJ       2.7249144999999995e-02
    x[3,26]   onehot_3  1
    x[3,26]   w_lb_3_26  -3.9145222845663033e-02
    x[3,26]   w_ub_3_26  -0.0680494916724233
    x[3,26]   hard_lower  26
    x[3,26]   hard_upper  26
    x[3,26]   old_TS1   -1.0177757939872389e+00
    x[3,26]   old_TS2   -1.7692867834830057e+00
    x[3,26]   old_TS3   -1.7692867834830057e+00
    x[3,26]   old_TS4   -1.0177757939872389e+00
    x[3,27]   OBJ       3.5034614999999991e-02
    x[3,27]   onehot_3  1
    x[3,27]   w_lb_3_27  -3.9145222845663033e-02
    x[3,27]   w_ub_3_27  -0.0680494916724233
    x[3,27]   hard_lower  27
    x[3,27]   hard_upper  27
    x[3,27]   old_TS1   -1.0569210168329020e+00
    x[3,27]   old_TS2   -1.8373362751554292e+00
    x[3,27]   old_TS3   -1.8373362751554292e+00
    x[3,27]   old_TS4   -1.0569210168329020e+00
    x[4,0]    OBJ       2.5692034090909081e-02
    x[4,0]    onehot_4  1
    x[4,0]    w_lb_4_0  -3.9145222845663033e-02
    x[4,0]    w_ub_4_0  -0.0680494916724233
    x[4,1]    OBJ       1.9982693181818174e-02
    x[4,1]    onehot_4  1
    x[4,1]    w_lb_4_1  -3.9145222845663033e-02
    x[4,1]    w_ub_4_1  -0.0680494916724233
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,1]    old_TS1   -3.9145222845663033e-02
    x[4,1]    old_TS2   -0.0680494916724233
    x[4,1]    old_TS3   -0.0680494916724233
    x[4,1]    old_TS4   -3.9145222845663033e-02
    x[4,2]    OBJ       1.4273352272727267e-02
    x[4,2]    onehot_4  1
    x[4,2]    w_lb_4_2  -3.9145222845663033e-02
    x[4,2]    w_ub_4_2  -0.0680494916724233
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,2]    old_TS1   -7.8290445691326066e-02
    x[4,2]    old_TS2   -1.3609898334484660e-01
    x[4,2]    old_TS3   -1.3609898334484660e-01
    x[4,2]    old_TS4   -7.8290445691326066e-02
    x[4,3]    OBJ       8.5640113636363587e-03
    x[4,3]    onehot_4  1
    x[4,3]    w_lb_4_3  -3.9145222845663033e-02
    x[4,3]    w_ub_4_3  -0.0680494916724233
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,3]    old_TS1   -1.1743566853698910e-01
    x[4,3]    old_TS2   -2.0414847501726990e-01
    x[4,3]    old_TS3   -2.0414847501726990e-01
    x[4,3]    old_TS4   -1.1743566853698910e-01
    x[4,4]    OBJ       2.8546704545454504e-03
    x[4,4]    onehot_4  1
    x[4,4]    w_lb_4_4  -3.9145222845663033e-02
    x[4,4]    w_ub_4_4  -0.0680494916724233
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,4]    old_TS1   -1.5658089138265213e-01
    x[4,4]    old_TS2   -2.7219796668969320e-01
    x[4,4]    old_TS3   -2.7219796668969320e-01
    x[4,4]    old_TS4   -1.5658089138265213e-01
    x[4,5]    OBJ       -2.8546704545454578e-03
    x[4,5]    onehot_4  1
    x[4,5]    w_lb_4_5  -3.9145222845663033e-02
    x[4,5]    w_ub_4_5  -0.0680494916724233
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,5]    old_TS1   -1.9572611422831515e-01
    x[4,5]    old_TS2   -3.4024745836211651e-01
    x[4,5]    old_TS3   -3.4024745836211651e-01
    x[4,5]    old_TS4   -1.9572611422831515e-01
    x[4,6]    OBJ       -8.5640113636363674e-03
    x[4,6]    onehot_4  1
    x[4,6]    w_lb_4_6  -3.9145222845663033e-02
    x[4,6]    w_ub_4_6  -0.0680494916724233
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,6]    old_TS1   -2.3487133707397820e-01
    x[4,6]    old_TS2   -4.0829695003453981e-01
    x[4,6]    old_TS3   -4.0829695003453981e-01
    x[4,6]    old_TS4   -2.3487133707397820e-01
    x[4,7]    OBJ       -1.4273352272727276e-02
    x[4,7]    onehot_4  1
    x[4,7]    w_lb_4_7  -3.9145222845663033e-02
    x[4,7]    w_ub_4_7  -0.0680494916724233
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,7]    old_TS1   -2.7401655991964124e-01
    x[4,7]    old_TS2   -4.7634644170696311e-01
    x[4,7]    old_TS3   -4.7634644170696311e-01
    x[4,7]    old_TS4   -2.7401655991964124e-01
    x[4,8]    OBJ       -1.9982693181818185e-02
    x[4,8]    onehot_4  1
    x[4,8]    w_lb_4_8  -3.9145222845663033e-02
    x[4,8]    w_ub_4_8  -0.0680494916724233
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,8]    old_TS1   -3.1316178276530426e-01
    x[4,8]    old_TS2   -5.4439593337938641e-01
    x[4,8]    old_TS3   -5.4439593337938641e-01
    x[4,8]    old_TS4   -3.1316178276530426e-01
    x[4,9]    OBJ       -2.5692034090909092e-02
    x[4,9]    onehot_4  1
    x[4,9]    w_lb_4_9  -3.9145222845663033e-02
    x[4,9]    w_ub_4_9  -0.0680494916724233
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,9]    old_TS1   -3.5230700561096728e-01
    x[4,9]    old_TS2   -6.1244542505180966e-01
    x[4,9]    old_TS3   -6.1244542505180966e-01
    x[4,9]    old_TS4   -3.5230700561096728e-01
    x[4,10]   OBJ       -0.031401375
    x[4,10]   onehot_4  1
    x[4,10]   w_lb_4_10  -3.9145222845663033e-02
    x[4,10]   w_ub_4_10  -0.0680494916724233
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,10]   old_TS1   -3.9145222845663030e-01
    x[4,10]   old_TS2   -0.680494916724233
    x[4,10]   old_TS3   -0.680494916724233
    x[4,10]   old_TS4   -3.9145222845663030e-01
    x[4,11]   OBJ       -3.7110715909090909e-02
    x[4,11]   onehot_4  1
    x[4,11]   w_lb_4_11  -3.9145222845663033e-02
    x[4,11]   w_ub_4_11  -0.0680494916724233
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,11]   old_TS1   -4.3059745130229338e-01
    x[4,11]   old_TS2   -7.4854440839665637e-01
    x[4,11]   old_TS3   -7.4854440839665637e-01
    x[4,11]   old_TS4   -4.3059745130229338e-01
    x[4,12]   OBJ       -0.031401375
    x[4,12]   onehot_4  1
    x[4,12]   w_lb_4_12  -3.9145222845663033e-02
    x[4,12]   w_ub_4_12  -0.0680494916724233
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,12]   old_TS1   -4.6974267414795640e-01
    x[4,12]   old_TS2   -8.1659390006907961e-01
    x[4,12]   old_TS3   -8.1659390006907961e-01
    x[4,12]   old_TS4   -4.6974267414795640e-01
    x[4,13]   OBJ       -2.5692034090909088e-02
    x[4,13]   onehot_4  1
    x[4,13]   w_lb_4_13  -3.9145222845663033e-02
    x[4,13]   w_ub_4_13  -0.0680494916724233
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,13]   old_TS1   -5.0888789699361947e-01
    x[4,13]   old_TS2   -8.8464339174150286e-01
    x[4,13]   old_TS3   -8.8464339174150286e-01
    x[4,13]   old_TS4   -5.0888789699361947e-01
    x[4,14]   OBJ       -1.9982693181818181e-02
    x[4,14]   onehot_4  1
    x[4,14]   w_lb_4_14  -3.9145222845663033e-02
    x[4,14]   w_ub_4_14  -0.0680494916724233
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,14]   old_TS1   -5.4803311983928249e-01
    x[4,14]   old_TS2   -9.5269288341392622e-01
    x[4,14]   old_TS3   -9.5269288341392622e-01
    x[4,14]   old_TS4   -5.4803311983928249e-01
    x[4,15]   OBJ       -1.4273352272727273e-02
    x[4,15]   onehot_4  1
    x[4,15]   w_lb_4_15  -3.9145222845663033e-02
    x[4,15]   w_ub_4_15  -0.0680494916724233
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[4,15]   old_TS1   -5.8717834268494551e-01
    x[4,15]   old_TS2   -1.0207423750863496e+00
    x[4,15]   old_TS3   -1.0207423750863496e+00
    x[4,15]   old_TS4   -5.8717834268494551e-01
    x[4,16]   OBJ       -8.5640113636363639e-03
    x[4,16]   onehot_4  1
    x[4,16]   w_lb_4_16  -3.9145222845663033e-02
    x[4,16]   w_ub_4_16  -0.0680494916724233
    x[4,16]   hard_lower  16
    x[4,16]   hard_upper  16
    x[4,16]   old_TS1   -6.2632356553060853e-01
    x[4,16]   old_TS2   -1.0887918667587728e+00
    x[4,16]   old_TS3   -1.0887918667587728e+00
    x[4,16]   old_TS4   -6.2632356553060853e-01
    x[4,17]   OBJ       -2.8546704545454544e-03
    x[4,17]   onehot_4  1
    x[4,17]   w_lb_4_17  -3.9145222845663033e-02
    x[4,17]   w_ub_4_17  -0.0680494916724233
    x[4,17]   hard_lower  17
    x[4,17]   hard_upper  17
    x[4,17]   old_TS1   -6.6546878837627155e-01
    x[4,17]   old_TS2   -1.1568413584311961e+00
    x[4,17]   old_TS3   -1.1568413584311961e+00
    x[4,17]   old_TS4   -6.6546878837627155e-01
    x[4,18]   OBJ       2.8546704545454539e-03
    x[4,18]   onehot_4  1
    x[4,18]   w_lb_4_18  -3.9145222845663033e-02
    x[4,18]   w_ub_4_18  -0.0680494916724233
    x[4,18]   hard_lower  18
    x[4,18]   hard_upper  18
    x[4,18]   old_TS1   -7.0461401122193457e-01
    x[4,18]   old_TS2   -1.2248908501036193e+00
    x[4,18]   old_TS3   -1.2248908501036193e+00
    x[4,18]   old_TS4   -7.0461401122193457e-01
    x[4,19]   OBJ       8.5640113636363622e-03
    x[4,19]   onehot_4  1
    x[4,19]   w_lb_4_19  -3.9145222845663033e-02
    x[4,19]   w_ub_4_19  -0.0680494916724233
    x[4,19]   hard_lower  19
    x[4,19]   hard_upper  19
    x[4,19]   old_TS1   -7.4375923406759759e-01
    x[4,19]   old_TS2   -1.2929403417760428e+00
    x[4,19]   old_TS3   -1.2929403417760428e+00
    x[4,19]   old_TS4   -7.4375923406759759e-01
    x[4,20]   OBJ       1.4273352272727271e-02
    x[4,20]   onehot_4  1
    x[4,20]   w_lb_4_20  -3.9145222845663033e-02
    x[4,20]   w_ub_4_20  -0.0680494916724233
    x[4,20]   hard_lower  20
    x[4,20]   hard_upper  20
    x[4,20]   old_TS1   -7.8290445691326060e-01
    x[4,20]   old_TS2   -1.3609898334484660e+00
    x[4,20]   old_TS3   -1.3609898334484660e+00
    x[4,20]   old_TS4   -7.8290445691326060e-01
    x[4,21]   OBJ       1.9982693181818178e-02
    x[4,21]   onehot_4  1
    x[4,21]   w_lb_4_21  -3.9145222845663033e-02
    x[4,21]   w_ub_4_21  -0.0680494916724233
    x[4,21]   hard_lower  21
    x[4,21]   hard_upper  21
    x[4,21]   old_TS1   -8.2204967975892373e-01
    x[4,21]   old_TS2   -1.4290393251208893e+00
    x[4,21]   old_TS3   -1.4290393251208893e+00
    x[4,21]   old_TS4   -8.2204967975892373e-01
    x[4,22]   OBJ       2.5692034090909085e-02
    x[4,22]   onehot_4  1
    x[4,22]   w_lb_4_22  -3.9145222845663033e-02
    x[4,22]   w_ub_4_22  -0.0680494916724233
    x[4,22]   hard_lower  22
    x[4,22]   hard_upper  22
    x[4,22]   old_TS1   -8.6119490260458675e-01
    x[4,22]   old_TS2   -1.4970888167933127e+00
    x[4,22]   old_TS3   -1.4970888167933127e+00
    x[4,22]   old_TS4   -8.6119490260458675e-01
    x[4,23]   OBJ       3.1401374999999995e-02
    x[4,23]   onehot_4  1
    x[4,23]   w_lb_4_23  -3.9145222845663033e-02
    x[4,23]   w_ub_4_23  -0.0680494916724233
    x[4,23]   hard_lower  23
    x[4,23]   hard_upper  23
    x[4,23]   old_TS1   -9.0034012545024977e-01
    x[4,23]   old_TS2   -1.5651383084657360e+00
    x[4,23]   old_TS3   -1.5651383084657360e+00
    x[4,23]   old_TS4   -9.0034012545024977e-01
    x[4,24]   OBJ       0.0371107159090909
    x[4,24]   onehot_4  1
    x[4,24]   w_lb_4_24  -3.9145222845663033e-02
    x[4,24]   w_ub_4_24  -0.0680494916724233
    x[4,24]   hard_lower  24
    x[4,24]   hard_upper  24
    x[4,24]   old_TS1   -9.3948534829591279e-01
    x[4,24]   old_TS2   -1.6331878001381592e+00
    x[4,24]   old_TS3   -1.6331878001381592e+00
    x[4,24]   old_TS4   -9.3948534829591279e-01
    x[5,0]    OBJ       3.1401374999999988e-02
    x[5,0]    onehot_5  1
    x[5,0]    w_lb_5_0  -3.9145222845663033e-02
    x[5,0]    w_ub_5_0  -0.0680494916724233
    x[5,1]    OBJ       2.5692034090909085e-02
    x[5,1]    onehot_5  1
    x[5,1]    w_lb_5_1  -3.9145222845663033e-02
    x[5,1]    w_ub_5_1  -0.0680494916724233
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,1]    old_TS1   -3.9145222845663033e-02
    x[5,1]    old_TS2   -0.0680494916724233
    x[5,1]    old_TS3   -0.0680494916724233
    x[5,1]    old_TS4   -3.9145222845663033e-02
    x[5,2]    OBJ       1.9982693181818174e-02
    x[5,2]    onehot_5  1
    x[5,2]    w_lb_5_2  -3.9145222845663033e-02
    x[5,2]    w_ub_5_2  -0.0680494916724233
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,2]    old_TS1   -7.8290445691326066e-02
    x[5,2]    old_TS2   -1.3609898334484660e-01
    x[5,2]    old_TS3   -1.3609898334484660e-01
    x[5,2]    old_TS4   -7.8290445691326066e-02
    x[5,3]    OBJ       1.4273352272727269e-02
    x[5,3]    onehot_5  1
    x[5,3]    w_lb_5_3  -3.9145222845663033e-02
    x[5,3]    w_ub_5_3  -0.0680494916724233
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,3]    old_TS1   -1.1743566853698910e-01
    x[5,3]    old_TS2   -2.0414847501726990e-01
    x[5,3]    old_TS3   -2.0414847501726990e-01
    x[5,3]    old_TS4   -1.1743566853698910e-01
    x[5,4]    OBJ       0.00856401136363636
    x[5,4]    onehot_5  1
    x[5,4]    w_lb_5_4  -3.9145222845663033e-02
    x[5,4]    w_ub_5_4  -0.0680494916724233
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,4]    old_TS1   -1.5658089138265213e-01
    x[5,4]    old_TS2   -2.7219796668969320e-01
    x[5,4]    old_TS3   -2.7219796668969320e-01
    x[5,4]    old_TS4   -1.5658089138265213e-01
    x[5,5]    OBJ       2.8546704545454522e-03
    x[5,5]    onehot_5  1
    x[5,5]    w_lb_5_5  -3.9145222845663033e-02
    x[5,5]    w_ub_5_5  -0.0680494916724233
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,5]    old_TS1   -1.9572611422831515e-01
    x[5,5]    old_TS2   -3.4024745836211651e-01
    x[5,5]    old_TS3   -3.4024745836211651e-01
    x[5,5]    old_TS4   -1.9572611422831515e-01
    x[5,6]    OBJ       -2.8546704545454561e-03
    x[5,6]    onehot_5  1
    x[5,6]    w_lb_5_6  -3.9145222845663033e-02
    x[5,6]    w_ub_5_6  -0.0680494916724233
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,6]    old_TS1   -2.3487133707397820e-01
    x[5,6]    old_TS2   -4.0829695003453981e-01
    x[5,6]    old_TS3   -4.0829695003453981e-01
    x[5,6]    old_TS4   -2.3487133707397820e-01
    x[5,7]    OBJ       -8.5640113636363657e-03
    x[5,7]    onehot_5  1
    x[5,7]    w_lb_5_7  -3.9145222845663033e-02
    x[5,7]    w_ub_5_7  -0.0680494916724233
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,7]    old_TS1   -2.7401655991964124e-01
    x[5,7]    old_TS2   -4.7634644170696311e-01
    x[5,7]    old_TS3   -4.7634644170696311e-01
    x[5,7]    old_TS4   -2.7401655991964124e-01
    x[5,8]    OBJ       -1.4273352272727274e-02
    x[5,8]    onehot_5  1
    x[5,8]    w_lb_5_8  -3.9145222845663033e-02
    x[5,8]    w_ub_5_8  -0.0680494916724233
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,8]    old_TS1   -3.1316178276530426e-01
    x[5,8]    old_TS2   -5.4439593337938641e-01
    x[5,8]    old_TS3   -5.4439593337938641e-01
    x[5,8]    old_TS4   -3.1316178276530426e-01
    x[5,9]    OBJ       -1.9982693181818181e-02
    x[5,9]    onehot_5  1
    x[5,9]    w_lb_5_9  -3.9145222845663033e-02
    x[5,9]    w_ub_5_9  -0.0680494916724233
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,9]    old_TS1   -3.5230700561096728e-01
    x[5,9]    old_TS2   -6.1244542505180966e-01
    x[5,9]    old_TS3   -6.1244542505180966e-01
    x[5,9]    old_TS4   -3.5230700561096728e-01
    x[5,10]   OBJ       -2.5692034090909092e-02
    x[5,10]   onehot_5  1
    x[5,10]   w_lb_5_10  -3.9145222845663033e-02
    x[5,10]   w_ub_5_10  -0.0680494916724233
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,10]   old_TS1   -3.9145222845663030e-01
    x[5,10]   old_TS2   -0.680494916724233
    x[5,10]   old_TS3   -0.680494916724233
    x[5,10]   old_TS4   -3.9145222845663030e-01
    x[5,11]   OBJ       -3.1401374999999995e-02
    x[5,11]   onehot_5  1
    x[5,11]   w_lb_5_11  -3.9145222845663033e-02
    x[5,11]   w_ub_5_11  -0.0680494916724233
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,11]   old_TS1   -4.3059745130229338e-01
    x[5,11]   old_TS2   -7.4854440839665637e-01
    x[5,11]   old_TS3   -7.4854440839665637e-01
    x[5,11]   old_TS4   -4.3059745130229338e-01
    x[5,12]   OBJ       -2.5692034090909088e-02
    x[5,12]   onehot_5  1
    x[5,12]   w_lb_5_12  -3.9145222845663033e-02
    x[5,12]   w_ub_5_12  -0.0680494916724233
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,12]   old_TS1   -4.6974267414795640e-01
    x[5,12]   old_TS2   -8.1659390006907961e-01
    x[5,12]   old_TS3   -8.1659390006907961e-01
    x[5,12]   old_TS4   -4.6974267414795640e-01
    x[5,13]   OBJ       -1.9982693181818178e-02
    x[5,13]   onehot_5  1
    x[5,13]   w_lb_5_13  -3.9145222845663033e-02
    x[5,13]   w_ub_5_13  -0.0680494916724233
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,13]   old_TS1   -5.0888789699361947e-01
    x[5,13]   old_TS2   -8.8464339174150286e-01
    x[5,13]   old_TS3   -8.8464339174150286e-01
    x[5,13]   old_TS4   -5.0888789699361947e-01
    x[5,14]   OBJ       -1.4273352272727271e-02
    x[5,14]   onehot_5  1
    x[5,14]   w_lb_5_14  -3.9145222845663033e-02
    x[5,14]   w_ub_5_14  -0.0680494916724233
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,14]   old_TS1   -5.4803311983928249e-01
    x[5,14]   old_TS2   -9.5269288341392622e-01
    x[5,14]   old_TS3   -9.5269288341392622e-01
    x[5,14]   old_TS4   -5.4803311983928249e-01
    x[5,15]   OBJ       -8.5640113636363622e-03
    x[5,15]   onehot_5  1
    x[5,15]   w_lb_5_15  -3.9145222845663033e-02
    x[5,15]   w_ub_5_15  -0.0680494916724233
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[5,15]   old_TS1   -5.8717834268494551e-01
    x[5,15]   old_TS2   -1.0207423750863496e+00
    x[5,15]   old_TS3   -1.0207423750863496e+00
    x[5,15]   old_TS4   -5.8717834268494551e-01
    x[5,16]   OBJ       -2.8546704545454526e-03
    x[5,16]   onehot_5  1
    x[5,16]   w_lb_5_16  -3.9145222845663033e-02
    x[5,16]   w_ub_5_16  -0.0680494916724233
    x[5,16]   hard_lower  16
    x[5,16]   hard_upper  16
    x[5,16]   old_TS1   -6.2632356553060853e-01
    x[5,16]   old_TS2   -1.0887918667587728e+00
    x[5,16]   old_TS3   -1.0887918667587728e+00
    x[5,16]   old_TS4   -6.2632356553060853e-01
    x[5,17]   OBJ       2.8546704545454557e-03
    x[5,17]   onehot_5  1
    x[5,17]   w_lb_5_17  -3.9145222845663033e-02
    x[5,17]   w_ub_5_17  -0.0680494916724233
    x[5,17]   hard_lower  17
    x[5,17]   hard_upper  17
    x[5,17]   old_TS1   -6.6546878837627155e-01
    x[5,17]   old_TS2   -1.1568413584311961e+00
    x[5,17]   old_TS3   -1.1568413584311961e+00
    x[5,17]   old_TS4   -6.6546878837627155e-01
    x[5,18]   OBJ       8.5640113636363639e-03
    x[5,18]   onehot_5  1
    x[5,18]   w_lb_5_18  -3.9145222845663033e-02
    x[5,18]   w_ub_5_18  -0.0680494916724233
    x[5,18]   hard_lower  18
    x[5,18]   hard_upper  18
    x[5,18]   old_TS1   -7.0461401122193457e-01
    x[5,18]   old_TS2   -1.2248908501036193e+00
    x[5,18]   old_TS3   -1.2248908501036193e+00
    x[5,18]   old_TS4   -7.0461401122193457e-01
    x[5,19]   OBJ       1.4273352272727273e-02
    x[5,19]   onehot_5  1
    x[5,19]   w_lb_5_19  -3.9145222845663033e-02
    x[5,19]   w_ub_5_19  -0.0680494916724233
    x[5,19]   hard_lower  19
    x[5,19]   hard_upper  19
    x[5,19]   old_TS1   -7.4375923406759759e-01
    x[5,19]   old_TS2   -1.2929403417760428e+00
    x[5,19]   old_TS3   -1.2929403417760428e+00
    x[5,19]   old_TS4   -7.4375923406759759e-01
    x[5,20]   OBJ       1.9982693181818178e-02
    x[5,20]   onehot_5  1
    x[5,20]   w_lb_5_20  -3.9145222845663033e-02
    x[5,20]   w_ub_5_20  -0.0680494916724233
    x[5,20]   hard_lower  20
    x[5,20]   hard_upper  20
    x[5,20]   old_TS1   -7.8290445691326060e-01
    x[5,20]   old_TS2   -1.3609898334484660e+00
    x[5,20]   old_TS3   -1.3609898334484660e+00
    x[5,20]   old_TS4   -7.8290445691326060e-01
    x[5,21]   OBJ       2.5692034090909088e-02
    x[5,21]   onehot_5  1
    x[5,21]   w_lb_5_21  -3.9145222845663033e-02
    x[5,21]   w_ub_5_21  -0.0680494916724233
    x[5,21]   hard_lower  21
    x[5,21]   hard_upper  21
    x[5,21]   old_TS1   -8.2204967975892373e-01
    x[5,21]   old_TS2   -1.4290393251208893e+00
    x[5,21]   old_TS3   -1.4290393251208893e+00
    x[5,21]   old_TS4   -8.2204967975892373e-01
    x[6,0]    OBJ       2.5692034090909081e-02
    x[6,0]    onehot_6  1
    x[6,0]    w_lb_6_0  -3.9145222845663033e-02
    x[6,0]    w_ub_6_0  -0.0680494916724233
    x[6,1]    OBJ       1.9982693181818174e-02
    x[6,1]    onehot_6  1
    x[6,1]    w_lb_6_1  -3.9145222845663033e-02
    x[6,1]    w_ub_6_1  -0.0680494916724233
    x[6,1]    hard_lower  1
    x[6,1]    hard_upper  1
    x[6,1]    old_TS1   -3.9145222845663033e-02
    x[6,1]    old_TS2   -0.0680494916724233
    x[6,1]    old_TS3   -0.0680494916724233
    x[6,1]    old_TS4   -3.9145222845663033e-02
    x[6,2]    OBJ       1.4273352272727267e-02
    x[6,2]    onehot_6  1
    x[6,2]    w_lb_6_2  -3.9145222845663033e-02
    x[6,2]    w_ub_6_2  -0.0680494916724233
    x[6,2]    hard_lower  2
    x[6,2]    hard_upper  2
    x[6,2]    old_TS1   -7.8290445691326066e-02
    x[6,2]    old_TS2   -1.3609898334484660e-01
    x[6,2]    old_TS3   -1.3609898334484660e-01
    x[6,2]    old_TS4   -7.8290445691326066e-02
    x[6,3]    OBJ       8.5640113636363587e-03
    x[6,3]    onehot_6  1
    x[6,3]    w_lb_6_3  -3.9145222845663033e-02
    x[6,3]    w_ub_6_3  -0.0680494916724233
    x[6,3]    hard_lower  3
    x[6,3]    hard_upper  3
    x[6,3]    old_TS1   -1.1743566853698910e-01
    x[6,3]    old_TS2   -2.0414847501726990e-01
    x[6,3]    old_TS3   -2.0414847501726990e-01
    x[6,3]    old_TS4   -1.1743566853698910e-01
    x[6,4]    OBJ       2.8546704545454504e-03
    x[6,4]    onehot_6  1
    x[6,4]    w_lb_6_4  -3.9145222845663033e-02
    x[6,4]    w_ub_6_4  -0.0680494916724233
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[6,4]    old_TS1   -1.5658089138265213e-01
    x[6,4]    old_TS2   -2.7219796668969320e-01
    x[6,4]    old_TS3   -2.7219796668969320e-01
    x[6,4]    old_TS4   -1.5658089138265213e-01
    x[6,5]    OBJ       -2.8546704545454578e-03
    x[6,5]    onehot_6  1
    x[6,5]    w_lb_6_5  -3.9145222845663033e-02
    x[6,5]    w_ub_6_5  -0.0680494916724233
    x[6,5]    hard_lower  5
    x[6,5]    hard_upper  5
    x[6,5]    old_TS1   -1.9572611422831515e-01
    x[6,5]    old_TS2   -3.4024745836211651e-01
    x[6,5]    old_TS3   -3.4024745836211651e-01
    x[6,5]    old_TS4   -1.9572611422831515e-01
    x[6,6]    OBJ       -8.5640113636363674e-03
    x[6,6]    onehot_6  1
    x[6,6]    w_lb_6_6  -3.9145222845663033e-02
    x[6,6]    w_ub_6_6  -0.0680494916724233
    x[6,6]    hard_lower  6
    x[6,6]    hard_upper  6
    x[6,6]    old_TS1   -2.3487133707397820e-01
    x[6,6]    old_TS2   -4.0829695003453981e-01
    x[6,6]    old_TS3   -4.0829695003453981e-01
    x[6,6]    old_TS4   -2.3487133707397820e-01
    x[6,7]    OBJ       -1.4273352272727276e-02
    x[6,7]    onehot_6  1
    x[6,7]    w_lb_6_7  -3.9145222845663033e-02
    x[6,7]    w_ub_6_7  -0.0680494916724233
    x[6,7]    hard_lower  7
    x[6,7]    hard_upper  7
    x[6,7]    old_TS1   -2.7401655991964124e-01
    x[6,7]    old_TS2   -4.7634644170696311e-01
    x[6,7]    old_TS3   -4.7634644170696311e-01
    x[6,7]    old_TS4   -2.7401655991964124e-01
    x[6,8]    OBJ       -1.9982693181818185e-02
    x[6,8]    onehot_6  1
    x[6,8]    w_lb_6_8  -3.9145222845663033e-02
    x[6,8]    w_ub_6_8  -0.0680494916724233
    x[6,8]    hard_lower  8
    x[6,8]    hard_upper  8
    x[6,8]    old_TS1   -3.1316178276530426e-01
    x[6,8]    old_TS2   -5.4439593337938641e-01
    x[6,8]    old_TS3   -5.4439593337938641e-01
    x[6,8]    old_TS4   -3.1316178276530426e-01
    x[6,9]    OBJ       -2.5692034090909092e-02
    x[6,9]    onehot_6  1
    x[6,9]    w_lb_6_9  -3.9145222845663033e-02
    x[6,9]    w_ub_6_9  -0.0680494916724233
    x[6,9]    hard_lower  9
    x[6,9]    hard_upper  9
    x[6,9]    old_TS1   -3.5230700561096728e-01
    x[6,9]    old_TS2   -6.1244542505180966e-01
    x[6,9]    old_TS3   -6.1244542505180966e-01
    x[6,9]    old_TS4   -3.5230700561096728e-01
    x[6,10]   OBJ       -0.031401375
    x[6,10]   onehot_6  1
    x[6,10]   w_lb_6_10  -3.9145222845663033e-02
    x[6,10]   w_ub_6_10  -0.0680494916724233
    x[6,10]   hard_lower  10
    x[6,10]   hard_upper  10
    x[6,10]   old_TS1   -3.9145222845663030e-01
    x[6,10]   old_TS2   -0.680494916724233
    x[6,10]   old_TS3   -0.680494916724233
    x[6,10]   old_TS4   -3.9145222845663030e-01
    x[6,11]   OBJ       -3.7110715909090909e-02
    x[6,11]   onehot_6  1
    x[6,11]   w_lb_6_11  -3.9145222845663033e-02
    x[6,11]   w_ub_6_11  -0.0680494916724233
    x[6,11]   hard_lower  11
    x[6,11]   hard_upper  11
    x[6,11]   old_TS1   -4.3059745130229338e-01
    x[6,11]   old_TS2   -7.4854440839665637e-01
    x[6,11]   old_TS3   -7.4854440839665637e-01
    x[6,11]   old_TS4   -4.3059745130229338e-01
    x[6,12]   OBJ       -0.031401375
    x[6,12]   onehot_6  1
    x[6,12]   w_lb_6_12  -3.9145222845663033e-02
    x[6,12]   w_ub_6_12  -0.0680494916724233
    x[6,12]   hard_lower  12
    x[6,12]   hard_upper  12
    x[6,12]   old_TS1   -4.6974267414795640e-01
    x[6,12]   old_TS2   -8.1659390006907961e-01
    x[6,12]   old_TS3   -8.1659390006907961e-01
    x[6,12]   old_TS4   -4.6974267414795640e-01
    x[6,13]   OBJ       -2.5692034090909088e-02
    x[6,13]   onehot_6  1
    x[6,13]   w_lb_6_13  -3.9145222845663033e-02
    x[6,13]   w_ub_6_13  -0.0680494916724233
    x[6,13]   hard_lower  13
    x[6,13]   hard_upper  13
    x[6,13]   old_TS1   -5.0888789699361947e-01
    x[6,13]   old_TS2   -8.8464339174150286e-01
    x[6,13]   old_TS3   -8.8464339174150286e-01
    x[6,13]   old_TS4   -5.0888789699361947e-01
    x[6,14]   OBJ       -1.9982693181818181e-02
    x[6,14]   onehot_6  1
    x[6,14]   w_lb_6_14  -3.9145222845663033e-02
    x[6,14]   w_ub_6_14  -0.0680494916724233
    x[6,14]   hard_lower  14
    x[6,14]   hard_upper  14
    x[6,14]   old_TS1   -5.4803311983928249e-01
    x[6,14]   old_TS2   -9.5269288341392622e-01
    x[6,14]   old_TS3   -9.5269288341392622e-01
    x[6,14]   old_TS4   -5.4803311983928249e-01
    x[6,15]   OBJ       -1.4273352272727273e-02
    x[6,15]   onehot_6  1
    x[6,15]   w_lb_6_15  -3.9145222845663033e-02
    x[6,15]   w_ub_6_15  -0.0680494916724233
    x[6,15]   hard_lower  15
    x[6,15]   hard_upper  15
    x[6,15]   old_TS1   -5.8717834268494551e-01
    x[6,15]   old_TS2   -1.0207423750863496e+00
    x[6,15]   old_TS3   -1.0207423750863496e+00
    x[6,15]   old_TS4   -5.8717834268494551e-01
    x[6,16]   OBJ       -8.5640113636363639e-03
    x[6,16]   onehot_6  1
    x[6,16]   w_lb_6_16  -3.9145222845663033e-02
    x[6,16]   w_ub_6_16  -0.0680494916724233
    x[6,16]   hard_lower  16
    x[6,16]   hard_upper  16
    x[6,16]   old_TS1   -6.2632356553060853e-01
    x[6,16]   old_TS2   -1.0887918667587728e+00
    x[6,16]   old_TS3   -1.0887918667587728e+00
    x[6,16]   old_TS4   -6.2632356553060853e-01
    x[6,17]   OBJ       -2.8546704545454544e-03
    x[6,17]   onehot_6  1
    x[6,17]   w_lb_6_17  -3.9145222845663033e-02
    x[6,17]   w_ub_6_17  -0.0680494916724233
    x[6,17]   hard_lower  17
    x[6,17]   hard_upper  17
    x[6,17]   old_TS1   -6.6546878837627155e-01
    x[6,17]   old_TS2   -1.1568413584311961e+00
    x[6,17]   old_TS3   -1.1568413584311961e+00
    x[6,17]   old_TS4   -6.6546878837627155e-01
    x[6,18]   OBJ       2.8546704545454539e-03
    x[6,18]   onehot_6  1
    x[6,18]   w_lb_6_18  -3.9145222845663033e-02
    x[6,18]   w_ub_6_18  -0.0680494916724233
    x[6,18]   hard_lower  18
    x[6,18]   hard_upper  18
    x[6,18]   old_TS1   -7.0461401122193457e-01
    x[6,18]   old_TS2   -1.2248908501036193e+00
    x[6,18]   old_TS3   -1.2248908501036193e+00
    x[6,18]   old_TS4   -7.0461401122193457e-01
    x[6,19]   OBJ       8.5640113636363622e-03
    x[6,19]   onehot_6  1
    x[6,19]   w_lb_6_19  -3.9145222845663033e-02
    x[6,19]   w_ub_6_19  -0.0680494916724233
    x[6,19]   hard_lower  19
    x[6,19]   hard_upper  19
    x[6,19]   old_TS1   -7.4375923406759759e-01
    x[6,19]   old_TS2   -1.2929403417760428e+00
    x[6,19]   old_TS3   -1.2929403417760428e+00
    x[6,19]   old_TS4   -7.4375923406759759e-01
    x[6,20]   OBJ       1.4273352272727271e-02
    x[6,20]   onehot_6  1
    x[6,20]   w_lb_6_20  -3.9145222845663033e-02
    x[6,20]   w_ub_6_20  -0.0680494916724233
    x[6,20]   hard_lower  20
    x[6,20]   hard_upper  20
    x[6,20]   old_TS1   -7.8290445691326060e-01
    x[6,20]   old_TS2   -1.3609898334484660e+00
    x[6,20]   old_TS3   -1.3609898334484660e+00
    x[6,20]   old_TS4   -7.8290445691326060e-01
    x[6,21]   OBJ       1.9982693181818178e-02
    x[6,21]   onehot_6  1
    x[6,21]   w_lb_6_21  -3.9145222845663033e-02
    x[6,21]   w_ub_6_21  -0.0680494916724233
    x[6,21]   hard_lower  21
    x[6,21]   hard_upper  21
    x[6,21]   old_TS1   -8.2204967975892373e-01
    x[6,21]   old_TS2   -1.4290393251208893e+00
    x[6,21]   old_TS3   -1.4290393251208893e+00
    x[6,21]   old_TS4   -8.2204967975892373e-01
    x[6,22]   OBJ       2.5692034090909085e-02
    x[6,22]   onehot_6  1
    x[6,22]   w_lb_6_22  -3.9145222845663033e-02
    x[6,22]   w_ub_6_22  -0.0680494916724233
    x[6,22]   hard_lower  22
    x[6,22]   hard_upper  22
    x[6,22]   old_TS1   -8.6119490260458675e-01
    x[6,22]   old_TS2   -1.4970888167933127e+00
    x[6,22]   old_TS3   -1.4970888167933127e+00
    x[6,22]   old_TS4   -8.6119490260458675e-01
    x[6,23]   OBJ       3.1401374999999995e-02
    x[6,23]   onehot_6  1
    x[6,23]   w_lb_6_23  -3.9145222845663033e-02
    x[6,23]   w_ub_6_23  -0.0680494916724233
    x[6,23]   hard_lower  23
    x[6,23]   hard_upper  23
    x[6,23]   old_TS1   -9.0034012545024977e-01
    x[6,23]   old_TS2   -1.5651383084657360e+00
    x[6,23]   old_TS3   -1.5651383084657360e+00
    x[6,23]   old_TS4   -9.0034012545024977e-01
    x[6,24]   OBJ       0.0371107159090909
    x[6,24]   onehot_6  1
    x[6,24]   w_lb_6_24  -3.9145222845663033e-02
    x[6,24]   w_ub_6_24  -0.0680494916724233
    x[6,24]   hard_lower  24
    x[6,24]   hard_upper  24
    x[6,24]   old_TS1   -9.3948534829591279e-01
    x[6,24]   old_TS2   -1.6331878001381592e+00
    x[6,24]   old_TS3   -1.6331878001381592e+00
    x[6,24]   old_TS4   -9.3948534829591279e-01
    x[7,0]    OBJ       2.0761259999999993e-02
    x[7,0]    onehot_7  1
    x[7,0]    w_lb_7_0  -3.9145222845663033e-02
    x[7,0]    w_ub_7_0  -0.0680494916724233
    x[7,1]    OBJ       1.5570944999999994e-02
    x[7,1]    onehot_7  1
    x[7,1]    w_lb_7_1  -3.9145222845663033e-02
    x[7,1]    w_ub_7_1  -0.0680494916724233
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,1]    old_TS1   -3.9145222845663033e-02
    x[7,1]    old_TS2   -0.0680494916724233
    x[7,1]    old_TS3   -0.0680494916724233
    x[7,1]    old_TS4   -3.9145222845663033e-02
    x[7,2]    OBJ       1.0380629999999995e-02
    x[7,2]    onehot_7  1
    x[7,2]    w_lb_7_2  -3.9145222845663033e-02
    x[7,2]    w_ub_7_2  -0.0680494916724233
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,2]    old_TS1   -7.8290445691326066e-02
    x[7,2]    old_TS2   -1.3609898334484660e-01
    x[7,2]    old_TS3   -1.3609898334484660e-01
    x[7,2]    old_TS4   -7.8290445691326066e-02
    x[7,3]    OBJ       5.1903149999999940e-03
    x[7,3]    onehot_7  1
    x[7,3]    w_lb_7_3  -3.9145222845663033e-02
    x[7,3]    w_ub_7_3  -0.0680494916724233
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,3]    old_TS1   -1.1743566853698910e-01
    x[7,3]    old_TS2   -2.0414847501726990e-01
    x[7,3]    old_TS3   -2.0414847501726990e-01
    x[7,3]    old_TS4   -1.1743566853698910e-01
    x[7,4]    OBJ       -5.7624072180573196e-18
    x[7,4]    onehot_7  1
    x[7,4]    w_lb_7_4  -3.9145222845663033e-02
    x[7,4]    w_ub_7_4  -0.0680494916724233
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,4]    old_TS1   -1.5658089138265213e-01
    x[7,4]    old_TS2   -2.7219796668969320e-01
    x[7,4]    old_TS3   -2.7219796668969320e-01
    x[7,4]    old_TS4   -1.5658089138265213e-01
    x[7,5]    OBJ       -5.1903150000000070e-03
    x[7,5]    onehot_7  1
    x[7,5]    w_lb_7_5  -3.9145222845663033e-02
    x[7,5]    w_ub_7_5  -0.0680494916724233
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,5]    old_TS1   -1.9572611422831515e-01
    x[7,5]    old_TS2   -3.4024745836211651e-01
    x[7,5]    old_TS3   -3.4024745836211651e-01
    x[7,5]    old_TS4   -1.9572611422831515e-01
    x[7,6]    OBJ       -1.0380630000000007e-02
    x[7,6]    onehot_7  1
    x[7,6]    w_lb_7_6  -3.9145222845663033e-02
    x[7,6]    w_ub_7_6  -0.0680494916724233
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,6]    old_TS1   -2.3487133707397820e-01
    x[7,6]    old_TS2   -4.0829695003453981e-01
    x[7,6]    old_TS3   -4.0829695003453981e-01
    x[7,6]    old_TS4   -2.3487133707397820e-01
    x[7,7]    OBJ       -1.5570945000000008e-02
    x[7,7]    onehot_7  1
    x[7,7]    w_lb_7_7  -3.9145222845663033e-02
    x[7,7]    w_ub_7_7  -0.0680494916724233
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,7]    old_TS1   -2.7401655991964124e-01
    x[7,7]    old_TS2   -4.7634644170696311e-01
    x[7,7]    old_TS3   -4.7634644170696311e-01
    x[7,7]    old_TS4   -2.7401655991964124e-01
    x[7,8]    OBJ       -2.0761260000000011e-02
    x[7,8]    onehot_7  1
    x[7,8]    w_lb_7_8  -3.9145222845663033e-02
    x[7,8]    w_ub_7_8  -0.0680494916724233
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,8]    old_TS1   -3.1316178276530426e-01
    x[7,8]    old_TS2   -5.4439593337938641e-01
    x[7,8]    old_TS3   -5.4439593337938641e-01
    x[7,8]    old_TS4   -3.1316178276530426e-01
    x[7,9]    OBJ       -2.5951575000000011e-02
    x[7,9]    onehot_7  1
    x[7,9]    w_lb_7_9  -3.9145222845663033e-02
    x[7,9]    w_ub_7_9  -0.0680494916724233
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,9]    old_TS1   -3.5230700561096728e-01
    x[7,9]    old_TS2   -6.1244542505180966e-01
    x[7,9]    old_TS3   -6.1244542505180966e-01
    x[7,9]    old_TS4   -3.5230700561096728e-01
    x[7,10]   OBJ       -3.1141890000000005e-02
    x[7,10]   onehot_7  1
    x[7,10]   w_lb_7_10  -3.9145222845663033e-02
    x[7,10]   w_ub_7_10  -0.0680494916724233
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,10]   old_TS1   -3.9145222845663030e-01
    x[7,10]   old_TS2   -0.680494916724233
    x[7,10]   old_TS3   -0.680494916724233
    x[7,10]   old_TS4   -3.9145222845663030e-01
    x[7,11]   OBJ       -2.5951575000000005e-02
    x[7,11]   onehot_7  1
    x[7,11]   w_lb_7_11  -3.9145222845663033e-02
    x[7,11]   w_ub_7_11  -0.0680494916724233
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,11]   old_TS1   -4.3059745130229338e-01
    x[7,11]   old_TS2   -7.4854440839665637e-01
    x[7,11]   old_TS3   -7.4854440839665637e-01
    x[7,11]   old_TS4   -4.3059745130229338e-01
    x[7,12]   OBJ       -2.0761260000000004e-02
    x[7,12]   onehot_7  1
    x[7,12]   w_lb_7_12  -3.9145222845663033e-02
    x[7,12]   w_ub_7_12  -0.0680494916724233
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,12]   old_TS1   -4.6974267414795640e-01
    x[7,12]   old_TS2   -8.1659390006907961e-01
    x[7,12]   old_TS3   -8.1659390006907961e-01
    x[7,12]   old_TS4   -4.6974267414795640e-01
    x[7,13]   OBJ       -1.5570945000000003e-02
    x[7,13]   onehot_7  1
    x[7,13]   w_lb_7_13  -3.9145222845663033e-02
    x[7,13]   w_ub_7_13  -0.0680494916724233
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,13]   old_TS1   -5.0888789699361947e-01
    x[7,13]   old_TS2   -8.8464339174150286e-01
    x[7,13]   old_TS3   -8.8464339174150286e-01
    x[7,13]   old_TS4   -5.0888789699361947e-01
    x[7,14]   OBJ       -1.0380630000000002e-02
    x[7,14]   onehot_7  1
    x[7,14]   w_lb_7_14  -3.9145222845663033e-02
    x[7,14]   w_ub_7_14  -0.0680494916724233
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,14]   old_TS1   -5.4803311983928249e-01
    x[7,14]   old_TS2   -9.5269288341392622e-01
    x[7,14]   old_TS3   -9.5269288341392622e-01
    x[7,14]   old_TS4   -5.4803311983928249e-01
    x[7,15]   OBJ       -5.1903150000000009e-03
    x[7,15]   onehot_7  1
    x[7,15]   w_lb_7_15  -3.9145222845663033e-02
    x[7,15]   w_ub_7_15  -0.0680494916724233
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,15]   old_TS1   -5.8717834268494551e-01
    x[7,15]   old_TS2   -1.0207423750863496e+00
    x[7,15]   old_TS3   -1.0207423750863496e+00
    x[7,15]   old_TS4   -5.8717834268494551e-01
    x[7,16]   onehot_7  1
    x[7,16]   w_lb_7_16  -3.9145222845663033e-02
    x[7,16]   w_ub_7_16  -0.0680494916724233
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,16]   old_TS1   -6.2632356553060853e-01
    x[7,16]   old_TS2   -1.0887918667587728e+00
    x[7,16]   old_TS3   -1.0887918667587728e+00
    x[7,16]   old_TS4   -6.2632356553060853e-01
    x[7,17]   OBJ       0.005190315
    x[7,17]   onehot_7  1
    x[7,17]   w_lb_7_17  -3.9145222845663033e-02
    x[7,17]   w_ub_7_17  -0.0680494916724233
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[7,17]   old_TS1   -6.6546878837627155e-01
    x[7,17]   old_TS2   -1.1568413584311961e+00
    x[7,17]   old_TS3   -1.1568413584311961e+00
    x[7,17]   old_TS4   -6.6546878837627155e-01
    x[7,18]   OBJ       0.01038063
    x[7,18]   onehot_7  1
    x[7,18]   w_lb_7_18  -3.9145222845663033e-02
    x[7,18]   w_ub_7_18  -0.0680494916724233
    x[7,18]   hard_lower  18
    x[7,18]   hard_upper  18
    x[7,18]   old_TS1   -7.0461401122193457e-01
    x[7,18]   old_TS2   -1.2248908501036193e+00
    x[7,18]   old_TS3   -1.2248908501036193e+00
    x[7,18]   old_TS4   -7.0461401122193457e-01
    x[7,19]   OBJ       1.5570945000000001e-02
    x[7,19]   onehot_7  1
    x[7,19]   w_lb_7_19  -3.9145222845663033e-02
    x[7,19]   w_ub_7_19  -0.0680494916724233
    x[7,19]   hard_lower  19
    x[7,19]   hard_upper  19
    x[7,19]   old_TS1   -7.4375923406759759e-01
    x[7,19]   old_TS2   -1.2929403417760428e+00
    x[7,19]   old_TS3   -1.2929403417760428e+00
    x[7,19]   old_TS4   -7.4375923406759759e-01
    x[7,20]   OBJ       0.02076126
    x[7,20]   onehot_7  1
    x[7,20]   w_lb_7_20  -3.9145222845663033e-02
    x[7,20]   w_ub_7_20  -0.0680494916724233
    x[7,20]   hard_lower  20
    x[7,20]   hard_upper  20
    x[7,20]   old_TS1   -7.8290445691326060e-01
    x[7,20]   old_TS2   -1.3609898334484660e+00
    x[7,20]   old_TS3   -1.3609898334484660e+00
    x[7,20]   old_TS4   -7.8290445691326060e-01
    x[7,21]   OBJ       0.025951575
    x[7,21]   onehot_7  1
    x[7,21]   w_lb_7_21  -3.9145222845663033e-02
    x[7,21]   w_ub_7_21  -0.0680494916724233
    x[7,21]   hard_lower  21
    x[7,21]   hard_upper  21
    x[7,21]   old_TS1   -8.2204967975892373e-01
    x[7,21]   old_TS2   -1.4290393251208893e+00
    x[7,21]   old_TS3   -1.4290393251208893e+00
    x[7,21]   old_TS4   -8.2204967975892373e-01
    x[7,22]   OBJ       3.1141890000000002e-02
    x[7,22]   onehot_7  1
    x[7,22]   w_lb_7_22  -3.9145222845663033e-02
    x[7,22]   w_ub_7_22  -0.0680494916724233
    x[7,22]   hard_lower  22
    x[7,22]   hard_upper  22
    x[7,22]   old_TS1   -8.6119490260458675e-01
    x[7,22]   old_TS2   -1.4970888167933127e+00
    x[7,22]   old_TS3   -1.4970888167933127e+00
    x[7,22]   old_TS4   -8.6119490260458675e-01
    x[8,0]    OBJ       3.1401374999999988e-02
    x[8,0]    onehot_8  1
    x[8,0]    w_lb_8_0  -3.9145222845663033e-02
    x[8,0]    w_ub_8_0  -0.0680494916724233
    x[8,1]    OBJ       2.5692034090909085e-02
    x[8,1]    onehot_8  1
    x[8,1]    w_lb_8_1  -3.9145222845663033e-02
    x[8,1]    w_ub_8_1  -0.0680494916724233
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,1]    old_TS1   -3.9145222845663033e-02
    x[8,1]    old_TS2   -0.0680494916724233
    x[8,1]    old_TS3   -0.0680494916724233
    x[8,1]    old_TS4   -3.9145222845663033e-02
    x[8,2]    OBJ       1.9982693181818174e-02
    x[8,2]    onehot_8  1
    x[8,2]    w_lb_8_2  -3.9145222845663033e-02
    x[8,2]    w_ub_8_2  -0.0680494916724233
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,2]    old_TS1   -7.8290445691326066e-02
    x[8,2]    old_TS2   -1.3609898334484660e-01
    x[8,2]    old_TS3   -1.3609898334484660e-01
    x[8,2]    old_TS4   -7.8290445691326066e-02
    x[8,3]    OBJ       1.4273352272727269e-02
    x[8,3]    onehot_8  1
    x[8,3]    w_lb_8_3  -3.9145222845663033e-02
    x[8,3]    w_ub_8_3  -0.0680494916724233
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,3]    old_TS1   -1.1743566853698910e-01
    x[8,3]    old_TS2   -2.0414847501726990e-01
    x[8,3]    old_TS3   -2.0414847501726990e-01
    x[8,3]    old_TS4   -1.1743566853698910e-01
    x[8,4]    OBJ       0.00856401136363636
    x[8,4]    onehot_8  1
    x[8,4]    w_lb_8_4  -3.9145222845663033e-02
    x[8,4]    w_ub_8_4  -0.0680494916724233
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,4]    old_TS1   -1.5658089138265213e-01
    x[8,4]    old_TS2   -2.7219796668969320e-01
    x[8,4]    old_TS3   -2.7219796668969320e-01
    x[8,4]    old_TS4   -1.5658089138265213e-01
    x[8,5]    OBJ       2.8546704545454522e-03
    x[8,5]    onehot_8  1
    x[8,5]    w_lb_8_5  -3.9145222845663033e-02
    x[8,5]    w_ub_8_5  -0.0680494916724233
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,5]    old_TS1   -1.9572611422831515e-01
    x[8,5]    old_TS2   -3.4024745836211651e-01
    x[8,5]    old_TS3   -3.4024745836211651e-01
    x[8,5]    old_TS4   -1.9572611422831515e-01
    x[8,6]    OBJ       -2.8546704545454561e-03
    x[8,6]    onehot_8  1
    x[8,6]    w_lb_8_6  -3.9145222845663033e-02
    x[8,6]    w_ub_8_6  -0.0680494916724233
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,6]    old_TS1   -2.3487133707397820e-01
    x[8,6]    old_TS2   -4.0829695003453981e-01
    x[8,6]    old_TS3   -4.0829695003453981e-01
    x[8,6]    old_TS4   -2.3487133707397820e-01
    x[8,7]    OBJ       -8.5640113636363657e-03
    x[8,7]    onehot_8  1
    x[8,7]    w_lb_8_7  -3.9145222845663033e-02
    x[8,7]    w_ub_8_7  -0.0680494916724233
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,7]    old_TS1   -2.7401655991964124e-01
    x[8,7]    old_TS2   -4.7634644170696311e-01
    x[8,7]    old_TS3   -4.7634644170696311e-01
    x[8,7]    old_TS4   -2.7401655991964124e-01
    x[8,8]    OBJ       -1.4273352272727274e-02
    x[8,8]    onehot_8  1
    x[8,8]    w_lb_8_8  -3.9145222845663033e-02
    x[8,8]    w_ub_8_8  -0.0680494916724233
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,8]    old_TS1   -3.1316178276530426e-01
    x[8,8]    old_TS2   -5.4439593337938641e-01
    x[8,8]    old_TS3   -5.4439593337938641e-01
    x[8,8]    old_TS4   -3.1316178276530426e-01
    x[8,9]    OBJ       -1.9982693181818181e-02
    x[8,9]    onehot_8  1
    x[8,9]    w_lb_8_9  -3.9145222845663033e-02
    x[8,9]    w_ub_8_9  -0.0680494916724233
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,9]    old_TS1   -3.5230700561096728e-01
    x[8,9]    old_TS2   -6.1244542505180966e-01
    x[8,9]    old_TS3   -6.1244542505180966e-01
    x[8,9]    old_TS4   -3.5230700561096728e-01
    x[8,10]   OBJ       -2.5692034090909092e-02
    x[8,10]   onehot_8  1
    x[8,10]   w_lb_8_10  -3.9145222845663033e-02
    x[8,10]   w_ub_8_10  -0.0680494916724233
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,10]   old_TS1   -3.9145222845663030e-01
    x[8,10]   old_TS2   -0.680494916724233
    x[8,10]   old_TS3   -0.680494916724233
    x[8,10]   old_TS4   -3.9145222845663030e-01
    x[8,11]   OBJ       -3.1401374999999995e-02
    x[8,11]   onehot_8  1
    x[8,11]   w_lb_8_11  -3.9145222845663033e-02
    x[8,11]   w_ub_8_11  -0.0680494916724233
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,11]   old_TS1   -4.3059745130229338e-01
    x[8,11]   old_TS2   -7.4854440839665637e-01
    x[8,11]   old_TS3   -7.4854440839665637e-01
    x[8,11]   old_TS4   -4.3059745130229338e-01
    x[8,12]   OBJ       -2.5692034090909088e-02
    x[8,12]   onehot_8  1
    x[8,12]   w_lb_8_12  -3.9145222845663033e-02
    x[8,12]   w_ub_8_12  -0.0680494916724233
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,12]   old_TS1   -4.6974267414795640e-01
    x[8,12]   old_TS2   -8.1659390006907961e-01
    x[8,12]   old_TS3   -8.1659390006907961e-01
    x[8,12]   old_TS4   -4.6974267414795640e-01
    x[8,13]   OBJ       -1.9982693181818178e-02
    x[8,13]   onehot_8  1
    x[8,13]   w_lb_8_13  -3.9145222845663033e-02
    x[8,13]   w_ub_8_13  -0.0680494916724233
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,13]   old_TS1   -5.0888789699361947e-01
    x[8,13]   old_TS2   -8.8464339174150286e-01
    x[8,13]   old_TS3   -8.8464339174150286e-01
    x[8,13]   old_TS4   -5.0888789699361947e-01
    x[8,14]   OBJ       -1.4273352272727271e-02
    x[8,14]   onehot_8  1
    x[8,14]   w_lb_8_14  -3.9145222845663033e-02
    x[8,14]   w_ub_8_14  -0.0680494916724233
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,14]   old_TS1   -5.4803311983928249e-01
    x[8,14]   old_TS2   -9.5269288341392622e-01
    x[8,14]   old_TS3   -9.5269288341392622e-01
    x[8,14]   old_TS4   -5.4803311983928249e-01
    x[8,15]   OBJ       -8.5640113636363622e-03
    x[8,15]   onehot_8  1
    x[8,15]   w_lb_8_15  -3.9145222845663033e-02
    x[8,15]   w_ub_8_15  -0.0680494916724233
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[8,15]   old_TS1   -5.8717834268494551e-01
    x[8,15]   old_TS2   -1.0207423750863496e+00
    x[8,15]   old_TS3   -1.0207423750863496e+00
    x[8,15]   old_TS4   -5.8717834268494551e-01
    x[8,16]   OBJ       -2.8546704545454526e-03
    x[8,16]   onehot_8  1
    x[8,16]   w_lb_8_16  -3.9145222845663033e-02
    x[8,16]   w_ub_8_16  -0.0680494916724233
    x[8,16]   hard_lower  16
    x[8,16]   hard_upper  16
    x[8,16]   old_TS1   -6.2632356553060853e-01
    x[8,16]   old_TS2   -1.0887918667587728e+00
    x[8,16]   old_TS3   -1.0887918667587728e+00
    x[8,16]   old_TS4   -6.2632356553060853e-01
    x[8,17]   OBJ       2.8546704545454557e-03
    x[8,17]   onehot_8  1
    x[8,17]   w_lb_8_17  -3.9145222845663033e-02
    x[8,17]   w_ub_8_17  -0.0680494916724233
    x[8,17]   hard_lower  17
    x[8,17]   hard_upper  17
    x[8,17]   old_TS1   -6.6546878837627155e-01
    x[8,17]   old_TS2   -1.1568413584311961e+00
    x[8,17]   old_TS3   -1.1568413584311961e+00
    x[8,17]   old_TS4   -6.6546878837627155e-01
    x[8,18]   OBJ       8.5640113636363639e-03
    x[8,18]   onehot_8  1
    x[8,18]   w_lb_8_18  -3.9145222845663033e-02
    x[8,18]   w_ub_8_18  -0.0680494916724233
    x[8,18]   hard_lower  18
    x[8,18]   hard_upper  18
    x[8,18]   old_TS1   -7.0461401122193457e-01
    x[8,18]   old_TS2   -1.2248908501036193e+00
    x[8,18]   old_TS3   -1.2248908501036193e+00
    x[8,18]   old_TS4   -7.0461401122193457e-01
    x[8,19]   OBJ       1.4273352272727273e-02
    x[8,19]   onehot_8  1
    x[8,19]   w_lb_8_19  -3.9145222845663033e-02
    x[8,19]   w_ub_8_19  -0.0680494916724233
    x[8,19]   hard_lower  19
    x[8,19]   hard_upper  19
    x[8,19]   old_TS1   -7.4375923406759759e-01
    x[8,19]   old_TS2   -1.2929403417760428e+00
    x[8,19]   old_TS3   -1.2929403417760428e+00
    x[8,19]   old_TS4   -7.4375923406759759e-01
    x[8,20]   OBJ       1.9982693181818178e-02
    x[8,20]   onehot_8  1
    x[8,20]   w_lb_8_20  -3.9145222845663033e-02
    x[8,20]   w_ub_8_20  -0.0680494916724233
    x[8,20]   hard_lower  20
    x[8,20]   hard_upper  20
    x[8,20]   old_TS1   -7.8290445691326060e-01
    x[8,20]   old_TS2   -1.3609898334484660e+00
    x[8,20]   old_TS3   -1.3609898334484660e+00
    x[8,20]   old_TS4   -7.8290445691326060e-01
    x[8,21]   OBJ       2.5692034090909088e-02
    x[8,21]   onehot_8  1
    x[8,21]   w_lb_8_21  -3.9145222845663033e-02
    x[8,21]   w_ub_8_21  -0.0680494916724233
    x[8,21]   hard_lower  21
    x[8,21]   hard_upper  21
    x[8,21]   old_TS1   -8.2204967975892373e-01
    x[8,21]   old_TS2   -1.4290393251208893e+00
    x[8,21]   old_TS3   -1.4290393251208893e+00
    x[8,21]   old_TS4   -8.2204967975892373e-01
    x[9,0]    OBJ       1.8685133333333333e-02
    x[9,0]    onehot_9  1
    x[9,0]    w_lb_9_0  -3.9145222845663033e-02
    x[9,0]    w_ub_9_0  -0.0680494916724233
    x[9,1]    OBJ       0.01401385
    x[9,1]    onehot_9  1
    x[9,1]    w_lb_9_1  -3.9145222845663033e-02
    x[9,1]    w_ub_9_1  -0.0680494916724233
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,1]    old_TS1   -3.9145222845663033e-02
    x[9,1]    old_TS2   -0.0680494916724233
    x[9,1]    old_TS3   -0.0680494916724233
    x[9,1]    old_TS4   -3.9145222845663033e-02
    x[9,2]    OBJ       9.3425666666666664e-03
    x[9,2]    onehot_9  1
    x[9,2]    w_lb_9_2  -3.9145222845663033e-02
    x[9,2]    w_ub_9_2  -0.0680494916724233
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,2]    old_TS1   -7.8290445691326066e-02
    x[9,2]    old_TS2   -1.3609898334484660e-01
    x[9,2]    old_TS3   -1.3609898334484660e-01
    x[9,2]    old_TS4   -7.8290445691326066e-02
    x[9,3]    OBJ       4.6712833333333349e-03
    x[9,3]    onehot_9  1
    x[9,3]    w_lb_9_3  -3.9145222845663033e-02
    x[9,3]    w_ub_9_3  -0.0680494916724233
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,3]    old_TS1   -1.1743566853698910e-01
    x[9,3]    old_TS2   -2.0414847501726990e-01
    x[9,3]    old_TS3   -2.0414847501726990e-01
    x[9,3]    old_TS4   -1.1743566853698910e-01
    x[9,4]    OBJ       2.3337748400464873e-18
    x[9,4]    onehot_9  1
    x[9,4]    w_lb_9_4  -3.9145222845663033e-02
    x[9,4]    w_ub_9_4  -0.0680494916724233
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,4]    old_TS1   -1.5658089138265213e-01
    x[9,4]    old_TS2   -2.7219796668969320e-01
    x[9,4]    old_TS3   -2.7219796668969320e-01
    x[9,4]    old_TS4   -1.5658089138265213e-01
    x[9,5]    OBJ       -4.6712833333333306e-03
    x[9,5]    onehot_9  1
    x[9,5]    w_lb_9_5  -3.9145222845663033e-02
    x[9,5]    w_ub_9_5  -0.0680494916724233
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,5]    old_TS1   -1.9572611422831515e-01
    x[9,5]    old_TS2   -3.4024745836211651e-01
    x[9,5]    old_TS3   -3.4024745836211651e-01
    x[9,5]    old_TS4   -1.9572611422831515e-01
    x[9,6]    OBJ       -9.3425666666666646e-03
    x[9,6]    onehot_9  1
    x[9,6]    w_lb_9_6  -3.9145222845663033e-02
    x[9,6]    w_ub_9_6  -0.0680494916724233
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,6]    old_TS1   -2.3487133707397820e-01
    x[9,6]    old_TS2   -4.0829695003453981e-01
    x[9,6]    old_TS3   -4.0829695003453981e-01
    x[9,6]    old_TS4   -2.3487133707397820e-01
    x[9,7]    OBJ       -1.4013849999999996e-02
    x[9,7]    onehot_9  1
    x[9,7]    w_lb_9_7  -3.9145222845663033e-02
    x[9,7]    w_ub_9_7  -0.0680494916724233
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,7]    old_TS1   -2.7401655991964124e-01
    x[9,7]    old_TS2   -4.7634644170696311e-01
    x[9,7]    old_TS3   -4.7634644170696311e-01
    x[9,7]    old_TS4   -2.7401655991964124e-01
    x[9,8]    OBJ       -1.8685133333333329e-02
    x[9,8]    onehot_9  1
    x[9,8]    w_lb_9_8  -3.9145222845663033e-02
    x[9,8]    w_ub_9_8  -0.0680494916724233
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,8]    old_TS1   -3.1316178276530426e-01
    x[9,8]    old_TS2   -5.4439593337938641e-01
    x[9,8]    old_TS3   -5.4439593337938641e-01
    x[9,8]    old_TS4   -3.1316178276530426e-01
    x[9,9]    OBJ       -2.3356416666666664e-02
    x[9,9]    onehot_9  1
    x[9,9]    w_lb_9_9  -3.9145222845663033e-02
    x[9,9]    w_ub_9_9  -0.0680494916724233
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,9]    old_TS1   -3.5230700561096728e-01
    x[9,9]    old_TS2   -6.1244542505180966e-01
    x[9,9]    old_TS3   -6.1244542505180966e-01
    x[9,9]    old_TS4   -3.5230700561096728e-01
    x[9,10]   OBJ       -1.8685133333333336e-02
    x[9,10]   onehot_9  1
    x[9,10]   w_lb_9_10  -3.9145222845663033e-02
    x[9,10]   w_ub_9_10  -0.0680494916724233
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,10]   old_TS1   -3.9145222845663030e-01
    x[9,10]   old_TS2   -0.680494916724233
    x[9,10]   old_TS3   -0.680494916724233
    x[9,10]   old_TS4   -3.9145222845663030e-01
    x[9,11]   OBJ       -1.4013850000000001e-02
    x[9,11]   onehot_9  1
    x[9,11]   w_lb_9_11  -3.9145222845663033e-02
    x[9,11]   w_ub_9_11  -0.0680494916724233
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,11]   old_TS1   -4.3059745130229338e-01
    x[9,11]   old_TS2   -7.4854440839665637e-01
    x[9,11]   old_TS3   -7.4854440839665637e-01
    x[9,11]   old_TS4   -4.3059745130229338e-01
    x[9,12]   OBJ       -9.3425666666666681e-03
    x[9,12]   onehot_9  1
    x[9,12]   w_lb_9_12  -3.9145222845663033e-02
    x[9,12]   w_ub_9_12  -0.0680494916724233
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[9,12]   old_TS1   -4.6974267414795640e-01
    x[9,12]   old_TS2   -8.1659390006907961e-01
    x[9,12]   old_TS3   -8.1659390006907961e-01
    x[9,12]   old_TS4   -4.6974267414795640e-01
    x[9,13]   OBJ       -4.6712833333333358e-03
    x[9,13]   onehot_9  1
    x[9,13]   w_lb_9_13  -3.9145222845663033e-02
    x[9,13]   w_ub_9_13  -0.0680494916724233
    x[9,13]   hard_lower  13
    x[9,13]   hard_upper  13
    x[9,13]   old_TS1   -5.0888789699361947e-01
    x[9,13]   old_TS2   -8.8464339174150286e-01
    x[9,13]   old_TS3   -8.8464339174150286e-01
    x[9,13]   old_TS4   -5.0888789699361947e-01
    x[9,14]   OBJ       -2.3337748400464873e-18
    x[9,14]   onehot_9  1
    x[9,14]   w_lb_9_14  -3.9145222845663033e-02
    x[9,14]   w_ub_9_14  -0.0680494916724233
    x[9,14]   hard_lower  14
    x[9,14]   hard_upper  14
    x[9,14]   old_TS1   -5.4803311983928249e-01
    x[9,14]   old_TS2   -9.5269288341392622e-01
    x[9,14]   old_TS3   -9.5269288341392622e-01
    x[9,14]   old_TS4   -5.4803311983928249e-01
    x[9,15]   OBJ       0.00467128333333333
    x[9,15]   onehot_9  1
    x[9,15]   w_lb_9_15  -3.9145222845663033e-02
    x[9,15]   w_ub_9_15  -0.0680494916724233
    x[9,15]   hard_lower  15
    x[9,15]   hard_upper  15
    x[9,15]   old_TS1   -5.8717834268494551e-01
    x[9,15]   old_TS2   -1.0207423750863496e+00
    x[9,15]   old_TS3   -1.0207423750863496e+00
    x[9,15]   old_TS4   -5.8717834268494551e-01
    x[9,16]   OBJ       9.3425666666666629e-03
    x[9,16]   onehot_9  1
    x[9,16]   w_lb_9_16  -3.9145222845663033e-02
    x[9,16]   w_ub_9_16  -0.0680494916724233
    x[9,16]   hard_lower  16
    x[9,16]   hard_upper  16
    x[9,16]   old_TS1   -6.2632356553060853e-01
    x[9,16]   old_TS2   -1.0887918667587728e+00
    x[9,16]   old_TS3   -1.0887918667587728e+00
    x[9,16]   old_TS4   -6.2632356553060853e-01
    x[9,17]   OBJ       1.4013849999999994e-02
    x[9,17]   onehot_9  1
    x[9,17]   w_lb_9_17  -3.9145222845663033e-02
    x[9,17]   w_ub_9_17  -0.0680494916724233
    x[9,17]   hard_lower  17
    x[9,17]   hard_upper  17
    x[9,17]   old_TS1   -6.6546878837627155e-01
    x[9,17]   old_TS2   -1.1568413584311961e+00
    x[9,17]   old_TS3   -1.1568413584311961e+00
    x[9,17]   old_TS4   -6.6546878837627155e-01
    x[9,18]   OBJ       1.8685133333333326e-02
    x[9,18]   onehot_9  1
    x[9,18]   w_lb_9_18  -3.9145222845663033e-02
    x[9,18]   w_ub_9_18  -0.0680494916724233
    x[9,18]   hard_lower  18
    x[9,18]   hard_upper  18
    x[9,18]   old_TS1   -7.0461401122193457e-01
    x[9,18]   old_TS2   -1.2248908501036193e+00
    x[9,18]   old_TS3   -1.2248908501036193e+00
    x[9,18]   old_TS4   -7.0461401122193457e-01
    x[9,19]   OBJ       2.3356416666666661e-02
    x[9,19]   onehot_9  1
    x[9,19]   w_lb_9_19  -3.9145222845663033e-02
    x[9,19]   w_ub_9_19  -0.0680494916724233
    x[9,19]   hard_lower  19
    x[9,19]   hard_upper  19
    x[9,19]   old_TS1   -7.4375923406759759e-01
    x[9,19]   old_TS2   -1.2929403417760428e+00
    x[9,19]   old_TS3   -1.2929403417760428e+00
    x[9,19]   old_TS4   -7.4375923406759759e-01
    x[10,0]   OBJ       0.066435975
    x[10,0]   onehot_10  1
    x[10,0]   w_lb_10_0  -3.9145222845663033e-02
    x[10,0]   w_ub_10_0  -0.0680494916724233
    x[10,1]   OBJ       5.8131478124999990e-02
    x[10,1]   onehot_10  1
    x[10,1]   w_lb_10_1  -3.9145222845663033e-02
    x[10,1]   w_ub_10_1  -0.0680494916724233
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,1]   old_TS1   -3.9145222845663033e-02
    x[10,1]   old_TS2   -0.0680494916724233
    x[10,1]   old_TS3   -0.0680494916724233
    x[10,1]   old_TS4   -3.9145222845663033e-02
    x[10,2]   OBJ       4.9826981249999992e-02
    x[10,2]   onehot_10  1
    x[10,2]   w_lb_10_2  -3.9145222845663033e-02
    x[10,2]   w_ub_10_2  -0.0680494916724233
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,2]   old_TS1   -7.8290445691326066e-02
    x[10,2]   old_TS2   -1.3609898334484660e-01
    x[10,2]   old_TS3   -1.3609898334484660e-01
    x[10,2]   old_TS4   -7.8290445691326066e-02
    x[10,3]   OBJ       4.1522484374999995e-02
    x[10,3]   onehot_10  1
    x[10,3]   w_lb_10_3  -3.9145222845663033e-02
    x[10,3]   w_ub_10_3  -0.0680494916724233
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,3]   old_TS1   -1.1743566853698910e-01
    x[10,3]   old_TS2   -2.0414847501726990e-01
    x[10,3]   old_TS3   -2.0414847501726990e-01
    x[10,3]   old_TS4   -1.1743566853698910e-01
    x[10,4]   OBJ       0.0332179875
    x[10,4]   onehot_10  1
    x[10,4]   w_lb_10_4  -3.9145222845663033e-02
    x[10,4]   w_ub_10_4  -0.0680494916724233
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,4]   old_TS1   -1.5658089138265213e-01
    x[10,4]   old_TS2   -2.7219796668969320e-01
    x[10,4]   old_TS3   -2.7219796668969320e-01
    x[10,4]   old_TS4   -1.5658089138265213e-01
    x[10,5]   OBJ       2.4913490624999996e-02
    x[10,5]   onehot_10  1
    x[10,5]   w_lb_10_5  -3.9145222845663033e-02
    x[10,5]   w_ub_10_5  -0.0680494916724233
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,5]   old_TS1   -1.9572611422831515e-01
    x[10,5]   old_TS2   -3.4024745836211651e-01
    x[10,5]   old_TS3   -3.4024745836211651e-01
    x[10,5]   old_TS4   -1.9572611422831515e-01
    x[10,6]   OBJ       0.01660899375
    x[10,6]   onehot_10  1
    x[10,6]   w_lb_10_6  -3.9145222845663033e-02
    x[10,6]   w_ub_10_6  -0.0680494916724233
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,6]   old_TS1   -2.3487133707397820e-01
    x[10,6]   old_TS2   -4.0829695003453981e-01
    x[10,6]   old_TS3   -4.0829695003453981e-01
    x[10,6]   old_TS4   -2.3487133707397820e-01
    x[10,7]   OBJ       0.008304496875
    x[10,7]   onehot_10  1
    x[10,7]   w_lb_10_7  -3.9145222845663033e-02
    x[10,7]   w_ub_10_7  -0.0680494916724233
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,7]   old_TS1   -2.7401655991964124e-01
    x[10,7]   old_TS2   -4.7634644170696311e-01
    x[10,7]   old_TS3   -4.7634644170696311e-01
    x[10,7]   old_TS4   -2.7401655991964124e-01
    x[10,8]   onehot_10  1
    x[10,8]   w_lb_10_8  -3.9145222845663033e-02
    x[10,8]   w_ub_10_8  -0.0680494916724233
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,8]   old_TS1   -3.1316178276530426e-01
    x[10,8]   old_TS2   -5.4439593337938641e-01
    x[10,8]   old_TS3   -5.4439593337938641e-01
    x[10,8]   old_TS4   -3.1316178276530426e-01
    x[10,9]   OBJ       -0.008304496875
    x[10,9]   onehot_10  1
    x[10,9]   w_lb_10_9  -3.9145222845663033e-02
    x[10,9]   w_ub_10_9  -0.0680494916724233
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,9]   old_TS1   -3.5230700561096728e-01
    x[10,9]   old_TS2   -6.1244542505180966e-01
    x[10,9]   old_TS3   -6.1244542505180966e-01
    x[10,9]   old_TS4   -3.5230700561096728e-01
    x[10,10]  OBJ       -0.01660899375
    x[10,10]  onehot_10  1
    x[10,10]  w_lb_10_10  -3.9145222845663033e-02
    x[10,10]  w_ub_10_10  -0.0680494916724233
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,10]  old_TS1   -3.9145222845663030e-01
    x[10,10]  old_TS2   -0.680494916724233
    x[10,10]  old_TS3   -0.680494916724233
    x[10,10]  old_TS4   -3.9145222845663030e-01
    x[10,11]  OBJ       -0.024913490625
    x[10,11]  onehot_10  1
    x[10,11]  w_lb_10_11  -3.9145222845663033e-02
    x[10,11]  w_ub_10_11  -0.0680494916724233
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[10,11]  old_TS1   -4.3059745130229338e-01
    x[10,11]  old_TS2   -7.4854440839665637e-01
    x[10,11]  old_TS3   -7.4854440839665637e-01
    x[10,11]  old_TS4   -4.3059745130229338e-01
    x[10,12]  OBJ       -0.0332179875
    x[10,12]  onehot_10  1
    x[10,12]  w_lb_10_12  -3.9145222845663033e-02
    x[10,12]  w_ub_10_12  -0.0680494916724233
    x[10,12]  hard_lower  12
    x[10,12]  hard_upper  12
    x[10,12]  old_TS1   -4.6974267414795640e-01
    x[10,12]  old_TS2   -8.1659390006907961e-01
    x[10,12]  old_TS3   -8.1659390006907961e-01
    x[10,12]  old_TS4   -4.6974267414795640e-01
    x[10,13]  OBJ       -0.041522484375
    x[10,13]  onehot_10  1
    x[10,13]  w_lb_10_13  -3.9145222845663033e-02
    x[10,13]  w_ub_10_13  -0.0680494916724233
    x[10,13]  hard_lower  13
    x[10,13]  hard_upper  13
    x[10,13]  old_TS1   -5.0888789699361947e-01
    x[10,13]  old_TS2   -8.8464339174150286e-01
    x[10,13]  old_TS3   -8.8464339174150286e-01
    x[10,13]  old_TS4   -5.0888789699361947e-01
    x[10,14]  OBJ       -0.04982698125
    x[10,14]  onehot_10  1
    x[10,14]  w_lb_10_14  -3.9145222845663033e-02
    x[10,14]  w_ub_10_14  -0.0680494916724233
    x[10,14]  hard_lower  14
    x[10,14]  hard_upper  14
    x[10,14]  old_TS1   -5.4803311983928249e-01
    x[10,14]  old_TS2   -9.5269288341392622e-01
    x[10,14]  old_TS3   -9.5269288341392622e-01
    x[10,14]  old_TS4   -5.4803311983928249e-01
    x[10,15]  OBJ       -0.058131478125
    x[10,15]  onehot_10  1
    x[10,15]  w_lb_10_15  -3.9145222845663033e-02
    x[10,15]  w_ub_10_15  -0.0680494916724233
    x[10,15]  hard_lower  15
    x[10,15]  hard_upper  15
    x[10,15]  old_TS1   -5.8717834268494551e-01
    x[10,15]  old_TS2   -1.0207423750863496e+00
    x[10,15]  old_TS3   -1.0207423750863496e+00
    x[10,15]  old_TS4   -5.8717834268494551e-01
    x[10,16]  OBJ       -0.066435975
    x[10,16]  onehot_10  1
    x[10,16]  w_lb_10_16  -3.9145222845663033e-02
    x[10,16]  w_ub_10_16  -0.0680494916724233
    x[10,16]  hard_lower  16
    x[10,16]  hard_upper  16
    x[10,16]  old_TS1   -6.2632356553060853e-01
    x[10,16]  old_TS2   -1.0887918667587728e+00
    x[10,16]  old_TS3   -1.0887918667587728e+00
    x[10,16]  old_TS4   -6.2632356553060853e-01
    x[10,17]  OBJ       -0.058131478125
    x[10,17]  onehot_10  1
    x[10,17]  w_lb_10_17  -3.9145222845663033e-02
    x[10,17]  w_ub_10_17  -0.0680494916724233
    x[10,17]  hard_lower  17
    x[10,17]  hard_upper  17
    x[10,17]  old_TS1   -6.6546878837627155e-01
    x[10,17]  old_TS2   -1.1568413584311961e+00
    x[10,17]  old_TS3   -1.1568413584311961e+00
    x[10,17]  old_TS4   -6.6546878837627155e-01
    x[10,18]  OBJ       -0.04982698125
    x[10,18]  onehot_10  1
    x[10,18]  w_lb_10_18  -3.9145222845663033e-02
    x[10,18]  w_ub_10_18  -0.0680494916724233
    x[10,18]  hard_lower  18
    x[10,18]  hard_upper  18
    x[10,18]  old_TS1   -7.0461401122193457e-01
    x[10,18]  old_TS2   -1.2248908501036193e+00
    x[10,18]  old_TS3   -1.2248908501036193e+00
    x[10,18]  old_TS4   -7.0461401122193457e-01
    x[10,19]  OBJ       -0.041522484375
    x[10,19]  onehot_10  1
    x[10,19]  w_lb_10_19  -3.9145222845663033e-02
    x[10,19]  w_ub_10_19  -0.0680494916724233
    x[10,19]  hard_lower  19
    x[10,19]  hard_upper  19
    x[10,19]  old_TS1   -7.4375923406759759e-01
    x[10,19]  old_TS2   -1.2929403417760428e+00
    x[10,19]  old_TS3   -1.2929403417760428e+00
    x[10,19]  old_TS4   -7.4375923406759759e-01
    x[10,20]  OBJ       -0.0332179875
    x[10,20]  onehot_10  1
    x[10,20]  w_lb_10_20  -3.9145222845663033e-02
    x[10,20]  w_ub_10_20  -0.0680494916724233
    x[10,20]  hard_lower  20
    x[10,20]  hard_upper  20
    x[10,20]  old_TS1   -7.8290445691326060e-01
    x[10,20]  old_TS2   -1.3609898334484660e+00
    x[10,20]  old_TS3   -1.3609898334484660e+00
    x[10,20]  old_TS4   -7.8290445691326060e-01
    x[10,21]  OBJ       -0.024913490625
    x[10,21]  onehot_10  1
    x[10,21]  w_lb_10_21  -3.9145222845663033e-02
    x[10,21]  w_ub_10_21  -0.0680494916724233
    x[10,21]  hard_lower  21
    x[10,21]  hard_upper  21
    x[10,21]  old_TS1   -8.2204967975892373e-01
    x[10,21]  old_TS2   -1.4290393251208893e+00
    x[10,21]  old_TS3   -1.4290393251208893e+00
    x[10,21]  old_TS4   -8.2204967975892373e-01
    x[10,22]  OBJ       -0.01660899375
    x[10,22]  onehot_10  1
    x[10,22]  w_lb_10_22  -3.9145222845663033e-02
    x[10,22]  w_ub_10_22  -0.0680494916724233
    x[10,22]  hard_lower  22
    x[10,22]  hard_upper  22
    x[10,22]  old_TS1   -8.6119490260458675e-01
    x[10,22]  old_TS2   -1.4970888167933127e+00
    x[10,22]  old_TS3   -1.4970888167933127e+00
    x[10,22]  old_TS4   -8.6119490260458675e-01
    x[10,23]  OBJ       -0.008304496875
    x[10,23]  onehot_10  1
    x[10,23]  w_lb_10_23  -3.9145222845663033e-02
    x[10,23]  w_ub_10_23  -0.0680494916724233
    x[10,23]  hard_lower  23
    x[10,23]  hard_upper  23
    x[10,23]  old_TS1   -9.0034012545024977e-01
    x[10,23]  old_TS2   -1.5651383084657360e+00
    x[10,23]  old_TS3   -1.5651383084657360e+00
    x[10,23]  old_TS4   -9.0034012545024977e-01
    x[10,24]  onehot_10  1
    x[10,24]  w_lb_10_24  -3.9145222845663033e-02
    x[10,24]  w_ub_10_24  -0.0680494916724233
    x[10,24]  hard_lower  24
    x[10,24]  hard_upper  24
    x[10,24]  old_TS1   -9.3948534829591279e-01
    x[10,24]  old_TS2   -1.6331878001381592e+00
    x[10,24]  old_TS3   -1.6331878001381592e+00
    x[10,24]  old_TS4   -9.3948534829591279e-01
    x[10,25]  OBJ       0.008304496875
    x[10,25]  onehot_10  1
    x[10,25]  w_lb_10_25  -3.9145222845663033e-02
    x[10,25]  w_ub_10_25  -0.0680494916724233
    x[10,25]  hard_lower  25
    x[10,25]  hard_upper  25
    x[10,25]  old_TS1   -9.7863057114157581e-01
    x[10,25]  old_TS2   -1.7012372918105825e+00
    x[10,25]  old_TS3   -1.7012372918105825e+00
    x[10,25]  old_TS4   -9.7863057114157581e-01
    x[10,26]  OBJ       0.01660899375
    x[10,26]  onehot_10  1
    x[10,26]  w_lb_10_26  -3.9145222845663033e-02
    x[10,26]  w_ub_10_26  -0.0680494916724233
    x[10,26]  hard_lower  26
    x[10,26]  hard_upper  26
    x[10,26]  old_TS1   -1.0177757939872389e+00
    x[10,26]  old_TS2   -1.7692867834830057e+00
    x[10,26]  old_TS3   -1.7692867834830057e+00
    x[10,26]  old_TS4   -1.0177757939872389e+00
    x[10,27]  OBJ       2.4913490624999996e-02
    x[10,27]  onehot_10  1
    x[10,27]  w_lb_10_27  -3.9145222845663033e-02
    x[10,27]  w_ub_10_27  -0.0680494916724233
    x[10,27]  hard_lower  27
    x[10,27]  hard_upper  27
    x[10,27]  old_TS1   -1.0569210168329020e+00
    x[10,27]  old_TS2   -1.8373362751554292e+00
    x[10,27]  old_TS3   -1.8373362751554292e+00
    x[10,27]  old_TS4   -1.0569210168329020e+00
    x[10,28]  OBJ       0.0332179875
    x[10,28]  onehot_10  1
    x[10,28]  w_lb_10_28  -3.9145222845663033e-02
    x[10,28]  w_ub_10_28  -0.0680494916724233
    x[10,28]  hard_lower  28
    x[10,28]  hard_upper  28
    x[10,28]  old_TS1   -1.0960662396785650e+00
    x[10,28]  old_TS2   -1.9053857668278524e+00
    x[10,28]  old_TS3   -1.9053857668278524e+00
    x[10,28]  old_TS4   -1.0960662396785650e+00
    x[10,29]  OBJ       4.1522484374999995e-02
    x[10,29]  onehot_10  1
    x[10,29]  w_lb_10_29  -3.9145222845663033e-02
    x[10,29]  w_ub_10_29  -0.0680494916724233
    x[10,29]  hard_lower  29
    x[10,29]  hard_upper  29
    x[10,29]  old_TS1   -1.1352114625242280e+00
    x[10,29]  old_TS2   -1.9734352585002757e+00
    x[10,29]  old_TS3   -1.9734352585002757e+00
    x[10,29]  old_TS4   -1.1352114625242280e+00
    x[11,0]   OBJ       7.4999999999999983e-02
    x[11,0]   onehot_11  1
    x[11,0]   w_lb_11_0  -3.9145222845663033e-02
    x[11,0]   w_ub_11_0  -0.0680494916724233
    x[11,1]   OBJ       6.6176470588235281e-02
    x[11,1]   onehot_11  1
    x[11,1]   w_lb_11_1  -3.9145222845663033e-02
    x[11,1]   w_ub_11_1  -0.0680494916724233
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,1]   old_TS1   -3.9145222845663033e-02
    x[11,1]   old_TS2   -0.0680494916724233
    x[11,1]   old_TS3   -0.0680494916724233
    x[11,1]   old_TS4   -3.9145222845663033e-02
    x[11,2]   OBJ       5.7352941176470579e-02
    x[11,2]   onehot_11  1
    x[11,2]   w_lb_11_2  -3.9145222845663033e-02
    x[11,2]   w_ub_11_2  -0.0680494916724233
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,2]   old_TS1   -7.8290445691326066e-02
    x[11,2]   old_TS2   -1.3609898334484660e-01
    x[11,2]   old_TS3   -1.3609898334484660e-01
    x[11,2]   old_TS4   -7.8290445691326066e-02
    x[11,3]   OBJ       4.8529411764705876e-02
    x[11,3]   onehot_11  1
    x[11,3]   w_lb_11_3  -3.9145222845663033e-02
    x[11,3]   w_ub_11_3  -0.0680494916724233
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,3]   old_TS1   -1.1743566853698910e-01
    x[11,3]   old_TS2   -2.0414847501726990e-01
    x[11,3]   old_TS3   -2.0414847501726990e-01
    x[11,3]   old_TS4   -1.1743566853698910e-01
    x[11,4]   OBJ       3.9705882352941174e-02
    x[11,4]   onehot_11  1
    x[11,4]   w_lb_11_4  -3.9145222845663033e-02
    x[11,4]   w_ub_11_4  -0.0680494916724233
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,4]   old_TS1   -1.5658089138265213e-01
    x[11,4]   old_TS2   -2.7219796668969320e-01
    x[11,4]   old_TS3   -2.7219796668969320e-01
    x[11,4]   old_TS4   -1.5658089138265213e-01
    x[11,5]   OBJ       3.0882352941176468e-02
    x[11,5]   onehot_11  1
    x[11,5]   w_lb_11_5  -3.9145222845663033e-02
    x[11,5]   w_ub_11_5  -0.0680494916724233
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,5]   old_TS1   -1.9572611422831515e-01
    x[11,5]   old_TS2   -3.4024745836211651e-01
    x[11,5]   old_TS3   -3.4024745836211651e-01
    x[11,5]   old_TS4   -1.9572611422831515e-01
    x[11,6]   OBJ       2.2058823529411763e-02
    x[11,6]   onehot_11  1
    x[11,6]   w_lb_11_6  -3.9145222845663033e-02
    x[11,6]   w_ub_11_6  -0.0680494916724233
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,6]   old_TS1   -2.3487133707397820e-01
    x[11,6]   old_TS2   -4.0829695003453981e-01
    x[11,6]   old_TS3   -4.0829695003453981e-01
    x[11,6]   old_TS4   -2.3487133707397820e-01
    x[11,7]   OBJ       1.3235294117647057e-02
    x[11,7]   onehot_11  1
    x[11,7]   w_lb_11_7  -3.9145222845663033e-02
    x[11,7]   w_ub_11_7  -0.0680494916724233
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,7]   old_TS1   -2.7401655991964124e-01
    x[11,7]   old_TS2   -4.7634644170696311e-01
    x[11,7]   old_TS3   -4.7634644170696311e-01
    x[11,7]   old_TS4   -2.7401655991964124e-01
    x[11,8]   OBJ       4.4117647058823520e-03
    x[11,8]   onehot_11  1
    x[11,8]   w_lb_11_8  -3.9145222845663033e-02
    x[11,8]   w_ub_11_8  -0.0680494916724233
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,8]   old_TS1   -3.1316178276530426e-01
    x[11,8]   old_TS2   -5.4439593337938641e-01
    x[11,8]   old_TS3   -5.4439593337938641e-01
    x[11,8]   old_TS4   -3.1316178276530426e-01
    x[11,9]   OBJ       -4.4117647058823529e-03
    x[11,9]   onehot_11  1
    x[11,9]   w_lb_11_9  -3.9145222845663033e-02
    x[11,9]   w_ub_11_9  -0.0680494916724233
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,9]   old_TS1   -3.5230700561096728e-01
    x[11,9]   old_TS2   -6.1244542505180966e-01
    x[11,9]   old_TS3   -6.1244542505180966e-01
    x[11,9]   old_TS4   -3.5230700561096728e-01
    x[11,10]  OBJ       -1.3235294117647059e-02
    x[11,10]  onehot_11  1
    x[11,10]  w_lb_11_10  -3.9145222845663033e-02
    x[11,10]  w_ub_11_10  -0.0680494916724233
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,10]  old_TS1   -3.9145222845663030e-01
    x[11,10]  old_TS2   -0.680494916724233
    x[11,10]  old_TS3   -0.680494916724233
    x[11,10]  old_TS4   -3.9145222845663030e-01
    x[11,11]  OBJ       -2.2058823529411766e-02
    x[11,11]  onehot_11  1
    x[11,11]  w_lb_11_11  -3.9145222845663033e-02
    x[11,11]  w_ub_11_11  -0.0680494916724233
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,11]  old_TS1   -4.3059745130229338e-01
    x[11,11]  old_TS2   -7.4854440839665637e-01
    x[11,11]  old_TS3   -7.4854440839665637e-01
    x[11,11]  old_TS4   -4.3059745130229338e-01
    x[11,12]  OBJ       -3.0882352941176472e-02
    x[11,12]  onehot_11  1
    x[11,12]  w_lb_11_12  -3.9145222845663033e-02
    x[11,12]  w_ub_11_12  -0.0680494916724233
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[11,12]  old_TS1   -4.6974267414795640e-01
    x[11,12]  old_TS2   -8.1659390006907961e-01
    x[11,12]  old_TS3   -8.1659390006907961e-01
    x[11,12]  old_TS4   -4.6974267414795640e-01
    x[11,13]  OBJ       -3.9705882352941181e-02
    x[11,13]  onehot_11  1
    x[11,13]  w_lb_11_13  -3.9145222845663033e-02
    x[11,13]  w_ub_11_13  -0.0680494916724233
    x[11,13]  hard_lower  13
    x[11,13]  hard_upper  13
    x[11,13]  old_TS1   -5.0888789699361947e-01
    x[11,13]  old_TS2   -8.8464339174150286e-01
    x[11,13]  old_TS3   -8.8464339174150286e-01
    x[11,13]  old_TS4   -5.0888789699361947e-01
    x[11,14]  OBJ       -4.8529411764705883e-02
    x[11,14]  onehot_11  1
    x[11,14]  w_lb_11_14  -3.9145222845663033e-02
    x[11,14]  w_ub_11_14  -0.0680494916724233
    x[11,14]  hard_lower  14
    x[11,14]  hard_upper  14
    x[11,14]  old_TS1   -5.4803311983928249e-01
    x[11,14]  old_TS2   -9.5269288341392622e-01
    x[11,14]  old_TS3   -9.5269288341392622e-01
    x[11,14]  old_TS4   -5.4803311983928249e-01
    x[11,15]  OBJ       -5.7352941176470586e-02
    x[11,15]  onehot_11  1
    x[11,15]  w_lb_11_15  -3.9145222845663033e-02
    x[11,15]  w_ub_11_15  -0.0680494916724233
    x[11,15]  hard_lower  15
    x[11,15]  hard_upper  15
    x[11,15]  old_TS1   -5.8717834268494551e-01
    x[11,15]  old_TS2   -1.0207423750863496e+00
    x[11,15]  old_TS3   -1.0207423750863496e+00
    x[11,15]  old_TS4   -5.8717834268494551e-01
    x[11,16]  OBJ       -0.0661764705882353
    x[11,16]  onehot_11  1
    x[11,16]  w_lb_11_16  -3.9145222845663033e-02
    x[11,16]  w_ub_11_16  -0.0680494916724233
    x[11,16]  hard_lower  16
    x[11,16]  hard_upper  16
    x[11,16]  old_TS1   -6.2632356553060853e-01
    x[11,16]  old_TS2   -1.0887918667587728e+00
    x[11,16]  old_TS3   -1.0887918667587728e+00
    x[11,16]  old_TS4   -6.2632356553060853e-01
    x[11,17]  OBJ       -0.075
    x[11,17]  onehot_11  1
    x[11,17]  w_lb_11_17  -3.9145222845663033e-02
    x[11,17]  w_ub_11_17  -0.0680494916724233
    x[11,17]  hard_lower  17
    x[11,17]  hard_upper  17
    x[11,17]  old_TS1   -6.6546878837627155e-01
    x[11,17]  old_TS2   -1.1568413584311961e+00
    x[11,17]  old_TS3   -1.1568413584311961e+00
    x[11,17]  old_TS4   -6.6546878837627155e-01
    x[11,18]  OBJ       -0.0661764705882353
    x[11,18]  onehot_11  1
    x[11,18]  w_lb_11_18  -3.9145222845663033e-02
    x[11,18]  w_ub_11_18  -0.0680494916724233
    x[11,18]  hard_lower  18
    x[11,18]  hard_upper  18
    x[11,18]  old_TS1   -7.0461401122193457e-01
    x[11,18]  old_TS2   -1.2248908501036193e+00
    x[11,18]  old_TS3   -1.2248908501036193e+00
    x[11,18]  old_TS4   -7.0461401122193457e-01
    x[11,19]  OBJ       -5.7352941176470593e-02
    x[11,19]  onehot_11  1
    x[11,19]  w_lb_11_19  -3.9145222845663033e-02
    x[11,19]  w_ub_11_19  -0.0680494916724233
    x[11,19]  hard_lower  19
    x[11,19]  hard_upper  19
    x[11,19]  old_TS1   -7.4375923406759759e-01
    x[11,19]  old_TS2   -1.2929403417760428e+00
    x[11,19]  old_TS3   -1.2929403417760428e+00
    x[11,19]  old_TS4   -7.4375923406759759e-01
    x[11,20]  OBJ       -4.8529411764705890e-02
    x[11,20]  onehot_11  1
    x[11,20]  w_lb_11_20  -3.9145222845663033e-02
    x[11,20]  w_ub_11_20  -0.0680494916724233
    x[11,20]  hard_lower  20
    x[11,20]  hard_upper  20
    x[11,20]  old_TS1   -7.8290445691326060e-01
    x[11,20]  old_TS2   -1.3609898334484660e+00
    x[11,20]  old_TS3   -1.3609898334484660e+00
    x[11,20]  old_TS4   -7.8290445691326060e-01
    x[11,21]  OBJ       -3.9705882352941181e-02
    x[11,21]  onehot_11  1
    x[11,21]  w_lb_11_21  -3.9145222845663033e-02
    x[11,21]  w_ub_11_21  -0.0680494916724233
    x[11,21]  hard_lower  21
    x[11,21]  hard_upper  21
    x[11,21]  old_TS1   -8.2204967975892373e-01
    x[11,21]  old_TS2   -1.4290393251208893e+00
    x[11,21]  old_TS3   -1.4290393251208893e+00
    x[11,21]  old_TS4   -8.2204967975892373e-01
    x[11,22]  OBJ       -3.0882352941176475e-02
    x[11,22]  onehot_11  1
    x[11,22]  w_lb_11_22  -3.9145222845663033e-02
    x[11,22]  w_ub_11_22  -0.0680494916724233
    x[11,22]  hard_lower  22
    x[11,22]  hard_upper  22
    x[11,22]  old_TS1   -8.6119490260458675e-01
    x[11,22]  old_TS2   -1.4970888167933127e+00
    x[11,22]  old_TS3   -1.4970888167933127e+00
    x[11,22]  old_TS4   -8.6119490260458675e-01
    x[11,23]  OBJ       -2.2058823529411770e-02
    x[11,23]  onehot_11  1
    x[11,23]  w_lb_11_23  -3.9145222845663033e-02
    x[11,23]  w_ub_11_23  -0.0680494916724233
    x[11,23]  hard_lower  23
    x[11,23]  hard_upper  23
    x[11,23]  old_TS1   -9.0034012545024977e-01
    x[11,23]  old_TS2   -1.5651383084657360e+00
    x[11,23]  old_TS3   -1.5651383084657360e+00
    x[11,23]  old_TS4   -9.0034012545024977e-01
    x[11,24]  OBJ       -1.3235294117647064e-02
    x[11,24]  onehot_11  1
    x[11,24]  w_lb_11_24  -3.9145222845663033e-02
    x[11,24]  w_ub_11_24  -0.0680494916724233
    x[11,24]  hard_lower  24
    x[11,24]  hard_upper  24
    x[11,24]  old_TS1   -9.3948534829591279e-01
    x[11,24]  old_TS2   -1.6331878001381592e+00
    x[11,24]  old_TS3   -1.6331878001381592e+00
    x[11,24]  old_TS4   -9.3948534829591279e-01
    x[11,25]  OBJ       -4.4117647058823572e-03
    x[11,25]  onehot_11  1
    x[11,25]  w_lb_11_25  -3.9145222845663033e-02
    x[11,25]  w_ub_11_25  -0.0680494916724233
    x[11,25]  hard_lower  25
    x[11,25]  hard_upper  25
    x[11,25]  old_TS1   -9.7863057114157581e-01
    x[11,25]  old_TS2   -1.7012372918105825e+00
    x[11,25]  old_TS3   -1.7012372918105825e+00
    x[11,25]  old_TS4   -9.7863057114157581e-01
    x[11,26]  OBJ       4.4117647058823485e-03
    x[11,26]  onehot_11  1
    x[11,26]  w_lb_11_26  -3.9145222845663033e-02
    x[11,26]  w_ub_11_26  -0.0680494916724233
    x[11,26]  hard_lower  26
    x[11,26]  hard_upper  26
    x[11,26]  old_TS1   -1.0177757939872389e+00
    x[11,26]  old_TS2   -1.7692867834830057e+00
    x[11,26]  old_TS3   -1.7692867834830057e+00
    x[11,26]  old_TS4   -1.0177757939872389e+00
    x[11,27]  OBJ       1.3235294117647053e-02
    x[11,27]  onehot_11  1
    x[11,27]  w_lb_11_27  -3.9145222845663033e-02
    x[11,27]  w_ub_11_27  -0.0680494916724233
    x[11,27]  hard_lower  27
    x[11,27]  hard_upper  27
    x[11,27]  old_TS1   -1.0569210168329020e+00
    x[11,27]  old_TS2   -1.8373362751554292e+00
    x[11,27]  old_TS3   -1.8373362751554292e+00
    x[11,27]  old_TS4   -1.0569210168329020e+00
    x[11,28]  OBJ       2.2058823529411759e-02
    x[11,28]  onehot_11  1
    x[11,28]  w_lb_11_28  -3.9145222845663033e-02
    x[11,28]  w_ub_11_28  -0.0680494916724233
    x[11,28]  hard_lower  28
    x[11,28]  hard_upper  28
    x[11,28]  old_TS1   -1.0960662396785650e+00
    x[11,28]  old_TS2   -1.9053857668278524e+00
    x[11,28]  old_TS3   -1.9053857668278524e+00
    x[11,28]  old_TS4   -1.0960662396785650e+00
    x[11,29]  OBJ       3.0882352941176461e-02
    x[11,29]  onehot_11  1
    x[11,29]  w_lb_11_29  -3.9145222845663033e-02
    x[11,29]  w_ub_11_29  -0.0680494916724233
    x[11,29]  hard_lower  29
    x[11,29]  hard_upper  29
    x[11,29]  old_TS1   -1.1352114625242280e+00
    x[11,29]  old_TS2   -1.9734352585002757e+00
    x[11,29]  old_TS3   -1.9734352585002757e+00
    x[11,29]  old_TS4   -1.1352114625242280e+00
    x[11,30]  OBJ       3.9705882352941167e-02
    x[11,30]  onehot_11  1
    x[11,30]  w_lb_11_30  -3.9145222845663033e-02
    x[11,30]  w_ub_11_30  -0.0680494916724233
    x[11,30]  hard_lower  30
    x[11,30]  hard_upper  30
    x[11,30]  old_TS1   -1.1743566853698910e+00
    x[11,30]  old_TS2   -2.0414847501726991e+00
    x[11,30]  old_TS3   -2.0414847501726991e+00
    x[11,30]  old_TS4   -1.1743566853698910e+00
    x[11,31]  OBJ       4.8529411764705870e-02
    x[11,31]  onehot_11  1
    x[11,31]  w_lb_11_31  -3.9145222845663033e-02
    x[11,31]  w_ub_11_31  -0.0680494916724233
    x[11,31]  hard_lower  31
    x[11,31]  hard_upper  31
    x[11,31]  old_TS1   -1.2135019082155540e+00
    x[11,31]  old_TS2   -2.1095342418451222e+00
    x[11,31]  old_TS3   -2.1095342418451222e+00
    x[11,31]  old_TS4   -1.2135019082155540e+00
    x[12,0]   OBJ       2.5951574999999998e-02
    x[12,0]   onehot_12  1
    x[12,0]   w_lb_12_0  -3.9145222845663033e-02
    x[12,0]   w_ub_12_0  -0.0680494916724233
    x[12,1]   OBJ       2.0761259999999997e-02
    x[12,1]   onehot_12  1
    x[12,1]   w_lb_12_1  -3.9145222845663033e-02
    x[12,1]   w_ub_12_1  -0.0680494916724233
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,1]   old_TS1   -3.9145222845663033e-02
    x[12,1]   old_TS2   -0.0680494916724233
    x[12,1]   old_TS3   -0.0680494916724233
    x[12,1]   old_TS4   -3.9145222845663033e-02
    x[12,2]   OBJ       1.5570944999999997e-02
    x[12,2]   onehot_12  1
    x[12,2]   w_lb_12_2  -3.9145222845663033e-02
    x[12,2]   w_ub_12_2  -0.0680494916724233
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,2]   old_TS1   -7.8290445691326066e-02
    x[12,2]   old_TS2   -1.3609898334484660e-01
    x[12,2]   old_TS3   -1.3609898334484660e-01
    x[12,2]   old_TS4   -7.8290445691326066e-02
    x[12,3]   OBJ       1.0380629999999997e-02
    x[12,3]   onehot_12  1
    x[12,3]   w_lb_12_3  -3.9145222845663033e-02
    x[12,3]   w_ub_12_3  -0.0680494916724233
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,3]   old_TS1   -1.1743566853698910e-01
    x[12,3]   old_TS2   -2.0414847501726990e-01
    x[12,3]   old_TS3   -2.0414847501726990e-01
    x[12,3]   old_TS4   -1.1743566853698910e-01
    x[12,4]   OBJ       5.1903149999999974e-03
    x[12,4]   onehot_12  1
    x[12,4]   w_lb_12_4  -3.9145222845663033e-02
    x[12,4]   w_ub_12_4  -0.0680494916724233
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,4]   old_TS1   -1.5658089138265213e-01
    x[12,4]   old_TS2   -2.7219796668969320e-01
    x[12,4]   old_TS3   -2.7219796668969320e-01
    x[12,4]   old_TS4   -1.5658089138265213e-01
    x[12,5]   OBJ       -2.8812036090286598e-18
    x[12,5]   onehot_12  1
    x[12,5]   w_lb_12_5  -3.9145222845663033e-02
    x[12,5]   w_ub_12_5  -0.0680494916724233
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,5]   old_TS1   -1.9572611422831515e-01
    x[12,5]   old_TS2   -3.4024745836211651e-01
    x[12,5]   old_TS3   -3.4024745836211651e-01
    x[12,5]   old_TS4   -1.9572611422831515e-01
    x[12,6]   OBJ       -5.1903150000000035e-03
    x[12,6]   onehot_12  1
    x[12,6]   w_lb_12_6  -3.9145222845663033e-02
    x[12,6]   w_ub_12_6  -0.0680494916724233
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,6]   old_TS1   -2.3487133707397820e-01
    x[12,6]   old_TS2   -4.0829695003453981e-01
    x[12,6]   old_TS3   -4.0829695003453981e-01
    x[12,6]   old_TS4   -2.3487133707397820e-01
    x[12,7]   OBJ       -1.0380630000000005e-02
    x[12,7]   onehot_12  1
    x[12,7]   w_lb_12_7  -3.9145222845663033e-02
    x[12,7]   w_ub_12_7  -0.0680494916724233
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,7]   old_TS1   -2.7401655991964124e-01
    x[12,7]   old_TS2   -4.7634644170696311e-01
    x[12,7]   old_TS3   -4.7634644170696311e-01
    x[12,7]   old_TS4   -2.7401655991964124e-01
    x[12,8]   OBJ       -1.5570945000000004e-02
    x[12,8]   onehot_12  1
    x[12,8]   w_lb_12_8  -3.9145222845663033e-02
    x[12,8]   w_ub_12_8  -0.0680494916724233
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,8]   old_TS1   -3.1316178276530426e-01
    x[12,8]   old_TS2   -5.4439593337938641e-01
    x[12,8]   old_TS3   -5.4439593337938641e-01
    x[12,8]   old_TS4   -3.1316178276530426e-01
    x[12,9]   OBJ       -2.0761260000000007e-02
    x[12,9]   onehot_12  1
    x[12,9]   w_lb_12_9  -3.9145222845663033e-02
    x[12,9]   w_ub_12_9  -0.0680494916724233
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,9]   old_TS1   -3.5230700561096728e-01
    x[12,9]   old_TS2   -6.1244542505180966e-01
    x[12,9]   old_TS3   -6.1244542505180966e-01
    x[12,9]   old_TS4   -3.5230700561096728e-01
    x[12,10]  OBJ       -0.025951575
    x[12,10]  onehot_12  1
    x[12,10]  w_lb_12_10  -3.9145222845663033e-02
    x[12,10]  w_ub_12_10  -0.0680494916724233
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,10]  old_TS1   -3.9145222845663030e-01
    x[12,10]  old_TS2   -0.680494916724233
    x[12,10]  old_TS3   -0.680494916724233
    x[12,10]  old_TS4   -3.9145222845663030e-01
    x[12,11]  OBJ       -0.02076126
    x[12,11]  onehot_12  1
    x[12,11]  w_lb_12_11  -3.9145222845663033e-02
    x[12,11]  w_ub_12_11  -0.0680494916724233
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,11]  old_TS1   -4.3059745130229338e-01
    x[12,11]  old_TS2   -7.4854440839665637e-01
    x[12,11]  old_TS3   -7.4854440839665637e-01
    x[12,11]  old_TS4   -4.3059745130229338e-01
    x[12,12]  OBJ       -0.015570945
    x[12,12]  onehot_12  1
    x[12,12]  w_lb_12_12  -3.9145222845663033e-02
    x[12,12]  w_ub_12_12  -0.0680494916724233
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,12]  old_TS1   -4.6974267414795640e-01
    x[12,12]  old_TS2   -8.1659390006907961e-01
    x[12,12]  old_TS3   -8.1659390006907961e-01
    x[12,12]  old_TS4   -4.6974267414795640e-01
    x[12,13]  OBJ       -1.0380629999999998e-02
    x[12,13]  onehot_12  1
    x[12,13]  w_lb_12_13  -3.9145222845663033e-02
    x[12,13]  w_ub_12_13  -0.0680494916724233
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,13]  old_TS1   -5.0888789699361947e-01
    x[12,13]  old_TS2   -8.8464339174150286e-01
    x[12,13]  old_TS3   -8.8464339174150286e-01
    x[12,13]  old_TS4   -5.0888789699361947e-01
    x[12,14]  OBJ       -5.1903149999999983e-03
    x[12,14]  onehot_12  1
    x[12,14]  w_lb_12_14  -3.9145222845663033e-02
    x[12,14]  w_ub_12_14  -0.0680494916724233
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,14]  old_TS1   -5.4803311983928249e-01
    x[12,14]  old_TS2   -9.5269288341392622e-01
    x[12,14]  old_TS3   -9.5269288341392622e-01
    x[12,14]  old_TS4   -5.4803311983928249e-01
    x[12,15]  OBJ       2.8812036090286598e-18
    x[12,15]  onehot_12  1
    x[12,15]  w_lb_12_15  -3.9145222845663033e-02
    x[12,15]  w_ub_12_15  -0.0680494916724233
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[12,15]  old_TS1   -5.8717834268494551e-01
    x[12,15]  old_TS2   -1.0207423750863496e+00
    x[12,15]  old_TS3   -1.0207423750863496e+00
    x[12,15]  old_TS4   -5.8717834268494551e-01
    x[12,16]  OBJ       5.1903150000000026e-03
    x[12,16]  onehot_12  1
    x[12,16]  w_lb_12_16  -3.9145222845663033e-02
    x[12,16]  w_ub_12_16  -0.0680494916724233
    x[12,16]  hard_lower  16
    x[12,16]  hard_upper  16
    x[12,16]  old_TS1   -6.2632356553060853e-01
    x[12,16]  old_TS2   -1.0887918667587728e+00
    x[12,16]  old_TS3   -1.0887918667587728e+00
    x[12,16]  old_TS4   -6.2632356553060853e-01
    x[12,17]  OBJ       1.0380630000000004e-02
    x[12,17]  onehot_12  1
    x[12,17]  w_lb_12_17  -3.9145222845663033e-02
    x[12,17]  w_ub_12_17  -0.0680494916724233
    x[12,17]  hard_lower  17
    x[12,17]  hard_upper  17
    x[12,17]  old_TS1   -6.6546878837627155e-01
    x[12,17]  old_TS2   -1.1568413584311961e+00
    x[12,17]  old_TS3   -1.1568413584311961e+00
    x[12,17]  old_TS4   -6.6546878837627155e-01
    x[12,18]  OBJ       1.5570945000000003e-02
    x[12,18]  onehot_12  1
    x[12,18]  w_lb_12_18  -3.9145222845663033e-02
    x[12,18]  w_ub_12_18  -0.0680494916724233
    x[12,18]  hard_lower  18
    x[12,18]  hard_upper  18
    x[12,18]  old_TS1   -7.0461401122193457e-01
    x[12,18]  old_TS2   -1.2248908501036193e+00
    x[12,18]  old_TS3   -1.2248908501036193e+00
    x[12,18]  old_TS4   -7.0461401122193457e-01
    x[12,19]  OBJ       2.0761260000000004e-02
    x[12,19]  onehot_12  1
    x[12,19]  w_lb_12_19  -3.9145222845663033e-02
    x[12,19]  w_ub_12_19  -0.0680494916724233
    x[12,19]  hard_lower  19
    x[12,19]  hard_upper  19
    x[12,19]  old_TS1   -7.4375923406759759e-01
    x[12,19]  old_TS2   -1.2929403417760428e+00
    x[12,19]  old_TS3   -1.2929403417760428e+00
    x[12,19]  old_TS4   -7.4375923406759759e-01
    x[13,0]   OBJ       0.043858125
    x[13,0]   onehot_13  1
    x[13,0]   w_lb_13_0  -3.9145222845663033e-02
    x[13,0]   w_ub_13_0  -0.0680494916724233
    x[13,1]   OBJ       3.7110721153846150e-02
    x[13,1]   onehot_13  1
    x[13,1]   w_lb_13_1  -3.9145222845663033e-02
    x[13,1]   w_ub_13_1  -0.0680494916724233
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,1]   old_TS1   -3.9145222845663033e-02
    x[13,1]   old_TS2   -0.0680494916724233
    x[13,1]   old_TS3   -0.0680494916724233
    x[13,1]   old_TS4   -3.9145222845663033e-02
    x[13,2]   OBJ       3.0363317307692306e-02
    x[13,2]   onehot_13  1
    x[13,2]   w_lb_13_2  -3.9145222845663033e-02
    x[13,2]   w_ub_13_2  -0.0680494916724233
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,2]   old_TS1   -7.8290445691326066e-02
    x[13,2]   old_TS2   -1.3609898334484660e-01
    x[13,2]   old_TS3   -1.3609898334484660e-01
    x[13,2]   old_TS4   -7.8290445691326066e-02
    x[13,3]   OBJ       2.3615913461538459e-02
    x[13,3]   onehot_13  1
    x[13,3]   w_lb_13_3  -3.9145222845663033e-02
    x[13,3]   w_ub_13_3  -0.0680494916724233
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,3]   old_TS1   -1.1743566853698910e-01
    x[13,3]   old_TS2   -2.0414847501726990e-01
    x[13,3]   old_TS3   -2.0414847501726990e-01
    x[13,3]   old_TS4   -1.1743566853698910e-01
    x[13,4]   OBJ       1.6868509615384612e-02
    x[13,4]   onehot_13  1
    x[13,4]   w_lb_13_4  -3.9145222845663033e-02
    x[13,4]   w_ub_13_4  -0.0680494916724233
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,4]   old_TS1   -1.5658089138265213e-01
    x[13,4]   old_TS2   -2.7219796668969320e-01
    x[13,4]   old_TS3   -2.7219796668969320e-01
    x[13,4]   old_TS4   -1.5658089138265213e-01
    x[13,5]   OBJ       1.0121105769230766e-02
    x[13,5]   onehot_13  1
    x[13,5]   w_lb_13_5  -3.9145222845663033e-02
    x[13,5]   w_ub_13_5  -0.0680494916724233
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,5]   old_TS1   -1.9572611422831515e-01
    x[13,5]   old_TS2   -3.4024745836211651e-01
    x[13,5]   old_TS3   -3.4024745836211651e-01
    x[13,5]   old_TS4   -1.9572611422831515e-01
    x[13,6]   OBJ       3.3737019230769185e-03
    x[13,6]   onehot_13  1
    x[13,6]   w_lb_13_6  -3.9145222845663033e-02
    x[13,6]   w_ub_13_6  -0.0680494916724233
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,6]   old_TS1   -2.3487133707397820e-01
    x[13,6]   old_TS2   -4.0829695003453981e-01
    x[13,6]   old_TS3   -4.0829695003453981e-01
    x[13,6]   old_TS4   -2.3487133707397820e-01
    x[13,7]   OBJ       -3.3737019230769289e-03
    x[13,7]   onehot_13  1
    x[13,7]   w_lb_13_7  -3.9145222845663033e-02
    x[13,7]   w_ub_13_7  -0.0680494916724233
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,7]   old_TS1   -2.7401655991964124e-01
    x[13,7]   old_TS2   -4.7634644170696311e-01
    x[13,7]   old_TS3   -4.7634644170696311e-01
    x[13,7]   old_TS4   -2.7401655991964124e-01
    x[13,8]   OBJ       -1.0121105769230776e-02
    x[13,8]   onehot_13  1
    x[13,8]   w_lb_13_8  -3.9145222845663033e-02
    x[13,8]   w_ub_13_8  -0.0680494916724233
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,8]   old_TS1   -3.1316178276530426e-01
    x[13,8]   old_TS2   -5.4439593337938641e-01
    x[13,8]   old_TS3   -5.4439593337938641e-01
    x[13,8]   old_TS4   -3.1316178276530426e-01
    x[13,9]   OBJ       -1.6868509615384625e-02
    x[13,9]   onehot_13  1
    x[13,9]   w_lb_13_9  -3.9145222845663033e-02
    x[13,9]   w_ub_13_9  -0.0680494916724233
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,9]   old_TS1   -3.5230700561096728e-01
    x[13,9]   old_TS2   -6.1244542505180966e-01
    x[13,9]   old_TS3   -6.1244542505180966e-01
    x[13,9]   old_TS4   -3.5230700561096728e-01
    x[13,10]  OBJ       -2.3615913461538473e-02
    x[13,10]  onehot_13  1
    x[13,10]  w_lb_13_10  -3.9145222845663033e-02
    x[13,10]  w_ub_13_10  -0.0680494916724233
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,10]  old_TS1   -3.9145222845663030e-01
    x[13,10]  old_TS2   -0.680494916724233
    x[13,10]  old_TS3   -0.680494916724233
    x[13,10]  old_TS4   -3.9145222845663030e-01
    x[13,11]  OBJ       -3.0363317307692320e-02
    x[13,11]  onehot_13  1
    x[13,11]  w_lb_13_11  -3.9145222845663033e-02
    x[13,11]  w_ub_13_11  -0.0680494916724233
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,11]  old_TS1   -4.3059745130229338e-01
    x[13,11]  old_TS2   -7.4854440839665637e-01
    x[13,11]  old_TS3   -7.4854440839665637e-01
    x[13,11]  old_TS4   -4.3059745130229338e-01
    x[13,12]  OBJ       -3.7110721153846171e-02
    x[13,12]  onehot_13  1
    x[13,12]  w_lb_13_12  -3.9145222845663033e-02
    x[13,12]  w_ub_13_12  -0.0680494916724233
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,12]  old_TS1   -4.6974267414795640e-01
    x[13,12]  old_TS2   -8.1659390006907961e-01
    x[13,12]  old_TS3   -8.1659390006907961e-01
    x[13,12]  old_TS4   -4.6974267414795640e-01
    x[13,13]  OBJ       -4.3858125000000005e-02
    x[13,13]  onehot_13  1
    x[13,13]  w_lb_13_13  -3.9145222845663033e-02
    x[13,13]  w_ub_13_13  -0.0680494916724233
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,13]  old_TS1   -5.0888789699361947e-01
    x[13,13]  old_TS2   -8.8464339174150286e-01
    x[13,13]  old_TS3   -8.8464339174150286e-01
    x[13,13]  old_TS4   -5.0888789699361947e-01
    x[13,14]  OBJ       -3.7110721153846157e-02
    x[13,14]  onehot_13  1
    x[13,14]  w_lb_13_14  -3.9145222845663033e-02
    x[13,14]  w_ub_13_14  -0.0680494916724233
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,14]  old_TS1   -5.4803311983928249e-01
    x[13,14]  old_TS2   -9.5269288341392622e-01
    x[13,14]  old_TS3   -9.5269288341392622e-01
    x[13,14]  old_TS4   -5.4803311983928249e-01
    x[13,15]  OBJ       -3.0363317307692310e-02
    x[13,15]  onehot_13  1
    x[13,15]  w_lb_13_15  -3.9145222845663033e-02
    x[13,15]  w_ub_13_15  -0.0680494916724233
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,15]  old_TS1   -5.8717834268494551e-01
    x[13,15]  old_TS2   -1.0207423750863496e+00
    x[13,15]  old_TS3   -1.0207423750863496e+00
    x[13,15]  old_TS4   -5.8717834268494551e-01
    x[13,16]  OBJ       -2.3615913461538462e-02
    x[13,16]  onehot_13  1
    x[13,16]  w_lb_13_16  -3.9145222845663033e-02
    x[13,16]  w_ub_13_16  -0.0680494916724233
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,16]  old_TS1   -6.2632356553060853e-01
    x[13,16]  old_TS2   -1.0887918667587728e+00
    x[13,16]  old_TS3   -1.0887918667587728e+00
    x[13,16]  old_TS4   -6.2632356553060853e-01
    x[13,17]  OBJ       -1.6868509615384615e-02
    x[13,17]  onehot_13  1
    x[13,17]  w_lb_13_17  -3.9145222845663033e-02
    x[13,17]  w_ub_13_17  -0.0680494916724233
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,17]  old_TS1   -6.6546878837627155e-01
    x[13,17]  old_TS2   -1.1568413584311961e+00
    x[13,17]  old_TS3   -1.1568413584311961e+00
    x[13,17]  old_TS4   -6.6546878837627155e-01
    x[13,18]  OBJ       -1.0121105769230768e-02
    x[13,18]  onehot_13  1
    x[13,18]  w_lb_13_18  -3.9145222845663033e-02
    x[13,18]  w_ub_13_18  -0.0680494916724233
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,18]  old_TS1   -7.0461401122193457e-01
    x[13,18]  old_TS2   -1.2248908501036193e+00
    x[13,18]  old_TS3   -1.2248908501036193e+00
    x[13,18]  old_TS4   -7.0461401122193457e-01
    x[13,19]  OBJ       -3.3737019230769189e-03
    x[13,19]  onehot_13  1
    x[13,19]  w_lb_13_19  -3.9145222845663033e-02
    x[13,19]  w_ub_13_19  -0.0680494916724233
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[13,19]  old_TS1   -7.4375923406759759e-01
    x[13,19]  old_TS2   -1.2929403417760428e+00
    x[13,19]  old_TS3   -1.2929403417760428e+00
    x[13,19]  old_TS4   -7.4375923406759759e-01
    x[13,20]  OBJ       3.3737019230769285e-03
    x[13,20]  onehot_13  1
    x[13,20]  w_lb_13_20  -3.9145222845663033e-02
    x[13,20]  w_ub_13_20  -0.0680494916724233
    x[13,20]  hard_lower  20
    x[13,20]  hard_upper  20
    x[13,20]  old_TS1   -7.8290445691326060e-01
    x[13,20]  old_TS2   -1.3609898334484660e+00
    x[13,20]  old_TS3   -1.3609898334484660e+00
    x[13,20]  old_TS4   -7.8290445691326060e-01
    x[13,21]  OBJ       1.0121105769230775e-02
    x[13,21]  onehot_13  1
    x[13,21]  w_lb_13_21  -3.9145222845663033e-02
    x[13,21]  w_ub_13_21  -0.0680494916724233
    x[13,21]  hard_lower  21
    x[13,21]  hard_upper  21
    x[13,21]  old_TS1   -8.2204967975892373e-01
    x[13,21]  old_TS2   -1.4290393251208893e+00
    x[13,21]  old_TS3   -1.4290393251208893e+00
    x[13,21]  old_TS4   -8.2204967975892373e-01
    x[13,22]  OBJ       1.6868509615384622e-02
    x[13,22]  onehot_13  1
    x[13,22]  w_lb_13_22  -3.9145222845663033e-02
    x[13,22]  w_ub_13_22  -0.0680494916724233
    x[13,22]  hard_lower  22
    x[13,22]  hard_upper  22
    x[13,22]  old_TS1   -8.6119490260458675e-01
    x[13,22]  old_TS2   -1.4970888167933127e+00
    x[13,22]  old_TS3   -1.4970888167933127e+00
    x[13,22]  old_TS4   -8.6119490260458675e-01
    x[13,23]  OBJ       2.3615913461538469e-02
    x[13,23]  onehot_13  1
    x[13,23]  w_lb_13_23  -3.9145222845663033e-02
    x[13,23]  w_ub_13_23  -0.0680494916724233
    x[13,23]  hard_lower  23
    x[13,23]  hard_upper  23
    x[13,23]  old_TS1   -9.0034012545024977e-01
    x[13,23]  old_TS2   -1.5651383084657360e+00
    x[13,23]  old_TS3   -1.5651383084657360e+00
    x[13,23]  old_TS4   -9.0034012545024977e-01
    x[13,24]  OBJ       3.0363317307692317e-02
    x[13,24]  onehot_13  1
    x[13,24]  w_lb_13_24  -3.9145222845663033e-02
    x[13,24]  w_ub_13_24  -0.0680494916724233
    x[13,24]  hard_lower  24
    x[13,24]  hard_upper  24
    x[13,24]  old_TS1   -9.3948534829591279e-01
    x[13,24]  old_TS2   -1.6331878001381592e+00
    x[13,24]  old_TS3   -1.6331878001381592e+00
    x[13,24]  old_TS4   -9.3948534829591279e-01
    x[13,25]  OBJ       3.7110721153846164e-02
    x[13,25]  onehot_13  1
    x[13,25]  w_lb_13_25  -3.9145222845663033e-02
    x[13,25]  w_ub_13_25  -0.0680494916724233
    x[13,25]  hard_lower  25
    x[13,25]  hard_upper  25
    x[13,25]  old_TS1   -9.7863057114157581e-01
    x[13,25]  old_TS2   -1.7012372918105825e+00
    x[13,25]  old_TS3   -1.7012372918105825e+00
    x[13,25]  old_TS4   -9.7863057114157581e-01
    x[14,0]   OBJ       0.043858125
    x[14,0]   onehot_14  1
    x[14,0]   w_lb_14_0  -3.9145222845663033e-02
    x[14,0]   w_ub_14_0  -0.0680494916724233
    x[14,1]   OBJ       3.7110721153846150e-02
    x[14,1]   onehot_14  1
    x[14,1]   w_lb_14_1  -3.9145222845663033e-02
    x[14,1]   w_ub_14_1  -0.0680494916724233
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,1]   old_TS1   -3.9145222845663033e-02
    x[14,1]   old_TS2   -0.0680494916724233
    x[14,1]   old_TS3   -0.0680494916724233
    x[14,1]   old_TS4   -3.9145222845663033e-02
    x[14,2]   OBJ       3.0363317307692306e-02
    x[14,2]   onehot_14  1
    x[14,2]   w_lb_14_2  -3.9145222845663033e-02
    x[14,2]   w_ub_14_2  -0.0680494916724233
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,2]   old_TS1   -7.8290445691326066e-02
    x[14,2]   old_TS2   -1.3609898334484660e-01
    x[14,2]   old_TS3   -1.3609898334484660e-01
    x[14,2]   old_TS4   -7.8290445691326066e-02
    x[14,3]   OBJ       2.3615913461538459e-02
    x[14,3]   onehot_14  1
    x[14,3]   w_lb_14_3  -3.9145222845663033e-02
    x[14,3]   w_ub_14_3  -0.0680494916724233
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,3]   old_TS1   -1.1743566853698910e-01
    x[14,3]   old_TS2   -2.0414847501726990e-01
    x[14,3]   old_TS3   -2.0414847501726990e-01
    x[14,3]   old_TS4   -1.1743566853698910e-01
    x[14,4]   OBJ       1.6868509615384612e-02
    x[14,4]   onehot_14  1
    x[14,4]   w_lb_14_4  -3.9145222845663033e-02
    x[14,4]   w_ub_14_4  -0.0680494916724233
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,4]   old_TS1   -1.5658089138265213e-01
    x[14,4]   old_TS2   -2.7219796668969320e-01
    x[14,4]   old_TS3   -2.7219796668969320e-01
    x[14,4]   old_TS4   -1.5658089138265213e-01
    x[14,5]   OBJ       1.0121105769230766e-02
    x[14,5]   onehot_14  1
    x[14,5]   w_lb_14_5  -3.9145222845663033e-02
    x[14,5]   w_ub_14_5  -0.0680494916724233
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,5]   old_TS1   -1.9572611422831515e-01
    x[14,5]   old_TS2   -3.4024745836211651e-01
    x[14,5]   old_TS3   -3.4024745836211651e-01
    x[14,5]   old_TS4   -1.9572611422831515e-01
    x[14,6]   OBJ       3.3737019230769185e-03
    x[14,6]   onehot_14  1
    x[14,6]   w_lb_14_6  -3.9145222845663033e-02
    x[14,6]   w_ub_14_6  -0.0680494916724233
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,6]   old_TS1   -2.3487133707397820e-01
    x[14,6]   old_TS2   -4.0829695003453981e-01
    x[14,6]   old_TS3   -4.0829695003453981e-01
    x[14,6]   old_TS4   -2.3487133707397820e-01
    x[14,7]   OBJ       -3.3737019230769289e-03
    x[14,7]   onehot_14  1
    x[14,7]   w_lb_14_7  -3.9145222845663033e-02
    x[14,7]   w_ub_14_7  -0.0680494916724233
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,7]   old_TS1   -2.7401655991964124e-01
    x[14,7]   old_TS2   -4.7634644170696311e-01
    x[14,7]   old_TS3   -4.7634644170696311e-01
    x[14,7]   old_TS4   -2.7401655991964124e-01
    x[14,8]   OBJ       -1.0121105769230776e-02
    x[14,8]   onehot_14  1
    x[14,8]   w_lb_14_8  -3.9145222845663033e-02
    x[14,8]   w_ub_14_8  -0.0680494916724233
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,8]   old_TS1   -3.1316178276530426e-01
    x[14,8]   old_TS2   -5.4439593337938641e-01
    x[14,8]   old_TS3   -5.4439593337938641e-01
    x[14,8]   old_TS4   -3.1316178276530426e-01
    x[14,9]   OBJ       -1.6868509615384625e-02
    x[14,9]   onehot_14  1
    x[14,9]   w_lb_14_9  -3.9145222845663033e-02
    x[14,9]   w_ub_14_9  -0.0680494916724233
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,9]   old_TS1   -3.5230700561096728e-01
    x[14,9]   old_TS2   -6.1244542505180966e-01
    x[14,9]   old_TS3   -6.1244542505180966e-01
    x[14,9]   old_TS4   -3.5230700561096728e-01
    x[14,10]  OBJ       -2.3615913461538473e-02
    x[14,10]  onehot_14  1
    x[14,10]  w_lb_14_10  -3.9145222845663033e-02
    x[14,10]  w_ub_14_10  -0.0680494916724233
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,10]  old_TS1   -3.9145222845663030e-01
    x[14,10]  old_TS2   -0.680494916724233
    x[14,10]  old_TS3   -0.680494916724233
    x[14,10]  old_TS4   -3.9145222845663030e-01
    x[14,11]  OBJ       -3.0363317307692320e-02
    x[14,11]  onehot_14  1
    x[14,11]  w_lb_14_11  -3.9145222845663033e-02
    x[14,11]  w_ub_14_11  -0.0680494916724233
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,11]  old_TS1   -4.3059745130229338e-01
    x[14,11]  old_TS2   -7.4854440839665637e-01
    x[14,11]  old_TS3   -7.4854440839665637e-01
    x[14,11]  old_TS4   -4.3059745130229338e-01
    x[14,12]  OBJ       -3.7110721153846171e-02
    x[14,12]  onehot_14  1
    x[14,12]  w_lb_14_12  -3.9145222845663033e-02
    x[14,12]  w_ub_14_12  -0.0680494916724233
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,12]  old_TS1   -4.6974267414795640e-01
    x[14,12]  old_TS2   -8.1659390006907961e-01
    x[14,12]  old_TS3   -8.1659390006907961e-01
    x[14,12]  old_TS4   -4.6974267414795640e-01
    x[14,13]  OBJ       -4.3858125000000005e-02
    x[14,13]  onehot_14  1
    x[14,13]  w_lb_14_13  -3.9145222845663033e-02
    x[14,13]  w_ub_14_13  -0.0680494916724233
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,13]  old_TS1   -5.0888789699361947e-01
    x[14,13]  old_TS2   -8.8464339174150286e-01
    x[14,13]  old_TS3   -8.8464339174150286e-01
    x[14,13]  old_TS4   -5.0888789699361947e-01
    x[14,14]  OBJ       -3.7110721153846157e-02
    x[14,14]  onehot_14  1
    x[14,14]  w_lb_14_14  -3.9145222845663033e-02
    x[14,14]  w_ub_14_14  -0.0680494916724233
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,14]  old_TS1   -5.4803311983928249e-01
    x[14,14]  old_TS2   -9.5269288341392622e-01
    x[14,14]  old_TS3   -9.5269288341392622e-01
    x[14,14]  old_TS4   -5.4803311983928249e-01
    x[14,15]  OBJ       -3.0363317307692310e-02
    x[14,15]  onehot_14  1
    x[14,15]  w_lb_14_15  -3.9145222845663033e-02
    x[14,15]  w_ub_14_15  -0.0680494916724233
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[14,15]  old_TS1   -5.8717834268494551e-01
    x[14,15]  old_TS2   -1.0207423750863496e+00
    x[14,15]  old_TS3   -1.0207423750863496e+00
    x[14,15]  old_TS4   -5.8717834268494551e-01
    x[14,16]  OBJ       -2.3615913461538462e-02
    x[14,16]  onehot_14  1
    x[14,16]  w_lb_14_16  -3.9145222845663033e-02
    x[14,16]  w_ub_14_16  -0.0680494916724233
    x[14,16]  hard_lower  16
    x[14,16]  hard_upper  16
    x[14,16]  old_TS1   -6.2632356553060853e-01
    x[14,16]  old_TS2   -1.0887918667587728e+00
    x[14,16]  old_TS3   -1.0887918667587728e+00
    x[14,16]  old_TS4   -6.2632356553060853e-01
    x[14,17]  OBJ       -1.6868509615384615e-02
    x[14,17]  onehot_14  1
    x[14,17]  w_lb_14_17  -3.9145222845663033e-02
    x[14,17]  w_ub_14_17  -0.0680494916724233
    x[14,17]  hard_lower  17
    x[14,17]  hard_upper  17
    x[14,17]  old_TS1   -6.6546878837627155e-01
    x[14,17]  old_TS2   -1.1568413584311961e+00
    x[14,17]  old_TS3   -1.1568413584311961e+00
    x[14,17]  old_TS4   -6.6546878837627155e-01
    x[14,18]  OBJ       -1.0121105769230768e-02
    x[14,18]  onehot_14  1
    x[14,18]  w_lb_14_18  -3.9145222845663033e-02
    x[14,18]  w_ub_14_18  -0.0680494916724233
    x[14,18]  hard_lower  18
    x[14,18]  hard_upper  18
    x[14,18]  old_TS1   -7.0461401122193457e-01
    x[14,18]  old_TS2   -1.2248908501036193e+00
    x[14,18]  old_TS3   -1.2248908501036193e+00
    x[14,18]  old_TS4   -7.0461401122193457e-01
    x[14,19]  OBJ       -3.3737019230769189e-03
    x[14,19]  onehot_14  1
    x[14,19]  w_lb_14_19  -3.9145222845663033e-02
    x[14,19]  w_ub_14_19  -0.0680494916724233
    x[14,19]  hard_lower  19
    x[14,19]  hard_upper  19
    x[14,19]  old_TS1   -7.4375923406759759e-01
    x[14,19]  old_TS2   -1.2929403417760428e+00
    x[14,19]  old_TS3   -1.2929403417760428e+00
    x[14,19]  old_TS4   -7.4375923406759759e-01
    x[14,20]  OBJ       3.3737019230769285e-03
    x[14,20]  onehot_14  1
    x[14,20]  w_lb_14_20  -3.9145222845663033e-02
    x[14,20]  w_ub_14_20  -0.0680494916724233
    x[14,20]  hard_lower  20
    x[14,20]  hard_upper  20
    x[14,20]  old_TS1   -7.8290445691326060e-01
    x[14,20]  old_TS2   -1.3609898334484660e+00
    x[14,20]  old_TS3   -1.3609898334484660e+00
    x[14,20]  old_TS4   -7.8290445691326060e-01
    x[14,21]  OBJ       1.0121105769230775e-02
    x[14,21]  onehot_14  1
    x[14,21]  w_lb_14_21  -3.9145222845663033e-02
    x[14,21]  w_ub_14_21  -0.0680494916724233
    x[14,21]  hard_lower  21
    x[14,21]  hard_upper  21
    x[14,21]  old_TS1   -8.2204967975892373e-01
    x[14,21]  old_TS2   -1.4290393251208893e+00
    x[14,21]  old_TS3   -1.4290393251208893e+00
    x[14,21]  old_TS4   -8.2204967975892373e-01
    x[14,22]  OBJ       1.6868509615384622e-02
    x[14,22]  onehot_14  1
    x[14,22]  w_lb_14_22  -3.9145222845663033e-02
    x[14,22]  w_ub_14_22  -0.0680494916724233
    x[14,22]  hard_lower  22
    x[14,22]  hard_upper  22
    x[14,22]  old_TS1   -8.6119490260458675e-01
    x[14,22]  old_TS2   -1.4970888167933127e+00
    x[14,22]  old_TS3   -1.4970888167933127e+00
    x[14,22]  old_TS4   -8.6119490260458675e-01
    x[14,23]  OBJ       2.3615913461538469e-02
    x[14,23]  onehot_14  1
    x[14,23]  w_lb_14_23  -3.9145222845663033e-02
    x[14,23]  w_ub_14_23  -0.0680494916724233
    x[14,23]  hard_lower  23
    x[14,23]  hard_upper  23
    x[14,23]  old_TS1   -9.0034012545024977e-01
    x[14,23]  old_TS2   -1.5651383084657360e+00
    x[14,23]  old_TS3   -1.5651383084657360e+00
    x[14,23]  old_TS4   -9.0034012545024977e-01
    x[15,0]   OBJ       5.0865074999999996e-02
    x[15,0]   onehot_15  1
    x[15,0]   w_lb_15_0  -3.9145222845663033e-02
    x[15,0]   w_ub_15_0  -0.0680494916724233
    x[15,1]   OBJ       4.3598635714285711e-02
    x[15,1]   onehot_15  1
    x[15,1]   w_lb_15_1  -3.9145222845663033e-02
    x[15,1]   w_ub_15_1  -0.0680494916724233
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,1]   old_TS1   -3.9145222845663033e-02
    x[15,1]   old_TS2   -0.0680494916724233
    x[15,1]   old_TS3   -0.0680494916724233
    x[15,1]   old_TS4   -3.9145222845663033e-02
    x[15,2]   OBJ       3.6332196428571426e-02
    x[15,2]   onehot_15  1
    x[15,2]   w_lb_15_2  -3.9145222845663033e-02
    x[15,2]   w_ub_15_2  -0.0680494916724233
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,2]   old_TS1   -7.8290445691326066e-02
    x[15,2]   old_TS2   -1.3609898334484660e-01
    x[15,2]   old_TS3   -1.3609898334484660e-01
    x[15,2]   old_TS4   -7.8290445691326066e-02
    x[15,3]   OBJ       2.9065757142857140e-02
    x[15,3]   onehot_15  1
    x[15,3]   w_lb_15_3  -3.9145222845663033e-02
    x[15,3]   w_ub_15_3  -0.0680494916724233
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,3]   old_TS1   -1.1743566853698910e-01
    x[15,3]   old_TS2   -2.0414847501726990e-01
    x[15,3]   old_TS3   -2.0414847501726990e-01
    x[15,3]   old_TS4   -1.1743566853698910e-01
    x[15,4]   OBJ       2.1799317857142855e-02
    x[15,4]   onehot_15  1
    x[15,4]   w_lb_15_4  -3.9145222845663033e-02
    x[15,4]   w_ub_15_4  -0.0680494916724233
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,4]   old_TS1   -1.5658089138265213e-01
    x[15,4]   old_TS2   -2.7219796668969320e-01
    x[15,4]   old_TS3   -2.7219796668969320e-01
    x[15,4]   old_TS4   -1.5658089138265213e-01
    x[15,5]   OBJ       1.4532878571428570e-02
    x[15,5]   onehot_15  1
    x[15,5]   w_lb_15_5  -3.9145222845663033e-02
    x[15,5]   w_ub_15_5  -0.0680494916724233
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,5]   old_TS1   -1.9572611422831515e-01
    x[15,5]   old_TS2   -3.4024745836211651e-01
    x[15,5]   old_TS3   -3.4024745836211651e-01
    x[15,5]   old_TS4   -1.9572611422831515e-01
    x[15,6]   OBJ       7.2664392857142851e-03
    x[15,6]   onehot_15  1
    x[15,6]   w_lb_15_6  -3.9145222845663033e-02
    x[15,6]   w_ub_15_6  -0.0680494916724233
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,6]   old_TS1   -2.3487133707397820e-01
    x[15,6]   old_TS2   -4.0829695003453981e-01
    x[15,6]   old_TS3   -4.0829695003453981e-01
    x[15,6]   old_TS4   -2.3487133707397820e-01
    x[15,7]   onehot_15  1
    x[15,7]   w_lb_15_7  -3.9145222845663033e-02
    x[15,7]   w_ub_15_7  -0.0680494916724233
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,7]   old_TS1   -2.7401655991964124e-01
    x[15,7]   old_TS2   -4.7634644170696311e-01
    x[15,7]   old_TS3   -4.7634644170696311e-01
    x[15,7]   old_TS4   -2.7401655991964124e-01
    x[15,8]   OBJ       -7.2664392857142860e-03
    x[15,8]   onehot_15  1
    x[15,8]   w_lb_15_8  -3.9145222845663033e-02
    x[15,8]   w_ub_15_8  -0.0680494916724233
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,8]   old_TS1   -3.1316178276530426e-01
    x[15,8]   old_TS2   -5.4439593337938641e-01
    x[15,8]   old_TS3   -5.4439593337938641e-01
    x[15,8]   old_TS4   -3.1316178276530426e-01
    x[15,9]   OBJ       -1.4532878571428572e-02
    x[15,9]   onehot_15  1
    x[15,9]   w_lb_15_9  -3.9145222845663033e-02
    x[15,9]   w_ub_15_9  -0.0680494916724233
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,9]   old_TS1   -3.5230700561096728e-01
    x[15,9]   old_TS2   -6.1244542505180966e-01
    x[15,9]   old_TS3   -6.1244542505180966e-01
    x[15,9]   old_TS4   -3.5230700561096728e-01
    x[15,10]  OBJ       -2.1799317857142859e-02
    x[15,10]  onehot_15  1
    x[15,10]  w_lb_15_10  -3.9145222845663033e-02
    x[15,10]  w_ub_15_10  -0.0680494916724233
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,10]  old_TS1   -3.9145222845663030e-01
    x[15,10]  old_TS2   -0.680494916724233
    x[15,10]  old_TS3   -0.680494916724233
    x[15,10]  old_TS4   -3.9145222845663030e-01
    x[15,11]  OBJ       -2.9065757142857144e-02
    x[15,11]  onehot_15  1
    x[15,11]  w_lb_15_11  -3.9145222845663033e-02
    x[15,11]  w_ub_15_11  -0.0680494916724233
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,11]  old_TS1   -4.3059745130229338e-01
    x[15,11]  old_TS2   -7.4854440839665637e-01
    x[15,11]  old_TS3   -7.4854440839665637e-01
    x[15,11]  old_TS4   -4.3059745130229338e-01
    x[15,12]  OBJ       -3.6332196428571432e-02
    x[15,12]  onehot_15  1
    x[15,12]  w_lb_15_12  -3.9145222845663033e-02
    x[15,12]  w_ub_15_12  -0.0680494916724233
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,12]  old_TS1   -4.6974267414795640e-01
    x[15,12]  old_TS2   -8.1659390006907961e-01
    x[15,12]  old_TS3   -8.1659390006907961e-01
    x[15,12]  old_TS4   -4.6974267414795640e-01
    x[15,13]  OBJ       -4.3598635714285718e-02
    x[15,13]  onehot_15  1
    x[15,13]  w_lb_15_13  -3.9145222845663033e-02
    x[15,13]  w_ub_15_13  -0.0680494916724233
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,13]  old_TS1   -5.0888789699361947e-01
    x[15,13]  old_TS2   -8.8464339174150286e-01
    x[15,13]  old_TS3   -8.8464339174150286e-01
    x[15,13]  old_TS4   -5.0888789699361947e-01
    x[15,14]  OBJ       -0.050865075
    x[15,14]  onehot_15  1
    x[15,14]  w_lb_15_14  -3.9145222845663033e-02
    x[15,14]  w_ub_15_14  -0.0680494916724233
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,14]  old_TS1   -5.4803311983928249e-01
    x[15,14]  old_TS2   -9.5269288341392622e-01
    x[15,14]  old_TS3   -9.5269288341392622e-01
    x[15,14]  old_TS4   -5.4803311983928249e-01
    x[15,15]  OBJ       -4.3598635714285731e-02
    x[15,15]  onehot_15  1
    x[15,15]  w_lb_15_15  -3.9145222845663033e-02
    x[15,15]  w_ub_15_15  -0.0680494916724233
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,15]  old_TS1   -5.8717834268494551e-01
    x[15,15]  old_TS2   -1.0207423750863496e+00
    x[15,15]  old_TS3   -1.0207423750863496e+00
    x[15,15]  old_TS4   -5.8717834268494551e-01
    x[15,16]  OBJ       -3.6332196428571446e-02
    x[15,16]  onehot_15  1
    x[15,16]  w_lb_15_16  -3.9145222845663033e-02
    x[15,16]  w_ub_15_16  -0.0680494916724233
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[15,16]  old_TS1   -6.2632356553060853e-01
    x[15,16]  old_TS2   -1.0887918667587728e+00
    x[15,16]  old_TS3   -1.0887918667587728e+00
    x[15,16]  old_TS4   -6.2632356553060853e-01
    x[15,17]  OBJ       -2.9065757142857154e-02
    x[15,17]  onehot_15  1
    x[15,17]  w_lb_15_17  -3.9145222845663033e-02
    x[15,17]  w_ub_15_17  -0.0680494916724233
    x[15,17]  hard_lower  17
    x[15,17]  hard_upper  17
    x[15,17]  old_TS1   -6.6546878837627155e-01
    x[15,17]  old_TS2   -1.1568413584311961e+00
    x[15,17]  old_TS3   -1.1568413584311961e+00
    x[15,17]  old_TS4   -6.6546878837627155e-01
    x[15,18]  OBJ       -2.1799317857142869e-02
    x[15,18]  onehot_15  1
    x[15,18]  w_lb_15_18  -3.9145222845663033e-02
    x[15,18]  w_ub_15_18  -0.0680494916724233
    x[15,18]  hard_lower  18
    x[15,18]  hard_upper  18
    x[15,18]  old_TS1   -7.0461401122193457e-01
    x[15,18]  old_TS2   -1.2248908501036193e+00
    x[15,18]  old_TS3   -1.2248908501036193e+00
    x[15,18]  old_TS4   -7.0461401122193457e-01
    x[15,19]  OBJ       -1.4532878571428584e-02
    x[15,19]  onehot_15  1
    x[15,19]  w_lb_15_19  -3.9145222845663033e-02
    x[15,19]  w_ub_15_19  -0.0680494916724233
    x[15,19]  hard_lower  19
    x[15,19]  hard_upper  19
    x[15,19]  old_TS1   -7.4375923406759759e-01
    x[15,19]  old_TS2   -1.2929403417760428e+00
    x[15,19]  old_TS3   -1.2929403417760428e+00
    x[15,19]  old_TS4   -7.4375923406759759e-01
    x[15,20]  OBJ       -7.2664392857142972e-03
    x[15,20]  onehot_15  1
    x[15,20]  w_lb_15_20  -3.9145222845663033e-02
    x[15,20]  w_ub_15_20  -0.0680494916724233
    x[15,20]  hard_lower  20
    x[15,20]  hard_upper  20
    x[15,20]  old_TS1   -7.8290445691326060e-01
    x[15,20]  old_TS2   -1.3609898334484660e+00
    x[15,20]  old_TS3   -1.3609898334484660e+00
    x[15,20]  old_TS4   -7.8290445691326060e-01
    x[15,21]  OBJ       -1.1294315482857087e-17
    x[15,21]  onehot_15  1
    x[15,21]  w_lb_15_21  -3.9145222845663033e-02
    x[15,21]  w_ub_15_21  -0.0680494916724233
    x[15,21]  hard_lower  21
    x[15,21]  hard_upper  21
    x[15,21]  old_TS1   -8.2204967975892373e-01
    x[15,21]  old_TS2   -1.4290393251208893e+00
    x[15,21]  old_TS3   -1.4290393251208893e+00
    x[15,21]  old_TS4   -8.2204967975892373e-01
    x[15,22]  OBJ       7.2664392857142738e-03
    x[15,22]  onehot_15  1
    x[15,22]  w_lb_15_22  -3.9145222845663033e-02
    x[15,22]  w_ub_15_22  -0.0680494916724233
    x[15,22]  hard_lower  22
    x[15,22]  hard_upper  22
    x[15,22]  old_TS1   -8.6119490260458675e-01
    x[15,22]  old_TS2   -1.4970888167933127e+00
    x[15,22]  old_TS3   -1.4970888167933127e+00
    x[15,22]  old_TS4   -8.6119490260458675e-01
    x[15,23]  OBJ       1.4532878571428560e-02
    x[15,23]  onehot_15  1
    x[15,23]  w_lb_15_23  -3.9145222845663033e-02
    x[15,23]  w_ub_15_23  -0.0680494916724233
    x[15,23]  hard_lower  23
    x[15,23]  hard_upper  23
    x[15,23]  old_TS1   -9.0034012545024977e-01
    x[15,23]  old_TS2   -1.5651383084657360e+00
    x[15,23]  old_TS3   -1.5651383084657360e+00
    x[15,23]  old_TS4   -9.0034012545024977e-01
    x[15,24]  OBJ       2.1799317857142845e-02
    x[15,24]  onehot_15  1
    x[15,24]  w_lb_15_24  -3.9145222845663033e-02
    x[15,24]  w_ub_15_24  -0.0680494916724233
    x[15,24]  hard_lower  24
    x[15,24]  hard_upper  24
    x[15,24]  old_TS1   -9.3948534829591279e-01
    x[15,24]  old_TS2   -1.6331878001381592e+00
    x[15,24]  old_TS3   -1.6331878001381592e+00
    x[15,24]  old_TS4   -9.3948534829591279e-01
    x[15,25]  OBJ       2.9065757142857130e-02
    x[15,25]  onehot_15  1
    x[15,25]  w_lb_15_25  -3.9145222845663033e-02
    x[15,25]  w_ub_15_25  -0.0680494916724233
    x[15,25]  hard_lower  25
    x[15,25]  hard_upper  25
    x[15,25]  old_TS1   -9.7863057114157581e-01
    x[15,25]  old_TS2   -1.7012372918105825e+00
    x[15,25]  old_TS3   -1.7012372918105825e+00
    x[15,25]  old_TS4   -9.7863057114157581e-01
    x[15,26]  OBJ       3.6332196428571412e-02
    x[15,26]  onehot_15  1
    x[15,26]  w_lb_15_26  -3.9145222845663033e-02
    x[15,26]  w_ub_15_26  -0.0680494916724233
    x[15,26]  hard_lower  26
    x[15,26]  hard_upper  26
    x[15,26]  old_TS1   -1.0177757939872389e+00
    x[15,26]  old_TS2   -1.7692867834830057e+00
    x[15,26]  old_TS3   -1.7692867834830057e+00
    x[15,26]  old_TS4   -1.0177757939872389e+00
    x[15,27]  OBJ       0.0435986357142857
    x[15,27]  onehot_15  1
    x[15,27]  w_lb_15_27  -3.9145222845663033e-02
    x[15,27]  w_ub_15_27  -0.0680494916724233
    x[15,27]  hard_lower  27
    x[15,27]  hard_upper  27
    x[15,27]  old_TS1   -1.0569210168329020e+00
    x[15,27]  old_TS2   -1.8373362751554292e+00
    x[15,27]  old_TS3   -1.8373362751554292e+00
    x[15,27]  old_TS4   -1.0569210168329020e+00
    x[16,0]   OBJ       3.7370249999999994e-02
    x[16,0]   onehot_16  1
    x[16,0]   w_lb_16_0  -3.9145222845663033e-02
    x[16,0]   w_ub_16_0  -0.0680494916724233
    x[16,1]   OBJ       3.1141874999999996e-02
    x[16,1]   onehot_16  1
    x[16,1]   w_lb_16_1  -3.9145222845663033e-02
    x[16,1]   w_ub_16_1  -0.0680494916724233
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,1]   old_TS1   -3.9145222845663033e-02
    x[16,1]   old_TS2   -0.0680494916724233
    x[16,1]   old_TS3   -0.0680494916724233
    x[16,1]   old_TS4   -3.9145222845663033e-02
    x[16,2]   OBJ       2.4913499999999998e-02
    x[16,2]   onehot_16  1
    x[16,2]   w_lb_16_2  -3.9145222845663033e-02
    x[16,2]   w_ub_16_2  -0.0680494916724233
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,2]   old_TS1   -7.8290445691326066e-02
    x[16,2]   old_TS2   -1.3609898334484660e-01
    x[16,2]   old_TS3   -1.3609898334484660e-01
    x[16,2]   old_TS4   -7.8290445691326066e-02
    x[16,3]   OBJ       1.8685124999999997e-02
    x[16,3]   onehot_16  1
    x[16,3]   w_lb_16_3  -3.9145222845663033e-02
    x[16,3]   w_ub_16_3  -0.0680494916724233
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,3]   old_TS1   -1.1743566853698910e-01
    x[16,3]   old_TS2   -2.0414847501726990e-01
    x[16,3]   old_TS3   -2.0414847501726990e-01
    x[16,3]   old_TS4   -1.1743566853698910e-01
    x[16,4]   OBJ       1.2456749999999999e-02
    x[16,4]   onehot_16  1
    x[16,4]   w_lb_16_4  -3.9145222845663033e-02
    x[16,4]   w_ub_16_4  -0.0680494916724233
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,4]   old_TS1   -1.5658089138265213e-01
    x[16,4]   old_TS2   -2.7219796668969320e-01
    x[16,4]   old_TS3   -2.7219796668969320e-01
    x[16,4]   old_TS4   -1.5658089138265213e-01
    x[16,5]   OBJ       6.2283749999999995e-03
    x[16,5]   onehot_16  1
    x[16,5]   w_lb_16_5  -3.9145222845663033e-02
    x[16,5]   w_ub_16_5  -0.0680494916724233
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,5]   old_TS1   -1.9572611422831515e-01
    x[16,5]   old_TS2   -3.4024745836211651e-01
    x[16,5]   old_TS3   -3.4024745836211651e-01
    x[16,5]   old_TS4   -1.9572611422831515e-01
    x[16,6]   onehot_16  1
    x[16,6]   w_lb_16_6  -3.9145222845663033e-02
    x[16,6]   w_ub_16_6  -0.0680494916724233
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,6]   old_TS1   -2.3487133707397820e-01
    x[16,6]   old_TS2   -4.0829695003453981e-01
    x[16,6]   old_TS3   -4.0829695003453981e-01
    x[16,6]   old_TS4   -2.3487133707397820e-01
    x[16,7]   OBJ       -0.006228375
    x[16,7]   onehot_16  1
    x[16,7]   w_lb_16_7  -3.9145222845663033e-02
    x[16,7]   w_ub_16_7  -0.0680494916724233
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,7]   old_TS1   -2.7401655991964124e-01
    x[16,7]   old_TS2   -4.7634644170696311e-01
    x[16,7]   old_TS3   -4.7634644170696311e-01
    x[16,7]   old_TS4   -2.7401655991964124e-01
    x[16,8]   OBJ       -0.01245675
    x[16,8]   onehot_16  1
    x[16,8]   w_lb_16_8  -3.9145222845663033e-02
    x[16,8]   w_ub_16_8  -0.0680494916724233
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,8]   old_TS1   -3.1316178276530426e-01
    x[16,8]   old_TS2   -5.4439593337938641e-01
    x[16,8]   old_TS3   -5.4439593337938641e-01
    x[16,8]   old_TS4   -3.1316178276530426e-01
    x[16,9]   OBJ       -0.018685125
    x[16,9]   onehot_16  1
    x[16,9]   w_lb_16_9  -3.9145222845663033e-02
    x[16,9]   w_ub_16_9  -0.0680494916724233
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,9]   old_TS1   -3.5230700561096728e-01
    x[16,9]   old_TS2   -6.1244542505180966e-01
    x[16,9]   old_TS3   -6.1244542505180966e-01
    x[16,9]   old_TS4   -3.5230700561096728e-01
    x[16,10]  OBJ       -0.0249135
    x[16,10]  onehot_16  1
    x[16,10]  w_lb_16_10  -3.9145222845663033e-02
    x[16,10]  w_ub_16_10  -0.0680494916724233
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,10]  old_TS1   -3.9145222845663030e-01
    x[16,10]  old_TS2   -0.680494916724233
    x[16,10]  old_TS3   -0.680494916724233
    x[16,10]  old_TS4   -3.9145222845663030e-01
    x[16,11]  OBJ       -0.031141875
    x[16,11]  onehot_16  1
    x[16,11]  w_lb_16_11  -3.9145222845663033e-02
    x[16,11]  w_ub_16_11  -0.0680494916724233
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[16,11]  old_TS1   -4.3059745130229338e-01
    x[16,11]  old_TS2   -7.4854440839665637e-01
    x[16,11]  old_TS3   -7.4854440839665637e-01
    x[16,11]  old_TS4   -4.3059745130229338e-01
    x[16,12]  OBJ       -0.03737025
    x[16,12]  onehot_16  1
    x[16,12]  w_lb_16_12  -3.9145222845663033e-02
    x[16,12]  w_ub_16_12  -0.0680494916724233
    x[16,12]  hard_lower  12
    x[16,12]  hard_upper  12
    x[16,12]  old_TS1   -4.6974267414795640e-01
    x[16,12]  old_TS2   -8.1659390006907961e-01
    x[16,12]  old_TS3   -8.1659390006907961e-01
    x[16,12]  old_TS4   -4.6974267414795640e-01
    x[16,13]  OBJ       -3.1141875000000010e-02
    x[16,13]  onehot_16  1
    x[16,13]  w_lb_16_13  -3.9145222845663033e-02
    x[16,13]  w_ub_16_13  -0.0680494916724233
    x[16,13]  hard_lower  13
    x[16,13]  hard_upper  13
    x[16,13]  old_TS1   -5.0888789699361947e-01
    x[16,13]  old_TS2   -8.8464339174150286e-01
    x[16,13]  old_TS3   -8.8464339174150286e-01
    x[16,13]  old_TS4   -5.0888789699361947e-01
    x[16,14]  OBJ       -2.4913500000000009e-02
    x[16,14]  onehot_16  1
    x[16,14]  w_lb_16_14  -3.9145222845663033e-02
    x[16,14]  w_ub_16_14  -0.0680494916724233
    x[16,14]  hard_lower  14
    x[16,14]  hard_upper  14
    x[16,14]  old_TS1   -5.4803311983928249e-01
    x[16,14]  old_TS2   -9.5269288341392622e-01
    x[16,14]  old_TS3   -9.5269288341392622e-01
    x[16,14]  old_TS4   -5.4803311983928249e-01
    x[16,15]  OBJ       -1.8685125000000011e-02
    x[16,15]  onehot_16  1
    x[16,15]  w_lb_16_15  -3.9145222845663033e-02
    x[16,15]  w_ub_16_15  -0.0680494916724233
    x[16,15]  hard_lower  15
    x[16,15]  hard_upper  15
    x[16,15]  old_TS1   -5.8717834268494551e-01
    x[16,15]  old_TS2   -1.0207423750863496e+00
    x[16,15]  old_TS3   -1.0207423750863496e+00
    x[16,15]  old_TS4   -5.8717834268494551e-01
    x[16,16]  OBJ       -1.2456750000000009e-02
    x[16,16]  onehot_16  1
    x[16,16]  w_lb_16_16  -3.9145222845663033e-02
    x[16,16]  w_ub_16_16  -0.0680494916724233
    x[16,16]  hard_lower  16
    x[16,16]  hard_upper  16
    x[16,16]  old_TS1   -6.2632356553060853e-01
    x[16,16]  old_TS2   -1.0887918667587728e+00
    x[16,16]  old_TS3   -1.0887918667587728e+00
    x[16,16]  old_TS4   -6.2632356553060853e-01
    x[16,17]  OBJ       -6.2283750000000082e-03
    x[16,17]  onehot_16  1
    x[16,17]  w_lb_16_17  -3.9145222845663033e-02
    x[16,17]  w_ub_16_17  -0.0680494916724233
    x[16,17]  hard_lower  17
    x[16,17]  hard_upper  17
    x[16,17]  old_TS1   -6.6546878837627155e-01
    x[16,17]  old_TS2   -1.1568413584311961e+00
    x[16,17]  old_TS3   -1.1568413584311961e+00
    x[16,17]  old_TS4   -6.6546878837627155e-01
    x[16,18]  OBJ       -8.2978623971996514e-18
    x[16,18]  onehot_16  1
    x[16,18]  w_lb_16_18  -3.9145222845663033e-02
    x[16,18]  w_ub_16_18  -0.0680494916724233
    x[16,18]  hard_lower  18
    x[16,18]  hard_upper  18
    x[16,18]  old_TS1   -7.0461401122193457e-01
    x[16,18]  old_TS2   -1.2248908501036193e+00
    x[16,18]  old_TS3   -1.2248908501036193e+00
    x[16,18]  old_TS4   -7.0461401122193457e-01
    x[16,19]  OBJ       6.2283749999999909e-03
    x[16,19]  onehot_16  1
    x[16,19]  w_lb_16_19  -3.9145222845663033e-02
    x[16,19]  w_ub_16_19  -0.0680494916724233
    x[16,19]  hard_lower  19
    x[16,19]  hard_upper  19
    x[16,19]  old_TS1   -7.4375923406759759e-01
    x[16,19]  old_TS2   -1.2929403417760428e+00
    x[16,19]  old_TS3   -1.2929403417760428e+00
    x[16,19]  old_TS4   -7.4375923406759759e-01
    x[16,20]  OBJ       1.2456749999999990e-02
    x[16,20]  onehot_16  1
    x[16,20]  w_lb_16_20  -3.9145222845663033e-02
    x[16,20]  w_ub_16_20  -0.0680494916724233
    x[16,20]  hard_lower  20
    x[16,20]  hard_upper  20
    x[16,20]  old_TS1   -7.8290445691326060e-01
    x[16,20]  old_TS2   -1.3609898334484660e+00
    x[16,20]  old_TS3   -1.3609898334484660e+00
    x[16,20]  old_TS4   -7.8290445691326060e-01
    x[16,21]  OBJ       1.8685124999999990e-02
    x[16,21]  onehot_16  1
    x[16,21]  w_lb_16_21  -3.9145222845663033e-02
    x[16,21]  w_ub_16_21  -0.0680494916724233
    x[16,21]  hard_lower  21
    x[16,21]  hard_upper  21
    x[16,21]  old_TS1   -8.2204967975892373e-01
    x[16,21]  old_TS2   -1.4290393251208893e+00
    x[16,21]  old_TS3   -1.4290393251208893e+00
    x[16,21]  old_TS4   -8.2204967975892373e-01
    x[16,22]  OBJ       2.4913499999999988e-02
    x[16,22]  onehot_16  1
    x[16,22]  w_lb_16_22  -3.9145222845663033e-02
    x[16,22]  w_ub_16_22  -0.0680494916724233
    x[16,22]  hard_lower  22
    x[16,22]  hard_upper  22
    x[16,22]  old_TS1   -8.6119490260458675e-01
    x[16,22]  old_TS2   -1.4970888167933127e+00
    x[16,22]  old_TS3   -1.4970888167933127e+00
    x[16,22]  old_TS4   -8.6119490260458675e-01
    x[17,0]   OBJ       0.010380609375
    x[17,0]   onehot_17  1
    x[17,0]   w_lb_17_0  -3.9145222845663033e-02
    x[17,0]   w_ub_17_0  -0.0680494916724233
    x[17,1]   OBJ       0.006228365625
    x[17,1]   onehot_17  1
    x[17,1]   w_lb_17_1  -3.9145222845663033e-02
    x[17,1]   w_ub_17_1  -0.0680494916724233
    x[17,1]   hard_lower  1
    x[17,1]   hard_upper  1
    x[17,1]   old_TS1   -3.9145222845663033e-02
    x[17,1]   old_TS2   -0.0680494916724233
    x[17,1]   old_TS3   -0.0680494916724233
    x[17,1]   old_TS4   -3.9145222845663033e-02
    x[17,2]   OBJ       0.002076121875
    x[17,2]   onehot_17  1
    x[17,2]   w_lb_17_2  -3.9145222845663033e-02
    x[17,2]   w_ub_17_2  -0.0680494916724233
    x[17,2]   hard_lower  2
    x[17,2]   hard_upper  2
    x[17,2]   old_TS1   -7.8290445691326066e-02
    x[17,2]   old_TS2   -1.3609898334484660e-01
    x[17,2]   old_TS3   -1.3609898334484660e-01
    x[17,2]   old_TS4   -7.8290445691326066e-02
    x[17,3]   OBJ       -0.002076121875
    x[17,3]   onehot_17  1
    x[17,3]   w_lb_17_3  -3.9145222845663033e-02
    x[17,3]   w_ub_17_3  -0.0680494916724233
    x[17,3]   hard_lower  3
    x[17,3]   hard_upper  3
    x[17,3]   old_TS1   -1.1743566853698910e-01
    x[17,3]   old_TS2   -2.0414847501726990e-01
    x[17,3]   old_TS3   -2.0414847501726990e-01
    x[17,3]   old_TS4   -1.1743566853698910e-01
    x[17,4]   OBJ       -6.2283656250000010e-03
    x[17,4]   onehot_17  1
    x[17,4]   w_lb_17_4  -3.9145222845663033e-02
    x[17,4]   w_ub_17_4  -0.0680494916724233
    x[17,4]   hard_lower  4
    x[17,4]   hard_upper  4
    x[17,4]   old_TS1   -1.5658089138265213e-01
    x[17,4]   old_TS2   -2.7219796668969320e-01
    x[17,4]   old_TS3   -2.7219796668969320e-01
    x[17,4]   old_TS4   -1.5658089138265213e-01
    x[17,5]   OBJ       -1.0380609375000002e-02
    x[17,5]   onehot_17  1
    x[17,5]   w_lb_17_5  -3.9145222845663033e-02
    x[17,5]   w_ub_17_5  -0.0680494916724233
    x[17,5]   hard_lower  5
    x[17,5]   hard_upper  5
    x[17,5]   old_TS1   -1.9572611422831515e-01
    x[17,5]   old_TS2   -3.4024745836211651e-01
    x[17,5]   old_TS3   -3.4024745836211651e-01
    x[17,5]   old_TS4   -1.9572611422831515e-01
    x[17,6]   OBJ       -1.4532853125000002e-02
    x[17,6]   onehot_17  1
    x[17,6]   w_lb_17_6  -3.9145222845663033e-02
    x[17,6]   w_ub_17_6  -0.0680494916724233
    x[17,6]   hard_lower  6
    x[17,6]   hard_upper  6
    x[17,6]   old_TS1   -2.3487133707397820e-01
    x[17,6]   old_TS2   -4.0829695003453981e-01
    x[17,6]   old_TS3   -4.0829695003453981e-01
    x[17,6]   old_TS4   -2.3487133707397820e-01
    x[17,7]   OBJ       -1.8685096875000005e-02
    x[17,7]   onehot_17  1
    x[17,7]   w_lb_17_7  -3.9145222845663033e-02
    x[17,7]   w_ub_17_7  -0.0680494916724233
    x[17,7]   hard_lower  7
    x[17,7]   hard_upper  7
    x[17,7]   old_TS1   -2.7401655991964124e-01
    x[17,7]   old_TS2   -4.7634644170696311e-01
    x[17,7]   old_TS3   -4.7634644170696311e-01
    x[17,7]   old_TS4   -2.7401655991964124e-01
    x[17,8]   OBJ       -2.2837340625000004e-02
    x[17,8]   onehot_17  1
    x[17,8]   w_lb_17_8  -3.9145222845663033e-02
    x[17,8]   w_ub_17_8  -0.0680494916724233
    x[17,8]   hard_lower  8
    x[17,8]   hard_upper  8
    x[17,8]   old_TS1   -3.1316178276530426e-01
    x[17,8]   old_TS2   -5.4439593337938641e-01
    x[17,8]   old_TS3   -5.4439593337938641e-01
    x[17,8]   old_TS4   -3.1316178276530426e-01
    x[17,9]   OBJ       -1.8685096875000005e-02
    x[17,9]   onehot_17  1
    x[17,9]   w_lb_17_9  -3.9145222845663033e-02
    x[17,9]   w_ub_17_9  -0.0680494916724233
    x[17,9]   hard_lower  9
    x[17,9]   hard_upper  9
    x[17,9]   old_TS1   -3.5230700561096728e-01
    x[17,9]   old_TS2   -6.1244542505180966e-01
    x[17,9]   old_TS3   -6.1244542505180966e-01
    x[17,9]   old_TS4   -3.5230700561096728e-01
    x[17,10]  OBJ       -1.4532853125000002e-02
    x[17,10]  onehot_17  1
    x[17,10]  w_lb_17_10  -3.9145222845663033e-02
    x[17,10]  w_ub_17_10  -0.0680494916724233
    x[17,10]  hard_lower  10
    x[17,10]  hard_upper  10
    x[17,10]  old_TS1   -3.9145222845663030e-01
    x[17,10]  old_TS2   -0.680494916724233
    x[17,10]  old_TS3   -0.680494916724233
    x[17,10]  old_TS4   -3.9145222845663030e-01
    x[17,11]  OBJ       -1.0380609375000002e-02
    x[17,11]  onehot_17  1
    x[17,11]  w_lb_17_11  -3.9145222845663033e-02
    x[17,11]  w_ub_17_11  -0.0680494916724233
    x[17,11]  hard_lower  11
    x[17,11]  hard_upper  11
    x[17,11]  old_TS1   -4.3059745130229338e-01
    x[17,11]  old_TS2   -7.4854440839665637e-01
    x[17,11]  old_TS3   -7.4854440839665637e-01
    x[17,11]  old_TS4   -4.3059745130229338e-01
    x[17,12]  OBJ       -6.2283656250000010e-03
    x[17,12]  onehot_17  1
    x[17,12]  w_lb_17_12  -3.9145222845663033e-02
    x[17,12]  w_ub_17_12  -0.0680494916724233
    x[17,12]  hard_lower  12
    x[17,12]  hard_upper  12
    x[17,12]  old_TS1   -4.6974267414795640e-01
    x[17,12]  old_TS2   -8.1659390006907961e-01
    x[17,12]  old_TS3   -8.1659390006907961e-01
    x[17,12]  old_TS4   -4.6974267414795640e-01
    x[17,13]  OBJ       -0.002076121875
    x[17,13]  onehot_17  1
    x[17,13]  w_lb_17_13  -3.9145222845663033e-02
    x[17,13]  w_ub_17_13  -0.0680494916724233
    x[17,13]  hard_lower  13
    x[17,13]  hard_upper  13
    x[17,13]  old_TS1   -5.0888789699361947e-01
    x[17,13]  old_TS2   -8.8464339174150286e-01
    x[17,13]  old_TS3   -8.8464339174150286e-01
    x[17,13]  old_TS4   -5.0888789699361947e-01
    x[17,14]  OBJ       0.002076121875
    x[17,14]  onehot_17  1
    x[17,14]  w_lb_17_14  -3.9145222845663033e-02
    x[17,14]  w_ub_17_14  -0.0680494916724233
    x[17,14]  hard_lower  14
    x[17,14]  hard_upper  14
    x[17,14]  old_TS1   -5.4803311983928249e-01
    x[17,14]  old_TS2   -9.5269288341392622e-01
    x[17,14]  old_TS3   -9.5269288341392622e-01
    x[17,14]  old_TS4   -5.4803311983928249e-01
    x[17,15]  OBJ       0.006228365625
    x[17,15]  onehot_17  1
    x[17,15]  w_lb_17_15  -3.9145222845663033e-02
    x[17,15]  w_ub_17_15  -0.0680494916724233
    x[17,15]  hard_lower  15
    x[17,15]  hard_upper  15
    x[17,15]  old_TS1   -5.8717834268494551e-01
    x[17,15]  old_TS2   -1.0207423750863496e+00
    x[17,15]  old_TS3   -1.0207423750863496e+00
    x[17,15]  old_TS4   -5.8717834268494551e-01
    x[17,16]  OBJ       0.010380609375
    x[17,16]  onehot_17  1
    x[17,16]  w_lb_17_16  -3.9145222845663033e-02
    x[17,16]  w_ub_17_16  -0.0680494916724233
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[17,16]  old_TS1   -6.2632356553060853e-01
    x[17,16]  old_TS2   -1.0887918667587728e+00
    x[17,16]  old_TS3   -1.0887918667587728e+00
    x[17,16]  old_TS4   -6.2632356553060853e-01
    x[17,17]  OBJ       0.014532853125
    x[17,17]  onehot_17  1
    x[17,17]  w_lb_17_17  -3.9145222845663033e-02
    x[17,17]  w_ub_17_17  -0.0680494916724233
    x[17,17]  hard_lower  17
    x[17,17]  hard_upper  17
    x[17,17]  old_TS1   -6.6546878837627155e-01
    x[17,17]  old_TS2   -1.1568413584311961e+00
    x[17,17]  old_TS3   -1.1568413584311961e+00
    x[17,17]  old_TS4   -6.6546878837627155e-01
    x[17,18]  OBJ       0.018685096875
    x[17,18]  onehot_17  1
    x[17,18]  w_lb_17_18  -3.9145222845663033e-02
    x[17,18]  w_ub_17_18  -0.0680494916724233
    x[17,18]  hard_lower  18
    x[17,18]  hard_upper  18
    x[17,18]  old_TS1   -7.0461401122193457e-01
    x[17,18]  old_TS2   -1.2248908501036193e+00
    x[17,18]  old_TS3   -1.2248908501036193e+00
    x[17,18]  old_TS4   -7.0461401122193457e-01
    x[17,19]  OBJ       0.022837340625
    x[17,19]  onehot_17  1
    x[17,19]  w_lb_17_19  -3.9145222845663033e-02
    x[17,19]  w_ub_17_19  -0.0680494916724233
    x[17,19]  hard_lower  19
    x[17,19]  hard_upper  19
    x[17,19]  old_TS1   -7.4375923406759759e-01
    x[17,19]  old_TS2   -1.2929403417760428e+00
    x[17,19]  old_TS3   -1.2929403417760428e+00
    x[17,19]  old_TS4   -7.4375923406759759e-01
    x[18,0]   OBJ       3.1401374999999988e-02
    x[18,0]   onehot_18  1
    x[18,0]   w_lb_18_0  -3.9145222845663033e-02
    x[18,0]   w_ub_18_0  -0.0680494916724233
    x[18,1]   OBJ       2.5692034090909081e-02
    x[18,1]   onehot_18  1
    x[18,1]   w_lb_18_1  -3.9145222845663033e-02
    x[18,1]   w_ub_18_1  -0.0680494916724233
    x[18,1]   hard_lower  1
    x[18,1]   hard_upper  1
    x[18,1]   old_TS1   -3.9145222845663033e-02
    x[18,1]   old_TS2   -0.0680494916724233
    x[18,1]   old_TS3   -0.0680494916724233
    x[18,1]   old_TS4   -3.9145222845663033e-02
    x[18,2]   OBJ       1.9982693181818174e-02
    x[18,2]   onehot_18  1
    x[18,2]   w_lb_18_2  -3.9145222845663033e-02
    x[18,2]   w_ub_18_2  -0.0680494916724233
    x[18,2]   hard_lower  2
    x[18,2]   hard_upper  2
    x[18,2]   old_TS1   -7.8290445691326066e-02
    x[18,2]   old_TS2   -1.3609898334484660e-01
    x[18,2]   old_TS3   -1.3609898334484660e-01
    x[18,2]   old_TS4   -7.8290445691326066e-02
    x[18,3]   OBJ       1.4273352272727267e-02
    x[18,3]   onehot_18  1
    x[18,3]   w_lb_18_3  -3.9145222845663033e-02
    x[18,3]   w_ub_18_3  -0.0680494916724233
    x[18,3]   hard_lower  3
    x[18,3]   hard_upper  3
    x[18,3]   old_TS1   -1.1743566853698910e-01
    x[18,3]   old_TS2   -2.0414847501726990e-01
    x[18,3]   old_TS3   -2.0414847501726990e-01
    x[18,3]   old_TS4   -1.1743566853698910e-01
    x[18,4]   OBJ       8.5640113636363587e-03
    x[18,4]   onehot_18  1
    x[18,4]   w_lb_18_4  -3.9145222845663033e-02
    x[18,4]   w_ub_18_4  -0.0680494916724233
    x[18,4]   hard_lower  4
    x[18,4]   hard_upper  4
    x[18,4]   old_TS1   -1.5658089138265213e-01
    x[18,4]   old_TS2   -2.7219796668969320e-01
    x[18,4]   old_TS3   -2.7219796668969320e-01
    x[18,4]   old_TS4   -1.5658089138265213e-01
    x[18,5]   OBJ       2.8546704545454504e-03
    x[18,5]   onehot_18  1
    x[18,5]   w_lb_18_5  -3.9145222845663033e-02
    x[18,5]   w_ub_18_5  -0.0680494916724233
    x[18,5]   hard_lower  5
    x[18,5]   hard_upper  5
    x[18,5]   old_TS1   -1.9572611422831515e-01
    x[18,5]   old_TS2   -3.4024745836211651e-01
    x[18,5]   old_TS3   -3.4024745836211651e-01
    x[18,5]   old_TS4   -1.9572611422831515e-01
    x[18,6]   OBJ       -2.8546704545454578e-03
    x[18,6]   onehot_18  1
    x[18,6]   w_lb_18_6  -3.9145222845663033e-02
    x[18,6]   w_ub_18_6  -0.0680494916724233
    x[18,6]   hard_lower  6
    x[18,6]   hard_upper  6
    x[18,6]   old_TS1   -2.3487133707397820e-01
    x[18,6]   old_TS2   -4.0829695003453981e-01
    x[18,6]   old_TS3   -4.0829695003453981e-01
    x[18,6]   old_TS4   -2.3487133707397820e-01
    x[18,7]   OBJ       -8.5640113636363674e-03
    x[18,7]   onehot_18  1
    x[18,7]   w_lb_18_7  -3.9145222845663033e-02
    x[18,7]   w_ub_18_7  -0.0680494916724233
    x[18,7]   hard_lower  7
    x[18,7]   hard_upper  7
    x[18,7]   old_TS1   -2.7401655991964124e-01
    x[18,7]   old_TS2   -4.7634644170696311e-01
    x[18,7]   old_TS3   -4.7634644170696311e-01
    x[18,7]   old_TS4   -2.7401655991964124e-01
    x[18,8]   OBJ       -1.4273352272727276e-02
    x[18,8]   onehot_18  1
    x[18,8]   w_lb_18_8  -3.9145222845663033e-02
    x[18,8]   w_ub_18_8  -0.0680494916724233
    x[18,8]   hard_lower  8
    x[18,8]   hard_upper  8
    x[18,8]   old_TS1   -3.1316178276530426e-01
    x[18,8]   old_TS2   -5.4439593337938641e-01
    x[18,8]   old_TS3   -5.4439593337938641e-01
    x[18,8]   old_TS4   -3.1316178276530426e-01
    x[18,9]   OBJ       -1.9982693181818185e-02
    x[18,9]   onehot_18  1
    x[18,9]   w_lb_18_9  -3.9145222845663033e-02
    x[18,9]   w_ub_18_9  -0.0680494916724233
    x[18,9]   hard_lower  9
    x[18,9]   hard_upper  9
    x[18,9]   old_TS1   -3.5230700561096728e-01
    x[18,9]   old_TS2   -6.1244542505180966e-01
    x[18,9]   old_TS3   -6.1244542505180966e-01
    x[18,9]   old_TS4   -3.5230700561096728e-01
    x[18,10]  OBJ       -2.5692034090909092e-02
    x[18,10]  onehot_18  1
    x[18,10]  w_lb_18_10  -3.9145222845663033e-02
    x[18,10]  w_ub_18_10  -0.0680494916724233
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,10]  old_TS1   -3.9145222845663030e-01
    x[18,10]  old_TS2   -0.680494916724233
    x[18,10]  old_TS3   -0.680494916724233
    x[18,10]  old_TS4   -3.9145222845663030e-01
    x[18,11]  OBJ       -0.031401375
    x[18,11]  onehot_18  1
    x[18,11]  w_lb_18_11  -3.9145222845663033e-02
    x[18,11]  w_ub_18_11  -0.0680494916724233
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,11]  old_TS1   -4.3059745130229338e-01
    x[18,11]  old_TS2   -7.4854440839665637e-01
    x[18,11]  old_TS3   -7.4854440839665637e-01
    x[18,11]  old_TS4   -4.3059745130229338e-01
    x[18,12]  OBJ       -2.5692034090909088e-02
    x[18,12]  onehot_18  1
    x[18,12]  w_lb_18_12  -3.9145222845663033e-02
    x[18,12]  w_ub_18_12  -0.0680494916724233
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,12]  old_TS1   -4.6974267414795640e-01
    x[18,12]  old_TS2   -8.1659390006907961e-01
    x[18,12]  old_TS3   -8.1659390006907961e-01
    x[18,12]  old_TS4   -4.6974267414795640e-01
    x[18,13]  OBJ       -1.9982693181818181e-02
    x[18,13]  onehot_18  1
    x[18,13]  w_lb_18_13  -3.9145222845663033e-02
    x[18,13]  w_ub_18_13  -0.0680494916724233
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,13]  old_TS1   -5.0888789699361947e-01
    x[18,13]  old_TS2   -8.8464339174150286e-01
    x[18,13]  old_TS3   -8.8464339174150286e-01
    x[18,13]  old_TS4   -5.0888789699361947e-01
    x[18,14]  OBJ       -1.4273352272727273e-02
    x[18,14]  onehot_18  1
    x[18,14]  w_lb_18_14  -3.9145222845663033e-02
    x[18,14]  w_ub_18_14  -0.0680494916724233
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,14]  old_TS1   -5.4803311983928249e-01
    x[18,14]  old_TS2   -9.5269288341392622e-01
    x[18,14]  old_TS3   -9.5269288341392622e-01
    x[18,14]  old_TS4   -5.4803311983928249e-01
    x[18,15]  OBJ       -8.5640113636363639e-03
    x[18,15]  onehot_18  1
    x[18,15]  w_lb_18_15  -3.9145222845663033e-02
    x[18,15]  w_ub_18_15  -0.0680494916724233
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[18,15]  old_TS1   -5.8717834268494551e-01
    x[18,15]  old_TS2   -1.0207423750863496e+00
    x[18,15]  old_TS3   -1.0207423750863496e+00
    x[18,15]  old_TS4   -5.8717834268494551e-01
    x[18,16]  OBJ       -2.8546704545454544e-03
    x[18,16]  onehot_18  1
    x[18,16]  w_lb_18_16  -3.9145222845663033e-02
    x[18,16]  w_ub_18_16  -0.0680494916724233
    x[18,16]  hard_lower  16
    x[18,16]  hard_upper  16
    x[18,16]  old_TS1   -6.2632356553060853e-01
    x[18,16]  old_TS2   -1.0887918667587728e+00
    x[18,16]  old_TS3   -1.0887918667587728e+00
    x[18,16]  old_TS4   -6.2632356553060853e-01
    x[18,17]  OBJ       2.8546704545454539e-03
    x[18,17]  onehot_18  1
    x[18,17]  w_lb_18_17  -3.9145222845663033e-02
    x[18,17]  w_ub_18_17  -0.0680494916724233
    x[18,17]  hard_lower  17
    x[18,17]  hard_upper  17
    x[18,17]  old_TS1   -6.6546878837627155e-01
    x[18,17]  old_TS2   -1.1568413584311961e+00
    x[18,17]  old_TS3   -1.1568413584311961e+00
    x[18,17]  old_TS4   -6.6546878837627155e-01
    x[18,18]  OBJ       8.5640113636363622e-03
    x[18,18]  onehot_18  1
    x[18,18]  w_lb_18_18  -3.9145222845663033e-02
    x[18,18]  w_ub_18_18  -0.0680494916724233
    x[18,18]  hard_lower  18
    x[18,18]  hard_upper  18
    x[18,18]  old_TS1   -7.0461401122193457e-01
    x[18,18]  old_TS2   -1.2248908501036193e+00
    x[18,18]  old_TS3   -1.2248908501036193e+00
    x[18,18]  old_TS4   -7.0461401122193457e-01
    x[18,19]  OBJ       1.4273352272727271e-02
    x[18,19]  onehot_18  1
    x[18,19]  w_lb_18_19  -3.9145222845663033e-02
    x[18,19]  w_ub_18_19  -0.0680494916724233
    x[18,19]  hard_lower  19
    x[18,19]  hard_upper  19
    x[18,19]  old_TS1   -7.4375923406759759e-01
    x[18,19]  old_TS2   -1.2929403417760428e+00
    x[18,19]  old_TS3   -1.2929403417760428e+00
    x[18,19]  old_TS4   -7.4375923406759759e-01
    x[18,20]  OBJ       1.9982693181818178e-02
    x[18,20]  onehot_18  1
    x[18,20]  w_lb_18_20  -3.9145222845663033e-02
    x[18,20]  w_ub_18_20  -0.0680494916724233
    x[18,20]  hard_lower  20
    x[18,20]  hard_upper  20
    x[18,20]  old_TS1   -7.8290445691326060e-01
    x[18,20]  old_TS2   -1.3609898334484660e+00
    x[18,20]  old_TS3   -1.3609898334484660e+00
    x[18,20]  old_TS4   -7.8290445691326060e-01
    x[18,21]  OBJ       2.5692034090909085e-02
    x[18,21]  onehot_18  1
    x[18,21]  w_lb_18_21  -3.9145222845663033e-02
    x[18,21]  w_ub_18_21  -0.0680494916724233
    x[18,21]  hard_lower  21
    x[18,21]  hard_upper  21
    x[18,21]  old_TS1   -8.2204967975892373e-01
    x[18,21]  old_TS2   -1.4290393251208893e+00
    x[18,21]  old_TS3   -1.4290393251208893e+00
    x[18,21]  old_TS4   -8.2204967975892373e-01
    x[18,22]  OBJ       3.1401374999999995e-02
    x[18,22]  onehot_18  1
    x[18,22]  w_lb_18_22  -3.9145222845663033e-02
    x[18,22]  w_ub_18_22  -0.0680494916724233
    x[18,22]  hard_lower  22
    x[18,22]  hard_upper  22
    x[18,22]  old_TS1   -8.6119490260458675e-01
    x[18,22]  old_TS2   -1.4970888167933127e+00
    x[18,22]  old_TS3   -1.4970888167933127e+00
    x[18,22]  old_TS4   -8.6119490260458675e-01
    x[19,0]   OBJ       3.7370249999999994e-02
    x[19,0]   onehot_19  1
    x[19,0]   w_lb_19_0  -3.9145222845663033e-02
    x[19,0]   w_ub_19_0  -0.0680494916724233
    x[19,1]   OBJ       3.1141874999999996e-02
    x[19,1]   onehot_19  1
    x[19,1]   w_lb_19_1  -3.9145222845663033e-02
    x[19,1]   w_ub_19_1  -0.0680494916724233
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,1]   old_TS1   -3.9145222845663033e-02
    x[19,1]   old_TS2   -0.0680494916724233
    x[19,1]   old_TS3   -0.0680494916724233
    x[19,1]   old_TS4   -3.9145222845663033e-02
    x[19,2]   OBJ       2.4913499999999998e-02
    x[19,2]   onehot_19  1
    x[19,2]   w_lb_19_2  -3.9145222845663033e-02
    x[19,2]   w_ub_19_2  -0.0680494916724233
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,2]   old_TS1   -7.8290445691326066e-02
    x[19,2]   old_TS2   -1.3609898334484660e-01
    x[19,2]   old_TS3   -1.3609898334484660e-01
    x[19,2]   old_TS4   -7.8290445691326066e-02
    x[19,3]   OBJ       1.8685124999999997e-02
    x[19,3]   onehot_19  1
    x[19,3]   w_lb_19_3  -3.9145222845663033e-02
    x[19,3]   w_ub_19_3  -0.0680494916724233
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,3]   old_TS1   -1.1743566853698910e-01
    x[19,3]   old_TS2   -2.0414847501726990e-01
    x[19,3]   old_TS3   -2.0414847501726990e-01
    x[19,3]   old_TS4   -1.1743566853698910e-01
    x[19,4]   OBJ       1.2456749999999999e-02
    x[19,4]   onehot_19  1
    x[19,4]   w_lb_19_4  -3.9145222845663033e-02
    x[19,4]   w_ub_19_4  -0.0680494916724233
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,4]   old_TS1   -1.5658089138265213e-01
    x[19,4]   old_TS2   -2.7219796668969320e-01
    x[19,4]   old_TS3   -2.7219796668969320e-01
    x[19,4]   old_TS4   -1.5658089138265213e-01
    x[19,5]   OBJ       6.2283749999999995e-03
    x[19,5]   onehot_19  1
    x[19,5]   w_lb_19_5  -3.9145222845663033e-02
    x[19,5]   w_ub_19_5  -0.0680494916724233
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,5]   old_TS1   -1.9572611422831515e-01
    x[19,5]   old_TS2   -3.4024745836211651e-01
    x[19,5]   old_TS3   -3.4024745836211651e-01
    x[19,5]   old_TS4   -1.9572611422831515e-01
    x[19,6]   onehot_19  1
    x[19,6]   w_lb_19_6  -3.9145222845663033e-02
    x[19,6]   w_ub_19_6  -0.0680494916724233
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,6]   old_TS1   -2.3487133707397820e-01
    x[19,6]   old_TS2   -4.0829695003453981e-01
    x[19,6]   old_TS3   -4.0829695003453981e-01
    x[19,6]   old_TS4   -2.3487133707397820e-01
    x[19,7]   OBJ       -0.006228375
    x[19,7]   onehot_19  1
    x[19,7]   w_lb_19_7  -3.9145222845663033e-02
    x[19,7]   w_ub_19_7  -0.0680494916724233
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,7]   old_TS1   -2.7401655991964124e-01
    x[19,7]   old_TS2   -4.7634644170696311e-01
    x[19,7]   old_TS3   -4.7634644170696311e-01
    x[19,7]   old_TS4   -2.7401655991964124e-01
    x[19,8]   OBJ       -0.01245675
    x[19,8]   onehot_19  1
    x[19,8]   w_lb_19_8  -3.9145222845663033e-02
    x[19,8]   w_ub_19_8  -0.0680494916724233
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[19,8]   old_TS1   -3.1316178276530426e-01
    x[19,8]   old_TS2   -5.4439593337938641e-01
    x[19,8]   old_TS3   -5.4439593337938641e-01
    x[19,8]   old_TS4   -3.1316178276530426e-01
    x[19,9]   OBJ       -0.018685125
    x[19,9]   onehot_19  1
    x[19,9]   w_lb_19_9  -3.9145222845663033e-02
    x[19,9]   w_ub_19_9  -0.0680494916724233
    x[19,9]   hard_lower  9
    x[19,9]   hard_upper  9
    x[19,9]   old_TS1   -3.5230700561096728e-01
    x[19,9]   old_TS2   -6.1244542505180966e-01
    x[19,9]   old_TS3   -6.1244542505180966e-01
    x[19,9]   old_TS4   -3.5230700561096728e-01
    x[19,10]  OBJ       -0.0249135
    x[19,10]  onehot_19  1
    x[19,10]  w_lb_19_10  -3.9145222845663033e-02
    x[19,10]  w_ub_19_10  -0.0680494916724233
    x[19,10]  hard_lower  10
    x[19,10]  hard_upper  10
    x[19,10]  old_TS1   -3.9145222845663030e-01
    x[19,10]  old_TS2   -0.680494916724233
    x[19,10]  old_TS3   -0.680494916724233
    x[19,10]  old_TS4   -3.9145222845663030e-01
    x[19,11]  OBJ       -0.031141875
    x[19,11]  onehot_19  1
    x[19,11]  w_lb_19_11  -3.9145222845663033e-02
    x[19,11]  w_ub_19_11  -0.0680494916724233
    x[19,11]  hard_lower  11
    x[19,11]  hard_upper  11
    x[19,11]  old_TS1   -4.3059745130229338e-01
    x[19,11]  old_TS2   -7.4854440839665637e-01
    x[19,11]  old_TS3   -7.4854440839665637e-01
    x[19,11]  old_TS4   -4.3059745130229338e-01
    x[19,12]  OBJ       -0.03737025
    x[19,12]  onehot_19  1
    x[19,12]  w_lb_19_12  -3.9145222845663033e-02
    x[19,12]  w_ub_19_12  -0.0680494916724233
    x[19,12]  hard_lower  12
    x[19,12]  hard_upper  12
    x[19,12]  old_TS1   -4.6974267414795640e-01
    x[19,12]  old_TS2   -8.1659390006907961e-01
    x[19,12]  old_TS3   -8.1659390006907961e-01
    x[19,12]  old_TS4   -4.6974267414795640e-01
    x[19,13]  OBJ       -3.1141875000000010e-02
    x[19,13]  onehot_19  1
    x[19,13]  w_lb_19_13  -3.9145222845663033e-02
    x[19,13]  w_ub_19_13  -0.0680494916724233
    x[19,13]  hard_lower  13
    x[19,13]  hard_upper  13
    x[19,13]  old_TS1   -5.0888789699361947e-01
    x[19,13]  old_TS2   -8.8464339174150286e-01
    x[19,13]  old_TS3   -8.8464339174150286e-01
    x[19,13]  old_TS4   -5.0888789699361947e-01
    x[19,14]  OBJ       -2.4913500000000009e-02
    x[19,14]  onehot_19  1
    x[19,14]  w_lb_19_14  -3.9145222845663033e-02
    x[19,14]  w_ub_19_14  -0.0680494916724233
    x[19,14]  hard_lower  14
    x[19,14]  hard_upper  14
    x[19,14]  old_TS1   -5.4803311983928249e-01
    x[19,14]  old_TS2   -9.5269288341392622e-01
    x[19,14]  old_TS3   -9.5269288341392622e-01
    x[19,14]  old_TS4   -5.4803311983928249e-01
    x[19,15]  OBJ       -1.8685125000000011e-02
    x[19,15]  onehot_19  1
    x[19,15]  w_lb_19_15  -3.9145222845663033e-02
    x[19,15]  w_ub_19_15  -0.0680494916724233
    x[19,15]  hard_lower  15
    x[19,15]  hard_upper  15
    x[19,15]  old_TS1   -5.8717834268494551e-01
    x[19,15]  old_TS2   -1.0207423750863496e+00
    x[19,15]  old_TS3   -1.0207423750863496e+00
    x[19,15]  old_TS4   -5.8717834268494551e-01
    x[19,16]  OBJ       -1.2456750000000009e-02
    x[19,16]  onehot_19  1
    x[19,16]  w_lb_19_16  -3.9145222845663033e-02
    x[19,16]  w_ub_19_16  -0.0680494916724233
    x[19,16]  hard_lower  16
    x[19,16]  hard_upper  16
    x[19,16]  old_TS1   -6.2632356553060853e-01
    x[19,16]  old_TS2   -1.0887918667587728e+00
    x[19,16]  old_TS3   -1.0887918667587728e+00
    x[19,16]  old_TS4   -6.2632356553060853e-01
    x[19,17]  OBJ       -6.2283750000000082e-03
    x[19,17]  onehot_19  1
    x[19,17]  w_lb_19_17  -3.9145222845663033e-02
    x[19,17]  w_ub_19_17  -0.0680494916724233
    x[19,17]  hard_lower  17
    x[19,17]  hard_upper  17
    x[19,17]  old_TS1   -6.6546878837627155e-01
    x[19,17]  old_TS2   -1.1568413584311961e+00
    x[19,17]  old_TS3   -1.1568413584311961e+00
    x[19,17]  old_TS4   -6.6546878837627155e-01
    x[19,18]  OBJ       -8.2978623971996514e-18
    x[19,18]  onehot_19  1
    x[19,18]  w_lb_19_18  -3.9145222845663033e-02
    x[19,18]  w_ub_19_18  -0.0680494916724233
    x[19,18]  hard_lower  18
    x[19,18]  hard_upper  18
    x[19,18]  old_TS1   -7.0461401122193457e-01
    x[19,18]  old_TS2   -1.2248908501036193e+00
    x[19,18]  old_TS3   -1.2248908501036193e+00
    x[19,18]  old_TS4   -7.0461401122193457e-01
    x[19,19]  OBJ       6.2283749999999909e-03
    x[19,19]  onehot_19  1
    x[19,19]  w_lb_19_19  -3.9145222845663033e-02
    x[19,19]  w_ub_19_19  -0.0680494916724233
    x[19,19]  hard_lower  19
    x[19,19]  hard_upper  19
    x[19,19]  old_TS1   -7.4375923406759759e-01
    x[19,19]  old_TS2   -1.2929403417760428e+00
    x[19,19]  old_TS3   -1.2929403417760428e+00
    x[19,19]  old_TS4   -7.4375923406759759e-01
    x[19,20]  OBJ       1.2456749999999990e-02
    x[19,20]  onehot_19  1
    x[19,20]  w_lb_19_20  -3.9145222845663033e-02
    x[19,20]  w_ub_19_20  -0.0680494916724233
    x[19,20]  hard_lower  20
    x[19,20]  hard_upper  20
    x[19,20]  old_TS1   -7.8290445691326060e-01
    x[19,20]  old_TS2   -1.3609898334484660e+00
    x[19,20]  old_TS3   -1.3609898334484660e+00
    x[19,20]  old_TS4   -7.8290445691326060e-01
    x[19,21]  OBJ       1.8685124999999990e-02
    x[19,21]  onehot_19  1
    x[19,21]  w_lb_19_21  -3.9145222845663033e-02
    x[19,21]  w_ub_19_21  -0.0680494916724233
    x[19,21]  hard_lower  21
    x[19,21]  hard_upper  21
    x[19,21]  old_TS1   -8.2204967975892373e-01
    x[19,21]  old_TS2   -1.4290393251208893e+00
    x[19,21]  old_TS3   -1.4290393251208893e+00
    x[19,21]  old_TS4   -8.2204967975892373e-01
    x[19,22]  OBJ       2.4913499999999988e-02
    x[19,22]  onehot_19  1
    x[19,22]  w_lb_19_22  -3.9145222845663033e-02
    x[19,22]  w_ub_19_22  -0.0680494916724233
    x[19,22]  hard_lower  22
    x[19,22]  hard_upper  22
    x[19,22]  old_TS1   -8.6119490260458675e-01
    x[19,22]  old_TS2   -1.4970888167933127e+00
    x[19,22]  old_TS3   -1.4970888167933127e+00
    x[19,22]  old_TS4   -8.6119490260458675e-01
    x[19,23]  OBJ       3.1141874999999989e-02
    x[19,23]  onehot_19  1
    x[19,23]  w_lb_19_23  -3.9145222845663033e-02
    x[19,23]  w_ub_19_23  -0.0680494916724233
    x[19,23]  hard_lower  23
    x[19,23]  hard_upper  23
    x[19,23]  old_TS1   -9.0034012545024977e-01
    x[19,23]  old_TS2   -1.5651383084657360e+00
    x[19,23]  old_TS3   -1.5651383084657360e+00
    x[19,23]  old_TS4   -9.0034012545024977e-01
    x[20,0]   OBJ       0.043858125
    x[20,0]   onehot_20  1
    x[20,0]   w_lb_20_0  -3.9145222845663033e-02
    x[20,0]   w_ub_20_0  -0.0680494916724233
    x[20,1]   OBJ       3.7110721153846150e-02
    x[20,1]   onehot_20  1
    x[20,1]   w_lb_20_1  -3.9145222845663033e-02
    x[20,1]   w_ub_20_1  -0.0680494916724233
    x[20,1]   hard_lower  1
    x[20,1]   hard_upper  1
    x[20,1]   old_TS1   -3.9145222845663033e-02
    x[20,1]   old_TS2   -0.0680494916724233
    x[20,1]   old_TS3   -0.0680494916724233
    x[20,1]   old_TS4   -3.9145222845663033e-02
    x[20,2]   OBJ       3.0363317307692306e-02
    x[20,2]   onehot_20  1
    x[20,2]   w_lb_20_2  -3.9145222845663033e-02
    x[20,2]   w_ub_20_2  -0.0680494916724233
    x[20,2]   hard_lower  2
    x[20,2]   hard_upper  2
    x[20,2]   old_TS1   -7.8290445691326066e-02
    x[20,2]   old_TS2   -1.3609898334484660e-01
    x[20,2]   old_TS3   -1.3609898334484660e-01
    x[20,2]   old_TS4   -7.8290445691326066e-02
    x[20,3]   OBJ       2.3615913461538459e-02
    x[20,3]   onehot_20  1
    x[20,3]   w_lb_20_3  -3.9145222845663033e-02
    x[20,3]   w_ub_20_3  -0.0680494916724233
    x[20,3]   hard_lower  3
    x[20,3]   hard_upper  3
    x[20,3]   old_TS1   -1.1743566853698910e-01
    x[20,3]   old_TS2   -2.0414847501726990e-01
    x[20,3]   old_TS3   -2.0414847501726990e-01
    x[20,3]   old_TS4   -1.1743566853698910e-01
    x[20,4]   OBJ       1.6868509615384612e-02
    x[20,4]   onehot_20  1
    x[20,4]   w_lb_20_4  -3.9145222845663033e-02
    x[20,4]   w_ub_20_4  -0.0680494916724233
    x[20,4]   hard_lower  4
    x[20,4]   hard_upper  4
    x[20,4]   old_TS1   -1.5658089138265213e-01
    x[20,4]   old_TS2   -2.7219796668969320e-01
    x[20,4]   old_TS3   -2.7219796668969320e-01
    x[20,4]   old_TS4   -1.5658089138265213e-01
    x[20,5]   OBJ       1.0121105769230766e-02
    x[20,5]   onehot_20  1
    x[20,5]   w_lb_20_5  -3.9145222845663033e-02
    x[20,5]   w_ub_20_5  -0.0680494916724233
    x[20,5]   hard_lower  5
    x[20,5]   hard_upper  5
    x[20,5]   old_TS1   -1.9572611422831515e-01
    x[20,5]   old_TS2   -3.4024745836211651e-01
    x[20,5]   old_TS3   -3.4024745836211651e-01
    x[20,5]   old_TS4   -1.9572611422831515e-01
    x[20,6]   OBJ       3.3737019230769185e-03
    x[20,6]   onehot_20  1
    x[20,6]   w_lb_20_6  -3.9145222845663033e-02
    x[20,6]   w_ub_20_6  -0.0680494916724233
    x[20,6]   hard_lower  6
    x[20,6]   hard_upper  6
    x[20,6]   old_TS1   -2.3487133707397820e-01
    x[20,6]   old_TS2   -4.0829695003453981e-01
    x[20,6]   old_TS3   -4.0829695003453981e-01
    x[20,6]   old_TS4   -2.3487133707397820e-01
    x[20,7]   OBJ       -3.3737019230769289e-03
    x[20,7]   onehot_20  1
    x[20,7]   w_lb_20_7  -3.9145222845663033e-02
    x[20,7]   w_ub_20_7  -0.0680494916724233
    x[20,7]   hard_lower  7
    x[20,7]   hard_upper  7
    x[20,7]   old_TS1   -2.7401655991964124e-01
    x[20,7]   old_TS2   -4.7634644170696311e-01
    x[20,7]   old_TS3   -4.7634644170696311e-01
    x[20,7]   old_TS4   -2.7401655991964124e-01
    x[20,8]   OBJ       -1.0121105769230776e-02
    x[20,8]   onehot_20  1
    x[20,8]   w_lb_20_8  -3.9145222845663033e-02
    x[20,8]   w_ub_20_8  -0.0680494916724233
    x[20,8]   hard_lower  8
    x[20,8]   hard_upper  8
    x[20,8]   old_TS1   -3.1316178276530426e-01
    x[20,8]   old_TS2   -5.4439593337938641e-01
    x[20,8]   old_TS3   -5.4439593337938641e-01
    x[20,8]   old_TS4   -3.1316178276530426e-01
    x[20,9]   OBJ       -1.6868509615384625e-02
    x[20,9]   onehot_20  1
    x[20,9]   w_lb_20_9  -3.9145222845663033e-02
    x[20,9]   w_ub_20_9  -0.0680494916724233
    x[20,9]   hard_lower  9
    x[20,9]   hard_upper  9
    x[20,9]   old_TS1   -3.5230700561096728e-01
    x[20,9]   old_TS2   -6.1244542505180966e-01
    x[20,9]   old_TS3   -6.1244542505180966e-01
    x[20,9]   old_TS4   -3.5230700561096728e-01
    x[20,10]  OBJ       -2.3615913461538473e-02
    x[20,10]  onehot_20  1
    x[20,10]  w_lb_20_10  -3.9145222845663033e-02
    x[20,10]  w_ub_20_10  -0.0680494916724233
    x[20,10]  hard_lower  10
    x[20,10]  hard_upper  10
    x[20,10]  old_TS1   -3.9145222845663030e-01
    x[20,10]  old_TS2   -0.680494916724233
    x[20,10]  old_TS3   -0.680494916724233
    x[20,10]  old_TS4   -3.9145222845663030e-01
    x[20,11]  OBJ       -3.0363317307692320e-02
    x[20,11]  onehot_20  1
    x[20,11]  w_lb_20_11  -3.9145222845663033e-02
    x[20,11]  w_ub_20_11  -0.0680494916724233
    x[20,11]  hard_lower  11
    x[20,11]  hard_upper  11
    x[20,11]  old_TS1   -4.3059745130229338e-01
    x[20,11]  old_TS2   -7.4854440839665637e-01
    x[20,11]  old_TS3   -7.4854440839665637e-01
    x[20,11]  old_TS4   -4.3059745130229338e-01
    x[20,12]  OBJ       -3.7110721153846171e-02
    x[20,12]  onehot_20  1
    x[20,12]  w_lb_20_12  -3.9145222845663033e-02
    x[20,12]  w_ub_20_12  -0.0680494916724233
    x[20,12]  hard_lower  12
    x[20,12]  hard_upper  12
    x[20,12]  old_TS1   -4.6974267414795640e-01
    x[20,12]  old_TS2   -8.1659390006907961e-01
    x[20,12]  old_TS3   -8.1659390006907961e-01
    x[20,12]  old_TS4   -4.6974267414795640e-01
    x[20,13]  OBJ       -4.3858125000000005e-02
    x[20,13]  onehot_20  1
    x[20,13]  w_lb_20_13  -3.9145222845663033e-02
    x[20,13]  w_ub_20_13  -0.0680494916724233
    x[20,13]  hard_lower  13
    x[20,13]  hard_upper  13
    x[20,13]  old_TS1   -5.0888789699361947e-01
    x[20,13]  old_TS2   -8.8464339174150286e-01
    x[20,13]  old_TS3   -8.8464339174150286e-01
    x[20,13]  old_TS4   -5.0888789699361947e-01
    x[20,14]  OBJ       -3.7110721153846157e-02
    x[20,14]  onehot_20  1
    x[20,14]  w_lb_20_14  -3.9145222845663033e-02
    x[20,14]  w_ub_20_14  -0.0680494916724233
    x[20,14]  hard_lower  14
    x[20,14]  hard_upper  14
    x[20,14]  old_TS1   -5.4803311983928249e-01
    x[20,14]  old_TS2   -9.5269288341392622e-01
    x[20,14]  old_TS3   -9.5269288341392622e-01
    x[20,14]  old_TS4   -5.4803311983928249e-01
    x[20,15]  OBJ       -3.0363317307692310e-02
    x[20,15]  onehot_20  1
    x[20,15]  w_lb_20_15  -3.9145222845663033e-02
    x[20,15]  w_ub_20_15  -0.0680494916724233
    x[20,15]  hard_lower  15
    x[20,15]  hard_upper  15
    x[20,15]  old_TS1   -5.8717834268494551e-01
    x[20,15]  old_TS2   -1.0207423750863496e+00
    x[20,15]  old_TS3   -1.0207423750863496e+00
    x[20,15]  old_TS4   -5.8717834268494551e-01
    x[20,16]  OBJ       -2.3615913461538462e-02
    x[20,16]  onehot_20  1
    x[20,16]  w_lb_20_16  -3.9145222845663033e-02
    x[20,16]  w_ub_20_16  -0.0680494916724233
    x[20,16]  hard_lower  16
    x[20,16]  hard_upper  16
    x[20,16]  old_TS1   -6.2632356553060853e-01
    x[20,16]  old_TS2   -1.0887918667587728e+00
    x[20,16]  old_TS3   -1.0887918667587728e+00
    x[20,16]  old_TS4   -6.2632356553060853e-01
    x[20,17]  OBJ       -1.6868509615384615e-02
    x[20,17]  onehot_20  1
    x[20,17]  w_lb_20_17  -3.9145222845663033e-02
    x[20,17]  w_ub_20_17  -0.0680494916724233
    x[20,17]  hard_lower  17
    x[20,17]  hard_upper  17
    x[20,17]  old_TS1   -6.6546878837627155e-01
    x[20,17]  old_TS2   -1.1568413584311961e+00
    x[20,17]  old_TS3   -1.1568413584311961e+00
    x[20,17]  old_TS4   -6.6546878837627155e-01
    x[20,18]  OBJ       -1.0121105769230768e-02
    x[20,18]  onehot_20  1
    x[20,18]  w_lb_20_18  -3.9145222845663033e-02
    x[20,18]  w_ub_20_18  -0.0680494916724233
    x[20,18]  hard_lower  18
    x[20,18]  hard_upper  18
    x[20,18]  old_TS1   -7.0461401122193457e-01
    x[20,18]  old_TS2   -1.2248908501036193e+00
    x[20,18]  old_TS3   -1.2248908501036193e+00
    x[20,18]  old_TS4   -7.0461401122193457e-01
    x[20,19]  OBJ       -3.3737019230769189e-03
    x[20,19]  onehot_20  1
    x[20,19]  w_lb_20_19  -3.9145222845663033e-02
    x[20,19]  w_ub_20_19  -0.0680494916724233
    x[20,19]  hard_lower  19
    x[20,19]  hard_upper  19
    x[20,19]  old_TS1   -7.4375923406759759e-01
    x[20,19]  old_TS2   -1.2929403417760428e+00
    x[20,19]  old_TS3   -1.2929403417760428e+00
    x[20,19]  old_TS4   -7.4375923406759759e-01
    x[20,20]  OBJ       3.3737019230769285e-03
    x[20,20]  onehot_20  1
    x[20,20]  w_lb_20_20  -3.9145222845663033e-02
    x[20,20]  w_ub_20_20  -0.0680494916724233
    x[20,20]  hard_lower  20
    x[20,20]  hard_upper  20
    x[20,20]  old_TS1   -7.8290445691326060e-01
    x[20,20]  old_TS2   -1.3609898334484660e+00
    x[20,20]  old_TS3   -1.3609898334484660e+00
    x[20,20]  old_TS4   -7.8290445691326060e-01
    x[20,21]  OBJ       1.0121105769230775e-02
    x[20,21]  onehot_20  1
    x[20,21]  w_lb_20_21  -3.9145222845663033e-02
    x[20,21]  w_ub_20_21  -0.0680494916724233
    x[20,21]  hard_lower  21
    x[20,21]  hard_upper  21
    x[20,21]  old_TS1   -8.2204967975892373e-01
    x[20,21]  old_TS2   -1.4290393251208893e+00
    x[20,21]  old_TS3   -1.4290393251208893e+00
    x[20,21]  old_TS4   -8.2204967975892373e-01
    x[20,22]  OBJ       1.6868509615384622e-02
    x[20,22]  onehot_20  1
    x[20,22]  w_lb_20_22  -3.9145222845663033e-02
    x[20,22]  w_ub_20_22  -0.0680494916724233
    x[20,22]  hard_lower  22
    x[20,22]  hard_upper  22
    x[20,22]  old_TS1   -8.6119490260458675e-01
    x[20,22]  old_TS2   -1.4970888167933127e+00
    x[20,22]  old_TS3   -1.4970888167933127e+00
    x[20,22]  old_TS4   -8.6119490260458675e-01
    x[20,23]  OBJ       2.3615913461538469e-02
    x[20,23]  onehot_20  1
    x[20,23]  w_lb_20_23  -3.9145222845663033e-02
    x[20,23]  w_ub_20_23  -0.0680494916724233
    x[20,23]  hard_lower  23
    x[20,23]  hard_upper  23
    x[20,23]  old_TS1   -9.0034012545024977e-01
    x[20,23]  old_TS2   -1.5651383084657360e+00
    x[20,23]  old_TS3   -1.5651383084657360e+00
    x[20,23]  old_TS4   -9.0034012545024977e-01
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    w_lb_1_0  1
    w[1,0]    w_ub_1_0  1
    w[1,1]    mass_1    1
    w[1,1]    w_lb_1_1  1
    w[1,1]    w_ub_1_1  1
    w[1,1]    normalized_inventory_1  -1
    w[1,1]    old_normalized_TC2  7.2727272727272729e-01
    w[1,2]    mass_1    1
    w[1,2]    w_lb_1_2  1
    w[1,2]    w_ub_1_2  1
    w[1,2]    normalized_inventory_1  -2
    w[1,2]    old_normalized_TC2  1.4545454545454546e+00
    w[1,3]    mass_1    1
    w[1,3]    w_lb_1_3  1
    w[1,3]    w_ub_1_3  1
    w[1,3]    normalized_inventory_1  -3
    w[1,3]    old_normalized_TC2  2.1090909090909093e+00
    w[1,4]    mass_1    1
    w[1,4]    w_lb_1_4  1
    w[1,4]    w_ub_1_4  1
    w[1,4]    normalized_inventory_1  -4
    w[1,4]    old_normalized_TC2  2.7454545454545456e+00
    w[1,5]    mass_1    1
    w[1,5]    w_lb_1_5  1
    w[1,5]    w_ub_1_5  1
    w[1,5]    normalized_inventory_1  -5
    w[1,5]    old_normalized_TC2  3.2909090909090910e+00
    w[1,6]    mass_1    1
    w[1,6]    w_lb_1_6  1
    w[1,6]    w_ub_1_6  1
    w[1,6]    normalized_inventory_1  -6
    w[1,6]    old_normalized_TC2  3.7524475524475527e+00
    w[1,7]    mass_1    1
    w[1,7]    w_lb_1_7  1
    w[1,7]    w_ub_1_7  1
    w[1,7]    normalized_inventory_1  -7
    w[1,7]    old_normalized_TC2  4.1539627039627041e+00
    w[1,8]    mass_1    1
    w[1,8]    w_lb_1_8  1
    w[1,8]    w_ub_1_8  1
    w[1,8]    normalized_inventory_1  -8
    w[1,8]    old_normalized_TC2  4.4569930069930077e+00
    w[1,9]    mass_1    1
    w[1,9]    w_lb_1_9  1
    w[1,9]    w_ub_1_9  1
    w[1,9]    normalized_inventory_1  -9
    w[1,9]    old_normalized_TC2  4.6807692307692310e+00
    w[1,10]   mass_1    1
    w[1,10]   w_lb_1_10  1
    w[1,10]   w_ub_1_10  1
    w[1,10]   normalized_inventory_1  -10
    w[1,10]   old_normalized_TC2  4.7868298368298374e+00
    w[1,11]   mass_1    1
    w[1,11]   w_lb_1_11  1
    w[1,11]   w_ub_1_11  1
    w[1,11]   normalized_inventory_1  -11
    w[1,11]   old_normalized_TC2  4.7868298368298374e+00
    w[1,12]   mass_1    1
    w[1,12]   w_lb_1_12  1
    w[1,12]   w_ub_1_12  1
    w[1,12]   normalized_inventory_1  -12
    w[1,12]   old_normalized_TC  -7.5757575757576662e-03
    w[1,12]   old_normalized_TC2  4.77925407925408
    w[1,13]   mass_1    1
    w[1,13]   w_lb_1_13  1
    w[1,13]   w_ub_1_13  1
    w[1,13]   normalized_inventory_1  -13
    w[1,13]   old_normalized_TC  -1.1363636363636383e-01
    w[1,13]   old_normalized_TC2  4.6731934731934732e+00
    w[1,14]   mass_1    1
    w[1,14]   w_lb_1_14  1
    w[1,14]   w_ub_1_14  1
    w[1,14]   normalized_inventory_1  -14
    w[1,14]   old_normalized_TC  -3.0151515151515174e-01
    w[1,14]   old_normalized_TC2  4.4853146853146857e+00
    w[1,15]   mass_1    1
    w[1,15]   w_lb_1_15  1
    w[1,15]   w_ub_1_15  1
    w[1,15]   normalized_inventory_1  -15
    w[1,15]   old_normalized_TC  -5.7424242424242444e-01
    w[1,15]   old_normalized_TC2  4.2125874125874132e+00
    w[1,16]   mass_1    1
    w[1,16]   w_lb_1_16  1
    w[1,16]   w_ub_1_16  1
    w[1,16]   normalized_inventory_1  -16
    w[1,16]   old_normalized_TC  -9.3787878787878809e-01
    w[1,16]   old_normalized_TC2  3.8489510489510490e+00
    w[1,17]   mass_1    1
    w[1,17]   w_lb_1_17  1
    w[1,17]   w_ub_1_17  1
    w[1,17]   normalized_inventory_1  -17
    w[1,17]   old_normalized_TC  -1.3924242424242426e+00
    w[1,17]   old_normalized_TC2  3.3944055944055944e+00
    w[1,18]   mass_1    1
    w[1,18]   w_lb_1_18  1
    w[1,18]   w_ub_1_18  1
    w[1,18]   normalized_inventory_1  -18
    w[1,18]   old_normalized_TC  -1.8833333333333335e+00
    w[1,18]   old_normalized_TC2  2.9034965034965037e+00
    w[1,19]   mass_1    1
    w[1,19]   w_lb_1_19  1
    w[1,19]   w_ub_1_19  1
    w[1,19]   normalized_inventory_1  -19
    w[1,19]   old_normalized_TC  -2.4287878787878787e+00
    w[1,19]   old_normalized_TC2  2.3580419580419578e+00
    w[1,20]   mass_1    1
    w[1,20]   w_lb_1_20  1
    w[1,20]   w_ub_1_20  1
    w[1,20]   normalized_inventory_1  -20
    w[1,20]   old_normalized_TC  -3.0651515151515154e+00
    w[1,20]   old_normalized_TC2  1.7216783216783216e+00
    w[1,21]   mass_1    1
    w[1,21]   w_lb_1_21  1
    w[1,21]   w_ub_1_21  1
    w[1,21]   normalized_inventory_1  -21
    w[1,21]   old_normalized_TC  -3.7356060606060608e+00
    w[1,21]   old_normalized_TC2  1.0512237762237759e+00
    w[1,22]   mass_1    1
    w[1,22]   w_lb_1_22  1
    w[1,22]   w_ub_1_22  1
    w[1,22]   normalized_inventory_1  -22
    w[1,22]   old_normalized_TC  -4.8763819513819513e+00
    w[1,22]   old_normalized_TC2  -8.9552114552115175e-02
    w[1,23]   mass_1    1
    w[1,23]   w_lb_1_23  1
    w[1,23]   w_ub_1_23  1
    w[1,23]   normalized_inventory_1  -23
    w[1,23]   old_normalized_TC  -6.1491092241092247e+00
    w[1,23]   old_normalized_TC2  -1.3622793872793879e+00
    w[1,24]   mass_1    1
    w[1,24]   w_lb_1_24  1
    w[1,24]   w_ub_1_24  1
    w[1,24]   normalized_inventory_1  -24
    w[1,24]   old_normalized_TC  -7.4925435675435681e+00
    w[1,24]   old_normalized_TC2  -2.7057137307137316e+00
    w[2,0]    mass_2    1
    w[2,0]    w_lb_2_0  1
    w[2,0]    w_ub_2_0  1
    w[2,1]    mass_2    1
    w[2,1]    w_lb_2_1  1
    w[2,1]    w_ub_2_1  1
    w[2,1]    normalized_inventory_2  -1
    w[2,1]    old_normalized_TC2  5.7142857142857140e-01
    w[2,2]    mass_2    1
    w[2,2]    w_lb_2_2  1
    w[2,2]    w_ub_2_2  1
    w[2,2]    normalized_inventory_2  -2
    w[2,2]    old_normalized_TC2  1.1428571428571428e+00
    w[2,3]    mass_2    1
    w[2,3]    w_lb_2_3  1
    w[2,3]    w_ub_2_3  1
    w[2,3]    normalized_inventory_2  -3
    w[2,3]    old_normalized_TC2  1.7
    w[2,4]    mass_2    1
    w[2,4]    w_lb_2_4  1
    w[2,4]    w_ub_2_4  1
    w[2,4]    normalized_inventory_2  -4
    w[2,4]    old_normalized_TC2  2.2
    w[2,5]    mass_2    1
    w[2,5]    w_lb_2_5  1
    w[2,5]    w_ub_2_5  1
    w[2,5]    normalized_inventory_2  -5
    w[2,5]    old_normalized_TC2  2.7
    w[2,6]    mass_2    1
    w[2,6]    w_lb_2_6  1
    w[2,6]    w_ub_2_6  1
    w[2,6]    normalized_inventory_2  -6
    w[2,6]    old_normalized_TC2  3.1350649350649351e+00
    w[2,7]    mass_2    1
    w[2,7]    w_lb_2_7  1
    w[2,7]    w_ub_2_7  1
    w[2,7]    normalized_inventory_2  -7
    w[2,7]    old_normalized_TC2  3.5251748251748252e+00
    w[2,8]    mass_2    1
    w[2,8]    w_lb_2_8  1
    w[2,8]    w_ub_2_8  1
    w[2,8]    normalized_inventory_2  -8
    w[2,8]    old_normalized_TC2  3.8823176823176824e+00
    w[2,9]    mass_2    1
    w[2,9]    w_lb_2_9  1
    w[2,9]    w_ub_2_9  1
    w[2,9]    normalized_inventory_2  -9
    w[2,9]    old_normalized_TC2  4.17993672993673
    w[2,10]   mass_2    1
    w[2,10]   w_lb_2_10  1
    w[2,10]   w_ub_2_10  1
    w[2,10]   normalized_inventory_2  -10
    w[2,10]   old_normalized_TC2  4.4180319680319684e+00
    w[2,11]   mass_2    1
    w[2,11]   w_lb_2_11  1
    w[2,11]   w_ub_2_11  1
    w[2,11]   normalized_inventory_2  -11
    w[2,11]   old_normalized_TC2  4.6158341658341664e+00
    w[2,12]   mass_2    1
    w[2,12]   w_lb_2_12  1
    w[2,12]   w_ub_2_12  1
    w[2,12]   normalized_inventory_2  -12
    w[2,12]   old_normalized_TC2  4.7348817848817850e+00
    w[2,13]   mass_2    1
    w[2,13]   w_lb_2_13  1
    w[2,13]   w_ub_2_13  1
    w[2,13]   normalized_inventory_2  -13
    w[2,13]   old_normalized_TC2  4.7868298368298374e+00
    w[2,14]   mass_2    1
    w[2,14]   w_lb_2_14  1
    w[2,14]   w_ub_2_14  1
    w[2,14]   normalized_inventory_2  -14
    w[2,14]   old_normalized_TC2  4.7868298368298374e+00
    w[2,15]   mass_2    1
    w[2,15]   w_lb_2_15  1
    w[2,15]   w_ub_2_15  1
    w[2,15]   normalized_inventory_2  -15
    w[2,15]   old_normalized_TC2  4.7868298368298374e+00
    w[2,16]   mass_2    1
    w[2,16]   w_lb_2_16  1
    w[2,16]   w_ub_2_16  1
    w[2,16]   normalized_inventory_2  -16
    w[2,16]   old_normalized_TC  -5.9523809523809521e-02
    w[2,16]   old_normalized_TC2  4.7273060273060281e+00
    w[2,17]   mass_2    1
    w[2,17]   w_lb_2_17  1
    w[2,17]   w_ub_2_17  1
    w[2,17]   normalized_inventory_2  -17
    w[2,17]   old_normalized_TC  -1.7857142857142855e-01
    w[2,17]   old_normalized_TC2  4.6082584082584086e+00
    w[2,18]   mass_2    1
    w[2,18]   w_lb_2_18  1
    w[2,18]   w_ub_2_18  1
    w[2,18]   normalized_inventory_2  -18
    w[2,18]   old_normalized_TC  -3.4047619047619038e-01
    w[2,18]   old_normalized_TC2  4.4463536463536473e+00
    w[2,19]   mass_2    1
    w[2,19]   w_lb_2_19  1
    w[2,19]   w_ub_2_19  1
    w[2,19]   normalized_inventory_2  -19
    w[2,19]   old_normalized_TC  -5.5476190476190468e-01
    w[2,19]   old_normalized_TC2  4.2320679320679329e+00
    w[2,20]   mass_2    1
    w[2,20]   w_lb_2_20  1
    w[2,20]   w_ub_2_20  1
    w[2,20]   normalized_inventory_2  -20
    w[2,20]   old_normalized_TC  -8.3398268398268371e-01
    w[2,20]   old_normalized_TC2  3.9528471528471534e+00
    w[2,21]   mass_2    1
    w[2,21]   w_lb_2_21  1
    w[2,21]   w_ub_2_21  1
    w[2,21]   normalized_inventory_2  -21
    w[2,21]   old_normalized_TC  -1.1651515151515146e+00
    w[2,21]   old_normalized_TC2  3.6216783216783224e+00
    w[2,22]   mass_2    1
    w[2,22]   w_lb_2_22  1
    w[2,22]   w_ub_2_22  1
    w[2,22]   normalized_inventory_2  -22
    w[2,22]   old_normalized_TC  -1.5222943722943718e+00
    w[2,22]   old_normalized_TC2  3.2645354645354652e+00
    w[2,23]   mass_2    1
    w[2,23]   w_lb_2_23  1
    w[2,23]   w_ub_2_23  1
    w[2,23]   normalized_inventory_2  -23
    w[2,23]   old_normalized_TC  -1.9222943722943717e+00
    w[2,23]   old_normalized_TC2  2.8645354645354653e+00
    w[2,24]   mass_2    1
    w[2,24]   w_lb_2_24  1
    w[2,24]   w_ub_2_24  1
    w[2,24]   normalized_inventory_2  -24
    w[2,24]   old_normalized_TC  -2.3508658008658
    w[2,24]   old_normalized_TC2  2.4359640359640369e+00
    w[2,25]   mass_2    1
    w[2,25]   w_lb_2_25  1
    w[2,25]   w_ub_2_25  1
    w[2,25]   normalized_inventory_2  -25
    w[2,25]   old_normalized_TC  -2.8378787878787870e+00
    w[2,25]   old_normalized_TC2  1.9489510489510498e+00
    w[3,0]    mass_3    1
    w[3,0]    w_lb_3_0  1
    w[3,0]    w_ub_3_0  1
    w[3,1]    mass_3    1
    w[3,1]    w_lb_3_1  1
    w[3,1]    w_ub_3_1  1
    w[3,1]    normalized_inventory_3  -1
    w[3,1]    old_normalized_TC2  5.3333333333333333e-01
    w[3,2]    mass_3    1
    w[3,2]    w_lb_3_2  1
    w[3,2]    w_ub_3_2  1
    w[3,2]    normalized_inventory_3  -2
    w[3,2]    old_normalized_TC2  1.0666666666666667e+00
    w[3,3]    mass_3    1
    w[3,3]    w_lb_3_3  1
    w[3,3]    w_ub_3_3  1
    w[3,3]    normalized_inventory_3  -3
    w[3,3]    old_normalized_TC2  1.6
    w[3,4]    mass_3    1
    w[3,4]    w_lb_3_4  1
    w[3,4]    w_ub_3_4  1
    w[3,4]    normalized_inventory_3  -4
    w[3,4]    old_normalized_TC2  2.0666666666666669e+00
    w[3,5]    mass_3    1
    w[3,5]    w_lb_3_5  1
    w[3,5]    w_ub_3_5  1
    w[3,5]    normalized_inventory_3  -5
    w[3,5]    old_normalized_TC2  2.5333333333333337e+00
    w[3,6]    mass_3    1
    w[3,6]    w_lb_3_6  1
    w[3,6]    w_ub_3_6  1
    w[3,6]    normalized_inventory_3  -6
    w[3,6]    old_normalized_TC2  2.9636363636363638e+00
    w[3,7]    mass_3    1
    w[3,7]    w_lb_3_7  1
    w[3,7]    w_ub_3_7  1
    w[3,7]    normalized_inventory_3  -7
    w[3,7]    old_normalized_TC2  3.3585081585081586e+00
    w[3,8]    mass_3    1
    w[3,8]    w_lb_3_8  1
    w[3,8]    w_ub_3_8  1
    w[3,8]    normalized_inventory_3  -8
    w[3,8]    old_normalized_TC2  3.6918414918414921e+00
    w[3,9]    mass_3    1
    w[3,9]    w_lb_3_9  1
    w[3,9]    w_ub_3_9  1
    w[3,9]    normalized_inventory_3  -9
    w[3,9]    old_normalized_TC2  4.0085081585081586e+00
    w[3,10]   mass_3    1
    w[3,10]   w_lb_3_10  1
    w[3,10]   w_ub_3_10  1
    w[3,10]   normalized_inventory_3  -10
    w[3,10]   old_normalized_TC2  4.2751748251748252e+00
    w[3,11]   mass_3    1
    w[3,11]   w_lb_3_11  1
    w[3,11]   w_ub_3_11  1
    w[3,11]   normalized_inventory_3  -11
    w[3,11]   old_normalized_TC2  4.4751748251748253e+00
    w[3,12]   mass_3    1
    w[3,12]   w_lb_3_12  1
    w[3,12]   w_ub_3_12  1
    w[3,12]   normalized_inventory_3  -12
    w[3,12]   old_normalized_TC2  4.6444055944055949e+00
    w[3,13]   mass_3    1
    w[3,13]   w_lb_3_13  1
    w[3,13]   w_ub_3_13  1
    w[3,13]   normalized_inventory_3  -13
    w[3,13]   old_normalized_TC2  4.7444055944055945e+00
    w[3,14]   mass_3    1
    w[3,14]   w_lb_3_14  1
    w[3,14]   w_ub_3_14  1
    w[3,14]   normalized_inventory_3  -14
    w[3,14]   old_normalized_TC2  4.7868298368298374e+00
    w[3,15]   mass_3    1
    w[3,15]   w_lb_3_15  1
    w[3,15]   w_ub_3_15  1
    w[3,15]   normalized_inventory_3  -15
    w[3,15]   old_normalized_TC2  4.7868298368298374e+00
    w[3,16]   mass_3    1
    w[3,16]   w_lb_3_16  1
    w[3,16]   w_ub_3_16  1
    w[3,16]   normalized_inventory_3  -16
    w[3,16]   old_normalized_TC2  4.7868298368298374e+00
    w[3,17]   mass_3    1
    w[3,17]   w_lb_3_17  1
    w[3,17]   w_ub_3_17  1
    w[3,17]   normalized_inventory_3  -17
    w[3,17]   old_normalized_TC  -5.0000000000000044e-02
    w[3,17]   old_normalized_TC2  4.7368298368298376e+00
    w[3,18]   mass_3    1
    w[3,18]   w_lb_3_18  1
    w[3,18]   w_ub_3_18  1
    w[3,18]   normalized_inventory_3  -18
    w[3,18]   old_normalized_TC  -1.5000000000000008e-01
    w[3,18]   old_normalized_TC2  4.6368298368298371e+00
    w[3,19]   mass_3    1
    w[3,19]   w_lb_3_19  1
    w[3,19]   w_ub_3_19  1
    w[3,19]   normalized_inventory_3  -19
    w[3,19]   old_normalized_TC  -2.8333333333333338e-01
    w[3,19]   old_normalized_TC2  4.5034965034965042e+00
    w[3,20]   mass_3    1
    w[3,20]   w_lb_3_20  1
    w[3,20]   w_ub_3_20  1
    w[3,20]   normalized_inventory_3  -20
    w[3,20]   old_normalized_TC  -4.8333333333333339e-01
    w[3,20]   old_normalized_TC2  4.3034965034965040e+00
    w[3,21]   mass_3    1
    w[3,21]   w_lb_3_21  1
    w[3,21]   w_ub_3_21  1
    w[3,21]   normalized_inventory_3  -21
    w[3,21]   old_normalized_TC  -7.1969696969696972e-01
    w[3,21]   old_normalized_TC2  4.0671328671328677e+00
    w[3,22]   mass_3    1
    w[3,22]   w_lb_3_22  1
    w[3,22]   w_ub_3_22  1
    w[3,22]   normalized_inventory_3  -22
    w[3,22]   old_normalized_TC  -9.9848484848484842e-01
    w[3,22]   old_normalized_TC2  3.7883449883449885e+00
    w[3,23]   mass_3    1
    w[3,23]   w_lb_3_23  1
    w[3,23]   w_ub_3_23  1
    w[3,23]   normalized_inventory_3  -23
    w[3,23]   old_normalized_TC  -1.3318181818181816e+00
    w[3,23]   old_normalized_TC2  3.4550116550116554e+00
    w[3,24]   mass_3    1
    w[3,24]   w_lb_3_24  1
    w[3,24]   w_ub_3_24  1
    w[3,24]   normalized_inventory_3  -24
    w[3,24]   old_normalized_TC  -1.6651515151515150e+00
    w[3,24]   old_normalized_TC2  3.1216783216783219e+00
    w[3,25]   mass_3    1
    w[3,25]   w_lb_3_25  1
    w[3,25]   w_ub_3_25  1
    w[3,25]   normalized_inventory_3  -25
    w[3,25]   old_normalized_TC  -2.0651515151515150e+00
    w[3,25]   old_normalized_TC2  2.7216783216783220e+00
    w[3,26]   mass_3    1
    w[3,26]   w_lb_3_26  1
    w[3,26]   w_ub_3_26  1
    w[3,26]   normalized_inventory_3  -26
    w[3,26]   old_normalized_TC  -2.4712121212121207e+00
    w[3,26]   old_normalized_TC2  2.3156177156177162e+00
    w[3,27]   mass_3    1
    w[3,27]   w_lb_3_27  1
    w[3,27]   w_ub_3_27  1
    w[3,27]   normalized_inventory_3  -27
    w[3,27]   old_normalized_TC  -2.9378787878787875e+00
    w[3,27]   old_normalized_TC2  1.8489510489510492e+00
    w[4,0]    mass_4    1
    w[4,0]    w_lb_4_0  1
    w[4,0]    w_ub_4_0  1
    w[4,1]    mass_4    1
    w[4,1]    w_lb_4_1  1
    w[4,1]    w_ub_4_1  1
    w[4,1]    normalized_inventory_4  -1
    w[4,1]    old_normalized_TC2  7.2727272727272729e-01
    w[4,2]    mass_4    1
    w[4,2]    w_lb_4_2  1
    w[4,2]    w_ub_4_2  1
    w[4,2]    normalized_inventory_4  -2
    w[4,2]    old_normalized_TC2  1.4545454545454546e+00
    w[4,3]    mass_4    1
    w[4,3]    w_lb_4_3  1
    w[4,3]    w_ub_4_3  1
    w[4,3]    normalized_inventory_4  -3
    w[4,3]    old_normalized_TC2  2.1090909090909093e+00
    w[4,4]    mass_4    1
    w[4,4]    w_lb_4_4  1
    w[4,4]    w_ub_4_4  1
    w[4,4]    normalized_inventory_4  -4
    w[4,4]    old_normalized_TC2  2.7454545454545456e+00
    w[4,5]    mass_4    1
    w[4,5]    w_lb_4_5  1
    w[4,5]    w_ub_4_5  1
    w[4,5]    normalized_inventory_4  -5
    w[4,5]    old_normalized_TC2  3.2909090909090910e+00
    w[4,6]    mass_4    1
    w[4,6]    w_lb_4_6  1
    w[4,6]    w_ub_4_6  1
    w[4,6]    normalized_inventory_4  -6
    w[4,6]    old_normalized_TC2  3.7524475524475527e+00
    w[4,7]    mass_4    1
    w[4,7]    w_lb_4_7  1
    w[4,7]    w_ub_4_7  1
    w[4,7]    normalized_inventory_4  -7
    w[4,7]    old_normalized_TC2  4.1539627039627041e+00
    w[4,8]    mass_4    1
    w[4,8]    w_lb_4_8  1
    w[4,8]    w_ub_4_8  1
    w[4,8]    normalized_inventory_4  -8
    w[4,8]    old_normalized_TC2  4.4569930069930077e+00
    w[4,9]    mass_4    1
    w[4,9]    w_lb_4_9  1
    w[4,9]    w_ub_4_9  1
    w[4,9]    normalized_inventory_4  -9
    w[4,9]    old_normalized_TC2  4.6807692307692310e+00
    w[4,10]   mass_4    1
    w[4,10]   w_lb_4_10  1
    w[4,10]   w_ub_4_10  1
    w[4,10]   normalized_inventory_4  -10
    w[4,10]   old_normalized_TC2  4.7868298368298374e+00
    w[4,11]   mass_4    1
    w[4,11]   w_lb_4_11  1
    w[4,11]   w_ub_4_11  1
    w[4,11]   normalized_inventory_4  -11
    w[4,11]   old_normalized_TC2  4.7868298368298374e+00
    w[4,12]   mass_4    1
    w[4,12]   w_lb_4_12  1
    w[4,12]   w_ub_4_12  1
    w[4,12]   normalized_inventory_4  -12
    w[4,12]   old_normalized_TC  -7.5757575757576662e-03
    w[4,12]   old_normalized_TC2  4.77925407925408
    w[4,13]   mass_4    1
    w[4,13]   w_lb_4_13  1
    w[4,13]   w_ub_4_13  1
    w[4,13]   normalized_inventory_4  -13
    w[4,13]   old_normalized_TC  -1.1363636363636383e-01
    w[4,13]   old_normalized_TC2  4.6731934731934732e+00
    w[4,14]   mass_4    1
    w[4,14]   w_lb_4_14  1
    w[4,14]   w_ub_4_14  1
    w[4,14]   normalized_inventory_4  -14
    w[4,14]   old_normalized_TC  -3.0151515151515174e-01
    w[4,14]   old_normalized_TC2  4.4853146853146857e+00
    w[4,15]   mass_4    1
    w[4,15]   w_lb_4_15  1
    w[4,15]   w_ub_4_15  1
    w[4,15]   normalized_inventory_4  -15
    w[4,15]   old_normalized_TC  -5.7424242424242444e-01
    w[4,15]   old_normalized_TC2  4.2125874125874132e+00
    w[4,16]   mass_4    1
    w[4,16]   w_lb_4_16  1
    w[4,16]   w_ub_4_16  1
    w[4,16]   normalized_inventory_4  -16
    w[4,16]   old_normalized_TC  -9.3787878787878809e-01
    w[4,16]   old_normalized_TC2  3.8489510489510490e+00
    w[4,17]   mass_4    1
    w[4,17]   w_lb_4_17  1
    w[4,17]   w_ub_4_17  1
    w[4,17]   normalized_inventory_4  -17
    w[4,17]   old_normalized_TC  -1.3924242424242426e+00
    w[4,17]   old_normalized_TC2  3.3944055944055944e+00
    w[4,18]   mass_4    1
    w[4,18]   w_lb_4_18  1
    w[4,18]   w_ub_4_18  1
    w[4,18]   normalized_inventory_4  -18
    w[4,18]   old_normalized_TC  -1.8833333333333335e+00
    w[4,18]   old_normalized_TC2  2.9034965034965037e+00
    w[4,19]   mass_4    1
    w[4,19]   w_lb_4_19  1
    w[4,19]   w_ub_4_19  1
    w[4,19]   normalized_inventory_4  -19
    w[4,19]   old_normalized_TC  -2.4287878787878787e+00
    w[4,19]   old_normalized_TC2  2.3580419580419578e+00
    w[4,20]   mass_4    1
    w[4,20]   w_lb_4_20  1
    w[4,20]   w_ub_4_20  1
    w[4,20]   normalized_inventory_4  -20
    w[4,20]   old_normalized_TC  -3.0651515151515154e+00
    w[4,20]   old_normalized_TC2  1.7216783216783216e+00
    w[4,21]   mass_4    1
    w[4,21]   w_lb_4_21  1
    w[4,21]   w_ub_4_21  1
    w[4,21]   normalized_inventory_4  -21
    w[4,21]   old_normalized_TC  -3.7356060606060608e+00
    w[4,21]   old_normalized_TC2  1.0512237762237759e+00
    w[4,22]   mass_4    1
    w[4,22]   w_lb_4_22  1
    w[4,22]   w_ub_4_22  1
    w[4,22]   normalized_inventory_4  -22
    w[4,22]   old_normalized_TC  -4.8763819513819513e+00
    w[4,22]   old_normalized_TC2  -8.9552114552115175e-02
    w[4,23]   mass_4    1
    w[4,23]   w_lb_4_23  1
    w[4,23]   w_ub_4_23  1
    w[4,23]   normalized_inventory_4  -23
    w[4,23]   old_normalized_TC  -6.1491092241092247e+00
    w[4,23]   old_normalized_TC2  -1.3622793872793879e+00
    w[4,24]   mass_4    1
    w[4,24]   w_lb_4_24  1
    w[4,24]   w_ub_4_24  1
    w[4,24]   normalized_inventory_4  -24
    w[4,24]   old_normalized_TC  -7.4925435675435681e+00
    w[4,24]   old_normalized_TC2  -2.7057137307137316e+00
    w[5,0]    mass_5    1
    w[5,0]    w_lb_5_0  1
    w[5,0]    w_ub_5_0  1
    w[5,1]    mass_5    1
    w[5,1]    w_lb_5_1  1
    w[5,1]    w_ub_5_1  1
    w[5,1]    normalized_inventory_5  -1
    w[5,1]    old_normalized_TC2  7.2727272727272729e-01
    w[5,2]    mass_5    1
    w[5,2]    w_lb_5_2  1
    w[5,2]    w_ub_5_2  1
    w[5,2]    normalized_inventory_5  -2
    w[5,2]    old_normalized_TC2  1.4545454545454546e+00
    w[5,3]    mass_5    1
    w[5,3]    w_lb_5_3  1
    w[5,3]    w_ub_5_3  1
    w[5,3]    normalized_inventory_5  -3
    w[5,3]    old_normalized_TC2  2.1090909090909093e+00
    w[5,4]    mass_5    1
    w[5,4]    w_lb_5_4  1
    w[5,4]    w_ub_5_4  1
    w[5,4]    normalized_inventory_5  -4
    w[5,4]    old_normalized_TC2  2.7454545454545456e+00
    w[5,5]    mass_5    1
    w[5,5]    w_lb_5_5  1
    w[5,5]    w_ub_5_5  1
    w[5,5]    normalized_inventory_5  -5
    w[5,5]    old_normalized_TC2  3.2909090909090910e+00
    w[5,6]    mass_5    1
    w[5,6]    w_lb_5_6  1
    w[5,6]    w_ub_5_6  1
    w[5,6]    normalized_inventory_5  -6
    w[5,6]    old_normalized_TC2  3.7524475524475527e+00
    w[5,7]    mass_5    1
    w[5,7]    w_lb_5_7  1
    w[5,7]    w_ub_5_7  1
    w[5,7]    normalized_inventory_5  -7
    w[5,7]    old_normalized_TC2  4.1539627039627041e+00
    w[5,8]    mass_5    1
    w[5,8]    w_lb_5_8  1
    w[5,8]    w_ub_5_8  1
    w[5,8]    normalized_inventory_5  -8
    w[5,8]    old_normalized_TC2  4.4569930069930077e+00
    w[5,9]    mass_5    1
    w[5,9]    w_lb_5_9  1
    w[5,9]    w_ub_5_9  1
    w[5,9]    normalized_inventory_5  -9
    w[5,9]    old_normalized_TC2  4.6807692307692310e+00
    w[5,10]   mass_5    1
    w[5,10]   w_lb_5_10  1
    w[5,10]   w_ub_5_10  1
    w[5,10]   normalized_inventory_5  -10
    w[5,10]   old_normalized_TC2  4.7868298368298374e+00
    w[5,11]   mass_5    1
    w[5,11]   w_lb_5_11  1
    w[5,11]   w_ub_5_11  1
    w[5,11]   normalized_inventory_5  -11
    w[5,11]   old_normalized_TC2  4.7868298368298374e+00
    w[5,12]   mass_5    1
    w[5,12]   w_lb_5_12  1
    w[5,12]   w_ub_5_12  1
    w[5,12]   normalized_inventory_5  -12
    w[5,12]   old_normalized_TC  -7.5757575757576662e-03
    w[5,12]   old_normalized_TC2  4.77925407925408
    w[5,13]   mass_5    1
    w[5,13]   w_lb_5_13  1
    w[5,13]   w_ub_5_13  1
    w[5,13]   normalized_inventory_5  -13
    w[5,13]   old_normalized_TC  -1.1363636363636383e-01
    w[5,13]   old_normalized_TC2  4.6731934731934732e+00
    w[5,14]   mass_5    1
    w[5,14]   w_lb_5_14  1
    w[5,14]   w_ub_5_14  1
    w[5,14]   normalized_inventory_5  -14
    w[5,14]   old_normalized_TC  -3.0151515151515174e-01
    w[5,14]   old_normalized_TC2  4.4853146853146857e+00
    w[5,15]   mass_5    1
    w[5,15]   w_lb_5_15  1
    w[5,15]   w_ub_5_15  1
    w[5,15]   normalized_inventory_5  -15
    w[5,15]   old_normalized_TC  -5.7424242424242444e-01
    w[5,15]   old_normalized_TC2  4.2125874125874132e+00
    w[5,16]   mass_5    1
    w[5,16]   w_lb_5_16  1
    w[5,16]   w_ub_5_16  1
    w[5,16]   normalized_inventory_5  -16
    w[5,16]   old_normalized_TC  -9.3787878787878809e-01
    w[5,16]   old_normalized_TC2  3.8489510489510490e+00
    w[5,17]   mass_5    1
    w[5,17]   w_lb_5_17  1
    w[5,17]   w_ub_5_17  1
    w[5,17]   normalized_inventory_5  -17
    w[5,17]   old_normalized_TC  -1.3924242424242426e+00
    w[5,17]   old_normalized_TC2  3.3944055944055944e+00
    w[5,18]   mass_5    1
    w[5,18]   w_lb_5_18  1
    w[5,18]   w_ub_5_18  1
    w[5,18]   normalized_inventory_5  -18
    w[5,18]   old_normalized_TC  -1.8833333333333335e+00
    w[5,18]   old_normalized_TC2  2.9034965034965037e+00
    w[5,19]   mass_5    1
    w[5,19]   w_lb_5_19  1
    w[5,19]   w_ub_5_19  1
    w[5,19]   normalized_inventory_5  -19
    w[5,19]   old_normalized_TC  -2.4287878787878787e+00
    w[5,19]   old_normalized_TC2  2.3580419580419578e+00
    w[5,20]   mass_5    1
    w[5,20]   w_lb_5_20  1
    w[5,20]   w_ub_5_20  1
    w[5,20]   normalized_inventory_5  -20
    w[5,20]   old_normalized_TC  -3.0651515151515154e+00
    w[5,20]   old_normalized_TC2  1.7216783216783216e+00
    w[5,21]   mass_5    1
    w[5,21]   w_lb_5_21  1
    w[5,21]   w_ub_5_21  1
    w[5,21]   normalized_inventory_5  -21
    w[5,21]   old_normalized_TC  -3.7356060606060608e+00
    w[5,21]   old_normalized_TC2  1.0512237762237759e+00
    w[6,0]    mass_6    1
    w[6,0]    w_lb_6_0  1
    w[6,0]    w_ub_6_0  1
    w[6,1]    mass_6    1
    w[6,1]    w_lb_6_1  1
    w[6,1]    w_ub_6_1  1
    w[6,1]    normalized_inventory_6  -1
    w[6,1]    old_normalized_TC2  7.2727272727272729e-01
    w[6,2]    mass_6    1
    w[6,2]    w_lb_6_2  1
    w[6,2]    w_ub_6_2  1
    w[6,2]    normalized_inventory_6  -2
    w[6,2]    old_normalized_TC2  1.4545454545454546e+00
    w[6,3]    mass_6    1
    w[6,3]    w_lb_6_3  1
    w[6,3]    w_ub_6_3  1
    w[6,3]    normalized_inventory_6  -3
    w[6,3]    old_normalized_TC2  2.1090909090909093e+00
    w[6,4]    mass_6    1
    w[6,4]    w_lb_6_4  1
    w[6,4]    w_ub_6_4  1
    w[6,4]    normalized_inventory_6  -4
    w[6,4]    old_normalized_TC2  2.7454545454545456e+00
    w[6,5]    mass_6    1
    w[6,5]    w_lb_6_5  1
    w[6,5]    w_ub_6_5  1
    w[6,5]    normalized_inventory_6  -5
    w[6,5]    old_normalized_TC2  3.2909090909090910e+00
    w[6,6]    mass_6    1
    w[6,6]    w_lb_6_6  1
    w[6,6]    w_ub_6_6  1
    w[6,6]    normalized_inventory_6  -6
    w[6,6]    old_normalized_TC2  3.7524475524475527e+00
    w[6,7]    mass_6    1
    w[6,7]    w_lb_6_7  1
    w[6,7]    w_ub_6_7  1
    w[6,7]    normalized_inventory_6  -7
    w[6,7]    old_normalized_TC2  4.1539627039627041e+00
    w[6,8]    mass_6    1
    w[6,8]    w_lb_6_8  1
    w[6,8]    w_ub_6_8  1
    w[6,8]    normalized_inventory_6  -8
    w[6,8]    old_normalized_TC2  4.4569930069930077e+00
    w[6,9]    mass_6    1
    w[6,9]    w_lb_6_9  1
    w[6,9]    w_ub_6_9  1
    w[6,9]    normalized_inventory_6  -9
    w[6,9]    old_normalized_TC2  4.6807692307692310e+00
    w[6,10]   mass_6    1
    w[6,10]   w_lb_6_10  1
    w[6,10]   w_ub_6_10  1
    w[6,10]   normalized_inventory_6  -10
    w[6,10]   old_normalized_TC2  4.7868298368298374e+00
    w[6,11]   mass_6    1
    w[6,11]   w_lb_6_11  1
    w[6,11]   w_ub_6_11  1
    w[6,11]   normalized_inventory_6  -11
    w[6,11]   old_normalized_TC2  4.7868298368298374e+00
    w[6,12]   mass_6    1
    w[6,12]   w_lb_6_12  1
    w[6,12]   w_ub_6_12  1
    w[6,12]   normalized_inventory_6  -12
    w[6,12]   old_normalized_TC  -7.5757575757576662e-03
    w[6,12]   old_normalized_TC2  4.77925407925408
    w[6,13]   mass_6    1
    w[6,13]   w_lb_6_13  1
    w[6,13]   w_ub_6_13  1
    w[6,13]   normalized_inventory_6  -13
    w[6,13]   old_normalized_TC  -1.1363636363636383e-01
    w[6,13]   old_normalized_TC2  4.6731934731934732e+00
    w[6,14]   mass_6    1
    w[6,14]   w_lb_6_14  1
    w[6,14]   w_ub_6_14  1
    w[6,14]   normalized_inventory_6  -14
    w[6,14]   old_normalized_TC  -3.0151515151515174e-01
    w[6,14]   old_normalized_TC2  4.4853146853146857e+00
    w[6,15]   mass_6    1
    w[6,15]   w_lb_6_15  1
    w[6,15]   w_ub_6_15  1
    w[6,15]   normalized_inventory_6  -15
    w[6,15]   old_normalized_TC  -5.7424242424242444e-01
    w[6,15]   old_normalized_TC2  4.2125874125874132e+00
    w[6,16]   mass_6    1
    w[6,16]   w_lb_6_16  1
    w[6,16]   w_ub_6_16  1
    w[6,16]   normalized_inventory_6  -16
    w[6,16]   old_normalized_TC  -9.3787878787878809e-01
    w[6,16]   old_normalized_TC2  3.8489510489510490e+00
    w[6,17]   mass_6    1
    w[6,17]   w_lb_6_17  1
    w[6,17]   w_ub_6_17  1
    w[6,17]   normalized_inventory_6  -17
    w[6,17]   old_normalized_TC  -1.3924242424242426e+00
    w[6,17]   old_normalized_TC2  3.3944055944055944e+00
    w[6,18]   mass_6    1
    w[6,18]   w_lb_6_18  1
    w[6,18]   w_ub_6_18  1
    w[6,18]   normalized_inventory_6  -18
    w[6,18]   old_normalized_TC  -1.8833333333333335e+00
    w[6,18]   old_normalized_TC2  2.9034965034965037e+00
    w[6,19]   mass_6    1
    w[6,19]   w_lb_6_19  1
    w[6,19]   w_ub_6_19  1
    w[6,19]   normalized_inventory_6  -19
    w[6,19]   old_normalized_TC  -2.4287878787878787e+00
    w[6,19]   old_normalized_TC2  2.3580419580419578e+00
    w[6,20]   mass_6    1
    w[6,20]   w_lb_6_20  1
    w[6,20]   w_ub_6_20  1
    w[6,20]   normalized_inventory_6  -20
    w[6,20]   old_normalized_TC  -3.0651515151515154e+00
    w[6,20]   old_normalized_TC2  1.7216783216783216e+00
    w[6,21]   mass_6    1
    w[6,21]   w_lb_6_21  1
    w[6,21]   w_ub_6_21  1
    w[6,21]   normalized_inventory_6  -21
    w[6,21]   old_normalized_TC  -3.7356060606060608e+00
    w[6,21]   old_normalized_TC2  1.0512237762237759e+00
    w[6,22]   mass_6    1
    w[6,22]   w_lb_6_22  1
    w[6,22]   w_ub_6_22  1
    w[6,22]   normalized_inventory_6  -22
    w[6,22]   old_normalized_TC  -4.8763819513819513e+00
    w[6,22]   old_normalized_TC2  -8.9552114552115175e-02
    w[6,23]   mass_6    1
    w[6,23]   w_lb_6_23  1
    w[6,23]   w_ub_6_23  1
    w[6,23]   normalized_inventory_6  -23
    w[6,23]   old_normalized_TC  -6.1491092241092247e+00
    w[6,23]   old_normalized_TC2  -1.3622793872793879e+00
    w[6,24]   mass_6    1
    w[6,24]   w_lb_6_24  1
    w[6,24]   w_ub_6_24  1
    w[6,24]   normalized_inventory_6  -24
    w[6,24]   old_normalized_TC  -7.4925435675435681e+00
    w[6,24]   old_normalized_TC2  -2.7057137307137316e+00
    w[7,0]    mass_7    1
    w[7,0]    w_lb_7_0  1
    w[7,0]    w_ub_7_0  1
    w[7,1]    mass_7    1
    w[7,1]    w_lb_7_1  1
    w[7,1]    w_ub_7_1  1
    w[7,1]    normalized_inventory_7  -1
    w[7,1]    old_normalized_TC2  0.8
    w[7,2]    mass_7    1
    w[7,2]    w_lb_7_2  1
    w[7,2]    w_ub_7_2  1
    w[7,2]    normalized_inventory_7  -2
    w[7,2]    old_normalized_TC2  1.6
    w[7,3]    mass_7    1
    w[7,3]    w_lb_7_3  1
    w[7,3]    w_ub_7_3  1
    w[7,3]    normalized_inventory_7  -3
    w[7,3]    old_normalized_TC2  2.3000000000000003e+00
    w[7,4]    mass_7    1
    w[7,4]    w_lb_7_4  1
    w[7,4]    w_ub_7_4  1
    w[7,4]    normalized_inventory_7  -4
    w[7,4]    old_normalized_TC2  2.9636363636363638e+00
    w[7,5]    mass_7    1
    w[7,5]    w_lb_7_5  1
    w[7,5]    w_ub_7_5  1
    w[7,5]    normalized_inventory_7  -5
    w[7,5]    old_normalized_TC2  3.5251748251748256e+00
    w[7,6]    mass_7    1
    w[7,6]    w_lb_7_6  1
    w[7,6]    w_ub_7_6  1
    w[7,6]    normalized_inventory_7  -6
    w[7,6]    old_normalized_TC2  4.0085081585081594e+00
    w[7,7]    mass_7    1
    w[7,7]    w_lb_7_7  1
    w[7,7]    w_ub_7_7  1
    w[7,7]    normalized_inventory_7  -7
    w[7,7]    old_normalized_TC2  4.3751748251748257e+00
    w[7,8]    mass_7    1
    w[7,8]    w_lb_7_8  1
    w[7,8]    w_ub_7_8  1
    w[7,8]    normalized_inventory_7  -8
    w[7,8]    old_normalized_TC2  4.6444055944055949e+00
    w[7,9]    mass_7    1
    w[7,9]    w_lb_7_9  1
    w[7,9]    w_ub_7_9  1
    w[7,9]    normalized_inventory_7  -9
    w[7,9]    old_normalized_TC2  4.7777389277389286e+00
    w[7,10]   mass_7    1
    w[7,10]   w_lb_7_10  1
    w[7,10]   w_ub_7_10  1
    w[7,10]   normalized_inventory_7  -10
    w[7,10]   old_normalized_TC2  4.7868298368298374e+00
    w[7,11]   mass_7    1
    w[7,11]   w_lb_7_11  1
    w[7,11]   w_ub_7_11  1
    w[7,11]   normalized_inventory_7  -11
    w[7,11]   old_normalized_TC  -1.6666666666666788e-02
    w[7,11]   old_normalized_TC2  4.7701631701631708e+00
    w[7,12]   mass_7    1
    w[7,12]   w_lb_7_12  1
    w[7,12]   w_ub_7_12  1
    w[7,12]   normalized_inventory_7  -12
    w[7,12]   old_normalized_TC  -1.5000000000000024e-01
    w[7,12]   old_normalized_TC2  4.6368298368298371e+00
    w[7,13]   mass_7    1
    w[7,13]   w_lb_7_13  1
    w[7,13]   w_ub_7_13  1
    w[7,13]   normalized_inventory_7  -13
    w[7,13]   old_normalized_TC  -3.8333333333333369e-01
    w[7,13]   old_normalized_TC2  4.4034965034965037e+00
    w[7,14]   mass_7    1
    w[7,14]   w_lb_7_14  1
    w[7,14]   w_ub_7_14  1
    w[7,14]   normalized_inventory_7  -14
    w[7,14]   old_normalized_TC  -7.1969696969697006e-01
    w[7,14]   old_normalized_TC2  4.0671328671328668e+00
    w[7,15]   mass_7    1
    w[7,15]   w_lb_7_15  1
    w[7,15]   w_ub_7_15  1
    w[7,15]   normalized_inventory_7  -15
    w[7,15]   old_normalized_TC  -1.1651515151515155e+00
    w[7,15]   old_normalized_TC2  3.6216783216783215e+00
    w[7,16]   mass_7    1
    w[7,16]   w_lb_7_16  1
    w[7,16]   w_ub_7_16  1
    w[7,16]   normalized_inventory_7  -16
    w[7,16]   old_normalized_TC  -1.6651515151515155e+00
    w[7,16]   old_normalized_TC2  3.1216783216783215e+00
    w[7,17]   mass_7    1
    w[7,17]   w_lb_7_17  1
    w[7,17]   w_ub_7_17  1
    w[7,17]   normalized_inventory_7  -17
    w[7,17]   old_normalized_TC  -2.2651515151515156e+00
    w[7,17]   old_normalized_TC2  2.5216783216783214e+00
    w[7,18]   mass_7    1
    w[7,18]   w_lb_7_18  1
    w[7,18]   w_ub_7_18  1
    w[7,18]   normalized_inventory_7  -18
    w[7,18]   old_normalized_TC  -2.9378787878787884e+00
    w[7,18]   old_normalized_TC2  1.8489510489510486e+00
    w[7,19]   mass_7    1
    w[7,19]   w_lb_7_19  1
    w[7,19]   w_ub_7_19  1
    w[7,19]   normalized_inventory_7  -19
    w[7,19]   old_normalized_TC  -3.6628787878787885e+00
    w[7,19]   old_normalized_TC2  1.1239510489510482e+00
    w[7,20]   mass_7    1
    w[7,20]   w_lb_7_20  1
    w[7,20]   w_ub_7_20  1
    w[7,20]   normalized_inventory_7  -20
    w[7,20]   old_normalized_TC  -4.8763819513819522e+00
    w[7,20]   old_normalized_TC2  -8.9552114552115952e-02
    w[7,21]   mass_7    1
    w[7,21]   w_lb_7_21  1
    w[7,21]   w_ub_7_21  1
    w[7,21]   normalized_inventory_7  -21
    w[7,21]   old_normalized_TC  -6.2763819513819525e+00
    w[7,21]   old_normalized_TC2  -1.4895521145521160e+00
    w[7,22]   mass_7    1
    w[7,22]   w_lb_7_22  1
    w[7,22]   w_ub_7_22  1
    w[7,22]   normalized_inventory_7  -22
    w[7,22]   old_normalized_TC  -7.8198162948162961e+00
    w[7,22]   old_normalized_TC2  -3.0329864579864596e+00
    w[8,0]    mass_8    1
    w[8,0]    w_lb_8_0  1
    w[8,0]    w_ub_8_0  1
    w[8,1]    mass_8    1
    w[8,1]    w_lb_8_1  1
    w[8,1]    w_ub_8_1  1
    w[8,1]    normalized_inventory_8  -1
    w[8,1]    old_normalized_TC2  7.2727272727272729e-01
    w[8,2]    mass_8    1
    w[8,2]    w_lb_8_2  1
    w[8,2]    w_ub_8_2  1
    w[8,2]    normalized_inventory_8  -2
    w[8,2]    old_normalized_TC2  1.4545454545454546e+00
    w[8,3]    mass_8    1
    w[8,3]    w_lb_8_3  1
    w[8,3]    w_ub_8_3  1
    w[8,3]    normalized_inventory_8  -3
    w[8,3]    old_normalized_TC2  2.1090909090909093e+00
    w[8,4]    mass_8    1
    w[8,4]    w_lb_8_4  1
    w[8,4]    w_ub_8_4  1
    w[8,4]    normalized_inventory_8  -4
    w[8,4]    old_normalized_TC2  2.7454545454545456e+00
    w[8,5]    mass_8    1
    w[8,5]    w_lb_8_5  1
    w[8,5]    w_ub_8_5  1
    w[8,5]    normalized_inventory_8  -5
    w[8,5]    old_normalized_TC2  3.2909090909090910e+00
    w[8,6]    mass_8    1
    w[8,6]    w_lb_8_6  1
    w[8,6]    w_ub_8_6  1
    w[8,6]    normalized_inventory_8  -6
    w[8,6]    old_normalized_TC2  3.7524475524475527e+00
    w[8,7]    mass_8    1
    w[8,7]    w_lb_8_7  1
    w[8,7]    w_ub_8_7  1
    w[8,7]    normalized_inventory_8  -7
    w[8,7]    old_normalized_TC2  4.1539627039627041e+00
    w[8,8]    mass_8    1
    w[8,8]    w_lb_8_8  1
    w[8,8]    w_ub_8_8  1
    w[8,8]    normalized_inventory_8  -8
    w[8,8]    old_normalized_TC2  4.4569930069930077e+00
    w[8,9]    mass_8    1
    w[8,9]    w_lb_8_9  1
    w[8,9]    w_ub_8_9  1
    w[8,9]    normalized_inventory_8  -9
    w[8,9]    old_normalized_TC2  4.6807692307692310e+00
    w[8,10]   mass_8    1
    w[8,10]   w_lb_8_10  1
    w[8,10]   w_ub_8_10  1
    w[8,10]   normalized_inventory_8  -10
    w[8,10]   old_normalized_TC2  4.7868298368298374e+00
    w[8,11]   mass_8    1
    w[8,11]   w_lb_8_11  1
    w[8,11]   w_ub_8_11  1
    w[8,11]   normalized_inventory_8  -11
    w[8,11]   old_normalized_TC2  4.7868298368298374e+00
    w[8,12]   mass_8    1
    w[8,12]   w_lb_8_12  1
    w[8,12]   w_ub_8_12  1
    w[8,12]   normalized_inventory_8  -12
    w[8,12]   old_normalized_TC  -7.5757575757576662e-03
    w[8,12]   old_normalized_TC2  4.77925407925408
    w[8,13]   mass_8    1
    w[8,13]   w_lb_8_13  1
    w[8,13]   w_ub_8_13  1
    w[8,13]   normalized_inventory_8  -13
    w[8,13]   old_normalized_TC  -1.1363636363636383e-01
    w[8,13]   old_normalized_TC2  4.6731934731934732e+00
    w[8,14]   mass_8    1
    w[8,14]   w_lb_8_14  1
    w[8,14]   w_ub_8_14  1
    w[8,14]   normalized_inventory_8  -14
    w[8,14]   old_normalized_TC  -3.0151515151515174e-01
    w[8,14]   old_normalized_TC2  4.4853146853146857e+00
    w[8,15]   mass_8    1
    w[8,15]   w_lb_8_15  1
    w[8,15]   w_ub_8_15  1
    w[8,15]   normalized_inventory_8  -15
    w[8,15]   old_normalized_TC  -5.7424242424242444e-01
    w[8,15]   old_normalized_TC2  4.2125874125874132e+00
    w[8,16]   mass_8    1
    w[8,16]   w_lb_8_16  1
    w[8,16]   w_ub_8_16  1
    w[8,16]   normalized_inventory_8  -16
    w[8,16]   old_normalized_TC  -9.3787878787878809e-01
    w[8,16]   old_normalized_TC2  3.8489510489510490e+00
    w[8,17]   mass_8    1
    w[8,17]   w_lb_8_17  1
    w[8,17]   w_ub_8_17  1
    w[8,17]   normalized_inventory_8  -17
    w[8,17]   old_normalized_TC  -1.3924242424242426e+00
    w[8,17]   old_normalized_TC2  3.3944055944055944e+00
    w[8,18]   mass_8    1
    w[8,18]   w_lb_8_18  1
    w[8,18]   w_ub_8_18  1
    w[8,18]   normalized_inventory_8  -18
    w[8,18]   old_normalized_TC  -1.8833333333333335e+00
    w[8,18]   old_normalized_TC2  2.9034965034965037e+00
    w[8,19]   mass_8    1
    w[8,19]   w_lb_8_19  1
    w[8,19]   w_ub_8_19  1
    w[8,19]   normalized_inventory_8  -19
    w[8,19]   old_normalized_TC  -2.4287878787878787e+00
    w[8,19]   old_normalized_TC2  2.3580419580419578e+00
    w[8,20]   mass_8    1
    w[8,20]   w_lb_8_20  1
    w[8,20]   w_ub_8_20  1
    w[8,20]   normalized_inventory_8  -20
    w[8,20]   old_normalized_TC  -3.0651515151515154e+00
    w[8,20]   old_normalized_TC2  1.7216783216783216e+00
    w[8,21]   mass_8    1
    w[8,21]   w_lb_8_21  1
    w[8,21]   w_ub_8_21  1
    w[8,21]   normalized_inventory_8  -21
    w[8,21]   old_normalized_TC  -3.7356060606060608e+00
    w[8,21]   old_normalized_TC2  1.0512237762237759e+00
    w[9,0]    mass_9    1
    w[9,0]    w_lb_9_0  1
    w[9,0]    w_ub_9_0  1
    w[9,1]    mass_9    1
    w[9,1]    w_lb_9_1  1
    w[9,1]    w_ub_9_1  1
    w[9,1]    normalized_inventory_9  -1
    w[9,1]    old_normalized_TC2  8.8888888888888884e-01
    w[9,2]    mass_9    1
    w[9,2]    w_lb_9_2  1
    w[9,2]    w_ub_9_2  1
    w[9,2]    normalized_inventory_9  -2
    w[9,2]    old_normalized_TC2  1.7555555555555555e+00
    w[9,3]    mass_9    1
    w[9,3]    w_lb_9_3  1
    w[9,3]    w_ub_9_3  1
    w[9,3]    normalized_inventory_9  -3
    w[9,3]    old_normalized_TC2  2.5333333333333332e+00
    w[9,4]    mass_9    1
    w[9,4]    w_lb_9_4  1
    w[9,4]    w_ub_9_4  1
    w[9,4]    normalized_inventory_9  -4
    w[9,4]    old_normalized_TC2  3.2303030303030305e+00
    w[9,5]    mass_9    1
    w[9,5]    w_lb_9_5  1
    w[9,5]    w_ub_9_5  1
    w[9,5]    normalized_inventory_9  -5
    w[9,5]    old_normalized_TC2  3.8029526029526028e+00
    w[9,6]    mass_9    1
    w[9,6]    w_lb_9_6  1
    w[9,6]    w_ub_9_6  1
    w[9,6]    normalized_inventory_9  -6
    w[9,6]    old_normalized_TC2  4.2751748251748252e+00
    w[9,7]    mass_9    1
    w[9,7]    w_lb_9_7  1
    w[9,7]    w_ub_9_7  1
    w[9,7]    normalized_inventory_9  -7
    w[9,7]    old_normalized_TC2  4.5999611499611506e+00
    w[9,8]    mass_9    1
    w[9,8]    w_lb_9_8  1
    w[9,8]    w_ub_9_8  1
    w[9,8]    normalized_inventory_9  -8
    w[9,8]    old_normalized_TC2  4.7666278166278166e+00
    w[9,9]    mass_9    1
    w[9,9]    w_lb_9_9  1
    w[9,9]    w_ub_9_9  1
    w[9,9]    normalized_inventory_9  -9
    w[9,9]    old_normalized_TC2  4.7868298368298374e+00
    w[9,10]   mass_9    1
    w[9,10]   w_lb_9_10  1
    w[9,10]   w_ub_9_10  1
    w[9,10]   normalized_inventory_9  -10
    w[9,10]   old_normalized_TC  -2.7777777777777776e-02
    w[9,10]   old_normalized_TC2  4.75905205905206
    w[9,11]   mass_9    1
    w[9,11]   w_lb_9_11  1
    w[9,11]   w_ub_9_11  1
    w[9,11]   normalized_inventory_9  -11
    w[9,11]   old_normalized_TC  -1.9444444444444442e-01
    w[9,11]   old_normalized_TC2  4.5923853923853928e+00
    w[9,12]   mass_9    1
    w[9,12]   w_lb_9_12  1
    w[9,12]   w_ub_9_12  1
    w[9,12]   normalized_inventory_9  -12
    w[9,12]   old_normalized_TC  -4.8333333333333323e-01
    w[9,12]   old_normalized_TC2  4.3034965034965040e+00
    w[9,13]   mass_9    1
    w[9,13]   w_lb_9_13  1
    w[9,13]   w_ub_9_13  1
    w[9,13]   normalized_inventory_9  -13
    w[9,13]   old_normalized_TC  -8.9747474747474720e-01
    w[9,13]   old_normalized_TC2  3.8893550893550897e+00
    w[9,14]   mass_9    1
    w[9,14]   w_lb_9_14  1
    w[9,14]   w_ub_9_14  1
    w[9,14]   normalized_inventory_9  -14
    w[9,14]   old_normalized_TC  -1.4429292929292925e+00
    w[9,14]   old_normalized_TC2  3.3439005439005447e+00
    w[9,15]   mass_9    1
    w[9,15]   w_lb_9_15  1
    w[9,15]   w_ub_9_15  1
    w[9,15]   normalized_inventory_9  -15
    w[9,15]   old_normalized_TC  -2.0651515151515145e+00
    w[9,15]   old_normalized_TC2  2.7216783216783225e+00
    w[9,16]   mass_9    1
    w[9,16]   w_lb_9_16  1
    w[9,16]   w_ub_9_16  1
    w[9,16]   normalized_inventory_9  -16
    w[9,16]   old_normalized_TC  -2.7823232323232312e+00
    w[9,16]   old_normalized_TC2  2.0045066045066053e+00
    w[9,17]   mass_9    1
    w[9,17]   w_lb_9_17  1
    w[9,17]   w_ub_9_17  1
    w[9,17]   normalized_inventory_9  -17
    w[9,17]   old_normalized_TC  -3.5739898989898977e+00
    w[9,17]   old_normalized_TC2  1.2128399378399388e+00
    w[9,18]   mass_9    1
    w[9,18]   w_lb_9_18  1
    w[9,18]   w_ub_9_18  1
    w[9,18]   normalized_inventory_9  -18
    w[9,18]   old_normalized_TC  -4.8763819513819495e+00
    w[9,18]   old_normalized_TC2  -8.9552114552113010e-02
    w[9,19]   mass_9    1
    w[9,19]   w_lb_9_19  1
    w[9,19]   w_ub_9_19  1
    w[9,19]   normalized_inventory_9  -19
    w[9,19]   old_normalized_TC  -6.4319375069375049e+00
    w[9,19]   old_normalized_TC2  -1.6451076701076681e+00
    w[10,0]   mass_10   1
    w[10,0]   w_lb_10_0  1
    w[10,0]   w_ub_10_0  1
    w[10,1]   mass_10   1
    w[10,1]   w_lb_10_1  1
    w[10,1]   w_ub_10_1  1
    w[10,1]   normalized_inventory_10  -1
    w[10,1]   old_normalized_TC2  0.5
    w[10,2]   mass_10   1
    w[10,2]   w_lb_10_2  1
    w[10,2]   w_ub_10_2  1
    w[10,2]   normalized_inventory_10  -2
    w[10,2]   old_normalized_TC2  1
    w[10,3]   mass_10   1
    w[10,3]   w_lb_10_3  1
    w[10,3]   w_ub_10_3  1
    w[10,3]   normalized_inventory_10  -3
    w[10,3]   old_normalized_TC2  1.5
    w[10,4]   mass_10   1
    w[10,4]   w_lb_10_4  1
    w[10,4]   w_ub_10_4  1
    w[10,4]   normalized_inventory_10  -4
    w[10,4]   old_normalized_TC2  1.9500000000000002e+00
    w[10,5]   mass_10   1
    w[10,5]   w_lb_10_5  1
    w[10,5]   w_ub_10_5  1
    w[10,5]   normalized_inventory_10  -5
    w[10,5]   old_normalized_TC2  2.3875
    w[10,6]   mass_10   1
    w[10,6]   w_lb_10_6  1
    w[10,6]   w_ub_10_6  1
    w[10,6]   normalized_inventory_10  -6
    w[10,6]   old_normalized_TC2  2.8136363636363639e+00
    w[10,7]   mass_10   1
    w[10,7]   w_lb_10_7  1
    w[10,7]   w_ub_10_7  1
    w[10,7]   normalized_inventory_10  -7
    w[10,7]   old_normalized_TC2  3.1886363636363639e+00
    w[10,8]   mass_10   1
    w[10,8]   w_lb_10_8  1
    w[10,8]   w_ub_10_8  1
    w[10,8]   normalized_inventory_10  -8
    w[10,8]   old_normalized_TC2  3.5251748251748256e+00
    w[10,9]   mass_10   1
    w[10,9]   w_lb_10_9  1
    w[10,9]   w_ub_10_9  1
    w[10,9]   normalized_inventory_10  -9
    w[10,9]   old_normalized_TC2  3.8376748251748256e+00
    w[10,10]  mass_10   1
    w[10,10]  w_lb_10_10  1
    w[10,10]  w_ub_10_10  1
    w[10,10]  normalized_inventory_10  -10
    w[10,10]  old_normalized_TC2  4.1085081585081591e+00
    w[10,11]  mass_10   1
    w[10,11]  w_lb_10_11  1
    w[10,11]  w_ub_10_11  1
    w[10,11]  normalized_inventory_10  -11
    w[10,11]  old_normalized_TC2  4.3376748251748261e+00
    w[10,12]  mass_10   1
    w[10,12]  w_lb_10_12  1
    w[10,12]  w_ub_10_12  1
    w[10,12]  normalized_inventory_10  -12
    w[10,12]  old_normalized_TC2  4.5251748251748261e+00
    w[10,13]  mass_10   1
    w[10,13]  w_lb_10_13  1
    w[10,13]  w_ub_10_13  1
    w[10,13]  normalized_inventory_10  -13
    w[10,13]  old_normalized_TC2  4.6694055944055952e+00
    w[10,14]  mass_10   1
    w[10,14]  w_lb_10_14  1
    w[10,14]  w_ub_10_14  1
    w[10,14]  normalized_inventory_10  -14
    w[10,14]  old_normalized_TC2  4.7527389277389283e+00
    w[10,15]  mass_10   1
    w[10,15]  w_lb_10_15  1
    w[10,15]  w_ub_10_15  1
    w[10,15]  normalized_inventory_10  -15
    w[10,15]  old_normalized_TC2  4.7868298368298374e+00
    w[10,16]  mass_10   1
    w[10,16]  w_lb_10_16  1
    w[10,16]  w_ub_10_16  1
    w[10,16]  normalized_inventory_10  -16
    w[10,16]  old_normalized_TC2  4.7868298368298374e+00
    w[10,17]  mass_10   1
    w[10,17]  w_lb_10_17  1
    w[10,17]  w_ub_10_17  1
    w[10,17]  normalized_inventory_10  -17
    w[10,17]  old_normalized_TC2  4.7868298368298374e+00
    w[10,18]  mass_10   1
    w[10,18]  w_lb_10_18  1
    w[10,18]  w_ub_10_18  1
    w[10,18]  normalized_inventory_10  -18
    w[10,18]  old_normalized_TC  -4.1666666666666727e-02
    w[10,18]  old_normalized_TC2  4.7451631701631705e+00
    w[10,19]  mass_10   1
    w[10,19]  w_lb_10_19  1
    w[10,19]  w_ub_10_19  1
    w[10,19]  normalized_inventory_10  -19
    w[10,19]  old_normalized_TC  -1.2500000000000011e-01
    w[10,19]  old_normalized_TC2  4.6618298368298374e+00
    w[10,20]  mass_10   1
    w[10,20]  w_lb_10_20  1
    w[10,20]  w_ub_10_20  1
    w[10,20]  normalized_inventory_10  -20
    w[10,20]  old_normalized_TC  -2.5000000000000011e-01
    w[10,20]  old_normalized_TC2  4.5368298368298374e+00
    w[10,21]  mass_10   1
    w[10,21]  w_lb_10_21  1
    w[10,21]  w_ub_10_21  1
    w[10,21]  normalized_inventory_10  -21
    w[10,21]  old_normalized_TC  -4.2083333333333345e-01
    w[10,21]  old_normalized_TC2  4.3659965034965040e+00
    w[10,22]  mass_10   1
    w[10,22]  w_lb_10_22  1
    w[10,22]  w_ub_10_22  1
    w[10,22]  normalized_inventory_10  -22
    w[10,22]  old_normalized_TC  -6.1969696969696975e-01
    w[10,22]  old_normalized_TC2  4.1671328671328673e+00
    w[10,23]  mass_10   1
    w[10,23]  w_lb_10_23  1
    w[10,23]  w_ub_10_23  1
    w[10,23]  normalized_inventory_10  -23
    w[10,23]  old_normalized_TC  -8.6969696969696975e-01
    w[10,23]  old_normalized_TC2  3.9171328671328673e+00
    w[10,24]  mass_10   1
    w[10,24]  w_lb_10_24  1
    w[10,24]  w_ub_10_24  1
    w[10,24]  normalized_inventory_10  -24
    w[10,24]  old_normalized_TC  -1.1651515151515150e+00
    w[10,24]  old_normalized_TC2  3.6216783216783219e+00
    w[10,25]  mass_10   1
    w[10,25]  w_lb_10_25  1
    w[10,25]  w_ub_10_25  1
    w[10,25]  normalized_inventory_10  -25
    w[10,25]  old_normalized_TC  -1.4776515151515150e+00
    w[10,25]  old_normalized_TC2  3.3091783216783219e+00
    w[10,26]  mass_10   1
    w[10,26]  w_lb_10_26  1
    w[10,26]  w_ub_10_26  1
    w[10,26]  normalized_inventory_10  -26
    w[10,26]  old_normalized_TC  -1.8151515151515150e+00
    w[10,26]  old_normalized_TC2  2.9716783216783220e+00
    w[10,27]  mass_10   1
    w[10,27]  w_lb_10_27  1
    w[10,27]  w_ub_10_27  1
    w[10,27]  normalized_inventory_10  -27
    w[10,27]  old_normalized_TC  -2.1901515151515150e+00
    w[10,27]  old_normalized_TC2  2.5966783216783220e+00
    w[10,28]  mass_10   1
    w[10,28]  w_lb_10_28  1
    w[10,28]  w_ub_10_28  1
    w[10,28]  normalized_inventory_10  -28
    w[10,28]  old_normalized_TC  -2.5878787878787874e+00
    w[10,28]  old_normalized_TC2  2.1989510489510491e+00
    w[10,29]  mass_10   1
    w[10,29]  w_lb_10_29  1
    w[10,29]  w_ub_10_29  1
    w[10,29]  normalized_inventory_10  -29
    w[10,29]  old_normalized_TC  -3.0253787878787874e+00
    w[10,29]  old_normalized_TC2  1.7614510489510491e+00
    w[11,0]   mass_11   1
    w[11,0]   w_lb_11_0  1
    w[11,0]   w_ub_11_0  1
    w[11,1]   mass_11   1
    w[11,1]   w_lb_11_1  1
    w[11,1]   w_ub_11_1  1
    w[11,1]   normalized_inventory_11  -1
    w[11,1]   old_normalized_TC2  4.7058823529411764e-01
    w[11,2]   mass_11   1
    w[11,2]   w_lb_11_2  1
    w[11,2]   w_ub_11_2  1
    w[11,2]   normalized_inventory_11  -2
    w[11,2]   old_normalized_TC2  9.4117647058823528e-01
    w[11,3]   mass_11   1
    w[11,3]   w_lb_11_3  1
    w[11,3]   w_ub_11_3  1
    w[11,3]   normalized_inventory_11  -3
    w[11,3]   old_normalized_TC2  1.4117647058823530e+00
    w[11,4]   mass_11   1
    w[11,4]   w_lb_11_4  1
    w[11,4]   w_ub_11_4  1
    w[11,4]   normalized_inventory_11  -4
    w[11,4]   old_normalized_TC2  1.8470588235294119e+00
    w[11,5]   mass_11   1
    w[11,5]   w_lb_11_5  1
    w[11,5]   w_ub_11_5  1
    w[11,5]   normalized_inventory_11  -5
    w[11,5]   old_normalized_TC2  2.2588235294117651e+00
    w[11,6]   mass_11   1
    w[11,6]   w_lb_11_6  1
    w[11,6]   w_ub_11_6  1
    w[11,6]   normalized_inventory_11  -6
    w[11,6]   old_normalized_TC2  2.6705882352941179e+00
    w[11,7]   mass_11   1
    w[11,7]   w_lb_11_7  1
    w[11,7]   w_ub_11_7  1
    w[11,7]   normalized_inventory_11  -7
    w[11,7]   old_normalized_TC2  3.0342245989304817e+00
    w[11,8]   mass_11   1
    w[11,8]   w_lb_11_8  1
    w[11,8]   w_ub_11_8  1
    w[11,8]   normalized_inventory_11  -8
    w[11,8]   old_normalized_TC2  3.3781160016454135e+00
    w[11,9]   mass_11   1
    w[11,9]   w_lb_11_9  1
    w[11,9]   w_ub_11_9  1
    w[11,9]   normalized_inventory_11  -9
    w[11,9]   old_normalized_TC2  3.6722336487042373e+00
    w[11,10]  mass_11   1
    w[11,10]  w_lb_11_10  1
    w[11,10]  w_ub_11_10  1
    w[11,10]  normalized_inventory_11  -10
    w[11,10]  old_normalized_TC2  3.9614493349787470e+00
    w[11,11]  mass_11   1
    w[11,11]  w_lb_11_11  1
    w[11,11]  w_ub_11_11  1
    w[11,11]  normalized_inventory_11  -11
    w[11,11]  old_normalized_TC2  4.1967434526258058e+00
    w[11,12]  mass_11   1
    w[11,12]  w_lb_11_12  1
    w[11,12]  w_ub_11_12  1
    w[11,12]  normalized_inventory_11  -12
    w[11,12]  old_normalized_TC2  4.3928218839983550e+00
    w[11,13]  mass_11   1
    w[11,13]  w_lb_11_13  1
    w[11,13]  w_ub_11_13  1
    w[11,13]  normalized_inventory_11  -13
    w[11,13]  old_normalized_TC2  4.5692924722336494e+00
    w[11,14]  mass_11   1
    w[11,14]  w_lb_11_14  1
    w[11,14]  w_ub_11_14  1
    w[11,14]  normalized_inventory_11  -14
    w[11,14]  old_normalized_TC2  4.6914644179350065e+00
    w[11,15]  mass_11   1
    w[11,15]  w_lb_11_15  1
    w[11,15]  w_ub_11_15  1
    w[11,15]  normalized_inventory_11  -15
    w[11,15]  old_normalized_TC2  4.7600918689153984e+00
    w[11,16]  mass_11   1
    w[11,16]  w_lb_11_16  1
    w[11,16]  w_ub_11_16  1
    w[11,16]  normalized_inventory_11  -16
    w[11,16]  old_normalized_TC2  4.7868298368298374e+00
    w[11,17]  mass_11   1
    w[11,17]  w_lb_11_17  1
    w[11,17]  w_ub_11_17  1
    w[11,17]  normalized_inventory_11  -17
    w[11,17]  old_normalized_TC2  4.7868298368298374e+00
    w[11,18]  mass_11   1
    w[11,18]  w_lb_11_18  1
    w[11,18]  w_ub_11_18  1
    w[11,18]  normalized_inventory_11  -18
    w[11,18]  old_normalized_TC2  4.7868298368298374e+00
    w[11,19]  mass_11   1
    w[11,19]  w_lb_11_19  1
    w[11,19]  w_ub_11_19  1
    w[11,19]  normalized_inventory_11  -19
    w[11,19]  old_normalized_TC  -3.4313725490196123e-02
    w[11,19]  old_normalized_TC2  4.7525161113396415e+00
    w[11,20]  mass_11   1
    w[11,20]  w_lb_11_20  1
    w[11,20]  w_ub_11_20  1
    w[11,20]  normalized_inventory_11  -20
    w[11,20]  old_normalized_TC  -1.0294117647058833e-01
    w[11,20]  old_normalized_TC2  4.6838886603592487e+00
    w[11,21]  mass_11   1
    w[11,21]  w_lb_11_21  1
    w[11,21]  w_ub_11_21  1
    w[11,21]  normalized_inventory_11  -21
    w[11,21]  old_normalized_TC  -2.2058823529411772e-01
    w[11,21]  old_normalized_TC2  4.56624160153572
    w[11,22]  mass_11   1
    w[11,22]  w_lb_11_22  1
    w[11,22]  w_ub_11_22  1
    w[11,22]  normalized_inventory_11  -22
    w[11,22]  old_normalized_TC  -0.365686274509804
    w[11,22]  old_normalized_TC2  4.4211435623200330e+00
    w[11,23]  mass_11   1
    w[11,23]  w_lb_11_23  1
    w[11,23]  w_ub_11_23  1
    w[11,23]  normalized_inventory_11  -23
    w[11,23]  old_normalized_TC  -5.4215686274509811e-01
    w[11,23]  old_normalized_TC2  4.2446729740847395e+00
    w[11,24]  mass_11   1
    w[11,24]  w_lb_11_24  1
    w[11,24]  w_ub_11_24  1
    w[11,24]  normalized_inventory_11  -24
    w[11,24]  old_normalized_TC  -7.6675579322638143e-01
    w[11,24]  old_normalized_TC2  4.0200740436034561e+00
    w[11,25]  mass_11   1
    w[11,25]  w_lb_11_25  1
    w[11,25]  w_ub_11_25  1
    w[11,25]  normalized_inventory_11  -25
    w[11,25]  old_normalized_TC  -1.0180926916221031e+00
    w[11,25]  old_normalized_TC2  3.7687371452077336e+00
    w[11,26]  mass_11   1
    w[11,26]  w_lb_11_26  1
    w[11,26]  w_ub_11_26  1
    w[11,26]  normalized_inventory_11  -26
    w[11,26]  old_normalized_TC  -1.3122103386809267e+00
    w[11,26]  old_normalized_TC2  3.4746194981489102e+00
    w[11,27]  mass_11   1
    w[11,27]  w_lb_11_27  1
    w[11,27]  w_ub_11_27  1
    w[11,27]  normalized_inventory_11  -27
    w[11,27]  old_normalized_TC  -1.6063279857397503e+00
    w[11,27]  old_normalized_TC2  3.1805018510900869e+00
    w[11,28]  mass_11   1
    w[11,28]  w_lb_11_28  1
    w[11,28]  w_ub_11_28  1
    w[11,28]  normalized_inventory_11  -28
    w[11,28]  old_normalized_TC  -1.9475044563279855e+00
    w[11,28]  old_normalized_TC2  2.8393253805018515e+00
    w[11,29]  mass_11   1
    w[11,29]  w_lb_11_29  1
    w[11,29]  w_ub_11_29  1
    w[11,29]  normalized_inventory_11  -29
    w[11,29]  old_normalized_TC  -2.3004456327985734e+00
    w[11,29]  old_normalized_TC2  2.4863842040312631e+00
    w[11,30]  mass_11   1
    w[11,30]  w_lb_11_30  1
    w[11,30]  w_ub_11_30  1
    w[11,30]  normalized_inventory_11  -30
    w[11,30]  old_normalized_TC  -2.6908199643493758e+00
    w[11,30]  old_normalized_TC2  2.0960098724804612e+00
    w[11,31]  mass_11   1
    w[11,31]  w_lb_11_31  1
    w[11,31]  w_ub_11_31  1
    w[11,31]  normalized_inventory_11  -31
    w[11,31]  old_normalized_TC  -3.1025846702317286e+00
    w[11,31]  old_normalized_TC2  1.6842451665981082e+00
    w[12,0]   mass_12   1
    w[12,0]   w_lb_12_0  1
    w[12,0]   w_ub_12_0  1
    w[12,1]   mass_12   1
    w[12,1]   w_lb_12_1  1
    w[12,1]   w_ub_12_1  1
    w[12,1]   normalized_inventory_12  -1
    w[12,1]   old_normalized_TC2  0.8
    w[12,2]   mass_12   1
    w[12,2]   w_lb_12_2  1
    w[12,2]   w_ub_12_2  1
    w[12,2]   normalized_inventory_12  -2
    w[12,2]   old_normalized_TC2  1.6
    w[12,3]   mass_12   1
    w[12,3]   w_lb_12_3  1
    w[12,3]   w_ub_12_3  1
    w[12,3]   normalized_inventory_12  -3
    w[12,3]   old_normalized_TC2  2.3000000000000003e+00
    w[12,4]   mass_12   1
    w[12,4]   w_lb_12_4  1
    w[12,4]   w_ub_12_4  1
    w[12,4]   normalized_inventory_12  -4
    w[12,4]   old_normalized_TC2  2.9636363636363638e+00
    w[12,5]   mass_12   1
    w[12,5]   w_lb_12_5  1
    w[12,5]   w_ub_12_5  1
    w[12,5]   normalized_inventory_12  -5
    w[12,5]   old_normalized_TC2  3.5251748251748256e+00
    w[12,6]   mass_12   1
    w[12,6]   w_lb_12_6  1
    w[12,6]   w_ub_12_6  1
    w[12,6]   normalized_inventory_12  -6
    w[12,6]   old_normalized_TC2  4.0085081585081594e+00
    w[12,7]   mass_12   1
    w[12,7]   w_lb_12_7  1
    w[12,7]   w_ub_12_7  1
    w[12,7]   normalized_inventory_12  -7
    w[12,7]   old_normalized_TC2  4.3751748251748257e+00
    w[12,8]   mass_12   1
    w[12,8]   w_lb_12_8  1
    w[12,8]   w_ub_12_8  1
    w[12,8]   normalized_inventory_12  -8
    w[12,8]   old_normalized_TC2  4.6444055944055949e+00
    w[12,9]   mass_12   1
    w[12,9]   w_lb_12_9  1
    w[12,9]   w_ub_12_9  1
    w[12,9]   normalized_inventory_12  -9
    w[12,9]   old_normalized_TC2  4.7777389277389286e+00
    w[12,10]  mass_12   1
    w[12,10]  w_lb_12_10  1
    w[12,10]  w_ub_12_10  1
    w[12,10]  normalized_inventory_12  -10
    w[12,10]  old_normalized_TC2  4.7868298368298374e+00
    w[12,11]  mass_12   1
    w[12,11]  w_lb_12_11  1
    w[12,11]  w_ub_12_11  1
    w[12,11]  normalized_inventory_12  -11
    w[12,11]  old_normalized_TC  -1.6666666666666788e-02
    w[12,11]  old_normalized_TC2  4.7701631701631708e+00
    w[12,12]  mass_12   1
    w[12,12]  w_lb_12_12  1
    w[12,12]  w_ub_12_12  1
    w[12,12]  normalized_inventory_12  -12
    w[12,12]  old_normalized_TC  -1.5000000000000024e-01
    w[12,12]  old_normalized_TC2  4.6368298368298371e+00
    w[12,13]  mass_12   1
    w[12,13]  w_lb_12_13  1
    w[12,13]  w_ub_12_13  1
    w[12,13]  normalized_inventory_12  -13
    w[12,13]  old_normalized_TC  -3.8333333333333369e-01
    w[12,13]  old_normalized_TC2  4.4034965034965037e+00
    w[12,14]  mass_12   1
    w[12,14]  w_lb_12_14  1
    w[12,14]  w_ub_12_14  1
    w[12,14]  normalized_inventory_12  -14
    w[12,14]  old_normalized_TC  -7.1969696969697006e-01
    w[12,14]  old_normalized_TC2  4.0671328671328668e+00
    w[12,15]  mass_12   1
    w[12,15]  w_lb_12_15  1
    w[12,15]  w_ub_12_15  1
    w[12,15]  normalized_inventory_12  -15
    w[12,15]  old_normalized_TC  -1.1651515151515155e+00
    w[12,15]  old_normalized_TC2  3.6216783216783215e+00
    w[12,16]  mass_12   1
    w[12,16]  w_lb_12_16  1
    w[12,16]  w_ub_12_16  1
    w[12,16]  normalized_inventory_12  -16
    w[12,16]  old_normalized_TC  -1.6651515151515155e+00
    w[12,16]  old_normalized_TC2  3.1216783216783215e+00
    w[12,17]  mass_12   1
    w[12,17]  w_lb_12_17  1
    w[12,17]  w_ub_12_17  1
    w[12,17]  normalized_inventory_12  -17
    w[12,17]  old_normalized_TC  -2.2651515151515156e+00
    w[12,17]  old_normalized_TC2  2.5216783216783214e+00
    w[12,18]  mass_12   1
    w[12,18]  w_lb_12_18  1
    w[12,18]  w_ub_12_18  1
    w[12,18]  normalized_inventory_12  -18
    w[12,18]  old_normalized_TC  -2.9378787878787884e+00
    w[12,18]  old_normalized_TC2  1.8489510489510486e+00
    w[12,19]  mass_12   1
    w[12,19]  w_lb_12_19  1
    w[12,19]  w_ub_12_19  1
    w[12,19]  normalized_inventory_12  -19
    w[12,19]  old_normalized_TC  -3.6628787878787885e+00
    w[12,19]  old_normalized_TC2  1.1239510489510482e+00
    w[13,0]   mass_13   1
    w[13,0]   w_lb_13_0  1
    w[13,0]   w_ub_13_0  1
    w[13,1]   mass_13   1
    w[13,1]   w_lb_13_1  1
    w[13,1]   w_ub_13_1  1
    w[13,1]   normalized_inventory_13  -1
    w[13,1]   old_normalized_TC2  6.1538461538461542e-01
    w[13,2]   mass_13   1
    w[13,2]   w_lb_13_2  1
    w[13,2]   w_ub_13_2  1
    w[13,2]   normalized_inventory_13  -2
    w[13,2]   old_normalized_TC2  1.2307692307692308e+00
    w[13,3]   mass_13   1
    w[13,3]   w_lb_13_3  1
    w[13,3]   w_ub_13_3  1
    w[13,3]   normalized_inventory_13  -3
    w[13,3]   old_normalized_TC2  1.8153846153846156e+00
    w[13,4]   mass_13   1
    w[13,4]   w_lb_13_4  1
    w[13,4]   w_ub_13_4  1
    w[13,4]   normalized_inventory_13  -4
    w[13,4]   old_normalized_TC2  2.3538461538461544e+00
    w[13,5]   mass_13   1
    w[13,5]   w_lb_13_5  1
    w[13,5]   w_ub_13_5  1
    w[13,5]   normalized_inventory_13  -5
    w[13,5]   old_normalized_TC2  2.8713286713286719e+00
    w[13,6]   mass_13   1
    w[13,6]   w_lb_13_6  1
    w[13,6]   w_ub_13_6  1
    w[13,6]   normalized_inventory_13  -6
    w[13,6]   old_normalized_TC2  3.3328671328671331e+00
    w[13,7]   mass_13   1
    w[13,7]   w_lb_13_7  1
    w[13,7]   w_ub_13_7  1
    w[13,7]   normalized_inventory_13  -7
    w[13,7]   old_normalized_TC2  3.7174825174825177e+00
    w[13,8]   mass_13   1
    w[13,8]   w_lb_13_8  1
    w[13,8]   w_ub_13_8  1
    w[13,8]   normalized_inventory_13  -8
    w[13,8]   old_normalized_TC2  4.0700466200466208e+00
    w[13,9]   mass_13   1
    w[13,9]   w_lb_13_9  1
    w[13,9]   w_ub_13_9  1
    w[13,9]   normalized_inventory_13  -9
    w[13,9]   old_normalized_TC2  4.3520979020979027e+00
    w[13,10]  mass_13   1
    w[13,10]  w_lb_13_10  1
    w[13,10]  w_ub_13_10  1
    w[13,10]  normalized_inventory_13  -10
    w[13,10]  old_normalized_TC2  4.5828671328671335e+00
    w[13,11]  mass_13   1
    w[13,11]  w_lb_13_11  1
    w[13,11]  w_ub_13_11  1
    w[13,11]  normalized_inventory_13  -11
    w[13,11]  old_normalized_TC2  4.7238927738927741e+00
    w[13,12]  mass_13   1
    w[13,12]  w_lb_13_12  1
    w[13,12]  w_ub_13_12  1
    w[13,12]  normalized_inventory_13  -12
    w[13,12]  old_normalized_TC2  4.7868298368298374e+00
    w[13,13]  mass_13   1
    w[13,13]  w_lb_13_13  1
    w[13,13]  w_ub_13_13  1
    w[13,13]  normalized_inventory_13  -13
    w[13,13]  old_normalized_TC2  4.7868298368298374e+00
    w[13,14]  mass_13   1
    w[13,14]  w_lb_13_14  1
    w[13,14]  w_ub_13_14  1
    w[13,14]  normalized_inventory_13  -14
    w[13,14]  old_normalized_TC2  4.7868298368298374e+00
    w[13,15]  mass_13   1
    w[13,15]  w_lb_13_15  1
    w[13,15]  w_ub_13_15  1
    w[13,15]  normalized_inventory_13  -15
    w[13,15]  old_normalized_TC  -7.0512820512820637e-02
    w[13,15]  old_normalized_TC2  4.7163170163170163e+00
    w[13,16]  mass_13   1
    w[13,16]  w_lb_13_16  1
    w[13,16]  w_ub_13_16  1
    w[13,16]  normalized_inventory_13  -16
    w[13,16]  old_normalized_TC  -2.1153846153846179e-01
    w[13,16]  old_normalized_TC2  4.5752913752913758e+00
    w[13,17]  mass_13   1
    w[13,17]  w_lb_13_17  1
    w[13,17]  w_ub_13_17  1
    w[13,17]  normalized_inventory_13  -17
    w[13,17]  old_normalized_TC  -4.0641025641025674e-01
    w[13,17]  old_normalized_TC2  4.3804195804195807e+00
    w[13,18]  mass_13   1
    w[13,18]  w_lb_13_18  1
    w[13,18]  w_ub_13_18  1
    w[13,18]  normalized_inventory_13  -18
    w[13,18]  old_normalized_TC  -6.5815850815850852e-01
    w[13,18]  old_normalized_TC2  4.1286713286713290e+00
    w[13,19]  mass_13   1
    w[13,19]  w_lb_13_19  1
    w[13,19]  w_ub_13_19  1
    w[13,19]  normalized_inventory_13  -19
    w[13,19]  old_normalized_TC  -9.7284382284382331e-01
    w[13,19]  old_normalized_TC2  3.8139860139860136e+00
    w[13,20]  mass_13   1
    w[13,20]  w_lb_13_20  1
    w[13,20]  w_ub_13_20  1
    w[13,20]  normalized_inventory_13  -20
    w[13,20]  old_normalized_TC  -1.3574592074592078e+00
    w[13,20]  old_normalized_TC2  3.4293706293706290e+00
    w[13,21]  mass_13   1
    w[13,21]  w_lb_13_21  1
    w[13,21]  w_ub_13_21  1
    w[13,21]  normalized_inventory_13  -21
    w[13,21]  old_normalized_TC  -1.7574592074592079e+00
    w[13,21]  old_normalized_TC2  3.0293706293706291e+00
    w[13,22]  mass_13   1
    w[13,22]  w_lb_13_22  1
    w[13,22]  w_ub_13_22  1
    w[13,22]  normalized_inventory_13  -22
    w[13,22]  old_normalized_TC  -2.2189976689976691e+00
    w[13,22]  old_normalized_TC2  2.5678321678321674e+00
    w[13,23]  mass_13   1
    w[13,23]  w_lb_13_23  1
    w[13,23]  w_ub_13_23  1
    w[13,23]  normalized_inventory_13  -23
    w[13,23]  old_normalized_TC  -2.7224941724941729e+00
    w[13,23]  old_normalized_TC2  2.0643356643356641e+00
    w[13,24]  mass_13   1
    w[13,24]  w_lb_13_24  1
    w[13,24]  w_ub_13_24  1
    w[13,24]  normalized_inventory_13  -24
    w[13,24]  old_normalized_TC  -3.2609557109557112e+00
    w[13,24]  old_normalized_TC2  1.5258741258741253e+00
    w[13,25]  mass_13   1
    w[13,25]  w_lb_13_25  1
    w[13,25]  w_ub_13_25  1
    w[13,25]  normalized_inventory_13  -25
    w[13,25]  old_normalized_TC  -3.8818764568764577e+00
    w[13,25]  old_normalized_TC2  9.0495337995337888e-01
    w[14,0]   mass_14   1
    w[14,0]   w_lb_14_0  1
    w[14,0]   w_ub_14_0  1
    w[14,1]   mass_14   1
    w[14,1]   w_lb_14_1  1
    w[14,1]   w_ub_14_1  1
    w[14,1]   normalized_inventory_14  -1
    w[14,1]   old_normalized_TC2  6.1538461538461542e-01
    w[14,2]   mass_14   1
    w[14,2]   w_lb_14_2  1
    w[14,2]   w_ub_14_2  1
    w[14,2]   normalized_inventory_14  -2
    w[14,2]   old_normalized_TC2  1.2307692307692308e+00
    w[14,3]   mass_14   1
    w[14,3]   w_lb_14_3  1
    w[14,3]   w_ub_14_3  1
    w[14,3]   normalized_inventory_14  -3
    w[14,3]   old_normalized_TC2  1.8153846153846156e+00
    w[14,4]   mass_14   1
    w[14,4]   w_lb_14_4  1
    w[14,4]   w_ub_14_4  1
    w[14,4]   normalized_inventory_14  -4
    w[14,4]   old_normalized_TC2  2.3538461538461544e+00
    w[14,5]   mass_14   1
    w[14,5]   w_lb_14_5  1
    w[14,5]   w_ub_14_5  1
    w[14,5]   normalized_inventory_14  -5
    w[14,5]   old_normalized_TC2  2.8713286713286719e+00
    w[14,6]   mass_14   1
    w[14,6]   w_lb_14_6  1
    w[14,6]   w_ub_14_6  1
    w[14,6]   normalized_inventory_14  -6
    w[14,6]   old_normalized_TC2  3.3328671328671331e+00
    w[14,7]   mass_14   1
    w[14,7]   w_lb_14_7  1
    w[14,7]   w_ub_14_7  1
    w[14,7]   normalized_inventory_14  -7
    w[14,7]   old_normalized_TC2  3.7174825174825177e+00
    w[14,8]   mass_14   1
    w[14,8]   w_lb_14_8  1
    w[14,8]   w_ub_14_8  1
    w[14,8]   normalized_inventory_14  -8
    w[14,8]   old_normalized_TC2  4.0700466200466208e+00
    w[14,9]   mass_14   1
    w[14,9]   w_lb_14_9  1
    w[14,9]   w_ub_14_9  1
    w[14,9]   normalized_inventory_14  -9
    w[14,9]   old_normalized_TC2  4.3520979020979027e+00
    w[14,10]  mass_14   1
    w[14,10]  w_lb_14_10  1
    w[14,10]  w_ub_14_10  1
    w[14,10]  normalized_inventory_14  -10
    w[14,10]  old_normalized_TC2  4.5828671328671335e+00
    w[14,11]  mass_14   1
    w[14,11]  w_lb_14_11  1
    w[14,11]  w_ub_14_11  1
    w[14,11]  normalized_inventory_14  -11
    w[14,11]  old_normalized_TC2  4.7238927738927741e+00
    w[14,12]  mass_14   1
    w[14,12]  w_lb_14_12  1
    w[14,12]  w_ub_14_12  1
    w[14,12]  normalized_inventory_14  -12
    w[14,12]  old_normalized_TC2  4.7868298368298374e+00
    w[14,13]  mass_14   1
    w[14,13]  w_lb_14_13  1
    w[14,13]  w_ub_14_13  1
    w[14,13]  normalized_inventory_14  -13
    w[14,13]  old_normalized_TC2  4.7868298368298374e+00
    w[14,14]  mass_14   1
    w[14,14]  w_lb_14_14  1
    w[14,14]  w_ub_14_14  1
    w[14,14]  normalized_inventory_14  -14
    w[14,14]  old_normalized_TC2  4.7868298368298374e+00
    w[14,15]  mass_14   1
    w[14,15]  w_lb_14_15  1
    w[14,15]  w_ub_14_15  1
    w[14,15]  normalized_inventory_14  -15
    w[14,15]  old_normalized_TC  -7.0512820512820637e-02
    w[14,15]  old_normalized_TC2  4.7163170163170163e+00
    w[14,16]  mass_14   1
    w[14,16]  w_lb_14_16  1
    w[14,16]  w_ub_14_16  1
    w[14,16]  normalized_inventory_14  -16
    w[14,16]  old_normalized_TC  -2.1153846153846179e-01
    w[14,16]  old_normalized_TC2  4.5752913752913758e+00
    w[14,17]  mass_14   1
    w[14,17]  w_lb_14_17  1
    w[14,17]  w_ub_14_17  1
    w[14,17]  normalized_inventory_14  -17
    w[14,17]  old_normalized_TC  -4.0641025641025674e-01
    w[14,17]  old_normalized_TC2  4.3804195804195807e+00
    w[14,18]  mass_14   1
    w[14,18]  w_lb_14_18  1
    w[14,18]  w_ub_14_18  1
    w[14,18]  normalized_inventory_14  -18
    w[14,18]  old_normalized_TC  -6.5815850815850852e-01
    w[14,18]  old_normalized_TC2  4.1286713286713290e+00
    w[14,19]  mass_14   1
    w[14,19]  w_lb_14_19  1
    w[14,19]  w_ub_14_19  1
    w[14,19]  normalized_inventory_14  -19
    w[14,19]  old_normalized_TC  -9.7284382284382331e-01
    w[14,19]  old_normalized_TC2  3.8139860139860136e+00
    w[14,20]  mass_14   1
    w[14,20]  w_lb_14_20  1
    w[14,20]  w_ub_14_20  1
    w[14,20]  normalized_inventory_14  -20
    w[14,20]  old_normalized_TC  -1.3574592074592078e+00
    w[14,20]  old_normalized_TC2  3.4293706293706290e+00
    w[14,21]  mass_14   1
    w[14,21]  w_lb_14_21  1
    w[14,21]  w_ub_14_21  1
    w[14,21]  normalized_inventory_14  -21
    w[14,21]  old_normalized_TC  -1.7574592074592079e+00
    w[14,21]  old_normalized_TC2  3.0293706293706291e+00
    w[14,22]  mass_14   1
    w[14,22]  w_lb_14_22  1
    w[14,22]  w_ub_14_22  1
    w[14,22]  normalized_inventory_14  -22
    w[14,22]  old_normalized_TC  -2.2189976689976691e+00
    w[14,22]  old_normalized_TC2  2.5678321678321674e+00
    w[14,23]  mass_14   1
    w[14,23]  w_lb_14_23  1
    w[14,23]  w_ub_14_23  1
    w[14,23]  normalized_inventory_14  -23
    w[14,23]  old_normalized_TC  -2.7224941724941729e+00
    w[14,23]  old_normalized_TC2  2.0643356643356641e+00
    w[15,0]   mass_15   1
    w[15,0]   w_lb_15_0  1
    w[15,0]   w_ub_15_0  1
    w[15,1]   mass_15   1
    w[15,1]   w_lb_15_1  1
    w[15,1]   w_ub_15_1  1
    w[15,1]   normalized_inventory_15  -1
    w[15,1]   old_normalized_TC2  5.7142857142857140e-01
    w[15,2]   mass_15   1
    w[15,2]   w_lb_15_2  1
    w[15,2]   w_ub_15_2  1
    w[15,2]   normalized_inventory_15  -2
    w[15,2]   old_normalized_TC2  1.1428571428571428e+00
    w[15,3]   mass_15   1
    w[15,3]   w_lb_15_3  1
    w[15,3]   w_ub_15_3  1
    w[15,3]   normalized_inventory_15  -3
    w[15,3]   old_normalized_TC2  1.7
    w[15,4]   mass_15   1
    w[15,4]   w_lb_15_4  1
    w[15,4]   w_ub_15_4  1
    w[15,4]   normalized_inventory_15  -4
    w[15,4]   old_normalized_TC2  2.2
    w[15,5]   mass_15   1
    w[15,5]   w_lb_15_5  1
    w[15,5]   w_ub_15_5  1
    w[15,5]   normalized_inventory_15  -5
    w[15,5]   old_normalized_TC2  2.7
    w[15,6]   mass_15   1
    w[15,6]   w_lb_15_6  1
    w[15,6]   w_ub_15_6  1
    w[15,6]   normalized_inventory_15  -6
    w[15,6]   old_normalized_TC2  3.1350649350649351e+00
    w[15,7]   mass_15   1
    w[15,7]   w_lb_15_7  1
    w[15,7]   w_ub_15_7  1
    w[15,7]   normalized_inventory_15  -7
    w[15,7]   old_normalized_TC2  3.5251748251748252e+00
    w[15,8]   mass_15   1
    w[15,8]   w_lb_15_8  1
    w[15,8]   w_ub_15_8  1
    w[15,8]   normalized_inventory_15  -8
    w[15,8]   old_normalized_TC2  3.8823176823176824e+00
    w[15,9]   mass_15   1
    w[15,9]   w_lb_15_9  1
    w[15,9]   w_ub_15_9  1
    w[15,9]   normalized_inventory_15  -9
    w[15,9]   old_normalized_TC2  4.17993672993673
    w[15,10]  mass_15   1
    w[15,10]  w_lb_15_10  1
    w[15,10]  w_ub_15_10  1
    w[15,10]  normalized_inventory_15  -10
    w[15,10]  old_normalized_TC2  4.4180319680319684e+00
    w[15,11]  mass_15   1
    w[15,11]  w_lb_15_11  1
    w[15,11]  w_ub_15_11  1
    w[15,11]  normalized_inventory_15  -11
    w[15,11]  old_normalized_TC2  4.6158341658341664e+00
    w[15,12]  mass_15   1
    w[15,12]  w_lb_15_12  1
    w[15,12]  w_ub_15_12  1
    w[15,12]  normalized_inventory_15  -12
    w[15,12]  old_normalized_TC2  4.7348817848817850e+00
    w[15,13]  mass_15   1
    w[15,13]  w_lb_15_13  1
    w[15,13]  w_ub_15_13  1
    w[15,13]  normalized_inventory_15  -13
    w[15,13]  old_normalized_TC2  4.7868298368298374e+00
    w[15,14]  mass_15   1
    w[15,14]  w_lb_15_14  1
    w[15,14]  w_ub_15_14  1
    w[15,14]  normalized_inventory_15  -14
    w[15,14]  old_normalized_TC2  4.7868298368298374e+00
    w[15,15]  mass_15   1
    w[15,15]  w_lb_15_15  1
    w[15,15]  w_ub_15_15  1
    w[15,15]  normalized_inventory_15  -15
    w[15,15]  old_normalized_TC2  4.7868298368298374e+00
    w[15,16]  mass_15   1
    w[15,16]  w_lb_15_16  1
    w[15,16]  w_ub_15_16  1
    w[15,16]  normalized_inventory_15  -16
    w[15,16]  old_normalized_TC  -5.9523809523809521e-02
    w[15,16]  old_normalized_TC2  4.7273060273060281e+00
    w[15,17]  mass_15   1
    w[15,17]  w_lb_15_17  1
    w[15,17]  w_ub_15_17  1
    w[15,17]  normalized_inventory_15  -17
    w[15,17]  old_normalized_TC  -1.7857142857142855e-01
    w[15,17]  old_normalized_TC2  4.6082584082584086e+00
    w[15,18]  mass_15   1
    w[15,18]  w_lb_15_18  1
    w[15,18]  w_ub_15_18  1
    w[15,18]  normalized_inventory_15  -18
    w[15,18]  old_normalized_TC  -3.4047619047619038e-01
    w[15,18]  old_normalized_TC2  4.4463536463536473e+00
    w[15,19]  mass_15   1
    w[15,19]  w_lb_15_19  1
    w[15,19]  w_ub_15_19  1
    w[15,19]  normalized_inventory_15  -19
    w[15,19]  old_normalized_TC  -5.5476190476190468e-01
    w[15,19]  old_normalized_TC2  4.2320679320679329e+00
    w[15,20]  mass_15   1
    w[15,20]  w_lb_15_20  1
    w[15,20]  w_ub_15_20  1
    w[15,20]  normalized_inventory_15  -20
    w[15,20]  old_normalized_TC  -8.3398268398268371e-01
    w[15,20]  old_normalized_TC2  3.9528471528471534e+00
    w[15,21]  mass_15   1
    w[15,21]  w_lb_15_21  1
    w[15,21]  w_ub_15_21  1
    w[15,21]  normalized_inventory_15  -21
    w[15,21]  old_normalized_TC  -1.1651515151515146e+00
    w[15,21]  old_normalized_TC2  3.6216783216783224e+00
    w[15,22]  mass_15   1
    w[15,22]  w_lb_15_22  1
    w[15,22]  w_ub_15_22  1
    w[15,22]  normalized_inventory_15  -22
    w[15,22]  old_normalized_TC  -1.5222943722943718e+00
    w[15,22]  old_normalized_TC2  3.2645354645354652e+00
    w[15,23]  mass_15   1
    w[15,23]  w_lb_15_23  1
    w[15,23]  w_ub_15_23  1
    w[15,23]  normalized_inventory_15  -23
    w[15,23]  old_normalized_TC  -1.9222943722943717e+00
    w[15,23]  old_normalized_TC2  2.8645354645354653e+00
    w[15,24]  mass_15   1
    w[15,24]  w_lb_15_24  1
    w[15,24]  w_ub_15_24  1
    w[15,24]  normalized_inventory_15  -24
    w[15,24]  old_normalized_TC  -2.3508658008658
    w[15,24]  old_normalized_TC2  2.4359640359640369e+00
    w[15,25]  mass_15   1
    w[15,25]  w_lb_15_25  1
    w[15,25]  w_ub_15_25  1
    w[15,25]  normalized_inventory_15  -25
    w[15,25]  old_normalized_TC  -2.8378787878787870e+00
    w[15,25]  old_normalized_TC2  1.9489510489510498e+00
    w[15,26]  mass_15   1
    w[15,26]  w_lb_15_26  1
    w[15,26]  w_ub_15_26  1
    w[15,26]  normalized_inventory_15  -26
    w[15,26]  old_normalized_TC  -3.3378787878787870e+00
    w[15,26]  old_normalized_TC2  1.44895104895105
    w[15,27]  mass_15   1
    w[15,27]  w_lb_15_27  1
    w[15,27]  w_ub_15_27  1
    w[15,27]  normalized_inventory_15  -27
    w[15,27]  old_normalized_TC  -3.9478105228105211e+00
    w[15,27]  old_normalized_TC2  8.3901931401931551e-01
    w[16,0]   mass_16   1
    w[16,0]   w_lb_16_0  1
    w[16,0]   w_ub_16_0  1
    w[16,1]   mass_16   1
    w[16,1]   w_lb_16_1  1
    w[16,1]   w_ub_16_1  1
    w[16,1]   normalized_inventory_16  -1
    w[16,1]   old_normalized_TC2  6.6666666666666663e-01
    w[16,2]   mass_16   1
    w[16,2]   w_lb_16_2  1
    w[16,2]   w_ub_16_2  1
    w[16,2]   normalized_inventory_16  -2
    w[16,2]   old_normalized_TC2  1.3333333333333333e+00
    w[16,3]   mass_16   1
    w[16,3]   w_lb_16_3  1
    w[16,3]   w_ub_16_3  1
    w[16,3]   normalized_inventory_16  -3
    w[16,3]   old_normalized_TC2  1.95
    w[16,4]   mass_16   1
    w[16,4]   w_lb_16_4  1
    w[16,4]   w_ub_16_4  1
    w[16,4]   normalized_inventory_16  -4
    w[16,4]   old_normalized_TC2  2.5333333333333332e+00
    w[16,5]   mass_16   1
    w[16,5]   w_lb_16_5  1
    w[16,5]   w_ub_16_5  1
    w[16,5]   normalized_inventory_16  -5
    w[16,5]   old_normalized_TC2  3.0636363636363639e+00
    w[16,6]   mass_16   1
    w[16,6]   w_lb_16_6  1
    w[16,6]   w_ub_16_6  1
    w[16,6]   normalized_inventory_16  -6
    w[16,6]   old_normalized_TC2  3.5251748251748252e+00
    w[16,7]   mass_16   1
    w[16,7]   w_lb_16_7  1
    w[16,7]   w_ub_16_7  1
    w[16,7]   normalized_inventory_16  -7
    w[16,7]   old_normalized_TC2  3.9418414918414921e+00
    w[16,8]   mass_16   1
    w[16,8]   w_lb_16_8  1
    w[16,8]   w_ub_16_8  1
    w[16,8]   normalized_inventory_16  -8
    w[16,8]   old_normalized_TC2  4.2751748251748252e+00
    w[16,9]   mass_16   1
    w[16,9]   w_lb_16_9  1
    w[16,9]   w_ub_16_9  1
    w[16,9]   normalized_inventory_16  -9
    w[16,9]   old_normalized_TC2  4.5251748251748252e+00
    w[16,10]  mass_16   1
    w[16,10]  w_lb_16_10  1
    w[16,10]  w_ub_16_10  1
    w[16,10]  normalized_inventory_16  -10
    w[16,10]  old_normalized_TC2  4.7110722610722613e+00
    w[16,11]  mass_16   1
    w[16,11]  w_lb_16_11  1
    w[16,11]  w_ub_16_11  1
    w[16,11]  normalized_inventory_16  -11
    w[16,11]  old_normalized_TC2  4.7868298368298374e+00
    w[16,12]  mass_16   1
    w[16,12]  w_lb_16_12  1
    w[16,12]  w_ub_16_12  1
    w[16,12]  normalized_inventory_16  -12
    w[16,12]  old_normalized_TC2  4.7868298368298374e+00
    w[16,13]  mass_16   1
    w[16,13]  w_lb_16_13  1
    w[16,13]  w_ub_16_13  1
    w[16,13]  normalized_inventory_16  -13
    w[16,13]  old_normalized_TC2  4.7868298368298374e+00
    w[16,14]  mass_16   1
    w[16,14]  w_lb_16_14  1
    w[16,14]  w_ub_16_14  1
    w[16,14]  normalized_inventory_16  -14
    w[16,14]  old_normalized_TC  -8.3333333333333329e-02
    w[16,14]  old_normalized_TC2  4.7034965034965044e+00
    w[16,15]  mass_16   1
    w[16,15]  w_lb_16_15  1
    w[16,15]  w_ub_16_15  1
    w[16,15]  normalized_inventory_16  -15
    w[16,15]  old_normalized_TC  -2.4999999999999997e-01
    w[16,15]  old_normalized_TC2  4.5368298368298374e+00
    w[16,16]  mass_16   1
    w[16,16]  w_lb_16_16  1
    w[16,16]  w_ub_16_16  1
    w[16,16]  normalized_inventory_16  -16
    w[16,16]  old_normalized_TC  -4.8333333333333323e-01
    w[16,16]  old_normalized_TC2  4.3034965034965040e+00
    w[16,17]  mass_16   1
    w[16,17]  w_lb_16_17  1
    w[16,17]  w_ub_16_17  1
    w[16,17]  normalized_inventory_16  -17
    w[16,17]  old_normalized_TC  -7.8636363636363615e-01
    w[16,17]  old_normalized_TC2  4.0004662004662013e+00
    w[16,18]  mass_16   1
    w[16,18]  w_lb_16_18  1
    w[16,18]  w_ub_16_18  1
    w[16,18]  normalized_inventory_16  -18
    w[16,18]  old_normalized_TC  -1.1651515151515146e+00
    w[16,18]  old_normalized_TC2  3.6216783216783224e+00
    w[16,19]  mass_16   1
    w[16,19]  w_lb_16_19  1
    w[16,19]  w_ub_16_19  1
    w[16,19]  normalized_inventory_16  -19
    w[16,19]  old_normalized_TC  -1.5818181818181813e+00
    w[16,19]  old_normalized_TC2  3.2050116550116554e+00
    w[16,20]  mass_16   1
    w[16,20]  w_lb_16_20  1
    w[16,20]  w_ub_16_20  1
    w[16,20]  normalized_inventory_16  -20
    w[16,20]  old_normalized_TC  -2.0651515151515145e+00
    w[16,20]  old_normalized_TC2  2.7216783216783225e+00
    w[16,21]  mass_16   1
    w[16,21]  w_lb_16_21  1
    w[16,21]  w_ub_16_21  1
    w[16,21]  normalized_inventory_16  -21
    w[16,21]  old_normalized_TC  -2.5878787878787870e+00
    w[16,21]  old_normalized_TC2  2.19895104895105
    w[16,22]  mass_16   1
    w[16,22]  w_lb_16_22  1
    w[16,22]  w_ub_16_22  1
    w[16,22]  normalized_inventory_16  -22
    w[16,22]  old_normalized_TC  -3.17121212121212
    w[16,22]  old_normalized_TC2  1.6156177156177165e+00
    w[17,0]   mass_17   1
    w[17,0]   w_lb_17_0  1
    w[17,0]   w_ub_17_0  1
    w[17,1]   mass_17   1
    w[17,1]   w_lb_17_1  1
    w[17,1]   w_ub_17_1  1
    w[17,1]   normalized_inventory_17  -1
    w[17,1]   old_normalized_TC2  1
    w[17,2]   mass_17   1
    w[17,2]   w_lb_17_2  1
    w[17,2]   w_ub_17_2  1
    w[17,2]   normalized_inventory_17  -2
    w[17,2]   old_normalized_TC2  1.9500000000000002e+00
    w[17,3]   mass_17   1
    w[17,3]   w_lb_17_3  1
    w[17,3]   w_ub_17_3  1
    w[17,3]   normalized_inventory_17  -3
    w[17,3]   old_normalized_TC2  2.8136363636363639e+00
    w[17,4]   mass_17   1
    w[17,4]   w_lb_17_4  1
    w[17,4]   w_ub_17_4  1
    w[17,4]   normalized_inventory_17  -4
    w[17,4]   old_normalized_TC2  3.5251748251748256e+00
    w[17,5]   mass_17   1
    w[17,5]   w_lb_17_5  1
    w[17,5]   w_ub_17_5  1
    w[17,5]   normalized_inventory_17  -5
    w[17,5]   old_normalized_TC2  4.1085081585081591e+00
    w[17,6]   mass_17   1
    w[17,6]   w_lb_17_6  1
    w[17,6]   w_ub_17_6  1
    w[17,6]   normalized_inventory_17  -6
    w[17,6]   old_normalized_TC2  4.5251748251748261e+00
    w[17,7]   mass_17   1
    w[17,7]   w_lb_17_7  1
    w[17,7]   w_ub_17_7  1
    w[17,7]   normalized_inventory_17  -7
    w[17,7]   old_normalized_TC2  4.7527389277389283e+00
    w[17,8]   mass_17   1
    w[17,8]   w_lb_17_8  1
    w[17,8]   w_ub_17_8  1
    w[17,8]   normalized_inventory_17  -8
    w[17,8]   old_normalized_TC2  4.7868298368298374e+00
    w[17,9]   mass_17   1
    w[17,9]   w_lb_17_9  1
    w[17,9]   w_ub_17_9  1
    w[17,9]   normalized_inventory_17  -9
    w[17,9]   old_normalized_TC  -4.1666666666666727e-02
    w[17,9]   old_normalized_TC2  4.7451631701631705e+00
    w[17,10]  mass_17   1
    w[17,10]  w_lb_17_10  1
    w[17,10]  w_ub_17_10  1
    w[17,10]  normalized_inventory_17  -10
    w[17,10]  old_normalized_TC  -2.5000000000000011e-01
    w[17,10]  old_normalized_TC2  4.5368298368298374e+00
    w[17,11]  mass_17   1
    w[17,11]  w_lb_17_11  1
    w[17,11]  w_ub_17_11  1
    w[17,11]  normalized_inventory_17  -11
    w[17,11]  old_normalized_TC  -6.1969696969696975e-01
    w[17,11]  old_normalized_TC2  4.1671328671328673e+00
    w[17,12]  mass_17   1
    w[17,12]  w_lb_17_12  1
    w[17,12]  w_ub_17_12  1
    w[17,12]  normalized_inventory_17  -12
    w[17,12]  old_normalized_TC  -1.1651515151515150e+00
    w[17,12]  old_normalized_TC2  3.6216783216783219e+00
    w[17,13]  mass_17   1
    w[17,13]  w_lb_17_13  1
    w[17,13]  w_ub_17_13  1
    w[17,13]  normalized_inventory_17  -13
    w[17,13]  old_normalized_TC  -1.8151515151515150e+00
    w[17,13]  old_normalized_TC2  2.9716783216783220e+00
    w[17,14]  mass_17   1
    w[17,14]  w_lb_17_14  1
    w[17,14]  w_ub_17_14  1
    w[17,14]  normalized_inventory_17  -14
    w[17,14]  old_normalized_TC  -2.5878787878787874e+00
    w[17,14]  old_normalized_TC2  2.1989510489510491e+00
    w[17,15]  mass_17   1
    w[17,15]  w_lb_17_15  1
    w[17,15]  w_ub_17_15  1
    w[17,15]  normalized_inventory_17  -15
    w[17,15]  old_normalized_TC  -3.4628787878787874e+00
    w[17,15]  old_normalized_TC2  1.3239510489510491e+00
    w[17,16]  mass_17   1
    w[17,16]  w_lb_17_16  1
    w[17,16]  w_ub_17_16  1
    w[17,16]  normalized_inventory_17  -16
    w[17,16]  old_normalized_TC  -4.8763819513819513e+00
    w[17,16]  old_normalized_TC2  -8.9552114552114453e-02
    w[17,17]  mass_17   1
    w[17,17]  w_lb_17_17  1
    w[17,17]  w_ub_17_17  1
    w[17,17]  normalized_inventory_17  -17
    w[17,17]  old_normalized_TC  -6.64027084027084
    w[17,17]  old_normalized_TC2  -1.8534410034410034e+00
    w[17,18]  mass_17   1
    w[17,18]  w_lb_17_18  1
    w[17,18]  w_ub_17_18  1
    w[17,18]  normalized_inventory_17  -18
    w[17,18]  old_normalized_TC  -8.7698162948162928e+00
    w[17,18]  old_normalized_TC2  -3.9829864579864576e+00
    w[17,19]  mass_17   1
    w[17,19]  w_lb_17_19  1
    w[17,19]  w_ub_17_19  1
    w[17,19]  normalized_inventory_17  -19
    w[17,19]  old_normalized_TC  -1.1144816294816293e+01
    w[17,19]  old_normalized_TC2  -6.3579864579864571e+00
    w[18,0]   mass_18   1
    w[18,0]   w_lb_18_0  1
    w[18,0]   w_ub_18_0  1
    w[18,1]   mass_18   1
    w[18,1]   w_lb_18_1  1
    w[18,1]   w_ub_18_1  1
    w[18,1]   normalized_inventory_18  -1
    w[18,1]   old_normalized_TC2  7.2727272727272729e-01
    w[18,2]   mass_18   1
    w[18,2]   w_lb_18_2  1
    w[18,2]   w_ub_18_2  1
    w[18,2]   normalized_inventory_18  -2
    w[18,2]   old_normalized_TC2  1.4545454545454546e+00
    w[18,3]   mass_18   1
    w[18,3]   w_lb_18_3  1
    w[18,3]   w_ub_18_3  1
    w[18,3]   normalized_inventory_18  -3
    w[18,3]   old_normalized_TC2  2.1090909090909093e+00
    w[18,4]   mass_18   1
    w[18,4]   w_lb_18_4  1
    w[18,4]   w_ub_18_4  1
    w[18,4]   normalized_inventory_18  -4
    w[18,4]   old_normalized_TC2  2.7454545454545456e+00
    w[18,5]   mass_18   1
    w[18,5]   w_lb_18_5  1
    w[18,5]   w_ub_18_5  1
    w[18,5]   normalized_inventory_18  -5
    w[18,5]   old_normalized_TC2  3.2909090909090910e+00
    w[18,6]   mass_18   1
    w[18,6]   w_lb_18_6  1
    w[18,6]   w_ub_18_6  1
    w[18,6]   normalized_inventory_18  -6
    w[18,6]   old_normalized_TC2  3.7524475524475527e+00
    w[18,7]   mass_18   1
    w[18,7]   w_lb_18_7  1
    w[18,7]   w_ub_18_7  1
    w[18,7]   normalized_inventory_18  -7
    w[18,7]   old_normalized_TC2  4.1539627039627041e+00
    w[18,8]   mass_18   1
    w[18,8]   w_lb_18_8  1
    w[18,8]   w_ub_18_8  1
    w[18,8]   normalized_inventory_18  -8
    w[18,8]   old_normalized_TC2  4.4569930069930077e+00
    w[18,9]   mass_18   1
    w[18,9]   w_lb_18_9  1
    w[18,9]   w_ub_18_9  1
    w[18,9]   normalized_inventory_18  -9
    w[18,9]   old_normalized_TC2  4.6807692307692310e+00
    w[18,10]  mass_18   1
    w[18,10]  w_lb_18_10  1
    w[18,10]  w_ub_18_10  1
    w[18,10]  normalized_inventory_18  -10
    w[18,10]  old_normalized_TC2  4.7868298368298374e+00
    w[18,11]  mass_18   1
    w[18,11]  w_lb_18_11  1
    w[18,11]  w_ub_18_11  1
    w[18,11]  normalized_inventory_18  -11
    w[18,11]  old_normalized_TC2  4.7868298368298374e+00
    w[18,12]  mass_18   1
    w[18,12]  w_lb_18_12  1
    w[18,12]  w_ub_18_12  1
    w[18,12]  normalized_inventory_18  -12
    w[18,12]  old_normalized_TC  -7.5757575757576662e-03
    w[18,12]  old_normalized_TC2  4.77925407925408
    w[18,13]  mass_18   1
    w[18,13]  w_lb_18_13  1
    w[18,13]  w_ub_18_13  1
    w[18,13]  normalized_inventory_18  -13
    w[18,13]  old_normalized_TC  -1.1363636363636383e-01
    w[18,13]  old_normalized_TC2  4.6731934731934732e+00
    w[18,14]  mass_18   1
    w[18,14]  w_lb_18_14  1
    w[18,14]  w_ub_18_14  1
    w[18,14]  normalized_inventory_18  -14
    w[18,14]  old_normalized_TC  -3.0151515151515174e-01
    w[18,14]  old_normalized_TC2  4.4853146853146857e+00
    w[18,15]  mass_18   1
    w[18,15]  w_lb_18_15  1
    w[18,15]  w_ub_18_15  1
    w[18,15]  normalized_inventory_18  -15
    w[18,15]  old_normalized_TC  -5.7424242424242444e-01
    w[18,15]  old_normalized_TC2  4.2125874125874132e+00
    w[18,16]  mass_18   1
    w[18,16]  w_lb_18_16  1
    w[18,16]  w_ub_18_16  1
    w[18,16]  normalized_inventory_18  -16
    w[18,16]  old_normalized_TC  -9.3787878787878809e-01
    w[18,16]  old_normalized_TC2  3.8489510489510490e+00
    w[18,17]  mass_18   1
    w[18,17]  w_lb_18_17  1
    w[18,17]  w_ub_18_17  1
    w[18,17]  normalized_inventory_18  -17
    w[18,17]  old_normalized_TC  -1.3924242424242426e+00
    w[18,17]  old_normalized_TC2  3.3944055944055944e+00
    w[18,18]  mass_18   1
    w[18,18]  w_lb_18_18  1
    w[18,18]  w_ub_18_18  1
    w[18,18]  normalized_inventory_18  -18
    w[18,18]  old_normalized_TC  -1.8833333333333335e+00
    w[18,18]  old_normalized_TC2  2.9034965034965037e+00
    w[18,19]  mass_18   1
    w[18,19]  w_lb_18_19  1
    w[18,19]  w_ub_18_19  1
    w[18,19]  normalized_inventory_18  -19
    w[18,19]  old_normalized_TC  -2.4287878787878787e+00
    w[18,19]  old_normalized_TC2  2.3580419580419578e+00
    w[18,20]  mass_18   1
    w[18,20]  w_lb_18_20  1
    w[18,20]  w_ub_18_20  1
    w[18,20]  normalized_inventory_18  -20
    w[18,20]  old_normalized_TC  -3.0651515151515154e+00
    w[18,20]  old_normalized_TC2  1.7216783216783216e+00
    w[18,21]  mass_18   1
    w[18,21]  w_lb_18_21  1
    w[18,21]  w_ub_18_21  1
    w[18,21]  normalized_inventory_18  -21
    w[18,21]  old_normalized_TC  -3.7356060606060608e+00
    w[18,21]  old_normalized_TC2  1.0512237762237759e+00
    w[18,22]  mass_18   1
    w[18,22]  w_lb_18_22  1
    w[18,22]  w_ub_18_22  1
    w[18,22]  normalized_inventory_18  -22
    w[18,22]  old_normalized_TC  -4.8763819513819513e+00
    w[18,22]  old_normalized_TC2  -8.9552114552115175e-02
    w[19,0]   mass_19   1
    w[19,0]   w_lb_19_0  1
    w[19,0]   w_ub_19_0  1
    w[19,1]   mass_19   1
    w[19,1]   w_lb_19_1  1
    w[19,1]   w_ub_19_1  1
    w[19,1]   normalized_inventory_19  -1
    w[19,1]   old_normalized_TC2  6.6666666666666663e-01
    w[19,2]   mass_19   1
    w[19,2]   w_lb_19_2  1
    w[19,2]   w_ub_19_2  1
    w[19,2]   normalized_inventory_19  -2
    w[19,2]   old_normalized_TC2  1.3333333333333333e+00
    w[19,3]   mass_19   1
    w[19,3]   w_lb_19_3  1
    w[19,3]   w_ub_19_3  1
    w[19,3]   normalized_inventory_19  -3
    w[19,3]   old_normalized_TC2  1.95
    w[19,4]   mass_19   1
    w[19,4]   w_lb_19_4  1
    w[19,4]   w_ub_19_4  1
    w[19,4]   normalized_inventory_19  -4
    w[19,4]   old_normalized_TC2  2.5333333333333332e+00
    w[19,5]   mass_19   1
    w[19,5]   w_lb_19_5  1
    w[19,5]   w_ub_19_5  1
    w[19,5]   normalized_inventory_19  -5
    w[19,5]   old_normalized_TC2  3.0636363636363639e+00
    w[19,6]   mass_19   1
    w[19,6]   w_lb_19_6  1
    w[19,6]   w_ub_19_6  1
    w[19,6]   normalized_inventory_19  -6
    w[19,6]   old_normalized_TC2  3.5251748251748252e+00
    w[19,7]   mass_19   1
    w[19,7]   w_lb_19_7  1
    w[19,7]   w_ub_19_7  1
    w[19,7]   normalized_inventory_19  -7
    w[19,7]   old_normalized_TC2  3.9418414918414921e+00
    w[19,8]   mass_19   1
    w[19,8]   w_lb_19_8  1
    w[19,8]   w_ub_19_8  1
    w[19,8]   normalized_inventory_19  -8
    w[19,8]   old_normalized_TC2  4.2751748251748252e+00
    w[19,9]   mass_19   1
    w[19,9]   w_lb_19_9  1
    w[19,9]   w_ub_19_9  1
    w[19,9]   normalized_inventory_19  -9
    w[19,9]   old_normalized_TC2  4.5251748251748252e+00
    w[19,10]  mass_19   1
    w[19,10]  w_lb_19_10  1
    w[19,10]  w_ub_19_10  1
    w[19,10]  normalized_inventory_19  -10
    w[19,10]  old_normalized_TC2  4.7110722610722613e+00
    w[19,11]  mass_19   1
    w[19,11]  w_lb_19_11  1
    w[19,11]  w_ub_19_11  1
    w[19,11]  normalized_inventory_19  -11
    w[19,11]  old_normalized_TC2  4.7868298368298374e+00
    w[19,12]  mass_19   1
    w[19,12]  w_lb_19_12  1
    w[19,12]  w_ub_19_12  1
    w[19,12]  normalized_inventory_19  -12
    w[19,12]  old_normalized_TC2  4.7868298368298374e+00
    w[19,13]  mass_19   1
    w[19,13]  w_lb_19_13  1
    w[19,13]  w_ub_19_13  1
    w[19,13]  normalized_inventory_19  -13
    w[19,13]  old_normalized_TC2  4.7868298368298374e+00
    w[19,14]  mass_19   1
    w[19,14]  w_lb_19_14  1
    w[19,14]  w_ub_19_14  1
    w[19,14]  normalized_inventory_19  -14
    w[19,14]  old_normalized_TC  -8.3333333333333329e-02
    w[19,14]  old_normalized_TC2  4.7034965034965044e+00
    w[19,15]  mass_19   1
    w[19,15]  w_lb_19_15  1
    w[19,15]  w_ub_19_15  1
    w[19,15]  normalized_inventory_19  -15
    w[19,15]  old_normalized_TC  -2.4999999999999997e-01
    w[19,15]  old_normalized_TC2  4.5368298368298374e+00
    w[19,16]  mass_19   1
    w[19,16]  w_lb_19_16  1
    w[19,16]  w_ub_19_16  1
    w[19,16]  normalized_inventory_19  -16
    w[19,16]  old_normalized_TC  -4.8333333333333323e-01
    w[19,16]  old_normalized_TC2  4.3034965034965040e+00
    w[19,17]  mass_19   1
    w[19,17]  w_lb_19_17  1
    w[19,17]  w_ub_19_17  1
    w[19,17]  normalized_inventory_19  -17
    w[19,17]  old_normalized_TC  -7.8636363636363615e-01
    w[19,17]  old_normalized_TC2  4.0004662004662013e+00
    w[19,18]  mass_19   1
    w[19,18]  w_lb_19_18  1
    w[19,18]  w_ub_19_18  1
    w[19,18]  normalized_inventory_19  -18
    w[19,18]  old_normalized_TC  -1.1651515151515146e+00
    w[19,18]  old_normalized_TC2  3.6216783216783224e+00
    w[19,19]  mass_19   1
    w[19,19]  w_lb_19_19  1
    w[19,19]  w_ub_19_19  1
    w[19,19]  normalized_inventory_19  -19
    w[19,19]  old_normalized_TC  -1.5818181818181813e+00
    w[19,19]  old_normalized_TC2  3.2050116550116554e+00
    w[19,20]  mass_19   1
    w[19,20]  w_lb_19_20  1
    w[19,20]  w_ub_19_20  1
    w[19,20]  normalized_inventory_19  -20
    w[19,20]  old_normalized_TC  -2.0651515151515145e+00
    w[19,20]  old_normalized_TC2  2.7216783216783225e+00
    w[19,21]  mass_19   1
    w[19,21]  w_lb_19_21  1
    w[19,21]  w_ub_19_21  1
    w[19,21]  normalized_inventory_19  -21
    w[19,21]  old_normalized_TC  -2.5878787878787870e+00
    w[19,21]  old_normalized_TC2  2.19895104895105
    w[19,22]  mass_19   1
    w[19,22]  w_lb_19_22  1
    w[19,22]  w_ub_19_22  1
    w[19,22]  normalized_inventory_19  -22
    w[19,22]  old_normalized_TC  -3.17121212121212
    w[19,22]  old_normalized_TC2  1.6156177156177165e+00
    w[19,23]  mass_19   1
    w[19,23]  w_lb_19_23  1
    w[19,23]  w_ub_19_23  1
    w[19,23]  normalized_inventory_19  -23
    w[19,23]  old_normalized_TC  -3.8113636363636347e+00
    w[19,23]  old_normalized_TC2  9.7546620046620180e-01
    w[20,0]   mass_20   1
    w[20,0]   w_lb_20_0  1
    w[20,0]   w_ub_20_0  1
    w[20,1]   mass_20   1
    w[20,1]   w_lb_20_1  1
    w[20,1]   w_ub_20_1  1
    w[20,1]   normalized_inventory_20  -1
    w[20,1]   old_normalized_TC2  6.1538461538461542e-01
    w[20,2]   mass_20   1
    w[20,2]   w_lb_20_2  1
    w[20,2]   w_ub_20_2  1
    w[20,2]   normalized_inventory_20  -2
    w[20,2]   old_normalized_TC2  1.2307692307692308e+00
    w[20,3]   mass_20   1
    w[20,3]   w_lb_20_3  1
    w[20,3]   w_ub_20_3  1
    w[20,3]   normalized_inventory_20  -3
    w[20,3]   old_normalized_TC2  1.8153846153846156e+00
    w[20,4]   mass_20   1
    w[20,4]   w_lb_20_4  1
    w[20,4]   w_ub_20_4  1
    w[20,4]   normalized_inventory_20  -4
    w[20,4]   old_normalized_TC2  2.3538461538461544e+00
    w[20,5]   mass_20   1
    w[20,5]   w_lb_20_5  1
    w[20,5]   w_ub_20_5  1
    w[20,5]   normalized_inventory_20  -5
    w[20,5]   old_normalized_TC2  2.8713286713286719e+00
    w[20,6]   mass_20   1
    w[20,6]   w_lb_20_6  1
    w[20,6]   w_ub_20_6  1
    w[20,6]   normalized_inventory_20  -6
    w[20,6]   old_normalized_TC2  3.3328671328671331e+00
    w[20,7]   mass_20   1
    w[20,7]   w_lb_20_7  1
    w[20,7]   w_ub_20_7  1
    w[20,7]   normalized_inventory_20  -7
    w[20,7]   old_normalized_TC2  3.7174825174825177e+00
    w[20,8]   mass_20   1
    w[20,8]   w_lb_20_8  1
    w[20,8]   w_ub_20_8  1
    w[20,8]   normalized_inventory_20  -8
    w[20,8]   old_normalized_TC2  4.0700466200466208e+00
    w[20,9]   mass_20   1
    w[20,9]   w_lb_20_9  1
    w[20,9]   w_ub_20_9  1
    w[20,9]   normalized_inventory_20  -9
    w[20,9]   old_normalized_TC2  4.3520979020979027e+00
    w[20,10]  mass_20   1
    w[20,10]  w_lb_20_10  1
    w[20,10]  w_ub_20_10  1
    w[20,10]  normalized_inventory_20  -10
    w[20,10]  old_normalized_TC2  4.5828671328671335e+00
    w[20,11]  mass_20   1
    w[20,11]  w_lb_20_11  1
    w[20,11]  w_ub_20_11  1
    w[20,11]  normalized_inventory_20  -11
    w[20,11]  old_normalized_TC2  4.7238927738927741e+00
    w[20,12]  mass_20   1
    w[20,12]  w_lb_20_12  1
    w[20,12]  w_ub_20_12  1
    w[20,12]  normalized_inventory_20  -12
    w[20,12]  old_normalized_TC2  4.7868298368298374e+00
    w[20,13]  mass_20   1
    w[20,13]  w_lb_20_13  1
    w[20,13]  w_ub_20_13  1
    w[20,13]  normalized_inventory_20  -13
    w[20,13]  old_normalized_TC2  4.7868298368298374e+00
    w[20,14]  mass_20   1
    w[20,14]  w_lb_20_14  1
    w[20,14]  w_ub_20_14  1
    w[20,14]  normalized_inventory_20  -14
    w[20,14]  old_normalized_TC2  4.7868298368298374e+00
    w[20,15]  mass_20   1
    w[20,15]  w_lb_20_15  1
    w[20,15]  w_ub_20_15  1
    w[20,15]  normalized_inventory_20  -15
    w[20,15]  old_normalized_TC  -7.0512820512820637e-02
    w[20,15]  old_normalized_TC2  4.7163170163170163e+00
    w[20,16]  mass_20   1
    w[20,16]  w_lb_20_16  1
    w[20,16]  w_ub_20_16  1
    w[20,16]  normalized_inventory_20  -16
    w[20,16]  old_normalized_TC  -2.1153846153846179e-01
    w[20,16]  old_normalized_TC2  4.5752913752913758e+00
    w[20,17]  mass_20   1
    w[20,17]  w_lb_20_17  1
    w[20,17]  w_ub_20_17  1
    w[20,17]  normalized_inventory_20  -17
    w[20,17]  old_normalized_TC  -4.0641025641025674e-01
    w[20,17]  old_normalized_TC2  4.3804195804195807e+00
    w[20,18]  mass_20   1
    w[20,18]  w_lb_20_18  1
    w[20,18]  w_ub_20_18  1
    w[20,18]  normalized_inventory_20  -18
    w[20,18]  old_normalized_TC  -6.5815850815850852e-01
    w[20,18]  old_normalized_TC2  4.1286713286713290e+00
    w[20,19]  mass_20   1
    w[20,19]  w_lb_20_19  1
    w[20,19]  w_ub_20_19  1
    w[20,19]  normalized_inventory_20  -19
    w[20,19]  old_normalized_TC  -9.7284382284382331e-01
    w[20,19]  old_normalized_TC2  3.8139860139860136e+00
    w[20,20]  mass_20   1
    w[20,20]  w_lb_20_20  1
    w[20,20]  w_ub_20_20  1
    w[20,20]  normalized_inventory_20  -20
    w[20,20]  old_normalized_TC  -1.3574592074592078e+00
    w[20,20]  old_normalized_TC2  3.4293706293706290e+00
    w[20,21]  mass_20   1
    w[20,21]  w_lb_20_21  1
    w[20,21]  w_ub_20_21  1
    w[20,21]  normalized_inventory_20  -21
    w[20,21]  old_normalized_TC  -1.7574592074592079e+00
    w[20,21]  old_normalized_TC2  3.0293706293706291e+00
    w[20,22]  mass_20   1
    w[20,22]  w_lb_20_22  1
    w[20,22]  w_ub_20_22  1
    w[20,22]  normalized_inventory_20  -22
    w[20,22]  old_normalized_TC  -2.2189976689976691e+00
    w[20,22]  old_normalized_TC2  2.5678321678321674e+00
    w[20,23]  mass_20   1
    w[20,23]  w_lb_20_23  1
    w[20,23]  w_ub_20_23  1
    w[20,23]  normalized_inventory_20  -23
    w[20,23]  old_normalized_TC  -2.7224941724941729e+00
    w[20,23]  old_normalized_TC2  2.0643356643356641e+00
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         scaled_stock_lower  -211
    t         scaled_stock_upper  -271
    t         old_normalized_TC2  -9.5736596736596724e+01
    t         old_TS1   -211
    t         old_TS2   -271
    t         old_TS3   -211
    t         old_TS4   -271
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -9.0909090909090912e-02
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[1]      old_TS1   1
    z[1]      old_TS2   1
    z[1]      old_TS3   1
    z[1]      old_TS4   1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -7.1428571428571425e-02
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[2]      old_TS1   1
    z[2]      old_TS2   1
    z[2]      old_TS3   1
    z[2]      old_TS4   1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -6.6666666666666666e-02
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[3]      old_TS1   1
    z[3]      old_TS2   1
    z[3]      old_TS3   1
    z[3]      old_TS4   1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -9.0909090909090912e-02
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[4]      old_TS1   1
    z[4]      old_TS2   1
    z[4]      old_TS3   1
    z[4]      old_TS4   1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -9.0909090909090912e-02
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[5]      old_TS1   1
    z[5]      old_TS2   1
    z[5]      old_TS3   1
    z[5]      old_TS4   1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -9.0909090909090912e-02
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[6]      old_TS1   1
    z[6]      old_TS2   1
    z[6]      old_TS3   1
    z[6]      old_TS4   1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -0.1
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[7]      old_TS1   1
    z[7]      old_TS2   1
    z[7]      old_TS3   1
    z[7]      old_TS4   1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -9.0909090909090912e-02
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[8]      old_TS1   1
    z[8]      old_TS2   1
    z[8]      old_TS3   1
    z[8]      old_TS4   1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -1.1111111111111110e-01
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[9]      old_TS1   1
    z[9]      old_TS2   1
    z[9]      old_TS3   1
    z[9]      old_TS4   1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -0.0625
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[10]     old_TS1   1
    z[10]     old_TS2   1
    z[10]     old_TS3   1
    z[10]     old_TS4   1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -5.8823529411764705e-02
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[11]     old_TS1   1
    z[11]     old_TS2   1
    z[11]     old_TS3   1
    z[11]     old_TS4   1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -0.1
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[12]     old_TS1   1
    z[12]     old_TS2   1
    z[12]     old_TS3   1
    z[12]     old_TS4   1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -7.6923076923076927e-02
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[13]     old_TS1   1
    z[13]     old_TS2   1
    z[13]     old_TS3   1
    z[13]     old_TS4   1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -7.6923076923076927e-02
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[14]     old_TS1   1
    z[14]     old_TS2   1
    z[14]     old_TS3   1
    z[14]     old_TS4   1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -7.1428571428571425e-02
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[15]     old_TS1   1
    z[15]     old_TS2   1
    z[15]     old_TS3   1
    z[15]     old_TS4   1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -8.3333333333333329e-02
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[16]     old_TS1   1
    z[16]     old_TS2   1
    z[16]     old_TS3   1
    z[16]     old_TS4   1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -0.125
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[17]     old_TS1   1
    z[17]     old_TS2   1
    z[17]     old_TS3   1
    z[17]     old_TS4   1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -9.0909090909090912e-02
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[18]     old_TS1   1
    z[18]     old_TS2   1
    z[18]     old_TS3   1
    z[18]     old_TS4   1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -8.3333333333333329e-02
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[19]     old_TS1   1
    z[19]     old_TS2   1
    z[19]     old_TS3   1
    z[19]     old_TS4   1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -7.6923076923076927e-02
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[20]     old_TS1   1
    z[20]     old_TS2   1
    z[20]     old_TS3   1
    z[20]     old_TS4   1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[1]      abs_p_1_4  -1
    r[1]      abs_m_1_4  1
    r[1]      abs_p_1_5  -1
    r[1]      abs_m_1_5  1
    r[1]      abs_p_1_6  -1
    r[1]      abs_m_1_6  1
    r[1]      abs_p_1_7  -1
    r[1]      abs_m_1_7  1
    r[1]      abs_p_1_8  -1
    r[1]      abs_m_1_8  1
    r[1]      abs_p_1_9  -1
    r[1]      abs_m_1_9  1
    r[1]      abs_p_1_10  -1
    r[1]      abs_m_1_10  1
    r[1]      abs_p_1_11  -1
    r[1]      abs_m_1_11  1
    r[1]      abs_p_1_12  -1
    r[1]      abs_m_1_12  1
    r[1]      abs_p_1_13  -1
    r[1]      abs_m_1_13  1
    r[1]      abs_p_1_14  -1
    r[1]      abs_m_1_14  1
    r[1]      abs_p_1_15  -1
    r[1]      abs_m_1_15  1
    r[1]      abs_p_1_16  -1
    r[1]      abs_m_1_16  1
    r[1]      abs_p_1_17  -1
    r[1]      abs_m_1_17  1
    r[1]      abs_p_1_18  -1
    r[1]      abs_m_1_18  1
    r[1]      abs_p_1_19  -1
    r[1]      abs_m_1_19  1
    r[1]      abs_p_1_20  -1
    r[1]      abs_m_1_20  1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[2]      abs_p_2_4  -1
    r[2]      abs_m_2_4  1
    r[2]      abs_p_2_5  -1
    r[2]      abs_m_2_5  1
    r[2]      abs_p_2_6  -1
    r[2]      abs_m_2_6  1
    r[2]      abs_p_2_7  -1
    r[2]      abs_m_2_7  1
    r[2]      abs_p_2_8  -1
    r[2]      abs_m_2_8  1
    r[2]      abs_p_2_9  -1
    r[2]      abs_m_2_9  1
    r[2]      abs_p_2_10  -1
    r[2]      abs_m_2_10  1
    r[2]      abs_p_2_11  -1
    r[2]      abs_m_2_11  1
    r[2]      abs_p_2_12  -1
    r[2]      abs_m_2_12  1
    r[2]      abs_p_2_13  -1
    r[2]      abs_m_2_13  1
    r[2]      abs_p_2_14  -1
    r[2]      abs_m_2_14  1
    r[2]      abs_p_2_15  -1
    r[2]      abs_m_2_15  1
    r[2]      abs_p_2_16  -1
    r[2]      abs_m_2_16  1
    r[2]      abs_p_2_17  -1
    r[2]      abs_m_2_17  1
    r[2]      abs_p_2_18  -1
    r[2]      abs_m_2_18  1
    r[2]      abs_p_2_19  -1
    r[2]      abs_m_2_19  1
    r[2]      abs_p_2_20  -1
    r[2]      abs_m_2_20  1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    r[3]      abs_p_3_4  -1
    r[3]      abs_m_3_4  1
    r[3]      abs_p_3_5  -1
    r[3]      abs_m_3_5  1
    r[3]      abs_p_3_6  -1
    r[3]      abs_m_3_6  1
    r[3]      abs_p_3_7  -1
    r[3]      abs_m_3_7  1
    r[3]      abs_p_3_8  -1
    r[3]      abs_m_3_8  1
    r[3]      abs_p_3_9  -1
    r[3]      abs_m_3_9  1
    r[3]      abs_p_3_10  -1
    r[3]      abs_m_3_10  1
    r[3]      abs_p_3_11  -1
    r[3]      abs_m_3_11  1
    r[3]      abs_p_3_12  -1
    r[3]      abs_m_3_12  1
    r[3]      abs_p_3_13  -1
    r[3]      abs_m_3_13  1
    r[3]      abs_p_3_14  -1
    r[3]      abs_m_3_14  1
    r[3]      abs_p_3_15  -1
    r[3]      abs_m_3_15  1
    r[3]      abs_p_3_16  -1
    r[3]      abs_m_3_16  1
    r[3]      abs_p_3_17  -1
    r[3]      abs_m_3_17  1
    r[3]      abs_p_3_18  -1
    r[3]      abs_m_3_18  1
    r[3]      abs_p_3_19  -1
    r[3]      abs_m_3_19  1
    r[3]      abs_p_3_20  -1
    r[3]      abs_m_3_20  1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      abs_p_1_4  1
    r[4]      abs_m_1_4  -1
    r[4]      abs_p_2_4  1
    r[4]      abs_m_2_4  -1
    r[4]      abs_p_3_4  1
    r[4]      abs_m_3_4  -1
    r[4]      abs_p_4_5  -1
    r[4]      abs_m_4_5  1
    r[4]      abs_p_4_6  -1
    r[4]      abs_m_4_6  1
    r[4]      abs_p_4_7  -1
    r[4]      abs_m_4_7  1
    r[4]      abs_p_4_8  -1
    r[4]      abs_m_4_8  1
    r[4]      abs_p_4_9  -1
    r[4]      abs_m_4_9  1
    r[4]      abs_p_4_10  -1
    r[4]      abs_m_4_10  1
    r[4]      abs_p_4_11  -1
    r[4]      abs_m_4_11  1
    r[4]      abs_p_4_12  -1
    r[4]      abs_m_4_12  1
    r[4]      abs_p_4_13  -1
    r[4]      abs_m_4_13  1
    r[4]      abs_p_4_14  -1
    r[4]      abs_m_4_14  1
    r[4]      abs_p_4_15  -1
    r[4]      abs_m_4_15  1
    r[4]      abs_p_4_16  -1
    r[4]      abs_m_4_16  1
    r[4]      abs_p_4_17  -1
    r[4]      abs_m_4_17  1
    r[4]      abs_p_4_18  -1
    r[4]      abs_m_4_18  1
    r[4]      abs_p_4_19  -1
    r[4]      abs_m_4_19  1
    r[4]      abs_p_4_20  -1
    r[4]      abs_m_4_20  1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      abs_p_1_5  1
    r[5]      abs_m_1_5  -1
    r[5]      abs_p_2_5  1
    r[5]      abs_m_2_5  -1
    r[5]      abs_p_3_5  1
    r[5]      abs_m_3_5  -1
    r[5]      abs_p_4_5  1
    r[5]      abs_m_4_5  -1
    r[5]      abs_p_5_6  -1
    r[5]      abs_m_5_6  1
    r[5]      abs_p_5_7  -1
    r[5]      abs_m_5_7  1
    r[5]      abs_p_5_8  -1
    r[5]      abs_m_5_8  1
    r[5]      abs_p_5_9  -1
    r[5]      abs_m_5_9  1
    r[5]      abs_p_5_10  -1
    r[5]      abs_m_5_10  1
    r[5]      abs_p_5_11  -1
    r[5]      abs_m_5_11  1
    r[5]      abs_p_5_12  -1
    r[5]      abs_m_5_12  1
    r[5]      abs_p_5_13  -1
    r[5]      abs_m_5_13  1
    r[5]      abs_p_5_14  -1
    r[5]      abs_m_5_14  1
    r[5]      abs_p_5_15  -1
    r[5]      abs_m_5_15  1
    r[5]      abs_p_5_16  -1
    r[5]      abs_m_5_16  1
    r[5]      abs_p_5_17  -1
    r[5]      abs_m_5_17  1
    r[5]      abs_p_5_18  -1
    r[5]      abs_m_5_18  1
    r[5]      abs_p_5_19  -1
    r[5]      abs_m_5_19  1
    r[5]      abs_p_5_20  -1
    r[5]      abs_m_5_20  1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      abs_p_1_6  1
    r[6]      abs_m_1_6  -1
    r[6]      abs_p_2_6  1
    r[6]      abs_m_2_6  -1
    r[6]      abs_p_3_6  1
    r[6]      abs_m_3_6  -1
    r[6]      abs_p_4_6  1
    r[6]      abs_m_4_6  -1
    r[6]      abs_p_5_6  1
    r[6]      abs_m_5_6  -1
    r[6]      abs_p_6_7  -1
    r[6]      abs_m_6_7  1
    r[6]      abs_p_6_8  -1
    r[6]      abs_m_6_8  1
    r[6]      abs_p_6_9  -1
    r[6]      abs_m_6_9  1
    r[6]      abs_p_6_10  -1
    r[6]      abs_m_6_10  1
    r[6]      abs_p_6_11  -1
    r[6]      abs_m_6_11  1
    r[6]      abs_p_6_12  -1
    r[6]      abs_m_6_12  1
    r[6]      abs_p_6_13  -1
    r[6]      abs_m_6_13  1
    r[6]      abs_p_6_14  -1
    r[6]      abs_m_6_14  1
    r[6]      abs_p_6_15  -1
    r[6]      abs_m_6_15  1
    r[6]      abs_p_6_16  -1
    r[6]      abs_m_6_16  1
    r[6]      abs_p_6_17  -1
    r[6]      abs_m_6_17  1
    r[6]      abs_p_6_18  -1
    r[6]      abs_m_6_18  1
    r[6]      abs_p_6_19  -1
    r[6]      abs_m_6_19  1
    r[6]      abs_p_6_20  -1
    r[6]      abs_m_6_20  1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      abs_p_1_7  1
    r[7]      abs_m_1_7  -1
    r[7]      abs_p_2_7  1
    r[7]      abs_m_2_7  -1
    r[7]      abs_p_3_7  1
    r[7]      abs_m_3_7  -1
    r[7]      abs_p_4_7  1
    r[7]      abs_m_4_7  -1
    r[7]      abs_p_5_7  1
    r[7]      abs_m_5_7  -1
    r[7]      abs_p_6_7  1
    r[7]      abs_m_6_7  -1
    r[7]      abs_p_7_8  -1
    r[7]      abs_m_7_8  1
    r[7]      abs_p_7_9  -1
    r[7]      abs_m_7_9  1
    r[7]      abs_p_7_10  -1
    r[7]      abs_m_7_10  1
    r[7]      abs_p_7_11  -1
    r[7]      abs_m_7_11  1
    r[7]      abs_p_7_12  -1
    r[7]      abs_m_7_12  1
    r[7]      abs_p_7_13  -1
    r[7]      abs_m_7_13  1
    r[7]      abs_p_7_14  -1
    r[7]      abs_m_7_14  1
    r[7]      abs_p_7_15  -1
    r[7]      abs_m_7_15  1
    r[7]      abs_p_7_16  -1
    r[7]      abs_m_7_16  1
    r[7]      abs_p_7_17  -1
    r[7]      abs_m_7_17  1
    r[7]      abs_p_7_18  -1
    r[7]      abs_m_7_18  1
    r[7]      abs_p_7_19  -1
    r[7]      abs_m_7_19  1
    r[7]      abs_p_7_20  -1
    r[7]      abs_m_7_20  1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      abs_p_1_8  1
    r[8]      abs_m_1_8  -1
    r[8]      abs_p_2_8  1
    r[8]      abs_m_2_8  -1
    r[8]      abs_p_3_8  1
    r[8]      abs_m_3_8  -1
    r[8]      abs_p_4_8  1
    r[8]      abs_m_4_8  -1
    r[8]      abs_p_5_8  1
    r[8]      abs_m_5_8  -1
    r[8]      abs_p_6_8  1
    r[8]      abs_m_6_8  -1
    r[8]      abs_p_7_8  1
    r[8]      abs_m_7_8  -1
    r[8]      abs_p_8_9  -1
    r[8]      abs_m_8_9  1
    r[8]      abs_p_8_10  -1
    r[8]      abs_m_8_10  1
    r[8]      abs_p_8_11  -1
    r[8]      abs_m_8_11  1
    r[8]      abs_p_8_12  -1
    r[8]      abs_m_8_12  1
    r[8]      abs_p_8_13  -1
    r[8]      abs_m_8_13  1
    r[8]      abs_p_8_14  -1
    r[8]      abs_m_8_14  1
    r[8]      abs_p_8_15  -1
    r[8]      abs_m_8_15  1
    r[8]      abs_p_8_16  -1
    r[8]      abs_m_8_16  1
    r[8]      abs_p_8_17  -1
    r[8]      abs_m_8_17  1
    r[8]      abs_p_8_18  -1
    r[8]      abs_m_8_18  1
    r[8]      abs_p_8_19  -1
    r[8]      abs_m_8_19  1
    r[8]      abs_p_8_20  -1
    r[8]      abs_m_8_20  1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      abs_p_1_9  1
    r[9]      abs_m_1_9  -1
    r[9]      abs_p_2_9  1
    r[9]      abs_m_2_9  -1
    r[9]      abs_p_3_9  1
    r[9]      abs_m_3_9  -1
    r[9]      abs_p_4_9  1
    r[9]      abs_m_4_9  -1
    r[9]      abs_p_5_9  1
    r[9]      abs_m_5_9  -1
    r[9]      abs_p_6_9  1
    r[9]      abs_m_6_9  -1
    r[9]      abs_p_7_9  1
    r[9]      abs_m_7_9  -1
    r[9]      abs_p_8_9  1
    r[9]      abs_m_8_9  -1
    r[9]      abs_p_9_10  -1
    r[9]      abs_m_9_10  1
    r[9]      abs_p_9_11  -1
    r[9]      abs_m_9_11  1
    r[9]      abs_p_9_12  -1
    r[9]      abs_m_9_12  1
    r[9]      abs_p_9_13  -1
    r[9]      abs_m_9_13  1
    r[9]      abs_p_9_14  -1
    r[9]      abs_m_9_14  1
    r[9]      abs_p_9_15  -1
    r[9]      abs_m_9_15  1
    r[9]      abs_p_9_16  -1
    r[9]      abs_m_9_16  1
    r[9]      abs_p_9_17  -1
    r[9]      abs_m_9_17  1
    r[9]      abs_p_9_18  -1
    r[9]      abs_m_9_18  1
    r[9]      abs_p_9_19  -1
    r[9]      abs_m_9_19  1
    r[9]      abs_p_9_20  -1
    r[9]      abs_m_9_20  1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     abs_p_1_10  1
    r[10]     abs_m_1_10  -1
    r[10]     abs_p_2_10  1
    r[10]     abs_m_2_10  -1
    r[10]     abs_p_3_10  1
    r[10]     abs_m_3_10  -1
    r[10]     abs_p_4_10  1
    r[10]     abs_m_4_10  -1
    r[10]     abs_p_5_10  1
    r[10]     abs_m_5_10  -1
    r[10]     abs_p_6_10  1
    r[10]     abs_m_6_10  -1
    r[10]     abs_p_7_10  1
    r[10]     abs_m_7_10  -1
    r[10]     abs_p_8_10  1
    r[10]     abs_m_8_10  -1
    r[10]     abs_p_9_10  1
    r[10]     abs_m_9_10  -1
    r[10]     abs_p_10_11  -1
    r[10]     abs_m_10_11  1
    r[10]     abs_p_10_12  -1
    r[10]     abs_m_10_12  1
    r[10]     abs_p_10_13  -1
    r[10]     abs_m_10_13  1
    r[10]     abs_p_10_14  -1
    r[10]     abs_m_10_14  1
    r[10]     abs_p_10_15  -1
    r[10]     abs_m_10_15  1
    r[10]     abs_p_10_16  -1
    r[10]     abs_m_10_16  1
    r[10]     abs_p_10_17  -1
    r[10]     abs_m_10_17  1
    r[10]     abs_p_10_18  -1
    r[10]     abs_m_10_18  1
    r[10]     abs_p_10_19  -1
    r[10]     abs_m_10_19  1
    r[10]     abs_p_10_20  -1
    r[10]     abs_m_10_20  1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     abs_p_1_11  1
    r[11]     abs_m_1_11  -1
    r[11]     abs_p_2_11  1
    r[11]     abs_m_2_11  -1
    r[11]     abs_p_3_11  1
    r[11]     abs_m_3_11  -1
    r[11]     abs_p_4_11  1
    r[11]     abs_m_4_11  -1
    r[11]     abs_p_5_11  1
    r[11]     abs_m_5_11  -1
    r[11]     abs_p_6_11  1
    r[11]     abs_m_6_11  -1
    r[11]     abs_p_7_11  1
    r[11]     abs_m_7_11  -1
    r[11]     abs_p_8_11  1
    r[11]     abs_m_8_11  -1
    r[11]     abs_p_9_11  1
    r[11]     abs_m_9_11  -1
    r[11]     abs_p_10_11  1
    r[11]     abs_m_10_11  -1
    r[11]     abs_p_11_12  -1
    r[11]     abs_m_11_12  1
    r[11]     abs_p_11_13  -1
    r[11]     abs_m_11_13  1
    r[11]     abs_p_11_14  -1
    r[11]     abs_m_11_14  1
    r[11]     abs_p_11_15  -1
    r[11]     abs_m_11_15  1
    r[11]     abs_p_11_16  -1
    r[11]     abs_m_11_16  1
    r[11]     abs_p_11_17  -1
    r[11]     abs_m_11_17  1
    r[11]     abs_p_11_18  -1
    r[11]     abs_m_11_18  1
    r[11]     abs_p_11_19  -1
    r[11]     abs_m_11_19  1
    r[11]     abs_p_11_20  -1
    r[11]     abs_m_11_20  1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     abs_p_1_12  1
    r[12]     abs_m_1_12  -1
    r[12]     abs_p_2_12  1
    r[12]     abs_m_2_12  -1
    r[12]     abs_p_3_12  1
    r[12]     abs_m_3_12  -1
    r[12]     abs_p_4_12  1
    r[12]     abs_m_4_12  -1
    r[12]     abs_p_5_12  1
    r[12]     abs_m_5_12  -1
    r[12]     abs_p_6_12  1
    r[12]     abs_m_6_12  -1
    r[12]     abs_p_7_12  1
    r[12]     abs_m_7_12  -1
    r[12]     abs_p_8_12  1
    r[12]     abs_m_8_12  -1
    r[12]     abs_p_9_12  1
    r[12]     abs_m_9_12  -1
    r[12]     abs_p_10_12  1
    r[12]     abs_m_10_12  -1
    r[12]     abs_p_11_12  1
    r[12]     abs_m_11_12  -1
    r[12]     abs_p_12_13  -1
    r[12]     abs_m_12_13  1
    r[12]     abs_p_12_14  -1
    r[12]     abs_m_12_14  1
    r[12]     abs_p_12_15  -1
    r[12]     abs_m_12_15  1
    r[12]     abs_p_12_16  -1
    r[12]     abs_m_12_16  1
    r[12]     abs_p_12_17  -1
    r[12]     abs_m_12_17  1
    r[12]     abs_p_12_18  -1
    r[12]     abs_m_12_18  1
    r[12]     abs_p_12_19  -1
    r[12]     abs_m_12_19  1
    r[12]     abs_p_12_20  -1
    r[12]     abs_m_12_20  1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     abs_p_1_13  1
    r[13]     abs_m_1_13  -1
    r[13]     abs_p_2_13  1
    r[13]     abs_m_2_13  -1
    r[13]     abs_p_3_13  1
    r[13]     abs_m_3_13  -1
    r[13]     abs_p_4_13  1
    r[13]     abs_m_4_13  -1
    r[13]     abs_p_5_13  1
    r[13]     abs_m_5_13  -1
    r[13]     abs_p_6_13  1
    r[13]     abs_m_6_13  -1
    r[13]     abs_p_7_13  1
    r[13]     abs_m_7_13  -1
    r[13]     abs_p_8_13  1
    r[13]     abs_m_8_13  -1
    r[13]     abs_p_9_13  1
    r[13]     abs_m_9_13  -1
    r[13]     abs_p_10_13  1
    r[13]     abs_m_10_13  -1
    r[13]     abs_p_11_13  1
    r[13]     abs_m_11_13  -1
    r[13]     abs_p_12_13  1
    r[13]     abs_m_12_13  -1
    r[13]     abs_p_13_14  -1
    r[13]     abs_m_13_14  1
    r[13]     abs_p_13_15  -1
    r[13]     abs_m_13_15  1
    r[13]     abs_p_13_16  -1
    r[13]     abs_m_13_16  1
    r[13]     abs_p_13_17  -1
    r[13]     abs_m_13_17  1
    r[13]     abs_p_13_18  -1
    r[13]     abs_m_13_18  1
    r[13]     abs_p_13_19  -1
    r[13]     abs_m_13_19  1
    r[13]     abs_p_13_20  -1
    r[13]     abs_m_13_20  1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     abs_p_1_14  1
    r[14]     abs_m_1_14  -1
    r[14]     abs_p_2_14  1
    r[14]     abs_m_2_14  -1
    r[14]     abs_p_3_14  1
    r[14]     abs_m_3_14  -1
    r[14]     abs_p_4_14  1
    r[14]     abs_m_4_14  -1
    r[14]     abs_p_5_14  1
    r[14]     abs_m_5_14  -1
    r[14]     abs_p_6_14  1
    r[14]     abs_m_6_14  -1
    r[14]     abs_p_7_14  1
    r[14]     abs_m_7_14  -1
    r[14]     abs_p_8_14  1
    r[14]     abs_m_8_14  -1
    r[14]     abs_p_9_14  1
    r[14]     abs_m_9_14  -1
    r[14]     abs_p_10_14  1
    r[14]     abs_m_10_14  -1
    r[14]     abs_p_11_14  1
    r[14]     abs_m_11_14  -1
    r[14]     abs_p_12_14  1
    r[14]     abs_m_12_14  -1
    r[14]     abs_p_13_14  1
    r[14]     abs_m_13_14  -1
    r[14]     abs_p_14_15  -1
    r[14]     abs_m_14_15  1
    r[14]     abs_p_14_16  -1
    r[14]     abs_m_14_16  1
    r[14]     abs_p_14_17  -1
    r[14]     abs_m_14_17  1
    r[14]     abs_p_14_18  -1
    r[14]     abs_m_14_18  1
    r[14]     abs_p_14_19  -1
    r[14]     abs_m_14_19  1
    r[14]     abs_p_14_20  -1
    r[14]     abs_m_14_20  1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     abs_p_1_15  1
    r[15]     abs_m_1_15  -1
    r[15]     abs_p_2_15  1
    r[15]     abs_m_2_15  -1
    r[15]     abs_p_3_15  1
    r[15]     abs_m_3_15  -1
    r[15]     abs_p_4_15  1
    r[15]     abs_m_4_15  -1
    r[15]     abs_p_5_15  1
    r[15]     abs_m_5_15  -1
    r[15]     abs_p_6_15  1
    r[15]     abs_m_6_15  -1
    r[15]     abs_p_7_15  1
    r[15]     abs_m_7_15  -1
    r[15]     abs_p_8_15  1
    r[15]     abs_m_8_15  -1
    r[15]     abs_p_9_15  1
    r[15]     abs_m_9_15  -1
    r[15]     abs_p_10_15  1
    r[15]     abs_m_10_15  -1
    r[15]     abs_p_11_15  1
    r[15]     abs_m_11_15  -1
    r[15]     abs_p_12_15  1
    r[15]     abs_m_12_15  -1
    r[15]     abs_p_13_15  1
    r[15]     abs_m_13_15  -1
    r[15]     abs_p_14_15  1
    r[15]     abs_m_14_15  -1
    r[15]     abs_p_15_16  -1
    r[15]     abs_m_15_16  1
    r[15]     abs_p_15_17  -1
    r[15]     abs_m_15_17  1
    r[15]     abs_p_15_18  -1
    r[15]     abs_m_15_18  1
    r[15]     abs_p_15_19  -1
    r[15]     abs_m_15_19  1
    r[15]     abs_p_15_20  -1
    r[15]     abs_m_15_20  1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     abs_p_1_16  1
    r[16]     abs_m_1_16  -1
    r[16]     abs_p_2_16  1
    r[16]     abs_m_2_16  -1
    r[16]     abs_p_3_16  1
    r[16]     abs_m_3_16  -1
    r[16]     abs_p_4_16  1
    r[16]     abs_m_4_16  -1
    r[16]     abs_p_5_16  1
    r[16]     abs_m_5_16  -1
    r[16]     abs_p_6_16  1
    r[16]     abs_m_6_16  -1
    r[16]     abs_p_7_16  1
    r[16]     abs_m_7_16  -1
    r[16]     abs_p_8_16  1
    r[16]     abs_m_8_16  -1
    r[16]     abs_p_9_16  1
    r[16]     abs_m_9_16  -1
    r[16]     abs_p_10_16  1
    r[16]     abs_m_10_16  -1
    r[16]     abs_p_11_16  1
    r[16]     abs_m_11_16  -1
    r[16]     abs_p_12_16  1
    r[16]     abs_m_12_16  -1
    r[16]     abs_p_13_16  1
    r[16]     abs_m_13_16  -1
    r[16]     abs_p_14_16  1
    r[16]     abs_m_14_16  -1
    r[16]     abs_p_15_16  1
    r[16]     abs_m_15_16  -1
    r[16]     abs_p_16_17  -1
    r[16]     abs_m_16_17  1
    r[16]     abs_p_16_18  -1
    r[16]     abs_m_16_18  1
    r[16]     abs_p_16_19  -1
    r[16]     abs_m_16_19  1
    r[16]     abs_p_16_20  -1
    r[16]     abs_m_16_20  1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     abs_p_1_17  1
    r[17]     abs_m_1_17  -1
    r[17]     abs_p_2_17  1
    r[17]     abs_m_2_17  -1
    r[17]     abs_p_3_17  1
    r[17]     abs_m_3_17  -1
    r[17]     abs_p_4_17  1
    r[17]     abs_m_4_17  -1
    r[17]     abs_p_5_17  1
    r[17]     abs_m_5_17  -1
    r[17]     abs_p_6_17  1
    r[17]     abs_m_6_17  -1
    r[17]     abs_p_7_17  1
    r[17]     abs_m_7_17  -1
    r[17]     abs_p_8_17  1
    r[17]     abs_m_8_17  -1
    r[17]     abs_p_9_17  1
    r[17]     abs_m_9_17  -1
    r[17]     abs_p_10_17  1
    r[17]     abs_m_10_17  -1
    r[17]     abs_p_11_17  1
    r[17]     abs_m_11_17  -1
    r[17]     abs_p_12_17  1
    r[17]     abs_m_12_17  -1
    r[17]     abs_p_13_17  1
    r[17]     abs_m_13_17  -1
    r[17]     abs_p_14_17  1
    r[17]     abs_m_14_17  -1
    r[17]     abs_p_15_17  1
    r[17]     abs_m_15_17  -1
    r[17]     abs_p_16_17  1
    r[17]     abs_m_16_17  -1
    r[17]     abs_p_17_18  -1
    r[17]     abs_m_17_18  1
    r[17]     abs_p_17_19  -1
    r[17]     abs_m_17_19  1
    r[17]     abs_p_17_20  -1
    r[17]     abs_m_17_20  1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     abs_p_1_18  1
    r[18]     abs_m_1_18  -1
    r[18]     abs_p_2_18  1
    r[18]     abs_m_2_18  -1
    r[18]     abs_p_3_18  1
    r[18]     abs_m_3_18  -1
    r[18]     abs_p_4_18  1
    r[18]     abs_m_4_18  -1
    r[18]     abs_p_5_18  1
    r[18]     abs_m_5_18  -1
    r[18]     abs_p_6_18  1
    r[18]     abs_m_6_18  -1
    r[18]     abs_p_7_18  1
    r[18]     abs_m_7_18  -1
    r[18]     abs_p_8_18  1
    r[18]     abs_m_8_18  -1
    r[18]     abs_p_9_18  1
    r[18]     abs_m_9_18  -1
    r[18]     abs_p_10_18  1
    r[18]     abs_m_10_18  -1
    r[18]     abs_p_11_18  1
    r[18]     abs_m_11_18  -1
    r[18]     abs_p_12_18  1
    r[18]     abs_m_12_18  -1
    r[18]     abs_p_13_18  1
    r[18]     abs_m_13_18  -1
    r[18]     abs_p_14_18  1
    r[18]     abs_m_14_18  -1
    r[18]     abs_p_15_18  1
    r[18]     abs_m_15_18  -1
    r[18]     abs_p_16_18  1
    r[18]     abs_m_16_18  -1
    r[18]     abs_p_17_18  1
    r[18]     abs_m_17_18  -1
    r[18]     abs_p_18_19  -1
    r[18]     abs_m_18_19  1
    r[18]     abs_p_18_20  -1
    r[18]     abs_m_18_20  1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     abs_p_1_19  1
    r[19]     abs_m_1_19  -1
    r[19]     abs_p_2_19  1
    r[19]     abs_m_2_19  -1
    r[19]     abs_p_3_19  1
    r[19]     abs_m_3_19  -1
    r[19]     abs_p_4_19  1
    r[19]     abs_m_4_19  -1
    r[19]     abs_p_5_19  1
    r[19]     abs_m_5_19  -1
    r[19]     abs_p_6_19  1
    r[19]     abs_m_6_19  -1
    r[19]     abs_p_7_19  1
    r[19]     abs_m_7_19  -1
    r[19]     abs_p_8_19  1
    r[19]     abs_m_8_19  -1
    r[19]     abs_p_9_19  1
    r[19]     abs_m_9_19  -1
    r[19]     abs_p_10_19  1
    r[19]     abs_m_10_19  -1
    r[19]     abs_p_11_19  1
    r[19]     abs_m_11_19  -1
    r[19]     abs_p_12_19  1
    r[19]     abs_m_12_19  -1
    r[19]     abs_p_13_19  1
    r[19]     abs_m_13_19  -1
    r[19]     abs_p_14_19  1
    r[19]     abs_m_14_19  -1
    r[19]     abs_p_15_19  1
    r[19]     abs_m_15_19  -1
    r[19]     abs_p_16_19  1
    r[19]     abs_m_16_19  -1
    r[19]     abs_p_17_19  1
    r[19]     abs_m_17_19  -1
    r[19]     abs_p_18_19  1
    r[19]     abs_m_18_19  -1
    r[19]     abs_p_19_20  -1
    r[19]     abs_m_19_20  1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     abs_p_1_20  1
    r[20]     abs_m_1_20  -1
    r[20]     abs_p_2_20  1
    r[20]     abs_m_2_20  -1
    r[20]     abs_p_3_20  1
    r[20]     abs_m_3_20  -1
    r[20]     abs_p_4_20  1
    r[20]     abs_m_4_20  -1
    r[20]     abs_p_5_20  1
    r[20]     abs_m_5_20  -1
    r[20]     abs_p_6_20  1
    r[20]     abs_m_6_20  -1
    r[20]     abs_p_7_20  1
    r[20]     abs_m_7_20  -1
    r[20]     abs_p_8_20  1
    r[20]     abs_m_8_20  -1
    r[20]     abs_p_9_20  1
    r[20]     abs_m_9_20  -1
    r[20]     abs_p_10_20  1
    r[20]     abs_m_10_20  -1
    r[20]     abs_p_11_20  1
    r[20]     abs_m_11_20  -1
    r[20]     abs_p_12_20  1
    r[20]     abs_m_12_20  -1
    r[20]     abs_p_13_20  1
    r[20]     abs_m_13_20  -1
    r[20]     abs_p_14_20  1
    r[20]     abs_m_14_20  -1
    r[20]     abs_p_15_20  1
    r[20]     abs_m_15_20  -1
    r[20]     abs_p_16_20  1
    r[20]     abs_m_16_20  -1
    r[20]     abs_p_17_20  1
    r[20]     abs_m_17_20  -1
    r[20]     abs_p_18_20  1
    r[20]     abs_m_18_20  -1
    r[20]     abs_p_19_20  1
    r[20]     abs_m_19_20  -1
    a[1,2]    abs_p_1_2  1
    a[1,2]    abs_m_1_2  1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,2]    old_normalized_TC  1
    a[1,2]    old_normalized_TC2  1
    a[1,3]    abs_p_1_3  1
    a[1,3]    abs_m_1_3  1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,3]    old_normalized_TC  1
    a[1,3]    old_normalized_TC2  1
    a[1,4]    abs_p_1_4  1
    a[1,4]    abs_m_1_4  1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,4]    old_normalized_TC  1
    a[1,4]    old_normalized_TC2  1
    a[1,5]    abs_p_1_5  1
    a[1,5]    abs_m_1_5  1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,5]    old_normalized_TC  1
    a[1,5]    old_normalized_TC2  1
    a[1,6]    abs_p_1_6  1
    a[1,6]    abs_m_1_6  1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,6]    old_normalized_TC  1
    a[1,6]    old_normalized_TC2  1
    a[1,7]    abs_p_1_7  1
    a[1,7]    abs_m_1_7  1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,7]    old_normalized_TC  1
    a[1,7]    old_normalized_TC2  1
    a[1,8]    abs_p_1_8  1
    a[1,8]    abs_m_1_8  1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,8]    old_normalized_TC  1
    a[1,8]    old_normalized_TC2  1
    a[1,9]    abs_p_1_9  1
    a[1,9]    abs_m_1_9  1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,9]    old_normalized_TC  1
    a[1,9]    old_normalized_TC2  1
    a[1,10]   abs_p_1_10  1
    a[1,10]   abs_m_1_10  1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,10]   old_normalized_TC  1
    a[1,10]   old_normalized_TC2  1
    a[1,11]   abs_p_1_11  1
    a[1,11]   abs_m_1_11  1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,11]   old_normalized_TC  1
    a[1,11]   old_normalized_TC2  1
    a[1,12]   abs_p_1_12  1
    a[1,12]   abs_m_1_12  1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,12]   old_normalized_TC  1
    a[1,12]   old_normalized_TC2  1
    a[1,13]   abs_p_1_13  1
    a[1,13]   abs_m_1_13  1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,13]   old_normalized_TC  1
    a[1,13]   old_normalized_TC2  1
    a[1,14]   abs_p_1_14  1
    a[1,14]   abs_m_1_14  1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,14]   old_normalized_TC  1
    a[1,14]   old_normalized_TC2  1
    a[1,15]   abs_p_1_15  1
    a[1,15]   abs_m_1_15  1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,15]   old_normalized_TC  1
    a[1,15]   old_normalized_TC2  1
    a[1,16]   abs_p_1_16  1
    a[1,16]   abs_m_1_16  1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,16]   old_normalized_TC  1
    a[1,16]   old_normalized_TC2  1
    a[1,17]   abs_p_1_17  1
    a[1,17]   abs_m_1_17  1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,17]   old_normalized_TC  1
    a[1,17]   old_normalized_TC2  1
    a[1,18]   abs_p_1_18  1
    a[1,18]   abs_m_1_18  1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,18]   old_normalized_TC  1
    a[1,18]   old_normalized_TC2  1
    a[1,19]   abs_p_1_19  1
    a[1,19]   abs_m_1_19  1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,19]   old_normalized_TC  1
    a[1,19]   old_normalized_TC2  1
    a[1,20]   abs_p_1_20  1
    a[1,20]   abs_m_1_20  1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,20]   old_normalized_TC  1
    a[1,20]   old_normalized_TC2  1
    a[2,3]    abs_p_2_3  1
    a[2,3]    abs_m_2_3  1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,3]    old_normalized_TC  1
    a[2,3]    old_normalized_TC2  1
    a[2,4]    abs_p_2_4  1
    a[2,4]    abs_m_2_4  1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,4]    old_normalized_TC  1
    a[2,4]    old_normalized_TC2  1
    a[2,5]    abs_p_2_5  1
    a[2,5]    abs_m_2_5  1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,5]    old_normalized_TC  1
    a[2,5]    old_normalized_TC2  1
    a[2,6]    abs_p_2_6  1
    a[2,6]    abs_m_2_6  1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,6]    old_normalized_TC  1
    a[2,6]    old_normalized_TC2  1
    a[2,7]    abs_p_2_7  1
    a[2,7]    abs_m_2_7  1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,7]    old_normalized_TC  1
    a[2,7]    old_normalized_TC2  1
    a[2,8]    abs_p_2_8  1
    a[2,8]    abs_m_2_8  1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,8]    old_normalized_TC  1
    a[2,8]    old_normalized_TC2  1
    a[2,9]    abs_p_2_9  1
    a[2,9]    abs_m_2_9  1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,9]    old_normalized_TC  1
    a[2,9]    old_normalized_TC2  1
    a[2,10]   abs_p_2_10  1
    a[2,10]   abs_m_2_10  1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,10]   old_normalized_TC  1
    a[2,10]   old_normalized_TC2  1
    a[2,11]   abs_p_2_11  1
    a[2,11]   abs_m_2_11  1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,11]   old_normalized_TC  1
    a[2,11]   old_normalized_TC2  1
    a[2,12]   abs_p_2_12  1
    a[2,12]   abs_m_2_12  1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,12]   old_normalized_TC  1
    a[2,12]   old_normalized_TC2  1
    a[2,13]   abs_p_2_13  1
    a[2,13]   abs_m_2_13  1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,13]   old_normalized_TC  1
    a[2,13]   old_normalized_TC2  1
    a[2,14]   abs_p_2_14  1
    a[2,14]   abs_m_2_14  1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,14]   old_normalized_TC  1
    a[2,14]   old_normalized_TC2  1
    a[2,15]   abs_p_2_15  1
    a[2,15]   abs_m_2_15  1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,15]   old_normalized_TC  1
    a[2,15]   old_normalized_TC2  1
    a[2,16]   abs_p_2_16  1
    a[2,16]   abs_m_2_16  1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,16]   old_normalized_TC  1
    a[2,16]   old_normalized_TC2  1
    a[2,17]   abs_p_2_17  1
    a[2,17]   abs_m_2_17  1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,17]   old_normalized_TC  1
    a[2,17]   old_normalized_TC2  1
    a[2,18]   abs_p_2_18  1
    a[2,18]   abs_m_2_18  1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,18]   old_normalized_TC  1
    a[2,18]   old_normalized_TC2  1
    a[2,19]   abs_p_2_19  1
    a[2,19]   abs_m_2_19  1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,19]   old_normalized_TC  1
    a[2,19]   old_normalized_TC2  1
    a[2,20]   abs_p_2_20  1
    a[2,20]   abs_m_2_20  1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,20]   old_normalized_TC  1
    a[2,20]   old_normalized_TC2  1
    a[3,4]    abs_p_3_4  1
    a[3,4]    abs_m_3_4  1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,4]    old_normalized_TC  1
    a[3,4]    old_normalized_TC2  1
    a[3,5]    abs_p_3_5  1
    a[3,5]    abs_m_3_5  1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,5]    old_normalized_TC  1
    a[3,5]    old_normalized_TC2  1
    a[3,6]    abs_p_3_6  1
    a[3,6]    abs_m_3_6  1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,6]    old_normalized_TC  1
    a[3,6]    old_normalized_TC2  1
    a[3,7]    abs_p_3_7  1
    a[3,7]    abs_m_3_7  1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,7]    old_normalized_TC  1
    a[3,7]    old_normalized_TC2  1
    a[3,8]    abs_p_3_8  1
    a[3,8]    abs_m_3_8  1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,8]    old_normalized_TC  1
    a[3,8]    old_normalized_TC2  1
    a[3,9]    abs_p_3_9  1
    a[3,9]    abs_m_3_9  1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,9]    old_normalized_TC  1
    a[3,9]    old_normalized_TC2  1
    a[3,10]   abs_p_3_10  1
    a[3,10]   abs_m_3_10  1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,10]   old_normalized_TC  1
    a[3,10]   old_normalized_TC2  1
    a[3,11]   abs_p_3_11  1
    a[3,11]   abs_m_3_11  1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,11]   old_normalized_TC  1
    a[3,11]   old_normalized_TC2  1
    a[3,12]   abs_p_3_12  1
    a[3,12]   abs_m_3_12  1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,12]   old_normalized_TC  1
    a[3,12]   old_normalized_TC2  1
    a[3,13]   abs_p_3_13  1
    a[3,13]   abs_m_3_13  1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,13]   old_normalized_TC  1
    a[3,13]   old_normalized_TC2  1
    a[3,14]   abs_p_3_14  1
    a[3,14]   abs_m_3_14  1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,14]   old_normalized_TC  1
    a[3,14]   old_normalized_TC2  1
    a[3,15]   abs_p_3_15  1
    a[3,15]   abs_m_3_15  1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,15]   old_normalized_TC  1
    a[3,15]   old_normalized_TC2  1
    a[3,16]   abs_p_3_16  1
    a[3,16]   abs_m_3_16  1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,16]   old_normalized_TC  1
    a[3,16]   old_normalized_TC2  1
    a[3,17]   abs_p_3_17  1
    a[3,17]   abs_m_3_17  1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,17]   old_normalized_TC  1
    a[3,17]   old_normalized_TC2  1
    a[3,18]   abs_p_3_18  1
    a[3,18]   abs_m_3_18  1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,18]   old_normalized_TC  1
    a[3,18]   old_normalized_TC2  1
    a[3,19]   abs_p_3_19  1
    a[3,19]   abs_m_3_19  1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,19]   old_normalized_TC  1
    a[3,19]   old_normalized_TC2  1
    a[3,20]   abs_p_3_20  1
    a[3,20]   abs_m_3_20  1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,20]   old_normalized_TC  1
    a[3,20]   old_normalized_TC2  1
    a[4,5]    abs_p_4_5  1
    a[4,5]    abs_m_4_5  1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,5]    old_normalized_TC  1
    a[4,5]    old_normalized_TC2  1
    a[4,6]    abs_p_4_6  1
    a[4,6]    abs_m_4_6  1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,6]    old_normalized_TC  1
    a[4,6]    old_normalized_TC2  1
    a[4,7]    abs_p_4_7  1
    a[4,7]    abs_m_4_7  1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,7]    old_normalized_TC  1
    a[4,7]    old_normalized_TC2  1
    a[4,8]    abs_p_4_8  1
    a[4,8]    abs_m_4_8  1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,8]    old_normalized_TC  1
    a[4,8]    old_normalized_TC2  1
    a[4,9]    abs_p_4_9  1
    a[4,9]    abs_m_4_9  1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,9]    old_normalized_TC  1
    a[4,9]    old_normalized_TC2  1
    a[4,10]   abs_p_4_10  1
    a[4,10]   abs_m_4_10  1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,10]   old_normalized_TC  1
    a[4,10]   old_normalized_TC2  1
    a[4,11]   abs_p_4_11  1
    a[4,11]   abs_m_4_11  1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,11]   old_normalized_TC  1
    a[4,11]   old_normalized_TC2  1
    a[4,12]   abs_p_4_12  1
    a[4,12]   abs_m_4_12  1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,12]   old_normalized_TC  1
    a[4,12]   old_normalized_TC2  1
    a[4,13]   abs_p_4_13  1
    a[4,13]   abs_m_4_13  1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,13]   old_normalized_TC  1
    a[4,13]   old_normalized_TC2  1
    a[4,14]   abs_p_4_14  1
    a[4,14]   abs_m_4_14  1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,14]   old_normalized_TC  1
    a[4,14]   old_normalized_TC2  1
    a[4,15]   abs_p_4_15  1
    a[4,15]   abs_m_4_15  1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,15]   old_normalized_TC  1
    a[4,15]   old_normalized_TC2  1
    a[4,16]   abs_p_4_16  1
    a[4,16]   abs_m_4_16  1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,16]   old_normalized_TC  1
    a[4,16]   old_normalized_TC2  1
    a[4,17]   abs_p_4_17  1
    a[4,17]   abs_m_4_17  1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,17]   old_normalized_TC  1
    a[4,17]   old_normalized_TC2  1
    a[4,18]   abs_p_4_18  1
    a[4,18]   abs_m_4_18  1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,18]   old_normalized_TC  1
    a[4,18]   old_normalized_TC2  1
    a[4,19]   abs_p_4_19  1
    a[4,19]   abs_m_4_19  1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,19]   old_normalized_TC  1
    a[4,19]   old_normalized_TC2  1
    a[4,20]   abs_p_4_20  1
    a[4,20]   abs_m_4_20  1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,20]   old_normalized_TC  1
    a[4,20]   old_normalized_TC2  1
    a[5,6]    abs_p_5_6  1
    a[5,6]    abs_m_5_6  1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,6]    old_normalized_TC  1
    a[5,6]    old_normalized_TC2  1
    a[5,7]    abs_p_5_7  1
    a[5,7]    abs_m_5_7  1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,7]    old_normalized_TC  1
    a[5,7]    old_normalized_TC2  1
    a[5,8]    abs_p_5_8  1
    a[5,8]    abs_m_5_8  1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,8]    old_normalized_TC  1
    a[5,8]    old_normalized_TC2  1
    a[5,9]    abs_p_5_9  1
    a[5,9]    abs_m_5_9  1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,9]    old_normalized_TC  1
    a[5,9]    old_normalized_TC2  1
    a[5,10]   abs_p_5_10  1
    a[5,10]   abs_m_5_10  1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,10]   old_normalized_TC  1
    a[5,10]   old_normalized_TC2  1
    a[5,11]   abs_p_5_11  1
    a[5,11]   abs_m_5_11  1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,11]   old_normalized_TC  1
    a[5,11]   old_normalized_TC2  1
    a[5,12]   abs_p_5_12  1
    a[5,12]   abs_m_5_12  1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,12]   old_normalized_TC  1
    a[5,12]   old_normalized_TC2  1
    a[5,13]   abs_p_5_13  1
    a[5,13]   abs_m_5_13  1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,13]   old_normalized_TC  1
    a[5,13]   old_normalized_TC2  1
    a[5,14]   abs_p_5_14  1
    a[5,14]   abs_m_5_14  1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,14]   old_normalized_TC  1
    a[5,14]   old_normalized_TC2  1
    a[5,15]   abs_p_5_15  1
    a[5,15]   abs_m_5_15  1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,15]   old_normalized_TC  1
    a[5,15]   old_normalized_TC2  1
    a[5,16]   abs_p_5_16  1
    a[5,16]   abs_m_5_16  1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,16]   old_normalized_TC  1
    a[5,16]   old_normalized_TC2  1
    a[5,17]   abs_p_5_17  1
    a[5,17]   abs_m_5_17  1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,17]   old_normalized_TC  1
    a[5,17]   old_normalized_TC2  1
    a[5,18]   abs_p_5_18  1
    a[5,18]   abs_m_5_18  1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,18]   old_normalized_TC  1
    a[5,18]   old_normalized_TC2  1
    a[5,19]   abs_p_5_19  1
    a[5,19]   abs_m_5_19  1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,19]   old_normalized_TC  1
    a[5,19]   old_normalized_TC2  1
    a[5,20]   abs_p_5_20  1
    a[5,20]   abs_m_5_20  1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,20]   old_normalized_TC  1
    a[5,20]   old_normalized_TC2  1
    a[6,7]    abs_p_6_7  1
    a[6,7]    abs_m_6_7  1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,7]    old_normalized_TC  1
    a[6,7]    old_normalized_TC2  1
    a[6,8]    abs_p_6_8  1
    a[6,8]    abs_m_6_8  1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,8]    old_normalized_TC  1
    a[6,8]    old_normalized_TC2  1
    a[6,9]    abs_p_6_9  1
    a[6,9]    abs_m_6_9  1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,9]    old_normalized_TC  1
    a[6,9]    old_normalized_TC2  1
    a[6,10]   abs_p_6_10  1
    a[6,10]   abs_m_6_10  1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,10]   old_normalized_TC  1
    a[6,10]   old_normalized_TC2  1
    a[6,11]   abs_p_6_11  1
    a[6,11]   abs_m_6_11  1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,11]   old_normalized_TC  1
    a[6,11]   old_normalized_TC2  1
    a[6,12]   abs_p_6_12  1
    a[6,12]   abs_m_6_12  1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,12]   old_normalized_TC  1
    a[6,12]   old_normalized_TC2  1
    a[6,13]   abs_p_6_13  1
    a[6,13]   abs_m_6_13  1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,13]   old_normalized_TC  1
    a[6,13]   old_normalized_TC2  1
    a[6,14]   abs_p_6_14  1
    a[6,14]   abs_m_6_14  1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,14]   old_normalized_TC  1
    a[6,14]   old_normalized_TC2  1
    a[6,15]   abs_p_6_15  1
    a[6,15]   abs_m_6_15  1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,15]   old_normalized_TC  1
    a[6,15]   old_normalized_TC2  1
    a[6,16]   abs_p_6_16  1
    a[6,16]   abs_m_6_16  1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,16]   old_normalized_TC  1
    a[6,16]   old_normalized_TC2  1
    a[6,17]   abs_p_6_17  1
    a[6,17]   abs_m_6_17  1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,17]   old_normalized_TC  1
    a[6,17]   old_normalized_TC2  1
    a[6,18]   abs_p_6_18  1
    a[6,18]   abs_m_6_18  1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,18]   old_normalized_TC  1
    a[6,18]   old_normalized_TC2  1
    a[6,19]   abs_p_6_19  1
    a[6,19]   abs_m_6_19  1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,19]   old_normalized_TC  1
    a[6,19]   old_normalized_TC2  1
    a[6,20]   abs_p_6_20  1
    a[6,20]   abs_m_6_20  1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,20]   old_normalized_TC  1
    a[6,20]   old_normalized_TC2  1
    a[7,8]    abs_p_7_8  1
    a[7,8]    abs_m_7_8  1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,8]    old_normalized_TC  1
    a[7,8]    old_normalized_TC2  1
    a[7,9]    abs_p_7_9  1
    a[7,9]    abs_m_7_9  1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,9]    old_normalized_TC  1
    a[7,9]    old_normalized_TC2  1
    a[7,10]   abs_p_7_10  1
    a[7,10]   abs_m_7_10  1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,10]   old_normalized_TC  1
    a[7,10]   old_normalized_TC2  1
    a[7,11]   abs_p_7_11  1
    a[7,11]   abs_m_7_11  1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,11]   old_normalized_TC  1
    a[7,11]   old_normalized_TC2  1
    a[7,12]   abs_p_7_12  1
    a[7,12]   abs_m_7_12  1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,12]   old_normalized_TC  1
    a[7,12]   old_normalized_TC2  1
    a[7,13]   abs_p_7_13  1
    a[7,13]   abs_m_7_13  1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,13]   old_normalized_TC  1
    a[7,13]   old_normalized_TC2  1
    a[7,14]   abs_p_7_14  1
    a[7,14]   abs_m_7_14  1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,14]   old_normalized_TC  1
    a[7,14]   old_normalized_TC2  1
    a[7,15]   abs_p_7_15  1
    a[7,15]   abs_m_7_15  1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,15]   old_normalized_TC  1
    a[7,15]   old_normalized_TC2  1
    a[7,16]   abs_p_7_16  1
    a[7,16]   abs_m_7_16  1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,16]   old_normalized_TC  1
    a[7,16]   old_normalized_TC2  1
    a[7,17]   abs_p_7_17  1
    a[7,17]   abs_m_7_17  1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,17]   old_normalized_TC  1
    a[7,17]   old_normalized_TC2  1
    a[7,18]   abs_p_7_18  1
    a[7,18]   abs_m_7_18  1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,18]   old_normalized_TC  1
    a[7,18]   old_normalized_TC2  1
    a[7,19]   abs_p_7_19  1
    a[7,19]   abs_m_7_19  1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,19]   old_normalized_TC  1
    a[7,19]   old_normalized_TC2  1
    a[7,20]   abs_p_7_20  1
    a[7,20]   abs_m_7_20  1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,20]   old_normalized_TC  1
    a[7,20]   old_normalized_TC2  1
    a[8,9]    abs_p_8_9  1
    a[8,9]    abs_m_8_9  1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,9]    old_normalized_TC  1
    a[8,9]    old_normalized_TC2  1
    a[8,10]   abs_p_8_10  1
    a[8,10]   abs_m_8_10  1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,10]   old_normalized_TC  1
    a[8,10]   old_normalized_TC2  1
    a[8,11]   abs_p_8_11  1
    a[8,11]   abs_m_8_11  1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,11]   old_normalized_TC  1
    a[8,11]   old_normalized_TC2  1
    a[8,12]   abs_p_8_12  1
    a[8,12]   abs_m_8_12  1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,12]   old_normalized_TC  1
    a[8,12]   old_normalized_TC2  1
    a[8,13]   abs_p_8_13  1
    a[8,13]   abs_m_8_13  1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,13]   old_normalized_TC  1
    a[8,13]   old_normalized_TC2  1
    a[8,14]   abs_p_8_14  1
    a[8,14]   abs_m_8_14  1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,14]   old_normalized_TC  1
    a[8,14]   old_normalized_TC2  1
    a[8,15]   abs_p_8_15  1
    a[8,15]   abs_m_8_15  1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,15]   old_normalized_TC  1
    a[8,15]   old_normalized_TC2  1
    a[8,16]   abs_p_8_16  1
    a[8,16]   abs_m_8_16  1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,16]   old_normalized_TC  1
    a[8,16]   old_normalized_TC2  1
    a[8,17]   abs_p_8_17  1
    a[8,17]   abs_m_8_17  1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,17]   old_normalized_TC  1
    a[8,17]   old_normalized_TC2  1
    a[8,18]   abs_p_8_18  1
    a[8,18]   abs_m_8_18  1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,18]   old_normalized_TC  1
    a[8,18]   old_normalized_TC2  1
    a[8,19]   abs_p_8_19  1
    a[8,19]   abs_m_8_19  1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,19]   old_normalized_TC  1
    a[8,19]   old_normalized_TC2  1
    a[8,20]   abs_p_8_20  1
    a[8,20]   abs_m_8_20  1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,20]   old_normalized_TC  1
    a[8,20]   old_normalized_TC2  1
    a[9,10]   abs_p_9_10  1
    a[9,10]   abs_m_9_10  1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,10]   old_normalized_TC  1
    a[9,10]   old_normalized_TC2  1
    a[9,11]   abs_p_9_11  1
    a[9,11]   abs_m_9_11  1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,11]   old_normalized_TC  1
    a[9,11]   old_normalized_TC2  1
    a[9,12]   abs_p_9_12  1
    a[9,12]   abs_m_9_12  1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,12]   old_normalized_TC  1
    a[9,12]   old_normalized_TC2  1
    a[9,13]   abs_p_9_13  1
    a[9,13]   abs_m_9_13  1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,13]   old_normalized_TC  1
    a[9,13]   old_normalized_TC2  1
    a[9,14]   abs_p_9_14  1
    a[9,14]   abs_m_9_14  1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,14]   old_normalized_TC  1
    a[9,14]   old_normalized_TC2  1
    a[9,15]   abs_p_9_15  1
    a[9,15]   abs_m_9_15  1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,15]   old_normalized_TC  1
    a[9,15]   old_normalized_TC2  1
    a[9,16]   abs_p_9_16  1
    a[9,16]   abs_m_9_16  1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,16]   old_normalized_TC  1
    a[9,16]   old_normalized_TC2  1
    a[9,17]   abs_p_9_17  1
    a[9,17]   abs_m_9_17  1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,17]   old_normalized_TC  1
    a[9,17]   old_normalized_TC2  1
    a[9,18]   abs_p_9_18  1
    a[9,18]   abs_m_9_18  1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,18]   old_normalized_TC  1
    a[9,18]   old_normalized_TC2  1
    a[9,19]   abs_p_9_19  1
    a[9,19]   abs_m_9_19  1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,19]   old_normalized_TC  1
    a[9,19]   old_normalized_TC2  1
    a[9,20]   abs_p_9_20  1
    a[9,20]   abs_m_9_20  1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,20]   old_normalized_TC  1
    a[9,20]   old_normalized_TC2  1
    a[10,11]  abs_p_10_11  1
    a[10,11]  abs_m_10_11  1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,11]  old_normalized_TC  1
    a[10,11]  old_normalized_TC2  1
    a[10,12]  abs_p_10_12  1
    a[10,12]  abs_m_10_12  1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,12]  old_normalized_TC  1
    a[10,12]  old_normalized_TC2  1
    a[10,13]  abs_p_10_13  1
    a[10,13]  abs_m_10_13  1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,13]  old_normalized_TC  1
    a[10,13]  old_normalized_TC2  1
    a[10,14]  abs_p_10_14  1
    a[10,14]  abs_m_10_14  1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,14]  old_normalized_TC  1
    a[10,14]  old_normalized_TC2  1
    a[10,15]  abs_p_10_15  1
    a[10,15]  abs_m_10_15  1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,15]  old_normalized_TC  1
    a[10,15]  old_normalized_TC2  1
    a[10,16]  abs_p_10_16  1
    a[10,16]  abs_m_10_16  1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,16]  old_normalized_TC  1
    a[10,16]  old_normalized_TC2  1
    a[10,17]  abs_p_10_17  1
    a[10,17]  abs_m_10_17  1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,17]  old_normalized_TC  1
    a[10,17]  old_normalized_TC2  1
    a[10,18]  abs_p_10_18  1
    a[10,18]  abs_m_10_18  1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,18]  old_normalized_TC  1
    a[10,18]  old_normalized_TC2  1
    a[10,19]  abs_p_10_19  1
    a[10,19]  abs_m_10_19  1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,19]  old_normalized_TC  1
    a[10,19]  old_normalized_TC2  1
    a[10,20]  abs_p_10_20  1
    a[10,20]  abs_m_10_20  1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,20]  old_normalized_TC  1
    a[10,20]  old_normalized_TC2  1
    a[11,12]  abs_p_11_12  1
    a[11,12]  abs_m_11_12  1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,12]  old_normalized_TC  1
    a[11,12]  old_normalized_TC2  1
    a[11,13]  abs_p_11_13  1
    a[11,13]  abs_m_11_13  1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,13]  old_normalized_TC  1
    a[11,13]  old_normalized_TC2  1
    a[11,14]  abs_p_11_14  1
    a[11,14]  abs_m_11_14  1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,14]  old_normalized_TC  1
    a[11,14]  old_normalized_TC2  1
    a[11,15]  abs_p_11_15  1
    a[11,15]  abs_m_11_15  1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,15]  old_normalized_TC  1
    a[11,15]  old_normalized_TC2  1
    a[11,16]  abs_p_11_16  1
    a[11,16]  abs_m_11_16  1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,16]  old_normalized_TC  1
    a[11,16]  old_normalized_TC2  1
    a[11,17]  abs_p_11_17  1
    a[11,17]  abs_m_11_17  1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,17]  old_normalized_TC  1
    a[11,17]  old_normalized_TC2  1
    a[11,18]  abs_p_11_18  1
    a[11,18]  abs_m_11_18  1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,18]  old_normalized_TC  1
    a[11,18]  old_normalized_TC2  1
    a[11,19]  abs_p_11_19  1
    a[11,19]  abs_m_11_19  1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,19]  old_normalized_TC  1
    a[11,19]  old_normalized_TC2  1
    a[11,20]  abs_p_11_20  1
    a[11,20]  abs_m_11_20  1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,20]  old_normalized_TC  1
    a[11,20]  old_normalized_TC2  1
    a[12,13]  abs_p_12_13  1
    a[12,13]  abs_m_12_13  1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,13]  old_normalized_TC  1
    a[12,13]  old_normalized_TC2  1
    a[12,14]  abs_p_12_14  1
    a[12,14]  abs_m_12_14  1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,14]  old_normalized_TC  1
    a[12,14]  old_normalized_TC2  1
    a[12,15]  abs_p_12_15  1
    a[12,15]  abs_m_12_15  1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,15]  old_normalized_TC  1
    a[12,15]  old_normalized_TC2  1
    a[12,16]  abs_p_12_16  1
    a[12,16]  abs_m_12_16  1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,16]  old_normalized_TC  1
    a[12,16]  old_normalized_TC2  1
    a[12,17]  abs_p_12_17  1
    a[12,17]  abs_m_12_17  1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,17]  old_normalized_TC  1
    a[12,17]  old_normalized_TC2  1
    a[12,18]  abs_p_12_18  1
    a[12,18]  abs_m_12_18  1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,18]  old_normalized_TC  1
    a[12,18]  old_normalized_TC2  1
    a[12,19]  abs_p_12_19  1
    a[12,19]  abs_m_12_19  1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,19]  old_normalized_TC  1
    a[12,19]  old_normalized_TC2  1
    a[12,20]  abs_p_12_20  1
    a[12,20]  abs_m_12_20  1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,20]  old_normalized_TC  1
    a[12,20]  old_normalized_TC2  1
    a[13,14]  abs_p_13_14  1
    a[13,14]  abs_m_13_14  1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,14]  old_normalized_TC  1
    a[13,14]  old_normalized_TC2  1
    a[13,15]  abs_p_13_15  1
    a[13,15]  abs_m_13_15  1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,15]  old_normalized_TC  1
    a[13,15]  old_normalized_TC2  1
    a[13,16]  abs_p_13_16  1
    a[13,16]  abs_m_13_16  1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,16]  old_normalized_TC  1
    a[13,16]  old_normalized_TC2  1
    a[13,17]  abs_p_13_17  1
    a[13,17]  abs_m_13_17  1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,17]  old_normalized_TC  1
    a[13,17]  old_normalized_TC2  1
    a[13,18]  abs_p_13_18  1
    a[13,18]  abs_m_13_18  1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,18]  old_normalized_TC  1
    a[13,18]  old_normalized_TC2  1
    a[13,19]  abs_p_13_19  1
    a[13,19]  abs_m_13_19  1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,19]  old_normalized_TC  1
    a[13,19]  old_normalized_TC2  1
    a[13,20]  abs_p_13_20  1
    a[13,20]  abs_m_13_20  1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,20]  old_normalized_TC  1
    a[13,20]  old_normalized_TC2  1
    a[14,15]  abs_p_14_15  1
    a[14,15]  abs_m_14_15  1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,15]  old_normalized_TC  1
    a[14,15]  old_normalized_TC2  1
    a[14,16]  abs_p_14_16  1
    a[14,16]  abs_m_14_16  1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,16]  old_normalized_TC  1
    a[14,16]  old_normalized_TC2  1
    a[14,17]  abs_p_14_17  1
    a[14,17]  abs_m_14_17  1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,17]  old_normalized_TC  1
    a[14,17]  old_normalized_TC2  1
    a[14,18]  abs_p_14_18  1
    a[14,18]  abs_m_14_18  1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,18]  old_normalized_TC  1
    a[14,18]  old_normalized_TC2  1
    a[14,19]  abs_p_14_19  1
    a[14,19]  abs_m_14_19  1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,19]  old_normalized_TC  1
    a[14,19]  old_normalized_TC2  1
    a[14,20]  abs_p_14_20  1
    a[14,20]  abs_m_14_20  1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,20]  old_normalized_TC  1
    a[14,20]  old_normalized_TC2  1
    a[15,16]  abs_p_15_16  1
    a[15,16]  abs_m_15_16  1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,16]  old_normalized_TC  1
    a[15,16]  old_normalized_TC2  1
    a[15,17]  abs_p_15_17  1
    a[15,17]  abs_m_15_17  1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,17]  old_normalized_TC  1
    a[15,17]  old_normalized_TC2  1
    a[15,18]  abs_p_15_18  1
    a[15,18]  abs_m_15_18  1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,18]  old_normalized_TC  1
    a[15,18]  old_normalized_TC2  1
    a[15,19]  abs_p_15_19  1
    a[15,19]  abs_m_15_19  1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,19]  old_normalized_TC  1
    a[15,19]  old_normalized_TC2  1
    a[15,20]  abs_p_15_20  1
    a[15,20]  abs_m_15_20  1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,20]  old_normalized_TC  1
    a[15,20]  old_normalized_TC2  1
    a[16,17]  abs_p_16_17  1
    a[16,17]  abs_m_16_17  1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,17]  old_normalized_TC  1
    a[16,17]  old_normalized_TC2  1
    a[16,18]  abs_p_16_18  1
    a[16,18]  abs_m_16_18  1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,18]  old_normalized_TC  1
    a[16,18]  old_normalized_TC2  1
    a[16,19]  abs_p_16_19  1
    a[16,19]  abs_m_16_19  1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,19]  old_normalized_TC  1
    a[16,19]  old_normalized_TC2  1
    a[16,20]  abs_p_16_20  1
    a[16,20]  abs_m_16_20  1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,20]  old_normalized_TC  1
    a[16,20]  old_normalized_TC2  1
    a[17,18]  abs_p_17_18  1
    a[17,18]  abs_m_17_18  1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,18]  old_normalized_TC  1
    a[17,18]  old_normalized_TC2  1
    a[17,19]  abs_p_17_19  1
    a[17,19]  abs_m_17_19  1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,19]  old_normalized_TC  1
    a[17,19]  old_normalized_TC2  1
    a[17,20]  abs_p_17_20  1
    a[17,20]  abs_m_17_20  1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,20]  old_normalized_TC  1
    a[17,20]  old_normalized_TC2  1
    a[18,19]  abs_p_18_19  1
    a[18,19]  abs_m_18_19  1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,19]  old_normalized_TC  1
    a[18,19]  old_normalized_TC2  1
    a[18,20]  abs_p_18_20  1
    a[18,20]  abs_m_18_20  1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,20]  old_normalized_TC  1
    a[18,20]  old_normalized_TC2  1
    a[19,20]  abs_p_19_20  1
    a[19,20]  abs_m_19_20  1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,20]  old_normalized_TC  1
    a[19,20]  old_normalized_TC2  1
    q         OBJ       1
    q         true_G_epigraph  -20
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      hard_lower  211
    RHS1      hard_upper  271
    RHS1      normalization  1
    RHS1      physical_G_upper  7.5953661356977875e+00
    RHS1      old_TS1   -8.2596420204349013e+00
    RHS1      old_TS2   -1.8441412243226718e+01
    RHS1      old_TS3   -1.4358442742881314e+01
    RHS1      old_TS4   -1.0608355391174680e+01
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[1,9]  
 BV BND1      x[1,10] 
 BV BND1      x[1,11] 
 BV BND1      x[1,12] 
 BV BND1      x[1,13] 
 BV BND1      x[1,14] 
 BV BND1      x[1,15] 
 BV BND1      x[1,16] 
 BV BND1      x[1,17] 
 BV BND1      x[1,18] 
 BV BND1      x[1,19] 
 BV BND1      x[1,20] 
 BV BND1      x[1,21] 
 BV BND1      x[1,22] 
 BV BND1      x[1,23] 
 BV BND1      x[1,24] 
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[2,16] 
 BV BND1      x[2,17] 
 BV BND1      x[2,18] 
 BV BND1      x[2,19] 
 BV BND1      x[2,20] 
 BV BND1      x[2,21] 
 BV BND1      x[2,22] 
 BV BND1      x[2,23] 
 BV BND1      x[2,24] 
 BV BND1      x[2,25] 
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[3,13] 
 BV BND1      x[3,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,16] 
 BV BND1      x[3,17] 
 BV BND1      x[3,18] 
 BV BND1      x[3,19] 
 BV BND1      x[3,20] 
 BV BND1      x[3,21] 
 BV BND1      x[3,22] 
 BV BND1      x[3,23] 
 BV BND1      x[3,24] 
 BV BND1      x[3,25] 
 BV BND1      x[3,26] 
 BV BND1      x[3,27] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[4,16] 
 BV BND1      x[4,17] 
 BV BND1      x[4,18] 
 BV BND1      x[4,19] 
 BV BND1      x[4,20] 
 BV BND1      x[4,21] 
 BV BND1      x[4,22] 
 BV BND1      x[4,23] 
 BV BND1      x[4,24] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[5,16] 
 BV BND1      x[5,17] 
 BV BND1      x[5,18] 
 BV BND1      x[5,19] 
 BV BND1      x[5,20] 
 BV BND1      x[5,21] 
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[6,2]  
 BV BND1      x[6,3]  
 BV BND1      x[6,4]  
 BV BND1      x[6,5]  
 BV BND1      x[6,6]  
 BV BND1      x[6,7]  
 BV BND1      x[6,8]  
 BV BND1      x[6,9]  
 BV BND1      x[6,10] 
 BV BND1      x[6,11] 
 BV BND1      x[6,12] 
 BV BND1      x[6,13] 
 BV BND1      x[6,14] 
 BV BND1      x[6,15] 
 BV BND1      x[6,16] 
 BV BND1      x[6,17] 
 BV BND1      x[6,18] 
 BV BND1      x[6,19] 
 BV BND1      x[6,20] 
 BV BND1      x[6,21] 
 BV BND1      x[6,22] 
 BV BND1      x[6,23] 
 BV BND1      x[6,24] 
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[7,18] 
 BV BND1      x[7,19] 
 BV BND1      x[7,20] 
 BV BND1      x[7,21] 
 BV BND1      x[7,22] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[8,16] 
 BV BND1      x[8,17] 
 BV BND1      x[8,18] 
 BV BND1      x[8,19] 
 BV BND1      x[8,20] 
 BV BND1      x[8,21] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[9,13] 
 BV BND1      x[9,14] 
 BV BND1      x[9,15] 
 BV BND1      x[9,16] 
 BV BND1      x[9,17] 
 BV BND1      x[9,18] 
 BV BND1      x[9,19] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[10,12]
 BV BND1      x[10,13]
 BV BND1      x[10,14]
 BV BND1      x[10,15]
 BV BND1      x[10,16]
 BV BND1      x[10,17]
 BV BND1      x[10,18]
 BV BND1      x[10,19]
 BV BND1      x[10,20]
 BV BND1      x[10,21]
 BV BND1      x[10,22]
 BV BND1      x[10,23]
 BV BND1      x[10,24]
 BV BND1      x[10,25]
 BV BND1      x[10,26]
 BV BND1      x[10,27]
 BV BND1      x[10,28]
 BV BND1      x[10,29]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[11,13]
 BV BND1      x[11,14]
 BV BND1      x[11,15]
 BV BND1      x[11,16]
 BV BND1      x[11,17]
 BV BND1      x[11,18]
 BV BND1      x[11,19]
 BV BND1      x[11,20]
 BV BND1      x[11,21]
 BV BND1      x[11,22]
 BV BND1      x[11,23]
 BV BND1      x[11,24]
 BV BND1      x[11,25]
 BV BND1      x[11,26]
 BV BND1      x[11,27]
 BV BND1      x[11,28]
 BV BND1      x[11,29]
 BV BND1      x[11,30]
 BV BND1      x[11,31]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[12,16]
 BV BND1      x[12,17]
 BV BND1      x[12,18]
 BV BND1      x[12,19]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[13,20]
 BV BND1      x[13,21]
 BV BND1      x[13,22]
 BV BND1      x[13,23]
 BV BND1      x[13,24]
 BV BND1      x[13,25]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[14,16]
 BV BND1      x[14,17]
 BV BND1      x[14,18]
 BV BND1      x[14,19]
 BV BND1      x[14,20]
 BV BND1      x[14,21]
 BV BND1      x[14,22]
 BV BND1      x[14,23]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[15,17]
 BV BND1      x[15,18]
 BV BND1      x[15,19]
 BV BND1      x[15,20]
 BV BND1      x[15,21]
 BV BND1      x[15,22]
 BV BND1      x[15,23]
 BV BND1      x[15,24]
 BV BND1      x[15,25]
 BV BND1      x[15,26]
 BV BND1      x[15,27]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[16,12]
 BV BND1      x[16,13]
 BV BND1      x[16,14]
 BV BND1      x[16,15]
 BV BND1      x[16,16]
 BV BND1      x[16,17]
 BV BND1      x[16,18]
 BV BND1      x[16,19]
 BV BND1      x[16,20]
 BV BND1      x[16,21]
 BV BND1      x[16,22]
 BV BND1      x[17,0] 
 BV BND1      x[17,1] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[17,5] 
 BV BND1      x[17,6] 
 BV BND1      x[17,7] 
 BV BND1      x[17,8] 
 BV BND1      x[17,9] 
 BV BND1      x[17,10]
 BV BND1      x[17,11]
 BV BND1      x[17,12]
 BV BND1      x[17,13]
 BV BND1      x[17,14]
 BV BND1      x[17,15]
 BV BND1      x[17,16]
 BV BND1      x[17,17]
 BV BND1      x[17,18]
 BV BND1      x[17,19]
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[18,16]
 BV BND1      x[18,17]
 BV BND1      x[18,18]
 BV BND1      x[18,19]
 BV BND1      x[18,20]
 BV BND1      x[18,21]
 BV BND1      x[18,22]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[19,9] 
 BV BND1      x[19,10]
 BV BND1      x[19,11]
 BV BND1      x[19,12]
 BV BND1      x[19,13]
 BV BND1      x[19,14]
 BV BND1      x[19,15]
 BV BND1      x[19,16]
 BV BND1      x[19,17]
 BV BND1      x[19,18]
 BV BND1      x[19,19]
 BV BND1      x[19,20]
 BV BND1      x[19,21]
 BV BND1      x[19,22]
 BV BND1      x[19,23]
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[20,11]
 BV BND1      x[20,12]
 BV BND1      x[20,13]
 BV BND1      x[20,14]
 BV BND1      x[20,15]
 BV BND1      x[20,16]
 BV BND1      x[20,17]
 BV BND1      x[20,18]
 BV BND1      x[20,19]
 BV BND1      x[20,20]
 BV BND1      x[20,21]
 BV BND1      x[20,22]
 BV BND1      x[20,23]
 UP BND1      w[1,0]    0.0680494916724233
 UP BND1      w[1,1]    0.0680494916724233
 UP BND1      w[1,2]    0.0680494916724233
 UP BND1      w[1,3]    0.0680494916724233
 UP BND1      w[1,4]    0.0680494916724233
 UP BND1      w[1,5]    0.0680494916724233
 UP BND1      w[1,6]    0.0680494916724233
 UP BND1      w[1,7]    0.0680494916724233
 UP BND1      w[1,8]    0.0680494916724233
 UP BND1      w[1,9]    0.0680494916724233
 UP BND1      w[1,10]   0.0680494916724233
 UP BND1      w[1,11]   0.0680494916724233
 UP BND1      w[1,12]   0.0680494916724233
 UP BND1      w[1,13]   0.0680494916724233
 UP BND1      w[1,14]   0.0680494916724233
 UP BND1      w[1,15]   0.0680494916724233
 UP BND1      w[1,16]   0.0680494916724233
 UP BND1      w[1,17]   0.0680494916724233
 UP BND1      w[1,18]   0.0680494916724233
 UP BND1      w[1,19]   0.0680494916724233
 UP BND1      w[1,20]   0.0680494916724233
 UP BND1      w[1,21]   0.0680494916724233
 UP BND1      w[1,22]   0.0680494916724233
 UP BND1      w[1,23]   0.0680494916724233
 UP BND1      w[1,24]   0.0680494916724233
 UP BND1      w[2,0]    0.0680494916724233
 UP BND1      w[2,1]    0.0680494916724233
 UP BND1      w[2,2]    0.0680494916724233
 UP BND1      w[2,3]    0.0680494916724233
 UP BND1      w[2,4]    0.0680494916724233
 UP BND1      w[2,5]    0.0680494916724233
 UP BND1      w[2,6]    0.0680494916724233
 UP BND1      w[2,7]    0.0680494916724233
 UP BND1      w[2,8]    0.0680494916724233
 UP BND1      w[2,9]    0.0680494916724233
 UP BND1      w[2,10]   0.0680494916724233
 UP BND1      w[2,11]   0.0680494916724233
 UP BND1      w[2,12]   0.0680494916724233
 UP BND1      w[2,13]   0.0680494916724233
 UP BND1      w[2,14]   0.0680494916724233
 UP BND1      w[2,15]   0.0680494916724233
 UP BND1      w[2,16]   0.0680494916724233
 UP BND1      w[2,17]   0.0680494916724233
 UP BND1      w[2,18]   0.0680494916724233
 UP BND1      w[2,19]   0.0680494916724233
 UP BND1      w[2,20]   0.0680494916724233
 UP BND1      w[2,21]   0.0680494916724233
 UP BND1      w[2,22]   0.0680494916724233
 UP BND1      w[2,23]   0.0680494916724233
 UP BND1      w[2,24]   0.0680494916724233
 UP BND1      w[2,25]   0.0680494916724233
 UP BND1      w[3,0]    0.0680494916724233
 UP BND1      w[3,1]    0.0680494916724233
 UP BND1      w[3,2]    0.0680494916724233
 UP BND1      w[3,3]    0.0680494916724233
 UP BND1      w[3,4]    0.0680494916724233
 UP BND1      w[3,5]    0.0680494916724233
 UP BND1      w[3,6]    0.0680494916724233
 UP BND1      w[3,7]    0.0680494916724233
 UP BND1      w[3,8]    0.0680494916724233
 UP BND1      w[3,9]    0.0680494916724233
 UP BND1      w[3,10]   0.0680494916724233
 UP BND1      w[3,11]   0.0680494916724233
 UP BND1      w[3,12]   0.0680494916724233
 UP BND1      w[3,13]   0.0680494916724233
 UP BND1      w[3,14]   0.0680494916724233
 UP BND1      w[3,15]   0.0680494916724233
 UP BND1      w[3,16]   0.0680494916724233
 UP BND1      w[3,17]   0.0680494916724233
 UP BND1      w[3,18]   0.0680494916724233
 UP BND1      w[3,19]   0.0680494916724233
 UP BND1      w[3,20]   0.0680494916724233
 UP BND1      w[3,21]   0.0680494916724233
 UP BND1      w[3,22]   0.0680494916724233
 UP BND1      w[3,23]   0.0680494916724233
 UP BND1      w[3,24]   0.0680494916724233
 UP BND1      w[3,25]   0.0680494916724233
 UP BND1      w[3,26]   0.0680494916724233
 UP BND1      w[3,27]   0.0680494916724233
 UP BND1      w[4,0]    0.0680494916724233
 UP BND1      w[4,1]    0.0680494916724233
 UP BND1      w[4,2]    0.0680494916724233
 UP BND1      w[4,3]    0.0680494916724233
 UP BND1      w[4,4]    0.0680494916724233
 UP BND1      w[4,5]    0.0680494916724233
 UP BND1      w[4,6]    0.0680494916724233
 UP BND1      w[4,7]    0.0680494916724233
 UP BND1      w[4,8]    0.0680494916724233
 UP BND1      w[4,9]    0.0680494916724233
 UP BND1      w[4,10]   0.0680494916724233
 UP BND1      w[4,11]   0.0680494916724233
 UP BND1      w[4,12]   0.0680494916724233
 UP BND1      w[4,13]   0.0680494916724233
 UP BND1      w[4,14]   0.0680494916724233
 UP BND1      w[4,15]   0.0680494916724233
 UP BND1      w[4,16]   0.0680494916724233
 UP BND1      w[4,17]   0.0680494916724233
 UP BND1      w[4,18]   0.0680494916724233
 UP BND1      w[4,19]   0.0680494916724233
 UP BND1      w[4,20]   0.0680494916724233
 UP BND1      w[4,21]   0.0680494916724233
 UP BND1      w[4,22]   0.0680494916724233
 UP BND1      w[4,23]   0.0680494916724233
 UP BND1      w[4,24]   0.0680494916724233
 UP BND1      w[5,0]    0.0680494916724233
 UP BND1      w[5,1]    0.0680494916724233
 UP BND1      w[5,2]    0.0680494916724233
 UP BND1      w[5,3]    0.0680494916724233
 UP BND1      w[5,4]    0.0680494916724233
 UP BND1      w[5,5]    0.0680494916724233
 UP BND1      w[5,6]    0.0680494916724233
 UP BND1      w[5,7]    0.0680494916724233
 UP BND1      w[5,8]    0.0680494916724233
 UP BND1      w[5,9]    0.0680494916724233
 UP BND1      w[5,10]   0.0680494916724233
 UP BND1      w[5,11]   0.0680494916724233
 UP BND1      w[5,12]   0.0680494916724233
 UP BND1      w[5,13]   0.0680494916724233
 UP BND1      w[5,14]   0.0680494916724233
 UP BND1      w[5,15]   0.0680494916724233
 UP BND1      w[5,16]   0.0680494916724233
 UP BND1      w[5,17]   0.0680494916724233
 UP BND1      w[5,18]   0.0680494916724233
 UP BND1      w[5,19]   0.0680494916724233
 UP BND1      w[5,20]   0.0680494916724233
 UP BND1      w[5,21]   0.0680494916724233
 UP BND1      w[6,0]    0.0680494916724233
 UP BND1      w[6,1]    0.0680494916724233
 UP BND1      w[6,2]    0.0680494916724233
 UP BND1      w[6,3]    0.0680494916724233
 UP BND1      w[6,4]    0.0680494916724233
 UP BND1      w[6,5]    0.0680494916724233
 UP BND1      w[6,6]    0.0680494916724233
 UP BND1      w[6,7]    0.0680494916724233
 UP BND1      w[6,8]    0.0680494916724233
 UP BND1      w[6,9]    0.0680494916724233
 UP BND1      w[6,10]   0.0680494916724233
 UP BND1      w[6,11]   0.0680494916724233
 UP BND1      w[6,12]   0.0680494916724233
 UP BND1      w[6,13]   0.0680494916724233
 UP BND1      w[6,14]   0.0680494916724233
 UP BND1      w[6,15]   0.0680494916724233
 UP BND1      w[6,16]   0.0680494916724233
 UP BND1      w[6,17]   0.0680494916724233
 UP BND1      w[6,18]   0.0680494916724233
 UP BND1      w[6,19]   0.0680494916724233
 UP BND1      w[6,20]   0.0680494916724233
 UP BND1      w[6,21]   0.0680494916724233
 UP BND1      w[6,22]   0.0680494916724233
 UP BND1      w[6,23]   0.0680494916724233
 UP BND1      w[6,24]   0.0680494916724233
 UP BND1      w[7,0]    0.0680494916724233
 UP BND1      w[7,1]    0.0680494916724233
 UP BND1      w[7,2]    0.0680494916724233
 UP BND1      w[7,3]    0.0680494916724233
 UP BND1      w[7,4]    0.0680494916724233
 UP BND1      w[7,5]    0.0680494916724233
 UP BND1      w[7,6]    0.0680494916724233
 UP BND1      w[7,7]    0.0680494916724233
 UP BND1      w[7,8]    0.0680494916724233
 UP BND1      w[7,9]    0.0680494916724233
 UP BND1      w[7,10]   0.0680494916724233
 UP BND1      w[7,11]   0.0680494916724233
 UP BND1      w[7,12]   0.0680494916724233
 UP BND1      w[7,13]   0.0680494916724233
 UP BND1      w[7,14]   0.0680494916724233
 UP BND1      w[7,15]   0.0680494916724233
 UP BND1      w[7,16]   0.0680494916724233
 UP BND1      w[7,17]   0.0680494916724233
 UP BND1      w[7,18]   0.0680494916724233
 UP BND1      w[7,19]   0.0680494916724233
 UP BND1      w[7,20]   0.0680494916724233
 UP BND1      w[7,21]   0.0680494916724233
 UP BND1      w[7,22]   0.0680494916724233
 UP BND1      w[8,0]    0.0680494916724233
 UP BND1      w[8,1]    0.0680494916724233
 UP BND1      w[8,2]    0.0680494916724233
 UP BND1      w[8,3]    0.0680494916724233
 UP BND1      w[8,4]    0.0680494916724233
 UP BND1      w[8,5]    0.0680494916724233
 UP BND1      w[8,6]    0.0680494916724233
 UP BND1      w[8,7]    0.0680494916724233
 UP BND1      w[8,8]    0.0680494916724233
 UP BND1      w[8,9]    0.0680494916724233
 UP BND1      w[8,10]   0.0680494916724233
 UP BND1      w[8,11]   0.0680494916724233
 UP BND1      w[8,12]   0.0680494916724233
 UP BND1      w[8,13]   0.0680494916724233
 UP BND1      w[8,14]   0.0680494916724233
 UP BND1      w[8,15]   0.0680494916724233
 UP BND1      w[8,16]   0.0680494916724233
 UP BND1      w[8,17]   0.0680494916724233
 UP BND1      w[8,18]   0.0680494916724233
 UP BND1      w[8,19]   0.0680494916724233
 UP BND1      w[8,20]   0.0680494916724233
 UP BND1      w[8,21]   0.0680494916724233
 UP BND1      w[9,0]    0.0680494916724233
 UP BND1      w[9,1]    0.0680494916724233
 UP BND1      w[9,2]    0.0680494916724233
 UP BND1      w[9,3]    0.0680494916724233
 UP BND1      w[9,4]    0.0680494916724233
 UP BND1      w[9,5]    0.0680494916724233
 UP BND1      w[9,6]    0.0680494916724233
 UP BND1      w[9,7]    0.0680494916724233
 UP BND1      w[9,8]    0.0680494916724233
 UP BND1      w[9,9]    0.0680494916724233
 UP BND1      w[9,10]   0.0680494916724233
 UP BND1      w[9,11]   0.0680494916724233
 UP BND1      w[9,12]   0.0680494916724233
 UP BND1      w[9,13]   0.0680494916724233
 UP BND1      w[9,14]   0.0680494916724233
 UP BND1      w[9,15]   0.0680494916724233
 UP BND1      w[9,16]   0.0680494916724233
 UP BND1      w[9,17]   0.0680494916724233
 UP BND1      w[9,18]   0.0680494916724233
 UP BND1      w[9,19]   0.0680494916724233
 UP BND1      w[10,0]   0.0680494916724233
 UP BND1      w[10,1]   0.0680494916724233
 UP BND1      w[10,2]   0.0680494916724233
 UP BND1      w[10,3]   0.0680494916724233
 UP BND1      w[10,4]   0.0680494916724233
 UP BND1      w[10,5]   0.0680494916724233
 UP BND1      w[10,6]   0.0680494916724233
 UP BND1      w[10,7]   0.0680494916724233
 UP BND1      w[10,8]   0.0680494916724233
 UP BND1      w[10,9]   0.0680494916724233
 UP BND1      w[10,10]  0.0680494916724233
 UP BND1      w[10,11]  0.0680494916724233
 UP BND1      w[10,12]  0.0680494916724233
 UP BND1      w[10,13]  0.0680494916724233
 UP BND1      w[10,14]  0.0680494916724233
 UP BND1      w[10,15]  0.0680494916724233
 UP BND1      w[10,16]  0.0680494916724233
 UP BND1      w[10,17]  0.0680494916724233
 UP BND1      w[10,18]  0.0680494916724233
 UP BND1      w[10,19]  0.0680494916724233
 UP BND1      w[10,20]  0.0680494916724233
 UP BND1      w[10,21]  0.0680494916724233
 UP BND1      w[10,22]  0.0680494916724233
 UP BND1      w[10,23]  0.0680494916724233
 UP BND1      w[10,24]  0.0680494916724233
 UP BND1      w[10,25]  0.0680494916724233
 UP BND1      w[10,26]  0.0680494916724233
 UP BND1      w[10,27]  0.0680494916724233
 UP BND1      w[10,28]  0.0680494916724233
 UP BND1      w[10,29]  0.0680494916724233
 UP BND1      w[11,0]   0.0680494916724233
 UP BND1      w[11,1]   0.0680494916724233
 UP BND1      w[11,2]   0.0680494916724233
 UP BND1      w[11,3]   0.0680494916724233
 UP BND1      w[11,4]   0.0680494916724233
 UP BND1      w[11,5]   0.0680494916724233
 UP BND1      w[11,6]   0.0680494916724233
 UP BND1      w[11,7]   0.0680494916724233
 UP BND1      w[11,8]   0.0680494916724233
 UP BND1      w[11,9]   0.0680494916724233
 UP BND1      w[11,10]  0.0680494916724233
 UP BND1      w[11,11]  0.0680494916724233
 UP BND1      w[11,12]  0.0680494916724233
 UP BND1      w[11,13]  0.0680494916724233
 UP BND1      w[11,14]  0.0680494916724233
 UP BND1      w[11,15]  0.0680494916724233
 UP BND1      w[11,16]  0.0680494916724233
 UP BND1      w[11,17]  0.0680494916724233
 UP BND1      w[11,18]  0.0680494916724233
 UP BND1      w[11,19]  0.0680494916724233
 UP BND1      w[11,20]  0.0680494916724233
 UP BND1      w[11,21]  0.0680494916724233
 UP BND1      w[11,22]  0.0680494916724233
 UP BND1      w[11,23]  0.0680494916724233
 UP BND1      w[11,24]  0.0680494916724233
 UP BND1      w[11,25]  0.0680494916724233
 UP BND1      w[11,26]  0.0680494916724233
 UP BND1      w[11,27]  0.0680494916724233
 UP BND1      w[11,28]  0.0680494916724233
 UP BND1      w[11,29]  0.0680494916724233
 UP BND1      w[11,30]  0.0680494916724233
 UP BND1      w[11,31]  0.0680494916724233
 UP BND1      w[12,0]   0.0680494916724233
 UP BND1      w[12,1]   0.0680494916724233
 UP BND1      w[12,2]   0.0680494916724233
 UP BND1      w[12,3]   0.0680494916724233
 UP BND1      w[12,4]   0.0680494916724233
 UP BND1      w[12,5]   0.0680494916724233
 UP BND1      w[12,6]   0.0680494916724233
 UP BND1      w[12,7]   0.0680494916724233
 UP BND1      w[12,8]   0.0680494916724233
 UP BND1      w[12,9]   0.0680494916724233
 UP BND1      w[12,10]  0.0680494916724233
 UP BND1      w[12,11]  0.0680494916724233
 UP BND1      w[12,12]  0.0680494916724233
 UP BND1      w[12,13]  0.0680494916724233
 UP BND1      w[12,14]  0.0680494916724233
 UP BND1      w[12,15]  0.0680494916724233
 UP BND1      w[12,16]  0.0680494916724233
 UP BND1      w[12,17]  0.0680494916724233
 UP BND1      w[12,18]  0.0680494916724233
 UP BND1      w[12,19]  0.0680494916724233
 UP BND1      w[13,0]   0.0680494916724233
 UP BND1      w[13,1]   0.0680494916724233
 UP BND1      w[13,2]   0.0680494916724233
 UP BND1      w[13,3]   0.0680494916724233
 UP BND1      w[13,4]   0.0680494916724233
 UP BND1      w[13,5]   0.0680494916724233
 UP BND1      w[13,6]   0.0680494916724233
 UP BND1      w[13,7]   0.0680494916724233
 UP BND1      w[13,8]   0.0680494916724233
 UP BND1      w[13,9]   0.0680494916724233
 UP BND1      w[13,10]  0.0680494916724233
 UP BND1      w[13,11]  0.0680494916724233
 UP BND1      w[13,12]  0.0680494916724233
 UP BND1      w[13,13]  0.0680494916724233
 UP BND1      w[13,14]  0.0680494916724233
 UP BND1      w[13,15]  0.0680494916724233
 UP BND1      w[13,16]  0.0680494916724233
 UP BND1      w[13,17]  0.0680494916724233
 UP BND1      w[13,18]  0.0680494916724233
 UP BND1      w[13,19]  0.0680494916724233
 UP BND1      w[13,20]  0.0680494916724233
 UP BND1      w[13,21]  0.0680494916724233
 UP BND1      w[13,22]  0.0680494916724233
 UP BND1      w[13,23]  0.0680494916724233
 UP BND1      w[13,24]  0.0680494916724233
 UP BND1      w[13,25]  0.0680494916724233
 UP BND1      w[14,0]   0.0680494916724233
 UP BND1      w[14,1]   0.0680494916724233
 UP BND1      w[14,2]   0.0680494916724233
 UP BND1      w[14,3]   0.0680494916724233
 UP BND1      w[14,4]   0.0680494916724233
 UP BND1      w[14,5]   0.0680494916724233
 UP BND1      w[14,6]   0.0680494916724233
 UP BND1      w[14,7]   0.0680494916724233
 UP BND1      w[14,8]   0.0680494916724233
 UP BND1      w[14,9]   0.0680494916724233
 UP BND1      w[14,10]  0.0680494916724233
 UP BND1      w[14,11]  0.0680494916724233
 UP BND1      w[14,12]  0.0680494916724233
 UP BND1      w[14,13]  0.0680494916724233
 UP BND1      w[14,14]  0.0680494916724233
 UP BND1      w[14,15]  0.0680494916724233
 UP BND1      w[14,16]  0.0680494916724233
 UP BND1      w[14,17]  0.0680494916724233
 UP BND1      w[14,18]  0.0680494916724233
 UP BND1      w[14,19]  0.0680494916724233
 UP BND1      w[14,20]  0.0680494916724233
 UP BND1      w[14,21]  0.0680494916724233
 UP BND1      w[14,22]  0.0680494916724233
 UP BND1      w[14,23]  0.0680494916724233
 UP BND1      w[15,0]   0.0680494916724233
 UP BND1      w[15,1]   0.0680494916724233
 UP BND1      w[15,2]   0.0680494916724233
 UP BND1      w[15,3]   0.0680494916724233
 UP BND1      w[15,4]   0.0680494916724233
 UP BND1      w[15,5]   0.0680494916724233
 UP BND1      w[15,6]   0.0680494916724233
 UP BND1      w[15,7]   0.0680494916724233
 UP BND1      w[15,8]   0.0680494916724233
 UP BND1      w[15,9]   0.0680494916724233
 UP BND1      w[15,10]  0.0680494916724233
 UP BND1      w[15,11]  0.0680494916724233
 UP BND1      w[15,12]  0.0680494916724233
 UP BND1      w[15,13]  0.0680494916724233
 UP BND1      w[15,14]  0.0680494916724233
 UP BND1      w[15,15]  0.0680494916724233
 UP BND1      w[15,16]  0.0680494916724233
 UP BND1      w[15,17]  0.0680494916724233
 UP BND1      w[15,18]  0.0680494916724233
 UP BND1      w[15,19]  0.0680494916724233
 UP BND1      w[15,20]  0.0680494916724233
 UP BND1      w[15,21]  0.0680494916724233
 UP BND1      w[15,22]  0.0680494916724233
 UP BND1      w[15,23]  0.0680494916724233
 UP BND1      w[15,24]  0.0680494916724233
 UP BND1      w[15,25]  0.0680494916724233
 UP BND1      w[15,26]  0.0680494916724233
 UP BND1      w[15,27]  0.0680494916724233
 UP BND1      w[16,0]   0.0680494916724233
 UP BND1      w[16,1]   0.0680494916724233
 UP BND1      w[16,2]   0.0680494916724233
 UP BND1      w[16,3]   0.0680494916724233
 UP BND1      w[16,4]   0.0680494916724233
 UP BND1      w[16,5]   0.0680494916724233
 UP BND1      w[16,6]   0.0680494916724233
 UP BND1      w[16,7]   0.0680494916724233
 UP BND1      w[16,8]   0.0680494916724233
 UP BND1      w[16,9]   0.0680494916724233
 UP BND1      w[16,10]  0.0680494916724233
 UP BND1      w[16,11]  0.0680494916724233
 UP BND1      w[16,12]  0.0680494916724233
 UP BND1      w[16,13]  0.0680494916724233
 UP BND1      w[16,14]  0.0680494916724233
 UP BND1      w[16,15]  0.0680494916724233
 UP BND1      w[16,16]  0.0680494916724233
 UP BND1      w[16,17]  0.0680494916724233
 UP BND1      w[16,18]  0.0680494916724233
 UP BND1      w[16,19]  0.0680494916724233
 UP BND1      w[16,20]  0.0680494916724233
 UP BND1      w[16,21]  0.0680494916724233
 UP BND1      w[16,22]  0.0680494916724233
 UP BND1      w[17,0]   0.0680494916724233
 UP BND1      w[17,1]   0.0680494916724233
 UP BND1      w[17,2]   0.0680494916724233
 UP BND1      w[17,3]   0.0680494916724233
 UP BND1      w[17,4]   0.0680494916724233
 UP BND1      w[17,5]   0.0680494916724233
 UP BND1      w[17,6]   0.0680494916724233
 UP BND1      w[17,7]   0.0680494916724233
 UP BND1      w[17,8]   0.0680494916724233
 UP BND1      w[17,9]   0.0680494916724233
 UP BND1      w[17,10]  0.0680494916724233
 UP BND1      w[17,11]  0.0680494916724233
 UP BND1      w[17,12]  0.0680494916724233
 UP BND1      w[17,13]  0.0680494916724233
 UP BND1      w[17,14]  0.0680494916724233
 UP BND1      w[17,15]  0.0680494916724233
 UP BND1      w[17,16]  0.0680494916724233
 UP BND1      w[17,17]  0.0680494916724233
 UP BND1      w[17,18]  0.0680494916724233
 UP BND1      w[17,19]  0.0680494916724233
 UP BND1      w[18,0]   0.0680494916724233
 UP BND1      w[18,1]   0.0680494916724233
 UP BND1      w[18,2]   0.0680494916724233
 UP BND1      w[18,3]   0.0680494916724233
 UP BND1      w[18,4]   0.0680494916724233
 UP BND1      w[18,5]   0.0680494916724233
 UP BND1      w[18,6]   0.0680494916724233
 UP BND1      w[18,7]   0.0680494916724233
 UP BND1      w[18,8]   0.0680494916724233
 UP BND1      w[18,9]   0.0680494916724233
 UP BND1      w[18,10]  0.0680494916724233
 UP BND1      w[18,11]  0.0680494916724233
 UP BND1      w[18,12]  0.0680494916724233
 UP BND1      w[18,13]  0.0680494916724233
 UP BND1      w[18,14]  0.0680494916724233
 UP BND1      w[18,15]  0.0680494916724233
 UP BND1      w[18,16]  0.0680494916724233
 UP BND1      w[18,17]  0.0680494916724233
 UP BND1      w[18,18]  0.0680494916724233
 UP BND1      w[18,19]  0.0680494916724233
 UP BND1      w[18,20]  0.0680494916724233
 UP BND1      w[18,21]  0.0680494916724233
 UP BND1      w[18,22]  0.0680494916724233
 UP BND1      w[19,0]   0.0680494916724233
 UP BND1      w[19,1]   0.0680494916724233
 UP BND1      w[19,2]   0.0680494916724233
 UP BND1      w[19,3]   0.0680494916724233
 UP BND1      w[19,4]   0.0680494916724233
 UP BND1      w[19,5]   0.0680494916724233
 UP BND1      w[19,6]   0.0680494916724233
 UP BND1      w[19,7]   0.0680494916724233
 UP BND1      w[19,8]   0.0680494916724233
 UP BND1      w[19,9]   0.0680494916724233
 UP BND1      w[19,10]  0.0680494916724233
 UP BND1      w[19,11]  0.0680494916724233
 UP BND1      w[19,12]  0.0680494916724233
 UP BND1      w[19,13]  0.0680494916724233
 UP BND1      w[19,14]  0.0680494916724233
 UP BND1      w[19,15]  0.0680494916724233
 UP BND1      w[19,16]  0.0680494916724233
 UP BND1      w[19,17]  0.0680494916724233
 UP BND1      w[19,18]  0.0680494916724233
 UP BND1      w[19,19]  0.0680494916724233
 UP BND1      w[19,20]  0.0680494916724233
 UP BND1      w[19,21]  0.0680494916724233
 UP BND1      w[19,22]  0.0680494916724233
 UP BND1      w[19,23]  0.0680494916724233
 UP BND1      w[20,0]   0.0680494916724233
 UP BND1      w[20,1]   0.0680494916724233
 UP BND1      w[20,2]   0.0680494916724233
 UP BND1      w[20,3]   0.0680494916724233
 UP BND1      w[20,4]   0.0680494916724233
 UP BND1      w[20,5]   0.0680494916724233
 UP BND1      w[20,6]   0.0680494916724233
 UP BND1      w[20,7]   0.0680494916724233
 UP BND1      w[20,8]   0.0680494916724233
 UP BND1      w[20,9]   0.0680494916724233
 UP BND1      w[20,10]  0.0680494916724233
 UP BND1      w[20,11]  0.0680494916724233
 UP BND1      w[20,12]  0.0680494916724233
 UP BND1      w[20,13]  0.0680494916724233
 UP BND1      w[20,14]  0.0680494916724233
 UP BND1      w[20,15]  0.0680494916724233
 UP BND1      w[20,16]  0.0680494916724233
 UP BND1      w[20,17]  0.0680494916724233
 UP BND1      w[20,18]  0.0680494916724233
 UP BND1      w[20,19]  0.0680494916724233
 UP BND1      w[20,20]  0.0680494916724233
 UP BND1      w[20,21]  0.0680494916724233
 UP BND1      w[20,22]  0.0680494916724233
 UP BND1      w[20,23]  0.0680494916724233
 LO BND1      t         3.9145222845663033e-02
 UP BND1      t         0.0680494916724233
 UP BND1      q         3.7976830678488938e-01
ENDATA
