* Signature: 0xfcb2ee52260f1204
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 E  onehot_15_4
 E  normalized_mass_15_5
 E  normalized_ratio_15_6
 G  product_lb_7
 L  product_ub_8
 G  product_lb_9
 L  product_ub_10
 G  product_lb_11
 L  product_ub_12
 G  product_lb_13
 L  product_ub_14
 G  product_lb_15
 L  product_ub_16
 G  product_lb_17
 L  product_ub_18
 G  product_lb_19
 L  product_ub_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_18_39
 E  normalized_mass_18_40
 E  normalized_ratio_18_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 E  onehot_17_76
 E  normalized_mass_17_77
 E  normalized_ratio_17_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 E  onehot_19_91
 E  normalized_mass_19_92
 E  normalized_ratio_19_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 G  product_lb_104
 L  product_ub_105
 G  product_lb_106
 L  product_ub_107
 G  product_lb_108
 L  product_ub_109
 G  product_lb_110
 L  product_ub_111
 G  product_lb_112
 L  product_ub_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 E  onehot_11_126
 E  normalized_mass_11_127
 E  normalized_ratio_11_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 E  onehot_16_135
 E  normalized_mass_16_136
 E  normalized_ratio_16_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 E  onehot_20_170
 E  normalized_mass_20_171
 E  normalized_ratio_20_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 E  onehot_12_205
 E  normalized_mass_12_206
 E  normalized_ratio_12_207
 G  stock_lb_208
 L  stock_ub_209
 L  parent_nonstrict_scope_210
 G  block_pair_pos_211
 G  block_pair_neg_212
 G  block_pair_pos_213
 G  block_pair_neg_214
 G  block_pair_pos_215
 G  block_pair_neg_216
 G  block_pair_pos_217
 G  block_pair_neg_218
 G  block_pair_pos_219
 G  block_pair_neg_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 E  normalization_267
 G  full_original_Gini_268
 E  unique_nonzero_owner_269
 E  unique_nonzero_owner_270
 E  unique_nonzero_owner_271
 E  unique_nonzero_owner_272
 E  unique_nonzero_owner_273
 E  unique_nonzero_owner_274
 E  unique_nonzero_owner_275
 E  unique_nonzero_owner_276
 E  unique_nonzero_owner_277
 E  unique_nonzero_owner_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 L  arc_capacity_353
 L  arc_capacity_354
 L  arc_capacity_355
 L  arc_capacity_356
 L  arc_capacity_357
 L  arc_capacity_358
 L  arc_capacity_359
 L  arc_capacity_360
 L  arc_capacity_361
 L  arc_capacity_362
 L  arc_capacity_363
 L  arc_capacity_364
 L  arc_capacity_365
 L  arc_capacity_366
 L  arc_capacity_367
 L  arc_capacity_368
 L  arc_capacity_369
 L  arc_capacity_370
 L  arc_capacity_371
 G  connected_order_arc_372
 L  arc_capacity_373
 G  connected_order_arc_374
 L  arc_capacity_375
 G  connected_order_arc_376
 L  arc_capacity_377
 G  connected_order_arc_378
 L  arc_capacity_379
 G  connected_order_arc_380
 L  arc_capacity_381
 G  connected_order_arc_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 G  connected_order_arc_770
 L  arc_capacity_771
 G  connected_order_arc_772
 L  arc_capacity_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 G  connected_order_arc_801
 L  arc_capacity_802
 G  connected_order_arc_803
 L  arc_capacity_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 E  depot_departure_or_bypass_866
 E  depot_return_or_bypass_867
 E  out_degree_868
 E  in_degree_869
 G  order_active_lb_870
 L  order_active_ub_871
 E  segment_load_conservation_872
 G  segment_prefix_lb_873
 L  segment_prefix_ub_874
 E  out_degree_875
 E  in_degree_876
 G  order_active_lb_877
 L  order_active_ub_878
 E  segment_load_conservation_879
 G  segment_prefix_lb_880
 L  segment_prefix_ub_881
 E  out_degree_882
 E  in_degree_883
 G  order_active_lb_884
 L  order_active_ub_885
 E  segment_load_conservation_886
 G  segment_prefix_lb_887
 L  segment_prefix_ub_888
 E  out_degree_889
 E  in_degree_890
 G  order_active_lb_891
 L  order_active_ub_892
 E  segment_load_conservation_893
 G  segment_prefix_lb_894
 L  segment_prefix_ub_895
 E  out_degree_896
 E  in_degree_897
 G  order_active_lb_898
 L  order_active_ub_899
 E  segment_load_conservation_900
 G  segment_prefix_lb_901
 L  segment_prefix_ub_902
 E  out_degree_903
 E  in_degree_904
 G  order_active_lb_905
 L  order_active_ub_906
 E  segment_load_conservation_907
 G  segment_prefix_lb_908
 L  segment_prefix_ub_909
 E  out_degree_910
 E  in_degree_911
 G  order_active_lb_912
 L  order_active_ub_913
 E  segment_load_conservation_914
 G  segment_prefix_lb_915
 L  segment_prefix_ub_916
 E  out_degree_917
 E  in_degree_918
 G  order_active_lb_919
 L  order_active_ub_920
 E  segment_load_conservation_921
 G  segment_prefix_lb_922
 L  segment_prefix_ub_923
 E  out_degree_924
 E  in_degree_925
 G  order_active_lb_926
 L  order_active_ub_927
 E  service_visit_def_928
 E  free_load_conservation_929
 E  out_degree_930
 E  in_degree_931
 G  order_active_lb_932
 L  order_active_ub_933
 E  service_visit_def_934
 E  free_load_conservation_935
 E  out_degree_936
 E  in_degree_937
 G  order_active_lb_938
 L  order_active_ub_939
 E  service_visit_def_940
 E  free_load_conservation_941
 E  out_degree_942
 E  in_degree_943
 G  order_active_lb_944
 L  order_active_ub_945
 E  service_visit_def_946
 E  free_load_conservation_947
 E  out_degree_948
 E  in_degree_949
 G  order_active_lb_950
 L  order_active_ub_951
 E  service_visit_def_952
 E  free_load_conservation_953
 E  out_degree_954
 E  in_degree_955
 G  order_active_lb_956
 L  order_active_ub_957
 E  service_visit_def_958
 E  free_load_conservation_959
 E  out_degree_960
 E  in_degree_961
 G  order_active_lb_962
 L  order_active_ub_963
 E  service_visit_def_964
 E  free_load_conservation_965
 E  out_degree_966
 E  in_degree_967
 G  order_active_lb_968
 L  order_active_ub_969
 E  service_visit_def_970
 E  free_load_conservation_971
 G  fixed_segment_relative_order_972
 G  fixed_segment_relative_order_973
 G  fixed_segment_relative_order_974
 G  fixed_segment_relative_order_975
 G  fixed_segment_relative_order_976
 G  fixed_segment_relative_order_977
 G  fixed_segment_relative_order_978
 L  original_T_including_depot_unload_979
 L  arc_capacity_980
 L  arc_capacity_981
 L  arc_capacity_982
 L  arc_capacity_983
 L  arc_capacity_984
 L  arc_capacity_985
 L  arc_capacity_986
 L  arc_capacity_987
 L  arc_capacity_988
 L  arc_capacity_989
 L  arc_capacity_990
 L  arc_capacity_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 E  depot_departure_or_bypass_1181
 E  depot_return_or_bypass_1182
 E  out_degree_1183
 E  in_degree_1184
 G  order_active_lb_1185
 L  order_active_ub_1186
 E  segment_load_conservation_1187
 G  segment_prefix_lb_1188
 L  segment_prefix_ub_1189
 E  out_degree_1190
 E  in_degree_1191
 G  order_active_lb_1192
 L  order_active_ub_1193
 E  segment_load_conservation_1194
 G  segment_prefix_lb_1195
 L  segment_prefix_ub_1196
 E  out_degree_1197
 E  in_degree_1198
 G  order_active_lb_1199
 L  order_active_ub_1200
 E  service_visit_def_1201
 E  free_load_conservation_1202
 E  out_degree_1203
 E  in_degree_1204
 G  order_active_lb_1205
 L  order_active_ub_1206
 E  service_visit_def_1207
 E  free_load_conservation_1208
 E  out_degree_1209
 E  in_degree_1210
 G  order_active_lb_1211
 L  order_active_ub_1212
 E  service_visit_def_1213
 E  free_load_conservation_1214
 E  out_degree_1215
 E  in_degree_1216
 G  order_active_lb_1217
 L  order_active_ub_1218
 E  service_visit_def_1219
 E  free_load_conservation_1220
 E  out_degree_1221
 E  in_degree_1222
 G  order_active_lb_1223
 L  order_active_ub_1224
 E  service_visit_def_1225
 E  free_load_conservation_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  service_visit_def_1231
 E  free_load_conservation_1232
 E  out_degree_1233
 E  in_degree_1234
 G  order_active_lb_1235
 L  order_active_ub_1236
 E  service_visit_def_1237
 E  free_load_conservation_1238
 E  out_degree_1239
 E  in_degree_1240
 G  order_active_lb_1241
 L  order_active_ub_1242
 E  service_visit_def_1243
 E  free_load_conservation_1244
 G  fixed_segment_relative_order_1245
 L  original_T_including_depot_unload_1246
COLUMNS
    t         normalized_mass_15_5  -1
    t         normalized_mass_18_40  -1
    t         normalized_mass_17_77  -1
    t         normalized_mass_19_92  -1
    t         normalized_mass_11_127  -1
    t         normalized_mass_16_136  -1
    t         normalized_mass_20_171  -1
    t         normalized_mass_12_206  -1
    t         normalization_267  1.0353571428571428e+01
    t         full_original_Gini_268  -1.8917857142857137e+01
    q         OBJ       1
    q         parent_nonstrict_scope_210  1
    q         full_original_Gini_268  20
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       6.3380304899829966e-03
    x_15_0    product_lb_0  -3.8960436604218850e-02
    x_15_0    product_ub_1  -9.6585029320551935e-02
    x_15_0    onehot_15_4  1
    x_15_0    parent_nonstrict_scope_210  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_0  1
    w_15_0    product_ub_1  1
    w_15_0    normalized_mass_15_5  1
    w_15_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       -6.3380304899829966e-03
    x_15_1    product_lb_2  -3.8960436604218850e-02
    x_15_1    product_ub_3  -9.6585029320551935e-02
    x_15_1    onehot_15_4  1
    x_15_1    stock_lb_208  1
    x_15_1    stock_ub_209  1
    x_15_1    unique_nonzero_owner_269  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_2  1
    w_15_1    product_ub_3  1
    w_15_1    normalized_mass_15_5  1
    w_15_1    normalized_ratio_15_6  -1
    w_15_1    full_original_Gini_268  -1.8964285714285714e+00
    rho_15    normalized_ratio_15_6  1
    rho_15    block_pair_pos_217  -1
    rho_15    block_pair_neg_218  1
    rho_15    block_pair_pos_219  -1
    rho_15    block_pair_neg_220  1
    rho_15    block_pair_pos_221  -1
    rho_15    block_pair_neg_222  1
    rho_15    block_pair_pos_223  -1
    rho_15    block_pair_neg_224  1
    rho_15    block_pair_pos_225  -1
    rho_15    block_pair_neg_226  1
    rho_15    block_pair_pos_227  -1
    rho_15    block_pair_neg_228  1
    rho_15    block_pair_pos_229  -1
    rho_15    block_pair_neg_230  1
    rho_15    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_7  -3.8960436604218850e-02
    x_18_0    product_ub_8  -9.6585029320551935e-02
    x_18_0    onehot_18_39  1
    x_18_0    parent_nonstrict_scope_210  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_7  1
    w_18_0    product_ub_8  1
    w_18_0    normalized_mass_18_40  1
    w_18_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_9  -3.8960436604218850e-02
    x_18_1    product_ub_10  -9.6585029320551935e-02
    x_18_1    onehot_18_39  1
    x_18_1    stock_lb_208  1
    x_18_1    stock_ub_209  1
    x_18_1    parent_nonstrict_scope_210  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_270  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_9  1
    w_18_1    product_ub_10  1
    w_18_1    normalized_mass_18_40  1
    w_18_1    normalized_ratio_18_41  -1.4285714285714285e-01
    w_18_1    full_original_Gini_268  -8.9250000000000025e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_11  -3.8960436604218850e-02
    x_18_2    product_ub_12  -9.6585029320551935e-02
    x_18_2    onehot_18_39  1
    x_18_2    stock_lb_208  2
    x_18_2    stock_ub_209  2
    x_18_2    parent_nonstrict_scope_210  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_271  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_11  1
    w_18_2    product_ub_12  1
    w_18_2    normalized_mass_18_40  1
    w_18_2    normalized_ratio_18_41  -2.8571428571428570e-01
    w_18_2    full_original_Gini_268  -7.4964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_13  -3.8960436604218850e-02
    x_18_3    product_ub_14  -9.6585029320551935e-02
    x_18_3    onehot_18_39  1
    x_18_3    stock_lb_208  3
    x_18_3    stock_ub_209  3
    x_18_3    parent_nonstrict_scope_210  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_272  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_13  1
    w_18_3    product_ub_14  1
    w_18_3    normalized_mass_18_40  1
    w_18_3    normalized_ratio_18_41  -4.2857142857142855e-01
    w_18_3    full_original_Gini_268  -6.0678571428571413e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_15  -3.8960436604218850e-02
    x_18_4    product_ub_16  -9.6585029320551935e-02
    x_18_4    onehot_18_39  1
    x_18_4    stock_lb_208  4
    x_18_4    stock_ub_209  4
    x_18_4    parent_nonstrict_scope_210  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_273  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_15  1
    w_18_4    product_ub_16  1
    w_18_4    normalized_mass_18_40  1
    w_18_4    normalized_ratio_18_41  -5.7142857142857140e-01
    w_18_4    full_original_Gini_268  -4.9250000000000007e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_17  -3.8960436604218850e-02
    x_18_5    product_ub_18  -9.6585029320551935e-02
    x_18_5    onehot_18_39  1
    x_18_5    stock_lb_208  5
    x_18_5    stock_ub_209  5
    x_18_5    parent_nonstrict_scope_210  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_274  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_17  1
    w_18_5    product_ub_18  1
    w_18_5    normalized_mass_18_40  1
    w_18_5    normalized_ratio_18_41  -7.1428571428571419e-01
    w_18_5    full_original_Gini_268  -3.7821428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_19  -3.8960436604218850e-02
    x_18_6    product_ub_20  -9.6585029320551935e-02
    x_18_6    onehot_18_39  1
    x_18_6    stock_lb_208  6
    x_18_6    stock_ub_209  6
    x_18_6    parent_nonstrict_scope_210  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_275  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_19  1
    w_18_6    product_ub_20  1
    w_18_6    normalized_mass_18_40  1
    w_18_6    normalized_ratio_18_41  -8.5714285714285710e-01
    w_18_6    full_original_Gini_268  -2.7535714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_21  -3.8960436604218850e-02
    x_18_7    product_ub_22  -9.6585029320551935e-02
    x_18_7    onehot_18_39  1
    x_18_7    stock_lb_208  7
    x_18_7    stock_ub_209  7
    x_18_7    unique_nonzero_owner_276  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_21  1
    w_18_7    product_ub_22  1
    w_18_7    normalized_mass_18_40  1
    w_18_7    normalized_ratio_18_41  -1
    w_18_7    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_23  -3.8960436604218850e-02
    x_18_8    product_ub_24  -9.6585029320551935e-02
    x_18_8    onehot_18_39  1
    x_18_8    stock_lb_208  8
    x_18_8    stock_ub_209  8
    x_18_8    parent_nonstrict_scope_210  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_277  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_23  1
    w_18_8    product_ub_24  1
    w_18_8    normalized_mass_18_40  1
    w_18_8    normalized_ratio_18_41  -1.1428571428571428e+00
    w_18_8    full_original_Gini_268  -3.3607142857142849e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_25  -3.8960436604218850e-02
    x_18_9    product_ub_26  -9.6585029320551935e-02
    x_18_9    onehot_18_39  1
    x_18_9    stock_lb_208  9
    x_18_9    stock_ub_209  9
    x_18_9    parent_nonstrict_scope_210  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_278  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_25  1
    w_18_9    product_ub_26  1
    w_18_9    normalized_mass_18_40  1
    w_18_9    normalized_ratio_18_41  -1.2857142857142856e+00
    w_18_9    full_original_Gini_268  -5.0749999999999984e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_27  -3.8960436604218850e-02
    x_18_10   product_ub_28  -9.6585029320551935e-02
    x_18_10   onehot_18_39  1
    x_18_10   stock_lb_208  10
    x_18_10   stock_ub_209  10
    x_18_10   parent_nonstrict_scope_210  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_27  1
    w_18_10   product_ub_28  1
    w_18_10   normalized_mass_18_40  1
    w_18_10   normalized_ratio_18_41  -1.4285714285714284e+00
    w_18_10   full_original_Gini_268  -6.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_29  -3.8960436604218850e-02
    x_18_11   product_ub_30  -9.6585029320551935e-02
    x_18_11   onehot_18_39  1
    x_18_11   stock_lb_208  11
    x_18_11   stock_ub_209  11
    x_18_11   parent_nonstrict_scope_210  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_29  1
    w_18_11   product_ub_30  1
    w_18_11   normalized_mass_18_40  1
    w_18_11   normalized_ratio_18_41  -1.5714285714285714e+00
    w_18_11   full_original_Gini_268  -8.5035714285714263e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_31  -3.8960436604218850e-02
    x_18_12   product_ub_32  -9.6585029320551935e-02
    x_18_12   onehot_18_39  1
    x_18_12   stock_lb_208  12
    x_18_12   stock_ub_209  12
    x_18_12   parent_nonstrict_scope_210  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_31  1
    w_18_12   product_ub_32  1
    w_18_12   normalized_mass_18_40  1
    w_18_12   normalized_ratio_18_41  -1.7142857142857142e+00
    w_18_12   full_original_Gini_268  -1.0217857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_33  -3.8960436604218850e-02
    x_18_13   product_ub_34  -9.6585029320551935e-02
    x_18_13   onehot_18_39  1
    x_18_13   stock_lb_208  13
    x_18_13   stock_ub_209  13
    x_18_13   parent_nonstrict_scope_210  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_33  1
    w_18_13   product_ub_34  1
    w_18_13   normalized_mass_18_40  1
    w_18_13   normalized_ratio_18_41  -1.8571428571428570e+00
    w_18_13   full_original_Gini_268  -1.1932142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_35  -3.8960436604218850e-02
    x_18_14   product_ub_36  -9.6585029320551935e-02
    x_18_14   onehot_18_39  1
    x_18_14   stock_lb_208  14
    x_18_14   stock_ub_209  14
    x_18_14   parent_nonstrict_scope_210  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_35  1
    w_18_14   product_ub_36  1
    w_18_14   normalized_mass_18_40  1
    w_18_14   normalized_ratio_18_41  -2
    w_18_14   full_original_Gini_268  -1.3646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_37  -3.8960436604218850e-02
    x_18_15   product_ub_38  -9.6585029320551935e-02
    x_18_15   onehot_18_39  1
    x_18_15   stock_lb_208  15
    x_18_15   stock_ub_209  15
    x_18_15   parent_nonstrict_scope_210  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_37  1
    w_18_15   product_ub_38  1
    w_18_15   normalized_mass_18_40  1
    w_18_15   normalized_ratio_18_41  -2.1428571428571428e+00
    w_18_15   full_original_Gini_268  -1.5360714285714282e+01
    rho_18    normalized_ratio_18_41  1
    rho_18    block_pair_pos_225  1
    rho_18    block_pair_neg_226  -1
    rho_18    block_pair_pos_245  -1
    rho_18    block_pair_neg_246  1
    rho_18    block_pair_pos_247  -1
    rho_18    block_pair_neg_248  1
    rho_18    block_pair_pos_249  -1
    rho_18    block_pair_neg_250  1
    rho_18    block_pair_pos_251  -1
    rho_18    block_pair_neg_252  1
    rho_18    block_pair_pos_253  -1
    rho_18    block_pair_neg_254  1
    rho_18    block_pair_pos_255  -1
    rho_18    block_pair_neg_256  1
    rho_18    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_42  -3.8960436604218850e-02
    x_17_0    product_ub_43  -9.6585029320551935e-02
    x_17_0    onehot_17_76  1
    x_17_0    parent_nonstrict_scope_210  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_42  1
    w_17_0    product_ub_43  1
    w_17_0    normalized_mass_17_77  1
    w_17_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_44  -3.8960436604218850e-02
    x_17_1    product_ub_45  -9.6585029320551935e-02
    x_17_1    onehot_17_76  1
    x_17_1    stock_lb_208  1
    x_17_1    stock_ub_209  1
    x_17_1    parent_nonstrict_scope_210  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_44  1
    w_17_1    product_ub_45  1
    w_17_1    normalized_mass_17_77  1
    w_17_1    normalized_ratio_17_78  -1.1111111111111110e-01
    w_17_1    full_original_Gini_268  -9.2424603174603170e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_46  -3.8960436604218850e-02
    x_17_2    product_ub_47  -9.6585029320551935e-02
    x_17_2    onehot_17_76  1
    x_17_2    stock_lb_208  2
    x_17_2    stock_ub_209  2
    x_17_2    parent_nonstrict_scope_210  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_46  1
    w_17_2    product_ub_47  1
    w_17_2    normalized_mass_17_77  1
    w_17_2    normalized_ratio_17_78  -2.2222222222222221e-01
    w_17_2    full_original_Gini_268  -8.1313492063492063e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_48  -3.8960436604218850e-02
    x_17_3    product_ub_49  -9.6585029320551935e-02
    x_17_3    onehot_17_76  1
    x_17_3    stock_lb_208  3
    x_17_3    stock_ub_209  3
    x_17_3    parent_nonstrict_scope_210  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_48  1
    w_17_3    product_ub_49  1
    w_17_3    normalized_mass_17_77  1
    w_17_3    normalized_ratio_17_78  -3.3333333333333331e-01
    w_17_3    full_original_Gini_268  -7.0202380952380974e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_50  -3.8960436604218850e-02
    x_17_4    product_ub_51  -9.6585029320551935e-02
    x_17_4    onehot_17_76  1
    x_17_4    stock_lb_208  4
    x_17_4    stock_ub_209  4
    x_17_4    parent_nonstrict_scope_210  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_50  1
    w_17_4    product_ub_51  1
    w_17_4    normalized_mass_17_77  1
    w_17_4    normalized_ratio_17_78  -4.4444444444444442e-01
    w_17_4    full_original_Gini_268  -5.9408730158730148e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_52  -3.8960436604218850e-02
    x_17_5    product_ub_53  -9.6585029320551935e-02
    x_17_5    onehot_17_76  1
    x_17_5    stock_lb_208  5
    x_17_5    stock_ub_209  5
    x_17_5    parent_nonstrict_scope_210  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_52  1
    w_17_5    product_ub_53  1
    w_17_5    normalized_mass_17_77  1
    w_17_5    normalized_ratio_17_78  -5.5555555555555558e-01
    w_17_5    full_original_Gini_268  -5.0519841269841272e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_54  -3.8960436604218850e-02
    x_17_6    product_ub_55  -9.6585029320551935e-02
    x_17_6    onehot_17_76  1
    x_17_6    stock_lb_208  6
    x_17_6    stock_ub_209  6
    x_17_6    parent_nonstrict_scope_210  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_54  1
    w_17_6    product_ub_55  1
    w_17_6    normalized_mass_17_77  1
    w_17_6    normalized_ratio_17_78  -6.6666666666666663e-01
    w_17_6    full_original_Gini_268  -4.1630952380952388e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_56  -3.8960436604218850e-02
    x_17_7    product_ub_57  -9.6585029320551935e-02
    x_17_7    onehot_17_76  1
    x_17_7    stock_lb_208  7
    x_17_7    stock_ub_209  7
    x_17_7    parent_nonstrict_scope_210  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_56  1
    w_17_7    product_ub_57  1
    w_17_7    normalized_mass_17_77  1
    w_17_7    normalized_ratio_17_78  -7.7777777777777768e-01
    w_17_7    full_original_Gini_268  -3.27420634920635
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_58  -3.8960436604218850e-02
    x_17_8    product_ub_59  -9.6585029320551935e-02
    x_17_8    onehot_17_76  1
    x_17_8    stock_lb_208  8
    x_17_8    stock_ub_209  8
    x_17_8    parent_nonstrict_scope_210  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_58  1
    w_17_8    product_ub_59  1
    w_17_8    normalized_mass_17_77  1
    w_17_8    normalized_ratio_17_78  -8.8888888888888884e-01
    w_17_8    full_original_Gini_268  -2.5630952380952383e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_60  -3.8960436604218850e-02
    x_17_9    product_ub_61  -9.6585029320551935e-02
    x_17_9    onehot_17_76  1
    x_17_9    stock_lb_208  9
    x_17_9    stock_ub_209  9
    x_17_9    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_60  1
    w_17_9    product_ub_61  1
    w_17_9    normalized_mass_17_77  1
    w_17_9    normalized_ratio_17_78  -1
    w_17_9    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_62  -3.8960436604218850e-02
    x_17_10   product_ub_63  -9.6585029320551935e-02
    x_17_10   onehot_17_76  1
    x_17_10   stock_lb_208  10
    x_17_10   stock_ub_209  10
    x_17_10   parent_nonstrict_scope_210  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_62  1
    w_17_10   product_ub_63  1
    w_17_10   normalized_mass_17_77  1
    w_17_10   normalized_ratio_17_78  -1.1111111111111112e+00
    w_17_10   full_original_Gini_268  -3.0075396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_64  -3.8960436604218850e-02
    x_17_11   product_ub_65  -9.6585029320551935e-02
    x_17_11   onehot_17_76  1
    x_17_11   stock_lb_208  11
    x_17_11   stock_ub_209  11
    x_17_11   parent_nonstrict_scope_210  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_64  1
    w_17_11   product_ub_65  1
    w_17_11   normalized_mass_17_77  1
    w_17_11   normalized_ratio_17_78  -1.2222222222222221e+00
    w_17_11   full_original_Gini_268  -4.3130952380952374e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_66  -3.8960436604218850e-02
    x_17_12   product_ub_67  -9.6585029320551935e-02
    x_17_12   onehot_17_76  1
    x_17_12   stock_lb_208  12
    x_17_12   stock_ub_209  12
    x_17_12   parent_nonstrict_scope_210  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_66  1
    w_17_12   product_ub_67  1
    w_17_12   normalized_mass_17_77  1
    w_17_12   normalized_ratio_17_78  -1.3333333333333333e+00
    w_17_12   full_original_Gini_268  -5.64642857142857
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_68  -3.8960436604218850e-02
    x_17_13   product_ub_69  -9.6585029320551935e-02
    x_17_13   onehot_17_76  1
    x_17_13   stock_lb_208  13
    x_17_13   stock_ub_209  13
    x_17_13   parent_nonstrict_scope_210  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_68  1
    w_17_13   product_ub_69  1
    w_17_13   normalized_mass_17_77  1
    w_17_13   normalized_ratio_17_78  -1.4444444444444444e+00
    w_17_13   full_original_Gini_268  -6.9797619047619053e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_70  -3.8960436604218850e-02
    x_17_14   product_ub_71  -9.6585029320551935e-02
    x_17_14   onehot_17_76  1
    x_17_14   stock_lb_208  14
    x_17_14   stock_ub_209  14
    x_17_14   parent_nonstrict_scope_210  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_70  1
    w_17_14   product_ub_71  1
    w_17_14   normalized_mass_17_77  1
    w_17_14   normalized_ratio_17_78  -1.5555555555555554e+00
    w_17_14   full_original_Gini_268  -8.3130952380952365e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_72  -3.8960436604218850e-02
    x_17_15   product_ub_73  -9.6585029320551935e-02
    x_17_15   onehot_17_76  1
    x_17_15   stock_lb_208  15
    x_17_15   stock_ub_209  15
    x_17_15   parent_nonstrict_scope_210  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_72  1
    w_17_15   product_ub_73  1
    w_17_15   normalized_mass_17_77  1
    w_17_15   normalized_ratio_17_78  -1.6666666666666665e+00
    w_17_15   full_original_Gini_268  -9.6464285714285687e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_74  -3.8960436604218850e-02
    x_17_16   product_ub_75  -9.6585029320551935e-02
    x_17_16   onehot_17_76  1
    x_17_16   stock_lb_208  16
    x_17_16   stock_ub_209  16
    x_17_16   parent_nonstrict_scope_210  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_74  1
    w_17_16   product_ub_75  1
    w_17_16   normalized_mass_17_77  1
    w_17_16   normalized_ratio_17_78  -1.7777777777777777e+00
    w_17_16   full_original_Gini_268  -1.0979761904761904e+01
    rho_17    normalized_ratio_17_78  1
    rho_17    block_pair_pos_223  1
    rho_17    block_pair_neg_224  -1
    rho_17    block_pair_pos_235  -1
    rho_17    block_pair_neg_236  1
    rho_17    block_pair_pos_237  -1
    rho_17    block_pair_neg_238  1
    rho_17    block_pair_pos_239  -1
    rho_17    block_pair_neg_240  1
    rho_17    block_pair_pos_241  -1
    rho_17    block_pair_neg_242  1
    rho_17    block_pair_pos_243  -1
    rho_17    block_pair_neg_244  1
    rho_17    block_pair_pos_251  1
    rho_17    block_pair_neg_252  -1
    rho_17    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       3.1690152449914983e-03
    x_19_0    product_lb_79  -3.8960436604218850e-02
    x_19_0    product_ub_80  -9.6585029320551935e-02
    x_19_0    onehot_19_91  1
    x_19_0    parent_nonstrict_scope_210  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_79  1
    w_19_0    product_ub_80  1
    w_19_0    normalized_mass_19_92  1
    w_19_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       -3.1690152449914983e-03
    x_19_1    product_lb_81  -3.8960436604218850e-02
    x_19_1    product_ub_82  -9.6585029320551935e-02
    x_19_1    onehot_19_91  1
    x_19_1    stock_lb_208  1
    x_19_1    stock_ub_209  1
    x_19_1    parent_nonstrict_scope_210  6.3380304899829966e-03
    x_19_1    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_81  1
    w_19_1    product_ub_82  1
    w_19_1    normalized_mass_19_92  1
    w_19_1    normalized_ratio_19_93  -0.5
    w_19_1    full_original_Gini_268  -5.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_2    OBJ       -9.5070457349744949e-03
    x_19_2    product_lb_83  -3.8960436604218850e-02
    x_19_2    product_ub_84  -9.6585029320551935e-02
    x_19_2    onehot_19_91  1
    x_19_2    stock_lb_208  2
    x_19_2    stock_ub_209  2
    x_19_2    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_83  1
    w_19_2    product_ub_84  1
    w_19_2    normalized_mass_19_92  1
    w_19_2    normalized_ratio_19_93  -1
    w_19_2    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -3.1690152449914983e-03
    x_19_3    product_lb_85  -3.8960436604218850e-02
    x_19_3    product_ub_86  -9.6585029320551935e-02
    x_19_3    onehot_19_91  1
    x_19_3    stock_lb_208  3
    x_19_3    stock_ub_209  3
    x_19_3    parent_nonstrict_scope_210  6.3380304899829966e-03
    x_19_3    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_85  1
    w_19_3    product_ub_86  1
    w_19_3    normalized_mass_19_92  1
    w_19_3    normalized_ratio_19_93  -1.5
    w_19_3    full_original_Gini_268  -7.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       3.1690152449914983e-03
    x_19_4    product_lb_87  -3.8960436604218850e-02
    x_19_4    product_ub_88  -9.6585029320551935e-02
    x_19_4    onehot_19_91  1
    x_19_4    stock_lb_208  4
    x_19_4    stock_ub_209  4
    x_19_4    parent_nonstrict_scope_210  1.2676060979965993e-02
    x_19_4    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_87  1
    w_19_4    product_ub_88  1
    w_19_4    normalized_mass_19_92  1
    w_19_4    normalized_ratio_19_93  -2
    w_19_4    full_original_Gini_268  -1.3646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       9.5070457349744949e-03
    x_19_5    product_lb_89  -3.8960436604218850e-02
    x_19_5    product_ub_90  -9.6585029320551935e-02
    x_19_5    onehot_19_91  1
    x_19_5    stock_lb_208  5
    x_19_5    stock_ub_209  5
    x_19_5    parent_nonstrict_scope_210  1.9014091469948990e-02
    x_19_5    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_89  1
    w_19_5    product_ub_90  1
    w_19_5    normalized_mass_19_92  1
    w_19_5    normalized_ratio_19_93  -2.5
    w_19_5    full_original_Gini_268  -1.9646428571428572e+01
    rho_19    normalized_ratio_19_93  1
    rho_19    block_pair_pos_227  1
    rho_19    block_pair_neg_228  -1
    rho_19    block_pair_pos_241  1
    rho_19    block_pair_neg_242  -1
    rho_19    block_pair_pos_253  1
    rho_19    block_pair_neg_254  -1
    rho_19    block_pair_pos_257  -1
    rho_19    block_pair_neg_258  1
    rho_19    block_pair_pos_259  -1
    rho_19    block_pair_neg_260  1
    rho_19    block_pair_pos_261  -1
    rho_19    block_pair_neg_262  1
    rho_19    block_pair_pos_263  -1
    rho_19    block_pair_neg_264  1
    rho_19    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_94  -3.8960436604218850e-02
    x_11_0    product_ub_95  -9.6585029320551935e-02
    x_11_0    onehot_11_126  1
    x_11_0    parent_nonstrict_scope_210  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_94  1
    w_11_0    product_ub_95  1
    w_11_0    normalized_mass_11_127  1
    w_11_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_96  -3.8960436604218850e-02
    x_11_1    product_ub_97  -9.6585029320551935e-02
    x_11_1    onehot_11_126  1
    x_11_1    stock_lb_208  1
    x_11_1    stock_ub_209  1
    x_11_1    parent_nonstrict_scope_210  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_96  1
    w_11_1    product_ub_97  1
    w_11_1    normalized_mass_11_127  1
    w_11_1    normalized_ratio_11_128  -0.125
    w_11_1    full_original_Gini_268  -9.1035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_98  -3.8960436604218850e-02
    x_11_2    product_ub_99  -9.6585029320551935e-02
    x_11_2    onehot_11_126  1
    x_11_2    stock_lb_208  2
    x_11_2    stock_ub_209  2
    x_11_2    parent_nonstrict_scope_210  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_98  1
    w_11_2    product_ub_99  1
    w_11_2    normalized_mass_11_127  1
    w_11_2    normalized_ratio_11_128  -0.25
    w_11_2    full_original_Gini_268  -7.8535714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_100  -3.8960436604218850e-02
    x_11_3    product_ub_101  -9.6585029320551935e-02
    x_11_3    onehot_11_126  1
    x_11_3    stock_lb_208  3
    x_11_3    stock_ub_209  3
    x_11_3    parent_nonstrict_scope_210  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_100  1
    w_11_3    product_ub_101  1
    w_11_3    normalized_mass_11_127  1
    w_11_3    normalized_ratio_11_128  -0.375
    w_11_3    full_original_Gini_268  -6.6035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_102  -3.8960436604218850e-02
    x_11_4    product_ub_103  -9.6585029320551935e-02
    x_11_4    onehot_11_126  1
    x_11_4    stock_lb_208  4
    x_11_4    stock_ub_209  4
    x_11_4    parent_nonstrict_scope_210  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_102  1
    w_11_4    product_ub_103  1
    w_11_4    normalized_mass_11_127  1
    w_11_4    normalized_ratio_11_128  -0.5
    w_11_4    full_original_Gini_268  -5.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_104  -3.8960436604218850e-02
    x_11_5    product_ub_105  -9.6585029320551935e-02
    x_11_5    onehot_11_126  1
    x_11_5    stock_lb_208  5
    x_11_5    stock_ub_209  5
    x_11_5    parent_nonstrict_scope_210  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_104  1
    w_11_5    product_ub_105  1
    w_11_5    normalized_mass_11_127  1
    w_11_5    normalized_ratio_11_128  -0.625
    w_11_5    full_original_Gini_268  -4.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_106  -3.8960436604218850e-02
    x_11_6    product_ub_107  -9.6585029320551935e-02
    x_11_6    onehot_11_126  1
    x_11_6    stock_lb_208  6
    x_11_6    stock_ub_209  6
    x_11_6    parent_nonstrict_scope_210  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_106  1
    w_11_6    product_ub_107  1
    w_11_6    normalized_mass_11_127  1
    w_11_6    normalized_ratio_11_128  -0.75
    w_11_6    full_original_Gini_268  -3.4964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_108  -3.8960436604218850e-02
    x_11_7    product_ub_109  -9.6585029320551935e-02
    x_11_7    onehot_11_126  1
    x_11_7    stock_lb_208  7
    x_11_7    stock_ub_209  7
    x_11_7    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_108  1
    w_11_7    product_ub_109  1
    w_11_7    normalized_mass_11_127  1
    w_11_7    normalized_ratio_11_128  -0.875
    w_11_7    full_original_Gini_268  -2.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_110  -3.8960436604218850e-02
    x_11_8    product_ub_111  -9.6585029320551935e-02
    x_11_8    onehot_11_126  1
    x_11_8    stock_lb_208  8
    x_11_8    stock_ub_209  8
    x_11_8    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_110  1
    w_11_8    product_ub_111  1
    w_11_8    normalized_mass_11_127  1
    w_11_8    normalized_ratio_11_128  -1
    w_11_8    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_112  -3.8960436604218850e-02
    x_11_9    product_ub_113  -9.6585029320551935e-02
    x_11_9    onehot_11_126  1
    x_11_9    stock_lb_208  9
    x_11_9    stock_ub_209  9
    x_11_9    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_112  1
    w_11_9    product_ub_113  1
    w_11_9    normalized_mass_11_127  1
    w_11_9    normalized_ratio_11_128  -1.125
    w_11_9    full_original_Gini_268  -3.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_114  -3.8960436604218850e-02
    x_11_10   product_ub_115  -9.6585029320551935e-02
    x_11_10   onehot_11_126  1
    x_11_10   stock_lb_208  10
    x_11_10   stock_ub_209  10
    x_11_10   parent_nonstrict_scope_210  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_114  1
    w_11_10   product_ub_115  1
    w_11_10   normalized_mass_11_127  1
    w_11_10   normalized_ratio_11_128  -1.25
    w_11_10   full_original_Gini_268  -4.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_116  -3.8960436604218850e-02
    x_11_11   product_ub_117  -9.6585029320551935e-02
    x_11_11   onehot_11_126  1
    x_11_11   stock_lb_208  11
    x_11_11   stock_ub_209  11
    x_11_11   parent_nonstrict_scope_210  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_116  1
    w_11_11   product_ub_117  1
    w_11_11   normalized_mass_11_127  1
    w_11_11   normalized_ratio_11_128  -1.375
    w_11_11   full_original_Gini_268  -6.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_118  -3.8960436604218850e-02
    x_11_12   product_ub_119  -9.6585029320551935e-02
    x_11_12   onehot_11_126  1
    x_11_12   stock_lb_208  12
    x_11_12   stock_ub_209  12
    x_11_12   parent_nonstrict_scope_210  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_118  1
    w_11_12   product_ub_119  1
    w_11_12   normalized_mass_11_127  1
    w_11_12   normalized_ratio_11_128  -1.5
    w_11_12   full_original_Gini_268  -7.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_120  -3.8960436604218850e-02
    x_11_13   product_ub_121  -9.6585029320551935e-02
    x_11_13   onehot_11_126  1
    x_11_13   stock_lb_208  13
    x_11_13   stock_ub_209  13
    x_11_13   parent_nonstrict_scope_210  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_120  1
    w_11_13   product_ub_121  1
    w_11_13   normalized_mass_11_127  1
    w_11_13   normalized_ratio_11_128  -1.625
    w_11_13   full_original_Gini_268  -9.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_122  -3.8960436604218850e-02
    x_11_14   product_ub_123  -9.6585029320551935e-02
    x_11_14   onehot_11_126  1
    x_11_14   stock_lb_208  14
    x_11_14   stock_ub_209  14
    x_11_14   parent_nonstrict_scope_210  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_122  1
    w_11_14   product_ub_123  1
    w_11_14   normalized_mass_11_127  1
    w_11_14   normalized_ratio_11_128  -1.75
    w_11_14   full_original_Gini_268  -1.0646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_124  -3.8960436604218850e-02
    x_11_15   product_ub_125  -9.6585029320551935e-02
    x_11_15   onehot_11_126  1
    x_11_15   stock_lb_208  15
    x_11_15   stock_ub_209  15
    x_11_15   parent_nonstrict_scope_210  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_124  1
    w_11_15   product_ub_125  1
    w_11_15   normalized_mass_11_127  1
    w_11_15   normalized_ratio_11_128  -1.875
    w_11_15   full_original_Gini_268  -1.2146428571428572e+01
    rho_11    normalized_ratio_11_128  1
    rho_11    block_pair_pos_211  -1
    rho_11    block_pair_neg_212  1
    rho_11    block_pair_pos_213  -1
    rho_11    block_pair_neg_214  1
    rho_11    block_pair_pos_215  -1
    rho_11    block_pair_neg_216  1
    rho_11    block_pair_pos_217  1
    rho_11    block_pair_neg_218  -1
    rho_11    block_pair_pos_235  1
    rho_11    block_pair_neg_236  -1
    rho_11    block_pair_pos_245  1
    rho_11    block_pair_neg_246  -1
    rho_11    block_pair_pos_257  1
    rho_11    block_pair_neg_258  -1
    rho_11    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       6.3380304899829966e-03
    x_16_0    product_lb_129  -3.8960436604218850e-02
    x_16_0    product_ub_130  -9.6585029320551935e-02
    x_16_0    onehot_16_135  1
    x_16_0    parent_nonstrict_scope_210  1.2676060979965993e-02
    x_16_0    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_129  1
    w_16_0    product_ub_130  1
    w_16_0    normalized_mass_16_136  1
    w_16_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       -6.3380304899829966e-03
    x_16_1    product_lb_131  -3.8960436604218850e-02
    x_16_1    product_ub_132  -9.6585029320551935e-02
    x_16_1    onehot_16_135  1
    x_16_1    stock_lb_208  1
    x_16_1    stock_ub_209  1
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_131  1
    w_16_1    product_ub_132  1
    w_16_1    normalized_mass_16_136  1
    w_16_1    normalized_ratio_16_137  -1
    w_16_1    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       6.3380304899829966e-03
    x_16_2    product_lb_133  -3.8960436604218850e-02
    x_16_2    product_ub_134  -9.6585029320551935e-02
    x_16_2    onehot_16_135  1
    x_16_2    stock_lb_208  2
    x_16_2    stock_ub_209  2
    x_16_2    parent_nonstrict_scope_210  1.2676060979965993e-02
    x_16_2    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_133  1
    w_16_2    product_ub_134  1
    w_16_2    normalized_mass_16_136  1
    w_16_2    normalized_ratio_16_137  -2
    w_16_2    full_original_Gini_268  -1.3646428571428572e+01
    rho_16    normalized_ratio_16_137  1
    rho_16    block_pair_pos_213  1
    rho_16    block_pair_neg_214  -1
    rho_16    block_pair_pos_221  1
    rho_16    block_pair_neg_222  -1
    rho_16    block_pair_pos_231  -1
    rho_16    block_pair_neg_232  1
    rho_16    block_pair_pos_233  -1
    rho_16    block_pair_neg_234  1
    rho_16    block_pair_pos_239  1
    rho_16    block_pair_neg_240  -1
    rho_16    block_pair_pos_249  1
    rho_16    block_pair_neg_250  -1
    rho_16    block_pair_pos_261  1
    rho_16    block_pair_neg_262  -1
    rho_16    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_138  -3.8960436604218850e-02
    x_20_0    product_ub_139  -9.6585029320551935e-02
    x_20_0    onehot_20_170  1
    x_20_0    parent_nonstrict_scope_210  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_138  1
    w_20_0    product_ub_139  1
    w_20_0    normalized_mass_20_171  1
    w_20_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_140  -3.8960436604218850e-02
    x_20_1    product_ub_141  -9.6585029320551935e-02
    x_20_1    onehot_20_170  1
    x_20_1    stock_lb_208  1
    x_20_1    stock_ub_209  1
    x_20_1    parent_nonstrict_scope_210  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_140  1
    w_20_1    product_ub_141  1
    w_20_1    normalized_mass_20_171  1
    w_20_1    normalized_ratio_20_172  -0.125
    w_20_1    full_original_Gini_268  -9.1035714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_142  -3.8960436604218850e-02
    x_20_2    product_ub_143  -9.6585029320551935e-02
    x_20_2    onehot_20_170  1
    x_20_2    stock_lb_208  2
    x_20_2    stock_ub_209  2
    x_20_2    parent_nonstrict_scope_210  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_142  1
    w_20_2    product_ub_143  1
    w_20_2    normalized_mass_20_171  1
    w_20_2    normalized_ratio_20_172  -0.25
    w_20_2    full_original_Gini_268  -7.8535714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_144  -3.8960436604218850e-02
    x_20_3    product_ub_145  -9.6585029320551935e-02
    x_20_3    onehot_20_170  1
    x_20_3    stock_lb_208  3
    x_20_3    stock_ub_209  3
    x_20_3    parent_nonstrict_scope_210  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_144  1
    w_20_3    product_ub_145  1
    w_20_3    normalized_mass_20_171  1
    w_20_3    normalized_ratio_20_172  -0.375
    w_20_3    full_original_Gini_268  -6.6035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_146  -3.8960436604218850e-02
    x_20_4    product_ub_147  -9.6585029320551935e-02
    x_20_4    onehot_20_170  1
    x_20_4    stock_lb_208  4
    x_20_4    stock_ub_209  4
    x_20_4    parent_nonstrict_scope_210  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_146  1
    w_20_4    product_ub_147  1
    w_20_4    normalized_mass_20_171  1
    w_20_4    normalized_ratio_20_172  -0.5
    w_20_4    full_original_Gini_268  -5.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_148  -3.8960436604218850e-02
    x_20_5    product_ub_149  -9.6585029320551935e-02
    x_20_5    onehot_20_170  1
    x_20_5    stock_lb_208  5
    x_20_5    stock_ub_209  5
    x_20_5    parent_nonstrict_scope_210  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_148  1
    w_20_5    product_ub_149  1
    w_20_5    normalized_mass_20_171  1
    w_20_5    normalized_ratio_20_172  -0.625
    w_20_5    full_original_Gini_268  -4.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_150  -3.8960436604218850e-02
    x_20_6    product_ub_151  -9.6585029320551935e-02
    x_20_6    onehot_20_170  1
    x_20_6    stock_lb_208  6
    x_20_6    stock_ub_209  6
    x_20_6    parent_nonstrict_scope_210  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_150  1
    w_20_6    product_ub_151  1
    w_20_6    normalized_mass_20_171  1
    w_20_6    normalized_ratio_20_172  -0.75
    w_20_6    full_original_Gini_268  -3.4964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_152  -3.8960436604218850e-02
    x_20_7    product_ub_153  -9.6585029320551935e-02
    x_20_7    onehot_20_170  1
    x_20_7    stock_lb_208  7
    x_20_7    stock_ub_209  7
    x_20_7    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_152  1
    w_20_7    product_ub_153  1
    w_20_7    normalized_mass_20_171  1
    w_20_7    normalized_ratio_20_172  -0.875
    w_20_7    full_original_Gini_268  -2.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_154  -3.8960436604218850e-02
    x_20_8    product_ub_155  -9.6585029320551935e-02
    x_20_8    onehot_20_170  1
    x_20_8    stock_lb_208  8
    x_20_8    stock_ub_209  8
    x_20_8    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_154  1
    w_20_8    product_ub_155  1
    w_20_8    normalized_mass_20_171  1
    w_20_8    normalized_ratio_20_172  -1
    w_20_8    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_156  -3.8960436604218850e-02
    x_20_9    product_ub_157  -9.6585029320551935e-02
    x_20_9    onehot_20_170  1
    x_20_9    stock_lb_208  9
    x_20_9    stock_ub_209  9
    x_20_9    parent_nonstrict_scope_210  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_156  1
    w_20_9    product_ub_157  1
    w_20_9    normalized_mass_20_171  1
    w_20_9    normalized_ratio_20_172  -1.125
    w_20_9    full_original_Gini_268  -3.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_158  -3.8960436604218850e-02
    x_20_10   product_ub_159  -9.6585029320551935e-02
    x_20_10   onehot_20_170  1
    x_20_10   stock_lb_208  10
    x_20_10   stock_ub_209  10
    x_20_10   parent_nonstrict_scope_210  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_158  1
    w_20_10   product_ub_159  1
    w_20_10   normalized_mass_20_171  1
    w_20_10   normalized_ratio_20_172  -1.25
    w_20_10   full_original_Gini_268  -4.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_160  -3.8960436604218850e-02
    x_20_11   product_ub_161  -9.6585029320551935e-02
    x_20_11   onehot_20_170  1
    x_20_11   stock_lb_208  11
    x_20_11   stock_ub_209  11
    x_20_11   parent_nonstrict_scope_210  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_160  1
    w_20_11   product_ub_161  1
    w_20_11   normalized_mass_20_171  1
    w_20_11   normalized_ratio_20_172  -1.375
    w_20_11   full_original_Gini_268  -6.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_162  -3.8960436604218850e-02
    x_20_12   product_ub_163  -9.6585029320551935e-02
    x_20_12   onehot_20_170  1
    x_20_12   stock_lb_208  12
    x_20_12   stock_ub_209  12
    x_20_12   parent_nonstrict_scope_210  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_162  1
    w_20_12   product_ub_163  1
    w_20_12   normalized_mass_20_171  1
    w_20_12   normalized_ratio_20_172  -1.5
    w_20_12   full_original_Gini_268  -7.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_164  -3.8960436604218850e-02
    x_20_13   product_ub_165  -9.6585029320551935e-02
    x_20_13   onehot_20_170  1
    x_20_13   stock_lb_208  13
    x_20_13   stock_ub_209  13
    x_20_13   parent_nonstrict_scope_210  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_164  1
    w_20_13   product_ub_165  1
    w_20_13   normalized_mass_20_171  1
    w_20_13   normalized_ratio_20_172  -1.625
    w_20_13   full_original_Gini_268  -9.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_166  -3.8960436604218850e-02
    x_20_14   product_ub_167  -9.6585029320551935e-02
    x_20_14   onehot_20_170  1
    x_20_14   stock_lb_208  14
    x_20_14   stock_ub_209  14
    x_20_14   parent_nonstrict_scope_210  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_166  1
    w_20_14   product_ub_167  1
    w_20_14   normalized_mass_20_171  1
    w_20_14   normalized_ratio_20_172  -1.75
    w_20_14   full_original_Gini_268  -1.0646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_168  -3.8960436604218850e-02
    x_20_15   product_ub_169  -9.6585029320551935e-02
    x_20_15   onehot_20_170  1
    x_20_15   stock_lb_208  15
    x_20_15   stock_ub_209  15
    x_20_15   parent_nonstrict_scope_210  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_168  1
    w_20_15   product_ub_169  1
    w_20_15   normalized_mass_20_171  1
    w_20_15   normalized_ratio_20_172  -1.875
    w_20_15   full_original_Gini_268  -1.2146428571428572e+01
    rho_20    normalized_ratio_20_172  1
    rho_20    block_pair_pos_215  1
    rho_20    block_pair_neg_216  -1
    rho_20    block_pair_pos_229  1
    rho_20    block_pair_neg_230  -1
    rho_20    block_pair_pos_233  1
    rho_20    block_pair_neg_234  -1
    rho_20    block_pair_pos_243  1
    rho_20    block_pair_neg_244  -1
    rho_20    block_pair_pos_255  1
    rho_20    block_pair_neg_256  -1
    rho_20    block_pair_pos_263  1
    rho_20    block_pair_neg_264  -1
    rho_20    block_pair_pos_265  -1
    rho_20    block_pair_neg_266  1
    rho_20    normalization_267  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_173  -3.8960436604218850e-02
    x_12_0    product_ub_174  -9.6585029320551935e-02
    x_12_0    onehot_12_205  1
    x_12_0    parent_nonstrict_scope_210  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_173  1
    w_12_0    product_ub_174  1
    w_12_0    normalized_mass_12_206  1
    w_12_0    full_original_Gini_268  -1.0353571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_175  -3.8960436604218850e-02
    x_12_1    product_ub_176  -9.6585029320551935e-02
    x_12_1    onehot_12_205  1
    x_12_1    stock_lb_208  1
    x_12_1    stock_ub_209  1
    x_12_1    parent_nonstrict_scope_210  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_175  1
    w_12_1    product_ub_176  1
    w_12_1    normalized_mass_12_206  1
    w_12_1    normalized_ratio_12_207  -1.4285714285714285e-01
    w_12_1    full_original_Gini_268  -8.9250000000000025e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_177  -3.8960436604218850e-02
    x_12_2    product_ub_178  -9.6585029320551935e-02
    x_12_2    onehot_12_205  1
    x_12_2    stock_lb_208  2
    x_12_2    stock_ub_209  2
    x_12_2    parent_nonstrict_scope_210  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_177  1
    w_12_2    product_ub_178  1
    w_12_2    normalized_mass_12_206  1
    w_12_2    normalized_ratio_12_207  -2.8571428571428570e-01
    w_12_2    full_original_Gini_268  -7.4964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_179  -3.8960436604218850e-02
    x_12_3    product_ub_180  -9.6585029320551935e-02
    x_12_3    onehot_12_205  1
    x_12_3    stock_lb_208  3
    x_12_3    stock_ub_209  3
    x_12_3    parent_nonstrict_scope_210  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_179  1
    w_12_3    product_ub_180  1
    w_12_3    normalized_mass_12_206  1
    w_12_3    normalized_ratio_12_207  -4.2857142857142855e-01
    w_12_3    full_original_Gini_268  -6.0678571428571413e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_181  -3.8960436604218850e-02
    x_12_4    product_ub_182  -9.6585029320551935e-02
    x_12_4    onehot_12_205  1
    x_12_4    stock_lb_208  4
    x_12_4    stock_ub_209  4
    x_12_4    parent_nonstrict_scope_210  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_181  1
    w_12_4    product_ub_182  1
    w_12_4    normalized_mass_12_206  1
    w_12_4    normalized_ratio_12_207  -5.7142857142857140e-01
    w_12_4    full_original_Gini_268  -4.9250000000000007e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_183  -3.8960436604218850e-02
    x_12_5    product_ub_184  -9.6585029320551935e-02
    x_12_5    onehot_12_205  1
    x_12_5    stock_lb_208  5
    x_12_5    stock_ub_209  5
    x_12_5    parent_nonstrict_scope_210  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_183  1
    w_12_5    product_ub_184  1
    w_12_5    normalized_mass_12_206  1
    w_12_5    normalized_ratio_12_207  -7.1428571428571419e-01
    w_12_5    full_original_Gini_268  -3.7821428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_185  -3.8960436604218850e-02
    x_12_6    product_ub_186  -9.6585029320551935e-02
    x_12_6    onehot_12_205  1
    x_12_6    stock_lb_208  6
    x_12_6    stock_ub_209  6
    x_12_6    parent_nonstrict_scope_210  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_185  1
    w_12_6    product_ub_186  1
    w_12_6    normalized_mass_12_206  1
    w_12_6    normalized_ratio_12_207  -8.5714285714285710e-01
    w_12_6    full_original_Gini_268  -2.7535714285714281e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_187  -3.8960436604218850e-02
    x_12_7    product_ub_188  -9.6585029320551935e-02
    x_12_7    onehot_12_205  1
    x_12_7    stock_lb_208  7
    x_12_7    stock_ub_209  7
    x_12_7    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_187  1
    w_12_7    product_ub_188  1
    w_12_7    normalized_mass_12_206  1
    w_12_7    normalized_ratio_12_207  -1
    w_12_7    full_original_Gini_268  -1.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_189  -3.8960436604218850e-02
    x_12_8    product_ub_190  -9.6585029320551935e-02
    x_12_8    onehot_12_205  1
    x_12_8    stock_lb_208  8
    x_12_8    stock_ub_209  8
    x_12_8    parent_nonstrict_scope_210  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_189  1
    w_12_8    product_ub_190  1
    w_12_8    normalized_mass_12_206  1
    w_12_8    normalized_ratio_12_207  -1.1428571428571428e+00
    w_12_8    full_original_Gini_268  -3.3607142857142849e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_191  -3.8960436604218850e-02
    x_12_9    product_ub_192  -9.6585029320551935e-02
    x_12_9    onehot_12_205  1
    x_12_9    stock_lb_208  9
    x_12_9    stock_ub_209  9
    x_12_9    parent_nonstrict_scope_210  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_191  1
    w_12_9    product_ub_192  1
    w_12_9    normalized_mass_12_206  1
    w_12_9    normalized_ratio_12_207  -1.2857142857142856e+00
    w_12_9    full_original_Gini_268  -5.0749999999999984e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_193  -3.8960436604218850e-02
    x_12_10   product_ub_194  -9.6585029320551935e-02
    x_12_10   onehot_12_205  1
    x_12_10   stock_lb_208  10
    x_12_10   stock_ub_209  10
    x_12_10   parent_nonstrict_scope_210  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_193  1
    w_12_10   product_ub_194  1
    w_12_10   normalized_mass_12_206  1
    w_12_10   normalized_ratio_12_207  -1.4285714285714284e+00
    w_12_10   full_original_Gini_268  -6.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_195  -3.8960436604218850e-02
    x_12_11   product_ub_196  -9.6585029320551935e-02
    x_12_11   onehot_12_205  1
    x_12_11   stock_lb_208  11
    x_12_11   stock_ub_209  11
    x_12_11   parent_nonstrict_scope_210  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_195  1
    w_12_11   product_ub_196  1
    w_12_11   normalized_mass_12_206  1
    w_12_11   normalized_ratio_12_207  -1.5714285714285714e+00
    w_12_11   full_original_Gini_268  -8.5035714285714263e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_197  -3.8960436604218850e-02
    x_12_12   product_ub_198  -9.6585029320551935e-02
    x_12_12   onehot_12_205  1
    x_12_12   stock_lb_208  12
    x_12_12   stock_ub_209  12
    x_12_12   parent_nonstrict_scope_210  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_197  1
    w_12_12   product_ub_198  1
    w_12_12   normalized_mass_12_206  1
    w_12_12   normalized_ratio_12_207  -1.7142857142857142e+00
    w_12_12   full_original_Gini_268  -1.0217857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_199  -3.8960436604218850e-02
    x_12_13   product_ub_200  -9.6585029320551935e-02
    x_12_13   onehot_12_205  1
    x_12_13   stock_lb_208  13
    x_12_13   stock_ub_209  13
    x_12_13   parent_nonstrict_scope_210  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_199  1
    w_12_13   product_ub_200  1
    w_12_13   normalized_mass_12_206  1
    w_12_13   normalized_ratio_12_207  -1.8571428571428570e+00
    w_12_13   full_original_Gini_268  -1.1932142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_201  -3.8960436604218850e-02
    x_12_14   product_ub_202  -9.6585029320551935e-02
    x_12_14   onehot_12_205  1
    x_12_14   stock_lb_208  14
    x_12_14   stock_ub_209  14
    x_12_14   parent_nonstrict_scope_210  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_201  1
    w_12_14   product_ub_202  1
    w_12_14   normalized_mass_12_206  1
    w_12_14   normalized_ratio_12_207  -2
    w_12_14   full_original_Gini_268  -1.3646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_203  -3.8960436604218850e-02
    x_12_15   product_ub_204  -9.6585029320551935e-02
    x_12_15   onehot_12_205  1
    x_12_15   stock_lb_208  15
    x_12_15   stock_ub_209  15
    x_12_15   parent_nonstrict_scope_210  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_203  1
    w_12_15   product_ub_204  1
    w_12_15   normalized_mass_12_206  1
    w_12_15   normalized_ratio_12_207  -2.1428571428571428e+00
    w_12_15   full_original_Gini_268  -1.5360714285714282e+01
    rho_12    normalized_ratio_12_207  1
    rho_12    block_pair_pos_211  1
    rho_12    block_pair_neg_212  -1
    rho_12    block_pair_pos_219  1
    rho_12    block_pair_neg_220  -1
    rho_12    block_pair_pos_231  1
    rho_12    block_pair_neg_232  -1
    rho_12    block_pair_pos_237  1
    rho_12    block_pair_neg_238  -1
    rho_12    block_pair_pos_247  1
    rho_12    block_pair_neg_248  -1
    rho_12    block_pair_pos_259  1
    rho_12    block_pair_neg_260  -1
    rho_12    block_pair_pos_265  1
    rho_12    block_pair_neg_266  -1
    rho_12    normalization_267  1
    a_15_18   block_pair_pos_225  1
    a_15_18   block_pair_neg_226  1
    a_15_18   full_original_Gini_268  -1
    a_15_17   block_pair_pos_223  1
    a_15_17   block_pair_neg_224  1
    a_15_17   full_original_Gini_268  -1
    a_15_19   block_pair_pos_227  1
    a_15_19   block_pair_neg_228  1
    a_15_19   full_original_Gini_268  -1
    a_15_11   block_pair_pos_217  1
    a_15_11   block_pair_neg_218  1
    a_15_11   full_original_Gini_268  -1
    a_15_16   block_pair_pos_221  1
    a_15_16   block_pair_neg_222  1
    a_15_16   full_original_Gini_268  -1
    a_15_20   block_pair_pos_229  1
    a_15_20   block_pair_neg_230  1
    a_15_20   full_original_Gini_268  -1
    a_15_12   block_pair_pos_219  1
    a_15_12   block_pair_neg_220  1
    a_15_12   full_original_Gini_268  -1
    a_18_17   block_pair_pos_251  1
    a_18_17   block_pair_neg_252  1
    a_18_17   full_original_Gini_268  -1
    a_18_19   block_pair_pos_253  1
    a_18_19   block_pair_neg_254  1
    a_18_19   full_original_Gini_268  -1
    a_18_11   block_pair_pos_245  1
    a_18_11   block_pair_neg_246  1
    a_18_11   full_original_Gini_268  -1
    a_18_16   block_pair_pos_249  1
    a_18_16   block_pair_neg_250  1
    a_18_16   full_original_Gini_268  -1
    a_18_20   block_pair_pos_255  1
    a_18_20   block_pair_neg_256  1
    a_18_20   full_original_Gini_268  -1
    a_18_12   block_pair_pos_247  1
    a_18_12   block_pair_neg_248  1
    a_18_12   full_original_Gini_268  -1
    a_17_19   block_pair_pos_241  1
    a_17_19   block_pair_neg_242  1
    a_17_19   full_original_Gini_268  -1
    a_17_11   block_pair_pos_235  1
    a_17_11   block_pair_neg_236  1
    a_17_11   full_original_Gini_268  -1
    a_17_16   block_pair_pos_239  1
    a_17_16   block_pair_neg_240  1
    a_17_16   full_original_Gini_268  -1
    a_17_20   block_pair_pos_243  1
    a_17_20   block_pair_neg_244  1
    a_17_20   full_original_Gini_268  -1
    a_17_12   block_pair_pos_237  1
    a_17_12   block_pair_neg_238  1
    a_17_12   full_original_Gini_268  -1
    a_19_11   block_pair_pos_257  1
    a_19_11   block_pair_neg_258  1
    a_19_11   full_original_Gini_268  -1
    a_19_16   block_pair_pos_261  1
    a_19_16   block_pair_neg_262  1
    a_19_16   full_original_Gini_268  -1
    a_19_20   block_pair_pos_263  1
    a_19_20   block_pair_neg_264  1
    a_19_20   full_original_Gini_268  -1
    a_19_12   block_pair_pos_259  1
    a_19_12   block_pair_neg_260  1
    a_19_12   full_original_Gini_268  -1
    a_11_16   block_pair_pos_213  1
    a_11_16   block_pair_neg_214  1
    a_11_16   full_original_Gini_268  -1
    a_11_20   block_pair_pos_215  1
    a_11_20   block_pair_neg_216  1
    a_11_20   full_original_Gini_268  -1
    a_11_12   block_pair_pos_211  1
    a_11_12   block_pair_neg_212  1
    a_11_12   full_original_Gini_268  -1
    a_16_20   block_pair_pos_233  1
    a_16_20   block_pair_neg_234  1
    a_16_20   full_original_Gini_268  -1
    a_16_12   block_pair_pos_231  1
    a_16_12   block_pair_neg_232  1
    a_16_12   full_original_Gini_268  -1
    a_20_12   block_pair_pos_265  1
    a_20_12   block_pair_neg_266  1
    a_20_12   full_original_Gini_268  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_15_1  unique_nonzero_owner_269  1
    service_0_15_1  service_visit_def_928  1
    service_0_15_1  free_load_conservation_929  1
    service_1_15_1  unique_nonzero_owner_269  1
    service_1_15_1  service_visit_def_1201  1
    service_1_15_1  free_load_conservation_1202  1
    service_0_18_1  unique_nonzero_owner_270  1
    service_0_18_1  service_visit_def_934  1
    service_0_18_1  free_load_conservation_935  1
    service_0_18_2  unique_nonzero_owner_271  1
    service_0_18_2  service_visit_def_934  1
    service_0_18_2  free_load_conservation_935  2
    service_0_18_3  unique_nonzero_owner_272  1
    service_0_18_3  service_visit_def_934  1
    service_0_18_3  free_load_conservation_935  3
    service_0_18_4  unique_nonzero_owner_273  1
    service_0_18_4  service_visit_def_934  1
    service_0_18_4  free_load_conservation_935  4
    service_0_18_5  unique_nonzero_owner_274  1
    service_0_18_5  service_visit_def_934  1
    service_0_18_5  free_load_conservation_935  5
    service_0_18_6  unique_nonzero_owner_275  1
    service_0_18_6  service_visit_def_934  1
    service_0_18_6  free_load_conservation_935  6
    service_0_18_7  unique_nonzero_owner_276  1
    service_0_18_7  service_visit_def_934  1
    service_0_18_7  free_load_conservation_935  7
    service_0_18_8  unique_nonzero_owner_277  1
    service_0_18_8  service_visit_def_934  1
    service_0_18_8  free_load_conservation_935  8
    service_0_18_9  unique_nonzero_owner_278  1
    service_0_18_9  service_visit_def_934  1
    service_0_18_9  free_load_conservation_935  9
    service_0_18_10  unique_nonzero_owner_279  1
    service_0_18_10  service_visit_def_934  1
    service_0_18_10  free_load_conservation_935  10
    service_0_18_11  unique_nonzero_owner_280  1
    service_0_18_11  service_visit_def_934  1
    service_0_18_11  free_load_conservation_935  11
    service_0_18_12  unique_nonzero_owner_281  1
    service_0_18_12  service_visit_def_934  1
    service_0_18_12  free_load_conservation_935  12
    service_0_18_13  unique_nonzero_owner_282  1
    service_0_18_13  service_visit_def_934  1
    service_0_18_13  free_load_conservation_935  13
    service_0_18_14  unique_nonzero_owner_283  1
    service_0_18_14  service_visit_def_934  1
    service_0_18_14  free_load_conservation_935  14
    service_0_18_15  unique_nonzero_owner_284  1
    service_0_18_15  service_visit_def_934  1
    service_0_18_15  free_load_conservation_935  15
    service_1_18_1  unique_nonzero_owner_270  1
    service_1_18_1  service_visit_def_1207  1
    service_1_18_1  free_load_conservation_1208  1
    service_1_18_2  unique_nonzero_owner_271  1
    service_1_18_2  service_visit_def_1207  1
    service_1_18_2  free_load_conservation_1208  2
    service_1_18_3  unique_nonzero_owner_272  1
    service_1_18_3  service_visit_def_1207  1
    service_1_18_3  free_load_conservation_1208  3
    service_1_18_4  unique_nonzero_owner_273  1
    service_1_18_4  service_visit_def_1207  1
    service_1_18_4  free_load_conservation_1208  4
    service_1_18_5  unique_nonzero_owner_274  1
    service_1_18_5  service_visit_def_1207  1
    service_1_18_5  free_load_conservation_1208  5
    service_1_18_6  unique_nonzero_owner_275  1
    service_1_18_6  service_visit_def_1207  1
    service_1_18_6  free_load_conservation_1208  6
    service_1_18_7  unique_nonzero_owner_276  1
    service_1_18_7  service_visit_def_1207  1
    service_1_18_7  free_load_conservation_1208  7
    service_1_18_8  unique_nonzero_owner_277  1
    service_1_18_8  service_visit_def_1207  1
    service_1_18_8  free_load_conservation_1208  8
    service_1_18_9  unique_nonzero_owner_278  1
    service_1_18_9  service_visit_def_1207  1
    service_1_18_9  free_load_conservation_1208  9
    service_1_18_10  unique_nonzero_owner_279  1
    service_1_18_10  service_visit_def_1207  1
    service_1_18_10  free_load_conservation_1208  10
    service_1_18_11  unique_nonzero_owner_280  1
    service_1_18_11  service_visit_def_1207  1
    service_1_18_11  free_load_conservation_1208  11
    service_1_18_12  unique_nonzero_owner_281  1
    service_1_18_12  service_visit_def_1207  1
    service_1_18_12  free_load_conservation_1208  12
    service_1_18_13  unique_nonzero_owner_282  1
    service_1_18_13  service_visit_def_1207  1
    service_1_18_13  free_load_conservation_1208  13
    service_1_18_14  unique_nonzero_owner_283  1
    service_1_18_14  service_visit_def_1207  1
    service_1_18_14  free_load_conservation_1208  14
    service_1_18_15  unique_nonzero_owner_284  1
    service_1_18_15  service_visit_def_1207  1
    service_1_18_15  free_load_conservation_1208  15
    service_0_17_0  unique_nonzero_owner_285  1
    service_0_17_0  service_visit_def_940  1
    service_0_17_0  free_load_conservation_941  -3
    service_0_17_0  original_T_including_depot_unload_979  360
    service_0_17_1  unique_nonzero_owner_286  1
    service_0_17_1  service_visit_def_940  1
    service_0_17_1  free_load_conservation_941  -2
    service_0_17_1  original_T_including_depot_unload_979  240
    service_0_17_2  unique_nonzero_owner_287  1
    service_0_17_2  service_visit_def_940  1
    service_0_17_2  free_load_conservation_941  -1
    service_0_17_2  original_T_including_depot_unload_979  120
    service_0_17_4  unique_nonzero_owner_288  1
    service_0_17_4  service_visit_def_940  1
    service_0_17_4  free_load_conservation_941  1
    service_0_17_5  unique_nonzero_owner_289  1
    service_0_17_5  service_visit_def_940  1
    service_0_17_5  free_load_conservation_941  2
    service_0_17_6  unique_nonzero_owner_290  1
    service_0_17_6  service_visit_def_940  1
    service_0_17_6  free_load_conservation_941  3
    service_0_17_7  unique_nonzero_owner_291  1
    service_0_17_7  service_visit_def_940  1
    service_0_17_7  free_load_conservation_941  4
    service_0_17_8  unique_nonzero_owner_292  1
    service_0_17_8  service_visit_def_940  1
    service_0_17_8  free_load_conservation_941  5
    service_0_17_9  unique_nonzero_owner_293  1
    service_0_17_9  service_visit_def_940  1
    service_0_17_9  free_load_conservation_941  6
    service_0_17_10  unique_nonzero_owner_294  1
    service_0_17_10  service_visit_def_940  1
    service_0_17_10  free_load_conservation_941  7
    service_0_17_11  unique_nonzero_owner_295  1
    service_0_17_11  service_visit_def_940  1
    service_0_17_11  free_load_conservation_941  8
    service_0_17_12  unique_nonzero_owner_296  1
    service_0_17_12  service_visit_def_940  1
    service_0_17_12  free_load_conservation_941  9
    service_0_17_13  unique_nonzero_owner_297  1
    service_0_17_13  service_visit_def_940  1
    service_0_17_13  free_load_conservation_941  10
    service_0_17_14  unique_nonzero_owner_298  1
    service_0_17_14  service_visit_def_940  1
    service_0_17_14  free_load_conservation_941  11
    service_0_17_15  unique_nonzero_owner_299  1
    service_0_17_15  service_visit_def_940  1
    service_0_17_15  free_load_conservation_941  12
    service_0_17_16  unique_nonzero_owner_300  1
    service_0_17_16  service_visit_def_940  1
    service_0_17_16  free_load_conservation_941  13
    service_1_17_0  unique_nonzero_owner_285  1
    service_1_17_0  service_visit_def_1213  1
    service_1_17_0  free_load_conservation_1214  -3
    service_1_17_0  original_T_including_depot_unload_1246  360
    service_1_17_1  unique_nonzero_owner_286  1
    service_1_17_1  service_visit_def_1213  1
    service_1_17_1  free_load_conservation_1214  -2
    service_1_17_1  original_T_including_depot_unload_1246  240
    service_1_17_2  unique_nonzero_owner_287  1
    service_1_17_2  service_visit_def_1213  1
    service_1_17_2  free_load_conservation_1214  -1
    service_1_17_2  original_T_including_depot_unload_1246  120
    service_1_17_4  unique_nonzero_owner_288  1
    service_1_17_4  service_visit_def_1213  1
    service_1_17_4  free_load_conservation_1214  1
    service_1_17_5  unique_nonzero_owner_289  1
    service_1_17_5  service_visit_def_1213  1
    service_1_17_5  free_load_conservation_1214  2
    service_1_17_6  unique_nonzero_owner_290  1
    service_1_17_6  service_visit_def_1213  1
    service_1_17_6  free_load_conservation_1214  3
    service_1_17_7  unique_nonzero_owner_291  1
    service_1_17_7  service_visit_def_1213  1
    service_1_17_7  free_load_conservation_1214  4
    service_1_17_8  unique_nonzero_owner_292  1
    service_1_17_8  service_visit_def_1213  1
    service_1_17_8  free_load_conservation_1214  5
    service_1_17_9  unique_nonzero_owner_293  1
    service_1_17_9  service_visit_def_1213  1
    service_1_17_9  free_load_conservation_1214  6
    service_1_17_10  unique_nonzero_owner_294  1
    service_1_17_10  service_visit_def_1213  1
    service_1_17_10  free_load_conservation_1214  7
    service_1_17_11  unique_nonzero_owner_295  1
    service_1_17_11  service_visit_def_1213  1
    service_1_17_11  free_load_conservation_1214  8
    service_1_17_12  unique_nonzero_owner_296  1
    service_1_17_12  service_visit_def_1213  1
    service_1_17_12  free_load_conservation_1214  9
    service_1_17_13  unique_nonzero_owner_297  1
    service_1_17_13  service_visit_def_1213  1
    service_1_17_13  free_load_conservation_1214  10
    service_1_17_14  unique_nonzero_owner_298  1
    service_1_17_14  service_visit_def_1213  1
    service_1_17_14  free_load_conservation_1214  11
    service_1_17_15  unique_nonzero_owner_299  1
    service_1_17_15  service_visit_def_1213  1
    service_1_17_15  free_load_conservation_1214  12
    service_1_17_16  unique_nonzero_owner_300  1
    service_1_17_16  service_visit_def_1213  1
    service_1_17_16  free_load_conservation_1214  13
    service_0_19_1  unique_nonzero_owner_301  1
    service_0_19_1  service_visit_def_946  1
    service_0_19_1  free_load_conservation_947  1
    service_0_19_2  unique_nonzero_owner_302  1
    service_0_19_2  service_visit_def_946  1
    service_0_19_2  free_load_conservation_947  2
    service_0_19_3  unique_nonzero_owner_303  1
    service_0_19_3  service_visit_def_946  1
    service_0_19_3  free_load_conservation_947  3
    service_0_19_4  unique_nonzero_owner_304  1
    service_0_19_4  service_visit_def_946  1
    service_0_19_4  free_load_conservation_947  4
    service_0_19_5  unique_nonzero_owner_305  1
    service_0_19_5  service_visit_def_946  1
    service_0_19_5  free_load_conservation_947  5
    service_1_19_1  unique_nonzero_owner_301  1
    service_1_19_1  service_visit_def_1219  1
    service_1_19_1  free_load_conservation_1220  1
    service_1_19_2  unique_nonzero_owner_302  1
    service_1_19_2  service_visit_def_1219  1
    service_1_19_2  free_load_conservation_1220  2
    service_1_19_3  unique_nonzero_owner_303  1
    service_1_19_3  service_visit_def_1219  1
    service_1_19_3  free_load_conservation_1220  3
    service_1_19_4  unique_nonzero_owner_304  1
    service_1_19_4  service_visit_def_1219  1
    service_1_19_4  free_load_conservation_1220  4
    service_1_19_5  unique_nonzero_owner_305  1
    service_1_19_5  service_visit_def_1219  1
    service_1_19_5  free_load_conservation_1220  5
    service_0_11_0  unique_nonzero_owner_306  1
    service_0_11_0  service_visit_def_952  1
    service_0_11_0  free_load_conservation_953  -1
    service_0_11_0  original_T_including_depot_unload_979  120
    service_0_11_2  unique_nonzero_owner_307  1
    service_0_11_2  service_visit_def_952  1
    service_0_11_2  free_load_conservation_953  1
    service_0_11_3  unique_nonzero_owner_308  1
    service_0_11_3  service_visit_def_952  1
    service_0_11_3  free_load_conservation_953  2
    service_0_11_4  unique_nonzero_owner_309  1
    service_0_11_4  service_visit_def_952  1
    service_0_11_4  free_load_conservation_953  3
    service_0_11_5  unique_nonzero_owner_310  1
    service_0_11_5  service_visit_def_952  1
    service_0_11_5  free_load_conservation_953  4
    service_0_11_6  unique_nonzero_owner_311  1
    service_0_11_6  service_visit_def_952  1
    service_0_11_6  free_load_conservation_953  5
    service_0_11_7  unique_nonzero_owner_312  1
    service_0_11_7  service_visit_def_952  1
    service_0_11_7  free_load_conservation_953  6
    service_0_11_8  unique_nonzero_owner_313  1
    service_0_11_8  service_visit_def_952  1
    service_0_11_8  free_load_conservation_953  7
    service_0_11_9  unique_nonzero_owner_314  1
    service_0_11_9  service_visit_def_952  1
    service_0_11_9  free_load_conservation_953  8
    service_0_11_10  unique_nonzero_owner_315  1
    service_0_11_10  service_visit_def_952  1
    service_0_11_10  free_load_conservation_953  9
    service_0_11_11  unique_nonzero_owner_316  1
    service_0_11_11  service_visit_def_952  1
    service_0_11_11  free_load_conservation_953  10
    service_0_11_12  unique_nonzero_owner_317  1
    service_0_11_12  service_visit_def_952  1
    service_0_11_12  free_load_conservation_953  11
    service_0_11_13  unique_nonzero_owner_318  1
    service_0_11_13  service_visit_def_952  1
    service_0_11_13  free_load_conservation_953  12
    service_0_11_14  unique_nonzero_owner_319  1
    service_0_11_14  service_visit_def_952  1
    service_0_11_14  free_load_conservation_953  13
    service_0_11_15  unique_nonzero_owner_320  1
    service_0_11_15  service_visit_def_952  1
    service_0_11_15  free_load_conservation_953  14
    service_1_11_0  unique_nonzero_owner_306  1
    service_1_11_0  service_visit_def_1225  1
    service_1_11_0  free_load_conservation_1226  -1
    service_1_11_0  original_T_including_depot_unload_1246  120
    service_1_11_2  unique_nonzero_owner_307  1
    service_1_11_2  service_visit_def_1225  1
    service_1_11_2  free_load_conservation_1226  1
    service_1_11_3  unique_nonzero_owner_308  1
    service_1_11_3  service_visit_def_1225  1
    service_1_11_3  free_load_conservation_1226  2
    service_1_11_4  unique_nonzero_owner_309  1
    service_1_11_4  service_visit_def_1225  1
    service_1_11_4  free_load_conservation_1226  3
    service_1_11_5  unique_nonzero_owner_310  1
    service_1_11_5  service_visit_def_1225  1
    service_1_11_5  free_load_conservation_1226  4
    service_1_11_6  unique_nonzero_owner_311  1
    service_1_11_6  service_visit_def_1225  1
    service_1_11_6  free_load_conservation_1226  5
    service_1_11_7  unique_nonzero_owner_312  1
    service_1_11_7  service_visit_def_1225  1
    service_1_11_7  free_load_conservation_1226  6
    service_1_11_8  unique_nonzero_owner_313  1
    service_1_11_8  service_visit_def_1225  1
    service_1_11_8  free_load_conservation_1226  7
    service_1_11_9  unique_nonzero_owner_314  1
    service_1_11_9  service_visit_def_1225  1
    service_1_11_9  free_load_conservation_1226  8
    service_1_11_10  unique_nonzero_owner_315  1
    service_1_11_10  service_visit_def_1225  1
    service_1_11_10  free_load_conservation_1226  9
    service_1_11_11  unique_nonzero_owner_316  1
    service_1_11_11  service_visit_def_1225  1
    service_1_11_11  free_load_conservation_1226  10
    service_1_11_12  unique_nonzero_owner_317  1
    service_1_11_12  service_visit_def_1225  1
    service_1_11_12  free_load_conservation_1226  11
    service_1_11_13  unique_nonzero_owner_318  1
    service_1_11_13  service_visit_def_1225  1
    service_1_11_13  free_load_conservation_1226  12
    service_1_11_14  unique_nonzero_owner_319  1
    service_1_11_14  service_visit_def_1225  1
    service_1_11_14  free_load_conservation_1226  13
    service_1_11_15  unique_nonzero_owner_320  1
    service_1_11_15  service_visit_def_1225  1
    service_1_11_15  free_load_conservation_1226  14
    service_0_16_0  unique_nonzero_owner_321  1
    service_0_16_0  service_visit_def_958  1
    service_0_16_0  free_load_conservation_959  -1
    service_0_16_0  original_T_including_depot_unload_979  120
    service_0_16_2  unique_nonzero_owner_322  1
    service_0_16_2  service_visit_def_958  1
    service_0_16_2  free_load_conservation_959  1
    service_1_16_0  unique_nonzero_owner_321  1
    service_1_16_0  service_visit_def_1231  1
    service_1_16_0  free_load_conservation_1232  -1
    service_1_16_0  original_T_including_depot_unload_1246  120
    service_1_16_2  unique_nonzero_owner_322  1
    service_1_16_2  service_visit_def_1231  1
    service_1_16_2  free_load_conservation_1232  1
    service_0_20_0  unique_nonzero_owner_323  1
    service_0_20_0  service_visit_def_964  1
    service_0_20_0  free_load_conservation_965  -12
    service_0_20_0  original_T_including_depot_unload_979  1440
    service_0_20_1  unique_nonzero_owner_324  1
    service_0_20_1  service_visit_def_964  1
    service_0_20_1  free_load_conservation_965  -11
    service_0_20_1  original_T_including_depot_unload_979  1320
    service_0_20_2  unique_nonzero_owner_325  1
    service_0_20_2  service_visit_def_964  1
    service_0_20_2  free_load_conservation_965  -10
    service_0_20_2  original_T_including_depot_unload_979  1200
    service_0_20_3  unique_nonzero_owner_326  1
    service_0_20_3  service_visit_def_964  1
    service_0_20_3  free_load_conservation_965  -9
    service_0_20_3  original_T_including_depot_unload_979  1080
    service_0_20_4  unique_nonzero_owner_327  1
    service_0_20_4  service_visit_def_964  1
    service_0_20_4  free_load_conservation_965  -8
    service_0_20_4  original_T_including_depot_unload_979  960
    service_0_20_5  unique_nonzero_owner_328  1
    service_0_20_5  service_visit_def_964  1
    service_0_20_5  free_load_conservation_965  -7
    service_0_20_5  original_T_including_depot_unload_979  840
    service_0_20_6  unique_nonzero_owner_329  1
    service_0_20_6  service_visit_def_964  1
    service_0_20_6  free_load_conservation_965  -6
    service_0_20_6  original_T_including_depot_unload_979  720
    service_0_20_7  unique_nonzero_owner_330  1
    service_0_20_7  service_visit_def_964  1
    service_0_20_7  free_load_conservation_965  -5
    service_0_20_7  original_T_including_depot_unload_979  600
    service_0_20_8  unique_nonzero_owner_331  1
    service_0_20_8  service_visit_def_964  1
    service_0_20_8  free_load_conservation_965  -4
    service_0_20_8  original_T_including_depot_unload_979  480
    service_0_20_9  unique_nonzero_owner_332  1
    service_0_20_9  service_visit_def_964  1
    service_0_20_9  free_load_conservation_965  -3
    service_0_20_9  original_T_including_depot_unload_979  360
    service_0_20_10  unique_nonzero_owner_333  1
    service_0_20_10  service_visit_def_964  1
    service_0_20_10  free_load_conservation_965  -2
    service_0_20_10  original_T_including_depot_unload_979  240
    service_0_20_11  unique_nonzero_owner_334  1
    service_0_20_11  service_visit_def_964  1
    service_0_20_11  free_load_conservation_965  -1
    service_0_20_11  original_T_including_depot_unload_979  120
    service_0_20_13  unique_nonzero_owner_335  1
    service_0_20_13  service_visit_def_964  1
    service_0_20_13  free_load_conservation_965  1
    service_0_20_14  unique_nonzero_owner_336  1
    service_0_20_14  service_visit_def_964  1
    service_0_20_14  free_load_conservation_965  2
    service_0_20_15  unique_nonzero_owner_337  1
    service_0_20_15  service_visit_def_964  1
    service_0_20_15  free_load_conservation_965  3
    service_1_20_0  unique_nonzero_owner_323  1
    service_1_20_0  service_visit_def_1237  1
    service_1_20_0  free_load_conservation_1238  -12
    service_1_20_0  original_T_including_depot_unload_1246  1440
    service_1_20_1  unique_nonzero_owner_324  1
    service_1_20_1  service_visit_def_1237  1
    service_1_20_1  free_load_conservation_1238  -11
    service_1_20_1  original_T_including_depot_unload_1246  1320
    service_1_20_2  unique_nonzero_owner_325  1
    service_1_20_2  service_visit_def_1237  1
    service_1_20_2  free_load_conservation_1238  -10
    service_1_20_2  original_T_including_depot_unload_1246  1200
    service_1_20_3  unique_nonzero_owner_326  1
    service_1_20_3  service_visit_def_1237  1
    service_1_20_3  free_load_conservation_1238  -9
    service_1_20_3  original_T_including_depot_unload_1246  1080
    service_1_20_4  unique_nonzero_owner_327  1
    service_1_20_4  service_visit_def_1237  1
    service_1_20_4  free_load_conservation_1238  -8
    service_1_20_4  original_T_including_depot_unload_1246  960
    service_1_20_5  unique_nonzero_owner_328  1
    service_1_20_5  service_visit_def_1237  1
    service_1_20_5  free_load_conservation_1238  -7
    service_1_20_5  original_T_including_depot_unload_1246  840
    service_1_20_6  unique_nonzero_owner_329  1
    service_1_20_6  service_visit_def_1237  1
    service_1_20_6  free_load_conservation_1238  -6
    service_1_20_6  original_T_including_depot_unload_1246  720
    service_1_20_7  unique_nonzero_owner_330  1
    service_1_20_7  service_visit_def_1237  1
    service_1_20_7  free_load_conservation_1238  -5
    service_1_20_7  original_T_including_depot_unload_1246  600
    service_1_20_8  unique_nonzero_owner_331  1
    service_1_20_8  service_visit_def_1237  1
    service_1_20_8  free_load_conservation_1238  -4
    service_1_20_8  original_T_including_depot_unload_1246  480
    service_1_20_9  unique_nonzero_owner_332  1
    service_1_20_9  service_visit_def_1237  1
    service_1_20_9  free_load_conservation_1238  -3
    service_1_20_9  original_T_including_depot_unload_1246  360
    service_1_20_10  unique_nonzero_owner_333  1
    service_1_20_10  service_visit_def_1237  1
    service_1_20_10  free_load_conservation_1238  -2
    service_1_20_10  original_T_including_depot_unload_1246  240
    service_1_20_11  unique_nonzero_owner_334  1
    service_1_20_11  service_visit_def_1237  1
    service_1_20_11  free_load_conservation_1238  -1
    service_1_20_11  original_T_including_depot_unload_1246  120
    service_1_20_13  unique_nonzero_owner_335  1
    service_1_20_13  service_visit_def_1237  1
    service_1_20_13  free_load_conservation_1238  1
    service_1_20_14  unique_nonzero_owner_336  1
    service_1_20_14  service_visit_def_1237  1
    service_1_20_14  free_load_conservation_1238  2
    service_1_20_15  unique_nonzero_owner_337  1
    service_1_20_15  service_visit_def_1237  1
    service_1_20_15  free_load_conservation_1238  3
    service_0_12_0  unique_nonzero_owner_338  1
    service_0_12_0  service_visit_def_970  1
    service_0_12_0  free_load_conservation_971  -11
    service_0_12_0  original_T_including_depot_unload_979  1320
    service_0_12_1  unique_nonzero_owner_339  1
    service_0_12_1  service_visit_def_970  1
    service_0_12_1  free_load_conservation_971  -10
    service_0_12_1  original_T_including_depot_unload_979  1200
    service_0_12_2  unique_nonzero_owner_340  1
    service_0_12_2  service_visit_def_970  1
    service_0_12_2  free_load_conservation_971  -9
    service_0_12_2  original_T_including_depot_unload_979  1080
    service_0_12_3  unique_nonzero_owner_341  1
    service_0_12_3  service_visit_def_970  1
    service_0_12_3  free_load_conservation_971  -8
    service_0_12_3  original_T_including_depot_unload_979  960
    service_0_12_4  unique_nonzero_owner_342  1
    service_0_12_4  service_visit_def_970  1
    service_0_12_4  free_load_conservation_971  -7
    service_0_12_4  original_T_including_depot_unload_979  840
    service_0_12_5  unique_nonzero_owner_343  1
    service_0_12_5  service_visit_def_970  1
    service_0_12_5  free_load_conservation_971  -6
    service_0_12_5  original_T_including_depot_unload_979  720
    service_0_12_6  unique_nonzero_owner_344  1
    service_0_12_6  service_visit_def_970  1
    service_0_12_6  free_load_conservation_971  -5
    service_0_12_6  original_T_including_depot_unload_979  600
    service_0_12_7  unique_nonzero_owner_345  1
    service_0_12_7  service_visit_def_970  1
    service_0_12_7  free_load_conservation_971  -4
    service_0_12_7  original_T_including_depot_unload_979  480
    service_0_12_8  unique_nonzero_owner_346  1
    service_0_12_8  service_visit_def_970  1
    service_0_12_8  free_load_conservation_971  -3
    service_0_12_8  original_T_including_depot_unload_979  360
    service_0_12_9  unique_nonzero_owner_347  1
    service_0_12_9  service_visit_def_970  1
    service_0_12_9  free_load_conservation_971  -2
    service_0_12_9  original_T_including_depot_unload_979  240
    service_0_12_10  unique_nonzero_owner_348  1
    service_0_12_10  service_visit_def_970  1
    service_0_12_10  free_load_conservation_971  -1
    service_0_12_10  original_T_including_depot_unload_979  120
    service_0_12_12  unique_nonzero_owner_349  1
    service_0_12_12  service_visit_def_970  1
    service_0_12_12  free_load_conservation_971  1
    service_0_12_13  unique_nonzero_owner_350  1
    service_0_12_13  service_visit_def_970  1
    service_0_12_13  free_load_conservation_971  2
    service_0_12_14  unique_nonzero_owner_351  1
    service_0_12_14  service_visit_def_970  1
    service_0_12_14  free_load_conservation_971  3
    service_0_12_15  unique_nonzero_owner_352  1
    service_0_12_15  service_visit_def_970  1
    service_0_12_15  free_load_conservation_971  4
    service_1_12_0  unique_nonzero_owner_338  1
    service_1_12_0  service_visit_def_1243  1
    service_1_12_0  free_load_conservation_1244  -11
    service_1_12_0  original_T_including_depot_unload_1246  1320
    service_1_12_1  unique_nonzero_owner_339  1
    service_1_12_1  service_visit_def_1243  1
    service_1_12_1  free_load_conservation_1244  -10
    service_1_12_1  original_T_including_depot_unload_1246  1200
    service_1_12_2  unique_nonzero_owner_340  1
    service_1_12_2  service_visit_def_1243  1
    service_1_12_2  free_load_conservation_1244  -9
    service_1_12_2  original_T_including_depot_unload_1246  1080
    service_1_12_3  unique_nonzero_owner_341  1
    service_1_12_3  service_visit_def_1243  1
    service_1_12_3  free_load_conservation_1244  -8
    service_1_12_3  original_T_including_depot_unload_1246  960
    service_1_12_4  unique_nonzero_owner_342  1
    service_1_12_4  service_visit_def_1243  1
    service_1_12_4  free_load_conservation_1244  -7
    service_1_12_4  original_T_including_depot_unload_1246  840
    service_1_12_5  unique_nonzero_owner_343  1
    service_1_12_5  service_visit_def_1243  1
    service_1_12_5  free_load_conservation_1244  -6
    service_1_12_5  original_T_including_depot_unload_1246  720
    service_1_12_6  unique_nonzero_owner_344  1
    service_1_12_6  service_visit_def_1243  1
    service_1_12_6  free_load_conservation_1244  -5
    service_1_12_6  original_T_including_depot_unload_1246  600
    service_1_12_7  unique_nonzero_owner_345  1
    service_1_12_7  service_visit_def_1243  1
    service_1_12_7  free_load_conservation_1244  -4
    service_1_12_7  original_T_including_depot_unload_1246  480
    service_1_12_8  unique_nonzero_owner_346  1
    service_1_12_8  service_visit_def_1243  1
    service_1_12_8  free_load_conservation_1244  -3
    service_1_12_8  original_T_including_depot_unload_1246  360
    service_1_12_9  unique_nonzero_owner_347  1
    service_1_12_9  service_visit_def_1243  1
    service_1_12_9  free_load_conservation_1244  -2
    service_1_12_9  original_T_including_depot_unload_1246  240
    service_1_12_10  unique_nonzero_owner_348  1
    service_1_12_10  service_visit_def_1243  1
    service_1_12_10  free_load_conservation_1244  -1
    service_1_12_10  original_T_including_depot_unload_1246  120
    service_1_12_12  unique_nonzero_owner_349  1
    service_1_12_12  service_visit_def_1243  1
    service_1_12_12  free_load_conservation_1244  1
    service_1_12_13  unique_nonzero_owner_350  1
    service_1_12_13  service_visit_def_1243  1
    service_1_12_13  free_load_conservation_1244  2
    service_1_12_14  unique_nonzero_owner_351  1
    service_1_12_14  service_visit_def_1243  1
    service_1_12_14  free_load_conservation_1244  3
    service_1_12_15  unique_nonzero_owner_352  1
    service_1_12_15  service_visit_def_1243  1
    service_1_12_15  free_load_conservation_1244  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_868  -1
    visit_0_1  in_degree_869  -1
    visit_0_1  order_active_lb_870  -1
    visit_0_1  order_active_ub_871  -16
    order_0_1  connected_order_arc_372  -1
    order_0_1  connected_order_arc_374  -1
    order_0_1  connected_order_arc_376  -1
    order_0_1  connected_order_arc_378  -1
    order_0_1  connected_order_arc_380  -1
    order_0_1  connected_order_arc_382  -1
    order_0_1  connected_order_arc_384  -1
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_390  -1
    order_0_1  connected_order_arc_392  -1
    order_0_1  connected_order_arc_394  -1
    order_0_1  connected_order_arc_396  -1
    order_0_1  connected_order_arc_398  -1
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_403  1
    order_0_1  connected_order_arc_434  1
    order_0_1  connected_order_arc_465  1
    order_0_1  connected_order_arc_496  1
    order_0_1  connected_order_arc_527  1
    order_0_1  connected_order_arc_558  1
    order_0_1  connected_order_arc_589  1
    order_0_1  connected_order_arc_620  1
    order_0_1  connected_order_arc_651  1
    order_0_1  connected_order_arc_682  1
    order_0_1  connected_order_arc_713  1
    order_0_1  connected_order_arc_744  1
    order_0_1  connected_order_arc_775  1
    order_0_1  connected_order_arc_806  1
    order_0_1  connected_order_arc_837  1
    order_0_1  order_active_lb_870  1
    order_0_1  order_active_ub_871  1
    order_0_1  fixed_segment_relative_order_972  -1
    visit_0_2  out_degree_875  -1
    visit_0_2  in_degree_876  -1
    visit_0_2  order_active_lb_877  -1
    visit_0_2  order_active_ub_878  -16
    order_0_2  connected_order_arc_372  1
    order_0_2  connected_order_arc_403  -1
    order_0_2  connected_order_arc_405  -1
    order_0_2  connected_order_arc_407  -1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_417  -1
    order_0_2  connected_order_arc_419  -1
    order_0_2  connected_order_arc_421  -1
    order_0_2  connected_order_arc_423  -1
    order_0_2  connected_order_arc_425  -1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_436  1
    order_0_2  connected_order_arc_467  1
    order_0_2  connected_order_arc_498  1
    order_0_2  connected_order_arc_529  1
    order_0_2  connected_order_arc_560  1
    order_0_2  connected_order_arc_591  1
    order_0_2  connected_order_arc_622  1
    order_0_2  connected_order_arc_653  1
    order_0_2  connected_order_arc_684  1
    order_0_2  connected_order_arc_715  1
    order_0_2  connected_order_arc_746  1
    order_0_2  connected_order_arc_777  1
    order_0_2  connected_order_arc_808  1
    order_0_2  connected_order_arc_839  1
    order_0_2  order_active_lb_877  1
    order_0_2  order_active_ub_878  1
    order_0_2  fixed_segment_relative_order_972  1
    order_0_2  fixed_segment_relative_order_973  -1
    visit_0_3  out_degree_882  -1
    visit_0_3  in_degree_883  -1
    visit_0_3  order_active_lb_884  -1
    visit_0_3  order_active_ub_885  -16
    order_0_3  connected_order_arc_374  1
    order_0_3  connected_order_arc_405  1
    order_0_3  connected_order_arc_434  -1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_442  -1
    order_0_3  connected_order_arc_444  -1
    order_0_3  connected_order_arc_446  -1
    order_0_3  connected_order_arc_448  -1
    order_0_3  connected_order_arc_450  -1
    order_0_3  connected_order_arc_452  -1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_462  -1
    order_0_3  connected_order_arc_469  1
    order_0_3  connected_order_arc_500  1
    order_0_3  connected_order_arc_531  1
    order_0_3  connected_order_arc_562  1
    order_0_3  connected_order_arc_593  1
    order_0_3  connected_order_arc_624  1
    order_0_3  connected_order_arc_655  1
    order_0_3  connected_order_arc_686  1
    order_0_3  connected_order_arc_717  1
    order_0_3  connected_order_arc_748  1
    order_0_3  connected_order_arc_779  1
    order_0_3  connected_order_arc_810  1
    order_0_3  connected_order_arc_841  1
    order_0_3  order_active_lb_884  1
    order_0_3  order_active_ub_885  1
    order_0_3  fixed_segment_relative_order_973  1
    order_0_3  fixed_segment_relative_order_974  -1
    visit_0_4  out_degree_889  -1
    visit_0_4  in_degree_890  -1
    visit_0_4  order_active_lb_891  -1
    visit_0_4  order_active_ub_892  -16
    order_0_4  connected_order_arc_376  1
    order_0_4  connected_order_arc_407  1
    order_0_4  connected_order_arc_438  1
    order_0_4  connected_order_arc_465  -1
    order_0_4  connected_order_arc_467  -1
    order_0_4  connected_order_arc_469  -1
    order_0_4  connected_order_arc_471  -1
    order_0_4  connected_order_arc_473  -1
    order_0_4  connected_order_arc_475  -1
    order_0_4  connected_order_arc_477  -1
    order_0_4  connected_order_arc_479  -1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_483  -1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_489  -1
    order_0_4  connected_order_arc_491  -1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_502  1
    order_0_4  connected_order_arc_533  1
    order_0_4  connected_order_arc_564  1
    order_0_4  connected_order_arc_595  1
    order_0_4  connected_order_arc_626  1
    order_0_4  connected_order_arc_657  1
    order_0_4  connected_order_arc_688  1
    order_0_4  connected_order_arc_719  1
    order_0_4  connected_order_arc_750  1
    order_0_4  connected_order_arc_781  1
    order_0_4  connected_order_arc_812  1
    order_0_4  connected_order_arc_843  1
    order_0_4  order_active_lb_891  1
    order_0_4  order_active_ub_892  1
    order_0_4  fixed_segment_relative_order_974  1
    order_0_4  fixed_segment_relative_order_975  -1
    visit_0_5  out_degree_896  -1
    visit_0_5  in_degree_897  -1
    visit_0_5  order_active_lb_898  -1
    visit_0_5  order_active_ub_899  -16
    order_0_5  connected_order_arc_378  1
    order_0_5  connected_order_arc_409  1
    order_0_5  connected_order_arc_440  1
    order_0_5  connected_order_arc_471  1
    order_0_5  connected_order_arc_496  -1
    order_0_5  connected_order_arc_498  -1
    order_0_5  connected_order_arc_500  -1
    order_0_5  connected_order_arc_502  -1
    order_0_5  connected_order_arc_504  -1
    order_0_5  connected_order_arc_506  -1
    order_0_5  connected_order_arc_508  -1
    order_0_5  connected_order_arc_510  -1
    order_0_5  connected_order_arc_512  -1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_516  -1
    order_0_5  connected_order_arc_518  -1
    order_0_5  connected_order_arc_520  -1
    order_0_5  connected_order_arc_522  -1
    order_0_5  connected_order_arc_524  -1
    order_0_5  connected_order_arc_535  1
    order_0_5  connected_order_arc_566  1
    order_0_5  connected_order_arc_597  1
    order_0_5  connected_order_arc_628  1
    order_0_5  connected_order_arc_659  1
    order_0_5  connected_order_arc_690  1
    order_0_5  connected_order_arc_721  1
    order_0_5  connected_order_arc_752  1
    order_0_5  connected_order_arc_783  1
    order_0_5  connected_order_arc_814  1
    order_0_5  connected_order_arc_845  1
    order_0_5  order_active_lb_898  1
    order_0_5  order_active_ub_899  1
    order_0_5  fixed_segment_relative_order_975  1
    order_0_5  fixed_segment_relative_order_976  -1
    visit_0_6  out_degree_903  -1
    visit_0_6  in_degree_904  -1
    visit_0_6  order_active_lb_905  -1
    visit_0_6  order_active_ub_906  -16
    order_0_6  connected_order_arc_380  1
    order_0_6  connected_order_arc_411  1
    order_0_6  connected_order_arc_442  1
    order_0_6  connected_order_arc_473  1
    order_0_6  connected_order_arc_504  1
    order_0_6  connected_order_arc_527  -1
    order_0_6  connected_order_arc_529  -1
    order_0_6  connected_order_arc_531  -1
    order_0_6  connected_order_arc_533  -1
    order_0_6  connected_order_arc_535  -1
    order_0_6  connected_order_arc_537  -1
    order_0_6  connected_order_arc_539  -1
    order_0_6  connected_order_arc_541  -1
    order_0_6  connected_order_arc_543  -1
    order_0_6  connected_order_arc_545  -1
    order_0_6  connected_order_arc_547  -1
    order_0_6  connected_order_arc_549  -1
    order_0_6  connected_order_arc_551  -1
    order_0_6  connected_order_arc_553  -1
    order_0_6  connected_order_arc_555  -1
    order_0_6  connected_order_arc_568  1
    order_0_6  connected_order_arc_599  1
    order_0_6  connected_order_arc_630  1
    order_0_6  connected_order_arc_661  1
    order_0_6  connected_order_arc_692  1
    order_0_6  connected_order_arc_723  1
    order_0_6  connected_order_arc_754  1
    order_0_6  connected_order_arc_785  1
    order_0_6  connected_order_arc_816  1
    order_0_6  connected_order_arc_847  1
    order_0_6  order_active_lb_905  1
    order_0_6  order_active_ub_906  1
    order_0_6  fixed_segment_relative_order_976  1
    order_0_6  fixed_segment_relative_order_977  -1
    visit_0_7  out_degree_910  -1
    visit_0_7  in_degree_911  -1
    visit_0_7  order_active_lb_912  -1
    visit_0_7  order_active_ub_913  -16
    order_0_7  connected_order_arc_382  1
    order_0_7  connected_order_arc_413  1
    order_0_7  connected_order_arc_444  1
    order_0_7  connected_order_arc_475  1
    order_0_7  connected_order_arc_506  1
    order_0_7  connected_order_arc_537  1
    order_0_7  connected_order_arc_558  -1
    order_0_7  connected_order_arc_560  -1
    order_0_7  connected_order_arc_562  -1
    order_0_7  connected_order_arc_564  -1
    order_0_7  connected_order_arc_566  -1
    order_0_7  connected_order_arc_568  -1
    order_0_7  connected_order_arc_570  -1
    order_0_7  connected_order_arc_572  -1
    order_0_7  connected_order_arc_574  -1
    order_0_7  connected_order_arc_576  -1
    order_0_7  connected_order_arc_578  -1
    order_0_7  connected_order_arc_580  -1
    order_0_7  connected_order_arc_582  -1
    order_0_7  connected_order_arc_584  -1
    order_0_7  connected_order_arc_586  -1
    order_0_7  connected_order_arc_601  1
    order_0_7  connected_order_arc_632  1
    order_0_7  connected_order_arc_663  1
    order_0_7  connected_order_arc_694  1
    order_0_7  connected_order_arc_725  1
    order_0_7  connected_order_arc_756  1
    order_0_7  connected_order_arc_787  1
    order_0_7  connected_order_arc_818  1
    order_0_7  connected_order_arc_849  1
    order_0_7  order_active_lb_912  1
    order_0_7  order_active_ub_913  1
    order_0_7  fixed_segment_relative_order_977  1
    order_0_7  fixed_segment_relative_order_978  -1
    visit_0_8  out_degree_917  -1
    visit_0_8  in_degree_918  -1
    visit_0_8  order_active_lb_919  -1
    visit_0_8  order_active_ub_920  -16
    order_0_8  connected_order_arc_384  1
    order_0_8  connected_order_arc_415  1
    order_0_8  connected_order_arc_446  1
    order_0_8  connected_order_arc_477  1
    order_0_8  connected_order_arc_508  1
    order_0_8  connected_order_arc_539  1
    order_0_8  connected_order_arc_570  1
    order_0_8  connected_order_arc_589  -1
    order_0_8  connected_order_arc_591  -1
    order_0_8  connected_order_arc_593  -1
    order_0_8  connected_order_arc_595  -1
    order_0_8  connected_order_arc_597  -1
    order_0_8  connected_order_arc_599  -1
    order_0_8  connected_order_arc_601  -1
    order_0_8  connected_order_arc_603  -1
    order_0_8  connected_order_arc_605  -1
    order_0_8  connected_order_arc_607  -1
    order_0_8  connected_order_arc_609  -1
    order_0_8  connected_order_arc_611  -1
    order_0_8  connected_order_arc_613  -1
    order_0_8  connected_order_arc_615  -1
    order_0_8  connected_order_arc_617  -1
    order_0_8  connected_order_arc_634  1
    order_0_8  connected_order_arc_665  1
    order_0_8  connected_order_arc_696  1
    order_0_8  connected_order_arc_727  1
    order_0_8  connected_order_arc_758  1
    order_0_8  connected_order_arc_789  1
    order_0_8  connected_order_arc_820  1
    order_0_8  connected_order_arc_851  1
    order_0_8  order_active_lb_919  1
    order_0_8  order_active_ub_920  1
    order_0_8  fixed_segment_relative_order_978  1
    visit_0_11  out_degree_924  -1
    visit_0_11  in_degree_925  -1
    visit_0_11  order_active_lb_926  -1
    visit_0_11  order_active_ub_927  -16
    visit_0_11  service_visit_def_928  -1
    order_0_11  connected_order_arc_386  1
    order_0_11  connected_order_arc_417  1
    order_0_11  connected_order_arc_448  1
    order_0_11  connected_order_arc_479  1
    order_0_11  connected_order_arc_510  1
    order_0_11  connected_order_arc_541  1
    order_0_11  connected_order_arc_572  1
    order_0_11  connected_order_arc_603  1
    order_0_11  connected_order_arc_620  -1
    order_0_11  connected_order_arc_622  -1
    order_0_11  connected_order_arc_624  -1
    order_0_11  connected_order_arc_626  -1
    order_0_11  connected_order_arc_628  -1
    order_0_11  connected_order_arc_630  -1
    order_0_11  connected_order_arc_632  -1
    order_0_11  connected_order_arc_634  -1
    order_0_11  connected_order_arc_636  -1
    order_0_11  connected_order_arc_638  -1
    order_0_11  connected_order_arc_640  -1
    order_0_11  connected_order_arc_642  -1
    order_0_11  connected_order_arc_644  -1
    order_0_11  connected_order_arc_646  -1
    order_0_11  connected_order_arc_648  -1
    order_0_11  connected_order_arc_667  1
    order_0_11  connected_order_arc_698  1
    order_0_11  connected_order_arc_729  1
    order_0_11  connected_order_arc_760  1
    order_0_11  connected_order_arc_791  1
    order_0_11  connected_order_arc_822  1
    order_0_11  connected_order_arc_853  1
    order_0_11  order_active_lb_926  1
    order_0_11  order_active_ub_927  1
    visit_0_12  out_degree_930  -1
    visit_0_12  in_degree_931  -1
    visit_0_12  order_active_lb_932  -1
    visit_0_12  order_active_ub_933  -16
    visit_0_12  service_visit_def_934  -1
    order_0_12  connected_order_arc_388  1
    order_0_12  connected_order_arc_419  1
    order_0_12  connected_order_arc_450  1
    order_0_12  connected_order_arc_481  1
    order_0_12  connected_order_arc_512  1
    order_0_12  connected_order_arc_543  1
    order_0_12  connected_order_arc_574  1
    order_0_12  connected_order_arc_605  1
    order_0_12  connected_order_arc_636  1
    order_0_12  connected_order_arc_651  -1
    order_0_12  connected_order_arc_653  -1
    order_0_12  connected_order_arc_655  -1
    order_0_12  connected_order_arc_657  -1
    order_0_12  connected_order_arc_659  -1
    order_0_12  connected_order_arc_661  -1
    order_0_12  connected_order_arc_663  -1
    order_0_12  connected_order_arc_665  -1
    order_0_12  connected_order_arc_667  -1
    order_0_12  connected_order_arc_669  -1
    order_0_12  connected_order_arc_671  -1
    order_0_12  connected_order_arc_673  -1
    order_0_12  connected_order_arc_675  -1
    order_0_12  connected_order_arc_677  -1
    order_0_12  connected_order_arc_679  -1
    order_0_12  connected_order_arc_700  1
    order_0_12  connected_order_arc_731  1
    order_0_12  connected_order_arc_762  1
    order_0_12  connected_order_arc_793  1
    order_0_12  connected_order_arc_824  1
    order_0_12  connected_order_arc_855  1
    order_0_12  order_active_lb_932  1
    order_0_12  order_active_ub_933  1
    visit_0_13  out_degree_936  -1
    visit_0_13  in_degree_937  -1
    visit_0_13  order_active_lb_938  -1
    visit_0_13  order_active_ub_939  -16
    visit_0_13  service_visit_def_940  -1
    order_0_13  connected_order_arc_390  1
    order_0_13  connected_order_arc_421  1
    order_0_13  connected_order_arc_452  1
    order_0_13  connected_order_arc_483  1
    order_0_13  connected_order_arc_514  1
    order_0_13  connected_order_arc_545  1
    order_0_13  connected_order_arc_576  1
    order_0_13  connected_order_arc_607  1
    order_0_13  connected_order_arc_638  1
    order_0_13  connected_order_arc_669  1
    order_0_13  connected_order_arc_682  -1
    order_0_13  connected_order_arc_684  -1
    order_0_13  connected_order_arc_686  -1
    order_0_13  connected_order_arc_688  -1
    order_0_13  connected_order_arc_690  -1
    order_0_13  connected_order_arc_692  -1
    order_0_13  connected_order_arc_694  -1
    order_0_13  connected_order_arc_696  -1
    order_0_13  connected_order_arc_698  -1
    order_0_13  connected_order_arc_700  -1
    order_0_13  connected_order_arc_702  -1
    order_0_13  connected_order_arc_704  -1
    order_0_13  connected_order_arc_706  -1
    order_0_13  connected_order_arc_708  -1
    order_0_13  connected_order_arc_710  -1
    order_0_13  connected_order_arc_733  1
    order_0_13  connected_order_arc_764  1
    order_0_13  connected_order_arc_795  1
    order_0_13  connected_order_arc_826  1
    order_0_13  connected_order_arc_857  1
    order_0_13  order_active_lb_938  1
    order_0_13  order_active_ub_939  1
    visit_0_14  out_degree_942  -1
    visit_0_14  in_degree_943  -1
    visit_0_14  order_active_lb_944  -1
    visit_0_14  order_active_ub_945  -16
    visit_0_14  service_visit_def_946  -1
    order_0_14  connected_order_arc_392  1
    order_0_14  connected_order_arc_423  1
    order_0_14  connected_order_arc_454  1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_516  1
    order_0_14  connected_order_arc_547  1
    order_0_14  connected_order_arc_578  1
    order_0_14  connected_order_arc_609  1
    order_0_14  connected_order_arc_640  1
    order_0_14  connected_order_arc_671  1
    order_0_14  connected_order_arc_702  1
    order_0_14  connected_order_arc_713  -1
    order_0_14  connected_order_arc_715  -1
    order_0_14  connected_order_arc_717  -1
    order_0_14  connected_order_arc_719  -1
    order_0_14  connected_order_arc_721  -1
    order_0_14  connected_order_arc_723  -1
    order_0_14  connected_order_arc_725  -1
    order_0_14  connected_order_arc_727  -1
    order_0_14  connected_order_arc_729  -1
    order_0_14  connected_order_arc_731  -1
    order_0_14  connected_order_arc_733  -1
    order_0_14  connected_order_arc_735  -1
    order_0_14  connected_order_arc_737  -1
    order_0_14  connected_order_arc_739  -1
    order_0_14  connected_order_arc_741  -1
    order_0_14  connected_order_arc_766  1
    order_0_14  connected_order_arc_797  1
    order_0_14  connected_order_arc_828  1
    order_0_14  connected_order_arc_859  1
    order_0_14  order_active_lb_944  1
    order_0_14  order_active_ub_945  1
    visit_0_15  out_degree_948  -1
    visit_0_15  in_degree_949  -1
    visit_0_15  order_active_lb_950  -1
    visit_0_15  order_active_ub_951  -16
    visit_0_15  service_visit_def_952  -1
    order_0_15  connected_order_arc_394  1
    order_0_15  connected_order_arc_425  1
    order_0_15  connected_order_arc_456  1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_518  1
    order_0_15  connected_order_arc_549  1
    order_0_15  connected_order_arc_580  1
    order_0_15  connected_order_arc_611  1
    order_0_15  connected_order_arc_642  1
    order_0_15  connected_order_arc_673  1
    order_0_15  connected_order_arc_704  1
    order_0_15  connected_order_arc_735  1
    order_0_15  connected_order_arc_744  -1
    order_0_15  connected_order_arc_746  -1
    order_0_15  connected_order_arc_748  -1
    order_0_15  connected_order_arc_750  -1
    order_0_15  connected_order_arc_752  -1
    order_0_15  connected_order_arc_754  -1
    order_0_15  connected_order_arc_756  -1
    order_0_15  connected_order_arc_758  -1
    order_0_15  connected_order_arc_760  -1
    order_0_15  connected_order_arc_762  -1
    order_0_15  connected_order_arc_764  -1
    order_0_15  connected_order_arc_766  -1
    order_0_15  connected_order_arc_768  -1
    order_0_15  connected_order_arc_770  -1
    order_0_15  connected_order_arc_772  -1
    order_0_15  connected_order_arc_799  1
    order_0_15  connected_order_arc_830  1
    order_0_15  connected_order_arc_861  1
    order_0_15  order_active_lb_950  1
    order_0_15  order_active_ub_951  1
    visit_0_16  out_degree_954  -1
    visit_0_16  in_degree_955  -1
    visit_0_16  order_active_lb_956  -1
    visit_0_16  order_active_ub_957  -16
    visit_0_16  service_visit_def_958  -1
    order_0_16  connected_order_arc_396  1
    order_0_16  connected_order_arc_427  1
    order_0_16  connected_order_arc_458  1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_520  1
    order_0_16  connected_order_arc_551  1
    order_0_16  connected_order_arc_582  1
    order_0_16  connected_order_arc_613  1
    order_0_16  connected_order_arc_644  1
    order_0_16  connected_order_arc_675  1
    order_0_16  connected_order_arc_706  1
    order_0_16  connected_order_arc_737  1
    order_0_16  connected_order_arc_768  1
    order_0_16  connected_order_arc_775  -1
    order_0_16  connected_order_arc_777  -1
    order_0_16  connected_order_arc_779  -1
    order_0_16  connected_order_arc_781  -1
    order_0_16  connected_order_arc_783  -1
    order_0_16  connected_order_arc_785  -1
    order_0_16  connected_order_arc_787  -1
    order_0_16  connected_order_arc_789  -1
    order_0_16  connected_order_arc_791  -1
    order_0_16  connected_order_arc_793  -1
    order_0_16  connected_order_arc_795  -1
    order_0_16  connected_order_arc_797  -1
    order_0_16  connected_order_arc_799  -1
    order_0_16  connected_order_arc_801  -1
    order_0_16  connected_order_arc_803  -1
    order_0_16  connected_order_arc_832  1
    order_0_16  connected_order_arc_863  1
    order_0_16  order_active_lb_956  1
    order_0_16  order_active_ub_957  1
    visit_0_17  out_degree_960  -1
    visit_0_17  in_degree_961  -1
    visit_0_17  order_active_lb_962  -1
    visit_0_17  order_active_ub_963  -16
    visit_0_17  service_visit_def_964  -1
    order_0_17  connected_order_arc_398  1
    order_0_17  connected_order_arc_429  1
    order_0_17  connected_order_arc_460  1
    order_0_17  connected_order_arc_491  1
    order_0_17  connected_order_arc_522  1
    order_0_17  connected_order_arc_553  1
    order_0_17  connected_order_arc_584  1
    order_0_17  connected_order_arc_615  1
    order_0_17  connected_order_arc_646  1
    order_0_17  connected_order_arc_677  1
    order_0_17  connected_order_arc_708  1
    order_0_17  connected_order_arc_739  1
    order_0_17  connected_order_arc_770  1
    order_0_17  connected_order_arc_801  1
    order_0_17  connected_order_arc_806  -1
    order_0_17  connected_order_arc_808  -1
    order_0_17  connected_order_arc_810  -1
    order_0_17  connected_order_arc_812  -1
    order_0_17  connected_order_arc_814  -1
    order_0_17  connected_order_arc_816  -1
    order_0_17  connected_order_arc_818  -1
    order_0_17  connected_order_arc_820  -1
    order_0_17  connected_order_arc_822  -1
    order_0_17  connected_order_arc_824  -1
    order_0_17  connected_order_arc_826  -1
    order_0_17  connected_order_arc_828  -1
    order_0_17  connected_order_arc_830  -1
    order_0_17  connected_order_arc_832  -1
    order_0_17  connected_order_arc_834  -1
    order_0_17  connected_order_arc_865  1
    order_0_17  order_active_lb_962  1
    order_0_17  order_active_ub_963  1
    visit_0_18  out_degree_966  -1
    visit_0_18  in_degree_967  -1
    visit_0_18  order_active_lb_968  -1
    visit_0_18  order_active_ub_969  -16
    visit_0_18  service_visit_def_970  -1
    order_0_18  connected_order_arc_400  1
    order_0_18  connected_order_arc_431  1
    order_0_18  connected_order_arc_462  1
    order_0_18  connected_order_arc_493  1
    order_0_18  connected_order_arc_524  1
    order_0_18  connected_order_arc_555  1
    order_0_18  connected_order_arc_586  1
    order_0_18  connected_order_arc_617  1
    order_0_18  connected_order_arc_648  1
    order_0_18  connected_order_arc_679  1
    order_0_18  connected_order_arc_710  1
    order_0_18  connected_order_arc_741  1
    order_0_18  connected_order_arc_772  1
    order_0_18  connected_order_arc_803  1
    order_0_18  connected_order_arc_834  1
    order_0_18  connected_order_arc_837  -1
    order_0_18  connected_order_arc_839  -1
    order_0_18  connected_order_arc_841  -1
    order_0_18  connected_order_arc_843  -1
    order_0_18  connected_order_arc_845  -1
    order_0_18  connected_order_arc_847  -1
    order_0_18  connected_order_arc_849  -1
    order_0_18  connected_order_arc_851  -1
    order_0_18  connected_order_arc_853  -1
    order_0_18  connected_order_arc_855  -1
    order_0_18  connected_order_arc_857  -1
    order_0_18  connected_order_arc_859  -1
    order_0_18  connected_order_arc_861  -1
    order_0_18  connected_order_arc_863  -1
    order_0_18  connected_order_arc_865  -1
    order_0_18  order_active_lb_968  1
    order_0_18  order_active_ub_969  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_353  -30
    arc_0_0_0  depot_departure_or_bypass_866  1
    arc_0_0_0  depot_return_or_bypass_867  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_353  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_354  -30
    arc_0_0_1  depot_departure_or_bypass_866  1
    arc_0_0_1  in_degree_869  1
    arc_0_0_1  original_T_including_depot_unload_979  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_354  1
    load_0_0_1  segment_load_conservation_872  -1
    load_0_0_1  segment_prefix_lb_873  1
    load_0_0_1  segment_prefix_ub_874  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_355  -30
    arc_0_0_2  depot_departure_or_bypass_866  1
    arc_0_0_2  in_degree_876  1
    arc_0_0_2  original_T_including_depot_unload_979  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_355  1
    load_0_0_2  segment_load_conservation_879  -1
    load_0_0_2  segment_prefix_lb_880  1
    load_0_0_2  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_356  -30
    arc_0_0_3  depot_departure_or_bypass_866  1
    arc_0_0_3  in_degree_883  1
    arc_0_0_3  original_T_including_depot_unload_979  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_356  1
    load_0_0_3  segment_load_conservation_886  -1
    load_0_0_3  segment_prefix_lb_887  1
    load_0_0_3  segment_prefix_ub_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_357  -30
    arc_0_0_4  depot_departure_or_bypass_866  1
    arc_0_0_4  in_degree_890  1
    arc_0_0_4  original_T_including_depot_unload_979  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_357  1
    load_0_0_4  segment_load_conservation_893  -1
    load_0_0_4  segment_prefix_lb_894  1
    load_0_0_4  segment_prefix_ub_895  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_358  -30
    arc_0_0_5  depot_departure_or_bypass_866  1
    arc_0_0_5  in_degree_897  1
    arc_0_0_5  original_T_including_depot_unload_979  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_358  1
    load_0_0_5  segment_load_conservation_900  -1
    load_0_0_5  segment_prefix_lb_901  1
    load_0_0_5  segment_prefix_ub_902  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_359  -30
    arc_0_0_6  depot_departure_or_bypass_866  1
    arc_0_0_6  in_degree_904  1
    arc_0_0_6  original_T_including_depot_unload_979  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_359  1
    load_0_0_6  segment_load_conservation_907  -1
    load_0_0_6  segment_prefix_lb_908  1
    load_0_0_6  segment_prefix_ub_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_7  arc_capacity_360  -30
    arc_0_0_7  depot_departure_or_bypass_866  1
    arc_0_0_7  in_degree_911  1
    arc_0_0_7  original_T_including_depot_unload_979  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_7  arc_capacity_360  1
    load_0_0_7  segment_load_conservation_914  -1
    load_0_0_7  segment_prefix_lb_915  1
    load_0_0_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_361  -30
    arc_0_0_8  depot_departure_or_bypass_866  1
    arc_0_0_8  in_degree_918  1
    arc_0_0_8  original_T_including_depot_unload_979  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_361  1
    load_0_0_8  segment_load_conservation_921  -1
    load_0_0_8  segment_prefix_lb_922  1
    load_0_0_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_362  -30
    arc_0_0_11  depot_departure_or_bypass_866  1
    arc_0_0_11  in_degree_925  1
    arc_0_0_11  original_T_including_depot_unload_979  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_362  1
    load_0_0_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_363  -30
    arc_0_0_12  depot_departure_or_bypass_866  1
    arc_0_0_12  in_degree_931  1
    arc_0_0_12  original_T_including_depot_unload_979  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_363  1
    load_0_0_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_364  -30
    arc_0_0_13  depot_departure_or_bypass_866  1
    arc_0_0_13  in_degree_937  1
    arc_0_0_13  original_T_including_depot_unload_979  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_364  1
    load_0_0_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_365  -30
    arc_0_0_14  depot_departure_or_bypass_866  1
    arc_0_0_14  in_degree_943  1
    arc_0_0_14  original_T_including_depot_unload_979  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_365  1
    load_0_0_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_366  -30
    arc_0_0_15  depot_departure_or_bypass_866  1
    arc_0_0_15  in_degree_949  1
    arc_0_0_15  original_T_including_depot_unload_979  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_366  1
    load_0_0_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_367  -30
    arc_0_0_16  depot_departure_or_bypass_866  1
    arc_0_0_16  in_degree_955  1
    arc_0_0_16  original_T_including_depot_unload_979  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_367  1
    load_0_0_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_368  -30
    arc_0_0_17  depot_departure_or_bypass_866  1
    arc_0_0_17  in_degree_961  1
    arc_0_0_17  original_T_including_depot_unload_979  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_368  1
    load_0_0_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_369  -30
    arc_0_0_18  depot_departure_or_bypass_866  1
    arc_0_0_18  in_degree_967  1
    arc_0_0_18  original_T_including_depot_unload_979  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_369  1
    load_0_0_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_370  -30
    arc_0_1_0  depot_return_or_bypass_867  1
    arc_0_1_0  out_degree_868  1
    arc_0_1_0  original_T_including_depot_unload_979  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_370  1
    load_0_1_0  segment_load_conservation_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_371  -30
    arc_0_1_2  connected_order_arc_372  -17
    arc_0_1_2  out_degree_868  1
    arc_0_1_2  in_degree_876  1
    arc_0_1_2  original_T_including_depot_unload_979  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_371  1
    load_0_1_2  segment_load_conservation_872  1
    load_0_1_2  segment_load_conservation_879  -1
    load_0_1_2  segment_prefix_lb_880  1
    load_0_1_2  segment_prefix_ub_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_373  -30
    arc_0_1_3  connected_order_arc_374  -17
    arc_0_1_3  out_degree_868  1
    arc_0_1_3  in_degree_883  1
    arc_0_1_3  original_T_including_depot_unload_979  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_373  1
    load_0_1_3  segment_load_conservation_872  1
    load_0_1_3  segment_load_conservation_886  -1
    load_0_1_3  segment_prefix_lb_887  1
    load_0_1_3  segment_prefix_ub_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_375  -30
    arc_0_1_4  connected_order_arc_376  -17
    arc_0_1_4  out_degree_868  1
    arc_0_1_4  in_degree_890  1
    arc_0_1_4  original_T_including_depot_unload_979  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_375  1
    load_0_1_4  segment_load_conservation_872  1
    load_0_1_4  segment_load_conservation_893  -1
    load_0_1_4  segment_prefix_lb_894  1
    load_0_1_4  segment_prefix_ub_895  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_377  -30
    arc_0_1_5  connected_order_arc_378  -17
    arc_0_1_5  out_degree_868  1
    arc_0_1_5  in_degree_897  1
    arc_0_1_5  original_T_including_depot_unload_979  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_377  1
    load_0_1_5  segment_load_conservation_872  1
    load_0_1_5  segment_load_conservation_900  -1
    load_0_1_5  segment_prefix_lb_901  1
    load_0_1_5  segment_prefix_ub_902  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_379  -30
    arc_0_1_6  connected_order_arc_380  -17
    arc_0_1_6  out_degree_868  1
    arc_0_1_6  in_degree_904  1
    arc_0_1_6  original_T_including_depot_unload_979  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_379  1
    load_0_1_6  segment_load_conservation_872  1
    load_0_1_6  segment_load_conservation_907  -1
    load_0_1_6  segment_prefix_lb_908  1
    load_0_1_6  segment_prefix_ub_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_7  arc_capacity_381  -30
    arc_0_1_7  connected_order_arc_382  -17
    arc_0_1_7  out_degree_868  1
    arc_0_1_7  in_degree_911  1
    arc_0_1_7  original_T_including_depot_unload_979  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_7  arc_capacity_381  1
    load_0_1_7  segment_load_conservation_872  1
    load_0_1_7  segment_load_conservation_914  -1
    load_0_1_7  segment_prefix_lb_915  1
    load_0_1_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_383  -30
    arc_0_1_8  connected_order_arc_384  -17
    arc_0_1_8  out_degree_868  1
    arc_0_1_8  in_degree_918  1
    arc_0_1_8  original_T_including_depot_unload_979  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_383  1
    load_0_1_8  segment_load_conservation_872  1
    load_0_1_8  segment_load_conservation_921  -1
    load_0_1_8  segment_prefix_lb_922  1
    load_0_1_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_385  -30
    arc_0_1_11  connected_order_arc_386  -17
    arc_0_1_11  out_degree_868  1
    arc_0_1_11  in_degree_925  1
    arc_0_1_11  original_T_including_depot_unload_979  2.7384186870432241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_385  1
    load_0_1_11  segment_load_conservation_872  1
    load_0_1_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_387  -30
    arc_0_1_12  connected_order_arc_388  -17
    arc_0_1_12  out_degree_868  1
    arc_0_1_12  in_degree_931  1
    arc_0_1_12  original_T_including_depot_unload_979  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_387  1
    load_0_1_12  segment_load_conservation_872  1
    load_0_1_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_389  -30
    arc_0_1_13  connected_order_arc_390  -17
    arc_0_1_13  out_degree_868  1
    arc_0_1_13  in_degree_937  1
    arc_0_1_13  original_T_including_depot_unload_979  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_389  1
    load_0_1_13  segment_load_conservation_872  1
    load_0_1_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_391  -30
    arc_0_1_14  connected_order_arc_392  -17
    arc_0_1_14  out_degree_868  1
    arc_0_1_14  in_degree_943  1
    arc_0_1_14  original_T_including_depot_unload_979  2.9475580354409412e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_391  1
    load_0_1_14  segment_load_conservation_872  1
    load_0_1_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_393  -30
    arc_0_1_15  connected_order_arc_394  -17
    arc_0_1_15  out_degree_868  1
    arc_0_1_15  in_degree_949  1
    arc_0_1_15  original_T_including_depot_unload_979  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_393  1
    load_0_1_15  segment_load_conservation_872  1
    load_0_1_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_395  -30
    arc_0_1_16  connected_order_arc_396  -17
    arc_0_1_16  out_degree_868  1
    arc_0_1_16  in_degree_955  1
    arc_0_1_16  original_T_including_depot_unload_979  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_395  1
    load_0_1_16  segment_load_conservation_872  1
    load_0_1_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_397  -30
    arc_0_1_17  connected_order_arc_398  -17
    arc_0_1_17  out_degree_868  1
    arc_0_1_17  in_degree_961  1
    arc_0_1_17  original_T_including_depot_unload_979  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_397  1
    load_0_1_17  segment_load_conservation_872  1
    load_0_1_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_399  -30
    arc_0_1_18  connected_order_arc_400  -17
    arc_0_1_18  out_degree_868  1
    arc_0_1_18  in_degree_967  1
    arc_0_1_18  original_T_including_depot_unload_979  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_399  1
    load_0_1_18  segment_load_conservation_872  1
    load_0_1_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_401  -30
    arc_0_2_0  depot_return_or_bypass_867  1
    arc_0_2_0  out_degree_875  1
    arc_0_2_0  original_T_including_depot_unload_979  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_401  1
    load_0_2_0  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_402  -30
    arc_0_2_1  connected_order_arc_403  -17
    arc_0_2_1  in_degree_869  1
    arc_0_2_1  out_degree_875  1
    arc_0_2_1  original_T_including_depot_unload_979  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_402  1
    load_0_2_1  segment_load_conservation_872  -1
    load_0_2_1  segment_prefix_lb_873  1
    load_0_2_1  segment_prefix_ub_874  1
    load_0_2_1  segment_load_conservation_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_404  -30
    arc_0_2_3  connected_order_arc_405  -17
    arc_0_2_3  out_degree_875  1
    arc_0_2_3  in_degree_883  1
    arc_0_2_3  original_T_including_depot_unload_979  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_404  1
    load_0_2_3  segment_load_conservation_879  1
    load_0_2_3  segment_load_conservation_886  -1
    load_0_2_3  segment_prefix_lb_887  1
    load_0_2_3  segment_prefix_ub_888  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_406  -30
    arc_0_2_4  connected_order_arc_407  -17
    arc_0_2_4  out_degree_875  1
    arc_0_2_4  in_degree_890  1
    arc_0_2_4  original_T_including_depot_unload_979  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_406  1
    load_0_2_4  segment_load_conservation_879  1
    load_0_2_4  segment_load_conservation_893  -1
    load_0_2_4  segment_prefix_lb_894  1
    load_0_2_4  segment_prefix_ub_895  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_408  -30
    arc_0_2_5  connected_order_arc_409  -17
    arc_0_2_5  out_degree_875  1
    arc_0_2_5  in_degree_897  1
    arc_0_2_5  original_T_including_depot_unload_979  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_408  1
    load_0_2_5  segment_load_conservation_879  1
    load_0_2_5  segment_load_conservation_900  -1
    load_0_2_5  segment_prefix_lb_901  1
    load_0_2_5  segment_prefix_ub_902  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_410  -30
    arc_0_2_6  connected_order_arc_411  -17
    arc_0_2_6  out_degree_875  1
    arc_0_2_6  in_degree_904  1
    arc_0_2_6  original_T_including_depot_unload_979  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_410  1
    load_0_2_6  segment_load_conservation_879  1
    load_0_2_6  segment_load_conservation_907  -1
    load_0_2_6  segment_prefix_lb_908  1
    load_0_2_6  segment_prefix_ub_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_7  arc_capacity_412  -30
    arc_0_2_7  connected_order_arc_413  -17
    arc_0_2_7  out_degree_875  1
    arc_0_2_7  in_degree_911  1
    arc_0_2_7  original_T_including_depot_unload_979  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_7  arc_capacity_412  1
    load_0_2_7  segment_load_conservation_879  1
    load_0_2_7  segment_load_conservation_914  -1
    load_0_2_7  segment_prefix_lb_915  1
    load_0_2_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_414  -30
    arc_0_2_8  connected_order_arc_415  -17
    arc_0_2_8  out_degree_875  1
    arc_0_2_8  in_degree_918  1
    arc_0_2_8  original_T_including_depot_unload_979  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_414  1
    load_0_2_8  segment_load_conservation_879  1
    load_0_2_8  segment_load_conservation_921  -1
    load_0_2_8  segment_prefix_lb_922  1
    load_0_2_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_416  -30
    arc_0_2_11  connected_order_arc_417  -17
    arc_0_2_11  out_degree_875  1
    arc_0_2_11  in_degree_925  1
    arc_0_2_11  original_T_including_depot_unload_979  3.0014740451067628e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_416  1
    load_0_2_11  segment_load_conservation_879  1
    load_0_2_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_418  -30
    arc_0_2_12  connected_order_arc_419  -17
    arc_0_2_12  out_degree_875  1
    arc_0_2_12  in_degree_931  1
    arc_0_2_12  original_T_including_depot_unload_979  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_418  1
    load_0_2_12  segment_load_conservation_879  1
    load_0_2_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_420  -30
    arc_0_2_13  connected_order_arc_421  -17
    arc_0_2_13  out_degree_875  1
    arc_0_2_13  in_degree_937  1
    arc_0_2_13  original_T_including_depot_unload_979  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_420  1
    load_0_2_13  segment_load_conservation_879  1
    load_0_2_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_422  -30
    arc_0_2_14  connected_order_arc_423  -17
    arc_0_2_14  out_degree_875  1
    arc_0_2_14  in_degree_943  1
    arc_0_2_14  original_T_including_depot_unload_979  3.1940365421146048e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_422  1
    load_0_2_14  segment_load_conservation_879  1
    load_0_2_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_424  -30
    arc_0_2_15  connected_order_arc_425  -17
    arc_0_2_15  out_degree_875  1
    arc_0_2_15  in_degree_949  1
    arc_0_2_15  original_T_including_depot_unload_979  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_424  1
    load_0_2_15  segment_load_conservation_879  1
    load_0_2_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_426  -30
    arc_0_2_16  connected_order_arc_427  -17
    arc_0_2_16  out_degree_875  1
    arc_0_2_16  in_degree_955  1
    arc_0_2_16  original_T_including_depot_unload_979  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_426  1
    load_0_2_16  segment_load_conservation_879  1
    load_0_2_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_428  -30
    arc_0_2_17  connected_order_arc_429  -17
    arc_0_2_17  out_degree_875  1
    arc_0_2_17  in_degree_961  1
    arc_0_2_17  original_T_including_depot_unload_979  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_428  1
    load_0_2_17  segment_load_conservation_879  1
    load_0_2_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_430  -30
    arc_0_2_18  connected_order_arc_431  -17
    arc_0_2_18  out_degree_875  1
    arc_0_2_18  in_degree_967  1
    arc_0_2_18  original_T_including_depot_unload_979  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_430  1
    load_0_2_18  segment_load_conservation_879  1
    load_0_2_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_432  -30
    arc_0_3_0  depot_return_or_bypass_867  1
    arc_0_3_0  out_degree_882  1
    arc_0_3_0  original_T_including_depot_unload_979  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_432  1
    load_0_3_0  segment_load_conservation_886  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_433  -30
    arc_0_3_1  connected_order_arc_434  -17
    arc_0_3_1  in_degree_869  1
    arc_0_3_1  out_degree_882  1
    arc_0_3_1  original_T_including_depot_unload_979  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_433  1
    load_0_3_1  segment_load_conservation_872  -1
    load_0_3_1  segment_prefix_lb_873  1
    load_0_3_1  segment_prefix_ub_874  1
    load_0_3_1  segment_load_conservation_886  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_435  -30
    arc_0_3_2  connected_order_arc_436  -17
    arc_0_3_2  in_degree_876  1
    arc_0_3_2  out_degree_882  1
    arc_0_3_2  original_T_including_depot_unload_979  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_435  1
    load_0_3_2  segment_load_conservation_879  -1
    load_0_3_2  segment_prefix_lb_880  1
    load_0_3_2  segment_prefix_ub_881  1
    load_0_3_2  segment_load_conservation_886  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_437  -30
    arc_0_3_4  connected_order_arc_438  -17
    arc_0_3_4  out_degree_882  1
    arc_0_3_4  in_degree_890  1
    arc_0_3_4  original_T_including_depot_unload_979  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_437  1
    load_0_3_4  segment_load_conservation_886  1
    load_0_3_4  segment_load_conservation_893  -1
    load_0_3_4  segment_prefix_lb_894  1
    load_0_3_4  segment_prefix_ub_895  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_439  -30
    arc_0_3_5  connected_order_arc_440  -17
    arc_0_3_5  out_degree_882  1
    arc_0_3_5  in_degree_897  1
    arc_0_3_5  original_T_including_depot_unload_979  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_439  1
    load_0_3_5  segment_load_conservation_886  1
    load_0_3_5  segment_load_conservation_900  -1
    load_0_3_5  segment_prefix_lb_901  1
    load_0_3_5  segment_prefix_ub_902  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_441  -30
    arc_0_3_6  connected_order_arc_442  -17
    arc_0_3_6  out_degree_882  1
    arc_0_3_6  in_degree_904  1
    arc_0_3_6  original_T_including_depot_unload_979  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_441  1
    load_0_3_6  segment_load_conservation_886  1
    load_0_3_6  segment_load_conservation_907  -1
    load_0_3_6  segment_prefix_lb_908  1
    load_0_3_6  segment_prefix_ub_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_7  arc_capacity_443  -30
    arc_0_3_7  connected_order_arc_444  -17
    arc_0_3_7  out_degree_882  1
    arc_0_3_7  in_degree_911  1
    arc_0_3_7  original_T_including_depot_unload_979  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_7  arc_capacity_443  1
    load_0_3_7  segment_load_conservation_886  1
    load_0_3_7  segment_load_conservation_914  -1
    load_0_3_7  segment_prefix_lb_915  1
    load_0_3_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_445  -30
    arc_0_3_8  connected_order_arc_446  -17
    arc_0_3_8  out_degree_882  1
    arc_0_3_8  in_degree_918  1
    arc_0_3_8  original_T_including_depot_unload_979  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_445  1
    load_0_3_8  segment_load_conservation_886  1
    load_0_3_8  segment_load_conservation_921  -1
    load_0_3_8  segment_prefix_lb_922  1
    load_0_3_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_447  -30
    arc_0_3_11  connected_order_arc_448  -17
    arc_0_3_11  out_degree_882  1
    arc_0_3_11  in_degree_925  1
    arc_0_3_11  original_T_including_depot_unload_979  2.9012357973868689e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_447  1
    load_0_3_11  segment_load_conservation_886  1
    load_0_3_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_449  -30
    arc_0_3_12  connected_order_arc_450  -17
    arc_0_3_12  out_degree_882  1
    arc_0_3_12  in_degree_931  1
    arc_0_3_12  original_T_including_depot_unload_979  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_449  1
    load_0_3_12  segment_load_conservation_886  1
    load_0_3_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_451  -30
    arc_0_3_13  connected_order_arc_452  -17
    arc_0_3_13  out_degree_882  1
    arc_0_3_13  in_degree_937  1
    arc_0_3_13  original_T_including_depot_unload_979  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_451  1
    load_0_3_13  segment_load_conservation_886  1
    load_0_3_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_453  -30
    arc_0_3_14  connected_order_arc_454  -17
    arc_0_3_14  out_degree_882  1
    arc_0_3_14  in_degree_943  1
    arc_0_3_14  original_T_including_depot_unload_979  3.0706942101225172e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_453  1
    load_0_3_14  segment_load_conservation_886  1
    load_0_3_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_455  -30
    arc_0_3_15  connected_order_arc_456  -17
    arc_0_3_15  out_degree_882  1
    arc_0_3_15  in_degree_949  1
    arc_0_3_15  original_T_including_depot_unload_979  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_455  1
    load_0_3_15  segment_load_conservation_886  1
    load_0_3_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_457  -30
    arc_0_3_16  connected_order_arc_458  -17
    arc_0_3_16  out_degree_882  1
    arc_0_3_16  in_degree_955  1
    arc_0_3_16  original_T_including_depot_unload_979  2.9361273497784791e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_457  1
    load_0_3_16  segment_load_conservation_886  1
    load_0_3_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_459  -30
    arc_0_3_17  connected_order_arc_460  -17
    arc_0_3_17  out_degree_882  1
    arc_0_3_17  in_degree_961  1
    arc_0_3_17  original_T_including_depot_unload_979  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_459  1
    load_0_3_17  segment_load_conservation_886  1
    load_0_3_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_461  -30
    arc_0_3_18  connected_order_arc_462  -17
    arc_0_3_18  out_degree_882  1
    arc_0_3_18  in_degree_967  1
    arc_0_3_18  original_T_including_depot_unload_979  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_461  1
    load_0_3_18  segment_load_conservation_886  1
    load_0_3_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_463  -30
    arc_0_4_0  depot_return_or_bypass_867  1
    arc_0_4_0  out_degree_889  1
    arc_0_4_0  original_T_including_depot_unload_979  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_463  1
    load_0_4_0  segment_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_464  -30
    arc_0_4_1  connected_order_arc_465  -17
    arc_0_4_1  in_degree_869  1
    arc_0_4_1  out_degree_889  1
    arc_0_4_1  original_T_including_depot_unload_979  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_464  1
    load_0_4_1  segment_load_conservation_872  -1
    load_0_4_1  segment_prefix_lb_873  1
    load_0_4_1  segment_prefix_ub_874  1
    load_0_4_1  segment_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_466  -30
    arc_0_4_2  connected_order_arc_467  -17
    arc_0_4_2  in_degree_876  1
    arc_0_4_2  out_degree_889  1
    arc_0_4_2  original_T_including_depot_unload_979  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_466  1
    load_0_4_2  segment_load_conservation_879  -1
    load_0_4_2  segment_prefix_lb_880  1
    load_0_4_2  segment_prefix_ub_881  1
    load_0_4_2  segment_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_468  -30
    arc_0_4_3  connected_order_arc_469  -17
    arc_0_4_3  in_degree_883  1
    arc_0_4_3  out_degree_889  1
    arc_0_4_3  original_T_including_depot_unload_979  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_468  1
    load_0_4_3  segment_load_conservation_886  -1
    load_0_4_3  segment_prefix_lb_887  1
    load_0_4_3  segment_prefix_ub_888  1
    load_0_4_3  segment_load_conservation_893  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_470  -30
    arc_0_4_5  connected_order_arc_471  -17
    arc_0_4_5  out_degree_889  1
    arc_0_4_5  in_degree_897  1
    arc_0_4_5  original_T_including_depot_unload_979  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_470  1
    load_0_4_5  segment_load_conservation_893  1
    load_0_4_5  segment_load_conservation_900  -1
    load_0_4_5  segment_prefix_lb_901  1
    load_0_4_5  segment_prefix_ub_902  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_472  -30
    arc_0_4_6  connected_order_arc_473  -17
    arc_0_4_6  out_degree_889  1
    arc_0_4_6  in_degree_904  1
    arc_0_4_6  original_T_including_depot_unload_979  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_472  1
    load_0_4_6  segment_load_conservation_893  1
    load_0_4_6  segment_load_conservation_907  -1
    load_0_4_6  segment_prefix_lb_908  1
    load_0_4_6  segment_prefix_ub_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_7  arc_capacity_474  -30
    arc_0_4_7  connected_order_arc_475  -17
    arc_0_4_7  out_degree_889  1
    arc_0_4_7  in_degree_911  1
    arc_0_4_7  original_T_including_depot_unload_979  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_7  arc_capacity_474  1
    load_0_4_7  segment_load_conservation_893  1
    load_0_4_7  segment_load_conservation_914  -1
    load_0_4_7  segment_prefix_lb_915  1
    load_0_4_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_476  -30
    arc_0_4_8  connected_order_arc_477  -17
    arc_0_4_8  out_degree_889  1
    arc_0_4_8  in_degree_918  1
    arc_0_4_8  original_T_including_depot_unload_979  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_476  1
    load_0_4_8  segment_load_conservation_893  1
    load_0_4_8  segment_load_conservation_921  -1
    load_0_4_8  segment_prefix_lb_922  1
    load_0_4_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_478  -30
    arc_0_4_11  connected_order_arc_479  -17
    arc_0_4_11  out_degree_889  1
    arc_0_4_11  in_degree_925  1
    arc_0_4_11  original_T_including_depot_unload_979  2.8044705317383118e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_478  1
    load_0_4_11  segment_load_conservation_893  1
    load_0_4_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_480  -30
    arc_0_4_12  connected_order_arc_481  -17
    arc_0_4_12  out_degree_889  1
    arc_0_4_12  in_degree_931  1
    arc_0_4_12  original_T_including_depot_unload_979  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_480  1
    load_0_4_12  segment_load_conservation_893  1
    load_0_4_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_482  -30
    arc_0_4_13  connected_order_arc_483  -17
    arc_0_4_13  out_degree_889  1
    arc_0_4_13  in_degree_937  1
    arc_0_4_13  original_T_including_depot_unload_979  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_482  1
    load_0_4_13  segment_load_conservation_893  1
    load_0_4_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_484  -30
    arc_0_4_14  connected_order_arc_485  -17
    arc_0_4_14  out_degree_889  1
    arc_0_4_14  in_degree_943  1
    arc_0_4_14  original_T_including_depot_unload_979  2.9857518131746506e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_484  1
    load_0_4_14  segment_load_conservation_893  1
    load_0_4_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_486  -30
    arc_0_4_15  connected_order_arc_487  -17
    arc_0_4_15  out_degree_889  1
    arc_0_4_15  in_degree_949  1
    arc_0_4_15  original_T_including_depot_unload_979  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_486  1
    load_0_4_15  segment_load_conservation_893  1
    load_0_4_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_488  -30
    arc_0_4_16  connected_order_arc_489  -17
    arc_0_4_16  out_degree_889  1
    arc_0_4_16  in_degree_955  1
    arc_0_4_16  original_T_including_depot_unload_979  2.8188003047777693e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_488  1
    load_0_4_16  segment_load_conservation_893  1
    load_0_4_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_490  -30
    arc_0_4_17  connected_order_arc_491  -17
    arc_0_4_17  out_degree_889  1
    arc_0_4_17  in_degree_961  1
    arc_0_4_17  original_T_including_depot_unload_979  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_490  1
    load_0_4_17  segment_load_conservation_893  1
    load_0_4_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_492  -30
    arc_0_4_18  connected_order_arc_493  -17
    arc_0_4_18  out_degree_889  1
    arc_0_4_18  in_degree_967  1
    arc_0_4_18  original_T_including_depot_unload_979  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_492  1
    load_0_4_18  segment_load_conservation_893  1
    load_0_4_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_494  -30
    arc_0_5_0  depot_return_or_bypass_867  1
    arc_0_5_0  out_degree_896  1
    arc_0_5_0  original_T_including_depot_unload_979  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_494  1
    load_0_5_0  segment_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_495  -30
    arc_0_5_1  connected_order_arc_496  -17
    arc_0_5_1  in_degree_869  1
    arc_0_5_1  out_degree_896  1
    arc_0_5_1  original_T_including_depot_unload_979  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_495  1
    load_0_5_1  segment_load_conservation_872  -1
    load_0_5_1  segment_prefix_lb_873  1
    load_0_5_1  segment_prefix_ub_874  1
    load_0_5_1  segment_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_497  -30
    arc_0_5_2  connected_order_arc_498  -17
    arc_0_5_2  in_degree_876  1
    arc_0_5_2  out_degree_896  1
    arc_0_5_2  original_T_including_depot_unload_979  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_497  1
    load_0_5_2  segment_load_conservation_879  -1
    load_0_5_2  segment_prefix_lb_880  1
    load_0_5_2  segment_prefix_ub_881  1
    load_0_5_2  segment_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_499  -30
    arc_0_5_3  connected_order_arc_500  -17
    arc_0_5_3  in_degree_883  1
    arc_0_5_3  out_degree_896  1
    arc_0_5_3  original_T_including_depot_unload_979  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_499  1
    load_0_5_3  segment_load_conservation_886  -1
    load_0_5_3  segment_prefix_lb_887  1
    load_0_5_3  segment_prefix_ub_888  1
    load_0_5_3  segment_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_501  -30
    arc_0_5_4  connected_order_arc_502  -17
    arc_0_5_4  in_degree_890  1
    arc_0_5_4  out_degree_896  1
    arc_0_5_4  original_T_including_depot_unload_979  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_501  1
    load_0_5_4  segment_load_conservation_893  -1
    load_0_5_4  segment_prefix_lb_894  1
    load_0_5_4  segment_prefix_ub_895  1
    load_0_5_4  segment_load_conservation_900  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_503  -30
    arc_0_5_6  connected_order_arc_504  -17
    arc_0_5_6  out_degree_896  1
    arc_0_5_6  in_degree_904  1
    arc_0_5_6  original_T_including_depot_unload_979  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_503  1
    load_0_5_6  segment_load_conservation_900  1
    load_0_5_6  segment_load_conservation_907  -1
    load_0_5_6  segment_prefix_lb_908  1
    load_0_5_6  segment_prefix_ub_909  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_7  arc_capacity_505  -30
    arc_0_5_7  connected_order_arc_506  -17
    arc_0_5_7  out_degree_896  1
    arc_0_5_7  in_degree_911  1
    arc_0_5_7  original_T_including_depot_unload_979  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_7  arc_capacity_505  1
    load_0_5_7  segment_load_conservation_900  1
    load_0_5_7  segment_load_conservation_914  -1
    load_0_5_7  segment_prefix_lb_915  1
    load_0_5_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_507  -30
    arc_0_5_8  connected_order_arc_508  -17
    arc_0_5_8  out_degree_896  1
    arc_0_5_8  in_degree_918  1
    arc_0_5_8  original_T_including_depot_unload_979  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_507  1
    load_0_5_8  segment_load_conservation_900  1
    load_0_5_8  segment_load_conservation_921  -1
    load_0_5_8  segment_prefix_lb_922  1
    load_0_5_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_509  -30
    arc_0_5_11  connected_order_arc_510  -17
    arc_0_5_11  out_degree_896  1
    arc_0_5_11  in_degree_925  1
    arc_0_5_11  original_T_including_depot_unload_979  2.8096824480964965e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_509  1
    load_0_5_11  segment_load_conservation_900  1
    load_0_5_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_511  -30
    arc_0_5_12  connected_order_arc_512  -17
    arc_0_5_12  out_degree_896  1
    arc_0_5_12  in_degree_931  1
    arc_0_5_12  original_T_including_depot_unload_979  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_511  1
    load_0_5_12  segment_load_conservation_900  1
    load_0_5_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_513  -30
    arc_0_5_13  connected_order_arc_514  -17
    arc_0_5_13  out_degree_896  1
    arc_0_5_13  in_degree_937  1
    arc_0_5_13  original_T_including_depot_unload_979  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_513  1
    load_0_5_13  segment_load_conservation_900  1
    load_0_5_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_515  -30
    arc_0_5_14  connected_order_arc_516  -17
    arc_0_5_14  out_degree_896  1
    arc_0_5_14  in_degree_943  1
    arc_0_5_14  original_T_including_depot_unload_979  2.9992588346691123e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_515  1
    load_0_5_14  segment_load_conservation_900  1
    load_0_5_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_517  -30
    arc_0_5_15  connected_order_arc_518  -17
    arc_0_5_15  out_degree_896  1
    arc_0_5_15  in_degree_949  1
    arc_0_5_15  original_T_including_depot_unload_979  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_517  1
    load_0_5_15  segment_load_conservation_900  1
    load_0_5_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_519  -30
    arc_0_5_16  connected_order_arc_520  -17
    arc_0_5_16  out_degree_896  1
    arc_0_5_16  in_degree_955  1
    arc_0_5_16  original_T_including_depot_unload_979  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_519  1
    load_0_5_16  segment_load_conservation_900  1
    load_0_5_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_521  -30
    arc_0_5_17  connected_order_arc_522  -17
    arc_0_5_17  out_degree_896  1
    arc_0_5_17  in_degree_961  1
    arc_0_5_17  original_T_including_depot_unload_979  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_521  1
    load_0_5_17  segment_load_conservation_900  1
    load_0_5_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_523  -30
    arc_0_5_18  connected_order_arc_524  -17
    arc_0_5_18  out_degree_896  1
    arc_0_5_18  in_degree_967  1
    arc_0_5_18  original_T_including_depot_unload_979  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_523  1
    load_0_5_18  segment_load_conservation_900  1
    load_0_5_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_525  -30
    arc_0_6_0  depot_return_or_bypass_867  1
    arc_0_6_0  out_degree_903  1
    arc_0_6_0  original_T_including_depot_unload_979  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_525  1
    load_0_6_0  segment_load_conservation_907  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_526  -30
    arc_0_6_1  connected_order_arc_527  -17
    arc_0_6_1  in_degree_869  1
    arc_0_6_1  out_degree_903  1
    arc_0_6_1  original_T_including_depot_unload_979  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_526  1
    load_0_6_1  segment_load_conservation_872  -1
    load_0_6_1  segment_prefix_lb_873  1
    load_0_6_1  segment_prefix_ub_874  1
    load_0_6_1  segment_load_conservation_907  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_528  -30
    arc_0_6_2  connected_order_arc_529  -17
    arc_0_6_2  in_degree_876  1
    arc_0_6_2  out_degree_903  1
    arc_0_6_2  original_T_including_depot_unload_979  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_528  1
    load_0_6_2  segment_load_conservation_879  -1
    load_0_6_2  segment_prefix_lb_880  1
    load_0_6_2  segment_prefix_ub_881  1
    load_0_6_2  segment_load_conservation_907  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_530  -30
    arc_0_6_3  connected_order_arc_531  -17
    arc_0_6_3  in_degree_883  1
    arc_0_6_3  out_degree_903  1
    arc_0_6_3  original_T_including_depot_unload_979  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_530  1
    load_0_6_3  segment_load_conservation_886  -1
    load_0_6_3  segment_prefix_lb_887  1
    load_0_6_3  segment_prefix_ub_888  1
    load_0_6_3  segment_load_conservation_907  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_532  -30
    arc_0_6_4  connected_order_arc_533  -17
    arc_0_6_4  in_degree_890  1
    arc_0_6_4  out_degree_903  1
    arc_0_6_4  original_T_including_depot_unload_979  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_532  1
    load_0_6_4  segment_load_conservation_893  -1
    load_0_6_4  segment_prefix_lb_894  1
    load_0_6_4  segment_prefix_ub_895  1
    load_0_6_4  segment_load_conservation_907  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_534  -30
    arc_0_6_5  connected_order_arc_535  -17
    arc_0_6_5  in_degree_897  1
    arc_0_6_5  out_degree_903  1
    arc_0_6_5  original_T_including_depot_unload_979  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_534  1
    load_0_6_5  segment_load_conservation_900  -1
    load_0_6_5  segment_prefix_lb_901  1
    load_0_6_5  segment_prefix_ub_902  1
    load_0_6_5  segment_load_conservation_907  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_7  arc_capacity_536  -30
    arc_0_6_7  connected_order_arc_537  -17
    arc_0_6_7  out_degree_903  1
    arc_0_6_7  in_degree_911  1
    arc_0_6_7  original_T_including_depot_unload_979  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_7  arc_capacity_536  1
    load_0_6_7  segment_load_conservation_907  1
    load_0_6_7  segment_load_conservation_914  -1
    load_0_6_7  segment_prefix_lb_915  1
    load_0_6_7  segment_prefix_ub_916  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_8  arc_capacity_538  -30
    arc_0_6_8  connected_order_arc_539  -17
    arc_0_6_8  out_degree_903  1
    arc_0_6_8  in_degree_918  1
    arc_0_6_8  original_T_including_depot_unload_979  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_8  arc_capacity_538  1
    load_0_6_8  segment_load_conservation_907  1
    load_0_6_8  segment_load_conservation_921  -1
    load_0_6_8  segment_prefix_lb_922  1
    load_0_6_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_540  -30
    arc_0_6_11  connected_order_arc_541  -17
    arc_0_6_11  out_degree_903  1
    arc_0_6_11  in_degree_925  1
    arc_0_6_11  original_T_including_depot_unload_979  2.8118819084250831e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_540  1
    load_0_6_11  segment_load_conservation_907  1
    load_0_6_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_542  -30
    arc_0_6_12  connected_order_arc_543  -17
    arc_0_6_12  out_degree_903  1
    arc_0_6_12  in_degree_931  1
    arc_0_6_12  original_T_including_depot_unload_979  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_542  1
    load_0_6_12  segment_load_conservation_907  1
    load_0_6_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_544  -30
    arc_0_6_13  connected_order_arc_545  -17
    arc_0_6_13  out_degree_903  1
    arc_0_6_13  in_degree_937  1
    arc_0_6_13  original_T_including_depot_unload_979  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_544  1
    load_0_6_13  segment_load_conservation_907  1
    load_0_6_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_546  -30
    arc_0_6_14  connected_order_arc_547  -17
    arc_0_6_14  out_degree_903  1
    arc_0_6_14  in_degree_943  1
    arc_0_6_14  original_T_including_depot_unload_979  3.0078695794061259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_546  1
    load_0_6_14  segment_load_conservation_907  1
    load_0_6_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_548  -30
    arc_0_6_15  connected_order_arc_549  -17
    arc_0_6_15  out_degree_903  1
    arc_0_6_15  in_degree_949  1
    arc_0_6_15  original_T_including_depot_unload_979  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_548  1
    load_0_6_15  segment_load_conservation_907  1
    load_0_6_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_550  -30
    arc_0_6_16  connected_order_arc_551  -17
    arc_0_6_16  out_degree_903  1
    arc_0_6_16  in_degree_955  1
    arc_0_6_16  original_T_including_depot_unload_979  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_550  1
    load_0_6_16  segment_load_conservation_907  1
    load_0_6_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_552  -30
    arc_0_6_17  connected_order_arc_553  -17
    arc_0_6_17  out_degree_903  1
    arc_0_6_17  in_degree_961  1
    arc_0_6_17  original_T_including_depot_unload_979  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_552  1
    load_0_6_17  segment_load_conservation_907  1
    load_0_6_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_554  -30
    arc_0_6_18  connected_order_arc_555  -17
    arc_0_6_18  out_degree_903  1
    arc_0_6_18  in_degree_967  1
    arc_0_6_18  original_T_including_depot_unload_979  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_554  1
    load_0_6_18  segment_load_conservation_907  1
    load_0_6_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_0  arc_capacity_556  -30
    arc_0_7_0  depot_return_or_bypass_867  1
    arc_0_7_0  out_degree_910  1
    arc_0_7_0  original_T_including_depot_unload_979  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_0  arc_capacity_556  1
    load_0_7_0  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_1  arc_capacity_557  -30
    arc_0_7_1  connected_order_arc_558  -17
    arc_0_7_1  in_degree_869  1
    arc_0_7_1  out_degree_910  1
    arc_0_7_1  original_T_including_depot_unload_979  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_1  arc_capacity_557  1
    load_0_7_1  segment_load_conservation_872  -1
    load_0_7_1  segment_prefix_lb_873  1
    load_0_7_1  segment_prefix_ub_874  1
    load_0_7_1  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_2  arc_capacity_559  -30
    arc_0_7_2  connected_order_arc_560  -17
    arc_0_7_2  in_degree_876  1
    arc_0_7_2  out_degree_910  1
    arc_0_7_2  original_T_including_depot_unload_979  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_2  arc_capacity_559  1
    load_0_7_2  segment_load_conservation_879  -1
    load_0_7_2  segment_prefix_lb_880  1
    load_0_7_2  segment_prefix_ub_881  1
    load_0_7_2  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_3  arc_capacity_561  -30
    arc_0_7_3  connected_order_arc_562  -17
    arc_0_7_3  in_degree_883  1
    arc_0_7_3  out_degree_910  1
    arc_0_7_3  original_T_including_depot_unload_979  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_3  arc_capacity_561  1
    load_0_7_3  segment_load_conservation_886  -1
    load_0_7_3  segment_prefix_lb_887  1
    load_0_7_3  segment_prefix_ub_888  1
    load_0_7_3  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_4  arc_capacity_563  -30
    arc_0_7_4  connected_order_arc_564  -17
    arc_0_7_4  in_degree_890  1
    arc_0_7_4  out_degree_910  1
    arc_0_7_4  original_T_including_depot_unload_979  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_4  arc_capacity_563  1
    load_0_7_4  segment_load_conservation_893  -1
    load_0_7_4  segment_prefix_lb_894  1
    load_0_7_4  segment_prefix_ub_895  1
    load_0_7_4  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_5  arc_capacity_565  -30
    arc_0_7_5  connected_order_arc_566  -17
    arc_0_7_5  in_degree_897  1
    arc_0_7_5  out_degree_910  1
    arc_0_7_5  original_T_including_depot_unload_979  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_5  arc_capacity_565  1
    load_0_7_5  segment_load_conservation_900  -1
    load_0_7_5  segment_prefix_lb_901  1
    load_0_7_5  segment_prefix_ub_902  1
    load_0_7_5  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_6  arc_capacity_567  -30
    arc_0_7_6  connected_order_arc_568  -17
    arc_0_7_6  in_degree_904  1
    arc_0_7_6  out_degree_910  1
    arc_0_7_6  original_T_including_depot_unload_979  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_6  arc_capacity_567  1
    load_0_7_6  segment_load_conservation_907  -1
    load_0_7_6  segment_prefix_lb_908  1
    load_0_7_6  segment_prefix_ub_909  1
    load_0_7_6  segment_load_conservation_914  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_8  arc_capacity_569  -30
    arc_0_7_8  connected_order_arc_570  -17
    arc_0_7_8  out_degree_910  1
    arc_0_7_8  in_degree_918  1
    arc_0_7_8  original_T_including_depot_unload_979  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_8  arc_capacity_569  1
    load_0_7_8  segment_load_conservation_914  1
    load_0_7_8  segment_load_conservation_921  -1
    load_0_7_8  segment_prefix_lb_922  1
    load_0_7_8  segment_prefix_ub_923  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_11  arc_capacity_571  -30
    arc_0_7_11  connected_order_arc_572  -17
    arc_0_7_11  out_degree_910  1
    arc_0_7_11  in_degree_925  1
    arc_0_7_11  original_T_including_depot_unload_979  2.7275263449800736e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_11  arc_capacity_571  1
    load_0_7_11  segment_load_conservation_914  1
    load_0_7_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_12  arc_capacity_573  -30
    arc_0_7_12  connected_order_arc_574  -17
    arc_0_7_12  out_degree_910  1
    arc_0_7_12  in_degree_931  1
    arc_0_7_12  original_T_including_depot_unload_979  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_12  arc_capacity_573  1
    load_0_7_12  segment_load_conservation_914  1
    load_0_7_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_13  arc_capacity_575  -30
    arc_0_7_13  connected_order_arc_576  -17
    arc_0_7_13  out_degree_910  1
    arc_0_7_13  in_degree_937  1
    arc_0_7_13  original_T_including_depot_unload_979  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_13  arc_capacity_575  1
    load_0_7_13  segment_load_conservation_914  1
    load_0_7_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_14  arc_capacity_577  -30
    arc_0_7_14  connected_order_arc_578  -17
    arc_0_7_14  out_degree_910  1
    arc_0_7_14  in_degree_943  1
    arc_0_7_14  original_T_including_depot_unload_979  2.9299952981117208e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_14  arc_capacity_577  1
    load_0_7_14  segment_load_conservation_914  1
    load_0_7_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_15  arc_capacity_579  -30
    arc_0_7_15  connected_order_arc_580  -17
    arc_0_7_15  out_degree_910  1
    arc_0_7_15  in_degree_949  1
    arc_0_7_15  original_T_including_depot_unload_979  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_15  arc_capacity_579  1
    load_0_7_15  segment_load_conservation_914  1
    load_0_7_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_16  arc_capacity_581  -30
    arc_0_7_16  connected_order_arc_582  -17
    arc_0_7_16  out_degree_910  1
    arc_0_7_16  in_degree_955  1
    arc_0_7_16  original_T_including_depot_unload_979  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_16  arc_capacity_581  1
    load_0_7_16  segment_load_conservation_914  1
    load_0_7_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_17  arc_capacity_583  -30
    arc_0_7_17  connected_order_arc_584  -17
    arc_0_7_17  out_degree_910  1
    arc_0_7_17  in_degree_961  1
    arc_0_7_17  original_T_including_depot_unload_979  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_17  arc_capacity_583  1
    load_0_7_17  segment_load_conservation_914  1
    load_0_7_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_18  arc_capacity_585  -30
    arc_0_7_18  connected_order_arc_586  -17
    arc_0_7_18  out_degree_910  1
    arc_0_7_18  in_degree_967  1
    arc_0_7_18  original_T_including_depot_unload_979  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_18  arc_capacity_585  1
    load_0_7_18  segment_load_conservation_914  1
    load_0_7_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_587  -30
    arc_0_8_0  depot_return_or_bypass_867  1
    arc_0_8_0  out_degree_917  1
    arc_0_8_0  original_T_including_depot_unload_979  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_587  1
    load_0_8_0  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_588  -30
    arc_0_8_1  connected_order_arc_589  -17
    arc_0_8_1  in_degree_869  1
    arc_0_8_1  out_degree_917  1
    arc_0_8_1  original_T_including_depot_unload_979  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_588  1
    load_0_8_1  segment_load_conservation_872  -1
    load_0_8_1  segment_prefix_lb_873  1
    load_0_8_1  segment_prefix_ub_874  1
    load_0_8_1  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_590  -30
    arc_0_8_2  connected_order_arc_591  -17
    arc_0_8_2  in_degree_876  1
    arc_0_8_2  out_degree_917  1
    arc_0_8_2  original_T_including_depot_unload_979  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_590  1
    load_0_8_2  segment_load_conservation_879  -1
    load_0_8_2  segment_prefix_lb_880  1
    load_0_8_2  segment_prefix_ub_881  1
    load_0_8_2  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_592  -30
    arc_0_8_3  connected_order_arc_593  -17
    arc_0_8_3  in_degree_883  1
    arc_0_8_3  out_degree_917  1
    arc_0_8_3  original_T_including_depot_unload_979  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_592  1
    load_0_8_3  segment_load_conservation_886  -1
    load_0_8_3  segment_prefix_lb_887  1
    load_0_8_3  segment_prefix_ub_888  1
    load_0_8_3  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_594  -30
    arc_0_8_4  connected_order_arc_595  -17
    arc_0_8_4  in_degree_890  1
    arc_0_8_4  out_degree_917  1
    arc_0_8_4  original_T_including_depot_unload_979  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_594  1
    load_0_8_4  segment_load_conservation_893  -1
    load_0_8_4  segment_prefix_lb_894  1
    load_0_8_4  segment_prefix_ub_895  1
    load_0_8_4  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_596  -30
    arc_0_8_5  connected_order_arc_597  -17
    arc_0_8_5  in_degree_897  1
    arc_0_8_5  out_degree_917  1
    arc_0_8_5  original_T_including_depot_unload_979  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_596  1
    load_0_8_5  segment_load_conservation_900  -1
    load_0_8_5  segment_prefix_lb_901  1
    load_0_8_5  segment_prefix_ub_902  1
    load_0_8_5  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_6  arc_capacity_598  -30
    arc_0_8_6  connected_order_arc_599  -17
    arc_0_8_6  in_degree_904  1
    arc_0_8_6  out_degree_917  1
    arc_0_8_6  original_T_including_depot_unload_979  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_6  arc_capacity_598  1
    load_0_8_6  segment_load_conservation_907  -1
    load_0_8_6  segment_prefix_lb_908  1
    load_0_8_6  segment_prefix_ub_909  1
    load_0_8_6  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_7  arc_capacity_600  -30
    arc_0_8_7  connected_order_arc_601  -17
    arc_0_8_7  in_degree_911  1
    arc_0_8_7  out_degree_917  1
    arc_0_8_7  original_T_including_depot_unload_979  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_7  arc_capacity_600  1
    load_0_8_7  segment_load_conservation_914  -1
    load_0_8_7  segment_prefix_lb_915  1
    load_0_8_7  segment_prefix_ub_916  1
    load_0_8_7  segment_load_conservation_921  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_602  -30
    arc_0_8_11  connected_order_arc_603  -17
    arc_0_8_11  out_degree_917  1
    arc_0_8_11  in_degree_925  1
    arc_0_8_11  original_T_including_depot_unload_979  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_602  1
    load_0_8_11  segment_load_conservation_921  1
    load_0_8_11  free_load_conservation_929  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_604  -30
    arc_0_8_12  connected_order_arc_605  -17
    arc_0_8_12  out_degree_917  1
    arc_0_8_12  in_degree_931  1
    arc_0_8_12  original_T_including_depot_unload_979  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_604  1
    load_0_8_12  segment_load_conservation_921  1
    load_0_8_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_606  -30
    arc_0_8_13  connected_order_arc_607  -17
    arc_0_8_13  out_degree_917  1
    arc_0_8_13  in_degree_937  1
    arc_0_8_13  original_T_including_depot_unload_979  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_606  1
    load_0_8_13  segment_load_conservation_921  1
    load_0_8_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_608  -30
    arc_0_8_14  connected_order_arc_609  -17
    arc_0_8_14  out_degree_917  1
    arc_0_8_14  in_degree_943  1
    arc_0_8_14  original_T_including_depot_unload_979  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_608  1
    load_0_8_14  segment_load_conservation_921  1
    load_0_8_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_610  -30
    arc_0_8_15  connected_order_arc_611  -17
    arc_0_8_15  out_degree_917  1
    arc_0_8_15  in_degree_949  1
    arc_0_8_15  original_T_including_depot_unload_979  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_610  1
    load_0_8_15  segment_load_conservation_921  1
    load_0_8_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_16  arc_capacity_612  -30
    arc_0_8_16  connected_order_arc_613  -17
    arc_0_8_16  out_degree_917  1
    arc_0_8_16  in_degree_955  1
    arc_0_8_16  original_T_including_depot_unload_979  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_16  arc_capacity_612  1
    load_0_8_16  segment_load_conservation_921  1
    load_0_8_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_17  arc_capacity_614  -30
    arc_0_8_17  connected_order_arc_615  -17
    arc_0_8_17  out_degree_917  1
    arc_0_8_17  in_degree_961  1
    arc_0_8_17  original_T_including_depot_unload_979  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_17  arc_capacity_614  1
    load_0_8_17  segment_load_conservation_921  1
    load_0_8_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_18  arc_capacity_616  -30
    arc_0_8_18  connected_order_arc_617  -17
    arc_0_8_18  out_degree_917  1
    arc_0_8_18  in_degree_967  1
    arc_0_8_18  original_T_including_depot_unload_979  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_18  arc_capacity_616  1
    load_0_8_18  segment_load_conservation_921  1
    load_0_8_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_618  -30
    arc_0_11_0  depot_return_or_bypass_867  1
    arc_0_11_0  out_degree_924  1
    arc_0_11_0  original_T_including_depot_unload_979  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_618  1
    load_0_11_0  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_619  -30
    arc_0_11_1  connected_order_arc_620  -17
    arc_0_11_1  in_degree_869  1
    arc_0_11_1  out_degree_924  1
    arc_0_11_1  original_T_including_depot_unload_979  2.7384186870432241e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_619  1
    load_0_11_1  segment_load_conservation_872  -1
    load_0_11_1  segment_prefix_lb_873  1
    load_0_11_1  segment_prefix_ub_874  1
    load_0_11_1  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_621  -30
    arc_0_11_2  connected_order_arc_622  -17
    arc_0_11_2  in_degree_876  1
    arc_0_11_2  out_degree_924  1
    arc_0_11_2  original_T_including_depot_unload_979  3.0014740451067628e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_621  1
    load_0_11_2  segment_load_conservation_879  -1
    load_0_11_2  segment_prefix_lb_880  1
    load_0_11_2  segment_prefix_ub_881  1
    load_0_11_2  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_623  -30
    arc_0_11_3  connected_order_arc_624  -17
    arc_0_11_3  in_degree_883  1
    arc_0_11_3  out_degree_924  1
    arc_0_11_3  original_T_including_depot_unload_979  3.2308847977395667e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_623  1
    load_0_11_3  segment_load_conservation_886  -1
    load_0_11_3  segment_prefix_lb_887  1
    load_0_11_3  segment_prefix_ub_888  1
    load_0_11_3  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_625  -30
    arc_0_11_4  connected_order_arc_626  -17
    arc_0_11_4  in_degree_890  1
    arc_0_11_4  out_degree_924  1
    arc_0_11_4  original_T_including_depot_unload_979  2.8044705317383118e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_625  1
    load_0_11_4  segment_load_conservation_893  -1
    load_0_11_4  segment_prefix_lb_894  1
    load_0_11_4  segment_prefix_ub_895  1
    load_0_11_4  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_627  -30
    arc_0_11_5  connected_order_arc_628  -17
    arc_0_11_5  in_degree_897  1
    arc_0_11_5  out_degree_924  1
    arc_0_11_5  original_T_including_depot_unload_979  2.8096824480964965e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_627  1
    load_0_11_5  segment_load_conservation_900  -1
    load_0_11_5  segment_prefix_lb_901  1
    load_0_11_5  segment_prefix_ub_902  1
    load_0_11_5  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_629  -30
    arc_0_11_6  connected_order_arc_630  -17
    arc_0_11_6  in_degree_904  1
    arc_0_11_6  out_degree_924  1
    arc_0_11_6  original_T_including_depot_unload_979  2.8118819084250831e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_629  1
    load_0_11_6  segment_load_conservation_907  -1
    load_0_11_6  segment_prefix_lb_908  1
    load_0_11_6  segment_prefix_ub_909  1
    load_0_11_6  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_7  arc_capacity_631  -30
    arc_0_11_7  connected_order_arc_632  -17
    arc_0_11_7  in_degree_911  1
    arc_0_11_7  out_degree_924  1
    arc_0_11_7  original_T_including_depot_unload_979  2.7275263449800736e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_7  arc_capacity_631  1
    load_0_11_7  segment_load_conservation_914  -1
    load_0_11_7  segment_prefix_lb_915  1
    load_0_11_7  segment_prefix_ub_916  1
    load_0_11_7  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_633  -30
    arc_0_11_8  connected_order_arc_634  -17
    arc_0_11_8  in_degree_918  1
    arc_0_11_8  out_degree_924  1
    arc_0_11_8  original_T_including_depot_unload_979  2.5026151120907321e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_633  1
    load_0_11_8  segment_load_conservation_921  -1
    load_0_11_8  segment_prefix_lb_922  1
    load_0_11_8  segment_prefix_ub_923  1
    load_0_11_8  free_load_conservation_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_635  -30
    arc_0_11_12  connected_order_arc_636  -17
    arc_0_11_12  out_degree_924  1
    arc_0_11_12  in_degree_931  1
    arc_0_11_12  original_T_including_depot_unload_979  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_635  1
    load_0_11_12  free_load_conservation_929  1
    load_0_11_12  free_load_conservation_935  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_637  -30
    arc_0_11_13  connected_order_arc_638  -17
    arc_0_11_13  out_degree_924  1
    arc_0_11_13  in_degree_937  1
    arc_0_11_13  original_T_including_depot_unload_979  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_637  1
    load_0_11_13  free_load_conservation_929  1
    load_0_11_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_639  -30
    arc_0_11_14  connected_order_arc_640  -17
    arc_0_11_14  out_degree_924  1
    arc_0_11_14  in_degree_943  1
    arc_0_11_14  original_T_including_depot_unload_979  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_639  1
    load_0_11_14  free_load_conservation_929  1
    load_0_11_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_641  -30
    arc_0_11_15  connected_order_arc_642  -17
    arc_0_11_15  out_degree_924  1
    arc_0_11_15  in_degree_949  1
    arc_0_11_15  original_T_including_depot_unload_979  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_641  1
    load_0_11_15  free_load_conservation_929  1
    load_0_11_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_643  -30
    arc_0_11_16  connected_order_arc_644  -17
    arc_0_11_16  out_degree_924  1
    arc_0_11_16  in_degree_955  1
    arc_0_11_16  original_T_including_depot_unload_979  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_643  1
    load_0_11_16  free_load_conservation_929  1
    load_0_11_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_17  arc_capacity_645  -30
    arc_0_11_17  connected_order_arc_646  -17
    arc_0_11_17  out_degree_924  1
    arc_0_11_17  in_degree_961  1
    arc_0_11_17  original_T_including_depot_unload_979  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_17  arc_capacity_645  1
    load_0_11_17  free_load_conservation_929  1
    load_0_11_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_18  arc_capacity_647  -30
    arc_0_11_18  connected_order_arc_648  -17
    arc_0_11_18  out_degree_924  1
    arc_0_11_18  in_degree_967  1
    arc_0_11_18  original_T_including_depot_unload_979  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_0_11_18  arc_capacity_647  1
    load_0_11_18  free_load_conservation_929  1
    load_0_11_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_649  -30
    arc_0_12_0  depot_return_or_bypass_867  1
    arc_0_12_0  out_degree_930  1
    arc_0_12_0  original_T_including_depot_unload_979  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_649  1
    load_0_12_0  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_650  -30
    arc_0_12_1  connected_order_arc_651  -17
    arc_0_12_1  in_degree_869  1
    arc_0_12_1  out_degree_930  1
    arc_0_12_1  original_T_including_depot_unload_979  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_650  1
    load_0_12_1  segment_load_conservation_872  -1
    load_0_12_1  segment_prefix_lb_873  1
    load_0_12_1  segment_prefix_ub_874  1
    load_0_12_1  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_652  -30
    arc_0_12_2  connected_order_arc_653  -17
    arc_0_12_2  in_degree_876  1
    arc_0_12_2  out_degree_930  1
    arc_0_12_2  original_T_including_depot_unload_979  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_652  1
    load_0_12_2  segment_load_conservation_879  -1
    load_0_12_2  segment_prefix_lb_880  1
    load_0_12_2  segment_prefix_ub_881  1
    load_0_12_2  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_654  -30
    arc_0_12_3  connected_order_arc_655  -17
    arc_0_12_3  in_degree_883  1
    arc_0_12_3  out_degree_930  1
    arc_0_12_3  original_T_including_depot_unload_979  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_654  1
    load_0_12_3  segment_load_conservation_886  -1
    load_0_12_3  segment_prefix_lb_887  1
    load_0_12_3  segment_prefix_ub_888  1
    load_0_12_3  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_656  -30
    arc_0_12_4  connected_order_arc_657  -17
    arc_0_12_4  in_degree_890  1
    arc_0_12_4  out_degree_930  1
    arc_0_12_4  original_T_including_depot_unload_979  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_656  1
    load_0_12_4  segment_load_conservation_893  -1
    load_0_12_4  segment_prefix_lb_894  1
    load_0_12_4  segment_prefix_ub_895  1
    load_0_12_4  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_658  -30
    arc_0_12_5  connected_order_arc_659  -17
    arc_0_12_5  in_degree_897  1
    arc_0_12_5  out_degree_930  1
    arc_0_12_5  original_T_including_depot_unload_979  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_658  1
    load_0_12_5  segment_load_conservation_900  -1
    load_0_12_5  segment_prefix_lb_901  1
    load_0_12_5  segment_prefix_ub_902  1
    load_0_12_5  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_660  -30
    arc_0_12_6  connected_order_arc_661  -17
    arc_0_12_6  in_degree_904  1
    arc_0_12_6  out_degree_930  1
    arc_0_12_6  original_T_including_depot_unload_979  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_660  1
    load_0_12_6  segment_load_conservation_907  -1
    load_0_12_6  segment_prefix_lb_908  1
    load_0_12_6  segment_prefix_ub_909  1
    load_0_12_6  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_7  arc_capacity_662  -30
    arc_0_12_7  connected_order_arc_663  -17
    arc_0_12_7  in_degree_911  1
    arc_0_12_7  out_degree_930  1
    arc_0_12_7  original_T_including_depot_unload_979  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_7  arc_capacity_662  1
    load_0_12_7  segment_load_conservation_914  -1
    load_0_12_7  segment_prefix_lb_915  1
    load_0_12_7  segment_prefix_ub_916  1
    load_0_12_7  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_664  -30
    arc_0_12_8  connected_order_arc_665  -17
    arc_0_12_8  in_degree_918  1
    arc_0_12_8  out_degree_930  1
    arc_0_12_8  original_T_including_depot_unload_979  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_664  1
    load_0_12_8  segment_load_conservation_921  -1
    load_0_12_8  segment_prefix_lb_922  1
    load_0_12_8  segment_prefix_ub_923  1
    load_0_12_8  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_666  -30
    arc_0_12_11  connected_order_arc_667  -17
    arc_0_12_11  in_degree_925  1
    arc_0_12_11  out_degree_930  1
    arc_0_12_11  original_T_including_depot_unload_979  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_666  1
    load_0_12_11  free_load_conservation_929  -1
    load_0_12_11  free_load_conservation_935  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_668  -30
    arc_0_12_13  connected_order_arc_669  -17
    arc_0_12_13  out_degree_930  1
    arc_0_12_13  in_degree_937  1
    arc_0_12_13  original_T_including_depot_unload_979  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_668  1
    load_0_12_13  free_load_conservation_935  1
    load_0_12_13  free_load_conservation_941  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_670  -30
    arc_0_12_14  connected_order_arc_671  -17
    arc_0_12_14  out_degree_930  1
    arc_0_12_14  in_degree_943  1
    arc_0_12_14  original_T_including_depot_unload_979  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_670  1
    load_0_12_14  free_load_conservation_935  1
    load_0_12_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_672  -30
    arc_0_12_15  connected_order_arc_673  -17
    arc_0_12_15  out_degree_930  1
    arc_0_12_15  in_degree_949  1
    arc_0_12_15  original_T_including_depot_unload_979  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_672  1
    load_0_12_15  free_load_conservation_935  1
    load_0_12_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_674  -30
    arc_0_12_16  connected_order_arc_675  -17
    arc_0_12_16  out_degree_930  1
    arc_0_12_16  in_degree_955  1
    arc_0_12_16  original_T_including_depot_unload_979  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_674  1
    load_0_12_16  free_load_conservation_935  1
    load_0_12_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_676  -30
    arc_0_12_17  connected_order_arc_677  -17
    arc_0_12_17  out_degree_930  1
    arc_0_12_17  in_degree_961  1
    arc_0_12_17  original_T_including_depot_unload_979  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_676  1
    load_0_12_17  free_load_conservation_935  1
    load_0_12_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_678  -30
    arc_0_12_18  connected_order_arc_679  -17
    arc_0_12_18  out_degree_930  1
    arc_0_12_18  in_degree_967  1
    arc_0_12_18  original_T_including_depot_unload_979  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_678  1
    load_0_12_18  free_load_conservation_935  1
    load_0_12_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_680  -30
    arc_0_13_0  depot_return_or_bypass_867  1
    arc_0_13_0  out_degree_936  1
    arc_0_13_0  original_T_including_depot_unload_979  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_680  1
    load_0_13_0  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_681  -30
    arc_0_13_1  connected_order_arc_682  -17
    arc_0_13_1  in_degree_869  1
    arc_0_13_1  out_degree_936  1
    arc_0_13_1  original_T_including_depot_unload_979  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_681  1
    load_0_13_1  segment_load_conservation_872  -1
    load_0_13_1  segment_prefix_lb_873  1
    load_0_13_1  segment_prefix_ub_874  1
    load_0_13_1  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_683  -30
    arc_0_13_2  connected_order_arc_684  -17
    arc_0_13_2  in_degree_876  1
    arc_0_13_2  out_degree_936  1
    arc_0_13_2  original_T_including_depot_unload_979  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_683  1
    load_0_13_2  segment_load_conservation_879  -1
    load_0_13_2  segment_prefix_lb_880  1
    load_0_13_2  segment_prefix_ub_881  1
    load_0_13_2  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_685  -30
    arc_0_13_3  connected_order_arc_686  -17
    arc_0_13_3  in_degree_883  1
    arc_0_13_3  out_degree_936  1
    arc_0_13_3  original_T_including_depot_unload_979  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_685  1
    load_0_13_3  segment_load_conservation_886  -1
    load_0_13_3  segment_prefix_lb_887  1
    load_0_13_3  segment_prefix_ub_888  1
    load_0_13_3  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_687  -30
    arc_0_13_4  connected_order_arc_688  -17
    arc_0_13_4  in_degree_890  1
    arc_0_13_4  out_degree_936  1
    arc_0_13_4  original_T_including_depot_unload_979  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_687  1
    load_0_13_4  segment_load_conservation_893  -1
    load_0_13_4  segment_prefix_lb_894  1
    load_0_13_4  segment_prefix_ub_895  1
    load_0_13_4  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_689  -30
    arc_0_13_5  connected_order_arc_690  -17
    arc_0_13_5  in_degree_897  1
    arc_0_13_5  out_degree_936  1
    arc_0_13_5  original_T_including_depot_unload_979  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_689  1
    load_0_13_5  segment_load_conservation_900  -1
    load_0_13_5  segment_prefix_lb_901  1
    load_0_13_5  segment_prefix_ub_902  1
    load_0_13_5  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_691  -30
    arc_0_13_6  connected_order_arc_692  -17
    arc_0_13_6  in_degree_904  1
    arc_0_13_6  out_degree_936  1
    arc_0_13_6  original_T_including_depot_unload_979  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_691  1
    load_0_13_6  segment_load_conservation_907  -1
    load_0_13_6  segment_prefix_lb_908  1
    load_0_13_6  segment_prefix_ub_909  1
    load_0_13_6  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_7  arc_capacity_693  -30
    arc_0_13_7  connected_order_arc_694  -17
    arc_0_13_7  in_degree_911  1
    arc_0_13_7  out_degree_936  1
    arc_0_13_7  original_T_including_depot_unload_979  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_7  arc_capacity_693  1
    load_0_13_7  segment_load_conservation_914  -1
    load_0_13_7  segment_prefix_lb_915  1
    load_0_13_7  segment_prefix_ub_916  1
    load_0_13_7  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_695  -30
    arc_0_13_8  connected_order_arc_696  -17
    arc_0_13_8  in_degree_918  1
    arc_0_13_8  out_degree_936  1
    arc_0_13_8  original_T_including_depot_unload_979  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_695  1
    load_0_13_8  segment_load_conservation_921  -1
    load_0_13_8  segment_prefix_lb_922  1
    load_0_13_8  segment_prefix_ub_923  1
    load_0_13_8  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_697  -30
    arc_0_13_11  connected_order_arc_698  -17
    arc_0_13_11  in_degree_925  1
    arc_0_13_11  out_degree_936  1
    arc_0_13_11  original_T_including_depot_unload_979  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_697  1
    load_0_13_11  free_load_conservation_929  -1
    load_0_13_11  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_699  -30
    arc_0_13_12  connected_order_arc_700  -17
    arc_0_13_12  in_degree_931  1
    arc_0_13_12  out_degree_936  1
    arc_0_13_12  original_T_including_depot_unload_979  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_699  1
    load_0_13_12  free_load_conservation_935  -1
    load_0_13_12  free_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_701  -30
    arc_0_13_14  connected_order_arc_702  -17
    arc_0_13_14  out_degree_936  1
    arc_0_13_14  in_degree_943  1
    arc_0_13_14  original_T_including_depot_unload_979  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_701  1
    load_0_13_14  free_load_conservation_941  1
    load_0_13_14  free_load_conservation_947  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_703  -30
    arc_0_13_15  connected_order_arc_704  -17
    arc_0_13_15  out_degree_936  1
    arc_0_13_15  in_degree_949  1
    arc_0_13_15  original_T_including_depot_unload_979  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_703  1
    load_0_13_15  free_load_conservation_941  1
    load_0_13_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_705  -30
    arc_0_13_16  connected_order_arc_706  -17
    arc_0_13_16  out_degree_936  1
    arc_0_13_16  in_degree_955  1
    arc_0_13_16  original_T_including_depot_unload_979  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_705  1
    load_0_13_16  free_load_conservation_941  1
    load_0_13_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_707  -30
    arc_0_13_17  connected_order_arc_708  -17
    arc_0_13_17  out_degree_936  1
    arc_0_13_17  in_degree_961  1
    arc_0_13_17  original_T_including_depot_unload_979  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_707  1
    load_0_13_17  free_load_conservation_941  1
    load_0_13_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_709  -30
    arc_0_13_18  connected_order_arc_710  -17
    arc_0_13_18  out_degree_936  1
    arc_0_13_18  in_degree_967  1
    arc_0_13_18  original_T_including_depot_unload_979  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_709  1
    load_0_13_18  free_load_conservation_941  1
    load_0_13_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_711  -30
    arc_0_14_0  depot_return_or_bypass_867  1
    arc_0_14_0  out_degree_942  1
    arc_0_14_0  original_T_including_depot_unload_979  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_711  1
    load_0_14_0  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_712  -30
    arc_0_14_1  connected_order_arc_713  -17
    arc_0_14_1  in_degree_869  1
    arc_0_14_1  out_degree_942  1
    arc_0_14_1  original_T_including_depot_unload_979  2.9475580354409412e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_712  1
    load_0_14_1  segment_load_conservation_872  -1
    load_0_14_1  segment_prefix_lb_873  1
    load_0_14_1  segment_prefix_ub_874  1
    load_0_14_1  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_714  -30
    arc_0_14_2  connected_order_arc_715  -17
    arc_0_14_2  in_degree_876  1
    arc_0_14_2  out_degree_942  1
    arc_0_14_2  original_T_including_depot_unload_979  3.1940365421146048e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_714  1
    load_0_14_2  segment_load_conservation_879  -1
    load_0_14_2  segment_prefix_lb_880  1
    load_0_14_2  segment_prefix_ub_881  1
    load_0_14_2  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_716  -30
    arc_0_14_3  connected_order_arc_717  -17
    arc_0_14_3  in_degree_883  1
    arc_0_14_3  out_degree_942  1
    arc_0_14_3  original_T_including_depot_unload_979  3.4153410343469327e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_716  1
    load_0_14_3  segment_load_conservation_886  -1
    load_0_14_3  segment_prefix_lb_887  1
    load_0_14_3  segment_prefix_ub_888  1
    load_0_14_3  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_718  -30
    arc_0_14_4  connected_order_arc_719  -17
    arc_0_14_4  in_degree_890  1
    arc_0_14_4  out_degree_942  1
    arc_0_14_4  original_T_including_depot_unload_979  2.9857518131746506e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_718  1
    load_0_14_4  segment_load_conservation_893  -1
    load_0_14_4  segment_prefix_lb_894  1
    load_0_14_4  segment_prefix_ub_895  1
    load_0_14_4  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_720  -30
    arc_0_14_5  connected_order_arc_721  -17
    arc_0_14_5  in_degree_897  1
    arc_0_14_5  out_degree_942  1
    arc_0_14_5  original_T_including_depot_unload_979  2.9992588346691123e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_720  1
    load_0_14_5  segment_load_conservation_900  -1
    load_0_14_5  segment_prefix_lb_901  1
    load_0_14_5  segment_prefix_ub_902  1
    load_0_14_5  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_722  -30
    arc_0_14_6  connected_order_arc_723  -17
    arc_0_14_6  in_degree_904  1
    arc_0_14_6  out_degree_942  1
    arc_0_14_6  original_T_including_depot_unload_979  3.0078695794061259e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_722  1
    load_0_14_6  segment_load_conservation_907  -1
    load_0_14_6  segment_prefix_lb_908  1
    load_0_14_6  segment_prefix_ub_909  1
    load_0_14_6  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_7  arc_capacity_724  -30
    arc_0_14_7  connected_order_arc_725  -17
    arc_0_14_7  in_degree_911  1
    arc_0_14_7  out_degree_942  1
    arc_0_14_7  original_T_including_depot_unload_979  2.9299952981117208e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_7  arc_capacity_724  1
    load_0_14_7  segment_load_conservation_914  -1
    load_0_14_7  segment_prefix_lb_915  1
    load_0_14_7  segment_prefix_ub_916  1
    load_0_14_7  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_726  -30
    arc_0_14_8  connected_order_arc_727  -17
    arc_0_14_8  in_degree_918  1
    arc_0_14_8  out_degree_942  1
    arc_0_14_8  original_T_including_depot_unload_979  2.7067041301428726e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_726  1
    load_0_14_8  segment_load_conservation_921  -1
    load_0_14_8  segment_prefix_lb_922  1
    load_0_14_8  segment_prefix_ub_923  1
    load_0_14_8  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_728  -30
    arc_0_14_11  connected_order_arc_729  -17
    arc_0_14_11  in_degree_925  1
    arc_0_14_11  out_degree_942  1
    arc_0_14_11  original_T_including_depot_unload_979  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_728  1
    load_0_14_11  free_load_conservation_929  -1
    load_0_14_11  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_730  -30
    arc_0_14_12  connected_order_arc_731  -17
    arc_0_14_12  in_degree_931  1
    arc_0_14_12  out_degree_942  1
    arc_0_14_12  original_T_including_depot_unload_979  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_730  1
    load_0_14_12  free_load_conservation_935  -1
    load_0_14_12  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_732  -30
    arc_0_14_13  connected_order_arc_733  -17
    arc_0_14_13  in_degree_937  1
    arc_0_14_13  out_degree_942  1
    arc_0_14_13  original_T_including_depot_unload_979  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_732  1
    load_0_14_13  free_load_conservation_941  -1
    load_0_14_13  free_load_conservation_947  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_734  -30
    arc_0_14_15  connected_order_arc_735  -17
    arc_0_14_15  out_degree_942  1
    arc_0_14_15  in_degree_949  1
    arc_0_14_15  original_T_including_depot_unload_979  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_734  1
    load_0_14_15  free_load_conservation_947  1
    load_0_14_15  free_load_conservation_953  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_736  -30
    arc_0_14_16  connected_order_arc_737  -17
    arc_0_14_16  out_degree_942  1
    arc_0_14_16  in_degree_955  1
    arc_0_14_16  original_T_including_depot_unload_979  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_736  1
    load_0_14_16  free_load_conservation_947  1
    load_0_14_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_738  -30
    arc_0_14_17  connected_order_arc_739  -17
    arc_0_14_17  out_degree_942  1
    arc_0_14_17  in_degree_961  1
    arc_0_14_17  original_T_including_depot_unload_979  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_738  1
    load_0_14_17  free_load_conservation_947  1
    load_0_14_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_740  -30
    arc_0_14_18  connected_order_arc_741  -17
    arc_0_14_18  out_degree_942  1
    arc_0_14_18  in_degree_967  1
    arc_0_14_18  original_T_including_depot_unload_979  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_740  1
    load_0_14_18  free_load_conservation_947  1
    load_0_14_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_742  -30
    arc_0_15_0  depot_return_or_bypass_867  1
    arc_0_15_0  out_degree_948  1
    arc_0_15_0  original_T_including_depot_unload_979  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_742  1
    load_0_15_0  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_743  -30
    arc_0_15_1  connected_order_arc_744  -17
    arc_0_15_1  in_degree_869  1
    arc_0_15_1  out_degree_948  1
    arc_0_15_1  original_T_including_depot_unload_979  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_743  1
    load_0_15_1  segment_load_conservation_872  -1
    load_0_15_1  segment_prefix_lb_873  1
    load_0_15_1  segment_prefix_ub_874  1
    load_0_15_1  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_745  -30
    arc_0_15_2  connected_order_arc_746  -17
    arc_0_15_2  in_degree_876  1
    arc_0_15_2  out_degree_948  1
    arc_0_15_2  original_T_including_depot_unload_979  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_745  1
    load_0_15_2  segment_load_conservation_879  -1
    load_0_15_2  segment_prefix_lb_880  1
    load_0_15_2  segment_prefix_ub_881  1
    load_0_15_2  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_747  -30
    arc_0_15_3  connected_order_arc_748  -17
    arc_0_15_3  in_degree_883  1
    arc_0_15_3  out_degree_948  1
    arc_0_15_3  original_T_including_depot_unload_979  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_747  1
    load_0_15_3  segment_load_conservation_886  -1
    load_0_15_3  segment_prefix_lb_887  1
    load_0_15_3  segment_prefix_ub_888  1
    load_0_15_3  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_749  -30
    arc_0_15_4  connected_order_arc_750  -17
    arc_0_15_4  in_degree_890  1
    arc_0_15_4  out_degree_948  1
    arc_0_15_4  original_T_including_depot_unload_979  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_749  1
    load_0_15_4  segment_load_conservation_893  -1
    load_0_15_4  segment_prefix_lb_894  1
    load_0_15_4  segment_prefix_ub_895  1
    load_0_15_4  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_751  -30
    arc_0_15_5  connected_order_arc_752  -17
    arc_0_15_5  in_degree_897  1
    arc_0_15_5  out_degree_948  1
    arc_0_15_5  original_T_including_depot_unload_979  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_751  1
    load_0_15_5  segment_load_conservation_900  -1
    load_0_15_5  segment_prefix_lb_901  1
    load_0_15_5  segment_prefix_ub_902  1
    load_0_15_5  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_753  -30
    arc_0_15_6  connected_order_arc_754  -17
    arc_0_15_6  in_degree_904  1
    arc_0_15_6  out_degree_948  1
    arc_0_15_6  original_T_including_depot_unload_979  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_753  1
    load_0_15_6  segment_load_conservation_907  -1
    load_0_15_6  segment_prefix_lb_908  1
    load_0_15_6  segment_prefix_ub_909  1
    load_0_15_6  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_7  arc_capacity_755  -30
    arc_0_15_7  connected_order_arc_756  -17
    arc_0_15_7  in_degree_911  1
    arc_0_15_7  out_degree_948  1
    arc_0_15_7  original_T_including_depot_unload_979  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_7  arc_capacity_755  1
    load_0_15_7  segment_load_conservation_914  -1
    load_0_15_7  segment_prefix_lb_915  1
    load_0_15_7  segment_prefix_ub_916  1
    load_0_15_7  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_757  -30
    arc_0_15_8  connected_order_arc_758  -17
    arc_0_15_8  in_degree_918  1
    arc_0_15_8  out_degree_948  1
    arc_0_15_8  original_T_including_depot_unload_979  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_757  1
    load_0_15_8  segment_load_conservation_921  -1
    load_0_15_8  segment_prefix_lb_922  1
    load_0_15_8  segment_prefix_ub_923  1
    load_0_15_8  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_759  -30
    arc_0_15_11  connected_order_arc_760  -17
    arc_0_15_11  in_degree_925  1
    arc_0_15_11  out_degree_948  1
    arc_0_15_11  original_T_including_depot_unload_979  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_759  1
    load_0_15_11  free_load_conservation_929  -1
    load_0_15_11  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_761  -30
    arc_0_15_12  connected_order_arc_762  -17
    arc_0_15_12  in_degree_931  1
    arc_0_15_12  out_degree_948  1
    arc_0_15_12  original_T_including_depot_unload_979  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_761  1
    load_0_15_12  free_load_conservation_935  -1
    load_0_15_12  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_763  -30
    arc_0_15_13  connected_order_arc_764  -17
    arc_0_15_13  in_degree_937  1
    arc_0_15_13  out_degree_948  1
    arc_0_15_13  original_T_including_depot_unload_979  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_763  1
    load_0_15_13  free_load_conservation_941  -1
    load_0_15_13  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_765  -30
    arc_0_15_14  connected_order_arc_766  -17
    arc_0_15_14  in_degree_943  1
    arc_0_15_14  out_degree_948  1
    arc_0_15_14  original_T_including_depot_unload_979  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_765  1
    load_0_15_14  free_load_conservation_947  -1
    load_0_15_14  free_load_conservation_953  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_767  -30
    arc_0_15_16  connected_order_arc_768  -17
    arc_0_15_16  out_degree_948  1
    arc_0_15_16  in_degree_955  1
    arc_0_15_16  original_T_including_depot_unload_979  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_767  1
    load_0_15_16  free_load_conservation_953  1
    load_0_15_16  free_load_conservation_959  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_769  -30
    arc_0_15_17  connected_order_arc_770  -17
    arc_0_15_17  out_degree_948  1
    arc_0_15_17  in_degree_961  1
    arc_0_15_17  original_T_including_depot_unload_979  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_769  1
    load_0_15_17  free_load_conservation_953  1
    load_0_15_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_771  -30
    arc_0_15_18  connected_order_arc_772  -17
    arc_0_15_18  out_degree_948  1
    arc_0_15_18  in_degree_967  1
    arc_0_15_18  original_T_including_depot_unload_979  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_771  1
    load_0_15_18  free_load_conservation_953  1
    load_0_15_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_773  -30
    arc_0_16_0  depot_return_or_bypass_867  1
    arc_0_16_0  out_degree_954  1
    arc_0_16_0  original_T_including_depot_unload_979  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_773  1
    load_0_16_0  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_774  -30
    arc_0_16_1  connected_order_arc_775  -17
    arc_0_16_1  in_degree_869  1
    arc_0_16_1  out_degree_954  1
    arc_0_16_1  original_T_including_depot_unload_979  2.6934497586971770e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_774  1
    load_0_16_1  segment_load_conservation_872  -1
    load_0_16_1  segment_prefix_lb_873  1
    load_0_16_1  segment_prefix_ub_874  1
    load_0_16_1  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_776  -30
    arc_0_16_2  connected_order_arc_777  -17
    arc_0_16_2  in_degree_876  1
    arc_0_16_2  out_degree_954  1
    arc_0_16_2  original_T_including_depot_unload_979  2.9919713471999544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_776  1
    load_0_16_2  segment_load_conservation_879  -1
    load_0_16_2  segment_prefix_lb_880  1
    load_0_16_2  segment_prefix_ub_881  1
    load_0_16_2  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_778  -30
    arc_0_16_3  connected_order_arc_779  -17
    arc_0_16_3  in_degree_883  1
    arc_0_16_3  out_degree_954  1
    arc_0_16_3  original_T_including_depot_unload_979  3.2360258354135326e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_778  1
    load_0_16_3  segment_load_conservation_886  -1
    load_0_16_3  segment_prefix_lb_887  1
    load_0_16_3  segment_prefix_ub_888  1
    load_0_16_3  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_780  -30
    arc_0_16_4  connected_order_arc_781  -17
    arc_0_16_4  in_degree_890  1
    arc_0_16_4  out_degree_954  1
    arc_0_16_4  original_T_including_depot_unload_979  2.8188003047777693e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_780  1
    load_0_16_4  segment_load_conservation_893  -1
    load_0_16_4  segment_prefix_lb_894  1
    load_0_16_4  segment_prefix_ub_895  1
    load_0_16_4  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_782  -30
    arc_0_16_5  connected_order_arc_783  -17
    arc_0_16_5  in_degree_897  1
    arc_0_16_5  out_degree_954  1
    arc_0_16_5  original_T_including_depot_unload_979  2.8077756945368888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_782  1
    load_0_16_5  segment_load_conservation_900  -1
    load_0_16_5  segment_prefix_lb_901  1
    load_0_16_5  segment_prefix_ub_902  1
    load_0_16_5  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_784  -30
    arc_0_16_6  connected_order_arc_785  -17
    arc_0_16_6  in_degree_904  1
    arc_0_16_6  out_degree_954  1
    arc_0_16_6  original_T_including_depot_unload_979  2.7966160677056928e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_784  1
    load_0_16_6  segment_load_conservation_907  -1
    load_0_16_6  segment_prefix_lb_908  1
    load_0_16_6  segment_prefix_ub_909  1
    load_0_16_6  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_7  arc_capacity_786  -30
    arc_0_16_7  connected_order_arc_787  -17
    arc_0_16_7  in_degree_911  1
    arc_0_16_7  out_degree_954  1
    arc_0_16_7  original_T_including_depot_unload_979  2.6985861397772510e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_7  arc_capacity_786  1
    load_0_16_7  segment_load_conservation_914  -1
    load_0_16_7  segment_prefix_lb_915  1
    load_0_16_7  segment_prefix_ub_916  1
    load_0_16_7  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_8  arc_capacity_788  -30
    arc_0_16_8  connected_order_arc_789  -17
    arc_0_16_8  in_degree_918  1
    arc_0_16_8  out_degree_954  1
    arc_0_16_8  original_T_including_depot_unload_979  2.4719804203198282e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_8  arc_capacity_788  1
    load_0_16_8  segment_load_conservation_921  -1
    load_0_16_8  segment_prefix_lb_922  1
    load_0_16_8  segment_prefix_ub_923  1
    load_0_16_8  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_790  -30
    arc_0_16_11  connected_order_arc_791  -17
    arc_0_16_11  in_degree_925  1
    arc_0_16_11  out_degree_954  1
    arc_0_16_11  original_T_including_depot_unload_979  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_790  1
    load_0_16_11  free_load_conservation_929  -1
    load_0_16_11  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_792  -30
    arc_0_16_12  connected_order_arc_793  -17
    arc_0_16_12  in_degree_931  1
    arc_0_16_12  out_degree_954  1
    arc_0_16_12  original_T_including_depot_unload_979  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_792  1
    load_0_16_12  free_load_conservation_935  -1
    load_0_16_12  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_794  -30
    arc_0_16_13  connected_order_arc_795  -17
    arc_0_16_13  in_degree_937  1
    arc_0_16_13  out_degree_954  1
    arc_0_16_13  original_T_including_depot_unload_979  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_794  1
    load_0_16_13  free_load_conservation_941  -1
    load_0_16_13  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_796  -30
    arc_0_16_14  connected_order_arc_797  -17
    arc_0_16_14  in_degree_943  1
    arc_0_16_14  out_degree_954  1
    arc_0_16_14  original_T_including_depot_unload_979  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_796  1
    load_0_16_14  free_load_conservation_947  -1
    load_0_16_14  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_798  -30
    arc_0_16_15  connected_order_arc_799  -17
    arc_0_16_15  in_degree_949  1
    arc_0_16_15  out_degree_954  1
    arc_0_16_15  original_T_including_depot_unload_979  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_798  1
    load_0_16_15  free_load_conservation_953  -1
    load_0_16_15  free_load_conservation_959  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_800  -30
    arc_0_16_17  connected_order_arc_801  -17
    arc_0_16_17  out_degree_954  1
    arc_0_16_17  in_degree_961  1
    arc_0_16_17  original_T_including_depot_unload_979  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_800  1
    load_0_16_17  free_load_conservation_959  1
    load_0_16_17  free_load_conservation_965  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_802  -30
    arc_0_16_18  connected_order_arc_803  -17
    arc_0_16_18  out_degree_954  1
    arc_0_16_18  in_degree_967  1
    arc_0_16_18  original_T_including_depot_unload_979  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_802  1
    load_0_16_18  free_load_conservation_959  1
    load_0_16_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_804  -30
    arc_0_17_0  depot_return_or_bypass_867  1
    arc_0_17_0  out_degree_960  1
    arc_0_17_0  original_T_including_depot_unload_979  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_804  1
    load_0_17_0  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_805  -30
    arc_0_17_1  connected_order_arc_806  -17
    arc_0_17_1  in_degree_869  1
    arc_0_17_1  out_degree_960  1
    arc_0_17_1  original_T_including_depot_unload_979  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_805  1
    load_0_17_1  segment_load_conservation_872  -1
    load_0_17_1  segment_prefix_lb_873  1
    load_0_17_1  segment_prefix_ub_874  1
    load_0_17_1  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_807  -30
    arc_0_17_2  connected_order_arc_808  -17
    arc_0_17_2  in_degree_876  1
    arc_0_17_2  out_degree_960  1
    arc_0_17_2  original_T_including_depot_unload_979  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_807  1
    load_0_17_2  segment_load_conservation_879  -1
    load_0_17_2  segment_prefix_lb_880  1
    load_0_17_2  segment_prefix_ub_881  1
    load_0_17_2  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_809  -30
    arc_0_17_3  connected_order_arc_810  -17
    arc_0_17_3  in_degree_883  1
    arc_0_17_3  out_degree_960  1
    arc_0_17_3  original_T_including_depot_unload_979  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_809  1
    load_0_17_3  segment_load_conservation_886  -1
    load_0_17_3  segment_prefix_lb_887  1
    load_0_17_3  segment_prefix_ub_888  1
    load_0_17_3  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_811  -30
    arc_0_17_4  connected_order_arc_812  -17
    arc_0_17_4  in_degree_890  1
    arc_0_17_4  out_degree_960  1
    arc_0_17_4  original_T_including_depot_unload_979  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_811  1
    load_0_17_4  segment_load_conservation_893  -1
    load_0_17_4  segment_prefix_lb_894  1
    load_0_17_4  segment_prefix_ub_895  1
    load_0_17_4  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_813  -30
    arc_0_17_5  connected_order_arc_814  -17
    arc_0_17_5  in_degree_897  1
    arc_0_17_5  out_degree_960  1
    arc_0_17_5  original_T_including_depot_unload_979  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_813  1
    load_0_17_5  segment_load_conservation_900  -1
    load_0_17_5  segment_prefix_lb_901  1
    load_0_17_5  segment_prefix_ub_902  1
    load_0_17_5  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_815  -30
    arc_0_17_6  connected_order_arc_816  -17
    arc_0_17_6  in_degree_904  1
    arc_0_17_6  out_degree_960  1
    arc_0_17_6  original_T_including_depot_unload_979  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_815  1
    load_0_17_6  segment_load_conservation_907  -1
    load_0_17_6  segment_prefix_lb_908  1
    load_0_17_6  segment_prefix_ub_909  1
    load_0_17_6  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_7  arc_capacity_817  -30
    arc_0_17_7  connected_order_arc_818  -17
    arc_0_17_7  in_degree_911  1
    arc_0_17_7  out_degree_960  1
    arc_0_17_7  original_T_including_depot_unload_979  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_7  arc_capacity_817  1
    load_0_17_7  segment_load_conservation_914  -1
    load_0_17_7  segment_prefix_lb_915  1
    load_0_17_7  segment_prefix_ub_916  1
    load_0_17_7  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_8  arc_capacity_819  -30
    arc_0_17_8  connected_order_arc_820  -17
    arc_0_17_8  in_degree_918  1
    arc_0_17_8  out_degree_960  1
    arc_0_17_8  original_T_including_depot_unload_979  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_8  arc_capacity_819  1
    load_0_17_8  segment_load_conservation_921  -1
    load_0_17_8  segment_prefix_lb_922  1
    load_0_17_8  segment_prefix_ub_923  1
    load_0_17_8  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_11  arc_capacity_821  -30
    arc_0_17_11  connected_order_arc_822  -17
    arc_0_17_11  in_degree_925  1
    arc_0_17_11  out_degree_960  1
    arc_0_17_11  original_T_including_depot_unload_979  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_11  arc_capacity_821  1
    load_0_17_11  free_load_conservation_929  -1
    load_0_17_11  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_823  -30
    arc_0_17_12  connected_order_arc_824  -17
    arc_0_17_12  in_degree_931  1
    arc_0_17_12  out_degree_960  1
    arc_0_17_12  original_T_including_depot_unload_979  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_823  1
    load_0_17_12  free_load_conservation_935  -1
    load_0_17_12  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_825  -30
    arc_0_17_13  connected_order_arc_826  -17
    arc_0_17_13  in_degree_937  1
    arc_0_17_13  out_degree_960  1
    arc_0_17_13  original_T_including_depot_unload_979  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_825  1
    load_0_17_13  free_load_conservation_941  -1
    load_0_17_13  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_827  -30
    arc_0_17_14  connected_order_arc_828  -17
    arc_0_17_14  in_degree_943  1
    arc_0_17_14  out_degree_960  1
    arc_0_17_14  original_T_including_depot_unload_979  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_827  1
    load_0_17_14  free_load_conservation_947  -1
    load_0_17_14  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_829  -30
    arc_0_17_15  connected_order_arc_830  -17
    arc_0_17_15  in_degree_949  1
    arc_0_17_15  out_degree_960  1
    arc_0_17_15  original_T_including_depot_unload_979  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_829  1
    load_0_17_15  free_load_conservation_953  -1
    load_0_17_15  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_831  -30
    arc_0_17_16  connected_order_arc_832  -17
    arc_0_17_16  in_degree_955  1
    arc_0_17_16  out_degree_960  1
    arc_0_17_16  original_T_including_depot_unload_979  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_831  1
    load_0_17_16  free_load_conservation_959  -1
    load_0_17_16  free_load_conservation_965  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_833  -30
    arc_0_17_18  connected_order_arc_834  -17
    arc_0_17_18  out_degree_960  1
    arc_0_17_18  in_degree_967  1
    arc_0_17_18  original_T_including_depot_unload_979  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_833  1
    load_0_17_18  free_load_conservation_965  1
    load_0_17_18  free_load_conservation_971  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_835  -30
    arc_0_18_0  depot_return_or_bypass_867  1
    arc_0_18_0  out_degree_966  1
    arc_0_18_0  original_T_including_depot_unload_979  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_835  1
    load_0_18_0  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_836  -30
    arc_0_18_1  connected_order_arc_837  -17
    arc_0_18_1  in_degree_869  1
    arc_0_18_1  out_degree_966  1
    arc_0_18_1  original_T_including_depot_unload_979  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_836  1
    load_0_18_1  segment_load_conservation_872  -1
    load_0_18_1  segment_prefix_lb_873  1
    load_0_18_1  segment_prefix_ub_874  1
    load_0_18_1  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_838  -30
    arc_0_18_2  connected_order_arc_839  -17
    arc_0_18_2  in_degree_876  1
    arc_0_18_2  out_degree_966  1
    arc_0_18_2  original_T_including_depot_unload_979  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_838  1
    load_0_18_2  segment_load_conservation_879  -1
    load_0_18_2  segment_prefix_lb_880  1
    load_0_18_2  segment_prefix_ub_881  1
    load_0_18_2  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_840  -30
    arc_0_18_3  connected_order_arc_841  -17
    arc_0_18_3  in_degree_883  1
    arc_0_18_3  out_degree_966  1
    arc_0_18_3  original_T_including_depot_unload_979  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_840  1
    load_0_18_3  segment_load_conservation_886  -1
    load_0_18_3  segment_prefix_lb_887  1
    load_0_18_3  segment_prefix_ub_888  1
    load_0_18_3  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_842  -30
    arc_0_18_4  connected_order_arc_843  -17
    arc_0_18_4  in_degree_890  1
    arc_0_18_4  out_degree_966  1
    arc_0_18_4  original_T_including_depot_unload_979  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_842  1
    load_0_18_4  segment_load_conservation_893  -1
    load_0_18_4  segment_prefix_lb_894  1
    load_0_18_4  segment_prefix_ub_895  1
    load_0_18_4  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_844  -30
    arc_0_18_5  connected_order_arc_845  -17
    arc_0_18_5  in_degree_897  1
    arc_0_18_5  out_degree_966  1
    arc_0_18_5  original_T_including_depot_unload_979  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_844  1
    load_0_18_5  segment_load_conservation_900  -1
    load_0_18_5  segment_prefix_lb_901  1
    load_0_18_5  segment_prefix_ub_902  1
    load_0_18_5  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_846  -30
    arc_0_18_6  connected_order_arc_847  -17
    arc_0_18_6  in_degree_904  1
    arc_0_18_6  out_degree_966  1
    arc_0_18_6  original_T_including_depot_unload_979  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_846  1
    load_0_18_6  segment_load_conservation_907  -1
    load_0_18_6  segment_prefix_lb_908  1
    load_0_18_6  segment_prefix_ub_909  1
    load_0_18_6  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_7  arc_capacity_848  -30
    arc_0_18_7  connected_order_arc_849  -17
    arc_0_18_7  in_degree_911  1
    arc_0_18_7  out_degree_966  1
    arc_0_18_7  original_T_including_depot_unload_979  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_7  arc_capacity_848  1
    load_0_18_7  segment_load_conservation_914  -1
    load_0_18_7  segment_prefix_lb_915  1
    load_0_18_7  segment_prefix_ub_916  1
    load_0_18_7  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_8  arc_capacity_850  -30
    arc_0_18_8  connected_order_arc_851  -17
    arc_0_18_8  in_degree_918  1
    arc_0_18_8  out_degree_966  1
    arc_0_18_8  original_T_including_depot_unload_979  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_8  arc_capacity_850  1
    load_0_18_8  segment_load_conservation_921  -1
    load_0_18_8  segment_prefix_lb_922  1
    load_0_18_8  segment_prefix_ub_923  1
    load_0_18_8  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_11  arc_capacity_852  -30
    arc_0_18_11  connected_order_arc_853  -17
    arc_0_18_11  in_degree_925  1
    arc_0_18_11  out_degree_966  1
    arc_0_18_11  original_T_including_depot_unload_979  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_0_18_11  arc_capacity_852  1
    load_0_18_11  free_load_conservation_929  -1
    load_0_18_11  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_854  -30
    arc_0_18_12  connected_order_arc_855  -17
    arc_0_18_12  in_degree_931  1
    arc_0_18_12  out_degree_966  1
    arc_0_18_12  original_T_including_depot_unload_979  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_854  1
    load_0_18_12  free_load_conservation_935  -1
    load_0_18_12  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_856  -30
    arc_0_18_13  connected_order_arc_857  -17
    arc_0_18_13  in_degree_937  1
    arc_0_18_13  out_degree_966  1
    arc_0_18_13  original_T_including_depot_unload_979  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_856  1
    load_0_18_13  free_load_conservation_941  -1
    load_0_18_13  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_858  -30
    arc_0_18_14  connected_order_arc_859  -17
    arc_0_18_14  in_degree_943  1
    arc_0_18_14  out_degree_966  1
    arc_0_18_14  original_T_including_depot_unload_979  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_858  1
    load_0_18_14  free_load_conservation_947  -1
    load_0_18_14  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_860  -30
    arc_0_18_15  connected_order_arc_861  -17
    arc_0_18_15  in_degree_949  1
    arc_0_18_15  out_degree_966  1
    arc_0_18_15  original_T_including_depot_unload_979  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_860  1
    load_0_18_15  free_load_conservation_953  -1
    load_0_18_15  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_862  -30
    arc_0_18_16  connected_order_arc_863  -17
    arc_0_18_16  in_degree_955  1
    arc_0_18_16  out_degree_966  1
    arc_0_18_16  original_T_including_depot_unload_979  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_862  1
    load_0_18_16  free_load_conservation_959  -1
    load_0_18_16  free_load_conservation_971  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_864  -30
    arc_0_18_17  connected_order_arc_865  -17
    arc_0_18_17  in_degree_961  1
    arc_0_18_17  out_degree_966  1
    arc_0_18_17  original_T_including_depot_unload_979  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_864  1
    load_0_18_17  free_load_conservation_965  -1
    load_0_18_17  free_load_conservation_971  1
    visit_1_9  out_degree_1183  -1
    visit_1_9  in_degree_1184  -1
    visit_1_9  order_active_lb_1185  -1
    visit_1_9  order_active_ub_1186  -10
    order_1_9  connected_order_arc_993  -1
    order_1_9  connected_order_arc_995  -1
    order_1_9  connected_order_arc_997  -1
    order_1_9  connected_order_arc_999  -1
    order_1_9  connected_order_arc_1001  -1
    order_1_9  connected_order_arc_1003  -1
    order_1_9  connected_order_arc_1005  -1
    order_1_9  connected_order_arc_1007  -1
    order_1_9  connected_order_arc_1009  -1
    order_1_9  connected_order_arc_1012  1
    order_1_9  connected_order_arc_1031  1
    order_1_9  connected_order_arc_1050  1
    order_1_9  connected_order_arc_1069  1
    order_1_9  connected_order_arc_1088  1
    order_1_9  connected_order_arc_1107  1
    order_1_9  connected_order_arc_1126  1
    order_1_9  connected_order_arc_1145  1
    order_1_9  connected_order_arc_1164  1
    order_1_9  order_active_lb_1185  1
    order_1_9  order_active_ub_1186  1
    order_1_9  fixed_segment_relative_order_1245  -1
    visit_1_10  out_degree_1190  -1
    visit_1_10  in_degree_1191  -1
    visit_1_10  order_active_lb_1192  -1
    visit_1_10  order_active_ub_1193  -10
    order_1_10  connected_order_arc_993  1
    order_1_10  connected_order_arc_1012  -1
    order_1_10  connected_order_arc_1014  -1
    order_1_10  connected_order_arc_1016  -1
    order_1_10  connected_order_arc_1018  -1
    order_1_10  connected_order_arc_1020  -1
    order_1_10  connected_order_arc_1022  -1
    order_1_10  connected_order_arc_1024  -1
    order_1_10  connected_order_arc_1026  -1
    order_1_10  connected_order_arc_1028  -1
    order_1_10  connected_order_arc_1033  1
    order_1_10  connected_order_arc_1052  1
    order_1_10  connected_order_arc_1071  1
    order_1_10  connected_order_arc_1090  1
    order_1_10  connected_order_arc_1109  1
    order_1_10  connected_order_arc_1128  1
    order_1_10  connected_order_arc_1147  1
    order_1_10  connected_order_arc_1166  1
    order_1_10  order_active_lb_1192  1
    order_1_10  order_active_ub_1193  1
    order_1_10  fixed_segment_relative_order_1245  1
    visit_1_11  out_degree_1197  -1
    visit_1_11  in_degree_1198  -1
    visit_1_11  order_active_lb_1199  -1
    visit_1_11  order_active_ub_1200  -10
    visit_1_11  service_visit_def_1201  -1
    order_1_11  connected_order_arc_995  1
    order_1_11  connected_order_arc_1014  1
    order_1_11  connected_order_arc_1031  -1
    order_1_11  connected_order_arc_1033  -1
    order_1_11  connected_order_arc_1035  -1
    order_1_11  connected_order_arc_1037  -1
    order_1_11  connected_order_arc_1039  -1
    order_1_11  connected_order_arc_1041  -1
    order_1_11  connected_order_arc_1043  -1
    order_1_11  connected_order_arc_1045  -1
    order_1_11  connected_order_arc_1047  -1
    order_1_11  connected_order_arc_1054  1
    order_1_11  connected_order_arc_1073  1
    order_1_11  connected_order_arc_1092  1
    order_1_11  connected_order_arc_1111  1
    order_1_11  connected_order_arc_1130  1
    order_1_11  connected_order_arc_1149  1
    order_1_11  connected_order_arc_1168  1
    order_1_11  order_active_lb_1199  1
    order_1_11  order_active_ub_1200  1
    visit_1_12  out_degree_1203  -1
    visit_1_12  in_degree_1204  -1
    visit_1_12  order_active_lb_1205  -1
    visit_1_12  order_active_ub_1206  -10
    visit_1_12  service_visit_def_1207  -1
    order_1_12  connected_order_arc_997  1
    order_1_12  connected_order_arc_1016  1
    order_1_12  connected_order_arc_1035  1
    order_1_12  connected_order_arc_1050  -1
    order_1_12  connected_order_arc_1052  -1
    order_1_12  connected_order_arc_1054  -1
    order_1_12  connected_order_arc_1056  -1
    order_1_12  connected_order_arc_1058  -1
    order_1_12  connected_order_arc_1060  -1
    order_1_12  connected_order_arc_1062  -1
    order_1_12  connected_order_arc_1064  -1
    order_1_12  connected_order_arc_1066  -1
    order_1_12  connected_order_arc_1075  1
    order_1_12  connected_order_arc_1094  1
    order_1_12  connected_order_arc_1113  1
    order_1_12  connected_order_arc_1132  1
    order_1_12  connected_order_arc_1151  1
    order_1_12  connected_order_arc_1170  1
    order_1_12  order_active_lb_1205  1
    order_1_12  order_active_ub_1206  1
    visit_1_13  out_degree_1209  -1
    visit_1_13  in_degree_1210  -1
    visit_1_13  order_active_lb_1211  -1
    visit_1_13  order_active_ub_1212  -10
    visit_1_13  service_visit_def_1213  -1
    order_1_13  connected_order_arc_999  1
    order_1_13  connected_order_arc_1018  1
    order_1_13  connected_order_arc_1037  1
    order_1_13  connected_order_arc_1056  1
    order_1_13  connected_order_arc_1069  -1
    order_1_13  connected_order_arc_1071  -1
    order_1_13  connected_order_arc_1073  -1
    order_1_13  connected_order_arc_1075  -1
    order_1_13  connected_order_arc_1077  -1
    order_1_13  connected_order_arc_1079  -1
    order_1_13  connected_order_arc_1081  -1
    order_1_13  connected_order_arc_1083  -1
    order_1_13  connected_order_arc_1085  -1
    order_1_13  connected_order_arc_1096  1
    order_1_13  connected_order_arc_1115  1
    order_1_13  connected_order_arc_1134  1
    order_1_13  connected_order_arc_1153  1
    order_1_13  connected_order_arc_1172  1
    order_1_13  order_active_lb_1211  1
    order_1_13  order_active_ub_1212  1
    visit_1_14  out_degree_1215  -1
    visit_1_14  in_degree_1216  -1
    visit_1_14  order_active_lb_1217  -1
    visit_1_14  order_active_ub_1218  -10
    visit_1_14  service_visit_def_1219  -1
    order_1_14  connected_order_arc_1001  1
    order_1_14  connected_order_arc_1020  1
    order_1_14  connected_order_arc_1039  1
    order_1_14  connected_order_arc_1058  1
    order_1_14  connected_order_arc_1077  1
    order_1_14  connected_order_arc_1088  -1
    order_1_14  connected_order_arc_1090  -1
    order_1_14  connected_order_arc_1092  -1
    order_1_14  connected_order_arc_1094  -1
    order_1_14  connected_order_arc_1096  -1
    order_1_14  connected_order_arc_1098  -1
    order_1_14  connected_order_arc_1100  -1
    order_1_14  connected_order_arc_1102  -1
    order_1_14  connected_order_arc_1104  -1
    order_1_14  connected_order_arc_1117  1
    order_1_14  connected_order_arc_1136  1
    order_1_14  connected_order_arc_1155  1
    order_1_14  connected_order_arc_1174  1
    order_1_14  order_active_lb_1217  1
    order_1_14  order_active_ub_1218  1
    visit_1_15  out_degree_1221  -1
    visit_1_15  in_degree_1222  -1
    visit_1_15  order_active_lb_1223  -1
    visit_1_15  order_active_ub_1224  -10
    visit_1_15  service_visit_def_1225  -1
    order_1_15  connected_order_arc_1003  1
    order_1_15  connected_order_arc_1022  1
    order_1_15  connected_order_arc_1041  1
    order_1_15  connected_order_arc_1060  1
    order_1_15  connected_order_arc_1079  1
    order_1_15  connected_order_arc_1098  1
    order_1_15  connected_order_arc_1107  -1
    order_1_15  connected_order_arc_1109  -1
    order_1_15  connected_order_arc_1111  -1
    order_1_15  connected_order_arc_1113  -1
    order_1_15  connected_order_arc_1115  -1
    order_1_15  connected_order_arc_1117  -1
    order_1_15  connected_order_arc_1119  -1
    order_1_15  connected_order_arc_1121  -1
    order_1_15  connected_order_arc_1123  -1
    order_1_15  connected_order_arc_1138  1
    order_1_15  connected_order_arc_1157  1
    order_1_15  connected_order_arc_1176  1
    order_1_15  order_active_lb_1223  1
    order_1_15  order_active_ub_1224  1
    visit_1_16  out_degree_1227  -1
    visit_1_16  in_degree_1228  -1
    visit_1_16  order_active_lb_1229  -1
    visit_1_16  order_active_ub_1230  -10
    visit_1_16  service_visit_def_1231  -1
    order_1_16  connected_order_arc_1005  1
    order_1_16  connected_order_arc_1024  1
    order_1_16  connected_order_arc_1043  1
    order_1_16  connected_order_arc_1062  1
    order_1_16  connected_order_arc_1081  1
    order_1_16  connected_order_arc_1100  1
    order_1_16  connected_order_arc_1119  1
    order_1_16  connected_order_arc_1126  -1
    order_1_16  connected_order_arc_1128  -1
    order_1_16  connected_order_arc_1130  -1
    order_1_16  connected_order_arc_1132  -1
    order_1_16  connected_order_arc_1134  -1
    order_1_16  connected_order_arc_1136  -1
    order_1_16  connected_order_arc_1138  -1
    order_1_16  connected_order_arc_1140  -1
    order_1_16  connected_order_arc_1142  -1
    order_1_16  connected_order_arc_1159  1
    order_1_16  connected_order_arc_1178  1
    order_1_16  order_active_lb_1229  1
    order_1_16  order_active_ub_1230  1
    visit_1_17  out_degree_1233  -1
    visit_1_17  in_degree_1234  -1
    visit_1_17  order_active_lb_1235  -1
    visit_1_17  order_active_ub_1236  -10
    visit_1_17  service_visit_def_1237  -1
    order_1_17  connected_order_arc_1007  1
    order_1_17  connected_order_arc_1026  1
    order_1_17  connected_order_arc_1045  1
    order_1_17  connected_order_arc_1064  1
    order_1_17  connected_order_arc_1083  1
    order_1_17  connected_order_arc_1102  1
    order_1_17  connected_order_arc_1121  1
    order_1_17  connected_order_arc_1140  1
    order_1_17  connected_order_arc_1145  -1
    order_1_17  connected_order_arc_1147  -1
    order_1_17  connected_order_arc_1149  -1
    order_1_17  connected_order_arc_1151  -1
    order_1_17  connected_order_arc_1153  -1
    order_1_17  connected_order_arc_1155  -1
    order_1_17  connected_order_arc_1157  -1
    order_1_17  connected_order_arc_1159  -1
    order_1_17  connected_order_arc_1161  -1
    order_1_17  connected_order_arc_1180  1
    order_1_17  order_active_lb_1235  1
    order_1_17  order_active_ub_1236  1
    visit_1_18  out_degree_1239  -1
    visit_1_18  in_degree_1240  -1
    visit_1_18  order_active_lb_1241  -1
    visit_1_18  order_active_ub_1242  -10
    visit_1_18  service_visit_def_1243  -1
    order_1_18  connected_order_arc_1009  1
    order_1_18  connected_order_arc_1028  1
    order_1_18  connected_order_arc_1047  1
    order_1_18  connected_order_arc_1066  1
    order_1_18  connected_order_arc_1085  1
    order_1_18  connected_order_arc_1104  1
    order_1_18  connected_order_arc_1123  1
    order_1_18  connected_order_arc_1142  1
    order_1_18  connected_order_arc_1161  1
    order_1_18  connected_order_arc_1164  -1
    order_1_18  connected_order_arc_1166  -1
    order_1_18  connected_order_arc_1168  -1
    order_1_18  connected_order_arc_1170  -1
    order_1_18  connected_order_arc_1172  -1
    order_1_18  connected_order_arc_1174  -1
    order_1_18  connected_order_arc_1176  -1
    order_1_18  connected_order_arc_1178  -1
    order_1_18  connected_order_arc_1180  -1
    order_1_18  order_active_lb_1241  1
    order_1_18  order_active_ub_1242  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_980  -30
    arc_1_0_0  depot_departure_or_bypass_1181  1
    arc_1_0_0  depot_return_or_bypass_1182  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_981  -30
    arc_1_0_9  depot_departure_or_bypass_1181  1
    arc_1_0_9  in_degree_1184  1
    arc_1_0_9  original_T_including_depot_unload_1246  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_981  1
    load_1_0_9  segment_load_conservation_1187  -1
    load_1_0_9  segment_prefix_lb_1188  1
    load_1_0_9  segment_prefix_ub_1189  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_982  -30
    arc_1_0_10  depot_departure_or_bypass_1181  1
    arc_1_0_10  in_degree_1191  1
    arc_1_0_10  original_T_including_depot_unload_1246  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_982  1
    load_1_0_10  segment_load_conservation_1194  -1
    load_1_0_10  segment_prefix_lb_1195  1
    load_1_0_10  segment_prefix_ub_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_983  -30
    arc_1_0_11  depot_departure_or_bypass_1181  1
    arc_1_0_11  in_degree_1198  1
    arc_1_0_11  original_T_including_depot_unload_1246  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_983  1
    load_1_0_11  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_984  -30
    arc_1_0_12  depot_departure_or_bypass_1181  1
    arc_1_0_12  in_degree_1204  1
    arc_1_0_12  original_T_including_depot_unload_1246  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_984  1
    load_1_0_12  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_985  -30
    arc_1_0_13  depot_departure_or_bypass_1181  1
    arc_1_0_13  in_degree_1210  1
    arc_1_0_13  original_T_including_depot_unload_1246  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_985  1
    load_1_0_13  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_986  -30
    arc_1_0_14  depot_departure_or_bypass_1181  1
    arc_1_0_14  in_degree_1216  1
    arc_1_0_14  original_T_including_depot_unload_1246  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_986  1
    load_1_0_14  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_987  -30
    arc_1_0_15  depot_departure_or_bypass_1181  1
    arc_1_0_15  in_degree_1222  1
    arc_1_0_15  original_T_including_depot_unload_1246  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_987  1
    load_1_0_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_988  -30
    arc_1_0_16  depot_departure_or_bypass_1181  1
    arc_1_0_16  in_degree_1228  1
    arc_1_0_16  original_T_including_depot_unload_1246  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_988  1
    load_1_0_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_989  -30
    arc_1_0_17  depot_departure_or_bypass_1181  1
    arc_1_0_17  in_degree_1234  1
    arc_1_0_17  original_T_including_depot_unload_1246  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_989  1
    load_1_0_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_990  -30
    arc_1_0_18  depot_departure_or_bypass_1181  1
    arc_1_0_18  in_degree_1240  1
    arc_1_0_18  original_T_including_depot_unload_1246  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_990  1
    load_1_0_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_991  -30
    arc_1_9_0  depot_return_or_bypass_1182  1
    arc_1_9_0  out_degree_1183  1
    arc_1_9_0  original_T_including_depot_unload_1246  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_991  1
    load_1_9_0  segment_load_conservation_1187  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_992  -30
    arc_1_9_10  connected_order_arc_993  -11
    arc_1_9_10  out_degree_1183  1
    arc_1_9_10  in_degree_1191  1
    arc_1_9_10  original_T_including_depot_unload_1246  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_992  1
    load_1_9_10  segment_load_conservation_1187  1
    load_1_9_10  segment_load_conservation_1194  -1
    load_1_9_10  segment_prefix_lb_1195  1
    load_1_9_10  segment_prefix_ub_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_994  -30
    arc_1_9_11  connected_order_arc_995  -11
    arc_1_9_11  out_degree_1183  1
    arc_1_9_11  in_degree_1198  1
    arc_1_9_11  original_T_including_depot_unload_1246  3.8248940301741582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_994  1
    load_1_9_11  segment_load_conservation_1187  1
    load_1_9_11  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_996  -30
    arc_1_9_12  connected_order_arc_997  -11
    arc_1_9_12  out_degree_1183  1
    arc_1_9_12  in_degree_1204  1
    arc_1_9_12  original_T_including_depot_unload_1246  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_996  1
    load_1_9_12  segment_load_conservation_1187  1
    load_1_9_12  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_998  -30
    arc_1_9_13  connected_order_arc_999  -11
    arc_1_9_13  out_degree_1183  1
    arc_1_9_13  in_degree_1210  1
    arc_1_9_13  original_T_including_depot_unload_1246  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_998  1
    load_1_9_13  segment_load_conservation_1187  1
    load_1_9_13  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_1000  -30
    arc_1_9_14  connected_order_arc_1001  -11
    arc_1_9_14  out_degree_1183  1
    arc_1_9_14  in_degree_1216  1
    arc_1_9_14  original_T_including_depot_unload_1246  4.0654406432457854e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_1000  1
    load_1_9_14  segment_load_conservation_1187  1
    load_1_9_14  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_1002  -30
    arc_1_9_15  connected_order_arc_1003  -11
    arc_1_9_15  out_degree_1183  1
    arc_1_9_15  in_degree_1222  1
    arc_1_9_15  original_T_including_depot_unload_1246  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_1002  1
    load_1_9_15  segment_load_conservation_1187  1
    load_1_9_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_1004  -30
    arc_1_9_16  connected_order_arc_1005  -11
    arc_1_9_16  out_degree_1183  1
    arc_1_9_16  in_degree_1228  1
    arc_1_9_16  original_T_including_depot_unload_1246  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_1004  1
    load_1_9_16  segment_load_conservation_1187  1
    load_1_9_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_1006  -30
    arc_1_9_17  connected_order_arc_1007  -11
    arc_1_9_17  out_degree_1183  1
    arc_1_9_17  in_degree_1234  1
    arc_1_9_17  original_T_including_depot_unload_1246  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_1006  1
    load_1_9_17  segment_load_conservation_1187  1
    load_1_9_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_1008  -30
    arc_1_9_18  connected_order_arc_1009  -11
    arc_1_9_18  out_degree_1183  1
    arc_1_9_18  in_degree_1240  1
    arc_1_9_18  original_T_including_depot_unload_1246  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_1008  1
    load_1_9_18  segment_load_conservation_1187  1
    load_1_9_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1010  -30
    arc_1_10_0  depot_return_or_bypass_1182  1
    arc_1_10_0  out_degree_1190  1
    arc_1_10_0  original_T_including_depot_unload_1246  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1010  1
    load_1_10_0  segment_load_conservation_1194  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1011  -30
    arc_1_10_9  connected_order_arc_1012  -11
    arc_1_10_9  in_degree_1184  1
    arc_1_10_9  out_degree_1190  1
    arc_1_10_9  original_T_including_depot_unload_1246  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1011  1
    load_1_10_9  segment_load_conservation_1187  -1
    load_1_10_9  segment_prefix_lb_1188  1
    load_1_10_9  segment_prefix_ub_1189  1
    load_1_10_9  segment_load_conservation_1194  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_1013  -30
    arc_1_10_11  connected_order_arc_1014  -11
    arc_1_10_11  out_degree_1190  1
    arc_1_10_11  in_degree_1198  1
    arc_1_10_11  original_T_including_depot_unload_1246  3.7172787566213742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_1013  1
    load_1_10_11  segment_load_conservation_1194  1
    load_1_10_11  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_1015  -30
    arc_1_10_12  connected_order_arc_1016  -11
    arc_1_10_12  out_degree_1190  1
    arc_1_10_12  in_degree_1204  1
    arc_1_10_12  original_T_including_depot_unload_1246  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_1015  1
    load_1_10_12  segment_load_conservation_1194  1
    load_1_10_12  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_1017  -30
    arc_1_10_13  connected_order_arc_1018  -11
    arc_1_10_13  out_degree_1190  1
    arc_1_10_13  in_degree_1210  1
    arc_1_10_13  original_T_including_depot_unload_1246  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_1017  1
    load_1_10_13  segment_load_conservation_1194  1
    load_1_10_13  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_1019  -30
    arc_1_10_14  connected_order_arc_1020  -11
    arc_1_10_14  out_degree_1190  1
    arc_1_10_14  in_degree_1216  1
    arc_1_10_14  original_T_including_depot_unload_1246  3.9583831508648805e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_1019  1
    load_1_10_14  segment_load_conservation_1194  1
    load_1_10_14  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1021  -30
    arc_1_10_15  connected_order_arc_1022  -11
    arc_1_10_15  out_degree_1190  1
    arc_1_10_15  in_degree_1222  1
    arc_1_10_15  original_T_including_depot_unload_1246  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1021  1
    load_1_10_15  segment_load_conservation_1194  1
    load_1_10_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1023  -30
    arc_1_10_16  connected_order_arc_1024  -11
    arc_1_10_16  out_degree_1190  1
    arc_1_10_16  in_degree_1228  1
    arc_1_10_16  original_T_including_depot_unload_1246  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1023  1
    load_1_10_16  segment_load_conservation_1194  1
    load_1_10_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1025  -30
    arc_1_10_17  connected_order_arc_1026  -11
    arc_1_10_17  out_degree_1190  1
    arc_1_10_17  in_degree_1234  1
    arc_1_10_17  original_T_including_depot_unload_1246  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1025  1
    load_1_10_17  segment_load_conservation_1194  1
    load_1_10_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1027  -30
    arc_1_10_18  connected_order_arc_1028  -11
    arc_1_10_18  out_degree_1190  1
    arc_1_10_18  in_degree_1240  1
    arc_1_10_18  original_T_including_depot_unload_1246  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1027  1
    load_1_10_18  segment_load_conservation_1194  1
    load_1_10_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_1029  -30
    arc_1_11_0  depot_return_or_bypass_1182  1
    arc_1_11_0  out_degree_1197  1
    arc_1_11_0  original_T_including_depot_unload_1246  2.2779423489344404e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_1029  1
    load_1_11_0  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_1030  -30
    arc_1_11_9  connected_order_arc_1031  -11
    arc_1_11_9  in_degree_1184  1
    arc_1_11_9  out_degree_1197  1
    arc_1_11_9  original_T_including_depot_unload_1246  3.8248940301741582e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_1030  1
    load_1_11_9  segment_load_conservation_1187  -1
    load_1_11_9  segment_prefix_lb_1188  1
    load_1_11_9  segment_prefix_ub_1189  1
    load_1_11_9  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_1032  -30
    arc_1_11_10  connected_order_arc_1033  -11
    arc_1_11_10  in_degree_1191  1
    arc_1_11_10  out_degree_1197  1
    arc_1_11_10  original_T_including_depot_unload_1246  3.7172787566213742e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_1032  1
    load_1_11_10  segment_load_conservation_1194  -1
    load_1_11_10  segment_prefix_lb_1195  1
    load_1_11_10  segment_prefix_ub_1196  1
    load_1_11_10  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_1034  -30
    arc_1_11_12  connected_order_arc_1035  -11
    arc_1_11_12  out_degree_1197  1
    arc_1_11_12  in_degree_1204  1
    arc_1_11_12  original_T_including_depot_unload_1246  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_1034  1
    load_1_11_12  free_load_conservation_1202  1
    load_1_11_12  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_1036  -30
    arc_1_11_13  connected_order_arc_1037  -11
    arc_1_11_13  out_degree_1197  1
    arc_1_11_13  in_degree_1210  1
    arc_1_11_13  original_T_including_depot_unload_1246  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_1036  1
    load_1_11_13  free_load_conservation_1202  1
    load_1_11_13  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_1038  -30
    arc_1_11_14  connected_order_arc_1039  -11
    arc_1_11_14  out_degree_1197  1
    arc_1_11_14  in_degree_1216  1
    arc_1_11_14  original_T_including_depot_unload_1246  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_1038  1
    load_1_11_14  free_load_conservation_1202  1
    load_1_11_14  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_1040  -30
    arc_1_11_15  connected_order_arc_1041  -11
    arc_1_11_15  out_degree_1197  1
    arc_1_11_15  in_degree_1222  1
    arc_1_11_15  original_T_including_depot_unload_1246  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_1040  1
    load_1_11_15  free_load_conservation_1202  1
    load_1_11_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_1042  -30
    arc_1_11_16  connected_order_arc_1043  -11
    arc_1_11_16  out_degree_1197  1
    arc_1_11_16  in_degree_1228  1
    arc_1_11_16  original_T_including_depot_unload_1246  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_1042  1
    load_1_11_16  free_load_conservation_1202  1
    load_1_11_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_17  arc_capacity_1044  -30
    arc_1_11_17  connected_order_arc_1045  -11
    arc_1_11_17  out_degree_1197  1
    arc_1_11_17  in_degree_1234  1
    arc_1_11_17  original_T_including_depot_unload_1246  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_17  arc_capacity_1044  1
    load_1_11_17  free_load_conservation_1202  1
    load_1_11_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_18  arc_capacity_1046  -30
    arc_1_11_18  connected_order_arc_1047  -11
    arc_1_11_18  out_degree_1197  1
    arc_1_11_18  in_degree_1240  1
    arc_1_11_18  original_T_including_depot_unload_1246  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_1_11_18  arc_capacity_1046  1
    load_1_11_18  free_load_conservation_1202  1
    load_1_11_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_1048  -30
    arc_1_12_0  depot_return_or_bypass_1182  1
    arc_1_12_0  out_degree_1203  1
    arc_1_12_0  original_T_including_depot_unload_1246  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_1048  1
    load_1_12_0  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_1049  -30
    arc_1_12_9  connected_order_arc_1050  -11
    arc_1_12_9  in_degree_1184  1
    arc_1_12_9  out_degree_1203  1
    arc_1_12_9  original_T_including_depot_unload_1246  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_1049  1
    load_1_12_9  segment_load_conservation_1187  -1
    load_1_12_9  segment_prefix_lb_1188  1
    load_1_12_9  segment_prefix_ub_1189  1
    load_1_12_9  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_1051  -30
    arc_1_12_10  connected_order_arc_1052  -11
    arc_1_12_10  in_degree_1191  1
    arc_1_12_10  out_degree_1203  1
    arc_1_12_10  original_T_including_depot_unload_1246  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_1051  1
    load_1_12_10  segment_load_conservation_1194  -1
    load_1_12_10  segment_prefix_lb_1195  1
    load_1_12_10  segment_prefix_ub_1196  1
    load_1_12_10  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_1053  -30
    arc_1_12_11  connected_order_arc_1054  -11
    arc_1_12_11  in_degree_1198  1
    arc_1_12_11  out_degree_1203  1
    arc_1_12_11  original_T_including_depot_unload_1246  1.3126604801096047e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_1053  1
    load_1_12_11  free_load_conservation_1202  -1
    load_1_12_11  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_1055  -30
    arc_1_12_13  connected_order_arc_1056  -11
    arc_1_12_13  out_degree_1203  1
    arc_1_12_13  in_degree_1210  1
    arc_1_12_13  original_T_including_depot_unload_1246  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_1055  1
    load_1_12_13  free_load_conservation_1208  1
    load_1_12_13  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_1057  -30
    arc_1_12_14  connected_order_arc_1058  -11
    arc_1_12_14  out_degree_1203  1
    arc_1_12_14  in_degree_1216  1
    arc_1_12_14  original_T_including_depot_unload_1246  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_1057  1
    load_1_12_14  free_load_conservation_1208  1
    load_1_12_14  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_1059  -30
    arc_1_12_15  connected_order_arc_1060  -11
    arc_1_12_15  out_degree_1203  1
    arc_1_12_15  in_degree_1222  1
    arc_1_12_15  original_T_including_depot_unload_1246  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_1059  1
    load_1_12_15  free_load_conservation_1208  1
    load_1_12_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_1061  -30
    arc_1_12_16  connected_order_arc_1062  -11
    arc_1_12_16  out_degree_1203  1
    arc_1_12_16  in_degree_1228  1
    arc_1_12_16  original_T_including_depot_unload_1246  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_1061  1
    load_1_12_16  free_load_conservation_1208  1
    load_1_12_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_1063  -30
    arc_1_12_17  connected_order_arc_1064  -11
    arc_1_12_17  out_degree_1203  1
    arc_1_12_17  in_degree_1234  1
    arc_1_12_17  original_T_including_depot_unload_1246  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_1063  1
    load_1_12_17  free_load_conservation_1208  1
    load_1_12_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_1065  -30
    arc_1_12_18  connected_order_arc_1066  -11
    arc_1_12_18  out_degree_1203  1
    arc_1_12_18  in_degree_1240  1
    arc_1_12_18  original_T_including_depot_unload_1246  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_1065  1
    load_1_12_18  free_load_conservation_1208  1
    load_1_12_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_1067  -30
    arc_1_13_0  depot_return_or_bypass_1182  1
    arc_1_13_0  out_degree_1209  1
    arc_1_13_0  original_T_including_depot_unload_1246  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_1067  1
    load_1_13_0  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_1068  -30
    arc_1_13_9  connected_order_arc_1069  -11
    arc_1_13_9  in_degree_1184  1
    arc_1_13_9  out_degree_1209  1
    arc_1_13_9  original_T_including_depot_unload_1246  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_1068  1
    load_1_13_9  segment_load_conservation_1187  -1
    load_1_13_9  segment_prefix_lb_1188  1
    load_1_13_9  segment_prefix_ub_1189  1
    load_1_13_9  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_1070  -30
    arc_1_13_10  connected_order_arc_1071  -11
    arc_1_13_10  in_degree_1191  1
    arc_1_13_10  out_degree_1209  1
    arc_1_13_10  original_T_including_depot_unload_1246  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_1070  1
    load_1_13_10  segment_load_conservation_1194  -1
    load_1_13_10  segment_prefix_lb_1195  1
    load_1_13_10  segment_prefix_ub_1196  1
    load_1_13_10  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_1072  -30
    arc_1_13_11  connected_order_arc_1073  -11
    arc_1_13_11  in_degree_1198  1
    arc_1_13_11  out_degree_1209  1
    arc_1_13_11  original_T_including_depot_unload_1246  4.1781804970479707e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_1072  1
    load_1_13_11  free_load_conservation_1202  -1
    load_1_13_11  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_1074  -30
    arc_1_13_12  connected_order_arc_1075  -11
    arc_1_13_12  in_degree_1204  1
    arc_1_13_12  out_degree_1209  1
    arc_1_13_12  original_T_including_depot_unload_1246  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_1074  1
    load_1_13_12  free_load_conservation_1208  -1
    load_1_13_12  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1076  -30
    arc_1_13_14  connected_order_arc_1077  -11
    arc_1_13_14  out_degree_1209  1
    arc_1_13_14  in_degree_1216  1
    arc_1_13_14  original_T_including_depot_unload_1246  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1076  1
    load_1_13_14  free_load_conservation_1214  1
    load_1_13_14  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1078  -30
    arc_1_13_15  connected_order_arc_1079  -11
    arc_1_13_15  out_degree_1209  1
    arc_1_13_15  in_degree_1222  1
    arc_1_13_15  original_T_including_depot_unload_1246  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1078  1
    load_1_13_15  free_load_conservation_1214  1
    load_1_13_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1080  -30
    arc_1_13_16  connected_order_arc_1081  -11
    arc_1_13_16  out_degree_1209  1
    arc_1_13_16  in_degree_1228  1
    arc_1_13_16  original_T_including_depot_unload_1246  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1080  1
    load_1_13_16  free_load_conservation_1214  1
    load_1_13_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_1082  -30
    arc_1_13_17  connected_order_arc_1083  -11
    arc_1_13_17  out_degree_1209  1
    arc_1_13_17  in_degree_1234  1
    arc_1_13_17  original_T_including_depot_unload_1246  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_1082  1
    load_1_13_17  free_load_conservation_1214  1
    load_1_13_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_1084  -30
    arc_1_13_18  connected_order_arc_1085  -11
    arc_1_13_18  out_degree_1209  1
    arc_1_13_18  in_degree_1240  1
    arc_1_13_18  original_T_including_depot_unload_1246  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_1084  1
    load_1_13_18  free_load_conservation_1214  1
    load_1_13_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1086  -30
    arc_1_14_0  depot_return_or_bypass_1182  1
    arc_1_14_0  out_degree_1215  1
    arc_1_14_0  original_T_including_depot_unload_1246  2.4985877836350596e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1086  1
    load_1_14_0  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1087  -30
    arc_1_14_9  connected_order_arc_1088  -11
    arc_1_14_9  in_degree_1184  1
    arc_1_14_9  out_degree_1215  1
    arc_1_14_9  original_T_including_depot_unload_1246  4.0654406432457854e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1087  1
    load_1_14_9  segment_load_conservation_1187  -1
    load_1_14_9  segment_prefix_lb_1188  1
    load_1_14_9  segment_prefix_ub_1189  1
    load_1_14_9  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1089  -30
    arc_1_14_10  connected_order_arc_1090  -11
    arc_1_14_10  in_degree_1191  1
    arc_1_14_10  out_degree_1215  1
    arc_1_14_10  original_T_including_depot_unload_1246  3.9583831508648805e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1089  1
    load_1_14_10  segment_load_conservation_1194  -1
    load_1_14_10  segment_prefix_lb_1195  1
    load_1_14_10  segment_prefix_ub_1196  1
    load_1_14_10  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1091  -30
    arc_1_14_11  connected_order_arc_1092  -11
    arc_1_14_11  in_degree_1198  1
    arc_1_14_11  out_degree_1215  1
    arc_1_14_11  original_T_including_depot_unload_1246  2.4254234166891203e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1091  1
    load_1_14_11  free_load_conservation_1202  -1
    load_1_14_11  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1093  -30
    arc_1_14_12  connected_order_arc_1094  -11
    arc_1_14_12  in_degree_1204  1
    arc_1_14_12  out_degree_1215  1
    arc_1_14_12  original_T_including_depot_unload_1246  2.8958539392642757e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1093  1
    load_1_14_12  free_load_conservation_1208  -1
    load_1_14_12  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1095  -30
    arc_1_14_13  connected_order_arc_1096  -11
    arc_1_14_13  in_degree_1210  1
    arc_1_14_13  out_degree_1215  1
    arc_1_14_13  original_T_including_depot_unload_1246  4.4205864351455948e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1095  1
    load_1_14_13  free_load_conservation_1214  -1
    load_1_14_13  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1097  -30
    arc_1_14_15  connected_order_arc_1098  -11
    arc_1_14_15  out_degree_1215  1
    arc_1_14_15  in_degree_1222  1
    arc_1_14_15  original_T_including_depot_unload_1246  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1097  1
    load_1_14_15  free_load_conservation_1220  1
    load_1_14_15  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1099  -30
    arc_1_14_16  connected_order_arc_1100  -11
    arc_1_14_16  out_degree_1215  1
    arc_1_14_16  in_degree_1228  1
    arc_1_14_16  original_T_including_depot_unload_1246  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1099  1
    load_1_14_16  free_load_conservation_1220  1
    load_1_14_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1101  -30
    arc_1_14_17  connected_order_arc_1102  -11
    arc_1_14_17  out_degree_1215  1
    arc_1_14_17  in_degree_1234  1
    arc_1_14_17  original_T_including_depot_unload_1246  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1101  1
    load_1_14_17  free_load_conservation_1220  1
    load_1_14_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1103  -30
    arc_1_14_18  connected_order_arc_1104  -11
    arc_1_14_18  out_degree_1215  1
    arc_1_14_18  in_degree_1240  1
    arc_1_14_18  original_T_including_depot_unload_1246  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1103  1
    load_1_14_18  free_load_conservation_1220  1
    load_1_14_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1105  -30
    arc_1_15_0  depot_return_or_bypass_1182  1
    arc_1_15_0  out_degree_1221  1
    arc_1_15_0  original_T_including_depot_unload_1246  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1105  1
    load_1_15_0  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1106  -30
    arc_1_15_9  connected_order_arc_1107  -11
    arc_1_15_9  in_degree_1184  1
    arc_1_15_9  out_degree_1221  1
    arc_1_15_9  original_T_including_depot_unload_1246  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1106  1
    load_1_15_9  segment_load_conservation_1187  -1
    load_1_15_9  segment_prefix_lb_1188  1
    load_1_15_9  segment_prefix_ub_1189  1
    load_1_15_9  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1108  -30
    arc_1_15_10  connected_order_arc_1109  -11
    arc_1_15_10  in_degree_1191  1
    arc_1_15_10  out_degree_1221  1
    arc_1_15_10  original_T_including_depot_unload_1246  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1108  1
    load_1_15_10  segment_load_conservation_1194  -1
    load_1_15_10  segment_prefix_lb_1195  1
    load_1_15_10  segment_prefix_ub_1196  1
    load_1_15_10  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1110  -30
    arc_1_15_11  connected_order_arc_1111  -11
    arc_1_15_11  in_degree_1198  1
    arc_1_15_11  out_degree_1221  1
    arc_1_15_11  original_T_including_depot_unload_1246  2.6166334544495612e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1110  1
    load_1_15_11  free_load_conservation_1202  -1
    load_1_15_11  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1112  -30
    arc_1_15_12  connected_order_arc_1113  -11
    arc_1_15_12  in_degree_1204  1
    arc_1_15_12  out_degree_1221  1
    arc_1_15_12  original_T_including_depot_unload_1246  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1112  1
    load_1_15_12  free_load_conservation_1208  -1
    load_1_15_12  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1114  -30
    arc_1_15_13  connected_order_arc_1115  -11
    arc_1_15_13  in_degree_1210  1
    arc_1_15_13  out_degree_1221  1
    arc_1_15_13  original_T_including_depot_unload_1246  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1114  1
    load_1_15_13  free_load_conservation_1214  -1
    load_1_15_13  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1116  -30
    arc_1_15_14  connected_order_arc_1117  -11
    arc_1_15_14  in_degree_1216  1
    arc_1_15_14  out_degree_1221  1
    arc_1_15_14  original_T_including_depot_unload_1246  2.8270830664529126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1116  1
    load_1_15_14  free_load_conservation_1220  -1
    load_1_15_14  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1118  -30
    arc_1_15_16  connected_order_arc_1119  -11
    arc_1_15_16  out_degree_1221  1
    arc_1_15_16  in_degree_1228  1
    arc_1_15_16  original_T_including_depot_unload_1246  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1118  1
    load_1_15_16  free_load_conservation_1226  1
    load_1_15_16  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1120  -30
    arc_1_15_17  connected_order_arc_1121  -11
    arc_1_15_17  out_degree_1221  1
    arc_1_15_17  in_degree_1234  1
    arc_1_15_17  original_T_including_depot_unload_1246  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1120  1
    load_1_15_17  free_load_conservation_1226  1
    load_1_15_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1122  -30
    arc_1_15_18  connected_order_arc_1123  -11
    arc_1_15_18  out_degree_1221  1
    arc_1_15_18  in_degree_1240  1
    arc_1_15_18  original_T_including_depot_unload_1246  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1122  1
    load_1_15_18  free_load_conservation_1226  1
    load_1_15_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1124  -30
    arc_1_16_0  depot_return_or_bypass_1182  1
    arc_1_16_0  out_degree_1227  1
    arc_1_16_0  original_T_including_depot_unload_1246  2.2058800397347450e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1124  1
    load_1_16_0  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1125  -30
    arc_1_16_9  connected_order_arc_1126  -11
    arc_1_16_9  in_degree_1184  1
    arc_1_16_9  out_degree_1227  1
    arc_1_16_9  original_T_including_depot_unload_1246  3.6590564985322576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1125  1
    load_1_16_9  segment_load_conservation_1187  -1
    load_1_16_9  segment_prefix_lb_1188  1
    load_1_16_9  segment_prefix_ub_1189  1
    load_1_16_9  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1127  -30
    arc_1_16_10  connected_order_arc_1128  -11
    arc_1_16_10  in_degree_1191  1
    arc_1_16_10  out_degree_1227  1
    arc_1_16_10  original_T_including_depot_unload_1246  3.5467090952179333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1127  1
    load_1_16_10  segment_load_conservation_1194  -1
    load_1_16_10  segment_prefix_lb_1195  1
    load_1_16_10  segment_prefix_ub_1196  1
    load_1_16_10  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1129  -30
    arc_1_16_11  connected_order_arc_1130  -11
    arc_1_16_11  in_degree_1198  1
    arc_1_16_11  out_degree_1227  1
    arc_1_16_11  original_T_including_depot_unload_1246  2.9613729621393293e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1129  1
    load_1_16_11  free_load_conservation_1202  -1
    load_1_16_11  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1131  -30
    arc_1_16_12  connected_order_arc_1132  -11
    arc_1_16_12  in_degree_1204  1
    arc_1_16_12  out_degree_1227  1
    arc_1_16_12  original_T_including_depot_unload_1246  2.0591198250504166e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1131  1
    load_1_16_12  free_load_conservation_1208  -1
    load_1_16_12  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1133  -30
    arc_1_16_13  connected_order_arc_1134  -11
    arc_1_16_13  in_degree_1210  1
    arc_1_16_13  out_degree_1227  1
    arc_1_16_13  original_T_including_depot_unload_1246  3.9880377227050253e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1133  1
    load_1_16_13  free_load_conservation_1214  -1
    load_1_16_13  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1135  -30
    arc_1_16_14  connected_order_arc_1136  -11
    arc_1_16_14  in_degree_1216  1
    arc_1_16_14  out_degree_1227  1
    arc_1_16_14  original_T_including_depot_unload_1246  4.9538322318613183e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1135  1
    load_1_16_14  free_load_conservation_1220  -1
    load_1_16_14  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1137  -30
    arc_1_16_15  connected_order_arc_1138  -11
    arc_1_16_15  in_degree_1222  1
    arc_1_16_15  out_degree_1227  1
    arc_1_16_15  original_T_including_depot_unload_1246  2.5694031842490126e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1137  1
    load_1_16_15  free_load_conservation_1226  -1
    load_1_16_15  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1139  -30
    arc_1_16_17  connected_order_arc_1140  -11
    arc_1_16_17  out_degree_1227  1
    arc_1_16_17  in_degree_1234  1
    arc_1_16_17  original_T_including_depot_unload_1246  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1139  1
    load_1_16_17  free_load_conservation_1232  1
    load_1_16_17  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1141  -30
    arc_1_16_18  connected_order_arc_1142  -11
    arc_1_16_18  out_degree_1227  1
    arc_1_16_18  in_degree_1240  1
    arc_1_16_18  original_T_including_depot_unload_1246  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1141  1
    load_1_16_18  free_load_conservation_1232  1
    load_1_16_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1143  -30
    arc_1_17_0  depot_return_or_bypass_1182  1
    arc_1_17_0  out_degree_1233  1
    arc_1_17_0  original_T_including_depot_unload_1246  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1143  1
    load_1_17_0  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1144  -30
    arc_1_17_9  connected_order_arc_1145  -11
    arc_1_17_9  in_degree_1184  1
    arc_1_17_9  out_degree_1233  1
    arc_1_17_9  original_T_including_depot_unload_1246  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1144  1
    load_1_17_9  segment_load_conservation_1187  -1
    load_1_17_9  segment_prefix_lb_1188  1
    load_1_17_9  segment_prefix_ub_1189  1
    load_1_17_9  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1146  -30
    arc_1_17_10  connected_order_arc_1147  -11
    arc_1_17_10  in_degree_1191  1
    arc_1_17_10  out_degree_1233  1
    arc_1_17_10  original_T_including_depot_unload_1246  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1146  1
    load_1_17_10  segment_load_conservation_1194  -1
    load_1_17_10  segment_prefix_lb_1195  1
    load_1_17_10  segment_prefix_ub_1196  1
    load_1_17_10  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_11  arc_capacity_1148  -30
    arc_1_17_11  connected_order_arc_1149  -11
    arc_1_17_11  in_degree_1198  1
    arc_1_17_11  out_degree_1233  1
    arc_1_17_11  original_T_including_depot_unload_1246  2.6300071929095179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_11  arc_capacity_1148  1
    load_1_17_11  free_load_conservation_1202  -1
    load_1_17_11  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_1150  -30
    arc_1_17_12  connected_order_arc_1151  -11
    arc_1_17_12  in_degree_1204  1
    arc_1_17_12  out_degree_1233  1
    arc_1_17_12  original_T_including_depot_unload_1246  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_1150  1
    load_1_17_12  free_load_conservation_1208  -1
    load_1_17_12  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1152  -30
    arc_1_17_13  connected_order_arc_1153  -11
    arc_1_17_13  in_degree_1210  1
    arc_1_17_13  out_degree_1233  1
    arc_1_17_13  original_T_including_depot_unload_1246  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1152  1
    load_1_17_13  free_load_conservation_1214  -1
    load_1_17_13  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1154  -30
    arc_1_17_14  connected_order_arc_1155  -11
    arc_1_17_14  in_degree_1216  1
    arc_1_17_14  out_degree_1233  1
    arc_1_17_14  original_T_including_depot_unload_1246  2.8559472795328161e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1154  1
    load_1_17_14  free_load_conservation_1220  -1
    load_1_17_14  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1156  -30
    arc_1_17_15  connected_order_arc_1157  -11
    arc_1_17_15  in_degree_1222  1
    arc_1_17_15  out_degree_1233  1
    arc_1_17_15  original_T_including_depot_unload_1246  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1156  1
    load_1_17_15  free_load_conservation_1226  -1
    load_1_17_15  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1158  -30
    arc_1_17_16  connected_order_arc_1159  -11
    arc_1_17_16  in_degree_1228  1
    arc_1_17_16  out_degree_1233  1
    arc_1_17_16  original_T_including_depot_unload_1246  2.3631048359201741e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1158  1
    load_1_17_16  free_load_conservation_1232  -1
    load_1_17_16  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1160  -30
    arc_1_17_18  connected_order_arc_1161  -11
    arc_1_17_18  out_degree_1233  1
    arc_1_17_18  in_degree_1240  1
    arc_1_17_18  original_T_including_depot_unload_1246  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1160  1
    load_1_17_18  free_load_conservation_1238  1
    load_1_17_18  free_load_conservation_1244  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1162  -30
    arc_1_18_0  depot_return_or_bypass_1182  1
    arc_1_18_0  out_degree_1239  1
    arc_1_18_0  original_T_including_depot_unload_1246  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1162  1
    load_1_18_0  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1163  -30
    arc_1_18_9  connected_order_arc_1164  -11
    arc_1_18_9  in_degree_1184  1
    arc_1_18_9  out_degree_1239  1
    arc_1_18_9  original_T_including_depot_unload_1246  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1163  1
    load_1_18_9  segment_load_conservation_1187  -1
    load_1_18_9  segment_prefix_lb_1188  1
    load_1_18_9  segment_prefix_ub_1189  1
    load_1_18_9  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1165  -30
    arc_1_18_10  connected_order_arc_1166  -11
    arc_1_18_10  in_degree_1191  1
    arc_1_18_10  out_degree_1239  1
    arc_1_18_10  original_T_including_depot_unload_1246  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1165  1
    load_1_18_10  segment_load_conservation_1194  -1
    load_1_18_10  segment_prefix_lb_1195  1
    load_1_18_10  segment_prefix_ub_1196  1
    load_1_18_10  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_11  arc_capacity_1167  -30
    arc_1_18_11  connected_order_arc_1168  -11
    arc_1_18_11  in_degree_1198  1
    arc_1_18_11  out_degree_1239  1
    arc_1_18_11  original_T_including_depot_unload_1246  2389.0890755213
    MARKER    'MARKER'                 'INTEND'
    load_1_18_11  arc_capacity_1167  1
    load_1_18_11  free_load_conservation_1202  -1
    load_1_18_11  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1169  -30
    arc_1_18_12  connected_order_arc_1170  -11
    arc_1_18_12  in_degree_1204  1
    arc_1_18_12  out_degree_1239  1
    arc_1_18_12  original_T_including_depot_unload_1246  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1169  1
    load_1_18_12  free_load_conservation_1208  -1
    load_1_18_12  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1171  -30
    arc_1_18_13  connected_order_arc_1172  -11
    arc_1_18_13  in_degree_1210  1
    arc_1_18_13  out_degree_1239  1
    arc_1_18_13  original_T_including_depot_unload_1246  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1171  1
    load_1_18_13  free_load_conservation_1214  -1
    load_1_18_13  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1173  -30
    arc_1_18_14  connected_order_arc_1174  -11
    arc_1_18_14  in_degree_1216  1
    arc_1_18_14  out_degree_1239  1
    arc_1_18_14  original_T_including_depot_unload_1246  2.6215712372467274e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1173  1
    load_1_18_14  free_load_conservation_1220  -1
    load_1_18_14  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1175  -30
    arc_1_18_15  connected_order_arc_1176  -11
    arc_1_18_15  in_degree_1222  1
    arc_1_18_15  out_degree_1239  1
    arc_1_18_15  original_T_including_depot_unload_1246  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1175  1
    load_1_18_15  free_load_conservation_1226  -1
    load_1_18_15  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1177  -30
    arc_1_18_16  connected_order_arc_1178  -11
    arc_1_18_16  in_degree_1228  1
    arc_1_18_16  out_degree_1239  1
    arc_1_18_16  original_T_including_depot_unload_1246  2.2742677293115130e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1177  1
    load_1_18_16  free_load_conservation_1232  -1
    load_1_18_16  free_load_conservation_1244  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1179  -30
    arc_1_18_17  connected_order_arc_1180  -11
    arc_1_18_17  in_degree_1234  1
    arc_1_18_17  out_degree_1239  1
    arc_1_18_17  original_T_including_depot_unload_1246  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1179  1
    load_1_18_17  free_load_conservation_1238  -1
    load_1_18_17  free_load_conservation_1244  1
RHS
    RHS1      OBJ       -3.5019562285835687e-01
    RHS1      onehot_15_4  1
    RHS1      onehot_18_39  1
    RHS1      onehot_17_76  1
    RHS1      onehot_19_91  1
    RHS1      onehot_11_126  1
    RHS1      onehot_16_135  1
    RHS1      onehot_20_170  1
    RHS1      onehot_12_205  1
    RHS1      stock_ub_209  28
    RHS1      parent_nonstrict_scope_210  6.1721188784574066e-01
    RHS1      normalization_267  1
    RHS1      connected_order_arc_372  -16
    RHS1      connected_order_arc_374  -16
    RHS1      connected_order_arc_376  -16
    RHS1      connected_order_arc_378  -16
    RHS1      connected_order_arc_380  -16
    RHS1      connected_order_arc_382  -16
    RHS1      connected_order_arc_384  -16
    RHS1      connected_order_arc_386  -16
    RHS1      connected_order_arc_388  -16
    RHS1      connected_order_arc_390  -16
    RHS1      connected_order_arc_392  -16
    RHS1      connected_order_arc_394  -16
    RHS1      connected_order_arc_396  -16
    RHS1      connected_order_arc_398  -16
    RHS1      connected_order_arc_400  -16
    RHS1      connected_order_arc_403  -16
    RHS1      connected_order_arc_405  -16
    RHS1      connected_order_arc_407  -16
    RHS1      connected_order_arc_409  -16
    RHS1      connected_order_arc_411  -16
    RHS1      connected_order_arc_413  -16
    RHS1      connected_order_arc_415  -16
    RHS1      connected_order_arc_417  -16
    RHS1      connected_order_arc_419  -16
    RHS1      connected_order_arc_421  -16
    RHS1      connected_order_arc_423  -16
    RHS1      connected_order_arc_425  -16
    RHS1      connected_order_arc_427  -16
    RHS1      connected_order_arc_429  -16
    RHS1      connected_order_arc_431  -16
    RHS1      connected_order_arc_434  -16
    RHS1      connected_order_arc_436  -16
    RHS1      connected_order_arc_438  -16
    RHS1      connected_order_arc_440  -16
    RHS1      connected_order_arc_442  -16
    RHS1      connected_order_arc_444  -16
    RHS1      connected_order_arc_446  -16
    RHS1      connected_order_arc_448  -16
    RHS1      connected_order_arc_450  -16
    RHS1      connected_order_arc_452  -16
    RHS1      connected_order_arc_454  -16
    RHS1      connected_order_arc_456  -16
    RHS1      connected_order_arc_458  -16
    RHS1      connected_order_arc_460  -16
    RHS1      connected_order_arc_462  -16
    RHS1      connected_order_arc_465  -16
    RHS1      connected_order_arc_467  -16
    RHS1      connected_order_arc_469  -16
    RHS1      connected_order_arc_471  -16
    RHS1      connected_order_arc_473  -16
    RHS1      connected_order_arc_475  -16
    RHS1      connected_order_arc_477  -16
    RHS1      connected_order_arc_479  -16
    RHS1      connected_order_arc_481  -16
    RHS1      connected_order_arc_483  -16
    RHS1      connected_order_arc_485  -16
    RHS1      connected_order_arc_487  -16
    RHS1      connected_order_arc_489  -16
    RHS1      connected_order_arc_491  -16
    RHS1      connected_order_arc_493  -16
    RHS1      connected_order_arc_496  -16
    RHS1      connected_order_arc_498  -16
    RHS1      connected_order_arc_500  -16
    RHS1      connected_order_arc_502  -16
    RHS1      connected_order_arc_504  -16
    RHS1      connected_order_arc_506  -16
    RHS1      connected_order_arc_508  -16
    RHS1      connected_order_arc_510  -16
    RHS1      connected_order_arc_512  -16
    RHS1      connected_order_arc_514  -16
    RHS1      connected_order_arc_516  -16
    RHS1      connected_order_arc_518  -16
    RHS1      connected_order_arc_520  -16
    RHS1      connected_order_arc_522  -16
    RHS1      connected_order_arc_524  -16
    RHS1      connected_order_arc_527  -16
    RHS1      connected_order_arc_529  -16
    RHS1      connected_order_arc_531  -16
    RHS1      connected_order_arc_533  -16
    RHS1      connected_order_arc_535  -16
    RHS1      connected_order_arc_537  -16
    RHS1      connected_order_arc_539  -16
    RHS1      connected_order_arc_541  -16
    RHS1      connected_order_arc_543  -16
    RHS1      connected_order_arc_545  -16
    RHS1      connected_order_arc_547  -16
    RHS1      connected_order_arc_549  -16
    RHS1      connected_order_arc_551  -16
    RHS1      connected_order_arc_553  -16
    RHS1      connected_order_arc_555  -16
    RHS1      connected_order_arc_558  -16
    RHS1      connected_order_arc_560  -16
    RHS1      connected_order_arc_562  -16
    RHS1      connected_order_arc_564  -16
    RHS1      connected_order_arc_566  -16
    RHS1      connected_order_arc_568  -16
    RHS1      connected_order_arc_570  -16
    RHS1      connected_order_arc_572  -16
    RHS1      connected_order_arc_574  -16
    RHS1      connected_order_arc_576  -16
    RHS1      connected_order_arc_578  -16
    RHS1      connected_order_arc_580  -16
    RHS1      connected_order_arc_582  -16
    RHS1      connected_order_arc_584  -16
    RHS1      connected_order_arc_586  -16
    RHS1      connected_order_arc_589  -16
    RHS1      connected_order_arc_591  -16
    RHS1      connected_order_arc_593  -16
    RHS1      connected_order_arc_595  -16
    RHS1      connected_order_arc_597  -16
    RHS1      connected_order_arc_599  -16
    RHS1      connected_order_arc_601  -16
    RHS1      connected_order_arc_603  -16
    RHS1      connected_order_arc_605  -16
    RHS1      connected_order_arc_607  -16
    RHS1      connected_order_arc_609  -16
    RHS1      connected_order_arc_611  -16
    RHS1      connected_order_arc_613  -16
    RHS1      connected_order_arc_615  -16
    RHS1      connected_order_arc_617  -16
    RHS1      connected_order_arc_620  -16
    RHS1      connected_order_arc_622  -16
    RHS1      connected_order_arc_624  -16
    RHS1      connected_order_arc_626  -16
    RHS1      connected_order_arc_628  -16
    RHS1      connected_order_arc_630  -16
    RHS1      connected_order_arc_632  -16
    RHS1      connected_order_arc_634  -16
    RHS1      connected_order_arc_636  -16
    RHS1      connected_order_arc_638  -16
    RHS1      connected_order_arc_640  -16
    RHS1      connected_order_arc_642  -16
    RHS1      connected_order_arc_644  -16
    RHS1      connected_order_arc_646  -16
    RHS1      connected_order_arc_648  -16
    RHS1      connected_order_arc_651  -16
    RHS1      connected_order_arc_653  -16
    RHS1      connected_order_arc_655  -16
    RHS1      connected_order_arc_657  -16
    RHS1      connected_order_arc_659  -16
    RHS1      connected_order_arc_661  -16
    RHS1      connected_order_arc_663  -16
    RHS1      connected_order_arc_665  -16
    RHS1      connected_order_arc_667  -16
    RHS1      connected_order_arc_669  -16
    RHS1      connected_order_arc_671  -16
    RHS1      connected_order_arc_673  -16
    RHS1      connected_order_arc_675  -16
    RHS1      connected_order_arc_677  -16
    RHS1      connected_order_arc_679  -16
    RHS1      connected_order_arc_682  -16
    RHS1      connected_order_arc_684  -16
    RHS1      connected_order_arc_686  -16
    RHS1      connected_order_arc_688  -16
    RHS1      connected_order_arc_690  -16
    RHS1      connected_order_arc_692  -16
    RHS1      connected_order_arc_694  -16
    RHS1      connected_order_arc_696  -16
    RHS1      connected_order_arc_698  -16
    RHS1      connected_order_arc_700  -16
    RHS1      connected_order_arc_702  -16
    RHS1      connected_order_arc_704  -16
    RHS1      connected_order_arc_706  -16
    RHS1      connected_order_arc_708  -16
    RHS1      connected_order_arc_710  -16
    RHS1      connected_order_arc_713  -16
    RHS1      connected_order_arc_715  -16
    RHS1      connected_order_arc_717  -16
    RHS1      connected_order_arc_719  -16
    RHS1      connected_order_arc_721  -16
    RHS1      connected_order_arc_723  -16
    RHS1      connected_order_arc_725  -16
    RHS1      connected_order_arc_727  -16
    RHS1      connected_order_arc_729  -16
    RHS1      connected_order_arc_731  -16
    RHS1      connected_order_arc_733  -16
    RHS1      connected_order_arc_735  -16
    RHS1      connected_order_arc_737  -16
    RHS1      connected_order_arc_739  -16
    RHS1      connected_order_arc_741  -16
    RHS1      connected_order_arc_744  -16
    RHS1      connected_order_arc_746  -16
    RHS1      connected_order_arc_748  -16
    RHS1      connected_order_arc_750  -16
    RHS1      connected_order_arc_752  -16
    RHS1      connected_order_arc_754  -16
    RHS1      connected_order_arc_756  -16
    RHS1      connected_order_arc_758  -16
    RHS1      connected_order_arc_760  -16
    RHS1      connected_order_arc_762  -16
    RHS1      connected_order_arc_764  -16
    RHS1      connected_order_arc_766  -16
    RHS1      connected_order_arc_768  -16
    RHS1      connected_order_arc_770  -16
    RHS1      connected_order_arc_772  -16
    RHS1      connected_order_arc_775  -16
    RHS1      connected_order_arc_777  -16
    RHS1      connected_order_arc_779  -16
    RHS1      connected_order_arc_781  -16
    RHS1      connected_order_arc_783  -16
    RHS1      connected_order_arc_785  -16
    RHS1      connected_order_arc_787  -16
    RHS1      connected_order_arc_789  -16
    RHS1      connected_order_arc_791  -16
    RHS1      connected_order_arc_793  -16
    RHS1      connected_order_arc_795  -16
    RHS1      connected_order_arc_797  -16
    RHS1      connected_order_arc_799  -16
    RHS1      connected_order_arc_801  -16
    RHS1      connected_order_arc_803  -16
    RHS1      connected_order_arc_806  -16
    RHS1      connected_order_arc_808  -16
    RHS1      connected_order_arc_810  -16
    RHS1      connected_order_arc_812  -16
    RHS1      connected_order_arc_814  -16
    RHS1      connected_order_arc_816  -16
    RHS1      connected_order_arc_818  -16
    RHS1      connected_order_arc_820  -16
    RHS1      connected_order_arc_822  -16
    RHS1      connected_order_arc_824  -16
    RHS1      connected_order_arc_826  -16
    RHS1      connected_order_arc_828  -16
    RHS1      connected_order_arc_830  -16
    RHS1      connected_order_arc_832  -16
    RHS1      connected_order_arc_834  -16
    RHS1      connected_order_arc_837  -16
    RHS1      connected_order_arc_839  -16
    RHS1      connected_order_arc_841  -16
    RHS1      connected_order_arc_843  -16
    RHS1      connected_order_arc_845  -16
    RHS1      connected_order_arc_847  -16
    RHS1      connected_order_arc_849  -16
    RHS1      connected_order_arc_851  -16
    RHS1      connected_order_arc_853  -16
    RHS1      connected_order_arc_855  -16
    RHS1      connected_order_arc_857  -16
    RHS1      connected_order_arc_859  -16
    RHS1      connected_order_arc_861  -16
    RHS1      connected_order_arc_863  -16
    RHS1      connected_order_arc_865  -16
    RHS1      depot_departure_or_bypass_866  1
    RHS1      depot_return_or_bypass_867  1
    RHS1      segment_load_conservation_872  -1
    RHS1      segment_prefix_lb_873  1
    RHS1      segment_prefix_ub_874  30
    RHS1      segment_load_conservation_879  -1
    RHS1      segment_prefix_lb_880  1
    RHS1      segment_prefix_ub_881  30
    RHS1      segment_load_conservation_886  2
    RHS1      segment_prefix_ub_888  26
    RHS1      segment_load_conservation_893  -1
    RHS1      segment_prefix_lb_894  1
    RHS1      segment_prefix_ub_895  30
    RHS1      segment_load_conservation_900  3
    RHS1      segment_prefix_ub_902  27
    RHS1      segment_load_conservation_907  -1
    RHS1      segment_prefix_lb_908  1
    RHS1      segment_prefix_ub_909  30
    RHS1      segment_load_conservation_914  -3
    RHS1      segment_prefix_lb_915  3
    RHS1      segment_prefix_ub_916  30
    RHS1      segment_load_conservation_921  -1
    RHS1      segment_prefix_lb_922  1
    RHS1      segment_prefix_ub_923  30
    RHS1      fixed_segment_relative_order_972  1
    RHS1      fixed_segment_relative_order_973  1
    RHS1      fixed_segment_relative_order_974  1
    RHS1      fixed_segment_relative_order_975  1
    RHS1      fixed_segment_relative_order_976  1
    RHS1      fixed_segment_relative_order_977  1
    RHS1      fixed_segment_relative_order_978  1
    RHS1      original_T_including_depot_unload_979  3.5184154298887588e+03
    RHS1      connected_order_arc_993  -10
    RHS1      connected_order_arc_995  -10
    RHS1      connected_order_arc_997  -10
    RHS1      connected_order_arc_999  -10
    RHS1      connected_order_arc_1001  -10
    RHS1      connected_order_arc_1003  -10
    RHS1      connected_order_arc_1005  -10
    RHS1      connected_order_arc_1007  -10
    RHS1      connected_order_arc_1009  -10
    RHS1      connected_order_arc_1012  -10
    RHS1      connected_order_arc_1014  -10
    RHS1      connected_order_arc_1016  -10
    RHS1      connected_order_arc_1018  -10
    RHS1      connected_order_arc_1020  -10
    RHS1      connected_order_arc_1022  -10
    RHS1      connected_order_arc_1024  -10
    RHS1      connected_order_arc_1026  -10
    RHS1      connected_order_arc_1028  -10
    RHS1      connected_order_arc_1031  -10
    RHS1      connected_order_arc_1033  -10
    RHS1      connected_order_arc_1035  -10
    RHS1      connected_order_arc_1037  -10
    RHS1      connected_order_arc_1039  -10
    RHS1      connected_order_arc_1041  -10
    RHS1      connected_order_arc_1043  -10
    RHS1      connected_order_arc_1045  -10
    RHS1      connected_order_arc_1047  -10
    RHS1      connected_order_arc_1050  -10
    RHS1      connected_order_arc_1052  -10
    RHS1      connected_order_arc_1054  -10
    RHS1      connected_order_arc_1056  -10
    RHS1      connected_order_arc_1058  -10
    RHS1      connected_order_arc_1060  -10
    RHS1      connected_order_arc_1062  -10
    RHS1      connected_order_arc_1064  -10
    RHS1      connected_order_arc_1066  -10
    RHS1      connected_order_arc_1069  -10
    RHS1      connected_order_arc_1071  -10
    RHS1      connected_order_arc_1073  -10
    RHS1      connected_order_arc_1075  -10
    RHS1      connected_order_arc_1077  -10
    RHS1      connected_order_arc_1079  -10
    RHS1      connected_order_arc_1081  -10
    RHS1      connected_order_arc_1083  -10
    RHS1      connected_order_arc_1085  -10
    RHS1      connected_order_arc_1088  -10
    RHS1      connected_order_arc_1090  -10
    RHS1      connected_order_arc_1092  -10
    RHS1      connected_order_arc_1094  -10
    RHS1      connected_order_arc_1096  -10
    RHS1      connected_order_arc_1098  -10
    RHS1      connected_order_arc_1100  -10
    RHS1      connected_order_arc_1102  -10
    RHS1      connected_order_arc_1104  -10
    RHS1      connected_order_arc_1107  -10
    RHS1      connected_order_arc_1109  -10
    RHS1      connected_order_arc_1111  -10
    RHS1      connected_order_arc_1113  -10
    RHS1      connected_order_arc_1115  -10
    RHS1      connected_order_arc_1117  -10
    RHS1      connected_order_arc_1119  -10
    RHS1      connected_order_arc_1121  -10
    RHS1      connected_order_arc_1123  -10
    RHS1      connected_order_arc_1126  -10
    RHS1      connected_order_arc_1128  -10
    RHS1      connected_order_arc_1130  -10
    RHS1      connected_order_arc_1132  -10
    RHS1      connected_order_arc_1134  -10
    RHS1      connected_order_arc_1136  -10
    RHS1      connected_order_arc_1138  -10
    RHS1      connected_order_arc_1140  -10
    RHS1      connected_order_arc_1142  -10
    RHS1      connected_order_arc_1145  -10
    RHS1      connected_order_arc_1147  -10
    RHS1      connected_order_arc_1149  -10
    RHS1      connected_order_arc_1151  -10
    RHS1      connected_order_arc_1153  -10
    RHS1      connected_order_arc_1155  -10
    RHS1      connected_order_arc_1157  -10
    RHS1      connected_order_arc_1159  -10
    RHS1      connected_order_arc_1161  -10
    RHS1      connected_order_arc_1164  -10
    RHS1      connected_order_arc_1166  -10
    RHS1      connected_order_arc_1168  -10
    RHS1      connected_order_arc_1170  -10
    RHS1      connected_order_arc_1172  -10
    RHS1      connected_order_arc_1174  -10
    RHS1      connected_order_arc_1176  -10
    RHS1      connected_order_arc_1178  -10
    RHS1      connected_order_arc_1180  -10
    RHS1      depot_departure_or_bypass_1181  1
    RHS1      depot_return_or_bypass_1182  1
    RHS1      segment_load_conservation_1187  4
    RHS1      segment_prefix_ub_1189  26
    RHS1      segment_load_conservation_1194  -1
    RHS1      segment_prefix_lb_1195  1
    RHS1      segment_prefix_ub_1196  30
    RHS1      fixed_segment_relative_order_1245  1
    RHS1      original_T_including_depot_unload_1246  4320
BOUNDS
 LO BND1      t         3.8960436604218850e-02
 UP BND1      t         9.6585029320551935e-02
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_15_0  
 UP BND1      w_15_0    9.6585029320551935e-02
 BV BND1      x_15_1  
 UP BND1      w_15_1    9.6585029320551935e-02
 UP BND1      rho_15    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    9.6585029320551935e-02
 BV BND1      x_18_1  
 UP BND1      w_18_1    9.6585029320551935e-02
 BV BND1      x_18_2  
 UP BND1      w_18_2    9.6585029320551935e-02
 BV BND1      x_18_3  
 UP BND1      w_18_3    9.6585029320551935e-02
 BV BND1      x_18_4  
 UP BND1      w_18_4    9.6585029320551935e-02
 BV BND1      x_18_5  
 UP BND1      w_18_5    9.6585029320551935e-02
 BV BND1      x_18_6  
 UP BND1      w_18_6    9.6585029320551935e-02
 BV BND1      x_18_7  
 UP BND1      w_18_7    9.6585029320551935e-02
 BV BND1      x_18_8  
 UP BND1      w_18_8    9.6585029320551935e-02
 BV BND1      x_18_9  
 UP BND1      w_18_9    9.6585029320551935e-02
 BV BND1      x_18_10 
 UP BND1      w_18_10   9.6585029320551935e-02
 BV BND1      x_18_11 
 UP BND1      w_18_11   9.6585029320551935e-02
 BV BND1      x_18_12 
 UP BND1      w_18_12   9.6585029320551935e-02
 BV BND1      x_18_13 
 UP BND1      w_18_13   9.6585029320551935e-02
 BV BND1      x_18_14 
 UP BND1      w_18_14   9.6585029320551935e-02
 BV BND1      x_18_15 
 UP BND1      w_18_15   9.6585029320551935e-02
 UP BND1      rho_18    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    9.6585029320551935e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    9.6585029320551935e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    9.6585029320551935e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    9.6585029320551935e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    9.6585029320551935e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    9.6585029320551935e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    9.6585029320551935e-02
 BV BND1      x_17_7  
 UP BND1      w_17_7    9.6585029320551935e-02
 BV BND1      x_17_8  
 UP BND1      w_17_8    9.6585029320551935e-02
 BV BND1      x_17_9  
 UP BND1      w_17_9    9.6585029320551935e-02
 BV BND1      x_17_10 
 UP BND1      w_17_10   9.6585029320551935e-02
 BV BND1      x_17_11 
 UP BND1      w_17_11   9.6585029320551935e-02
 BV BND1      x_17_12 
 UP BND1      w_17_12   9.6585029320551935e-02
 BV BND1      x_17_13 
 UP BND1      w_17_13   9.6585029320551935e-02
 BV BND1      x_17_14 
 UP BND1      w_17_14   9.6585029320551935e-02
 BV BND1      x_17_15 
 UP BND1      w_17_15   9.6585029320551935e-02
 BV BND1      x_17_16 
 UP BND1      w_17_16   9.6585029320551935e-02
 UP BND1      rho_17    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    9.6585029320551935e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    9.6585029320551935e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    9.6585029320551935e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    9.6585029320551935e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    9.6585029320551935e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    9.6585029320551935e-02
 UP BND1      rho_19    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    9.6585029320551935e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    9.6585029320551935e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    9.6585029320551935e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    9.6585029320551935e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    9.6585029320551935e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    9.6585029320551935e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    9.6585029320551935e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    9.6585029320551935e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    9.6585029320551935e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    9.6585029320551935e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   9.6585029320551935e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   9.6585029320551935e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   9.6585029320551935e-02
 BV BND1      x_11_13 
 UP BND1      w_11_13   9.6585029320551935e-02
 BV BND1      x_11_14 
 UP BND1      w_11_14   9.6585029320551935e-02
 BV BND1      x_11_15 
 UP BND1      w_11_15   9.6585029320551935e-02
 UP BND1      rho_11    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    9.6585029320551935e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    9.6585029320551935e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    9.6585029320551935e-02
 UP BND1      rho_16    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    9.6585029320551935e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    9.6585029320551935e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    9.6585029320551935e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    9.6585029320551935e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    9.6585029320551935e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    9.6585029320551935e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    9.6585029320551935e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    9.6585029320551935e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    9.6585029320551935e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    9.6585029320551935e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   9.6585029320551935e-02
 BV BND1      x_20_11 
 UP BND1      w_20_11   9.6585029320551935e-02
 BV BND1      x_20_12 
 UP BND1      w_20_12   9.6585029320551935e-02
 BV BND1      x_20_13 
 UP BND1      w_20_13   9.6585029320551935e-02
 BV BND1      x_20_14 
 UP BND1      w_20_14   9.6585029320551935e-02
 BV BND1      x_20_15 
 UP BND1      w_20_15   9.6585029320551935e-02
 UP BND1      rho_20    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    9.6585029320551935e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    9.6585029320551935e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    9.6585029320551935e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    9.6585029320551935e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    9.6585029320551935e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    9.6585029320551935e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    9.6585029320551935e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    9.6585029320551935e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    9.6585029320551935e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    9.6585029320551935e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   9.6585029320551935e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   9.6585029320551935e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   9.6585029320551935e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   9.6585029320551935e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   9.6585029320551935e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   9.6585029320551935e-02
 UP BND1      rho_12    1
 UP BND1      a_15_18   1
 UP BND1      a_15_17   1
 UP BND1      a_15_19   1
 UP BND1      a_15_11   1
 UP BND1      a_15_16   1
 UP BND1      a_15_20   1
 UP BND1      a_15_12   1
 UP BND1      a_18_17   1
 UP BND1      a_18_19   1
 UP BND1      a_18_11   1
 UP BND1      a_18_16   1
 UP BND1      a_18_20   1
 UP BND1      a_18_12   1
 UP BND1      a_17_19   1
 UP BND1      a_17_11   1
 UP BND1      a_17_16   1
 UP BND1      a_17_20   1
 UP BND1      a_17_12   1
 UP BND1      a_19_11   1
 UP BND1      a_19_16   1
 UP BND1      a_19_20   1
 UP BND1      a_19_12   1
 UP BND1      a_11_16   1
 UP BND1      a_11_20   1
 UP BND1      a_11_12   1
 UP BND1      a_16_20   1
 UP BND1      a_16_12   1
 UP BND1      a_20_12   1
 BV BND1      service_0_15_1
 BV BND1      service_1_15_1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  16
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  16
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  16
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  16
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  16
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  16
 FX BND1      visit_0_7  1
 UP BND1      order_0_7  16
 FX BND1      visit_0_8  1
 UP BND1      order_0_8  16
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  16
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  16
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  16
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  16
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  16
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  16
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  16
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  16
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_7
 FX BND1      load_0_0_7  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_7
 UP BND1      load_0_1_7  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  30
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_7
 UP BND1      load_0_2_7  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  30
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_7
 UP BND1      load_0_3_7  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  30
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_7
 UP BND1      load_0_4_7  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  30
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_7
 UP BND1      load_0_5_7  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  30
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_7
 UP BND1      load_0_6_7  30
 BV BND1      arc_0_6_8
 UP BND1      load_0_6_8  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  30
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  30
 BV BND1      arc_0_7_0
 UP BND1      load_0_7_0  30
 BV BND1      arc_0_7_1
 UP BND1      load_0_7_1  30
 BV BND1      arc_0_7_2
 UP BND1      load_0_7_2  30
 BV BND1      arc_0_7_3
 UP BND1      load_0_7_3  30
 BV BND1      arc_0_7_4
 UP BND1      load_0_7_4  30
 BV BND1      arc_0_7_5
 UP BND1      load_0_7_5  30
 BV BND1      arc_0_7_6
 UP BND1      load_0_7_6  30
 BV BND1      arc_0_7_8
 UP BND1      load_0_7_8  30
 BV BND1      arc_0_7_11
 UP BND1      load_0_7_11  30
 BV BND1      arc_0_7_12
 UP BND1      load_0_7_12  30
 BV BND1      arc_0_7_13
 UP BND1      load_0_7_13  30
 BV BND1      arc_0_7_14
 UP BND1      load_0_7_14  30
 BV BND1      arc_0_7_15
 UP BND1      load_0_7_15  30
 BV BND1      arc_0_7_16
 UP BND1      load_0_7_16  30
 BV BND1      arc_0_7_17
 UP BND1      load_0_7_17  30
 BV BND1      arc_0_7_18
 UP BND1      load_0_7_18  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_6
 UP BND1      load_0_8_6  30
 BV BND1      arc_0_8_7
 UP BND1      load_0_8_7  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_8_16
 UP BND1      load_0_8_16  30
 BV BND1      arc_0_8_17
 UP BND1      load_0_8_17  30
 BV BND1      arc_0_8_18
 UP BND1      load_0_8_18  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_7
 UP BND1      load_0_11_7  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_11_17
 UP BND1      load_0_11_17  30
 BV BND1      arc_0_11_18
 UP BND1      load_0_11_18  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_7
 UP BND1      load_0_12_7  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  30
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_7
 UP BND1      load_0_13_7  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  30
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_7
 UP BND1      load_0_14_7  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  30
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_7
 UP BND1      load_0_15_7  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  30
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_7
 UP BND1      load_0_16_7  30
 BV BND1      arc_0_16_8
 UP BND1      load_0_16_8  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  30
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  30
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  30
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  30
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  30
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  30
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  30
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  30
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  30
 BV BND1      arc_0_17_7
 UP BND1      load_0_17_7  30
 BV BND1      arc_0_17_8
 UP BND1      load_0_17_8  30
 BV BND1      arc_0_17_11
 UP BND1      load_0_17_11  30
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  30
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  30
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  30
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  30
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  30
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  30
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  30
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  30
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  30
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  30
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  30
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  30
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  30
 BV BND1      arc_0_18_7
 UP BND1      load_0_18_7  30
 BV BND1      arc_0_18_8
 UP BND1      load_0_18_8  30
 BV BND1      arc_0_18_11
 UP BND1      load_0_18_11  30
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  30
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  30
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  30
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  30
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  30
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  30
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  10
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  10
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  10
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  30
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  30
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_11_17
 UP BND1      load_1_11_17  30
 BV BND1      arc_1_11_18
 UP BND1      load_1_11_18  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  30
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  30
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  30
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  30
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  30
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  30
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  30
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  30
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  30
 BV BND1      arc_1_17_11
 UP BND1      load_1_17_11  30
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  30
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  30
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  30
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  30
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  30
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  30
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  30
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  30
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  30
 BV BND1      arc_1_18_11
 UP BND1      load_1_18_11  30
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  30
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  30
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  30
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  30
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  30
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  30
ENDATA
