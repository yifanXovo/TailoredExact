import subprocess,sys,time,os,json
from pathlib import Path
p=subprocess.Popen([sys.executable,"-c","import time;time.sleep(60)"])
Path(sys.argv[1]).write_text(json.dumps({"parent":os.getpid(),"child":p.pid}))
time.sleep(60)
