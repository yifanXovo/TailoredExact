* Signature: 0xcb960a9f5970884d
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  R2      
 L  R3      
 G  R4      
 L  R5      
 G  R6      
 L  R7      
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  R12     
 L  R13     
 G  R14     
 L  R15     
 G  R16     
 L  R17     
 E  normalized_inventory_2
 E  normalized_ratio_2
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  R25     
 G  R26     
 L  true_G_epigraph
 L  physical_G_upper
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       0.5
    x[1,0]    onehot_1  1
    x[1,0]    R2        -3.9999999999999997e-01
    x[1,0]    R3        -2
    x[1,1]    OBJ       -0.5625
    x[1,1]    onehot_1  1
    x[1,1]    R4        -3.9999999999999997e-01
    x[1,1]    R5        -2
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,3]    OBJ       -0.5625
    x[1,3]    onehot_1  1
    x[1,3]    R6        -3.9999999999999997e-01
    x[1,3]    R7        -2
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[2,0]    OBJ       0.5
    x[2,0]    onehot_2  1
    x[2,0]    R12       -3.9999999999999997e-01
    x[2,0]    R13       -2
    x[2,1]    OBJ       -0.625
    x[2,1]    onehot_2  1
    x[2,1]    R14       -3.9999999999999997e-01
    x[2,1]    R15       -2
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,2]    OBJ       0.5
    x[2,2]    onehot_2  1
    x[2,2]    R16       -3.9999999999999997e-01
    x[2,2]    R17       -2
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    R2        1
    w[1,0]    R3        1
    w[1,1]    mass_1    1
    w[1,1]    R4        1
    w[1,1]    R5        1
    w[1,1]    normalized_inventory_1  -1
    w[1,3]    mass_1    1
    w[1,3]    R6        1
    w[1,3]    R7        1
    w[1,3]    normalized_inventory_1  -3
    w[2,0]    mass_2    1
    w[2,0]    R12       1
    w[2,0]    R13       1
    w[2,1]    mass_2    1
    w[2,1]    R14       1
    w[2,1]    R15       1
    w[2,1]    normalized_inventory_2  -1
    w[2,2]    mass_2    1
    w[2,2]    R16       1
    w[2,2]    R17       1
    w[2,2]    normalized_inventory_2  -2
    t         mass_1    -1
    t         mass_2    -1
    t         scaled_stock_upper  -3
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -0.5
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -1
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      R25       -1
    r[1]      R26       1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      R25       1
    r[2]      R26       -1
    a[1,2]    R25       1
    a[1,2]    R26       1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    q         OBJ       1
    q         true_G_epigraph  -2
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      hard_upper  3
    RHS1      normalization  1
    RHS1      physical_G_upper  1
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,3]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 UP BND1      w[1,0]    2
 UP BND1      w[1,1]    2
 UP BND1      w[1,3]    2
 UP BND1      w[2,0]    2
 UP BND1      w[2,1]    2
 UP BND1      w[2,2]    2
 LO BND1      t         3.9999999999999997e-01
 UP BND1      t         2
 LO BND1      q         0.2
ENDATA
