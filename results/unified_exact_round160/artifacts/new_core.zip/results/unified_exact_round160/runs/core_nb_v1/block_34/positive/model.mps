* Signature: 0x9a17041efee562bd
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_35_32
 E  normalized_mass_35_33
 E  normalized_ratio_35_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_30_53
 E  normalized_mass_30_54
 E  normalized_ratio_30_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_31_82
 E  normalized_mass_31_83
 E  normalized_ratio_31_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_32_111
 E  normalized_mass_32_112
 E  normalized_ratio_32_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 E  onehot_16_140
 E  normalized_mass_16_141
 E  normalized_ratio_16_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 E  onehot_26_161
 E  normalized_mass_26_162
 E  normalized_ratio_26_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 G  product_lb_178
 L  product_ub_179
 G  product_lb_180
 L  product_ub_181
 G  product_lb_182
 L  product_ub_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 E  onehot_5_198
 E  normalized_mass_5_199
 E  normalized_ratio_5_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 E  onehot_19_219
 E  normalized_mass_19_220
 E  normalized_ratio_19_221
 G  stock_lb_222
 L  stock_ub_223
 L  parent_nonstrict_scope_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 E  normalization_281
 G  full_original_Gini_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 L  arc_capacity_374
 L  arc_capacity_375
 L  arc_capacity_376
 L  arc_capacity_377
 L  arc_capacity_378
 L  arc_capacity_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 G  connected_order_arc_391
 L  arc_capacity_392
 G  connected_order_arc_393
 L  arc_capacity_394
 G  connected_order_arc_395
 L  arc_capacity_396
 G  connected_order_arc_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 G  connected_order_arc_426
 L  arc_capacity_427
 G  connected_order_arc_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 E  depot_departure_or_bypass_767
 E  depot_return_or_bypass_768
 E  out_degree_769
 E  in_degree_770
 G  order_active_lb_771
 L  order_active_ub_772
 E  segment_load_conservation_773
 G  segment_prefix_lb_774
 L  segment_prefix_ub_775
 E  out_degree_776
 E  in_degree_777
 G  order_active_lb_778
 L  order_active_ub_779
 E  segment_load_conservation_780
 G  segment_prefix_lb_781
 L  segment_prefix_ub_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  segment_load_conservation_787
 G  segment_prefix_lb_788
 L  segment_prefix_ub_789
 E  out_degree_790
 E  in_degree_791
 G  order_active_lb_792
 L  order_active_ub_793
 E  segment_load_conservation_794
 G  segment_prefix_lb_795
 L  segment_prefix_ub_796
 E  out_degree_797
 E  in_degree_798
 G  order_active_lb_799
 L  order_active_ub_800
 E  segment_load_conservation_801
 G  segment_prefix_lb_802
 L  segment_prefix_ub_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  segment_load_conservation_808
 G  segment_prefix_lb_809
 L  segment_prefix_ub_810
 E  out_degree_811
 E  in_degree_812
 G  order_active_lb_813
 L  order_active_ub_814
 E  service_visit_def_815
 E  free_load_conservation_816
 E  out_degree_817
 E  in_degree_818
 G  order_active_lb_819
 L  order_active_ub_820
 E  service_visit_def_821
 E  free_load_conservation_822
 E  out_degree_823
 E  in_degree_824
 G  order_active_lb_825
 L  order_active_ub_826
 E  service_visit_def_827
 E  free_load_conservation_828
 E  out_degree_829
 E  in_degree_830
 G  order_active_lb_831
 L  order_active_ub_832
 E  service_visit_def_833
 E  free_load_conservation_834
 E  out_degree_835
 E  in_degree_836
 G  order_active_lb_837
 L  order_active_ub_838
 E  service_visit_def_839
 E  free_load_conservation_840
 E  out_degree_841
 E  in_degree_842
 G  order_active_lb_843
 L  order_active_ub_844
 E  service_visit_def_845
 E  free_load_conservation_846
 E  out_degree_847
 E  in_degree_848
 G  order_active_lb_849
 L  order_active_ub_850
 E  service_visit_def_851
 E  free_load_conservation_852
 E  out_degree_853
 E  in_degree_854
 G  order_active_lb_855
 L  order_active_ub_856
 E  service_visit_def_857
 E  free_load_conservation_858
 G  fixed_segment_relative_order_859
 G  fixed_segment_relative_order_860
 G  fixed_segment_relative_order_861
 G  fixed_segment_relative_order_862
 G  fixed_segment_relative_order_863
 L  original_T_including_depot_unload_864
 L  arc_capacity_865
 L  arc_capacity_866
 L  arc_capacity_867
 L  arc_capacity_868
 L  arc_capacity_869
 L  arc_capacity_870
 L  arc_capacity_871
 L  arc_capacity_872
 L  arc_capacity_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 G  connected_order_arc_1139
 L  arc_capacity_1140
 G  connected_order_arc_1141
 L  arc_capacity_1142
 G  connected_order_arc_1143
 L  arc_capacity_1144
 G  connected_order_arc_1145
 L  arc_capacity_1146
 G  connected_order_arc_1147
 L  arc_capacity_1148
 G  connected_order_arc_1149
 L  arc_capacity_1150
 G  connected_order_arc_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 L  arc_capacity_1161
 G  connected_order_arc_1162
 L  arc_capacity_1163
 G  connected_order_arc_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 E  depot_departure_or_bypass_1204
 E  depot_return_or_bypass_1205
 E  out_degree_1206
 E  in_degree_1207
 G  order_active_lb_1208
 L  order_active_ub_1209
 E  segment_load_conservation_1210
 G  segment_prefix_lb_1211
 L  segment_prefix_ub_1212
 E  out_degree_1213
 E  in_degree_1214
 G  order_active_lb_1215
 L  order_active_ub_1216
 E  segment_load_conservation_1217
 G  segment_prefix_lb_1218
 L  segment_prefix_ub_1219
 E  out_degree_1220
 E  in_degree_1221
 G  order_active_lb_1222
 L  order_active_ub_1223
 E  segment_load_conservation_1224
 G  segment_prefix_lb_1225
 L  segment_prefix_ub_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  segment_load_conservation_1231
 G  segment_prefix_lb_1232
 L  segment_prefix_ub_1233
 E  out_degree_1234
 E  in_degree_1235
 G  order_active_lb_1236
 L  order_active_ub_1237
 E  segment_load_conservation_1238
 G  segment_prefix_lb_1239
 L  segment_prefix_ub_1240
 E  out_degree_1241
 E  in_degree_1242
 G  order_active_lb_1243
 L  order_active_ub_1244
 E  service_visit_def_1245
 E  free_load_conservation_1246
 E  out_degree_1247
 E  in_degree_1248
 G  order_active_lb_1249
 L  order_active_ub_1250
 E  service_visit_def_1251
 E  free_load_conservation_1252
 E  out_degree_1253
 E  in_degree_1254
 G  order_active_lb_1255
 L  order_active_ub_1256
 E  service_visit_def_1257
 E  free_load_conservation_1258
 E  out_degree_1259
 E  in_degree_1260
 G  order_active_lb_1261
 L  order_active_ub_1262
 E  service_visit_def_1263
 E  free_load_conservation_1264
 E  out_degree_1265
 E  in_degree_1266
 G  order_active_lb_1267
 L  order_active_ub_1268
 E  service_visit_def_1269
 E  free_load_conservation_1270
 E  out_degree_1271
 E  in_degree_1272
 G  order_active_lb_1273
 L  order_active_ub_1274
 E  service_visit_def_1275
 E  free_load_conservation_1276
 E  out_degree_1277
 E  in_degree_1278
 G  order_active_lb_1279
 L  order_active_ub_1280
 E  service_visit_def_1281
 E  free_load_conservation_1282
 E  out_degree_1283
 E  in_degree_1284
 G  order_active_lb_1285
 L  order_active_ub_1286
 E  service_visit_def_1287
 E  free_load_conservation_1288
 G  fixed_segment_relative_order_1289
 G  fixed_segment_relative_order_1290
 G  fixed_segment_relative_order_1291
 G  fixed_segment_relative_order_1292
 L  original_T_including_depot_unload_1293
 L  arc_capacity_1294
 L  arc_capacity_1295
 L  arc_capacity_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 L  arc_capacity_1299
 L  arc_capacity_1300
 L  arc_capacity_1301
 L  arc_capacity_1302
 L  arc_capacity_1303
 L  arc_capacity_1304
 L  arc_capacity_1305
 L  arc_capacity_1306
 L  arc_capacity_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 L  arc_capacity_1456
 G  connected_order_arc_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 G  connected_order_arc_1476
 L  arc_capacity_1477
 G  connected_order_arc_1478
 L  arc_capacity_1479
 G  connected_order_arc_1480
 L  arc_capacity_1481
 G  connected_order_arc_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 G  connected_order_arc_1497
 L  arc_capacity_1498
 G  connected_order_arc_1499
 L  arc_capacity_1500
 G  connected_order_arc_1501
 L  arc_capacity_1502
 G  connected_order_arc_1503
 L  arc_capacity_1504
 G  connected_order_arc_1505
 L  arc_capacity_1506
 G  connected_order_arc_1507
 L  arc_capacity_1508
 G  connected_order_arc_1509
 L  arc_capacity_1510
 G  connected_order_arc_1511
 L  arc_capacity_1512
 G  connected_order_arc_1513
 L  arc_capacity_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 G  connected_order_arc_1518
 L  arc_capacity_1519
 G  connected_order_arc_1520
 L  arc_capacity_1521
 G  connected_order_arc_1522
 L  arc_capacity_1523
 G  connected_order_arc_1524
 L  arc_capacity_1525
 G  connected_order_arc_1526
 L  arc_capacity_1527
 G  connected_order_arc_1528
 L  arc_capacity_1529
 G  connected_order_arc_1530
 L  arc_capacity_1531
 G  connected_order_arc_1532
 L  arc_capacity_1533
 G  connected_order_arc_1534
 L  arc_capacity_1535
 G  connected_order_arc_1536
 L  arc_capacity_1537
 L  arc_capacity_1538
 G  connected_order_arc_1539
 L  arc_capacity_1540
 G  connected_order_arc_1541
 L  arc_capacity_1542
 G  connected_order_arc_1543
 L  arc_capacity_1544
 G  connected_order_arc_1545
 L  arc_capacity_1546
 G  connected_order_arc_1547
 L  arc_capacity_1548
 G  connected_order_arc_1549
 L  arc_capacity_1550
 G  connected_order_arc_1551
 L  arc_capacity_1552
 G  connected_order_arc_1553
 L  arc_capacity_1554
 G  connected_order_arc_1555
 L  arc_capacity_1556
 G  connected_order_arc_1557
 L  arc_capacity_1558
 G  connected_order_arc_1559
 L  arc_capacity_1560
 L  arc_capacity_1561
 G  connected_order_arc_1562
 L  arc_capacity_1563
 G  connected_order_arc_1564
 L  arc_capacity_1565
 G  connected_order_arc_1566
 L  arc_capacity_1567
 G  connected_order_arc_1568
 L  arc_capacity_1569
 G  connected_order_arc_1570
 L  arc_capacity_1571
 G  connected_order_arc_1572
 L  arc_capacity_1573
 G  connected_order_arc_1574
 L  arc_capacity_1575
 G  connected_order_arc_1576
 L  arc_capacity_1577
 G  connected_order_arc_1578
 L  arc_capacity_1579
 G  connected_order_arc_1580
 L  arc_capacity_1581
 G  connected_order_arc_1582
 E  depot_departure_or_bypass_1583
 E  depot_return_or_bypass_1584
 E  out_degree_1585
 E  in_degree_1586
 G  order_active_lb_1587
 L  order_active_ub_1588
 E  segment_load_conservation_1589
 G  segment_prefix_lb_1590
 L  segment_prefix_ub_1591
 E  out_degree_1592
 E  in_degree_1593
 G  order_active_lb_1594
 L  order_active_ub_1595
 E  segment_load_conservation_1596
 G  segment_prefix_lb_1597
 L  segment_prefix_ub_1598
 E  out_degree_1599
 E  in_degree_1600
 G  order_active_lb_1601
 L  order_active_ub_1602
 E  segment_load_conservation_1603
 G  segment_prefix_lb_1604
 L  segment_prefix_ub_1605
 E  out_degree_1606
 E  in_degree_1607
 G  order_active_lb_1608
 L  order_active_ub_1609
 E  segment_load_conservation_1610
 G  segment_prefix_lb_1611
 L  segment_prefix_ub_1612
 E  out_degree_1613
 E  in_degree_1614
 G  order_active_lb_1615
 L  order_active_ub_1616
 E  service_visit_def_1617
 E  free_load_conservation_1618
 E  out_degree_1619
 E  in_degree_1620
 G  order_active_lb_1621
 L  order_active_ub_1622
 E  service_visit_def_1623
 E  free_load_conservation_1624
 E  out_degree_1625
 E  in_degree_1626
 G  order_active_lb_1627
 L  order_active_ub_1628
 E  service_visit_def_1629
 E  free_load_conservation_1630
 E  out_degree_1631
 E  in_degree_1632
 G  order_active_lb_1633
 L  order_active_ub_1634
 E  service_visit_def_1635
 E  free_load_conservation_1636
 E  out_degree_1637
 E  in_degree_1638
 G  order_active_lb_1639
 L  order_active_ub_1640
 E  service_visit_def_1641
 E  free_load_conservation_1642
 E  out_degree_1643
 E  in_degree_1644
 G  order_active_lb_1645
 L  order_active_ub_1646
 E  service_visit_def_1647
 E  free_load_conservation_1648
 E  out_degree_1649
 E  in_degree_1650
 G  order_active_lb_1651
 L  order_active_ub_1652
 E  service_visit_def_1653
 E  free_load_conservation_1654
 E  out_degree_1655
 E  in_degree_1656
 G  order_active_lb_1657
 L  order_active_ub_1658
 E  service_visit_def_1659
 E  free_load_conservation_1660
 G  fixed_segment_relative_order_1661
 G  fixed_segment_relative_order_1662
 G  fixed_segment_relative_order_1663
 L  original_T_including_depot_unload_1664
COLUMNS
    t         normalized_mass_35_33  -1
    t         normalized_mass_30_54  -1
    t         normalized_mass_31_83  -1
    t         normalized_mass_32_112  -1
    t         normalized_mass_16_141  -1
    t         normalized_mass_26_162  -1
    t         normalized_mass_5_199  -1
    t         normalized_mass_19_220  -1
    t         normalization_281  2.4168253968253971e+01
    t         full_original_Gini_282  -5.0325396825396794e+01
    q         OBJ       1
    q         parent_nonstrict_scope_224  1
    q         full_original_Gini_282  35
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       0.048
    x_35_0    product_lb_0  -2.4901923970053259e-02
    x_35_0    product_ub_1  -4.1376592670473542e-02
    x_35_0    onehot_35_32  1
    x_35_0    parent_nonstrict_scope_224  0.096
    x_35_0    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_0  1
    w_35_0    product_ub_1  1
    w_35_0    normalized_mass_35_33  1
    w_35_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       3.6000000000000004e-02
    x_35_1    product_lb_2  -2.4901923970053259e-02
    x_35_1    product_ub_3  -4.1376592670473542e-02
    x_35_1    onehot_35_32  1
    x_35_1    stock_lb_222  1
    x_35_1    stock_ub_223  1
    x_35_1    parent_nonstrict_scope_224  0.084
    x_35_1    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_2  1
    w_35_1    product_ub_3  1
    w_35_1    normalized_mass_35_33  1
    w_35_1    normalized_ratio_35_34  -0.125
    w_35_1    full_original_Gini_282  -2.0793253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       2.4000000000000007e-02
    x_35_2    product_lb_4  -2.4901923970053259e-02
    x_35_2    product_ub_5  -4.1376592670473542e-02
    x_35_2    onehot_35_32  1
    x_35_2    stock_lb_222  2
    x_35_2    stock_ub_223  2
    x_35_2    parent_nonstrict_scope_224  7.2000000000000008e-02
    x_35_2    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_4  1
    w_35_2    product_ub_5  1
    w_35_2    normalized_mass_35_33  1
    w_35_2    normalized_ratio_35_34  -0.25
    w_35_2    full_original_Gini_282  -1.7418253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       1.1999999999999997e-02
    x_35_3    product_lb_6  -2.4901923970053259e-02
    x_35_3    product_ub_7  -4.1376592670473542e-02
    x_35_3    onehot_35_32  1
    x_35_3    stock_lb_222  3
    x_35_3    stock_ub_223  3
    x_35_3    parent_nonstrict_scope_224  0.06
    x_35_3    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_6  1
    w_35_3    product_ub_7  1
    w_35_3    normalized_mass_35_33  1
    w_35_3    normalized_ratio_35_34  -0.375
    w_35_3    full_original_Gini_282  -1.4043253968253968e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_8  -2.4901923970053259e-02
    x_35_4    product_ub_9  -4.1376592670473542e-02
    x_35_4    onehot_35_32  1
    x_35_4    stock_lb_222  4
    x_35_4    stock_ub_223  4
    x_35_4    parent_nonstrict_scope_224  0.048
    x_35_4    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_8  1
    w_35_4    product_ub_9  1
    w_35_4    normalized_mass_35_33  1
    w_35_4    normalized_ratio_35_34  -0.5
    w_35_4    full_original_Gini_282  -1.0668253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -1.1999999999999997e-02
    x_35_5    product_lb_10  -2.4901923970053259e-02
    x_35_5    product_ub_11  -4.1376592670473542e-02
    x_35_5    onehot_35_32  1
    x_35_5    stock_lb_222  5
    x_35_5    stock_ub_223  5
    x_35_5    parent_nonstrict_scope_224  3.6000000000000004e-02
    x_35_5    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_10  1
    w_35_5    product_ub_11  1
    w_35_5    normalized_mass_35_33  1
    w_35_5    normalized_ratio_35_34  -0.625
    w_35_5    full_original_Gini_282  -7.3932539682539673e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -0.024
    x_35_6    product_lb_12  -2.4901923970053259e-02
    x_35_6    product_ub_13  -4.1376592670473542e-02
    x_35_6    onehot_35_32  1
    x_35_6    stock_lb_222  6
    x_35_6    stock_ub_223  6
    x_35_6    parent_nonstrict_scope_224  0.024
    x_35_6    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_12  1
    w_35_6    product_ub_13  1
    w_35_6    normalized_mass_35_33  1
    w_35_6    normalized_ratio_35_34  -0.75
    w_35_6    full_original_Gini_282  -4.7325396825396808e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -3.6000000000000004e-02
    x_35_7    product_lb_14  -2.4901923970053259e-02
    x_35_7    product_ub_15  -4.1376592670473542e-02
    x_35_7    onehot_35_32  1
    x_35_7    stock_lb_222  7
    x_35_7    stock_ub_223  7
    x_35_7    parent_nonstrict_scope_224  0.012
    x_35_7    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_14  1
    w_35_7    product_ub_15  1
    w_35_7    normalized_mass_35_33  1
    w_35_7    normalized_ratio_35_34  -0.875
    w_35_7    full_original_Gini_282  -3.2623015873015873e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -0.048
    x_35_8    product_lb_16  -2.4901923970053259e-02
    x_35_8    product_ub_17  -4.1376592670473542e-02
    x_35_8    onehot_35_32  1
    x_35_8    stock_lb_222  8
    x_35_8    stock_ub_223  8
    x_35_8    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_16  1
    w_35_8    product_ub_17  1
    w_35_8    normalized_mass_35_33  1
    w_35_8    normalized_ratio_35_34  -1
    w_35_8    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -3.6000000000000004e-02
    x_35_9    product_lb_18  -2.4901923970053259e-02
    x_35_9    product_ub_19  -4.1376592670473542e-02
    x_35_9    onehot_35_32  1
    x_35_9    stock_lb_222  9
    x_35_9    stock_ub_223  9
    x_35_9    parent_nonstrict_scope_224  0.012
    x_35_9    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_18  1
    w_35_9    product_ub_19  1
    w_35_9    normalized_mass_35_33  1
    w_35_9    normalized_ratio_35_34  -1.125
    w_35_9    full_original_Gini_282  -6.2067460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -0.024
    x_35_10   product_lb_20  -2.4901923970053259e-02
    x_35_10   product_ub_21  -4.1376592670473542e-02
    x_35_10   onehot_35_32  1
    x_35_10   stock_lb_222  10
    x_35_10   stock_ub_223  10
    x_35_10   parent_nonstrict_scope_224  0.024
    x_35_10   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_20  1
    w_35_10   product_ub_21  1
    w_35_10   normalized_mass_35_33  1
    w_35_10   normalized_ratio_35_34  -1.25
    w_35_10   full_original_Gini_282  -9.5817460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -1.1999999999999997e-02
    x_35_11   product_lb_22  -2.4901923970053259e-02
    x_35_11   product_ub_23  -4.1376592670473542e-02
    x_35_11   onehot_35_32  1
    x_35_11   stock_lb_222  11
    x_35_11   stock_ub_223  11
    x_35_11   parent_nonstrict_scope_224  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_22  1
    w_35_11   product_ub_23  1
    w_35_11   normalized_mass_35_33  1
    w_35_11   normalized_ratio_35_34  -1.375
    w_35_11   full_original_Gini_282  -1.2956746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_24  -2.4901923970053259e-02
    x_35_12   product_ub_25  -4.1376592670473542e-02
    x_35_12   onehot_35_32  1
    x_35_12   stock_lb_222  12
    x_35_12   stock_ub_223  12
    x_35_12   parent_nonstrict_scope_224  0.048
    x_35_12   unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_24  1
    w_35_12   product_ub_25  1
    w_35_12   normalized_mass_35_33  1
    w_35_12   normalized_ratio_35_34  -1.5
    w_35_12   full_original_Gini_282  -1.6331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       1.1999999999999997e-02
    x_35_13   product_lb_26  -2.4901923970053259e-02
    x_35_13   product_ub_27  -4.1376592670473542e-02
    x_35_13   onehot_35_32  1
    x_35_13   stock_lb_222  13
    x_35_13   stock_ub_223  13
    x_35_13   parent_nonstrict_scope_224  0.06
    x_35_13   unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_26  1
    w_35_13   product_ub_27  1
    w_35_13   normalized_mass_35_33  1
    w_35_13   normalized_ratio_35_34  -1.625
    w_35_13   full_original_Gini_282  -1.9706746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       2.4000000000000007e-02
    x_35_14   product_lb_28  -2.4901923970053259e-02
    x_35_14   product_ub_29  -4.1376592670473542e-02
    x_35_14   onehot_35_32  1
    x_35_14   stock_lb_222  14
    x_35_14   stock_ub_223  14
    x_35_14   parent_nonstrict_scope_224  7.2000000000000008e-02
    x_35_14   unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_28  1
    w_35_14   product_ub_29  1
    w_35_14   normalized_mass_35_33  1
    w_35_14   normalized_ratio_35_34  -1.75
    w_35_14   full_original_Gini_282  -2.3081746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       3.6000000000000004e-02
    x_35_15   product_lb_30  -2.4901923970053259e-02
    x_35_15   product_ub_31  -4.1376592670473542e-02
    x_35_15   onehot_35_32  1
    x_35_15   stock_lb_222  15
    x_35_15   stock_ub_223  15
    x_35_15   parent_nonstrict_scope_224  0.084
    x_35_15   unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_30  1
    w_35_15   product_ub_31  1
    w_35_15   normalized_mass_35_33  1
    w_35_15   normalized_ratio_35_34  -1.875
    w_35_15   full_original_Gini_282  -2.6456746031746029e+01
    rho_35    normalized_ratio_35_34  1
    rho_35    block_pair_pos_267  -1
    rho_35    block_pair_neg_268  1
    rho_35    block_pair_pos_269  -1
    rho_35    block_pair_neg_270  1
    rho_35    block_pair_pos_271  -1
    rho_35    block_pair_neg_272  1
    rho_35    block_pair_pos_273  -1
    rho_35    block_pair_neg_274  1
    rho_35    block_pair_pos_275  -1
    rho_35    block_pair_neg_276  1
    rho_35    block_pair_pos_277  -1
    rho_35    block_pair_neg_278  1
    rho_35    block_pair_pos_279  -1
    rho_35    block_pair_neg_280  1
    rho_35    normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       0.012
    x_30_0    product_lb_35  -2.4901923970053259e-02
    x_30_0    product_ub_36  -4.1376592670473542e-02
    x_30_0    onehot_30_53  1
    x_30_0    parent_nonstrict_scope_224  0.024
    x_30_0    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_35  1
    w_30_0    product_ub_36  1
    w_30_0    normalized_mass_30_54  1
    w_30_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       6.0000000000000019e-03
    x_30_1    product_lb_37  -2.4901923970053259e-02
    x_30_1    product_ub_38  -4.1376592670473542e-02
    x_30_1    onehot_30_53  1
    x_30_1    stock_lb_222  1
    x_30_1    stock_ub_223  1
    x_30_1    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_30_1    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_37  1
    w_30_1    product_ub_38  1
    w_30_1    normalized_mass_30_54  1
    w_30_1    normalized_ratio_30_55  -0.25
    w_30_1    full_original_Gini_282  -1.7418253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_39  -2.4901923970053259e-02
    x_30_2    product_ub_40  -4.1376592670473542e-02
    x_30_2    onehot_30_53  1
    x_30_2    stock_lb_222  2
    x_30_2    stock_ub_223  2
    x_30_2    parent_nonstrict_scope_224  0.012
    x_30_2    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_39  1
    w_30_2    product_ub_40  1
    w_30_2    normalized_mass_30_54  1
    w_30_2    normalized_ratio_30_55  -0.5
    w_30_2    full_original_Gini_282  -1.0668253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -0.006
    x_30_3    product_lb_41  -2.4901923970053259e-02
    x_30_3    product_ub_42  -4.1376592670473542e-02
    x_30_3    onehot_30_53  1
    x_30_3    stock_lb_222  3
    x_30_3    stock_ub_223  3
    x_30_3    parent_nonstrict_scope_224  0.006
    x_30_3    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_41  1
    w_30_3    product_ub_42  1
    w_30_3    normalized_mass_30_54  1
    w_30_3    normalized_ratio_30_55  -0.75
    w_30_3    full_original_Gini_282  -4.7325396825396808e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -0.012
    x_30_4    product_lb_43  -2.4901923970053259e-02
    x_30_4    product_ub_44  -4.1376592670473542e-02
    x_30_4    onehot_30_53  1
    x_30_4    stock_lb_222  4
    x_30_4    stock_ub_223  4
    x_30_4    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_43  1
    w_30_4    product_ub_44  1
    w_30_4    normalized_mass_30_54  1
    w_30_4    normalized_ratio_30_55  -1
    w_30_4    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -0.006
    x_30_5    product_lb_45  -2.4901923970053259e-02
    x_30_5    product_ub_46  -4.1376592670473542e-02
    x_30_5    onehot_30_53  1
    x_30_5    stock_lb_222  5
    x_30_5    stock_ub_223  5
    x_30_5    parent_nonstrict_scope_224  0.006
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_45  1
    w_30_5    product_ub_46  1
    w_30_5    normalized_mass_30_54  1
    w_30_5    normalized_ratio_30_55  -1.25
    w_30_5    full_original_Gini_282  -9.5817460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_47  -2.4901923970053259e-02
    x_30_6    product_ub_48  -4.1376592670473542e-02
    x_30_6    onehot_30_53  1
    x_30_6    stock_lb_222  6
    x_30_6    stock_ub_223  6
    x_30_6    parent_nonstrict_scope_224  0.012
    x_30_6    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_47  1
    w_30_6    product_ub_48  1
    w_30_6    normalized_mass_30_54  1
    w_30_6    normalized_ratio_30_55  -1.5
    w_30_6    full_original_Gini_282  -1.6331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       6.0000000000000019e-03
    x_30_7    product_lb_49  -2.4901923970053259e-02
    x_30_7    product_ub_50  -4.1376592670473542e-02
    x_30_7    onehot_30_53  1
    x_30_7    stock_lb_222  7
    x_30_7    stock_ub_223  7
    x_30_7    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_30_7    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_49  1
    w_30_7    product_ub_50  1
    w_30_7    normalized_mass_30_54  1
    w_30_7    normalized_ratio_30_55  -1.75
    w_30_7    full_original_Gini_282  -2.3081746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       0.012
    x_30_8    product_lb_51  -2.4901923970053259e-02
    x_30_8    product_ub_52  -4.1376592670473542e-02
    x_30_8    onehot_30_53  1
    x_30_8    stock_lb_222  8
    x_30_8    stock_ub_223  8
    x_30_8    parent_nonstrict_scope_224  0.024
    x_30_8    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_51  1
    w_30_8    product_ub_52  1
    w_30_8    normalized_mass_30_54  1
    w_30_8    normalized_ratio_30_55  -2
    w_30_8    full_original_Gini_282  -2.9831746031746029e+01
    rho_30    normalized_ratio_30_55  1
    rho_30    block_pair_pos_237  -1
    rho_30    block_pair_neg_238  1
    rho_30    block_pair_pos_239  -1
    rho_30    block_pair_neg_240  1
    rho_30    block_pair_pos_241  -1
    rho_30    block_pair_neg_242  1
    rho_30    block_pair_pos_243  -1
    rho_30    block_pair_neg_244  1
    rho_30    block_pair_pos_245  -1
    rho_30    block_pair_neg_246  1
    rho_30    block_pair_pos_247  -1
    rho_30    block_pair_neg_248  1
    rho_30    block_pair_pos_275  1
    rho_30    block_pair_neg_276  -1
    rho_30    normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_56  -2.4901923970053259e-02
    x_31_0    product_ub_57  -4.1376592670473542e-02
    x_31_0    onehot_31_82  1
    x_31_0    parent_nonstrict_scope_224  0.0735
    x_31_0    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_56  1
    w_31_0    product_ub_57  1
    w_31_0    normalized_mass_31_83  1
    w_31_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_58  -2.4901923970053259e-02
    x_31_1    product_ub_59  -4.1376592670473542e-02
    x_31_1    onehot_31_82  1
    x_31_1    stock_lb_222  1
    x_31_1    stock_ub_223  1
    x_31_1    parent_nonstrict_scope_224  0.063
    x_31_1    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_58  1
    w_31_1    product_ub_59  1
    w_31_1    normalized_mass_31_83  1
    w_31_1    normalized_ratio_31_84  -1.4285714285714285e-01
    w_31_1    full_original_Gini_282  -2.0311111111111121e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_60  -2.4901923970053259e-02
    x_31_2    product_ub_61  -4.1376592670473542e-02
    x_31_2    onehot_31_82  1
    x_31_2    stock_lb_222  2
    x_31_2    stock_ub_223  2
    x_31_2    parent_nonstrict_scope_224  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_60  1
    w_31_2    product_ub_61  1
    w_31_2    normalized_mass_31_83  1
    w_31_2    normalized_ratio_31_84  -2.8571428571428570e-01
    w_31_2    full_original_Gini_282  -1.6453968253968245e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_62  -2.4901923970053259e-02
    x_31_3    product_ub_63  -4.1376592670473542e-02
    x_31_3    onehot_31_82  1
    x_31_3    stock_lb_222  3
    x_31_3    stock_ub_223  3
    x_31_3    parent_nonstrict_scope_224  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_62  1
    w_31_3    product_ub_63  1
    w_31_3    normalized_mass_31_83  1
    w_31_3    normalized_ratio_31_84  -4.2857142857142855e-01
    w_31_3    full_original_Gini_282  -1.2596825396825395e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_64  -2.4901923970053259e-02
    x_31_4    product_ub_65  -4.1376592670473542e-02
    x_31_4    onehot_31_82  1
    x_31_4    stock_lb_222  4
    x_31_4    stock_ub_223  4
    x_31_4    parent_nonstrict_scope_224  0.0315
    x_31_4    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_64  1
    w_31_4    product_ub_65  1
    w_31_4    normalized_mass_31_83  1
    w_31_4    normalized_ratio_31_84  -5.7142857142857140e-01
    w_31_4    full_original_Gini_282  -8.73968253968254
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_66  -2.4901923970053259e-02
    x_31_5    product_ub_67  -4.1376592670473542e-02
    x_31_5    onehot_31_82  1
    x_31_5    stock_lb_222  5
    x_31_5    stock_ub_223  5
    x_31_5    parent_nonstrict_scope_224  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_66  1
    w_31_5    product_ub_67  1
    w_31_5    normalized_mass_31_83  1
    w_31_5    normalized_ratio_31_84  -7.1428571428571419e-01
    w_31_5    full_original_Gini_282  -5.3396825396825394e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_68  -2.4901923970053259e-02
    x_31_6    product_ub_69  -4.1376592670473542e-02
    x_31_6    onehot_31_82  1
    x_31_6    stock_lb_222  6
    x_31_6    stock_ub_223  6
    x_31_6    parent_nonstrict_scope_224  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_68  1
    w_31_6    product_ub_69  1
    w_31_6    normalized_mass_31_83  1
    w_31_6    normalized_ratio_31_84  -8.5714285714285710e-01
    w_31_6    full_original_Gini_282  -3.3873015873015864e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_70  -2.4901923970053259e-02
    x_31_7    product_ub_71  -4.1376592670473542e-02
    x_31_7    onehot_31_82  1
    x_31_7    stock_lb_222  7
    x_31_7    stock_ub_223  7
    x_31_7    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_70  1
    w_31_7    product_ub_71  1
    w_31_7    normalized_mass_31_83  1
    w_31_7    normalized_ratio_31_84  -1
    w_31_7    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_72  -2.4901923970053259e-02
    x_31_8    product_ub_73  -4.1376592670473542e-02
    x_31_8    onehot_31_82  1
    x_31_8    stock_lb_222  8
    x_31_8    stock_ub_223  8
    x_31_8    parent_nonstrict_scope_224  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_72  1
    w_31_8    product_ub_73  1
    w_31_8    normalized_mass_31_83  1
    w_31_8    normalized_ratio_31_84  -1.1428571428571428e+00
    w_31_8    full_original_Gini_282  -6.6888888888888864e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_74  -2.4901923970053259e-02
    x_31_9    product_ub_75  -4.1376592670473542e-02
    x_31_9    onehot_31_82  1
    x_31_9    stock_lb_222  9
    x_31_9    stock_ub_223  9
    x_31_9    parent_nonstrict_scope_224  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_74  1
    w_31_9    product_ub_75  1
    w_31_9    normalized_mass_31_83  1
    w_31_9    normalized_ratio_31_84  -1.2857142857142856e+00
    w_31_9    full_original_Gini_282  -1.0546031746031741e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_76  -2.4901923970053259e-02
    x_31_10   product_ub_77  -4.1376592670473542e-02
    x_31_10   onehot_31_82  1
    x_31_10   stock_lb_222  10
    x_31_10   stock_ub_223  10
    x_31_10   parent_nonstrict_scope_224  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_76  1
    w_31_10   product_ub_77  1
    w_31_10   normalized_mass_31_83  1
    w_31_10   normalized_ratio_31_84  -1.4285714285714284e+00
    w_31_10   full_original_Gini_282  -1.4403174603174602e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_78  -2.4901923970053259e-02
    x_31_11   product_ub_79  -4.1376592670473542e-02
    x_31_11   onehot_31_82  1
    x_31_11   stock_lb_222  11
    x_31_11   stock_ub_223  11
    x_31_11   parent_nonstrict_scope_224  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_78  1
    w_31_11   product_ub_79  1
    w_31_11   normalized_mass_31_83  1
    w_31_11   normalized_ratio_31_84  -1.5714285714285714e+00
    w_31_11   full_original_Gini_282  -1.8260317460317459e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_80  -2.4901923970053259e-02
    x_31_12   product_ub_81  -4.1376592670473542e-02
    x_31_12   onehot_31_82  1
    x_31_12   stock_lb_222  12
    x_31_12   stock_ub_223  12
    x_31_12   parent_nonstrict_scope_224  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_80  1
    w_31_12   product_ub_81  1
    w_31_12   normalized_mass_31_83  1
    w_31_12   normalized_ratio_31_84  -1.7142857142857142e+00
    w_31_12   full_original_Gini_282  -2.2117460317460321e+01
    rho_31    normalized_ratio_31_84  1
    rho_31    block_pair_pos_245  1
    rho_31    block_pair_neg_246  -1
    rho_31    block_pair_pos_249  -1
    rho_31    block_pair_neg_250  1
    rho_31    block_pair_pos_251  -1
    rho_31    block_pair_neg_252  1
    rho_31    block_pair_pos_253  -1
    rho_31    block_pair_neg_254  1
    rho_31    block_pair_pos_255  -1
    rho_31    block_pair_neg_256  1
    rho_31    block_pair_pos_257  -1
    rho_31    block_pair_neg_258  1
    rho_31    block_pair_pos_277  1
    rho_31    block_pair_neg_278  -1
    rho_31    normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_85  -2.4901923970053259e-02
    x_32_0    product_ub_86  -4.1376592670473542e-02
    x_32_0    onehot_32_111  1
    x_32_0    parent_nonstrict_scope_224  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_85  1
    w_32_0    product_ub_86  1
    w_32_0    normalized_mass_32_112  1
    w_32_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_87  -2.4901923970053259e-02
    x_32_1    product_ub_88  -4.1376592670473542e-02
    x_32_1    onehot_32_111  1
    x_32_1    stock_lb_222  1
    x_32_1    stock_ub_223  1
    x_32_1    parent_nonstrict_scope_224  0.03
    x_32_1    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_87  1
    w_32_1    product_ub_88  1
    w_32_1    normalized_mass_32_112  1
    w_32_1    normalized_ratio_32_113  -0.2
    w_32_1    full_original_Gini_282  -1.8768253968253973e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_89  -2.4901923970053259e-02
    x_32_2    product_ub_90  -4.1376592670473542e-02
    x_32_2    onehot_32_111  1
    x_32_2    stock_lb_222  2
    x_32_2    stock_ub_223  2
    x_32_2    parent_nonstrict_scope_224  0.0225
    x_32_2    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_89  1
    w_32_2    product_ub_90  1
    w_32_2    normalized_mass_32_112  1
    w_32_2    normalized_ratio_32_113  -0.4
    w_32_2    full_original_Gini_282  -1.3368253968253965e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_91  -2.4901923970053259e-02
    x_32_3    product_ub_92  -4.1376592670473542e-02
    x_32_3    onehot_32_111  1
    x_32_3    stock_lb_222  3
    x_32_3    stock_ub_223  3
    x_32_3    parent_nonstrict_scope_224  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_91  1
    w_32_3    product_ub_92  1
    w_32_3    normalized_mass_32_112  1
    w_32_3    normalized_ratio_32_113  -6.0000000000000009e-01
    w_32_3    full_original_Gini_282  -7.9682539682539684e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_93  -2.4901923970053259e-02
    x_32_4    product_ub_94  -4.1376592670473542e-02
    x_32_4    onehot_32_111  1
    x_32_4    stock_lb_222  4
    x_32_4    stock_ub_223  4
    x_32_4    parent_nonstrict_scope_224  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_93  1
    w_32_4    product_ub_94  1
    w_32_4    normalized_mass_32_112  1
    w_32_4    normalized_ratio_32_113  -0.8
    w_32_4    full_original_Gini_282  -4.0825396825396822e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_95  -2.4901923970053259e-02
    x_32_5    product_ub_96  -4.1376592670473542e-02
    x_32_5    onehot_32_111  1
    x_32_5    stock_lb_222  5
    x_32_5    stock_ub_223  5
    x_32_5    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_95  1
    w_32_5    product_ub_96  1
    w_32_5    normalized_mass_32_112  1
    w_32_5    normalized_ratio_32_113  -1
    w_32_5    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_97  -2.4901923970053259e-02
    x_32_6    product_ub_98  -4.1376592670473542e-02
    x_32_6    onehot_32_111  1
    x_32_6    stock_lb_222  6
    x_32_6    stock_ub_223  6
    x_32_6    parent_nonstrict_scope_224  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_97  1
    w_32_6    product_ub_98  1
    w_32_6    normalized_mass_32_112  1
    w_32_6    normalized_ratio_32_113  -1.2000000000000002e+00
    w_32_6    full_original_Gini_282  -8.2317460317460363e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_99  -2.4901923970053259e-02
    x_32_7    product_ub_100  -4.1376592670473542e-02
    x_32_7    onehot_32_111  1
    x_32_7    stock_lb_222  7
    x_32_7    stock_ub_223  7
    x_32_7    parent_nonstrict_scope_224  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_99  1
    w_32_7    product_ub_100  1
    w_32_7    normalized_mass_32_112  1
    w_32_7    normalized_ratio_32_113  -1.4000000000000001e+00
    w_32_7    full_original_Gini_282  -1.3631746031746037e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_101  -2.4901923970053259e-02
    x_32_8    product_ub_102  -4.1376592670473542e-02
    x_32_8    onehot_32_111  1
    x_32_8    stock_lb_222  8
    x_32_8    stock_ub_223  8
    x_32_8    parent_nonstrict_scope_224  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_101  1
    w_32_8    product_ub_102  1
    w_32_8    normalized_mass_32_112  1
    w_32_8    normalized_ratio_32_113  -1.6
    w_32_8    full_original_Gini_282  -1.9031746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_103  -2.4901923970053259e-02
    x_32_9    product_ub_104  -4.1376592670473542e-02
    x_32_9    onehot_32_111  1
    x_32_9    stock_lb_222  9
    x_32_9    stock_ub_223  9
    x_32_9    parent_nonstrict_scope_224  0.03
    x_32_9    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_103  1
    w_32_9    product_ub_104  1
    w_32_9    normalized_mass_32_112  1
    w_32_9    normalized_ratio_32_113  -1.8
    w_32_9    full_original_Gini_282  -2.4431746031746037e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_105  -2.4901923970053259e-02
    x_32_10   product_ub_106  -4.1376592670473542e-02
    x_32_10   onehot_32_111  1
    x_32_10   stock_lb_222  10
    x_32_10   stock_ub_223  10
    x_32_10   parent_nonstrict_scope_224  0.0375
    x_32_10   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_105  1
    w_32_10   product_ub_106  1
    w_32_10   normalized_mass_32_112  1
    w_32_10   normalized_ratio_32_113  -2
    w_32_10   full_original_Gini_282  -2.9831746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_107  -2.4901923970053259e-02
    x_32_11   product_ub_108  -4.1376592670473542e-02
    x_32_11   onehot_32_111  1
    x_32_11   stock_lb_222  11
    x_32_11   stock_ub_223  11
    x_32_11   parent_nonstrict_scope_224  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_107  1
    w_32_11   product_ub_108  1
    w_32_11   normalized_mass_32_112  1
    w_32_11   normalized_ratio_32_113  -2.2
    w_32_11   full_original_Gini_282  -3.5231746031746034e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_109  -2.4901923970053259e-02
    x_32_12   product_ub_110  -4.1376592670473542e-02
    x_32_12   onehot_32_111  1
    x_32_12   stock_lb_222  12
    x_32_12   stock_ub_223  12
    x_32_12   parent_nonstrict_scope_224  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_109  1
    w_32_12   product_ub_110  1
    w_32_12   normalized_mass_32_112  1
    w_32_12   normalized_ratio_32_113  -2.4000000000000004e+00
    w_32_12   full_original_Gini_282  -4.0631746031746019e+01
    rho_32    normalized_ratio_32_113  1
    rho_32    block_pair_pos_247  1
    rho_32    block_pair_neg_248  -1
    rho_32    block_pair_pos_257  1
    rho_32    block_pair_neg_258  -1
    rho_32    block_pair_pos_259  -1
    rho_32    block_pair_neg_260  1
    rho_32    block_pair_pos_261  -1
    rho_32    block_pair_neg_262  1
    rho_32    block_pair_pos_263  -1
    rho_32    block_pair_neg_264  1
    rho_32    block_pair_pos_265  -1
    rho_32    block_pair_neg_266  1
    rho_32    block_pair_pos_279  1
    rho_32    block_pair_neg_280  -1
    rho_32    normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_114  -2.4901923970053259e-02
    x_16_0    product_ub_115  -4.1376592670473542e-02
    x_16_0    onehot_16_140  1
    x_16_0    parent_nonstrict_scope_224  0.054
    x_16_0    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_114  1
    w_16_0    product_ub_115  1
    w_16_0    normalized_mass_16_141  1
    w_16_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_116  -2.4901923970053259e-02
    x_16_1    product_ub_117  -4.1376592670473542e-02
    x_16_1    onehot_16_140  1
    x_16_1    stock_lb_222  1
    x_16_1    stock_ub_223  1
    x_16_1    parent_nonstrict_scope_224  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_116  1
    w_16_1    product_ub_117  1
    w_16_1    normalized_mass_16_141  1
    w_16_1    normalized_ratio_16_142  -1.6666666666666666e-01
    w_16_1    full_original_Gini_282  -1.9668253968253968e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_118  -2.4901923970053259e-02
    x_16_2    product_ub_119  -4.1376592670473542e-02
    x_16_2    onehot_16_140  1
    x_16_2    stock_lb_222  2
    x_16_2    stock_ub_223  2
    x_16_2    parent_nonstrict_scope_224  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_118  1
    w_16_2    product_ub_119  1
    w_16_2    normalized_mass_16_141  1
    w_16_2    normalized_ratio_16_142  -3.3333333333333331e-01
    w_16_2    full_original_Gini_282  -1.5168253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_120  -2.4901923970053259e-02
    x_16_3    product_ub_121  -4.1376592670473542e-02
    x_16_3    onehot_16_140  1
    x_16_3    stock_lb_222  3
    x_16_3    stock_ub_223  3
    x_16_3    parent_nonstrict_scope_224  0.027
    x_16_3    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_120  1
    w_16_3    product_ub_121  1
    w_16_3    normalized_mass_16_141  1
    w_16_3    normalized_ratio_16_142  -0.5
    w_16_3    full_original_Gini_282  -1.0668253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_122  -2.4901923970053259e-02
    x_16_4    product_ub_123  -4.1376592670473542e-02
    x_16_4    onehot_16_140  1
    x_16_4    stock_lb_222  4
    x_16_4    stock_ub_223  4
    x_16_4    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_122  1
    w_16_4    product_ub_123  1
    w_16_4    normalized_mass_16_141  1
    w_16_4    normalized_ratio_16_142  -6.6666666666666663e-01
    w_16_4    full_original_Gini_282  -6.4349206349206334e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_124  -2.4901923970053259e-02
    x_16_5    product_ub_125  -4.1376592670473542e-02
    x_16_5    onehot_16_140  1
    x_16_5    stock_lb_222  5
    x_16_5    stock_ub_223  5
    x_16_5    parent_nonstrict_scope_224  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_124  1
    w_16_5    product_ub_125  1
    w_16_5    normalized_mass_16_141  1
    w_16_5    normalized_ratio_16_142  -8.3333333333333326e-01
    w_16_5    full_original_Gini_282  -3.6492063492063505e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_126  -2.4901923970053259e-02
    x_16_6    product_ub_127  -4.1376592670473542e-02
    x_16_6    onehot_16_140  1
    x_16_6    stock_lb_222  6
    x_16_6    stock_ub_223  6
    x_16_6    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_126  1
    w_16_6    product_ub_127  1
    w_16_6    normalized_mass_16_141  1
    w_16_6    normalized_ratio_16_142  -1
    w_16_6    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_128  -2.4901923970053259e-02
    x_16_7    product_ub_129  -4.1376592670473542e-02
    x_16_7    onehot_16_140  1
    x_16_7    stock_lb_222  7
    x_16_7    stock_ub_223  7
    x_16_7    parent_nonstrict_scope_224  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_128  1
    w_16_7    product_ub_129  1
    w_16_7    normalized_mass_16_141  1
    w_16_7    normalized_ratio_16_142  -1.1666666666666665e+00
    w_16_7    full_original_Gini_282  -7.3317460317460270e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_130  -2.4901923970053259e-02
    x_16_8    product_ub_131  -4.1376592670473542e-02
    x_16_8    onehot_16_140  1
    x_16_8    stock_lb_222  8
    x_16_8    stock_ub_223  8
    x_16_8    parent_nonstrict_scope_224  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_130  1
    w_16_8    product_ub_131  1
    w_16_8    normalized_mass_16_141  1
    w_16_8    normalized_ratio_16_142  -1.3333333333333333e+00
    w_16_8    full_original_Gini_282  -1.1831746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_132  -2.4901923970053259e-02
    x_16_9    product_ub_133  -4.1376592670473542e-02
    x_16_9    onehot_16_140  1
    x_16_9    stock_lb_222  9
    x_16_9    stock_ub_223  9
    x_16_9    parent_nonstrict_scope_224  0.027
    x_16_9    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_132  1
    w_16_9    product_ub_133  1
    w_16_9    normalized_mass_16_141  1
    w_16_9    normalized_ratio_16_142  -1.5
    w_16_9    full_original_Gini_282  -1.6331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_134  -2.4901923970053259e-02
    x_16_10   product_ub_135  -4.1376592670473542e-02
    x_16_10   onehot_16_140  1
    x_16_10   stock_lb_222  10
    x_16_10   stock_ub_223  10
    x_16_10   parent_nonstrict_scope_224  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_134  1
    w_16_10   product_ub_135  1
    w_16_10   normalized_mass_16_141  1
    w_16_10   normalized_ratio_16_142  -1.6666666666666665e+00
    w_16_10   full_original_Gini_282  -2.0831746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_136  -2.4901923970053259e-02
    x_16_11   product_ub_137  -4.1376592670473542e-02
    x_16_11   onehot_16_140  1
    x_16_11   stock_lb_222  11
    x_16_11   stock_ub_223  11
    x_16_11   parent_nonstrict_scope_224  0.045
    x_16_11   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_136  1
    w_16_11   product_ub_137  1
    w_16_11   normalized_mass_16_141  1
    w_16_11   normalized_ratio_16_142  -1.8333333333333333e+00
    w_16_11   full_original_Gini_282  -2.5331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_138  -2.4901923970053259e-02
    x_16_12   product_ub_139  -4.1376592670473542e-02
    x_16_12   onehot_16_140  1
    x_16_12   stock_lb_222  12
    x_16_12   stock_ub_223  12
    x_16_12   parent_nonstrict_scope_224  0.054
    x_16_12   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_138  1
    w_16_12   product_ub_139  1
    w_16_12   normalized_mass_16_141  1
    w_16_12   normalized_ratio_16_142  -2
    w_16_12   full_original_Gini_282  -2.9831746031746029e+01
    rho_16    normalized_ratio_16_142  1
    rho_16    block_pair_pos_227  -1
    rho_16    block_pair_neg_228  1
    rho_16    block_pair_pos_229  -1
    rho_16    block_pair_neg_230  1
    rho_16    block_pair_pos_231  -1
    rho_16    block_pair_neg_232  1
    rho_16    block_pair_pos_239  1
    rho_16    block_pair_neg_240  -1
    rho_16    block_pair_pos_251  1
    rho_16    block_pair_neg_252  -1
    rho_16    block_pair_pos_261  1
    rho_16    block_pair_neg_262  -1
    rho_16    block_pair_pos_269  1
    rho_16    block_pair_neg_270  -1
    rho_16    normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       0.012
    x_26_0    product_lb_143  -2.4901923970053259e-02
    x_26_0    product_ub_144  -4.1376592670473542e-02
    x_26_0    onehot_26_161  1
    x_26_0    parent_nonstrict_scope_224  0.024
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_143  1
    w_26_0    product_ub_144  1
    w_26_0    normalized_mass_26_162  1
    w_26_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       6.0000000000000019e-03
    x_26_1    product_lb_145  -2.4901923970053259e-02
    x_26_1    product_ub_146  -4.1376592670473542e-02
    x_26_1    onehot_26_161  1
    x_26_1    stock_lb_222  1
    x_26_1    stock_ub_223  1
    x_26_1    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_26_1    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_145  1
    w_26_1    product_ub_146  1
    w_26_1    normalized_mass_26_162  1
    w_26_1    normalized_ratio_26_163  -0.25
    w_26_1    full_original_Gini_282  -1.7418253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_147  -2.4901923970053259e-02
    x_26_2    product_ub_148  -4.1376592670473542e-02
    x_26_2    onehot_26_161  1
    x_26_2    stock_lb_222  2
    x_26_2    stock_ub_223  2
    x_26_2    parent_nonstrict_scope_224  0.012
    x_26_2    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_147  1
    w_26_2    product_ub_148  1
    w_26_2    normalized_mass_26_162  1
    w_26_2    normalized_ratio_26_163  -0.5
    w_26_2    full_original_Gini_282  -1.0668253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -0.006
    x_26_3    product_lb_149  -2.4901923970053259e-02
    x_26_3    product_ub_150  -4.1376592670473542e-02
    x_26_3    onehot_26_161  1
    x_26_3    stock_lb_222  3
    x_26_3    stock_ub_223  3
    x_26_3    parent_nonstrict_scope_224  0.006
    x_26_3    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_149  1
    w_26_3    product_ub_150  1
    w_26_3    normalized_mass_26_162  1
    w_26_3    normalized_ratio_26_163  -0.75
    w_26_3    full_original_Gini_282  -4.7325396825396808e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -0.012
    x_26_4    product_lb_151  -2.4901923970053259e-02
    x_26_4    product_ub_152  -4.1376592670473542e-02
    x_26_4    onehot_26_161  1
    x_26_4    stock_lb_222  4
    x_26_4    stock_ub_223  4
    x_26_4    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_151  1
    w_26_4    product_ub_152  1
    w_26_4    normalized_mass_26_162  1
    w_26_4    normalized_ratio_26_163  -1
    w_26_4    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -0.006
    x_26_5    product_lb_153  -2.4901923970053259e-02
    x_26_5    product_ub_154  -4.1376592670473542e-02
    x_26_5    onehot_26_161  1
    x_26_5    stock_lb_222  5
    x_26_5    stock_ub_223  5
    x_26_5    parent_nonstrict_scope_224  0.006
    x_26_5    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_153  1
    w_26_5    product_ub_154  1
    w_26_5    normalized_mass_26_162  1
    w_26_5    normalized_ratio_26_163  -1.25
    w_26_5    full_original_Gini_282  -9.5817460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_155  -2.4901923970053259e-02
    x_26_6    product_ub_156  -4.1376592670473542e-02
    x_26_6    onehot_26_161  1
    x_26_6    stock_lb_222  6
    x_26_6    stock_ub_223  6
    x_26_6    parent_nonstrict_scope_224  0.012
    x_26_6    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_155  1
    w_26_6    product_ub_156  1
    w_26_6    normalized_mass_26_162  1
    w_26_6    normalized_ratio_26_163  -1.5
    w_26_6    full_original_Gini_282  -1.6331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       6.0000000000000019e-03
    x_26_7    product_lb_157  -2.4901923970053259e-02
    x_26_7    product_ub_158  -4.1376592670473542e-02
    x_26_7    onehot_26_161  1
    x_26_7    stock_lb_222  7
    x_26_7    stock_ub_223  7
    x_26_7    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_26_7    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_157  1
    w_26_7    product_ub_158  1
    w_26_7    normalized_mass_26_162  1
    w_26_7    normalized_ratio_26_163  -1.75
    w_26_7    full_original_Gini_282  -2.3081746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       0.012
    x_26_8    product_lb_159  -2.4901923970053259e-02
    x_26_8    product_ub_160  -4.1376592670473542e-02
    x_26_8    onehot_26_161  1
    x_26_8    stock_lb_222  8
    x_26_8    stock_ub_223  8
    x_26_8    parent_nonstrict_scope_224  0.024
    x_26_8    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_159  1
    w_26_8    product_ub_160  1
    w_26_8    normalized_mass_26_162  1
    w_26_8    normalized_ratio_26_163  -2
    w_26_8    full_original_Gini_282  -2.9831746031746029e+01
    rho_26    normalized_ratio_26_163  1
    rho_26    block_pair_pos_231  1
    rho_26    block_pair_neg_232  -1
    rho_26    block_pair_pos_233  -1
    rho_26    block_pair_neg_234  1
    rho_26    block_pair_pos_235  -1
    rho_26    block_pair_neg_236  1
    rho_26    block_pair_pos_243  1
    rho_26    block_pair_neg_244  -1
    rho_26    block_pair_pos_255  1
    rho_26    block_pair_neg_256  -1
    rho_26    block_pair_pos_265  1
    rho_26    block_pair_neg_266  -1
    rho_26    block_pair_pos_273  1
    rho_26    block_pair_neg_274  -1
    rho_26    normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_164  -2.4901923970053259e-02
    x_5_0     product_ub_165  -4.1376592670473542e-02
    x_5_0     onehot_5_198  1
    x_5_0     parent_nonstrict_scope_224  0.096
    x_5_0     unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_164  1
    w_5_0     product_ub_165  1
    w_5_0     normalized_mass_5_199  1
    w_5_0     full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_166  -2.4901923970053259e-02
    x_5_1     product_ub_167  -4.1376592670473542e-02
    x_5_1     onehot_5_198  1
    x_5_1     stock_lb_222  1
    x_5_1     stock_ub_223  1
    x_5_1     parent_nonstrict_scope_224  0.084
    x_5_1     unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_166  1
    w_5_1     product_ub_167  1
    w_5_1     normalized_mass_5_199  1
    w_5_1     normalized_ratio_5_200  -0.125
    w_5_1     full_original_Gini_282  -2.0793253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_168  -2.4901923970053259e-02
    x_5_2     product_ub_169  -4.1376592670473542e-02
    x_5_2     onehot_5_198  1
    x_5_2     stock_lb_222  2
    x_5_2     stock_ub_223  2
    x_5_2     parent_nonstrict_scope_224  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_168  1
    w_5_2     product_ub_169  1
    w_5_2     normalized_mass_5_199  1
    w_5_2     normalized_ratio_5_200  -0.25
    w_5_2     full_original_Gini_282  -1.7418253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_170  -2.4901923970053259e-02
    x_5_3     product_ub_171  -4.1376592670473542e-02
    x_5_3     onehot_5_198  1
    x_5_3     stock_lb_222  3
    x_5_3     stock_ub_223  3
    x_5_3     parent_nonstrict_scope_224  0.06
    x_5_3     unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_170  1
    w_5_3     product_ub_171  1
    w_5_3     normalized_mass_5_199  1
    w_5_3     normalized_ratio_5_200  -0.375
    w_5_3     full_original_Gini_282  -1.4043253968253968e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_172  -2.4901923970053259e-02
    x_5_4     product_ub_173  -4.1376592670473542e-02
    x_5_4     onehot_5_198  1
    x_5_4     stock_lb_222  4
    x_5_4     stock_ub_223  4
    x_5_4     parent_nonstrict_scope_224  0.048
    x_5_4     unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_172  1
    w_5_4     product_ub_173  1
    w_5_4     normalized_mass_5_199  1
    w_5_4     normalized_ratio_5_200  -0.5
    w_5_4     full_original_Gini_282  -1.0668253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_174  -2.4901923970053259e-02
    x_5_5     product_ub_175  -4.1376592670473542e-02
    x_5_5     onehot_5_198  1
    x_5_5     stock_lb_222  5
    x_5_5     stock_ub_223  5
    x_5_5     parent_nonstrict_scope_224  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_174  1
    w_5_5     product_ub_175  1
    w_5_5     normalized_mass_5_199  1
    w_5_5     normalized_ratio_5_200  -0.625
    w_5_5     full_original_Gini_282  -7.3932539682539673e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_176  -2.4901923970053259e-02
    x_5_6     product_ub_177  -4.1376592670473542e-02
    x_5_6     onehot_5_198  1
    x_5_6     stock_lb_222  6
    x_5_6     stock_ub_223  6
    x_5_6     parent_nonstrict_scope_224  0.024
    x_5_6     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_176  1
    w_5_6     product_ub_177  1
    w_5_6     normalized_mass_5_199  1
    w_5_6     normalized_ratio_5_200  -0.75
    w_5_6     full_original_Gini_282  -4.7325396825396808e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_178  -2.4901923970053259e-02
    x_5_7     product_ub_179  -4.1376592670473542e-02
    x_5_7     onehot_5_198  1
    x_5_7     stock_lb_222  7
    x_5_7     stock_ub_223  7
    x_5_7     parent_nonstrict_scope_224  0.012
    x_5_7     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_178  1
    w_5_7     product_ub_179  1
    w_5_7     normalized_mass_5_199  1
    w_5_7     normalized_ratio_5_200  -0.875
    w_5_7     full_original_Gini_282  -3.2623015873015873e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_180  -2.4901923970053259e-02
    x_5_8     product_ub_181  -4.1376592670473542e-02
    x_5_8     onehot_5_198  1
    x_5_8     stock_lb_222  8
    x_5_8     stock_ub_223  8
    x_5_8     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_180  1
    w_5_8     product_ub_181  1
    w_5_8     normalized_mass_5_199  1
    w_5_8     normalized_ratio_5_200  -1
    w_5_8     full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_182  -2.4901923970053259e-02
    x_5_9     product_ub_183  -4.1376592670473542e-02
    x_5_9     onehot_5_198  1
    x_5_9     stock_lb_222  9
    x_5_9     stock_ub_223  9
    x_5_9     parent_nonstrict_scope_224  0.012
    x_5_9     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_182  1
    w_5_9     product_ub_183  1
    w_5_9     normalized_mass_5_199  1
    w_5_9     normalized_ratio_5_200  -1.125
    w_5_9     full_original_Gini_282  -6.2067460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_184  -2.4901923970053259e-02
    x_5_10    product_ub_185  -4.1376592670473542e-02
    x_5_10    onehot_5_198  1
    x_5_10    stock_lb_222  10
    x_5_10    stock_ub_223  10
    x_5_10    parent_nonstrict_scope_224  0.024
    x_5_10    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_184  1
    w_5_10    product_ub_185  1
    w_5_10    normalized_mass_5_199  1
    w_5_10    normalized_ratio_5_200  -1.25
    w_5_10    full_original_Gini_282  -9.5817460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_186  -2.4901923970053259e-02
    x_5_11    product_ub_187  -4.1376592670473542e-02
    x_5_11    onehot_5_198  1
    x_5_11    stock_lb_222  11
    x_5_11    stock_ub_223  11
    x_5_11    parent_nonstrict_scope_224  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_186  1
    w_5_11    product_ub_187  1
    w_5_11    normalized_mass_5_199  1
    w_5_11    normalized_ratio_5_200  -1.375
    w_5_11    full_original_Gini_282  -1.2956746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_188  -2.4901923970053259e-02
    x_5_12    product_ub_189  -4.1376592670473542e-02
    x_5_12    onehot_5_198  1
    x_5_12    stock_lb_222  12
    x_5_12    stock_ub_223  12
    x_5_12    parent_nonstrict_scope_224  0.048
    x_5_12    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_188  1
    w_5_12    product_ub_189  1
    w_5_12    normalized_mass_5_199  1
    w_5_12    normalized_ratio_5_200  -1.5
    w_5_12    full_original_Gini_282  -1.6331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_190  -2.4901923970053259e-02
    x_5_13    product_ub_191  -4.1376592670473542e-02
    x_5_13    onehot_5_198  1
    x_5_13    stock_lb_222  13
    x_5_13    stock_ub_223  13
    x_5_13    parent_nonstrict_scope_224  0.06
    x_5_13    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_190  1
    w_5_13    product_ub_191  1
    w_5_13    normalized_mass_5_199  1
    w_5_13    normalized_ratio_5_200  -1.625
    w_5_13    full_original_Gini_282  -1.9706746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_192  -2.4901923970053259e-02
    x_5_14    product_ub_193  -4.1376592670473542e-02
    x_5_14    onehot_5_198  1
    x_5_14    stock_lb_222  14
    x_5_14    stock_ub_223  14
    x_5_14    parent_nonstrict_scope_224  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_192  1
    w_5_14    product_ub_193  1
    w_5_14    normalized_mass_5_199  1
    w_5_14    normalized_ratio_5_200  -1.75
    w_5_14    full_original_Gini_282  -2.3081746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_194  -2.4901923970053259e-02
    x_5_15    product_ub_195  -4.1376592670473542e-02
    x_5_15    onehot_5_198  1
    x_5_15    stock_lb_222  15
    x_5_15    stock_ub_223  15
    x_5_15    parent_nonstrict_scope_224  0.084
    x_5_15    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_194  1
    w_5_15    product_ub_195  1
    w_5_15    normalized_mass_5_199  1
    w_5_15    normalized_ratio_5_200  -1.875
    w_5_15    full_original_Gini_282  -2.6456746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_196  -2.4901923970053259e-02
    x_5_16    product_ub_197  -4.1376592670473542e-02
    x_5_16    onehot_5_198  1
    x_5_16    stock_lb_222  16
    x_5_16    stock_ub_223  16
    x_5_16    parent_nonstrict_scope_224  0.096
    x_5_16    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_196  1
    w_5_16    product_ub_197  1
    w_5_16    normalized_mass_5_199  1
    w_5_16    normalized_ratio_5_200  -2
    w_5_16    full_original_Gini_282  -2.9831746031746029e+01
    rho_5     normalized_ratio_5_200  1
    rho_5     block_pair_pos_225  -1
    rho_5     block_pair_neg_226  1
    rho_5     block_pair_pos_227  1
    rho_5     block_pair_neg_228  -1
    rho_5     block_pair_pos_233  1
    rho_5     block_pair_neg_234  -1
    rho_5     block_pair_pos_237  1
    rho_5     block_pair_neg_238  -1
    rho_5     block_pair_pos_249  1
    rho_5     block_pair_neg_250  -1
    rho_5     block_pair_pos_259  1
    rho_5     block_pair_neg_260  -1
    rho_5     block_pair_pos_267  1
    rho_5     block_pair_neg_268  -1
    rho_5     normalization_281  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_201  -2.4901923970053259e-02
    x_19_0    product_ub_202  -4.1376592670473542e-02
    x_19_0    onehot_19_219  1
    x_19_0    parent_nonstrict_scope_224  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_201  1
    w_19_0    product_ub_202  1
    w_19_0    normalized_mass_19_220  1
    w_19_0    full_original_Gini_282  -2.4168253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_203  -2.4901923970053259e-02
    x_19_1    product_ub_204  -4.1376592670473542e-02
    x_19_1    onehot_19_219  1
    x_19_1    stock_lb_222  1
    x_19_1    stock_ub_223  1
    x_19_1    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_203  1
    w_19_1    product_ub_204  1
    w_19_1    normalized_mass_19_220  1
    w_19_1    normalized_ratio_19_221  -0.25
    w_19_1    full_original_Gini_282  -1.7418253968253971e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_205  -2.4901923970053259e-02
    x_19_2    product_ub_206  -4.1376592670473542e-02
    x_19_2    onehot_19_219  1
    x_19_2    stock_lb_222  2
    x_19_2    stock_ub_223  2
    x_19_2    parent_nonstrict_scope_224  0.012
    x_19_2    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_205  1
    w_19_2    product_ub_206  1
    w_19_2    normalized_mass_19_220  1
    w_19_2    normalized_ratio_19_221  -0.5
    w_19_2    full_original_Gini_282  -1.0668253968253966e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_207  -2.4901923970053259e-02
    x_19_3    product_ub_208  -4.1376592670473542e-02
    x_19_3    onehot_19_219  1
    x_19_3    stock_lb_222  3
    x_19_3    stock_ub_223  3
    x_19_3    parent_nonstrict_scope_224  0.006
    x_19_3    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_207  1
    w_19_3    product_ub_208  1
    w_19_3    normalized_mass_19_220  1
    w_19_3    normalized_ratio_19_221  -0.75
    w_19_3    full_original_Gini_282  -4.7325396825396808e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_209  -2.4901923970053259e-02
    x_19_4    product_ub_210  -4.1376592670473542e-02
    x_19_4    onehot_19_219  1
    x_19_4    stock_lb_222  4
    x_19_4    stock_ub_223  4
    x_19_4    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_209  1
    w_19_4    product_ub_210  1
    w_19_4    normalized_mass_19_220  1
    w_19_4    normalized_ratio_19_221  -1
    w_19_4    full_original_Gini_282  -2.8317460317460319e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_211  -2.4901923970053259e-02
    x_19_5    product_ub_212  -4.1376592670473542e-02
    x_19_5    onehot_19_219  1
    x_19_5    stock_lb_222  5
    x_19_5    stock_ub_223  5
    x_19_5    parent_nonstrict_scope_224  0.006
    x_19_5    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_211  1
    w_19_5    product_ub_212  1
    w_19_5    normalized_mass_19_220  1
    w_19_5    normalized_ratio_19_221  -1.25
    w_19_5    full_original_Gini_282  -9.5817460317460323e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_213  -2.4901923970053259e-02
    x_19_6    product_ub_214  -4.1376592670473542e-02
    x_19_6    onehot_19_219  1
    x_19_6    stock_lb_222  6
    x_19_6    stock_ub_223  6
    x_19_6    parent_nonstrict_scope_224  0.012
    x_19_6    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_213  1
    w_19_6    product_ub_214  1
    w_19_6    normalized_mass_19_220  1
    w_19_6    normalized_ratio_19_221  -1.5
    w_19_6    full_original_Gini_282  -1.6331746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_215  -2.4901923970053259e-02
    x_19_7    product_ub_216  -4.1376592670473542e-02
    x_19_7    onehot_19_219  1
    x_19_7    stock_lb_222  7
    x_19_7    stock_ub_223  7
    x_19_7    parent_nonstrict_scope_224  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_215  1
    w_19_7    product_ub_216  1
    w_19_7    normalized_mass_19_220  1
    w_19_7    normalized_ratio_19_221  -1.75
    w_19_7    full_original_Gini_282  -2.3081746031746029e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_217  -2.4901923970053259e-02
    x_19_8    product_ub_218  -4.1376592670473542e-02
    x_19_8    onehot_19_219  1
    x_19_8    stock_lb_222  8
    x_19_8    stock_ub_223  8
    x_19_8    parent_nonstrict_scope_224  0.024
    x_19_8    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_217  1
    w_19_8    product_ub_218  1
    w_19_8    normalized_mass_19_220  1
    w_19_8    normalized_ratio_19_221  -2
    w_19_8    full_original_Gini_282  -2.9831746031746029e+01
    rho_19    normalized_ratio_19_221  1
    rho_19    block_pair_pos_225  1
    rho_19    block_pair_neg_226  -1
    rho_19    block_pair_pos_229  1
    rho_19    block_pair_neg_230  -1
    rho_19    block_pair_pos_235  1
    rho_19    block_pair_neg_236  -1
    rho_19    block_pair_pos_241  1
    rho_19    block_pair_neg_242  -1
    rho_19    block_pair_pos_253  1
    rho_19    block_pair_neg_254  -1
    rho_19    block_pair_pos_263  1
    rho_19    block_pair_neg_264  -1
    rho_19    block_pair_pos_271  1
    rho_19    block_pair_neg_272  -1
    rho_19    normalization_281  1
    a_35_30   block_pair_pos_275  1
    a_35_30   block_pair_neg_276  1
    a_35_30   full_original_Gini_282  -1
    a_35_31   block_pair_pos_277  1
    a_35_31   block_pair_neg_278  1
    a_35_31   full_original_Gini_282  -1
    a_35_32   block_pair_pos_279  1
    a_35_32   block_pair_neg_280  1
    a_35_32   full_original_Gini_282  -1
    a_35_16   block_pair_pos_269  1
    a_35_16   block_pair_neg_270  1
    a_35_16   full_original_Gini_282  -1
    a_35_26   block_pair_pos_273  1
    a_35_26   block_pair_neg_274  1
    a_35_26   full_original_Gini_282  -1
    a_35_5    block_pair_pos_267  1
    a_35_5    block_pair_neg_268  1
    a_35_5    full_original_Gini_282  -1
    a_35_19   block_pair_pos_271  1
    a_35_19   block_pair_neg_272  1
    a_35_19   full_original_Gini_282  -1
    a_30_31   block_pair_pos_245  1
    a_30_31   block_pair_neg_246  1
    a_30_31   full_original_Gini_282  -1
    a_30_32   block_pair_pos_247  1
    a_30_32   block_pair_neg_248  1
    a_30_32   full_original_Gini_282  -1
    a_30_16   block_pair_pos_239  1
    a_30_16   block_pair_neg_240  1
    a_30_16   full_original_Gini_282  -1
    a_30_26   block_pair_pos_243  1
    a_30_26   block_pair_neg_244  1
    a_30_26   full_original_Gini_282  -1
    a_30_5    block_pair_pos_237  1
    a_30_5    block_pair_neg_238  1
    a_30_5    full_original_Gini_282  -1
    a_30_19   block_pair_pos_241  1
    a_30_19   block_pair_neg_242  1
    a_30_19   full_original_Gini_282  -1
    a_31_32   block_pair_pos_257  1
    a_31_32   block_pair_neg_258  1
    a_31_32   full_original_Gini_282  -1
    a_31_16   block_pair_pos_251  1
    a_31_16   block_pair_neg_252  1
    a_31_16   full_original_Gini_282  -1
    a_31_26   block_pair_pos_255  1
    a_31_26   block_pair_neg_256  1
    a_31_26   full_original_Gini_282  -1
    a_31_5    block_pair_pos_249  1
    a_31_5    block_pair_neg_250  1
    a_31_5    full_original_Gini_282  -1
    a_31_19   block_pair_pos_253  1
    a_31_19   block_pair_neg_254  1
    a_31_19   full_original_Gini_282  -1
    a_32_16   block_pair_pos_261  1
    a_32_16   block_pair_neg_262  1
    a_32_16   full_original_Gini_282  -1
    a_32_26   block_pair_pos_265  1
    a_32_26   block_pair_neg_266  1
    a_32_26   full_original_Gini_282  -1
    a_32_5    block_pair_pos_259  1
    a_32_5    block_pair_neg_260  1
    a_32_5    full_original_Gini_282  -1
    a_32_19   block_pair_pos_263  1
    a_32_19   block_pair_neg_264  1
    a_32_19   full_original_Gini_282  -1
    a_16_26   block_pair_pos_231  1
    a_16_26   block_pair_neg_232  1
    a_16_26   full_original_Gini_282  -1
    a_16_5    block_pair_pos_227  1
    a_16_5    block_pair_neg_228  1
    a_16_5    full_original_Gini_282  -1
    a_16_19   block_pair_pos_229  1
    a_16_19   block_pair_neg_230  1
    a_16_19   full_original_Gini_282  -1
    a_26_5    block_pair_pos_233  1
    a_26_5    block_pair_neg_234  1
    a_26_5    full_original_Gini_282  -1
    a_26_19   block_pair_pos_235  1
    a_26_19   block_pair_neg_236  1
    a_26_19   full_original_Gini_282  -1
    a_5_19    block_pair_pos_225  1
    a_5_19    block_pair_neg_226  1
    a_5_19    full_original_Gini_282  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_35_0  unique_nonzero_owner_283  1
    service_0_35_0  service_visit_def_815  1
    service_0_35_0  free_load_conservation_816  -11
    service_0_35_0  original_T_including_depot_unload_864  1320
    service_0_35_1  unique_nonzero_owner_284  1
    service_0_35_1  service_visit_def_815  1
    service_0_35_1  free_load_conservation_816  -10
    service_0_35_1  original_T_including_depot_unload_864  1200
    service_0_35_2  unique_nonzero_owner_285  1
    service_0_35_2  service_visit_def_815  1
    service_0_35_2  free_load_conservation_816  -9
    service_0_35_2  original_T_including_depot_unload_864  1080
    service_0_35_3  unique_nonzero_owner_286  1
    service_0_35_3  service_visit_def_815  1
    service_0_35_3  free_load_conservation_816  -8
    service_0_35_3  original_T_including_depot_unload_864  960
    service_0_35_4  unique_nonzero_owner_287  1
    service_0_35_4  service_visit_def_815  1
    service_0_35_4  free_load_conservation_816  -7
    service_0_35_4  original_T_including_depot_unload_864  840
    service_0_35_5  unique_nonzero_owner_288  1
    service_0_35_5  service_visit_def_815  1
    service_0_35_5  free_load_conservation_816  -6
    service_0_35_5  original_T_including_depot_unload_864  720
    service_0_35_6  unique_nonzero_owner_289  1
    service_0_35_6  service_visit_def_815  1
    service_0_35_6  free_load_conservation_816  -5
    service_0_35_6  original_T_including_depot_unload_864  600
    service_0_35_7  unique_nonzero_owner_290  1
    service_0_35_7  service_visit_def_815  1
    service_0_35_7  free_load_conservation_816  -4
    service_0_35_7  original_T_including_depot_unload_864  480
    service_0_35_8  unique_nonzero_owner_291  1
    service_0_35_8  service_visit_def_815  1
    service_0_35_8  free_load_conservation_816  -3
    service_0_35_8  original_T_including_depot_unload_864  360
    service_0_35_9  unique_nonzero_owner_292  1
    service_0_35_9  service_visit_def_815  1
    service_0_35_9  free_load_conservation_816  -2
    service_0_35_9  original_T_including_depot_unload_864  240
    service_0_35_10  unique_nonzero_owner_293  1
    service_0_35_10  service_visit_def_815  1
    service_0_35_10  free_load_conservation_816  -1
    service_0_35_10  original_T_including_depot_unload_864  120
    service_0_35_12  unique_nonzero_owner_294  1
    service_0_35_12  service_visit_def_815  1
    service_0_35_12  free_load_conservation_816  1
    service_0_35_13  unique_nonzero_owner_295  1
    service_0_35_13  service_visit_def_815  1
    service_0_35_13  free_load_conservation_816  2
    service_0_35_14  unique_nonzero_owner_296  1
    service_0_35_14  service_visit_def_815  1
    service_0_35_14  free_load_conservation_816  3
    service_0_35_15  unique_nonzero_owner_297  1
    service_0_35_15  service_visit_def_815  1
    service_0_35_15  free_load_conservation_816  4
    service_1_35_0  unique_nonzero_owner_283  1
    service_1_35_0  service_visit_def_1245  1
    service_1_35_0  free_load_conservation_1246  -11
    service_1_35_0  original_T_including_depot_unload_1293  1320
    service_1_35_1  unique_nonzero_owner_284  1
    service_1_35_1  service_visit_def_1245  1
    service_1_35_1  free_load_conservation_1246  -10
    service_1_35_1  original_T_including_depot_unload_1293  1200
    service_1_35_2  unique_nonzero_owner_285  1
    service_1_35_2  service_visit_def_1245  1
    service_1_35_2  free_load_conservation_1246  -9
    service_1_35_2  original_T_including_depot_unload_1293  1080
    service_1_35_3  unique_nonzero_owner_286  1
    service_1_35_3  service_visit_def_1245  1
    service_1_35_3  free_load_conservation_1246  -8
    service_1_35_3  original_T_including_depot_unload_1293  960
    service_1_35_4  unique_nonzero_owner_287  1
    service_1_35_4  service_visit_def_1245  1
    service_1_35_4  free_load_conservation_1246  -7
    service_1_35_4  original_T_including_depot_unload_1293  840
    service_1_35_5  unique_nonzero_owner_288  1
    service_1_35_5  service_visit_def_1245  1
    service_1_35_5  free_load_conservation_1246  -6
    service_1_35_5  original_T_including_depot_unload_1293  720
    service_1_35_6  unique_nonzero_owner_289  1
    service_1_35_6  service_visit_def_1245  1
    service_1_35_6  free_load_conservation_1246  -5
    service_1_35_6  original_T_including_depot_unload_1293  600
    service_1_35_7  unique_nonzero_owner_290  1
    service_1_35_7  service_visit_def_1245  1
    service_1_35_7  free_load_conservation_1246  -4
    service_1_35_7  original_T_including_depot_unload_1293  480
    service_1_35_8  unique_nonzero_owner_291  1
    service_1_35_8  service_visit_def_1245  1
    service_1_35_8  free_load_conservation_1246  -3
    service_1_35_8  original_T_including_depot_unload_1293  360
    service_1_35_9  unique_nonzero_owner_292  1
    service_1_35_9  service_visit_def_1245  1
    service_1_35_9  free_load_conservation_1246  -2
    service_1_35_9  original_T_including_depot_unload_1293  240
    service_1_35_10  unique_nonzero_owner_293  1
    service_1_35_10  service_visit_def_1245  1
    service_1_35_10  free_load_conservation_1246  -1
    service_1_35_10  original_T_including_depot_unload_1293  120
    service_1_35_12  unique_nonzero_owner_294  1
    service_1_35_12  service_visit_def_1245  1
    service_1_35_12  free_load_conservation_1246  1
    service_1_35_13  unique_nonzero_owner_295  1
    service_1_35_13  service_visit_def_1245  1
    service_1_35_13  free_load_conservation_1246  2
    service_1_35_14  unique_nonzero_owner_296  1
    service_1_35_14  service_visit_def_1245  1
    service_1_35_14  free_load_conservation_1246  3
    service_1_35_15  unique_nonzero_owner_297  1
    service_1_35_15  service_visit_def_1245  1
    service_1_35_15  free_load_conservation_1246  4
    service_2_35_0  unique_nonzero_owner_283  1
    service_2_35_0  service_visit_def_1617  1
    service_2_35_0  free_load_conservation_1618  -11
    service_2_35_0  original_T_including_depot_unload_1664  1320
    service_2_35_1  unique_nonzero_owner_284  1
    service_2_35_1  service_visit_def_1617  1
    service_2_35_1  free_load_conservation_1618  -10
    service_2_35_1  original_T_including_depot_unload_1664  1200
    service_2_35_2  unique_nonzero_owner_285  1
    service_2_35_2  service_visit_def_1617  1
    service_2_35_2  free_load_conservation_1618  -9
    service_2_35_2  original_T_including_depot_unload_1664  1080
    service_2_35_3  unique_nonzero_owner_286  1
    service_2_35_3  service_visit_def_1617  1
    service_2_35_3  free_load_conservation_1618  -8
    service_2_35_3  original_T_including_depot_unload_1664  960
    service_2_35_4  unique_nonzero_owner_287  1
    service_2_35_4  service_visit_def_1617  1
    service_2_35_4  free_load_conservation_1618  -7
    service_2_35_4  original_T_including_depot_unload_1664  840
    service_2_35_5  unique_nonzero_owner_288  1
    service_2_35_5  service_visit_def_1617  1
    service_2_35_5  free_load_conservation_1618  -6
    service_2_35_5  original_T_including_depot_unload_1664  720
    service_2_35_6  unique_nonzero_owner_289  1
    service_2_35_6  service_visit_def_1617  1
    service_2_35_6  free_load_conservation_1618  -5
    service_2_35_6  original_T_including_depot_unload_1664  600
    service_2_35_7  unique_nonzero_owner_290  1
    service_2_35_7  service_visit_def_1617  1
    service_2_35_7  free_load_conservation_1618  -4
    service_2_35_7  original_T_including_depot_unload_1664  480
    service_2_35_8  unique_nonzero_owner_291  1
    service_2_35_8  service_visit_def_1617  1
    service_2_35_8  free_load_conservation_1618  -3
    service_2_35_8  original_T_including_depot_unload_1664  360
    service_2_35_9  unique_nonzero_owner_292  1
    service_2_35_9  service_visit_def_1617  1
    service_2_35_9  free_load_conservation_1618  -2
    service_2_35_9  original_T_including_depot_unload_1664  240
    service_2_35_10  unique_nonzero_owner_293  1
    service_2_35_10  service_visit_def_1617  1
    service_2_35_10  free_load_conservation_1618  -1
    service_2_35_10  original_T_including_depot_unload_1664  120
    service_2_35_12  unique_nonzero_owner_294  1
    service_2_35_12  service_visit_def_1617  1
    service_2_35_12  free_load_conservation_1618  1
    service_2_35_13  unique_nonzero_owner_295  1
    service_2_35_13  service_visit_def_1617  1
    service_2_35_13  free_load_conservation_1618  2
    service_2_35_14  unique_nonzero_owner_296  1
    service_2_35_14  service_visit_def_1617  1
    service_2_35_14  free_load_conservation_1618  3
    service_2_35_15  unique_nonzero_owner_297  1
    service_2_35_15  service_visit_def_1617  1
    service_2_35_15  free_load_conservation_1618  4
    service_0_30_0  unique_nonzero_owner_298  1
    service_0_30_0  service_visit_def_821  1
    service_0_30_0  free_load_conservation_822  -5
    service_0_30_0  original_T_including_depot_unload_864  600
    service_0_30_1  unique_nonzero_owner_299  1
    service_0_30_1  service_visit_def_821  1
    service_0_30_1  free_load_conservation_822  -4
    service_0_30_1  original_T_including_depot_unload_864  480
    service_0_30_2  unique_nonzero_owner_300  1
    service_0_30_2  service_visit_def_821  1
    service_0_30_2  free_load_conservation_822  -3
    service_0_30_2  original_T_including_depot_unload_864  360
    service_0_30_3  unique_nonzero_owner_301  1
    service_0_30_3  service_visit_def_821  1
    service_0_30_3  free_load_conservation_822  -2
    service_0_30_3  original_T_including_depot_unload_864  240
    service_0_30_4  unique_nonzero_owner_302  1
    service_0_30_4  service_visit_def_821  1
    service_0_30_4  free_load_conservation_822  -1
    service_0_30_4  original_T_including_depot_unload_864  120
    service_0_30_6  unique_nonzero_owner_303  1
    service_0_30_6  service_visit_def_821  1
    service_0_30_6  free_load_conservation_822  1
    service_0_30_7  unique_nonzero_owner_304  1
    service_0_30_7  service_visit_def_821  1
    service_0_30_7  free_load_conservation_822  2
    service_0_30_8  unique_nonzero_owner_305  1
    service_0_30_8  service_visit_def_821  1
    service_0_30_8  free_load_conservation_822  3
    service_1_30_0  unique_nonzero_owner_298  1
    service_1_30_0  service_visit_def_1251  1
    service_1_30_0  free_load_conservation_1252  -5
    service_1_30_0  original_T_including_depot_unload_1293  600
    service_1_30_1  unique_nonzero_owner_299  1
    service_1_30_1  service_visit_def_1251  1
    service_1_30_1  free_load_conservation_1252  -4
    service_1_30_1  original_T_including_depot_unload_1293  480
    service_1_30_2  unique_nonzero_owner_300  1
    service_1_30_2  service_visit_def_1251  1
    service_1_30_2  free_load_conservation_1252  -3
    service_1_30_2  original_T_including_depot_unload_1293  360
    service_1_30_3  unique_nonzero_owner_301  1
    service_1_30_3  service_visit_def_1251  1
    service_1_30_3  free_load_conservation_1252  -2
    service_1_30_3  original_T_including_depot_unload_1293  240
    service_1_30_4  unique_nonzero_owner_302  1
    service_1_30_4  service_visit_def_1251  1
    service_1_30_4  free_load_conservation_1252  -1
    service_1_30_4  original_T_including_depot_unload_1293  120
    service_1_30_6  unique_nonzero_owner_303  1
    service_1_30_6  service_visit_def_1251  1
    service_1_30_6  free_load_conservation_1252  1
    service_1_30_7  unique_nonzero_owner_304  1
    service_1_30_7  service_visit_def_1251  1
    service_1_30_7  free_load_conservation_1252  2
    service_1_30_8  unique_nonzero_owner_305  1
    service_1_30_8  service_visit_def_1251  1
    service_1_30_8  free_load_conservation_1252  3
    service_2_30_0  unique_nonzero_owner_298  1
    service_2_30_0  service_visit_def_1623  1
    service_2_30_0  free_load_conservation_1624  -5
    service_2_30_0  original_T_including_depot_unload_1664  600
    service_2_30_1  unique_nonzero_owner_299  1
    service_2_30_1  service_visit_def_1623  1
    service_2_30_1  free_load_conservation_1624  -4
    service_2_30_1  original_T_including_depot_unload_1664  480
    service_2_30_2  unique_nonzero_owner_300  1
    service_2_30_2  service_visit_def_1623  1
    service_2_30_2  free_load_conservation_1624  -3
    service_2_30_2  original_T_including_depot_unload_1664  360
    service_2_30_3  unique_nonzero_owner_301  1
    service_2_30_3  service_visit_def_1623  1
    service_2_30_3  free_load_conservation_1624  -2
    service_2_30_3  original_T_including_depot_unload_1664  240
    service_2_30_4  unique_nonzero_owner_302  1
    service_2_30_4  service_visit_def_1623  1
    service_2_30_4  free_load_conservation_1624  -1
    service_2_30_4  original_T_including_depot_unload_1664  120
    service_2_30_6  unique_nonzero_owner_303  1
    service_2_30_6  service_visit_def_1623  1
    service_2_30_6  free_load_conservation_1624  1
    service_2_30_7  unique_nonzero_owner_304  1
    service_2_30_7  service_visit_def_1623  1
    service_2_30_7  free_load_conservation_1624  2
    service_2_30_8  unique_nonzero_owner_305  1
    service_2_30_8  service_visit_def_1623  1
    service_2_30_8  free_load_conservation_1624  3
    service_0_31_0  unique_nonzero_owner_306  1
    service_0_31_0  service_visit_def_827  1
    service_0_31_0  free_load_conservation_828  -2
    service_0_31_0  original_T_including_depot_unload_864  240
    service_0_31_1  unique_nonzero_owner_307  1
    service_0_31_1  service_visit_def_827  1
    service_0_31_1  free_load_conservation_828  -1
    service_0_31_1  original_T_including_depot_unload_864  120
    service_0_31_3  unique_nonzero_owner_308  1
    service_0_31_3  service_visit_def_827  1
    service_0_31_3  free_load_conservation_828  1
    service_0_31_4  unique_nonzero_owner_309  1
    service_0_31_4  service_visit_def_827  1
    service_0_31_4  free_load_conservation_828  2
    service_0_31_5  unique_nonzero_owner_310  1
    service_0_31_5  service_visit_def_827  1
    service_0_31_5  free_load_conservation_828  3
    service_0_31_6  unique_nonzero_owner_311  1
    service_0_31_6  service_visit_def_827  1
    service_0_31_6  free_load_conservation_828  4
    service_0_31_7  unique_nonzero_owner_312  1
    service_0_31_7  service_visit_def_827  1
    service_0_31_7  free_load_conservation_828  5
    service_0_31_8  unique_nonzero_owner_313  1
    service_0_31_8  service_visit_def_827  1
    service_0_31_8  free_load_conservation_828  6
    service_0_31_9  unique_nonzero_owner_314  1
    service_0_31_9  service_visit_def_827  1
    service_0_31_9  free_load_conservation_828  7
    service_0_31_10  unique_nonzero_owner_315  1
    service_0_31_10  service_visit_def_827  1
    service_0_31_10  free_load_conservation_828  8
    service_0_31_11  unique_nonzero_owner_316  1
    service_0_31_11  service_visit_def_827  1
    service_0_31_11  free_load_conservation_828  9
    service_0_31_12  unique_nonzero_owner_317  1
    service_0_31_12  service_visit_def_827  1
    service_0_31_12  free_load_conservation_828  10
    service_1_31_0  unique_nonzero_owner_306  1
    service_1_31_0  service_visit_def_1257  1
    service_1_31_0  free_load_conservation_1258  -2
    service_1_31_0  original_T_including_depot_unload_1293  240
    service_1_31_1  unique_nonzero_owner_307  1
    service_1_31_1  service_visit_def_1257  1
    service_1_31_1  free_load_conservation_1258  -1
    service_1_31_1  original_T_including_depot_unload_1293  120
    service_1_31_3  unique_nonzero_owner_308  1
    service_1_31_3  service_visit_def_1257  1
    service_1_31_3  free_load_conservation_1258  1
    service_1_31_4  unique_nonzero_owner_309  1
    service_1_31_4  service_visit_def_1257  1
    service_1_31_4  free_load_conservation_1258  2
    service_1_31_5  unique_nonzero_owner_310  1
    service_1_31_5  service_visit_def_1257  1
    service_1_31_5  free_load_conservation_1258  3
    service_1_31_6  unique_nonzero_owner_311  1
    service_1_31_6  service_visit_def_1257  1
    service_1_31_6  free_load_conservation_1258  4
    service_1_31_7  unique_nonzero_owner_312  1
    service_1_31_7  service_visit_def_1257  1
    service_1_31_7  free_load_conservation_1258  5
    service_1_31_8  unique_nonzero_owner_313  1
    service_1_31_8  service_visit_def_1257  1
    service_1_31_8  free_load_conservation_1258  6
    service_1_31_9  unique_nonzero_owner_314  1
    service_1_31_9  service_visit_def_1257  1
    service_1_31_9  free_load_conservation_1258  7
    service_1_31_10  unique_nonzero_owner_315  1
    service_1_31_10  service_visit_def_1257  1
    service_1_31_10  free_load_conservation_1258  8
    service_1_31_11  unique_nonzero_owner_316  1
    service_1_31_11  service_visit_def_1257  1
    service_1_31_11  free_load_conservation_1258  9
    service_1_31_12  unique_nonzero_owner_317  1
    service_1_31_12  service_visit_def_1257  1
    service_1_31_12  free_load_conservation_1258  10
    service_2_31_0  unique_nonzero_owner_306  1
    service_2_31_0  service_visit_def_1629  1
    service_2_31_0  free_load_conservation_1630  -2
    service_2_31_0  original_T_including_depot_unload_1664  240
    service_2_31_1  unique_nonzero_owner_307  1
    service_2_31_1  service_visit_def_1629  1
    service_2_31_1  free_load_conservation_1630  -1
    service_2_31_1  original_T_including_depot_unload_1664  120
    service_2_31_3  unique_nonzero_owner_308  1
    service_2_31_3  service_visit_def_1629  1
    service_2_31_3  free_load_conservation_1630  1
    service_2_31_4  unique_nonzero_owner_309  1
    service_2_31_4  service_visit_def_1629  1
    service_2_31_4  free_load_conservation_1630  2
    service_2_31_5  unique_nonzero_owner_310  1
    service_2_31_5  service_visit_def_1629  1
    service_2_31_5  free_load_conservation_1630  3
    service_2_31_6  unique_nonzero_owner_311  1
    service_2_31_6  service_visit_def_1629  1
    service_2_31_6  free_load_conservation_1630  4
    service_2_31_7  unique_nonzero_owner_312  1
    service_2_31_7  service_visit_def_1629  1
    service_2_31_7  free_load_conservation_1630  5
    service_2_31_8  unique_nonzero_owner_313  1
    service_2_31_8  service_visit_def_1629  1
    service_2_31_8  free_load_conservation_1630  6
    service_2_31_9  unique_nonzero_owner_314  1
    service_2_31_9  service_visit_def_1629  1
    service_2_31_9  free_load_conservation_1630  7
    service_2_31_10  unique_nonzero_owner_315  1
    service_2_31_10  service_visit_def_1629  1
    service_2_31_10  free_load_conservation_1630  8
    service_2_31_11  unique_nonzero_owner_316  1
    service_2_31_11  service_visit_def_1629  1
    service_2_31_11  free_load_conservation_1630  9
    service_2_31_12  unique_nonzero_owner_317  1
    service_2_31_12  service_visit_def_1629  1
    service_2_31_12  free_load_conservation_1630  10
    service_0_32_1  unique_nonzero_owner_318  1
    service_0_32_1  service_visit_def_833  1
    service_0_32_1  free_load_conservation_834  1
    service_0_32_2  unique_nonzero_owner_319  1
    service_0_32_2  service_visit_def_833  1
    service_0_32_2  free_load_conservation_834  2
    service_0_32_3  unique_nonzero_owner_320  1
    service_0_32_3  service_visit_def_833  1
    service_0_32_3  free_load_conservation_834  3
    service_0_32_4  unique_nonzero_owner_321  1
    service_0_32_4  service_visit_def_833  1
    service_0_32_4  free_load_conservation_834  4
    service_0_32_5  unique_nonzero_owner_322  1
    service_0_32_5  service_visit_def_833  1
    service_0_32_5  free_load_conservation_834  5
    service_0_32_6  unique_nonzero_owner_323  1
    service_0_32_6  service_visit_def_833  1
    service_0_32_6  free_load_conservation_834  6
    service_0_32_7  unique_nonzero_owner_324  1
    service_0_32_7  service_visit_def_833  1
    service_0_32_7  free_load_conservation_834  7
    service_0_32_8  unique_nonzero_owner_325  1
    service_0_32_8  service_visit_def_833  1
    service_0_32_8  free_load_conservation_834  8
    service_0_32_9  unique_nonzero_owner_326  1
    service_0_32_9  service_visit_def_833  1
    service_0_32_9  free_load_conservation_834  9
    service_0_32_10  unique_nonzero_owner_327  1
    service_0_32_10  service_visit_def_833  1
    service_0_32_10  free_load_conservation_834  10
    service_0_32_11  unique_nonzero_owner_328  1
    service_0_32_11  service_visit_def_833  1
    service_0_32_11  free_load_conservation_834  11
    service_0_32_12  unique_nonzero_owner_329  1
    service_0_32_12  service_visit_def_833  1
    service_0_32_12  free_load_conservation_834  12
    service_1_32_1  unique_nonzero_owner_318  1
    service_1_32_1  service_visit_def_1263  1
    service_1_32_1  free_load_conservation_1264  1
    service_1_32_2  unique_nonzero_owner_319  1
    service_1_32_2  service_visit_def_1263  1
    service_1_32_2  free_load_conservation_1264  2
    service_1_32_3  unique_nonzero_owner_320  1
    service_1_32_3  service_visit_def_1263  1
    service_1_32_3  free_load_conservation_1264  3
    service_1_32_4  unique_nonzero_owner_321  1
    service_1_32_4  service_visit_def_1263  1
    service_1_32_4  free_load_conservation_1264  4
    service_1_32_5  unique_nonzero_owner_322  1
    service_1_32_5  service_visit_def_1263  1
    service_1_32_5  free_load_conservation_1264  5
    service_1_32_6  unique_nonzero_owner_323  1
    service_1_32_6  service_visit_def_1263  1
    service_1_32_6  free_load_conservation_1264  6
    service_1_32_7  unique_nonzero_owner_324  1
    service_1_32_7  service_visit_def_1263  1
    service_1_32_7  free_load_conservation_1264  7
    service_1_32_8  unique_nonzero_owner_325  1
    service_1_32_8  service_visit_def_1263  1
    service_1_32_8  free_load_conservation_1264  8
    service_1_32_9  unique_nonzero_owner_326  1
    service_1_32_9  service_visit_def_1263  1
    service_1_32_9  free_load_conservation_1264  9
    service_1_32_10  unique_nonzero_owner_327  1
    service_1_32_10  service_visit_def_1263  1
    service_1_32_10  free_load_conservation_1264  10
    service_1_32_11  unique_nonzero_owner_328  1
    service_1_32_11  service_visit_def_1263  1
    service_1_32_11  free_load_conservation_1264  11
    service_1_32_12  unique_nonzero_owner_329  1
    service_1_32_12  service_visit_def_1263  1
    service_1_32_12  free_load_conservation_1264  12
    service_2_32_1  unique_nonzero_owner_318  1
    service_2_32_1  service_visit_def_1635  1
    service_2_32_1  free_load_conservation_1636  1
    service_2_32_2  unique_nonzero_owner_319  1
    service_2_32_2  service_visit_def_1635  1
    service_2_32_2  free_load_conservation_1636  2
    service_2_32_3  unique_nonzero_owner_320  1
    service_2_32_3  service_visit_def_1635  1
    service_2_32_3  free_load_conservation_1636  3
    service_2_32_4  unique_nonzero_owner_321  1
    service_2_32_4  service_visit_def_1635  1
    service_2_32_4  free_load_conservation_1636  4
    service_2_32_5  unique_nonzero_owner_322  1
    service_2_32_5  service_visit_def_1635  1
    service_2_32_5  free_load_conservation_1636  5
    service_2_32_6  unique_nonzero_owner_323  1
    service_2_32_6  service_visit_def_1635  1
    service_2_32_6  free_load_conservation_1636  6
    service_2_32_7  unique_nonzero_owner_324  1
    service_2_32_7  service_visit_def_1635  1
    service_2_32_7  free_load_conservation_1636  7
    service_2_32_8  unique_nonzero_owner_325  1
    service_2_32_8  service_visit_def_1635  1
    service_2_32_8  free_load_conservation_1636  8
    service_2_32_9  unique_nonzero_owner_326  1
    service_2_32_9  service_visit_def_1635  1
    service_2_32_9  free_load_conservation_1636  9
    service_2_32_10  unique_nonzero_owner_327  1
    service_2_32_10  service_visit_def_1635  1
    service_2_32_10  free_load_conservation_1636  10
    service_2_32_11  unique_nonzero_owner_328  1
    service_2_32_11  service_visit_def_1635  1
    service_2_32_11  free_load_conservation_1636  11
    service_2_32_12  unique_nonzero_owner_329  1
    service_2_32_12  service_visit_def_1635  1
    service_2_32_12  free_load_conservation_1636  12
    service_0_16_0  unique_nonzero_owner_330  1
    service_0_16_0  service_visit_def_839  1
    service_0_16_0  free_load_conservation_840  -1
    service_0_16_0  original_T_including_depot_unload_864  120
    service_0_16_2  unique_nonzero_owner_331  1
    service_0_16_2  service_visit_def_839  1
    service_0_16_2  free_load_conservation_840  1
    service_0_16_3  unique_nonzero_owner_332  1
    service_0_16_3  service_visit_def_839  1
    service_0_16_3  free_load_conservation_840  2
    service_0_16_4  unique_nonzero_owner_333  1
    service_0_16_4  service_visit_def_839  1
    service_0_16_4  free_load_conservation_840  3
    service_0_16_5  unique_nonzero_owner_334  1
    service_0_16_5  service_visit_def_839  1
    service_0_16_5  free_load_conservation_840  4
    service_0_16_6  unique_nonzero_owner_335  1
    service_0_16_6  service_visit_def_839  1
    service_0_16_6  free_load_conservation_840  5
    service_0_16_7  unique_nonzero_owner_336  1
    service_0_16_7  service_visit_def_839  1
    service_0_16_7  free_load_conservation_840  6
    service_0_16_8  unique_nonzero_owner_337  1
    service_0_16_8  service_visit_def_839  1
    service_0_16_8  free_load_conservation_840  7
    service_0_16_9  unique_nonzero_owner_338  1
    service_0_16_9  service_visit_def_839  1
    service_0_16_9  free_load_conservation_840  8
    service_0_16_10  unique_nonzero_owner_339  1
    service_0_16_10  service_visit_def_839  1
    service_0_16_10  free_load_conservation_840  9
    service_0_16_11  unique_nonzero_owner_340  1
    service_0_16_11  service_visit_def_839  1
    service_0_16_11  free_load_conservation_840  10
    service_0_16_12  unique_nonzero_owner_341  1
    service_0_16_12  service_visit_def_839  1
    service_0_16_12  free_load_conservation_840  11
    service_1_16_0  unique_nonzero_owner_330  1
    service_1_16_0  service_visit_def_1269  1
    service_1_16_0  free_load_conservation_1270  -1
    service_1_16_0  original_T_including_depot_unload_1293  120
    service_1_16_2  unique_nonzero_owner_331  1
    service_1_16_2  service_visit_def_1269  1
    service_1_16_2  free_load_conservation_1270  1
    service_1_16_3  unique_nonzero_owner_332  1
    service_1_16_3  service_visit_def_1269  1
    service_1_16_3  free_load_conservation_1270  2
    service_1_16_4  unique_nonzero_owner_333  1
    service_1_16_4  service_visit_def_1269  1
    service_1_16_4  free_load_conservation_1270  3
    service_1_16_5  unique_nonzero_owner_334  1
    service_1_16_5  service_visit_def_1269  1
    service_1_16_5  free_load_conservation_1270  4
    service_1_16_6  unique_nonzero_owner_335  1
    service_1_16_6  service_visit_def_1269  1
    service_1_16_6  free_load_conservation_1270  5
    service_1_16_7  unique_nonzero_owner_336  1
    service_1_16_7  service_visit_def_1269  1
    service_1_16_7  free_load_conservation_1270  6
    service_1_16_8  unique_nonzero_owner_337  1
    service_1_16_8  service_visit_def_1269  1
    service_1_16_8  free_load_conservation_1270  7
    service_1_16_9  unique_nonzero_owner_338  1
    service_1_16_9  service_visit_def_1269  1
    service_1_16_9  free_load_conservation_1270  8
    service_1_16_10  unique_nonzero_owner_339  1
    service_1_16_10  service_visit_def_1269  1
    service_1_16_10  free_load_conservation_1270  9
    service_1_16_11  unique_nonzero_owner_340  1
    service_1_16_11  service_visit_def_1269  1
    service_1_16_11  free_load_conservation_1270  10
    service_1_16_12  unique_nonzero_owner_341  1
    service_1_16_12  service_visit_def_1269  1
    service_1_16_12  free_load_conservation_1270  11
    service_2_16_0  unique_nonzero_owner_330  1
    service_2_16_0  service_visit_def_1641  1
    service_2_16_0  free_load_conservation_1642  -1
    service_2_16_0  original_T_including_depot_unload_1664  120
    service_2_16_2  unique_nonzero_owner_331  1
    service_2_16_2  service_visit_def_1641  1
    service_2_16_2  free_load_conservation_1642  1
    service_2_16_3  unique_nonzero_owner_332  1
    service_2_16_3  service_visit_def_1641  1
    service_2_16_3  free_load_conservation_1642  2
    service_2_16_4  unique_nonzero_owner_333  1
    service_2_16_4  service_visit_def_1641  1
    service_2_16_4  free_load_conservation_1642  3
    service_2_16_5  unique_nonzero_owner_334  1
    service_2_16_5  service_visit_def_1641  1
    service_2_16_5  free_load_conservation_1642  4
    service_2_16_6  unique_nonzero_owner_335  1
    service_2_16_6  service_visit_def_1641  1
    service_2_16_6  free_load_conservation_1642  5
    service_2_16_7  unique_nonzero_owner_336  1
    service_2_16_7  service_visit_def_1641  1
    service_2_16_7  free_load_conservation_1642  6
    service_2_16_8  unique_nonzero_owner_337  1
    service_2_16_8  service_visit_def_1641  1
    service_2_16_8  free_load_conservation_1642  7
    service_2_16_9  unique_nonzero_owner_338  1
    service_2_16_9  service_visit_def_1641  1
    service_2_16_9  free_load_conservation_1642  8
    service_2_16_10  unique_nonzero_owner_339  1
    service_2_16_10  service_visit_def_1641  1
    service_2_16_10  free_load_conservation_1642  9
    service_2_16_11  unique_nonzero_owner_340  1
    service_2_16_11  service_visit_def_1641  1
    service_2_16_11  free_load_conservation_1642  10
    service_2_16_12  unique_nonzero_owner_341  1
    service_2_16_12  service_visit_def_1641  1
    service_2_16_12  free_load_conservation_1642  11
    service_0_26_1  unique_nonzero_owner_342  1
    service_0_26_1  service_visit_def_845  1
    service_0_26_1  free_load_conservation_846  1
    service_0_26_2  unique_nonzero_owner_343  1
    service_0_26_2  service_visit_def_845  1
    service_0_26_2  free_load_conservation_846  2
    service_0_26_3  unique_nonzero_owner_344  1
    service_0_26_3  service_visit_def_845  1
    service_0_26_3  free_load_conservation_846  3
    service_0_26_4  unique_nonzero_owner_345  1
    service_0_26_4  service_visit_def_845  1
    service_0_26_4  free_load_conservation_846  4
    service_0_26_5  unique_nonzero_owner_346  1
    service_0_26_5  service_visit_def_845  1
    service_0_26_5  free_load_conservation_846  5
    service_0_26_6  unique_nonzero_owner_347  1
    service_0_26_6  service_visit_def_845  1
    service_0_26_6  free_load_conservation_846  6
    service_0_26_7  unique_nonzero_owner_348  1
    service_0_26_7  service_visit_def_845  1
    service_0_26_7  free_load_conservation_846  7
    service_0_26_8  unique_nonzero_owner_349  1
    service_0_26_8  service_visit_def_845  1
    service_0_26_8  free_load_conservation_846  8
    service_1_26_1  unique_nonzero_owner_342  1
    service_1_26_1  service_visit_def_1275  1
    service_1_26_1  free_load_conservation_1276  1
    service_1_26_2  unique_nonzero_owner_343  1
    service_1_26_2  service_visit_def_1275  1
    service_1_26_2  free_load_conservation_1276  2
    service_1_26_3  unique_nonzero_owner_344  1
    service_1_26_3  service_visit_def_1275  1
    service_1_26_3  free_load_conservation_1276  3
    service_1_26_4  unique_nonzero_owner_345  1
    service_1_26_4  service_visit_def_1275  1
    service_1_26_4  free_load_conservation_1276  4
    service_1_26_5  unique_nonzero_owner_346  1
    service_1_26_5  service_visit_def_1275  1
    service_1_26_5  free_load_conservation_1276  5
    service_1_26_6  unique_nonzero_owner_347  1
    service_1_26_6  service_visit_def_1275  1
    service_1_26_6  free_load_conservation_1276  6
    service_1_26_7  unique_nonzero_owner_348  1
    service_1_26_7  service_visit_def_1275  1
    service_1_26_7  free_load_conservation_1276  7
    service_1_26_8  unique_nonzero_owner_349  1
    service_1_26_8  service_visit_def_1275  1
    service_1_26_8  free_load_conservation_1276  8
    service_2_26_1  unique_nonzero_owner_342  1
    service_2_26_1  service_visit_def_1647  1
    service_2_26_1  free_load_conservation_1648  1
    service_2_26_2  unique_nonzero_owner_343  1
    service_2_26_2  service_visit_def_1647  1
    service_2_26_2  free_load_conservation_1648  2
    service_2_26_3  unique_nonzero_owner_344  1
    service_2_26_3  service_visit_def_1647  1
    service_2_26_3  free_load_conservation_1648  3
    service_2_26_4  unique_nonzero_owner_345  1
    service_2_26_4  service_visit_def_1647  1
    service_2_26_4  free_load_conservation_1648  4
    service_2_26_5  unique_nonzero_owner_346  1
    service_2_26_5  service_visit_def_1647  1
    service_2_26_5  free_load_conservation_1648  5
    service_2_26_6  unique_nonzero_owner_347  1
    service_2_26_6  service_visit_def_1647  1
    service_2_26_6  free_load_conservation_1648  6
    service_2_26_7  unique_nonzero_owner_348  1
    service_2_26_7  service_visit_def_1647  1
    service_2_26_7  free_load_conservation_1648  7
    service_2_26_8  unique_nonzero_owner_349  1
    service_2_26_8  service_visit_def_1647  1
    service_2_26_8  free_load_conservation_1648  8
    service_0_5_0  unique_nonzero_owner_350  1
    service_0_5_0  service_visit_def_851  1
    service_0_5_0  free_load_conservation_852  -2
    service_0_5_0  original_T_including_depot_unload_864  240
    service_0_5_1  unique_nonzero_owner_351  1
    service_0_5_1  service_visit_def_851  1
    service_0_5_1  free_load_conservation_852  -1
    service_0_5_1  original_T_including_depot_unload_864  120
    service_0_5_3  unique_nonzero_owner_352  1
    service_0_5_3  service_visit_def_851  1
    service_0_5_3  free_load_conservation_852  1
    service_0_5_4  unique_nonzero_owner_353  1
    service_0_5_4  service_visit_def_851  1
    service_0_5_4  free_load_conservation_852  2
    service_0_5_5  unique_nonzero_owner_354  1
    service_0_5_5  service_visit_def_851  1
    service_0_5_5  free_load_conservation_852  3
    service_0_5_6  unique_nonzero_owner_355  1
    service_0_5_6  service_visit_def_851  1
    service_0_5_6  free_load_conservation_852  4
    service_0_5_7  unique_nonzero_owner_356  1
    service_0_5_7  service_visit_def_851  1
    service_0_5_7  free_load_conservation_852  5
    service_0_5_8  unique_nonzero_owner_357  1
    service_0_5_8  service_visit_def_851  1
    service_0_5_8  free_load_conservation_852  6
    service_0_5_9  unique_nonzero_owner_358  1
    service_0_5_9  service_visit_def_851  1
    service_0_5_9  free_load_conservation_852  7
    service_0_5_10  unique_nonzero_owner_359  1
    service_0_5_10  service_visit_def_851  1
    service_0_5_10  free_load_conservation_852  8
    service_0_5_11  unique_nonzero_owner_360  1
    service_0_5_11  service_visit_def_851  1
    service_0_5_11  free_load_conservation_852  9
    service_0_5_12  unique_nonzero_owner_361  1
    service_0_5_12  service_visit_def_851  1
    service_0_5_12  free_load_conservation_852  10
    service_0_5_13  unique_nonzero_owner_362  1
    service_0_5_13  service_visit_def_851  1
    service_0_5_13  free_load_conservation_852  11
    service_0_5_14  unique_nonzero_owner_363  1
    service_0_5_14  service_visit_def_851  1
    service_0_5_14  free_load_conservation_852  12
    service_0_5_15  unique_nonzero_owner_364  1
    service_0_5_15  service_visit_def_851  1
    service_0_5_15  free_load_conservation_852  13
    service_0_5_16  unique_nonzero_owner_365  1
    service_0_5_16  service_visit_def_851  1
    service_0_5_16  free_load_conservation_852  14
    service_1_5_0  unique_nonzero_owner_350  1
    service_1_5_0  service_visit_def_1281  1
    service_1_5_0  free_load_conservation_1282  -2
    service_1_5_0  original_T_including_depot_unload_1293  240
    service_1_5_1  unique_nonzero_owner_351  1
    service_1_5_1  service_visit_def_1281  1
    service_1_5_1  free_load_conservation_1282  -1
    service_1_5_1  original_T_including_depot_unload_1293  120
    service_1_5_3  unique_nonzero_owner_352  1
    service_1_5_3  service_visit_def_1281  1
    service_1_5_3  free_load_conservation_1282  1
    service_1_5_4  unique_nonzero_owner_353  1
    service_1_5_4  service_visit_def_1281  1
    service_1_5_4  free_load_conservation_1282  2
    service_1_5_5  unique_nonzero_owner_354  1
    service_1_5_5  service_visit_def_1281  1
    service_1_5_5  free_load_conservation_1282  3
    service_1_5_6  unique_nonzero_owner_355  1
    service_1_5_6  service_visit_def_1281  1
    service_1_5_6  free_load_conservation_1282  4
    service_1_5_7  unique_nonzero_owner_356  1
    service_1_5_7  service_visit_def_1281  1
    service_1_5_7  free_load_conservation_1282  5
    service_1_5_8  unique_nonzero_owner_357  1
    service_1_5_8  service_visit_def_1281  1
    service_1_5_8  free_load_conservation_1282  6
    service_1_5_9  unique_nonzero_owner_358  1
    service_1_5_9  service_visit_def_1281  1
    service_1_5_9  free_load_conservation_1282  7
    service_1_5_10  unique_nonzero_owner_359  1
    service_1_5_10  service_visit_def_1281  1
    service_1_5_10  free_load_conservation_1282  8
    service_1_5_11  unique_nonzero_owner_360  1
    service_1_5_11  service_visit_def_1281  1
    service_1_5_11  free_load_conservation_1282  9
    service_1_5_12  unique_nonzero_owner_361  1
    service_1_5_12  service_visit_def_1281  1
    service_1_5_12  free_load_conservation_1282  10
    service_1_5_13  unique_nonzero_owner_362  1
    service_1_5_13  service_visit_def_1281  1
    service_1_5_13  free_load_conservation_1282  11
    service_1_5_14  unique_nonzero_owner_363  1
    service_1_5_14  service_visit_def_1281  1
    service_1_5_14  free_load_conservation_1282  12
    service_1_5_15  unique_nonzero_owner_364  1
    service_1_5_15  service_visit_def_1281  1
    service_1_5_15  free_load_conservation_1282  13
    service_1_5_16  unique_nonzero_owner_365  1
    service_1_5_16  service_visit_def_1281  1
    service_1_5_16  free_load_conservation_1282  14
    service_2_5_0  unique_nonzero_owner_350  1
    service_2_5_0  service_visit_def_1653  1
    service_2_5_0  free_load_conservation_1654  -2
    service_2_5_0  original_T_including_depot_unload_1664  240
    service_2_5_1  unique_nonzero_owner_351  1
    service_2_5_1  service_visit_def_1653  1
    service_2_5_1  free_load_conservation_1654  -1
    service_2_5_1  original_T_including_depot_unload_1664  120
    service_2_5_3  unique_nonzero_owner_352  1
    service_2_5_3  service_visit_def_1653  1
    service_2_5_3  free_load_conservation_1654  1
    service_2_5_4  unique_nonzero_owner_353  1
    service_2_5_4  service_visit_def_1653  1
    service_2_5_4  free_load_conservation_1654  2
    service_2_5_5  unique_nonzero_owner_354  1
    service_2_5_5  service_visit_def_1653  1
    service_2_5_5  free_load_conservation_1654  3
    service_2_5_6  unique_nonzero_owner_355  1
    service_2_5_6  service_visit_def_1653  1
    service_2_5_6  free_load_conservation_1654  4
    service_2_5_7  unique_nonzero_owner_356  1
    service_2_5_7  service_visit_def_1653  1
    service_2_5_7  free_load_conservation_1654  5
    service_2_5_8  unique_nonzero_owner_357  1
    service_2_5_8  service_visit_def_1653  1
    service_2_5_8  free_load_conservation_1654  6
    service_2_5_9  unique_nonzero_owner_358  1
    service_2_5_9  service_visit_def_1653  1
    service_2_5_9  free_load_conservation_1654  7
    service_2_5_10  unique_nonzero_owner_359  1
    service_2_5_10  service_visit_def_1653  1
    service_2_5_10  free_load_conservation_1654  8
    service_2_5_11  unique_nonzero_owner_360  1
    service_2_5_11  service_visit_def_1653  1
    service_2_5_11  free_load_conservation_1654  9
    service_2_5_12  unique_nonzero_owner_361  1
    service_2_5_12  service_visit_def_1653  1
    service_2_5_12  free_load_conservation_1654  10
    service_2_5_13  unique_nonzero_owner_362  1
    service_2_5_13  service_visit_def_1653  1
    service_2_5_13  free_load_conservation_1654  11
    service_2_5_14  unique_nonzero_owner_363  1
    service_2_5_14  service_visit_def_1653  1
    service_2_5_14  free_load_conservation_1654  12
    service_2_5_15  unique_nonzero_owner_364  1
    service_2_5_15  service_visit_def_1653  1
    service_2_5_15  free_load_conservation_1654  13
    service_2_5_16  unique_nonzero_owner_365  1
    service_2_5_16  service_visit_def_1653  1
    service_2_5_16  free_load_conservation_1654  14
    service_0_19_1  unique_nonzero_owner_366  1
    service_0_19_1  service_visit_def_857  1
    service_0_19_1  free_load_conservation_858  1
    service_0_19_2  unique_nonzero_owner_367  1
    service_0_19_2  service_visit_def_857  1
    service_0_19_2  free_load_conservation_858  2
    service_0_19_3  unique_nonzero_owner_368  1
    service_0_19_3  service_visit_def_857  1
    service_0_19_3  free_load_conservation_858  3
    service_0_19_4  unique_nonzero_owner_369  1
    service_0_19_4  service_visit_def_857  1
    service_0_19_4  free_load_conservation_858  4
    service_0_19_5  unique_nonzero_owner_370  1
    service_0_19_5  service_visit_def_857  1
    service_0_19_5  free_load_conservation_858  5
    service_0_19_6  unique_nonzero_owner_371  1
    service_0_19_6  service_visit_def_857  1
    service_0_19_6  free_load_conservation_858  6
    service_0_19_7  unique_nonzero_owner_372  1
    service_0_19_7  service_visit_def_857  1
    service_0_19_7  free_load_conservation_858  7
    service_0_19_8  unique_nonzero_owner_373  1
    service_0_19_8  service_visit_def_857  1
    service_0_19_8  free_load_conservation_858  8
    service_1_19_1  unique_nonzero_owner_366  1
    service_1_19_1  service_visit_def_1287  1
    service_1_19_1  free_load_conservation_1288  1
    service_1_19_2  unique_nonzero_owner_367  1
    service_1_19_2  service_visit_def_1287  1
    service_1_19_2  free_load_conservation_1288  2
    service_1_19_3  unique_nonzero_owner_368  1
    service_1_19_3  service_visit_def_1287  1
    service_1_19_3  free_load_conservation_1288  3
    service_1_19_4  unique_nonzero_owner_369  1
    service_1_19_4  service_visit_def_1287  1
    service_1_19_4  free_load_conservation_1288  4
    service_1_19_5  unique_nonzero_owner_370  1
    service_1_19_5  service_visit_def_1287  1
    service_1_19_5  free_load_conservation_1288  5
    service_1_19_6  unique_nonzero_owner_371  1
    service_1_19_6  service_visit_def_1287  1
    service_1_19_6  free_load_conservation_1288  6
    service_1_19_7  unique_nonzero_owner_372  1
    service_1_19_7  service_visit_def_1287  1
    service_1_19_7  free_load_conservation_1288  7
    service_1_19_8  unique_nonzero_owner_373  1
    service_1_19_8  service_visit_def_1287  1
    service_1_19_8  free_load_conservation_1288  8
    service_2_19_1  unique_nonzero_owner_366  1
    service_2_19_1  service_visit_def_1659  1
    service_2_19_1  free_load_conservation_1660  1
    service_2_19_2  unique_nonzero_owner_367  1
    service_2_19_2  service_visit_def_1659  1
    service_2_19_2  free_load_conservation_1660  2
    service_2_19_3  unique_nonzero_owner_368  1
    service_2_19_3  service_visit_def_1659  1
    service_2_19_3  free_load_conservation_1660  3
    service_2_19_4  unique_nonzero_owner_369  1
    service_2_19_4  service_visit_def_1659  1
    service_2_19_4  free_load_conservation_1660  4
    service_2_19_5  unique_nonzero_owner_370  1
    service_2_19_5  service_visit_def_1659  1
    service_2_19_5  free_load_conservation_1660  5
    service_2_19_6  unique_nonzero_owner_371  1
    service_2_19_6  service_visit_def_1659  1
    service_2_19_6  free_load_conservation_1660  6
    service_2_19_7  unique_nonzero_owner_372  1
    service_2_19_7  service_visit_def_1659  1
    service_2_19_7  free_load_conservation_1660  7
    service_2_19_8  unique_nonzero_owner_373  1
    service_2_19_8  service_visit_def_1659  1
    service_2_19_8  free_load_conservation_1660  8
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_769  -1
    visit_0_1  in_degree_770  -1
    visit_0_1  order_active_lb_771  -1
    visit_0_1  order_active_ub_772  -14
    order_0_1  connected_order_arc_391  -1
    order_0_1  connected_order_arc_393  -1
    order_0_1  connected_order_arc_395  -1
    order_0_1  connected_order_arc_397  -1
    order_0_1  connected_order_arc_399  -1
    order_0_1  connected_order_arc_401  -1
    order_0_1  connected_order_arc_403  -1
    order_0_1  connected_order_arc_405  -1
    order_0_1  connected_order_arc_407  -1
    order_0_1  connected_order_arc_409  -1
    order_0_1  connected_order_arc_411  -1
    order_0_1  connected_order_arc_413  -1
    order_0_1  connected_order_arc_415  -1
    order_0_1  connected_order_arc_418  1
    order_0_1  connected_order_arc_445  1
    order_0_1  connected_order_arc_472  1
    order_0_1  connected_order_arc_499  1
    order_0_1  connected_order_arc_526  1
    order_0_1  connected_order_arc_553  1
    order_0_1  connected_order_arc_580  1
    order_0_1  connected_order_arc_607  1
    order_0_1  connected_order_arc_634  1
    order_0_1  connected_order_arc_661  1
    order_0_1  connected_order_arc_688  1
    order_0_1  connected_order_arc_715  1
    order_0_1  connected_order_arc_742  1
    order_0_1  order_active_lb_771  1
    order_0_1  order_active_ub_772  1
    order_0_1  fixed_segment_relative_order_859  -1
    visit_0_2  out_degree_776  -1
    visit_0_2  in_degree_777  -1
    visit_0_2  order_active_lb_778  -1
    visit_0_2  order_active_ub_779  -14
    order_0_2  connected_order_arc_391  1
    order_0_2  connected_order_arc_418  -1
    order_0_2  connected_order_arc_420  -1
    order_0_2  connected_order_arc_422  -1
    order_0_2  connected_order_arc_424  -1
    order_0_2  connected_order_arc_426  -1
    order_0_2  connected_order_arc_428  -1
    order_0_2  connected_order_arc_430  -1
    order_0_2  connected_order_arc_432  -1
    order_0_2  connected_order_arc_434  -1
    order_0_2  connected_order_arc_436  -1
    order_0_2  connected_order_arc_438  -1
    order_0_2  connected_order_arc_440  -1
    order_0_2  connected_order_arc_442  -1
    order_0_2  connected_order_arc_447  1
    order_0_2  connected_order_arc_474  1
    order_0_2  connected_order_arc_501  1
    order_0_2  connected_order_arc_528  1
    order_0_2  connected_order_arc_555  1
    order_0_2  connected_order_arc_582  1
    order_0_2  connected_order_arc_609  1
    order_0_2  connected_order_arc_636  1
    order_0_2  connected_order_arc_663  1
    order_0_2  connected_order_arc_690  1
    order_0_2  connected_order_arc_717  1
    order_0_2  connected_order_arc_744  1
    order_0_2  order_active_lb_778  1
    order_0_2  order_active_ub_779  1
    order_0_2  fixed_segment_relative_order_859  1
    order_0_2  fixed_segment_relative_order_860  -1
    visit_0_3  out_degree_783  -1
    visit_0_3  in_degree_784  -1
    visit_0_3  order_active_lb_785  -1
    visit_0_3  order_active_ub_786  -14
    order_0_3  connected_order_arc_393  1
    order_0_3  connected_order_arc_420  1
    order_0_3  connected_order_arc_445  -1
    order_0_3  connected_order_arc_447  -1
    order_0_3  connected_order_arc_449  -1
    order_0_3  connected_order_arc_451  -1
    order_0_3  connected_order_arc_453  -1
    order_0_3  connected_order_arc_455  -1
    order_0_3  connected_order_arc_457  -1
    order_0_3  connected_order_arc_459  -1
    order_0_3  connected_order_arc_461  -1
    order_0_3  connected_order_arc_463  -1
    order_0_3  connected_order_arc_465  -1
    order_0_3  connected_order_arc_467  -1
    order_0_3  connected_order_arc_469  -1
    order_0_3  connected_order_arc_476  1
    order_0_3  connected_order_arc_503  1
    order_0_3  connected_order_arc_530  1
    order_0_3  connected_order_arc_557  1
    order_0_3  connected_order_arc_584  1
    order_0_3  connected_order_arc_611  1
    order_0_3  connected_order_arc_638  1
    order_0_3  connected_order_arc_665  1
    order_0_3  connected_order_arc_692  1
    order_0_3  connected_order_arc_719  1
    order_0_3  connected_order_arc_746  1
    order_0_3  order_active_lb_785  1
    order_0_3  order_active_ub_786  1
    order_0_3  fixed_segment_relative_order_860  1
    order_0_3  fixed_segment_relative_order_861  -1
    visit_0_4  out_degree_790  -1
    visit_0_4  in_degree_791  -1
    visit_0_4  order_active_lb_792  -1
    visit_0_4  order_active_ub_793  -14
    order_0_4  connected_order_arc_395  1
    order_0_4  connected_order_arc_422  1
    order_0_4  connected_order_arc_449  1
    order_0_4  connected_order_arc_472  -1
    order_0_4  connected_order_arc_474  -1
    order_0_4  connected_order_arc_476  -1
    order_0_4  connected_order_arc_478  -1
    order_0_4  connected_order_arc_480  -1
    order_0_4  connected_order_arc_482  -1
    order_0_4  connected_order_arc_484  -1
    order_0_4  connected_order_arc_486  -1
    order_0_4  connected_order_arc_488  -1
    order_0_4  connected_order_arc_490  -1
    order_0_4  connected_order_arc_492  -1
    order_0_4  connected_order_arc_494  -1
    order_0_4  connected_order_arc_496  -1
    order_0_4  connected_order_arc_505  1
    order_0_4  connected_order_arc_532  1
    order_0_4  connected_order_arc_559  1
    order_0_4  connected_order_arc_586  1
    order_0_4  connected_order_arc_613  1
    order_0_4  connected_order_arc_640  1
    order_0_4  connected_order_arc_667  1
    order_0_4  connected_order_arc_694  1
    order_0_4  connected_order_arc_721  1
    order_0_4  connected_order_arc_748  1
    order_0_4  order_active_lb_792  1
    order_0_4  order_active_ub_793  1
    order_0_4  fixed_segment_relative_order_861  1
    order_0_4  fixed_segment_relative_order_862  -1
    visit_0_5  out_degree_797  -1
    visit_0_5  in_degree_798  -1
    visit_0_5  order_active_lb_799  -1
    visit_0_5  order_active_ub_800  -14
    order_0_5  connected_order_arc_397  1
    order_0_5  connected_order_arc_424  1
    order_0_5  connected_order_arc_451  1
    order_0_5  connected_order_arc_478  1
    order_0_5  connected_order_arc_499  -1
    order_0_5  connected_order_arc_501  -1
    order_0_5  connected_order_arc_503  -1
    order_0_5  connected_order_arc_505  -1
    order_0_5  connected_order_arc_507  -1
    order_0_5  connected_order_arc_509  -1
    order_0_5  connected_order_arc_511  -1
    order_0_5  connected_order_arc_513  -1
    order_0_5  connected_order_arc_515  -1
    order_0_5  connected_order_arc_517  -1
    order_0_5  connected_order_arc_519  -1
    order_0_5  connected_order_arc_521  -1
    order_0_5  connected_order_arc_523  -1
    order_0_5  connected_order_arc_534  1
    order_0_5  connected_order_arc_561  1
    order_0_5  connected_order_arc_588  1
    order_0_5  connected_order_arc_615  1
    order_0_5  connected_order_arc_642  1
    order_0_5  connected_order_arc_669  1
    order_0_5  connected_order_arc_696  1
    order_0_5  connected_order_arc_723  1
    order_0_5  connected_order_arc_750  1
    order_0_5  order_active_lb_799  1
    order_0_5  order_active_ub_800  1
    order_0_5  fixed_segment_relative_order_862  1
    order_0_5  fixed_segment_relative_order_863  -1
    visit_0_6  out_degree_804  -1
    visit_0_6  in_degree_805  -1
    visit_0_6  order_active_lb_806  -1
    visit_0_6  order_active_ub_807  -14
    order_0_6  connected_order_arc_399  1
    order_0_6  connected_order_arc_426  1
    order_0_6  connected_order_arc_453  1
    order_0_6  connected_order_arc_480  1
    order_0_6  connected_order_arc_507  1
    order_0_6  connected_order_arc_526  -1
    order_0_6  connected_order_arc_528  -1
    order_0_6  connected_order_arc_530  -1
    order_0_6  connected_order_arc_532  -1
    order_0_6  connected_order_arc_534  -1
    order_0_6  connected_order_arc_536  -1
    order_0_6  connected_order_arc_538  -1
    order_0_6  connected_order_arc_540  -1
    order_0_6  connected_order_arc_542  -1
    order_0_6  connected_order_arc_544  -1
    order_0_6  connected_order_arc_546  -1
    order_0_6  connected_order_arc_548  -1
    order_0_6  connected_order_arc_550  -1
    order_0_6  connected_order_arc_563  1
    order_0_6  connected_order_arc_590  1
    order_0_6  connected_order_arc_617  1
    order_0_6  connected_order_arc_644  1
    order_0_6  connected_order_arc_671  1
    order_0_6  connected_order_arc_698  1
    order_0_6  connected_order_arc_725  1
    order_0_6  connected_order_arc_752  1
    order_0_6  order_active_lb_806  1
    order_0_6  order_active_ub_807  1
    order_0_6  fixed_segment_relative_order_863  1
    visit_0_16  out_degree_811  -1
    visit_0_16  in_degree_812  -1
    visit_0_16  order_active_lb_813  -1
    visit_0_16  order_active_ub_814  -14
    visit_0_16  service_visit_def_815  -1
    order_0_16  connected_order_arc_401  1
    order_0_16  connected_order_arc_428  1
    order_0_16  connected_order_arc_455  1
    order_0_16  connected_order_arc_482  1
    order_0_16  connected_order_arc_509  1
    order_0_16  connected_order_arc_536  1
    order_0_16  connected_order_arc_553  -1
    order_0_16  connected_order_arc_555  -1
    order_0_16  connected_order_arc_557  -1
    order_0_16  connected_order_arc_559  -1
    order_0_16  connected_order_arc_561  -1
    order_0_16  connected_order_arc_563  -1
    order_0_16  connected_order_arc_565  -1
    order_0_16  connected_order_arc_567  -1
    order_0_16  connected_order_arc_569  -1
    order_0_16  connected_order_arc_571  -1
    order_0_16  connected_order_arc_573  -1
    order_0_16  connected_order_arc_575  -1
    order_0_16  connected_order_arc_577  -1
    order_0_16  connected_order_arc_592  1
    order_0_16  connected_order_arc_619  1
    order_0_16  connected_order_arc_646  1
    order_0_16  connected_order_arc_673  1
    order_0_16  connected_order_arc_700  1
    order_0_16  connected_order_arc_727  1
    order_0_16  connected_order_arc_754  1
    order_0_16  order_active_lb_813  1
    order_0_16  order_active_ub_814  1
    visit_0_17  out_degree_817  -1
    visit_0_17  in_degree_818  -1
    visit_0_17  order_active_lb_819  -1
    visit_0_17  order_active_ub_820  -14
    visit_0_17  service_visit_def_821  -1
    order_0_17  connected_order_arc_403  1
    order_0_17  connected_order_arc_430  1
    order_0_17  connected_order_arc_457  1
    order_0_17  connected_order_arc_484  1
    order_0_17  connected_order_arc_511  1
    order_0_17  connected_order_arc_538  1
    order_0_17  connected_order_arc_565  1
    order_0_17  connected_order_arc_580  -1
    order_0_17  connected_order_arc_582  -1
    order_0_17  connected_order_arc_584  -1
    order_0_17  connected_order_arc_586  -1
    order_0_17  connected_order_arc_588  -1
    order_0_17  connected_order_arc_590  -1
    order_0_17  connected_order_arc_592  -1
    order_0_17  connected_order_arc_594  -1
    order_0_17  connected_order_arc_596  -1
    order_0_17  connected_order_arc_598  -1
    order_0_17  connected_order_arc_600  -1
    order_0_17  connected_order_arc_602  -1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_621  1
    order_0_17  connected_order_arc_648  1
    order_0_17  connected_order_arc_675  1
    order_0_17  connected_order_arc_702  1
    order_0_17  connected_order_arc_729  1
    order_0_17  connected_order_arc_756  1
    order_0_17  order_active_lb_819  1
    order_0_17  order_active_ub_820  1
    visit_0_18  out_degree_823  -1
    visit_0_18  in_degree_824  -1
    visit_0_18  order_active_lb_825  -1
    visit_0_18  order_active_ub_826  -14
    visit_0_18  service_visit_def_827  -1
    order_0_18  connected_order_arc_405  1
    order_0_18  connected_order_arc_432  1
    order_0_18  connected_order_arc_459  1
    order_0_18  connected_order_arc_486  1
    order_0_18  connected_order_arc_513  1
    order_0_18  connected_order_arc_540  1
    order_0_18  connected_order_arc_567  1
    order_0_18  connected_order_arc_594  1
    order_0_18  connected_order_arc_607  -1
    order_0_18  connected_order_arc_609  -1
    order_0_18  connected_order_arc_611  -1
    order_0_18  connected_order_arc_613  -1
    order_0_18  connected_order_arc_615  -1
    order_0_18  connected_order_arc_617  -1
    order_0_18  connected_order_arc_619  -1
    order_0_18  connected_order_arc_621  -1
    order_0_18  connected_order_arc_623  -1
    order_0_18  connected_order_arc_625  -1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_650  1
    order_0_18  connected_order_arc_677  1
    order_0_18  connected_order_arc_704  1
    order_0_18  connected_order_arc_731  1
    order_0_18  connected_order_arc_758  1
    order_0_18  order_active_lb_825  1
    order_0_18  order_active_ub_826  1
    visit_0_19  out_degree_829  -1
    visit_0_19  in_degree_830  -1
    visit_0_19  order_active_lb_831  -1
    visit_0_19  order_active_ub_832  -14
    visit_0_19  service_visit_def_833  -1
    order_0_19  connected_order_arc_407  1
    order_0_19  connected_order_arc_434  1
    order_0_19  connected_order_arc_461  1
    order_0_19  connected_order_arc_488  1
    order_0_19  connected_order_arc_515  1
    order_0_19  connected_order_arc_542  1
    order_0_19  connected_order_arc_569  1
    order_0_19  connected_order_arc_596  1
    order_0_19  connected_order_arc_623  1
    order_0_19  connected_order_arc_634  -1
    order_0_19  connected_order_arc_636  -1
    order_0_19  connected_order_arc_638  -1
    order_0_19  connected_order_arc_640  -1
    order_0_19  connected_order_arc_642  -1
    order_0_19  connected_order_arc_644  -1
    order_0_19  connected_order_arc_646  -1
    order_0_19  connected_order_arc_648  -1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_679  1
    order_0_19  connected_order_arc_706  1
    order_0_19  connected_order_arc_733  1
    order_0_19  connected_order_arc_760  1
    order_0_19  order_active_lb_831  1
    order_0_19  order_active_ub_832  1
    visit_0_20  out_degree_835  -1
    visit_0_20  in_degree_836  -1
    visit_0_20  order_active_lb_837  -1
    visit_0_20  order_active_ub_838  -14
    visit_0_20  service_visit_def_839  -1
    order_0_20  connected_order_arc_409  1
    order_0_20  connected_order_arc_436  1
    order_0_20  connected_order_arc_463  1
    order_0_20  connected_order_arc_490  1
    order_0_20  connected_order_arc_517  1
    order_0_20  connected_order_arc_544  1
    order_0_20  connected_order_arc_571  1
    order_0_20  connected_order_arc_598  1
    order_0_20  connected_order_arc_625  1
    order_0_20  connected_order_arc_652  1
    order_0_20  connected_order_arc_661  -1
    order_0_20  connected_order_arc_663  -1
    order_0_20  connected_order_arc_665  -1
    order_0_20  connected_order_arc_667  -1
    order_0_20  connected_order_arc_669  -1
    order_0_20  connected_order_arc_671  -1
    order_0_20  connected_order_arc_673  -1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_708  1
    order_0_20  connected_order_arc_735  1
    order_0_20  connected_order_arc_762  1
    order_0_20  order_active_lb_837  1
    order_0_20  order_active_ub_838  1
    visit_0_21  out_degree_841  -1
    visit_0_21  in_degree_842  -1
    visit_0_21  order_active_lb_843  -1
    visit_0_21  order_active_ub_844  -14
    visit_0_21  service_visit_def_845  -1
    order_0_21  connected_order_arc_411  1
    order_0_21  connected_order_arc_438  1
    order_0_21  connected_order_arc_465  1
    order_0_21  connected_order_arc_492  1
    order_0_21  connected_order_arc_519  1
    order_0_21  connected_order_arc_546  1
    order_0_21  connected_order_arc_573  1
    order_0_21  connected_order_arc_600  1
    order_0_21  connected_order_arc_627  1
    order_0_21  connected_order_arc_654  1
    order_0_21  connected_order_arc_681  1
    order_0_21  connected_order_arc_688  -1
    order_0_21  connected_order_arc_690  -1
    order_0_21  connected_order_arc_692  -1
    order_0_21  connected_order_arc_694  -1
    order_0_21  connected_order_arc_696  -1
    order_0_21  connected_order_arc_698  -1
    order_0_21  connected_order_arc_700  -1
    order_0_21  connected_order_arc_702  -1
    order_0_21  connected_order_arc_704  -1
    order_0_21  connected_order_arc_706  -1
    order_0_21  connected_order_arc_708  -1
    order_0_21  connected_order_arc_710  -1
    order_0_21  connected_order_arc_712  -1
    order_0_21  connected_order_arc_737  1
    order_0_21  connected_order_arc_764  1
    order_0_21  order_active_lb_843  1
    order_0_21  order_active_ub_844  1
    visit_0_22  out_degree_847  -1
    visit_0_22  in_degree_848  -1
    visit_0_22  order_active_lb_849  -1
    visit_0_22  order_active_ub_850  -14
    visit_0_22  service_visit_def_851  -1
    order_0_22  connected_order_arc_413  1
    order_0_22  connected_order_arc_440  1
    order_0_22  connected_order_arc_467  1
    order_0_22  connected_order_arc_494  1
    order_0_22  connected_order_arc_521  1
    order_0_22  connected_order_arc_548  1
    order_0_22  connected_order_arc_575  1
    order_0_22  connected_order_arc_602  1
    order_0_22  connected_order_arc_629  1
    order_0_22  connected_order_arc_656  1
    order_0_22  connected_order_arc_683  1
    order_0_22  connected_order_arc_710  1
    order_0_22  connected_order_arc_715  -1
    order_0_22  connected_order_arc_717  -1
    order_0_22  connected_order_arc_719  -1
    order_0_22  connected_order_arc_721  -1
    order_0_22  connected_order_arc_723  -1
    order_0_22  connected_order_arc_725  -1
    order_0_22  connected_order_arc_727  -1
    order_0_22  connected_order_arc_729  -1
    order_0_22  connected_order_arc_731  -1
    order_0_22  connected_order_arc_733  -1
    order_0_22  connected_order_arc_735  -1
    order_0_22  connected_order_arc_737  -1
    order_0_22  connected_order_arc_739  -1
    order_0_22  connected_order_arc_766  1
    order_0_22  order_active_lb_849  1
    order_0_22  order_active_ub_850  1
    visit_0_23  out_degree_853  -1
    visit_0_23  in_degree_854  -1
    visit_0_23  order_active_lb_855  -1
    visit_0_23  order_active_ub_856  -14
    visit_0_23  service_visit_def_857  -1
    order_0_23  connected_order_arc_415  1
    order_0_23  connected_order_arc_442  1
    order_0_23  connected_order_arc_469  1
    order_0_23  connected_order_arc_496  1
    order_0_23  connected_order_arc_523  1
    order_0_23  connected_order_arc_550  1
    order_0_23  connected_order_arc_577  1
    order_0_23  connected_order_arc_604  1
    order_0_23  connected_order_arc_631  1
    order_0_23  connected_order_arc_658  1
    order_0_23  connected_order_arc_685  1
    order_0_23  connected_order_arc_712  1
    order_0_23  connected_order_arc_739  1
    order_0_23  connected_order_arc_742  -1
    order_0_23  connected_order_arc_744  -1
    order_0_23  connected_order_arc_746  -1
    order_0_23  connected_order_arc_748  -1
    order_0_23  connected_order_arc_750  -1
    order_0_23  connected_order_arc_752  -1
    order_0_23  connected_order_arc_754  -1
    order_0_23  connected_order_arc_756  -1
    order_0_23  connected_order_arc_758  -1
    order_0_23  connected_order_arc_760  -1
    order_0_23  connected_order_arc_762  -1
    order_0_23  connected_order_arc_764  -1
    order_0_23  connected_order_arc_766  -1
    order_0_23  order_active_lb_855  1
    order_0_23  order_active_ub_856  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_374  -20
    arc_0_0_0  depot_departure_or_bypass_767  1
    arc_0_0_0  depot_return_or_bypass_768  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_374  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_375  -20
    arc_0_0_1  depot_departure_or_bypass_767  1
    arc_0_0_1  in_degree_770  1
    arc_0_0_1  original_T_including_depot_unload_864  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_375  1
    load_0_0_1  segment_load_conservation_773  -1
    load_0_0_1  segment_prefix_lb_774  1
    load_0_0_1  segment_prefix_ub_775  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_376  -20
    arc_0_0_2  depot_departure_or_bypass_767  1
    arc_0_0_2  in_degree_777  1
    arc_0_0_2  original_T_including_depot_unload_864  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_376  1
    load_0_0_2  segment_load_conservation_780  -1
    load_0_0_2  segment_prefix_lb_781  1
    load_0_0_2  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_377  -20
    arc_0_0_3  depot_departure_or_bypass_767  1
    arc_0_0_3  in_degree_784  1
    arc_0_0_3  original_T_including_depot_unload_864  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_377  1
    load_0_0_3  segment_load_conservation_787  -1
    load_0_0_3  segment_prefix_lb_788  1
    load_0_0_3  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_378  -20
    arc_0_0_4  depot_departure_or_bypass_767  1
    arc_0_0_4  in_degree_791  1
    arc_0_0_4  original_T_including_depot_unload_864  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_378  1
    load_0_0_4  segment_load_conservation_794  -1
    load_0_0_4  segment_prefix_lb_795  1
    load_0_0_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_379  -20
    arc_0_0_5  depot_departure_or_bypass_767  1
    arc_0_0_5  in_degree_798  1
    arc_0_0_5  original_T_including_depot_unload_864  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_379  1
    load_0_0_5  segment_load_conservation_801  -1
    load_0_0_5  segment_prefix_lb_802  1
    load_0_0_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_380  -20
    arc_0_0_6  depot_departure_or_bypass_767  1
    arc_0_0_6  in_degree_805  1
    arc_0_0_6  original_T_including_depot_unload_864  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_380  1
    load_0_0_6  segment_load_conservation_808  -1
    load_0_0_6  segment_prefix_lb_809  1
    load_0_0_6  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_381  -20
    arc_0_0_16  depot_departure_or_bypass_767  1
    arc_0_0_16  in_degree_812  1
    arc_0_0_16  original_T_including_depot_unload_864  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_381  1
    load_0_0_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_382  -20
    arc_0_0_17  depot_departure_or_bypass_767  1
    arc_0_0_17  in_degree_818  1
    arc_0_0_17  original_T_including_depot_unload_864  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_382  1
    load_0_0_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_383  -20
    arc_0_0_18  depot_departure_or_bypass_767  1
    arc_0_0_18  in_degree_824  1
    arc_0_0_18  original_T_including_depot_unload_864  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_383  1
    load_0_0_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_384  -20
    arc_0_0_19  depot_departure_or_bypass_767  1
    arc_0_0_19  in_degree_830  1
    arc_0_0_19  original_T_including_depot_unload_864  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_384  1
    load_0_0_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_385  -20
    arc_0_0_20  depot_departure_or_bypass_767  1
    arc_0_0_20  in_degree_836  1
    arc_0_0_20  original_T_including_depot_unload_864  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_385  1
    load_0_0_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_386  -20
    arc_0_0_21  depot_departure_or_bypass_767  1
    arc_0_0_21  in_degree_842  1
    arc_0_0_21  original_T_including_depot_unload_864  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_386  1
    load_0_0_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_387  -20
    arc_0_0_22  depot_departure_or_bypass_767  1
    arc_0_0_22  in_degree_848  1
    arc_0_0_22  original_T_including_depot_unload_864  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_387  1
    load_0_0_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_23  arc_capacity_388  -20
    arc_0_0_23  depot_departure_or_bypass_767  1
    arc_0_0_23  in_degree_854  1
    arc_0_0_23  original_T_including_depot_unload_864  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_23  arc_capacity_388  1
    load_0_0_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_389  -20
    arc_0_1_0  depot_return_or_bypass_768  1
    arc_0_1_0  out_degree_769  1
    arc_0_1_0  original_T_including_depot_unload_864  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_389  1
    load_0_1_0  segment_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_390  -20
    arc_0_1_2  connected_order_arc_391  -15
    arc_0_1_2  out_degree_769  1
    arc_0_1_2  in_degree_777  1
    arc_0_1_2  original_T_including_depot_unload_864  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_390  1
    load_0_1_2  segment_load_conservation_773  1
    load_0_1_2  segment_load_conservation_780  -1
    load_0_1_2  segment_prefix_lb_781  1
    load_0_1_2  segment_prefix_ub_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_392  -20
    arc_0_1_3  connected_order_arc_393  -15
    arc_0_1_3  out_degree_769  1
    arc_0_1_3  in_degree_784  1
    arc_0_1_3  original_T_including_depot_unload_864  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_392  1
    load_0_1_3  segment_load_conservation_773  1
    load_0_1_3  segment_load_conservation_787  -1
    load_0_1_3  segment_prefix_lb_788  1
    load_0_1_3  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_394  -20
    arc_0_1_4  connected_order_arc_395  -15
    arc_0_1_4  out_degree_769  1
    arc_0_1_4  in_degree_791  1
    arc_0_1_4  original_T_including_depot_unload_864  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_394  1
    load_0_1_4  segment_load_conservation_773  1
    load_0_1_4  segment_load_conservation_794  -1
    load_0_1_4  segment_prefix_lb_795  1
    load_0_1_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_396  -20
    arc_0_1_5  connected_order_arc_397  -15
    arc_0_1_5  out_degree_769  1
    arc_0_1_5  in_degree_798  1
    arc_0_1_5  original_T_including_depot_unload_864  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_396  1
    load_0_1_5  segment_load_conservation_773  1
    load_0_1_5  segment_load_conservation_801  -1
    load_0_1_5  segment_prefix_lb_802  1
    load_0_1_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_398  -20
    arc_0_1_6  connected_order_arc_399  -15
    arc_0_1_6  out_degree_769  1
    arc_0_1_6  in_degree_805  1
    arc_0_1_6  original_T_including_depot_unload_864  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_398  1
    load_0_1_6  segment_load_conservation_773  1
    load_0_1_6  segment_load_conservation_808  -1
    load_0_1_6  segment_prefix_lb_809  1
    load_0_1_6  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_400  -20
    arc_0_1_16  connected_order_arc_401  -15
    arc_0_1_16  out_degree_769  1
    arc_0_1_16  in_degree_812  1
    arc_0_1_16  original_T_including_depot_unload_864  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_400  1
    load_0_1_16  segment_load_conservation_773  1
    load_0_1_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_402  -20
    arc_0_1_17  connected_order_arc_403  -15
    arc_0_1_17  out_degree_769  1
    arc_0_1_17  in_degree_818  1
    arc_0_1_17  original_T_including_depot_unload_864  1.7022035239152008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_402  1
    load_0_1_17  segment_load_conservation_773  1
    load_0_1_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_404  -20
    arc_0_1_18  connected_order_arc_405  -15
    arc_0_1_18  out_degree_769  1
    arc_0_1_18  in_degree_824  1
    arc_0_1_18  original_T_including_depot_unload_864  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_404  1
    load_0_1_18  segment_load_conservation_773  1
    load_0_1_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_406  -20
    arc_0_1_19  connected_order_arc_407  -15
    arc_0_1_19  out_degree_769  1
    arc_0_1_19  in_degree_830  1
    arc_0_1_19  original_T_including_depot_unload_864  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_406  1
    load_0_1_19  segment_load_conservation_773  1
    load_0_1_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_408  -20
    arc_0_1_20  connected_order_arc_409  -15
    arc_0_1_20  out_degree_769  1
    arc_0_1_20  in_degree_836  1
    arc_0_1_20  original_T_including_depot_unload_864  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_408  1
    load_0_1_20  segment_load_conservation_773  1
    load_0_1_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_410  -20
    arc_0_1_21  connected_order_arc_411  -15
    arc_0_1_21  out_degree_769  1
    arc_0_1_21  in_degree_842  1
    arc_0_1_21  original_T_including_depot_unload_864  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_410  1
    load_0_1_21  segment_load_conservation_773  1
    load_0_1_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_412  -20
    arc_0_1_22  connected_order_arc_413  -15
    arc_0_1_22  out_degree_769  1
    arc_0_1_22  in_degree_848  1
    arc_0_1_22  original_T_including_depot_unload_864  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_412  1
    load_0_1_22  segment_load_conservation_773  1
    load_0_1_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_23  arc_capacity_414  -20
    arc_0_1_23  connected_order_arc_415  -15
    arc_0_1_23  out_degree_769  1
    arc_0_1_23  in_degree_854  1
    arc_0_1_23  original_T_including_depot_unload_864  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_23  arc_capacity_414  1
    load_0_1_23  segment_load_conservation_773  1
    load_0_1_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_416  -20
    arc_0_2_0  depot_return_or_bypass_768  1
    arc_0_2_0  out_degree_776  1
    arc_0_2_0  original_T_including_depot_unload_864  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_416  1
    load_0_2_0  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_417  -20
    arc_0_2_1  connected_order_arc_418  -15
    arc_0_2_1  in_degree_770  1
    arc_0_2_1  out_degree_776  1
    arc_0_2_1  original_T_including_depot_unload_864  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_417  1
    load_0_2_1  segment_load_conservation_773  -1
    load_0_2_1  segment_prefix_lb_774  1
    load_0_2_1  segment_prefix_ub_775  1
    load_0_2_1  segment_load_conservation_780  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_419  -20
    arc_0_2_3  connected_order_arc_420  -15
    arc_0_2_3  out_degree_776  1
    arc_0_2_3  in_degree_784  1
    arc_0_2_3  original_T_including_depot_unload_864  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_419  1
    load_0_2_3  segment_load_conservation_780  1
    load_0_2_3  segment_load_conservation_787  -1
    load_0_2_3  segment_prefix_lb_788  1
    load_0_2_3  segment_prefix_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_421  -20
    arc_0_2_4  connected_order_arc_422  -15
    arc_0_2_4  out_degree_776  1
    arc_0_2_4  in_degree_791  1
    arc_0_2_4  original_T_including_depot_unload_864  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_421  1
    load_0_2_4  segment_load_conservation_780  1
    load_0_2_4  segment_load_conservation_794  -1
    load_0_2_4  segment_prefix_lb_795  1
    load_0_2_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_423  -20
    arc_0_2_5  connected_order_arc_424  -15
    arc_0_2_5  out_degree_776  1
    arc_0_2_5  in_degree_798  1
    arc_0_2_5  original_T_including_depot_unload_864  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_423  1
    load_0_2_5  segment_load_conservation_780  1
    load_0_2_5  segment_load_conservation_801  -1
    load_0_2_5  segment_prefix_lb_802  1
    load_0_2_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_425  -20
    arc_0_2_6  connected_order_arc_426  -15
    arc_0_2_6  out_degree_776  1
    arc_0_2_6  in_degree_805  1
    arc_0_2_6  original_T_including_depot_unload_864  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_425  1
    load_0_2_6  segment_load_conservation_780  1
    load_0_2_6  segment_load_conservation_808  -1
    load_0_2_6  segment_prefix_lb_809  1
    load_0_2_6  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_427  -20
    arc_0_2_16  connected_order_arc_428  -15
    arc_0_2_16  out_degree_776  1
    arc_0_2_16  in_degree_812  1
    arc_0_2_16  original_T_including_depot_unload_864  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_427  1
    load_0_2_16  segment_load_conservation_780  1
    load_0_2_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_429  -20
    arc_0_2_17  connected_order_arc_430  -15
    arc_0_2_17  out_degree_776  1
    arc_0_2_17  in_degree_818  1
    arc_0_2_17  original_T_including_depot_unload_864  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_429  1
    load_0_2_17  segment_load_conservation_780  1
    load_0_2_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_431  -20
    arc_0_2_18  connected_order_arc_432  -15
    arc_0_2_18  out_degree_776  1
    arc_0_2_18  in_degree_824  1
    arc_0_2_18  original_T_including_depot_unload_864  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_431  1
    load_0_2_18  segment_load_conservation_780  1
    load_0_2_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_433  -20
    arc_0_2_19  connected_order_arc_434  -15
    arc_0_2_19  out_degree_776  1
    arc_0_2_19  in_degree_830  1
    arc_0_2_19  original_T_including_depot_unload_864  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_433  1
    load_0_2_19  segment_load_conservation_780  1
    load_0_2_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_435  -20
    arc_0_2_20  connected_order_arc_436  -15
    arc_0_2_20  out_degree_776  1
    arc_0_2_20  in_degree_836  1
    arc_0_2_20  original_T_including_depot_unload_864  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_435  1
    load_0_2_20  segment_load_conservation_780  1
    load_0_2_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_437  -20
    arc_0_2_21  connected_order_arc_438  -15
    arc_0_2_21  out_degree_776  1
    arc_0_2_21  in_degree_842  1
    arc_0_2_21  original_T_including_depot_unload_864  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_437  1
    load_0_2_21  segment_load_conservation_780  1
    load_0_2_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_439  -20
    arc_0_2_22  connected_order_arc_440  -15
    arc_0_2_22  out_degree_776  1
    arc_0_2_22  in_degree_848  1
    arc_0_2_22  original_T_including_depot_unload_864  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_439  1
    load_0_2_22  segment_load_conservation_780  1
    load_0_2_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_23  arc_capacity_441  -20
    arc_0_2_23  connected_order_arc_442  -15
    arc_0_2_23  out_degree_776  1
    arc_0_2_23  in_degree_854  1
    arc_0_2_23  original_T_including_depot_unload_864  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_23  arc_capacity_441  1
    load_0_2_23  segment_load_conservation_780  1
    load_0_2_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_443  -20
    arc_0_3_0  depot_return_or_bypass_768  1
    arc_0_3_0  out_degree_783  1
    arc_0_3_0  original_T_including_depot_unload_864  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_443  1
    load_0_3_0  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_444  -20
    arc_0_3_1  connected_order_arc_445  -15
    arc_0_3_1  in_degree_770  1
    arc_0_3_1  out_degree_783  1
    arc_0_3_1  original_T_including_depot_unload_864  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_444  1
    load_0_3_1  segment_load_conservation_773  -1
    load_0_3_1  segment_prefix_lb_774  1
    load_0_3_1  segment_prefix_ub_775  1
    load_0_3_1  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_446  -20
    arc_0_3_2  connected_order_arc_447  -15
    arc_0_3_2  in_degree_777  1
    arc_0_3_2  out_degree_783  1
    arc_0_3_2  original_T_including_depot_unload_864  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_446  1
    load_0_3_2  segment_load_conservation_780  -1
    load_0_3_2  segment_prefix_lb_781  1
    load_0_3_2  segment_prefix_ub_782  1
    load_0_3_2  segment_load_conservation_787  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_448  -20
    arc_0_3_4  connected_order_arc_449  -15
    arc_0_3_4  out_degree_783  1
    arc_0_3_4  in_degree_791  1
    arc_0_3_4  original_T_including_depot_unload_864  3.1728416035596246e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_448  1
    load_0_3_4  segment_load_conservation_787  1
    load_0_3_4  segment_load_conservation_794  -1
    load_0_3_4  segment_prefix_lb_795  1
    load_0_3_4  segment_prefix_ub_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_450  -20
    arc_0_3_5  connected_order_arc_451  -15
    arc_0_3_5  out_degree_783  1
    arc_0_3_5  in_degree_798  1
    arc_0_3_5  original_T_including_depot_unload_864  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_450  1
    load_0_3_5  segment_load_conservation_787  1
    load_0_3_5  segment_load_conservation_801  -1
    load_0_3_5  segment_prefix_lb_802  1
    load_0_3_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_452  -20
    arc_0_3_6  connected_order_arc_453  -15
    arc_0_3_6  out_degree_783  1
    arc_0_3_6  in_degree_805  1
    arc_0_3_6  original_T_including_depot_unload_864  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_452  1
    load_0_3_6  segment_load_conservation_787  1
    load_0_3_6  segment_load_conservation_808  -1
    load_0_3_6  segment_prefix_lb_809  1
    load_0_3_6  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_454  -20
    arc_0_3_16  connected_order_arc_455  -15
    arc_0_3_16  out_degree_783  1
    arc_0_3_16  in_degree_812  1
    arc_0_3_16  original_T_including_depot_unload_864  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_454  1
    load_0_3_16  segment_load_conservation_787  1
    load_0_3_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_456  -20
    arc_0_3_17  connected_order_arc_457  -15
    arc_0_3_17  out_degree_783  1
    arc_0_3_17  in_degree_818  1
    arc_0_3_17  original_T_including_depot_unload_864  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_456  1
    load_0_3_17  segment_load_conservation_787  1
    load_0_3_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_458  -20
    arc_0_3_18  connected_order_arc_459  -15
    arc_0_3_18  out_degree_783  1
    arc_0_3_18  in_degree_824  1
    arc_0_3_18  original_T_including_depot_unload_864  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_458  1
    load_0_3_18  segment_load_conservation_787  1
    load_0_3_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_460  -20
    arc_0_3_19  connected_order_arc_461  -15
    arc_0_3_19  out_degree_783  1
    arc_0_3_19  in_degree_830  1
    arc_0_3_19  original_T_including_depot_unload_864  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_460  1
    load_0_3_19  segment_load_conservation_787  1
    load_0_3_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_462  -20
    arc_0_3_20  connected_order_arc_463  -15
    arc_0_3_20  out_degree_783  1
    arc_0_3_20  in_degree_836  1
    arc_0_3_20  original_T_including_depot_unload_864  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_462  1
    load_0_3_20  segment_load_conservation_787  1
    load_0_3_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_464  -20
    arc_0_3_21  connected_order_arc_465  -15
    arc_0_3_21  out_degree_783  1
    arc_0_3_21  in_degree_842  1
    arc_0_3_21  original_T_including_depot_unload_864  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_464  1
    load_0_3_21  segment_load_conservation_787  1
    load_0_3_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_466  -20
    arc_0_3_22  connected_order_arc_467  -15
    arc_0_3_22  out_degree_783  1
    arc_0_3_22  in_degree_848  1
    arc_0_3_22  original_T_including_depot_unload_864  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_466  1
    load_0_3_22  segment_load_conservation_787  1
    load_0_3_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_23  arc_capacity_468  -20
    arc_0_3_23  connected_order_arc_469  -15
    arc_0_3_23  out_degree_783  1
    arc_0_3_23  in_degree_854  1
    arc_0_3_23  original_T_including_depot_unload_864  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_23  arc_capacity_468  1
    load_0_3_23  segment_load_conservation_787  1
    load_0_3_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_470  -20
    arc_0_4_0  depot_return_or_bypass_768  1
    arc_0_4_0  out_degree_790  1
    arc_0_4_0  original_T_including_depot_unload_864  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_470  1
    load_0_4_0  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_471  -20
    arc_0_4_1  connected_order_arc_472  -15
    arc_0_4_1  in_degree_770  1
    arc_0_4_1  out_degree_790  1
    arc_0_4_1  original_T_including_depot_unload_864  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_471  1
    load_0_4_1  segment_load_conservation_773  -1
    load_0_4_1  segment_prefix_lb_774  1
    load_0_4_1  segment_prefix_ub_775  1
    load_0_4_1  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_473  -20
    arc_0_4_2  connected_order_arc_474  -15
    arc_0_4_2  in_degree_777  1
    arc_0_4_2  out_degree_790  1
    arc_0_4_2  original_T_including_depot_unload_864  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_473  1
    load_0_4_2  segment_load_conservation_780  -1
    load_0_4_2  segment_prefix_lb_781  1
    load_0_4_2  segment_prefix_ub_782  1
    load_0_4_2  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_475  -20
    arc_0_4_3  connected_order_arc_476  -15
    arc_0_4_3  in_degree_784  1
    arc_0_4_3  out_degree_790  1
    arc_0_4_3  original_T_including_depot_unload_864  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_475  1
    load_0_4_3  segment_load_conservation_787  -1
    load_0_4_3  segment_prefix_lb_788  1
    load_0_4_3  segment_prefix_ub_789  1
    load_0_4_3  segment_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_477  -20
    arc_0_4_5  connected_order_arc_478  -15
    arc_0_4_5  out_degree_790  1
    arc_0_4_5  in_degree_798  1
    arc_0_4_5  original_T_including_depot_unload_864  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_477  1
    load_0_4_5  segment_load_conservation_794  1
    load_0_4_5  segment_load_conservation_801  -1
    load_0_4_5  segment_prefix_lb_802  1
    load_0_4_5  segment_prefix_ub_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_479  -20
    arc_0_4_6  connected_order_arc_480  -15
    arc_0_4_6  out_degree_790  1
    arc_0_4_6  in_degree_805  1
    arc_0_4_6  original_T_including_depot_unload_864  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_479  1
    load_0_4_6  segment_load_conservation_794  1
    load_0_4_6  segment_load_conservation_808  -1
    load_0_4_6  segment_prefix_lb_809  1
    load_0_4_6  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_481  -20
    arc_0_4_16  connected_order_arc_482  -15
    arc_0_4_16  out_degree_790  1
    arc_0_4_16  in_degree_812  1
    arc_0_4_16  original_T_including_depot_unload_864  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_481  1
    load_0_4_16  segment_load_conservation_794  1
    load_0_4_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_483  -20
    arc_0_4_17  connected_order_arc_484  -15
    arc_0_4_17  out_degree_790  1
    arc_0_4_17  in_degree_818  1
    arc_0_4_17  original_T_including_depot_unload_864  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_483  1
    load_0_4_17  segment_load_conservation_794  1
    load_0_4_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_485  -20
    arc_0_4_18  connected_order_arc_486  -15
    arc_0_4_18  out_degree_790  1
    arc_0_4_18  in_degree_824  1
    arc_0_4_18  original_T_including_depot_unload_864  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_485  1
    load_0_4_18  segment_load_conservation_794  1
    load_0_4_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_487  -20
    arc_0_4_19  connected_order_arc_488  -15
    arc_0_4_19  out_degree_790  1
    arc_0_4_19  in_degree_830  1
    arc_0_4_19  original_T_including_depot_unload_864  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_487  1
    load_0_4_19  segment_load_conservation_794  1
    load_0_4_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_489  -20
    arc_0_4_20  connected_order_arc_490  -15
    arc_0_4_20  out_degree_790  1
    arc_0_4_20  in_degree_836  1
    arc_0_4_20  original_T_including_depot_unload_864  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_489  1
    load_0_4_20  segment_load_conservation_794  1
    load_0_4_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_491  -20
    arc_0_4_21  connected_order_arc_492  -15
    arc_0_4_21  out_degree_790  1
    arc_0_4_21  in_degree_842  1
    arc_0_4_21  original_T_including_depot_unload_864  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_491  1
    load_0_4_21  segment_load_conservation_794  1
    load_0_4_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_493  -20
    arc_0_4_22  connected_order_arc_494  -15
    arc_0_4_22  out_degree_790  1
    arc_0_4_22  in_degree_848  1
    arc_0_4_22  original_T_including_depot_unload_864  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_493  1
    load_0_4_22  segment_load_conservation_794  1
    load_0_4_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_23  arc_capacity_495  -20
    arc_0_4_23  connected_order_arc_496  -15
    arc_0_4_23  out_degree_790  1
    arc_0_4_23  in_degree_854  1
    arc_0_4_23  original_T_including_depot_unload_864  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_23  arc_capacity_495  1
    load_0_4_23  segment_load_conservation_794  1
    load_0_4_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_497  -20
    arc_0_5_0  depot_return_or_bypass_768  1
    arc_0_5_0  out_degree_797  1
    arc_0_5_0  original_T_including_depot_unload_864  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_497  1
    load_0_5_0  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_498  -20
    arc_0_5_1  connected_order_arc_499  -15
    arc_0_5_1  in_degree_770  1
    arc_0_5_1  out_degree_797  1
    arc_0_5_1  original_T_including_depot_unload_864  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_498  1
    load_0_5_1  segment_load_conservation_773  -1
    load_0_5_1  segment_prefix_lb_774  1
    load_0_5_1  segment_prefix_ub_775  1
    load_0_5_1  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_500  -20
    arc_0_5_2  connected_order_arc_501  -15
    arc_0_5_2  in_degree_777  1
    arc_0_5_2  out_degree_797  1
    arc_0_5_2  original_T_including_depot_unload_864  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_500  1
    load_0_5_2  segment_load_conservation_780  -1
    load_0_5_2  segment_prefix_lb_781  1
    load_0_5_2  segment_prefix_ub_782  1
    load_0_5_2  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_502  -20
    arc_0_5_3  connected_order_arc_503  -15
    arc_0_5_3  in_degree_784  1
    arc_0_5_3  out_degree_797  1
    arc_0_5_3  original_T_including_depot_unload_864  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_502  1
    load_0_5_3  segment_load_conservation_787  -1
    load_0_5_3  segment_prefix_lb_788  1
    load_0_5_3  segment_prefix_ub_789  1
    load_0_5_3  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_504  -20
    arc_0_5_4  connected_order_arc_505  -15
    arc_0_5_4  in_degree_791  1
    arc_0_5_4  out_degree_797  1
    arc_0_5_4  original_T_including_depot_unload_864  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_504  1
    load_0_5_4  segment_load_conservation_794  -1
    load_0_5_4  segment_prefix_lb_795  1
    load_0_5_4  segment_prefix_ub_796  1
    load_0_5_4  segment_load_conservation_801  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_506  -20
    arc_0_5_6  connected_order_arc_507  -15
    arc_0_5_6  out_degree_797  1
    arc_0_5_6  in_degree_805  1
    arc_0_5_6  original_T_including_depot_unload_864  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_506  1
    load_0_5_6  segment_load_conservation_801  1
    load_0_5_6  segment_load_conservation_808  -1
    load_0_5_6  segment_prefix_lb_809  1
    load_0_5_6  segment_prefix_ub_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_508  -20
    arc_0_5_16  connected_order_arc_509  -15
    arc_0_5_16  out_degree_797  1
    arc_0_5_16  in_degree_812  1
    arc_0_5_16  original_T_including_depot_unload_864  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_508  1
    load_0_5_16  segment_load_conservation_801  1
    load_0_5_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_510  -20
    arc_0_5_17  connected_order_arc_511  -15
    arc_0_5_17  out_degree_797  1
    arc_0_5_17  in_degree_818  1
    arc_0_5_17  original_T_including_depot_unload_864  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_510  1
    load_0_5_17  segment_load_conservation_801  1
    load_0_5_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_512  -20
    arc_0_5_18  connected_order_arc_513  -15
    arc_0_5_18  out_degree_797  1
    arc_0_5_18  in_degree_824  1
    arc_0_5_18  original_T_including_depot_unload_864  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_512  1
    load_0_5_18  segment_load_conservation_801  1
    load_0_5_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_514  -20
    arc_0_5_19  connected_order_arc_515  -15
    arc_0_5_19  out_degree_797  1
    arc_0_5_19  in_degree_830  1
    arc_0_5_19  original_T_including_depot_unload_864  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_514  1
    load_0_5_19  segment_load_conservation_801  1
    load_0_5_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_516  -20
    arc_0_5_20  connected_order_arc_517  -15
    arc_0_5_20  out_degree_797  1
    arc_0_5_20  in_degree_836  1
    arc_0_5_20  original_T_including_depot_unload_864  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_516  1
    load_0_5_20  segment_load_conservation_801  1
    load_0_5_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_518  -20
    arc_0_5_21  connected_order_arc_519  -15
    arc_0_5_21  out_degree_797  1
    arc_0_5_21  in_degree_842  1
    arc_0_5_21  original_T_including_depot_unload_864  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_518  1
    load_0_5_21  segment_load_conservation_801  1
    load_0_5_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_520  -20
    arc_0_5_22  connected_order_arc_521  -15
    arc_0_5_22  out_degree_797  1
    arc_0_5_22  in_degree_848  1
    arc_0_5_22  original_T_including_depot_unload_864  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_520  1
    load_0_5_22  segment_load_conservation_801  1
    load_0_5_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_23  arc_capacity_522  -20
    arc_0_5_23  connected_order_arc_523  -15
    arc_0_5_23  out_degree_797  1
    arc_0_5_23  in_degree_854  1
    arc_0_5_23  original_T_including_depot_unload_864  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_23  arc_capacity_522  1
    load_0_5_23  segment_load_conservation_801  1
    load_0_5_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_524  -20
    arc_0_6_0  depot_return_or_bypass_768  1
    arc_0_6_0  out_degree_804  1
    arc_0_6_0  original_T_including_depot_unload_864  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_524  1
    load_0_6_0  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_525  -20
    arc_0_6_1  connected_order_arc_526  -15
    arc_0_6_1  in_degree_770  1
    arc_0_6_1  out_degree_804  1
    arc_0_6_1  original_T_including_depot_unload_864  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_525  1
    load_0_6_1  segment_load_conservation_773  -1
    load_0_6_1  segment_prefix_lb_774  1
    load_0_6_1  segment_prefix_ub_775  1
    load_0_6_1  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_527  -20
    arc_0_6_2  connected_order_arc_528  -15
    arc_0_6_2  in_degree_777  1
    arc_0_6_2  out_degree_804  1
    arc_0_6_2  original_T_including_depot_unload_864  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_527  1
    load_0_6_2  segment_load_conservation_780  -1
    load_0_6_2  segment_prefix_lb_781  1
    load_0_6_2  segment_prefix_ub_782  1
    load_0_6_2  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_529  -20
    arc_0_6_3  connected_order_arc_530  -15
    arc_0_6_3  in_degree_784  1
    arc_0_6_3  out_degree_804  1
    arc_0_6_3  original_T_including_depot_unload_864  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_529  1
    load_0_6_3  segment_load_conservation_787  -1
    load_0_6_3  segment_prefix_lb_788  1
    load_0_6_3  segment_prefix_ub_789  1
    load_0_6_3  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_531  -20
    arc_0_6_4  connected_order_arc_532  -15
    arc_0_6_4  in_degree_791  1
    arc_0_6_4  out_degree_804  1
    arc_0_6_4  original_T_including_depot_unload_864  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_531  1
    load_0_6_4  segment_load_conservation_794  -1
    load_0_6_4  segment_prefix_lb_795  1
    load_0_6_4  segment_prefix_ub_796  1
    load_0_6_4  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_533  -20
    arc_0_6_5  connected_order_arc_534  -15
    arc_0_6_5  in_degree_798  1
    arc_0_6_5  out_degree_804  1
    arc_0_6_5  original_T_including_depot_unload_864  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_533  1
    load_0_6_5  segment_load_conservation_801  -1
    load_0_6_5  segment_prefix_lb_802  1
    load_0_6_5  segment_prefix_ub_803  1
    load_0_6_5  segment_load_conservation_808  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_535  -20
    arc_0_6_16  connected_order_arc_536  -15
    arc_0_6_16  out_degree_804  1
    arc_0_6_16  in_degree_812  1
    arc_0_6_16  original_T_including_depot_unload_864  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_535  1
    load_0_6_16  segment_load_conservation_808  1
    load_0_6_16  free_load_conservation_816  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_17  arc_capacity_537  -20
    arc_0_6_17  connected_order_arc_538  -15
    arc_0_6_17  out_degree_804  1
    arc_0_6_17  in_degree_818  1
    arc_0_6_17  original_T_including_depot_unload_864  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_17  arc_capacity_537  1
    load_0_6_17  segment_load_conservation_808  1
    load_0_6_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_18  arc_capacity_539  -20
    arc_0_6_18  connected_order_arc_540  -15
    arc_0_6_18  out_degree_804  1
    arc_0_6_18  in_degree_824  1
    arc_0_6_18  original_T_including_depot_unload_864  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_6_18  arc_capacity_539  1
    load_0_6_18  segment_load_conservation_808  1
    load_0_6_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_19  arc_capacity_541  -20
    arc_0_6_19  connected_order_arc_542  -15
    arc_0_6_19  out_degree_804  1
    arc_0_6_19  in_degree_830  1
    arc_0_6_19  original_T_including_depot_unload_864  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_19  arc_capacity_541  1
    load_0_6_19  segment_load_conservation_808  1
    load_0_6_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_20  arc_capacity_543  -20
    arc_0_6_20  connected_order_arc_544  -15
    arc_0_6_20  out_degree_804  1
    arc_0_6_20  in_degree_836  1
    arc_0_6_20  original_T_including_depot_unload_864  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_20  arc_capacity_543  1
    load_0_6_20  segment_load_conservation_808  1
    load_0_6_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_21  arc_capacity_545  -20
    arc_0_6_21  connected_order_arc_546  -15
    arc_0_6_21  out_degree_804  1
    arc_0_6_21  in_degree_842  1
    arc_0_6_21  original_T_including_depot_unload_864  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_21  arc_capacity_545  1
    load_0_6_21  segment_load_conservation_808  1
    load_0_6_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_22  arc_capacity_547  -20
    arc_0_6_22  connected_order_arc_548  -15
    arc_0_6_22  out_degree_804  1
    arc_0_6_22  in_degree_848  1
    arc_0_6_22  original_T_including_depot_unload_864  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_22  arc_capacity_547  1
    load_0_6_22  segment_load_conservation_808  1
    load_0_6_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_23  arc_capacity_549  -20
    arc_0_6_23  connected_order_arc_550  -15
    arc_0_6_23  out_degree_804  1
    arc_0_6_23  in_degree_854  1
    arc_0_6_23  original_T_including_depot_unload_864  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_23  arc_capacity_549  1
    load_0_6_23  segment_load_conservation_808  1
    load_0_6_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_551  -20
    arc_0_16_0  depot_return_or_bypass_768  1
    arc_0_16_0  out_degree_811  1
    arc_0_16_0  original_T_including_depot_unload_864  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_551  1
    load_0_16_0  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_552  -20
    arc_0_16_1  connected_order_arc_553  -15
    arc_0_16_1  in_degree_770  1
    arc_0_16_1  out_degree_811  1
    arc_0_16_1  original_T_including_depot_unload_864  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_552  1
    load_0_16_1  segment_load_conservation_773  -1
    load_0_16_1  segment_prefix_lb_774  1
    load_0_16_1  segment_prefix_ub_775  1
    load_0_16_1  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_554  -20
    arc_0_16_2  connected_order_arc_555  -15
    arc_0_16_2  in_degree_777  1
    arc_0_16_2  out_degree_811  1
    arc_0_16_2  original_T_including_depot_unload_864  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_554  1
    load_0_16_2  segment_load_conservation_780  -1
    load_0_16_2  segment_prefix_lb_781  1
    load_0_16_2  segment_prefix_ub_782  1
    load_0_16_2  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_556  -20
    arc_0_16_3  connected_order_arc_557  -15
    arc_0_16_3  in_degree_784  1
    arc_0_16_3  out_degree_811  1
    arc_0_16_3  original_T_including_depot_unload_864  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_556  1
    load_0_16_3  segment_load_conservation_787  -1
    load_0_16_3  segment_prefix_lb_788  1
    load_0_16_3  segment_prefix_ub_789  1
    load_0_16_3  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_558  -20
    arc_0_16_4  connected_order_arc_559  -15
    arc_0_16_4  in_degree_791  1
    arc_0_16_4  out_degree_811  1
    arc_0_16_4  original_T_including_depot_unload_864  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_558  1
    load_0_16_4  segment_load_conservation_794  -1
    load_0_16_4  segment_prefix_lb_795  1
    load_0_16_4  segment_prefix_ub_796  1
    load_0_16_4  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_560  -20
    arc_0_16_5  connected_order_arc_561  -15
    arc_0_16_5  in_degree_798  1
    arc_0_16_5  out_degree_811  1
    arc_0_16_5  original_T_including_depot_unload_864  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_560  1
    load_0_16_5  segment_load_conservation_801  -1
    load_0_16_5  segment_prefix_lb_802  1
    load_0_16_5  segment_prefix_ub_803  1
    load_0_16_5  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_562  -20
    arc_0_16_6  connected_order_arc_563  -15
    arc_0_16_6  in_degree_805  1
    arc_0_16_6  out_degree_811  1
    arc_0_16_6  original_T_including_depot_unload_864  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_562  1
    load_0_16_6  segment_load_conservation_808  -1
    load_0_16_6  segment_prefix_lb_809  1
    load_0_16_6  segment_prefix_ub_810  1
    load_0_16_6  free_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_564  -20
    arc_0_16_17  connected_order_arc_565  -15
    arc_0_16_17  out_degree_811  1
    arc_0_16_17  in_degree_818  1
    arc_0_16_17  original_T_including_depot_unload_864  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_564  1
    load_0_16_17  free_load_conservation_816  1
    load_0_16_17  free_load_conservation_822  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_566  -20
    arc_0_16_18  connected_order_arc_567  -15
    arc_0_16_18  out_degree_811  1
    arc_0_16_18  in_degree_824  1
    arc_0_16_18  original_T_including_depot_unload_864  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_566  1
    load_0_16_18  free_load_conservation_816  1
    load_0_16_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_568  -20
    arc_0_16_19  connected_order_arc_569  -15
    arc_0_16_19  out_degree_811  1
    arc_0_16_19  in_degree_830  1
    arc_0_16_19  original_T_including_depot_unload_864  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_568  1
    load_0_16_19  free_load_conservation_816  1
    load_0_16_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_570  -20
    arc_0_16_20  connected_order_arc_571  -15
    arc_0_16_20  out_degree_811  1
    arc_0_16_20  in_degree_836  1
    arc_0_16_20  original_T_including_depot_unload_864  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_570  1
    load_0_16_20  free_load_conservation_816  1
    load_0_16_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_572  -20
    arc_0_16_21  connected_order_arc_573  -15
    arc_0_16_21  out_degree_811  1
    arc_0_16_21  in_degree_842  1
    arc_0_16_21  original_T_including_depot_unload_864  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_572  1
    load_0_16_21  free_load_conservation_816  1
    load_0_16_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_574  -20
    arc_0_16_22  connected_order_arc_575  -15
    arc_0_16_22  out_degree_811  1
    arc_0_16_22  in_degree_848  1
    arc_0_16_22  original_T_including_depot_unload_864  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_574  1
    load_0_16_22  free_load_conservation_816  1
    load_0_16_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_23  arc_capacity_576  -20
    arc_0_16_23  connected_order_arc_577  -15
    arc_0_16_23  out_degree_811  1
    arc_0_16_23  in_degree_854  1
    arc_0_16_23  original_T_including_depot_unload_864  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_23  arc_capacity_576  1
    load_0_16_23  free_load_conservation_816  1
    load_0_16_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_578  -20
    arc_0_17_0  depot_return_or_bypass_768  1
    arc_0_17_0  out_degree_817  1
    arc_0_17_0  original_T_including_depot_unload_864  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_578  1
    load_0_17_0  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_579  -20
    arc_0_17_1  connected_order_arc_580  -15
    arc_0_17_1  in_degree_770  1
    arc_0_17_1  out_degree_817  1
    arc_0_17_1  original_T_including_depot_unload_864  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_579  1
    load_0_17_1  segment_load_conservation_773  -1
    load_0_17_1  segment_prefix_lb_774  1
    load_0_17_1  segment_prefix_ub_775  1
    load_0_17_1  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_581  -20
    arc_0_17_2  connected_order_arc_582  -15
    arc_0_17_2  in_degree_777  1
    arc_0_17_2  out_degree_817  1
    arc_0_17_2  original_T_including_depot_unload_864  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_581  1
    load_0_17_2  segment_load_conservation_780  -1
    load_0_17_2  segment_prefix_lb_781  1
    load_0_17_2  segment_prefix_ub_782  1
    load_0_17_2  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_583  -20
    arc_0_17_3  connected_order_arc_584  -15
    arc_0_17_3  in_degree_784  1
    arc_0_17_3  out_degree_817  1
    arc_0_17_3  original_T_including_depot_unload_864  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_583  1
    load_0_17_3  segment_load_conservation_787  -1
    load_0_17_3  segment_prefix_lb_788  1
    load_0_17_3  segment_prefix_ub_789  1
    load_0_17_3  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_585  -20
    arc_0_17_4  connected_order_arc_586  -15
    arc_0_17_4  in_degree_791  1
    arc_0_17_4  out_degree_817  1
    arc_0_17_4  original_T_including_depot_unload_864  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_585  1
    load_0_17_4  segment_load_conservation_794  -1
    load_0_17_4  segment_prefix_lb_795  1
    load_0_17_4  segment_prefix_ub_796  1
    load_0_17_4  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_587  -20
    arc_0_17_5  connected_order_arc_588  -15
    arc_0_17_5  in_degree_798  1
    arc_0_17_5  out_degree_817  1
    arc_0_17_5  original_T_including_depot_unload_864  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_587  1
    load_0_17_5  segment_load_conservation_801  -1
    load_0_17_5  segment_prefix_lb_802  1
    load_0_17_5  segment_prefix_ub_803  1
    load_0_17_5  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_6  arc_capacity_589  -20
    arc_0_17_6  connected_order_arc_590  -15
    arc_0_17_6  in_degree_805  1
    arc_0_17_6  out_degree_817  1
    arc_0_17_6  original_T_including_depot_unload_864  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_6  arc_capacity_589  1
    load_0_17_6  segment_load_conservation_808  -1
    load_0_17_6  segment_prefix_lb_809  1
    load_0_17_6  segment_prefix_ub_810  1
    load_0_17_6  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_591  -20
    arc_0_17_16  connected_order_arc_592  -15
    arc_0_17_16  in_degree_812  1
    arc_0_17_16  out_degree_817  1
    arc_0_17_16  original_T_including_depot_unload_864  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_591  1
    load_0_17_16  free_load_conservation_816  -1
    load_0_17_16  free_load_conservation_822  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_593  -20
    arc_0_17_18  connected_order_arc_594  -15
    arc_0_17_18  out_degree_817  1
    arc_0_17_18  in_degree_824  1
    arc_0_17_18  original_T_including_depot_unload_864  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_593  1
    load_0_17_18  free_load_conservation_822  1
    load_0_17_18  free_load_conservation_828  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_595  -20
    arc_0_17_19  connected_order_arc_596  -15
    arc_0_17_19  out_degree_817  1
    arc_0_17_19  in_degree_830  1
    arc_0_17_19  original_T_including_depot_unload_864  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_595  1
    load_0_17_19  free_load_conservation_822  1
    load_0_17_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_597  -20
    arc_0_17_20  connected_order_arc_598  -15
    arc_0_17_20  out_degree_817  1
    arc_0_17_20  in_degree_836  1
    arc_0_17_20  original_T_including_depot_unload_864  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_597  1
    load_0_17_20  free_load_conservation_822  1
    load_0_17_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_599  -20
    arc_0_17_21  connected_order_arc_600  -15
    arc_0_17_21  out_degree_817  1
    arc_0_17_21  in_degree_842  1
    arc_0_17_21  original_T_including_depot_unload_864  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_599  1
    load_0_17_21  free_load_conservation_822  1
    load_0_17_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_601  -20
    arc_0_17_22  connected_order_arc_602  -15
    arc_0_17_22  out_degree_817  1
    arc_0_17_22  in_degree_848  1
    arc_0_17_22  original_T_including_depot_unload_864  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_601  1
    load_0_17_22  free_load_conservation_822  1
    load_0_17_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_23  arc_capacity_603  -20
    arc_0_17_23  connected_order_arc_604  -15
    arc_0_17_23  out_degree_817  1
    arc_0_17_23  in_degree_854  1
    arc_0_17_23  original_T_including_depot_unload_864  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_23  arc_capacity_603  1
    load_0_17_23  free_load_conservation_822  1
    load_0_17_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_605  -20
    arc_0_18_0  depot_return_or_bypass_768  1
    arc_0_18_0  out_degree_823  1
    arc_0_18_0  original_T_including_depot_unload_864  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_605  1
    load_0_18_0  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_606  -20
    arc_0_18_1  connected_order_arc_607  -15
    arc_0_18_1  in_degree_770  1
    arc_0_18_1  out_degree_823  1
    arc_0_18_1  original_T_including_depot_unload_864  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_606  1
    load_0_18_1  segment_load_conservation_773  -1
    load_0_18_1  segment_prefix_lb_774  1
    load_0_18_1  segment_prefix_ub_775  1
    load_0_18_1  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_608  -20
    arc_0_18_2  connected_order_arc_609  -15
    arc_0_18_2  in_degree_777  1
    arc_0_18_2  out_degree_823  1
    arc_0_18_2  original_T_including_depot_unload_864  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_608  1
    load_0_18_2  segment_load_conservation_780  -1
    load_0_18_2  segment_prefix_lb_781  1
    load_0_18_2  segment_prefix_ub_782  1
    load_0_18_2  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_610  -20
    arc_0_18_3  connected_order_arc_611  -15
    arc_0_18_3  in_degree_784  1
    arc_0_18_3  out_degree_823  1
    arc_0_18_3  original_T_including_depot_unload_864  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_610  1
    load_0_18_3  segment_load_conservation_787  -1
    load_0_18_3  segment_prefix_lb_788  1
    load_0_18_3  segment_prefix_ub_789  1
    load_0_18_3  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_612  -20
    arc_0_18_4  connected_order_arc_613  -15
    arc_0_18_4  in_degree_791  1
    arc_0_18_4  out_degree_823  1
    arc_0_18_4  original_T_including_depot_unload_864  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_612  1
    load_0_18_4  segment_load_conservation_794  -1
    load_0_18_4  segment_prefix_lb_795  1
    load_0_18_4  segment_prefix_ub_796  1
    load_0_18_4  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_614  -20
    arc_0_18_5  connected_order_arc_615  -15
    arc_0_18_5  in_degree_798  1
    arc_0_18_5  out_degree_823  1
    arc_0_18_5  original_T_including_depot_unload_864  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_614  1
    load_0_18_5  segment_load_conservation_801  -1
    load_0_18_5  segment_prefix_lb_802  1
    load_0_18_5  segment_prefix_ub_803  1
    load_0_18_5  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_6  arc_capacity_616  -20
    arc_0_18_6  connected_order_arc_617  -15
    arc_0_18_6  in_degree_805  1
    arc_0_18_6  out_degree_823  1
    arc_0_18_6  original_T_including_depot_unload_864  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_18_6  arc_capacity_616  1
    load_0_18_6  segment_load_conservation_808  -1
    load_0_18_6  segment_prefix_lb_809  1
    load_0_18_6  segment_prefix_ub_810  1
    load_0_18_6  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_618  -20
    arc_0_18_16  connected_order_arc_619  -15
    arc_0_18_16  in_degree_812  1
    arc_0_18_16  out_degree_823  1
    arc_0_18_16  original_T_including_depot_unload_864  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_618  1
    load_0_18_16  free_load_conservation_816  -1
    load_0_18_16  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_620  -20
    arc_0_18_17  connected_order_arc_621  -15
    arc_0_18_17  in_degree_818  1
    arc_0_18_17  out_degree_823  1
    arc_0_18_17  original_T_including_depot_unload_864  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_620  1
    load_0_18_17  free_load_conservation_822  -1
    load_0_18_17  free_load_conservation_828  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_622  -20
    arc_0_18_19  connected_order_arc_623  -15
    arc_0_18_19  out_degree_823  1
    arc_0_18_19  in_degree_830  1
    arc_0_18_19  original_T_including_depot_unload_864  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_622  1
    load_0_18_19  free_load_conservation_828  1
    load_0_18_19  free_load_conservation_834  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_624  -20
    arc_0_18_20  connected_order_arc_625  -15
    arc_0_18_20  out_degree_823  1
    arc_0_18_20  in_degree_836  1
    arc_0_18_20  original_T_including_depot_unload_864  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_624  1
    load_0_18_20  free_load_conservation_828  1
    load_0_18_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_626  -20
    arc_0_18_21  connected_order_arc_627  -15
    arc_0_18_21  out_degree_823  1
    arc_0_18_21  in_degree_842  1
    arc_0_18_21  original_T_including_depot_unload_864  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_626  1
    load_0_18_21  free_load_conservation_828  1
    load_0_18_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_628  -20
    arc_0_18_22  connected_order_arc_629  -15
    arc_0_18_22  out_degree_823  1
    arc_0_18_22  in_degree_848  1
    arc_0_18_22  original_T_including_depot_unload_864  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_628  1
    load_0_18_22  free_load_conservation_828  1
    load_0_18_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_23  arc_capacity_630  -20
    arc_0_18_23  connected_order_arc_631  -15
    arc_0_18_23  out_degree_823  1
    arc_0_18_23  in_degree_854  1
    arc_0_18_23  original_T_including_depot_unload_864  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_23  arc_capacity_630  1
    load_0_18_23  free_load_conservation_828  1
    load_0_18_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_632  -20
    arc_0_19_0  depot_return_or_bypass_768  1
    arc_0_19_0  out_degree_829  1
    arc_0_19_0  original_T_including_depot_unload_864  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_632  1
    load_0_19_0  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_633  -20
    arc_0_19_1  connected_order_arc_634  -15
    arc_0_19_1  in_degree_770  1
    arc_0_19_1  out_degree_829  1
    arc_0_19_1  original_T_including_depot_unload_864  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_633  1
    load_0_19_1  segment_load_conservation_773  -1
    load_0_19_1  segment_prefix_lb_774  1
    load_0_19_1  segment_prefix_ub_775  1
    load_0_19_1  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_635  -20
    arc_0_19_2  connected_order_arc_636  -15
    arc_0_19_2  in_degree_777  1
    arc_0_19_2  out_degree_829  1
    arc_0_19_2  original_T_including_depot_unload_864  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_635  1
    load_0_19_2  segment_load_conservation_780  -1
    load_0_19_2  segment_prefix_lb_781  1
    load_0_19_2  segment_prefix_ub_782  1
    load_0_19_2  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_637  -20
    arc_0_19_3  connected_order_arc_638  -15
    arc_0_19_3  in_degree_784  1
    arc_0_19_3  out_degree_829  1
    arc_0_19_3  original_T_including_depot_unload_864  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_637  1
    load_0_19_3  segment_load_conservation_787  -1
    load_0_19_3  segment_prefix_lb_788  1
    load_0_19_3  segment_prefix_ub_789  1
    load_0_19_3  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_639  -20
    arc_0_19_4  connected_order_arc_640  -15
    arc_0_19_4  in_degree_791  1
    arc_0_19_4  out_degree_829  1
    arc_0_19_4  original_T_including_depot_unload_864  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_639  1
    load_0_19_4  segment_load_conservation_794  -1
    load_0_19_4  segment_prefix_lb_795  1
    load_0_19_4  segment_prefix_ub_796  1
    load_0_19_4  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_641  -20
    arc_0_19_5  connected_order_arc_642  -15
    arc_0_19_5  in_degree_798  1
    arc_0_19_5  out_degree_829  1
    arc_0_19_5  original_T_including_depot_unload_864  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_641  1
    load_0_19_5  segment_load_conservation_801  -1
    load_0_19_5  segment_prefix_lb_802  1
    load_0_19_5  segment_prefix_ub_803  1
    load_0_19_5  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_6  arc_capacity_643  -20
    arc_0_19_6  connected_order_arc_644  -15
    arc_0_19_6  in_degree_805  1
    arc_0_19_6  out_degree_829  1
    arc_0_19_6  original_T_including_depot_unload_864  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_6  arc_capacity_643  1
    load_0_19_6  segment_load_conservation_808  -1
    load_0_19_6  segment_prefix_lb_809  1
    load_0_19_6  segment_prefix_ub_810  1
    load_0_19_6  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_645  -20
    arc_0_19_16  connected_order_arc_646  -15
    arc_0_19_16  in_degree_812  1
    arc_0_19_16  out_degree_829  1
    arc_0_19_16  original_T_including_depot_unload_864  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_645  1
    load_0_19_16  free_load_conservation_816  -1
    load_0_19_16  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_647  -20
    arc_0_19_17  connected_order_arc_648  -15
    arc_0_19_17  in_degree_818  1
    arc_0_19_17  out_degree_829  1
    arc_0_19_17  original_T_including_depot_unload_864  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_647  1
    load_0_19_17  free_load_conservation_822  -1
    load_0_19_17  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_649  -20
    arc_0_19_18  connected_order_arc_650  -15
    arc_0_19_18  in_degree_824  1
    arc_0_19_18  out_degree_829  1
    arc_0_19_18  original_T_including_depot_unload_864  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_649  1
    load_0_19_18  free_load_conservation_828  -1
    load_0_19_18  free_load_conservation_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_651  -20
    arc_0_19_20  connected_order_arc_652  -15
    arc_0_19_20  out_degree_829  1
    arc_0_19_20  in_degree_836  1
    arc_0_19_20  original_T_including_depot_unload_864  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_651  1
    load_0_19_20  free_load_conservation_834  1
    load_0_19_20  free_load_conservation_840  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_653  -20
    arc_0_19_21  connected_order_arc_654  -15
    arc_0_19_21  out_degree_829  1
    arc_0_19_21  in_degree_842  1
    arc_0_19_21  original_T_including_depot_unload_864  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_653  1
    load_0_19_21  free_load_conservation_834  1
    load_0_19_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_655  -20
    arc_0_19_22  connected_order_arc_656  -15
    arc_0_19_22  out_degree_829  1
    arc_0_19_22  in_degree_848  1
    arc_0_19_22  original_T_including_depot_unload_864  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_655  1
    load_0_19_22  free_load_conservation_834  1
    load_0_19_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_23  arc_capacity_657  -20
    arc_0_19_23  connected_order_arc_658  -15
    arc_0_19_23  out_degree_829  1
    arc_0_19_23  in_degree_854  1
    arc_0_19_23  original_T_including_depot_unload_864  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_23  arc_capacity_657  1
    load_0_19_23  free_load_conservation_834  1
    load_0_19_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_659  -20
    arc_0_20_0  depot_return_or_bypass_768  1
    arc_0_20_0  out_degree_835  1
    arc_0_20_0  original_T_including_depot_unload_864  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_659  1
    load_0_20_0  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_660  -20
    arc_0_20_1  connected_order_arc_661  -15
    arc_0_20_1  in_degree_770  1
    arc_0_20_1  out_degree_835  1
    arc_0_20_1  original_T_including_depot_unload_864  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_660  1
    load_0_20_1  segment_load_conservation_773  -1
    load_0_20_1  segment_prefix_lb_774  1
    load_0_20_1  segment_prefix_ub_775  1
    load_0_20_1  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_662  -20
    arc_0_20_2  connected_order_arc_663  -15
    arc_0_20_2  in_degree_777  1
    arc_0_20_2  out_degree_835  1
    arc_0_20_2  original_T_including_depot_unload_864  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_662  1
    load_0_20_2  segment_load_conservation_780  -1
    load_0_20_2  segment_prefix_lb_781  1
    load_0_20_2  segment_prefix_ub_782  1
    load_0_20_2  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_664  -20
    arc_0_20_3  connected_order_arc_665  -15
    arc_0_20_3  in_degree_784  1
    arc_0_20_3  out_degree_835  1
    arc_0_20_3  original_T_including_depot_unload_864  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_664  1
    load_0_20_3  segment_load_conservation_787  -1
    load_0_20_3  segment_prefix_lb_788  1
    load_0_20_3  segment_prefix_ub_789  1
    load_0_20_3  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_666  -20
    arc_0_20_4  connected_order_arc_667  -15
    arc_0_20_4  in_degree_791  1
    arc_0_20_4  out_degree_835  1
    arc_0_20_4  original_T_including_depot_unload_864  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_666  1
    load_0_20_4  segment_load_conservation_794  -1
    load_0_20_4  segment_prefix_lb_795  1
    load_0_20_4  segment_prefix_ub_796  1
    load_0_20_4  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_668  -20
    arc_0_20_5  connected_order_arc_669  -15
    arc_0_20_5  in_degree_798  1
    arc_0_20_5  out_degree_835  1
    arc_0_20_5  original_T_including_depot_unload_864  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_668  1
    load_0_20_5  segment_load_conservation_801  -1
    load_0_20_5  segment_prefix_lb_802  1
    load_0_20_5  segment_prefix_ub_803  1
    load_0_20_5  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_6  arc_capacity_670  -20
    arc_0_20_6  connected_order_arc_671  -15
    arc_0_20_6  in_degree_805  1
    arc_0_20_6  out_degree_835  1
    arc_0_20_6  original_T_including_depot_unload_864  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_6  arc_capacity_670  1
    load_0_20_6  segment_load_conservation_808  -1
    load_0_20_6  segment_prefix_lb_809  1
    load_0_20_6  segment_prefix_ub_810  1
    load_0_20_6  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_672  -20
    arc_0_20_16  connected_order_arc_673  -15
    arc_0_20_16  in_degree_812  1
    arc_0_20_16  out_degree_835  1
    arc_0_20_16  original_T_including_depot_unload_864  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_672  1
    load_0_20_16  free_load_conservation_816  -1
    load_0_20_16  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_674  -20
    arc_0_20_17  connected_order_arc_675  -15
    arc_0_20_17  in_degree_818  1
    arc_0_20_17  out_degree_835  1
    arc_0_20_17  original_T_including_depot_unload_864  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_674  1
    load_0_20_17  free_load_conservation_822  -1
    load_0_20_17  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_676  -20
    arc_0_20_18  connected_order_arc_677  -15
    arc_0_20_18  in_degree_824  1
    arc_0_20_18  out_degree_835  1
    arc_0_20_18  original_T_including_depot_unload_864  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_676  1
    load_0_20_18  free_load_conservation_828  -1
    load_0_20_18  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_678  -20
    arc_0_20_19  connected_order_arc_679  -15
    arc_0_20_19  in_degree_830  1
    arc_0_20_19  out_degree_835  1
    arc_0_20_19  original_T_including_depot_unload_864  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_678  1
    load_0_20_19  free_load_conservation_834  -1
    load_0_20_19  free_load_conservation_840  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_680  -20
    arc_0_20_21  connected_order_arc_681  -15
    arc_0_20_21  out_degree_835  1
    arc_0_20_21  in_degree_842  1
    arc_0_20_21  original_T_including_depot_unload_864  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_680  1
    load_0_20_21  free_load_conservation_840  1
    load_0_20_21  free_load_conservation_846  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_682  -20
    arc_0_20_22  connected_order_arc_683  -15
    arc_0_20_22  out_degree_835  1
    arc_0_20_22  in_degree_848  1
    arc_0_20_22  original_T_including_depot_unload_864  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_682  1
    load_0_20_22  free_load_conservation_840  1
    load_0_20_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_23  arc_capacity_684  -20
    arc_0_20_23  connected_order_arc_685  -15
    arc_0_20_23  out_degree_835  1
    arc_0_20_23  in_degree_854  1
    arc_0_20_23  original_T_including_depot_unload_864  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_23  arc_capacity_684  1
    load_0_20_23  free_load_conservation_840  1
    load_0_20_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_686  -20
    arc_0_21_0  depot_return_or_bypass_768  1
    arc_0_21_0  out_degree_841  1
    arc_0_21_0  original_T_including_depot_unload_864  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_686  1
    load_0_21_0  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_687  -20
    arc_0_21_1  connected_order_arc_688  -15
    arc_0_21_1  in_degree_770  1
    arc_0_21_1  out_degree_841  1
    arc_0_21_1  original_T_including_depot_unload_864  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_687  1
    load_0_21_1  segment_load_conservation_773  -1
    load_0_21_1  segment_prefix_lb_774  1
    load_0_21_1  segment_prefix_ub_775  1
    load_0_21_1  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_689  -20
    arc_0_21_2  connected_order_arc_690  -15
    arc_0_21_2  in_degree_777  1
    arc_0_21_2  out_degree_841  1
    arc_0_21_2  original_T_including_depot_unload_864  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_689  1
    load_0_21_2  segment_load_conservation_780  -1
    load_0_21_2  segment_prefix_lb_781  1
    load_0_21_2  segment_prefix_ub_782  1
    load_0_21_2  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_691  -20
    arc_0_21_3  connected_order_arc_692  -15
    arc_0_21_3  in_degree_784  1
    arc_0_21_3  out_degree_841  1
    arc_0_21_3  original_T_including_depot_unload_864  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_691  1
    load_0_21_3  segment_load_conservation_787  -1
    load_0_21_3  segment_prefix_lb_788  1
    load_0_21_3  segment_prefix_ub_789  1
    load_0_21_3  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_693  -20
    arc_0_21_4  connected_order_arc_694  -15
    arc_0_21_4  in_degree_791  1
    arc_0_21_4  out_degree_841  1
    arc_0_21_4  original_T_including_depot_unload_864  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_693  1
    load_0_21_4  segment_load_conservation_794  -1
    load_0_21_4  segment_prefix_lb_795  1
    load_0_21_4  segment_prefix_ub_796  1
    load_0_21_4  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_695  -20
    arc_0_21_5  connected_order_arc_696  -15
    arc_0_21_5  in_degree_798  1
    arc_0_21_5  out_degree_841  1
    arc_0_21_5  original_T_including_depot_unload_864  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_695  1
    load_0_21_5  segment_load_conservation_801  -1
    load_0_21_5  segment_prefix_lb_802  1
    load_0_21_5  segment_prefix_ub_803  1
    load_0_21_5  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_6  arc_capacity_697  -20
    arc_0_21_6  connected_order_arc_698  -15
    arc_0_21_6  in_degree_805  1
    arc_0_21_6  out_degree_841  1
    arc_0_21_6  original_T_including_depot_unload_864  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_6  arc_capacity_697  1
    load_0_21_6  segment_load_conservation_808  -1
    load_0_21_6  segment_prefix_lb_809  1
    load_0_21_6  segment_prefix_ub_810  1
    load_0_21_6  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_699  -20
    arc_0_21_16  connected_order_arc_700  -15
    arc_0_21_16  in_degree_812  1
    arc_0_21_16  out_degree_841  1
    arc_0_21_16  original_T_including_depot_unload_864  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_699  1
    load_0_21_16  free_load_conservation_816  -1
    load_0_21_16  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_701  -20
    arc_0_21_17  connected_order_arc_702  -15
    arc_0_21_17  in_degree_818  1
    arc_0_21_17  out_degree_841  1
    arc_0_21_17  original_T_including_depot_unload_864  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_701  1
    load_0_21_17  free_load_conservation_822  -1
    load_0_21_17  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_703  -20
    arc_0_21_18  connected_order_arc_704  -15
    arc_0_21_18  in_degree_824  1
    arc_0_21_18  out_degree_841  1
    arc_0_21_18  original_T_including_depot_unload_864  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_703  1
    load_0_21_18  free_load_conservation_828  -1
    load_0_21_18  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_705  -20
    arc_0_21_19  connected_order_arc_706  -15
    arc_0_21_19  in_degree_830  1
    arc_0_21_19  out_degree_841  1
    arc_0_21_19  original_T_including_depot_unload_864  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_705  1
    load_0_21_19  free_load_conservation_834  -1
    load_0_21_19  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_707  -20
    arc_0_21_20  connected_order_arc_708  -15
    arc_0_21_20  in_degree_836  1
    arc_0_21_20  out_degree_841  1
    arc_0_21_20  original_T_including_depot_unload_864  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_707  1
    load_0_21_20  free_load_conservation_840  -1
    load_0_21_20  free_load_conservation_846  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_709  -20
    arc_0_21_22  connected_order_arc_710  -15
    arc_0_21_22  out_degree_841  1
    arc_0_21_22  in_degree_848  1
    arc_0_21_22  original_T_including_depot_unload_864  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_709  1
    load_0_21_22  free_load_conservation_846  1
    load_0_21_22  free_load_conservation_852  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_23  arc_capacity_711  -20
    arc_0_21_23  connected_order_arc_712  -15
    arc_0_21_23  out_degree_841  1
    arc_0_21_23  in_degree_854  1
    arc_0_21_23  original_T_including_depot_unload_864  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_23  arc_capacity_711  1
    load_0_21_23  free_load_conservation_846  1
    load_0_21_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_713  -20
    arc_0_22_0  depot_return_or_bypass_768  1
    arc_0_22_0  out_degree_847  1
    arc_0_22_0  original_T_including_depot_unload_864  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_713  1
    load_0_22_0  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_714  -20
    arc_0_22_1  connected_order_arc_715  -15
    arc_0_22_1  in_degree_770  1
    arc_0_22_1  out_degree_847  1
    arc_0_22_1  original_T_including_depot_unload_864  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_714  1
    load_0_22_1  segment_load_conservation_773  -1
    load_0_22_1  segment_prefix_lb_774  1
    load_0_22_1  segment_prefix_ub_775  1
    load_0_22_1  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_716  -20
    arc_0_22_2  connected_order_arc_717  -15
    arc_0_22_2  in_degree_777  1
    arc_0_22_2  out_degree_847  1
    arc_0_22_2  original_T_including_depot_unload_864  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_716  1
    load_0_22_2  segment_load_conservation_780  -1
    load_0_22_2  segment_prefix_lb_781  1
    load_0_22_2  segment_prefix_ub_782  1
    load_0_22_2  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_718  -20
    arc_0_22_3  connected_order_arc_719  -15
    arc_0_22_3  in_degree_784  1
    arc_0_22_3  out_degree_847  1
    arc_0_22_3  original_T_including_depot_unload_864  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_718  1
    load_0_22_3  segment_load_conservation_787  -1
    load_0_22_3  segment_prefix_lb_788  1
    load_0_22_3  segment_prefix_ub_789  1
    load_0_22_3  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_720  -20
    arc_0_22_4  connected_order_arc_721  -15
    arc_0_22_4  in_degree_791  1
    arc_0_22_4  out_degree_847  1
    arc_0_22_4  original_T_including_depot_unload_864  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_720  1
    load_0_22_4  segment_load_conservation_794  -1
    load_0_22_4  segment_prefix_lb_795  1
    load_0_22_4  segment_prefix_ub_796  1
    load_0_22_4  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_722  -20
    arc_0_22_5  connected_order_arc_723  -15
    arc_0_22_5  in_degree_798  1
    arc_0_22_5  out_degree_847  1
    arc_0_22_5  original_T_including_depot_unload_864  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_722  1
    load_0_22_5  segment_load_conservation_801  -1
    load_0_22_5  segment_prefix_lb_802  1
    load_0_22_5  segment_prefix_ub_803  1
    load_0_22_5  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_6  arc_capacity_724  -20
    arc_0_22_6  connected_order_arc_725  -15
    arc_0_22_6  in_degree_805  1
    arc_0_22_6  out_degree_847  1
    arc_0_22_6  original_T_including_depot_unload_864  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_6  arc_capacity_724  1
    load_0_22_6  segment_load_conservation_808  -1
    load_0_22_6  segment_prefix_lb_809  1
    load_0_22_6  segment_prefix_ub_810  1
    load_0_22_6  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_726  -20
    arc_0_22_16  connected_order_arc_727  -15
    arc_0_22_16  in_degree_812  1
    arc_0_22_16  out_degree_847  1
    arc_0_22_16  original_T_including_depot_unload_864  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_726  1
    load_0_22_16  free_load_conservation_816  -1
    load_0_22_16  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_728  -20
    arc_0_22_17  connected_order_arc_729  -15
    arc_0_22_17  in_degree_818  1
    arc_0_22_17  out_degree_847  1
    arc_0_22_17  original_T_including_depot_unload_864  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_728  1
    load_0_22_17  free_load_conservation_822  -1
    load_0_22_17  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_730  -20
    arc_0_22_18  connected_order_arc_731  -15
    arc_0_22_18  in_degree_824  1
    arc_0_22_18  out_degree_847  1
    arc_0_22_18  original_T_including_depot_unload_864  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_730  1
    load_0_22_18  free_load_conservation_828  -1
    load_0_22_18  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_732  -20
    arc_0_22_19  connected_order_arc_733  -15
    arc_0_22_19  in_degree_830  1
    arc_0_22_19  out_degree_847  1
    arc_0_22_19  original_T_including_depot_unload_864  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_732  1
    load_0_22_19  free_load_conservation_834  -1
    load_0_22_19  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_734  -20
    arc_0_22_20  connected_order_arc_735  -15
    arc_0_22_20  in_degree_836  1
    arc_0_22_20  out_degree_847  1
    arc_0_22_20  original_T_including_depot_unload_864  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_734  1
    load_0_22_20  free_load_conservation_840  -1
    load_0_22_20  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_736  -20
    arc_0_22_21  connected_order_arc_737  -15
    arc_0_22_21  in_degree_842  1
    arc_0_22_21  out_degree_847  1
    arc_0_22_21  original_T_including_depot_unload_864  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_736  1
    load_0_22_21  free_load_conservation_846  -1
    load_0_22_21  free_load_conservation_852  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_23  arc_capacity_738  -20
    arc_0_22_23  connected_order_arc_739  -15
    arc_0_22_23  out_degree_847  1
    arc_0_22_23  in_degree_854  1
    arc_0_22_23  original_T_including_depot_unload_864  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_23  arc_capacity_738  1
    load_0_22_23  free_load_conservation_852  1
    load_0_22_23  free_load_conservation_858  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_0  arc_capacity_740  -20
    arc_0_23_0  depot_return_or_bypass_768  1
    arc_0_23_0  out_degree_853  1
    arc_0_23_0  original_T_including_depot_unload_864  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_0  arc_capacity_740  1
    load_0_23_0  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_1  arc_capacity_741  -20
    arc_0_23_1  connected_order_arc_742  -15
    arc_0_23_1  in_degree_770  1
    arc_0_23_1  out_degree_853  1
    arc_0_23_1  original_T_including_depot_unload_864  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_1  arc_capacity_741  1
    load_0_23_1  segment_load_conservation_773  -1
    load_0_23_1  segment_prefix_lb_774  1
    load_0_23_1  segment_prefix_ub_775  1
    load_0_23_1  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_2  arc_capacity_743  -20
    arc_0_23_2  connected_order_arc_744  -15
    arc_0_23_2  in_degree_777  1
    arc_0_23_2  out_degree_853  1
    arc_0_23_2  original_T_including_depot_unload_864  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_2  arc_capacity_743  1
    load_0_23_2  segment_load_conservation_780  -1
    load_0_23_2  segment_prefix_lb_781  1
    load_0_23_2  segment_prefix_ub_782  1
    load_0_23_2  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_3  arc_capacity_745  -20
    arc_0_23_3  connected_order_arc_746  -15
    arc_0_23_3  in_degree_784  1
    arc_0_23_3  out_degree_853  1
    arc_0_23_3  original_T_including_depot_unload_864  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_3  arc_capacity_745  1
    load_0_23_3  segment_load_conservation_787  -1
    load_0_23_3  segment_prefix_lb_788  1
    load_0_23_3  segment_prefix_ub_789  1
    load_0_23_3  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_4  arc_capacity_747  -20
    arc_0_23_4  connected_order_arc_748  -15
    arc_0_23_4  in_degree_791  1
    arc_0_23_4  out_degree_853  1
    arc_0_23_4  original_T_including_depot_unload_864  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_4  arc_capacity_747  1
    load_0_23_4  segment_load_conservation_794  -1
    load_0_23_4  segment_prefix_lb_795  1
    load_0_23_4  segment_prefix_ub_796  1
    load_0_23_4  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_5  arc_capacity_749  -20
    arc_0_23_5  connected_order_arc_750  -15
    arc_0_23_5  in_degree_798  1
    arc_0_23_5  out_degree_853  1
    arc_0_23_5  original_T_including_depot_unload_864  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_5  arc_capacity_749  1
    load_0_23_5  segment_load_conservation_801  -1
    load_0_23_5  segment_prefix_lb_802  1
    load_0_23_5  segment_prefix_ub_803  1
    load_0_23_5  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_6  arc_capacity_751  -20
    arc_0_23_6  connected_order_arc_752  -15
    arc_0_23_6  in_degree_805  1
    arc_0_23_6  out_degree_853  1
    arc_0_23_6  original_T_including_depot_unload_864  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_6  arc_capacity_751  1
    load_0_23_6  segment_load_conservation_808  -1
    load_0_23_6  segment_prefix_lb_809  1
    load_0_23_6  segment_prefix_ub_810  1
    load_0_23_6  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_16  arc_capacity_753  -20
    arc_0_23_16  connected_order_arc_754  -15
    arc_0_23_16  in_degree_812  1
    arc_0_23_16  out_degree_853  1
    arc_0_23_16  original_T_including_depot_unload_864  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_16  arc_capacity_753  1
    load_0_23_16  free_load_conservation_816  -1
    load_0_23_16  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_17  arc_capacity_755  -20
    arc_0_23_17  connected_order_arc_756  -15
    arc_0_23_17  in_degree_818  1
    arc_0_23_17  out_degree_853  1
    arc_0_23_17  original_T_including_depot_unload_864  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_17  arc_capacity_755  1
    load_0_23_17  free_load_conservation_822  -1
    load_0_23_17  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_18  arc_capacity_757  -20
    arc_0_23_18  connected_order_arc_758  -15
    arc_0_23_18  in_degree_824  1
    arc_0_23_18  out_degree_853  1
    arc_0_23_18  original_T_including_depot_unload_864  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_18  arc_capacity_757  1
    load_0_23_18  free_load_conservation_828  -1
    load_0_23_18  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_19  arc_capacity_759  -20
    arc_0_23_19  connected_order_arc_760  -15
    arc_0_23_19  in_degree_830  1
    arc_0_23_19  out_degree_853  1
    arc_0_23_19  original_T_including_depot_unload_864  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_19  arc_capacity_759  1
    load_0_23_19  free_load_conservation_834  -1
    load_0_23_19  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_20  arc_capacity_761  -20
    arc_0_23_20  connected_order_arc_762  -15
    arc_0_23_20  in_degree_836  1
    arc_0_23_20  out_degree_853  1
    arc_0_23_20  original_T_including_depot_unload_864  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_20  arc_capacity_761  1
    load_0_23_20  free_load_conservation_840  -1
    load_0_23_20  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_21  arc_capacity_763  -20
    arc_0_23_21  connected_order_arc_764  -15
    arc_0_23_21  in_degree_842  1
    arc_0_23_21  out_degree_853  1
    arc_0_23_21  original_T_including_depot_unload_864  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_23_21  arc_capacity_763  1
    load_0_23_21  free_load_conservation_846  -1
    load_0_23_21  free_load_conservation_858  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_23_22  arc_capacity_765  -20
    arc_0_23_22  connected_order_arc_766  -15
    arc_0_23_22  in_degree_848  1
    arc_0_23_22  out_degree_853  1
    arc_0_23_22  original_T_including_depot_unload_864  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_23_22  arc_capacity_765  1
    load_0_23_22  free_load_conservation_852  -1
    load_0_23_22  free_load_conservation_858  1
    visit_1_7  out_degree_1206  -1
    visit_1_7  in_degree_1207  -1
    visit_1_7  order_active_lb_1208  -1
    visit_1_7  order_active_ub_1209  -13
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_889  -1
    order_1_7  connected_order_arc_891  -1
    order_1_7  connected_order_arc_893  -1
    order_1_7  connected_order_arc_895  -1
    order_1_7  connected_order_arc_897  -1
    order_1_7  connected_order_arc_899  -1
    order_1_7  connected_order_arc_901  -1
    order_1_7  connected_order_arc_903  -1
    order_1_7  connected_order_arc_906  1
    order_1_7  connected_order_arc_931  1
    order_1_7  connected_order_arc_956  1
    order_1_7  connected_order_arc_981  1
    order_1_7  connected_order_arc_1006  1
    order_1_7  connected_order_arc_1031  1
    order_1_7  connected_order_arc_1056  1
    order_1_7  connected_order_arc_1081  1
    order_1_7  connected_order_arc_1106  1
    order_1_7  connected_order_arc_1131  1
    order_1_7  connected_order_arc_1156  1
    order_1_7  connected_order_arc_1181  1
    order_1_7  order_active_lb_1208  1
    order_1_7  order_active_ub_1209  1
    order_1_7  fixed_segment_relative_order_1289  -1
    visit_1_8  out_degree_1213  -1
    visit_1_8  in_degree_1214  -1
    visit_1_8  order_active_lb_1215  -1
    visit_1_8  order_active_ub_1216  -13
    order_1_8  connected_order_arc_881  1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_914  -1
    order_1_8  connected_order_arc_916  -1
    order_1_8  connected_order_arc_918  -1
    order_1_8  connected_order_arc_920  -1
    order_1_8  connected_order_arc_922  -1
    order_1_8  connected_order_arc_924  -1
    order_1_8  connected_order_arc_926  -1
    order_1_8  connected_order_arc_928  -1
    order_1_8  connected_order_arc_933  1
    order_1_8  connected_order_arc_958  1
    order_1_8  connected_order_arc_983  1
    order_1_8  connected_order_arc_1008  1
    order_1_8  connected_order_arc_1033  1
    order_1_8  connected_order_arc_1058  1
    order_1_8  connected_order_arc_1083  1
    order_1_8  connected_order_arc_1108  1
    order_1_8  connected_order_arc_1133  1
    order_1_8  connected_order_arc_1158  1
    order_1_8  connected_order_arc_1183  1
    order_1_8  order_active_lb_1215  1
    order_1_8  order_active_ub_1216  1
    order_1_8  fixed_segment_relative_order_1289  1
    order_1_8  fixed_segment_relative_order_1290  -1
    visit_1_9  out_degree_1220  -1
    visit_1_9  in_degree_1221  -1
    visit_1_9  order_active_lb_1222  -1
    visit_1_9  order_active_ub_1223  -13
    order_1_9  connected_order_arc_883  1
    order_1_9  connected_order_arc_908  1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_933  -1
    order_1_9  connected_order_arc_935  -1
    order_1_9  connected_order_arc_937  -1
    order_1_9  connected_order_arc_939  -1
    order_1_9  connected_order_arc_941  -1
    order_1_9  connected_order_arc_943  -1
    order_1_9  connected_order_arc_945  -1
    order_1_9  connected_order_arc_947  -1
    order_1_9  connected_order_arc_949  -1
    order_1_9  connected_order_arc_951  -1
    order_1_9  connected_order_arc_953  -1
    order_1_9  connected_order_arc_960  1
    order_1_9  connected_order_arc_985  1
    order_1_9  connected_order_arc_1010  1
    order_1_9  connected_order_arc_1035  1
    order_1_9  connected_order_arc_1060  1
    order_1_9  connected_order_arc_1085  1
    order_1_9  connected_order_arc_1110  1
    order_1_9  connected_order_arc_1135  1
    order_1_9  connected_order_arc_1160  1
    order_1_9  connected_order_arc_1185  1
    order_1_9  order_active_lb_1222  1
    order_1_9  order_active_ub_1223  1
    order_1_9  fixed_segment_relative_order_1290  1
    order_1_9  fixed_segment_relative_order_1291  -1
    visit_1_10  out_degree_1227  -1
    visit_1_10  in_degree_1228  -1
    visit_1_10  order_active_lb_1229  -1
    visit_1_10  order_active_ub_1230  -13
    order_1_10  connected_order_arc_885  1
    order_1_10  connected_order_arc_910  1
    order_1_10  connected_order_arc_935  1
    order_1_10  connected_order_arc_956  -1
    order_1_10  connected_order_arc_958  -1
    order_1_10  connected_order_arc_960  -1
    order_1_10  connected_order_arc_962  -1
    order_1_10  connected_order_arc_964  -1
    order_1_10  connected_order_arc_966  -1
    order_1_10  connected_order_arc_968  -1
    order_1_10  connected_order_arc_970  -1
    order_1_10  connected_order_arc_972  -1
    order_1_10  connected_order_arc_974  -1
    order_1_10  connected_order_arc_976  -1
    order_1_10  connected_order_arc_978  -1
    order_1_10  connected_order_arc_987  1
    order_1_10  connected_order_arc_1012  1
    order_1_10  connected_order_arc_1037  1
    order_1_10  connected_order_arc_1062  1
    order_1_10  connected_order_arc_1087  1
    order_1_10  connected_order_arc_1112  1
    order_1_10  connected_order_arc_1137  1
    order_1_10  connected_order_arc_1162  1
    order_1_10  connected_order_arc_1187  1
    order_1_10  order_active_lb_1229  1
    order_1_10  order_active_ub_1230  1
    order_1_10  fixed_segment_relative_order_1291  1
    order_1_10  fixed_segment_relative_order_1292  -1
    visit_1_11  out_degree_1234  -1
    visit_1_11  in_degree_1235  -1
    visit_1_11  order_active_lb_1236  -1
    visit_1_11  order_active_ub_1237  -13
    order_1_11  connected_order_arc_887  1
    order_1_11  connected_order_arc_912  1
    order_1_11  connected_order_arc_937  1
    order_1_11  connected_order_arc_962  1
    order_1_11  connected_order_arc_981  -1
    order_1_11  connected_order_arc_983  -1
    order_1_11  connected_order_arc_985  -1
    order_1_11  connected_order_arc_987  -1
    order_1_11  connected_order_arc_989  -1
    order_1_11  connected_order_arc_991  -1
    order_1_11  connected_order_arc_993  -1
    order_1_11  connected_order_arc_995  -1
    order_1_11  connected_order_arc_997  -1
    order_1_11  connected_order_arc_999  -1
    order_1_11  connected_order_arc_1001  -1
    order_1_11  connected_order_arc_1003  -1
    order_1_11  connected_order_arc_1014  1
    order_1_11  connected_order_arc_1039  1
    order_1_11  connected_order_arc_1064  1
    order_1_11  connected_order_arc_1089  1
    order_1_11  connected_order_arc_1114  1
    order_1_11  connected_order_arc_1139  1
    order_1_11  connected_order_arc_1164  1
    order_1_11  connected_order_arc_1189  1
    order_1_11  order_active_lb_1236  1
    order_1_11  order_active_ub_1237  1
    order_1_11  fixed_segment_relative_order_1292  1
    visit_1_16  out_degree_1241  -1
    visit_1_16  in_degree_1242  -1
    visit_1_16  order_active_lb_1243  -1
    visit_1_16  order_active_ub_1244  -13
    visit_1_16  service_visit_def_1245  -1
    order_1_16  connected_order_arc_889  1
    order_1_16  connected_order_arc_914  1
    order_1_16  connected_order_arc_939  1
    order_1_16  connected_order_arc_964  1
    order_1_16  connected_order_arc_989  1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1014  -1
    order_1_16  connected_order_arc_1016  -1
    order_1_16  connected_order_arc_1018  -1
    order_1_16  connected_order_arc_1020  -1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1024  -1
    order_1_16  connected_order_arc_1026  -1
    order_1_16  connected_order_arc_1028  -1
    order_1_16  connected_order_arc_1041  1
    order_1_16  connected_order_arc_1066  1
    order_1_16  connected_order_arc_1091  1
    order_1_16  connected_order_arc_1116  1
    order_1_16  connected_order_arc_1141  1
    order_1_16  connected_order_arc_1166  1
    order_1_16  connected_order_arc_1191  1
    order_1_16  order_active_lb_1243  1
    order_1_16  order_active_ub_1244  1
    visit_1_17  out_degree_1247  -1
    visit_1_17  in_degree_1248  -1
    visit_1_17  order_active_lb_1249  -1
    visit_1_17  order_active_ub_1250  -13
    visit_1_17  service_visit_def_1251  -1
    order_1_17  connected_order_arc_891  1
    order_1_17  connected_order_arc_916  1
    order_1_17  connected_order_arc_941  1
    order_1_17  connected_order_arc_966  1
    order_1_17  connected_order_arc_991  1
    order_1_17  connected_order_arc_1016  1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1037  -1
    order_1_17  connected_order_arc_1039  -1
    order_1_17  connected_order_arc_1041  -1
    order_1_17  connected_order_arc_1043  -1
    order_1_17  connected_order_arc_1045  -1
    order_1_17  connected_order_arc_1047  -1
    order_1_17  connected_order_arc_1049  -1
    order_1_17  connected_order_arc_1051  -1
    order_1_17  connected_order_arc_1053  -1
    order_1_17  connected_order_arc_1068  1
    order_1_17  connected_order_arc_1093  1
    order_1_17  connected_order_arc_1118  1
    order_1_17  connected_order_arc_1143  1
    order_1_17  connected_order_arc_1168  1
    order_1_17  connected_order_arc_1193  1
    order_1_17  order_active_lb_1249  1
    order_1_17  order_active_ub_1250  1
    visit_1_18  out_degree_1253  -1
    visit_1_18  in_degree_1254  -1
    visit_1_18  order_active_lb_1255  -1
    visit_1_18  order_active_ub_1256  -13
    visit_1_18  service_visit_def_1257  -1
    order_1_18  connected_order_arc_893  1
    order_1_18  connected_order_arc_918  1
    order_1_18  connected_order_arc_943  1
    order_1_18  connected_order_arc_968  1
    order_1_18  connected_order_arc_993  1
    order_1_18  connected_order_arc_1018  1
    order_1_18  connected_order_arc_1043  1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1060  -1
    order_1_18  connected_order_arc_1062  -1
    order_1_18  connected_order_arc_1064  -1
    order_1_18  connected_order_arc_1066  -1
    order_1_18  connected_order_arc_1068  -1
    order_1_18  connected_order_arc_1070  -1
    order_1_18  connected_order_arc_1072  -1
    order_1_18  connected_order_arc_1074  -1
    order_1_18  connected_order_arc_1076  -1
    order_1_18  connected_order_arc_1078  -1
    order_1_18  connected_order_arc_1095  1
    order_1_18  connected_order_arc_1120  1
    order_1_18  connected_order_arc_1145  1
    order_1_18  connected_order_arc_1170  1
    order_1_18  connected_order_arc_1195  1
    order_1_18  order_active_lb_1255  1
    order_1_18  order_active_ub_1256  1
    visit_1_19  out_degree_1259  -1
    visit_1_19  in_degree_1260  -1
    visit_1_19  order_active_lb_1261  -1
    visit_1_19  order_active_ub_1262  -13
    visit_1_19  service_visit_def_1263  -1
    order_1_19  connected_order_arc_895  1
    order_1_19  connected_order_arc_920  1
    order_1_19  connected_order_arc_945  1
    order_1_19  connected_order_arc_970  1
    order_1_19  connected_order_arc_995  1
    order_1_19  connected_order_arc_1020  1
    order_1_19  connected_order_arc_1045  1
    order_1_19  connected_order_arc_1070  1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1083  -1
    order_1_19  connected_order_arc_1085  -1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1089  -1
    order_1_19  connected_order_arc_1091  -1
    order_1_19  connected_order_arc_1093  -1
    order_1_19  connected_order_arc_1095  -1
    order_1_19  connected_order_arc_1097  -1
    order_1_19  connected_order_arc_1099  -1
    order_1_19  connected_order_arc_1101  -1
    order_1_19  connected_order_arc_1103  -1
    order_1_19  connected_order_arc_1122  1
    order_1_19  connected_order_arc_1147  1
    order_1_19  connected_order_arc_1172  1
    order_1_19  connected_order_arc_1197  1
    order_1_19  order_active_lb_1261  1
    order_1_19  order_active_ub_1262  1
    visit_1_20  out_degree_1265  -1
    visit_1_20  in_degree_1266  -1
    visit_1_20  order_active_lb_1267  -1
    visit_1_20  order_active_ub_1268  -13
    visit_1_20  service_visit_def_1269  -1
    order_1_20  connected_order_arc_897  1
    order_1_20  connected_order_arc_922  1
    order_1_20  connected_order_arc_947  1
    order_1_20  connected_order_arc_972  1
    order_1_20  connected_order_arc_997  1
    order_1_20  connected_order_arc_1022  1
    order_1_20  connected_order_arc_1047  1
    order_1_20  connected_order_arc_1072  1
    order_1_20  connected_order_arc_1097  1
    order_1_20  connected_order_arc_1106  -1
    order_1_20  connected_order_arc_1108  -1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  connected_order_arc_1114  -1
    order_1_20  connected_order_arc_1116  -1
    order_1_20  connected_order_arc_1118  -1
    order_1_20  connected_order_arc_1120  -1
    order_1_20  connected_order_arc_1122  -1
    order_1_20  connected_order_arc_1124  -1
    order_1_20  connected_order_arc_1126  -1
    order_1_20  connected_order_arc_1128  -1
    order_1_20  connected_order_arc_1149  1
    order_1_20  connected_order_arc_1174  1
    order_1_20  connected_order_arc_1199  1
    order_1_20  order_active_lb_1267  1
    order_1_20  order_active_ub_1268  1
    visit_1_21  out_degree_1271  -1
    visit_1_21  in_degree_1272  -1
    visit_1_21  order_active_lb_1273  -1
    visit_1_21  order_active_ub_1274  -13
    visit_1_21  service_visit_def_1275  -1
    order_1_21  connected_order_arc_899  1
    order_1_21  connected_order_arc_924  1
    order_1_21  connected_order_arc_949  1
    order_1_21  connected_order_arc_974  1
    order_1_21  connected_order_arc_999  1
    order_1_21  connected_order_arc_1024  1
    order_1_21  connected_order_arc_1049  1
    order_1_21  connected_order_arc_1074  1
    order_1_21  connected_order_arc_1099  1
    order_1_21  connected_order_arc_1124  1
    order_1_21  connected_order_arc_1131  -1
    order_1_21  connected_order_arc_1133  -1
    order_1_21  connected_order_arc_1135  -1
    order_1_21  connected_order_arc_1137  -1
    order_1_21  connected_order_arc_1139  -1
    order_1_21  connected_order_arc_1141  -1
    order_1_21  connected_order_arc_1143  -1
    order_1_21  connected_order_arc_1145  -1
    order_1_21  connected_order_arc_1147  -1
    order_1_21  connected_order_arc_1149  -1
    order_1_21  connected_order_arc_1151  -1
    order_1_21  connected_order_arc_1153  -1
    order_1_21  connected_order_arc_1176  1
    order_1_21  connected_order_arc_1201  1
    order_1_21  order_active_lb_1273  1
    order_1_21  order_active_ub_1274  1
    visit_1_22  out_degree_1277  -1
    visit_1_22  in_degree_1278  -1
    visit_1_22  order_active_lb_1279  -1
    visit_1_22  order_active_ub_1280  -13
    visit_1_22  service_visit_def_1281  -1
    order_1_22  connected_order_arc_901  1
    order_1_22  connected_order_arc_926  1
    order_1_22  connected_order_arc_951  1
    order_1_22  connected_order_arc_976  1
    order_1_22  connected_order_arc_1001  1
    order_1_22  connected_order_arc_1026  1
    order_1_22  connected_order_arc_1051  1
    order_1_22  connected_order_arc_1076  1
    order_1_22  connected_order_arc_1101  1
    order_1_22  connected_order_arc_1126  1
    order_1_22  connected_order_arc_1151  1
    order_1_22  connected_order_arc_1156  -1
    order_1_22  connected_order_arc_1158  -1
    order_1_22  connected_order_arc_1160  -1
    order_1_22  connected_order_arc_1162  -1
    order_1_22  connected_order_arc_1164  -1
    order_1_22  connected_order_arc_1166  -1
    order_1_22  connected_order_arc_1168  -1
    order_1_22  connected_order_arc_1170  -1
    order_1_22  connected_order_arc_1172  -1
    order_1_22  connected_order_arc_1174  -1
    order_1_22  connected_order_arc_1176  -1
    order_1_22  connected_order_arc_1178  -1
    order_1_22  connected_order_arc_1203  1
    order_1_22  order_active_lb_1279  1
    order_1_22  order_active_ub_1280  1
    visit_1_23  out_degree_1283  -1
    visit_1_23  in_degree_1284  -1
    visit_1_23  order_active_lb_1285  -1
    visit_1_23  order_active_ub_1286  -13
    visit_1_23  service_visit_def_1287  -1
    order_1_23  connected_order_arc_903  1
    order_1_23  connected_order_arc_928  1
    order_1_23  connected_order_arc_953  1
    order_1_23  connected_order_arc_978  1
    order_1_23  connected_order_arc_1003  1
    order_1_23  connected_order_arc_1028  1
    order_1_23  connected_order_arc_1053  1
    order_1_23  connected_order_arc_1078  1
    order_1_23  connected_order_arc_1103  1
    order_1_23  connected_order_arc_1128  1
    order_1_23  connected_order_arc_1153  1
    order_1_23  connected_order_arc_1178  1
    order_1_23  connected_order_arc_1181  -1
    order_1_23  connected_order_arc_1183  -1
    order_1_23  connected_order_arc_1185  -1
    order_1_23  connected_order_arc_1187  -1
    order_1_23  connected_order_arc_1189  -1
    order_1_23  connected_order_arc_1191  -1
    order_1_23  connected_order_arc_1193  -1
    order_1_23  connected_order_arc_1195  -1
    order_1_23  connected_order_arc_1197  -1
    order_1_23  connected_order_arc_1199  -1
    order_1_23  connected_order_arc_1201  -1
    order_1_23  connected_order_arc_1203  -1
    order_1_23  order_active_lb_1285  1
    order_1_23  order_active_ub_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_865  -25
    arc_1_0_0  depot_departure_or_bypass_1204  1
    arc_1_0_0  depot_return_or_bypass_1205  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_865  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_866  -25
    arc_1_0_7  depot_departure_or_bypass_1204  1
    arc_1_0_7  in_degree_1207  1
    arc_1_0_7  original_T_including_depot_unload_1293  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_866  1
    load_1_0_7  segment_load_conservation_1210  -1
    load_1_0_7  segment_prefix_lb_1211  1
    load_1_0_7  segment_prefix_ub_1212  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_867  -25
    arc_1_0_8  depot_departure_or_bypass_1204  1
    arc_1_0_8  in_degree_1214  1
    arc_1_0_8  original_T_including_depot_unload_1293  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_867  1
    load_1_0_8  segment_load_conservation_1217  -1
    load_1_0_8  segment_prefix_lb_1218  1
    load_1_0_8  segment_prefix_ub_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_868  -25
    arc_1_0_9  depot_departure_or_bypass_1204  1
    arc_1_0_9  in_degree_1221  1
    arc_1_0_9  original_T_including_depot_unload_1293  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_868  1
    load_1_0_9  segment_load_conservation_1224  -1
    load_1_0_9  segment_prefix_lb_1225  1
    load_1_0_9  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_869  -25
    arc_1_0_10  depot_departure_or_bypass_1204  1
    arc_1_0_10  in_degree_1228  1
    arc_1_0_10  original_T_including_depot_unload_1293  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_869  1
    load_1_0_10  segment_load_conservation_1231  -1
    load_1_0_10  segment_prefix_lb_1232  1
    load_1_0_10  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_870  -25
    arc_1_0_11  depot_departure_or_bypass_1204  1
    arc_1_0_11  in_degree_1235  1
    arc_1_0_11  original_T_including_depot_unload_1293  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_870  1
    load_1_0_11  segment_load_conservation_1238  -1
    load_1_0_11  segment_prefix_lb_1239  1
    load_1_0_11  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_871  -25
    arc_1_0_16  depot_departure_or_bypass_1204  1
    arc_1_0_16  in_degree_1242  1
    arc_1_0_16  original_T_including_depot_unload_1293  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_871  1
    load_1_0_16  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_872  -25
    arc_1_0_17  depot_departure_or_bypass_1204  1
    arc_1_0_17  in_degree_1248  1
    arc_1_0_17  original_T_including_depot_unload_1293  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_872  1
    load_1_0_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_873  -25
    arc_1_0_18  depot_departure_or_bypass_1204  1
    arc_1_0_18  in_degree_1254  1
    arc_1_0_18  original_T_including_depot_unload_1293  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_873  1
    load_1_0_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_874  -25
    arc_1_0_19  depot_departure_or_bypass_1204  1
    arc_1_0_19  in_degree_1260  1
    arc_1_0_19  original_T_including_depot_unload_1293  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_874  1
    load_1_0_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_875  -25
    arc_1_0_20  depot_departure_or_bypass_1204  1
    arc_1_0_20  in_degree_1266  1
    arc_1_0_20  original_T_including_depot_unload_1293  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_875  1
    load_1_0_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_876  -25
    arc_1_0_21  depot_departure_or_bypass_1204  1
    arc_1_0_21  in_degree_1272  1
    arc_1_0_21  original_T_including_depot_unload_1293  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_876  1
    load_1_0_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_877  -25
    arc_1_0_22  depot_departure_or_bypass_1204  1
    arc_1_0_22  in_degree_1278  1
    arc_1_0_22  original_T_including_depot_unload_1293  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_877  1
    load_1_0_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_23  arc_capacity_878  -25
    arc_1_0_23  depot_departure_or_bypass_1204  1
    arc_1_0_23  in_degree_1284  1
    arc_1_0_23  original_T_including_depot_unload_1293  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_23  arc_capacity_878  1
    load_1_0_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_879  -25
    arc_1_7_0  depot_return_or_bypass_1205  1
    arc_1_7_0  out_degree_1206  1
    arc_1_7_0  original_T_including_depot_unload_1293  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_879  1
    load_1_7_0  segment_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_880  -25
    arc_1_7_8  connected_order_arc_881  -14
    arc_1_7_8  out_degree_1206  1
    arc_1_7_8  in_degree_1214  1
    arc_1_7_8  original_T_including_depot_unload_1293  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_880  1
    load_1_7_8  segment_load_conservation_1210  1
    load_1_7_8  segment_load_conservation_1217  -1
    load_1_7_8  segment_prefix_lb_1218  1
    load_1_7_8  segment_prefix_ub_1219  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_882  -25
    arc_1_7_9  connected_order_arc_883  -14
    arc_1_7_9  out_degree_1206  1
    arc_1_7_9  in_degree_1221  1
    arc_1_7_9  original_T_including_depot_unload_1293  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_882  1
    load_1_7_9  segment_load_conservation_1210  1
    load_1_7_9  segment_load_conservation_1224  -1
    load_1_7_9  segment_prefix_lb_1225  1
    load_1_7_9  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_884  -25
    arc_1_7_10  connected_order_arc_885  -14
    arc_1_7_10  out_degree_1206  1
    arc_1_7_10  in_degree_1228  1
    arc_1_7_10  original_T_including_depot_unload_1293  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_884  1
    load_1_7_10  segment_load_conservation_1210  1
    load_1_7_10  segment_load_conservation_1231  -1
    load_1_7_10  segment_prefix_lb_1232  1
    load_1_7_10  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_886  -25
    arc_1_7_11  connected_order_arc_887  -14
    arc_1_7_11  out_degree_1206  1
    arc_1_7_11  in_degree_1235  1
    arc_1_7_11  original_T_including_depot_unload_1293  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_886  1
    load_1_7_11  segment_load_conservation_1210  1
    load_1_7_11  segment_load_conservation_1238  -1
    load_1_7_11  segment_prefix_lb_1239  1
    load_1_7_11  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_888  -25
    arc_1_7_16  connected_order_arc_889  -14
    arc_1_7_16  out_degree_1206  1
    arc_1_7_16  in_degree_1242  1
    arc_1_7_16  original_T_including_depot_unload_1293  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_888  1
    load_1_7_16  segment_load_conservation_1210  1
    load_1_7_16  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_890  -25
    arc_1_7_17  connected_order_arc_891  -14
    arc_1_7_17  out_degree_1206  1
    arc_1_7_17  in_degree_1248  1
    arc_1_7_17  original_T_including_depot_unload_1293  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_890  1
    load_1_7_17  segment_load_conservation_1210  1
    load_1_7_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_892  -25
    arc_1_7_18  connected_order_arc_893  -14
    arc_1_7_18  out_degree_1206  1
    arc_1_7_18  in_degree_1254  1
    arc_1_7_18  original_T_including_depot_unload_1293  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_892  1
    load_1_7_18  segment_load_conservation_1210  1
    load_1_7_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_894  -25
    arc_1_7_19  connected_order_arc_895  -14
    arc_1_7_19  out_degree_1206  1
    arc_1_7_19  in_degree_1260  1
    arc_1_7_19  original_T_including_depot_unload_1293  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_894  1
    load_1_7_19  segment_load_conservation_1210  1
    load_1_7_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_896  -25
    arc_1_7_20  connected_order_arc_897  -14
    arc_1_7_20  out_degree_1206  1
    arc_1_7_20  in_degree_1266  1
    arc_1_7_20  original_T_including_depot_unload_1293  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_896  1
    load_1_7_20  segment_load_conservation_1210  1
    load_1_7_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_898  -25
    arc_1_7_21  connected_order_arc_899  -14
    arc_1_7_21  out_degree_1206  1
    arc_1_7_21  in_degree_1272  1
    arc_1_7_21  original_T_including_depot_unload_1293  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_898  1
    load_1_7_21  segment_load_conservation_1210  1
    load_1_7_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_900  -25
    arc_1_7_22  connected_order_arc_901  -14
    arc_1_7_22  out_degree_1206  1
    arc_1_7_22  in_degree_1278  1
    arc_1_7_22  original_T_including_depot_unload_1293  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_900  1
    load_1_7_22  segment_load_conservation_1210  1
    load_1_7_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_23  arc_capacity_902  -25
    arc_1_7_23  connected_order_arc_903  -14
    arc_1_7_23  out_degree_1206  1
    arc_1_7_23  in_degree_1284  1
    arc_1_7_23  original_T_including_depot_unload_1293  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_23  arc_capacity_902  1
    load_1_7_23  segment_load_conservation_1210  1
    load_1_7_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_904  -25
    arc_1_8_0  depot_return_or_bypass_1205  1
    arc_1_8_0  out_degree_1213  1
    arc_1_8_0  original_T_including_depot_unload_1293  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_904  1
    load_1_8_0  segment_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_905  -25
    arc_1_8_7  connected_order_arc_906  -14
    arc_1_8_7  in_degree_1207  1
    arc_1_8_7  out_degree_1213  1
    arc_1_8_7  original_T_including_depot_unload_1293  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_905  1
    load_1_8_7  segment_load_conservation_1210  -1
    load_1_8_7  segment_prefix_lb_1211  1
    load_1_8_7  segment_prefix_ub_1212  1
    load_1_8_7  segment_load_conservation_1217  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_907  -25
    arc_1_8_9  connected_order_arc_908  -14
    arc_1_8_9  out_degree_1213  1
    arc_1_8_9  in_degree_1221  1
    arc_1_8_9  original_T_including_depot_unload_1293  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_907  1
    load_1_8_9  segment_load_conservation_1217  1
    load_1_8_9  segment_load_conservation_1224  -1
    load_1_8_9  segment_prefix_lb_1225  1
    load_1_8_9  segment_prefix_ub_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_909  -25
    arc_1_8_10  connected_order_arc_910  -14
    arc_1_8_10  out_degree_1213  1
    arc_1_8_10  in_degree_1228  1
    arc_1_8_10  original_T_including_depot_unload_1293  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_909  1
    load_1_8_10  segment_load_conservation_1217  1
    load_1_8_10  segment_load_conservation_1231  -1
    load_1_8_10  segment_prefix_lb_1232  1
    load_1_8_10  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_911  -25
    arc_1_8_11  connected_order_arc_912  -14
    arc_1_8_11  out_degree_1213  1
    arc_1_8_11  in_degree_1235  1
    arc_1_8_11  original_T_including_depot_unload_1293  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_911  1
    load_1_8_11  segment_load_conservation_1217  1
    load_1_8_11  segment_load_conservation_1238  -1
    load_1_8_11  segment_prefix_lb_1239  1
    load_1_8_11  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_913  -25
    arc_1_8_16  connected_order_arc_914  -14
    arc_1_8_16  out_degree_1213  1
    arc_1_8_16  in_degree_1242  1
    arc_1_8_16  original_T_including_depot_unload_1293  2.2630748095713293e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_913  1
    load_1_8_16  segment_load_conservation_1217  1
    load_1_8_16  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_915  -25
    arc_1_8_17  connected_order_arc_916  -14
    arc_1_8_17  out_degree_1213  1
    arc_1_8_17  in_degree_1248  1
    arc_1_8_17  original_T_including_depot_unload_1293  2.1139218026901112e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_915  1
    load_1_8_17  segment_load_conservation_1217  1
    load_1_8_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_917  -25
    arc_1_8_18  connected_order_arc_918  -14
    arc_1_8_18  out_degree_1213  1
    arc_1_8_18  in_degree_1254  1
    arc_1_8_18  original_T_including_depot_unload_1293  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_917  1
    load_1_8_18  segment_load_conservation_1217  1
    load_1_8_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_919  -25
    arc_1_8_19  connected_order_arc_920  -14
    arc_1_8_19  out_degree_1213  1
    arc_1_8_19  in_degree_1260  1
    arc_1_8_19  original_T_including_depot_unload_1293  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_919  1
    load_1_8_19  segment_load_conservation_1217  1
    load_1_8_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_921  -25
    arc_1_8_20  connected_order_arc_922  -14
    arc_1_8_20  out_degree_1213  1
    arc_1_8_20  in_degree_1266  1
    arc_1_8_20  original_T_including_depot_unload_1293  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_921  1
    load_1_8_20  segment_load_conservation_1217  1
    load_1_8_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_923  -25
    arc_1_8_21  connected_order_arc_924  -14
    arc_1_8_21  out_degree_1213  1
    arc_1_8_21  in_degree_1272  1
    arc_1_8_21  original_T_including_depot_unload_1293  2.1293186465553604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_923  1
    load_1_8_21  segment_load_conservation_1217  1
    load_1_8_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_925  -25
    arc_1_8_22  connected_order_arc_926  -14
    arc_1_8_22  out_degree_1213  1
    arc_1_8_22  in_degree_1278  1
    arc_1_8_22  original_T_including_depot_unload_1293  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_925  1
    load_1_8_22  segment_load_conservation_1217  1
    load_1_8_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_23  arc_capacity_927  -25
    arc_1_8_23  connected_order_arc_928  -14
    arc_1_8_23  out_degree_1213  1
    arc_1_8_23  in_degree_1284  1
    arc_1_8_23  original_T_including_depot_unload_1293  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_23  arc_capacity_927  1
    load_1_8_23  segment_load_conservation_1217  1
    load_1_8_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_929  -25
    arc_1_9_0  depot_return_or_bypass_1205  1
    arc_1_9_0  out_degree_1220  1
    arc_1_9_0  original_T_including_depot_unload_1293  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_929  1
    load_1_9_0  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_930  -25
    arc_1_9_7  connected_order_arc_931  -14
    arc_1_9_7  in_degree_1207  1
    arc_1_9_7  out_degree_1220  1
    arc_1_9_7  original_T_including_depot_unload_1293  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_930  1
    load_1_9_7  segment_load_conservation_1210  -1
    load_1_9_7  segment_prefix_lb_1211  1
    load_1_9_7  segment_prefix_ub_1212  1
    load_1_9_7  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_932  -25
    arc_1_9_8  connected_order_arc_933  -14
    arc_1_9_8  in_degree_1214  1
    arc_1_9_8  out_degree_1220  1
    arc_1_9_8  original_T_including_depot_unload_1293  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_932  1
    load_1_9_8  segment_load_conservation_1217  -1
    load_1_9_8  segment_prefix_lb_1218  1
    load_1_9_8  segment_prefix_ub_1219  1
    load_1_9_8  segment_load_conservation_1224  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_934  -25
    arc_1_9_10  connected_order_arc_935  -14
    arc_1_9_10  out_degree_1220  1
    arc_1_9_10  in_degree_1228  1
    arc_1_9_10  original_T_including_depot_unload_1293  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_934  1
    load_1_9_10  segment_load_conservation_1224  1
    load_1_9_10  segment_load_conservation_1231  -1
    load_1_9_10  segment_prefix_lb_1232  1
    load_1_9_10  segment_prefix_ub_1233  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_936  -25
    arc_1_9_11  connected_order_arc_937  -14
    arc_1_9_11  out_degree_1220  1
    arc_1_9_11  in_degree_1235  1
    arc_1_9_11  original_T_including_depot_unload_1293  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_936  1
    load_1_9_11  segment_load_conservation_1224  1
    load_1_9_11  segment_load_conservation_1238  -1
    load_1_9_11  segment_prefix_lb_1239  1
    load_1_9_11  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_938  -25
    arc_1_9_16  connected_order_arc_939  -14
    arc_1_9_16  out_degree_1220  1
    arc_1_9_16  in_degree_1242  1
    arc_1_9_16  original_T_including_depot_unload_1293  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_938  1
    load_1_9_16  segment_load_conservation_1224  1
    load_1_9_16  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_940  -25
    arc_1_9_17  connected_order_arc_941  -14
    arc_1_9_17  out_degree_1220  1
    arc_1_9_17  in_degree_1248  1
    arc_1_9_17  original_T_including_depot_unload_1293  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_940  1
    load_1_9_17  segment_load_conservation_1224  1
    load_1_9_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_942  -25
    arc_1_9_18  connected_order_arc_943  -14
    arc_1_9_18  out_degree_1220  1
    arc_1_9_18  in_degree_1254  1
    arc_1_9_18  original_T_including_depot_unload_1293  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_942  1
    load_1_9_18  segment_load_conservation_1224  1
    load_1_9_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_944  -25
    arc_1_9_19  connected_order_arc_945  -14
    arc_1_9_19  out_degree_1220  1
    arc_1_9_19  in_degree_1260  1
    arc_1_9_19  original_T_including_depot_unload_1293  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_944  1
    load_1_9_19  segment_load_conservation_1224  1
    load_1_9_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_946  -25
    arc_1_9_20  connected_order_arc_947  -14
    arc_1_9_20  out_degree_1220  1
    arc_1_9_20  in_degree_1266  1
    arc_1_9_20  original_T_including_depot_unload_1293  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_946  1
    load_1_9_20  segment_load_conservation_1224  1
    load_1_9_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_948  -25
    arc_1_9_21  connected_order_arc_949  -14
    arc_1_9_21  out_degree_1220  1
    arc_1_9_21  in_degree_1272  1
    arc_1_9_21  original_T_including_depot_unload_1293  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_948  1
    load_1_9_21  segment_load_conservation_1224  1
    load_1_9_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_950  -25
    arc_1_9_22  connected_order_arc_951  -14
    arc_1_9_22  out_degree_1220  1
    arc_1_9_22  in_degree_1278  1
    arc_1_9_22  original_T_including_depot_unload_1293  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_950  1
    load_1_9_22  segment_load_conservation_1224  1
    load_1_9_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_23  arc_capacity_952  -25
    arc_1_9_23  connected_order_arc_953  -14
    arc_1_9_23  out_degree_1220  1
    arc_1_9_23  in_degree_1284  1
    arc_1_9_23  original_T_including_depot_unload_1293  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_23  arc_capacity_952  1
    load_1_9_23  segment_load_conservation_1224  1
    load_1_9_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_954  -25
    arc_1_10_0  depot_return_or_bypass_1205  1
    arc_1_10_0  out_degree_1227  1
    arc_1_10_0  original_T_including_depot_unload_1293  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_954  1
    load_1_10_0  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_955  -25
    arc_1_10_7  connected_order_arc_956  -14
    arc_1_10_7  in_degree_1207  1
    arc_1_10_7  out_degree_1227  1
    arc_1_10_7  original_T_including_depot_unload_1293  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_955  1
    load_1_10_7  segment_load_conservation_1210  -1
    load_1_10_7  segment_prefix_lb_1211  1
    load_1_10_7  segment_prefix_ub_1212  1
    load_1_10_7  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_957  -25
    arc_1_10_8  connected_order_arc_958  -14
    arc_1_10_8  in_degree_1214  1
    arc_1_10_8  out_degree_1227  1
    arc_1_10_8  original_T_including_depot_unload_1293  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_957  1
    load_1_10_8  segment_load_conservation_1217  -1
    load_1_10_8  segment_prefix_lb_1218  1
    load_1_10_8  segment_prefix_ub_1219  1
    load_1_10_8  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_959  -25
    arc_1_10_9  connected_order_arc_960  -14
    arc_1_10_9  in_degree_1221  1
    arc_1_10_9  out_degree_1227  1
    arc_1_10_9  original_T_including_depot_unload_1293  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_959  1
    load_1_10_9  segment_load_conservation_1224  -1
    load_1_10_9  segment_prefix_lb_1225  1
    load_1_10_9  segment_prefix_ub_1226  1
    load_1_10_9  segment_load_conservation_1231  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_961  -25
    arc_1_10_11  connected_order_arc_962  -14
    arc_1_10_11  out_degree_1227  1
    arc_1_10_11  in_degree_1235  1
    arc_1_10_11  original_T_including_depot_unload_1293  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_961  1
    load_1_10_11  segment_load_conservation_1231  1
    load_1_10_11  segment_load_conservation_1238  -1
    load_1_10_11  segment_prefix_lb_1239  1
    load_1_10_11  segment_prefix_ub_1240  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_963  -25
    arc_1_10_16  connected_order_arc_964  -14
    arc_1_10_16  out_degree_1227  1
    arc_1_10_16  in_degree_1242  1
    arc_1_10_16  original_T_including_depot_unload_1293  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_963  1
    load_1_10_16  segment_load_conservation_1231  1
    load_1_10_16  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_965  -25
    arc_1_10_17  connected_order_arc_966  -14
    arc_1_10_17  out_degree_1227  1
    arc_1_10_17  in_degree_1248  1
    arc_1_10_17  original_T_including_depot_unload_1293  1.7644788835951622e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_965  1
    load_1_10_17  segment_load_conservation_1231  1
    load_1_10_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_967  -25
    arc_1_10_18  connected_order_arc_968  -14
    arc_1_10_18  out_degree_1227  1
    arc_1_10_18  in_degree_1254  1
    arc_1_10_18  original_T_including_depot_unload_1293  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_967  1
    load_1_10_18  segment_load_conservation_1231  1
    load_1_10_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_969  -25
    arc_1_10_19  connected_order_arc_970  -14
    arc_1_10_19  out_degree_1227  1
    arc_1_10_19  in_degree_1260  1
    arc_1_10_19  original_T_including_depot_unload_1293  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_969  1
    load_1_10_19  segment_load_conservation_1231  1
    load_1_10_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_971  -25
    arc_1_10_20  connected_order_arc_972  -14
    arc_1_10_20  out_degree_1227  1
    arc_1_10_20  in_degree_1266  1
    arc_1_10_20  original_T_including_depot_unload_1293  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_971  1
    load_1_10_20  segment_load_conservation_1231  1
    load_1_10_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_973  -25
    arc_1_10_21  connected_order_arc_974  -14
    arc_1_10_21  out_degree_1227  1
    arc_1_10_21  in_degree_1272  1
    arc_1_10_21  original_T_including_depot_unload_1293  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_973  1
    load_1_10_21  segment_load_conservation_1231  1
    load_1_10_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_22  arc_capacity_975  -25
    arc_1_10_22  connected_order_arc_976  -14
    arc_1_10_22  out_degree_1227  1
    arc_1_10_22  in_degree_1278  1
    arc_1_10_22  original_T_including_depot_unload_1293  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_22  arc_capacity_975  1
    load_1_10_22  segment_load_conservation_1231  1
    load_1_10_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_23  arc_capacity_977  -25
    arc_1_10_23  connected_order_arc_978  -14
    arc_1_10_23  out_degree_1227  1
    arc_1_10_23  in_degree_1284  1
    arc_1_10_23  original_T_including_depot_unload_1293  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_23  arc_capacity_977  1
    load_1_10_23  segment_load_conservation_1231  1
    load_1_10_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_979  -25
    arc_1_11_0  depot_return_or_bypass_1205  1
    arc_1_11_0  out_degree_1234  1
    arc_1_11_0  original_T_including_depot_unload_1293  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_979  1
    load_1_11_0  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_980  -25
    arc_1_11_7  connected_order_arc_981  -14
    arc_1_11_7  in_degree_1207  1
    arc_1_11_7  out_degree_1234  1
    arc_1_11_7  original_T_including_depot_unload_1293  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_980  1
    load_1_11_7  segment_load_conservation_1210  -1
    load_1_11_7  segment_prefix_lb_1211  1
    load_1_11_7  segment_prefix_ub_1212  1
    load_1_11_7  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_982  -25
    arc_1_11_8  connected_order_arc_983  -14
    arc_1_11_8  in_degree_1214  1
    arc_1_11_8  out_degree_1234  1
    arc_1_11_8  original_T_including_depot_unload_1293  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_982  1
    load_1_11_8  segment_load_conservation_1217  -1
    load_1_11_8  segment_prefix_lb_1218  1
    load_1_11_8  segment_prefix_ub_1219  1
    load_1_11_8  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_984  -25
    arc_1_11_9  connected_order_arc_985  -14
    arc_1_11_9  in_degree_1221  1
    arc_1_11_9  out_degree_1234  1
    arc_1_11_9  original_T_including_depot_unload_1293  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_984  1
    load_1_11_9  segment_load_conservation_1224  -1
    load_1_11_9  segment_prefix_lb_1225  1
    load_1_11_9  segment_prefix_ub_1226  1
    load_1_11_9  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_986  -25
    arc_1_11_10  connected_order_arc_987  -14
    arc_1_11_10  in_degree_1228  1
    arc_1_11_10  out_degree_1234  1
    arc_1_11_10  original_T_including_depot_unload_1293  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_986  1
    load_1_11_10  segment_load_conservation_1231  -1
    load_1_11_10  segment_prefix_lb_1232  1
    load_1_11_10  segment_prefix_ub_1233  1
    load_1_11_10  segment_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_988  -25
    arc_1_11_16  connected_order_arc_989  -14
    arc_1_11_16  out_degree_1234  1
    arc_1_11_16  in_degree_1242  1
    arc_1_11_16  original_T_including_depot_unload_1293  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_988  1
    load_1_11_16  segment_load_conservation_1238  1
    load_1_11_16  free_load_conservation_1246  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_17  arc_capacity_990  -25
    arc_1_11_17  connected_order_arc_991  -14
    arc_1_11_17  out_degree_1234  1
    arc_1_11_17  in_degree_1248  1
    arc_1_11_17  original_T_including_depot_unload_1293  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_17  arc_capacity_990  1
    load_1_11_17  segment_load_conservation_1238  1
    load_1_11_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_18  arc_capacity_992  -25
    arc_1_11_18  connected_order_arc_993  -14
    arc_1_11_18  out_degree_1234  1
    arc_1_11_18  in_degree_1254  1
    arc_1_11_18  original_T_including_depot_unload_1293  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_18  arc_capacity_992  1
    load_1_11_18  segment_load_conservation_1238  1
    load_1_11_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_19  arc_capacity_994  -25
    arc_1_11_19  connected_order_arc_995  -14
    arc_1_11_19  out_degree_1234  1
    arc_1_11_19  in_degree_1260  1
    arc_1_11_19  original_T_including_depot_unload_1293  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_19  arc_capacity_994  1
    load_1_11_19  segment_load_conservation_1238  1
    load_1_11_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_20  arc_capacity_996  -25
    arc_1_11_20  connected_order_arc_997  -14
    arc_1_11_20  out_degree_1234  1
    arc_1_11_20  in_degree_1266  1
    arc_1_11_20  original_T_including_depot_unload_1293  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_20  arc_capacity_996  1
    load_1_11_20  segment_load_conservation_1238  1
    load_1_11_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_21  arc_capacity_998  -25
    arc_1_11_21  connected_order_arc_999  -14
    arc_1_11_21  out_degree_1234  1
    arc_1_11_21  in_degree_1272  1
    arc_1_11_21  original_T_including_depot_unload_1293  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_21  arc_capacity_998  1
    load_1_11_21  segment_load_conservation_1238  1
    load_1_11_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_22  arc_capacity_1000  -25
    arc_1_11_22  connected_order_arc_1001  -14
    arc_1_11_22  out_degree_1234  1
    arc_1_11_22  in_degree_1278  1
    arc_1_11_22  original_T_including_depot_unload_1293  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_22  arc_capacity_1000  1
    load_1_11_22  segment_load_conservation_1238  1
    load_1_11_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_23  arc_capacity_1002  -25
    arc_1_11_23  connected_order_arc_1003  -14
    arc_1_11_23  out_degree_1234  1
    arc_1_11_23  in_degree_1284  1
    arc_1_11_23  original_T_including_depot_unload_1293  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_23  arc_capacity_1002  1
    load_1_11_23  segment_load_conservation_1238  1
    load_1_11_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1004  -25
    arc_1_16_0  depot_return_or_bypass_1205  1
    arc_1_16_0  out_degree_1241  1
    arc_1_16_0  original_T_including_depot_unload_1293  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1004  1
    load_1_16_0  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1005  -25
    arc_1_16_7  connected_order_arc_1006  -14
    arc_1_16_7  in_degree_1207  1
    arc_1_16_7  out_degree_1241  1
    arc_1_16_7  original_T_including_depot_unload_1293  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1005  1
    load_1_16_7  segment_load_conservation_1210  -1
    load_1_16_7  segment_prefix_lb_1211  1
    load_1_16_7  segment_prefix_ub_1212  1
    load_1_16_7  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1007  -25
    arc_1_16_8  connected_order_arc_1008  -14
    arc_1_16_8  in_degree_1214  1
    arc_1_16_8  out_degree_1241  1
    arc_1_16_8  original_T_including_depot_unload_1293  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1007  1
    load_1_16_8  segment_load_conservation_1217  -1
    load_1_16_8  segment_prefix_lb_1218  1
    load_1_16_8  segment_prefix_ub_1219  1
    load_1_16_8  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1009  -25
    arc_1_16_9  connected_order_arc_1010  -14
    arc_1_16_9  in_degree_1221  1
    arc_1_16_9  out_degree_1241  1
    arc_1_16_9  original_T_including_depot_unload_1293  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1009  1
    load_1_16_9  segment_load_conservation_1224  -1
    load_1_16_9  segment_prefix_lb_1225  1
    load_1_16_9  segment_prefix_ub_1226  1
    load_1_16_9  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1011  -25
    arc_1_16_10  connected_order_arc_1012  -14
    arc_1_16_10  in_degree_1228  1
    arc_1_16_10  out_degree_1241  1
    arc_1_16_10  original_T_including_depot_unload_1293  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1011  1
    load_1_16_10  segment_load_conservation_1231  -1
    load_1_16_10  segment_prefix_lb_1232  1
    load_1_16_10  segment_prefix_ub_1233  1
    load_1_16_10  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1013  -25
    arc_1_16_11  connected_order_arc_1014  -14
    arc_1_16_11  in_degree_1235  1
    arc_1_16_11  out_degree_1241  1
    arc_1_16_11  original_T_including_depot_unload_1293  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1013  1
    load_1_16_11  segment_load_conservation_1238  -1
    load_1_16_11  segment_prefix_lb_1239  1
    load_1_16_11  segment_prefix_ub_1240  1
    load_1_16_11  free_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1015  -25
    arc_1_16_17  connected_order_arc_1016  -14
    arc_1_16_17  out_degree_1241  1
    arc_1_16_17  in_degree_1248  1
    arc_1_16_17  original_T_including_depot_unload_1293  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1015  1
    load_1_16_17  free_load_conservation_1246  1
    load_1_16_17  free_load_conservation_1252  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1017  -25
    arc_1_16_18  connected_order_arc_1018  -14
    arc_1_16_18  out_degree_1241  1
    arc_1_16_18  in_degree_1254  1
    arc_1_16_18  original_T_including_depot_unload_1293  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1017  1
    load_1_16_18  free_load_conservation_1246  1
    load_1_16_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1019  -25
    arc_1_16_19  connected_order_arc_1020  -14
    arc_1_16_19  out_degree_1241  1
    arc_1_16_19  in_degree_1260  1
    arc_1_16_19  original_T_including_depot_unload_1293  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1019  1
    load_1_16_19  free_load_conservation_1246  1
    load_1_16_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1021  -25
    arc_1_16_20  connected_order_arc_1022  -14
    arc_1_16_20  out_degree_1241  1
    arc_1_16_20  in_degree_1266  1
    arc_1_16_20  original_T_including_depot_unload_1293  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1021  1
    load_1_16_20  free_load_conservation_1246  1
    load_1_16_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1023  -25
    arc_1_16_21  connected_order_arc_1024  -14
    arc_1_16_21  out_degree_1241  1
    arc_1_16_21  in_degree_1272  1
    arc_1_16_21  original_T_including_depot_unload_1293  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1023  1
    load_1_16_21  free_load_conservation_1246  1
    load_1_16_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_1025  -25
    arc_1_16_22  connected_order_arc_1026  -14
    arc_1_16_22  out_degree_1241  1
    arc_1_16_22  in_degree_1278  1
    arc_1_16_22  original_T_including_depot_unload_1293  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_1025  1
    load_1_16_22  free_load_conservation_1246  1
    load_1_16_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_23  arc_capacity_1027  -25
    arc_1_16_23  connected_order_arc_1028  -14
    arc_1_16_23  out_degree_1241  1
    arc_1_16_23  in_degree_1284  1
    arc_1_16_23  original_T_including_depot_unload_1293  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_23  arc_capacity_1027  1
    load_1_16_23  free_load_conservation_1246  1
    load_1_16_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1029  -25
    arc_1_17_0  depot_return_or_bypass_1205  1
    arc_1_17_0  out_degree_1247  1
    arc_1_17_0  original_T_including_depot_unload_1293  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1029  1
    load_1_17_0  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1030  -25
    arc_1_17_7  connected_order_arc_1031  -14
    arc_1_17_7  in_degree_1207  1
    arc_1_17_7  out_degree_1247  1
    arc_1_17_7  original_T_including_depot_unload_1293  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1030  1
    load_1_17_7  segment_load_conservation_1210  -1
    load_1_17_7  segment_prefix_lb_1211  1
    load_1_17_7  segment_prefix_ub_1212  1
    load_1_17_7  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1032  -25
    arc_1_17_8  connected_order_arc_1033  -14
    arc_1_17_8  in_degree_1214  1
    arc_1_17_8  out_degree_1247  1
    arc_1_17_8  original_T_including_depot_unload_1293  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1032  1
    load_1_17_8  segment_load_conservation_1217  -1
    load_1_17_8  segment_prefix_lb_1218  1
    load_1_17_8  segment_prefix_ub_1219  1
    load_1_17_8  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1034  -25
    arc_1_17_9  connected_order_arc_1035  -14
    arc_1_17_9  in_degree_1221  1
    arc_1_17_9  out_degree_1247  1
    arc_1_17_9  original_T_including_depot_unload_1293  2.0027314450664605e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1034  1
    load_1_17_9  segment_load_conservation_1224  -1
    load_1_17_9  segment_prefix_lb_1225  1
    load_1_17_9  segment_prefix_ub_1226  1
    load_1_17_9  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1036  -25
    arc_1_17_10  connected_order_arc_1037  -14
    arc_1_17_10  in_degree_1228  1
    arc_1_17_10  out_degree_1247  1
    arc_1_17_10  original_T_including_depot_unload_1293  1.7644788835951622e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1036  1
    load_1_17_10  segment_load_conservation_1231  -1
    load_1_17_10  segment_prefix_lb_1232  1
    load_1_17_10  segment_prefix_ub_1233  1
    load_1_17_10  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_11  arc_capacity_1038  -25
    arc_1_17_11  connected_order_arc_1039  -14
    arc_1_17_11  in_degree_1235  1
    arc_1_17_11  out_degree_1247  1
    arc_1_17_11  original_T_including_depot_unload_1293  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_11  arc_capacity_1038  1
    load_1_17_11  segment_load_conservation_1238  -1
    load_1_17_11  segment_prefix_lb_1239  1
    load_1_17_11  segment_prefix_ub_1240  1
    load_1_17_11  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1040  -25
    arc_1_17_16  connected_order_arc_1041  -14
    arc_1_17_16  in_degree_1242  1
    arc_1_17_16  out_degree_1247  1
    arc_1_17_16  original_T_including_depot_unload_1293  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1040  1
    load_1_17_16  free_load_conservation_1246  -1
    load_1_17_16  free_load_conservation_1252  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1042  -25
    arc_1_17_18  connected_order_arc_1043  -14
    arc_1_17_18  out_degree_1247  1
    arc_1_17_18  in_degree_1254  1
    arc_1_17_18  original_T_including_depot_unload_1293  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1042  1
    load_1_17_18  free_load_conservation_1252  1
    load_1_17_18  free_load_conservation_1258  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1044  -25
    arc_1_17_19  connected_order_arc_1045  -14
    arc_1_17_19  out_degree_1247  1
    arc_1_17_19  in_degree_1260  1
    arc_1_17_19  original_T_including_depot_unload_1293  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1044  1
    load_1_17_19  free_load_conservation_1252  1
    load_1_17_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1046  -25
    arc_1_17_20  connected_order_arc_1047  -14
    arc_1_17_20  out_degree_1247  1
    arc_1_17_20  in_degree_1266  1
    arc_1_17_20  original_T_including_depot_unload_1293  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1046  1
    load_1_17_20  free_load_conservation_1252  1
    load_1_17_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1048  -25
    arc_1_17_21  connected_order_arc_1049  -14
    arc_1_17_21  out_degree_1247  1
    arc_1_17_21  in_degree_1272  1
    arc_1_17_21  original_T_including_depot_unload_1293  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1048  1
    load_1_17_21  free_load_conservation_1252  1
    load_1_17_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_1050  -25
    arc_1_17_22  connected_order_arc_1051  -14
    arc_1_17_22  out_degree_1247  1
    arc_1_17_22  in_degree_1278  1
    arc_1_17_22  original_T_including_depot_unload_1293  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_1050  1
    load_1_17_22  free_load_conservation_1252  1
    load_1_17_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_23  arc_capacity_1052  -25
    arc_1_17_23  connected_order_arc_1053  -14
    arc_1_17_23  out_degree_1247  1
    arc_1_17_23  in_degree_1284  1
    arc_1_17_23  original_T_including_depot_unload_1293  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_23  arc_capacity_1052  1
    load_1_17_23  free_load_conservation_1252  1
    load_1_17_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1054  -25
    arc_1_18_0  depot_return_or_bypass_1205  1
    arc_1_18_0  out_degree_1253  1
    arc_1_18_0  original_T_including_depot_unload_1293  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1054  1
    load_1_18_0  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1055  -25
    arc_1_18_7  connected_order_arc_1056  -14
    arc_1_18_7  in_degree_1207  1
    arc_1_18_7  out_degree_1253  1
    arc_1_18_7  original_T_including_depot_unload_1293  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1055  1
    load_1_18_7  segment_load_conservation_1210  -1
    load_1_18_7  segment_prefix_lb_1211  1
    load_1_18_7  segment_prefix_ub_1212  1
    load_1_18_7  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1057  -25
    arc_1_18_8  connected_order_arc_1058  -14
    arc_1_18_8  in_degree_1214  1
    arc_1_18_8  out_degree_1253  1
    arc_1_18_8  original_T_including_depot_unload_1293  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1057  1
    load_1_18_8  segment_load_conservation_1217  -1
    load_1_18_8  segment_prefix_lb_1218  1
    load_1_18_8  segment_prefix_ub_1219  1
    load_1_18_8  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1059  -25
    arc_1_18_9  connected_order_arc_1060  -14
    arc_1_18_9  in_degree_1221  1
    arc_1_18_9  out_degree_1253  1
    arc_1_18_9  original_T_including_depot_unload_1293  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1059  1
    load_1_18_9  segment_load_conservation_1224  -1
    load_1_18_9  segment_prefix_lb_1225  1
    load_1_18_9  segment_prefix_ub_1226  1
    load_1_18_9  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1061  -25
    arc_1_18_10  connected_order_arc_1062  -14
    arc_1_18_10  in_degree_1228  1
    arc_1_18_10  out_degree_1253  1
    arc_1_18_10  original_T_including_depot_unload_1293  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1061  1
    load_1_18_10  segment_load_conservation_1231  -1
    load_1_18_10  segment_prefix_lb_1232  1
    load_1_18_10  segment_prefix_ub_1233  1
    load_1_18_10  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_11  arc_capacity_1063  -25
    arc_1_18_11  connected_order_arc_1064  -14
    arc_1_18_11  in_degree_1235  1
    arc_1_18_11  out_degree_1253  1
    arc_1_18_11  original_T_including_depot_unload_1293  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_11  arc_capacity_1063  1
    load_1_18_11  segment_load_conservation_1238  -1
    load_1_18_11  segment_prefix_lb_1239  1
    load_1_18_11  segment_prefix_ub_1240  1
    load_1_18_11  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1065  -25
    arc_1_18_16  connected_order_arc_1066  -14
    arc_1_18_16  in_degree_1242  1
    arc_1_18_16  out_degree_1253  1
    arc_1_18_16  original_T_including_depot_unload_1293  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1065  1
    load_1_18_16  free_load_conservation_1246  -1
    load_1_18_16  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1067  -25
    arc_1_18_17  connected_order_arc_1068  -14
    arc_1_18_17  in_degree_1248  1
    arc_1_18_17  out_degree_1253  1
    arc_1_18_17  original_T_including_depot_unload_1293  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1067  1
    load_1_18_17  free_load_conservation_1252  -1
    load_1_18_17  free_load_conservation_1258  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1069  -25
    arc_1_18_19  connected_order_arc_1070  -14
    arc_1_18_19  out_degree_1253  1
    arc_1_18_19  in_degree_1260  1
    arc_1_18_19  original_T_including_depot_unload_1293  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1069  1
    load_1_18_19  free_load_conservation_1258  1
    load_1_18_19  free_load_conservation_1264  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1071  -25
    arc_1_18_20  connected_order_arc_1072  -14
    arc_1_18_20  out_degree_1253  1
    arc_1_18_20  in_degree_1266  1
    arc_1_18_20  original_T_including_depot_unload_1293  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1071  1
    load_1_18_20  free_load_conservation_1258  1
    load_1_18_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1073  -25
    arc_1_18_21  connected_order_arc_1074  -14
    arc_1_18_21  out_degree_1253  1
    arc_1_18_21  in_degree_1272  1
    arc_1_18_21  original_T_including_depot_unload_1293  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1073  1
    load_1_18_21  free_load_conservation_1258  1
    load_1_18_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_1075  -25
    arc_1_18_22  connected_order_arc_1076  -14
    arc_1_18_22  out_degree_1253  1
    arc_1_18_22  in_degree_1278  1
    arc_1_18_22  original_T_including_depot_unload_1293  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_1075  1
    load_1_18_22  free_load_conservation_1258  1
    load_1_18_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_23  arc_capacity_1077  -25
    arc_1_18_23  connected_order_arc_1078  -14
    arc_1_18_23  out_degree_1253  1
    arc_1_18_23  in_degree_1284  1
    arc_1_18_23  original_T_including_depot_unload_1293  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_23  arc_capacity_1077  1
    load_1_18_23  free_load_conservation_1258  1
    load_1_18_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1079  -25
    arc_1_19_0  depot_return_or_bypass_1205  1
    arc_1_19_0  out_degree_1259  1
    arc_1_19_0  original_T_including_depot_unload_1293  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1079  1
    load_1_19_0  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1080  -25
    arc_1_19_7  connected_order_arc_1081  -14
    arc_1_19_7  in_degree_1207  1
    arc_1_19_7  out_degree_1259  1
    arc_1_19_7  original_T_including_depot_unload_1293  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1080  1
    load_1_19_7  segment_load_conservation_1210  -1
    load_1_19_7  segment_prefix_lb_1211  1
    load_1_19_7  segment_prefix_ub_1212  1
    load_1_19_7  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1082  -25
    arc_1_19_8  connected_order_arc_1083  -14
    arc_1_19_8  in_degree_1214  1
    arc_1_19_8  out_degree_1259  1
    arc_1_19_8  original_T_including_depot_unload_1293  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1082  1
    load_1_19_8  segment_load_conservation_1217  -1
    load_1_19_8  segment_prefix_lb_1218  1
    load_1_19_8  segment_prefix_ub_1219  1
    load_1_19_8  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1084  -25
    arc_1_19_9  connected_order_arc_1085  -14
    arc_1_19_9  in_degree_1221  1
    arc_1_19_9  out_degree_1259  1
    arc_1_19_9  original_T_including_depot_unload_1293  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1084  1
    load_1_19_9  segment_load_conservation_1224  -1
    load_1_19_9  segment_prefix_lb_1225  1
    load_1_19_9  segment_prefix_ub_1226  1
    load_1_19_9  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1086  -25
    arc_1_19_10  connected_order_arc_1087  -14
    arc_1_19_10  in_degree_1228  1
    arc_1_19_10  out_degree_1259  1
    arc_1_19_10  original_T_including_depot_unload_1293  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1086  1
    load_1_19_10  segment_load_conservation_1231  -1
    load_1_19_10  segment_prefix_lb_1232  1
    load_1_19_10  segment_prefix_ub_1233  1
    load_1_19_10  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_11  arc_capacity_1088  -25
    arc_1_19_11  connected_order_arc_1089  -14
    arc_1_19_11  in_degree_1235  1
    arc_1_19_11  out_degree_1259  1
    arc_1_19_11  original_T_including_depot_unload_1293  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_11  arc_capacity_1088  1
    load_1_19_11  segment_load_conservation_1238  -1
    load_1_19_11  segment_prefix_lb_1239  1
    load_1_19_11  segment_prefix_ub_1240  1
    load_1_19_11  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1090  -25
    arc_1_19_16  connected_order_arc_1091  -14
    arc_1_19_16  in_degree_1242  1
    arc_1_19_16  out_degree_1259  1
    arc_1_19_16  original_T_including_depot_unload_1293  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1090  1
    load_1_19_16  free_load_conservation_1246  -1
    load_1_19_16  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1092  -25
    arc_1_19_17  connected_order_arc_1093  -14
    arc_1_19_17  in_degree_1248  1
    arc_1_19_17  out_degree_1259  1
    arc_1_19_17  original_T_including_depot_unload_1293  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1092  1
    load_1_19_17  free_load_conservation_1252  -1
    load_1_19_17  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1094  -25
    arc_1_19_18  connected_order_arc_1095  -14
    arc_1_19_18  in_degree_1254  1
    arc_1_19_18  out_degree_1259  1
    arc_1_19_18  original_T_including_depot_unload_1293  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1094  1
    load_1_19_18  free_load_conservation_1258  -1
    load_1_19_18  free_load_conservation_1264  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1096  -25
    arc_1_19_20  connected_order_arc_1097  -14
    arc_1_19_20  out_degree_1259  1
    arc_1_19_20  in_degree_1266  1
    arc_1_19_20  original_T_including_depot_unload_1293  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1096  1
    load_1_19_20  free_load_conservation_1264  1
    load_1_19_20  free_load_conservation_1270  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1098  -25
    arc_1_19_21  connected_order_arc_1099  -14
    arc_1_19_21  out_degree_1259  1
    arc_1_19_21  in_degree_1272  1
    arc_1_19_21  original_T_including_depot_unload_1293  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1098  1
    load_1_19_21  free_load_conservation_1264  1
    load_1_19_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1100  -25
    arc_1_19_22  connected_order_arc_1101  -14
    arc_1_19_22  out_degree_1259  1
    arc_1_19_22  in_degree_1278  1
    arc_1_19_22  original_T_including_depot_unload_1293  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1100  1
    load_1_19_22  free_load_conservation_1264  1
    load_1_19_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_23  arc_capacity_1102  -25
    arc_1_19_23  connected_order_arc_1103  -14
    arc_1_19_23  out_degree_1259  1
    arc_1_19_23  in_degree_1284  1
    arc_1_19_23  original_T_including_depot_unload_1293  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_23  arc_capacity_1102  1
    load_1_19_23  free_load_conservation_1264  1
    load_1_19_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1104  -25
    arc_1_20_0  depot_return_or_bypass_1205  1
    arc_1_20_0  out_degree_1265  1
    arc_1_20_0  original_T_including_depot_unload_1293  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1104  1
    load_1_20_0  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1105  -25
    arc_1_20_7  connected_order_arc_1106  -14
    arc_1_20_7  in_degree_1207  1
    arc_1_20_7  out_degree_1265  1
    arc_1_20_7  original_T_including_depot_unload_1293  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1105  1
    load_1_20_7  segment_load_conservation_1210  -1
    load_1_20_7  segment_prefix_lb_1211  1
    load_1_20_7  segment_prefix_ub_1212  1
    load_1_20_7  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1107  -25
    arc_1_20_8  connected_order_arc_1108  -14
    arc_1_20_8  in_degree_1214  1
    arc_1_20_8  out_degree_1265  1
    arc_1_20_8  original_T_including_depot_unload_1293  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1107  1
    load_1_20_8  segment_load_conservation_1217  -1
    load_1_20_8  segment_prefix_lb_1218  1
    load_1_20_8  segment_prefix_ub_1219  1
    load_1_20_8  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1109  -25
    arc_1_20_9  connected_order_arc_1110  -14
    arc_1_20_9  in_degree_1221  1
    arc_1_20_9  out_degree_1265  1
    arc_1_20_9  original_T_including_depot_unload_1293  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1109  1
    load_1_20_9  segment_load_conservation_1224  -1
    load_1_20_9  segment_prefix_lb_1225  1
    load_1_20_9  segment_prefix_ub_1226  1
    load_1_20_9  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1111  -25
    arc_1_20_10  connected_order_arc_1112  -14
    arc_1_20_10  in_degree_1228  1
    arc_1_20_10  out_degree_1265  1
    arc_1_20_10  original_T_including_depot_unload_1293  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1111  1
    load_1_20_10  segment_load_conservation_1231  -1
    load_1_20_10  segment_prefix_lb_1232  1
    load_1_20_10  segment_prefix_ub_1233  1
    load_1_20_10  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_11  arc_capacity_1113  -25
    arc_1_20_11  connected_order_arc_1114  -14
    arc_1_20_11  in_degree_1235  1
    arc_1_20_11  out_degree_1265  1
    arc_1_20_11  original_T_including_depot_unload_1293  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_11  arc_capacity_1113  1
    load_1_20_11  segment_load_conservation_1238  -1
    load_1_20_11  segment_prefix_lb_1239  1
    load_1_20_11  segment_prefix_ub_1240  1
    load_1_20_11  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1115  -25
    arc_1_20_16  connected_order_arc_1116  -14
    arc_1_20_16  in_degree_1242  1
    arc_1_20_16  out_degree_1265  1
    arc_1_20_16  original_T_including_depot_unload_1293  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1115  1
    load_1_20_16  free_load_conservation_1246  -1
    load_1_20_16  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1117  -25
    arc_1_20_17  connected_order_arc_1118  -14
    arc_1_20_17  in_degree_1248  1
    arc_1_20_17  out_degree_1265  1
    arc_1_20_17  original_T_including_depot_unload_1293  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1117  1
    load_1_20_17  free_load_conservation_1252  -1
    load_1_20_17  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1119  -25
    arc_1_20_18  connected_order_arc_1120  -14
    arc_1_20_18  in_degree_1254  1
    arc_1_20_18  out_degree_1265  1
    arc_1_20_18  original_T_including_depot_unload_1293  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1119  1
    load_1_20_18  free_load_conservation_1258  -1
    load_1_20_18  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1121  -25
    arc_1_20_19  connected_order_arc_1122  -14
    arc_1_20_19  in_degree_1260  1
    arc_1_20_19  out_degree_1265  1
    arc_1_20_19  original_T_including_depot_unload_1293  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1121  1
    load_1_20_19  free_load_conservation_1264  -1
    load_1_20_19  free_load_conservation_1270  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1123  -25
    arc_1_20_21  connected_order_arc_1124  -14
    arc_1_20_21  out_degree_1265  1
    arc_1_20_21  in_degree_1272  1
    arc_1_20_21  original_T_including_depot_unload_1293  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1123  1
    load_1_20_21  free_load_conservation_1270  1
    load_1_20_21  free_load_conservation_1276  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1125  -25
    arc_1_20_22  connected_order_arc_1126  -14
    arc_1_20_22  out_degree_1265  1
    arc_1_20_22  in_degree_1278  1
    arc_1_20_22  original_T_including_depot_unload_1293  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1125  1
    load_1_20_22  free_load_conservation_1270  1
    load_1_20_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_23  arc_capacity_1127  -25
    arc_1_20_23  connected_order_arc_1128  -14
    arc_1_20_23  out_degree_1265  1
    arc_1_20_23  in_degree_1284  1
    arc_1_20_23  original_T_including_depot_unload_1293  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_23  arc_capacity_1127  1
    load_1_20_23  free_load_conservation_1270  1
    load_1_20_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1129  -25
    arc_1_21_0  depot_return_or_bypass_1205  1
    arc_1_21_0  out_degree_1271  1
    arc_1_21_0  original_T_including_depot_unload_1293  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1129  1
    load_1_21_0  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1130  -25
    arc_1_21_7  connected_order_arc_1131  -14
    arc_1_21_7  in_degree_1207  1
    arc_1_21_7  out_degree_1271  1
    arc_1_21_7  original_T_including_depot_unload_1293  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1130  1
    load_1_21_7  segment_load_conservation_1210  -1
    load_1_21_7  segment_prefix_lb_1211  1
    load_1_21_7  segment_prefix_ub_1212  1
    load_1_21_7  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1132  -25
    arc_1_21_8  connected_order_arc_1133  -14
    arc_1_21_8  in_degree_1214  1
    arc_1_21_8  out_degree_1271  1
    arc_1_21_8  original_T_including_depot_unload_1293  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1132  1
    load_1_21_8  segment_load_conservation_1217  -1
    load_1_21_8  segment_prefix_lb_1218  1
    load_1_21_8  segment_prefix_ub_1219  1
    load_1_21_8  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1134  -25
    arc_1_21_9  connected_order_arc_1135  -14
    arc_1_21_9  in_degree_1221  1
    arc_1_21_9  out_degree_1271  1
    arc_1_21_9  original_T_including_depot_unload_1293  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1134  1
    load_1_21_9  segment_load_conservation_1224  -1
    load_1_21_9  segment_prefix_lb_1225  1
    load_1_21_9  segment_prefix_ub_1226  1
    load_1_21_9  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1136  -25
    arc_1_21_10  connected_order_arc_1137  -14
    arc_1_21_10  in_degree_1228  1
    arc_1_21_10  out_degree_1271  1
    arc_1_21_10  original_T_including_depot_unload_1293  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1136  1
    load_1_21_10  segment_load_conservation_1231  -1
    load_1_21_10  segment_prefix_lb_1232  1
    load_1_21_10  segment_prefix_ub_1233  1
    load_1_21_10  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_11  arc_capacity_1138  -25
    arc_1_21_11  connected_order_arc_1139  -14
    arc_1_21_11  in_degree_1235  1
    arc_1_21_11  out_degree_1271  1
    arc_1_21_11  original_T_including_depot_unload_1293  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_11  arc_capacity_1138  1
    load_1_21_11  segment_load_conservation_1238  -1
    load_1_21_11  segment_prefix_lb_1239  1
    load_1_21_11  segment_prefix_ub_1240  1
    load_1_21_11  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1140  -25
    arc_1_21_16  connected_order_arc_1141  -14
    arc_1_21_16  in_degree_1242  1
    arc_1_21_16  out_degree_1271  1
    arc_1_21_16  original_T_including_depot_unload_1293  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1140  1
    load_1_21_16  free_load_conservation_1246  -1
    load_1_21_16  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1142  -25
    arc_1_21_17  connected_order_arc_1143  -14
    arc_1_21_17  in_degree_1248  1
    arc_1_21_17  out_degree_1271  1
    arc_1_21_17  original_T_including_depot_unload_1293  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1142  1
    load_1_21_17  free_load_conservation_1252  -1
    load_1_21_17  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1144  -25
    arc_1_21_18  connected_order_arc_1145  -14
    arc_1_21_18  in_degree_1254  1
    arc_1_21_18  out_degree_1271  1
    arc_1_21_18  original_T_including_depot_unload_1293  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1144  1
    load_1_21_18  free_load_conservation_1258  -1
    load_1_21_18  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1146  -25
    arc_1_21_19  connected_order_arc_1147  -14
    arc_1_21_19  in_degree_1260  1
    arc_1_21_19  out_degree_1271  1
    arc_1_21_19  original_T_including_depot_unload_1293  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1146  1
    load_1_21_19  free_load_conservation_1264  -1
    load_1_21_19  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1148  -25
    arc_1_21_20  connected_order_arc_1149  -14
    arc_1_21_20  in_degree_1266  1
    arc_1_21_20  out_degree_1271  1
    arc_1_21_20  original_T_including_depot_unload_1293  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1148  1
    load_1_21_20  free_load_conservation_1270  -1
    load_1_21_20  free_load_conservation_1276  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1150  -25
    arc_1_21_22  connected_order_arc_1151  -14
    arc_1_21_22  out_degree_1271  1
    arc_1_21_22  in_degree_1278  1
    arc_1_21_22  original_T_including_depot_unload_1293  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1150  1
    load_1_21_22  free_load_conservation_1276  1
    load_1_21_22  free_load_conservation_1282  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_23  arc_capacity_1152  -25
    arc_1_21_23  connected_order_arc_1153  -14
    arc_1_21_23  out_degree_1271  1
    arc_1_21_23  in_degree_1284  1
    arc_1_21_23  original_T_including_depot_unload_1293  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_23  arc_capacity_1152  1
    load_1_21_23  free_load_conservation_1276  1
    load_1_21_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1154  -25
    arc_1_22_0  depot_return_or_bypass_1205  1
    arc_1_22_0  out_degree_1277  1
    arc_1_22_0  original_T_including_depot_unload_1293  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1154  1
    load_1_22_0  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1155  -25
    arc_1_22_7  connected_order_arc_1156  -14
    arc_1_22_7  in_degree_1207  1
    arc_1_22_7  out_degree_1277  1
    arc_1_22_7  original_T_including_depot_unload_1293  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1155  1
    load_1_22_7  segment_load_conservation_1210  -1
    load_1_22_7  segment_prefix_lb_1211  1
    load_1_22_7  segment_prefix_ub_1212  1
    load_1_22_7  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1157  -25
    arc_1_22_8  connected_order_arc_1158  -14
    arc_1_22_8  in_degree_1214  1
    arc_1_22_8  out_degree_1277  1
    arc_1_22_8  original_T_including_depot_unload_1293  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1157  1
    load_1_22_8  segment_load_conservation_1217  -1
    load_1_22_8  segment_prefix_lb_1218  1
    load_1_22_8  segment_prefix_ub_1219  1
    load_1_22_8  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1159  -25
    arc_1_22_9  connected_order_arc_1160  -14
    arc_1_22_9  in_degree_1221  1
    arc_1_22_9  out_degree_1277  1
    arc_1_22_9  original_T_including_depot_unload_1293  1.1952607376785465e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1159  1
    load_1_22_9  segment_load_conservation_1224  -1
    load_1_22_9  segment_prefix_lb_1225  1
    load_1_22_9  segment_prefix_ub_1226  1
    load_1_22_9  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_10  arc_capacity_1161  -25
    arc_1_22_10  connected_order_arc_1162  -14
    arc_1_22_10  in_degree_1228  1
    arc_1_22_10  out_degree_1277  1
    arc_1_22_10  original_T_including_depot_unload_1293  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_10  arc_capacity_1161  1
    load_1_22_10  segment_load_conservation_1231  -1
    load_1_22_10  segment_prefix_lb_1232  1
    load_1_22_10  segment_prefix_ub_1233  1
    load_1_22_10  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_11  arc_capacity_1163  -25
    arc_1_22_11  connected_order_arc_1164  -14
    arc_1_22_11  in_degree_1235  1
    arc_1_22_11  out_degree_1277  1
    arc_1_22_11  original_T_including_depot_unload_1293  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_11  arc_capacity_1163  1
    load_1_22_11  segment_load_conservation_1238  -1
    load_1_22_11  segment_prefix_lb_1239  1
    load_1_22_11  segment_prefix_ub_1240  1
    load_1_22_11  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1165  -25
    arc_1_22_16  connected_order_arc_1166  -14
    arc_1_22_16  in_degree_1242  1
    arc_1_22_16  out_degree_1277  1
    arc_1_22_16  original_T_including_depot_unload_1293  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1165  1
    load_1_22_16  free_load_conservation_1246  -1
    load_1_22_16  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1167  -25
    arc_1_22_17  connected_order_arc_1168  -14
    arc_1_22_17  in_degree_1248  1
    arc_1_22_17  out_degree_1277  1
    arc_1_22_17  original_T_including_depot_unload_1293  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1167  1
    load_1_22_17  free_load_conservation_1252  -1
    load_1_22_17  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1169  -25
    arc_1_22_18  connected_order_arc_1170  -14
    arc_1_22_18  in_degree_1254  1
    arc_1_22_18  out_degree_1277  1
    arc_1_22_18  original_T_including_depot_unload_1293  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1169  1
    load_1_22_18  free_load_conservation_1258  -1
    load_1_22_18  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1171  -25
    arc_1_22_19  connected_order_arc_1172  -14
    arc_1_22_19  in_degree_1260  1
    arc_1_22_19  out_degree_1277  1
    arc_1_22_19  original_T_including_depot_unload_1293  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1171  1
    load_1_22_19  free_load_conservation_1264  -1
    load_1_22_19  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1173  -25
    arc_1_22_20  connected_order_arc_1174  -14
    arc_1_22_20  in_degree_1266  1
    arc_1_22_20  out_degree_1277  1
    arc_1_22_20  original_T_including_depot_unload_1293  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1173  1
    load_1_22_20  free_load_conservation_1270  -1
    load_1_22_20  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1175  -25
    arc_1_22_21  connected_order_arc_1176  -14
    arc_1_22_21  in_degree_1272  1
    arc_1_22_21  out_degree_1277  1
    arc_1_22_21  original_T_including_depot_unload_1293  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1175  1
    load_1_22_21  free_load_conservation_1276  -1
    load_1_22_21  free_load_conservation_1282  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_23  arc_capacity_1177  -25
    arc_1_22_23  connected_order_arc_1178  -14
    arc_1_22_23  out_degree_1277  1
    arc_1_22_23  in_degree_1284  1
    arc_1_22_23  original_T_including_depot_unload_1293  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_23  arc_capacity_1177  1
    load_1_22_23  free_load_conservation_1282  1
    load_1_22_23  free_load_conservation_1288  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_0  arc_capacity_1179  -25
    arc_1_23_0  depot_return_or_bypass_1205  1
    arc_1_23_0  out_degree_1283  1
    arc_1_23_0  original_T_including_depot_unload_1293  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_23_0  arc_capacity_1179  1
    load_1_23_0  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_7  arc_capacity_1180  -25
    arc_1_23_7  connected_order_arc_1181  -14
    arc_1_23_7  in_degree_1207  1
    arc_1_23_7  out_degree_1283  1
    arc_1_23_7  original_T_including_depot_unload_1293  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_7  arc_capacity_1180  1
    load_1_23_7  segment_load_conservation_1210  -1
    load_1_23_7  segment_prefix_lb_1211  1
    load_1_23_7  segment_prefix_ub_1212  1
    load_1_23_7  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_8  arc_capacity_1182  -25
    arc_1_23_8  connected_order_arc_1183  -14
    arc_1_23_8  in_degree_1214  1
    arc_1_23_8  out_degree_1283  1
    arc_1_23_8  original_T_including_depot_unload_1293  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_8  arc_capacity_1182  1
    load_1_23_8  segment_load_conservation_1217  -1
    load_1_23_8  segment_prefix_lb_1218  1
    load_1_23_8  segment_prefix_ub_1219  1
    load_1_23_8  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_9  arc_capacity_1184  -25
    arc_1_23_9  connected_order_arc_1185  -14
    arc_1_23_9  in_degree_1221  1
    arc_1_23_9  out_degree_1283  1
    arc_1_23_9  original_T_including_depot_unload_1293  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_9  arc_capacity_1184  1
    load_1_23_9  segment_load_conservation_1224  -1
    load_1_23_9  segment_prefix_lb_1225  1
    load_1_23_9  segment_prefix_ub_1226  1
    load_1_23_9  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_10  arc_capacity_1186  -25
    arc_1_23_10  connected_order_arc_1187  -14
    arc_1_23_10  in_degree_1228  1
    arc_1_23_10  out_degree_1283  1
    arc_1_23_10  original_T_including_depot_unload_1293  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_10  arc_capacity_1186  1
    load_1_23_10  segment_load_conservation_1231  -1
    load_1_23_10  segment_prefix_lb_1232  1
    load_1_23_10  segment_prefix_ub_1233  1
    load_1_23_10  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_11  arc_capacity_1188  -25
    arc_1_23_11  connected_order_arc_1189  -14
    arc_1_23_11  in_degree_1235  1
    arc_1_23_11  out_degree_1283  1
    arc_1_23_11  original_T_including_depot_unload_1293  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_23_11  arc_capacity_1188  1
    load_1_23_11  segment_load_conservation_1238  -1
    load_1_23_11  segment_prefix_lb_1239  1
    load_1_23_11  segment_prefix_ub_1240  1
    load_1_23_11  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_16  arc_capacity_1190  -25
    arc_1_23_16  connected_order_arc_1191  -14
    arc_1_23_16  in_degree_1242  1
    arc_1_23_16  out_degree_1283  1
    arc_1_23_16  original_T_including_depot_unload_1293  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_23_16  arc_capacity_1190  1
    load_1_23_16  free_load_conservation_1246  -1
    load_1_23_16  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_17  arc_capacity_1192  -25
    arc_1_23_17  connected_order_arc_1193  -14
    arc_1_23_17  in_degree_1248  1
    arc_1_23_17  out_degree_1283  1
    arc_1_23_17  original_T_including_depot_unload_1293  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_23_17  arc_capacity_1192  1
    load_1_23_17  free_load_conservation_1252  -1
    load_1_23_17  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_18  arc_capacity_1194  -25
    arc_1_23_18  connected_order_arc_1195  -14
    arc_1_23_18  in_degree_1254  1
    arc_1_23_18  out_degree_1283  1
    arc_1_23_18  original_T_including_depot_unload_1293  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_18  arc_capacity_1194  1
    load_1_23_18  free_load_conservation_1258  -1
    load_1_23_18  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_19  arc_capacity_1196  -25
    arc_1_23_19  connected_order_arc_1197  -14
    arc_1_23_19  in_degree_1260  1
    arc_1_23_19  out_degree_1283  1
    arc_1_23_19  original_T_including_depot_unload_1293  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_23_19  arc_capacity_1196  1
    load_1_23_19  free_load_conservation_1264  -1
    load_1_23_19  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_20  arc_capacity_1198  -25
    arc_1_23_20  connected_order_arc_1199  -14
    arc_1_23_20  in_degree_1266  1
    arc_1_23_20  out_degree_1283  1
    arc_1_23_20  original_T_including_depot_unload_1293  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_20  arc_capacity_1198  1
    load_1_23_20  free_load_conservation_1270  -1
    load_1_23_20  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_21  arc_capacity_1200  -25
    arc_1_23_21  connected_order_arc_1201  -14
    arc_1_23_21  in_degree_1272  1
    arc_1_23_21  out_degree_1283  1
    arc_1_23_21  original_T_including_depot_unload_1293  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_23_21  arc_capacity_1200  1
    load_1_23_21  free_load_conservation_1276  -1
    load_1_23_21  free_load_conservation_1288  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_23_22  arc_capacity_1202  -25
    arc_1_23_22  connected_order_arc_1203  -14
    arc_1_23_22  in_degree_1278  1
    arc_1_23_22  out_degree_1283  1
    arc_1_23_22  original_T_including_depot_unload_1293  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_23_22  arc_capacity_1202  1
    load_1_23_22  free_load_conservation_1282  -1
    load_1_23_22  free_load_conservation_1288  1
    visit_2_12  out_degree_1585  -1
    visit_2_12  in_degree_1586  -1
    visit_2_12  order_active_lb_1587  -1
    visit_2_12  order_active_ub_1588  -12
    order_2_12  connected_order_arc_1309  -1
    order_2_12  connected_order_arc_1311  -1
    order_2_12  connected_order_arc_1313  -1
    order_2_12  connected_order_arc_1315  -1
    order_2_12  connected_order_arc_1317  -1
    order_2_12  connected_order_arc_1319  -1
    order_2_12  connected_order_arc_1321  -1
    order_2_12  connected_order_arc_1323  -1
    order_2_12  connected_order_arc_1325  -1
    order_2_12  connected_order_arc_1327  -1
    order_2_12  connected_order_arc_1329  -1
    order_2_12  connected_order_arc_1332  1
    order_2_12  connected_order_arc_1355  1
    order_2_12  connected_order_arc_1378  1
    order_2_12  connected_order_arc_1401  1
    order_2_12  connected_order_arc_1424  1
    order_2_12  connected_order_arc_1447  1
    order_2_12  connected_order_arc_1470  1
    order_2_12  connected_order_arc_1493  1
    order_2_12  connected_order_arc_1516  1
    order_2_12  connected_order_arc_1539  1
    order_2_12  connected_order_arc_1562  1
    order_2_12  order_active_lb_1587  1
    order_2_12  order_active_ub_1588  1
    order_2_12  fixed_segment_relative_order_1661  -1
    visit_2_13  out_degree_1592  -1
    visit_2_13  in_degree_1593  -1
    visit_2_13  order_active_lb_1594  -1
    visit_2_13  order_active_ub_1595  -12
    order_2_13  connected_order_arc_1309  1
    order_2_13  connected_order_arc_1332  -1
    order_2_13  connected_order_arc_1334  -1
    order_2_13  connected_order_arc_1336  -1
    order_2_13  connected_order_arc_1338  -1
    order_2_13  connected_order_arc_1340  -1
    order_2_13  connected_order_arc_1342  -1
    order_2_13  connected_order_arc_1344  -1
    order_2_13  connected_order_arc_1346  -1
    order_2_13  connected_order_arc_1348  -1
    order_2_13  connected_order_arc_1350  -1
    order_2_13  connected_order_arc_1352  -1
    order_2_13  connected_order_arc_1357  1
    order_2_13  connected_order_arc_1380  1
    order_2_13  connected_order_arc_1403  1
    order_2_13  connected_order_arc_1426  1
    order_2_13  connected_order_arc_1449  1
    order_2_13  connected_order_arc_1472  1
    order_2_13  connected_order_arc_1495  1
    order_2_13  connected_order_arc_1518  1
    order_2_13  connected_order_arc_1541  1
    order_2_13  connected_order_arc_1564  1
    order_2_13  order_active_lb_1594  1
    order_2_13  order_active_ub_1595  1
    order_2_13  fixed_segment_relative_order_1661  1
    order_2_13  fixed_segment_relative_order_1662  -1
    visit_2_14  out_degree_1599  -1
    visit_2_14  in_degree_1600  -1
    visit_2_14  order_active_lb_1601  -1
    visit_2_14  order_active_ub_1602  -12
    order_2_14  connected_order_arc_1311  1
    order_2_14  connected_order_arc_1334  1
    order_2_14  connected_order_arc_1355  -1
    order_2_14  connected_order_arc_1357  -1
    order_2_14  connected_order_arc_1359  -1
    order_2_14  connected_order_arc_1361  -1
    order_2_14  connected_order_arc_1363  -1
    order_2_14  connected_order_arc_1365  -1
    order_2_14  connected_order_arc_1367  -1
    order_2_14  connected_order_arc_1369  -1
    order_2_14  connected_order_arc_1371  -1
    order_2_14  connected_order_arc_1373  -1
    order_2_14  connected_order_arc_1375  -1
    order_2_14  connected_order_arc_1382  1
    order_2_14  connected_order_arc_1405  1
    order_2_14  connected_order_arc_1428  1
    order_2_14  connected_order_arc_1451  1
    order_2_14  connected_order_arc_1474  1
    order_2_14  connected_order_arc_1497  1
    order_2_14  connected_order_arc_1520  1
    order_2_14  connected_order_arc_1543  1
    order_2_14  connected_order_arc_1566  1
    order_2_14  order_active_lb_1601  1
    order_2_14  order_active_ub_1602  1
    order_2_14  fixed_segment_relative_order_1662  1
    order_2_14  fixed_segment_relative_order_1663  -1
    visit_2_15  out_degree_1606  -1
    visit_2_15  in_degree_1607  -1
    visit_2_15  order_active_lb_1608  -1
    visit_2_15  order_active_ub_1609  -12
    order_2_15  connected_order_arc_1313  1
    order_2_15  connected_order_arc_1336  1
    order_2_15  connected_order_arc_1359  1
    order_2_15  connected_order_arc_1378  -1
    order_2_15  connected_order_arc_1380  -1
    order_2_15  connected_order_arc_1382  -1
    order_2_15  connected_order_arc_1384  -1
    order_2_15  connected_order_arc_1386  -1
    order_2_15  connected_order_arc_1388  -1
    order_2_15  connected_order_arc_1390  -1
    order_2_15  connected_order_arc_1392  -1
    order_2_15  connected_order_arc_1394  -1
    order_2_15  connected_order_arc_1396  -1
    order_2_15  connected_order_arc_1398  -1
    order_2_15  connected_order_arc_1407  1
    order_2_15  connected_order_arc_1430  1
    order_2_15  connected_order_arc_1453  1
    order_2_15  connected_order_arc_1476  1
    order_2_15  connected_order_arc_1499  1
    order_2_15  connected_order_arc_1522  1
    order_2_15  connected_order_arc_1545  1
    order_2_15  connected_order_arc_1568  1
    order_2_15  order_active_lb_1608  1
    order_2_15  order_active_ub_1609  1
    order_2_15  fixed_segment_relative_order_1663  1
    visit_2_16  out_degree_1613  -1
    visit_2_16  in_degree_1614  -1
    visit_2_16  order_active_lb_1615  -1
    visit_2_16  order_active_ub_1616  -12
    visit_2_16  service_visit_def_1617  -1
    order_2_16  connected_order_arc_1315  1
    order_2_16  connected_order_arc_1338  1
    order_2_16  connected_order_arc_1361  1
    order_2_16  connected_order_arc_1384  1
    order_2_16  connected_order_arc_1401  -1
    order_2_16  connected_order_arc_1403  -1
    order_2_16  connected_order_arc_1405  -1
    order_2_16  connected_order_arc_1407  -1
    order_2_16  connected_order_arc_1409  -1
    order_2_16  connected_order_arc_1411  -1
    order_2_16  connected_order_arc_1413  -1
    order_2_16  connected_order_arc_1415  -1
    order_2_16  connected_order_arc_1417  -1
    order_2_16  connected_order_arc_1419  -1
    order_2_16  connected_order_arc_1421  -1
    order_2_16  connected_order_arc_1432  1
    order_2_16  connected_order_arc_1455  1
    order_2_16  connected_order_arc_1478  1
    order_2_16  connected_order_arc_1501  1
    order_2_16  connected_order_arc_1524  1
    order_2_16  connected_order_arc_1547  1
    order_2_16  connected_order_arc_1570  1
    order_2_16  order_active_lb_1615  1
    order_2_16  order_active_ub_1616  1
    visit_2_17  out_degree_1619  -1
    visit_2_17  in_degree_1620  -1
    visit_2_17  order_active_lb_1621  -1
    visit_2_17  order_active_ub_1622  -12
    visit_2_17  service_visit_def_1623  -1
    order_2_17  connected_order_arc_1317  1
    order_2_17  connected_order_arc_1340  1
    order_2_17  connected_order_arc_1363  1
    order_2_17  connected_order_arc_1386  1
    order_2_17  connected_order_arc_1409  1
    order_2_17  connected_order_arc_1424  -1
    order_2_17  connected_order_arc_1426  -1
    order_2_17  connected_order_arc_1428  -1
    order_2_17  connected_order_arc_1430  -1
    order_2_17  connected_order_arc_1432  -1
    order_2_17  connected_order_arc_1434  -1
    order_2_17  connected_order_arc_1436  -1
    order_2_17  connected_order_arc_1438  -1
    order_2_17  connected_order_arc_1440  -1
    order_2_17  connected_order_arc_1442  -1
    order_2_17  connected_order_arc_1444  -1
    order_2_17  connected_order_arc_1457  1
    order_2_17  connected_order_arc_1480  1
    order_2_17  connected_order_arc_1503  1
    order_2_17  connected_order_arc_1526  1
    order_2_17  connected_order_arc_1549  1
    order_2_17  connected_order_arc_1572  1
    order_2_17  order_active_lb_1621  1
    order_2_17  order_active_ub_1622  1
    visit_2_18  out_degree_1625  -1
    visit_2_18  in_degree_1626  -1
    visit_2_18  order_active_lb_1627  -1
    visit_2_18  order_active_ub_1628  -12
    visit_2_18  service_visit_def_1629  -1
    order_2_18  connected_order_arc_1319  1
    order_2_18  connected_order_arc_1342  1
    order_2_18  connected_order_arc_1365  1
    order_2_18  connected_order_arc_1388  1
    order_2_18  connected_order_arc_1411  1
    order_2_18  connected_order_arc_1434  1
    order_2_18  connected_order_arc_1447  -1
    order_2_18  connected_order_arc_1449  -1
    order_2_18  connected_order_arc_1451  -1
    order_2_18  connected_order_arc_1453  -1
    order_2_18  connected_order_arc_1455  -1
    order_2_18  connected_order_arc_1457  -1
    order_2_18  connected_order_arc_1459  -1
    order_2_18  connected_order_arc_1461  -1
    order_2_18  connected_order_arc_1463  -1
    order_2_18  connected_order_arc_1465  -1
    order_2_18  connected_order_arc_1467  -1
    order_2_18  connected_order_arc_1482  1
    order_2_18  connected_order_arc_1505  1
    order_2_18  connected_order_arc_1528  1
    order_2_18  connected_order_arc_1551  1
    order_2_18  connected_order_arc_1574  1
    order_2_18  order_active_lb_1627  1
    order_2_18  order_active_ub_1628  1
    visit_2_19  out_degree_1631  -1
    visit_2_19  in_degree_1632  -1
    visit_2_19  order_active_lb_1633  -1
    visit_2_19  order_active_ub_1634  -12
    visit_2_19  service_visit_def_1635  -1
    order_2_19  connected_order_arc_1321  1
    order_2_19  connected_order_arc_1344  1
    order_2_19  connected_order_arc_1367  1
    order_2_19  connected_order_arc_1390  1
    order_2_19  connected_order_arc_1413  1
    order_2_19  connected_order_arc_1436  1
    order_2_19  connected_order_arc_1459  1
    order_2_19  connected_order_arc_1470  -1
    order_2_19  connected_order_arc_1472  -1
    order_2_19  connected_order_arc_1474  -1
    order_2_19  connected_order_arc_1476  -1
    order_2_19  connected_order_arc_1478  -1
    order_2_19  connected_order_arc_1480  -1
    order_2_19  connected_order_arc_1482  -1
    order_2_19  connected_order_arc_1484  -1
    order_2_19  connected_order_arc_1486  -1
    order_2_19  connected_order_arc_1488  -1
    order_2_19  connected_order_arc_1490  -1
    order_2_19  connected_order_arc_1507  1
    order_2_19  connected_order_arc_1530  1
    order_2_19  connected_order_arc_1553  1
    order_2_19  connected_order_arc_1576  1
    order_2_19  order_active_lb_1633  1
    order_2_19  order_active_ub_1634  1
    visit_2_20  out_degree_1637  -1
    visit_2_20  in_degree_1638  -1
    visit_2_20  order_active_lb_1639  -1
    visit_2_20  order_active_ub_1640  -12
    visit_2_20  service_visit_def_1641  -1
    order_2_20  connected_order_arc_1323  1
    order_2_20  connected_order_arc_1346  1
    order_2_20  connected_order_arc_1369  1
    order_2_20  connected_order_arc_1392  1
    order_2_20  connected_order_arc_1415  1
    order_2_20  connected_order_arc_1438  1
    order_2_20  connected_order_arc_1461  1
    order_2_20  connected_order_arc_1484  1
    order_2_20  connected_order_arc_1493  -1
    order_2_20  connected_order_arc_1495  -1
    order_2_20  connected_order_arc_1497  -1
    order_2_20  connected_order_arc_1499  -1
    order_2_20  connected_order_arc_1501  -1
    order_2_20  connected_order_arc_1503  -1
    order_2_20  connected_order_arc_1505  -1
    order_2_20  connected_order_arc_1507  -1
    order_2_20  connected_order_arc_1509  -1
    order_2_20  connected_order_arc_1511  -1
    order_2_20  connected_order_arc_1513  -1
    order_2_20  connected_order_arc_1532  1
    order_2_20  connected_order_arc_1555  1
    order_2_20  connected_order_arc_1578  1
    order_2_20  order_active_lb_1639  1
    order_2_20  order_active_ub_1640  1
    visit_2_21  out_degree_1643  -1
    visit_2_21  in_degree_1644  -1
    visit_2_21  order_active_lb_1645  -1
    visit_2_21  order_active_ub_1646  -12
    visit_2_21  service_visit_def_1647  -1
    order_2_21  connected_order_arc_1325  1
    order_2_21  connected_order_arc_1348  1
    order_2_21  connected_order_arc_1371  1
    order_2_21  connected_order_arc_1394  1
    order_2_21  connected_order_arc_1417  1
    order_2_21  connected_order_arc_1440  1
    order_2_21  connected_order_arc_1463  1
    order_2_21  connected_order_arc_1486  1
    order_2_21  connected_order_arc_1509  1
    order_2_21  connected_order_arc_1516  -1
    order_2_21  connected_order_arc_1518  -1
    order_2_21  connected_order_arc_1520  -1
    order_2_21  connected_order_arc_1522  -1
    order_2_21  connected_order_arc_1524  -1
    order_2_21  connected_order_arc_1526  -1
    order_2_21  connected_order_arc_1528  -1
    order_2_21  connected_order_arc_1530  -1
    order_2_21  connected_order_arc_1532  -1
    order_2_21  connected_order_arc_1534  -1
    order_2_21  connected_order_arc_1536  -1
    order_2_21  connected_order_arc_1557  1
    order_2_21  connected_order_arc_1580  1
    order_2_21  order_active_lb_1645  1
    order_2_21  order_active_ub_1646  1
    visit_2_22  out_degree_1649  -1
    visit_2_22  in_degree_1650  -1
    visit_2_22  order_active_lb_1651  -1
    visit_2_22  order_active_ub_1652  -12
    visit_2_22  service_visit_def_1653  -1
    order_2_22  connected_order_arc_1327  1
    order_2_22  connected_order_arc_1350  1
    order_2_22  connected_order_arc_1373  1
    order_2_22  connected_order_arc_1396  1
    order_2_22  connected_order_arc_1419  1
    order_2_22  connected_order_arc_1442  1
    order_2_22  connected_order_arc_1465  1
    order_2_22  connected_order_arc_1488  1
    order_2_22  connected_order_arc_1511  1
    order_2_22  connected_order_arc_1534  1
    order_2_22  connected_order_arc_1539  -1
    order_2_22  connected_order_arc_1541  -1
    order_2_22  connected_order_arc_1543  -1
    order_2_22  connected_order_arc_1545  -1
    order_2_22  connected_order_arc_1547  -1
    order_2_22  connected_order_arc_1549  -1
    order_2_22  connected_order_arc_1551  -1
    order_2_22  connected_order_arc_1553  -1
    order_2_22  connected_order_arc_1555  -1
    order_2_22  connected_order_arc_1557  -1
    order_2_22  connected_order_arc_1559  -1
    order_2_22  connected_order_arc_1582  1
    order_2_22  order_active_lb_1651  1
    order_2_22  order_active_ub_1652  1
    visit_2_23  out_degree_1655  -1
    visit_2_23  in_degree_1656  -1
    visit_2_23  order_active_lb_1657  -1
    visit_2_23  order_active_ub_1658  -12
    visit_2_23  service_visit_def_1659  -1
    order_2_23  connected_order_arc_1329  1
    order_2_23  connected_order_arc_1352  1
    order_2_23  connected_order_arc_1375  1
    order_2_23  connected_order_arc_1398  1
    order_2_23  connected_order_arc_1421  1
    order_2_23  connected_order_arc_1444  1
    order_2_23  connected_order_arc_1467  1
    order_2_23  connected_order_arc_1490  1
    order_2_23  connected_order_arc_1513  1
    order_2_23  connected_order_arc_1536  1
    order_2_23  connected_order_arc_1559  1
    order_2_23  connected_order_arc_1562  -1
    order_2_23  connected_order_arc_1564  -1
    order_2_23  connected_order_arc_1566  -1
    order_2_23  connected_order_arc_1568  -1
    order_2_23  connected_order_arc_1570  -1
    order_2_23  connected_order_arc_1572  -1
    order_2_23  connected_order_arc_1574  -1
    order_2_23  connected_order_arc_1576  -1
    order_2_23  connected_order_arc_1578  -1
    order_2_23  connected_order_arc_1580  -1
    order_2_23  connected_order_arc_1582  -1
    order_2_23  order_active_lb_1657  1
    order_2_23  order_active_ub_1658  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1294  -30
    arc_2_0_0  depot_departure_or_bypass_1583  1
    arc_2_0_0  depot_return_or_bypass_1584  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1294  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1295  -30
    arc_2_0_12  depot_departure_or_bypass_1583  1
    arc_2_0_12  in_degree_1586  1
    arc_2_0_12  original_T_including_depot_unload_1664  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1295  1
    load_2_0_12  segment_load_conservation_1589  -1
    load_2_0_12  segment_prefix_lb_1590  1
    load_2_0_12  segment_prefix_ub_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1296  -30
    arc_2_0_13  depot_departure_or_bypass_1583  1
    arc_2_0_13  in_degree_1593  1
    arc_2_0_13  original_T_including_depot_unload_1664  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1296  1
    load_2_0_13  segment_load_conservation_1596  -1
    load_2_0_13  segment_prefix_lb_1597  1
    load_2_0_13  segment_prefix_ub_1598  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1297  -30
    arc_2_0_14  depot_departure_or_bypass_1583  1
    arc_2_0_14  in_degree_1600  1
    arc_2_0_14  original_T_including_depot_unload_1664  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1297  1
    load_2_0_14  segment_load_conservation_1603  -1
    load_2_0_14  segment_prefix_lb_1604  1
    load_2_0_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1298  -30
    arc_2_0_15  depot_departure_or_bypass_1583  1
    arc_2_0_15  in_degree_1607  1
    arc_2_0_15  original_T_including_depot_unload_1664  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1298  1
    load_2_0_15  segment_load_conservation_1610  -1
    load_2_0_15  segment_prefix_lb_1611  1
    load_2_0_15  segment_prefix_ub_1612  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1299  -30
    arc_2_0_16  depot_departure_or_bypass_1583  1
    arc_2_0_16  in_degree_1614  1
    arc_2_0_16  original_T_including_depot_unload_1664  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1299  1
    load_2_0_16  free_load_conservation_1618  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1300  -30
    arc_2_0_17  depot_departure_or_bypass_1583  1
    arc_2_0_17  in_degree_1620  1
    arc_2_0_17  original_T_including_depot_unload_1664  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1300  1
    load_2_0_17  free_load_conservation_1624  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1301  -30
    arc_2_0_18  depot_departure_or_bypass_1583  1
    arc_2_0_18  in_degree_1626  1
    arc_2_0_18  original_T_including_depot_unload_1664  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1301  1
    load_2_0_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1302  -30
    arc_2_0_19  depot_departure_or_bypass_1583  1
    arc_2_0_19  in_degree_1632  1
    arc_2_0_19  original_T_including_depot_unload_1664  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1302  1
    load_2_0_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1303  -30
    arc_2_0_20  depot_departure_or_bypass_1583  1
    arc_2_0_20  in_degree_1638  1
    arc_2_0_20  original_T_including_depot_unload_1664  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1303  1
    load_2_0_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1304  -30
    arc_2_0_21  depot_departure_or_bypass_1583  1
    arc_2_0_21  in_degree_1644  1
    arc_2_0_21  original_T_including_depot_unload_1664  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1304  1
    load_2_0_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1305  -30
    arc_2_0_22  depot_departure_or_bypass_1583  1
    arc_2_0_22  in_degree_1650  1
    arc_2_0_22  original_T_including_depot_unload_1664  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1305  1
    load_2_0_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_23  arc_capacity_1306  -30
    arc_2_0_23  depot_departure_or_bypass_1583  1
    arc_2_0_23  in_degree_1656  1
    arc_2_0_23  original_T_including_depot_unload_1664  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_23  arc_capacity_1306  1
    load_2_0_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1307  -30
    arc_2_12_0  depot_return_or_bypass_1584  1
    arc_2_12_0  out_degree_1585  1
    arc_2_12_0  original_T_including_depot_unload_1664  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1307  1
    load_2_12_0  segment_load_conservation_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1308  -30
    arc_2_12_13  connected_order_arc_1309  -13
    arc_2_12_13  out_degree_1585  1
    arc_2_12_13  in_degree_1593  1
    arc_2_12_13  original_T_including_depot_unload_1664  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1308  1
    load_2_12_13  segment_load_conservation_1589  1
    load_2_12_13  segment_load_conservation_1596  -1
    load_2_12_13  segment_prefix_lb_1597  1
    load_2_12_13  segment_prefix_ub_1598  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1310  -30
    arc_2_12_14  connected_order_arc_1311  -13
    arc_2_12_14  out_degree_1585  1
    arc_2_12_14  in_degree_1600  1
    arc_2_12_14  original_T_including_depot_unload_1664  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1310  1
    load_2_12_14  segment_load_conservation_1589  1
    load_2_12_14  segment_load_conservation_1603  -1
    load_2_12_14  segment_prefix_lb_1604  1
    load_2_12_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1312  -30
    arc_2_12_15  connected_order_arc_1313  -13
    arc_2_12_15  out_degree_1585  1
    arc_2_12_15  in_degree_1607  1
    arc_2_12_15  original_T_including_depot_unload_1664  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1312  1
    load_2_12_15  segment_load_conservation_1589  1
    load_2_12_15  segment_load_conservation_1610  -1
    load_2_12_15  segment_prefix_lb_1611  1
    load_2_12_15  segment_prefix_ub_1612  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1314  -30
    arc_2_12_16  connected_order_arc_1315  -13
    arc_2_12_16  out_degree_1585  1
    arc_2_12_16  in_degree_1614  1
    arc_2_12_16  original_T_including_depot_unload_1664  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1314  1
    load_2_12_16  segment_load_conservation_1589  1
    load_2_12_16  free_load_conservation_1618  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1316  -30
    arc_2_12_17  connected_order_arc_1317  -13
    arc_2_12_17  out_degree_1585  1
    arc_2_12_17  in_degree_1620  1
    arc_2_12_17  original_T_including_depot_unload_1664  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1316  1
    load_2_12_17  segment_load_conservation_1589  1
    load_2_12_17  free_load_conservation_1624  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1318  -30
    arc_2_12_18  connected_order_arc_1319  -13
    arc_2_12_18  out_degree_1585  1
    arc_2_12_18  in_degree_1626  1
    arc_2_12_18  original_T_including_depot_unload_1664  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1318  1
    load_2_12_18  segment_load_conservation_1589  1
    load_2_12_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1320  -30
    arc_2_12_19  connected_order_arc_1321  -13
    arc_2_12_19  out_degree_1585  1
    arc_2_12_19  in_degree_1632  1
    arc_2_12_19  original_T_including_depot_unload_1664  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1320  1
    load_2_12_19  segment_load_conservation_1589  1
    load_2_12_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1322  -30
    arc_2_12_20  connected_order_arc_1323  -13
    arc_2_12_20  out_degree_1585  1
    arc_2_12_20  in_degree_1638  1
    arc_2_12_20  original_T_including_depot_unload_1664  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1322  1
    load_2_12_20  segment_load_conservation_1589  1
    load_2_12_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1324  -30
    arc_2_12_21  connected_order_arc_1325  -13
    arc_2_12_21  out_degree_1585  1
    arc_2_12_21  in_degree_1644  1
    arc_2_12_21  original_T_including_depot_unload_1664  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1324  1
    load_2_12_21  segment_load_conservation_1589  1
    load_2_12_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1326  -30
    arc_2_12_22  connected_order_arc_1327  -13
    arc_2_12_22  out_degree_1585  1
    arc_2_12_22  in_degree_1650  1
    arc_2_12_22  original_T_including_depot_unload_1664  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1326  1
    load_2_12_22  segment_load_conservation_1589  1
    load_2_12_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_23  arc_capacity_1328  -30
    arc_2_12_23  connected_order_arc_1329  -13
    arc_2_12_23  out_degree_1585  1
    arc_2_12_23  in_degree_1656  1
    arc_2_12_23  original_T_including_depot_unload_1664  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_23  arc_capacity_1328  1
    load_2_12_23  segment_load_conservation_1589  1
    load_2_12_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1330  -30
    arc_2_13_0  depot_return_or_bypass_1584  1
    arc_2_13_0  out_degree_1592  1
    arc_2_13_0  original_T_including_depot_unload_1664  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1330  1
    load_2_13_0  segment_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1331  -30
    arc_2_13_12  connected_order_arc_1332  -13
    arc_2_13_12  in_degree_1586  1
    arc_2_13_12  out_degree_1592  1
    arc_2_13_12  original_T_including_depot_unload_1664  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1331  1
    load_2_13_12  segment_load_conservation_1589  -1
    load_2_13_12  segment_prefix_lb_1590  1
    load_2_13_12  segment_prefix_ub_1591  1
    load_2_13_12  segment_load_conservation_1596  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1333  -30
    arc_2_13_14  connected_order_arc_1334  -13
    arc_2_13_14  out_degree_1592  1
    arc_2_13_14  in_degree_1600  1
    arc_2_13_14  original_T_including_depot_unload_1664  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1333  1
    load_2_13_14  segment_load_conservation_1596  1
    load_2_13_14  segment_load_conservation_1603  -1
    load_2_13_14  segment_prefix_lb_1604  1
    load_2_13_14  segment_prefix_ub_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1335  -30
    arc_2_13_15  connected_order_arc_1336  -13
    arc_2_13_15  out_degree_1592  1
    arc_2_13_15  in_degree_1607  1
    arc_2_13_15  original_T_including_depot_unload_1664  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1335  1
    load_2_13_15  segment_load_conservation_1596  1
    load_2_13_15  segment_load_conservation_1610  -1
    load_2_13_15  segment_prefix_lb_1611  1
    load_2_13_15  segment_prefix_ub_1612  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1337  -30
    arc_2_13_16  connected_order_arc_1338  -13
    arc_2_13_16  out_degree_1592  1
    arc_2_13_16  in_degree_1614  1
    arc_2_13_16  original_T_including_depot_unload_1664  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1337  1
    load_2_13_16  segment_load_conservation_1596  1
    load_2_13_16  free_load_conservation_1618  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1339  -30
    arc_2_13_17  connected_order_arc_1340  -13
    arc_2_13_17  out_degree_1592  1
    arc_2_13_17  in_degree_1620  1
    arc_2_13_17  original_T_including_depot_unload_1664  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1339  1
    load_2_13_17  segment_load_conservation_1596  1
    load_2_13_17  free_load_conservation_1624  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1341  -30
    arc_2_13_18  connected_order_arc_1342  -13
    arc_2_13_18  out_degree_1592  1
    arc_2_13_18  in_degree_1626  1
    arc_2_13_18  original_T_including_depot_unload_1664  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1341  1
    load_2_13_18  segment_load_conservation_1596  1
    load_2_13_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1343  -30
    arc_2_13_19  connected_order_arc_1344  -13
    arc_2_13_19  out_degree_1592  1
    arc_2_13_19  in_degree_1632  1
    arc_2_13_19  original_T_including_depot_unload_1664  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1343  1
    load_2_13_19  segment_load_conservation_1596  1
    load_2_13_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1345  -30
    arc_2_13_20  connected_order_arc_1346  -13
    arc_2_13_20  out_degree_1592  1
    arc_2_13_20  in_degree_1638  1
    arc_2_13_20  original_T_including_depot_unload_1664  1.4088953223409719e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1345  1
    load_2_13_20  segment_load_conservation_1596  1
    load_2_13_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1347  -30
    arc_2_13_21  connected_order_arc_1348  -13
    arc_2_13_21  out_degree_1592  1
    arc_2_13_21  in_degree_1644  1
    arc_2_13_21  original_T_including_depot_unload_1664  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1347  1
    load_2_13_21  segment_load_conservation_1596  1
    load_2_13_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1349  -30
    arc_2_13_22  connected_order_arc_1350  -13
    arc_2_13_22  out_degree_1592  1
    arc_2_13_22  in_degree_1650  1
    arc_2_13_22  original_T_including_depot_unload_1664  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1349  1
    load_2_13_22  segment_load_conservation_1596  1
    load_2_13_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_23  arc_capacity_1351  -30
    arc_2_13_23  connected_order_arc_1352  -13
    arc_2_13_23  out_degree_1592  1
    arc_2_13_23  in_degree_1656  1
    arc_2_13_23  original_T_including_depot_unload_1664  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_23  arc_capacity_1351  1
    load_2_13_23  segment_load_conservation_1596  1
    load_2_13_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1353  -30
    arc_2_14_0  depot_return_or_bypass_1584  1
    arc_2_14_0  out_degree_1599  1
    arc_2_14_0  original_T_including_depot_unload_1664  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1353  1
    load_2_14_0  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1354  -30
    arc_2_14_12  connected_order_arc_1355  -13
    arc_2_14_12  in_degree_1586  1
    arc_2_14_12  out_degree_1599  1
    arc_2_14_12  original_T_including_depot_unload_1664  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1354  1
    load_2_14_12  segment_load_conservation_1589  -1
    load_2_14_12  segment_prefix_lb_1590  1
    load_2_14_12  segment_prefix_ub_1591  1
    load_2_14_12  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1356  -30
    arc_2_14_13  connected_order_arc_1357  -13
    arc_2_14_13  in_degree_1593  1
    arc_2_14_13  out_degree_1599  1
    arc_2_14_13  original_T_including_depot_unload_1664  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1356  1
    load_2_14_13  segment_load_conservation_1596  -1
    load_2_14_13  segment_prefix_lb_1597  1
    load_2_14_13  segment_prefix_ub_1598  1
    load_2_14_13  segment_load_conservation_1603  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1358  -30
    arc_2_14_15  connected_order_arc_1359  -13
    arc_2_14_15  out_degree_1599  1
    arc_2_14_15  in_degree_1607  1
    arc_2_14_15  original_T_including_depot_unload_1664  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1358  1
    load_2_14_15  segment_load_conservation_1603  1
    load_2_14_15  segment_load_conservation_1610  -1
    load_2_14_15  segment_prefix_lb_1611  1
    load_2_14_15  segment_prefix_ub_1612  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1360  -30
    arc_2_14_16  connected_order_arc_1361  -13
    arc_2_14_16  out_degree_1599  1
    arc_2_14_16  in_degree_1614  1
    arc_2_14_16  original_T_including_depot_unload_1664  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1360  1
    load_2_14_16  segment_load_conservation_1603  1
    load_2_14_16  free_load_conservation_1618  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1362  -30
    arc_2_14_17  connected_order_arc_1363  -13
    arc_2_14_17  out_degree_1599  1
    arc_2_14_17  in_degree_1620  1
    arc_2_14_17  original_T_including_depot_unload_1664  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1362  1
    load_2_14_17  segment_load_conservation_1603  1
    load_2_14_17  free_load_conservation_1624  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1364  -30
    arc_2_14_18  connected_order_arc_1365  -13
    arc_2_14_18  out_degree_1599  1
    arc_2_14_18  in_degree_1626  1
    arc_2_14_18  original_T_including_depot_unload_1664  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1364  1
    load_2_14_18  segment_load_conservation_1603  1
    load_2_14_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1366  -30
    arc_2_14_19  connected_order_arc_1367  -13
    arc_2_14_19  out_degree_1599  1
    arc_2_14_19  in_degree_1632  1
    arc_2_14_19  original_T_including_depot_unload_1664  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1366  1
    load_2_14_19  segment_load_conservation_1603  1
    load_2_14_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1368  -30
    arc_2_14_20  connected_order_arc_1369  -13
    arc_2_14_20  out_degree_1599  1
    arc_2_14_20  in_degree_1638  1
    arc_2_14_20  original_T_including_depot_unload_1664  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1368  1
    load_2_14_20  segment_load_conservation_1603  1
    load_2_14_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1370  -30
    arc_2_14_21  connected_order_arc_1371  -13
    arc_2_14_21  out_degree_1599  1
    arc_2_14_21  in_degree_1644  1
    arc_2_14_21  original_T_including_depot_unload_1664  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1370  1
    load_2_14_21  segment_load_conservation_1603  1
    load_2_14_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1372  -30
    arc_2_14_22  connected_order_arc_1373  -13
    arc_2_14_22  out_degree_1599  1
    arc_2_14_22  in_degree_1650  1
    arc_2_14_22  original_T_including_depot_unload_1664  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1372  1
    load_2_14_22  segment_load_conservation_1603  1
    load_2_14_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_23  arc_capacity_1374  -30
    arc_2_14_23  connected_order_arc_1375  -13
    arc_2_14_23  out_degree_1599  1
    arc_2_14_23  in_degree_1656  1
    arc_2_14_23  original_T_including_depot_unload_1664  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_23  arc_capacity_1374  1
    load_2_14_23  segment_load_conservation_1603  1
    load_2_14_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1376  -30
    arc_2_15_0  depot_return_or_bypass_1584  1
    arc_2_15_0  out_degree_1606  1
    arc_2_15_0  original_T_including_depot_unload_1664  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1376  1
    load_2_15_0  segment_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1377  -30
    arc_2_15_12  connected_order_arc_1378  -13
    arc_2_15_12  in_degree_1586  1
    arc_2_15_12  out_degree_1606  1
    arc_2_15_12  original_T_including_depot_unload_1664  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1377  1
    load_2_15_12  segment_load_conservation_1589  -1
    load_2_15_12  segment_prefix_lb_1590  1
    load_2_15_12  segment_prefix_ub_1591  1
    load_2_15_12  segment_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1379  -30
    arc_2_15_13  connected_order_arc_1380  -13
    arc_2_15_13  in_degree_1593  1
    arc_2_15_13  out_degree_1606  1
    arc_2_15_13  original_T_including_depot_unload_1664  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1379  1
    load_2_15_13  segment_load_conservation_1596  -1
    load_2_15_13  segment_prefix_lb_1597  1
    load_2_15_13  segment_prefix_ub_1598  1
    load_2_15_13  segment_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1381  -30
    arc_2_15_14  connected_order_arc_1382  -13
    arc_2_15_14  in_degree_1600  1
    arc_2_15_14  out_degree_1606  1
    arc_2_15_14  original_T_including_depot_unload_1664  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1381  1
    load_2_15_14  segment_load_conservation_1603  -1
    load_2_15_14  segment_prefix_lb_1604  1
    load_2_15_14  segment_prefix_ub_1605  1
    load_2_15_14  segment_load_conservation_1610  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1383  -30
    arc_2_15_16  connected_order_arc_1384  -13
    arc_2_15_16  out_degree_1606  1
    arc_2_15_16  in_degree_1614  1
    arc_2_15_16  original_T_including_depot_unload_1664  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1383  1
    load_2_15_16  segment_load_conservation_1610  1
    load_2_15_16  free_load_conservation_1618  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1385  -30
    arc_2_15_17  connected_order_arc_1386  -13
    arc_2_15_17  out_degree_1606  1
    arc_2_15_17  in_degree_1620  1
    arc_2_15_17  original_T_including_depot_unload_1664  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1385  1
    load_2_15_17  segment_load_conservation_1610  1
    load_2_15_17  free_load_conservation_1624  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1387  -30
    arc_2_15_18  connected_order_arc_1388  -13
    arc_2_15_18  out_degree_1606  1
    arc_2_15_18  in_degree_1626  1
    arc_2_15_18  original_T_including_depot_unload_1664  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1387  1
    load_2_15_18  segment_load_conservation_1610  1
    load_2_15_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1389  -30
    arc_2_15_19  connected_order_arc_1390  -13
    arc_2_15_19  out_degree_1606  1
    arc_2_15_19  in_degree_1632  1
    arc_2_15_19  original_T_including_depot_unload_1664  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1389  1
    load_2_15_19  segment_load_conservation_1610  1
    load_2_15_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1391  -30
    arc_2_15_20  connected_order_arc_1392  -13
    arc_2_15_20  out_degree_1606  1
    arc_2_15_20  in_degree_1638  1
    arc_2_15_20  original_T_including_depot_unload_1664  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1391  1
    load_2_15_20  segment_load_conservation_1610  1
    load_2_15_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1393  -30
    arc_2_15_21  connected_order_arc_1394  -13
    arc_2_15_21  out_degree_1606  1
    arc_2_15_21  in_degree_1644  1
    arc_2_15_21  original_T_including_depot_unload_1664  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1393  1
    load_2_15_21  segment_load_conservation_1610  1
    load_2_15_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1395  -30
    arc_2_15_22  connected_order_arc_1396  -13
    arc_2_15_22  out_degree_1606  1
    arc_2_15_22  in_degree_1650  1
    arc_2_15_22  original_T_including_depot_unload_1664  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1395  1
    load_2_15_22  segment_load_conservation_1610  1
    load_2_15_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_23  arc_capacity_1397  -30
    arc_2_15_23  connected_order_arc_1398  -13
    arc_2_15_23  out_degree_1606  1
    arc_2_15_23  in_degree_1656  1
    arc_2_15_23  original_T_including_depot_unload_1664  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_23  arc_capacity_1397  1
    load_2_15_23  segment_load_conservation_1610  1
    load_2_15_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1399  -30
    arc_2_16_0  depot_return_or_bypass_1584  1
    arc_2_16_0  out_degree_1613  1
    arc_2_16_0  original_T_including_depot_unload_1664  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1399  1
    load_2_16_0  free_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1400  -30
    arc_2_16_12  connected_order_arc_1401  -13
    arc_2_16_12  in_degree_1586  1
    arc_2_16_12  out_degree_1613  1
    arc_2_16_12  original_T_including_depot_unload_1664  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1400  1
    load_2_16_12  segment_load_conservation_1589  -1
    load_2_16_12  segment_prefix_lb_1590  1
    load_2_16_12  segment_prefix_ub_1591  1
    load_2_16_12  free_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1402  -30
    arc_2_16_13  connected_order_arc_1403  -13
    arc_2_16_13  in_degree_1593  1
    arc_2_16_13  out_degree_1613  1
    arc_2_16_13  original_T_including_depot_unload_1664  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1402  1
    load_2_16_13  segment_load_conservation_1596  -1
    load_2_16_13  segment_prefix_lb_1597  1
    load_2_16_13  segment_prefix_ub_1598  1
    load_2_16_13  free_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1404  -30
    arc_2_16_14  connected_order_arc_1405  -13
    arc_2_16_14  in_degree_1600  1
    arc_2_16_14  out_degree_1613  1
    arc_2_16_14  original_T_including_depot_unload_1664  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1404  1
    load_2_16_14  segment_load_conservation_1603  -1
    load_2_16_14  segment_prefix_lb_1604  1
    load_2_16_14  segment_prefix_ub_1605  1
    load_2_16_14  free_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1406  -30
    arc_2_16_15  connected_order_arc_1407  -13
    arc_2_16_15  in_degree_1607  1
    arc_2_16_15  out_degree_1613  1
    arc_2_16_15  original_T_including_depot_unload_1664  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1406  1
    load_2_16_15  segment_load_conservation_1610  -1
    load_2_16_15  segment_prefix_lb_1611  1
    load_2_16_15  segment_prefix_ub_1612  1
    load_2_16_15  free_load_conservation_1618  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1408  -30
    arc_2_16_17  connected_order_arc_1409  -13
    arc_2_16_17  out_degree_1613  1
    arc_2_16_17  in_degree_1620  1
    arc_2_16_17  original_T_including_depot_unload_1664  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1408  1
    load_2_16_17  free_load_conservation_1618  1
    load_2_16_17  free_load_conservation_1624  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1410  -30
    arc_2_16_18  connected_order_arc_1411  -13
    arc_2_16_18  out_degree_1613  1
    arc_2_16_18  in_degree_1626  1
    arc_2_16_18  original_T_including_depot_unload_1664  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1410  1
    load_2_16_18  free_load_conservation_1618  1
    load_2_16_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1412  -30
    arc_2_16_19  connected_order_arc_1413  -13
    arc_2_16_19  out_degree_1613  1
    arc_2_16_19  in_degree_1632  1
    arc_2_16_19  original_T_including_depot_unload_1664  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1412  1
    load_2_16_19  free_load_conservation_1618  1
    load_2_16_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1414  -30
    arc_2_16_20  connected_order_arc_1415  -13
    arc_2_16_20  out_degree_1613  1
    arc_2_16_20  in_degree_1638  1
    arc_2_16_20  original_T_including_depot_unload_1664  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1414  1
    load_2_16_20  free_load_conservation_1618  1
    load_2_16_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1416  -30
    arc_2_16_21  connected_order_arc_1417  -13
    arc_2_16_21  out_degree_1613  1
    arc_2_16_21  in_degree_1644  1
    arc_2_16_21  original_T_including_depot_unload_1664  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1416  1
    load_2_16_21  free_load_conservation_1618  1
    load_2_16_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1418  -30
    arc_2_16_22  connected_order_arc_1419  -13
    arc_2_16_22  out_degree_1613  1
    arc_2_16_22  in_degree_1650  1
    arc_2_16_22  original_T_including_depot_unload_1664  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1418  1
    load_2_16_22  free_load_conservation_1618  1
    load_2_16_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_23  arc_capacity_1420  -30
    arc_2_16_23  connected_order_arc_1421  -13
    arc_2_16_23  out_degree_1613  1
    arc_2_16_23  in_degree_1656  1
    arc_2_16_23  original_T_including_depot_unload_1664  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_23  arc_capacity_1420  1
    load_2_16_23  free_load_conservation_1618  1
    load_2_16_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1422  -30
    arc_2_17_0  depot_return_or_bypass_1584  1
    arc_2_17_0  out_degree_1619  1
    arc_2_17_0  original_T_including_depot_unload_1664  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1422  1
    load_2_17_0  free_load_conservation_1624  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1423  -30
    arc_2_17_12  connected_order_arc_1424  -13
    arc_2_17_12  in_degree_1586  1
    arc_2_17_12  out_degree_1619  1
    arc_2_17_12  original_T_including_depot_unload_1664  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1423  1
    load_2_17_12  segment_load_conservation_1589  -1
    load_2_17_12  segment_prefix_lb_1590  1
    load_2_17_12  segment_prefix_ub_1591  1
    load_2_17_12  free_load_conservation_1624  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1425  -30
    arc_2_17_13  connected_order_arc_1426  -13
    arc_2_17_13  in_degree_1593  1
    arc_2_17_13  out_degree_1619  1
    arc_2_17_13  original_T_including_depot_unload_1664  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1425  1
    load_2_17_13  segment_load_conservation_1596  -1
    load_2_17_13  segment_prefix_lb_1597  1
    load_2_17_13  segment_prefix_ub_1598  1
    load_2_17_13  free_load_conservation_1624  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1427  -30
    arc_2_17_14  connected_order_arc_1428  -13
    arc_2_17_14  in_degree_1600  1
    arc_2_17_14  out_degree_1619  1
    arc_2_17_14  original_T_including_depot_unload_1664  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1427  1
    load_2_17_14  segment_load_conservation_1603  -1
    load_2_17_14  segment_prefix_lb_1604  1
    load_2_17_14  segment_prefix_ub_1605  1
    load_2_17_14  free_load_conservation_1624  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1429  -30
    arc_2_17_15  connected_order_arc_1430  -13
    arc_2_17_15  in_degree_1607  1
    arc_2_17_15  out_degree_1619  1
    arc_2_17_15  original_T_including_depot_unload_1664  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1429  1
    load_2_17_15  segment_load_conservation_1610  -1
    load_2_17_15  segment_prefix_lb_1611  1
    load_2_17_15  segment_prefix_ub_1612  1
    load_2_17_15  free_load_conservation_1624  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1431  -30
    arc_2_17_16  connected_order_arc_1432  -13
    arc_2_17_16  in_degree_1614  1
    arc_2_17_16  out_degree_1619  1
    arc_2_17_16  original_T_including_depot_unload_1664  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1431  1
    load_2_17_16  free_load_conservation_1618  -1
    load_2_17_16  free_load_conservation_1624  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1433  -30
    arc_2_17_18  connected_order_arc_1434  -13
    arc_2_17_18  out_degree_1619  1
    arc_2_17_18  in_degree_1626  1
    arc_2_17_18  original_T_including_depot_unload_1664  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1433  1
    load_2_17_18  free_load_conservation_1624  1
    load_2_17_18  free_load_conservation_1630  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1435  -30
    arc_2_17_19  connected_order_arc_1436  -13
    arc_2_17_19  out_degree_1619  1
    arc_2_17_19  in_degree_1632  1
    arc_2_17_19  original_T_including_depot_unload_1664  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1435  1
    load_2_17_19  free_load_conservation_1624  1
    load_2_17_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1437  -30
    arc_2_17_20  connected_order_arc_1438  -13
    arc_2_17_20  out_degree_1619  1
    arc_2_17_20  in_degree_1638  1
    arc_2_17_20  original_T_including_depot_unload_1664  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1437  1
    load_2_17_20  free_load_conservation_1624  1
    load_2_17_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1439  -30
    arc_2_17_21  connected_order_arc_1440  -13
    arc_2_17_21  out_degree_1619  1
    arc_2_17_21  in_degree_1644  1
    arc_2_17_21  original_T_including_depot_unload_1664  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1439  1
    load_2_17_21  free_load_conservation_1624  1
    load_2_17_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1441  -30
    arc_2_17_22  connected_order_arc_1442  -13
    arc_2_17_22  out_degree_1619  1
    arc_2_17_22  in_degree_1650  1
    arc_2_17_22  original_T_including_depot_unload_1664  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1441  1
    load_2_17_22  free_load_conservation_1624  1
    load_2_17_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_23  arc_capacity_1443  -30
    arc_2_17_23  connected_order_arc_1444  -13
    arc_2_17_23  out_degree_1619  1
    arc_2_17_23  in_degree_1656  1
    arc_2_17_23  original_T_including_depot_unload_1664  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_23  arc_capacity_1443  1
    load_2_17_23  free_load_conservation_1624  1
    load_2_17_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1445  -30
    arc_2_18_0  depot_return_or_bypass_1584  1
    arc_2_18_0  out_degree_1625  1
    arc_2_18_0  original_T_including_depot_unload_1664  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1445  1
    load_2_18_0  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1446  -30
    arc_2_18_12  connected_order_arc_1447  -13
    arc_2_18_12  in_degree_1586  1
    arc_2_18_12  out_degree_1625  1
    arc_2_18_12  original_T_including_depot_unload_1664  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1446  1
    load_2_18_12  segment_load_conservation_1589  -1
    load_2_18_12  segment_prefix_lb_1590  1
    load_2_18_12  segment_prefix_ub_1591  1
    load_2_18_12  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1448  -30
    arc_2_18_13  connected_order_arc_1449  -13
    arc_2_18_13  in_degree_1593  1
    arc_2_18_13  out_degree_1625  1
    arc_2_18_13  original_T_including_depot_unload_1664  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1448  1
    load_2_18_13  segment_load_conservation_1596  -1
    load_2_18_13  segment_prefix_lb_1597  1
    load_2_18_13  segment_prefix_ub_1598  1
    load_2_18_13  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1450  -30
    arc_2_18_14  connected_order_arc_1451  -13
    arc_2_18_14  in_degree_1600  1
    arc_2_18_14  out_degree_1625  1
    arc_2_18_14  original_T_including_depot_unload_1664  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1450  1
    load_2_18_14  segment_load_conservation_1603  -1
    load_2_18_14  segment_prefix_lb_1604  1
    load_2_18_14  segment_prefix_ub_1605  1
    load_2_18_14  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1452  -30
    arc_2_18_15  connected_order_arc_1453  -13
    arc_2_18_15  in_degree_1607  1
    arc_2_18_15  out_degree_1625  1
    arc_2_18_15  original_T_including_depot_unload_1664  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1452  1
    load_2_18_15  segment_load_conservation_1610  -1
    load_2_18_15  segment_prefix_lb_1611  1
    load_2_18_15  segment_prefix_ub_1612  1
    load_2_18_15  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1454  -30
    arc_2_18_16  connected_order_arc_1455  -13
    arc_2_18_16  in_degree_1614  1
    arc_2_18_16  out_degree_1625  1
    arc_2_18_16  original_T_including_depot_unload_1664  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1454  1
    load_2_18_16  free_load_conservation_1618  -1
    load_2_18_16  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1456  -30
    arc_2_18_17  connected_order_arc_1457  -13
    arc_2_18_17  in_degree_1620  1
    arc_2_18_17  out_degree_1625  1
    arc_2_18_17  original_T_including_depot_unload_1664  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1456  1
    load_2_18_17  free_load_conservation_1624  -1
    load_2_18_17  free_load_conservation_1630  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1458  -30
    arc_2_18_19  connected_order_arc_1459  -13
    arc_2_18_19  out_degree_1625  1
    arc_2_18_19  in_degree_1632  1
    arc_2_18_19  original_T_including_depot_unload_1664  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1458  1
    load_2_18_19  free_load_conservation_1630  1
    load_2_18_19  free_load_conservation_1636  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1460  -30
    arc_2_18_20  connected_order_arc_1461  -13
    arc_2_18_20  out_degree_1625  1
    arc_2_18_20  in_degree_1638  1
    arc_2_18_20  original_T_including_depot_unload_1664  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1460  1
    load_2_18_20  free_load_conservation_1630  1
    load_2_18_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1462  -30
    arc_2_18_21  connected_order_arc_1463  -13
    arc_2_18_21  out_degree_1625  1
    arc_2_18_21  in_degree_1644  1
    arc_2_18_21  original_T_including_depot_unload_1664  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1462  1
    load_2_18_21  free_load_conservation_1630  1
    load_2_18_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1464  -30
    arc_2_18_22  connected_order_arc_1465  -13
    arc_2_18_22  out_degree_1625  1
    arc_2_18_22  in_degree_1650  1
    arc_2_18_22  original_T_including_depot_unload_1664  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1464  1
    load_2_18_22  free_load_conservation_1630  1
    load_2_18_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_23  arc_capacity_1466  -30
    arc_2_18_23  connected_order_arc_1467  -13
    arc_2_18_23  out_degree_1625  1
    arc_2_18_23  in_degree_1656  1
    arc_2_18_23  original_T_including_depot_unload_1664  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_23  arc_capacity_1466  1
    load_2_18_23  free_load_conservation_1630  1
    load_2_18_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1468  -30
    arc_2_19_0  depot_return_or_bypass_1584  1
    arc_2_19_0  out_degree_1631  1
    arc_2_19_0  original_T_including_depot_unload_1664  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1468  1
    load_2_19_0  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1469  -30
    arc_2_19_12  connected_order_arc_1470  -13
    arc_2_19_12  in_degree_1586  1
    arc_2_19_12  out_degree_1631  1
    arc_2_19_12  original_T_including_depot_unload_1664  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1469  1
    load_2_19_12  segment_load_conservation_1589  -1
    load_2_19_12  segment_prefix_lb_1590  1
    load_2_19_12  segment_prefix_ub_1591  1
    load_2_19_12  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1471  -30
    arc_2_19_13  connected_order_arc_1472  -13
    arc_2_19_13  in_degree_1593  1
    arc_2_19_13  out_degree_1631  1
    arc_2_19_13  original_T_including_depot_unload_1664  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1471  1
    load_2_19_13  segment_load_conservation_1596  -1
    load_2_19_13  segment_prefix_lb_1597  1
    load_2_19_13  segment_prefix_ub_1598  1
    load_2_19_13  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1473  -30
    arc_2_19_14  connected_order_arc_1474  -13
    arc_2_19_14  in_degree_1600  1
    arc_2_19_14  out_degree_1631  1
    arc_2_19_14  original_T_including_depot_unload_1664  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1473  1
    load_2_19_14  segment_load_conservation_1603  -1
    load_2_19_14  segment_prefix_lb_1604  1
    load_2_19_14  segment_prefix_ub_1605  1
    load_2_19_14  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1475  -30
    arc_2_19_15  connected_order_arc_1476  -13
    arc_2_19_15  in_degree_1607  1
    arc_2_19_15  out_degree_1631  1
    arc_2_19_15  original_T_including_depot_unload_1664  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1475  1
    load_2_19_15  segment_load_conservation_1610  -1
    load_2_19_15  segment_prefix_lb_1611  1
    load_2_19_15  segment_prefix_ub_1612  1
    load_2_19_15  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1477  -30
    arc_2_19_16  connected_order_arc_1478  -13
    arc_2_19_16  in_degree_1614  1
    arc_2_19_16  out_degree_1631  1
    arc_2_19_16  original_T_including_depot_unload_1664  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1477  1
    load_2_19_16  free_load_conservation_1618  -1
    load_2_19_16  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1479  -30
    arc_2_19_17  connected_order_arc_1480  -13
    arc_2_19_17  in_degree_1620  1
    arc_2_19_17  out_degree_1631  1
    arc_2_19_17  original_T_including_depot_unload_1664  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1479  1
    load_2_19_17  free_load_conservation_1624  -1
    load_2_19_17  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1481  -30
    arc_2_19_18  connected_order_arc_1482  -13
    arc_2_19_18  in_degree_1626  1
    arc_2_19_18  out_degree_1631  1
    arc_2_19_18  original_T_including_depot_unload_1664  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1481  1
    load_2_19_18  free_load_conservation_1630  -1
    load_2_19_18  free_load_conservation_1636  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1483  -30
    arc_2_19_20  connected_order_arc_1484  -13
    arc_2_19_20  out_degree_1631  1
    arc_2_19_20  in_degree_1638  1
    arc_2_19_20  original_T_including_depot_unload_1664  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1483  1
    load_2_19_20  free_load_conservation_1636  1
    load_2_19_20  free_load_conservation_1642  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1485  -30
    arc_2_19_21  connected_order_arc_1486  -13
    arc_2_19_21  out_degree_1631  1
    arc_2_19_21  in_degree_1644  1
    arc_2_19_21  original_T_including_depot_unload_1664  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1485  1
    load_2_19_21  free_load_conservation_1636  1
    load_2_19_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1487  -30
    arc_2_19_22  connected_order_arc_1488  -13
    arc_2_19_22  out_degree_1631  1
    arc_2_19_22  in_degree_1650  1
    arc_2_19_22  original_T_including_depot_unload_1664  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1487  1
    load_2_19_22  free_load_conservation_1636  1
    load_2_19_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_23  arc_capacity_1489  -30
    arc_2_19_23  connected_order_arc_1490  -13
    arc_2_19_23  out_degree_1631  1
    arc_2_19_23  in_degree_1656  1
    arc_2_19_23  original_T_including_depot_unload_1664  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_23  arc_capacity_1489  1
    load_2_19_23  free_load_conservation_1636  1
    load_2_19_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1491  -30
    arc_2_20_0  depot_return_or_bypass_1584  1
    arc_2_20_0  out_degree_1637  1
    arc_2_20_0  original_T_including_depot_unload_1664  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1491  1
    load_2_20_0  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1492  -30
    arc_2_20_12  connected_order_arc_1493  -13
    arc_2_20_12  in_degree_1586  1
    arc_2_20_12  out_degree_1637  1
    arc_2_20_12  original_T_including_depot_unload_1664  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1492  1
    load_2_20_12  segment_load_conservation_1589  -1
    load_2_20_12  segment_prefix_lb_1590  1
    load_2_20_12  segment_prefix_ub_1591  1
    load_2_20_12  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1494  -30
    arc_2_20_13  connected_order_arc_1495  -13
    arc_2_20_13  in_degree_1593  1
    arc_2_20_13  out_degree_1637  1
    arc_2_20_13  original_T_including_depot_unload_1664  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1494  1
    load_2_20_13  segment_load_conservation_1596  -1
    load_2_20_13  segment_prefix_lb_1597  1
    load_2_20_13  segment_prefix_ub_1598  1
    load_2_20_13  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1496  -30
    arc_2_20_14  connected_order_arc_1497  -13
    arc_2_20_14  in_degree_1600  1
    arc_2_20_14  out_degree_1637  1
    arc_2_20_14  original_T_including_depot_unload_1664  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1496  1
    load_2_20_14  segment_load_conservation_1603  -1
    load_2_20_14  segment_prefix_lb_1604  1
    load_2_20_14  segment_prefix_ub_1605  1
    load_2_20_14  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1498  -30
    arc_2_20_15  connected_order_arc_1499  -13
    arc_2_20_15  in_degree_1607  1
    arc_2_20_15  out_degree_1637  1
    arc_2_20_15  original_T_including_depot_unload_1664  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1498  1
    load_2_20_15  segment_load_conservation_1610  -1
    load_2_20_15  segment_prefix_lb_1611  1
    load_2_20_15  segment_prefix_ub_1612  1
    load_2_20_15  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1500  -30
    arc_2_20_16  connected_order_arc_1501  -13
    arc_2_20_16  in_degree_1614  1
    arc_2_20_16  out_degree_1637  1
    arc_2_20_16  original_T_including_depot_unload_1664  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1500  1
    load_2_20_16  free_load_conservation_1618  -1
    load_2_20_16  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1502  -30
    arc_2_20_17  connected_order_arc_1503  -13
    arc_2_20_17  in_degree_1620  1
    arc_2_20_17  out_degree_1637  1
    arc_2_20_17  original_T_including_depot_unload_1664  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1502  1
    load_2_20_17  free_load_conservation_1624  -1
    load_2_20_17  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1504  -30
    arc_2_20_18  connected_order_arc_1505  -13
    arc_2_20_18  in_degree_1626  1
    arc_2_20_18  out_degree_1637  1
    arc_2_20_18  original_T_including_depot_unload_1664  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1504  1
    load_2_20_18  free_load_conservation_1630  -1
    load_2_20_18  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1506  -30
    arc_2_20_19  connected_order_arc_1507  -13
    arc_2_20_19  in_degree_1632  1
    arc_2_20_19  out_degree_1637  1
    arc_2_20_19  original_T_including_depot_unload_1664  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1506  1
    load_2_20_19  free_load_conservation_1636  -1
    load_2_20_19  free_load_conservation_1642  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1508  -30
    arc_2_20_21  connected_order_arc_1509  -13
    arc_2_20_21  out_degree_1637  1
    arc_2_20_21  in_degree_1644  1
    arc_2_20_21  original_T_including_depot_unload_1664  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1508  1
    load_2_20_21  free_load_conservation_1642  1
    load_2_20_21  free_load_conservation_1648  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1510  -30
    arc_2_20_22  connected_order_arc_1511  -13
    arc_2_20_22  out_degree_1637  1
    arc_2_20_22  in_degree_1650  1
    arc_2_20_22  original_T_including_depot_unload_1664  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1510  1
    load_2_20_22  free_load_conservation_1642  1
    load_2_20_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_23  arc_capacity_1512  -30
    arc_2_20_23  connected_order_arc_1513  -13
    arc_2_20_23  out_degree_1637  1
    arc_2_20_23  in_degree_1656  1
    arc_2_20_23  original_T_including_depot_unload_1664  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_23  arc_capacity_1512  1
    load_2_20_23  free_load_conservation_1642  1
    load_2_20_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1514  -30
    arc_2_21_0  depot_return_or_bypass_1584  1
    arc_2_21_0  out_degree_1643  1
    arc_2_21_0  original_T_including_depot_unload_1664  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1514  1
    load_2_21_0  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1515  -30
    arc_2_21_12  connected_order_arc_1516  -13
    arc_2_21_12  in_degree_1586  1
    arc_2_21_12  out_degree_1643  1
    arc_2_21_12  original_T_including_depot_unload_1664  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1515  1
    load_2_21_12  segment_load_conservation_1589  -1
    load_2_21_12  segment_prefix_lb_1590  1
    load_2_21_12  segment_prefix_ub_1591  1
    load_2_21_12  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1517  -30
    arc_2_21_13  connected_order_arc_1518  -13
    arc_2_21_13  in_degree_1593  1
    arc_2_21_13  out_degree_1643  1
    arc_2_21_13  original_T_including_depot_unload_1664  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1517  1
    load_2_21_13  segment_load_conservation_1596  -1
    load_2_21_13  segment_prefix_lb_1597  1
    load_2_21_13  segment_prefix_ub_1598  1
    load_2_21_13  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1519  -30
    arc_2_21_14  connected_order_arc_1520  -13
    arc_2_21_14  in_degree_1600  1
    arc_2_21_14  out_degree_1643  1
    arc_2_21_14  original_T_including_depot_unload_1664  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1519  1
    load_2_21_14  segment_load_conservation_1603  -1
    load_2_21_14  segment_prefix_lb_1604  1
    load_2_21_14  segment_prefix_ub_1605  1
    load_2_21_14  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1521  -30
    arc_2_21_15  connected_order_arc_1522  -13
    arc_2_21_15  in_degree_1607  1
    arc_2_21_15  out_degree_1643  1
    arc_2_21_15  original_T_including_depot_unload_1664  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1521  1
    load_2_21_15  segment_load_conservation_1610  -1
    load_2_21_15  segment_prefix_lb_1611  1
    load_2_21_15  segment_prefix_ub_1612  1
    load_2_21_15  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1523  -30
    arc_2_21_16  connected_order_arc_1524  -13
    arc_2_21_16  in_degree_1614  1
    arc_2_21_16  out_degree_1643  1
    arc_2_21_16  original_T_including_depot_unload_1664  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1523  1
    load_2_21_16  free_load_conservation_1618  -1
    load_2_21_16  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1525  -30
    arc_2_21_17  connected_order_arc_1526  -13
    arc_2_21_17  in_degree_1620  1
    arc_2_21_17  out_degree_1643  1
    arc_2_21_17  original_T_including_depot_unload_1664  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1525  1
    load_2_21_17  free_load_conservation_1624  -1
    load_2_21_17  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1527  -30
    arc_2_21_18  connected_order_arc_1528  -13
    arc_2_21_18  in_degree_1626  1
    arc_2_21_18  out_degree_1643  1
    arc_2_21_18  original_T_including_depot_unload_1664  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1527  1
    load_2_21_18  free_load_conservation_1630  -1
    load_2_21_18  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1529  -30
    arc_2_21_19  connected_order_arc_1530  -13
    arc_2_21_19  in_degree_1632  1
    arc_2_21_19  out_degree_1643  1
    arc_2_21_19  original_T_including_depot_unload_1664  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1529  1
    load_2_21_19  free_load_conservation_1636  -1
    load_2_21_19  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1531  -30
    arc_2_21_20  connected_order_arc_1532  -13
    arc_2_21_20  in_degree_1638  1
    arc_2_21_20  out_degree_1643  1
    arc_2_21_20  original_T_including_depot_unload_1664  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1531  1
    load_2_21_20  free_load_conservation_1642  -1
    load_2_21_20  free_load_conservation_1648  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1533  -30
    arc_2_21_22  connected_order_arc_1534  -13
    arc_2_21_22  out_degree_1643  1
    arc_2_21_22  in_degree_1650  1
    arc_2_21_22  original_T_including_depot_unload_1664  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1533  1
    load_2_21_22  free_load_conservation_1648  1
    load_2_21_22  free_load_conservation_1654  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_23  arc_capacity_1535  -30
    arc_2_21_23  connected_order_arc_1536  -13
    arc_2_21_23  out_degree_1643  1
    arc_2_21_23  in_degree_1656  1
    arc_2_21_23  original_T_including_depot_unload_1664  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_23  arc_capacity_1535  1
    load_2_21_23  free_load_conservation_1648  1
    load_2_21_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1537  -30
    arc_2_22_0  depot_return_or_bypass_1584  1
    arc_2_22_0  out_degree_1649  1
    arc_2_22_0  original_T_including_depot_unload_1664  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1537  1
    load_2_22_0  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1538  -30
    arc_2_22_12  connected_order_arc_1539  -13
    arc_2_22_12  in_degree_1586  1
    arc_2_22_12  out_degree_1649  1
    arc_2_22_12  original_T_including_depot_unload_1664  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1538  1
    load_2_22_12  segment_load_conservation_1589  -1
    load_2_22_12  segment_prefix_lb_1590  1
    load_2_22_12  segment_prefix_ub_1591  1
    load_2_22_12  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1540  -30
    arc_2_22_13  connected_order_arc_1541  -13
    arc_2_22_13  in_degree_1593  1
    arc_2_22_13  out_degree_1649  1
    arc_2_22_13  original_T_including_depot_unload_1664  7.6789230776331749e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1540  1
    load_2_22_13  segment_load_conservation_1596  -1
    load_2_22_13  segment_prefix_lb_1597  1
    load_2_22_13  segment_prefix_ub_1598  1
    load_2_22_13  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1542  -30
    arc_2_22_14  connected_order_arc_1543  -13
    arc_2_22_14  in_degree_1600  1
    arc_2_22_14  out_degree_1649  1
    arc_2_22_14  original_T_including_depot_unload_1664  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1542  1
    load_2_22_14  segment_load_conservation_1603  -1
    load_2_22_14  segment_prefix_lb_1604  1
    load_2_22_14  segment_prefix_ub_1605  1
    load_2_22_14  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1544  -30
    arc_2_22_15  connected_order_arc_1545  -13
    arc_2_22_15  in_degree_1607  1
    arc_2_22_15  out_degree_1649  1
    arc_2_22_15  original_T_including_depot_unload_1664  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1544  1
    load_2_22_15  segment_load_conservation_1610  -1
    load_2_22_15  segment_prefix_lb_1611  1
    load_2_22_15  segment_prefix_ub_1612  1
    load_2_22_15  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1546  -30
    arc_2_22_16  connected_order_arc_1547  -13
    arc_2_22_16  in_degree_1614  1
    arc_2_22_16  out_degree_1649  1
    arc_2_22_16  original_T_including_depot_unload_1664  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1546  1
    load_2_22_16  free_load_conservation_1618  -1
    load_2_22_16  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1548  -30
    arc_2_22_17  connected_order_arc_1549  -13
    arc_2_22_17  in_degree_1620  1
    arc_2_22_17  out_degree_1649  1
    arc_2_22_17  original_T_including_depot_unload_1664  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1548  1
    load_2_22_17  free_load_conservation_1624  -1
    load_2_22_17  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1550  -30
    arc_2_22_18  connected_order_arc_1551  -13
    arc_2_22_18  in_degree_1626  1
    arc_2_22_18  out_degree_1649  1
    arc_2_22_18  original_T_including_depot_unload_1664  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1550  1
    load_2_22_18  free_load_conservation_1630  -1
    load_2_22_18  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1552  -30
    arc_2_22_19  connected_order_arc_1553  -13
    arc_2_22_19  in_degree_1632  1
    arc_2_22_19  out_degree_1649  1
    arc_2_22_19  original_T_including_depot_unload_1664  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1552  1
    load_2_22_19  free_load_conservation_1636  -1
    load_2_22_19  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1554  -30
    arc_2_22_20  connected_order_arc_1555  -13
    arc_2_22_20  in_degree_1638  1
    arc_2_22_20  out_degree_1649  1
    arc_2_22_20  original_T_including_depot_unload_1664  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1554  1
    load_2_22_20  free_load_conservation_1642  -1
    load_2_22_20  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1556  -30
    arc_2_22_21  connected_order_arc_1557  -13
    arc_2_22_21  in_degree_1644  1
    arc_2_22_21  out_degree_1649  1
    arc_2_22_21  original_T_including_depot_unload_1664  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1556  1
    load_2_22_21  free_load_conservation_1648  -1
    load_2_22_21  free_load_conservation_1654  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_23  arc_capacity_1558  -30
    arc_2_22_23  connected_order_arc_1559  -13
    arc_2_22_23  out_degree_1649  1
    arc_2_22_23  in_degree_1656  1
    arc_2_22_23  original_T_including_depot_unload_1664  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_23  arc_capacity_1558  1
    load_2_22_23  free_load_conservation_1654  1
    load_2_22_23  free_load_conservation_1660  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_0  arc_capacity_1560  -30
    arc_2_23_0  depot_return_or_bypass_1584  1
    arc_2_23_0  out_degree_1655  1
    arc_2_23_0  original_T_including_depot_unload_1664  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_0  arc_capacity_1560  1
    load_2_23_0  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_12  arc_capacity_1561  -30
    arc_2_23_12  connected_order_arc_1562  -13
    arc_2_23_12  in_degree_1586  1
    arc_2_23_12  out_degree_1655  1
    arc_2_23_12  original_T_including_depot_unload_1664  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_12  arc_capacity_1561  1
    load_2_23_12  segment_load_conservation_1589  -1
    load_2_23_12  segment_prefix_lb_1590  1
    load_2_23_12  segment_prefix_ub_1591  1
    load_2_23_12  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_13  arc_capacity_1563  -30
    arc_2_23_13  connected_order_arc_1564  -13
    arc_2_23_13  in_degree_1593  1
    arc_2_23_13  out_degree_1655  1
    arc_2_23_13  original_T_including_depot_unload_1664  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_13  arc_capacity_1563  1
    load_2_23_13  segment_load_conservation_1596  -1
    load_2_23_13  segment_prefix_lb_1597  1
    load_2_23_13  segment_prefix_ub_1598  1
    load_2_23_13  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_14  arc_capacity_1565  -30
    arc_2_23_14  connected_order_arc_1566  -13
    arc_2_23_14  in_degree_1600  1
    arc_2_23_14  out_degree_1655  1
    arc_2_23_14  original_T_including_depot_unload_1664  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_14  arc_capacity_1565  1
    load_2_23_14  segment_load_conservation_1603  -1
    load_2_23_14  segment_prefix_lb_1604  1
    load_2_23_14  segment_prefix_ub_1605  1
    load_2_23_14  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_15  arc_capacity_1567  -30
    arc_2_23_15  connected_order_arc_1568  -13
    arc_2_23_15  in_degree_1607  1
    arc_2_23_15  out_degree_1655  1
    arc_2_23_15  original_T_including_depot_unload_1664  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_15  arc_capacity_1567  1
    load_2_23_15  segment_load_conservation_1610  -1
    load_2_23_15  segment_prefix_lb_1611  1
    load_2_23_15  segment_prefix_ub_1612  1
    load_2_23_15  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_16  arc_capacity_1569  -30
    arc_2_23_16  connected_order_arc_1570  -13
    arc_2_23_16  in_degree_1614  1
    arc_2_23_16  out_degree_1655  1
    arc_2_23_16  original_T_including_depot_unload_1664  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_16  arc_capacity_1569  1
    load_2_23_16  free_load_conservation_1618  -1
    load_2_23_16  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_17  arc_capacity_1571  -30
    arc_2_23_17  connected_order_arc_1572  -13
    arc_2_23_17  in_degree_1620  1
    arc_2_23_17  out_degree_1655  1
    arc_2_23_17  original_T_including_depot_unload_1664  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_17  arc_capacity_1571  1
    load_2_23_17  free_load_conservation_1624  -1
    load_2_23_17  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_18  arc_capacity_1573  -30
    arc_2_23_18  connected_order_arc_1574  -13
    arc_2_23_18  in_degree_1626  1
    arc_2_23_18  out_degree_1655  1
    arc_2_23_18  original_T_including_depot_unload_1664  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_18  arc_capacity_1573  1
    load_2_23_18  free_load_conservation_1630  -1
    load_2_23_18  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_19  arc_capacity_1575  -30
    arc_2_23_19  connected_order_arc_1576  -13
    arc_2_23_19  in_degree_1632  1
    arc_2_23_19  out_degree_1655  1
    arc_2_23_19  original_T_including_depot_unload_1664  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_19  arc_capacity_1575  1
    load_2_23_19  free_load_conservation_1636  -1
    load_2_23_19  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_20  arc_capacity_1577  -30
    arc_2_23_20  connected_order_arc_1578  -13
    arc_2_23_20  in_degree_1638  1
    arc_2_23_20  out_degree_1655  1
    arc_2_23_20  original_T_including_depot_unload_1664  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_20  arc_capacity_1577  1
    load_2_23_20  free_load_conservation_1642  -1
    load_2_23_20  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_21  arc_capacity_1579  -30
    arc_2_23_21  connected_order_arc_1580  -13
    arc_2_23_21  in_degree_1644  1
    arc_2_23_21  out_degree_1655  1
    arc_2_23_21  original_T_including_depot_unload_1664  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_23_21  arc_capacity_1579  1
    load_2_23_21  free_load_conservation_1648  -1
    load_2_23_21  free_load_conservation_1660  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_23_22  arc_capacity_1581  -30
    arc_2_23_22  connected_order_arc_1582  -13
    arc_2_23_22  in_degree_1650  1
    arc_2_23_22  out_degree_1655  1
    arc_2_23_22  original_T_including_depot_unload_1664  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_23_22  arc_capacity_1581  1
    load_2_23_22  free_load_conservation_1654  -1
    load_2_23_22  free_load_conservation_1660  1
RHS
    RHS1      OBJ       -4.2000000000000010e-01
    RHS1      onehot_35_32  1
    RHS1      onehot_30_53  1
    RHS1      onehot_31_82  1
    RHS1      onehot_32_111  1
    RHS1      onehot_16_140  1
    RHS1      onehot_26_161  1
    RHS1      onehot_5_198  1
    RHS1      onehot_19_219  1
    RHS1      stock_ub_223  30
    RHS1      parent_nonstrict_scope_224  2.9207157375771531e-01
    RHS1      normalization_281  1
    RHS1      connected_order_arc_391  -14
    RHS1      connected_order_arc_393  -14
    RHS1      connected_order_arc_395  -14
    RHS1      connected_order_arc_397  -14
    RHS1      connected_order_arc_399  -14
    RHS1      connected_order_arc_401  -14
    RHS1      connected_order_arc_403  -14
    RHS1      connected_order_arc_405  -14
    RHS1      connected_order_arc_407  -14
    RHS1      connected_order_arc_409  -14
    RHS1      connected_order_arc_411  -14
    RHS1      connected_order_arc_413  -14
    RHS1      connected_order_arc_415  -14
    RHS1      connected_order_arc_418  -14
    RHS1      connected_order_arc_420  -14
    RHS1      connected_order_arc_422  -14
    RHS1      connected_order_arc_424  -14
    RHS1      connected_order_arc_426  -14
    RHS1      connected_order_arc_428  -14
    RHS1      connected_order_arc_430  -14
    RHS1      connected_order_arc_432  -14
    RHS1      connected_order_arc_434  -14
    RHS1      connected_order_arc_436  -14
    RHS1      connected_order_arc_438  -14
    RHS1      connected_order_arc_440  -14
    RHS1      connected_order_arc_442  -14
    RHS1      connected_order_arc_445  -14
    RHS1      connected_order_arc_447  -14
    RHS1      connected_order_arc_449  -14
    RHS1      connected_order_arc_451  -14
    RHS1      connected_order_arc_453  -14
    RHS1      connected_order_arc_455  -14
    RHS1      connected_order_arc_457  -14
    RHS1      connected_order_arc_459  -14
    RHS1      connected_order_arc_461  -14
    RHS1      connected_order_arc_463  -14
    RHS1      connected_order_arc_465  -14
    RHS1      connected_order_arc_467  -14
    RHS1      connected_order_arc_469  -14
    RHS1      connected_order_arc_472  -14
    RHS1      connected_order_arc_474  -14
    RHS1      connected_order_arc_476  -14
    RHS1      connected_order_arc_478  -14
    RHS1      connected_order_arc_480  -14
    RHS1      connected_order_arc_482  -14
    RHS1      connected_order_arc_484  -14
    RHS1      connected_order_arc_486  -14
    RHS1      connected_order_arc_488  -14
    RHS1      connected_order_arc_490  -14
    RHS1      connected_order_arc_492  -14
    RHS1      connected_order_arc_494  -14
    RHS1      connected_order_arc_496  -14
    RHS1      connected_order_arc_499  -14
    RHS1      connected_order_arc_501  -14
    RHS1      connected_order_arc_503  -14
    RHS1      connected_order_arc_505  -14
    RHS1      connected_order_arc_507  -14
    RHS1      connected_order_arc_509  -14
    RHS1      connected_order_arc_511  -14
    RHS1      connected_order_arc_513  -14
    RHS1      connected_order_arc_515  -14
    RHS1      connected_order_arc_517  -14
    RHS1      connected_order_arc_519  -14
    RHS1      connected_order_arc_521  -14
    RHS1      connected_order_arc_523  -14
    RHS1      connected_order_arc_526  -14
    RHS1      connected_order_arc_528  -14
    RHS1      connected_order_arc_530  -14
    RHS1      connected_order_arc_532  -14
    RHS1      connected_order_arc_534  -14
    RHS1      connected_order_arc_536  -14
    RHS1      connected_order_arc_538  -14
    RHS1      connected_order_arc_540  -14
    RHS1      connected_order_arc_542  -14
    RHS1      connected_order_arc_544  -14
    RHS1      connected_order_arc_546  -14
    RHS1      connected_order_arc_548  -14
    RHS1      connected_order_arc_550  -14
    RHS1      connected_order_arc_553  -14
    RHS1      connected_order_arc_555  -14
    RHS1      connected_order_arc_557  -14
    RHS1      connected_order_arc_559  -14
    RHS1      connected_order_arc_561  -14
    RHS1      connected_order_arc_563  -14
    RHS1      connected_order_arc_565  -14
    RHS1      connected_order_arc_567  -14
    RHS1      connected_order_arc_569  -14
    RHS1      connected_order_arc_571  -14
    RHS1      connected_order_arc_573  -14
    RHS1      connected_order_arc_575  -14
    RHS1      connected_order_arc_577  -14
    RHS1      connected_order_arc_580  -14
    RHS1      connected_order_arc_582  -14
    RHS1      connected_order_arc_584  -14
    RHS1      connected_order_arc_586  -14
    RHS1      connected_order_arc_588  -14
    RHS1      connected_order_arc_590  -14
    RHS1      connected_order_arc_592  -14
    RHS1      connected_order_arc_594  -14
    RHS1      connected_order_arc_596  -14
    RHS1      connected_order_arc_598  -14
    RHS1      connected_order_arc_600  -14
    RHS1      connected_order_arc_602  -14
    RHS1      connected_order_arc_604  -14
    RHS1      connected_order_arc_607  -14
    RHS1      connected_order_arc_609  -14
    RHS1      connected_order_arc_611  -14
    RHS1      connected_order_arc_613  -14
    RHS1      connected_order_arc_615  -14
    RHS1      connected_order_arc_617  -14
    RHS1      connected_order_arc_619  -14
    RHS1      connected_order_arc_621  -14
    RHS1      connected_order_arc_623  -14
    RHS1      connected_order_arc_625  -14
    RHS1      connected_order_arc_627  -14
    RHS1      connected_order_arc_629  -14
    RHS1      connected_order_arc_631  -14
    RHS1      connected_order_arc_634  -14
    RHS1      connected_order_arc_636  -14
    RHS1      connected_order_arc_638  -14
    RHS1      connected_order_arc_640  -14
    RHS1      connected_order_arc_642  -14
    RHS1      connected_order_arc_644  -14
    RHS1      connected_order_arc_646  -14
    RHS1      connected_order_arc_648  -14
    RHS1      connected_order_arc_650  -14
    RHS1      connected_order_arc_652  -14
    RHS1      connected_order_arc_654  -14
    RHS1      connected_order_arc_656  -14
    RHS1      connected_order_arc_658  -14
    RHS1      connected_order_arc_661  -14
    RHS1      connected_order_arc_663  -14
    RHS1      connected_order_arc_665  -14
    RHS1      connected_order_arc_667  -14
    RHS1      connected_order_arc_669  -14
    RHS1      connected_order_arc_671  -14
    RHS1      connected_order_arc_673  -14
    RHS1      connected_order_arc_675  -14
    RHS1      connected_order_arc_677  -14
    RHS1      connected_order_arc_679  -14
    RHS1      connected_order_arc_681  -14
    RHS1      connected_order_arc_683  -14
    RHS1      connected_order_arc_685  -14
    RHS1      connected_order_arc_688  -14
    RHS1      connected_order_arc_690  -14
    RHS1      connected_order_arc_692  -14
    RHS1      connected_order_arc_694  -14
    RHS1      connected_order_arc_696  -14
    RHS1      connected_order_arc_698  -14
    RHS1      connected_order_arc_700  -14
    RHS1      connected_order_arc_702  -14
    RHS1      connected_order_arc_704  -14
    RHS1      connected_order_arc_706  -14
    RHS1      connected_order_arc_708  -14
    RHS1      connected_order_arc_710  -14
    RHS1      connected_order_arc_712  -14
    RHS1      connected_order_arc_715  -14
    RHS1      connected_order_arc_717  -14
    RHS1      connected_order_arc_719  -14
    RHS1      connected_order_arc_721  -14
    RHS1      connected_order_arc_723  -14
    RHS1      connected_order_arc_725  -14
    RHS1      connected_order_arc_727  -14
    RHS1      connected_order_arc_729  -14
    RHS1      connected_order_arc_731  -14
    RHS1      connected_order_arc_733  -14
    RHS1      connected_order_arc_735  -14
    RHS1      connected_order_arc_737  -14
    RHS1      connected_order_arc_739  -14
    RHS1      connected_order_arc_742  -14
    RHS1      connected_order_arc_744  -14
    RHS1      connected_order_arc_746  -14
    RHS1      connected_order_arc_748  -14
    RHS1      connected_order_arc_750  -14
    RHS1      connected_order_arc_752  -14
    RHS1      connected_order_arc_754  -14
    RHS1      connected_order_arc_756  -14
    RHS1      connected_order_arc_758  -14
    RHS1      connected_order_arc_760  -14
    RHS1      connected_order_arc_762  -14
    RHS1      connected_order_arc_764  -14
    RHS1      connected_order_arc_766  -14
    RHS1      depot_departure_or_bypass_767  1
    RHS1      depot_return_or_bypass_768  1
    RHS1      segment_load_conservation_773  18
    RHS1      segment_prefix_ub_775  2
    RHS1      segment_load_conservation_780  -8
    RHS1      segment_prefix_lb_781  8
    RHS1      segment_prefix_ub_782  20
    RHS1      segment_load_conservation_787  -4
    RHS1      segment_prefix_lb_788  4
    RHS1      segment_prefix_ub_789  20
    RHS1      segment_load_conservation_794  10
    RHS1      segment_prefix_ub_796  10
    RHS1      segment_load_conservation_801  -5
    RHS1      segment_prefix_lb_802  5
    RHS1      segment_prefix_ub_803  20
    RHS1      segment_load_conservation_808  -5
    RHS1      segment_prefix_lb_809  5
    RHS1      segment_prefix_ub_810  20
    RHS1      fixed_segment_relative_order_859  1
    RHS1      fixed_segment_relative_order_860  1
    RHS1      fixed_segment_relative_order_861  1
    RHS1      fixed_segment_relative_order_862  1
    RHS1      fixed_segment_relative_order_863  1
    RHS1      original_T_including_depot_unload_864  2.6039169573008685e+03
    RHS1      connected_order_arc_881  -13
    RHS1      connected_order_arc_883  -13
    RHS1      connected_order_arc_885  -13
    RHS1      connected_order_arc_887  -13
    RHS1      connected_order_arc_889  -13
    RHS1      connected_order_arc_891  -13
    RHS1      connected_order_arc_893  -13
    RHS1      connected_order_arc_895  -13
    RHS1      connected_order_arc_897  -13
    RHS1      connected_order_arc_899  -13
    RHS1      connected_order_arc_901  -13
    RHS1      connected_order_arc_903  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_908  -13
    RHS1      connected_order_arc_910  -13
    RHS1      connected_order_arc_912  -13
    RHS1      connected_order_arc_914  -13
    RHS1      connected_order_arc_916  -13
    RHS1      connected_order_arc_918  -13
    RHS1      connected_order_arc_920  -13
    RHS1      connected_order_arc_922  -13
    RHS1      connected_order_arc_924  -13
    RHS1      connected_order_arc_926  -13
    RHS1      connected_order_arc_928  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_933  -13
    RHS1      connected_order_arc_935  -13
    RHS1      connected_order_arc_937  -13
    RHS1      connected_order_arc_939  -13
    RHS1      connected_order_arc_941  -13
    RHS1      connected_order_arc_943  -13
    RHS1      connected_order_arc_945  -13
    RHS1      connected_order_arc_947  -13
    RHS1      connected_order_arc_949  -13
    RHS1      connected_order_arc_951  -13
    RHS1      connected_order_arc_953  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_962  -13
    RHS1      connected_order_arc_964  -13
    RHS1      connected_order_arc_966  -13
    RHS1      connected_order_arc_968  -13
    RHS1      connected_order_arc_970  -13
    RHS1      connected_order_arc_972  -13
    RHS1      connected_order_arc_974  -13
    RHS1      connected_order_arc_976  -13
    RHS1      connected_order_arc_978  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_987  -13
    RHS1      connected_order_arc_989  -13
    RHS1      connected_order_arc_991  -13
    RHS1      connected_order_arc_993  -13
    RHS1      connected_order_arc_995  -13
    RHS1      connected_order_arc_997  -13
    RHS1      connected_order_arc_999  -13
    RHS1      connected_order_arc_1001  -13
    RHS1      connected_order_arc_1003  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1012  -13
    RHS1      connected_order_arc_1014  -13
    RHS1      connected_order_arc_1016  -13
    RHS1      connected_order_arc_1018  -13
    RHS1      connected_order_arc_1020  -13
    RHS1      connected_order_arc_1022  -13
    RHS1      connected_order_arc_1024  -13
    RHS1      connected_order_arc_1026  -13
    RHS1      connected_order_arc_1028  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1037  -13
    RHS1      connected_order_arc_1039  -13
    RHS1      connected_order_arc_1041  -13
    RHS1      connected_order_arc_1043  -13
    RHS1      connected_order_arc_1045  -13
    RHS1      connected_order_arc_1047  -13
    RHS1      connected_order_arc_1049  -13
    RHS1      connected_order_arc_1051  -13
    RHS1      connected_order_arc_1053  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1062  -13
    RHS1      connected_order_arc_1064  -13
    RHS1      connected_order_arc_1066  -13
    RHS1      connected_order_arc_1068  -13
    RHS1      connected_order_arc_1070  -13
    RHS1      connected_order_arc_1072  -13
    RHS1      connected_order_arc_1074  -13
    RHS1      connected_order_arc_1076  -13
    RHS1      connected_order_arc_1078  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1087  -13
    RHS1      connected_order_arc_1089  -13
    RHS1      connected_order_arc_1091  -13
    RHS1      connected_order_arc_1093  -13
    RHS1      connected_order_arc_1095  -13
    RHS1      connected_order_arc_1097  -13
    RHS1      connected_order_arc_1099  -13
    RHS1      connected_order_arc_1101  -13
    RHS1      connected_order_arc_1103  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1112  -13
    RHS1      connected_order_arc_1114  -13
    RHS1      connected_order_arc_1116  -13
    RHS1      connected_order_arc_1118  -13
    RHS1      connected_order_arc_1120  -13
    RHS1      connected_order_arc_1122  -13
    RHS1      connected_order_arc_1124  -13
    RHS1      connected_order_arc_1126  -13
    RHS1      connected_order_arc_1128  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1133  -13
    RHS1      connected_order_arc_1135  -13
    RHS1      connected_order_arc_1137  -13
    RHS1      connected_order_arc_1139  -13
    RHS1      connected_order_arc_1141  -13
    RHS1      connected_order_arc_1143  -13
    RHS1      connected_order_arc_1145  -13
    RHS1      connected_order_arc_1147  -13
    RHS1      connected_order_arc_1149  -13
    RHS1      connected_order_arc_1151  -13
    RHS1      connected_order_arc_1153  -13
    RHS1      connected_order_arc_1156  -13
    RHS1      connected_order_arc_1158  -13
    RHS1      connected_order_arc_1160  -13
    RHS1      connected_order_arc_1162  -13
    RHS1      connected_order_arc_1164  -13
    RHS1      connected_order_arc_1166  -13
    RHS1      connected_order_arc_1168  -13
    RHS1      connected_order_arc_1170  -13
    RHS1      connected_order_arc_1172  -13
    RHS1      connected_order_arc_1174  -13
    RHS1      connected_order_arc_1176  -13
    RHS1      connected_order_arc_1178  -13
    RHS1      connected_order_arc_1181  -13
    RHS1      connected_order_arc_1183  -13
    RHS1      connected_order_arc_1185  -13
    RHS1      connected_order_arc_1187  -13
    RHS1      connected_order_arc_1189  -13
    RHS1      connected_order_arc_1191  -13
    RHS1      connected_order_arc_1193  -13
    RHS1      connected_order_arc_1195  -13
    RHS1      connected_order_arc_1197  -13
    RHS1      connected_order_arc_1199  -13
    RHS1      connected_order_arc_1201  -13
    RHS1      connected_order_arc_1203  -13
    RHS1      depot_departure_or_bypass_1204  1
    RHS1      depot_return_or_bypass_1205  1
    RHS1      segment_load_conservation_1210  6
    RHS1      segment_prefix_ub_1212  19
    RHS1      segment_load_conservation_1217  -4
    RHS1      segment_prefix_lb_1218  6
    RHS1      segment_prefix_ub_1219  24
    RHS1      segment_load_conservation_1224  3
    RHS1      segment_prefix_ub_1226  22
    RHS1      segment_load_conservation_1231  2
    RHS1      segment_prefix_ub_1233  23
    RHS1      segment_load_conservation_1238  -5
    RHS1      segment_prefix_lb_1239  5
    RHS1      segment_prefix_ub_1240  25
    RHS1      fixed_segment_relative_order_1289  1
    RHS1      fixed_segment_relative_order_1290  1
    RHS1      fixed_segment_relative_order_1291  1
    RHS1      fixed_segment_relative_order_1292  1
    RHS1      original_T_including_depot_unload_1293  2.2933958320926176e+03
    RHS1      connected_order_arc_1309  -12
    RHS1      connected_order_arc_1311  -12
    RHS1      connected_order_arc_1313  -12
    RHS1      connected_order_arc_1315  -12
    RHS1      connected_order_arc_1317  -12
    RHS1      connected_order_arc_1319  -12
    RHS1      connected_order_arc_1321  -12
    RHS1      connected_order_arc_1323  -12
    RHS1      connected_order_arc_1325  -12
    RHS1      connected_order_arc_1327  -12
    RHS1      connected_order_arc_1329  -12
    RHS1      connected_order_arc_1332  -12
    RHS1      connected_order_arc_1334  -12
    RHS1      connected_order_arc_1336  -12
    RHS1      connected_order_arc_1338  -12
    RHS1      connected_order_arc_1340  -12
    RHS1      connected_order_arc_1342  -12
    RHS1      connected_order_arc_1344  -12
    RHS1      connected_order_arc_1346  -12
    RHS1      connected_order_arc_1348  -12
    RHS1      connected_order_arc_1350  -12
    RHS1      connected_order_arc_1352  -12
    RHS1      connected_order_arc_1355  -12
    RHS1      connected_order_arc_1357  -12
    RHS1      connected_order_arc_1359  -12
    RHS1      connected_order_arc_1361  -12
    RHS1      connected_order_arc_1363  -12
    RHS1      connected_order_arc_1365  -12
    RHS1      connected_order_arc_1367  -12
    RHS1      connected_order_arc_1369  -12
    RHS1      connected_order_arc_1371  -12
    RHS1      connected_order_arc_1373  -12
    RHS1      connected_order_arc_1375  -12
    RHS1      connected_order_arc_1378  -12
    RHS1      connected_order_arc_1380  -12
    RHS1      connected_order_arc_1382  -12
    RHS1      connected_order_arc_1384  -12
    RHS1      connected_order_arc_1386  -12
    RHS1      connected_order_arc_1388  -12
    RHS1      connected_order_arc_1390  -12
    RHS1      connected_order_arc_1392  -12
    RHS1      connected_order_arc_1394  -12
    RHS1      connected_order_arc_1396  -12
    RHS1      connected_order_arc_1398  -12
    RHS1      connected_order_arc_1401  -12
    RHS1      connected_order_arc_1403  -12
    RHS1      connected_order_arc_1405  -12
    RHS1      connected_order_arc_1407  -12
    RHS1      connected_order_arc_1409  -12
    RHS1      connected_order_arc_1411  -12
    RHS1      connected_order_arc_1413  -12
    RHS1      connected_order_arc_1415  -12
    RHS1      connected_order_arc_1417  -12
    RHS1      connected_order_arc_1419  -12
    RHS1      connected_order_arc_1421  -12
    RHS1      connected_order_arc_1424  -12
    RHS1      connected_order_arc_1426  -12
    RHS1      connected_order_arc_1428  -12
    RHS1      connected_order_arc_1430  -12
    RHS1      connected_order_arc_1432  -12
    RHS1      connected_order_arc_1434  -12
    RHS1      connected_order_arc_1436  -12
    RHS1      connected_order_arc_1438  -12
    RHS1      connected_order_arc_1440  -12
    RHS1      connected_order_arc_1442  -12
    RHS1      connected_order_arc_1444  -12
    RHS1      connected_order_arc_1447  -12
    RHS1      connected_order_arc_1449  -12
    RHS1      connected_order_arc_1451  -12
    RHS1      connected_order_arc_1453  -12
    RHS1      connected_order_arc_1455  -12
    RHS1      connected_order_arc_1457  -12
    RHS1      connected_order_arc_1459  -12
    RHS1      connected_order_arc_1461  -12
    RHS1      connected_order_arc_1463  -12
    RHS1      connected_order_arc_1465  -12
    RHS1      connected_order_arc_1467  -12
    RHS1      connected_order_arc_1470  -12
    RHS1      connected_order_arc_1472  -12
    RHS1      connected_order_arc_1474  -12
    RHS1      connected_order_arc_1476  -12
    RHS1      connected_order_arc_1478  -12
    RHS1      connected_order_arc_1480  -12
    RHS1      connected_order_arc_1482  -12
    RHS1      connected_order_arc_1484  -12
    RHS1      connected_order_arc_1486  -12
    RHS1      connected_order_arc_1488  -12
    RHS1      connected_order_arc_1490  -12
    RHS1      connected_order_arc_1493  -12
    RHS1      connected_order_arc_1495  -12
    RHS1      connected_order_arc_1497  -12
    RHS1      connected_order_arc_1499  -12
    RHS1      connected_order_arc_1501  -12
    RHS1      connected_order_arc_1503  -12
    RHS1      connected_order_arc_1505  -12
    RHS1      connected_order_arc_1507  -12
    RHS1      connected_order_arc_1509  -12
    RHS1      connected_order_arc_1511  -12
    RHS1      connected_order_arc_1513  -12
    RHS1      connected_order_arc_1516  -12
    RHS1      connected_order_arc_1518  -12
    RHS1      connected_order_arc_1520  -12
    RHS1      connected_order_arc_1522  -12
    RHS1      connected_order_arc_1524  -12
    RHS1      connected_order_arc_1526  -12
    RHS1      connected_order_arc_1528  -12
    RHS1      connected_order_arc_1530  -12
    RHS1      connected_order_arc_1532  -12
    RHS1      connected_order_arc_1534  -12
    RHS1      connected_order_arc_1536  -12
    RHS1      connected_order_arc_1539  -12
    RHS1      connected_order_arc_1541  -12
    RHS1      connected_order_arc_1543  -12
    RHS1      connected_order_arc_1545  -12
    RHS1      connected_order_arc_1547  -12
    RHS1      connected_order_arc_1549  -12
    RHS1      connected_order_arc_1551  -12
    RHS1      connected_order_arc_1553  -12
    RHS1      connected_order_arc_1555  -12
    RHS1      connected_order_arc_1557  -12
    RHS1      connected_order_arc_1559  -12
    RHS1      connected_order_arc_1562  -12
    RHS1      connected_order_arc_1564  -12
    RHS1      connected_order_arc_1566  -12
    RHS1      connected_order_arc_1568  -12
    RHS1      connected_order_arc_1570  -12
    RHS1      connected_order_arc_1572  -12
    RHS1      connected_order_arc_1574  -12
    RHS1      connected_order_arc_1576  -12
    RHS1      connected_order_arc_1578  -12
    RHS1      connected_order_arc_1580  -12
    RHS1      connected_order_arc_1582  -12
    RHS1      depot_departure_or_bypass_1583  1
    RHS1      depot_return_or_bypass_1584  1
    RHS1      segment_load_conservation_1589  3
    RHS1      segment_prefix_ub_1591  27
    RHS1      segment_load_conservation_1596  6
    RHS1      segment_prefix_ub_1598  24
    RHS1      segment_load_conservation_1603  -6
    RHS1      segment_prefix_lb_1604  6
    RHS1      segment_prefix_ub_1605  30
    RHS1      segment_load_conservation_1610  -2
    RHS1      segment_prefix_lb_1611  2
    RHS1      segment_prefix_ub_1612  30
    RHS1      fixed_segment_relative_order_1661  1
    RHS1      fixed_segment_relative_order_1662  1
    RHS1      fixed_segment_relative_order_1663  1
    RHS1      original_T_including_depot_unload_1664  5632.18965781578
BOUNDS
 LO BND1      t         2.4901923970053259e-02
 UP BND1      t         4.1376592670473542e-02
 UP BND1      q         4.9007157375771537e-01
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.1376592670473542e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.1376592670473542e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.1376592670473542e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.1376592670473542e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.1376592670473542e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.1376592670473542e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.1376592670473542e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.1376592670473542e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.1376592670473542e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.1376592670473542e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.1376592670473542e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.1376592670473542e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.1376592670473542e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.1376592670473542e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.1376592670473542e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.1376592670473542e-02
 UP BND1      rho_35    1
 BV BND1      x_30_0  
 UP BND1      w_30_0    4.1376592670473542e-02
 BV BND1      x_30_1  
 UP BND1      w_30_1    4.1376592670473542e-02
 BV BND1      x_30_2  
 UP BND1      w_30_2    4.1376592670473542e-02
 BV BND1      x_30_3  
 UP BND1      w_30_3    4.1376592670473542e-02
 BV BND1      x_30_4  
 UP BND1      w_30_4    4.1376592670473542e-02
 BV BND1      x_30_5  
 UP BND1      w_30_5    4.1376592670473542e-02
 BV BND1      x_30_6  
 UP BND1      w_30_6    4.1376592670473542e-02
 BV BND1      x_30_7  
 UP BND1      w_30_7    4.1376592670473542e-02
 BV BND1      x_30_8  
 UP BND1      w_30_8    4.1376592670473542e-02
 UP BND1      rho_30    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1376592670473542e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1376592670473542e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1376592670473542e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1376592670473542e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1376592670473542e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1376592670473542e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1376592670473542e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1376592670473542e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1376592670473542e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1376592670473542e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1376592670473542e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1376592670473542e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1376592670473542e-02
 UP BND1      rho_31    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1376592670473542e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1376592670473542e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1376592670473542e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1376592670473542e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1376592670473542e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1376592670473542e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1376592670473542e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1376592670473542e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1376592670473542e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1376592670473542e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1376592670473542e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1376592670473542e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1376592670473542e-02
 UP BND1      rho_32    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.1376592670473542e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.1376592670473542e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.1376592670473542e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.1376592670473542e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.1376592670473542e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.1376592670473542e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.1376592670473542e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.1376592670473542e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.1376592670473542e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.1376592670473542e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.1376592670473542e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.1376592670473542e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.1376592670473542e-02
 UP BND1      rho_16    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.1376592670473542e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.1376592670473542e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.1376592670473542e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.1376592670473542e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.1376592670473542e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.1376592670473542e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.1376592670473542e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.1376592670473542e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.1376592670473542e-02
 UP BND1      rho_26    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.1376592670473542e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.1376592670473542e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.1376592670473542e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.1376592670473542e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.1376592670473542e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.1376592670473542e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.1376592670473542e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.1376592670473542e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.1376592670473542e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.1376592670473542e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.1376592670473542e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.1376592670473542e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.1376592670473542e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.1376592670473542e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.1376592670473542e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.1376592670473542e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.1376592670473542e-02
 UP BND1      rho_5     1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.1376592670473542e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.1376592670473542e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.1376592670473542e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.1376592670473542e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.1376592670473542e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.1376592670473542e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.1376592670473542e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.1376592670473542e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.1376592670473542e-02
 UP BND1      rho_19    1
 UP BND1      a_35_30   1
 UP BND1      a_35_31   1
 UP BND1      a_35_32   1
 UP BND1      a_35_16   1
 UP BND1      a_35_26   1
 UP BND1      a_35_5    1
 UP BND1      a_35_19   1
 UP BND1      a_30_31   1
 UP BND1      a_30_32   1
 UP BND1      a_30_16   1
 UP BND1      a_30_26   1
 UP BND1      a_30_5    1
 UP BND1      a_30_19   1
 UP BND1      a_31_32   1
 UP BND1      a_31_16   1
 UP BND1      a_31_26   1
 UP BND1      a_31_5    1
 UP BND1      a_31_19   1
 UP BND1      a_32_16   1
 UP BND1      a_32_26   1
 UP BND1      a_32_5    1
 UP BND1      a_32_19   1
 UP BND1      a_16_26   1
 UP BND1      a_16_5    1
 UP BND1      a_16_19   1
 UP BND1      a_26_5    1
 UP BND1      a_26_19   1
 UP BND1      a_5_19    1
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_3
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_3
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_3
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_5
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_5
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_5
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  14
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  14
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  14
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  14
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  14
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  14
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  14
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  14
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  14
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  14
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  14
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  14
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  14
 UP BND1      visit_0_23  1
 UP BND1      order_0_23  14
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_0_23
 FX BND1      load_0_0_23  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_1_23
 UP BND1      load_0_1_23  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_2_23
 UP BND1      load_0_2_23  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_3_23
 UP BND1      load_0_3_23  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_4_23
 UP BND1      load_0_4_23  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_5_23
 UP BND1      load_0_5_23  20
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  20
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  20
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  20
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  20
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  20
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  20
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  20
 BV BND1      arc_0_6_17
 UP BND1      load_0_6_17  20
 BV BND1      arc_0_6_18
 UP BND1      load_0_6_18  20
 BV BND1      arc_0_6_19
 UP BND1      load_0_6_19  20
 BV BND1      arc_0_6_20
 UP BND1      load_0_6_20  20
 BV BND1      arc_0_6_21
 UP BND1      load_0_6_21  20
 BV BND1      arc_0_6_22
 UP BND1      load_0_6_22  20
 BV BND1      arc_0_6_23
 UP BND1      load_0_6_23  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_16_23
 UP BND1      load_0_16_23  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_6
 UP BND1      load_0_17_6  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_17_23
 UP BND1      load_0_17_23  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_6
 UP BND1      load_0_18_6  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_18_23
 UP BND1      load_0_18_23  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_6
 UP BND1      load_0_19_6  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_19_23
 UP BND1      load_0_19_23  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_6
 UP BND1      load_0_20_6  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_20_23
 UP BND1      load_0_20_23  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_6
 UP BND1      load_0_21_6  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_21_23
 UP BND1      load_0_21_23  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_6
 UP BND1      load_0_22_6  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 BV BND1      arc_0_22_23
 UP BND1      load_0_22_23  20
 BV BND1      arc_0_23_0
 UP BND1      load_0_23_0  20
 BV BND1      arc_0_23_1
 UP BND1      load_0_23_1  20
 BV BND1      arc_0_23_2
 UP BND1      load_0_23_2  20
 BV BND1      arc_0_23_3
 UP BND1      load_0_23_3  20
 BV BND1      arc_0_23_4
 UP BND1      load_0_23_4  20
 BV BND1      arc_0_23_5
 UP BND1      load_0_23_5  20
 BV BND1      arc_0_23_6
 UP BND1      load_0_23_6  20
 BV BND1      arc_0_23_16
 UP BND1      load_0_23_16  20
 BV BND1      arc_0_23_17
 UP BND1      load_0_23_17  20
 BV BND1      arc_0_23_18
 UP BND1      load_0_23_18  20
 BV BND1      arc_0_23_19
 UP BND1      load_0_23_19  20
 BV BND1      arc_0_23_20
 UP BND1      load_0_23_20  20
 BV BND1      arc_0_23_21
 UP BND1      load_0_23_21  20
 BV BND1      arc_0_23_22
 UP BND1      load_0_23_22  20
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 FX BND1      visit_1_11  1
 UP BND1      order_1_11  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  13
 UP BND1      visit_1_23  1
 UP BND1      order_1_23  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_0_23
 FX BND1      load_1_0_23  0
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_7_23
 UP BND1      load_1_7_23  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_8_23
 UP BND1      load_1_8_23  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_9_23
 UP BND1      load_1_9_23  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_10_22
 UP BND1      load_1_10_22  25
 BV BND1      arc_1_10_23
 UP BND1      load_1_10_23  25
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  25
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  25
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  25
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  25
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  25
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  25
 BV BND1      arc_1_11_17
 UP BND1      load_1_11_17  25
 BV BND1      arc_1_11_18
 UP BND1      load_1_11_18  25
 BV BND1      arc_1_11_19
 UP BND1      load_1_11_19  25
 BV BND1      arc_1_11_20
 UP BND1      load_1_11_20  25
 BV BND1      arc_1_11_21
 UP BND1      load_1_11_21  25
 BV BND1      arc_1_11_22
 UP BND1      load_1_11_22  25
 BV BND1      arc_1_11_23
 UP BND1      load_1_11_23  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_16_23
 UP BND1      load_1_16_23  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_11
 UP BND1      load_1_17_11  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_17_23
 UP BND1      load_1_17_23  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_11
 UP BND1      load_1_18_11  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_18_23
 UP BND1      load_1_18_23  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_11
 UP BND1      load_1_19_11  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_19_23
 UP BND1      load_1_19_23  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_11
 UP BND1      load_1_20_11  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_20_23
 UP BND1      load_1_20_23  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_11
 UP BND1      load_1_21_11  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_21_23
 UP BND1      load_1_21_23  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_10
 UP BND1      load_1_22_10  25
 BV BND1      arc_1_22_11
 UP BND1      load_1_22_11  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 BV BND1      arc_1_22_23
 UP BND1      load_1_22_23  25
 BV BND1      arc_1_23_0
 UP BND1      load_1_23_0  25
 BV BND1      arc_1_23_7
 UP BND1      load_1_23_7  25
 BV BND1      arc_1_23_8
 UP BND1      load_1_23_8  25
 BV BND1      arc_1_23_9
 UP BND1      load_1_23_9  25
 BV BND1      arc_1_23_10
 UP BND1      load_1_23_10  25
 BV BND1      arc_1_23_11
 UP BND1      load_1_23_11  25
 BV BND1      arc_1_23_16
 UP BND1      load_1_23_16  25
 BV BND1      arc_1_23_17
 UP BND1      load_1_23_17  25
 BV BND1      arc_1_23_18
 UP BND1      load_1_23_18  25
 BV BND1      arc_1_23_19
 UP BND1      load_1_23_19  25
 BV BND1      arc_1_23_20
 UP BND1      load_1_23_20  25
 BV BND1      arc_1_23_21
 UP BND1      load_1_23_21  25
 BV BND1      arc_1_23_22
 UP BND1      load_1_23_22  25
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  12
 FX BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  12
 UP BND1      visit_2_23  1
 UP BND1      order_2_23  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_0_23
 FX BND1      load_2_0_23  0
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_12_23
 UP BND1      load_2_12_23  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_13_23
 UP BND1      load_2_13_23  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_14_23
 UP BND1      load_2_14_23  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_15_23
 UP BND1      load_2_15_23  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_16_23
 UP BND1      load_2_16_23  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_17_23
 UP BND1      load_2_17_23  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_18_23
 UP BND1      load_2_18_23  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_19_23
 UP BND1      load_2_19_23  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_20_23
 UP BND1      load_2_20_23  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_21_23
 UP BND1      load_2_21_23  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
 BV BND1      arc_2_22_23
 UP BND1      load_2_22_23  30
 BV BND1      arc_2_23_0
 UP BND1      load_2_23_0  30
 BV BND1      arc_2_23_12
 UP BND1      load_2_23_12  30
 BV BND1      arc_2_23_13
 UP BND1      load_2_23_13  30
 BV BND1      arc_2_23_14
 UP BND1      load_2_23_14  30
 BV BND1      arc_2_23_15
 UP BND1      load_2_23_15  30
 BV BND1      arc_2_23_16
 UP BND1      load_2_23_16  30
 BV BND1      arc_2_23_17
 UP BND1      load_2_23_17  30
 BV BND1      arc_2_23_18
 UP BND1      load_2_23_18  30
 BV BND1      arc_2_23_19
 UP BND1      load_2_23_19  30
 BV BND1      arc_2_23_20
 UP BND1      load_2_23_20  30
 BV BND1      arc_2_23_21
 UP BND1      load_2_23_21  30
 BV BND1      arc_2_23_22
 UP BND1      load_2_23_22  30
ENDATA
