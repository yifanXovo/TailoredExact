* Signature: 0x324ac9d62187d7dc
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  onehot_2
 G  total_lower
COLUMNS
    G         OBJ       1
    state_1_0  onehot_1  1
    state_1_1  OBJ       0.2
    state_1_1  onehot_1  1
    state_1_1  total_lower  1
    state_2_0  onehot_2  1
    state_2_1  OBJ       0.3
    state_2_1  onehot_2  1
    state_2_1  total_lower  1
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      total_lower  1
BOUNDS
 UP BND1      G         1
 UP BND1      state_1_0  1
 UP BND1      state_1_1  1
 UP BND1      state_2_0  1
 UP BND1      state_2_1  1
ENDATA
