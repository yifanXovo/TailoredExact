* Signature: 0xa596aaa37949c841
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  product_mass_1
 G  product_lx_1_0
 L  product_ux_1_0
 G  product_Su_1_0
 L  product_Sl_1_0
 G  product_lx_1_1
 L  product_ux_1_1
 G  product_Su_1_1
 L  product_Sl_1_1
 G  product_lx_1_2
 L  product_ux_1_2
 G  product_Su_1_2
 L  product_Sl_1_2
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  product_mass_2
 G  product_lx_2_0
 L  product_ux_2_0
 G  product_Su_2_0
 L  product_Sl_2_0
 G  product_lx_2_1
 L  product_ux_2_1
 G  product_Su_2_1
 L  product_Sl_2_1
 G  product_lx_2_2
 L  product_ux_2_2
 G  product_Su_2_2
 L  product_Sl_2_2
 E  onehot_3
 E  inventory_3
 E  ratio_3 
 E  product_mass_3
 G  product_lx_3_0
 L  product_ux_3_0
 G  product_Su_3_0
 L  product_Sl_3_0
 G  product_lx_3_1
 L  product_ux_3_1
 G  product_Su_3_1
 L  product_Sl_3_1
 G  product_lx_3_2
 L  product_ux_3_2
 G  product_Su_3_2
 L  product_Sl_3_2
 E  denominator
 G  hard_lower
 L  hard_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_2_3
 G  abs_m_2_3
 L  physical_G_upper_outward
 G  total_product_lower
 L  total_product_upper
 G  floor_residual
 G  G_residual
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    onehot_1  1
    x[1,0]    product_lx_1_0  -0.1
    x[1,0]    product_ux_1_0  -2
    x[1,0]    product_Su_1_0  -2
    x[1,0]    product_Sl_1_0  -0.1
    x[1,1]    onehot_1  1
    x[1,1]    inventory_1  -1
    x[1,1]    product_lx_1_1  -0.1
    x[1,1]    product_ux_1_1  -2
    x[1,1]    product_Su_1_1  -2
    x[1,1]    product_Sl_1_1  -0.1
    x[1,2]    onehot_1  1
    x[1,2]    inventory_1  -2
    x[1,2]    product_lx_1_2  -0.1
    x[1,2]    product_ux_1_2  -2
    x[1,2]    product_Su_1_2  -2
    x[1,2]    product_Sl_1_2  -0.1
    x[2,0]    onehot_2  1
    x[2,0]    product_lx_2_0  -0.1
    x[2,0]    product_ux_2_0  -2
    x[2,0]    product_Su_2_0  -2
    x[2,0]    product_Sl_2_0  -0.1
    x[2,1]    onehot_2  1
    x[2,1]    inventory_2  -1
    x[2,1]    product_lx_2_1  -0.1
    x[2,1]    product_ux_2_1  -2
    x[2,1]    product_Su_2_1  -2
    x[2,1]    product_Sl_2_1  -0.1
    x[2,2]    onehot_2  1
    x[2,2]    inventory_2  -2
    x[2,2]    product_lx_2_2  -0.1
    x[2,2]    product_ux_2_2  -2
    x[2,2]    product_Su_2_2  -2
    x[2,2]    product_Sl_2_2  -0.1
    x[3,0]    onehot_3  1
    x[3,0]    product_lx_3_0  -0.1
    x[3,0]    product_ux_3_0  -2
    x[3,0]    product_Su_3_0  -2
    x[3,0]    product_Sl_3_0  -0.1
    x[3,1]    onehot_3  1
    x[3,1]    inventory_3  -1
    x[3,1]    product_lx_3_1  -0.1
    x[3,1]    product_ux_3_1  -2
    x[3,1]    product_Su_3_1  -2
    x[3,1]    product_Sl_3_1  -0.1
    x[3,2]    onehot_3  1
    x[3,2]    inventory_3  -2
    x[3,2]    product_lx_3_2  -0.1
    x[3,2]    product_ux_3_2  -2
    x[3,2]    product_Su_3_2  -2
    x[3,2]    product_Sl_3_2  -0.1
    MARKER    'MARKER'                 'INTEND'
    Sx[1,0]   product_mass_1  1
    Sx[1,0]   product_lx_1_0  1
    Sx[1,0]   product_ux_1_0  1
    Sx[1,0]   product_Su_1_0  1
    Sx[1,0]   product_Sl_1_0  1
    Sx[1,0]   floor_residual  -0.15625
    Sx[1,0]   G_residual  -0.15625
    Sx[1,1]   product_mass_1  1
    Sx[1,1]   product_lx_1_1  1
    Sx[1,1]   product_ux_1_1  1
    Sx[1,1]   product_Su_1_1  1
    Sx[1,1]   product_Sl_1_1  1
    Sx[1,1]   total_product_lower  1
    Sx[1,1]   total_product_upper  1
    Sx[1,2]   product_mass_1  1
    Sx[1,2]   product_lx_1_2  1
    Sx[1,2]   product_ux_1_2  1
    Sx[1,2]   product_Su_1_2  1
    Sx[1,2]   product_Sl_1_2  1
    Sx[1,2]   total_product_lower  2
    Sx[1,2]   total_product_upper  2
    Sx[1,2]   floor_residual  0.15625
    Sx[1,2]   G_residual  0.15625
    Sx[2,0]   product_mass_2  1
    Sx[2,0]   product_lx_2_0  1
    Sx[2,0]   product_ux_2_0  1
    Sx[2,0]   product_Su_2_0  1
    Sx[2,0]   product_Sl_2_0  1
    Sx[2,0]   floor_residual  -0.15625
    Sx[2,0]   G_residual  -0.15625
    Sx[2,1]   product_mass_2  1
    Sx[2,1]   product_lx_2_1  1
    Sx[2,1]   product_ux_2_1  1
    Sx[2,1]   product_Su_2_1  1
    Sx[2,1]   product_Sl_2_1  1
    Sx[2,1]   total_product_lower  1
    Sx[2,1]   total_product_upper  1
    Sx[2,2]   product_mass_2  1
    Sx[2,2]   product_lx_2_2  1
    Sx[2,2]   product_ux_2_2  1
    Sx[2,2]   product_Su_2_2  1
    Sx[2,2]   product_Sl_2_2  1
    Sx[2,2]   total_product_lower  2
    Sx[2,2]   total_product_upper  2
    Sx[2,2]   floor_residual  0.15625
    Sx[2,2]   G_residual  0.15625
    Sx[3,0]   product_mass_3  1
    Sx[3,0]   product_lx_3_0  1
    Sx[3,0]   product_ux_3_0  1
    Sx[3,0]   product_Su_3_0  1
    Sx[3,0]   product_Sl_3_0  1
    Sx[3,0]   floor_residual  -0.15625
    Sx[3,0]   G_residual  -0.15625
    Sx[3,1]   product_mass_3  1
    Sx[3,1]   product_lx_3_1  1
    Sx[3,1]   product_ux_3_1  1
    Sx[3,1]   product_Su_3_1  1
    Sx[3,1]   product_Sl_3_1  1
    Sx[3,1]   total_product_lower  1
    Sx[3,1]   total_product_upper  1
    Sx[3,2]   product_mass_3  1
    Sx[3,2]   product_lx_3_2  1
    Sx[3,2]   product_ux_3_2  1
    Sx[3,2]   product_Su_3_2  1
    Sx[3,2]   product_Sl_3_2  1
    Sx[3,2]   total_product_lower  2
    Sx[3,2]   total_product_upper  2
    Sx[3,2]   floor_residual  0.15625
    Sx[3,2]   G_residual  0.15625
    S         product_mass_1  -1
    S         product_Su_1_0  -1
    S         product_Sl_1_0  -1
    S         product_Su_1_1  -1
    S         product_Sl_1_1  -1
    S         product_Su_1_2  -1
    S         product_Sl_1_2  -1
    S         product_mass_2  -1
    S         product_Su_2_0  -1
    S         product_Sl_2_0  -1
    S         product_Su_2_1  -1
    S         product_Sl_2_1  -1
    S         product_Su_2_2  -1
    S         product_Sl_2_2  -1
    S         product_mass_3  -1
    S         product_Su_3_0  -1
    S         product_Sl_3_0  -1
    S         product_Su_3_1  -1
    S         product_Sl_3_1  -1
    S         product_Su_3_2  -1
    S         product_Sl_3_2  -1
    S         denominator  1
    S         physical_G_upper_outward  -1.8
    S         total_product_lower  -1
    S         total_product_upper  -4
    S         floor_residual  -0.21875
    S         G_residual  -0.21875
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -0.1
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -0.3
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    Y[3]      inventory_3  1
    Y[3]      ratio_3   -0.7
    Y[3]      hard_lower  1
    Y[3]      hard_upper  1
    r[1]      ratio_1   1
    r[1]      denominator  -1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[2]      ratio_2   1
    r[2]      denominator  -1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[3]      ratio_3   1
    r[3]      denominator  -1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    abs[1,2]  abs_p_1_2  1
    abs[1,2]  abs_m_1_2  1
    abs[1,2]  physical_G_upper_outward  1
    abs[1,3]  abs_p_1_3  1
    abs[1,3]  abs_m_1_3  1
    abs[1,3]  physical_G_upper_outward  1
    abs[2,3]  abs_p_2_3  1
    abs[2,3]  abs_m_2_3  1
    abs[2,3]  physical_G_upper_outward  1
    residual_scaled  OBJ       1
    residual_scaled  floor_residual  1
    residual_scaled  G_residual  1
RHS
    RHS1      onehot_1  1
    RHS1      product_Su_1_0  -2
    RHS1      product_Sl_1_0  -0.1
    RHS1      product_Su_1_1  -2
    RHS1      product_Sl_1_1  -0.1
    RHS1      product_Su_1_2  -2
    RHS1      product_Sl_1_2  -0.1
    RHS1      onehot_2  1
    RHS1      product_Su_2_0  -2
    RHS1      product_Sl_2_0  -0.1
    RHS1      product_Su_2_1  -2
    RHS1      product_Sl_2_1  -0.1
    RHS1      product_Su_2_2  -2
    RHS1      product_Sl_2_2  -0.1
    RHS1      onehot_3  1
    RHS1      product_Su_3_0  -2
    RHS1      product_Sl_3_0  -0.1
    RHS1      product_Su_3_1  -2
    RHS1      product_Sl_3_1  -0.1
    RHS1      product_Su_3_2  -2
    RHS1      product_Sl_3_2  -0.1
    RHS1      hard_lower  1
    RHS1      hard_upper  4
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 UP BND1      Sx[1,0]   2
 UP BND1      Sx[1,1]   2
 UP BND1      Sx[1,2]   2
 UP BND1      Sx[2,0]   2
 UP BND1      Sx[2,1]   2
 UP BND1      Sx[2,2]   2
 UP BND1      Sx[3,0]   2
 UP BND1      Sx[3,1]   2
 UP BND1      Sx[3,2]   2
 LO BND1      S         0.1
 UP BND1      S         2
 FR BND1      residual_scaled
ENDATA
