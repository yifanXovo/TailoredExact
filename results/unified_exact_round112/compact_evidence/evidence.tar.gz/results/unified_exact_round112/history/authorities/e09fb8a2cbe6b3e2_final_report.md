# Round108: SELECT_MB_FOR_BROAD_EVALUATION

The exact frozen M-B is selected for broader paper evaluation. This is a resource/candidate decision, not proof of stable generalization or completed paper qualification. ENS-C remains the default.

The study compares only original cold P-GRB, full ENS-C and the inherited R100 M-B. There is no production source change, new cut, new algorithm variant, tuning, instance dispatcher or default replacement. The added work is a current comparable build, frozen input/measurement protocol, conditional confirmation and auditable selection.

## Current complete paired results

| Stage / role | Arm | Physical T | Cap | Complete seconds | Own physical U | Qualified complete-cover L | Signed U-L | Certified |
|---|---|---:|---:|---:|---:|---:|---:|---|
| bridge01 / F2 | P-GRB | 3600 | 1200 | 1171.012 | 0.8659435203 | 0.7638859210 | 0.1020575994 | False |
| bridge01 / F2 | ENS-C | 3600 | 1200 | 539.537 | 0.8659435203 | 0.8659435203 | 5.551e-16 | True |
| bridge01 / F2 | M-B | 3600 | 1200 | 715.970 | 0.8659435203 | 0.8659435175 | 2.862e-09 | True |
| bridge01 / C2 | ENS-C | 7200 | 1800 | 1770.988 | 0.2167930653 | 0.1896916167 | 0.0271014486 | False |
| bridge01 / C2 | M-B | 7200 | 1800 | 1771.157 | 0.1946348157 | 0.1906691839 | 0.0039656318 | False |
| bridge01 / C2 | P-GRB | 7200 | 1800 | 1771.029 | 0.1983028486 | 0.1866380920 | 0.0116647566 | False |
| confirmation01 / S12 | M-B | 3600 | 900 | 10.542 | 0.2252487060 | 0.2252487060 | 4.996e-16 | True |
| confirmation01 / S12 | P-GRB | 3600 | 900 | 38.719 | 0.2252487060 | 0.2252487060 | 1.665e-16 | True |
| confirmation01 / S12 | ENS-C | 3600 | 900 | 11.692 | 0.2252487060 | 0.2252487060 | 8.049e-16 | True |
| confirmation01 / B24 | P-GRB | 5400 | 1800 | 1772.559 | 0.1289645462 | 0.0633158467 | 0.0656486994 | False |
| confirmation01 / B24 | ENS-C | 5400 | 1800 | 284.138 | 0.1279747042 | 0.1279747042 | 2.220e-16 | True |
| confirmation01 / B24 | M-B | 5400 | 1800 | 286.149 | 0.1279747042 | 0.1279747012 | 3.025e-09 | True |
| confirmation01 / L48 | ENS-C | 18000 | 1800 | 1541.250 | 0.2017085230 | 0.2017085230 | 1.943e-16 | True |
| confirmation01 / L48 | M-B | 18000 | 1800 | 1561.943 | 0.2017085230 | 0.2017085230 | 3.886e-16 | True |
| confirmation01 / L48 | P-GRB | 18000 | 1800 | 1771.110 | 0.2032383317 | 0.2017085230 | 0.0015298088 | False |
| confirmation01 / F5 | M-B | 7200 | 5400 | 5371.200 | 0.3450212709 | 0.2814898163 | 0.0635314546 | False |
| confirmation01 / F5 | P-GRB | 7200 | 5400 | 5371.165 | 0.4160039101 | 0.2687398457 | 0.1472640644 | False |
| confirmation01 / F5 | ENS-C | 7200 | 5400 | 5371.215 | 0.3139451474 | 0.2814538063 | 0.0324913411 | False |
| confirmation01 / N36 | P-GRB | 7200 | 5400 | 5371.124 | 0.2869750317 | 0.1500360176 | 0.1369390141 | False |
| confirmation01 / N36 | ENS-C | 7200 | 5400 | 5371.100 | 0.1825124730 | 0.1532371169 | 0.0292753560 | False |
| confirmation01 / N36 | M-B | 7200 | 5400 | 5371.086 | 0.1890334344 | 0.1530742204 | 0.0359592140 | False |

Every U has its own full fleet and independently recomputed inventory, objective, empty departure, prefix/return capacity, unique nonzero one-direction integer service and closed travel/handling duration. No cross-arm UB, Start, route, cut or cache is used. Tiny signed negative gaps remain visible; invalid contradictions are rejected. Relative gap is null at the original 1e-12 zero tolerance and for missing/unqualified values. Complete certification is reconstructed from scope/cover, actual native statuses/provenance and physical U, never from a zero summary gap alone.

| Role | M-B vs P | Severe P regression | M-B vs ENS | Severe ENS regression |
|---|---|---|---|---|
| F2 | WIN | False | LOSS | False |
| C2 | WIN | False | WIN | False |
| S12 | TIE | False | TIE | False |
| B24 | WIN | False | TIE | False |
| L48 | WIN | False | TIE | False |
| F5 | WIN | False | LOSS | True |
| N36 | WIN | False | LOSS | False |

Material P gains established by complete certification within the window: F2, B24, L48. Other material P gains: C2 (both_uncertified_absolute_materiality), F5 (both_uncertified_absolute_materiality), N36 (both_uncertified_absolute_materiality). Certificate-priority gains do not require the own UB difference separately to reach the dual-uncertified UB threshold. Complete time ratios are reported only when both methods certify.

Observed losses and mixed tradeoffs:
- F2 versus ENS-C: LOSS; complete time increase 176.432556s, threshold 53.953707s; severe regression=False.
- F5 versus ENS-C: LOSS; own U 0.3450212709 versus 0.3139451474, signed gap 0.0635314546 versus 0.0324913411, candidate/control certificates False/False; severe regression=True.
- N36 versus ENS-C: LOSS; own U 0.1890334344 versus 0.1825124730, signed gap 0.0359592140 versus 0.0292753560, candidate/control certificates False/False; severe regression=False.

S12 is TIE: the complete P time benefit is 28.177672s against its 30.000000s materiality floor. Its small easy certified result is retained without substitution.

Exact prospective four-role count: WIN=3, LOSS=0; denominator remains S12/B24/L48/N36. Complete formal arms=21; cancelled arms=0. F2/C2 are development bridges, F5 is known stress, and H100 is functional qualification. The 21 registered arms are not 21 independent new samples. No cross-instance mean of unnormalized objectives or precise speedup of censored proof times is reported.

F2 gate=True; C2 gate=True; joint admission=True. All six current bridge arms were completed. Relative ENS dominance is not a hidden condition. Pair thresholds, certificate priority, absolute materiality, severe-risk definitions, and exact early-cancellation conditions remain the preregistered rules. `pairs.csv` and `worst_losses.csv` disclose all ENS losses and MIXED tradeoffs.

## Prospective inputs and observed mechanism scope

Frozen role identities and exact input bytes:

| Role / identity | V/M | Q | Physical T | Cap | Order | Input SHA256 |
|---|---|---|---:|---:|---|---|
| F2 / known_development_bridge | 20/2 | [30, 30] | 3600 | 1200 | P-GRB, ENS-C, M-B | `ebdf99e77dc9dcc57946970fa6d7e1cdf2defdcd277562a454d4889c716b645e` |
| C2 / known_development_bridge | 30/3 | [20, 25, 30] | 7200 | 1800 | ENS-C, M-B, P-GRB | `07d0964c87b534254e6bf2957911859a6a2bd73e377211728b7e65f44294fc76` |
| S12 / sealed_unused_for_selection | 12/2 | [8, 12] | 3600 | 900 | M-B, P-GRB, ENS-C | `475763e70a2dc3b9d28a88028378e76946cbebf33aa7b7e5b033e018dd13369f` |
| B24 / new_draw_unused_for_selection | 24/2 | [16, 24] | 5400 | 1800 | P-GRB, ENS-C, M-B | `068cbb4edc3f851f8c16e234dad6aa99aa14da8734d8ae22ff76cfd7133ae8ca` |
| L48 / new_draw_unused_for_selection | 48/4 | [30, 30, 30, 30] | 18000 | 1800 | ENS-C, M-B, P-GRB | `8ce2bceb8de415a1ff62ea78790456ee54e3542ce57714a7a53505d30ea54755` |
| F5 / known_pressure | 50/4 | [30, 30, 30, 30] | 7200 | 5400 | M-B, P-GRB, ENS-C | `5145b134f52dc573900b0b271325639fb04dc5eed37bf996f6b984f74efacc8a` |
| N36 / sealed_unused_for_selection | 36/3 | [24, 30, 36] | 7200 | 5400 | P-GRB, ENS-C, M-B | `52d7e43a1cc3717cfe7183b302212c7ef0a4e81f3e62642c4fe8f83c546e6fea` |

All roles use pickup/drop 60 seconds and lambda .15. Source input and prototype identities are pinned before the first formal arm.
B24: station-only original/target stock totals 535/535, weight range [0.287814, 0.978083]. Depot placeholders are excluded.
L48: station-only original/target stock totals 974/1052, weight range [0.259019, 0.998865]. Depot placeholders are excluded.

S12/N36 retain their original R106 bytes. Independent retained-history scans used their exact path/SHA, distinguished unrelated old S12 aliases, and found no prior solver/LP measurement. B24/L48 were single deterministic draws under `round108-uniform-candidate-confirmation-v1`, using existing landscape/writer code and no solver, difficulty screening or reseeding. A depot-inclusive parser assertion failed before any new draw; that failure and same-recipe repair are preserved. These are new draws/structure combinations, not new cities or independent data-generating distributions.

B24 has balanced original/target station totals; any legal zero result is retained rather than replaced. L48 has positive weights, lambda .15 and original stock below target total. Empty-departure stock conservation therefore prevents every target ratio from being one, excluding F=0 without establishing difficulty. Measured confirmation evidence becomes seen evidence for later design.

`controller_*`, `frontier.csv`, `leaf_obligations.csv`, `native_calls.csv`, `models.csv`, `starts.csv` and `native_type_readbacks.csv` report actual startup, original lookahead LP/partial/terminal calls, AM actions/targets, active covers, epochs and declared/restored domains. A lookahead child LP is not a committed multileaf split. M-B keeps integer routes and does not use R107 assignment-event or route-oracle counts. Actual submitted Start CSVs check every column/type/bound/row; native full-model counts confirm MIP restoration. Native accepted physical witnesses pass the unchanged all-quantity guard before decoding and are independently checked as integer operations. This is not retention of every native branch variable or a native-tree identity claim.

`time_partitions.csv` separates startup-before-exact, original LP native inclusive, MIP/callback native inclusive, controller/model/mapping/write residual and prelaunch/postexit audit. AM/mapping/callback parts lacking an independent timer remain merged. Nested native seconds are not added to fees. `checkpoints.csv` marks only actual observed 300/600/900/1200/1800/3600/5400 windows; reserve-ending and early-completed missing checkpoints are not extrapolated. `optimal_witness_bounds.csv` exists only for roles with reliable original Fstar and uses a safe [0, committed-observation upper] interval, not exact first native discovery time.

Actual formal mechanism exposure (counts from raw returned-call/AM/cover ledgers):

| Role | Arm | LP | Partial target MIP | Terminal MIP | AM actions | Maximum open relevant leaves |
|---|---|---:|---:|---:|---|---:|
| F2 | P-GRB | 0 | 0 | 1 | {} | 0 |
| F2 | ENS-C | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| F2 | M-B | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| C2 | ENS-C | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| C2 | M-B | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| C2 | P-GRB | 0 | 0 | 1 | {} | 0 |
| S12 | M-B | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| S12 | P-GRB | 0 | 0 | 1 | {} | 0 |
| S12 | ENS-C | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| B24 | P-GRB | 0 | 0 | 1 | {} | 0 |
| B24 | ENS-C | 3 | 0 | 1 | {"exact-close":1} | 1 |
| B24 | M-B | 3 | 0 | 1 | {"exact-close":1} | 1 |
| L48 | ENS-C | 7 | 2 | 1 | {"exact-close":1,"split":1} | 2 |
| L48 | M-B | 7 | 2 | 1 | {"exact-close":1,"split":1} | 2 |
| L48 | P-GRB | 0 | 0 | 1 | {} | 0 |
| F5 | M-B | 5 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| F5 | P-GRB | 0 | 0 | 1 | {} | 0 |
| F5 | ENS-C | 5 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| N36 | P-GRB | 0 | 0 | 1 | {} | 0 |
| N36 | ENS-C | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |
| N36 | M-B | 3 | 1 | 1 | {"exact-close":1,"native-target":1} | 1 |

Current original-controller exposure with multiple open relevant leaves: L48 / ENS-C, L48 / M-B. Partial-target counts include original child-bound and next-leaf targets, with separate subcounts in the raw-rebuilt mechanism table. A saved open leaf is discharged only after its complete true-G partition and already available bounds independently exclude improvement of the own physical U. This finite M-B/ENS exposure does not reopen the stopped R107 assignment/STRUCT configuration or establish a causal split/type/A-B speed attribution.

## Inheritance, resources and recovery

The [R100 candidate freeze](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round100/candidate_freeze.json), [report](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round100/final_report.md) and [frozen mathematics](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round100/mathematical_algorithm.md) establish the inherited candidate, implicit p/d integrality and valid A/B. R100 M-B had F2/C1 ENS delays and weaker F5 ENS quality, alongside P gains on C2/N2 and certification roles. This round cannot separately identify p/d declaration and A/B contributions or infer native speed from root LP strength.

[R107 report](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round107/final_report.md) preserves STOP_TESTED_CONFIGURATION: F2 ENS certified at 539.500s while FRONTIER did not; C2 GLOBAL/FRONTIER U≈.3750564073 and L≈.1891247571 versus P U≈.1983028486. Both FRONTIER runs exposed three original lookahead LPs, root partial target/requeue/cache and root terminal, with no actual multiactive-leaf split. Noninitial cross-request cache/remap exposure was 0. Integer-operation/Y event prefixes 104 (F2) / 2465 (C2) matched GLOBAL; complete native trees, bases and all-variable identity were not established. That tested AM/backend combination is not reopened here.

Measured production source content is inherited R107 delivery `b5db3f038f64215766a54498d8acc82e384de733`. Current PE SHA `4647ee9f146a010ae4bc48f191ec12d4b9113e167b8eeccf0e43a3764e0a8ee0`; actual Gurobi 13.0.2 DLL SHA `9b5fccef82043cc9a0f052d31fa9c12b6d59cec999ad0cc19ca1b68ed6d18a88`. Source/tool/input/full argv bindings are in `candidate_identity.json` and campaign identities. Threads 1 / Seed 0 / Presolve Auto, gaps 0, FeasibilityTol/OptimalityTol 1e-6 and IntFeasTol 1e-5 are read back. The running F2-P actual PE/DLL module sample is retained. Pure reader repairs do not rerun performance. The original decision reader and later actual engineering attempts have source snapshots and receipts; the initial route-I/B diagnostic failure retains its traceback, but its exact whole-script snapshot and elapsed time were not captured. `reproduce.md` records this limitation.

The independent through-F5 audit initially rejected a source-vehicle comparison because it omitted the inherited equal-capacity route normalization before Start mapping. The existing mapper stably orders nonempty routes by operation count within each capacity class and assigns ascending vehicle IDs. The corrected independent audit checks the complete x/conn/z/mode/p/d/load/ord/Y/state/G vector against that precisely normalized own fleet, in addition to all native columns, types, bounds, rows and objective. The failed audit and exact source/receipt/diagnosis are retained; 24 finite normalization cases and R100 function/call-site bindings passed. Production, performance commands, primary reconstruction and selection rules were unchanged; no performance rerun was used.

Historical measured identities are not current performance arms: R107 production source `bb0017620008f9c98e40ba032d022f52f4f23788`, PE `364501ac3dd2599834ee2bf40ccceca2d6c01bbb761cdc706f141832619088a2`; R100 frozen source `b5d6d83bb8fc74682de6f1f6862c2e687712f4cf`, PE `fd2a30ea0bdba13dda7c19ee69e8c1f7f874482f3dad7cb2c1df48c4d7404f64`. Historical file paths and exact byte SHA values are pinned separately in the public carrier manifest.

Additional retained family decisions use the public [R98](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round98/final_report.md), [R99](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round99/final_report.md), [R102](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round102/final_report.md), [R105](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round105/final_report.md) and [R106](https://github.com/yifanXovo/TailoredExact/blob/b5db3f038f64215766a54498d8acc82e384de733/results/unified_exact_round106/final_report.md) reports, with exact dependency SHA values in the same manifest. R102 remains a genuine service-resource increment with mixed results and research opt-in/default-off status; it is not relabelled as a stopped family.

Paid conservative starts=46/48; outer solver fee=47514.073242100/80000 seconds. Actual Optimize=100, returned=100, IIS=0, route-oracle=0. Qualification, every native child and enclosing wrapper are charged once; unused preregistered fallback children remain conservatively charged. Failures and cancellations are retained. Build, reader, independent review, packaging and recovery are engineering work.

The complete raw carrier and precise small public historical dependencies are described in `compact_evidence/manifest.json` and `reproduce.md`. Actual export to a new public-only directory, new isolated restoration, exact all-field CSV/decision comparisons and independent isolated physics/cover/selection review have separate public receipts. No PE, DLL, license file or credentials are distributed. This is evidence/mathematical reconstruction, not an independent engine performance rerun.

The remaining evidence and historical mechanism decisions are in `reports_final/candidate_evidence_gap.csv` and `reports_final/stopped_mechanism_families.csv`. A positive stage requires broader prospective paper evidence for this same uniform candidate; a negative stage does not automatically fund another M-B/STRUCT mechanism layer.
