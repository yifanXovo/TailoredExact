* Signature: 0xadf5d2ae890d2899
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 G  R0      
 G  R1      
 G  R2      
 G  R3      
 L  label_0 
 L  label_1 
 L  label_2 
 L  label_3 
 L  label_4 
 L  label_5 
 L  label_6 
COLUMNS
    p         R1        -4
    p         label_0   -3
    p         label_2   -2
    p         label_3   -8
    p         label_4   -7
    p         label_5   -5
    p         label_6   -1
    r         R2        -1.6666666666666667e+00
    r         R3        -2.8333333333333335e+00
    r         label_0   -1.5
    r         label_2   -1.5
    r         label_3   -6
    r         label_4   -5.5
    r         label_5   -3.5
    r         label_6   -0.5
    eta       label_0   -6.0000000000000009e-01
    eta       label_2   3.9999999999999997e-01
    eta       label_3   1.5999999999999999e+00
    eta       label_4   7.9999999999999982e-01
    eta       label_5   1.5999999999999999e+00
    eta       label_6   -0.2
    theta     OBJ       1
    theta     label_0   1
    theta     label_1   1
    theta     label_2   1
    theta     label_3   1
    theta     label_4   1
    theta     label_5   1
    theta     label_6   1
    support_T  OBJ       -1
    support_T  R0        1
    support_T  R1        1
    support_S  OBJ       -1
    support_S  R2        1
    support_S  R3        1
RHS
    RHS1      label_0   -0.625
    RHS1      label_4   -1.125
    RHS1      label_5   -0.875
    RHS1      label_6   -0.375
BOUNDS
 LO BND1      p         -2.25
 UP BND1      p         2.25
 LO BND1      r         -2.25
 UP BND1      r         2.25
 UP BND1      eta       2.25
 FR BND1      theta   
 FR BND1      support_T
 FR BND1      support_S
ENDATA
