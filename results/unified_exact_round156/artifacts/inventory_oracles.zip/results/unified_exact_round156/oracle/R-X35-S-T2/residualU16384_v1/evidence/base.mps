* Signature: 0xa1e814fa2d4cbd44
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  inventory_1
 E  ratio_1 
 E  product_mass_1
 G  product_lx_1_0
 L  product_ux_1_0
 G  product_Su_1_0
 L  product_Sl_1_0
 G  product_lx_1_1
 L  product_ux_1_1
 G  product_Su_1_1
 L  product_Sl_1_1
 G  product_lx_1_2
 L  product_ux_1_2
 G  product_Su_1_2
 L  product_Sl_1_2
 G  product_lx_1_3
 L  product_ux_1_3
 G  product_Su_1_3
 L  product_Sl_1_3
 G  product_lx_1_4
 L  product_ux_1_4
 G  product_Su_1_4
 L  product_Sl_1_4
 G  product_lx_1_5
 L  product_ux_1_5
 G  product_Su_1_5
 L  product_Sl_1_5
 G  product_lx_1_6
 L  product_ux_1_6
 G  product_Su_1_6
 L  product_Sl_1_6
 G  product_lx_1_7
 L  product_ux_1_7
 G  product_Su_1_7
 L  product_Sl_1_7
 G  product_lx_1_8
 L  product_ux_1_8
 G  product_Su_1_8
 L  product_Sl_1_8
 E  onehot_2
 E  inventory_2
 E  ratio_2 
 E  product_mass_2
 G  product_lx_2_0
 L  product_ux_2_0
 G  product_Su_2_0
 L  product_Sl_2_0
 G  product_lx_2_1
 L  product_ux_2_1
 G  product_Su_2_1
 L  product_Sl_2_1
 G  product_lx_2_2
 L  product_ux_2_2
 G  product_Su_2_2
 L  product_Sl_2_2
 G  product_lx_2_3
 L  product_ux_2_3
 G  product_Su_2_3
 L  product_Sl_2_3
 G  product_lx_2_4
 L  product_ux_2_4
 G  product_Su_2_4
 L  product_Sl_2_4
 G  product_lx_2_5
 L  product_ux_2_5
 G  product_Su_2_5
 L  product_Sl_2_5
 G  product_lx_2_6
 L  product_ux_2_6
 G  product_Su_2_6
 L  product_Sl_2_6
 G  product_lx_2_7
 L  product_ux_2_7
 G  product_Su_2_7
 L  product_Sl_2_7
 G  product_lx_2_8
 L  product_ux_2_8
 G  product_Su_2_8
 L  product_Sl_2_8
 G  product_lx_2_9
 L  product_ux_2_9
 G  product_Su_2_9
 L  product_Sl_2_9
 G  product_lx_2_10
 L  product_ux_2_10
 G  product_Su_2_10
 L  product_Sl_2_10
 G  product_lx_2_11
 L  product_ux_2_11
 G  product_Su_2_11
 L  product_Sl_2_11
 G  product_lx_2_12
 L  product_ux_2_12
 G  product_Su_2_12
 L  product_Sl_2_12
 G  product_lx_2_13
 L  product_ux_2_13
 G  product_Su_2_13
 L  product_Sl_2_13
 G  product_lx_2_14
 L  product_ux_2_14
 G  product_Su_2_14
 L  product_Sl_2_14
 G  product_lx_2_15
 L  product_ux_2_15
 G  product_Su_2_15
 L  product_Sl_2_15
 E  onehot_3
 E  inventory_3
 E  ratio_3 
 E  product_mass_3
 G  product_lx_3_0
 L  product_ux_3_0
 G  product_Su_3_0
 L  product_Sl_3_0
 G  product_lx_3_1
 L  product_ux_3_1
 G  product_Su_3_1
 L  product_Sl_3_1
 G  product_lx_3_2
 L  product_ux_3_2
 G  product_Su_3_2
 L  product_Sl_3_2
 G  product_lx_3_3
 L  product_ux_3_3
 G  product_Su_3_3
 L  product_Sl_3_3
 G  product_lx_3_4
 L  product_ux_3_4
 G  product_Su_3_4
 L  product_Sl_3_4
 G  product_lx_3_5
 L  product_ux_3_5
 G  product_Su_3_5
 L  product_Sl_3_5
 G  product_lx_3_6
 L  product_ux_3_6
 G  product_Su_3_6
 L  product_Sl_3_6
 G  product_lx_3_7
 L  product_ux_3_7
 G  product_Su_3_7
 L  product_Sl_3_7
 G  product_lx_3_8
 L  product_ux_3_8
 G  product_Su_3_8
 L  product_Sl_3_8
 G  product_lx_3_9
 L  product_ux_3_9
 G  product_Su_3_9
 L  product_Sl_3_9
 G  product_lx_3_10
 L  product_ux_3_10
 G  product_Su_3_10
 L  product_Sl_3_10
 G  product_lx_3_11
 L  product_ux_3_11
 G  product_Su_3_11
 L  product_Sl_3_11
 G  product_lx_3_12
 L  product_ux_3_12
 G  product_Su_3_12
 L  product_Sl_3_12
 E  onehot_4
 E  inventory_4
 E  ratio_4 
 E  product_mass_4
 G  product_lx_4_0
 L  product_ux_4_0
 G  product_Su_4_0
 L  product_Sl_4_0
 G  product_lx_4_1
 L  product_ux_4_1
 G  product_Su_4_1
 L  product_Sl_4_1
 G  product_lx_4_2
 L  product_ux_4_2
 G  product_Su_4_2
 L  product_Sl_4_2
 G  product_lx_4_3
 L  product_ux_4_3
 G  product_Su_4_3
 L  product_Sl_4_3
 G  product_lx_4_4
 L  product_ux_4_4
 G  product_Su_4_4
 L  product_Sl_4_4
 G  product_lx_4_5
 L  product_ux_4_5
 G  product_Su_4_5
 L  product_Sl_4_5
 G  product_lx_4_6
 L  product_ux_4_6
 G  product_Su_4_6
 L  product_Sl_4_6
 G  product_lx_4_7
 L  product_ux_4_7
 G  product_Su_4_7
 L  product_Sl_4_7
 G  product_lx_4_8
 L  product_ux_4_8
 G  product_Su_4_8
 L  product_Sl_4_8
 G  product_lx_4_9
 L  product_ux_4_9
 G  product_Su_4_9
 L  product_Sl_4_9
 G  product_lx_4_10
 L  product_ux_4_10
 G  product_Su_4_10
 L  product_Sl_4_10
 G  product_lx_4_11
 L  product_ux_4_11
 G  product_Su_4_11
 L  product_Sl_4_11
 G  product_lx_4_12
 L  product_ux_4_12
 G  product_Su_4_12
 L  product_Sl_4_12
 G  product_lx_4_13
 L  product_ux_4_13
 G  product_Su_4_13
 L  product_Sl_4_13
 G  product_lx_4_14
 L  product_ux_4_14
 G  product_Su_4_14
 L  product_Sl_4_14
 G  product_lx_4_15
 L  product_ux_4_15
 G  product_Su_4_15
 L  product_Sl_4_15
 E  onehot_5
 E  inventory_5
 E  ratio_5 
 E  product_mass_5
 G  product_lx_5_0
 L  product_ux_5_0
 G  product_Su_5_0
 L  product_Sl_5_0
 G  product_lx_5_1
 L  product_ux_5_1
 G  product_Su_5_1
 L  product_Sl_5_1
 G  product_lx_5_2
 L  product_ux_5_2
 G  product_Su_5_2
 L  product_Sl_5_2
 G  product_lx_5_3
 L  product_ux_5_3
 G  product_Su_5_3
 L  product_Sl_5_3
 G  product_lx_5_4
 L  product_ux_5_4
 G  product_Su_5_4
 L  product_Sl_5_4
 G  product_lx_5_5
 L  product_ux_5_5
 G  product_Su_5_5
 L  product_Sl_5_5
 G  product_lx_5_6
 L  product_ux_5_6
 G  product_Su_5_6
 L  product_Sl_5_6
 G  product_lx_5_7
 L  product_ux_5_7
 G  product_Su_5_7
 L  product_Sl_5_7
 G  product_lx_5_8
 L  product_ux_5_8
 G  product_Su_5_8
 L  product_Sl_5_8
 G  product_lx_5_9
 L  product_ux_5_9
 G  product_Su_5_9
 L  product_Sl_5_9
 G  product_lx_5_10
 L  product_ux_5_10
 G  product_Su_5_10
 L  product_Sl_5_10
 G  product_lx_5_11
 L  product_ux_5_11
 G  product_Su_5_11
 L  product_Sl_5_11
 G  product_lx_5_12
 L  product_ux_5_12
 G  product_Su_5_12
 L  product_Sl_5_12
 G  product_lx_5_13
 L  product_ux_5_13
 G  product_Su_5_13
 L  product_Sl_5_13
 G  product_lx_5_14
 L  product_ux_5_14
 G  product_Su_5_14
 L  product_Sl_5_14
 G  product_lx_5_15
 L  product_ux_5_15
 G  product_Su_5_15
 L  product_Sl_5_15
 E  onehot_6
 E  inventory_6
 E  ratio_6 
 E  product_mass_6
 G  product_lx_6_0
 L  product_ux_6_0
 G  product_Su_6_0
 L  product_Sl_6_0
 G  product_lx_6_1
 L  product_ux_6_1
 G  product_Su_6_1
 L  product_Sl_6_1
 G  product_lx_6_2
 L  product_ux_6_2
 G  product_Su_6_2
 L  product_Sl_6_2
 G  product_lx_6_3
 L  product_ux_6_3
 G  product_Su_6_3
 L  product_Sl_6_3
 G  product_lx_6_4
 L  product_ux_6_4
 G  product_Su_6_4
 L  product_Sl_6_4
 G  product_lx_6_5
 L  product_ux_6_5
 G  product_Su_6_5
 L  product_Sl_6_5
 G  product_lx_6_6
 L  product_ux_6_6
 G  product_Su_6_6
 L  product_Sl_6_6
 G  product_lx_6_7
 L  product_ux_6_7
 G  product_Su_6_7
 L  product_Sl_6_7
 G  product_lx_6_8
 L  product_ux_6_8
 G  product_Su_6_8
 L  product_Sl_6_8
 E  onehot_7
 E  inventory_7
 E  ratio_7 
 E  product_mass_7
 G  product_lx_7_0
 L  product_ux_7_0
 G  product_Su_7_0
 L  product_Sl_7_0
 G  product_lx_7_1
 L  product_ux_7_1
 G  product_Su_7_1
 L  product_Sl_7_1
 G  product_lx_7_2
 L  product_ux_7_2
 G  product_Su_7_2
 L  product_Sl_7_2
 G  product_lx_7_3
 L  product_ux_7_3
 G  product_Su_7_3
 L  product_Sl_7_3
 G  product_lx_7_4
 L  product_ux_7_4
 G  product_Su_7_4
 L  product_Sl_7_4
 G  product_lx_7_5
 L  product_ux_7_5
 G  product_Su_7_5
 L  product_Sl_7_5
 G  product_lx_7_6
 L  product_ux_7_6
 G  product_Su_7_6
 L  product_Sl_7_6
 G  product_lx_7_7
 L  product_ux_7_7
 G  product_Su_7_7
 L  product_Sl_7_7
 G  product_lx_7_8
 L  product_ux_7_8
 G  product_Su_7_8
 L  product_Sl_7_8
 G  product_lx_7_9
 L  product_ux_7_9
 G  product_Su_7_9
 L  product_Sl_7_9
 G  product_lx_7_10
 L  product_ux_7_10
 G  product_Su_7_10
 L  product_Sl_7_10
 G  product_lx_7_11
 L  product_ux_7_11
 G  product_Su_7_11
 L  product_Sl_7_11
 G  product_lx_7_12
 L  product_ux_7_12
 G  product_Su_7_12
 L  product_Sl_7_12
 G  product_lx_7_13
 L  product_ux_7_13
 G  product_Su_7_13
 L  product_Sl_7_13
 G  product_lx_7_14
 L  product_ux_7_14
 G  product_Su_7_14
 L  product_Sl_7_14
 G  product_lx_7_15
 L  product_ux_7_15
 G  product_Su_7_15
 L  product_Sl_7_15
 E  onehot_8
 E  inventory_8
 E  ratio_8 
 E  product_mass_8
 G  product_lx_8_0
 L  product_ux_8_0
 G  product_Su_8_0
 L  product_Sl_8_0
 G  product_lx_8_1
 L  product_ux_8_1
 G  product_Su_8_1
 L  product_Sl_8_1
 G  product_lx_8_2
 L  product_ux_8_2
 G  product_Su_8_2
 L  product_Sl_8_2
 G  product_lx_8_3
 L  product_ux_8_3
 G  product_Su_8_3
 L  product_Sl_8_3
 G  product_lx_8_4
 L  product_ux_8_4
 G  product_Su_8_4
 L  product_Sl_8_4
 G  product_lx_8_5
 L  product_ux_8_5
 G  product_Su_8_5
 L  product_Sl_8_5
 G  product_lx_8_6
 L  product_ux_8_6
 G  product_Su_8_6
 L  product_Sl_8_6
 G  product_lx_8_7
 L  product_ux_8_7
 G  product_Su_8_7
 L  product_Sl_8_7
 G  product_lx_8_8
 L  product_ux_8_8
 G  product_Su_8_8
 L  product_Sl_8_8
 G  product_lx_8_9
 L  product_ux_8_9
 G  product_Su_8_9
 L  product_Sl_8_9
 G  product_lx_8_10
 L  product_ux_8_10
 G  product_Su_8_10
 L  product_Sl_8_10
 G  product_lx_8_11
 L  product_ux_8_11
 G  product_Su_8_11
 L  product_Sl_8_11
 G  product_lx_8_12
 L  product_ux_8_12
 G  product_Su_8_12
 L  product_Sl_8_12
 E  onehot_9
 E  inventory_9
 E  ratio_9 
 E  product_mass_9
 G  product_lx_9_0
 L  product_ux_9_0
 G  product_Su_9_0
 L  product_Sl_9_0
 G  product_lx_9_1
 L  product_ux_9_1
 G  product_Su_9_1
 L  product_Sl_9_1
 G  product_lx_9_2
 L  product_ux_9_2
 G  product_Su_9_2
 L  product_Sl_9_2
 G  product_lx_9_3
 L  product_ux_9_3
 G  product_Su_9_3
 L  product_Sl_9_3
 G  product_lx_9_4
 L  product_ux_9_4
 G  product_Su_9_4
 L  product_Sl_9_4
 G  product_lx_9_5
 L  product_ux_9_5
 G  product_Su_9_5
 L  product_Sl_9_5
 G  product_lx_9_6
 L  product_ux_9_6
 G  product_Su_9_6
 L  product_Sl_9_6
 G  product_lx_9_7
 L  product_ux_9_7
 G  product_Su_9_7
 L  product_Sl_9_7
 G  product_lx_9_8
 L  product_ux_9_8
 G  product_Su_9_8
 L  product_Sl_9_8
 G  product_lx_9_9
 L  product_ux_9_9
 G  product_Su_9_9
 L  product_Sl_9_9
 G  product_lx_9_10
 L  product_ux_9_10
 G  product_Su_9_10
 L  product_Sl_9_10
 E  onehot_10
 E  inventory_10
 E  ratio_10
 E  product_mass_10
 G  product_lx_10_0
 L  product_ux_10_0
 G  product_Su_10_0
 L  product_Sl_10_0
 G  product_lx_10_1
 L  product_ux_10_1
 G  product_Su_10_1
 L  product_Sl_10_1
 G  product_lx_10_2
 L  product_ux_10_2
 G  product_Su_10_2
 L  product_Sl_10_2
 G  product_lx_10_3
 L  product_ux_10_3
 G  product_Su_10_3
 L  product_Sl_10_3
 G  product_lx_10_4
 L  product_ux_10_4
 G  product_Su_10_4
 L  product_Sl_10_4
 G  product_lx_10_5
 L  product_ux_10_5
 G  product_Su_10_5
 L  product_Sl_10_5
 G  product_lx_10_6
 L  product_ux_10_6
 G  product_Su_10_6
 L  product_Sl_10_6
 E  onehot_11
 E  inventory_11
 E  ratio_11
 E  product_mass_11
 G  product_lx_11_0
 L  product_ux_11_0
 G  product_Su_11_0
 L  product_Sl_11_0
 G  product_lx_11_1
 L  product_ux_11_1
 G  product_Su_11_1
 L  product_Sl_11_1
 G  product_lx_11_2
 L  product_ux_11_2
 G  product_Su_11_2
 L  product_Sl_11_2
 G  product_lx_11_3
 L  product_ux_11_3
 G  product_Su_11_3
 L  product_Sl_11_3
 G  product_lx_11_4
 L  product_ux_11_4
 G  product_Su_11_4
 L  product_Sl_11_4
 G  product_lx_11_5
 L  product_ux_11_5
 G  product_Su_11_5
 L  product_Sl_11_5
 G  product_lx_11_6
 L  product_ux_11_6
 G  product_Su_11_6
 L  product_Sl_11_6
 G  product_lx_11_7
 L  product_ux_11_7
 G  product_Su_11_7
 L  product_Sl_11_7
 G  product_lx_11_8
 L  product_ux_11_8
 G  product_Su_11_8
 L  product_Sl_11_8
 G  product_lx_11_9
 L  product_ux_11_9
 G  product_Su_11_9
 L  product_Sl_11_9
 G  product_lx_11_10
 L  product_ux_11_10
 G  product_Su_11_10
 L  product_Sl_11_10
 E  onehot_12
 E  inventory_12
 E  ratio_12
 E  product_mass_12
 G  product_lx_12_0
 L  product_ux_12_0
 G  product_Su_12_0
 L  product_Sl_12_0
 G  product_lx_12_1
 L  product_ux_12_1
 G  product_Su_12_1
 L  product_Sl_12_1
 G  product_lx_12_2
 L  product_ux_12_2
 G  product_Su_12_2
 L  product_Sl_12_2
 G  product_lx_12_3
 L  product_ux_12_3
 G  product_Su_12_3
 L  product_Sl_12_3
 G  product_lx_12_4
 L  product_ux_12_4
 G  product_Su_12_4
 L  product_Sl_12_4
 G  product_lx_12_5
 L  product_ux_12_5
 G  product_Su_12_5
 L  product_Sl_12_5
 G  product_lx_12_6
 L  product_ux_12_6
 G  product_Su_12_6
 L  product_Sl_12_6
 G  product_lx_12_7
 L  product_ux_12_7
 G  product_Su_12_7
 L  product_Sl_12_7
 G  product_lx_12_8
 L  product_ux_12_8
 G  product_Su_12_8
 L  product_Sl_12_8
 G  product_lx_12_9
 L  product_ux_12_9
 G  product_Su_12_9
 L  product_Sl_12_9
 G  product_lx_12_10
 L  product_ux_12_10
 G  product_Su_12_10
 L  product_Sl_12_10
 G  product_lx_12_11
 L  product_ux_12_11
 G  product_Su_12_11
 L  product_Sl_12_11
 G  product_lx_12_12
 L  product_ux_12_12
 G  product_Su_12_12
 L  product_Sl_12_12
 E  onehot_13
 E  inventory_13
 E  ratio_13
 E  product_mass_13
 G  product_lx_13_0
 L  product_ux_13_0
 G  product_Su_13_0
 L  product_Sl_13_0
 G  product_lx_13_1
 L  product_ux_13_1
 G  product_Su_13_1
 L  product_Sl_13_1
 G  product_lx_13_2
 L  product_ux_13_2
 G  product_Su_13_2
 L  product_Sl_13_2
 G  product_lx_13_3
 L  product_ux_13_3
 G  product_Su_13_3
 L  product_Sl_13_3
 G  product_lx_13_4
 L  product_ux_13_4
 G  product_Su_13_4
 L  product_Sl_13_4
 G  product_lx_13_5
 L  product_ux_13_5
 G  product_Su_13_5
 L  product_Sl_13_5
 G  product_lx_13_6
 L  product_ux_13_6
 G  product_Su_13_6
 L  product_Sl_13_6
 G  product_lx_13_7
 L  product_ux_13_7
 G  product_Su_13_7
 L  product_Sl_13_7
 G  product_lx_13_8
 L  product_ux_13_8
 G  product_Su_13_8
 L  product_Sl_13_8
 E  onehot_14
 E  inventory_14
 E  ratio_14
 E  product_mass_14
 G  product_lx_14_0
 L  product_ux_14_0
 G  product_Su_14_0
 L  product_Sl_14_0
 G  product_lx_14_1
 L  product_ux_14_1
 G  product_Su_14_1
 L  product_Sl_14_1
 G  product_lx_14_2
 L  product_ux_14_2
 G  product_Su_14_2
 L  product_Sl_14_2
 G  product_lx_14_3
 L  product_ux_14_3
 G  product_Su_14_3
 L  product_Sl_14_3
 G  product_lx_14_4
 L  product_ux_14_4
 G  product_Su_14_4
 L  product_Sl_14_4
 G  product_lx_14_5
 L  product_ux_14_5
 G  product_Su_14_5
 L  product_Sl_14_5
 G  product_lx_14_6
 L  product_ux_14_6
 G  product_Su_14_6
 L  product_Sl_14_6
 G  product_lx_14_7
 L  product_ux_14_7
 G  product_Su_14_7
 L  product_Sl_14_7
 G  product_lx_14_8
 L  product_ux_14_8
 G  product_Su_14_8
 L  product_Sl_14_8
 E  onehot_15
 E  inventory_15
 E  ratio_15
 E  product_mass_15
 G  product_lx_15_0
 L  product_ux_15_0
 G  product_Su_15_0
 L  product_Sl_15_0
 G  product_lx_15_1
 L  product_ux_15_1
 G  product_Su_15_1
 L  product_Sl_15_1
 G  product_lx_15_2
 L  product_ux_15_2
 G  product_Su_15_2
 L  product_Sl_15_2
 G  product_lx_15_3
 L  product_ux_15_3
 G  product_Su_15_3
 L  product_Sl_15_3
 G  product_lx_15_4
 L  product_ux_15_4
 G  product_Su_15_4
 L  product_Sl_15_4
 G  product_lx_15_5
 L  product_ux_15_5
 G  product_Su_15_5
 L  product_Sl_15_5
 G  product_lx_15_6
 L  product_ux_15_6
 G  product_Su_15_6
 L  product_Sl_15_6
 G  product_lx_15_7
 L  product_ux_15_7
 G  product_Su_15_7
 L  product_Sl_15_7
 G  product_lx_15_8
 L  product_ux_15_8
 G  product_Su_15_8
 L  product_Sl_15_8
 E  onehot_16
 E  inventory_16
 E  ratio_16
 E  product_mass_16
 G  product_lx_16_0
 L  product_ux_16_0
 G  product_Su_16_0
 L  product_Sl_16_0
 G  product_lx_16_1
 L  product_ux_16_1
 G  product_Su_16_1
 L  product_Sl_16_1
 G  product_lx_16_2
 L  product_ux_16_2
 G  product_Su_16_2
 L  product_Sl_16_2
 G  product_lx_16_3
 L  product_ux_16_3
 G  product_Su_16_3
 L  product_Sl_16_3
 G  product_lx_16_4
 L  product_ux_16_4
 G  product_Su_16_4
 L  product_Sl_16_4
 G  product_lx_16_5
 L  product_ux_16_5
 G  product_Su_16_5
 L  product_Sl_16_5
 G  product_lx_16_6
 L  product_ux_16_6
 G  product_Su_16_6
 L  product_Sl_16_6
 G  product_lx_16_7
 L  product_ux_16_7
 G  product_Su_16_7
 L  product_Sl_16_7
 G  product_lx_16_8
 L  product_ux_16_8
 G  product_Su_16_8
 L  product_Sl_16_8
 G  product_lx_16_9
 L  product_ux_16_9
 G  product_Su_16_9
 L  product_Sl_16_9
 G  product_lx_16_10
 L  product_ux_16_10
 G  product_Su_16_10
 L  product_Sl_16_10
 G  product_lx_16_11
 L  product_ux_16_11
 G  product_Su_16_11
 L  product_Sl_16_11
 G  product_lx_16_12
 L  product_ux_16_12
 G  product_Su_16_12
 L  product_Sl_16_12
 G  product_lx_16_13
 L  product_ux_16_13
 G  product_Su_16_13
 L  product_Sl_16_13
 G  product_lx_16_14
 L  product_ux_16_14
 G  product_Su_16_14
 L  product_Sl_16_14
 G  product_lx_16_15
 L  product_ux_16_15
 G  product_Su_16_15
 L  product_Sl_16_15
 E  onehot_17
 E  inventory_17
 E  ratio_17
 E  product_mass_17
 G  product_lx_17_0
 L  product_ux_17_0
 G  product_Su_17_0
 L  product_Sl_17_0
 G  product_lx_17_1
 L  product_ux_17_1
 G  product_Su_17_1
 L  product_Sl_17_1
 G  product_lx_17_2
 L  product_ux_17_2
 G  product_Su_17_2
 L  product_Sl_17_2
 G  product_lx_17_3
 L  product_ux_17_3
 G  product_Su_17_3
 L  product_Sl_17_3
 G  product_lx_17_4
 L  product_ux_17_4
 G  product_Su_17_4
 L  product_Sl_17_4
 G  product_lx_17_5
 L  product_ux_17_5
 G  product_Su_17_5
 L  product_Sl_17_5
 G  product_lx_17_6
 L  product_ux_17_6
 G  product_Su_17_6
 L  product_Sl_17_6
 E  onehot_18
 E  inventory_18
 E  ratio_18
 E  product_mass_18
 G  product_lx_18_0
 L  product_ux_18_0
 G  product_Su_18_0
 L  product_Sl_18_0
 G  product_lx_18_1
 L  product_ux_18_1
 G  product_Su_18_1
 L  product_Sl_18_1
 G  product_lx_18_2
 L  product_ux_18_2
 G  product_Su_18_2
 L  product_Sl_18_2
 G  product_lx_18_3
 L  product_ux_18_3
 G  product_Su_18_3
 L  product_Sl_18_3
 G  product_lx_18_4
 L  product_ux_18_4
 G  product_Su_18_4
 L  product_Sl_18_4
 G  product_lx_18_5
 L  product_ux_18_5
 G  product_Su_18_5
 L  product_Sl_18_5
 G  product_lx_18_6
 L  product_ux_18_6
 G  product_Su_18_6
 L  product_Sl_18_6
 G  product_lx_18_7
 L  product_ux_18_7
 G  product_Su_18_7
 L  product_Sl_18_7
 G  product_lx_18_8
 L  product_ux_18_8
 G  product_Su_18_8
 L  product_Sl_18_8
 G  product_lx_18_9
 L  product_ux_18_9
 G  product_Su_18_9
 L  product_Sl_18_9
 G  product_lx_18_10
 L  product_ux_18_10
 G  product_Su_18_10
 L  product_Sl_18_10
 E  onehot_19
 E  inventory_19
 E  ratio_19
 E  product_mass_19
 G  product_lx_19_0
 L  product_ux_19_0
 G  product_Su_19_0
 L  product_Sl_19_0
 G  product_lx_19_1
 L  product_ux_19_1
 G  product_Su_19_1
 L  product_Sl_19_1
 G  product_lx_19_2
 L  product_ux_19_2
 G  product_Su_19_2
 L  product_Sl_19_2
 G  product_lx_19_3
 L  product_ux_19_3
 G  product_Su_19_3
 L  product_Sl_19_3
 G  product_lx_19_4
 L  product_ux_19_4
 G  product_Su_19_4
 L  product_Sl_19_4
 G  product_lx_19_5
 L  product_ux_19_5
 G  product_Su_19_5
 L  product_Sl_19_5
 G  product_lx_19_6
 L  product_ux_19_6
 G  product_Su_19_6
 L  product_Sl_19_6
 G  product_lx_19_7
 L  product_ux_19_7
 G  product_Su_19_7
 L  product_Sl_19_7
 G  product_lx_19_8
 L  product_ux_19_8
 G  product_Su_19_8
 L  product_Sl_19_8
 G  product_lx_19_9
 L  product_ux_19_9
 G  product_Su_19_9
 L  product_Sl_19_9
 G  product_lx_19_10
 L  product_ux_19_10
 G  product_Su_19_10
 L  product_Sl_19_10
 E  onehot_20
 E  inventory_20
 E  ratio_20
 E  product_mass_20
 G  product_lx_20_0
 L  product_ux_20_0
 G  product_Su_20_0
 L  product_Sl_20_0
 G  product_lx_20_1
 L  product_ux_20_1
 G  product_Su_20_1
 L  product_Sl_20_1
 G  product_lx_20_2
 L  product_ux_20_2
 G  product_Su_20_2
 L  product_Sl_20_2
 G  product_lx_20_3
 L  product_ux_20_3
 G  product_Su_20_3
 L  product_Sl_20_3
 G  product_lx_20_4
 L  product_ux_20_4
 G  product_Su_20_4
 L  product_Sl_20_4
 G  product_lx_20_5
 L  product_ux_20_5
 G  product_Su_20_5
 L  product_Sl_20_5
 G  product_lx_20_6
 L  product_ux_20_6
 G  product_Su_20_6
 L  product_Sl_20_6
 G  product_lx_20_7
 L  product_ux_20_7
 G  product_Su_20_7
 L  product_Sl_20_7
 G  product_lx_20_8
 L  product_ux_20_8
 G  product_Su_20_8
 L  product_Sl_20_8
 G  product_lx_20_9
 L  product_ux_20_9
 G  product_Su_20_9
 L  product_Sl_20_9
 G  product_lx_20_10
 L  product_ux_20_10
 G  product_Su_20_10
 L  product_Sl_20_10
 E  onehot_21
 E  inventory_21
 E  ratio_21
 E  product_mass_21
 G  product_lx_21_0
 L  product_ux_21_0
 G  product_Su_21_0
 L  product_Sl_21_0
 G  product_lx_21_1
 L  product_ux_21_1
 G  product_Su_21_1
 L  product_Sl_21_1
 G  product_lx_21_2
 L  product_ux_21_2
 G  product_Su_21_2
 L  product_Sl_21_2
 G  product_lx_21_3
 L  product_ux_21_3
 G  product_Su_21_3
 L  product_Sl_21_3
 G  product_lx_21_4
 L  product_ux_21_4
 G  product_Su_21_4
 L  product_Sl_21_4
 G  product_lx_21_5
 L  product_ux_21_5
 G  product_Su_21_5
 L  product_Sl_21_5
 G  product_lx_21_6
 L  product_ux_21_6
 G  product_Su_21_6
 L  product_Sl_21_6
 E  onehot_22
 E  inventory_22
 E  ratio_22
 E  product_mass_22
 G  product_lx_22_0
 L  product_ux_22_0
 G  product_Su_22_0
 L  product_Sl_22_0
 G  product_lx_22_1
 L  product_ux_22_1
 G  product_Su_22_1
 L  product_Sl_22_1
 G  product_lx_22_2
 L  product_ux_22_2
 G  product_Su_22_2
 L  product_Sl_22_2
 G  product_lx_22_3
 L  product_ux_22_3
 G  product_Su_22_3
 L  product_Sl_22_3
 G  product_lx_22_4
 L  product_ux_22_4
 G  product_Su_22_4
 L  product_Sl_22_4
 G  product_lx_22_5
 L  product_ux_22_5
 G  product_Su_22_5
 L  product_Sl_22_5
 G  product_lx_22_6
 L  product_ux_22_6
 G  product_Su_22_6
 L  product_Sl_22_6
 G  product_lx_22_7
 L  product_ux_22_7
 G  product_Su_22_7
 L  product_Sl_22_7
 G  product_lx_22_8
 L  product_ux_22_8
 G  product_Su_22_8
 L  product_Sl_22_8
 G  product_lx_22_9
 L  product_ux_22_9
 G  product_Su_22_9
 L  product_Sl_22_9
 G  product_lx_22_10
 L  product_ux_22_10
 G  product_Su_22_10
 L  product_Sl_22_10
 G  product_lx_22_11
 L  product_ux_22_11
 G  product_Su_22_11
 L  product_Sl_22_11
 G  product_lx_22_12
 L  product_ux_22_12
 G  product_Su_22_12
 L  product_Sl_22_12
 G  product_lx_22_13
 L  product_ux_22_13
 G  product_Su_22_13
 L  product_Sl_22_13
 G  product_lx_22_14
 L  product_ux_22_14
 G  product_Su_22_14
 L  product_Sl_22_14
 G  product_lx_22_15
 L  product_ux_22_15
 G  product_Su_22_15
 L  product_Sl_22_15
 E  onehot_23
 E  inventory_23
 E  ratio_23
 E  product_mass_23
 G  product_lx_23_0
 L  product_ux_23_0
 G  product_Su_23_0
 L  product_Sl_23_0
 G  product_lx_23_1
 L  product_ux_23_1
 G  product_Su_23_1
 L  product_Sl_23_1
 G  product_lx_23_2
 L  product_ux_23_2
 G  product_Su_23_2
 L  product_Sl_23_2
 G  product_lx_23_3
 L  product_ux_23_3
 G  product_Su_23_3
 L  product_Sl_23_3
 E  onehot_24
 E  inventory_24
 E  ratio_24
 E  product_mass_24
 G  product_lx_24_0
 L  product_ux_24_0
 G  product_Su_24_0
 L  product_Sl_24_0
 G  product_lx_24_1
 L  product_ux_24_1
 G  product_Su_24_1
 L  product_Sl_24_1
 G  product_lx_24_2
 L  product_ux_24_2
 G  product_Su_24_2
 L  product_Sl_24_2
 G  product_lx_24_3
 L  product_ux_24_3
 G  product_Su_24_3
 L  product_Sl_24_3
 G  product_lx_24_4
 L  product_ux_24_4
 G  product_Su_24_4
 L  product_Sl_24_4
 G  product_lx_24_5
 L  product_ux_24_5
 G  product_Su_24_5
 L  product_Sl_24_5
 G  product_lx_24_6
 L  product_ux_24_6
 G  product_Su_24_6
 L  product_Sl_24_6
 G  product_lx_24_7
 L  product_ux_24_7
 G  product_Su_24_7
 L  product_Sl_24_7
 G  product_lx_24_8
 L  product_ux_24_8
 G  product_Su_24_8
 L  product_Sl_24_8
 G  product_lx_24_9
 L  product_ux_24_9
 G  product_Su_24_9
 L  product_Sl_24_9
 G  product_lx_24_10
 L  product_ux_24_10
 G  product_Su_24_10
 L  product_Sl_24_10
 G  product_lx_24_11
 L  product_ux_24_11
 G  product_Su_24_11
 L  product_Sl_24_11
 G  product_lx_24_12
 L  product_ux_24_12
 G  product_Su_24_12
 L  product_Sl_24_12
 G  product_lx_24_13
 L  product_ux_24_13
 G  product_Su_24_13
 L  product_Sl_24_13
 G  product_lx_24_14
 L  product_ux_24_14
 G  product_Su_24_14
 L  product_Sl_24_14
 G  product_lx_24_15
 L  product_ux_24_15
 G  product_Su_24_15
 L  product_Sl_24_15
 E  onehot_25
 E  inventory_25
 E  ratio_25
 E  product_mass_25
 G  product_lx_25_0
 L  product_ux_25_0
 G  product_Su_25_0
 L  product_Sl_25_0
 G  product_lx_25_1
 L  product_ux_25_1
 G  product_Su_25_1
 L  product_Sl_25_1
 G  product_lx_25_2
 L  product_ux_25_2
 G  product_Su_25_2
 L  product_Sl_25_2
 G  product_lx_25_3
 L  product_ux_25_3
 G  product_Su_25_3
 L  product_Sl_25_3
 G  product_lx_25_4
 L  product_ux_25_4
 G  product_Su_25_4
 L  product_Sl_25_4
 E  onehot_26
 E  inventory_26
 E  ratio_26
 E  product_mass_26
 G  product_lx_26_0
 L  product_ux_26_0
 G  product_Su_26_0
 L  product_Sl_26_0
 G  product_lx_26_1
 L  product_ux_26_1
 G  product_Su_26_1
 L  product_Sl_26_1
 G  product_lx_26_2
 L  product_ux_26_2
 G  product_Su_26_2
 L  product_Sl_26_2
 G  product_lx_26_3
 L  product_ux_26_3
 G  product_Su_26_3
 L  product_Sl_26_3
 G  product_lx_26_4
 L  product_ux_26_4
 G  product_Su_26_4
 L  product_Sl_26_4
 G  product_lx_26_5
 L  product_ux_26_5
 G  product_Su_26_5
 L  product_Sl_26_5
 G  product_lx_26_6
 L  product_ux_26_6
 G  product_Su_26_6
 L  product_Sl_26_6
 G  product_lx_26_7
 L  product_ux_26_7
 G  product_Su_26_7
 L  product_Sl_26_7
 G  product_lx_26_8
 L  product_ux_26_8
 G  product_Su_26_8
 L  product_Sl_26_8
 E  onehot_27
 E  inventory_27
 E  ratio_27
 E  product_mass_27
 G  product_lx_27_0
 L  product_ux_27_0
 G  product_Su_27_0
 L  product_Sl_27_0
 G  product_lx_27_1
 L  product_ux_27_1
 G  product_Su_27_1
 L  product_Sl_27_1
 G  product_lx_27_2
 L  product_ux_27_2
 G  product_Su_27_2
 L  product_Sl_27_2
 G  product_lx_27_3
 L  product_ux_27_3
 G  product_Su_27_3
 L  product_Sl_27_3
 G  product_lx_27_4
 L  product_ux_27_4
 G  product_Su_27_4
 L  product_Sl_27_4
 G  product_lx_27_5
 L  product_ux_27_5
 G  product_Su_27_5
 L  product_Sl_27_5
 G  product_lx_27_6
 L  product_ux_27_6
 G  product_Su_27_6
 L  product_Sl_27_6
 E  onehot_28
 E  inventory_28
 E  ratio_28
 E  product_mass_28
 G  product_lx_28_0
 L  product_ux_28_0
 G  product_Su_28_0
 L  product_Sl_28_0
 G  product_lx_28_1
 L  product_ux_28_1
 G  product_Su_28_1
 L  product_Sl_28_1
 G  product_lx_28_2
 L  product_ux_28_2
 G  product_Su_28_2
 L  product_Sl_28_2
 G  product_lx_28_3
 L  product_ux_28_3
 G  product_Su_28_3
 L  product_Sl_28_3
 G  product_lx_28_4
 L  product_ux_28_4
 G  product_Su_28_4
 L  product_Sl_28_4
 G  product_lx_28_5
 L  product_ux_28_5
 G  product_Su_28_5
 L  product_Sl_28_5
 G  product_lx_28_6
 L  product_ux_28_6
 G  product_Su_28_6
 L  product_Sl_28_6
 E  onehot_29
 E  inventory_29
 E  ratio_29
 E  product_mass_29
 G  product_lx_29_0
 L  product_ux_29_0
 G  product_Su_29_0
 L  product_Sl_29_0
 G  product_lx_29_1
 L  product_ux_29_1
 G  product_Su_29_1
 L  product_Sl_29_1
 G  product_lx_29_2
 L  product_ux_29_2
 G  product_Su_29_2
 L  product_Sl_29_2
 G  product_lx_29_3
 L  product_ux_29_3
 G  product_Su_29_3
 L  product_Sl_29_3
 G  product_lx_29_4
 L  product_ux_29_4
 G  product_Su_29_4
 L  product_Sl_29_4
 G  product_lx_29_5
 L  product_ux_29_5
 G  product_Su_29_5
 L  product_Sl_29_5
 G  product_lx_29_6
 L  product_ux_29_6
 G  product_Su_29_6
 L  product_Sl_29_6
 G  product_lx_29_7
 L  product_ux_29_7
 G  product_Su_29_7
 L  product_Sl_29_7
 G  product_lx_29_8
 L  product_ux_29_8
 G  product_Su_29_8
 L  product_Sl_29_8
 G  product_lx_29_9
 L  product_ux_29_9
 G  product_Su_29_9
 L  product_Sl_29_9
 G  product_lx_29_10
 L  product_ux_29_10
 G  product_Su_29_10
 L  product_Sl_29_10
 E  onehot_30
 E  inventory_30
 E  ratio_30
 E  product_mass_30
 G  product_lx_30_0
 L  product_ux_30_0
 G  product_Su_30_0
 L  product_Sl_30_0
 G  product_lx_30_1
 L  product_ux_30_1
 G  product_Su_30_1
 L  product_Sl_30_1
 G  product_lx_30_2
 L  product_ux_30_2
 G  product_Su_30_2
 L  product_Sl_30_2
 G  product_lx_30_3
 L  product_ux_30_3
 G  product_Su_30_3
 L  product_Sl_30_3
 G  product_lx_30_4
 L  product_ux_30_4
 G  product_Su_30_4
 L  product_Sl_30_4
 G  product_lx_30_5
 L  product_ux_30_5
 G  product_Su_30_5
 L  product_Sl_30_5
 G  product_lx_30_6
 L  product_ux_30_6
 G  product_Su_30_6
 L  product_Sl_30_6
 G  product_lx_30_7
 L  product_ux_30_7
 G  product_Su_30_7
 L  product_Sl_30_7
 G  product_lx_30_8
 L  product_ux_30_8
 G  product_Su_30_8
 L  product_Sl_30_8
 E  onehot_31
 E  inventory_31
 E  ratio_31
 E  product_mass_31
 G  product_lx_31_0
 L  product_ux_31_0
 G  product_Su_31_0
 L  product_Sl_31_0
 G  product_lx_31_1
 L  product_ux_31_1
 G  product_Su_31_1
 L  product_Sl_31_1
 G  product_lx_31_2
 L  product_ux_31_2
 G  product_Su_31_2
 L  product_Sl_31_2
 G  product_lx_31_3
 L  product_ux_31_3
 G  product_Su_31_3
 L  product_Sl_31_3
 G  product_lx_31_4
 L  product_ux_31_4
 G  product_Su_31_4
 L  product_Sl_31_4
 G  product_lx_31_5
 L  product_ux_31_5
 G  product_Su_31_5
 L  product_Sl_31_5
 G  product_lx_31_6
 L  product_ux_31_6
 G  product_Su_31_6
 L  product_Sl_31_6
 G  product_lx_31_7
 L  product_ux_31_7
 G  product_Su_31_7
 L  product_Sl_31_7
 G  product_lx_31_8
 L  product_ux_31_8
 G  product_Su_31_8
 L  product_Sl_31_8
 G  product_lx_31_9
 L  product_ux_31_9
 G  product_Su_31_9
 L  product_Sl_31_9
 G  product_lx_31_10
 L  product_ux_31_10
 G  product_Su_31_10
 L  product_Sl_31_10
 G  product_lx_31_11
 L  product_ux_31_11
 G  product_Su_31_11
 L  product_Sl_31_11
 E  onehot_32
 E  inventory_32
 E  ratio_32
 E  product_mass_32
 G  product_lx_32_0
 L  product_ux_32_0
 G  product_Su_32_0
 L  product_Sl_32_0
 G  product_lx_32_1
 L  product_ux_32_1
 G  product_Su_32_1
 L  product_Sl_32_1
 G  product_lx_32_2
 L  product_ux_32_2
 G  product_Su_32_2
 L  product_Sl_32_2
 G  product_lx_32_3
 L  product_ux_32_3
 G  product_Su_32_3
 L  product_Sl_32_3
 G  product_lx_32_4
 L  product_ux_32_4
 G  product_Su_32_4
 L  product_Sl_32_4
 G  product_lx_32_5
 L  product_ux_32_5
 G  product_Su_32_5
 L  product_Sl_32_5
 G  product_lx_32_6
 L  product_ux_32_6
 G  product_Su_32_6
 L  product_Sl_32_6
 G  product_lx_32_7
 L  product_ux_32_7
 G  product_Su_32_7
 L  product_Sl_32_7
 G  product_lx_32_8
 L  product_ux_32_8
 G  product_Su_32_8
 L  product_Sl_32_8
 G  product_lx_32_9
 L  product_ux_32_9
 G  product_Su_32_9
 L  product_Sl_32_9
 G  product_lx_32_10
 L  product_ux_32_10
 G  product_Su_32_10
 L  product_Sl_32_10
 G  product_lx_32_11
 L  product_ux_32_11
 G  product_Su_32_11
 L  product_Sl_32_11
 G  product_lx_32_12
 L  product_ux_32_12
 G  product_Su_32_12
 L  product_Sl_32_12
 G  product_lx_32_13
 L  product_ux_32_13
 G  product_Su_32_13
 L  product_Sl_32_13
 G  product_lx_32_14
 L  product_ux_32_14
 G  product_Su_32_14
 L  product_Sl_32_14
 G  product_lx_32_15
 L  product_ux_32_15
 G  product_Su_32_15
 L  product_Sl_32_15
 G  product_lx_32_16
 L  product_ux_32_16
 G  product_Su_32_16
 L  product_Sl_32_16
 G  product_lx_32_17
 L  product_ux_32_17
 G  product_Su_32_17
 L  product_Sl_32_17
 G  product_lx_32_18
 L  product_ux_32_18
 G  product_Su_32_18
 L  product_Sl_32_18
 G  product_lx_32_19
 L  product_ux_32_19
 G  product_Su_32_19
 L  product_Sl_32_19
 E  onehot_33
 E  inventory_33
 E  ratio_33
 E  product_mass_33
 G  product_lx_33_0
 L  product_ux_33_0
 G  product_Su_33_0
 L  product_Sl_33_0
 G  product_lx_33_1
 L  product_ux_33_1
 G  product_Su_33_1
 L  product_Sl_33_1
 G  product_lx_33_2
 L  product_ux_33_2
 G  product_Su_33_2
 L  product_Sl_33_2
 G  product_lx_33_3
 L  product_ux_33_3
 G  product_Su_33_3
 L  product_Sl_33_3
 G  product_lx_33_4
 L  product_ux_33_4
 G  product_Su_33_4
 L  product_Sl_33_4
 G  product_lx_33_5
 L  product_ux_33_5
 G  product_Su_33_5
 L  product_Sl_33_5
 G  product_lx_33_6
 L  product_ux_33_6
 G  product_Su_33_6
 L  product_Sl_33_6
 G  product_lx_33_7
 L  product_ux_33_7
 G  product_Su_33_7
 L  product_Sl_33_7
 G  product_lx_33_8
 L  product_ux_33_8
 G  product_Su_33_8
 L  product_Sl_33_8
 G  product_lx_33_9
 L  product_ux_33_9
 G  product_Su_33_9
 L  product_Sl_33_9
 G  product_lx_33_10
 L  product_ux_33_10
 G  product_Su_33_10
 L  product_Sl_33_10
 G  product_lx_33_11
 L  product_ux_33_11
 G  product_Su_33_11
 L  product_Sl_33_11
 E  onehot_34
 E  inventory_34
 E  ratio_34
 E  product_mass_34
 G  product_lx_34_0
 L  product_ux_34_0
 G  product_Su_34_0
 L  product_Sl_34_0
 G  product_lx_34_1
 L  product_ux_34_1
 G  product_Su_34_1
 L  product_Sl_34_1
 G  product_lx_34_2
 L  product_ux_34_2
 G  product_Su_34_2
 L  product_Sl_34_2
 G  product_lx_34_3
 L  product_ux_34_3
 G  product_Su_34_3
 L  product_Sl_34_3
 G  product_lx_34_4
 L  product_ux_34_4
 G  product_Su_34_4
 L  product_Sl_34_4
 G  product_lx_34_5
 L  product_ux_34_5
 G  product_Su_34_5
 L  product_Sl_34_5
 G  product_lx_34_6
 L  product_ux_34_6
 G  product_Su_34_6
 L  product_Sl_34_6
 G  product_lx_34_7
 L  product_ux_34_7
 G  product_Su_34_7
 L  product_Sl_34_7
 G  product_lx_34_8
 L  product_ux_34_8
 G  product_Su_34_8
 L  product_Sl_34_8
 G  product_lx_34_9
 L  product_ux_34_9
 G  product_Su_34_9
 L  product_Sl_34_9
 G  product_lx_34_10
 L  product_ux_34_10
 G  product_Su_34_10
 L  product_Sl_34_10
 G  product_lx_34_11
 L  product_ux_34_11
 G  product_Su_34_11
 L  product_Sl_34_11
 G  product_lx_34_12
 L  product_ux_34_12
 G  product_Su_34_12
 L  product_Sl_34_12
 G  product_lx_34_13
 L  product_ux_34_13
 G  product_Su_34_13
 L  product_Sl_34_13
 G  product_lx_34_14
 L  product_ux_34_14
 G  product_Su_34_14
 L  product_Sl_34_14
 G  product_lx_34_15
 L  product_ux_34_15
 G  product_Su_34_15
 L  product_Sl_34_15
 E  onehot_35
 E  inventory_35
 E  ratio_35
 E  product_mass_35
 G  product_lx_35_0
 L  product_ux_35_0
 G  product_Su_35_0
 L  product_Sl_35_0
 G  product_lx_35_1
 L  product_ux_35_1
 G  product_Su_35_1
 L  product_Sl_35_1
 G  product_lx_35_2
 L  product_ux_35_2
 G  product_Su_35_2
 L  product_Sl_35_2
 G  product_lx_35_3
 L  product_ux_35_3
 G  product_Su_35_3
 L  product_Sl_35_3
 G  product_lx_35_4
 L  product_ux_35_4
 G  product_Su_35_4
 L  product_Sl_35_4
 G  product_lx_35_5
 L  product_ux_35_5
 G  product_Su_35_5
 L  product_Sl_35_5
 G  product_lx_35_6
 L  product_ux_35_6
 G  product_Su_35_6
 L  product_Sl_35_6
 G  product_lx_35_7
 L  product_ux_35_7
 G  product_Su_35_7
 L  product_Sl_35_7
 G  product_lx_35_8
 L  product_ux_35_8
 G  product_Su_35_8
 L  product_Sl_35_8
 G  product_lx_35_9
 L  product_ux_35_9
 G  product_Su_35_9
 L  product_Sl_35_9
 G  product_lx_35_10
 L  product_ux_35_10
 G  product_Su_35_10
 L  product_Sl_35_10
 G  product_lx_35_11
 L  product_ux_35_11
 G  product_Su_35_11
 L  product_Sl_35_11
 G  product_lx_35_12
 L  product_ux_35_12
 G  product_Su_35_12
 L  product_Sl_35_12
 G  product_lx_35_13
 L  product_ux_35_13
 G  product_Su_35_13
 L  product_Sl_35_13
 G  product_lx_35_14
 L  product_ux_35_14
 G  product_Su_35_14
 L  product_Sl_35_14
 G  product_lx_35_15
 L  product_ux_35_15
 G  product_Su_35_15
 L  product_Sl_35_15
 E  denominator
 G  hard_lower
 L  hard_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_1_4
 G  abs_m_1_4
 G  abs_p_1_5
 G  abs_m_1_5
 G  abs_p_1_6
 G  abs_m_1_6
 G  abs_p_1_7
 G  abs_m_1_7
 G  abs_p_1_8
 G  abs_m_1_8
 G  abs_p_1_9
 G  abs_m_1_9
 G  abs_p_1_10
 G  abs_m_1_10
 G  abs_p_1_11
 G  abs_m_1_11
 G  abs_p_1_12
 G  abs_m_1_12
 G  abs_p_1_13
 G  abs_m_1_13
 G  abs_p_1_14
 G  abs_m_1_14
 G  abs_p_1_15
 G  abs_m_1_15
 G  abs_p_1_16
 G  abs_m_1_16
 G  abs_p_1_17
 G  abs_m_1_17
 G  abs_p_1_18
 G  abs_m_1_18
 G  abs_p_1_19
 G  abs_m_1_19
 G  abs_p_1_20
 G  abs_m_1_20
 G  abs_p_1_21
 G  abs_m_1_21
 G  abs_p_1_22
 G  abs_m_1_22
 G  abs_p_1_23
 G  abs_m_1_23
 G  abs_p_1_24
 G  abs_m_1_24
 G  abs_p_1_25
 G  abs_m_1_25
 G  abs_p_1_26
 G  abs_m_1_26
 G  abs_p_1_27
 G  abs_m_1_27
 G  abs_p_1_28
 G  abs_m_1_28
 G  abs_p_1_29
 G  abs_m_1_29
 G  abs_p_1_30
 G  abs_m_1_30
 G  abs_p_1_31
 G  abs_m_1_31
 G  abs_p_1_32
 G  abs_m_1_32
 G  abs_p_1_33
 G  abs_m_1_33
 G  abs_p_1_34
 G  abs_m_1_34
 G  abs_p_1_35
 G  abs_m_1_35
 G  abs_p_2_3
 G  abs_m_2_3
 G  abs_p_2_4
 G  abs_m_2_4
 G  abs_p_2_5
 G  abs_m_2_5
 G  abs_p_2_6
 G  abs_m_2_6
 G  abs_p_2_7
 G  abs_m_2_7
 G  abs_p_2_8
 G  abs_m_2_8
 G  abs_p_2_9
 G  abs_m_2_9
 G  abs_p_2_10
 G  abs_m_2_10
 G  abs_p_2_11
 G  abs_m_2_11
 G  abs_p_2_12
 G  abs_m_2_12
 G  abs_p_2_13
 G  abs_m_2_13
 G  abs_p_2_14
 G  abs_m_2_14
 G  abs_p_2_15
 G  abs_m_2_15
 G  abs_p_2_16
 G  abs_m_2_16
 G  abs_p_2_17
 G  abs_m_2_17
 G  abs_p_2_18
 G  abs_m_2_18
 G  abs_p_2_19
 G  abs_m_2_19
 G  abs_p_2_20
 G  abs_m_2_20
 G  abs_p_2_21
 G  abs_m_2_21
 G  abs_p_2_22
 G  abs_m_2_22
 G  abs_p_2_23
 G  abs_m_2_23
 G  abs_p_2_24
 G  abs_m_2_24
 G  abs_p_2_25
 G  abs_m_2_25
 G  abs_p_2_26
 G  abs_m_2_26
 G  abs_p_2_27
 G  abs_m_2_27
 G  abs_p_2_28
 G  abs_m_2_28
 G  abs_p_2_29
 G  abs_m_2_29
 G  abs_p_2_30
 G  abs_m_2_30
 G  abs_p_2_31
 G  abs_m_2_31
 G  abs_p_2_32
 G  abs_m_2_32
 G  abs_p_2_33
 G  abs_m_2_33
 G  abs_p_2_34
 G  abs_m_2_34
 G  abs_p_2_35
 G  abs_m_2_35
 G  abs_p_3_4
 G  abs_m_3_4
 G  abs_p_3_5
 G  abs_m_3_5
 G  abs_p_3_6
 G  abs_m_3_6
 G  abs_p_3_7
 G  abs_m_3_7
 G  abs_p_3_8
 G  abs_m_3_8
 G  abs_p_3_9
 G  abs_m_3_9
 G  abs_p_3_10
 G  abs_m_3_10
 G  abs_p_3_11
 G  abs_m_3_11
 G  abs_p_3_12
 G  abs_m_3_12
 G  abs_p_3_13
 G  abs_m_3_13
 G  abs_p_3_14
 G  abs_m_3_14
 G  abs_p_3_15
 G  abs_m_3_15
 G  abs_p_3_16
 G  abs_m_3_16
 G  abs_p_3_17
 G  abs_m_3_17
 G  abs_p_3_18
 G  abs_m_3_18
 G  abs_p_3_19
 G  abs_m_3_19
 G  abs_p_3_20
 G  abs_m_3_20
 G  abs_p_3_21
 G  abs_m_3_21
 G  abs_p_3_22
 G  abs_m_3_22
 G  abs_p_3_23
 G  abs_m_3_23
 G  abs_p_3_24
 G  abs_m_3_24
 G  abs_p_3_25
 G  abs_m_3_25
 G  abs_p_3_26
 G  abs_m_3_26
 G  abs_p_3_27
 G  abs_m_3_27
 G  abs_p_3_28
 G  abs_m_3_28
 G  abs_p_3_29
 G  abs_m_3_29
 G  abs_p_3_30
 G  abs_m_3_30
 G  abs_p_3_31
 G  abs_m_3_31
 G  abs_p_3_32
 G  abs_m_3_32
 G  abs_p_3_33
 G  abs_m_3_33
 G  abs_p_3_34
 G  abs_m_3_34
 G  abs_p_3_35
 G  abs_m_3_35
 G  abs_p_4_5
 G  abs_m_4_5
 G  abs_p_4_6
 G  abs_m_4_6
 G  abs_p_4_7
 G  abs_m_4_7
 G  abs_p_4_8
 G  abs_m_4_8
 G  abs_p_4_9
 G  abs_m_4_9
 G  abs_p_4_10
 G  abs_m_4_10
 G  abs_p_4_11
 G  abs_m_4_11
 G  abs_p_4_12
 G  abs_m_4_12
 G  abs_p_4_13
 G  abs_m_4_13
 G  abs_p_4_14
 G  abs_m_4_14
 G  abs_p_4_15
 G  abs_m_4_15
 G  abs_p_4_16
 G  abs_m_4_16
 G  abs_p_4_17
 G  abs_m_4_17
 G  abs_p_4_18
 G  abs_m_4_18
 G  abs_p_4_19
 G  abs_m_4_19
 G  abs_p_4_20
 G  abs_m_4_20
 G  abs_p_4_21
 G  abs_m_4_21
 G  abs_p_4_22
 G  abs_m_4_22
 G  abs_p_4_23
 G  abs_m_4_23
 G  abs_p_4_24
 G  abs_m_4_24
 G  abs_p_4_25
 G  abs_m_4_25
 G  abs_p_4_26
 G  abs_m_4_26
 G  abs_p_4_27
 G  abs_m_4_27
 G  abs_p_4_28
 G  abs_m_4_28
 G  abs_p_4_29
 G  abs_m_4_29
 G  abs_p_4_30
 G  abs_m_4_30
 G  abs_p_4_31
 G  abs_m_4_31
 G  abs_p_4_32
 G  abs_m_4_32
 G  abs_p_4_33
 G  abs_m_4_33
 G  abs_p_4_34
 G  abs_m_4_34
 G  abs_p_4_35
 G  abs_m_4_35
 G  abs_p_5_6
 G  abs_m_5_6
 G  abs_p_5_7
 G  abs_m_5_7
 G  abs_p_5_8
 G  abs_m_5_8
 G  abs_p_5_9
 G  abs_m_5_9
 G  abs_p_5_10
 G  abs_m_5_10
 G  abs_p_5_11
 G  abs_m_5_11
 G  abs_p_5_12
 G  abs_m_5_12
 G  abs_p_5_13
 G  abs_m_5_13
 G  abs_p_5_14
 G  abs_m_5_14
 G  abs_p_5_15
 G  abs_m_5_15
 G  abs_p_5_16
 G  abs_m_5_16
 G  abs_p_5_17
 G  abs_m_5_17
 G  abs_p_5_18
 G  abs_m_5_18
 G  abs_p_5_19
 G  abs_m_5_19
 G  abs_p_5_20
 G  abs_m_5_20
 G  abs_p_5_21
 G  abs_m_5_21
 G  abs_p_5_22
 G  abs_m_5_22
 G  abs_p_5_23
 G  abs_m_5_23
 G  abs_p_5_24
 G  abs_m_5_24
 G  abs_p_5_25
 G  abs_m_5_25
 G  abs_p_5_26
 G  abs_m_5_26
 G  abs_p_5_27
 G  abs_m_5_27
 G  abs_p_5_28
 G  abs_m_5_28
 G  abs_p_5_29
 G  abs_m_5_29
 G  abs_p_5_30
 G  abs_m_5_30
 G  abs_p_5_31
 G  abs_m_5_31
 G  abs_p_5_32
 G  abs_m_5_32
 G  abs_p_5_33
 G  abs_m_5_33
 G  abs_p_5_34
 G  abs_m_5_34
 G  abs_p_5_35
 G  abs_m_5_35
 G  abs_p_6_7
 G  abs_m_6_7
 G  abs_p_6_8
 G  abs_m_6_8
 G  abs_p_6_9
 G  abs_m_6_9
 G  abs_p_6_10
 G  abs_m_6_10
 G  abs_p_6_11
 G  abs_m_6_11
 G  abs_p_6_12
 G  abs_m_6_12
 G  abs_p_6_13
 G  abs_m_6_13
 G  abs_p_6_14
 G  abs_m_6_14
 G  abs_p_6_15
 G  abs_m_6_15
 G  abs_p_6_16
 G  abs_m_6_16
 G  abs_p_6_17
 G  abs_m_6_17
 G  abs_p_6_18
 G  abs_m_6_18
 G  abs_p_6_19
 G  abs_m_6_19
 G  abs_p_6_20
 G  abs_m_6_20
 G  abs_p_6_21
 G  abs_m_6_21
 G  abs_p_6_22
 G  abs_m_6_22
 G  abs_p_6_23
 G  abs_m_6_23
 G  abs_p_6_24
 G  abs_m_6_24
 G  abs_p_6_25
 G  abs_m_6_25
 G  abs_p_6_26
 G  abs_m_6_26
 G  abs_p_6_27
 G  abs_m_6_27
 G  abs_p_6_28
 G  abs_m_6_28
 G  abs_p_6_29
 G  abs_m_6_29
 G  abs_p_6_30
 G  abs_m_6_30
 G  abs_p_6_31
 G  abs_m_6_31
 G  abs_p_6_32
 G  abs_m_6_32
 G  abs_p_6_33
 G  abs_m_6_33
 G  abs_p_6_34
 G  abs_m_6_34
 G  abs_p_6_35
 G  abs_m_6_35
 G  abs_p_7_8
 G  abs_m_7_8
 G  abs_p_7_9
 G  abs_m_7_9
 G  abs_p_7_10
 G  abs_m_7_10
 G  abs_p_7_11
 G  abs_m_7_11
 G  abs_p_7_12
 G  abs_m_7_12
 G  abs_p_7_13
 G  abs_m_7_13
 G  abs_p_7_14
 G  abs_m_7_14
 G  abs_p_7_15
 G  abs_m_7_15
 G  abs_p_7_16
 G  abs_m_7_16
 G  abs_p_7_17
 G  abs_m_7_17
 G  abs_p_7_18
 G  abs_m_7_18
 G  abs_p_7_19
 G  abs_m_7_19
 G  abs_p_7_20
 G  abs_m_7_20
 G  abs_p_7_21
 G  abs_m_7_21
 G  abs_p_7_22
 G  abs_m_7_22
 G  abs_p_7_23
 G  abs_m_7_23
 G  abs_p_7_24
 G  abs_m_7_24
 G  abs_p_7_25
 G  abs_m_7_25
 G  abs_p_7_26
 G  abs_m_7_26
 G  abs_p_7_27
 G  abs_m_7_27
 G  abs_p_7_28
 G  abs_m_7_28
 G  abs_p_7_29
 G  abs_m_7_29
 G  abs_p_7_30
 G  abs_m_7_30
 G  abs_p_7_31
 G  abs_m_7_31
 G  abs_p_7_32
 G  abs_m_7_32
 G  abs_p_7_33
 G  abs_m_7_33
 G  abs_p_7_34
 G  abs_m_7_34
 G  abs_p_7_35
 G  abs_m_7_35
 G  abs_p_8_9
 G  abs_m_8_9
 G  abs_p_8_10
 G  abs_m_8_10
 G  abs_p_8_11
 G  abs_m_8_11
 G  abs_p_8_12
 G  abs_m_8_12
 G  abs_p_8_13
 G  abs_m_8_13
 G  abs_p_8_14
 G  abs_m_8_14
 G  abs_p_8_15
 G  abs_m_8_15
 G  abs_p_8_16
 G  abs_m_8_16
 G  abs_p_8_17
 G  abs_m_8_17
 G  abs_p_8_18
 G  abs_m_8_18
 G  abs_p_8_19
 G  abs_m_8_19
 G  abs_p_8_20
 G  abs_m_8_20
 G  abs_p_8_21
 G  abs_m_8_21
 G  abs_p_8_22
 G  abs_m_8_22
 G  abs_p_8_23
 G  abs_m_8_23
 G  abs_p_8_24
 G  abs_m_8_24
 G  abs_p_8_25
 G  abs_m_8_25
 G  abs_p_8_26
 G  abs_m_8_26
 G  abs_p_8_27
 G  abs_m_8_27
 G  abs_p_8_28
 G  abs_m_8_28
 G  abs_p_8_29
 G  abs_m_8_29
 G  abs_p_8_30
 G  abs_m_8_30
 G  abs_p_8_31
 G  abs_m_8_31
 G  abs_p_8_32
 G  abs_m_8_32
 G  abs_p_8_33
 G  abs_m_8_33
 G  abs_p_8_34
 G  abs_m_8_34
 G  abs_p_8_35
 G  abs_m_8_35
 G  abs_p_9_10
 G  abs_m_9_10
 G  abs_p_9_11
 G  abs_m_9_11
 G  abs_p_9_12
 G  abs_m_9_12
 G  abs_p_9_13
 G  abs_m_9_13
 G  abs_p_9_14
 G  abs_m_9_14
 G  abs_p_9_15
 G  abs_m_9_15
 G  abs_p_9_16
 G  abs_m_9_16
 G  abs_p_9_17
 G  abs_m_9_17
 G  abs_p_9_18
 G  abs_m_9_18
 G  abs_p_9_19
 G  abs_m_9_19
 G  abs_p_9_20
 G  abs_m_9_20
 G  abs_p_9_21
 G  abs_m_9_21
 G  abs_p_9_22
 G  abs_m_9_22
 G  abs_p_9_23
 G  abs_m_9_23
 G  abs_p_9_24
 G  abs_m_9_24
 G  abs_p_9_25
 G  abs_m_9_25
 G  abs_p_9_26
 G  abs_m_9_26
 G  abs_p_9_27
 G  abs_m_9_27
 G  abs_p_9_28
 G  abs_m_9_28
 G  abs_p_9_29
 G  abs_m_9_29
 G  abs_p_9_30
 G  abs_m_9_30
 G  abs_p_9_31
 G  abs_m_9_31
 G  abs_p_9_32
 G  abs_m_9_32
 G  abs_p_9_33
 G  abs_m_9_33
 G  abs_p_9_34
 G  abs_m_9_34
 G  abs_p_9_35
 G  abs_m_9_35
 G  abs_p_10_11
 G  abs_m_10_11
 G  abs_p_10_12
 G  abs_m_10_12
 G  abs_p_10_13
 G  abs_m_10_13
 G  abs_p_10_14
 G  abs_m_10_14
 G  abs_p_10_15
 G  abs_m_10_15
 G  abs_p_10_16
 G  abs_m_10_16
 G  abs_p_10_17
 G  abs_m_10_17
 G  abs_p_10_18
 G  abs_m_10_18
 G  abs_p_10_19
 G  abs_m_10_19
 G  abs_p_10_20
 G  abs_m_10_20
 G  abs_p_10_21
 G  abs_m_10_21
 G  abs_p_10_22
 G  abs_m_10_22
 G  abs_p_10_23
 G  abs_m_10_23
 G  abs_p_10_24
 G  abs_m_10_24
 G  abs_p_10_25
 G  abs_m_10_25
 G  abs_p_10_26
 G  abs_m_10_26
 G  abs_p_10_27
 G  abs_m_10_27
 G  abs_p_10_28
 G  abs_m_10_28
 G  abs_p_10_29
 G  abs_m_10_29
 G  abs_p_10_30
 G  abs_m_10_30
 G  abs_p_10_31
 G  abs_m_10_31
 G  abs_p_10_32
 G  abs_m_10_32
 G  abs_p_10_33
 G  abs_m_10_33
 G  abs_p_10_34
 G  abs_m_10_34
 G  abs_p_10_35
 G  abs_m_10_35
 G  abs_p_11_12
 G  abs_m_11_12
 G  abs_p_11_13
 G  abs_m_11_13
 G  abs_p_11_14
 G  abs_m_11_14
 G  abs_p_11_15
 G  abs_m_11_15
 G  abs_p_11_16
 G  abs_m_11_16
 G  abs_p_11_17
 G  abs_m_11_17
 G  abs_p_11_18
 G  abs_m_11_18
 G  abs_p_11_19
 G  abs_m_11_19
 G  abs_p_11_20
 G  abs_m_11_20
 G  abs_p_11_21
 G  abs_m_11_21
 G  abs_p_11_22
 G  abs_m_11_22
 G  abs_p_11_23
 G  abs_m_11_23
 G  abs_p_11_24
 G  abs_m_11_24
 G  abs_p_11_25
 G  abs_m_11_25
 G  abs_p_11_26
 G  abs_m_11_26
 G  abs_p_11_27
 G  abs_m_11_27
 G  abs_p_11_28
 G  abs_m_11_28
 G  abs_p_11_29
 G  abs_m_11_29
 G  abs_p_11_30
 G  abs_m_11_30
 G  abs_p_11_31
 G  abs_m_11_31
 G  abs_p_11_32
 G  abs_m_11_32
 G  abs_p_11_33
 G  abs_m_11_33
 G  abs_p_11_34
 G  abs_m_11_34
 G  abs_p_11_35
 G  abs_m_11_35
 G  abs_p_12_13
 G  abs_m_12_13
 G  abs_p_12_14
 G  abs_m_12_14
 G  abs_p_12_15
 G  abs_m_12_15
 G  abs_p_12_16
 G  abs_m_12_16
 G  abs_p_12_17
 G  abs_m_12_17
 G  abs_p_12_18
 G  abs_m_12_18
 G  abs_p_12_19
 G  abs_m_12_19
 G  abs_p_12_20
 G  abs_m_12_20
 G  abs_p_12_21
 G  abs_m_12_21
 G  abs_p_12_22
 G  abs_m_12_22
 G  abs_p_12_23
 G  abs_m_12_23
 G  abs_p_12_24
 G  abs_m_12_24
 G  abs_p_12_25
 G  abs_m_12_25
 G  abs_p_12_26
 G  abs_m_12_26
 G  abs_p_12_27
 G  abs_m_12_27
 G  abs_p_12_28
 G  abs_m_12_28
 G  abs_p_12_29
 G  abs_m_12_29
 G  abs_p_12_30
 G  abs_m_12_30
 G  abs_p_12_31
 G  abs_m_12_31
 G  abs_p_12_32
 G  abs_m_12_32
 G  abs_p_12_33
 G  abs_m_12_33
 G  abs_p_12_34
 G  abs_m_12_34
 G  abs_p_12_35
 G  abs_m_12_35
 G  abs_p_13_14
 G  abs_m_13_14
 G  abs_p_13_15
 G  abs_m_13_15
 G  abs_p_13_16
 G  abs_m_13_16
 G  abs_p_13_17
 G  abs_m_13_17
 G  abs_p_13_18
 G  abs_m_13_18
 G  abs_p_13_19
 G  abs_m_13_19
 G  abs_p_13_20
 G  abs_m_13_20
 G  abs_p_13_21
 G  abs_m_13_21
 G  abs_p_13_22
 G  abs_m_13_22
 G  abs_p_13_23
 G  abs_m_13_23
 G  abs_p_13_24
 G  abs_m_13_24
 G  abs_p_13_25
 G  abs_m_13_25
 G  abs_p_13_26
 G  abs_m_13_26
 G  abs_p_13_27
 G  abs_m_13_27
 G  abs_p_13_28
 G  abs_m_13_28
 G  abs_p_13_29
 G  abs_m_13_29
 G  abs_p_13_30
 G  abs_m_13_30
 G  abs_p_13_31
 G  abs_m_13_31
 G  abs_p_13_32
 G  abs_m_13_32
 G  abs_p_13_33
 G  abs_m_13_33
 G  abs_p_13_34
 G  abs_m_13_34
 G  abs_p_13_35
 G  abs_m_13_35
 G  abs_p_14_15
 G  abs_m_14_15
 G  abs_p_14_16
 G  abs_m_14_16
 G  abs_p_14_17
 G  abs_m_14_17
 G  abs_p_14_18
 G  abs_m_14_18
 G  abs_p_14_19
 G  abs_m_14_19
 G  abs_p_14_20
 G  abs_m_14_20
 G  abs_p_14_21
 G  abs_m_14_21
 G  abs_p_14_22
 G  abs_m_14_22
 G  abs_p_14_23
 G  abs_m_14_23
 G  abs_p_14_24
 G  abs_m_14_24
 G  abs_p_14_25
 G  abs_m_14_25
 G  abs_p_14_26
 G  abs_m_14_26
 G  abs_p_14_27
 G  abs_m_14_27
 G  abs_p_14_28
 G  abs_m_14_28
 G  abs_p_14_29
 G  abs_m_14_29
 G  abs_p_14_30
 G  abs_m_14_30
 G  abs_p_14_31
 G  abs_m_14_31
 G  abs_p_14_32
 G  abs_m_14_32
 G  abs_p_14_33
 G  abs_m_14_33
 G  abs_p_14_34
 G  abs_m_14_34
 G  abs_p_14_35
 G  abs_m_14_35
 G  abs_p_15_16
 G  abs_m_15_16
 G  abs_p_15_17
 G  abs_m_15_17
 G  abs_p_15_18
 G  abs_m_15_18
 G  abs_p_15_19
 G  abs_m_15_19
 G  abs_p_15_20
 G  abs_m_15_20
 G  abs_p_15_21
 G  abs_m_15_21
 G  abs_p_15_22
 G  abs_m_15_22
 G  abs_p_15_23
 G  abs_m_15_23
 G  abs_p_15_24
 G  abs_m_15_24
 G  abs_p_15_25
 G  abs_m_15_25
 G  abs_p_15_26
 G  abs_m_15_26
 G  abs_p_15_27
 G  abs_m_15_27
 G  abs_p_15_28
 G  abs_m_15_28
 G  abs_p_15_29
 G  abs_m_15_29
 G  abs_p_15_30
 G  abs_m_15_30
 G  abs_p_15_31
 G  abs_m_15_31
 G  abs_p_15_32
 G  abs_m_15_32
 G  abs_p_15_33
 G  abs_m_15_33
 G  abs_p_15_34
 G  abs_m_15_34
 G  abs_p_15_35
 G  abs_m_15_35
 G  abs_p_16_17
 G  abs_m_16_17
 G  abs_p_16_18
 G  abs_m_16_18
 G  abs_p_16_19
 G  abs_m_16_19
 G  abs_p_16_20
 G  abs_m_16_20
 G  abs_p_16_21
 G  abs_m_16_21
 G  abs_p_16_22
 G  abs_m_16_22
 G  abs_p_16_23
 G  abs_m_16_23
 G  abs_p_16_24
 G  abs_m_16_24
 G  abs_p_16_25
 G  abs_m_16_25
 G  abs_p_16_26
 G  abs_m_16_26
 G  abs_p_16_27
 G  abs_m_16_27
 G  abs_p_16_28
 G  abs_m_16_28
 G  abs_p_16_29
 G  abs_m_16_29
 G  abs_p_16_30
 G  abs_m_16_30
 G  abs_p_16_31
 G  abs_m_16_31
 G  abs_p_16_32
 G  abs_m_16_32
 G  abs_p_16_33
 G  abs_m_16_33
 G  abs_p_16_34
 G  abs_m_16_34
 G  abs_p_16_35
 G  abs_m_16_35
 G  abs_p_17_18
 G  abs_m_17_18
 G  abs_p_17_19
 G  abs_m_17_19
 G  abs_p_17_20
 G  abs_m_17_20
 G  abs_p_17_21
 G  abs_m_17_21
 G  abs_p_17_22
 G  abs_m_17_22
 G  abs_p_17_23
 G  abs_m_17_23
 G  abs_p_17_24
 G  abs_m_17_24
 G  abs_p_17_25
 G  abs_m_17_25
 G  abs_p_17_26
 G  abs_m_17_26
 G  abs_p_17_27
 G  abs_m_17_27
 G  abs_p_17_28
 G  abs_m_17_28
 G  abs_p_17_29
 G  abs_m_17_29
 G  abs_p_17_30
 G  abs_m_17_30
 G  abs_p_17_31
 G  abs_m_17_31
 G  abs_p_17_32
 G  abs_m_17_32
 G  abs_p_17_33
 G  abs_m_17_33
 G  abs_p_17_34
 G  abs_m_17_34
 G  abs_p_17_35
 G  abs_m_17_35
 G  abs_p_18_19
 G  abs_m_18_19
 G  abs_p_18_20
 G  abs_m_18_20
 G  abs_p_18_21
 G  abs_m_18_21
 G  abs_p_18_22
 G  abs_m_18_22
 G  abs_p_18_23
 G  abs_m_18_23
 G  abs_p_18_24
 G  abs_m_18_24
 G  abs_p_18_25
 G  abs_m_18_25
 G  abs_p_18_26
 G  abs_m_18_26
 G  abs_p_18_27
 G  abs_m_18_27
 G  abs_p_18_28
 G  abs_m_18_28
 G  abs_p_18_29
 G  abs_m_18_29
 G  abs_p_18_30
 G  abs_m_18_30
 G  abs_p_18_31
 G  abs_m_18_31
 G  abs_p_18_32
 G  abs_m_18_32
 G  abs_p_18_33
 G  abs_m_18_33
 G  abs_p_18_34
 G  abs_m_18_34
 G  abs_p_18_35
 G  abs_m_18_35
 G  abs_p_19_20
 G  abs_m_19_20
 G  abs_p_19_21
 G  abs_m_19_21
 G  abs_p_19_22
 G  abs_m_19_22
 G  abs_p_19_23
 G  abs_m_19_23
 G  abs_p_19_24
 G  abs_m_19_24
 G  abs_p_19_25
 G  abs_m_19_25
 G  abs_p_19_26
 G  abs_m_19_26
 G  abs_p_19_27
 G  abs_m_19_27
 G  abs_p_19_28
 G  abs_m_19_28
 G  abs_p_19_29
 G  abs_m_19_29
 G  abs_p_19_30
 G  abs_m_19_30
 G  abs_p_19_31
 G  abs_m_19_31
 G  abs_p_19_32
 G  abs_m_19_32
 G  abs_p_19_33
 G  abs_m_19_33
 G  abs_p_19_34
 G  abs_m_19_34
 G  abs_p_19_35
 G  abs_m_19_35
 G  abs_p_20_21
 G  abs_m_20_21
 G  abs_p_20_22
 G  abs_m_20_22
 G  abs_p_20_23
 G  abs_m_20_23
 G  abs_p_20_24
 G  abs_m_20_24
 G  abs_p_20_25
 G  abs_m_20_25
 G  abs_p_20_26
 G  abs_m_20_26
 G  abs_p_20_27
 G  abs_m_20_27
 G  abs_p_20_28
 G  abs_m_20_28
 G  abs_p_20_29
 G  abs_m_20_29
 G  abs_p_20_30
 G  abs_m_20_30
 G  abs_p_20_31
 G  abs_m_20_31
 G  abs_p_20_32
 G  abs_m_20_32
 G  abs_p_20_33
 G  abs_m_20_33
 G  abs_p_20_34
 G  abs_m_20_34
 G  abs_p_20_35
 G  abs_m_20_35
 G  abs_p_21_22
 G  abs_m_21_22
 G  abs_p_21_23
 G  abs_m_21_23
 G  abs_p_21_24
 G  abs_m_21_24
 G  abs_p_21_25
 G  abs_m_21_25
 G  abs_p_21_26
 G  abs_m_21_26
 G  abs_p_21_27
 G  abs_m_21_27
 G  abs_p_21_28
 G  abs_m_21_28
 G  abs_p_21_29
 G  abs_m_21_29
 G  abs_p_21_30
 G  abs_m_21_30
 G  abs_p_21_31
 G  abs_m_21_31
 G  abs_p_21_32
 G  abs_m_21_32
 G  abs_p_21_33
 G  abs_m_21_33
 G  abs_p_21_34
 G  abs_m_21_34
 G  abs_p_21_35
 G  abs_m_21_35
 G  abs_p_22_23
 G  abs_m_22_23
 G  abs_p_22_24
 G  abs_m_22_24
 G  abs_p_22_25
 G  abs_m_22_25
 G  abs_p_22_26
 G  abs_m_22_26
 G  abs_p_22_27
 G  abs_m_22_27
 G  abs_p_22_28
 G  abs_m_22_28
 G  abs_p_22_29
 G  abs_m_22_29
 G  abs_p_22_30
 G  abs_m_22_30
 G  abs_p_22_31
 G  abs_m_22_31
 G  abs_p_22_32
 G  abs_m_22_32
 G  abs_p_22_33
 G  abs_m_22_33
 G  abs_p_22_34
 G  abs_m_22_34
 G  abs_p_22_35
 G  abs_m_22_35
 G  abs_p_23_24
 G  abs_m_23_24
 G  abs_p_23_25
 G  abs_m_23_25
 G  abs_p_23_26
 G  abs_m_23_26
 G  abs_p_23_27
 G  abs_m_23_27
 G  abs_p_23_28
 G  abs_m_23_28
 G  abs_p_23_29
 G  abs_m_23_29
 G  abs_p_23_30
 G  abs_m_23_30
 G  abs_p_23_31
 G  abs_m_23_31
 G  abs_p_23_32
 G  abs_m_23_32
 G  abs_p_23_33
 G  abs_m_23_33
 G  abs_p_23_34
 G  abs_m_23_34
 G  abs_p_23_35
 G  abs_m_23_35
 G  abs_p_24_25
 G  abs_m_24_25
 G  abs_p_24_26
 G  abs_m_24_26
 G  abs_p_24_27
 G  abs_m_24_27
 G  abs_p_24_28
 G  abs_m_24_28
 G  abs_p_24_29
 G  abs_m_24_29
 G  abs_p_24_30
 G  abs_m_24_30
 G  abs_p_24_31
 G  abs_m_24_31
 G  abs_p_24_32
 G  abs_m_24_32
 G  abs_p_24_33
 G  abs_m_24_33
 G  abs_p_24_34
 G  abs_m_24_34
 G  abs_p_24_35
 G  abs_m_24_35
 G  abs_p_25_26
 G  abs_m_25_26
 G  abs_p_25_27
 G  abs_m_25_27
 G  abs_p_25_28
 G  abs_m_25_28
 G  abs_p_25_29
 G  abs_m_25_29
 G  abs_p_25_30
 G  abs_m_25_30
 G  abs_p_25_31
 G  abs_m_25_31
 G  abs_p_25_32
 G  abs_m_25_32
 G  abs_p_25_33
 G  abs_m_25_33
 G  abs_p_25_34
 G  abs_m_25_34
 G  abs_p_25_35
 G  abs_m_25_35
 G  abs_p_26_27
 G  abs_m_26_27
 G  abs_p_26_28
 G  abs_m_26_28
 G  abs_p_26_29
 G  abs_m_26_29
 G  abs_p_26_30
 G  abs_m_26_30
 G  abs_p_26_31
 G  abs_m_26_31
 G  abs_p_26_32
 G  abs_m_26_32
 G  abs_p_26_33
 G  abs_m_26_33
 G  abs_p_26_34
 G  abs_m_26_34
 G  abs_p_26_35
 G  abs_m_26_35
 G  abs_p_27_28
 G  abs_m_27_28
 G  abs_p_27_29
 G  abs_m_27_29
 G  abs_p_27_30
 G  abs_m_27_30
 G  abs_p_27_31
 G  abs_m_27_31
 G  abs_p_27_32
 G  abs_m_27_32
 G  abs_p_27_33
 G  abs_m_27_33
 G  abs_p_27_34
 G  abs_m_27_34
 G  abs_p_27_35
 G  abs_m_27_35
 G  abs_p_28_29
 G  abs_m_28_29
 G  abs_p_28_30
 G  abs_m_28_30
 G  abs_p_28_31
 G  abs_m_28_31
 G  abs_p_28_32
 G  abs_m_28_32
 G  abs_p_28_33
 G  abs_m_28_33
 G  abs_p_28_34
 G  abs_m_28_34
 G  abs_p_28_35
 G  abs_m_28_35
 G  abs_p_29_30
 G  abs_m_29_30
 G  abs_p_29_31
 G  abs_m_29_31
 G  abs_p_29_32
 G  abs_m_29_32
 G  abs_p_29_33
 G  abs_m_29_33
 G  abs_p_29_34
 G  abs_m_29_34
 G  abs_p_29_35
 G  abs_m_29_35
 G  abs_p_30_31
 G  abs_m_30_31
 G  abs_p_30_32
 G  abs_m_30_32
 G  abs_p_30_33
 G  abs_m_30_33
 G  abs_p_30_34
 G  abs_m_30_34
 G  abs_p_30_35
 G  abs_m_30_35
 G  abs_p_31_32
 G  abs_m_31_32
 G  abs_p_31_33
 G  abs_m_31_33
 G  abs_p_31_34
 G  abs_m_31_34
 G  abs_p_31_35
 G  abs_m_31_35
 G  abs_p_32_33
 G  abs_m_32_33
 G  abs_p_32_34
 G  abs_m_32_34
 G  abs_p_32_35
 G  abs_m_32_35
 G  abs_p_33_34
 G  abs_m_33_34
 G  abs_p_33_35
 G  abs_m_33_35
 G  abs_p_34_35
 G  abs_m_34_35
 L  physical_G_upper_outward
 G  total_product_lower
 L  total_product_upper
 G  conditional_Sx_lower_1_0
 L  conditional_Sx_upper_1_0
 G  conditional_complement_lower_1_0
 L  conditional_complement_upper_1_0
 G  conditional_Sx_lower_1_1
 L  conditional_Sx_upper_1_1
 G  conditional_complement_lower_1_1
 L  conditional_complement_upper_1_1
 G  conditional_Sx_lower_1_2
 L  conditional_Sx_upper_1_2
 G  conditional_complement_lower_1_2
 L  conditional_complement_upper_1_2
 G  conditional_Sx_lower_1_3
 L  conditional_Sx_upper_1_3
 G  conditional_complement_lower_1_3
 L  conditional_complement_upper_1_3
 G  conditional_Sx_lower_1_4
 L  conditional_Sx_upper_1_4
 G  conditional_complement_lower_1_4
 L  conditional_complement_upper_1_4
 G  conditional_Sx_lower_1_5
 L  conditional_Sx_upper_1_5
 G  conditional_complement_lower_1_5
 L  conditional_complement_upper_1_5
 G  conditional_Sx_lower_1_6
 L  conditional_Sx_upper_1_6
 G  conditional_complement_lower_1_6
 L  conditional_complement_upper_1_6
 G  conditional_Sx_lower_1_7
 L  conditional_Sx_upper_1_7
 G  conditional_complement_lower_1_7
 L  conditional_complement_upper_1_7
 G  conditional_Sx_lower_1_8
 L  conditional_Sx_upper_1_8
 G  conditional_complement_lower_1_8
 L  conditional_complement_upper_1_8
 G  conditional_Sx_lower_2_0
 L  conditional_Sx_upper_2_0
 G  conditional_complement_lower_2_0
 L  conditional_complement_upper_2_0
 G  conditional_Sx_lower_2_1
 L  conditional_Sx_upper_2_1
 G  conditional_complement_lower_2_1
 L  conditional_complement_upper_2_1
 G  conditional_Sx_lower_2_2
 L  conditional_Sx_upper_2_2
 G  conditional_complement_lower_2_2
 L  conditional_complement_upper_2_2
 G  conditional_Sx_lower_2_3
 L  conditional_Sx_upper_2_3
 G  conditional_complement_lower_2_3
 L  conditional_complement_upper_2_3
 G  conditional_Sx_lower_2_4
 L  conditional_Sx_upper_2_4
 G  conditional_complement_lower_2_4
 L  conditional_complement_upper_2_4
 G  conditional_Sx_lower_2_5
 L  conditional_Sx_upper_2_5
 G  conditional_complement_lower_2_5
 L  conditional_complement_upper_2_5
 G  conditional_Sx_lower_2_6
 L  conditional_Sx_upper_2_6
 G  conditional_complement_lower_2_6
 L  conditional_complement_upper_2_6
 G  conditional_Sx_lower_2_7
 L  conditional_Sx_upper_2_7
 G  conditional_complement_lower_2_7
 L  conditional_complement_upper_2_7
 G  conditional_Sx_lower_2_8
 L  conditional_Sx_upper_2_8
 G  conditional_complement_lower_2_8
 L  conditional_complement_upper_2_8
 G  conditional_Sx_lower_2_9
 L  conditional_Sx_upper_2_9
 G  conditional_complement_lower_2_9
 L  conditional_complement_upper_2_9
 G  conditional_Sx_lower_2_10
 L  conditional_Sx_upper_2_10
 G  conditional_complement_lower_2_10
 L  conditional_complement_upper_2_10
 G  conditional_Sx_lower_2_11
 L  conditional_Sx_upper_2_11
 G  conditional_complement_lower_2_11
 L  conditional_complement_upper_2_11
 G  conditional_Sx_lower_2_12
 L  conditional_Sx_upper_2_12
 G  conditional_complement_lower_2_12
 L  conditional_complement_upper_2_12
 G  conditional_Sx_lower_2_13
 L  conditional_Sx_upper_2_13
 G  conditional_complement_lower_2_13
 L  conditional_complement_upper_2_13
 G  conditional_Sx_lower_2_14
 L  conditional_Sx_upper_2_14
 G  conditional_complement_lower_2_14
 L  conditional_complement_upper_2_14
 G  conditional_Sx_lower_2_15
 L  conditional_Sx_upper_2_15
 G  conditional_complement_lower_2_15
 L  conditional_complement_upper_2_15
 G  conditional_Sx_lower_3_0
 L  conditional_Sx_upper_3_0
 G  conditional_complement_lower_3_0
 L  conditional_complement_upper_3_0
 G  conditional_Sx_lower_3_1
 L  conditional_Sx_upper_3_1
 G  conditional_complement_lower_3_1
 L  conditional_complement_upper_3_1
 G  conditional_Sx_lower_3_2
 L  conditional_Sx_upper_3_2
 G  conditional_complement_lower_3_2
 L  conditional_complement_upper_3_2
 G  conditional_Sx_lower_3_3
 L  conditional_Sx_upper_3_3
 G  conditional_complement_lower_3_3
 L  conditional_complement_upper_3_3
 G  conditional_Sx_lower_3_4
 L  conditional_Sx_upper_3_4
 G  conditional_complement_lower_3_4
 L  conditional_complement_upper_3_4
 G  conditional_Sx_lower_3_5
 L  conditional_Sx_upper_3_5
 G  conditional_complement_lower_3_5
 L  conditional_complement_upper_3_5
 G  conditional_Sx_lower_3_6
 L  conditional_Sx_upper_3_6
 G  conditional_complement_lower_3_6
 L  conditional_complement_upper_3_6
 G  conditional_Sx_lower_3_7
 L  conditional_Sx_upper_3_7
 G  conditional_complement_lower_3_7
 L  conditional_complement_upper_3_7
 G  conditional_Sx_lower_3_8
 L  conditional_Sx_upper_3_8
 G  conditional_complement_lower_3_8
 L  conditional_complement_upper_3_8
 G  conditional_Sx_lower_3_9
 L  conditional_Sx_upper_3_9
 G  conditional_complement_lower_3_9
 L  conditional_complement_upper_3_9
 G  conditional_Sx_lower_3_10
 L  conditional_Sx_upper_3_10
 G  conditional_complement_lower_3_10
 L  conditional_complement_upper_3_10
 G  conditional_Sx_lower_3_11
 L  conditional_Sx_upper_3_11
 G  conditional_complement_lower_3_11
 L  conditional_complement_upper_3_11
 G  conditional_Sx_lower_3_12
 L  conditional_Sx_upper_3_12
 G  conditional_complement_lower_3_12
 L  conditional_complement_upper_3_12
 G  conditional_Sx_lower_4_0
 L  conditional_Sx_upper_4_0
 G  conditional_complement_lower_4_0
 L  conditional_complement_upper_4_0
 G  conditional_Sx_lower_4_1
 L  conditional_Sx_upper_4_1
 G  conditional_complement_lower_4_1
 L  conditional_complement_upper_4_1
 G  conditional_Sx_lower_4_2
 L  conditional_Sx_upper_4_2
 G  conditional_complement_lower_4_2
 L  conditional_complement_upper_4_2
 G  conditional_Sx_lower_4_3
 L  conditional_Sx_upper_4_3
 G  conditional_complement_lower_4_3
 L  conditional_complement_upper_4_3
 G  conditional_Sx_lower_4_4
 L  conditional_Sx_upper_4_4
 G  conditional_complement_lower_4_4
 L  conditional_complement_upper_4_4
 G  conditional_Sx_lower_4_5
 L  conditional_Sx_upper_4_5
 G  conditional_complement_lower_4_5
 L  conditional_complement_upper_4_5
 G  conditional_Sx_lower_4_6
 L  conditional_Sx_upper_4_6
 G  conditional_complement_lower_4_6
 L  conditional_complement_upper_4_6
 G  conditional_Sx_lower_4_7
 L  conditional_Sx_upper_4_7
 G  conditional_complement_lower_4_7
 L  conditional_complement_upper_4_7
 G  conditional_Sx_lower_4_8
 L  conditional_Sx_upper_4_8
 G  conditional_complement_lower_4_8
 L  conditional_complement_upper_4_8
 G  conditional_Sx_lower_4_9
 L  conditional_Sx_upper_4_9
 G  conditional_complement_lower_4_9
 L  conditional_complement_upper_4_9
 G  conditional_Sx_lower_4_10
 L  conditional_Sx_upper_4_10
 G  conditional_complement_lower_4_10
 L  conditional_complement_upper_4_10
 G  conditional_Sx_lower_4_11
 L  conditional_Sx_upper_4_11
 G  conditional_complement_lower_4_11
 L  conditional_complement_upper_4_11
 G  conditional_Sx_lower_4_12
 L  conditional_Sx_upper_4_12
 G  conditional_complement_lower_4_12
 L  conditional_complement_upper_4_12
 G  conditional_Sx_lower_4_13
 L  conditional_Sx_upper_4_13
 G  conditional_complement_lower_4_13
 L  conditional_complement_upper_4_13
 G  conditional_Sx_lower_4_14
 L  conditional_Sx_upper_4_14
 G  conditional_complement_lower_4_14
 L  conditional_complement_upper_4_14
 G  conditional_Sx_lower_4_15
 L  conditional_Sx_upper_4_15
 G  conditional_complement_lower_4_15
 L  conditional_complement_upper_4_15
 G  conditional_Sx_lower_5_0
 L  conditional_Sx_upper_5_0
 G  conditional_complement_lower_5_0
 L  conditional_complement_upper_5_0
 G  conditional_Sx_lower_5_1
 L  conditional_Sx_upper_5_1
 G  conditional_complement_lower_5_1
 L  conditional_complement_upper_5_1
 G  conditional_Sx_lower_5_2
 L  conditional_Sx_upper_5_2
 G  conditional_complement_lower_5_2
 L  conditional_complement_upper_5_2
 G  conditional_Sx_lower_5_3
 L  conditional_Sx_upper_5_3
 G  conditional_complement_lower_5_3
 L  conditional_complement_upper_5_3
 G  conditional_Sx_lower_5_4
 L  conditional_Sx_upper_5_4
 G  conditional_complement_lower_5_4
 L  conditional_complement_upper_5_4
 G  conditional_Sx_lower_5_5
 L  conditional_Sx_upper_5_5
 G  conditional_complement_lower_5_5
 L  conditional_complement_upper_5_5
 G  conditional_Sx_lower_5_6
 L  conditional_Sx_upper_5_6
 G  conditional_complement_lower_5_6
 L  conditional_complement_upper_5_6
 G  conditional_Sx_lower_5_7
 L  conditional_Sx_upper_5_7
 G  conditional_complement_lower_5_7
 L  conditional_complement_upper_5_7
 G  conditional_Sx_lower_5_8
 L  conditional_Sx_upper_5_8
 G  conditional_complement_lower_5_8
 L  conditional_complement_upper_5_8
 G  conditional_Sx_lower_5_9
 L  conditional_Sx_upper_5_9
 G  conditional_complement_lower_5_9
 L  conditional_complement_upper_5_9
 G  conditional_Sx_lower_5_10
 L  conditional_Sx_upper_5_10
 G  conditional_complement_lower_5_10
 L  conditional_complement_upper_5_10
 G  conditional_Sx_lower_5_11
 L  conditional_Sx_upper_5_11
 G  conditional_complement_lower_5_11
 L  conditional_complement_upper_5_11
 G  conditional_Sx_lower_5_12
 L  conditional_Sx_upper_5_12
 G  conditional_complement_lower_5_12
 L  conditional_complement_upper_5_12
 G  conditional_Sx_lower_5_13
 L  conditional_Sx_upper_5_13
 G  conditional_complement_lower_5_13
 L  conditional_complement_upper_5_13
 G  conditional_Sx_lower_5_14
 L  conditional_Sx_upper_5_14
 G  conditional_complement_lower_5_14
 L  conditional_complement_upper_5_14
 G  conditional_Sx_lower_5_15
 L  conditional_Sx_upper_5_15
 G  conditional_complement_lower_5_15
 L  conditional_complement_upper_5_15
 G  conditional_Sx_lower_6_0
 L  conditional_Sx_upper_6_0
 G  conditional_complement_lower_6_0
 L  conditional_complement_upper_6_0
 G  conditional_Sx_lower_6_1
 L  conditional_Sx_upper_6_1
 G  conditional_complement_lower_6_1
 L  conditional_complement_upper_6_1
 G  conditional_Sx_lower_6_2
 L  conditional_Sx_upper_6_2
 G  conditional_complement_lower_6_2
 L  conditional_complement_upper_6_2
 G  conditional_Sx_lower_6_3
 L  conditional_Sx_upper_6_3
 G  conditional_complement_lower_6_3
 L  conditional_complement_upper_6_3
 G  conditional_Sx_lower_6_4
 L  conditional_Sx_upper_6_4
 G  conditional_complement_lower_6_4
 L  conditional_complement_upper_6_4
 G  conditional_Sx_lower_6_5
 L  conditional_Sx_upper_6_5
 G  conditional_complement_lower_6_5
 L  conditional_complement_upper_6_5
 G  conditional_Sx_lower_6_6
 L  conditional_Sx_upper_6_6
 G  conditional_complement_lower_6_6
 L  conditional_complement_upper_6_6
 G  conditional_Sx_lower_6_7
 L  conditional_Sx_upper_6_7
 G  conditional_complement_lower_6_7
 L  conditional_complement_upper_6_7
 G  conditional_Sx_lower_6_8
 L  conditional_Sx_upper_6_8
 G  conditional_complement_lower_6_8
 L  conditional_complement_upper_6_8
 G  conditional_Sx_lower_7_0
 L  conditional_Sx_upper_7_0
 G  conditional_complement_lower_7_0
 L  conditional_complement_upper_7_0
 G  conditional_Sx_lower_7_1
 L  conditional_Sx_upper_7_1
 G  conditional_complement_lower_7_1
 L  conditional_complement_upper_7_1
 G  conditional_Sx_lower_7_2
 L  conditional_Sx_upper_7_2
 G  conditional_complement_lower_7_2
 L  conditional_complement_upper_7_2
 G  conditional_Sx_lower_7_3
 L  conditional_Sx_upper_7_3
 G  conditional_complement_lower_7_3
 L  conditional_complement_upper_7_3
 G  conditional_Sx_lower_7_4
 L  conditional_Sx_upper_7_4
 G  conditional_complement_lower_7_4
 L  conditional_complement_upper_7_4
 G  conditional_Sx_lower_7_5
 L  conditional_Sx_upper_7_5
 G  conditional_complement_lower_7_5
 L  conditional_complement_upper_7_5
 G  conditional_Sx_lower_7_6
 L  conditional_Sx_upper_7_6
 G  conditional_complement_lower_7_6
 L  conditional_complement_upper_7_6
 G  conditional_Sx_lower_7_7
 L  conditional_Sx_upper_7_7
 G  conditional_complement_lower_7_7
 L  conditional_complement_upper_7_7
 G  conditional_Sx_lower_7_8
 L  conditional_Sx_upper_7_8
 G  conditional_complement_lower_7_8
 L  conditional_complement_upper_7_8
 G  conditional_Sx_lower_7_9
 L  conditional_Sx_upper_7_9
 G  conditional_complement_lower_7_9
 L  conditional_complement_upper_7_9
 G  conditional_Sx_lower_7_10
 L  conditional_Sx_upper_7_10
 G  conditional_complement_lower_7_10
 L  conditional_complement_upper_7_10
 G  conditional_Sx_lower_7_11
 L  conditional_Sx_upper_7_11
 G  conditional_complement_lower_7_11
 L  conditional_complement_upper_7_11
 G  conditional_Sx_lower_7_12
 L  conditional_Sx_upper_7_12
 G  conditional_complement_lower_7_12
 L  conditional_complement_upper_7_12
 G  conditional_Sx_lower_7_13
 L  conditional_Sx_upper_7_13
 G  conditional_complement_lower_7_13
 L  conditional_complement_upper_7_13
 G  conditional_Sx_lower_7_14
 L  conditional_Sx_upper_7_14
 G  conditional_complement_lower_7_14
 L  conditional_complement_upper_7_14
 G  conditional_Sx_lower_7_15
 L  conditional_Sx_upper_7_15
 G  conditional_complement_lower_7_15
 L  conditional_complement_upper_7_15
 G  conditional_Sx_lower_8_0
 L  conditional_Sx_upper_8_0
 G  conditional_complement_lower_8_0
 L  conditional_complement_upper_8_0
 G  conditional_Sx_lower_8_1
 L  conditional_Sx_upper_8_1
 G  conditional_complement_lower_8_1
 L  conditional_complement_upper_8_1
 G  conditional_Sx_lower_8_2
 L  conditional_Sx_upper_8_2
 G  conditional_complement_lower_8_2
 L  conditional_complement_upper_8_2
 G  conditional_Sx_lower_8_3
 L  conditional_Sx_upper_8_3
 G  conditional_complement_lower_8_3
 L  conditional_complement_upper_8_3
 G  conditional_Sx_lower_8_4
 L  conditional_Sx_upper_8_4
 G  conditional_complement_lower_8_4
 L  conditional_complement_upper_8_4
 G  conditional_Sx_lower_8_5
 L  conditional_Sx_upper_8_5
 G  conditional_complement_lower_8_5
 L  conditional_complement_upper_8_5
 G  conditional_Sx_lower_8_6
 L  conditional_Sx_upper_8_6
 G  conditional_complement_lower_8_6
 L  conditional_complement_upper_8_6
 G  conditional_Sx_lower_8_7
 L  conditional_Sx_upper_8_7
 G  conditional_complement_lower_8_7
 L  conditional_complement_upper_8_7
 G  conditional_Sx_lower_8_8
 L  conditional_Sx_upper_8_8
 G  conditional_complement_lower_8_8
 L  conditional_complement_upper_8_8
 G  conditional_Sx_lower_8_9
 L  conditional_Sx_upper_8_9
 G  conditional_complement_lower_8_9
 L  conditional_complement_upper_8_9
 G  conditional_Sx_lower_8_10
 L  conditional_Sx_upper_8_10
 G  conditional_complement_lower_8_10
 L  conditional_complement_upper_8_10
 G  conditional_Sx_lower_8_11
 L  conditional_Sx_upper_8_11
 G  conditional_complement_lower_8_11
 L  conditional_complement_upper_8_11
 G  conditional_Sx_lower_8_12
 L  conditional_Sx_upper_8_12
 G  conditional_complement_lower_8_12
 L  conditional_complement_upper_8_12
 G  conditional_Sx_lower_9_0
 L  conditional_Sx_upper_9_0
 G  conditional_complement_lower_9_0
 L  conditional_complement_upper_9_0
 G  conditional_Sx_lower_9_1
 L  conditional_Sx_upper_9_1
 G  conditional_complement_lower_9_1
 L  conditional_complement_upper_9_1
 G  conditional_Sx_lower_9_2
 L  conditional_Sx_upper_9_2
 G  conditional_complement_lower_9_2
 L  conditional_complement_upper_9_2
 G  conditional_Sx_lower_9_3
 L  conditional_Sx_upper_9_3
 G  conditional_complement_lower_9_3
 L  conditional_complement_upper_9_3
 G  conditional_Sx_lower_9_4
 L  conditional_Sx_upper_9_4
 G  conditional_complement_lower_9_4
 L  conditional_complement_upper_9_4
 G  conditional_Sx_lower_9_5
 L  conditional_Sx_upper_9_5
 G  conditional_complement_lower_9_5
 L  conditional_complement_upper_9_5
 G  conditional_Sx_lower_9_6
 L  conditional_Sx_upper_9_6
 G  conditional_complement_lower_9_6
 L  conditional_complement_upper_9_6
 G  conditional_Sx_lower_9_7
 L  conditional_Sx_upper_9_7
 G  conditional_complement_lower_9_7
 L  conditional_complement_upper_9_7
 G  conditional_Sx_lower_9_8
 L  conditional_Sx_upper_9_8
 G  conditional_complement_lower_9_8
 L  conditional_complement_upper_9_8
 G  conditional_Sx_lower_9_9
 L  conditional_Sx_upper_9_9
 G  conditional_complement_lower_9_9
 L  conditional_complement_upper_9_9
 G  conditional_Sx_lower_9_10
 L  conditional_Sx_upper_9_10
 G  conditional_complement_lower_9_10
 L  conditional_complement_upper_9_10
 G  conditional_Sx_lower_10_0
 L  conditional_Sx_upper_10_0
 G  conditional_complement_lower_10_0
 L  conditional_complement_upper_10_0
 G  conditional_Sx_lower_10_1
 L  conditional_Sx_upper_10_1
 G  conditional_complement_lower_10_1
 L  conditional_complement_upper_10_1
 G  conditional_Sx_lower_10_2
 L  conditional_Sx_upper_10_2
 G  conditional_complement_lower_10_2
 L  conditional_complement_upper_10_2
 G  conditional_Sx_lower_10_3
 L  conditional_Sx_upper_10_3
 G  conditional_complement_lower_10_3
 L  conditional_complement_upper_10_3
 G  conditional_Sx_lower_10_4
 L  conditional_Sx_upper_10_4
 G  conditional_complement_lower_10_4
 L  conditional_complement_upper_10_4
 G  conditional_Sx_lower_10_5
 L  conditional_Sx_upper_10_5
 G  conditional_complement_lower_10_5
 L  conditional_complement_upper_10_5
 G  conditional_Sx_lower_10_6
 L  conditional_Sx_upper_10_6
 G  conditional_complement_lower_10_6
 L  conditional_complement_upper_10_6
 G  conditional_Sx_lower_11_0
 L  conditional_Sx_upper_11_0
 G  conditional_complement_lower_11_0
 L  conditional_complement_upper_11_0
 G  conditional_Sx_lower_11_1
 L  conditional_Sx_upper_11_1
 G  conditional_complement_lower_11_1
 L  conditional_complement_upper_11_1
 G  conditional_Sx_lower_11_2
 L  conditional_Sx_upper_11_2
 G  conditional_complement_lower_11_2
 L  conditional_complement_upper_11_2
 G  conditional_Sx_lower_11_3
 L  conditional_Sx_upper_11_3
 G  conditional_complement_lower_11_3
 L  conditional_complement_upper_11_3
 G  conditional_Sx_lower_11_4
 L  conditional_Sx_upper_11_4
 G  conditional_complement_lower_11_4
 L  conditional_complement_upper_11_4
 G  conditional_Sx_lower_11_5
 L  conditional_Sx_upper_11_5
 G  conditional_complement_lower_11_5
 L  conditional_complement_upper_11_5
 G  conditional_Sx_lower_11_6
 L  conditional_Sx_upper_11_6
 G  conditional_complement_lower_11_6
 L  conditional_complement_upper_11_6
 G  conditional_Sx_lower_11_7
 L  conditional_Sx_upper_11_7
 G  conditional_complement_lower_11_7
 L  conditional_complement_upper_11_7
 G  conditional_Sx_lower_11_8
 L  conditional_Sx_upper_11_8
 G  conditional_complement_lower_11_8
 L  conditional_complement_upper_11_8
 G  conditional_Sx_lower_11_9
 L  conditional_Sx_upper_11_9
 G  conditional_complement_lower_11_9
 L  conditional_complement_upper_11_9
 G  conditional_Sx_lower_11_10
 L  conditional_Sx_upper_11_10
 G  conditional_complement_lower_11_10
 L  conditional_complement_upper_11_10
 G  conditional_Sx_lower_12_0
 L  conditional_Sx_upper_12_0
 G  conditional_complement_lower_12_0
 L  conditional_complement_upper_12_0
 G  conditional_Sx_lower_12_1
 L  conditional_Sx_upper_12_1
 G  conditional_complement_lower_12_1
 L  conditional_complement_upper_12_1
 G  conditional_Sx_lower_12_2
 L  conditional_Sx_upper_12_2
 G  conditional_complement_lower_12_2
 L  conditional_complement_upper_12_2
 G  conditional_Sx_lower_12_3
 L  conditional_Sx_upper_12_3
 G  conditional_complement_lower_12_3
 L  conditional_complement_upper_12_3
 G  conditional_Sx_lower_12_4
 L  conditional_Sx_upper_12_4
 G  conditional_complement_lower_12_4
 L  conditional_complement_upper_12_4
 G  conditional_Sx_lower_12_5
 L  conditional_Sx_upper_12_5
 G  conditional_complement_lower_12_5
 L  conditional_complement_upper_12_5
 G  conditional_Sx_lower_12_6
 L  conditional_Sx_upper_12_6
 G  conditional_complement_lower_12_6
 L  conditional_complement_upper_12_6
 G  conditional_Sx_lower_12_7
 L  conditional_Sx_upper_12_7
 G  conditional_complement_lower_12_7
 L  conditional_complement_upper_12_7
 G  conditional_Sx_lower_12_8
 L  conditional_Sx_upper_12_8
 G  conditional_complement_lower_12_8
 L  conditional_complement_upper_12_8
 G  conditional_Sx_lower_12_9
 L  conditional_Sx_upper_12_9
 G  conditional_complement_lower_12_9
 L  conditional_complement_upper_12_9
 G  conditional_Sx_lower_12_10
 L  conditional_Sx_upper_12_10
 G  conditional_complement_lower_12_10
 L  conditional_complement_upper_12_10
 G  conditional_Sx_lower_12_11
 L  conditional_Sx_upper_12_11
 G  conditional_complement_lower_12_11
 L  conditional_complement_upper_12_11
 G  conditional_Sx_lower_12_12
 L  conditional_Sx_upper_12_12
 G  conditional_complement_lower_12_12
 L  conditional_complement_upper_12_12
 G  conditional_Sx_lower_13_0
 L  conditional_Sx_upper_13_0
 G  conditional_complement_lower_13_0
 L  conditional_complement_upper_13_0
 G  conditional_Sx_lower_13_1
 L  conditional_Sx_upper_13_1
 G  conditional_complement_lower_13_1
 L  conditional_complement_upper_13_1
 G  conditional_Sx_lower_13_2
 L  conditional_Sx_upper_13_2
 G  conditional_complement_lower_13_2
 L  conditional_complement_upper_13_2
 G  conditional_Sx_lower_13_3
 L  conditional_Sx_upper_13_3
 G  conditional_complement_lower_13_3
 L  conditional_complement_upper_13_3
 G  conditional_Sx_lower_13_4
 L  conditional_Sx_upper_13_4
 G  conditional_complement_lower_13_4
 L  conditional_complement_upper_13_4
 G  conditional_Sx_lower_13_5
 L  conditional_Sx_upper_13_5
 G  conditional_complement_lower_13_5
 L  conditional_complement_upper_13_5
 G  conditional_Sx_lower_13_6
 L  conditional_Sx_upper_13_6
 G  conditional_complement_lower_13_6
 L  conditional_complement_upper_13_6
 G  conditional_Sx_lower_13_7
 L  conditional_Sx_upper_13_7
 G  conditional_complement_lower_13_7
 L  conditional_complement_upper_13_7
 G  conditional_Sx_lower_13_8
 L  conditional_Sx_upper_13_8
 G  conditional_complement_lower_13_8
 L  conditional_complement_upper_13_8
 G  conditional_Sx_lower_14_0
 L  conditional_Sx_upper_14_0
 G  conditional_complement_lower_14_0
 L  conditional_complement_upper_14_0
 G  conditional_Sx_lower_14_1
 L  conditional_Sx_upper_14_1
 G  conditional_complement_lower_14_1
 L  conditional_complement_upper_14_1
 G  conditional_Sx_lower_14_2
 L  conditional_Sx_upper_14_2
 G  conditional_complement_lower_14_2
 L  conditional_complement_upper_14_2
 G  conditional_Sx_lower_14_3
 L  conditional_Sx_upper_14_3
 G  conditional_complement_lower_14_3
 L  conditional_complement_upper_14_3
 G  conditional_Sx_lower_14_4
 L  conditional_Sx_upper_14_4
 G  conditional_complement_lower_14_4
 L  conditional_complement_upper_14_4
 G  conditional_Sx_lower_14_5
 L  conditional_Sx_upper_14_5
 G  conditional_complement_lower_14_5
 L  conditional_complement_upper_14_5
 G  conditional_Sx_lower_14_6
 L  conditional_Sx_upper_14_6
 G  conditional_complement_lower_14_6
 L  conditional_complement_upper_14_6
 G  conditional_Sx_lower_14_7
 L  conditional_Sx_upper_14_7
 G  conditional_complement_lower_14_7
 L  conditional_complement_upper_14_7
 G  conditional_Sx_lower_14_8
 L  conditional_Sx_upper_14_8
 G  conditional_complement_lower_14_8
 L  conditional_complement_upper_14_8
 G  conditional_Sx_lower_15_0
 L  conditional_Sx_upper_15_0
 G  conditional_complement_lower_15_0
 L  conditional_complement_upper_15_0
 G  conditional_Sx_lower_15_1
 L  conditional_Sx_upper_15_1
 G  conditional_complement_lower_15_1
 L  conditional_complement_upper_15_1
 G  conditional_Sx_lower_15_2
 L  conditional_Sx_upper_15_2
 G  conditional_complement_lower_15_2
 L  conditional_complement_upper_15_2
 G  conditional_Sx_lower_15_3
 L  conditional_Sx_upper_15_3
 G  conditional_complement_lower_15_3
 L  conditional_complement_upper_15_3
 G  conditional_Sx_lower_15_4
 L  conditional_Sx_upper_15_4
 G  conditional_complement_lower_15_4
 L  conditional_complement_upper_15_4
 G  conditional_Sx_lower_15_5
 L  conditional_Sx_upper_15_5
 G  conditional_complement_lower_15_5
 L  conditional_complement_upper_15_5
 G  conditional_Sx_lower_15_6
 L  conditional_Sx_upper_15_6
 G  conditional_complement_lower_15_6
 L  conditional_complement_upper_15_6
 G  conditional_Sx_lower_15_7
 L  conditional_Sx_upper_15_7
 G  conditional_complement_lower_15_7
 L  conditional_complement_upper_15_7
 G  conditional_Sx_lower_15_8
 L  conditional_Sx_upper_15_8
 G  conditional_complement_lower_15_8
 L  conditional_complement_upper_15_8
 G  conditional_Sx_lower_16_0
 L  conditional_Sx_upper_16_0
 G  conditional_complement_lower_16_0
 L  conditional_complement_upper_16_0
 G  conditional_Sx_lower_16_1
 L  conditional_Sx_upper_16_1
 G  conditional_complement_lower_16_1
 L  conditional_complement_upper_16_1
 G  conditional_Sx_lower_16_2
 L  conditional_Sx_upper_16_2
 G  conditional_complement_lower_16_2
 L  conditional_complement_upper_16_2
 G  conditional_Sx_lower_16_3
 L  conditional_Sx_upper_16_3
 G  conditional_complement_lower_16_3
 L  conditional_complement_upper_16_3
 G  conditional_Sx_lower_16_4
 L  conditional_Sx_upper_16_4
 G  conditional_complement_lower_16_4
 L  conditional_complement_upper_16_4
 G  conditional_Sx_lower_16_5
 L  conditional_Sx_upper_16_5
 G  conditional_complement_lower_16_5
 L  conditional_complement_upper_16_5
 G  conditional_Sx_lower_16_6
 L  conditional_Sx_upper_16_6
 G  conditional_complement_lower_16_6
 L  conditional_complement_upper_16_6
 G  conditional_Sx_lower_16_7
 L  conditional_Sx_upper_16_7
 G  conditional_complement_lower_16_7
 L  conditional_complement_upper_16_7
 G  conditional_Sx_lower_16_8
 L  conditional_Sx_upper_16_8
 G  conditional_complement_lower_16_8
 L  conditional_complement_upper_16_8
 G  conditional_Sx_lower_16_9
 L  conditional_Sx_upper_16_9
 G  conditional_complement_lower_16_9
 L  conditional_complement_upper_16_9
 G  conditional_Sx_lower_16_10
 L  conditional_Sx_upper_16_10
 G  conditional_complement_lower_16_10
 L  conditional_complement_upper_16_10
 G  conditional_Sx_lower_16_11
 L  conditional_Sx_upper_16_11
 G  conditional_complement_lower_16_11
 L  conditional_complement_upper_16_11
 G  conditional_Sx_lower_16_12
 L  conditional_Sx_upper_16_12
 G  conditional_complement_lower_16_12
 L  conditional_complement_upper_16_12
 G  conditional_Sx_lower_16_13
 L  conditional_Sx_upper_16_13
 G  conditional_complement_lower_16_13
 L  conditional_complement_upper_16_13
 G  conditional_Sx_lower_16_14
 L  conditional_Sx_upper_16_14
 G  conditional_complement_lower_16_14
 L  conditional_complement_upper_16_14
 G  conditional_Sx_lower_16_15
 L  conditional_Sx_upper_16_15
 G  conditional_complement_lower_16_15
 L  conditional_complement_upper_16_15
 G  conditional_Sx_lower_17_0
 L  conditional_Sx_upper_17_0
 G  conditional_complement_lower_17_0
 L  conditional_complement_upper_17_0
 G  conditional_Sx_lower_17_1
 L  conditional_Sx_upper_17_1
 G  conditional_complement_lower_17_1
 L  conditional_complement_upper_17_1
 G  conditional_Sx_lower_17_2
 L  conditional_Sx_upper_17_2
 G  conditional_complement_lower_17_2
 L  conditional_complement_upper_17_2
 G  conditional_Sx_lower_17_3
 L  conditional_Sx_upper_17_3
 G  conditional_complement_lower_17_3
 L  conditional_complement_upper_17_3
 G  conditional_Sx_lower_17_4
 L  conditional_Sx_upper_17_4
 G  conditional_complement_lower_17_4
 L  conditional_complement_upper_17_4
 G  conditional_Sx_lower_17_5
 L  conditional_Sx_upper_17_5
 G  conditional_complement_lower_17_5
 L  conditional_complement_upper_17_5
 G  conditional_Sx_lower_17_6
 L  conditional_Sx_upper_17_6
 G  conditional_complement_lower_17_6
 L  conditional_complement_upper_17_6
 G  conditional_Sx_lower_18_0
 L  conditional_Sx_upper_18_0
 G  conditional_complement_lower_18_0
 L  conditional_complement_upper_18_0
 G  conditional_Sx_lower_18_1
 L  conditional_Sx_upper_18_1
 G  conditional_complement_lower_18_1
 L  conditional_complement_upper_18_1
 G  conditional_Sx_lower_18_2
 L  conditional_Sx_upper_18_2
 G  conditional_complement_lower_18_2
 L  conditional_complement_upper_18_2
 G  conditional_Sx_lower_18_3
 L  conditional_Sx_upper_18_3
 G  conditional_complement_lower_18_3
 L  conditional_complement_upper_18_3
 G  conditional_Sx_lower_18_4
 L  conditional_Sx_upper_18_4
 G  conditional_complement_lower_18_4
 L  conditional_complement_upper_18_4
 G  conditional_Sx_lower_18_5
 L  conditional_Sx_upper_18_5
 G  conditional_complement_lower_18_5
 L  conditional_complement_upper_18_5
 G  conditional_Sx_lower_18_6
 L  conditional_Sx_upper_18_6
 G  conditional_complement_lower_18_6
 L  conditional_complement_upper_18_6
 G  conditional_Sx_lower_18_7
 L  conditional_Sx_upper_18_7
 G  conditional_complement_lower_18_7
 L  conditional_complement_upper_18_7
 G  conditional_Sx_lower_18_8
 L  conditional_Sx_upper_18_8
 G  conditional_complement_lower_18_8
 L  conditional_complement_upper_18_8
 G  conditional_Sx_lower_18_9
 L  conditional_Sx_upper_18_9
 G  conditional_complement_lower_18_9
 L  conditional_complement_upper_18_9
 G  conditional_Sx_lower_18_10
 L  conditional_Sx_upper_18_10
 G  conditional_complement_lower_18_10
 L  conditional_complement_upper_18_10
 G  conditional_Sx_lower_19_0
 L  conditional_Sx_upper_19_0
 G  conditional_complement_lower_19_0
 L  conditional_complement_upper_19_0
 G  conditional_Sx_lower_19_1
 L  conditional_Sx_upper_19_1
 G  conditional_complement_lower_19_1
 L  conditional_complement_upper_19_1
 G  conditional_Sx_lower_19_2
 L  conditional_Sx_upper_19_2
 G  conditional_complement_lower_19_2
 L  conditional_complement_upper_19_2
 G  conditional_Sx_lower_19_3
 L  conditional_Sx_upper_19_3
 G  conditional_complement_lower_19_3
 L  conditional_complement_upper_19_3
 G  conditional_Sx_lower_19_4
 L  conditional_Sx_upper_19_4
 G  conditional_complement_lower_19_4
 L  conditional_complement_upper_19_4
 G  conditional_Sx_lower_19_5
 L  conditional_Sx_upper_19_5
 G  conditional_complement_lower_19_5
 L  conditional_complement_upper_19_5
 G  conditional_Sx_lower_19_6
 L  conditional_Sx_upper_19_6
 G  conditional_complement_lower_19_6
 L  conditional_complement_upper_19_6
 G  conditional_Sx_lower_19_7
 L  conditional_Sx_upper_19_7
 G  conditional_complement_lower_19_7
 L  conditional_complement_upper_19_7
 G  conditional_Sx_lower_19_8
 L  conditional_Sx_upper_19_8
 G  conditional_complement_lower_19_8
 L  conditional_complement_upper_19_8
 G  conditional_Sx_lower_19_9
 L  conditional_Sx_upper_19_9
 G  conditional_complement_lower_19_9
 L  conditional_complement_upper_19_9
 G  conditional_Sx_lower_19_10
 L  conditional_Sx_upper_19_10
 G  conditional_complement_lower_19_10
 L  conditional_complement_upper_19_10
 G  conditional_Sx_lower_20_0
 L  conditional_Sx_upper_20_0
 G  conditional_complement_lower_20_0
 L  conditional_complement_upper_20_0
 G  conditional_Sx_lower_20_1
 L  conditional_Sx_upper_20_1
 G  conditional_complement_lower_20_1
 L  conditional_complement_upper_20_1
 G  conditional_Sx_lower_20_2
 L  conditional_Sx_upper_20_2
 G  conditional_complement_lower_20_2
 L  conditional_complement_upper_20_2
 G  conditional_Sx_lower_20_3
 L  conditional_Sx_upper_20_3
 G  conditional_complement_lower_20_3
 L  conditional_complement_upper_20_3
 G  conditional_Sx_lower_20_4
 L  conditional_Sx_upper_20_4
 G  conditional_complement_lower_20_4
 L  conditional_complement_upper_20_4
 G  conditional_Sx_lower_20_5
 L  conditional_Sx_upper_20_5
 G  conditional_complement_lower_20_5
 L  conditional_complement_upper_20_5
 G  conditional_Sx_lower_20_6
 L  conditional_Sx_upper_20_6
 G  conditional_complement_lower_20_6
 L  conditional_complement_upper_20_6
 G  conditional_Sx_lower_20_7
 L  conditional_Sx_upper_20_7
 G  conditional_complement_lower_20_7
 L  conditional_complement_upper_20_7
 G  conditional_Sx_lower_20_8
 L  conditional_Sx_upper_20_8
 G  conditional_complement_lower_20_8
 L  conditional_complement_upper_20_8
 G  conditional_Sx_lower_20_9
 L  conditional_Sx_upper_20_9
 G  conditional_complement_lower_20_9
 L  conditional_complement_upper_20_9
 G  conditional_Sx_lower_20_10
 L  conditional_Sx_upper_20_10
 G  conditional_complement_lower_20_10
 L  conditional_complement_upper_20_10
 G  conditional_Sx_lower_21_0
 L  conditional_Sx_upper_21_0
 G  conditional_complement_lower_21_0
 L  conditional_complement_upper_21_0
 G  conditional_Sx_lower_21_1
 L  conditional_Sx_upper_21_1
 G  conditional_complement_lower_21_1
 L  conditional_complement_upper_21_1
 G  conditional_Sx_lower_21_2
 L  conditional_Sx_upper_21_2
 G  conditional_complement_lower_21_2
 L  conditional_complement_upper_21_2
 G  conditional_Sx_lower_21_3
 L  conditional_Sx_upper_21_3
 G  conditional_complement_lower_21_3
 L  conditional_complement_upper_21_3
 G  conditional_Sx_lower_21_4
 L  conditional_Sx_upper_21_4
 G  conditional_complement_lower_21_4
 L  conditional_complement_upper_21_4
 G  conditional_Sx_lower_21_5
 L  conditional_Sx_upper_21_5
 G  conditional_complement_lower_21_5
 L  conditional_complement_upper_21_5
 G  conditional_Sx_lower_21_6
 L  conditional_Sx_upper_21_6
 G  conditional_complement_lower_21_6
 L  conditional_complement_upper_21_6
 G  conditional_Sx_lower_22_0
 L  conditional_Sx_upper_22_0
 G  conditional_complement_lower_22_0
 L  conditional_complement_upper_22_0
 G  conditional_Sx_lower_22_1
 L  conditional_Sx_upper_22_1
 G  conditional_complement_lower_22_1
 L  conditional_complement_upper_22_1
 G  conditional_Sx_lower_22_2
 L  conditional_Sx_upper_22_2
 G  conditional_complement_lower_22_2
 L  conditional_complement_upper_22_2
 G  conditional_Sx_lower_22_3
 L  conditional_Sx_upper_22_3
 G  conditional_complement_lower_22_3
 L  conditional_complement_upper_22_3
 G  conditional_Sx_lower_22_4
 L  conditional_Sx_upper_22_4
 G  conditional_complement_lower_22_4
 L  conditional_complement_upper_22_4
 G  conditional_Sx_lower_22_5
 L  conditional_Sx_upper_22_5
 G  conditional_complement_lower_22_5
 L  conditional_complement_upper_22_5
 G  conditional_Sx_lower_22_6
 L  conditional_Sx_upper_22_6
 G  conditional_complement_lower_22_6
 L  conditional_complement_upper_22_6
 G  conditional_Sx_lower_22_7
 L  conditional_Sx_upper_22_7
 G  conditional_complement_lower_22_7
 L  conditional_complement_upper_22_7
 G  conditional_Sx_lower_22_8
 L  conditional_Sx_upper_22_8
 G  conditional_complement_lower_22_8
 L  conditional_complement_upper_22_8
 G  conditional_Sx_lower_22_9
 L  conditional_Sx_upper_22_9
 G  conditional_complement_lower_22_9
 L  conditional_complement_upper_22_9
 G  conditional_Sx_lower_22_10
 L  conditional_Sx_upper_22_10
 G  conditional_complement_lower_22_10
 L  conditional_complement_upper_22_10
 G  conditional_Sx_lower_22_11
 L  conditional_Sx_upper_22_11
 G  conditional_complement_lower_22_11
 L  conditional_complement_upper_22_11
 G  conditional_Sx_lower_22_12
 L  conditional_Sx_upper_22_12
 G  conditional_complement_lower_22_12
 L  conditional_complement_upper_22_12
 G  conditional_Sx_lower_22_13
 L  conditional_Sx_upper_22_13
 G  conditional_complement_lower_22_13
 L  conditional_complement_upper_22_13
 G  conditional_Sx_lower_22_14
 L  conditional_Sx_upper_22_14
 G  conditional_complement_lower_22_14
 L  conditional_complement_upper_22_14
 G  conditional_Sx_lower_22_15
 L  conditional_Sx_upper_22_15
 G  conditional_complement_lower_22_15
 L  conditional_complement_upper_22_15
 G  conditional_Sx_lower_23_0
 L  conditional_Sx_upper_23_0
 G  conditional_complement_lower_23_0
 L  conditional_complement_upper_23_0
 G  conditional_Sx_lower_23_1
 L  conditional_Sx_upper_23_1
 G  conditional_complement_lower_23_1
 L  conditional_complement_upper_23_1
 G  conditional_Sx_lower_23_2
 L  conditional_Sx_upper_23_2
 G  conditional_complement_lower_23_2
 L  conditional_complement_upper_23_2
 G  conditional_Sx_lower_23_3
 L  conditional_Sx_upper_23_3
 G  conditional_complement_lower_23_3
 L  conditional_complement_upper_23_3
 G  conditional_Sx_lower_24_0
 L  conditional_Sx_upper_24_0
 G  conditional_complement_lower_24_0
 L  conditional_complement_upper_24_0
 G  conditional_Sx_lower_24_1
 L  conditional_Sx_upper_24_1
 G  conditional_complement_lower_24_1
 L  conditional_complement_upper_24_1
 G  conditional_Sx_lower_24_2
 L  conditional_Sx_upper_24_2
 G  conditional_complement_lower_24_2
 L  conditional_complement_upper_24_2
 G  conditional_Sx_lower_24_3
 L  conditional_Sx_upper_24_3
 G  conditional_complement_lower_24_3
 L  conditional_complement_upper_24_3
 G  conditional_Sx_lower_24_4
 L  conditional_Sx_upper_24_4
 G  conditional_complement_lower_24_4
 L  conditional_complement_upper_24_4
 G  conditional_Sx_lower_24_5
 L  conditional_Sx_upper_24_5
 G  conditional_complement_lower_24_5
 L  conditional_complement_upper_24_5
 G  conditional_Sx_lower_24_6
 L  conditional_Sx_upper_24_6
 G  conditional_complement_lower_24_6
 L  conditional_complement_upper_24_6
 G  conditional_Sx_lower_24_7
 L  conditional_Sx_upper_24_7
 G  conditional_complement_lower_24_7
 L  conditional_complement_upper_24_7
 G  conditional_Sx_lower_24_8
 L  conditional_Sx_upper_24_8
 G  conditional_complement_lower_24_8
 L  conditional_complement_upper_24_8
 G  conditional_Sx_lower_24_9
 L  conditional_Sx_upper_24_9
 G  conditional_complement_lower_24_9
 L  conditional_complement_upper_24_9
 G  conditional_Sx_lower_24_10
 L  conditional_Sx_upper_24_10
 G  conditional_complement_lower_24_10
 L  conditional_complement_upper_24_10
 G  conditional_Sx_lower_24_11
 L  conditional_Sx_upper_24_11
 G  conditional_complement_lower_24_11
 L  conditional_complement_upper_24_11
 G  conditional_Sx_lower_24_12
 L  conditional_Sx_upper_24_12
 G  conditional_complement_lower_24_12
 L  conditional_complement_upper_24_12
 G  conditional_Sx_lower_24_13
 L  conditional_Sx_upper_24_13
 G  conditional_complement_lower_24_13
 L  conditional_complement_upper_24_13
 G  conditional_Sx_lower_24_14
 L  conditional_Sx_upper_24_14
 G  conditional_complement_lower_24_14
 L  conditional_complement_upper_24_14
 G  conditional_Sx_lower_24_15
 L  conditional_Sx_upper_24_15
 G  conditional_complement_lower_24_15
 L  conditional_complement_upper_24_15
 G  conditional_Sx_lower_25_0
 L  conditional_Sx_upper_25_0
 G  conditional_complement_lower_25_0
 L  conditional_complement_upper_25_0
 G  conditional_Sx_lower_25_1
 L  conditional_Sx_upper_25_1
 G  conditional_complement_lower_25_1
 L  conditional_complement_upper_25_1
 G  conditional_Sx_lower_25_2
 L  conditional_Sx_upper_25_2
 G  conditional_complement_lower_25_2
 L  conditional_complement_upper_25_2
 G  conditional_Sx_lower_25_3
 L  conditional_Sx_upper_25_3
 G  conditional_complement_lower_25_3
 L  conditional_complement_upper_25_3
 G  conditional_Sx_lower_25_4
 L  conditional_Sx_upper_25_4
 G  conditional_complement_lower_25_4
 L  conditional_complement_upper_25_4
 G  conditional_Sx_lower_26_0
 L  conditional_Sx_upper_26_0
 G  conditional_complement_lower_26_0
 L  conditional_complement_upper_26_0
 G  conditional_Sx_lower_26_1
 L  conditional_Sx_upper_26_1
 G  conditional_complement_lower_26_1
 L  conditional_complement_upper_26_1
 G  conditional_Sx_lower_26_2
 L  conditional_Sx_upper_26_2
 G  conditional_complement_lower_26_2
 L  conditional_complement_upper_26_2
 G  conditional_Sx_lower_26_3
 L  conditional_Sx_upper_26_3
 G  conditional_complement_lower_26_3
 L  conditional_complement_upper_26_3
 G  conditional_Sx_lower_26_4
 L  conditional_Sx_upper_26_4
 G  conditional_complement_lower_26_4
 L  conditional_complement_upper_26_4
 G  conditional_Sx_lower_26_5
 L  conditional_Sx_upper_26_5
 G  conditional_complement_lower_26_5
 L  conditional_complement_upper_26_5
 G  conditional_Sx_lower_26_6
 L  conditional_Sx_upper_26_6
 G  conditional_complement_lower_26_6
 L  conditional_complement_upper_26_6
 G  conditional_Sx_lower_26_7
 L  conditional_Sx_upper_26_7
 G  conditional_complement_lower_26_7
 L  conditional_complement_upper_26_7
 G  conditional_Sx_lower_26_8
 L  conditional_Sx_upper_26_8
 G  conditional_complement_lower_26_8
 L  conditional_complement_upper_26_8
 G  conditional_Sx_lower_27_0
 L  conditional_Sx_upper_27_0
 G  conditional_complement_lower_27_0
 L  conditional_complement_upper_27_0
 G  conditional_Sx_lower_27_1
 L  conditional_Sx_upper_27_1
 G  conditional_complement_lower_27_1
 L  conditional_complement_upper_27_1
 G  conditional_Sx_lower_27_2
 L  conditional_Sx_upper_27_2
 G  conditional_complement_lower_27_2
 L  conditional_complement_upper_27_2
 G  conditional_Sx_lower_27_3
 L  conditional_Sx_upper_27_3
 G  conditional_complement_lower_27_3
 L  conditional_complement_upper_27_3
 G  conditional_Sx_lower_27_4
 L  conditional_Sx_upper_27_4
 G  conditional_complement_lower_27_4
 L  conditional_complement_upper_27_4
 G  conditional_Sx_lower_27_5
 L  conditional_Sx_upper_27_5
 G  conditional_complement_lower_27_5
 L  conditional_complement_upper_27_5
 G  conditional_Sx_lower_27_6
 L  conditional_Sx_upper_27_6
 G  conditional_complement_lower_27_6
 L  conditional_complement_upper_27_6
 G  conditional_Sx_lower_28_0
 L  conditional_Sx_upper_28_0
 G  conditional_complement_lower_28_0
 L  conditional_complement_upper_28_0
 G  conditional_Sx_lower_28_1
 L  conditional_Sx_upper_28_1
 G  conditional_complement_lower_28_1
 L  conditional_complement_upper_28_1
 G  conditional_Sx_lower_28_2
 L  conditional_Sx_upper_28_2
 G  conditional_complement_lower_28_2
 L  conditional_complement_upper_28_2
 G  conditional_Sx_lower_28_3
 L  conditional_Sx_upper_28_3
 G  conditional_complement_lower_28_3
 L  conditional_complement_upper_28_3
 G  conditional_Sx_lower_28_4
 L  conditional_Sx_upper_28_4
 G  conditional_complement_lower_28_4
 L  conditional_complement_upper_28_4
 G  conditional_Sx_lower_28_5
 L  conditional_Sx_upper_28_5
 G  conditional_complement_lower_28_5
 L  conditional_complement_upper_28_5
 G  conditional_Sx_lower_28_6
 L  conditional_Sx_upper_28_6
 G  conditional_complement_lower_28_6
 L  conditional_complement_upper_28_6
 G  conditional_Sx_lower_29_0
 L  conditional_Sx_upper_29_0
 G  conditional_complement_lower_29_0
 L  conditional_complement_upper_29_0
 G  conditional_Sx_lower_29_1
 L  conditional_Sx_upper_29_1
 G  conditional_complement_lower_29_1
 L  conditional_complement_upper_29_1
 G  conditional_Sx_lower_29_2
 L  conditional_Sx_upper_29_2
 G  conditional_complement_lower_29_2
 L  conditional_complement_upper_29_2
 G  conditional_Sx_lower_29_3
 L  conditional_Sx_upper_29_3
 G  conditional_complement_lower_29_3
 L  conditional_complement_upper_29_3
 G  conditional_Sx_lower_29_4
 L  conditional_Sx_upper_29_4
 G  conditional_complement_lower_29_4
 L  conditional_complement_upper_29_4
 G  conditional_Sx_lower_29_5
 L  conditional_Sx_upper_29_5
 G  conditional_complement_lower_29_5
 L  conditional_complement_upper_29_5
 G  conditional_Sx_lower_29_6
 L  conditional_Sx_upper_29_6
 G  conditional_complement_lower_29_6
 L  conditional_complement_upper_29_6
 G  conditional_Sx_lower_29_7
 L  conditional_Sx_upper_29_7
 G  conditional_complement_lower_29_7
 L  conditional_complement_upper_29_7
 G  conditional_Sx_lower_29_8
 L  conditional_Sx_upper_29_8
 G  conditional_complement_lower_29_8
 L  conditional_complement_upper_29_8
 G  conditional_Sx_lower_29_9
 L  conditional_Sx_upper_29_9
 G  conditional_complement_lower_29_9
 L  conditional_complement_upper_29_9
 G  conditional_Sx_lower_29_10
 L  conditional_Sx_upper_29_10
 G  conditional_complement_lower_29_10
 L  conditional_complement_upper_29_10
 G  conditional_Sx_lower_30_0
 L  conditional_Sx_upper_30_0
 G  conditional_complement_lower_30_0
 L  conditional_complement_upper_30_0
 G  conditional_Sx_lower_30_1
 L  conditional_Sx_upper_30_1
 G  conditional_complement_lower_30_1
 L  conditional_complement_upper_30_1
 G  conditional_Sx_lower_30_2
 L  conditional_Sx_upper_30_2
 G  conditional_complement_lower_30_2
 L  conditional_complement_upper_30_2
 G  conditional_Sx_lower_30_3
 L  conditional_Sx_upper_30_3
 G  conditional_complement_lower_30_3
 L  conditional_complement_upper_30_3
 G  conditional_Sx_lower_30_4
 L  conditional_Sx_upper_30_4
 G  conditional_complement_lower_30_4
 L  conditional_complement_upper_30_4
 G  conditional_Sx_lower_30_5
 L  conditional_Sx_upper_30_5
 G  conditional_complement_lower_30_5
 L  conditional_complement_upper_30_5
 G  conditional_Sx_lower_30_6
 L  conditional_Sx_upper_30_6
 G  conditional_complement_lower_30_6
 L  conditional_complement_upper_30_6
 G  conditional_Sx_lower_30_7
 L  conditional_Sx_upper_30_7
 G  conditional_complement_lower_30_7
 L  conditional_complement_upper_30_7
 G  conditional_Sx_lower_30_8
 L  conditional_Sx_upper_30_8
 G  conditional_complement_lower_30_8
 L  conditional_complement_upper_30_8
 G  conditional_Sx_lower_31_0
 L  conditional_Sx_upper_31_0
 G  conditional_complement_lower_31_0
 L  conditional_complement_upper_31_0
 G  conditional_Sx_lower_31_1
 L  conditional_Sx_upper_31_1
 G  conditional_complement_lower_31_1
 L  conditional_complement_upper_31_1
 G  conditional_Sx_lower_31_2
 L  conditional_Sx_upper_31_2
 G  conditional_complement_lower_31_2
 L  conditional_complement_upper_31_2
 G  conditional_Sx_lower_31_3
 L  conditional_Sx_upper_31_3
 G  conditional_complement_lower_31_3
 L  conditional_complement_upper_31_3
 G  conditional_Sx_lower_31_4
 L  conditional_Sx_upper_31_4
 G  conditional_complement_lower_31_4
 L  conditional_complement_upper_31_4
 G  conditional_Sx_lower_31_5
 L  conditional_Sx_upper_31_5
 G  conditional_complement_lower_31_5
 L  conditional_complement_upper_31_5
 G  conditional_Sx_lower_31_6
 L  conditional_Sx_upper_31_6
 G  conditional_complement_lower_31_6
 L  conditional_complement_upper_31_6
 G  conditional_Sx_lower_31_7
 L  conditional_Sx_upper_31_7
 G  conditional_complement_lower_31_7
 L  conditional_complement_upper_31_7
 G  conditional_Sx_lower_31_8
 L  conditional_Sx_upper_31_8
 G  conditional_complement_lower_31_8
 L  conditional_complement_upper_31_8
 G  conditional_Sx_lower_31_9
 L  conditional_Sx_upper_31_9
 G  conditional_complement_lower_31_9
 L  conditional_complement_upper_31_9
 G  conditional_Sx_lower_31_10
 L  conditional_Sx_upper_31_10
 G  conditional_complement_lower_31_10
 L  conditional_complement_upper_31_10
 G  conditional_Sx_lower_31_11
 L  conditional_Sx_upper_31_11
 G  conditional_complement_lower_31_11
 L  conditional_complement_upper_31_11
 G  conditional_Sx_lower_32_0
 L  conditional_Sx_upper_32_0
 G  conditional_complement_lower_32_0
 L  conditional_complement_upper_32_0
 G  conditional_Sx_lower_32_1
 L  conditional_Sx_upper_32_1
 G  conditional_complement_lower_32_1
 L  conditional_complement_upper_32_1
 G  conditional_Sx_lower_32_2
 L  conditional_Sx_upper_32_2
 G  conditional_complement_lower_32_2
 L  conditional_complement_upper_32_2
 G  conditional_Sx_lower_32_3
 L  conditional_Sx_upper_32_3
 G  conditional_complement_lower_32_3
 L  conditional_complement_upper_32_3
 G  conditional_Sx_lower_32_4
 L  conditional_Sx_upper_32_4
 G  conditional_complement_lower_32_4
 L  conditional_complement_upper_32_4
 G  conditional_Sx_lower_32_5
 L  conditional_Sx_upper_32_5
 G  conditional_complement_lower_32_5
 L  conditional_complement_upper_32_5
 G  conditional_Sx_lower_32_6
 L  conditional_Sx_upper_32_6
 G  conditional_complement_lower_32_6
 L  conditional_complement_upper_32_6
 G  conditional_Sx_lower_32_7
 L  conditional_Sx_upper_32_7
 G  conditional_complement_lower_32_7
 L  conditional_complement_upper_32_7
 G  conditional_Sx_lower_32_8
 L  conditional_Sx_upper_32_8
 G  conditional_complement_lower_32_8
 L  conditional_complement_upper_32_8
 G  conditional_Sx_lower_32_9
 L  conditional_Sx_upper_32_9
 G  conditional_complement_lower_32_9
 L  conditional_complement_upper_32_9
 G  conditional_Sx_lower_32_10
 L  conditional_Sx_upper_32_10
 G  conditional_complement_lower_32_10
 L  conditional_complement_upper_32_10
 G  conditional_Sx_lower_32_11
 L  conditional_Sx_upper_32_11
 G  conditional_complement_lower_32_11
 L  conditional_complement_upper_32_11
 G  conditional_Sx_lower_32_12
 L  conditional_Sx_upper_32_12
 G  conditional_complement_lower_32_12
 L  conditional_complement_upper_32_12
 G  conditional_Sx_lower_32_13
 L  conditional_Sx_upper_32_13
 G  conditional_complement_lower_32_13
 L  conditional_complement_upper_32_13
 G  conditional_Sx_lower_32_14
 L  conditional_Sx_upper_32_14
 G  conditional_complement_lower_32_14
 L  conditional_complement_upper_32_14
 G  conditional_Sx_lower_32_15
 L  conditional_Sx_upper_32_15
 G  conditional_complement_lower_32_15
 L  conditional_complement_upper_32_15
 G  conditional_Sx_lower_32_16
 L  conditional_Sx_upper_32_16
 G  conditional_complement_lower_32_16
 L  conditional_complement_upper_32_16
 G  conditional_Sx_lower_32_17
 L  conditional_Sx_upper_32_17
 G  conditional_complement_lower_32_17
 L  conditional_complement_upper_32_17
 G  conditional_Sx_lower_32_18
 L  conditional_Sx_upper_32_18
 G  conditional_complement_lower_32_18
 L  conditional_complement_upper_32_18
 G  conditional_Sx_lower_32_19
 L  conditional_Sx_upper_32_19
 G  conditional_complement_lower_32_19
 L  conditional_complement_upper_32_19
 G  conditional_Sx_lower_33_0
 L  conditional_Sx_upper_33_0
 G  conditional_complement_lower_33_0
 L  conditional_complement_upper_33_0
 G  conditional_Sx_lower_33_1
 L  conditional_Sx_upper_33_1
 G  conditional_complement_lower_33_1
 L  conditional_complement_upper_33_1
 G  conditional_Sx_lower_33_2
 L  conditional_Sx_upper_33_2
 G  conditional_complement_lower_33_2
 L  conditional_complement_upper_33_2
 G  conditional_Sx_lower_33_3
 L  conditional_Sx_upper_33_3
 G  conditional_complement_lower_33_3
 L  conditional_complement_upper_33_3
 G  conditional_Sx_lower_33_4
 L  conditional_Sx_upper_33_4
 G  conditional_complement_lower_33_4
 L  conditional_complement_upper_33_4
 G  conditional_Sx_lower_33_5
 L  conditional_Sx_upper_33_5
 G  conditional_complement_lower_33_5
 L  conditional_complement_upper_33_5
 G  conditional_Sx_lower_33_6
 L  conditional_Sx_upper_33_6
 G  conditional_complement_lower_33_6
 L  conditional_complement_upper_33_6
 G  conditional_Sx_lower_33_7
 L  conditional_Sx_upper_33_7
 G  conditional_complement_lower_33_7
 L  conditional_complement_upper_33_7
 G  conditional_Sx_lower_33_8
 L  conditional_Sx_upper_33_8
 G  conditional_complement_lower_33_8
 L  conditional_complement_upper_33_8
 G  conditional_Sx_lower_33_9
 L  conditional_Sx_upper_33_9
 G  conditional_complement_lower_33_9
 L  conditional_complement_upper_33_9
 G  conditional_Sx_lower_33_10
 L  conditional_Sx_upper_33_10
 G  conditional_complement_lower_33_10
 L  conditional_complement_upper_33_10
 G  conditional_Sx_lower_33_11
 L  conditional_Sx_upper_33_11
 G  conditional_complement_lower_33_11
 L  conditional_complement_upper_33_11
 G  conditional_Sx_lower_34_0
 L  conditional_Sx_upper_34_0
 G  conditional_complement_lower_34_0
 L  conditional_complement_upper_34_0
 G  conditional_Sx_lower_34_1
 L  conditional_Sx_upper_34_1
 G  conditional_complement_lower_34_1
 L  conditional_complement_upper_34_1
 G  conditional_Sx_lower_34_2
 L  conditional_Sx_upper_34_2
 G  conditional_complement_lower_34_2
 L  conditional_complement_upper_34_2
 G  conditional_Sx_lower_34_3
 L  conditional_Sx_upper_34_3
 G  conditional_complement_lower_34_3
 L  conditional_complement_upper_34_3
 G  conditional_Sx_lower_34_4
 L  conditional_Sx_upper_34_4
 G  conditional_complement_lower_34_4
 L  conditional_complement_upper_34_4
 G  conditional_Sx_lower_34_5
 L  conditional_Sx_upper_34_5
 G  conditional_complement_lower_34_5
 L  conditional_complement_upper_34_5
 G  conditional_Sx_lower_34_6
 L  conditional_Sx_upper_34_6
 G  conditional_complement_lower_34_6
 L  conditional_complement_upper_34_6
 G  conditional_Sx_lower_34_7
 L  conditional_Sx_upper_34_7
 G  conditional_complement_lower_34_7
 L  conditional_complement_upper_34_7
 G  conditional_Sx_lower_34_8
 L  conditional_Sx_upper_34_8
 G  conditional_complement_lower_34_8
 L  conditional_complement_upper_34_8
 G  conditional_Sx_lower_34_9
 L  conditional_Sx_upper_34_9
 G  conditional_complement_lower_34_9
 L  conditional_complement_upper_34_9
 G  conditional_Sx_lower_34_10
 L  conditional_Sx_upper_34_10
 G  conditional_complement_lower_34_10
 L  conditional_complement_upper_34_10
 G  conditional_Sx_lower_34_11
 L  conditional_Sx_upper_34_11
 G  conditional_complement_lower_34_11
 L  conditional_complement_upper_34_11
 G  conditional_Sx_lower_34_12
 L  conditional_Sx_upper_34_12
 G  conditional_complement_lower_34_12
 L  conditional_complement_upper_34_12
 G  conditional_Sx_lower_34_13
 L  conditional_Sx_upper_34_13
 G  conditional_complement_lower_34_13
 L  conditional_complement_upper_34_13
 G  conditional_Sx_lower_34_14
 L  conditional_Sx_upper_34_14
 G  conditional_complement_lower_34_14
 L  conditional_complement_upper_34_14
 G  conditional_Sx_lower_34_15
 L  conditional_Sx_upper_34_15
 G  conditional_complement_lower_34_15
 L  conditional_complement_upper_34_15
 G  conditional_Sx_lower_35_0
 L  conditional_Sx_upper_35_0
 G  conditional_complement_lower_35_0
 L  conditional_complement_upper_35_0
 G  conditional_Sx_lower_35_1
 L  conditional_Sx_upper_35_1
 G  conditional_complement_lower_35_1
 L  conditional_complement_upper_35_1
 G  conditional_Sx_lower_35_2
 L  conditional_Sx_upper_35_2
 G  conditional_complement_lower_35_2
 L  conditional_complement_upper_35_2
 G  conditional_Sx_lower_35_3
 L  conditional_Sx_upper_35_3
 G  conditional_complement_lower_35_3
 L  conditional_complement_upper_35_3
 G  conditional_Sx_lower_35_4
 L  conditional_Sx_upper_35_4
 G  conditional_complement_lower_35_4
 L  conditional_complement_upper_35_4
 G  conditional_Sx_lower_35_5
 L  conditional_Sx_upper_35_5
 G  conditional_complement_lower_35_5
 L  conditional_complement_upper_35_5
 G  conditional_Sx_lower_35_6
 L  conditional_Sx_upper_35_6
 G  conditional_complement_lower_35_6
 L  conditional_complement_upper_35_6
 G  conditional_Sx_lower_35_7
 L  conditional_Sx_upper_35_7
 G  conditional_complement_lower_35_7
 L  conditional_complement_upper_35_7
 G  conditional_Sx_lower_35_8
 L  conditional_Sx_upper_35_8
 G  conditional_complement_lower_35_8
 L  conditional_complement_upper_35_8
 G  conditional_Sx_lower_35_9
 L  conditional_Sx_upper_35_9
 G  conditional_complement_lower_35_9
 L  conditional_complement_upper_35_9
 G  conditional_Sx_lower_35_10
 L  conditional_Sx_upper_35_10
 G  conditional_complement_lower_35_10
 L  conditional_complement_upper_35_10
 G  conditional_Sx_lower_35_11
 L  conditional_Sx_upper_35_11
 G  conditional_complement_lower_35_11
 L  conditional_complement_upper_35_11
 G  conditional_Sx_lower_35_12
 L  conditional_Sx_upper_35_12
 G  conditional_complement_lower_35_12
 L  conditional_complement_upper_35_12
 G  conditional_Sx_lower_35_13
 L  conditional_Sx_upper_35_13
 G  conditional_complement_lower_35_13
 L  conditional_complement_upper_35_13
 G  conditional_Sx_lower_35_14
 L  conditional_Sx_upper_35_14
 G  conditional_complement_lower_35_14
 L  conditional_complement_upper_35_14
 G  conditional_Sx_lower_35_15
 L  conditional_Sx_upper_35_15
 G  conditional_complement_lower_35_15
 L  conditional_complement_upper_35_15
 E  hard_cost_D_definition
 E  hard_cost_W_definition
 G  tight_DP_cost_product_ll
 G  tight_DP_cost_product_uu
 L  tight_DP_cost_product_ul
 L  tight_DP_cost_product_lu
 G  floor_residual
 G  G_residual
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    onehot_1  1
    x[1,0]    product_lx_1_0  -8.61111111111111
    x[1,0]    product_ux_1_0  -39.6
    x[1,0]    product_Su_1_0  -39.6
    x[1,0]    product_Sl_1_0  -8.61111111111111
    x[1,0]    conditional_Sx_lower_1_0  -8.61111111111111
    x[1,0]    conditional_Sx_upper_1_0  -39.2
    x[1,0]    conditional_complement_lower_1_0  8.73611111111111
    x[1,0]    conditional_complement_upper_1_0  39.6
    x[1,0]    hard_cost_D_definition  -2.3273157207916555e-04
    x[1,1]    onehot_1  1
    x[1,1]    inventory_1  -1
    x[1,1]    product_lx_1_1  -8.61111111111111
    x[1,1]    product_ux_1_1  -39.6
    x[1,1]    product_Su_1_1  -39.6
    x[1,1]    product_Sl_1_1  -8.61111111111111
    x[1,1]    conditional_Sx_lower_1_1  -8.73611111111111
    x[1,1]    conditional_Sx_upper_1_1  -3.9250000000000007e+01
    x[1,1]    conditional_complement_lower_1_1  8.61111111111111
    x[1,1]    conditional_complement_upper_1_1  39.6
    x[1,1]    hard_cost_D_definition  -1.1636578603958278e-04
    x[1,2]    onehot_1  1
    x[1,2]    inventory_1  -2
    x[1,2]    product_lx_1_2  -8.61111111111111
    x[1,2]    product_ux_1_2  -39.6
    x[1,2]    product_Su_1_2  -39.6
    x[1,2]    product_Sl_1_2  -8.61111111111111
    x[1,2]    conditional_Sx_lower_1_2  -8.86111111111111
    x[1,2]    conditional_Sx_upper_1_2  -3.9300000000000004e+01
    x[1,2]    conditional_complement_lower_1_2  8.61111111111111
    x[1,2]    conditional_complement_upper_1_2  39.6
    x[1,3]    onehot_1  1
    x[1,3]    inventory_1  -3
    x[1,3]    product_lx_1_3  -8.61111111111111
    x[1,3]    product_ux_1_3  -39.6
    x[1,3]    product_Su_1_3  -39.6
    x[1,3]    product_Sl_1_3  -8.61111111111111
    x[1,3]    conditional_Sx_lower_1_3  -8.98611111111111
    x[1,3]    conditional_Sx_upper_1_3  -39.35
    x[1,3]    conditional_complement_lower_1_3  8.61111111111111
    x[1,3]    conditional_complement_upper_1_3  39.6
    x[1,3]    hard_cost_D_definition  1.1636578603958278e-04
    x[1,4]    onehot_1  1
    x[1,4]    inventory_1  -4
    x[1,4]    product_lx_1_4  -8.61111111111111
    x[1,4]    product_ux_1_4  -39.6
    x[1,4]    product_Su_1_4  -39.6
    x[1,4]    product_Sl_1_4  -8.61111111111111
    x[1,4]    conditional_Sx_lower_1_4  -9.11111111111111
    x[1,4]    conditional_Sx_upper_1_4  -3.9400000000000006e+01
    x[1,4]    conditional_complement_lower_1_4  8.61111111111111
    x[1,4]    conditional_complement_upper_1_4  39.6
    x[1,4]    hard_cost_D_definition  2.3273157207916555e-04
    x[1,5]    onehot_1  1
    x[1,5]    inventory_1  -5
    x[1,5]    product_lx_1_5  -8.61111111111111
    x[1,5]    product_ux_1_5  -39.6
    x[1,5]    product_Su_1_5  -39.6
    x[1,5]    product_Sl_1_5  -8.61111111111111
    x[1,5]    conditional_Sx_lower_1_5  -9.23611111111111
    x[1,5]    conditional_Sx_upper_1_5  -39.45
    x[1,5]    conditional_complement_lower_1_5  8.61111111111111
    x[1,5]    conditional_complement_upper_1_5  39.6
    x[1,5]    hard_cost_D_definition  1.1636578603958278e-04
    x[1,6]    onehot_1  1
    x[1,6]    inventory_1  -6
    x[1,6]    product_lx_1_6  -8.61111111111111
    x[1,6]    product_ux_1_6  -39.6
    x[1,6]    product_Su_1_6  -39.6
    x[1,6]    product_Sl_1_6  -8.61111111111111
    x[1,6]    conditional_Sx_lower_1_6  -9.36111111111111
    x[1,6]    conditional_Sx_upper_1_6  -3.9500000000000007e+01
    x[1,6]    conditional_complement_lower_1_6  8.61111111111111
    x[1,6]    conditional_complement_upper_1_6  39.6
    x[1,7]    onehot_1  1
    x[1,7]    inventory_1  -7
    x[1,7]    product_lx_1_7  -8.61111111111111
    x[1,7]    product_ux_1_7  -39.6
    x[1,7]    product_Su_1_7  -39.6
    x[1,7]    product_Sl_1_7  -8.61111111111111
    x[1,7]    conditional_Sx_lower_1_7  -9.48611111111111
    x[1,7]    conditional_Sx_upper_1_7  -3.9550000000000004e+01
    x[1,7]    conditional_complement_lower_1_7  8.61111111111111
    x[1,7]    conditional_complement_upper_1_7  39.6
    x[1,7]    hard_cost_D_definition  -1.1636578603958278e-04
    x[1,8]    onehot_1  1
    x[1,8]    inventory_1  -8
    x[1,8]    product_lx_1_8  -8.61111111111111
    x[1,8]    product_ux_1_8  -39.6
    x[1,8]    product_Su_1_8  -39.6
    x[1,8]    product_Sl_1_8  -8.61111111111111
    x[1,8]    conditional_Sx_lower_1_8  -9.61111111111111
    x[1,8]    conditional_Sx_upper_1_8  -39.6
    x[1,8]    conditional_complement_lower_1_8  8.61111111111111
    x[1,8]    conditional_complement_upper_1_8  3.9550000000000004e+01
    x[1,8]    hard_cost_D_definition  -2.3273157207916555e-04
    x[2,0]    onehot_2  1
    x[2,0]    product_lx_2_0  -8.61111111111111
    x[2,0]    product_ux_2_0  -39.6
    x[2,0]    product_Su_2_0  -39.6
    x[2,0]    product_Sl_2_0  -8.61111111111111
    x[2,0]    conditional_Sx_lower_2_0  -8.61111111111111
    x[2,0]    conditional_Sx_upper_2_0  -39.6
    x[2,0]    conditional_complement_lower_2_0  8.6289682539682531e+00
    x[2,0]    conditional_complement_upper_2_0  3.9542857142857144e+01
    x[2,0]    hard_cost_D_definition  -6.1091968240974646e-04
    x[2,1]    onehot_2  1
    x[2,1]    inventory_2  -1
    x[2,1]    product_lx_2_1  -8.61111111111111
    x[2,1]    product_ux_2_1  -39.6
    x[2,1]    product_Su_2_1  -39.6
    x[2,1]    product_Sl_2_1  -8.61111111111111
    x[2,1]    conditional_Sx_lower_2_1  -8.6289682539682531e+00
    x[2,1]    conditional_Sx_upper_2_1  -3.9542857142857144e+01
    x[2,1]    conditional_complement_lower_2_1  8.61111111111111
    x[2,1]    conditional_complement_upper_2_1  39.6
    x[2,1]    hard_cost_D_definition  -4.0727978827316433e-04
    x[2,2]    onehot_2  1
    x[2,2]    inventory_2  -2
    x[2,2]    product_lx_2_2  -8.61111111111111
    x[2,2]    product_ux_2_2  -39.6
    x[2,2]    product_Su_2_2  -39.6
    x[2,2]    product_Sl_2_2  -8.61111111111111
    x[2,2]    conditional_Sx_lower_2_2  -8.6468253968253954e+00
    x[2,2]    conditional_Sx_upper_2_2  -3.9485714285714288e+01
    x[2,2]    conditional_complement_lower_2_2  8.61111111111111
    x[2,2]    conditional_complement_upper_2_2  39.6
    x[2,2]    hard_cost_D_definition  -2.0363989413658219e-04
    x[2,3]    onehot_2  1
    x[2,3]    inventory_2  -3
    x[2,3]    product_lx_2_3  -8.61111111111111
    x[2,3]    product_ux_2_3  -39.6
    x[2,3]    product_Su_2_3  -39.6
    x[2,3]    product_Sl_2_3  -8.61111111111111
    x[2,3]    conditional_Sx_lower_2_3  -8.66468253968254
    x[2,3]    conditional_Sx_upper_2_3  -3.9428571428571431e+01
    x[2,3]    conditional_complement_lower_2_3  8.61111111111111
    x[2,3]    conditional_complement_upper_2_3  39.6
    x[2,4]    onehot_2  1
    x[2,4]    inventory_2  -4
    x[2,4]    product_lx_2_4  -8.61111111111111
    x[2,4]    product_ux_2_4  -39.6
    x[2,4]    product_Su_2_4  -39.6
    x[2,4]    product_Sl_2_4  -8.61111111111111
    x[2,4]    conditional_Sx_lower_2_4  -8.6825396825396819e+00
    x[2,4]    conditional_Sx_upper_2_4  -3.9371428571428574e+01
    x[2,4]    conditional_complement_lower_2_4  8.61111111111111
    x[2,4]    conditional_complement_upper_2_4  39.6
    x[2,4]    hard_cost_D_definition  2.0363989413658206e-04
    x[2,5]    onehot_2  1
    x[2,5]    inventory_2  -5
    x[2,5]    product_lx_2_5  -8.61111111111111
    x[2,5]    product_ux_2_5  -39.6
    x[2,5]    product_Su_2_5  -39.6
    x[2,5]    product_Sl_2_5  -8.61111111111111
    x[2,5]    conditional_Sx_lower_2_5  -8.7003968253968242e+00
    x[2,5]    conditional_Sx_upper_2_5  -3.9314285714285717e+01
    x[2,5]    conditional_complement_lower_2_5  8.61111111111111
    x[2,5]    conditional_complement_upper_2_5  39.6
    x[2,5]    hard_cost_D_definition  4.0727978827316422e-04
    x[2,6]    onehot_2  1
    x[2,6]    inventory_2  -6
    x[2,6]    product_lx_2_6  -8.61111111111111
    x[2,6]    product_ux_2_6  -39.6
    x[2,6]    product_Su_2_6  -39.6
    x[2,6]    product_Sl_2_6  -8.61111111111111
    x[2,6]    conditional_Sx_lower_2_6  -8.7182539682539666e+00
    x[2,6]    conditional_Sx_upper_2_6  -3.9257142857142860e+01
    x[2,6]    conditional_complement_lower_2_6  8.61111111111111
    x[2,6]    conditional_complement_upper_2_6  39.6
    x[2,6]    hard_cost_D_definition  6.1091968240974636e-04
    x[2,7]    onehot_2  1
    x[2,7]    inventory_2  -7
    x[2,7]    product_lx_2_7  -8.61111111111111
    x[2,7]    product_ux_2_7  -39.6
    x[2,7]    product_Su_2_7  -39.6
    x[2,7]    product_Sl_2_7  -8.61111111111111
    x[2,7]    conditional_Sx_lower_2_7  -8.73611111111111
    x[2,7]    conditional_Sx_upper_2_7  -39.2
    x[2,7]    conditional_complement_lower_2_7  8.61111111111111
    x[2,7]    conditional_complement_upper_2_7  39.6
    x[2,7]    hard_cost_D_definition  8.1455957654632855e-04
    x[2,8]    onehot_2  1
    x[2,8]    inventory_2  -8
    x[2,8]    product_lx_2_8  -8.61111111111111
    x[2,8]    product_ux_2_8  -39.6
    x[2,8]    product_Su_2_8  -39.6
    x[2,8]    product_Sl_2_8  -8.61111111111111
    x[2,8]    conditional_Sx_lower_2_8  -8.7539682539682531e+00
    x[2,8]    conditional_Sx_upper_2_8  -3.9142857142857146e+01
    x[2,8]    conditional_complement_lower_2_8  8.61111111111111
    x[2,8]    conditional_complement_upper_2_8  39.6
    x[2,8]    hard_cost_D_definition  6.1091968240974657e-04
    x[2,9]    onehot_2  1
    x[2,9]    inventory_2  -9
    x[2,9]    product_lx_2_9  -8.61111111111111
    x[2,9]    product_ux_2_9  -39.6
    x[2,9]    product_Su_2_9  -39.6
    x[2,9]    product_Sl_2_9  -8.61111111111111
    x[2,9]    conditional_Sx_lower_2_9  -8.7718253968253954e+00
    x[2,9]    conditional_Sx_upper_2_9  -3.9085714285714289e+01
    x[2,9]    conditional_complement_lower_2_9  8.61111111111111
    x[2,9]    conditional_complement_upper_2_9  39.6
    x[2,9]    hard_cost_D_definition  4.0727978827316438e-04
    x[2,10]   onehot_2  1
    x[2,10]   inventory_2  -10
    x[2,10]   product_lx_2_10  -8.61111111111111
    x[2,10]   product_ux_2_10  -39.6
    x[2,10]   product_Su_2_10  -39.6
    x[2,10]   product_Sl_2_10  -8.61111111111111
    x[2,10]   conditional_Sx_lower_2_10  -8.7896825396825378e+00
    x[2,10]   conditional_Sx_upper_2_10  -3.9028571428571432e+01
    x[2,10]   conditional_complement_lower_2_10  8.61111111111111
    x[2,10]   conditional_complement_upper_2_10  39.6
    x[2,10]   hard_cost_D_definition  2.0363989413658222e-04
    x[2,11]   onehot_2  1
    x[2,11]   inventory_2  -11
    x[2,11]   product_lx_2_11  -8.61111111111111
    x[2,11]   product_ux_2_11  -39.6
    x[2,11]   product_Su_2_11  -39.6
    x[2,11]   product_Sl_2_11  -8.61111111111111
    x[2,11]   conditional_Sx_lower_2_11  -8.8075396825396819e+00
    x[2,11]   conditional_Sx_upper_2_11  -3.8971428571428575e+01
    x[2,11]   conditional_complement_lower_2_11  8.61111111111111
    x[2,11]   conditional_complement_upper_2_11  39.6
    x[2,12]   onehot_2  1
    x[2,12]   inventory_2  -12
    x[2,12]   product_lx_2_12  -8.61111111111111
    x[2,12]   product_ux_2_12  -39.6
    x[2,12]   product_Su_2_12  -39.6
    x[2,12]   product_Sl_2_12  -8.61111111111111
    x[2,12]   conditional_Sx_lower_2_12  -8.8253968253968242e+00
    x[2,12]   conditional_Sx_upper_2_12  -3.8914285714285718e+01
    x[2,12]   conditional_complement_lower_2_12  8.61111111111111
    x[2,12]   conditional_complement_upper_2_12  39.6
    x[2,12]   hard_cost_D_definition  -2.0363989413658203e-04
    x[2,13]   onehot_2  1
    x[2,13]   inventory_2  -13
    x[2,13]   product_lx_2_13  -8.61111111111111
    x[2,13]   product_ux_2_13  -39.6
    x[2,13]   product_Su_2_13  -39.6
    x[2,13]   product_Sl_2_13  -8.61111111111111
    x[2,13]   conditional_Sx_lower_2_13  -8.8432539682539666e+00
    x[2,13]   conditional_Sx_upper_2_13  -3.8857142857142861e+01
    x[2,13]   conditional_complement_lower_2_13  8.61111111111111
    x[2,13]   conditional_complement_upper_2_13  39.6
    x[2,13]   hard_cost_D_definition  -4.0727978827316417e-04
    x[2,14]   onehot_2  1
    x[2,14]   inventory_2  -14
    x[2,14]   product_lx_2_14  -8.61111111111111
    x[2,14]   product_ux_2_14  -39.6
    x[2,14]   product_Su_2_14  -39.6
    x[2,14]   product_Sl_2_14  -8.61111111111111
    x[2,14]   conditional_Sx_lower_2_14  -8.86111111111111
    x[2,14]   conditional_Sx_upper_2_14  -3.8800000000000004e+01
    x[2,14]   conditional_complement_lower_2_14  8.61111111111111
    x[2,14]   conditional_complement_upper_2_14  39.6
    x[2,14]   hard_cost_D_definition  -6.1091968240974625e-04
    x[2,15]   onehot_2  1
    x[2,15]   inventory_2  -15
    x[2,15]   product_lx_2_15  -8.61111111111111
    x[2,15]   product_ux_2_15  -39.6
    x[2,15]   product_Su_2_15  -39.6
    x[2,15]   product_Sl_2_15  -8.61111111111111
    x[2,15]   conditional_Sx_lower_2_15  -8.8789682539682531e+00
    x[2,15]   conditional_Sx_upper_2_15  -3.8742857142857147e+01
    x[2,15]   conditional_complement_lower_2_15  8.61111111111111
    x[2,15]   conditional_complement_upper_2_15  39.6
    x[2,15]   hard_cost_D_definition  -8.1455957654632844e-04
    x[3,0]    onehot_3  1
    x[3,0]    product_lx_3_0  -8.61111111111111
    x[3,0]    product_ux_3_0  -39.6
    x[3,0]    product_Su_3_0  -39.6
    x[3,0]    product_Sl_3_0  -8.61111111111111
    x[3,0]    conditional_Sx_lower_3_0  -8.61111111111111
    x[3,0]    conditional_Sx_upper_3_0  -39.6
    x[3,0]    conditional_complement_lower_3_0  8.6527777777777768e+00
    x[3,0]    conditional_complement_upper_3_0  3.9566666666666670e+01
    x[3,0]    hard_cost_D_definition  -5.2364515352604213e-04
    x[3,1]    onehot_3  1
    x[3,1]    inventory_3  -1
    x[3,1]    product_lx_3_1  -8.61111111111111
    x[3,1]    product_ux_3_1  -39.6
    x[3,1]    product_Su_3_1  -39.6
    x[3,1]    product_Sl_3_1  -8.61111111111111
    x[3,1]    conditional_Sx_lower_3_1  -8.6527777777777768e+00
    x[3,1]    conditional_Sx_upper_3_1  -3.9566666666666670e+01
    x[3,1]    conditional_complement_lower_3_1  8.61111111111111
    x[3,1]    conditional_complement_upper_3_1  39.6
    x[3,1]    hard_cost_D_definition  -3.4909676901736142e-04
    x[3,2]    onehot_3  1
    x[3,2]    inventory_3  -2
    x[3,2]    product_lx_3_2  -8.61111111111111
    x[3,2]    product_ux_3_2  -39.6
    x[3,2]    product_Su_3_2  -39.6
    x[3,2]    product_Sl_3_2  -8.61111111111111
    x[3,2]    conditional_Sx_lower_3_2  -8.6944444444444429e+00
    x[3,2]    conditional_Sx_upper_3_2  -3.9533333333333339e+01
    x[3,2]    conditional_complement_lower_3_2  8.61111111111111
    x[3,2]    conditional_complement_upper_3_2  39.6
    x[3,2]    hard_cost_D_definition  -1.7454838450868071e-04
    x[3,3]    onehot_3  1
    x[3,3]    inventory_3  -3
    x[3,3]    product_lx_3_3  -8.61111111111111
    x[3,3]    product_ux_3_3  -39.6
    x[3,3]    product_Su_3_3  -39.6
    x[3,3]    product_Sl_3_3  -8.61111111111111
    x[3,3]    conditional_Sx_lower_3_3  -8.73611111111111
    x[3,3]    conditional_Sx_upper_3_3  -39.5
    x[3,3]    conditional_complement_lower_3_3  8.61111111111111
    x[3,3]    conditional_complement_upper_3_3  39.6
    x[3,4]    onehot_3  1
    x[3,4]    inventory_3  -4
    x[3,4]    product_lx_3_4  -8.61111111111111
    x[3,4]    product_ux_3_4  -39.6
    x[3,4]    product_Su_3_4  -39.6
    x[3,4]    product_Sl_3_4  -8.61111111111111
    x[3,4]    conditional_Sx_lower_3_4  -8.7777777777777768e+00
    x[3,4]    conditional_Sx_upper_3_4  -3.9466666666666669e+01
    x[3,4]    conditional_complement_lower_3_4  8.61111111111111
    x[3,4]    conditional_complement_upper_3_4  39.6
    x[3,4]    hard_cost_D_definition  1.7454838450868074e-04
    x[3,5]    onehot_3  1
    x[3,5]    inventory_3  -5
    x[3,5]    product_lx_3_5  -8.61111111111111
    x[3,5]    product_ux_3_5  -39.6
    x[3,5]    product_Su_3_5  -39.6
    x[3,5]    product_Sl_3_5  -8.61111111111111
    x[3,5]    conditional_Sx_lower_3_5  -8.8194444444444429e+00
    x[3,5]    conditional_Sx_upper_3_5  -3.9433333333333337e+01
    x[3,5]    conditional_complement_lower_3_5  8.61111111111111
    x[3,5]    conditional_complement_upper_3_5  39.6
    x[3,5]    hard_cost_D_definition  3.4909676901736148e-04
    x[3,6]    onehot_3  1
    x[3,6]    inventory_3  -6
    x[3,6]    product_lx_3_6  -8.61111111111111
    x[3,6]    product_ux_3_6  -39.6
    x[3,6]    product_Su_3_6  -39.6
    x[3,6]    product_Sl_3_6  -8.61111111111111
    x[3,6]    conditional_Sx_lower_3_6  -8.86111111111111
    x[3,6]    conditional_Sx_upper_3_6  -3.9400000000000006e+01
    x[3,6]    conditional_complement_lower_3_6  8.61111111111111
    x[3,6]    conditional_complement_upper_3_6  39.6
    x[3,6]    hard_cost_D_definition  5.2364515352604224e-04
    x[3,7]    onehot_3  1
    x[3,7]    inventory_3  -7
    x[3,7]    product_lx_3_7  -8.61111111111111
    x[3,7]    product_ux_3_7  -39.6
    x[3,7]    product_Su_3_7  -39.6
    x[3,7]    product_Sl_3_7  -8.61111111111111
    x[3,7]    conditional_Sx_lower_3_7  -8.9027777777777768e+00
    x[3,7]    conditional_Sx_upper_3_7  -3.9366666666666667e+01
    x[3,7]    conditional_complement_lower_3_7  8.61111111111111
    x[3,7]    conditional_complement_upper_3_7  39.6
    x[3,7]    hard_cost_D_definition  3.4909676901736164e-04
    x[3,8]    onehot_3  1
    x[3,8]    inventory_3  -8
    x[3,8]    product_lx_3_8  -8.61111111111111
    x[3,8]    product_ux_3_8  -39.6
    x[3,8]    product_Su_3_8  -39.6
    x[3,8]    product_Sl_3_8  -8.61111111111111
    x[3,8]    conditional_Sx_lower_3_8  -8.9444444444444429e+00
    x[3,8]    conditional_Sx_upper_3_8  -3.9333333333333336e+01
    x[3,8]    conditional_complement_lower_3_8  8.61111111111111
    x[3,8]    conditional_complement_upper_3_8  39.6
    x[3,8]    hard_cost_D_definition  1.7454838450868087e-04
    x[3,9]    onehot_3  1
    x[3,9]    inventory_3  -9
    x[3,9]    product_lx_3_9  -8.61111111111111
    x[3,9]    product_ux_3_9  -39.6
    x[3,9]    product_Su_3_9  -39.6
    x[3,9]    product_Sl_3_9  -8.61111111111111
    x[3,9]    conditional_Sx_lower_3_9  -8.98611111111111
    x[3,9]    conditional_Sx_upper_3_9  -3.9300000000000004e+01
    x[3,9]    conditional_complement_lower_3_9  8.61111111111111
    x[3,9]    conditional_complement_upper_3_9  39.6
    x[3,10]   onehot_3  1
    x[3,10]   inventory_3  -10
    x[3,10]   product_lx_3_10  -8.61111111111111
    x[3,10]   product_ux_3_10  -39.6
    x[3,10]   product_Su_3_10  -39.6
    x[3,10]   product_Sl_3_10  -8.61111111111111
    x[3,10]   conditional_Sx_lower_3_10  -9.0277777777777768e+00
    x[3,10]   conditional_Sx_upper_3_10  -3.9266666666666673e+01
    x[3,10]   conditional_complement_lower_3_10  8.61111111111111
    x[3,10]   conditional_complement_upper_3_10  39.6
    x[3,10]   hard_cost_D_definition  -1.7454838450868060e-04
    x[3,11]   onehot_3  1
    x[3,11]   inventory_3  -11
    x[3,11]   product_lx_3_11  -8.61111111111111
    x[3,11]   product_ux_3_11  -39.6
    x[3,11]   product_Su_3_11  -39.6
    x[3,11]   product_Sl_3_11  -8.61111111111111
    x[3,11]   conditional_Sx_lower_3_11  -9.0694444444444429e+00
    x[3,11]   conditional_Sx_upper_3_11  -3.9233333333333334e+01
    x[3,11]   conditional_complement_lower_3_11  8.61111111111111
    x[3,11]   conditional_complement_upper_3_11  39.6
    x[3,11]   hard_cost_D_definition  -3.4909676901736131e-04
    x[3,12]   onehot_3  1
    x[3,12]   inventory_3  -12
    x[3,12]   product_lx_3_12  -8.61111111111111
    x[3,12]   product_ux_3_12  -39.6
    x[3,12]   product_Su_3_12  -39.6
    x[3,12]   product_Sl_3_12  -8.61111111111111
    x[3,12]   conditional_Sx_lower_3_12  -9.11111111111111
    x[3,12]   conditional_Sx_upper_3_12  -39.2
    x[3,12]   conditional_complement_lower_3_12  8.61111111111111
    x[3,12]   conditional_complement_upper_3_12  39.6
    x[3,12]   hard_cost_D_definition  -0.000523645153526042
    x[4,0]    onehot_4  1
    x[4,0]    product_lx_4_0  -8.61111111111111
    x[4,0]    product_ux_4_0  -39.6
    x[4,0]    product_Su_4_0  -39.6
    x[4,0]    product_Sl_4_0  -8.61111111111111
    x[4,0]    conditional_Sx_lower_4_0  -8.61111111111111
    x[4,0]    conditional_Sx_upper_4_0  -39.6
    x[4,0]    conditional_complement_lower_4_0  8.6289682539682531e+00
    x[4,0]    conditional_complement_upper_4_0  3.9542857142857144e+01
    x[4,0]    hard_cost_D_definition  -6.1091968240974646e-04
    x[4,1]    onehot_4  1
    x[4,1]    inventory_4  -1
    x[4,1]    product_lx_4_1  -8.61111111111111
    x[4,1]    product_ux_4_1  -39.6
    x[4,1]    product_Su_4_1  -39.6
    x[4,1]    product_Sl_4_1  -8.61111111111111
    x[4,1]    conditional_Sx_lower_4_1  -8.6289682539682531e+00
    x[4,1]    conditional_Sx_upper_4_1  -3.9542857142857144e+01
    x[4,1]    conditional_complement_lower_4_1  8.61111111111111
    x[4,1]    conditional_complement_upper_4_1  39.6
    x[4,1]    hard_cost_D_definition  -4.0727978827316433e-04
    x[4,2]    onehot_4  1
    x[4,2]    inventory_4  -2
    x[4,2]    product_lx_4_2  -8.61111111111111
    x[4,2]    product_ux_4_2  -39.6
    x[4,2]    product_Su_4_2  -39.6
    x[4,2]    product_Sl_4_2  -8.61111111111111
    x[4,2]    conditional_Sx_lower_4_2  -8.6468253968253954e+00
    x[4,2]    conditional_Sx_upper_4_2  -3.9485714285714288e+01
    x[4,2]    conditional_complement_lower_4_2  8.61111111111111
    x[4,2]    conditional_complement_upper_4_2  39.6
    x[4,2]    hard_cost_D_definition  -2.0363989413658219e-04
    x[4,3]    onehot_4  1
    x[4,3]    inventory_4  -3
    x[4,3]    product_lx_4_3  -8.61111111111111
    x[4,3]    product_ux_4_3  -39.6
    x[4,3]    product_Su_4_3  -39.6
    x[4,3]    product_Sl_4_3  -8.61111111111111
    x[4,3]    conditional_Sx_lower_4_3  -8.66468253968254
    x[4,3]    conditional_Sx_upper_4_3  -3.9428571428571431e+01
    x[4,3]    conditional_complement_lower_4_3  8.61111111111111
    x[4,3]    conditional_complement_upper_4_3  39.6
    x[4,4]    onehot_4  1
    x[4,4]    inventory_4  -4
    x[4,4]    product_lx_4_4  -8.61111111111111
    x[4,4]    product_ux_4_4  -39.6
    x[4,4]    product_Su_4_4  -39.6
    x[4,4]    product_Sl_4_4  -8.61111111111111
    x[4,4]    conditional_Sx_lower_4_4  -8.6825396825396819e+00
    x[4,4]    conditional_Sx_upper_4_4  -3.9371428571428574e+01
    x[4,4]    conditional_complement_lower_4_4  8.61111111111111
    x[4,4]    conditional_complement_upper_4_4  39.6
    x[4,4]    hard_cost_D_definition  2.0363989413658206e-04
    x[4,5]    onehot_4  1
    x[4,5]    inventory_4  -5
    x[4,5]    product_lx_4_5  -8.61111111111111
    x[4,5]    product_ux_4_5  -39.6
    x[4,5]    product_Su_4_5  -39.6
    x[4,5]    product_Sl_4_5  -8.61111111111111
    x[4,5]    conditional_Sx_lower_4_5  -8.7003968253968242e+00
    x[4,5]    conditional_Sx_upper_4_5  -3.9314285714285717e+01
    x[4,5]    conditional_complement_lower_4_5  8.61111111111111
    x[4,5]    conditional_complement_upper_4_5  39.6
    x[4,5]    hard_cost_D_definition  4.0727978827316422e-04
    x[4,6]    onehot_4  1
    x[4,6]    inventory_4  -6
    x[4,6]    product_lx_4_6  -8.61111111111111
    x[4,6]    product_ux_4_6  -39.6
    x[4,6]    product_Su_4_6  -39.6
    x[4,6]    product_Sl_4_6  -8.61111111111111
    x[4,6]    conditional_Sx_lower_4_6  -8.7182539682539666e+00
    x[4,6]    conditional_Sx_upper_4_6  -3.9257142857142860e+01
    x[4,6]    conditional_complement_lower_4_6  8.61111111111111
    x[4,6]    conditional_complement_upper_4_6  39.6
    x[4,6]    hard_cost_D_definition  6.1091968240974636e-04
    x[4,7]    onehot_4  1
    x[4,7]    inventory_4  -7
    x[4,7]    product_lx_4_7  -8.61111111111111
    x[4,7]    product_ux_4_7  -39.6
    x[4,7]    product_Su_4_7  -39.6
    x[4,7]    product_Sl_4_7  -8.61111111111111
    x[4,7]    conditional_Sx_lower_4_7  -8.73611111111111
    x[4,7]    conditional_Sx_upper_4_7  -39.2
    x[4,7]    conditional_complement_lower_4_7  8.61111111111111
    x[4,7]    conditional_complement_upper_4_7  39.6
    x[4,7]    hard_cost_D_definition  8.1455957654632855e-04
    x[4,8]    onehot_4  1
    x[4,8]    inventory_4  -8
    x[4,8]    product_lx_4_8  -8.61111111111111
    x[4,8]    product_ux_4_8  -39.6
    x[4,8]    product_Su_4_8  -39.6
    x[4,8]    product_Sl_4_8  -8.61111111111111
    x[4,8]    conditional_Sx_lower_4_8  -8.7539682539682531e+00
    x[4,8]    conditional_Sx_upper_4_8  -3.9142857142857146e+01
    x[4,8]    conditional_complement_lower_4_8  8.61111111111111
    x[4,8]    conditional_complement_upper_4_8  39.6
    x[4,8]    hard_cost_D_definition  6.1091968240974657e-04
    x[4,9]    onehot_4  1
    x[4,9]    inventory_4  -9
    x[4,9]    product_lx_4_9  -8.61111111111111
    x[4,9]    product_ux_4_9  -39.6
    x[4,9]    product_Su_4_9  -39.6
    x[4,9]    product_Sl_4_9  -8.61111111111111
    x[4,9]    conditional_Sx_lower_4_9  -8.7718253968253954e+00
    x[4,9]    conditional_Sx_upper_4_9  -3.9085714285714289e+01
    x[4,9]    conditional_complement_lower_4_9  8.61111111111111
    x[4,9]    conditional_complement_upper_4_9  39.6
    x[4,9]    hard_cost_D_definition  4.0727978827316438e-04
    x[4,10]   onehot_4  1
    x[4,10]   inventory_4  -10
    x[4,10]   product_lx_4_10  -8.61111111111111
    x[4,10]   product_ux_4_10  -39.6
    x[4,10]   product_Su_4_10  -39.6
    x[4,10]   product_Sl_4_10  -8.61111111111111
    x[4,10]   conditional_Sx_lower_4_10  -8.7896825396825378e+00
    x[4,10]   conditional_Sx_upper_4_10  -3.9028571428571432e+01
    x[4,10]   conditional_complement_lower_4_10  8.61111111111111
    x[4,10]   conditional_complement_upper_4_10  39.6
    x[4,10]   hard_cost_D_definition  2.0363989413658222e-04
    x[4,11]   onehot_4  1
    x[4,11]   inventory_4  -11
    x[4,11]   product_lx_4_11  -8.61111111111111
    x[4,11]   product_ux_4_11  -39.6
    x[4,11]   product_Su_4_11  -39.6
    x[4,11]   product_Sl_4_11  -8.61111111111111
    x[4,11]   conditional_Sx_lower_4_11  -8.8075396825396819e+00
    x[4,11]   conditional_Sx_upper_4_11  -3.8971428571428575e+01
    x[4,11]   conditional_complement_lower_4_11  8.61111111111111
    x[4,11]   conditional_complement_upper_4_11  39.6
    x[4,12]   onehot_4  1
    x[4,12]   inventory_4  -12
    x[4,12]   product_lx_4_12  -8.61111111111111
    x[4,12]   product_ux_4_12  -39.6
    x[4,12]   product_Su_4_12  -39.6
    x[4,12]   product_Sl_4_12  -8.61111111111111
    x[4,12]   conditional_Sx_lower_4_12  -8.8253968253968242e+00
    x[4,12]   conditional_Sx_upper_4_12  -3.8914285714285718e+01
    x[4,12]   conditional_complement_lower_4_12  8.61111111111111
    x[4,12]   conditional_complement_upper_4_12  39.6
    x[4,12]   hard_cost_D_definition  -2.0363989413658203e-04
    x[4,13]   onehot_4  1
    x[4,13]   inventory_4  -13
    x[4,13]   product_lx_4_13  -8.61111111111111
    x[4,13]   product_ux_4_13  -39.6
    x[4,13]   product_Su_4_13  -39.6
    x[4,13]   product_Sl_4_13  -8.61111111111111
    x[4,13]   conditional_Sx_lower_4_13  -8.8432539682539666e+00
    x[4,13]   conditional_Sx_upper_4_13  -3.8857142857142861e+01
    x[4,13]   conditional_complement_lower_4_13  8.61111111111111
    x[4,13]   conditional_complement_upper_4_13  39.6
    x[4,13]   hard_cost_D_definition  -4.0727978827316417e-04
    x[4,14]   onehot_4  1
    x[4,14]   inventory_4  -14
    x[4,14]   product_lx_4_14  -8.61111111111111
    x[4,14]   product_ux_4_14  -39.6
    x[4,14]   product_Su_4_14  -39.6
    x[4,14]   product_Sl_4_14  -8.61111111111111
    x[4,14]   conditional_Sx_lower_4_14  -8.86111111111111
    x[4,14]   conditional_Sx_upper_4_14  -3.8800000000000004e+01
    x[4,14]   conditional_complement_lower_4_14  8.61111111111111
    x[4,14]   conditional_complement_upper_4_14  39.6
    x[4,14]   hard_cost_D_definition  -6.1091968240974625e-04
    x[4,15]   onehot_4  1
    x[4,15]   inventory_4  -15
    x[4,15]   product_lx_4_15  -8.61111111111111
    x[4,15]   product_ux_4_15  -39.6
    x[4,15]   product_Su_4_15  -39.6
    x[4,15]   product_Sl_4_15  -8.61111111111111
    x[4,15]   conditional_Sx_lower_4_15  -8.8789682539682531e+00
    x[4,15]   conditional_Sx_upper_4_15  -3.8742857142857147e+01
    x[4,15]   conditional_complement_lower_4_15  8.61111111111111
    x[4,15]   conditional_complement_upper_4_15  39.6
    x[4,15]   hard_cost_D_definition  -8.1455957654632844e-04
    x[5,0]    onehot_5  1
    x[5,0]    product_lx_5_0  -8.61111111111111
    x[5,0]    product_ux_5_0  -39.6
    x[5,0]    product_Su_5_0  -39.6
    x[5,0]    product_Sl_5_0  -8.61111111111111
    x[5,0]    conditional_Sx_lower_5_0  -8.61111111111111
    x[5,0]    conditional_Sx_upper_5_0  -39.6
    x[5,0]    conditional_complement_lower_5_0  8.6289682539682531e+00
    x[5,0]    conditional_complement_upper_5_0  3.9542857142857144e+01
    x[5,0]    hard_cost_D_definition  -6.1091968240974646e-04
    x[5,1]    onehot_5  1
    x[5,1]    inventory_5  -1
    x[5,1]    product_lx_5_1  -8.61111111111111
    x[5,1]    product_ux_5_1  -39.6
    x[5,1]    product_Su_5_1  -39.6
    x[5,1]    product_Sl_5_1  -8.61111111111111
    x[5,1]    conditional_Sx_lower_5_1  -8.6289682539682531e+00
    x[5,1]    conditional_Sx_upper_5_1  -3.9542857142857144e+01
    x[5,1]    conditional_complement_lower_5_1  8.61111111111111
    x[5,1]    conditional_complement_upper_5_1  39.6
    x[5,1]    hard_cost_D_definition  -4.0727978827316433e-04
    x[5,2]    onehot_5  1
    x[5,2]    inventory_5  -2
    x[5,2]    product_lx_5_2  -8.61111111111111
    x[5,2]    product_ux_5_2  -39.6
    x[5,2]    product_Su_5_2  -39.6
    x[5,2]    product_Sl_5_2  -8.61111111111111
    x[5,2]    conditional_Sx_lower_5_2  -8.6468253968253954e+00
    x[5,2]    conditional_Sx_upper_5_2  -3.9485714285714288e+01
    x[5,2]    conditional_complement_lower_5_2  8.61111111111111
    x[5,2]    conditional_complement_upper_5_2  39.6
    x[5,2]    hard_cost_D_definition  -2.0363989413658219e-04
    x[5,3]    onehot_5  1
    x[5,3]    inventory_5  -3
    x[5,3]    product_lx_5_3  -8.61111111111111
    x[5,3]    product_ux_5_3  -39.6
    x[5,3]    product_Su_5_3  -39.6
    x[5,3]    product_Sl_5_3  -8.61111111111111
    x[5,3]    conditional_Sx_lower_5_3  -8.66468253968254
    x[5,3]    conditional_Sx_upper_5_3  -3.9428571428571431e+01
    x[5,3]    conditional_complement_lower_5_3  8.61111111111111
    x[5,3]    conditional_complement_upper_5_3  39.6
    x[5,4]    onehot_5  1
    x[5,4]    inventory_5  -4
    x[5,4]    product_lx_5_4  -8.61111111111111
    x[5,4]    product_ux_5_4  -39.6
    x[5,4]    product_Su_5_4  -39.6
    x[5,4]    product_Sl_5_4  -8.61111111111111
    x[5,4]    conditional_Sx_lower_5_4  -8.6825396825396819e+00
    x[5,4]    conditional_Sx_upper_5_4  -3.9371428571428574e+01
    x[5,4]    conditional_complement_lower_5_4  8.61111111111111
    x[5,4]    conditional_complement_upper_5_4  39.6
    x[5,4]    hard_cost_D_definition  2.0363989413658206e-04
    x[5,5]    onehot_5  1
    x[5,5]    inventory_5  -5
    x[5,5]    product_lx_5_5  -8.61111111111111
    x[5,5]    product_ux_5_5  -39.6
    x[5,5]    product_Su_5_5  -39.6
    x[5,5]    product_Sl_5_5  -8.61111111111111
    x[5,5]    conditional_Sx_lower_5_5  -8.7003968253968242e+00
    x[5,5]    conditional_Sx_upper_5_5  -3.9314285714285717e+01
    x[5,5]    conditional_complement_lower_5_5  8.61111111111111
    x[5,5]    conditional_complement_upper_5_5  39.6
    x[5,5]    hard_cost_D_definition  4.0727978827316422e-04
    x[5,6]    onehot_5  1
    x[5,6]    inventory_5  -6
    x[5,6]    product_lx_5_6  -8.61111111111111
    x[5,6]    product_ux_5_6  -39.6
    x[5,6]    product_Su_5_6  -39.6
    x[5,6]    product_Sl_5_6  -8.61111111111111
    x[5,6]    conditional_Sx_lower_5_6  -8.7182539682539666e+00
    x[5,6]    conditional_Sx_upper_5_6  -3.9257142857142860e+01
    x[5,6]    conditional_complement_lower_5_6  8.61111111111111
    x[5,6]    conditional_complement_upper_5_6  39.6
    x[5,6]    hard_cost_D_definition  6.1091968240974636e-04
    x[5,7]    onehot_5  1
    x[5,7]    inventory_5  -7
    x[5,7]    product_lx_5_7  -8.61111111111111
    x[5,7]    product_ux_5_7  -39.6
    x[5,7]    product_Su_5_7  -39.6
    x[5,7]    product_Sl_5_7  -8.61111111111111
    x[5,7]    conditional_Sx_lower_5_7  -8.73611111111111
    x[5,7]    conditional_Sx_upper_5_7  -39.2
    x[5,7]    conditional_complement_lower_5_7  8.61111111111111
    x[5,7]    conditional_complement_upper_5_7  39.6
    x[5,7]    hard_cost_D_definition  8.1455957654632855e-04
    x[5,8]    onehot_5  1
    x[5,8]    inventory_5  -8
    x[5,8]    product_lx_5_8  -8.61111111111111
    x[5,8]    product_ux_5_8  -39.6
    x[5,8]    product_Su_5_8  -39.6
    x[5,8]    product_Sl_5_8  -8.61111111111111
    x[5,8]    conditional_Sx_lower_5_8  -8.7539682539682531e+00
    x[5,8]    conditional_Sx_upper_5_8  -3.9142857142857146e+01
    x[5,8]    conditional_complement_lower_5_8  8.61111111111111
    x[5,8]    conditional_complement_upper_5_8  39.6
    x[5,8]    hard_cost_D_definition  6.1091968240974657e-04
    x[5,9]    onehot_5  1
    x[5,9]    inventory_5  -9
    x[5,9]    product_lx_5_9  -8.61111111111111
    x[5,9]    product_ux_5_9  -39.6
    x[5,9]    product_Su_5_9  -39.6
    x[5,9]    product_Sl_5_9  -8.61111111111111
    x[5,9]    conditional_Sx_lower_5_9  -8.7718253968253954e+00
    x[5,9]    conditional_Sx_upper_5_9  -3.9085714285714289e+01
    x[5,9]    conditional_complement_lower_5_9  8.61111111111111
    x[5,9]    conditional_complement_upper_5_9  39.6
    x[5,9]    hard_cost_D_definition  4.0727978827316438e-04
    x[5,10]   onehot_5  1
    x[5,10]   inventory_5  -10
    x[5,10]   product_lx_5_10  -8.61111111111111
    x[5,10]   product_ux_5_10  -39.6
    x[5,10]   product_Su_5_10  -39.6
    x[5,10]   product_Sl_5_10  -8.61111111111111
    x[5,10]   conditional_Sx_lower_5_10  -8.7896825396825378e+00
    x[5,10]   conditional_Sx_upper_5_10  -3.9028571428571432e+01
    x[5,10]   conditional_complement_lower_5_10  8.61111111111111
    x[5,10]   conditional_complement_upper_5_10  39.6
    x[5,10]   hard_cost_D_definition  2.0363989413658222e-04
    x[5,11]   onehot_5  1
    x[5,11]   inventory_5  -11
    x[5,11]   product_lx_5_11  -8.61111111111111
    x[5,11]   product_ux_5_11  -39.6
    x[5,11]   product_Su_5_11  -39.6
    x[5,11]   product_Sl_5_11  -8.61111111111111
    x[5,11]   conditional_Sx_lower_5_11  -8.8075396825396819e+00
    x[5,11]   conditional_Sx_upper_5_11  -3.8971428571428575e+01
    x[5,11]   conditional_complement_lower_5_11  8.61111111111111
    x[5,11]   conditional_complement_upper_5_11  39.6
    x[5,12]   onehot_5  1
    x[5,12]   inventory_5  -12
    x[5,12]   product_lx_5_12  -8.61111111111111
    x[5,12]   product_ux_5_12  -39.6
    x[5,12]   product_Su_5_12  -39.6
    x[5,12]   product_Sl_5_12  -8.61111111111111
    x[5,12]   conditional_Sx_lower_5_12  -8.8253968253968242e+00
    x[5,12]   conditional_Sx_upper_5_12  -3.8914285714285718e+01
    x[5,12]   conditional_complement_lower_5_12  8.61111111111111
    x[5,12]   conditional_complement_upper_5_12  39.6
    x[5,12]   hard_cost_D_definition  -2.0363989413658203e-04
    x[5,13]   onehot_5  1
    x[5,13]   inventory_5  -13
    x[5,13]   product_lx_5_13  -8.61111111111111
    x[5,13]   product_ux_5_13  -39.6
    x[5,13]   product_Su_5_13  -39.6
    x[5,13]   product_Sl_5_13  -8.61111111111111
    x[5,13]   conditional_Sx_lower_5_13  -8.8432539682539666e+00
    x[5,13]   conditional_Sx_upper_5_13  -3.8857142857142861e+01
    x[5,13]   conditional_complement_lower_5_13  8.61111111111111
    x[5,13]   conditional_complement_upper_5_13  39.6
    x[5,13]   hard_cost_D_definition  -4.0727978827316417e-04
    x[5,14]   onehot_5  1
    x[5,14]   inventory_5  -14
    x[5,14]   product_lx_5_14  -8.61111111111111
    x[5,14]   product_ux_5_14  -39.6
    x[5,14]   product_Su_5_14  -39.6
    x[5,14]   product_Sl_5_14  -8.61111111111111
    x[5,14]   conditional_Sx_lower_5_14  -8.86111111111111
    x[5,14]   conditional_Sx_upper_5_14  -3.8800000000000004e+01
    x[5,14]   conditional_complement_lower_5_14  8.61111111111111
    x[5,14]   conditional_complement_upper_5_14  39.6
    x[5,14]   hard_cost_D_definition  -6.1091968240974625e-04
    x[5,15]   onehot_5  1
    x[5,15]   inventory_5  -15
    x[5,15]   product_lx_5_15  -8.61111111111111
    x[5,15]   product_ux_5_15  -39.6
    x[5,15]   product_Su_5_15  -39.6
    x[5,15]   product_Sl_5_15  -8.61111111111111
    x[5,15]   conditional_Sx_lower_5_15  -8.8789682539682531e+00
    x[5,15]   conditional_Sx_upper_5_15  -3.8742857142857147e+01
    x[5,15]   conditional_complement_lower_5_15  8.61111111111111
    x[5,15]   conditional_complement_upper_5_15  39.6
    x[5,15]   hard_cost_D_definition  -8.1455957654632844e-04
    x[6,0]    onehot_6  1
    x[6,0]    product_lx_6_0  -8.61111111111111
    x[6,0]    product_ux_6_0  -39.6
    x[6,0]    product_Su_6_0  -39.6
    x[6,0]    product_Sl_6_0  -8.61111111111111
    x[6,0]    conditional_Sx_lower_6_0  -8.61111111111111
    x[6,0]    conditional_Sx_upper_6_0  -39.2
    x[6,0]    conditional_complement_lower_6_0  8.73611111111111
    x[6,0]    conditional_complement_upper_6_0  39.6
    x[6,0]    hard_cost_D_definition  -2.3273157207916555e-04
    x[6,1]    onehot_6  1
    x[6,1]    inventory_6  -1
    x[6,1]    product_lx_6_1  -8.61111111111111
    x[6,1]    product_ux_6_1  -39.6
    x[6,1]    product_Su_6_1  -39.6
    x[6,1]    product_Sl_6_1  -8.61111111111111
    x[6,1]    conditional_Sx_lower_6_1  -8.73611111111111
    x[6,1]    conditional_Sx_upper_6_1  -3.9250000000000007e+01
    x[6,1]    conditional_complement_lower_6_1  8.61111111111111
    x[6,1]    conditional_complement_upper_6_1  39.6
    x[6,1]    hard_cost_D_definition  -1.1636578603958278e-04
    x[6,2]    onehot_6  1
    x[6,2]    inventory_6  -2
    x[6,2]    product_lx_6_2  -8.61111111111111
    x[6,2]    product_ux_6_2  -39.6
    x[6,2]    product_Su_6_2  -39.6
    x[6,2]    product_Sl_6_2  -8.61111111111111
    x[6,2]    conditional_Sx_lower_6_2  -8.86111111111111
    x[6,2]    conditional_Sx_upper_6_2  -3.9300000000000004e+01
    x[6,2]    conditional_complement_lower_6_2  8.61111111111111
    x[6,2]    conditional_complement_upper_6_2  39.6
    x[6,3]    onehot_6  1
    x[6,3]    inventory_6  -3
    x[6,3]    product_lx_6_3  -8.61111111111111
    x[6,3]    product_ux_6_3  -39.6
    x[6,3]    product_Su_6_3  -39.6
    x[6,3]    product_Sl_6_3  -8.61111111111111
    x[6,3]    conditional_Sx_lower_6_3  -8.98611111111111
    x[6,3]    conditional_Sx_upper_6_3  -39.35
    x[6,3]    conditional_complement_lower_6_3  8.61111111111111
    x[6,3]    conditional_complement_upper_6_3  39.6
    x[6,3]    hard_cost_D_definition  1.1636578603958278e-04
    x[6,4]    onehot_6  1
    x[6,4]    inventory_6  -4
    x[6,4]    product_lx_6_4  -8.61111111111111
    x[6,4]    product_ux_6_4  -39.6
    x[6,4]    product_Su_6_4  -39.6
    x[6,4]    product_Sl_6_4  -8.61111111111111
    x[6,4]    conditional_Sx_lower_6_4  -9.11111111111111
    x[6,4]    conditional_Sx_upper_6_4  -3.9400000000000006e+01
    x[6,4]    conditional_complement_lower_6_4  8.61111111111111
    x[6,4]    conditional_complement_upper_6_4  39.6
    x[6,4]    hard_cost_D_definition  2.3273157207916555e-04
    x[6,5]    onehot_6  1
    x[6,5]    inventory_6  -5
    x[6,5]    product_lx_6_5  -8.61111111111111
    x[6,5]    product_ux_6_5  -39.6
    x[6,5]    product_Su_6_5  -39.6
    x[6,5]    product_Sl_6_5  -8.61111111111111
    x[6,5]    conditional_Sx_lower_6_5  -9.23611111111111
    x[6,5]    conditional_Sx_upper_6_5  -39.45
    x[6,5]    conditional_complement_lower_6_5  8.61111111111111
    x[6,5]    conditional_complement_upper_6_5  39.6
    x[6,5]    hard_cost_D_definition  1.1636578603958278e-04
    x[6,6]    onehot_6  1
    x[6,6]    inventory_6  -6
    x[6,6]    product_lx_6_6  -8.61111111111111
    x[6,6]    product_ux_6_6  -39.6
    x[6,6]    product_Su_6_6  -39.6
    x[6,6]    product_Sl_6_6  -8.61111111111111
    x[6,6]    conditional_Sx_lower_6_6  -9.36111111111111
    x[6,6]    conditional_Sx_upper_6_6  -3.9500000000000007e+01
    x[6,6]    conditional_complement_lower_6_6  8.61111111111111
    x[6,6]    conditional_complement_upper_6_6  39.6
    x[6,7]    onehot_6  1
    x[6,7]    inventory_6  -7
    x[6,7]    product_lx_6_7  -8.61111111111111
    x[6,7]    product_ux_6_7  -39.6
    x[6,7]    product_Su_6_7  -39.6
    x[6,7]    product_Sl_6_7  -8.61111111111111
    x[6,7]    conditional_Sx_lower_6_7  -9.48611111111111
    x[6,7]    conditional_Sx_upper_6_7  -3.9550000000000004e+01
    x[6,7]    conditional_complement_lower_6_7  8.61111111111111
    x[6,7]    conditional_complement_upper_6_7  39.6
    x[6,7]    hard_cost_D_definition  -1.1636578603958278e-04
    x[6,8]    onehot_6  1
    x[6,8]    inventory_6  -8
    x[6,8]    product_lx_6_8  -8.61111111111111
    x[6,8]    product_ux_6_8  -39.6
    x[6,8]    product_Su_6_8  -39.6
    x[6,8]    product_Sl_6_8  -8.61111111111111
    x[6,8]    conditional_Sx_lower_6_8  -9.61111111111111
    x[6,8]    conditional_Sx_upper_6_8  -39.6
    x[6,8]    conditional_complement_lower_6_8  8.61111111111111
    x[6,8]    conditional_complement_upper_6_8  3.9550000000000004e+01
    x[6,8]    hard_cost_D_definition  -2.3273157207916555e-04
    x[7,0]    onehot_7  1
    x[7,0]    product_lx_7_0  -8.61111111111111
    x[7,0]    product_ux_7_0  -39.6
    x[7,0]    product_Su_7_0  -39.6
    x[7,0]    product_Sl_7_0  -8.61111111111111
    x[7,0]    conditional_Sx_lower_7_0  -8.61111111111111
    x[7,0]    conditional_Sx_upper_7_0  -39.6
    x[7,0]    conditional_complement_lower_7_0  8.6289682539682531e+00
    x[7,0]    conditional_complement_upper_7_0  3.9542857142857144e+01
    x[7,0]    hard_cost_D_definition  -6.1091968240974646e-04
    x[7,1]    onehot_7  1
    x[7,1]    inventory_7  -1
    x[7,1]    product_lx_7_1  -8.61111111111111
    x[7,1]    product_ux_7_1  -39.6
    x[7,1]    product_Su_7_1  -39.6
    x[7,1]    product_Sl_7_1  -8.61111111111111
    x[7,1]    conditional_Sx_lower_7_1  -8.6289682539682531e+00
    x[7,1]    conditional_Sx_upper_7_1  -3.9542857142857144e+01
    x[7,1]    conditional_complement_lower_7_1  8.61111111111111
    x[7,1]    conditional_complement_upper_7_1  39.6
    x[7,1]    hard_cost_D_definition  -4.0727978827316433e-04
    x[7,2]    onehot_7  1
    x[7,2]    inventory_7  -2
    x[7,2]    product_lx_7_2  -8.61111111111111
    x[7,2]    product_ux_7_2  -39.6
    x[7,2]    product_Su_7_2  -39.6
    x[7,2]    product_Sl_7_2  -8.61111111111111
    x[7,2]    conditional_Sx_lower_7_2  -8.6468253968253954e+00
    x[7,2]    conditional_Sx_upper_7_2  -3.9485714285714288e+01
    x[7,2]    conditional_complement_lower_7_2  8.61111111111111
    x[7,2]    conditional_complement_upper_7_2  39.6
    x[7,2]    hard_cost_D_definition  -2.0363989413658219e-04
    x[7,3]    onehot_7  1
    x[7,3]    inventory_7  -3
    x[7,3]    product_lx_7_3  -8.61111111111111
    x[7,3]    product_ux_7_3  -39.6
    x[7,3]    product_Su_7_3  -39.6
    x[7,3]    product_Sl_7_3  -8.61111111111111
    x[7,3]    conditional_Sx_lower_7_3  -8.66468253968254
    x[7,3]    conditional_Sx_upper_7_3  -3.9428571428571431e+01
    x[7,3]    conditional_complement_lower_7_3  8.61111111111111
    x[7,3]    conditional_complement_upper_7_3  39.6
    x[7,4]    onehot_7  1
    x[7,4]    inventory_7  -4
    x[7,4]    product_lx_7_4  -8.61111111111111
    x[7,4]    product_ux_7_4  -39.6
    x[7,4]    product_Su_7_4  -39.6
    x[7,4]    product_Sl_7_4  -8.61111111111111
    x[7,4]    conditional_Sx_lower_7_4  -8.6825396825396819e+00
    x[7,4]    conditional_Sx_upper_7_4  -3.9371428571428574e+01
    x[7,4]    conditional_complement_lower_7_4  8.61111111111111
    x[7,4]    conditional_complement_upper_7_4  39.6
    x[7,4]    hard_cost_D_definition  2.0363989413658206e-04
    x[7,5]    onehot_7  1
    x[7,5]    inventory_7  -5
    x[7,5]    product_lx_7_5  -8.61111111111111
    x[7,5]    product_ux_7_5  -39.6
    x[7,5]    product_Su_7_5  -39.6
    x[7,5]    product_Sl_7_5  -8.61111111111111
    x[7,5]    conditional_Sx_lower_7_5  -8.7003968253968242e+00
    x[7,5]    conditional_Sx_upper_7_5  -3.9314285714285717e+01
    x[7,5]    conditional_complement_lower_7_5  8.61111111111111
    x[7,5]    conditional_complement_upper_7_5  39.6
    x[7,5]    hard_cost_D_definition  4.0727978827316422e-04
    x[7,6]    onehot_7  1
    x[7,6]    inventory_7  -6
    x[7,6]    product_lx_7_6  -8.61111111111111
    x[7,6]    product_ux_7_6  -39.6
    x[7,6]    product_Su_7_6  -39.6
    x[7,6]    product_Sl_7_6  -8.61111111111111
    x[7,6]    conditional_Sx_lower_7_6  -8.7182539682539666e+00
    x[7,6]    conditional_Sx_upper_7_6  -3.9257142857142860e+01
    x[7,6]    conditional_complement_lower_7_6  8.61111111111111
    x[7,6]    conditional_complement_upper_7_6  39.6
    x[7,6]    hard_cost_D_definition  6.1091968240974636e-04
    x[7,7]    onehot_7  1
    x[7,7]    inventory_7  -7
    x[7,7]    product_lx_7_7  -8.61111111111111
    x[7,7]    product_ux_7_7  -39.6
    x[7,7]    product_Su_7_7  -39.6
    x[7,7]    product_Sl_7_7  -8.61111111111111
    x[7,7]    conditional_Sx_lower_7_7  -8.73611111111111
    x[7,7]    conditional_Sx_upper_7_7  -39.2
    x[7,7]    conditional_complement_lower_7_7  8.61111111111111
    x[7,7]    conditional_complement_upper_7_7  39.6
    x[7,7]    hard_cost_D_definition  8.1455957654632855e-04
    x[7,8]    onehot_7  1
    x[7,8]    inventory_7  -8
    x[7,8]    product_lx_7_8  -8.61111111111111
    x[7,8]    product_ux_7_8  -39.6
    x[7,8]    product_Su_7_8  -39.6
    x[7,8]    product_Sl_7_8  -8.61111111111111
    x[7,8]    conditional_Sx_lower_7_8  -8.7539682539682531e+00
    x[7,8]    conditional_Sx_upper_7_8  -3.9142857142857146e+01
    x[7,8]    conditional_complement_lower_7_8  8.61111111111111
    x[7,8]    conditional_complement_upper_7_8  39.6
    x[7,8]    hard_cost_D_definition  6.1091968240974657e-04
    x[7,9]    onehot_7  1
    x[7,9]    inventory_7  -9
    x[7,9]    product_lx_7_9  -8.61111111111111
    x[7,9]    product_ux_7_9  -39.6
    x[7,9]    product_Su_7_9  -39.6
    x[7,9]    product_Sl_7_9  -8.61111111111111
    x[7,9]    conditional_Sx_lower_7_9  -8.7718253968253954e+00
    x[7,9]    conditional_Sx_upper_7_9  -3.9085714285714289e+01
    x[7,9]    conditional_complement_lower_7_9  8.61111111111111
    x[7,9]    conditional_complement_upper_7_9  39.6
    x[7,9]    hard_cost_D_definition  4.0727978827316438e-04
    x[7,10]   onehot_7  1
    x[7,10]   inventory_7  -10
    x[7,10]   product_lx_7_10  -8.61111111111111
    x[7,10]   product_ux_7_10  -39.6
    x[7,10]   product_Su_7_10  -39.6
    x[7,10]   product_Sl_7_10  -8.61111111111111
    x[7,10]   conditional_Sx_lower_7_10  -8.7896825396825378e+00
    x[7,10]   conditional_Sx_upper_7_10  -3.9028571428571432e+01
    x[7,10]   conditional_complement_lower_7_10  8.61111111111111
    x[7,10]   conditional_complement_upper_7_10  39.6
    x[7,10]   hard_cost_D_definition  2.0363989413658222e-04
    x[7,11]   onehot_7  1
    x[7,11]   inventory_7  -11
    x[7,11]   product_lx_7_11  -8.61111111111111
    x[7,11]   product_ux_7_11  -39.6
    x[7,11]   product_Su_7_11  -39.6
    x[7,11]   product_Sl_7_11  -8.61111111111111
    x[7,11]   conditional_Sx_lower_7_11  -8.8075396825396819e+00
    x[7,11]   conditional_Sx_upper_7_11  -3.8971428571428575e+01
    x[7,11]   conditional_complement_lower_7_11  8.61111111111111
    x[7,11]   conditional_complement_upper_7_11  39.6
    x[7,12]   onehot_7  1
    x[7,12]   inventory_7  -12
    x[7,12]   product_lx_7_12  -8.61111111111111
    x[7,12]   product_ux_7_12  -39.6
    x[7,12]   product_Su_7_12  -39.6
    x[7,12]   product_Sl_7_12  -8.61111111111111
    x[7,12]   conditional_Sx_lower_7_12  -8.8253968253968242e+00
    x[7,12]   conditional_Sx_upper_7_12  -3.8914285714285718e+01
    x[7,12]   conditional_complement_lower_7_12  8.61111111111111
    x[7,12]   conditional_complement_upper_7_12  39.6
    x[7,12]   hard_cost_D_definition  -2.0363989413658203e-04
    x[7,13]   onehot_7  1
    x[7,13]   inventory_7  -13
    x[7,13]   product_lx_7_13  -8.61111111111111
    x[7,13]   product_ux_7_13  -39.6
    x[7,13]   product_Su_7_13  -39.6
    x[7,13]   product_Sl_7_13  -8.61111111111111
    x[7,13]   conditional_Sx_lower_7_13  -8.8432539682539666e+00
    x[7,13]   conditional_Sx_upper_7_13  -3.8857142857142861e+01
    x[7,13]   conditional_complement_lower_7_13  8.61111111111111
    x[7,13]   conditional_complement_upper_7_13  39.6
    x[7,13]   hard_cost_D_definition  -4.0727978827316417e-04
    x[7,14]   onehot_7  1
    x[7,14]   inventory_7  -14
    x[7,14]   product_lx_7_14  -8.61111111111111
    x[7,14]   product_ux_7_14  -39.6
    x[7,14]   product_Su_7_14  -39.6
    x[7,14]   product_Sl_7_14  -8.61111111111111
    x[7,14]   conditional_Sx_lower_7_14  -8.86111111111111
    x[7,14]   conditional_Sx_upper_7_14  -3.8800000000000004e+01
    x[7,14]   conditional_complement_lower_7_14  8.61111111111111
    x[7,14]   conditional_complement_upper_7_14  39.6
    x[7,14]   hard_cost_D_definition  -6.1091968240974625e-04
    x[7,15]   onehot_7  1
    x[7,15]   inventory_7  -15
    x[7,15]   product_lx_7_15  -8.61111111111111
    x[7,15]   product_ux_7_15  -39.6
    x[7,15]   product_Su_7_15  -39.6
    x[7,15]   product_Sl_7_15  -8.61111111111111
    x[7,15]   conditional_Sx_lower_7_15  -8.8789682539682531e+00
    x[7,15]   conditional_Sx_upper_7_15  -3.8742857142857147e+01
    x[7,15]   conditional_complement_lower_7_15  8.61111111111111
    x[7,15]   conditional_complement_upper_7_15  39.6
    x[7,15]   hard_cost_D_definition  -8.1455957654632844e-04
    x[8,0]    onehot_8  1
    x[8,0]    product_lx_8_0  -8.61111111111111
    x[8,0]    product_ux_8_0  -39.6
    x[8,0]    product_Su_8_0  -39.6
    x[8,0]    product_Sl_8_0  -8.61111111111111
    x[8,0]    conditional_Sx_lower_8_0  -8.61111111111111
    x[8,0]    conditional_Sx_upper_8_0  -39.6
    x[8,0]    conditional_complement_lower_8_0  8.6527777777777768e+00
    x[8,0]    conditional_complement_upper_8_0  3.9566666666666670e+01
    x[8,0]    hard_cost_D_definition  -5.2364515352604213e-04
    x[8,1]    onehot_8  1
    x[8,1]    inventory_8  -1
    x[8,1]    product_lx_8_1  -8.61111111111111
    x[8,1]    product_ux_8_1  -39.6
    x[8,1]    product_Su_8_1  -39.6
    x[8,1]    product_Sl_8_1  -8.61111111111111
    x[8,1]    conditional_Sx_lower_8_1  -8.6527777777777768e+00
    x[8,1]    conditional_Sx_upper_8_1  -3.9566666666666670e+01
    x[8,1]    conditional_complement_lower_8_1  8.61111111111111
    x[8,1]    conditional_complement_upper_8_1  39.6
    x[8,1]    hard_cost_D_definition  -3.4909676901736142e-04
    x[8,2]    onehot_8  1
    x[8,2]    inventory_8  -2
    x[8,2]    product_lx_8_2  -8.61111111111111
    x[8,2]    product_ux_8_2  -39.6
    x[8,2]    product_Su_8_2  -39.6
    x[8,2]    product_Sl_8_2  -8.61111111111111
    x[8,2]    conditional_Sx_lower_8_2  -8.6944444444444429e+00
    x[8,2]    conditional_Sx_upper_8_2  -3.9533333333333339e+01
    x[8,2]    conditional_complement_lower_8_2  8.61111111111111
    x[8,2]    conditional_complement_upper_8_2  39.6
    x[8,2]    hard_cost_D_definition  -1.7454838450868071e-04
    x[8,3]    onehot_8  1
    x[8,3]    inventory_8  -3
    x[8,3]    product_lx_8_3  -8.61111111111111
    x[8,3]    product_ux_8_3  -39.6
    x[8,3]    product_Su_8_3  -39.6
    x[8,3]    product_Sl_8_3  -8.61111111111111
    x[8,3]    conditional_Sx_lower_8_3  -8.73611111111111
    x[8,3]    conditional_Sx_upper_8_3  -39.5
    x[8,3]    conditional_complement_lower_8_3  8.61111111111111
    x[8,3]    conditional_complement_upper_8_3  39.6
    x[8,4]    onehot_8  1
    x[8,4]    inventory_8  -4
    x[8,4]    product_lx_8_4  -8.61111111111111
    x[8,4]    product_ux_8_4  -39.6
    x[8,4]    product_Su_8_4  -39.6
    x[8,4]    product_Sl_8_4  -8.61111111111111
    x[8,4]    conditional_Sx_lower_8_4  -8.7777777777777768e+00
    x[8,4]    conditional_Sx_upper_8_4  -3.9466666666666669e+01
    x[8,4]    conditional_complement_lower_8_4  8.61111111111111
    x[8,4]    conditional_complement_upper_8_4  39.6
    x[8,4]    hard_cost_D_definition  1.7454838450868074e-04
    x[8,5]    onehot_8  1
    x[8,5]    inventory_8  -5
    x[8,5]    product_lx_8_5  -8.61111111111111
    x[8,5]    product_ux_8_5  -39.6
    x[8,5]    product_Su_8_5  -39.6
    x[8,5]    product_Sl_8_5  -8.61111111111111
    x[8,5]    conditional_Sx_lower_8_5  -8.8194444444444429e+00
    x[8,5]    conditional_Sx_upper_8_5  -3.9433333333333337e+01
    x[8,5]    conditional_complement_lower_8_5  8.61111111111111
    x[8,5]    conditional_complement_upper_8_5  39.6
    x[8,5]    hard_cost_D_definition  3.4909676901736148e-04
    x[8,6]    onehot_8  1
    x[8,6]    inventory_8  -6
    x[8,6]    product_lx_8_6  -8.61111111111111
    x[8,6]    product_ux_8_6  -39.6
    x[8,6]    product_Su_8_6  -39.6
    x[8,6]    product_Sl_8_6  -8.61111111111111
    x[8,6]    conditional_Sx_lower_8_6  -8.86111111111111
    x[8,6]    conditional_Sx_upper_8_6  -3.9400000000000006e+01
    x[8,6]    conditional_complement_lower_8_6  8.61111111111111
    x[8,6]    conditional_complement_upper_8_6  39.6
    x[8,6]    hard_cost_D_definition  5.2364515352604224e-04
    x[8,7]    onehot_8  1
    x[8,7]    inventory_8  -7
    x[8,7]    product_lx_8_7  -8.61111111111111
    x[8,7]    product_ux_8_7  -39.6
    x[8,7]    product_Su_8_7  -39.6
    x[8,7]    product_Sl_8_7  -8.61111111111111
    x[8,7]    conditional_Sx_lower_8_7  -8.9027777777777768e+00
    x[8,7]    conditional_Sx_upper_8_7  -3.9366666666666667e+01
    x[8,7]    conditional_complement_lower_8_7  8.61111111111111
    x[8,7]    conditional_complement_upper_8_7  39.6
    x[8,7]    hard_cost_D_definition  3.4909676901736164e-04
    x[8,8]    onehot_8  1
    x[8,8]    inventory_8  -8
    x[8,8]    product_lx_8_8  -8.61111111111111
    x[8,8]    product_ux_8_8  -39.6
    x[8,8]    product_Su_8_8  -39.6
    x[8,8]    product_Sl_8_8  -8.61111111111111
    x[8,8]    conditional_Sx_lower_8_8  -8.9444444444444429e+00
    x[8,8]    conditional_Sx_upper_8_8  -3.9333333333333336e+01
    x[8,8]    conditional_complement_lower_8_8  8.61111111111111
    x[8,8]    conditional_complement_upper_8_8  39.6
    x[8,8]    hard_cost_D_definition  1.7454838450868087e-04
    x[8,9]    onehot_8  1
    x[8,9]    inventory_8  -9
    x[8,9]    product_lx_8_9  -8.61111111111111
    x[8,9]    product_ux_8_9  -39.6
    x[8,9]    product_Su_8_9  -39.6
    x[8,9]    product_Sl_8_9  -8.61111111111111
    x[8,9]    conditional_Sx_lower_8_9  -8.98611111111111
    x[8,9]    conditional_Sx_upper_8_9  -3.9300000000000004e+01
    x[8,9]    conditional_complement_lower_8_9  8.61111111111111
    x[8,9]    conditional_complement_upper_8_9  39.6
    x[8,10]   onehot_8  1
    x[8,10]   inventory_8  -10
    x[8,10]   product_lx_8_10  -8.61111111111111
    x[8,10]   product_ux_8_10  -39.6
    x[8,10]   product_Su_8_10  -39.6
    x[8,10]   product_Sl_8_10  -8.61111111111111
    x[8,10]   conditional_Sx_lower_8_10  -9.0277777777777768e+00
    x[8,10]   conditional_Sx_upper_8_10  -3.9266666666666673e+01
    x[8,10]   conditional_complement_lower_8_10  8.61111111111111
    x[8,10]   conditional_complement_upper_8_10  39.6
    x[8,10]   hard_cost_D_definition  -1.7454838450868060e-04
    x[8,11]   onehot_8  1
    x[8,11]   inventory_8  -11
    x[8,11]   product_lx_8_11  -8.61111111111111
    x[8,11]   product_ux_8_11  -39.6
    x[8,11]   product_Su_8_11  -39.6
    x[8,11]   product_Sl_8_11  -8.61111111111111
    x[8,11]   conditional_Sx_lower_8_11  -9.0694444444444429e+00
    x[8,11]   conditional_Sx_upper_8_11  -3.9233333333333334e+01
    x[8,11]   conditional_complement_lower_8_11  8.61111111111111
    x[8,11]   conditional_complement_upper_8_11  39.6
    x[8,11]   hard_cost_D_definition  -3.4909676901736131e-04
    x[8,12]   onehot_8  1
    x[8,12]   inventory_8  -12
    x[8,12]   product_lx_8_12  -8.61111111111111
    x[8,12]   product_ux_8_12  -39.6
    x[8,12]   product_Su_8_12  -39.6
    x[8,12]   product_Sl_8_12  -8.61111111111111
    x[8,12]   conditional_Sx_lower_8_12  -9.11111111111111
    x[8,12]   conditional_Sx_upper_8_12  -39.2
    x[8,12]   conditional_complement_lower_8_12  8.61111111111111
    x[8,12]   conditional_complement_upper_8_12  39.6
    x[8,12]   hard_cost_D_definition  -0.000523645153526042
    x[9,0]    onehot_9  1
    x[9,0]    product_lx_9_0  -8.61111111111111
    x[9,0]    product_ux_9_0  -39.6
    x[9,0]    product_Su_9_0  -39.6
    x[9,0]    product_Sl_9_0  -8.61111111111111
    x[9,0]    conditional_Sx_lower_9_0  -8.61111111111111
    x[9,0]    conditional_Sx_upper_9_0  -39.6
    x[9,0]    conditional_complement_lower_9_0  8.68611111111111
    x[9,0]    conditional_complement_upper_9_0  39.6
    x[9,0]    hard_cost_D_definition  -3.6364286046067603e-04
    x[9,1]    onehot_9  1
    x[9,1]    inventory_9  -1
    x[9,1]    product_lx_9_1  -8.61111111111111
    x[9,1]    product_ux_9_1  -39.6
    x[9,1]    product_Su_9_1  -39.6
    x[9,1]    product_Sl_9_1  -8.61111111111111
    x[9,1]    conditional_Sx_lower_9_1  -8.68611111111111
    x[9,1]    conditional_Sx_upper_9_1  -39.6
    x[9,1]    conditional_complement_lower_9_1  8.61111111111111
    x[9,1]    conditional_complement_upper_9_1  39.6
    x[9,1]    hard_cost_D_definition  -2.1818571627640559e-04
    x[9,2]    onehot_9  1
    x[9,2]    inventory_9  -2
    x[9,2]    product_lx_9_2  -8.61111111111111
    x[9,2]    product_ux_9_2  -39.6
    x[9,2]    product_Su_9_2  -39.6
    x[9,2]    product_Sl_9_2  -8.61111111111111
    x[9,2]    conditional_Sx_lower_9_2  -8.76111111111111
    x[9,2]    conditional_Sx_upper_9_2  -39.6
    x[9,2]    conditional_complement_lower_9_2  8.61111111111111
    x[9,2]    conditional_complement_upper_9_2  39.6
    x[9,2]    hard_cost_D_definition  -7.2728572092135138e-05
    x[9,3]    onehot_9  1
    x[9,3]    inventory_9  -3
    x[9,3]    product_lx_9_3  -8.61111111111111
    x[9,3]    product_ux_9_3  -39.6
    x[9,3]    product_Su_9_3  -39.6
    x[9,3]    product_Sl_9_3  -8.61111111111111
    x[9,3]    conditional_Sx_lower_9_3  -8.83611111111111
    x[9,3]    conditional_Sx_upper_9_3  -39.6
    x[9,3]    conditional_complement_lower_9_3  8.61111111111111
    x[9,3]    conditional_complement_upper_9_3  39.6
    x[9,3]    hard_cost_D_definition  7.2728572092135315e-05
    x[9,4]    onehot_9  1
    x[9,4]    inventory_9  -4
    x[9,4]    product_lx_9_4  -8.61111111111111
    x[9,4]    product_ux_9_4  -39.6
    x[9,4]    product_Su_9_4  -39.6
    x[9,4]    product_Sl_9_4  -8.61111111111111
    x[9,4]    conditional_Sx_lower_9_4  -8.91111111111111
    x[9,4]    conditional_Sx_upper_9_4  -39.6
    x[9,4]    conditional_complement_lower_9_4  8.61111111111111
    x[9,4]    conditional_complement_upper_9_4  39.6
    x[9,4]    hard_cost_D_definition  2.1818571627640578e-04
    x[9,5]    onehot_9  1
    x[9,5]    inventory_9  -5
    x[9,5]    product_lx_9_5  -8.61111111111111
    x[9,5]    product_ux_9_5  -39.6
    x[9,5]    product_Su_9_5  -39.6
    x[9,5]    product_Sl_9_5  -8.61111111111111
    x[9,5]    conditional_Sx_lower_9_5  -8.98611111111111
    x[9,5]    conditional_Sx_upper_9_5  -39.6
    x[9,5]    conditional_complement_lower_9_5  8.61111111111111
    x[9,5]    conditional_complement_upper_9_5  39.6
    x[9,5]    hard_cost_D_definition  3.6364286046067619e-04
    x[9,6]    onehot_9  1
    x[9,6]    inventory_9  -6
    x[9,6]    product_lx_9_6  -8.61111111111111
    x[9,6]    product_ux_9_6  -39.6
    x[9,6]    product_Su_9_6  -39.6
    x[9,6]    product_Sl_9_6  -8.61111111111111
    x[9,6]    conditional_Sx_lower_9_6  -9.06111111111111
    x[9,6]    conditional_Sx_upper_9_6  -39.6
    x[9,6]    conditional_complement_lower_9_6  8.61111111111111
    x[9,6]    conditional_complement_upper_9_6  39.6
    x[9,6]    hard_cost_D_definition  2.1818571627640570e-04
    x[9,7]    onehot_9  1
    x[9,7]    inventory_9  -7
    x[9,7]    product_lx_9_7  -8.61111111111111
    x[9,7]    product_ux_9_7  -39.6
    x[9,7]    product_Su_9_7  -39.6
    x[9,7]    product_Sl_9_7  -8.61111111111111
    x[9,7]    conditional_Sx_lower_9_7  -9.1361111111111111e+00
    x[9,7]    conditional_Sx_upper_9_7  -39.6
    x[9,7]    conditional_complement_lower_9_7  8.61111111111111
    x[9,7]    conditional_complement_upper_9_7  39.6
    x[9,7]    hard_cost_D_definition  7.2728572092135233e-05
    x[9,8]    onehot_9  1
    x[9,8]    inventory_9  -8
    x[9,8]    product_lx_9_8  -8.61111111111111
    x[9,8]    product_ux_9_8  -39.6
    x[9,8]    product_Su_9_8  -39.6
    x[9,8]    product_Sl_9_8  -8.61111111111111
    x[9,8]    conditional_Sx_lower_9_8  -9.21111111111111
    x[9,8]    conditional_Sx_upper_9_8  -39.6
    x[9,8]    conditional_complement_lower_9_8  8.61111111111111
    x[9,8]    conditional_complement_upper_9_8  39.6
    x[9,8]    hard_cost_D_definition  -7.2728572092135220e-05
    x[9,9]    onehot_9  1
    x[9,9]    inventory_9  -9
    x[9,9]    product_lx_9_9  -8.61111111111111
    x[9,9]    product_ux_9_9  -39.6
    x[9,9]    product_Su_9_9  -39.6
    x[9,9]    product_Sl_9_9  -8.61111111111111
    x[9,9]    conditional_Sx_lower_9_9  -9.28611111111111
    x[9,9]    conditional_Sx_upper_9_9  -39.6
    x[9,9]    conditional_complement_lower_9_9  8.61111111111111
    x[9,9]    conditional_complement_upper_9_9  39.6
    x[9,9]    hard_cost_D_definition  -2.1818571627640567e-04
    x[9,10]   onehot_9  1
    x[9,10]   inventory_9  -10
    x[9,10]   product_lx_9_10  -8.61111111111111
    x[9,10]   product_ux_9_10  -39.6
    x[9,10]   product_Su_9_10  -39.6
    x[9,10]   product_Sl_9_10  -8.61111111111111
    x[9,10]   conditional_Sx_lower_9_10  -9.36111111111111
    x[9,10]   conditional_Sx_upper_9_10  -39.6
    x[9,10]   conditional_complement_lower_9_10  8.61111111111111
    x[9,10]   conditional_complement_upper_9_10  39.6
    x[9,10]   hard_cost_D_definition  -3.6364286046067614e-04
    x[10,0]   onehot_10  1
    x[10,0]   product_lx_10_0  -8.61111111111111
    x[10,0]   product_ux_10_0  -39.6
    x[10,0]   product_Su_10_0  -39.6
    x[10,0]   product_Sl_10_0  -8.61111111111111
    x[10,0]   conditional_Sx_lower_10_0  -8.61111111111111
    x[10,0]   conditional_Sx_upper_10_0  -3.8800000000000004e+01
    x[10,0]   conditional_complement_lower_10_0  8.8194444444444429e+00
    x[10,0]   conditional_complement_upper_10_0  39.6
    x[10,0]   hard_cost_D_definition  -1.3091128838151053e-04
    x[10,1]   onehot_10  1
    x[10,1]   inventory_10  -1
    x[10,1]   product_lx_10_1  -8.61111111111111
    x[10,1]   product_ux_10_1  -39.6
    x[10,1]   product_Su_10_1  -39.6
    x[10,1]   product_Sl_10_1  -8.61111111111111
    x[10,1]   conditional_Sx_lower_10_1  -8.8194444444444429e+00
    x[10,1]   conditional_Sx_upper_10_1  -3.8933333333333337e+01
    x[10,1]   conditional_complement_lower_10_1  8.61111111111111
    x[10,1]   conditional_complement_upper_10_1  39.6
    x[10,1]   hard_cost_D_definition  -4.3637096127170178e-05
    x[10,2]   onehot_10  1
    x[10,2]   inventory_10  -2
    x[10,2]   product_lx_10_2  -8.61111111111111
    x[10,2]   product_ux_10_2  -39.6
    x[10,2]   product_Su_10_2  -39.6
    x[10,2]   product_Sl_10_2  -8.61111111111111
    x[10,2]   conditional_Sx_lower_10_2  -9.0277777777777768e+00
    x[10,2]   conditional_Sx_upper_10_2  -3.9066666666666670e+01
    x[10,2]   conditional_complement_lower_10_2  8.61111111111111
    x[10,2]   conditional_complement_upper_10_2  39.6
    x[10,2]   hard_cost_D_definition  4.3637096127170184e-05
    x[10,3]   onehot_10  1
    x[10,3]   inventory_10  -3
    x[10,3]   product_lx_10_3  -8.61111111111111
    x[10,3]   product_ux_10_3  -39.6
    x[10,3]   product_Su_10_3  -39.6
    x[10,3]   product_Sl_10_3  -8.61111111111111
    x[10,3]   conditional_Sx_lower_10_3  -9.23611111111111
    x[10,3]   conditional_Sx_upper_10_3  -39.2
    x[10,3]   conditional_complement_lower_10_3  8.61111111111111
    x[10,3]   conditional_complement_upper_10_3  39.6
    x[10,3]   hard_cost_D_definition  1.3091128838151056e-04
    x[10,4]   onehot_10  1
    x[10,4]   inventory_10  -4
    x[10,4]   product_lx_10_4  -8.61111111111111
    x[10,4]   product_ux_10_4  -39.6
    x[10,4]   product_Su_10_4  -39.6
    x[10,4]   product_Sl_10_4  -8.61111111111111
    x[10,4]   conditional_Sx_lower_10_4  -9.4444444444444429e+00
    x[10,4]   conditional_Sx_upper_10_4  -3.9333333333333336e+01
    x[10,4]   conditional_complement_lower_10_4  8.61111111111111
    x[10,4]   conditional_complement_upper_10_4  39.6
    x[10,4]   hard_cost_D_definition  4.3637096127170218e-05
    x[10,5]   onehot_10  1
    x[10,5]   inventory_10  -5
    x[10,5]   product_lx_10_5  -8.61111111111111
    x[10,5]   product_ux_10_5  -39.6
    x[10,5]   product_Su_10_5  -39.6
    x[10,5]   product_Sl_10_5  -8.61111111111111
    x[10,5]   conditional_Sx_lower_10_5  -9.6527777777777768e+00
    x[10,5]   conditional_Sx_upper_10_5  -3.9466666666666669e+01
    x[10,5]   conditional_complement_lower_10_5  8.61111111111111
    x[10,5]   conditional_complement_upper_10_5  39.6
    x[10,5]   hard_cost_D_definition  -4.3637096127170150e-05
    x[10,6]   onehot_10  1
    x[10,6]   inventory_10  -6
    x[10,6]   product_lx_10_6  -8.61111111111111
    x[10,6]   product_ux_10_6  -39.6
    x[10,6]   product_Su_10_6  -39.6
    x[10,6]   product_Sl_10_6  -8.61111111111111
    x[10,6]   conditional_Sx_lower_10_6  -9.86111111111111
    x[10,6]   conditional_Sx_upper_10_6  -39.6
    x[10,6]   conditional_complement_lower_10_6  8.61111111111111
    x[10,6]   conditional_complement_upper_10_6  3.9466666666666669e+01
    x[10,6]   hard_cost_D_definition  -1.3091128838151051e-04
    x[11,0]   onehot_11  1
    x[11,0]   product_lx_11_0  -8.61111111111111
    x[11,0]   product_ux_11_0  -39.6
    x[11,0]   product_Su_11_0  -39.6
    x[11,0]   product_Sl_11_0  -8.61111111111111
    x[11,0]   conditional_Sx_lower_11_0  -8.61111111111111
    x[11,0]   conditional_Sx_upper_11_0  -39.6
    x[11,0]   conditional_complement_lower_11_0  8.68611111111111
    x[11,0]   conditional_complement_upper_11_0  39.6
    x[11,0]   hard_cost_D_definition  -3.6364286046067603e-04
    x[11,1]   onehot_11  1
    x[11,1]   inventory_11  -1
    x[11,1]   product_lx_11_1  -8.61111111111111
    x[11,1]   product_ux_11_1  -39.6
    x[11,1]   product_Su_11_1  -39.6
    x[11,1]   product_Sl_11_1  -8.61111111111111
    x[11,1]   conditional_Sx_lower_11_1  -8.68611111111111
    x[11,1]   conditional_Sx_upper_11_1  -39.6
    x[11,1]   conditional_complement_lower_11_1  8.61111111111111
    x[11,1]   conditional_complement_upper_11_1  39.6
    x[11,1]   hard_cost_D_definition  -2.1818571627640559e-04
    x[11,2]   onehot_11  1
    x[11,2]   inventory_11  -2
    x[11,2]   product_lx_11_2  -8.61111111111111
    x[11,2]   product_ux_11_2  -39.6
    x[11,2]   product_Su_11_2  -39.6
    x[11,2]   product_Sl_11_2  -8.61111111111111
    x[11,2]   conditional_Sx_lower_11_2  -8.76111111111111
    x[11,2]   conditional_Sx_upper_11_2  -39.6
    x[11,2]   conditional_complement_lower_11_2  8.61111111111111
    x[11,2]   conditional_complement_upper_11_2  39.6
    x[11,2]   hard_cost_D_definition  -7.2728572092135138e-05
    x[11,3]   onehot_11  1
    x[11,3]   inventory_11  -3
    x[11,3]   product_lx_11_3  -8.61111111111111
    x[11,3]   product_ux_11_3  -39.6
    x[11,3]   product_Su_11_3  -39.6
    x[11,3]   product_Sl_11_3  -8.61111111111111
    x[11,3]   conditional_Sx_lower_11_3  -8.83611111111111
    x[11,3]   conditional_Sx_upper_11_3  -39.6
    x[11,3]   conditional_complement_lower_11_3  8.61111111111111
    x[11,3]   conditional_complement_upper_11_3  39.6
    x[11,3]   hard_cost_D_definition  7.2728572092135315e-05
    x[11,4]   onehot_11  1
    x[11,4]   inventory_11  -4
    x[11,4]   product_lx_11_4  -8.61111111111111
    x[11,4]   product_ux_11_4  -39.6
    x[11,4]   product_Su_11_4  -39.6
    x[11,4]   product_Sl_11_4  -8.61111111111111
    x[11,4]   conditional_Sx_lower_11_4  -8.91111111111111
    x[11,4]   conditional_Sx_upper_11_4  -39.6
    x[11,4]   conditional_complement_lower_11_4  8.61111111111111
    x[11,4]   conditional_complement_upper_11_4  39.6
    x[11,4]   hard_cost_D_definition  2.1818571627640578e-04
    x[11,5]   onehot_11  1
    x[11,5]   inventory_11  -5
    x[11,5]   product_lx_11_5  -8.61111111111111
    x[11,5]   product_ux_11_5  -39.6
    x[11,5]   product_Su_11_5  -39.6
    x[11,5]   product_Sl_11_5  -8.61111111111111
    x[11,5]   conditional_Sx_lower_11_5  -8.98611111111111
    x[11,5]   conditional_Sx_upper_11_5  -39.6
    x[11,5]   conditional_complement_lower_11_5  8.61111111111111
    x[11,5]   conditional_complement_upper_11_5  39.6
    x[11,5]   hard_cost_D_definition  3.6364286046067619e-04
    x[11,6]   onehot_11  1
    x[11,6]   inventory_11  -6
    x[11,6]   product_lx_11_6  -8.61111111111111
    x[11,6]   product_ux_11_6  -39.6
    x[11,6]   product_Su_11_6  -39.6
    x[11,6]   product_Sl_11_6  -8.61111111111111
    x[11,6]   conditional_Sx_lower_11_6  -9.06111111111111
    x[11,6]   conditional_Sx_upper_11_6  -39.6
    x[11,6]   conditional_complement_lower_11_6  8.61111111111111
    x[11,6]   conditional_complement_upper_11_6  39.6
    x[11,6]   hard_cost_D_definition  2.1818571627640570e-04
    x[11,7]   onehot_11  1
    x[11,7]   inventory_11  -7
    x[11,7]   product_lx_11_7  -8.61111111111111
    x[11,7]   product_ux_11_7  -39.6
    x[11,7]   product_Su_11_7  -39.6
    x[11,7]   product_Sl_11_7  -8.61111111111111
    x[11,7]   conditional_Sx_lower_11_7  -9.1361111111111111e+00
    x[11,7]   conditional_Sx_upper_11_7  -39.6
    x[11,7]   conditional_complement_lower_11_7  8.61111111111111
    x[11,7]   conditional_complement_upper_11_7  39.6
    x[11,7]   hard_cost_D_definition  7.2728572092135233e-05
    x[11,8]   onehot_11  1
    x[11,8]   inventory_11  -8
    x[11,8]   product_lx_11_8  -8.61111111111111
    x[11,8]   product_ux_11_8  -39.6
    x[11,8]   product_Su_11_8  -39.6
    x[11,8]   product_Sl_11_8  -8.61111111111111
    x[11,8]   conditional_Sx_lower_11_8  -9.21111111111111
    x[11,8]   conditional_Sx_upper_11_8  -39.6
    x[11,8]   conditional_complement_lower_11_8  8.61111111111111
    x[11,8]   conditional_complement_upper_11_8  39.6
    x[11,8]   hard_cost_D_definition  -7.2728572092135220e-05
    x[11,9]   onehot_11  1
    x[11,9]   inventory_11  -9
    x[11,9]   product_lx_11_9  -8.61111111111111
    x[11,9]   product_ux_11_9  -39.6
    x[11,9]   product_Su_11_9  -39.6
    x[11,9]   product_Sl_11_9  -8.61111111111111
    x[11,9]   conditional_Sx_lower_11_9  -9.28611111111111
    x[11,9]   conditional_Sx_upper_11_9  -39.6
    x[11,9]   conditional_complement_lower_11_9  8.61111111111111
    x[11,9]   conditional_complement_upper_11_9  39.6
    x[11,9]   hard_cost_D_definition  -2.1818571627640567e-04
    x[11,10]  onehot_11  1
    x[11,10]  inventory_11  -10
    x[11,10]  product_lx_11_10  -8.61111111111111
    x[11,10]  product_ux_11_10  -39.6
    x[11,10]  product_Su_11_10  -39.6
    x[11,10]  product_Sl_11_10  -8.61111111111111
    x[11,10]  conditional_Sx_lower_11_10  -9.36111111111111
    x[11,10]  conditional_Sx_upper_11_10  -39.6
    x[11,10]  conditional_complement_lower_11_10  8.61111111111111
    x[11,10]  conditional_complement_upper_11_10  39.6
    x[11,10]  hard_cost_D_definition  -3.6364286046067614e-04
    x[12,0]   onehot_12  1
    x[12,0]   product_lx_12_0  -8.61111111111111
    x[12,0]   product_ux_12_0  -39.6
    x[12,0]   product_Su_12_0  -39.6
    x[12,0]   product_Sl_12_0  -8.61111111111111
    x[12,0]   conditional_Sx_lower_12_0  -8.61111111111111
    x[12,0]   conditional_Sx_upper_12_0  -39.6
    x[12,0]   conditional_complement_lower_12_0  8.6527777777777768e+00
    x[12,0]   conditional_complement_upper_12_0  3.9566666666666670e+01
    x[12,0]   hard_cost_D_definition  -5.2364515352604213e-04
    x[12,1]   onehot_12  1
    x[12,1]   inventory_12  -1
    x[12,1]   product_lx_12_1  -8.61111111111111
    x[12,1]   product_ux_12_1  -39.6
    x[12,1]   product_Su_12_1  -39.6
    x[12,1]   product_Sl_12_1  -8.61111111111111
    x[12,1]   conditional_Sx_lower_12_1  -8.6527777777777768e+00
    x[12,1]   conditional_Sx_upper_12_1  -3.9566666666666670e+01
    x[12,1]   conditional_complement_lower_12_1  8.61111111111111
    x[12,1]   conditional_complement_upper_12_1  39.6
    x[12,1]   hard_cost_D_definition  -3.4909676901736142e-04
    x[12,2]   onehot_12  1
    x[12,2]   inventory_12  -2
    x[12,2]   product_lx_12_2  -8.61111111111111
    x[12,2]   product_ux_12_2  -39.6
    x[12,2]   product_Su_12_2  -39.6
    x[12,2]   product_Sl_12_2  -8.61111111111111
    x[12,2]   conditional_Sx_lower_12_2  -8.6944444444444429e+00
    x[12,2]   conditional_Sx_upper_12_2  -3.9533333333333339e+01
    x[12,2]   conditional_complement_lower_12_2  8.61111111111111
    x[12,2]   conditional_complement_upper_12_2  39.6
    x[12,2]   hard_cost_D_definition  -1.7454838450868071e-04
    x[12,3]   onehot_12  1
    x[12,3]   inventory_12  -3
    x[12,3]   product_lx_12_3  -8.61111111111111
    x[12,3]   product_ux_12_3  -39.6
    x[12,3]   product_Su_12_3  -39.6
    x[12,3]   product_Sl_12_3  -8.61111111111111
    x[12,3]   conditional_Sx_lower_12_3  -8.73611111111111
    x[12,3]   conditional_Sx_upper_12_3  -39.5
    x[12,3]   conditional_complement_lower_12_3  8.61111111111111
    x[12,3]   conditional_complement_upper_12_3  39.6
    x[12,4]   onehot_12  1
    x[12,4]   inventory_12  -4
    x[12,4]   product_lx_12_4  -8.61111111111111
    x[12,4]   product_ux_12_4  -39.6
    x[12,4]   product_Su_12_4  -39.6
    x[12,4]   product_Sl_12_4  -8.61111111111111
    x[12,4]   conditional_Sx_lower_12_4  -8.7777777777777768e+00
    x[12,4]   conditional_Sx_upper_12_4  -3.9466666666666669e+01
    x[12,4]   conditional_complement_lower_12_4  8.61111111111111
    x[12,4]   conditional_complement_upper_12_4  39.6
    x[12,4]   hard_cost_D_definition  1.7454838450868074e-04
    x[12,5]   onehot_12  1
    x[12,5]   inventory_12  -5
    x[12,5]   product_lx_12_5  -8.61111111111111
    x[12,5]   product_ux_12_5  -39.6
    x[12,5]   product_Su_12_5  -39.6
    x[12,5]   product_Sl_12_5  -8.61111111111111
    x[12,5]   conditional_Sx_lower_12_5  -8.8194444444444429e+00
    x[12,5]   conditional_Sx_upper_12_5  -3.9433333333333337e+01
    x[12,5]   conditional_complement_lower_12_5  8.61111111111111
    x[12,5]   conditional_complement_upper_12_5  39.6
    x[12,5]   hard_cost_D_definition  3.4909676901736148e-04
    x[12,6]   onehot_12  1
    x[12,6]   inventory_12  -6
    x[12,6]   product_lx_12_6  -8.61111111111111
    x[12,6]   product_ux_12_6  -39.6
    x[12,6]   product_Su_12_6  -39.6
    x[12,6]   product_Sl_12_6  -8.61111111111111
    x[12,6]   conditional_Sx_lower_12_6  -8.86111111111111
    x[12,6]   conditional_Sx_upper_12_6  -3.9400000000000006e+01
    x[12,6]   conditional_complement_lower_12_6  8.61111111111111
    x[12,6]   conditional_complement_upper_12_6  39.6
    x[12,6]   hard_cost_D_definition  5.2364515352604224e-04
    x[12,7]   onehot_12  1
    x[12,7]   inventory_12  -7
    x[12,7]   product_lx_12_7  -8.61111111111111
    x[12,7]   product_ux_12_7  -39.6
    x[12,7]   product_Su_12_7  -39.6
    x[12,7]   product_Sl_12_7  -8.61111111111111
    x[12,7]   conditional_Sx_lower_12_7  -8.9027777777777768e+00
    x[12,7]   conditional_Sx_upper_12_7  -3.9366666666666667e+01
    x[12,7]   conditional_complement_lower_12_7  8.61111111111111
    x[12,7]   conditional_complement_upper_12_7  39.6
    x[12,7]   hard_cost_D_definition  3.4909676901736164e-04
    x[12,8]   onehot_12  1
    x[12,8]   inventory_12  -8
    x[12,8]   product_lx_12_8  -8.61111111111111
    x[12,8]   product_ux_12_8  -39.6
    x[12,8]   product_Su_12_8  -39.6
    x[12,8]   product_Sl_12_8  -8.61111111111111
    x[12,8]   conditional_Sx_lower_12_8  -8.9444444444444429e+00
    x[12,8]   conditional_Sx_upper_12_8  -3.9333333333333336e+01
    x[12,8]   conditional_complement_lower_12_8  8.61111111111111
    x[12,8]   conditional_complement_upper_12_8  39.6
    x[12,8]   hard_cost_D_definition  1.7454838450868087e-04
    x[12,9]   onehot_12  1
    x[12,9]   inventory_12  -9
    x[12,9]   product_lx_12_9  -8.61111111111111
    x[12,9]   product_ux_12_9  -39.6
    x[12,9]   product_Su_12_9  -39.6
    x[12,9]   product_Sl_12_9  -8.61111111111111
    x[12,9]   conditional_Sx_lower_12_9  -8.98611111111111
    x[12,9]   conditional_Sx_upper_12_9  -3.9300000000000004e+01
    x[12,9]   conditional_complement_lower_12_9  8.61111111111111
    x[12,9]   conditional_complement_upper_12_9  39.6
    x[12,10]  onehot_12  1
    x[12,10]  inventory_12  -10
    x[12,10]  product_lx_12_10  -8.61111111111111
    x[12,10]  product_ux_12_10  -39.6
    x[12,10]  product_Su_12_10  -39.6
    x[12,10]  product_Sl_12_10  -8.61111111111111
    x[12,10]  conditional_Sx_lower_12_10  -9.0277777777777768e+00
    x[12,10]  conditional_Sx_upper_12_10  -3.9266666666666673e+01
    x[12,10]  conditional_complement_lower_12_10  8.61111111111111
    x[12,10]  conditional_complement_upper_12_10  39.6
    x[12,10]  hard_cost_D_definition  -1.7454838450868060e-04
    x[12,11]  onehot_12  1
    x[12,11]  inventory_12  -11
    x[12,11]  product_lx_12_11  -8.61111111111111
    x[12,11]  product_ux_12_11  -39.6
    x[12,11]  product_Su_12_11  -39.6
    x[12,11]  product_Sl_12_11  -8.61111111111111
    x[12,11]  conditional_Sx_lower_12_11  -9.0694444444444429e+00
    x[12,11]  conditional_Sx_upper_12_11  -3.9233333333333334e+01
    x[12,11]  conditional_complement_lower_12_11  8.61111111111111
    x[12,11]  conditional_complement_upper_12_11  39.6
    x[12,11]  hard_cost_D_definition  -3.4909676901736131e-04
    x[12,12]  onehot_12  1
    x[12,12]  inventory_12  -12
    x[12,12]  product_lx_12_12  -8.61111111111111
    x[12,12]  product_ux_12_12  -39.6
    x[12,12]  product_Su_12_12  -39.6
    x[12,12]  product_Sl_12_12  -8.61111111111111
    x[12,12]  conditional_Sx_lower_12_12  -9.11111111111111
    x[12,12]  conditional_Sx_upper_12_12  -39.2
    x[12,12]  conditional_complement_lower_12_12  8.61111111111111
    x[12,12]  conditional_complement_upper_12_12  39.6
    x[12,12]  hard_cost_D_definition  -0.000523645153526042
    x[13,0]   onehot_13  1
    x[13,0]   product_lx_13_0  -8.61111111111111
    x[13,0]   product_ux_13_0  -39.6
    x[13,0]   product_Su_13_0  -39.6
    x[13,0]   product_Sl_13_0  -8.61111111111111
    x[13,0]   conditional_Sx_lower_13_0  -8.61111111111111
    x[13,0]   conditional_Sx_upper_13_0  -39.2
    x[13,0]   conditional_complement_lower_13_0  8.73611111111111
    x[13,0]   conditional_complement_upper_13_0  39.6
    x[13,0]   hard_cost_D_definition  -2.3273157207916555e-04
    x[13,1]   onehot_13  1
    x[13,1]   inventory_13  -1
    x[13,1]   product_lx_13_1  -8.61111111111111
    x[13,1]   product_ux_13_1  -39.6
    x[13,1]   product_Su_13_1  -39.6
    x[13,1]   product_Sl_13_1  -8.61111111111111
    x[13,1]   conditional_Sx_lower_13_1  -8.73611111111111
    x[13,1]   conditional_Sx_upper_13_1  -3.9250000000000007e+01
    x[13,1]   conditional_complement_lower_13_1  8.61111111111111
    x[13,1]   conditional_complement_upper_13_1  39.6
    x[13,1]   hard_cost_D_definition  -1.1636578603958278e-04
    x[13,2]   onehot_13  1
    x[13,2]   inventory_13  -2
    x[13,2]   product_lx_13_2  -8.61111111111111
    x[13,2]   product_ux_13_2  -39.6
    x[13,2]   product_Su_13_2  -39.6
    x[13,2]   product_Sl_13_2  -8.61111111111111
    x[13,2]   conditional_Sx_lower_13_2  -8.86111111111111
    x[13,2]   conditional_Sx_upper_13_2  -3.9300000000000004e+01
    x[13,2]   conditional_complement_lower_13_2  8.61111111111111
    x[13,2]   conditional_complement_upper_13_2  39.6
    x[13,3]   onehot_13  1
    x[13,3]   inventory_13  -3
    x[13,3]   product_lx_13_3  -8.61111111111111
    x[13,3]   product_ux_13_3  -39.6
    x[13,3]   product_Su_13_3  -39.6
    x[13,3]   product_Sl_13_3  -8.61111111111111
    x[13,3]   conditional_Sx_lower_13_3  -8.98611111111111
    x[13,3]   conditional_Sx_upper_13_3  -39.35
    x[13,3]   conditional_complement_lower_13_3  8.61111111111111
    x[13,3]   conditional_complement_upper_13_3  39.6
    x[13,3]   hard_cost_D_definition  1.1636578603958278e-04
    x[13,4]   onehot_13  1
    x[13,4]   inventory_13  -4
    x[13,4]   product_lx_13_4  -8.61111111111111
    x[13,4]   product_ux_13_4  -39.6
    x[13,4]   product_Su_13_4  -39.6
    x[13,4]   product_Sl_13_4  -8.61111111111111
    x[13,4]   conditional_Sx_lower_13_4  -9.11111111111111
    x[13,4]   conditional_Sx_upper_13_4  -3.9400000000000006e+01
    x[13,4]   conditional_complement_lower_13_4  8.61111111111111
    x[13,4]   conditional_complement_upper_13_4  39.6
    x[13,4]   hard_cost_D_definition  2.3273157207916555e-04
    x[13,5]   onehot_13  1
    x[13,5]   inventory_13  -5
    x[13,5]   product_lx_13_5  -8.61111111111111
    x[13,5]   product_ux_13_5  -39.6
    x[13,5]   product_Su_13_5  -39.6
    x[13,5]   product_Sl_13_5  -8.61111111111111
    x[13,5]   conditional_Sx_lower_13_5  -9.23611111111111
    x[13,5]   conditional_Sx_upper_13_5  -39.45
    x[13,5]   conditional_complement_lower_13_5  8.61111111111111
    x[13,5]   conditional_complement_upper_13_5  39.6
    x[13,5]   hard_cost_D_definition  1.1636578603958278e-04
    x[13,6]   onehot_13  1
    x[13,6]   inventory_13  -6
    x[13,6]   product_lx_13_6  -8.61111111111111
    x[13,6]   product_ux_13_6  -39.6
    x[13,6]   product_Su_13_6  -39.6
    x[13,6]   product_Sl_13_6  -8.61111111111111
    x[13,6]   conditional_Sx_lower_13_6  -9.36111111111111
    x[13,6]   conditional_Sx_upper_13_6  -3.9500000000000007e+01
    x[13,6]   conditional_complement_lower_13_6  8.61111111111111
    x[13,6]   conditional_complement_upper_13_6  39.6
    x[13,7]   onehot_13  1
    x[13,7]   inventory_13  -7
    x[13,7]   product_lx_13_7  -8.61111111111111
    x[13,7]   product_ux_13_7  -39.6
    x[13,7]   product_Su_13_7  -39.6
    x[13,7]   product_Sl_13_7  -8.61111111111111
    x[13,7]   conditional_Sx_lower_13_7  -9.48611111111111
    x[13,7]   conditional_Sx_upper_13_7  -3.9550000000000004e+01
    x[13,7]   conditional_complement_lower_13_7  8.61111111111111
    x[13,7]   conditional_complement_upper_13_7  39.6
    x[13,7]   hard_cost_D_definition  -1.1636578603958278e-04
    x[13,8]   onehot_13  1
    x[13,8]   inventory_13  -8
    x[13,8]   product_lx_13_8  -8.61111111111111
    x[13,8]   product_ux_13_8  -39.6
    x[13,8]   product_Su_13_8  -39.6
    x[13,8]   product_Sl_13_8  -8.61111111111111
    x[13,8]   conditional_Sx_lower_13_8  -9.61111111111111
    x[13,8]   conditional_Sx_upper_13_8  -39.6
    x[13,8]   conditional_complement_lower_13_8  8.61111111111111
    x[13,8]   conditional_complement_upper_13_8  3.9550000000000004e+01
    x[13,8]   hard_cost_D_definition  -2.3273157207916555e-04
    x[14,0]   onehot_14  1
    x[14,0]   product_lx_14_0  -8.61111111111111
    x[14,0]   product_ux_14_0  -39.6
    x[14,0]   product_Su_14_0  -39.6
    x[14,0]   product_Sl_14_0  -8.61111111111111
    x[14,0]   conditional_Sx_lower_14_0  -8.61111111111111
    x[14,0]   conditional_Sx_upper_14_0  -39.2
    x[14,0]   conditional_complement_lower_14_0  8.73611111111111
    x[14,0]   conditional_complement_upper_14_0  39.6
    x[14,0]   hard_cost_D_definition  -2.3273157207916555e-04
    x[14,1]   onehot_14  1
    x[14,1]   inventory_14  -1
    x[14,1]   product_lx_14_1  -8.61111111111111
    x[14,1]   product_ux_14_1  -39.6
    x[14,1]   product_Su_14_1  -39.6
    x[14,1]   product_Sl_14_1  -8.61111111111111
    x[14,1]   conditional_Sx_lower_14_1  -8.73611111111111
    x[14,1]   conditional_Sx_upper_14_1  -3.9250000000000007e+01
    x[14,1]   conditional_complement_lower_14_1  8.61111111111111
    x[14,1]   conditional_complement_upper_14_1  39.6
    x[14,1]   hard_cost_D_definition  -1.1636578603958278e-04
    x[14,2]   onehot_14  1
    x[14,2]   inventory_14  -2
    x[14,2]   product_lx_14_2  -8.61111111111111
    x[14,2]   product_ux_14_2  -39.6
    x[14,2]   product_Su_14_2  -39.6
    x[14,2]   product_Sl_14_2  -8.61111111111111
    x[14,2]   conditional_Sx_lower_14_2  -8.86111111111111
    x[14,2]   conditional_Sx_upper_14_2  -3.9300000000000004e+01
    x[14,2]   conditional_complement_lower_14_2  8.61111111111111
    x[14,2]   conditional_complement_upper_14_2  39.6
    x[14,3]   onehot_14  1
    x[14,3]   inventory_14  -3
    x[14,3]   product_lx_14_3  -8.61111111111111
    x[14,3]   product_ux_14_3  -39.6
    x[14,3]   product_Su_14_3  -39.6
    x[14,3]   product_Sl_14_3  -8.61111111111111
    x[14,3]   conditional_Sx_lower_14_3  -8.98611111111111
    x[14,3]   conditional_Sx_upper_14_3  -39.35
    x[14,3]   conditional_complement_lower_14_3  8.61111111111111
    x[14,3]   conditional_complement_upper_14_3  39.6
    x[14,3]   hard_cost_D_definition  1.1636578603958278e-04
    x[14,4]   onehot_14  1
    x[14,4]   inventory_14  -4
    x[14,4]   product_lx_14_4  -8.61111111111111
    x[14,4]   product_ux_14_4  -39.6
    x[14,4]   product_Su_14_4  -39.6
    x[14,4]   product_Sl_14_4  -8.61111111111111
    x[14,4]   conditional_Sx_lower_14_4  -9.11111111111111
    x[14,4]   conditional_Sx_upper_14_4  -3.9400000000000006e+01
    x[14,4]   conditional_complement_lower_14_4  8.61111111111111
    x[14,4]   conditional_complement_upper_14_4  39.6
    x[14,4]   hard_cost_D_definition  2.3273157207916555e-04
    x[14,5]   onehot_14  1
    x[14,5]   inventory_14  -5
    x[14,5]   product_lx_14_5  -8.61111111111111
    x[14,5]   product_ux_14_5  -39.6
    x[14,5]   product_Su_14_5  -39.6
    x[14,5]   product_Sl_14_5  -8.61111111111111
    x[14,5]   conditional_Sx_lower_14_5  -9.23611111111111
    x[14,5]   conditional_Sx_upper_14_5  -39.45
    x[14,5]   conditional_complement_lower_14_5  8.61111111111111
    x[14,5]   conditional_complement_upper_14_5  39.6
    x[14,5]   hard_cost_D_definition  1.1636578603958278e-04
    x[14,6]   onehot_14  1
    x[14,6]   inventory_14  -6
    x[14,6]   product_lx_14_6  -8.61111111111111
    x[14,6]   product_ux_14_6  -39.6
    x[14,6]   product_Su_14_6  -39.6
    x[14,6]   product_Sl_14_6  -8.61111111111111
    x[14,6]   conditional_Sx_lower_14_6  -9.36111111111111
    x[14,6]   conditional_Sx_upper_14_6  -3.9500000000000007e+01
    x[14,6]   conditional_complement_lower_14_6  8.61111111111111
    x[14,6]   conditional_complement_upper_14_6  39.6
    x[14,7]   onehot_14  1
    x[14,7]   inventory_14  -7
    x[14,7]   product_lx_14_7  -8.61111111111111
    x[14,7]   product_ux_14_7  -39.6
    x[14,7]   product_Su_14_7  -39.6
    x[14,7]   product_Sl_14_7  -8.61111111111111
    x[14,7]   conditional_Sx_lower_14_7  -9.48611111111111
    x[14,7]   conditional_Sx_upper_14_7  -3.9550000000000004e+01
    x[14,7]   conditional_complement_lower_14_7  8.61111111111111
    x[14,7]   conditional_complement_upper_14_7  39.6
    x[14,7]   hard_cost_D_definition  -1.1636578603958278e-04
    x[14,8]   onehot_14  1
    x[14,8]   inventory_14  -8
    x[14,8]   product_lx_14_8  -8.61111111111111
    x[14,8]   product_ux_14_8  -39.6
    x[14,8]   product_Su_14_8  -39.6
    x[14,8]   product_Sl_14_8  -8.61111111111111
    x[14,8]   conditional_Sx_lower_14_8  -9.61111111111111
    x[14,8]   conditional_Sx_upper_14_8  -39.6
    x[14,8]   conditional_complement_lower_14_8  8.61111111111111
    x[14,8]   conditional_complement_upper_14_8  3.9550000000000004e+01
    x[14,8]   hard_cost_D_definition  -2.3273157207916555e-04
    x[15,0]   onehot_15  1
    x[15,0]   product_lx_15_0  -8.61111111111111
    x[15,0]   product_ux_15_0  -39.6
    x[15,0]   product_Su_15_0  -39.6
    x[15,0]   product_Sl_15_0  -8.61111111111111
    x[15,0]   conditional_Sx_lower_15_0  -8.61111111111111
    x[15,0]   conditional_Sx_upper_15_0  -39.2
    x[15,0]   conditional_complement_lower_15_0  8.73611111111111
    x[15,0]   conditional_complement_upper_15_0  39.6
    x[15,0]   hard_cost_D_definition  -2.3273157207916555e-04
    x[15,1]   onehot_15  1
    x[15,1]   inventory_15  -1
    x[15,1]   product_lx_15_1  -8.61111111111111
    x[15,1]   product_ux_15_1  -39.6
    x[15,1]   product_Su_15_1  -39.6
    x[15,1]   product_Sl_15_1  -8.61111111111111
    x[15,1]   conditional_Sx_lower_15_1  -8.73611111111111
    x[15,1]   conditional_Sx_upper_15_1  -3.9250000000000007e+01
    x[15,1]   conditional_complement_lower_15_1  8.61111111111111
    x[15,1]   conditional_complement_upper_15_1  39.6
    x[15,1]   hard_cost_D_definition  -1.1636578603958278e-04
    x[15,2]   onehot_15  1
    x[15,2]   inventory_15  -2
    x[15,2]   product_lx_15_2  -8.61111111111111
    x[15,2]   product_ux_15_2  -39.6
    x[15,2]   product_Su_15_2  -39.6
    x[15,2]   product_Sl_15_2  -8.61111111111111
    x[15,2]   conditional_Sx_lower_15_2  -8.86111111111111
    x[15,2]   conditional_Sx_upper_15_2  -3.9300000000000004e+01
    x[15,2]   conditional_complement_lower_15_2  8.61111111111111
    x[15,2]   conditional_complement_upper_15_2  39.6
    x[15,3]   onehot_15  1
    x[15,3]   inventory_15  -3
    x[15,3]   product_lx_15_3  -8.61111111111111
    x[15,3]   product_ux_15_3  -39.6
    x[15,3]   product_Su_15_3  -39.6
    x[15,3]   product_Sl_15_3  -8.61111111111111
    x[15,3]   conditional_Sx_lower_15_3  -8.98611111111111
    x[15,3]   conditional_Sx_upper_15_3  -39.35
    x[15,3]   conditional_complement_lower_15_3  8.61111111111111
    x[15,3]   conditional_complement_upper_15_3  39.6
    x[15,3]   hard_cost_D_definition  1.1636578603958278e-04
    x[15,4]   onehot_15  1
    x[15,4]   inventory_15  -4
    x[15,4]   product_lx_15_4  -8.61111111111111
    x[15,4]   product_ux_15_4  -39.6
    x[15,4]   product_Su_15_4  -39.6
    x[15,4]   product_Sl_15_4  -8.61111111111111
    x[15,4]   conditional_Sx_lower_15_4  -9.11111111111111
    x[15,4]   conditional_Sx_upper_15_4  -3.9400000000000006e+01
    x[15,4]   conditional_complement_lower_15_4  8.61111111111111
    x[15,4]   conditional_complement_upper_15_4  39.6
    x[15,4]   hard_cost_D_definition  2.3273157207916555e-04
    x[15,5]   onehot_15  1
    x[15,5]   inventory_15  -5
    x[15,5]   product_lx_15_5  -8.61111111111111
    x[15,5]   product_ux_15_5  -39.6
    x[15,5]   product_Su_15_5  -39.6
    x[15,5]   product_Sl_15_5  -8.61111111111111
    x[15,5]   conditional_Sx_lower_15_5  -9.23611111111111
    x[15,5]   conditional_Sx_upper_15_5  -39.45
    x[15,5]   conditional_complement_lower_15_5  8.61111111111111
    x[15,5]   conditional_complement_upper_15_5  39.6
    x[15,5]   hard_cost_D_definition  1.1636578603958278e-04
    x[15,6]   onehot_15  1
    x[15,6]   inventory_15  -6
    x[15,6]   product_lx_15_6  -8.61111111111111
    x[15,6]   product_ux_15_6  -39.6
    x[15,6]   product_Su_15_6  -39.6
    x[15,6]   product_Sl_15_6  -8.61111111111111
    x[15,6]   conditional_Sx_lower_15_6  -9.36111111111111
    x[15,6]   conditional_Sx_upper_15_6  -3.9500000000000007e+01
    x[15,6]   conditional_complement_lower_15_6  8.61111111111111
    x[15,6]   conditional_complement_upper_15_6  39.6
    x[15,7]   onehot_15  1
    x[15,7]   inventory_15  -7
    x[15,7]   product_lx_15_7  -8.61111111111111
    x[15,7]   product_ux_15_7  -39.6
    x[15,7]   product_Su_15_7  -39.6
    x[15,7]   product_Sl_15_7  -8.61111111111111
    x[15,7]   conditional_Sx_lower_15_7  -9.48611111111111
    x[15,7]   conditional_Sx_upper_15_7  -3.9550000000000004e+01
    x[15,7]   conditional_complement_lower_15_7  8.61111111111111
    x[15,7]   conditional_complement_upper_15_7  39.6
    x[15,7]   hard_cost_D_definition  -1.1636578603958278e-04
    x[15,8]   onehot_15  1
    x[15,8]   inventory_15  -8
    x[15,8]   product_lx_15_8  -8.61111111111111
    x[15,8]   product_ux_15_8  -39.6
    x[15,8]   product_Su_15_8  -39.6
    x[15,8]   product_Sl_15_8  -8.61111111111111
    x[15,8]   conditional_Sx_lower_15_8  -9.61111111111111
    x[15,8]   conditional_Sx_upper_15_8  -39.6
    x[15,8]   conditional_complement_lower_15_8  8.61111111111111
    x[15,8]   conditional_complement_upper_15_8  3.9550000000000004e+01
    x[15,8]   hard_cost_D_definition  -2.3273157207916555e-04
    x[16,0]   onehot_16  1
    x[16,0]   product_lx_16_0  -8.61111111111111
    x[16,0]   product_ux_16_0  -39.6
    x[16,0]   product_Su_16_0  -39.6
    x[16,0]   product_Sl_16_0  -8.61111111111111
    x[16,0]   conditional_Sx_lower_16_0  -8.73611111111111
    x[16,0]   conditional_Sx_upper_16_0  -39.6
    x[16,0]   conditional_complement_lower_16_0  8.61111111111111
    x[16,0]   conditional_complement_upper_16_0  3.9525000000000006e+01
    x[16,0]   hard_cost_D_definition  -9.3092511011388858e-04
    x[16,1]   onehot_16  1
    x[16,1]   inventory_16  -1
    x[16,1]   product_lx_16_1  -8.61111111111111
    x[16,1]   product_ux_16_1  -39.6
    x[16,1]   product_Su_16_1  -39.6
    x[16,1]   product_Sl_16_1  -8.61111111111111
    x[16,1]   conditional_Sx_lower_16_1  -8.7182539682539666e+00
    x[16,1]   conditional_Sx_upper_16_1  -3.9525000000000006e+01
    x[16,1]   conditional_complement_lower_16_1  8.61111111111111
    x[16,1]   conditional_complement_upper_16_1  39.6
    x[16,1]   hard_cost_D_definition  -6.9819383258541636e-04
    x[16,2]   onehot_16  1
    x[16,2]   inventory_16  -2
    x[16,2]   product_lx_16_2  -8.61111111111111
    x[16,2]   product_ux_16_2  -39.6
    x[16,2]   product_Su_16_2  -39.6
    x[16,2]   product_Sl_16_2  -8.61111111111111
    x[16,2]   conditional_Sx_lower_16_2  -8.7003968253968242e+00
    x[16,2]   conditional_Sx_upper_16_2  -39.45
    x[16,2]   conditional_complement_lower_16_2  8.61111111111111
    x[16,2]   conditional_complement_upper_16_2  39.6
    x[16,2]   hard_cost_D_definition  -4.6546255505694429e-04
    x[16,3]   onehot_16  1
    x[16,3]   inventory_16  -3
    x[16,3]   product_lx_16_3  -8.61111111111111
    x[16,3]   product_ux_16_3  -39.6
    x[16,3]   product_Su_16_3  -39.6
    x[16,3]   product_Sl_16_3  -8.61111111111111
    x[16,3]   conditional_Sx_lower_16_3  -8.6825396825396819e+00
    x[16,3]   conditional_Sx_upper_16_3  -39.375
    x[16,3]   conditional_complement_lower_16_3  8.61111111111111
    x[16,3]   conditional_complement_upper_16_3  39.6
    x[16,3]   hard_cost_D_definition  -2.3273127752847215e-04
    x[16,4]   onehot_16  1
    x[16,4]   inventory_16  -4
    x[16,4]   product_lx_16_4  -8.61111111111111
    x[16,4]   product_ux_16_4  -39.6
    x[16,4]   product_Su_16_4  -39.6
    x[16,4]   product_Sl_16_4  -8.61111111111111
    x[16,4]   conditional_Sx_lower_16_4  -8.66468253968254
    x[16,4]   conditional_Sx_upper_16_4  -3.9300000000000004e+01
    x[16,4]   conditional_complement_lower_16_4  8.61111111111111
    x[16,4]   conditional_complement_upper_16_4  39.6
    x[16,5]   onehot_16  1
    x[16,5]   inventory_16  -5
    x[16,5]   product_lx_16_5  -8.61111111111111
    x[16,5]   product_ux_16_5  -39.6
    x[16,5]   product_Su_16_5  -39.6
    x[16,5]   product_Sl_16_5  -8.61111111111111
    x[16,5]   conditional_Sx_lower_16_5  -8.6468253968253954e+00
    x[16,5]   conditional_Sx_upper_16_5  -39.225
    x[16,5]   conditional_complement_lower_16_5  8.61111111111111
    x[16,5]   conditional_complement_upper_16_5  39.6
    x[16,5]   hard_cost_D_definition  2.3273127752847215e-04
    x[16,6]   onehot_16  1
    x[16,6]   inventory_16  -6
    x[16,6]   product_lx_16_6  -8.61111111111111
    x[16,6]   product_ux_16_6  -39.6
    x[16,6]   product_Su_16_6  -39.6
    x[16,6]   product_Sl_16_6  -8.61111111111111
    x[16,6]   conditional_Sx_lower_16_6  -8.6289682539682531e+00
    x[16,6]   conditional_Sx_upper_16_6  -3.9150000000000006e+01
    x[16,6]   conditional_complement_lower_16_6  8.61111111111111
    x[16,6]   conditional_complement_upper_16_6  39.6
    x[16,6]   hard_cost_D_definition  4.6546255505694429e-04
    x[16,7]   onehot_16  1
    x[16,7]   inventory_16  -7
    x[16,7]   product_lx_16_7  -8.61111111111111
    x[16,7]   product_ux_16_7  -39.6
    x[16,7]   product_Su_16_7  -39.6
    x[16,7]   product_Sl_16_7  -8.61111111111111
    x[16,7]   conditional_Sx_lower_16_7  -8.61111111111111
    x[16,7]   conditional_Sx_upper_16_7  -39.075
    x[16,7]   conditional_complement_lower_16_7  8.61111111111111
    x[16,7]   conditional_complement_upper_16_7  39.6
    x[16,7]   hard_cost_D_definition  6.9819383258541646e-04
    x[16,8]   onehot_16  1
    x[16,8]   inventory_16  -8
    x[16,8]   product_lx_16_8  -8.61111111111111
    x[16,8]   product_ux_16_8  -39.6
    x[16,8]   product_Su_16_8  -39.6
    x[16,8]   product_Sl_16_8  -8.61111111111111
    x[16,8]   conditional_Sx_lower_16_8  -8.61111111111111
    x[16,8]   conditional_Sx_upper_16_8  -39
    x[16,8]   conditional_complement_lower_16_8  8.61111111111111
    x[16,8]   conditional_complement_upper_16_8  39.6
    x[16,8]   hard_cost_D_definition  9.3092511011388858e-04
    x[16,9]   onehot_16  1
    x[16,9]   inventory_16  -9
    x[16,9]   product_lx_16_9  -8.61111111111111
    x[16,9]   product_ux_16_9  -39.6
    x[16,9]   product_Su_16_9  -39.6
    x[16,9]   product_Sl_16_9  -8.61111111111111
    x[16,9]   conditional_Sx_lower_16_9  -8.61111111111111
    x[16,9]   conditional_Sx_upper_16_9  -3.8925000000000004e+01
    x[16,9]   conditional_complement_lower_16_9  8.61111111111111
    x[16,9]   conditional_complement_upper_16_9  39.6
    x[16,9]   hard_cost_D_definition  6.9819383258541646e-04
    x[16,10]  onehot_16  1
    x[16,10]  inventory_16  -10
    x[16,10]  product_lx_16_10  -8.61111111111111
    x[16,10]  product_ux_16_10  -39.6
    x[16,10]  product_Su_16_10  -39.6
    x[16,10]  product_Sl_16_10  -8.61111111111111
    x[16,10]  conditional_Sx_lower_16_10  -8.61111111111111
    x[16,10]  conditional_Sx_upper_16_10  -38.85
    x[16,10]  conditional_complement_lower_16_10  8.61111111111111
    x[16,10]  conditional_complement_upper_16_10  39.6
    x[16,10]  hard_cost_D_definition  4.6546255505694429e-04
    x[16,11]  onehot_16  1
    x[16,11]  inventory_16  -11
    x[16,11]  product_lx_16_11  -8.61111111111111
    x[16,11]  product_ux_16_11  -39.6
    x[16,11]  product_Su_16_11  -39.6
    x[16,11]  product_Sl_16_11  -8.61111111111111
    x[16,11]  conditional_Sx_lower_16_11  -8.61111111111111
    x[16,11]  conditional_Sx_upper_16_11  -3.8775000000000006e+01
    x[16,11]  conditional_complement_lower_16_11  8.61111111111111
    x[16,11]  conditional_complement_upper_16_11  39.6
    x[16,11]  hard_cost_D_definition  2.3273127752847215e-04
    x[16,12]  onehot_16  1
    x[16,12]  inventory_16  -12
    x[16,12]  product_lx_16_12  -8.61111111111111
    x[16,12]  product_ux_16_12  -39.6
    x[16,12]  product_Su_16_12  -39.6
    x[16,12]  product_Sl_16_12  -8.61111111111111
    x[16,12]  conditional_Sx_lower_16_12  -8.61111111111111
    x[16,12]  conditional_Sx_upper_16_12  -38.7
    x[16,12]  conditional_complement_lower_16_12  8.61111111111111
    x[16,12]  conditional_complement_upper_16_12  39.6
    x[16,13]  onehot_16  1
    x[16,13]  inventory_16  -13
    x[16,13]  product_lx_16_13  -8.61111111111111
    x[16,13]  product_ux_16_13  -39.6
    x[16,13]  product_Su_16_13  -39.6
    x[16,13]  product_Sl_16_13  -8.61111111111111
    x[16,13]  conditional_Sx_lower_16_13  -8.61111111111111
    x[16,13]  conditional_Sx_upper_16_13  -38.625
    x[16,13]  conditional_complement_lower_16_13  8.61111111111111
    x[16,13]  conditional_complement_upper_16_13  39.6
    x[16,13]  hard_cost_D_definition  -2.3273127752847215e-04
    x[16,14]  onehot_16  1
    x[16,14]  inventory_16  -14
    x[16,14]  product_lx_16_14  -8.61111111111111
    x[16,14]  product_ux_16_14  -39.6
    x[16,14]  product_Su_16_14  -39.6
    x[16,14]  product_Sl_16_14  -8.61111111111111
    x[16,14]  conditional_Sx_lower_16_14  -8.61111111111111
    x[16,14]  conditional_Sx_upper_16_14  -3.8550000000000004e+01
    x[16,14]  conditional_complement_lower_16_14  8.61111111111111
    x[16,14]  conditional_complement_upper_16_14  39.6
    x[16,14]  hard_cost_D_definition  -4.6546255505694429e-04
    x[16,15]  onehot_16  1
    x[16,15]  inventory_16  -15
    x[16,15]  product_lx_16_15  -8.61111111111111
    x[16,15]  product_ux_16_15  -39.6
    x[16,15]  product_Su_16_15  -39.6
    x[16,15]  product_Sl_16_15  -8.61111111111111
    x[16,15]  conditional_Sx_lower_16_15  -8.61111111111111
    x[16,15]  conditional_Sx_upper_16_15  -38.475
    x[16,15]  conditional_complement_lower_16_15  8.61111111111111
    x[16,15]  conditional_complement_upper_16_15  39.6
    x[16,15]  hard_cost_D_definition  -6.9819383258541636e-04
    x[17,0]   onehot_17  1
    x[17,0]   product_lx_17_0  -8.61111111111111
    x[17,0]   product_ux_17_0  -39.6
    x[17,0]   product_Su_17_0  -39.6
    x[17,0]   product_Sl_17_0  -8.61111111111111
    x[17,0]   conditional_Sx_lower_17_0  -8.61111111111111
    x[17,0]   conditional_Sx_upper_17_0  -3.8800000000000004e+01
    x[17,0]   conditional_complement_lower_17_0  8.8194444444444429e+00
    x[17,0]   conditional_complement_upper_17_0  39.6
    x[17,0]   hard_cost_D_definition  -1.3091128838151053e-04
    x[17,1]   onehot_17  1
    x[17,1]   inventory_17  -1
    x[17,1]   product_lx_17_1  -8.61111111111111
    x[17,1]   product_ux_17_1  -39.6
    x[17,1]   product_Su_17_1  -39.6
    x[17,1]   product_Sl_17_1  -8.61111111111111
    x[17,1]   conditional_Sx_lower_17_1  -8.8194444444444429e+00
    x[17,1]   conditional_Sx_upper_17_1  -3.8933333333333337e+01
    x[17,1]   conditional_complement_lower_17_1  8.61111111111111
    x[17,1]   conditional_complement_upper_17_1  39.6
    x[17,1]   hard_cost_D_definition  -4.3637096127170178e-05
    x[17,2]   onehot_17  1
    x[17,2]   inventory_17  -2
    x[17,2]   product_lx_17_2  -8.61111111111111
    x[17,2]   product_ux_17_2  -39.6
    x[17,2]   product_Su_17_2  -39.6
    x[17,2]   product_Sl_17_2  -8.61111111111111
    x[17,2]   conditional_Sx_lower_17_2  -9.0277777777777768e+00
    x[17,2]   conditional_Sx_upper_17_2  -3.9066666666666670e+01
    x[17,2]   conditional_complement_lower_17_2  8.61111111111111
    x[17,2]   conditional_complement_upper_17_2  39.6
    x[17,2]   hard_cost_D_definition  4.3637096127170184e-05
    x[17,3]   onehot_17  1
    x[17,3]   inventory_17  -3
    x[17,3]   product_lx_17_3  -8.61111111111111
    x[17,3]   product_ux_17_3  -39.6
    x[17,3]   product_Su_17_3  -39.6
    x[17,3]   product_Sl_17_3  -8.61111111111111
    x[17,3]   conditional_Sx_lower_17_3  -9.23611111111111
    x[17,3]   conditional_Sx_upper_17_3  -39.2
    x[17,3]   conditional_complement_lower_17_3  8.61111111111111
    x[17,3]   conditional_complement_upper_17_3  39.6
    x[17,3]   hard_cost_D_definition  1.3091128838151056e-04
    x[17,4]   onehot_17  1
    x[17,4]   inventory_17  -4
    x[17,4]   product_lx_17_4  -8.61111111111111
    x[17,4]   product_ux_17_4  -39.6
    x[17,4]   product_Su_17_4  -39.6
    x[17,4]   product_Sl_17_4  -8.61111111111111
    x[17,4]   conditional_Sx_lower_17_4  -9.4444444444444429e+00
    x[17,4]   conditional_Sx_upper_17_4  -3.9333333333333336e+01
    x[17,4]   conditional_complement_lower_17_4  8.61111111111111
    x[17,4]   conditional_complement_upper_17_4  39.6
    x[17,4]   hard_cost_D_definition  4.3637096127170218e-05
    x[17,5]   onehot_17  1
    x[17,5]   inventory_17  -5
    x[17,5]   product_lx_17_5  -8.61111111111111
    x[17,5]   product_ux_17_5  -39.6
    x[17,5]   product_Su_17_5  -39.6
    x[17,5]   product_Sl_17_5  -8.61111111111111
    x[17,5]   conditional_Sx_lower_17_5  -9.6527777777777768e+00
    x[17,5]   conditional_Sx_upper_17_5  -3.9466666666666669e+01
    x[17,5]   conditional_complement_lower_17_5  8.61111111111111
    x[17,5]   conditional_complement_upper_17_5  39.6
    x[17,5]   hard_cost_D_definition  -4.3637096127170150e-05
    x[17,6]   onehot_17  1
    x[17,6]   inventory_17  -6
    x[17,6]   product_lx_17_6  -8.61111111111111
    x[17,6]   product_ux_17_6  -39.6
    x[17,6]   product_Su_17_6  -39.6
    x[17,6]   product_Sl_17_6  -8.61111111111111
    x[17,6]   conditional_Sx_lower_17_6  -9.86111111111111
    x[17,6]   conditional_Sx_upper_17_6  -39.6
    x[17,6]   conditional_complement_lower_17_6  8.61111111111111
    x[17,6]   conditional_complement_upper_17_6  3.9466666666666669e+01
    x[17,6]   hard_cost_D_definition  -1.3091128838151051e-04
    x[18,0]   onehot_18  1
    x[18,0]   product_lx_18_0  -8.61111111111111
    x[18,0]   product_ux_18_0  -39.6
    x[18,0]   product_Su_18_0  -39.6
    x[18,0]   product_Sl_18_0  -8.61111111111111
    x[18,0]   conditional_Sx_lower_18_0  -8.61111111111111
    x[18,0]   conditional_Sx_upper_18_0  -39.6
    x[18,0]   conditional_complement_lower_18_0  8.68611111111111
    x[18,0]   conditional_complement_upper_18_0  39.6
    x[18,0]   hard_cost_D_definition  -3.6364286046067603e-04
    x[18,1]   onehot_18  1
    x[18,1]   inventory_18  -1
    x[18,1]   product_lx_18_1  -8.61111111111111
    x[18,1]   product_ux_18_1  -39.6
    x[18,1]   product_Su_18_1  -39.6
    x[18,1]   product_Sl_18_1  -8.61111111111111
    x[18,1]   conditional_Sx_lower_18_1  -8.68611111111111
    x[18,1]   conditional_Sx_upper_18_1  -39.6
    x[18,1]   conditional_complement_lower_18_1  8.61111111111111
    x[18,1]   conditional_complement_upper_18_1  39.6
    x[18,1]   hard_cost_D_definition  -2.1818571627640559e-04
    x[18,2]   onehot_18  1
    x[18,2]   inventory_18  -2
    x[18,2]   product_lx_18_2  -8.61111111111111
    x[18,2]   product_ux_18_2  -39.6
    x[18,2]   product_Su_18_2  -39.6
    x[18,2]   product_Sl_18_2  -8.61111111111111
    x[18,2]   conditional_Sx_lower_18_2  -8.76111111111111
    x[18,2]   conditional_Sx_upper_18_2  -39.6
    x[18,2]   conditional_complement_lower_18_2  8.61111111111111
    x[18,2]   conditional_complement_upper_18_2  39.6
    x[18,2]   hard_cost_D_definition  -7.2728572092135138e-05
    x[18,3]   onehot_18  1
    x[18,3]   inventory_18  -3
    x[18,3]   product_lx_18_3  -8.61111111111111
    x[18,3]   product_ux_18_3  -39.6
    x[18,3]   product_Su_18_3  -39.6
    x[18,3]   product_Sl_18_3  -8.61111111111111
    x[18,3]   conditional_Sx_lower_18_3  -8.83611111111111
    x[18,3]   conditional_Sx_upper_18_3  -39.6
    x[18,3]   conditional_complement_lower_18_3  8.61111111111111
    x[18,3]   conditional_complement_upper_18_3  39.6
    x[18,3]   hard_cost_D_definition  7.2728572092135315e-05
    x[18,4]   onehot_18  1
    x[18,4]   inventory_18  -4
    x[18,4]   product_lx_18_4  -8.61111111111111
    x[18,4]   product_ux_18_4  -39.6
    x[18,4]   product_Su_18_4  -39.6
    x[18,4]   product_Sl_18_4  -8.61111111111111
    x[18,4]   conditional_Sx_lower_18_4  -8.91111111111111
    x[18,4]   conditional_Sx_upper_18_4  -39.6
    x[18,4]   conditional_complement_lower_18_4  8.61111111111111
    x[18,4]   conditional_complement_upper_18_4  39.6
    x[18,4]   hard_cost_D_definition  2.1818571627640578e-04
    x[18,5]   onehot_18  1
    x[18,5]   inventory_18  -5
    x[18,5]   product_lx_18_5  -8.61111111111111
    x[18,5]   product_ux_18_5  -39.6
    x[18,5]   product_Su_18_5  -39.6
    x[18,5]   product_Sl_18_5  -8.61111111111111
    x[18,5]   conditional_Sx_lower_18_5  -8.98611111111111
    x[18,5]   conditional_Sx_upper_18_5  -39.6
    x[18,5]   conditional_complement_lower_18_5  8.61111111111111
    x[18,5]   conditional_complement_upper_18_5  39.6
    x[18,5]   hard_cost_D_definition  3.6364286046067619e-04
    x[18,6]   onehot_18  1
    x[18,6]   inventory_18  -6
    x[18,6]   product_lx_18_6  -8.61111111111111
    x[18,6]   product_ux_18_6  -39.6
    x[18,6]   product_Su_18_6  -39.6
    x[18,6]   product_Sl_18_6  -8.61111111111111
    x[18,6]   conditional_Sx_lower_18_6  -9.06111111111111
    x[18,6]   conditional_Sx_upper_18_6  -39.6
    x[18,6]   conditional_complement_lower_18_6  8.61111111111111
    x[18,6]   conditional_complement_upper_18_6  39.6
    x[18,6]   hard_cost_D_definition  2.1818571627640570e-04
    x[18,7]   onehot_18  1
    x[18,7]   inventory_18  -7
    x[18,7]   product_lx_18_7  -8.61111111111111
    x[18,7]   product_ux_18_7  -39.6
    x[18,7]   product_Su_18_7  -39.6
    x[18,7]   product_Sl_18_7  -8.61111111111111
    x[18,7]   conditional_Sx_lower_18_7  -9.1361111111111111e+00
    x[18,7]   conditional_Sx_upper_18_7  -39.6
    x[18,7]   conditional_complement_lower_18_7  8.61111111111111
    x[18,7]   conditional_complement_upper_18_7  39.6
    x[18,7]   hard_cost_D_definition  7.2728572092135233e-05
    x[18,8]   onehot_18  1
    x[18,8]   inventory_18  -8
    x[18,8]   product_lx_18_8  -8.61111111111111
    x[18,8]   product_ux_18_8  -39.6
    x[18,8]   product_Su_18_8  -39.6
    x[18,8]   product_Sl_18_8  -8.61111111111111
    x[18,8]   conditional_Sx_lower_18_8  -9.21111111111111
    x[18,8]   conditional_Sx_upper_18_8  -39.6
    x[18,8]   conditional_complement_lower_18_8  8.61111111111111
    x[18,8]   conditional_complement_upper_18_8  39.6
    x[18,8]   hard_cost_D_definition  -7.2728572092135220e-05
    x[18,9]   onehot_18  1
    x[18,9]   inventory_18  -9
    x[18,9]   product_lx_18_9  -8.61111111111111
    x[18,9]   product_ux_18_9  -39.6
    x[18,9]   product_Su_18_9  -39.6
    x[18,9]   product_Sl_18_9  -8.61111111111111
    x[18,9]   conditional_Sx_lower_18_9  -9.28611111111111
    x[18,9]   conditional_Sx_upper_18_9  -39.6
    x[18,9]   conditional_complement_lower_18_9  8.61111111111111
    x[18,9]   conditional_complement_upper_18_9  39.6
    x[18,9]   hard_cost_D_definition  -2.1818571627640567e-04
    x[18,10]  onehot_18  1
    x[18,10]  inventory_18  -10
    x[18,10]  product_lx_18_10  -8.61111111111111
    x[18,10]  product_ux_18_10  -39.6
    x[18,10]  product_Su_18_10  -39.6
    x[18,10]  product_Sl_18_10  -8.61111111111111
    x[18,10]  conditional_Sx_lower_18_10  -9.36111111111111
    x[18,10]  conditional_Sx_upper_18_10  -39.6
    x[18,10]  conditional_complement_lower_18_10  8.61111111111111
    x[18,10]  conditional_complement_upper_18_10  39.6
    x[18,10]  hard_cost_D_definition  -3.6364286046067614e-04
    x[19,0]   onehot_19  1
    x[19,0]   product_lx_19_0  -8.61111111111111
    x[19,0]   product_ux_19_0  -39.6
    x[19,0]   product_Su_19_0  -39.6
    x[19,0]   product_Sl_19_0  -8.61111111111111
    x[19,0]   conditional_Sx_lower_19_0  -8.61111111111111
    x[19,0]   conditional_Sx_upper_19_0  -39.6
    x[19,0]   conditional_complement_lower_19_0  8.68611111111111
    x[19,0]   conditional_complement_upper_19_0  39.6
    x[19,0]   hard_cost_D_definition  -3.6364286046067603e-04
    x[19,1]   onehot_19  1
    x[19,1]   inventory_19  -1
    x[19,1]   product_lx_19_1  -8.61111111111111
    x[19,1]   product_ux_19_1  -39.6
    x[19,1]   product_Su_19_1  -39.6
    x[19,1]   product_Sl_19_1  -8.61111111111111
    x[19,1]   conditional_Sx_lower_19_1  -8.68611111111111
    x[19,1]   conditional_Sx_upper_19_1  -39.6
    x[19,1]   conditional_complement_lower_19_1  8.61111111111111
    x[19,1]   conditional_complement_upper_19_1  39.6
    x[19,1]   hard_cost_D_definition  -2.1818571627640559e-04
    x[19,2]   onehot_19  1
    x[19,2]   inventory_19  -2
    x[19,2]   product_lx_19_2  -8.61111111111111
    x[19,2]   product_ux_19_2  -39.6
    x[19,2]   product_Su_19_2  -39.6
    x[19,2]   product_Sl_19_2  -8.61111111111111
    x[19,2]   conditional_Sx_lower_19_2  -8.76111111111111
    x[19,2]   conditional_Sx_upper_19_2  -39.6
    x[19,2]   conditional_complement_lower_19_2  8.61111111111111
    x[19,2]   conditional_complement_upper_19_2  39.6
    x[19,2]   hard_cost_D_definition  -7.2728572092135138e-05
    x[19,3]   onehot_19  1
    x[19,3]   inventory_19  -3
    x[19,3]   product_lx_19_3  -8.61111111111111
    x[19,3]   product_ux_19_3  -39.6
    x[19,3]   product_Su_19_3  -39.6
    x[19,3]   product_Sl_19_3  -8.61111111111111
    x[19,3]   conditional_Sx_lower_19_3  -8.83611111111111
    x[19,3]   conditional_Sx_upper_19_3  -39.6
    x[19,3]   conditional_complement_lower_19_3  8.61111111111111
    x[19,3]   conditional_complement_upper_19_3  39.6
    x[19,3]   hard_cost_D_definition  7.2728572092135315e-05
    x[19,4]   onehot_19  1
    x[19,4]   inventory_19  -4
    x[19,4]   product_lx_19_4  -8.61111111111111
    x[19,4]   product_ux_19_4  -39.6
    x[19,4]   product_Su_19_4  -39.6
    x[19,4]   product_Sl_19_4  -8.61111111111111
    x[19,4]   conditional_Sx_lower_19_4  -8.91111111111111
    x[19,4]   conditional_Sx_upper_19_4  -39.6
    x[19,4]   conditional_complement_lower_19_4  8.61111111111111
    x[19,4]   conditional_complement_upper_19_4  39.6
    x[19,4]   hard_cost_D_definition  2.1818571627640578e-04
    x[19,5]   onehot_19  1
    x[19,5]   inventory_19  -5
    x[19,5]   product_lx_19_5  -8.61111111111111
    x[19,5]   product_ux_19_5  -39.6
    x[19,5]   product_Su_19_5  -39.6
    x[19,5]   product_Sl_19_5  -8.61111111111111
    x[19,5]   conditional_Sx_lower_19_5  -8.98611111111111
    x[19,5]   conditional_Sx_upper_19_5  -39.6
    x[19,5]   conditional_complement_lower_19_5  8.61111111111111
    x[19,5]   conditional_complement_upper_19_5  39.6
    x[19,5]   hard_cost_D_definition  3.6364286046067619e-04
    x[19,6]   onehot_19  1
    x[19,6]   inventory_19  -6
    x[19,6]   product_lx_19_6  -8.61111111111111
    x[19,6]   product_ux_19_6  -39.6
    x[19,6]   product_Su_19_6  -39.6
    x[19,6]   product_Sl_19_6  -8.61111111111111
    x[19,6]   conditional_Sx_lower_19_6  -9.06111111111111
    x[19,6]   conditional_Sx_upper_19_6  -39.6
    x[19,6]   conditional_complement_lower_19_6  8.61111111111111
    x[19,6]   conditional_complement_upper_19_6  39.6
    x[19,6]   hard_cost_D_definition  2.1818571627640570e-04
    x[19,7]   onehot_19  1
    x[19,7]   inventory_19  -7
    x[19,7]   product_lx_19_7  -8.61111111111111
    x[19,7]   product_ux_19_7  -39.6
    x[19,7]   product_Su_19_7  -39.6
    x[19,7]   product_Sl_19_7  -8.61111111111111
    x[19,7]   conditional_Sx_lower_19_7  -9.1361111111111111e+00
    x[19,7]   conditional_Sx_upper_19_7  -39.6
    x[19,7]   conditional_complement_lower_19_7  8.61111111111111
    x[19,7]   conditional_complement_upper_19_7  39.6
    x[19,7]   hard_cost_D_definition  7.2728572092135233e-05
    x[19,8]   onehot_19  1
    x[19,8]   inventory_19  -8
    x[19,8]   product_lx_19_8  -8.61111111111111
    x[19,8]   product_ux_19_8  -39.6
    x[19,8]   product_Su_19_8  -39.6
    x[19,8]   product_Sl_19_8  -8.61111111111111
    x[19,8]   conditional_Sx_lower_19_8  -9.21111111111111
    x[19,8]   conditional_Sx_upper_19_8  -39.6
    x[19,8]   conditional_complement_lower_19_8  8.61111111111111
    x[19,8]   conditional_complement_upper_19_8  39.6
    x[19,8]   hard_cost_D_definition  -7.2728572092135220e-05
    x[19,9]   onehot_19  1
    x[19,9]   inventory_19  -9
    x[19,9]   product_lx_19_9  -8.61111111111111
    x[19,9]   product_ux_19_9  -39.6
    x[19,9]   product_Su_19_9  -39.6
    x[19,9]   product_Sl_19_9  -8.61111111111111
    x[19,9]   conditional_Sx_lower_19_9  -9.28611111111111
    x[19,9]   conditional_Sx_upper_19_9  -39.6
    x[19,9]   conditional_complement_lower_19_9  8.61111111111111
    x[19,9]   conditional_complement_upper_19_9  39.6
    x[19,9]   hard_cost_D_definition  -2.1818571627640567e-04
    x[19,10]  onehot_19  1
    x[19,10]  inventory_19  -10
    x[19,10]  product_lx_19_10  -8.61111111111111
    x[19,10]  product_ux_19_10  -39.6
    x[19,10]  product_Su_19_10  -39.6
    x[19,10]  product_Sl_19_10  -8.61111111111111
    x[19,10]  conditional_Sx_lower_19_10  -9.36111111111111
    x[19,10]  conditional_Sx_upper_19_10  -39.6
    x[19,10]  conditional_complement_lower_19_10  8.61111111111111
    x[19,10]  conditional_complement_upper_19_10  39.6
    x[19,10]  hard_cost_D_definition  -3.6364286046067614e-04
    x[20,0]   onehot_20  1
    x[20,0]   product_lx_20_0  -8.61111111111111
    x[20,0]   product_ux_20_0  -39.6
    x[20,0]   product_Su_20_0  -39.6
    x[20,0]   product_Sl_20_0  -8.61111111111111
    x[20,0]   conditional_Sx_lower_20_0  -8.61111111111111
    x[20,0]   conditional_Sx_upper_20_0  -39.6
    x[20,0]   conditional_complement_lower_20_0  8.68611111111111
    x[20,0]   conditional_complement_upper_20_0  39.6
    x[20,0]   hard_cost_D_definition  -3.6364286046067603e-04
    x[20,1]   onehot_20  1
    x[20,1]   inventory_20  -1
    x[20,1]   product_lx_20_1  -8.61111111111111
    x[20,1]   product_ux_20_1  -39.6
    x[20,1]   product_Su_20_1  -39.6
    x[20,1]   product_Sl_20_1  -8.61111111111111
    x[20,1]   conditional_Sx_lower_20_1  -8.68611111111111
    x[20,1]   conditional_Sx_upper_20_1  -39.6
    x[20,1]   conditional_complement_lower_20_1  8.61111111111111
    x[20,1]   conditional_complement_upper_20_1  39.6
    x[20,1]   hard_cost_D_definition  -2.1818571627640559e-04
    x[20,2]   onehot_20  1
    x[20,2]   inventory_20  -2
    x[20,2]   product_lx_20_2  -8.61111111111111
    x[20,2]   product_ux_20_2  -39.6
    x[20,2]   product_Su_20_2  -39.6
    x[20,2]   product_Sl_20_2  -8.61111111111111
    x[20,2]   conditional_Sx_lower_20_2  -8.76111111111111
    x[20,2]   conditional_Sx_upper_20_2  -39.6
    x[20,2]   conditional_complement_lower_20_2  8.61111111111111
    x[20,2]   conditional_complement_upper_20_2  39.6
    x[20,2]   hard_cost_D_definition  -7.2728572092135138e-05
    x[20,3]   onehot_20  1
    x[20,3]   inventory_20  -3
    x[20,3]   product_lx_20_3  -8.61111111111111
    x[20,3]   product_ux_20_3  -39.6
    x[20,3]   product_Su_20_3  -39.6
    x[20,3]   product_Sl_20_3  -8.61111111111111
    x[20,3]   conditional_Sx_lower_20_3  -8.83611111111111
    x[20,3]   conditional_Sx_upper_20_3  -39.6
    x[20,3]   conditional_complement_lower_20_3  8.61111111111111
    x[20,3]   conditional_complement_upper_20_3  39.6
    x[20,3]   hard_cost_D_definition  7.2728572092135315e-05
    x[20,4]   onehot_20  1
    x[20,4]   inventory_20  -4
    x[20,4]   product_lx_20_4  -8.61111111111111
    x[20,4]   product_ux_20_4  -39.6
    x[20,4]   product_Su_20_4  -39.6
    x[20,4]   product_Sl_20_4  -8.61111111111111
    x[20,4]   conditional_Sx_lower_20_4  -8.91111111111111
    x[20,4]   conditional_Sx_upper_20_4  -39.6
    x[20,4]   conditional_complement_lower_20_4  8.61111111111111
    x[20,4]   conditional_complement_upper_20_4  39.6
    x[20,4]   hard_cost_D_definition  2.1818571627640578e-04
    x[20,5]   onehot_20  1
    x[20,5]   inventory_20  -5
    x[20,5]   product_lx_20_5  -8.61111111111111
    x[20,5]   product_ux_20_5  -39.6
    x[20,5]   product_Su_20_5  -39.6
    x[20,5]   product_Sl_20_5  -8.61111111111111
    x[20,5]   conditional_Sx_lower_20_5  -8.98611111111111
    x[20,5]   conditional_Sx_upper_20_5  -39.6
    x[20,5]   conditional_complement_lower_20_5  8.61111111111111
    x[20,5]   conditional_complement_upper_20_5  39.6
    x[20,5]   hard_cost_D_definition  3.6364286046067619e-04
    x[20,6]   onehot_20  1
    x[20,6]   inventory_20  -6
    x[20,6]   product_lx_20_6  -8.61111111111111
    x[20,6]   product_ux_20_6  -39.6
    x[20,6]   product_Su_20_6  -39.6
    x[20,6]   product_Sl_20_6  -8.61111111111111
    x[20,6]   conditional_Sx_lower_20_6  -9.06111111111111
    x[20,6]   conditional_Sx_upper_20_6  -39.6
    x[20,6]   conditional_complement_lower_20_6  8.61111111111111
    x[20,6]   conditional_complement_upper_20_6  39.6
    x[20,6]   hard_cost_D_definition  2.1818571627640570e-04
    x[20,7]   onehot_20  1
    x[20,7]   inventory_20  -7
    x[20,7]   product_lx_20_7  -8.61111111111111
    x[20,7]   product_ux_20_7  -39.6
    x[20,7]   product_Su_20_7  -39.6
    x[20,7]   product_Sl_20_7  -8.61111111111111
    x[20,7]   conditional_Sx_lower_20_7  -9.1361111111111111e+00
    x[20,7]   conditional_Sx_upper_20_7  -39.6
    x[20,7]   conditional_complement_lower_20_7  8.61111111111111
    x[20,7]   conditional_complement_upper_20_7  39.6
    x[20,7]   hard_cost_D_definition  7.2728572092135233e-05
    x[20,8]   onehot_20  1
    x[20,8]   inventory_20  -8
    x[20,8]   product_lx_20_8  -8.61111111111111
    x[20,8]   product_ux_20_8  -39.6
    x[20,8]   product_Su_20_8  -39.6
    x[20,8]   product_Sl_20_8  -8.61111111111111
    x[20,8]   conditional_Sx_lower_20_8  -9.21111111111111
    x[20,8]   conditional_Sx_upper_20_8  -39.6
    x[20,8]   conditional_complement_lower_20_8  8.61111111111111
    x[20,8]   conditional_complement_upper_20_8  39.6
    x[20,8]   hard_cost_D_definition  -7.2728572092135220e-05
    x[20,9]   onehot_20  1
    x[20,9]   inventory_20  -9
    x[20,9]   product_lx_20_9  -8.61111111111111
    x[20,9]   product_ux_20_9  -39.6
    x[20,9]   product_Su_20_9  -39.6
    x[20,9]   product_Sl_20_9  -8.61111111111111
    x[20,9]   conditional_Sx_lower_20_9  -9.28611111111111
    x[20,9]   conditional_Sx_upper_20_9  -39.6
    x[20,9]   conditional_complement_lower_20_9  8.61111111111111
    x[20,9]   conditional_complement_upper_20_9  39.6
    x[20,9]   hard_cost_D_definition  -2.1818571627640567e-04
    x[20,10]  onehot_20  1
    x[20,10]  inventory_20  -10
    x[20,10]  product_lx_20_10  -8.61111111111111
    x[20,10]  product_ux_20_10  -39.6
    x[20,10]  product_Su_20_10  -39.6
    x[20,10]  product_Sl_20_10  -8.61111111111111
    x[20,10]  conditional_Sx_lower_20_10  -9.36111111111111
    x[20,10]  conditional_Sx_upper_20_10  -39.6
    x[20,10]  conditional_complement_lower_20_10  8.61111111111111
    x[20,10]  conditional_complement_upper_20_10  39.6
    x[20,10]  hard_cost_D_definition  -3.6364286046067614e-04
    x[21,0]   onehot_21  1
    x[21,0]   product_lx_21_0  -8.61111111111111
    x[21,0]   product_ux_21_0  -39.6
    x[21,0]   product_Su_21_0  -39.6
    x[21,0]   product_Sl_21_0  -8.61111111111111
    x[21,0]   conditional_Sx_lower_21_0  -8.61111111111111
    x[21,0]   conditional_Sx_upper_21_0  -3.8800000000000004e+01
    x[21,0]   conditional_complement_lower_21_0  8.8194444444444429e+00
    x[21,0]   conditional_complement_upper_21_0  39.6
    x[21,0]   hard_cost_D_definition  -1.3091128838151053e-04
    x[21,1]   onehot_21  1
    x[21,1]   inventory_21  -1
    x[21,1]   product_lx_21_1  -8.61111111111111
    x[21,1]   product_ux_21_1  -39.6
    x[21,1]   product_Su_21_1  -39.6
    x[21,1]   product_Sl_21_1  -8.61111111111111
    x[21,1]   conditional_Sx_lower_21_1  -8.8194444444444429e+00
    x[21,1]   conditional_Sx_upper_21_1  -3.8933333333333337e+01
    x[21,1]   conditional_complement_lower_21_1  8.61111111111111
    x[21,1]   conditional_complement_upper_21_1  39.6
    x[21,1]   hard_cost_D_definition  -4.3637096127170178e-05
    x[21,2]   onehot_21  1
    x[21,2]   inventory_21  -2
    x[21,2]   product_lx_21_2  -8.61111111111111
    x[21,2]   product_ux_21_2  -39.6
    x[21,2]   product_Su_21_2  -39.6
    x[21,2]   product_Sl_21_2  -8.61111111111111
    x[21,2]   conditional_Sx_lower_21_2  -9.0277777777777768e+00
    x[21,2]   conditional_Sx_upper_21_2  -3.9066666666666670e+01
    x[21,2]   conditional_complement_lower_21_2  8.61111111111111
    x[21,2]   conditional_complement_upper_21_2  39.6
    x[21,2]   hard_cost_D_definition  4.3637096127170184e-05
    x[21,3]   onehot_21  1
    x[21,3]   inventory_21  -3
    x[21,3]   product_lx_21_3  -8.61111111111111
    x[21,3]   product_ux_21_3  -39.6
    x[21,3]   product_Su_21_3  -39.6
    x[21,3]   product_Sl_21_3  -8.61111111111111
    x[21,3]   conditional_Sx_lower_21_3  -9.23611111111111
    x[21,3]   conditional_Sx_upper_21_3  -39.2
    x[21,3]   conditional_complement_lower_21_3  8.61111111111111
    x[21,3]   conditional_complement_upper_21_3  39.6
    x[21,3]   hard_cost_D_definition  1.3091128838151056e-04
    x[21,4]   onehot_21  1
    x[21,4]   inventory_21  -4
    x[21,4]   product_lx_21_4  -8.61111111111111
    x[21,4]   product_ux_21_4  -39.6
    x[21,4]   product_Su_21_4  -39.6
    x[21,4]   product_Sl_21_4  -8.61111111111111
    x[21,4]   conditional_Sx_lower_21_4  -9.4444444444444429e+00
    x[21,4]   conditional_Sx_upper_21_4  -3.9333333333333336e+01
    x[21,4]   conditional_complement_lower_21_4  8.61111111111111
    x[21,4]   conditional_complement_upper_21_4  39.6
    x[21,4]   hard_cost_D_definition  4.3637096127170218e-05
    x[21,5]   onehot_21  1
    x[21,5]   inventory_21  -5
    x[21,5]   product_lx_21_5  -8.61111111111111
    x[21,5]   product_ux_21_5  -39.6
    x[21,5]   product_Su_21_5  -39.6
    x[21,5]   product_Sl_21_5  -8.61111111111111
    x[21,5]   conditional_Sx_lower_21_5  -9.6527777777777768e+00
    x[21,5]   conditional_Sx_upper_21_5  -3.9466666666666669e+01
    x[21,5]   conditional_complement_lower_21_5  8.61111111111111
    x[21,5]   conditional_complement_upper_21_5  39.6
    x[21,5]   hard_cost_D_definition  -4.3637096127170150e-05
    x[21,6]   onehot_21  1
    x[21,6]   inventory_21  -6
    x[21,6]   product_lx_21_6  -8.61111111111111
    x[21,6]   product_ux_21_6  -39.6
    x[21,6]   product_Su_21_6  -39.6
    x[21,6]   product_Sl_21_6  -8.61111111111111
    x[21,6]   conditional_Sx_lower_21_6  -9.86111111111111
    x[21,6]   conditional_Sx_upper_21_6  -39.6
    x[21,6]   conditional_complement_lower_21_6  8.61111111111111
    x[21,6]   conditional_complement_upper_21_6  3.9466666666666669e+01
    x[21,6]   hard_cost_D_definition  -1.3091128838151051e-04
    x[22,0]   onehot_22  1
    x[22,0]   product_lx_22_0  -8.61111111111111
    x[22,0]   product_ux_22_0  -39.6
    x[22,0]   product_Su_22_0  -39.6
    x[22,0]   product_Sl_22_0  -8.61111111111111
    x[22,0]   conditional_Sx_lower_22_0  -8.61111111111111
    x[22,0]   conditional_Sx_upper_22_0  -39.6
    x[22,0]   conditional_complement_lower_22_0  8.6289682539682531e+00
    x[22,0]   conditional_complement_upper_22_0  3.9542857142857144e+01
    x[22,0]   hard_cost_D_definition  -6.1091968240974646e-04
    x[22,1]   onehot_22  1
    x[22,1]   inventory_22  -1
    x[22,1]   product_lx_22_1  -8.61111111111111
    x[22,1]   product_ux_22_1  -39.6
    x[22,1]   product_Su_22_1  -39.6
    x[22,1]   product_Sl_22_1  -8.61111111111111
    x[22,1]   conditional_Sx_lower_22_1  -8.6289682539682531e+00
    x[22,1]   conditional_Sx_upper_22_1  -3.9542857142857144e+01
    x[22,1]   conditional_complement_lower_22_1  8.61111111111111
    x[22,1]   conditional_complement_upper_22_1  39.6
    x[22,1]   hard_cost_D_definition  -4.0727978827316433e-04
    x[22,2]   onehot_22  1
    x[22,2]   inventory_22  -2
    x[22,2]   product_lx_22_2  -8.61111111111111
    x[22,2]   product_ux_22_2  -39.6
    x[22,2]   product_Su_22_2  -39.6
    x[22,2]   product_Sl_22_2  -8.61111111111111
    x[22,2]   conditional_Sx_lower_22_2  -8.6468253968253954e+00
    x[22,2]   conditional_Sx_upper_22_2  -3.9485714285714288e+01
    x[22,2]   conditional_complement_lower_22_2  8.61111111111111
    x[22,2]   conditional_complement_upper_22_2  39.6
    x[22,2]   hard_cost_D_definition  -2.0363989413658219e-04
    x[22,3]   onehot_22  1
    x[22,3]   inventory_22  -3
    x[22,3]   product_lx_22_3  -8.61111111111111
    x[22,3]   product_ux_22_3  -39.6
    x[22,3]   product_Su_22_3  -39.6
    x[22,3]   product_Sl_22_3  -8.61111111111111
    x[22,3]   conditional_Sx_lower_22_3  -8.66468253968254
    x[22,3]   conditional_Sx_upper_22_3  -3.9428571428571431e+01
    x[22,3]   conditional_complement_lower_22_3  8.61111111111111
    x[22,3]   conditional_complement_upper_22_3  39.6
    x[22,4]   onehot_22  1
    x[22,4]   inventory_22  -4
    x[22,4]   product_lx_22_4  -8.61111111111111
    x[22,4]   product_ux_22_4  -39.6
    x[22,4]   product_Su_22_4  -39.6
    x[22,4]   product_Sl_22_4  -8.61111111111111
    x[22,4]   conditional_Sx_lower_22_4  -8.6825396825396819e+00
    x[22,4]   conditional_Sx_upper_22_4  -3.9371428571428574e+01
    x[22,4]   conditional_complement_lower_22_4  8.61111111111111
    x[22,4]   conditional_complement_upper_22_4  39.6
    x[22,4]   hard_cost_D_definition  2.0363989413658206e-04
    x[22,5]   onehot_22  1
    x[22,5]   inventory_22  -5
    x[22,5]   product_lx_22_5  -8.61111111111111
    x[22,5]   product_ux_22_5  -39.6
    x[22,5]   product_Su_22_5  -39.6
    x[22,5]   product_Sl_22_5  -8.61111111111111
    x[22,5]   conditional_Sx_lower_22_5  -8.7003968253968242e+00
    x[22,5]   conditional_Sx_upper_22_5  -3.9314285714285717e+01
    x[22,5]   conditional_complement_lower_22_5  8.61111111111111
    x[22,5]   conditional_complement_upper_22_5  39.6
    x[22,5]   hard_cost_D_definition  4.0727978827316422e-04
    x[22,6]   onehot_22  1
    x[22,6]   inventory_22  -6
    x[22,6]   product_lx_22_6  -8.61111111111111
    x[22,6]   product_ux_22_6  -39.6
    x[22,6]   product_Su_22_6  -39.6
    x[22,6]   product_Sl_22_6  -8.61111111111111
    x[22,6]   conditional_Sx_lower_22_6  -8.7182539682539666e+00
    x[22,6]   conditional_Sx_upper_22_6  -3.9257142857142860e+01
    x[22,6]   conditional_complement_lower_22_6  8.61111111111111
    x[22,6]   conditional_complement_upper_22_6  39.6
    x[22,6]   hard_cost_D_definition  6.1091968240974636e-04
    x[22,7]   onehot_22  1
    x[22,7]   inventory_22  -7
    x[22,7]   product_lx_22_7  -8.61111111111111
    x[22,7]   product_ux_22_7  -39.6
    x[22,7]   product_Su_22_7  -39.6
    x[22,7]   product_Sl_22_7  -8.61111111111111
    x[22,7]   conditional_Sx_lower_22_7  -8.73611111111111
    x[22,7]   conditional_Sx_upper_22_7  -39.2
    x[22,7]   conditional_complement_lower_22_7  8.61111111111111
    x[22,7]   conditional_complement_upper_22_7  39.6
    x[22,7]   hard_cost_D_definition  8.1455957654632855e-04
    x[22,8]   onehot_22  1
    x[22,8]   inventory_22  -8
    x[22,8]   product_lx_22_8  -8.61111111111111
    x[22,8]   product_ux_22_8  -39.6
    x[22,8]   product_Su_22_8  -39.6
    x[22,8]   product_Sl_22_8  -8.61111111111111
    x[22,8]   conditional_Sx_lower_22_8  -8.7539682539682531e+00
    x[22,8]   conditional_Sx_upper_22_8  -3.9142857142857146e+01
    x[22,8]   conditional_complement_lower_22_8  8.61111111111111
    x[22,8]   conditional_complement_upper_22_8  39.6
    x[22,8]   hard_cost_D_definition  6.1091968240974657e-04
    x[22,9]   onehot_22  1
    x[22,9]   inventory_22  -9
    x[22,9]   product_lx_22_9  -8.61111111111111
    x[22,9]   product_ux_22_9  -39.6
    x[22,9]   product_Su_22_9  -39.6
    x[22,9]   product_Sl_22_9  -8.61111111111111
    x[22,9]   conditional_Sx_lower_22_9  -8.7718253968253954e+00
    x[22,9]   conditional_Sx_upper_22_9  -3.9085714285714289e+01
    x[22,9]   conditional_complement_lower_22_9  8.61111111111111
    x[22,9]   conditional_complement_upper_22_9  39.6
    x[22,9]   hard_cost_D_definition  4.0727978827316438e-04
    x[22,10]  onehot_22  1
    x[22,10]  inventory_22  -10
    x[22,10]  product_lx_22_10  -8.61111111111111
    x[22,10]  product_ux_22_10  -39.6
    x[22,10]  product_Su_22_10  -39.6
    x[22,10]  product_Sl_22_10  -8.61111111111111
    x[22,10]  conditional_Sx_lower_22_10  -8.7896825396825378e+00
    x[22,10]  conditional_Sx_upper_22_10  -3.9028571428571432e+01
    x[22,10]  conditional_complement_lower_22_10  8.61111111111111
    x[22,10]  conditional_complement_upper_22_10  39.6
    x[22,10]  hard_cost_D_definition  2.0363989413658222e-04
    x[22,11]  onehot_22  1
    x[22,11]  inventory_22  -11
    x[22,11]  product_lx_22_11  -8.61111111111111
    x[22,11]  product_ux_22_11  -39.6
    x[22,11]  product_Su_22_11  -39.6
    x[22,11]  product_Sl_22_11  -8.61111111111111
    x[22,11]  conditional_Sx_lower_22_11  -8.8075396825396819e+00
    x[22,11]  conditional_Sx_upper_22_11  -3.8971428571428575e+01
    x[22,11]  conditional_complement_lower_22_11  8.61111111111111
    x[22,11]  conditional_complement_upper_22_11  39.6
    x[22,12]  onehot_22  1
    x[22,12]  inventory_22  -12
    x[22,12]  product_lx_22_12  -8.61111111111111
    x[22,12]  product_ux_22_12  -39.6
    x[22,12]  product_Su_22_12  -39.6
    x[22,12]  product_Sl_22_12  -8.61111111111111
    x[22,12]  conditional_Sx_lower_22_12  -8.8253968253968242e+00
    x[22,12]  conditional_Sx_upper_22_12  -3.8914285714285718e+01
    x[22,12]  conditional_complement_lower_22_12  8.61111111111111
    x[22,12]  conditional_complement_upper_22_12  39.6
    x[22,12]  hard_cost_D_definition  -2.0363989413658203e-04
    x[22,13]  onehot_22  1
    x[22,13]  inventory_22  -13
    x[22,13]  product_lx_22_13  -8.61111111111111
    x[22,13]  product_ux_22_13  -39.6
    x[22,13]  product_Su_22_13  -39.6
    x[22,13]  product_Sl_22_13  -8.61111111111111
    x[22,13]  conditional_Sx_lower_22_13  -8.8432539682539666e+00
    x[22,13]  conditional_Sx_upper_22_13  -3.8857142857142861e+01
    x[22,13]  conditional_complement_lower_22_13  8.61111111111111
    x[22,13]  conditional_complement_upper_22_13  39.6
    x[22,13]  hard_cost_D_definition  -4.0727978827316417e-04
    x[22,14]  onehot_22  1
    x[22,14]  inventory_22  -14
    x[22,14]  product_lx_22_14  -8.61111111111111
    x[22,14]  product_ux_22_14  -39.6
    x[22,14]  product_Su_22_14  -39.6
    x[22,14]  product_Sl_22_14  -8.61111111111111
    x[22,14]  conditional_Sx_lower_22_14  -8.86111111111111
    x[22,14]  conditional_Sx_upper_22_14  -3.8800000000000004e+01
    x[22,14]  conditional_complement_lower_22_14  8.61111111111111
    x[22,14]  conditional_complement_upper_22_14  39.6
    x[22,14]  hard_cost_D_definition  -6.1091968240974625e-04
    x[22,15]  onehot_22  1
    x[22,15]  inventory_22  -15
    x[22,15]  product_lx_22_15  -8.61111111111111
    x[22,15]  product_ux_22_15  -39.6
    x[22,15]  product_Su_22_15  -39.6
    x[22,15]  product_Sl_22_15  -8.61111111111111
    x[22,15]  conditional_Sx_lower_22_15  -8.8789682539682531e+00
    x[22,15]  conditional_Sx_upper_22_15  -3.8742857142857147e+01
    x[22,15]  conditional_complement_lower_22_15  8.61111111111111
    x[22,15]  conditional_complement_upper_22_15  39.6
    x[22,15]  hard_cost_D_definition  -8.1455957654632844e-04
    x[23,0]   onehot_23  1
    x[23,0]   product_lx_23_0  -8.61111111111111
    x[23,0]   product_ux_23_0  -39.6
    x[23,0]   product_Su_23_0  -39.6
    x[23,0]   product_Sl_23_0  -8.61111111111111
    x[23,0]   conditional_Sx_lower_23_0  -8.61111111111111
    x[23,0]   conditional_Sx_upper_23_0  -37.2
    x[23,0]   conditional_complement_lower_23_0  9.48611111111111
    x[23,0]   conditional_complement_upper_23_0  39.6
    x[23,1]   onehot_23  1
    x[23,1]   inventory_23  -1
    x[23,1]   product_lx_23_1  -8.61111111111111
    x[23,1]   product_ux_23_1  -39.6
    x[23,1]   product_Su_23_1  -39.6
    x[23,1]   product_Sl_23_1  -8.61111111111111
    x[23,1]   conditional_Sx_lower_23_1  -9.48611111111111
    x[23,1]   conditional_Sx_upper_23_1  -3.8000000000000007e+01
    x[23,1]   conditional_complement_lower_23_1  8.61111111111111
    x[23,1]   conditional_complement_upper_23_1  39.6
    x[23,1]   hard_cost_D_definition  2.3564055472727373e-04
    x[23,2]   onehot_23  1
    x[23,2]   inventory_23  -2
    x[23,2]   product_lx_23_2  -8.61111111111111
    x[23,2]   product_ux_23_2  -39.6
    x[23,2]   product_Su_23_2  -39.6
    x[23,2]   product_Sl_23_2  -8.61111111111111
    x[23,2]   conditional_Sx_lower_23_2  -1.0361111111111111e+01
    x[23,2]   conditional_Sx_upper_23_2  -3.8800000000000004e+01
    x[23,2]   conditional_complement_lower_23_2  8.61111111111111
    x[23,2]   conditional_complement_upper_23_2  39.6
    x[23,3]   onehot_23  1
    x[23,3]   inventory_23  -3
    x[23,3]   product_lx_23_3  -8.61111111111111
    x[23,3]   product_ux_23_3  -39.6
    x[23,3]   product_Su_23_3  -39.6
    x[23,3]   product_Sl_23_3  -8.61111111111111
    x[23,3]   conditional_Sx_lower_23_3  -1.1236111111111111e+01
    x[23,3]   conditional_Sx_upper_23_3  -39.6
    x[23,3]   conditional_complement_lower_23_3  8.61111111111111
    x[23,3]   conditional_complement_upper_23_3  3.8800000000000004e+01
    x[23,3]   hard_cost_D_definition  -2.3564055472727373e-04
    x[24,0]   onehot_24  1
    x[24,0]   product_lx_24_0  -8.61111111111111
    x[24,0]   product_ux_24_0  -39.6
    x[24,0]   product_Su_24_0  -39.6
    x[24,0]   product_Sl_24_0  -8.61111111111111
    x[24,0]   conditional_Sx_lower_24_0  -8.73611111111111
    x[24,0]   conditional_Sx_upper_24_0  -39.6
    x[24,0]   conditional_complement_lower_24_0  8.61111111111111
    x[24,0]   conditional_complement_upper_24_0  3.9525000000000006e+01
    x[24,0]   hard_cost_D_definition  -9.3092511011388858e-04
    x[24,1]   onehot_24  1
    x[24,1]   inventory_24  -1
    x[24,1]   product_lx_24_1  -8.61111111111111
    x[24,1]   product_ux_24_1  -39.6
    x[24,1]   product_Su_24_1  -39.6
    x[24,1]   product_Sl_24_1  -8.61111111111111
    x[24,1]   conditional_Sx_lower_24_1  -8.7182539682539666e+00
    x[24,1]   conditional_Sx_upper_24_1  -3.9525000000000006e+01
    x[24,1]   conditional_complement_lower_24_1  8.61111111111111
    x[24,1]   conditional_complement_upper_24_1  39.6
    x[24,1]   hard_cost_D_definition  -6.9819383258541636e-04
    x[24,2]   onehot_24  1
    x[24,2]   inventory_24  -2
    x[24,2]   product_lx_24_2  -8.61111111111111
    x[24,2]   product_ux_24_2  -39.6
    x[24,2]   product_Su_24_2  -39.6
    x[24,2]   product_Sl_24_2  -8.61111111111111
    x[24,2]   conditional_Sx_lower_24_2  -8.7003968253968242e+00
    x[24,2]   conditional_Sx_upper_24_2  -39.45
    x[24,2]   conditional_complement_lower_24_2  8.61111111111111
    x[24,2]   conditional_complement_upper_24_2  39.6
    x[24,2]   hard_cost_D_definition  -4.6546255505694429e-04
    x[24,3]   onehot_24  1
    x[24,3]   inventory_24  -3
    x[24,3]   product_lx_24_3  -8.61111111111111
    x[24,3]   product_ux_24_3  -39.6
    x[24,3]   product_Su_24_3  -39.6
    x[24,3]   product_Sl_24_3  -8.61111111111111
    x[24,3]   conditional_Sx_lower_24_3  -8.6825396825396819e+00
    x[24,3]   conditional_Sx_upper_24_3  -39.375
    x[24,3]   conditional_complement_lower_24_3  8.61111111111111
    x[24,3]   conditional_complement_upper_24_3  39.6
    x[24,3]   hard_cost_D_definition  -2.3273127752847215e-04
    x[24,4]   onehot_24  1
    x[24,4]   inventory_24  -4
    x[24,4]   product_lx_24_4  -8.61111111111111
    x[24,4]   product_ux_24_4  -39.6
    x[24,4]   product_Su_24_4  -39.6
    x[24,4]   product_Sl_24_4  -8.61111111111111
    x[24,4]   conditional_Sx_lower_24_4  -8.66468253968254
    x[24,4]   conditional_Sx_upper_24_4  -3.9300000000000004e+01
    x[24,4]   conditional_complement_lower_24_4  8.61111111111111
    x[24,4]   conditional_complement_upper_24_4  39.6
    x[24,5]   onehot_24  1
    x[24,5]   inventory_24  -5
    x[24,5]   product_lx_24_5  -8.61111111111111
    x[24,5]   product_ux_24_5  -39.6
    x[24,5]   product_Su_24_5  -39.6
    x[24,5]   product_Sl_24_5  -8.61111111111111
    x[24,5]   conditional_Sx_lower_24_5  -8.6468253968253954e+00
    x[24,5]   conditional_Sx_upper_24_5  -39.225
    x[24,5]   conditional_complement_lower_24_5  8.61111111111111
    x[24,5]   conditional_complement_upper_24_5  39.6
    x[24,5]   hard_cost_D_definition  2.3273127752847215e-04
    x[24,6]   onehot_24  1
    x[24,6]   inventory_24  -6
    x[24,6]   product_lx_24_6  -8.61111111111111
    x[24,6]   product_ux_24_6  -39.6
    x[24,6]   product_Su_24_6  -39.6
    x[24,6]   product_Sl_24_6  -8.61111111111111
    x[24,6]   conditional_Sx_lower_24_6  -8.6289682539682531e+00
    x[24,6]   conditional_Sx_upper_24_6  -3.9150000000000006e+01
    x[24,6]   conditional_complement_lower_24_6  8.61111111111111
    x[24,6]   conditional_complement_upper_24_6  39.6
    x[24,6]   hard_cost_D_definition  4.6546255505694429e-04
    x[24,7]   onehot_24  1
    x[24,7]   inventory_24  -7
    x[24,7]   product_lx_24_7  -8.61111111111111
    x[24,7]   product_ux_24_7  -39.6
    x[24,7]   product_Su_24_7  -39.6
    x[24,7]   product_Sl_24_7  -8.61111111111111
    x[24,7]   conditional_Sx_lower_24_7  -8.61111111111111
    x[24,7]   conditional_Sx_upper_24_7  -39.075
    x[24,7]   conditional_complement_lower_24_7  8.61111111111111
    x[24,7]   conditional_complement_upper_24_7  39.6
    x[24,7]   hard_cost_D_definition  6.9819383258541646e-04
    x[24,8]   onehot_24  1
    x[24,8]   inventory_24  -8
    x[24,8]   product_lx_24_8  -8.61111111111111
    x[24,8]   product_ux_24_8  -39.6
    x[24,8]   product_Su_24_8  -39.6
    x[24,8]   product_Sl_24_8  -8.61111111111111
    x[24,8]   conditional_Sx_lower_24_8  -8.61111111111111
    x[24,8]   conditional_Sx_upper_24_8  -39
    x[24,8]   conditional_complement_lower_24_8  8.61111111111111
    x[24,8]   conditional_complement_upper_24_8  39.6
    x[24,8]   hard_cost_D_definition  9.3092511011388858e-04
    x[24,9]   onehot_24  1
    x[24,9]   inventory_24  -9
    x[24,9]   product_lx_24_9  -8.61111111111111
    x[24,9]   product_ux_24_9  -39.6
    x[24,9]   product_Su_24_9  -39.6
    x[24,9]   product_Sl_24_9  -8.61111111111111
    x[24,9]   conditional_Sx_lower_24_9  -8.61111111111111
    x[24,9]   conditional_Sx_upper_24_9  -3.8925000000000004e+01
    x[24,9]   conditional_complement_lower_24_9  8.61111111111111
    x[24,9]   conditional_complement_upper_24_9  39.6
    x[24,9]   hard_cost_D_definition  6.9819383258541646e-04
    x[24,10]  onehot_24  1
    x[24,10]  inventory_24  -10
    x[24,10]  product_lx_24_10  -8.61111111111111
    x[24,10]  product_ux_24_10  -39.6
    x[24,10]  product_Su_24_10  -39.6
    x[24,10]  product_Sl_24_10  -8.61111111111111
    x[24,10]  conditional_Sx_lower_24_10  -8.61111111111111
    x[24,10]  conditional_Sx_upper_24_10  -38.85
    x[24,10]  conditional_complement_lower_24_10  8.61111111111111
    x[24,10]  conditional_complement_upper_24_10  39.6
    x[24,10]  hard_cost_D_definition  4.6546255505694429e-04
    x[24,11]  onehot_24  1
    x[24,11]  inventory_24  -11
    x[24,11]  product_lx_24_11  -8.61111111111111
    x[24,11]  product_ux_24_11  -39.6
    x[24,11]  product_Su_24_11  -39.6
    x[24,11]  product_Sl_24_11  -8.61111111111111
    x[24,11]  conditional_Sx_lower_24_11  -8.61111111111111
    x[24,11]  conditional_Sx_upper_24_11  -3.8775000000000006e+01
    x[24,11]  conditional_complement_lower_24_11  8.61111111111111
    x[24,11]  conditional_complement_upper_24_11  39.6
    x[24,11]  hard_cost_D_definition  2.3273127752847215e-04
    x[24,12]  onehot_24  1
    x[24,12]  inventory_24  -12
    x[24,12]  product_lx_24_12  -8.61111111111111
    x[24,12]  product_ux_24_12  -39.6
    x[24,12]  product_Su_24_12  -39.6
    x[24,12]  product_Sl_24_12  -8.61111111111111
    x[24,12]  conditional_Sx_lower_24_12  -8.61111111111111
    x[24,12]  conditional_Sx_upper_24_12  -38.7
    x[24,12]  conditional_complement_lower_24_12  8.61111111111111
    x[24,12]  conditional_complement_upper_24_12  39.6
    x[24,13]  onehot_24  1
    x[24,13]  inventory_24  -13
    x[24,13]  product_lx_24_13  -8.61111111111111
    x[24,13]  product_ux_24_13  -39.6
    x[24,13]  product_Su_24_13  -39.6
    x[24,13]  product_Sl_24_13  -8.61111111111111
    x[24,13]  conditional_Sx_lower_24_13  -8.61111111111111
    x[24,13]  conditional_Sx_upper_24_13  -38.625
    x[24,13]  conditional_complement_lower_24_13  8.61111111111111
    x[24,13]  conditional_complement_upper_24_13  39.6
    x[24,13]  hard_cost_D_definition  -2.3273127752847215e-04
    x[24,14]  onehot_24  1
    x[24,14]  inventory_24  -14
    x[24,14]  product_lx_24_14  -8.61111111111111
    x[24,14]  product_ux_24_14  -39.6
    x[24,14]  product_Su_24_14  -39.6
    x[24,14]  product_Sl_24_14  -8.61111111111111
    x[24,14]  conditional_Sx_lower_24_14  -8.61111111111111
    x[24,14]  conditional_Sx_upper_24_14  -3.8550000000000004e+01
    x[24,14]  conditional_complement_lower_24_14  8.61111111111111
    x[24,14]  conditional_complement_upper_24_14  39.6
    x[24,14]  hard_cost_D_definition  -4.6546255505694429e-04
    x[24,15]  onehot_24  1
    x[24,15]  inventory_24  -15
    x[24,15]  product_lx_24_15  -8.61111111111111
    x[24,15]  product_ux_24_15  -39.6
    x[24,15]  product_Su_24_15  -39.6
    x[24,15]  product_Sl_24_15  -8.61111111111111
    x[24,15]  conditional_Sx_lower_24_15  -8.61111111111111
    x[24,15]  conditional_Sx_upper_24_15  -38.475
    x[24,15]  conditional_complement_lower_24_15  8.61111111111111
    x[24,15]  conditional_complement_upper_24_15  39.6
    x[24,15]  hard_cost_D_definition  -6.9819383258541636e-04
    x[25,0]   onehot_25  1
    x[25,0]   product_lx_25_0  -8.61111111111111
    x[25,0]   product_ux_25_0  -39.6
    x[25,0]   product_Su_25_0  -39.6
    x[25,0]   product_Sl_25_0  -8.61111111111111
    x[25,0]   conditional_Sx_lower_25_0  -8.61111111111111
    x[25,0]   conditional_Sx_upper_25_0  -3.8400000000000006e+01
    x[25,0]   conditional_complement_lower_25_0  8.98611111111111
    x[25,0]   conditional_complement_upper_25_0  39.6
    x[25,0]   hard_cost_D_definition  -1.1782027736363687e-04
    x[25,1]   onehot_25  1
    x[25,1]   inventory_25  -1
    x[25,1]   product_lx_25_1  -8.61111111111111
    x[25,1]   product_ux_25_1  -39.6
    x[25,1]   product_Su_25_1  -39.6
    x[25,1]   product_Sl_25_1  -8.61111111111111
    x[25,1]   conditional_Sx_lower_25_1  -8.98611111111111
    x[25,1]   conditional_Sx_upper_25_1  -38.7
    x[25,1]   conditional_complement_lower_25_1  8.61111111111111
    x[25,1]   conditional_complement_upper_25_1  39.6
    x[25,2]   onehot_25  1
    x[25,2]   inventory_25  -2
    x[25,2]   product_lx_25_2  -8.61111111111111
    x[25,2]   product_ux_25_2  -39.6
    x[25,2]   product_Su_25_2  -39.6
    x[25,2]   product_Sl_25_2  -8.61111111111111
    x[25,2]   conditional_Sx_lower_25_2  -9.36111111111111
    x[25,2]   conditional_Sx_upper_25_2  -3.9000000000000007e+01
    x[25,2]   conditional_complement_lower_25_2  8.61111111111111
    x[25,2]   conditional_complement_upper_25_2  39.6
    x[25,2]   hard_cost_D_definition  1.1782027736363687e-04
    x[25,3]   onehot_25  1
    x[25,3]   inventory_25  -3
    x[25,3]   product_lx_25_3  -8.61111111111111
    x[25,3]   product_ux_25_3  -39.6
    x[25,3]   product_Su_25_3  -39.6
    x[25,3]   product_Sl_25_3  -8.61111111111111
    x[25,3]   conditional_Sx_lower_25_3  -9.73611111111111
    x[25,3]   conditional_Sx_upper_25_3  -3.9300000000000004e+01
    x[25,3]   conditional_complement_lower_25_3  8.61111111111111
    x[25,3]   conditional_complement_upper_25_3  39.6
    x[25,4]   onehot_25  1
    x[25,4]   inventory_25  -4
    x[25,4]   product_lx_25_4  -8.61111111111111
    x[25,4]   product_ux_25_4  -39.6
    x[25,4]   product_Su_25_4  -39.6
    x[25,4]   product_Sl_25_4  -8.61111111111111
    x[25,4]   conditional_Sx_lower_25_4  -1.0111111111111111e+01
    x[25,4]   conditional_Sx_upper_25_4  -39.6
    x[25,4]   conditional_complement_lower_25_4  8.61111111111111
    x[25,4]   conditional_complement_upper_25_4  3.9300000000000004e+01
    x[25,4]   hard_cost_D_definition  -1.1782027736363687e-04
    x[26,0]   onehot_26  1
    x[26,0]   product_lx_26_0  -8.61111111111111
    x[26,0]   product_ux_26_0  -39.6
    x[26,0]   product_Su_26_0  -39.6
    x[26,0]   product_Sl_26_0  -8.61111111111111
    x[26,0]   conditional_Sx_lower_26_0  -8.61111111111111
    x[26,0]   conditional_Sx_upper_26_0  -39.2
    x[26,0]   conditional_complement_lower_26_0  8.73611111111111
    x[26,0]   conditional_complement_upper_26_0  39.6
    x[26,0]   hard_cost_D_definition  -2.3273157207916555e-04
    x[26,1]   onehot_26  1
    x[26,1]   inventory_26  -1
    x[26,1]   product_lx_26_1  -8.61111111111111
    x[26,1]   product_ux_26_1  -39.6
    x[26,1]   product_Su_26_1  -39.6
    x[26,1]   product_Sl_26_1  -8.61111111111111
    x[26,1]   conditional_Sx_lower_26_1  -8.73611111111111
    x[26,1]   conditional_Sx_upper_26_1  -3.9250000000000007e+01
    x[26,1]   conditional_complement_lower_26_1  8.61111111111111
    x[26,1]   conditional_complement_upper_26_1  39.6
    x[26,1]   hard_cost_D_definition  -1.1636578603958278e-04
    x[26,2]   onehot_26  1
    x[26,2]   inventory_26  -2
    x[26,2]   product_lx_26_2  -8.61111111111111
    x[26,2]   product_ux_26_2  -39.6
    x[26,2]   product_Su_26_2  -39.6
    x[26,2]   product_Sl_26_2  -8.61111111111111
    x[26,2]   conditional_Sx_lower_26_2  -8.86111111111111
    x[26,2]   conditional_Sx_upper_26_2  -3.9300000000000004e+01
    x[26,2]   conditional_complement_lower_26_2  8.61111111111111
    x[26,2]   conditional_complement_upper_26_2  39.6
    x[26,3]   onehot_26  1
    x[26,3]   inventory_26  -3
    x[26,3]   product_lx_26_3  -8.61111111111111
    x[26,3]   product_ux_26_3  -39.6
    x[26,3]   product_Su_26_3  -39.6
    x[26,3]   product_Sl_26_3  -8.61111111111111
    x[26,3]   conditional_Sx_lower_26_3  -8.98611111111111
    x[26,3]   conditional_Sx_upper_26_3  -39.35
    x[26,3]   conditional_complement_lower_26_3  8.61111111111111
    x[26,3]   conditional_complement_upper_26_3  39.6
    x[26,3]   hard_cost_D_definition  1.1636578603958278e-04
    x[26,4]   onehot_26  1
    x[26,4]   inventory_26  -4
    x[26,4]   product_lx_26_4  -8.61111111111111
    x[26,4]   product_ux_26_4  -39.6
    x[26,4]   product_Su_26_4  -39.6
    x[26,4]   product_Sl_26_4  -8.61111111111111
    x[26,4]   conditional_Sx_lower_26_4  -9.11111111111111
    x[26,4]   conditional_Sx_upper_26_4  -3.9400000000000006e+01
    x[26,4]   conditional_complement_lower_26_4  8.61111111111111
    x[26,4]   conditional_complement_upper_26_4  39.6
    x[26,4]   hard_cost_D_definition  2.3273157207916555e-04
    x[26,5]   onehot_26  1
    x[26,5]   inventory_26  -5
    x[26,5]   product_lx_26_5  -8.61111111111111
    x[26,5]   product_ux_26_5  -39.6
    x[26,5]   product_Su_26_5  -39.6
    x[26,5]   product_Sl_26_5  -8.61111111111111
    x[26,5]   conditional_Sx_lower_26_5  -9.23611111111111
    x[26,5]   conditional_Sx_upper_26_5  -39.45
    x[26,5]   conditional_complement_lower_26_5  8.61111111111111
    x[26,5]   conditional_complement_upper_26_5  39.6
    x[26,5]   hard_cost_D_definition  1.1636578603958278e-04
    x[26,6]   onehot_26  1
    x[26,6]   inventory_26  -6
    x[26,6]   product_lx_26_6  -8.61111111111111
    x[26,6]   product_ux_26_6  -39.6
    x[26,6]   product_Su_26_6  -39.6
    x[26,6]   product_Sl_26_6  -8.61111111111111
    x[26,6]   conditional_Sx_lower_26_6  -9.36111111111111
    x[26,6]   conditional_Sx_upper_26_6  -3.9500000000000007e+01
    x[26,6]   conditional_complement_lower_26_6  8.61111111111111
    x[26,6]   conditional_complement_upper_26_6  39.6
    x[26,7]   onehot_26  1
    x[26,7]   inventory_26  -7
    x[26,7]   product_lx_26_7  -8.61111111111111
    x[26,7]   product_ux_26_7  -39.6
    x[26,7]   product_Su_26_7  -39.6
    x[26,7]   product_Sl_26_7  -8.61111111111111
    x[26,7]   conditional_Sx_lower_26_7  -9.48611111111111
    x[26,7]   conditional_Sx_upper_26_7  -3.9550000000000004e+01
    x[26,7]   conditional_complement_lower_26_7  8.61111111111111
    x[26,7]   conditional_complement_upper_26_7  39.6
    x[26,7]   hard_cost_D_definition  -1.1636578603958278e-04
    x[26,8]   onehot_26  1
    x[26,8]   inventory_26  -8
    x[26,8]   product_lx_26_8  -8.61111111111111
    x[26,8]   product_ux_26_8  -39.6
    x[26,8]   product_Su_26_8  -39.6
    x[26,8]   product_Sl_26_8  -8.61111111111111
    x[26,8]   conditional_Sx_lower_26_8  -9.61111111111111
    x[26,8]   conditional_Sx_upper_26_8  -39.6
    x[26,8]   conditional_complement_lower_26_8  8.61111111111111
    x[26,8]   conditional_complement_upper_26_8  3.9550000000000004e+01
    x[26,8]   hard_cost_D_definition  -2.3273157207916555e-04
    x[27,0]   onehot_27  1
    x[27,0]   product_lx_27_0  -8.61111111111111
    x[27,0]   product_ux_27_0  -39.6
    x[27,0]   product_Su_27_0  -39.6
    x[27,0]   product_Sl_27_0  -8.61111111111111
    x[27,0]   conditional_Sx_lower_27_0  -8.61111111111111
    x[27,0]   conditional_Sx_upper_27_0  -3.8800000000000004e+01
    x[27,0]   conditional_complement_lower_27_0  8.8194444444444429e+00
    x[27,0]   conditional_complement_upper_27_0  39.6
    x[27,0]   hard_cost_D_definition  -1.3091128838151053e-04
    x[27,1]   onehot_27  1
    x[27,1]   inventory_27  -1
    x[27,1]   product_lx_27_1  -8.61111111111111
    x[27,1]   product_ux_27_1  -39.6
    x[27,1]   product_Su_27_1  -39.6
    x[27,1]   product_Sl_27_1  -8.61111111111111
    x[27,1]   conditional_Sx_lower_27_1  -8.8194444444444429e+00
    x[27,1]   conditional_Sx_upper_27_1  -3.8933333333333337e+01
    x[27,1]   conditional_complement_lower_27_1  8.61111111111111
    x[27,1]   conditional_complement_upper_27_1  39.6
    x[27,1]   hard_cost_D_definition  -4.3637096127170178e-05
    x[27,2]   onehot_27  1
    x[27,2]   inventory_27  -2
    x[27,2]   product_lx_27_2  -8.61111111111111
    x[27,2]   product_ux_27_2  -39.6
    x[27,2]   product_Su_27_2  -39.6
    x[27,2]   product_Sl_27_2  -8.61111111111111
    x[27,2]   conditional_Sx_lower_27_2  -9.0277777777777768e+00
    x[27,2]   conditional_Sx_upper_27_2  -3.9066666666666670e+01
    x[27,2]   conditional_complement_lower_27_2  8.61111111111111
    x[27,2]   conditional_complement_upper_27_2  39.6
    x[27,2]   hard_cost_D_definition  4.3637096127170184e-05
    x[27,3]   onehot_27  1
    x[27,3]   inventory_27  -3
    x[27,3]   product_lx_27_3  -8.61111111111111
    x[27,3]   product_ux_27_3  -39.6
    x[27,3]   product_Su_27_3  -39.6
    x[27,3]   product_Sl_27_3  -8.61111111111111
    x[27,3]   conditional_Sx_lower_27_3  -9.23611111111111
    x[27,3]   conditional_Sx_upper_27_3  -39.2
    x[27,3]   conditional_complement_lower_27_3  8.61111111111111
    x[27,3]   conditional_complement_upper_27_3  39.6
    x[27,3]   hard_cost_D_definition  1.3091128838151056e-04
    x[27,4]   onehot_27  1
    x[27,4]   inventory_27  -4
    x[27,4]   product_lx_27_4  -8.61111111111111
    x[27,4]   product_ux_27_4  -39.6
    x[27,4]   product_Su_27_4  -39.6
    x[27,4]   product_Sl_27_4  -8.61111111111111
    x[27,4]   conditional_Sx_lower_27_4  -9.4444444444444429e+00
    x[27,4]   conditional_Sx_upper_27_4  -3.9333333333333336e+01
    x[27,4]   conditional_complement_lower_27_4  8.61111111111111
    x[27,4]   conditional_complement_upper_27_4  39.6
    x[27,4]   hard_cost_D_definition  4.3637096127170218e-05
    x[27,5]   onehot_27  1
    x[27,5]   inventory_27  -5
    x[27,5]   product_lx_27_5  -8.61111111111111
    x[27,5]   product_ux_27_5  -39.6
    x[27,5]   product_Su_27_5  -39.6
    x[27,5]   product_Sl_27_5  -8.61111111111111
    x[27,5]   conditional_Sx_lower_27_5  -9.6527777777777768e+00
    x[27,5]   conditional_Sx_upper_27_5  -3.9466666666666669e+01
    x[27,5]   conditional_complement_lower_27_5  8.61111111111111
    x[27,5]   conditional_complement_upper_27_5  39.6
    x[27,5]   hard_cost_D_definition  -4.3637096127170150e-05
    x[27,6]   onehot_27  1
    x[27,6]   inventory_27  -6
    x[27,6]   product_lx_27_6  -8.61111111111111
    x[27,6]   product_ux_27_6  -39.6
    x[27,6]   product_Su_27_6  -39.6
    x[27,6]   product_Sl_27_6  -8.61111111111111
    x[27,6]   conditional_Sx_lower_27_6  -9.86111111111111
    x[27,6]   conditional_Sx_upper_27_6  -39.6
    x[27,6]   conditional_complement_lower_27_6  8.61111111111111
    x[27,6]   conditional_complement_upper_27_6  3.9466666666666669e+01
    x[27,6]   hard_cost_D_definition  -1.3091128838151051e-04
    x[28,0]   onehot_28  1
    x[28,0]   product_lx_28_0  -8.61111111111111
    x[28,0]   product_ux_28_0  -39.6
    x[28,0]   product_Su_28_0  -39.6
    x[28,0]   product_Sl_28_0  -8.61111111111111
    x[28,0]   conditional_Sx_lower_28_0  -8.61111111111111
    x[28,0]   conditional_Sx_upper_28_0  -3.8800000000000004e+01
    x[28,0]   conditional_complement_lower_28_0  8.8194444444444429e+00
    x[28,0]   conditional_complement_upper_28_0  39.6
    x[28,0]   hard_cost_D_definition  -1.3091128838151053e-04
    x[28,1]   onehot_28  1
    x[28,1]   inventory_28  -1
    x[28,1]   product_lx_28_1  -8.61111111111111
    x[28,1]   product_ux_28_1  -39.6
    x[28,1]   product_Su_28_1  -39.6
    x[28,1]   product_Sl_28_1  -8.61111111111111
    x[28,1]   conditional_Sx_lower_28_1  -8.8194444444444429e+00
    x[28,1]   conditional_Sx_upper_28_1  -3.8933333333333337e+01
    x[28,1]   conditional_complement_lower_28_1  8.61111111111111
    x[28,1]   conditional_complement_upper_28_1  39.6
    x[28,1]   hard_cost_D_definition  -4.3637096127170178e-05
    x[28,2]   onehot_28  1
    x[28,2]   inventory_28  -2
    x[28,2]   product_lx_28_2  -8.61111111111111
    x[28,2]   product_ux_28_2  -39.6
    x[28,2]   product_Su_28_2  -39.6
    x[28,2]   product_Sl_28_2  -8.61111111111111
    x[28,2]   conditional_Sx_lower_28_2  -9.0277777777777768e+00
    x[28,2]   conditional_Sx_upper_28_2  -3.9066666666666670e+01
    x[28,2]   conditional_complement_lower_28_2  8.61111111111111
    x[28,2]   conditional_complement_upper_28_2  39.6
    x[28,2]   hard_cost_D_definition  4.3637096127170184e-05
    x[28,3]   onehot_28  1
    x[28,3]   inventory_28  -3
    x[28,3]   product_lx_28_3  -8.61111111111111
    x[28,3]   product_ux_28_3  -39.6
    x[28,3]   product_Su_28_3  -39.6
    x[28,3]   product_Sl_28_3  -8.61111111111111
    x[28,3]   conditional_Sx_lower_28_3  -9.23611111111111
    x[28,3]   conditional_Sx_upper_28_3  -39.2
    x[28,3]   conditional_complement_lower_28_3  8.61111111111111
    x[28,3]   conditional_complement_upper_28_3  39.6
    x[28,3]   hard_cost_D_definition  1.3091128838151056e-04
    x[28,4]   onehot_28  1
    x[28,4]   inventory_28  -4
    x[28,4]   product_lx_28_4  -8.61111111111111
    x[28,4]   product_ux_28_4  -39.6
    x[28,4]   product_Su_28_4  -39.6
    x[28,4]   product_Sl_28_4  -8.61111111111111
    x[28,4]   conditional_Sx_lower_28_4  -9.4444444444444429e+00
    x[28,4]   conditional_Sx_upper_28_4  -3.9333333333333336e+01
    x[28,4]   conditional_complement_lower_28_4  8.61111111111111
    x[28,4]   conditional_complement_upper_28_4  39.6
    x[28,4]   hard_cost_D_definition  4.3637096127170218e-05
    x[28,5]   onehot_28  1
    x[28,5]   inventory_28  -5
    x[28,5]   product_lx_28_5  -8.61111111111111
    x[28,5]   product_ux_28_5  -39.6
    x[28,5]   product_Su_28_5  -39.6
    x[28,5]   product_Sl_28_5  -8.61111111111111
    x[28,5]   conditional_Sx_lower_28_5  -9.6527777777777768e+00
    x[28,5]   conditional_Sx_upper_28_5  -3.9466666666666669e+01
    x[28,5]   conditional_complement_lower_28_5  8.61111111111111
    x[28,5]   conditional_complement_upper_28_5  39.6
    x[28,5]   hard_cost_D_definition  -4.3637096127170150e-05
    x[28,6]   onehot_28  1
    x[28,6]   inventory_28  -6
    x[28,6]   product_lx_28_6  -8.61111111111111
    x[28,6]   product_ux_28_6  -39.6
    x[28,6]   product_Su_28_6  -39.6
    x[28,6]   product_Sl_28_6  -8.61111111111111
    x[28,6]   conditional_Sx_lower_28_6  -9.86111111111111
    x[28,6]   conditional_Sx_upper_28_6  -39.6
    x[28,6]   conditional_complement_lower_28_6  8.61111111111111
    x[28,6]   conditional_complement_upper_28_6  3.9466666666666669e+01
    x[28,6]   hard_cost_D_definition  -1.3091128838151051e-04
    x[29,0]   onehot_29  1
    x[29,0]   product_lx_29_0  -8.61111111111111
    x[29,0]   product_ux_29_0  -39.6
    x[29,0]   product_Su_29_0  -39.6
    x[29,0]   product_Sl_29_0  -8.61111111111111
    x[29,0]   conditional_Sx_lower_29_0  -8.61111111111111
    x[29,0]   conditional_Sx_upper_29_0  -39.6
    x[29,0]   conditional_complement_lower_29_0  8.68611111111111
    x[29,0]   conditional_complement_upper_29_0  39.6
    x[29,0]   hard_cost_D_definition  -3.6364286046067603e-04
    x[29,1]   onehot_29  1
    x[29,1]   inventory_29  -1
    x[29,1]   product_lx_29_1  -8.61111111111111
    x[29,1]   product_ux_29_1  -39.6
    x[29,1]   product_Su_29_1  -39.6
    x[29,1]   product_Sl_29_1  -8.61111111111111
    x[29,1]   conditional_Sx_lower_29_1  -8.68611111111111
    x[29,1]   conditional_Sx_upper_29_1  -39.6
    x[29,1]   conditional_complement_lower_29_1  8.61111111111111
    x[29,1]   conditional_complement_upper_29_1  39.6
    x[29,1]   hard_cost_D_definition  -2.1818571627640559e-04
    x[29,2]   onehot_29  1
    x[29,2]   inventory_29  -2
    x[29,2]   product_lx_29_2  -8.61111111111111
    x[29,2]   product_ux_29_2  -39.6
    x[29,2]   product_Su_29_2  -39.6
    x[29,2]   product_Sl_29_2  -8.61111111111111
    x[29,2]   conditional_Sx_lower_29_2  -8.76111111111111
    x[29,2]   conditional_Sx_upper_29_2  -39.6
    x[29,2]   conditional_complement_lower_29_2  8.61111111111111
    x[29,2]   conditional_complement_upper_29_2  39.6
    x[29,2]   hard_cost_D_definition  -7.2728572092135138e-05
    x[29,3]   onehot_29  1
    x[29,3]   inventory_29  -3
    x[29,3]   product_lx_29_3  -8.61111111111111
    x[29,3]   product_ux_29_3  -39.6
    x[29,3]   product_Su_29_3  -39.6
    x[29,3]   product_Sl_29_3  -8.61111111111111
    x[29,3]   conditional_Sx_lower_29_3  -8.83611111111111
    x[29,3]   conditional_Sx_upper_29_3  -39.6
    x[29,3]   conditional_complement_lower_29_3  8.61111111111111
    x[29,3]   conditional_complement_upper_29_3  39.6
    x[29,3]   hard_cost_D_definition  7.2728572092135315e-05
    x[29,4]   onehot_29  1
    x[29,4]   inventory_29  -4
    x[29,4]   product_lx_29_4  -8.61111111111111
    x[29,4]   product_ux_29_4  -39.6
    x[29,4]   product_Su_29_4  -39.6
    x[29,4]   product_Sl_29_4  -8.61111111111111
    x[29,4]   conditional_Sx_lower_29_4  -8.91111111111111
    x[29,4]   conditional_Sx_upper_29_4  -39.6
    x[29,4]   conditional_complement_lower_29_4  8.61111111111111
    x[29,4]   conditional_complement_upper_29_4  39.6
    x[29,4]   hard_cost_D_definition  2.1818571627640578e-04
    x[29,5]   onehot_29  1
    x[29,5]   inventory_29  -5
    x[29,5]   product_lx_29_5  -8.61111111111111
    x[29,5]   product_ux_29_5  -39.6
    x[29,5]   product_Su_29_5  -39.6
    x[29,5]   product_Sl_29_5  -8.61111111111111
    x[29,5]   conditional_Sx_lower_29_5  -8.98611111111111
    x[29,5]   conditional_Sx_upper_29_5  -39.6
    x[29,5]   conditional_complement_lower_29_5  8.61111111111111
    x[29,5]   conditional_complement_upper_29_5  39.6
    x[29,5]   hard_cost_D_definition  3.6364286046067619e-04
    x[29,6]   onehot_29  1
    x[29,6]   inventory_29  -6
    x[29,6]   product_lx_29_6  -8.61111111111111
    x[29,6]   product_ux_29_6  -39.6
    x[29,6]   product_Su_29_6  -39.6
    x[29,6]   product_Sl_29_6  -8.61111111111111
    x[29,6]   conditional_Sx_lower_29_6  -9.06111111111111
    x[29,6]   conditional_Sx_upper_29_6  -39.6
    x[29,6]   conditional_complement_lower_29_6  8.61111111111111
    x[29,6]   conditional_complement_upper_29_6  39.6
    x[29,6]   hard_cost_D_definition  2.1818571627640570e-04
    x[29,7]   onehot_29  1
    x[29,7]   inventory_29  -7
    x[29,7]   product_lx_29_7  -8.61111111111111
    x[29,7]   product_ux_29_7  -39.6
    x[29,7]   product_Su_29_7  -39.6
    x[29,7]   product_Sl_29_7  -8.61111111111111
    x[29,7]   conditional_Sx_lower_29_7  -9.1361111111111111e+00
    x[29,7]   conditional_Sx_upper_29_7  -39.6
    x[29,7]   conditional_complement_lower_29_7  8.61111111111111
    x[29,7]   conditional_complement_upper_29_7  39.6
    x[29,7]   hard_cost_D_definition  7.2728572092135233e-05
    x[29,8]   onehot_29  1
    x[29,8]   inventory_29  -8
    x[29,8]   product_lx_29_8  -8.61111111111111
    x[29,8]   product_ux_29_8  -39.6
    x[29,8]   product_Su_29_8  -39.6
    x[29,8]   product_Sl_29_8  -8.61111111111111
    x[29,8]   conditional_Sx_lower_29_8  -9.21111111111111
    x[29,8]   conditional_Sx_upper_29_8  -39.6
    x[29,8]   conditional_complement_lower_29_8  8.61111111111111
    x[29,8]   conditional_complement_upper_29_8  39.6
    x[29,8]   hard_cost_D_definition  -7.2728572092135220e-05
    x[29,9]   onehot_29  1
    x[29,9]   inventory_29  -9
    x[29,9]   product_lx_29_9  -8.61111111111111
    x[29,9]   product_ux_29_9  -39.6
    x[29,9]   product_Su_29_9  -39.6
    x[29,9]   product_Sl_29_9  -8.61111111111111
    x[29,9]   conditional_Sx_lower_29_9  -9.28611111111111
    x[29,9]   conditional_Sx_upper_29_9  -39.6
    x[29,9]   conditional_complement_lower_29_9  8.61111111111111
    x[29,9]   conditional_complement_upper_29_9  39.6
    x[29,9]   hard_cost_D_definition  -2.1818571627640567e-04
    x[29,10]  onehot_29  1
    x[29,10]  inventory_29  -10
    x[29,10]  product_lx_29_10  -8.61111111111111
    x[29,10]  product_ux_29_10  -39.6
    x[29,10]  product_Su_29_10  -39.6
    x[29,10]  product_Sl_29_10  -8.61111111111111
    x[29,10]  conditional_Sx_lower_29_10  -9.36111111111111
    x[29,10]  conditional_Sx_upper_29_10  -39.6
    x[29,10]  conditional_complement_lower_29_10  8.61111111111111
    x[29,10]  conditional_complement_upper_29_10  39.6
    x[29,10]  hard_cost_D_definition  -3.6364286046067614e-04
    x[30,0]   onehot_30  1
    x[30,0]   product_lx_30_0  -8.61111111111111
    x[30,0]   product_ux_30_0  -39.6
    x[30,0]   product_Su_30_0  -39.6
    x[30,0]   product_Sl_30_0  -8.61111111111111
    x[30,0]   conditional_Sx_lower_30_0  -8.61111111111111
    x[30,0]   conditional_Sx_upper_30_0  -39.2
    x[30,0]   conditional_complement_lower_30_0  8.73611111111111
    x[30,0]   conditional_complement_upper_30_0  39.6
    x[30,0]   hard_cost_D_definition  -2.3273157207916555e-04
    x[30,1]   onehot_30  1
    x[30,1]   inventory_30  -1
    x[30,1]   product_lx_30_1  -8.61111111111111
    x[30,1]   product_ux_30_1  -39.6
    x[30,1]   product_Su_30_1  -39.6
    x[30,1]   product_Sl_30_1  -8.61111111111111
    x[30,1]   conditional_Sx_lower_30_1  -8.73611111111111
    x[30,1]   conditional_Sx_upper_30_1  -3.9250000000000007e+01
    x[30,1]   conditional_complement_lower_30_1  8.61111111111111
    x[30,1]   conditional_complement_upper_30_1  39.6
    x[30,1]   hard_cost_D_definition  -1.1636578603958278e-04
    x[30,2]   onehot_30  1
    x[30,2]   inventory_30  -2
    x[30,2]   product_lx_30_2  -8.61111111111111
    x[30,2]   product_ux_30_2  -39.6
    x[30,2]   product_Su_30_2  -39.6
    x[30,2]   product_Sl_30_2  -8.61111111111111
    x[30,2]   conditional_Sx_lower_30_2  -8.86111111111111
    x[30,2]   conditional_Sx_upper_30_2  -3.9300000000000004e+01
    x[30,2]   conditional_complement_lower_30_2  8.61111111111111
    x[30,2]   conditional_complement_upper_30_2  39.6
    x[30,3]   onehot_30  1
    x[30,3]   inventory_30  -3
    x[30,3]   product_lx_30_3  -8.61111111111111
    x[30,3]   product_ux_30_3  -39.6
    x[30,3]   product_Su_30_3  -39.6
    x[30,3]   product_Sl_30_3  -8.61111111111111
    x[30,3]   conditional_Sx_lower_30_3  -8.98611111111111
    x[30,3]   conditional_Sx_upper_30_3  -39.35
    x[30,3]   conditional_complement_lower_30_3  8.61111111111111
    x[30,3]   conditional_complement_upper_30_3  39.6
    x[30,3]   hard_cost_D_definition  1.1636578603958278e-04
    x[30,4]   onehot_30  1
    x[30,4]   inventory_30  -4
    x[30,4]   product_lx_30_4  -8.61111111111111
    x[30,4]   product_ux_30_4  -39.6
    x[30,4]   product_Su_30_4  -39.6
    x[30,4]   product_Sl_30_4  -8.61111111111111
    x[30,4]   conditional_Sx_lower_30_4  -9.11111111111111
    x[30,4]   conditional_Sx_upper_30_4  -3.9400000000000006e+01
    x[30,4]   conditional_complement_lower_30_4  8.61111111111111
    x[30,4]   conditional_complement_upper_30_4  39.6
    x[30,4]   hard_cost_D_definition  2.3273157207916555e-04
    x[30,5]   onehot_30  1
    x[30,5]   inventory_30  -5
    x[30,5]   product_lx_30_5  -8.61111111111111
    x[30,5]   product_ux_30_5  -39.6
    x[30,5]   product_Su_30_5  -39.6
    x[30,5]   product_Sl_30_5  -8.61111111111111
    x[30,5]   conditional_Sx_lower_30_5  -9.23611111111111
    x[30,5]   conditional_Sx_upper_30_5  -39.45
    x[30,5]   conditional_complement_lower_30_5  8.61111111111111
    x[30,5]   conditional_complement_upper_30_5  39.6
    x[30,5]   hard_cost_D_definition  1.1636578603958278e-04
    x[30,6]   onehot_30  1
    x[30,6]   inventory_30  -6
    x[30,6]   product_lx_30_6  -8.61111111111111
    x[30,6]   product_ux_30_6  -39.6
    x[30,6]   product_Su_30_6  -39.6
    x[30,6]   product_Sl_30_6  -8.61111111111111
    x[30,6]   conditional_Sx_lower_30_6  -9.36111111111111
    x[30,6]   conditional_Sx_upper_30_6  -3.9500000000000007e+01
    x[30,6]   conditional_complement_lower_30_6  8.61111111111111
    x[30,6]   conditional_complement_upper_30_6  39.6
    x[30,7]   onehot_30  1
    x[30,7]   inventory_30  -7
    x[30,7]   product_lx_30_7  -8.61111111111111
    x[30,7]   product_ux_30_7  -39.6
    x[30,7]   product_Su_30_7  -39.6
    x[30,7]   product_Sl_30_7  -8.61111111111111
    x[30,7]   conditional_Sx_lower_30_7  -9.48611111111111
    x[30,7]   conditional_Sx_upper_30_7  -3.9550000000000004e+01
    x[30,7]   conditional_complement_lower_30_7  8.61111111111111
    x[30,7]   conditional_complement_upper_30_7  39.6
    x[30,7]   hard_cost_D_definition  -1.1636578603958278e-04
    x[30,8]   onehot_30  1
    x[30,8]   inventory_30  -8
    x[30,8]   product_lx_30_8  -8.61111111111111
    x[30,8]   product_ux_30_8  -39.6
    x[30,8]   product_Su_30_8  -39.6
    x[30,8]   product_Sl_30_8  -8.61111111111111
    x[30,8]   conditional_Sx_lower_30_8  -9.61111111111111
    x[30,8]   conditional_Sx_upper_30_8  -39.6
    x[30,8]   conditional_complement_lower_30_8  8.61111111111111
    x[30,8]   conditional_complement_upper_30_8  3.9550000000000004e+01
    x[30,8]   hard_cost_D_definition  -2.3273157207916555e-04
    x[31,0]   onehot_31  1
    x[31,0]   product_lx_31_0  -8.61111111111111
    x[31,0]   product_ux_31_0  -39.6
    x[31,0]   product_Su_31_0  -39.6
    x[31,0]   product_Sl_31_0  -8.61111111111111
    x[31,0]   conditional_Sx_lower_31_0  -8.61111111111111
    x[31,0]   conditional_Sx_upper_31_0  -39.6
    x[31,0]   conditional_complement_lower_31_0  8.6527777777777768e+00
    x[31,0]   conditional_complement_upper_31_0  3.9566666666666670e+01
    x[31,0]   hard_cost_D_definition  -5.2364515352604213e-04
    x[31,1]   onehot_31  1
    x[31,1]   inventory_31  -1
    x[31,1]   product_lx_31_1  -8.61111111111111
    x[31,1]   product_ux_31_1  -39.6
    x[31,1]   product_Su_31_1  -39.6
    x[31,1]   product_Sl_31_1  -8.61111111111111
    x[31,1]   conditional_Sx_lower_31_1  -8.6527777777777768e+00
    x[31,1]   conditional_Sx_upper_31_1  -3.9566666666666670e+01
    x[31,1]   conditional_complement_lower_31_1  8.61111111111111
    x[31,1]   conditional_complement_upper_31_1  39.6
    x[31,1]   hard_cost_D_definition  -3.4909676901736142e-04
    x[31,2]   onehot_31  1
    x[31,2]   inventory_31  -2
    x[31,2]   product_lx_31_2  -8.61111111111111
    x[31,2]   product_ux_31_2  -39.6
    x[31,2]   product_Su_31_2  -39.6
    x[31,2]   product_Sl_31_2  -8.61111111111111
    x[31,2]   conditional_Sx_lower_31_2  -8.6944444444444429e+00
    x[31,2]   conditional_Sx_upper_31_2  -3.9533333333333339e+01
    x[31,2]   conditional_complement_lower_31_2  8.61111111111111
    x[31,2]   conditional_complement_upper_31_2  39.6
    x[31,2]   hard_cost_D_definition  -1.7454838450868071e-04
    x[31,3]   onehot_31  1
    x[31,3]   inventory_31  -3
    x[31,3]   product_lx_31_3  -8.61111111111111
    x[31,3]   product_ux_31_3  -39.6
    x[31,3]   product_Su_31_3  -39.6
    x[31,3]   product_Sl_31_3  -8.61111111111111
    x[31,3]   conditional_Sx_lower_31_3  -8.73611111111111
    x[31,3]   conditional_Sx_upper_31_3  -39.5
    x[31,3]   conditional_complement_lower_31_3  8.61111111111111
    x[31,3]   conditional_complement_upper_31_3  39.6
    x[31,4]   onehot_31  1
    x[31,4]   inventory_31  -4
    x[31,4]   product_lx_31_4  -8.61111111111111
    x[31,4]   product_ux_31_4  -39.6
    x[31,4]   product_Su_31_4  -39.6
    x[31,4]   product_Sl_31_4  -8.61111111111111
    x[31,4]   conditional_Sx_lower_31_4  -8.7777777777777768e+00
    x[31,4]   conditional_Sx_upper_31_4  -3.9466666666666669e+01
    x[31,4]   conditional_complement_lower_31_4  8.61111111111111
    x[31,4]   conditional_complement_upper_31_4  39.6
    x[31,4]   hard_cost_D_definition  1.7454838450868074e-04
    x[31,5]   onehot_31  1
    x[31,5]   inventory_31  -5
    x[31,5]   product_lx_31_5  -8.61111111111111
    x[31,5]   product_ux_31_5  -39.6
    x[31,5]   product_Su_31_5  -39.6
    x[31,5]   product_Sl_31_5  -8.61111111111111
    x[31,5]   conditional_Sx_lower_31_5  -8.8194444444444429e+00
    x[31,5]   conditional_Sx_upper_31_5  -3.9433333333333337e+01
    x[31,5]   conditional_complement_lower_31_5  8.61111111111111
    x[31,5]   conditional_complement_upper_31_5  39.6
    x[31,5]   hard_cost_D_definition  3.4909676901736148e-04
    x[31,6]   onehot_31  1
    x[31,6]   inventory_31  -6
    x[31,6]   product_lx_31_6  -8.61111111111111
    x[31,6]   product_ux_31_6  -39.6
    x[31,6]   product_Su_31_6  -39.6
    x[31,6]   product_Sl_31_6  -8.61111111111111
    x[31,6]   conditional_Sx_lower_31_6  -8.86111111111111
    x[31,6]   conditional_Sx_upper_31_6  -3.9400000000000006e+01
    x[31,6]   conditional_complement_lower_31_6  8.61111111111111
    x[31,6]   conditional_complement_upper_31_6  39.6
    x[31,6]   hard_cost_D_definition  5.2364515352604224e-04
    x[31,7]   onehot_31  1
    x[31,7]   inventory_31  -7
    x[31,7]   product_lx_31_7  -8.61111111111111
    x[31,7]   product_ux_31_7  -39.6
    x[31,7]   product_Su_31_7  -39.6
    x[31,7]   product_Sl_31_7  -8.61111111111111
    x[31,7]   conditional_Sx_lower_31_7  -8.9027777777777768e+00
    x[31,7]   conditional_Sx_upper_31_7  -3.9366666666666667e+01
    x[31,7]   conditional_complement_lower_31_7  8.61111111111111
    x[31,7]   conditional_complement_upper_31_7  39.6
    x[31,7]   hard_cost_D_definition  3.4909676901736164e-04
    x[31,8]   onehot_31  1
    x[31,8]   inventory_31  -8
    x[31,8]   product_lx_31_8  -8.61111111111111
    x[31,8]   product_ux_31_8  -39.6
    x[31,8]   product_Su_31_8  -39.6
    x[31,8]   product_Sl_31_8  -8.61111111111111
    x[31,8]   conditional_Sx_lower_31_8  -8.9444444444444429e+00
    x[31,8]   conditional_Sx_upper_31_8  -3.9333333333333336e+01
    x[31,8]   conditional_complement_lower_31_8  8.61111111111111
    x[31,8]   conditional_complement_upper_31_8  39.6
    x[31,8]   hard_cost_D_definition  1.7454838450868087e-04
    x[31,9]   onehot_31  1
    x[31,9]   inventory_31  -9
    x[31,9]   product_lx_31_9  -8.61111111111111
    x[31,9]   product_ux_31_9  -39.6
    x[31,9]   product_Su_31_9  -39.6
    x[31,9]   product_Sl_31_9  -8.61111111111111
    x[31,9]   conditional_Sx_lower_31_9  -8.98611111111111
    x[31,9]   conditional_Sx_upper_31_9  -3.9300000000000004e+01
    x[31,9]   conditional_complement_lower_31_9  8.61111111111111
    x[31,9]   conditional_complement_upper_31_9  39.6
    x[31,10]  onehot_31  1
    x[31,10]  inventory_31  -10
    x[31,10]  product_lx_31_10  -8.61111111111111
    x[31,10]  product_ux_31_10  -39.6
    x[31,10]  product_Su_31_10  -39.6
    x[31,10]  product_Sl_31_10  -8.61111111111111
    x[31,10]  conditional_Sx_lower_31_10  -9.0277777777777768e+00
    x[31,10]  conditional_Sx_upper_31_10  -3.9266666666666673e+01
    x[31,10]  conditional_complement_lower_31_10  8.61111111111111
    x[31,10]  conditional_complement_upper_31_10  39.6
    x[31,10]  hard_cost_D_definition  -1.7454838450868060e-04
    x[31,11]  onehot_31  1
    x[31,11]  inventory_31  -11
    x[31,11]  product_lx_31_11  -8.61111111111111
    x[31,11]  product_ux_31_11  -39.6
    x[31,11]  product_Su_31_11  -39.6
    x[31,11]  product_Sl_31_11  -8.61111111111111
    x[31,11]  conditional_Sx_lower_31_11  -9.0694444444444429e+00
    x[31,11]  conditional_Sx_upper_31_11  -3.9233333333333334e+01
    x[31,11]  conditional_complement_lower_31_11  8.61111111111111
    x[31,11]  conditional_complement_upper_31_11  39.6
    x[31,11]  hard_cost_D_definition  -3.4909676901736131e-04
    x[32,0]   onehot_32  1
    x[32,0]   product_lx_32_0  -8.61111111111111
    x[32,0]   product_ux_32_0  -39.6
    x[32,0]   product_Su_32_0  -39.6
    x[32,0]   product_Sl_32_0  -8.61111111111111
    x[32,0]   conditional_Sx_lower_32_0  -9.0714285714285712e+00
    x[32,0]   conditional_Sx_upper_32_0  -39.6
    x[32,0]   conditional_complement_lower_32_0  8.61111111111111
    x[32,0]   conditional_complement_upper_32_0  3.9511111111111113e+01
    x[32,0]   hard_cost_D_definition  -1.0472913543434388e-03
    x[32,1]   onehot_32  1
    x[32,1]   inventory_32  -1
    x[32,1]   product_lx_32_1  -8.61111111111111
    x[32,1]   product_ux_32_1  -39.6
    x[32,1]   product_Su_32_1  -39.6
    x[32,1]   product_Sl_32_1  -8.61111111111111
    x[32,1]   conditional_Sx_lower_32_1  -9.03968253968254
    x[32,1]   conditional_Sx_upper_32_1  -3.9511111111111113e+01
    x[32,1]   conditional_complement_lower_32_1  8.61111111111111
    x[32,1]   conditional_complement_upper_32_1  39.6
    x[32,1]   hard_cost_D_definition  -7.8546851575757911e-04
    x[32,2]   onehot_32  1
    x[32,2]   inventory_32  -2
    x[32,2]   product_lx_32_2  -8.61111111111111
    x[32,2]   product_ux_32_2  -39.6
    x[32,2]   product_Su_32_2  -39.6
    x[32,2]   product_Sl_32_2  -8.61111111111111
    x[32,2]   conditional_Sx_lower_32_2  -9.0079365079365061e+00
    x[32,2]   conditional_Sx_upper_32_2  -3.9422222222222224e+01
    x[32,2]   conditional_complement_lower_32_2  8.61111111111111
    x[32,2]   conditional_complement_upper_32_2  39.6
    x[32,2]   hard_cost_D_definition  -5.2364567717171941e-04
    x[32,3]   onehot_32  1
    x[32,3]   inventory_32  -3
    x[32,3]   product_lx_32_3  -8.61111111111111
    x[32,3]   product_ux_32_3  -39.6
    x[32,3]   product_Su_32_3  -39.6
    x[32,3]   product_Sl_32_3  -8.61111111111111
    x[32,3]   conditional_Sx_lower_32_3  -8.9761904761904745e+00
    x[32,3]   conditional_Sx_upper_32_3  -3.9333333333333336e+01
    x[32,3]   conditional_complement_lower_32_3  8.61111111111111
    x[32,3]   conditional_complement_upper_32_3  39.6
    x[32,3]   hard_cost_D_definition  -2.6182283858585981e-04
    x[32,4]   onehot_32  1
    x[32,4]   inventory_32  -4
    x[32,4]   product_lx_32_4  -8.61111111111111
    x[32,4]   product_ux_32_4  -39.6
    x[32,4]   product_Su_32_4  -39.6
    x[32,4]   product_Sl_32_4  -8.61111111111111
    x[32,4]   conditional_Sx_lower_32_4  -8.9444444444444429e+00
    x[32,4]   conditional_Sx_upper_32_4  -3.9244444444444447e+01
    x[32,4]   conditional_complement_lower_32_4  8.61111111111111
    x[32,4]   conditional_complement_upper_32_4  39.6
    x[32,5]   onehot_32  1
    x[32,5]   inventory_32  -5
    x[32,5]   product_lx_32_5  -8.61111111111111
    x[32,5]   product_ux_32_5  -39.6
    x[32,5]   product_Su_32_5  -39.6
    x[32,5]   product_Sl_32_5  -8.61111111111111
    x[32,5]   conditional_Sx_lower_32_5  -8.9126984126984112e+00
    x[32,5]   conditional_Sx_upper_32_5  -3.9155555555555559e+01
    x[32,5]   conditional_complement_lower_32_5  8.61111111111111
    x[32,5]   conditional_complement_upper_32_5  39.6
    x[32,5]   hard_cost_D_definition  2.6182283858585959e-04
    x[32,6]   onehot_32  1
    x[32,6]   inventory_32  -6
    x[32,6]   product_lx_32_6  -8.61111111111111
    x[32,6]   product_ux_32_6  -39.6
    x[32,6]   product_Su_32_6  -39.6
    x[32,6]   product_Sl_32_6  -8.61111111111111
    x[32,6]   conditional_Sx_lower_32_6  -8.88095238095238
    x[32,6]   conditional_Sx_upper_32_6  -3.9066666666666670e+01
    x[32,6]   conditional_complement_lower_32_6  8.61111111111111
    x[32,6]   conditional_complement_upper_32_6  39.6
    x[32,6]   hard_cost_D_definition  5.2364567717171930e-04
    x[32,7]   onehot_32  1
    x[32,7]   inventory_32  -7
    x[32,7]   product_lx_32_7  -8.61111111111111
    x[32,7]   product_ux_32_7  -39.6
    x[32,7]   product_Su_32_7  -39.6
    x[32,7]   product_Sl_32_7  -8.61111111111111
    x[32,7]   conditional_Sx_lower_32_7  -8.8492063492063480e+00
    x[32,7]   conditional_Sx_upper_32_7  -3.8977777777777781e+01
    x[32,7]   conditional_complement_lower_32_7  8.61111111111111
    x[32,7]   conditional_complement_upper_32_7  39.6
    x[32,7]   hard_cost_D_definition  0.000785468515757579
    x[32,8]   onehot_32  1
    x[32,8]   inventory_32  -8
    x[32,8]   product_lx_32_8  -8.61111111111111
    x[32,8]   product_ux_32_8  -39.6
    x[32,8]   product_Su_32_8  -39.6
    x[32,8]   product_Sl_32_8  -8.61111111111111
    x[32,8]   conditional_Sx_lower_32_8  -8.8174603174603163e+00
    x[32,8]   conditional_Sx_upper_32_8  -3.8888888888888893e+01
    x[32,8]   conditional_complement_lower_32_8  8.61111111111111
    x[32,8]   conditional_complement_upper_32_8  39.6
    x[32,8]   hard_cost_D_definition  1.0472913543434388e-03
    x[32,9]   onehot_32  1
    x[32,9]   inventory_32  -9
    x[32,9]   product_lx_32_9  -8.61111111111111
    x[32,9]   product_ux_32_9  -39.6
    x[32,9]   product_Su_32_9  -39.6
    x[32,9]   product_Sl_32_9  -8.61111111111111
    x[32,9]   conditional_Sx_lower_32_9  -8.7857142857142847e+00
    x[32,9]   conditional_Sx_upper_32_9  -3.8800000000000004e+01
    x[32,9]   conditional_complement_lower_32_9  8.61111111111111
    x[32,9]   conditional_complement_upper_32_9  39.6
    x[32,9]   hard_cost_D_definition  1.3091141929292985e-03
    x[32,10]  onehot_32  1
    x[32,10]  inventory_32  -10
    x[32,10]  product_lx_32_10  -8.61111111111111
    x[32,10]  product_ux_32_10  -39.6
    x[32,10]  product_Su_32_10  -39.6
    x[32,10]  product_Sl_32_10  -8.61111111111111
    x[32,10]  conditional_Sx_lower_32_10  -8.7539682539682531e+00
    x[32,10]  conditional_Sx_upper_32_10  -3.8711111111111116e+01
    x[32,10]  conditional_complement_lower_32_10  8.61111111111111
    x[32,10]  conditional_complement_upper_32_10  39.6
    x[32,10]  hard_cost_D_definition  1.0472913543434390e-03
    x[32,11]  onehot_32  1
    x[32,11]  inventory_32  -11
    x[32,11]  product_lx_32_11  -8.61111111111111
    x[32,11]  product_ux_32_11  -39.6
    x[32,11]  product_Su_32_11  -39.6
    x[32,11]  product_Sl_32_11  -8.61111111111111
    x[32,11]  conditional_Sx_lower_32_11  -8.7222222222222214e+00
    x[32,11]  conditional_Sx_upper_32_11  -3.8622222222222227e+01
    x[32,11]  conditional_complement_lower_32_11  8.61111111111111
    x[32,11]  conditional_complement_upper_32_11  39.6
    x[32,11]  hard_cost_D_definition  7.8546851575757922e-04
    x[32,12]  onehot_32  1
    x[32,12]  inventory_32  -12
    x[32,12]  product_lx_32_12  -8.61111111111111
    x[32,12]  product_ux_32_12  -39.6
    x[32,12]  product_Su_32_12  -39.6
    x[32,12]  product_Sl_32_12  -8.61111111111111
    x[32,12]  conditional_Sx_lower_32_12  -8.7083333333333321e+00
    x[32,12]  conditional_Sx_upper_32_12  -3.8533333333333339e+01
    x[32,12]  conditional_complement_lower_32_12  8.61111111111111
    x[32,12]  conditional_complement_upper_32_12  39.6
    x[32,12]  hard_cost_D_definition  5.2364567717171951e-04
    x[32,13]  onehot_32  1
    x[32,13]  inventory_32  -13
    x[32,13]  product_lx_32_13  -8.61111111111111
    x[32,13]  product_ux_32_13  -39.6
    x[32,13]  product_Su_32_13  -39.6
    x[32,13]  product_Sl_32_13  -8.61111111111111
    x[32,13]  conditional_Sx_lower_32_13  -8.6944444444444429e+00
    x[32,13]  conditional_Sx_upper_32_13  -3.8444444444444450e+01
    x[32,13]  conditional_complement_lower_32_13  8.61111111111111
    x[32,13]  conditional_complement_upper_32_13  39.6
    x[32,13]  hard_cost_D_definition  2.6182283858585987e-04
    x[32,14]  onehot_32  1
    x[32,14]  inventory_32  -14
    x[32,14]  product_lx_32_14  -8.61111111111111
    x[32,14]  product_ux_32_14  -39.6
    x[32,14]  product_Su_32_14  -39.6
    x[32,14]  product_Sl_32_14  -8.61111111111111
    x[32,14]  conditional_Sx_lower_32_14  -8.6805555555555554e+00
    x[32,14]  conditional_Sx_upper_32_14  -3.8355555555555561e+01
    x[32,14]  conditional_complement_lower_32_14  8.61111111111111
    x[32,14]  conditional_complement_upper_32_14  39.6
    x[32,15]  onehot_32  1
    x[32,15]  inventory_32  -15
    x[32,15]  product_lx_32_15  -8.61111111111111
    x[32,15]  product_ux_32_15  -39.6
    x[32,15]  product_Su_32_15  -39.6
    x[32,15]  product_Sl_32_15  -8.61111111111111
    x[32,15]  conditional_Sx_lower_32_15  -8.6666666666666661e+00
    x[32,15]  conditional_Sx_upper_32_15  -3.8266666666666673e+01
    x[32,15]  conditional_complement_lower_32_15  8.61111111111111
    x[32,15]  conditional_complement_upper_32_15  39.6
    x[32,15]  hard_cost_D_definition  -2.6182283858585954e-04
    x[32,16]  onehot_32  1
    x[32,16]  inventory_32  -16
    x[32,16]  product_lx_32_16  -8.61111111111111
    x[32,16]  product_ux_32_16  -39.6
    x[32,16]  product_Su_32_16  -39.6
    x[32,16]  product_Sl_32_16  -8.61111111111111
    x[32,16]  conditional_Sx_lower_32_16  -8.6527777777777768e+00
    x[32,16]  conditional_Sx_upper_32_16  -3.8177777777777784e+01
    x[32,16]  conditional_complement_lower_32_16  8.61111111111111
    x[32,16]  conditional_complement_upper_32_16  39.6
    x[32,16]  hard_cost_D_definition  -5.2364567717171919e-04
    x[32,17]  onehot_32  1
    x[32,17]  inventory_32  -17
    x[32,17]  product_lx_32_17  -8.61111111111111
    x[32,17]  product_ux_32_17  -39.6
    x[32,17]  product_Su_32_17  -39.6
    x[32,17]  product_Sl_32_17  -8.61111111111111
    x[32,17]  conditional_Sx_lower_32_17  -8.6388888888888875e+00
    x[32,17]  conditional_Sx_upper_32_17  -3.8088888888888896e+01
    x[32,17]  conditional_complement_lower_32_17  8.61111111111111
    x[32,17]  conditional_complement_upper_32_17  39.6
    x[32,17]  hard_cost_D_definition  -7.8546851575757889e-04
    x[32,18]  onehot_32  1
    x[32,18]  inventory_32  -18
    x[32,18]  product_lx_32_18  -8.61111111111111
    x[32,18]  product_ux_32_18  -39.6
    x[32,18]  product_Su_32_18  -39.6
    x[32,18]  product_Sl_32_18  -8.61111111111111
    x[32,18]  conditional_Sx_lower_32_18  -8.6249999999999982e+00
    x[32,18]  conditional_Sx_upper_32_18  -38
    x[32,18]  conditional_complement_lower_32_18  8.61111111111111
    x[32,18]  conditional_complement_upper_32_18  39.6
    x[32,18]  hard_cost_D_definition  -1.0472913543434386e-03
    x[32,19]  onehot_32  1
    x[32,19]  inventory_32  -19
    x[32,19]  product_lx_32_19  -8.61111111111111
    x[32,19]  product_ux_32_19  -39.6
    x[32,19]  product_Su_32_19  -39.6
    x[32,19]  product_Sl_32_19  -8.61111111111111
    x[32,19]  conditional_Sx_lower_32_19  -8.61111111111111
    x[32,19]  conditional_Sx_upper_32_19  -3.7911111111111111e+01
    x[32,19]  conditional_complement_lower_32_19  8.6249999999999982e+00
    x[32,19]  conditional_complement_upper_32_19  39.6
    x[32,19]  hard_cost_D_definition  -1.3091141929292983e-03
    x[33,0]   onehot_33  1
    x[33,0]   product_lx_33_0  -8.61111111111111
    x[33,0]   product_ux_33_0  -39.6
    x[33,0]   product_Su_33_0  -39.6
    x[33,0]   product_Sl_33_0  -8.61111111111111
    x[33,0]   conditional_Sx_lower_33_0  -8.61111111111111
    x[33,0]   conditional_Sx_upper_33_0  -39.6
    x[33,0]   conditional_complement_lower_33_0  8.68611111111111
    x[33,0]   conditional_complement_upper_33_0  39.6
    x[33,0]   hard_cost_D_definition  -2.9091428836854082e-04
    x[33,1]   onehot_33  1
    x[33,1]   inventory_33  -1
    x[33,1]   product_lx_33_1  -8.61111111111111
    x[33,1]   product_ux_33_1  -39.6
    x[33,1]   product_Su_33_1  -39.6
    x[33,1]   product_Sl_33_1  -8.61111111111111
    x[33,1]   conditional_Sx_lower_33_1  -8.68611111111111
    x[33,1]   conditional_Sx_upper_33_1  -39.6
    x[33,1]   conditional_complement_lower_33_1  8.61111111111111
    x[33,1]   conditional_complement_upper_33_1  39.6
    x[33,1]   hard_cost_D_definition  -1.4545714418427036e-04
    x[33,2]   onehot_33  1
    x[33,2]   inventory_33  -2
    x[33,2]   product_lx_33_2  -8.61111111111111
    x[33,2]   product_ux_33_2  -39.6
    x[33,2]   product_Su_33_2  -39.6
    x[33,2]   product_Sl_33_2  -8.61111111111111
    x[33,2]   conditional_Sx_lower_33_2  -8.76111111111111
    x[33,2]   conditional_Sx_upper_33_2  -39.6
    x[33,2]   conditional_complement_lower_33_2  8.61111111111111
    x[33,2]   conditional_complement_upper_33_2  39.6
    x[33,3]   onehot_33  1
    x[33,3]   inventory_33  -3
    x[33,3]   product_lx_33_3  -8.61111111111111
    x[33,3]   product_ux_33_3  -39.6
    x[33,3]   product_Su_33_3  -39.6
    x[33,3]   product_Sl_33_3  -8.61111111111111
    x[33,3]   conditional_Sx_lower_33_3  -8.83611111111111
    x[33,3]   conditional_Sx_upper_33_3  -39.6
    x[33,3]   conditional_complement_lower_33_3  8.61111111111111
    x[33,3]   conditional_complement_upper_33_3  39.6
    x[33,3]   hard_cost_D_definition  1.4545714418427055e-04
    x[33,4]   onehot_33  1
    x[33,4]   inventory_33  -4
    x[33,4]   product_lx_33_4  -8.61111111111111
    x[33,4]   product_ux_33_4  -39.6
    x[33,4]   product_Su_33_4  -39.6
    x[33,4]   product_Sl_33_4  -8.61111111111111
    x[33,4]   conditional_Sx_lower_33_4  -8.91111111111111
    x[33,4]   conditional_Sx_upper_33_4  -39.6
    x[33,4]   conditional_complement_lower_33_4  8.61111111111111
    x[33,4]   conditional_complement_upper_33_4  39.6
    x[33,4]   hard_cost_D_definition  2.9091428836854104e-04
    x[33,5]   onehot_33  1
    x[33,5]   inventory_33  -5
    x[33,5]   product_lx_33_5  -8.61111111111111
    x[33,5]   product_ux_33_5  -39.6
    x[33,5]   product_Su_33_5  -39.6
    x[33,5]   product_Sl_33_5  -8.61111111111111
    x[33,5]   conditional_Sx_lower_33_5  -8.98611111111111
    x[33,5]   conditional_Sx_upper_33_5  -39.6
    x[33,5]   conditional_complement_lower_33_5  8.61111111111111
    x[33,5]   conditional_complement_upper_33_5  39.6
    x[33,5]   hard_cost_D_definition  4.3637143255281140e-04
    x[33,6]   onehot_33  1
    x[33,6]   inventory_33  -6
    x[33,6]   product_lx_33_6  -8.61111111111111
    x[33,6]   product_ux_33_6  -39.6
    x[33,6]   product_Su_33_6  -39.6
    x[33,6]   product_Sl_33_6  -8.61111111111111
    x[33,6]   conditional_Sx_lower_33_6  -9.06111111111111
    x[33,6]   conditional_Sx_upper_33_6  -39.6
    x[33,6]   conditional_complement_lower_33_6  8.61111111111111
    x[33,6]   conditional_complement_upper_33_6  39.6
    x[33,6]   hard_cost_D_definition  2.9091428836854093e-04
    x[33,7]   onehot_33  1
    x[33,7]   inventory_33  -7
    x[33,7]   product_lx_33_7  -8.61111111111111
    x[33,7]   product_ux_33_7  -39.6
    x[33,7]   product_Su_33_7  -39.6
    x[33,7]   product_Sl_33_7  -8.61111111111111
    x[33,7]   conditional_Sx_lower_33_7  -9.1361111111111111e+00
    x[33,7]   conditional_Sx_upper_33_7  -39.6
    x[33,7]   conditional_complement_lower_33_7  8.61111111111111
    x[33,7]   conditional_complement_upper_33_7  39.6
    x[33,7]   hard_cost_D_definition  1.4545714418427047e-04
    x[33,8]   onehot_33  1
    x[33,8]   inventory_33  -8
    x[33,8]   product_lx_33_8  -8.61111111111111
    x[33,8]   product_ux_33_8  -39.6
    x[33,8]   product_Su_33_8  -39.6
    x[33,8]   product_Sl_33_8  -8.61111111111111
    x[33,8]   conditional_Sx_lower_33_8  -9.21111111111111
    x[33,8]   conditional_Sx_upper_33_8  -39.6
    x[33,8]   conditional_complement_lower_33_8  8.61111111111111
    x[33,8]   conditional_complement_upper_33_8  39.6
    x[33,9]   onehot_33  1
    x[33,9]   inventory_33  -9
    x[33,9]   product_lx_33_9  -8.61111111111111
    x[33,9]   product_ux_33_9  -39.6
    x[33,9]   product_Su_33_9  -39.6
    x[33,9]   product_Sl_33_9  -8.61111111111111
    x[33,9]   conditional_Sx_lower_33_9  -9.28611111111111
    x[33,9]   conditional_Sx_upper_33_9  -39.6
    x[33,9]   conditional_complement_lower_33_9  8.61111111111111
    x[33,9]   conditional_complement_upper_33_9  39.6
    x[33,9]   hard_cost_D_definition  -1.4545714418427044e-04
    x[33,10]  onehot_33  1
    x[33,10]  inventory_33  -10
    x[33,10]  product_lx_33_10  -8.61111111111111
    x[33,10]  product_ux_33_10  -39.6
    x[33,10]  product_Su_33_10  -39.6
    x[33,10]  product_Sl_33_10  -8.61111111111111
    x[33,10]  conditional_Sx_lower_33_10  -9.36111111111111
    x[33,10]  conditional_Sx_upper_33_10  -39.6
    x[33,10]  conditional_complement_lower_33_10  8.61111111111111
    x[33,10]  conditional_complement_upper_33_10  39.6
    x[33,10]  hard_cost_D_definition  -2.9091428836854088e-04
    x[33,11]  onehot_33  1
    x[33,11]  inventory_33  -11
    x[33,11]  product_lx_33_11  -8.61111111111111
    x[33,11]  product_ux_33_11  -39.6
    x[33,11]  product_Su_33_11  -39.6
    x[33,11]  product_Sl_33_11  -8.61111111111111
    x[33,11]  conditional_Sx_lower_33_11  -9.43611111111111
    x[33,11]  conditional_Sx_upper_33_11  -39.6
    x[33,11]  conditional_complement_lower_33_11  8.61111111111111
    x[33,11]  conditional_complement_upper_33_11  39.6
    x[33,11]  hard_cost_D_definition  -4.3637143255281135e-04
    x[34,0]   onehot_34  1
    x[34,0]   product_lx_34_0  -8.61111111111111
    x[34,0]   product_ux_34_0  -39.6
    x[34,0]   product_Su_34_0  -39.6
    x[34,0]   product_Sl_34_0  -8.61111111111111
    x[34,0]   conditional_Sx_lower_34_0  -8.73611111111111
    x[34,0]   conditional_Sx_upper_34_0  -39.6
    x[34,0]   conditional_complement_lower_34_0  8.61111111111111
    x[34,0]   conditional_complement_upper_34_0  3.9525000000000006e+01
    x[34,0]   hard_cost_D_definition  -9.3092511011388858e-04
    x[34,1]   onehot_34  1
    x[34,1]   inventory_34  -1
    x[34,1]   product_lx_34_1  -8.61111111111111
    x[34,1]   product_ux_34_1  -39.6
    x[34,1]   product_Su_34_1  -39.6
    x[34,1]   product_Sl_34_1  -8.61111111111111
    x[34,1]   conditional_Sx_lower_34_1  -8.7182539682539666e+00
    x[34,1]   conditional_Sx_upper_34_1  -3.9525000000000006e+01
    x[34,1]   conditional_complement_lower_34_1  8.61111111111111
    x[34,1]   conditional_complement_upper_34_1  39.6
    x[34,1]   hard_cost_D_definition  -6.9819383258541636e-04
    x[34,2]   onehot_34  1
    x[34,2]   inventory_34  -2
    x[34,2]   product_lx_34_2  -8.61111111111111
    x[34,2]   product_ux_34_2  -39.6
    x[34,2]   product_Su_34_2  -39.6
    x[34,2]   product_Sl_34_2  -8.61111111111111
    x[34,2]   conditional_Sx_lower_34_2  -8.7003968253968242e+00
    x[34,2]   conditional_Sx_upper_34_2  -39.45
    x[34,2]   conditional_complement_lower_34_2  8.61111111111111
    x[34,2]   conditional_complement_upper_34_2  39.6
    x[34,2]   hard_cost_D_definition  -4.6546255505694429e-04
    x[34,3]   onehot_34  1
    x[34,3]   inventory_34  -3
    x[34,3]   product_lx_34_3  -8.61111111111111
    x[34,3]   product_ux_34_3  -39.6
    x[34,3]   product_Su_34_3  -39.6
    x[34,3]   product_Sl_34_3  -8.61111111111111
    x[34,3]   conditional_Sx_lower_34_3  -8.6825396825396819e+00
    x[34,3]   conditional_Sx_upper_34_3  -39.375
    x[34,3]   conditional_complement_lower_34_3  8.61111111111111
    x[34,3]   conditional_complement_upper_34_3  39.6
    x[34,3]   hard_cost_D_definition  -2.3273127752847215e-04
    x[34,4]   onehot_34  1
    x[34,4]   inventory_34  -4
    x[34,4]   product_lx_34_4  -8.61111111111111
    x[34,4]   product_ux_34_4  -39.6
    x[34,4]   product_Su_34_4  -39.6
    x[34,4]   product_Sl_34_4  -8.61111111111111
    x[34,4]   conditional_Sx_lower_34_4  -8.66468253968254
    x[34,4]   conditional_Sx_upper_34_4  -3.9300000000000004e+01
    x[34,4]   conditional_complement_lower_34_4  8.61111111111111
    x[34,4]   conditional_complement_upper_34_4  39.6
    x[34,5]   onehot_34  1
    x[34,5]   inventory_34  -5
    x[34,5]   product_lx_34_5  -8.61111111111111
    x[34,5]   product_ux_34_5  -39.6
    x[34,5]   product_Su_34_5  -39.6
    x[34,5]   product_Sl_34_5  -8.61111111111111
    x[34,5]   conditional_Sx_lower_34_5  -8.6468253968253954e+00
    x[34,5]   conditional_Sx_upper_34_5  -39.225
    x[34,5]   conditional_complement_lower_34_5  8.61111111111111
    x[34,5]   conditional_complement_upper_34_5  39.6
    x[34,5]   hard_cost_D_definition  2.3273127752847215e-04
    x[34,6]   onehot_34  1
    x[34,6]   inventory_34  -6
    x[34,6]   product_lx_34_6  -8.61111111111111
    x[34,6]   product_ux_34_6  -39.6
    x[34,6]   product_Su_34_6  -39.6
    x[34,6]   product_Sl_34_6  -8.61111111111111
    x[34,6]   conditional_Sx_lower_34_6  -8.6289682539682531e+00
    x[34,6]   conditional_Sx_upper_34_6  -3.9150000000000006e+01
    x[34,6]   conditional_complement_lower_34_6  8.61111111111111
    x[34,6]   conditional_complement_upper_34_6  39.6
    x[34,6]   hard_cost_D_definition  4.6546255505694429e-04
    x[34,7]   onehot_34  1
    x[34,7]   inventory_34  -7
    x[34,7]   product_lx_34_7  -8.61111111111111
    x[34,7]   product_ux_34_7  -39.6
    x[34,7]   product_Su_34_7  -39.6
    x[34,7]   product_Sl_34_7  -8.61111111111111
    x[34,7]   conditional_Sx_lower_34_7  -8.61111111111111
    x[34,7]   conditional_Sx_upper_34_7  -39.075
    x[34,7]   conditional_complement_lower_34_7  8.61111111111111
    x[34,7]   conditional_complement_upper_34_7  39.6
    x[34,7]   hard_cost_D_definition  6.9819383258541646e-04
    x[34,8]   onehot_34  1
    x[34,8]   inventory_34  -8
    x[34,8]   product_lx_34_8  -8.61111111111111
    x[34,8]   product_ux_34_8  -39.6
    x[34,8]   product_Su_34_8  -39.6
    x[34,8]   product_Sl_34_8  -8.61111111111111
    x[34,8]   conditional_Sx_lower_34_8  -8.61111111111111
    x[34,8]   conditional_Sx_upper_34_8  -39
    x[34,8]   conditional_complement_lower_34_8  8.61111111111111
    x[34,8]   conditional_complement_upper_34_8  39.6
    x[34,8]   hard_cost_D_definition  9.3092511011388858e-04
    x[34,9]   onehot_34  1
    x[34,9]   inventory_34  -9
    x[34,9]   product_lx_34_9  -8.61111111111111
    x[34,9]   product_ux_34_9  -39.6
    x[34,9]   product_Su_34_9  -39.6
    x[34,9]   product_Sl_34_9  -8.61111111111111
    x[34,9]   conditional_Sx_lower_34_9  -8.61111111111111
    x[34,9]   conditional_Sx_upper_34_9  -3.8925000000000004e+01
    x[34,9]   conditional_complement_lower_34_9  8.61111111111111
    x[34,9]   conditional_complement_upper_34_9  39.6
    x[34,9]   hard_cost_D_definition  6.9819383258541646e-04
    x[34,10]  onehot_34  1
    x[34,10]  inventory_34  -10
    x[34,10]  product_lx_34_10  -8.61111111111111
    x[34,10]  product_ux_34_10  -39.6
    x[34,10]  product_Su_34_10  -39.6
    x[34,10]  product_Sl_34_10  -8.61111111111111
    x[34,10]  conditional_Sx_lower_34_10  -8.61111111111111
    x[34,10]  conditional_Sx_upper_34_10  -38.85
    x[34,10]  conditional_complement_lower_34_10  8.61111111111111
    x[34,10]  conditional_complement_upper_34_10  39.6
    x[34,10]  hard_cost_D_definition  4.6546255505694429e-04
    x[34,11]  onehot_34  1
    x[34,11]  inventory_34  -11
    x[34,11]  product_lx_34_11  -8.61111111111111
    x[34,11]  product_ux_34_11  -39.6
    x[34,11]  product_Su_34_11  -39.6
    x[34,11]  product_Sl_34_11  -8.61111111111111
    x[34,11]  conditional_Sx_lower_34_11  -8.61111111111111
    x[34,11]  conditional_Sx_upper_34_11  -3.8775000000000006e+01
    x[34,11]  conditional_complement_lower_34_11  8.61111111111111
    x[34,11]  conditional_complement_upper_34_11  39.6
    x[34,11]  hard_cost_D_definition  2.3273127752847215e-04
    x[34,12]  onehot_34  1
    x[34,12]  inventory_34  -12
    x[34,12]  product_lx_34_12  -8.61111111111111
    x[34,12]  product_ux_34_12  -39.6
    x[34,12]  product_Su_34_12  -39.6
    x[34,12]  product_Sl_34_12  -8.61111111111111
    x[34,12]  conditional_Sx_lower_34_12  -8.61111111111111
    x[34,12]  conditional_Sx_upper_34_12  -38.7
    x[34,12]  conditional_complement_lower_34_12  8.61111111111111
    x[34,12]  conditional_complement_upper_34_12  39.6
    x[34,13]  onehot_34  1
    x[34,13]  inventory_34  -13
    x[34,13]  product_lx_34_13  -8.61111111111111
    x[34,13]  product_ux_34_13  -39.6
    x[34,13]  product_Su_34_13  -39.6
    x[34,13]  product_Sl_34_13  -8.61111111111111
    x[34,13]  conditional_Sx_lower_34_13  -8.61111111111111
    x[34,13]  conditional_Sx_upper_34_13  -38.625
    x[34,13]  conditional_complement_lower_34_13  8.61111111111111
    x[34,13]  conditional_complement_upper_34_13  39.6
    x[34,13]  hard_cost_D_definition  -2.3273127752847215e-04
    x[34,14]  onehot_34  1
    x[34,14]  inventory_34  -14
    x[34,14]  product_lx_34_14  -8.61111111111111
    x[34,14]  product_ux_34_14  -39.6
    x[34,14]  product_Su_34_14  -39.6
    x[34,14]  product_Sl_34_14  -8.61111111111111
    x[34,14]  conditional_Sx_lower_34_14  -8.61111111111111
    x[34,14]  conditional_Sx_upper_34_14  -3.8550000000000004e+01
    x[34,14]  conditional_complement_lower_34_14  8.61111111111111
    x[34,14]  conditional_complement_upper_34_14  39.6
    x[34,14]  hard_cost_D_definition  -4.6546255505694429e-04
    x[34,15]  onehot_34  1
    x[34,15]  inventory_34  -15
    x[34,15]  product_lx_34_15  -8.61111111111111
    x[34,15]  product_ux_34_15  -39.6
    x[34,15]  product_Su_34_15  -39.6
    x[34,15]  product_Sl_34_15  -8.61111111111111
    x[34,15]  conditional_Sx_lower_34_15  -8.61111111111111
    x[34,15]  conditional_Sx_upper_34_15  -38.475
    x[34,15]  conditional_complement_lower_34_15  8.61111111111111
    x[34,15]  conditional_complement_upper_34_15  39.6
    x[34,15]  hard_cost_D_definition  -6.9819383258541636e-04
    x[35,0]   onehot_35  1
    x[35,0]   product_lx_35_0  -8.61111111111111
    x[35,0]   product_ux_35_0  -39.6
    x[35,0]   product_Su_35_0  -39.6
    x[35,0]   product_Sl_35_0  -8.61111111111111
    x[35,0]   conditional_Sx_lower_35_0  -8.73611111111111
    x[35,0]   conditional_Sx_upper_35_0  -39.6
    x[35,0]   conditional_complement_lower_35_0  8.61111111111111
    x[35,0]   conditional_complement_upper_35_0  3.9525000000000006e+01
    x[35,0]   hard_cost_D_definition  -9.3092511011388858e-04
    x[35,1]   onehot_35  1
    x[35,1]   inventory_35  -1
    x[35,1]   product_lx_35_1  -8.61111111111111
    x[35,1]   product_ux_35_1  -39.6
    x[35,1]   product_Su_35_1  -39.6
    x[35,1]   product_Sl_35_1  -8.61111111111111
    x[35,1]   conditional_Sx_lower_35_1  -8.7182539682539666e+00
    x[35,1]   conditional_Sx_upper_35_1  -3.9525000000000006e+01
    x[35,1]   conditional_complement_lower_35_1  8.61111111111111
    x[35,1]   conditional_complement_upper_35_1  39.6
    x[35,1]   hard_cost_D_definition  -6.9819383258541636e-04
    x[35,2]   onehot_35  1
    x[35,2]   inventory_35  -2
    x[35,2]   product_lx_35_2  -8.61111111111111
    x[35,2]   product_ux_35_2  -39.6
    x[35,2]   product_Su_35_2  -39.6
    x[35,2]   product_Sl_35_2  -8.61111111111111
    x[35,2]   conditional_Sx_lower_35_2  -8.7003968253968242e+00
    x[35,2]   conditional_Sx_upper_35_2  -39.45
    x[35,2]   conditional_complement_lower_35_2  8.61111111111111
    x[35,2]   conditional_complement_upper_35_2  39.6
    x[35,2]   hard_cost_D_definition  -4.6546255505694429e-04
    x[35,3]   onehot_35  1
    x[35,3]   inventory_35  -3
    x[35,3]   product_lx_35_3  -8.61111111111111
    x[35,3]   product_ux_35_3  -39.6
    x[35,3]   product_Su_35_3  -39.6
    x[35,3]   product_Sl_35_3  -8.61111111111111
    x[35,3]   conditional_Sx_lower_35_3  -8.6825396825396819e+00
    x[35,3]   conditional_Sx_upper_35_3  -39.375
    x[35,3]   conditional_complement_lower_35_3  8.61111111111111
    x[35,3]   conditional_complement_upper_35_3  39.6
    x[35,3]   hard_cost_D_definition  -2.3273127752847215e-04
    x[35,4]   onehot_35  1
    x[35,4]   inventory_35  -4
    x[35,4]   product_lx_35_4  -8.61111111111111
    x[35,4]   product_ux_35_4  -39.6
    x[35,4]   product_Su_35_4  -39.6
    x[35,4]   product_Sl_35_4  -8.61111111111111
    x[35,4]   conditional_Sx_lower_35_4  -8.66468253968254
    x[35,4]   conditional_Sx_upper_35_4  -3.9300000000000004e+01
    x[35,4]   conditional_complement_lower_35_4  8.61111111111111
    x[35,4]   conditional_complement_upper_35_4  39.6
    x[35,5]   onehot_35  1
    x[35,5]   inventory_35  -5
    x[35,5]   product_lx_35_5  -8.61111111111111
    x[35,5]   product_ux_35_5  -39.6
    x[35,5]   product_Su_35_5  -39.6
    x[35,5]   product_Sl_35_5  -8.61111111111111
    x[35,5]   conditional_Sx_lower_35_5  -8.6468253968253954e+00
    x[35,5]   conditional_Sx_upper_35_5  -39.225
    x[35,5]   conditional_complement_lower_35_5  8.61111111111111
    x[35,5]   conditional_complement_upper_35_5  39.6
    x[35,5]   hard_cost_D_definition  2.3273127752847215e-04
    x[35,6]   onehot_35  1
    x[35,6]   inventory_35  -6
    x[35,6]   product_lx_35_6  -8.61111111111111
    x[35,6]   product_ux_35_6  -39.6
    x[35,6]   product_Su_35_6  -39.6
    x[35,6]   product_Sl_35_6  -8.61111111111111
    x[35,6]   conditional_Sx_lower_35_6  -8.6289682539682531e+00
    x[35,6]   conditional_Sx_upper_35_6  -3.9150000000000006e+01
    x[35,6]   conditional_complement_lower_35_6  8.61111111111111
    x[35,6]   conditional_complement_upper_35_6  39.6
    x[35,6]   hard_cost_D_definition  4.6546255505694429e-04
    x[35,7]   onehot_35  1
    x[35,7]   inventory_35  -7
    x[35,7]   product_lx_35_7  -8.61111111111111
    x[35,7]   product_ux_35_7  -39.6
    x[35,7]   product_Su_35_7  -39.6
    x[35,7]   product_Sl_35_7  -8.61111111111111
    x[35,7]   conditional_Sx_lower_35_7  -8.61111111111111
    x[35,7]   conditional_Sx_upper_35_7  -39.075
    x[35,7]   conditional_complement_lower_35_7  8.61111111111111
    x[35,7]   conditional_complement_upper_35_7  39.6
    x[35,7]   hard_cost_D_definition  6.9819383258541646e-04
    x[35,8]   onehot_35  1
    x[35,8]   inventory_35  -8
    x[35,8]   product_lx_35_8  -8.61111111111111
    x[35,8]   product_ux_35_8  -39.6
    x[35,8]   product_Su_35_8  -39.6
    x[35,8]   product_Sl_35_8  -8.61111111111111
    x[35,8]   conditional_Sx_lower_35_8  -8.61111111111111
    x[35,8]   conditional_Sx_upper_35_8  -39
    x[35,8]   conditional_complement_lower_35_8  8.61111111111111
    x[35,8]   conditional_complement_upper_35_8  39.6
    x[35,8]   hard_cost_D_definition  9.3092511011388858e-04
    x[35,9]   onehot_35  1
    x[35,9]   inventory_35  -9
    x[35,9]   product_lx_35_9  -8.61111111111111
    x[35,9]   product_ux_35_9  -39.6
    x[35,9]   product_Su_35_9  -39.6
    x[35,9]   product_Sl_35_9  -8.61111111111111
    x[35,9]   conditional_Sx_lower_35_9  -8.61111111111111
    x[35,9]   conditional_Sx_upper_35_9  -3.8925000000000004e+01
    x[35,9]   conditional_complement_lower_35_9  8.61111111111111
    x[35,9]   conditional_complement_upper_35_9  39.6
    x[35,9]   hard_cost_D_definition  6.9819383258541646e-04
    x[35,10]  onehot_35  1
    x[35,10]  inventory_35  -10
    x[35,10]  product_lx_35_10  -8.61111111111111
    x[35,10]  product_ux_35_10  -39.6
    x[35,10]  product_Su_35_10  -39.6
    x[35,10]  product_Sl_35_10  -8.61111111111111
    x[35,10]  conditional_Sx_lower_35_10  -8.61111111111111
    x[35,10]  conditional_Sx_upper_35_10  -38.85
    x[35,10]  conditional_complement_lower_35_10  8.61111111111111
    x[35,10]  conditional_complement_upper_35_10  39.6
    x[35,10]  hard_cost_D_definition  4.6546255505694429e-04
    x[35,11]  onehot_35  1
    x[35,11]  inventory_35  -11
    x[35,11]  product_lx_35_11  -8.61111111111111
    x[35,11]  product_ux_35_11  -39.6
    x[35,11]  product_Su_35_11  -39.6
    x[35,11]  product_Sl_35_11  -8.61111111111111
    x[35,11]  conditional_Sx_lower_35_11  -8.61111111111111
    x[35,11]  conditional_Sx_upper_35_11  -3.8775000000000006e+01
    x[35,11]  conditional_complement_lower_35_11  8.61111111111111
    x[35,11]  conditional_complement_upper_35_11  39.6
    x[35,11]  hard_cost_D_definition  2.3273127752847215e-04
    x[35,12]  onehot_35  1
    x[35,12]  inventory_35  -12
    x[35,12]  product_lx_35_12  -8.61111111111111
    x[35,12]  product_ux_35_12  -39.6
    x[35,12]  product_Su_35_12  -39.6
    x[35,12]  product_Sl_35_12  -8.61111111111111
    x[35,12]  conditional_Sx_lower_35_12  -8.61111111111111
    x[35,12]  conditional_Sx_upper_35_12  -38.7
    x[35,12]  conditional_complement_lower_35_12  8.61111111111111
    x[35,12]  conditional_complement_upper_35_12  39.6
    x[35,13]  onehot_35  1
    x[35,13]  inventory_35  -13
    x[35,13]  product_lx_35_13  -8.61111111111111
    x[35,13]  product_ux_35_13  -39.6
    x[35,13]  product_Su_35_13  -39.6
    x[35,13]  product_Sl_35_13  -8.61111111111111
    x[35,13]  conditional_Sx_lower_35_13  -8.61111111111111
    x[35,13]  conditional_Sx_upper_35_13  -38.625
    x[35,13]  conditional_complement_lower_35_13  8.61111111111111
    x[35,13]  conditional_complement_upper_35_13  39.6
    x[35,13]  hard_cost_D_definition  -2.3273127752847215e-04
    x[35,14]  onehot_35  1
    x[35,14]  inventory_35  -14
    x[35,14]  product_lx_35_14  -8.61111111111111
    x[35,14]  product_ux_35_14  -39.6
    x[35,14]  product_Su_35_14  -39.6
    x[35,14]  product_Sl_35_14  -8.61111111111111
    x[35,14]  conditional_Sx_lower_35_14  -8.61111111111111
    x[35,14]  conditional_Sx_upper_35_14  -3.8550000000000004e+01
    x[35,14]  conditional_complement_lower_35_14  8.61111111111111
    x[35,14]  conditional_complement_upper_35_14  39.6
    x[35,14]  hard_cost_D_definition  -4.6546255505694429e-04
    x[35,15]  onehot_35  1
    x[35,15]  inventory_35  -15
    x[35,15]  product_lx_35_15  -8.61111111111111
    x[35,15]  product_ux_35_15  -39.6
    x[35,15]  product_Su_35_15  -39.6
    x[35,15]  product_Sl_35_15  -8.61111111111111
    x[35,15]  conditional_Sx_lower_35_15  -8.61111111111111
    x[35,15]  conditional_Sx_upper_35_15  -38.475
    x[35,15]  conditional_complement_lower_35_15  8.61111111111111
    x[35,15]  conditional_complement_upper_35_15  39.6
    x[35,15]  hard_cost_D_definition  -6.9819383258541636e-04
    MARKER    'MARKER'                 'INTEND'
    Sx[1,0]   product_mass_1  1
    Sx[1,0]   product_lx_1_0  1
    Sx[1,0]   product_ux_1_0  1
    Sx[1,0]   product_Su_1_0  1
    Sx[1,0]   product_Sl_1_0  1
    Sx[1,0]   conditional_Sx_lower_1_0  1
    Sx[1,0]   conditional_Sx_upper_1_0  1
    Sx[1,0]   conditional_complement_lower_1_0  -1
    Sx[1,0]   conditional_complement_upper_1_0  -1
    Sx[1,0]   hard_cost_W_definition  -2.3273157207916555e-04
    Sx[1,0]   floor_residual  -2.3273157207916555e-04
    Sx[1,0]   G_residual  -2.3273157207916555e-04
    Sx[1,1]   product_mass_1  1
    Sx[1,1]   product_lx_1_1  1
    Sx[1,1]   product_ux_1_1  1
    Sx[1,1]   product_Su_1_1  1
    Sx[1,1]   product_Sl_1_1  1
    Sx[1,1]   total_product_lower  1
    Sx[1,1]   total_product_upper  1
    Sx[1,1]   conditional_Sx_lower_1_1  1
    Sx[1,1]   conditional_Sx_upper_1_1  1
    Sx[1,1]   conditional_complement_lower_1_1  -1
    Sx[1,1]   conditional_complement_upper_1_1  -1
    Sx[1,1]   hard_cost_W_definition  -1.1636578603958278e-04
    Sx[1,1]   floor_residual  -1.1636578603958278e-04
    Sx[1,1]   G_residual  -1.1636578603958278e-04
    Sx[1,2]   product_mass_1  1
    Sx[1,2]   product_lx_1_2  1
    Sx[1,2]   product_ux_1_2  1
    Sx[1,2]   product_Su_1_2  1
    Sx[1,2]   product_Sl_1_2  1
    Sx[1,2]   total_product_lower  2
    Sx[1,2]   total_product_upper  2
    Sx[1,2]   conditional_Sx_lower_1_2  1
    Sx[1,2]   conditional_Sx_upper_1_2  1
    Sx[1,2]   conditional_complement_lower_1_2  -1
    Sx[1,2]   conditional_complement_upper_1_2  -1
    Sx[1,3]   product_mass_1  1
    Sx[1,3]   product_lx_1_3  1
    Sx[1,3]   product_ux_1_3  1
    Sx[1,3]   product_Su_1_3  1
    Sx[1,3]   product_Sl_1_3  1
    Sx[1,3]   total_product_lower  3
    Sx[1,3]   total_product_upper  3
    Sx[1,3]   conditional_Sx_lower_1_3  1
    Sx[1,3]   conditional_Sx_upper_1_3  1
    Sx[1,3]   conditional_complement_lower_1_3  -1
    Sx[1,3]   conditional_complement_upper_1_3  -1
    Sx[1,3]   hard_cost_W_definition  1.1636578603958278e-04
    Sx[1,3]   floor_residual  1.1636578603958278e-04
    Sx[1,3]   G_residual  1.1636578603958278e-04
    Sx[1,4]   product_mass_1  1
    Sx[1,4]   product_lx_1_4  1
    Sx[1,4]   product_ux_1_4  1
    Sx[1,4]   product_Su_1_4  1
    Sx[1,4]   product_Sl_1_4  1
    Sx[1,4]   total_product_lower  4
    Sx[1,4]   total_product_upper  4
    Sx[1,4]   conditional_Sx_lower_1_4  1
    Sx[1,4]   conditional_Sx_upper_1_4  1
    Sx[1,4]   conditional_complement_lower_1_4  -1
    Sx[1,4]   conditional_complement_upper_1_4  -1
    Sx[1,4]   hard_cost_W_definition  2.3273157207916555e-04
    Sx[1,4]   floor_residual  2.3273157207916555e-04
    Sx[1,4]   G_residual  2.3273157207916555e-04
    Sx[1,5]   product_mass_1  1
    Sx[1,5]   product_lx_1_5  1
    Sx[1,5]   product_ux_1_5  1
    Sx[1,5]   product_Su_1_5  1
    Sx[1,5]   product_Sl_1_5  1
    Sx[1,5]   total_product_lower  5
    Sx[1,5]   total_product_upper  5
    Sx[1,5]   conditional_Sx_lower_1_5  1
    Sx[1,5]   conditional_Sx_upper_1_5  1
    Sx[1,5]   conditional_complement_lower_1_5  -1
    Sx[1,5]   conditional_complement_upper_1_5  -1
    Sx[1,5]   hard_cost_W_definition  1.1636578603958278e-04
    Sx[1,5]   floor_residual  1.1636578603958278e-04
    Sx[1,5]   G_residual  1.1636578603958278e-04
    Sx[1,6]   product_mass_1  1
    Sx[1,6]   product_lx_1_6  1
    Sx[1,6]   product_ux_1_6  1
    Sx[1,6]   product_Su_1_6  1
    Sx[1,6]   product_Sl_1_6  1
    Sx[1,6]   total_product_lower  6
    Sx[1,6]   total_product_upper  6
    Sx[1,6]   conditional_Sx_lower_1_6  1
    Sx[1,6]   conditional_Sx_upper_1_6  1
    Sx[1,6]   conditional_complement_lower_1_6  -1
    Sx[1,6]   conditional_complement_upper_1_6  -1
    Sx[1,7]   product_mass_1  1
    Sx[1,7]   product_lx_1_7  1
    Sx[1,7]   product_ux_1_7  1
    Sx[1,7]   product_Su_1_7  1
    Sx[1,7]   product_Sl_1_7  1
    Sx[1,7]   total_product_lower  7
    Sx[1,7]   total_product_upper  7
    Sx[1,7]   conditional_Sx_lower_1_7  1
    Sx[1,7]   conditional_Sx_upper_1_7  1
    Sx[1,7]   conditional_complement_lower_1_7  -1
    Sx[1,7]   conditional_complement_upper_1_7  -1
    Sx[1,7]   hard_cost_W_definition  -1.1636578603958278e-04
    Sx[1,7]   floor_residual  -1.1636578603958278e-04
    Sx[1,7]   G_residual  -1.1636578603958278e-04
    Sx[1,8]   product_mass_1  1
    Sx[1,8]   product_lx_1_8  1
    Sx[1,8]   product_ux_1_8  1
    Sx[1,8]   product_Su_1_8  1
    Sx[1,8]   product_Sl_1_8  1
    Sx[1,8]   total_product_lower  8
    Sx[1,8]   total_product_upper  8
    Sx[1,8]   conditional_Sx_lower_1_8  1
    Sx[1,8]   conditional_Sx_upper_1_8  1
    Sx[1,8]   conditional_complement_lower_1_8  -1
    Sx[1,8]   conditional_complement_upper_1_8  -1
    Sx[1,8]   hard_cost_W_definition  -2.3273157207916555e-04
    Sx[1,8]   floor_residual  -2.3273157207916555e-04
    Sx[1,8]   G_residual  -2.3273157207916555e-04
    Sx[2,0]   product_mass_2  1
    Sx[2,0]   product_lx_2_0  1
    Sx[2,0]   product_ux_2_0  1
    Sx[2,0]   product_Su_2_0  1
    Sx[2,0]   product_Sl_2_0  1
    Sx[2,0]   conditional_Sx_lower_2_0  1
    Sx[2,0]   conditional_Sx_upper_2_0  1
    Sx[2,0]   conditional_complement_lower_2_0  -1
    Sx[2,0]   conditional_complement_upper_2_0  -1
    Sx[2,0]   hard_cost_W_definition  -6.1091968240974646e-04
    Sx[2,0]   floor_residual  -6.1091968240974646e-04
    Sx[2,0]   G_residual  -6.1091968240974646e-04
    Sx[2,1]   product_mass_2  1
    Sx[2,1]   product_lx_2_1  1
    Sx[2,1]   product_ux_2_1  1
    Sx[2,1]   product_Su_2_1  1
    Sx[2,1]   product_Sl_2_1  1
    Sx[2,1]   total_product_lower  1
    Sx[2,1]   total_product_upper  1
    Sx[2,1]   conditional_Sx_lower_2_1  1
    Sx[2,1]   conditional_Sx_upper_2_1  1
    Sx[2,1]   conditional_complement_lower_2_1  -1
    Sx[2,1]   conditional_complement_upper_2_1  -1
    Sx[2,1]   hard_cost_W_definition  -4.0727978827316433e-04
    Sx[2,1]   floor_residual  -4.0727978827316433e-04
    Sx[2,1]   G_residual  -4.0727978827316433e-04
    Sx[2,2]   product_mass_2  1
    Sx[2,2]   product_lx_2_2  1
    Sx[2,2]   product_ux_2_2  1
    Sx[2,2]   product_Su_2_2  1
    Sx[2,2]   product_Sl_2_2  1
    Sx[2,2]   total_product_lower  2
    Sx[2,2]   total_product_upper  2
    Sx[2,2]   conditional_Sx_lower_2_2  1
    Sx[2,2]   conditional_Sx_upper_2_2  1
    Sx[2,2]   conditional_complement_lower_2_2  -1
    Sx[2,2]   conditional_complement_upper_2_2  -1
    Sx[2,2]   hard_cost_W_definition  -2.0363989413658219e-04
    Sx[2,2]   floor_residual  -2.0363989413658219e-04
    Sx[2,2]   G_residual  -2.0363989413658219e-04
    Sx[2,3]   product_mass_2  1
    Sx[2,3]   product_lx_2_3  1
    Sx[2,3]   product_ux_2_3  1
    Sx[2,3]   product_Su_2_3  1
    Sx[2,3]   product_Sl_2_3  1
    Sx[2,3]   total_product_lower  3
    Sx[2,3]   total_product_upper  3
    Sx[2,3]   conditional_Sx_lower_2_3  1
    Sx[2,3]   conditional_Sx_upper_2_3  1
    Sx[2,3]   conditional_complement_lower_2_3  -1
    Sx[2,3]   conditional_complement_upper_2_3  -1
    Sx[2,4]   product_mass_2  1
    Sx[2,4]   product_lx_2_4  1
    Sx[2,4]   product_ux_2_4  1
    Sx[2,4]   product_Su_2_4  1
    Sx[2,4]   product_Sl_2_4  1
    Sx[2,4]   total_product_lower  4
    Sx[2,4]   total_product_upper  4
    Sx[2,4]   conditional_Sx_lower_2_4  1
    Sx[2,4]   conditional_Sx_upper_2_4  1
    Sx[2,4]   conditional_complement_lower_2_4  -1
    Sx[2,4]   conditional_complement_upper_2_4  -1
    Sx[2,4]   hard_cost_W_definition  2.0363989413658206e-04
    Sx[2,4]   floor_residual  2.0363989413658206e-04
    Sx[2,4]   G_residual  2.0363989413658206e-04
    Sx[2,5]   product_mass_2  1
    Sx[2,5]   product_lx_2_5  1
    Sx[2,5]   product_ux_2_5  1
    Sx[2,5]   product_Su_2_5  1
    Sx[2,5]   product_Sl_2_5  1
    Sx[2,5]   total_product_lower  5
    Sx[2,5]   total_product_upper  5
    Sx[2,5]   conditional_Sx_lower_2_5  1
    Sx[2,5]   conditional_Sx_upper_2_5  1
    Sx[2,5]   conditional_complement_lower_2_5  -1
    Sx[2,5]   conditional_complement_upper_2_5  -1
    Sx[2,5]   hard_cost_W_definition  4.0727978827316422e-04
    Sx[2,5]   floor_residual  4.0727978827316422e-04
    Sx[2,5]   G_residual  4.0727978827316422e-04
    Sx[2,6]   product_mass_2  1
    Sx[2,6]   product_lx_2_6  1
    Sx[2,6]   product_ux_2_6  1
    Sx[2,6]   product_Su_2_6  1
    Sx[2,6]   product_Sl_2_6  1
    Sx[2,6]   total_product_lower  6
    Sx[2,6]   total_product_upper  6
    Sx[2,6]   conditional_Sx_lower_2_6  1
    Sx[2,6]   conditional_Sx_upper_2_6  1
    Sx[2,6]   conditional_complement_lower_2_6  -1
    Sx[2,6]   conditional_complement_upper_2_6  -1
    Sx[2,6]   hard_cost_W_definition  6.1091968240974636e-04
    Sx[2,6]   floor_residual  6.1091968240974636e-04
    Sx[2,6]   G_residual  6.1091968240974636e-04
    Sx[2,7]   product_mass_2  1
    Sx[2,7]   product_lx_2_7  1
    Sx[2,7]   product_ux_2_7  1
    Sx[2,7]   product_Su_2_7  1
    Sx[2,7]   product_Sl_2_7  1
    Sx[2,7]   total_product_lower  7
    Sx[2,7]   total_product_upper  7
    Sx[2,7]   conditional_Sx_lower_2_7  1
    Sx[2,7]   conditional_Sx_upper_2_7  1
    Sx[2,7]   conditional_complement_lower_2_7  -1
    Sx[2,7]   conditional_complement_upper_2_7  -1
    Sx[2,7]   hard_cost_W_definition  8.1455957654632855e-04
    Sx[2,7]   floor_residual  8.1455957654632855e-04
    Sx[2,7]   G_residual  8.1455957654632855e-04
    Sx[2,8]   product_mass_2  1
    Sx[2,8]   product_lx_2_8  1
    Sx[2,8]   product_ux_2_8  1
    Sx[2,8]   product_Su_2_8  1
    Sx[2,8]   product_Sl_2_8  1
    Sx[2,8]   total_product_lower  8
    Sx[2,8]   total_product_upper  8
    Sx[2,8]   conditional_Sx_lower_2_8  1
    Sx[2,8]   conditional_Sx_upper_2_8  1
    Sx[2,8]   conditional_complement_lower_2_8  -1
    Sx[2,8]   conditional_complement_upper_2_8  -1
    Sx[2,8]   hard_cost_W_definition  6.1091968240974657e-04
    Sx[2,8]   floor_residual  6.1091968240974657e-04
    Sx[2,8]   G_residual  6.1091968240974657e-04
    Sx[2,9]   product_mass_2  1
    Sx[2,9]   product_lx_2_9  1
    Sx[2,9]   product_ux_2_9  1
    Sx[2,9]   product_Su_2_9  1
    Sx[2,9]   product_Sl_2_9  1
    Sx[2,9]   total_product_lower  9
    Sx[2,9]   total_product_upper  9
    Sx[2,9]   conditional_Sx_lower_2_9  1
    Sx[2,9]   conditional_Sx_upper_2_9  1
    Sx[2,9]   conditional_complement_lower_2_9  -1
    Sx[2,9]   conditional_complement_upper_2_9  -1
    Sx[2,9]   hard_cost_W_definition  4.0727978827316438e-04
    Sx[2,9]   floor_residual  4.0727978827316438e-04
    Sx[2,9]   G_residual  4.0727978827316438e-04
    Sx[2,10]  product_mass_2  1
    Sx[2,10]  product_lx_2_10  1
    Sx[2,10]  product_ux_2_10  1
    Sx[2,10]  product_Su_2_10  1
    Sx[2,10]  product_Sl_2_10  1
    Sx[2,10]  total_product_lower  10
    Sx[2,10]  total_product_upper  10
    Sx[2,10]  conditional_Sx_lower_2_10  1
    Sx[2,10]  conditional_Sx_upper_2_10  1
    Sx[2,10]  conditional_complement_lower_2_10  -1
    Sx[2,10]  conditional_complement_upper_2_10  -1
    Sx[2,10]  hard_cost_W_definition  2.0363989413658222e-04
    Sx[2,10]  floor_residual  2.0363989413658222e-04
    Sx[2,10]  G_residual  2.0363989413658222e-04
    Sx[2,11]  product_mass_2  1
    Sx[2,11]  product_lx_2_11  1
    Sx[2,11]  product_ux_2_11  1
    Sx[2,11]  product_Su_2_11  1
    Sx[2,11]  product_Sl_2_11  1
    Sx[2,11]  total_product_lower  11
    Sx[2,11]  total_product_upper  11
    Sx[2,11]  conditional_Sx_lower_2_11  1
    Sx[2,11]  conditional_Sx_upper_2_11  1
    Sx[2,11]  conditional_complement_lower_2_11  -1
    Sx[2,11]  conditional_complement_upper_2_11  -1
    Sx[2,12]  product_mass_2  1
    Sx[2,12]  product_lx_2_12  1
    Sx[2,12]  product_ux_2_12  1
    Sx[2,12]  product_Su_2_12  1
    Sx[2,12]  product_Sl_2_12  1
    Sx[2,12]  total_product_lower  12
    Sx[2,12]  total_product_upper  12
    Sx[2,12]  conditional_Sx_lower_2_12  1
    Sx[2,12]  conditional_Sx_upper_2_12  1
    Sx[2,12]  conditional_complement_lower_2_12  -1
    Sx[2,12]  conditional_complement_upper_2_12  -1
    Sx[2,12]  hard_cost_W_definition  -2.0363989413658203e-04
    Sx[2,12]  floor_residual  -2.0363989413658203e-04
    Sx[2,12]  G_residual  -2.0363989413658203e-04
    Sx[2,13]  product_mass_2  1
    Sx[2,13]  product_lx_2_13  1
    Sx[2,13]  product_ux_2_13  1
    Sx[2,13]  product_Su_2_13  1
    Sx[2,13]  product_Sl_2_13  1
    Sx[2,13]  total_product_lower  13
    Sx[2,13]  total_product_upper  13
    Sx[2,13]  conditional_Sx_lower_2_13  1
    Sx[2,13]  conditional_Sx_upper_2_13  1
    Sx[2,13]  conditional_complement_lower_2_13  -1
    Sx[2,13]  conditional_complement_upper_2_13  -1
    Sx[2,13]  hard_cost_W_definition  -4.0727978827316417e-04
    Sx[2,13]  floor_residual  -4.0727978827316417e-04
    Sx[2,13]  G_residual  -4.0727978827316417e-04
    Sx[2,14]  product_mass_2  1
    Sx[2,14]  product_lx_2_14  1
    Sx[2,14]  product_ux_2_14  1
    Sx[2,14]  product_Su_2_14  1
    Sx[2,14]  product_Sl_2_14  1
    Sx[2,14]  total_product_lower  14
    Sx[2,14]  total_product_upper  14
    Sx[2,14]  conditional_Sx_lower_2_14  1
    Sx[2,14]  conditional_Sx_upper_2_14  1
    Sx[2,14]  conditional_complement_lower_2_14  -1
    Sx[2,14]  conditional_complement_upper_2_14  -1
    Sx[2,14]  hard_cost_W_definition  -6.1091968240974625e-04
    Sx[2,14]  floor_residual  -6.1091968240974625e-04
    Sx[2,14]  G_residual  -6.1091968240974625e-04
    Sx[2,15]  product_mass_2  1
    Sx[2,15]  product_lx_2_15  1
    Sx[2,15]  product_ux_2_15  1
    Sx[2,15]  product_Su_2_15  1
    Sx[2,15]  product_Sl_2_15  1
    Sx[2,15]  total_product_lower  15
    Sx[2,15]  total_product_upper  15
    Sx[2,15]  conditional_Sx_lower_2_15  1
    Sx[2,15]  conditional_Sx_upper_2_15  1
    Sx[2,15]  conditional_complement_lower_2_15  -1
    Sx[2,15]  conditional_complement_upper_2_15  -1
    Sx[2,15]  hard_cost_W_definition  -8.1455957654632844e-04
    Sx[2,15]  floor_residual  -8.1455957654632844e-04
    Sx[2,15]  G_residual  -8.1455957654632844e-04
    Sx[3,0]   product_mass_3  1
    Sx[3,0]   product_lx_3_0  1
    Sx[3,0]   product_ux_3_0  1
    Sx[3,0]   product_Su_3_0  1
    Sx[3,0]   product_Sl_3_0  1
    Sx[3,0]   conditional_Sx_lower_3_0  1
    Sx[3,0]   conditional_Sx_upper_3_0  1
    Sx[3,0]   conditional_complement_lower_3_0  -1
    Sx[3,0]   conditional_complement_upper_3_0  -1
    Sx[3,0]   hard_cost_W_definition  -5.2364515352604213e-04
    Sx[3,0]   floor_residual  -5.2364515352604213e-04
    Sx[3,0]   G_residual  -5.2364515352604213e-04
    Sx[3,1]   product_mass_3  1
    Sx[3,1]   product_lx_3_1  1
    Sx[3,1]   product_ux_3_1  1
    Sx[3,1]   product_Su_3_1  1
    Sx[3,1]   product_Sl_3_1  1
    Sx[3,1]   total_product_lower  1
    Sx[3,1]   total_product_upper  1
    Sx[3,1]   conditional_Sx_lower_3_1  1
    Sx[3,1]   conditional_Sx_upper_3_1  1
    Sx[3,1]   conditional_complement_lower_3_1  -1
    Sx[3,1]   conditional_complement_upper_3_1  -1
    Sx[3,1]   hard_cost_W_definition  -3.4909676901736142e-04
    Sx[3,1]   floor_residual  -3.4909676901736142e-04
    Sx[3,1]   G_residual  -3.4909676901736142e-04
    Sx[3,2]   product_mass_3  1
    Sx[3,2]   product_lx_3_2  1
    Sx[3,2]   product_ux_3_2  1
    Sx[3,2]   product_Su_3_2  1
    Sx[3,2]   product_Sl_3_2  1
    Sx[3,2]   total_product_lower  2
    Sx[3,2]   total_product_upper  2
    Sx[3,2]   conditional_Sx_lower_3_2  1
    Sx[3,2]   conditional_Sx_upper_3_2  1
    Sx[3,2]   conditional_complement_lower_3_2  -1
    Sx[3,2]   conditional_complement_upper_3_2  -1
    Sx[3,2]   hard_cost_W_definition  -1.7454838450868071e-04
    Sx[3,2]   floor_residual  -1.7454838450868071e-04
    Sx[3,2]   G_residual  -1.7454838450868071e-04
    Sx[3,3]   product_mass_3  1
    Sx[3,3]   product_lx_3_3  1
    Sx[3,3]   product_ux_3_3  1
    Sx[3,3]   product_Su_3_3  1
    Sx[3,3]   product_Sl_3_3  1
    Sx[3,3]   total_product_lower  3
    Sx[3,3]   total_product_upper  3
    Sx[3,3]   conditional_Sx_lower_3_3  1
    Sx[3,3]   conditional_Sx_upper_3_3  1
    Sx[3,3]   conditional_complement_lower_3_3  -1
    Sx[3,3]   conditional_complement_upper_3_3  -1
    Sx[3,4]   product_mass_3  1
    Sx[3,4]   product_lx_3_4  1
    Sx[3,4]   product_ux_3_4  1
    Sx[3,4]   product_Su_3_4  1
    Sx[3,4]   product_Sl_3_4  1
    Sx[3,4]   total_product_lower  4
    Sx[3,4]   total_product_upper  4
    Sx[3,4]   conditional_Sx_lower_3_4  1
    Sx[3,4]   conditional_Sx_upper_3_4  1
    Sx[3,4]   conditional_complement_lower_3_4  -1
    Sx[3,4]   conditional_complement_upper_3_4  -1
    Sx[3,4]   hard_cost_W_definition  1.7454838450868074e-04
    Sx[3,4]   floor_residual  1.7454838450868074e-04
    Sx[3,4]   G_residual  1.7454838450868074e-04
    Sx[3,5]   product_mass_3  1
    Sx[3,5]   product_lx_3_5  1
    Sx[3,5]   product_ux_3_5  1
    Sx[3,5]   product_Su_3_5  1
    Sx[3,5]   product_Sl_3_5  1
    Sx[3,5]   total_product_lower  5
    Sx[3,5]   total_product_upper  5
    Sx[3,5]   conditional_Sx_lower_3_5  1
    Sx[3,5]   conditional_Sx_upper_3_5  1
    Sx[3,5]   conditional_complement_lower_3_5  -1
    Sx[3,5]   conditional_complement_upper_3_5  -1
    Sx[3,5]   hard_cost_W_definition  3.4909676901736148e-04
    Sx[3,5]   floor_residual  3.4909676901736148e-04
    Sx[3,5]   G_residual  3.4909676901736148e-04
    Sx[3,6]   product_mass_3  1
    Sx[3,6]   product_lx_3_6  1
    Sx[3,6]   product_ux_3_6  1
    Sx[3,6]   product_Su_3_6  1
    Sx[3,6]   product_Sl_3_6  1
    Sx[3,6]   total_product_lower  6
    Sx[3,6]   total_product_upper  6
    Sx[3,6]   conditional_Sx_lower_3_6  1
    Sx[3,6]   conditional_Sx_upper_3_6  1
    Sx[3,6]   conditional_complement_lower_3_6  -1
    Sx[3,6]   conditional_complement_upper_3_6  -1
    Sx[3,6]   hard_cost_W_definition  5.2364515352604224e-04
    Sx[3,6]   floor_residual  5.2364515352604224e-04
    Sx[3,6]   G_residual  5.2364515352604224e-04
    Sx[3,7]   product_mass_3  1
    Sx[3,7]   product_lx_3_7  1
    Sx[3,7]   product_ux_3_7  1
    Sx[3,7]   product_Su_3_7  1
    Sx[3,7]   product_Sl_3_7  1
    Sx[3,7]   total_product_lower  7
    Sx[3,7]   total_product_upper  7
    Sx[3,7]   conditional_Sx_lower_3_7  1
    Sx[3,7]   conditional_Sx_upper_3_7  1
    Sx[3,7]   conditional_complement_lower_3_7  -1
    Sx[3,7]   conditional_complement_upper_3_7  -1
    Sx[3,7]   hard_cost_W_definition  3.4909676901736164e-04
    Sx[3,7]   floor_residual  3.4909676901736164e-04
    Sx[3,7]   G_residual  3.4909676901736164e-04
    Sx[3,8]   product_mass_3  1
    Sx[3,8]   product_lx_3_8  1
    Sx[3,8]   product_ux_3_8  1
    Sx[3,8]   product_Su_3_8  1
    Sx[3,8]   product_Sl_3_8  1
    Sx[3,8]   total_product_lower  8
    Sx[3,8]   total_product_upper  8
    Sx[3,8]   conditional_Sx_lower_3_8  1
    Sx[3,8]   conditional_Sx_upper_3_8  1
    Sx[3,8]   conditional_complement_lower_3_8  -1
    Sx[3,8]   conditional_complement_upper_3_8  -1
    Sx[3,8]   hard_cost_W_definition  1.7454838450868087e-04
    Sx[3,8]   floor_residual  1.7454838450868087e-04
    Sx[3,8]   G_residual  1.7454838450868087e-04
    Sx[3,9]   product_mass_3  1
    Sx[3,9]   product_lx_3_9  1
    Sx[3,9]   product_ux_3_9  1
    Sx[3,9]   product_Su_3_9  1
    Sx[3,9]   product_Sl_3_9  1
    Sx[3,9]   total_product_lower  9
    Sx[3,9]   total_product_upper  9
    Sx[3,9]   conditional_Sx_lower_3_9  1
    Sx[3,9]   conditional_Sx_upper_3_9  1
    Sx[3,9]   conditional_complement_lower_3_9  -1
    Sx[3,9]   conditional_complement_upper_3_9  -1
    Sx[3,10]  product_mass_3  1
    Sx[3,10]  product_lx_3_10  1
    Sx[3,10]  product_ux_3_10  1
    Sx[3,10]  product_Su_3_10  1
    Sx[3,10]  product_Sl_3_10  1
    Sx[3,10]  total_product_lower  10
    Sx[3,10]  total_product_upper  10
    Sx[3,10]  conditional_Sx_lower_3_10  1
    Sx[3,10]  conditional_Sx_upper_3_10  1
    Sx[3,10]  conditional_complement_lower_3_10  -1
    Sx[3,10]  conditional_complement_upper_3_10  -1
    Sx[3,10]  hard_cost_W_definition  -1.7454838450868060e-04
    Sx[3,10]  floor_residual  -1.7454838450868060e-04
    Sx[3,10]  G_residual  -1.7454838450868060e-04
    Sx[3,11]  product_mass_3  1
    Sx[3,11]  product_lx_3_11  1
    Sx[3,11]  product_ux_3_11  1
    Sx[3,11]  product_Su_3_11  1
    Sx[3,11]  product_Sl_3_11  1
    Sx[3,11]  total_product_lower  11
    Sx[3,11]  total_product_upper  11
    Sx[3,11]  conditional_Sx_lower_3_11  1
    Sx[3,11]  conditional_Sx_upper_3_11  1
    Sx[3,11]  conditional_complement_lower_3_11  -1
    Sx[3,11]  conditional_complement_upper_3_11  -1
    Sx[3,11]  hard_cost_W_definition  -3.4909676901736131e-04
    Sx[3,11]  floor_residual  -3.4909676901736131e-04
    Sx[3,11]  G_residual  -3.4909676901736131e-04
    Sx[3,12]  product_mass_3  1
    Sx[3,12]  product_lx_3_12  1
    Sx[3,12]  product_ux_3_12  1
    Sx[3,12]  product_Su_3_12  1
    Sx[3,12]  product_Sl_3_12  1
    Sx[3,12]  total_product_lower  12
    Sx[3,12]  total_product_upper  12
    Sx[3,12]  conditional_Sx_lower_3_12  1
    Sx[3,12]  conditional_Sx_upper_3_12  1
    Sx[3,12]  conditional_complement_lower_3_12  -1
    Sx[3,12]  conditional_complement_upper_3_12  -1
    Sx[3,12]  hard_cost_W_definition  -0.000523645153526042
    Sx[3,12]  floor_residual  -0.000523645153526042
    Sx[3,12]  G_residual  -0.000523645153526042
    Sx[4,0]   product_mass_4  1
    Sx[4,0]   product_lx_4_0  1
    Sx[4,0]   product_ux_4_0  1
    Sx[4,0]   product_Su_4_0  1
    Sx[4,0]   product_Sl_4_0  1
    Sx[4,0]   conditional_Sx_lower_4_0  1
    Sx[4,0]   conditional_Sx_upper_4_0  1
    Sx[4,0]   conditional_complement_lower_4_0  -1
    Sx[4,0]   conditional_complement_upper_4_0  -1
    Sx[4,0]   hard_cost_W_definition  -6.1091968240974646e-04
    Sx[4,0]   floor_residual  -6.1091968240974646e-04
    Sx[4,0]   G_residual  -6.1091968240974646e-04
    Sx[4,1]   product_mass_4  1
    Sx[4,1]   product_lx_4_1  1
    Sx[4,1]   product_ux_4_1  1
    Sx[4,1]   product_Su_4_1  1
    Sx[4,1]   product_Sl_4_1  1
    Sx[4,1]   total_product_lower  1
    Sx[4,1]   total_product_upper  1
    Sx[4,1]   conditional_Sx_lower_4_1  1
    Sx[4,1]   conditional_Sx_upper_4_1  1
    Sx[4,1]   conditional_complement_lower_4_1  -1
    Sx[4,1]   conditional_complement_upper_4_1  -1
    Sx[4,1]   hard_cost_W_definition  -4.0727978827316433e-04
    Sx[4,1]   floor_residual  -4.0727978827316433e-04
    Sx[4,1]   G_residual  -4.0727978827316433e-04
    Sx[4,2]   product_mass_4  1
    Sx[4,2]   product_lx_4_2  1
    Sx[4,2]   product_ux_4_2  1
    Sx[4,2]   product_Su_4_2  1
    Sx[4,2]   product_Sl_4_2  1
    Sx[4,2]   total_product_lower  2
    Sx[4,2]   total_product_upper  2
    Sx[4,2]   conditional_Sx_lower_4_2  1
    Sx[4,2]   conditional_Sx_upper_4_2  1
    Sx[4,2]   conditional_complement_lower_4_2  -1
    Sx[4,2]   conditional_complement_upper_4_2  -1
    Sx[4,2]   hard_cost_W_definition  -2.0363989413658219e-04
    Sx[4,2]   floor_residual  -2.0363989413658219e-04
    Sx[4,2]   G_residual  -2.0363989413658219e-04
    Sx[4,3]   product_mass_4  1
    Sx[4,3]   product_lx_4_3  1
    Sx[4,3]   product_ux_4_3  1
    Sx[4,3]   product_Su_4_3  1
    Sx[4,3]   product_Sl_4_3  1
    Sx[4,3]   total_product_lower  3
    Sx[4,3]   total_product_upper  3
    Sx[4,3]   conditional_Sx_lower_4_3  1
    Sx[4,3]   conditional_Sx_upper_4_3  1
    Sx[4,3]   conditional_complement_lower_4_3  -1
    Sx[4,3]   conditional_complement_upper_4_3  -1
    Sx[4,4]   product_mass_4  1
    Sx[4,4]   product_lx_4_4  1
    Sx[4,4]   product_ux_4_4  1
    Sx[4,4]   product_Su_4_4  1
    Sx[4,4]   product_Sl_4_4  1
    Sx[4,4]   total_product_lower  4
    Sx[4,4]   total_product_upper  4
    Sx[4,4]   conditional_Sx_lower_4_4  1
    Sx[4,4]   conditional_Sx_upper_4_4  1
    Sx[4,4]   conditional_complement_lower_4_4  -1
    Sx[4,4]   conditional_complement_upper_4_4  -1
    Sx[4,4]   hard_cost_W_definition  2.0363989413658206e-04
    Sx[4,4]   floor_residual  2.0363989413658206e-04
    Sx[4,4]   G_residual  2.0363989413658206e-04
    Sx[4,5]   product_mass_4  1
    Sx[4,5]   product_lx_4_5  1
    Sx[4,5]   product_ux_4_5  1
    Sx[4,5]   product_Su_4_5  1
    Sx[4,5]   product_Sl_4_5  1
    Sx[4,5]   total_product_lower  5
    Sx[4,5]   total_product_upper  5
    Sx[4,5]   conditional_Sx_lower_4_5  1
    Sx[4,5]   conditional_Sx_upper_4_5  1
    Sx[4,5]   conditional_complement_lower_4_5  -1
    Sx[4,5]   conditional_complement_upper_4_5  -1
    Sx[4,5]   hard_cost_W_definition  4.0727978827316422e-04
    Sx[4,5]   floor_residual  4.0727978827316422e-04
    Sx[4,5]   G_residual  4.0727978827316422e-04
    Sx[4,6]   product_mass_4  1
    Sx[4,6]   product_lx_4_6  1
    Sx[4,6]   product_ux_4_6  1
    Sx[4,6]   product_Su_4_6  1
    Sx[4,6]   product_Sl_4_6  1
    Sx[4,6]   total_product_lower  6
    Sx[4,6]   total_product_upper  6
    Sx[4,6]   conditional_Sx_lower_4_6  1
    Sx[4,6]   conditional_Sx_upper_4_6  1
    Sx[4,6]   conditional_complement_lower_4_6  -1
    Sx[4,6]   conditional_complement_upper_4_6  -1
    Sx[4,6]   hard_cost_W_definition  6.1091968240974636e-04
    Sx[4,6]   floor_residual  6.1091968240974636e-04
    Sx[4,6]   G_residual  6.1091968240974636e-04
    Sx[4,7]   product_mass_4  1
    Sx[4,7]   product_lx_4_7  1
    Sx[4,7]   product_ux_4_7  1
    Sx[4,7]   product_Su_4_7  1
    Sx[4,7]   product_Sl_4_7  1
    Sx[4,7]   total_product_lower  7
    Sx[4,7]   total_product_upper  7
    Sx[4,7]   conditional_Sx_lower_4_7  1
    Sx[4,7]   conditional_Sx_upper_4_7  1
    Sx[4,7]   conditional_complement_lower_4_7  -1
    Sx[4,7]   conditional_complement_upper_4_7  -1
    Sx[4,7]   hard_cost_W_definition  8.1455957654632855e-04
    Sx[4,7]   floor_residual  8.1455957654632855e-04
    Sx[4,7]   G_residual  8.1455957654632855e-04
    Sx[4,8]   product_mass_4  1
    Sx[4,8]   product_lx_4_8  1
    Sx[4,8]   product_ux_4_8  1
    Sx[4,8]   product_Su_4_8  1
    Sx[4,8]   product_Sl_4_8  1
    Sx[4,8]   total_product_lower  8
    Sx[4,8]   total_product_upper  8
    Sx[4,8]   conditional_Sx_lower_4_8  1
    Sx[4,8]   conditional_Sx_upper_4_8  1
    Sx[4,8]   conditional_complement_lower_4_8  -1
    Sx[4,8]   conditional_complement_upper_4_8  -1
    Sx[4,8]   hard_cost_W_definition  6.1091968240974657e-04
    Sx[4,8]   floor_residual  6.1091968240974657e-04
    Sx[4,8]   G_residual  6.1091968240974657e-04
    Sx[4,9]   product_mass_4  1
    Sx[4,9]   product_lx_4_9  1
    Sx[4,9]   product_ux_4_9  1
    Sx[4,9]   product_Su_4_9  1
    Sx[4,9]   product_Sl_4_9  1
    Sx[4,9]   total_product_lower  9
    Sx[4,9]   total_product_upper  9
    Sx[4,9]   conditional_Sx_lower_4_9  1
    Sx[4,9]   conditional_Sx_upper_4_9  1
    Sx[4,9]   conditional_complement_lower_4_9  -1
    Sx[4,9]   conditional_complement_upper_4_9  -1
    Sx[4,9]   hard_cost_W_definition  4.0727978827316438e-04
    Sx[4,9]   floor_residual  4.0727978827316438e-04
    Sx[4,9]   G_residual  4.0727978827316438e-04
    Sx[4,10]  product_mass_4  1
    Sx[4,10]  product_lx_4_10  1
    Sx[4,10]  product_ux_4_10  1
    Sx[4,10]  product_Su_4_10  1
    Sx[4,10]  product_Sl_4_10  1
    Sx[4,10]  total_product_lower  10
    Sx[4,10]  total_product_upper  10
    Sx[4,10]  conditional_Sx_lower_4_10  1
    Sx[4,10]  conditional_Sx_upper_4_10  1
    Sx[4,10]  conditional_complement_lower_4_10  -1
    Sx[4,10]  conditional_complement_upper_4_10  -1
    Sx[4,10]  hard_cost_W_definition  2.0363989413658222e-04
    Sx[4,10]  floor_residual  2.0363989413658222e-04
    Sx[4,10]  G_residual  2.0363989413658222e-04
    Sx[4,11]  product_mass_4  1
    Sx[4,11]  product_lx_4_11  1
    Sx[4,11]  product_ux_4_11  1
    Sx[4,11]  product_Su_4_11  1
    Sx[4,11]  product_Sl_4_11  1
    Sx[4,11]  total_product_lower  11
    Sx[4,11]  total_product_upper  11
    Sx[4,11]  conditional_Sx_lower_4_11  1
    Sx[4,11]  conditional_Sx_upper_4_11  1
    Sx[4,11]  conditional_complement_lower_4_11  -1
    Sx[4,11]  conditional_complement_upper_4_11  -1
    Sx[4,12]  product_mass_4  1
    Sx[4,12]  product_lx_4_12  1
    Sx[4,12]  product_ux_4_12  1
    Sx[4,12]  product_Su_4_12  1
    Sx[4,12]  product_Sl_4_12  1
    Sx[4,12]  total_product_lower  12
    Sx[4,12]  total_product_upper  12
    Sx[4,12]  conditional_Sx_lower_4_12  1
    Sx[4,12]  conditional_Sx_upper_4_12  1
    Sx[4,12]  conditional_complement_lower_4_12  -1
    Sx[4,12]  conditional_complement_upper_4_12  -1
    Sx[4,12]  hard_cost_W_definition  -2.0363989413658203e-04
    Sx[4,12]  floor_residual  -2.0363989413658203e-04
    Sx[4,12]  G_residual  -2.0363989413658203e-04
    Sx[4,13]  product_mass_4  1
    Sx[4,13]  product_lx_4_13  1
    Sx[4,13]  product_ux_4_13  1
    Sx[4,13]  product_Su_4_13  1
    Sx[4,13]  product_Sl_4_13  1
    Sx[4,13]  total_product_lower  13
    Sx[4,13]  total_product_upper  13
    Sx[4,13]  conditional_Sx_lower_4_13  1
    Sx[4,13]  conditional_Sx_upper_4_13  1
    Sx[4,13]  conditional_complement_lower_4_13  -1
    Sx[4,13]  conditional_complement_upper_4_13  -1
    Sx[4,13]  hard_cost_W_definition  -4.0727978827316417e-04
    Sx[4,13]  floor_residual  -4.0727978827316417e-04
    Sx[4,13]  G_residual  -4.0727978827316417e-04
    Sx[4,14]  product_mass_4  1
    Sx[4,14]  product_lx_4_14  1
    Sx[4,14]  product_ux_4_14  1
    Sx[4,14]  product_Su_4_14  1
    Sx[4,14]  product_Sl_4_14  1
    Sx[4,14]  total_product_lower  14
    Sx[4,14]  total_product_upper  14
    Sx[4,14]  conditional_Sx_lower_4_14  1
    Sx[4,14]  conditional_Sx_upper_4_14  1
    Sx[4,14]  conditional_complement_lower_4_14  -1
    Sx[4,14]  conditional_complement_upper_4_14  -1
    Sx[4,14]  hard_cost_W_definition  -6.1091968240974625e-04
    Sx[4,14]  floor_residual  -6.1091968240974625e-04
    Sx[4,14]  G_residual  -6.1091968240974625e-04
    Sx[4,15]  product_mass_4  1
    Sx[4,15]  product_lx_4_15  1
    Sx[4,15]  product_ux_4_15  1
    Sx[4,15]  product_Su_4_15  1
    Sx[4,15]  product_Sl_4_15  1
    Sx[4,15]  total_product_lower  15
    Sx[4,15]  total_product_upper  15
    Sx[4,15]  conditional_Sx_lower_4_15  1
    Sx[4,15]  conditional_Sx_upper_4_15  1
    Sx[4,15]  conditional_complement_lower_4_15  -1
    Sx[4,15]  conditional_complement_upper_4_15  -1
    Sx[4,15]  hard_cost_W_definition  -8.1455957654632844e-04
    Sx[4,15]  floor_residual  -8.1455957654632844e-04
    Sx[4,15]  G_residual  -8.1455957654632844e-04
    Sx[5,0]   product_mass_5  1
    Sx[5,0]   product_lx_5_0  1
    Sx[5,0]   product_ux_5_0  1
    Sx[5,0]   product_Su_5_0  1
    Sx[5,0]   product_Sl_5_0  1
    Sx[5,0]   conditional_Sx_lower_5_0  1
    Sx[5,0]   conditional_Sx_upper_5_0  1
    Sx[5,0]   conditional_complement_lower_5_0  -1
    Sx[5,0]   conditional_complement_upper_5_0  -1
    Sx[5,0]   hard_cost_W_definition  -6.1091968240974646e-04
    Sx[5,0]   floor_residual  -6.1091968240974646e-04
    Sx[5,0]   G_residual  -6.1091968240974646e-04
    Sx[5,1]   product_mass_5  1
    Sx[5,1]   product_lx_5_1  1
    Sx[5,1]   product_ux_5_1  1
    Sx[5,1]   product_Su_5_1  1
    Sx[5,1]   product_Sl_5_1  1
    Sx[5,1]   total_product_lower  1
    Sx[5,1]   total_product_upper  1
    Sx[5,1]   conditional_Sx_lower_5_1  1
    Sx[5,1]   conditional_Sx_upper_5_1  1
    Sx[5,1]   conditional_complement_lower_5_1  -1
    Sx[5,1]   conditional_complement_upper_5_1  -1
    Sx[5,1]   hard_cost_W_definition  -4.0727978827316433e-04
    Sx[5,1]   floor_residual  -4.0727978827316433e-04
    Sx[5,1]   G_residual  -4.0727978827316433e-04
    Sx[5,2]   product_mass_5  1
    Sx[5,2]   product_lx_5_2  1
    Sx[5,2]   product_ux_5_2  1
    Sx[5,2]   product_Su_5_2  1
    Sx[5,2]   product_Sl_5_2  1
    Sx[5,2]   total_product_lower  2
    Sx[5,2]   total_product_upper  2
    Sx[5,2]   conditional_Sx_lower_5_2  1
    Sx[5,2]   conditional_Sx_upper_5_2  1
    Sx[5,2]   conditional_complement_lower_5_2  -1
    Sx[5,2]   conditional_complement_upper_5_2  -1
    Sx[5,2]   hard_cost_W_definition  -2.0363989413658219e-04
    Sx[5,2]   floor_residual  -2.0363989413658219e-04
    Sx[5,2]   G_residual  -2.0363989413658219e-04
    Sx[5,3]   product_mass_5  1
    Sx[5,3]   product_lx_5_3  1
    Sx[5,3]   product_ux_5_3  1
    Sx[5,3]   product_Su_5_3  1
    Sx[5,3]   product_Sl_5_3  1
    Sx[5,3]   total_product_lower  3
    Sx[5,3]   total_product_upper  3
    Sx[5,3]   conditional_Sx_lower_5_3  1
    Sx[5,3]   conditional_Sx_upper_5_3  1
    Sx[5,3]   conditional_complement_lower_5_3  -1
    Sx[5,3]   conditional_complement_upper_5_3  -1
    Sx[5,4]   product_mass_5  1
    Sx[5,4]   product_lx_5_4  1
    Sx[5,4]   product_ux_5_4  1
    Sx[5,4]   product_Su_5_4  1
    Sx[5,4]   product_Sl_5_4  1
    Sx[5,4]   total_product_lower  4
    Sx[5,4]   total_product_upper  4
    Sx[5,4]   conditional_Sx_lower_5_4  1
    Sx[5,4]   conditional_Sx_upper_5_4  1
    Sx[5,4]   conditional_complement_lower_5_4  -1
    Sx[5,4]   conditional_complement_upper_5_4  -1
    Sx[5,4]   hard_cost_W_definition  2.0363989413658206e-04
    Sx[5,4]   floor_residual  2.0363989413658206e-04
    Sx[5,4]   G_residual  2.0363989413658206e-04
    Sx[5,5]   product_mass_5  1
    Sx[5,5]   product_lx_5_5  1
    Sx[5,5]   product_ux_5_5  1
    Sx[5,5]   product_Su_5_5  1
    Sx[5,5]   product_Sl_5_5  1
    Sx[5,5]   total_product_lower  5
    Sx[5,5]   total_product_upper  5
    Sx[5,5]   conditional_Sx_lower_5_5  1
    Sx[5,5]   conditional_Sx_upper_5_5  1
    Sx[5,5]   conditional_complement_lower_5_5  -1
    Sx[5,5]   conditional_complement_upper_5_5  -1
    Sx[5,5]   hard_cost_W_definition  4.0727978827316422e-04
    Sx[5,5]   floor_residual  4.0727978827316422e-04
    Sx[5,5]   G_residual  4.0727978827316422e-04
    Sx[5,6]   product_mass_5  1
    Sx[5,6]   product_lx_5_6  1
    Sx[5,6]   product_ux_5_6  1
    Sx[5,6]   product_Su_5_6  1
    Sx[5,6]   product_Sl_5_6  1
    Sx[5,6]   total_product_lower  6
    Sx[5,6]   total_product_upper  6
    Sx[5,6]   conditional_Sx_lower_5_6  1
    Sx[5,6]   conditional_Sx_upper_5_6  1
    Sx[5,6]   conditional_complement_lower_5_6  -1
    Sx[5,6]   conditional_complement_upper_5_6  -1
    Sx[5,6]   hard_cost_W_definition  6.1091968240974636e-04
    Sx[5,6]   floor_residual  6.1091968240974636e-04
    Sx[5,6]   G_residual  6.1091968240974636e-04
    Sx[5,7]   product_mass_5  1
    Sx[5,7]   product_lx_5_7  1
    Sx[5,7]   product_ux_5_7  1
    Sx[5,7]   product_Su_5_7  1
    Sx[5,7]   product_Sl_5_7  1
    Sx[5,7]   total_product_lower  7
    Sx[5,7]   total_product_upper  7
    Sx[5,7]   conditional_Sx_lower_5_7  1
    Sx[5,7]   conditional_Sx_upper_5_7  1
    Sx[5,7]   conditional_complement_lower_5_7  -1
    Sx[5,7]   conditional_complement_upper_5_7  -1
    Sx[5,7]   hard_cost_W_definition  8.1455957654632855e-04
    Sx[5,7]   floor_residual  8.1455957654632855e-04
    Sx[5,7]   G_residual  8.1455957654632855e-04
    Sx[5,8]   product_mass_5  1
    Sx[5,8]   product_lx_5_8  1
    Sx[5,8]   product_ux_5_8  1
    Sx[5,8]   product_Su_5_8  1
    Sx[5,8]   product_Sl_5_8  1
    Sx[5,8]   total_product_lower  8
    Sx[5,8]   total_product_upper  8
    Sx[5,8]   conditional_Sx_lower_5_8  1
    Sx[5,8]   conditional_Sx_upper_5_8  1
    Sx[5,8]   conditional_complement_lower_5_8  -1
    Sx[5,8]   conditional_complement_upper_5_8  -1
    Sx[5,8]   hard_cost_W_definition  6.1091968240974657e-04
    Sx[5,8]   floor_residual  6.1091968240974657e-04
    Sx[5,8]   G_residual  6.1091968240974657e-04
    Sx[5,9]   product_mass_5  1
    Sx[5,9]   product_lx_5_9  1
    Sx[5,9]   product_ux_5_9  1
    Sx[5,9]   product_Su_5_9  1
    Sx[5,9]   product_Sl_5_9  1
    Sx[5,9]   total_product_lower  9
    Sx[5,9]   total_product_upper  9
    Sx[5,9]   conditional_Sx_lower_5_9  1
    Sx[5,9]   conditional_Sx_upper_5_9  1
    Sx[5,9]   conditional_complement_lower_5_9  -1
    Sx[5,9]   conditional_complement_upper_5_9  -1
    Sx[5,9]   hard_cost_W_definition  4.0727978827316438e-04
    Sx[5,9]   floor_residual  4.0727978827316438e-04
    Sx[5,9]   G_residual  4.0727978827316438e-04
    Sx[5,10]  product_mass_5  1
    Sx[5,10]  product_lx_5_10  1
    Sx[5,10]  product_ux_5_10  1
    Sx[5,10]  product_Su_5_10  1
    Sx[5,10]  product_Sl_5_10  1
    Sx[5,10]  total_product_lower  10
    Sx[5,10]  total_product_upper  10
    Sx[5,10]  conditional_Sx_lower_5_10  1
    Sx[5,10]  conditional_Sx_upper_5_10  1
    Sx[5,10]  conditional_complement_lower_5_10  -1
    Sx[5,10]  conditional_complement_upper_5_10  -1
    Sx[5,10]  hard_cost_W_definition  2.0363989413658222e-04
    Sx[5,10]  floor_residual  2.0363989413658222e-04
    Sx[5,10]  G_residual  2.0363989413658222e-04
    Sx[5,11]  product_mass_5  1
    Sx[5,11]  product_lx_5_11  1
    Sx[5,11]  product_ux_5_11  1
    Sx[5,11]  product_Su_5_11  1
    Sx[5,11]  product_Sl_5_11  1
    Sx[5,11]  total_product_lower  11
    Sx[5,11]  total_product_upper  11
    Sx[5,11]  conditional_Sx_lower_5_11  1
    Sx[5,11]  conditional_Sx_upper_5_11  1
    Sx[5,11]  conditional_complement_lower_5_11  -1
    Sx[5,11]  conditional_complement_upper_5_11  -1
    Sx[5,12]  product_mass_5  1
    Sx[5,12]  product_lx_5_12  1
    Sx[5,12]  product_ux_5_12  1
    Sx[5,12]  product_Su_5_12  1
    Sx[5,12]  product_Sl_5_12  1
    Sx[5,12]  total_product_lower  12
    Sx[5,12]  total_product_upper  12
    Sx[5,12]  conditional_Sx_lower_5_12  1
    Sx[5,12]  conditional_Sx_upper_5_12  1
    Sx[5,12]  conditional_complement_lower_5_12  -1
    Sx[5,12]  conditional_complement_upper_5_12  -1
    Sx[5,12]  hard_cost_W_definition  -2.0363989413658203e-04
    Sx[5,12]  floor_residual  -2.0363989413658203e-04
    Sx[5,12]  G_residual  -2.0363989413658203e-04
    Sx[5,13]  product_mass_5  1
    Sx[5,13]  product_lx_5_13  1
    Sx[5,13]  product_ux_5_13  1
    Sx[5,13]  product_Su_5_13  1
    Sx[5,13]  product_Sl_5_13  1
    Sx[5,13]  total_product_lower  13
    Sx[5,13]  total_product_upper  13
    Sx[5,13]  conditional_Sx_lower_5_13  1
    Sx[5,13]  conditional_Sx_upper_5_13  1
    Sx[5,13]  conditional_complement_lower_5_13  -1
    Sx[5,13]  conditional_complement_upper_5_13  -1
    Sx[5,13]  hard_cost_W_definition  -4.0727978827316417e-04
    Sx[5,13]  floor_residual  -4.0727978827316417e-04
    Sx[5,13]  G_residual  -4.0727978827316417e-04
    Sx[5,14]  product_mass_5  1
    Sx[5,14]  product_lx_5_14  1
    Sx[5,14]  product_ux_5_14  1
    Sx[5,14]  product_Su_5_14  1
    Sx[5,14]  product_Sl_5_14  1
    Sx[5,14]  total_product_lower  14
    Sx[5,14]  total_product_upper  14
    Sx[5,14]  conditional_Sx_lower_5_14  1
    Sx[5,14]  conditional_Sx_upper_5_14  1
    Sx[5,14]  conditional_complement_lower_5_14  -1
    Sx[5,14]  conditional_complement_upper_5_14  -1
    Sx[5,14]  hard_cost_W_definition  -6.1091968240974625e-04
    Sx[5,14]  floor_residual  -6.1091968240974625e-04
    Sx[5,14]  G_residual  -6.1091968240974625e-04
    Sx[5,15]  product_mass_5  1
    Sx[5,15]  product_lx_5_15  1
    Sx[5,15]  product_ux_5_15  1
    Sx[5,15]  product_Su_5_15  1
    Sx[5,15]  product_Sl_5_15  1
    Sx[5,15]  total_product_lower  15
    Sx[5,15]  total_product_upper  15
    Sx[5,15]  conditional_Sx_lower_5_15  1
    Sx[5,15]  conditional_Sx_upper_5_15  1
    Sx[5,15]  conditional_complement_lower_5_15  -1
    Sx[5,15]  conditional_complement_upper_5_15  -1
    Sx[5,15]  hard_cost_W_definition  -8.1455957654632844e-04
    Sx[5,15]  floor_residual  -8.1455957654632844e-04
    Sx[5,15]  G_residual  -8.1455957654632844e-04
    Sx[6,0]   product_mass_6  1
    Sx[6,0]   product_lx_6_0  1
    Sx[6,0]   product_ux_6_0  1
    Sx[6,0]   product_Su_6_0  1
    Sx[6,0]   product_Sl_6_0  1
    Sx[6,0]   conditional_Sx_lower_6_0  1
    Sx[6,0]   conditional_Sx_upper_6_0  1
    Sx[6,0]   conditional_complement_lower_6_0  -1
    Sx[6,0]   conditional_complement_upper_6_0  -1
    Sx[6,0]   hard_cost_W_definition  -2.3273157207916555e-04
    Sx[6,0]   floor_residual  -2.3273157207916555e-04
    Sx[6,0]   G_residual  -2.3273157207916555e-04
    Sx[6,1]   product_mass_6  1
    Sx[6,1]   product_lx_6_1  1
    Sx[6,1]   product_ux_6_1  1
    Sx[6,1]   product_Su_6_1  1
    Sx[6,1]   product_Sl_6_1  1
    Sx[6,1]   total_product_lower  1
    Sx[6,1]   total_product_upper  1
    Sx[6,1]   conditional_Sx_lower_6_1  1
    Sx[6,1]   conditional_Sx_upper_6_1  1
    Sx[6,1]   conditional_complement_lower_6_1  -1
    Sx[6,1]   conditional_complement_upper_6_1  -1
    Sx[6,1]   hard_cost_W_definition  -1.1636578603958278e-04
    Sx[6,1]   floor_residual  -1.1636578603958278e-04
    Sx[6,1]   G_residual  -1.1636578603958278e-04
    Sx[6,2]   product_mass_6  1
    Sx[6,2]   product_lx_6_2  1
    Sx[6,2]   product_ux_6_2  1
    Sx[6,2]   product_Su_6_2  1
    Sx[6,2]   product_Sl_6_2  1
    Sx[6,2]   total_product_lower  2
    Sx[6,2]   total_product_upper  2
    Sx[6,2]   conditional_Sx_lower_6_2  1
    Sx[6,2]   conditional_Sx_upper_6_2  1
    Sx[6,2]   conditional_complement_lower_6_2  -1
    Sx[6,2]   conditional_complement_upper_6_2  -1
    Sx[6,3]   product_mass_6  1
    Sx[6,3]   product_lx_6_3  1
    Sx[6,3]   product_ux_6_3  1
    Sx[6,3]   product_Su_6_3  1
    Sx[6,3]   product_Sl_6_3  1
    Sx[6,3]   total_product_lower  3
    Sx[6,3]   total_product_upper  3
    Sx[6,3]   conditional_Sx_lower_6_3  1
    Sx[6,3]   conditional_Sx_upper_6_3  1
    Sx[6,3]   conditional_complement_lower_6_3  -1
    Sx[6,3]   conditional_complement_upper_6_3  -1
    Sx[6,3]   hard_cost_W_definition  1.1636578603958278e-04
    Sx[6,3]   floor_residual  1.1636578603958278e-04
    Sx[6,3]   G_residual  1.1636578603958278e-04
    Sx[6,4]   product_mass_6  1
    Sx[6,4]   product_lx_6_4  1
    Sx[6,4]   product_ux_6_4  1
    Sx[6,4]   product_Su_6_4  1
    Sx[6,4]   product_Sl_6_4  1
    Sx[6,4]   total_product_lower  4
    Sx[6,4]   total_product_upper  4
    Sx[6,4]   conditional_Sx_lower_6_4  1
    Sx[6,4]   conditional_Sx_upper_6_4  1
    Sx[6,4]   conditional_complement_lower_6_4  -1
    Sx[6,4]   conditional_complement_upper_6_4  -1
    Sx[6,4]   hard_cost_W_definition  2.3273157207916555e-04
    Sx[6,4]   floor_residual  2.3273157207916555e-04
    Sx[6,4]   G_residual  2.3273157207916555e-04
    Sx[6,5]   product_mass_6  1
    Sx[6,5]   product_lx_6_5  1
    Sx[6,5]   product_ux_6_5  1
    Sx[6,5]   product_Su_6_5  1
    Sx[6,5]   product_Sl_6_5  1
    Sx[6,5]   total_product_lower  5
    Sx[6,5]   total_product_upper  5
    Sx[6,5]   conditional_Sx_lower_6_5  1
    Sx[6,5]   conditional_Sx_upper_6_5  1
    Sx[6,5]   conditional_complement_lower_6_5  -1
    Sx[6,5]   conditional_complement_upper_6_5  -1
    Sx[6,5]   hard_cost_W_definition  1.1636578603958278e-04
    Sx[6,5]   floor_residual  1.1636578603958278e-04
    Sx[6,5]   G_residual  1.1636578603958278e-04
    Sx[6,6]   product_mass_6  1
    Sx[6,6]   product_lx_6_6  1
    Sx[6,6]   product_ux_6_6  1
    Sx[6,6]   product_Su_6_6  1
    Sx[6,6]   product_Sl_6_6  1
    Sx[6,6]   total_product_lower  6
    Sx[6,6]   total_product_upper  6
    Sx[6,6]   conditional_Sx_lower_6_6  1
    Sx[6,6]   conditional_Sx_upper_6_6  1
    Sx[6,6]   conditional_complement_lower_6_6  -1
    Sx[6,6]   conditional_complement_upper_6_6  -1
    Sx[6,7]   product_mass_6  1
    Sx[6,7]   product_lx_6_7  1
    Sx[6,7]   product_ux_6_7  1
    Sx[6,7]   product_Su_6_7  1
    Sx[6,7]   product_Sl_6_7  1
    Sx[6,7]   total_product_lower  7
    Sx[6,7]   total_product_upper  7
    Sx[6,7]   conditional_Sx_lower_6_7  1
    Sx[6,7]   conditional_Sx_upper_6_7  1
    Sx[6,7]   conditional_complement_lower_6_7  -1
    Sx[6,7]   conditional_complement_upper_6_7  -1
    Sx[6,7]   hard_cost_W_definition  -1.1636578603958278e-04
    Sx[6,7]   floor_residual  -1.1636578603958278e-04
    Sx[6,7]   G_residual  -1.1636578603958278e-04
    Sx[6,8]   product_mass_6  1
    Sx[6,8]   product_lx_6_8  1
    Sx[6,8]   product_ux_6_8  1
    Sx[6,8]   product_Su_6_8  1
    Sx[6,8]   product_Sl_6_8  1
    Sx[6,8]   total_product_lower  8
    Sx[6,8]   total_product_upper  8
    Sx[6,8]   conditional_Sx_lower_6_8  1
    Sx[6,8]   conditional_Sx_upper_6_8  1
    Sx[6,8]   conditional_complement_lower_6_8  -1
    Sx[6,8]   conditional_complement_upper_6_8  -1
    Sx[6,8]   hard_cost_W_definition  -2.3273157207916555e-04
    Sx[6,8]   floor_residual  -2.3273157207916555e-04
    Sx[6,8]   G_residual  -2.3273157207916555e-04
    Sx[7,0]   product_mass_7  1
    Sx[7,0]   product_lx_7_0  1
    Sx[7,0]   product_ux_7_0  1
    Sx[7,0]   product_Su_7_0  1
    Sx[7,0]   product_Sl_7_0  1
    Sx[7,0]   conditional_Sx_lower_7_0  1
    Sx[7,0]   conditional_Sx_upper_7_0  1
    Sx[7,0]   conditional_complement_lower_7_0  -1
    Sx[7,0]   conditional_complement_upper_7_0  -1
    Sx[7,0]   hard_cost_W_definition  -6.1091968240974646e-04
    Sx[7,0]   floor_residual  -6.1091968240974646e-04
    Sx[7,0]   G_residual  -6.1091968240974646e-04
    Sx[7,1]   product_mass_7  1
    Sx[7,1]   product_lx_7_1  1
    Sx[7,1]   product_ux_7_1  1
    Sx[7,1]   product_Su_7_1  1
    Sx[7,1]   product_Sl_7_1  1
    Sx[7,1]   total_product_lower  1
    Sx[7,1]   total_product_upper  1
    Sx[7,1]   conditional_Sx_lower_7_1  1
    Sx[7,1]   conditional_Sx_upper_7_1  1
    Sx[7,1]   conditional_complement_lower_7_1  -1
    Sx[7,1]   conditional_complement_upper_7_1  -1
    Sx[7,1]   hard_cost_W_definition  -4.0727978827316433e-04
    Sx[7,1]   floor_residual  -4.0727978827316433e-04
    Sx[7,1]   G_residual  -4.0727978827316433e-04
    Sx[7,2]   product_mass_7  1
    Sx[7,2]   product_lx_7_2  1
    Sx[7,2]   product_ux_7_2  1
    Sx[7,2]   product_Su_7_2  1
    Sx[7,2]   product_Sl_7_2  1
    Sx[7,2]   total_product_lower  2
    Sx[7,2]   total_product_upper  2
    Sx[7,2]   conditional_Sx_lower_7_2  1
    Sx[7,2]   conditional_Sx_upper_7_2  1
    Sx[7,2]   conditional_complement_lower_7_2  -1
    Sx[7,2]   conditional_complement_upper_7_2  -1
    Sx[7,2]   hard_cost_W_definition  -2.0363989413658219e-04
    Sx[7,2]   floor_residual  -2.0363989413658219e-04
    Sx[7,2]   G_residual  -2.0363989413658219e-04
    Sx[7,3]   product_mass_7  1
    Sx[7,3]   product_lx_7_3  1
    Sx[7,3]   product_ux_7_3  1
    Sx[7,3]   product_Su_7_3  1
    Sx[7,3]   product_Sl_7_3  1
    Sx[7,3]   total_product_lower  3
    Sx[7,3]   total_product_upper  3
    Sx[7,3]   conditional_Sx_lower_7_3  1
    Sx[7,3]   conditional_Sx_upper_7_3  1
    Sx[7,3]   conditional_complement_lower_7_3  -1
    Sx[7,3]   conditional_complement_upper_7_3  -1
    Sx[7,4]   product_mass_7  1
    Sx[7,4]   product_lx_7_4  1
    Sx[7,4]   product_ux_7_4  1
    Sx[7,4]   product_Su_7_4  1
    Sx[7,4]   product_Sl_7_4  1
    Sx[7,4]   total_product_lower  4
    Sx[7,4]   total_product_upper  4
    Sx[7,4]   conditional_Sx_lower_7_4  1
    Sx[7,4]   conditional_Sx_upper_7_4  1
    Sx[7,4]   conditional_complement_lower_7_4  -1
    Sx[7,4]   conditional_complement_upper_7_4  -1
    Sx[7,4]   hard_cost_W_definition  2.0363989413658206e-04
    Sx[7,4]   floor_residual  2.0363989413658206e-04
    Sx[7,4]   G_residual  2.0363989413658206e-04
    Sx[7,5]   product_mass_7  1
    Sx[7,5]   product_lx_7_5  1
    Sx[7,5]   product_ux_7_5  1
    Sx[7,5]   product_Su_7_5  1
    Sx[7,5]   product_Sl_7_5  1
    Sx[7,5]   total_product_lower  5
    Sx[7,5]   total_product_upper  5
    Sx[7,5]   conditional_Sx_lower_7_5  1
    Sx[7,5]   conditional_Sx_upper_7_5  1
    Sx[7,5]   conditional_complement_lower_7_5  -1
    Sx[7,5]   conditional_complement_upper_7_5  -1
    Sx[7,5]   hard_cost_W_definition  4.0727978827316422e-04
    Sx[7,5]   floor_residual  4.0727978827316422e-04
    Sx[7,5]   G_residual  4.0727978827316422e-04
    Sx[7,6]   product_mass_7  1
    Sx[7,6]   product_lx_7_6  1
    Sx[7,6]   product_ux_7_6  1
    Sx[7,6]   product_Su_7_6  1
    Sx[7,6]   product_Sl_7_6  1
    Sx[7,6]   total_product_lower  6
    Sx[7,6]   total_product_upper  6
    Sx[7,6]   conditional_Sx_lower_7_6  1
    Sx[7,6]   conditional_Sx_upper_7_6  1
    Sx[7,6]   conditional_complement_lower_7_6  -1
    Sx[7,6]   conditional_complement_upper_7_6  -1
    Sx[7,6]   hard_cost_W_definition  6.1091968240974636e-04
    Sx[7,6]   floor_residual  6.1091968240974636e-04
    Sx[7,6]   G_residual  6.1091968240974636e-04
    Sx[7,7]   product_mass_7  1
    Sx[7,7]   product_lx_7_7  1
    Sx[7,7]   product_ux_7_7  1
    Sx[7,7]   product_Su_7_7  1
    Sx[7,7]   product_Sl_7_7  1
    Sx[7,7]   total_product_lower  7
    Sx[7,7]   total_product_upper  7
    Sx[7,7]   conditional_Sx_lower_7_7  1
    Sx[7,7]   conditional_Sx_upper_7_7  1
    Sx[7,7]   conditional_complement_lower_7_7  -1
    Sx[7,7]   conditional_complement_upper_7_7  -1
    Sx[7,7]   hard_cost_W_definition  8.1455957654632855e-04
    Sx[7,7]   floor_residual  8.1455957654632855e-04
    Sx[7,7]   G_residual  8.1455957654632855e-04
    Sx[7,8]   product_mass_7  1
    Sx[7,8]   product_lx_7_8  1
    Sx[7,8]   product_ux_7_8  1
    Sx[7,8]   product_Su_7_8  1
    Sx[7,8]   product_Sl_7_8  1
    Sx[7,8]   total_product_lower  8
    Sx[7,8]   total_product_upper  8
    Sx[7,8]   conditional_Sx_lower_7_8  1
    Sx[7,8]   conditional_Sx_upper_7_8  1
    Sx[7,8]   conditional_complement_lower_7_8  -1
    Sx[7,8]   conditional_complement_upper_7_8  -1
    Sx[7,8]   hard_cost_W_definition  6.1091968240974657e-04
    Sx[7,8]   floor_residual  6.1091968240974657e-04
    Sx[7,8]   G_residual  6.1091968240974657e-04
    Sx[7,9]   product_mass_7  1
    Sx[7,9]   product_lx_7_9  1
    Sx[7,9]   product_ux_7_9  1
    Sx[7,9]   product_Su_7_9  1
    Sx[7,9]   product_Sl_7_9  1
    Sx[7,9]   total_product_lower  9
    Sx[7,9]   total_product_upper  9
    Sx[7,9]   conditional_Sx_lower_7_9  1
    Sx[7,9]   conditional_Sx_upper_7_9  1
    Sx[7,9]   conditional_complement_lower_7_9  -1
    Sx[7,9]   conditional_complement_upper_7_9  -1
    Sx[7,9]   hard_cost_W_definition  4.0727978827316438e-04
    Sx[7,9]   floor_residual  4.0727978827316438e-04
    Sx[7,9]   G_residual  4.0727978827316438e-04
    Sx[7,10]  product_mass_7  1
    Sx[7,10]  product_lx_7_10  1
    Sx[7,10]  product_ux_7_10  1
    Sx[7,10]  product_Su_7_10  1
    Sx[7,10]  product_Sl_7_10  1
    Sx[7,10]  total_product_lower  10
    Sx[7,10]  total_product_upper  10
    Sx[7,10]  conditional_Sx_lower_7_10  1
    Sx[7,10]  conditional_Sx_upper_7_10  1
    Sx[7,10]  conditional_complement_lower_7_10  -1
    Sx[7,10]  conditional_complement_upper_7_10  -1
    Sx[7,10]  hard_cost_W_definition  2.0363989413658222e-04
    Sx[7,10]  floor_residual  2.0363989413658222e-04
    Sx[7,10]  G_residual  2.0363989413658222e-04
    Sx[7,11]  product_mass_7  1
    Sx[7,11]  product_lx_7_11  1
    Sx[7,11]  product_ux_7_11  1
    Sx[7,11]  product_Su_7_11  1
    Sx[7,11]  product_Sl_7_11  1
    Sx[7,11]  total_product_lower  11
    Sx[7,11]  total_product_upper  11
    Sx[7,11]  conditional_Sx_lower_7_11  1
    Sx[7,11]  conditional_Sx_upper_7_11  1
    Sx[7,11]  conditional_complement_lower_7_11  -1
    Sx[7,11]  conditional_complement_upper_7_11  -1
    Sx[7,12]  product_mass_7  1
    Sx[7,12]  product_lx_7_12  1
    Sx[7,12]  product_ux_7_12  1
    Sx[7,12]  product_Su_7_12  1
    Sx[7,12]  product_Sl_7_12  1
    Sx[7,12]  total_product_lower  12
    Sx[7,12]  total_product_upper  12
    Sx[7,12]  conditional_Sx_lower_7_12  1
    Sx[7,12]  conditional_Sx_upper_7_12  1
    Sx[7,12]  conditional_complement_lower_7_12  -1
    Sx[7,12]  conditional_complement_upper_7_12  -1
    Sx[7,12]  hard_cost_W_definition  -2.0363989413658203e-04
    Sx[7,12]  floor_residual  -2.0363989413658203e-04
    Sx[7,12]  G_residual  -2.0363989413658203e-04
    Sx[7,13]  product_mass_7  1
    Sx[7,13]  product_lx_7_13  1
    Sx[7,13]  product_ux_7_13  1
    Sx[7,13]  product_Su_7_13  1
    Sx[7,13]  product_Sl_7_13  1
    Sx[7,13]  total_product_lower  13
    Sx[7,13]  total_product_upper  13
    Sx[7,13]  conditional_Sx_lower_7_13  1
    Sx[7,13]  conditional_Sx_upper_7_13  1
    Sx[7,13]  conditional_complement_lower_7_13  -1
    Sx[7,13]  conditional_complement_upper_7_13  -1
    Sx[7,13]  hard_cost_W_definition  -4.0727978827316417e-04
    Sx[7,13]  floor_residual  -4.0727978827316417e-04
    Sx[7,13]  G_residual  -4.0727978827316417e-04
    Sx[7,14]  product_mass_7  1
    Sx[7,14]  product_lx_7_14  1
    Sx[7,14]  product_ux_7_14  1
    Sx[7,14]  product_Su_7_14  1
    Sx[7,14]  product_Sl_7_14  1
    Sx[7,14]  total_product_lower  14
    Sx[7,14]  total_product_upper  14
    Sx[7,14]  conditional_Sx_lower_7_14  1
    Sx[7,14]  conditional_Sx_upper_7_14  1
    Sx[7,14]  conditional_complement_lower_7_14  -1
    Sx[7,14]  conditional_complement_upper_7_14  -1
    Sx[7,14]  hard_cost_W_definition  -6.1091968240974625e-04
    Sx[7,14]  floor_residual  -6.1091968240974625e-04
    Sx[7,14]  G_residual  -6.1091968240974625e-04
    Sx[7,15]  product_mass_7  1
    Sx[7,15]  product_lx_7_15  1
    Sx[7,15]  product_ux_7_15  1
    Sx[7,15]  product_Su_7_15  1
    Sx[7,15]  product_Sl_7_15  1
    Sx[7,15]  total_product_lower  15
    Sx[7,15]  total_product_upper  15
    Sx[7,15]  conditional_Sx_lower_7_15  1
    Sx[7,15]  conditional_Sx_upper_7_15  1
    Sx[7,15]  conditional_complement_lower_7_15  -1
    Sx[7,15]  conditional_complement_upper_7_15  -1
    Sx[7,15]  hard_cost_W_definition  -8.1455957654632844e-04
    Sx[7,15]  floor_residual  -8.1455957654632844e-04
    Sx[7,15]  G_residual  -8.1455957654632844e-04
    Sx[8,0]   product_mass_8  1
    Sx[8,0]   product_lx_8_0  1
    Sx[8,0]   product_ux_8_0  1
    Sx[8,0]   product_Su_8_0  1
    Sx[8,0]   product_Sl_8_0  1
    Sx[8,0]   conditional_Sx_lower_8_0  1
    Sx[8,0]   conditional_Sx_upper_8_0  1
    Sx[8,0]   conditional_complement_lower_8_0  -1
    Sx[8,0]   conditional_complement_upper_8_0  -1
    Sx[8,0]   hard_cost_W_definition  -5.2364515352604213e-04
    Sx[8,0]   floor_residual  -5.2364515352604213e-04
    Sx[8,0]   G_residual  -5.2364515352604213e-04
    Sx[8,1]   product_mass_8  1
    Sx[8,1]   product_lx_8_1  1
    Sx[8,1]   product_ux_8_1  1
    Sx[8,1]   product_Su_8_1  1
    Sx[8,1]   product_Sl_8_1  1
    Sx[8,1]   total_product_lower  1
    Sx[8,1]   total_product_upper  1
    Sx[8,1]   conditional_Sx_lower_8_1  1
    Sx[8,1]   conditional_Sx_upper_8_1  1
    Sx[8,1]   conditional_complement_lower_8_1  -1
    Sx[8,1]   conditional_complement_upper_8_1  -1
    Sx[8,1]   hard_cost_W_definition  -3.4909676901736142e-04
    Sx[8,1]   floor_residual  -3.4909676901736142e-04
    Sx[8,1]   G_residual  -3.4909676901736142e-04
    Sx[8,2]   product_mass_8  1
    Sx[8,2]   product_lx_8_2  1
    Sx[8,2]   product_ux_8_2  1
    Sx[8,2]   product_Su_8_2  1
    Sx[8,2]   product_Sl_8_2  1
    Sx[8,2]   total_product_lower  2
    Sx[8,2]   total_product_upper  2
    Sx[8,2]   conditional_Sx_lower_8_2  1
    Sx[8,2]   conditional_Sx_upper_8_2  1
    Sx[8,2]   conditional_complement_lower_8_2  -1
    Sx[8,2]   conditional_complement_upper_8_2  -1
    Sx[8,2]   hard_cost_W_definition  -1.7454838450868071e-04
    Sx[8,2]   floor_residual  -1.7454838450868071e-04
    Sx[8,2]   G_residual  -1.7454838450868071e-04
    Sx[8,3]   product_mass_8  1
    Sx[8,3]   product_lx_8_3  1
    Sx[8,3]   product_ux_8_3  1
    Sx[8,3]   product_Su_8_3  1
    Sx[8,3]   product_Sl_8_3  1
    Sx[8,3]   total_product_lower  3
    Sx[8,3]   total_product_upper  3
    Sx[8,3]   conditional_Sx_lower_8_3  1
    Sx[8,3]   conditional_Sx_upper_8_3  1
    Sx[8,3]   conditional_complement_lower_8_3  -1
    Sx[8,3]   conditional_complement_upper_8_3  -1
    Sx[8,4]   product_mass_8  1
    Sx[8,4]   product_lx_8_4  1
    Sx[8,4]   product_ux_8_4  1
    Sx[8,4]   product_Su_8_4  1
    Sx[8,4]   product_Sl_8_4  1
    Sx[8,4]   total_product_lower  4
    Sx[8,4]   total_product_upper  4
    Sx[8,4]   conditional_Sx_lower_8_4  1
    Sx[8,4]   conditional_Sx_upper_8_4  1
    Sx[8,4]   conditional_complement_lower_8_4  -1
    Sx[8,4]   conditional_complement_upper_8_4  -1
    Sx[8,4]   hard_cost_W_definition  1.7454838450868074e-04
    Sx[8,4]   floor_residual  1.7454838450868074e-04
    Sx[8,4]   G_residual  1.7454838450868074e-04
    Sx[8,5]   product_mass_8  1
    Sx[8,5]   product_lx_8_5  1
    Sx[8,5]   product_ux_8_5  1
    Sx[8,5]   product_Su_8_5  1
    Sx[8,5]   product_Sl_8_5  1
    Sx[8,5]   total_product_lower  5
    Sx[8,5]   total_product_upper  5
    Sx[8,5]   conditional_Sx_lower_8_5  1
    Sx[8,5]   conditional_Sx_upper_8_5  1
    Sx[8,5]   conditional_complement_lower_8_5  -1
    Sx[8,5]   conditional_complement_upper_8_5  -1
    Sx[8,5]   hard_cost_W_definition  3.4909676901736148e-04
    Sx[8,5]   floor_residual  3.4909676901736148e-04
    Sx[8,5]   G_residual  3.4909676901736148e-04
    Sx[8,6]   product_mass_8  1
    Sx[8,6]   product_lx_8_6  1
    Sx[8,6]   product_ux_8_6  1
    Sx[8,6]   product_Su_8_6  1
    Sx[8,6]   product_Sl_8_6  1
    Sx[8,6]   total_product_lower  6
    Sx[8,6]   total_product_upper  6
    Sx[8,6]   conditional_Sx_lower_8_6  1
    Sx[8,6]   conditional_Sx_upper_8_6  1
    Sx[8,6]   conditional_complement_lower_8_6  -1
    Sx[8,6]   conditional_complement_upper_8_6  -1
    Sx[8,6]   hard_cost_W_definition  5.2364515352604224e-04
    Sx[8,6]   floor_residual  5.2364515352604224e-04
    Sx[8,6]   G_residual  5.2364515352604224e-04
    Sx[8,7]   product_mass_8  1
    Sx[8,7]   product_lx_8_7  1
    Sx[8,7]   product_ux_8_7  1
    Sx[8,7]   product_Su_8_7  1
    Sx[8,7]   product_Sl_8_7  1
    Sx[8,7]   total_product_lower  7
    Sx[8,7]   total_product_upper  7
    Sx[8,7]   conditional_Sx_lower_8_7  1
    Sx[8,7]   conditional_Sx_upper_8_7  1
    Sx[8,7]   conditional_complement_lower_8_7  -1
    Sx[8,7]   conditional_complement_upper_8_7  -1
    Sx[8,7]   hard_cost_W_definition  3.4909676901736164e-04
    Sx[8,7]   floor_residual  3.4909676901736164e-04
    Sx[8,7]   G_residual  3.4909676901736164e-04
    Sx[8,8]   product_mass_8  1
    Sx[8,8]   product_lx_8_8  1
    Sx[8,8]   product_ux_8_8  1
    Sx[8,8]   product_Su_8_8  1
    Sx[8,8]   product_Sl_8_8  1
    Sx[8,8]   total_product_lower  8
    Sx[8,8]   total_product_upper  8
    Sx[8,8]   conditional_Sx_lower_8_8  1
    Sx[8,8]   conditional_Sx_upper_8_8  1
    Sx[8,8]   conditional_complement_lower_8_8  -1
    Sx[8,8]   conditional_complement_upper_8_8  -1
    Sx[8,8]   hard_cost_W_definition  1.7454838450868087e-04
    Sx[8,8]   floor_residual  1.7454838450868087e-04
    Sx[8,8]   G_residual  1.7454838450868087e-04
    Sx[8,9]   product_mass_8  1
    Sx[8,9]   product_lx_8_9  1
    Sx[8,9]   product_ux_8_9  1
    Sx[8,9]   product_Su_8_9  1
    Sx[8,9]   product_Sl_8_9  1
    Sx[8,9]   total_product_lower  9
    Sx[8,9]   total_product_upper  9
    Sx[8,9]   conditional_Sx_lower_8_9  1
    Sx[8,9]   conditional_Sx_upper_8_9  1
    Sx[8,9]   conditional_complement_lower_8_9  -1
    Sx[8,9]   conditional_complement_upper_8_9  -1
    Sx[8,10]  product_mass_8  1
    Sx[8,10]  product_lx_8_10  1
    Sx[8,10]  product_ux_8_10  1
    Sx[8,10]  product_Su_8_10  1
    Sx[8,10]  product_Sl_8_10  1
    Sx[8,10]  total_product_lower  10
    Sx[8,10]  total_product_upper  10
    Sx[8,10]  conditional_Sx_lower_8_10  1
    Sx[8,10]  conditional_Sx_upper_8_10  1
    Sx[8,10]  conditional_complement_lower_8_10  -1
    Sx[8,10]  conditional_complement_upper_8_10  -1
    Sx[8,10]  hard_cost_W_definition  -1.7454838450868060e-04
    Sx[8,10]  floor_residual  -1.7454838450868060e-04
    Sx[8,10]  G_residual  -1.7454838450868060e-04
    Sx[8,11]  product_mass_8  1
    Sx[8,11]  product_lx_8_11  1
    Sx[8,11]  product_ux_8_11  1
    Sx[8,11]  product_Su_8_11  1
    Sx[8,11]  product_Sl_8_11  1
    Sx[8,11]  total_product_lower  11
    Sx[8,11]  total_product_upper  11
    Sx[8,11]  conditional_Sx_lower_8_11  1
    Sx[8,11]  conditional_Sx_upper_8_11  1
    Sx[8,11]  conditional_complement_lower_8_11  -1
    Sx[8,11]  conditional_complement_upper_8_11  -1
    Sx[8,11]  hard_cost_W_definition  -3.4909676901736131e-04
    Sx[8,11]  floor_residual  -3.4909676901736131e-04
    Sx[8,11]  G_residual  -3.4909676901736131e-04
    Sx[8,12]  product_mass_8  1
    Sx[8,12]  product_lx_8_12  1
    Sx[8,12]  product_ux_8_12  1
    Sx[8,12]  product_Su_8_12  1
    Sx[8,12]  product_Sl_8_12  1
    Sx[8,12]  total_product_lower  12
    Sx[8,12]  total_product_upper  12
    Sx[8,12]  conditional_Sx_lower_8_12  1
    Sx[8,12]  conditional_Sx_upper_8_12  1
    Sx[8,12]  conditional_complement_lower_8_12  -1
    Sx[8,12]  conditional_complement_upper_8_12  -1
    Sx[8,12]  hard_cost_W_definition  -0.000523645153526042
    Sx[8,12]  floor_residual  -0.000523645153526042
    Sx[8,12]  G_residual  -0.000523645153526042
    Sx[9,0]   product_mass_9  1
    Sx[9,0]   product_lx_9_0  1
    Sx[9,0]   product_ux_9_0  1
    Sx[9,0]   product_Su_9_0  1
    Sx[9,0]   product_Sl_9_0  1
    Sx[9,0]   conditional_Sx_lower_9_0  1
    Sx[9,0]   conditional_Sx_upper_9_0  1
    Sx[9,0]   conditional_complement_lower_9_0  -1
    Sx[9,0]   conditional_complement_upper_9_0  -1
    Sx[9,0]   hard_cost_W_definition  -3.6364286046067603e-04
    Sx[9,0]   floor_residual  -3.6364286046067603e-04
    Sx[9,0]   G_residual  -3.6364286046067603e-04
    Sx[9,1]   product_mass_9  1
    Sx[9,1]   product_lx_9_1  1
    Sx[9,1]   product_ux_9_1  1
    Sx[9,1]   product_Su_9_1  1
    Sx[9,1]   product_Sl_9_1  1
    Sx[9,1]   total_product_lower  1
    Sx[9,1]   total_product_upper  1
    Sx[9,1]   conditional_Sx_lower_9_1  1
    Sx[9,1]   conditional_Sx_upper_9_1  1
    Sx[9,1]   conditional_complement_lower_9_1  -1
    Sx[9,1]   conditional_complement_upper_9_1  -1
    Sx[9,1]   hard_cost_W_definition  -2.1818571627640559e-04
    Sx[9,1]   floor_residual  -2.1818571627640559e-04
    Sx[9,1]   G_residual  -2.1818571627640559e-04
    Sx[9,2]   product_mass_9  1
    Sx[9,2]   product_lx_9_2  1
    Sx[9,2]   product_ux_9_2  1
    Sx[9,2]   product_Su_9_2  1
    Sx[9,2]   product_Sl_9_2  1
    Sx[9,2]   total_product_lower  2
    Sx[9,2]   total_product_upper  2
    Sx[9,2]   conditional_Sx_lower_9_2  1
    Sx[9,2]   conditional_Sx_upper_9_2  1
    Sx[9,2]   conditional_complement_lower_9_2  -1
    Sx[9,2]   conditional_complement_upper_9_2  -1
    Sx[9,2]   hard_cost_W_definition  -7.2728572092135138e-05
    Sx[9,2]   floor_residual  -7.2728572092135138e-05
    Sx[9,2]   G_residual  -7.2728572092135138e-05
    Sx[9,3]   product_mass_9  1
    Sx[9,3]   product_lx_9_3  1
    Sx[9,3]   product_ux_9_3  1
    Sx[9,3]   product_Su_9_3  1
    Sx[9,3]   product_Sl_9_3  1
    Sx[9,3]   total_product_lower  3
    Sx[9,3]   total_product_upper  3
    Sx[9,3]   conditional_Sx_lower_9_3  1
    Sx[9,3]   conditional_Sx_upper_9_3  1
    Sx[9,3]   conditional_complement_lower_9_3  -1
    Sx[9,3]   conditional_complement_upper_9_3  -1
    Sx[9,3]   hard_cost_W_definition  7.2728572092135315e-05
    Sx[9,3]   floor_residual  7.2728572092135315e-05
    Sx[9,3]   G_residual  7.2728572092135315e-05
    Sx[9,4]   product_mass_9  1
    Sx[9,4]   product_lx_9_4  1
    Sx[9,4]   product_ux_9_4  1
    Sx[9,4]   product_Su_9_4  1
    Sx[9,4]   product_Sl_9_4  1
    Sx[9,4]   total_product_lower  4
    Sx[9,4]   total_product_upper  4
    Sx[9,4]   conditional_Sx_lower_9_4  1
    Sx[9,4]   conditional_Sx_upper_9_4  1
    Sx[9,4]   conditional_complement_lower_9_4  -1
    Sx[9,4]   conditional_complement_upper_9_4  -1
    Sx[9,4]   hard_cost_W_definition  2.1818571627640578e-04
    Sx[9,4]   floor_residual  2.1818571627640578e-04
    Sx[9,4]   G_residual  2.1818571627640578e-04
    Sx[9,5]   product_mass_9  1
    Sx[9,5]   product_lx_9_5  1
    Sx[9,5]   product_ux_9_5  1
    Sx[9,5]   product_Su_9_5  1
    Sx[9,5]   product_Sl_9_5  1
    Sx[9,5]   total_product_lower  5
    Sx[9,5]   total_product_upper  5
    Sx[9,5]   conditional_Sx_lower_9_5  1
    Sx[9,5]   conditional_Sx_upper_9_5  1
    Sx[9,5]   conditional_complement_lower_9_5  -1
    Sx[9,5]   conditional_complement_upper_9_5  -1
    Sx[9,5]   hard_cost_W_definition  3.6364286046067619e-04
    Sx[9,5]   floor_residual  3.6364286046067619e-04
    Sx[9,5]   G_residual  3.6364286046067619e-04
    Sx[9,6]   product_mass_9  1
    Sx[9,6]   product_lx_9_6  1
    Sx[9,6]   product_ux_9_6  1
    Sx[9,6]   product_Su_9_6  1
    Sx[9,6]   product_Sl_9_6  1
    Sx[9,6]   total_product_lower  6
    Sx[9,6]   total_product_upper  6
    Sx[9,6]   conditional_Sx_lower_9_6  1
    Sx[9,6]   conditional_Sx_upper_9_6  1
    Sx[9,6]   conditional_complement_lower_9_6  -1
    Sx[9,6]   conditional_complement_upper_9_6  -1
    Sx[9,6]   hard_cost_W_definition  2.1818571627640570e-04
    Sx[9,6]   floor_residual  2.1818571627640570e-04
    Sx[9,6]   G_residual  2.1818571627640570e-04
    Sx[9,7]   product_mass_9  1
    Sx[9,7]   product_lx_9_7  1
    Sx[9,7]   product_ux_9_7  1
    Sx[9,7]   product_Su_9_7  1
    Sx[9,7]   product_Sl_9_7  1
    Sx[9,7]   total_product_lower  7
    Sx[9,7]   total_product_upper  7
    Sx[9,7]   conditional_Sx_lower_9_7  1
    Sx[9,7]   conditional_Sx_upper_9_7  1
    Sx[9,7]   conditional_complement_lower_9_7  -1
    Sx[9,7]   conditional_complement_upper_9_7  -1
    Sx[9,7]   hard_cost_W_definition  7.2728572092135233e-05
    Sx[9,7]   floor_residual  7.2728572092135233e-05
    Sx[9,7]   G_residual  7.2728572092135233e-05
    Sx[9,8]   product_mass_9  1
    Sx[9,8]   product_lx_9_8  1
    Sx[9,8]   product_ux_9_8  1
    Sx[9,8]   product_Su_9_8  1
    Sx[9,8]   product_Sl_9_8  1
    Sx[9,8]   total_product_lower  8
    Sx[9,8]   total_product_upper  8
    Sx[9,8]   conditional_Sx_lower_9_8  1
    Sx[9,8]   conditional_Sx_upper_9_8  1
    Sx[9,8]   conditional_complement_lower_9_8  -1
    Sx[9,8]   conditional_complement_upper_9_8  -1
    Sx[9,8]   hard_cost_W_definition  -7.2728572092135220e-05
    Sx[9,8]   floor_residual  -7.2728572092135220e-05
    Sx[9,8]   G_residual  -7.2728572092135220e-05
    Sx[9,9]   product_mass_9  1
    Sx[9,9]   product_lx_9_9  1
    Sx[9,9]   product_ux_9_9  1
    Sx[9,9]   product_Su_9_9  1
    Sx[9,9]   product_Sl_9_9  1
    Sx[9,9]   total_product_lower  9
    Sx[9,9]   total_product_upper  9
    Sx[9,9]   conditional_Sx_lower_9_9  1
    Sx[9,9]   conditional_Sx_upper_9_9  1
    Sx[9,9]   conditional_complement_lower_9_9  -1
    Sx[9,9]   conditional_complement_upper_9_9  -1
    Sx[9,9]   hard_cost_W_definition  -2.1818571627640567e-04
    Sx[9,9]   floor_residual  -2.1818571627640567e-04
    Sx[9,9]   G_residual  -2.1818571627640567e-04
    Sx[9,10]  product_mass_9  1
    Sx[9,10]  product_lx_9_10  1
    Sx[9,10]  product_ux_9_10  1
    Sx[9,10]  product_Su_9_10  1
    Sx[9,10]  product_Sl_9_10  1
    Sx[9,10]  total_product_lower  10
    Sx[9,10]  total_product_upper  10
    Sx[9,10]  conditional_Sx_lower_9_10  1
    Sx[9,10]  conditional_Sx_upper_9_10  1
    Sx[9,10]  conditional_complement_lower_9_10  -1
    Sx[9,10]  conditional_complement_upper_9_10  -1
    Sx[9,10]  hard_cost_W_definition  -3.6364286046067614e-04
    Sx[9,10]  floor_residual  -3.6364286046067614e-04
    Sx[9,10]  G_residual  -3.6364286046067614e-04
    Sx[10,0]  product_mass_10  1
    Sx[10,0]  product_lx_10_0  1
    Sx[10,0]  product_ux_10_0  1
    Sx[10,0]  product_Su_10_0  1
    Sx[10,0]  product_Sl_10_0  1
    Sx[10,0]  conditional_Sx_lower_10_0  1
    Sx[10,0]  conditional_Sx_upper_10_0  1
    Sx[10,0]  conditional_complement_lower_10_0  -1
    Sx[10,0]  conditional_complement_upper_10_0  -1
    Sx[10,0]  hard_cost_W_definition  -1.3091128838151053e-04
    Sx[10,0]  floor_residual  -1.3091128838151053e-04
    Sx[10,0]  G_residual  -1.3091128838151053e-04
    Sx[10,1]  product_mass_10  1
    Sx[10,1]  product_lx_10_1  1
    Sx[10,1]  product_ux_10_1  1
    Sx[10,1]  product_Su_10_1  1
    Sx[10,1]  product_Sl_10_1  1
    Sx[10,1]  total_product_lower  1
    Sx[10,1]  total_product_upper  1
    Sx[10,1]  conditional_Sx_lower_10_1  1
    Sx[10,1]  conditional_Sx_upper_10_1  1
    Sx[10,1]  conditional_complement_lower_10_1  -1
    Sx[10,1]  conditional_complement_upper_10_1  -1
    Sx[10,1]  hard_cost_W_definition  -4.3637096127170178e-05
    Sx[10,1]  floor_residual  -4.3637096127170178e-05
    Sx[10,1]  G_residual  -4.3637096127170178e-05
    Sx[10,2]  product_mass_10  1
    Sx[10,2]  product_lx_10_2  1
    Sx[10,2]  product_ux_10_2  1
    Sx[10,2]  product_Su_10_2  1
    Sx[10,2]  product_Sl_10_2  1
    Sx[10,2]  total_product_lower  2
    Sx[10,2]  total_product_upper  2
    Sx[10,2]  conditional_Sx_lower_10_2  1
    Sx[10,2]  conditional_Sx_upper_10_2  1
    Sx[10,2]  conditional_complement_lower_10_2  -1
    Sx[10,2]  conditional_complement_upper_10_2  -1
    Sx[10,2]  hard_cost_W_definition  4.3637096127170184e-05
    Sx[10,2]  floor_residual  4.3637096127170184e-05
    Sx[10,2]  G_residual  4.3637096127170184e-05
    Sx[10,3]  product_mass_10  1
    Sx[10,3]  product_lx_10_3  1
    Sx[10,3]  product_ux_10_3  1
    Sx[10,3]  product_Su_10_3  1
    Sx[10,3]  product_Sl_10_3  1
    Sx[10,3]  total_product_lower  3
    Sx[10,3]  total_product_upper  3
    Sx[10,3]  conditional_Sx_lower_10_3  1
    Sx[10,3]  conditional_Sx_upper_10_3  1
    Sx[10,3]  conditional_complement_lower_10_3  -1
    Sx[10,3]  conditional_complement_upper_10_3  -1
    Sx[10,3]  hard_cost_W_definition  1.3091128838151056e-04
    Sx[10,3]  floor_residual  1.3091128838151056e-04
    Sx[10,3]  G_residual  1.3091128838151056e-04
    Sx[10,4]  product_mass_10  1
    Sx[10,4]  product_lx_10_4  1
    Sx[10,4]  product_ux_10_4  1
    Sx[10,4]  product_Su_10_4  1
    Sx[10,4]  product_Sl_10_4  1
    Sx[10,4]  total_product_lower  4
    Sx[10,4]  total_product_upper  4
    Sx[10,4]  conditional_Sx_lower_10_4  1
    Sx[10,4]  conditional_Sx_upper_10_4  1
    Sx[10,4]  conditional_complement_lower_10_4  -1
    Sx[10,4]  conditional_complement_upper_10_4  -1
    Sx[10,4]  hard_cost_W_definition  4.3637096127170218e-05
    Sx[10,4]  floor_residual  4.3637096127170218e-05
    Sx[10,4]  G_residual  4.3637096127170218e-05
    Sx[10,5]  product_mass_10  1
    Sx[10,5]  product_lx_10_5  1
    Sx[10,5]  product_ux_10_5  1
    Sx[10,5]  product_Su_10_5  1
    Sx[10,5]  product_Sl_10_5  1
    Sx[10,5]  total_product_lower  5
    Sx[10,5]  total_product_upper  5
    Sx[10,5]  conditional_Sx_lower_10_5  1
    Sx[10,5]  conditional_Sx_upper_10_5  1
    Sx[10,5]  conditional_complement_lower_10_5  -1
    Sx[10,5]  conditional_complement_upper_10_5  -1
    Sx[10,5]  hard_cost_W_definition  -4.3637096127170150e-05
    Sx[10,5]  floor_residual  -4.3637096127170150e-05
    Sx[10,5]  G_residual  -4.3637096127170150e-05
    Sx[10,6]  product_mass_10  1
    Sx[10,6]  product_lx_10_6  1
    Sx[10,6]  product_ux_10_6  1
    Sx[10,6]  product_Su_10_6  1
    Sx[10,6]  product_Sl_10_6  1
    Sx[10,6]  total_product_lower  6
    Sx[10,6]  total_product_upper  6
    Sx[10,6]  conditional_Sx_lower_10_6  1
    Sx[10,6]  conditional_Sx_upper_10_6  1
    Sx[10,6]  conditional_complement_lower_10_6  -1
    Sx[10,6]  conditional_complement_upper_10_6  -1
    Sx[10,6]  hard_cost_W_definition  -1.3091128838151051e-04
    Sx[10,6]  floor_residual  -1.3091128838151051e-04
    Sx[10,6]  G_residual  -1.3091128838151051e-04
    Sx[11,0]  product_mass_11  1
    Sx[11,0]  product_lx_11_0  1
    Sx[11,0]  product_ux_11_0  1
    Sx[11,0]  product_Su_11_0  1
    Sx[11,0]  product_Sl_11_0  1
    Sx[11,0]  conditional_Sx_lower_11_0  1
    Sx[11,0]  conditional_Sx_upper_11_0  1
    Sx[11,0]  conditional_complement_lower_11_0  -1
    Sx[11,0]  conditional_complement_upper_11_0  -1
    Sx[11,0]  hard_cost_W_definition  -3.6364286046067603e-04
    Sx[11,0]  floor_residual  -3.6364286046067603e-04
    Sx[11,0]  G_residual  -3.6364286046067603e-04
    Sx[11,1]  product_mass_11  1
    Sx[11,1]  product_lx_11_1  1
    Sx[11,1]  product_ux_11_1  1
    Sx[11,1]  product_Su_11_1  1
    Sx[11,1]  product_Sl_11_1  1
    Sx[11,1]  total_product_lower  1
    Sx[11,1]  total_product_upper  1
    Sx[11,1]  conditional_Sx_lower_11_1  1
    Sx[11,1]  conditional_Sx_upper_11_1  1
    Sx[11,1]  conditional_complement_lower_11_1  -1
    Sx[11,1]  conditional_complement_upper_11_1  -1
    Sx[11,1]  hard_cost_W_definition  -2.1818571627640559e-04
    Sx[11,1]  floor_residual  -2.1818571627640559e-04
    Sx[11,1]  G_residual  -2.1818571627640559e-04
    Sx[11,2]  product_mass_11  1
    Sx[11,2]  product_lx_11_2  1
    Sx[11,2]  product_ux_11_2  1
    Sx[11,2]  product_Su_11_2  1
    Sx[11,2]  product_Sl_11_2  1
    Sx[11,2]  total_product_lower  2
    Sx[11,2]  total_product_upper  2
    Sx[11,2]  conditional_Sx_lower_11_2  1
    Sx[11,2]  conditional_Sx_upper_11_2  1
    Sx[11,2]  conditional_complement_lower_11_2  -1
    Sx[11,2]  conditional_complement_upper_11_2  -1
    Sx[11,2]  hard_cost_W_definition  -7.2728572092135138e-05
    Sx[11,2]  floor_residual  -7.2728572092135138e-05
    Sx[11,2]  G_residual  -7.2728572092135138e-05
    Sx[11,3]  product_mass_11  1
    Sx[11,3]  product_lx_11_3  1
    Sx[11,3]  product_ux_11_3  1
    Sx[11,3]  product_Su_11_3  1
    Sx[11,3]  product_Sl_11_3  1
    Sx[11,3]  total_product_lower  3
    Sx[11,3]  total_product_upper  3
    Sx[11,3]  conditional_Sx_lower_11_3  1
    Sx[11,3]  conditional_Sx_upper_11_3  1
    Sx[11,3]  conditional_complement_lower_11_3  -1
    Sx[11,3]  conditional_complement_upper_11_3  -1
    Sx[11,3]  hard_cost_W_definition  7.2728572092135315e-05
    Sx[11,3]  floor_residual  7.2728572092135315e-05
    Sx[11,3]  G_residual  7.2728572092135315e-05
    Sx[11,4]  product_mass_11  1
    Sx[11,4]  product_lx_11_4  1
    Sx[11,4]  product_ux_11_4  1
    Sx[11,4]  product_Su_11_4  1
    Sx[11,4]  product_Sl_11_4  1
    Sx[11,4]  total_product_lower  4
    Sx[11,4]  total_product_upper  4
    Sx[11,4]  conditional_Sx_lower_11_4  1
    Sx[11,4]  conditional_Sx_upper_11_4  1
    Sx[11,4]  conditional_complement_lower_11_4  -1
    Sx[11,4]  conditional_complement_upper_11_4  -1
    Sx[11,4]  hard_cost_W_definition  2.1818571627640578e-04
    Sx[11,4]  floor_residual  2.1818571627640578e-04
    Sx[11,4]  G_residual  2.1818571627640578e-04
    Sx[11,5]  product_mass_11  1
    Sx[11,5]  product_lx_11_5  1
    Sx[11,5]  product_ux_11_5  1
    Sx[11,5]  product_Su_11_5  1
    Sx[11,5]  product_Sl_11_5  1
    Sx[11,5]  total_product_lower  5
    Sx[11,5]  total_product_upper  5
    Sx[11,5]  conditional_Sx_lower_11_5  1
    Sx[11,5]  conditional_Sx_upper_11_5  1
    Sx[11,5]  conditional_complement_lower_11_5  -1
    Sx[11,5]  conditional_complement_upper_11_5  -1
    Sx[11,5]  hard_cost_W_definition  3.6364286046067619e-04
    Sx[11,5]  floor_residual  3.6364286046067619e-04
    Sx[11,5]  G_residual  3.6364286046067619e-04
    Sx[11,6]  product_mass_11  1
    Sx[11,6]  product_lx_11_6  1
    Sx[11,6]  product_ux_11_6  1
    Sx[11,6]  product_Su_11_6  1
    Sx[11,6]  product_Sl_11_6  1
    Sx[11,6]  total_product_lower  6
    Sx[11,6]  total_product_upper  6
    Sx[11,6]  conditional_Sx_lower_11_6  1
    Sx[11,6]  conditional_Sx_upper_11_6  1
    Sx[11,6]  conditional_complement_lower_11_6  -1
    Sx[11,6]  conditional_complement_upper_11_6  -1
    Sx[11,6]  hard_cost_W_definition  2.1818571627640570e-04
    Sx[11,6]  floor_residual  2.1818571627640570e-04
    Sx[11,6]  G_residual  2.1818571627640570e-04
    Sx[11,7]  product_mass_11  1
    Sx[11,7]  product_lx_11_7  1
    Sx[11,7]  product_ux_11_7  1
    Sx[11,7]  product_Su_11_7  1
    Sx[11,7]  product_Sl_11_7  1
    Sx[11,7]  total_product_lower  7
    Sx[11,7]  total_product_upper  7
    Sx[11,7]  conditional_Sx_lower_11_7  1
    Sx[11,7]  conditional_Sx_upper_11_7  1
    Sx[11,7]  conditional_complement_lower_11_7  -1
    Sx[11,7]  conditional_complement_upper_11_7  -1
    Sx[11,7]  hard_cost_W_definition  7.2728572092135233e-05
    Sx[11,7]  floor_residual  7.2728572092135233e-05
    Sx[11,7]  G_residual  7.2728572092135233e-05
    Sx[11,8]  product_mass_11  1
    Sx[11,8]  product_lx_11_8  1
    Sx[11,8]  product_ux_11_8  1
    Sx[11,8]  product_Su_11_8  1
    Sx[11,8]  product_Sl_11_8  1
    Sx[11,8]  total_product_lower  8
    Sx[11,8]  total_product_upper  8
    Sx[11,8]  conditional_Sx_lower_11_8  1
    Sx[11,8]  conditional_Sx_upper_11_8  1
    Sx[11,8]  conditional_complement_lower_11_8  -1
    Sx[11,8]  conditional_complement_upper_11_8  -1
    Sx[11,8]  hard_cost_W_definition  -7.2728572092135220e-05
    Sx[11,8]  floor_residual  -7.2728572092135220e-05
    Sx[11,8]  G_residual  -7.2728572092135220e-05
    Sx[11,9]  product_mass_11  1
    Sx[11,9]  product_lx_11_9  1
    Sx[11,9]  product_ux_11_9  1
    Sx[11,9]  product_Su_11_9  1
    Sx[11,9]  product_Sl_11_9  1
    Sx[11,9]  total_product_lower  9
    Sx[11,9]  total_product_upper  9
    Sx[11,9]  conditional_Sx_lower_11_9  1
    Sx[11,9]  conditional_Sx_upper_11_9  1
    Sx[11,9]  conditional_complement_lower_11_9  -1
    Sx[11,9]  conditional_complement_upper_11_9  -1
    Sx[11,9]  hard_cost_W_definition  -2.1818571627640567e-04
    Sx[11,9]  floor_residual  -2.1818571627640567e-04
    Sx[11,9]  G_residual  -2.1818571627640567e-04
    Sx[11,10]  product_mass_11  1
    Sx[11,10]  product_lx_11_10  1
    Sx[11,10]  product_ux_11_10  1
    Sx[11,10]  product_Su_11_10  1
    Sx[11,10]  product_Sl_11_10  1
    Sx[11,10]  total_product_lower  10
    Sx[11,10]  total_product_upper  10
    Sx[11,10]  conditional_Sx_lower_11_10  1
    Sx[11,10]  conditional_Sx_upper_11_10  1
    Sx[11,10]  conditional_complement_lower_11_10  -1
    Sx[11,10]  conditional_complement_upper_11_10  -1
    Sx[11,10]  hard_cost_W_definition  -3.6364286046067614e-04
    Sx[11,10]  floor_residual  -3.6364286046067614e-04
    Sx[11,10]  G_residual  -3.6364286046067614e-04
    Sx[12,0]  product_mass_12  1
    Sx[12,0]  product_lx_12_0  1
    Sx[12,0]  product_ux_12_0  1
    Sx[12,0]  product_Su_12_0  1
    Sx[12,0]  product_Sl_12_0  1
    Sx[12,0]  conditional_Sx_lower_12_0  1
    Sx[12,0]  conditional_Sx_upper_12_0  1
    Sx[12,0]  conditional_complement_lower_12_0  -1
    Sx[12,0]  conditional_complement_upper_12_0  -1
    Sx[12,0]  hard_cost_W_definition  -5.2364515352604213e-04
    Sx[12,0]  floor_residual  -5.2364515352604213e-04
    Sx[12,0]  G_residual  -5.2364515352604213e-04
    Sx[12,1]  product_mass_12  1
    Sx[12,1]  product_lx_12_1  1
    Sx[12,1]  product_ux_12_1  1
    Sx[12,1]  product_Su_12_1  1
    Sx[12,1]  product_Sl_12_1  1
    Sx[12,1]  total_product_lower  1
    Sx[12,1]  total_product_upper  1
    Sx[12,1]  conditional_Sx_lower_12_1  1
    Sx[12,1]  conditional_Sx_upper_12_1  1
    Sx[12,1]  conditional_complement_lower_12_1  -1
    Sx[12,1]  conditional_complement_upper_12_1  -1
    Sx[12,1]  hard_cost_W_definition  -3.4909676901736142e-04
    Sx[12,1]  floor_residual  -3.4909676901736142e-04
    Sx[12,1]  G_residual  -3.4909676901736142e-04
    Sx[12,2]  product_mass_12  1
    Sx[12,2]  product_lx_12_2  1
    Sx[12,2]  product_ux_12_2  1
    Sx[12,2]  product_Su_12_2  1
    Sx[12,2]  product_Sl_12_2  1
    Sx[12,2]  total_product_lower  2
    Sx[12,2]  total_product_upper  2
    Sx[12,2]  conditional_Sx_lower_12_2  1
    Sx[12,2]  conditional_Sx_upper_12_2  1
    Sx[12,2]  conditional_complement_lower_12_2  -1
    Sx[12,2]  conditional_complement_upper_12_2  -1
    Sx[12,2]  hard_cost_W_definition  -1.7454838450868071e-04
    Sx[12,2]  floor_residual  -1.7454838450868071e-04
    Sx[12,2]  G_residual  -1.7454838450868071e-04
    Sx[12,3]  product_mass_12  1
    Sx[12,3]  product_lx_12_3  1
    Sx[12,3]  product_ux_12_3  1
    Sx[12,3]  product_Su_12_3  1
    Sx[12,3]  product_Sl_12_3  1
    Sx[12,3]  total_product_lower  3
    Sx[12,3]  total_product_upper  3
    Sx[12,3]  conditional_Sx_lower_12_3  1
    Sx[12,3]  conditional_Sx_upper_12_3  1
    Sx[12,3]  conditional_complement_lower_12_3  -1
    Sx[12,3]  conditional_complement_upper_12_3  -1
    Sx[12,4]  product_mass_12  1
    Sx[12,4]  product_lx_12_4  1
    Sx[12,4]  product_ux_12_4  1
    Sx[12,4]  product_Su_12_4  1
    Sx[12,4]  product_Sl_12_4  1
    Sx[12,4]  total_product_lower  4
    Sx[12,4]  total_product_upper  4
    Sx[12,4]  conditional_Sx_lower_12_4  1
    Sx[12,4]  conditional_Sx_upper_12_4  1
    Sx[12,4]  conditional_complement_lower_12_4  -1
    Sx[12,4]  conditional_complement_upper_12_4  -1
    Sx[12,4]  hard_cost_W_definition  1.7454838450868074e-04
    Sx[12,4]  floor_residual  1.7454838450868074e-04
    Sx[12,4]  G_residual  1.7454838450868074e-04
    Sx[12,5]  product_mass_12  1
    Sx[12,5]  product_lx_12_5  1
    Sx[12,5]  product_ux_12_5  1
    Sx[12,5]  product_Su_12_5  1
    Sx[12,5]  product_Sl_12_5  1
    Sx[12,5]  total_product_lower  5
    Sx[12,5]  total_product_upper  5
    Sx[12,5]  conditional_Sx_lower_12_5  1
    Sx[12,5]  conditional_Sx_upper_12_5  1
    Sx[12,5]  conditional_complement_lower_12_5  -1
    Sx[12,5]  conditional_complement_upper_12_5  -1
    Sx[12,5]  hard_cost_W_definition  3.4909676901736148e-04
    Sx[12,5]  floor_residual  3.4909676901736148e-04
    Sx[12,5]  G_residual  3.4909676901736148e-04
    Sx[12,6]  product_mass_12  1
    Sx[12,6]  product_lx_12_6  1
    Sx[12,6]  product_ux_12_6  1
    Sx[12,6]  product_Su_12_6  1
    Sx[12,6]  product_Sl_12_6  1
    Sx[12,6]  total_product_lower  6
    Sx[12,6]  total_product_upper  6
    Sx[12,6]  conditional_Sx_lower_12_6  1
    Sx[12,6]  conditional_Sx_upper_12_6  1
    Sx[12,6]  conditional_complement_lower_12_6  -1
    Sx[12,6]  conditional_complement_upper_12_6  -1
    Sx[12,6]  hard_cost_W_definition  5.2364515352604224e-04
    Sx[12,6]  floor_residual  5.2364515352604224e-04
    Sx[12,6]  G_residual  5.2364515352604224e-04
    Sx[12,7]  product_mass_12  1
    Sx[12,7]  product_lx_12_7  1
    Sx[12,7]  product_ux_12_7  1
    Sx[12,7]  product_Su_12_7  1
    Sx[12,7]  product_Sl_12_7  1
    Sx[12,7]  total_product_lower  7
    Sx[12,7]  total_product_upper  7
    Sx[12,7]  conditional_Sx_lower_12_7  1
    Sx[12,7]  conditional_Sx_upper_12_7  1
    Sx[12,7]  conditional_complement_lower_12_7  -1
    Sx[12,7]  conditional_complement_upper_12_7  -1
    Sx[12,7]  hard_cost_W_definition  3.4909676901736164e-04
    Sx[12,7]  floor_residual  3.4909676901736164e-04
    Sx[12,7]  G_residual  3.4909676901736164e-04
    Sx[12,8]  product_mass_12  1
    Sx[12,8]  product_lx_12_8  1
    Sx[12,8]  product_ux_12_8  1
    Sx[12,8]  product_Su_12_8  1
    Sx[12,8]  product_Sl_12_8  1
    Sx[12,8]  total_product_lower  8
    Sx[12,8]  total_product_upper  8
    Sx[12,8]  conditional_Sx_lower_12_8  1
    Sx[12,8]  conditional_Sx_upper_12_8  1
    Sx[12,8]  conditional_complement_lower_12_8  -1
    Sx[12,8]  conditional_complement_upper_12_8  -1
    Sx[12,8]  hard_cost_W_definition  1.7454838450868087e-04
    Sx[12,8]  floor_residual  1.7454838450868087e-04
    Sx[12,8]  G_residual  1.7454838450868087e-04
    Sx[12,9]  product_mass_12  1
    Sx[12,9]  product_lx_12_9  1
    Sx[12,9]  product_ux_12_9  1
    Sx[12,9]  product_Su_12_9  1
    Sx[12,9]  product_Sl_12_9  1
    Sx[12,9]  total_product_lower  9
    Sx[12,9]  total_product_upper  9
    Sx[12,9]  conditional_Sx_lower_12_9  1
    Sx[12,9]  conditional_Sx_upper_12_9  1
    Sx[12,9]  conditional_complement_lower_12_9  -1
    Sx[12,9]  conditional_complement_upper_12_9  -1
    Sx[12,10]  product_mass_12  1
    Sx[12,10]  product_lx_12_10  1
    Sx[12,10]  product_ux_12_10  1
    Sx[12,10]  product_Su_12_10  1
    Sx[12,10]  product_Sl_12_10  1
    Sx[12,10]  total_product_lower  10
    Sx[12,10]  total_product_upper  10
    Sx[12,10]  conditional_Sx_lower_12_10  1
    Sx[12,10]  conditional_Sx_upper_12_10  1
    Sx[12,10]  conditional_complement_lower_12_10  -1
    Sx[12,10]  conditional_complement_upper_12_10  -1
    Sx[12,10]  hard_cost_W_definition  -1.7454838450868060e-04
    Sx[12,10]  floor_residual  -1.7454838450868060e-04
    Sx[12,10]  G_residual  -1.7454838450868060e-04
    Sx[12,11]  product_mass_12  1
    Sx[12,11]  product_lx_12_11  1
    Sx[12,11]  product_ux_12_11  1
    Sx[12,11]  product_Su_12_11  1
    Sx[12,11]  product_Sl_12_11  1
    Sx[12,11]  total_product_lower  11
    Sx[12,11]  total_product_upper  11
    Sx[12,11]  conditional_Sx_lower_12_11  1
    Sx[12,11]  conditional_Sx_upper_12_11  1
    Sx[12,11]  conditional_complement_lower_12_11  -1
    Sx[12,11]  conditional_complement_upper_12_11  -1
    Sx[12,11]  hard_cost_W_definition  -3.4909676901736131e-04
    Sx[12,11]  floor_residual  -3.4909676901736131e-04
    Sx[12,11]  G_residual  -3.4909676901736131e-04
    Sx[12,12]  product_mass_12  1
    Sx[12,12]  product_lx_12_12  1
    Sx[12,12]  product_ux_12_12  1
    Sx[12,12]  product_Su_12_12  1
    Sx[12,12]  product_Sl_12_12  1
    Sx[12,12]  total_product_lower  12
    Sx[12,12]  total_product_upper  12
    Sx[12,12]  conditional_Sx_lower_12_12  1
    Sx[12,12]  conditional_Sx_upper_12_12  1
    Sx[12,12]  conditional_complement_lower_12_12  -1
    Sx[12,12]  conditional_complement_upper_12_12  -1
    Sx[12,12]  hard_cost_W_definition  -0.000523645153526042
    Sx[12,12]  floor_residual  -0.000523645153526042
    Sx[12,12]  G_residual  -0.000523645153526042
    Sx[13,0]  product_mass_13  1
    Sx[13,0]  product_lx_13_0  1
    Sx[13,0]  product_ux_13_0  1
    Sx[13,0]  product_Su_13_0  1
    Sx[13,0]  product_Sl_13_0  1
    Sx[13,0]  conditional_Sx_lower_13_0  1
    Sx[13,0]  conditional_Sx_upper_13_0  1
    Sx[13,0]  conditional_complement_lower_13_0  -1
    Sx[13,0]  conditional_complement_upper_13_0  -1
    Sx[13,0]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[13,0]  floor_residual  -2.3273157207916555e-04
    Sx[13,0]  G_residual  -2.3273157207916555e-04
    Sx[13,1]  product_mass_13  1
    Sx[13,1]  product_lx_13_1  1
    Sx[13,1]  product_ux_13_1  1
    Sx[13,1]  product_Su_13_1  1
    Sx[13,1]  product_Sl_13_1  1
    Sx[13,1]  total_product_lower  1
    Sx[13,1]  total_product_upper  1
    Sx[13,1]  conditional_Sx_lower_13_1  1
    Sx[13,1]  conditional_Sx_upper_13_1  1
    Sx[13,1]  conditional_complement_lower_13_1  -1
    Sx[13,1]  conditional_complement_upper_13_1  -1
    Sx[13,1]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[13,1]  floor_residual  -1.1636578603958278e-04
    Sx[13,1]  G_residual  -1.1636578603958278e-04
    Sx[13,2]  product_mass_13  1
    Sx[13,2]  product_lx_13_2  1
    Sx[13,2]  product_ux_13_2  1
    Sx[13,2]  product_Su_13_2  1
    Sx[13,2]  product_Sl_13_2  1
    Sx[13,2]  total_product_lower  2
    Sx[13,2]  total_product_upper  2
    Sx[13,2]  conditional_Sx_lower_13_2  1
    Sx[13,2]  conditional_Sx_upper_13_2  1
    Sx[13,2]  conditional_complement_lower_13_2  -1
    Sx[13,2]  conditional_complement_upper_13_2  -1
    Sx[13,3]  product_mass_13  1
    Sx[13,3]  product_lx_13_3  1
    Sx[13,3]  product_ux_13_3  1
    Sx[13,3]  product_Su_13_3  1
    Sx[13,3]  product_Sl_13_3  1
    Sx[13,3]  total_product_lower  3
    Sx[13,3]  total_product_upper  3
    Sx[13,3]  conditional_Sx_lower_13_3  1
    Sx[13,3]  conditional_Sx_upper_13_3  1
    Sx[13,3]  conditional_complement_lower_13_3  -1
    Sx[13,3]  conditional_complement_upper_13_3  -1
    Sx[13,3]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[13,3]  floor_residual  1.1636578603958278e-04
    Sx[13,3]  G_residual  1.1636578603958278e-04
    Sx[13,4]  product_mass_13  1
    Sx[13,4]  product_lx_13_4  1
    Sx[13,4]  product_ux_13_4  1
    Sx[13,4]  product_Su_13_4  1
    Sx[13,4]  product_Sl_13_4  1
    Sx[13,4]  total_product_lower  4
    Sx[13,4]  total_product_upper  4
    Sx[13,4]  conditional_Sx_lower_13_4  1
    Sx[13,4]  conditional_Sx_upper_13_4  1
    Sx[13,4]  conditional_complement_lower_13_4  -1
    Sx[13,4]  conditional_complement_upper_13_4  -1
    Sx[13,4]  hard_cost_W_definition  2.3273157207916555e-04
    Sx[13,4]  floor_residual  2.3273157207916555e-04
    Sx[13,4]  G_residual  2.3273157207916555e-04
    Sx[13,5]  product_mass_13  1
    Sx[13,5]  product_lx_13_5  1
    Sx[13,5]  product_ux_13_5  1
    Sx[13,5]  product_Su_13_5  1
    Sx[13,5]  product_Sl_13_5  1
    Sx[13,5]  total_product_lower  5
    Sx[13,5]  total_product_upper  5
    Sx[13,5]  conditional_Sx_lower_13_5  1
    Sx[13,5]  conditional_Sx_upper_13_5  1
    Sx[13,5]  conditional_complement_lower_13_5  -1
    Sx[13,5]  conditional_complement_upper_13_5  -1
    Sx[13,5]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[13,5]  floor_residual  1.1636578603958278e-04
    Sx[13,5]  G_residual  1.1636578603958278e-04
    Sx[13,6]  product_mass_13  1
    Sx[13,6]  product_lx_13_6  1
    Sx[13,6]  product_ux_13_6  1
    Sx[13,6]  product_Su_13_6  1
    Sx[13,6]  product_Sl_13_6  1
    Sx[13,6]  total_product_lower  6
    Sx[13,6]  total_product_upper  6
    Sx[13,6]  conditional_Sx_lower_13_6  1
    Sx[13,6]  conditional_Sx_upper_13_6  1
    Sx[13,6]  conditional_complement_lower_13_6  -1
    Sx[13,6]  conditional_complement_upper_13_6  -1
    Sx[13,7]  product_mass_13  1
    Sx[13,7]  product_lx_13_7  1
    Sx[13,7]  product_ux_13_7  1
    Sx[13,7]  product_Su_13_7  1
    Sx[13,7]  product_Sl_13_7  1
    Sx[13,7]  total_product_lower  7
    Sx[13,7]  total_product_upper  7
    Sx[13,7]  conditional_Sx_lower_13_7  1
    Sx[13,7]  conditional_Sx_upper_13_7  1
    Sx[13,7]  conditional_complement_lower_13_7  -1
    Sx[13,7]  conditional_complement_upper_13_7  -1
    Sx[13,7]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[13,7]  floor_residual  -1.1636578603958278e-04
    Sx[13,7]  G_residual  -1.1636578603958278e-04
    Sx[13,8]  product_mass_13  1
    Sx[13,8]  product_lx_13_8  1
    Sx[13,8]  product_ux_13_8  1
    Sx[13,8]  product_Su_13_8  1
    Sx[13,8]  product_Sl_13_8  1
    Sx[13,8]  total_product_lower  8
    Sx[13,8]  total_product_upper  8
    Sx[13,8]  conditional_Sx_lower_13_8  1
    Sx[13,8]  conditional_Sx_upper_13_8  1
    Sx[13,8]  conditional_complement_lower_13_8  -1
    Sx[13,8]  conditional_complement_upper_13_8  -1
    Sx[13,8]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[13,8]  floor_residual  -2.3273157207916555e-04
    Sx[13,8]  G_residual  -2.3273157207916555e-04
    Sx[14,0]  product_mass_14  1
    Sx[14,0]  product_lx_14_0  1
    Sx[14,0]  product_ux_14_0  1
    Sx[14,0]  product_Su_14_0  1
    Sx[14,0]  product_Sl_14_0  1
    Sx[14,0]  conditional_Sx_lower_14_0  1
    Sx[14,0]  conditional_Sx_upper_14_0  1
    Sx[14,0]  conditional_complement_lower_14_0  -1
    Sx[14,0]  conditional_complement_upper_14_0  -1
    Sx[14,0]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[14,0]  floor_residual  -2.3273157207916555e-04
    Sx[14,0]  G_residual  -2.3273157207916555e-04
    Sx[14,1]  product_mass_14  1
    Sx[14,1]  product_lx_14_1  1
    Sx[14,1]  product_ux_14_1  1
    Sx[14,1]  product_Su_14_1  1
    Sx[14,1]  product_Sl_14_1  1
    Sx[14,1]  total_product_lower  1
    Sx[14,1]  total_product_upper  1
    Sx[14,1]  conditional_Sx_lower_14_1  1
    Sx[14,1]  conditional_Sx_upper_14_1  1
    Sx[14,1]  conditional_complement_lower_14_1  -1
    Sx[14,1]  conditional_complement_upper_14_1  -1
    Sx[14,1]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[14,1]  floor_residual  -1.1636578603958278e-04
    Sx[14,1]  G_residual  -1.1636578603958278e-04
    Sx[14,2]  product_mass_14  1
    Sx[14,2]  product_lx_14_2  1
    Sx[14,2]  product_ux_14_2  1
    Sx[14,2]  product_Su_14_2  1
    Sx[14,2]  product_Sl_14_2  1
    Sx[14,2]  total_product_lower  2
    Sx[14,2]  total_product_upper  2
    Sx[14,2]  conditional_Sx_lower_14_2  1
    Sx[14,2]  conditional_Sx_upper_14_2  1
    Sx[14,2]  conditional_complement_lower_14_2  -1
    Sx[14,2]  conditional_complement_upper_14_2  -1
    Sx[14,3]  product_mass_14  1
    Sx[14,3]  product_lx_14_3  1
    Sx[14,3]  product_ux_14_3  1
    Sx[14,3]  product_Su_14_3  1
    Sx[14,3]  product_Sl_14_3  1
    Sx[14,3]  total_product_lower  3
    Sx[14,3]  total_product_upper  3
    Sx[14,3]  conditional_Sx_lower_14_3  1
    Sx[14,3]  conditional_Sx_upper_14_3  1
    Sx[14,3]  conditional_complement_lower_14_3  -1
    Sx[14,3]  conditional_complement_upper_14_3  -1
    Sx[14,3]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[14,3]  floor_residual  1.1636578603958278e-04
    Sx[14,3]  G_residual  1.1636578603958278e-04
    Sx[14,4]  product_mass_14  1
    Sx[14,4]  product_lx_14_4  1
    Sx[14,4]  product_ux_14_4  1
    Sx[14,4]  product_Su_14_4  1
    Sx[14,4]  product_Sl_14_4  1
    Sx[14,4]  total_product_lower  4
    Sx[14,4]  total_product_upper  4
    Sx[14,4]  conditional_Sx_lower_14_4  1
    Sx[14,4]  conditional_Sx_upper_14_4  1
    Sx[14,4]  conditional_complement_lower_14_4  -1
    Sx[14,4]  conditional_complement_upper_14_4  -1
    Sx[14,4]  hard_cost_W_definition  2.3273157207916555e-04
    Sx[14,4]  floor_residual  2.3273157207916555e-04
    Sx[14,4]  G_residual  2.3273157207916555e-04
    Sx[14,5]  product_mass_14  1
    Sx[14,5]  product_lx_14_5  1
    Sx[14,5]  product_ux_14_5  1
    Sx[14,5]  product_Su_14_5  1
    Sx[14,5]  product_Sl_14_5  1
    Sx[14,5]  total_product_lower  5
    Sx[14,5]  total_product_upper  5
    Sx[14,5]  conditional_Sx_lower_14_5  1
    Sx[14,5]  conditional_Sx_upper_14_5  1
    Sx[14,5]  conditional_complement_lower_14_5  -1
    Sx[14,5]  conditional_complement_upper_14_5  -1
    Sx[14,5]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[14,5]  floor_residual  1.1636578603958278e-04
    Sx[14,5]  G_residual  1.1636578603958278e-04
    Sx[14,6]  product_mass_14  1
    Sx[14,6]  product_lx_14_6  1
    Sx[14,6]  product_ux_14_6  1
    Sx[14,6]  product_Su_14_6  1
    Sx[14,6]  product_Sl_14_6  1
    Sx[14,6]  total_product_lower  6
    Sx[14,6]  total_product_upper  6
    Sx[14,6]  conditional_Sx_lower_14_6  1
    Sx[14,6]  conditional_Sx_upper_14_6  1
    Sx[14,6]  conditional_complement_lower_14_6  -1
    Sx[14,6]  conditional_complement_upper_14_6  -1
    Sx[14,7]  product_mass_14  1
    Sx[14,7]  product_lx_14_7  1
    Sx[14,7]  product_ux_14_7  1
    Sx[14,7]  product_Su_14_7  1
    Sx[14,7]  product_Sl_14_7  1
    Sx[14,7]  total_product_lower  7
    Sx[14,7]  total_product_upper  7
    Sx[14,7]  conditional_Sx_lower_14_7  1
    Sx[14,7]  conditional_Sx_upper_14_7  1
    Sx[14,7]  conditional_complement_lower_14_7  -1
    Sx[14,7]  conditional_complement_upper_14_7  -1
    Sx[14,7]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[14,7]  floor_residual  -1.1636578603958278e-04
    Sx[14,7]  G_residual  -1.1636578603958278e-04
    Sx[14,8]  product_mass_14  1
    Sx[14,8]  product_lx_14_8  1
    Sx[14,8]  product_ux_14_8  1
    Sx[14,8]  product_Su_14_8  1
    Sx[14,8]  product_Sl_14_8  1
    Sx[14,8]  total_product_lower  8
    Sx[14,8]  total_product_upper  8
    Sx[14,8]  conditional_Sx_lower_14_8  1
    Sx[14,8]  conditional_Sx_upper_14_8  1
    Sx[14,8]  conditional_complement_lower_14_8  -1
    Sx[14,8]  conditional_complement_upper_14_8  -1
    Sx[14,8]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[14,8]  floor_residual  -2.3273157207916555e-04
    Sx[14,8]  G_residual  -2.3273157207916555e-04
    Sx[15,0]  product_mass_15  1
    Sx[15,0]  product_lx_15_0  1
    Sx[15,0]  product_ux_15_0  1
    Sx[15,0]  product_Su_15_0  1
    Sx[15,0]  product_Sl_15_0  1
    Sx[15,0]  conditional_Sx_lower_15_0  1
    Sx[15,0]  conditional_Sx_upper_15_0  1
    Sx[15,0]  conditional_complement_lower_15_0  -1
    Sx[15,0]  conditional_complement_upper_15_0  -1
    Sx[15,0]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[15,0]  floor_residual  -2.3273157207916555e-04
    Sx[15,0]  G_residual  -2.3273157207916555e-04
    Sx[15,1]  product_mass_15  1
    Sx[15,1]  product_lx_15_1  1
    Sx[15,1]  product_ux_15_1  1
    Sx[15,1]  product_Su_15_1  1
    Sx[15,1]  product_Sl_15_1  1
    Sx[15,1]  total_product_lower  1
    Sx[15,1]  total_product_upper  1
    Sx[15,1]  conditional_Sx_lower_15_1  1
    Sx[15,1]  conditional_Sx_upper_15_1  1
    Sx[15,1]  conditional_complement_lower_15_1  -1
    Sx[15,1]  conditional_complement_upper_15_1  -1
    Sx[15,1]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[15,1]  floor_residual  -1.1636578603958278e-04
    Sx[15,1]  G_residual  -1.1636578603958278e-04
    Sx[15,2]  product_mass_15  1
    Sx[15,2]  product_lx_15_2  1
    Sx[15,2]  product_ux_15_2  1
    Sx[15,2]  product_Su_15_2  1
    Sx[15,2]  product_Sl_15_2  1
    Sx[15,2]  total_product_lower  2
    Sx[15,2]  total_product_upper  2
    Sx[15,2]  conditional_Sx_lower_15_2  1
    Sx[15,2]  conditional_Sx_upper_15_2  1
    Sx[15,2]  conditional_complement_lower_15_2  -1
    Sx[15,2]  conditional_complement_upper_15_2  -1
    Sx[15,3]  product_mass_15  1
    Sx[15,3]  product_lx_15_3  1
    Sx[15,3]  product_ux_15_3  1
    Sx[15,3]  product_Su_15_3  1
    Sx[15,3]  product_Sl_15_3  1
    Sx[15,3]  total_product_lower  3
    Sx[15,3]  total_product_upper  3
    Sx[15,3]  conditional_Sx_lower_15_3  1
    Sx[15,3]  conditional_Sx_upper_15_3  1
    Sx[15,3]  conditional_complement_lower_15_3  -1
    Sx[15,3]  conditional_complement_upper_15_3  -1
    Sx[15,3]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[15,3]  floor_residual  1.1636578603958278e-04
    Sx[15,3]  G_residual  1.1636578603958278e-04
    Sx[15,4]  product_mass_15  1
    Sx[15,4]  product_lx_15_4  1
    Sx[15,4]  product_ux_15_4  1
    Sx[15,4]  product_Su_15_4  1
    Sx[15,4]  product_Sl_15_4  1
    Sx[15,4]  total_product_lower  4
    Sx[15,4]  total_product_upper  4
    Sx[15,4]  conditional_Sx_lower_15_4  1
    Sx[15,4]  conditional_Sx_upper_15_4  1
    Sx[15,4]  conditional_complement_lower_15_4  -1
    Sx[15,4]  conditional_complement_upper_15_4  -1
    Sx[15,4]  hard_cost_W_definition  2.3273157207916555e-04
    Sx[15,4]  floor_residual  2.3273157207916555e-04
    Sx[15,4]  G_residual  2.3273157207916555e-04
    Sx[15,5]  product_mass_15  1
    Sx[15,5]  product_lx_15_5  1
    Sx[15,5]  product_ux_15_5  1
    Sx[15,5]  product_Su_15_5  1
    Sx[15,5]  product_Sl_15_5  1
    Sx[15,5]  total_product_lower  5
    Sx[15,5]  total_product_upper  5
    Sx[15,5]  conditional_Sx_lower_15_5  1
    Sx[15,5]  conditional_Sx_upper_15_5  1
    Sx[15,5]  conditional_complement_lower_15_5  -1
    Sx[15,5]  conditional_complement_upper_15_5  -1
    Sx[15,5]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[15,5]  floor_residual  1.1636578603958278e-04
    Sx[15,5]  G_residual  1.1636578603958278e-04
    Sx[15,6]  product_mass_15  1
    Sx[15,6]  product_lx_15_6  1
    Sx[15,6]  product_ux_15_6  1
    Sx[15,6]  product_Su_15_6  1
    Sx[15,6]  product_Sl_15_6  1
    Sx[15,6]  total_product_lower  6
    Sx[15,6]  total_product_upper  6
    Sx[15,6]  conditional_Sx_lower_15_6  1
    Sx[15,6]  conditional_Sx_upper_15_6  1
    Sx[15,6]  conditional_complement_lower_15_6  -1
    Sx[15,6]  conditional_complement_upper_15_6  -1
    Sx[15,7]  product_mass_15  1
    Sx[15,7]  product_lx_15_7  1
    Sx[15,7]  product_ux_15_7  1
    Sx[15,7]  product_Su_15_7  1
    Sx[15,7]  product_Sl_15_7  1
    Sx[15,7]  total_product_lower  7
    Sx[15,7]  total_product_upper  7
    Sx[15,7]  conditional_Sx_lower_15_7  1
    Sx[15,7]  conditional_Sx_upper_15_7  1
    Sx[15,7]  conditional_complement_lower_15_7  -1
    Sx[15,7]  conditional_complement_upper_15_7  -1
    Sx[15,7]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[15,7]  floor_residual  -1.1636578603958278e-04
    Sx[15,7]  G_residual  -1.1636578603958278e-04
    Sx[15,8]  product_mass_15  1
    Sx[15,8]  product_lx_15_8  1
    Sx[15,8]  product_ux_15_8  1
    Sx[15,8]  product_Su_15_8  1
    Sx[15,8]  product_Sl_15_8  1
    Sx[15,8]  total_product_lower  8
    Sx[15,8]  total_product_upper  8
    Sx[15,8]  conditional_Sx_lower_15_8  1
    Sx[15,8]  conditional_Sx_upper_15_8  1
    Sx[15,8]  conditional_complement_lower_15_8  -1
    Sx[15,8]  conditional_complement_upper_15_8  -1
    Sx[15,8]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[15,8]  floor_residual  -2.3273157207916555e-04
    Sx[15,8]  G_residual  -2.3273157207916555e-04
    Sx[16,0]  product_mass_16  1
    Sx[16,0]  product_lx_16_0  1
    Sx[16,0]  product_ux_16_0  1
    Sx[16,0]  product_Su_16_0  1
    Sx[16,0]  product_Sl_16_0  1
    Sx[16,0]  conditional_Sx_lower_16_0  1
    Sx[16,0]  conditional_Sx_upper_16_0  1
    Sx[16,0]  conditional_complement_lower_16_0  -1
    Sx[16,0]  conditional_complement_upper_16_0  -1
    Sx[16,0]  hard_cost_W_definition  -9.3092511011388858e-04
    Sx[16,0]  floor_residual  -9.3092511011388858e-04
    Sx[16,0]  G_residual  -9.3092511011388858e-04
    Sx[16,1]  product_mass_16  1
    Sx[16,1]  product_lx_16_1  1
    Sx[16,1]  product_ux_16_1  1
    Sx[16,1]  product_Su_16_1  1
    Sx[16,1]  product_Sl_16_1  1
    Sx[16,1]  total_product_lower  1
    Sx[16,1]  total_product_upper  1
    Sx[16,1]  conditional_Sx_lower_16_1  1
    Sx[16,1]  conditional_Sx_upper_16_1  1
    Sx[16,1]  conditional_complement_lower_16_1  -1
    Sx[16,1]  conditional_complement_upper_16_1  -1
    Sx[16,1]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[16,1]  floor_residual  -6.9819383258541636e-04
    Sx[16,1]  G_residual  -6.9819383258541636e-04
    Sx[16,2]  product_mass_16  1
    Sx[16,2]  product_lx_16_2  1
    Sx[16,2]  product_ux_16_2  1
    Sx[16,2]  product_Su_16_2  1
    Sx[16,2]  product_Sl_16_2  1
    Sx[16,2]  total_product_lower  2
    Sx[16,2]  total_product_upper  2
    Sx[16,2]  conditional_Sx_lower_16_2  1
    Sx[16,2]  conditional_Sx_upper_16_2  1
    Sx[16,2]  conditional_complement_lower_16_2  -1
    Sx[16,2]  conditional_complement_upper_16_2  -1
    Sx[16,2]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[16,2]  floor_residual  -4.6546255505694429e-04
    Sx[16,2]  G_residual  -4.6546255505694429e-04
    Sx[16,3]  product_mass_16  1
    Sx[16,3]  product_lx_16_3  1
    Sx[16,3]  product_ux_16_3  1
    Sx[16,3]  product_Su_16_3  1
    Sx[16,3]  product_Sl_16_3  1
    Sx[16,3]  total_product_lower  3
    Sx[16,3]  total_product_upper  3
    Sx[16,3]  conditional_Sx_lower_16_3  1
    Sx[16,3]  conditional_Sx_upper_16_3  1
    Sx[16,3]  conditional_complement_lower_16_3  -1
    Sx[16,3]  conditional_complement_upper_16_3  -1
    Sx[16,3]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[16,3]  floor_residual  -2.3273127752847215e-04
    Sx[16,3]  G_residual  -2.3273127752847215e-04
    Sx[16,4]  product_mass_16  1
    Sx[16,4]  product_lx_16_4  1
    Sx[16,4]  product_ux_16_4  1
    Sx[16,4]  product_Su_16_4  1
    Sx[16,4]  product_Sl_16_4  1
    Sx[16,4]  total_product_lower  4
    Sx[16,4]  total_product_upper  4
    Sx[16,4]  conditional_Sx_lower_16_4  1
    Sx[16,4]  conditional_Sx_upper_16_4  1
    Sx[16,4]  conditional_complement_lower_16_4  -1
    Sx[16,4]  conditional_complement_upper_16_4  -1
    Sx[16,5]  product_mass_16  1
    Sx[16,5]  product_lx_16_5  1
    Sx[16,5]  product_ux_16_5  1
    Sx[16,5]  product_Su_16_5  1
    Sx[16,5]  product_Sl_16_5  1
    Sx[16,5]  total_product_lower  5
    Sx[16,5]  total_product_upper  5
    Sx[16,5]  conditional_Sx_lower_16_5  1
    Sx[16,5]  conditional_Sx_upper_16_5  1
    Sx[16,5]  conditional_complement_lower_16_5  -1
    Sx[16,5]  conditional_complement_upper_16_5  -1
    Sx[16,5]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[16,5]  floor_residual  2.3273127752847215e-04
    Sx[16,5]  G_residual  2.3273127752847215e-04
    Sx[16,6]  product_mass_16  1
    Sx[16,6]  product_lx_16_6  1
    Sx[16,6]  product_ux_16_6  1
    Sx[16,6]  product_Su_16_6  1
    Sx[16,6]  product_Sl_16_6  1
    Sx[16,6]  total_product_lower  6
    Sx[16,6]  total_product_upper  6
    Sx[16,6]  conditional_Sx_lower_16_6  1
    Sx[16,6]  conditional_Sx_upper_16_6  1
    Sx[16,6]  conditional_complement_lower_16_6  -1
    Sx[16,6]  conditional_complement_upper_16_6  -1
    Sx[16,6]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[16,6]  floor_residual  4.6546255505694429e-04
    Sx[16,6]  G_residual  4.6546255505694429e-04
    Sx[16,7]  product_mass_16  1
    Sx[16,7]  product_lx_16_7  1
    Sx[16,7]  product_ux_16_7  1
    Sx[16,7]  product_Su_16_7  1
    Sx[16,7]  product_Sl_16_7  1
    Sx[16,7]  total_product_lower  7
    Sx[16,7]  total_product_upper  7
    Sx[16,7]  conditional_Sx_lower_16_7  1
    Sx[16,7]  conditional_Sx_upper_16_7  1
    Sx[16,7]  conditional_complement_lower_16_7  -1
    Sx[16,7]  conditional_complement_upper_16_7  -1
    Sx[16,7]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[16,7]  floor_residual  6.9819383258541646e-04
    Sx[16,7]  G_residual  6.9819383258541646e-04
    Sx[16,8]  product_mass_16  1
    Sx[16,8]  product_lx_16_8  1
    Sx[16,8]  product_ux_16_8  1
    Sx[16,8]  product_Su_16_8  1
    Sx[16,8]  product_Sl_16_8  1
    Sx[16,8]  total_product_lower  8
    Sx[16,8]  total_product_upper  8
    Sx[16,8]  conditional_Sx_lower_16_8  1
    Sx[16,8]  conditional_Sx_upper_16_8  1
    Sx[16,8]  conditional_complement_lower_16_8  -1
    Sx[16,8]  conditional_complement_upper_16_8  -1
    Sx[16,8]  hard_cost_W_definition  9.3092511011388858e-04
    Sx[16,8]  floor_residual  9.3092511011388858e-04
    Sx[16,8]  G_residual  9.3092511011388858e-04
    Sx[16,9]  product_mass_16  1
    Sx[16,9]  product_lx_16_9  1
    Sx[16,9]  product_ux_16_9  1
    Sx[16,9]  product_Su_16_9  1
    Sx[16,9]  product_Sl_16_9  1
    Sx[16,9]  total_product_lower  9
    Sx[16,9]  total_product_upper  9
    Sx[16,9]  conditional_Sx_lower_16_9  1
    Sx[16,9]  conditional_Sx_upper_16_9  1
    Sx[16,9]  conditional_complement_lower_16_9  -1
    Sx[16,9]  conditional_complement_upper_16_9  -1
    Sx[16,9]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[16,9]  floor_residual  6.9819383258541646e-04
    Sx[16,9]  G_residual  6.9819383258541646e-04
    Sx[16,10]  product_mass_16  1
    Sx[16,10]  product_lx_16_10  1
    Sx[16,10]  product_ux_16_10  1
    Sx[16,10]  product_Su_16_10  1
    Sx[16,10]  product_Sl_16_10  1
    Sx[16,10]  total_product_lower  10
    Sx[16,10]  total_product_upper  10
    Sx[16,10]  conditional_Sx_lower_16_10  1
    Sx[16,10]  conditional_Sx_upper_16_10  1
    Sx[16,10]  conditional_complement_lower_16_10  -1
    Sx[16,10]  conditional_complement_upper_16_10  -1
    Sx[16,10]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[16,10]  floor_residual  4.6546255505694429e-04
    Sx[16,10]  G_residual  4.6546255505694429e-04
    Sx[16,11]  product_mass_16  1
    Sx[16,11]  product_lx_16_11  1
    Sx[16,11]  product_ux_16_11  1
    Sx[16,11]  product_Su_16_11  1
    Sx[16,11]  product_Sl_16_11  1
    Sx[16,11]  total_product_lower  11
    Sx[16,11]  total_product_upper  11
    Sx[16,11]  conditional_Sx_lower_16_11  1
    Sx[16,11]  conditional_Sx_upper_16_11  1
    Sx[16,11]  conditional_complement_lower_16_11  -1
    Sx[16,11]  conditional_complement_upper_16_11  -1
    Sx[16,11]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[16,11]  floor_residual  2.3273127752847215e-04
    Sx[16,11]  G_residual  2.3273127752847215e-04
    Sx[16,12]  product_mass_16  1
    Sx[16,12]  product_lx_16_12  1
    Sx[16,12]  product_ux_16_12  1
    Sx[16,12]  product_Su_16_12  1
    Sx[16,12]  product_Sl_16_12  1
    Sx[16,12]  total_product_lower  12
    Sx[16,12]  total_product_upper  12
    Sx[16,12]  conditional_Sx_lower_16_12  1
    Sx[16,12]  conditional_Sx_upper_16_12  1
    Sx[16,12]  conditional_complement_lower_16_12  -1
    Sx[16,12]  conditional_complement_upper_16_12  -1
    Sx[16,13]  product_mass_16  1
    Sx[16,13]  product_lx_16_13  1
    Sx[16,13]  product_ux_16_13  1
    Sx[16,13]  product_Su_16_13  1
    Sx[16,13]  product_Sl_16_13  1
    Sx[16,13]  total_product_lower  13
    Sx[16,13]  total_product_upper  13
    Sx[16,13]  conditional_Sx_lower_16_13  1
    Sx[16,13]  conditional_Sx_upper_16_13  1
    Sx[16,13]  conditional_complement_lower_16_13  -1
    Sx[16,13]  conditional_complement_upper_16_13  -1
    Sx[16,13]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[16,13]  floor_residual  -2.3273127752847215e-04
    Sx[16,13]  G_residual  -2.3273127752847215e-04
    Sx[16,14]  product_mass_16  1
    Sx[16,14]  product_lx_16_14  1
    Sx[16,14]  product_ux_16_14  1
    Sx[16,14]  product_Su_16_14  1
    Sx[16,14]  product_Sl_16_14  1
    Sx[16,14]  total_product_lower  14
    Sx[16,14]  total_product_upper  14
    Sx[16,14]  conditional_Sx_lower_16_14  1
    Sx[16,14]  conditional_Sx_upper_16_14  1
    Sx[16,14]  conditional_complement_lower_16_14  -1
    Sx[16,14]  conditional_complement_upper_16_14  -1
    Sx[16,14]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[16,14]  floor_residual  -4.6546255505694429e-04
    Sx[16,14]  G_residual  -4.6546255505694429e-04
    Sx[16,15]  product_mass_16  1
    Sx[16,15]  product_lx_16_15  1
    Sx[16,15]  product_ux_16_15  1
    Sx[16,15]  product_Su_16_15  1
    Sx[16,15]  product_Sl_16_15  1
    Sx[16,15]  total_product_lower  15
    Sx[16,15]  total_product_upper  15
    Sx[16,15]  conditional_Sx_lower_16_15  1
    Sx[16,15]  conditional_Sx_upper_16_15  1
    Sx[16,15]  conditional_complement_lower_16_15  -1
    Sx[16,15]  conditional_complement_upper_16_15  -1
    Sx[16,15]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[16,15]  floor_residual  -6.9819383258541636e-04
    Sx[16,15]  G_residual  -6.9819383258541636e-04
    Sx[17,0]  product_mass_17  1
    Sx[17,0]  product_lx_17_0  1
    Sx[17,0]  product_ux_17_0  1
    Sx[17,0]  product_Su_17_0  1
    Sx[17,0]  product_Sl_17_0  1
    Sx[17,0]  conditional_Sx_lower_17_0  1
    Sx[17,0]  conditional_Sx_upper_17_0  1
    Sx[17,0]  conditional_complement_lower_17_0  -1
    Sx[17,0]  conditional_complement_upper_17_0  -1
    Sx[17,0]  hard_cost_W_definition  -1.3091128838151053e-04
    Sx[17,0]  floor_residual  -1.3091128838151053e-04
    Sx[17,0]  G_residual  -1.3091128838151053e-04
    Sx[17,1]  product_mass_17  1
    Sx[17,1]  product_lx_17_1  1
    Sx[17,1]  product_ux_17_1  1
    Sx[17,1]  product_Su_17_1  1
    Sx[17,1]  product_Sl_17_1  1
    Sx[17,1]  total_product_lower  1
    Sx[17,1]  total_product_upper  1
    Sx[17,1]  conditional_Sx_lower_17_1  1
    Sx[17,1]  conditional_Sx_upper_17_1  1
    Sx[17,1]  conditional_complement_lower_17_1  -1
    Sx[17,1]  conditional_complement_upper_17_1  -1
    Sx[17,1]  hard_cost_W_definition  -4.3637096127170178e-05
    Sx[17,1]  floor_residual  -4.3637096127170178e-05
    Sx[17,1]  G_residual  -4.3637096127170178e-05
    Sx[17,2]  product_mass_17  1
    Sx[17,2]  product_lx_17_2  1
    Sx[17,2]  product_ux_17_2  1
    Sx[17,2]  product_Su_17_2  1
    Sx[17,2]  product_Sl_17_2  1
    Sx[17,2]  total_product_lower  2
    Sx[17,2]  total_product_upper  2
    Sx[17,2]  conditional_Sx_lower_17_2  1
    Sx[17,2]  conditional_Sx_upper_17_2  1
    Sx[17,2]  conditional_complement_lower_17_2  -1
    Sx[17,2]  conditional_complement_upper_17_2  -1
    Sx[17,2]  hard_cost_W_definition  4.3637096127170184e-05
    Sx[17,2]  floor_residual  4.3637096127170184e-05
    Sx[17,2]  G_residual  4.3637096127170184e-05
    Sx[17,3]  product_mass_17  1
    Sx[17,3]  product_lx_17_3  1
    Sx[17,3]  product_ux_17_3  1
    Sx[17,3]  product_Su_17_3  1
    Sx[17,3]  product_Sl_17_3  1
    Sx[17,3]  total_product_lower  3
    Sx[17,3]  total_product_upper  3
    Sx[17,3]  conditional_Sx_lower_17_3  1
    Sx[17,3]  conditional_Sx_upper_17_3  1
    Sx[17,3]  conditional_complement_lower_17_3  -1
    Sx[17,3]  conditional_complement_upper_17_3  -1
    Sx[17,3]  hard_cost_W_definition  1.3091128838151056e-04
    Sx[17,3]  floor_residual  1.3091128838151056e-04
    Sx[17,3]  G_residual  1.3091128838151056e-04
    Sx[17,4]  product_mass_17  1
    Sx[17,4]  product_lx_17_4  1
    Sx[17,4]  product_ux_17_4  1
    Sx[17,4]  product_Su_17_4  1
    Sx[17,4]  product_Sl_17_4  1
    Sx[17,4]  total_product_lower  4
    Sx[17,4]  total_product_upper  4
    Sx[17,4]  conditional_Sx_lower_17_4  1
    Sx[17,4]  conditional_Sx_upper_17_4  1
    Sx[17,4]  conditional_complement_lower_17_4  -1
    Sx[17,4]  conditional_complement_upper_17_4  -1
    Sx[17,4]  hard_cost_W_definition  4.3637096127170218e-05
    Sx[17,4]  floor_residual  4.3637096127170218e-05
    Sx[17,4]  G_residual  4.3637096127170218e-05
    Sx[17,5]  product_mass_17  1
    Sx[17,5]  product_lx_17_5  1
    Sx[17,5]  product_ux_17_5  1
    Sx[17,5]  product_Su_17_5  1
    Sx[17,5]  product_Sl_17_5  1
    Sx[17,5]  total_product_lower  5
    Sx[17,5]  total_product_upper  5
    Sx[17,5]  conditional_Sx_lower_17_5  1
    Sx[17,5]  conditional_Sx_upper_17_5  1
    Sx[17,5]  conditional_complement_lower_17_5  -1
    Sx[17,5]  conditional_complement_upper_17_5  -1
    Sx[17,5]  hard_cost_W_definition  -4.3637096127170150e-05
    Sx[17,5]  floor_residual  -4.3637096127170150e-05
    Sx[17,5]  G_residual  -4.3637096127170150e-05
    Sx[17,6]  product_mass_17  1
    Sx[17,6]  product_lx_17_6  1
    Sx[17,6]  product_ux_17_6  1
    Sx[17,6]  product_Su_17_6  1
    Sx[17,6]  product_Sl_17_6  1
    Sx[17,6]  total_product_lower  6
    Sx[17,6]  total_product_upper  6
    Sx[17,6]  conditional_Sx_lower_17_6  1
    Sx[17,6]  conditional_Sx_upper_17_6  1
    Sx[17,6]  conditional_complement_lower_17_6  -1
    Sx[17,6]  conditional_complement_upper_17_6  -1
    Sx[17,6]  hard_cost_W_definition  -1.3091128838151051e-04
    Sx[17,6]  floor_residual  -1.3091128838151051e-04
    Sx[17,6]  G_residual  -1.3091128838151051e-04
    Sx[18,0]  product_mass_18  1
    Sx[18,0]  product_lx_18_0  1
    Sx[18,0]  product_ux_18_0  1
    Sx[18,0]  product_Su_18_0  1
    Sx[18,0]  product_Sl_18_0  1
    Sx[18,0]  conditional_Sx_lower_18_0  1
    Sx[18,0]  conditional_Sx_upper_18_0  1
    Sx[18,0]  conditional_complement_lower_18_0  -1
    Sx[18,0]  conditional_complement_upper_18_0  -1
    Sx[18,0]  hard_cost_W_definition  -3.6364286046067603e-04
    Sx[18,0]  floor_residual  -3.6364286046067603e-04
    Sx[18,0]  G_residual  -3.6364286046067603e-04
    Sx[18,1]  product_mass_18  1
    Sx[18,1]  product_lx_18_1  1
    Sx[18,1]  product_ux_18_1  1
    Sx[18,1]  product_Su_18_1  1
    Sx[18,1]  product_Sl_18_1  1
    Sx[18,1]  total_product_lower  1
    Sx[18,1]  total_product_upper  1
    Sx[18,1]  conditional_Sx_lower_18_1  1
    Sx[18,1]  conditional_Sx_upper_18_1  1
    Sx[18,1]  conditional_complement_lower_18_1  -1
    Sx[18,1]  conditional_complement_upper_18_1  -1
    Sx[18,1]  hard_cost_W_definition  -2.1818571627640559e-04
    Sx[18,1]  floor_residual  -2.1818571627640559e-04
    Sx[18,1]  G_residual  -2.1818571627640559e-04
    Sx[18,2]  product_mass_18  1
    Sx[18,2]  product_lx_18_2  1
    Sx[18,2]  product_ux_18_2  1
    Sx[18,2]  product_Su_18_2  1
    Sx[18,2]  product_Sl_18_2  1
    Sx[18,2]  total_product_lower  2
    Sx[18,2]  total_product_upper  2
    Sx[18,2]  conditional_Sx_lower_18_2  1
    Sx[18,2]  conditional_Sx_upper_18_2  1
    Sx[18,2]  conditional_complement_lower_18_2  -1
    Sx[18,2]  conditional_complement_upper_18_2  -1
    Sx[18,2]  hard_cost_W_definition  -7.2728572092135138e-05
    Sx[18,2]  floor_residual  -7.2728572092135138e-05
    Sx[18,2]  G_residual  -7.2728572092135138e-05
    Sx[18,3]  product_mass_18  1
    Sx[18,3]  product_lx_18_3  1
    Sx[18,3]  product_ux_18_3  1
    Sx[18,3]  product_Su_18_3  1
    Sx[18,3]  product_Sl_18_3  1
    Sx[18,3]  total_product_lower  3
    Sx[18,3]  total_product_upper  3
    Sx[18,3]  conditional_Sx_lower_18_3  1
    Sx[18,3]  conditional_Sx_upper_18_3  1
    Sx[18,3]  conditional_complement_lower_18_3  -1
    Sx[18,3]  conditional_complement_upper_18_3  -1
    Sx[18,3]  hard_cost_W_definition  7.2728572092135315e-05
    Sx[18,3]  floor_residual  7.2728572092135315e-05
    Sx[18,3]  G_residual  7.2728572092135315e-05
    Sx[18,4]  product_mass_18  1
    Sx[18,4]  product_lx_18_4  1
    Sx[18,4]  product_ux_18_4  1
    Sx[18,4]  product_Su_18_4  1
    Sx[18,4]  product_Sl_18_4  1
    Sx[18,4]  total_product_lower  4
    Sx[18,4]  total_product_upper  4
    Sx[18,4]  conditional_Sx_lower_18_4  1
    Sx[18,4]  conditional_Sx_upper_18_4  1
    Sx[18,4]  conditional_complement_lower_18_4  -1
    Sx[18,4]  conditional_complement_upper_18_4  -1
    Sx[18,4]  hard_cost_W_definition  2.1818571627640578e-04
    Sx[18,4]  floor_residual  2.1818571627640578e-04
    Sx[18,4]  G_residual  2.1818571627640578e-04
    Sx[18,5]  product_mass_18  1
    Sx[18,5]  product_lx_18_5  1
    Sx[18,5]  product_ux_18_5  1
    Sx[18,5]  product_Su_18_5  1
    Sx[18,5]  product_Sl_18_5  1
    Sx[18,5]  total_product_lower  5
    Sx[18,5]  total_product_upper  5
    Sx[18,5]  conditional_Sx_lower_18_5  1
    Sx[18,5]  conditional_Sx_upper_18_5  1
    Sx[18,5]  conditional_complement_lower_18_5  -1
    Sx[18,5]  conditional_complement_upper_18_5  -1
    Sx[18,5]  hard_cost_W_definition  3.6364286046067619e-04
    Sx[18,5]  floor_residual  3.6364286046067619e-04
    Sx[18,5]  G_residual  3.6364286046067619e-04
    Sx[18,6]  product_mass_18  1
    Sx[18,6]  product_lx_18_6  1
    Sx[18,6]  product_ux_18_6  1
    Sx[18,6]  product_Su_18_6  1
    Sx[18,6]  product_Sl_18_6  1
    Sx[18,6]  total_product_lower  6
    Sx[18,6]  total_product_upper  6
    Sx[18,6]  conditional_Sx_lower_18_6  1
    Sx[18,6]  conditional_Sx_upper_18_6  1
    Sx[18,6]  conditional_complement_lower_18_6  -1
    Sx[18,6]  conditional_complement_upper_18_6  -1
    Sx[18,6]  hard_cost_W_definition  2.1818571627640570e-04
    Sx[18,6]  floor_residual  2.1818571627640570e-04
    Sx[18,6]  G_residual  2.1818571627640570e-04
    Sx[18,7]  product_mass_18  1
    Sx[18,7]  product_lx_18_7  1
    Sx[18,7]  product_ux_18_7  1
    Sx[18,7]  product_Su_18_7  1
    Sx[18,7]  product_Sl_18_7  1
    Sx[18,7]  total_product_lower  7
    Sx[18,7]  total_product_upper  7
    Sx[18,7]  conditional_Sx_lower_18_7  1
    Sx[18,7]  conditional_Sx_upper_18_7  1
    Sx[18,7]  conditional_complement_lower_18_7  -1
    Sx[18,7]  conditional_complement_upper_18_7  -1
    Sx[18,7]  hard_cost_W_definition  7.2728572092135233e-05
    Sx[18,7]  floor_residual  7.2728572092135233e-05
    Sx[18,7]  G_residual  7.2728572092135233e-05
    Sx[18,8]  product_mass_18  1
    Sx[18,8]  product_lx_18_8  1
    Sx[18,8]  product_ux_18_8  1
    Sx[18,8]  product_Su_18_8  1
    Sx[18,8]  product_Sl_18_8  1
    Sx[18,8]  total_product_lower  8
    Sx[18,8]  total_product_upper  8
    Sx[18,8]  conditional_Sx_lower_18_8  1
    Sx[18,8]  conditional_Sx_upper_18_8  1
    Sx[18,8]  conditional_complement_lower_18_8  -1
    Sx[18,8]  conditional_complement_upper_18_8  -1
    Sx[18,8]  hard_cost_W_definition  -7.2728572092135220e-05
    Sx[18,8]  floor_residual  -7.2728572092135220e-05
    Sx[18,8]  G_residual  -7.2728572092135220e-05
    Sx[18,9]  product_mass_18  1
    Sx[18,9]  product_lx_18_9  1
    Sx[18,9]  product_ux_18_9  1
    Sx[18,9]  product_Su_18_9  1
    Sx[18,9]  product_Sl_18_9  1
    Sx[18,9]  total_product_lower  9
    Sx[18,9]  total_product_upper  9
    Sx[18,9]  conditional_Sx_lower_18_9  1
    Sx[18,9]  conditional_Sx_upper_18_9  1
    Sx[18,9]  conditional_complement_lower_18_9  -1
    Sx[18,9]  conditional_complement_upper_18_9  -1
    Sx[18,9]  hard_cost_W_definition  -2.1818571627640567e-04
    Sx[18,9]  floor_residual  -2.1818571627640567e-04
    Sx[18,9]  G_residual  -2.1818571627640567e-04
    Sx[18,10]  product_mass_18  1
    Sx[18,10]  product_lx_18_10  1
    Sx[18,10]  product_ux_18_10  1
    Sx[18,10]  product_Su_18_10  1
    Sx[18,10]  product_Sl_18_10  1
    Sx[18,10]  total_product_lower  10
    Sx[18,10]  total_product_upper  10
    Sx[18,10]  conditional_Sx_lower_18_10  1
    Sx[18,10]  conditional_Sx_upper_18_10  1
    Sx[18,10]  conditional_complement_lower_18_10  -1
    Sx[18,10]  conditional_complement_upper_18_10  -1
    Sx[18,10]  hard_cost_W_definition  -3.6364286046067614e-04
    Sx[18,10]  floor_residual  -3.6364286046067614e-04
    Sx[18,10]  G_residual  -3.6364286046067614e-04
    Sx[19,0]  product_mass_19  1
    Sx[19,0]  product_lx_19_0  1
    Sx[19,0]  product_ux_19_0  1
    Sx[19,0]  product_Su_19_0  1
    Sx[19,0]  product_Sl_19_0  1
    Sx[19,0]  conditional_Sx_lower_19_0  1
    Sx[19,0]  conditional_Sx_upper_19_0  1
    Sx[19,0]  conditional_complement_lower_19_0  -1
    Sx[19,0]  conditional_complement_upper_19_0  -1
    Sx[19,0]  hard_cost_W_definition  -3.6364286046067603e-04
    Sx[19,0]  floor_residual  -3.6364286046067603e-04
    Sx[19,0]  G_residual  -3.6364286046067603e-04
    Sx[19,1]  product_mass_19  1
    Sx[19,1]  product_lx_19_1  1
    Sx[19,1]  product_ux_19_1  1
    Sx[19,1]  product_Su_19_1  1
    Sx[19,1]  product_Sl_19_1  1
    Sx[19,1]  total_product_lower  1
    Sx[19,1]  total_product_upper  1
    Sx[19,1]  conditional_Sx_lower_19_1  1
    Sx[19,1]  conditional_Sx_upper_19_1  1
    Sx[19,1]  conditional_complement_lower_19_1  -1
    Sx[19,1]  conditional_complement_upper_19_1  -1
    Sx[19,1]  hard_cost_W_definition  -2.1818571627640559e-04
    Sx[19,1]  floor_residual  -2.1818571627640559e-04
    Sx[19,1]  G_residual  -2.1818571627640559e-04
    Sx[19,2]  product_mass_19  1
    Sx[19,2]  product_lx_19_2  1
    Sx[19,2]  product_ux_19_2  1
    Sx[19,2]  product_Su_19_2  1
    Sx[19,2]  product_Sl_19_2  1
    Sx[19,2]  total_product_lower  2
    Sx[19,2]  total_product_upper  2
    Sx[19,2]  conditional_Sx_lower_19_2  1
    Sx[19,2]  conditional_Sx_upper_19_2  1
    Sx[19,2]  conditional_complement_lower_19_2  -1
    Sx[19,2]  conditional_complement_upper_19_2  -1
    Sx[19,2]  hard_cost_W_definition  -7.2728572092135138e-05
    Sx[19,2]  floor_residual  -7.2728572092135138e-05
    Sx[19,2]  G_residual  -7.2728572092135138e-05
    Sx[19,3]  product_mass_19  1
    Sx[19,3]  product_lx_19_3  1
    Sx[19,3]  product_ux_19_3  1
    Sx[19,3]  product_Su_19_3  1
    Sx[19,3]  product_Sl_19_3  1
    Sx[19,3]  total_product_lower  3
    Sx[19,3]  total_product_upper  3
    Sx[19,3]  conditional_Sx_lower_19_3  1
    Sx[19,3]  conditional_Sx_upper_19_3  1
    Sx[19,3]  conditional_complement_lower_19_3  -1
    Sx[19,3]  conditional_complement_upper_19_3  -1
    Sx[19,3]  hard_cost_W_definition  7.2728572092135315e-05
    Sx[19,3]  floor_residual  7.2728572092135315e-05
    Sx[19,3]  G_residual  7.2728572092135315e-05
    Sx[19,4]  product_mass_19  1
    Sx[19,4]  product_lx_19_4  1
    Sx[19,4]  product_ux_19_4  1
    Sx[19,4]  product_Su_19_4  1
    Sx[19,4]  product_Sl_19_4  1
    Sx[19,4]  total_product_lower  4
    Sx[19,4]  total_product_upper  4
    Sx[19,4]  conditional_Sx_lower_19_4  1
    Sx[19,4]  conditional_Sx_upper_19_4  1
    Sx[19,4]  conditional_complement_lower_19_4  -1
    Sx[19,4]  conditional_complement_upper_19_4  -1
    Sx[19,4]  hard_cost_W_definition  2.1818571627640578e-04
    Sx[19,4]  floor_residual  2.1818571627640578e-04
    Sx[19,4]  G_residual  2.1818571627640578e-04
    Sx[19,5]  product_mass_19  1
    Sx[19,5]  product_lx_19_5  1
    Sx[19,5]  product_ux_19_5  1
    Sx[19,5]  product_Su_19_5  1
    Sx[19,5]  product_Sl_19_5  1
    Sx[19,5]  total_product_lower  5
    Sx[19,5]  total_product_upper  5
    Sx[19,5]  conditional_Sx_lower_19_5  1
    Sx[19,5]  conditional_Sx_upper_19_5  1
    Sx[19,5]  conditional_complement_lower_19_5  -1
    Sx[19,5]  conditional_complement_upper_19_5  -1
    Sx[19,5]  hard_cost_W_definition  3.6364286046067619e-04
    Sx[19,5]  floor_residual  3.6364286046067619e-04
    Sx[19,5]  G_residual  3.6364286046067619e-04
    Sx[19,6]  product_mass_19  1
    Sx[19,6]  product_lx_19_6  1
    Sx[19,6]  product_ux_19_6  1
    Sx[19,6]  product_Su_19_6  1
    Sx[19,6]  product_Sl_19_6  1
    Sx[19,6]  total_product_lower  6
    Sx[19,6]  total_product_upper  6
    Sx[19,6]  conditional_Sx_lower_19_6  1
    Sx[19,6]  conditional_Sx_upper_19_6  1
    Sx[19,6]  conditional_complement_lower_19_6  -1
    Sx[19,6]  conditional_complement_upper_19_6  -1
    Sx[19,6]  hard_cost_W_definition  2.1818571627640570e-04
    Sx[19,6]  floor_residual  2.1818571627640570e-04
    Sx[19,6]  G_residual  2.1818571627640570e-04
    Sx[19,7]  product_mass_19  1
    Sx[19,7]  product_lx_19_7  1
    Sx[19,7]  product_ux_19_7  1
    Sx[19,7]  product_Su_19_7  1
    Sx[19,7]  product_Sl_19_7  1
    Sx[19,7]  total_product_lower  7
    Sx[19,7]  total_product_upper  7
    Sx[19,7]  conditional_Sx_lower_19_7  1
    Sx[19,7]  conditional_Sx_upper_19_7  1
    Sx[19,7]  conditional_complement_lower_19_7  -1
    Sx[19,7]  conditional_complement_upper_19_7  -1
    Sx[19,7]  hard_cost_W_definition  7.2728572092135233e-05
    Sx[19,7]  floor_residual  7.2728572092135233e-05
    Sx[19,7]  G_residual  7.2728572092135233e-05
    Sx[19,8]  product_mass_19  1
    Sx[19,8]  product_lx_19_8  1
    Sx[19,8]  product_ux_19_8  1
    Sx[19,8]  product_Su_19_8  1
    Sx[19,8]  product_Sl_19_8  1
    Sx[19,8]  total_product_lower  8
    Sx[19,8]  total_product_upper  8
    Sx[19,8]  conditional_Sx_lower_19_8  1
    Sx[19,8]  conditional_Sx_upper_19_8  1
    Sx[19,8]  conditional_complement_lower_19_8  -1
    Sx[19,8]  conditional_complement_upper_19_8  -1
    Sx[19,8]  hard_cost_W_definition  -7.2728572092135220e-05
    Sx[19,8]  floor_residual  -7.2728572092135220e-05
    Sx[19,8]  G_residual  -7.2728572092135220e-05
    Sx[19,9]  product_mass_19  1
    Sx[19,9]  product_lx_19_9  1
    Sx[19,9]  product_ux_19_9  1
    Sx[19,9]  product_Su_19_9  1
    Sx[19,9]  product_Sl_19_9  1
    Sx[19,9]  total_product_lower  9
    Sx[19,9]  total_product_upper  9
    Sx[19,9]  conditional_Sx_lower_19_9  1
    Sx[19,9]  conditional_Sx_upper_19_9  1
    Sx[19,9]  conditional_complement_lower_19_9  -1
    Sx[19,9]  conditional_complement_upper_19_9  -1
    Sx[19,9]  hard_cost_W_definition  -2.1818571627640567e-04
    Sx[19,9]  floor_residual  -2.1818571627640567e-04
    Sx[19,9]  G_residual  -2.1818571627640567e-04
    Sx[19,10]  product_mass_19  1
    Sx[19,10]  product_lx_19_10  1
    Sx[19,10]  product_ux_19_10  1
    Sx[19,10]  product_Su_19_10  1
    Sx[19,10]  product_Sl_19_10  1
    Sx[19,10]  total_product_lower  10
    Sx[19,10]  total_product_upper  10
    Sx[19,10]  conditional_Sx_lower_19_10  1
    Sx[19,10]  conditional_Sx_upper_19_10  1
    Sx[19,10]  conditional_complement_lower_19_10  -1
    Sx[19,10]  conditional_complement_upper_19_10  -1
    Sx[19,10]  hard_cost_W_definition  -3.6364286046067614e-04
    Sx[19,10]  floor_residual  -3.6364286046067614e-04
    Sx[19,10]  G_residual  -3.6364286046067614e-04
    Sx[20,0]  product_mass_20  1
    Sx[20,0]  product_lx_20_0  1
    Sx[20,0]  product_ux_20_0  1
    Sx[20,0]  product_Su_20_0  1
    Sx[20,0]  product_Sl_20_0  1
    Sx[20,0]  conditional_Sx_lower_20_0  1
    Sx[20,0]  conditional_Sx_upper_20_0  1
    Sx[20,0]  conditional_complement_lower_20_0  -1
    Sx[20,0]  conditional_complement_upper_20_0  -1
    Sx[20,0]  hard_cost_W_definition  -3.6364286046067603e-04
    Sx[20,0]  floor_residual  -3.6364286046067603e-04
    Sx[20,0]  G_residual  -3.6364286046067603e-04
    Sx[20,1]  product_mass_20  1
    Sx[20,1]  product_lx_20_1  1
    Sx[20,1]  product_ux_20_1  1
    Sx[20,1]  product_Su_20_1  1
    Sx[20,1]  product_Sl_20_1  1
    Sx[20,1]  total_product_lower  1
    Sx[20,1]  total_product_upper  1
    Sx[20,1]  conditional_Sx_lower_20_1  1
    Sx[20,1]  conditional_Sx_upper_20_1  1
    Sx[20,1]  conditional_complement_lower_20_1  -1
    Sx[20,1]  conditional_complement_upper_20_1  -1
    Sx[20,1]  hard_cost_W_definition  -2.1818571627640559e-04
    Sx[20,1]  floor_residual  -2.1818571627640559e-04
    Sx[20,1]  G_residual  -2.1818571627640559e-04
    Sx[20,2]  product_mass_20  1
    Sx[20,2]  product_lx_20_2  1
    Sx[20,2]  product_ux_20_2  1
    Sx[20,2]  product_Su_20_2  1
    Sx[20,2]  product_Sl_20_2  1
    Sx[20,2]  total_product_lower  2
    Sx[20,2]  total_product_upper  2
    Sx[20,2]  conditional_Sx_lower_20_2  1
    Sx[20,2]  conditional_Sx_upper_20_2  1
    Sx[20,2]  conditional_complement_lower_20_2  -1
    Sx[20,2]  conditional_complement_upper_20_2  -1
    Sx[20,2]  hard_cost_W_definition  -7.2728572092135138e-05
    Sx[20,2]  floor_residual  -7.2728572092135138e-05
    Sx[20,2]  G_residual  -7.2728572092135138e-05
    Sx[20,3]  product_mass_20  1
    Sx[20,3]  product_lx_20_3  1
    Sx[20,3]  product_ux_20_3  1
    Sx[20,3]  product_Su_20_3  1
    Sx[20,3]  product_Sl_20_3  1
    Sx[20,3]  total_product_lower  3
    Sx[20,3]  total_product_upper  3
    Sx[20,3]  conditional_Sx_lower_20_3  1
    Sx[20,3]  conditional_Sx_upper_20_3  1
    Sx[20,3]  conditional_complement_lower_20_3  -1
    Sx[20,3]  conditional_complement_upper_20_3  -1
    Sx[20,3]  hard_cost_W_definition  7.2728572092135315e-05
    Sx[20,3]  floor_residual  7.2728572092135315e-05
    Sx[20,3]  G_residual  7.2728572092135315e-05
    Sx[20,4]  product_mass_20  1
    Sx[20,4]  product_lx_20_4  1
    Sx[20,4]  product_ux_20_4  1
    Sx[20,4]  product_Su_20_4  1
    Sx[20,4]  product_Sl_20_4  1
    Sx[20,4]  total_product_lower  4
    Sx[20,4]  total_product_upper  4
    Sx[20,4]  conditional_Sx_lower_20_4  1
    Sx[20,4]  conditional_Sx_upper_20_4  1
    Sx[20,4]  conditional_complement_lower_20_4  -1
    Sx[20,4]  conditional_complement_upper_20_4  -1
    Sx[20,4]  hard_cost_W_definition  2.1818571627640578e-04
    Sx[20,4]  floor_residual  2.1818571627640578e-04
    Sx[20,4]  G_residual  2.1818571627640578e-04
    Sx[20,5]  product_mass_20  1
    Sx[20,5]  product_lx_20_5  1
    Sx[20,5]  product_ux_20_5  1
    Sx[20,5]  product_Su_20_5  1
    Sx[20,5]  product_Sl_20_5  1
    Sx[20,5]  total_product_lower  5
    Sx[20,5]  total_product_upper  5
    Sx[20,5]  conditional_Sx_lower_20_5  1
    Sx[20,5]  conditional_Sx_upper_20_5  1
    Sx[20,5]  conditional_complement_lower_20_5  -1
    Sx[20,5]  conditional_complement_upper_20_5  -1
    Sx[20,5]  hard_cost_W_definition  3.6364286046067619e-04
    Sx[20,5]  floor_residual  3.6364286046067619e-04
    Sx[20,5]  G_residual  3.6364286046067619e-04
    Sx[20,6]  product_mass_20  1
    Sx[20,6]  product_lx_20_6  1
    Sx[20,6]  product_ux_20_6  1
    Sx[20,6]  product_Su_20_6  1
    Sx[20,6]  product_Sl_20_6  1
    Sx[20,6]  total_product_lower  6
    Sx[20,6]  total_product_upper  6
    Sx[20,6]  conditional_Sx_lower_20_6  1
    Sx[20,6]  conditional_Sx_upper_20_6  1
    Sx[20,6]  conditional_complement_lower_20_6  -1
    Sx[20,6]  conditional_complement_upper_20_6  -1
    Sx[20,6]  hard_cost_W_definition  2.1818571627640570e-04
    Sx[20,6]  floor_residual  2.1818571627640570e-04
    Sx[20,6]  G_residual  2.1818571627640570e-04
    Sx[20,7]  product_mass_20  1
    Sx[20,7]  product_lx_20_7  1
    Sx[20,7]  product_ux_20_7  1
    Sx[20,7]  product_Su_20_7  1
    Sx[20,7]  product_Sl_20_7  1
    Sx[20,7]  total_product_lower  7
    Sx[20,7]  total_product_upper  7
    Sx[20,7]  conditional_Sx_lower_20_7  1
    Sx[20,7]  conditional_Sx_upper_20_7  1
    Sx[20,7]  conditional_complement_lower_20_7  -1
    Sx[20,7]  conditional_complement_upper_20_7  -1
    Sx[20,7]  hard_cost_W_definition  7.2728572092135233e-05
    Sx[20,7]  floor_residual  7.2728572092135233e-05
    Sx[20,7]  G_residual  7.2728572092135233e-05
    Sx[20,8]  product_mass_20  1
    Sx[20,8]  product_lx_20_8  1
    Sx[20,8]  product_ux_20_8  1
    Sx[20,8]  product_Su_20_8  1
    Sx[20,8]  product_Sl_20_8  1
    Sx[20,8]  total_product_lower  8
    Sx[20,8]  total_product_upper  8
    Sx[20,8]  conditional_Sx_lower_20_8  1
    Sx[20,8]  conditional_Sx_upper_20_8  1
    Sx[20,8]  conditional_complement_lower_20_8  -1
    Sx[20,8]  conditional_complement_upper_20_8  -1
    Sx[20,8]  hard_cost_W_definition  -7.2728572092135220e-05
    Sx[20,8]  floor_residual  -7.2728572092135220e-05
    Sx[20,8]  G_residual  -7.2728572092135220e-05
    Sx[20,9]  product_mass_20  1
    Sx[20,9]  product_lx_20_9  1
    Sx[20,9]  product_ux_20_9  1
    Sx[20,9]  product_Su_20_9  1
    Sx[20,9]  product_Sl_20_9  1
    Sx[20,9]  total_product_lower  9
    Sx[20,9]  total_product_upper  9
    Sx[20,9]  conditional_Sx_lower_20_9  1
    Sx[20,9]  conditional_Sx_upper_20_9  1
    Sx[20,9]  conditional_complement_lower_20_9  -1
    Sx[20,9]  conditional_complement_upper_20_9  -1
    Sx[20,9]  hard_cost_W_definition  -2.1818571627640567e-04
    Sx[20,9]  floor_residual  -2.1818571627640567e-04
    Sx[20,9]  G_residual  -2.1818571627640567e-04
    Sx[20,10]  product_mass_20  1
    Sx[20,10]  product_lx_20_10  1
    Sx[20,10]  product_ux_20_10  1
    Sx[20,10]  product_Su_20_10  1
    Sx[20,10]  product_Sl_20_10  1
    Sx[20,10]  total_product_lower  10
    Sx[20,10]  total_product_upper  10
    Sx[20,10]  conditional_Sx_lower_20_10  1
    Sx[20,10]  conditional_Sx_upper_20_10  1
    Sx[20,10]  conditional_complement_lower_20_10  -1
    Sx[20,10]  conditional_complement_upper_20_10  -1
    Sx[20,10]  hard_cost_W_definition  -3.6364286046067614e-04
    Sx[20,10]  floor_residual  -3.6364286046067614e-04
    Sx[20,10]  G_residual  -3.6364286046067614e-04
    Sx[21,0]  product_mass_21  1
    Sx[21,0]  product_lx_21_0  1
    Sx[21,0]  product_ux_21_0  1
    Sx[21,0]  product_Su_21_0  1
    Sx[21,0]  product_Sl_21_0  1
    Sx[21,0]  conditional_Sx_lower_21_0  1
    Sx[21,0]  conditional_Sx_upper_21_0  1
    Sx[21,0]  conditional_complement_lower_21_0  -1
    Sx[21,0]  conditional_complement_upper_21_0  -1
    Sx[21,0]  hard_cost_W_definition  -1.3091128838151053e-04
    Sx[21,0]  floor_residual  -1.3091128838151053e-04
    Sx[21,0]  G_residual  -1.3091128838151053e-04
    Sx[21,1]  product_mass_21  1
    Sx[21,1]  product_lx_21_1  1
    Sx[21,1]  product_ux_21_1  1
    Sx[21,1]  product_Su_21_1  1
    Sx[21,1]  product_Sl_21_1  1
    Sx[21,1]  total_product_lower  1
    Sx[21,1]  total_product_upper  1
    Sx[21,1]  conditional_Sx_lower_21_1  1
    Sx[21,1]  conditional_Sx_upper_21_1  1
    Sx[21,1]  conditional_complement_lower_21_1  -1
    Sx[21,1]  conditional_complement_upper_21_1  -1
    Sx[21,1]  hard_cost_W_definition  -4.3637096127170178e-05
    Sx[21,1]  floor_residual  -4.3637096127170178e-05
    Sx[21,1]  G_residual  -4.3637096127170178e-05
    Sx[21,2]  product_mass_21  1
    Sx[21,2]  product_lx_21_2  1
    Sx[21,2]  product_ux_21_2  1
    Sx[21,2]  product_Su_21_2  1
    Sx[21,2]  product_Sl_21_2  1
    Sx[21,2]  total_product_lower  2
    Sx[21,2]  total_product_upper  2
    Sx[21,2]  conditional_Sx_lower_21_2  1
    Sx[21,2]  conditional_Sx_upper_21_2  1
    Sx[21,2]  conditional_complement_lower_21_2  -1
    Sx[21,2]  conditional_complement_upper_21_2  -1
    Sx[21,2]  hard_cost_W_definition  4.3637096127170184e-05
    Sx[21,2]  floor_residual  4.3637096127170184e-05
    Sx[21,2]  G_residual  4.3637096127170184e-05
    Sx[21,3]  product_mass_21  1
    Sx[21,3]  product_lx_21_3  1
    Sx[21,3]  product_ux_21_3  1
    Sx[21,3]  product_Su_21_3  1
    Sx[21,3]  product_Sl_21_3  1
    Sx[21,3]  total_product_lower  3
    Sx[21,3]  total_product_upper  3
    Sx[21,3]  conditional_Sx_lower_21_3  1
    Sx[21,3]  conditional_Sx_upper_21_3  1
    Sx[21,3]  conditional_complement_lower_21_3  -1
    Sx[21,3]  conditional_complement_upper_21_3  -1
    Sx[21,3]  hard_cost_W_definition  1.3091128838151056e-04
    Sx[21,3]  floor_residual  1.3091128838151056e-04
    Sx[21,3]  G_residual  1.3091128838151056e-04
    Sx[21,4]  product_mass_21  1
    Sx[21,4]  product_lx_21_4  1
    Sx[21,4]  product_ux_21_4  1
    Sx[21,4]  product_Su_21_4  1
    Sx[21,4]  product_Sl_21_4  1
    Sx[21,4]  total_product_lower  4
    Sx[21,4]  total_product_upper  4
    Sx[21,4]  conditional_Sx_lower_21_4  1
    Sx[21,4]  conditional_Sx_upper_21_4  1
    Sx[21,4]  conditional_complement_lower_21_4  -1
    Sx[21,4]  conditional_complement_upper_21_4  -1
    Sx[21,4]  hard_cost_W_definition  4.3637096127170218e-05
    Sx[21,4]  floor_residual  4.3637096127170218e-05
    Sx[21,4]  G_residual  4.3637096127170218e-05
    Sx[21,5]  product_mass_21  1
    Sx[21,5]  product_lx_21_5  1
    Sx[21,5]  product_ux_21_5  1
    Sx[21,5]  product_Su_21_5  1
    Sx[21,5]  product_Sl_21_5  1
    Sx[21,5]  total_product_lower  5
    Sx[21,5]  total_product_upper  5
    Sx[21,5]  conditional_Sx_lower_21_5  1
    Sx[21,5]  conditional_Sx_upper_21_5  1
    Sx[21,5]  conditional_complement_lower_21_5  -1
    Sx[21,5]  conditional_complement_upper_21_5  -1
    Sx[21,5]  hard_cost_W_definition  -4.3637096127170150e-05
    Sx[21,5]  floor_residual  -4.3637096127170150e-05
    Sx[21,5]  G_residual  -4.3637096127170150e-05
    Sx[21,6]  product_mass_21  1
    Sx[21,6]  product_lx_21_6  1
    Sx[21,6]  product_ux_21_6  1
    Sx[21,6]  product_Su_21_6  1
    Sx[21,6]  product_Sl_21_6  1
    Sx[21,6]  total_product_lower  6
    Sx[21,6]  total_product_upper  6
    Sx[21,6]  conditional_Sx_lower_21_6  1
    Sx[21,6]  conditional_Sx_upper_21_6  1
    Sx[21,6]  conditional_complement_lower_21_6  -1
    Sx[21,6]  conditional_complement_upper_21_6  -1
    Sx[21,6]  hard_cost_W_definition  -1.3091128838151051e-04
    Sx[21,6]  floor_residual  -1.3091128838151051e-04
    Sx[21,6]  G_residual  -1.3091128838151051e-04
    Sx[22,0]  product_mass_22  1
    Sx[22,0]  product_lx_22_0  1
    Sx[22,0]  product_ux_22_0  1
    Sx[22,0]  product_Su_22_0  1
    Sx[22,0]  product_Sl_22_0  1
    Sx[22,0]  conditional_Sx_lower_22_0  1
    Sx[22,0]  conditional_Sx_upper_22_0  1
    Sx[22,0]  conditional_complement_lower_22_0  -1
    Sx[22,0]  conditional_complement_upper_22_0  -1
    Sx[22,0]  hard_cost_W_definition  -6.1091968240974646e-04
    Sx[22,0]  floor_residual  -6.1091968240974646e-04
    Sx[22,0]  G_residual  -6.1091968240974646e-04
    Sx[22,1]  product_mass_22  1
    Sx[22,1]  product_lx_22_1  1
    Sx[22,1]  product_ux_22_1  1
    Sx[22,1]  product_Su_22_1  1
    Sx[22,1]  product_Sl_22_1  1
    Sx[22,1]  total_product_lower  1
    Sx[22,1]  total_product_upper  1
    Sx[22,1]  conditional_Sx_lower_22_1  1
    Sx[22,1]  conditional_Sx_upper_22_1  1
    Sx[22,1]  conditional_complement_lower_22_1  -1
    Sx[22,1]  conditional_complement_upper_22_1  -1
    Sx[22,1]  hard_cost_W_definition  -4.0727978827316433e-04
    Sx[22,1]  floor_residual  -4.0727978827316433e-04
    Sx[22,1]  G_residual  -4.0727978827316433e-04
    Sx[22,2]  product_mass_22  1
    Sx[22,2]  product_lx_22_2  1
    Sx[22,2]  product_ux_22_2  1
    Sx[22,2]  product_Su_22_2  1
    Sx[22,2]  product_Sl_22_2  1
    Sx[22,2]  total_product_lower  2
    Sx[22,2]  total_product_upper  2
    Sx[22,2]  conditional_Sx_lower_22_2  1
    Sx[22,2]  conditional_Sx_upper_22_2  1
    Sx[22,2]  conditional_complement_lower_22_2  -1
    Sx[22,2]  conditional_complement_upper_22_2  -1
    Sx[22,2]  hard_cost_W_definition  -2.0363989413658219e-04
    Sx[22,2]  floor_residual  -2.0363989413658219e-04
    Sx[22,2]  G_residual  -2.0363989413658219e-04
    Sx[22,3]  product_mass_22  1
    Sx[22,3]  product_lx_22_3  1
    Sx[22,3]  product_ux_22_3  1
    Sx[22,3]  product_Su_22_3  1
    Sx[22,3]  product_Sl_22_3  1
    Sx[22,3]  total_product_lower  3
    Sx[22,3]  total_product_upper  3
    Sx[22,3]  conditional_Sx_lower_22_3  1
    Sx[22,3]  conditional_Sx_upper_22_3  1
    Sx[22,3]  conditional_complement_lower_22_3  -1
    Sx[22,3]  conditional_complement_upper_22_3  -1
    Sx[22,4]  product_mass_22  1
    Sx[22,4]  product_lx_22_4  1
    Sx[22,4]  product_ux_22_4  1
    Sx[22,4]  product_Su_22_4  1
    Sx[22,4]  product_Sl_22_4  1
    Sx[22,4]  total_product_lower  4
    Sx[22,4]  total_product_upper  4
    Sx[22,4]  conditional_Sx_lower_22_4  1
    Sx[22,4]  conditional_Sx_upper_22_4  1
    Sx[22,4]  conditional_complement_lower_22_4  -1
    Sx[22,4]  conditional_complement_upper_22_4  -1
    Sx[22,4]  hard_cost_W_definition  2.0363989413658206e-04
    Sx[22,4]  floor_residual  2.0363989413658206e-04
    Sx[22,4]  G_residual  2.0363989413658206e-04
    Sx[22,5]  product_mass_22  1
    Sx[22,5]  product_lx_22_5  1
    Sx[22,5]  product_ux_22_5  1
    Sx[22,5]  product_Su_22_5  1
    Sx[22,5]  product_Sl_22_5  1
    Sx[22,5]  total_product_lower  5
    Sx[22,5]  total_product_upper  5
    Sx[22,5]  conditional_Sx_lower_22_5  1
    Sx[22,5]  conditional_Sx_upper_22_5  1
    Sx[22,5]  conditional_complement_lower_22_5  -1
    Sx[22,5]  conditional_complement_upper_22_5  -1
    Sx[22,5]  hard_cost_W_definition  4.0727978827316422e-04
    Sx[22,5]  floor_residual  4.0727978827316422e-04
    Sx[22,5]  G_residual  4.0727978827316422e-04
    Sx[22,6]  product_mass_22  1
    Sx[22,6]  product_lx_22_6  1
    Sx[22,6]  product_ux_22_6  1
    Sx[22,6]  product_Su_22_6  1
    Sx[22,6]  product_Sl_22_6  1
    Sx[22,6]  total_product_lower  6
    Sx[22,6]  total_product_upper  6
    Sx[22,6]  conditional_Sx_lower_22_6  1
    Sx[22,6]  conditional_Sx_upper_22_6  1
    Sx[22,6]  conditional_complement_lower_22_6  -1
    Sx[22,6]  conditional_complement_upper_22_6  -1
    Sx[22,6]  hard_cost_W_definition  6.1091968240974636e-04
    Sx[22,6]  floor_residual  6.1091968240974636e-04
    Sx[22,6]  G_residual  6.1091968240974636e-04
    Sx[22,7]  product_mass_22  1
    Sx[22,7]  product_lx_22_7  1
    Sx[22,7]  product_ux_22_7  1
    Sx[22,7]  product_Su_22_7  1
    Sx[22,7]  product_Sl_22_7  1
    Sx[22,7]  total_product_lower  7
    Sx[22,7]  total_product_upper  7
    Sx[22,7]  conditional_Sx_lower_22_7  1
    Sx[22,7]  conditional_Sx_upper_22_7  1
    Sx[22,7]  conditional_complement_lower_22_7  -1
    Sx[22,7]  conditional_complement_upper_22_7  -1
    Sx[22,7]  hard_cost_W_definition  8.1455957654632855e-04
    Sx[22,7]  floor_residual  8.1455957654632855e-04
    Sx[22,7]  G_residual  8.1455957654632855e-04
    Sx[22,8]  product_mass_22  1
    Sx[22,8]  product_lx_22_8  1
    Sx[22,8]  product_ux_22_8  1
    Sx[22,8]  product_Su_22_8  1
    Sx[22,8]  product_Sl_22_8  1
    Sx[22,8]  total_product_lower  8
    Sx[22,8]  total_product_upper  8
    Sx[22,8]  conditional_Sx_lower_22_8  1
    Sx[22,8]  conditional_Sx_upper_22_8  1
    Sx[22,8]  conditional_complement_lower_22_8  -1
    Sx[22,8]  conditional_complement_upper_22_8  -1
    Sx[22,8]  hard_cost_W_definition  6.1091968240974657e-04
    Sx[22,8]  floor_residual  6.1091968240974657e-04
    Sx[22,8]  G_residual  6.1091968240974657e-04
    Sx[22,9]  product_mass_22  1
    Sx[22,9]  product_lx_22_9  1
    Sx[22,9]  product_ux_22_9  1
    Sx[22,9]  product_Su_22_9  1
    Sx[22,9]  product_Sl_22_9  1
    Sx[22,9]  total_product_lower  9
    Sx[22,9]  total_product_upper  9
    Sx[22,9]  conditional_Sx_lower_22_9  1
    Sx[22,9]  conditional_Sx_upper_22_9  1
    Sx[22,9]  conditional_complement_lower_22_9  -1
    Sx[22,9]  conditional_complement_upper_22_9  -1
    Sx[22,9]  hard_cost_W_definition  4.0727978827316438e-04
    Sx[22,9]  floor_residual  4.0727978827316438e-04
    Sx[22,9]  G_residual  4.0727978827316438e-04
    Sx[22,10]  product_mass_22  1
    Sx[22,10]  product_lx_22_10  1
    Sx[22,10]  product_ux_22_10  1
    Sx[22,10]  product_Su_22_10  1
    Sx[22,10]  product_Sl_22_10  1
    Sx[22,10]  total_product_lower  10
    Sx[22,10]  total_product_upper  10
    Sx[22,10]  conditional_Sx_lower_22_10  1
    Sx[22,10]  conditional_Sx_upper_22_10  1
    Sx[22,10]  conditional_complement_lower_22_10  -1
    Sx[22,10]  conditional_complement_upper_22_10  -1
    Sx[22,10]  hard_cost_W_definition  2.0363989413658222e-04
    Sx[22,10]  floor_residual  2.0363989413658222e-04
    Sx[22,10]  G_residual  2.0363989413658222e-04
    Sx[22,11]  product_mass_22  1
    Sx[22,11]  product_lx_22_11  1
    Sx[22,11]  product_ux_22_11  1
    Sx[22,11]  product_Su_22_11  1
    Sx[22,11]  product_Sl_22_11  1
    Sx[22,11]  total_product_lower  11
    Sx[22,11]  total_product_upper  11
    Sx[22,11]  conditional_Sx_lower_22_11  1
    Sx[22,11]  conditional_Sx_upper_22_11  1
    Sx[22,11]  conditional_complement_lower_22_11  -1
    Sx[22,11]  conditional_complement_upper_22_11  -1
    Sx[22,12]  product_mass_22  1
    Sx[22,12]  product_lx_22_12  1
    Sx[22,12]  product_ux_22_12  1
    Sx[22,12]  product_Su_22_12  1
    Sx[22,12]  product_Sl_22_12  1
    Sx[22,12]  total_product_lower  12
    Sx[22,12]  total_product_upper  12
    Sx[22,12]  conditional_Sx_lower_22_12  1
    Sx[22,12]  conditional_Sx_upper_22_12  1
    Sx[22,12]  conditional_complement_lower_22_12  -1
    Sx[22,12]  conditional_complement_upper_22_12  -1
    Sx[22,12]  hard_cost_W_definition  -2.0363989413658203e-04
    Sx[22,12]  floor_residual  -2.0363989413658203e-04
    Sx[22,12]  G_residual  -2.0363989413658203e-04
    Sx[22,13]  product_mass_22  1
    Sx[22,13]  product_lx_22_13  1
    Sx[22,13]  product_ux_22_13  1
    Sx[22,13]  product_Su_22_13  1
    Sx[22,13]  product_Sl_22_13  1
    Sx[22,13]  total_product_lower  13
    Sx[22,13]  total_product_upper  13
    Sx[22,13]  conditional_Sx_lower_22_13  1
    Sx[22,13]  conditional_Sx_upper_22_13  1
    Sx[22,13]  conditional_complement_lower_22_13  -1
    Sx[22,13]  conditional_complement_upper_22_13  -1
    Sx[22,13]  hard_cost_W_definition  -4.0727978827316417e-04
    Sx[22,13]  floor_residual  -4.0727978827316417e-04
    Sx[22,13]  G_residual  -4.0727978827316417e-04
    Sx[22,14]  product_mass_22  1
    Sx[22,14]  product_lx_22_14  1
    Sx[22,14]  product_ux_22_14  1
    Sx[22,14]  product_Su_22_14  1
    Sx[22,14]  product_Sl_22_14  1
    Sx[22,14]  total_product_lower  14
    Sx[22,14]  total_product_upper  14
    Sx[22,14]  conditional_Sx_lower_22_14  1
    Sx[22,14]  conditional_Sx_upper_22_14  1
    Sx[22,14]  conditional_complement_lower_22_14  -1
    Sx[22,14]  conditional_complement_upper_22_14  -1
    Sx[22,14]  hard_cost_W_definition  -6.1091968240974625e-04
    Sx[22,14]  floor_residual  -6.1091968240974625e-04
    Sx[22,14]  G_residual  -6.1091968240974625e-04
    Sx[22,15]  product_mass_22  1
    Sx[22,15]  product_lx_22_15  1
    Sx[22,15]  product_ux_22_15  1
    Sx[22,15]  product_Su_22_15  1
    Sx[22,15]  product_Sl_22_15  1
    Sx[22,15]  total_product_lower  15
    Sx[22,15]  total_product_upper  15
    Sx[22,15]  conditional_Sx_lower_22_15  1
    Sx[22,15]  conditional_Sx_upper_22_15  1
    Sx[22,15]  conditional_complement_lower_22_15  -1
    Sx[22,15]  conditional_complement_upper_22_15  -1
    Sx[22,15]  hard_cost_W_definition  -8.1455957654632844e-04
    Sx[22,15]  floor_residual  -8.1455957654632844e-04
    Sx[22,15]  G_residual  -8.1455957654632844e-04
    Sx[23,0]  product_mass_23  1
    Sx[23,0]  product_lx_23_0  1
    Sx[23,0]  product_ux_23_0  1
    Sx[23,0]  product_Su_23_0  1
    Sx[23,0]  product_Sl_23_0  1
    Sx[23,0]  conditional_Sx_lower_23_0  1
    Sx[23,0]  conditional_Sx_upper_23_0  1
    Sx[23,0]  conditional_complement_lower_23_0  -1
    Sx[23,0]  conditional_complement_upper_23_0  -1
    Sx[23,1]  product_mass_23  1
    Sx[23,1]  product_lx_23_1  1
    Sx[23,1]  product_ux_23_1  1
    Sx[23,1]  product_Su_23_1  1
    Sx[23,1]  product_Sl_23_1  1
    Sx[23,1]  total_product_lower  1
    Sx[23,1]  total_product_upper  1
    Sx[23,1]  conditional_Sx_lower_23_1  1
    Sx[23,1]  conditional_Sx_upper_23_1  1
    Sx[23,1]  conditional_complement_lower_23_1  -1
    Sx[23,1]  conditional_complement_upper_23_1  -1
    Sx[23,1]  hard_cost_W_definition  2.3564055472727373e-04
    Sx[23,1]  floor_residual  2.3564055472727373e-04
    Sx[23,1]  G_residual  2.3564055472727373e-04
    Sx[23,2]  product_mass_23  1
    Sx[23,2]  product_lx_23_2  1
    Sx[23,2]  product_ux_23_2  1
    Sx[23,2]  product_Su_23_2  1
    Sx[23,2]  product_Sl_23_2  1
    Sx[23,2]  total_product_lower  2
    Sx[23,2]  total_product_upper  2
    Sx[23,2]  conditional_Sx_lower_23_2  1
    Sx[23,2]  conditional_Sx_upper_23_2  1
    Sx[23,2]  conditional_complement_lower_23_2  -1
    Sx[23,2]  conditional_complement_upper_23_2  -1
    Sx[23,3]  product_mass_23  1
    Sx[23,3]  product_lx_23_3  1
    Sx[23,3]  product_ux_23_3  1
    Sx[23,3]  product_Su_23_3  1
    Sx[23,3]  product_Sl_23_3  1
    Sx[23,3]  total_product_lower  3
    Sx[23,3]  total_product_upper  3
    Sx[23,3]  conditional_Sx_lower_23_3  1
    Sx[23,3]  conditional_Sx_upper_23_3  1
    Sx[23,3]  conditional_complement_lower_23_3  -1
    Sx[23,3]  conditional_complement_upper_23_3  -1
    Sx[23,3]  hard_cost_W_definition  -2.3564055472727373e-04
    Sx[23,3]  floor_residual  -2.3564055472727373e-04
    Sx[23,3]  G_residual  -2.3564055472727373e-04
    Sx[24,0]  product_mass_24  1
    Sx[24,0]  product_lx_24_0  1
    Sx[24,0]  product_ux_24_0  1
    Sx[24,0]  product_Su_24_0  1
    Sx[24,0]  product_Sl_24_0  1
    Sx[24,0]  conditional_Sx_lower_24_0  1
    Sx[24,0]  conditional_Sx_upper_24_0  1
    Sx[24,0]  conditional_complement_lower_24_0  -1
    Sx[24,0]  conditional_complement_upper_24_0  -1
    Sx[24,0]  hard_cost_W_definition  -9.3092511011388858e-04
    Sx[24,0]  floor_residual  -9.3092511011388858e-04
    Sx[24,0]  G_residual  -9.3092511011388858e-04
    Sx[24,1]  product_mass_24  1
    Sx[24,1]  product_lx_24_1  1
    Sx[24,1]  product_ux_24_1  1
    Sx[24,1]  product_Su_24_1  1
    Sx[24,1]  product_Sl_24_1  1
    Sx[24,1]  total_product_lower  1
    Sx[24,1]  total_product_upper  1
    Sx[24,1]  conditional_Sx_lower_24_1  1
    Sx[24,1]  conditional_Sx_upper_24_1  1
    Sx[24,1]  conditional_complement_lower_24_1  -1
    Sx[24,1]  conditional_complement_upper_24_1  -1
    Sx[24,1]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[24,1]  floor_residual  -6.9819383258541636e-04
    Sx[24,1]  G_residual  -6.9819383258541636e-04
    Sx[24,2]  product_mass_24  1
    Sx[24,2]  product_lx_24_2  1
    Sx[24,2]  product_ux_24_2  1
    Sx[24,2]  product_Su_24_2  1
    Sx[24,2]  product_Sl_24_2  1
    Sx[24,2]  total_product_lower  2
    Sx[24,2]  total_product_upper  2
    Sx[24,2]  conditional_Sx_lower_24_2  1
    Sx[24,2]  conditional_Sx_upper_24_2  1
    Sx[24,2]  conditional_complement_lower_24_2  -1
    Sx[24,2]  conditional_complement_upper_24_2  -1
    Sx[24,2]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[24,2]  floor_residual  -4.6546255505694429e-04
    Sx[24,2]  G_residual  -4.6546255505694429e-04
    Sx[24,3]  product_mass_24  1
    Sx[24,3]  product_lx_24_3  1
    Sx[24,3]  product_ux_24_3  1
    Sx[24,3]  product_Su_24_3  1
    Sx[24,3]  product_Sl_24_3  1
    Sx[24,3]  total_product_lower  3
    Sx[24,3]  total_product_upper  3
    Sx[24,3]  conditional_Sx_lower_24_3  1
    Sx[24,3]  conditional_Sx_upper_24_3  1
    Sx[24,3]  conditional_complement_lower_24_3  -1
    Sx[24,3]  conditional_complement_upper_24_3  -1
    Sx[24,3]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[24,3]  floor_residual  -2.3273127752847215e-04
    Sx[24,3]  G_residual  -2.3273127752847215e-04
    Sx[24,4]  product_mass_24  1
    Sx[24,4]  product_lx_24_4  1
    Sx[24,4]  product_ux_24_4  1
    Sx[24,4]  product_Su_24_4  1
    Sx[24,4]  product_Sl_24_4  1
    Sx[24,4]  total_product_lower  4
    Sx[24,4]  total_product_upper  4
    Sx[24,4]  conditional_Sx_lower_24_4  1
    Sx[24,4]  conditional_Sx_upper_24_4  1
    Sx[24,4]  conditional_complement_lower_24_4  -1
    Sx[24,4]  conditional_complement_upper_24_4  -1
    Sx[24,5]  product_mass_24  1
    Sx[24,5]  product_lx_24_5  1
    Sx[24,5]  product_ux_24_5  1
    Sx[24,5]  product_Su_24_5  1
    Sx[24,5]  product_Sl_24_5  1
    Sx[24,5]  total_product_lower  5
    Sx[24,5]  total_product_upper  5
    Sx[24,5]  conditional_Sx_lower_24_5  1
    Sx[24,5]  conditional_Sx_upper_24_5  1
    Sx[24,5]  conditional_complement_lower_24_5  -1
    Sx[24,5]  conditional_complement_upper_24_5  -1
    Sx[24,5]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[24,5]  floor_residual  2.3273127752847215e-04
    Sx[24,5]  G_residual  2.3273127752847215e-04
    Sx[24,6]  product_mass_24  1
    Sx[24,6]  product_lx_24_6  1
    Sx[24,6]  product_ux_24_6  1
    Sx[24,6]  product_Su_24_6  1
    Sx[24,6]  product_Sl_24_6  1
    Sx[24,6]  total_product_lower  6
    Sx[24,6]  total_product_upper  6
    Sx[24,6]  conditional_Sx_lower_24_6  1
    Sx[24,6]  conditional_Sx_upper_24_6  1
    Sx[24,6]  conditional_complement_lower_24_6  -1
    Sx[24,6]  conditional_complement_upper_24_6  -1
    Sx[24,6]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[24,6]  floor_residual  4.6546255505694429e-04
    Sx[24,6]  G_residual  4.6546255505694429e-04
    Sx[24,7]  product_mass_24  1
    Sx[24,7]  product_lx_24_7  1
    Sx[24,7]  product_ux_24_7  1
    Sx[24,7]  product_Su_24_7  1
    Sx[24,7]  product_Sl_24_7  1
    Sx[24,7]  total_product_lower  7
    Sx[24,7]  total_product_upper  7
    Sx[24,7]  conditional_Sx_lower_24_7  1
    Sx[24,7]  conditional_Sx_upper_24_7  1
    Sx[24,7]  conditional_complement_lower_24_7  -1
    Sx[24,7]  conditional_complement_upper_24_7  -1
    Sx[24,7]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[24,7]  floor_residual  6.9819383258541646e-04
    Sx[24,7]  G_residual  6.9819383258541646e-04
    Sx[24,8]  product_mass_24  1
    Sx[24,8]  product_lx_24_8  1
    Sx[24,8]  product_ux_24_8  1
    Sx[24,8]  product_Su_24_8  1
    Sx[24,8]  product_Sl_24_8  1
    Sx[24,8]  total_product_lower  8
    Sx[24,8]  total_product_upper  8
    Sx[24,8]  conditional_Sx_lower_24_8  1
    Sx[24,8]  conditional_Sx_upper_24_8  1
    Sx[24,8]  conditional_complement_lower_24_8  -1
    Sx[24,8]  conditional_complement_upper_24_8  -1
    Sx[24,8]  hard_cost_W_definition  9.3092511011388858e-04
    Sx[24,8]  floor_residual  9.3092511011388858e-04
    Sx[24,8]  G_residual  9.3092511011388858e-04
    Sx[24,9]  product_mass_24  1
    Sx[24,9]  product_lx_24_9  1
    Sx[24,9]  product_ux_24_9  1
    Sx[24,9]  product_Su_24_9  1
    Sx[24,9]  product_Sl_24_9  1
    Sx[24,9]  total_product_lower  9
    Sx[24,9]  total_product_upper  9
    Sx[24,9]  conditional_Sx_lower_24_9  1
    Sx[24,9]  conditional_Sx_upper_24_9  1
    Sx[24,9]  conditional_complement_lower_24_9  -1
    Sx[24,9]  conditional_complement_upper_24_9  -1
    Sx[24,9]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[24,9]  floor_residual  6.9819383258541646e-04
    Sx[24,9]  G_residual  6.9819383258541646e-04
    Sx[24,10]  product_mass_24  1
    Sx[24,10]  product_lx_24_10  1
    Sx[24,10]  product_ux_24_10  1
    Sx[24,10]  product_Su_24_10  1
    Sx[24,10]  product_Sl_24_10  1
    Sx[24,10]  total_product_lower  10
    Sx[24,10]  total_product_upper  10
    Sx[24,10]  conditional_Sx_lower_24_10  1
    Sx[24,10]  conditional_Sx_upper_24_10  1
    Sx[24,10]  conditional_complement_lower_24_10  -1
    Sx[24,10]  conditional_complement_upper_24_10  -1
    Sx[24,10]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[24,10]  floor_residual  4.6546255505694429e-04
    Sx[24,10]  G_residual  4.6546255505694429e-04
    Sx[24,11]  product_mass_24  1
    Sx[24,11]  product_lx_24_11  1
    Sx[24,11]  product_ux_24_11  1
    Sx[24,11]  product_Su_24_11  1
    Sx[24,11]  product_Sl_24_11  1
    Sx[24,11]  total_product_lower  11
    Sx[24,11]  total_product_upper  11
    Sx[24,11]  conditional_Sx_lower_24_11  1
    Sx[24,11]  conditional_Sx_upper_24_11  1
    Sx[24,11]  conditional_complement_lower_24_11  -1
    Sx[24,11]  conditional_complement_upper_24_11  -1
    Sx[24,11]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[24,11]  floor_residual  2.3273127752847215e-04
    Sx[24,11]  G_residual  2.3273127752847215e-04
    Sx[24,12]  product_mass_24  1
    Sx[24,12]  product_lx_24_12  1
    Sx[24,12]  product_ux_24_12  1
    Sx[24,12]  product_Su_24_12  1
    Sx[24,12]  product_Sl_24_12  1
    Sx[24,12]  total_product_lower  12
    Sx[24,12]  total_product_upper  12
    Sx[24,12]  conditional_Sx_lower_24_12  1
    Sx[24,12]  conditional_Sx_upper_24_12  1
    Sx[24,12]  conditional_complement_lower_24_12  -1
    Sx[24,12]  conditional_complement_upper_24_12  -1
    Sx[24,13]  product_mass_24  1
    Sx[24,13]  product_lx_24_13  1
    Sx[24,13]  product_ux_24_13  1
    Sx[24,13]  product_Su_24_13  1
    Sx[24,13]  product_Sl_24_13  1
    Sx[24,13]  total_product_lower  13
    Sx[24,13]  total_product_upper  13
    Sx[24,13]  conditional_Sx_lower_24_13  1
    Sx[24,13]  conditional_Sx_upper_24_13  1
    Sx[24,13]  conditional_complement_lower_24_13  -1
    Sx[24,13]  conditional_complement_upper_24_13  -1
    Sx[24,13]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[24,13]  floor_residual  -2.3273127752847215e-04
    Sx[24,13]  G_residual  -2.3273127752847215e-04
    Sx[24,14]  product_mass_24  1
    Sx[24,14]  product_lx_24_14  1
    Sx[24,14]  product_ux_24_14  1
    Sx[24,14]  product_Su_24_14  1
    Sx[24,14]  product_Sl_24_14  1
    Sx[24,14]  total_product_lower  14
    Sx[24,14]  total_product_upper  14
    Sx[24,14]  conditional_Sx_lower_24_14  1
    Sx[24,14]  conditional_Sx_upper_24_14  1
    Sx[24,14]  conditional_complement_lower_24_14  -1
    Sx[24,14]  conditional_complement_upper_24_14  -1
    Sx[24,14]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[24,14]  floor_residual  -4.6546255505694429e-04
    Sx[24,14]  G_residual  -4.6546255505694429e-04
    Sx[24,15]  product_mass_24  1
    Sx[24,15]  product_lx_24_15  1
    Sx[24,15]  product_ux_24_15  1
    Sx[24,15]  product_Su_24_15  1
    Sx[24,15]  product_Sl_24_15  1
    Sx[24,15]  total_product_lower  15
    Sx[24,15]  total_product_upper  15
    Sx[24,15]  conditional_Sx_lower_24_15  1
    Sx[24,15]  conditional_Sx_upper_24_15  1
    Sx[24,15]  conditional_complement_lower_24_15  -1
    Sx[24,15]  conditional_complement_upper_24_15  -1
    Sx[24,15]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[24,15]  floor_residual  -6.9819383258541636e-04
    Sx[24,15]  G_residual  -6.9819383258541636e-04
    Sx[25,0]  product_mass_25  1
    Sx[25,0]  product_lx_25_0  1
    Sx[25,0]  product_ux_25_0  1
    Sx[25,0]  product_Su_25_0  1
    Sx[25,0]  product_Sl_25_0  1
    Sx[25,0]  conditional_Sx_lower_25_0  1
    Sx[25,0]  conditional_Sx_upper_25_0  1
    Sx[25,0]  conditional_complement_lower_25_0  -1
    Sx[25,0]  conditional_complement_upper_25_0  -1
    Sx[25,0]  hard_cost_W_definition  -1.1782027736363687e-04
    Sx[25,0]  floor_residual  -1.1782027736363687e-04
    Sx[25,0]  G_residual  -1.1782027736363687e-04
    Sx[25,1]  product_mass_25  1
    Sx[25,1]  product_lx_25_1  1
    Sx[25,1]  product_ux_25_1  1
    Sx[25,1]  product_Su_25_1  1
    Sx[25,1]  product_Sl_25_1  1
    Sx[25,1]  total_product_lower  1
    Sx[25,1]  total_product_upper  1
    Sx[25,1]  conditional_Sx_lower_25_1  1
    Sx[25,1]  conditional_Sx_upper_25_1  1
    Sx[25,1]  conditional_complement_lower_25_1  -1
    Sx[25,1]  conditional_complement_upper_25_1  -1
    Sx[25,2]  product_mass_25  1
    Sx[25,2]  product_lx_25_2  1
    Sx[25,2]  product_ux_25_2  1
    Sx[25,2]  product_Su_25_2  1
    Sx[25,2]  product_Sl_25_2  1
    Sx[25,2]  total_product_lower  2
    Sx[25,2]  total_product_upper  2
    Sx[25,2]  conditional_Sx_lower_25_2  1
    Sx[25,2]  conditional_Sx_upper_25_2  1
    Sx[25,2]  conditional_complement_lower_25_2  -1
    Sx[25,2]  conditional_complement_upper_25_2  -1
    Sx[25,2]  hard_cost_W_definition  1.1782027736363687e-04
    Sx[25,2]  floor_residual  1.1782027736363687e-04
    Sx[25,2]  G_residual  1.1782027736363687e-04
    Sx[25,3]  product_mass_25  1
    Sx[25,3]  product_lx_25_3  1
    Sx[25,3]  product_ux_25_3  1
    Sx[25,3]  product_Su_25_3  1
    Sx[25,3]  product_Sl_25_3  1
    Sx[25,3]  total_product_lower  3
    Sx[25,3]  total_product_upper  3
    Sx[25,3]  conditional_Sx_lower_25_3  1
    Sx[25,3]  conditional_Sx_upper_25_3  1
    Sx[25,3]  conditional_complement_lower_25_3  -1
    Sx[25,3]  conditional_complement_upper_25_3  -1
    Sx[25,4]  product_mass_25  1
    Sx[25,4]  product_lx_25_4  1
    Sx[25,4]  product_ux_25_4  1
    Sx[25,4]  product_Su_25_4  1
    Sx[25,4]  product_Sl_25_4  1
    Sx[25,4]  total_product_lower  4
    Sx[25,4]  total_product_upper  4
    Sx[25,4]  conditional_Sx_lower_25_4  1
    Sx[25,4]  conditional_Sx_upper_25_4  1
    Sx[25,4]  conditional_complement_lower_25_4  -1
    Sx[25,4]  conditional_complement_upper_25_4  -1
    Sx[25,4]  hard_cost_W_definition  -1.1782027736363687e-04
    Sx[25,4]  floor_residual  -1.1782027736363687e-04
    Sx[25,4]  G_residual  -1.1782027736363687e-04
    Sx[26,0]  product_mass_26  1
    Sx[26,0]  product_lx_26_0  1
    Sx[26,0]  product_ux_26_0  1
    Sx[26,0]  product_Su_26_0  1
    Sx[26,0]  product_Sl_26_0  1
    Sx[26,0]  conditional_Sx_lower_26_0  1
    Sx[26,0]  conditional_Sx_upper_26_0  1
    Sx[26,0]  conditional_complement_lower_26_0  -1
    Sx[26,0]  conditional_complement_upper_26_0  -1
    Sx[26,0]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[26,0]  floor_residual  -2.3273157207916555e-04
    Sx[26,0]  G_residual  -2.3273157207916555e-04
    Sx[26,1]  product_mass_26  1
    Sx[26,1]  product_lx_26_1  1
    Sx[26,1]  product_ux_26_1  1
    Sx[26,1]  product_Su_26_1  1
    Sx[26,1]  product_Sl_26_1  1
    Sx[26,1]  total_product_lower  1
    Sx[26,1]  total_product_upper  1
    Sx[26,1]  conditional_Sx_lower_26_1  1
    Sx[26,1]  conditional_Sx_upper_26_1  1
    Sx[26,1]  conditional_complement_lower_26_1  -1
    Sx[26,1]  conditional_complement_upper_26_1  -1
    Sx[26,1]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[26,1]  floor_residual  -1.1636578603958278e-04
    Sx[26,1]  G_residual  -1.1636578603958278e-04
    Sx[26,2]  product_mass_26  1
    Sx[26,2]  product_lx_26_2  1
    Sx[26,2]  product_ux_26_2  1
    Sx[26,2]  product_Su_26_2  1
    Sx[26,2]  product_Sl_26_2  1
    Sx[26,2]  total_product_lower  2
    Sx[26,2]  total_product_upper  2
    Sx[26,2]  conditional_Sx_lower_26_2  1
    Sx[26,2]  conditional_Sx_upper_26_2  1
    Sx[26,2]  conditional_complement_lower_26_2  -1
    Sx[26,2]  conditional_complement_upper_26_2  -1
    Sx[26,3]  product_mass_26  1
    Sx[26,3]  product_lx_26_3  1
    Sx[26,3]  product_ux_26_3  1
    Sx[26,3]  product_Su_26_3  1
    Sx[26,3]  product_Sl_26_3  1
    Sx[26,3]  total_product_lower  3
    Sx[26,3]  total_product_upper  3
    Sx[26,3]  conditional_Sx_lower_26_3  1
    Sx[26,3]  conditional_Sx_upper_26_3  1
    Sx[26,3]  conditional_complement_lower_26_3  -1
    Sx[26,3]  conditional_complement_upper_26_3  -1
    Sx[26,3]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[26,3]  floor_residual  1.1636578603958278e-04
    Sx[26,3]  G_residual  1.1636578603958278e-04
    Sx[26,4]  product_mass_26  1
    Sx[26,4]  product_lx_26_4  1
    Sx[26,4]  product_ux_26_4  1
    Sx[26,4]  product_Su_26_4  1
    Sx[26,4]  product_Sl_26_4  1
    Sx[26,4]  total_product_lower  4
    Sx[26,4]  total_product_upper  4
    Sx[26,4]  conditional_Sx_lower_26_4  1
    Sx[26,4]  conditional_Sx_upper_26_4  1
    Sx[26,4]  conditional_complement_lower_26_4  -1
    Sx[26,4]  conditional_complement_upper_26_4  -1
    Sx[26,4]  hard_cost_W_definition  2.3273157207916555e-04
    Sx[26,4]  floor_residual  2.3273157207916555e-04
    Sx[26,4]  G_residual  2.3273157207916555e-04
    Sx[26,5]  product_mass_26  1
    Sx[26,5]  product_lx_26_5  1
    Sx[26,5]  product_ux_26_5  1
    Sx[26,5]  product_Su_26_5  1
    Sx[26,5]  product_Sl_26_5  1
    Sx[26,5]  total_product_lower  5
    Sx[26,5]  total_product_upper  5
    Sx[26,5]  conditional_Sx_lower_26_5  1
    Sx[26,5]  conditional_Sx_upper_26_5  1
    Sx[26,5]  conditional_complement_lower_26_5  -1
    Sx[26,5]  conditional_complement_upper_26_5  -1
    Sx[26,5]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[26,5]  floor_residual  1.1636578603958278e-04
    Sx[26,5]  G_residual  1.1636578603958278e-04
    Sx[26,6]  product_mass_26  1
    Sx[26,6]  product_lx_26_6  1
    Sx[26,6]  product_ux_26_6  1
    Sx[26,6]  product_Su_26_6  1
    Sx[26,6]  product_Sl_26_6  1
    Sx[26,6]  total_product_lower  6
    Sx[26,6]  total_product_upper  6
    Sx[26,6]  conditional_Sx_lower_26_6  1
    Sx[26,6]  conditional_Sx_upper_26_6  1
    Sx[26,6]  conditional_complement_lower_26_6  -1
    Sx[26,6]  conditional_complement_upper_26_6  -1
    Sx[26,7]  product_mass_26  1
    Sx[26,7]  product_lx_26_7  1
    Sx[26,7]  product_ux_26_7  1
    Sx[26,7]  product_Su_26_7  1
    Sx[26,7]  product_Sl_26_7  1
    Sx[26,7]  total_product_lower  7
    Sx[26,7]  total_product_upper  7
    Sx[26,7]  conditional_Sx_lower_26_7  1
    Sx[26,7]  conditional_Sx_upper_26_7  1
    Sx[26,7]  conditional_complement_lower_26_7  -1
    Sx[26,7]  conditional_complement_upper_26_7  -1
    Sx[26,7]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[26,7]  floor_residual  -1.1636578603958278e-04
    Sx[26,7]  G_residual  -1.1636578603958278e-04
    Sx[26,8]  product_mass_26  1
    Sx[26,8]  product_lx_26_8  1
    Sx[26,8]  product_ux_26_8  1
    Sx[26,8]  product_Su_26_8  1
    Sx[26,8]  product_Sl_26_8  1
    Sx[26,8]  total_product_lower  8
    Sx[26,8]  total_product_upper  8
    Sx[26,8]  conditional_Sx_lower_26_8  1
    Sx[26,8]  conditional_Sx_upper_26_8  1
    Sx[26,8]  conditional_complement_lower_26_8  -1
    Sx[26,8]  conditional_complement_upper_26_8  -1
    Sx[26,8]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[26,8]  floor_residual  -2.3273157207916555e-04
    Sx[26,8]  G_residual  -2.3273157207916555e-04
    Sx[27,0]  product_mass_27  1
    Sx[27,0]  product_lx_27_0  1
    Sx[27,0]  product_ux_27_0  1
    Sx[27,0]  product_Su_27_0  1
    Sx[27,0]  product_Sl_27_0  1
    Sx[27,0]  conditional_Sx_lower_27_0  1
    Sx[27,0]  conditional_Sx_upper_27_0  1
    Sx[27,0]  conditional_complement_lower_27_0  -1
    Sx[27,0]  conditional_complement_upper_27_0  -1
    Sx[27,0]  hard_cost_W_definition  -1.3091128838151053e-04
    Sx[27,0]  floor_residual  -1.3091128838151053e-04
    Sx[27,0]  G_residual  -1.3091128838151053e-04
    Sx[27,1]  product_mass_27  1
    Sx[27,1]  product_lx_27_1  1
    Sx[27,1]  product_ux_27_1  1
    Sx[27,1]  product_Su_27_1  1
    Sx[27,1]  product_Sl_27_1  1
    Sx[27,1]  total_product_lower  1
    Sx[27,1]  total_product_upper  1
    Sx[27,1]  conditional_Sx_lower_27_1  1
    Sx[27,1]  conditional_Sx_upper_27_1  1
    Sx[27,1]  conditional_complement_lower_27_1  -1
    Sx[27,1]  conditional_complement_upper_27_1  -1
    Sx[27,1]  hard_cost_W_definition  -4.3637096127170178e-05
    Sx[27,1]  floor_residual  -4.3637096127170178e-05
    Sx[27,1]  G_residual  -4.3637096127170178e-05
    Sx[27,2]  product_mass_27  1
    Sx[27,2]  product_lx_27_2  1
    Sx[27,2]  product_ux_27_2  1
    Sx[27,2]  product_Su_27_2  1
    Sx[27,2]  product_Sl_27_2  1
    Sx[27,2]  total_product_lower  2
    Sx[27,2]  total_product_upper  2
    Sx[27,2]  conditional_Sx_lower_27_2  1
    Sx[27,2]  conditional_Sx_upper_27_2  1
    Sx[27,2]  conditional_complement_lower_27_2  -1
    Sx[27,2]  conditional_complement_upper_27_2  -1
    Sx[27,2]  hard_cost_W_definition  4.3637096127170184e-05
    Sx[27,2]  floor_residual  4.3637096127170184e-05
    Sx[27,2]  G_residual  4.3637096127170184e-05
    Sx[27,3]  product_mass_27  1
    Sx[27,3]  product_lx_27_3  1
    Sx[27,3]  product_ux_27_3  1
    Sx[27,3]  product_Su_27_3  1
    Sx[27,3]  product_Sl_27_3  1
    Sx[27,3]  total_product_lower  3
    Sx[27,3]  total_product_upper  3
    Sx[27,3]  conditional_Sx_lower_27_3  1
    Sx[27,3]  conditional_Sx_upper_27_3  1
    Sx[27,3]  conditional_complement_lower_27_3  -1
    Sx[27,3]  conditional_complement_upper_27_3  -1
    Sx[27,3]  hard_cost_W_definition  1.3091128838151056e-04
    Sx[27,3]  floor_residual  1.3091128838151056e-04
    Sx[27,3]  G_residual  1.3091128838151056e-04
    Sx[27,4]  product_mass_27  1
    Sx[27,4]  product_lx_27_4  1
    Sx[27,4]  product_ux_27_4  1
    Sx[27,4]  product_Su_27_4  1
    Sx[27,4]  product_Sl_27_4  1
    Sx[27,4]  total_product_lower  4
    Sx[27,4]  total_product_upper  4
    Sx[27,4]  conditional_Sx_lower_27_4  1
    Sx[27,4]  conditional_Sx_upper_27_4  1
    Sx[27,4]  conditional_complement_lower_27_4  -1
    Sx[27,4]  conditional_complement_upper_27_4  -1
    Sx[27,4]  hard_cost_W_definition  4.3637096127170218e-05
    Sx[27,4]  floor_residual  4.3637096127170218e-05
    Sx[27,4]  G_residual  4.3637096127170218e-05
    Sx[27,5]  product_mass_27  1
    Sx[27,5]  product_lx_27_5  1
    Sx[27,5]  product_ux_27_5  1
    Sx[27,5]  product_Su_27_5  1
    Sx[27,5]  product_Sl_27_5  1
    Sx[27,5]  total_product_lower  5
    Sx[27,5]  total_product_upper  5
    Sx[27,5]  conditional_Sx_lower_27_5  1
    Sx[27,5]  conditional_Sx_upper_27_5  1
    Sx[27,5]  conditional_complement_lower_27_5  -1
    Sx[27,5]  conditional_complement_upper_27_5  -1
    Sx[27,5]  hard_cost_W_definition  -4.3637096127170150e-05
    Sx[27,5]  floor_residual  -4.3637096127170150e-05
    Sx[27,5]  G_residual  -4.3637096127170150e-05
    Sx[27,6]  product_mass_27  1
    Sx[27,6]  product_lx_27_6  1
    Sx[27,6]  product_ux_27_6  1
    Sx[27,6]  product_Su_27_6  1
    Sx[27,6]  product_Sl_27_6  1
    Sx[27,6]  total_product_lower  6
    Sx[27,6]  total_product_upper  6
    Sx[27,6]  conditional_Sx_lower_27_6  1
    Sx[27,6]  conditional_Sx_upper_27_6  1
    Sx[27,6]  conditional_complement_lower_27_6  -1
    Sx[27,6]  conditional_complement_upper_27_6  -1
    Sx[27,6]  hard_cost_W_definition  -1.3091128838151051e-04
    Sx[27,6]  floor_residual  -1.3091128838151051e-04
    Sx[27,6]  G_residual  -1.3091128838151051e-04
    Sx[28,0]  product_mass_28  1
    Sx[28,0]  product_lx_28_0  1
    Sx[28,0]  product_ux_28_0  1
    Sx[28,0]  product_Su_28_0  1
    Sx[28,0]  product_Sl_28_0  1
    Sx[28,0]  conditional_Sx_lower_28_0  1
    Sx[28,0]  conditional_Sx_upper_28_0  1
    Sx[28,0]  conditional_complement_lower_28_0  -1
    Sx[28,0]  conditional_complement_upper_28_0  -1
    Sx[28,0]  hard_cost_W_definition  -1.3091128838151053e-04
    Sx[28,0]  floor_residual  -1.3091128838151053e-04
    Sx[28,0]  G_residual  -1.3091128838151053e-04
    Sx[28,1]  product_mass_28  1
    Sx[28,1]  product_lx_28_1  1
    Sx[28,1]  product_ux_28_1  1
    Sx[28,1]  product_Su_28_1  1
    Sx[28,1]  product_Sl_28_1  1
    Sx[28,1]  total_product_lower  1
    Sx[28,1]  total_product_upper  1
    Sx[28,1]  conditional_Sx_lower_28_1  1
    Sx[28,1]  conditional_Sx_upper_28_1  1
    Sx[28,1]  conditional_complement_lower_28_1  -1
    Sx[28,1]  conditional_complement_upper_28_1  -1
    Sx[28,1]  hard_cost_W_definition  -4.3637096127170178e-05
    Sx[28,1]  floor_residual  -4.3637096127170178e-05
    Sx[28,1]  G_residual  -4.3637096127170178e-05
    Sx[28,2]  product_mass_28  1
    Sx[28,2]  product_lx_28_2  1
    Sx[28,2]  product_ux_28_2  1
    Sx[28,2]  product_Su_28_2  1
    Sx[28,2]  product_Sl_28_2  1
    Sx[28,2]  total_product_lower  2
    Sx[28,2]  total_product_upper  2
    Sx[28,2]  conditional_Sx_lower_28_2  1
    Sx[28,2]  conditional_Sx_upper_28_2  1
    Sx[28,2]  conditional_complement_lower_28_2  -1
    Sx[28,2]  conditional_complement_upper_28_2  -1
    Sx[28,2]  hard_cost_W_definition  4.3637096127170184e-05
    Sx[28,2]  floor_residual  4.3637096127170184e-05
    Sx[28,2]  G_residual  4.3637096127170184e-05
    Sx[28,3]  product_mass_28  1
    Sx[28,3]  product_lx_28_3  1
    Sx[28,3]  product_ux_28_3  1
    Sx[28,3]  product_Su_28_3  1
    Sx[28,3]  product_Sl_28_3  1
    Sx[28,3]  total_product_lower  3
    Sx[28,3]  total_product_upper  3
    Sx[28,3]  conditional_Sx_lower_28_3  1
    Sx[28,3]  conditional_Sx_upper_28_3  1
    Sx[28,3]  conditional_complement_lower_28_3  -1
    Sx[28,3]  conditional_complement_upper_28_3  -1
    Sx[28,3]  hard_cost_W_definition  1.3091128838151056e-04
    Sx[28,3]  floor_residual  1.3091128838151056e-04
    Sx[28,3]  G_residual  1.3091128838151056e-04
    Sx[28,4]  product_mass_28  1
    Sx[28,4]  product_lx_28_4  1
    Sx[28,4]  product_ux_28_4  1
    Sx[28,4]  product_Su_28_4  1
    Sx[28,4]  product_Sl_28_4  1
    Sx[28,4]  total_product_lower  4
    Sx[28,4]  total_product_upper  4
    Sx[28,4]  conditional_Sx_lower_28_4  1
    Sx[28,4]  conditional_Sx_upper_28_4  1
    Sx[28,4]  conditional_complement_lower_28_4  -1
    Sx[28,4]  conditional_complement_upper_28_4  -1
    Sx[28,4]  hard_cost_W_definition  4.3637096127170218e-05
    Sx[28,4]  floor_residual  4.3637096127170218e-05
    Sx[28,4]  G_residual  4.3637096127170218e-05
    Sx[28,5]  product_mass_28  1
    Sx[28,5]  product_lx_28_5  1
    Sx[28,5]  product_ux_28_5  1
    Sx[28,5]  product_Su_28_5  1
    Sx[28,5]  product_Sl_28_5  1
    Sx[28,5]  total_product_lower  5
    Sx[28,5]  total_product_upper  5
    Sx[28,5]  conditional_Sx_lower_28_5  1
    Sx[28,5]  conditional_Sx_upper_28_5  1
    Sx[28,5]  conditional_complement_lower_28_5  -1
    Sx[28,5]  conditional_complement_upper_28_5  -1
    Sx[28,5]  hard_cost_W_definition  -4.3637096127170150e-05
    Sx[28,5]  floor_residual  -4.3637096127170150e-05
    Sx[28,5]  G_residual  -4.3637096127170150e-05
    Sx[28,6]  product_mass_28  1
    Sx[28,6]  product_lx_28_6  1
    Sx[28,6]  product_ux_28_6  1
    Sx[28,6]  product_Su_28_6  1
    Sx[28,6]  product_Sl_28_6  1
    Sx[28,6]  total_product_lower  6
    Sx[28,6]  total_product_upper  6
    Sx[28,6]  conditional_Sx_lower_28_6  1
    Sx[28,6]  conditional_Sx_upper_28_6  1
    Sx[28,6]  conditional_complement_lower_28_6  -1
    Sx[28,6]  conditional_complement_upper_28_6  -1
    Sx[28,6]  hard_cost_W_definition  -1.3091128838151051e-04
    Sx[28,6]  floor_residual  -1.3091128838151051e-04
    Sx[28,6]  G_residual  -1.3091128838151051e-04
    Sx[29,0]  product_mass_29  1
    Sx[29,0]  product_lx_29_0  1
    Sx[29,0]  product_ux_29_0  1
    Sx[29,0]  product_Su_29_0  1
    Sx[29,0]  product_Sl_29_0  1
    Sx[29,0]  conditional_Sx_lower_29_0  1
    Sx[29,0]  conditional_Sx_upper_29_0  1
    Sx[29,0]  conditional_complement_lower_29_0  -1
    Sx[29,0]  conditional_complement_upper_29_0  -1
    Sx[29,0]  hard_cost_W_definition  -3.6364286046067603e-04
    Sx[29,0]  floor_residual  -3.6364286046067603e-04
    Sx[29,0]  G_residual  -3.6364286046067603e-04
    Sx[29,1]  product_mass_29  1
    Sx[29,1]  product_lx_29_1  1
    Sx[29,1]  product_ux_29_1  1
    Sx[29,1]  product_Su_29_1  1
    Sx[29,1]  product_Sl_29_1  1
    Sx[29,1]  total_product_lower  1
    Sx[29,1]  total_product_upper  1
    Sx[29,1]  conditional_Sx_lower_29_1  1
    Sx[29,1]  conditional_Sx_upper_29_1  1
    Sx[29,1]  conditional_complement_lower_29_1  -1
    Sx[29,1]  conditional_complement_upper_29_1  -1
    Sx[29,1]  hard_cost_W_definition  -2.1818571627640559e-04
    Sx[29,1]  floor_residual  -2.1818571627640559e-04
    Sx[29,1]  G_residual  -2.1818571627640559e-04
    Sx[29,2]  product_mass_29  1
    Sx[29,2]  product_lx_29_2  1
    Sx[29,2]  product_ux_29_2  1
    Sx[29,2]  product_Su_29_2  1
    Sx[29,2]  product_Sl_29_2  1
    Sx[29,2]  total_product_lower  2
    Sx[29,2]  total_product_upper  2
    Sx[29,2]  conditional_Sx_lower_29_2  1
    Sx[29,2]  conditional_Sx_upper_29_2  1
    Sx[29,2]  conditional_complement_lower_29_2  -1
    Sx[29,2]  conditional_complement_upper_29_2  -1
    Sx[29,2]  hard_cost_W_definition  -7.2728572092135138e-05
    Sx[29,2]  floor_residual  -7.2728572092135138e-05
    Sx[29,2]  G_residual  -7.2728572092135138e-05
    Sx[29,3]  product_mass_29  1
    Sx[29,3]  product_lx_29_3  1
    Sx[29,3]  product_ux_29_3  1
    Sx[29,3]  product_Su_29_3  1
    Sx[29,3]  product_Sl_29_3  1
    Sx[29,3]  total_product_lower  3
    Sx[29,3]  total_product_upper  3
    Sx[29,3]  conditional_Sx_lower_29_3  1
    Sx[29,3]  conditional_Sx_upper_29_3  1
    Sx[29,3]  conditional_complement_lower_29_3  -1
    Sx[29,3]  conditional_complement_upper_29_3  -1
    Sx[29,3]  hard_cost_W_definition  7.2728572092135315e-05
    Sx[29,3]  floor_residual  7.2728572092135315e-05
    Sx[29,3]  G_residual  7.2728572092135315e-05
    Sx[29,4]  product_mass_29  1
    Sx[29,4]  product_lx_29_4  1
    Sx[29,4]  product_ux_29_4  1
    Sx[29,4]  product_Su_29_4  1
    Sx[29,4]  product_Sl_29_4  1
    Sx[29,4]  total_product_lower  4
    Sx[29,4]  total_product_upper  4
    Sx[29,4]  conditional_Sx_lower_29_4  1
    Sx[29,4]  conditional_Sx_upper_29_4  1
    Sx[29,4]  conditional_complement_lower_29_4  -1
    Sx[29,4]  conditional_complement_upper_29_4  -1
    Sx[29,4]  hard_cost_W_definition  2.1818571627640578e-04
    Sx[29,4]  floor_residual  2.1818571627640578e-04
    Sx[29,4]  G_residual  2.1818571627640578e-04
    Sx[29,5]  product_mass_29  1
    Sx[29,5]  product_lx_29_5  1
    Sx[29,5]  product_ux_29_5  1
    Sx[29,5]  product_Su_29_5  1
    Sx[29,5]  product_Sl_29_5  1
    Sx[29,5]  total_product_lower  5
    Sx[29,5]  total_product_upper  5
    Sx[29,5]  conditional_Sx_lower_29_5  1
    Sx[29,5]  conditional_Sx_upper_29_5  1
    Sx[29,5]  conditional_complement_lower_29_5  -1
    Sx[29,5]  conditional_complement_upper_29_5  -1
    Sx[29,5]  hard_cost_W_definition  3.6364286046067619e-04
    Sx[29,5]  floor_residual  3.6364286046067619e-04
    Sx[29,5]  G_residual  3.6364286046067619e-04
    Sx[29,6]  product_mass_29  1
    Sx[29,6]  product_lx_29_6  1
    Sx[29,6]  product_ux_29_6  1
    Sx[29,6]  product_Su_29_6  1
    Sx[29,6]  product_Sl_29_6  1
    Sx[29,6]  total_product_lower  6
    Sx[29,6]  total_product_upper  6
    Sx[29,6]  conditional_Sx_lower_29_6  1
    Sx[29,6]  conditional_Sx_upper_29_6  1
    Sx[29,6]  conditional_complement_lower_29_6  -1
    Sx[29,6]  conditional_complement_upper_29_6  -1
    Sx[29,6]  hard_cost_W_definition  2.1818571627640570e-04
    Sx[29,6]  floor_residual  2.1818571627640570e-04
    Sx[29,6]  G_residual  2.1818571627640570e-04
    Sx[29,7]  product_mass_29  1
    Sx[29,7]  product_lx_29_7  1
    Sx[29,7]  product_ux_29_7  1
    Sx[29,7]  product_Su_29_7  1
    Sx[29,7]  product_Sl_29_7  1
    Sx[29,7]  total_product_lower  7
    Sx[29,7]  total_product_upper  7
    Sx[29,7]  conditional_Sx_lower_29_7  1
    Sx[29,7]  conditional_Sx_upper_29_7  1
    Sx[29,7]  conditional_complement_lower_29_7  -1
    Sx[29,7]  conditional_complement_upper_29_7  -1
    Sx[29,7]  hard_cost_W_definition  7.2728572092135233e-05
    Sx[29,7]  floor_residual  7.2728572092135233e-05
    Sx[29,7]  G_residual  7.2728572092135233e-05
    Sx[29,8]  product_mass_29  1
    Sx[29,8]  product_lx_29_8  1
    Sx[29,8]  product_ux_29_8  1
    Sx[29,8]  product_Su_29_8  1
    Sx[29,8]  product_Sl_29_8  1
    Sx[29,8]  total_product_lower  8
    Sx[29,8]  total_product_upper  8
    Sx[29,8]  conditional_Sx_lower_29_8  1
    Sx[29,8]  conditional_Sx_upper_29_8  1
    Sx[29,8]  conditional_complement_lower_29_8  -1
    Sx[29,8]  conditional_complement_upper_29_8  -1
    Sx[29,8]  hard_cost_W_definition  -7.2728572092135220e-05
    Sx[29,8]  floor_residual  -7.2728572092135220e-05
    Sx[29,8]  G_residual  -7.2728572092135220e-05
    Sx[29,9]  product_mass_29  1
    Sx[29,9]  product_lx_29_9  1
    Sx[29,9]  product_ux_29_9  1
    Sx[29,9]  product_Su_29_9  1
    Sx[29,9]  product_Sl_29_9  1
    Sx[29,9]  total_product_lower  9
    Sx[29,9]  total_product_upper  9
    Sx[29,9]  conditional_Sx_lower_29_9  1
    Sx[29,9]  conditional_Sx_upper_29_9  1
    Sx[29,9]  conditional_complement_lower_29_9  -1
    Sx[29,9]  conditional_complement_upper_29_9  -1
    Sx[29,9]  hard_cost_W_definition  -2.1818571627640567e-04
    Sx[29,9]  floor_residual  -2.1818571627640567e-04
    Sx[29,9]  G_residual  -2.1818571627640567e-04
    Sx[29,10]  product_mass_29  1
    Sx[29,10]  product_lx_29_10  1
    Sx[29,10]  product_ux_29_10  1
    Sx[29,10]  product_Su_29_10  1
    Sx[29,10]  product_Sl_29_10  1
    Sx[29,10]  total_product_lower  10
    Sx[29,10]  total_product_upper  10
    Sx[29,10]  conditional_Sx_lower_29_10  1
    Sx[29,10]  conditional_Sx_upper_29_10  1
    Sx[29,10]  conditional_complement_lower_29_10  -1
    Sx[29,10]  conditional_complement_upper_29_10  -1
    Sx[29,10]  hard_cost_W_definition  -3.6364286046067614e-04
    Sx[29,10]  floor_residual  -3.6364286046067614e-04
    Sx[29,10]  G_residual  -3.6364286046067614e-04
    Sx[30,0]  product_mass_30  1
    Sx[30,0]  product_lx_30_0  1
    Sx[30,0]  product_ux_30_0  1
    Sx[30,0]  product_Su_30_0  1
    Sx[30,0]  product_Sl_30_0  1
    Sx[30,0]  conditional_Sx_lower_30_0  1
    Sx[30,0]  conditional_Sx_upper_30_0  1
    Sx[30,0]  conditional_complement_lower_30_0  -1
    Sx[30,0]  conditional_complement_upper_30_0  -1
    Sx[30,0]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[30,0]  floor_residual  -2.3273157207916555e-04
    Sx[30,0]  G_residual  -2.3273157207916555e-04
    Sx[30,1]  product_mass_30  1
    Sx[30,1]  product_lx_30_1  1
    Sx[30,1]  product_ux_30_1  1
    Sx[30,1]  product_Su_30_1  1
    Sx[30,1]  product_Sl_30_1  1
    Sx[30,1]  total_product_lower  1
    Sx[30,1]  total_product_upper  1
    Sx[30,1]  conditional_Sx_lower_30_1  1
    Sx[30,1]  conditional_Sx_upper_30_1  1
    Sx[30,1]  conditional_complement_lower_30_1  -1
    Sx[30,1]  conditional_complement_upper_30_1  -1
    Sx[30,1]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[30,1]  floor_residual  -1.1636578603958278e-04
    Sx[30,1]  G_residual  -1.1636578603958278e-04
    Sx[30,2]  product_mass_30  1
    Sx[30,2]  product_lx_30_2  1
    Sx[30,2]  product_ux_30_2  1
    Sx[30,2]  product_Su_30_2  1
    Sx[30,2]  product_Sl_30_2  1
    Sx[30,2]  total_product_lower  2
    Sx[30,2]  total_product_upper  2
    Sx[30,2]  conditional_Sx_lower_30_2  1
    Sx[30,2]  conditional_Sx_upper_30_2  1
    Sx[30,2]  conditional_complement_lower_30_2  -1
    Sx[30,2]  conditional_complement_upper_30_2  -1
    Sx[30,3]  product_mass_30  1
    Sx[30,3]  product_lx_30_3  1
    Sx[30,3]  product_ux_30_3  1
    Sx[30,3]  product_Su_30_3  1
    Sx[30,3]  product_Sl_30_3  1
    Sx[30,3]  total_product_lower  3
    Sx[30,3]  total_product_upper  3
    Sx[30,3]  conditional_Sx_lower_30_3  1
    Sx[30,3]  conditional_Sx_upper_30_3  1
    Sx[30,3]  conditional_complement_lower_30_3  -1
    Sx[30,3]  conditional_complement_upper_30_3  -1
    Sx[30,3]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[30,3]  floor_residual  1.1636578603958278e-04
    Sx[30,3]  G_residual  1.1636578603958278e-04
    Sx[30,4]  product_mass_30  1
    Sx[30,4]  product_lx_30_4  1
    Sx[30,4]  product_ux_30_4  1
    Sx[30,4]  product_Su_30_4  1
    Sx[30,4]  product_Sl_30_4  1
    Sx[30,4]  total_product_lower  4
    Sx[30,4]  total_product_upper  4
    Sx[30,4]  conditional_Sx_lower_30_4  1
    Sx[30,4]  conditional_Sx_upper_30_4  1
    Sx[30,4]  conditional_complement_lower_30_4  -1
    Sx[30,4]  conditional_complement_upper_30_4  -1
    Sx[30,4]  hard_cost_W_definition  2.3273157207916555e-04
    Sx[30,4]  floor_residual  2.3273157207916555e-04
    Sx[30,4]  G_residual  2.3273157207916555e-04
    Sx[30,5]  product_mass_30  1
    Sx[30,5]  product_lx_30_5  1
    Sx[30,5]  product_ux_30_5  1
    Sx[30,5]  product_Su_30_5  1
    Sx[30,5]  product_Sl_30_5  1
    Sx[30,5]  total_product_lower  5
    Sx[30,5]  total_product_upper  5
    Sx[30,5]  conditional_Sx_lower_30_5  1
    Sx[30,5]  conditional_Sx_upper_30_5  1
    Sx[30,5]  conditional_complement_lower_30_5  -1
    Sx[30,5]  conditional_complement_upper_30_5  -1
    Sx[30,5]  hard_cost_W_definition  1.1636578603958278e-04
    Sx[30,5]  floor_residual  1.1636578603958278e-04
    Sx[30,5]  G_residual  1.1636578603958278e-04
    Sx[30,6]  product_mass_30  1
    Sx[30,6]  product_lx_30_6  1
    Sx[30,6]  product_ux_30_6  1
    Sx[30,6]  product_Su_30_6  1
    Sx[30,6]  product_Sl_30_6  1
    Sx[30,6]  total_product_lower  6
    Sx[30,6]  total_product_upper  6
    Sx[30,6]  conditional_Sx_lower_30_6  1
    Sx[30,6]  conditional_Sx_upper_30_6  1
    Sx[30,6]  conditional_complement_lower_30_6  -1
    Sx[30,6]  conditional_complement_upper_30_6  -1
    Sx[30,7]  product_mass_30  1
    Sx[30,7]  product_lx_30_7  1
    Sx[30,7]  product_ux_30_7  1
    Sx[30,7]  product_Su_30_7  1
    Sx[30,7]  product_Sl_30_7  1
    Sx[30,7]  total_product_lower  7
    Sx[30,7]  total_product_upper  7
    Sx[30,7]  conditional_Sx_lower_30_7  1
    Sx[30,7]  conditional_Sx_upper_30_7  1
    Sx[30,7]  conditional_complement_lower_30_7  -1
    Sx[30,7]  conditional_complement_upper_30_7  -1
    Sx[30,7]  hard_cost_W_definition  -1.1636578603958278e-04
    Sx[30,7]  floor_residual  -1.1636578603958278e-04
    Sx[30,7]  G_residual  -1.1636578603958278e-04
    Sx[30,8]  product_mass_30  1
    Sx[30,8]  product_lx_30_8  1
    Sx[30,8]  product_ux_30_8  1
    Sx[30,8]  product_Su_30_8  1
    Sx[30,8]  product_Sl_30_8  1
    Sx[30,8]  total_product_lower  8
    Sx[30,8]  total_product_upper  8
    Sx[30,8]  conditional_Sx_lower_30_8  1
    Sx[30,8]  conditional_Sx_upper_30_8  1
    Sx[30,8]  conditional_complement_lower_30_8  -1
    Sx[30,8]  conditional_complement_upper_30_8  -1
    Sx[30,8]  hard_cost_W_definition  -2.3273157207916555e-04
    Sx[30,8]  floor_residual  -2.3273157207916555e-04
    Sx[30,8]  G_residual  -2.3273157207916555e-04
    Sx[31,0]  product_mass_31  1
    Sx[31,0]  product_lx_31_0  1
    Sx[31,0]  product_ux_31_0  1
    Sx[31,0]  product_Su_31_0  1
    Sx[31,0]  product_Sl_31_0  1
    Sx[31,0]  conditional_Sx_lower_31_0  1
    Sx[31,0]  conditional_Sx_upper_31_0  1
    Sx[31,0]  conditional_complement_lower_31_0  -1
    Sx[31,0]  conditional_complement_upper_31_0  -1
    Sx[31,0]  hard_cost_W_definition  -5.2364515352604213e-04
    Sx[31,0]  floor_residual  -5.2364515352604213e-04
    Sx[31,0]  G_residual  -5.2364515352604213e-04
    Sx[31,1]  product_mass_31  1
    Sx[31,1]  product_lx_31_1  1
    Sx[31,1]  product_ux_31_1  1
    Sx[31,1]  product_Su_31_1  1
    Sx[31,1]  product_Sl_31_1  1
    Sx[31,1]  total_product_lower  1
    Sx[31,1]  total_product_upper  1
    Sx[31,1]  conditional_Sx_lower_31_1  1
    Sx[31,1]  conditional_Sx_upper_31_1  1
    Sx[31,1]  conditional_complement_lower_31_1  -1
    Sx[31,1]  conditional_complement_upper_31_1  -1
    Sx[31,1]  hard_cost_W_definition  -3.4909676901736142e-04
    Sx[31,1]  floor_residual  -3.4909676901736142e-04
    Sx[31,1]  G_residual  -3.4909676901736142e-04
    Sx[31,2]  product_mass_31  1
    Sx[31,2]  product_lx_31_2  1
    Sx[31,2]  product_ux_31_2  1
    Sx[31,2]  product_Su_31_2  1
    Sx[31,2]  product_Sl_31_2  1
    Sx[31,2]  total_product_lower  2
    Sx[31,2]  total_product_upper  2
    Sx[31,2]  conditional_Sx_lower_31_2  1
    Sx[31,2]  conditional_Sx_upper_31_2  1
    Sx[31,2]  conditional_complement_lower_31_2  -1
    Sx[31,2]  conditional_complement_upper_31_2  -1
    Sx[31,2]  hard_cost_W_definition  -1.7454838450868071e-04
    Sx[31,2]  floor_residual  -1.7454838450868071e-04
    Sx[31,2]  G_residual  -1.7454838450868071e-04
    Sx[31,3]  product_mass_31  1
    Sx[31,3]  product_lx_31_3  1
    Sx[31,3]  product_ux_31_3  1
    Sx[31,3]  product_Su_31_3  1
    Sx[31,3]  product_Sl_31_3  1
    Sx[31,3]  total_product_lower  3
    Sx[31,3]  total_product_upper  3
    Sx[31,3]  conditional_Sx_lower_31_3  1
    Sx[31,3]  conditional_Sx_upper_31_3  1
    Sx[31,3]  conditional_complement_lower_31_3  -1
    Sx[31,3]  conditional_complement_upper_31_3  -1
    Sx[31,4]  product_mass_31  1
    Sx[31,4]  product_lx_31_4  1
    Sx[31,4]  product_ux_31_4  1
    Sx[31,4]  product_Su_31_4  1
    Sx[31,4]  product_Sl_31_4  1
    Sx[31,4]  total_product_lower  4
    Sx[31,4]  total_product_upper  4
    Sx[31,4]  conditional_Sx_lower_31_4  1
    Sx[31,4]  conditional_Sx_upper_31_4  1
    Sx[31,4]  conditional_complement_lower_31_4  -1
    Sx[31,4]  conditional_complement_upper_31_4  -1
    Sx[31,4]  hard_cost_W_definition  1.7454838450868074e-04
    Sx[31,4]  floor_residual  1.7454838450868074e-04
    Sx[31,4]  G_residual  1.7454838450868074e-04
    Sx[31,5]  product_mass_31  1
    Sx[31,5]  product_lx_31_5  1
    Sx[31,5]  product_ux_31_5  1
    Sx[31,5]  product_Su_31_5  1
    Sx[31,5]  product_Sl_31_5  1
    Sx[31,5]  total_product_lower  5
    Sx[31,5]  total_product_upper  5
    Sx[31,5]  conditional_Sx_lower_31_5  1
    Sx[31,5]  conditional_Sx_upper_31_5  1
    Sx[31,5]  conditional_complement_lower_31_5  -1
    Sx[31,5]  conditional_complement_upper_31_5  -1
    Sx[31,5]  hard_cost_W_definition  3.4909676901736148e-04
    Sx[31,5]  floor_residual  3.4909676901736148e-04
    Sx[31,5]  G_residual  3.4909676901736148e-04
    Sx[31,6]  product_mass_31  1
    Sx[31,6]  product_lx_31_6  1
    Sx[31,6]  product_ux_31_6  1
    Sx[31,6]  product_Su_31_6  1
    Sx[31,6]  product_Sl_31_6  1
    Sx[31,6]  total_product_lower  6
    Sx[31,6]  total_product_upper  6
    Sx[31,6]  conditional_Sx_lower_31_6  1
    Sx[31,6]  conditional_Sx_upper_31_6  1
    Sx[31,6]  conditional_complement_lower_31_6  -1
    Sx[31,6]  conditional_complement_upper_31_6  -1
    Sx[31,6]  hard_cost_W_definition  5.2364515352604224e-04
    Sx[31,6]  floor_residual  5.2364515352604224e-04
    Sx[31,6]  G_residual  5.2364515352604224e-04
    Sx[31,7]  product_mass_31  1
    Sx[31,7]  product_lx_31_7  1
    Sx[31,7]  product_ux_31_7  1
    Sx[31,7]  product_Su_31_7  1
    Sx[31,7]  product_Sl_31_7  1
    Sx[31,7]  total_product_lower  7
    Sx[31,7]  total_product_upper  7
    Sx[31,7]  conditional_Sx_lower_31_7  1
    Sx[31,7]  conditional_Sx_upper_31_7  1
    Sx[31,7]  conditional_complement_lower_31_7  -1
    Sx[31,7]  conditional_complement_upper_31_7  -1
    Sx[31,7]  hard_cost_W_definition  3.4909676901736164e-04
    Sx[31,7]  floor_residual  3.4909676901736164e-04
    Sx[31,7]  G_residual  3.4909676901736164e-04
    Sx[31,8]  product_mass_31  1
    Sx[31,8]  product_lx_31_8  1
    Sx[31,8]  product_ux_31_8  1
    Sx[31,8]  product_Su_31_8  1
    Sx[31,8]  product_Sl_31_8  1
    Sx[31,8]  total_product_lower  8
    Sx[31,8]  total_product_upper  8
    Sx[31,8]  conditional_Sx_lower_31_8  1
    Sx[31,8]  conditional_Sx_upper_31_8  1
    Sx[31,8]  conditional_complement_lower_31_8  -1
    Sx[31,8]  conditional_complement_upper_31_8  -1
    Sx[31,8]  hard_cost_W_definition  1.7454838450868087e-04
    Sx[31,8]  floor_residual  1.7454838450868087e-04
    Sx[31,8]  G_residual  1.7454838450868087e-04
    Sx[31,9]  product_mass_31  1
    Sx[31,9]  product_lx_31_9  1
    Sx[31,9]  product_ux_31_9  1
    Sx[31,9]  product_Su_31_9  1
    Sx[31,9]  product_Sl_31_9  1
    Sx[31,9]  total_product_lower  9
    Sx[31,9]  total_product_upper  9
    Sx[31,9]  conditional_Sx_lower_31_9  1
    Sx[31,9]  conditional_Sx_upper_31_9  1
    Sx[31,9]  conditional_complement_lower_31_9  -1
    Sx[31,9]  conditional_complement_upper_31_9  -1
    Sx[31,10]  product_mass_31  1
    Sx[31,10]  product_lx_31_10  1
    Sx[31,10]  product_ux_31_10  1
    Sx[31,10]  product_Su_31_10  1
    Sx[31,10]  product_Sl_31_10  1
    Sx[31,10]  total_product_lower  10
    Sx[31,10]  total_product_upper  10
    Sx[31,10]  conditional_Sx_lower_31_10  1
    Sx[31,10]  conditional_Sx_upper_31_10  1
    Sx[31,10]  conditional_complement_lower_31_10  -1
    Sx[31,10]  conditional_complement_upper_31_10  -1
    Sx[31,10]  hard_cost_W_definition  -1.7454838450868060e-04
    Sx[31,10]  floor_residual  -1.7454838450868060e-04
    Sx[31,10]  G_residual  -1.7454838450868060e-04
    Sx[31,11]  product_mass_31  1
    Sx[31,11]  product_lx_31_11  1
    Sx[31,11]  product_ux_31_11  1
    Sx[31,11]  product_Su_31_11  1
    Sx[31,11]  product_Sl_31_11  1
    Sx[31,11]  total_product_lower  11
    Sx[31,11]  total_product_upper  11
    Sx[31,11]  conditional_Sx_lower_31_11  1
    Sx[31,11]  conditional_Sx_upper_31_11  1
    Sx[31,11]  conditional_complement_lower_31_11  -1
    Sx[31,11]  conditional_complement_upper_31_11  -1
    Sx[31,11]  hard_cost_W_definition  -3.4909676901736131e-04
    Sx[31,11]  floor_residual  -3.4909676901736131e-04
    Sx[31,11]  G_residual  -3.4909676901736131e-04
    Sx[32,0]  product_mass_32  1
    Sx[32,0]  product_lx_32_0  1
    Sx[32,0]  product_ux_32_0  1
    Sx[32,0]  product_Su_32_0  1
    Sx[32,0]  product_Sl_32_0  1
    Sx[32,0]  conditional_Sx_lower_32_0  1
    Sx[32,0]  conditional_Sx_upper_32_0  1
    Sx[32,0]  conditional_complement_lower_32_0  -1
    Sx[32,0]  conditional_complement_upper_32_0  -1
    Sx[32,0]  hard_cost_W_definition  -1.0472913543434388e-03
    Sx[32,0]  floor_residual  -1.0472913543434388e-03
    Sx[32,0]  G_residual  -1.0472913543434388e-03
    Sx[32,1]  product_mass_32  1
    Sx[32,1]  product_lx_32_1  1
    Sx[32,1]  product_ux_32_1  1
    Sx[32,1]  product_Su_32_1  1
    Sx[32,1]  product_Sl_32_1  1
    Sx[32,1]  total_product_lower  1
    Sx[32,1]  total_product_upper  1
    Sx[32,1]  conditional_Sx_lower_32_1  1
    Sx[32,1]  conditional_Sx_upper_32_1  1
    Sx[32,1]  conditional_complement_lower_32_1  -1
    Sx[32,1]  conditional_complement_upper_32_1  -1
    Sx[32,1]  hard_cost_W_definition  -7.8546851575757911e-04
    Sx[32,1]  floor_residual  -7.8546851575757911e-04
    Sx[32,1]  G_residual  -7.8546851575757911e-04
    Sx[32,2]  product_mass_32  1
    Sx[32,2]  product_lx_32_2  1
    Sx[32,2]  product_ux_32_2  1
    Sx[32,2]  product_Su_32_2  1
    Sx[32,2]  product_Sl_32_2  1
    Sx[32,2]  total_product_lower  2
    Sx[32,2]  total_product_upper  2
    Sx[32,2]  conditional_Sx_lower_32_2  1
    Sx[32,2]  conditional_Sx_upper_32_2  1
    Sx[32,2]  conditional_complement_lower_32_2  -1
    Sx[32,2]  conditional_complement_upper_32_2  -1
    Sx[32,2]  hard_cost_W_definition  -5.2364567717171941e-04
    Sx[32,2]  floor_residual  -5.2364567717171941e-04
    Sx[32,2]  G_residual  -5.2364567717171941e-04
    Sx[32,3]  product_mass_32  1
    Sx[32,3]  product_lx_32_3  1
    Sx[32,3]  product_ux_32_3  1
    Sx[32,3]  product_Su_32_3  1
    Sx[32,3]  product_Sl_32_3  1
    Sx[32,3]  total_product_lower  3
    Sx[32,3]  total_product_upper  3
    Sx[32,3]  conditional_Sx_lower_32_3  1
    Sx[32,3]  conditional_Sx_upper_32_3  1
    Sx[32,3]  conditional_complement_lower_32_3  -1
    Sx[32,3]  conditional_complement_upper_32_3  -1
    Sx[32,3]  hard_cost_W_definition  -2.6182283858585981e-04
    Sx[32,3]  floor_residual  -2.6182283858585981e-04
    Sx[32,3]  G_residual  -2.6182283858585981e-04
    Sx[32,4]  product_mass_32  1
    Sx[32,4]  product_lx_32_4  1
    Sx[32,4]  product_ux_32_4  1
    Sx[32,4]  product_Su_32_4  1
    Sx[32,4]  product_Sl_32_4  1
    Sx[32,4]  total_product_lower  4
    Sx[32,4]  total_product_upper  4
    Sx[32,4]  conditional_Sx_lower_32_4  1
    Sx[32,4]  conditional_Sx_upper_32_4  1
    Sx[32,4]  conditional_complement_lower_32_4  -1
    Sx[32,4]  conditional_complement_upper_32_4  -1
    Sx[32,5]  product_mass_32  1
    Sx[32,5]  product_lx_32_5  1
    Sx[32,5]  product_ux_32_5  1
    Sx[32,5]  product_Su_32_5  1
    Sx[32,5]  product_Sl_32_5  1
    Sx[32,5]  total_product_lower  5
    Sx[32,5]  total_product_upper  5
    Sx[32,5]  conditional_Sx_lower_32_5  1
    Sx[32,5]  conditional_Sx_upper_32_5  1
    Sx[32,5]  conditional_complement_lower_32_5  -1
    Sx[32,5]  conditional_complement_upper_32_5  -1
    Sx[32,5]  hard_cost_W_definition  2.6182283858585959e-04
    Sx[32,5]  floor_residual  2.6182283858585959e-04
    Sx[32,5]  G_residual  2.6182283858585959e-04
    Sx[32,6]  product_mass_32  1
    Sx[32,6]  product_lx_32_6  1
    Sx[32,6]  product_ux_32_6  1
    Sx[32,6]  product_Su_32_6  1
    Sx[32,6]  product_Sl_32_6  1
    Sx[32,6]  total_product_lower  6
    Sx[32,6]  total_product_upper  6
    Sx[32,6]  conditional_Sx_lower_32_6  1
    Sx[32,6]  conditional_Sx_upper_32_6  1
    Sx[32,6]  conditional_complement_lower_32_6  -1
    Sx[32,6]  conditional_complement_upper_32_6  -1
    Sx[32,6]  hard_cost_W_definition  5.2364567717171930e-04
    Sx[32,6]  floor_residual  5.2364567717171930e-04
    Sx[32,6]  G_residual  5.2364567717171930e-04
    Sx[32,7]  product_mass_32  1
    Sx[32,7]  product_lx_32_7  1
    Sx[32,7]  product_ux_32_7  1
    Sx[32,7]  product_Su_32_7  1
    Sx[32,7]  product_Sl_32_7  1
    Sx[32,7]  total_product_lower  7
    Sx[32,7]  total_product_upper  7
    Sx[32,7]  conditional_Sx_lower_32_7  1
    Sx[32,7]  conditional_Sx_upper_32_7  1
    Sx[32,7]  conditional_complement_lower_32_7  -1
    Sx[32,7]  conditional_complement_upper_32_7  -1
    Sx[32,7]  hard_cost_W_definition  0.000785468515757579
    Sx[32,7]  floor_residual  0.000785468515757579
    Sx[32,7]  G_residual  0.000785468515757579
    Sx[32,8]  product_mass_32  1
    Sx[32,8]  product_lx_32_8  1
    Sx[32,8]  product_ux_32_8  1
    Sx[32,8]  product_Su_32_8  1
    Sx[32,8]  product_Sl_32_8  1
    Sx[32,8]  total_product_lower  8
    Sx[32,8]  total_product_upper  8
    Sx[32,8]  conditional_Sx_lower_32_8  1
    Sx[32,8]  conditional_Sx_upper_32_8  1
    Sx[32,8]  conditional_complement_lower_32_8  -1
    Sx[32,8]  conditional_complement_upper_32_8  -1
    Sx[32,8]  hard_cost_W_definition  1.0472913543434388e-03
    Sx[32,8]  floor_residual  1.0472913543434388e-03
    Sx[32,8]  G_residual  1.0472913543434388e-03
    Sx[32,9]  product_mass_32  1
    Sx[32,9]  product_lx_32_9  1
    Sx[32,9]  product_ux_32_9  1
    Sx[32,9]  product_Su_32_9  1
    Sx[32,9]  product_Sl_32_9  1
    Sx[32,9]  total_product_lower  9
    Sx[32,9]  total_product_upper  9
    Sx[32,9]  conditional_Sx_lower_32_9  1
    Sx[32,9]  conditional_Sx_upper_32_9  1
    Sx[32,9]  conditional_complement_lower_32_9  -1
    Sx[32,9]  conditional_complement_upper_32_9  -1
    Sx[32,9]  hard_cost_W_definition  1.3091141929292985e-03
    Sx[32,9]  floor_residual  1.3091141929292985e-03
    Sx[32,9]  G_residual  1.3091141929292985e-03
    Sx[32,10]  product_mass_32  1
    Sx[32,10]  product_lx_32_10  1
    Sx[32,10]  product_ux_32_10  1
    Sx[32,10]  product_Su_32_10  1
    Sx[32,10]  product_Sl_32_10  1
    Sx[32,10]  total_product_lower  10
    Sx[32,10]  total_product_upper  10
    Sx[32,10]  conditional_Sx_lower_32_10  1
    Sx[32,10]  conditional_Sx_upper_32_10  1
    Sx[32,10]  conditional_complement_lower_32_10  -1
    Sx[32,10]  conditional_complement_upper_32_10  -1
    Sx[32,10]  hard_cost_W_definition  1.0472913543434390e-03
    Sx[32,10]  floor_residual  1.0472913543434390e-03
    Sx[32,10]  G_residual  1.0472913543434390e-03
    Sx[32,11]  product_mass_32  1
    Sx[32,11]  product_lx_32_11  1
    Sx[32,11]  product_ux_32_11  1
    Sx[32,11]  product_Su_32_11  1
    Sx[32,11]  product_Sl_32_11  1
    Sx[32,11]  total_product_lower  11
    Sx[32,11]  total_product_upper  11
    Sx[32,11]  conditional_Sx_lower_32_11  1
    Sx[32,11]  conditional_Sx_upper_32_11  1
    Sx[32,11]  conditional_complement_lower_32_11  -1
    Sx[32,11]  conditional_complement_upper_32_11  -1
    Sx[32,11]  hard_cost_W_definition  7.8546851575757922e-04
    Sx[32,11]  floor_residual  7.8546851575757922e-04
    Sx[32,11]  G_residual  7.8546851575757922e-04
    Sx[32,12]  product_mass_32  1
    Sx[32,12]  product_lx_32_12  1
    Sx[32,12]  product_ux_32_12  1
    Sx[32,12]  product_Su_32_12  1
    Sx[32,12]  product_Sl_32_12  1
    Sx[32,12]  total_product_lower  12
    Sx[32,12]  total_product_upper  12
    Sx[32,12]  conditional_Sx_lower_32_12  1
    Sx[32,12]  conditional_Sx_upper_32_12  1
    Sx[32,12]  conditional_complement_lower_32_12  -1
    Sx[32,12]  conditional_complement_upper_32_12  -1
    Sx[32,12]  hard_cost_W_definition  5.2364567717171951e-04
    Sx[32,12]  floor_residual  5.2364567717171951e-04
    Sx[32,12]  G_residual  5.2364567717171951e-04
    Sx[32,13]  product_mass_32  1
    Sx[32,13]  product_lx_32_13  1
    Sx[32,13]  product_ux_32_13  1
    Sx[32,13]  product_Su_32_13  1
    Sx[32,13]  product_Sl_32_13  1
    Sx[32,13]  total_product_lower  13
    Sx[32,13]  total_product_upper  13
    Sx[32,13]  conditional_Sx_lower_32_13  1
    Sx[32,13]  conditional_Sx_upper_32_13  1
    Sx[32,13]  conditional_complement_lower_32_13  -1
    Sx[32,13]  conditional_complement_upper_32_13  -1
    Sx[32,13]  hard_cost_W_definition  2.6182283858585987e-04
    Sx[32,13]  floor_residual  2.6182283858585987e-04
    Sx[32,13]  G_residual  2.6182283858585987e-04
    Sx[32,14]  product_mass_32  1
    Sx[32,14]  product_lx_32_14  1
    Sx[32,14]  product_ux_32_14  1
    Sx[32,14]  product_Su_32_14  1
    Sx[32,14]  product_Sl_32_14  1
    Sx[32,14]  total_product_lower  14
    Sx[32,14]  total_product_upper  14
    Sx[32,14]  conditional_Sx_lower_32_14  1
    Sx[32,14]  conditional_Sx_upper_32_14  1
    Sx[32,14]  conditional_complement_lower_32_14  -1
    Sx[32,14]  conditional_complement_upper_32_14  -1
    Sx[32,15]  product_mass_32  1
    Sx[32,15]  product_lx_32_15  1
    Sx[32,15]  product_ux_32_15  1
    Sx[32,15]  product_Su_32_15  1
    Sx[32,15]  product_Sl_32_15  1
    Sx[32,15]  total_product_lower  15
    Sx[32,15]  total_product_upper  15
    Sx[32,15]  conditional_Sx_lower_32_15  1
    Sx[32,15]  conditional_Sx_upper_32_15  1
    Sx[32,15]  conditional_complement_lower_32_15  -1
    Sx[32,15]  conditional_complement_upper_32_15  -1
    Sx[32,15]  hard_cost_W_definition  -2.6182283858585954e-04
    Sx[32,15]  floor_residual  -2.6182283858585954e-04
    Sx[32,15]  G_residual  -2.6182283858585954e-04
    Sx[32,16]  product_mass_32  1
    Sx[32,16]  product_lx_32_16  1
    Sx[32,16]  product_ux_32_16  1
    Sx[32,16]  product_Su_32_16  1
    Sx[32,16]  product_Sl_32_16  1
    Sx[32,16]  total_product_lower  16
    Sx[32,16]  total_product_upper  16
    Sx[32,16]  conditional_Sx_lower_32_16  1
    Sx[32,16]  conditional_Sx_upper_32_16  1
    Sx[32,16]  conditional_complement_lower_32_16  -1
    Sx[32,16]  conditional_complement_upper_32_16  -1
    Sx[32,16]  hard_cost_W_definition  -5.2364567717171919e-04
    Sx[32,16]  floor_residual  -5.2364567717171919e-04
    Sx[32,16]  G_residual  -5.2364567717171919e-04
    Sx[32,17]  product_mass_32  1
    Sx[32,17]  product_lx_32_17  1
    Sx[32,17]  product_ux_32_17  1
    Sx[32,17]  product_Su_32_17  1
    Sx[32,17]  product_Sl_32_17  1
    Sx[32,17]  total_product_lower  17
    Sx[32,17]  total_product_upper  17
    Sx[32,17]  conditional_Sx_lower_32_17  1
    Sx[32,17]  conditional_Sx_upper_32_17  1
    Sx[32,17]  conditional_complement_lower_32_17  -1
    Sx[32,17]  conditional_complement_upper_32_17  -1
    Sx[32,17]  hard_cost_W_definition  -7.8546851575757889e-04
    Sx[32,17]  floor_residual  -7.8546851575757889e-04
    Sx[32,17]  G_residual  -7.8546851575757889e-04
    Sx[32,18]  product_mass_32  1
    Sx[32,18]  product_lx_32_18  1
    Sx[32,18]  product_ux_32_18  1
    Sx[32,18]  product_Su_32_18  1
    Sx[32,18]  product_Sl_32_18  1
    Sx[32,18]  total_product_lower  18
    Sx[32,18]  total_product_upper  18
    Sx[32,18]  conditional_Sx_lower_32_18  1
    Sx[32,18]  conditional_Sx_upper_32_18  1
    Sx[32,18]  conditional_complement_lower_32_18  -1
    Sx[32,18]  conditional_complement_upper_32_18  -1
    Sx[32,18]  hard_cost_W_definition  -1.0472913543434386e-03
    Sx[32,18]  floor_residual  -1.0472913543434386e-03
    Sx[32,18]  G_residual  -1.0472913543434386e-03
    Sx[32,19]  product_mass_32  1
    Sx[32,19]  product_lx_32_19  1
    Sx[32,19]  product_ux_32_19  1
    Sx[32,19]  product_Su_32_19  1
    Sx[32,19]  product_Sl_32_19  1
    Sx[32,19]  total_product_lower  19
    Sx[32,19]  total_product_upper  19
    Sx[32,19]  conditional_Sx_lower_32_19  1
    Sx[32,19]  conditional_Sx_upper_32_19  1
    Sx[32,19]  conditional_complement_lower_32_19  -1
    Sx[32,19]  conditional_complement_upper_32_19  -1
    Sx[32,19]  hard_cost_W_definition  -1.3091141929292983e-03
    Sx[32,19]  floor_residual  -1.3091141929292983e-03
    Sx[32,19]  G_residual  -1.3091141929292983e-03
    Sx[33,0]  product_mass_33  1
    Sx[33,0]  product_lx_33_0  1
    Sx[33,0]  product_ux_33_0  1
    Sx[33,0]  product_Su_33_0  1
    Sx[33,0]  product_Sl_33_0  1
    Sx[33,0]  conditional_Sx_lower_33_0  1
    Sx[33,0]  conditional_Sx_upper_33_0  1
    Sx[33,0]  conditional_complement_lower_33_0  -1
    Sx[33,0]  conditional_complement_upper_33_0  -1
    Sx[33,0]  hard_cost_W_definition  -2.9091428836854082e-04
    Sx[33,0]  floor_residual  -2.9091428836854082e-04
    Sx[33,0]  G_residual  -2.9091428836854082e-04
    Sx[33,1]  product_mass_33  1
    Sx[33,1]  product_lx_33_1  1
    Sx[33,1]  product_ux_33_1  1
    Sx[33,1]  product_Su_33_1  1
    Sx[33,1]  product_Sl_33_1  1
    Sx[33,1]  total_product_lower  1
    Sx[33,1]  total_product_upper  1
    Sx[33,1]  conditional_Sx_lower_33_1  1
    Sx[33,1]  conditional_Sx_upper_33_1  1
    Sx[33,1]  conditional_complement_lower_33_1  -1
    Sx[33,1]  conditional_complement_upper_33_1  -1
    Sx[33,1]  hard_cost_W_definition  -1.4545714418427036e-04
    Sx[33,1]  floor_residual  -1.4545714418427036e-04
    Sx[33,1]  G_residual  -1.4545714418427036e-04
    Sx[33,2]  product_mass_33  1
    Sx[33,2]  product_lx_33_2  1
    Sx[33,2]  product_ux_33_2  1
    Sx[33,2]  product_Su_33_2  1
    Sx[33,2]  product_Sl_33_2  1
    Sx[33,2]  total_product_lower  2
    Sx[33,2]  total_product_upper  2
    Sx[33,2]  conditional_Sx_lower_33_2  1
    Sx[33,2]  conditional_Sx_upper_33_2  1
    Sx[33,2]  conditional_complement_lower_33_2  -1
    Sx[33,2]  conditional_complement_upper_33_2  -1
    Sx[33,3]  product_mass_33  1
    Sx[33,3]  product_lx_33_3  1
    Sx[33,3]  product_ux_33_3  1
    Sx[33,3]  product_Su_33_3  1
    Sx[33,3]  product_Sl_33_3  1
    Sx[33,3]  total_product_lower  3
    Sx[33,3]  total_product_upper  3
    Sx[33,3]  conditional_Sx_lower_33_3  1
    Sx[33,3]  conditional_Sx_upper_33_3  1
    Sx[33,3]  conditional_complement_lower_33_3  -1
    Sx[33,3]  conditional_complement_upper_33_3  -1
    Sx[33,3]  hard_cost_W_definition  1.4545714418427055e-04
    Sx[33,3]  floor_residual  1.4545714418427055e-04
    Sx[33,3]  G_residual  1.4545714418427055e-04
    Sx[33,4]  product_mass_33  1
    Sx[33,4]  product_lx_33_4  1
    Sx[33,4]  product_ux_33_4  1
    Sx[33,4]  product_Su_33_4  1
    Sx[33,4]  product_Sl_33_4  1
    Sx[33,4]  total_product_lower  4
    Sx[33,4]  total_product_upper  4
    Sx[33,4]  conditional_Sx_lower_33_4  1
    Sx[33,4]  conditional_Sx_upper_33_4  1
    Sx[33,4]  conditional_complement_lower_33_4  -1
    Sx[33,4]  conditional_complement_upper_33_4  -1
    Sx[33,4]  hard_cost_W_definition  2.9091428836854104e-04
    Sx[33,4]  floor_residual  2.9091428836854104e-04
    Sx[33,4]  G_residual  2.9091428836854104e-04
    Sx[33,5]  product_mass_33  1
    Sx[33,5]  product_lx_33_5  1
    Sx[33,5]  product_ux_33_5  1
    Sx[33,5]  product_Su_33_5  1
    Sx[33,5]  product_Sl_33_5  1
    Sx[33,5]  total_product_lower  5
    Sx[33,5]  total_product_upper  5
    Sx[33,5]  conditional_Sx_lower_33_5  1
    Sx[33,5]  conditional_Sx_upper_33_5  1
    Sx[33,5]  conditional_complement_lower_33_5  -1
    Sx[33,5]  conditional_complement_upper_33_5  -1
    Sx[33,5]  hard_cost_W_definition  4.3637143255281140e-04
    Sx[33,5]  floor_residual  4.3637143255281140e-04
    Sx[33,5]  G_residual  4.3637143255281140e-04
    Sx[33,6]  product_mass_33  1
    Sx[33,6]  product_lx_33_6  1
    Sx[33,6]  product_ux_33_6  1
    Sx[33,6]  product_Su_33_6  1
    Sx[33,6]  product_Sl_33_6  1
    Sx[33,6]  total_product_lower  6
    Sx[33,6]  total_product_upper  6
    Sx[33,6]  conditional_Sx_lower_33_6  1
    Sx[33,6]  conditional_Sx_upper_33_6  1
    Sx[33,6]  conditional_complement_lower_33_6  -1
    Sx[33,6]  conditional_complement_upper_33_6  -1
    Sx[33,6]  hard_cost_W_definition  2.9091428836854093e-04
    Sx[33,6]  floor_residual  2.9091428836854093e-04
    Sx[33,6]  G_residual  2.9091428836854093e-04
    Sx[33,7]  product_mass_33  1
    Sx[33,7]  product_lx_33_7  1
    Sx[33,7]  product_ux_33_7  1
    Sx[33,7]  product_Su_33_7  1
    Sx[33,7]  product_Sl_33_7  1
    Sx[33,7]  total_product_lower  7
    Sx[33,7]  total_product_upper  7
    Sx[33,7]  conditional_Sx_lower_33_7  1
    Sx[33,7]  conditional_Sx_upper_33_7  1
    Sx[33,7]  conditional_complement_lower_33_7  -1
    Sx[33,7]  conditional_complement_upper_33_7  -1
    Sx[33,7]  hard_cost_W_definition  1.4545714418427047e-04
    Sx[33,7]  floor_residual  1.4545714418427047e-04
    Sx[33,7]  G_residual  1.4545714418427047e-04
    Sx[33,8]  product_mass_33  1
    Sx[33,8]  product_lx_33_8  1
    Sx[33,8]  product_ux_33_8  1
    Sx[33,8]  product_Su_33_8  1
    Sx[33,8]  product_Sl_33_8  1
    Sx[33,8]  total_product_lower  8
    Sx[33,8]  total_product_upper  8
    Sx[33,8]  conditional_Sx_lower_33_8  1
    Sx[33,8]  conditional_Sx_upper_33_8  1
    Sx[33,8]  conditional_complement_lower_33_8  -1
    Sx[33,8]  conditional_complement_upper_33_8  -1
    Sx[33,9]  product_mass_33  1
    Sx[33,9]  product_lx_33_9  1
    Sx[33,9]  product_ux_33_9  1
    Sx[33,9]  product_Su_33_9  1
    Sx[33,9]  product_Sl_33_9  1
    Sx[33,9]  total_product_lower  9
    Sx[33,9]  total_product_upper  9
    Sx[33,9]  conditional_Sx_lower_33_9  1
    Sx[33,9]  conditional_Sx_upper_33_9  1
    Sx[33,9]  conditional_complement_lower_33_9  -1
    Sx[33,9]  conditional_complement_upper_33_9  -1
    Sx[33,9]  hard_cost_W_definition  -1.4545714418427044e-04
    Sx[33,9]  floor_residual  -1.4545714418427044e-04
    Sx[33,9]  G_residual  -1.4545714418427044e-04
    Sx[33,10]  product_mass_33  1
    Sx[33,10]  product_lx_33_10  1
    Sx[33,10]  product_ux_33_10  1
    Sx[33,10]  product_Su_33_10  1
    Sx[33,10]  product_Sl_33_10  1
    Sx[33,10]  total_product_lower  10
    Sx[33,10]  total_product_upper  10
    Sx[33,10]  conditional_Sx_lower_33_10  1
    Sx[33,10]  conditional_Sx_upper_33_10  1
    Sx[33,10]  conditional_complement_lower_33_10  -1
    Sx[33,10]  conditional_complement_upper_33_10  -1
    Sx[33,10]  hard_cost_W_definition  -2.9091428836854088e-04
    Sx[33,10]  floor_residual  -2.9091428836854088e-04
    Sx[33,10]  G_residual  -2.9091428836854088e-04
    Sx[33,11]  product_mass_33  1
    Sx[33,11]  product_lx_33_11  1
    Sx[33,11]  product_ux_33_11  1
    Sx[33,11]  product_Su_33_11  1
    Sx[33,11]  product_Sl_33_11  1
    Sx[33,11]  total_product_lower  11
    Sx[33,11]  total_product_upper  11
    Sx[33,11]  conditional_Sx_lower_33_11  1
    Sx[33,11]  conditional_Sx_upper_33_11  1
    Sx[33,11]  conditional_complement_lower_33_11  -1
    Sx[33,11]  conditional_complement_upper_33_11  -1
    Sx[33,11]  hard_cost_W_definition  -4.3637143255281135e-04
    Sx[33,11]  floor_residual  -4.3637143255281135e-04
    Sx[33,11]  G_residual  -4.3637143255281135e-04
    Sx[34,0]  product_mass_34  1
    Sx[34,0]  product_lx_34_0  1
    Sx[34,0]  product_ux_34_0  1
    Sx[34,0]  product_Su_34_0  1
    Sx[34,0]  product_Sl_34_0  1
    Sx[34,0]  conditional_Sx_lower_34_0  1
    Sx[34,0]  conditional_Sx_upper_34_0  1
    Sx[34,0]  conditional_complement_lower_34_0  -1
    Sx[34,0]  conditional_complement_upper_34_0  -1
    Sx[34,0]  hard_cost_W_definition  -9.3092511011388858e-04
    Sx[34,0]  floor_residual  -9.3092511011388858e-04
    Sx[34,0]  G_residual  -9.3092511011388858e-04
    Sx[34,1]  product_mass_34  1
    Sx[34,1]  product_lx_34_1  1
    Sx[34,1]  product_ux_34_1  1
    Sx[34,1]  product_Su_34_1  1
    Sx[34,1]  product_Sl_34_1  1
    Sx[34,1]  total_product_lower  1
    Sx[34,1]  total_product_upper  1
    Sx[34,1]  conditional_Sx_lower_34_1  1
    Sx[34,1]  conditional_Sx_upper_34_1  1
    Sx[34,1]  conditional_complement_lower_34_1  -1
    Sx[34,1]  conditional_complement_upper_34_1  -1
    Sx[34,1]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[34,1]  floor_residual  -6.9819383258541636e-04
    Sx[34,1]  G_residual  -6.9819383258541636e-04
    Sx[34,2]  product_mass_34  1
    Sx[34,2]  product_lx_34_2  1
    Sx[34,2]  product_ux_34_2  1
    Sx[34,2]  product_Su_34_2  1
    Sx[34,2]  product_Sl_34_2  1
    Sx[34,2]  total_product_lower  2
    Sx[34,2]  total_product_upper  2
    Sx[34,2]  conditional_Sx_lower_34_2  1
    Sx[34,2]  conditional_Sx_upper_34_2  1
    Sx[34,2]  conditional_complement_lower_34_2  -1
    Sx[34,2]  conditional_complement_upper_34_2  -1
    Sx[34,2]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[34,2]  floor_residual  -4.6546255505694429e-04
    Sx[34,2]  G_residual  -4.6546255505694429e-04
    Sx[34,3]  product_mass_34  1
    Sx[34,3]  product_lx_34_3  1
    Sx[34,3]  product_ux_34_3  1
    Sx[34,3]  product_Su_34_3  1
    Sx[34,3]  product_Sl_34_3  1
    Sx[34,3]  total_product_lower  3
    Sx[34,3]  total_product_upper  3
    Sx[34,3]  conditional_Sx_lower_34_3  1
    Sx[34,3]  conditional_Sx_upper_34_3  1
    Sx[34,3]  conditional_complement_lower_34_3  -1
    Sx[34,3]  conditional_complement_upper_34_3  -1
    Sx[34,3]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[34,3]  floor_residual  -2.3273127752847215e-04
    Sx[34,3]  G_residual  -2.3273127752847215e-04
    Sx[34,4]  product_mass_34  1
    Sx[34,4]  product_lx_34_4  1
    Sx[34,4]  product_ux_34_4  1
    Sx[34,4]  product_Su_34_4  1
    Sx[34,4]  product_Sl_34_4  1
    Sx[34,4]  total_product_lower  4
    Sx[34,4]  total_product_upper  4
    Sx[34,4]  conditional_Sx_lower_34_4  1
    Sx[34,4]  conditional_Sx_upper_34_4  1
    Sx[34,4]  conditional_complement_lower_34_4  -1
    Sx[34,4]  conditional_complement_upper_34_4  -1
    Sx[34,5]  product_mass_34  1
    Sx[34,5]  product_lx_34_5  1
    Sx[34,5]  product_ux_34_5  1
    Sx[34,5]  product_Su_34_5  1
    Sx[34,5]  product_Sl_34_5  1
    Sx[34,5]  total_product_lower  5
    Sx[34,5]  total_product_upper  5
    Sx[34,5]  conditional_Sx_lower_34_5  1
    Sx[34,5]  conditional_Sx_upper_34_5  1
    Sx[34,5]  conditional_complement_lower_34_5  -1
    Sx[34,5]  conditional_complement_upper_34_5  -1
    Sx[34,5]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[34,5]  floor_residual  2.3273127752847215e-04
    Sx[34,5]  G_residual  2.3273127752847215e-04
    Sx[34,6]  product_mass_34  1
    Sx[34,6]  product_lx_34_6  1
    Sx[34,6]  product_ux_34_6  1
    Sx[34,6]  product_Su_34_6  1
    Sx[34,6]  product_Sl_34_6  1
    Sx[34,6]  total_product_lower  6
    Sx[34,6]  total_product_upper  6
    Sx[34,6]  conditional_Sx_lower_34_6  1
    Sx[34,6]  conditional_Sx_upper_34_6  1
    Sx[34,6]  conditional_complement_lower_34_6  -1
    Sx[34,6]  conditional_complement_upper_34_6  -1
    Sx[34,6]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[34,6]  floor_residual  4.6546255505694429e-04
    Sx[34,6]  G_residual  4.6546255505694429e-04
    Sx[34,7]  product_mass_34  1
    Sx[34,7]  product_lx_34_7  1
    Sx[34,7]  product_ux_34_7  1
    Sx[34,7]  product_Su_34_7  1
    Sx[34,7]  product_Sl_34_7  1
    Sx[34,7]  total_product_lower  7
    Sx[34,7]  total_product_upper  7
    Sx[34,7]  conditional_Sx_lower_34_7  1
    Sx[34,7]  conditional_Sx_upper_34_7  1
    Sx[34,7]  conditional_complement_lower_34_7  -1
    Sx[34,7]  conditional_complement_upper_34_7  -1
    Sx[34,7]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[34,7]  floor_residual  6.9819383258541646e-04
    Sx[34,7]  G_residual  6.9819383258541646e-04
    Sx[34,8]  product_mass_34  1
    Sx[34,8]  product_lx_34_8  1
    Sx[34,8]  product_ux_34_8  1
    Sx[34,8]  product_Su_34_8  1
    Sx[34,8]  product_Sl_34_8  1
    Sx[34,8]  total_product_lower  8
    Sx[34,8]  total_product_upper  8
    Sx[34,8]  conditional_Sx_lower_34_8  1
    Sx[34,8]  conditional_Sx_upper_34_8  1
    Sx[34,8]  conditional_complement_lower_34_8  -1
    Sx[34,8]  conditional_complement_upper_34_8  -1
    Sx[34,8]  hard_cost_W_definition  9.3092511011388858e-04
    Sx[34,8]  floor_residual  9.3092511011388858e-04
    Sx[34,8]  G_residual  9.3092511011388858e-04
    Sx[34,9]  product_mass_34  1
    Sx[34,9]  product_lx_34_9  1
    Sx[34,9]  product_ux_34_9  1
    Sx[34,9]  product_Su_34_9  1
    Sx[34,9]  product_Sl_34_9  1
    Sx[34,9]  total_product_lower  9
    Sx[34,9]  total_product_upper  9
    Sx[34,9]  conditional_Sx_lower_34_9  1
    Sx[34,9]  conditional_Sx_upper_34_9  1
    Sx[34,9]  conditional_complement_lower_34_9  -1
    Sx[34,9]  conditional_complement_upper_34_9  -1
    Sx[34,9]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[34,9]  floor_residual  6.9819383258541646e-04
    Sx[34,9]  G_residual  6.9819383258541646e-04
    Sx[34,10]  product_mass_34  1
    Sx[34,10]  product_lx_34_10  1
    Sx[34,10]  product_ux_34_10  1
    Sx[34,10]  product_Su_34_10  1
    Sx[34,10]  product_Sl_34_10  1
    Sx[34,10]  total_product_lower  10
    Sx[34,10]  total_product_upper  10
    Sx[34,10]  conditional_Sx_lower_34_10  1
    Sx[34,10]  conditional_Sx_upper_34_10  1
    Sx[34,10]  conditional_complement_lower_34_10  -1
    Sx[34,10]  conditional_complement_upper_34_10  -1
    Sx[34,10]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[34,10]  floor_residual  4.6546255505694429e-04
    Sx[34,10]  G_residual  4.6546255505694429e-04
    Sx[34,11]  product_mass_34  1
    Sx[34,11]  product_lx_34_11  1
    Sx[34,11]  product_ux_34_11  1
    Sx[34,11]  product_Su_34_11  1
    Sx[34,11]  product_Sl_34_11  1
    Sx[34,11]  total_product_lower  11
    Sx[34,11]  total_product_upper  11
    Sx[34,11]  conditional_Sx_lower_34_11  1
    Sx[34,11]  conditional_Sx_upper_34_11  1
    Sx[34,11]  conditional_complement_lower_34_11  -1
    Sx[34,11]  conditional_complement_upper_34_11  -1
    Sx[34,11]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[34,11]  floor_residual  2.3273127752847215e-04
    Sx[34,11]  G_residual  2.3273127752847215e-04
    Sx[34,12]  product_mass_34  1
    Sx[34,12]  product_lx_34_12  1
    Sx[34,12]  product_ux_34_12  1
    Sx[34,12]  product_Su_34_12  1
    Sx[34,12]  product_Sl_34_12  1
    Sx[34,12]  total_product_lower  12
    Sx[34,12]  total_product_upper  12
    Sx[34,12]  conditional_Sx_lower_34_12  1
    Sx[34,12]  conditional_Sx_upper_34_12  1
    Sx[34,12]  conditional_complement_lower_34_12  -1
    Sx[34,12]  conditional_complement_upper_34_12  -1
    Sx[34,13]  product_mass_34  1
    Sx[34,13]  product_lx_34_13  1
    Sx[34,13]  product_ux_34_13  1
    Sx[34,13]  product_Su_34_13  1
    Sx[34,13]  product_Sl_34_13  1
    Sx[34,13]  total_product_lower  13
    Sx[34,13]  total_product_upper  13
    Sx[34,13]  conditional_Sx_lower_34_13  1
    Sx[34,13]  conditional_Sx_upper_34_13  1
    Sx[34,13]  conditional_complement_lower_34_13  -1
    Sx[34,13]  conditional_complement_upper_34_13  -1
    Sx[34,13]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[34,13]  floor_residual  -2.3273127752847215e-04
    Sx[34,13]  G_residual  -2.3273127752847215e-04
    Sx[34,14]  product_mass_34  1
    Sx[34,14]  product_lx_34_14  1
    Sx[34,14]  product_ux_34_14  1
    Sx[34,14]  product_Su_34_14  1
    Sx[34,14]  product_Sl_34_14  1
    Sx[34,14]  total_product_lower  14
    Sx[34,14]  total_product_upper  14
    Sx[34,14]  conditional_Sx_lower_34_14  1
    Sx[34,14]  conditional_Sx_upper_34_14  1
    Sx[34,14]  conditional_complement_lower_34_14  -1
    Sx[34,14]  conditional_complement_upper_34_14  -1
    Sx[34,14]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[34,14]  floor_residual  -4.6546255505694429e-04
    Sx[34,14]  G_residual  -4.6546255505694429e-04
    Sx[34,15]  product_mass_34  1
    Sx[34,15]  product_lx_34_15  1
    Sx[34,15]  product_ux_34_15  1
    Sx[34,15]  product_Su_34_15  1
    Sx[34,15]  product_Sl_34_15  1
    Sx[34,15]  total_product_lower  15
    Sx[34,15]  total_product_upper  15
    Sx[34,15]  conditional_Sx_lower_34_15  1
    Sx[34,15]  conditional_Sx_upper_34_15  1
    Sx[34,15]  conditional_complement_lower_34_15  -1
    Sx[34,15]  conditional_complement_upper_34_15  -1
    Sx[34,15]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[34,15]  floor_residual  -6.9819383258541636e-04
    Sx[34,15]  G_residual  -6.9819383258541636e-04
    Sx[35,0]  product_mass_35  1
    Sx[35,0]  product_lx_35_0  1
    Sx[35,0]  product_ux_35_0  1
    Sx[35,0]  product_Su_35_0  1
    Sx[35,0]  product_Sl_35_0  1
    Sx[35,0]  conditional_Sx_lower_35_0  1
    Sx[35,0]  conditional_Sx_upper_35_0  1
    Sx[35,0]  conditional_complement_lower_35_0  -1
    Sx[35,0]  conditional_complement_upper_35_0  -1
    Sx[35,0]  hard_cost_W_definition  -9.3092511011388858e-04
    Sx[35,0]  floor_residual  -9.3092511011388858e-04
    Sx[35,0]  G_residual  -9.3092511011388858e-04
    Sx[35,1]  product_mass_35  1
    Sx[35,1]  product_lx_35_1  1
    Sx[35,1]  product_ux_35_1  1
    Sx[35,1]  product_Su_35_1  1
    Sx[35,1]  product_Sl_35_1  1
    Sx[35,1]  total_product_lower  1
    Sx[35,1]  total_product_upper  1
    Sx[35,1]  conditional_Sx_lower_35_1  1
    Sx[35,1]  conditional_Sx_upper_35_1  1
    Sx[35,1]  conditional_complement_lower_35_1  -1
    Sx[35,1]  conditional_complement_upper_35_1  -1
    Sx[35,1]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[35,1]  floor_residual  -6.9819383258541636e-04
    Sx[35,1]  G_residual  -6.9819383258541636e-04
    Sx[35,2]  product_mass_35  1
    Sx[35,2]  product_lx_35_2  1
    Sx[35,2]  product_ux_35_2  1
    Sx[35,2]  product_Su_35_2  1
    Sx[35,2]  product_Sl_35_2  1
    Sx[35,2]  total_product_lower  2
    Sx[35,2]  total_product_upper  2
    Sx[35,2]  conditional_Sx_lower_35_2  1
    Sx[35,2]  conditional_Sx_upper_35_2  1
    Sx[35,2]  conditional_complement_lower_35_2  -1
    Sx[35,2]  conditional_complement_upper_35_2  -1
    Sx[35,2]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[35,2]  floor_residual  -4.6546255505694429e-04
    Sx[35,2]  G_residual  -4.6546255505694429e-04
    Sx[35,3]  product_mass_35  1
    Sx[35,3]  product_lx_35_3  1
    Sx[35,3]  product_ux_35_3  1
    Sx[35,3]  product_Su_35_3  1
    Sx[35,3]  product_Sl_35_3  1
    Sx[35,3]  total_product_lower  3
    Sx[35,3]  total_product_upper  3
    Sx[35,3]  conditional_Sx_lower_35_3  1
    Sx[35,3]  conditional_Sx_upper_35_3  1
    Sx[35,3]  conditional_complement_lower_35_3  -1
    Sx[35,3]  conditional_complement_upper_35_3  -1
    Sx[35,3]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[35,3]  floor_residual  -2.3273127752847215e-04
    Sx[35,3]  G_residual  -2.3273127752847215e-04
    Sx[35,4]  product_mass_35  1
    Sx[35,4]  product_lx_35_4  1
    Sx[35,4]  product_ux_35_4  1
    Sx[35,4]  product_Su_35_4  1
    Sx[35,4]  product_Sl_35_4  1
    Sx[35,4]  total_product_lower  4
    Sx[35,4]  total_product_upper  4
    Sx[35,4]  conditional_Sx_lower_35_4  1
    Sx[35,4]  conditional_Sx_upper_35_4  1
    Sx[35,4]  conditional_complement_lower_35_4  -1
    Sx[35,4]  conditional_complement_upper_35_4  -1
    Sx[35,5]  product_mass_35  1
    Sx[35,5]  product_lx_35_5  1
    Sx[35,5]  product_ux_35_5  1
    Sx[35,5]  product_Su_35_5  1
    Sx[35,5]  product_Sl_35_5  1
    Sx[35,5]  total_product_lower  5
    Sx[35,5]  total_product_upper  5
    Sx[35,5]  conditional_Sx_lower_35_5  1
    Sx[35,5]  conditional_Sx_upper_35_5  1
    Sx[35,5]  conditional_complement_lower_35_5  -1
    Sx[35,5]  conditional_complement_upper_35_5  -1
    Sx[35,5]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[35,5]  floor_residual  2.3273127752847215e-04
    Sx[35,5]  G_residual  2.3273127752847215e-04
    Sx[35,6]  product_mass_35  1
    Sx[35,6]  product_lx_35_6  1
    Sx[35,6]  product_ux_35_6  1
    Sx[35,6]  product_Su_35_6  1
    Sx[35,6]  product_Sl_35_6  1
    Sx[35,6]  total_product_lower  6
    Sx[35,6]  total_product_upper  6
    Sx[35,6]  conditional_Sx_lower_35_6  1
    Sx[35,6]  conditional_Sx_upper_35_6  1
    Sx[35,6]  conditional_complement_lower_35_6  -1
    Sx[35,6]  conditional_complement_upper_35_6  -1
    Sx[35,6]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[35,6]  floor_residual  4.6546255505694429e-04
    Sx[35,6]  G_residual  4.6546255505694429e-04
    Sx[35,7]  product_mass_35  1
    Sx[35,7]  product_lx_35_7  1
    Sx[35,7]  product_ux_35_7  1
    Sx[35,7]  product_Su_35_7  1
    Sx[35,7]  product_Sl_35_7  1
    Sx[35,7]  total_product_lower  7
    Sx[35,7]  total_product_upper  7
    Sx[35,7]  conditional_Sx_lower_35_7  1
    Sx[35,7]  conditional_Sx_upper_35_7  1
    Sx[35,7]  conditional_complement_lower_35_7  -1
    Sx[35,7]  conditional_complement_upper_35_7  -1
    Sx[35,7]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[35,7]  floor_residual  6.9819383258541646e-04
    Sx[35,7]  G_residual  6.9819383258541646e-04
    Sx[35,8]  product_mass_35  1
    Sx[35,8]  product_lx_35_8  1
    Sx[35,8]  product_ux_35_8  1
    Sx[35,8]  product_Su_35_8  1
    Sx[35,8]  product_Sl_35_8  1
    Sx[35,8]  total_product_lower  8
    Sx[35,8]  total_product_upper  8
    Sx[35,8]  conditional_Sx_lower_35_8  1
    Sx[35,8]  conditional_Sx_upper_35_8  1
    Sx[35,8]  conditional_complement_lower_35_8  -1
    Sx[35,8]  conditional_complement_upper_35_8  -1
    Sx[35,8]  hard_cost_W_definition  9.3092511011388858e-04
    Sx[35,8]  floor_residual  9.3092511011388858e-04
    Sx[35,8]  G_residual  9.3092511011388858e-04
    Sx[35,9]  product_mass_35  1
    Sx[35,9]  product_lx_35_9  1
    Sx[35,9]  product_ux_35_9  1
    Sx[35,9]  product_Su_35_9  1
    Sx[35,9]  product_Sl_35_9  1
    Sx[35,9]  total_product_lower  9
    Sx[35,9]  total_product_upper  9
    Sx[35,9]  conditional_Sx_lower_35_9  1
    Sx[35,9]  conditional_Sx_upper_35_9  1
    Sx[35,9]  conditional_complement_lower_35_9  -1
    Sx[35,9]  conditional_complement_upper_35_9  -1
    Sx[35,9]  hard_cost_W_definition  6.9819383258541646e-04
    Sx[35,9]  floor_residual  6.9819383258541646e-04
    Sx[35,9]  G_residual  6.9819383258541646e-04
    Sx[35,10]  product_mass_35  1
    Sx[35,10]  product_lx_35_10  1
    Sx[35,10]  product_ux_35_10  1
    Sx[35,10]  product_Su_35_10  1
    Sx[35,10]  product_Sl_35_10  1
    Sx[35,10]  total_product_lower  10
    Sx[35,10]  total_product_upper  10
    Sx[35,10]  conditional_Sx_lower_35_10  1
    Sx[35,10]  conditional_Sx_upper_35_10  1
    Sx[35,10]  conditional_complement_lower_35_10  -1
    Sx[35,10]  conditional_complement_upper_35_10  -1
    Sx[35,10]  hard_cost_W_definition  4.6546255505694429e-04
    Sx[35,10]  floor_residual  4.6546255505694429e-04
    Sx[35,10]  G_residual  4.6546255505694429e-04
    Sx[35,11]  product_mass_35  1
    Sx[35,11]  product_lx_35_11  1
    Sx[35,11]  product_ux_35_11  1
    Sx[35,11]  product_Su_35_11  1
    Sx[35,11]  product_Sl_35_11  1
    Sx[35,11]  total_product_lower  11
    Sx[35,11]  total_product_upper  11
    Sx[35,11]  conditional_Sx_lower_35_11  1
    Sx[35,11]  conditional_Sx_upper_35_11  1
    Sx[35,11]  conditional_complement_lower_35_11  -1
    Sx[35,11]  conditional_complement_upper_35_11  -1
    Sx[35,11]  hard_cost_W_definition  2.3273127752847215e-04
    Sx[35,11]  floor_residual  2.3273127752847215e-04
    Sx[35,11]  G_residual  2.3273127752847215e-04
    Sx[35,12]  product_mass_35  1
    Sx[35,12]  product_lx_35_12  1
    Sx[35,12]  product_ux_35_12  1
    Sx[35,12]  product_Su_35_12  1
    Sx[35,12]  product_Sl_35_12  1
    Sx[35,12]  total_product_lower  12
    Sx[35,12]  total_product_upper  12
    Sx[35,12]  conditional_Sx_lower_35_12  1
    Sx[35,12]  conditional_Sx_upper_35_12  1
    Sx[35,12]  conditional_complement_lower_35_12  -1
    Sx[35,12]  conditional_complement_upper_35_12  -1
    Sx[35,13]  product_mass_35  1
    Sx[35,13]  product_lx_35_13  1
    Sx[35,13]  product_ux_35_13  1
    Sx[35,13]  product_Su_35_13  1
    Sx[35,13]  product_Sl_35_13  1
    Sx[35,13]  total_product_lower  13
    Sx[35,13]  total_product_upper  13
    Sx[35,13]  conditional_Sx_lower_35_13  1
    Sx[35,13]  conditional_Sx_upper_35_13  1
    Sx[35,13]  conditional_complement_lower_35_13  -1
    Sx[35,13]  conditional_complement_upper_35_13  -1
    Sx[35,13]  hard_cost_W_definition  -2.3273127752847215e-04
    Sx[35,13]  floor_residual  -2.3273127752847215e-04
    Sx[35,13]  G_residual  -2.3273127752847215e-04
    Sx[35,14]  product_mass_35  1
    Sx[35,14]  product_lx_35_14  1
    Sx[35,14]  product_ux_35_14  1
    Sx[35,14]  product_Su_35_14  1
    Sx[35,14]  product_Sl_35_14  1
    Sx[35,14]  total_product_lower  14
    Sx[35,14]  total_product_upper  14
    Sx[35,14]  conditional_Sx_lower_35_14  1
    Sx[35,14]  conditional_Sx_upper_35_14  1
    Sx[35,14]  conditional_complement_lower_35_14  -1
    Sx[35,14]  conditional_complement_upper_35_14  -1
    Sx[35,14]  hard_cost_W_definition  -4.6546255505694429e-04
    Sx[35,14]  floor_residual  -4.6546255505694429e-04
    Sx[35,14]  G_residual  -4.6546255505694429e-04
    Sx[35,15]  product_mass_35  1
    Sx[35,15]  product_lx_35_15  1
    Sx[35,15]  product_ux_35_15  1
    Sx[35,15]  product_Su_35_15  1
    Sx[35,15]  product_Sl_35_15  1
    Sx[35,15]  total_product_lower  15
    Sx[35,15]  total_product_upper  15
    Sx[35,15]  conditional_Sx_lower_35_15  1
    Sx[35,15]  conditional_Sx_upper_35_15  1
    Sx[35,15]  conditional_complement_lower_35_15  -1
    Sx[35,15]  conditional_complement_upper_35_15  -1
    Sx[35,15]  hard_cost_W_definition  -6.9819383258541636e-04
    Sx[35,15]  floor_residual  -6.9819383258541636e-04
    Sx[35,15]  G_residual  -6.9819383258541636e-04
    S         product_mass_1  -1
    S         product_Su_1_0  -1
    S         product_Sl_1_0  -1
    S         product_Su_1_1  -1
    S         product_Sl_1_1  -1
    S         product_Su_1_2  -1
    S         product_Sl_1_2  -1
    S         product_Su_1_3  -1
    S         product_Sl_1_3  -1
    S         product_Su_1_4  -1
    S         product_Sl_1_4  -1
    S         product_Su_1_5  -1
    S         product_Sl_1_5  -1
    S         product_Su_1_6  -1
    S         product_Sl_1_6  -1
    S         product_Su_1_7  -1
    S         product_Sl_1_7  -1
    S         product_Su_1_8  -1
    S         product_Sl_1_8  -1
    S         product_mass_2  -1
    S         product_Su_2_0  -1
    S         product_Sl_2_0  -1
    S         product_Su_2_1  -1
    S         product_Sl_2_1  -1
    S         product_Su_2_2  -1
    S         product_Sl_2_2  -1
    S         product_Su_2_3  -1
    S         product_Sl_2_3  -1
    S         product_Su_2_4  -1
    S         product_Sl_2_4  -1
    S         product_Su_2_5  -1
    S         product_Sl_2_5  -1
    S         product_Su_2_6  -1
    S         product_Sl_2_6  -1
    S         product_Su_2_7  -1
    S         product_Sl_2_7  -1
    S         product_Su_2_8  -1
    S         product_Sl_2_8  -1
    S         product_Su_2_9  -1
    S         product_Sl_2_9  -1
    S         product_Su_2_10  -1
    S         product_Sl_2_10  -1
    S         product_Su_2_11  -1
    S         product_Sl_2_11  -1
    S         product_Su_2_12  -1
    S         product_Sl_2_12  -1
    S         product_Su_2_13  -1
    S         product_Sl_2_13  -1
    S         product_Su_2_14  -1
    S         product_Sl_2_14  -1
    S         product_Su_2_15  -1
    S         product_Sl_2_15  -1
    S         product_mass_3  -1
    S         product_Su_3_0  -1
    S         product_Sl_3_0  -1
    S         product_Su_3_1  -1
    S         product_Sl_3_1  -1
    S         product_Su_3_2  -1
    S         product_Sl_3_2  -1
    S         product_Su_3_3  -1
    S         product_Sl_3_3  -1
    S         product_Su_3_4  -1
    S         product_Sl_3_4  -1
    S         product_Su_3_5  -1
    S         product_Sl_3_5  -1
    S         product_Su_3_6  -1
    S         product_Sl_3_6  -1
    S         product_Su_3_7  -1
    S         product_Sl_3_7  -1
    S         product_Su_3_8  -1
    S         product_Sl_3_8  -1
    S         product_Su_3_9  -1
    S         product_Sl_3_9  -1
    S         product_Su_3_10  -1
    S         product_Sl_3_10  -1
    S         product_Su_3_11  -1
    S         product_Sl_3_11  -1
    S         product_Su_3_12  -1
    S         product_Sl_3_12  -1
    S         product_mass_4  -1
    S         product_Su_4_0  -1
    S         product_Sl_4_0  -1
    S         product_Su_4_1  -1
    S         product_Sl_4_1  -1
    S         product_Su_4_2  -1
    S         product_Sl_4_2  -1
    S         product_Su_4_3  -1
    S         product_Sl_4_3  -1
    S         product_Su_4_4  -1
    S         product_Sl_4_4  -1
    S         product_Su_4_5  -1
    S         product_Sl_4_5  -1
    S         product_Su_4_6  -1
    S         product_Sl_4_6  -1
    S         product_Su_4_7  -1
    S         product_Sl_4_7  -1
    S         product_Su_4_8  -1
    S         product_Sl_4_8  -1
    S         product_Su_4_9  -1
    S         product_Sl_4_9  -1
    S         product_Su_4_10  -1
    S         product_Sl_4_10  -1
    S         product_Su_4_11  -1
    S         product_Sl_4_11  -1
    S         product_Su_4_12  -1
    S         product_Sl_4_12  -1
    S         product_Su_4_13  -1
    S         product_Sl_4_13  -1
    S         product_Su_4_14  -1
    S         product_Sl_4_14  -1
    S         product_Su_4_15  -1
    S         product_Sl_4_15  -1
    S         product_mass_5  -1
    S         product_Su_5_0  -1
    S         product_Sl_5_0  -1
    S         product_Su_5_1  -1
    S         product_Sl_5_1  -1
    S         product_Su_5_2  -1
    S         product_Sl_5_2  -1
    S         product_Su_5_3  -1
    S         product_Sl_5_3  -1
    S         product_Su_5_4  -1
    S         product_Sl_5_4  -1
    S         product_Su_5_5  -1
    S         product_Sl_5_5  -1
    S         product_Su_5_6  -1
    S         product_Sl_5_6  -1
    S         product_Su_5_7  -1
    S         product_Sl_5_7  -1
    S         product_Su_5_8  -1
    S         product_Sl_5_8  -1
    S         product_Su_5_9  -1
    S         product_Sl_5_9  -1
    S         product_Su_5_10  -1
    S         product_Sl_5_10  -1
    S         product_Su_5_11  -1
    S         product_Sl_5_11  -1
    S         product_Su_5_12  -1
    S         product_Sl_5_12  -1
    S         product_Su_5_13  -1
    S         product_Sl_5_13  -1
    S         product_Su_5_14  -1
    S         product_Sl_5_14  -1
    S         product_Su_5_15  -1
    S         product_Sl_5_15  -1
    S         product_mass_6  -1
    S         product_Su_6_0  -1
    S         product_Sl_6_0  -1
    S         product_Su_6_1  -1
    S         product_Sl_6_1  -1
    S         product_Su_6_2  -1
    S         product_Sl_6_2  -1
    S         product_Su_6_3  -1
    S         product_Sl_6_3  -1
    S         product_Su_6_4  -1
    S         product_Sl_6_4  -1
    S         product_Su_6_5  -1
    S         product_Sl_6_5  -1
    S         product_Su_6_6  -1
    S         product_Sl_6_6  -1
    S         product_Su_6_7  -1
    S         product_Sl_6_7  -1
    S         product_Su_6_8  -1
    S         product_Sl_6_8  -1
    S         product_mass_7  -1
    S         product_Su_7_0  -1
    S         product_Sl_7_0  -1
    S         product_Su_7_1  -1
    S         product_Sl_7_1  -1
    S         product_Su_7_2  -1
    S         product_Sl_7_2  -1
    S         product_Su_7_3  -1
    S         product_Sl_7_3  -1
    S         product_Su_7_4  -1
    S         product_Sl_7_4  -1
    S         product_Su_7_5  -1
    S         product_Sl_7_5  -1
    S         product_Su_7_6  -1
    S         product_Sl_7_6  -1
    S         product_Su_7_7  -1
    S         product_Sl_7_7  -1
    S         product_Su_7_8  -1
    S         product_Sl_7_8  -1
    S         product_Su_7_9  -1
    S         product_Sl_7_9  -1
    S         product_Su_7_10  -1
    S         product_Sl_7_10  -1
    S         product_Su_7_11  -1
    S         product_Sl_7_11  -1
    S         product_Su_7_12  -1
    S         product_Sl_7_12  -1
    S         product_Su_7_13  -1
    S         product_Sl_7_13  -1
    S         product_Su_7_14  -1
    S         product_Sl_7_14  -1
    S         product_Su_7_15  -1
    S         product_Sl_7_15  -1
    S         product_mass_8  -1
    S         product_Su_8_0  -1
    S         product_Sl_8_0  -1
    S         product_Su_8_1  -1
    S         product_Sl_8_1  -1
    S         product_Su_8_2  -1
    S         product_Sl_8_2  -1
    S         product_Su_8_3  -1
    S         product_Sl_8_3  -1
    S         product_Su_8_4  -1
    S         product_Sl_8_4  -1
    S         product_Su_8_5  -1
    S         product_Sl_8_5  -1
    S         product_Su_8_6  -1
    S         product_Sl_8_6  -1
    S         product_Su_8_7  -1
    S         product_Sl_8_7  -1
    S         product_Su_8_8  -1
    S         product_Sl_8_8  -1
    S         product_Su_8_9  -1
    S         product_Sl_8_9  -1
    S         product_Su_8_10  -1
    S         product_Sl_8_10  -1
    S         product_Su_8_11  -1
    S         product_Sl_8_11  -1
    S         product_Su_8_12  -1
    S         product_Sl_8_12  -1
    S         product_mass_9  -1
    S         product_Su_9_0  -1
    S         product_Sl_9_0  -1
    S         product_Su_9_1  -1
    S         product_Sl_9_1  -1
    S         product_Su_9_2  -1
    S         product_Sl_9_2  -1
    S         product_Su_9_3  -1
    S         product_Sl_9_3  -1
    S         product_Su_9_4  -1
    S         product_Sl_9_4  -1
    S         product_Su_9_5  -1
    S         product_Sl_9_5  -1
    S         product_Su_9_6  -1
    S         product_Sl_9_6  -1
    S         product_Su_9_7  -1
    S         product_Sl_9_7  -1
    S         product_Su_9_8  -1
    S         product_Sl_9_8  -1
    S         product_Su_9_9  -1
    S         product_Sl_9_9  -1
    S         product_Su_9_10  -1
    S         product_Sl_9_10  -1
    S         product_mass_10  -1
    S         product_Su_10_0  -1
    S         product_Sl_10_0  -1
    S         product_Su_10_1  -1
    S         product_Sl_10_1  -1
    S         product_Su_10_2  -1
    S         product_Sl_10_2  -1
    S         product_Su_10_3  -1
    S         product_Sl_10_3  -1
    S         product_Su_10_4  -1
    S         product_Sl_10_4  -1
    S         product_Su_10_5  -1
    S         product_Sl_10_5  -1
    S         product_Su_10_6  -1
    S         product_Sl_10_6  -1
    S         product_mass_11  -1
    S         product_Su_11_0  -1
    S         product_Sl_11_0  -1
    S         product_Su_11_1  -1
    S         product_Sl_11_1  -1
    S         product_Su_11_2  -1
    S         product_Sl_11_2  -1
    S         product_Su_11_3  -1
    S         product_Sl_11_3  -1
    S         product_Su_11_4  -1
    S         product_Sl_11_4  -1
    S         product_Su_11_5  -1
    S         product_Sl_11_5  -1
    S         product_Su_11_6  -1
    S         product_Sl_11_6  -1
    S         product_Su_11_7  -1
    S         product_Sl_11_7  -1
    S         product_Su_11_8  -1
    S         product_Sl_11_8  -1
    S         product_Su_11_9  -1
    S         product_Sl_11_9  -1
    S         product_Su_11_10  -1
    S         product_Sl_11_10  -1
    S         product_mass_12  -1
    S         product_Su_12_0  -1
    S         product_Sl_12_0  -1
    S         product_Su_12_1  -1
    S         product_Sl_12_1  -1
    S         product_Su_12_2  -1
    S         product_Sl_12_2  -1
    S         product_Su_12_3  -1
    S         product_Sl_12_3  -1
    S         product_Su_12_4  -1
    S         product_Sl_12_4  -1
    S         product_Su_12_5  -1
    S         product_Sl_12_5  -1
    S         product_Su_12_6  -1
    S         product_Sl_12_6  -1
    S         product_Su_12_7  -1
    S         product_Sl_12_7  -1
    S         product_Su_12_8  -1
    S         product_Sl_12_8  -1
    S         product_Su_12_9  -1
    S         product_Sl_12_9  -1
    S         product_Su_12_10  -1
    S         product_Sl_12_10  -1
    S         product_Su_12_11  -1
    S         product_Sl_12_11  -1
    S         product_Su_12_12  -1
    S         product_Sl_12_12  -1
    S         product_mass_13  -1
    S         product_Su_13_0  -1
    S         product_Sl_13_0  -1
    S         product_Su_13_1  -1
    S         product_Sl_13_1  -1
    S         product_Su_13_2  -1
    S         product_Sl_13_2  -1
    S         product_Su_13_3  -1
    S         product_Sl_13_3  -1
    S         product_Su_13_4  -1
    S         product_Sl_13_4  -1
    S         product_Su_13_5  -1
    S         product_Sl_13_5  -1
    S         product_Su_13_6  -1
    S         product_Sl_13_6  -1
    S         product_Su_13_7  -1
    S         product_Sl_13_7  -1
    S         product_Su_13_8  -1
    S         product_Sl_13_8  -1
    S         product_mass_14  -1
    S         product_Su_14_0  -1
    S         product_Sl_14_0  -1
    S         product_Su_14_1  -1
    S         product_Sl_14_1  -1
    S         product_Su_14_2  -1
    S         product_Sl_14_2  -1
    S         product_Su_14_3  -1
    S         product_Sl_14_3  -1
    S         product_Su_14_4  -1
    S         product_Sl_14_4  -1
    S         product_Su_14_5  -1
    S         product_Sl_14_5  -1
    S         product_Su_14_6  -1
    S         product_Sl_14_6  -1
    S         product_Su_14_7  -1
    S         product_Sl_14_7  -1
    S         product_Su_14_8  -1
    S         product_Sl_14_8  -1
    S         product_mass_15  -1
    S         product_Su_15_0  -1
    S         product_Sl_15_0  -1
    S         product_Su_15_1  -1
    S         product_Sl_15_1  -1
    S         product_Su_15_2  -1
    S         product_Sl_15_2  -1
    S         product_Su_15_3  -1
    S         product_Sl_15_3  -1
    S         product_Su_15_4  -1
    S         product_Sl_15_4  -1
    S         product_Su_15_5  -1
    S         product_Sl_15_5  -1
    S         product_Su_15_6  -1
    S         product_Sl_15_6  -1
    S         product_Su_15_7  -1
    S         product_Sl_15_7  -1
    S         product_Su_15_8  -1
    S         product_Sl_15_8  -1
    S         product_mass_16  -1
    S         product_Su_16_0  -1
    S         product_Sl_16_0  -1
    S         product_Su_16_1  -1
    S         product_Sl_16_1  -1
    S         product_Su_16_2  -1
    S         product_Sl_16_2  -1
    S         product_Su_16_3  -1
    S         product_Sl_16_3  -1
    S         product_Su_16_4  -1
    S         product_Sl_16_4  -1
    S         product_Su_16_5  -1
    S         product_Sl_16_5  -1
    S         product_Su_16_6  -1
    S         product_Sl_16_6  -1
    S         product_Su_16_7  -1
    S         product_Sl_16_7  -1
    S         product_Su_16_8  -1
    S         product_Sl_16_8  -1
    S         product_Su_16_9  -1
    S         product_Sl_16_9  -1
    S         product_Su_16_10  -1
    S         product_Sl_16_10  -1
    S         product_Su_16_11  -1
    S         product_Sl_16_11  -1
    S         product_Su_16_12  -1
    S         product_Sl_16_12  -1
    S         product_Su_16_13  -1
    S         product_Sl_16_13  -1
    S         product_Su_16_14  -1
    S         product_Sl_16_14  -1
    S         product_Su_16_15  -1
    S         product_Sl_16_15  -1
    S         product_mass_17  -1
    S         product_Su_17_0  -1
    S         product_Sl_17_0  -1
    S         product_Su_17_1  -1
    S         product_Sl_17_1  -1
    S         product_Su_17_2  -1
    S         product_Sl_17_2  -1
    S         product_Su_17_3  -1
    S         product_Sl_17_3  -1
    S         product_Su_17_4  -1
    S         product_Sl_17_4  -1
    S         product_Su_17_5  -1
    S         product_Sl_17_5  -1
    S         product_Su_17_6  -1
    S         product_Sl_17_6  -1
    S         product_mass_18  -1
    S         product_Su_18_0  -1
    S         product_Sl_18_0  -1
    S         product_Su_18_1  -1
    S         product_Sl_18_1  -1
    S         product_Su_18_2  -1
    S         product_Sl_18_2  -1
    S         product_Su_18_3  -1
    S         product_Sl_18_3  -1
    S         product_Su_18_4  -1
    S         product_Sl_18_4  -1
    S         product_Su_18_5  -1
    S         product_Sl_18_5  -1
    S         product_Su_18_6  -1
    S         product_Sl_18_6  -1
    S         product_Su_18_7  -1
    S         product_Sl_18_7  -1
    S         product_Su_18_8  -1
    S         product_Sl_18_8  -1
    S         product_Su_18_9  -1
    S         product_Sl_18_9  -1
    S         product_Su_18_10  -1
    S         product_Sl_18_10  -1
    S         product_mass_19  -1
    S         product_Su_19_0  -1
    S         product_Sl_19_0  -1
    S         product_Su_19_1  -1
    S         product_Sl_19_1  -1
    S         product_Su_19_2  -1
    S         product_Sl_19_2  -1
    S         product_Su_19_3  -1
    S         product_Sl_19_3  -1
    S         product_Su_19_4  -1
    S         product_Sl_19_4  -1
    S         product_Su_19_5  -1
    S         product_Sl_19_5  -1
    S         product_Su_19_6  -1
    S         product_Sl_19_6  -1
    S         product_Su_19_7  -1
    S         product_Sl_19_7  -1
    S         product_Su_19_8  -1
    S         product_Sl_19_8  -1
    S         product_Su_19_9  -1
    S         product_Sl_19_9  -1
    S         product_Su_19_10  -1
    S         product_Sl_19_10  -1
    S         product_mass_20  -1
    S         product_Su_20_0  -1
    S         product_Sl_20_0  -1
    S         product_Su_20_1  -1
    S         product_Sl_20_1  -1
    S         product_Su_20_2  -1
    S         product_Sl_20_2  -1
    S         product_Su_20_3  -1
    S         product_Sl_20_3  -1
    S         product_Su_20_4  -1
    S         product_Sl_20_4  -1
    S         product_Su_20_5  -1
    S         product_Sl_20_5  -1
    S         product_Su_20_6  -1
    S         product_Sl_20_6  -1
    S         product_Su_20_7  -1
    S         product_Sl_20_7  -1
    S         product_Su_20_8  -1
    S         product_Sl_20_8  -1
    S         product_Su_20_9  -1
    S         product_Sl_20_9  -1
    S         product_Su_20_10  -1
    S         product_Sl_20_10  -1
    S         product_mass_21  -1
    S         product_Su_21_0  -1
    S         product_Sl_21_0  -1
    S         product_Su_21_1  -1
    S         product_Sl_21_1  -1
    S         product_Su_21_2  -1
    S         product_Sl_21_2  -1
    S         product_Su_21_3  -1
    S         product_Sl_21_3  -1
    S         product_Su_21_4  -1
    S         product_Sl_21_4  -1
    S         product_Su_21_5  -1
    S         product_Sl_21_5  -1
    S         product_Su_21_6  -1
    S         product_Sl_21_6  -1
    S         product_mass_22  -1
    S         product_Su_22_0  -1
    S         product_Sl_22_0  -1
    S         product_Su_22_1  -1
    S         product_Sl_22_1  -1
    S         product_Su_22_2  -1
    S         product_Sl_22_2  -1
    S         product_Su_22_3  -1
    S         product_Sl_22_3  -1
    S         product_Su_22_4  -1
    S         product_Sl_22_4  -1
    S         product_Su_22_5  -1
    S         product_Sl_22_5  -1
    S         product_Su_22_6  -1
    S         product_Sl_22_6  -1
    S         product_Su_22_7  -1
    S         product_Sl_22_7  -1
    S         product_Su_22_8  -1
    S         product_Sl_22_8  -1
    S         product_Su_22_9  -1
    S         product_Sl_22_9  -1
    S         product_Su_22_10  -1
    S         product_Sl_22_10  -1
    S         product_Su_22_11  -1
    S         product_Sl_22_11  -1
    S         product_Su_22_12  -1
    S         product_Sl_22_12  -1
    S         product_Su_22_13  -1
    S         product_Sl_22_13  -1
    S         product_Su_22_14  -1
    S         product_Sl_22_14  -1
    S         product_Su_22_15  -1
    S         product_Sl_22_15  -1
    S         product_mass_23  -1
    S         product_Su_23_0  -1
    S         product_Sl_23_0  -1
    S         product_Su_23_1  -1
    S         product_Sl_23_1  -1
    S         product_Su_23_2  -1
    S         product_Sl_23_2  -1
    S         product_Su_23_3  -1
    S         product_Sl_23_3  -1
    S         product_mass_24  -1
    S         product_Su_24_0  -1
    S         product_Sl_24_0  -1
    S         product_Su_24_1  -1
    S         product_Sl_24_1  -1
    S         product_Su_24_2  -1
    S         product_Sl_24_2  -1
    S         product_Su_24_3  -1
    S         product_Sl_24_3  -1
    S         product_Su_24_4  -1
    S         product_Sl_24_4  -1
    S         product_Su_24_5  -1
    S         product_Sl_24_5  -1
    S         product_Su_24_6  -1
    S         product_Sl_24_6  -1
    S         product_Su_24_7  -1
    S         product_Sl_24_7  -1
    S         product_Su_24_8  -1
    S         product_Sl_24_8  -1
    S         product_Su_24_9  -1
    S         product_Sl_24_9  -1
    S         product_Su_24_10  -1
    S         product_Sl_24_10  -1
    S         product_Su_24_11  -1
    S         product_Sl_24_11  -1
    S         product_Su_24_12  -1
    S         product_Sl_24_12  -1
    S         product_Su_24_13  -1
    S         product_Sl_24_13  -1
    S         product_Su_24_14  -1
    S         product_Sl_24_14  -1
    S         product_Su_24_15  -1
    S         product_Sl_24_15  -1
    S         product_mass_25  -1
    S         product_Su_25_0  -1
    S         product_Sl_25_0  -1
    S         product_Su_25_1  -1
    S         product_Sl_25_1  -1
    S         product_Su_25_2  -1
    S         product_Sl_25_2  -1
    S         product_Su_25_3  -1
    S         product_Sl_25_3  -1
    S         product_Su_25_4  -1
    S         product_Sl_25_4  -1
    S         product_mass_26  -1
    S         product_Su_26_0  -1
    S         product_Sl_26_0  -1
    S         product_Su_26_1  -1
    S         product_Sl_26_1  -1
    S         product_Su_26_2  -1
    S         product_Sl_26_2  -1
    S         product_Su_26_3  -1
    S         product_Sl_26_3  -1
    S         product_Su_26_4  -1
    S         product_Sl_26_4  -1
    S         product_Su_26_5  -1
    S         product_Sl_26_5  -1
    S         product_Su_26_6  -1
    S         product_Sl_26_6  -1
    S         product_Su_26_7  -1
    S         product_Sl_26_7  -1
    S         product_Su_26_8  -1
    S         product_Sl_26_8  -1
    S         product_mass_27  -1
    S         product_Su_27_0  -1
    S         product_Sl_27_0  -1
    S         product_Su_27_1  -1
    S         product_Sl_27_1  -1
    S         product_Su_27_2  -1
    S         product_Sl_27_2  -1
    S         product_Su_27_3  -1
    S         product_Sl_27_3  -1
    S         product_Su_27_4  -1
    S         product_Sl_27_4  -1
    S         product_Su_27_5  -1
    S         product_Sl_27_5  -1
    S         product_Su_27_6  -1
    S         product_Sl_27_6  -1
    S         product_mass_28  -1
    S         product_Su_28_0  -1
    S         product_Sl_28_0  -1
    S         product_Su_28_1  -1
    S         product_Sl_28_1  -1
    S         product_Su_28_2  -1
    S         product_Sl_28_2  -1
    S         product_Su_28_3  -1
    S         product_Sl_28_3  -1
    S         product_Su_28_4  -1
    S         product_Sl_28_4  -1
    S         product_Su_28_5  -1
    S         product_Sl_28_5  -1
    S         product_Su_28_6  -1
    S         product_Sl_28_6  -1
    S         product_mass_29  -1
    S         product_Su_29_0  -1
    S         product_Sl_29_0  -1
    S         product_Su_29_1  -1
    S         product_Sl_29_1  -1
    S         product_Su_29_2  -1
    S         product_Sl_29_2  -1
    S         product_Su_29_3  -1
    S         product_Sl_29_3  -1
    S         product_Su_29_4  -1
    S         product_Sl_29_4  -1
    S         product_Su_29_5  -1
    S         product_Sl_29_5  -1
    S         product_Su_29_6  -1
    S         product_Sl_29_6  -1
    S         product_Su_29_7  -1
    S         product_Sl_29_7  -1
    S         product_Su_29_8  -1
    S         product_Sl_29_8  -1
    S         product_Su_29_9  -1
    S         product_Sl_29_9  -1
    S         product_Su_29_10  -1
    S         product_Sl_29_10  -1
    S         product_mass_30  -1
    S         product_Su_30_0  -1
    S         product_Sl_30_0  -1
    S         product_Su_30_1  -1
    S         product_Sl_30_1  -1
    S         product_Su_30_2  -1
    S         product_Sl_30_2  -1
    S         product_Su_30_3  -1
    S         product_Sl_30_3  -1
    S         product_Su_30_4  -1
    S         product_Sl_30_4  -1
    S         product_Su_30_5  -1
    S         product_Sl_30_5  -1
    S         product_Su_30_6  -1
    S         product_Sl_30_6  -1
    S         product_Su_30_7  -1
    S         product_Sl_30_7  -1
    S         product_Su_30_8  -1
    S         product_Sl_30_8  -1
    S         product_mass_31  -1
    S         product_Su_31_0  -1
    S         product_Sl_31_0  -1
    S         product_Su_31_1  -1
    S         product_Sl_31_1  -1
    S         product_Su_31_2  -1
    S         product_Sl_31_2  -1
    S         product_Su_31_3  -1
    S         product_Sl_31_3  -1
    S         product_Su_31_4  -1
    S         product_Sl_31_4  -1
    S         product_Su_31_5  -1
    S         product_Sl_31_5  -1
    S         product_Su_31_6  -1
    S         product_Sl_31_6  -1
    S         product_Su_31_7  -1
    S         product_Sl_31_7  -1
    S         product_Su_31_8  -1
    S         product_Sl_31_8  -1
    S         product_Su_31_9  -1
    S         product_Sl_31_9  -1
    S         product_Su_31_10  -1
    S         product_Sl_31_10  -1
    S         product_Su_31_11  -1
    S         product_Sl_31_11  -1
    S         product_mass_32  -1
    S         product_Su_32_0  -1
    S         product_Sl_32_0  -1
    S         product_Su_32_1  -1
    S         product_Sl_32_1  -1
    S         product_Su_32_2  -1
    S         product_Sl_32_2  -1
    S         product_Su_32_3  -1
    S         product_Sl_32_3  -1
    S         product_Su_32_4  -1
    S         product_Sl_32_4  -1
    S         product_Su_32_5  -1
    S         product_Sl_32_5  -1
    S         product_Su_32_6  -1
    S         product_Sl_32_6  -1
    S         product_Su_32_7  -1
    S         product_Sl_32_7  -1
    S         product_Su_32_8  -1
    S         product_Sl_32_8  -1
    S         product_Su_32_9  -1
    S         product_Sl_32_9  -1
    S         product_Su_32_10  -1
    S         product_Sl_32_10  -1
    S         product_Su_32_11  -1
    S         product_Sl_32_11  -1
    S         product_Su_32_12  -1
    S         product_Sl_32_12  -1
    S         product_Su_32_13  -1
    S         product_Sl_32_13  -1
    S         product_Su_32_14  -1
    S         product_Sl_32_14  -1
    S         product_Su_32_15  -1
    S         product_Sl_32_15  -1
    S         product_Su_32_16  -1
    S         product_Sl_32_16  -1
    S         product_Su_32_17  -1
    S         product_Sl_32_17  -1
    S         product_Su_32_18  -1
    S         product_Sl_32_18  -1
    S         product_Su_32_19  -1
    S         product_Sl_32_19  -1
    S         product_mass_33  -1
    S         product_Su_33_0  -1
    S         product_Sl_33_0  -1
    S         product_Su_33_1  -1
    S         product_Sl_33_1  -1
    S         product_Su_33_2  -1
    S         product_Sl_33_2  -1
    S         product_Su_33_3  -1
    S         product_Sl_33_3  -1
    S         product_Su_33_4  -1
    S         product_Sl_33_4  -1
    S         product_Su_33_5  -1
    S         product_Sl_33_5  -1
    S         product_Su_33_6  -1
    S         product_Sl_33_6  -1
    S         product_Su_33_7  -1
    S         product_Sl_33_7  -1
    S         product_Su_33_8  -1
    S         product_Sl_33_8  -1
    S         product_Su_33_9  -1
    S         product_Sl_33_9  -1
    S         product_Su_33_10  -1
    S         product_Sl_33_10  -1
    S         product_Su_33_11  -1
    S         product_Sl_33_11  -1
    S         product_mass_34  -1
    S         product_Su_34_0  -1
    S         product_Sl_34_0  -1
    S         product_Su_34_1  -1
    S         product_Sl_34_1  -1
    S         product_Su_34_2  -1
    S         product_Sl_34_2  -1
    S         product_Su_34_3  -1
    S         product_Sl_34_3  -1
    S         product_Su_34_4  -1
    S         product_Sl_34_4  -1
    S         product_Su_34_5  -1
    S         product_Sl_34_5  -1
    S         product_Su_34_6  -1
    S         product_Sl_34_6  -1
    S         product_Su_34_7  -1
    S         product_Sl_34_7  -1
    S         product_Su_34_8  -1
    S         product_Sl_34_8  -1
    S         product_Su_34_9  -1
    S         product_Sl_34_9  -1
    S         product_Su_34_10  -1
    S         product_Sl_34_10  -1
    S         product_Su_34_11  -1
    S         product_Sl_34_11  -1
    S         product_Su_34_12  -1
    S         product_Sl_34_12  -1
    S         product_Su_34_13  -1
    S         product_Sl_34_13  -1
    S         product_Su_34_14  -1
    S         product_Sl_34_14  -1
    S         product_Su_34_15  -1
    S         product_Sl_34_15  -1
    S         product_mass_35  -1
    S         product_Su_35_0  -1
    S         product_Sl_35_0  -1
    S         product_Su_35_1  -1
    S         product_Sl_35_1  -1
    S         product_Su_35_2  -1
    S         product_Sl_35_2  -1
    S         product_Su_35_3  -1
    S         product_Sl_35_3  -1
    S         product_Su_35_4  -1
    S         product_Sl_35_4  -1
    S         product_Su_35_5  -1
    S         product_Sl_35_5  -1
    S         product_Su_35_6  -1
    S         product_Sl_35_6  -1
    S         product_Su_35_7  -1
    S         product_Sl_35_7  -1
    S         product_Su_35_8  -1
    S         product_Sl_35_8  -1
    S         product_Su_35_9  -1
    S         product_Sl_35_9  -1
    S         product_Su_35_10  -1
    S         product_Sl_35_10  -1
    S         product_Su_35_11  -1
    S         product_Sl_35_11  -1
    S         product_Su_35_12  -1
    S         product_Sl_35_12  -1
    S         product_Su_35_13  -1
    S         product_Sl_35_13  -1
    S         product_Su_35_14  -1
    S         product_Sl_35_14  -1
    S         product_Su_35_15  -1
    S         product_Sl_35_15  -1
    S         denominator  1
    S         physical_G_upper_outward  -1.4862744580727425e+01
    S         total_product_lower  -71
    S         total_product_upper  -146
    S         conditional_complement_lower_1_0  1
    S         conditional_complement_upper_1_0  1
    S         conditional_complement_lower_1_1  1
    S         conditional_complement_upper_1_1  1
    S         conditional_complement_lower_1_2  1
    S         conditional_complement_upper_1_2  1
    S         conditional_complement_lower_1_3  1
    S         conditional_complement_upper_1_3  1
    S         conditional_complement_lower_1_4  1
    S         conditional_complement_upper_1_4  1
    S         conditional_complement_lower_1_5  1
    S         conditional_complement_upper_1_5  1
    S         conditional_complement_lower_1_6  1
    S         conditional_complement_upper_1_6  1
    S         conditional_complement_lower_1_7  1
    S         conditional_complement_upper_1_7  1
    S         conditional_complement_lower_1_8  1
    S         conditional_complement_upper_1_8  1
    S         conditional_complement_lower_2_0  1
    S         conditional_complement_upper_2_0  1
    S         conditional_complement_lower_2_1  1
    S         conditional_complement_upper_2_1  1
    S         conditional_complement_lower_2_2  1
    S         conditional_complement_upper_2_2  1
    S         conditional_complement_lower_2_3  1
    S         conditional_complement_upper_2_3  1
    S         conditional_complement_lower_2_4  1
    S         conditional_complement_upper_2_4  1
    S         conditional_complement_lower_2_5  1
    S         conditional_complement_upper_2_5  1
    S         conditional_complement_lower_2_6  1
    S         conditional_complement_upper_2_6  1
    S         conditional_complement_lower_2_7  1
    S         conditional_complement_upper_2_7  1
    S         conditional_complement_lower_2_8  1
    S         conditional_complement_upper_2_8  1
    S         conditional_complement_lower_2_9  1
    S         conditional_complement_upper_2_9  1
    S         conditional_complement_lower_2_10  1
    S         conditional_complement_upper_2_10  1
    S         conditional_complement_lower_2_11  1
    S         conditional_complement_upper_2_11  1
    S         conditional_complement_lower_2_12  1
    S         conditional_complement_upper_2_12  1
    S         conditional_complement_lower_2_13  1
    S         conditional_complement_upper_2_13  1
    S         conditional_complement_lower_2_14  1
    S         conditional_complement_upper_2_14  1
    S         conditional_complement_lower_2_15  1
    S         conditional_complement_upper_2_15  1
    S         conditional_complement_lower_3_0  1
    S         conditional_complement_upper_3_0  1
    S         conditional_complement_lower_3_1  1
    S         conditional_complement_upper_3_1  1
    S         conditional_complement_lower_3_2  1
    S         conditional_complement_upper_3_2  1
    S         conditional_complement_lower_3_3  1
    S         conditional_complement_upper_3_3  1
    S         conditional_complement_lower_3_4  1
    S         conditional_complement_upper_3_4  1
    S         conditional_complement_lower_3_5  1
    S         conditional_complement_upper_3_5  1
    S         conditional_complement_lower_3_6  1
    S         conditional_complement_upper_3_6  1
    S         conditional_complement_lower_3_7  1
    S         conditional_complement_upper_3_7  1
    S         conditional_complement_lower_3_8  1
    S         conditional_complement_upper_3_8  1
    S         conditional_complement_lower_3_9  1
    S         conditional_complement_upper_3_9  1
    S         conditional_complement_lower_3_10  1
    S         conditional_complement_upper_3_10  1
    S         conditional_complement_lower_3_11  1
    S         conditional_complement_upper_3_11  1
    S         conditional_complement_lower_3_12  1
    S         conditional_complement_upper_3_12  1
    S         conditional_complement_lower_4_0  1
    S         conditional_complement_upper_4_0  1
    S         conditional_complement_lower_4_1  1
    S         conditional_complement_upper_4_1  1
    S         conditional_complement_lower_4_2  1
    S         conditional_complement_upper_4_2  1
    S         conditional_complement_lower_4_3  1
    S         conditional_complement_upper_4_3  1
    S         conditional_complement_lower_4_4  1
    S         conditional_complement_upper_4_4  1
    S         conditional_complement_lower_4_5  1
    S         conditional_complement_upper_4_5  1
    S         conditional_complement_lower_4_6  1
    S         conditional_complement_upper_4_6  1
    S         conditional_complement_lower_4_7  1
    S         conditional_complement_upper_4_7  1
    S         conditional_complement_lower_4_8  1
    S         conditional_complement_upper_4_8  1
    S         conditional_complement_lower_4_9  1
    S         conditional_complement_upper_4_9  1
    S         conditional_complement_lower_4_10  1
    S         conditional_complement_upper_4_10  1
    S         conditional_complement_lower_4_11  1
    S         conditional_complement_upper_4_11  1
    S         conditional_complement_lower_4_12  1
    S         conditional_complement_upper_4_12  1
    S         conditional_complement_lower_4_13  1
    S         conditional_complement_upper_4_13  1
    S         conditional_complement_lower_4_14  1
    S         conditional_complement_upper_4_14  1
    S         conditional_complement_lower_4_15  1
    S         conditional_complement_upper_4_15  1
    S         conditional_complement_lower_5_0  1
    S         conditional_complement_upper_5_0  1
    S         conditional_complement_lower_5_1  1
    S         conditional_complement_upper_5_1  1
    S         conditional_complement_lower_5_2  1
    S         conditional_complement_upper_5_2  1
    S         conditional_complement_lower_5_3  1
    S         conditional_complement_upper_5_3  1
    S         conditional_complement_lower_5_4  1
    S         conditional_complement_upper_5_4  1
    S         conditional_complement_lower_5_5  1
    S         conditional_complement_upper_5_5  1
    S         conditional_complement_lower_5_6  1
    S         conditional_complement_upper_5_6  1
    S         conditional_complement_lower_5_7  1
    S         conditional_complement_upper_5_7  1
    S         conditional_complement_lower_5_8  1
    S         conditional_complement_upper_5_8  1
    S         conditional_complement_lower_5_9  1
    S         conditional_complement_upper_5_9  1
    S         conditional_complement_lower_5_10  1
    S         conditional_complement_upper_5_10  1
    S         conditional_complement_lower_5_11  1
    S         conditional_complement_upper_5_11  1
    S         conditional_complement_lower_5_12  1
    S         conditional_complement_upper_5_12  1
    S         conditional_complement_lower_5_13  1
    S         conditional_complement_upper_5_13  1
    S         conditional_complement_lower_5_14  1
    S         conditional_complement_upper_5_14  1
    S         conditional_complement_lower_5_15  1
    S         conditional_complement_upper_5_15  1
    S         conditional_complement_lower_6_0  1
    S         conditional_complement_upper_6_0  1
    S         conditional_complement_lower_6_1  1
    S         conditional_complement_upper_6_1  1
    S         conditional_complement_lower_6_2  1
    S         conditional_complement_upper_6_2  1
    S         conditional_complement_lower_6_3  1
    S         conditional_complement_upper_6_3  1
    S         conditional_complement_lower_6_4  1
    S         conditional_complement_upper_6_4  1
    S         conditional_complement_lower_6_5  1
    S         conditional_complement_upper_6_5  1
    S         conditional_complement_lower_6_6  1
    S         conditional_complement_upper_6_6  1
    S         conditional_complement_lower_6_7  1
    S         conditional_complement_upper_6_7  1
    S         conditional_complement_lower_6_8  1
    S         conditional_complement_upper_6_8  1
    S         conditional_complement_lower_7_0  1
    S         conditional_complement_upper_7_0  1
    S         conditional_complement_lower_7_1  1
    S         conditional_complement_upper_7_1  1
    S         conditional_complement_lower_7_2  1
    S         conditional_complement_upper_7_2  1
    S         conditional_complement_lower_7_3  1
    S         conditional_complement_upper_7_3  1
    S         conditional_complement_lower_7_4  1
    S         conditional_complement_upper_7_4  1
    S         conditional_complement_lower_7_5  1
    S         conditional_complement_upper_7_5  1
    S         conditional_complement_lower_7_6  1
    S         conditional_complement_upper_7_6  1
    S         conditional_complement_lower_7_7  1
    S         conditional_complement_upper_7_7  1
    S         conditional_complement_lower_7_8  1
    S         conditional_complement_upper_7_8  1
    S         conditional_complement_lower_7_9  1
    S         conditional_complement_upper_7_9  1
    S         conditional_complement_lower_7_10  1
    S         conditional_complement_upper_7_10  1
    S         conditional_complement_lower_7_11  1
    S         conditional_complement_upper_7_11  1
    S         conditional_complement_lower_7_12  1
    S         conditional_complement_upper_7_12  1
    S         conditional_complement_lower_7_13  1
    S         conditional_complement_upper_7_13  1
    S         conditional_complement_lower_7_14  1
    S         conditional_complement_upper_7_14  1
    S         conditional_complement_lower_7_15  1
    S         conditional_complement_upper_7_15  1
    S         conditional_complement_lower_8_0  1
    S         conditional_complement_upper_8_0  1
    S         conditional_complement_lower_8_1  1
    S         conditional_complement_upper_8_1  1
    S         conditional_complement_lower_8_2  1
    S         conditional_complement_upper_8_2  1
    S         conditional_complement_lower_8_3  1
    S         conditional_complement_upper_8_3  1
    S         conditional_complement_lower_8_4  1
    S         conditional_complement_upper_8_4  1
    S         conditional_complement_lower_8_5  1
    S         conditional_complement_upper_8_5  1
    S         conditional_complement_lower_8_6  1
    S         conditional_complement_upper_8_6  1
    S         conditional_complement_lower_8_7  1
    S         conditional_complement_upper_8_7  1
    S         conditional_complement_lower_8_8  1
    S         conditional_complement_upper_8_8  1
    S         conditional_complement_lower_8_9  1
    S         conditional_complement_upper_8_9  1
    S         conditional_complement_lower_8_10  1
    S         conditional_complement_upper_8_10  1
    S         conditional_complement_lower_8_11  1
    S         conditional_complement_upper_8_11  1
    S         conditional_complement_lower_8_12  1
    S         conditional_complement_upper_8_12  1
    S         conditional_complement_lower_9_0  1
    S         conditional_complement_upper_9_0  1
    S         conditional_complement_lower_9_1  1
    S         conditional_complement_upper_9_1  1
    S         conditional_complement_lower_9_2  1
    S         conditional_complement_upper_9_2  1
    S         conditional_complement_lower_9_3  1
    S         conditional_complement_upper_9_3  1
    S         conditional_complement_lower_9_4  1
    S         conditional_complement_upper_9_4  1
    S         conditional_complement_lower_9_5  1
    S         conditional_complement_upper_9_5  1
    S         conditional_complement_lower_9_6  1
    S         conditional_complement_upper_9_6  1
    S         conditional_complement_lower_9_7  1
    S         conditional_complement_upper_9_7  1
    S         conditional_complement_lower_9_8  1
    S         conditional_complement_upper_9_8  1
    S         conditional_complement_lower_9_9  1
    S         conditional_complement_upper_9_9  1
    S         conditional_complement_lower_9_10  1
    S         conditional_complement_upper_9_10  1
    S         conditional_complement_lower_10_0  1
    S         conditional_complement_upper_10_0  1
    S         conditional_complement_lower_10_1  1
    S         conditional_complement_upper_10_1  1
    S         conditional_complement_lower_10_2  1
    S         conditional_complement_upper_10_2  1
    S         conditional_complement_lower_10_3  1
    S         conditional_complement_upper_10_3  1
    S         conditional_complement_lower_10_4  1
    S         conditional_complement_upper_10_4  1
    S         conditional_complement_lower_10_5  1
    S         conditional_complement_upper_10_5  1
    S         conditional_complement_lower_10_6  1
    S         conditional_complement_upper_10_6  1
    S         conditional_complement_lower_11_0  1
    S         conditional_complement_upper_11_0  1
    S         conditional_complement_lower_11_1  1
    S         conditional_complement_upper_11_1  1
    S         conditional_complement_lower_11_2  1
    S         conditional_complement_upper_11_2  1
    S         conditional_complement_lower_11_3  1
    S         conditional_complement_upper_11_3  1
    S         conditional_complement_lower_11_4  1
    S         conditional_complement_upper_11_4  1
    S         conditional_complement_lower_11_5  1
    S         conditional_complement_upper_11_5  1
    S         conditional_complement_lower_11_6  1
    S         conditional_complement_upper_11_6  1
    S         conditional_complement_lower_11_7  1
    S         conditional_complement_upper_11_7  1
    S         conditional_complement_lower_11_8  1
    S         conditional_complement_upper_11_8  1
    S         conditional_complement_lower_11_9  1
    S         conditional_complement_upper_11_9  1
    S         conditional_complement_lower_11_10  1
    S         conditional_complement_upper_11_10  1
    S         conditional_complement_lower_12_0  1
    S         conditional_complement_upper_12_0  1
    S         conditional_complement_lower_12_1  1
    S         conditional_complement_upper_12_1  1
    S         conditional_complement_lower_12_2  1
    S         conditional_complement_upper_12_2  1
    S         conditional_complement_lower_12_3  1
    S         conditional_complement_upper_12_3  1
    S         conditional_complement_lower_12_4  1
    S         conditional_complement_upper_12_4  1
    S         conditional_complement_lower_12_5  1
    S         conditional_complement_upper_12_5  1
    S         conditional_complement_lower_12_6  1
    S         conditional_complement_upper_12_6  1
    S         conditional_complement_lower_12_7  1
    S         conditional_complement_upper_12_7  1
    S         conditional_complement_lower_12_8  1
    S         conditional_complement_upper_12_8  1
    S         conditional_complement_lower_12_9  1
    S         conditional_complement_upper_12_9  1
    S         conditional_complement_lower_12_10  1
    S         conditional_complement_upper_12_10  1
    S         conditional_complement_lower_12_11  1
    S         conditional_complement_upper_12_11  1
    S         conditional_complement_lower_12_12  1
    S         conditional_complement_upper_12_12  1
    S         conditional_complement_lower_13_0  1
    S         conditional_complement_upper_13_0  1
    S         conditional_complement_lower_13_1  1
    S         conditional_complement_upper_13_1  1
    S         conditional_complement_lower_13_2  1
    S         conditional_complement_upper_13_2  1
    S         conditional_complement_lower_13_3  1
    S         conditional_complement_upper_13_3  1
    S         conditional_complement_lower_13_4  1
    S         conditional_complement_upper_13_4  1
    S         conditional_complement_lower_13_5  1
    S         conditional_complement_upper_13_5  1
    S         conditional_complement_lower_13_6  1
    S         conditional_complement_upper_13_6  1
    S         conditional_complement_lower_13_7  1
    S         conditional_complement_upper_13_7  1
    S         conditional_complement_lower_13_8  1
    S         conditional_complement_upper_13_8  1
    S         conditional_complement_lower_14_0  1
    S         conditional_complement_upper_14_0  1
    S         conditional_complement_lower_14_1  1
    S         conditional_complement_upper_14_1  1
    S         conditional_complement_lower_14_2  1
    S         conditional_complement_upper_14_2  1
    S         conditional_complement_lower_14_3  1
    S         conditional_complement_upper_14_3  1
    S         conditional_complement_lower_14_4  1
    S         conditional_complement_upper_14_4  1
    S         conditional_complement_lower_14_5  1
    S         conditional_complement_upper_14_5  1
    S         conditional_complement_lower_14_6  1
    S         conditional_complement_upper_14_6  1
    S         conditional_complement_lower_14_7  1
    S         conditional_complement_upper_14_7  1
    S         conditional_complement_lower_14_8  1
    S         conditional_complement_upper_14_8  1
    S         conditional_complement_lower_15_0  1
    S         conditional_complement_upper_15_0  1
    S         conditional_complement_lower_15_1  1
    S         conditional_complement_upper_15_1  1
    S         conditional_complement_lower_15_2  1
    S         conditional_complement_upper_15_2  1
    S         conditional_complement_lower_15_3  1
    S         conditional_complement_upper_15_3  1
    S         conditional_complement_lower_15_4  1
    S         conditional_complement_upper_15_4  1
    S         conditional_complement_lower_15_5  1
    S         conditional_complement_upper_15_5  1
    S         conditional_complement_lower_15_6  1
    S         conditional_complement_upper_15_6  1
    S         conditional_complement_lower_15_7  1
    S         conditional_complement_upper_15_7  1
    S         conditional_complement_lower_15_8  1
    S         conditional_complement_upper_15_8  1
    S         conditional_complement_lower_16_0  1
    S         conditional_complement_upper_16_0  1
    S         conditional_complement_lower_16_1  1
    S         conditional_complement_upper_16_1  1
    S         conditional_complement_lower_16_2  1
    S         conditional_complement_upper_16_2  1
    S         conditional_complement_lower_16_3  1
    S         conditional_complement_upper_16_3  1
    S         conditional_complement_lower_16_4  1
    S         conditional_complement_upper_16_4  1
    S         conditional_complement_lower_16_5  1
    S         conditional_complement_upper_16_5  1
    S         conditional_complement_lower_16_6  1
    S         conditional_complement_upper_16_6  1
    S         conditional_complement_lower_16_7  1
    S         conditional_complement_upper_16_7  1
    S         conditional_complement_lower_16_8  1
    S         conditional_complement_upper_16_8  1
    S         conditional_complement_lower_16_9  1
    S         conditional_complement_upper_16_9  1
    S         conditional_complement_lower_16_10  1
    S         conditional_complement_upper_16_10  1
    S         conditional_complement_lower_16_11  1
    S         conditional_complement_upper_16_11  1
    S         conditional_complement_lower_16_12  1
    S         conditional_complement_upper_16_12  1
    S         conditional_complement_lower_16_13  1
    S         conditional_complement_upper_16_13  1
    S         conditional_complement_lower_16_14  1
    S         conditional_complement_upper_16_14  1
    S         conditional_complement_lower_16_15  1
    S         conditional_complement_upper_16_15  1
    S         conditional_complement_lower_17_0  1
    S         conditional_complement_upper_17_0  1
    S         conditional_complement_lower_17_1  1
    S         conditional_complement_upper_17_1  1
    S         conditional_complement_lower_17_2  1
    S         conditional_complement_upper_17_2  1
    S         conditional_complement_lower_17_3  1
    S         conditional_complement_upper_17_3  1
    S         conditional_complement_lower_17_4  1
    S         conditional_complement_upper_17_4  1
    S         conditional_complement_lower_17_5  1
    S         conditional_complement_upper_17_5  1
    S         conditional_complement_lower_17_6  1
    S         conditional_complement_upper_17_6  1
    S         conditional_complement_lower_18_0  1
    S         conditional_complement_upper_18_0  1
    S         conditional_complement_lower_18_1  1
    S         conditional_complement_upper_18_1  1
    S         conditional_complement_lower_18_2  1
    S         conditional_complement_upper_18_2  1
    S         conditional_complement_lower_18_3  1
    S         conditional_complement_upper_18_3  1
    S         conditional_complement_lower_18_4  1
    S         conditional_complement_upper_18_4  1
    S         conditional_complement_lower_18_5  1
    S         conditional_complement_upper_18_5  1
    S         conditional_complement_lower_18_6  1
    S         conditional_complement_upper_18_6  1
    S         conditional_complement_lower_18_7  1
    S         conditional_complement_upper_18_7  1
    S         conditional_complement_lower_18_8  1
    S         conditional_complement_upper_18_8  1
    S         conditional_complement_lower_18_9  1
    S         conditional_complement_upper_18_9  1
    S         conditional_complement_lower_18_10  1
    S         conditional_complement_upper_18_10  1
    S         conditional_complement_lower_19_0  1
    S         conditional_complement_upper_19_0  1
    S         conditional_complement_lower_19_1  1
    S         conditional_complement_upper_19_1  1
    S         conditional_complement_lower_19_2  1
    S         conditional_complement_upper_19_2  1
    S         conditional_complement_lower_19_3  1
    S         conditional_complement_upper_19_3  1
    S         conditional_complement_lower_19_4  1
    S         conditional_complement_upper_19_4  1
    S         conditional_complement_lower_19_5  1
    S         conditional_complement_upper_19_5  1
    S         conditional_complement_lower_19_6  1
    S         conditional_complement_upper_19_6  1
    S         conditional_complement_lower_19_7  1
    S         conditional_complement_upper_19_7  1
    S         conditional_complement_lower_19_8  1
    S         conditional_complement_upper_19_8  1
    S         conditional_complement_lower_19_9  1
    S         conditional_complement_upper_19_9  1
    S         conditional_complement_lower_19_10  1
    S         conditional_complement_upper_19_10  1
    S         conditional_complement_lower_20_0  1
    S         conditional_complement_upper_20_0  1
    S         conditional_complement_lower_20_1  1
    S         conditional_complement_upper_20_1  1
    S         conditional_complement_lower_20_2  1
    S         conditional_complement_upper_20_2  1
    S         conditional_complement_lower_20_3  1
    S         conditional_complement_upper_20_3  1
    S         conditional_complement_lower_20_4  1
    S         conditional_complement_upper_20_4  1
    S         conditional_complement_lower_20_5  1
    S         conditional_complement_upper_20_5  1
    S         conditional_complement_lower_20_6  1
    S         conditional_complement_upper_20_6  1
    S         conditional_complement_lower_20_7  1
    S         conditional_complement_upper_20_7  1
    S         conditional_complement_lower_20_8  1
    S         conditional_complement_upper_20_8  1
    S         conditional_complement_lower_20_9  1
    S         conditional_complement_upper_20_9  1
    S         conditional_complement_lower_20_10  1
    S         conditional_complement_upper_20_10  1
    S         conditional_complement_lower_21_0  1
    S         conditional_complement_upper_21_0  1
    S         conditional_complement_lower_21_1  1
    S         conditional_complement_upper_21_1  1
    S         conditional_complement_lower_21_2  1
    S         conditional_complement_upper_21_2  1
    S         conditional_complement_lower_21_3  1
    S         conditional_complement_upper_21_3  1
    S         conditional_complement_lower_21_4  1
    S         conditional_complement_upper_21_4  1
    S         conditional_complement_lower_21_5  1
    S         conditional_complement_upper_21_5  1
    S         conditional_complement_lower_21_6  1
    S         conditional_complement_upper_21_6  1
    S         conditional_complement_lower_22_0  1
    S         conditional_complement_upper_22_0  1
    S         conditional_complement_lower_22_1  1
    S         conditional_complement_upper_22_1  1
    S         conditional_complement_lower_22_2  1
    S         conditional_complement_upper_22_2  1
    S         conditional_complement_lower_22_3  1
    S         conditional_complement_upper_22_3  1
    S         conditional_complement_lower_22_4  1
    S         conditional_complement_upper_22_4  1
    S         conditional_complement_lower_22_5  1
    S         conditional_complement_upper_22_5  1
    S         conditional_complement_lower_22_6  1
    S         conditional_complement_upper_22_6  1
    S         conditional_complement_lower_22_7  1
    S         conditional_complement_upper_22_7  1
    S         conditional_complement_lower_22_8  1
    S         conditional_complement_upper_22_8  1
    S         conditional_complement_lower_22_9  1
    S         conditional_complement_upper_22_9  1
    S         conditional_complement_lower_22_10  1
    S         conditional_complement_upper_22_10  1
    S         conditional_complement_lower_22_11  1
    S         conditional_complement_upper_22_11  1
    S         conditional_complement_lower_22_12  1
    S         conditional_complement_upper_22_12  1
    S         conditional_complement_lower_22_13  1
    S         conditional_complement_upper_22_13  1
    S         conditional_complement_lower_22_14  1
    S         conditional_complement_upper_22_14  1
    S         conditional_complement_lower_22_15  1
    S         conditional_complement_upper_22_15  1
    S         conditional_complement_lower_23_0  1
    S         conditional_complement_upper_23_0  1
    S         conditional_complement_lower_23_1  1
    S         conditional_complement_upper_23_1  1
    S         conditional_complement_lower_23_2  1
    S         conditional_complement_upper_23_2  1
    S         conditional_complement_lower_23_3  1
    S         conditional_complement_upper_23_3  1
    S         conditional_complement_lower_24_0  1
    S         conditional_complement_upper_24_0  1
    S         conditional_complement_lower_24_1  1
    S         conditional_complement_upper_24_1  1
    S         conditional_complement_lower_24_2  1
    S         conditional_complement_upper_24_2  1
    S         conditional_complement_lower_24_3  1
    S         conditional_complement_upper_24_3  1
    S         conditional_complement_lower_24_4  1
    S         conditional_complement_upper_24_4  1
    S         conditional_complement_lower_24_5  1
    S         conditional_complement_upper_24_5  1
    S         conditional_complement_lower_24_6  1
    S         conditional_complement_upper_24_6  1
    S         conditional_complement_lower_24_7  1
    S         conditional_complement_upper_24_7  1
    S         conditional_complement_lower_24_8  1
    S         conditional_complement_upper_24_8  1
    S         conditional_complement_lower_24_9  1
    S         conditional_complement_upper_24_9  1
    S         conditional_complement_lower_24_10  1
    S         conditional_complement_upper_24_10  1
    S         conditional_complement_lower_24_11  1
    S         conditional_complement_upper_24_11  1
    S         conditional_complement_lower_24_12  1
    S         conditional_complement_upper_24_12  1
    S         conditional_complement_lower_24_13  1
    S         conditional_complement_upper_24_13  1
    S         conditional_complement_lower_24_14  1
    S         conditional_complement_upper_24_14  1
    S         conditional_complement_lower_24_15  1
    S         conditional_complement_upper_24_15  1
    S         conditional_complement_lower_25_0  1
    S         conditional_complement_upper_25_0  1
    S         conditional_complement_lower_25_1  1
    S         conditional_complement_upper_25_1  1
    S         conditional_complement_lower_25_2  1
    S         conditional_complement_upper_25_2  1
    S         conditional_complement_lower_25_3  1
    S         conditional_complement_upper_25_3  1
    S         conditional_complement_lower_25_4  1
    S         conditional_complement_upper_25_4  1
    S         conditional_complement_lower_26_0  1
    S         conditional_complement_upper_26_0  1
    S         conditional_complement_lower_26_1  1
    S         conditional_complement_upper_26_1  1
    S         conditional_complement_lower_26_2  1
    S         conditional_complement_upper_26_2  1
    S         conditional_complement_lower_26_3  1
    S         conditional_complement_upper_26_3  1
    S         conditional_complement_lower_26_4  1
    S         conditional_complement_upper_26_4  1
    S         conditional_complement_lower_26_5  1
    S         conditional_complement_upper_26_5  1
    S         conditional_complement_lower_26_6  1
    S         conditional_complement_upper_26_6  1
    S         conditional_complement_lower_26_7  1
    S         conditional_complement_upper_26_7  1
    S         conditional_complement_lower_26_8  1
    S         conditional_complement_upper_26_8  1
    S         conditional_complement_lower_27_0  1
    S         conditional_complement_upper_27_0  1
    S         conditional_complement_lower_27_1  1
    S         conditional_complement_upper_27_1  1
    S         conditional_complement_lower_27_2  1
    S         conditional_complement_upper_27_2  1
    S         conditional_complement_lower_27_3  1
    S         conditional_complement_upper_27_3  1
    S         conditional_complement_lower_27_4  1
    S         conditional_complement_upper_27_4  1
    S         conditional_complement_lower_27_5  1
    S         conditional_complement_upper_27_5  1
    S         conditional_complement_lower_27_6  1
    S         conditional_complement_upper_27_6  1
    S         conditional_complement_lower_28_0  1
    S         conditional_complement_upper_28_0  1
    S         conditional_complement_lower_28_1  1
    S         conditional_complement_upper_28_1  1
    S         conditional_complement_lower_28_2  1
    S         conditional_complement_upper_28_2  1
    S         conditional_complement_lower_28_3  1
    S         conditional_complement_upper_28_3  1
    S         conditional_complement_lower_28_4  1
    S         conditional_complement_upper_28_4  1
    S         conditional_complement_lower_28_5  1
    S         conditional_complement_upper_28_5  1
    S         conditional_complement_lower_28_6  1
    S         conditional_complement_upper_28_6  1
    S         conditional_complement_lower_29_0  1
    S         conditional_complement_upper_29_0  1
    S         conditional_complement_lower_29_1  1
    S         conditional_complement_upper_29_1  1
    S         conditional_complement_lower_29_2  1
    S         conditional_complement_upper_29_2  1
    S         conditional_complement_lower_29_3  1
    S         conditional_complement_upper_29_3  1
    S         conditional_complement_lower_29_4  1
    S         conditional_complement_upper_29_4  1
    S         conditional_complement_lower_29_5  1
    S         conditional_complement_upper_29_5  1
    S         conditional_complement_lower_29_6  1
    S         conditional_complement_upper_29_6  1
    S         conditional_complement_lower_29_7  1
    S         conditional_complement_upper_29_7  1
    S         conditional_complement_lower_29_8  1
    S         conditional_complement_upper_29_8  1
    S         conditional_complement_lower_29_9  1
    S         conditional_complement_upper_29_9  1
    S         conditional_complement_lower_29_10  1
    S         conditional_complement_upper_29_10  1
    S         conditional_complement_lower_30_0  1
    S         conditional_complement_upper_30_0  1
    S         conditional_complement_lower_30_1  1
    S         conditional_complement_upper_30_1  1
    S         conditional_complement_lower_30_2  1
    S         conditional_complement_upper_30_2  1
    S         conditional_complement_lower_30_3  1
    S         conditional_complement_upper_30_3  1
    S         conditional_complement_lower_30_4  1
    S         conditional_complement_upper_30_4  1
    S         conditional_complement_lower_30_5  1
    S         conditional_complement_upper_30_5  1
    S         conditional_complement_lower_30_6  1
    S         conditional_complement_upper_30_6  1
    S         conditional_complement_lower_30_7  1
    S         conditional_complement_upper_30_7  1
    S         conditional_complement_lower_30_8  1
    S         conditional_complement_upper_30_8  1
    S         conditional_complement_lower_31_0  1
    S         conditional_complement_upper_31_0  1
    S         conditional_complement_lower_31_1  1
    S         conditional_complement_upper_31_1  1
    S         conditional_complement_lower_31_2  1
    S         conditional_complement_upper_31_2  1
    S         conditional_complement_lower_31_3  1
    S         conditional_complement_upper_31_3  1
    S         conditional_complement_lower_31_4  1
    S         conditional_complement_upper_31_4  1
    S         conditional_complement_lower_31_5  1
    S         conditional_complement_upper_31_5  1
    S         conditional_complement_lower_31_6  1
    S         conditional_complement_upper_31_6  1
    S         conditional_complement_lower_31_7  1
    S         conditional_complement_upper_31_7  1
    S         conditional_complement_lower_31_8  1
    S         conditional_complement_upper_31_8  1
    S         conditional_complement_lower_31_9  1
    S         conditional_complement_upper_31_9  1
    S         conditional_complement_lower_31_10  1
    S         conditional_complement_upper_31_10  1
    S         conditional_complement_lower_31_11  1
    S         conditional_complement_upper_31_11  1
    S         conditional_complement_lower_32_0  1
    S         conditional_complement_upper_32_0  1
    S         conditional_complement_lower_32_1  1
    S         conditional_complement_upper_32_1  1
    S         conditional_complement_lower_32_2  1
    S         conditional_complement_upper_32_2  1
    S         conditional_complement_lower_32_3  1
    S         conditional_complement_upper_32_3  1
    S         conditional_complement_lower_32_4  1
    S         conditional_complement_upper_32_4  1
    S         conditional_complement_lower_32_5  1
    S         conditional_complement_upper_32_5  1
    S         conditional_complement_lower_32_6  1
    S         conditional_complement_upper_32_6  1
    S         conditional_complement_lower_32_7  1
    S         conditional_complement_upper_32_7  1
    S         conditional_complement_lower_32_8  1
    S         conditional_complement_upper_32_8  1
    S         conditional_complement_lower_32_9  1
    S         conditional_complement_upper_32_9  1
    S         conditional_complement_lower_32_10  1
    S         conditional_complement_upper_32_10  1
    S         conditional_complement_lower_32_11  1
    S         conditional_complement_upper_32_11  1
    S         conditional_complement_lower_32_12  1
    S         conditional_complement_upper_32_12  1
    S         conditional_complement_lower_32_13  1
    S         conditional_complement_upper_32_13  1
    S         conditional_complement_lower_32_14  1
    S         conditional_complement_upper_32_14  1
    S         conditional_complement_lower_32_15  1
    S         conditional_complement_upper_32_15  1
    S         conditional_complement_lower_32_16  1
    S         conditional_complement_upper_32_16  1
    S         conditional_complement_lower_32_17  1
    S         conditional_complement_upper_32_17  1
    S         conditional_complement_lower_32_18  1
    S         conditional_complement_upper_32_18  1
    S         conditional_complement_lower_32_19  1
    S         conditional_complement_upper_32_19  1
    S         conditional_complement_lower_33_0  1
    S         conditional_complement_upper_33_0  1
    S         conditional_complement_lower_33_1  1
    S         conditional_complement_upper_33_1  1
    S         conditional_complement_lower_33_2  1
    S         conditional_complement_upper_33_2  1
    S         conditional_complement_lower_33_3  1
    S         conditional_complement_upper_33_3  1
    S         conditional_complement_lower_33_4  1
    S         conditional_complement_upper_33_4  1
    S         conditional_complement_lower_33_5  1
    S         conditional_complement_upper_33_5  1
    S         conditional_complement_lower_33_6  1
    S         conditional_complement_upper_33_6  1
    S         conditional_complement_lower_33_7  1
    S         conditional_complement_upper_33_7  1
    S         conditional_complement_lower_33_8  1
    S         conditional_complement_upper_33_8  1
    S         conditional_complement_lower_33_9  1
    S         conditional_complement_upper_33_9  1
    S         conditional_complement_lower_33_10  1
    S         conditional_complement_upper_33_10  1
    S         conditional_complement_lower_33_11  1
    S         conditional_complement_upper_33_11  1
    S         conditional_complement_lower_34_0  1
    S         conditional_complement_upper_34_0  1
    S         conditional_complement_lower_34_1  1
    S         conditional_complement_upper_34_1  1
    S         conditional_complement_lower_34_2  1
    S         conditional_complement_upper_34_2  1
    S         conditional_complement_lower_34_3  1
    S         conditional_complement_upper_34_3  1
    S         conditional_complement_lower_34_4  1
    S         conditional_complement_upper_34_4  1
    S         conditional_complement_lower_34_5  1
    S         conditional_complement_upper_34_5  1
    S         conditional_complement_lower_34_6  1
    S         conditional_complement_upper_34_6  1
    S         conditional_complement_lower_34_7  1
    S         conditional_complement_upper_34_7  1
    S         conditional_complement_lower_34_8  1
    S         conditional_complement_upper_34_8  1
    S         conditional_complement_lower_34_9  1
    S         conditional_complement_upper_34_9  1
    S         conditional_complement_lower_34_10  1
    S         conditional_complement_upper_34_10  1
    S         conditional_complement_lower_34_11  1
    S         conditional_complement_upper_34_11  1
    S         conditional_complement_lower_34_12  1
    S         conditional_complement_upper_34_12  1
    S         conditional_complement_lower_34_13  1
    S         conditional_complement_upper_34_13  1
    S         conditional_complement_lower_34_14  1
    S         conditional_complement_upper_34_14  1
    S         conditional_complement_lower_34_15  1
    S         conditional_complement_upper_34_15  1
    S         conditional_complement_lower_35_0  1
    S         conditional_complement_upper_35_0  1
    S         conditional_complement_lower_35_1  1
    S         conditional_complement_upper_35_1  1
    S         conditional_complement_lower_35_2  1
    S         conditional_complement_upper_35_2  1
    S         conditional_complement_lower_35_3  1
    S         conditional_complement_upper_35_3  1
    S         conditional_complement_lower_35_4  1
    S         conditional_complement_upper_35_4  1
    S         conditional_complement_lower_35_5  1
    S         conditional_complement_upper_35_5  1
    S         conditional_complement_lower_35_6  1
    S         conditional_complement_upper_35_6  1
    S         conditional_complement_lower_35_7  1
    S         conditional_complement_upper_35_7  1
    S         conditional_complement_lower_35_8  1
    S         conditional_complement_upper_35_8  1
    S         conditional_complement_lower_35_9  1
    S         conditional_complement_upper_35_9  1
    S         conditional_complement_lower_35_10  1
    S         conditional_complement_upper_35_10  1
    S         conditional_complement_lower_35_11  1
    S         conditional_complement_upper_35_11  1
    S         conditional_complement_lower_35_12  1
    S         conditional_complement_upper_35_12  1
    S         conditional_complement_lower_35_13  1
    S         conditional_complement_upper_35_13  1
    S         conditional_complement_lower_35_14  1
    S         conditional_complement_upper_35_14  1
    S         conditional_complement_lower_35_15  1
    S         conditional_complement_upper_35_15  1
    S         tight_DP_cost_product_ll  1.2819131399483395e-02
    S         tight_DP_cost_product_uu  0.00905387221327508
    S         tight_DP_cost_product_ul  1.2819131399483395e-02
    S         tight_DP_cost_product_lu  0.00905387221327508
    S         floor_residual  -0.00928186329742747
    S         G_residual  -0.00928186329742747
    Y[1]      inventory_1  1
    Y[1]      ratio_1   -0.25
    Y[1]      hard_lower  1
    Y[1]      hard_upper  1
    Y[2]      inventory_2  1
    Y[2]      ratio_2   -1.4285714285714285e-01
    Y[2]      hard_lower  1
    Y[2]      hard_upper  1
    Y[3]      inventory_3  1
    Y[3]      ratio_3   -1.6666666666666666e-01
    Y[3]      hard_lower  1
    Y[3]      hard_upper  1
    Y[4]      inventory_4  1
    Y[4]      ratio_4   -1.4285714285714285e-01
    Y[4]      hard_lower  1
    Y[4]      hard_upper  1
    Y[5]      inventory_5  1
    Y[5]      ratio_5   -1.4285714285714285e-01
    Y[5]      hard_lower  1
    Y[5]      hard_upper  1
    Y[6]      inventory_6  1
    Y[6]      ratio_6   -0.25
    Y[6]      hard_lower  1
    Y[6]      hard_upper  1
    Y[7]      inventory_7  1
    Y[7]      ratio_7   -1.4285714285714285e-01
    Y[7]      hard_lower  1
    Y[7]      hard_upper  1
    Y[8]      inventory_8  1
    Y[8]      ratio_8   -1.6666666666666666e-01
    Y[8]      hard_lower  1
    Y[8]      hard_upper  1
    Y[9]      inventory_9  1
    Y[9]      ratio_9   -0.2
    Y[9]      hard_lower  1
    Y[9]      hard_upper  1
    Y[10]     inventory_10  1
    Y[10]     ratio_10  -3.3333333333333331e-01
    Y[10]     hard_lower  1
    Y[10]     hard_upper  1
    Y[11]     inventory_11  1
    Y[11]     ratio_11  -0.2
    Y[11]     hard_lower  1
    Y[11]     hard_upper  1
    Y[12]     inventory_12  1
    Y[12]     ratio_12  -1.6666666666666666e-01
    Y[12]     hard_lower  1
    Y[12]     hard_upper  1
    Y[13]     inventory_13  1
    Y[13]     ratio_13  -0.25
    Y[13]     hard_lower  1
    Y[13]     hard_upper  1
    Y[14]     inventory_14  1
    Y[14]     ratio_14  -0.25
    Y[14]     hard_lower  1
    Y[14]     hard_upper  1
    Y[15]     inventory_15  1
    Y[15]     ratio_15  -0.25
    Y[15]     hard_lower  1
    Y[15]     hard_upper  1
    Y[16]     inventory_16  1
    Y[16]     ratio_16  -0.125
    Y[16]     hard_lower  1
    Y[16]     hard_upper  1
    Y[17]     inventory_17  1
    Y[17]     ratio_17  -3.3333333333333331e-01
    Y[17]     hard_lower  1
    Y[17]     hard_upper  1
    Y[18]     inventory_18  1
    Y[18]     ratio_18  -0.2
    Y[18]     hard_lower  1
    Y[18]     hard_upper  1
    Y[19]     inventory_19  1
    Y[19]     ratio_19  -0.2
    Y[19]     hard_lower  1
    Y[19]     hard_upper  1
    Y[20]     inventory_20  1
    Y[20]     ratio_20  -0.2
    Y[20]     hard_lower  1
    Y[20]     hard_upper  1
    Y[21]     inventory_21  1
    Y[21]     ratio_21  -3.3333333333333331e-01
    Y[21]     hard_lower  1
    Y[21]     hard_upper  1
    Y[22]     inventory_22  1
    Y[22]     ratio_22  -1.4285714285714285e-01
    Y[22]     hard_lower  1
    Y[22]     hard_upper  1
    Y[23]     inventory_23  1
    Y[23]     ratio_23  -1
    Y[23]     hard_lower  1
    Y[23]     hard_upper  1
    Y[24]     inventory_24  1
    Y[24]     ratio_24  -0.125
    Y[24]     hard_lower  1
    Y[24]     hard_upper  1
    Y[25]     inventory_25  1
    Y[25]     ratio_25  -0.5
    Y[25]     hard_lower  1
    Y[25]     hard_upper  1
    Y[26]     inventory_26  1
    Y[26]     ratio_26  -0.25
    Y[26]     hard_lower  1
    Y[26]     hard_upper  1
    Y[27]     inventory_27  1
    Y[27]     ratio_27  -3.3333333333333331e-01
    Y[27]     hard_lower  1
    Y[27]     hard_upper  1
    Y[28]     inventory_28  1
    Y[28]     ratio_28  -3.3333333333333331e-01
    Y[28]     hard_lower  1
    Y[28]     hard_upper  1
    Y[29]     inventory_29  1
    Y[29]     ratio_29  -0.2
    Y[29]     hard_lower  1
    Y[29]     hard_upper  1
    Y[30]     inventory_30  1
    Y[30]     ratio_30  -0.25
    Y[30]     hard_lower  1
    Y[30]     hard_upper  1
    Y[31]     inventory_31  1
    Y[31]     ratio_31  -1.6666666666666666e-01
    Y[31]     hard_lower  1
    Y[31]     hard_upper  1
    Y[32]     inventory_32  1
    Y[32]     ratio_32  -1.1111111111111110e-01
    Y[32]     hard_lower  1
    Y[32]     hard_upper  1
    Y[33]     inventory_33  1
    Y[33]     ratio_33  -0.2
    Y[33]     hard_lower  1
    Y[33]     hard_upper  1
    Y[34]     inventory_34  1
    Y[34]     ratio_34  -0.125
    Y[34]     hard_lower  1
    Y[34]     hard_upper  1
    Y[35]     inventory_35  1
    Y[35]     ratio_35  -0.125
    Y[35]     hard_lower  1
    Y[35]     hard_upper  1
    r[1]      ratio_1   1
    r[1]      denominator  -1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[1]      abs_p_1_4  -1
    r[1]      abs_m_1_4  1
    r[1]      abs_p_1_5  -1
    r[1]      abs_m_1_5  1
    r[1]      abs_p_1_6  -1
    r[1]      abs_m_1_6  1
    r[1]      abs_p_1_7  -1
    r[1]      abs_m_1_7  1
    r[1]      abs_p_1_8  -1
    r[1]      abs_m_1_8  1
    r[1]      abs_p_1_9  -1
    r[1]      abs_m_1_9  1
    r[1]      abs_p_1_10  -1
    r[1]      abs_m_1_10  1
    r[1]      abs_p_1_11  -1
    r[1]      abs_m_1_11  1
    r[1]      abs_p_1_12  -1
    r[1]      abs_m_1_12  1
    r[1]      abs_p_1_13  -1
    r[1]      abs_m_1_13  1
    r[1]      abs_p_1_14  -1
    r[1]      abs_m_1_14  1
    r[1]      abs_p_1_15  -1
    r[1]      abs_m_1_15  1
    r[1]      abs_p_1_16  -1
    r[1]      abs_m_1_16  1
    r[1]      abs_p_1_17  -1
    r[1]      abs_m_1_17  1
    r[1]      abs_p_1_18  -1
    r[1]      abs_m_1_18  1
    r[1]      abs_p_1_19  -1
    r[1]      abs_m_1_19  1
    r[1]      abs_p_1_20  -1
    r[1]      abs_m_1_20  1
    r[1]      abs_p_1_21  -1
    r[1]      abs_m_1_21  1
    r[1]      abs_p_1_22  -1
    r[1]      abs_m_1_22  1
    r[1]      abs_p_1_23  -1
    r[1]      abs_m_1_23  1
    r[1]      abs_p_1_24  -1
    r[1]      abs_m_1_24  1
    r[1]      abs_p_1_25  -1
    r[1]      abs_m_1_25  1
    r[1]      abs_p_1_26  -1
    r[1]      abs_m_1_26  1
    r[1]      abs_p_1_27  -1
    r[1]      abs_m_1_27  1
    r[1]      abs_p_1_28  -1
    r[1]      abs_m_1_28  1
    r[1]      abs_p_1_29  -1
    r[1]      abs_m_1_29  1
    r[1]      abs_p_1_30  -1
    r[1]      abs_m_1_30  1
    r[1]      abs_p_1_31  -1
    r[1]      abs_m_1_31  1
    r[1]      abs_p_1_32  -1
    r[1]      abs_m_1_32  1
    r[1]      abs_p_1_33  -1
    r[1]      abs_m_1_33  1
    r[1]      abs_p_1_34  -1
    r[1]      abs_m_1_34  1
    r[1]      abs_p_1_35  -1
    r[1]      abs_m_1_35  1
    r[2]      ratio_2   1
    r[2]      denominator  -1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[2]      abs_p_2_4  -1
    r[2]      abs_m_2_4  1
    r[2]      abs_p_2_5  -1
    r[2]      abs_m_2_5  1
    r[2]      abs_p_2_6  -1
    r[2]      abs_m_2_6  1
    r[2]      abs_p_2_7  -1
    r[2]      abs_m_2_7  1
    r[2]      abs_p_2_8  -1
    r[2]      abs_m_2_8  1
    r[2]      abs_p_2_9  -1
    r[2]      abs_m_2_9  1
    r[2]      abs_p_2_10  -1
    r[2]      abs_m_2_10  1
    r[2]      abs_p_2_11  -1
    r[2]      abs_m_2_11  1
    r[2]      abs_p_2_12  -1
    r[2]      abs_m_2_12  1
    r[2]      abs_p_2_13  -1
    r[2]      abs_m_2_13  1
    r[2]      abs_p_2_14  -1
    r[2]      abs_m_2_14  1
    r[2]      abs_p_2_15  -1
    r[2]      abs_m_2_15  1
    r[2]      abs_p_2_16  -1
    r[2]      abs_m_2_16  1
    r[2]      abs_p_2_17  -1
    r[2]      abs_m_2_17  1
    r[2]      abs_p_2_18  -1
    r[2]      abs_m_2_18  1
    r[2]      abs_p_2_19  -1
    r[2]      abs_m_2_19  1
    r[2]      abs_p_2_20  -1
    r[2]      abs_m_2_20  1
    r[2]      abs_p_2_21  -1
    r[2]      abs_m_2_21  1
    r[2]      abs_p_2_22  -1
    r[2]      abs_m_2_22  1
    r[2]      abs_p_2_23  -1
    r[2]      abs_m_2_23  1
    r[2]      abs_p_2_24  -1
    r[2]      abs_m_2_24  1
    r[2]      abs_p_2_25  -1
    r[2]      abs_m_2_25  1
    r[2]      abs_p_2_26  -1
    r[2]      abs_m_2_26  1
    r[2]      abs_p_2_27  -1
    r[2]      abs_m_2_27  1
    r[2]      abs_p_2_28  -1
    r[2]      abs_m_2_28  1
    r[2]      abs_p_2_29  -1
    r[2]      abs_m_2_29  1
    r[2]      abs_p_2_30  -1
    r[2]      abs_m_2_30  1
    r[2]      abs_p_2_31  -1
    r[2]      abs_m_2_31  1
    r[2]      abs_p_2_32  -1
    r[2]      abs_m_2_32  1
    r[2]      abs_p_2_33  -1
    r[2]      abs_m_2_33  1
    r[2]      abs_p_2_34  -1
    r[2]      abs_m_2_34  1
    r[2]      abs_p_2_35  -1
    r[2]      abs_m_2_35  1
    r[3]      ratio_3   1
    r[3]      denominator  -1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    r[3]      abs_p_3_4  -1
    r[3]      abs_m_3_4  1
    r[3]      abs_p_3_5  -1
    r[3]      abs_m_3_5  1
    r[3]      abs_p_3_6  -1
    r[3]      abs_m_3_6  1
    r[3]      abs_p_3_7  -1
    r[3]      abs_m_3_7  1
    r[3]      abs_p_3_8  -1
    r[3]      abs_m_3_8  1
    r[3]      abs_p_3_9  -1
    r[3]      abs_m_3_9  1
    r[3]      abs_p_3_10  -1
    r[3]      abs_m_3_10  1
    r[3]      abs_p_3_11  -1
    r[3]      abs_m_3_11  1
    r[3]      abs_p_3_12  -1
    r[3]      abs_m_3_12  1
    r[3]      abs_p_3_13  -1
    r[3]      abs_m_3_13  1
    r[3]      abs_p_3_14  -1
    r[3]      abs_m_3_14  1
    r[3]      abs_p_3_15  -1
    r[3]      abs_m_3_15  1
    r[3]      abs_p_3_16  -1
    r[3]      abs_m_3_16  1
    r[3]      abs_p_3_17  -1
    r[3]      abs_m_3_17  1
    r[3]      abs_p_3_18  -1
    r[3]      abs_m_3_18  1
    r[3]      abs_p_3_19  -1
    r[3]      abs_m_3_19  1
    r[3]      abs_p_3_20  -1
    r[3]      abs_m_3_20  1
    r[3]      abs_p_3_21  -1
    r[3]      abs_m_3_21  1
    r[3]      abs_p_3_22  -1
    r[3]      abs_m_3_22  1
    r[3]      abs_p_3_23  -1
    r[3]      abs_m_3_23  1
    r[3]      abs_p_3_24  -1
    r[3]      abs_m_3_24  1
    r[3]      abs_p_3_25  -1
    r[3]      abs_m_3_25  1
    r[3]      abs_p_3_26  -1
    r[3]      abs_m_3_26  1
    r[3]      abs_p_3_27  -1
    r[3]      abs_m_3_27  1
    r[3]      abs_p_3_28  -1
    r[3]      abs_m_3_28  1
    r[3]      abs_p_3_29  -1
    r[3]      abs_m_3_29  1
    r[3]      abs_p_3_30  -1
    r[3]      abs_m_3_30  1
    r[3]      abs_p_3_31  -1
    r[3]      abs_m_3_31  1
    r[3]      abs_p_3_32  -1
    r[3]      abs_m_3_32  1
    r[3]      abs_p_3_33  -1
    r[3]      abs_m_3_33  1
    r[3]      abs_p_3_34  -1
    r[3]      abs_m_3_34  1
    r[3]      abs_p_3_35  -1
    r[3]      abs_m_3_35  1
    r[4]      ratio_4   1
    r[4]      denominator  -1
    r[4]      abs_p_1_4  1
    r[4]      abs_m_1_4  -1
    r[4]      abs_p_2_4  1
    r[4]      abs_m_2_4  -1
    r[4]      abs_p_3_4  1
    r[4]      abs_m_3_4  -1
    r[4]      abs_p_4_5  -1
    r[4]      abs_m_4_5  1
    r[4]      abs_p_4_6  -1
    r[4]      abs_m_4_6  1
    r[4]      abs_p_4_7  -1
    r[4]      abs_m_4_7  1
    r[4]      abs_p_4_8  -1
    r[4]      abs_m_4_8  1
    r[4]      abs_p_4_9  -1
    r[4]      abs_m_4_9  1
    r[4]      abs_p_4_10  -1
    r[4]      abs_m_4_10  1
    r[4]      abs_p_4_11  -1
    r[4]      abs_m_4_11  1
    r[4]      abs_p_4_12  -1
    r[4]      abs_m_4_12  1
    r[4]      abs_p_4_13  -1
    r[4]      abs_m_4_13  1
    r[4]      abs_p_4_14  -1
    r[4]      abs_m_4_14  1
    r[4]      abs_p_4_15  -1
    r[4]      abs_m_4_15  1
    r[4]      abs_p_4_16  -1
    r[4]      abs_m_4_16  1
    r[4]      abs_p_4_17  -1
    r[4]      abs_m_4_17  1
    r[4]      abs_p_4_18  -1
    r[4]      abs_m_4_18  1
    r[4]      abs_p_4_19  -1
    r[4]      abs_m_4_19  1
    r[4]      abs_p_4_20  -1
    r[4]      abs_m_4_20  1
    r[4]      abs_p_4_21  -1
    r[4]      abs_m_4_21  1
    r[4]      abs_p_4_22  -1
    r[4]      abs_m_4_22  1
    r[4]      abs_p_4_23  -1
    r[4]      abs_m_4_23  1
    r[4]      abs_p_4_24  -1
    r[4]      abs_m_4_24  1
    r[4]      abs_p_4_25  -1
    r[4]      abs_m_4_25  1
    r[4]      abs_p_4_26  -1
    r[4]      abs_m_4_26  1
    r[4]      abs_p_4_27  -1
    r[4]      abs_m_4_27  1
    r[4]      abs_p_4_28  -1
    r[4]      abs_m_4_28  1
    r[4]      abs_p_4_29  -1
    r[4]      abs_m_4_29  1
    r[4]      abs_p_4_30  -1
    r[4]      abs_m_4_30  1
    r[4]      abs_p_4_31  -1
    r[4]      abs_m_4_31  1
    r[4]      abs_p_4_32  -1
    r[4]      abs_m_4_32  1
    r[4]      abs_p_4_33  -1
    r[4]      abs_m_4_33  1
    r[4]      abs_p_4_34  -1
    r[4]      abs_m_4_34  1
    r[4]      abs_p_4_35  -1
    r[4]      abs_m_4_35  1
    r[5]      ratio_5   1
    r[5]      denominator  -1
    r[5]      abs_p_1_5  1
    r[5]      abs_m_1_5  -1
    r[5]      abs_p_2_5  1
    r[5]      abs_m_2_5  -1
    r[5]      abs_p_3_5  1
    r[5]      abs_m_3_5  -1
    r[5]      abs_p_4_5  1
    r[5]      abs_m_4_5  -1
    r[5]      abs_p_5_6  -1
    r[5]      abs_m_5_6  1
    r[5]      abs_p_5_7  -1
    r[5]      abs_m_5_7  1
    r[5]      abs_p_5_8  -1
    r[5]      abs_m_5_8  1
    r[5]      abs_p_5_9  -1
    r[5]      abs_m_5_9  1
    r[5]      abs_p_5_10  -1
    r[5]      abs_m_5_10  1
    r[5]      abs_p_5_11  -1
    r[5]      abs_m_5_11  1
    r[5]      abs_p_5_12  -1
    r[5]      abs_m_5_12  1
    r[5]      abs_p_5_13  -1
    r[5]      abs_m_5_13  1
    r[5]      abs_p_5_14  -1
    r[5]      abs_m_5_14  1
    r[5]      abs_p_5_15  -1
    r[5]      abs_m_5_15  1
    r[5]      abs_p_5_16  -1
    r[5]      abs_m_5_16  1
    r[5]      abs_p_5_17  -1
    r[5]      abs_m_5_17  1
    r[5]      abs_p_5_18  -1
    r[5]      abs_m_5_18  1
    r[5]      abs_p_5_19  -1
    r[5]      abs_m_5_19  1
    r[5]      abs_p_5_20  -1
    r[5]      abs_m_5_20  1
    r[5]      abs_p_5_21  -1
    r[5]      abs_m_5_21  1
    r[5]      abs_p_5_22  -1
    r[5]      abs_m_5_22  1
    r[5]      abs_p_5_23  -1
    r[5]      abs_m_5_23  1
    r[5]      abs_p_5_24  -1
    r[5]      abs_m_5_24  1
    r[5]      abs_p_5_25  -1
    r[5]      abs_m_5_25  1
    r[5]      abs_p_5_26  -1
    r[5]      abs_m_5_26  1
    r[5]      abs_p_5_27  -1
    r[5]      abs_m_5_27  1
    r[5]      abs_p_5_28  -1
    r[5]      abs_m_5_28  1
    r[5]      abs_p_5_29  -1
    r[5]      abs_m_5_29  1
    r[5]      abs_p_5_30  -1
    r[5]      abs_m_5_30  1
    r[5]      abs_p_5_31  -1
    r[5]      abs_m_5_31  1
    r[5]      abs_p_5_32  -1
    r[5]      abs_m_5_32  1
    r[5]      abs_p_5_33  -1
    r[5]      abs_m_5_33  1
    r[5]      abs_p_5_34  -1
    r[5]      abs_m_5_34  1
    r[5]      abs_p_5_35  -1
    r[5]      abs_m_5_35  1
    r[6]      ratio_6   1
    r[6]      denominator  -1
    r[6]      abs_p_1_6  1
    r[6]      abs_m_1_6  -1
    r[6]      abs_p_2_6  1
    r[6]      abs_m_2_6  -1
    r[6]      abs_p_3_6  1
    r[6]      abs_m_3_6  -1
    r[6]      abs_p_4_6  1
    r[6]      abs_m_4_6  -1
    r[6]      abs_p_5_6  1
    r[6]      abs_m_5_6  -1
    r[6]      abs_p_6_7  -1
    r[6]      abs_m_6_7  1
    r[6]      abs_p_6_8  -1
    r[6]      abs_m_6_8  1
    r[6]      abs_p_6_9  -1
    r[6]      abs_m_6_9  1
    r[6]      abs_p_6_10  -1
    r[6]      abs_m_6_10  1
    r[6]      abs_p_6_11  -1
    r[6]      abs_m_6_11  1
    r[6]      abs_p_6_12  -1
    r[6]      abs_m_6_12  1
    r[6]      abs_p_6_13  -1
    r[6]      abs_m_6_13  1
    r[6]      abs_p_6_14  -1
    r[6]      abs_m_6_14  1
    r[6]      abs_p_6_15  -1
    r[6]      abs_m_6_15  1
    r[6]      abs_p_6_16  -1
    r[6]      abs_m_6_16  1
    r[6]      abs_p_6_17  -1
    r[6]      abs_m_6_17  1
    r[6]      abs_p_6_18  -1
    r[6]      abs_m_6_18  1
    r[6]      abs_p_6_19  -1
    r[6]      abs_m_6_19  1
    r[6]      abs_p_6_20  -1
    r[6]      abs_m_6_20  1
    r[6]      abs_p_6_21  -1
    r[6]      abs_m_6_21  1
    r[6]      abs_p_6_22  -1
    r[6]      abs_m_6_22  1
    r[6]      abs_p_6_23  -1
    r[6]      abs_m_6_23  1
    r[6]      abs_p_6_24  -1
    r[6]      abs_m_6_24  1
    r[6]      abs_p_6_25  -1
    r[6]      abs_m_6_25  1
    r[6]      abs_p_6_26  -1
    r[6]      abs_m_6_26  1
    r[6]      abs_p_6_27  -1
    r[6]      abs_m_6_27  1
    r[6]      abs_p_6_28  -1
    r[6]      abs_m_6_28  1
    r[6]      abs_p_6_29  -1
    r[6]      abs_m_6_29  1
    r[6]      abs_p_6_30  -1
    r[6]      abs_m_6_30  1
    r[6]      abs_p_6_31  -1
    r[6]      abs_m_6_31  1
    r[6]      abs_p_6_32  -1
    r[6]      abs_m_6_32  1
    r[6]      abs_p_6_33  -1
    r[6]      abs_m_6_33  1
    r[6]      abs_p_6_34  -1
    r[6]      abs_m_6_34  1
    r[6]      abs_p_6_35  -1
    r[6]      abs_m_6_35  1
    r[7]      ratio_7   1
    r[7]      denominator  -1
    r[7]      abs_p_1_7  1
    r[7]      abs_m_1_7  -1
    r[7]      abs_p_2_7  1
    r[7]      abs_m_2_7  -1
    r[7]      abs_p_3_7  1
    r[7]      abs_m_3_7  -1
    r[7]      abs_p_4_7  1
    r[7]      abs_m_4_7  -1
    r[7]      abs_p_5_7  1
    r[7]      abs_m_5_7  -1
    r[7]      abs_p_6_7  1
    r[7]      abs_m_6_7  -1
    r[7]      abs_p_7_8  -1
    r[7]      abs_m_7_8  1
    r[7]      abs_p_7_9  -1
    r[7]      abs_m_7_9  1
    r[7]      abs_p_7_10  -1
    r[7]      abs_m_7_10  1
    r[7]      abs_p_7_11  -1
    r[7]      abs_m_7_11  1
    r[7]      abs_p_7_12  -1
    r[7]      abs_m_7_12  1
    r[7]      abs_p_7_13  -1
    r[7]      abs_m_7_13  1
    r[7]      abs_p_7_14  -1
    r[7]      abs_m_7_14  1
    r[7]      abs_p_7_15  -1
    r[7]      abs_m_7_15  1
    r[7]      abs_p_7_16  -1
    r[7]      abs_m_7_16  1
    r[7]      abs_p_7_17  -1
    r[7]      abs_m_7_17  1
    r[7]      abs_p_7_18  -1
    r[7]      abs_m_7_18  1
    r[7]      abs_p_7_19  -1
    r[7]      abs_m_7_19  1
    r[7]      abs_p_7_20  -1
    r[7]      abs_m_7_20  1
    r[7]      abs_p_7_21  -1
    r[7]      abs_m_7_21  1
    r[7]      abs_p_7_22  -1
    r[7]      abs_m_7_22  1
    r[7]      abs_p_7_23  -1
    r[7]      abs_m_7_23  1
    r[7]      abs_p_7_24  -1
    r[7]      abs_m_7_24  1
    r[7]      abs_p_7_25  -1
    r[7]      abs_m_7_25  1
    r[7]      abs_p_7_26  -1
    r[7]      abs_m_7_26  1
    r[7]      abs_p_7_27  -1
    r[7]      abs_m_7_27  1
    r[7]      abs_p_7_28  -1
    r[7]      abs_m_7_28  1
    r[7]      abs_p_7_29  -1
    r[7]      abs_m_7_29  1
    r[7]      abs_p_7_30  -1
    r[7]      abs_m_7_30  1
    r[7]      abs_p_7_31  -1
    r[7]      abs_m_7_31  1
    r[7]      abs_p_7_32  -1
    r[7]      abs_m_7_32  1
    r[7]      abs_p_7_33  -1
    r[7]      abs_m_7_33  1
    r[7]      abs_p_7_34  -1
    r[7]      abs_m_7_34  1
    r[7]      abs_p_7_35  -1
    r[7]      abs_m_7_35  1
    r[8]      ratio_8   1
    r[8]      denominator  -1
    r[8]      abs_p_1_8  1
    r[8]      abs_m_1_8  -1
    r[8]      abs_p_2_8  1
    r[8]      abs_m_2_8  -1
    r[8]      abs_p_3_8  1
    r[8]      abs_m_3_8  -1
    r[8]      abs_p_4_8  1
    r[8]      abs_m_4_8  -1
    r[8]      abs_p_5_8  1
    r[8]      abs_m_5_8  -1
    r[8]      abs_p_6_8  1
    r[8]      abs_m_6_8  -1
    r[8]      abs_p_7_8  1
    r[8]      abs_m_7_8  -1
    r[8]      abs_p_8_9  -1
    r[8]      abs_m_8_9  1
    r[8]      abs_p_8_10  -1
    r[8]      abs_m_8_10  1
    r[8]      abs_p_8_11  -1
    r[8]      abs_m_8_11  1
    r[8]      abs_p_8_12  -1
    r[8]      abs_m_8_12  1
    r[8]      abs_p_8_13  -1
    r[8]      abs_m_8_13  1
    r[8]      abs_p_8_14  -1
    r[8]      abs_m_8_14  1
    r[8]      abs_p_8_15  -1
    r[8]      abs_m_8_15  1
    r[8]      abs_p_8_16  -1
    r[8]      abs_m_8_16  1
    r[8]      abs_p_8_17  -1
    r[8]      abs_m_8_17  1
    r[8]      abs_p_8_18  -1
    r[8]      abs_m_8_18  1
    r[8]      abs_p_8_19  -1
    r[8]      abs_m_8_19  1
    r[8]      abs_p_8_20  -1
    r[8]      abs_m_8_20  1
    r[8]      abs_p_8_21  -1
    r[8]      abs_m_8_21  1
    r[8]      abs_p_8_22  -1
    r[8]      abs_m_8_22  1
    r[8]      abs_p_8_23  -1
    r[8]      abs_m_8_23  1
    r[8]      abs_p_8_24  -1
    r[8]      abs_m_8_24  1
    r[8]      abs_p_8_25  -1
    r[8]      abs_m_8_25  1
    r[8]      abs_p_8_26  -1
    r[8]      abs_m_8_26  1
    r[8]      abs_p_8_27  -1
    r[8]      abs_m_8_27  1
    r[8]      abs_p_8_28  -1
    r[8]      abs_m_8_28  1
    r[8]      abs_p_8_29  -1
    r[8]      abs_m_8_29  1
    r[8]      abs_p_8_30  -1
    r[8]      abs_m_8_30  1
    r[8]      abs_p_8_31  -1
    r[8]      abs_m_8_31  1
    r[8]      abs_p_8_32  -1
    r[8]      abs_m_8_32  1
    r[8]      abs_p_8_33  -1
    r[8]      abs_m_8_33  1
    r[8]      abs_p_8_34  -1
    r[8]      abs_m_8_34  1
    r[8]      abs_p_8_35  -1
    r[8]      abs_m_8_35  1
    r[9]      ratio_9   1
    r[9]      denominator  -1
    r[9]      abs_p_1_9  1
    r[9]      abs_m_1_9  -1
    r[9]      abs_p_2_9  1
    r[9]      abs_m_2_9  -1
    r[9]      abs_p_3_9  1
    r[9]      abs_m_3_9  -1
    r[9]      abs_p_4_9  1
    r[9]      abs_m_4_9  -1
    r[9]      abs_p_5_9  1
    r[9]      abs_m_5_9  -1
    r[9]      abs_p_6_9  1
    r[9]      abs_m_6_9  -1
    r[9]      abs_p_7_9  1
    r[9]      abs_m_7_9  -1
    r[9]      abs_p_8_9  1
    r[9]      abs_m_8_9  -1
    r[9]      abs_p_9_10  -1
    r[9]      abs_m_9_10  1
    r[9]      abs_p_9_11  -1
    r[9]      abs_m_9_11  1
    r[9]      abs_p_9_12  -1
    r[9]      abs_m_9_12  1
    r[9]      abs_p_9_13  -1
    r[9]      abs_m_9_13  1
    r[9]      abs_p_9_14  -1
    r[9]      abs_m_9_14  1
    r[9]      abs_p_9_15  -1
    r[9]      abs_m_9_15  1
    r[9]      abs_p_9_16  -1
    r[9]      abs_m_9_16  1
    r[9]      abs_p_9_17  -1
    r[9]      abs_m_9_17  1
    r[9]      abs_p_9_18  -1
    r[9]      abs_m_9_18  1
    r[9]      abs_p_9_19  -1
    r[9]      abs_m_9_19  1
    r[9]      abs_p_9_20  -1
    r[9]      abs_m_9_20  1
    r[9]      abs_p_9_21  -1
    r[9]      abs_m_9_21  1
    r[9]      abs_p_9_22  -1
    r[9]      abs_m_9_22  1
    r[9]      abs_p_9_23  -1
    r[9]      abs_m_9_23  1
    r[9]      abs_p_9_24  -1
    r[9]      abs_m_9_24  1
    r[9]      abs_p_9_25  -1
    r[9]      abs_m_9_25  1
    r[9]      abs_p_9_26  -1
    r[9]      abs_m_9_26  1
    r[9]      abs_p_9_27  -1
    r[9]      abs_m_9_27  1
    r[9]      abs_p_9_28  -1
    r[9]      abs_m_9_28  1
    r[9]      abs_p_9_29  -1
    r[9]      abs_m_9_29  1
    r[9]      abs_p_9_30  -1
    r[9]      abs_m_9_30  1
    r[9]      abs_p_9_31  -1
    r[9]      abs_m_9_31  1
    r[9]      abs_p_9_32  -1
    r[9]      abs_m_9_32  1
    r[9]      abs_p_9_33  -1
    r[9]      abs_m_9_33  1
    r[9]      abs_p_9_34  -1
    r[9]      abs_m_9_34  1
    r[9]      abs_p_9_35  -1
    r[9]      abs_m_9_35  1
    r[10]     ratio_10  1
    r[10]     denominator  -1
    r[10]     abs_p_1_10  1
    r[10]     abs_m_1_10  -1
    r[10]     abs_p_2_10  1
    r[10]     abs_m_2_10  -1
    r[10]     abs_p_3_10  1
    r[10]     abs_m_3_10  -1
    r[10]     abs_p_4_10  1
    r[10]     abs_m_4_10  -1
    r[10]     abs_p_5_10  1
    r[10]     abs_m_5_10  -1
    r[10]     abs_p_6_10  1
    r[10]     abs_m_6_10  -1
    r[10]     abs_p_7_10  1
    r[10]     abs_m_7_10  -1
    r[10]     abs_p_8_10  1
    r[10]     abs_m_8_10  -1
    r[10]     abs_p_9_10  1
    r[10]     abs_m_9_10  -1
    r[10]     abs_p_10_11  -1
    r[10]     abs_m_10_11  1
    r[10]     abs_p_10_12  -1
    r[10]     abs_m_10_12  1
    r[10]     abs_p_10_13  -1
    r[10]     abs_m_10_13  1
    r[10]     abs_p_10_14  -1
    r[10]     abs_m_10_14  1
    r[10]     abs_p_10_15  -1
    r[10]     abs_m_10_15  1
    r[10]     abs_p_10_16  -1
    r[10]     abs_m_10_16  1
    r[10]     abs_p_10_17  -1
    r[10]     abs_m_10_17  1
    r[10]     abs_p_10_18  -1
    r[10]     abs_m_10_18  1
    r[10]     abs_p_10_19  -1
    r[10]     abs_m_10_19  1
    r[10]     abs_p_10_20  -1
    r[10]     abs_m_10_20  1
    r[10]     abs_p_10_21  -1
    r[10]     abs_m_10_21  1
    r[10]     abs_p_10_22  -1
    r[10]     abs_m_10_22  1
    r[10]     abs_p_10_23  -1
    r[10]     abs_m_10_23  1
    r[10]     abs_p_10_24  -1
    r[10]     abs_m_10_24  1
    r[10]     abs_p_10_25  -1
    r[10]     abs_m_10_25  1
    r[10]     abs_p_10_26  -1
    r[10]     abs_m_10_26  1
    r[10]     abs_p_10_27  -1
    r[10]     abs_m_10_27  1
    r[10]     abs_p_10_28  -1
    r[10]     abs_m_10_28  1
    r[10]     abs_p_10_29  -1
    r[10]     abs_m_10_29  1
    r[10]     abs_p_10_30  -1
    r[10]     abs_m_10_30  1
    r[10]     abs_p_10_31  -1
    r[10]     abs_m_10_31  1
    r[10]     abs_p_10_32  -1
    r[10]     abs_m_10_32  1
    r[10]     abs_p_10_33  -1
    r[10]     abs_m_10_33  1
    r[10]     abs_p_10_34  -1
    r[10]     abs_m_10_34  1
    r[10]     abs_p_10_35  -1
    r[10]     abs_m_10_35  1
    r[11]     ratio_11  1
    r[11]     denominator  -1
    r[11]     abs_p_1_11  1
    r[11]     abs_m_1_11  -1
    r[11]     abs_p_2_11  1
    r[11]     abs_m_2_11  -1
    r[11]     abs_p_3_11  1
    r[11]     abs_m_3_11  -1
    r[11]     abs_p_4_11  1
    r[11]     abs_m_4_11  -1
    r[11]     abs_p_5_11  1
    r[11]     abs_m_5_11  -1
    r[11]     abs_p_6_11  1
    r[11]     abs_m_6_11  -1
    r[11]     abs_p_7_11  1
    r[11]     abs_m_7_11  -1
    r[11]     abs_p_8_11  1
    r[11]     abs_m_8_11  -1
    r[11]     abs_p_9_11  1
    r[11]     abs_m_9_11  -1
    r[11]     abs_p_10_11  1
    r[11]     abs_m_10_11  -1
    r[11]     abs_p_11_12  -1
    r[11]     abs_m_11_12  1
    r[11]     abs_p_11_13  -1
    r[11]     abs_m_11_13  1
    r[11]     abs_p_11_14  -1
    r[11]     abs_m_11_14  1
    r[11]     abs_p_11_15  -1
    r[11]     abs_m_11_15  1
    r[11]     abs_p_11_16  -1
    r[11]     abs_m_11_16  1
    r[11]     abs_p_11_17  -1
    r[11]     abs_m_11_17  1
    r[11]     abs_p_11_18  -1
    r[11]     abs_m_11_18  1
    r[11]     abs_p_11_19  -1
    r[11]     abs_m_11_19  1
    r[11]     abs_p_11_20  -1
    r[11]     abs_m_11_20  1
    r[11]     abs_p_11_21  -1
    r[11]     abs_m_11_21  1
    r[11]     abs_p_11_22  -1
    r[11]     abs_m_11_22  1
    r[11]     abs_p_11_23  -1
    r[11]     abs_m_11_23  1
    r[11]     abs_p_11_24  -1
    r[11]     abs_m_11_24  1
    r[11]     abs_p_11_25  -1
    r[11]     abs_m_11_25  1
    r[11]     abs_p_11_26  -1
    r[11]     abs_m_11_26  1
    r[11]     abs_p_11_27  -1
    r[11]     abs_m_11_27  1
    r[11]     abs_p_11_28  -1
    r[11]     abs_m_11_28  1
    r[11]     abs_p_11_29  -1
    r[11]     abs_m_11_29  1
    r[11]     abs_p_11_30  -1
    r[11]     abs_m_11_30  1
    r[11]     abs_p_11_31  -1
    r[11]     abs_m_11_31  1
    r[11]     abs_p_11_32  -1
    r[11]     abs_m_11_32  1
    r[11]     abs_p_11_33  -1
    r[11]     abs_m_11_33  1
    r[11]     abs_p_11_34  -1
    r[11]     abs_m_11_34  1
    r[11]     abs_p_11_35  -1
    r[11]     abs_m_11_35  1
    r[12]     ratio_12  1
    r[12]     denominator  -1
    r[12]     abs_p_1_12  1
    r[12]     abs_m_1_12  -1
    r[12]     abs_p_2_12  1
    r[12]     abs_m_2_12  -1
    r[12]     abs_p_3_12  1
    r[12]     abs_m_3_12  -1
    r[12]     abs_p_4_12  1
    r[12]     abs_m_4_12  -1
    r[12]     abs_p_5_12  1
    r[12]     abs_m_5_12  -1
    r[12]     abs_p_6_12  1
    r[12]     abs_m_6_12  -1
    r[12]     abs_p_7_12  1
    r[12]     abs_m_7_12  -1
    r[12]     abs_p_8_12  1
    r[12]     abs_m_8_12  -1
    r[12]     abs_p_9_12  1
    r[12]     abs_m_9_12  -1
    r[12]     abs_p_10_12  1
    r[12]     abs_m_10_12  -1
    r[12]     abs_p_11_12  1
    r[12]     abs_m_11_12  -1
    r[12]     abs_p_12_13  -1
    r[12]     abs_m_12_13  1
    r[12]     abs_p_12_14  -1
    r[12]     abs_m_12_14  1
    r[12]     abs_p_12_15  -1
    r[12]     abs_m_12_15  1
    r[12]     abs_p_12_16  -1
    r[12]     abs_m_12_16  1
    r[12]     abs_p_12_17  -1
    r[12]     abs_m_12_17  1
    r[12]     abs_p_12_18  -1
    r[12]     abs_m_12_18  1
    r[12]     abs_p_12_19  -1
    r[12]     abs_m_12_19  1
    r[12]     abs_p_12_20  -1
    r[12]     abs_m_12_20  1
    r[12]     abs_p_12_21  -1
    r[12]     abs_m_12_21  1
    r[12]     abs_p_12_22  -1
    r[12]     abs_m_12_22  1
    r[12]     abs_p_12_23  -1
    r[12]     abs_m_12_23  1
    r[12]     abs_p_12_24  -1
    r[12]     abs_m_12_24  1
    r[12]     abs_p_12_25  -1
    r[12]     abs_m_12_25  1
    r[12]     abs_p_12_26  -1
    r[12]     abs_m_12_26  1
    r[12]     abs_p_12_27  -1
    r[12]     abs_m_12_27  1
    r[12]     abs_p_12_28  -1
    r[12]     abs_m_12_28  1
    r[12]     abs_p_12_29  -1
    r[12]     abs_m_12_29  1
    r[12]     abs_p_12_30  -1
    r[12]     abs_m_12_30  1
    r[12]     abs_p_12_31  -1
    r[12]     abs_m_12_31  1
    r[12]     abs_p_12_32  -1
    r[12]     abs_m_12_32  1
    r[12]     abs_p_12_33  -1
    r[12]     abs_m_12_33  1
    r[12]     abs_p_12_34  -1
    r[12]     abs_m_12_34  1
    r[12]     abs_p_12_35  -1
    r[12]     abs_m_12_35  1
    r[13]     ratio_13  1
    r[13]     denominator  -1
    r[13]     abs_p_1_13  1
    r[13]     abs_m_1_13  -1
    r[13]     abs_p_2_13  1
    r[13]     abs_m_2_13  -1
    r[13]     abs_p_3_13  1
    r[13]     abs_m_3_13  -1
    r[13]     abs_p_4_13  1
    r[13]     abs_m_4_13  -1
    r[13]     abs_p_5_13  1
    r[13]     abs_m_5_13  -1
    r[13]     abs_p_6_13  1
    r[13]     abs_m_6_13  -1
    r[13]     abs_p_7_13  1
    r[13]     abs_m_7_13  -1
    r[13]     abs_p_8_13  1
    r[13]     abs_m_8_13  -1
    r[13]     abs_p_9_13  1
    r[13]     abs_m_9_13  -1
    r[13]     abs_p_10_13  1
    r[13]     abs_m_10_13  -1
    r[13]     abs_p_11_13  1
    r[13]     abs_m_11_13  -1
    r[13]     abs_p_12_13  1
    r[13]     abs_m_12_13  -1
    r[13]     abs_p_13_14  -1
    r[13]     abs_m_13_14  1
    r[13]     abs_p_13_15  -1
    r[13]     abs_m_13_15  1
    r[13]     abs_p_13_16  -1
    r[13]     abs_m_13_16  1
    r[13]     abs_p_13_17  -1
    r[13]     abs_m_13_17  1
    r[13]     abs_p_13_18  -1
    r[13]     abs_m_13_18  1
    r[13]     abs_p_13_19  -1
    r[13]     abs_m_13_19  1
    r[13]     abs_p_13_20  -1
    r[13]     abs_m_13_20  1
    r[13]     abs_p_13_21  -1
    r[13]     abs_m_13_21  1
    r[13]     abs_p_13_22  -1
    r[13]     abs_m_13_22  1
    r[13]     abs_p_13_23  -1
    r[13]     abs_m_13_23  1
    r[13]     abs_p_13_24  -1
    r[13]     abs_m_13_24  1
    r[13]     abs_p_13_25  -1
    r[13]     abs_m_13_25  1
    r[13]     abs_p_13_26  -1
    r[13]     abs_m_13_26  1
    r[13]     abs_p_13_27  -1
    r[13]     abs_m_13_27  1
    r[13]     abs_p_13_28  -1
    r[13]     abs_m_13_28  1
    r[13]     abs_p_13_29  -1
    r[13]     abs_m_13_29  1
    r[13]     abs_p_13_30  -1
    r[13]     abs_m_13_30  1
    r[13]     abs_p_13_31  -1
    r[13]     abs_m_13_31  1
    r[13]     abs_p_13_32  -1
    r[13]     abs_m_13_32  1
    r[13]     abs_p_13_33  -1
    r[13]     abs_m_13_33  1
    r[13]     abs_p_13_34  -1
    r[13]     abs_m_13_34  1
    r[13]     abs_p_13_35  -1
    r[13]     abs_m_13_35  1
    r[14]     ratio_14  1
    r[14]     denominator  -1
    r[14]     abs_p_1_14  1
    r[14]     abs_m_1_14  -1
    r[14]     abs_p_2_14  1
    r[14]     abs_m_2_14  -1
    r[14]     abs_p_3_14  1
    r[14]     abs_m_3_14  -1
    r[14]     abs_p_4_14  1
    r[14]     abs_m_4_14  -1
    r[14]     abs_p_5_14  1
    r[14]     abs_m_5_14  -1
    r[14]     abs_p_6_14  1
    r[14]     abs_m_6_14  -1
    r[14]     abs_p_7_14  1
    r[14]     abs_m_7_14  -1
    r[14]     abs_p_8_14  1
    r[14]     abs_m_8_14  -1
    r[14]     abs_p_9_14  1
    r[14]     abs_m_9_14  -1
    r[14]     abs_p_10_14  1
    r[14]     abs_m_10_14  -1
    r[14]     abs_p_11_14  1
    r[14]     abs_m_11_14  -1
    r[14]     abs_p_12_14  1
    r[14]     abs_m_12_14  -1
    r[14]     abs_p_13_14  1
    r[14]     abs_m_13_14  -1
    r[14]     abs_p_14_15  -1
    r[14]     abs_m_14_15  1
    r[14]     abs_p_14_16  -1
    r[14]     abs_m_14_16  1
    r[14]     abs_p_14_17  -1
    r[14]     abs_m_14_17  1
    r[14]     abs_p_14_18  -1
    r[14]     abs_m_14_18  1
    r[14]     abs_p_14_19  -1
    r[14]     abs_m_14_19  1
    r[14]     abs_p_14_20  -1
    r[14]     abs_m_14_20  1
    r[14]     abs_p_14_21  -1
    r[14]     abs_m_14_21  1
    r[14]     abs_p_14_22  -1
    r[14]     abs_m_14_22  1
    r[14]     abs_p_14_23  -1
    r[14]     abs_m_14_23  1
    r[14]     abs_p_14_24  -1
    r[14]     abs_m_14_24  1
    r[14]     abs_p_14_25  -1
    r[14]     abs_m_14_25  1
    r[14]     abs_p_14_26  -1
    r[14]     abs_m_14_26  1
    r[14]     abs_p_14_27  -1
    r[14]     abs_m_14_27  1
    r[14]     abs_p_14_28  -1
    r[14]     abs_m_14_28  1
    r[14]     abs_p_14_29  -1
    r[14]     abs_m_14_29  1
    r[14]     abs_p_14_30  -1
    r[14]     abs_m_14_30  1
    r[14]     abs_p_14_31  -1
    r[14]     abs_m_14_31  1
    r[14]     abs_p_14_32  -1
    r[14]     abs_m_14_32  1
    r[14]     abs_p_14_33  -1
    r[14]     abs_m_14_33  1
    r[14]     abs_p_14_34  -1
    r[14]     abs_m_14_34  1
    r[14]     abs_p_14_35  -1
    r[14]     abs_m_14_35  1
    r[15]     ratio_15  1
    r[15]     denominator  -1
    r[15]     abs_p_1_15  1
    r[15]     abs_m_1_15  -1
    r[15]     abs_p_2_15  1
    r[15]     abs_m_2_15  -1
    r[15]     abs_p_3_15  1
    r[15]     abs_m_3_15  -1
    r[15]     abs_p_4_15  1
    r[15]     abs_m_4_15  -1
    r[15]     abs_p_5_15  1
    r[15]     abs_m_5_15  -1
    r[15]     abs_p_6_15  1
    r[15]     abs_m_6_15  -1
    r[15]     abs_p_7_15  1
    r[15]     abs_m_7_15  -1
    r[15]     abs_p_8_15  1
    r[15]     abs_m_8_15  -1
    r[15]     abs_p_9_15  1
    r[15]     abs_m_9_15  -1
    r[15]     abs_p_10_15  1
    r[15]     abs_m_10_15  -1
    r[15]     abs_p_11_15  1
    r[15]     abs_m_11_15  -1
    r[15]     abs_p_12_15  1
    r[15]     abs_m_12_15  -1
    r[15]     abs_p_13_15  1
    r[15]     abs_m_13_15  -1
    r[15]     abs_p_14_15  1
    r[15]     abs_m_14_15  -1
    r[15]     abs_p_15_16  -1
    r[15]     abs_m_15_16  1
    r[15]     abs_p_15_17  -1
    r[15]     abs_m_15_17  1
    r[15]     abs_p_15_18  -1
    r[15]     abs_m_15_18  1
    r[15]     abs_p_15_19  -1
    r[15]     abs_m_15_19  1
    r[15]     abs_p_15_20  -1
    r[15]     abs_m_15_20  1
    r[15]     abs_p_15_21  -1
    r[15]     abs_m_15_21  1
    r[15]     abs_p_15_22  -1
    r[15]     abs_m_15_22  1
    r[15]     abs_p_15_23  -1
    r[15]     abs_m_15_23  1
    r[15]     abs_p_15_24  -1
    r[15]     abs_m_15_24  1
    r[15]     abs_p_15_25  -1
    r[15]     abs_m_15_25  1
    r[15]     abs_p_15_26  -1
    r[15]     abs_m_15_26  1
    r[15]     abs_p_15_27  -1
    r[15]     abs_m_15_27  1
    r[15]     abs_p_15_28  -1
    r[15]     abs_m_15_28  1
    r[15]     abs_p_15_29  -1
    r[15]     abs_m_15_29  1
    r[15]     abs_p_15_30  -1
    r[15]     abs_m_15_30  1
    r[15]     abs_p_15_31  -1
    r[15]     abs_m_15_31  1
    r[15]     abs_p_15_32  -1
    r[15]     abs_m_15_32  1
    r[15]     abs_p_15_33  -1
    r[15]     abs_m_15_33  1
    r[15]     abs_p_15_34  -1
    r[15]     abs_m_15_34  1
    r[15]     abs_p_15_35  -1
    r[15]     abs_m_15_35  1
    r[16]     ratio_16  1
    r[16]     denominator  -1
    r[16]     abs_p_1_16  1
    r[16]     abs_m_1_16  -1
    r[16]     abs_p_2_16  1
    r[16]     abs_m_2_16  -1
    r[16]     abs_p_3_16  1
    r[16]     abs_m_3_16  -1
    r[16]     abs_p_4_16  1
    r[16]     abs_m_4_16  -1
    r[16]     abs_p_5_16  1
    r[16]     abs_m_5_16  -1
    r[16]     abs_p_6_16  1
    r[16]     abs_m_6_16  -1
    r[16]     abs_p_7_16  1
    r[16]     abs_m_7_16  -1
    r[16]     abs_p_8_16  1
    r[16]     abs_m_8_16  -1
    r[16]     abs_p_9_16  1
    r[16]     abs_m_9_16  -1
    r[16]     abs_p_10_16  1
    r[16]     abs_m_10_16  -1
    r[16]     abs_p_11_16  1
    r[16]     abs_m_11_16  -1
    r[16]     abs_p_12_16  1
    r[16]     abs_m_12_16  -1
    r[16]     abs_p_13_16  1
    r[16]     abs_m_13_16  -1
    r[16]     abs_p_14_16  1
    r[16]     abs_m_14_16  -1
    r[16]     abs_p_15_16  1
    r[16]     abs_m_15_16  -1
    r[16]     abs_p_16_17  -1
    r[16]     abs_m_16_17  1
    r[16]     abs_p_16_18  -1
    r[16]     abs_m_16_18  1
    r[16]     abs_p_16_19  -1
    r[16]     abs_m_16_19  1
    r[16]     abs_p_16_20  -1
    r[16]     abs_m_16_20  1
    r[16]     abs_p_16_21  -1
    r[16]     abs_m_16_21  1
    r[16]     abs_p_16_22  -1
    r[16]     abs_m_16_22  1
    r[16]     abs_p_16_23  -1
    r[16]     abs_m_16_23  1
    r[16]     abs_p_16_24  -1
    r[16]     abs_m_16_24  1
    r[16]     abs_p_16_25  -1
    r[16]     abs_m_16_25  1
    r[16]     abs_p_16_26  -1
    r[16]     abs_m_16_26  1
    r[16]     abs_p_16_27  -1
    r[16]     abs_m_16_27  1
    r[16]     abs_p_16_28  -1
    r[16]     abs_m_16_28  1
    r[16]     abs_p_16_29  -1
    r[16]     abs_m_16_29  1
    r[16]     abs_p_16_30  -1
    r[16]     abs_m_16_30  1
    r[16]     abs_p_16_31  -1
    r[16]     abs_m_16_31  1
    r[16]     abs_p_16_32  -1
    r[16]     abs_m_16_32  1
    r[16]     abs_p_16_33  -1
    r[16]     abs_m_16_33  1
    r[16]     abs_p_16_34  -1
    r[16]     abs_m_16_34  1
    r[16]     abs_p_16_35  -1
    r[16]     abs_m_16_35  1
    r[17]     ratio_17  1
    r[17]     denominator  -1
    r[17]     abs_p_1_17  1
    r[17]     abs_m_1_17  -1
    r[17]     abs_p_2_17  1
    r[17]     abs_m_2_17  -1
    r[17]     abs_p_3_17  1
    r[17]     abs_m_3_17  -1
    r[17]     abs_p_4_17  1
    r[17]     abs_m_4_17  -1
    r[17]     abs_p_5_17  1
    r[17]     abs_m_5_17  -1
    r[17]     abs_p_6_17  1
    r[17]     abs_m_6_17  -1
    r[17]     abs_p_7_17  1
    r[17]     abs_m_7_17  -1
    r[17]     abs_p_8_17  1
    r[17]     abs_m_8_17  -1
    r[17]     abs_p_9_17  1
    r[17]     abs_m_9_17  -1
    r[17]     abs_p_10_17  1
    r[17]     abs_m_10_17  -1
    r[17]     abs_p_11_17  1
    r[17]     abs_m_11_17  -1
    r[17]     abs_p_12_17  1
    r[17]     abs_m_12_17  -1
    r[17]     abs_p_13_17  1
    r[17]     abs_m_13_17  -1
    r[17]     abs_p_14_17  1
    r[17]     abs_m_14_17  -1
    r[17]     abs_p_15_17  1
    r[17]     abs_m_15_17  -1
    r[17]     abs_p_16_17  1
    r[17]     abs_m_16_17  -1
    r[17]     abs_p_17_18  -1
    r[17]     abs_m_17_18  1
    r[17]     abs_p_17_19  -1
    r[17]     abs_m_17_19  1
    r[17]     abs_p_17_20  -1
    r[17]     abs_m_17_20  1
    r[17]     abs_p_17_21  -1
    r[17]     abs_m_17_21  1
    r[17]     abs_p_17_22  -1
    r[17]     abs_m_17_22  1
    r[17]     abs_p_17_23  -1
    r[17]     abs_m_17_23  1
    r[17]     abs_p_17_24  -1
    r[17]     abs_m_17_24  1
    r[17]     abs_p_17_25  -1
    r[17]     abs_m_17_25  1
    r[17]     abs_p_17_26  -1
    r[17]     abs_m_17_26  1
    r[17]     abs_p_17_27  -1
    r[17]     abs_m_17_27  1
    r[17]     abs_p_17_28  -1
    r[17]     abs_m_17_28  1
    r[17]     abs_p_17_29  -1
    r[17]     abs_m_17_29  1
    r[17]     abs_p_17_30  -1
    r[17]     abs_m_17_30  1
    r[17]     abs_p_17_31  -1
    r[17]     abs_m_17_31  1
    r[17]     abs_p_17_32  -1
    r[17]     abs_m_17_32  1
    r[17]     abs_p_17_33  -1
    r[17]     abs_m_17_33  1
    r[17]     abs_p_17_34  -1
    r[17]     abs_m_17_34  1
    r[17]     abs_p_17_35  -1
    r[17]     abs_m_17_35  1
    r[18]     ratio_18  1
    r[18]     denominator  -1
    r[18]     abs_p_1_18  1
    r[18]     abs_m_1_18  -1
    r[18]     abs_p_2_18  1
    r[18]     abs_m_2_18  -1
    r[18]     abs_p_3_18  1
    r[18]     abs_m_3_18  -1
    r[18]     abs_p_4_18  1
    r[18]     abs_m_4_18  -1
    r[18]     abs_p_5_18  1
    r[18]     abs_m_5_18  -1
    r[18]     abs_p_6_18  1
    r[18]     abs_m_6_18  -1
    r[18]     abs_p_7_18  1
    r[18]     abs_m_7_18  -1
    r[18]     abs_p_8_18  1
    r[18]     abs_m_8_18  -1
    r[18]     abs_p_9_18  1
    r[18]     abs_m_9_18  -1
    r[18]     abs_p_10_18  1
    r[18]     abs_m_10_18  -1
    r[18]     abs_p_11_18  1
    r[18]     abs_m_11_18  -1
    r[18]     abs_p_12_18  1
    r[18]     abs_m_12_18  -1
    r[18]     abs_p_13_18  1
    r[18]     abs_m_13_18  -1
    r[18]     abs_p_14_18  1
    r[18]     abs_m_14_18  -1
    r[18]     abs_p_15_18  1
    r[18]     abs_m_15_18  -1
    r[18]     abs_p_16_18  1
    r[18]     abs_m_16_18  -1
    r[18]     abs_p_17_18  1
    r[18]     abs_m_17_18  -1
    r[18]     abs_p_18_19  -1
    r[18]     abs_m_18_19  1
    r[18]     abs_p_18_20  -1
    r[18]     abs_m_18_20  1
    r[18]     abs_p_18_21  -1
    r[18]     abs_m_18_21  1
    r[18]     abs_p_18_22  -1
    r[18]     abs_m_18_22  1
    r[18]     abs_p_18_23  -1
    r[18]     abs_m_18_23  1
    r[18]     abs_p_18_24  -1
    r[18]     abs_m_18_24  1
    r[18]     abs_p_18_25  -1
    r[18]     abs_m_18_25  1
    r[18]     abs_p_18_26  -1
    r[18]     abs_m_18_26  1
    r[18]     abs_p_18_27  -1
    r[18]     abs_m_18_27  1
    r[18]     abs_p_18_28  -1
    r[18]     abs_m_18_28  1
    r[18]     abs_p_18_29  -1
    r[18]     abs_m_18_29  1
    r[18]     abs_p_18_30  -1
    r[18]     abs_m_18_30  1
    r[18]     abs_p_18_31  -1
    r[18]     abs_m_18_31  1
    r[18]     abs_p_18_32  -1
    r[18]     abs_m_18_32  1
    r[18]     abs_p_18_33  -1
    r[18]     abs_m_18_33  1
    r[18]     abs_p_18_34  -1
    r[18]     abs_m_18_34  1
    r[18]     abs_p_18_35  -1
    r[18]     abs_m_18_35  1
    r[19]     ratio_19  1
    r[19]     denominator  -1
    r[19]     abs_p_1_19  1
    r[19]     abs_m_1_19  -1
    r[19]     abs_p_2_19  1
    r[19]     abs_m_2_19  -1
    r[19]     abs_p_3_19  1
    r[19]     abs_m_3_19  -1
    r[19]     abs_p_4_19  1
    r[19]     abs_m_4_19  -1
    r[19]     abs_p_5_19  1
    r[19]     abs_m_5_19  -1
    r[19]     abs_p_6_19  1
    r[19]     abs_m_6_19  -1
    r[19]     abs_p_7_19  1
    r[19]     abs_m_7_19  -1
    r[19]     abs_p_8_19  1
    r[19]     abs_m_8_19  -1
    r[19]     abs_p_9_19  1
    r[19]     abs_m_9_19  -1
    r[19]     abs_p_10_19  1
    r[19]     abs_m_10_19  -1
    r[19]     abs_p_11_19  1
    r[19]     abs_m_11_19  -1
    r[19]     abs_p_12_19  1
    r[19]     abs_m_12_19  -1
    r[19]     abs_p_13_19  1
    r[19]     abs_m_13_19  -1
    r[19]     abs_p_14_19  1
    r[19]     abs_m_14_19  -1
    r[19]     abs_p_15_19  1
    r[19]     abs_m_15_19  -1
    r[19]     abs_p_16_19  1
    r[19]     abs_m_16_19  -1
    r[19]     abs_p_17_19  1
    r[19]     abs_m_17_19  -1
    r[19]     abs_p_18_19  1
    r[19]     abs_m_18_19  -1
    r[19]     abs_p_19_20  -1
    r[19]     abs_m_19_20  1
    r[19]     abs_p_19_21  -1
    r[19]     abs_m_19_21  1
    r[19]     abs_p_19_22  -1
    r[19]     abs_m_19_22  1
    r[19]     abs_p_19_23  -1
    r[19]     abs_m_19_23  1
    r[19]     abs_p_19_24  -1
    r[19]     abs_m_19_24  1
    r[19]     abs_p_19_25  -1
    r[19]     abs_m_19_25  1
    r[19]     abs_p_19_26  -1
    r[19]     abs_m_19_26  1
    r[19]     abs_p_19_27  -1
    r[19]     abs_m_19_27  1
    r[19]     abs_p_19_28  -1
    r[19]     abs_m_19_28  1
    r[19]     abs_p_19_29  -1
    r[19]     abs_m_19_29  1
    r[19]     abs_p_19_30  -1
    r[19]     abs_m_19_30  1
    r[19]     abs_p_19_31  -1
    r[19]     abs_m_19_31  1
    r[19]     abs_p_19_32  -1
    r[19]     abs_m_19_32  1
    r[19]     abs_p_19_33  -1
    r[19]     abs_m_19_33  1
    r[19]     abs_p_19_34  -1
    r[19]     abs_m_19_34  1
    r[19]     abs_p_19_35  -1
    r[19]     abs_m_19_35  1
    r[20]     ratio_20  1
    r[20]     denominator  -1
    r[20]     abs_p_1_20  1
    r[20]     abs_m_1_20  -1
    r[20]     abs_p_2_20  1
    r[20]     abs_m_2_20  -1
    r[20]     abs_p_3_20  1
    r[20]     abs_m_3_20  -1
    r[20]     abs_p_4_20  1
    r[20]     abs_m_4_20  -1
    r[20]     abs_p_5_20  1
    r[20]     abs_m_5_20  -1
    r[20]     abs_p_6_20  1
    r[20]     abs_m_6_20  -1
    r[20]     abs_p_7_20  1
    r[20]     abs_m_7_20  -1
    r[20]     abs_p_8_20  1
    r[20]     abs_m_8_20  -1
    r[20]     abs_p_9_20  1
    r[20]     abs_m_9_20  -1
    r[20]     abs_p_10_20  1
    r[20]     abs_m_10_20  -1
    r[20]     abs_p_11_20  1
    r[20]     abs_m_11_20  -1
    r[20]     abs_p_12_20  1
    r[20]     abs_m_12_20  -1
    r[20]     abs_p_13_20  1
    r[20]     abs_m_13_20  -1
    r[20]     abs_p_14_20  1
    r[20]     abs_m_14_20  -1
    r[20]     abs_p_15_20  1
    r[20]     abs_m_15_20  -1
    r[20]     abs_p_16_20  1
    r[20]     abs_m_16_20  -1
    r[20]     abs_p_17_20  1
    r[20]     abs_m_17_20  -1
    r[20]     abs_p_18_20  1
    r[20]     abs_m_18_20  -1
    r[20]     abs_p_19_20  1
    r[20]     abs_m_19_20  -1
    r[20]     abs_p_20_21  -1
    r[20]     abs_m_20_21  1
    r[20]     abs_p_20_22  -1
    r[20]     abs_m_20_22  1
    r[20]     abs_p_20_23  -1
    r[20]     abs_m_20_23  1
    r[20]     abs_p_20_24  -1
    r[20]     abs_m_20_24  1
    r[20]     abs_p_20_25  -1
    r[20]     abs_m_20_25  1
    r[20]     abs_p_20_26  -1
    r[20]     abs_m_20_26  1
    r[20]     abs_p_20_27  -1
    r[20]     abs_m_20_27  1
    r[20]     abs_p_20_28  -1
    r[20]     abs_m_20_28  1
    r[20]     abs_p_20_29  -1
    r[20]     abs_m_20_29  1
    r[20]     abs_p_20_30  -1
    r[20]     abs_m_20_30  1
    r[20]     abs_p_20_31  -1
    r[20]     abs_m_20_31  1
    r[20]     abs_p_20_32  -1
    r[20]     abs_m_20_32  1
    r[20]     abs_p_20_33  -1
    r[20]     abs_m_20_33  1
    r[20]     abs_p_20_34  -1
    r[20]     abs_m_20_34  1
    r[20]     abs_p_20_35  -1
    r[20]     abs_m_20_35  1
    r[21]     ratio_21  1
    r[21]     denominator  -1
    r[21]     abs_p_1_21  1
    r[21]     abs_m_1_21  -1
    r[21]     abs_p_2_21  1
    r[21]     abs_m_2_21  -1
    r[21]     abs_p_3_21  1
    r[21]     abs_m_3_21  -1
    r[21]     abs_p_4_21  1
    r[21]     abs_m_4_21  -1
    r[21]     abs_p_5_21  1
    r[21]     abs_m_5_21  -1
    r[21]     abs_p_6_21  1
    r[21]     abs_m_6_21  -1
    r[21]     abs_p_7_21  1
    r[21]     abs_m_7_21  -1
    r[21]     abs_p_8_21  1
    r[21]     abs_m_8_21  -1
    r[21]     abs_p_9_21  1
    r[21]     abs_m_9_21  -1
    r[21]     abs_p_10_21  1
    r[21]     abs_m_10_21  -1
    r[21]     abs_p_11_21  1
    r[21]     abs_m_11_21  -1
    r[21]     abs_p_12_21  1
    r[21]     abs_m_12_21  -1
    r[21]     abs_p_13_21  1
    r[21]     abs_m_13_21  -1
    r[21]     abs_p_14_21  1
    r[21]     abs_m_14_21  -1
    r[21]     abs_p_15_21  1
    r[21]     abs_m_15_21  -1
    r[21]     abs_p_16_21  1
    r[21]     abs_m_16_21  -1
    r[21]     abs_p_17_21  1
    r[21]     abs_m_17_21  -1
    r[21]     abs_p_18_21  1
    r[21]     abs_m_18_21  -1
    r[21]     abs_p_19_21  1
    r[21]     abs_m_19_21  -1
    r[21]     abs_p_20_21  1
    r[21]     abs_m_20_21  -1
    r[21]     abs_p_21_22  -1
    r[21]     abs_m_21_22  1
    r[21]     abs_p_21_23  -1
    r[21]     abs_m_21_23  1
    r[21]     abs_p_21_24  -1
    r[21]     abs_m_21_24  1
    r[21]     abs_p_21_25  -1
    r[21]     abs_m_21_25  1
    r[21]     abs_p_21_26  -1
    r[21]     abs_m_21_26  1
    r[21]     abs_p_21_27  -1
    r[21]     abs_m_21_27  1
    r[21]     abs_p_21_28  -1
    r[21]     abs_m_21_28  1
    r[21]     abs_p_21_29  -1
    r[21]     abs_m_21_29  1
    r[21]     abs_p_21_30  -1
    r[21]     abs_m_21_30  1
    r[21]     abs_p_21_31  -1
    r[21]     abs_m_21_31  1
    r[21]     abs_p_21_32  -1
    r[21]     abs_m_21_32  1
    r[21]     abs_p_21_33  -1
    r[21]     abs_m_21_33  1
    r[21]     abs_p_21_34  -1
    r[21]     abs_m_21_34  1
    r[21]     abs_p_21_35  -1
    r[21]     abs_m_21_35  1
    r[22]     ratio_22  1
    r[22]     denominator  -1
    r[22]     abs_p_1_22  1
    r[22]     abs_m_1_22  -1
    r[22]     abs_p_2_22  1
    r[22]     abs_m_2_22  -1
    r[22]     abs_p_3_22  1
    r[22]     abs_m_3_22  -1
    r[22]     abs_p_4_22  1
    r[22]     abs_m_4_22  -1
    r[22]     abs_p_5_22  1
    r[22]     abs_m_5_22  -1
    r[22]     abs_p_6_22  1
    r[22]     abs_m_6_22  -1
    r[22]     abs_p_7_22  1
    r[22]     abs_m_7_22  -1
    r[22]     abs_p_8_22  1
    r[22]     abs_m_8_22  -1
    r[22]     abs_p_9_22  1
    r[22]     abs_m_9_22  -1
    r[22]     abs_p_10_22  1
    r[22]     abs_m_10_22  -1
    r[22]     abs_p_11_22  1
    r[22]     abs_m_11_22  -1
    r[22]     abs_p_12_22  1
    r[22]     abs_m_12_22  -1
    r[22]     abs_p_13_22  1
    r[22]     abs_m_13_22  -1
    r[22]     abs_p_14_22  1
    r[22]     abs_m_14_22  -1
    r[22]     abs_p_15_22  1
    r[22]     abs_m_15_22  -1
    r[22]     abs_p_16_22  1
    r[22]     abs_m_16_22  -1
    r[22]     abs_p_17_22  1
    r[22]     abs_m_17_22  -1
    r[22]     abs_p_18_22  1
    r[22]     abs_m_18_22  -1
    r[22]     abs_p_19_22  1
    r[22]     abs_m_19_22  -1
    r[22]     abs_p_20_22  1
    r[22]     abs_m_20_22  -1
    r[22]     abs_p_21_22  1
    r[22]     abs_m_21_22  -1
    r[22]     abs_p_22_23  -1
    r[22]     abs_m_22_23  1
    r[22]     abs_p_22_24  -1
    r[22]     abs_m_22_24  1
    r[22]     abs_p_22_25  -1
    r[22]     abs_m_22_25  1
    r[22]     abs_p_22_26  -1
    r[22]     abs_m_22_26  1
    r[22]     abs_p_22_27  -1
    r[22]     abs_m_22_27  1
    r[22]     abs_p_22_28  -1
    r[22]     abs_m_22_28  1
    r[22]     abs_p_22_29  -1
    r[22]     abs_m_22_29  1
    r[22]     abs_p_22_30  -1
    r[22]     abs_m_22_30  1
    r[22]     abs_p_22_31  -1
    r[22]     abs_m_22_31  1
    r[22]     abs_p_22_32  -1
    r[22]     abs_m_22_32  1
    r[22]     abs_p_22_33  -1
    r[22]     abs_m_22_33  1
    r[22]     abs_p_22_34  -1
    r[22]     abs_m_22_34  1
    r[22]     abs_p_22_35  -1
    r[22]     abs_m_22_35  1
    r[23]     ratio_23  1
    r[23]     denominator  -1
    r[23]     abs_p_1_23  1
    r[23]     abs_m_1_23  -1
    r[23]     abs_p_2_23  1
    r[23]     abs_m_2_23  -1
    r[23]     abs_p_3_23  1
    r[23]     abs_m_3_23  -1
    r[23]     abs_p_4_23  1
    r[23]     abs_m_4_23  -1
    r[23]     abs_p_5_23  1
    r[23]     abs_m_5_23  -1
    r[23]     abs_p_6_23  1
    r[23]     abs_m_6_23  -1
    r[23]     abs_p_7_23  1
    r[23]     abs_m_7_23  -1
    r[23]     abs_p_8_23  1
    r[23]     abs_m_8_23  -1
    r[23]     abs_p_9_23  1
    r[23]     abs_m_9_23  -1
    r[23]     abs_p_10_23  1
    r[23]     abs_m_10_23  -1
    r[23]     abs_p_11_23  1
    r[23]     abs_m_11_23  -1
    r[23]     abs_p_12_23  1
    r[23]     abs_m_12_23  -1
    r[23]     abs_p_13_23  1
    r[23]     abs_m_13_23  -1
    r[23]     abs_p_14_23  1
    r[23]     abs_m_14_23  -1
    r[23]     abs_p_15_23  1
    r[23]     abs_m_15_23  -1
    r[23]     abs_p_16_23  1
    r[23]     abs_m_16_23  -1
    r[23]     abs_p_17_23  1
    r[23]     abs_m_17_23  -1
    r[23]     abs_p_18_23  1
    r[23]     abs_m_18_23  -1
    r[23]     abs_p_19_23  1
    r[23]     abs_m_19_23  -1
    r[23]     abs_p_20_23  1
    r[23]     abs_m_20_23  -1
    r[23]     abs_p_21_23  1
    r[23]     abs_m_21_23  -1
    r[23]     abs_p_22_23  1
    r[23]     abs_m_22_23  -1
    r[23]     abs_p_23_24  -1
    r[23]     abs_m_23_24  1
    r[23]     abs_p_23_25  -1
    r[23]     abs_m_23_25  1
    r[23]     abs_p_23_26  -1
    r[23]     abs_m_23_26  1
    r[23]     abs_p_23_27  -1
    r[23]     abs_m_23_27  1
    r[23]     abs_p_23_28  -1
    r[23]     abs_m_23_28  1
    r[23]     abs_p_23_29  -1
    r[23]     abs_m_23_29  1
    r[23]     abs_p_23_30  -1
    r[23]     abs_m_23_30  1
    r[23]     abs_p_23_31  -1
    r[23]     abs_m_23_31  1
    r[23]     abs_p_23_32  -1
    r[23]     abs_m_23_32  1
    r[23]     abs_p_23_33  -1
    r[23]     abs_m_23_33  1
    r[23]     abs_p_23_34  -1
    r[23]     abs_m_23_34  1
    r[23]     abs_p_23_35  -1
    r[23]     abs_m_23_35  1
    r[24]     ratio_24  1
    r[24]     denominator  -1
    r[24]     abs_p_1_24  1
    r[24]     abs_m_1_24  -1
    r[24]     abs_p_2_24  1
    r[24]     abs_m_2_24  -1
    r[24]     abs_p_3_24  1
    r[24]     abs_m_3_24  -1
    r[24]     abs_p_4_24  1
    r[24]     abs_m_4_24  -1
    r[24]     abs_p_5_24  1
    r[24]     abs_m_5_24  -1
    r[24]     abs_p_6_24  1
    r[24]     abs_m_6_24  -1
    r[24]     abs_p_7_24  1
    r[24]     abs_m_7_24  -1
    r[24]     abs_p_8_24  1
    r[24]     abs_m_8_24  -1
    r[24]     abs_p_9_24  1
    r[24]     abs_m_9_24  -1
    r[24]     abs_p_10_24  1
    r[24]     abs_m_10_24  -1
    r[24]     abs_p_11_24  1
    r[24]     abs_m_11_24  -1
    r[24]     abs_p_12_24  1
    r[24]     abs_m_12_24  -1
    r[24]     abs_p_13_24  1
    r[24]     abs_m_13_24  -1
    r[24]     abs_p_14_24  1
    r[24]     abs_m_14_24  -1
    r[24]     abs_p_15_24  1
    r[24]     abs_m_15_24  -1
    r[24]     abs_p_16_24  1
    r[24]     abs_m_16_24  -1
    r[24]     abs_p_17_24  1
    r[24]     abs_m_17_24  -1
    r[24]     abs_p_18_24  1
    r[24]     abs_m_18_24  -1
    r[24]     abs_p_19_24  1
    r[24]     abs_m_19_24  -1
    r[24]     abs_p_20_24  1
    r[24]     abs_m_20_24  -1
    r[24]     abs_p_21_24  1
    r[24]     abs_m_21_24  -1
    r[24]     abs_p_22_24  1
    r[24]     abs_m_22_24  -1
    r[24]     abs_p_23_24  1
    r[24]     abs_m_23_24  -1
    r[24]     abs_p_24_25  -1
    r[24]     abs_m_24_25  1
    r[24]     abs_p_24_26  -1
    r[24]     abs_m_24_26  1
    r[24]     abs_p_24_27  -1
    r[24]     abs_m_24_27  1
    r[24]     abs_p_24_28  -1
    r[24]     abs_m_24_28  1
    r[24]     abs_p_24_29  -1
    r[24]     abs_m_24_29  1
    r[24]     abs_p_24_30  -1
    r[24]     abs_m_24_30  1
    r[24]     abs_p_24_31  -1
    r[24]     abs_m_24_31  1
    r[24]     abs_p_24_32  -1
    r[24]     abs_m_24_32  1
    r[24]     abs_p_24_33  -1
    r[24]     abs_m_24_33  1
    r[24]     abs_p_24_34  -1
    r[24]     abs_m_24_34  1
    r[24]     abs_p_24_35  -1
    r[24]     abs_m_24_35  1
    r[25]     ratio_25  1
    r[25]     denominator  -1
    r[25]     abs_p_1_25  1
    r[25]     abs_m_1_25  -1
    r[25]     abs_p_2_25  1
    r[25]     abs_m_2_25  -1
    r[25]     abs_p_3_25  1
    r[25]     abs_m_3_25  -1
    r[25]     abs_p_4_25  1
    r[25]     abs_m_4_25  -1
    r[25]     abs_p_5_25  1
    r[25]     abs_m_5_25  -1
    r[25]     abs_p_6_25  1
    r[25]     abs_m_6_25  -1
    r[25]     abs_p_7_25  1
    r[25]     abs_m_7_25  -1
    r[25]     abs_p_8_25  1
    r[25]     abs_m_8_25  -1
    r[25]     abs_p_9_25  1
    r[25]     abs_m_9_25  -1
    r[25]     abs_p_10_25  1
    r[25]     abs_m_10_25  -1
    r[25]     abs_p_11_25  1
    r[25]     abs_m_11_25  -1
    r[25]     abs_p_12_25  1
    r[25]     abs_m_12_25  -1
    r[25]     abs_p_13_25  1
    r[25]     abs_m_13_25  -1
    r[25]     abs_p_14_25  1
    r[25]     abs_m_14_25  -1
    r[25]     abs_p_15_25  1
    r[25]     abs_m_15_25  -1
    r[25]     abs_p_16_25  1
    r[25]     abs_m_16_25  -1
    r[25]     abs_p_17_25  1
    r[25]     abs_m_17_25  -1
    r[25]     abs_p_18_25  1
    r[25]     abs_m_18_25  -1
    r[25]     abs_p_19_25  1
    r[25]     abs_m_19_25  -1
    r[25]     abs_p_20_25  1
    r[25]     abs_m_20_25  -1
    r[25]     abs_p_21_25  1
    r[25]     abs_m_21_25  -1
    r[25]     abs_p_22_25  1
    r[25]     abs_m_22_25  -1
    r[25]     abs_p_23_25  1
    r[25]     abs_m_23_25  -1
    r[25]     abs_p_24_25  1
    r[25]     abs_m_24_25  -1
    r[25]     abs_p_25_26  -1
    r[25]     abs_m_25_26  1
    r[25]     abs_p_25_27  -1
    r[25]     abs_m_25_27  1
    r[25]     abs_p_25_28  -1
    r[25]     abs_m_25_28  1
    r[25]     abs_p_25_29  -1
    r[25]     abs_m_25_29  1
    r[25]     abs_p_25_30  -1
    r[25]     abs_m_25_30  1
    r[25]     abs_p_25_31  -1
    r[25]     abs_m_25_31  1
    r[25]     abs_p_25_32  -1
    r[25]     abs_m_25_32  1
    r[25]     abs_p_25_33  -1
    r[25]     abs_m_25_33  1
    r[25]     abs_p_25_34  -1
    r[25]     abs_m_25_34  1
    r[25]     abs_p_25_35  -1
    r[25]     abs_m_25_35  1
    r[26]     ratio_26  1
    r[26]     denominator  -1
    r[26]     abs_p_1_26  1
    r[26]     abs_m_1_26  -1
    r[26]     abs_p_2_26  1
    r[26]     abs_m_2_26  -1
    r[26]     abs_p_3_26  1
    r[26]     abs_m_3_26  -1
    r[26]     abs_p_4_26  1
    r[26]     abs_m_4_26  -1
    r[26]     abs_p_5_26  1
    r[26]     abs_m_5_26  -1
    r[26]     abs_p_6_26  1
    r[26]     abs_m_6_26  -1
    r[26]     abs_p_7_26  1
    r[26]     abs_m_7_26  -1
    r[26]     abs_p_8_26  1
    r[26]     abs_m_8_26  -1
    r[26]     abs_p_9_26  1
    r[26]     abs_m_9_26  -1
    r[26]     abs_p_10_26  1
    r[26]     abs_m_10_26  -1
    r[26]     abs_p_11_26  1
    r[26]     abs_m_11_26  -1
    r[26]     abs_p_12_26  1
    r[26]     abs_m_12_26  -1
    r[26]     abs_p_13_26  1
    r[26]     abs_m_13_26  -1
    r[26]     abs_p_14_26  1
    r[26]     abs_m_14_26  -1
    r[26]     abs_p_15_26  1
    r[26]     abs_m_15_26  -1
    r[26]     abs_p_16_26  1
    r[26]     abs_m_16_26  -1
    r[26]     abs_p_17_26  1
    r[26]     abs_m_17_26  -1
    r[26]     abs_p_18_26  1
    r[26]     abs_m_18_26  -1
    r[26]     abs_p_19_26  1
    r[26]     abs_m_19_26  -1
    r[26]     abs_p_20_26  1
    r[26]     abs_m_20_26  -1
    r[26]     abs_p_21_26  1
    r[26]     abs_m_21_26  -1
    r[26]     abs_p_22_26  1
    r[26]     abs_m_22_26  -1
    r[26]     abs_p_23_26  1
    r[26]     abs_m_23_26  -1
    r[26]     abs_p_24_26  1
    r[26]     abs_m_24_26  -1
    r[26]     abs_p_25_26  1
    r[26]     abs_m_25_26  -1
    r[26]     abs_p_26_27  -1
    r[26]     abs_m_26_27  1
    r[26]     abs_p_26_28  -1
    r[26]     abs_m_26_28  1
    r[26]     abs_p_26_29  -1
    r[26]     abs_m_26_29  1
    r[26]     abs_p_26_30  -1
    r[26]     abs_m_26_30  1
    r[26]     abs_p_26_31  -1
    r[26]     abs_m_26_31  1
    r[26]     abs_p_26_32  -1
    r[26]     abs_m_26_32  1
    r[26]     abs_p_26_33  -1
    r[26]     abs_m_26_33  1
    r[26]     abs_p_26_34  -1
    r[26]     abs_m_26_34  1
    r[26]     abs_p_26_35  -1
    r[26]     abs_m_26_35  1
    r[27]     ratio_27  1
    r[27]     denominator  -1
    r[27]     abs_p_1_27  1
    r[27]     abs_m_1_27  -1
    r[27]     abs_p_2_27  1
    r[27]     abs_m_2_27  -1
    r[27]     abs_p_3_27  1
    r[27]     abs_m_3_27  -1
    r[27]     abs_p_4_27  1
    r[27]     abs_m_4_27  -1
    r[27]     abs_p_5_27  1
    r[27]     abs_m_5_27  -1
    r[27]     abs_p_6_27  1
    r[27]     abs_m_6_27  -1
    r[27]     abs_p_7_27  1
    r[27]     abs_m_7_27  -1
    r[27]     abs_p_8_27  1
    r[27]     abs_m_8_27  -1
    r[27]     abs_p_9_27  1
    r[27]     abs_m_9_27  -1
    r[27]     abs_p_10_27  1
    r[27]     abs_m_10_27  -1
    r[27]     abs_p_11_27  1
    r[27]     abs_m_11_27  -1
    r[27]     abs_p_12_27  1
    r[27]     abs_m_12_27  -1
    r[27]     abs_p_13_27  1
    r[27]     abs_m_13_27  -1
    r[27]     abs_p_14_27  1
    r[27]     abs_m_14_27  -1
    r[27]     abs_p_15_27  1
    r[27]     abs_m_15_27  -1
    r[27]     abs_p_16_27  1
    r[27]     abs_m_16_27  -1
    r[27]     abs_p_17_27  1
    r[27]     abs_m_17_27  -1
    r[27]     abs_p_18_27  1
    r[27]     abs_m_18_27  -1
    r[27]     abs_p_19_27  1
    r[27]     abs_m_19_27  -1
    r[27]     abs_p_20_27  1
    r[27]     abs_m_20_27  -1
    r[27]     abs_p_21_27  1
    r[27]     abs_m_21_27  -1
    r[27]     abs_p_22_27  1
    r[27]     abs_m_22_27  -1
    r[27]     abs_p_23_27  1
    r[27]     abs_m_23_27  -1
    r[27]     abs_p_24_27  1
    r[27]     abs_m_24_27  -1
    r[27]     abs_p_25_27  1
    r[27]     abs_m_25_27  -1
    r[27]     abs_p_26_27  1
    r[27]     abs_m_26_27  -1
    r[27]     abs_p_27_28  -1
    r[27]     abs_m_27_28  1
    r[27]     abs_p_27_29  -1
    r[27]     abs_m_27_29  1
    r[27]     abs_p_27_30  -1
    r[27]     abs_m_27_30  1
    r[27]     abs_p_27_31  -1
    r[27]     abs_m_27_31  1
    r[27]     abs_p_27_32  -1
    r[27]     abs_m_27_32  1
    r[27]     abs_p_27_33  -1
    r[27]     abs_m_27_33  1
    r[27]     abs_p_27_34  -1
    r[27]     abs_m_27_34  1
    r[27]     abs_p_27_35  -1
    r[27]     abs_m_27_35  1
    r[28]     ratio_28  1
    r[28]     denominator  -1
    r[28]     abs_p_1_28  1
    r[28]     abs_m_1_28  -1
    r[28]     abs_p_2_28  1
    r[28]     abs_m_2_28  -1
    r[28]     abs_p_3_28  1
    r[28]     abs_m_3_28  -1
    r[28]     abs_p_4_28  1
    r[28]     abs_m_4_28  -1
    r[28]     abs_p_5_28  1
    r[28]     abs_m_5_28  -1
    r[28]     abs_p_6_28  1
    r[28]     abs_m_6_28  -1
    r[28]     abs_p_7_28  1
    r[28]     abs_m_7_28  -1
    r[28]     abs_p_8_28  1
    r[28]     abs_m_8_28  -1
    r[28]     abs_p_9_28  1
    r[28]     abs_m_9_28  -1
    r[28]     abs_p_10_28  1
    r[28]     abs_m_10_28  -1
    r[28]     abs_p_11_28  1
    r[28]     abs_m_11_28  -1
    r[28]     abs_p_12_28  1
    r[28]     abs_m_12_28  -1
    r[28]     abs_p_13_28  1
    r[28]     abs_m_13_28  -1
    r[28]     abs_p_14_28  1
    r[28]     abs_m_14_28  -1
    r[28]     abs_p_15_28  1
    r[28]     abs_m_15_28  -1
    r[28]     abs_p_16_28  1
    r[28]     abs_m_16_28  -1
    r[28]     abs_p_17_28  1
    r[28]     abs_m_17_28  -1
    r[28]     abs_p_18_28  1
    r[28]     abs_m_18_28  -1
    r[28]     abs_p_19_28  1
    r[28]     abs_m_19_28  -1
    r[28]     abs_p_20_28  1
    r[28]     abs_m_20_28  -1
    r[28]     abs_p_21_28  1
    r[28]     abs_m_21_28  -1
    r[28]     abs_p_22_28  1
    r[28]     abs_m_22_28  -1
    r[28]     abs_p_23_28  1
    r[28]     abs_m_23_28  -1
    r[28]     abs_p_24_28  1
    r[28]     abs_m_24_28  -1
    r[28]     abs_p_25_28  1
    r[28]     abs_m_25_28  -1
    r[28]     abs_p_26_28  1
    r[28]     abs_m_26_28  -1
    r[28]     abs_p_27_28  1
    r[28]     abs_m_27_28  -1
    r[28]     abs_p_28_29  -1
    r[28]     abs_m_28_29  1
    r[28]     abs_p_28_30  -1
    r[28]     abs_m_28_30  1
    r[28]     abs_p_28_31  -1
    r[28]     abs_m_28_31  1
    r[28]     abs_p_28_32  -1
    r[28]     abs_m_28_32  1
    r[28]     abs_p_28_33  -1
    r[28]     abs_m_28_33  1
    r[28]     abs_p_28_34  -1
    r[28]     abs_m_28_34  1
    r[28]     abs_p_28_35  -1
    r[28]     abs_m_28_35  1
    r[29]     ratio_29  1
    r[29]     denominator  -1
    r[29]     abs_p_1_29  1
    r[29]     abs_m_1_29  -1
    r[29]     abs_p_2_29  1
    r[29]     abs_m_2_29  -1
    r[29]     abs_p_3_29  1
    r[29]     abs_m_3_29  -1
    r[29]     abs_p_4_29  1
    r[29]     abs_m_4_29  -1
    r[29]     abs_p_5_29  1
    r[29]     abs_m_5_29  -1
    r[29]     abs_p_6_29  1
    r[29]     abs_m_6_29  -1
    r[29]     abs_p_7_29  1
    r[29]     abs_m_7_29  -1
    r[29]     abs_p_8_29  1
    r[29]     abs_m_8_29  -1
    r[29]     abs_p_9_29  1
    r[29]     abs_m_9_29  -1
    r[29]     abs_p_10_29  1
    r[29]     abs_m_10_29  -1
    r[29]     abs_p_11_29  1
    r[29]     abs_m_11_29  -1
    r[29]     abs_p_12_29  1
    r[29]     abs_m_12_29  -1
    r[29]     abs_p_13_29  1
    r[29]     abs_m_13_29  -1
    r[29]     abs_p_14_29  1
    r[29]     abs_m_14_29  -1
    r[29]     abs_p_15_29  1
    r[29]     abs_m_15_29  -1
    r[29]     abs_p_16_29  1
    r[29]     abs_m_16_29  -1
    r[29]     abs_p_17_29  1
    r[29]     abs_m_17_29  -1
    r[29]     abs_p_18_29  1
    r[29]     abs_m_18_29  -1
    r[29]     abs_p_19_29  1
    r[29]     abs_m_19_29  -1
    r[29]     abs_p_20_29  1
    r[29]     abs_m_20_29  -1
    r[29]     abs_p_21_29  1
    r[29]     abs_m_21_29  -1
    r[29]     abs_p_22_29  1
    r[29]     abs_m_22_29  -1
    r[29]     abs_p_23_29  1
    r[29]     abs_m_23_29  -1
    r[29]     abs_p_24_29  1
    r[29]     abs_m_24_29  -1
    r[29]     abs_p_25_29  1
    r[29]     abs_m_25_29  -1
    r[29]     abs_p_26_29  1
    r[29]     abs_m_26_29  -1
    r[29]     abs_p_27_29  1
    r[29]     abs_m_27_29  -1
    r[29]     abs_p_28_29  1
    r[29]     abs_m_28_29  -1
    r[29]     abs_p_29_30  -1
    r[29]     abs_m_29_30  1
    r[29]     abs_p_29_31  -1
    r[29]     abs_m_29_31  1
    r[29]     abs_p_29_32  -1
    r[29]     abs_m_29_32  1
    r[29]     abs_p_29_33  -1
    r[29]     abs_m_29_33  1
    r[29]     abs_p_29_34  -1
    r[29]     abs_m_29_34  1
    r[29]     abs_p_29_35  -1
    r[29]     abs_m_29_35  1
    r[30]     ratio_30  1
    r[30]     denominator  -1
    r[30]     abs_p_1_30  1
    r[30]     abs_m_1_30  -1
    r[30]     abs_p_2_30  1
    r[30]     abs_m_2_30  -1
    r[30]     abs_p_3_30  1
    r[30]     abs_m_3_30  -1
    r[30]     abs_p_4_30  1
    r[30]     abs_m_4_30  -1
    r[30]     abs_p_5_30  1
    r[30]     abs_m_5_30  -1
    r[30]     abs_p_6_30  1
    r[30]     abs_m_6_30  -1
    r[30]     abs_p_7_30  1
    r[30]     abs_m_7_30  -1
    r[30]     abs_p_8_30  1
    r[30]     abs_m_8_30  -1
    r[30]     abs_p_9_30  1
    r[30]     abs_m_9_30  -1
    r[30]     abs_p_10_30  1
    r[30]     abs_m_10_30  -1
    r[30]     abs_p_11_30  1
    r[30]     abs_m_11_30  -1
    r[30]     abs_p_12_30  1
    r[30]     abs_m_12_30  -1
    r[30]     abs_p_13_30  1
    r[30]     abs_m_13_30  -1
    r[30]     abs_p_14_30  1
    r[30]     abs_m_14_30  -1
    r[30]     abs_p_15_30  1
    r[30]     abs_m_15_30  -1
    r[30]     abs_p_16_30  1
    r[30]     abs_m_16_30  -1
    r[30]     abs_p_17_30  1
    r[30]     abs_m_17_30  -1
    r[30]     abs_p_18_30  1
    r[30]     abs_m_18_30  -1
    r[30]     abs_p_19_30  1
    r[30]     abs_m_19_30  -1
    r[30]     abs_p_20_30  1
    r[30]     abs_m_20_30  -1
    r[30]     abs_p_21_30  1
    r[30]     abs_m_21_30  -1
    r[30]     abs_p_22_30  1
    r[30]     abs_m_22_30  -1
    r[30]     abs_p_23_30  1
    r[30]     abs_m_23_30  -1
    r[30]     abs_p_24_30  1
    r[30]     abs_m_24_30  -1
    r[30]     abs_p_25_30  1
    r[30]     abs_m_25_30  -1
    r[30]     abs_p_26_30  1
    r[30]     abs_m_26_30  -1
    r[30]     abs_p_27_30  1
    r[30]     abs_m_27_30  -1
    r[30]     abs_p_28_30  1
    r[30]     abs_m_28_30  -1
    r[30]     abs_p_29_30  1
    r[30]     abs_m_29_30  -1
    r[30]     abs_p_30_31  -1
    r[30]     abs_m_30_31  1
    r[30]     abs_p_30_32  -1
    r[30]     abs_m_30_32  1
    r[30]     abs_p_30_33  -1
    r[30]     abs_m_30_33  1
    r[30]     abs_p_30_34  -1
    r[30]     abs_m_30_34  1
    r[30]     abs_p_30_35  -1
    r[30]     abs_m_30_35  1
    r[31]     ratio_31  1
    r[31]     denominator  -1
    r[31]     abs_p_1_31  1
    r[31]     abs_m_1_31  -1
    r[31]     abs_p_2_31  1
    r[31]     abs_m_2_31  -1
    r[31]     abs_p_3_31  1
    r[31]     abs_m_3_31  -1
    r[31]     abs_p_4_31  1
    r[31]     abs_m_4_31  -1
    r[31]     abs_p_5_31  1
    r[31]     abs_m_5_31  -1
    r[31]     abs_p_6_31  1
    r[31]     abs_m_6_31  -1
    r[31]     abs_p_7_31  1
    r[31]     abs_m_7_31  -1
    r[31]     abs_p_8_31  1
    r[31]     abs_m_8_31  -1
    r[31]     abs_p_9_31  1
    r[31]     abs_m_9_31  -1
    r[31]     abs_p_10_31  1
    r[31]     abs_m_10_31  -1
    r[31]     abs_p_11_31  1
    r[31]     abs_m_11_31  -1
    r[31]     abs_p_12_31  1
    r[31]     abs_m_12_31  -1
    r[31]     abs_p_13_31  1
    r[31]     abs_m_13_31  -1
    r[31]     abs_p_14_31  1
    r[31]     abs_m_14_31  -1
    r[31]     abs_p_15_31  1
    r[31]     abs_m_15_31  -1
    r[31]     abs_p_16_31  1
    r[31]     abs_m_16_31  -1
    r[31]     abs_p_17_31  1
    r[31]     abs_m_17_31  -1
    r[31]     abs_p_18_31  1
    r[31]     abs_m_18_31  -1
    r[31]     abs_p_19_31  1
    r[31]     abs_m_19_31  -1
    r[31]     abs_p_20_31  1
    r[31]     abs_m_20_31  -1
    r[31]     abs_p_21_31  1
    r[31]     abs_m_21_31  -1
    r[31]     abs_p_22_31  1
    r[31]     abs_m_22_31  -1
    r[31]     abs_p_23_31  1
    r[31]     abs_m_23_31  -1
    r[31]     abs_p_24_31  1
    r[31]     abs_m_24_31  -1
    r[31]     abs_p_25_31  1
    r[31]     abs_m_25_31  -1
    r[31]     abs_p_26_31  1
    r[31]     abs_m_26_31  -1
    r[31]     abs_p_27_31  1
    r[31]     abs_m_27_31  -1
    r[31]     abs_p_28_31  1
    r[31]     abs_m_28_31  -1
    r[31]     abs_p_29_31  1
    r[31]     abs_m_29_31  -1
    r[31]     abs_p_30_31  1
    r[31]     abs_m_30_31  -1
    r[31]     abs_p_31_32  -1
    r[31]     abs_m_31_32  1
    r[31]     abs_p_31_33  -1
    r[31]     abs_m_31_33  1
    r[31]     abs_p_31_34  -1
    r[31]     abs_m_31_34  1
    r[31]     abs_p_31_35  -1
    r[31]     abs_m_31_35  1
    r[32]     ratio_32  1
    r[32]     denominator  -1
    r[32]     abs_p_1_32  1
    r[32]     abs_m_1_32  -1
    r[32]     abs_p_2_32  1
    r[32]     abs_m_2_32  -1
    r[32]     abs_p_3_32  1
    r[32]     abs_m_3_32  -1
    r[32]     abs_p_4_32  1
    r[32]     abs_m_4_32  -1
    r[32]     abs_p_5_32  1
    r[32]     abs_m_5_32  -1
    r[32]     abs_p_6_32  1
    r[32]     abs_m_6_32  -1
    r[32]     abs_p_7_32  1
    r[32]     abs_m_7_32  -1
    r[32]     abs_p_8_32  1
    r[32]     abs_m_8_32  -1
    r[32]     abs_p_9_32  1
    r[32]     abs_m_9_32  -1
    r[32]     abs_p_10_32  1
    r[32]     abs_m_10_32  -1
    r[32]     abs_p_11_32  1
    r[32]     abs_m_11_32  -1
    r[32]     abs_p_12_32  1
    r[32]     abs_m_12_32  -1
    r[32]     abs_p_13_32  1
    r[32]     abs_m_13_32  -1
    r[32]     abs_p_14_32  1
    r[32]     abs_m_14_32  -1
    r[32]     abs_p_15_32  1
    r[32]     abs_m_15_32  -1
    r[32]     abs_p_16_32  1
    r[32]     abs_m_16_32  -1
    r[32]     abs_p_17_32  1
    r[32]     abs_m_17_32  -1
    r[32]     abs_p_18_32  1
    r[32]     abs_m_18_32  -1
    r[32]     abs_p_19_32  1
    r[32]     abs_m_19_32  -1
    r[32]     abs_p_20_32  1
    r[32]     abs_m_20_32  -1
    r[32]     abs_p_21_32  1
    r[32]     abs_m_21_32  -1
    r[32]     abs_p_22_32  1
    r[32]     abs_m_22_32  -1
    r[32]     abs_p_23_32  1
    r[32]     abs_m_23_32  -1
    r[32]     abs_p_24_32  1
    r[32]     abs_m_24_32  -1
    r[32]     abs_p_25_32  1
    r[32]     abs_m_25_32  -1
    r[32]     abs_p_26_32  1
    r[32]     abs_m_26_32  -1
    r[32]     abs_p_27_32  1
    r[32]     abs_m_27_32  -1
    r[32]     abs_p_28_32  1
    r[32]     abs_m_28_32  -1
    r[32]     abs_p_29_32  1
    r[32]     abs_m_29_32  -1
    r[32]     abs_p_30_32  1
    r[32]     abs_m_30_32  -1
    r[32]     abs_p_31_32  1
    r[32]     abs_m_31_32  -1
    r[32]     abs_p_32_33  -1
    r[32]     abs_m_32_33  1
    r[32]     abs_p_32_34  -1
    r[32]     abs_m_32_34  1
    r[32]     abs_p_32_35  -1
    r[32]     abs_m_32_35  1
    r[33]     ratio_33  1
    r[33]     denominator  -1
    r[33]     abs_p_1_33  1
    r[33]     abs_m_1_33  -1
    r[33]     abs_p_2_33  1
    r[33]     abs_m_2_33  -1
    r[33]     abs_p_3_33  1
    r[33]     abs_m_3_33  -1
    r[33]     abs_p_4_33  1
    r[33]     abs_m_4_33  -1
    r[33]     abs_p_5_33  1
    r[33]     abs_m_5_33  -1
    r[33]     abs_p_6_33  1
    r[33]     abs_m_6_33  -1
    r[33]     abs_p_7_33  1
    r[33]     abs_m_7_33  -1
    r[33]     abs_p_8_33  1
    r[33]     abs_m_8_33  -1
    r[33]     abs_p_9_33  1
    r[33]     abs_m_9_33  -1
    r[33]     abs_p_10_33  1
    r[33]     abs_m_10_33  -1
    r[33]     abs_p_11_33  1
    r[33]     abs_m_11_33  -1
    r[33]     abs_p_12_33  1
    r[33]     abs_m_12_33  -1
    r[33]     abs_p_13_33  1
    r[33]     abs_m_13_33  -1
    r[33]     abs_p_14_33  1
    r[33]     abs_m_14_33  -1
    r[33]     abs_p_15_33  1
    r[33]     abs_m_15_33  -1
    r[33]     abs_p_16_33  1
    r[33]     abs_m_16_33  -1
    r[33]     abs_p_17_33  1
    r[33]     abs_m_17_33  -1
    r[33]     abs_p_18_33  1
    r[33]     abs_m_18_33  -1
    r[33]     abs_p_19_33  1
    r[33]     abs_m_19_33  -1
    r[33]     abs_p_20_33  1
    r[33]     abs_m_20_33  -1
    r[33]     abs_p_21_33  1
    r[33]     abs_m_21_33  -1
    r[33]     abs_p_22_33  1
    r[33]     abs_m_22_33  -1
    r[33]     abs_p_23_33  1
    r[33]     abs_m_23_33  -1
    r[33]     abs_p_24_33  1
    r[33]     abs_m_24_33  -1
    r[33]     abs_p_25_33  1
    r[33]     abs_m_25_33  -1
    r[33]     abs_p_26_33  1
    r[33]     abs_m_26_33  -1
    r[33]     abs_p_27_33  1
    r[33]     abs_m_27_33  -1
    r[33]     abs_p_28_33  1
    r[33]     abs_m_28_33  -1
    r[33]     abs_p_29_33  1
    r[33]     abs_m_29_33  -1
    r[33]     abs_p_30_33  1
    r[33]     abs_m_30_33  -1
    r[33]     abs_p_31_33  1
    r[33]     abs_m_31_33  -1
    r[33]     abs_p_32_33  1
    r[33]     abs_m_32_33  -1
    r[33]     abs_p_33_34  -1
    r[33]     abs_m_33_34  1
    r[33]     abs_p_33_35  -1
    r[33]     abs_m_33_35  1
    r[34]     ratio_34  1
    r[34]     denominator  -1
    r[34]     abs_p_1_34  1
    r[34]     abs_m_1_34  -1
    r[34]     abs_p_2_34  1
    r[34]     abs_m_2_34  -1
    r[34]     abs_p_3_34  1
    r[34]     abs_m_3_34  -1
    r[34]     abs_p_4_34  1
    r[34]     abs_m_4_34  -1
    r[34]     abs_p_5_34  1
    r[34]     abs_m_5_34  -1
    r[34]     abs_p_6_34  1
    r[34]     abs_m_6_34  -1
    r[34]     abs_p_7_34  1
    r[34]     abs_m_7_34  -1
    r[34]     abs_p_8_34  1
    r[34]     abs_m_8_34  -1
    r[34]     abs_p_9_34  1
    r[34]     abs_m_9_34  -1
    r[34]     abs_p_10_34  1
    r[34]     abs_m_10_34  -1
    r[34]     abs_p_11_34  1
    r[34]     abs_m_11_34  -1
    r[34]     abs_p_12_34  1
    r[34]     abs_m_12_34  -1
    r[34]     abs_p_13_34  1
    r[34]     abs_m_13_34  -1
    r[34]     abs_p_14_34  1
    r[34]     abs_m_14_34  -1
    r[34]     abs_p_15_34  1
    r[34]     abs_m_15_34  -1
    r[34]     abs_p_16_34  1
    r[34]     abs_m_16_34  -1
    r[34]     abs_p_17_34  1
    r[34]     abs_m_17_34  -1
    r[34]     abs_p_18_34  1
    r[34]     abs_m_18_34  -1
    r[34]     abs_p_19_34  1
    r[34]     abs_m_19_34  -1
    r[34]     abs_p_20_34  1
    r[34]     abs_m_20_34  -1
    r[34]     abs_p_21_34  1
    r[34]     abs_m_21_34  -1
    r[34]     abs_p_22_34  1
    r[34]     abs_m_22_34  -1
    r[34]     abs_p_23_34  1
    r[34]     abs_m_23_34  -1
    r[34]     abs_p_24_34  1
    r[34]     abs_m_24_34  -1
    r[34]     abs_p_25_34  1
    r[34]     abs_m_25_34  -1
    r[34]     abs_p_26_34  1
    r[34]     abs_m_26_34  -1
    r[34]     abs_p_27_34  1
    r[34]     abs_m_27_34  -1
    r[34]     abs_p_28_34  1
    r[34]     abs_m_28_34  -1
    r[34]     abs_p_29_34  1
    r[34]     abs_m_29_34  -1
    r[34]     abs_p_30_34  1
    r[34]     abs_m_30_34  -1
    r[34]     abs_p_31_34  1
    r[34]     abs_m_31_34  -1
    r[34]     abs_p_32_34  1
    r[34]     abs_m_32_34  -1
    r[34]     abs_p_33_34  1
    r[34]     abs_m_33_34  -1
    r[34]     abs_p_34_35  -1
    r[34]     abs_m_34_35  1
    r[35]     ratio_35  1
    r[35]     denominator  -1
    r[35]     abs_p_1_35  1
    r[35]     abs_m_1_35  -1
    r[35]     abs_p_2_35  1
    r[35]     abs_m_2_35  -1
    r[35]     abs_p_3_35  1
    r[35]     abs_m_3_35  -1
    r[35]     abs_p_4_35  1
    r[35]     abs_m_4_35  -1
    r[35]     abs_p_5_35  1
    r[35]     abs_m_5_35  -1
    r[35]     abs_p_6_35  1
    r[35]     abs_m_6_35  -1
    r[35]     abs_p_7_35  1
    r[35]     abs_m_7_35  -1
    r[35]     abs_p_8_35  1
    r[35]     abs_m_8_35  -1
    r[35]     abs_p_9_35  1
    r[35]     abs_m_9_35  -1
    r[35]     abs_p_10_35  1
    r[35]     abs_m_10_35  -1
    r[35]     abs_p_11_35  1
    r[35]     abs_m_11_35  -1
    r[35]     abs_p_12_35  1
    r[35]     abs_m_12_35  -1
    r[35]     abs_p_13_35  1
    r[35]     abs_m_13_35  -1
    r[35]     abs_p_14_35  1
    r[35]     abs_m_14_35  -1
    r[35]     abs_p_15_35  1
    r[35]     abs_m_15_35  -1
    r[35]     abs_p_16_35  1
    r[35]     abs_m_16_35  -1
    r[35]     abs_p_17_35  1
    r[35]     abs_m_17_35  -1
    r[35]     abs_p_18_35  1
    r[35]     abs_m_18_35  -1
    r[35]     abs_p_19_35  1
    r[35]     abs_m_19_35  -1
    r[35]     abs_p_20_35  1
    r[35]     abs_m_20_35  -1
    r[35]     abs_p_21_35  1
    r[35]     abs_m_21_35  -1
    r[35]     abs_p_22_35  1
    r[35]     abs_m_22_35  -1
    r[35]     abs_p_23_35  1
    r[35]     abs_m_23_35  -1
    r[35]     abs_p_24_35  1
    r[35]     abs_m_24_35  -1
    r[35]     abs_p_25_35  1
    r[35]     abs_m_25_35  -1
    r[35]     abs_p_26_35  1
    r[35]     abs_m_26_35  -1
    r[35]     abs_p_27_35  1
    r[35]     abs_m_27_35  -1
    r[35]     abs_p_28_35  1
    r[35]     abs_m_28_35  -1
    r[35]     abs_p_29_35  1
    r[35]     abs_m_29_35  -1
    r[35]     abs_p_30_35  1
    r[35]     abs_m_30_35  -1
    r[35]     abs_p_31_35  1
    r[35]     abs_m_31_35  -1
    r[35]     abs_p_32_35  1
    r[35]     abs_m_32_35  -1
    r[35]     abs_p_33_35  1
    r[35]     abs_m_33_35  -1
    r[35]     abs_p_34_35  1
    r[35]     abs_m_34_35  -1
    abs[1,2]  abs_p_1_2  1
    abs[1,2]  abs_m_1_2  1
    abs[1,2]  physical_G_upper_outward  1
    abs[1,2]  G_residual  -8.9285714285714283e-04
    abs[1,3]  abs_p_1_3  1
    abs[1,3]  abs_m_1_3  1
    abs[1,3]  physical_G_upper_outward  1
    abs[1,3]  G_residual  -8.9285714285714283e-04
    abs[1,4]  abs_p_1_4  1
    abs[1,4]  abs_m_1_4  1
    abs[1,4]  physical_G_upper_outward  1
    abs[1,4]  G_residual  -8.9285714285714283e-04
    abs[1,5]  abs_p_1_5  1
    abs[1,5]  abs_m_1_5  1
    abs[1,5]  physical_G_upper_outward  1
    abs[1,5]  G_residual  -8.9285714285714283e-04
    abs[1,6]  abs_p_1_6  1
    abs[1,6]  abs_m_1_6  1
    abs[1,6]  physical_G_upper_outward  1
    abs[1,6]  G_residual  -8.9285714285714283e-04
    abs[1,7]  abs_p_1_7  1
    abs[1,7]  abs_m_1_7  1
    abs[1,7]  physical_G_upper_outward  1
    abs[1,7]  G_residual  -8.9285714285714283e-04
    abs[1,8]  abs_p_1_8  1
    abs[1,8]  abs_m_1_8  1
    abs[1,8]  physical_G_upper_outward  1
    abs[1,8]  G_residual  -8.9285714285714283e-04
    abs[1,9]  abs_p_1_9  1
    abs[1,9]  abs_m_1_9  1
    abs[1,9]  physical_G_upper_outward  1
    abs[1,9]  G_residual  -8.9285714285714283e-04
    abs[1,10]  abs_p_1_10  1
    abs[1,10]  abs_m_1_10  1
    abs[1,10]  physical_G_upper_outward  1
    abs[1,10]  G_residual  -8.9285714285714283e-04
    abs[1,11]  abs_p_1_11  1
    abs[1,11]  abs_m_1_11  1
    abs[1,11]  physical_G_upper_outward  1
    abs[1,11]  G_residual  -8.9285714285714283e-04
    abs[1,12]  abs_p_1_12  1
    abs[1,12]  abs_m_1_12  1
    abs[1,12]  physical_G_upper_outward  1
    abs[1,12]  G_residual  -8.9285714285714283e-04
    abs[1,13]  abs_p_1_13  1
    abs[1,13]  abs_m_1_13  1
    abs[1,13]  physical_G_upper_outward  1
    abs[1,13]  G_residual  -8.9285714285714283e-04
    abs[1,14]  abs_p_1_14  1
    abs[1,14]  abs_m_1_14  1
    abs[1,14]  physical_G_upper_outward  1
    abs[1,14]  G_residual  -8.9285714285714283e-04
    abs[1,15]  abs_p_1_15  1
    abs[1,15]  abs_m_1_15  1
    abs[1,15]  physical_G_upper_outward  1
    abs[1,15]  G_residual  -8.9285714285714283e-04
    abs[1,16]  abs_p_1_16  1
    abs[1,16]  abs_m_1_16  1
    abs[1,16]  physical_G_upper_outward  1
    abs[1,16]  G_residual  -8.9285714285714283e-04
    abs[1,17]  abs_p_1_17  1
    abs[1,17]  abs_m_1_17  1
    abs[1,17]  physical_G_upper_outward  1
    abs[1,17]  G_residual  -8.9285714285714283e-04
    abs[1,18]  abs_p_1_18  1
    abs[1,18]  abs_m_1_18  1
    abs[1,18]  physical_G_upper_outward  1
    abs[1,18]  G_residual  -8.9285714285714283e-04
    abs[1,19]  abs_p_1_19  1
    abs[1,19]  abs_m_1_19  1
    abs[1,19]  physical_G_upper_outward  1
    abs[1,19]  G_residual  -8.9285714285714283e-04
    abs[1,20]  abs_p_1_20  1
    abs[1,20]  abs_m_1_20  1
    abs[1,20]  physical_G_upper_outward  1
    abs[1,20]  G_residual  -8.9285714285714283e-04
    abs[1,21]  abs_p_1_21  1
    abs[1,21]  abs_m_1_21  1
    abs[1,21]  physical_G_upper_outward  1
    abs[1,21]  G_residual  -8.9285714285714283e-04
    abs[1,22]  abs_p_1_22  1
    abs[1,22]  abs_m_1_22  1
    abs[1,22]  physical_G_upper_outward  1
    abs[1,22]  G_residual  -8.9285714285714283e-04
    abs[1,23]  abs_p_1_23  1
    abs[1,23]  abs_m_1_23  1
    abs[1,23]  physical_G_upper_outward  1
    abs[1,23]  G_residual  -8.9285714285714283e-04
    abs[1,24]  abs_p_1_24  1
    abs[1,24]  abs_m_1_24  1
    abs[1,24]  physical_G_upper_outward  1
    abs[1,24]  G_residual  -8.9285714285714283e-04
    abs[1,25]  abs_p_1_25  1
    abs[1,25]  abs_m_1_25  1
    abs[1,25]  physical_G_upper_outward  1
    abs[1,25]  G_residual  -8.9285714285714283e-04
    abs[1,26]  abs_p_1_26  1
    abs[1,26]  abs_m_1_26  1
    abs[1,26]  physical_G_upper_outward  1
    abs[1,26]  G_residual  -8.9285714285714283e-04
    abs[1,27]  abs_p_1_27  1
    abs[1,27]  abs_m_1_27  1
    abs[1,27]  physical_G_upper_outward  1
    abs[1,27]  G_residual  -8.9285714285714283e-04
    abs[1,28]  abs_p_1_28  1
    abs[1,28]  abs_m_1_28  1
    abs[1,28]  physical_G_upper_outward  1
    abs[1,28]  G_residual  -8.9285714285714283e-04
    abs[1,29]  abs_p_1_29  1
    abs[1,29]  abs_m_1_29  1
    abs[1,29]  physical_G_upper_outward  1
    abs[1,29]  G_residual  -8.9285714285714283e-04
    abs[1,30]  abs_p_1_30  1
    abs[1,30]  abs_m_1_30  1
    abs[1,30]  physical_G_upper_outward  1
    abs[1,30]  G_residual  -8.9285714285714283e-04
    abs[1,31]  abs_p_1_31  1
    abs[1,31]  abs_m_1_31  1
    abs[1,31]  physical_G_upper_outward  1
    abs[1,31]  G_residual  -8.9285714285714283e-04
    abs[1,32]  abs_p_1_32  1
    abs[1,32]  abs_m_1_32  1
    abs[1,32]  physical_G_upper_outward  1
    abs[1,32]  G_residual  -8.9285714285714283e-04
    abs[1,33]  abs_p_1_33  1
    abs[1,33]  abs_m_1_33  1
    abs[1,33]  physical_G_upper_outward  1
    abs[1,33]  G_residual  -8.9285714285714283e-04
    abs[1,34]  abs_p_1_34  1
    abs[1,34]  abs_m_1_34  1
    abs[1,34]  physical_G_upper_outward  1
    abs[1,34]  G_residual  -8.9285714285714283e-04
    abs[1,35]  abs_p_1_35  1
    abs[1,35]  abs_m_1_35  1
    abs[1,35]  physical_G_upper_outward  1
    abs[1,35]  G_residual  -8.9285714285714283e-04
    abs[2,3]  abs_p_2_3  1
    abs[2,3]  abs_m_2_3  1
    abs[2,3]  physical_G_upper_outward  1
    abs[2,3]  G_residual  -8.9285714285714283e-04
    abs[2,4]  abs_p_2_4  1
    abs[2,4]  abs_m_2_4  1
    abs[2,4]  physical_G_upper_outward  1
    abs[2,4]  G_residual  -8.9285714285714283e-04
    abs[2,5]  abs_p_2_5  1
    abs[2,5]  abs_m_2_5  1
    abs[2,5]  physical_G_upper_outward  1
    abs[2,5]  G_residual  -8.9285714285714283e-04
    abs[2,6]  abs_p_2_6  1
    abs[2,6]  abs_m_2_6  1
    abs[2,6]  physical_G_upper_outward  1
    abs[2,6]  G_residual  -8.9285714285714283e-04
    abs[2,7]  abs_p_2_7  1
    abs[2,7]  abs_m_2_7  1
    abs[2,7]  physical_G_upper_outward  1
    abs[2,7]  G_residual  -8.9285714285714283e-04
    abs[2,8]  abs_p_2_8  1
    abs[2,8]  abs_m_2_8  1
    abs[2,8]  physical_G_upper_outward  1
    abs[2,8]  G_residual  -8.9285714285714283e-04
    abs[2,9]  abs_p_2_9  1
    abs[2,9]  abs_m_2_9  1
    abs[2,9]  physical_G_upper_outward  1
    abs[2,9]  G_residual  -8.9285714285714283e-04
    abs[2,10]  abs_p_2_10  1
    abs[2,10]  abs_m_2_10  1
    abs[2,10]  physical_G_upper_outward  1
    abs[2,10]  G_residual  -8.9285714285714283e-04
    abs[2,11]  abs_p_2_11  1
    abs[2,11]  abs_m_2_11  1
    abs[2,11]  physical_G_upper_outward  1
    abs[2,11]  G_residual  -8.9285714285714283e-04
    abs[2,12]  abs_p_2_12  1
    abs[2,12]  abs_m_2_12  1
    abs[2,12]  physical_G_upper_outward  1
    abs[2,12]  G_residual  -8.9285714285714283e-04
    abs[2,13]  abs_p_2_13  1
    abs[2,13]  abs_m_2_13  1
    abs[2,13]  physical_G_upper_outward  1
    abs[2,13]  G_residual  -8.9285714285714283e-04
    abs[2,14]  abs_p_2_14  1
    abs[2,14]  abs_m_2_14  1
    abs[2,14]  physical_G_upper_outward  1
    abs[2,14]  G_residual  -8.9285714285714283e-04
    abs[2,15]  abs_p_2_15  1
    abs[2,15]  abs_m_2_15  1
    abs[2,15]  physical_G_upper_outward  1
    abs[2,15]  G_residual  -8.9285714285714283e-04
    abs[2,16]  abs_p_2_16  1
    abs[2,16]  abs_m_2_16  1
    abs[2,16]  physical_G_upper_outward  1
    abs[2,16]  G_residual  -8.9285714285714283e-04
    abs[2,17]  abs_p_2_17  1
    abs[2,17]  abs_m_2_17  1
    abs[2,17]  physical_G_upper_outward  1
    abs[2,17]  G_residual  -8.9285714285714283e-04
    abs[2,18]  abs_p_2_18  1
    abs[2,18]  abs_m_2_18  1
    abs[2,18]  physical_G_upper_outward  1
    abs[2,18]  G_residual  -8.9285714285714283e-04
    abs[2,19]  abs_p_2_19  1
    abs[2,19]  abs_m_2_19  1
    abs[2,19]  physical_G_upper_outward  1
    abs[2,19]  G_residual  -8.9285714285714283e-04
    abs[2,20]  abs_p_2_20  1
    abs[2,20]  abs_m_2_20  1
    abs[2,20]  physical_G_upper_outward  1
    abs[2,20]  G_residual  -8.9285714285714283e-04
    abs[2,21]  abs_p_2_21  1
    abs[2,21]  abs_m_2_21  1
    abs[2,21]  physical_G_upper_outward  1
    abs[2,21]  G_residual  -8.9285714285714283e-04
    abs[2,22]  abs_p_2_22  1
    abs[2,22]  abs_m_2_22  1
    abs[2,22]  physical_G_upper_outward  1
    abs[2,22]  G_residual  -8.9285714285714283e-04
    abs[2,23]  abs_p_2_23  1
    abs[2,23]  abs_m_2_23  1
    abs[2,23]  physical_G_upper_outward  1
    abs[2,23]  G_residual  -8.9285714285714283e-04
    abs[2,24]  abs_p_2_24  1
    abs[2,24]  abs_m_2_24  1
    abs[2,24]  physical_G_upper_outward  1
    abs[2,24]  G_residual  -8.9285714285714283e-04
    abs[2,25]  abs_p_2_25  1
    abs[2,25]  abs_m_2_25  1
    abs[2,25]  physical_G_upper_outward  1
    abs[2,25]  G_residual  -8.9285714285714283e-04
    abs[2,26]  abs_p_2_26  1
    abs[2,26]  abs_m_2_26  1
    abs[2,26]  physical_G_upper_outward  1
    abs[2,26]  G_residual  -8.9285714285714283e-04
    abs[2,27]  abs_p_2_27  1
    abs[2,27]  abs_m_2_27  1
    abs[2,27]  physical_G_upper_outward  1
    abs[2,27]  G_residual  -8.9285714285714283e-04
    abs[2,28]  abs_p_2_28  1
    abs[2,28]  abs_m_2_28  1
    abs[2,28]  physical_G_upper_outward  1
    abs[2,28]  G_residual  -8.9285714285714283e-04
    abs[2,29]  abs_p_2_29  1
    abs[2,29]  abs_m_2_29  1
    abs[2,29]  physical_G_upper_outward  1
    abs[2,29]  G_residual  -8.9285714285714283e-04
    abs[2,30]  abs_p_2_30  1
    abs[2,30]  abs_m_2_30  1
    abs[2,30]  physical_G_upper_outward  1
    abs[2,30]  G_residual  -8.9285714285714283e-04
    abs[2,31]  abs_p_2_31  1
    abs[2,31]  abs_m_2_31  1
    abs[2,31]  physical_G_upper_outward  1
    abs[2,31]  G_residual  -8.9285714285714283e-04
    abs[2,32]  abs_p_2_32  1
    abs[2,32]  abs_m_2_32  1
    abs[2,32]  physical_G_upper_outward  1
    abs[2,32]  G_residual  -8.9285714285714283e-04
    abs[2,33]  abs_p_2_33  1
    abs[2,33]  abs_m_2_33  1
    abs[2,33]  physical_G_upper_outward  1
    abs[2,33]  G_residual  -8.9285714285714283e-04
    abs[2,34]  abs_p_2_34  1
    abs[2,34]  abs_m_2_34  1
    abs[2,34]  physical_G_upper_outward  1
    abs[2,34]  G_residual  -8.9285714285714283e-04
    abs[2,35]  abs_p_2_35  1
    abs[2,35]  abs_m_2_35  1
    abs[2,35]  physical_G_upper_outward  1
    abs[2,35]  G_residual  -8.9285714285714283e-04
    abs[3,4]  abs_p_3_4  1
    abs[3,4]  abs_m_3_4  1
    abs[3,4]  physical_G_upper_outward  1
    abs[3,4]  G_residual  -8.9285714285714283e-04
    abs[3,5]  abs_p_3_5  1
    abs[3,5]  abs_m_3_5  1
    abs[3,5]  physical_G_upper_outward  1
    abs[3,5]  G_residual  -8.9285714285714283e-04
    abs[3,6]  abs_p_3_6  1
    abs[3,6]  abs_m_3_6  1
    abs[3,6]  physical_G_upper_outward  1
    abs[3,6]  G_residual  -8.9285714285714283e-04
    abs[3,7]  abs_p_3_7  1
    abs[3,7]  abs_m_3_7  1
    abs[3,7]  physical_G_upper_outward  1
    abs[3,7]  G_residual  -8.9285714285714283e-04
    abs[3,8]  abs_p_3_8  1
    abs[3,8]  abs_m_3_8  1
    abs[3,8]  physical_G_upper_outward  1
    abs[3,8]  G_residual  -8.9285714285714283e-04
    abs[3,9]  abs_p_3_9  1
    abs[3,9]  abs_m_3_9  1
    abs[3,9]  physical_G_upper_outward  1
    abs[3,9]  G_residual  -8.9285714285714283e-04
    abs[3,10]  abs_p_3_10  1
    abs[3,10]  abs_m_3_10  1
    abs[3,10]  physical_G_upper_outward  1
    abs[3,10]  G_residual  -8.9285714285714283e-04
    abs[3,11]  abs_p_3_11  1
    abs[3,11]  abs_m_3_11  1
    abs[3,11]  physical_G_upper_outward  1
    abs[3,11]  G_residual  -8.9285714285714283e-04
    abs[3,12]  abs_p_3_12  1
    abs[3,12]  abs_m_3_12  1
    abs[3,12]  physical_G_upper_outward  1
    abs[3,12]  G_residual  -8.9285714285714283e-04
    abs[3,13]  abs_p_3_13  1
    abs[3,13]  abs_m_3_13  1
    abs[3,13]  physical_G_upper_outward  1
    abs[3,13]  G_residual  -8.9285714285714283e-04
    abs[3,14]  abs_p_3_14  1
    abs[3,14]  abs_m_3_14  1
    abs[3,14]  physical_G_upper_outward  1
    abs[3,14]  G_residual  -8.9285714285714283e-04
    abs[3,15]  abs_p_3_15  1
    abs[3,15]  abs_m_3_15  1
    abs[3,15]  physical_G_upper_outward  1
    abs[3,15]  G_residual  -8.9285714285714283e-04
    abs[3,16]  abs_p_3_16  1
    abs[3,16]  abs_m_3_16  1
    abs[3,16]  physical_G_upper_outward  1
    abs[3,16]  G_residual  -8.9285714285714283e-04
    abs[3,17]  abs_p_3_17  1
    abs[3,17]  abs_m_3_17  1
    abs[3,17]  physical_G_upper_outward  1
    abs[3,17]  G_residual  -8.9285714285714283e-04
    abs[3,18]  abs_p_3_18  1
    abs[3,18]  abs_m_3_18  1
    abs[3,18]  physical_G_upper_outward  1
    abs[3,18]  G_residual  -8.9285714285714283e-04
    abs[3,19]  abs_p_3_19  1
    abs[3,19]  abs_m_3_19  1
    abs[3,19]  physical_G_upper_outward  1
    abs[3,19]  G_residual  -8.9285714285714283e-04
    abs[3,20]  abs_p_3_20  1
    abs[3,20]  abs_m_3_20  1
    abs[3,20]  physical_G_upper_outward  1
    abs[3,20]  G_residual  -8.9285714285714283e-04
    abs[3,21]  abs_p_3_21  1
    abs[3,21]  abs_m_3_21  1
    abs[3,21]  physical_G_upper_outward  1
    abs[3,21]  G_residual  -8.9285714285714283e-04
    abs[3,22]  abs_p_3_22  1
    abs[3,22]  abs_m_3_22  1
    abs[3,22]  physical_G_upper_outward  1
    abs[3,22]  G_residual  -8.9285714285714283e-04
    abs[3,23]  abs_p_3_23  1
    abs[3,23]  abs_m_3_23  1
    abs[3,23]  physical_G_upper_outward  1
    abs[3,23]  G_residual  -8.9285714285714283e-04
    abs[3,24]  abs_p_3_24  1
    abs[3,24]  abs_m_3_24  1
    abs[3,24]  physical_G_upper_outward  1
    abs[3,24]  G_residual  -8.9285714285714283e-04
    abs[3,25]  abs_p_3_25  1
    abs[3,25]  abs_m_3_25  1
    abs[3,25]  physical_G_upper_outward  1
    abs[3,25]  G_residual  -8.9285714285714283e-04
    abs[3,26]  abs_p_3_26  1
    abs[3,26]  abs_m_3_26  1
    abs[3,26]  physical_G_upper_outward  1
    abs[3,26]  G_residual  -8.9285714285714283e-04
    abs[3,27]  abs_p_3_27  1
    abs[3,27]  abs_m_3_27  1
    abs[3,27]  physical_G_upper_outward  1
    abs[3,27]  G_residual  -8.9285714285714283e-04
    abs[3,28]  abs_p_3_28  1
    abs[3,28]  abs_m_3_28  1
    abs[3,28]  physical_G_upper_outward  1
    abs[3,28]  G_residual  -8.9285714285714283e-04
    abs[3,29]  abs_p_3_29  1
    abs[3,29]  abs_m_3_29  1
    abs[3,29]  physical_G_upper_outward  1
    abs[3,29]  G_residual  -8.9285714285714283e-04
    abs[3,30]  abs_p_3_30  1
    abs[3,30]  abs_m_3_30  1
    abs[3,30]  physical_G_upper_outward  1
    abs[3,30]  G_residual  -8.9285714285714283e-04
    abs[3,31]  abs_p_3_31  1
    abs[3,31]  abs_m_3_31  1
    abs[3,31]  physical_G_upper_outward  1
    abs[3,31]  G_residual  -8.9285714285714283e-04
    abs[3,32]  abs_p_3_32  1
    abs[3,32]  abs_m_3_32  1
    abs[3,32]  physical_G_upper_outward  1
    abs[3,32]  G_residual  -8.9285714285714283e-04
    abs[3,33]  abs_p_3_33  1
    abs[3,33]  abs_m_3_33  1
    abs[3,33]  physical_G_upper_outward  1
    abs[3,33]  G_residual  -8.9285714285714283e-04
    abs[3,34]  abs_p_3_34  1
    abs[3,34]  abs_m_3_34  1
    abs[3,34]  physical_G_upper_outward  1
    abs[3,34]  G_residual  -8.9285714285714283e-04
    abs[3,35]  abs_p_3_35  1
    abs[3,35]  abs_m_3_35  1
    abs[3,35]  physical_G_upper_outward  1
    abs[3,35]  G_residual  -8.9285714285714283e-04
    abs[4,5]  abs_p_4_5  1
    abs[4,5]  abs_m_4_5  1
    abs[4,5]  physical_G_upper_outward  1
    abs[4,5]  G_residual  -8.9285714285714283e-04
    abs[4,6]  abs_p_4_6  1
    abs[4,6]  abs_m_4_6  1
    abs[4,6]  physical_G_upper_outward  1
    abs[4,6]  G_residual  -8.9285714285714283e-04
    abs[4,7]  abs_p_4_7  1
    abs[4,7]  abs_m_4_7  1
    abs[4,7]  physical_G_upper_outward  1
    abs[4,7]  G_residual  -8.9285714285714283e-04
    abs[4,8]  abs_p_4_8  1
    abs[4,8]  abs_m_4_8  1
    abs[4,8]  physical_G_upper_outward  1
    abs[4,8]  G_residual  -8.9285714285714283e-04
    abs[4,9]  abs_p_4_9  1
    abs[4,9]  abs_m_4_9  1
    abs[4,9]  physical_G_upper_outward  1
    abs[4,9]  G_residual  -8.9285714285714283e-04
    abs[4,10]  abs_p_4_10  1
    abs[4,10]  abs_m_4_10  1
    abs[4,10]  physical_G_upper_outward  1
    abs[4,10]  G_residual  -8.9285714285714283e-04
    abs[4,11]  abs_p_4_11  1
    abs[4,11]  abs_m_4_11  1
    abs[4,11]  physical_G_upper_outward  1
    abs[4,11]  G_residual  -8.9285714285714283e-04
    abs[4,12]  abs_p_4_12  1
    abs[4,12]  abs_m_4_12  1
    abs[4,12]  physical_G_upper_outward  1
    abs[4,12]  G_residual  -8.9285714285714283e-04
    abs[4,13]  abs_p_4_13  1
    abs[4,13]  abs_m_4_13  1
    abs[4,13]  physical_G_upper_outward  1
    abs[4,13]  G_residual  -8.9285714285714283e-04
    abs[4,14]  abs_p_4_14  1
    abs[4,14]  abs_m_4_14  1
    abs[4,14]  physical_G_upper_outward  1
    abs[4,14]  G_residual  -8.9285714285714283e-04
    abs[4,15]  abs_p_4_15  1
    abs[4,15]  abs_m_4_15  1
    abs[4,15]  physical_G_upper_outward  1
    abs[4,15]  G_residual  -8.9285714285714283e-04
    abs[4,16]  abs_p_4_16  1
    abs[4,16]  abs_m_4_16  1
    abs[4,16]  physical_G_upper_outward  1
    abs[4,16]  G_residual  -8.9285714285714283e-04
    abs[4,17]  abs_p_4_17  1
    abs[4,17]  abs_m_4_17  1
    abs[4,17]  physical_G_upper_outward  1
    abs[4,17]  G_residual  -8.9285714285714283e-04
    abs[4,18]  abs_p_4_18  1
    abs[4,18]  abs_m_4_18  1
    abs[4,18]  physical_G_upper_outward  1
    abs[4,18]  G_residual  -8.9285714285714283e-04
    abs[4,19]  abs_p_4_19  1
    abs[4,19]  abs_m_4_19  1
    abs[4,19]  physical_G_upper_outward  1
    abs[4,19]  G_residual  -8.9285714285714283e-04
    abs[4,20]  abs_p_4_20  1
    abs[4,20]  abs_m_4_20  1
    abs[4,20]  physical_G_upper_outward  1
    abs[4,20]  G_residual  -8.9285714285714283e-04
    abs[4,21]  abs_p_4_21  1
    abs[4,21]  abs_m_4_21  1
    abs[4,21]  physical_G_upper_outward  1
    abs[4,21]  G_residual  -8.9285714285714283e-04
    abs[4,22]  abs_p_4_22  1
    abs[4,22]  abs_m_4_22  1
    abs[4,22]  physical_G_upper_outward  1
    abs[4,22]  G_residual  -8.9285714285714283e-04
    abs[4,23]  abs_p_4_23  1
    abs[4,23]  abs_m_4_23  1
    abs[4,23]  physical_G_upper_outward  1
    abs[4,23]  G_residual  -8.9285714285714283e-04
    abs[4,24]  abs_p_4_24  1
    abs[4,24]  abs_m_4_24  1
    abs[4,24]  physical_G_upper_outward  1
    abs[4,24]  G_residual  -8.9285714285714283e-04
    abs[4,25]  abs_p_4_25  1
    abs[4,25]  abs_m_4_25  1
    abs[4,25]  physical_G_upper_outward  1
    abs[4,25]  G_residual  -8.9285714285714283e-04
    abs[4,26]  abs_p_4_26  1
    abs[4,26]  abs_m_4_26  1
    abs[4,26]  physical_G_upper_outward  1
    abs[4,26]  G_residual  -8.9285714285714283e-04
    abs[4,27]  abs_p_4_27  1
    abs[4,27]  abs_m_4_27  1
    abs[4,27]  physical_G_upper_outward  1
    abs[4,27]  G_residual  -8.9285714285714283e-04
    abs[4,28]  abs_p_4_28  1
    abs[4,28]  abs_m_4_28  1
    abs[4,28]  physical_G_upper_outward  1
    abs[4,28]  G_residual  -8.9285714285714283e-04
    abs[4,29]  abs_p_4_29  1
    abs[4,29]  abs_m_4_29  1
    abs[4,29]  physical_G_upper_outward  1
    abs[4,29]  G_residual  -8.9285714285714283e-04
    abs[4,30]  abs_p_4_30  1
    abs[4,30]  abs_m_4_30  1
    abs[4,30]  physical_G_upper_outward  1
    abs[4,30]  G_residual  -8.9285714285714283e-04
    abs[4,31]  abs_p_4_31  1
    abs[4,31]  abs_m_4_31  1
    abs[4,31]  physical_G_upper_outward  1
    abs[4,31]  G_residual  -8.9285714285714283e-04
    abs[4,32]  abs_p_4_32  1
    abs[4,32]  abs_m_4_32  1
    abs[4,32]  physical_G_upper_outward  1
    abs[4,32]  G_residual  -8.9285714285714283e-04
    abs[4,33]  abs_p_4_33  1
    abs[4,33]  abs_m_4_33  1
    abs[4,33]  physical_G_upper_outward  1
    abs[4,33]  G_residual  -8.9285714285714283e-04
    abs[4,34]  abs_p_4_34  1
    abs[4,34]  abs_m_4_34  1
    abs[4,34]  physical_G_upper_outward  1
    abs[4,34]  G_residual  -8.9285714285714283e-04
    abs[4,35]  abs_p_4_35  1
    abs[4,35]  abs_m_4_35  1
    abs[4,35]  physical_G_upper_outward  1
    abs[4,35]  G_residual  -8.9285714285714283e-04
    abs[5,6]  abs_p_5_6  1
    abs[5,6]  abs_m_5_6  1
    abs[5,6]  physical_G_upper_outward  1
    abs[5,6]  G_residual  -8.9285714285714283e-04
    abs[5,7]  abs_p_5_7  1
    abs[5,7]  abs_m_5_7  1
    abs[5,7]  physical_G_upper_outward  1
    abs[5,7]  G_residual  -8.9285714285714283e-04
    abs[5,8]  abs_p_5_8  1
    abs[5,8]  abs_m_5_8  1
    abs[5,8]  physical_G_upper_outward  1
    abs[5,8]  G_residual  -8.9285714285714283e-04
    abs[5,9]  abs_p_5_9  1
    abs[5,9]  abs_m_5_9  1
    abs[5,9]  physical_G_upper_outward  1
    abs[5,9]  G_residual  -8.9285714285714283e-04
    abs[5,10]  abs_p_5_10  1
    abs[5,10]  abs_m_5_10  1
    abs[5,10]  physical_G_upper_outward  1
    abs[5,10]  G_residual  -8.9285714285714283e-04
    abs[5,11]  abs_p_5_11  1
    abs[5,11]  abs_m_5_11  1
    abs[5,11]  physical_G_upper_outward  1
    abs[5,11]  G_residual  -8.9285714285714283e-04
    abs[5,12]  abs_p_5_12  1
    abs[5,12]  abs_m_5_12  1
    abs[5,12]  physical_G_upper_outward  1
    abs[5,12]  G_residual  -8.9285714285714283e-04
    abs[5,13]  abs_p_5_13  1
    abs[5,13]  abs_m_5_13  1
    abs[5,13]  physical_G_upper_outward  1
    abs[5,13]  G_residual  -8.9285714285714283e-04
    abs[5,14]  abs_p_5_14  1
    abs[5,14]  abs_m_5_14  1
    abs[5,14]  physical_G_upper_outward  1
    abs[5,14]  G_residual  -8.9285714285714283e-04
    abs[5,15]  abs_p_5_15  1
    abs[5,15]  abs_m_5_15  1
    abs[5,15]  physical_G_upper_outward  1
    abs[5,15]  G_residual  -8.9285714285714283e-04
    abs[5,16]  abs_p_5_16  1
    abs[5,16]  abs_m_5_16  1
    abs[5,16]  physical_G_upper_outward  1
    abs[5,16]  G_residual  -8.9285714285714283e-04
    abs[5,17]  abs_p_5_17  1
    abs[5,17]  abs_m_5_17  1
    abs[5,17]  physical_G_upper_outward  1
    abs[5,17]  G_residual  -8.9285714285714283e-04
    abs[5,18]  abs_p_5_18  1
    abs[5,18]  abs_m_5_18  1
    abs[5,18]  physical_G_upper_outward  1
    abs[5,18]  G_residual  -8.9285714285714283e-04
    abs[5,19]  abs_p_5_19  1
    abs[5,19]  abs_m_5_19  1
    abs[5,19]  physical_G_upper_outward  1
    abs[5,19]  G_residual  -8.9285714285714283e-04
    abs[5,20]  abs_p_5_20  1
    abs[5,20]  abs_m_5_20  1
    abs[5,20]  physical_G_upper_outward  1
    abs[5,20]  G_residual  -8.9285714285714283e-04
    abs[5,21]  abs_p_5_21  1
    abs[5,21]  abs_m_5_21  1
    abs[5,21]  physical_G_upper_outward  1
    abs[5,21]  G_residual  -8.9285714285714283e-04
    abs[5,22]  abs_p_5_22  1
    abs[5,22]  abs_m_5_22  1
    abs[5,22]  physical_G_upper_outward  1
    abs[5,22]  G_residual  -8.9285714285714283e-04
    abs[5,23]  abs_p_5_23  1
    abs[5,23]  abs_m_5_23  1
    abs[5,23]  physical_G_upper_outward  1
    abs[5,23]  G_residual  -8.9285714285714283e-04
    abs[5,24]  abs_p_5_24  1
    abs[5,24]  abs_m_5_24  1
    abs[5,24]  physical_G_upper_outward  1
    abs[5,24]  G_residual  -8.9285714285714283e-04
    abs[5,25]  abs_p_5_25  1
    abs[5,25]  abs_m_5_25  1
    abs[5,25]  physical_G_upper_outward  1
    abs[5,25]  G_residual  -8.9285714285714283e-04
    abs[5,26]  abs_p_5_26  1
    abs[5,26]  abs_m_5_26  1
    abs[5,26]  physical_G_upper_outward  1
    abs[5,26]  G_residual  -8.9285714285714283e-04
    abs[5,27]  abs_p_5_27  1
    abs[5,27]  abs_m_5_27  1
    abs[5,27]  physical_G_upper_outward  1
    abs[5,27]  G_residual  -8.9285714285714283e-04
    abs[5,28]  abs_p_5_28  1
    abs[5,28]  abs_m_5_28  1
    abs[5,28]  physical_G_upper_outward  1
    abs[5,28]  G_residual  -8.9285714285714283e-04
    abs[5,29]  abs_p_5_29  1
    abs[5,29]  abs_m_5_29  1
    abs[5,29]  physical_G_upper_outward  1
    abs[5,29]  G_residual  -8.9285714285714283e-04
    abs[5,30]  abs_p_5_30  1
    abs[5,30]  abs_m_5_30  1
    abs[5,30]  physical_G_upper_outward  1
    abs[5,30]  G_residual  -8.9285714285714283e-04
    abs[5,31]  abs_p_5_31  1
    abs[5,31]  abs_m_5_31  1
    abs[5,31]  physical_G_upper_outward  1
    abs[5,31]  G_residual  -8.9285714285714283e-04
    abs[5,32]  abs_p_5_32  1
    abs[5,32]  abs_m_5_32  1
    abs[5,32]  physical_G_upper_outward  1
    abs[5,32]  G_residual  -8.9285714285714283e-04
    abs[5,33]  abs_p_5_33  1
    abs[5,33]  abs_m_5_33  1
    abs[5,33]  physical_G_upper_outward  1
    abs[5,33]  G_residual  -8.9285714285714283e-04
    abs[5,34]  abs_p_5_34  1
    abs[5,34]  abs_m_5_34  1
    abs[5,34]  physical_G_upper_outward  1
    abs[5,34]  G_residual  -8.9285714285714283e-04
    abs[5,35]  abs_p_5_35  1
    abs[5,35]  abs_m_5_35  1
    abs[5,35]  physical_G_upper_outward  1
    abs[5,35]  G_residual  -8.9285714285714283e-04
    abs[6,7]  abs_p_6_7  1
    abs[6,7]  abs_m_6_7  1
    abs[6,7]  physical_G_upper_outward  1
    abs[6,7]  G_residual  -8.9285714285714283e-04
    abs[6,8]  abs_p_6_8  1
    abs[6,8]  abs_m_6_8  1
    abs[6,8]  physical_G_upper_outward  1
    abs[6,8]  G_residual  -8.9285714285714283e-04
    abs[6,9]  abs_p_6_9  1
    abs[6,9]  abs_m_6_9  1
    abs[6,9]  physical_G_upper_outward  1
    abs[6,9]  G_residual  -8.9285714285714283e-04
    abs[6,10]  abs_p_6_10  1
    abs[6,10]  abs_m_6_10  1
    abs[6,10]  physical_G_upper_outward  1
    abs[6,10]  G_residual  -8.9285714285714283e-04
    abs[6,11]  abs_p_6_11  1
    abs[6,11]  abs_m_6_11  1
    abs[6,11]  physical_G_upper_outward  1
    abs[6,11]  G_residual  -8.9285714285714283e-04
    abs[6,12]  abs_p_6_12  1
    abs[6,12]  abs_m_6_12  1
    abs[6,12]  physical_G_upper_outward  1
    abs[6,12]  G_residual  -8.9285714285714283e-04
    abs[6,13]  abs_p_6_13  1
    abs[6,13]  abs_m_6_13  1
    abs[6,13]  physical_G_upper_outward  1
    abs[6,13]  G_residual  -8.9285714285714283e-04
    abs[6,14]  abs_p_6_14  1
    abs[6,14]  abs_m_6_14  1
    abs[6,14]  physical_G_upper_outward  1
    abs[6,14]  G_residual  -8.9285714285714283e-04
    abs[6,15]  abs_p_6_15  1
    abs[6,15]  abs_m_6_15  1
    abs[6,15]  physical_G_upper_outward  1
    abs[6,15]  G_residual  -8.9285714285714283e-04
    abs[6,16]  abs_p_6_16  1
    abs[6,16]  abs_m_6_16  1
    abs[6,16]  physical_G_upper_outward  1
    abs[6,16]  G_residual  -8.9285714285714283e-04
    abs[6,17]  abs_p_6_17  1
    abs[6,17]  abs_m_6_17  1
    abs[6,17]  physical_G_upper_outward  1
    abs[6,17]  G_residual  -8.9285714285714283e-04
    abs[6,18]  abs_p_6_18  1
    abs[6,18]  abs_m_6_18  1
    abs[6,18]  physical_G_upper_outward  1
    abs[6,18]  G_residual  -8.9285714285714283e-04
    abs[6,19]  abs_p_6_19  1
    abs[6,19]  abs_m_6_19  1
    abs[6,19]  physical_G_upper_outward  1
    abs[6,19]  G_residual  -8.9285714285714283e-04
    abs[6,20]  abs_p_6_20  1
    abs[6,20]  abs_m_6_20  1
    abs[6,20]  physical_G_upper_outward  1
    abs[6,20]  G_residual  -8.9285714285714283e-04
    abs[6,21]  abs_p_6_21  1
    abs[6,21]  abs_m_6_21  1
    abs[6,21]  physical_G_upper_outward  1
    abs[6,21]  G_residual  -8.9285714285714283e-04
    abs[6,22]  abs_p_6_22  1
    abs[6,22]  abs_m_6_22  1
    abs[6,22]  physical_G_upper_outward  1
    abs[6,22]  G_residual  -8.9285714285714283e-04
    abs[6,23]  abs_p_6_23  1
    abs[6,23]  abs_m_6_23  1
    abs[6,23]  physical_G_upper_outward  1
    abs[6,23]  G_residual  -8.9285714285714283e-04
    abs[6,24]  abs_p_6_24  1
    abs[6,24]  abs_m_6_24  1
    abs[6,24]  physical_G_upper_outward  1
    abs[6,24]  G_residual  -8.9285714285714283e-04
    abs[6,25]  abs_p_6_25  1
    abs[6,25]  abs_m_6_25  1
    abs[6,25]  physical_G_upper_outward  1
    abs[6,25]  G_residual  -8.9285714285714283e-04
    abs[6,26]  abs_p_6_26  1
    abs[6,26]  abs_m_6_26  1
    abs[6,26]  physical_G_upper_outward  1
    abs[6,26]  G_residual  -8.9285714285714283e-04
    abs[6,27]  abs_p_6_27  1
    abs[6,27]  abs_m_6_27  1
    abs[6,27]  physical_G_upper_outward  1
    abs[6,27]  G_residual  -8.9285714285714283e-04
    abs[6,28]  abs_p_6_28  1
    abs[6,28]  abs_m_6_28  1
    abs[6,28]  physical_G_upper_outward  1
    abs[6,28]  G_residual  -8.9285714285714283e-04
    abs[6,29]  abs_p_6_29  1
    abs[6,29]  abs_m_6_29  1
    abs[6,29]  physical_G_upper_outward  1
    abs[6,29]  G_residual  -8.9285714285714283e-04
    abs[6,30]  abs_p_6_30  1
    abs[6,30]  abs_m_6_30  1
    abs[6,30]  physical_G_upper_outward  1
    abs[6,30]  G_residual  -8.9285714285714283e-04
    abs[6,31]  abs_p_6_31  1
    abs[6,31]  abs_m_6_31  1
    abs[6,31]  physical_G_upper_outward  1
    abs[6,31]  G_residual  -8.9285714285714283e-04
    abs[6,32]  abs_p_6_32  1
    abs[6,32]  abs_m_6_32  1
    abs[6,32]  physical_G_upper_outward  1
    abs[6,32]  G_residual  -8.9285714285714283e-04
    abs[6,33]  abs_p_6_33  1
    abs[6,33]  abs_m_6_33  1
    abs[6,33]  physical_G_upper_outward  1
    abs[6,33]  G_residual  -8.9285714285714283e-04
    abs[6,34]  abs_p_6_34  1
    abs[6,34]  abs_m_6_34  1
    abs[6,34]  physical_G_upper_outward  1
    abs[6,34]  G_residual  -8.9285714285714283e-04
    abs[6,35]  abs_p_6_35  1
    abs[6,35]  abs_m_6_35  1
    abs[6,35]  physical_G_upper_outward  1
    abs[6,35]  G_residual  -8.9285714285714283e-04
    abs[7,8]  abs_p_7_8  1
    abs[7,8]  abs_m_7_8  1
    abs[7,8]  physical_G_upper_outward  1
    abs[7,8]  G_residual  -8.9285714285714283e-04
    abs[7,9]  abs_p_7_9  1
    abs[7,9]  abs_m_7_9  1
    abs[7,9]  physical_G_upper_outward  1
    abs[7,9]  G_residual  -8.9285714285714283e-04
    abs[7,10]  abs_p_7_10  1
    abs[7,10]  abs_m_7_10  1
    abs[7,10]  physical_G_upper_outward  1
    abs[7,10]  G_residual  -8.9285714285714283e-04
    abs[7,11]  abs_p_7_11  1
    abs[7,11]  abs_m_7_11  1
    abs[7,11]  physical_G_upper_outward  1
    abs[7,11]  G_residual  -8.9285714285714283e-04
    abs[7,12]  abs_p_7_12  1
    abs[7,12]  abs_m_7_12  1
    abs[7,12]  physical_G_upper_outward  1
    abs[7,12]  G_residual  -8.9285714285714283e-04
    abs[7,13]  abs_p_7_13  1
    abs[7,13]  abs_m_7_13  1
    abs[7,13]  physical_G_upper_outward  1
    abs[7,13]  G_residual  -8.9285714285714283e-04
    abs[7,14]  abs_p_7_14  1
    abs[7,14]  abs_m_7_14  1
    abs[7,14]  physical_G_upper_outward  1
    abs[7,14]  G_residual  -8.9285714285714283e-04
    abs[7,15]  abs_p_7_15  1
    abs[7,15]  abs_m_7_15  1
    abs[7,15]  physical_G_upper_outward  1
    abs[7,15]  G_residual  -8.9285714285714283e-04
    abs[7,16]  abs_p_7_16  1
    abs[7,16]  abs_m_7_16  1
    abs[7,16]  physical_G_upper_outward  1
    abs[7,16]  G_residual  -8.9285714285714283e-04
    abs[7,17]  abs_p_7_17  1
    abs[7,17]  abs_m_7_17  1
    abs[7,17]  physical_G_upper_outward  1
    abs[7,17]  G_residual  -8.9285714285714283e-04
    abs[7,18]  abs_p_7_18  1
    abs[7,18]  abs_m_7_18  1
    abs[7,18]  physical_G_upper_outward  1
    abs[7,18]  G_residual  -8.9285714285714283e-04
    abs[7,19]  abs_p_7_19  1
    abs[7,19]  abs_m_7_19  1
    abs[7,19]  physical_G_upper_outward  1
    abs[7,19]  G_residual  -8.9285714285714283e-04
    abs[7,20]  abs_p_7_20  1
    abs[7,20]  abs_m_7_20  1
    abs[7,20]  physical_G_upper_outward  1
    abs[7,20]  G_residual  -8.9285714285714283e-04
    abs[7,21]  abs_p_7_21  1
    abs[7,21]  abs_m_7_21  1
    abs[7,21]  physical_G_upper_outward  1
    abs[7,21]  G_residual  -8.9285714285714283e-04
    abs[7,22]  abs_p_7_22  1
    abs[7,22]  abs_m_7_22  1
    abs[7,22]  physical_G_upper_outward  1
    abs[7,22]  G_residual  -8.9285714285714283e-04
    abs[7,23]  abs_p_7_23  1
    abs[7,23]  abs_m_7_23  1
    abs[7,23]  physical_G_upper_outward  1
    abs[7,23]  G_residual  -8.9285714285714283e-04
    abs[7,24]  abs_p_7_24  1
    abs[7,24]  abs_m_7_24  1
    abs[7,24]  physical_G_upper_outward  1
    abs[7,24]  G_residual  -8.9285714285714283e-04
    abs[7,25]  abs_p_7_25  1
    abs[7,25]  abs_m_7_25  1
    abs[7,25]  physical_G_upper_outward  1
    abs[7,25]  G_residual  -8.9285714285714283e-04
    abs[7,26]  abs_p_7_26  1
    abs[7,26]  abs_m_7_26  1
    abs[7,26]  physical_G_upper_outward  1
    abs[7,26]  G_residual  -8.9285714285714283e-04
    abs[7,27]  abs_p_7_27  1
    abs[7,27]  abs_m_7_27  1
    abs[7,27]  physical_G_upper_outward  1
    abs[7,27]  G_residual  -8.9285714285714283e-04
    abs[7,28]  abs_p_7_28  1
    abs[7,28]  abs_m_7_28  1
    abs[7,28]  physical_G_upper_outward  1
    abs[7,28]  G_residual  -8.9285714285714283e-04
    abs[7,29]  abs_p_7_29  1
    abs[7,29]  abs_m_7_29  1
    abs[7,29]  physical_G_upper_outward  1
    abs[7,29]  G_residual  -8.9285714285714283e-04
    abs[7,30]  abs_p_7_30  1
    abs[7,30]  abs_m_7_30  1
    abs[7,30]  physical_G_upper_outward  1
    abs[7,30]  G_residual  -8.9285714285714283e-04
    abs[7,31]  abs_p_7_31  1
    abs[7,31]  abs_m_7_31  1
    abs[7,31]  physical_G_upper_outward  1
    abs[7,31]  G_residual  -8.9285714285714283e-04
    abs[7,32]  abs_p_7_32  1
    abs[7,32]  abs_m_7_32  1
    abs[7,32]  physical_G_upper_outward  1
    abs[7,32]  G_residual  -8.9285714285714283e-04
    abs[7,33]  abs_p_7_33  1
    abs[7,33]  abs_m_7_33  1
    abs[7,33]  physical_G_upper_outward  1
    abs[7,33]  G_residual  -8.9285714285714283e-04
    abs[7,34]  abs_p_7_34  1
    abs[7,34]  abs_m_7_34  1
    abs[7,34]  physical_G_upper_outward  1
    abs[7,34]  G_residual  -8.9285714285714283e-04
    abs[7,35]  abs_p_7_35  1
    abs[7,35]  abs_m_7_35  1
    abs[7,35]  physical_G_upper_outward  1
    abs[7,35]  G_residual  -8.9285714285714283e-04
    abs[8,9]  abs_p_8_9  1
    abs[8,9]  abs_m_8_9  1
    abs[8,9]  physical_G_upper_outward  1
    abs[8,9]  G_residual  -8.9285714285714283e-04
    abs[8,10]  abs_p_8_10  1
    abs[8,10]  abs_m_8_10  1
    abs[8,10]  physical_G_upper_outward  1
    abs[8,10]  G_residual  -8.9285714285714283e-04
    abs[8,11]  abs_p_8_11  1
    abs[8,11]  abs_m_8_11  1
    abs[8,11]  physical_G_upper_outward  1
    abs[8,11]  G_residual  -8.9285714285714283e-04
    abs[8,12]  abs_p_8_12  1
    abs[8,12]  abs_m_8_12  1
    abs[8,12]  physical_G_upper_outward  1
    abs[8,12]  G_residual  -8.9285714285714283e-04
    abs[8,13]  abs_p_8_13  1
    abs[8,13]  abs_m_8_13  1
    abs[8,13]  physical_G_upper_outward  1
    abs[8,13]  G_residual  -8.9285714285714283e-04
    abs[8,14]  abs_p_8_14  1
    abs[8,14]  abs_m_8_14  1
    abs[8,14]  physical_G_upper_outward  1
    abs[8,14]  G_residual  -8.9285714285714283e-04
    abs[8,15]  abs_p_8_15  1
    abs[8,15]  abs_m_8_15  1
    abs[8,15]  physical_G_upper_outward  1
    abs[8,15]  G_residual  -8.9285714285714283e-04
    abs[8,16]  abs_p_8_16  1
    abs[8,16]  abs_m_8_16  1
    abs[8,16]  physical_G_upper_outward  1
    abs[8,16]  G_residual  -8.9285714285714283e-04
    abs[8,17]  abs_p_8_17  1
    abs[8,17]  abs_m_8_17  1
    abs[8,17]  physical_G_upper_outward  1
    abs[8,17]  G_residual  -8.9285714285714283e-04
    abs[8,18]  abs_p_8_18  1
    abs[8,18]  abs_m_8_18  1
    abs[8,18]  physical_G_upper_outward  1
    abs[8,18]  G_residual  -8.9285714285714283e-04
    abs[8,19]  abs_p_8_19  1
    abs[8,19]  abs_m_8_19  1
    abs[8,19]  physical_G_upper_outward  1
    abs[8,19]  G_residual  -8.9285714285714283e-04
    abs[8,20]  abs_p_8_20  1
    abs[8,20]  abs_m_8_20  1
    abs[8,20]  physical_G_upper_outward  1
    abs[8,20]  G_residual  -8.9285714285714283e-04
    abs[8,21]  abs_p_8_21  1
    abs[8,21]  abs_m_8_21  1
    abs[8,21]  physical_G_upper_outward  1
    abs[8,21]  G_residual  -8.9285714285714283e-04
    abs[8,22]  abs_p_8_22  1
    abs[8,22]  abs_m_8_22  1
    abs[8,22]  physical_G_upper_outward  1
    abs[8,22]  G_residual  -8.9285714285714283e-04
    abs[8,23]  abs_p_8_23  1
    abs[8,23]  abs_m_8_23  1
    abs[8,23]  physical_G_upper_outward  1
    abs[8,23]  G_residual  -8.9285714285714283e-04
    abs[8,24]  abs_p_8_24  1
    abs[8,24]  abs_m_8_24  1
    abs[8,24]  physical_G_upper_outward  1
    abs[8,24]  G_residual  -8.9285714285714283e-04
    abs[8,25]  abs_p_8_25  1
    abs[8,25]  abs_m_8_25  1
    abs[8,25]  physical_G_upper_outward  1
    abs[8,25]  G_residual  -8.9285714285714283e-04
    abs[8,26]  abs_p_8_26  1
    abs[8,26]  abs_m_8_26  1
    abs[8,26]  physical_G_upper_outward  1
    abs[8,26]  G_residual  -8.9285714285714283e-04
    abs[8,27]  abs_p_8_27  1
    abs[8,27]  abs_m_8_27  1
    abs[8,27]  physical_G_upper_outward  1
    abs[8,27]  G_residual  -8.9285714285714283e-04
    abs[8,28]  abs_p_8_28  1
    abs[8,28]  abs_m_8_28  1
    abs[8,28]  physical_G_upper_outward  1
    abs[8,28]  G_residual  -8.9285714285714283e-04
    abs[8,29]  abs_p_8_29  1
    abs[8,29]  abs_m_8_29  1
    abs[8,29]  physical_G_upper_outward  1
    abs[8,29]  G_residual  -8.9285714285714283e-04
    abs[8,30]  abs_p_8_30  1
    abs[8,30]  abs_m_8_30  1
    abs[8,30]  physical_G_upper_outward  1
    abs[8,30]  G_residual  -8.9285714285714283e-04
    abs[8,31]  abs_p_8_31  1
    abs[8,31]  abs_m_8_31  1
    abs[8,31]  physical_G_upper_outward  1
    abs[8,31]  G_residual  -8.9285714285714283e-04
    abs[8,32]  abs_p_8_32  1
    abs[8,32]  abs_m_8_32  1
    abs[8,32]  physical_G_upper_outward  1
    abs[8,32]  G_residual  -8.9285714285714283e-04
    abs[8,33]  abs_p_8_33  1
    abs[8,33]  abs_m_8_33  1
    abs[8,33]  physical_G_upper_outward  1
    abs[8,33]  G_residual  -8.9285714285714283e-04
    abs[8,34]  abs_p_8_34  1
    abs[8,34]  abs_m_8_34  1
    abs[8,34]  physical_G_upper_outward  1
    abs[8,34]  G_residual  -8.9285714285714283e-04
    abs[8,35]  abs_p_8_35  1
    abs[8,35]  abs_m_8_35  1
    abs[8,35]  physical_G_upper_outward  1
    abs[8,35]  G_residual  -8.9285714285714283e-04
    abs[9,10]  abs_p_9_10  1
    abs[9,10]  abs_m_9_10  1
    abs[9,10]  physical_G_upper_outward  1
    abs[9,10]  G_residual  -8.9285714285714283e-04
    abs[9,11]  abs_p_9_11  1
    abs[9,11]  abs_m_9_11  1
    abs[9,11]  physical_G_upper_outward  1
    abs[9,11]  G_residual  -8.9285714285714283e-04
    abs[9,12]  abs_p_9_12  1
    abs[9,12]  abs_m_9_12  1
    abs[9,12]  physical_G_upper_outward  1
    abs[9,12]  G_residual  -8.9285714285714283e-04
    abs[9,13]  abs_p_9_13  1
    abs[9,13]  abs_m_9_13  1
    abs[9,13]  physical_G_upper_outward  1
    abs[9,13]  G_residual  -8.9285714285714283e-04
    abs[9,14]  abs_p_9_14  1
    abs[9,14]  abs_m_9_14  1
    abs[9,14]  physical_G_upper_outward  1
    abs[9,14]  G_residual  -8.9285714285714283e-04
    abs[9,15]  abs_p_9_15  1
    abs[9,15]  abs_m_9_15  1
    abs[9,15]  physical_G_upper_outward  1
    abs[9,15]  G_residual  -8.9285714285714283e-04
    abs[9,16]  abs_p_9_16  1
    abs[9,16]  abs_m_9_16  1
    abs[9,16]  physical_G_upper_outward  1
    abs[9,16]  G_residual  -8.9285714285714283e-04
    abs[9,17]  abs_p_9_17  1
    abs[9,17]  abs_m_9_17  1
    abs[9,17]  physical_G_upper_outward  1
    abs[9,17]  G_residual  -8.9285714285714283e-04
    abs[9,18]  abs_p_9_18  1
    abs[9,18]  abs_m_9_18  1
    abs[9,18]  physical_G_upper_outward  1
    abs[9,18]  G_residual  -8.9285714285714283e-04
    abs[9,19]  abs_p_9_19  1
    abs[9,19]  abs_m_9_19  1
    abs[9,19]  physical_G_upper_outward  1
    abs[9,19]  G_residual  -8.9285714285714283e-04
    abs[9,20]  abs_p_9_20  1
    abs[9,20]  abs_m_9_20  1
    abs[9,20]  physical_G_upper_outward  1
    abs[9,20]  G_residual  -8.9285714285714283e-04
    abs[9,21]  abs_p_9_21  1
    abs[9,21]  abs_m_9_21  1
    abs[9,21]  physical_G_upper_outward  1
    abs[9,21]  G_residual  -8.9285714285714283e-04
    abs[9,22]  abs_p_9_22  1
    abs[9,22]  abs_m_9_22  1
    abs[9,22]  physical_G_upper_outward  1
    abs[9,22]  G_residual  -8.9285714285714283e-04
    abs[9,23]  abs_p_9_23  1
    abs[9,23]  abs_m_9_23  1
    abs[9,23]  physical_G_upper_outward  1
    abs[9,23]  G_residual  -8.9285714285714283e-04
    abs[9,24]  abs_p_9_24  1
    abs[9,24]  abs_m_9_24  1
    abs[9,24]  physical_G_upper_outward  1
    abs[9,24]  G_residual  -8.9285714285714283e-04
    abs[9,25]  abs_p_9_25  1
    abs[9,25]  abs_m_9_25  1
    abs[9,25]  physical_G_upper_outward  1
    abs[9,25]  G_residual  -8.9285714285714283e-04
    abs[9,26]  abs_p_9_26  1
    abs[9,26]  abs_m_9_26  1
    abs[9,26]  physical_G_upper_outward  1
    abs[9,26]  G_residual  -8.9285714285714283e-04
    abs[9,27]  abs_p_9_27  1
    abs[9,27]  abs_m_9_27  1
    abs[9,27]  physical_G_upper_outward  1
    abs[9,27]  G_residual  -8.9285714285714283e-04
    abs[9,28]  abs_p_9_28  1
    abs[9,28]  abs_m_9_28  1
    abs[9,28]  physical_G_upper_outward  1
    abs[9,28]  G_residual  -8.9285714285714283e-04
    abs[9,29]  abs_p_9_29  1
    abs[9,29]  abs_m_9_29  1
    abs[9,29]  physical_G_upper_outward  1
    abs[9,29]  G_residual  -8.9285714285714283e-04
    abs[9,30]  abs_p_9_30  1
    abs[9,30]  abs_m_9_30  1
    abs[9,30]  physical_G_upper_outward  1
    abs[9,30]  G_residual  -8.9285714285714283e-04
    abs[9,31]  abs_p_9_31  1
    abs[9,31]  abs_m_9_31  1
    abs[9,31]  physical_G_upper_outward  1
    abs[9,31]  G_residual  -8.9285714285714283e-04
    abs[9,32]  abs_p_9_32  1
    abs[9,32]  abs_m_9_32  1
    abs[9,32]  physical_G_upper_outward  1
    abs[9,32]  G_residual  -8.9285714285714283e-04
    abs[9,33]  abs_p_9_33  1
    abs[9,33]  abs_m_9_33  1
    abs[9,33]  physical_G_upper_outward  1
    abs[9,33]  G_residual  -8.9285714285714283e-04
    abs[9,34]  abs_p_9_34  1
    abs[9,34]  abs_m_9_34  1
    abs[9,34]  physical_G_upper_outward  1
    abs[9,34]  G_residual  -8.9285714285714283e-04
    abs[9,35]  abs_p_9_35  1
    abs[9,35]  abs_m_9_35  1
    abs[9,35]  physical_G_upper_outward  1
    abs[9,35]  G_residual  -8.9285714285714283e-04
    abs[10,11]  abs_p_10_11  1
    abs[10,11]  abs_m_10_11  1
    abs[10,11]  physical_G_upper_outward  1
    abs[10,11]  G_residual  -8.9285714285714283e-04
    abs[10,12]  abs_p_10_12  1
    abs[10,12]  abs_m_10_12  1
    abs[10,12]  physical_G_upper_outward  1
    abs[10,12]  G_residual  -8.9285714285714283e-04
    abs[10,13]  abs_p_10_13  1
    abs[10,13]  abs_m_10_13  1
    abs[10,13]  physical_G_upper_outward  1
    abs[10,13]  G_residual  -8.9285714285714283e-04
    abs[10,14]  abs_p_10_14  1
    abs[10,14]  abs_m_10_14  1
    abs[10,14]  physical_G_upper_outward  1
    abs[10,14]  G_residual  -8.9285714285714283e-04
    abs[10,15]  abs_p_10_15  1
    abs[10,15]  abs_m_10_15  1
    abs[10,15]  physical_G_upper_outward  1
    abs[10,15]  G_residual  -8.9285714285714283e-04
    abs[10,16]  abs_p_10_16  1
    abs[10,16]  abs_m_10_16  1
    abs[10,16]  physical_G_upper_outward  1
    abs[10,16]  G_residual  -8.9285714285714283e-04
    abs[10,17]  abs_p_10_17  1
    abs[10,17]  abs_m_10_17  1
    abs[10,17]  physical_G_upper_outward  1
    abs[10,17]  G_residual  -8.9285714285714283e-04
    abs[10,18]  abs_p_10_18  1
    abs[10,18]  abs_m_10_18  1
    abs[10,18]  physical_G_upper_outward  1
    abs[10,18]  G_residual  -8.9285714285714283e-04
    abs[10,19]  abs_p_10_19  1
    abs[10,19]  abs_m_10_19  1
    abs[10,19]  physical_G_upper_outward  1
    abs[10,19]  G_residual  -8.9285714285714283e-04
    abs[10,20]  abs_p_10_20  1
    abs[10,20]  abs_m_10_20  1
    abs[10,20]  physical_G_upper_outward  1
    abs[10,20]  G_residual  -8.9285714285714283e-04
    abs[10,21]  abs_p_10_21  1
    abs[10,21]  abs_m_10_21  1
    abs[10,21]  physical_G_upper_outward  1
    abs[10,21]  G_residual  -8.9285714285714283e-04
    abs[10,22]  abs_p_10_22  1
    abs[10,22]  abs_m_10_22  1
    abs[10,22]  physical_G_upper_outward  1
    abs[10,22]  G_residual  -8.9285714285714283e-04
    abs[10,23]  abs_p_10_23  1
    abs[10,23]  abs_m_10_23  1
    abs[10,23]  physical_G_upper_outward  1
    abs[10,23]  G_residual  -8.9285714285714283e-04
    abs[10,24]  abs_p_10_24  1
    abs[10,24]  abs_m_10_24  1
    abs[10,24]  physical_G_upper_outward  1
    abs[10,24]  G_residual  -8.9285714285714283e-04
    abs[10,25]  abs_p_10_25  1
    abs[10,25]  abs_m_10_25  1
    abs[10,25]  physical_G_upper_outward  1
    abs[10,25]  G_residual  -8.9285714285714283e-04
    abs[10,26]  abs_p_10_26  1
    abs[10,26]  abs_m_10_26  1
    abs[10,26]  physical_G_upper_outward  1
    abs[10,26]  G_residual  -8.9285714285714283e-04
    abs[10,27]  abs_p_10_27  1
    abs[10,27]  abs_m_10_27  1
    abs[10,27]  physical_G_upper_outward  1
    abs[10,27]  G_residual  -8.9285714285714283e-04
    abs[10,28]  abs_p_10_28  1
    abs[10,28]  abs_m_10_28  1
    abs[10,28]  physical_G_upper_outward  1
    abs[10,28]  G_residual  -8.9285714285714283e-04
    abs[10,29]  abs_p_10_29  1
    abs[10,29]  abs_m_10_29  1
    abs[10,29]  physical_G_upper_outward  1
    abs[10,29]  G_residual  -8.9285714285714283e-04
    abs[10,30]  abs_p_10_30  1
    abs[10,30]  abs_m_10_30  1
    abs[10,30]  physical_G_upper_outward  1
    abs[10,30]  G_residual  -8.9285714285714283e-04
    abs[10,31]  abs_p_10_31  1
    abs[10,31]  abs_m_10_31  1
    abs[10,31]  physical_G_upper_outward  1
    abs[10,31]  G_residual  -8.9285714285714283e-04
    abs[10,32]  abs_p_10_32  1
    abs[10,32]  abs_m_10_32  1
    abs[10,32]  physical_G_upper_outward  1
    abs[10,32]  G_residual  -8.9285714285714283e-04
    abs[10,33]  abs_p_10_33  1
    abs[10,33]  abs_m_10_33  1
    abs[10,33]  physical_G_upper_outward  1
    abs[10,33]  G_residual  -8.9285714285714283e-04
    abs[10,34]  abs_p_10_34  1
    abs[10,34]  abs_m_10_34  1
    abs[10,34]  physical_G_upper_outward  1
    abs[10,34]  G_residual  -8.9285714285714283e-04
    abs[10,35]  abs_p_10_35  1
    abs[10,35]  abs_m_10_35  1
    abs[10,35]  physical_G_upper_outward  1
    abs[10,35]  G_residual  -8.9285714285714283e-04
    abs[11,12]  abs_p_11_12  1
    abs[11,12]  abs_m_11_12  1
    abs[11,12]  physical_G_upper_outward  1
    abs[11,12]  G_residual  -8.9285714285714283e-04
    abs[11,13]  abs_p_11_13  1
    abs[11,13]  abs_m_11_13  1
    abs[11,13]  physical_G_upper_outward  1
    abs[11,13]  G_residual  -8.9285714285714283e-04
    abs[11,14]  abs_p_11_14  1
    abs[11,14]  abs_m_11_14  1
    abs[11,14]  physical_G_upper_outward  1
    abs[11,14]  G_residual  -8.9285714285714283e-04
    abs[11,15]  abs_p_11_15  1
    abs[11,15]  abs_m_11_15  1
    abs[11,15]  physical_G_upper_outward  1
    abs[11,15]  G_residual  -8.9285714285714283e-04
    abs[11,16]  abs_p_11_16  1
    abs[11,16]  abs_m_11_16  1
    abs[11,16]  physical_G_upper_outward  1
    abs[11,16]  G_residual  -8.9285714285714283e-04
    abs[11,17]  abs_p_11_17  1
    abs[11,17]  abs_m_11_17  1
    abs[11,17]  physical_G_upper_outward  1
    abs[11,17]  G_residual  -8.9285714285714283e-04
    abs[11,18]  abs_p_11_18  1
    abs[11,18]  abs_m_11_18  1
    abs[11,18]  physical_G_upper_outward  1
    abs[11,18]  G_residual  -8.9285714285714283e-04
    abs[11,19]  abs_p_11_19  1
    abs[11,19]  abs_m_11_19  1
    abs[11,19]  physical_G_upper_outward  1
    abs[11,19]  G_residual  -8.9285714285714283e-04
    abs[11,20]  abs_p_11_20  1
    abs[11,20]  abs_m_11_20  1
    abs[11,20]  physical_G_upper_outward  1
    abs[11,20]  G_residual  -8.9285714285714283e-04
    abs[11,21]  abs_p_11_21  1
    abs[11,21]  abs_m_11_21  1
    abs[11,21]  physical_G_upper_outward  1
    abs[11,21]  G_residual  -8.9285714285714283e-04
    abs[11,22]  abs_p_11_22  1
    abs[11,22]  abs_m_11_22  1
    abs[11,22]  physical_G_upper_outward  1
    abs[11,22]  G_residual  -8.9285714285714283e-04
    abs[11,23]  abs_p_11_23  1
    abs[11,23]  abs_m_11_23  1
    abs[11,23]  physical_G_upper_outward  1
    abs[11,23]  G_residual  -8.9285714285714283e-04
    abs[11,24]  abs_p_11_24  1
    abs[11,24]  abs_m_11_24  1
    abs[11,24]  physical_G_upper_outward  1
    abs[11,24]  G_residual  -8.9285714285714283e-04
    abs[11,25]  abs_p_11_25  1
    abs[11,25]  abs_m_11_25  1
    abs[11,25]  physical_G_upper_outward  1
    abs[11,25]  G_residual  -8.9285714285714283e-04
    abs[11,26]  abs_p_11_26  1
    abs[11,26]  abs_m_11_26  1
    abs[11,26]  physical_G_upper_outward  1
    abs[11,26]  G_residual  -8.9285714285714283e-04
    abs[11,27]  abs_p_11_27  1
    abs[11,27]  abs_m_11_27  1
    abs[11,27]  physical_G_upper_outward  1
    abs[11,27]  G_residual  -8.9285714285714283e-04
    abs[11,28]  abs_p_11_28  1
    abs[11,28]  abs_m_11_28  1
    abs[11,28]  physical_G_upper_outward  1
    abs[11,28]  G_residual  -8.9285714285714283e-04
    abs[11,29]  abs_p_11_29  1
    abs[11,29]  abs_m_11_29  1
    abs[11,29]  physical_G_upper_outward  1
    abs[11,29]  G_residual  -8.9285714285714283e-04
    abs[11,30]  abs_p_11_30  1
    abs[11,30]  abs_m_11_30  1
    abs[11,30]  physical_G_upper_outward  1
    abs[11,30]  G_residual  -8.9285714285714283e-04
    abs[11,31]  abs_p_11_31  1
    abs[11,31]  abs_m_11_31  1
    abs[11,31]  physical_G_upper_outward  1
    abs[11,31]  G_residual  -8.9285714285714283e-04
    abs[11,32]  abs_p_11_32  1
    abs[11,32]  abs_m_11_32  1
    abs[11,32]  physical_G_upper_outward  1
    abs[11,32]  G_residual  -8.9285714285714283e-04
    abs[11,33]  abs_p_11_33  1
    abs[11,33]  abs_m_11_33  1
    abs[11,33]  physical_G_upper_outward  1
    abs[11,33]  G_residual  -8.9285714285714283e-04
    abs[11,34]  abs_p_11_34  1
    abs[11,34]  abs_m_11_34  1
    abs[11,34]  physical_G_upper_outward  1
    abs[11,34]  G_residual  -8.9285714285714283e-04
    abs[11,35]  abs_p_11_35  1
    abs[11,35]  abs_m_11_35  1
    abs[11,35]  physical_G_upper_outward  1
    abs[11,35]  G_residual  -8.9285714285714283e-04
    abs[12,13]  abs_p_12_13  1
    abs[12,13]  abs_m_12_13  1
    abs[12,13]  physical_G_upper_outward  1
    abs[12,13]  G_residual  -8.9285714285714283e-04
    abs[12,14]  abs_p_12_14  1
    abs[12,14]  abs_m_12_14  1
    abs[12,14]  physical_G_upper_outward  1
    abs[12,14]  G_residual  -8.9285714285714283e-04
    abs[12,15]  abs_p_12_15  1
    abs[12,15]  abs_m_12_15  1
    abs[12,15]  physical_G_upper_outward  1
    abs[12,15]  G_residual  -8.9285714285714283e-04
    abs[12,16]  abs_p_12_16  1
    abs[12,16]  abs_m_12_16  1
    abs[12,16]  physical_G_upper_outward  1
    abs[12,16]  G_residual  -8.9285714285714283e-04
    abs[12,17]  abs_p_12_17  1
    abs[12,17]  abs_m_12_17  1
    abs[12,17]  physical_G_upper_outward  1
    abs[12,17]  G_residual  -8.9285714285714283e-04
    abs[12,18]  abs_p_12_18  1
    abs[12,18]  abs_m_12_18  1
    abs[12,18]  physical_G_upper_outward  1
    abs[12,18]  G_residual  -8.9285714285714283e-04
    abs[12,19]  abs_p_12_19  1
    abs[12,19]  abs_m_12_19  1
    abs[12,19]  physical_G_upper_outward  1
    abs[12,19]  G_residual  -8.9285714285714283e-04
    abs[12,20]  abs_p_12_20  1
    abs[12,20]  abs_m_12_20  1
    abs[12,20]  physical_G_upper_outward  1
    abs[12,20]  G_residual  -8.9285714285714283e-04
    abs[12,21]  abs_p_12_21  1
    abs[12,21]  abs_m_12_21  1
    abs[12,21]  physical_G_upper_outward  1
    abs[12,21]  G_residual  -8.9285714285714283e-04
    abs[12,22]  abs_p_12_22  1
    abs[12,22]  abs_m_12_22  1
    abs[12,22]  physical_G_upper_outward  1
    abs[12,22]  G_residual  -8.9285714285714283e-04
    abs[12,23]  abs_p_12_23  1
    abs[12,23]  abs_m_12_23  1
    abs[12,23]  physical_G_upper_outward  1
    abs[12,23]  G_residual  -8.9285714285714283e-04
    abs[12,24]  abs_p_12_24  1
    abs[12,24]  abs_m_12_24  1
    abs[12,24]  physical_G_upper_outward  1
    abs[12,24]  G_residual  -8.9285714285714283e-04
    abs[12,25]  abs_p_12_25  1
    abs[12,25]  abs_m_12_25  1
    abs[12,25]  physical_G_upper_outward  1
    abs[12,25]  G_residual  -8.9285714285714283e-04
    abs[12,26]  abs_p_12_26  1
    abs[12,26]  abs_m_12_26  1
    abs[12,26]  physical_G_upper_outward  1
    abs[12,26]  G_residual  -8.9285714285714283e-04
    abs[12,27]  abs_p_12_27  1
    abs[12,27]  abs_m_12_27  1
    abs[12,27]  physical_G_upper_outward  1
    abs[12,27]  G_residual  -8.9285714285714283e-04
    abs[12,28]  abs_p_12_28  1
    abs[12,28]  abs_m_12_28  1
    abs[12,28]  physical_G_upper_outward  1
    abs[12,28]  G_residual  -8.9285714285714283e-04
    abs[12,29]  abs_p_12_29  1
    abs[12,29]  abs_m_12_29  1
    abs[12,29]  physical_G_upper_outward  1
    abs[12,29]  G_residual  -8.9285714285714283e-04
    abs[12,30]  abs_p_12_30  1
    abs[12,30]  abs_m_12_30  1
    abs[12,30]  physical_G_upper_outward  1
    abs[12,30]  G_residual  -8.9285714285714283e-04
    abs[12,31]  abs_p_12_31  1
    abs[12,31]  abs_m_12_31  1
    abs[12,31]  physical_G_upper_outward  1
    abs[12,31]  G_residual  -8.9285714285714283e-04
    abs[12,32]  abs_p_12_32  1
    abs[12,32]  abs_m_12_32  1
    abs[12,32]  physical_G_upper_outward  1
    abs[12,32]  G_residual  -8.9285714285714283e-04
    abs[12,33]  abs_p_12_33  1
    abs[12,33]  abs_m_12_33  1
    abs[12,33]  physical_G_upper_outward  1
    abs[12,33]  G_residual  -8.9285714285714283e-04
    abs[12,34]  abs_p_12_34  1
    abs[12,34]  abs_m_12_34  1
    abs[12,34]  physical_G_upper_outward  1
    abs[12,34]  G_residual  -8.9285714285714283e-04
    abs[12,35]  abs_p_12_35  1
    abs[12,35]  abs_m_12_35  1
    abs[12,35]  physical_G_upper_outward  1
    abs[12,35]  G_residual  -8.9285714285714283e-04
    abs[13,14]  abs_p_13_14  1
    abs[13,14]  abs_m_13_14  1
    abs[13,14]  physical_G_upper_outward  1
    abs[13,14]  G_residual  -8.9285714285714283e-04
    abs[13,15]  abs_p_13_15  1
    abs[13,15]  abs_m_13_15  1
    abs[13,15]  physical_G_upper_outward  1
    abs[13,15]  G_residual  -8.9285714285714283e-04
    abs[13,16]  abs_p_13_16  1
    abs[13,16]  abs_m_13_16  1
    abs[13,16]  physical_G_upper_outward  1
    abs[13,16]  G_residual  -8.9285714285714283e-04
    abs[13,17]  abs_p_13_17  1
    abs[13,17]  abs_m_13_17  1
    abs[13,17]  physical_G_upper_outward  1
    abs[13,17]  G_residual  -8.9285714285714283e-04
    abs[13,18]  abs_p_13_18  1
    abs[13,18]  abs_m_13_18  1
    abs[13,18]  physical_G_upper_outward  1
    abs[13,18]  G_residual  -8.9285714285714283e-04
    abs[13,19]  abs_p_13_19  1
    abs[13,19]  abs_m_13_19  1
    abs[13,19]  physical_G_upper_outward  1
    abs[13,19]  G_residual  -8.9285714285714283e-04
    abs[13,20]  abs_p_13_20  1
    abs[13,20]  abs_m_13_20  1
    abs[13,20]  physical_G_upper_outward  1
    abs[13,20]  G_residual  -8.9285714285714283e-04
    abs[13,21]  abs_p_13_21  1
    abs[13,21]  abs_m_13_21  1
    abs[13,21]  physical_G_upper_outward  1
    abs[13,21]  G_residual  -8.9285714285714283e-04
    abs[13,22]  abs_p_13_22  1
    abs[13,22]  abs_m_13_22  1
    abs[13,22]  physical_G_upper_outward  1
    abs[13,22]  G_residual  -8.9285714285714283e-04
    abs[13,23]  abs_p_13_23  1
    abs[13,23]  abs_m_13_23  1
    abs[13,23]  physical_G_upper_outward  1
    abs[13,23]  G_residual  -8.9285714285714283e-04
    abs[13,24]  abs_p_13_24  1
    abs[13,24]  abs_m_13_24  1
    abs[13,24]  physical_G_upper_outward  1
    abs[13,24]  G_residual  -8.9285714285714283e-04
    abs[13,25]  abs_p_13_25  1
    abs[13,25]  abs_m_13_25  1
    abs[13,25]  physical_G_upper_outward  1
    abs[13,25]  G_residual  -8.9285714285714283e-04
    abs[13,26]  abs_p_13_26  1
    abs[13,26]  abs_m_13_26  1
    abs[13,26]  physical_G_upper_outward  1
    abs[13,26]  G_residual  -8.9285714285714283e-04
    abs[13,27]  abs_p_13_27  1
    abs[13,27]  abs_m_13_27  1
    abs[13,27]  physical_G_upper_outward  1
    abs[13,27]  G_residual  -8.9285714285714283e-04
    abs[13,28]  abs_p_13_28  1
    abs[13,28]  abs_m_13_28  1
    abs[13,28]  physical_G_upper_outward  1
    abs[13,28]  G_residual  -8.9285714285714283e-04
    abs[13,29]  abs_p_13_29  1
    abs[13,29]  abs_m_13_29  1
    abs[13,29]  physical_G_upper_outward  1
    abs[13,29]  G_residual  -8.9285714285714283e-04
    abs[13,30]  abs_p_13_30  1
    abs[13,30]  abs_m_13_30  1
    abs[13,30]  physical_G_upper_outward  1
    abs[13,30]  G_residual  -8.9285714285714283e-04
    abs[13,31]  abs_p_13_31  1
    abs[13,31]  abs_m_13_31  1
    abs[13,31]  physical_G_upper_outward  1
    abs[13,31]  G_residual  -8.9285714285714283e-04
    abs[13,32]  abs_p_13_32  1
    abs[13,32]  abs_m_13_32  1
    abs[13,32]  physical_G_upper_outward  1
    abs[13,32]  G_residual  -8.9285714285714283e-04
    abs[13,33]  abs_p_13_33  1
    abs[13,33]  abs_m_13_33  1
    abs[13,33]  physical_G_upper_outward  1
    abs[13,33]  G_residual  -8.9285714285714283e-04
    abs[13,34]  abs_p_13_34  1
    abs[13,34]  abs_m_13_34  1
    abs[13,34]  physical_G_upper_outward  1
    abs[13,34]  G_residual  -8.9285714285714283e-04
    abs[13,35]  abs_p_13_35  1
    abs[13,35]  abs_m_13_35  1
    abs[13,35]  physical_G_upper_outward  1
    abs[13,35]  G_residual  -8.9285714285714283e-04
    abs[14,15]  abs_p_14_15  1
    abs[14,15]  abs_m_14_15  1
    abs[14,15]  physical_G_upper_outward  1
    abs[14,15]  G_residual  -8.9285714285714283e-04
    abs[14,16]  abs_p_14_16  1
    abs[14,16]  abs_m_14_16  1
    abs[14,16]  physical_G_upper_outward  1
    abs[14,16]  G_residual  -8.9285714285714283e-04
    abs[14,17]  abs_p_14_17  1
    abs[14,17]  abs_m_14_17  1
    abs[14,17]  physical_G_upper_outward  1
    abs[14,17]  G_residual  -8.9285714285714283e-04
    abs[14,18]  abs_p_14_18  1
    abs[14,18]  abs_m_14_18  1
    abs[14,18]  physical_G_upper_outward  1
    abs[14,18]  G_residual  -8.9285714285714283e-04
    abs[14,19]  abs_p_14_19  1
    abs[14,19]  abs_m_14_19  1
    abs[14,19]  physical_G_upper_outward  1
    abs[14,19]  G_residual  -8.9285714285714283e-04
    abs[14,20]  abs_p_14_20  1
    abs[14,20]  abs_m_14_20  1
    abs[14,20]  physical_G_upper_outward  1
    abs[14,20]  G_residual  -8.9285714285714283e-04
    abs[14,21]  abs_p_14_21  1
    abs[14,21]  abs_m_14_21  1
    abs[14,21]  physical_G_upper_outward  1
    abs[14,21]  G_residual  -8.9285714285714283e-04
    abs[14,22]  abs_p_14_22  1
    abs[14,22]  abs_m_14_22  1
    abs[14,22]  physical_G_upper_outward  1
    abs[14,22]  G_residual  -8.9285714285714283e-04
    abs[14,23]  abs_p_14_23  1
    abs[14,23]  abs_m_14_23  1
    abs[14,23]  physical_G_upper_outward  1
    abs[14,23]  G_residual  -8.9285714285714283e-04
    abs[14,24]  abs_p_14_24  1
    abs[14,24]  abs_m_14_24  1
    abs[14,24]  physical_G_upper_outward  1
    abs[14,24]  G_residual  -8.9285714285714283e-04
    abs[14,25]  abs_p_14_25  1
    abs[14,25]  abs_m_14_25  1
    abs[14,25]  physical_G_upper_outward  1
    abs[14,25]  G_residual  -8.9285714285714283e-04
    abs[14,26]  abs_p_14_26  1
    abs[14,26]  abs_m_14_26  1
    abs[14,26]  physical_G_upper_outward  1
    abs[14,26]  G_residual  -8.9285714285714283e-04
    abs[14,27]  abs_p_14_27  1
    abs[14,27]  abs_m_14_27  1
    abs[14,27]  physical_G_upper_outward  1
    abs[14,27]  G_residual  -8.9285714285714283e-04
    abs[14,28]  abs_p_14_28  1
    abs[14,28]  abs_m_14_28  1
    abs[14,28]  physical_G_upper_outward  1
    abs[14,28]  G_residual  -8.9285714285714283e-04
    abs[14,29]  abs_p_14_29  1
    abs[14,29]  abs_m_14_29  1
    abs[14,29]  physical_G_upper_outward  1
    abs[14,29]  G_residual  -8.9285714285714283e-04
    abs[14,30]  abs_p_14_30  1
    abs[14,30]  abs_m_14_30  1
    abs[14,30]  physical_G_upper_outward  1
    abs[14,30]  G_residual  -8.9285714285714283e-04
    abs[14,31]  abs_p_14_31  1
    abs[14,31]  abs_m_14_31  1
    abs[14,31]  physical_G_upper_outward  1
    abs[14,31]  G_residual  -8.9285714285714283e-04
    abs[14,32]  abs_p_14_32  1
    abs[14,32]  abs_m_14_32  1
    abs[14,32]  physical_G_upper_outward  1
    abs[14,32]  G_residual  -8.9285714285714283e-04
    abs[14,33]  abs_p_14_33  1
    abs[14,33]  abs_m_14_33  1
    abs[14,33]  physical_G_upper_outward  1
    abs[14,33]  G_residual  -8.9285714285714283e-04
    abs[14,34]  abs_p_14_34  1
    abs[14,34]  abs_m_14_34  1
    abs[14,34]  physical_G_upper_outward  1
    abs[14,34]  G_residual  -8.9285714285714283e-04
    abs[14,35]  abs_p_14_35  1
    abs[14,35]  abs_m_14_35  1
    abs[14,35]  physical_G_upper_outward  1
    abs[14,35]  G_residual  -8.9285714285714283e-04
    abs[15,16]  abs_p_15_16  1
    abs[15,16]  abs_m_15_16  1
    abs[15,16]  physical_G_upper_outward  1
    abs[15,16]  G_residual  -8.9285714285714283e-04
    abs[15,17]  abs_p_15_17  1
    abs[15,17]  abs_m_15_17  1
    abs[15,17]  physical_G_upper_outward  1
    abs[15,17]  G_residual  -8.9285714285714283e-04
    abs[15,18]  abs_p_15_18  1
    abs[15,18]  abs_m_15_18  1
    abs[15,18]  physical_G_upper_outward  1
    abs[15,18]  G_residual  -8.9285714285714283e-04
    abs[15,19]  abs_p_15_19  1
    abs[15,19]  abs_m_15_19  1
    abs[15,19]  physical_G_upper_outward  1
    abs[15,19]  G_residual  -8.9285714285714283e-04
    abs[15,20]  abs_p_15_20  1
    abs[15,20]  abs_m_15_20  1
    abs[15,20]  physical_G_upper_outward  1
    abs[15,20]  G_residual  -8.9285714285714283e-04
    abs[15,21]  abs_p_15_21  1
    abs[15,21]  abs_m_15_21  1
    abs[15,21]  physical_G_upper_outward  1
    abs[15,21]  G_residual  -8.9285714285714283e-04
    abs[15,22]  abs_p_15_22  1
    abs[15,22]  abs_m_15_22  1
    abs[15,22]  physical_G_upper_outward  1
    abs[15,22]  G_residual  -8.9285714285714283e-04
    abs[15,23]  abs_p_15_23  1
    abs[15,23]  abs_m_15_23  1
    abs[15,23]  physical_G_upper_outward  1
    abs[15,23]  G_residual  -8.9285714285714283e-04
    abs[15,24]  abs_p_15_24  1
    abs[15,24]  abs_m_15_24  1
    abs[15,24]  physical_G_upper_outward  1
    abs[15,24]  G_residual  -8.9285714285714283e-04
    abs[15,25]  abs_p_15_25  1
    abs[15,25]  abs_m_15_25  1
    abs[15,25]  physical_G_upper_outward  1
    abs[15,25]  G_residual  -8.9285714285714283e-04
    abs[15,26]  abs_p_15_26  1
    abs[15,26]  abs_m_15_26  1
    abs[15,26]  physical_G_upper_outward  1
    abs[15,26]  G_residual  -8.9285714285714283e-04
    abs[15,27]  abs_p_15_27  1
    abs[15,27]  abs_m_15_27  1
    abs[15,27]  physical_G_upper_outward  1
    abs[15,27]  G_residual  -8.9285714285714283e-04
    abs[15,28]  abs_p_15_28  1
    abs[15,28]  abs_m_15_28  1
    abs[15,28]  physical_G_upper_outward  1
    abs[15,28]  G_residual  -8.9285714285714283e-04
    abs[15,29]  abs_p_15_29  1
    abs[15,29]  abs_m_15_29  1
    abs[15,29]  physical_G_upper_outward  1
    abs[15,29]  G_residual  -8.9285714285714283e-04
    abs[15,30]  abs_p_15_30  1
    abs[15,30]  abs_m_15_30  1
    abs[15,30]  physical_G_upper_outward  1
    abs[15,30]  G_residual  -8.9285714285714283e-04
    abs[15,31]  abs_p_15_31  1
    abs[15,31]  abs_m_15_31  1
    abs[15,31]  physical_G_upper_outward  1
    abs[15,31]  G_residual  -8.9285714285714283e-04
    abs[15,32]  abs_p_15_32  1
    abs[15,32]  abs_m_15_32  1
    abs[15,32]  physical_G_upper_outward  1
    abs[15,32]  G_residual  -8.9285714285714283e-04
    abs[15,33]  abs_p_15_33  1
    abs[15,33]  abs_m_15_33  1
    abs[15,33]  physical_G_upper_outward  1
    abs[15,33]  G_residual  -8.9285714285714283e-04
    abs[15,34]  abs_p_15_34  1
    abs[15,34]  abs_m_15_34  1
    abs[15,34]  physical_G_upper_outward  1
    abs[15,34]  G_residual  -8.9285714285714283e-04
    abs[15,35]  abs_p_15_35  1
    abs[15,35]  abs_m_15_35  1
    abs[15,35]  physical_G_upper_outward  1
    abs[15,35]  G_residual  -8.9285714285714283e-04
    abs[16,17]  abs_p_16_17  1
    abs[16,17]  abs_m_16_17  1
    abs[16,17]  physical_G_upper_outward  1
    abs[16,17]  G_residual  -8.9285714285714283e-04
    abs[16,18]  abs_p_16_18  1
    abs[16,18]  abs_m_16_18  1
    abs[16,18]  physical_G_upper_outward  1
    abs[16,18]  G_residual  -8.9285714285714283e-04
    abs[16,19]  abs_p_16_19  1
    abs[16,19]  abs_m_16_19  1
    abs[16,19]  physical_G_upper_outward  1
    abs[16,19]  G_residual  -8.9285714285714283e-04
    abs[16,20]  abs_p_16_20  1
    abs[16,20]  abs_m_16_20  1
    abs[16,20]  physical_G_upper_outward  1
    abs[16,20]  G_residual  -8.9285714285714283e-04
    abs[16,21]  abs_p_16_21  1
    abs[16,21]  abs_m_16_21  1
    abs[16,21]  physical_G_upper_outward  1
    abs[16,21]  G_residual  -8.9285714285714283e-04
    abs[16,22]  abs_p_16_22  1
    abs[16,22]  abs_m_16_22  1
    abs[16,22]  physical_G_upper_outward  1
    abs[16,22]  G_residual  -8.9285714285714283e-04
    abs[16,23]  abs_p_16_23  1
    abs[16,23]  abs_m_16_23  1
    abs[16,23]  physical_G_upper_outward  1
    abs[16,23]  G_residual  -8.9285714285714283e-04
    abs[16,24]  abs_p_16_24  1
    abs[16,24]  abs_m_16_24  1
    abs[16,24]  physical_G_upper_outward  1
    abs[16,24]  G_residual  -8.9285714285714283e-04
    abs[16,25]  abs_p_16_25  1
    abs[16,25]  abs_m_16_25  1
    abs[16,25]  physical_G_upper_outward  1
    abs[16,25]  G_residual  -8.9285714285714283e-04
    abs[16,26]  abs_p_16_26  1
    abs[16,26]  abs_m_16_26  1
    abs[16,26]  physical_G_upper_outward  1
    abs[16,26]  G_residual  -8.9285714285714283e-04
    abs[16,27]  abs_p_16_27  1
    abs[16,27]  abs_m_16_27  1
    abs[16,27]  physical_G_upper_outward  1
    abs[16,27]  G_residual  -8.9285714285714283e-04
    abs[16,28]  abs_p_16_28  1
    abs[16,28]  abs_m_16_28  1
    abs[16,28]  physical_G_upper_outward  1
    abs[16,28]  G_residual  -8.9285714285714283e-04
    abs[16,29]  abs_p_16_29  1
    abs[16,29]  abs_m_16_29  1
    abs[16,29]  physical_G_upper_outward  1
    abs[16,29]  G_residual  -8.9285714285714283e-04
    abs[16,30]  abs_p_16_30  1
    abs[16,30]  abs_m_16_30  1
    abs[16,30]  physical_G_upper_outward  1
    abs[16,30]  G_residual  -8.9285714285714283e-04
    abs[16,31]  abs_p_16_31  1
    abs[16,31]  abs_m_16_31  1
    abs[16,31]  physical_G_upper_outward  1
    abs[16,31]  G_residual  -8.9285714285714283e-04
    abs[16,32]  abs_p_16_32  1
    abs[16,32]  abs_m_16_32  1
    abs[16,32]  physical_G_upper_outward  1
    abs[16,32]  G_residual  -8.9285714285714283e-04
    abs[16,33]  abs_p_16_33  1
    abs[16,33]  abs_m_16_33  1
    abs[16,33]  physical_G_upper_outward  1
    abs[16,33]  G_residual  -8.9285714285714283e-04
    abs[16,34]  abs_p_16_34  1
    abs[16,34]  abs_m_16_34  1
    abs[16,34]  physical_G_upper_outward  1
    abs[16,34]  G_residual  -8.9285714285714283e-04
    abs[16,35]  abs_p_16_35  1
    abs[16,35]  abs_m_16_35  1
    abs[16,35]  physical_G_upper_outward  1
    abs[16,35]  G_residual  -8.9285714285714283e-04
    abs[17,18]  abs_p_17_18  1
    abs[17,18]  abs_m_17_18  1
    abs[17,18]  physical_G_upper_outward  1
    abs[17,18]  G_residual  -8.9285714285714283e-04
    abs[17,19]  abs_p_17_19  1
    abs[17,19]  abs_m_17_19  1
    abs[17,19]  physical_G_upper_outward  1
    abs[17,19]  G_residual  -8.9285714285714283e-04
    abs[17,20]  abs_p_17_20  1
    abs[17,20]  abs_m_17_20  1
    abs[17,20]  physical_G_upper_outward  1
    abs[17,20]  G_residual  -8.9285714285714283e-04
    abs[17,21]  abs_p_17_21  1
    abs[17,21]  abs_m_17_21  1
    abs[17,21]  physical_G_upper_outward  1
    abs[17,21]  G_residual  -8.9285714285714283e-04
    abs[17,22]  abs_p_17_22  1
    abs[17,22]  abs_m_17_22  1
    abs[17,22]  physical_G_upper_outward  1
    abs[17,22]  G_residual  -8.9285714285714283e-04
    abs[17,23]  abs_p_17_23  1
    abs[17,23]  abs_m_17_23  1
    abs[17,23]  physical_G_upper_outward  1
    abs[17,23]  G_residual  -8.9285714285714283e-04
    abs[17,24]  abs_p_17_24  1
    abs[17,24]  abs_m_17_24  1
    abs[17,24]  physical_G_upper_outward  1
    abs[17,24]  G_residual  -8.9285714285714283e-04
    abs[17,25]  abs_p_17_25  1
    abs[17,25]  abs_m_17_25  1
    abs[17,25]  physical_G_upper_outward  1
    abs[17,25]  G_residual  -8.9285714285714283e-04
    abs[17,26]  abs_p_17_26  1
    abs[17,26]  abs_m_17_26  1
    abs[17,26]  physical_G_upper_outward  1
    abs[17,26]  G_residual  -8.9285714285714283e-04
    abs[17,27]  abs_p_17_27  1
    abs[17,27]  abs_m_17_27  1
    abs[17,27]  physical_G_upper_outward  1
    abs[17,27]  G_residual  -8.9285714285714283e-04
    abs[17,28]  abs_p_17_28  1
    abs[17,28]  abs_m_17_28  1
    abs[17,28]  physical_G_upper_outward  1
    abs[17,28]  G_residual  -8.9285714285714283e-04
    abs[17,29]  abs_p_17_29  1
    abs[17,29]  abs_m_17_29  1
    abs[17,29]  physical_G_upper_outward  1
    abs[17,29]  G_residual  -8.9285714285714283e-04
    abs[17,30]  abs_p_17_30  1
    abs[17,30]  abs_m_17_30  1
    abs[17,30]  physical_G_upper_outward  1
    abs[17,30]  G_residual  -8.9285714285714283e-04
    abs[17,31]  abs_p_17_31  1
    abs[17,31]  abs_m_17_31  1
    abs[17,31]  physical_G_upper_outward  1
    abs[17,31]  G_residual  -8.9285714285714283e-04
    abs[17,32]  abs_p_17_32  1
    abs[17,32]  abs_m_17_32  1
    abs[17,32]  physical_G_upper_outward  1
    abs[17,32]  G_residual  -8.9285714285714283e-04
    abs[17,33]  abs_p_17_33  1
    abs[17,33]  abs_m_17_33  1
    abs[17,33]  physical_G_upper_outward  1
    abs[17,33]  G_residual  -8.9285714285714283e-04
    abs[17,34]  abs_p_17_34  1
    abs[17,34]  abs_m_17_34  1
    abs[17,34]  physical_G_upper_outward  1
    abs[17,34]  G_residual  -8.9285714285714283e-04
    abs[17,35]  abs_p_17_35  1
    abs[17,35]  abs_m_17_35  1
    abs[17,35]  physical_G_upper_outward  1
    abs[17,35]  G_residual  -8.9285714285714283e-04
    abs[18,19]  abs_p_18_19  1
    abs[18,19]  abs_m_18_19  1
    abs[18,19]  physical_G_upper_outward  1
    abs[18,19]  G_residual  -8.9285714285714283e-04
    abs[18,20]  abs_p_18_20  1
    abs[18,20]  abs_m_18_20  1
    abs[18,20]  physical_G_upper_outward  1
    abs[18,20]  G_residual  -8.9285714285714283e-04
    abs[18,21]  abs_p_18_21  1
    abs[18,21]  abs_m_18_21  1
    abs[18,21]  physical_G_upper_outward  1
    abs[18,21]  G_residual  -8.9285714285714283e-04
    abs[18,22]  abs_p_18_22  1
    abs[18,22]  abs_m_18_22  1
    abs[18,22]  physical_G_upper_outward  1
    abs[18,22]  G_residual  -8.9285714285714283e-04
    abs[18,23]  abs_p_18_23  1
    abs[18,23]  abs_m_18_23  1
    abs[18,23]  physical_G_upper_outward  1
    abs[18,23]  G_residual  -8.9285714285714283e-04
    abs[18,24]  abs_p_18_24  1
    abs[18,24]  abs_m_18_24  1
    abs[18,24]  physical_G_upper_outward  1
    abs[18,24]  G_residual  -8.9285714285714283e-04
    abs[18,25]  abs_p_18_25  1
    abs[18,25]  abs_m_18_25  1
    abs[18,25]  physical_G_upper_outward  1
    abs[18,25]  G_residual  -8.9285714285714283e-04
    abs[18,26]  abs_p_18_26  1
    abs[18,26]  abs_m_18_26  1
    abs[18,26]  physical_G_upper_outward  1
    abs[18,26]  G_residual  -8.9285714285714283e-04
    abs[18,27]  abs_p_18_27  1
    abs[18,27]  abs_m_18_27  1
    abs[18,27]  physical_G_upper_outward  1
    abs[18,27]  G_residual  -8.9285714285714283e-04
    abs[18,28]  abs_p_18_28  1
    abs[18,28]  abs_m_18_28  1
    abs[18,28]  physical_G_upper_outward  1
    abs[18,28]  G_residual  -8.9285714285714283e-04
    abs[18,29]  abs_p_18_29  1
    abs[18,29]  abs_m_18_29  1
    abs[18,29]  physical_G_upper_outward  1
    abs[18,29]  G_residual  -8.9285714285714283e-04
    abs[18,30]  abs_p_18_30  1
    abs[18,30]  abs_m_18_30  1
    abs[18,30]  physical_G_upper_outward  1
    abs[18,30]  G_residual  -8.9285714285714283e-04
    abs[18,31]  abs_p_18_31  1
    abs[18,31]  abs_m_18_31  1
    abs[18,31]  physical_G_upper_outward  1
    abs[18,31]  G_residual  -8.9285714285714283e-04
    abs[18,32]  abs_p_18_32  1
    abs[18,32]  abs_m_18_32  1
    abs[18,32]  physical_G_upper_outward  1
    abs[18,32]  G_residual  -8.9285714285714283e-04
    abs[18,33]  abs_p_18_33  1
    abs[18,33]  abs_m_18_33  1
    abs[18,33]  physical_G_upper_outward  1
    abs[18,33]  G_residual  -8.9285714285714283e-04
    abs[18,34]  abs_p_18_34  1
    abs[18,34]  abs_m_18_34  1
    abs[18,34]  physical_G_upper_outward  1
    abs[18,34]  G_residual  -8.9285714285714283e-04
    abs[18,35]  abs_p_18_35  1
    abs[18,35]  abs_m_18_35  1
    abs[18,35]  physical_G_upper_outward  1
    abs[18,35]  G_residual  -8.9285714285714283e-04
    abs[19,20]  abs_p_19_20  1
    abs[19,20]  abs_m_19_20  1
    abs[19,20]  physical_G_upper_outward  1
    abs[19,20]  G_residual  -8.9285714285714283e-04
    abs[19,21]  abs_p_19_21  1
    abs[19,21]  abs_m_19_21  1
    abs[19,21]  physical_G_upper_outward  1
    abs[19,21]  G_residual  -8.9285714285714283e-04
    abs[19,22]  abs_p_19_22  1
    abs[19,22]  abs_m_19_22  1
    abs[19,22]  physical_G_upper_outward  1
    abs[19,22]  G_residual  -8.9285714285714283e-04
    abs[19,23]  abs_p_19_23  1
    abs[19,23]  abs_m_19_23  1
    abs[19,23]  physical_G_upper_outward  1
    abs[19,23]  G_residual  -8.9285714285714283e-04
    abs[19,24]  abs_p_19_24  1
    abs[19,24]  abs_m_19_24  1
    abs[19,24]  physical_G_upper_outward  1
    abs[19,24]  G_residual  -8.9285714285714283e-04
    abs[19,25]  abs_p_19_25  1
    abs[19,25]  abs_m_19_25  1
    abs[19,25]  physical_G_upper_outward  1
    abs[19,25]  G_residual  -8.9285714285714283e-04
    abs[19,26]  abs_p_19_26  1
    abs[19,26]  abs_m_19_26  1
    abs[19,26]  physical_G_upper_outward  1
    abs[19,26]  G_residual  -8.9285714285714283e-04
    abs[19,27]  abs_p_19_27  1
    abs[19,27]  abs_m_19_27  1
    abs[19,27]  physical_G_upper_outward  1
    abs[19,27]  G_residual  -8.9285714285714283e-04
    abs[19,28]  abs_p_19_28  1
    abs[19,28]  abs_m_19_28  1
    abs[19,28]  physical_G_upper_outward  1
    abs[19,28]  G_residual  -8.9285714285714283e-04
    abs[19,29]  abs_p_19_29  1
    abs[19,29]  abs_m_19_29  1
    abs[19,29]  physical_G_upper_outward  1
    abs[19,29]  G_residual  -8.9285714285714283e-04
    abs[19,30]  abs_p_19_30  1
    abs[19,30]  abs_m_19_30  1
    abs[19,30]  physical_G_upper_outward  1
    abs[19,30]  G_residual  -8.9285714285714283e-04
    abs[19,31]  abs_p_19_31  1
    abs[19,31]  abs_m_19_31  1
    abs[19,31]  physical_G_upper_outward  1
    abs[19,31]  G_residual  -8.9285714285714283e-04
    abs[19,32]  abs_p_19_32  1
    abs[19,32]  abs_m_19_32  1
    abs[19,32]  physical_G_upper_outward  1
    abs[19,32]  G_residual  -8.9285714285714283e-04
    abs[19,33]  abs_p_19_33  1
    abs[19,33]  abs_m_19_33  1
    abs[19,33]  physical_G_upper_outward  1
    abs[19,33]  G_residual  -8.9285714285714283e-04
    abs[19,34]  abs_p_19_34  1
    abs[19,34]  abs_m_19_34  1
    abs[19,34]  physical_G_upper_outward  1
    abs[19,34]  G_residual  -8.9285714285714283e-04
    abs[19,35]  abs_p_19_35  1
    abs[19,35]  abs_m_19_35  1
    abs[19,35]  physical_G_upper_outward  1
    abs[19,35]  G_residual  -8.9285714285714283e-04
    abs[20,21]  abs_p_20_21  1
    abs[20,21]  abs_m_20_21  1
    abs[20,21]  physical_G_upper_outward  1
    abs[20,21]  G_residual  -8.9285714285714283e-04
    abs[20,22]  abs_p_20_22  1
    abs[20,22]  abs_m_20_22  1
    abs[20,22]  physical_G_upper_outward  1
    abs[20,22]  G_residual  -8.9285714285714283e-04
    abs[20,23]  abs_p_20_23  1
    abs[20,23]  abs_m_20_23  1
    abs[20,23]  physical_G_upper_outward  1
    abs[20,23]  G_residual  -8.9285714285714283e-04
    abs[20,24]  abs_p_20_24  1
    abs[20,24]  abs_m_20_24  1
    abs[20,24]  physical_G_upper_outward  1
    abs[20,24]  G_residual  -8.9285714285714283e-04
    abs[20,25]  abs_p_20_25  1
    abs[20,25]  abs_m_20_25  1
    abs[20,25]  physical_G_upper_outward  1
    abs[20,25]  G_residual  -8.9285714285714283e-04
    abs[20,26]  abs_p_20_26  1
    abs[20,26]  abs_m_20_26  1
    abs[20,26]  physical_G_upper_outward  1
    abs[20,26]  G_residual  -8.9285714285714283e-04
    abs[20,27]  abs_p_20_27  1
    abs[20,27]  abs_m_20_27  1
    abs[20,27]  physical_G_upper_outward  1
    abs[20,27]  G_residual  -8.9285714285714283e-04
    abs[20,28]  abs_p_20_28  1
    abs[20,28]  abs_m_20_28  1
    abs[20,28]  physical_G_upper_outward  1
    abs[20,28]  G_residual  -8.9285714285714283e-04
    abs[20,29]  abs_p_20_29  1
    abs[20,29]  abs_m_20_29  1
    abs[20,29]  physical_G_upper_outward  1
    abs[20,29]  G_residual  -8.9285714285714283e-04
    abs[20,30]  abs_p_20_30  1
    abs[20,30]  abs_m_20_30  1
    abs[20,30]  physical_G_upper_outward  1
    abs[20,30]  G_residual  -8.9285714285714283e-04
    abs[20,31]  abs_p_20_31  1
    abs[20,31]  abs_m_20_31  1
    abs[20,31]  physical_G_upper_outward  1
    abs[20,31]  G_residual  -8.9285714285714283e-04
    abs[20,32]  abs_p_20_32  1
    abs[20,32]  abs_m_20_32  1
    abs[20,32]  physical_G_upper_outward  1
    abs[20,32]  G_residual  -8.9285714285714283e-04
    abs[20,33]  abs_p_20_33  1
    abs[20,33]  abs_m_20_33  1
    abs[20,33]  physical_G_upper_outward  1
    abs[20,33]  G_residual  -8.9285714285714283e-04
    abs[20,34]  abs_p_20_34  1
    abs[20,34]  abs_m_20_34  1
    abs[20,34]  physical_G_upper_outward  1
    abs[20,34]  G_residual  -8.9285714285714283e-04
    abs[20,35]  abs_p_20_35  1
    abs[20,35]  abs_m_20_35  1
    abs[20,35]  physical_G_upper_outward  1
    abs[20,35]  G_residual  -8.9285714285714283e-04
    abs[21,22]  abs_p_21_22  1
    abs[21,22]  abs_m_21_22  1
    abs[21,22]  physical_G_upper_outward  1
    abs[21,22]  G_residual  -8.9285714285714283e-04
    abs[21,23]  abs_p_21_23  1
    abs[21,23]  abs_m_21_23  1
    abs[21,23]  physical_G_upper_outward  1
    abs[21,23]  G_residual  -8.9285714285714283e-04
    abs[21,24]  abs_p_21_24  1
    abs[21,24]  abs_m_21_24  1
    abs[21,24]  physical_G_upper_outward  1
    abs[21,24]  G_residual  -8.9285714285714283e-04
    abs[21,25]  abs_p_21_25  1
    abs[21,25]  abs_m_21_25  1
    abs[21,25]  physical_G_upper_outward  1
    abs[21,25]  G_residual  -8.9285714285714283e-04
    abs[21,26]  abs_p_21_26  1
    abs[21,26]  abs_m_21_26  1
    abs[21,26]  physical_G_upper_outward  1
    abs[21,26]  G_residual  -8.9285714285714283e-04
    abs[21,27]  abs_p_21_27  1
    abs[21,27]  abs_m_21_27  1
    abs[21,27]  physical_G_upper_outward  1
    abs[21,27]  G_residual  -8.9285714285714283e-04
    abs[21,28]  abs_p_21_28  1
    abs[21,28]  abs_m_21_28  1
    abs[21,28]  physical_G_upper_outward  1
    abs[21,28]  G_residual  -8.9285714285714283e-04
    abs[21,29]  abs_p_21_29  1
    abs[21,29]  abs_m_21_29  1
    abs[21,29]  physical_G_upper_outward  1
    abs[21,29]  G_residual  -8.9285714285714283e-04
    abs[21,30]  abs_p_21_30  1
    abs[21,30]  abs_m_21_30  1
    abs[21,30]  physical_G_upper_outward  1
    abs[21,30]  G_residual  -8.9285714285714283e-04
    abs[21,31]  abs_p_21_31  1
    abs[21,31]  abs_m_21_31  1
    abs[21,31]  physical_G_upper_outward  1
    abs[21,31]  G_residual  -8.9285714285714283e-04
    abs[21,32]  abs_p_21_32  1
    abs[21,32]  abs_m_21_32  1
    abs[21,32]  physical_G_upper_outward  1
    abs[21,32]  G_residual  -8.9285714285714283e-04
    abs[21,33]  abs_p_21_33  1
    abs[21,33]  abs_m_21_33  1
    abs[21,33]  physical_G_upper_outward  1
    abs[21,33]  G_residual  -8.9285714285714283e-04
    abs[21,34]  abs_p_21_34  1
    abs[21,34]  abs_m_21_34  1
    abs[21,34]  physical_G_upper_outward  1
    abs[21,34]  G_residual  -8.9285714285714283e-04
    abs[21,35]  abs_p_21_35  1
    abs[21,35]  abs_m_21_35  1
    abs[21,35]  physical_G_upper_outward  1
    abs[21,35]  G_residual  -8.9285714285714283e-04
    abs[22,23]  abs_p_22_23  1
    abs[22,23]  abs_m_22_23  1
    abs[22,23]  physical_G_upper_outward  1
    abs[22,23]  G_residual  -8.9285714285714283e-04
    abs[22,24]  abs_p_22_24  1
    abs[22,24]  abs_m_22_24  1
    abs[22,24]  physical_G_upper_outward  1
    abs[22,24]  G_residual  -8.9285714285714283e-04
    abs[22,25]  abs_p_22_25  1
    abs[22,25]  abs_m_22_25  1
    abs[22,25]  physical_G_upper_outward  1
    abs[22,25]  G_residual  -8.9285714285714283e-04
    abs[22,26]  abs_p_22_26  1
    abs[22,26]  abs_m_22_26  1
    abs[22,26]  physical_G_upper_outward  1
    abs[22,26]  G_residual  -8.9285714285714283e-04
    abs[22,27]  abs_p_22_27  1
    abs[22,27]  abs_m_22_27  1
    abs[22,27]  physical_G_upper_outward  1
    abs[22,27]  G_residual  -8.9285714285714283e-04
    abs[22,28]  abs_p_22_28  1
    abs[22,28]  abs_m_22_28  1
    abs[22,28]  physical_G_upper_outward  1
    abs[22,28]  G_residual  -8.9285714285714283e-04
    abs[22,29]  abs_p_22_29  1
    abs[22,29]  abs_m_22_29  1
    abs[22,29]  physical_G_upper_outward  1
    abs[22,29]  G_residual  -8.9285714285714283e-04
    abs[22,30]  abs_p_22_30  1
    abs[22,30]  abs_m_22_30  1
    abs[22,30]  physical_G_upper_outward  1
    abs[22,30]  G_residual  -8.9285714285714283e-04
    abs[22,31]  abs_p_22_31  1
    abs[22,31]  abs_m_22_31  1
    abs[22,31]  physical_G_upper_outward  1
    abs[22,31]  G_residual  -8.9285714285714283e-04
    abs[22,32]  abs_p_22_32  1
    abs[22,32]  abs_m_22_32  1
    abs[22,32]  physical_G_upper_outward  1
    abs[22,32]  G_residual  -8.9285714285714283e-04
    abs[22,33]  abs_p_22_33  1
    abs[22,33]  abs_m_22_33  1
    abs[22,33]  physical_G_upper_outward  1
    abs[22,33]  G_residual  -8.9285714285714283e-04
    abs[22,34]  abs_p_22_34  1
    abs[22,34]  abs_m_22_34  1
    abs[22,34]  physical_G_upper_outward  1
    abs[22,34]  G_residual  -8.9285714285714283e-04
    abs[22,35]  abs_p_22_35  1
    abs[22,35]  abs_m_22_35  1
    abs[22,35]  physical_G_upper_outward  1
    abs[22,35]  G_residual  -8.9285714285714283e-04
    abs[23,24]  abs_p_23_24  1
    abs[23,24]  abs_m_23_24  1
    abs[23,24]  physical_G_upper_outward  1
    abs[23,24]  G_residual  -8.9285714285714283e-04
    abs[23,25]  abs_p_23_25  1
    abs[23,25]  abs_m_23_25  1
    abs[23,25]  physical_G_upper_outward  1
    abs[23,25]  G_residual  -8.9285714285714283e-04
    abs[23,26]  abs_p_23_26  1
    abs[23,26]  abs_m_23_26  1
    abs[23,26]  physical_G_upper_outward  1
    abs[23,26]  G_residual  -8.9285714285714283e-04
    abs[23,27]  abs_p_23_27  1
    abs[23,27]  abs_m_23_27  1
    abs[23,27]  physical_G_upper_outward  1
    abs[23,27]  G_residual  -8.9285714285714283e-04
    abs[23,28]  abs_p_23_28  1
    abs[23,28]  abs_m_23_28  1
    abs[23,28]  physical_G_upper_outward  1
    abs[23,28]  G_residual  -8.9285714285714283e-04
    abs[23,29]  abs_p_23_29  1
    abs[23,29]  abs_m_23_29  1
    abs[23,29]  physical_G_upper_outward  1
    abs[23,29]  G_residual  -8.9285714285714283e-04
    abs[23,30]  abs_p_23_30  1
    abs[23,30]  abs_m_23_30  1
    abs[23,30]  physical_G_upper_outward  1
    abs[23,30]  G_residual  -8.9285714285714283e-04
    abs[23,31]  abs_p_23_31  1
    abs[23,31]  abs_m_23_31  1
    abs[23,31]  physical_G_upper_outward  1
    abs[23,31]  G_residual  -8.9285714285714283e-04
    abs[23,32]  abs_p_23_32  1
    abs[23,32]  abs_m_23_32  1
    abs[23,32]  physical_G_upper_outward  1
    abs[23,32]  G_residual  -8.9285714285714283e-04
    abs[23,33]  abs_p_23_33  1
    abs[23,33]  abs_m_23_33  1
    abs[23,33]  physical_G_upper_outward  1
    abs[23,33]  G_residual  -8.9285714285714283e-04
    abs[23,34]  abs_p_23_34  1
    abs[23,34]  abs_m_23_34  1
    abs[23,34]  physical_G_upper_outward  1
    abs[23,34]  G_residual  -8.9285714285714283e-04
    abs[23,35]  abs_p_23_35  1
    abs[23,35]  abs_m_23_35  1
    abs[23,35]  physical_G_upper_outward  1
    abs[23,35]  G_residual  -8.9285714285714283e-04
    abs[24,25]  abs_p_24_25  1
    abs[24,25]  abs_m_24_25  1
    abs[24,25]  physical_G_upper_outward  1
    abs[24,25]  G_residual  -8.9285714285714283e-04
    abs[24,26]  abs_p_24_26  1
    abs[24,26]  abs_m_24_26  1
    abs[24,26]  physical_G_upper_outward  1
    abs[24,26]  G_residual  -8.9285714285714283e-04
    abs[24,27]  abs_p_24_27  1
    abs[24,27]  abs_m_24_27  1
    abs[24,27]  physical_G_upper_outward  1
    abs[24,27]  G_residual  -8.9285714285714283e-04
    abs[24,28]  abs_p_24_28  1
    abs[24,28]  abs_m_24_28  1
    abs[24,28]  physical_G_upper_outward  1
    abs[24,28]  G_residual  -8.9285714285714283e-04
    abs[24,29]  abs_p_24_29  1
    abs[24,29]  abs_m_24_29  1
    abs[24,29]  physical_G_upper_outward  1
    abs[24,29]  G_residual  -8.9285714285714283e-04
    abs[24,30]  abs_p_24_30  1
    abs[24,30]  abs_m_24_30  1
    abs[24,30]  physical_G_upper_outward  1
    abs[24,30]  G_residual  -8.9285714285714283e-04
    abs[24,31]  abs_p_24_31  1
    abs[24,31]  abs_m_24_31  1
    abs[24,31]  physical_G_upper_outward  1
    abs[24,31]  G_residual  -8.9285714285714283e-04
    abs[24,32]  abs_p_24_32  1
    abs[24,32]  abs_m_24_32  1
    abs[24,32]  physical_G_upper_outward  1
    abs[24,32]  G_residual  -8.9285714285714283e-04
    abs[24,33]  abs_p_24_33  1
    abs[24,33]  abs_m_24_33  1
    abs[24,33]  physical_G_upper_outward  1
    abs[24,33]  G_residual  -8.9285714285714283e-04
    abs[24,34]  abs_p_24_34  1
    abs[24,34]  abs_m_24_34  1
    abs[24,34]  physical_G_upper_outward  1
    abs[24,34]  G_residual  -8.9285714285714283e-04
    abs[24,35]  abs_p_24_35  1
    abs[24,35]  abs_m_24_35  1
    abs[24,35]  physical_G_upper_outward  1
    abs[24,35]  G_residual  -8.9285714285714283e-04
    abs[25,26]  abs_p_25_26  1
    abs[25,26]  abs_m_25_26  1
    abs[25,26]  physical_G_upper_outward  1
    abs[25,26]  G_residual  -8.9285714285714283e-04
    abs[25,27]  abs_p_25_27  1
    abs[25,27]  abs_m_25_27  1
    abs[25,27]  physical_G_upper_outward  1
    abs[25,27]  G_residual  -8.9285714285714283e-04
    abs[25,28]  abs_p_25_28  1
    abs[25,28]  abs_m_25_28  1
    abs[25,28]  physical_G_upper_outward  1
    abs[25,28]  G_residual  -8.9285714285714283e-04
    abs[25,29]  abs_p_25_29  1
    abs[25,29]  abs_m_25_29  1
    abs[25,29]  physical_G_upper_outward  1
    abs[25,29]  G_residual  -8.9285714285714283e-04
    abs[25,30]  abs_p_25_30  1
    abs[25,30]  abs_m_25_30  1
    abs[25,30]  physical_G_upper_outward  1
    abs[25,30]  G_residual  -8.9285714285714283e-04
    abs[25,31]  abs_p_25_31  1
    abs[25,31]  abs_m_25_31  1
    abs[25,31]  physical_G_upper_outward  1
    abs[25,31]  G_residual  -8.9285714285714283e-04
    abs[25,32]  abs_p_25_32  1
    abs[25,32]  abs_m_25_32  1
    abs[25,32]  physical_G_upper_outward  1
    abs[25,32]  G_residual  -8.9285714285714283e-04
    abs[25,33]  abs_p_25_33  1
    abs[25,33]  abs_m_25_33  1
    abs[25,33]  physical_G_upper_outward  1
    abs[25,33]  G_residual  -8.9285714285714283e-04
    abs[25,34]  abs_p_25_34  1
    abs[25,34]  abs_m_25_34  1
    abs[25,34]  physical_G_upper_outward  1
    abs[25,34]  G_residual  -8.9285714285714283e-04
    abs[25,35]  abs_p_25_35  1
    abs[25,35]  abs_m_25_35  1
    abs[25,35]  physical_G_upper_outward  1
    abs[25,35]  G_residual  -8.9285714285714283e-04
    abs[26,27]  abs_p_26_27  1
    abs[26,27]  abs_m_26_27  1
    abs[26,27]  physical_G_upper_outward  1
    abs[26,27]  G_residual  -8.9285714285714283e-04
    abs[26,28]  abs_p_26_28  1
    abs[26,28]  abs_m_26_28  1
    abs[26,28]  physical_G_upper_outward  1
    abs[26,28]  G_residual  -8.9285714285714283e-04
    abs[26,29]  abs_p_26_29  1
    abs[26,29]  abs_m_26_29  1
    abs[26,29]  physical_G_upper_outward  1
    abs[26,29]  G_residual  -8.9285714285714283e-04
    abs[26,30]  abs_p_26_30  1
    abs[26,30]  abs_m_26_30  1
    abs[26,30]  physical_G_upper_outward  1
    abs[26,30]  G_residual  -8.9285714285714283e-04
    abs[26,31]  abs_p_26_31  1
    abs[26,31]  abs_m_26_31  1
    abs[26,31]  physical_G_upper_outward  1
    abs[26,31]  G_residual  -8.9285714285714283e-04
    abs[26,32]  abs_p_26_32  1
    abs[26,32]  abs_m_26_32  1
    abs[26,32]  physical_G_upper_outward  1
    abs[26,32]  G_residual  -8.9285714285714283e-04
    abs[26,33]  abs_p_26_33  1
    abs[26,33]  abs_m_26_33  1
    abs[26,33]  physical_G_upper_outward  1
    abs[26,33]  G_residual  -8.9285714285714283e-04
    abs[26,34]  abs_p_26_34  1
    abs[26,34]  abs_m_26_34  1
    abs[26,34]  physical_G_upper_outward  1
    abs[26,34]  G_residual  -8.9285714285714283e-04
    abs[26,35]  abs_p_26_35  1
    abs[26,35]  abs_m_26_35  1
    abs[26,35]  physical_G_upper_outward  1
    abs[26,35]  G_residual  -8.9285714285714283e-04
    abs[27,28]  abs_p_27_28  1
    abs[27,28]  abs_m_27_28  1
    abs[27,28]  physical_G_upper_outward  1
    abs[27,28]  G_residual  -8.9285714285714283e-04
    abs[27,29]  abs_p_27_29  1
    abs[27,29]  abs_m_27_29  1
    abs[27,29]  physical_G_upper_outward  1
    abs[27,29]  G_residual  -8.9285714285714283e-04
    abs[27,30]  abs_p_27_30  1
    abs[27,30]  abs_m_27_30  1
    abs[27,30]  physical_G_upper_outward  1
    abs[27,30]  G_residual  -8.9285714285714283e-04
    abs[27,31]  abs_p_27_31  1
    abs[27,31]  abs_m_27_31  1
    abs[27,31]  physical_G_upper_outward  1
    abs[27,31]  G_residual  -8.9285714285714283e-04
    abs[27,32]  abs_p_27_32  1
    abs[27,32]  abs_m_27_32  1
    abs[27,32]  physical_G_upper_outward  1
    abs[27,32]  G_residual  -8.9285714285714283e-04
    abs[27,33]  abs_p_27_33  1
    abs[27,33]  abs_m_27_33  1
    abs[27,33]  physical_G_upper_outward  1
    abs[27,33]  G_residual  -8.9285714285714283e-04
    abs[27,34]  abs_p_27_34  1
    abs[27,34]  abs_m_27_34  1
    abs[27,34]  physical_G_upper_outward  1
    abs[27,34]  G_residual  -8.9285714285714283e-04
    abs[27,35]  abs_p_27_35  1
    abs[27,35]  abs_m_27_35  1
    abs[27,35]  physical_G_upper_outward  1
    abs[27,35]  G_residual  -8.9285714285714283e-04
    abs[28,29]  abs_p_28_29  1
    abs[28,29]  abs_m_28_29  1
    abs[28,29]  physical_G_upper_outward  1
    abs[28,29]  G_residual  -8.9285714285714283e-04
    abs[28,30]  abs_p_28_30  1
    abs[28,30]  abs_m_28_30  1
    abs[28,30]  physical_G_upper_outward  1
    abs[28,30]  G_residual  -8.9285714285714283e-04
    abs[28,31]  abs_p_28_31  1
    abs[28,31]  abs_m_28_31  1
    abs[28,31]  physical_G_upper_outward  1
    abs[28,31]  G_residual  -8.9285714285714283e-04
    abs[28,32]  abs_p_28_32  1
    abs[28,32]  abs_m_28_32  1
    abs[28,32]  physical_G_upper_outward  1
    abs[28,32]  G_residual  -8.9285714285714283e-04
    abs[28,33]  abs_p_28_33  1
    abs[28,33]  abs_m_28_33  1
    abs[28,33]  physical_G_upper_outward  1
    abs[28,33]  G_residual  -8.9285714285714283e-04
    abs[28,34]  abs_p_28_34  1
    abs[28,34]  abs_m_28_34  1
    abs[28,34]  physical_G_upper_outward  1
    abs[28,34]  G_residual  -8.9285714285714283e-04
    abs[28,35]  abs_p_28_35  1
    abs[28,35]  abs_m_28_35  1
    abs[28,35]  physical_G_upper_outward  1
    abs[28,35]  G_residual  -8.9285714285714283e-04
    abs[29,30]  abs_p_29_30  1
    abs[29,30]  abs_m_29_30  1
    abs[29,30]  physical_G_upper_outward  1
    abs[29,30]  G_residual  -8.9285714285714283e-04
    abs[29,31]  abs_p_29_31  1
    abs[29,31]  abs_m_29_31  1
    abs[29,31]  physical_G_upper_outward  1
    abs[29,31]  G_residual  -8.9285714285714283e-04
    abs[29,32]  abs_p_29_32  1
    abs[29,32]  abs_m_29_32  1
    abs[29,32]  physical_G_upper_outward  1
    abs[29,32]  G_residual  -8.9285714285714283e-04
    abs[29,33]  abs_p_29_33  1
    abs[29,33]  abs_m_29_33  1
    abs[29,33]  physical_G_upper_outward  1
    abs[29,33]  G_residual  -8.9285714285714283e-04
    abs[29,34]  abs_p_29_34  1
    abs[29,34]  abs_m_29_34  1
    abs[29,34]  physical_G_upper_outward  1
    abs[29,34]  G_residual  -8.9285714285714283e-04
    abs[29,35]  abs_p_29_35  1
    abs[29,35]  abs_m_29_35  1
    abs[29,35]  physical_G_upper_outward  1
    abs[29,35]  G_residual  -8.9285714285714283e-04
    abs[30,31]  abs_p_30_31  1
    abs[30,31]  abs_m_30_31  1
    abs[30,31]  physical_G_upper_outward  1
    abs[30,31]  G_residual  -8.9285714285714283e-04
    abs[30,32]  abs_p_30_32  1
    abs[30,32]  abs_m_30_32  1
    abs[30,32]  physical_G_upper_outward  1
    abs[30,32]  G_residual  -8.9285714285714283e-04
    abs[30,33]  abs_p_30_33  1
    abs[30,33]  abs_m_30_33  1
    abs[30,33]  physical_G_upper_outward  1
    abs[30,33]  G_residual  -8.9285714285714283e-04
    abs[30,34]  abs_p_30_34  1
    abs[30,34]  abs_m_30_34  1
    abs[30,34]  physical_G_upper_outward  1
    abs[30,34]  G_residual  -8.9285714285714283e-04
    abs[30,35]  abs_p_30_35  1
    abs[30,35]  abs_m_30_35  1
    abs[30,35]  physical_G_upper_outward  1
    abs[30,35]  G_residual  -8.9285714285714283e-04
    abs[31,32]  abs_p_31_32  1
    abs[31,32]  abs_m_31_32  1
    abs[31,32]  physical_G_upper_outward  1
    abs[31,32]  G_residual  -8.9285714285714283e-04
    abs[31,33]  abs_p_31_33  1
    abs[31,33]  abs_m_31_33  1
    abs[31,33]  physical_G_upper_outward  1
    abs[31,33]  G_residual  -8.9285714285714283e-04
    abs[31,34]  abs_p_31_34  1
    abs[31,34]  abs_m_31_34  1
    abs[31,34]  physical_G_upper_outward  1
    abs[31,34]  G_residual  -8.9285714285714283e-04
    abs[31,35]  abs_p_31_35  1
    abs[31,35]  abs_m_31_35  1
    abs[31,35]  physical_G_upper_outward  1
    abs[31,35]  G_residual  -8.9285714285714283e-04
    abs[32,33]  abs_p_32_33  1
    abs[32,33]  abs_m_32_33  1
    abs[32,33]  physical_G_upper_outward  1
    abs[32,33]  G_residual  -8.9285714285714283e-04
    abs[32,34]  abs_p_32_34  1
    abs[32,34]  abs_m_32_34  1
    abs[32,34]  physical_G_upper_outward  1
    abs[32,34]  G_residual  -8.9285714285714283e-04
    abs[32,35]  abs_p_32_35  1
    abs[32,35]  abs_m_32_35  1
    abs[32,35]  physical_G_upper_outward  1
    abs[32,35]  G_residual  -8.9285714285714283e-04
    abs[33,34]  abs_p_33_34  1
    abs[33,34]  abs_m_33_34  1
    abs[33,34]  physical_G_upper_outward  1
    abs[33,34]  G_residual  -8.9285714285714283e-04
    abs[33,35]  abs_p_33_35  1
    abs[33,35]  abs_m_33_35  1
    abs[33,35]  physical_G_upper_outward  1
    abs[33,35]  G_residual  -8.9285714285714283e-04
    abs[34,35]  abs_p_34_35  1
    abs[34,35]  abs_m_34_35  1
    abs[34,35]  physical_G_upper_outward  1
    abs[34,35]  G_residual  -8.9285714285714283e-04
    residual_scaled  OBJ       1
    residual_scaled  floor_residual  1
    residual_scaled  G_residual  1
    hard_cost_D  hard_cost_D_definition  1
    hard_cost_D  tight_DP_cost_product_ll  -8.61111111111111
    hard_cost_D  tight_DP_cost_product_uu  -39.6
    hard_cost_D  tight_DP_cost_product_ul  -39.6
    hard_cost_D  tight_DP_cost_product_lu  -8.61111111111111
    hard_cost_W  hard_cost_W_definition  1
    hard_cost_W  tight_DP_cost_product_ll  1
    hard_cost_W  tight_DP_cost_product_uu  1
    hard_cost_W  tight_DP_cost_product_ul  1
    hard_cost_W  tight_DP_cost_product_lu  1
RHS
    RHS1      onehot_1  1
    RHS1      product_Su_1_0  -39.6
    RHS1      product_Sl_1_0  -8.61111111111111
    RHS1      product_Su_1_1  -39.6
    RHS1      product_Sl_1_1  -8.61111111111111
    RHS1      product_Su_1_2  -39.6
    RHS1      product_Sl_1_2  -8.61111111111111
    RHS1      product_Su_1_3  -39.6
    RHS1      product_Sl_1_3  -8.61111111111111
    RHS1      product_Su_1_4  -39.6
    RHS1      product_Sl_1_4  -8.61111111111111
    RHS1      product_Su_1_5  -39.6
    RHS1      product_Sl_1_5  -8.61111111111111
    RHS1      product_Su_1_6  -39.6
    RHS1      product_Sl_1_6  -8.61111111111111
    RHS1      product_Su_1_7  -39.6
    RHS1      product_Sl_1_7  -8.61111111111111
    RHS1      product_Su_1_8  -39.6
    RHS1      product_Sl_1_8  -8.61111111111111
    RHS1      onehot_2  1
    RHS1      product_Su_2_0  -39.6
    RHS1      product_Sl_2_0  -8.61111111111111
    RHS1      product_Su_2_1  -39.6
    RHS1      product_Sl_2_1  -8.61111111111111
    RHS1      product_Su_2_2  -39.6
    RHS1      product_Sl_2_2  -8.61111111111111
    RHS1      product_Su_2_3  -39.6
    RHS1      product_Sl_2_3  -8.61111111111111
    RHS1      product_Su_2_4  -39.6
    RHS1      product_Sl_2_4  -8.61111111111111
    RHS1      product_Su_2_5  -39.6
    RHS1      product_Sl_2_5  -8.61111111111111
    RHS1      product_Su_2_6  -39.6
    RHS1      product_Sl_2_6  -8.61111111111111
    RHS1      product_Su_2_7  -39.6
    RHS1      product_Sl_2_7  -8.61111111111111
    RHS1      product_Su_2_8  -39.6
    RHS1      product_Sl_2_8  -8.61111111111111
    RHS1      product_Su_2_9  -39.6
    RHS1      product_Sl_2_9  -8.61111111111111
    RHS1      product_Su_2_10  -39.6
    RHS1      product_Sl_2_10  -8.61111111111111
    RHS1      product_Su_2_11  -39.6
    RHS1      product_Sl_2_11  -8.61111111111111
    RHS1      product_Su_2_12  -39.6
    RHS1      product_Sl_2_12  -8.61111111111111
    RHS1      product_Su_2_13  -39.6
    RHS1      product_Sl_2_13  -8.61111111111111
    RHS1      product_Su_2_14  -39.6
    RHS1      product_Sl_2_14  -8.61111111111111
    RHS1      product_Su_2_15  -39.6
    RHS1      product_Sl_2_15  -8.61111111111111
    RHS1      onehot_3  1
    RHS1      product_Su_3_0  -39.6
    RHS1      product_Sl_3_0  -8.61111111111111
    RHS1      product_Su_3_1  -39.6
    RHS1      product_Sl_3_1  -8.61111111111111
    RHS1      product_Su_3_2  -39.6
    RHS1      product_Sl_3_2  -8.61111111111111
    RHS1      product_Su_3_3  -39.6
    RHS1      product_Sl_3_3  -8.61111111111111
    RHS1      product_Su_3_4  -39.6
    RHS1      product_Sl_3_4  -8.61111111111111
    RHS1      product_Su_3_5  -39.6
    RHS1      product_Sl_3_5  -8.61111111111111
    RHS1      product_Su_3_6  -39.6
    RHS1      product_Sl_3_6  -8.61111111111111
    RHS1      product_Su_3_7  -39.6
    RHS1      product_Sl_3_7  -8.61111111111111
    RHS1      product_Su_3_8  -39.6
    RHS1      product_Sl_3_8  -8.61111111111111
    RHS1      product_Su_3_9  -39.6
    RHS1      product_Sl_3_9  -8.61111111111111
    RHS1      product_Su_3_10  -39.6
    RHS1      product_Sl_3_10  -8.61111111111111
    RHS1      product_Su_3_11  -39.6
    RHS1      product_Sl_3_11  -8.61111111111111
    RHS1      product_Su_3_12  -39.6
    RHS1      product_Sl_3_12  -8.61111111111111
    RHS1      onehot_4  1
    RHS1      product_Su_4_0  -39.6
    RHS1      product_Sl_4_0  -8.61111111111111
    RHS1      product_Su_4_1  -39.6
    RHS1      product_Sl_4_1  -8.61111111111111
    RHS1      product_Su_4_2  -39.6
    RHS1      product_Sl_4_2  -8.61111111111111
    RHS1      product_Su_4_3  -39.6
    RHS1      product_Sl_4_3  -8.61111111111111
    RHS1      product_Su_4_4  -39.6
    RHS1      product_Sl_4_4  -8.61111111111111
    RHS1      product_Su_4_5  -39.6
    RHS1      product_Sl_4_5  -8.61111111111111
    RHS1      product_Su_4_6  -39.6
    RHS1      product_Sl_4_6  -8.61111111111111
    RHS1      product_Su_4_7  -39.6
    RHS1      product_Sl_4_7  -8.61111111111111
    RHS1      product_Su_4_8  -39.6
    RHS1      product_Sl_4_8  -8.61111111111111
    RHS1      product_Su_4_9  -39.6
    RHS1      product_Sl_4_9  -8.61111111111111
    RHS1      product_Su_4_10  -39.6
    RHS1      product_Sl_4_10  -8.61111111111111
    RHS1      product_Su_4_11  -39.6
    RHS1      product_Sl_4_11  -8.61111111111111
    RHS1      product_Su_4_12  -39.6
    RHS1      product_Sl_4_12  -8.61111111111111
    RHS1      product_Su_4_13  -39.6
    RHS1      product_Sl_4_13  -8.61111111111111
    RHS1      product_Su_4_14  -39.6
    RHS1      product_Sl_4_14  -8.61111111111111
    RHS1      product_Su_4_15  -39.6
    RHS1      product_Sl_4_15  -8.61111111111111
    RHS1      onehot_5  1
    RHS1      product_Su_5_0  -39.6
    RHS1      product_Sl_5_0  -8.61111111111111
    RHS1      product_Su_5_1  -39.6
    RHS1      product_Sl_5_1  -8.61111111111111
    RHS1      product_Su_5_2  -39.6
    RHS1      product_Sl_5_2  -8.61111111111111
    RHS1      product_Su_5_3  -39.6
    RHS1      product_Sl_5_3  -8.61111111111111
    RHS1      product_Su_5_4  -39.6
    RHS1      product_Sl_5_4  -8.61111111111111
    RHS1      product_Su_5_5  -39.6
    RHS1      product_Sl_5_5  -8.61111111111111
    RHS1      product_Su_5_6  -39.6
    RHS1      product_Sl_5_6  -8.61111111111111
    RHS1      product_Su_5_7  -39.6
    RHS1      product_Sl_5_7  -8.61111111111111
    RHS1      product_Su_5_8  -39.6
    RHS1      product_Sl_5_8  -8.61111111111111
    RHS1      product_Su_5_9  -39.6
    RHS1      product_Sl_5_9  -8.61111111111111
    RHS1      product_Su_5_10  -39.6
    RHS1      product_Sl_5_10  -8.61111111111111
    RHS1      product_Su_5_11  -39.6
    RHS1      product_Sl_5_11  -8.61111111111111
    RHS1      product_Su_5_12  -39.6
    RHS1      product_Sl_5_12  -8.61111111111111
    RHS1      product_Su_5_13  -39.6
    RHS1      product_Sl_5_13  -8.61111111111111
    RHS1      product_Su_5_14  -39.6
    RHS1      product_Sl_5_14  -8.61111111111111
    RHS1      product_Su_5_15  -39.6
    RHS1      product_Sl_5_15  -8.61111111111111
    RHS1      onehot_6  1
    RHS1      product_Su_6_0  -39.6
    RHS1      product_Sl_6_0  -8.61111111111111
    RHS1      product_Su_6_1  -39.6
    RHS1      product_Sl_6_1  -8.61111111111111
    RHS1      product_Su_6_2  -39.6
    RHS1      product_Sl_6_2  -8.61111111111111
    RHS1      product_Su_6_3  -39.6
    RHS1      product_Sl_6_3  -8.61111111111111
    RHS1      product_Su_6_4  -39.6
    RHS1      product_Sl_6_4  -8.61111111111111
    RHS1      product_Su_6_5  -39.6
    RHS1      product_Sl_6_5  -8.61111111111111
    RHS1      product_Su_6_6  -39.6
    RHS1      product_Sl_6_6  -8.61111111111111
    RHS1      product_Su_6_7  -39.6
    RHS1      product_Sl_6_7  -8.61111111111111
    RHS1      product_Su_6_8  -39.6
    RHS1      product_Sl_6_8  -8.61111111111111
    RHS1      onehot_7  1
    RHS1      product_Su_7_0  -39.6
    RHS1      product_Sl_7_0  -8.61111111111111
    RHS1      product_Su_7_1  -39.6
    RHS1      product_Sl_7_1  -8.61111111111111
    RHS1      product_Su_7_2  -39.6
    RHS1      product_Sl_7_2  -8.61111111111111
    RHS1      product_Su_7_3  -39.6
    RHS1      product_Sl_7_3  -8.61111111111111
    RHS1      product_Su_7_4  -39.6
    RHS1      product_Sl_7_4  -8.61111111111111
    RHS1      product_Su_7_5  -39.6
    RHS1      product_Sl_7_5  -8.61111111111111
    RHS1      product_Su_7_6  -39.6
    RHS1      product_Sl_7_6  -8.61111111111111
    RHS1      product_Su_7_7  -39.6
    RHS1      product_Sl_7_7  -8.61111111111111
    RHS1      product_Su_7_8  -39.6
    RHS1      product_Sl_7_8  -8.61111111111111
    RHS1      product_Su_7_9  -39.6
    RHS1      product_Sl_7_9  -8.61111111111111
    RHS1      product_Su_7_10  -39.6
    RHS1      product_Sl_7_10  -8.61111111111111
    RHS1      product_Su_7_11  -39.6
    RHS1      product_Sl_7_11  -8.61111111111111
    RHS1      product_Su_7_12  -39.6
    RHS1      product_Sl_7_12  -8.61111111111111
    RHS1      product_Su_7_13  -39.6
    RHS1      product_Sl_7_13  -8.61111111111111
    RHS1      product_Su_7_14  -39.6
    RHS1      product_Sl_7_14  -8.61111111111111
    RHS1      product_Su_7_15  -39.6
    RHS1      product_Sl_7_15  -8.61111111111111
    RHS1      onehot_8  1
    RHS1      product_Su_8_0  -39.6
    RHS1      product_Sl_8_0  -8.61111111111111
    RHS1      product_Su_8_1  -39.6
    RHS1      product_Sl_8_1  -8.61111111111111
    RHS1      product_Su_8_2  -39.6
    RHS1      product_Sl_8_2  -8.61111111111111
    RHS1      product_Su_8_3  -39.6
    RHS1      product_Sl_8_3  -8.61111111111111
    RHS1      product_Su_8_4  -39.6
    RHS1      product_Sl_8_4  -8.61111111111111
    RHS1      product_Su_8_5  -39.6
    RHS1      product_Sl_8_5  -8.61111111111111
    RHS1      product_Su_8_6  -39.6
    RHS1      product_Sl_8_6  -8.61111111111111
    RHS1      product_Su_8_7  -39.6
    RHS1      product_Sl_8_7  -8.61111111111111
    RHS1      product_Su_8_8  -39.6
    RHS1      product_Sl_8_8  -8.61111111111111
    RHS1      product_Su_8_9  -39.6
    RHS1      product_Sl_8_9  -8.61111111111111
    RHS1      product_Su_8_10  -39.6
    RHS1      product_Sl_8_10  -8.61111111111111
    RHS1      product_Su_8_11  -39.6
    RHS1      product_Sl_8_11  -8.61111111111111
    RHS1      product_Su_8_12  -39.6
    RHS1      product_Sl_8_12  -8.61111111111111
    RHS1      onehot_9  1
    RHS1      product_Su_9_0  -39.6
    RHS1      product_Sl_9_0  -8.61111111111111
    RHS1      product_Su_9_1  -39.6
    RHS1      product_Sl_9_1  -8.61111111111111
    RHS1      product_Su_9_2  -39.6
    RHS1      product_Sl_9_2  -8.61111111111111
    RHS1      product_Su_9_3  -39.6
    RHS1      product_Sl_9_3  -8.61111111111111
    RHS1      product_Su_9_4  -39.6
    RHS1      product_Sl_9_4  -8.61111111111111
    RHS1      product_Su_9_5  -39.6
    RHS1      product_Sl_9_5  -8.61111111111111
    RHS1      product_Su_9_6  -39.6
    RHS1      product_Sl_9_6  -8.61111111111111
    RHS1      product_Su_9_7  -39.6
    RHS1      product_Sl_9_7  -8.61111111111111
    RHS1      product_Su_9_8  -39.6
    RHS1      product_Sl_9_8  -8.61111111111111
    RHS1      product_Su_9_9  -39.6
    RHS1      product_Sl_9_9  -8.61111111111111
    RHS1      product_Su_9_10  -39.6
    RHS1      product_Sl_9_10  -8.61111111111111
    RHS1      onehot_10  1
    RHS1      product_Su_10_0  -39.6
    RHS1      product_Sl_10_0  -8.61111111111111
    RHS1      product_Su_10_1  -39.6
    RHS1      product_Sl_10_1  -8.61111111111111
    RHS1      product_Su_10_2  -39.6
    RHS1      product_Sl_10_2  -8.61111111111111
    RHS1      product_Su_10_3  -39.6
    RHS1      product_Sl_10_3  -8.61111111111111
    RHS1      product_Su_10_4  -39.6
    RHS1      product_Sl_10_4  -8.61111111111111
    RHS1      product_Su_10_5  -39.6
    RHS1      product_Sl_10_5  -8.61111111111111
    RHS1      product_Su_10_6  -39.6
    RHS1      product_Sl_10_6  -8.61111111111111
    RHS1      onehot_11  1
    RHS1      product_Su_11_0  -39.6
    RHS1      product_Sl_11_0  -8.61111111111111
    RHS1      product_Su_11_1  -39.6
    RHS1      product_Sl_11_1  -8.61111111111111
    RHS1      product_Su_11_2  -39.6
    RHS1      product_Sl_11_2  -8.61111111111111
    RHS1      product_Su_11_3  -39.6
    RHS1      product_Sl_11_3  -8.61111111111111
    RHS1      product_Su_11_4  -39.6
    RHS1      product_Sl_11_4  -8.61111111111111
    RHS1      product_Su_11_5  -39.6
    RHS1      product_Sl_11_5  -8.61111111111111
    RHS1      product_Su_11_6  -39.6
    RHS1      product_Sl_11_6  -8.61111111111111
    RHS1      product_Su_11_7  -39.6
    RHS1      product_Sl_11_7  -8.61111111111111
    RHS1      product_Su_11_8  -39.6
    RHS1      product_Sl_11_8  -8.61111111111111
    RHS1      product_Su_11_9  -39.6
    RHS1      product_Sl_11_9  -8.61111111111111
    RHS1      product_Su_11_10  -39.6
    RHS1      product_Sl_11_10  -8.61111111111111
    RHS1      onehot_12  1
    RHS1      product_Su_12_0  -39.6
    RHS1      product_Sl_12_0  -8.61111111111111
    RHS1      product_Su_12_1  -39.6
    RHS1      product_Sl_12_1  -8.61111111111111
    RHS1      product_Su_12_2  -39.6
    RHS1      product_Sl_12_2  -8.61111111111111
    RHS1      product_Su_12_3  -39.6
    RHS1      product_Sl_12_3  -8.61111111111111
    RHS1      product_Su_12_4  -39.6
    RHS1      product_Sl_12_4  -8.61111111111111
    RHS1      product_Su_12_5  -39.6
    RHS1      product_Sl_12_5  -8.61111111111111
    RHS1      product_Su_12_6  -39.6
    RHS1      product_Sl_12_6  -8.61111111111111
    RHS1      product_Su_12_7  -39.6
    RHS1      product_Sl_12_7  -8.61111111111111
    RHS1      product_Su_12_8  -39.6
    RHS1      product_Sl_12_8  -8.61111111111111
    RHS1      product_Su_12_9  -39.6
    RHS1      product_Sl_12_9  -8.61111111111111
    RHS1      product_Su_12_10  -39.6
    RHS1      product_Sl_12_10  -8.61111111111111
    RHS1      product_Su_12_11  -39.6
    RHS1      product_Sl_12_11  -8.61111111111111
    RHS1      product_Su_12_12  -39.6
    RHS1      product_Sl_12_12  -8.61111111111111
    RHS1      onehot_13  1
    RHS1      product_Su_13_0  -39.6
    RHS1      product_Sl_13_0  -8.61111111111111
    RHS1      product_Su_13_1  -39.6
    RHS1      product_Sl_13_1  -8.61111111111111
    RHS1      product_Su_13_2  -39.6
    RHS1      product_Sl_13_2  -8.61111111111111
    RHS1      product_Su_13_3  -39.6
    RHS1      product_Sl_13_3  -8.61111111111111
    RHS1      product_Su_13_4  -39.6
    RHS1      product_Sl_13_4  -8.61111111111111
    RHS1      product_Su_13_5  -39.6
    RHS1      product_Sl_13_5  -8.61111111111111
    RHS1      product_Su_13_6  -39.6
    RHS1      product_Sl_13_6  -8.61111111111111
    RHS1      product_Su_13_7  -39.6
    RHS1      product_Sl_13_7  -8.61111111111111
    RHS1      product_Su_13_8  -39.6
    RHS1      product_Sl_13_8  -8.61111111111111
    RHS1      onehot_14  1
    RHS1      product_Su_14_0  -39.6
    RHS1      product_Sl_14_0  -8.61111111111111
    RHS1      product_Su_14_1  -39.6
    RHS1      product_Sl_14_1  -8.61111111111111
    RHS1      product_Su_14_2  -39.6
    RHS1      product_Sl_14_2  -8.61111111111111
    RHS1      product_Su_14_3  -39.6
    RHS1      product_Sl_14_3  -8.61111111111111
    RHS1      product_Su_14_4  -39.6
    RHS1      product_Sl_14_4  -8.61111111111111
    RHS1      product_Su_14_5  -39.6
    RHS1      product_Sl_14_5  -8.61111111111111
    RHS1      product_Su_14_6  -39.6
    RHS1      product_Sl_14_6  -8.61111111111111
    RHS1      product_Su_14_7  -39.6
    RHS1      product_Sl_14_7  -8.61111111111111
    RHS1      product_Su_14_8  -39.6
    RHS1      product_Sl_14_8  -8.61111111111111
    RHS1      onehot_15  1
    RHS1      product_Su_15_0  -39.6
    RHS1      product_Sl_15_0  -8.61111111111111
    RHS1      product_Su_15_1  -39.6
    RHS1      product_Sl_15_1  -8.61111111111111
    RHS1      product_Su_15_2  -39.6
    RHS1      product_Sl_15_2  -8.61111111111111
    RHS1      product_Su_15_3  -39.6
    RHS1      product_Sl_15_3  -8.61111111111111
    RHS1      product_Su_15_4  -39.6
    RHS1      product_Sl_15_4  -8.61111111111111
    RHS1      product_Su_15_5  -39.6
    RHS1      product_Sl_15_5  -8.61111111111111
    RHS1      product_Su_15_6  -39.6
    RHS1      product_Sl_15_6  -8.61111111111111
    RHS1      product_Su_15_7  -39.6
    RHS1      product_Sl_15_7  -8.61111111111111
    RHS1      product_Su_15_8  -39.6
    RHS1      product_Sl_15_8  -8.61111111111111
    RHS1      onehot_16  1
    RHS1      product_Su_16_0  -39.6
    RHS1      product_Sl_16_0  -8.61111111111111
    RHS1      product_Su_16_1  -39.6
    RHS1      product_Sl_16_1  -8.61111111111111
    RHS1      product_Su_16_2  -39.6
    RHS1      product_Sl_16_2  -8.61111111111111
    RHS1      product_Su_16_3  -39.6
    RHS1      product_Sl_16_3  -8.61111111111111
    RHS1      product_Su_16_4  -39.6
    RHS1      product_Sl_16_4  -8.61111111111111
    RHS1      product_Su_16_5  -39.6
    RHS1      product_Sl_16_5  -8.61111111111111
    RHS1      product_Su_16_6  -39.6
    RHS1      product_Sl_16_6  -8.61111111111111
    RHS1      product_Su_16_7  -39.6
    RHS1      product_Sl_16_7  -8.61111111111111
    RHS1      product_Su_16_8  -39.6
    RHS1      product_Sl_16_8  -8.61111111111111
    RHS1      product_Su_16_9  -39.6
    RHS1      product_Sl_16_9  -8.61111111111111
    RHS1      product_Su_16_10  -39.6
    RHS1      product_Sl_16_10  -8.61111111111111
    RHS1      product_Su_16_11  -39.6
    RHS1      product_Sl_16_11  -8.61111111111111
    RHS1      product_Su_16_12  -39.6
    RHS1      product_Sl_16_12  -8.61111111111111
    RHS1      product_Su_16_13  -39.6
    RHS1      product_Sl_16_13  -8.61111111111111
    RHS1      product_Su_16_14  -39.6
    RHS1      product_Sl_16_14  -8.61111111111111
    RHS1      product_Su_16_15  -39.6
    RHS1      product_Sl_16_15  -8.61111111111111
    RHS1      onehot_17  1
    RHS1      product_Su_17_0  -39.6
    RHS1      product_Sl_17_0  -8.61111111111111
    RHS1      product_Su_17_1  -39.6
    RHS1      product_Sl_17_1  -8.61111111111111
    RHS1      product_Su_17_2  -39.6
    RHS1      product_Sl_17_2  -8.61111111111111
    RHS1      product_Su_17_3  -39.6
    RHS1      product_Sl_17_3  -8.61111111111111
    RHS1      product_Su_17_4  -39.6
    RHS1      product_Sl_17_4  -8.61111111111111
    RHS1      product_Su_17_5  -39.6
    RHS1      product_Sl_17_5  -8.61111111111111
    RHS1      product_Su_17_6  -39.6
    RHS1      product_Sl_17_6  -8.61111111111111
    RHS1      onehot_18  1
    RHS1      product_Su_18_0  -39.6
    RHS1      product_Sl_18_0  -8.61111111111111
    RHS1      product_Su_18_1  -39.6
    RHS1      product_Sl_18_1  -8.61111111111111
    RHS1      product_Su_18_2  -39.6
    RHS1      product_Sl_18_2  -8.61111111111111
    RHS1      product_Su_18_3  -39.6
    RHS1      product_Sl_18_3  -8.61111111111111
    RHS1      product_Su_18_4  -39.6
    RHS1      product_Sl_18_4  -8.61111111111111
    RHS1      product_Su_18_5  -39.6
    RHS1      product_Sl_18_5  -8.61111111111111
    RHS1      product_Su_18_6  -39.6
    RHS1      product_Sl_18_6  -8.61111111111111
    RHS1      product_Su_18_7  -39.6
    RHS1      product_Sl_18_7  -8.61111111111111
    RHS1      product_Su_18_8  -39.6
    RHS1      product_Sl_18_8  -8.61111111111111
    RHS1      product_Su_18_9  -39.6
    RHS1      product_Sl_18_9  -8.61111111111111
    RHS1      product_Su_18_10  -39.6
    RHS1      product_Sl_18_10  -8.61111111111111
    RHS1      onehot_19  1
    RHS1      product_Su_19_0  -39.6
    RHS1      product_Sl_19_0  -8.61111111111111
    RHS1      product_Su_19_1  -39.6
    RHS1      product_Sl_19_1  -8.61111111111111
    RHS1      product_Su_19_2  -39.6
    RHS1      product_Sl_19_2  -8.61111111111111
    RHS1      product_Su_19_3  -39.6
    RHS1      product_Sl_19_3  -8.61111111111111
    RHS1      product_Su_19_4  -39.6
    RHS1      product_Sl_19_4  -8.61111111111111
    RHS1      product_Su_19_5  -39.6
    RHS1      product_Sl_19_5  -8.61111111111111
    RHS1      product_Su_19_6  -39.6
    RHS1      product_Sl_19_6  -8.61111111111111
    RHS1      product_Su_19_7  -39.6
    RHS1      product_Sl_19_7  -8.61111111111111
    RHS1      product_Su_19_8  -39.6
    RHS1      product_Sl_19_8  -8.61111111111111
    RHS1      product_Su_19_9  -39.6
    RHS1      product_Sl_19_9  -8.61111111111111
    RHS1      product_Su_19_10  -39.6
    RHS1      product_Sl_19_10  -8.61111111111111
    RHS1      onehot_20  1
    RHS1      product_Su_20_0  -39.6
    RHS1      product_Sl_20_0  -8.61111111111111
    RHS1      product_Su_20_1  -39.6
    RHS1      product_Sl_20_1  -8.61111111111111
    RHS1      product_Su_20_2  -39.6
    RHS1      product_Sl_20_2  -8.61111111111111
    RHS1      product_Su_20_3  -39.6
    RHS1      product_Sl_20_3  -8.61111111111111
    RHS1      product_Su_20_4  -39.6
    RHS1      product_Sl_20_4  -8.61111111111111
    RHS1      product_Su_20_5  -39.6
    RHS1      product_Sl_20_5  -8.61111111111111
    RHS1      product_Su_20_6  -39.6
    RHS1      product_Sl_20_6  -8.61111111111111
    RHS1      product_Su_20_7  -39.6
    RHS1      product_Sl_20_7  -8.61111111111111
    RHS1      product_Su_20_8  -39.6
    RHS1      product_Sl_20_8  -8.61111111111111
    RHS1      product_Su_20_9  -39.6
    RHS1      product_Sl_20_9  -8.61111111111111
    RHS1      product_Su_20_10  -39.6
    RHS1      product_Sl_20_10  -8.61111111111111
    RHS1      onehot_21  1
    RHS1      product_Su_21_0  -39.6
    RHS1      product_Sl_21_0  -8.61111111111111
    RHS1      product_Su_21_1  -39.6
    RHS1      product_Sl_21_1  -8.61111111111111
    RHS1      product_Su_21_2  -39.6
    RHS1      product_Sl_21_2  -8.61111111111111
    RHS1      product_Su_21_3  -39.6
    RHS1      product_Sl_21_3  -8.61111111111111
    RHS1      product_Su_21_4  -39.6
    RHS1      product_Sl_21_4  -8.61111111111111
    RHS1      product_Su_21_5  -39.6
    RHS1      product_Sl_21_5  -8.61111111111111
    RHS1      product_Su_21_6  -39.6
    RHS1      product_Sl_21_6  -8.61111111111111
    RHS1      onehot_22  1
    RHS1      product_Su_22_0  -39.6
    RHS1      product_Sl_22_0  -8.61111111111111
    RHS1      product_Su_22_1  -39.6
    RHS1      product_Sl_22_1  -8.61111111111111
    RHS1      product_Su_22_2  -39.6
    RHS1      product_Sl_22_2  -8.61111111111111
    RHS1      product_Su_22_3  -39.6
    RHS1      product_Sl_22_3  -8.61111111111111
    RHS1      product_Su_22_4  -39.6
    RHS1      product_Sl_22_4  -8.61111111111111
    RHS1      product_Su_22_5  -39.6
    RHS1      product_Sl_22_5  -8.61111111111111
    RHS1      product_Su_22_6  -39.6
    RHS1      product_Sl_22_6  -8.61111111111111
    RHS1      product_Su_22_7  -39.6
    RHS1      product_Sl_22_7  -8.61111111111111
    RHS1      product_Su_22_8  -39.6
    RHS1      product_Sl_22_8  -8.61111111111111
    RHS1      product_Su_22_9  -39.6
    RHS1      product_Sl_22_9  -8.61111111111111
    RHS1      product_Su_22_10  -39.6
    RHS1      product_Sl_22_10  -8.61111111111111
    RHS1      product_Su_22_11  -39.6
    RHS1      product_Sl_22_11  -8.61111111111111
    RHS1      product_Su_22_12  -39.6
    RHS1      product_Sl_22_12  -8.61111111111111
    RHS1      product_Su_22_13  -39.6
    RHS1      product_Sl_22_13  -8.61111111111111
    RHS1      product_Su_22_14  -39.6
    RHS1      product_Sl_22_14  -8.61111111111111
    RHS1      product_Su_22_15  -39.6
    RHS1      product_Sl_22_15  -8.61111111111111
    RHS1      onehot_23  1
    RHS1      product_Su_23_0  -39.6
    RHS1      product_Sl_23_0  -8.61111111111111
    RHS1      product_Su_23_1  -39.6
    RHS1      product_Sl_23_1  -8.61111111111111
    RHS1      product_Su_23_2  -39.6
    RHS1      product_Sl_23_2  -8.61111111111111
    RHS1      product_Su_23_3  -39.6
    RHS1      product_Sl_23_3  -8.61111111111111
    RHS1      onehot_24  1
    RHS1      product_Su_24_0  -39.6
    RHS1      product_Sl_24_0  -8.61111111111111
    RHS1      product_Su_24_1  -39.6
    RHS1      product_Sl_24_1  -8.61111111111111
    RHS1      product_Su_24_2  -39.6
    RHS1      product_Sl_24_2  -8.61111111111111
    RHS1      product_Su_24_3  -39.6
    RHS1      product_Sl_24_3  -8.61111111111111
    RHS1      product_Su_24_4  -39.6
    RHS1      product_Sl_24_4  -8.61111111111111
    RHS1      product_Su_24_5  -39.6
    RHS1      product_Sl_24_5  -8.61111111111111
    RHS1      product_Su_24_6  -39.6
    RHS1      product_Sl_24_6  -8.61111111111111
    RHS1      product_Su_24_7  -39.6
    RHS1      product_Sl_24_7  -8.61111111111111
    RHS1      product_Su_24_8  -39.6
    RHS1      product_Sl_24_8  -8.61111111111111
    RHS1      product_Su_24_9  -39.6
    RHS1      product_Sl_24_9  -8.61111111111111
    RHS1      product_Su_24_10  -39.6
    RHS1      product_Sl_24_10  -8.61111111111111
    RHS1      product_Su_24_11  -39.6
    RHS1      product_Sl_24_11  -8.61111111111111
    RHS1      product_Su_24_12  -39.6
    RHS1      product_Sl_24_12  -8.61111111111111
    RHS1      product_Su_24_13  -39.6
    RHS1      product_Sl_24_13  -8.61111111111111
    RHS1      product_Su_24_14  -39.6
    RHS1      product_Sl_24_14  -8.61111111111111
    RHS1      product_Su_24_15  -39.6
    RHS1      product_Sl_24_15  -8.61111111111111
    RHS1      onehot_25  1
    RHS1      product_Su_25_0  -39.6
    RHS1      product_Sl_25_0  -8.61111111111111
    RHS1      product_Su_25_1  -39.6
    RHS1      product_Sl_25_1  -8.61111111111111
    RHS1      product_Su_25_2  -39.6
    RHS1      product_Sl_25_2  -8.61111111111111
    RHS1      product_Su_25_3  -39.6
    RHS1      product_Sl_25_3  -8.61111111111111
    RHS1      product_Su_25_4  -39.6
    RHS1      product_Sl_25_4  -8.61111111111111
    RHS1      onehot_26  1
    RHS1      product_Su_26_0  -39.6
    RHS1      product_Sl_26_0  -8.61111111111111
    RHS1      product_Su_26_1  -39.6
    RHS1      product_Sl_26_1  -8.61111111111111
    RHS1      product_Su_26_2  -39.6
    RHS1      product_Sl_26_2  -8.61111111111111
    RHS1      product_Su_26_3  -39.6
    RHS1      product_Sl_26_3  -8.61111111111111
    RHS1      product_Su_26_4  -39.6
    RHS1      product_Sl_26_4  -8.61111111111111
    RHS1      product_Su_26_5  -39.6
    RHS1      product_Sl_26_5  -8.61111111111111
    RHS1      product_Su_26_6  -39.6
    RHS1      product_Sl_26_6  -8.61111111111111
    RHS1      product_Su_26_7  -39.6
    RHS1      product_Sl_26_7  -8.61111111111111
    RHS1      product_Su_26_8  -39.6
    RHS1      product_Sl_26_8  -8.61111111111111
    RHS1      onehot_27  1
    RHS1      product_Su_27_0  -39.6
    RHS1      product_Sl_27_0  -8.61111111111111
    RHS1      product_Su_27_1  -39.6
    RHS1      product_Sl_27_1  -8.61111111111111
    RHS1      product_Su_27_2  -39.6
    RHS1      product_Sl_27_2  -8.61111111111111
    RHS1      product_Su_27_3  -39.6
    RHS1      product_Sl_27_3  -8.61111111111111
    RHS1      product_Su_27_4  -39.6
    RHS1      product_Sl_27_4  -8.61111111111111
    RHS1      product_Su_27_5  -39.6
    RHS1      product_Sl_27_5  -8.61111111111111
    RHS1      product_Su_27_6  -39.6
    RHS1      product_Sl_27_6  -8.61111111111111
    RHS1      onehot_28  1
    RHS1      product_Su_28_0  -39.6
    RHS1      product_Sl_28_0  -8.61111111111111
    RHS1      product_Su_28_1  -39.6
    RHS1      product_Sl_28_1  -8.61111111111111
    RHS1      product_Su_28_2  -39.6
    RHS1      product_Sl_28_2  -8.61111111111111
    RHS1      product_Su_28_3  -39.6
    RHS1      product_Sl_28_3  -8.61111111111111
    RHS1      product_Su_28_4  -39.6
    RHS1      product_Sl_28_4  -8.61111111111111
    RHS1      product_Su_28_5  -39.6
    RHS1      product_Sl_28_5  -8.61111111111111
    RHS1      product_Su_28_6  -39.6
    RHS1      product_Sl_28_6  -8.61111111111111
    RHS1      onehot_29  1
    RHS1      product_Su_29_0  -39.6
    RHS1      product_Sl_29_0  -8.61111111111111
    RHS1      product_Su_29_1  -39.6
    RHS1      product_Sl_29_1  -8.61111111111111
    RHS1      product_Su_29_2  -39.6
    RHS1      product_Sl_29_2  -8.61111111111111
    RHS1      product_Su_29_3  -39.6
    RHS1      product_Sl_29_3  -8.61111111111111
    RHS1      product_Su_29_4  -39.6
    RHS1      product_Sl_29_4  -8.61111111111111
    RHS1      product_Su_29_5  -39.6
    RHS1      product_Sl_29_5  -8.61111111111111
    RHS1      product_Su_29_6  -39.6
    RHS1      product_Sl_29_6  -8.61111111111111
    RHS1      product_Su_29_7  -39.6
    RHS1      product_Sl_29_7  -8.61111111111111
    RHS1      product_Su_29_8  -39.6
    RHS1      product_Sl_29_8  -8.61111111111111
    RHS1      product_Su_29_9  -39.6
    RHS1      product_Sl_29_9  -8.61111111111111
    RHS1      product_Su_29_10  -39.6
    RHS1      product_Sl_29_10  -8.61111111111111
    RHS1      onehot_30  1
    RHS1      product_Su_30_0  -39.6
    RHS1      product_Sl_30_0  -8.61111111111111
    RHS1      product_Su_30_1  -39.6
    RHS1      product_Sl_30_1  -8.61111111111111
    RHS1      product_Su_30_2  -39.6
    RHS1      product_Sl_30_2  -8.61111111111111
    RHS1      product_Su_30_3  -39.6
    RHS1      product_Sl_30_3  -8.61111111111111
    RHS1      product_Su_30_4  -39.6
    RHS1      product_Sl_30_4  -8.61111111111111
    RHS1      product_Su_30_5  -39.6
    RHS1      product_Sl_30_5  -8.61111111111111
    RHS1      product_Su_30_6  -39.6
    RHS1      product_Sl_30_6  -8.61111111111111
    RHS1      product_Su_30_7  -39.6
    RHS1      product_Sl_30_7  -8.61111111111111
    RHS1      product_Su_30_8  -39.6
    RHS1      product_Sl_30_8  -8.61111111111111
    RHS1      onehot_31  1
    RHS1      product_Su_31_0  -39.6
    RHS1      product_Sl_31_0  -8.61111111111111
    RHS1      product_Su_31_1  -39.6
    RHS1      product_Sl_31_1  -8.61111111111111
    RHS1      product_Su_31_2  -39.6
    RHS1      product_Sl_31_2  -8.61111111111111
    RHS1      product_Su_31_3  -39.6
    RHS1      product_Sl_31_3  -8.61111111111111
    RHS1      product_Su_31_4  -39.6
    RHS1      product_Sl_31_4  -8.61111111111111
    RHS1      product_Su_31_5  -39.6
    RHS1      product_Sl_31_5  -8.61111111111111
    RHS1      product_Su_31_6  -39.6
    RHS1      product_Sl_31_6  -8.61111111111111
    RHS1      product_Su_31_7  -39.6
    RHS1      product_Sl_31_7  -8.61111111111111
    RHS1      product_Su_31_8  -39.6
    RHS1      product_Sl_31_8  -8.61111111111111
    RHS1      product_Su_31_9  -39.6
    RHS1      product_Sl_31_9  -8.61111111111111
    RHS1      product_Su_31_10  -39.6
    RHS1      product_Sl_31_10  -8.61111111111111
    RHS1      product_Su_31_11  -39.6
    RHS1      product_Sl_31_11  -8.61111111111111
    RHS1      onehot_32  1
    RHS1      product_Su_32_0  -39.6
    RHS1      product_Sl_32_0  -8.61111111111111
    RHS1      product_Su_32_1  -39.6
    RHS1      product_Sl_32_1  -8.61111111111111
    RHS1      product_Su_32_2  -39.6
    RHS1      product_Sl_32_2  -8.61111111111111
    RHS1      product_Su_32_3  -39.6
    RHS1      product_Sl_32_3  -8.61111111111111
    RHS1      product_Su_32_4  -39.6
    RHS1      product_Sl_32_4  -8.61111111111111
    RHS1      product_Su_32_5  -39.6
    RHS1      product_Sl_32_5  -8.61111111111111
    RHS1      product_Su_32_6  -39.6
    RHS1      product_Sl_32_6  -8.61111111111111
    RHS1      product_Su_32_7  -39.6
    RHS1      product_Sl_32_7  -8.61111111111111
    RHS1      product_Su_32_8  -39.6
    RHS1      product_Sl_32_8  -8.61111111111111
    RHS1      product_Su_32_9  -39.6
    RHS1      product_Sl_32_9  -8.61111111111111
    RHS1      product_Su_32_10  -39.6
    RHS1      product_Sl_32_10  -8.61111111111111
    RHS1      product_Su_32_11  -39.6
    RHS1      product_Sl_32_11  -8.61111111111111
    RHS1      product_Su_32_12  -39.6
    RHS1      product_Sl_32_12  -8.61111111111111
    RHS1      product_Su_32_13  -39.6
    RHS1      product_Sl_32_13  -8.61111111111111
    RHS1      product_Su_32_14  -39.6
    RHS1      product_Sl_32_14  -8.61111111111111
    RHS1      product_Su_32_15  -39.6
    RHS1      product_Sl_32_15  -8.61111111111111
    RHS1      product_Su_32_16  -39.6
    RHS1      product_Sl_32_16  -8.61111111111111
    RHS1      product_Su_32_17  -39.6
    RHS1      product_Sl_32_17  -8.61111111111111
    RHS1      product_Su_32_18  -39.6
    RHS1      product_Sl_32_18  -8.61111111111111
    RHS1      product_Su_32_19  -39.6
    RHS1      product_Sl_32_19  -8.61111111111111
    RHS1      onehot_33  1
    RHS1      product_Su_33_0  -39.6
    RHS1      product_Sl_33_0  -8.61111111111111
    RHS1      product_Su_33_1  -39.6
    RHS1      product_Sl_33_1  -8.61111111111111
    RHS1      product_Su_33_2  -39.6
    RHS1      product_Sl_33_2  -8.61111111111111
    RHS1      product_Su_33_3  -39.6
    RHS1      product_Sl_33_3  -8.61111111111111
    RHS1      product_Su_33_4  -39.6
    RHS1      product_Sl_33_4  -8.61111111111111
    RHS1      product_Su_33_5  -39.6
    RHS1      product_Sl_33_5  -8.61111111111111
    RHS1      product_Su_33_6  -39.6
    RHS1      product_Sl_33_6  -8.61111111111111
    RHS1      product_Su_33_7  -39.6
    RHS1      product_Sl_33_7  -8.61111111111111
    RHS1      product_Su_33_8  -39.6
    RHS1      product_Sl_33_8  -8.61111111111111
    RHS1      product_Su_33_9  -39.6
    RHS1      product_Sl_33_9  -8.61111111111111
    RHS1      product_Su_33_10  -39.6
    RHS1      product_Sl_33_10  -8.61111111111111
    RHS1      product_Su_33_11  -39.6
    RHS1      product_Sl_33_11  -8.61111111111111
    RHS1      onehot_34  1
    RHS1      product_Su_34_0  -39.6
    RHS1      product_Sl_34_0  -8.61111111111111
    RHS1      product_Su_34_1  -39.6
    RHS1      product_Sl_34_1  -8.61111111111111
    RHS1      product_Su_34_2  -39.6
    RHS1      product_Sl_34_2  -8.61111111111111
    RHS1      product_Su_34_3  -39.6
    RHS1      product_Sl_34_3  -8.61111111111111
    RHS1      product_Su_34_4  -39.6
    RHS1      product_Sl_34_4  -8.61111111111111
    RHS1      product_Su_34_5  -39.6
    RHS1      product_Sl_34_5  -8.61111111111111
    RHS1      product_Su_34_6  -39.6
    RHS1      product_Sl_34_6  -8.61111111111111
    RHS1      product_Su_34_7  -39.6
    RHS1      product_Sl_34_7  -8.61111111111111
    RHS1      product_Su_34_8  -39.6
    RHS1      product_Sl_34_8  -8.61111111111111
    RHS1      product_Su_34_9  -39.6
    RHS1      product_Sl_34_9  -8.61111111111111
    RHS1      product_Su_34_10  -39.6
    RHS1      product_Sl_34_10  -8.61111111111111
    RHS1      product_Su_34_11  -39.6
    RHS1      product_Sl_34_11  -8.61111111111111
    RHS1      product_Su_34_12  -39.6
    RHS1      product_Sl_34_12  -8.61111111111111
    RHS1      product_Su_34_13  -39.6
    RHS1      product_Sl_34_13  -8.61111111111111
    RHS1      product_Su_34_14  -39.6
    RHS1      product_Sl_34_14  -8.61111111111111
    RHS1      product_Su_34_15  -39.6
    RHS1      product_Sl_34_15  -8.61111111111111
    RHS1      onehot_35  1
    RHS1      product_Su_35_0  -39.6
    RHS1      product_Sl_35_0  -8.61111111111111
    RHS1      product_Su_35_1  -39.6
    RHS1      product_Sl_35_1  -8.61111111111111
    RHS1      product_Su_35_2  -39.6
    RHS1      product_Sl_35_2  -8.61111111111111
    RHS1      product_Su_35_3  -39.6
    RHS1      product_Sl_35_3  -8.61111111111111
    RHS1      product_Su_35_4  -39.6
    RHS1      product_Sl_35_4  -8.61111111111111
    RHS1      product_Su_35_5  -39.6
    RHS1      product_Sl_35_5  -8.61111111111111
    RHS1      product_Su_35_6  -39.6
    RHS1      product_Sl_35_6  -8.61111111111111
    RHS1      product_Su_35_7  -39.6
    RHS1      product_Sl_35_7  -8.61111111111111
    RHS1      product_Su_35_8  -39.6
    RHS1      product_Sl_35_8  -8.61111111111111
    RHS1      product_Su_35_9  -39.6
    RHS1      product_Sl_35_9  -8.61111111111111
    RHS1      product_Su_35_10  -39.6
    RHS1      product_Sl_35_10  -8.61111111111111
    RHS1      product_Su_35_11  -39.6
    RHS1      product_Sl_35_11  -8.61111111111111
    RHS1      product_Su_35_12  -39.6
    RHS1      product_Sl_35_12  -8.61111111111111
    RHS1      product_Su_35_13  -39.6
    RHS1      product_Sl_35_13  -8.61111111111111
    RHS1      product_Su_35_14  -39.6
    RHS1      product_Sl_35_14  -8.61111111111111
    RHS1      product_Su_35_15  -39.6
    RHS1      product_Sl_35_15  -8.61111111111111
    RHS1      hard_lower  71
    RHS1      hard_upper  146
    RHS1      conditional_complement_lower_1_0  8.73611111111111
    RHS1      conditional_complement_upper_1_0  39.6
    RHS1      conditional_complement_lower_1_1  8.61111111111111
    RHS1      conditional_complement_upper_1_1  39.6
    RHS1      conditional_complement_lower_1_2  8.61111111111111
    RHS1      conditional_complement_upper_1_2  39.6
    RHS1      conditional_complement_lower_1_3  8.61111111111111
    RHS1      conditional_complement_upper_1_3  39.6
    RHS1      conditional_complement_lower_1_4  8.61111111111111
    RHS1      conditional_complement_upper_1_4  39.6
    RHS1      conditional_complement_lower_1_5  8.61111111111111
    RHS1      conditional_complement_upper_1_5  39.6
    RHS1      conditional_complement_lower_1_6  8.61111111111111
    RHS1      conditional_complement_upper_1_6  39.6
    RHS1      conditional_complement_lower_1_7  8.61111111111111
    RHS1      conditional_complement_upper_1_7  39.6
    RHS1      conditional_complement_lower_1_8  8.61111111111111
    RHS1      conditional_complement_upper_1_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_2_0  8.6289682539682531e+00
    RHS1      conditional_complement_upper_2_0  3.9542857142857144e+01
    RHS1      conditional_complement_lower_2_1  8.61111111111111
    RHS1      conditional_complement_upper_2_1  39.6
    RHS1      conditional_complement_lower_2_2  8.61111111111111
    RHS1      conditional_complement_upper_2_2  39.6
    RHS1      conditional_complement_lower_2_3  8.61111111111111
    RHS1      conditional_complement_upper_2_3  39.6
    RHS1      conditional_complement_lower_2_4  8.61111111111111
    RHS1      conditional_complement_upper_2_4  39.6
    RHS1      conditional_complement_lower_2_5  8.61111111111111
    RHS1      conditional_complement_upper_2_5  39.6
    RHS1      conditional_complement_lower_2_6  8.61111111111111
    RHS1      conditional_complement_upper_2_6  39.6
    RHS1      conditional_complement_lower_2_7  8.61111111111111
    RHS1      conditional_complement_upper_2_7  39.6
    RHS1      conditional_complement_lower_2_8  8.61111111111111
    RHS1      conditional_complement_upper_2_8  39.6
    RHS1      conditional_complement_lower_2_9  8.61111111111111
    RHS1      conditional_complement_upper_2_9  39.6
    RHS1      conditional_complement_lower_2_10  8.61111111111111
    RHS1      conditional_complement_upper_2_10  39.6
    RHS1      conditional_complement_lower_2_11  8.61111111111111
    RHS1      conditional_complement_upper_2_11  39.6
    RHS1      conditional_complement_lower_2_12  8.61111111111111
    RHS1      conditional_complement_upper_2_12  39.6
    RHS1      conditional_complement_lower_2_13  8.61111111111111
    RHS1      conditional_complement_upper_2_13  39.6
    RHS1      conditional_complement_lower_2_14  8.61111111111111
    RHS1      conditional_complement_upper_2_14  39.6
    RHS1      conditional_complement_lower_2_15  8.61111111111111
    RHS1      conditional_complement_upper_2_15  39.6
    RHS1      conditional_complement_lower_3_0  8.6527777777777768e+00
    RHS1      conditional_complement_upper_3_0  3.9566666666666670e+01
    RHS1      conditional_complement_lower_3_1  8.61111111111111
    RHS1      conditional_complement_upper_3_1  39.6
    RHS1      conditional_complement_lower_3_2  8.61111111111111
    RHS1      conditional_complement_upper_3_2  39.6
    RHS1      conditional_complement_lower_3_3  8.61111111111111
    RHS1      conditional_complement_upper_3_3  39.6
    RHS1      conditional_complement_lower_3_4  8.61111111111111
    RHS1      conditional_complement_upper_3_4  39.6
    RHS1      conditional_complement_lower_3_5  8.61111111111111
    RHS1      conditional_complement_upper_3_5  39.6
    RHS1      conditional_complement_lower_3_6  8.61111111111111
    RHS1      conditional_complement_upper_3_6  39.6
    RHS1      conditional_complement_lower_3_7  8.61111111111111
    RHS1      conditional_complement_upper_3_7  39.6
    RHS1      conditional_complement_lower_3_8  8.61111111111111
    RHS1      conditional_complement_upper_3_8  39.6
    RHS1      conditional_complement_lower_3_9  8.61111111111111
    RHS1      conditional_complement_upper_3_9  39.6
    RHS1      conditional_complement_lower_3_10  8.61111111111111
    RHS1      conditional_complement_upper_3_10  39.6
    RHS1      conditional_complement_lower_3_11  8.61111111111111
    RHS1      conditional_complement_upper_3_11  39.6
    RHS1      conditional_complement_lower_3_12  8.61111111111111
    RHS1      conditional_complement_upper_3_12  39.6
    RHS1      conditional_complement_lower_4_0  8.6289682539682531e+00
    RHS1      conditional_complement_upper_4_0  3.9542857142857144e+01
    RHS1      conditional_complement_lower_4_1  8.61111111111111
    RHS1      conditional_complement_upper_4_1  39.6
    RHS1      conditional_complement_lower_4_2  8.61111111111111
    RHS1      conditional_complement_upper_4_2  39.6
    RHS1      conditional_complement_lower_4_3  8.61111111111111
    RHS1      conditional_complement_upper_4_3  39.6
    RHS1      conditional_complement_lower_4_4  8.61111111111111
    RHS1      conditional_complement_upper_4_4  39.6
    RHS1      conditional_complement_lower_4_5  8.61111111111111
    RHS1      conditional_complement_upper_4_5  39.6
    RHS1      conditional_complement_lower_4_6  8.61111111111111
    RHS1      conditional_complement_upper_4_6  39.6
    RHS1      conditional_complement_lower_4_7  8.61111111111111
    RHS1      conditional_complement_upper_4_7  39.6
    RHS1      conditional_complement_lower_4_8  8.61111111111111
    RHS1      conditional_complement_upper_4_8  39.6
    RHS1      conditional_complement_lower_4_9  8.61111111111111
    RHS1      conditional_complement_upper_4_9  39.6
    RHS1      conditional_complement_lower_4_10  8.61111111111111
    RHS1      conditional_complement_upper_4_10  39.6
    RHS1      conditional_complement_lower_4_11  8.61111111111111
    RHS1      conditional_complement_upper_4_11  39.6
    RHS1      conditional_complement_lower_4_12  8.61111111111111
    RHS1      conditional_complement_upper_4_12  39.6
    RHS1      conditional_complement_lower_4_13  8.61111111111111
    RHS1      conditional_complement_upper_4_13  39.6
    RHS1      conditional_complement_lower_4_14  8.61111111111111
    RHS1      conditional_complement_upper_4_14  39.6
    RHS1      conditional_complement_lower_4_15  8.61111111111111
    RHS1      conditional_complement_upper_4_15  39.6
    RHS1      conditional_complement_lower_5_0  8.6289682539682531e+00
    RHS1      conditional_complement_upper_5_0  3.9542857142857144e+01
    RHS1      conditional_complement_lower_5_1  8.61111111111111
    RHS1      conditional_complement_upper_5_1  39.6
    RHS1      conditional_complement_lower_5_2  8.61111111111111
    RHS1      conditional_complement_upper_5_2  39.6
    RHS1      conditional_complement_lower_5_3  8.61111111111111
    RHS1      conditional_complement_upper_5_3  39.6
    RHS1      conditional_complement_lower_5_4  8.61111111111111
    RHS1      conditional_complement_upper_5_4  39.6
    RHS1      conditional_complement_lower_5_5  8.61111111111111
    RHS1      conditional_complement_upper_5_5  39.6
    RHS1      conditional_complement_lower_5_6  8.61111111111111
    RHS1      conditional_complement_upper_5_6  39.6
    RHS1      conditional_complement_lower_5_7  8.61111111111111
    RHS1      conditional_complement_upper_5_7  39.6
    RHS1      conditional_complement_lower_5_8  8.61111111111111
    RHS1      conditional_complement_upper_5_8  39.6
    RHS1      conditional_complement_lower_5_9  8.61111111111111
    RHS1      conditional_complement_upper_5_9  39.6
    RHS1      conditional_complement_lower_5_10  8.61111111111111
    RHS1      conditional_complement_upper_5_10  39.6
    RHS1      conditional_complement_lower_5_11  8.61111111111111
    RHS1      conditional_complement_upper_5_11  39.6
    RHS1      conditional_complement_lower_5_12  8.61111111111111
    RHS1      conditional_complement_upper_5_12  39.6
    RHS1      conditional_complement_lower_5_13  8.61111111111111
    RHS1      conditional_complement_upper_5_13  39.6
    RHS1      conditional_complement_lower_5_14  8.61111111111111
    RHS1      conditional_complement_upper_5_14  39.6
    RHS1      conditional_complement_lower_5_15  8.61111111111111
    RHS1      conditional_complement_upper_5_15  39.6
    RHS1      conditional_complement_lower_6_0  8.73611111111111
    RHS1      conditional_complement_upper_6_0  39.6
    RHS1      conditional_complement_lower_6_1  8.61111111111111
    RHS1      conditional_complement_upper_6_1  39.6
    RHS1      conditional_complement_lower_6_2  8.61111111111111
    RHS1      conditional_complement_upper_6_2  39.6
    RHS1      conditional_complement_lower_6_3  8.61111111111111
    RHS1      conditional_complement_upper_6_3  39.6
    RHS1      conditional_complement_lower_6_4  8.61111111111111
    RHS1      conditional_complement_upper_6_4  39.6
    RHS1      conditional_complement_lower_6_5  8.61111111111111
    RHS1      conditional_complement_upper_6_5  39.6
    RHS1      conditional_complement_lower_6_6  8.61111111111111
    RHS1      conditional_complement_upper_6_6  39.6
    RHS1      conditional_complement_lower_6_7  8.61111111111111
    RHS1      conditional_complement_upper_6_7  39.6
    RHS1      conditional_complement_lower_6_8  8.61111111111111
    RHS1      conditional_complement_upper_6_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_7_0  8.6289682539682531e+00
    RHS1      conditional_complement_upper_7_0  3.9542857142857144e+01
    RHS1      conditional_complement_lower_7_1  8.61111111111111
    RHS1      conditional_complement_upper_7_1  39.6
    RHS1      conditional_complement_lower_7_2  8.61111111111111
    RHS1      conditional_complement_upper_7_2  39.6
    RHS1      conditional_complement_lower_7_3  8.61111111111111
    RHS1      conditional_complement_upper_7_3  39.6
    RHS1      conditional_complement_lower_7_4  8.61111111111111
    RHS1      conditional_complement_upper_7_4  39.6
    RHS1      conditional_complement_lower_7_5  8.61111111111111
    RHS1      conditional_complement_upper_7_5  39.6
    RHS1      conditional_complement_lower_7_6  8.61111111111111
    RHS1      conditional_complement_upper_7_6  39.6
    RHS1      conditional_complement_lower_7_7  8.61111111111111
    RHS1      conditional_complement_upper_7_7  39.6
    RHS1      conditional_complement_lower_7_8  8.61111111111111
    RHS1      conditional_complement_upper_7_8  39.6
    RHS1      conditional_complement_lower_7_9  8.61111111111111
    RHS1      conditional_complement_upper_7_9  39.6
    RHS1      conditional_complement_lower_7_10  8.61111111111111
    RHS1      conditional_complement_upper_7_10  39.6
    RHS1      conditional_complement_lower_7_11  8.61111111111111
    RHS1      conditional_complement_upper_7_11  39.6
    RHS1      conditional_complement_lower_7_12  8.61111111111111
    RHS1      conditional_complement_upper_7_12  39.6
    RHS1      conditional_complement_lower_7_13  8.61111111111111
    RHS1      conditional_complement_upper_7_13  39.6
    RHS1      conditional_complement_lower_7_14  8.61111111111111
    RHS1      conditional_complement_upper_7_14  39.6
    RHS1      conditional_complement_lower_7_15  8.61111111111111
    RHS1      conditional_complement_upper_7_15  39.6
    RHS1      conditional_complement_lower_8_0  8.6527777777777768e+00
    RHS1      conditional_complement_upper_8_0  3.9566666666666670e+01
    RHS1      conditional_complement_lower_8_1  8.61111111111111
    RHS1      conditional_complement_upper_8_1  39.6
    RHS1      conditional_complement_lower_8_2  8.61111111111111
    RHS1      conditional_complement_upper_8_2  39.6
    RHS1      conditional_complement_lower_8_3  8.61111111111111
    RHS1      conditional_complement_upper_8_3  39.6
    RHS1      conditional_complement_lower_8_4  8.61111111111111
    RHS1      conditional_complement_upper_8_4  39.6
    RHS1      conditional_complement_lower_8_5  8.61111111111111
    RHS1      conditional_complement_upper_8_5  39.6
    RHS1      conditional_complement_lower_8_6  8.61111111111111
    RHS1      conditional_complement_upper_8_6  39.6
    RHS1      conditional_complement_lower_8_7  8.61111111111111
    RHS1      conditional_complement_upper_8_7  39.6
    RHS1      conditional_complement_lower_8_8  8.61111111111111
    RHS1      conditional_complement_upper_8_8  39.6
    RHS1      conditional_complement_lower_8_9  8.61111111111111
    RHS1      conditional_complement_upper_8_9  39.6
    RHS1      conditional_complement_lower_8_10  8.61111111111111
    RHS1      conditional_complement_upper_8_10  39.6
    RHS1      conditional_complement_lower_8_11  8.61111111111111
    RHS1      conditional_complement_upper_8_11  39.6
    RHS1      conditional_complement_lower_8_12  8.61111111111111
    RHS1      conditional_complement_upper_8_12  39.6
    RHS1      conditional_complement_lower_9_0  8.68611111111111
    RHS1      conditional_complement_upper_9_0  39.6
    RHS1      conditional_complement_lower_9_1  8.61111111111111
    RHS1      conditional_complement_upper_9_1  39.6
    RHS1      conditional_complement_lower_9_2  8.61111111111111
    RHS1      conditional_complement_upper_9_2  39.6
    RHS1      conditional_complement_lower_9_3  8.61111111111111
    RHS1      conditional_complement_upper_9_3  39.6
    RHS1      conditional_complement_lower_9_4  8.61111111111111
    RHS1      conditional_complement_upper_9_4  39.6
    RHS1      conditional_complement_lower_9_5  8.61111111111111
    RHS1      conditional_complement_upper_9_5  39.6
    RHS1      conditional_complement_lower_9_6  8.61111111111111
    RHS1      conditional_complement_upper_9_6  39.6
    RHS1      conditional_complement_lower_9_7  8.61111111111111
    RHS1      conditional_complement_upper_9_7  39.6
    RHS1      conditional_complement_lower_9_8  8.61111111111111
    RHS1      conditional_complement_upper_9_8  39.6
    RHS1      conditional_complement_lower_9_9  8.61111111111111
    RHS1      conditional_complement_upper_9_9  39.6
    RHS1      conditional_complement_lower_9_10  8.61111111111111
    RHS1      conditional_complement_upper_9_10  39.6
    RHS1      conditional_complement_lower_10_0  8.8194444444444429e+00
    RHS1      conditional_complement_upper_10_0  39.6
    RHS1      conditional_complement_lower_10_1  8.61111111111111
    RHS1      conditional_complement_upper_10_1  39.6
    RHS1      conditional_complement_lower_10_2  8.61111111111111
    RHS1      conditional_complement_upper_10_2  39.6
    RHS1      conditional_complement_lower_10_3  8.61111111111111
    RHS1      conditional_complement_upper_10_3  39.6
    RHS1      conditional_complement_lower_10_4  8.61111111111111
    RHS1      conditional_complement_upper_10_4  39.6
    RHS1      conditional_complement_lower_10_5  8.61111111111111
    RHS1      conditional_complement_upper_10_5  39.6
    RHS1      conditional_complement_lower_10_6  8.61111111111111
    RHS1      conditional_complement_upper_10_6  3.9466666666666669e+01
    RHS1      conditional_complement_lower_11_0  8.68611111111111
    RHS1      conditional_complement_upper_11_0  39.6
    RHS1      conditional_complement_lower_11_1  8.61111111111111
    RHS1      conditional_complement_upper_11_1  39.6
    RHS1      conditional_complement_lower_11_2  8.61111111111111
    RHS1      conditional_complement_upper_11_2  39.6
    RHS1      conditional_complement_lower_11_3  8.61111111111111
    RHS1      conditional_complement_upper_11_3  39.6
    RHS1      conditional_complement_lower_11_4  8.61111111111111
    RHS1      conditional_complement_upper_11_4  39.6
    RHS1      conditional_complement_lower_11_5  8.61111111111111
    RHS1      conditional_complement_upper_11_5  39.6
    RHS1      conditional_complement_lower_11_6  8.61111111111111
    RHS1      conditional_complement_upper_11_6  39.6
    RHS1      conditional_complement_lower_11_7  8.61111111111111
    RHS1      conditional_complement_upper_11_7  39.6
    RHS1      conditional_complement_lower_11_8  8.61111111111111
    RHS1      conditional_complement_upper_11_8  39.6
    RHS1      conditional_complement_lower_11_9  8.61111111111111
    RHS1      conditional_complement_upper_11_9  39.6
    RHS1      conditional_complement_lower_11_10  8.61111111111111
    RHS1      conditional_complement_upper_11_10  39.6
    RHS1      conditional_complement_lower_12_0  8.6527777777777768e+00
    RHS1      conditional_complement_upper_12_0  3.9566666666666670e+01
    RHS1      conditional_complement_lower_12_1  8.61111111111111
    RHS1      conditional_complement_upper_12_1  39.6
    RHS1      conditional_complement_lower_12_2  8.61111111111111
    RHS1      conditional_complement_upper_12_2  39.6
    RHS1      conditional_complement_lower_12_3  8.61111111111111
    RHS1      conditional_complement_upper_12_3  39.6
    RHS1      conditional_complement_lower_12_4  8.61111111111111
    RHS1      conditional_complement_upper_12_4  39.6
    RHS1      conditional_complement_lower_12_5  8.61111111111111
    RHS1      conditional_complement_upper_12_5  39.6
    RHS1      conditional_complement_lower_12_6  8.61111111111111
    RHS1      conditional_complement_upper_12_6  39.6
    RHS1      conditional_complement_lower_12_7  8.61111111111111
    RHS1      conditional_complement_upper_12_7  39.6
    RHS1      conditional_complement_lower_12_8  8.61111111111111
    RHS1      conditional_complement_upper_12_8  39.6
    RHS1      conditional_complement_lower_12_9  8.61111111111111
    RHS1      conditional_complement_upper_12_9  39.6
    RHS1      conditional_complement_lower_12_10  8.61111111111111
    RHS1      conditional_complement_upper_12_10  39.6
    RHS1      conditional_complement_lower_12_11  8.61111111111111
    RHS1      conditional_complement_upper_12_11  39.6
    RHS1      conditional_complement_lower_12_12  8.61111111111111
    RHS1      conditional_complement_upper_12_12  39.6
    RHS1      conditional_complement_lower_13_0  8.73611111111111
    RHS1      conditional_complement_upper_13_0  39.6
    RHS1      conditional_complement_lower_13_1  8.61111111111111
    RHS1      conditional_complement_upper_13_1  39.6
    RHS1      conditional_complement_lower_13_2  8.61111111111111
    RHS1      conditional_complement_upper_13_2  39.6
    RHS1      conditional_complement_lower_13_3  8.61111111111111
    RHS1      conditional_complement_upper_13_3  39.6
    RHS1      conditional_complement_lower_13_4  8.61111111111111
    RHS1      conditional_complement_upper_13_4  39.6
    RHS1      conditional_complement_lower_13_5  8.61111111111111
    RHS1      conditional_complement_upper_13_5  39.6
    RHS1      conditional_complement_lower_13_6  8.61111111111111
    RHS1      conditional_complement_upper_13_6  39.6
    RHS1      conditional_complement_lower_13_7  8.61111111111111
    RHS1      conditional_complement_upper_13_7  39.6
    RHS1      conditional_complement_lower_13_8  8.61111111111111
    RHS1      conditional_complement_upper_13_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_14_0  8.73611111111111
    RHS1      conditional_complement_upper_14_0  39.6
    RHS1      conditional_complement_lower_14_1  8.61111111111111
    RHS1      conditional_complement_upper_14_1  39.6
    RHS1      conditional_complement_lower_14_2  8.61111111111111
    RHS1      conditional_complement_upper_14_2  39.6
    RHS1      conditional_complement_lower_14_3  8.61111111111111
    RHS1      conditional_complement_upper_14_3  39.6
    RHS1      conditional_complement_lower_14_4  8.61111111111111
    RHS1      conditional_complement_upper_14_4  39.6
    RHS1      conditional_complement_lower_14_5  8.61111111111111
    RHS1      conditional_complement_upper_14_5  39.6
    RHS1      conditional_complement_lower_14_6  8.61111111111111
    RHS1      conditional_complement_upper_14_6  39.6
    RHS1      conditional_complement_lower_14_7  8.61111111111111
    RHS1      conditional_complement_upper_14_7  39.6
    RHS1      conditional_complement_lower_14_8  8.61111111111111
    RHS1      conditional_complement_upper_14_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_15_0  8.73611111111111
    RHS1      conditional_complement_upper_15_0  39.6
    RHS1      conditional_complement_lower_15_1  8.61111111111111
    RHS1      conditional_complement_upper_15_1  39.6
    RHS1      conditional_complement_lower_15_2  8.61111111111111
    RHS1      conditional_complement_upper_15_2  39.6
    RHS1      conditional_complement_lower_15_3  8.61111111111111
    RHS1      conditional_complement_upper_15_3  39.6
    RHS1      conditional_complement_lower_15_4  8.61111111111111
    RHS1      conditional_complement_upper_15_4  39.6
    RHS1      conditional_complement_lower_15_5  8.61111111111111
    RHS1      conditional_complement_upper_15_5  39.6
    RHS1      conditional_complement_lower_15_6  8.61111111111111
    RHS1      conditional_complement_upper_15_6  39.6
    RHS1      conditional_complement_lower_15_7  8.61111111111111
    RHS1      conditional_complement_upper_15_7  39.6
    RHS1      conditional_complement_lower_15_8  8.61111111111111
    RHS1      conditional_complement_upper_15_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_16_0  8.61111111111111
    RHS1      conditional_complement_upper_16_0  3.9525000000000006e+01
    RHS1      conditional_complement_lower_16_1  8.61111111111111
    RHS1      conditional_complement_upper_16_1  39.6
    RHS1      conditional_complement_lower_16_2  8.61111111111111
    RHS1      conditional_complement_upper_16_2  39.6
    RHS1      conditional_complement_lower_16_3  8.61111111111111
    RHS1      conditional_complement_upper_16_3  39.6
    RHS1      conditional_complement_lower_16_4  8.61111111111111
    RHS1      conditional_complement_upper_16_4  39.6
    RHS1      conditional_complement_lower_16_5  8.61111111111111
    RHS1      conditional_complement_upper_16_5  39.6
    RHS1      conditional_complement_lower_16_6  8.61111111111111
    RHS1      conditional_complement_upper_16_6  39.6
    RHS1      conditional_complement_lower_16_7  8.61111111111111
    RHS1      conditional_complement_upper_16_7  39.6
    RHS1      conditional_complement_lower_16_8  8.61111111111111
    RHS1      conditional_complement_upper_16_8  39.6
    RHS1      conditional_complement_lower_16_9  8.61111111111111
    RHS1      conditional_complement_upper_16_9  39.6
    RHS1      conditional_complement_lower_16_10  8.61111111111111
    RHS1      conditional_complement_upper_16_10  39.6
    RHS1      conditional_complement_lower_16_11  8.61111111111111
    RHS1      conditional_complement_upper_16_11  39.6
    RHS1      conditional_complement_lower_16_12  8.61111111111111
    RHS1      conditional_complement_upper_16_12  39.6
    RHS1      conditional_complement_lower_16_13  8.61111111111111
    RHS1      conditional_complement_upper_16_13  39.6
    RHS1      conditional_complement_lower_16_14  8.61111111111111
    RHS1      conditional_complement_upper_16_14  39.6
    RHS1      conditional_complement_lower_16_15  8.61111111111111
    RHS1      conditional_complement_upper_16_15  39.6
    RHS1      conditional_complement_lower_17_0  8.8194444444444429e+00
    RHS1      conditional_complement_upper_17_0  39.6
    RHS1      conditional_complement_lower_17_1  8.61111111111111
    RHS1      conditional_complement_upper_17_1  39.6
    RHS1      conditional_complement_lower_17_2  8.61111111111111
    RHS1      conditional_complement_upper_17_2  39.6
    RHS1      conditional_complement_lower_17_3  8.61111111111111
    RHS1      conditional_complement_upper_17_3  39.6
    RHS1      conditional_complement_lower_17_4  8.61111111111111
    RHS1      conditional_complement_upper_17_4  39.6
    RHS1      conditional_complement_lower_17_5  8.61111111111111
    RHS1      conditional_complement_upper_17_5  39.6
    RHS1      conditional_complement_lower_17_6  8.61111111111111
    RHS1      conditional_complement_upper_17_6  3.9466666666666669e+01
    RHS1      conditional_complement_lower_18_0  8.68611111111111
    RHS1      conditional_complement_upper_18_0  39.6
    RHS1      conditional_complement_lower_18_1  8.61111111111111
    RHS1      conditional_complement_upper_18_1  39.6
    RHS1      conditional_complement_lower_18_2  8.61111111111111
    RHS1      conditional_complement_upper_18_2  39.6
    RHS1      conditional_complement_lower_18_3  8.61111111111111
    RHS1      conditional_complement_upper_18_3  39.6
    RHS1      conditional_complement_lower_18_4  8.61111111111111
    RHS1      conditional_complement_upper_18_4  39.6
    RHS1      conditional_complement_lower_18_5  8.61111111111111
    RHS1      conditional_complement_upper_18_5  39.6
    RHS1      conditional_complement_lower_18_6  8.61111111111111
    RHS1      conditional_complement_upper_18_6  39.6
    RHS1      conditional_complement_lower_18_7  8.61111111111111
    RHS1      conditional_complement_upper_18_7  39.6
    RHS1      conditional_complement_lower_18_8  8.61111111111111
    RHS1      conditional_complement_upper_18_8  39.6
    RHS1      conditional_complement_lower_18_9  8.61111111111111
    RHS1      conditional_complement_upper_18_9  39.6
    RHS1      conditional_complement_lower_18_10  8.61111111111111
    RHS1      conditional_complement_upper_18_10  39.6
    RHS1      conditional_complement_lower_19_0  8.68611111111111
    RHS1      conditional_complement_upper_19_0  39.6
    RHS1      conditional_complement_lower_19_1  8.61111111111111
    RHS1      conditional_complement_upper_19_1  39.6
    RHS1      conditional_complement_lower_19_2  8.61111111111111
    RHS1      conditional_complement_upper_19_2  39.6
    RHS1      conditional_complement_lower_19_3  8.61111111111111
    RHS1      conditional_complement_upper_19_3  39.6
    RHS1      conditional_complement_lower_19_4  8.61111111111111
    RHS1      conditional_complement_upper_19_4  39.6
    RHS1      conditional_complement_lower_19_5  8.61111111111111
    RHS1      conditional_complement_upper_19_5  39.6
    RHS1      conditional_complement_lower_19_6  8.61111111111111
    RHS1      conditional_complement_upper_19_6  39.6
    RHS1      conditional_complement_lower_19_7  8.61111111111111
    RHS1      conditional_complement_upper_19_7  39.6
    RHS1      conditional_complement_lower_19_8  8.61111111111111
    RHS1      conditional_complement_upper_19_8  39.6
    RHS1      conditional_complement_lower_19_9  8.61111111111111
    RHS1      conditional_complement_upper_19_9  39.6
    RHS1      conditional_complement_lower_19_10  8.61111111111111
    RHS1      conditional_complement_upper_19_10  39.6
    RHS1      conditional_complement_lower_20_0  8.68611111111111
    RHS1      conditional_complement_upper_20_0  39.6
    RHS1      conditional_complement_lower_20_1  8.61111111111111
    RHS1      conditional_complement_upper_20_1  39.6
    RHS1      conditional_complement_lower_20_2  8.61111111111111
    RHS1      conditional_complement_upper_20_2  39.6
    RHS1      conditional_complement_lower_20_3  8.61111111111111
    RHS1      conditional_complement_upper_20_3  39.6
    RHS1      conditional_complement_lower_20_4  8.61111111111111
    RHS1      conditional_complement_upper_20_4  39.6
    RHS1      conditional_complement_lower_20_5  8.61111111111111
    RHS1      conditional_complement_upper_20_5  39.6
    RHS1      conditional_complement_lower_20_6  8.61111111111111
    RHS1      conditional_complement_upper_20_6  39.6
    RHS1      conditional_complement_lower_20_7  8.61111111111111
    RHS1      conditional_complement_upper_20_7  39.6
    RHS1      conditional_complement_lower_20_8  8.61111111111111
    RHS1      conditional_complement_upper_20_8  39.6
    RHS1      conditional_complement_lower_20_9  8.61111111111111
    RHS1      conditional_complement_upper_20_9  39.6
    RHS1      conditional_complement_lower_20_10  8.61111111111111
    RHS1      conditional_complement_upper_20_10  39.6
    RHS1      conditional_complement_lower_21_0  8.8194444444444429e+00
    RHS1      conditional_complement_upper_21_0  39.6
    RHS1      conditional_complement_lower_21_1  8.61111111111111
    RHS1      conditional_complement_upper_21_1  39.6
    RHS1      conditional_complement_lower_21_2  8.61111111111111
    RHS1      conditional_complement_upper_21_2  39.6
    RHS1      conditional_complement_lower_21_3  8.61111111111111
    RHS1      conditional_complement_upper_21_3  39.6
    RHS1      conditional_complement_lower_21_4  8.61111111111111
    RHS1      conditional_complement_upper_21_4  39.6
    RHS1      conditional_complement_lower_21_5  8.61111111111111
    RHS1      conditional_complement_upper_21_5  39.6
    RHS1      conditional_complement_lower_21_6  8.61111111111111
    RHS1      conditional_complement_upper_21_6  3.9466666666666669e+01
    RHS1      conditional_complement_lower_22_0  8.6289682539682531e+00
    RHS1      conditional_complement_upper_22_0  3.9542857142857144e+01
    RHS1      conditional_complement_lower_22_1  8.61111111111111
    RHS1      conditional_complement_upper_22_1  39.6
    RHS1      conditional_complement_lower_22_2  8.61111111111111
    RHS1      conditional_complement_upper_22_2  39.6
    RHS1      conditional_complement_lower_22_3  8.61111111111111
    RHS1      conditional_complement_upper_22_3  39.6
    RHS1      conditional_complement_lower_22_4  8.61111111111111
    RHS1      conditional_complement_upper_22_4  39.6
    RHS1      conditional_complement_lower_22_5  8.61111111111111
    RHS1      conditional_complement_upper_22_5  39.6
    RHS1      conditional_complement_lower_22_6  8.61111111111111
    RHS1      conditional_complement_upper_22_6  39.6
    RHS1      conditional_complement_lower_22_7  8.61111111111111
    RHS1      conditional_complement_upper_22_7  39.6
    RHS1      conditional_complement_lower_22_8  8.61111111111111
    RHS1      conditional_complement_upper_22_8  39.6
    RHS1      conditional_complement_lower_22_9  8.61111111111111
    RHS1      conditional_complement_upper_22_9  39.6
    RHS1      conditional_complement_lower_22_10  8.61111111111111
    RHS1      conditional_complement_upper_22_10  39.6
    RHS1      conditional_complement_lower_22_11  8.61111111111111
    RHS1      conditional_complement_upper_22_11  39.6
    RHS1      conditional_complement_lower_22_12  8.61111111111111
    RHS1      conditional_complement_upper_22_12  39.6
    RHS1      conditional_complement_lower_22_13  8.61111111111111
    RHS1      conditional_complement_upper_22_13  39.6
    RHS1      conditional_complement_lower_22_14  8.61111111111111
    RHS1      conditional_complement_upper_22_14  39.6
    RHS1      conditional_complement_lower_22_15  8.61111111111111
    RHS1      conditional_complement_upper_22_15  39.6
    RHS1      conditional_complement_lower_23_0  9.48611111111111
    RHS1      conditional_complement_upper_23_0  39.6
    RHS1      conditional_complement_lower_23_1  8.61111111111111
    RHS1      conditional_complement_upper_23_1  39.6
    RHS1      conditional_complement_lower_23_2  8.61111111111111
    RHS1      conditional_complement_upper_23_2  39.6
    RHS1      conditional_complement_lower_23_3  8.61111111111111
    RHS1      conditional_complement_upper_23_3  3.8800000000000004e+01
    RHS1      conditional_complement_lower_24_0  8.61111111111111
    RHS1      conditional_complement_upper_24_0  3.9525000000000006e+01
    RHS1      conditional_complement_lower_24_1  8.61111111111111
    RHS1      conditional_complement_upper_24_1  39.6
    RHS1      conditional_complement_lower_24_2  8.61111111111111
    RHS1      conditional_complement_upper_24_2  39.6
    RHS1      conditional_complement_lower_24_3  8.61111111111111
    RHS1      conditional_complement_upper_24_3  39.6
    RHS1      conditional_complement_lower_24_4  8.61111111111111
    RHS1      conditional_complement_upper_24_4  39.6
    RHS1      conditional_complement_lower_24_5  8.61111111111111
    RHS1      conditional_complement_upper_24_5  39.6
    RHS1      conditional_complement_lower_24_6  8.61111111111111
    RHS1      conditional_complement_upper_24_6  39.6
    RHS1      conditional_complement_lower_24_7  8.61111111111111
    RHS1      conditional_complement_upper_24_7  39.6
    RHS1      conditional_complement_lower_24_8  8.61111111111111
    RHS1      conditional_complement_upper_24_8  39.6
    RHS1      conditional_complement_lower_24_9  8.61111111111111
    RHS1      conditional_complement_upper_24_9  39.6
    RHS1      conditional_complement_lower_24_10  8.61111111111111
    RHS1      conditional_complement_upper_24_10  39.6
    RHS1      conditional_complement_lower_24_11  8.61111111111111
    RHS1      conditional_complement_upper_24_11  39.6
    RHS1      conditional_complement_lower_24_12  8.61111111111111
    RHS1      conditional_complement_upper_24_12  39.6
    RHS1      conditional_complement_lower_24_13  8.61111111111111
    RHS1      conditional_complement_upper_24_13  39.6
    RHS1      conditional_complement_lower_24_14  8.61111111111111
    RHS1      conditional_complement_upper_24_14  39.6
    RHS1      conditional_complement_lower_24_15  8.61111111111111
    RHS1      conditional_complement_upper_24_15  39.6
    RHS1      conditional_complement_lower_25_0  8.98611111111111
    RHS1      conditional_complement_upper_25_0  39.6
    RHS1      conditional_complement_lower_25_1  8.61111111111111
    RHS1      conditional_complement_upper_25_1  39.6
    RHS1      conditional_complement_lower_25_2  8.61111111111111
    RHS1      conditional_complement_upper_25_2  39.6
    RHS1      conditional_complement_lower_25_3  8.61111111111111
    RHS1      conditional_complement_upper_25_3  39.6
    RHS1      conditional_complement_lower_25_4  8.61111111111111
    RHS1      conditional_complement_upper_25_4  3.9300000000000004e+01
    RHS1      conditional_complement_lower_26_0  8.73611111111111
    RHS1      conditional_complement_upper_26_0  39.6
    RHS1      conditional_complement_lower_26_1  8.61111111111111
    RHS1      conditional_complement_upper_26_1  39.6
    RHS1      conditional_complement_lower_26_2  8.61111111111111
    RHS1      conditional_complement_upper_26_2  39.6
    RHS1      conditional_complement_lower_26_3  8.61111111111111
    RHS1      conditional_complement_upper_26_3  39.6
    RHS1      conditional_complement_lower_26_4  8.61111111111111
    RHS1      conditional_complement_upper_26_4  39.6
    RHS1      conditional_complement_lower_26_5  8.61111111111111
    RHS1      conditional_complement_upper_26_5  39.6
    RHS1      conditional_complement_lower_26_6  8.61111111111111
    RHS1      conditional_complement_upper_26_6  39.6
    RHS1      conditional_complement_lower_26_7  8.61111111111111
    RHS1      conditional_complement_upper_26_7  39.6
    RHS1      conditional_complement_lower_26_8  8.61111111111111
    RHS1      conditional_complement_upper_26_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_27_0  8.8194444444444429e+00
    RHS1      conditional_complement_upper_27_0  39.6
    RHS1      conditional_complement_lower_27_1  8.61111111111111
    RHS1      conditional_complement_upper_27_1  39.6
    RHS1      conditional_complement_lower_27_2  8.61111111111111
    RHS1      conditional_complement_upper_27_2  39.6
    RHS1      conditional_complement_lower_27_3  8.61111111111111
    RHS1      conditional_complement_upper_27_3  39.6
    RHS1      conditional_complement_lower_27_4  8.61111111111111
    RHS1      conditional_complement_upper_27_4  39.6
    RHS1      conditional_complement_lower_27_5  8.61111111111111
    RHS1      conditional_complement_upper_27_5  39.6
    RHS1      conditional_complement_lower_27_6  8.61111111111111
    RHS1      conditional_complement_upper_27_6  3.9466666666666669e+01
    RHS1      conditional_complement_lower_28_0  8.8194444444444429e+00
    RHS1      conditional_complement_upper_28_0  39.6
    RHS1      conditional_complement_lower_28_1  8.61111111111111
    RHS1      conditional_complement_upper_28_1  39.6
    RHS1      conditional_complement_lower_28_2  8.61111111111111
    RHS1      conditional_complement_upper_28_2  39.6
    RHS1      conditional_complement_lower_28_3  8.61111111111111
    RHS1      conditional_complement_upper_28_3  39.6
    RHS1      conditional_complement_lower_28_4  8.61111111111111
    RHS1      conditional_complement_upper_28_4  39.6
    RHS1      conditional_complement_lower_28_5  8.61111111111111
    RHS1      conditional_complement_upper_28_5  39.6
    RHS1      conditional_complement_lower_28_6  8.61111111111111
    RHS1      conditional_complement_upper_28_6  3.9466666666666669e+01
    RHS1      conditional_complement_lower_29_0  8.68611111111111
    RHS1      conditional_complement_upper_29_0  39.6
    RHS1      conditional_complement_lower_29_1  8.61111111111111
    RHS1      conditional_complement_upper_29_1  39.6
    RHS1      conditional_complement_lower_29_2  8.61111111111111
    RHS1      conditional_complement_upper_29_2  39.6
    RHS1      conditional_complement_lower_29_3  8.61111111111111
    RHS1      conditional_complement_upper_29_3  39.6
    RHS1      conditional_complement_lower_29_4  8.61111111111111
    RHS1      conditional_complement_upper_29_4  39.6
    RHS1      conditional_complement_lower_29_5  8.61111111111111
    RHS1      conditional_complement_upper_29_5  39.6
    RHS1      conditional_complement_lower_29_6  8.61111111111111
    RHS1      conditional_complement_upper_29_6  39.6
    RHS1      conditional_complement_lower_29_7  8.61111111111111
    RHS1      conditional_complement_upper_29_7  39.6
    RHS1      conditional_complement_lower_29_8  8.61111111111111
    RHS1      conditional_complement_upper_29_8  39.6
    RHS1      conditional_complement_lower_29_9  8.61111111111111
    RHS1      conditional_complement_upper_29_9  39.6
    RHS1      conditional_complement_lower_29_10  8.61111111111111
    RHS1      conditional_complement_upper_29_10  39.6
    RHS1      conditional_complement_lower_30_0  8.73611111111111
    RHS1      conditional_complement_upper_30_0  39.6
    RHS1      conditional_complement_lower_30_1  8.61111111111111
    RHS1      conditional_complement_upper_30_1  39.6
    RHS1      conditional_complement_lower_30_2  8.61111111111111
    RHS1      conditional_complement_upper_30_2  39.6
    RHS1      conditional_complement_lower_30_3  8.61111111111111
    RHS1      conditional_complement_upper_30_3  39.6
    RHS1      conditional_complement_lower_30_4  8.61111111111111
    RHS1      conditional_complement_upper_30_4  39.6
    RHS1      conditional_complement_lower_30_5  8.61111111111111
    RHS1      conditional_complement_upper_30_5  39.6
    RHS1      conditional_complement_lower_30_6  8.61111111111111
    RHS1      conditional_complement_upper_30_6  39.6
    RHS1      conditional_complement_lower_30_7  8.61111111111111
    RHS1      conditional_complement_upper_30_7  39.6
    RHS1      conditional_complement_lower_30_8  8.61111111111111
    RHS1      conditional_complement_upper_30_8  3.9550000000000004e+01
    RHS1      conditional_complement_lower_31_0  8.6527777777777768e+00
    RHS1      conditional_complement_upper_31_0  3.9566666666666670e+01
    RHS1      conditional_complement_lower_31_1  8.61111111111111
    RHS1      conditional_complement_upper_31_1  39.6
    RHS1      conditional_complement_lower_31_2  8.61111111111111
    RHS1      conditional_complement_upper_31_2  39.6
    RHS1      conditional_complement_lower_31_3  8.61111111111111
    RHS1      conditional_complement_upper_31_3  39.6
    RHS1      conditional_complement_lower_31_4  8.61111111111111
    RHS1      conditional_complement_upper_31_4  39.6
    RHS1      conditional_complement_lower_31_5  8.61111111111111
    RHS1      conditional_complement_upper_31_5  39.6
    RHS1      conditional_complement_lower_31_6  8.61111111111111
    RHS1      conditional_complement_upper_31_6  39.6
    RHS1      conditional_complement_lower_31_7  8.61111111111111
    RHS1      conditional_complement_upper_31_7  39.6
    RHS1      conditional_complement_lower_31_8  8.61111111111111
    RHS1      conditional_complement_upper_31_8  39.6
    RHS1      conditional_complement_lower_31_9  8.61111111111111
    RHS1      conditional_complement_upper_31_9  39.6
    RHS1      conditional_complement_lower_31_10  8.61111111111111
    RHS1      conditional_complement_upper_31_10  39.6
    RHS1      conditional_complement_lower_31_11  8.61111111111111
    RHS1      conditional_complement_upper_31_11  39.6
    RHS1      conditional_complement_lower_32_0  8.61111111111111
    RHS1      conditional_complement_upper_32_0  3.9511111111111113e+01
    RHS1      conditional_complement_lower_32_1  8.61111111111111
    RHS1      conditional_complement_upper_32_1  39.6
    RHS1      conditional_complement_lower_32_2  8.61111111111111
    RHS1      conditional_complement_upper_32_2  39.6
    RHS1      conditional_complement_lower_32_3  8.61111111111111
    RHS1      conditional_complement_upper_32_3  39.6
    RHS1      conditional_complement_lower_32_4  8.61111111111111
    RHS1      conditional_complement_upper_32_4  39.6
    RHS1      conditional_complement_lower_32_5  8.61111111111111
    RHS1      conditional_complement_upper_32_5  39.6
    RHS1      conditional_complement_lower_32_6  8.61111111111111
    RHS1      conditional_complement_upper_32_6  39.6
    RHS1      conditional_complement_lower_32_7  8.61111111111111
    RHS1      conditional_complement_upper_32_7  39.6
    RHS1      conditional_complement_lower_32_8  8.61111111111111
    RHS1      conditional_complement_upper_32_8  39.6
    RHS1      conditional_complement_lower_32_9  8.61111111111111
    RHS1      conditional_complement_upper_32_9  39.6
    RHS1      conditional_complement_lower_32_10  8.61111111111111
    RHS1      conditional_complement_upper_32_10  39.6
    RHS1      conditional_complement_lower_32_11  8.61111111111111
    RHS1      conditional_complement_upper_32_11  39.6
    RHS1      conditional_complement_lower_32_12  8.61111111111111
    RHS1      conditional_complement_upper_32_12  39.6
    RHS1      conditional_complement_lower_32_13  8.61111111111111
    RHS1      conditional_complement_upper_32_13  39.6
    RHS1      conditional_complement_lower_32_14  8.61111111111111
    RHS1      conditional_complement_upper_32_14  39.6
    RHS1      conditional_complement_lower_32_15  8.61111111111111
    RHS1      conditional_complement_upper_32_15  39.6
    RHS1      conditional_complement_lower_32_16  8.61111111111111
    RHS1      conditional_complement_upper_32_16  39.6
    RHS1      conditional_complement_lower_32_17  8.61111111111111
    RHS1      conditional_complement_upper_32_17  39.6
    RHS1      conditional_complement_lower_32_18  8.61111111111111
    RHS1      conditional_complement_upper_32_18  39.6
    RHS1      conditional_complement_lower_32_19  8.6249999999999982e+00
    RHS1      conditional_complement_upper_32_19  39.6
    RHS1      conditional_complement_lower_33_0  8.68611111111111
    RHS1      conditional_complement_upper_33_0  39.6
    RHS1      conditional_complement_lower_33_1  8.61111111111111
    RHS1      conditional_complement_upper_33_1  39.6
    RHS1      conditional_complement_lower_33_2  8.61111111111111
    RHS1      conditional_complement_upper_33_2  39.6
    RHS1      conditional_complement_lower_33_3  8.61111111111111
    RHS1      conditional_complement_upper_33_3  39.6
    RHS1      conditional_complement_lower_33_4  8.61111111111111
    RHS1      conditional_complement_upper_33_4  39.6
    RHS1      conditional_complement_lower_33_5  8.61111111111111
    RHS1      conditional_complement_upper_33_5  39.6
    RHS1      conditional_complement_lower_33_6  8.61111111111111
    RHS1      conditional_complement_upper_33_6  39.6
    RHS1      conditional_complement_lower_33_7  8.61111111111111
    RHS1      conditional_complement_upper_33_7  39.6
    RHS1      conditional_complement_lower_33_8  8.61111111111111
    RHS1      conditional_complement_upper_33_8  39.6
    RHS1      conditional_complement_lower_33_9  8.61111111111111
    RHS1      conditional_complement_upper_33_9  39.6
    RHS1      conditional_complement_lower_33_10  8.61111111111111
    RHS1      conditional_complement_upper_33_10  39.6
    RHS1      conditional_complement_lower_33_11  8.61111111111111
    RHS1      conditional_complement_upper_33_11  39.6
    RHS1      conditional_complement_lower_34_0  8.61111111111111
    RHS1      conditional_complement_upper_34_0  3.9525000000000006e+01
    RHS1      conditional_complement_lower_34_1  8.61111111111111
    RHS1      conditional_complement_upper_34_1  39.6
    RHS1      conditional_complement_lower_34_2  8.61111111111111
    RHS1      conditional_complement_upper_34_2  39.6
    RHS1      conditional_complement_lower_34_3  8.61111111111111
    RHS1      conditional_complement_upper_34_3  39.6
    RHS1      conditional_complement_lower_34_4  8.61111111111111
    RHS1      conditional_complement_upper_34_4  39.6
    RHS1      conditional_complement_lower_34_5  8.61111111111111
    RHS1      conditional_complement_upper_34_5  39.6
    RHS1      conditional_complement_lower_34_6  8.61111111111111
    RHS1      conditional_complement_upper_34_6  39.6
    RHS1      conditional_complement_lower_34_7  8.61111111111111
    RHS1      conditional_complement_upper_34_7  39.6
    RHS1      conditional_complement_lower_34_8  8.61111111111111
    RHS1      conditional_complement_upper_34_8  39.6
    RHS1      conditional_complement_lower_34_9  8.61111111111111
    RHS1      conditional_complement_upper_34_9  39.6
    RHS1      conditional_complement_lower_34_10  8.61111111111111
    RHS1      conditional_complement_upper_34_10  39.6
    RHS1      conditional_complement_lower_34_11  8.61111111111111
    RHS1      conditional_complement_upper_34_11  39.6
    RHS1      conditional_complement_lower_34_12  8.61111111111111
    RHS1      conditional_complement_upper_34_12  39.6
    RHS1      conditional_complement_lower_34_13  8.61111111111111
    RHS1      conditional_complement_upper_34_13  39.6
    RHS1      conditional_complement_lower_34_14  8.61111111111111
    RHS1      conditional_complement_upper_34_14  39.6
    RHS1      conditional_complement_lower_34_15  8.61111111111111
    RHS1      conditional_complement_upper_34_15  39.6
    RHS1      conditional_complement_lower_35_0  8.61111111111111
    RHS1      conditional_complement_upper_35_0  3.9525000000000006e+01
    RHS1      conditional_complement_lower_35_1  8.61111111111111
    RHS1      conditional_complement_upper_35_1  39.6
    RHS1      conditional_complement_lower_35_2  8.61111111111111
    RHS1      conditional_complement_upper_35_2  39.6
    RHS1      conditional_complement_lower_35_3  8.61111111111111
    RHS1      conditional_complement_upper_35_3  39.6
    RHS1      conditional_complement_lower_35_4  8.61111111111111
    RHS1      conditional_complement_upper_35_4  39.6
    RHS1      conditional_complement_lower_35_5  8.61111111111111
    RHS1      conditional_complement_upper_35_5  39.6
    RHS1      conditional_complement_lower_35_6  8.61111111111111
    RHS1      conditional_complement_upper_35_6  39.6
    RHS1      conditional_complement_lower_35_7  8.61111111111111
    RHS1      conditional_complement_upper_35_7  39.6
    RHS1      conditional_complement_lower_35_8  8.61111111111111
    RHS1      conditional_complement_upper_35_8  39.6
    RHS1      conditional_complement_lower_35_9  8.61111111111111
    RHS1      conditional_complement_upper_35_9  39.6
    RHS1      conditional_complement_lower_35_10  8.61111111111111
    RHS1      conditional_complement_upper_35_10  39.6
    RHS1      conditional_complement_lower_35_11  8.61111111111111
    RHS1      conditional_complement_upper_35_11  39.6
    RHS1      conditional_complement_lower_35_12  8.61111111111111
    RHS1      conditional_complement_upper_35_12  39.6
    RHS1      conditional_complement_lower_35_13  8.61111111111111
    RHS1      conditional_complement_upper_35_13  39.6
    RHS1      conditional_complement_lower_35_14  8.61111111111111
    RHS1      conditional_complement_upper_35_14  39.6
    RHS1      conditional_complement_lower_35_15  8.61111111111111
    RHS1      conditional_complement_upper_35_15  39.6
    RHS1      tight_DP_cost_product_ll  1.1038696482888478e-01
    RHS1      tight_DP_cost_product_uu  3.5853333964569312e-01
    RHS1      tight_DP_cost_product_ul  5.0763760341954256e-01
    RHS1      tight_DP_cost_product_lu  7.7963899614313187e-02
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[6,2]  
 BV BND1      x[6,3]  
 BV BND1      x[6,4]  
 BV BND1      x[6,5]  
 BV BND1      x[6,6]  
 BV BND1      x[6,7]  
 BV BND1      x[6,8]  
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[16,12]
 BV BND1      x[16,13]
 BV BND1      x[16,14]
 BV BND1      x[16,15]
 BV BND1      x[17,0] 
 BV BND1      x[17,1] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[17,5] 
 BV BND1      x[17,6] 
 BV BND1      x[18,0] 
 BV BND1      x[18,1] 
 BV BND1      x[18,2] 
 BV BND1      x[18,3] 
 BV BND1      x[18,4] 
 BV BND1      x[18,5] 
 BV BND1      x[18,6] 
 BV BND1      x[18,7] 
 BV BND1      x[18,8] 
 BV BND1      x[18,9] 
 BV BND1      x[18,10]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[19,9] 
 BV BND1      x[19,10]
 BV BND1      x[20,0] 
 BV BND1      x[20,1] 
 BV BND1      x[20,2] 
 BV BND1      x[20,3] 
 BV BND1      x[20,4] 
 BV BND1      x[20,5] 
 BV BND1      x[20,6] 
 BV BND1      x[20,7] 
 BV BND1      x[20,8] 
 BV BND1      x[20,9] 
 BV BND1      x[20,10]
 BV BND1      x[21,0] 
 BV BND1      x[21,1] 
 BV BND1      x[21,2] 
 BV BND1      x[21,3] 
 BV BND1      x[21,4] 
 BV BND1      x[21,5] 
 BV BND1      x[21,6] 
 BV BND1      x[22,0] 
 BV BND1      x[22,1] 
 BV BND1      x[22,2] 
 BV BND1      x[22,3] 
 BV BND1      x[22,4] 
 BV BND1      x[22,5] 
 BV BND1      x[22,6] 
 BV BND1      x[22,7] 
 BV BND1      x[22,8] 
 BV BND1      x[22,9] 
 BV BND1      x[22,10]
 BV BND1      x[22,11]
 BV BND1      x[22,12]
 BV BND1      x[22,13]
 BV BND1      x[22,14]
 BV BND1      x[22,15]
 BV BND1      x[23,0] 
 BV BND1      x[23,1] 
 BV BND1      x[23,2] 
 BV BND1      x[23,3] 
 BV BND1      x[24,0] 
 BV BND1      x[24,1] 
 BV BND1      x[24,2] 
 BV BND1      x[24,3] 
 BV BND1      x[24,4] 
 BV BND1      x[24,5] 
 BV BND1      x[24,6] 
 BV BND1      x[24,7] 
 BV BND1      x[24,8] 
 BV BND1      x[24,9] 
 BV BND1      x[24,10]
 BV BND1      x[24,11]
 BV BND1      x[24,12]
 BV BND1      x[24,13]
 BV BND1      x[24,14]
 BV BND1      x[24,15]
 BV BND1      x[25,0] 
 BV BND1      x[25,1] 
 BV BND1      x[25,2] 
 BV BND1      x[25,3] 
 BV BND1      x[25,4] 
 BV BND1      x[26,0] 
 BV BND1      x[26,1] 
 BV BND1      x[26,2] 
 BV BND1      x[26,3] 
 BV BND1      x[26,4] 
 BV BND1      x[26,5] 
 BV BND1      x[26,6] 
 BV BND1      x[26,7] 
 BV BND1      x[26,8] 
 BV BND1      x[27,0] 
 BV BND1      x[27,1] 
 BV BND1      x[27,2] 
 BV BND1      x[27,3] 
 BV BND1      x[27,4] 
 BV BND1      x[27,5] 
 BV BND1      x[27,6] 
 BV BND1      x[28,0] 
 BV BND1      x[28,1] 
 BV BND1      x[28,2] 
 BV BND1      x[28,3] 
 BV BND1      x[28,4] 
 BV BND1      x[28,5] 
 BV BND1      x[28,6] 
 BV BND1      x[29,0] 
 BV BND1      x[29,1] 
 BV BND1      x[29,2] 
 BV BND1      x[29,3] 
 BV BND1      x[29,4] 
 BV BND1      x[29,5] 
 BV BND1      x[29,6] 
 BV BND1      x[29,7] 
 BV BND1      x[29,8] 
 BV BND1      x[29,9] 
 BV BND1      x[29,10]
 BV BND1      x[30,0] 
 BV BND1      x[30,1] 
 BV BND1      x[30,2] 
 BV BND1      x[30,3] 
 BV BND1      x[30,4] 
 BV BND1      x[30,5] 
 BV BND1      x[30,6] 
 BV BND1      x[30,7] 
 BV BND1      x[30,8] 
 BV BND1      x[31,0] 
 BV BND1      x[31,1] 
 BV BND1      x[31,2] 
 BV BND1      x[31,3] 
 BV BND1      x[31,4] 
 BV BND1      x[31,5] 
 BV BND1      x[31,6] 
 BV BND1      x[31,7] 
 BV BND1      x[31,8] 
 BV BND1      x[31,9] 
 BV BND1      x[31,10]
 BV BND1      x[31,11]
 BV BND1      x[32,0] 
 BV BND1      x[32,1] 
 BV BND1      x[32,2] 
 BV BND1      x[32,3] 
 BV BND1      x[32,4] 
 BV BND1      x[32,5] 
 BV BND1      x[32,6] 
 BV BND1      x[32,7] 
 BV BND1      x[32,8] 
 BV BND1      x[32,9] 
 BV BND1      x[32,10]
 BV BND1      x[32,11]
 BV BND1      x[32,12]
 BV BND1      x[32,13]
 BV BND1      x[32,14]
 BV BND1      x[32,15]
 BV BND1      x[32,16]
 BV BND1      x[32,17]
 BV BND1      x[32,18]
 BV BND1      x[32,19]
 BV BND1      x[33,0] 
 BV BND1      x[33,1] 
 BV BND1      x[33,2] 
 BV BND1      x[33,3] 
 BV BND1      x[33,4] 
 BV BND1      x[33,5] 
 BV BND1      x[33,6] 
 BV BND1      x[33,7] 
 BV BND1      x[33,8] 
 BV BND1      x[33,9] 
 BV BND1      x[33,10]
 BV BND1      x[33,11]
 BV BND1      x[34,0] 
 BV BND1      x[34,1] 
 BV BND1      x[34,2] 
 BV BND1      x[34,3] 
 BV BND1      x[34,4] 
 BV BND1      x[34,5] 
 BV BND1      x[34,6] 
 BV BND1      x[34,7] 
 BV BND1      x[34,8] 
 BV BND1      x[34,9] 
 BV BND1      x[34,10]
 BV BND1      x[34,11]
 BV BND1      x[34,12]
 BV BND1      x[34,13]
 BV BND1      x[34,14]
 BV BND1      x[34,15]
 BV BND1      x[35,0] 
 BV BND1      x[35,1] 
 BV BND1      x[35,2] 
 BV BND1      x[35,3] 
 BV BND1      x[35,4] 
 BV BND1      x[35,5] 
 BV BND1      x[35,6] 
 BV BND1      x[35,7] 
 BV BND1      x[35,8] 
 BV BND1      x[35,9] 
 BV BND1      x[35,10]
 BV BND1      x[35,11]
 BV BND1      x[35,12]
 BV BND1      x[35,13]
 BV BND1      x[35,14]
 BV BND1      x[35,15]
 UP BND1      Sx[1,0]   39.6
 UP BND1      Sx[1,1]   39.6
 UP BND1      Sx[1,2]   39.6
 UP BND1      Sx[1,3]   39.6
 UP BND1      Sx[1,4]   39.6
 UP BND1      Sx[1,5]   39.6
 UP BND1      Sx[1,6]   39.6
 UP BND1      Sx[1,7]   39.6
 UP BND1      Sx[1,8]   39.6
 UP BND1      Sx[2,0]   39.6
 UP BND1      Sx[2,1]   39.6
 UP BND1      Sx[2,2]   39.6
 UP BND1      Sx[2,3]   39.6
 UP BND1      Sx[2,4]   39.6
 UP BND1      Sx[2,5]   39.6
 UP BND1      Sx[2,6]   39.6
 UP BND1      Sx[2,7]   39.6
 UP BND1      Sx[2,8]   39.6
 UP BND1      Sx[2,9]   39.6
 UP BND1      Sx[2,10]  39.6
 UP BND1      Sx[2,11]  39.6
 UP BND1      Sx[2,12]  39.6
 UP BND1      Sx[2,13]  39.6
 UP BND1      Sx[2,14]  39.6
 UP BND1      Sx[2,15]  39.6
 UP BND1      Sx[3,0]   39.6
 UP BND1      Sx[3,1]   39.6
 UP BND1      Sx[3,2]   39.6
 UP BND1      Sx[3,3]   39.6
 UP BND1      Sx[3,4]   39.6
 UP BND1      Sx[3,5]   39.6
 UP BND1      Sx[3,6]   39.6
 UP BND1      Sx[3,7]   39.6
 UP BND1      Sx[3,8]   39.6
 UP BND1      Sx[3,9]   39.6
 UP BND1      Sx[3,10]  39.6
 UP BND1      Sx[3,11]  39.6
 UP BND1      Sx[3,12]  39.6
 UP BND1      Sx[4,0]   39.6
 UP BND1      Sx[4,1]   39.6
 UP BND1      Sx[4,2]   39.6
 UP BND1      Sx[4,3]   39.6
 UP BND1      Sx[4,4]   39.6
 UP BND1      Sx[4,5]   39.6
 UP BND1      Sx[4,6]   39.6
 UP BND1      Sx[4,7]   39.6
 UP BND1      Sx[4,8]   39.6
 UP BND1      Sx[4,9]   39.6
 UP BND1      Sx[4,10]  39.6
 UP BND1      Sx[4,11]  39.6
 UP BND1      Sx[4,12]  39.6
 UP BND1      Sx[4,13]  39.6
 UP BND1      Sx[4,14]  39.6
 UP BND1      Sx[4,15]  39.6
 UP BND1      Sx[5,0]   39.6
 UP BND1      Sx[5,1]   39.6
 UP BND1      Sx[5,2]   39.6
 UP BND1      Sx[5,3]   39.6
 UP BND1      Sx[5,4]   39.6
 UP BND1      Sx[5,5]   39.6
 UP BND1      Sx[5,6]   39.6
 UP BND1      Sx[5,7]   39.6
 UP BND1      Sx[5,8]   39.6
 UP BND1      Sx[5,9]   39.6
 UP BND1      Sx[5,10]  39.6
 UP BND1      Sx[5,11]  39.6
 UP BND1      Sx[5,12]  39.6
 UP BND1      Sx[5,13]  39.6
 UP BND1      Sx[5,14]  39.6
 UP BND1      Sx[5,15]  39.6
 UP BND1      Sx[6,0]   39.6
 UP BND1      Sx[6,1]   39.6
 UP BND1      Sx[6,2]   39.6
 UP BND1      Sx[6,3]   39.6
 UP BND1      Sx[6,4]   39.6
 UP BND1      Sx[6,5]   39.6
 UP BND1      Sx[6,6]   39.6
 UP BND1      Sx[6,7]   39.6
 UP BND1      Sx[6,8]   39.6
 UP BND1      Sx[7,0]   39.6
 UP BND1      Sx[7,1]   39.6
 UP BND1      Sx[7,2]   39.6
 UP BND1      Sx[7,3]   39.6
 UP BND1      Sx[7,4]   39.6
 UP BND1      Sx[7,5]   39.6
 UP BND1      Sx[7,6]   39.6
 UP BND1      Sx[7,7]   39.6
 UP BND1      Sx[7,8]   39.6
 UP BND1      Sx[7,9]   39.6
 UP BND1      Sx[7,10]  39.6
 UP BND1      Sx[7,11]  39.6
 UP BND1      Sx[7,12]  39.6
 UP BND1      Sx[7,13]  39.6
 UP BND1      Sx[7,14]  39.6
 UP BND1      Sx[7,15]  39.6
 UP BND1      Sx[8,0]   39.6
 UP BND1      Sx[8,1]   39.6
 UP BND1      Sx[8,2]   39.6
 UP BND1      Sx[8,3]   39.6
 UP BND1      Sx[8,4]   39.6
 UP BND1      Sx[8,5]   39.6
 UP BND1      Sx[8,6]   39.6
 UP BND1      Sx[8,7]   39.6
 UP BND1      Sx[8,8]   39.6
 UP BND1      Sx[8,9]   39.6
 UP BND1      Sx[8,10]  39.6
 UP BND1      Sx[8,11]  39.6
 UP BND1      Sx[8,12]  39.6
 UP BND1      Sx[9,0]   39.6
 UP BND1      Sx[9,1]   39.6
 UP BND1      Sx[9,2]   39.6
 UP BND1      Sx[9,3]   39.6
 UP BND1      Sx[9,4]   39.6
 UP BND1      Sx[9,5]   39.6
 UP BND1      Sx[9,6]   39.6
 UP BND1      Sx[9,7]   39.6
 UP BND1      Sx[9,8]   39.6
 UP BND1      Sx[9,9]   39.6
 UP BND1      Sx[9,10]  39.6
 UP BND1      Sx[10,0]  39.6
 UP BND1      Sx[10,1]  39.6
 UP BND1      Sx[10,2]  39.6
 UP BND1      Sx[10,3]  39.6
 UP BND1      Sx[10,4]  39.6
 UP BND1      Sx[10,5]  39.6
 UP BND1      Sx[10,6]  39.6
 UP BND1      Sx[11,0]  39.6
 UP BND1      Sx[11,1]  39.6
 UP BND1      Sx[11,2]  39.6
 UP BND1      Sx[11,3]  39.6
 UP BND1      Sx[11,4]  39.6
 UP BND1      Sx[11,5]  39.6
 UP BND1      Sx[11,6]  39.6
 UP BND1      Sx[11,7]  39.6
 UP BND1      Sx[11,8]  39.6
 UP BND1      Sx[11,9]  39.6
 UP BND1      Sx[11,10]  39.6
 UP BND1      Sx[12,0]  39.6
 UP BND1      Sx[12,1]  39.6
 UP BND1      Sx[12,2]  39.6
 UP BND1      Sx[12,3]  39.6
 UP BND1      Sx[12,4]  39.6
 UP BND1      Sx[12,5]  39.6
 UP BND1      Sx[12,6]  39.6
 UP BND1      Sx[12,7]  39.6
 UP BND1      Sx[12,8]  39.6
 UP BND1      Sx[12,9]  39.6
 UP BND1      Sx[12,10]  39.6
 UP BND1      Sx[12,11]  39.6
 UP BND1      Sx[12,12]  39.6
 UP BND1      Sx[13,0]  39.6
 UP BND1      Sx[13,1]  39.6
 UP BND1      Sx[13,2]  39.6
 UP BND1      Sx[13,3]  39.6
 UP BND1      Sx[13,4]  39.6
 UP BND1      Sx[13,5]  39.6
 UP BND1      Sx[13,6]  39.6
 UP BND1      Sx[13,7]  39.6
 UP BND1      Sx[13,8]  39.6
 UP BND1      Sx[14,0]  39.6
 UP BND1      Sx[14,1]  39.6
 UP BND1      Sx[14,2]  39.6
 UP BND1      Sx[14,3]  39.6
 UP BND1      Sx[14,4]  39.6
 UP BND1      Sx[14,5]  39.6
 UP BND1      Sx[14,6]  39.6
 UP BND1      Sx[14,7]  39.6
 UP BND1      Sx[14,8]  39.6
 UP BND1      Sx[15,0]  39.6
 UP BND1      Sx[15,1]  39.6
 UP BND1      Sx[15,2]  39.6
 UP BND1      Sx[15,3]  39.6
 UP BND1      Sx[15,4]  39.6
 UP BND1      Sx[15,5]  39.6
 UP BND1      Sx[15,6]  39.6
 UP BND1      Sx[15,7]  39.6
 UP BND1      Sx[15,8]  39.6
 UP BND1      Sx[16,0]  39.6
 UP BND1      Sx[16,1]  39.6
 UP BND1      Sx[16,2]  39.6
 UP BND1      Sx[16,3]  39.6
 UP BND1      Sx[16,4]  39.6
 UP BND1      Sx[16,5]  39.6
 UP BND1      Sx[16,6]  39.6
 UP BND1      Sx[16,7]  39.6
 UP BND1      Sx[16,8]  39.6
 UP BND1      Sx[16,9]  39.6
 UP BND1      Sx[16,10]  39.6
 UP BND1      Sx[16,11]  39.6
 UP BND1      Sx[16,12]  39.6
 UP BND1      Sx[16,13]  39.6
 UP BND1      Sx[16,14]  39.6
 UP BND1      Sx[16,15]  39.6
 UP BND1      Sx[17,0]  39.6
 UP BND1      Sx[17,1]  39.6
 UP BND1      Sx[17,2]  39.6
 UP BND1      Sx[17,3]  39.6
 UP BND1      Sx[17,4]  39.6
 UP BND1      Sx[17,5]  39.6
 UP BND1      Sx[17,6]  39.6
 UP BND1      Sx[18,0]  39.6
 UP BND1      Sx[18,1]  39.6
 UP BND1      Sx[18,2]  39.6
 UP BND1      Sx[18,3]  39.6
 UP BND1      Sx[18,4]  39.6
 UP BND1      Sx[18,5]  39.6
 UP BND1      Sx[18,6]  39.6
 UP BND1      Sx[18,7]  39.6
 UP BND1      Sx[18,8]  39.6
 UP BND1      Sx[18,9]  39.6
 UP BND1      Sx[18,10]  39.6
 UP BND1      Sx[19,0]  39.6
 UP BND1      Sx[19,1]  39.6
 UP BND1      Sx[19,2]  39.6
 UP BND1      Sx[19,3]  39.6
 UP BND1      Sx[19,4]  39.6
 UP BND1      Sx[19,5]  39.6
 UP BND1      Sx[19,6]  39.6
 UP BND1      Sx[19,7]  39.6
 UP BND1      Sx[19,8]  39.6
 UP BND1      Sx[19,9]  39.6
 UP BND1      Sx[19,10]  39.6
 UP BND1      Sx[20,0]  39.6
 UP BND1      Sx[20,1]  39.6
 UP BND1      Sx[20,2]  39.6
 UP BND1      Sx[20,3]  39.6
 UP BND1      Sx[20,4]  39.6
 UP BND1      Sx[20,5]  39.6
 UP BND1      Sx[20,6]  39.6
 UP BND1      Sx[20,7]  39.6
 UP BND1      Sx[20,8]  39.6
 UP BND1      Sx[20,9]  39.6
 UP BND1      Sx[20,10]  39.6
 UP BND1      Sx[21,0]  39.6
 UP BND1      Sx[21,1]  39.6
 UP BND1      Sx[21,2]  39.6
 UP BND1      Sx[21,3]  39.6
 UP BND1      Sx[21,4]  39.6
 UP BND1      Sx[21,5]  39.6
 UP BND1      Sx[21,6]  39.6
 UP BND1      Sx[22,0]  39.6
 UP BND1      Sx[22,1]  39.6
 UP BND1      Sx[22,2]  39.6
 UP BND1      Sx[22,3]  39.6
 UP BND1      Sx[22,4]  39.6
 UP BND1      Sx[22,5]  39.6
 UP BND1      Sx[22,6]  39.6
 UP BND1      Sx[22,7]  39.6
 UP BND1      Sx[22,8]  39.6
 UP BND1      Sx[22,9]  39.6
 UP BND1      Sx[22,10]  39.6
 UP BND1      Sx[22,11]  39.6
 UP BND1      Sx[22,12]  39.6
 UP BND1      Sx[22,13]  39.6
 UP BND1      Sx[22,14]  39.6
 UP BND1      Sx[22,15]  39.6
 UP BND1      Sx[23,0]  39.6
 UP BND1      Sx[23,1]  39.6
 UP BND1      Sx[23,2]  39.6
 UP BND1      Sx[23,3]  39.6
 UP BND1      Sx[24,0]  39.6
 UP BND1      Sx[24,1]  39.6
 UP BND1      Sx[24,2]  39.6
 UP BND1      Sx[24,3]  39.6
 UP BND1      Sx[24,4]  39.6
 UP BND1      Sx[24,5]  39.6
 UP BND1      Sx[24,6]  39.6
 UP BND1      Sx[24,7]  39.6
 UP BND1      Sx[24,8]  39.6
 UP BND1      Sx[24,9]  39.6
 UP BND1      Sx[24,10]  39.6
 UP BND1      Sx[24,11]  39.6
 UP BND1      Sx[24,12]  39.6
 UP BND1      Sx[24,13]  39.6
 UP BND1      Sx[24,14]  39.6
 UP BND1      Sx[24,15]  39.6
 UP BND1      Sx[25,0]  39.6
 UP BND1      Sx[25,1]  39.6
 UP BND1      Sx[25,2]  39.6
 UP BND1      Sx[25,3]  39.6
 UP BND1      Sx[25,4]  39.6
 UP BND1      Sx[26,0]  39.6
 UP BND1      Sx[26,1]  39.6
 UP BND1      Sx[26,2]  39.6
 UP BND1      Sx[26,3]  39.6
 UP BND1      Sx[26,4]  39.6
 UP BND1      Sx[26,5]  39.6
 UP BND1      Sx[26,6]  39.6
 UP BND1      Sx[26,7]  39.6
 UP BND1      Sx[26,8]  39.6
 UP BND1      Sx[27,0]  39.6
 UP BND1      Sx[27,1]  39.6
 UP BND1      Sx[27,2]  39.6
 UP BND1      Sx[27,3]  39.6
 UP BND1      Sx[27,4]  39.6
 UP BND1      Sx[27,5]  39.6
 UP BND1      Sx[27,6]  39.6
 UP BND1      Sx[28,0]  39.6
 UP BND1      Sx[28,1]  39.6
 UP BND1      Sx[28,2]  39.6
 UP BND1      Sx[28,3]  39.6
 UP BND1      Sx[28,4]  39.6
 UP BND1      Sx[28,5]  39.6
 UP BND1      Sx[28,6]  39.6
 UP BND1      Sx[29,0]  39.6
 UP BND1      Sx[29,1]  39.6
 UP BND1      Sx[29,2]  39.6
 UP BND1      Sx[29,3]  39.6
 UP BND1      Sx[29,4]  39.6
 UP BND1      Sx[29,5]  39.6
 UP BND1      Sx[29,6]  39.6
 UP BND1      Sx[29,7]  39.6
 UP BND1      Sx[29,8]  39.6
 UP BND1      Sx[29,9]  39.6
 UP BND1      Sx[29,10]  39.6
 UP BND1      Sx[30,0]  39.6
 UP BND1      Sx[30,1]  39.6
 UP BND1      Sx[30,2]  39.6
 UP BND1      Sx[30,3]  39.6
 UP BND1      Sx[30,4]  39.6
 UP BND1      Sx[30,5]  39.6
 UP BND1      Sx[30,6]  39.6
 UP BND1      Sx[30,7]  39.6
 UP BND1      Sx[30,8]  39.6
 UP BND1      Sx[31,0]  39.6
 UP BND1      Sx[31,1]  39.6
 UP BND1      Sx[31,2]  39.6
 UP BND1      Sx[31,3]  39.6
 UP BND1      Sx[31,4]  39.6
 UP BND1      Sx[31,5]  39.6
 UP BND1      Sx[31,6]  39.6
 UP BND1      Sx[31,7]  39.6
 UP BND1      Sx[31,8]  39.6
 UP BND1      Sx[31,9]  39.6
 UP BND1      Sx[31,10]  39.6
 UP BND1      Sx[31,11]  39.6
 UP BND1      Sx[32,0]  39.6
 UP BND1      Sx[32,1]  39.6
 UP BND1      Sx[32,2]  39.6
 UP BND1      Sx[32,3]  39.6
 UP BND1      Sx[32,4]  39.6
 UP BND1      Sx[32,5]  39.6
 UP BND1      Sx[32,6]  39.6
 UP BND1      Sx[32,7]  39.6
 UP BND1      Sx[32,8]  39.6
 UP BND1      Sx[32,9]  39.6
 UP BND1      Sx[32,10]  39.6
 UP BND1      Sx[32,11]  39.6
 UP BND1      Sx[32,12]  39.6
 UP BND1      Sx[32,13]  39.6
 UP BND1      Sx[32,14]  39.6
 UP BND1      Sx[32,15]  39.6
 UP BND1      Sx[32,16]  39.6
 UP BND1      Sx[32,17]  39.6
 UP BND1      Sx[32,18]  39.6
 UP BND1      Sx[32,19]  39.6
 UP BND1      Sx[33,0]  39.6
 UP BND1      Sx[33,1]  39.6
 UP BND1      Sx[33,2]  39.6
 UP BND1      Sx[33,3]  39.6
 UP BND1      Sx[33,4]  39.6
 UP BND1      Sx[33,5]  39.6
 UP BND1      Sx[33,6]  39.6
 UP BND1      Sx[33,7]  39.6
 UP BND1      Sx[33,8]  39.6
 UP BND1      Sx[33,9]  39.6
 UP BND1      Sx[33,10]  39.6
 UP BND1      Sx[33,11]  39.6
 UP BND1      Sx[34,0]  39.6
 UP BND1      Sx[34,1]  39.6
 UP BND1      Sx[34,2]  39.6
 UP BND1      Sx[34,3]  39.6
 UP BND1      Sx[34,4]  39.6
 UP BND1      Sx[34,5]  39.6
 UP BND1      Sx[34,6]  39.6
 UP BND1      Sx[34,7]  39.6
 UP BND1      Sx[34,8]  39.6
 UP BND1      Sx[34,9]  39.6
 UP BND1      Sx[34,10]  39.6
 UP BND1      Sx[34,11]  39.6
 UP BND1      Sx[34,12]  39.6
 UP BND1      Sx[34,13]  39.6
 UP BND1      Sx[34,14]  39.6
 UP BND1      Sx[34,15]  39.6
 UP BND1      Sx[35,0]  39.6
 UP BND1      Sx[35,1]  39.6
 UP BND1      Sx[35,2]  39.6
 UP BND1      Sx[35,3]  39.6
 UP BND1      Sx[35,4]  39.6
 UP BND1      Sx[35,5]  39.6
 UP BND1      Sx[35,6]  39.6
 UP BND1      Sx[35,7]  39.6
 UP BND1      Sx[35,8]  39.6
 UP BND1      Sx[35,9]  39.6
 UP BND1      Sx[35,10]  39.6
 UP BND1      Sx[35,11]  39.6
 UP BND1      Sx[35,12]  39.6
 UP BND1      Sx[35,13]  39.6
 UP BND1      Sx[35,14]  39.6
 UP BND1      Sx[35,15]  39.6
 LO BND1      S         8.61111111111111
 UP BND1      S         39.6
 FR BND1      residual_scaled
 LO BND1      hard_cost_D  -1.2819131399483395e-02
 UP BND1      hard_cost_D  -0.00905387221327508
 FR BND1      hard_cost_W
ENDATA
