* Signature: 0xf259b1e561fb91f8
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
COLUMNS
    psi[1,4]  OBJ       1
    psi[1,4]  column_0  1
    psi[1,4]  column_1  1
    psi[1,4]  column_2  1
    psi[1,4]  column_3  1
    psi[1,4]  column_4  1
    psi[1,4]  column_5  1
    psi[1,4]  column_6  1
    psi[1,4]  column_7  1
    psi[1,4]  column_8  1
    psi[1,4]  column_9  1
    psi[1,4]  column_10  1
    psi[1,4]  column_11  1
    psi[1,4]  column_12  1
    psi[1,4]  column_13  1
    psi[2,12]  OBJ       1
    psi[2,12]  column_0  1
    psi[2,12]  column_1  1
    psi[2,12]  column_2  1
    psi[2,12]  column_3  1
    psi[2,12]  column_4  1
    psi[2,12]  column_5  1
    psi[2,12]  column_6  1
    psi[2,12]  column_7  1
    psi[2,12]  column_8  1
    psi[2,12]  column_9  1
    psi[2,12]  column_10  1
    psi[2,12]  column_11  1
    psi[2,12]  column_12  1
    psi[2,12]  column_13  1
    psi[3,13]  OBJ       1
    psi[3,13]  column_0  1
    psi[3,13]  column_1  1
    psi[3,13]  column_2  1
    psi[3,13]  column_3  1
    psi[3,13]  column_4  1
    psi[3,13]  column_5  1
    psi[3,13]  column_6  1
    psi[3,13]  column_7  1
    psi[3,13]  column_8  1
    psi[3,13]  column_9  1
    psi[3,13]  column_10  1
    psi[3,13]  column_11  1
    psi[3,13]  column_12  1
    psi[3,13]  column_13  1
    psi[4,7]  OBJ       9.4444444444444431e-01
    psi[4,7]  column_0  1
    psi[4,7]  column_1  1
    psi[4,7]  column_2  1
    psi[4,7]  column_3  1
    psi[4,7]  column_4  1
    psi[4,7]  column_5  1
    psi[4,7]  column_6  1
    psi[4,7]  column_7  1
    psi[4,7]  column_8  1
    psi[4,7]  column_9  1
    psi[4,7]  column_10  1
    psi[4,7]  column_11  1
    psi[4,13]  OBJ       0.0555555555555557
    psi[4,13]  column_12  1
    psi[4,13]  column_13  1
    psi[5,8]  OBJ       1
    psi[5,8]  column_0  1
    psi[5,8]  column_1  1
    psi[5,8]  column_2  1
    psi[5,8]  column_3  1
    psi[5,8]  column_4  1
    psi[5,8]  column_5  1
    psi[5,8]  column_6  1
    psi[5,8]  column_7  1
    psi[5,8]  column_8  1
    psi[5,8]  column_9  1
    psi[5,8]  column_10  1
    psi[5,8]  column_11  1
    psi[5,8]  column_12  1
    psi[5,8]  column_13  1
    psi[6,4]  OBJ       1
    psi[6,4]  column_0  1
    psi[6,4]  column_1  1
    psi[6,4]  column_2  1
    psi[6,4]  column_3  1
    psi[6,4]  column_4  1
    psi[6,4]  column_5  1
    psi[6,4]  column_6  1
    psi[6,4]  column_7  1
    psi[6,4]  column_8  1
    psi[6,4]  column_9  1
    psi[6,4]  column_10  1
    psi[6,4]  column_11  1
    psi[6,4]  column_12  1
    psi[6,4]  column_13  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[7,10]  column_12  1
    psi[7,10]  column_13  1
    psi[8,7]  OBJ       9.5630608610139212e-01
    psi[8,7]  column_0  1
    psi[8,7]  column_1  1
    psi[8,7]  column_2  1
    psi[8,7]  column_3  1
    psi[8,7]  column_4  1
    psi[8,7]  column_5  1
    psi[8,7]  column_6  1
    psi[8,7]  column_7  1
    psi[8,7]  column_8  1
    psi[8,7]  column_9  1
    psi[8,7]  column_10  1
    psi[8,7]  column_12  1
    psi[8,13]  OBJ       4.3693913898607911e-02
    psi[8,13]  column_11  1
    psi[8,13]  column_13  1
    psi[9,5]  OBJ       0.111111111111111
    psi[9,5]  column_0  1
    psi[9,10]  OBJ       8.8888888888888906e-01
    psi[9,10]  column_1  1
    psi[9,10]  column_2  1
    psi[9,10]  column_3  1
    psi[9,10]  column_4  1
    psi[9,10]  column_5  1
    psi[9,10]  column_6  1
    psi[9,10]  column_7  1
    psi[9,10]  column_8  1
    psi[9,10]  column_9  1
    psi[9,10]  column_10  1
    psi[9,10]  column_11  1
    psi[9,10]  column_12  1
    psi[9,10]  column_13  1
    psi[10,4]  OBJ       1.4699858369351132e-01
    psi[10,4]  column_1  1
    psi[10,4]  column_2  1
    psi[10,6]  OBJ       8.5300141630646542e-01
    psi[10,6]  column_0  1
    psi[10,6]  column_3  1
    psi[10,6]  column_4  1
    psi[10,6]  column_5  1
    psi[10,6]  column_6  1
    psi[10,6]  column_7  1
    psi[10,6]  column_8  1
    psi[10,6]  column_9  1
    psi[10,6]  column_10  1
    psi[10,6]  column_11  1
    psi[10,6]  column_12  1
    psi[10,6]  column_13  1
    psi[11,7]  OBJ       1
    psi[11,7]  column_0  1
    psi[11,7]  column_1  1
    psi[11,7]  column_2  1
    psi[11,7]  column_3  1
    psi[11,7]  column_4  1
    psi[11,7]  column_5  1
    psi[11,7]  column_6  1
    psi[11,7]  column_7  1
    psi[11,7]  column_8  1
    psi[11,7]  column_9  1
    psi[11,7]  column_10  1
    psi[11,7]  column_11  1
    psi[11,7]  column_12  1
    psi[11,7]  column_13  1
    psi[12,8]  OBJ       9.1931497517239191e-01
    psi[12,8]  column_0  1
    psi[12,8]  column_1  1
    psi[12,8]  column_2  1
    psi[12,8]  column_3  1
    psi[12,8]  column_4  1
    psi[12,8]  column_5  1
    psi[12,8]  column_6  1
    psi[12,8]  column_7  1
    psi[12,8]  column_8  1
    psi[12,8]  column_9  1
    psi[12,8]  column_10  1
    psi[12,8]  column_13  1
    psi[12,14]  OBJ       8.0685024827608087e-02
    psi[12,14]  column_11  1
    psi[12,14]  column_12  1
    psi[13,10]  OBJ       1
    psi[13,10]  column_0  1
    psi[13,10]  column_1  1
    psi[13,10]  column_2  1
    psi[13,10]  column_3  1
    psi[13,10]  column_4  1
    psi[13,10]  column_5  1
    psi[13,10]  column_6  1
    psi[13,10]  column_7  1
    psi[13,10]  column_8  1
    psi[13,10]  column_9  1
    psi[13,10]  column_10  1
    psi[13,10]  column_11  1
    psi[13,10]  column_12  1
    psi[13,10]  column_13  1
    psi[14,10]  OBJ       1
    psi[14,10]  column_0  1
    psi[14,10]  column_1  1
    psi[14,10]  column_2  1
    psi[14,10]  column_3  1
    psi[14,10]  column_4  1
    psi[14,10]  column_5  1
    psi[14,10]  column_6  1
    psi[14,10]  column_7  1
    psi[14,10]  column_8  1
    psi[14,10]  column_9  1
    psi[14,10]  column_10  1
    psi[14,10]  column_11  1
    psi[14,10]  column_12  1
    psi[14,10]  column_13  1
    psi[15,10]  OBJ       1
    psi[15,10]  column_0  1
    psi[15,10]  column_1  1
    psi[15,10]  column_2  1
    psi[15,10]  column_3  1
    psi[15,10]  column_4  1
    psi[15,10]  column_5  1
    psi[15,10]  column_6  1
    psi[15,10]  column_7  1
    psi[15,10]  column_8  1
    psi[15,10]  column_9  1
    psi[15,10]  column_10  1
    psi[15,10]  column_11  1
    psi[15,10]  column_12  1
    psi[15,10]  column_13  1
    psi[16,3]  OBJ       9.0248441601798512e-01
    psi[16,3]  column_0  1
    psi[16,3]  column_1  1
    psi[16,3]  column_2  1
    psi[16,3]  column_3  1
    psi[16,3]  column_4  1
    psi[16,3]  column_5  1
    psi[16,3]  column_6  1
    psi[16,3]  column_7  1
    psi[16,3]  column_8  1
    psi[16,3]  column_9  1
    psi[16,3]  column_11  1
    psi[16,3]  column_12  1
    psi[16,3]  column_13  1
    psi[16,11]  OBJ       9.7515583982014931e-02
    psi[16,11]  column_10  1
    psi[17,16]  OBJ       1
    psi[17,16]  column_0  1
    psi[17,16]  column_1  1
    psi[17,16]  column_2  1
    psi[17,16]  column_3  1
    psi[17,16]  column_4  1
    psi[17,16]  column_5  1
    psi[17,16]  column_6  1
    psi[17,16]  column_7  1
    psi[17,16]  column_8  1
    psi[17,16]  column_9  1
    psi[17,16]  column_10  1
    psi[17,16]  column_11  1
    psi[17,16]  column_12  1
    psi[17,16]  column_13  1
    psi[18,7]  OBJ       1
    psi[18,7]  column_0  1
    psi[18,7]  column_1  1
    psi[18,7]  column_2  1
    psi[18,7]  column_3  1
    psi[18,7]  column_4  1
    psi[18,7]  column_5  1
    psi[18,7]  column_6  1
    psi[18,7]  column_7  1
    psi[18,7]  column_8  1
    psi[18,7]  column_9  1
    psi[18,7]  column_10  1
    psi[18,7]  column_11  1
    psi[18,7]  column_12  1
    psi[18,7]  column_13  1
    psi[19,9]  OBJ       1
    psi[19,9]  column_0  1
    psi[19,9]  column_1  1
    psi[19,9]  column_2  1
    psi[19,9]  column_3  1
    psi[19,9]  column_4  1
    psi[19,9]  column_5  1
    psi[19,9]  column_6  1
    psi[19,9]  column_7  1
    psi[19,9]  column_8  1
    psi[19,9]  column_9  1
    psi[19,9]  column_10  1
    psi[19,9]  column_11  1
    psi[19,9]  column_12  1
    psi[19,9]  column_13  1
    psi[20,7]  OBJ       1
    psi[20,7]  column_0  1
    psi[20,7]  column_1  1
    psi[20,7]  column_2  1
    psi[20,7]  column_3  1
    psi[20,7]  column_4  1
    psi[20,7]  column_5  1
    psi[20,7]  column_6  1
    psi[20,7]  column_7  1
    psi[20,7]  column_8  1
    psi[20,7]  column_9  1
    psi[20,7]  column_10  1
    psi[20,7]  column_11  1
    psi[20,7]  column_12  1
    psi[20,7]  column_13  1
    psi[21,9]  OBJ       1
    psi[21,9]  column_0  1
    psi[21,9]  column_1  1
    psi[21,9]  column_2  1
    psi[21,9]  column_3  1
    psi[21,9]  column_4  1
    psi[21,9]  column_5  1
    psi[21,9]  column_6  1
    psi[21,9]  column_7  1
    psi[21,9]  column_8  1
    psi[21,9]  column_9  1
    psi[21,9]  column_10  1
    psi[21,9]  column_11  1
    psi[21,9]  column_12  1
    psi[21,9]  column_13  1
    psi[22,10]  OBJ       1
    psi[22,10]  column_0  1
    psi[22,10]  column_1  1
    psi[22,10]  column_2  1
    psi[22,10]  column_3  1
    psi[22,10]  column_4  1
    psi[22,10]  column_5  1
    psi[22,10]  column_6  1
    psi[22,10]  column_7  1
    psi[22,10]  column_8  1
    psi[22,10]  column_9  1
    psi[22,10]  column_10  1
    psi[22,10]  column_11  1
    psi[22,10]  column_12  1
    psi[22,10]  column_13  1
    psi[23,8]  OBJ       9.0317797020687041e-01
    psi[23,8]  column_0  1
    psi[23,8]  column_1  1
    psi[23,8]  column_2  1
    psi[23,8]  column_3  1
    psi[23,8]  column_4  1
    psi[23,8]  column_5  1
    psi[23,8]  column_6  1
    psi[23,8]  column_7  1
    psi[23,8]  column_8  1
    psi[23,8]  column_10  1
    psi[23,13]  OBJ       9.6822029793129621e-02
    psi[23,13]  column_9  1
    psi[23,13]  column_11  1
    psi[23,13]  column_12  1
    psi[23,13]  column_13  1
    psi[24,2]  OBJ       4.9125849442228409e-01
    psi[24,2]  column_1  1
    psi[24,2]  column_3  1
    psi[24,2]  column_9  1
    psi[24,2]  column_10  1
    psi[24,4]  OBJ       1.0160812175664766e-02
    psi[24,4]  column_4  1
    psi[24,5]  OBJ       2.1497287217362712e-01
    psi[24,5]  column_0  1
    psi[24,5]  column_5  1
    psi[24,5]  column_6  1
    psi[24,6]  OBJ       1.8079493099633581e-01
    psi[24,6]  column_7  1
    psi[24,7]  OBJ       5.2973062500732008e-03
    psi[24,7]  column_8  1
    psi[24,8]  OBJ       9.7515583982014931e-02
    psi[24,8]  column_2  1
    psi[24,8]  column_11  1
    psi[24,8]  column_12  1
    psi[24,8]  column_13  1
    psi[25,7]  OBJ       1
    psi[25,7]  column_0  1
    psi[25,7]  column_1  1
    psi[25,7]  column_2  1
    psi[25,7]  column_3  1
    psi[25,7]  column_4  1
    psi[25,7]  column_5  1
    psi[25,7]  column_6  1
    psi[25,7]  column_7  1
    psi[25,7]  column_8  1
    psi[25,7]  column_9  1
    psi[25,7]  column_10  1
    psi[25,7]  column_11  1
    psi[25,7]  column_12  1
    psi[25,7]  column_13  1
    psi[26,8]  OBJ       9.0317797020687030e-01
    psi[26,8]  column_0  1
    psi[26,8]  column_1  1
    psi[26,8]  column_2  1
    psi[26,8]  column_3  1
    psi[26,8]  column_4  1
    psi[26,8]  column_5  1
    psi[26,8]  column_7  1
    psi[26,8]  column_8  1
    psi[26,8]  column_9  1
    psi[26,8]  column_10  1
    psi[26,8]  column_11  1
    psi[26,8]  column_12  1
    psi[26,8]  column_13  1
    psi[26,13]  OBJ       0.0968220297931297
    psi[26,13]  column_6  1
    psi[27,9]  OBJ       1
    psi[27,9]  column_0  1
    psi[27,9]  column_1  1
    psi[27,9]  column_2  1
    psi[27,9]  column_3  1
    psi[27,9]  column_4  1
    psi[27,9]  column_5  1
    psi[27,9]  column_6  1
    psi[27,9]  column_7  1
    psi[27,9]  column_8  1
    psi[27,9]  column_9  1
    psi[27,9]  column_10  1
    psi[27,9]  column_11  1
    psi[27,9]  column_12  1
    psi[27,9]  column_13  1
    psi[28,7]  OBJ       1
    psi[28,7]  column_0  1
    psi[28,7]  column_1  1
    psi[28,7]  column_2  1
    psi[28,7]  column_3  1
    psi[28,7]  column_4  1
    psi[28,7]  column_5  1
    psi[28,7]  column_6  1
    psi[28,7]  column_7  1
    psi[28,7]  column_8  1
    psi[28,7]  column_9  1
    psi[28,7]  column_10  1
    psi[28,7]  column_11  1
    psi[28,7]  column_12  1
    psi[28,7]  column_13  1
    psi[29,7]  OBJ       1
    psi[29,7]  column_0  1
    psi[29,7]  column_1  1
    psi[29,7]  column_2  1
    psi[29,7]  column_3  1
    psi[29,7]  column_4  1
    psi[29,7]  column_5  1
    psi[29,7]  column_6  1
    psi[29,7]  column_7  1
    psi[29,7]  column_8  1
    psi[29,7]  column_9  1
    psi[29,7]  column_10  1
    psi[29,7]  column_11  1
    psi[29,7]  column_12  1
    psi[29,7]  column_13  1
    psi[30,11]  OBJ       1
    psi[30,11]  column_0  1
    psi[30,11]  column_1  1
    psi[30,11]  column_2  1
    psi[30,11]  column_3  1
    psi[30,11]  column_4  1
    psi[30,11]  column_5  1
    psi[30,11]  column_6  1
    psi[30,11]  column_7  1
    psi[30,11]  column_8  1
    psi[30,11]  column_9  1
    psi[30,11]  column_10  1
    psi[30,11]  column_11  1
    psi[30,11]  column_12  1
    psi[30,11]  column_13  1
    psi[31,7]  OBJ       1
    psi[31,7]  column_0  1
    psi[31,7]  column_1  1
    psi[31,7]  column_2  1
    psi[31,7]  column_3  1
    psi[31,7]  column_4  1
    psi[31,7]  column_5  1
    psi[31,7]  column_6  1
    psi[31,7]  column_7  1
    psi[31,7]  column_8  1
    psi[31,7]  column_9  1
    psi[31,7]  column_10  1
    psi[31,7]  column_11  1
    psi[31,7]  column_12  1
    psi[31,7]  column_13  1
    psi[32,8]  OBJ       1
    psi[32,8]  column_0  1
    psi[32,8]  column_1  1
    psi[32,8]  column_2  1
    psi[32,8]  column_3  1
    psi[32,8]  column_4  1
    psi[32,8]  column_5  1
    psi[32,8]  column_6  1
    psi[32,8]  column_7  1
    psi[32,8]  column_8  1
    psi[32,8]  column_9  1
    psi[32,8]  column_10  1
    psi[32,8]  column_11  1
    psi[32,8]  column_12  1
    psi[32,8]  column_13  1
    psi[33,13]  OBJ       1
    psi[33,13]  column_0  1
    psi[33,13]  column_1  1
    psi[33,13]  column_2  1
    psi[33,13]  column_3  1
    psi[33,13]  column_4  1
    psi[33,13]  column_5  1
    psi[33,13]  column_6  1
    psi[33,13]  column_7  1
    psi[33,13]  column_8  1
    psi[33,13]  column_9  1
    psi[33,13]  column_10  1
    psi[33,13]  column_11  1
    psi[33,13]  column_12  1
    psi[33,13]  column_13  1
    psi[34,8]  OBJ       1
    psi[34,8]  column_0  1
    psi[34,8]  column_1  1
    psi[34,8]  column_2  1
    psi[34,8]  column_3  1
    psi[34,8]  column_4  1
    psi[34,8]  column_5  1
    psi[34,8]  column_6  1
    psi[34,8]  column_7  1
    psi[34,8]  column_8  1
    psi[34,8]  column_9  1
    psi[34,8]  column_10  1
    psi[34,8]  column_11  1
    psi[34,8]  column_12  1
    psi[34,8]  column_13  1
    psi[35,9]  OBJ       1
    psi[35,9]  column_0  1
    psi[35,9]  column_1  1
    psi[35,9]  column_2  1
    psi[35,9]  column_3  1
    psi[35,9]  column_4  1
    psi[35,9]  column_5  1
    psi[35,9]  column_6  1
    psi[35,9]  column_7  1
    psi[35,9]  column_8  1
    psi[35,9]  column_9  1
    psi[35,9]  column_10  1
    psi[35,9]  column_11  1
    psi[35,9]  column_12  1
    psi[35,9]  column_13  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
RHS
    RHS1      column_0  1.0030089880127373e-01
    RHS1      column_1  1.0297492506569134e-01
    RHS1      column_2  1.1237277092123660e-01
    RHS1      column_3  9.4844902442851931e-02
    RHS1      column_4  8.1964148742112039e-02
    RHS1      column_5  8.7434037255949865e-02
    RHS1      column_6  1.0038066097588205e-01
    RHS1      column_7  9.2827272380613446e-02
    RHS1      column_8  9.8145454201207349e-02
    RHS1      column_9  1.0834001050148612e-01
    RHS1      column_10  1.1139806990349520e-01
    RHS1      column_11  1.4155692546551771e-01
    RHS1      column_12  1.4155692546551771e-01
    RHS1      column_13  1.4334723144102235e-01
BOUNDS
 FX BND1      psi[1,4]  0
 FX BND1      psi[2,12]  0
 FX BND1      psi[3,13]  0
 FX BND1      psi[4,7]  0
 LO BND1      psi[4,13]  -0.05
 UP BND1      psi[4,13]  0.05
 FX BND1      psi[5,8]  0
 FX BND1      psi[6,4]  0
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,7]  0
 LO BND1      psi[8,13]  -0.05
 UP BND1      psi[8,13]  0.05
 LO BND1      psi[9,5]  -0.05
 UP BND1      psi[9,5]  0.05
 FX BND1      psi[9,10]  0
 LO BND1      psi[10,4]  -0.05
 UP BND1      psi[10,4]  0.05
 FX BND1      psi[10,6]  0
 FX BND1      psi[11,7]  0
 FX BND1      psi[12,8]  0
 LO BND1      psi[12,14]  -0.05
 UP BND1      psi[12,14]  0.05
 FX BND1      psi[13,10]  0
 FX BND1      psi[14,10]  0
 FX BND1      psi[15,10]  0
 FX BND1      psi[16,3]  0
 LO BND1      psi[16,11]  -0.05
 UP BND1      psi[16,11]  0.05
 FX BND1      psi[17,16]  0
 FX BND1      psi[18,7]  0
 FX BND1      psi[19,9]  0
 FX BND1      psi[20,7]  0
 FX BND1      psi[21,9]  0
 FX BND1      psi[22,10]  0
 FX BND1      psi[23,8]  0
 LO BND1      psi[23,13]  -0.05
 UP BND1      psi[23,13]  0.05
 FX BND1      psi[24,2]  0
 LO BND1      psi[24,4]  -0.05
 UP BND1      psi[24,4]  0.05
 LO BND1      psi[24,5]  -0.05
 UP BND1      psi[24,5]  0.05
 LO BND1      psi[24,6]  -0.05
 UP BND1      psi[24,6]  0.05
 LO BND1      psi[24,7]  -0.05
 UP BND1      psi[24,7]  0.05
 LO BND1      psi[24,8]  -0.05
 UP BND1      psi[24,8]  0.05
 FX BND1      psi[25,7]  0
 FX BND1      psi[26,8]  0
 LO BND1      psi[26,13]  -0.05
 UP BND1      psi[26,13]  0.05
 FX BND1      psi[27,9]  0
 FX BND1      psi[28,7]  0
 FX BND1      psi[29,7]  0
 FX BND1      psi[30,11]  0
 FX BND1      psi[31,7]  0
 FX BND1      psi[32,8]  0
 FX BND1      psi[33,13]  0
 FX BND1      psi[34,8]  0
 FX BND1      psi[35,9]  0
 FR BND1      a       
ENDATA
