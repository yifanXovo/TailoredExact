* Signature: 0xa5866e1af0a2d27
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 E  onehot_19_18
 E  normalized_mass_19_19
 E  normalized_ratio_19_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 E  onehot_17_55
 E  normalized_mass_17_56
 E  normalized_ratio_17_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 E  onehot_31_84
 E  normalized_mass_31_85
 E  normalized_ratio_31_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 E  onehot_15_121
 E  normalized_mass_15_122
 E  normalized_ratio_15_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 E  onehot_2_156
 E  normalized_mass_2_157
 E  normalized_ratio_2_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 E  onehot_13_199
 E  normalized_mass_13_200
 E  normalized_ratio_13_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 E  onehot_6_224
 E  normalized_mass_6_225
 E  normalized_ratio_6_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 E  onehot_9_253
 E  normalized_mass_9_254
 E  normalized_ratio_9_255
 G  stock_lb_256
 L  stock_ub_257
 L  parent_nonstrict_scope_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 E  normalization_315
 G  full_original_Gini_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 L  arc_capacity_425
 L  arc_capacity_426
 L  arc_capacity_427
 L  arc_capacity_428
 L  arc_capacity_429
 L  arc_capacity_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 E  depot_departure_or_bypass_714
 E  depot_return_or_bypass_715
 E  out_degree_716
 E  in_degree_717
 G  order_active_lb_718
 L  order_active_ub_719
 E  segment_load_conservation_720
 G  segment_prefix_lb_721
 L  segment_prefix_ub_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  segment_load_conservation_727
 G  segment_prefix_lb_728
 L  segment_prefix_ub_729
 E  out_degree_730
 E  in_degree_731
 G  order_active_lb_732
 L  order_active_ub_733
 E  segment_load_conservation_734
 G  segment_prefix_lb_735
 L  segment_prefix_ub_736
 E  out_degree_737
 E  in_degree_738
 G  order_active_lb_739
 L  order_active_ub_740
 E  segment_load_conservation_741
 G  segment_prefix_lb_742
 L  segment_prefix_ub_743
 E  out_degree_744
 E  in_degree_745
 G  order_active_lb_746
 L  order_active_ub_747
 E  service_visit_def_748
 E  free_load_conservation_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  service_visit_def_754
 E  free_load_conservation_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 E  out_degree_780
 E  in_degree_781
 G  order_active_lb_782
 L  order_active_ub_783
 E  service_visit_def_784
 E  free_load_conservation_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 G  fixed_segment_relative_order_792
 G  fixed_segment_relative_order_793
 G  fixed_segment_relative_order_794
 L  original_T_including_depot_unload_795
 L  arc_capacity_796
 L  arc_capacity_797
 L  arc_capacity_798
 L  arc_capacity_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 L  arc_capacity_803
 L  arc_capacity_804
 L  arc_capacity_805
 L  arc_capacity_806
 L  arc_capacity_807
 L  arc_capacity_808
 L  arc_capacity_809
 L  arc_capacity_810
 G  connected_order_arc_811
 L  arc_capacity_812
 G  connected_order_arc_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 E  depot_departure_or_bypass_1085
 E  depot_return_or_bypass_1086
 E  out_degree_1087
 E  in_degree_1088
 G  order_active_lb_1089
 L  order_active_ub_1090
 E  segment_load_conservation_1091
 G  segment_prefix_lb_1092
 L  segment_prefix_ub_1093
 E  out_degree_1094
 E  in_degree_1095
 G  order_active_lb_1096
 L  order_active_ub_1097
 E  segment_load_conservation_1098
 G  segment_prefix_lb_1099
 L  segment_prefix_ub_1100
 E  out_degree_1101
 E  in_degree_1102
 G  order_active_lb_1103
 L  order_active_ub_1104
 E  segment_load_conservation_1105
 G  segment_prefix_lb_1106
 L  segment_prefix_ub_1107
 E  out_degree_1108
 E  in_degree_1109
 G  order_active_lb_1110
 L  order_active_ub_1111
 E  segment_load_conservation_1112
 G  segment_prefix_lb_1113
 L  segment_prefix_ub_1114
 E  out_degree_1115
 E  in_degree_1116
 G  order_active_lb_1117
 L  order_active_ub_1118
 E  service_visit_def_1119
 E  free_load_conservation_1120
 E  out_degree_1121
 E  in_degree_1122
 G  order_active_lb_1123
 L  order_active_ub_1124
 E  service_visit_def_1125
 E  free_load_conservation_1126
 E  out_degree_1127
 E  in_degree_1128
 G  order_active_lb_1129
 L  order_active_ub_1130
 E  service_visit_def_1131
 E  free_load_conservation_1132
 E  out_degree_1133
 E  in_degree_1134
 G  order_active_lb_1135
 L  order_active_ub_1136
 E  service_visit_def_1137
 E  free_load_conservation_1138
 E  out_degree_1139
 E  in_degree_1140
 G  order_active_lb_1141
 L  order_active_ub_1142
 E  service_visit_def_1143
 E  free_load_conservation_1144
 E  out_degree_1145
 E  in_degree_1146
 G  order_active_lb_1147
 L  order_active_ub_1148
 E  service_visit_def_1149
 E  free_load_conservation_1150
 E  out_degree_1151
 E  in_degree_1152
 G  order_active_lb_1153
 L  order_active_ub_1154
 E  service_visit_def_1155
 E  free_load_conservation_1156
 E  out_degree_1157
 E  in_degree_1158
 G  order_active_lb_1159
 L  order_active_ub_1160
 E  service_visit_def_1161
 E  free_load_conservation_1162
 G  fixed_segment_relative_order_1163
 G  fixed_segment_relative_order_1164
 G  fixed_segment_relative_order_1165
 L  original_T_including_depot_unload_1166
 L  arc_capacity_1167
 L  arc_capacity_1168
 L  arc_capacity_1169
 L  arc_capacity_1170
 L  arc_capacity_1171
 L  arc_capacity_1172
 L  arc_capacity_1173
 L  arc_capacity_1174
 L  arc_capacity_1175
 L  arc_capacity_1176
 L  arc_capacity_1177
 L  arc_capacity_1178
 L  arc_capacity_1179
 L  arc_capacity_1180
 G  connected_order_arc_1181
 L  arc_capacity_1182
 G  connected_order_arc_1183
 L  arc_capacity_1184
 G  connected_order_arc_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 E  depot_departure_or_bypass_1410
 E  depot_return_or_bypass_1411
 E  out_degree_1412
 E  in_degree_1413
 G  order_active_lb_1414
 L  order_active_ub_1415
 E  segment_load_conservation_1416
 G  segment_prefix_lb_1417
 L  segment_prefix_ub_1418
 E  out_degree_1419
 E  in_degree_1420
 G  order_active_lb_1421
 L  order_active_ub_1422
 E  segment_load_conservation_1423
 G  segment_prefix_lb_1424
 L  segment_prefix_ub_1425
 E  out_degree_1426
 E  in_degree_1427
 G  order_active_lb_1428
 L  order_active_ub_1429
 E  segment_load_conservation_1430
 G  segment_prefix_lb_1431
 L  segment_prefix_ub_1432
 E  out_degree_1433
 E  in_degree_1434
 G  order_active_lb_1435
 L  order_active_ub_1436
 E  service_visit_def_1437
 E  free_load_conservation_1438
 E  out_degree_1439
 E  in_degree_1440
 G  order_active_lb_1441
 L  order_active_ub_1442
 E  service_visit_def_1443
 E  free_load_conservation_1444
 E  out_degree_1445
 E  in_degree_1446
 G  order_active_lb_1447
 L  order_active_ub_1448
 E  service_visit_def_1449
 E  free_load_conservation_1450
 E  out_degree_1451
 E  in_degree_1452
 G  order_active_lb_1453
 L  order_active_ub_1454
 E  service_visit_def_1455
 E  free_load_conservation_1456
 E  out_degree_1457
 E  in_degree_1458
 G  order_active_lb_1459
 L  order_active_ub_1460
 E  service_visit_def_1461
 E  free_load_conservation_1462
 E  out_degree_1463
 E  in_degree_1464
 G  order_active_lb_1465
 L  order_active_ub_1466
 E  service_visit_def_1467
 E  free_load_conservation_1468
 E  out_degree_1469
 E  in_degree_1470
 G  order_active_lb_1471
 L  order_active_ub_1472
 E  service_visit_def_1473
 E  free_load_conservation_1474
 E  out_degree_1475
 E  in_degree_1476
 G  order_active_lb_1477
 L  order_active_ub_1478
 E  service_visit_def_1479
 E  free_load_conservation_1480
 G  fixed_segment_relative_order_1481
 G  fixed_segment_relative_order_1482
 L  original_T_including_depot_unload_1483
COLUMNS
    t         normalized_mass_19_19  -1
    t         normalized_mass_17_56  -1
    t         normalized_mass_31_85  -1
    t         normalized_mass_15_122  -1
    t         normalized_mass_2_157  -1
    t         normalized_mass_13_200  -1
    t         normalized_mass_6_225  -1
    t         normalized_mass_9_254  -1
    t         normalization_315  2.3528571428571428e+01
    t         full_original_Gini_316  -9.0135714285714329e+01
    q         OBJ       1
    q         parent_nonstrict_scope_258  1
    q         full_original_Gini_316  35
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_0  -2.5178598191512011e-02
    x_19_0    product_ub_1  -4.2501517911396489e-02
    x_19_0    onehot_19_18  1
    x_19_0    parent_nonstrict_scope_258  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_0  1
    w_19_0    product_ub_1  1
    w_19_0    normalized_mass_19_19  1
    w_19_0    full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_2  -2.5178598191512011e-02
    x_19_1    product_ub_3  -4.2501517911396489e-02
    x_19_1    onehot_19_18  1
    x_19_1    stock_lb_256  1
    x_19_1    stock_ub_257  1
    x_19_1    parent_nonstrict_scope_258  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_2  1
    w_19_1    product_ub_3  1
    w_19_1    normalized_mass_19_19  1
    w_19_1    normalized_ratio_19_20  -0.25
    w_19_1    full_original_Gini_316  -1.6878571428571430e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_4  -2.5178598191512011e-02
    x_19_2    product_ub_5  -4.2501517911396489e-02
    x_19_2    onehot_19_18  1
    x_19_2    stock_lb_256  2
    x_19_2    stock_ub_257  2
    x_19_2    parent_nonstrict_scope_258  0.012
    x_19_2    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_4  1
    w_19_2    product_ub_5  1
    w_19_2    normalized_mass_19_19  1
    w_19_2    normalized_ratio_19_20  -0.5
    w_19_2    full_original_Gini_316  -1.1328571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_6  -2.5178598191512011e-02
    x_19_3    product_ub_7  -4.2501517911396489e-02
    x_19_3    onehot_19_18  1
    x_19_3    stock_lb_256  3
    x_19_3    stock_ub_257  3
    x_19_3    parent_nonstrict_scope_258  0.006
    x_19_3    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_6  1
    w_19_3    product_ub_7  1
    w_19_3    normalized_mass_19_19  1
    w_19_3    normalized_ratio_19_20  -0.75
    w_19_3    full_original_Gini_316  -6.6499999999999995e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_8  -2.5178598191512011e-02
    x_19_4    product_ub_9  -4.2501517911396489e-02
    x_19_4    onehot_19_18  1
    x_19_4    stock_lb_256  4
    x_19_4    stock_ub_257  4
    x_19_4    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_8  1
    w_19_4    product_ub_9  1
    w_19_4    normalized_mass_19_19  1
    w_19_4    normalized_ratio_19_20  -1
    w_19_4    full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_10  -2.5178598191512011e-02
    x_19_5    product_ub_11  -4.2501517911396489e-02
    x_19_5    onehot_19_18  1
    x_19_5    stock_lb_256  5
    x_19_5    stock_ub_257  5
    x_19_5    parent_nonstrict_scope_258  0.006
    x_19_5    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_10  1
    w_19_5    product_ub_11  1
    w_19_5    normalized_mass_19_19  1
    w_19_5    normalized_ratio_19_20  -1.25
    w_19_5    full_original_Gini_316  -1.0221428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_12  -2.5178598191512011e-02
    x_19_6    product_ub_13  -4.2501517911396489e-02
    x_19_6    onehot_19_18  1
    x_19_6    stock_lb_256  6
    x_19_6    stock_ub_257  6
    x_19_6    parent_nonstrict_scope_258  0.012
    x_19_6    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_12  1
    w_19_6    product_ub_13  1
    w_19_6    normalized_mass_19_19  1
    w_19_6    normalized_ratio_19_20  -1.5
    w_19_6    full_original_Gini_316  -1.6971428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_14  -2.5178598191512011e-02
    x_19_7    product_ub_15  -4.2501517911396489e-02
    x_19_7    onehot_19_18  1
    x_19_7    stock_lb_256  7
    x_19_7    stock_ub_257  7
    x_19_7    parent_nonstrict_scope_258  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_14  1
    w_19_7    product_ub_15  1
    w_19_7    normalized_mass_19_19  1
    w_19_7    normalized_ratio_19_20  -1.75
    w_19_7    full_original_Gini_316  -2.3721428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_16  -2.5178598191512011e-02
    x_19_8    product_ub_17  -4.2501517911396489e-02
    x_19_8    onehot_19_18  1
    x_19_8    stock_lb_256  8
    x_19_8    stock_ub_257  8
    x_19_8    parent_nonstrict_scope_258  0.024
    x_19_8    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_16  1
    w_19_8    product_ub_17  1
    w_19_8    normalized_mass_19_19  1
    w_19_8    normalized_ratio_19_20  -2
    w_19_8    full_original_Gini_316  -3.0471428571428572e+01
    rho_19    normalized_ratio_19_20  1
    rho_19    block_pair_pos_291  -1
    rho_19    block_pair_neg_292  1
    rho_19    block_pair_pos_293  -1
    rho_19    block_pair_neg_294  1
    rho_19    block_pair_pos_295  -1
    rho_19    block_pair_neg_296  1
    rho_19    block_pair_pos_297  -1
    rho_19    block_pair_neg_298  1
    rho_19    block_pair_pos_299  -1
    rho_19    block_pair_neg_300  1
    rho_19    block_pair_pos_301  -1
    rho_19    block_pair_neg_302  1
    rho_19    block_pair_pos_303  -1
    rho_19    block_pair_neg_304  1
    rho_19    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       0.06075
    x_17_0    product_lb_21  -2.5178598191512011e-02
    x_17_0    product_ub_22  -4.2501517911396489e-02
    x_17_0    onehot_17_55  1
    x_17_0    parent_nonstrict_scope_258  0.1215
    x_17_0    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_21  1
    w_17_0    product_ub_22  1
    w_17_0    normalized_mass_17_56  1
    w_17_0    full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.7249999999999986e-02
    x_17_1    product_lb_23  -2.5178598191512011e-02
    x_17_1    product_ub_24  -4.2501517911396489e-02
    x_17_1    onehot_17_55  1
    x_17_1    stock_lb_256  1
    x_17_1    stock_ub_257  1
    x_17_1    parent_nonstrict_scope_258  1.0799999999999998e-01
    x_17_1    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_23  1
    w_17_1    product_ub_24  1
    w_17_1    normalized_mass_17_56  1
    w_17_1    normalized_ratio_17_57  -1.1111111111111110e-01
    w_17_1    full_original_Gini_316  -2.0528571428571432e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       0.03375
    x_17_2    product_lb_25  -2.5178598191512011e-02
    x_17_2    product_ub_26  -4.2501517911396489e-02
    x_17_2    onehot_17_55  1
    x_17_2    stock_lb_256  2
    x_17_2    stock_ub_257  2
    x_17_2    parent_nonstrict_scope_258  0.0945
    x_17_2    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_25  1
    w_17_2    product_ub_26  1
    w_17_2    normalized_mass_17_56  1
    w_17_2    normalized_ratio_17_57  -2.2222222222222221e-01
    w_17_2    full_original_Gini_316  -1.7573015873015880e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.0250000000000004e-02
    x_17_3    product_lb_27  -2.5178598191512011e-02
    x_17_3    product_ub_28  -4.2501517911396489e-02
    x_17_3    onehot_17_55  1
    x_17_3    stock_lb_256  3
    x_17_3    stock_ub_257  3
    x_17_3    parent_nonstrict_scope_258  0.081
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_27  1
    w_17_3    product_ub_28  1
    w_17_3    normalized_mass_17_56  1
    w_17_3    normalized_ratio_17_57  -3.3333333333333331e-01
    w_17_3    full_original_Gini_316  -1.4961904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       6.7500000000000060e-03
    x_17_4    product_lb_29  -2.5178598191512011e-02
    x_17_4    product_ub_30  -4.2501517911396489e-02
    x_17_4    onehot_17_55  1
    x_17_4    stock_lb_256  4
    x_17_4    stock_ub_257  4
    x_17_4    parent_nonstrict_scope_258  0.0675
    x_17_4    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_29  1
    w_17_4    product_ub_30  1
    w_17_4    normalized_mass_17_56  1
    w_17_4    normalized_ratio_17_57  -4.4444444444444442e-01
    w_17_4    full_original_Gini_316  -1.2495238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -6.7500000000000060e-03
    x_17_5    product_lb_31  -2.5178598191512011e-02
    x_17_5    product_ub_32  -4.2501517911396489e-02
    x_17_5    onehot_17_55  1
    x_17_5    stock_lb_256  5
    x_17_5    stock_ub_257  5
    x_17_5    parent_nonstrict_scope_258  5.3999999999999992e-02
    x_17_5    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_31  1
    w_17_5    product_ub_32  1
    w_17_5    normalized_mass_17_56  1
    w_17_5    normalized_ratio_17_57  -5.5555555555555558e-01
    w_17_5    full_original_Gini_316  -1.0273015873015876e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.0249999999999997e-02
    x_17_6    product_lb_33  -2.5178598191512011e-02
    x_17_6    product_ub_34  -4.2501517911396489e-02
    x_17_6    onehot_17_55  1
    x_17_6    stock_lb_256  6
    x_17_6    stock_ub_257  6
    x_17_6    parent_nonstrict_scope_258  0.0405
    x_17_6    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_33  1
    w_17_6    product_ub_34  1
    w_17_6    normalized_mass_17_56  1
    w_17_6    normalized_ratio_17_57  -6.6666666666666663e-01
    w_17_6    full_original_Gini_316  -8.1619047619047613e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.3749999999999988e-02
    x_17_7    product_lb_35  -2.5178598191512011e-02
    x_17_7    product_ub_36  -4.2501517911396489e-02
    x_17_7    onehot_17_55  1
    x_17_7    stock_lb_256  7
    x_17_7    stock_ub_257  7
    x_17_7    parent_nonstrict_scope_258  2.7000000000000010e-02
    x_17_7    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_35  1
    w_17_7    product_ub_36  1
    w_17_7    normalized_mass_17_56  1
    w_17_7    normalized_ratio_17_57  -7.7777777777777768e-01
    w_17_7    full_original_Gini_316  -6.2333333333333343e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.7249999999999993e-02
    x_17_8    product_lb_37  -2.5178598191512011e-02
    x_17_8    product_ub_38  -4.2501517911396489e-02
    x_17_8    onehot_17_55  1
    x_17_8    stock_lb_256  8
    x_17_8    stock_ub_257  8
    x_17_8    parent_nonstrict_scope_258  1.3500000000000005e-02
    x_17_8    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_37  1
    w_17_8    product_ub_38  1
    w_17_8    normalized_mass_17_56  1
    w_17_8    normalized_ratio_17_57  -8.8888888888888884e-01
    w_17_8    full_original_Gini_316  -4.9269841269841272e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -0.06075
    x_17_9    product_lb_39  -2.5178598191512011e-02
    x_17_9    product_ub_40  -4.2501517911396489e-02
    x_17_9    onehot_17_55  1
    x_17_9    stock_lb_256  9
    x_17_9    stock_ub_257  9
    x_17_9    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_39  1
    w_17_9    product_ub_40  1
    w_17_9    normalized_mass_17_56  1
    w_17_9    normalized_ratio_17_57  -1
    w_17_9    full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.7249999999999993e-02
    x_17_10   product_lb_41  -2.5178598191512011e-02
    x_17_10   product_ub_42  -4.2501517911396489e-02
    x_17_10   onehot_17_55  1
    x_17_10   stock_lb_256  10
    x_17_10   stock_ub_257  10
    x_17_10   parent_nonstrict_scope_258  1.3500000000000005e-02
    x_17_10   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_41  1
    w_17_10   product_ub_42  1
    w_17_10   normalized_mass_17_56  1
    w_17_10   normalized_ratio_17_57  -1.1111111111111112e+00
    w_17_10   full_original_Gini_316  -6.9269841269841272e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.3750000000000016e-02
    x_17_11   product_lb_43  -2.5178598191512011e-02
    x_17_11   product_ub_44  -4.2501517911396489e-02
    x_17_11   onehot_17_55  1
    x_17_11   stock_lb_256  11
    x_17_11   stock_ub_257  11
    x_17_11   parent_nonstrict_scope_258  2.6999999999999986e-02
    x_17_11   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_43  1
    w_17_11   product_ub_44  1
    w_17_11   normalized_mass_17_56  1
    w_17_11   normalized_ratio_17_57  -1.2222222222222221e+00
    w_17_11   full_original_Gini_316  -9.5269841269841269e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.0250000000000011e-02
    x_17_12   product_lb_45  -2.5178598191512011e-02
    x_17_12   product_ub_46  -4.2501517911396489e-02
    x_17_12   onehot_17_55  1
    x_17_12   stock_lb_256  12
    x_17_12   stock_ub_257  12
    x_17_12   parent_nonstrict_scope_258  4.0499999999999987e-02
    x_17_12   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_45  1
    w_17_12   product_ub_46  1
    w_17_12   normalized_mass_17_56  1
    w_17_12   normalized_ratio_17_57  -1.3333333333333333e+00
    w_17_12   full_original_Gini_316  -1.2471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -6.7500000000000060e-03
    x_17_13   product_lb_47  -2.5178598191512011e-02
    x_17_13   product_ub_48  -4.2501517911396489e-02
    x_17_13   onehot_17_55  1
    x_17_13   stock_lb_256  13
    x_17_13   stock_ub_257  13
    x_17_13   parent_nonstrict_scope_258  5.3999999999999992e-02
    x_17_13   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_47  1
    w_17_13   product_ub_48  1
    w_17_13   normalized_mass_17_56  1
    w_17_13   normalized_ratio_17_57  -1.4444444444444444e+00
    w_17_13   full_original_Gini_316  -1.5471428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       6.7499999999999782e-03
    x_17_14   product_lb_49  -2.5178598191512011e-02
    x_17_14   product_ub_50  -4.2501517911396489e-02
    x_17_14   onehot_17_55  1
    x_17_14   stock_lb_256  14
    x_17_14   stock_ub_257  14
    x_17_14   parent_nonstrict_scope_258  6.7499999999999977e-02
    x_17_14   unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_49  1
    w_17_14   product_ub_50  1
    w_17_14   normalized_mass_17_56  1
    w_17_14   normalized_ratio_17_57  -1.5555555555555554e+00
    w_17_14   full_original_Gini_316  -1.8471428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.0249999999999976e-02
    x_17_15   product_lb_51  -2.5178598191512011e-02
    x_17_15   product_ub_52  -4.2501517911396489e-02
    x_17_15   onehot_17_55  1
    x_17_15   stock_lb_256  15
    x_17_15   stock_ub_257  15
    x_17_15   parent_nonstrict_scope_258  8.0999999999999975e-02
    x_17_15   unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_51  1
    w_17_15   product_ub_52  1
    w_17_15   normalized_mass_17_56  1
    w_17_15   normalized_ratio_17_57  -1.6666666666666665e+00
    w_17_15   full_original_Gini_316  -2.1471428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.3749999999999988e-02
    x_17_16   product_lb_53  -2.5178598191512011e-02
    x_17_16   product_ub_54  -4.2501517911396489e-02
    x_17_16   onehot_17_55  1
    x_17_16   stock_lb_256  16
    x_17_16   stock_ub_257  16
    x_17_16   parent_nonstrict_scope_258  9.4499999999999987e-02
    x_17_16   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_53  1
    w_17_16   product_ub_54  1
    w_17_16   normalized_mass_17_56  1
    w_17_16   normalized_ratio_17_57  -1.7777777777777777e+00
    w_17_16   full_original_Gini_316  -2.4471428571428579e+01
    rho_17    normalized_ratio_17_57  1
    rho_17    block_pair_pos_279  -1
    rho_17    block_pair_neg_280  1
    rho_17    block_pair_pos_281  -1
    rho_17    block_pair_neg_282  1
    rho_17    block_pair_pos_283  -1
    rho_17    block_pair_neg_284  1
    rho_17    block_pair_pos_285  -1
    rho_17    block_pair_neg_286  1
    rho_17    block_pair_pos_287  -1
    rho_17    block_pair_neg_288  1
    rho_17    block_pair_pos_289  -1
    rho_17    block_pair_neg_290  1
    rho_17    block_pair_pos_301  1
    rho_17    block_pair_neg_302  -1
    rho_17    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_58  -2.5178598191512011e-02
    x_31_0    product_ub_59  -4.2501517911396489e-02
    x_31_0    onehot_31_84  1
    x_31_0    parent_nonstrict_scope_258  0.0735
    x_31_0    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_58  1
    w_31_0    product_ub_59  1
    w_31_0    normalized_mass_31_85  1
    w_31_0    full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_60  -2.5178598191512011e-02
    x_31_1    product_ub_61  -4.2501517911396489e-02
    x_31_1    onehot_31_84  1
    x_31_1    stock_lb_256  1
    x_31_1    stock_ub_257  1
    x_31_1    parent_nonstrict_scope_258  0.063
    x_31_1    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_60  1
    w_31_1    product_ub_61  1
    w_31_1    normalized_mass_31_85  1
    w_31_1    normalized_ratio_31_86  -1.4285714285714285e-01
    w_31_1    full_original_Gini_316  -1.9671428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_62  -2.5178598191512011e-02
    x_31_2    product_ub_63  -4.2501517911396489e-02
    x_31_2    onehot_31_84  1
    x_31_2    stock_lb_256  2
    x_31_2    stock_ub_257  2
    x_31_2    parent_nonstrict_scope_258  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_62  1
    w_31_2    product_ub_63  1
    w_31_2    normalized_mass_31_85  1
    w_31_2    normalized_ratio_31_86  -2.8571428571428570e-01
    w_31_2    full_original_Gini_316  -1.6057142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_64  -2.5178598191512011e-02
    x_31_3    product_ub_65  -4.2501517911396489e-02
    x_31_3    onehot_31_84  1
    x_31_3    stock_lb_256  3
    x_31_3    stock_ub_257  3
    x_31_3    parent_nonstrict_scope_258  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_64  1
    w_31_3    product_ub_65  1
    w_31_3    normalized_mass_31_85  1
    w_31_3    normalized_ratio_31_86  -4.2857142857142855e-01
    w_31_3    full_original_Gini_316  -1.2828571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_66  -2.5178598191512011e-02
    x_31_4    product_ub_67  -4.2501517911396489e-02
    x_31_4    onehot_31_84  1
    x_31_4    stock_lb_256  4
    x_31_4    stock_ub_257  4
    x_31_4    parent_nonstrict_scope_258  0.0315
    x_31_4    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_66  1
    w_31_4    product_ub_67  1
    w_31_4    normalized_mass_31_85  1
    w_31_4    normalized_ratio_31_86  -5.7142857142857140e-01
    w_31_4    full_original_Gini_316  -9.9714285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_68  -2.5178598191512011e-02
    x_31_5    product_ub_69  -4.2501517911396489e-02
    x_31_5    onehot_31_84  1
    x_31_5    stock_lb_256  5
    x_31_5    stock_ub_257  5
    x_31_5    parent_nonstrict_scope_258  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_68  1
    w_31_5    product_ub_69  1
    w_31_5    normalized_mass_31_85  1
    w_31_5    normalized_ratio_31_86  -7.1428571428571419e-01
    w_31_5    full_original_Gini_316  -7.2571428571428571e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_70  -2.5178598191512011e-02
    x_31_6    product_ub_71  -4.2501517911396489e-02
    x_31_6    onehot_31_84  1
    x_31_6    stock_lb_256  6
    x_31_6    stock_ub_257  6
    x_31_6    parent_nonstrict_scope_258  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_70  1
    w_31_6    product_ub_71  1
    w_31_6    normalized_mass_31_85  1
    w_31_6    normalized_ratio_31_86  -8.5714285714285710e-01
    w_31_6    full_original_Gini_316  -5.1571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_72  -2.5178598191512011e-02
    x_31_7    product_ub_73  -4.2501517911396489e-02
    x_31_7    onehot_31_84  1
    x_31_7    stock_lb_256  7
    x_31_7    stock_ub_257  7
    x_31_7    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_72  1
    w_31_7    product_ub_73  1
    w_31_7    normalized_mass_31_85  1
    w_31_7    normalized_ratio_31_86  -1
    w_31_7    full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_74  -2.5178598191512011e-02
    x_31_8    product_ub_75  -4.2501517911396489e-02
    x_31_8    onehot_31_84  1
    x_31_8    stock_lb_256  8
    x_31_8    stock_ub_257  8
    x_31_8    parent_nonstrict_scope_258  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_74  1
    w_31_8    product_ub_75  1
    w_31_8    normalized_mass_31_85  1
    w_31_8    normalized_ratio_31_86  -1.1428571428571428e+00
    w_31_8    full_original_Gini_316  -7.6571428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_76  -2.5178598191512011e-02
    x_31_9    product_ub_77  -4.2501517911396489e-02
    x_31_9    onehot_31_84  1
    x_31_9    stock_lb_256  9
    x_31_9    stock_ub_257  9
    x_31_9    parent_nonstrict_scope_258  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_76  1
    w_31_9    product_ub_77  1
    w_31_9    normalized_mass_31_85  1
    w_31_9    normalized_ratio_31_86  -1.2857142857142856e+00
    w_31_9    full_original_Gini_316  -1.1185714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_78  -2.5178598191512011e-02
    x_31_10   product_ub_79  -4.2501517911396489e-02
    x_31_10   onehot_31_84  1
    x_31_10   stock_lb_256  10
    x_31_10   stock_ub_257  10
    x_31_10   parent_nonstrict_scope_258  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_78  1
    w_31_10   product_ub_79  1
    w_31_10   normalized_mass_31_85  1
    w_31_10   normalized_ratio_31_86  -1.4285714285714284e+00
    w_31_10   full_original_Gini_316  -1.5042857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_80  -2.5178598191512011e-02
    x_31_11   product_ub_81  -4.2501517911396489e-02
    x_31_11   onehot_31_84  1
    x_31_11   stock_lb_256  11
    x_31_11   stock_ub_257  11
    x_31_11   parent_nonstrict_scope_258  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_80  1
    w_31_11   product_ub_81  1
    w_31_11   normalized_mass_31_85  1
    w_31_11   normalized_ratio_31_86  -1.5714285714285714e+00
    w_31_11   full_original_Gini_316  -18.9
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_82  -2.5178598191512011e-02
    x_31_12   product_ub_83  -4.2501517911396489e-02
    x_31_12   onehot_31_84  1
    x_31_12   stock_lb_256  12
    x_31_12   stock_ub_257  12
    x_31_12   parent_nonstrict_scope_258  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_82  1
    w_31_12   product_ub_83  1
    w_31_12   normalized_mass_31_85  1
    w_31_12   normalized_ratio_31_86  -1.7142857142857142e+00
    w_31_12   full_original_Gini_316  -2.2757142857142853e+01
    rho_31    normalized_ratio_31_86  1
    rho_31    block_pair_pos_289  1
    rho_31    block_pair_neg_290  -1
    rho_31    block_pair_pos_303  1
    rho_31    block_pair_neg_304  -1
    rho_31    block_pair_pos_305  -1
    rho_31    block_pair_neg_306  1
    rho_31    block_pair_pos_307  -1
    rho_31    block_pair_neg_308  1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       0.06075
    x_15_0    product_lb_87  -2.5178598191512011e-02
    x_15_0    product_ub_88  -4.2501517911396489e-02
    x_15_0    onehot_15_121  1
    x_15_0    parent_nonstrict_scope_258  0.1215
    x_15_0    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_87  1
    w_15_0    product_ub_88  1
    w_15_0    normalized_mass_15_122  1
    w_15_0    full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       4.7249999999999986e-02
    x_15_1    product_lb_89  -2.5178598191512011e-02
    x_15_1    product_ub_90  -4.2501517911396489e-02
    x_15_1    onehot_15_121  1
    x_15_1    stock_lb_256  1
    x_15_1    stock_ub_257  1
    x_15_1    parent_nonstrict_scope_258  1.0799999999999998e-01
    x_15_1    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_89  1
    w_15_1    product_ub_90  1
    w_15_1    normalized_mass_15_122  1
    w_15_1    normalized_ratio_15_123  -1.1111111111111110e-01
    w_15_1    full_original_Gini_316  -2.0528571428571432e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_2    OBJ       0.03375
    x_15_2    product_lb_91  -2.5178598191512011e-02
    x_15_2    product_ub_92  -4.2501517911396489e-02
    x_15_2    onehot_15_121  1
    x_15_2    stock_lb_256  2
    x_15_2    stock_ub_257  2
    x_15_2    parent_nonstrict_scope_258  0.0945
    x_15_2    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_2    product_lb_91  1
    w_15_2    product_ub_92  1
    w_15_2    normalized_mass_15_122  1
    w_15_2    normalized_ratio_15_123  -2.2222222222222221e-01
    w_15_2    full_original_Gini_316  -1.7573015873015880e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_3    OBJ       2.0250000000000004e-02
    x_15_3    product_lb_93  -2.5178598191512011e-02
    x_15_3    product_ub_94  -4.2501517911396489e-02
    x_15_3    onehot_15_121  1
    x_15_3    stock_lb_256  3
    x_15_3    stock_ub_257  3
    x_15_3    parent_nonstrict_scope_258  0.081
    MARKER    'MARKER'                 'INTEND'
    w_15_3    product_lb_93  1
    w_15_3    product_ub_94  1
    w_15_3    normalized_mass_15_122  1
    w_15_3    normalized_ratio_15_123  -3.3333333333333331e-01
    w_15_3    full_original_Gini_316  -1.4961904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_4    OBJ       6.7500000000000060e-03
    x_15_4    product_lb_95  -2.5178598191512011e-02
    x_15_4    product_ub_96  -4.2501517911396489e-02
    x_15_4    onehot_15_121  1
    x_15_4    stock_lb_256  4
    x_15_4    stock_ub_257  4
    x_15_4    parent_nonstrict_scope_258  0.0675
    x_15_4    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_4    product_lb_95  1
    w_15_4    product_ub_96  1
    w_15_4    normalized_mass_15_122  1
    w_15_4    normalized_ratio_15_123  -4.4444444444444442e-01
    w_15_4    full_original_Gini_316  -1.2495238095238092e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_5    OBJ       -6.7500000000000060e-03
    x_15_5    product_lb_97  -2.5178598191512011e-02
    x_15_5    product_ub_98  -4.2501517911396489e-02
    x_15_5    onehot_15_121  1
    x_15_5    stock_lb_256  5
    x_15_5    stock_ub_257  5
    x_15_5    parent_nonstrict_scope_258  5.3999999999999992e-02
    x_15_5    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_5    product_lb_97  1
    w_15_5    product_ub_98  1
    w_15_5    normalized_mass_15_122  1
    w_15_5    normalized_ratio_15_123  -5.5555555555555558e-01
    w_15_5    full_original_Gini_316  -1.0273015873015876e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_6    OBJ       -2.0249999999999997e-02
    x_15_6    product_lb_99  -2.5178598191512011e-02
    x_15_6    product_ub_100  -4.2501517911396489e-02
    x_15_6    onehot_15_121  1
    x_15_6    stock_lb_256  6
    x_15_6    stock_ub_257  6
    x_15_6    parent_nonstrict_scope_258  0.0405
    x_15_6    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_6    product_lb_99  1
    w_15_6    product_ub_100  1
    w_15_6    normalized_mass_15_122  1
    w_15_6    normalized_ratio_15_123  -6.6666666666666663e-01
    w_15_6    full_original_Gini_316  -8.1619047619047613e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_7    OBJ       -3.3749999999999988e-02
    x_15_7    product_lb_101  -2.5178598191512011e-02
    x_15_7    product_ub_102  -4.2501517911396489e-02
    x_15_7    onehot_15_121  1
    x_15_7    stock_lb_256  7
    x_15_7    stock_ub_257  7
    x_15_7    parent_nonstrict_scope_258  2.7000000000000010e-02
    x_15_7    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_7    product_lb_101  1
    w_15_7    product_ub_102  1
    w_15_7    normalized_mass_15_122  1
    w_15_7    normalized_ratio_15_123  -7.7777777777777768e-01
    w_15_7    full_original_Gini_316  -6.2333333333333343e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_8    OBJ       -4.7249999999999993e-02
    x_15_8    product_lb_103  -2.5178598191512011e-02
    x_15_8    product_ub_104  -4.2501517911396489e-02
    x_15_8    onehot_15_121  1
    x_15_8    stock_lb_256  8
    x_15_8    stock_ub_257  8
    x_15_8    parent_nonstrict_scope_258  1.3500000000000005e-02
    x_15_8    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_8    product_lb_103  1
    w_15_8    product_ub_104  1
    w_15_8    normalized_mass_15_122  1
    w_15_8    normalized_ratio_15_123  -8.8888888888888884e-01
    w_15_8    full_original_Gini_316  -4.9269841269841272e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_9    OBJ       -0.06075
    x_15_9    product_lb_105  -2.5178598191512011e-02
    x_15_9    product_ub_106  -4.2501517911396489e-02
    x_15_9    onehot_15_121  1
    x_15_9    stock_lb_256  9
    x_15_9    stock_ub_257  9
    x_15_9    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_9    product_lb_105  1
    w_15_9    product_ub_106  1
    w_15_9    normalized_mass_15_122  1
    w_15_9    normalized_ratio_15_123  -1
    w_15_9    full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_10   OBJ       -4.7249999999999993e-02
    x_15_10   product_lb_107  -2.5178598191512011e-02
    x_15_10   product_ub_108  -4.2501517911396489e-02
    x_15_10   onehot_15_121  1
    x_15_10   stock_lb_256  10
    x_15_10   stock_ub_257  10
    x_15_10   parent_nonstrict_scope_258  1.3500000000000005e-02
    x_15_10   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_10   product_lb_107  1
    w_15_10   product_ub_108  1
    w_15_10   normalized_mass_15_122  1
    w_15_10   normalized_ratio_15_123  -1.1111111111111112e+00
    w_15_10   full_original_Gini_316  -6.9269841269841272e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_11   OBJ       -3.3750000000000016e-02
    x_15_11   product_lb_109  -2.5178598191512011e-02
    x_15_11   product_ub_110  -4.2501517911396489e-02
    x_15_11   onehot_15_121  1
    x_15_11   stock_lb_256  11
    x_15_11   stock_ub_257  11
    x_15_11   parent_nonstrict_scope_258  2.6999999999999986e-02
    x_15_11   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_11   product_lb_109  1
    w_15_11   product_ub_110  1
    w_15_11   normalized_mass_15_122  1
    w_15_11   normalized_ratio_15_123  -1.2222222222222221e+00
    w_15_11   full_original_Gini_316  -9.5269841269841269e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_12   OBJ       -2.0250000000000011e-02
    x_15_12   product_lb_111  -2.5178598191512011e-02
    x_15_12   product_ub_112  -4.2501517911396489e-02
    x_15_12   onehot_15_121  1
    x_15_12   stock_lb_256  12
    x_15_12   stock_ub_257  12
    x_15_12   parent_nonstrict_scope_258  4.0499999999999987e-02
    x_15_12   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_12   product_lb_111  1
    w_15_12   product_ub_112  1
    w_15_12   normalized_mass_15_122  1
    w_15_12   normalized_ratio_15_123  -1.3333333333333333e+00
    w_15_12   full_original_Gini_316  -1.2471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_13   OBJ       -6.7500000000000060e-03
    x_15_13   product_lb_113  -2.5178598191512011e-02
    x_15_13   product_ub_114  -4.2501517911396489e-02
    x_15_13   onehot_15_121  1
    x_15_13   stock_lb_256  13
    x_15_13   stock_ub_257  13
    x_15_13   parent_nonstrict_scope_258  5.3999999999999992e-02
    x_15_13   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_13   product_lb_113  1
    w_15_13   product_ub_114  1
    w_15_13   normalized_mass_15_122  1
    w_15_13   normalized_ratio_15_123  -1.4444444444444444e+00
    w_15_13   full_original_Gini_316  -1.5471428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_14   OBJ       6.7499999999999782e-03
    x_15_14   product_lb_115  -2.5178598191512011e-02
    x_15_14   product_ub_116  -4.2501517911396489e-02
    x_15_14   onehot_15_121  1
    x_15_14   stock_lb_256  14
    x_15_14   stock_ub_257  14
    x_15_14   parent_nonstrict_scope_258  6.7499999999999977e-02
    x_15_14   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_14   product_lb_115  1
    w_15_14   product_ub_116  1
    w_15_14   normalized_mass_15_122  1
    w_15_14   normalized_ratio_15_123  -1.5555555555555554e+00
    w_15_14   full_original_Gini_316  -1.8471428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_15   OBJ       2.0249999999999976e-02
    x_15_15   product_lb_117  -2.5178598191512011e-02
    x_15_15   product_ub_118  -4.2501517911396489e-02
    x_15_15   onehot_15_121  1
    x_15_15   stock_lb_256  15
    x_15_15   stock_ub_257  15
    x_15_15   parent_nonstrict_scope_258  8.0999999999999975e-02
    x_15_15   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_15   product_lb_117  1
    w_15_15   product_ub_118  1
    w_15_15   normalized_mass_15_122  1
    w_15_15   normalized_ratio_15_123  -1.6666666666666665e+00
    w_15_15   full_original_Gini_316  -2.1471428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_16   OBJ       3.3749999999999988e-02
    x_15_16   product_lb_119  -2.5178598191512011e-02
    x_15_16   product_ub_120  -4.2501517911396489e-02
    x_15_16   onehot_15_121  1
    x_15_16   stock_lb_256  16
    x_15_16   stock_ub_257  16
    x_15_16   parent_nonstrict_scope_258  9.4499999999999987e-02
    x_15_16   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_16   product_lb_119  1
    w_15_16   product_ub_120  1
    w_15_16   normalized_mass_15_122  1
    w_15_16   normalized_ratio_15_123  -1.7777777777777777e+00
    w_15_16   full_original_Gini_316  -2.4471428571428579e+01
    rho_15    normalized_ratio_15_123  1
    rho_15    block_pair_pos_271  -1
    rho_15    block_pair_neg_272  1
    rho_15    block_pair_pos_273  -1
    rho_15    block_pair_neg_274  1
    rho_15    block_pair_pos_275  -1
    rho_15    block_pair_neg_276  1
    rho_15    block_pair_pos_277  -1
    rho_15    block_pair_neg_278  1
    rho_15    block_pair_pos_287  1
    rho_15    block_pair_neg_288  -1
    rho_15    block_pair_pos_299  1
    rho_15    block_pair_neg_300  -1
    rho_15    block_pair_pos_313  1
    rho_15    block_pair_neg_314  -1
    rho_15    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_124  -2.5178598191512011e-02
    x_2_0     product_ub_125  -4.2501517911396489e-02
    x_2_0     onehot_2_156  1
    x_2_0     parent_nonstrict_scope_258  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_124  1
    w_2_0     product_ub_125  1
    w_2_0     normalized_mass_2_157  1
    w_2_0     full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_126  -2.5178598191512011e-02
    x_2_1     product_ub_127  -4.2501517911396489e-02
    x_2_1     onehot_2_156  1
    x_2_1     stock_lb_256  1
    x_2_1     stock_ub_257  1
    x_2_1     parent_nonstrict_scope_258  0.063
    x_2_1     unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_126  1
    w_2_1     product_ub_127  1
    w_2_1     normalized_mass_2_157  1
    w_2_1     normalized_ratio_2_158  -1.4285714285714285e-01
    w_2_1     full_original_Gini_316  -1.9671428571428578e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_128  -2.5178598191512011e-02
    x_2_2     product_ub_129  -4.2501517911396489e-02
    x_2_2     onehot_2_156  1
    x_2_2     stock_lb_256  2
    x_2_2     stock_ub_257  2
    x_2_2     parent_nonstrict_scope_258  0.0525
    x_2_2     unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_128  1
    w_2_2     product_ub_129  1
    w_2_2     normalized_mass_2_157  1
    w_2_2     normalized_ratio_2_158  -2.8571428571428570e-01
    w_2_2     full_original_Gini_316  -1.6057142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_130  -2.5178598191512011e-02
    x_2_3     product_ub_131  -4.2501517911396489e-02
    x_2_3     onehot_2_156  1
    x_2_3     stock_lb_256  3
    x_2_3     stock_ub_257  3
    x_2_3     parent_nonstrict_scope_258  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_130  1
    w_2_3     product_ub_131  1
    w_2_3     normalized_mass_2_157  1
    w_2_3     normalized_ratio_2_158  -4.2857142857142855e-01
    w_2_3     full_original_Gini_316  -1.2828571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_132  -2.5178598191512011e-02
    x_2_4     product_ub_133  -4.2501517911396489e-02
    x_2_4     onehot_2_156  1
    x_2_4     stock_lb_256  4
    x_2_4     stock_ub_257  4
    x_2_4     parent_nonstrict_scope_258  0.0315
    x_2_4     unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_132  1
    w_2_4     product_ub_133  1
    w_2_4     normalized_mass_2_157  1
    w_2_4     normalized_ratio_2_158  -5.7142857142857140e-01
    w_2_4     full_original_Gini_316  -9.9714285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_134  -2.5178598191512011e-02
    x_2_5     product_ub_135  -4.2501517911396489e-02
    x_2_5     onehot_2_156  1
    x_2_5     stock_lb_256  5
    x_2_5     stock_ub_257  5
    x_2_5     parent_nonstrict_scope_258  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_134  1
    w_2_5     product_ub_135  1
    w_2_5     normalized_mass_2_157  1
    w_2_5     normalized_ratio_2_158  -7.1428571428571419e-01
    w_2_5     full_original_Gini_316  -7.2571428571428571e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_136  -2.5178598191512011e-02
    x_2_6     product_ub_137  -4.2501517911396489e-02
    x_2_6     onehot_2_156  1
    x_2_6     stock_lb_256  6
    x_2_6     stock_ub_257  6
    x_2_6     parent_nonstrict_scope_258  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_136  1
    w_2_6     product_ub_137  1
    w_2_6     normalized_mass_2_157  1
    w_2_6     normalized_ratio_2_158  -8.5714285714285710e-01
    w_2_6     full_original_Gini_316  -5.1571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_138  -2.5178598191512011e-02
    x_2_7     product_ub_139  -4.2501517911396489e-02
    x_2_7     onehot_2_156  1
    x_2_7     stock_lb_256  7
    x_2_7     stock_ub_257  7
    x_2_7     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_138  1
    w_2_7     product_ub_139  1
    w_2_7     normalized_mass_2_157  1
    w_2_7     normalized_ratio_2_158  -1
    w_2_7     full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_140  -2.5178598191512011e-02
    x_2_8     product_ub_141  -4.2501517911396489e-02
    x_2_8     onehot_2_156  1
    x_2_8     stock_lb_256  8
    x_2_8     stock_ub_257  8
    x_2_8     parent_nonstrict_scope_258  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_140  1
    w_2_8     product_ub_141  1
    w_2_8     normalized_mass_2_157  1
    w_2_8     normalized_ratio_2_158  -1.1428571428571428e+00
    w_2_8     full_original_Gini_316  -7.6571428571428548e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_142  -2.5178598191512011e-02
    x_2_9     product_ub_143  -4.2501517911396489e-02
    x_2_9     onehot_2_156  1
    x_2_9     stock_lb_256  9
    x_2_9     stock_ub_257  9
    x_2_9     parent_nonstrict_scope_258  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_142  1
    w_2_9     product_ub_143  1
    w_2_9     normalized_mass_2_157  1
    w_2_9     normalized_ratio_2_158  -1.2857142857142856e+00
    w_2_9     full_original_Gini_316  -1.1185714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_144  -2.5178598191512011e-02
    x_2_10    product_ub_145  -4.2501517911396489e-02
    x_2_10    onehot_2_156  1
    x_2_10    stock_lb_256  10
    x_2_10    stock_ub_257  10
    x_2_10    parent_nonstrict_scope_258  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_144  1
    w_2_10    product_ub_145  1
    w_2_10    normalized_mass_2_157  1
    w_2_10    normalized_ratio_2_158  -1.4285714285714284e+00
    w_2_10    full_original_Gini_316  -1.5042857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_146  -2.5178598191512011e-02
    x_2_11    product_ub_147  -4.2501517911396489e-02
    x_2_11    onehot_2_156  1
    x_2_11    stock_lb_256  11
    x_2_11    stock_ub_257  11
    x_2_11    parent_nonstrict_scope_258  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_146  1
    w_2_11    product_ub_147  1
    w_2_11    normalized_mass_2_157  1
    w_2_11    normalized_ratio_2_158  -1.5714285714285714e+00
    w_2_11    full_original_Gini_316  -18.9
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_148  -2.5178598191512011e-02
    x_2_12    product_ub_149  -4.2501517911396489e-02
    x_2_12    onehot_2_156  1
    x_2_12    stock_lb_256  12
    x_2_12    stock_ub_257  12
    x_2_12    parent_nonstrict_scope_258  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_148  1
    w_2_12    product_ub_149  1
    w_2_12    normalized_mass_2_157  1
    w_2_12    normalized_ratio_2_158  -1.7142857142857142e+00
    w_2_12    full_original_Gini_316  -2.2757142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_150  -2.5178598191512011e-02
    x_2_13    product_ub_151  -4.2501517911396489e-02
    x_2_13    onehot_2_156  1
    x_2_13    stock_lb_256  13
    x_2_13    stock_ub_257  13
    x_2_13    parent_nonstrict_scope_258  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_150  1
    w_2_13    product_ub_151  1
    w_2_13    normalized_mass_2_157  1
    w_2_13    normalized_ratio_2_158  -1.8571428571428570e+00
    w_2_13    full_original_Gini_316  -2.6614285714285717e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_152  -2.5178598191512011e-02
    x_2_14    product_ub_153  -4.2501517911396489e-02
    x_2_14    onehot_2_156  1
    x_2_14    stock_lb_256  14
    x_2_14    stock_ub_257  14
    x_2_14    parent_nonstrict_scope_258  0.0735
    x_2_14    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_152  1
    w_2_14    product_ub_153  1
    w_2_14    normalized_mass_2_157  1
    w_2_14    normalized_ratio_2_158  -2
    w_2_14    full_original_Gini_316  -3.0471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_154  -2.5178598191512011e-02
    x_2_15    product_ub_155  -4.2501517911396489e-02
    x_2_15    onehot_2_156  1
    x_2_15    stock_lb_256  15
    x_2_15    stock_ub_257  15
    x_2_15    parent_nonstrict_scope_258  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_154  1
    w_2_15    product_ub_155  1
    w_2_15    normalized_mass_2_157  1
    w_2_15    normalized_ratio_2_158  -2.1428571428571428e+00
    w_2_15    full_original_Gini_316  -3.4328571428571422e+01
    rho_2     normalized_ratio_2_158  1
    rho_2     block_pair_pos_259  -1
    rho_2     block_pair_neg_260  1
    rho_2     block_pair_pos_261  -1
    rho_2     block_pair_neg_262  1
    rho_2     block_pair_pos_263  -1
    rho_2     block_pair_neg_264  1
    rho_2     block_pair_pos_271  1
    rho_2     block_pair_neg_272  -1
    rho_2     block_pair_pos_279  1
    rho_2     block_pair_neg_280  -1
    rho_2     block_pair_pos_291  1
    rho_2     block_pair_neg_292  -1
    rho_2     block_pair_pos_305  1
    rho_2     block_pair_neg_306  -1
    rho_2     normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       0.03
    x_13_0    product_lb_159  -2.5178598191512011e-02
    x_13_0    product_ub_160  -4.2501517911396489e-02
    x_13_0    onehot_13_199  1
    x_13_0    parent_nonstrict_scope_258  0.096
    x_13_0    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_159  1
    w_13_0    product_ub_160  1
    w_13_0    normalized_mass_13_200  1
    w_13_0    full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       1.8000000000000002e-02
    x_13_1    product_lb_161  -2.5178598191512011e-02
    x_13_1    product_ub_162  -4.2501517911396489e-02
    x_13_1    onehot_13_199  1
    x_13_1    stock_lb_256  1
    x_13_1    stock_ub_257  1
    x_13_1    parent_nonstrict_scope_258  0.084
    x_13_1    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_161  1
    w_13_1    product_ub_162  1
    w_13_1    normalized_mass_13_200  1
    w_13_1    normalized_ratio_13_201  -0.125
    w_13_1    full_original_Gini_316  -2.0153571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    OBJ       6.0000000000000053e-03
    x_13_2    product_lb_163  -2.5178598191512011e-02
    x_13_2    product_ub_164  -4.2501517911396489e-02
    x_13_2    onehot_13_199  1
    x_13_2    stock_lb_256  2
    x_13_2    stock_ub_257  2
    x_13_2    parent_nonstrict_scope_258  7.2000000000000008e-02
    x_13_2    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_163  1
    w_13_2    product_ub_164  1
    w_13_2    normalized_mass_13_200  1
    w_13_2    normalized_ratio_13_201  -0.25
    w_13_2    full_original_Gini_316  -1.6878571428571430e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -6.0000000000000053e-03
    x_13_3    product_lb_165  -2.5178598191512011e-02
    x_13_3    product_ub_166  -4.2501517911396489e-02
    x_13_3    onehot_13_199  1
    x_13_3    stock_lb_256  3
    x_13_3    stock_ub_257  3
    x_13_3    parent_nonstrict_scope_258  0.06
    x_13_3    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_165  1
    w_13_3    product_ub_166  1
    w_13_3    normalized_mass_13_200  1
    w_13_3    normalized_ratio_13_201  -0.375
    w_13_3    full_original_Gini_316  -1.4003571428571430e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -1.8000000000000002e-02
    x_13_4    product_lb_167  -2.5178598191512011e-02
    x_13_4    product_ub_168  -4.2501517911396489e-02
    x_13_4    onehot_13_199  1
    x_13_4    stock_lb_256  4
    x_13_4    stock_ub_257  4
    x_13_4    parent_nonstrict_scope_258  0.048
    x_13_4    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_167  1
    w_13_4    product_ub_168  1
    w_13_4    normalized_mass_13_200  1
    w_13_4    normalized_ratio_13_201  -0.5
    w_13_4    full_original_Gini_316  -1.1328571428571429e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -0.03
    x_13_5    product_lb_169  -2.5178598191512011e-02
    x_13_5    product_ub_170  -4.2501517911396489e-02
    x_13_5    onehot_13_199  1
    x_13_5    stock_lb_256  5
    x_13_5    stock_ub_257  5
    x_13_5    parent_nonstrict_scope_258  3.6000000000000004e-02
    x_13_5    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_169  1
    w_13_5    product_ub_170  1
    w_13_5    normalized_mass_13_200  1
    w_13_5    normalized_ratio_13_201  -0.625
    w_13_5    full_original_Gini_316  -8.95357142857143
    MARKER    'MARKER'                 'INTORG'
    x_13_6    OBJ       -0.042
    x_13_6    product_lb_171  -2.5178598191512011e-02
    x_13_6    product_ub_172  -4.2501517911396489e-02
    x_13_6    onehot_13_199  1
    x_13_6    stock_lb_256  6
    x_13_6    stock_ub_257  6
    x_13_6    parent_nonstrict_scope_258  0.024
    x_13_6    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_171  1
    w_13_6    product_ub_172  1
    w_13_6    normalized_mass_13_200  1
    w_13_6    normalized_ratio_13_201  -0.75
    w_13_6    full_original_Gini_316  -6.6499999999999995e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       -5.4000000000000006e-02
    x_13_7    product_lb_173  -2.5178598191512011e-02
    x_13_7    product_ub_174  -4.2501517911396489e-02
    x_13_7    onehot_13_199  1
    x_13_7    stock_lb_256  7
    x_13_7    stock_ub_257  7
    x_13_7    parent_nonstrict_scope_258  0.012
    x_13_7    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_173  1
    w_13_7    product_ub_174  1
    w_13_7    normalized_mass_13_200  1
    w_13_7    normalized_ratio_13_201  -0.875
    w_13_7    full_original_Gini_316  -4.9964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       -0.066
    x_13_8    product_lb_175  -2.5178598191512011e-02
    x_13_8    product_ub_176  -4.2501517911396489e-02
    x_13_8    onehot_13_199  1
    x_13_8    stock_lb_256  8
    x_13_8    stock_ub_257  8
    x_13_8    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_175  1
    w_13_8    product_ub_176  1
    w_13_8    normalized_mass_13_200  1
    w_13_8    normalized_ratio_13_201  -1
    w_13_8    full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_9    OBJ       -5.4000000000000006e-02
    x_13_9    product_lb_177  -2.5178598191512011e-02
    x_13_9    product_ub_178  -4.2501517911396489e-02
    x_13_9    onehot_13_199  1
    x_13_9    stock_lb_256  9
    x_13_9    stock_ub_257  9
    x_13_9    parent_nonstrict_scope_258  0.012
    x_13_9    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_9    product_lb_177  1
    w_13_9    product_ub_178  1
    w_13_9    normalized_mass_13_200  1
    w_13_9    normalized_ratio_13_201  -1.125
    w_13_9    full_original_Gini_316  -7.2464285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_10   OBJ       -0.042
    x_13_10   product_lb_179  -2.5178598191512011e-02
    x_13_10   product_ub_180  -4.2501517911396489e-02
    x_13_10   onehot_13_199  1
    x_13_10   stock_lb_256  10
    x_13_10   stock_ub_257  10
    x_13_10   parent_nonstrict_scope_258  0.024
    x_13_10   unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_10   product_lb_179  1
    w_13_10   product_ub_180  1
    w_13_10   normalized_mass_13_200  1
    w_13_10   normalized_ratio_13_201  -1.25
    w_13_10   full_original_Gini_316  -1.0221428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_11   OBJ       -0.03
    x_13_11   product_lb_181  -2.5178598191512011e-02
    x_13_11   product_ub_182  -4.2501517911396489e-02
    x_13_11   onehot_13_199  1
    x_13_11   stock_lb_256  11
    x_13_11   stock_ub_257  11
    x_13_11   parent_nonstrict_scope_258  3.6000000000000004e-02
    x_13_11   unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_11   product_lb_181  1
    w_13_11   product_ub_182  1
    w_13_11   normalized_mass_13_200  1
    w_13_11   normalized_ratio_13_201  -1.375
    w_13_11   full_original_Gini_316  -1.3596428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_12   OBJ       -1.8000000000000002e-02
    x_13_12   product_lb_183  -2.5178598191512011e-02
    x_13_12   product_ub_184  -4.2501517911396489e-02
    x_13_12   onehot_13_199  1
    x_13_12   stock_lb_256  12
    x_13_12   stock_ub_257  12
    x_13_12   parent_nonstrict_scope_258  0.048
    x_13_12   unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_12   product_lb_183  1
    w_13_12   product_ub_184  1
    w_13_12   normalized_mass_13_200  1
    w_13_12   normalized_ratio_13_201  -1.5
    w_13_12   full_original_Gini_316  -1.6971428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_13   OBJ       -6.0000000000000053e-03
    x_13_13   product_lb_185  -2.5178598191512011e-02
    x_13_13   product_ub_186  -4.2501517911396489e-02
    x_13_13   onehot_13_199  1
    x_13_13   stock_lb_256  13
    x_13_13   stock_ub_257  13
    x_13_13   parent_nonstrict_scope_258  0.06
    MARKER    'MARKER'                 'INTEND'
    w_13_13   product_lb_185  1
    w_13_13   product_ub_186  1
    w_13_13   normalized_mass_13_200  1
    w_13_13   normalized_ratio_13_201  -1.625
    w_13_13   full_original_Gini_316  -2.0346428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_14   OBJ       6.0000000000000053e-03
    x_13_14   product_lb_187  -2.5178598191512011e-02
    x_13_14   product_ub_188  -4.2501517911396489e-02
    x_13_14   onehot_13_199  1
    x_13_14   stock_lb_256  14
    x_13_14   stock_ub_257  14
    x_13_14   parent_nonstrict_scope_258  7.2000000000000008e-02
    x_13_14   unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_14   product_lb_187  1
    w_13_14   product_ub_188  1
    w_13_14   normalized_mass_13_200  1
    w_13_14   normalized_ratio_13_201  -1.75
    w_13_14   full_original_Gini_316  -2.3721428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_15   OBJ       1.8000000000000002e-02
    x_13_15   product_lb_189  -2.5178598191512011e-02
    x_13_15   product_ub_190  -4.2501517911396489e-02
    x_13_15   onehot_13_199  1
    x_13_15   stock_lb_256  15
    x_13_15   stock_ub_257  15
    x_13_15   parent_nonstrict_scope_258  0.084
    x_13_15   unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_15   product_lb_189  1
    w_13_15   product_ub_190  1
    w_13_15   normalized_mass_13_200  1
    w_13_15   normalized_ratio_13_201  -1.875
    w_13_15   full_original_Gini_316  -2.7096428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_16   OBJ       0.03
    x_13_16   product_lb_191  -2.5178598191512011e-02
    x_13_16   product_ub_192  -4.2501517911396489e-02
    x_13_16   onehot_13_199  1
    x_13_16   stock_lb_256  16
    x_13_16   stock_ub_257  16
    x_13_16   parent_nonstrict_scope_258  0.096
    x_13_16   unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_16   product_lb_191  1
    w_13_16   product_ub_192  1
    w_13_16   normalized_mass_13_200  1
    w_13_16   normalized_ratio_13_201  -2
    w_13_16   full_original_Gini_316  -3.0471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_17   OBJ       4.1999999999999996e-02
    x_13_17   product_lb_193  -2.5178598191512011e-02
    x_13_17   product_ub_194  -4.2501517911396489e-02
    x_13_17   onehot_13_199  1
    x_13_17   stock_lb_256  17
    x_13_17   stock_ub_257  17
    x_13_17   parent_nonstrict_scope_258  0.108
    x_13_17   unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_17   product_lb_193  1
    w_13_17   product_ub_194  1
    w_13_17   normalized_mass_13_200  1
    w_13_17   normalized_ratio_13_201  -2.125
    w_13_17   full_original_Gini_316  -3.3846428571428568e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_18   OBJ       5.3999999999999992e-02
    x_13_18   product_lb_195  -2.5178598191512011e-02
    x_13_18   product_ub_196  -4.2501517911396489e-02
    x_13_18   onehot_13_199  1
    x_13_18   stock_lb_256  18
    x_13_18   stock_ub_257  18
    x_13_18   parent_nonstrict_scope_258  0.12
    x_13_18   unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_18   product_lb_195  1
    w_13_18   product_ub_196  1
    w_13_18   normalized_mass_13_200  1
    w_13_18   normalized_ratio_13_201  -2.25
    w_13_18   full_original_Gini_316  -3.7221428571428575e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_19   OBJ       0.066
    x_13_19   product_lb_197  -2.5178598191512011e-02
    x_13_19   product_ub_198  -4.2501517911396489e-02
    x_13_19   onehot_13_199  1
    x_13_19   stock_lb_256  19
    x_13_19   stock_ub_257  19
    x_13_19   parent_nonstrict_scope_258  0.132
    x_13_19   unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_19   product_lb_197  1
    w_13_19   product_ub_198  1
    w_13_19   normalized_mass_13_200  1
    w_13_19   normalized_ratio_13_201  -2.375
    w_13_19   full_original_Gini_316  -4.0596428571428575e+01
    rho_13    normalized_ratio_13_201  1
    rho_13    block_pair_pos_263  1
    rho_13    block_pair_neg_264  -1
    rho_13    block_pair_pos_267  -1
    rho_13    block_pair_neg_268  1
    rho_13    block_pair_pos_269  -1
    rho_13    block_pair_neg_270  1
    rho_13    block_pair_pos_277  1
    rho_13    block_pair_neg_278  -1
    rho_13    block_pair_pos_285  1
    rho_13    block_pair_neg_286  -1
    rho_13    block_pair_pos_297  1
    rho_13    block_pair_neg_298  -1
    rho_13    block_pair_pos_311  1
    rho_13    block_pair_neg_312  -1
    rho_13    normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_202  -2.5178598191512011e-02
    x_6_0     product_ub_203  -4.2501517911396489e-02
    x_6_0     onehot_6_224  1
    x_6_0     parent_nonstrict_scope_258  0.0375
    x_6_0     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_202  1
    w_6_0     product_ub_203  1
    w_6_0     normalized_mass_6_225  1
    w_6_0     full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_204  -2.5178598191512011e-02
    x_6_1     product_ub_205  -4.2501517911396489e-02
    x_6_1     onehot_6_224  1
    x_6_1     stock_lb_256  1
    x_6_1     stock_ub_257  1
    x_6_1     parent_nonstrict_scope_258  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_204  1
    w_6_1     product_ub_205  1
    w_6_1     normalized_mass_6_225  1
    w_6_1     normalized_ratio_6_226  -0.2
    w_6_1     full_original_Gini_316  -1.8128571428571433e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_206  -2.5178598191512011e-02
    x_6_2     product_ub_207  -4.2501517911396489e-02
    x_6_2     onehot_6_224  1
    x_6_2     stock_lb_256  2
    x_6_2     stock_ub_257  2
    x_6_2     parent_nonstrict_scope_258  0.0225
    x_6_2     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_206  1
    w_6_2     product_ub_207  1
    w_6_2     normalized_mass_6_225  1
    w_6_2     normalized_ratio_6_226  -0.4
    w_6_2     full_original_Gini_316  -1.3428571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_208  -2.5178598191512011e-02
    x_6_3     product_ub_209  -4.2501517911396489e-02
    x_6_3     onehot_6_224  1
    x_6_3     stock_lb_256  3
    x_6_3     stock_ub_257  3
    x_6_3     parent_nonstrict_scope_258  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_208  1
    w_6_3     product_ub_209  1
    w_6_3     normalized_mass_6_225  1
    w_6_3     normalized_ratio_6_226  -6.0000000000000009e-01
    w_6_3     full_original_Gini_316  -9.4285714285714270e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_210  -2.5178598191512011e-02
    x_6_4     product_ub_211  -4.2501517911396489e-02
    x_6_4     onehot_6_224  1
    x_6_4     stock_lb_256  4
    x_6_4     stock_ub_257  4
    x_6_4     parent_nonstrict_scope_258  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_210  1
    w_6_4     product_ub_211  1
    w_6_4     normalized_mass_6_225  1
    w_6_4     normalized_ratio_6_226  -0.8
    w_6_4     full_original_Gini_316  -5.9000000000000012e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_212  -2.5178598191512011e-02
    x_6_5     product_ub_213  -4.2501517911396489e-02
    x_6_5     onehot_6_224  1
    x_6_5     stock_lb_256  5
    x_6_5     stock_ub_257  5
    x_6_5     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_212  1
    w_6_5     product_ub_213  1
    w_6_5     normalized_mass_6_225  1
    w_6_5     normalized_ratio_6_226  -1
    w_6_5     full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_214  -2.5178598191512011e-02
    x_6_6     product_ub_215  -4.2501517911396489e-02
    x_6_6     onehot_6_224  1
    x_6_6     stock_lb_256  6
    x_6_6     stock_ub_257  6
    x_6_6     parent_nonstrict_scope_258  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_214  1
    w_6_6     product_ub_215  1
    w_6_6     normalized_mass_6_225  1
    w_6_6     normalized_ratio_6_226  -1.2000000000000002e+00
    w_6_6     full_original_Gini_316  -8.9714285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_216  -2.5178598191512011e-02
    x_6_7     product_ub_217  -4.2501517911396489e-02
    x_6_7     onehot_6_224  1
    x_6_7     stock_lb_256  7
    x_6_7     stock_ub_257  7
    x_6_7     parent_nonstrict_scope_258  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_216  1
    w_6_7     product_ub_217  1
    w_6_7     normalized_mass_6_225  1
    w_6_7     normalized_ratio_6_226  -1.4000000000000001e+00
    w_6_7     full_original_Gini_316  -1.4271428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_218  -2.5178598191512011e-02
    x_6_8     product_ub_219  -4.2501517911396489e-02
    x_6_8     onehot_6_224  1
    x_6_8     stock_lb_256  8
    x_6_8     stock_ub_257  8
    x_6_8     parent_nonstrict_scope_258  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_218  1
    w_6_8     product_ub_219  1
    w_6_8     normalized_mass_6_225  1
    w_6_8     normalized_ratio_6_226  -1.6
    w_6_8     full_original_Gini_316  -1.9671428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_220  -2.5178598191512011e-02
    x_6_9     product_ub_221  -4.2501517911396489e-02
    x_6_9     onehot_6_224  1
    x_6_9     stock_lb_256  9
    x_6_9     stock_ub_257  9
    x_6_9     parent_nonstrict_scope_258  0.03
    x_6_9     unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_220  1
    w_6_9     product_ub_221  1
    w_6_9     normalized_mass_6_225  1
    w_6_9     normalized_ratio_6_226  -1.8
    w_6_9     full_original_Gini_316  -2.5071428571428580e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_222  -2.5178598191512011e-02
    x_6_10    product_ub_223  -4.2501517911396489e-02
    x_6_10    onehot_6_224  1
    x_6_10    stock_lb_256  10
    x_6_10    stock_ub_257  10
    x_6_10    parent_nonstrict_scope_258  0.0375
    x_6_10    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_222  1
    w_6_10    product_ub_223  1
    w_6_10    normalized_mass_6_225  1
    w_6_10    normalized_ratio_6_226  -2
    w_6_10    full_original_Gini_316  -3.0471428571428572e+01
    rho_6     normalized_ratio_6_226  1
    rho_6     block_pair_pos_259  1
    rho_6     block_pair_neg_260  -1
    rho_6     block_pair_pos_265  -1
    rho_6     block_pair_neg_266  1
    rho_6     block_pair_pos_267  1
    rho_6     block_pair_neg_268  -1
    rho_6     block_pair_pos_273  1
    rho_6     block_pair_neg_274  -1
    rho_6     block_pair_pos_281  1
    rho_6     block_pair_neg_282  -1
    rho_6     block_pair_pos_293  1
    rho_6     block_pair_neg_294  -1
    rho_6     block_pair_pos_307  1
    rho_6     block_pair_neg_308  -1
    rho_6     normalization_315  1
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1249999999999993e-02
    x_9_0     product_lb_227  -2.5178598191512011e-02
    x_9_0     product_ub_228  -4.2501517911396489e-02
    x_9_0     onehot_9_253  1
    x_9_0     parent_nonstrict_scope_258  0.0375
    x_9_0     unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_227  1
    w_9_0     product_ub_228  1
    w_9_0     normalized_mass_9_254  1
    w_9_0     full_original_Gini_316  -2.3528571428571428e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       3.7499999999999929e-03
    x_9_1     product_lb_229  -2.5178598191512011e-02
    x_9_1     product_ub_230  -4.2501517911396489e-02
    x_9_1     onehot_9_253  1
    x_9_1     stock_lb_256  1
    x_9_1     stock_ub_257  1
    x_9_1     parent_nonstrict_scope_258  0.03
    x_9_1     unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_229  1
    w_9_1     product_ub_230  1
    w_9_1     normalized_mass_9_254  1
    w_9_1     normalized_ratio_9_255  -0.2
    w_9_1     full_original_Gini_316  -1.8128571428571433e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       -3.7500000000000068e-03
    x_9_2     product_lb_231  -2.5178598191512011e-02
    x_9_2     product_ub_232  -4.2501517911396489e-02
    x_9_2     onehot_9_253  1
    x_9_2     stock_lb_256  2
    x_9_2     stock_ub_257  2
    x_9_2     parent_nonstrict_scope_258  0.0225
    x_9_2     unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_231  1
    w_9_2     product_ub_232  1
    w_9_2     normalized_mass_9_254  1
    w_9_2     normalized_ratio_9_255  -0.4
    w_9_2     full_original_Gini_316  -1.3428571428571425e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -1.1250000000000010e-02
    x_9_3     product_lb_233  -2.5178598191512011e-02
    x_9_3     product_ub_234  -4.2501517911396489e-02
    x_9_3     onehot_9_253  1
    x_9_3     stock_lb_256  3
    x_9_3     stock_ub_257  3
    x_9_3     parent_nonstrict_scope_258  1.4999999999999996e-02
    x_9_3     unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_233  1
    w_9_3     product_ub_234  1
    w_9_3     normalized_mass_9_254  1
    w_9_3     normalized_ratio_9_255  -6.0000000000000009e-01
    w_9_3     full_original_Gini_316  -9.4285714285714270e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -1.8750000000000010e-02
    x_9_4     product_lb_235  -2.5178598191512011e-02
    x_9_4     product_ub_236  -4.2501517911396489e-02
    x_9_4     onehot_9_253  1
    x_9_4     stock_lb_256  4
    x_9_4     stock_ub_257  4
    x_9_4     parent_nonstrict_scope_258  7.4999999999999980e-03
    x_9_4     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_235  1
    w_9_4     product_ub_236  1
    w_9_4     normalized_mass_9_254  1
    w_9_4     normalized_ratio_9_255  -0.8
    w_9_4     full_original_Gini_316  -5.9000000000000012e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -2.6250000000000006e-02
    x_9_5     product_lb_237  -2.5178598191512011e-02
    x_9_5     product_ub_238  -4.2501517911396489e-02
    x_9_5     onehot_9_253  1
    x_9_5     stock_lb_256  5
    x_9_5     stock_ub_257  5
    x_9_5     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_237  1
    w_9_5     product_ub_238  1
    w_9_5     normalized_mass_9_254  1
    w_9_5     normalized_ratio_9_255  -1
    w_9_5     full_original_Gini_316  -4.3714285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -0.01875
    x_9_6     product_lb_239  -2.5178598191512011e-02
    x_9_6     product_ub_240  -4.2501517911396489e-02
    x_9_6     onehot_9_253  1
    x_9_6     stock_lb_256  6
    x_9_6     stock_ub_257  6
    x_9_6     parent_nonstrict_scope_258  7.5000000000000067e-03
    x_9_6     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_239  1
    w_9_6     product_ub_240  1
    w_9_6     normalized_mass_9_254  1
    w_9_6     normalized_ratio_9_255  -1.2000000000000002e+00
    w_9_6     full_original_Gini_316  -8.9714285714285751e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -1.1250000000000001e-02
    x_9_7     product_lb_241  -2.5178598191512011e-02
    x_9_7     product_ub_242  -4.2501517911396489e-02
    x_9_7     onehot_9_253  1
    x_9_7     stock_lb_256  7
    x_9_7     stock_ub_257  7
    x_9_7     parent_nonstrict_scope_258  1.5000000000000005e-02
    x_9_7     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_241  1
    w_9_7     product_ub_242  1
    w_9_7     normalized_mass_9_254  1
    w_9_7     normalized_ratio_9_255  -1.4000000000000001e+00
    w_9_7     full_original_Gini_316  -1.4271428571428579e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       -3.7500000000000033e-03
    x_9_8     product_lb_243  -2.5178598191512011e-02
    x_9_8     product_ub_244  -4.2501517911396489e-02
    x_9_8     onehot_9_253  1
    x_9_8     stock_lb_256  8
    x_9_8     stock_ub_257  8
    x_9_8     parent_nonstrict_scope_258  2.2500000000000003e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_243  1
    w_9_8     product_ub_244  1
    w_9_8     normalized_mass_9_254  1
    w_9_8     normalized_ratio_9_255  -1.6
    w_9_8     full_original_Gini_316  -1.9671428571428571e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       3.7499999999999929e-03
    x_9_9     product_lb_245  -2.5178598191512011e-02
    x_9_9     product_ub_246  -4.2501517911396489e-02
    x_9_9     onehot_9_253  1
    x_9_9     stock_lb_256  9
    x_9_9     stock_ub_257  9
    x_9_9     parent_nonstrict_scope_258  0.03
    x_9_9     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_245  1
    w_9_9     product_ub_246  1
    w_9_9     normalized_mass_9_254  1
    w_9_9     normalized_ratio_9_255  -1.8
    w_9_9     full_original_Gini_316  -2.5071428571428580e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1249999999999993e-02
    x_9_10    product_lb_247  -2.5178598191512011e-02
    x_9_10    product_ub_248  -4.2501517911396489e-02
    x_9_10    onehot_9_253  1
    x_9_10    stock_lb_256  10
    x_9_10    stock_ub_257  10
    x_9_10    parent_nonstrict_scope_258  0.0375
    x_9_10    unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_247  1
    w_9_10    product_ub_248  1
    w_9_10    normalized_mass_9_254  1
    w_9_10    normalized_ratio_9_255  -2
    w_9_10    full_original_Gini_316  -3.0471428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_11    OBJ       0.01875
    x_9_11    product_lb_249  -2.5178598191512011e-02
    x_9_11    product_ub_250  -4.2501517911396489e-02
    x_9_11    onehot_9_253  1
    x_9_11    stock_lb_256  11
    x_9_11    stock_ub_257  11
    x_9_11    parent_nonstrict_scope_258  4.5000000000000005e-02
    x_9_11    unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_11    product_lb_249  1
    w_9_11    product_ub_250  1
    w_9_11    normalized_mass_9_254  1
    w_9_11    normalized_ratio_9_255  -2.2
    w_9_11    full_original_Gini_316  -3.5871428571428567e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_12    OBJ       2.6250000000000006e-02
    x_9_12    product_lb_251  -2.5178598191512011e-02
    x_9_12    product_ub_252  -4.2501517911396489e-02
    x_9_12    onehot_9_253  1
    x_9_12    stock_lb_256  12
    x_9_12    stock_ub_257  12
    x_9_12    parent_nonstrict_scope_258  5.2500000000000012e-02
    x_9_12    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_12    product_lb_251  1
    w_9_12    product_ub_252  1
    w_9_12    normalized_mass_9_254  1
    w_9_12    normalized_ratio_9_255  -2.4000000000000004e+00
    w_9_12    full_original_Gini_316  -4.1271428571428572e+01
    rho_9     normalized_ratio_9_255  1
    rho_9     block_pair_pos_261  1
    rho_9     block_pair_neg_262  -1
    rho_9     block_pair_pos_265  1
    rho_9     block_pair_neg_266  -1
    rho_9     block_pair_pos_269  1
    rho_9     block_pair_neg_270  -1
    rho_9     block_pair_pos_275  1
    rho_9     block_pair_neg_276  -1
    rho_9     block_pair_pos_283  1
    rho_9     block_pair_neg_284  -1
    rho_9     block_pair_pos_295  1
    rho_9     block_pair_neg_296  -1
    rho_9     block_pair_pos_309  1
    rho_9     block_pair_neg_310  -1
    rho_9     normalization_315  1
    a_19_17   block_pair_pos_301  1
    a_19_17   block_pair_neg_302  1
    a_19_17   full_original_Gini_316  -1
    a_19_31   block_pair_pos_303  1
    a_19_31   block_pair_neg_304  1
    a_19_31   full_original_Gini_316  -1
    a_19_15   block_pair_pos_299  1
    a_19_15   block_pair_neg_300  1
    a_19_15   full_original_Gini_316  -1
    a_19_2    block_pair_pos_291  1
    a_19_2    block_pair_neg_292  1
    a_19_2    full_original_Gini_316  -1
    a_19_13   block_pair_pos_297  1
    a_19_13   block_pair_neg_298  1
    a_19_13   full_original_Gini_316  -1
    a_19_6    block_pair_pos_293  1
    a_19_6    block_pair_neg_294  1
    a_19_6    full_original_Gini_316  -1
    a_19_9    block_pair_pos_295  1
    a_19_9    block_pair_neg_296  1
    a_19_9    full_original_Gini_316  -1
    a_17_31   block_pair_pos_289  1
    a_17_31   block_pair_neg_290  1
    a_17_31   full_original_Gini_316  -1
    a_17_15   block_pair_pos_287  1
    a_17_15   block_pair_neg_288  1
    a_17_15   full_original_Gini_316  -1
    a_17_2    block_pair_pos_279  1
    a_17_2    block_pair_neg_280  1
    a_17_2    full_original_Gini_316  -1
    a_17_13   block_pair_pos_285  1
    a_17_13   block_pair_neg_286  1
    a_17_13   full_original_Gini_316  -1
    a_17_6    block_pair_pos_281  1
    a_17_6    block_pair_neg_282  1
    a_17_6    full_original_Gini_316  -1
    a_17_9    block_pair_pos_283  1
    a_17_9    block_pair_neg_284  1
    a_17_9    full_original_Gini_316  -1
    a_31_15   block_pair_pos_313  1
    a_31_15   block_pair_neg_314  1
    a_31_15   full_original_Gini_316  -1
    a_31_2    block_pair_pos_305  1
    a_31_2    block_pair_neg_306  1
    a_31_2    full_original_Gini_316  -1
    a_31_13   block_pair_pos_311  1
    a_31_13   block_pair_neg_312  1
    a_31_13   full_original_Gini_316  -1
    a_31_6    block_pair_pos_307  1
    a_31_6    block_pair_neg_308  1
    a_31_6    full_original_Gini_316  -1
    a_31_9    block_pair_pos_309  1
    a_31_9    block_pair_neg_310  1
    a_31_9    full_original_Gini_316  -1
    a_15_2    block_pair_pos_271  1
    a_15_2    block_pair_neg_272  1
    a_15_2    full_original_Gini_316  -1
    a_15_13   block_pair_pos_277  1
    a_15_13   block_pair_neg_278  1
    a_15_13   full_original_Gini_316  -1
    a_15_6    block_pair_pos_273  1
    a_15_6    block_pair_neg_274  1
    a_15_6    full_original_Gini_316  -1
    a_15_9    block_pair_pos_275  1
    a_15_9    block_pair_neg_276  1
    a_15_9    full_original_Gini_316  -1
    a_2_13    block_pair_pos_263  1
    a_2_13    block_pair_neg_264  1
    a_2_13    full_original_Gini_316  -1
    a_2_6     block_pair_pos_259  1
    a_2_6     block_pair_neg_260  1
    a_2_6     full_original_Gini_316  -1
    a_2_9     block_pair_pos_261  1
    a_2_9     block_pair_neg_262  1
    a_2_9     full_original_Gini_316  -1
    a_13_6    block_pair_pos_267  1
    a_13_6    block_pair_neg_268  1
    a_13_6    full_original_Gini_316  -1
    a_13_9    block_pair_pos_269  1
    a_13_9    block_pair_neg_270  1
    a_13_9    full_original_Gini_316  -1
    a_6_9     block_pair_pos_265  1
    a_6_9     block_pair_neg_266  1
    a_6_9     full_original_Gini_316  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_19_1  unique_nonzero_owner_317  1
    service_0_19_1  service_visit_def_748  1
    service_0_19_1  free_load_conservation_749  1
    service_0_19_2  unique_nonzero_owner_318  1
    service_0_19_2  service_visit_def_748  1
    service_0_19_2  free_load_conservation_749  2
    service_0_19_3  unique_nonzero_owner_319  1
    service_0_19_3  service_visit_def_748  1
    service_0_19_3  free_load_conservation_749  3
    service_0_19_4  unique_nonzero_owner_320  1
    service_0_19_4  service_visit_def_748  1
    service_0_19_4  free_load_conservation_749  4
    service_0_19_5  unique_nonzero_owner_321  1
    service_0_19_5  service_visit_def_748  1
    service_0_19_5  free_load_conservation_749  5
    service_0_19_6  unique_nonzero_owner_322  1
    service_0_19_6  service_visit_def_748  1
    service_0_19_6  free_load_conservation_749  6
    service_0_19_7  unique_nonzero_owner_323  1
    service_0_19_7  service_visit_def_748  1
    service_0_19_7  free_load_conservation_749  7
    service_0_19_8  unique_nonzero_owner_324  1
    service_0_19_8  service_visit_def_748  1
    service_0_19_8  free_load_conservation_749  8
    service_1_19_1  unique_nonzero_owner_317  1
    service_1_19_1  service_visit_def_1119  1
    service_1_19_1  free_load_conservation_1120  1
    service_1_19_2  unique_nonzero_owner_318  1
    service_1_19_2  service_visit_def_1119  1
    service_1_19_2  free_load_conservation_1120  2
    service_1_19_3  unique_nonzero_owner_319  1
    service_1_19_3  service_visit_def_1119  1
    service_1_19_3  free_load_conservation_1120  3
    service_1_19_4  unique_nonzero_owner_320  1
    service_1_19_4  service_visit_def_1119  1
    service_1_19_4  free_load_conservation_1120  4
    service_1_19_5  unique_nonzero_owner_321  1
    service_1_19_5  service_visit_def_1119  1
    service_1_19_5  free_load_conservation_1120  5
    service_1_19_6  unique_nonzero_owner_322  1
    service_1_19_6  service_visit_def_1119  1
    service_1_19_6  free_load_conservation_1120  6
    service_1_19_7  unique_nonzero_owner_323  1
    service_1_19_7  service_visit_def_1119  1
    service_1_19_7  free_load_conservation_1120  7
    service_1_19_8  unique_nonzero_owner_324  1
    service_1_19_8  service_visit_def_1119  1
    service_1_19_8  free_load_conservation_1120  8
    service_2_19_1  unique_nonzero_owner_317  1
    service_2_19_1  service_visit_def_1437  1
    service_2_19_1  free_load_conservation_1438  1
    service_2_19_2  unique_nonzero_owner_318  1
    service_2_19_2  service_visit_def_1437  1
    service_2_19_2  free_load_conservation_1438  2
    service_2_19_3  unique_nonzero_owner_319  1
    service_2_19_3  service_visit_def_1437  1
    service_2_19_3  free_load_conservation_1438  3
    service_2_19_4  unique_nonzero_owner_320  1
    service_2_19_4  service_visit_def_1437  1
    service_2_19_4  free_load_conservation_1438  4
    service_2_19_5  unique_nonzero_owner_321  1
    service_2_19_5  service_visit_def_1437  1
    service_2_19_5  free_load_conservation_1438  5
    service_2_19_6  unique_nonzero_owner_322  1
    service_2_19_6  service_visit_def_1437  1
    service_2_19_6  free_load_conservation_1438  6
    service_2_19_7  unique_nonzero_owner_323  1
    service_2_19_7  service_visit_def_1437  1
    service_2_19_7  free_load_conservation_1438  7
    service_2_19_8  unique_nonzero_owner_324  1
    service_2_19_8  service_visit_def_1437  1
    service_2_19_8  free_load_conservation_1438  8
    service_0_17_0  unique_nonzero_owner_325  1
    service_0_17_0  service_visit_def_754  1
    service_0_17_0  free_load_conservation_755  -3
    service_0_17_0  original_T_including_depot_unload_795  360
    service_0_17_1  unique_nonzero_owner_326  1
    service_0_17_1  service_visit_def_754  1
    service_0_17_1  free_load_conservation_755  -2
    service_0_17_1  original_T_including_depot_unload_795  240
    service_0_17_2  unique_nonzero_owner_327  1
    service_0_17_2  service_visit_def_754  1
    service_0_17_2  free_load_conservation_755  -1
    service_0_17_2  original_T_including_depot_unload_795  120
    service_0_17_4  unique_nonzero_owner_328  1
    service_0_17_4  service_visit_def_754  1
    service_0_17_4  free_load_conservation_755  1
    service_0_17_5  unique_nonzero_owner_329  1
    service_0_17_5  service_visit_def_754  1
    service_0_17_5  free_load_conservation_755  2
    service_0_17_6  unique_nonzero_owner_330  1
    service_0_17_6  service_visit_def_754  1
    service_0_17_6  free_load_conservation_755  3
    service_0_17_7  unique_nonzero_owner_331  1
    service_0_17_7  service_visit_def_754  1
    service_0_17_7  free_load_conservation_755  4
    service_0_17_8  unique_nonzero_owner_332  1
    service_0_17_8  service_visit_def_754  1
    service_0_17_8  free_load_conservation_755  5
    service_0_17_9  unique_nonzero_owner_333  1
    service_0_17_9  service_visit_def_754  1
    service_0_17_9  free_load_conservation_755  6
    service_0_17_10  unique_nonzero_owner_334  1
    service_0_17_10  service_visit_def_754  1
    service_0_17_10  free_load_conservation_755  7
    service_0_17_11  unique_nonzero_owner_335  1
    service_0_17_11  service_visit_def_754  1
    service_0_17_11  free_load_conservation_755  8
    service_0_17_12  unique_nonzero_owner_336  1
    service_0_17_12  service_visit_def_754  1
    service_0_17_12  free_load_conservation_755  9
    service_0_17_13  unique_nonzero_owner_337  1
    service_0_17_13  service_visit_def_754  1
    service_0_17_13  free_load_conservation_755  10
    service_0_17_14  unique_nonzero_owner_338  1
    service_0_17_14  service_visit_def_754  1
    service_0_17_14  free_load_conservation_755  11
    service_0_17_15  unique_nonzero_owner_339  1
    service_0_17_15  service_visit_def_754  1
    service_0_17_15  free_load_conservation_755  12
    service_0_17_16  unique_nonzero_owner_340  1
    service_0_17_16  service_visit_def_754  1
    service_0_17_16  free_load_conservation_755  13
    service_1_17_0  unique_nonzero_owner_325  1
    service_1_17_0  service_visit_def_1125  1
    service_1_17_0  free_load_conservation_1126  -3
    service_1_17_0  original_T_including_depot_unload_1166  360
    service_1_17_1  unique_nonzero_owner_326  1
    service_1_17_1  service_visit_def_1125  1
    service_1_17_1  free_load_conservation_1126  -2
    service_1_17_1  original_T_including_depot_unload_1166  240
    service_1_17_2  unique_nonzero_owner_327  1
    service_1_17_2  service_visit_def_1125  1
    service_1_17_2  free_load_conservation_1126  -1
    service_1_17_2  original_T_including_depot_unload_1166  120
    service_1_17_4  unique_nonzero_owner_328  1
    service_1_17_4  service_visit_def_1125  1
    service_1_17_4  free_load_conservation_1126  1
    service_1_17_5  unique_nonzero_owner_329  1
    service_1_17_5  service_visit_def_1125  1
    service_1_17_5  free_load_conservation_1126  2
    service_1_17_6  unique_nonzero_owner_330  1
    service_1_17_6  service_visit_def_1125  1
    service_1_17_6  free_load_conservation_1126  3
    service_1_17_7  unique_nonzero_owner_331  1
    service_1_17_7  service_visit_def_1125  1
    service_1_17_7  free_load_conservation_1126  4
    service_1_17_8  unique_nonzero_owner_332  1
    service_1_17_8  service_visit_def_1125  1
    service_1_17_8  free_load_conservation_1126  5
    service_1_17_9  unique_nonzero_owner_333  1
    service_1_17_9  service_visit_def_1125  1
    service_1_17_9  free_load_conservation_1126  6
    service_1_17_10  unique_nonzero_owner_334  1
    service_1_17_10  service_visit_def_1125  1
    service_1_17_10  free_load_conservation_1126  7
    service_1_17_11  unique_nonzero_owner_335  1
    service_1_17_11  service_visit_def_1125  1
    service_1_17_11  free_load_conservation_1126  8
    service_1_17_12  unique_nonzero_owner_336  1
    service_1_17_12  service_visit_def_1125  1
    service_1_17_12  free_load_conservation_1126  9
    service_1_17_13  unique_nonzero_owner_337  1
    service_1_17_13  service_visit_def_1125  1
    service_1_17_13  free_load_conservation_1126  10
    service_1_17_14  unique_nonzero_owner_338  1
    service_1_17_14  service_visit_def_1125  1
    service_1_17_14  free_load_conservation_1126  11
    service_1_17_15  unique_nonzero_owner_339  1
    service_1_17_15  service_visit_def_1125  1
    service_1_17_15  free_load_conservation_1126  12
    service_1_17_16  unique_nonzero_owner_340  1
    service_1_17_16  service_visit_def_1125  1
    service_1_17_16  free_load_conservation_1126  13
    service_2_17_0  unique_nonzero_owner_325  1
    service_2_17_0  service_visit_def_1443  1
    service_2_17_0  free_load_conservation_1444  -3
    service_2_17_0  original_T_including_depot_unload_1483  360
    service_2_17_1  unique_nonzero_owner_326  1
    service_2_17_1  service_visit_def_1443  1
    service_2_17_1  free_load_conservation_1444  -2
    service_2_17_1  original_T_including_depot_unload_1483  240
    service_2_17_2  unique_nonzero_owner_327  1
    service_2_17_2  service_visit_def_1443  1
    service_2_17_2  free_load_conservation_1444  -1
    service_2_17_2  original_T_including_depot_unload_1483  120
    service_2_17_4  unique_nonzero_owner_328  1
    service_2_17_4  service_visit_def_1443  1
    service_2_17_4  free_load_conservation_1444  1
    service_2_17_5  unique_nonzero_owner_329  1
    service_2_17_5  service_visit_def_1443  1
    service_2_17_5  free_load_conservation_1444  2
    service_2_17_6  unique_nonzero_owner_330  1
    service_2_17_6  service_visit_def_1443  1
    service_2_17_6  free_load_conservation_1444  3
    service_2_17_7  unique_nonzero_owner_331  1
    service_2_17_7  service_visit_def_1443  1
    service_2_17_7  free_load_conservation_1444  4
    service_2_17_8  unique_nonzero_owner_332  1
    service_2_17_8  service_visit_def_1443  1
    service_2_17_8  free_load_conservation_1444  5
    service_2_17_9  unique_nonzero_owner_333  1
    service_2_17_9  service_visit_def_1443  1
    service_2_17_9  free_load_conservation_1444  6
    service_2_17_10  unique_nonzero_owner_334  1
    service_2_17_10  service_visit_def_1443  1
    service_2_17_10  free_load_conservation_1444  7
    service_2_17_11  unique_nonzero_owner_335  1
    service_2_17_11  service_visit_def_1443  1
    service_2_17_11  free_load_conservation_1444  8
    service_2_17_12  unique_nonzero_owner_336  1
    service_2_17_12  service_visit_def_1443  1
    service_2_17_12  free_load_conservation_1444  9
    service_2_17_13  unique_nonzero_owner_337  1
    service_2_17_13  service_visit_def_1443  1
    service_2_17_13  free_load_conservation_1444  10
    service_2_17_14  unique_nonzero_owner_338  1
    service_2_17_14  service_visit_def_1443  1
    service_2_17_14  free_load_conservation_1444  11
    service_2_17_15  unique_nonzero_owner_339  1
    service_2_17_15  service_visit_def_1443  1
    service_2_17_15  free_load_conservation_1444  12
    service_2_17_16  unique_nonzero_owner_340  1
    service_2_17_16  service_visit_def_1443  1
    service_2_17_16  free_load_conservation_1444  13
    service_0_31_0  unique_nonzero_owner_341  1
    service_0_31_0  service_visit_def_760  1
    service_0_31_0  free_load_conservation_761  -2
    service_0_31_0  original_T_including_depot_unload_795  240
    service_0_31_1  unique_nonzero_owner_342  1
    service_0_31_1  service_visit_def_760  1
    service_0_31_1  free_load_conservation_761  -1
    service_0_31_1  original_T_including_depot_unload_795  120
    service_0_31_3  unique_nonzero_owner_343  1
    service_0_31_3  service_visit_def_760  1
    service_0_31_3  free_load_conservation_761  1
    service_0_31_4  unique_nonzero_owner_344  1
    service_0_31_4  service_visit_def_760  1
    service_0_31_4  free_load_conservation_761  2
    service_0_31_5  unique_nonzero_owner_345  1
    service_0_31_5  service_visit_def_760  1
    service_0_31_5  free_load_conservation_761  3
    service_0_31_6  unique_nonzero_owner_346  1
    service_0_31_6  service_visit_def_760  1
    service_0_31_6  free_load_conservation_761  4
    service_0_31_7  unique_nonzero_owner_347  1
    service_0_31_7  service_visit_def_760  1
    service_0_31_7  free_load_conservation_761  5
    service_0_31_8  unique_nonzero_owner_348  1
    service_0_31_8  service_visit_def_760  1
    service_0_31_8  free_load_conservation_761  6
    service_0_31_9  unique_nonzero_owner_349  1
    service_0_31_9  service_visit_def_760  1
    service_0_31_9  free_load_conservation_761  7
    service_0_31_10  unique_nonzero_owner_350  1
    service_0_31_10  service_visit_def_760  1
    service_0_31_10  free_load_conservation_761  8
    service_0_31_11  unique_nonzero_owner_351  1
    service_0_31_11  service_visit_def_760  1
    service_0_31_11  free_load_conservation_761  9
    service_0_31_12  unique_nonzero_owner_352  1
    service_0_31_12  service_visit_def_760  1
    service_0_31_12  free_load_conservation_761  10
    service_1_31_0  unique_nonzero_owner_341  1
    service_1_31_0  service_visit_def_1131  1
    service_1_31_0  free_load_conservation_1132  -2
    service_1_31_0  original_T_including_depot_unload_1166  240
    service_1_31_1  unique_nonzero_owner_342  1
    service_1_31_1  service_visit_def_1131  1
    service_1_31_1  free_load_conservation_1132  -1
    service_1_31_1  original_T_including_depot_unload_1166  120
    service_1_31_3  unique_nonzero_owner_343  1
    service_1_31_3  service_visit_def_1131  1
    service_1_31_3  free_load_conservation_1132  1
    service_1_31_4  unique_nonzero_owner_344  1
    service_1_31_4  service_visit_def_1131  1
    service_1_31_4  free_load_conservation_1132  2
    service_1_31_5  unique_nonzero_owner_345  1
    service_1_31_5  service_visit_def_1131  1
    service_1_31_5  free_load_conservation_1132  3
    service_1_31_6  unique_nonzero_owner_346  1
    service_1_31_6  service_visit_def_1131  1
    service_1_31_6  free_load_conservation_1132  4
    service_1_31_7  unique_nonzero_owner_347  1
    service_1_31_7  service_visit_def_1131  1
    service_1_31_7  free_load_conservation_1132  5
    service_1_31_8  unique_nonzero_owner_348  1
    service_1_31_8  service_visit_def_1131  1
    service_1_31_8  free_load_conservation_1132  6
    service_1_31_9  unique_nonzero_owner_349  1
    service_1_31_9  service_visit_def_1131  1
    service_1_31_9  free_load_conservation_1132  7
    service_1_31_10  unique_nonzero_owner_350  1
    service_1_31_10  service_visit_def_1131  1
    service_1_31_10  free_load_conservation_1132  8
    service_1_31_11  unique_nonzero_owner_351  1
    service_1_31_11  service_visit_def_1131  1
    service_1_31_11  free_load_conservation_1132  9
    service_1_31_12  unique_nonzero_owner_352  1
    service_1_31_12  service_visit_def_1131  1
    service_1_31_12  free_load_conservation_1132  10
    service_2_31_0  unique_nonzero_owner_341  1
    service_2_31_0  service_visit_def_1449  1
    service_2_31_0  free_load_conservation_1450  -2
    service_2_31_0  original_T_including_depot_unload_1483  240
    service_2_31_1  unique_nonzero_owner_342  1
    service_2_31_1  service_visit_def_1449  1
    service_2_31_1  free_load_conservation_1450  -1
    service_2_31_1  original_T_including_depot_unload_1483  120
    service_2_31_3  unique_nonzero_owner_343  1
    service_2_31_3  service_visit_def_1449  1
    service_2_31_3  free_load_conservation_1450  1
    service_2_31_4  unique_nonzero_owner_344  1
    service_2_31_4  service_visit_def_1449  1
    service_2_31_4  free_load_conservation_1450  2
    service_2_31_5  unique_nonzero_owner_345  1
    service_2_31_5  service_visit_def_1449  1
    service_2_31_5  free_load_conservation_1450  3
    service_2_31_6  unique_nonzero_owner_346  1
    service_2_31_6  service_visit_def_1449  1
    service_2_31_6  free_load_conservation_1450  4
    service_2_31_7  unique_nonzero_owner_347  1
    service_2_31_7  service_visit_def_1449  1
    service_2_31_7  free_load_conservation_1450  5
    service_2_31_8  unique_nonzero_owner_348  1
    service_2_31_8  service_visit_def_1449  1
    service_2_31_8  free_load_conservation_1450  6
    service_2_31_9  unique_nonzero_owner_349  1
    service_2_31_9  service_visit_def_1449  1
    service_2_31_9  free_load_conservation_1450  7
    service_2_31_10  unique_nonzero_owner_350  1
    service_2_31_10  service_visit_def_1449  1
    service_2_31_10  free_load_conservation_1450  8
    service_2_31_11  unique_nonzero_owner_351  1
    service_2_31_11  service_visit_def_1449  1
    service_2_31_11  free_load_conservation_1450  9
    service_2_31_12  unique_nonzero_owner_352  1
    service_2_31_12  service_visit_def_1449  1
    service_2_31_12  free_load_conservation_1450  10
    service_0_15_0  unique_nonzero_owner_353  1
    service_0_15_0  service_visit_def_766  1
    service_0_15_0  free_load_conservation_767  -3
    service_0_15_0  original_T_including_depot_unload_795  360
    service_0_15_1  unique_nonzero_owner_354  1
    service_0_15_1  service_visit_def_766  1
    service_0_15_1  free_load_conservation_767  -2
    service_0_15_1  original_T_including_depot_unload_795  240
    service_0_15_2  unique_nonzero_owner_355  1
    service_0_15_2  service_visit_def_766  1
    service_0_15_2  free_load_conservation_767  -1
    service_0_15_2  original_T_including_depot_unload_795  120
    service_0_15_4  unique_nonzero_owner_356  1
    service_0_15_4  service_visit_def_766  1
    service_0_15_4  free_load_conservation_767  1
    service_0_15_5  unique_nonzero_owner_357  1
    service_0_15_5  service_visit_def_766  1
    service_0_15_5  free_load_conservation_767  2
    service_0_15_6  unique_nonzero_owner_358  1
    service_0_15_6  service_visit_def_766  1
    service_0_15_6  free_load_conservation_767  3
    service_0_15_7  unique_nonzero_owner_359  1
    service_0_15_7  service_visit_def_766  1
    service_0_15_7  free_load_conservation_767  4
    service_0_15_8  unique_nonzero_owner_360  1
    service_0_15_8  service_visit_def_766  1
    service_0_15_8  free_load_conservation_767  5
    service_0_15_9  unique_nonzero_owner_361  1
    service_0_15_9  service_visit_def_766  1
    service_0_15_9  free_load_conservation_767  6
    service_0_15_10  unique_nonzero_owner_362  1
    service_0_15_10  service_visit_def_766  1
    service_0_15_10  free_load_conservation_767  7
    service_0_15_11  unique_nonzero_owner_363  1
    service_0_15_11  service_visit_def_766  1
    service_0_15_11  free_load_conservation_767  8
    service_0_15_12  unique_nonzero_owner_364  1
    service_0_15_12  service_visit_def_766  1
    service_0_15_12  free_load_conservation_767  9
    service_0_15_13  unique_nonzero_owner_365  1
    service_0_15_13  service_visit_def_766  1
    service_0_15_13  free_load_conservation_767  10
    service_0_15_14  unique_nonzero_owner_366  1
    service_0_15_14  service_visit_def_766  1
    service_0_15_14  free_load_conservation_767  11
    service_0_15_15  unique_nonzero_owner_367  1
    service_0_15_15  service_visit_def_766  1
    service_0_15_15  free_load_conservation_767  12
    service_0_15_16  unique_nonzero_owner_368  1
    service_0_15_16  service_visit_def_766  1
    service_0_15_16  free_load_conservation_767  13
    service_1_15_0  unique_nonzero_owner_353  1
    service_1_15_0  service_visit_def_1137  1
    service_1_15_0  free_load_conservation_1138  -3
    service_1_15_0  original_T_including_depot_unload_1166  360
    service_1_15_1  unique_nonzero_owner_354  1
    service_1_15_1  service_visit_def_1137  1
    service_1_15_1  free_load_conservation_1138  -2
    service_1_15_1  original_T_including_depot_unload_1166  240
    service_1_15_2  unique_nonzero_owner_355  1
    service_1_15_2  service_visit_def_1137  1
    service_1_15_2  free_load_conservation_1138  -1
    service_1_15_2  original_T_including_depot_unload_1166  120
    service_1_15_4  unique_nonzero_owner_356  1
    service_1_15_4  service_visit_def_1137  1
    service_1_15_4  free_load_conservation_1138  1
    service_1_15_5  unique_nonzero_owner_357  1
    service_1_15_5  service_visit_def_1137  1
    service_1_15_5  free_load_conservation_1138  2
    service_1_15_6  unique_nonzero_owner_358  1
    service_1_15_6  service_visit_def_1137  1
    service_1_15_6  free_load_conservation_1138  3
    service_1_15_7  unique_nonzero_owner_359  1
    service_1_15_7  service_visit_def_1137  1
    service_1_15_7  free_load_conservation_1138  4
    service_1_15_8  unique_nonzero_owner_360  1
    service_1_15_8  service_visit_def_1137  1
    service_1_15_8  free_load_conservation_1138  5
    service_1_15_9  unique_nonzero_owner_361  1
    service_1_15_9  service_visit_def_1137  1
    service_1_15_9  free_load_conservation_1138  6
    service_1_15_10  unique_nonzero_owner_362  1
    service_1_15_10  service_visit_def_1137  1
    service_1_15_10  free_load_conservation_1138  7
    service_1_15_11  unique_nonzero_owner_363  1
    service_1_15_11  service_visit_def_1137  1
    service_1_15_11  free_load_conservation_1138  8
    service_1_15_12  unique_nonzero_owner_364  1
    service_1_15_12  service_visit_def_1137  1
    service_1_15_12  free_load_conservation_1138  9
    service_1_15_13  unique_nonzero_owner_365  1
    service_1_15_13  service_visit_def_1137  1
    service_1_15_13  free_load_conservation_1138  10
    service_1_15_14  unique_nonzero_owner_366  1
    service_1_15_14  service_visit_def_1137  1
    service_1_15_14  free_load_conservation_1138  11
    service_1_15_15  unique_nonzero_owner_367  1
    service_1_15_15  service_visit_def_1137  1
    service_1_15_15  free_load_conservation_1138  12
    service_1_15_16  unique_nonzero_owner_368  1
    service_1_15_16  service_visit_def_1137  1
    service_1_15_16  free_load_conservation_1138  13
    service_2_15_0  unique_nonzero_owner_353  1
    service_2_15_0  service_visit_def_1455  1
    service_2_15_0  free_load_conservation_1456  -3
    service_2_15_0  original_T_including_depot_unload_1483  360
    service_2_15_1  unique_nonzero_owner_354  1
    service_2_15_1  service_visit_def_1455  1
    service_2_15_1  free_load_conservation_1456  -2
    service_2_15_1  original_T_including_depot_unload_1483  240
    service_2_15_2  unique_nonzero_owner_355  1
    service_2_15_2  service_visit_def_1455  1
    service_2_15_2  free_load_conservation_1456  -1
    service_2_15_2  original_T_including_depot_unload_1483  120
    service_2_15_4  unique_nonzero_owner_356  1
    service_2_15_4  service_visit_def_1455  1
    service_2_15_4  free_load_conservation_1456  1
    service_2_15_5  unique_nonzero_owner_357  1
    service_2_15_5  service_visit_def_1455  1
    service_2_15_5  free_load_conservation_1456  2
    service_2_15_6  unique_nonzero_owner_358  1
    service_2_15_6  service_visit_def_1455  1
    service_2_15_6  free_load_conservation_1456  3
    service_2_15_7  unique_nonzero_owner_359  1
    service_2_15_7  service_visit_def_1455  1
    service_2_15_7  free_load_conservation_1456  4
    service_2_15_8  unique_nonzero_owner_360  1
    service_2_15_8  service_visit_def_1455  1
    service_2_15_8  free_load_conservation_1456  5
    service_2_15_9  unique_nonzero_owner_361  1
    service_2_15_9  service_visit_def_1455  1
    service_2_15_9  free_load_conservation_1456  6
    service_2_15_10  unique_nonzero_owner_362  1
    service_2_15_10  service_visit_def_1455  1
    service_2_15_10  free_load_conservation_1456  7
    service_2_15_11  unique_nonzero_owner_363  1
    service_2_15_11  service_visit_def_1455  1
    service_2_15_11  free_load_conservation_1456  8
    service_2_15_12  unique_nonzero_owner_364  1
    service_2_15_12  service_visit_def_1455  1
    service_2_15_12  free_load_conservation_1456  9
    service_2_15_13  unique_nonzero_owner_365  1
    service_2_15_13  service_visit_def_1455  1
    service_2_15_13  free_load_conservation_1456  10
    service_2_15_14  unique_nonzero_owner_366  1
    service_2_15_14  service_visit_def_1455  1
    service_2_15_14  free_load_conservation_1456  11
    service_2_15_15  unique_nonzero_owner_367  1
    service_2_15_15  service_visit_def_1455  1
    service_2_15_15  free_load_conservation_1456  12
    service_2_15_16  unique_nonzero_owner_368  1
    service_2_15_16  service_visit_def_1455  1
    service_2_15_16  free_load_conservation_1456  13
    service_0_2_1  unique_nonzero_owner_369  1
    service_0_2_1  service_visit_def_772  1
    service_0_2_1  free_load_conservation_773  1
    service_0_2_2  unique_nonzero_owner_370  1
    service_0_2_2  service_visit_def_772  1
    service_0_2_2  free_load_conservation_773  2
    service_0_2_3  unique_nonzero_owner_371  1
    service_0_2_3  service_visit_def_772  1
    service_0_2_3  free_load_conservation_773  3
    service_0_2_4  unique_nonzero_owner_372  1
    service_0_2_4  service_visit_def_772  1
    service_0_2_4  free_load_conservation_773  4
    service_0_2_5  unique_nonzero_owner_373  1
    service_0_2_5  service_visit_def_772  1
    service_0_2_5  free_load_conservation_773  5
    service_0_2_6  unique_nonzero_owner_374  1
    service_0_2_6  service_visit_def_772  1
    service_0_2_6  free_load_conservation_773  6
    service_0_2_7  unique_nonzero_owner_375  1
    service_0_2_7  service_visit_def_772  1
    service_0_2_7  free_load_conservation_773  7
    service_0_2_8  unique_nonzero_owner_376  1
    service_0_2_8  service_visit_def_772  1
    service_0_2_8  free_load_conservation_773  8
    service_0_2_9  unique_nonzero_owner_377  1
    service_0_2_9  service_visit_def_772  1
    service_0_2_9  free_load_conservation_773  9
    service_0_2_10  unique_nonzero_owner_378  1
    service_0_2_10  service_visit_def_772  1
    service_0_2_10  free_load_conservation_773  10
    service_0_2_11  unique_nonzero_owner_379  1
    service_0_2_11  service_visit_def_772  1
    service_0_2_11  free_load_conservation_773  11
    service_0_2_12  unique_nonzero_owner_380  1
    service_0_2_12  service_visit_def_772  1
    service_0_2_12  free_load_conservation_773  12
    service_0_2_13  unique_nonzero_owner_381  1
    service_0_2_13  service_visit_def_772  1
    service_0_2_13  free_load_conservation_773  13
    service_0_2_14  unique_nonzero_owner_382  1
    service_0_2_14  service_visit_def_772  1
    service_0_2_14  free_load_conservation_773  14
    service_0_2_15  unique_nonzero_owner_383  1
    service_0_2_15  service_visit_def_772  1
    service_0_2_15  free_load_conservation_773  15
    service_1_2_1  unique_nonzero_owner_369  1
    service_1_2_1  service_visit_def_1143  1
    service_1_2_1  free_load_conservation_1144  1
    service_1_2_2  unique_nonzero_owner_370  1
    service_1_2_2  service_visit_def_1143  1
    service_1_2_2  free_load_conservation_1144  2
    service_1_2_3  unique_nonzero_owner_371  1
    service_1_2_3  service_visit_def_1143  1
    service_1_2_3  free_load_conservation_1144  3
    service_1_2_4  unique_nonzero_owner_372  1
    service_1_2_4  service_visit_def_1143  1
    service_1_2_4  free_load_conservation_1144  4
    service_1_2_5  unique_nonzero_owner_373  1
    service_1_2_5  service_visit_def_1143  1
    service_1_2_5  free_load_conservation_1144  5
    service_1_2_6  unique_nonzero_owner_374  1
    service_1_2_6  service_visit_def_1143  1
    service_1_2_6  free_load_conservation_1144  6
    service_1_2_7  unique_nonzero_owner_375  1
    service_1_2_7  service_visit_def_1143  1
    service_1_2_7  free_load_conservation_1144  7
    service_1_2_8  unique_nonzero_owner_376  1
    service_1_2_8  service_visit_def_1143  1
    service_1_2_8  free_load_conservation_1144  8
    service_1_2_9  unique_nonzero_owner_377  1
    service_1_2_9  service_visit_def_1143  1
    service_1_2_9  free_load_conservation_1144  9
    service_1_2_10  unique_nonzero_owner_378  1
    service_1_2_10  service_visit_def_1143  1
    service_1_2_10  free_load_conservation_1144  10
    service_1_2_11  unique_nonzero_owner_379  1
    service_1_2_11  service_visit_def_1143  1
    service_1_2_11  free_load_conservation_1144  11
    service_1_2_12  unique_nonzero_owner_380  1
    service_1_2_12  service_visit_def_1143  1
    service_1_2_12  free_load_conservation_1144  12
    service_1_2_13  unique_nonzero_owner_381  1
    service_1_2_13  service_visit_def_1143  1
    service_1_2_13  free_load_conservation_1144  13
    service_1_2_14  unique_nonzero_owner_382  1
    service_1_2_14  service_visit_def_1143  1
    service_1_2_14  free_load_conservation_1144  14
    service_1_2_15  unique_nonzero_owner_383  1
    service_1_2_15  service_visit_def_1143  1
    service_1_2_15  free_load_conservation_1144  15
    service_2_2_1  unique_nonzero_owner_369  1
    service_2_2_1  service_visit_def_1461  1
    service_2_2_1  free_load_conservation_1462  1
    service_2_2_2  unique_nonzero_owner_370  1
    service_2_2_2  service_visit_def_1461  1
    service_2_2_2  free_load_conservation_1462  2
    service_2_2_3  unique_nonzero_owner_371  1
    service_2_2_3  service_visit_def_1461  1
    service_2_2_3  free_load_conservation_1462  3
    service_2_2_4  unique_nonzero_owner_372  1
    service_2_2_4  service_visit_def_1461  1
    service_2_2_4  free_load_conservation_1462  4
    service_2_2_5  unique_nonzero_owner_373  1
    service_2_2_5  service_visit_def_1461  1
    service_2_2_5  free_load_conservation_1462  5
    service_2_2_6  unique_nonzero_owner_374  1
    service_2_2_6  service_visit_def_1461  1
    service_2_2_6  free_load_conservation_1462  6
    service_2_2_7  unique_nonzero_owner_375  1
    service_2_2_7  service_visit_def_1461  1
    service_2_2_7  free_load_conservation_1462  7
    service_2_2_8  unique_nonzero_owner_376  1
    service_2_2_8  service_visit_def_1461  1
    service_2_2_8  free_load_conservation_1462  8
    service_2_2_9  unique_nonzero_owner_377  1
    service_2_2_9  service_visit_def_1461  1
    service_2_2_9  free_load_conservation_1462  9
    service_2_2_10  unique_nonzero_owner_378  1
    service_2_2_10  service_visit_def_1461  1
    service_2_2_10  free_load_conservation_1462  10
    service_2_2_11  unique_nonzero_owner_379  1
    service_2_2_11  service_visit_def_1461  1
    service_2_2_11  free_load_conservation_1462  11
    service_2_2_12  unique_nonzero_owner_380  1
    service_2_2_12  service_visit_def_1461  1
    service_2_2_12  free_load_conservation_1462  12
    service_2_2_13  unique_nonzero_owner_381  1
    service_2_2_13  service_visit_def_1461  1
    service_2_2_13  free_load_conservation_1462  13
    service_2_2_14  unique_nonzero_owner_382  1
    service_2_2_14  service_visit_def_1461  1
    service_2_2_14  free_load_conservation_1462  14
    service_2_2_15  unique_nonzero_owner_383  1
    service_2_2_15  service_visit_def_1461  1
    service_2_2_15  free_load_conservation_1462  15
    service_0_13_0  unique_nonzero_owner_384  1
    service_0_13_0  service_visit_def_778  1
    service_0_13_0  free_load_conservation_779  -13
    service_0_13_0  original_T_including_depot_unload_795  1560
    service_0_13_1  unique_nonzero_owner_385  1
    service_0_13_1  service_visit_def_778  1
    service_0_13_1  free_load_conservation_779  -12
    service_0_13_1  original_T_including_depot_unload_795  1440
    service_0_13_2  unique_nonzero_owner_386  1
    service_0_13_2  service_visit_def_778  1
    service_0_13_2  free_load_conservation_779  -11
    service_0_13_2  original_T_including_depot_unload_795  1320
    service_0_13_3  unique_nonzero_owner_387  1
    service_0_13_3  service_visit_def_778  1
    service_0_13_3  free_load_conservation_779  -10
    service_0_13_3  original_T_including_depot_unload_795  1200
    service_0_13_4  unique_nonzero_owner_388  1
    service_0_13_4  service_visit_def_778  1
    service_0_13_4  free_load_conservation_779  -9
    service_0_13_4  original_T_including_depot_unload_795  1080
    service_0_13_5  unique_nonzero_owner_389  1
    service_0_13_5  service_visit_def_778  1
    service_0_13_5  free_load_conservation_779  -8
    service_0_13_5  original_T_including_depot_unload_795  960
    service_0_13_6  unique_nonzero_owner_390  1
    service_0_13_6  service_visit_def_778  1
    service_0_13_6  free_load_conservation_779  -7
    service_0_13_6  original_T_including_depot_unload_795  840
    service_0_13_7  unique_nonzero_owner_391  1
    service_0_13_7  service_visit_def_778  1
    service_0_13_7  free_load_conservation_779  -6
    service_0_13_7  original_T_including_depot_unload_795  720
    service_0_13_8  unique_nonzero_owner_392  1
    service_0_13_8  service_visit_def_778  1
    service_0_13_8  free_load_conservation_779  -5
    service_0_13_8  original_T_including_depot_unload_795  600
    service_0_13_9  unique_nonzero_owner_393  1
    service_0_13_9  service_visit_def_778  1
    service_0_13_9  free_load_conservation_779  -4
    service_0_13_9  original_T_including_depot_unload_795  480
    service_0_13_10  unique_nonzero_owner_394  1
    service_0_13_10  service_visit_def_778  1
    service_0_13_10  free_load_conservation_779  -3
    service_0_13_10  original_T_including_depot_unload_795  360
    service_0_13_11  unique_nonzero_owner_395  1
    service_0_13_11  service_visit_def_778  1
    service_0_13_11  free_load_conservation_779  -2
    service_0_13_11  original_T_including_depot_unload_795  240
    service_0_13_12  unique_nonzero_owner_396  1
    service_0_13_12  service_visit_def_778  1
    service_0_13_12  free_load_conservation_779  -1
    service_0_13_12  original_T_including_depot_unload_795  120
    service_0_13_14  unique_nonzero_owner_397  1
    service_0_13_14  service_visit_def_778  1
    service_0_13_14  free_load_conservation_779  1
    service_0_13_15  unique_nonzero_owner_398  1
    service_0_13_15  service_visit_def_778  1
    service_0_13_15  free_load_conservation_779  2
    service_0_13_16  unique_nonzero_owner_399  1
    service_0_13_16  service_visit_def_778  1
    service_0_13_16  free_load_conservation_779  3
    service_0_13_17  unique_nonzero_owner_400  1
    service_0_13_17  service_visit_def_778  1
    service_0_13_17  free_load_conservation_779  4
    service_0_13_18  unique_nonzero_owner_401  1
    service_0_13_18  service_visit_def_778  1
    service_0_13_18  free_load_conservation_779  5
    service_0_13_19  unique_nonzero_owner_402  1
    service_0_13_19  service_visit_def_778  1
    service_0_13_19  free_load_conservation_779  6
    service_1_13_0  unique_nonzero_owner_384  1
    service_1_13_0  service_visit_def_1149  1
    service_1_13_0  free_load_conservation_1150  -13
    service_1_13_0  original_T_including_depot_unload_1166  1560
    service_1_13_1  unique_nonzero_owner_385  1
    service_1_13_1  service_visit_def_1149  1
    service_1_13_1  free_load_conservation_1150  -12
    service_1_13_1  original_T_including_depot_unload_1166  1440
    service_1_13_2  unique_nonzero_owner_386  1
    service_1_13_2  service_visit_def_1149  1
    service_1_13_2  free_load_conservation_1150  -11
    service_1_13_2  original_T_including_depot_unload_1166  1320
    service_1_13_3  unique_nonzero_owner_387  1
    service_1_13_3  service_visit_def_1149  1
    service_1_13_3  free_load_conservation_1150  -10
    service_1_13_3  original_T_including_depot_unload_1166  1200
    service_1_13_4  unique_nonzero_owner_388  1
    service_1_13_4  service_visit_def_1149  1
    service_1_13_4  free_load_conservation_1150  -9
    service_1_13_4  original_T_including_depot_unload_1166  1080
    service_1_13_5  unique_nonzero_owner_389  1
    service_1_13_5  service_visit_def_1149  1
    service_1_13_5  free_load_conservation_1150  -8
    service_1_13_5  original_T_including_depot_unload_1166  960
    service_1_13_6  unique_nonzero_owner_390  1
    service_1_13_6  service_visit_def_1149  1
    service_1_13_6  free_load_conservation_1150  -7
    service_1_13_6  original_T_including_depot_unload_1166  840
    service_1_13_7  unique_nonzero_owner_391  1
    service_1_13_7  service_visit_def_1149  1
    service_1_13_7  free_load_conservation_1150  -6
    service_1_13_7  original_T_including_depot_unload_1166  720
    service_1_13_8  unique_nonzero_owner_392  1
    service_1_13_8  service_visit_def_1149  1
    service_1_13_8  free_load_conservation_1150  -5
    service_1_13_8  original_T_including_depot_unload_1166  600
    service_1_13_9  unique_nonzero_owner_393  1
    service_1_13_9  service_visit_def_1149  1
    service_1_13_9  free_load_conservation_1150  -4
    service_1_13_9  original_T_including_depot_unload_1166  480
    service_1_13_10  unique_nonzero_owner_394  1
    service_1_13_10  service_visit_def_1149  1
    service_1_13_10  free_load_conservation_1150  -3
    service_1_13_10  original_T_including_depot_unload_1166  360
    service_1_13_11  unique_nonzero_owner_395  1
    service_1_13_11  service_visit_def_1149  1
    service_1_13_11  free_load_conservation_1150  -2
    service_1_13_11  original_T_including_depot_unload_1166  240
    service_1_13_12  unique_nonzero_owner_396  1
    service_1_13_12  service_visit_def_1149  1
    service_1_13_12  free_load_conservation_1150  -1
    service_1_13_12  original_T_including_depot_unload_1166  120
    service_1_13_14  unique_nonzero_owner_397  1
    service_1_13_14  service_visit_def_1149  1
    service_1_13_14  free_load_conservation_1150  1
    service_1_13_15  unique_nonzero_owner_398  1
    service_1_13_15  service_visit_def_1149  1
    service_1_13_15  free_load_conservation_1150  2
    service_1_13_16  unique_nonzero_owner_399  1
    service_1_13_16  service_visit_def_1149  1
    service_1_13_16  free_load_conservation_1150  3
    service_1_13_17  unique_nonzero_owner_400  1
    service_1_13_17  service_visit_def_1149  1
    service_1_13_17  free_load_conservation_1150  4
    service_1_13_18  unique_nonzero_owner_401  1
    service_1_13_18  service_visit_def_1149  1
    service_1_13_18  free_load_conservation_1150  5
    service_1_13_19  unique_nonzero_owner_402  1
    service_1_13_19  service_visit_def_1149  1
    service_1_13_19  free_load_conservation_1150  6
    service_2_13_0  unique_nonzero_owner_384  1
    service_2_13_0  service_visit_def_1467  1
    service_2_13_0  free_load_conservation_1468  -13
    service_2_13_0  original_T_including_depot_unload_1483  1560
    service_2_13_1  unique_nonzero_owner_385  1
    service_2_13_1  service_visit_def_1467  1
    service_2_13_1  free_load_conservation_1468  -12
    service_2_13_1  original_T_including_depot_unload_1483  1440
    service_2_13_2  unique_nonzero_owner_386  1
    service_2_13_2  service_visit_def_1467  1
    service_2_13_2  free_load_conservation_1468  -11
    service_2_13_2  original_T_including_depot_unload_1483  1320
    service_2_13_3  unique_nonzero_owner_387  1
    service_2_13_3  service_visit_def_1467  1
    service_2_13_3  free_load_conservation_1468  -10
    service_2_13_3  original_T_including_depot_unload_1483  1200
    service_2_13_4  unique_nonzero_owner_388  1
    service_2_13_4  service_visit_def_1467  1
    service_2_13_4  free_load_conservation_1468  -9
    service_2_13_4  original_T_including_depot_unload_1483  1080
    service_2_13_5  unique_nonzero_owner_389  1
    service_2_13_5  service_visit_def_1467  1
    service_2_13_5  free_load_conservation_1468  -8
    service_2_13_5  original_T_including_depot_unload_1483  960
    service_2_13_6  unique_nonzero_owner_390  1
    service_2_13_6  service_visit_def_1467  1
    service_2_13_6  free_load_conservation_1468  -7
    service_2_13_6  original_T_including_depot_unload_1483  840
    service_2_13_7  unique_nonzero_owner_391  1
    service_2_13_7  service_visit_def_1467  1
    service_2_13_7  free_load_conservation_1468  -6
    service_2_13_7  original_T_including_depot_unload_1483  720
    service_2_13_8  unique_nonzero_owner_392  1
    service_2_13_8  service_visit_def_1467  1
    service_2_13_8  free_load_conservation_1468  -5
    service_2_13_8  original_T_including_depot_unload_1483  600
    service_2_13_9  unique_nonzero_owner_393  1
    service_2_13_9  service_visit_def_1467  1
    service_2_13_9  free_load_conservation_1468  -4
    service_2_13_9  original_T_including_depot_unload_1483  480
    service_2_13_10  unique_nonzero_owner_394  1
    service_2_13_10  service_visit_def_1467  1
    service_2_13_10  free_load_conservation_1468  -3
    service_2_13_10  original_T_including_depot_unload_1483  360
    service_2_13_11  unique_nonzero_owner_395  1
    service_2_13_11  service_visit_def_1467  1
    service_2_13_11  free_load_conservation_1468  -2
    service_2_13_11  original_T_including_depot_unload_1483  240
    service_2_13_12  unique_nonzero_owner_396  1
    service_2_13_12  service_visit_def_1467  1
    service_2_13_12  free_load_conservation_1468  -1
    service_2_13_12  original_T_including_depot_unload_1483  120
    service_2_13_14  unique_nonzero_owner_397  1
    service_2_13_14  service_visit_def_1467  1
    service_2_13_14  free_load_conservation_1468  1
    service_2_13_15  unique_nonzero_owner_398  1
    service_2_13_15  service_visit_def_1467  1
    service_2_13_15  free_load_conservation_1468  2
    service_2_13_16  unique_nonzero_owner_399  1
    service_2_13_16  service_visit_def_1467  1
    service_2_13_16  free_load_conservation_1468  3
    service_2_13_17  unique_nonzero_owner_400  1
    service_2_13_17  service_visit_def_1467  1
    service_2_13_17  free_load_conservation_1468  4
    service_2_13_18  unique_nonzero_owner_401  1
    service_2_13_18  service_visit_def_1467  1
    service_2_13_18  free_load_conservation_1468  5
    service_2_13_19  unique_nonzero_owner_402  1
    service_2_13_19  service_visit_def_1467  1
    service_2_13_19  free_load_conservation_1468  6
    service_0_6_0  unique_nonzero_owner_403  1
    service_0_6_0  service_visit_def_784  1
    service_0_6_0  free_load_conservation_785  -1
    service_0_6_0  original_T_including_depot_unload_795  120
    service_0_6_2  unique_nonzero_owner_404  1
    service_0_6_2  service_visit_def_784  1
    service_0_6_2  free_load_conservation_785  1
    service_0_6_3  unique_nonzero_owner_405  1
    service_0_6_3  service_visit_def_784  1
    service_0_6_3  free_load_conservation_785  2
    service_0_6_4  unique_nonzero_owner_406  1
    service_0_6_4  service_visit_def_784  1
    service_0_6_4  free_load_conservation_785  3
    service_0_6_5  unique_nonzero_owner_407  1
    service_0_6_5  service_visit_def_784  1
    service_0_6_5  free_load_conservation_785  4
    service_0_6_6  unique_nonzero_owner_408  1
    service_0_6_6  service_visit_def_784  1
    service_0_6_6  free_load_conservation_785  5
    service_0_6_7  unique_nonzero_owner_409  1
    service_0_6_7  service_visit_def_784  1
    service_0_6_7  free_load_conservation_785  6
    service_0_6_8  unique_nonzero_owner_410  1
    service_0_6_8  service_visit_def_784  1
    service_0_6_8  free_load_conservation_785  7
    service_0_6_9  unique_nonzero_owner_411  1
    service_0_6_9  service_visit_def_784  1
    service_0_6_9  free_load_conservation_785  8
    service_0_6_10  unique_nonzero_owner_412  1
    service_0_6_10  service_visit_def_784  1
    service_0_6_10  free_load_conservation_785  9
    service_1_6_0  unique_nonzero_owner_403  1
    service_1_6_0  service_visit_def_1155  1
    service_1_6_0  free_load_conservation_1156  -1
    service_1_6_0  original_T_including_depot_unload_1166  120
    service_1_6_2  unique_nonzero_owner_404  1
    service_1_6_2  service_visit_def_1155  1
    service_1_6_2  free_load_conservation_1156  1
    service_1_6_3  unique_nonzero_owner_405  1
    service_1_6_3  service_visit_def_1155  1
    service_1_6_3  free_load_conservation_1156  2
    service_1_6_4  unique_nonzero_owner_406  1
    service_1_6_4  service_visit_def_1155  1
    service_1_6_4  free_load_conservation_1156  3
    service_1_6_5  unique_nonzero_owner_407  1
    service_1_6_5  service_visit_def_1155  1
    service_1_6_5  free_load_conservation_1156  4
    service_1_6_6  unique_nonzero_owner_408  1
    service_1_6_6  service_visit_def_1155  1
    service_1_6_6  free_load_conservation_1156  5
    service_1_6_7  unique_nonzero_owner_409  1
    service_1_6_7  service_visit_def_1155  1
    service_1_6_7  free_load_conservation_1156  6
    service_1_6_8  unique_nonzero_owner_410  1
    service_1_6_8  service_visit_def_1155  1
    service_1_6_8  free_load_conservation_1156  7
    service_1_6_9  unique_nonzero_owner_411  1
    service_1_6_9  service_visit_def_1155  1
    service_1_6_9  free_load_conservation_1156  8
    service_1_6_10  unique_nonzero_owner_412  1
    service_1_6_10  service_visit_def_1155  1
    service_1_6_10  free_load_conservation_1156  9
    service_2_6_0  unique_nonzero_owner_403  1
    service_2_6_0  service_visit_def_1473  1
    service_2_6_0  free_load_conservation_1474  -1
    service_2_6_0  original_T_including_depot_unload_1483  120
    service_2_6_2  unique_nonzero_owner_404  1
    service_2_6_2  service_visit_def_1473  1
    service_2_6_2  free_load_conservation_1474  1
    service_2_6_3  unique_nonzero_owner_405  1
    service_2_6_3  service_visit_def_1473  1
    service_2_6_3  free_load_conservation_1474  2
    service_2_6_4  unique_nonzero_owner_406  1
    service_2_6_4  service_visit_def_1473  1
    service_2_6_4  free_load_conservation_1474  3
    service_2_6_5  unique_nonzero_owner_407  1
    service_2_6_5  service_visit_def_1473  1
    service_2_6_5  free_load_conservation_1474  4
    service_2_6_6  unique_nonzero_owner_408  1
    service_2_6_6  service_visit_def_1473  1
    service_2_6_6  free_load_conservation_1474  5
    service_2_6_7  unique_nonzero_owner_409  1
    service_2_6_7  service_visit_def_1473  1
    service_2_6_7  free_load_conservation_1474  6
    service_2_6_8  unique_nonzero_owner_410  1
    service_2_6_8  service_visit_def_1473  1
    service_2_6_8  free_load_conservation_1474  7
    service_2_6_9  unique_nonzero_owner_411  1
    service_2_6_9  service_visit_def_1473  1
    service_2_6_9  free_load_conservation_1474  8
    service_2_6_10  unique_nonzero_owner_412  1
    service_2_6_10  service_visit_def_1473  1
    service_2_6_10  free_load_conservation_1474  9
    service_0_9_0  unique_nonzero_owner_413  1
    service_0_9_0  service_visit_def_790  1
    service_0_9_0  free_load_conservation_791  -8
    service_0_9_0  original_T_including_depot_unload_795  960
    service_0_9_1  unique_nonzero_owner_414  1
    service_0_9_1  service_visit_def_790  1
    service_0_9_1  free_load_conservation_791  -7
    service_0_9_1  original_T_including_depot_unload_795  840
    service_0_9_2  unique_nonzero_owner_415  1
    service_0_9_2  service_visit_def_790  1
    service_0_9_2  free_load_conservation_791  -6
    service_0_9_2  original_T_including_depot_unload_795  720
    service_0_9_3  unique_nonzero_owner_416  1
    service_0_9_3  service_visit_def_790  1
    service_0_9_3  free_load_conservation_791  -5
    service_0_9_3  original_T_including_depot_unload_795  600
    service_0_9_4  unique_nonzero_owner_417  1
    service_0_9_4  service_visit_def_790  1
    service_0_9_4  free_load_conservation_791  -4
    service_0_9_4  original_T_including_depot_unload_795  480
    service_0_9_5  unique_nonzero_owner_418  1
    service_0_9_5  service_visit_def_790  1
    service_0_9_5  free_load_conservation_791  -3
    service_0_9_5  original_T_including_depot_unload_795  360
    service_0_9_6  unique_nonzero_owner_419  1
    service_0_9_6  service_visit_def_790  1
    service_0_9_6  free_load_conservation_791  -2
    service_0_9_6  original_T_including_depot_unload_795  240
    service_0_9_7  unique_nonzero_owner_420  1
    service_0_9_7  service_visit_def_790  1
    service_0_9_7  free_load_conservation_791  -1
    service_0_9_7  original_T_including_depot_unload_795  120
    service_0_9_9  unique_nonzero_owner_421  1
    service_0_9_9  service_visit_def_790  1
    service_0_9_9  free_load_conservation_791  1
    service_0_9_10  unique_nonzero_owner_422  1
    service_0_9_10  service_visit_def_790  1
    service_0_9_10  free_load_conservation_791  2
    service_0_9_11  unique_nonzero_owner_423  1
    service_0_9_11  service_visit_def_790  1
    service_0_9_11  free_load_conservation_791  3
    service_0_9_12  unique_nonzero_owner_424  1
    service_0_9_12  service_visit_def_790  1
    service_0_9_12  free_load_conservation_791  4
    service_1_9_0  unique_nonzero_owner_413  1
    service_1_9_0  service_visit_def_1161  1
    service_1_9_0  free_load_conservation_1162  -8
    service_1_9_0  original_T_including_depot_unload_1166  960
    service_1_9_1  unique_nonzero_owner_414  1
    service_1_9_1  service_visit_def_1161  1
    service_1_9_1  free_load_conservation_1162  -7
    service_1_9_1  original_T_including_depot_unload_1166  840
    service_1_9_2  unique_nonzero_owner_415  1
    service_1_9_2  service_visit_def_1161  1
    service_1_9_2  free_load_conservation_1162  -6
    service_1_9_2  original_T_including_depot_unload_1166  720
    service_1_9_3  unique_nonzero_owner_416  1
    service_1_9_3  service_visit_def_1161  1
    service_1_9_3  free_load_conservation_1162  -5
    service_1_9_3  original_T_including_depot_unload_1166  600
    service_1_9_4  unique_nonzero_owner_417  1
    service_1_9_4  service_visit_def_1161  1
    service_1_9_4  free_load_conservation_1162  -4
    service_1_9_4  original_T_including_depot_unload_1166  480
    service_1_9_5  unique_nonzero_owner_418  1
    service_1_9_5  service_visit_def_1161  1
    service_1_9_5  free_load_conservation_1162  -3
    service_1_9_5  original_T_including_depot_unload_1166  360
    service_1_9_6  unique_nonzero_owner_419  1
    service_1_9_6  service_visit_def_1161  1
    service_1_9_6  free_load_conservation_1162  -2
    service_1_9_6  original_T_including_depot_unload_1166  240
    service_1_9_7  unique_nonzero_owner_420  1
    service_1_9_7  service_visit_def_1161  1
    service_1_9_7  free_load_conservation_1162  -1
    service_1_9_7  original_T_including_depot_unload_1166  120
    service_1_9_9  unique_nonzero_owner_421  1
    service_1_9_9  service_visit_def_1161  1
    service_1_9_9  free_load_conservation_1162  1
    service_1_9_10  unique_nonzero_owner_422  1
    service_1_9_10  service_visit_def_1161  1
    service_1_9_10  free_load_conservation_1162  2
    service_1_9_11  unique_nonzero_owner_423  1
    service_1_9_11  service_visit_def_1161  1
    service_1_9_11  free_load_conservation_1162  3
    service_1_9_12  unique_nonzero_owner_424  1
    service_1_9_12  service_visit_def_1161  1
    service_1_9_12  free_load_conservation_1162  4
    service_2_9_0  unique_nonzero_owner_413  1
    service_2_9_0  service_visit_def_1479  1
    service_2_9_0  free_load_conservation_1480  -8
    service_2_9_0  original_T_including_depot_unload_1483  960
    service_2_9_1  unique_nonzero_owner_414  1
    service_2_9_1  service_visit_def_1479  1
    service_2_9_1  free_load_conservation_1480  -7
    service_2_9_1  original_T_including_depot_unload_1483  840
    service_2_9_2  unique_nonzero_owner_415  1
    service_2_9_2  service_visit_def_1479  1
    service_2_9_2  free_load_conservation_1480  -6
    service_2_9_2  original_T_including_depot_unload_1483  720
    service_2_9_3  unique_nonzero_owner_416  1
    service_2_9_3  service_visit_def_1479  1
    service_2_9_3  free_load_conservation_1480  -5
    service_2_9_3  original_T_including_depot_unload_1483  600
    service_2_9_4  unique_nonzero_owner_417  1
    service_2_9_4  service_visit_def_1479  1
    service_2_9_4  free_load_conservation_1480  -4
    service_2_9_4  original_T_including_depot_unload_1483  480
    service_2_9_5  unique_nonzero_owner_418  1
    service_2_9_5  service_visit_def_1479  1
    service_2_9_5  free_load_conservation_1480  -3
    service_2_9_5  original_T_including_depot_unload_1483  360
    service_2_9_6  unique_nonzero_owner_419  1
    service_2_9_6  service_visit_def_1479  1
    service_2_9_6  free_load_conservation_1480  -2
    service_2_9_6  original_T_including_depot_unload_1483  240
    service_2_9_7  unique_nonzero_owner_420  1
    service_2_9_7  service_visit_def_1479  1
    service_2_9_7  free_load_conservation_1480  -1
    service_2_9_7  original_T_including_depot_unload_1483  120
    service_2_9_9  unique_nonzero_owner_421  1
    service_2_9_9  service_visit_def_1479  1
    service_2_9_9  free_load_conservation_1480  1
    service_2_9_10  unique_nonzero_owner_422  1
    service_2_9_10  service_visit_def_1479  1
    service_2_9_10  free_load_conservation_1480  2
    service_2_9_11  unique_nonzero_owner_423  1
    service_2_9_11  service_visit_def_1479  1
    service_2_9_11  free_load_conservation_1480  3
    service_2_9_12  unique_nonzero_owner_424  1
    service_2_9_12  service_visit_def_1479  1
    service_2_9_12  free_load_conservation_1480  4
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_716  -1
    visit_0_1  in_degree_717  -1
    visit_0_1  order_active_lb_718  -1
    visit_0_1  order_active_ub_719  -12
    order_0_1  connected_order_arc_440  -1
    order_0_1  connected_order_arc_442  -1
    order_0_1  connected_order_arc_444  -1
    order_0_1  connected_order_arc_446  -1
    order_0_1  connected_order_arc_448  -1
    order_0_1  connected_order_arc_450  -1
    order_0_1  connected_order_arc_452  -1
    order_0_1  connected_order_arc_454  -1
    order_0_1  connected_order_arc_456  -1
    order_0_1  connected_order_arc_458  -1
    order_0_1  connected_order_arc_460  -1
    order_0_1  connected_order_arc_463  1
    order_0_1  connected_order_arc_486  1
    order_0_1  connected_order_arc_509  1
    order_0_1  connected_order_arc_532  1
    order_0_1  connected_order_arc_555  1
    order_0_1  connected_order_arc_578  1
    order_0_1  connected_order_arc_601  1
    order_0_1  connected_order_arc_624  1
    order_0_1  connected_order_arc_647  1
    order_0_1  connected_order_arc_670  1
    order_0_1  connected_order_arc_693  1
    order_0_1  order_active_lb_718  1
    order_0_1  order_active_ub_719  1
    order_0_1  fixed_segment_relative_order_792  -1
    visit_0_2  out_degree_723  -1
    visit_0_2  in_degree_724  -1
    visit_0_2  order_active_lb_725  -1
    visit_0_2  order_active_ub_726  -12
    order_0_2  connected_order_arc_440  1
    order_0_2  connected_order_arc_463  -1
    order_0_2  connected_order_arc_465  -1
    order_0_2  connected_order_arc_467  -1
    order_0_2  connected_order_arc_469  -1
    order_0_2  connected_order_arc_471  -1
    order_0_2  connected_order_arc_473  -1
    order_0_2  connected_order_arc_475  -1
    order_0_2  connected_order_arc_477  -1
    order_0_2  connected_order_arc_479  -1
    order_0_2  connected_order_arc_481  -1
    order_0_2  connected_order_arc_483  -1
    order_0_2  connected_order_arc_488  1
    order_0_2  connected_order_arc_511  1
    order_0_2  connected_order_arc_534  1
    order_0_2  connected_order_arc_557  1
    order_0_2  connected_order_arc_580  1
    order_0_2  connected_order_arc_603  1
    order_0_2  connected_order_arc_626  1
    order_0_2  connected_order_arc_649  1
    order_0_2  connected_order_arc_672  1
    order_0_2  connected_order_arc_695  1
    order_0_2  order_active_lb_725  1
    order_0_2  order_active_ub_726  1
    order_0_2  fixed_segment_relative_order_792  1
    order_0_2  fixed_segment_relative_order_793  -1
    visit_0_3  out_degree_730  -1
    visit_0_3  in_degree_731  -1
    visit_0_3  order_active_lb_732  -1
    visit_0_3  order_active_ub_733  -12
    order_0_3  connected_order_arc_442  1
    order_0_3  connected_order_arc_465  1
    order_0_3  connected_order_arc_486  -1
    order_0_3  connected_order_arc_488  -1
    order_0_3  connected_order_arc_490  -1
    order_0_3  connected_order_arc_492  -1
    order_0_3  connected_order_arc_494  -1
    order_0_3  connected_order_arc_496  -1
    order_0_3  connected_order_arc_498  -1
    order_0_3  connected_order_arc_500  -1
    order_0_3  connected_order_arc_502  -1
    order_0_3  connected_order_arc_504  -1
    order_0_3  connected_order_arc_506  -1
    order_0_3  connected_order_arc_513  1
    order_0_3  connected_order_arc_536  1
    order_0_3  connected_order_arc_559  1
    order_0_3  connected_order_arc_582  1
    order_0_3  connected_order_arc_605  1
    order_0_3  connected_order_arc_628  1
    order_0_3  connected_order_arc_651  1
    order_0_3  connected_order_arc_674  1
    order_0_3  connected_order_arc_697  1
    order_0_3  order_active_lb_732  1
    order_0_3  order_active_ub_733  1
    order_0_3  fixed_segment_relative_order_793  1
    order_0_3  fixed_segment_relative_order_794  -1
    visit_0_4  out_degree_737  -1
    visit_0_4  in_degree_738  -1
    visit_0_4  order_active_lb_739  -1
    visit_0_4  order_active_ub_740  -12
    order_0_4  connected_order_arc_444  1
    order_0_4  connected_order_arc_467  1
    order_0_4  connected_order_arc_490  1
    order_0_4  connected_order_arc_509  -1
    order_0_4  connected_order_arc_511  -1
    order_0_4  connected_order_arc_513  -1
    order_0_4  connected_order_arc_515  -1
    order_0_4  connected_order_arc_517  -1
    order_0_4  connected_order_arc_519  -1
    order_0_4  connected_order_arc_521  -1
    order_0_4  connected_order_arc_523  -1
    order_0_4  connected_order_arc_525  -1
    order_0_4  connected_order_arc_527  -1
    order_0_4  connected_order_arc_529  -1
    order_0_4  connected_order_arc_538  1
    order_0_4  connected_order_arc_561  1
    order_0_4  connected_order_arc_584  1
    order_0_4  connected_order_arc_607  1
    order_0_4  connected_order_arc_630  1
    order_0_4  connected_order_arc_653  1
    order_0_4  connected_order_arc_676  1
    order_0_4  connected_order_arc_699  1
    order_0_4  order_active_lb_739  1
    order_0_4  order_active_ub_740  1
    order_0_4  fixed_segment_relative_order_794  1
    visit_0_12  out_degree_744  -1
    visit_0_12  in_degree_745  -1
    visit_0_12  order_active_lb_746  -1
    visit_0_12  order_active_ub_747  -12
    visit_0_12  service_visit_def_748  -1
    order_0_12  connected_order_arc_446  1
    order_0_12  connected_order_arc_469  1
    order_0_12  connected_order_arc_492  1
    order_0_12  connected_order_arc_515  1
    order_0_12  connected_order_arc_532  -1
    order_0_12  connected_order_arc_534  -1
    order_0_12  connected_order_arc_536  -1
    order_0_12  connected_order_arc_538  -1
    order_0_12  connected_order_arc_540  -1
    order_0_12  connected_order_arc_542  -1
    order_0_12  connected_order_arc_544  -1
    order_0_12  connected_order_arc_546  -1
    order_0_12  connected_order_arc_548  -1
    order_0_12  connected_order_arc_550  -1
    order_0_12  connected_order_arc_552  -1
    order_0_12  connected_order_arc_563  1
    order_0_12  connected_order_arc_586  1
    order_0_12  connected_order_arc_609  1
    order_0_12  connected_order_arc_632  1
    order_0_12  connected_order_arc_655  1
    order_0_12  connected_order_arc_678  1
    order_0_12  connected_order_arc_701  1
    order_0_12  order_active_lb_746  1
    order_0_12  order_active_ub_747  1
    visit_0_13  out_degree_750  -1
    visit_0_13  in_degree_751  -1
    visit_0_13  order_active_lb_752  -1
    visit_0_13  order_active_ub_753  -12
    visit_0_13  service_visit_def_754  -1
    order_0_13  connected_order_arc_448  1
    order_0_13  connected_order_arc_471  1
    order_0_13  connected_order_arc_494  1
    order_0_13  connected_order_arc_517  1
    order_0_13  connected_order_arc_540  1
    order_0_13  connected_order_arc_555  -1
    order_0_13  connected_order_arc_557  -1
    order_0_13  connected_order_arc_559  -1
    order_0_13  connected_order_arc_561  -1
    order_0_13  connected_order_arc_563  -1
    order_0_13  connected_order_arc_565  -1
    order_0_13  connected_order_arc_567  -1
    order_0_13  connected_order_arc_569  -1
    order_0_13  connected_order_arc_571  -1
    order_0_13  connected_order_arc_573  -1
    order_0_13  connected_order_arc_575  -1
    order_0_13  connected_order_arc_588  1
    order_0_13  connected_order_arc_611  1
    order_0_13  connected_order_arc_634  1
    order_0_13  connected_order_arc_657  1
    order_0_13  connected_order_arc_680  1
    order_0_13  connected_order_arc_703  1
    order_0_13  order_active_lb_752  1
    order_0_13  order_active_ub_753  1
    visit_0_14  out_degree_756  -1
    visit_0_14  in_degree_757  -1
    visit_0_14  order_active_lb_758  -1
    visit_0_14  order_active_ub_759  -12
    visit_0_14  service_visit_def_760  -1
    order_0_14  connected_order_arc_450  1
    order_0_14  connected_order_arc_473  1
    order_0_14  connected_order_arc_496  1
    order_0_14  connected_order_arc_519  1
    order_0_14  connected_order_arc_542  1
    order_0_14  connected_order_arc_565  1
    order_0_14  connected_order_arc_578  -1
    order_0_14  connected_order_arc_580  -1
    order_0_14  connected_order_arc_582  -1
    order_0_14  connected_order_arc_584  -1
    order_0_14  connected_order_arc_586  -1
    order_0_14  connected_order_arc_588  -1
    order_0_14  connected_order_arc_590  -1
    order_0_14  connected_order_arc_592  -1
    order_0_14  connected_order_arc_594  -1
    order_0_14  connected_order_arc_596  -1
    order_0_14  connected_order_arc_598  -1
    order_0_14  connected_order_arc_613  1
    order_0_14  connected_order_arc_636  1
    order_0_14  connected_order_arc_659  1
    order_0_14  connected_order_arc_682  1
    order_0_14  connected_order_arc_705  1
    order_0_14  order_active_lb_758  1
    order_0_14  order_active_ub_759  1
    visit_0_15  out_degree_762  -1
    visit_0_15  in_degree_763  -1
    visit_0_15  order_active_lb_764  -1
    visit_0_15  order_active_ub_765  -12
    visit_0_15  service_visit_def_766  -1
    order_0_15  connected_order_arc_452  1
    order_0_15  connected_order_arc_475  1
    order_0_15  connected_order_arc_498  1
    order_0_15  connected_order_arc_521  1
    order_0_15  connected_order_arc_544  1
    order_0_15  connected_order_arc_567  1
    order_0_15  connected_order_arc_590  1
    order_0_15  connected_order_arc_601  -1
    order_0_15  connected_order_arc_603  -1
    order_0_15  connected_order_arc_605  -1
    order_0_15  connected_order_arc_607  -1
    order_0_15  connected_order_arc_609  -1
    order_0_15  connected_order_arc_611  -1
    order_0_15  connected_order_arc_613  -1
    order_0_15  connected_order_arc_615  -1
    order_0_15  connected_order_arc_617  -1
    order_0_15  connected_order_arc_619  -1
    order_0_15  connected_order_arc_621  -1
    order_0_15  connected_order_arc_638  1
    order_0_15  connected_order_arc_661  1
    order_0_15  connected_order_arc_684  1
    order_0_15  connected_order_arc_707  1
    order_0_15  order_active_lb_764  1
    order_0_15  order_active_ub_765  1
    visit_0_16  out_degree_768  -1
    visit_0_16  in_degree_769  -1
    visit_0_16  order_active_lb_770  -1
    visit_0_16  order_active_ub_771  -12
    visit_0_16  service_visit_def_772  -1
    order_0_16  connected_order_arc_454  1
    order_0_16  connected_order_arc_477  1
    order_0_16  connected_order_arc_500  1
    order_0_16  connected_order_arc_523  1
    order_0_16  connected_order_arc_546  1
    order_0_16  connected_order_arc_569  1
    order_0_16  connected_order_arc_592  1
    order_0_16  connected_order_arc_615  1
    order_0_16  connected_order_arc_624  -1
    order_0_16  connected_order_arc_626  -1
    order_0_16  connected_order_arc_628  -1
    order_0_16  connected_order_arc_630  -1
    order_0_16  connected_order_arc_632  -1
    order_0_16  connected_order_arc_634  -1
    order_0_16  connected_order_arc_636  -1
    order_0_16  connected_order_arc_638  -1
    order_0_16  connected_order_arc_640  -1
    order_0_16  connected_order_arc_642  -1
    order_0_16  connected_order_arc_644  -1
    order_0_16  connected_order_arc_663  1
    order_0_16  connected_order_arc_686  1
    order_0_16  connected_order_arc_709  1
    order_0_16  order_active_lb_770  1
    order_0_16  order_active_ub_771  1
    visit_0_17  out_degree_774  -1
    visit_0_17  in_degree_775  -1
    visit_0_17  order_active_lb_776  -1
    visit_0_17  order_active_ub_777  -12
    visit_0_17  service_visit_def_778  -1
    order_0_17  connected_order_arc_456  1
    order_0_17  connected_order_arc_479  1
    order_0_17  connected_order_arc_502  1
    order_0_17  connected_order_arc_525  1
    order_0_17  connected_order_arc_548  1
    order_0_17  connected_order_arc_571  1
    order_0_17  connected_order_arc_594  1
    order_0_17  connected_order_arc_617  1
    order_0_17  connected_order_arc_640  1
    order_0_17  connected_order_arc_647  -1
    order_0_17  connected_order_arc_649  -1
    order_0_17  connected_order_arc_651  -1
    order_0_17  connected_order_arc_653  -1
    order_0_17  connected_order_arc_655  -1
    order_0_17  connected_order_arc_657  -1
    order_0_17  connected_order_arc_659  -1
    order_0_17  connected_order_arc_661  -1
    order_0_17  connected_order_arc_663  -1
    order_0_17  connected_order_arc_665  -1
    order_0_17  connected_order_arc_667  -1
    order_0_17  connected_order_arc_688  1
    order_0_17  connected_order_arc_711  1
    order_0_17  order_active_lb_776  1
    order_0_17  order_active_ub_777  1
    visit_0_18  out_degree_780  -1
    visit_0_18  in_degree_781  -1
    visit_0_18  order_active_lb_782  -1
    visit_0_18  order_active_ub_783  -12
    visit_0_18  service_visit_def_784  -1
    order_0_18  connected_order_arc_458  1
    order_0_18  connected_order_arc_481  1
    order_0_18  connected_order_arc_504  1
    order_0_18  connected_order_arc_527  1
    order_0_18  connected_order_arc_550  1
    order_0_18  connected_order_arc_573  1
    order_0_18  connected_order_arc_596  1
    order_0_18  connected_order_arc_619  1
    order_0_18  connected_order_arc_642  1
    order_0_18  connected_order_arc_665  1
    order_0_18  connected_order_arc_670  -1
    order_0_18  connected_order_arc_672  -1
    order_0_18  connected_order_arc_674  -1
    order_0_18  connected_order_arc_676  -1
    order_0_18  connected_order_arc_678  -1
    order_0_18  connected_order_arc_680  -1
    order_0_18  connected_order_arc_682  -1
    order_0_18  connected_order_arc_684  -1
    order_0_18  connected_order_arc_686  -1
    order_0_18  connected_order_arc_688  -1
    order_0_18  connected_order_arc_690  -1
    order_0_18  connected_order_arc_713  1
    order_0_18  order_active_lb_782  1
    order_0_18  order_active_ub_783  1
    visit_0_19  out_degree_786  -1
    visit_0_19  in_degree_787  -1
    visit_0_19  order_active_lb_788  -1
    visit_0_19  order_active_ub_789  -12
    visit_0_19  service_visit_def_790  -1
    order_0_19  connected_order_arc_460  1
    order_0_19  connected_order_arc_483  1
    order_0_19  connected_order_arc_506  1
    order_0_19  connected_order_arc_529  1
    order_0_19  connected_order_arc_552  1
    order_0_19  connected_order_arc_575  1
    order_0_19  connected_order_arc_598  1
    order_0_19  connected_order_arc_621  1
    order_0_19  connected_order_arc_644  1
    order_0_19  connected_order_arc_667  1
    order_0_19  connected_order_arc_690  1
    order_0_19  connected_order_arc_693  -1
    order_0_19  connected_order_arc_695  -1
    order_0_19  connected_order_arc_697  -1
    order_0_19  connected_order_arc_699  -1
    order_0_19  connected_order_arc_701  -1
    order_0_19  connected_order_arc_703  -1
    order_0_19  connected_order_arc_705  -1
    order_0_19  connected_order_arc_707  -1
    order_0_19  connected_order_arc_709  -1
    order_0_19  connected_order_arc_711  -1
    order_0_19  connected_order_arc_713  -1
    order_0_19  order_active_lb_788  1
    order_0_19  order_active_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_425  -20
    arc_0_0_0  depot_departure_or_bypass_714  1
    arc_0_0_0  depot_return_or_bypass_715  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_425  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_426  -20
    arc_0_0_1  depot_departure_or_bypass_714  1
    arc_0_0_1  in_degree_717  1
    arc_0_0_1  original_T_including_depot_unload_795  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_426  1
    load_0_0_1  segment_load_conservation_720  -1
    load_0_0_1  segment_prefix_lb_721  1
    load_0_0_1  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_427  -20
    arc_0_0_2  depot_departure_or_bypass_714  1
    arc_0_0_2  in_degree_724  1
    arc_0_0_2  original_T_including_depot_unload_795  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_427  1
    load_0_0_2  segment_load_conservation_727  -1
    load_0_0_2  segment_prefix_lb_728  1
    load_0_0_2  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_428  -20
    arc_0_0_3  depot_departure_or_bypass_714  1
    arc_0_0_3  in_degree_731  1
    arc_0_0_3  original_T_including_depot_unload_795  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_428  1
    load_0_0_3  segment_load_conservation_734  -1
    load_0_0_3  segment_prefix_lb_735  1
    load_0_0_3  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_429  -20
    arc_0_0_4  depot_departure_or_bypass_714  1
    arc_0_0_4  in_degree_738  1
    arc_0_0_4  original_T_including_depot_unload_795  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_429  1
    load_0_0_4  segment_load_conservation_741  -1
    load_0_0_4  segment_prefix_lb_742  1
    load_0_0_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_430  -20
    arc_0_0_12  depot_departure_or_bypass_714  1
    arc_0_0_12  in_degree_745  1
    arc_0_0_12  original_T_including_depot_unload_795  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_430  1
    load_0_0_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_431  -20
    arc_0_0_13  depot_departure_or_bypass_714  1
    arc_0_0_13  in_degree_751  1
    arc_0_0_13  original_T_including_depot_unload_795  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_431  1
    load_0_0_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_432  -20
    arc_0_0_14  depot_departure_or_bypass_714  1
    arc_0_0_14  in_degree_757  1
    arc_0_0_14  original_T_including_depot_unload_795  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_432  1
    load_0_0_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_433  -20
    arc_0_0_15  depot_departure_or_bypass_714  1
    arc_0_0_15  in_degree_763  1
    arc_0_0_15  original_T_including_depot_unload_795  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_433  1
    load_0_0_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_434  -20
    arc_0_0_16  depot_departure_or_bypass_714  1
    arc_0_0_16  in_degree_769  1
    arc_0_0_16  original_T_including_depot_unload_795  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_434  1
    load_0_0_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_435  -20
    arc_0_0_17  depot_departure_or_bypass_714  1
    arc_0_0_17  in_degree_775  1
    arc_0_0_17  original_T_including_depot_unload_795  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_435  1
    load_0_0_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_436  -20
    arc_0_0_18  depot_departure_or_bypass_714  1
    arc_0_0_18  in_degree_781  1
    arc_0_0_18  original_T_including_depot_unload_795  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_436  1
    load_0_0_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_437  -20
    arc_0_0_19  depot_departure_or_bypass_714  1
    arc_0_0_19  in_degree_787  1
    arc_0_0_19  original_T_including_depot_unload_795  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_437  1
    load_0_0_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_438  -20
    arc_0_1_0  depot_return_or_bypass_715  1
    arc_0_1_0  out_degree_716  1
    arc_0_1_0  original_T_including_depot_unload_795  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_438  1
    load_0_1_0  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_439  -20
    arc_0_1_2  connected_order_arc_440  -13
    arc_0_1_2  out_degree_716  1
    arc_0_1_2  in_degree_724  1
    arc_0_1_2  original_T_including_depot_unload_795  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_439  1
    load_0_1_2  segment_load_conservation_720  1
    load_0_1_2  segment_load_conservation_727  -1
    load_0_1_2  segment_prefix_lb_728  1
    load_0_1_2  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_441  -20
    arc_0_1_3  connected_order_arc_442  -13
    arc_0_1_3  out_degree_716  1
    arc_0_1_3  in_degree_731  1
    arc_0_1_3  original_T_including_depot_unload_795  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_441  1
    load_0_1_3  segment_load_conservation_720  1
    load_0_1_3  segment_load_conservation_734  -1
    load_0_1_3  segment_prefix_lb_735  1
    load_0_1_3  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_443  -20
    arc_0_1_4  connected_order_arc_444  -13
    arc_0_1_4  out_degree_716  1
    arc_0_1_4  in_degree_738  1
    arc_0_1_4  original_T_including_depot_unload_795  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_443  1
    load_0_1_4  segment_load_conservation_720  1
    load_0_1_4  segment_load_conservation_741  -1
    load_0_1_4  segment_prefix_lb_742  1
    load_0_1_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_445  -20
    arc_0_1_12  connected_order_arc_446  -13
    arc_0_1_12  out_degree_716  1
    arc_0_1_12  in_degree_745  1
    arc_0_1_12  original_T_including_depot_unload_795  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_445  1
    load_0_1_12  segment_load_conservation_720  1
    load_0_1_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_447  -20
    arc_0_1_13  connected_order_arc_448  -13
    arc_0_1_13  out_degree_716  1
    arc_0_1_13  in_degree_751  1
    arc_0_1_13  original_T_including_depot_unload_795  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_447  1
    load_0_1_13  segment_load_conservation_720  1
    load_0_1_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_449  -20
    arc_0_1_14  connected_order_arc_450  -13
    arc_0_1_14  out_degree_716  1
    arc_0_1_14  in_degree_757  1
    arc_0_1_14  original_T_including_depot_unload_795  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_449  1
    load_0_1_14  segment_load_conservation_720  1
    load_0_1_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_451  -20
    arc_0_1_15  connected_order_arc_452  -13
    arc_0_1_15  out_degree_716  1
    arc_0_1_15  in_degree_763  1
    arc_0_1_15  original_T_including_depot_unload_795  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_451  1
    load_0_1_15  segment_load_conservation_720  1
    load_0_1_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_453  -20
    arc_0_1_16  connected_order_arc_454  -13
    arc_0_1_16  out_degree_716  1
    arc_0_1_16  in_degree_769  1
    arc_0_1_16  original_T_including_depot_unload_795  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_453  1
    load_0_1_16  segment_load_conservation_720  1
    load_0_1_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_455  -20
    arc_0_1_17  connected_order_arc_456  -13
    arc_0_1_17  out_degree_716  1
    arc_0_1_17  in_degree_775  1
    arc_0_1_17  original_T_including_depot_unload_795  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_455  1
    load_0_1_17  segment_load_conservation_720  1
    load_0_1_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_457  -20
    arc_0_1_18  connected_order_arc_458  -13
    arc_0_1_18  out_degree_716  1
    arc_0_1_18  in_degree_781  1
    arc_0_1_18  original_T_including_depot_unload_795  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_457  1
    load_0_1_18  segment_load_conservation_720  1
    load_0_1_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_459  -20
    arc_0_1_19  connected_order_arc_460  -13
    arc_0_1_19  out_degree_716  1
    arc_0_1_19  in_degree_787  1
    arc_0_1_19  original_T_including_depot_unload_795  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_459  1
    load_0_1_19  segment_load_conservation_720  1
    load_0_1_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_461  -20
    arc_0_2_0  depot_return_or_bypass_715  1
    arc_0_2_0  out_degree_723  1
    arc_0_2_0  original_T_including_depot_unload_795  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_461  1
    load_0_2_0  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_462  -20
    arc_0_2_1  connected_order_arc_463  -13
    arc_0_2_1  in_degree_717  1
    arc_0_2_1  out_degree_723  1
    arc_0_2_1  original_T_including_depot_unload_795  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_462  1
    load_0_2_1  segment_load_conservation_720  -1
    load_0_2_1  segment_prefix_lb_721  1
    load_0_2_1  segment_prefix_ub_722  1
    load_0_2_1  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_464  -20
    arc_0_2_3  connected_order_arc_465  -13
    arc_0_2_3  out_degree_723  1
    arc_0_2_3  in_degree_731  1
    arc_0_2_3  original_T_including_depot_unload_795  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_464  1
    load_0_2_3  segment_load_conservation_727  1
    load_0_2_3  segment_load_conservation_734  -1
    load_0_2_3  segment_prefix_lb_735  1
    load_0_2_3  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_466  -20
    arc_0_2_4  connected_order_arc_467  -13
    arc_0_2_4  out_degree_723  1
    arc_0_2_4  in_degree_738  1
    arc_0_2_4  original_T_including_depot_unload_795  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_466  1
    load_0_2_4  segment_load_conservation_727  1
    load_0_2_4  segment_load_conservation_741  -1
    load_0_2_4  segment_prefix_lb_742  1
    load_0_2_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_468  -20
    arc_0_2_12  connected_order_arc_469  -13
    arc_0_2_12  out_degree_723  1
    arc_0_2_12  in_degree_745  1
    arc_0_2_12  original_T_including_depot_unload_795  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_468  1
    load_0_2_12  segment_load_conservation_727  1
    load_0_2_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_470  -20
    arc_0_2_13  connected_order_arc_471  -13
    arc_0_2_13  out_degree_723  1
    arc_0_2_13  in_degree_751  1
    arc_0_2_13  original_T_including_depot_unload_795  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_470  1
    load_0_2_13  segment_load_conservation_727  1
    load_0_2_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_472  -20
    arc_0_2_14  connected_order_arc_473  -13
    arc_0_2_14  out_degree_723  1
    arc_0_2_14  in_degree_757  1
    arc_0_2_14  original_T_including_depot_unload_795  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_472  1
    load_0_2_14  segment_load_conservation_727  1
    load_0_2_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_474  -20
    arc_0_2_15  connected_order_arc_475  -13
    arc_0_2_15  out_degree_723  1
    arc_0_2_15  in_degree_763  1
    arc_0_2_15  original_T_including_depot_unload_795  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_474  1
    load_0_2_15  segment_load_conservation_727  1
    load_0_2_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_476  -20
    arc_0_2_16  connected_order_arc_477  -13
    arc_0_2_16  out_degree_723  1
    arc_0_2_16  in_degree_769  1
    arc_0_2_16  original_T_including_depot_unload_795  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_476  1
    load_0_2_16  segment_load_conservation_727  1
    load_0_2_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_478  -20
    arc_0_2_17  connected_order_arc_479  -13
    arc_0_2_17  out_degree_723  1
    arc_0_2_17  in_degree_775  1
    arc_0_2_17  original_T_including_depot_unload_795  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_478  1
    load_0_2_17  segment_load_conservation_727  1
    load_0_2_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_480  -20
    arc_0_2_18  connected_order_arc_481  -13
    arc_0_2_18  out_degree_723  1
    arc_0_2_18  in_degree_781  1
    arc_0_2_18  original_T_including_depot_unload_795  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_480  1
    load_0_2_18  segment_load_conservation_727  1
    load_0_2_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_482  -20
    arc_0_2_19  connected_order_arc_483  -13
    arc_0_2_19  out_degree_723  1
    arc_0_2_19  in_degree_787  1
    arc_0_2_19  original_T_including_depot_unload_795  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_482  1
    load_0_2_19  segment_load_conservation_727  1
    load_0_2_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_484  -20
    arc_0_3_0  depot_return_or_bypass_715  1
    arc_0_3_0  out_degree_730  1
    arc_0_3_0  original_T_including_depot_unload_795  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_484  1
    load_0_3_0  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_485  -20
    arc_0_3_1  connected_order_arc_486  -13
    arc_0_3_1  in_degree_717  1
    arc_0_3_1  out_degree_730  1
    arc_0_3_1  original_T_including_depot_unload_795  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_485  1
    load_0_3_1  segment_load_conservation_720  -1
    load_0_3_1  segment_prefix_lb_721  1
    load_0_3_1  segment_prefix_ub_722  1
    load_0_3_1  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_487  -20
    arc_0_3_2  connected_order_arc_488  -13
    arc_0_3_2  in_degree_724  1
    arc_0_3_2  out_degree_730  1
    arc_0_3_2  original_T_including_depot_unload_795  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_487  1
    load_0_3_2  segment_load_conservation_727  -1
    load_0_3_2  segment_prefix_lb_728  1
    load_0_3_2  segment_prefix_ub_729  1
    load_0_3_2  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_489  -20
    arc_0_3_4  connected_order_arc_490  -13
    arc_0_3_4  out_degree_730  1
    arc_0_3_4  in_degree_738  1
    arc_0_3_4  original_T_including_depot_unload_795  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_489  1
    load_0_3_4  segment_load_conservation_734  1
    load_0_3_4  segment_load_conservation_741  -1
    load_0_3_4  segment_prefix_lb_742  1
    load_0_3_4  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_491  -20
    arc_0_3_12  connected_order_arc_492  -13
    arc_0_3_12  out_degree_730  1
    arc_0_3_12  in_degree_745  1
    arc_0_3_12  original_T_including_depot_unload_795  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_491  1
    load_0_3_12  segment_load_conservation_734  1
    load_0_3_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_493  -20
    arc_0_3_13  connected_order_arc_494  -13
    arc_0_3_13  out_degree_730  1
    arc_0_3_13  in_degree_751  1
    arc_0_3_13  original_T_including_depot_unload_795  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_493  1
    load_0_3_13  segment_load_conservation_734  1
    load_0_3_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_495  -20
    arc_0_3_14  connected_order_arc_496  -13
    arc_0_3_14  out_degree_730  1
    arc_0_3_14  in_degree_757  1
    arc_0_3_14  original_T_including_depot_unload_795  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_495  1
    load_0_3_14  segment_load_conservation_734  1
    load_0_3_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_497  -20
    arc_0_3_15  connected_order_arc_498  -13
    arc_0_3_15  out_degree_730  1
    arc_0_3_15  in_degree_763  1
    arc_0_3_15  original_T_including_depot_unload_795  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_497  1
    load_0_3_15  segment_load_conservation_734  1
    load_0_3_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_499  -20
    arc_0_3_16  connected_order_arc_500  -13
    arc_0_3_16  out_degree_730  1
    arc_0_3_16  in_degree_769  1
    arc_0_3_16  original_T_including_depot_unload_795  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_499  1
    load_0_3_16  segment_load_conservation_734  1
    load_0_3_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_501  -20
    arc_0_3_17  connected_order_arc_502  -13
    arc_0_3_17  out_degree_730  1
    arc_0_3_17  in_degree_775  1
    arc_0_3_17  original_T_including_depot_unload_795  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_501  1
    load_0_3_17  segment_load_conservation_734  1
    load_0_3_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_503  -20
    arc_0_3_18  connected_order_arc_504  -13
    arc_0_3_18  out_degree_730  1
    arc_0_3_18  in_degree_781  1
    arc_0_3_18  original_T_including_depot_unload_795  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_503  1
    load_0_3_18  segment_load_conservation_734  1
    load_0_3_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_505  -20
    arc_0_3_19  connected_order_arc_506  -13
    arc_0_3_19  out_degree_730  1
    arc_0_3_19  in_degree_787  1
    arc_0_3_19  original_T_including_depot_unload_795  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_505  1
    load_0_3_19  segment_load_conservation_734  1
    load_0_3_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_507  -20
    arc_0_4_0  depot_return_or_bypass_715  1
    arc_0_4_0  out_degree_737  1
    arc_0_4_0  original_T_including_depot_unload_795  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_507  1
    load_0_4_0  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_508  -20
    arc_0_4_1  connected_order_arc_509  -13
    arc_0_4_1  in_degree_717  1
    arc_0_4_1  out_degree_737  1
    arc_0_4_1  original_T_including_depot_unload_795  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_508  1
    load_0_4_1  segment_load_conservation_720  -1
    load_0_4_1  segment_prefix_lb_721  1
    load_0_4_1  segment_prefix_ub_722  1
    load_0_4_1  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_510  -20
    arc_0_4_2  connected_order_arc_511  -13
    arc_0_4_2  in_degree_724  1
    arc_0_4_2  out_degree_737  1
    arc_0_4_2  original_T_including_depot_unload_795  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_510  1
    load_0_4_2  segment_load_conservation_727  -1
    load_0_4_2  segment_prefix_lb_728  1
    load_0_4_2  segment_prefix_ub_729  1
    load_0_4_2  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_512  -20
    arc_0_4_3  connected_order_arc_513  -13
    arc_0_4_3  in_degree_731  1
    arc_0_4_3  out_degree_737  1
    arc_0_4_3  original_T_including_depot_unload_795  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_512  1
    load_0_4_3  segment_load_conservation_734  -1
    load_0_4_3  segment_prefix_lb_735  1
    load_0_4_3  segment_prefix_ub_736  1
    load_0_4_3  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_514  -20
    arc_0_4_12  connected_order_arc_515  -13
    arc_0_4_12  out_degree_737  1
    arc_0_4_12  in_degree_745  1
    arc_0_4_12  original_T_including_depot_unload_795  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_514  1
    load_0_4_12  segment_load_conservation_741  1
    load_0_4_12  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_516  -20
    arc_0_4_13  connected_order_arc_517  -13
    arc_0_4_13  out_degree_737  1
    arc_0_4_13  in_degree_751  1
    arc_0_4_13  original_T_including_depot_unload_795  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_516  1
    load_0_4_13  segment_load_conservation_741  1
    load_0_4_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_518  -20
    arc_0_4_14  connected_order_arc_519  -13
    arc_0_4_14  out_degree_737  1
    arc_0_4_14  in_degree_757  1
    arc_0_4_14  original_T_including_depot_unload_795  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_518  1
    load_0_4_14  segment_load_conservation_741  1
    load_0_4_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_520  -20
    arc_0_4_15  connected_order_arc_521  -13
    arc_0_4_15  out_degree_737  1
    arc_0_4_15  in_degree_763  1
    arc_0_4_15  original_T_including_depot_unload_795  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_520  1
    load_0_4_15  segment_load_conservation_741  1
    load_0_4_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_522  -20
    arc_0_4_16  connected_order_arc_523  -13
    arc_0_4_16  out_degree_737  1
    arc_0_4_16  in_degree_769  1
    arc_0_4_16  original_T_including_depot_unload_795  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_522  1
    load_0_4_16  segment_load_conservation_741  1
    load_0_4_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_524  -20
    arc_0_4_17  connected_order_arc_525  -13
    arc_0_4_17  out_degree_737  1
    arc_0_4_17  in_degree_775  1
    arc_0_4_17  original_T_including_depot_unload_795  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_524  1
    load_0_4_17  segment_load_conservation_741  1
    load_0_4_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_526  -20
    arc_0_4_18  connected_order_arc_527  -13
    arc_0_4_18  out_degree_737  1
    arc_0_4_18  in_degree_781  1
    arc_0_4_18  original_T_including_depot_unload_795  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_526  1
    load_0_4_18  segment_load_conservation_741  1
    load_0_4_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_528  -20
    arc_0_4_19  connected_order_arc_529  -13
    arc_0_4_19  out_degree_737  1
    arc_0_4_19  in_degree_787  1
    arc_0_4_19  original_T_including_depot_unload_795  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_528  1
    load_0_4_19  segment_load_conservation_741  1
    load_0_4_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_530  -20
    arc_0_12_0  depot_return_or_bypass_715  1
    arc_0_12_0  out_degree_744  1
    arc_0_12_0  original_T_including_depot_unload_795  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_530  1
    load_0_12_0  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_531  -20
    arc_0_12_1  connected_order_arc_532  -13
    arc_0_12_1  in_degree_717  1
    arc_0_12_1  out_degree_744  1
    arc_0_12_1  original_T_including_depot_unload_795  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_531  1
    load_0_12_1  segment_load_conservation_720  -1
    load_0_12_1  segment_prefix_lb_721  1
    load_0_12_1  segment_prefix_ub_722  1
    load_0_12_1  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_533  -20
    arc_0_12_2  connected_order_arc_534  -13
    arc_0_12_2  in_degree_724  1
    arc_0_12_2  out_degree_744  1
    arc_0_12_2  original_T_including_depot_unload_795  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_533  1
    load_0_12_2  segment_load_conservation_727  -1
    load_0_12_2  segment_prefix_lb_728  1
    load_0_12_2  segment_prefix_ub_729  1
    load_0_12_2  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_535  -20
    arc_0_12_3  connected_order_arc_536  -13
    arc_0_12_3  in_degree_731  1
    arc_0_12_3  out_degree_744  1
    arc_0_12_3  original_T_including_depot_unload_795  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_535  1
    load_0_12_3  segment_load_conservation_734  -1
    load_0_12_3  segment_prefix_lb_735  1
    load_0_12_3  segment_prefix_ub_736  1
    load_0_12_3  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_537  -20
    arc_0_12_4  connected_order_arc_538  -13
    arc_0_12_4  in_degree_738  1
    arc_0_12_4  out_degree_744  1
    arc_0_12_4  original_T_including_depot_unload_795  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_537  1
    load_0_12_4  segment_load_conservation_741  -1
    load_0_12_4  segment_prefix_lb_742  1
    load_0_12_4  segment_prefix_ub_743  1
    load_0_12_4  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_539  -20
    arc_0_12_13  connected_order_arc_540  -13
    arc_0_12_13  out_degree_744  1
    arc_0_12_13  in_degree_751  1
    arc_0_12_13  original_T_including_depot_unload_795  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_539  1
    load_0_12_13  free_load_conservation_749  1
    load_0_12_13  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_541  -20
    arc_0_12_14  connected_order_arc_542  -13
    arc_0_12_14  out_degree_744  1
    arc_0_12_14  in_degree_757  1
    arc_0_12_14  original_T_including_depot_unload_795  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_541  1
    load_0_12_14  free_load_conservation_749  1
    load_0_12_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_543  -20
    arc_0_12_15  connected_order_arc_544  -13
    arc_0_12_15  out_degree_744  1
    arc_0_12_15  in_degree_763  1
    arc_0_12_15  original_T_including_depot_unload_795  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_543  1
    load_0_12_15  free_load_conservation_749  1
    load_0_12_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_545  -20
    arc_0_12_16  connected_order_arc_546  -13
    arc_0_12_16  out_degree_744  1
    arc_0_12_16  in_degree_769  1
    arc_0_12_16  original_T_including_depot_unload_795  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_545  1
    load_0_12_16  free_load_conservation_749  1
    load_0_12_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_547  -20
    arc_0_12_17  connected_order_arc_548  -13
    arc_0_12_17  out_degree_744  1
    arc_0_12_17  in_degree_775  1
    arc_0_12_17  original_T_including_depot_unload_795  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_547  1
    load_0_12_17  free_load_conservation_749  1
    load_0_12_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_549  -20
    arc_0_12_18  connected_order_arc_550  -13
    arc_0_12_18  out_degree_744  1
    arc_0_12_18  in_degree_781  1
    arc_0_12_18  original_T_including_depot_unload_795  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_549  1
    load_0_12_18  free_load_conservation_749  1
    load_0_12_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_551  -20
    arc_0_12_19  connected_order_arc_552  -13
    arc_0_12_19  out_degree_744  1
    arc_0_12_19  in_degree_787  1
    arc_0_12_19  original_T_including_depot_unload_795  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_551  1
    load_0_12_19  free_load_conservation_749  1
    load_0_12_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_553  -20
    arc_0_13_0  depot_return_or_bypass_715  1
    arc_0_13_0  out_degree_750  1
    arc_0_13_0  original_T_including_depot_unload_795  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_553  1
    load_0_13_0  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_554  -20
    arc_0_13_1  connected_order_arc_555  -13
    arc_0_13_1  in_degree_717  1
    arc_0_13_1  out_degree_750  1
    arc_0_13_1  original_T_including_depot_unload_795  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_554  1
    load_0_13_1  segment_load_conservation_720  -1
    load_0_13_1  segment_prefix_lb_721  1
    load_0_13_1  segment_prefix_ub_722  1
    load_0_13_1  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_556  -20
    arc_0_13_2  connected_order_arc_557  -13
    arc_0_13_2  in_degree_724  1
    arc_0_13_2  out_degree_750  1
    arc_0_13_2  original_T_including_depot_unload_795  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_556  1
    load_0_13_2  segment_load_conservation_727  -1
    load_0_13_2  segment_prefix_lb_728  1
    load_0_13_2  segment_prefix_ub_729  1
    load_0_13_2  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_558  -20
    arc_0_13_3  connected_order_arc_559  -13
    arc_0_13_3  in_degree_731  1
    arc_0_13_3  out_degree_750  1
    arc_0_13_3  original_T_including_depot_unload_795  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_558  1
    load_0_13_3  segment_load_conservation_734  -1
    load_0_13_3  segment_prefix_lb_735  1
    load_0_13_3  segment_prefix_ub_736  1
    load_0_13_3  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_560  -20
    arc_0_13_4  connected_order_arc_561  -13
    arc_0_13_4  in_degree_738  1
    arc_0_13_4  out_degree_750  1
    arc_0_13_4  original_T_including_depot_unload_795  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_560  1
    load_0_13_4  segment_load_conservation_741  -1
    load_0_13_4  segment_prefix_lb_742  1
    load_0_13_4  segment_prefix_ub_743  1
    load_0_13_4  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_562  -20
    arc_0_13_12  connected_order_arc_563  -13
    arc_0_13_12  in_degree_745  1
    arc_0_13_12  out_degree_750  1
    arc_0_13_12  original_T_including_depot_unload_795  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_562  1
    load_0_13_12  free_load_conservation_749  -1
    load_0_13_12  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_564  -20
    arc_0_13_14  connected_order_arc_565  -13
    arc_0_13_14  out_degree_750  1
    arc_0_13_14  in_degree_757  1
    arc_0_13_14  original_T_including_depot_unload_795  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_564  1
    load_0_13_14  free_load_conservation_755  1
    load_0_13_14  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_566  -20
    arc_0_13_15  connected_order_arc_567  -13
    arc_0_13_15  out_degree_750  1
    arc_0_13_15  in_degree_763  1
    arc_0_13_15  original_T_including_depot_unload_795  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_566  1
    load_0_13_15  free_load_conservation_755  1
    load_0_13_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_568  -20
    arc_0_13_16  connected_order_arc_569  -13
    arc_0_13_16  out_degree_750  1
    arc_0_13_16  in_degree_769  1
    arc_0_13_16  original_T_including_depot_unload_795  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_568  1
    load_0_13_16  free_load_conservation_755  1
    load_0_13_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_570  -20
    arc_0_13_17  connected_order_arc_571  -13
    arc_0_13_17  out_degree_750  1
    arc_0_13_17  in_degree_775  1
    arc_0_13_17  original_T_including_depot_unload_795  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_570  1
    load_0_13_17  free_load_conservation_755  1
    load_0_13_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_572  -20
    arc_0_13_18  connected_order_arc_573  -13
    arc_0_13_18  out_degree_750  1
    arc_0_13_18  in_degree_781  1
    arc_0_13_18  original_T_including_depot_unload_795  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_572  1
    load_0_13_18  free_load_conservation_755  1
    load_0_13_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_574  -20
    arc_0_13_19  connected_order_arc_575  -13
    arc_0_13_19  out_degree_750  1
    arc_0_13_19  in_degree_787  1
    arc_0_13_19  original_T_including_depot_unload_795  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_574  1
    load_0_13_19  free_load_conservation_755  1
    load_0_13_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_576  -20
    arc_0_14_0  depot_return_or_bypass_715  1
    arc_0_14_0  out_degree_756  1
    arc_0_14_0  original_T_including_depot_unload_795  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_576  1
    load_0_14_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_577  -20
    arc_0_14_1  connected_order_arc_578  -13
    arc_0_14_1  in_degree_717  1
    arc_0_14_1  out_degree_756  1
    arc_0_14_1  original_T_including_depot_unload_795  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_577  1
    load_0_14_1  segment_load_conservation_720  -1
    load_0_14_1  segment_prefix_lb_721  1
    load_0_14_1  segment_prefix_ub_722  1
    load_0_14_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_579  -20
    arc_0_14_2  connected_order_arc_580  -13
    arc_0_14_2  in_degree_724  1
    arc_0_14_2  out_degree_756  1
    arc_0_14_2  original_T_including_depot_unload_795  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_579  1
    load_0_14_2  segment_load_conservation_727  -1
    load_0_14_2  segment_prefix_lb_728  1
    load_0_14_2  segment_prefix_ub_729  1
    load_0_14_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_581  -20
    arc_0_14_3  connected_order_arc_582  -13
    arc_0_14_3  in_degree_731  1
    arc_0_14_3  out_degree_756  1
    arc_0_14_3  original_T_including_depot_unload_795  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_581  1
    load_0_14_3  segment_load_conservation_734  -1
    load_0_14_3  segment_prefix_lb_735  1
    load_0_14_3  segment_prefix_ub_736  1
    load_0_14_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_583  -20
    arc_0_14_4  connected_order_arc_584  -13
    arc_0_14_4  in_degree_738  1
    arc_0_14_4  out_degree_756  1
    arc_0_14_4  original_T_including_depot_unload_795  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_583  1
    load_0_14_4  segment_load_conservation_741  -1
    load_0_14_4  segment_prefix_lb_742  1
    load_0_14_4  segment_prefix_ub_743  1
    load_0_14_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_585  -20
    arc_0_14_12  connected_order_arc_586  -13
    arc_0_14_12  in_degree_745  1
    arc_0_14_12  out_degree_756  1
    arc_0_14_12  original_T_including_depot_unload_795  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_585  1
    load_0_14_12  free_load_conservation_749  -1
    load_0_14_12  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_587  -20
    arc_0_14_13  connected_order_arc_588  -13
    arc_0_14_13  in_degree_751  1
    arc_0_14_13  out_degree_756  1
    arc_0_14_13  original_T_including_depot_unload_795  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_587  1
    load_0_14_13  free_load_conservation_755  -1
    load_0_14_13  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_589  -20
    arc_0_14_15  connected_order_arc_590  -13
    arc_0_14_15  out_degree_756  1
    arc_0_14_15  in_degree_763  1
    arc_0_14_15  original_T_including_depot_unload_795  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_589  1
    load_0_14_15  free_load_conservation_761  1
    load_0_14_15  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_591  -20
    arc_0_14_16  connected_order_arc_592  -13
    arc_0_14_16  out_degree_756  1
    arc_0_14_16  in_degree_769  1
    arc_0_14_16  original_T_including_depot_unload_795  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_591  1
    load_0_14_16  free_load_conservation_761  1
    load_0_14_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_593  -20
    arc_0_14_17  connected_order_arc_594  -13
    arc_0_14_17  out_degree_756  1
    arc_0_14_17  in_degree_775  1
    arc_0_14_17  original_T_including_depot_unload_795  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_593  1
    load_0_14_17  free_load_conservation_761  1
    load_0_14_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_595  -20
    arc_0_14_18  connected_order_arc_596  -13
    arc_0_14_18  out_degree_756  1
    arc_0_14_18  in_degree_781  1
    arc_0_14_18  original_T_including_depot_unload_795  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_595  1
    load_0_14_18  free_load_conservation_761  1
    load_0_14_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_597  -20
    arc_0_14_19  connected_order_arc_598  -13
    arc_0_14_19  out_degree_756  1
    arc_0_14_19  in_degree_787  1
    arc_0_14_19  original_T_including_depot_unload_795  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_597  1
    load_0_14_19  free_load_conservation_761  1
    load_0_14_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_599  -20
    arc_0_15_0  depot_return_or_bypass_715  1
    arc_0_15_0  out_degree_762  1
    arc_0_15_0  original_T_including_depot_unload_795  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_599  1
    load_0_15_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_600  -20
    arc_0_15_1  connected_order_arc_601  -13
    arc_0_15_1  in_degree_717  1
    arc_0_15_1  out_degree_762  1
    arc_0_15_1  original_T_including_depot_unload_795  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_600  1
    load_0_15_1  segment_load_conservation_720  -1
    load_0_15_1  segment_prefix_lb_721  1
    load_0_15_1  segment_prefix_ub_722  1
    load_0_15_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_602  -20
    arc_0_15_2  connected_order_arc_603  -13
    arc_0_15_2  in_degree_724  1
    arc_0_15_2  out_degree_762  1
    arc_0_15_2  original_T_including_depot_unload_795  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_602  1
    load_0_15_2  segment_load_conservation_727  -1
    load_0_15_2  segment_prefix_lb_728  1
    load_0_15_2  segment_prefix_ub_729  1
    load_0_15_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_604  -20
    arc_0_15_3  connected_order_arc_605  -13
    arc_0_15_3  in_degree_731  1
    arc_0_15_3  out_degree_762  1
    arc_0_15_3  original_T_including_depot_unload_795  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_604  1
    load_0_15_3  segment_load_conservation_734  -1
    load_0_15_3  segment_prefix_lb_735  1
    load_0_15_3  segment_prefix_ub_736  1
    load_0_15_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_606  -20
    arc_0_15_4  connected_order_arc_607  -13
    arc_0_15_4  in_degree_738  1
    arc_0_15_4  out_degree_762  1
    arc_0_15_4  original_T_including_depot_unload_795  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_606  1
    load_0_15_4  segment_load_conservation_741  -1
    load_0_15_4  segment_prefix_lb_742  1
    load_0_15_4  segment_prefix_ub_743  1
    load_0_15_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_608  -20
    arc_0_15_12  connected_order_arc_609  -13
    arc_0_15_12  in_degree_745  1
    arc_0_15_12  out_degree_762  1
    arc_0_15_12  original_T_including_depot_unload_795  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_608  1
    load_0_15_12  free_load_conservation_749  -1
    load_0_15_12  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_610  -20
    arc_0_15_13  connected_order_arc_611  -13
    arc_0_15_13  in_degree_751  1
    arc_0_15_13  out_degree_762  1
    arc_0_15_13  original_T_including_depot_unload_795  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_610  1
    load_0_15_13  free_load_conservation_755  -1
    load_0_15_13  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_612  -20
    arc_0_15_14  connected_order_arc_613  -13
    arc_0_15_14  in_degree_757  1
    arc_0_15_14  out_degree_762  1
    arc_0_15_14  original_T_including_depot_unload_795  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_612  1
    load_0_15_14  free_load_conservation_761  -1
    load_0_15_14  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_614  -20
    arc_0_15_16  connected_order_arc_615  -13
    arc_0_15_16  out_degree_762  1
    arc_0_15_16  in_degree_769  1
    arc_0_15_16  original_T_including_depot_unload_795  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_614  1
    load_0_15_16  free_load_conservation_767  1
    load_0_15_16  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_616  -20
    arc_0_15_17  connected_order_arc_617  -13
    arc_0_15_17  out_degree_762  1
    arc_0_15_17  in_degree_775  1
    arc_0_15_17  original_T_including_depot_unload_795  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_616  1
    load_0_15_17  free_load_conservation_767  1
    load_0_15_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_618  -20
    arc_0_15_18  connected_order_arc_619  -13
    arc_0_15_18  out_degree_762  1
    arc_0_15_18  in_degree_781  1
    arc_0_15_18  original_T_including_depot_unload_795  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_618  1
    load_0_15_18  free_load_conservation_767  1
    load_0_15_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_620  -20
    arc_0_15_19  connected_order_arc_621  -13
    arc_0_15_19  out_degree_762  1
    arc_0_15_19  in_degree_787  1
    arc_0_15_19  original_T_including_depot_unload_795  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_620  1
    load_0_15_19  free_load_conservation_767  1
    load_0_15_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_622  -20
    arc_0_16_0  depot_return_or_bypass_715  1
    arc_0_16_0  out_degree_768  1
    arc_0_16_0  original_T_including_depot_unload_795  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_622  1
    load_0_16_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_623  -20
    arc_0_16_1  connected_order_arc_624  -13
    arc_0_16_1  in_degree_717  1
    arc_0_16_1  out_degree_768  1
    arc_0_16_1  original_T_including_depot_unload_795  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_623  1
    load_0_16_1  segment_load_conservation_720  -1
    load_0_16_1  segment_prefix_lb_721  1
    load_0_16_1  segment_prefix_ub_722  1
    load_0_16_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_625  -20
    arc_0_16_2  connected_order_arc_626  -13
    arc_0_16_2  in_degree_724  1
    arc_0_16_2  out_degree_768  1
    arc_0_16_2  original_T_including_depot_unload_795  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_625  1
    load_0_16_2  segment_load_conservation_727  -1
    load_0_16_2  segment_prefix_lb_728  1
    load_0_16_2  segment_prefix_ub_729  1
    load_0_16_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_627  -20
    arc_0_16_3  connected_order_arc_628  -13
    arc_0_16_3  in_degree_731  1
    arc_0_16_3  out_degree_768  1
    arc_0_16_3  original_T_including_depot_unload_795  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_627  1
    load_0_16_3  segment_load_conservation_734  -1
    load_0_16_3  segment_prefix_lb_735  1
    load_0_16_3  segment_prefix_ub_736  1
    load_0_16_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_629  -20
    arc_0_16_4  connected_order_arc_630  -13
    arc_0_16_4  in_degree_738  1
    arc_0_16_4  out_degree_768  1
    arc_0_16_4  original_T_including_depot_unload_795  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_629  1
    load_0_16_4  segment_load_conservation_741  -1
    load_0_16_4  segment_prefix_lb_742  1
    load_0_16_4  segment_prefix_ub_743  1
    load_0_16_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_631  -20
    arc_0_16_12  connected_order_arc_632  -13
    arc_0_16_12  in_degree_745  1
    arc_0_16_12  out_degree_768  1
    arc_0_16_12  original_T_including_depot_unload_795  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_631  1
    load_0_16_12  free_load_conservation_749  -1
    load_0_16_12  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_633  -20
    arc_0_16_13  connected_order_arc_634  -13
    arc_0_16_13  in_degree_751  1
    arc_0_16_13  out_degree_768  1
    arc_0_16_13  original_T_including_depot_unload_795  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_633  1
    load_0_16_13  free_load_conservation_755  -1
    load_0_16_13  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_635  -20
    arc_0_16_14  connected_order_arc_636  -13
    arc_0_16_14  in_degree_757  1
    arc_0_16_14  out_degree_768  1
    arc_0_16_14  original_T_including_depot_unload_795  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_635  1
    load_0_16_14  free_load_conservation_761  -1
    load_0_16_14  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_637  -20
    arc_0_16_15  connected_order_arc_638  -13
    arc_0_16_15  in_degree_763  1
    arc_0_16_15  out_degree_768  1
    arc_0_16_15  original_T_including_depot_unload_795  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_637  1
    load_0_16_15  free_load_conservation_767  -1
    load_0_16_15  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_639  -20
    arc_0_16_17  connected_order_arc_640  -13
    arc_0_16_17  out_degree_768  1
    arc_0_16_17  in_degree_775  1
    arc_0_16_17  original_T_including_depot_unload_795  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_639  1
    load_0_16_17  free_load_conservation_773  1
    load_0_16_17  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_641  -20
    arc_0_16_18  connected_order_arc_642  -13
    arc_0_16_18  out_degree_768  1
    arc_0_16_18  in_degree_781  1
    arc_0_16_18  original_T_including_depot_unload_795  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_641  1
    load_0_16_18  free_load_conservation_773  1
    load_0_16_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_643  -20
    arc_0_16_19  connected_order_arc_644  -13
    arc_0_16_19  out_degree_768  1
    arc_0_16_19  in_degree_787  1
    arc_0_16_19  original_T_including_depot_unload_795  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_643  1
    load_0_16_19  free_load_conservation_773  1
    load_0_16_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_645  -20
    arc_0_17_0  depot_return_or_bypass_715  1
    arc_0_17_0  out_degree_774  1
    arc_0_17_0  original_T_including_depot_unload_795  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_645  1
    load_0_17_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_646  -20
    arc_0_17_1  connected_order_arc_647  -13
    arc_0_17_1  in_degree_717  1
    arc_0_17_1  out_degree_774  1
    arc_0_17_1  original_T_including_depot_unload_795  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_646  1
    load_0_17_1  segment_load_conservation_720  -1
    load_0_17_1  segment_prefix_lb_721  1
    load_0_17_1  segment_prefix_ub_722  1
    load_0_17_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_648  -20
    arc_0_17_2  connected_order_arc_649  -13
    arc_0_17_2  in_degree_724  1
    arc_0_17_2  out_degree_774  1
    arc_0_17_2  original_T_including_depot_unload_795  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_648  1
    load_0_17_2  segment_load_conservation_727  -1
    load_0_17_2  segment_prefix_lb_728  1
    load_0_17_2  segment_prefix_ub_729  1
    load_0_17_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_650  -20
    arc_0_17_3  connected_order_arc_651  -13
    arc_0_17_3  in_degree_731  1
    arc_0_17_3  out_degree_774  1
    arc_0_17_3  original_T_including_depot_unload_795  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_650  1
    load_0_17_3  segment_load_conservation_734  -1
    load_0_17_3  segment_prefix_lb_735  1
    load_0_17_3  segment_prefix_ub_736  1
    load_0_17_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_652  -20
    arc_0_17_4  connected_order_arc_653  -13
    arc_0_17_4  in_degree_738  1
    arc_0_17_4  out_degree_774  1
    arc_0_17_4  original_T_including_depot_unload_795  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_652  1
    load_0_17_4  segment_load_conservation_741  -1
    load_0_17_4  segment_prefix_lb_742  1
    load_0_17_4  segment_prefix_ub_743  1
    load_0_17_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_654  -20
    arc_0_17_12  connected_order_arc_655  -13
    arc_0_17_12  in_degree_745  1
    arc_0_17_12  out_degree_774  1
    arc_0_17_12  original_T_including_depot_unload_795  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_654  1
    load_0_17_12  free_load_conservation_749  -1
    load_0_17_12  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_656  -20
    arc_0_17_13  connected_order_arc_657  -13
    arc_0_17_13  in_degree_751  1
    arc_0_17_13  out_degree_774  1
    arc_0_17_13  original_T_including_depot_unload_795  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_656  1
    load_0_17_13  free_load_conservation_755  -1
    load_0_17_13  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_658  -20
    arc_0_17_14  connected_order_arc_659  -13
    arc_0_17_14  in_degree_757  1
    arc_0_17_14  out_degree_774  1
    arc_0_17_14  original_T_including_depot_unload_795  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_658  1
    load_0_17_14  free_load_conservation_761  -1
    load_0_17_14  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_660  -20
    arc_0_17_15  connected_order_arc_661  -13
    arc_0_17_15  in_degree_763  1
    arc_0_17_15  out_degree_774  1
    arc_0_17_15  original_T_including_depot_unload_795  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_660  1
    load_0_17_15  free_load_conservation_767  -1
    load_0_17_15  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_662  -20
    arc_0_17_16  connected_order_arc_663  -13
    arc_0_17_16  in_degree_769  1
    arc_0_17_16  out_degree_774  1
    arc_0_17_16  original_T_including_depot_unload_795  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_662  1
    load_0_17_16  free_load_conservation_773  -1
    load_0_17_16  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_664  -20
    arc_0_17_18  connected_order_arc_665  -13
    arc_0_17_18  out_degree_774  1
    arc_0_17_18  in_degree_781  1
    arc_0_17_18  original_T_including_depot_unload_795  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_664  1
    load_0_17_18  free_load_conservation_779  1
    load_0_17_18  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_666  -20
    arc_0_17_19  connected_order_arc_667  -13
    arc_0_17_19  out_degree_774  1
    arc_0_17_19  in_degree_787  1
    arc_0_17_19  original_T_including_depot_unload_795  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_666  1
    load_0_17_19  free_load_conservation_779  1
    load_0_17_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_668  -20
    arc_0_18_0  depot_return_or_bypass_715  1
    arc_0_18_0  out_degree_780  1
    arc_0_18_0  original_T_including_depot_unload_795  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_668  1
    load_0_18_0  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_669  -20
    arc_0_18_1  connected_order_arc_670  -13
    arc_0_18_1  in_degree_717  1
    arc_0_18_1  out_degree_780  1
    arc_0_18_1  original_T_including_depot_unload_795  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_669  1
    load_0_18_1  segment_load_conservation_720  -1
    load_0_18_1  segment_prefix_lb_721  1
    load_0_18_1  segment_prefix_ub_722  1
    load_0_18_1  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_671  -20
    arc_0_18_2  connected_order_arc_672  -13
    arc_0_18_2  in_degree_724  1
    arc_0_18_2  out_degree_780  1
    arc_0_18_2  original_T_including_depot_unload_795  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_671  1
    load_0_18_2  segment_load_conservation_727  -1
    load_0_18_2  segment_prefix_lb_728  1
    load_0_18_2  segment_prefix_ub_729  1
    load_0_18_2  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_673  -20
    arc_0_18_3  connected_order_arc_674  -13
    arc_0_18_3  in_degree_731  1
    arc_0_18_3  out_degree_780  1
    arc_0_18_3  original_T_including_depot_unload_795  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_673  1
    load_0_18_3  segment_load_conservation_734  -1
    load_0_18_3  segment_prefix_lb_735  1
    load_0_18_3  segment_prefix_ub_736  1
    load_0_18_3  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_675  -20
    arc_0_18_4  connected_order_arc_676  -13
    arc_0_18_4  in_degree_738  1
    arc_0_18_4  out_degree_780  1
    arc_0_18_4  original_T_including_depot_unload_795  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_675  1
    load_0_18_4  segment_load_conservation_741  -1
    load_0_18_4  segment_prefix_lb_742  1
    load_0_18_4  segment_prefix_ub_743  1
    load_0_18_4  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_677  -20
    arc_0_18_12  connected_order_arc_678  -13
    arc_0_18_12  in_degree_745  1
    arc_0_18_12  out_degree_780  1
    arc_0_18_12  original_T_including_depot_unload_795  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_677  1
    load_0_18_12  free_load_conservation_749  -1
    load_0_18_12  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_679  -20
    arc_0_18_13  connected_order_arc_680  -13
    arc_0_18_13  in_degree_751  1
    arc_0_18_13  out_degree_780  1
    arc_0_18_13  original_T_including_depot_unload_795  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_679  1
    load_0_18_13  free_load_conservation_755  -1
    load_0_18_13  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_681  -20
    arc_0_18_14  connected_order_arc_682  -13
    arc_0_18_14  in_degree_757  1
    arc_0_18_14  out_degree_780  1
    arc_0_18_14  original_T_including_depot_unload_795  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_681  1
    load_0_18_14  free_load_conservation_761  -1
    load_0_18_14  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_683  -20
    arc_0_18_15  connected_order_arc_684  -13
    arc_0_18_15  in_degree_763  1
    arc_0_18_15  out_degree_780  1
    arc_0_18_15  original_T_including_depot_unload_795  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_683  1
    load_0_18_15  free_load_conservation_767  -1
    load_0_18_15  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_685  -20
    arc_0_18_16  connected_order_arc_686  -13
    arc_0_18_16  in_degree_769  1
    arc_0_18_16  out_degree_780  1
    arc_0_18_16  original_T_including_depot_unload_795  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_685  1
    load_0_18_16  free_load_conservation_773  -1
    load_0_18_16  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_687  -20
    arc_0_18_17  connected_order_arc_688  -13
    arc_0_18_17  in_degree_775  1
    arc_0_18_17  out_degree_780  1
    arc_0_18_17  original_T_including_depot_unload_795  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_687  1
    load_0_18_17  free_load_conservation_779  -1
    load_0_18_17  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_689  -20
    arc_0_18_19  connected_order_arc_690  -13
    arc_0_18_19  out_degree_780  1
    arc_0_18_19  in_degree_787  1
    arc_0_18_19  original_T_including_depot_unload_795  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_689  1
    load_0_18_19  free_load_conservation_785  1
    load_0_18_19  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_691  -20
    arc_0_19_0  depot_return_or_bypass_715  1
    arc_0_19_0  out_degree_786  1
    arc_0_19_0  original_T_including_depot_unload_795  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_691  1
    load_0_19_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_692  -20
    arc_0_19_1  connected_order_arc_693  -13
    arc_0_19_1  in_degree_717  1
    arc_0_19_1  out_degree_786  1
    arc_0_19_1  original_T_including_depot_unload_795  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_692  1
    load_0_19_1  segment_load_conservation_720  -1
    load_0_19_1  segment_prefix_lb_721  1
    load_0_19_1  segment_prefix_ub_722  1
    load_0_19_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_694  -20
    arc_0_19_2  connected_order_arc_695  -13
    arc_0_19_2  in_degree_724  1
    arc_0_19_2  out_degree_786  1
    arc_0_19_2  original_T_including_depot_unload_795  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_694  1
    load_0_19_2  segment_load_conservation_727  -1
    load_0_19_2  segment_prefix_lb_728  1
    load_0_19_2  segment_prefix_ub_729  1
    load_0_19_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_696  -20
    arc_0_19_3  connected_order_arc_697  -13
    arc_0_19_3  in_degree_731  1
    arc_0_19_3  out_degree_786  1
    arc_0_19_3  original_T_including_depot_unload_795  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_696  1
    load_0_19_3  segment_load_conservation_734  -1
    load_0_19_3  segment_prefix_lb_735  1
    load_0_19_3  segment_prefix_ub_736  1
    load_0_19_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_698  -20
    arc_0_19_4  connected_order_arc_699  -13
    arc_0_19_4  in_degree_738  1
    arc_0_19_4  out_degree_786  1
    arc_0_19_4  original_T_including_depot_unload_795  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_698  1
    load_0_19_4  segment_load_conservation_741  -1
    load_0_19_4  segment_prefix_lb_742  1
    load_0_19_4  segment_prefix_ub_743  1
    load_0_19_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_700  -20
    arc_0_19_12  connected_order_arc_701  -13
    arc_0_19_12  in_degree_745  1
    arc_0_19_12  out_degree_786  1
    arc_0_19_12  original_T_including_depot_unload_795  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_700  1
    load_0_19_12  free_load_conservation_749  -1
    load_0_19_12  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_702  -20
    arc_0_19_13  connected_order_arc_703  -13
    arc_0_19_13  in_degree_751  1
    arc_0_19_13  out_degree_786  1
    arc_0_19_13  original_T_including_depot_unload_795  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_702  1
    load_0_19_13  free_load_conservation_755  -1
    load_0_19_13  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_704  -20
    arc_0_19_14  connected_order_arc_705  -13
    arc_0_19_14  in_degree_757  1
    arc_0_19_14  out_degree_786  1
    arc_0_19_14  original_T_including_depot_unload_795  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_704  1
    load_0_19_14  free_load_conservation_761  -1
    load_0_19_14  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_706  -20
    arc_0_19_15  connected_order_arc_707  -13
    arc_0_19_15  in_degree_763  1
    arc_0_19_15  out_degree_786  1
    arc_0_19_15  original_T_including_depot_unload_795  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_706  1
    load_0_19_15  free_load_conservation_767  -1
    load_0_19_15  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_708  -20
    arc_0_19_16  connected_order_arc_709  -13
    arc_0_19_16  in_degree_769  1
    arc_0_19_16  out_degree_786  1
    arc_0_19_16  original_T_including_depot_unload_795  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_708  1
    load_0_19_16  free_load_conservation_773  -1
    load_0_19_16  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_710  -20
    arc_0_19_17  connected_order_arc_711  -13
    arc_0_19_17  in_degree_775  1
    arc_0_19_17  out_degree_786  1
    arc_0_19_17  original_T_including_depot_unload_795  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_710  1
    load_0_19_17  free_load_conservation_779  -1
    load_0_19_17  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_712  -20
    arc_0_19_18  connected_order_arc_713  -13
    arc_0_19_18  in_degree_781  1
    arc_0_19_18  out_degree_786  1
    arc_0_19_18  original_T_including_depot_unload_795  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_712  1
    load_0_19_18  free_load_conservation_785  -1
    load_0_19_18  free_load_conservation_791  1
    visit_1_5  out_degree_1087  -1
    visit_1_5  in_degree_1088  -1
    visit_1_5  order_active_lb_1089  -1
    visit_1_5  order_active_ub_1090  -12
    order_1_5  connected_order_arc_811  -1
    order_1_5  connected_order_arc_813  -1
    order_1_5  connected_order_arc_815  -1
    order_1_5  connected_order_arc_817  -1
    order_1_5  connected_order_arc_819  -1
    order_1_5  connected_order_arc_821  -1
    order_1_5  connected_order_arc_823  -1
    order_1_5  connected_order_arc_825  -1
    order_1_5  connected_order_arc_827  -1
    order_1_5  connected_order_arc_829  -1
    order_1_5  connected_order_arc_831  -1
    order_1_5  connected_order_arc_834  1
    order_1_5  connected_order_arc_857  1
    order_1_5  connected_order_arc_880  1
    order_1_5  connected_order_arc_903  1
    order_1_5  connected_order_arc_926  1
    order_1_5  connected_order_arc_949  1
    order_1_5  connected_order_arc_972  1
    order_1_5  connected_order_arc_995  1
    order_1_5  connected_order_arc_1018  1
    order_1_5  connected_order_arc_1041  1
    order_1_5  connected_order_arc_1064  1
    order_1_5  order_active_lb_1089  1
    order_1_5  order_active_ub_1090  1
    order_1_5  fixed_segment_relative_order_1163  -1
    visit_1_6  out_degree_1094  -1
    visit_1_6  in_degree_1095  -1
    visit_1_6  order_active_lb_1096  -1
    visit_1_6  order_active_ub_1097  -12
    order_1_6  connected_order_arc_811  1
    order_1_6  connected_order_arc_834  -1
    order_1_6  connected_order_arc_836  -1
    order_1_6  connected_order_arc_838  -1
    order_1_6  connected_order_arc_840  -1
    order_1_6  connected_order_arc_842  -1
    order_1_6  connected_order_arc_844  -1
    order_1_6  connected_order_arc_846  -1
    order_1_6  connected_order_arc_848  -1
    order_1_6  connected_order_arc_850  -1
    order_1_6  connected_order_arc_852  -1
    order_1_6  connected_order_arc_854  -1
    order_1_6  connected_order_arc_859  1
    order_1_6  connected_order_arc_882  1
    order_1_6  connected_order_arc_905  1
    order_1_6  connected_order_arc_928  1
    order_1_6  connected_order_arc_951  1
    order_1_6  connected_order_arc_974  1
    order_1_6  connected_order_arc_997  1
    order_1_6  connected_order_arc_1020  1
    order_1_6  connected_order_arc_1043  1
    order_1_6  connected_order_arc_1066  1
    order_1_6  order_active_lb_1096  1
    order_1_6  order_active_ub_1097  1
    order_1_6  fixed_segment_relative_order_1163  1
    order_1_6  fixed_segment_relative_order_1164  -1
    visit_1_7  out_degree_1101  -1
    visit_1_7  in_degree_1102  -1
    visit_1_7  order_active_lb_1103  -1
    visit_1_7  order_active_ub_1104  -12
    order_1_7  connected_order_arc_813  1
    order_1_7  connected_order_arc_836  1
    order_1_7  connected_order_arc_857  -1
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_865  -1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_884  1
    order_1_7  connected_order_arc_907  1
    order_1_7  connected_order_arc_930  1
    order_1_7  connected_order_arc_953  1
    order_1_7  connected_order_arc_976  1
    order_1_7  connected_order_arc_999  1
    order_1_7  connected_order_arc_1022  1
    order_1_7  connected_order_arc_1045  1
    order_1_7  connected_order_arc_1068  1
    order_1_7  order_active_lb_1103  1
    order_1_7  order_active_ub_1104  1
    order_1_7  fixed_segment_relative_order_1164  1
    order_1_7  fixed_segment_relative_order_1165  -1
    visit_1_8  out_degree_1108  -1
    visit_1_8  in_degree_1109  -1
    visit_1_8  order_active_lb_1110  -1
    visit_1_8  order_active_ub_1111  -12
    order_1_8  connected_order_arc_815  1
    order_1_8  connected_order_arc_838  1
    order_1_8  connected_order_arc_861  1
    order_1_8  connected_order_arc_880  -1
    order_1_8  connected_order_arc_882  -1
    order_1_8  connected_order_arc_884  -1
    order_1_8  connected_order_arc_886  -1
    order_1_8  connected_order_arc_888  -1
    order_1_8  connected_order_arc_890  -1
    order_1_8  connected_order_arc_892  -1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_909  1
    order_1_8  connected_order_arc_932  1
    order_1_8  connected_order_arc_955  1
    order_1_8  connected_order_arc_978  1
    order_1_8  connected_order_arc_1001  1
    order_1_8  connected_order_arc_1024  1
    order_1_8  connected_order_arc_1047  1
    order_1_8  connected_order_arc_1070  1
    order_1_8  order_active_lb_1110  1
    order_1_8  order_active_ub_1111  1
    order_1_8  fixed_segment_relative_order_1165  1
    visit_1_12  out_degree_1115  -1
    visit_1_12  in_degree_1116  -1
    visit_1_12  order_active_lb_1117  -1
    visit_1_12  order_active_ub_1118  -12
    visit_1_12  service_visit_def_1119  -1
    order_1_12  connected_order_arc_817  1
    order_1_12  connected_order_arc_840  1
    order_1_12  connected_order_arc_863  1
    order_1_12  connected_order_arc_886  1
    order_1_12  connected_order_arc_903  -1
    order_1_12  connected_order_arc_905  -1
    order_1_12  connected_order_arc_907  -1
    order_1_12  connected_order_arc_909  -1
    order_1_12  connected_order_arc_911  -1
    order_1_12  connected_order_arc_913  -1
    order_1_12  connected_order_arc_915  -1
    order_1_12  connected_order_arc_917  -1
    order_1_12  connected_order_arc_919  -1
    order_1_12  connected_order_arc_921  -1
    order_1_12  connected_order_arc_923  -1
    order_1_12  connected_order_arc_934  1
    order_1_12  connected_order_arc_957  1
    order_1_12  connected_order_arc_980  1
    order_1_12  connected_order_arc_1003  1
    order_1_12  connected_order_arc_1026  1
    order_1_12  connected_order_arc_1049  1
    order_1_12  connected_order_arc_1072  1
    order_1_12  order_active_lb_1117  1
    order_1_12  order_active_ub_1118  1
    visit_1_13  out_degree_1121  -1
    visit_1_13  in_degree_1122  -1
    visit_1_13  order_active_lb_1123  -1
    visit_1_13  order_active_ub_1124  -12
    visit_1_13  service_visit_def_1125  -1
    order_1_13  connected_order_arc_819  1
    order_1_13  connected_order_arc_842  1
    order_1_13  connected_order_arc_865  1
    order_1_13  connected_order_arc_888  1
    order_1_13  connected_order_arc_911  1
    order_1_13  connected_order_arc_926  -1
    order_1_13  connected_order_arc_928  -1
    order_1_13  connected_order_arc_930  -1
    order_1_13  connected_order_arc_932  -1
    order_1_13  connected_order_arc_934  -1
    order_1_13  connected_order_arc_936  -1
    order_1_13  connected_order_arc_938  -1
    order_1_13  connected_order_arc_940  -1
    order_1_13  connected_order_arc_942  -1
    order_1_13  connected_order_arc_944  -1
    order_1_13  connected_order_arc_946  -1
    order_1_13  connected_order_arc_959  1
    order_1_13  connected_order_arc_982  1
    order_1_13  connected_order_arc_1005  1
    order_1_13  connected_order_arc_1028  1
    order_1_13  connected_order_arc_1051  1
    order_1_13  connected_order_arc_1074  1
    order_1_13  order_active_lb_1123  1
    order_1_13  order_active_ub_1124  1
    visit_1_14  out_degree_1127  -1
    visit_1_14  in_degree_1128  -1
    visit_1_14  order_active_lb_1129  -1
    visit_1_14  order_active_ub_1130  -12
    visit_1_14  service_visit_def_1131  -1
    order_1_14  connected_order_arc_821  1
    order_1_14  connected_order_arc_844  1
    order_1_14  connected_order_arc_867  1
    order_1_14  connected_order_arc_890  1
    order_1_14  connected_order_arc_913  1
    order_1_14  connected_order_arc_936  1
    order_1_14  connected_order_arc_949  -1
    order_1_14  connected_order_arc_951  -1
    order_1_14  connected_order_arc_953  -1
    order_1_14  connected_order_arc_955  -1
    order_1_14  connected_order_arc_957  -1
    order_1_14  connected_order_arc_959  -1
    order_1_14  connected_order_arc_961  -1
    order_1_14  connected_order_arc_963  -1
    order_1_14  connected_order_arc_965  -1
    order_1_14  connected_order_arc_967  -1
    order_1_14  connected_order_arc_969  -1
    order_1_14  connected_order_arc_984  1
    order_1_14  connected_order_arc_1007  1
    order_1_14  connected_order_arc_1030  1
    order_1_14  connected_order_arc_1053  1
    order_1_14  connected_order_arc_1076  1
    order_1_14  order_active_lb_1129  1
    order_1_14  order_active_ub_1130  1
    visit_1_15  out_degree_1133  -1
    visit_1_15  in_degree_1134  -1
    visit_1_15  order_active_lb_1135  -1
    visit_1_15  order_active_ub_1136  -12
    visit_1_15  service_visit_def_1137  -1
    order_1_15  connected_order_arc_823  1
    order_1_15  connected_order_arc_846  1
    order_1_15  connected_order_arc_869  1
    order_1_15  connected_order_arc_892  1
    order_1_15  connected_order_arc_915  1
    order_1_15  connected_order_arc_938  1
    order_1_15  connected_order_arc_961  1
    order_1_15  connected_order_arc_972  -1
    order_1_15  connected_order_arc_974  -1
    order_1_15  connected_order_arc_976  -1
    order_1_15  connected_order_arc_978  -1
    order_1_15  connected_order_arc_980  -1
    order_1_15  connected_order_arc_982  -1
    order_1_15  connected_order_arc_984  -1
    order_1_15  connected_order_arc_986  -1
    order_1_15  connected_order_arc_988  -1
    order_1_15  connected_order_arc_990  -1
    order_1_15  connected_order_arc_992  -1
    order_1_15  connected_order_arc_1009  1
    order_1_15  connected_order_arc_1032  1
    order_1_15  connected_order_arc_1055  1
    order_1_15  connected_order_arc_1078  1
    order_1_15  order_active_lb_1135  1
    order_1_15  order_active_ub_1136  1
    visit_1_16  out_degree_1139  -1
    visit_1_16  in_degree_1140  -1
    visit_1_16  order_active_lb_1141  -1
    visit_1_16  order_active_ub_1142  -12
    visit_1_16  service_visit_def_1143  -1
    order_1_16  connected_order_arc_825  1
    order_1_16  connected_order_arc_848  1
    order_1_16  connected_order_arc_871  1
    order_1_16  connected_order_arc_894  1
    order_1_16  connected_order_arc_917  1
    order_1_16  connected_order_arc_940  1
    order_1_16  connected_order_arc_963  1
    order_1_16  connected_order_arc_986  1
    order_1_16  connected_order_arc_995  -1
    order_1_16  connected_order_arc_997  -1
    order_1_16  connected_order_arc_999  -1
    order_1_16  connected_order_arc_1001  -1
    order_1_16  connected_order_arc_1003  -1
    order_1_16  connected_order_arc_1005  -1
    order_1_16  connected_order_arc_1007  -1
    order_1_16  connected_order_arc_1009  -1
    order_1_16  connected_order_arc_1011  -1
    order_1_16  connected_order_arc_1013  -1
    order_1_16  connected_order_arc_1015  -1
    order_1_16  connected_order_arc_1034  1
    order_1_16  connected_order_arc_1057  1
    order_1_16  connected_order_arc_1080  1
    order_1_16  order_active_lb_1141  1
    order_1_16  order_active_ub_1142  1
    visit_1_17  out_degree_1145  -1
    visit_1_17  in_degree_1146  -1
    visit_1_17  order_active_lb_1147  -1
    visit_1_17  order_active_ub_1148  -12
    visit_1_17  service_visit_def_1149  -1
    order_1_17  connected_order_arc_827  1
    order_1_17  connected_order_arc_850  1
    order_1_17  connected_order_arc_873  1
    order_1_17  connected_order_arc_896  1
    order_1_17  connected_order_arc_919  1
    order_1_17  connected_order_arc_942  1
    order_1_17  connected_order_arc_965  1
    order_1_17  connected_order_arc_988  1
    order_1_17  connected_order_arc_1011  1
    order_1_17  connected_order_arc_1018  -1
    order_1_17  connected_order_arc_1020  -1
    order_1_17  connected_order_arc_1022  -1
    order_1_17  connected_order_arc_1024  -1
    order_1_17  connected_order_arc_1026  -1
    order_1_17  connected_order_arc_1028  -1
    order_1_17  connected_order_arc_1030  -1
    order_1_17  connected_order_arc_1032  -1
    order_1_17  connected_order_arc_1034  -1
    order_1_17  connected_order_arc_1036  -1
    order_1_17  connected_order_arc_1038  -1
    order_1_17  connected_order_arc_1059  1
    order_1_17  connected_order_arc_1082  1
    order_1_17  order_active_lb_1147  1
    order_1_17  order_active_ub_1148  1
    visit_1_18  out_degree_1151  -1
    visit_1_18  in_degree_1152  -1
    visit_1_18  order_active_lb_1153  -1
    visit_1_18  order_active_ub_1154  -12
    visit_1_18  service_visit_def_1155  -1
    order_1_18  connected_order_arc_829  1
    order_1_18  connected_order_arc_852  1
    order_1_18  connected_order_arc_875  1
    order_1_18  connected_order_arc_898  1
    order_1_18  connected_order_arc_921  1
    order_1_18  connected_order_arc_944  1
    order_1_18  connected_order_arc_967  1
    order_1_18  connected_order_arc_990  1
    order_1_18  connected_order_arc_1013  1
    order_1_18  connected_order_arc_1036  1
    order_1_18  connected_order_arc_1041  -1
    order_1_18  connected_order_arc_1043  -1
    order_1_18  connected_order_arc_1045  -1
    order_1_18  connected_order_arc_1047  -1
    order_1_18  connected_order_arc_1049  -1
    order_1_18  connected_order_arc_1051  -1
    order_1_18  connected_order_arc_1053  -1
    order_1_18  connected_order_arc_1055  -1
    order_1_18  connected_order_arc_1057  -1
    order_1_18  connected_order_arc_1059  -1
    order_1_18  connected_order_arc_1061  -1
    order_1_18  connected_order_arc_1084  1
    order_1_18  order_active_lb_1153  1
    order_1_18  order_active_ub_1154  1
    visit_1_19  out_degree_1157  -1
    visit_1_19  in_degree_1158  -1
    visit_1_19  order_active_lb_1159  -1
    visit_1_19  order_active_ub_1160  -12
    visit_1_19  service_visit_def_1161  -1
    order_1_19  connected_order_arc_831  1
    order_1_19  connected_order_arc_854  1
    order_1_19  connected_order_arc_877  1
    order_1_19  connected_order_arc_900  1
    order_1_19  connected_order_arc_923  1
    order_1_19  connected_order_arc_946  1
    order_1_19  connected_order_arc_969  1
    order_1_19  connected_order_arc_992  1
    order_1_19  connected_order_arc_1015  1
    order_1_19  connected_order_arc_1038  1
    order_1_19  connected_order_arc_1061  1
    order_1_19  connected_order_arc_1064  -1
    order_1_19  connected_order_arc_1066  -1
    order_1_19  connected_order_arc_1068  -1
    order_1_19  connected_order_arc_1070  -1
    order_1_19  connected_order_arc_1072  -1
    order_1_19  connected_order_arc_1074  -1
    order_1_19  connected_order_arc_1076  -1
    order_1_19  connected_order_arc_1078  -1
    order_1_19  connected_order_arc_1080  -1
    order_1_19  connected_order_arc_1082  -1
    order_1_19  connected_order_arc_1084  -1
    order_1_19  order_active_lb_1159  1
    order_1_19  order_active_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_796  -25
    arc_1_0_0  depot_departure_or_bypass_1085  1
    arc_1_0_0  depot_return_or_bypass_1086  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_796  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_797  -25
    arc_1_0_5  depot_departure_or_bypass_1085  1
    arc_1_0_5  in_degree_1088  1
    arc_1_0_5  original_T_including_depot_unload_1166  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_797  1
    load_1_0_5  segment_load_conservation_1091  -1
    load_1_0_5  segment_prefix_lb_1092  1
    load_1_0_5  segment_prefix_ub_1093  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_798  -25
    arc_1_0_6  depot_departure_or_bypass_1085  1
    arc_1_0_6  in_degree_1095  1
    arc_1_0_6  original_T_including_depot_unload_1166  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_798  1
    load_1_0_6  segment_load_conservation_1098  -1
    load_1_0_6  segment_prefix_lb_1099  1
    load_1_0_6  segment_prefix_ub_1100  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_799  -25
    arc_1_0_7  depot_departure_or_bypass_1085  1
    arc_1_0_7  in_degree_1102  1
    arc_1_0_7  original_T_including_depot_unload_1166  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_799  1
    load_1_0_7  segment_load_conservation_1105  -1
    load_1_0_7  segment_prefix_lb_1106  1
    load_1_0_7  segment_prefix_ub_1107  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_800  -25
    arc_1_0_8  depot_departure_or_bypass_1085  1
    arc_1_0_8  in_degree_1109  1
    arc_1_0_8  original_T_including_depot_unload_1166  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_800  1
    load_1_0_8  segment_load_conservation_1112  -1
    load_1_0_8  segment_prefix_lb_1113  1
    load_1_0_8  segment_prefix_ub_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_801  -25
    arc_1_0_12  depot_departure_or_bypass_1085  1
    arc_1_0_12  in_degree_1116  1
    arc_1_0_12  original_T_including_depot_unload_1166  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_801  1
    load_1_0_12  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_802  -25
    arc_1_0_13  depot_departure_or_bypass_1085  1
    arc_1_0_13  in_degree_1122  1
    arc_1_0_13  original_T_including_depot_unload_1166  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_802  1
    load_1_0_13  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_803  -25
    arc_1_0_14  depot_departure_or_bypass_1085  1
    arc_1_0_14  in_degree_1128  1
    arc_1_0_14  original_T_including_depot_unload_1166  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_803  1
    load_1_0_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_804  -25
    arc_1_0_15  depot_departure_or_bypass_1085  1
    arc_1_0_15  in_degree_1134  1
    arc_1_0_15  original_T_including_depot_unload_1166  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_804  1
    load_1_0_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_805  -25
    arc_1_0_16  depot_departure_or_bypass_1085  1
    arc_1_0_16  in_degree_1140  1
    arc_1_0_16  original_T_including_depot_unload_1166  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_805  1
    load_1_0_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_806  -25
    arc_1_0_17  depot_departure_or_bypass_1085  1
    arc_1_0_17  in_degree_1146  1
    arc_1_0_17  original_T_including_depot_unload_1166  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_806  1
    load_1_0_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_807  -25
    arc_1_0_18  depot_departure_or_bypass_1085  1
    arc_1_0_18  in_degree_1152  1
    arc_1_0_18  original_T_including_depot_unload_1166  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_807  1
    load_1_0_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_808  -25
    arc_1_0_19  depot_departure_or_bypass_1085  1
    arc_1_0_19  in_degree_1158  1
    arc_1_0_19  original_T_including_depot_unload_1166  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_808  1
    load_1_0_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_809  -25
    arc_1_5_0  depot_return_or_bypass_1086  1
    arc_1_5_0  out_degree_1087  1
    arc_1_5_0  original_T_including_depot_unload_1166  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_809  1
    load_1_5_0  segment_load_conservation_1091  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_810  -25
    arc_1_5_6  connected_order_arc_811  -13
    arc_1_5_6  out_degree_1087  1
    arc_1_5_6  in_degree_1095  1
    arc_1_5_6  original_T_including_depot_unload_1166  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_810  1
    load_1_5_6  segment_load_conservation_1091  1
    load_1_5_6  segment_load_conservation_1098  -1
    load_1_5_6  segment_prefix_lb_1099  1
    load_1_5_6  segment_prefix_ub_1100  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_812  -25
    arc_1_5_7  connected_order_arc_813  -13
    arc_1_5_7  out_degree_1087  1
    arc_1_5_7  in_degree_1102  1
    arc_1_5_7  original_T_including_depot_unload_1166  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_812  1
    load_1_5_7  segment_load_conservation_1091  1
    load_1_5_7  segment_load_conservation_1105  -1
    load_1_5_7  segment_prefix_lb_1106  1
    load_1_5_7  segment_prefix_ub_1107  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_814  -25
    arc_1_5_8  connected_order_arc_815  -13
    arc_1_5_8  out_degree_1087  1
    arc_1_5_8  in_degree_1109  1
    arc_1_5_8  original_T_including_depot_unload_1166  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_814  1
    load_1_5_8  segment_load_conservation_1091  1
    load_1_5_8  segment_load_conservation_1112  -1
    load_1_5_8  segment_prefix_lb_1113  1
    load_1_5_8  segment_prefix_ub_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_816  -25
    arc_1_5_12  connected_order_arc_817  -13
    arc_1_5_12  out_degree_1087  1
    arc_1_5_12  in_degree_1116  1
    arc_1_5_12  original_T_including_depot_unload_1166  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_816  1
    load_1_5_12  segment_load_conservation_1091  1
    load_1_5_12  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_818  -25
    arc_1_5_13  connected_order_arc_819  -13
    arc_1_5_13  out_degree_1087  1
    arc_1_5_13  in_degree_1122  1
    arc_1_5_13  original_T_including_depot_unload_1166  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_818  1
    load_1_5_13  segment_load_conservation_1091  1
    load_1_5_13  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_820  -25
    arc_1_5_14  connected_order_arc_821  -13
    arc_1_5_14  out_degree_1087  1
    arc_1_5_14  in_degree_1128  1
    arc_1_5_14  original_T_including_depot_unload_1166  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_820  1
    load_1_5_14  segment_load_conservation_1091  1
    load_1_5_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_822  -25
    arc_1_5_15  connected_order_arc_823  -13
    arc_1_5_15  out_degree_1087  1
    arc_1_5_15  in_degree_1134  1
    arc_1_5_15  original_T_including_depot_unload_1166  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_822  1
    load_1_5_15  segment_load_conservation_1091  1
    load_1_5_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_824  -25
    arc_1_5_16  connected_order_arc_825  -13
    arc_1_5_16  out_degree_1087  1
    arc_1_5_16  in_degree_1140  1
    arc_1_5_16  original_T_including_depot_unload_1166  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_824  1
    load_1_5_16  segment_load_conservation_1091  1
    load_1_5_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_826  -25
    arc_1_5_17  connected_order_arc_827  -13
    arc_1_5_17  out_degree_1087  1
    arc_1_5_17  in_degree_1146  1
    arc_1_5_17  original_T_including_depot_unload_1166  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_826  1
    load_1_5_17  segment_load_conservation_1091  1
    load_1_5_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_828  -25
    arc_1_5_18  connected_order_arc_829  -13
    arc_1_5_18  out_degree_1087  1
    arc_1_5_18  in_degree_1152  1
    arc_1_5_18  original_T_including_depot_unload_1166  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_828  1
    load_1_5_18  segment_load_conservation_1091  1
    load_1_5_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_830  -25
    arc_1_5_19  connected_order_arc_831  -13
    arc_1_5_19  out_degree_1087  1
    arc_1_5_19  in_degree_1158  1
    arc_1_5_19  original_T_including_depot_unload_1166  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_830  1
    load_1_5_19  segment_load_conservation_1091  1
    load_1_5_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_832  -25
    arc_1_6_0  depot_return_or_bypass_1086  1
    arc_1_6_0  out_degree_1094  1
    arc_1_6_0  original_T_including_depot_unload_1166  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_832  1
    load_1_6_0  segment_load_conservation_1098  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_833  -25
    arc_1_6_5  connected_order_arc_834  -13
    arc_1_6_5  in_degree_1088  1
    arc_1_6_5  out_degree_1094  1
    arc_1_6_5  original_T_including_depot_unload_1166  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_833  1
    load_1_6_5  segment_load_conservation_1091  -1
    load_1_6_5  segment_prefix_lb_1092  1
    load_1_6_5  segment_prefix_ub_1093  1
    load_1_6_5  segment_load_conservation_1098  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_835  -25
    arc_1_6_7  connected_order_arc_836  -13
    arc_1_6_7  out_degree_1094  1
    arc_1_6_7  in_degree_1102  1
    arc_1_6_7  original_T_including_depot_unload_1166  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_835  1
    load_1_6_7  segment_load_conservation_1098  1
    load_1_6_7  segment_load_conservation_1105  -1
    load_1_6_7  segment_prefix_lb_1106  1
    load_1_6_7  segment_prefix_ub_1107  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_837  -25
    arc_1_6_8  connected_order_arc_838  -13
    arc_1_6_8  out_degree_1094  1
    arc_1_6_8  in_degree_1109  1
    arc_1_6_8  original_T_including_depot_unload_1166  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_837  1
    load_1_6_8  segment_load_conservation_1098  1
    load_1_6_8  segment_load_conservation_1112  -1
    load_1_6_8  segment_prefix_lb_1113  1
    load_1_6_8  segment_prefix_ub_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_839  -25
    arc_1_6_12  connected_order_arc_840  -13
    arc_1_6_12  out_degree_1094  1
    arc_1_6_12  in_degree_1116  1
    arc_1_6_12  original_T_including_depot_unload_1166  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_839  1
    load_1_6_12  segment_load_conservation_1098  1
    load_1_6_12  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_841  -25
    arc_1_6_13  connected_order_arc_842  -13
    arc_1_6_13  out_degree_1094  1
    arc_1_6_13  in_degree_1122  1
    arc_1_6_13  original_T_including_depot_unload_1166  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_841  1
    load_1_6_13  segment_load_conservation_1098  1
    load_1_6_13  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_843  -25
    arc_1_6_14  connected_order_arc_844  -13
    arc_1_6_14  out_degree_1094  1
    arc_1_6_14  in_degree_1128  1
    arc_1_6_14  original_T_including_depot_unload_1166  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_843  1
    load_1_6_14  segment_load_conservation_1098  1
    load_1_6_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_845  -25
    arc_1_6_15  connected_order_arc_846  -13
    arc_1_6_15  out_degree_1094  1
    arc_1_6_15  in_degree_1134  1
    arc_1_6_15  original_T_including_depot_unload_1166  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_845  1
    load_1_6_15  segment_load_conservation_1098  1
    load_1_6_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_847  -25
    arc_1_6_16  connected_order_arc_848  -13
    arc_1_6_16  out_degree_1094  1
    arc_1_6_16  in_degree_1140  1
    arc_1_6_16  original_T_including_depot_unload_1166  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_847  1
    load_1_6_16  segment_load_conservation_1098  1
    load_1_6_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_849  -25
    arc_1_6_17  connected_order_arc_850  -13
    arc_1_6_17  out_degree_1094  1
    arc_1_6_17  in_degree_1146  1
    arc_1_6_17  original_T_including_depot_unload_1166  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_849  1
    load_1_6_17  segment_load_conservation_1098  1
    load_1_6_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_851  -25
    arc_1_6_18  connected_order_arc_852  -13
    arc_1_6_18  out_degree_1094  1
    arc_1_6_18  in_degree_1152  1
    arc_1_6_18  original_T_including_depot_unload_1166  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_851  1
    load_1_6_18  segment_load_conservation_1098  1
    load_1_6_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_853  -25
    arc_1_6_19  connected_order_arc_854  -13
    arc_1_6_19  out_degree_1094  1
    arc_1_6_19  in_degree_1158  1
    arc_1_6_19  original_T_including_depot_unload_1166  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_853  1
    load_1_6_19  segment_load_conservation_1098  1
    load_1_6_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_855  -25
    arc_1_7_0  depot_return_or_bypass_1086  1
    arc_1_7_0  out_degree_1101  1
    arc_1_7_0  original_T_including_depot_unload_1166  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_855  1
    load_1_7_0  segment_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_856  -25
    arc_1_7_5  connected_order_arc_857  -13
    arc_1_7_5  in_degree_1088  1
    arc_1_7_5  out_degree_1101  1
    arc_1_7_5  original_T_including_depot_unload_1166  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_856  1
    load_1_7_5  segment_load_conservation_1091  -1
    load_1_7_5  segment_prefix_lb_1092  1
    load_1_7_5  segment_prefix_ub_1093  1
    load_1_7_5  segment_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_858  -25
    arc_1_7_6  connected_order_arc_859  -13
    arc_1_7_6  in_degree_1095  1
    arc_1_7_6  out_degree_1101  1
    arc_1_7_6  original_T_including_depot_unload_1166  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_858  1
    load_1_7_6  segment_load_conservation_1098  -1
    load_1_7_6  segment_prefix_lb_1099  1
    load_1_7_6  segment_prefix_ub_1100  1
    load_1_7_6  segment_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_860  -25
    arc_1_7_8  connected_order_arc_861  -13
    arc_1_7_8  out_degree_1101  1
    arc_1_7_8  in_degree_1109  1
    arc_1_7_8  original_T_including_depot_unload_1166  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_860  1
    load_1_7_8  segment_load_conservation_1105  1
    load_1_7_8  segment_load_conservation_1112  -1
    load_1_7_8  segment_prefix_lb_1113  1
    load_1_7_8  segment_prefix_ub_1114  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_862  -25
    arc_1_7_12  connected_order_arc_863  -13
    arc_1_7_12  out_degree_1101  1
    arc_1_7_12  in_degree_1116  1
    arc_1_7_12  original_T_including_depot_unload_1166  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_862  1
    load_1_7_12  segment_load_conservation_1105  1
    load_1_7_12  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_864  -25
    arc_1_7_13  connected_order_arc_865  -13
    arc_1_7_13  out_degree_1101  1
    arc_1_7_13  in_degree_1122  1
    arc_1_7_13  original_T_including_depot_unload_1166  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_864  1
    load_1_7_13  segment_load_conservation_1105  1
    load_1_7_13  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_866  -25
    arc_1_7_14  connected_order_arc_867  -13
    arc_1_7_14  out_degree_1101  1
    arc_1_7_14  in_degree_1128  1
    arc_1_7_14  original_T_including_depot_unload_1166  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_866  1
    load_1_7_14  segment_load_conservation_1105  1
    load_1_7_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_868  -25
    arc_1_7_15  connected_order_arc_869  -13
    arc_1_7_15  out_degree_1101  1
    arc_1_7_15  in_degree_1134  1
    arc_1_7_15  original_T_including_depot_unload_1166  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_868  1
    load_1_7_15  segment_load_conservation_1105  1
    load_1_7_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_870  -25
    arc_1_7_16  connected_order_arc_871  -13
    arc_1_7_16  out_degree_1101  1
    arc_1_7_16  in_degree_1140  1
    arc_1_7_16  original_T_including_depot_unload_1166  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_870  1
    load_1_7_16  segment_load_conservation_1105  1
    load_1_7_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_872  -25
    arc_1_7_17  connected_order_arc_873  -13
    arc_1_7_17  out_degree_1101  1
    arc_1_7_17  in_degree_1146  1
    arc_1_7_17  original_T_including_depot_unload_1166  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_872  1
    load_1_7_17  segment_load_conservation_1105  1
    load_1_7_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_874  -25
    arc_1_7_18  connected_order_arc_875  -13
    arc_1_7_18  out_degree_1101  1
    arc_1_7_18  in_degree_1152  1
    arc_1_7_18  original_T_including_depot_unload_1166  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_874  1
    load_1_7_18  segment_load_conservation_1105  1
    load_1_7_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_876  -25
    arc_1_7_19  connected_order_arc_877  -13
    arc_1_7_19  out_degree_1101  1
    arc_1_7_19  in_degree_1158  1
    arc_1_7_19  original_T_including_depot_unload_1166  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_876  1
    load_1_7_19  segment_load_conservation_1105  1
    load_1_7_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_878  -25
    arc_1_8_0  depot_return_or_bypass_1086  1
    arc_1_8_0  out_degree_1108  1
    arc_1_8_0  original_T_including_depot_unload_1166  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_878  1
    load_1_8_0  segment_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_879  -25
    arc_1_8_5  connected_order_arc_880  -13
    arc_1_8_5  in_degree_1088  1
    arc_1_8_5  out_degree_1108  1
    arc_1_8_5  original_T_including_depot_unload_1166  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_879  1
    load_1_8_5  segment_load_conservation_1091  -1
    load_1_8_5  segment_prefix_lb_1092  1
    load_1_8_5  segment_prefix_ub_1093  1
    load_1_8_5  segment_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_881  -25
    arc_1_8_6  connected_order_arc_882  -13
    arc_1_8_6  in_degree_1095  1
    arc_1_8_6  out_degree_1108  1
    arc_1_8_6  original_T_including_depot_unload_1166  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_881  1
    load_1_8_6  segment_load_conservation_1098  -1
    load_1_8_6  segment_prefix_lb_1099  1
    load_1_8_6  segment_prefix_ub_1100  1
    load_1_8_6  segment_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_883  -25
    arc_1_8_7  connected_order_arc_884  -13
    arc_1_8_7  in_degree_1102  1
    arc_1_8_7  out_degree_1108  1
    arc_1_8_7  original_T_including_depot_unload_1166  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_883  1
    load_1_8_7  segment_load_conservation_1105  -1
    load_1_8_7  segment_prefix_lb_1106  1
    load_1_8_7  segment_prefix_ub_1107  1
    load_1_8_7  segment_load_conservation_1112  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_885  -25
    arc_1_8_12  connected_order_arc_886  -13
    arc_1_8_12  out_degree_1108  1
    arc_1_8_12  in_degree_1116  1
    arc_1_8_12  original_T_including_depot_unload_1166  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_885  1
    load_1_8_12  segment_load_conservation_1112  1
    load_1_8_12  free_load_conservation_1120  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_887  -25
    arc_1_8_13  connected_order_arc_888  -13
    arc_1_8_13  out_degree_1108  1
    arc_1_8_13  in_degree_1122  1
    arc_1_8_13  original_T_including_depot_unload_1166  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_887  1
    load_1_8_13  segment_load_conservation_1112  1
    load_1_8_13  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_889  -25
    arc_1_8_14  connected_order_arc_890  -13
    arc_1_8_14  out_degree_1108  1
    arc_1_8_14  in_degree_1128  1
    arc_1_8_14  original_T_including_depot_unload_1166  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_889  1
    load_1_8_14  segment_load_conservation_1112  1
    load_1_8_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_891  -25
    arc_1_8_15  connected_order_arc_892  -13
    arc_1_8_15  out_degree_1108  1
    arc_1_8_15  in_degree_1134  1
    arc_1_8_15  original_T_including_depot_unload_1166  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_891  1
    load_1_8_15  segment_load_conservation_1112  1
    load_1_8_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_893  -25
    arc_1_8_16  connected_order_arc_894  -13
    arc_1_8_16  out_degree_1108  1
    arc_1_8_16  in_degree_1140  1
    arc_1_8_16  original_T_including_depot_unload_1166  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_893  1
    load_1_8_16  segment_load_conservation_1112  1
    load_1_8_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_895  -25
    arc_1_8_17  connected_order_arc_896  -13
    arc_1_8_17  out_degree_1108  1
    arc_1_8_17  in_degree_1146  1
    arc_1_8_17  original_T_including_depot_unload_1166  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_895  1
    load_1_8_17  segment_load_conservation_1112  1
    load_1_8_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_897  -25
    arc_1_8_18  connected_order_arc_898  -13
    arc_1_8_18  out_degree_1108  1
    arc_1_8_18  in_degree_1152  1
    arc_1_8_18  original_T_including_depot_unload_1166  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_897  1
    load_1_8_18  segment_load_conservation_1112  1
    load_1_8_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_899  -25
    arc_1_8_19  connected_order_arc_900  -13
    arc_1_8_19  out_degree_1108  1
    arc_1_8_19  in_degree_1158  1
    arc_1_8_19  original_T_including_depot_unload_1166  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_899  1
    load_1_8_19  segment_load_conservation_1112  1
    load_1_8_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_901  -25
    arc_1_12_0  depot_return_or_bypass_1086  1
    arc_1_12_0  out_degree_1115  1
    arc_1_12_0  original_T_including_depot_unload_1166  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_901  1
    load_1_12_0  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_902  -25
    arc_1_12_5  connected_order_arc_903  -13
    arc_1_12_5  in_degree_1088  1
    arc_1_12_5  out_degree_1115  1
    arc_1_12_5  original_T_including_depot_unload_1166  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_902  1
    load_1_12_5  segment_load_conservation_1091  -1
    load_1_12_5  segment_prefix_lb_1092  1
    load_1_12_5  segment_prefix_ub_1093  1
    load_1_12_5  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_904  -25
    arc_1_12_6  connected_order_arc_905  -13
    arc_1_12_6  in_degree_1095  1
    arc_1_12_6  out_degree_1115  1
    arc_1_12_6  original_T_including_depot_unload_1166  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_904  1
    load_1_12_6  segment_load_conservation_1098  -1
    load_1_12_6  segment_prefix_lb_1099  1
    load_1_12_6  segment_prefix_ub_1100  1
    load_1_12_6  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_906  -25
    arc_1_12_7  connected_order_arc_907  -13
    arc_1_12_7  in_degree_1102  1
    arc_1_12_7  out_degree_1115  1
    arc_1_12_7  original_T_including_depot_unload_1166  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_906  1
    load_1_12_7  segment_load_conservation_1105  -1
    load_1_12_7  segment_prefix_lb_1106  1
    load_1_12_7  segment_prefix_ub_1107  1
    load_1_12_7  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_908  -25
    arc_1_12_8  connected_order_arc_909  -13
    arc_1_12_8  in_degree_1109  1
    arc_1_12_8  out_degree_1115  1
    arc_1_12_8  original_T_including_depot_unload_1166  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_908  1
    load_1_12_8  segment_load_conservation_1112  -1
    load_1_12_8  segment_prefix_lb_1113  1
    load_1_12_8  segment_prefix_ub_1114  1
    load_1_12_8  free_load_conservation_1120  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_910  -25
    arc_1_12_13  connected_order_arc_911  -13
    arc_1_12_13  out_degree_1115  1
    arc_1_12_13  in_degree_1122  1
    arc_1_12_13  original_T_including_depot_unload_1166  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_910  1
    load_1_12_13  free_load_conservation_1120  1
    load_1_12_13  free_load_conservation_1126  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_912  -25
    arc_1_12_14  connected_order_arc_913  -13
    arc_1_12_14  out_degree_1115  1
    arc_1_12_14  in_degree_1128  1
    arc_1_12_14  original_T_including_depot_unload_1166  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_912  1
    load_1_12_14  free_load_conservation_1120  1
    load_1_12_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_914  -25
    arc_1_12_15  connected_order_arc_915  -13
    arc_1_12_15  out_degree_1115  1
    arc_1_12_15  in_degree_1134  1
    arc_1_12_15  original_T_including_depot_unload_1166  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_914  1
    load_1_12_15  free_load_conservation_1120  1
    load_1_12_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_916  -25
    arc_1_12_16  connected_order_arc_917  -13
    arc_1_12_16  out_degree_1115  1
    arc_1_12_16  in_degree_1140  1
    arc_1_12_16  original_T_including_depot_unload_1166  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_916  1
    load_1_12_16  free_load_conservation_1120  1
    load_1_12_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_918  -25
    arc_1_12_17  connected_order_arc_919  -13
    arc_1_12_17  out_degree_1115  1
    arc_1_12_17  in_degree_1146  1
    arc_1_12_17  original_T_including_depot_unload_1166  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_918  1
    load_1_12_17  free_load_conservation_1120  1
    load_1_12_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_920  -25
    arc_1_12_18  connected_order_arc_921  -13
    arc_1_12_18  out_degree_1115  1
    arc_1_12_18  in_degree_1152  1
    arc_1_12_18  original_T_including_depot_unload_1166  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_920  1
    load_1_12_18  free_load_conservation_1120  1
    load_1_12_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_922  -25
    arc_1_12_19  connected_order_arc_923  -13
    arc_1_12_19  out_degree_1115  1
    arc_1_12_19  in_degree_1158  1
    arc_1_12_19  original_T_including_depot_unload_1166  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_922  1
    load_1_12_19  free_load_conservation_1120  1
    load_1_12_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_924  -25
    arc_1_13_0  depot_return_or_bypass_1086  1
    arc_1_13_0  out_degree_1121  1
    arc_1_13_0  original_T_including_depot_unload_1166  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_924  1
    load_1_13_0  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_925  -25
    arc_1_13_5  connected_order_arc_926  -13
    arc_1_13_5  in_degree_1088  1
    arc_1_13_5  out_degree_1121  1
    arc_1_13_5  original_T_including_depot_unload_1166  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_925  1
    load_1_13_5  segment_load_conservation_1091  -1
    load_1_13_5  segment_prefix_lb_1092  1
    load_1_13_5  segment_prefix_ub_1093  1
    load_1_13_5  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_927  -25
    arc_1_13_6  connected_order_arc_928  -13
    arc_1_13_6  in_degree_1095  1
    arc_1_13_6  out_degree_1121  1
    arc_1_13_6  original_T_including_depot_unload_1166  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_927  1
    load_1_13_6  segment_load_conservation_1098  -1
    load_1_13_6  segment_prefix_lb_1099  1
    load_1_13_6  segment_prefix_ub_1100  1
    load_1_13_6  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_929  -25
    arc_1_13_7  connected_order_arc_930  -13
    arc_1_13_7  in_degree_1102  1
    arc_1_13_7  out_degree_1121  1
    arc_1_13_7  original_T_including_depot_unload_1166  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_929  1
    load_1_13_7  segment_load_conservation_1105  -1
    load_1_13_7  segment_prefix_lb_1106  1
    load_1_13_7  segment_prefix_ub_1107  1
    load_1_13_7  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_931  -25
    arc_1_13_8  connected_order_arc_932  -13
    arc_1_13_8  in_degree_1109  1
    arc_1_13_8  out_degree_1121  1
    arc_1_13_8  original_T_including_depot_unload_1166  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_931  1
    load_1_13_8  segment_load_conservation_1112  -1
    load_1_13_8  segment_prefix_lb_1113  1
    load_1_13_8  segment_prefix_ub_1114  1
    load_1_13_8  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_933  -25
    arc_1_13_12  connected_order_arc_934  -13
    arc_1_13_12  in_degree_1116  1
    arc_1_13_12  out_degree_1121  1
    arc_1_13_12  original_T_including_depot_unload_1166  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_933  1
    load_1_13_12  free_load_conservation_1120  -1
    load_1_13_12  free_load_conservation_1126  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_935  -25
    arc_1_13_14  connected_order_arc_936  -13
    arc_1_13_14  out_degree_1121  1
    arc_1_13_14  in_degree_1128  1
    arc_1_13_14  original_T_including_depot_unload_1166  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_935  1
    load_1_13_14  free_load_conservation_1126  1
    load_1_13_14  free_load_conservation_1132  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_937  -25
    arc_1_13_15  connected_order_arc_938  -13
    arc_1_13_15  out_degree_1121  1
    arc_1_13_15  in_degree_1134  1
    arc_1_13_15  original_T_including_depot_unload_1166  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_937  1
    load_1_13_15  free_load_conservation_1126  1
    load_1_13_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_939  -25
    arc_1_13_16  connected_order_arc_940  -13
    arc_1_13_16  out_degree_1121  1
    arc_1_13_16  in_degree_1140  1
    arc_1_13_16  original_T_including_depot_unload_1166  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_939  1
    load_1_13_16  free_load_conservation_1126  1
    load_1_13_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_941  -25
    arc_1_13_17  connected_order_arc_942  -13
    arc_1_13_17  out_degree_1121  1
    arc_1_13_17  in_degree_1146  1
    arc_1_13_17  original_T_including_depot_unload_1166  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_941  1
    load_1_13_17  free_load_conservation_1126  1
    load_1_13_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_943  -25
    arc_1_13_18  connected_order_arc_944  -13
    arc_1_13_18  out_degree_1121  1
    arc_1_13_18  in_degree_1152  1
    arc_1_13_18  original_T_including_depot_unload_1166  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_943  1
    load_1_13_18  free_load_conservation_1126  1
    load_1_13_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_945  -25
    arc_1_13_19  connected_order_arc_946  -13
    arc_1_13_19  out_degree_1121  1
    arc_1_13_19  in_degree_1158  1
    arc_1_13_19  original_T_including_depot_unload_1166  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_945  1
    load_1_13_19  free_load_conservation_1126  1
    load_1_13_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_947  -25
    arc_1_14_0  depot_return_or_bypass_1086  1
    arc_1_14_0  out_degree_1127  1
    arc_1_14_0  original_T_including_depot_unload_1166  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_947  1
    load_1_14_0  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_948  -25
    arc_1_14_5  connected_order_arc_949  -13
    arc_1_14_5  in_degree_1088  1
    arc_1_14_5  out_degree_1127  1
    arc_1_14_5  original_T_including_depot_unload_1166  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_948  1
    load_1_14_5  segment_load_conservation_1091  -1
    load_1_14_5  segment_prefix_lb_1092  1
    load_1_14_5  segment_prefix_ub_1093  1
    load_1_14_5  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_950  -25
    arc_1_14_6  connected_order_arc_951  -13
    arc_1_14_6  in_degree_1095  1
    arc_1_14_6  out_degree_1127  1
    arc_1_14_6  original_T_including_depot_unload_1166  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_950  1
    load_1_14_6  segment_load_conservation_1098  -1
    load_1_14_6  segment_prefix_lb_1099  1
    load_1_14_6  segment_prefix_ub_1100  1
    load_1_14_6  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_952  -25
    arc_1_14_7  connected_order_arc_953  -13
    arc_1_14_7  in_degree_1102  1
    arc_1_14_7  out_degree_1127  1
    arc_1_14_7  original_T_including_depot_unload_1166  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_952  1
    load_1_14_7  segment_load_conservation_1105  -1
    load_1_14_7  segment_prefix_lb_1106  1
    load_1_14_7  segment_prefix_ub_1107  1
    load_1_14_7  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_954  -25
    arc_1_14_8  connected_order_arc_955  -13
    arc_1_14_8  in_degree_1109  1
    arc_1_14_8  out_degree_1127  1
    arc_1_14_8  original_T_including_depot_unload_1166  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_954  1
    load_1_14_8  segment_load_conservation_1112  -1
    load_1_14_8  segment_prefix_lb_1113  1
    load_1_14_8  segment_prefix_ub_1114  1
    load_1_14_8  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_956  -25
    arc_1_14_12  connected_order_arc_957  -13
    arc_1_14_12  in_degree_1116  1
    arc_1_14_12  out_degree_1127  1
    arc_1_14_12  original_T_including_depot_unload_1166  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_956  1
    load_1_14_12  free_load_conservation_1120  -1
    load_1_14_12  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_958  -25
    arc_1_14_13  connected_order_arc_959  -13
    arc_1_14_13  in_degree_1122  1
    arc_1_14_13  out_degree_1127  1
    arc_1_14_13  original_T_including_depot_unload_1166  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_958  1
    load_1_14_13  free_load_conservation_1126  -1
    load_1_14_13  free_load_conservation_1132  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_960  -25
    arc_1_14_15  connected_order_arc_961  -13
    arc_1_14_15  out_degree_1127  1
    arc_1_14_15  in_degree_1134  1
    arc_1_14_15  original_T_including_depot_unload_1166  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_960  1
    load_1_14_15  free_load_conservation_1132  1
    load_1_14_15  free_load_conservation_1138  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_962  -25
    arc_1_14_16  connected_order_arc_963  -13
    arc_1_14_16  out_degree_1127  1
    arc_1_14_16  in_degree_1140  1
    arc_1_14_16  original_T_including_depot_unload_1166  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_962  1
    load_1_14_16  free_load_conservation_1132  1
    load_1_14_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_964  -25
    arc_1_14_17  connected_order_arc_965  -13
    arc_1_14_17  out_degree_1127  1
    arc_1_14_17  in_degree_1146  1
    arc_1_14_17  original_T_including_depot_unload_1166  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_964  1
    load_1_14_17  free_load_conservation_1132  1
    load_1_14_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_966  -25
    arc_1_14_18  connected_order_arc_967  -13
    arc_1_14_18  out_degree_1127  1
    arc_1_14_18  in_degree_1152  1
    arc_1_14_18  original_T_including_depot_unload_1166  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_966  1
    load_1_14_18  free_load_conservation_1132  1
    load_1_14_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_968  -25
    arc_1_14_19  connected_order_arc_969  -13
    arc_1_14_19  out_degree_1127  1
    arc_1_14_19  in_degree_1158  1
    arc_1_14_19  original_T_including_depot_unload_1166  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_968  1
    load_1_14_19  free_load_conservation_1132  1
    load_1_14_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_970  -25
    arc_1_15_0  depot_return_or_bypass_1086  1
    arc_1_15_0  out_degree_1133  1
    arc_1_15_0  original_T_including_depot_unload_1166  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_970  1
    load_1_15_0  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_971  -25
    arc_1_15_5  connected_order_arc_972  -13
    arc_1_15_5  in_degree_1088  1
    arc_1_15_5  out_degree_1133  1
    arc_1_15_5  original_T_including_depot_unload_1166  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_971  1
    load_1_15_5  segment_load_conservation_1091  -1
    load_1_15_5  segment_prefix_lb_1092  1
    load_1_15_5  segment_prefix_ub_1093  1
    load_1_15_5  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_973  -25
    arc_1_15_6  connected_order_arc_974  -13
    arc_1_15_6  in_degree_1095  1
    arc_1_15_6  out_degree_1133  1
    arc_1_15_6  original_T_including_depot_unload_1166  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_973  1
    load_1_15_6  segment_load_conservation_1098  -1
    load_1_15_6  segment_prefix_lb_1099  1
    load_1_15_6  segment_prefix_ub_1100  1
    load_1_15_6  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_975  -25
    arc_1_15_7  connected_order_arc_976  -13
    arc_1_15_7  in_degree_1102  1
    arc_1_15_7  out_degree_1133  1
    arc_1_15_7  original_T_including_depot_unload_1166  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_975  1
    load_1_15_7  segment_load_conservation_1105  -1
    load_1_15_7  segment_prefix_lb_1106  1
    load_1_15_7  segment_prefix_ub_1107  1
    load_1_15_7  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_977  -25
    arc_1_15_8  connected_order_arc_978  -13
    arc_1_15_8  in_degree_1109  1
    arc_1_15_8  out_degree_1133  1
    arc_1_15_8  original_T_including_depot_unload_1166  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_977  1
    load_1_15_8  segment_load_conservation_1112  -1
    load_1_15_8  segment_prefix_lb_1113  1
    load_1_15_8  segment_prefix_ub_1114  1
    load_1_15_8  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_979  -25
    arc_1_15_12  connected_order_arc_980  -13
    arc_1_15_12  in_degree_1116  1
    arc_1_15_12  out_degree_1133  1
    arc_1_15_12  original_T_including_depot_unload_1166  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_979  1
    load_1_15_12  free_load_conservation_1120  -1
    load_1_15_12  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_981  -25
    arc_1_15_13  connected_order_arc_982  -13
    arc_1_15_13  in_degree_1122  1
    arc_1_15_13  out_degree_1133  1
    arc_1_15_13  original_T_including_depot_unload_1166  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_981  1
    load_1_15_13  free_load_conservation_1126  -1
    load_1_15_13  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_983  -25
    arc_1_15_14  connected_order_arc_984  -13
    arc_1_15_14  in_degree_1128  1
    arc_1_15_14  out_degree_1133  1
    arc_1_15_14  original_T_including_depot_unload_1166  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_983  1
    load_1_15_14  free_load_conservation_1132  -1
    load_1_15_14  free_load_conservation_1138  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_985  -25
    arc_1_15_16  connected_order_arc_986  -13
    arc_1_15_16  out_degree_1133  1
    arc_1_15_16  in_degree_1140  1
    arc_1_15_16  original_T_including_depot_unload_1166  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_985  1
    load_1_15_16  free_load_conservation_1138  1
    load_1_15_16  free_load_conservation_1144  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_987  -25
    arc_1_15_17  connected_order_arc_988  -13
    arc_1_15_17  out_degree_1133  1
    arc_1_15_17  in_degree_1146  1
    arc_1_15_17  original_T_including_depot_unload_1166  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_987  1
    load_1_15_17  free_load_conservation_1138  1
    load_1_15_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_989  -25
    arc_1_15_18  connected_order_arc_990  -13
    arc_1_15_18  out_degree_1133  1
    arc_1_15_18  in_degree_1152  1
    arc_1_15_18  original_T_including_depot_unload_1166  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_989  1
    load_1_15_18  free_load_conservation_1138  1
    load_1_15_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_991  -25
    arc_1_15_19  connected_order_arc_992  -13
    arc_1_15_19  out_degree_1133  1
    arc_1_15_19  in_degree_1158  1
    arc_1_15_19  original_T_including_depot_unload_1166  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_991  1
    load_1_15_19  free_load_conservation_1138  1
    load_1_15_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_993  -25
    arc_1_16_0  depot_return_or_bypass_1086  1
    arc_1_16_0  out_degree_1139  1
    arc_1_16_0  original_T_including_depot_unload_1166  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_993  1
    load_1_16_0  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_994  -25
    arc_1_16_5  connected_order_arc_995  -13
    arc_1_16_5  in_degree_1088  1
    arc_1_16_5  out_degree_1139  1
    arc_1_16_5  original_T_including_depot_unload_1166  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_994  1
    load_1_16_5  segment_load_conservation_1091  -1
    load_1_16_5  segment_prefix_lb_1092  1
    load_1_16_5  segment_prefix_ub_1093  1
    load_1_16_5  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_996  -25
    arc_1_16_6  connected_order_arc_997  -13
    arc_1_16_6  in_degree_1095  1
    arc_1_16_6  out_degree_1139  1
    arc_1_16_6  original_T_including_depot_unload_1166  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_996  1
    load_1_16_6  segment_load_conservation_1098  -1
    load_1_16_6  segment_prefix_lb_1099  1
    load_1_16_6  segment_prefix_ub_1100  1
    load_1_16_6  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_998  -25
    arc_1_16_7  connected_order_arc_999  -13
    arc_1_16_7  in_degree_1102  1
    arc_1_16_7  out_degree_1139  1
    arc_1_16_7  original_T_including_depot_unload_1166  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_998  1
    load_1_16_7  segment_load_conservation_1105  -1
    load_1_16_7  segment_prefix_lb_1106  1
    load_1_16_7  segment_prefix_ub_1107  1
    load_1_16_7  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1000  -25
    arc_1_16_8  connected_order_arc_1001  -13
    arc_1_16_8  in_degree_1109  1
    arc_1_16_8  out_degree_1139  1
    arc_1_16_8  original_T_including_depot_unload_1166  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1000  1
    load_1_16_8  segment_load_conservation_1112  -1
    load_1_16_8  segment_prefix_lb_1113  1
    load_1_16_8  segment_prefix_ub_1114  1
    load_1_16_8  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1002  -25
    arc_1_16_12  connected_order_arc_1003  -13
    arc_1_16_12  in_degree_1116  1
    arc_1_16_12  out_degree_1139  1
    arc_1_16_12  original_T_including_depot_unload_1166  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1002  1
    load_1_16_12  free_load_conservation_1120  -1
    load_1_16_12  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1004  -25
    arc_1_16_13  connected_order_arc_1005  -13
    arc_1_16_13  in_degree_1122  1
    arc_1_16_13  out_degree_1139  1
    arc_1_16_13  original_T_including_depot_unload_1166  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1004  1
    load_1_16_13  free_load_conservation_1126  -1
    load_1_16_13  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1006  -25
    arc_1_16_14  connected_order_arc_1007  -13
    arc_1_16_14  in_degree_1128  1
    arc_1_16_14  out_degree_1139  1
    arc_1_16_14  original_T_including_depot_unload_1166  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1006  1
    load_1_16_14  free_load_conservation_1132  -1
    load_1_16_14  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1008  -25
    arc_1_16_15  connected_order_arc_1009  -13
    arc_1_16_15  in_degree_1134  1
    arc_1_16_15  out_degree_1139  1
    arc_1_16_15  original_T_including_depot_unload_1166  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1008  1
    load_1_16_15  free_load_conservation_1138  -1
    load_1_16_15  free_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1010  -25
    arc_1_16_17  connected_order_arc_1011  -13
    arc_1_16_17  out_degree_1139  1
    arc_1_16_17  in_degree_1146  1
    arc_1_16_17  original_T_including_depot_unload_1166  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1010  1
    load_1_16_17  free_load_conservation_1144  1
    load_1_16_17  free_load_conservation_1150  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1012  -25
    arc_1_16_18  connected_order_arc_1013  -13
    arc_1_16_18  out_degree_1139  1
    arc_1_16_18  in_degree_1152  1
    arc_1_16_18  original_T_including_depot_unload_1166  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1012  1
    load_1_16_18  free_load_conservation_1144  1
    load_1_16_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1014  -25
    arc_1_16_19  connected_order_arc_1015  -13
    arc_1_16_19  out_degree_1139  1
    arc_1_16_19  in_degree_1158  1
    arc_1_16_19  original_T_including_depot_unload_1166  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1014  1
    load_1_16_19  free_load_conservation_1144  1
    load_1_16_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1016  -25
    arc_1_17_0  depot_return_or_bypass_1086  1
    arc_1_17_0  out_degree_1145  1
    arc_1_17_0  original_T_including_depot_unload_1166  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1016  1
    load_1_17_0  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1017  -25
    arc_1_17_5  connected_order_arc_1018  -13
    arc_1_17_5  in_degree_1088  1
    arc_1_17_5  out_degree_1145  1
    arc_1_17_5  original_T_including_depot_unload_1166  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1017  1
    load_1_17_5  segment_load_conservation_1091  -1
    load_1_17_5  segment_prefix_lb_1092  1
    load_1_17_5  segment_prefix_ub_1093  1
    load_1_17_5  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1019  -25
    arc_1_17_6  connected_order_arc_1020  -13
    arc_1_17_6  in_degree_1095  1
    arc_1_17_6  out_degree_1145  1
    arc_1_17_6  original_T_including_depot_unload_1166  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1019  1
    load_1_17_6  segment_load_conservation_1098  -1
    load_1_17_6  segment_prefix_lb_1099  1
    load_1_17_6  segment_prefix_ub_1100  1
    load_1_17_6  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1021  -25
    arc_1_17_7  connected_order_arc_1022  -13
    arc_1_17_7  in_degree_1102  1
    arc_1_17_7  out_degree_1145  1
    arc_1_17_7  original_T_including_depot_unload_1166  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1021  1
    load_1_17_7  segment_load_conservation_1105  -1
    load_1_17_7  segment_prefix_lb_1106  1
    load_1_17_7  segment_prefix_ub_1107  1
    load_1_17_7  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1023  -25
    arc_1_17_8  connected_order_arc_1024  -13
    arc_1_17_8  in_degree_1109  1
    arc_1_17_8  out_degree_1145  1
    arc_1_17_8  original_T_including_depot_unload_1166  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1023  1
    load_1_17_8  segment_load_conservation_1112  -1
    load_1_17_8  segment_prefix_lb_1113  1
    load_1_17_8  segment_prefix_ub_1114  1
    load_1_17_8  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_1025  -25
    arc_1_17_12  connected_order_arc_1026  -13
    arc_1_17_12  in_degree_1116  1
    arc_1_17_12  out_degree_1145  1
    arc_1_17_12  original_T_including_depot_unload_1166  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_1025  1
    load_1_17_12  free_load_conservation_1120  -1
    load_1_17_12  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1027  -25
    arc_1_17_13  connected_order_arc_1028  -13
    arc_1_17_13  in_degree_1122  1
    arc_1_17_13  out_degree_1145  1
    arc_1_17_13  original_T_including_depot_unload_1166  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1027  1
    load_1_17_13  free_load_conservation_1126  -1
    load_1_17_13  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1029  -25
    arc_1_17_14  connected_order_arc_1030  -13
    arc_1_17_14  in_degree_1128  1
    arc_1_17_14  out_degree_1145  1
    arc_1_17_14  original_T_including_depot_unload_1166  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1029  1
    load_1_17_14  free_load_conservation_1132  -1
    load_1_17_14  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1031  -25
    arc_1_17_15  connected_order_arc_1032  -13
    arc_1_17_15  in_degree_1134  1
    arc_1_17_15  out_degree_1145  1
    arc_1_17_15  original_T_including_depot_unload_1166  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1031  1
    load_1_17_15  free_load_conservation_1138  -1
    load_1_17_15  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1033  -25
    arc_1_17_16  connected_order_arc_1034  -13
    arc_1_17_16  in_degree_1140  1
    arc_1_17_16  out_degree_1145  1
    arc_1_17_16  original_T_including_depot_unload_1166  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1033  1
    load_1_17_16  free_load_conservation_1144  -1
    load_1_17_16  free_load_conservation_1150  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1035  -25
    arc_1_17_18  connected_order_arc_1036  -13
    arc_1_17_18  out_degree_1145  1
    arc_1_17_18  in_degree_1152  1
    arc_1_17_18  original_T_including_depot_unload_1166  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1035  1
    load_1_17_18  free_load_conservation_1150  1
    load_1_17_18  free_load_conservation_1156  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1037  -25
    arc_1_17_19  connected_order_arc_1038  -13
    arc_1_17_19  out_degree_1145  1
    arc_1_17_19  in_degree_1158  1
    arc_1_17_19  original_T_including_depot_unload_1166  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1037  1
    load_1_17_19  free_load_conservation_1150  1
    load_1_17_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1039  -25
    arc_1_18_0  depot_return_or_bypass_1086  1
    arc_1_18_0  out_degree_1151  1
    arc_1_18_0  original_T_including_depot_unload_1166  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1039  1
    load_1_18_0  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1040  -25
    arc_1_18_5  connected_order_arc_1041  -13
    arc_1_18_5  in_degree_1088  1
    arc_1_18_5  out_degree_1151  1
    arc_1_18_5  original_T_including_depot_unload_1166  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1040  1
    load_1_18_5  segment_load_conservation_1091  -1
    load_1_18_5  segment_prefix_lb_1092  1
    load_1_18_5  segment_prefix_ub_1093  1
    load_1_18_5  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1042  -25
    arc_1_18_6  connected_order_arc_1043  -13
    arc_1_18_6  in_degree_1095  1
    arc_1_18_6  out_degree_1151  1
    arc_1_18_6  original_T_including_depot_unload_1166  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1042  1
    load_1_18_6  segment_load_conservation_1098  -1
    load_1_18_6  segment_prefix_lb_1099  1
    load_1_18_6  segment_prefix_ub_1100  1
    load_1_18_6  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1044  -25
    arc_1_18_7  connected_order_arc_1045  -13
    arc_1_18_7  in_degree_1102  1
    arc_1_18_7  out_degree_1151  1
    arc_1_18_7  original_T_including_depot_unload_1166  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1044  1
    load_1_18_7  segment_load_conservation_1105  -1
    load_1_18_7  segment_prefix_lb_1106  1
    load_1_18_7  segment_prefix_ub_1107  1
    load_1_18_7  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1046  -25
    arc_1_18_8  connected_order_arc_1047  -13
    arc_1_18_8  in_degree_1109  1
    arc_1_18_8  out_degree_1151  1
    arc_1_18_8  original_T_including_depot_unload_1166  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1046  1
    load_1_18_8  segment_load_conservation_1112  -1
    load_1_18_8  segment_prefix_lb_1113  1
    load_1_18_8  segment_prefix_ub_1114  1
    load_1_18_8  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1048  -25
    arc_1_18_12  connected_order_arc_1049  -13
    arc_1_18_12  in_degree_1116  1
    arc_1_18_12  out_degree_1151  1
    arc_1_18_12  original_T_including_depot_unload_1166  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1048  1
    load_1_18_12  free_load_conservation_1120  -1
    load_1_18_12  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1050  -25
    arc_1_18_13  connected_order_arc_1051  -13
    arc_1_18_13  in_degree_1122  1
    arc_1_18_13  out_degree_1151  1
    arc_1_18_13  original_T_including_depot_unload_1166  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1050  1
    load_1_18_13  free_load_conservation_1126  -1
    load_1_18_13  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1052  -25
    arc_1_18_14  connected_order_arc_1053  -13
    arc_1_18_14  in_degree_1128  1
    arc_1_18_14  out_degree_1151  1
    arc_1_18_14  original_T_including_depot_unload_1166  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1052  1
    load_1_18_14  free_load_conservation_1132  -1
    load_1_18_14  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1054  -25
    arc_1_18_15  connected_order_arc_1055  -13
    arc_1_18_15  in_degree_1134  1
    arc_1_18_15  out_degree_1151  1
    arc_1_18_15  original_T_including_depot_unload_1166  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1054  1
    load_1_18_15  free_load_conservation_1138  -1
    load_1_18_15  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1056  -25
    arc_1_18_16  connected_order_arc_1057  -13
    arc_1_18_16  in_degree_1140  1
    arc_1_18_16  out_degree_1151  1
    arc_1_18_16  original_T_including_depot_unload_1166  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1056  1
    load_1_18_16  free_load_conservation_1144  -1
    load_1_18_16  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1058  -25
    arc_1_18_17  connected_order_arc_1059  -13
    arc_1_18_17  in_degree_1146  1
    arc_1_18_17  out_degree_1151  1
    arc_1_18_17  original_T_including_depot_unload_1166  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1058  1
    load_1_18_17  free_load_conservation_1150  -1
    load_1_18_17  free_load_conservation_1156  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1060  -25
    arc_1_18_19  connected_order_arc_1061  -13
    arc_1_18_19  out_degree_1151  1
    arc_1_18_19  in_degree_1158  1
    arc_1_18_19  original_T_including_depot_unload_1166  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1060  1
    load_1_18_19  free_load_conservation_1156  1
    load_1_18_19  free_load_conservation_1162  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1062  -25
    arc_1_19_0  depot_return_or_bypass_1086  1
    arc_1_19_0  out_degree_1157  1
    arc_1_19_0  original_T_including_depot_unload_1166  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1062  1
    load_1_19_0  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1063  -25
    arc_1_19_5  connected_order_arc_1064  -13
    arc_1_19_5  in_degree_1088  1
    arc_1_19_5  out_degree_1157  1
    arc_1_19_5  original_T_including_depot_unload_1166  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1063  1
    load_1_19_5  segment_load_conservation_1091  -1
    load_1_19_5  segment_prefix_lb_1092  1
    load_1_19_5  segment_prefix_ub_1093  1
    load_1_19_5  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1065  -25
    arc_1_19_6  connected_order_arc_1066  -13
    arc_1_19_6  in_degree_1095  1
    arc_1_19_6  out_degree_1157  1
    arc_1_19_6  original_T_including_depot_unload_1166  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1065  1
    load_1_19_6  segment_load_conservation_1098  -1
    load_1_19_6  segment_prefix_lb_1099  1
    load_1_19_6  segment_prefix_ub_1100  1
    load_1_19_6  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1067  -25
    arc_1_19_7  connected_order_arc_1068  -13
    arc_1_19_7  in_degree_1102  1
    arc_1_19_7  out_degree_1157  1
    arc_1_19_7  original_T_including_depot_unload_1166  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1067  1
    load_1_19_7  segment_load_conservation_1105  -1
    load_1_19_7  segment_prefix_lb_1106  1
    load_1_19_7  segment_prefix_ub_1107  1
    load_1_19_7  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1069  -25
    arc_1_19_8  connected_order_arc_1070  -13
    arc_1_19_8  in_degree_1109  1
    arc_1_19_8  out_degree_1157  1
    arc_1_19_8  original_T_including_depot_unload_1166  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1069  1
    load_1_19_8  segment_load_conservation_1112  -1
    load_1_19_8  segment_prefix_lb_1113  1
    load_1_19_8  segment_prefix_ub_1114  1
    load_1_19_8  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_1071  -25
    arc_1_19_12  connected_order_arc_1072  -13
    arc_1_19_12  in_degree_1116  1
    arc_1_19_12  out_degree_1157  1
    arc_1_19_12  original_T_including_depot_unload_1166  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_1071  1
    load_1_19_12  free_load_conservation_1120  -1
    load_1_19_12  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1073  -25
    arc_1_19_13  connected_order_arc_1074  -13
    arc_1_19_13  in_degree_1122  1
    arc_1_19_13  out_degree_1157  1
    arc_1_19_13  original_T_including_depot_unload_1166  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1073  1
    load_1_19_13  free_load_conservation_1126  -1
    load_1_19_13  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1075  -25
    arc_1_19_14  connected_order_arc_1076  -13
    arc_1_19_14  in_degree_1128  1
    arc_1_19_14  out_degree_1157  1
    arc_1_19_14  original_T_including_depot_unload_1166  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1075  1
    load_1_19_14  free_load_conservation_1132  -1
    load_1_19_14  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1077  -25
    arc_1_19_15  connected_order_arc_1078  -13
    arc_1_19_15  in_degree_1134  1
    arc_1_19_15  out_degree_1157  1
    arc_1_19_15  original_T_including_depot_unload_1166  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1077  1
    load_1_19_15  free_load_conservation_1138  -1
    load_1_19_15  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1079  -25
    arc_1_19_16  connected_order_arc_1080  -13
    arc_1_19_16  in_degree_1140  1
    arc_1_19_16  out_degree_1157  1
    arc_1_19_16  original_T_including_depot_unload_1166  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1079  1
    load_1_19_16  free_load_conservation_1144  -1
    load_1_19_16  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1081  -25
    arc_1_19_17  connected_order_arc_1082  -13
    arc_1_19_17  in_degree_1146  1
    arc_1_19_17  out_degree_1157  1
    arc_1_19_17  original_T_including_depot_unload_1166  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1081  1
    load_1_19_17  free_load_conservation_1150  -1
    load_1_19_17  free_load_conservation_1162  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1083  -25
    arc_1_19_18  connected_order_arc_1084  -13
    arc_1_19_18  in_degree_1152  1
    arc_1_19_18  out_degree_1157  1
    arc_1_19_18  original_T_including_depot_unload_1166  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1083  1
    load_1_19_18  free_load_conservation_1156  -1
    load_1_19_18  free_load_conservation_1162  1
    visit_2_9  out_degree_1412  -1
    visit_2_9  in_degree_1413  -1
    visit_2_9  order_active_lb_1414  -1
    visit_2_9  order_active_ub_1415  -11
    order_2_9  connected_order_arc_1181  -1
    order_2_9  connected_order_arc_1183  -1
    order_2_9  connected_order_arc_1185  -1
    order_2_9  connected_order_arc_1187  -1
    order_2_9  connected_order_arc_1189  -1
    order_2_9  connected_order_arc_1191  -1
    order_2_9  connected_order_arc_1193  -1
    order_2_9  connected_order_arc_1195  -1
    order_2_9  connected_order_arc_1197  -1
    order_2_9  connected_order_arc_1199  -1
    order_2_9  connected_order_arc_1202  1
    order_2_9  connected_order_arc_1223  1
    order_2_9  connected_order_arc_1244  1
    order_2_9  connected_order_arc_1265  1
    order_2_9  connected_order_arc_1286  1
    order_2_9  connected_order_arc_1307  1
    order_2_9  connected_order_arc_1328  1
    order_2_9  connected_order_arc_1349  1
    order_2_9  connected_order_arc_1370  1
    order_2_9  connected_order_arc_1391  1
    order_2_9  order_active_lb_1414  1
    order_2_9  order_active_ub_1415  1
    order_2_9  fixed_segment_relative_order_1481  -1
    visit_2_10  out_degree_1419  -1
    visit_2_10  in_degree_1420  -1
    visit_2_10  order_active_lb_1421  -1
    visit_2_10  order_active_ub_1422  -11
    order_2_10  connected_order_arc_1181  1
    order_2_10  connected_order_arc_1202  -1
    order_2_10  connected_order_arc_1204  -1
    order_2_10  connected_order_arc_1206  -1
    order_2_10  connected_order_arc_1208  -1
    order_2_10  connected_order_arc_1210  -1
    order_2_10  connected_order_arc_1212  -1
    order_2_10  connected_order_arc_1214  -1
    order_2_10  connected_order_arc_1216  -1
    order_2_10  connected_order_arc_1218  -1
    order_2_10  connected_order_arc_1220  -1
    order_2_10  connected_order_arc_1225  1
    order_2_10  connected_order_arc_1246  1
    order_2_10  connected_order_arc_1267  1
    order_2_10  connected_order_arc_1288  1
    order_2_10  connected_order_arc_1309  1
    order_2_10  connected_order_arc_1330  1
    order_2_10  connected_order_arc_1351  1
    order_2_10  connected_order_arc_1372  1
    order_2_10  connected_order_arc_1393  1
    order_2_10  order_active_lb_1421  1
    order_2_10  order_active_ub_1422  1
    order_2_10  fixed_segment_relative_order_1481  1
    order_2_10  fixed_segment_relative_order_1482  -1
    visit_2_11  out_degree_1426  -1
    visit_2_11  in_degree_1427  -1
    visit_2_11  order_active_lb_1428  -1
    visit_2_11  order_active_ub_1429  -11
    order_2_11  connected_order_arc_1183  1
    order_2_11  connected_order_arc_1204  1
    order_2_11  connected_order_arc_1223  -1
    order_2_11  connected_order_arc_1225  -1
    order_2_11  connected_order_arc_1227  -1
    order_2_11  connected_order_arc_1229  -1
    order_2_11  connected_order_arc_1231  -1
    order_2_11  connected_order_arc_1233  -1
    order_2_11  connected_order_arc_1235  -1
    order_2_11  connected_order_arc_1237  -1
    order_2_11  connected_order_arc_1239  -1
    order_2_11  connected_order_arc_1241  -1
    order_2_11  connected_order_arc_1248  1
    order_2_11  connected_order_arc_1269  1
    order_2_11  connected_order_arc_1290  1
    order_2_11  connected_order_arc_1311  1
    order_2_11  connected_order_arc_1332  1
    order_2_11  connected_order_arc_1353  1
    order_2_11  connected_order_arc_1374  1
    order_2_11  connected_order_arc_1395  1
    order_2_11  order_active_lb_1428  1
    order_2_11  order_active_ub_1429  1
    order_2_11  fixed_segment_relative_order_1482  1
    visit_2_12  out_degree_1433  -1
    visit_2_12  in_degree_1434  -1
    visit_2_12  order_active_lb_1435  -1
    visit_2_12  order_active_ub_1436  -11
    visit_2_12  service_visit_def_1437  -1
    order_2_12  connected_order_arc_1185  1
    order_2_12  connected_order_arc_1206  1
    order_2_12  connected_order_arc_1227  1
    order_2_12  connected_order_arc_1244  -1
    order_2_12  connected_order_arc_1246  -1
    order_2_12  connected_order_arc_1248  -1
    order_2_12  connected_order_arc_1250  -1
    order_2_12  connected_order_arc_1252  -1
    order_2_12  connected_order_arc_1254  -1
    order_2_12  connected_order_arc_1256  -1
    order_2_12  connected_order_arc_1258  -1
    order_2_12  connected_order_arc_1260  -1
    order_2_12  connected_order_arc_1262  -1
    order_2_12  connected_order_arc_1271  1
    order_2_12  connected_order_arc_1292  1
    order_2_12  connected_order_arc_1313  1
    order_2_12  connected_order_arc_1334  1
    order_2_12  connected_order_arc_1355  1
    order_2_12  connected_order_arc_1376  1
    order_2_12  connected_order_arc_1397  1
    order_2_12  order_active_lb_1435  1
    order_2_12  order_active_ub_1436  1
    visit_2_13  out_degree_1439  -1
    visit_2_13  in_degree_1440  -1
    visit_2_13  order_active_lb_1441  -1
    visit_2_13  order_active_ub_1442  -11
    visit_2_13  service_visit_def_1443  -1
    order_2_13  connected_order_arc_1187  1
    order_2_13  connected_order_arc_1208  1
    order_2_13  connected_order_arc_1229  1
    order_2_13  connected_order_arc_1250  1
    order_2_13  connected_order_arc_1265  -1
    order_2_13  connected_order_arc_1267  -1
    order_2_13  connected_order_arc_1269  -1
    order_2_13  connected_order_arc_1271  -1
    order_2_13  connected_order_arc_1273  -1
    order_2_13  connected_order_arc_1275  -1
    order_2_13  connected_order_arc_1277  -1
    order_2_13  connected_order_arc_1279  -1
    order_2_13  connected_order_arc_1281  -1
    order_2_13  connected_order_arc_1283  -1
    order_2_13  connected_order_arc_1294  1
    order_2_13  connected_order_arc_1315  1
    order_2_13  connected_order_arc_1336  1
    order_2_13  connected_order_arc_1357  1
    order_2_13  connected_order_arc_1378  1
    order_2_13  connected_order_arc_1399  1
    order_2_13  order_active_lb_1441  1
    order_2_13  order_active_ub_1442  1
    visit_2_14  out_degree_1445  -1
    visit_2_14  in_degree_1446  -1
    visit_2_14  order_active_lb_1447  -1
    visit_2_14  order_active_ub_1448  -11
    visit_2_14  service_visit_def_1449  -1
    order_2_14  connected_order_arc_1189  1
    order_2_14  connected_order_arc_1210  1
    order_2_14  connected_order_arc_1231  1
    order_2_14  connected_order_arc_1252  1
    order_2_14  connected_order_arc_1273  1
    order_2_14  connected_order_arc_1286  -1
    order_2_14  connected_order_arc_1288  -1
    order_2_14  connected_order_arc_1290  -1
    order_2_14  connected_order_arc_1292  -1
    order_2_14  connected_order_arc_1294  -1
    order_2_14  connected_order_arc_1296  -1
    order_2_14  connected_order_arc_1298  -1
    order_2_14  connected_order_arc_1300  -1
    order_2_14  connected_order_arc_1302  -1
    order_2_14  connected_order_arc_1304  -1
    order_2_14  connected_order_arc_1317  1
    order_2_14  connected_order_arc_1338  1
    order_2_14  connected_order_arc_1359  1
    order_2_14  connected_order_arc_1380  1
    order_2_14  connected_order_arc_1401  1
    order_2_14  order_active_lb_1447  1
    order_2_14  order_active_ub_1448  1
    visit_2_15  out_degree_1451  -1
    visit_2_15  in_degree_1452  -1
    visit_2_15  order_active_lb_1453  -1
    visit_2_15  order_active_ub_1454  -11
    visit_2_15  service_visit_def_1455  -1
    order_2_15  connected_order_arc_1191  1
    order_2_15  connected_order_arc_1212  1
    order_2_15  connected_order_arc_1233  1
    order_2_15  connected_order_arc_1254  1
    order_2_15  connected_order_arc_1275  1
    order_2_15  connected_order_arc_1296  1
    order_2_15  connected_order_arc_1307  -1
    order_2_15  connected_order_arc_1309  -1
    order_2_15  connected_order_arc_1311  -1
    order_2_15  connected_order_arc_1313  -1
    order_2_15  connected_order_arc_1315  -1
    order_2_15  connected_order_arc_1317  -1
    order_2_15  connected_order_arc_1319  -1
    order_2_15  connected_order_arc_1321  -1
    order_2_15  connected_order_arc_1323  -1
    order_2_15  connected_order_arc_1325  -1
    order_2_15  connected_order_arc_1340  1
    order_2_15  connected_order_arc_1361  1
    order_2_15  connected_order_arc_1382  1
    order_2_15  connected_order_arc_1403  1
    order_2_15  order_active_lb_1453  1
    order_2_15  order_active_ub_1454  1
    visit_2_16  out_degree_1457  -1
    visit_2_16  in_degree_1458  -1
    visit_2_16  order_active_lb_1459  -1
    visit_2_16  order_active_ub_1460  -11
    visit_2_16  service_visit_def_1461  -1
    order_2_16  connected_order_arc_1193  1
    order_2_16  connected_order_arc_1214  1
    order_2_16  connected_order_arc_1235  1
    order_2_16  connected_order_arc_1256  1
    order_2_16  connected_order_arc_1277  1
    order_2_16  connected_order_arc_1298  1
    order_2_16  connected_order_arc_1319  1
    order_2_16  connected_order_arc_1328  -1
    order_2_16  connected_order_arc_1330  -1
    order_2_16  connected_order_arc_1332  -1
    order_2_16  connected_order_arc_1334  -1
    order_2_16  connected_order_arc_1336  -1
    order_2_16  connected_order_arc_1338  -1
    order_2_16  connected_order_arc_1340  -1
    order_2_16  connected_order_arc_1342  -1
    order_2_16  connected_order_arc_1344  -1
    order_2_16  connected_order_arc_1346  -1
    order_2_16  connected_order_arc_1363  1
    order_2_16  connected_order_arc_1384  1
    order_2_16  connected_order_arc_1405  1
    order_2_16  order_active_lb_1459  1
    order_2_16  order_active_ub_1460  1
    visit_2_17  out_degree_1463  -1
    visit_2_17  in_degree_1464  -1
    visit_2_17  order_active_lb_1465  -1
    visit_2_17  order_active_ub_1466  -11
    visit_2_17  service_visit_def_1467  -1
    order_2_17  connected_order_arc_1195  1
    order_2_17  connected_order_arc_1216  1
    order_2_17  connected_order_arc_1237  1
    order_2_17  connected_order_arc_1258  1
    order_2_17  connected_order_arc_1279  1
    order_2_17  connected_order_arc_1300  1
    order_2_17  connected_order_arc_1321  1
    order_2_17  connected_order_arc_1342  1
    order_2_17  connected_order_arc_1349  -1
    order_2_17  connected_order_arc_1351  -1
    order_2_17  connected_order_arc_1353  -1
    order_2_17  connected_order_arc_1355  -1
    order_2_17  connected_order_arc_1357  -1
    order_2_17  connected_order_arc_1359  -1
    order_2_17  connected_order_arc_1361  -1
    order_2_17  connected_order_arc_1363  -1
    order_2_17  connected_order_arc_1365  -1
    order_2_17  connected_order_arc_1367  -1
    order_2_17  connected_order_arc_1386  1
    order_2_17  connected_order_arc_1407  1
    order_2_17  order_active_lb_1465  1
    order_2_17  order_active_ub_1466  1
    visit_2_18  out_degree_1469  -1
    visit_2_18  in_degree_1470  -1
    visit_2_18  order_active_lb_1471  -1
    visit_2_18  order_active_ub_1472  -11
    visit_2_18  service_visit_def_1473  -1
    order_2_18  connected_order_arc_1197  1
    order_2_18  connected_order_arc_1218  1
    order_2_18  connected_order_arc_1239  1
    order_2_18  connected_order_arc_1260  1
    order_2_18  connected_order_arc_1281  1
    order_2_18  connected_order_arc_1302  1
    order_2_18  connected_order_arc_1323  1
    order_2_18  connected_order_arc_1344  1
    order_2_18  connected_order_arc_1365  1
    order_2_18  connected_order_arc_1370  -1
    order_2_18  connected_order_arc_1372  -1
    order_2_18  connected_order_arc_1374  -1
    order_2_18  connected_order_arc_1376  -1
    order_2_18  connected_order_arc_1378  -1
    order_2_18  connected_order_arc_1380  -1
    order_2_18  connected_order_arc_1382  -1
    order_2_18  connected_order_arc_1384  -1
    order_2_18  connected_order_arc_1386  -1
    order_2_18  connected_order_arc_1388  -1
    order_2_18  connected_order_arc_1409  1
    order_2_18  order_active_lb_1471  1
    order_2_18  order_active_ub_1472  1
    visit_2_19  out_degree_1475  -1
    visit_2_19  in_degree_1476  -1
    visit_2_19  order_active_lb_1477  -1
    visit_2_19  order_active_ub_1478  -11
    visit_2_19  service_visit_def_1479  -1
    order_2_19  connected_order_arc_1199  1
    order_2_19  connected_order_arc_1220  1
    order_2_19  connected_order_arc_1241  1
    order_2_19  connected_order_arc_1262  1
    order_2_19  connected_order_arc_1283  1
    order_2_19  connected_order_arc_1304  1
    order_2_19  connected_order_arc_1325  1
    order_2_19  connected_order_arc_1346  1
    order_2_19  connected_order_arc_1367  1
    order_2_19  connected_order_arc_1388  1
    order_2_19  connected_order_arc_1391  -1
    order_2_19  connected_order_arc_1393  -1
    order_2_19  connected_order_arc_1395  -1
    order_2_19  connected_order_arc_1397  -1
    order_2_19  connected_order_arc_1399  -1
    order_2_19  connected_order_arc_1401  -1
    order_2_19  connected_order_arc_1403  -1
    order_2_19  connected_order_arc_1405  -1
    order_2_19  connected_order_arc_1407  -1
    order_2_19  connected_order_arc_1409  -1
    order_2_19  order_active_lb_1477  1
    order_2_19  order_active_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1167  -30
    arc_2_0_0  depot_departure_or_bypass_1410  1
    arc_2_0_0  depot_return_or_bypass_1411  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1168  -30
    arc_2_0_9  depot_departure_or_bypass_1410  1
    arc_2_0_9  in_degree_1413  1
    arc_2_0_9  original_T_including_depot_unload_1483  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1168  1
    load_2_0_9  segment_load_conservation_1416  -1
    load_2_0_9  segment_prefix_lb_1417  1
    load_2_0_9  segment_prefix_ub_1418  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1169  -30
    arc_2_0_10  depot_departure_or_bypass_1410  1
    arc_2_0_10  in_degree_1420  1
    arc_2_0_10  original_T_including_depot_unload_1483  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1169  1
    load_2_0_10  segment_load_conservation_1423  -1
    load_2_0_10  segment_prefix_lb_1424  1
    load_2_0_10  segment_prefix_ub_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1170  -30
    arc_2_0_11  depot_departure_or_bypass_1410  1
    arc_2_0_11  in_degree_1427  1
    arc_2_0_11  original_T_including_depot_unload_1483  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1170  1
    load_2_0_11  segment_load_conservation_1430  -1
    load_2_0_11  segment_prefix_lb_1431  1
    load_2_0_11  segment_prefix_ub_1432  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1171  -30
    arc_2_0_12  depot_departure_or_bypass_1410  1
    arc_2_0_12  in_degree_1434  1
    arc_2_0_12  original_T_including_depot_unload_1483  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1171  1
    load_2_0_12  free_load_conservation_1438  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1172  -30
    arc_2_0_13  depot_departure_or_bypass_1410  1
    arc_2_0_13  in_degree_1440  1
    arc_2_0_13  original_T_including_depot_unload_1483  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1172  1
    load_2_0_13  free_load_conservation_1444  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1173  -30
    arc_2_0_14  depot_departure_or_bypass_1410  1
    arc_2_0_14  in_degree_1446  1
    arc_2_0_14  original_T_including_depot_unload_1483  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1173  1
    load_2_0_14  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1174  -30
    arc_2_0_15  depot_departure_or_bypass_1410  1
    arc_2_0_15  in_degree_1452  1
    arc_2_0_15  original_T_including_depot_unload_1483  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1174  1
    load_2_0_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1175  -30
    arc_2_0_16  depot_departure_or_bypass_1410  1
    arc_2_0_16  in_degree_1458  1
    arc_2_0_16  original_T_including_depot_unload_1483  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1175  1
    load_2_0_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1176  -30
    arc_2_0_17  depot_departure_or_bypass_1410  1
    arc_2_0_17  in_degree_1464  1
    arc_2_0_17  original_T_including_depot_unload_1483  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1176  1
    load_2_0_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1177  -30
    arc_2_0_18  depot_departure_or_bypass_1410  1
    arc_2_0_18  in_degree_1470  1
    arc_2_0_18  original_T_including_depot_unload_1483  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1177  1
    load_2_0_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1178  -30
    arc_2_0_19  depot_departure_or_bypass_1410  1
    arc_2_0_19  in_degree_1476  1
    arc_2_0_19  original_T_including_depot_unload_1483  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1178  1
    load_2_0_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1179  -30
    arc_2_9_0  depot_return_or_bypass_1411  1
    arc_2_9_0  out_degree_1412  1
    arc_2_9_0  original_T_including_depot_unload_1483  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1179  1
    load_2_9_0  segment_load_conservation_1416  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1180  -30
    arc_2_9_10  connected_order_arc_1181  -12
    arc_2_9_10  out_degree_1412  1
    arc_2_9_10  in_degree_1420  1
    arc_2_9_10  original_T_including_depot_unload_1483  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1180  1
    load_2_9_10  segment_load_conservation_1416  1
    load_2_9_10  segment_load_conservation_1423  -1
    load_2_9_10  segment_prefix_lb_1424  1
    load_2_9_10  segment_prefix_ub_1425  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1182  -30
    arc_2_9_11  connected_order_arc_1183  -12
    arc_2_9_11  out_degree_1412  1
    arc_2_9_11  in_degree_1427  1
    arc_2_9_11  original_T_including_depot_unload_1483  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1182  1
    load_2_9_11  segment_load_conservation_1416  1
    load_2_9_11  segment_load_conservation_1430  -1
    load_2_9_11  segment_prefix_lb_1431  1
    load_2_9_11  segment_prefix_ub_1432  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1184  -30
    arc_2_9_12  connected_order_arc_1185  -12
    arc_2_9_12  out_degree_1412  1
    arc_2_9_12  in_degree_1434  1
    arc_2_9_12  original_T_including_depot_unload_1483  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1184  1
    load_2_9_12  segment_load_conservation_1416  1
    load_2_9_12  free_load_conservation_1438  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1186  -30
    arc_2_9_13  connected_order_arc_1187  -12
    arc_2_9_13  out_degree_1412  1
    arc_2_9_13  in_degree_1440  1
    arc_2_9_13  original_T_including_depot_unload_1483  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1186  1
    load_2_9_13  segment_load_conservation_1416  1
    load_2_9_13  free_load_conservation_1444  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1188  -30
    arc_2_9_14  connected_order_arc_1189  -12
    arc_2_9_14  out_degree_1412  1
    arc_2_9_14  in_degree_1446  1
    arc_2_9_14  original_T_including_depot_unload_1483  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1188  1
    load_2_9_14  segment_load_conservation_1416  1
    load_2_9_14  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1190  -30
    arc_2_9_15  connected_order_arc_1191  -12
    arc_2_9_15  out_degree_1412  1
    arc_2_9_15  in_degree_1452  1
    arc_2_9_15  original_T_including_depot_unload_1483  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1190  1
    load_2_9_15  segment_load_conservation_1416  1
    load_2_9_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1192  -30
    arc_2_9_16  connected_order_arc_1193  -12
    arc_2_9_16  out_degree_1412  1
    arc_2_9_16  in_degree_1458  1
    arc_2_9_16  original_T_including_depot_unload_1483  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1192  1
    load_2_9_16  segment_load_conservation_1416  1
    load_2_9_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1194  -30
    arc_2_9_17  connected_order_arc_1195  -12
    arc_2_9_17  out_degree_1412  1
    arc_2_9_17  in_degree_1464  1
    arc_2_9_17  original_T_including_depot_unload_1483  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1194  1
    load_2_9_17  segment_load_conservation_1416  1
    load_2_9_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1196  -30
    arc_2_9_18  connected_order_arc_1197  -12
    arc_2_9_18  out_degree_1412  1
    arc_2_9_18  in_degree_1470  1
    arc_2_9_18  original_T_including_depot_unload_1483  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1196  1
    load_2_9_18  segment_load_conservation_1416  1
    load_2_9_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1198  -30
    arc_2_9_19  connected_order_arc_1199  -12
    arc_2_9_19  out_degree_1412  1
    arc_2_9_19  in_degree_1476  1
    arc_2_9_19  original_T_including_depot_unload_1483  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1198  1
    load_2_9_19  segment_load_conservation_1416  1
    load_2_9_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1200  -30
    arc_2_10_0  depot_return_or_bypass_1411  1
    arc_2_10_0  out_degree_1419  1
    arc_2_10_0  original_T_including_depot_unload_1483  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1200  1
    load_2_10_0  segment_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1201  -30
    arc_2_10_9  connected_order_arc_1202  -12
    arc_2_10_9  in_degree_1413  1
    arc_2_10_9  out_degree_1419  1
    arc_2_10_9  original_T_including_depot_unload_1483  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1201  1
    load_2_10_9  segment_load_conservation_1416  -1
    load_2_10_9  segment_prefix_lb_1417  1
    load_2_10_9  segment_prefix_ub_1418  1
    load_2_10_9  segment_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1203  -30
    arc_2_10_11  connected_order_arc_1204  -12
    arc_2_10_11  out_degree_1419  1
    arc_2_10_11  in_degree_1427  1
    arc_2_10_11  original_T_including_depot_unload_1483  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1203  1
    load_2_10_11  segment_load_conservation_1423  1
    load_2_10_11  segment_load_conservation_1430  -1
    load_2_10_11  segment_prefix_lb_1431  1
    load_2_10_11  segment_prefix_ub_1432  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1205  -30
    arc_2_10_12  connected_order_arc_1206  -12
    arc_2_10_12  out_degree_1419  1
    arc_2_10_12  in_degree_1434  1
    arc_2_10_12  original_T_including_depot_unload_1483  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1205  1
    load_2_10_12  segment_load_conservation_1423  1
    load_2_10_12  free_load_conservation_1438  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1207  -30
    arc_2_10_13  connected_order_arc_1208  -12
    arc_2_10_13  out_degree_1419  1
    arc_2_10_13  in_degree_1440  1
    arc_2_10_13  original_T_including_depot_unload_1483  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1207  1
    load_2_10_13  segment_load_conservation_1423  1
    load_2_10_13  free_load_conservation_1444  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1209  -30
    arc_2_10_14  connected_order_arc_1210  -12
    arc_2_10_14  out_degree_1419  1
    arc_2_10_14  in_degree_1446  1
    arc_2_10_14  original_T_including_depot_unload_1483  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1209  1
    load_2_10_14  segment_load_conservation_1423  1
    load_2_10_14  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1211  -30
    arc_2_10_15  connected_order_arc_1212  -12
    arc_2_10_15  out_degree_1419  1
    arc_2_10_15  in_degree_1452  1
    arc_2_10_15  original_T_including_depot_unload_1483  1.3898988531263665e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1211  1
    load_2_10_15  segment_load_conservation_1423  1
    load_2_10_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1213  -30
    arc_2_10_16  connected_order_arc_1214  -12
    arc_2_10_16  out_degree_1419  1
    arc_2_10_16  in_degree_1458  1
    arc_2_10_16  original_T_including_depot_unload_1483  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1213  1
    load_2_10_16  segment_load_conservation_1423  1
    load_2_10_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1215  -30
    arc_2_10_17  connected_order_arc_1216  -12
    arc_2_10_17  out_degree_1419  1
    arc_2_10_17  in_degree_1464  1
    arc_2_10_17  original_T_including_depot_unload_1483  1.1016218375294079e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1215  1
    load_2_10_17  segment_load_conservation_1423  1
    load_2_10_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1217  -30
    arc_2_10_18  connected_order_arc_1218  -12
    arc_2_10_18  out_degree_1419  1
    arc_2_10_18  in_degree_1470  1
    arc_2_10_18  original_T_including_depot_unload_1483  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1217  1
    load_2_10_18  segment_load_conservation_1423  1
    load_2_10_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1219  -30
    arc_2_10_19  connected_order_arc_1220  -12
    arc_2_10_19  out_degree_1419  1
    arc_2_10_19  in_degree_1476  1
    arc_2_10_19  original_T_including_depot_unload_1483  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1219  1
    load_2_10_19  segment_load_conservation_1423  1
    load_2_10_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1221  -30
    arc_2_11_0  depot_return_or_bypass_1411  1
    arc_2_11_0  out_degree_1426  1
    arc_2_11_0  original_T_including_depot_unload_1483  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1221  1
    load_2_11_0  segment_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1222  -30
    arc_2_11_9  connected_order_arc_1223  -12
    arc_2_11_9  in_degree_1413  1
    arc_2_11_9  out_degree_1426  1
    arc_2_11_9  original_T_including_depot_unload_1483  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1222  1
    load_2_11_9  segment_load_conservation_1416  -1
    load_2_11_9  segment_prefix_lb_1417  1
    load_2_11_9  segment_prefix_ub_1418  1
    load_2_11_9  segment_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1224  -30
    arc_2_11_10  connected_order_arc_1225  -12
    arc_2_11_10  in_degree_1420  1
    arc_2_11_10  out_degree_1426  1
    arc_2_11_10  original_T_including_depot_unload_1483  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1224  1
    load_2_11_10  segment_load_conservation_1423  -1
    load_2_11_10  segment_prefix_lb_1424  1
    load_2_11_10  segment_prefix_ub_1425  1
    load_2_11_10  segment_load_conservation_1430  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1226  -30
    arc_2_11_12  connected_order_arc_1227  -12
    arc_2_11_12  out_degree_1426  1
    arc_2_11_12  in_degree_1434  1
    arc_2_11_12  original_T_including_depot_unload_1483  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1226  1
    load_2_11_12  segment_load_conservation_1430  1
    load_2_11_12  free_load_conservation_1438  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1228  -30
    arc_2_11_13  connected_order_arc_1229  -12
    arc_2_11_13  out_degree_1426  1
    arc_2_11_13  in_degree_1440  1
    arc_2_11_13  original_T_including_depot_unload_1483  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1228  1
    load_2_11_13  segment_load_conservation_1430  1
    load_2_11_13  free_load_conservation_1444  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1230  -30
    arc_2_11_14  connected_order_arc_1231  -12
    arc_2_11_14  out_degree_1426  1
    arc_2_11_14  in_degree_1446  1
    arc_2_11_14  original_T_including_depot_unload_1483  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1230  1
    load_2_11_14  segment_load_conservation_1430  1
    load_2_11_14  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1232  -30
    arc_2_11_15  connected_order_arc_1233  -12
    arc_2_11_15  out_degree_1426  1
    arc_2_11_15  in_degree_1452  1
    arc_2_11_15  original_T_including_depot_unload_1483  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1232  1
    load_2_11_15  segment_load_conservation_1430  1
    load_2_11_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1234  -30
    arc_2_11_16  connected_order_arc_1235  -12
    arc_2_11_16  out_degree_1426  1
    arc_2_11_16  in_degree_1458  1
    arc_2_11_16  original_T_including_depot_unload_1483  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1234  1
    load_2_11_16  segment_load_conservation_1430  1
    load_2_11_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1236  -30
    arc_2_11_17  connected_order_arc_1237  -12
    arc_2_11_17  out_degree_1426  1
    arc_2_11_17  in_degree_1464  1
    arc_2_11_17  original_T_including_depot_unload_1483  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1236  1
    load_2_11_17  segment_load_conservation_1430  1
    load_2_11_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1238  -30
    arc_2_11_18  connected_order_arc_1239  -12
    arc_2_11_18  out_degree_1426  1
    arc_2_11_18  in_degree_1470  1
    arc_2_11_18  original_T_including_depot_unload_1483  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1238  1
    load_2_11_18  segment_load_conservation_1430  1
    load_2_11_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1240  -30
    arc_2_11_19  connected_order_arc_1241  -12
    arc_2_11_19  out_degree_1426  1
    arc_2_11_19  in_degree_1476  1
    arc_2_11_19  original_T_including_depot_unload_1483  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1240  1
    load_2_11_19  segment_load_conservation_1430  1
    load_2_11_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1242  -30
    arc_2_12_0  depot_return_or_bypass_1411  1
    arc_2_12_0  out_degree_1433  1
    arc_2_12_0  original_T_including_depot_unload_1483  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1242  1
    load_2_12_0  free_load_conservation_1438  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1243  -30
    arc_2_12_9  connected_order_arc_1244  -12
    arc_2_12_9  in_degree_1413  1
    arc_2_12_9  out_degree_1433  1
    arc_2_12_9  original_T_including_depot_unload_1483  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1243  1
    load_2_12_9  segment_load_conservation_1416  -1
    load_2_12_9  segment_prefix_lb_1417  1
    load_2_12_9  segment_prefix_ub_1418  1
    load_2_12_9  free_load_conservation_1438  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1245  -30
    arc_2_12_10  connected_order_arc_1246  -12
    arc_2_12_10  in_degree_1420  1
    arc_2_12_10  out_degree_1433  1
    arc_2_12_10  original_T_including_depot_unload_1483  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1245  1
    load_2_12_10  segment_load_conservation_1423  -1
    load_2_12_10  segment_prefix_lb_1424  1
    load_2_12_10  segment_prefix_ub_1425  1
    load_2_12_10  free_load_conservation_1438  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1247  -30
    arc_2_12_11  connected_order_arc_1248  -12
    arc_2_12_11  in_degree_1427  1
    arc_2_12_11  out_degree_1433  1
    arc_2_12_11  original_T_including_depot_unload_1483  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1247  1
    load_2_12_11  segment_load_conservation_1430  -1
    load_2_12_11  segment_prefix_lb_1431  1
    load_2_12_11  segment_prefix_ub_1432  1
    load_2_12_11  free_load_conservation_1438  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1249  -30
    arc_2_12_13  connected_order_arc_1250  -12
    arc_2_12_13  out_degree_1433  1
    arc_2_12_13  in_degree_1440  1
    arc_2_12_13  original_T_including_depot_unload_1483  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1249  1
    load_2_12_13  free_load_conservation_1438  1
    load_2_12_13  free_load_conservation_1444  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1251  -30
    arc_2_12_14  connected_order_arc_1252  -12
    arc_2_12_14  out_degree_1433  1
    arc_2_12_14  in_degree_1446  1
    arc_2_12_14  original_T_including_depot_unload_1483  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1251  1
    load_2_12_14  free_load_conservation_1438  1
    load_2_12_14  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1253  -30
    arc_2_12_15  connected_order_arc_1254  -12
    arc_2_12_15  out_degree_1433  1
    arc_2_12_15  in_degree_1452  1
    arc_2_12_15  original_T_including_depot_unload_1483  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1253  1
    load_2_12_15  free_load_conservation_1438  1
    load_2_12_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1255  -30
    arc_2_12_16  connected_order_arc_1256  -12
    arc_2_12_16  out_degree_1433  1
    arc_2_12_16  in_degree_1458  1
    arc_2_12_16  original_T_including_depot_unload_1483  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1255  1
    load_2_12_16  free_load_conservation_1438  1
    load_2_12_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1257  -30
    arc_2_12_17  connected_order_arc_1258  -12
    arc_2_12_17  out_degree_1433  1
    arc_2_12_17  in_degree_1464  1
    arc_2_12_17  original_T_including_depot_unload_1483  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1257  1
    load_2_12_17  free_load_conservation_1438  1
    load_2_12_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1259  -30
    arc_2_12_18  connected_order_arc_1260  -12
    arc_2_12_18  out_degree_1433  1
    arc_2_12_18  in_degree_1470  1
    arc_2_12_18  original_T_including_depot_unload_1483  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1259  1
    load_2_12_18  free_load_conservation_1438  1
    load_2_12_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1261  -30
    arc_2_12_19  connected_order_arc_1262  -12
    arc_2_12_19  out_degree_1433  1
    arc_2_12_19  in_degree_1476  1
    arc_2_12_19  original_T_including_depot_unload_1483  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1261  1
    load_2_12_19  free_load_conservation_1438  1
    load_2_12_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1263  -30
    arc_2_13_0  depot_return_or_bypass_1411  1
    arc_2_13_0  out_degree_1439  1
    arc_2_13_0  original_T_including_depot_unload_1483  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1263  1
    load_2_13_0  free_load_conservation_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1264  -30
    arc_2_13_9  connected_order_arc_1265  -12
    arc_2_13_9  in_degree_1413  1
    arc_2_13_9  out_degree_1439  1
    arc_2_13_9  original_T_including_depot_unload_1483  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1264  1
    load_2_13_9  segment_load_conservation_1416  -1
    load_2_13_9  segment_prefix_lb_1417  1
    load_2_13_9  segment_prefix_ub_1418  1
    load_2_13_9  free_load_conservation_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1266  -30
    arc_2_13_10  connected_order_arc_1267  -12
    arc_2_13_10  in_degree_1420  1
    arc_2_13_10  out_degree_1439  1
    arc_2_13_10  original_T_including_depot_unload_1483  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1266  1
    load_2_13_10  segment_load_conservation_1423  -1
    load_2_13_10  segment_prefix_lb_1424  1
    load_2_13_10  segment_prefix_ub_1425  1
    load_2_13_10  free_load_conservation_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1268  -30
    arc_2_13_11  connected_order_arc_1269  -12
    arc_2_13_11  in_degree_1427  1
    arc_2_13_11  out_degree_1439  1
    arc_2_13_11  original_T_including_depot_unload_1483  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1268  1
    load_2_13_11  segment_load_conservation_1430  -1
    load_2_13_11  segment_prefix_lb_1431  1
    load_2_13_11  segment_prefix_ub_1432  1
    load_2_13_11  free_load_conservation_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1270  -30
    arc_2_13_12  connected_order_arc_1271  -12
    arc_2_13_12  in_degree_1434  1
    arc_2_13_12  out_degree_1439  1
    arc_2_13_12  original_T_including_depot_unload_1483  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1270  1
    load_2_13_12  free_load_conservation_1438  -1
    load_2_13_12  free_load_conservation_1444  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1272  -30
    arc_2_13_14  connected_order_arc_1273  -12
    arc_2_13_14  out_degree_1439  1
    arc_2_13_14  in_degree_1446  1
    arc_2_13_14  original_T_including_depot_unload_1483  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1272  1
    load_2_13_14  free_load_conservation_1444  1
    load_2_13_14  free_load_conservation_1450  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1274  -30
    arc_2_13_15  connected_order_arc_1275  -12
    arc_2_13_15  out_degree_1439  1
    arc_2_13_15  in_degree_1452  1
    arc_2_13_15  original_T_including_depot_unload_1483  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1274  1
    load_2_13_15  free_load_conservation_1444  1
    load_2_13_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1276  -30
    arc_2_13_16  connected_order_arc_1277  -12
    arc_2_13_16  out_degree_1439  1
    arc_2_13_16  in_degree_1458  1
    arc_2_13_16  original_T_including_depot_unload_1483  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1276  1
    load_2_13_16  free_load_conservation_1444  1
    load_2_13_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1278  -30
    arc_2_13_17  connected_order_arc_1279  -12
    arc_2_13_17  out_degree_1439  1
    arc_2_13_17  in_degree_1464  1
    arc_2_13_17  original_T_including_depot_unload_1483  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1278  1
    load_2_13_17  free_load_conservation_1444  1
    load_2_13_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1280  -30
    arc_2_13_18  connected_order_arc_1281  -12
    arc_2_13_18  out_degree_1439  1
    arc_2_13_18  in_degree_1470  1
    arc_2_13_18  original_T_including_depot_unload_1483  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1280  1
    load_2_13_18  free_load_conservation_1444  1
    load_2_13_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1282  -30
    arc_2_13_19  connected_order_arc_1283  -12
    arc_2_13_19  out_degree_1439  1
    arc_2_13_19  in_degree_1476  1
    arc_2_13_19  original_T_including_depot_unload_1483  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1282  1
    load_2_13_19  free_load_conservation_1444  1
    load_2_13_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1284  -30
    arc_2_14_0  depot_return_or_bypass_1411  1
    arc_2_14_0  out_degree_1445  1
    arc_2_14_0  original_T_including_depot_unload_1483  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1284  1
    load_2_14_0  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1285  -30
    arc_2_14_9  connected_order_arc_1286  -12
    arc_2_14_9  in_degree_1413  1
    arc_2_14_9  out_degree_1445  1
    arc_2_14_9  original_T_including_depot_unload_1483  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1285  1
    load_2_14_9  segment_load_conservation_1416  -1
    load_2_14_9  segment_prefix_lb_1417  1
    load_2_14_9  segment_prefix_ub_1418  1
    load_2_14_9  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1287  -30
    arc_2_14_10  connected_order_arc_1288  -12
    arc_2_14_10  in_degree_1420  1
    arc_2_14_10  out_degree_1445  1
    arc_2_14_10  original_T_including_depot_unload_1483  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1287  1
    load_2_14_10  segment_load_conservation_1423  -1
    load_2_14_10  segment_prefix_lb_1424  1
    load_2_14_10  segment_prefix_ub_1425  1
    load_2_14_10  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1289  -30
    arc_2_14_11  connected_order_arc_1290  -12
    arc_2_14_11  in_degree_1427  1
    arc_2_14_11  out_degree_1445  1
    arc_2_14_11  original_T_including_depot_unload_1483  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1289  1
    load_2_14_11  segment_load_conservation_1430  -1
    load_2_14_11  segment_prefix_lb_1431  1
    load_2_14_11  segment_prefix_ub_1432  1
    load_2_14_11  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1291  -30
    arc_2_14_12  connected_order_arc_1292  -12
    arc_2_14_12  in_degree_1434  1
    arc_2_14_12  out_degree_1445  1
    arc_2_14_12  original_T_including_depot_unload_1483  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1291  1
    load_2_14_12  free_load_conservation_1438  -1
    load_2_14_12  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1293  -30
    arc_2_14_13  connected_order_arc_1294  -12
    arc_2_14_13  in_degree_1440  1
    arc_2_14_13  out_degree_1445  1
    arc_2_14_13  original_T_including_depot_unload_1483  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1293  1
    load_2_14_13  free_load_conservation_1444  -1
    load_2_14_13  free_load_conservation_1450  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1295  -30
    arc_2_14_15  connected_order_arc_1296  -12
    arc_2_14_15  out_degree_1445  1
    arc_2_14_15  in_degree_1452  1
    arc_2_14_15  original_T_including_depot_unload_1483  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1295  1
    load_2_14_15  free_load_conservation_1450  1
    load_2_14_15  free_load_conservation_1456  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1297  -30
    arc_2_14_16  connected_order_arc_1298  -12
    arc_2_14_16  out_degree_1445  1
    arc_2_14_16  in_degree_1458  1
    arc_2_14_16  original_T_including_depot_unload_1483  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1297  1
    load_2_14_16  free_load_conservation_1450  1
    load_2_14_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1299  -30
    arc_2_14_17  connected_order_arc_1300  -12
    arc_2_14_17  out_degree_1445  1
    arc_2_14_17  in_degree_1464  1
    arc_2_14_17  original_T_including_depot_unload_1483  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1299  1
    load_2_14_17  free_load_conservation_1450  1
    load_2_14_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1301  -30
    arc_2_14_18  connected_order_arc_1302  -12
    arc_2_14_18  out_degree_1445  1
    arc_2_14_18  in_degree_1470  1
    arc_2_14_18  original_T_including_depot_unload_1483  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1301  1
    load_2_14_18  free_load_conservation_1450  1
    load_2_14_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1303  -30
    arc_2_14_19  connected_order_arc_1304  -12
    arc_2_14_19  out_degree_1445  1
    arc_2_14_19  in_degree_1476  1
    arc_2_14_19  original_T_including_depot_unload_1483  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1303  1
    load_2_14_19  free_load_conservation_1450  1
    load_2_14_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1305  -30
    arc_2_15_0  depot_return_or_bypass_1411  1
    arc_2_15_0  out_degree_1451  1
    arc_2_15_0  original_T_including_depot_unload_1483  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1305  1
    load_2_15_0  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1306  -30
    arc_2_15_9  connected_order_arc_1307  -12
    arc_2_15_9  in_degree_1413  1
    arc_2_15_9  out_degree_1451  1
    arc_2_15_9  original_T_including_depot_unload_1483  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1306  1
    load_2_15_9  segment_load_conservation_1416  -1
    load_2_15_9  segment_prefix_lb_1417  1
    load_2_15_9  segment_prefix_ub_1418  1
    load_2_15_9  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1308  -30
    arc_2_15_10  connected_order_arc_1309  -12
    arc_2_15_10  in_degree_1420  1
    arc_2_15_10  out_degree_1451  1
    arc_2_15_10  original_T_including_depot_unload_1483  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1308  1
    load_2_15_10  segment_load_conservation_1423  -1
    load_2_15_10  segment_prefix_lb_1424  1
    load_2_15_10  segment_prefix_ub_1425  1
    load_2_15_10  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1310  -30
    arc_2_15_11  connected_order_arc_1311  -12
    arc_2_15_11  in_degree_1427  1
    arc_2_15_11  out_degree_1451  1
    arc_2_15_11  original_T_including_depot_unload_1483  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1310  1
    load_2_15_11  segment_load_conservation_1430  -1
    load_2_15_11  segment_prefix_lb_1431  1
    load_2_15_11  segment_prefix_ub_1432  1
    load_2_15_11  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1312  -30
    arc_2_15_12  connected_order_arc_1313  -12
    arc_2_15_12  in_degree_1434  1
    arc_2_15_12  out_degree_1451  1
    arc_2_15_12  original_T_including_depot_unload_1483  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1312  1
    load_2_15_12  free_load_conservation_1438  -1
    load_2_15_12  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1314  -30
    arc_2_15_13  connected_order_arc_1315  -12
    arc_2_15_13  in_degree_1440  1
    arc_2_15_13  out_degree_1451  1
    arc_2_15_13  original_T_including_depot_unload_1483  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1314  1
    load_2_15_13  free_load_conservation_1444  -1
    load_2_15_13  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1316  -30
    arc_2_15_14  connected_order_arc_1317  -12
    arc_2_15_14  in_degree_1446  1
    arc_2_15_14  out_degree_1451  1
    arc_2_15_14  original_T_including_depot_unload_1483  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1316  1
    load_2_15_14  free_load_conservation_1450  -1
    load_2_15_14  free_load_conservation_1456  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1318  -30
    arc_2_15_16  connected_order_arc_1319  -12
    arc_2_15_16  out_degree_1451  1
    arc_2_15_16  in_degree_1458  1
    arc_2_15_16  original_T_including_depot_unload_1483  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1318  1
    load_2_15_16  free_load_conservation_1456  1
    load_2_15_16  free_load_conservation_1462  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1320  -30
    arc_2_15_17  connected_order_arc_1321  -12
    arc_2_15_17  out_degree_1451  1
    arc_2_15_17  in_degree_1464  1
    arc_2_15_17  original_T_including_depot_unload_1483  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1320  1
    load_2_15_17  free_load_conservation_1456  1
    load_2_15_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1322  -30
    arc_2_15_18  connected_order_arc_1323  -12
    arc_2_15_18  out_degree_1451  1
    arc_2_15_18  in_degree_1470  1
    arc_2_15_18  original_T_including_depot_unload_1483  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1322  1
    load_2_15_18  free_load_conservation_1456  1
    load_2_15_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1324  -30
    arc_2_15_19  connected_order_arc_1325  -12
    arc_2_15_19  out_degree_1451  1
    arc_2_15_19  in_degree_1476  1
    arc_2_15_19  original_T_including_depot_unload_1483  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1324  1
    load_2_15_19  free_load_conservation_1456  1
    load_2_15_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1326  -30
    arc_2_16_0  depot_return_or_bypass_1411  1
    arc_2_16_0  out_degree_1457  1
    arc_2_16_0  original_T_including_depot_unload_1483  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1326  1
    load_2_16_0  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1327  -30
    arc_2_16_9  connected_order_arc_1328  -12
    arc_2_16_9  in_degree_1413  1
    arc_2_16_9  out_degree_1457  1
    arc_2_16_9  original_T_including_depot_unload_1483  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1327  1
    load_2_16_9  segment_load_conservation_1416  -1
    load_2_16_9  segment_prefix_lb_1417  1
    load_2_16_9  segment_prefix_ub_1418  1
    load_2_16_9  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1329  -30
    arc_2_16_10  connected_order_arc_1330  -12
    arc_2_16_10  in_degree_1420  1
    arc_2_16_10  out_degree_1457  1
    arc_2_16_10  original_T_including_depot_unload_1483  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1329  1
    load_2_16_10  segment_load_conservation_1423  -1
    load_2_16_10  segment_prefix_lb_1424  1
    load_2_16_10  segment_prefix_ub_1425  1
    load_2_16_10  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1331  -30
    arc_2_16_11  connected_order_arc_1332  -12
    arc_2_16_11  in_degree_1427  1
    arc_2_16_11  out_degree_1457  1
    arc_2_16_11  original_T_including_depot_unload_1483  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1331  1
    load_2_16_11  segment_load_conservation_1430  -1
    load_2_16_11  segment_prefix_lb_1431  1
    load_2_16_11  segment_prefix_ub_1432  1
    load_2_16_11  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1333  -30
    arc_2_16_12  connected_order_arc_1334  -12
    arc_2_16_12  in_degree_1434  1
    arc_2_16_12  out_degree_1457  1
    arc_2_16_12  original_T_including_depot_unload_1483  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1333  1
    load_2_16_12  free_load_conservation_1438  -1
    load_2_16_12  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1335  -30
    arc_2_16_13  connected_order_arc_1336  -12
    arc_2_16_13  in_degree_1440  1
    arc_2_16_13  out_degree_1457  1
    arc_2_16_13  original_T_including_depot_unload_1483  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1335  1
    load_2_16_13  free_load_conservation_1444  -1
    load_2_16_13  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1337  -30
    arc_2_16_14  connected_order_arc_1338  -12
    arc_2_16_14  in_degree_1446  1
    arc_2_16_14  out_degree_1457  1
    arc_2_16_14  original_T_including_depot_unload_1483  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1337  1
    load_2_16_14  free_load_conservation_1450  -1
    load_2_16_14  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1339  -30
    arc_2_16_15  connected_order_arc_1340  -12
    arc_2_16_15  in_degree_1452  1
    arc_2_16_15  out_degree_1457  1
    arc_2_16_15  original_T_including_depot_unload_1483  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1339  1
    load_2_16_15  free_load_conservation_1456  -1
    load_2_16_15  free_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1341  -30
    arc_2_16_17  connected_order_arc_1342  -12
    arc_2_16_17  out_degree_1457  1
    arc_2_16_17  in_degree_1464  1
    arc_2_16_17  original_T_including_depot_unload_1483  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1341  1
    load_2_16_17  free_load_conservation_1462  1
    load_2_16_17  free_load_conservation_1468  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1343  -30
    arc_2_16_18  connected_order_arc_1344  -12
    arc_2_16_18  out_degree_1457  1
    arc_2_16_18  in_degree_1470  1
    arc_2_16_18  original_T_including_depot_unload_1483  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1343  1
    load_2_16_18  free_load_conservation_1462  1
    load_2_16_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1345  -30
    arc_2_16_19  connected_order_arc_1346  -12
    arc_2_16_19  out_degree_1457  1
    arc_2_16_19  in_degree_1476  1
    arc_2_16_19  original_T_including_depot_unload_1483  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1345  1
    load_2_16_19  free_load_conservation_1462  1
    load_2_16_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1347  -30
    arc_2_17_0  depot_return_or_bypass_1411  1
    arc_2_17_0  out_degree_1463  1
    arc_2_17_0  original_T_including_depot_unload_1483  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1347  1
    load_2_17_0  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1348  -30
    arc_2_17_9  connected_order_arc_1349  -12
    arc_2_17_9  in_degree_1413  1
    arc_2_17_9  out_degree_1463  1
    arc_2_17_9  original_T_including_depot_unload_1483  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1348  1
    load_2_17_9  segment_load_conservation_1416  -1
    load_2_17_9  segment_prefix_lb_1417  1
    load_2_17_9  segment_prefix_ub_1418  1
    load_2_17_9  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1350  -30
    arc_2_17_10  connected_order_arc_1351  -12
    arc_2_17_10  in_degree_1420  1
    arc_2_17_10  out_degree_1463  1
    arc_2_17_10  original_T_including_depot_unload_1483  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1350  1
    load_2_17_10  segment_load_conservation_1423  -1
    load_2_17_10  segment_prefix_lb_1424  1
    load_2_17_10  segment_prefix_ub_1425  1
    load_2_17_10  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1352  -30
    arc_2_17_11  connected_order_arc_1353  -12
    arc_2_17_11  in_degree_1427  1
    arc_2_17_11  out_degree_1463  1
    arc_2_17_11  original_T_including_depot_unload_1483  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1352  1
    load_2_17_11  segment_load_conservation_1430  -1
    load_2_17_11  segment_prefix_lb_1431  1
    load_2_17_11  segment_prefix_ub_1432  1
    load_2_17_11  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1354  -30
    arc_2_17_12  connected_order_arc_1355  -12
    arc_2_17_12  in_degree_1434  1
    arc_2_17_12  out_degree_1463  1
    arc_2_17_12  original_T_including_depot_unload_1483  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1354  1
    load_2_17_12  free_load_conservation_1438  -1
    load_2_17_12  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1356  -30
    arc_2_17_13  connected_order_arc_1357  -12
    arc_2_17_13  in_degree_1440  1
    arc_2_17_13  out_degree_1463  1
    arc_2_17_13  original_T_including_depot_unload_1483  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1356  1
    load_2_17_13  free_load_conservation_1444  -1
    load_2_17_13  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1358  -30
    arc_2_17_14  connected_order_arc_1359  -12
    arc_2_17_14  in_degree_1446  1
    arc_2_17_14  out_degree_1463  1
    arc_2_17_14  original_T_including_depot_unload_1483  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1358  1
    load_2_17_14  free_load_conservation_1450  -1
    load_2_17_14  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1360  -30
    arc_2_17_15  connected_order_arc_1361  -12
    arc_2_17_15  in_degree_1452  1
    arc_2_17_15  out_degree_1463  1
    arc_2_17_15  original_T_including_depot_unload_1483  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1360  1
    load_2_17_15  free_load_conservation_1456  -1
    load_2_17_15  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1362  -30
    arc_2_17_16  connected_order_arc_1363  -12
    arc_2_17_16  in_degree_1458  1
    arc_2_17_16  out_degree_1463  1
    arc_2_17_16  original_T_including_depot_unload_1483  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1362  1
    load_2_17_16  free_load_conservation_1462  -1
    load_2_17_16  free_load_conservation_1468  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1364  -30
    arc_2_17_18  connected_order_arc_1365  -12
    arc_2_17_18  out_degree_1463  1
    arc_2_17_18  in_degree_1470  1
    arc_2_17_18  original_T_including_depot_unload_1483  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1364  1
    load_2_17_18  free_load_conservation_1468  1
    load_2_17_18  free_load_conservation_1474  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1366  -30
    arc_2_17_19  connected_order_arc_1367  -12
    arc_2_17_19  out_degree_1463  1
    arc_2_17_19  in_degree_1476  1
    arc_2_17_19  original_T_including_depot_unload_1483  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1366  1
    load_2_17_19  free_load_conservation_1468  1
    load_2_17_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1368  -30
    arc_2_18_0  depot_return_or_bypass_1411  1
    arc_2_18_0  out_degree_1469  1
    arc_2_18_0  original_T_including_depot_unload_1483  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1368  1
    load_2_18_0  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1369  -30
    arc_2_18_9  connected_order_arc_1370  -12
    arc_2_18_9  in_degree_1413  1
    arc_2_18_9  out_degree_1469  1
    arc_2_18_9  original_T_including_depot_unload_1483  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1369  1
    load_2_18_9  segment_load_conservation_1416  -1
    load_2_18_9  segment_prefix_lb_1417  1
    load_2_18_9  segment_prefix_ub_1418  1
    load_2_18_9  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1371  -30
    arc_2_18_10  connected_order_arc_1372  -12
    arc_2_18_10  in_degree_1420  1
    arc_2_18_10  out_degree_1469  1
    arc_2_18_10  original_T_including_depot_unload_1483  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1371  1
    load_2_18_10  segment_load_conservation_1423  -1
    load_2_18_10  segment_prefix_lb_1424  1
    load_2_18_10  segment_prefix_ub_1425  1
    load_2_18_10  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1373  -30
    arc_2_18_11  connected_order_arc_1374  -12
    arc_2_18_11  in_degree_1427  1
    arc_2_18_11  out_degree_1469  1
    arc_2_18_11  original_T_including_depot_unload_1483  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1373  1
    load_2_18_11  segment_load_conservation_1430  -1
    load_2_18_11  segment_prefix_lb_1431  1
    load_2_18_11  segment_prefix_ub_1432  1
    load_2_18_11  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1375  -30
    arc_2_18_12  connected_order_arc_1376  -12
    arc_2_18_12  in_degree_1434  1
    arc_2_18_12  out_degree_1469  1
    arc_2_18_12  original_T_including_depot_unload_1483  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1375  1
    load_2_18_12  free_load_conservation_1438  -1
    load_2_18_12  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1377  -30
    arc_2_18_13  connected_order_arc_1378  -12
    arc_2_18_13  in_degree_1440  1
    arc_2_18_13  out_degree_1469  1
    arc_2_18_13  original_T_including_depot_unload_1483  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1377  1
    load_2_18_13  free_load_conservation_1444  -1
    load_2_18_13  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1379  -30
    arc_2_18_14  connected_order_arc_1380  -12
    arc_2_18_14  in_degree_1446  1
    arc_2_18_14  out_degree_1469  1
    arc_2_18_14  original_T_including_depot_unload_1483  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1379  1
    load_2_18_14  free_load_conservation_1450  -1
    load_2_18_14  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1381  -30
    arc_2_18_15  connected_order_arc_1382  -12
    arc_2_18_15  in_degree_1452  1
    arc_2_18_15  out_degree_1469  1
    arc_2_18_15  original_T_including_depot_unload_1483  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1381  1
    load_2_18_15  free_load_conservation_1456  -1
    load_2_18_15  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1383  -30
    arc_2_18_16  connected_order_arc_1384  -12
    arc_2_18_16  in_degree_1458  1
    arc_2_18_16  out_degree_1469  1
    arc_2_18_16  original_T_including_depot_unload_1483  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1383  1
    load_2_18_16  free_load_conservation_1462  -1
    load_2_18_16  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1385  -30
    arc_2_18_17  connected_order_arc_1386  -12
    arc_2_18_17  in_degree_1464  1
    arc_2_18_17  out_degree_1469  1
    arc_2_18_17  original_T_including_depot_unload_1483  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1385  1
    load_2_18_17  free_load_conservation_1468  -1
    load_2_18_17  free_load_conservation_1474  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1387  -30
    arc_2_18_19  connected_order_arc_1388  -12
    arc_2_18_19  out_degree_1469  1
    arc_2_18_19  in_degree_1476  1
    arc_2_18_19  original_T_including_depot_unload_1483  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1387  1
    load_2_18_19  free_load_conservation_1474  1
    load_2_18_19  free_load_conservation_1480  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1389  -30
    arc_2_19_0  depot_return_or_bypass_1411  1
    arc_2_19_0  out_degree_1475  1
    arc_2_19_0  original_T_including_depot_unload_1483  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1389  1
    load_2_19_0  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1390  -30
    arc_2_19_9  connected_order_arc_1391  -12
    arc_2_19_9  in_degree_1413  1
    arc_2_19_9  out_degree_1475  1
    arc_2_19_9  original_T_including_depot_unload_1483  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1390  1
    load_2_19_9  segment_load_conservation_1416  -1
    load_2_19_9  segment_prefix_lb_1417  1
    load_2_19_9  segment_prefix_ub_1418  1
    load_2_19_9  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1392  -30
    arc_2_19_10  connected_order_arc_1393  -12
    arc_2_19_10  in_degree_1420  1
    arc_2_19_10  out_degree_1475  1
    arc_2_19_10  original_T_including_depot_unload_1483  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1392  1
    load_2_19_10  segment_load_conservation_1423  -1
    load_2_19_10  segment_prefix_lb_1424  1
    load_2_19_10  segment_prefix_ub_1425  1
    load_2_19_10  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1394  -30
    arc_2_19_11  connected_order_arc_1395  -12
    arc_2_19_11  in_degree_1427  1
    arc_2_19_11  out_degree_1475  1
    arc_2_19_11  original_T_including_depot_unload_1483  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1394  1
    load_2_19_11  segment_load_conservation_1430  -1
    load_2_19_11  segment_prefix_lb_1431  1
    load_2_19_11  segment_prefix_ub_1432  1
    load_2_19_11  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1396  -30
    arc_2_19_12  connected_order_arc_1397  -12
    arc_2_19_12  in_degree_1434  1
    arc_2_19_12  out_degree_1475  1
    arc_2_19_12  original_T_including_depot_unload_1483  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1396  1
    load_2_19_12  free_load_conservation_1438  -1
    load_2_19_12  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1398  -30
    arc_2_19_13  connected_order_arc_1399  -12
    arc_2_19_13  in_degree_1440  1
    arc_2_19_13  out_degree_1475  1
    arc_2_19_13  original_T_including_depot_unload_1483  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1398  1
    load_2_19_13  free_load_conservation_1444  -1
    load_2_19_13  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1400  -30
    arc_2_19_14  connected_order_arc_1401  -12
    arc_2_19_14  in_degree_1446  1
    arc_2_19_14  out_degree_1475  1
    arc_2_19_14  original_T_including_depot_unload_1483  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1400  1
    load_2_19_14  free_load_conservation_1450  -1
    load_2_19_14  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1402  -30
    arc_2_19_15  connected_order_arc_1403  -12
    arc_2_19_15  in_degree_1452  1
    arc_2_19_15  out_degree_1475  1
    arc_2_19_15  original_T_including_depot_unload_1483  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1402  1
    load_2_19_15  free_load_conservation_1456  -1
    load_2_19_15  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1404  -30
    arc_2_19_16  connected_order_arc_1405  -12
    arc_2_19_16  in_degree_1458  1
    arc_2_19_16  out_degree_1475  1
    arc_2_19_16  original_T_including_depot_unload_1483  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1404  1
    load_2_19_16  free_load_conservation_1462  -1
    load_2_19_16  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1406  -30
    arc_2_19_17  connected_order_arc_1407  -12
    arc_2_19_17  in_degree_1464  1
    arc_2_19_17  out_degree_1475  1
    arc_2_19_17  original_T_including_depot_unload_1483  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1406  1
    load_2_19_17  free_load_conservation_1468  -1
    load_2_19_17  free_load_conservation_1480  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1408  -30
    arc_2_19_18  connected_order_arc_1409  -12
    arc_2_19_18  in_degree_1470  1
    arc_2_19_18  out_degree_1475  1
    arc_2_19_18  original_T_including_depot_unload_1483  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1408  1
    load_2_19_18  free_load_conservation_1474  -1
    load_2_19_18  free_load_conservation_1480  1
RHS
    RHS1      OBJ       -5.3175000000000006e-01
    RHS1      onehot_19_18  1
    RHS1      onehot_17_55  1
    RHS1      onehot_31_84  1
    RHS1      onehot_15_121  1
    RHS1      onehot_2_156  1
    RHS1      onehot_13_199  1
    RHS1      onehot_6_224  1
    RHS1      onehot_9_253  1
    RHS1      stock_ub_257  39
    RHS1      parent_nonstrict_scope_258  3.3746954911354421e-01
    RHS1      normalization_315  1
    RHS1      connected_order_arc_440  -12
    RHS1      connected_order_arc_442  -12
    RHS1      connected_order_arc_444  -12
    RHS1      connected_order_arc_446  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_450  -12
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_454  -12
    RHS1      connected_order_arc_456  -12
    RHS1      connected_order_arc_458  -12
    RHS1      connected_order_arc_460  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_465  -12
    RHS1      connected_order_arc_467  -12
    RHS1      connected_order_arc_469  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_473  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_477  -12
    RHS1      connected_order_arc_479  -12
    RHS1      connected_order_arc_481  -12
    RHS1      connected_order_arc_483  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_488  -12
    RHS1      connected_order_arc_490  -12
    RHS1      connected_order_arc_492  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_504  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_511  -12
    RHS1      connected_order_arc_513  -12
    RHS1      connected_order_arc_515  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_527  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_534  -12
    RHS1      connected_order_arc_536  -12
    RHS1      connected_order_arc_538  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_550  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_557  -12
    RHS1      connected_order_arc_559  -12
    RHS1      connected_order_arc_561  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_573  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_580  -12
    RHS1      connected_order_arc_582  -12
    RHS1      connected_order_arc_584  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_596  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_603  -12
    RHS1      connected_order_arc_605  -12
    RHS1      connected_order_arc_607  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_611  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_615  -12
    RHS1      connected_order_arc_617  -12
    RHS1      connected_order_arc_619  -12
    RHS1      connected_order_arc_621  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_626  -12
    RHS1      connected_order_arc_628  -12
    RHS1      connected_order_arc_630  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_634  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_638  -12
    RHS1      connected_order_arc_640  -12
    RHS1      connected_order_arc_642  -12
    RHS1      connected_order_arc_644  -12
    RHS1      connected_order_arc_647  -12
    RHS1      connected_order_arc_649  -12
    RHS1      connected_order_arc_651  -12
    RHS1      connected_order_arc_653  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_657  -12
    RHS1      connected_order_arc_659  -12
    RHS1      connected_order_arc_661  -12
    RHS1      connected_order_arc_663  -12
    RHS1      connected_order_arc_665  -12
    RHS1      connected_order_arc_667  -12
    RHS1      connected_order_arc_670  -12
    RHS1      connected_order_arc_672  -12
    RHS1      connected_order_arc_674  -12
    RHS1      connected_order_arc_676  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_680  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_693  -12
    RHS1      connected_order_arc_695  -12
    RHS1      connected_order_arc_697  -12
    RHS1      connected_order_arc_699  -12
    RHS1      connected_order_arc_701  -12
    RHS1      connected_order_arc_703  -12
    RHS1      connected_order_arc_705  -12
    RHS1      connected_order_arc_707  -12
    RHS1      connected_order_arc_709  -12
    RHS1      connected_order_arc_711  -12
    RHS1      connected_order_arc_713  -12
    RHS1      depot_departure_or_bypass_714  1
    RHS1      depot_return_or_bypass_715  1
    RHS1      segment_load_conservation_720  15
    RHS1      segment_prefix_ub_722  5
    RHS1      segment_load_conservation_727  -8
    RHS1      segment_prefix_lb_728  8
    RHS1      segment_prefix_ub_729  20
    RHS1      segment_load_conservation_734  -4
    RHS1      segment_prefix_lb_735  4
    RHS1      segment_prefix_ub_736  20
    RHS1      segment_load_conservation_741  5
    RHS1      segment_prefix_ub_743  15
    RHS1      fixed_segment_relative_order_792  1
    RHS1      fixed_segment_relative_order_793  1
    RHS1      fixed_segment_relative_order_794  1
    RHS1      original_T_including_depot_unload_795  3.1885372111439337e+03
    RHS1      connected_order_arc_811  -12
    RHS1      connected_order_arc_813  -12
    RHS1      connected_order_arc_815  -12
    RHS1      connected_order_arc_817  -12
    RHS1      connected_order_arc_819  -12
    RHS1      connected_order_arc_821  -12
    RHS1      connected_order_arc_823  -12
    RHS1      connected_order_arc_825  -12
    RHS1      connected_order_arc_827  -12
    RHS1      connected_order_arc_829  -12
    RHS1      connected_order_arc_831  -12
    RHS1      connected_order_arc_834  -12
    RHS1      connected_order_arc_836  -12
    RHS1      connected_order_arc_838  -12
    RHS1      connected_order_arc_840  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_848  -12
    RHS1      connected_order_arc_850  -12
    RHS1      connected_order_arc_852  -12
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      depot_departure_or_bypass_1085  1
    RHS1      depot_return_or_bypass_1086  1
    RHS1      segment_load_conservation_1091  6
    RHS1      segment_prefix_ub_1093  19
    RHS1      segment_load_conservation_1098  -4
    RHS1      segment_prefix_lb_1099  4
    RHS1      segment_prefix_ub_1100  25
    RHS1      segment_load_conservation_1105  4
    RHS1      segment_prefix_lb_1106  2
    RHS1      segment_prefix_ub_1107  21
    RHS1      segment_load_conservation_1112  -6
    RHS1      segment_prefix_lb_1113  6
    RHS1      segment_prefix_ub_1114  25
    RHS1      fixed_segment_relative_order_1163  1
    RHS1      fixed_segment_relative_order_1164  1
    RHS1      fixed_segment_relative_order_1165  1
    RHS1      original_T_including_depot_unload_1166  2.2736280646580772e+03
    RHS1      connected_order_arc_1181  -11
    RHS1      connected_order_arc_1183  -11
    RHS1      connected_order_arc_1185  -11
    RHS1      connected_order_arc_1187  -11
    RHS1      connected_order_arc_1189  -11
    RHS1      connected_order_arc_1191  -11
    RHS1      connected_order_arc_1193  -11
    RHS1      connected_order_arc_1195  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1202  -11
    RHS1      connected_order_arc_1204  -11
    RHS1      connected_order_arc_1206  -11
    RHS1      connected_order_arc_1208  -11
    RHS1      connected_order_arc_1210  -11
    RHS1      connected_order_arc_1212  -11
    RHS1      connected_order_arc_1214  -11
    RHS1      connected_order_arc_1216  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1223  -11
    RHS1      connected_order_arc_1225  -11
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1244  -11
    RHS1      connected_order_arc_1246  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1267  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      depot_departure_or_bypass_1410  1
    RHS1      depot_return_or_bypass_1411  1
    RHS1      segment_load_conservation_1416  1
    RHS1      segment_prefix_ub_1418  27
    RHS1      segment_load_conservation_1423  5
    RHS1      segment_prefix_ub_1425  25
    RHS1      segment_load_conservation_1430  -5
    RHS1      segment_prefix_lb_1431  5
    RHS1      segment_prefix_ub_1432  30
    RHS1      fixed_segment_relative_order_1481  1
    RHS1      fixed_segment_relative_order_1482  1
    RHS1      original_T_including_depot_unload_1483  5.2123517179470655e+03
BOUNDS
 LO BND1      t         2.5178598191512011e-02
 UP BND1      t         4.2501517911396489e-02
 UP BND1      q         5.4596954911354423e-01
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.2501517911396489e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.2501517911396489e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.2501517911396489e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.2501517911396489e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.2501517911396489e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.2501517911396489e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.2501517911396489e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.2501517911396489e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.2501517911396489e-02
 UP BND1      rho_19    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    4.2501517911396489e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    4.2501517911396489e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    4.2501517911396489e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    4.2501517911396489e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    4.2501517911396489e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    4.2501517911396489e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    4.2501517911396489e-02
 BV BND1      x_17_7  
 UP BND1      w_17_7    4.2501517911396489e-02
 BV BND1      x_17_8  
 UP BND1      w_17_8    4.2501517911396489e-02
 BV BND1      x_17_9  
 UP BND1      w_17_9    4.2501517911396489e-02
 BV BND1      x_17_10 
 UP BND1      w_17_10   4.2501517911396489e-02
 BV BND1      x_17_11 
 UP BND1      w_17_11   4.2501517911396489e-02
 BV BND1      x_17_12 
 UP BND1      w_17_12   4.2501517911396489e-02
 BV BND1      x_17_13 
 UP BND1      w_17_13   4.2501517911396489e-02
 BV BND1      x_17_14 
 UP BND1      w_17_14   4.2501517911396489e-02
 BV BND1      x_17_15 
 UP BND1      w_17_15   4.2501517911396489e-02
 BV BND1      x_17_16 
 UP BND1      w_17_16   4.2501517911396489e-02
 UP BND1      rho_17    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2501517911396489e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2501517911396489e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2501517911396489e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2501517911396489e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2501517911396489e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2501517911396489e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2501517911396489e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2501517911396489e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2501517911396489e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2501517911396489e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2501517911396489e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2501517911396489e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2501517911396489e-02
 UP BND1      rho_31    1
 BV BND1      x_15_0  
 UP BND1      w_15_0    4.2501517911396489e-02
 BV BND1      x_15_1  
 UP BND1      w_15_1    4.2501517911396489e-02
 BV BND1      x_15_2  
 UP BND1      w_15_2    4.2501517911396489e-02
 BV BND1      x_15_3  
 UP BND1      w_15_3    4.2501517911396489e-02
 BV BND1      x_15_4  
 UP BND1      w_15_4    4.2501517911396489e-02
 BV BND1      x_15_5  
 UP BND1      w_15_5    4.2501517911396489e-02
 BV BND1      x_15_6  
 UP BND1      w_15_6    4.2501517911396489e-02
 BV BND1      x_15_7  
 UP BND1      w_15_7    4.2501517911396489e-02
 BV BND1      x_15_8  
 UP BND1      w_15_8    4.2501517911396489e-02
 BV BND1      x_15_9  
 UP BND1      w_15_9    4.2501517911396489e-02
 BV BND1      x_15_10 
 UP BND1      w_15_10   4.2501517911396489e-02
 BV BND1      x_15_11 
 UP BND1      w_15_11   4.2501517911396489e-02
 BV BND1      x_15_12 
 UP BND1      w_15_12   4.2501517911396489e-02
 BV BND1      x_15_13 
 UP BND1      w_15_13   4.2501517911396489e-02
 BV BND1      x_15_14 
 UP BND1      w_15_14   4.2501517911396489e-02
 BV BND1      x_15_15 
 UP BND1      w_15_15   4.2501517911396489e-02
 BV BND1      x_15_16 
 UP BND1      w_15_16   4.2501517911396489e-02
 UP BND1      rho_15    1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.2501517911396489e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.2501517911396489e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.2501517911396489e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.2501517911396489e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.2501517911396489e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.2501517911396489e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.2501517911396489e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.2501517911396489e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.2501517911396489e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.2501517911396489e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.2501517911396489e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.2501517911396489e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.2501517911396489e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.2501517911396489e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.2501517911396489e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.2501517911396489e-02
 UP BND1      rho_2     1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.2501517911396489e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.2501517911396489e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.2501517911396489e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.2501517911396489e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.2501517911396489e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.2501517911396489e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.2501517911396489e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.2501517911396489e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.2501517911396489e-02
 BV BND1      x_13_9  
 UP BND1      w_13_9    4.2501517911396489e-02
 BV BND1      x_13_10 
 UP BND1      w_13_10   4.2501517911396489e-02
 BV BND1      x_13_11 
 UP BND1      w_13_11   4.2501517911396489e-02
 BV BND1      x_13_12 
 UP BND1      w_13_12   4.2501517911396489e-02
 BV BND1      x_13_13 
 UP BND1      w_13_13   4.2501517911396489e-02
 BV BND1      x_13_14 
 UP BND1      w_13_14   4.2501517911396489e-02
 BV BND1      x_13_15 
 UP BND1      w_13_15   4.2501517911396489e-02
 BV BND1      x_13_16 
 UP BND1      w_13_16   4.2501517911396489e-02
 BV BND1      x_13_17 
 UP BND1      w_13_17   4.2501517911396489e-02
 BV BND1      x_13_18 
 UP BND1      w_13_18   4.2501517911396489e-02
 BV BND1      x_13_19 
 UP BND1      w_13_19   4.2501517911396489e-02
 UP BND1      rho_13    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.2501517911396489e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.2501517911396489e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.2501517911396489e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.2501517911396489e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.2501517911396489e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.2501517911396489e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.2501517911396489e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.2501517911396489e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.2501517911396489e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.2501517911396489e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.2501517911396489e-02
 UP BND1      rho_6     1
 BV BND1      x_9_0   
 UP BND1      w_9_0     4.2501517911396489e-02
 BV BND1      x_9_1   
 UP BND1      w_9_1     4.2501517911396489e-02
 BV BND1      x_9_2   
 UP BND1      w_9_2     4.2501517911396489e-02
 BV BND1      x_9_3   
 UP BND1      w_9_3     4.2501517911396489e-02
 BV BND1      x_9_4   
 UP BND1      w_9_4     4.2501517911396489e-02
 BV BND1      x_9_5   
 UP BND1      w_9_5     4.2501517911396489e-02
 BV BND1      x_9_6   
 UP BND1      w_9_6     4.2501517911396489e-02
 BV BND1      x_9_7   
 UP BND1      w_9_7     4.2501517911396489e-02
 BV BND1      x_9_8   
 UP BND1      w_9_8     4.2501517911396489e-02
 BV BND1      x_9_9   
 UP BND1      w_9_9     4.2501517911396489e-02
 BV BND1      x_9_10  
 UP BND1      w_9_10    4.2501517911396489e-02
 BV BND1      x_9_11  
 UP BND1      w_9_11    4.2501517911396489e-02
 BV BND1      x_9_12  
 UP BND1      w_9_12    4.2501517911396489e-02
 UP BND1      rho_9     1
 UP BND1      a_19_17   1
 UP BND1      a_19_31   1
 UP BND1      a_19_15   1
 UP BND1      a_19_2    1
 UP BND1      a_19_13   1
 UP BND1      a_19_6    1
 UP BND1      a_19_9    1
 UP BND1      a_17_31   1
 UP BND1      a_17_15   1
 UP BND1      a_17_2    1
 UP BND1      a_17_13   1
 UP BND1      a_17_6    1
 UP BND1      a_17_9    1
 UP BND1      a_31_15   1
 UP BND1      a_31_2    1
 UP BND1      a_31_13   1
 UP BND1      a_31_6    1
 UP BND1      a_31_9    1
 UP BND1      a_15_2    1
 UP BND1      a_15_13   1
 UP BND1      a_15_6    1
 UP BND1      a_15_9    1
 UP BND1      a_2_13    1
 UP BND1      a_2_6     1
 UP BND1      a_2_9     1
 UP BND1      a_13_6    1
 UP BND1      a_13_9    1
 UP BND1      a_6_9     1
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_4
 BV BND1      service_2_17_5
 BV BND1      service_2_17_6
 BV BND1      service_2_17_7
 BV BND1      service_2_17_8
 BV BND1      service_2_17_9
 BV BND1      service_2_17_10
 BV BND1      service_2_17_11
 BV BND1      service_2_17_12
 BV BND1      service_2_17_13
 BV BND1      service_2_17_14
 BV BND1      service_2_17_15
 BV BND1      service_2_17_16
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_15_0
 BV BND1      service_0_15_1
 BV BND1      service_0_15_2
 BV BND1      service_0_15_4
 BV BND1      service_0_15_5
 BV BND1      service_0_15_6
 BV BND1      service_0_15_7
 BV BND1      service_0_15_8
 BV BND1      service_0_15_9
 BV BND1      service_0_15_10
 BV BND1      service_0_15_11
 BV BND1      service_0_15_12
 BV BND1      service_0_15_13
 BV BND1      service_0_15_14
 BV BND1      service_0_15_15
 BV BND1      service_0_15_16
 BV BND1      service_1_15_0
 BV BND1      service_1_15_1
 BV BND1      service_1_15_2
 BV BND1      service_1_15_4
 BV BND1      service_1_15_5
 BV BND1      service_1_15_6
 BV BND1      service_1_15_7
 BV BND1      service_1_15_8
 BV BND1      service_1_15_9
 BV BND1      service_1_15_10
 BV BND1      service_1_15_11
 BV BND1      service_1_15_12
 BV BND1      service_1_15_13
 BV BND1      service_1_15_14
 BV BND1      service_1_15_15
 BV BND1      service_1_15_16
 BV BND1      service_2_15_0
 BV BND1      service_2_15_1
 BV BND1      service_2_15_2
 BV BND1      service_2_15_4
 BV BND1      service_2_15_5
 BV BND1      service_2_15_6
 BV BND1      service_2_15_7
 BV BND1      service_2_15_8
 BV BND1      service_2_15_9
 BV BND1      service_2_15_10
 BV BND1      service_2_15_11
 BV BND1      service_2_15_12
 BV BND1      service_2_15_13
 BV BND1      service_2_15_14
 BV BND1      service_2_15_15
 BV BND1      service_2_15_16
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_5
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_0_13_9
 BV BND1      service_0_13_10
 BV BND1      service_0_13_11
 BV BND1      service_0_13_12
 BV BND1      service_0_13_14
 BV BND1      service_0_13_15
 BV BND1      service_0_13_16
 BV BND1      service_0_13_17
 BV BND1      service_0_13_18
 BV BND1      service_0_13_19
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_5
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_1_13_9
 BV BND1      service_1_13_10
 BV BND1      service_1_13_11
 BV BND1      service_1_13_12
 BV BND1      service_1_13_14
 BV BND1      service_1_13_15
 BV BND1      service_1_13_16
 BV BND1      service_1_13_17
 BV BND1      service_1_13_18
 BV BND1      service_1_13_19
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_5
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_2_13_9
 BV BND1      service_2_13_10
 BV BND1      service_2_13_11
 BV BND1      service_2_13_12
 BV BND1      service_2_13_14
 BV BND1      service_2_13_15
 BV BND1      service_2_13_16
 BV BND1      service_2_13_17
 BV BND1      service_2_13_18
 BV BND1      service_2_13_19
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_2
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_0_9_11
 BV BND1      service_0_9_12
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_2
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_1_9_11
 BV BND1      service_1_9_12
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_2
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_2_9_11
 BV BND1      service_2_9_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
