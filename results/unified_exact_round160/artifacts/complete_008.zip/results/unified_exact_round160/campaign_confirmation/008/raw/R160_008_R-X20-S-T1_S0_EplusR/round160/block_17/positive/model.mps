* Signature: 0x5b36a32486095ce2
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 E  onehot_13_4
 E  normalized_mass_13_5
 E  normalized_ratio_13_6
 G  product_lb_7
 L  product_ub_8
 G  product_lb_9
 L  product_ub_10
 G  product_lb_11
 L  product_ub_12
 G  product_lb_13
 L  product_ub_14
 G  product_lb_15
 L  product_ub_16
 G  product_lb_17
 L  product_ub_18
 G  product_lb_19
 L  product_ub_20
 G  product_lb_21
 L  product_ub_22
 G  product_lb_23
 L  product_ub_24
 G  product_lb_25
 L  product_ub_26
 G  product_lb_27
 L  product_ub_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_14_39
 E  normalized_mass_14_40
 E  normalized_ratio_14_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_18_74
 E  normalized_mass_18_75
 E  normalized_ratio_18_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_17_111
 E  normalized_mass_17_112
 E  normalized_ratio_17_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_11_146
 E  normalized_mass_11_147
 E  normalized_ratio_11_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 E  onehot_12_181
 E  normalized_mass_12_182
 E  normalized_ratio_12_183
 G  product_lb_184
 L  product_ub_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_20_216
 E  normalized_mass_20_217
 E  normalized_ratio_20_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 E  onehot_10_223
 E  normalized_mass_10_224
 E  normalized_ratio_10_225
 G  stock_lb_226
 L  stock_ub_227
 L  parent_nonstrict_scope_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 E  normalization_285
 G  full_original_Gini_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 L  arc_capacity_384
 L  arc_capacity_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 G  connected_order_arc_399
 L  arc_capacity_400
 G  connected_order_arc_401
 L  arc_capacity_402
 G  connected_order_arc_403
 L  arc_capacity_404
 G  connected_order_arc_405
 L  arc_capacity_406
 G  connected_order_arc_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 L  arc_capacity_429
 G  connected_order_arc_430
 L  arc_capacity_431
 G  connected_order_arc_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 G  connected_order_arc_758
 L  arc_capacity_759
 G  connected_order_arc_760
 L  arc_capacity_761
 G  connected_order_arc_762
 L  arc_capacity_763
 G  connected_order_arc_764
 L  arc_capacity_765
 G  connected_order_arc_766
 L  arc_capacity_767
 G  connected_order_arc_768
 L  arc_capacity_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 L  arc_capacity_782
 G  connected_order_arc_783
 L  arc_capacity_784
 G  connected_order_arc_785
 L  arc_capacity_786
 G  connected_order_arc_787
 L  arc_capacity_788
 G  connected_order_arc_789
 L  arc_capacity_790
 G  connected_order_arc_791
 L  arc_capacity_792
 G  connected_order_arc_793
 L  arc_capacity_794
 G  connected_order_arc_795
 L  arc_capacity_796
 G  connected_order_arc_797
 L  arc_capacity_798
 G  connected_order_arc_799
 L  arc_capacity_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 E  depot_departure_or_bypass_893
 E  depot_return_or_bypass_894
 E  out_degree_895
 E  in_degree_896
 G  order_active_lb_897
 L  order_active_ub_898
 E  segment_load_conservation_899
 G  segment_prefix_lb_900
 L  segment_prefix_ub_901
 E  out_degree_902
 E  in_degree_903
 G  order_active_lb_904
 L  order_active_ub_905
 E  segment_load_conservation_906
 G  segment_prefix_lb_907
 L  segment_prefix_ub_908
 E  out_degree_909
 E  in_degree_910
 G  order_active_lb_911
 L  order_active_ub_912
 E  segment_load_conservation_913
 G  segment_prefix_lb_914
 L  segment_prefix_ub_915
 E  out_degree_916
 E  in_degree_917
 G  order_active_lb_918
 L  order_active_ub_919
 E  segment_load_conservation_920
 G  segment_prefix_lb_921
 L  segment_prefix_ub_922
 E  out_degree_923
 E  in_degree_924
 G  order_active_lb_925
 L  order_active_ub_926
 E  segment_load_conservation_927
 G  segment_prefix_lb_928
 L  segment_prefix_ub_929
 E  out_degree_930
 E  in_degree_931
 G  order_active_lb_932
 L  order_active_ub_933
 E  segment_load_conservation_934
 G  segment_prefix_lb_935
 L  segment_prefix_ub_936
 E  out_degree_937
 E  in_degree_938
 G  order_active_lb_939
 L  order_active_ub_940
 E  segment_load_conservation_941
 G  segment_prefix_lb_942
 L  segment_prefix_ub_943
 E  out_degree_944
 E  in_degree_945
 G  order_active_lb_946
 L  order_active_ub_947
 E  segment_load_conservation_948
 G  segment_prefix_lb_949
 L  segment_prefix_ub_950
 E  out_degree_951
 E  in_degree_952
 G  order_active_lb_953
 L  order_active_ub_954
 E  service_visit_def_955
 E  free_load_conservation_956
 E  out_degree_957
 E  in_degree_958
 G  order_active_lb_959
 L  order_active_ub_960
 E  service_visit_def_961
 E  free_load_conservation_962
 E  out_degree_963
 E  in_degree_964
 G  order_active_lb_965
 L  order_active_ub_966
 E  service_visit_def_967
 E  free_load_conservation_968
 E  out_degree_969
 E  in_degree_970
 G  order_active_lb_971
 L  order_active_ub_972
 E  service_visit_def_973
 E  free_load_conservation_974
 E  out_degree_975
 E  in_degree_976
 G  order_active_lb_977
 L  order_active_ub_978
 E  service_visit_def_979
 E  free_load_conservation_980
 E  out_degree_981
 E  in_degree_982
 G  order_active_lb_983
 L  order_active_ub_984
 E  service_visit_def_985
 E  free_load_conservation_986
 E  out_degree_987
 E  in_degree_988
 G  order_active_lb_989
 L  order_active_ub_990
 E  service_visit_def_991
 E  free_load_conservation_992
 E  out_degree_993
 E  in_degree_994
 G  order_active_lb_995
 L  order_active_ub_996
 E  service_visit_def_997
 E  free_load_conservation_998
 G  fixed_segment_relative_order_999
 G  fixed_segment_relative_order_1000
 G  fixed_segment_relative_order_1001
 G  fixed_segment_relative_order_1002
 G  fixed_segment_relative_order_1003
 G  fixed_segment_relative_order_1004
 G  fixed_segment_relative_order_1005
 L  original_T_including_depot_unload_1006
 L  arc_capacity_1007
 L  arc_capacity_1008
 L  arc_capacity_1009
 L  arc_capacity_1010
 L  arc_capacity_1011
 L  arc_capacity_1012
 L  arc_capacity_1013
 L  arc_capacity_1014
 L  arc_capacity_1015
 L  arc_capacity_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 E  depot_departure_or_bypass_1136
 E  depot_return_or_bypass_1137
 E  out_degree_1138
 E  in_degree_1139
 G  order_active_lb_1140
 L  order_active_ub_1141
 E  service_visit_def_1142
 E  free_load_conservation_1143
 E  out_degree_1144
 E  in_degree_1145
 G  order_active_lb_1146
 L  order_active_ub_1147
 E  service_visit_def_1148
 E  free_load_conservation_1149
 E  out_degree_1150
 E  in_degree_1151
 G  order_active_lb_1152
 L  order_active_ub_1153
 E  service_visit_def_1154
 E  free_load_conservation_1155
 E  out_degree_1156
 E  in_degree_1157
 G  order_active_lb_1158
 L  order_active_ub_1159
 E  service_visit_def_1160
 E  free_load_conservation_1161
 E  out_degree_1162
 E  in_degree_1163
 G  order_active_lb_1164
 L  order_active_ub_1165
 E  service_visit_def_1166
 E  free_load_conservation_1167
 E  out_degree_1168
 E  in_degree_1169
 G  order_active_lb_1170
 L  order_active_ub_1171
 E  service_visit_def_1172
 E  free_load_conservation_1173
 E  out_degree_1174
 E  in_degree_1175
 G  order_active_lb_1176
 L  order_active_ub_1177
 E  service_visit_def_1178
 E  free_load_conservation_1179
 E  out_degree_1180
 E  in_degree_1181
 G  order_active_lb_1182
 L  order_active_ub_1183
 E  service_visit_def_1184
 E  free_load_conservation_1185
 L  original_T_including_depot_unload_1186
COLUMNS
    t         normalized_mass_13_5  -1
    t         normalized_mass_14_40  -1
    t         normalized_mass_18_75  -1
    t         normalized_mass_17_112  -1
    t         normalized_mass_11_147  -1
    t         normalized_mass_12_182  -1
    t         normalized_mass_20_217  -1
    t         normalized_mass_10_224  -1
    t         normalization_285  8.3535714285714278e+00
    t         full_original_Gini_286  -3.1832142857142856e+01
    q         OBJ       1
    q         parent_nonstrict_scope_228  1
    q         full_original_Gini_286  20
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       6.3380304899829966e-03
    x_13_0    product_lb_0  -4.4823108802715707e-02
    x_13_0    product_ub_1  -1.1970927746912360e-01
    x_13_0    onehot_13_4  1
    x_13_0    parent_nonstrict_scope_228  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_0  1
    w_13_0    product_ub_1  1
    w_13_0    normalized_mass_13_5  1
    w_13_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       -6.3380304899829966e-03
    x_13_1    product_lb_2  -4.4823108802715707e-02
    x_13_1    product_ub_3  -1.1970927746912360e-01
    x_13_1    onehot_13_4  1
    x_13_1    stock_lb_226  1
    x_13_1    stock_ub_227  1
    x_13_1    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_2  1
    w_13_1    product_ub_3  1
    w_13_1    normalized_mass_13_5  1
    w_13_1    normalized_ratio_13_6  -1
    w_13_1    full_original_Gini_286  -3.8964285714285714e+00
    rho_13    normalized_ratio_13_6  1
    rho_13    block_pair_pos_239  -1
    rho_13    block_pair_neg_240  1
    rho_13    block_pair_pos_241  -1
    rho_13    block_pair_neg_242  1
    rho_13    block_pair_pos_243  -1
    rho_13    block_pair_neg_244  1
    rho_13    block_pair_pos_245  -1
    rho_13    block_pair_neg_246  1
    rho_13    block_pair_pos_247  -1
    rho_13    block_pair_neg_248  1
    rho_13    block_pair_pos_249  -1
    rho_13    block_pair_neg_250  1
    rho_13    block_pair_pos_251  -1
    rho_13    block_pair_neg_252  1
    rho_13    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_14_0    OBJ       3.2863847044708572e-02
    x_14_0    product_lb_7  -4.4823108802715707e-02
    x_14_0    product_ub_8  -1.1970927746912360e-01
    x_14_0    onehot_14_39  1
    x_14_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_14_0    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_0    product_lb_7  1
    w_14_0    product_ub_8  1
    w_14_0    normalized_mass_14_40  1
    w_14_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_1    OBJ       2.1909231363139048e-02
    x_14_1    product_lb_9  -4.4823108802715707e-02
    x_14_1    product_ub_10  -1.1970927746912360e-01
    x_14_1    onehot_14_39  1
    x_14_1    stock_lb_226  1
    x_14_1    stock_ub_227  1
    x_14_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_14_1    unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_1    product_lb_9  1
    w_14_1    product_ub_10  1
    w_14_1    normalized_mass_14_40  1
    w_14_1    normalized_ratio_14_41  -1.4285714285714285e-01
    w_14_1    full_original_Gini_286  -7.4964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_2    OBJ       1.0954615681569524e-02
    x_14_2    product_lb_11  -4.4823108802715707e-02
    x_14_2    product_ub_12  -1.1970927746912360e-01
    x_14_2    onehot_14_39  1
    x_14_2    stock_lb_226  2
    x_14_2    stock_ub_227  2
    x_14_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_14_2    unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_2    product_lb_11  1
    w_14_2    product_ub_12  1
    w_14_2    normalized_mass_14_40  1
    w_14_2    normalized_ratio_14_41  -2.8571428571428570e-01
    w_14_2    full_original_Gini_286  -6.6392857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_3    product_lb_13  -4.4823108802715707e-02
    x_14_3    product_ub_14  -1.1970927746912360e-01
    x_14_3    onehot_14_39  1
    x_14_3    stock_lb_226  3
    x_14_3    stock_ub_227  3
    x_14_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_14_3    unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_3    product_lb_13  1
    w_14_3    product_ub_14  1
    w_14_3    normalized_mass_14_40  1
    w_14_3    normalized_ratio_14_41  -4.2857142857142855e-01
    w_14_3    full_original_Gini_286  -5.7821428571428566e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_4    OBJ       -1.0954615681569524e-02
    x_14_4    product_lb_15  -4.4823108802715707e-02
    x_14_4    product_ub_16  -1.1970927746912360e-01
    x_14_4    onehot_14_39  1
    x_14_4    stock_lb_226  4
    x_14_4    stock_ub_227  4
    x_14_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_14_4    unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_4    product_lb_15  1
    w_14_4    product_ub_16  1
    w_14_4    normalized_mass_14_40  1
    w_14_4    normalized_ratio_14_41  -5.7142857142857140e-01
    w_14_4    full_original_Gini_286  -5.2107142857142854e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_5    OBJ       -2.1909231363139041e-02
    x_14_5    product_lb_17  -4.4823108802715707e-02
    x_14_5    product_ub_18  -1.1970927746912360e-01
    x_14_5    onehot_14_39  1
    x_14_5    stock_lb_226  5
    x_14_5    stock_ub_227  5
    x_14_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_14_5    unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_5    product_lb_17  1
    w_14_5    product_ub_18  1
    w_14_5    normalized_mass_14_40  1
    w_14_5    normalized_ratio_14_41  -7.1428571428571419e-01
    w_14_5    full_original_Gini_286  -4.6392857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_6    OBJ       -3.2863847044708572e-02
    x_14_6    product_lb_19  -4.4823108802715707e-02
    x_14_6    product_ub_20  -1.1970927746912360e-01
    x_14_6    onehot_14_39  1
    x_14_6    stock_lb_226  6
    x_14_6    stock_ub_227  6
    x_14_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_14_6    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_6    product_lb_19  1
    w_14_6    product_ub_20  1
    w_14_6    normalized_mass_14_40  1
    w_14_6    normalized_ratio_14_41  -8.5714285714285710e-01
    w_14_6    full_original_Gini_286  -4.1821428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_7    OBJ       -4.3818462726278096e-02
    x_14_7    product_lb_21  -4.4823108802715707e-02
    x_14_7    product_ub_22  -1.1970927746912360e-01
    x_14_7    onehot_14_39  1
    x_14_7    stock_lb_226  7
    x_14_7    stock_ub_227  7
    x_14_7    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_7    product_lb_21  1
    w_14_7    product_ub_22  1
    w_14_7    normalized_mass_14_40  1
    w_14_7    normalized_ratio_14_41  -1
    w_14_7    full_original_Gini_286  -3.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_8    OBJ       -3.2863847044708579e-02
    x_14_8    product_lb_23  -4.4823108802715707e-02
    x_14_8    product_ub_24  -1.1970927746912360e-01
    x_14_8    onehot_14_39  1
    x_14_8    stock_lb_226  8
    x_14_8    stock_ub_227  8
    x_14_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_14_8    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_8    product_lb_23  1
    w_14_8    product_ub_24  1
    w_14_8    normalized_mass_14_40  1
    w_14_8    normalized_ratio_14_41  -1.1428571428571428e+00
    w_14_8    full_original_Gini_286  -5.3607142857142840e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_9    OBJ       -2.1909231363139058e-02
    x_14_9    product_lb_25  -4.4823108802715707e-02
    x_14_9    product_ub_26  -1.1970927746912360e-01
    x_14_9    onehot_14_39  1
    x_14_9    stock_lb_226  9
    x_14_9    stock_ub_227  9
    x_14_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_14_9    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_9    product_lb_25  1
    w_14_9    product_ub_26  1
    w_14_9    normalized_mass_14_40  1
    w_14_9    normalized_ratio_14_41  -1.2857142857142856e+00
    w_14_9    full_original_Gini_286  -7.0749999999999984e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_10   OBJ       -1.0954615681569538e-02
    x_14_10   product_lb_27  -4.4823108802715707e-02
    x_14_10   product_ub_28  -1.1970927746912360e-01
    x_14_10   onehot_14_39  1
    x_14_10   stock_lb_226  10
    x_14_10   stock_ub_227  10
    x_14_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_14_10   unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_10   product_lb_27  1
    w_14_10   product_ub_28  1
    w_14_10   normalized_mass_14_40  1
    w_14_10   normalized_ratio_14_41  -1.4285714285714284e+00
    w_14_10   full_original_Gini_286  -8.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_14_11   product_lb_29  -4.4823108802715707e-02
    x_14_11   product_ub_30  -1.1970927746912360e-01
    x_14_11   onehot_14_39  1
    x_14_11   stock_lb_226  11
    x_14_11   stock_ub_227  11
    x_14_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_14_11   product_lb_29  1
    w_14_11   product_ub_30  1
    w_14_11   normalized_mass_14_40  1
    w_14_11   normalized_ratio_14_41  -1.5714285714285714e+00
    w_14_11   full_original_Gini_286  -1.0503571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_12   OBJ       1.0954615681569517e-02
    x_14_12   product_lb_31  -4.4823108802715707e-02
    x_14_12   product_ub_32  -1.1970927746912360e-01
    x_14_12   onehot_14_39  1
    x_14_12   stock_lb_226  12
    x_14_12   stock_ub_227  12
    x_14_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_14_12   unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_12   product_lb_31  1
    w_14_12   product_ub_32  1
    w_14_12   normalized_mass_14_40  1
    w_14_12   normalized_ratio_14_41  -1.7142857142857142e+00
    w_14_12   full_original_Gini_286  -1.2217857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_13   OBJ       2.1909231363139034e-02
    x_14_13   product_lb_33  -4.4823108802715707e-02
    x_14_13   product_ub_34  -1.1970927746912360e-01
    x_14_13   onehot_14_39  1
    x_14_13   stock_lb_226  13
    x_14_13   stock_ub_227  13
    x_14_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_14_13   unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_13   product_lb_33  1
    w_14_13   product_ub_34  1
    w_14_13   normalized_mass_14_40  1
    w_14_13   normalized_ratio_14_41  -1.8571428571428570e+00
    w_14_13   full_original_Gini_286  -1.3932142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_14   OBJ       3.2863847044708572e-02
    x_14_14   product_lb_35  -4.4823108802715707e-02
    x_14_14   product_ub_36  -1.1970927746912360e-01
    x_14_14   onehot_14_39  1
    x_14_14   stock_lb_226  14
    x_14_14   stock_ub_227  14
    x_14_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_14_14   unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_14   product_lb_35  1
    w_14_14   product_ub_36  1
    w_14_14   normalized_mass_14_40  1
    w_14_14   normalized_ratio_14_41  -2
    w_14_14   full_original_Gini_286  -1.5646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_14_15   OBJ       4.3818462726278096e-02
    x_14_15   product_lb_37  -4.4823108802715707e-02
    x_14_15   product_ub_38  -1.1970927746912360e-01
    x_14_15   onehot_14_39  1
    x_14_15   stock_lb_226  15
    x_14_15   stock_ub_227  15
    x_14_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_14_15   unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_14_15   product_lb_37  1
    w_14_15   product_ub_38  1
    w_14_15   normalized_mass_14_40  1
    w_14_15   normalized_ratio_14_41  -2.1428571428571428e+00
    w_14_15   full_original_Gini_286  -1.7360714285714284e+01
    rho_14    normalized_ratio_14_41  1
    rho_14    block_pair_pos_245  1
    rho_14    block_pair_neg_246  -1
    rho_14    block_pair_pos_253  -1
    rho_14    block_pair_neg_254  1
    rho_14    block_pair_pos_255  -1
    rho_14    block_pair_neg_256  1
    rho_14    block_pair_pos_257  -1
    rho_14    block_pair_neg_258  1
    rho_14    block_pair_pos_259  -1
    rho_14    block_pair_neg_260  1
    rho_14    block_pair_pos_261  -1
    rho_14    block_pair_neg_262  1
    rho_14    block_pair_pos_263  -1
    rho_14    block_pair_neg_264  1
    rho_14    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_42  -4.4823108802715707e-02
    x_18_0    product_ub_43  -1.1970927746912360e-01
    x_18_0    onehot_18_74  1
    x_18_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_42  1
    w_18_0    product_ub_43  1
    w_18_0    normalized_mass_18_75  1
    w_18_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_44  -4.4823108802715707e-02
    x_18_1    product_ub_45  -1.1970927746912360e-01
    x_18_1    onehot_18_74  1
    x_18_1    stock_lb_226  1
    x_18_1    stock_ub_227  1
    x_18_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_44  1
    w_18_1    product_ub_45  1
    w_18_1    normalized_mass_18_75  1
    w_18_1    normalized_ratio_18_76  -1.4285714285714285e-01
    w_18_1    full_original_Gini_286  -7.4964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_46  -4.4823108802715707e-02
    x_18_2    product_ub_47  -1.1970927746912360e-01
    x_18_2    onehot_18_74  1
    x_18_2    stock_lb_226  2
    x_18_2    stock_ub_227  2
    x_18_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_46  1
    w_18_2    product_ub_47  1
    w_18_2    normalized_mass_18_75  1
    w_18_2    normalized_ratio_18_76  -2.8571428571428570e-01
    w_18_2    full_original_Gini_286  -6.6392857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_48  -4.4823108802715707e-02
    x_18_3    product_ub_49  -1.1970927746912360e-01
    x_18_3    onehot_18_74  1
    x_18_3    stock_lb_226  3
    x_18_3    stock_ub_227  3
    x_18_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_48  1
    w_18_3    product_ub_49  1
    w_18_3    normalized_mass_18_75  1
    w_18_3    normalized_ratio_18_76  -4.2857142857142855e-01
    w_18_3    full_original_Gini_286  -5.7821428571428566e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_50  -4.4823108802715707e-02
    x_18_4    product_ub_51  -1.1970927746912360e-01
    x_18_4    onehot_18_74  1
    x_18_4    stock_lb_226  4
    x_18_4    stock_ub_227  4
    x_18_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_50  1
    w_18_4    product_ub_51  1
    w_18_4    normalized_mass_18_75  1
    w_18_4    normalized_ratio_18_76  -5.7142857142857140e-01
    w_18_4    full_original_Gini_286  -5.2107142857142854e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_52  -4.4823108802715707e-02
    x_18_5    product_ub_53  -1.1970927746912360e-01
    x_18_5    onehot_18_74  1
    x_18_5    stock_lb_226  5
    x_18_5    stock_ub_227  5
    x_18_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_52  1
    w_18_5    product_ub_53  1
    w_18_5    normalized_mass_18_75  1
    w_18_5    normalized_ratio_18_76  -7.1428571428571419e-01
    w_18_5    full_original_Gini_286  -4.6392857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_54  -4.4823108802715707e-02
    x_18_6    product_ub_55  -1.1970927746912360e-01
    x_18_6    onehot_18_74  1
    x_18_6    stock_lb_226  6
    x_18_6    stock_ub_227  6
    x_18_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_54  1
    w_18_6    product_ub_55  1
    w_18_6    normalized_mass_18_75  1
    w_18_6    normalized_ratio_18_76  -8.5714285714285710e-01
    w_18_6    full_original_Gini_286  -4.1821428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_56  -4.4823108802715707e-02
    x_18_7    product_ub_57  -1.1970927746912360e-01
    x_18_7    onehot_18_74  1
    x_18_7    stock_lb_226  7
    x_18_7    stock_ub_227  7
    x_18_7    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_56  1
    w_18_7    product_ub_57  1
    w_18_7    normalized_mass_18_75  1
    w_18_7    normalized_ratio_18_76  -1
    w_18_7    full_original_Gini_286  -3.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_58  -4.4823108802715707e-02
    x_18_8    product_ub_59  -1.1970927746912360e-01
    x_18_8    onehot_18_74  1
    x_18_8    stock_lb_226  8
    x_18_8    stock_ub_227  8
    x_18_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_58  1
    w_18_8    product_ub_59  1
    w_18_8    normalized_mass_18_75  1
    w_18_8    normalized_ratio_18_76  -1.1428571428571428e+00
    w_18_8    full_original_Gini_286  -5.3607142857142840e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_60  -4.4823108802715707e-02
    x_18_9    product_ub_61  -1.1970927746912360e-01
    x_18_9    onehot_18_74  1
    x_18_9    stock_lb_226  9
    x_18_9    stock_ub_227  9
    x_18_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_60  1
    w_18_9    product_ub_61  1
    w_18_9    normalized_mass_18_75  1
    w_18_9    normalized_ratio_18_76  -1.2857142857142856e+00
    w_18_9    full_original_Gini_286  -7.0749999999999984e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_62  -4.4823108802715707e-02
    x_18_10   product_ub_63  -1.1970927746912360e-01
    x_18_10   onehot_18_74  1
    x_18_10   stock_lb_226  10
    x_18_10   stock_ub_227  10
    x_18_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_62  1
    w_18_10   product_ub_63  1
    w_18_10   normalized_mass_18_75  1
    w_18_10   normalized_ratio_18_76  -1.4285714285714284e+00
    w_18_10   full_original_Gini_286  -8.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_64  -4.4823108802715707e-02
    x_18_11   product_ub_65  -1.1970927746912360e-01
    x_18_11   onehot_18_74  1
    x_18_11   stock_lb_226  11
    x_18_11   stock_ub_227  11
    x_18_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_64  1
    w_18_11   product_ub_65  1
    w_18_11   normalized_mass_18_75  1
    w_18_11   normalized_ratio_18_76  -1.5714285714285714e+00
    w_18_11   full_original_Gini_286  -1.0503571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_66  -4.4823108802715707e-02
    x_18_12   product_ub_67  -1.1970927746912360e-01
    x_18_12   onehot_18_74  1
    x_18_12   stock_lb_226  12
    x_18_12   stock_ub_227  12
    x_18_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_66  1
    w_18_12   product_ub_67  1
    w_18_12   normalized_mass_18_75  1
    w_18_12   normalized_ratio_18_76  -1.7142857142857142e+00
    w_18_12   full_original_Gini_286  -1.2217857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_68  -4.4823108802715707e-02
    x_18_13   product_ub_69  -1.1970927746912360e-01
    x_18_13   onehot_18_74  1
    x_18_13   stock_lb_226  13
    x_18_13   stock_ub_227  13
    x_18_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_68  1
    w_18_13   product_ub_69  1
    w_18_13   normalized_mass_18_75  1
    w_18_13   normalized_ratio_18_76  -1.8571428571428570e+00
    w_18_13   full_original_Gini_286  -1.3932142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_70  -4.4823108802715707e-02
    x_18_14   product_ub_71  -1.1970927746912360e-01
    x_18_14   onehot_18_74  1
    x_18_14   stock_lb_226  14
    x_18_14   stock_ub_227  14
    x_18_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_70  1
    w_18_14   product_ub_71  1
    w_18_14   normalized_mass_18_75  1
    w_18_14   normalized_ratio_18_76  -2
    w_18_14   full_original_Gini_286  -1.5646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_72  -4.4823108802715707e-02
    x_18_15   product_ub_73  -1.1970927746912360e-01
    x_18_15   onehot_18_74  1
    x_18_15   stock_lb_226  15
    x_18_15   stock_ub_227  15
    x_18_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_72  1
    w_18_15   product_ub_73  1
    w_18_15   normalized_mass_18_75  1
    w_18_15   normalized_ratio_18_76  -2.1428571428571428e+00
    w_18_15   full_original_Gini_286  -1.7360714285714284e+01
    rho_18    normalized_ratio_18_76  1
    rho_18    block_pair_pos_249  1
    rho_18    block_pair_neg_250  -1
    rho_18    block_pair_pos_261  1
    rho_18    block_pair_neg_262  -1
    rho_18    block_pair_pos_273  -1
    rho_18    block_pair_neg_274  1
    rho_18    block_pair_pos_275  -1
    rho_18    block_pair_neg_276  1
    rho_18    block_pair_pos_277  -1
    rho_18    block_pair_neg_278  1
    rho_18    block_pair_pos_279  -1
    rho_18    block_pair_neg_280  1
    rho_18    block_pair_pos_281  -1
    rho_18    block_pair_neg_282  1
    rho_18    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_77  -4.4823108802715707e-02
    x_17_0    product_ub_78  -1.1970927746912360e-01
    x_17_0    onehot_17_111  1
    x_17_0    parent_nonstrict_scope_228  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_77  1
    w_17_0    product_ub_78  1
    w_17_0    normalized_mass_17_112  1
    w_17_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_79  -4.4823108802715707e-02
    x_17_1    product_ub_80  -1.1970927746912360e-01
    x_17_1    onehot_17_111  1
    x_17_1    stock_lb_226  1
    x_17_1    stock_ub_227  1
    x_17_1    parent_nonstrict_scope_228  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_79  1
    w_17_1    product_ub_80  1
    w_17_1    normalized_mass_17_112  1
    w_17_1    normalized_ratio_17_113  -1.1111111111111110e-01
    w_17_1    full_original_Gini_286  -7.68690476190476
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_81  -4.4823108802715707e-02
    x_17_2    product_ub_82  -1.1970927746912360e-01
    x_17_2    onehot_17_111  1
    x_17_2    stock_lb_226  2
    x_17_2    stock_ub_227  2
    x_17_2    parent_nonstrict_scope_228  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_81  1
    w_17_2    product_ub_82  1
    w_17_2    normalized_mass_17_112  1
    w_17_2    normalized_ratio_17_113  -2.2222222222222221e-01
    w_17_2    full_original_Gini_286  -7.0202380952380947e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_83  -4.4823108802715707e-02
    x_17_3    product_ub_84  -1.1970927746912360e-01
    x_17_3    onehot_17_111  1
    x_17_3    stock_lb_226  3
    x_17_3    stock_ub_227  3
    x_17_3    parent_nonstrict_scope_228  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_83  1
    w_17_3    product_ub_84  1
    w_17_3    normalized_mass_17_112  1
    w_17_3    normalized_ratio_17_113  -3.3333333333333331e-01
    w_17_3    full_original_Gini_286  -6.3535714285714295e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_85  -4.4823108802715707e-02
    x_17_4    product_ub_86  -1.1970927746912360e-01
    x_17_4    onehot_17_111  1
    x_17_4    stock_lb_226  4
    x_17_4    stock_ub_227  4
    x_17_4    parent_nonstrict_scope_228  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_85  1
    w_17_4    product_ub_86  1
    w_17_4    normalized_mass_17_112  1
    w_17_4    normalized_ratio_17_113  -4.4444444444444442e-01
    w_17_4    full_original_Gini_286  -5.7186507936507933e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_87  -4.4823108802715707e-02
    x_17_5    product_ub_88  -1.1970927746912360e-01
    x_17_5    onehot_17_111  1
    x_17_5    stock_lb_226  5
    x_17_5    stock_ub_227  5
    x_17_5    parent_nonstrict_scope_228  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_87  1
    w_17_5    product_ub_88  1
    w_17_5    normalized_mass_17_112  1
    w_17_5    normalized_ratio_17_113  -5.5555555555555558e-01
    w_17_5    full_original_Gini_286  -5.2742063492063487e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_89  -4.4823108802715707e-02
    x_17_6    product_ub_90  -1.1970927746912360e-01
    x_17_6    onehot_17_111  1
    x_17_6    stock_lb_226  6
    x_17_6    stock_ub_227  6
    x_17_6    parent_nonstrict_scope_228  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_89  1
    w_17_6    product_ub_90  1
    w_17_6    normalized_mass_17_112  1
    w_17_6    normalized_ratio_17_113  -6.6666666666666663e-01
    w_17_6    full_original_Gini_286  -4.8297619047619049e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_91  -4.4823108802715707e-02
    x_17_7    product_ub_92  -1.1970927746912360e-01
    x_17_7    onehot_17_111  1
    x_17_7    stock_lb_226  7
    x_17_7    stock_ub_227  7
    x_17_7    parent_nonstrict_scope_228  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_91  1
    w_17_7    product_ub_92  1
    w_17_7    normalized_mass_17_112  1
    w_17_7    normalized_ratio_17_113  -7.7777777777777768e-01
    w_17_7    full_original_Gini_286  -4.3853174603174612e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_93  -4.4823108802715707e-02
    x_17_8    product_ub_94  -1.1970927746912360e-01
    x_17_8    onehot_17_111  1
    x_17_8    stock_lb_226  8
    x_17_8    stock_ub_227  8
    x_17_8    parent_nonstrict_scope_228  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_93  1
    w_17_8    product_ub_94  1
    w_17_8    normalized_mass_17_112  1
    w_17_8    normalized_ratio_17_113  -8.8888888888888884e-01
    w_17_8    full_original_Gini_286  -4.1186507936507937e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_95  -4.4823108802715707e-02
    x_17_9    product_ub_96  -1.1970927746912360e-01
    x_17_9    onehot_17_111  1
    x_17_9    stock_lb_226  9
    x_17_9    stock_ub_227  9
    x_17_9    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_95  1
    w_17_9    product_ub_96  1
    w_17_9    normalized_mass_17_112  1
    w_17_9    normalized_ratio_17_113  -1
    w_17_9    full_original_Gini_286  -3.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_97  -4.4823108802715707e-02
    x_17_10   product_ub_98  -1.1970927746912360e-01
    x_17_10   onehot_17_111  1
    x_17_10   stock_lb_226  10
    x_17_10   stock_ub_227  10
    x_17_10   parent_nonstrict_scope_228  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_97  1
    w_17_10   product_ub_98  1
    w_17_10   normalized_mass_17_112  1
    w_17_10   normalized_ratio_17_113  -1.1111111111111112e+00
    w_17_10   full_original_Gini_286  -5.0075396825396830e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_99  -4.4823108802715707e-02
    x_17_11   product_ub_100  -1.1970927746912360e-01
    x_17_11   onehot_17_111  1
    x_17_11   stock_lb_226  11
    x_17_11   stock_ub_227  11
    x_17_11   parent_nonstrict_scope_228  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_99  1
    w_17_11   product_ub_100  1
    w_17_11   normalized_mass_17_112  1
    w_17_11   normalized_ratio_17_113  -1.2222222222222221e+00
    w_17_11   full_original_Gini_286  -6.3130952380952374e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_101  -4.4823108802715707e-02
    x_17_12   product_ub_102  -1.1970927746912360e-01
    x_17_12   onehot_17_111  1
    x_17_12   stock_lb_226  12
    x_17_12   stock_ub_227  12
    x_17_12   parent_nonstrict_scope_228  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_101  1
    w_17_12   product_ub_102  1
    w_17_12   normalized_mass_17_112  1
    w_17_12   normalized_ratio_17_113  -1.3333333333333333e+00
    w_17_12   full_original_Gini_286  -7.64642857142857
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_103  -4.4823108802715707e-02
    x_17_13   product_ub_104  -1.1970927746912360e-01
    x_17_13   onehot_17_111  1
    x_17_13   stock_lb_226  13
    x_17_13   stock_ub_227  13
    x_17_13   parent_nonstrict_scope_228  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_103  1
    w_17_13   product_ub_104  1
    w_17_13   normalized_mass_17_112  1
    w_17_13   normalized_ratio_17_113  -1.4444444444444444e+00
    w_17_13   full_original_Gini_286  -8.9797619047619044e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_105  -4.4823108802715707e-02
    x_17_14   product_ub_106  -1.1970927746912360e-01
    x_17_14   onehot_17_111  1
    x_17_14   stock_lb_226  14
    x_17_14   stock_ub_227  14
    x_17_14   parent_nonstrict_scope_228  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_105  1
    w_17_14   product_ub_106  1
    w_17_14   normalized_mass_17_112  1
    w_17_14   normalized_ratio_17_113  -1.5555555555555554e+00
    w_17_14   full_original_Gini_286  -1.0313095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_107  -4.4823108802715707e-02
    x_17_15   product_ub_108  -1.1970927746912360e-01
    x_17_15   onehot_17_111  1
    x_17_15   stock_lb_226  15
    x_17_15   stock_ub_227  15
    x_17_15   parent_nonstrict_scope_228  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_107  1
    w_17_15   product_ub_108  1
    w_17_15   normalized_mass_17_112  1
    w_17_15   normalized_ratio_17_113  -1.6666666666666665e+00
    w_17_15   full_original_Gini_286  -1.1646428571428569e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_109  -4.4823108802715707e-02
    x_17_16   product_ub_110  -1.1970927746912360e-01
    x_17_16   onehot_17_111  1
    x_17_16   stock_lb_226  16
    x_17_16   stock_ub_227  16
    x_17_16   parent_nonstrict_scope_228  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_109  1
    w_17_16   product_ub_110  1
    w_17_16   normalized_mass_17_112  1
    w_17_16   normalized_ratio_17_113  -1.7777777777777777e+00
    w_17_16   full_original_Gini_286  -1.2979761904761904e+01
    rho_17    normalized_ratio_17_113  1
    rho_17    block_pair_pos_247  1
    rho_17    block_pair_neg_248  -1
    rho_17    block_pair_pos_259  1
    rho_17    block_pair_neg_260  -1
    rho_17    block_pair_pos_265  -1
    rho_17    block_pair_neg_266  1
    rho_17    block_pair_pos_267  -1
    rho_17    block_pair_neg_268  1
    rho_17    block_pair_pos_269  -1
    rho_17    block_pair_neg_270  1
    rho_17    block_pair_pos_271  -1
    rho_17    block_pair_neg_272  1
    rho_17    block_pair_pos_279  1
    rho_17    block_pair_neg_280  -1
    rho_17    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_114  -4.4823108802715707e-02
    x_11_0    product_ub_115  -1.1970927746912360e-01
    x_11_0    onehot_11_146  1
    x_11_0    parent_nonstrict_scope_228  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_114  1
    w_11_0    product_ub_115  1
    w_11_0    normalized_mass_11_147  1
    w_11_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_116  -4.4823108802715707e-02
    x_11_1    product_ub_117  -1.1970927746912360e-01
    x_11_1    onehot_11_146  1
    x_11_1    stock_lb_226  1
    x_11_1    stock_ub_227  1
    x_11_1    parent_nonstrict_scope_228  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_116  1
    w_11_1    product_ub_117  1
    w_11_1    normalized_mass_11_147  1
    w_11_1    normalized_ratio_11_148  -0.125
    w_11_1    full_original_Gini_286  -7.6035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_118  -4.4823108802715707e-02
    x_11_2    product_ub_119  -1.1970927746912360e-01
    x_11_2    onehot_11_146  1
    x_11_2    stock_lb_226  2
    x_11_2    stock_ub_227  2
    x_11_2    parent_nonstrict_scope_228  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_118  1
    w_11_2    product_ub_119  1
    w_11_2    normalized_mass_11_147  1
    w_11_2    normalized_ratio_11_148  -0.25
    w_11_2    full_original_Gini_286  -6.8535714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_120  -4.4823108802715707e-02
    x_11_3    product_ub_121  -1.1970927746912360e-01
    x_11_3    onehot_11_146  1
    x_11_3    stock_lb_226  3
    x_11_3    stock_ub_227  3
    x_11_3    parent_nonstrict_scope_228  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_120  1
    w_11_3    product_ub_121  1
    w_11_3    normalized_mass_11_147  1
    w_11_3    normalized_ratio_11_148  -0.375
    w_11_3    full_original_Gini_286  -6.1035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_122  -4.4823108802715707e-02
    x_11_4    product_ub_123  -1.1970927746912360e-01
    x_11_4    onehot_11_146  1
    x_11_4    stock_lb_226  4
    x_11_4    stock_ub_227  4
    x_11_4    parent_nonstrict_scope_228  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_122  1
    w_11_4    product_ub_123  1
    w_11_4    normalized_mass_11_147  1
    w_11_4    normalized_ratio_11_148  -0.5
    w_11_4    full_original_Gini_286  -5.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_124  -4.4823108802715707e-02
    x_11_5    product_ub_125  -1.1970927746912360e-01
    x_11_5    onehot_11_146  1
    x_11_5    stock_lb_226  5
    x_11_5    stock_ub_227  5
    x_11_5    parent_nonstrict_scope_228  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_124  1
    w_11_5    product_ub_125  1
    w_11_5    normalized_mass_11_147  1
    w_11_5    normalized_ratio_11_148  -0.625
    w_11_5    full_original_Gini_286  -4.9964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_126  -4.4823108802715707e-02
    x_11_6    product_ub_127  -1.1970927746912360e-01
    x_11_6    onehot_11_146  1
    x_11_6    stock_lb_226  6
    x_11_6    stock_ub_227  6
    x_11_6    parent_nonstrict_scope_228  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_126  1
    w_11_6    product_ub_127  1
    w_11_6    normalized_mass_11_147  1
    w_11_6    normalized_ratio_11_148  -0.75
    w_11_6    full_original_Gini_286  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_128  -4.4823108802715707e-02
    x_11_7    product_ub_129  -1.1970927746912360e-01
    x_11_7    onehot_11_146  1
    x_11_7    stock_lb_226  7
    x_11_7    stock_ub_227  7
    x_11_7    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_128  1
    w_11_7    product_ub_129  1
    w_11_7    normalized_mass_11_147  1
    w_11_7    normalized_ratio_11_148  -0.875
    w_11_7    full_original_Gini_286  -4.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_130  -4.4823108802715707e-02
    x_11_8    product_ub_131  -1.1970927746912360e-01
    x_11_8    onehot_11_146  1
    x_11_8    stock_lb_226  8
    x_11_8    stock_ub_227  8
    x_11_8    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_130  1
    w_11_8    product_ub_131  1
    w_11_8    normalized_mass_11_147  1
    w_11_8    normalized_ratio_11_148  -1
    w_11_8    full_original_Gini_286  -3.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_132  -4.4823108802715707e-02
    x_11_9    product_ub_133  -1.1970927746912360e-01
    x_11_9    onehot_11_146  1
    x_11_9    stock_lb_226  9
    x_11_9    stock_ub_227  9
    x_11_9    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_132  1
    w_11_9    product_ub_133  1
    w_11_9    normalized_mass_11_147  1
    w_11_9    normalized_ratio_11_148  -1.125
    w_11_9    full_original_Gini_286  -5.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_134  -4.4823108802715707e-02
    x_11_10   product_ub_135  -1.1970927746912360e-01
    x_11_10   onehot_11_146  1
    x_11_10   stock_lb_226  10
    x_11_10   stock_ub_227  10
    x_11_10   parent_nonstrict_scope_228  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_134  1
    w_11_10   product_ub_135  1
    w_11_10   normalized_mass_11_147  1
    w_11_10   normalized_ratio_11_148  -1.25
    w_11_10   full_original_Gini_286  -6.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_136  -4.4823108802715707e-02
    x_11_11   product_ub_137  -1.1970927746912360e-01
    x_11_11   onehot_11_146  1
    x_11_11   stock_lb_226  11
    x_11_11   stock_ub_227  11
    x_11_11   parent_nonstrict_scope_228  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_136  1
    w_11_11   product_ub_137  1
    w_11_11   normalized_mass_11_147  1
    w_11_11   normalized_ratio_11_148  -1.375
    w_11_11   full_original_Gini_286  -8.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_138  -4.4823108802715707e-02
    x_11_12   product_ub_139  -1.1970927746912360e-01
    x_11_12   onehot_11_146  1
    x_11_12   stock_lb_226  12
    x_11_12   stock_ub_227  12
    x_11_12   parent_nonstrict_scope_228  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_138  1
    w_11_12   product_ub_139  1
    w_11_12   normalized_mass_11_147  1
    w_11_12   normalized_ratio_11_148  -1.5
    w_11_12   full_original_Gini_286  -9.6464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_140  -4.4823108802715707e-02
    x_11_13   product_ub_141  -1.1970927746912360e-01
    x_11_13   onehot_11_146  1
    x_11_13   stock_lb_226  13
    x_11_13   stock_ub_227  13
    x_11_13   parent_nonstrict_scope_228  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_140  1
    w_11_13   product_ub_141  1
    w_11_13   normalized_mass_11_147  1
    w_11_13   normalized_ratio_11_148  -1.625
    w_11_13   full_original_Gini_286  -1.1146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_142  -4.4823108802715707e-02
    x_11_14   product_ub_143  -1.1970927746912360e-01
    x_11_14   onehot_11_146  1
    x_11_14   stock_lb_226  14
    x_11_14   stock_ub_227  14
    x_11_14   parent_nonstrict_scope_228  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_142  1
    w_11_14   product_ub_143  1
    w_11_14   normalized_mass_11_147  1
    w_11_14   normalized_ratio_11_148  -1.75
    w_11_14   full_original_Gini_286  -1.2646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_144  -4.4823108802715707e-02
    x_11_15   product_ub_145  -1.1970927746912360e-01
    x_11_15   onehot_11_146  1
    x_11_15   stock_lb_226  15
    x_11_15   stock_ub_227  15
    x_11_15   parent_nonstrict_scope_228  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_144  1
    w_11_15   product_ub_145  1
    w_11_15   normalized_mass_11_147  1
    w_11_15   normalized_ratio_11_148  -1.875
    w_11_15   full_original_Gini_286  -1.4146428571428572e+01
    rho_11    normalized_ratio_11_148  1
    rho_11    block_pair_pos_229  -1
    rho_11    block_pair_neg_230  1
    rho_11    block_pair_pos_231  -1
    rho_11    block_pair_neg_232  1
    rho_11    block_pair_pos_233  -1
    rho_11    block_pair_neg_234  1
    rho_11    block_pair_pos_241  1
    rho_11    block_pair_neg_242  -1
    rho_11    block_pair_pos_255  1
    rho_11    block_pair_neg_256  -1
    rho_11    block_pair_pos_267  1
    rho_11    block_pair_neg_268  -1
    rho_11    block_pair_pos_275  1
    rho_11    block_pair_neg_276  -1
    rho_11    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       3.2863847044708572e-02
    x_12_0    product_lb_149  -4.4823108802715707e-02
    x_12_0    product_ub_150  -1.1970927746912360e-01
    x_12_0    onehot_12_181  1
    x_12_0    parent_nonstrict_scope_228  7.6682309770986667e-02
    x_12_0    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_149  1
    w_12_0    product_ub_150  1
    w_12_0    normalized_mass_12_182  1
    w_12_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1909231363139048e-02
    x_12_1    product_lb_151  -4.4823108802715707e-02
    x_12_1    product_ub_152  -1.1970927746912360e-01
    x_12_1    onehot_12_181  1
    x_12_1    stock_lb_226  1
    x_12_1    stock_ub_227  1
    x_12_1    parent_nonstrict_scope_228  6.5727694089417144e-02
    x_12_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_151  1
    w_12_1    product_ub_152  1
    w_12_1    normalized_mass_12_182  1
    w_12_1    normalized_ratio_12_183  -1.4285714285714285e-01
    w_12_1    full_original_Gini_286  -7.4964285714285728e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0954615681569524e-02
    x_12_2    product_lb_153  -4.4823108802715707e-02
    x_12_2    product_ub_154  -1.1970927746912360e-01
    x_12_2    onehot_12_181  1
    x_12_2    stock_lb_226  2
    x_12_2    stock_ub_227  2
    x_12_2    parent_nonstrict_scope_228  5.4773078407847620e-02
    x_12_2    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_153  1
    w_12_2    product_ub_154  1
    w_12_2    normalized_mass_12_182  1
    w_12_2    normalized_ratio_12_183  -2.8571428571428570e-01
    w_12_2    full_original_Gini_286  -6.6392857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_155  -4.4823108802715707e-02
    x_12_3    product_ub_156  -1.1970927746912360e-01
    x_12_3    onehot_12_181  1
    x_12_3    stock_lb_226  3
    x_12_3    stock_ub_227  3
    x_12_3    parent_nonstrict_scope_228  4.3818462726278096e-02
    x_12_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_155  1
    w_12_3    product_ub_156  1
    w_12_3    normalized_mass_12_182  1
    w_12_3    normalized_ratio_12_183  -4.2857142857142855e-01
    w_12_3    full_original_Gini_286  -5.7821428571428566e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0954615681569524e-02
    x_12_4    product_lb_157  -4.4823108802715707e-02
    x_12_4    product_ub_158  -1.1970927746912360e-01
    x_12_4    onehot_12_181  1
    x_12_4    stock_lb_226  4
    x_12_4    stock_ub_227  4
    x_12_4    parent_nonstrict_scope_228  3.2863847044708572e-02
    x_12_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_157  1
    w_12_4    product_ub_158  1
    w_12_4    normalized_mass_12_182  1
    w_12_4    normalized_ratio_12_183  -5.7142857142857140e-01
    w_12_4    full_original_Gini_286  -5.2107142857142854e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.1909231363139041e-02
    x_12_5    product_lb_159  -4.4823108802715707e-02
    x_12_5    product_ub_160  -1.1970927746912360e-01
    x_12_5    onehot_12_181  1
    x_12_5    stock_lb_226  5
    x_12_5    stock_ub_227  5
    x_12_5    parent_nonstrict_scope_228  2.1909231363139055e-02
    x_12_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_159  1
    w_12_5    product_ub_160  1
    w_12_5    normalized_mass_12_182  1
    w_12_5    normalized_ratio_12_183  -7.1428571428571419e-01
    w_12_5    full_original_Gini_286  -4.6392857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.2863847044708572e-02
    x_12_6    product_lb_161  -4.4823108802715707e-02
    x_12_6    product_ub_162  -1.1970927746912360e-01
    x_12_6    onehot_12_181  1
    x_12_6    stock_lb_226  6
    x_12_6    stock_ub_227  6
    x_12_6    parent_nonstrict_scope_228  1.0954615681569527e-02
    x_12_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_161  1
    w_12_6    product_ub_162  1
    w_12_6    normalized_mass_12_182  1
    w_12_6    normalized_ratio_12_183  -8.5714285714285710e-01
    w_12_6    full_original_Gini_286  -4.1821428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.3818462726278096e-02
    x_12_7    product_lb_163  -4.4823108802715707e-02
    x_12_7    product_ub_164  -1.1970927746912360e-01
    x_12_7    onehot_12_181  1
    x_12_7    stock_lb_226  7
    x_12_7    stock_ub_227  7
    x_12_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_163  1
    w_12_7    product_ub_164  1
    w_12_7    normalized_mass_12_182  1
    w_12_7    normalized_ratio_12_183  -1
    w_12_7    full_original_Gini_286  -3.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -3.2863847044708579e-02
    x_12_8    product_lb_165  -4.4823108802715707e-02
    x_12_8    product_ub_166  -1.1970927746912360e-01
    x_12_8    onehot_12_181  1
    x_12_8    stock_lb_226  8
    x_12_8    stock_ub_227  8
    x_12_8    parent_nonstrict_scope_228  1.0954615681569519e-02
    x_12_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_165  1
    w_12_8    product_ub_166  1
    w_12_8    normalized_mass_12_182  1
    w_12_8    normalized_ratio_12_183  -1.1428571428571428e+00
    w_12_8    full_original_Gini_286  -5.3607142857142840e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1909231363139058e-02
    x_12_9    product_lb_167  -4.4823108802715707e-02
    x_12_9    product_ub_168  -1.1970927746912360e-01
    x_12_9    onehot_12_181  1
    x_12_9    stock_lb_226  9
    x_12_9    stock_ub_227  9
    x_12_9    parent_nonstrict_scope_228  2.1909231363139037e-02
    x_12_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_167  1
    w_12_9    product_ub_168  1
    w_12_9    normalized_mass_12_182  1
    w_12_9    normalized_ratio_12_183  -1.2857142857142856e+00
    w_12_9    full_original_Gini_286  -7.0749999999999984e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0954615681569538e-02
    x_12_10   product_lb_169  -4.4823108802715707e-02
    x_12_10   product_ub_170  -1.1970927746912360e-01
    x_12_10   onehot_12_181  1
    x_12_10   stock_lb_226  10
    x_12_10   stock_ub_227  10
    x_12_10   parent_nonstrict_scope_228  3.2863847044708558e-02
    x_12_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_169  1
    w_12_10   product_ub_170  1
    w_12_10   normalized_mass_12_182  1
    w_12_10   normalized_ratio_12_183  -1.4285714285714284e+00
    w_12_10   full_original_Gini_286  -8.7892857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_171  -4.4823108802715707e-02
    x_12_11   product_ub_172  -1.1970927746912360e-01
    x_12_11   onehot_12_181  1
    x_12_11   stock_lb_226  11
    x_12_11   stock_ub_227  11
    x_12_11   parent_nonstrict_scope_228  4.3818462726278096e-02
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_171  1
    w_12_11   product_ub_172  1
    w_12_11   normalized_mass_12_182  1
    w_12_11   normalized_ratio_12_183  -1.5714285714285714e+00
    w_12_11   full_original_Gini_286  -1.0503571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0954615681569517e-02
    x_12_12   product_lb_173  -4.4823108802715707e-02
    x_12_12   product_ub_174  -1.1970927746912360e-01
    x_12_12   onehot_12_181  1
    x_12_12   stock_lb_226  12
    x_12_12   stock_ub_227  12
    x_12_12   parent_nonstrict_scope_228  5.4773078407847613e-02
    x_12_12   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_173  1
    w_12_12   product_ub_174  1
    w_12_12   normalized_mass_12_182  1
    w_12_12   normalized_ratio_12_183  -1.7142857142857142e+00
    w_12_12   full_original_Gini_286  -1.2217857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.1909231363139034e-02
    x_12_13   product_lb_175  -4.4823108802715707e-02
    x_12_13   product_ub_176  -1.1970927746912360e-01
    x_12_13   onehot_12_181  1
    x_12_13   stock_lb_226  13
    x_12_13   stock_ub_227  13
    x_12_13   parent_nonstrict_scope_228  6.5727694089417130e-02
    x_12_13   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_175  1
    w_12_13   product_ub_176  1
    w_12_13   normalized_mass_12_182  1
    w_12_13   normalized_ratio_12_183  -1.8571428571428570e+00
    w_12_13   full_original_Gini_286  -1.3932142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       3.2863847044708572e-02
    x_12_14   product_lb_177  -4.4823108802715707e-02
    x_12_14   product_ub_178  -1.1970927746912360e-01
    x_12_14   onehot_12_181  1
    x_12_14   stock_lb_226  14
    x_12_14   stock_ub_227  14
    x_12_14   parent_nonstrict_scope_228  7.6682309770986667e-02
    x_12_14   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_177  1
    w_12_14   product_ub_178  1
    w_12_14   normalized_mass_12_182  1
    w_12_14   normalized_ratio_12_183  -2
    w_12_14   full_original_Gini_286  -1.5646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.3818462726278096e-02
    x_12_15   product_lb_179  -4.4823108802715707e-02
    x_12_15   product_ub_180  -1.1970927746912360e-01
    x_12_15   onehot_12_181  1
    x_12_15   stock_lb_226  15
    x_12_15   stock_ub_227  15
    x_12_15   parent_nonstrict_scope_228  8.7636925452556191e-02
    x_12_15   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_179  1
    w_12_15   product_ub_180  1
    w_12_15   normalized_mass_12_182  1
    w_12_15   normalized_ratio_12_183  -2.1428571428571428e+00
    w_12_15   full_original_Gini_286  -1.7360714285714284e+01
    rho_12    normalized_ratio_12_183  1
    rho_12    block_pair_pos_231  1
    rho_12    block_pair_neg_232  -1
    rho_12    block_pair_pos_235  -1
    rho_12    block_pair_neg_236  1
    rho_12    block_pair_pos_237  -1
    rho_12    block_pair_neg_238  1
    rho_12    block_pair_pos_243  1
    rho_12    block_pair_neg_244  -1
    rho_12    block_pair_pos_257  1
    rho_12    block_pair_neg_258  -1
    rho_12    block_pair_pos_269  1
    rho_12    block_pair_neg_270  -1
    rho_12    block_pair_pos_277  1
    rho_12    block_pair_neg_278  -1
    rho_12    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       5.0078236648368350e-02
    x_20_0    product_lb_184  -4.4823108802715707e-02
    x_20_0    product_ub_185  -1.1970927746912360e-01
    x_20_0    onehot_20_216  1
    x_20_0    parent_nonstrict_scope_228  1.0015647329673670e-01
    x_20_0    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_184  1
    w_20_0    product_ub_185  1
    w_20_0    normalized_mass_20_217  1
    w_20_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       3.7558677486276261e-02
    x_20_1    product_lb_186  -4.4823108802715707e-02
    x_20_1    product_ub_187  -1.1970927746912360e-01
    x_20_1    onehot_20_216  1
    x_20_1    stock_lb_226  1
    x_20_1    stock_ub_227  1
    x_20_1    parent_nonstrict_scope_228  8.7636914134644611e-02
    x_20_1    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_186  1
    w_20_1    product_ub_187  1
    w_20_1    normalized_mass_20_217  1
    w_20_1    normalized_ratio_20_218  -0.125
    w_20_1    full_original_Gini_286  -7.6035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       2.5039118324184172e-02
    x_20_2    product_lb_188  -4.4823108802715707e-02
    x_20_2    product_ub_189  -1.1970927746912360e-01
    x_20_2    onehot_20_216  1
    x_20_2    stock_lb_226  2
    x_20_2    stock_ub_227  2
    x_20_2    parent_nonstrict_scope_228  7.5117354972552522e-02
    x_20_2    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_188  1
    w_20_2    product_ub_189  1
    w_20_2    normalized_mass_20_217  1
    w_20_2    normalized_ratio_20_218  -0.25
    w_20_2    full_original_Gini_286  -6.8535714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_3    OBJ       1.2519559162092082e-02
    x_20_3    product_lb_190  -4.4823108802715707e-02
    x_20_3    product_ub_191  -1.1970927746912360e-01
    x_20_3    onehot_20_216  1
    x_20_3    stock_lb_226  3
    x_20_3    stock_ub_227  3
    x_20_3    parent_nonstrict_scope_228  6.2597795810460433e-02
    x_20_3    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_190  1
    w_20_3    product_ub_191  1
    w_20_3    normalized_mass_20_217  1
    w_20_3    normalized_ratio_20_218  -0.375
    w_20_3    full_original_Gini_286  -6.1035714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_4    product_lb_192  -4.4823108802715707e-02
    x_20_4    product_ub_193  -1.1970927746912360e-01
    x_20_4    onehot_20_216  1
    x_20_4    stock_lb_226  4
    x_20_4    stock_ub_227  4
    x_20_4    parent_nonstrict_scope_228  5.0078236648368350e-02
    x_20_4    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_192  1
    w_20_4    product_ub_193  1
    w_20_4    normalized_mass_20_217  1
    w_20_4    normalized_ratio_20_218  -0.5
    w_20_4    full_original_Gini_286  -5.4964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.2519559162092089e-02
    x_20_5    product_lb_194  -4.4823108802715707e-02
    x_20_5    product_ub_195  -1.1970927746912360e-01
    x_20_5    onehot_20_216  1
    x_20_5    stock_lb_226  5
    x_20_5    stock_ub_227  5
    x_20_5    parent_nonstrict_scope_228  3.7558677486276261e-02
    x_20_5    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_194  1
    w_20_5    product_ub_195  1
    w_20_5    normalized_mass_20_217  1
    w_20_5    normalized_ratio_20_218  -0.625
    w_20_5    full_original_Gini_286  -4.9964285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -2.5039118324184175e-02
    x_20_6    product_lb_196  -4.4823108802715707e-02
    x_20_6    product_ub_197  -1.1970927746912360e-01
    x_20_6    onehot_20_216  1
    x_20_6    stock_lb_226  6
    x_20_6    stock_ub_227  6
    x_20_6    parent_nonstrict_scope_228  2.5039118324184175e-02
    x_20_6    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_196  1
    w_20_6    product_ub_197  1
    w_20_6    normalized_mass_20_217  1
    w_20_6    normalized_ratio_20_218  -0.75
    w_20_6    full_original_Gini_286  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -3.7558677486276261e-02
    x_20_7    product_lb_198  -4.4823108802715707e-02
    x_20_7    product_ub_199  -1.1970927746912360e-01
    x_20_7    onehot_20_216  1
    x_20_7    stock_lb_226  7
    x_20_7    stock_ub_227  7
    x_20_7    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_20_7    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_198  1
    w_20_7    product_ub_199  1
    w_20_7    normalized_mass_20_217  1
    w_20_7    normalized_ratio_20_218  -0.875
    w_20_7    full_original_Gini_286  -4.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -5.0078236648368350e-02
    x_20_8    product_lb_200  -4.4823108802715707e-02
    x_20_8    product_ub_201  -1.1970927746912360e-01
    x_20_8    onehot_20_216  1
    x_20_8    stock_lb_226  8
    x_20_8    stock_ub_227  8
    x_20_8    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_200  1
    w_20_8    product_ub_201  1
    w_20_8    normalized_mass_20_217  1
    w_20_8    normalized_ratio_20_218  -1
    w_20_8    full_original_Gini_286  -3.8964285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_9    OBJ       -3.7558677486276261e-02
    x_20_9    product_lb_202  -4.4823108802715707e-02
    x_20_9    product_ub_203  -1.1970927746912360e-01
    x_20_9    onehot_20_216  1
    x_20_9    stock_lb_226  9
    x_20_9    stock_ub_227  9
    x_20_9    parent_nonstrict_scope_228  1.2519559162092088e-02
    x_20_9    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_202  1
    w_20_9    product_ub_203  1
    w_20_9    normalized_mass_20_217  1
    w_20_9    normalized_ratio_20_218  -1.125
    w_20_9    full_original_Gini_286  -5.1464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       -2.5039118324184175e-02
    x_20_10   product_lb_204  -4.4823108802715707e-02
    x_20_10   product_ub_205  -1.1970927746912360e-01
    x_20_10   onehot_20_216  1
    x_20_10   stock_lb_226  10
    x_20_10   stock_ub_227  10
    x_20_10   parent_nonstrict_scope_228  2.5039118324184175e-02
    x_20_10   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_204  1
    w_20_10   product_ub_205  1
    w_20_10   normalized_mass_20_217  1
    w_20_10   normalized_ratio_20_218  -1.25
    w_20_10   full_original_Gini_286  -6.6464285714285714e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       -1.2519559162092089e-02
    x_20_11   product_lb_206  -4.4823108802715707e-02
    x_20_11   product_ub_207  -1.1970927746912360e-01
    x_20_11   onehot_20_216  1
    x_20_11   stock_lb_226  11
    x_20_11   stock_ub_227  11
    x_20_11   parent_nonstrict_scope_228  3.7558677486276261e-02
    x_20_11   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_206  1
    w_20_11   product_ub_207  1
    w_20_11   normalized_mass_20_217  1
    w_20_11   normalized_ratio_20_218  -1.375
    w_20_11   full_original_Gini_286  -8.1464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_12   product_lb_208  -4.4823108802715707e-02
    x_20_12   product_ub_209  -1.1970927746912360e-01
    x_20_12   onehot_20_216  1
    x_20_12   stock_lb_226  12
    x_20_12   stock_ub_227  12
    x_20_12   parent_nonstrict_scope_228  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_208  1
    w_20_12   product_ub_209  1
    w_20_12   normalized_mass_20_217  1
    w_20_12   normalized_ratio_20_218  -1.5
    w_20_12   full_original_Gini_286  -9.6464285714285722e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_13   OBJ       1.2519559162092082e-02
    x_20_13   product_lb_210  -4.4823108802715707e-02
    x_20_13   product_ub_211  -1.1970927746912360e-01
    x_20_13   onehot_20_216  1
    x_20_13   stock_lb_226  13
    x_20_13   stock_ub_227  13
    x_20_13   parent_nonstrict_scope_228  6.2597795810460433e-02
    x_20_13   unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_13   product_lb_210  1
    w_20_13   product_ub_211  1
    w_20_13   normalized_mass_20_217  1
    w_20_13   normalized_ratio_20_218  -1.625
    w_20_13   full_original_Gini_286  -1.1146428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_14   OBJ       2.5039118324184172e-02
    x_20_14   product_lb_212  -4.4823108802715707e-02
    x_20_14   product_ub_213  -1.1970927746912360e-01
    x_20_14   onehot_20_216  1
    x_20_14   stock_lb_226  14
    x_20_14   stock_ub_227  14
    x_20_14   parent_nonstrict_scope_228  7.5117354972552522e-02
    x_20_14   unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_14   product_lb_212  1
    w_20_14   product_ub_213  1
    w_20_14   normalized_mass_20_217  1
    w_20_14   normalized_ratio_20_218  -1.75
    w_20_14   full_original_Gini_286  -1.2646428571428572e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_15   OBJ       3.7558677486276261e-02
    x_20_15   product_lb_214  -4.4823108802715707e-02
    x_20_15   product_ub_215  -1.1970927746912360e-01
    x_20_15   onehot_20_216  1
    x_20_15   stock_lb_226  15
    x_20_15   stock_ub_227  15
    x_20_15   parent_nonstrict_scope_228  8.7636914134644611e-02
    x_20_15   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_15   product_lb_214  1
    w_20_15   product_ub_215  1
    w_20_15   normalized_mass_20_217  1
    w_20_15   normalized_ratio_20_218  -1.875
    w_20_15   full_original_Gini_286  -1.4146428571428572e+01
    rho_20    normalized_ratio_20_218  1
    rho_20    block_pair_pos_233  1
    rho_20    block_pair_neg_234  -1
    rho_20    block_pair_pos_237  1
    rho_20    block_pair_neg_238  -1
    rho_20    block_pair_pos_251  1
    rho_20    block_pair_neg_252  -1
    rho_20    block_pair_pos_263  1
    rho_20    block_pair_neg_264  -1
    rho_20    block_pair_pos_271  1
    rho_20    block_pair_neg_272  -1
    rho_20    block_pair_pos_281  1
    rho_20    block_pair_neg_282  -1
    rho_20    block_pair_pos_283  -1
    rho_20    block_pair_neg_284  1
    rho_20    normalization_285  1
    MARKER    'MARKER'                 'INTORG'
    x_10_0    OBJ       6.3380304899829966e-03
    x_10_0    product_lb_219  -4.4823108802715707e-02
    x_10_0    product_ub_220  -1.1970927746912360e-01
    x_10_0    onehot_10_223  1
    x_10_0    parent_nonstrict_scope_228  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_10_0    product_lb_219  1
    w_10_0    product_ub_220  1
    w_10_0    normalized_mass_10_224  1
    w_10_0    full_original_Gini_286  -8.3535714285714278e+00
    MARKER    'MARKER'                 'INTORG'
    x_10_1    OBJ       -6.3380304899829966e-03
    x_10_1    product_lb_221  -4.4823108802715707e-02
    x_10_1    product_ub_222  -1.1970927746912360e-01
    x_10_1    onehot_10_223  1
    x_10_1    stock_lb_226  1
    x_10_1    stock_ub_227  1
    x_10_1    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_10_1    product_lb_221  1
    w_10_1    product_ub_222  1
    w_10_1    normalized_mass_10_224  1
    w_10_1    normalized_ratio_10_225  -1
    w_10_1    full_original_Gini_286  -3.8964285714285714e+00
    rho_10    normalized_ratio_10_225  1
    rho_10    block_pair_pos_229  1
    rho_10    block_pair_neg_230  -1
    rho_10    block_pair_pos_235  1
    rho_10    block_pair_neg_236  -1
    rho_10    block_pair_pos_239  1
    rho_10    block_pair_neg_240  -1
    rho_10    block_pair_pos_253  1
    rho_10    block_pair_neg_254  -1
    rho_10    block_pair_pos_265  1
    rho_10    block_pair_neg_266  -1
    rho_10    block_pair_pos_273  1
    rho_10    block_pair_neg_274  -1
    rho_10    block_pair_pos_283  1
    rho_10    block_pair_neg_284  -1
    rho_10    normalization_285  1
    a_13_14   block_pair_pos_245  1
    a_13_14   block_pair_neg_246  1
    a_13_14   full_original_Gini_286  -1
    a_13_18   block_pair_pos_249  1
    a_13_18   block_pair_neg_250  1
    a_13_18   full_original_Gini_286  -1
    a_13_17   block_pair_pos_247  1
    a_13_17   block_pair_neg_248  1
    a_13_17   full_original_Gini_286  -1
    a_13_11   block_pair_pos_241  1
    a_13_11   block_pair_neg_242  1
    a_13_11   full_original_Gini_286  -1
    a_13_12   block_pair_pos_243  1
    a_13_12   block_pair_neg_244  1
    a_13_12   full_original_Gini_286  -1
    a_13_20   block_pair_pos_251  1
    a_13_20   block_pair_neg_252  1
    a_13_20   full_original_Gini_286  -1
    a_13_10   block_pair_pos_239  1
    a_13_10   block_pair_neg_240  1
    a_13_10   full_original_Gini_286  -1
    a_14_18   block_pair_pos_261  1
    a_14_18   block_pair_neg_262  1
    a_14_18   full_original_Gini_286  -1
    a_14_17   block_pair_pos_259  1
    a_14_17   block_pair_neg_260  1
    a_14_17   full_original_Gini_286  -1
    a_14_11   block_pair_pos_255  1
    a_14_11   block_pair_neg_256  1
    a_14_11   full_original_Gini_286  -1
    a_14_12   block_pair_pos_257  1
    a_14_12   block_pair_neg_258  1
    a_14_12   full_original_Gini_286  -1
    a_14_20   block_pair_pos_263  1
    a_14_20   block_pair_neg_264  1
    a_14_20   full_original_Gini_286  -1
    a_14_10   block_pair_pos_253  1
    a_14_10   block_pair_neg_254  1
    a_14_10   full_original_Gini_286  -1
    a_18_17   block_pair_pos_279  1
    a_18_17   block_pair_neg_280  1
    a_18_17   full_original_Gini_286  -1
    a_18_11   block_pair_pos_275  1
    a_18_11   block_pair_neg_276  1
    a_18_11   full_original_Gini_286  -1
    a_18_12   block_pair_pos_277  1
    a_18_12   block_pair_neg_278  1
    a_18_12   full_original_Gini_286  -1
    a_18_20   block_pair_pos_281  1
    a_18_20   block_pair_neg_282  1
    a_18_20   full_original_Gini_286  -1
    a_18_10   block_pair_pos_273  1
    a_18_10   block_pair_neg_274  1
    a_18_10   full_original_Gini_286  -1
    a_17_11   block_pair_pos_267  1
    a_17_11   block_pair_neg_268  1
    a_17_11   full_original_Gini_286  -1
    a_17_12   block_pair_pos_269  1
    a_17_12   block_pair_neg_270  1
    a_17_12   full_original_Gini_286  -1
    a_17_20   block_pair_pos_271  1
    a_17_20   block_pair_neg_272  1
    a_17_20   full_original_Gini_286  -1
    a_17_10   block_pair_pos_265  1
    a_17_10   block_pair_neg_266  1
    a_17_10   full_original_Gini_286  -1
    a_11_12   block_pair_pos_231  1
    a_11_12   block_pair_neg_232  1
    a_11_12   full_original_Gini_286  -1
    a_11_20   block_pair_pos_233  1
    a_11_20   block_pair_neg_234  1
    a_11_20   full_original_Gini_286  -1
    a_11_10   block_pair_pos_229  1
    a_11_10   block_pair_neg_230  1
    a_11_10   full_original_Gini_286  -1
    a_12_20   block_pair_pos_237  1
    a_12_20   block_pair_neg_238  1
    a_12_20   full_original_Gini_286  -1
    a_12_10   block_pair_pos_235  1
    a_12_10   block_pair_neg_236  1
    a_12_10   full_original_Gini_286  -1
    a_20_10   block_pair_pos_283  1
    a_20_10   block_pair_neg_284  1
    a_20_10   full_original_Gini_286  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_13_1  unique_nonzero_owner_287  1
    service_0_13_1  service_visit_def_955  1
    service_0_13_1  free_load_conservation_956  1
    service_1_13_1  unique_nonzero_owner_287  1
    service_1_13_1  service_visit_def_1142  1
    service_1_13_1  free_load_conservation_1143  1
    service_0_14_0  unique_nonzero_owner_288  1
    service_0_14_0  service_visit_def_961  1
    service_0_14_0  free_load_conservation_962  -11
    service_0_14_0  original_T_including_depot_unload_1006  1320
    service_0_14_1  unique_nonzero_owner_289  1
    service_0_14_1  service_visit_def_961  1
    service_0_14_1  free_load_conservation_962  -10
    service_0_14_1  original_T_including_depot_unload_1006  1200
    service_0_14_2  unique_nonzero_owner_290  1
    service_0_14_2  service_visit_def_961  1
    service_0_14_2  free_load_conservation_962  -9
    service_0_14_2  original_T_including_depot_unload_1006  1080
    service_0_14_3  unique_nonzero_owner_291  1
    service_0_14_3  service_visit_def_961  1
    service_0_14_3  free_load_conservation_962  -8
    service_0_14_3  original_T_including_depot_unload_1006  960
    service_0_14_4  unique_nonzero_owner_292  1
    service_0_14_4  service_visit_def_961  1
    service_0_14_4  free_load_conservation_962  -7
    service_0_14_4  original_T_including_depot_unload_1006  840
    service_0_14_5  unique_nonzero_owner_293  1
    service_0_14_5  service_visit_def_961  1
    service_0_14_5  free_load_conservation_962  -6
    service_0_14_5  original_T_including_depot_unload_1006  720
    service_0_14_6  unique_nonzero_owner_294  1
    service_0_14_6  service_visit_def_961  1
    service_0_14_6  free_load_conservation_962  -5
    service_0_14_6  original_T_including_depot_unload_1006  600
    service_0_14_7  unique_nonzero_owner_295  1
    service_0_14_7  service_visit_def_961  1
    service_0_14_7  free_load_conservation_962  -4
    service_0_14_7  original_T_including_depot_unload_1006  480
    service_0_14_8  unique_nonzero_owner_296  1
    service_0_14_8  service_visit_def_961  1
    service_0_14_8  free_load_conservation_962  -3
    service_0_14_8  original_T_including_depot_unload_1006  360
    service_0_14_9  unique_nonzero_owner_297  1
    service_0_14_9  service_visit_def_961  1
    service_0_14_9  free_load_conservation_962  -2
    service_0_14_9  original_T_including_depot_unload_1006  240
    service_0_14_10  unique_nonzero_owner_298  1
    service_0_14_10  service_visit_def_961  1
    service_0_14_10  free_load_conservation_962  -1
    service_0_14_10  original_T_including_depot_unload_1006  120
    service_0_14_12  unique_nonzero_owner_299  1
    service_0_14_12  service_visit_def_961  1
    service_0_14_12  free_load_conservation_962  1
    service_0_14_13  unique_nonzero_owner_300  1
    service_0_14_13  service_visit_def_961  1
    service_0_14_13  free_load_conservation_962  2
    service_0_14_14  unique_nonzero_owner_301  1
    service_0_14_14  service_visit_def_961  1
    service_0_14_14  free_load_conservation_962  3
    service_0_14_15  unique_nonzero_owner_302  1
    service_0_14_15  service_visit_def_961  1
    service_0_14_15  free_load_conservation_962  4
    service_1_14_0  unique_nonzero_owner_288  1
    service_1_14_0  service_visit_def_1148  1
    service_1_14_0  free_load_conservation_1149  -11
    service_1_14_0  original_T_including_depot_unload_1186  1320
    service_1_14_1  unique_nonzero_owner_289  1
    service_1_14_1  service_visit_def_1148  1
    service_1_14_1  free_load_conservation_1149  -10
    service_1_14_1  original_T_including_depot_unload_1186  1200
    service_1_14_2  unique_nonzero_owner_290  1
    service_1_14_2  service_visit_def_1148  1
    service_1_14_2  free_load_conservation_1149  -9
    service_1_14_2  original_T_including_depot_unload_1186  1080
    service_1_14_3  unique_nonzero_owner_291  1
    service_1_14_3  service_visit_def_1148  1
    service_1_14_3  free_load_conservation_1149  -8
    service_1_14_3  original_T_including_depot_unload_1186  960
    service_1_14_4  unique_nonzero_owner_292  1
    service_1_14_4  service_visit_def_1148  1
    service_1_14_4  free_load_conservation_1149  -7
    service_1_14_4  original_T_including_depot_unload_1186  840
    service_1_14_5  unique_nonzero_owner_293  1
    service_1_14_5  service_visit_def_1148  1
    service_1_14_5  free_load_conservation_1149  -6
    service_1_14_5  original_T_including_depot_unload_1186  720
    service_1_14_6  unique_nonzero_owner_294  1
    service_1_14_6  service_visit_def_1148  1
    service_1_14_6  free_load_conservation_1149  -5
    service_1_14_6  original_T_including_depot_unload_1186  600
    service_1_14_7  unique_nonzero_owner_295  1
    service_1_14_7  service_visit_def_1148  1
    service_1_14_7  free_load_conservation_1149  -4
    service_1_14_7  original_T_including_depot_unload_1186  480
    service_1_14_8  unique_nonzero_owner_296  1
    service_1_14_8  service_visit_def_1148  1
    service_1_14_8  free_load_conservation_1149  -3
    service_1_14_8  original_T_including_depot_unload_1186  360
    service_1_14_9  unique_nonzero_owner_297  1
    service_1_14_9  service_visit_def_1148  1
    service_1_14_9  free_load_conservation_1149  -2
    service_1_14_9  original_T_including_depot_unload_1186  240
    service_1_14_10  unique_nonzero_owner_298  1
    service_1_14_10  service_visit_def_1148  1
    service_1_14_10  free_load_conservation_1149  -1
    service_1_14_10  original_T_including_depot_unload_1186  120
    service_1_14_12  unique_nonzero_owner_299  1
    service_1_14_12  service_visit_def_1148  1
    service_1_14_12  free_load_conservation_1149  1
    service_1_14_13  unique_nonzero_owner_300  1
    service_1_14_13  service_visit_def_1148  1
    service_1_14_13  free_load_conservation_1149  2
    service_1_14_14  unique_nonzero_owner_301  1
    service_1_14_14  service_visit_def_1148  1
    service_1_14_14  free_load_conservation_1149  3
    service_1_14_15  unique_nonzero_owner_302  1
    service_1_14_15  service_visit_def_1148  1
    service_1_14_15  free_load_conservation_1149  4
    service_0_18_1  unique_nonzero_owner_303  1
    service_0_18_1  service_visit_def_967  1
    service_0_18_1  free_load_conservation_968  1
    service_0_18_2  unique_nonzero_owner_304  1
    service_0_18_2  service_visit_def_967  1
    service_0_18_2  free_load_conservation_968  2
    service_0_18_3  unique_nonzero_owner_305  1
    service_0_18_3  service_visit_def_967  1
    service_0_18_3  free_load_conservation_968  3
    service_0_18_4  unique_nonzero_owner_306  1
    service_0_18_4  service_visit_def_967  1
    service_0_18_4  free_load_conservation_968  4
    service_0_18_5  unique_nonzero_owner_307  1
    service_0_18_5  service_visit_def_967  1
    service_0_18_5  free_load_conservation_968  5
    service_0_18_6  unique_nonzero_owner_308  1
    service_0_18_6  service_visit_def_967  1
    service_0_18_6  free_load_conservation_968  6
    service_0_18_7  unique_nonzero_owner_309  1
    service_0_18_7  service_visit_def_967  1
    service_0_18_7  free_load_conservation_968  7
    service_0_18_8  unique_nonzero_owner_310  1
    service_0_18_8  service_visit_def_967  1
    service_0_18_8  free_load_conservation_968  8
    service_0_18_9  unique_nonzero_owner_311  1
    service_0_18_9  service_visit_def_967  1
    service_0_18_9  free_load_conservation_968  9
    service_0_18_10  unique_nonzero_owner_312  1
    service_0_18_10  service_visit_def_967  1
    service_0_18_10  free_load_conservation_968  10
    service_0_18_11  unique_nonzero_owner_313  1
    service_0_18_11  service_visit_def_967  1
    service_0_18_11  free_load_conservation_968  11
    service_0_18_12  unique_nonzero_owner_314  1
    service_0_18_12  service_visit_def_967  1
    service_0_18_12  free_load_conservation_968  12
    service_0_18_13  unique_nonzero_owner_315  1
    service_0_18_13  service_visit_def_967  1
    service_0_18_13  free_load_conservation_968  13
    service_0_18_14  unique_nonzero_owner_316  1
    service_0_18_14  service_visit_def_967  1
    service_0_18_14  free_load_conservation_968  14
    service_0_18_15  unique_nonzero_owner_317  1
    service_0_18_15  service_visit_def_967  1
    service_0_18_15  free_load_conservation_968  15
    service_1_18_1  unique_nonzero_owner_303  1
    service_1_18_1  service_visit_def_1154  1
    service_1_18_1  free_load_conservation_1155  1
    service_1_18_2  unique_nonzero_owner_304  1
    service_1_18_2  service_visit_def_1154  1
    service_1_18_2  free_load_conservation_1155  2
    service_1_18_3  unique_nonzero_owner_305  1
    service_1_18_3  service_visit_def_1154  1
    service_1_18_3  free_load_conservation_1155  3
    service_1_18_4  unique_nonzero_owner_306  1
    service_1_18_4  service_visit_def_1154  1
    service_1_18_4  free_load_conservation_1155  4
    service_1_18_5  unique_nonzero_owner_307  1
    service_1_18_5  service_visit_def_1154  1
    service_1_18_5  free_load_conservation_1155  5
    service_1_18_6  unique_nonzero_owner_308  1
    service_1_18_6  service_visit_def_1154  1
    service_1_18_6  free_load_conservation_1155  6
    service_1_18_7  unique_nonzero_owner_309  1
    service_1_18_7  service_visit_def_1154  1
    service_1_18_7  free_load_conservation_1155  7
    service_1_18_8  unique_nonzero_owner_310  1
    service_1_18_8  service_visit_def_1154  1
    service_1_18_8  free_load_conservation_1155  8
    service_1_18_9  unique_nonzero_owner_311  1
    service_1_18_9  service_visit_def_1154  1
    service_1_18_9  free_load_conservation_1155  9
    service_1_18_10  unique_nonzero_owner_312  1
    service_1_18_10  service_visit_def_1154  1
    service_1_18_10  free_load_conservation_1155  10
    service_1_18_11  unique_nonzero_owner_313  1
    service_1_18_11  service_visit_def_1154  1
    service_1_18_11  free_load_conservation_1155  11
    service_1_18_12  unique_nonzero_owner_314  1
    service_1_18_12  service_visit_def_1154  1
    service_1_18_12  free_load_conservation_1155  12
    service_1_18_13  unique_nonzero_owner_315  1
    service_1_18_13  service_visit_def_1154  1
    service_1_18_13  free_load_conservation_1155  13
    service_1_18_14  unique_nonzero_owner_316  1
    service_1_18_14  service_visit_def_1154  1
    service_1_18_14  free_load_conservation_1155  14
    service_1_18_15  unique_nonzero_owner_317  1
    service_1_18_15  service_visit_def_1154  1
    service_1_18_15  free_load_conservation_1155  15
    service_0_17_0  unique_nonzero_owner_318  1
    service_0_17_0  service_visit_def_973  1
    service_0_17_0  free_load_conservation_974  -3
    service_0_17_0  original_T_including_depot_unload_1006  360
    service_0_17_1  unique_nonzero_owner_319  1
    service_0_17_1  service_visit_def_973  1
    service_0_17_1  free_load_conservation_974  -2
    service_0_17_1  original_T_including_depot_unload_1006  240
    service_0_17_2  unique_nonzero_owner_320  1
    service_0_17_2  service_visit_def_973  1
    service_0_17_2  free_load_conservation_974  -1
    service_0_17_2  original_T_including_depot_unload_1006  120
    service_0_17_4  unique_nonzero_owner_321  1
    service_0_17_4  service_visit_def_973  1
    service_0_17_4  free_load_conservation_974  1
    service_0_17_5  unique_nonzero_owner_322  1
    service_0_17_5  service_visit_def_973  1
    service_0_17_5  free_load_conservation_974  2
    service_0_17_6  unique_nonzero_owner_323  1
    service_0_17_6  service_visit_def_973  1
    service_0_17_6  free_load_conservation_974  3
    service_0_17_7  unique_nonzero_owner_324  1
    service_0_17_7  service_visit_def_973  1
    service_0_17_7  free_load_conservation_974  4
    service_0_17_8  unique_nonzero_owner_325  1
    service_0_17_8  service_visit_def_973  1
    service_0_17_8  free_load_conservation_974  5
    service_0_17_9  unique_nonzero_owner_326  1
    service_0_17_9  service_visit_def_973  1
    service_0_17_9  free_load_conservation_974  6
    service_0_17_10  unique_nonzero_owner_327  1
    service_0_17_10  service_visit_def_973  1
    service_0_17_10  free_load_conservation_974  7
    service_0_17_11  unique_nonzero_owner_328  1
    service_0_17_11  service_visit_def_973  1
    service_0_17_11  free_load_conservation_974  8
    service_0_17_12  unique_nonzero_owner_329  1
    service_0_17_12  service_visit_def_973  1
    service_0_17_12  free_load_conservation_974  9
    service_0_17_13  unique_nonzero_owner_330  1
    service_0_17_13  service_visit_def_973  1
    service_0_17_13  free_load_conservation_974  10
    service_0_17_14  unique_nonzero_owner_331  1
    service_0_17_14  service_visit_def_973  1
    service_0_17_14  free_load_conservation_974  11
    service_0_17_15  unique_nonzero_owner_332  1
    service_0_17_15  service_visit_def_973  1
    service_0_17_15  free_load_conservation_974  12
    service_0_17_16  unique_nonzero_owner_333  1
    service_0_17_16  service_visit_def_973  1
    service_0_17_16  free_load_conservation_974  13
    service_1_17_0  unique_nonzero_owner_318  1
    service_1_17_0  service_visit_def_1160  1
    service_1_17_0  free_load_conservation_1161  -3
    service_1_17_0  original_T_including_depot_unload_1186  360
    service_1_17_1  unique_nonzero_owner_319  1
    service_1_17_1  service_visit_def_1160  1
    service_1_17_1  free_load_conservation_1161  -2
    service_1_17_1  original_T_including_depot_unload_1186  240
    service_1_17_2  unique_nonzero_owner_320  1
    service_1_17_2  service_visit_def_1160  1
    service_1_17_2  free_load_conservation_1161  -1
    service_1_17_2  original_T_including_depot_unload_1186  120
    service_1_17_4  unique_nonzero_owner_321  1
    service_1_17_4  service_visit_def_1160  1
    service_1_17_4  free_load_conservation_1161  1
    service_1_17_5  unique_nonzero_owner_322  1
    service_1_17_5  service_visit_def_1160  1
    service_1_17_5  free_load_conservation_1161  2
    service_1_17_6  unique_nonzero_owner_323  1
    service_1_17_6  service_visit_def_1160  1
    service_1_17_6  free_load_conservation_1161  3
    service_1_17_7  unique_nonzero_owner_324  1
    service_1_17_7  service_visit_def_1160  1
    service_1_17_7  free_load_conservation_1161  4
    service_1_17_8  unique_nonzero_owner_325  1
    service_1_17_8  service_visit_def_1160  1
    service_1_17_8  free_load_conservation_1161  5
    service_1_17_9  unique_nonzero_owner_326  1
    service_1_17_9  service_visit_def_1160  1
    service_1_17_9  free_load_conservation_1161  6
    service_1_17_10  unique_nonzero_owner_327  1
    service_1_17_10  service_visit_def_1160  1
    service_1_17_10  free_load_conservation_1161  7
    service_1_17_11  unique_nonzero_owner_328  1
    service_1_17_11  service_visit_def_1160  1
    service_1_17_11  free_load_conservation_1161  8
    service_1_17_12  unique_nonzero_owner_329  1
    service_1_17_12  service_visit_def_1160  1
    service_1_17_12  free_load_conservation_1161  9
    service_1_17_13  unique_nonzero_owner_330  1
    service_1_17_13  service_visit_def_1160  1
    service_1_17_13  free_load_conservation_1161  10
    service_1_17_14  unique_nonzero_owner_331  1
    service_1_17_14  service_visit_def_1160  1
    service_1_17_14  free_load_conservation_1161  11
    service_1_17_15  unique_nonzero_owner_332  1
    service_1_17_15  service_visit_def_1160  1
    service_1_17_15  free_load_conservation_1161  12
    service_1_17_16  unique_nonzero_owner_333  1
    service_1_17_16  service_visit_def_1160  1
    service_1_17_16  free_load_conservation_1161  13
    service_0_11_0  unique_nonzero_owner_334  1
    service_0_11_0  service_visit_def_979  1
    service_0_11_0  free_load_conservation_980  -1
    service_0_11_0  original_T_including_depot_unload_1006  120
    service_0_11_2  unique_nonzero_owner_335  1
    service_0_11_2  service_visit_def_979  1
    service_0_11_2  free_load_conservation_980  1
    service_0_11_3  unique_nonzero_owner_336  1
    service_0_11_3  service_visit_def_979  1
    service_0_11_3  free_load_conservation_980  2
    service_0_11_4  unique_nonzero_owner_337  1
    service_0_11_4  service_visit_def_979  1
    service_0_11_4  free_load_conservation_980  3
    service_0_11_5  unique_nonzero_owner_338  1
    service_0_11_5  service_visit_def_979  1
    service_0_11_5  free_load_conservation_980  4
    service_0_11_6  unique_nonzero_owner_339  1
    service_0_11_6  service_visit_def_979  1
    service_0_11_6  free_load_conservation_980  5
    service_0_11_7  unique_nonzero_owner_340  1
    service_0_11_7  service_visit_def_979  1
    service_0_11_7  free_load_conservation_980  6
    service_0_11_8  unique_nonzero_owner_341  1
    service_0_11_8  service_visit_def_979  1
    service_0_11_8  free_load_conservation_980  7
    service_0_11_9  unique_nonzero_owner_342  1
    service_0_11_9  service_visit_def_979  1
    service_0_11_9  free_load_conservation_980  8
    service_0_11_10  unique_nonzero_owner_343  1
    service_0_11_10  service_visit_def_979  1
    service_0_11_10  free_load_conservation_980  9
    service_0_11_11  unique_nonzero_owner_344  1
    service_0_11_11  service_visit_def_979  1
    service_0_11_11  free_load_conservation_980  10
    service_0_11_12  unique_nonzero_owner_345  1
    service_0_11_12  service_visit_def_979  1
    service_0_11_12  free_load_conservation_980  11
    service_0_11_13  unique_nonzero_owner_346  1
    service_0_11_13  service_visit_def_979  1
    service_0_11_13  free_load_conservation_980  12
    service_0_11_14  unique_nonzero_owner_347  1
    service_0_11_14  service_visit_def_979  1
    service_0_11_14  free_load_conservation_980  13
    service_0_11_15  unique_nonzero_owner_348  1
    service_0_11_15  service_visit_def_979  1
    service_0_11_15  free_load_conservation_980  14
    service_1_11_0  unique_nonzero_owner_334  1
    service_1_11_0  service_visit_def_1166  1
    service_1_11_0  free_load_conservation_1167  -1
    service_1_11_0  original_T_including_depot_unload_1186  120
    service_1_11_2  unique_nonzero_owner_335  1
    service_1_11_2  service_visit_def_1166  1
    service_1_11_2  free_load_conservation_1167  1
    service_1_11_3  unique_nonzero_owner_336  1
    service_1_11_3  service_visit_def_1166  1
    service_1_11_3  free_load_conservation_1167  2
    service_1_11_4  unique_nonzero_owner_337  1
    service_1_11_4  service_visit_def_1166  1
    service_1_11_4  free_load_conservation_1167  3
    service_1_11_5  unique_nonzero_owner_338  1
    service_1_11_5  service_visit_def_1166  1
    service_1_11_5  free_load_conservation_1167  4
    service_1_11_6  unique_nonzero_owner_339  1
    service_1_11_6  service_visit_def_1166  1
    service_1_11_6  free_load_conservation_1167  5
    service_1_11_7  unique_nonzero_owner_340  1
    service_1_11_7  service_visit_def_1166  1
    service_1_11_7  free_load_conservation_1167  6
    service_1_11_8  unique_nonzero_owner_341  1
    service_1_11_8  service_visit_def_1166  1
    service_1_11_8  free_load_conservation_1167  7
    service_1_11_9  unique_nonzero_owner_342  1
    service_1_11_9  service_visit_def_1166  1
    service_1_11_9  free_load_conservation_1167  8
    service_1_11_10  unique_nonzero_owner_343  1
    service_1_11_10  service_visit_def_1166  1
    service_1_11_10  free_load_conservation_1167  9
    service_1_11_11  unique_nonzero_owner_344  1
    service_1_11_11  service_visit_def_1166  1
    service_1_11_11  free_load_conservation_1167  10
    service_1_11_12  unique_nonzero_owner_345  1
    service_1_11_12  service_visit_def_1166  1
    service_1_11_12  free_load_conservation_1167  11
    service_1_11_13  unique_nonzero_owner_346  1
    service_1_11_13  service_visit_def_1166  1
    service_1_11_13  free_load_conservation_1167  12
    service_1_11_14  unique_nonzero_owner_347  1
    service_1_11_14  service_visit_def_1166  1
    service_1_11_14  free_load_conservation_1167  13
    service_1_11_15  unique_nonzero_owner_348  1
    service_1_11_15  service_visit_def_1166  1
    service_1_11_15  free_load_conservation_1167  14
    service_0_12_0  unique_nonzero_owner_349  1
    service_0_12_0  service_visit_def_985  1
    service_0_12_0  free_load_conservation_986  -11
    service_0_12_0  original_T_including_depot_unload_1006  1320
    service_0_12_1  unique_nonzero_owner_350  1
    service_0_12_1  service_visit_def_985  1
    service_0_12_1  free_load_conservation_986  -10
    service_0_12_1  original_T_including_depot_unload_1006  1200
    service_0_12_2  unique_nonzero_owner_351  1
    service_0_12_2  service_visit_def_985  1
    service_0_12_2  free_load_conservation_986  -9
    service_0_12_2  original_T_including_depot_unload_1006  1080
    service_0_12_3  unique_nonzero_owner_352  1
    service_0_12_3  service_visit_def_985  1
    service_0_12_3  free_load_conservation_986  -8
    service_0_12_3  original_T_including_depot_unload_1006  960
    service_0_12_4  unique_nonzero_owner_353  1
    service_0_12_4  service_visit_def_985  1
    service_0_12_4  free_load_conservation_986  -7
    service_0_12_4  original_T_including_depot_unload_1006  840
    service_0_12_5  unique_nonzero_owner_354  1
    service_0_12_5  service_visit_def_985  1
    service_0_12_5  free_load_conservation_986  -6
    service_0_12_5  original_T_including_depot_unload_1006  720
    service_0_12_6  unique_nonzero_owner_355  1
    service_0_12_6  service_visit_def_985  1
    service_0_12_6  free_load_conservation_986  -5
    service_0_12_6  original_T_including_depot_unload_1006  600
    service_0_12_7  unique_nonzero_owner_356  1
    service_0_12_7  service_visit_def_985  1
    service_0_12_7  free_load_conservation_986  -4
    service_0_12_7  original_T_including_depot_unload_1006  480
    service_0_12_8  unique_nonzero_owner_357  1
    service_0_12_8  service_visit_def_985  1
    service_0_12_8  free_load_conservation_986  -3
    service_0_12_8  original_T_including_depot_unload_1006  360
    service_0_12_9  unique_nonzero_owner_358  1
    service_0_12_9  service_visit_def_985  1
    service_0_12_9  free_load_conservation_986  -2
    service_0_12_9  original_T_including_depot_unload_1006  240
    service_0_12_10  unique_nonzero_owner_359  1
    service_0_12_10  service_visit_def_985  1
    service_0_12_10  free_load_conservation_986  -1
    service_0_12_10  original_T_including_depot_unload_1006  120
    service_0_12_12  unique_nonzero_owner_360  1
    service_0_12_12  service_visit_def_985  1
    service_0_12_12  free_load_conservation_986  1
    service_0_12_13  unique_nonzero_owner_361  1
    service_0_12_13  service_visit_def_985  1
    service_0_12_13  free_load_conservation_986  2
    service_0_12_14  unique_nonzero_owner_362  1
    service_0_12_14  service_visit_def_985  1
    service_0_12_14  free_load_conservation_986  3
    service_0_12_15  unique_nonzero_owner_363  1
    service_0_12_15  service_visit_def_985  1
    service_0_12_15  free_load_conservation_986  4
    service_1_12_0  unique_nonzero_owner_349  1
    service_1_12_0  service_visit_def_1172  1
    service_1_12_0  free_load_conservation_1173  -11
    service_1_12_0  original_T_including_depot_unload_1186  1320
    service_1_12_1  unique_nonzero_owner_350  1
    service_1_12_1  service_visit_def_1172  1
    service_1_12_1  free_load_conservation_1173  -10
    service_1_12_1  original_T_including_depot_unload_1186  1200
    service_1_12_2  unique_nonzero_owner_351  1
    service_1_12_2  service_visit_def_1172  1
    service_1_12_2  free_load_conservation_1173  -9
    service_1_12_2  original_T_including_depot_unload_1186  1080
    service_1_12_3  unique_nonzero_owner_352  1
    service_1_12_3  service_visit_def_1172  1
    service_1_12_3  free_load_conservation_1173  -8
    service_1_12_3  original_T_including_depot_unload_1186  960
    service_1_12_4  unique_nonzero_owner_353  1
    service_1_12_4  service_visit_def_1172  1
    service_1_12_4  free_load_conservation_1173  -7
    service_1_12_4  original_T_including_depot_unload_1186  840
    service_1_12_5  unique_nonzero_owner_354  1
    service_1_12_5  service_visit_def_1172  1
    service_1_12_5  free_load_conservation_1173  -6
    service_1_12_5  original_T_including_depot_unload_1186  720
    service_1_12_6  unique_nonzero_owner_355  1
    service_1_12_6  service_visit_def_1172  1
    service_1_12_6  free_load_conservation_1173  -5
    service_1_12_6  original_T_including_depot_unload_1186  600
    service_1_12_7  unique_nonzero_owner_356  1
    service_1_12_7  service_visit_def_1172  1
    service_1_12_7  free_load_conservation_1173  -4
    service_1_12_7  original_T_including_depot_unload_1186  480
    service_1_12_8  unique_nonzero_owner_357  1
    service_1_12_8  service_visit_def_1172  1
    service_1_12_8  free_load_conservation_1173  -3
    service_1_12_8  original_T_including_depot_unload_1186  360
    service_1_12_9  unique_nonzero_owner_358  1
    service_1_12_9  service_visit_def_1172  1
    service_1_12_9  free_load_conservation_1173  -2
    service_1_12_9  original_T_including_depot_unload_1186  240
    service_1_12_10  unique_nonzero_owner_359  1
    service_1_12_10  service_visit_def_1172  1
    service_1_12_10  free_load_conservation_1173  -1
    service_1_12_10  original_T_including_depot_unload_1186  120
    service_1_12_12  unique_nonzero_owner_360  1
    service_1_12_12  service_visit_def_1172  1
    service_1_12_12  free_load_conservation_1173  1
    service_1_12_13  unique_nonzero_owner_361  1
    service_1_12_13  service_visit_def_1172  1
    service_1_12_13  free_load_conservation_1173  2
    service_1_12_14  unique_nonzero_owner_362  1
    service_1_12_14  service_visit_def_1172  1
    service_1_12_14  free_load_conservation_1173  3
    service_1_12_15  unique_nonzero_owner_363  1
    service_1_12_15  service_visit_def_1172  1
    service_1_12_15  free_load_conservation_1173  4
    service_0_20_0  unique_nonzero_owner_364  1
    service_0_20_0  service_visit_def_991  1
    service_0_20_0  free_load_conservation_992  -12
    service_0_20_0  original_T_including_depot_unload_1006  1440
    service_0_20_1  unique_nonzero_owner_365  1
    service_0_20_1  service_visit_def_991  1
    service_0_20_1  free_load_conservation_992  -11
    service_0_20_1  original_T_including_depot_unload_1006  1320
    service_0_20_2  unique_nonzero_owner_366  1
    service_0_20_2  service_visit_def_991  1
    service_0_20_2  free_load_conservation_992  -10
    service_0_20_2  original_T_including_depot_unload_1006  1200
    service_0_20_3  unique_nonzero_owner_367  1
    service_0_20_3  service_visit_def_991  1
    service_0_20_3  free_load_conservation_992  -9
    service_0_20_3  original_T_including_depot_unload_1006  1080
    service_0_20_4  unique_nonzero_owner_368  1
    service_0_20_4  service_visit_def_991  1
    service_0_20_4  free_load_conservation_992  -8
    service_0_20_4  original_T_including_depot_unload_1006  960
    service_0_20_5  unique_nonzero_owner_369  1
    service_0_20_5  service_visit_def_991  1
    service_0_20_5  free_load_conservation_992  -7
    service_0_20_5  original_T_including_depot_unload_1006  840
    service_0_20_6  unique_nonzero_owner_370  1
    service_0_20_6  service_visit_def_991  1
    service_0_20_6  free_load_conservation_992  -6
    service_0_20_6  original_T_including_depot_unload_1006  720
    service_0_20_7  unique_nonzero_owner_371  1
    service_0_20_7  service_visit_def_991  1
    service_0_20_7  free_load_conservation_992  -5
    service_0_20_7  original_T_including_depot_unload_1006  600
    service_0_20_8  unique_nonzero_owner_372  1
    service_0_20_8  service_visit_def_991  1
    service_0_20_8  free_load_conservation_992  -4
    service_0_20_8  original_T_including_depot_unload_1006  480
    service_0_20_9  unique_nonzero_owner_373  1
    service_0_20_9  service_visit_def_991  1
    service_0_20_9  free_load_conservation_992  -3
    service_0_20_9  original_T_including_depot_unload_1006  360
    service_0_20_10  unique_nonzero_owner_374  1
    service_0_20_10  service_visit_def_991  1
    service_0_20_10  free_load_conservation_992  -2
    service_0_20_10  original_T_including_depot_unload_1006  240
    service_0_20_11  unique_nonzero_owner_375  1
    service_0_20_11  service_visit_def_991  1
    service_0_20_11  free_load_conservation_992  -1
    service_0_20_11  original_T_including_depot_unload_1006  120
    service_0_20_13  unique_nonzero_owner_376  1
    service_0_20_13  service_visit_def_991  1
    service_0_20_13  free_load_conservation_992  1
    service_0_20_14  unique_nonzero_owner_377  1
    service_0_20_14  service_visit_def_991  1
    service_0_20_14  free_load_conservation_992  2
    service_0_20_15  unique_nonzero_owner_378  1
    service_0_20_15  service_visit_def_991  1
    service_0_20_15  free_load_conservation_992  3
    service_1_20_0  unique_nonzero_owner_364  1
    service_1_20_0  service_visit_def_1178  1
    service_1_20_0  free_load_conservation_1179  -12
    service_1_20_0  original_T_including_depot_unload_1186  1440
    service_1_20_1  unique_nonzero_owner_365  1
    service_1_20_1  service_visit_def_1178  1
    service_1_20_1  free_load_conservation_1179  -11
    service_1_20_1  original_T_including_depot_unload_1186  1320
    service_1_20_2  unique_nonzero_owner_366  1
    service_1_20_2  service_visit_def_1178  1
    service_1_20_2  free_load_conservation_1179  -10
    service_1_20_2  original_T_including_depot_unload_1186  1200
    service_1_20_3  unique_nonzero_owner_367  1
    service_1_20_3  service_visit_def_1178  1
    service_1_20_3  free_load_conservation_1179  -9
    service_1_20_3  original_T_including_depot_unload_1186  1080
    service_1_20_4  unique_nonzero_owner_368  1
    service_1_20_4  service_visit_def_1178  1
    service_1_20_4  free_load_conservation_1179  -8
    service_1_20_4  original_T_including_depot_unload_1186  960
    service_1_20_5  unique_nonzero_owner_369  1
    service_1_20_5  service_visit_def_1178  1
    service_1_20_5  free_load_conservation_1179  -7
    service_1_20_5  original_T_including_depot_unload_1186  840
    service_1_20_6  unique_nonzero_owner_370  1
    service_1_20_6  service_visit_def_1178  1
    service_1_20_6  free_load_conservation_1179  -6
    service_1_20_6  original_T_including_depot_unload_1186  720
    service_1_20_7  unique_nonzero_owner_371  1
    service_1_20_7  service_visit_def_1178  1
    service_1_20_7  free_load_conservation_1179  -5
    service_1_20_7  original_T_including_depot_unload_1186  600
    service_1_20_8  unique_nonzero_owner_372  1
    service_1_20_8  service_visit_def_1178  1
    service_1_20_8  free_load_conservation_1179  -4
    service_1_20_8  original_T_including_depot_unload_1186  480
    service_1_20_9  unique_nonzero_owner_373  1
    service_1_20_9  service_visit_def_1178  1
    service_1_20_9  free_load_conservation_1179  -3
    service_1_20_9  original_T_including_depot_unload_1186  360
    service_1_20_10  unique_nonzero_owner_374  1
    service_1_20_10  service_visit_def_1178  1
    service_1_20_10  free_load_conservation_1179  -2
    service_1_20_10  original_T_including_depot_unload_1186  240
    service_1_20_11  unique_nonzero_owner_375  1
    service_1_20_11  service_visit_def_1178  1
    service_1_20_11  free_load_conservation_1179  -1
    service_1_20_11  original_T_including_depot_unload_1186  120
    service_1_20_13  unique_nonzero_owner_376  1
    service_1_20_13  service_visit_def_1178  1
    service_1_20_13  free_load_conservation_1179  1
    service_1_20_14  unique_nonzero_owner_377  1
    service_1_20_14  service_visit_def_1178  1
    service_1_20_14  free_load_conservation_1179  2
    service_1_20_15  unique_nonzero_owner_378  1
    service_1_20_15  service_visit_def_1178  1
    service_1_20_15  free_load_conservation_1179  3
    service_0_10_1  unique_nonzero_owner_379  1
    service_0_10_1  service_visit_def_997  1
    service_0_10_1  free_load_conservation_998  1
    service_1_10_1  unique_nonzero_owner_379  1
    service_1_10_1  service_visit_def_1184  1
    service_1_10_1  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_895  -1
    visit_0_1  in_degree_896  -1
    visit_0_1  order_active_lb_897  -1
    visit_0_1  order_active_ub_898  -16
    order_0_1  connected_order_arc_399  -1
    order_0_1  connected_order_arc_401  -1
    order_0_1  connected_order_arc_403  -1
    order_0_1  connected_order_arc_405  -1
    order_0_1  connected_order_arc_407  -1
    order_0_1  connected_order_arc_409  -1
    order_0_1  connected_order_arc_411  -1
    order_0_1  connected_order_arc_413  -1
    order_0_1  connected_order_arc_415  -1
    order_0_1  connected_order_arc_417  -1
    order_0_1  connected_order_arc_419  -1
    order_0_1  connected_order_arc_421  -1
    order_0_1  connected_order_arc_423  -1
    order_0_1  connected_order_arc_425  -1
    order_0_1  connected_order_arc_427  -1
    order_0_1  connected_order_arc_430  1
    order_0_1  connected_order_arc_461  1
    order_0_1  connected_order_arc_492  1
    order_0_1  connected_order_arc_523  1
    order_0_1  connected_order_arc_554  1
    order_0_1  connected_order_arc_585  1
    order_0_1  connected_order_arc_616  1
    order_0_1  connected_order_arc_647  1
    order_0_1  connected_order_arc_678  1
    order_0_1  connected_order_arc_709  1
    order_0_1  connected_order_arc_740  1
    order_0_1  connected_order_arc_771  1
    order_0_1  connected_order_arc_802  1
    order_0_1  connected_order_arc_833  1
    order_0_1  connected_order_arc_864  1
    order_0_1  order_active_lb_897  1
    order_0_1  order_active_ub_898  1
    order_0_1  fixed_segment_relative_order_999  -1
    visit_0_2  out_degree_902  -1
    visit_0_2  in_degree_903  -1
    visit_0_2  order_active_lb_904  -1
    visit_0_2  order_active_ub_905  -16
    order_0_2  connected_order_arc_399  1
    order_0_2  connected_order_arc_430  -1
    order_0_2  connected_order_arc_432  -1
    order_0_2  connected_order_arc_434  -1
    order_0_2  connected_order_arc_436  -1
    order_0_2  connected_order_arc_438  -1
    order_0_2  connected_order_arc_440  -1
    order_0_2  connected_order_arc_442  -1
    order_0_2  connected_order_arc_444  -1
    order_0_2  connected_order_arc_446  -1
    order_0_2  connected_order_arc_448  -1
    order_0_2  connected_order_arc_450  -1
    order_0_2  connected_order_arc_452  -1
    order_0_2  connected_order_arc_454  -1
    order_0_2  connected_order_arc_456  -1
    order_0_2  connected_order_arc_458  -1
    order_0_2  connected_order_arc_463  1
    order_0_2  connected_order_arc_494  1
    order_0_2  connected_order_arc_525  1
    order_0_2  connected_order_arc_556  1
    order_0_2  connected_order_arc_587  1
    order_0_2  connected_order_arc_618  1
    order_0_2  connected_order_arc_649  1
    order_0_2  connected_order_arc_680  1
    order_0_2  connected_order_arc_711  1
    order_0_2  connected_order_arc_742  1
    order_0_2  connected_order_arc_773  1
    order_0_2  connected_order_arc_804  1
    order_0_2  connected_order_arc_835  1
    order_0_2  connected_order_arc_866  1
    order_0_2  order_active_lb_904  1
    order_0_2  order_active_ub_905  1
    order_0_2  fixed_segment_relative_order_999  1
    order_0_2  fixed_segment_relative_order_1000  -1
    visit_0_3  out_degree_909  -1
    visit_0_3  in_degree_910  -1
    visit_0_3  order_active_lb_911  -1
    visit_0_3  order_active_ub_912  -16
    order_0_3  connected_order_arc_401  1
    order_0_3  connected_order_arc_432  1
    order_0_3  connected_order_arc_461  -1
    order_0_3  connected_order_arc_463  -1
    order_0_3  connected_order_arc_465  -1
    order_0_3  connected_order_arc_467  -1
    order_0_3  connected_order_arc_469  -1
    order_0_3  connected_order_arc_471  -1
    order_0_3  connected_order_arc_473  -1
    order_0_3  connected_order_arc_475  -1
    order_0_3  connected_order_arc_477  -1
    order_0_3  connected_order_arc_479  -1
    order_0_3  connected_order_arc_481  -1
    order_0_3  connected_order_arc_483  -1
    order_0_3  connected_order_arc_485  -1
    order_0_3  connected_order_arc_487  -1
    order_0_3  connected_order_arc_489  -1
    order_0_3  connected_order_arc_496  1
    order_0_3  connected_order_arc_527  1
    order_0_3  connected_order_arc_558  1
    order_0_3  connected_order_arc_589  1
    order_0_3  connected_order_arc_620  1
    order_0_3  connected_order_arc_651  1
    order_0_3  connected_order_arc_682  1
    order_0_3  connected_order_arc_713  1
    order_0_3  connected_order_arc_744  1
    order_0_3  connected_order_arc_775  1
    order_0_3  connected_order_arc_806  1
    order_0_3  connected_order_arc_837  1
    order_0_3  connected_order_arc_868  1
    order_0_3  order_active_lb_911  1
    order_0_3  order_active_ub_912  1
    order_0_3  fixed_segment_relative_order_1000  1
    order_0_3  fixed_segment_relative_order_1001  -1
    visit_0_4  out_degree_916  -1
    visit_0_4  in_degree_917  -1
    visit_0_4  order_active_lb_918  -1
    visit_0_4  order_active_ub_919  -16
    order_0_4  connected_order_arc_403  1
    order_0_4  connected_order_arc_434  1
    order_0_4  connected_order_arc_465  1
    order_0_4  connected_order_arc_492  -1
    order_0_4  connected_order_arc_494  -1
    order_0_4  connected_order_arc_496  -1
    order_0_4  connected_order_arc_498  -1
    order_0_4  connected_order_arc_500  -1
    order_0_4  connected_order_arc_502  -1
    order_0_4  connected_order_arc_504  -1
    order_0_4  connected_order_arc_506  -1
    order_0_4  connected_order_arc_508  -1
    order_0_4  connected_order_arc_510  -1
    order_0_4  connected_order_arc_512  -1
    order_0_4  connected_order_arc_514  -1
    order_0_4  connected_order_arc_516  -1
    order_0_4  connected_order_arc_518  -1
    order_0_4  connected_order_arc_520  -1
    order_0_4  connected_order_arc_529  1
    order_0_4  connected_order_arc_560  1
    order_0_4  connected_order_arc_591  1
    order_0_4  connected_order_arc_622  1
    order_0_4  connected_order_arc_653  1
    order_0_4  connected_order_arc_684  1
    order_0_4  connected_order_arc_715  1
    order_0_4  connected_order_arc_746  1
    order_0_4  connected_order_arc_777  1
    order_0_4  connected_order_arc_808  1
    order_0_4  connected_order_arc_839  1
    order_0_4  connected_order_arc_870  1
    order_0_4  order_active_lb_918  1
    order_0_4  order_active_ub_919  1
    order_0_4  fixed_segment_relative_order_1001  1
    order_0_4  fixed_segment_relative_order_1002  -1
    visit_0_5  out_degree_923  -1
    visit_0_5  in_degree_924  -1
    visit_0_5  order_active_lb_925  -1
    visit_0_5  order_active_ub_926  -16
    order_0_5  connected_order_arc_405  1
    order_0_5  connected_order_arc_436  1
    order_0_5  connected_order_arc_467  1
    order_0_5  connected_order_arc_498  1
    order_0_5  connected_order_arc_523  -1
    order_0_5  connected_order_arc_525  -1
    order_0_5  connected_order_arc_527  -1
    order_0_5  connected_order_arc_529  -1
    order_0_5  connected_order_arc_531  -1
    order_0_5  connected_order_arc_533  -1
    order_0_5  connected_order_arc_535  -1
    order_0_5  connected_order_arc_537  -1
    order_0_5  connected_order_arc_539  -1
    order_0_5  connected_order_arc_541  -1
    order_0_5  connected_order_arc_543  -1
    order_0_5  connected_order_arc_545  -1
    order_0_5  connected_order_arc_547  -1
    order_0_5  connected_order_arc_549  -1
    order_0_5  connected_order_arc_551  -1
    order_0_5  connected_order_arc_562  1
    order_0_5  connected_order_arc_593  1
    order_0_5  connected_order_arc_624  1
    order_0_5  connected_order_arc_655  1
    order_0_5  connected_order_arc_686  1
    order_0_5  connected_order_arc_717  1
    order_0_5  connected_order_arc_748  1
    order_0_5  connected_order_arc_779  1
    order_0_5  connected_order_arc_810  1
    order_0_5  connected_order_arc_841  1
    order_0_5  connected_order_arc_872  1
    order_0_5  order_active_lb_925  1
    order_0_5  order_active_ub_926  1
    order_0_5  fixed_segment_relative_order_1002  1
    order_0_5  fixed_segment_relative_order_1003  -1
    visit_0_6  out_degree_930  -1
    visit_0_6  in_degree_931  -1
    visit_0_6  order_active_lb_932  -1
    visit_0_6  order_active_ub_933  -16
    order_0_6  connected_order_arc_407  1
    order_0_6  connected_order_arc_438  1
    order_0_6  connected_order_arc_469  1
    order_0_6  connected_order_arc_500  1
    order_0_6  connected_order_arc_531  1
    order_0_6  connected_order_arc_554  -1
    order_0_6  connected_order_arc_556  -1
    order_0_6  connected_order_arc_558  -1
    order_0_6  connected_order_arc_560  -1
    order_0_6  connected_order_arc_562  -1
    order_0_6  connected_order_arc_564  -1
    order_0_6  connected_order_arc_566  -1
    order_0_6  connected_order_arc_568  -1
    order_0_6  connected_order_arc_570  -1
    order_0_6  connected_order_arc_572  -1
    order_0_6  connected_order_arc_574  -1
    order_0_6  connected_order_arc_576  -1
    order_0_6  connected_order_arc_578  -1
    order_0_6  connected_order_arc_580  -1
    order_0_6  connected_order_arc_582  -1
    order_0_6  connected_order_arc_595  1
    order_0_6  connected_order_arc_626  1
    order_0_6  connected_order_arc_657  1
    order_0_6  connected_order_arc_688  1
    order_0_6  connected_order_arc_719  1
    order_0_6  connected_order_arc_750  1
    order_0_6  connected_order_arc_781  1
    order_0_6  connected_order_arc_812  1
    order_0_6  connected_order_arc_843  1
    order_0_6  connected_order_arc_874  1
    order_0_6  order_active_lb_932  1
    order_0_6  order_active_ub_933  1
    order_0_6  fixed_segment_relative_order_1003  1
    order_0_6  fixed_segment_relative_order_1004  -1
    visit_0_7  out_degree_937  -1
    visit_0_7  in_degree_938  -1
    visit_0_7  order_active_lb_939  -1
    visit_0_7  order_active_ub_940  -16
    order_0_7  connected_order_arc_409  1
    order_0_7  connected_order_arc_440  1
    order_0_7  connected_order_arc_471  1
    order_0_7  connected_order_arc_502  1
    order_0_7  connected_order_arc_533  1
    order_0_7  connected_order_arc_564  1
    order_0_7  connected_order_arc_585  -1
    order_0_7  connected_order_arc_587  -1
    order_0_7  connected_order_arc_589  -1
    order_0_7  connected_order_arc_591  -1
    order_0_7  connected_order_arc_593  -1
    order_0_7  connected_order_arc_595  -1
    order_0_7  connected_order_arc_597  -1
    order_0_7  connected_order_arc_599  -1
    order_0_7  connected_order_arc_601  -1
    order_0_7  connected_order_arc_603  -1
    order_0_7  connected_order_arc_605  -1
    order_0_7  connected_order_arc_607  -1
    order_0_7  connected_order_arc_609  -1
    order_0_7  connected_order_arc_611  -1
    order_0_7  connected_order_arc_613  -1
    order_0_7  connected_order_arc_628  1
    order_0_7  connected_order_arc_659  1
    order_0_7  connected_order_arc_690  1
    order_0_7  connected_order_arc_721  1
    order_0_7  connected_order_arc_752  1
    order_0_7  connected_order_arc_783  1
    order_0_7  connected_order_arc_814  1
    order_0_7  connected_order_arc_845  1
    order_0_7  connected_order_arc_876  1
    order_0_7  order_active_lb_939  1
    order_0_7  order_active_ub_940  1
    order_0_7  fixed_segment_relative_order_1004  1
    order_0_7  fixed_segment_relative_order_1005  -1
    visit_0_8  out_degree_944  -1
    visit_0_8  in_degree_945  -1
    visit_0_8  order_active_lb_946  -1
    visit_0_8  order_active_ub_947  -16
    order_0_8  connected_order_arc_411  1
    order_0_8  connected_order_arc_442  1
    order_0_8  connected_order_arc_473  1
    order_0_8  connected_order_arc_504  1
    order_0_8  connected_order_arc_535  1
    order_0_8  connected_order_arc_566  1
    order_0_8  connected_order_arc_597  1
    order_0_8  connected_order_arc_616  -1
    order_0_8  connected_order_arc_618  -1
    order_0_8  connected_order_arc_620  -1
    order_0_8  connected_order_arc_622  -1
    order_0_8  connected_order_arc_624  -1
    order_0_8  connected_order_arc_626  -1
    order_0_8  connected_order_arc_628  -1
    order_0_8  connected_order_arc_630  -1
    order_0_8  connected_order_arc_632  -1
    order_0_8  connected_order_arc_634  -1
    order_0_8  connected_order_arc_636  -1
    order_0_8  connected_order_arc_638  -1
    order_0_8  connected_order_arc_640  -1
    order_0_8  connected_order_arc_642  -1
    order_0_8  connected_order_arc_644  -1
    order_0_8  connected_order_arc_661  1
    order_0_8  connected_order_arc_692  1
    order_0_8  connected_order_arc_723  1
    order_0_8  connected_order_arc_754  1
    order_0_8  connected_order_arc_785  1
    order_0_8  connected_order_arc_816  1
    order_0_8  connected_order_arc_847  1
    order_0_8  connected_order_arc_878  1
    order_0_8  order_active_lb_946  1
    order_0_8  order_active_ub_947  1
    order_0_8  fixed_segment_relative_order_1005  1
    visit_0_9  out_degree_951  -1
    visit_0_9  in_degree_952  -1
    visit_0_9  order_active_lb_953  -1
    visit_0_9  order_active_ub_954  -16
    visit_0_9  service_visit_def_955  -1
    order_0_9  connected_order_arc_413  1
    order_0_9  connected_order_arc_444  1
    order_0_9  connected_order_arc_475  1
    order_0_9  connected_order_arc_506  1
    order_0_9  connected_order_arc_537  1
    order_0_9  connected_order_arc_568  1
    order_0_9  connected_order_arc_599  1
    order_0_9  connected_order_arc_630  1
    order_0_9  connected_order_arc_647  -1
    order_0_9  connected_order_arc_649  -1
    order_0_9  connected_order_arc_651  -1
    order_0_9  connected_order_arc_653  -1
    order_0_9  connected_order_arc_655  -1
    order_0_9  connected_order_arc_657  -1
    order_0_9  connected_order_arc_659  -1
    order_0_9  connected_order_arc_661  -1
    order_0_9  connected_order_arc_663  -1
    order_0_9  connected_order_arc_665  -1
    order_0_9  connected_order_arc_667  -1
    order_0_9  connected_order_arc_669  -1
    order_0_9  connected_order_arc_671  -1
    order_0_9  connected_order_arc_673  -1
    order_0_9  connected_order_arc_675  -1
    order_0_9  connected_order_arc_694  1
    order_0_9  connected_order_arc_725  1
    order_0_9  connected_order_arc_756  1
    order_0_9  connected_order_arc_787  1
    order_0_9  connected_order_arc_818  1
    order_0_9  connected_order_arc_849  1
    order_0_9  connected_order_arc_880  1
    order_0_9  order_active_lb_953  1
    order_0_9  order_active_ub_954  1
    visit_0_10  out_degree_957  -1
    visit_0_10  in_degree_958  -1
    visit_0_10  order_active_lb_959  -1
    visit_0_10  order_active_ub_960  -16
    visit_0_10  service_visit_def_961  -1
    order_0_10  connected_order_arc_415  1
    order_0_10  connected_order_arc_446  1
    order_0_10  connected_order_arc_477  1
    order_0_10  connected_order_arc_508  1
    order_0_10  connected_order_arc_539  1
    order_0_10  connected_order_arc_570  1
    order_0_10  connected_order_arc_601  1
    order_0_10  connected_order_arc_632  1
    order_0_10  connected_order_arc_663  1
    order_0_10  connected_order_arc_678  -1
    order_0_10  connected_order_arc_680  -1
    order_0_10  connected_order_arc_682  -1
    order_0_10  connected_order_arc_684  -1
    order_0_10  connected_order_arc_686  -1
    order_0_10  connected_order_arc_688  -1
    order_0_10  connected_order_arc_690  -1
    order_0_10  connected_order_arc_692  -1
    order_0_10  connected_order_arc_694  -1
    order_0_10  connected_order_arc_696  -1
    order_0_10  connected_order_arc_698  -1
    order_0_10  connected_order_arc_700  -1
    order_0_10  connected_order_arc_702  -1
    order_0_10  connected_order_arc_704  -1
    order_0_10  connected_order_arc_706  -1
    order_0_10  connected_order_arc_727  1
    order_0_10  connected_order_arc_758  1
    order_0_10  connected_order_arc_789  1
    order_0_10  connected_order_arc_820  1
    order_0_10  connected_order_arc_851  1
    order_0_10  connected_order_arc_882  1
    order_0_10  order_active_lb_959  1
    order_0_10  order_active_ub_960  1
    visit_0_11  out_degree_963  -1
    visit_0_11  in_degree_964  -1
    visit_0_11  order_active_lb_965  -1
    visit_0_11  order_active_ub_966  -16
    visit_0_11  service_visit_def_967  -1
    order_0_11  connected_order_arc_417  1
    order_0_11  connected_order_arc_448  1
    order_0_11  connected_order_arc_479  1
    order_0_11  connected_order_arc_510  1
    order_0_11  connected_order_arc_541  1
    order_0_11  connected_order_arc_572  1
    order_0_11  connected_order_arc_603  1
    order_0_11  connected_order_arc_634  1
    order_0_11  connected_order_arc_665  1
    order_0_11  connected_order_arc_696  1
    order_0_11  connected_order_arc_709  -1
    order_0_11  connected_order_arc_711  -1
    order_0_11  connected_order_arc_713  -1
    order_0_11  connected_order_arc_715  -1
    order_0_11  connected_order_arc_717  -1
    order_0_11  connected_order_arc_719  -1
    order_0_11  connected_order_arc_721  -1
    order_0_11  connected_order_arc_723  -1
    order_0_11  connected_order_arc_725  -1
    order_0_11  connected_order_arc_727  -1
    order_0_11  connected_order_arc_729  -1
    order_0_11  connected_order_arc_731  -1
    order_0_11  connected_order_arc_733  -1
    order_0_11  connected_order_arc_735  -1
    order_0_11  connected_order_arc_737  -1
    order_0_11  connected_order_arc_760  1
    order_0_11  connected_order_arc_791  1
    order_0_11  connected_order_arc_822  1
    order_0_11  connected_order_arc_853  1
    order_0_11  connected_order_arc_884  1
    order_0_11  order_active_lb_965  1
    order_0_11  order_active_ub_966  1
    visit_0_12  out_degree_969  -1
    visit_0_12  in_degree_970  -1
    visit_0_12  order_active_lb_971  -1
    visit_0_12  order_active_ub_972  -16
    visit_0_12  service_visit_def_973  -1
    order_0_12  connected_order_arc_419  1
    order_0_12  connected_order_arc_450  1
    order_0_12  connected_order_arc_481  1
    order_0_12  connected_order_arc_512  1
    order_0_12  connected_order_arc_543  1
    order_0_12  connected_order_arc_574  1
    order_0_12  connected_order_arc_605  1
    order_0_12  connected_order_arc_636  1
    order_0_12  connected_order_arc_667  1
    order_0_12  connected_order_arc_698  1
    order_0_12  connected_order_arc_729  1
    order_0_12  connected_order_arc_740  -1
    order_0_12  connected_order_arc_742  -1
    order_0_12  connected_order_arc_744  -1
    order_0_12  connected_order_arc_746  -1
    order_0_12  connected_order_arc_748  -1
    order_0_12  connected_order_arc_750  -1
    order_0_12  connected_order_arc_752  -1
    order_0_12  connected_order_arc_754  -1
    order_0_12  connected_order_arc_756  -1
    order_0_12  connected_order_arc_758  -1
    order_0_12  connected_order_arc_760  -1
    order_0_12  connected_order_arc_762  -1
    order_0_12  connected_order_arc_764  -1
    order_0_12  connected_order_arc_766  -1
    order_0_12  connected_order_arc_768  -1
    order_0_12  connected_order_arc_793  1
    order_0_12  connected_order_arc_824  1
    order_0_12  connected_order_arc_855  1
    order_0_12  connected_order_arc_886  1
    order_0_12  order_active_lb_971  1
    order_0_12  order_active_ub_972  1
    visit_0_13  out_degree_975  -1
    visit_0_13  in_degree_976  -1
    visit_0_13  order_active_lb_977  -1
    visit_0_13  order_active_ub_978  -16
    visit_0_13  service_visit_def_979  -1
    order_0_13  connected_order_arc_421  1
    order_0_13  connected_order_arc_452  1
    order_0_13  connected_order_arc_483  1
    order_0_13  connected_order_arc_514  1
    order_0_13  connected_order_arc_545  1
    order_0_13  connected_order_arc_576  1
    order_0_13  connected_order_arc_607  1
    order_0_13  connected_order_arc_638  1
    order_0_13  connected_order_arc_669  1
    order_0_13  connected_order_arc_700  1
    order_0_13  connected_order_arc_731  1
    order_0_13  connected_order_arc_762  1
    order_0_13  connected_order_arc_771  -1
    order_0_13  connected_order_arc_773  -1
    order_0_13  connected_order_arc_775  -1
    order_0_13  connected_order_arc_777  -1
    order_0_13  connected_order_arc_779  -1
    order_0_13  connected_order_arc_781  -1
    order_0_13  connected_order_arc_783  -1
    order_0_13  connected_order_arc_785  -1
    order_0_13  connected_order_arc_787  -1
    order_0_13  connected_order_arc_789  -1
    order_0_13  connected_order_arc_791  -1
    order_0_13  connected_order_arc_793  -1
    order_0_13  connected_order_arc_795  -1
    order_0_13  connected_order_arc_797  -1
    order_0_13  connected_order_arc_799  -1
    order_0_13  connected_order_arc_826  1
    order_0_13  connected_order_arc_857  1
    order_0_13  connected_order_arc_888  1
    order_0_13  order_active_lb_977  1
    order_0_13  order_active_ub_978  1
    visit_0_14  out_degree_981  -1
    visit_0_14  in_degree_982  -1
    visit_0_14  order_active_lb_983  -1
    visit_0_14  order_active_ub_984  -16
    visit_0_14  service_visit_def_985  -1
    order_0_14  connected_order_arc_423  1
    order_0_14  connected_order_arc_454  1
    order_0_14  connected_order_arc_485  1
    order_0_14  connected_order_arc_516  1
    order_0_14  connected_order_arc_547  1
    order_0_14  connected_order_arc_578  1
    order_0_14  connected_order_arc_609  1
    order_0_14  connected_order_arc_640  1
    order_0_14  connected_order_arc_671  1
    order_0_14  connected_order_arc_702  1
    order_0_14  connected_order_arc_733  1
    order_0_14  connected_order_arc_764  1
    order_0_14  connected_order_arc_795  1
    order_0_14  connected_order_arc_802  -1
    order_0_14  connected_order_arc_804  -1
    order_0_14  connected_order_arc_806  -1
    order_0_14  connected_order_arc_808  -1
    order_0_14  connected_order_arc_810  -1
    order_0_14  connected_order_arc_812  -1
    order_0_14  connected_order_arc_814  -1
    order_0_14  connected_order_arc_816  -1
    order_0_14  connected_order_arc_818  -1
    order_0_14  connected_order_arc_820  -1
    order_0_14  connected_order_arc_822  -1
    order_0_14  connected_order_arc_824  -1
    order_0_14  connected_order_arc_826  -1
    order_0_14  connected_order_arc_828  -1
    order_0_14  connected_order_arc_830  -1
    order_0_14  connected_order_arc_859  1
    order_0_14  connected_order_arc_890  1
    order_0_14  order_active_lb_983  1
    order_0_14  order_active_ub_984  1
    visit_0_15  out_degree_987  -1
    visit_0_15  in_degree_988  -1
    visit_0_15  order_active_lb_989  -1
    visit_0_15  order_active_ub_990  -16
    visit_0_15  service_visit_def_991  -1
    order_0_15  connected_order_arc_425  1
    order_0_15  connected_order_arc_456  1
    order_0_15  connected_order_arc_487  1
    order_0_15  connected_order_arc_518  1
    order_0_15  connected_order_arc_549  1
    order_0_15  connected_order_arc_580  1
    order_0_15  connected_order_arc_611  1
    order_0_15  connected_order_arc_642  1
    order_0_15  connected_order_arc_673  1
    order_0_15  connected_order_arc_704  1
    order_0_15  connected_order_arc_735  1
    order_0_15  connected_order_arc_766  1
    order_0_15  connected_order_arc_797  1
    order_0_15  connected_order_arc_828  1
    order_0_15  connected_order_arc_833  -1
    order_0_15  connected_order_arc_835  -1
    order_0_15  connected_order_arc_837  -1
    order_0_15  connected_order_arc_839  -1
    order_0_15  connected_order_arc_841  -1
    order_0_15  connected_order_arc_843  -1
    order_0_15  connected_order_arc_845  -1
    order_0_15  connected_order_arc_847  -1
    order_0_15  connected_order_arc_849  -1
    order_0_15  connected_order_arc_851  -1
    order_0_15  connected_order_arc_853  -1
    order_0_15  connected_order_arc_855  -1
    order_0_15  connected_order_arc_857  -1
    order_0_15  connected_order_arc_859  -1
    order_0_15  connected_order_arc_861  -1
    order_0_15  connected_order_arc_892  1
    order_0_15  order_active_lb_989  1
    order_0_15  order_active_ub_990  1
    visit_0_16  out_degree_993  -1
    visit_0_16  in_degree_994  -1
    visit_0_16  order_active_lb_995  -1
    visit_0_16  order_active_ub_996  -16
    visit_0_16  service_visit_def_997  -1
    order_0_16  connected_order_arc_427  1
    order_0_16  connected_order_arc_458  1
    order_0_16  connected_order_arc_489  1
    order_0_16  connected_order_arc_520  1
    order_0_16  connected_order_arc_551  1
    order_0_16  connected_order_arc_582  1
    order_0_16  connected_order_arc_613  1
    order_0_16  connected_order_arc_644  1
    order_0_16  connected_order_arc_675  1
    order_0_16  connected_order_arc_706  1
    order_0_16  connected_order_arc_737  1
    order_0_16  connected_order_arc_768  1
    order_0_16  connected_order_arc_799  1
    order_0_16  connected_order_arc_830  1
    order_0_16  connected_order_arc_861  1
    order_0_16  connected_order_arc_864  -1
    order_0_16  connected_order_arc_866  -1
    order_0_16  connected_order_arc_868  -1
    order_0_16  connected_order_arc_870  -1
    order_0_16  connected_order_arc_872  -1
    order_0_16  connected_order_arc_874  -1
    order_0_16  connected_order_arc_876  -1
    order_0_16  connected_order_arc_878  -1
    order_0_16  connected_order_arc_880  -1
    order_0_16  connected_order_arc_882  -1
    order_0_16  connected_order_arc_884  -1
    order_0_16  connected_order_arc_886  -1
    order_0_16  connected_order_arc_888  -1
    order_0_16  connected_order_arc_890  -1
    order_0_16  connected_order_arc_892  -1
    order_0_16  order_active_lb_995  1
    order_0_16  order_active_ub_996  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_380  -30
    arc_0_0_0  depot_departure_or_bypass_893  1
    arc_0_0_0  depot_return_or_bypass_894  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_380  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_381  -30
    arc_0_0_1  depot_departure_or_bypass_893  1
    arc_0_0_1  in_degree_896  1
    arc_0_0_1  original_T_including_depot_unload_1006  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_381  1
    load_0_0_1  segment_load_conservation_899  -1
    load_0_0_1  segment_prefix_lb_900  1
    load_0_0_1  segment_prefix_ub_901  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_382  -30
    arc_0_0_2  depot_departure_or_bypass_893  1
    arc_0_0_2  in_degree_903  1
    arc_0_0_2  original_T_including_depot_unload_1006  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_382  1
    load_0_0_2  segment_load_conservation_906  -1
    load_0_0_2  segment_prefix_lb_907  1
    load_0_0_2  segment_prefix_ub_908  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_383  -30
    arc_0_0_3  depot_departure_or_bypass_893  1
    arc_0_0_3  in_degree_910  1
    arc_0_0_3  original_T_including_depot_unload_1006  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_383  1
    load_0_0_3  segment_load_conservation_913  -1
    load_0_0_3  segment_prefix_lb_914  1
    load_0_0_3  segment_prefix_ub_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_384  -30
    arc_0_0_4  depot_departure_or_bypass_893  1
    arc_0_0_4  in_degree_917  1
    arc_0_0_4  original_T_including_depot_unload_1006  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_384  1
    load_0_0_4  segment_load_conservation_920  -1
    load_0_0_4  segment_prefix_lb_921  1
    load_0_0_4  segment_prefix_ub_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_385  -30
    arc_0_0_5  depot_departure_or_bypass_893  1
    arc_0_0_5  in_degree_924  1
    arc_0_0_5  original_T_including_depot_unload_1006  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_385  1
    load_0_0_5  segment_load_conservation_927  -1
    load_0_0_5  segment_prefix_lb_928  1
    load_0_0_5  segment_prefix_ub_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_6  arc_capacity_386  -30
    arc_0_0_6  depot_departure_or_bypass_893  1
    arc_0_0_6  in_degree_931  1
    arc_0_0_6  original_T_including_depot_unload_1006  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_6  arc_capacity_386  1
    load_0_0_6  segment_load_conservation_934  -1
    load_0_0_6  segment_prefix_lb_935  1
    load_0_0_6  segment_prefix_ub_936  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_7  arc_capacity_387  -30
    arc_0_0_7  depot_departure_or_bypass_893  1
    arc_0_0_7  in_degree_938  1
    arc_0_0_7  original_T_including_depot_unload_1006  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_7  arc_capacity_387  1
    load_0_0_7  segment_load_conservation_941  -1
    load_0_0_7  segment_prefix_lb_942  1
    load_0_0_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_388  -30
    arc_0_0_8  depot_departure_or_bypass_893  1
    arc_0_0_8  in_degree_945  1
    arc_0_0_8  original_T_including_depot_unload_1006  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_388  1
    load_0_0_8  segment_load_conservation_948  -1
    load_0_0_8  segment_prefix_lb_949  1
    load_0_0_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_389  -30
    arc_0_0_9  depot_departure_or_bypass_893  1
    arc_0_0_9  in_degree_952  1
    arc_0_0_9  original_T_including_depot_unload_1006  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_389  1
    load_0_0_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_390  -30
    arc_0_0_10  depot_departure_or_bypass_893  1
    arc_0_0_10  in_degree_958  1
    arc_0_0_10  original_T_including_depot_unload_1006  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_390  1
    load_0_0_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_391  -30
    arc_0_0_11  depot_departure_or_bypass_893  1
    arc_0_0_11  in_degree_964  1
    arc_0_0_11  original_T_including_depot_unload_1006  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_391  1
    load_0_0_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_392  -30
    arc_0_0_12  depot_departure_or_bypass_893  1
    arc_0_0_12  in_degree_970  1
    arc_0_0_12  original_T_including_depot_unload_1006  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_392  1
    load_0_0_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_393  -30
    arc_0_0_13  depot_departure_or_bypass_893  1
    arc_0_0_13  in_degree_976  1
    arc_0_0_13  original_T_including_depot_unload_1006  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_393  1
    load_0_0_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_394  -30
    arc_0_0_14  depot_departure_or_bypass_893  1
    arc_0_0_14  in_degree_982  1
    arc_0_0_14  original_T_including_depot_unload_1006  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_394  1
    load_0_0_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_395  -30
    arc_0_0_15  depot_departure_or_bypass_893  1
    arc_0_0_15  in_degree_988  1
    arc_0_0_15  original_T_including_depot_unload_1006  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_395  1
    load_0_0_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_396  -30
    arc_0_0_16  depot_departure_or_bypass_893  1
    arc_0_0_16  in_degree_994  1
    arc_0_0_16  original_T_including_depot_unload_1006  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_396  1
    load_0_0_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_397  -30
    arc_0_1_0  depot_return_or_bypass_894  1
    arc_0_1_0  out_degree_895  1
    arc_0_1_0  original_T_including_depot_unload_1006  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_397  1
    load_0_1_0  segment_load_conservation_899  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_398  -30
    arc_0_1_2  connected_order_arc_399  -17
    arc_0_1_2  out_degree_895  1
    arc_0_1_2  in_degree_903  1
    arc_0_1_2  original_T_including_depot_unload_1006  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_398  1
    load_0_1_2  segment_load_conservation_899  1
    load_0_1_2  segment_load_conservation_906  -1
    load_0_1_2  segment_prefix_lb_907  1
    load_0_1_2  segment_prefix_ub_908  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_400  -30
    arc_0_1_3  connected_order_arc_401  -17
    arc_0_1_3  out_degree_895  1
    arc_0_1_3  in_degree_910  1
    arc_0_1_3  original_T_including_depot_unload_1006  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_400  1
    load_0_1_3  segment_load_conservation_899  1
    load_0_1_3  segment_load_conservation_913  -1
    load_0_1_3  segment_prefix_lb_914  1
    load_0_1_3  segment_prefix_ub_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_402  -30
    arc_0_1_4  connected_order_arc_403  -17
    arc_0_1_4  out_degree_895  1
    arc_0_1_4  in_degree_917  1
    arc_0_1_4  original_T_including_depot_unload_1006  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_402  1
    load_0_1_4  segment_load_conservation_899  1
    load_0_1_4  segment_load_conservation_920  -1
    load_0_1_4  segment_prefix_lb_921  1
    load_0_1_4  segment_prefix_ub_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_404  -30
    arc_0_1_5  connected_order_arc_405  -17
    arc_0_1_5  out_degree_895  1
    arc_0_1_5  in_degree_924  1
    arc_0_1_5  original_T_including_depot_unload_1006  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_404  1
    load_0_1_5  segment_load_conservation_899  1
    load_0_1_5  segment_load_conservation_927  -1
    load_0_1_5  segment_prefix_lb_928  1
    load_0_1_5  segment_prefix_ub_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_6  arc_capacity_406  -30
    arc_0_1_6  connected_order_arc_407  -17
    arc_0_1_6  out_degree_895  1
    arc_0_1_6  in_degree_931  1
    arc_0_1_6  original_T_including_depot_unload_1006  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_6  arc_capacity_406  1
    load_0_1_6  segment_load_conservation_899  1
    load_0_1_6  segment_load_conservation_934  -1
    load_0_1_6  segment_prefix_lb_935  1
    load_0_1_6  segment_prefix_ub_936  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_7  arc_capacity_408  -30
    arc_0_1_7  connected_order_arc_409  -17
    arc_0_1_7  out_degree_895  1
    arc_0_1_7  in_degree_938  1
    arc_0_1_7  original_T_including_depot_unload_1006  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_7  arc_capacity_408  1
    load_0_1_7  segment_load_conservation_899  1
    load_0_1_7  segment_load_conservation_941  -1
    load_0_1_7  segment_prefix_lb_942  1
    load_0_1_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_410  -30
    arc_0_1_8  connected_order_arc_411  -17
    arc_0_1_8  out_degree_895  1
    arc_0_1_8  in_degree_945  1
    arc_0_1_8  original_T_including_depot_unload_1006  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_410  1
    load_0_1_8  segment_load_conservation_899  1
    load_0_1_8  segment_load_conservation_948  -1
    load_0_1_8  segment_prefix_lb_949  1
    load_0_1_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_412  -30
    arc_0_1_9  connected_order_arc_413  -17
    arc_0_1_9  out_degree_895  1
    arc_0_1_9  in_degree_952  1
    arc_0_1_9  original_T_including_depot_unload_1006  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_412  1
    load_0_1_9  segment_load_conservation_899  1
    load_0_1_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_414  -30
    arc_0_1_10  connected_order_arc_415  -17
    arc_0_1_10  out_degree_895  1
    arc_0_1_10  in_degree_958  1
    arc_0_1_10  original_T_including_depot_unload_1006  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_414  1
    load_0_1_10  segment_load_conservation_899  1
    load_0_1_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_416  -30
    arc_0_1_11  connected_order_arc_417  -17
    arc_0_1_11  out_degree_895  1
    arc_0_1_11  in_degree_964  1
    arc_0_1_11  original_T_including_depot_unload_1006  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_416  1
    load_0_1_11  segment_load_conservation_899  1
    load_0_1_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_418  -30
    arc_0_1_12  connected_order_arc_419  -17
    arc_0_1_12  out_degree_895  1
    arc_0_1_12  in_degree_970  1
    arc_0_1_12  original_T_including_depot_unload_1006  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_418  1
    load_0_1_12  segment_load_conservation_899  1
    load_0_1_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_420  -30
    arc_0_1_13  connected_order_arc_421  -17
    arc_0_1_13  out_degree_895  1
    arc_0_1_13  in_degree_976  1
    arc_0_1_13  original_T_including_depot_unload_1006  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_420  1
    load_0_1_13  segment_load_conservation_899  1
    load_0_1_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_422  -30
    arc_0_1_14  connected_order_arc_423  -17
    arc_0_1_14  out_degree_895  1
    arc_0_1_14  in_degree_982  1
    arc_0_1_14  original_T_including_depot_unload_1006  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_422  1
    load_0_1_14  segment_load_conservation_899  1
    load_0_1_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_424  -30
    arc_0_1_15  connected_order_arc_425  -17
    arc_0_1_15  out_degree_895  1
    arc_0_1_15  in_degree_988  1
    arc_0_1_15  original_T_including_depot_unload_1006  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_424  1
    load_0_1_15  segment_load_conservation_899  1
    load_0_1_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_426  -30
    arc_0_1_16  connected_order_arc_427  -17
    arc_0_1_16  out_degree_895  1
    arc_0_1_16  in_degree_994  1
    arc_0_1_16  original_T_including_depot_unload_1006  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_426  1
    load_0_1_16  segment_load_conservation_899  1
    load_0_1_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_428  -30
    arc_0_2_0  depot_return_or_bypass_894  1
    arc_0_2_0  out_degree_902  1
    arc_0_2_0  original_T_including_depot_unload_1006  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_428  1
    load_0_2_0  segment_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_429  -30
    arc_0_2_1  connected_order_arc_430  -17
    arc_0_2_1  in_degree_896  1
    arc_0_2_1  out_degree_902  1
    arc_0_2_1  original_T_including_depot_unload_1006  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_429  1
    load_0_2_1  segment_load_conservation_899  -1
    load_0_2_1  segment_prefix_lb_900  1
    load_0_2_1  segment_prefix_ub_901  1
    load_0_2_1  segment_load_conservation_906  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_431  -30
    arc_0_2_3  connected_order_arc_432  -17
    arc_0_2_3  out_degree_902  1
    arc_0_2_3  in_degree_910  1
    arc_0_2_3  original_T_including_depot_unload_1006  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_431  1
    load_0_2_3  segment_load_conservation_906  1
    load_0_2_3  segment_load_conservation_913  -1
    load_0_2_3  segment_prefix_lb_914  1
    load_0_2_3  segment_prefix_ub_915  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_433  -30
    arc_0_2_4  connected_order_arc_434  -17
    arc_0_2_4  out_degree_902  1
    arc_0_2_4  in_degree_917  1
    arc_0_2_4  original_T_including_depot_unload_1006  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_433  1
    load_0_2_4  segment_load_conservation_906  1
    load_0_2_4  segment_load_conservation_920  -1
    load_0_2_4  segment_prefix_lb_921  1
    load_0_2_4  segment_prefix_ub_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_435  -30
    arc_0_2_5  connected_order_arc_436  -17
    arc_0_2_5  out_degree_902  1
    arc_0_2_5  in_degree_924  1
    arc_0_2_5  original_T_including_depot_unload_1006  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_435  1
    load_0_2_5  segment_load_conservation_906  1
    load_0_2_5  segment_load_conservation_927  -1
    load_0_2_5  segment_prefix_lb_928  1
    load_0_2_5  segment_prefix_ub_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_6  arc_capacity_437  -30
    arc_0_2_6  connected_order_arc_438  -17
    arc_0_2_6  out_degree_902  1
    arc_0_2_6  in_degree_931  1
    arc_0_2_6  original_T_including_depot_unload_1006  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_6  arc_capacity_437  1
    load_0_2_6  segment_load_conservation_906  1
    load_0_2_6  segment_load_conservation_934  -1
    load_0_2_6  segment_prefix_lb_935  1
    load_0_2_6  segment_prefix_ub_936  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_7  arc_capacity_439  -30
    arc_0_2_7  connected_order_arc_440  -17
    arc_0_2_7  out_degree_902  1
    arc_0_2_7  in_degree_938  1
    arc_0_2_7  original_T_including_depot_unload_1006  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_7  arc_capacity_439  1
    load_0_2_7  segment_load_conservation_906  1
    load_0_2_7  segment_load_conservation_941  -1
    load_0_2_7  segment_prefix_lb_942  1
    load_0_2_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_441  -30
    arc_0_2_8  connected_order_arc_442  -17
    arc_0_2_8  out_degree_902  1
    arc_0_2_8  in_degree_945  1
    arc_0_2_8  original_T_including_depot_unload_1006  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_441  1
    load_0_2_8  segment_load_conservation_906  1
    load_0_2_8  segment_load_conservation_948  -1
    load_0_2_8  segment_prefix_lb_949  1
    load_0_2_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_443  -30
    arc_0_2_9  connected_order_arc_444  -17
    arc_0_2_9  out_degree_902  1
    arc_0_2_9  in_degree_952  1
    arc_0_2_9  original_T_including_depot_unload_1006  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_443  1
    load_0_2_9  segment_load_conservation_906  1
    load_0_2_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_445  -30
    arc_0_2_10  connected_order_arc_446  -17
    arc_0_2_10  out_degree_902  1
    arc_0_2_10  in_degree_958  1
    arc_0_2_10  original_T_including_depot_unload_1006  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_445  1
    load_0_2_10  segment_load_conservation_906  1
    load_0_2_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_447  -30
    arc_0_2_11  connected_order_arc_448  -17
    arc_0_2_11  out_degree_902  1
    arc_0_2_11  in_degree_964  1
    arc_0_2_11  original_T_including_depot_unload_1006  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_447  1
    load_0_2_11  segment_load_conservation_906  1
    load_0_2_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_449  -30
    arc_0_2_12  connected_order_arc_450  -17
    arc_0_2_12  out_degree_902  1
    arc_0_2_12  in_degree_970  1
    arc_0_2_12  original_T_including_depot_unload_1006  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_449  1
    load_0_2_12  segment_load_conservation_906  1
    load_0_2_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_451  -30
    arc_0_2_13  connected_order_arc_452  -17
    arc_0_2_13  out_degree_902  1
    arc_0_2_13  in_degree_976  1
    arc_0_2_13  original_T_including_depot_unload_1006  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_451  1
    load_0_2_13  segment_load_conservation_906  1
    load_0_2_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_453  -30
    arc_0_2_14  connected_order_arc_454  -17
    arc_0_2_14  out_degree_902  1
    arc_0_2_14  in_degree_982  1
    arc_0_2_14  original_T_including_depot_unload_1006  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_453  1
    load_0_2_14  segment_load_conservation_906  1
    load_0_2_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_455  -30
    arc_0_2_15  connected_order_arc_456  -17
    arc_0_2_15  out_degree_902  1
    arc_0_2_15  in_degree_988  1
    arc_0_2_15  original_T_including_depot_unload_1006  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_455  1
    load_0_2_15  segment_load_conservation_906  1
    load_0_2_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_457  -30
    arc_0_2_16  connected_order_arc_458  -17
    arc_0_2_16  out_degree_902  1
    arc_0_2_16  in_degree_994  1
    arc_0_2_16  original_T_including_depot_unload_1006  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_457  1
    load_0_2_16  segment_load_conservation_906  1
    load_0_2_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_459  -30
    arc_0_3_0  depot_return_or_bypass_894  1
    arc_0_3_0  out_degree_909  1
    arc_0_3_0  original_T_including_depot_unload_1006  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_459  1
    load_0_3_0  segment_load_conservation_913  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_460  -30
    arc_0_3_1  connected_order_arc_461  -17
    arc_0_3_1  in_degree_896  1
    arc_0_3_1  out_degree_909  1
    arc_0_3_1  original_T_including_depot_unload_1006  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_460  1
    load_0_3_1  segment_load_conservation_899  -1
    load_0_3_1  segment_prefix_lb_900  1
    load_0_3_1  segment_prefix_ub_901  1
    load_0_3_1  segment_load_conservation_913  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_462  -30
    arc_0_3_2  connected_order_arc_463  -17
    arc_0_3_2  in_degree_903  1
    arc_0_3_2  out_degree_909  1
    arc_0_3_2  original_T_including_depot_unload_1006  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_462  1
    load_0_3_2  segment_load_conservation_906  -1
    load_0_3_2  segment_prefix_lb_907  1
    load_0_3_2  segment_prefix_ub_908  1
    load_0_3_2  segment_load_conservation_913  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_464  -30
    arc_0_3_4  connected_order_arc_465  -17
    arc_0_3_4  out_degree_909  1
    arc_0_3_4  in_degree_917  1
    arc_0_3_4  original_T_including_depot_unload_1006  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_464  1
    load_0_3_4  segment_load_conservation_913  1
    load_0_3_4  segment_load_conservation_920  -1
    load_0_3_4  segment_prefix_lb_921  1
    load_0_3_4  segment_prefix_ub_922  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_466  -30
    arc_0_3_5  connected_order_arc_467  -17
    arc_0_3_5  out_degree_909  1
    arc_0_3_5  in_degree_924  1
    arc_0_3_5  original_T_including_depot_unload_1006  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_466  1
    load_0_3_5  segment_load_conservation_913  1
    load_0_3_5  segment_load_conservation_927  -1
    load_0_3_5  segment_prefix_lb_928  1
    load_0_3_5  segment_prefix_ub_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_6  arc_capacity_468  -30
    arc_0_3_6  connected_order_arc_469  -17
    arc_0_3_6  out_degree_909  1
    arc_0_3_6  in_degree_931  1
    arc_0_3_6  original_T_including_depot_unload_1006  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_6  arc_capacity_468  1
    load_0_3_6  segment_load_conservation_913  1
    load_0_3_6  segment_load_conservation_934  -1
    load_0_3_6  segment_prefix_lb_935  1
    load_0_3_6  segment_prefix_ub_936  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_7  arc_capacity_470  -30
    arc_0_3_7  connected_order_arc_471  -17
    arc_0_3_7  out_degree_909  1
    arc_0_3_7  in_degree_938  1
    arc_0_3_7  original_T_including_depot_unload_1006  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_7  arc_capacity_470  1
    load_0_3_7  segment_load_conservation_913  1
    load_0_3_7  segment_load_conservation_941  -1
    load_0_3_7  segment_prefix_lb_942  1
    load_0_3_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_472  -30
    arc_0_3_8  connected_order_arc_473  -17
    arc_0_3_8  out_degree_909  1
    arc_0_3_8  in_degree_945  1
    arc_0_3_8  original_T_including_depot_unload_1006  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_472  1
    load_0_3_8  segment_load_conservation_913  1
    load_0_3_8  segment_load_conservation_948  -1
    load_0_3_8  segment_prefix_lb_949  1
    load_0_3_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_474  -30
    arc_0_3_9  connected_order_arc_475  -17
    arc_0_3_9  out_degree_909  1
    arc_0_3_9  in_degree_952  1
    arc_0_3_9  original_T_including_depot_unload_1006  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_474  1
    load_0_3_9  segment_load_conservation_913  1
    load_0_3_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_476  -30
    arc_0_3_10  connected_order_arc_477  -17
    arc_0_3_10  out_degree_909  1
    arc_0_3_10  in_degree_958  1
    arc_0_3_10  original_T_including_depot_unload_1006  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_476  1
    load_0_3_10  segment_load_conservation_913  1
    load_0_3_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_478  -30
    arc_0_3_11  connected_order_arc_479  -17
    arc_0_3_11  out_degree_909  1
    arc_0_3_11  in_degree_964  1
    arc_0_3_11  original_T_including_depot_unload_1006  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_478  1
    load_0_3_11  segment_load_conservation_913  1
    load_0_3_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_480  -30
    arc_0_3_12  connected_order_arc_481  -17
    arc_0_3_12  out_degree_909  1
    arc_0_3_12  in_degree_970  1
    arc_0_3_12  original_T_including_depot_unload_1006  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_480  1
    load_0_3_12  segment_load_conservation_913  1
    load_0_3_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_482  -30
    arc_0_3_13  connected_order_arc_483  -17
    arc_0_3_13  out_degree_909  1
    arc_0_3_13  in_degree_976  1
    arc_0_3_13  original_T_including_depot_unload_1006  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_482  1
    load_0_3_13  segment_load_conservation_913  1
    load_0_3_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_484  -30
    arc_0_3_14  connected_order_arc_485  -17
    arc_0_3_14  out_degree_909  1
    arc_0_3_14  in_degree_982  1
    arc_0_3_14  original_T_including_depot_unload_1006  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_484  1
    load_0_3_14  segment_load_conservation_913  1
    load_0_3_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_486  -30
    arc_0_3_15  connected_order_arc_487  -17
    arc_0_3_15  out_degree_909  1
    arc_0_3_15  in_degree_988  1
    arc_0_3_15  original_T_including_depot_unload_1006  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_486  1
    load_0_3_15  segment_load_conservation_913  1
    load_0_3_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_488  -30
    arc_0_3_16  connected_order_arc_489  -17
    arc_0_3_16  out_degree_909  1
    arc_0_3_16  in_degree_994  1
    arc_0_3_16  original_T_including_depot_unload_1006  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_488  1
    load_0_3_16  segment_load_conservation_913  1
    load_0_3_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_490  -30
    arc_0_4_0  depot_return_or_bypass_894  1
    arc_0_4_0  out_degree_916  1
    arc_0_4_0  original_T_including_depot_unload_1006  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_490  1
    load_0_4_0  segment_load_conservation_920  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_491  -30
    arc_0_4_1  connected_order_arc_492  -17
    arc_0_4_1  in_degree_896  1
    arc_0_4_1  out_degree_916  1
    arc_0_4_1  original_T_including_depot_unload_1006  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_491  1
    load_0_4_1  segment_load_conservation_899  -1
    load_0_4_1  segment_prefix_lb_900  1
    load_0_4_1  segment_prefix_ub_901  1
    load_0_4_1  segment_load_conservation_920  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_493  -30
    arc_0_4_2  connected_order_arc_494  -17
    arc_0_4_2  in_degree_903  1
    arc_0_4_2  out_degree_916  1
    arc_0_4_2  original_T_including_depot_unload_1006  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_493  1
    load_0_4_2  segment_load_conservation_906  -1
    load_0_4_2  segment_prefix_lb_907  1
    load_0_4_2  segment_prefix_ub_908  1
    load_0_4_2  segment_load_conservation_920  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_495  -30
    arc_0_4_3  connected_order_arc_496  -17
    arc_0_4_3  in_degree_910  1
    arc_0_4_3  out_degree_916  1
    arc_0_4_3  original_T_including_depot_unload_1006  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_495  1
    load_0_4_3  segment_load_conservation_913  -1
    load_0_4_3  segment_prefix_lb_914  1
    load_0_4_3  segment_prefix_ub_915  1
    load_0_4_3  segment_load_conservation_920  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_497  -30
    arc_0_4_5  connected_order_arc_498  -17
    arc_0_4_5  out_degree_916  1
    arc_0_4_5  in_degree_924  1
    arc_0_4_5  original_T_including_depot_unload_1006  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_497  1
    load_0_4_5  segment_load_conservation_920  1
    load_0_4_5  segment_load_conservation_927  -1
    load_0_4_5  segment_prefix_lb_928  1
    load_0_4_5  segment_prefix_ub_929  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_6  arc_capacity_499  -30
    arc_0_4_6  connected_order_arc_500  -17
    arc_0_4_6  out_degree_916  1
    arc_0_4_6  in_degree_931  1
    arc_0_4_6  original_T_including_depot_unload_1006  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_6  arc_capacity_499  1
    load_0_4_6  segment_load_conservation_920  1
    load_0_4_6  segment_load_conservation_934  -1
    load_0_4_6  segment_prefix_lb_935  1
    load_0_4_6  segment_prefix_ub_936  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_7  arc_capacity_501  -30
    arc_0_4_7  connected_order_arc_502  -17
    arc_0_4_7  out_degree_916  1
    arc_0_4_7  in_degree_938  1
    arc_0_4_7  original_T_including_depot_unload_1006  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_7  arc_capacity_501  1
    load_0_4_7  segment_load_conservation_920  1
    load_0_4_7  segment_load_conservation_941  -1
    load_0_4_7  segment_prefix_lb_942  1
    load_0_4_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_503  -30
    arc_0_4_8  connected_order_arc_504  -17
    arc_0_4_8  out_degree_916  1
    arc_0_4_8  in_degree_945  1
    arc_0_4_8  original_T_including_depot_unload_1006  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_503  1
    load_0_4_8  segment_load_conservation_920  1
    load_0_4_8  segment_load_conservation_948  -1
    load_0_4_8  segment_prefix_lb_949  1
    load_0_4_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_505  -30
    arc_0_4_9  connected_order_arc_506  -17
    arc_0_4_9  out_degree_916  1
    arc_0_4_9  in_degree_952  1
    arc_0_4_9  original_T_including_depot_unload_1006  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_505  1
    load_0_4_9  segment_load_conservation_920  1
    load_0_4_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_507  -30
    arc_0_4_10  connected_order_arc_508  -17
    arc_0_4_10  out_degree_916  1
    arc_0_4_10  in_degree_958  1
    arc_0_4_10  original_T_including_depot_unload_1006  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_507  1
    load_0_4_10  segment_load_conservation_920  1
    load_0_4_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_509  -30
    arc_0_4_11  connected_order_arc_510  -17
    arc_0_4_11  out_degree_916  1
    arc_0_4_11  in_degree_964  1
    arc_0_4_11  original_T_including_depot_unload_1006  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_509  1
    load_0_4_11  segment_load_conservation_920  1
    load_0_4_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_511  -30
    arc_0_4_12  connected_order_arc_512  -17
    arc_0_4_12  out_degree_916  1
    arc_0_4_12  in_degree_970  1
    arc_0_4_12  original_T_including_depot_unload_1006  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_511  1
    load_0_4_12  segment_load_conservation_920  1
    load_0_4_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_513  -30
    arc_0_4_13  connected_order_arc_514  -17
    arc_0_4_13  out_degree_916  1
    arc_0_4_13  in_degree_976  1
    arc_0_4_13  original_T_including_depot_unload_1006  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_513  1
    load_0_4_13  segment_load_conservation_920  1
    load_0_4_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_515  -30
    arc_0_4_14  connected_order_arc_516  -17
    arc_0_4_14  out_degree_916  1
    arc_0_4_14  in_degree_982  1
    arc_0_4_14  original_T_including_depot_unload_1006  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_515  1
    load_0_4_14  segment_load_conservation_920  1
    load_0_4_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_517  -30
    arc_0_4_15  connected_order_arc_518  -17
    arc_0_4_15  out_degree_916  1
    arc_0_4_15  in_degree_988  1
    arc_0_4_15  original_T_including_depot_unload_1006  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_517  1
    load_0_4_15  segment_load_conservation_920  1
    load_0_4_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_519  -30
    arc_0_4_16  connected_order_arc_520  -17
    arc_0_4_16  out_degree_916  1
    arc_0_4_16  in_degree_994  1
    arc_0_4_16  original_T_including_depot_unload_1006  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_519  1
    load_0_4_16  segment_load_conservation_920  1
    load_0_4_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_521  -30
    arc_0_5_0  depot_return_or_bypass_894  1
    arc_0_5_0  out_degree_923  1
    arc_0_5_0  original_T_including_depot_unload_1006  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_521  1
    load_0_5_0  segment_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_522  -30
    arc_0_5_1  connected_order_arc_523  -17
    arc_0_5_1  in_degree_896  1
    arc_0_5_1  out_degree_923  1
    arc_0_5_1  original_T_including_depot_unload_1006  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_522  1
    load_0_5_1  segment_load_conservation_899  -1
    load_0_5_1  segment_prefix_lb_900  1
    load_0_5_1  segment_prefix_ub_901  1
    load_0_5_1  segment_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_524  -30
    arc_0_5_2  connected_order_arc_525  -17
    arc_0_5_2  in_degree_903  1
    arc_0_5_2  out_degree_923  1
    arc_0_5_2  original_T_including_depot_unload_1006  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_524  1
    load_0_5_2  segment_load_conservation_906  -1
    load_0_5_2  segment_prefix_lb_907  1
    load_0_5_2  segment_prefix_ub_908  1
    load_0_5_2  segment_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_526  -30
    arc_0_5_3  connected_order_arc_527  -17
    arc_0_5_3  in_degree_910  1
    arc_0_5_3  out_degree_923  1
    arc_0_5_3  original_T_including_depot_unload_1006  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_526  1
    load_0_5_3  segment_load_conservation_913  -1
    load_0_5_3  segment_prefix_lb_914  1
    load_0_5_3  segment_prefix_ub_915  1
    load_0_5_3  segment_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_528  -30
    arc_0_5_4  connected_order_arc_529  -17
    arc_0_5_4  in_degree_917  1
    arc_0_5_4  out_degree_923  1
    arc_0_5_4  original_T_including_depot_unload_1006  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_528  1
    load_0_5_4  segment_load_conservation_920  -1
    load_0_5_4  segment_prefix_lb_921  1
    load_0_5_4  segment_prefix_ub_922  1
    load_0_5_4  segment_load_conservation_927  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_6  arc_capacity_530  -30
    arc_0_5_6  connected_order_arc_531  -17
    arc_0_5_6  out_degree_923  1
    arc_0_5_6  in_degree_931  1
    arc_0_5_6  original_T_including_depot_unload_1006  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_6  arc_capacity_530  1
    load_0_5_6  segment_load_conservation_927  1
    load_0_5_6  segment_load_conservation_934  -1
    load_0_5_6  segment_prefix_lb_935  1
    load_0_5_6  segment_prefix_ub_936  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_7  arc_capacity_532  -30
    arc_0_5_7  connected_order_arc_533  -17
    arc_0_5_7  out_degree_923  1
    arc_0_5_7  in_degree_938  1
    arc_0_5_7  original_T_including_depot_unload_1006  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_7  arc_capacity_532  1
    load_0_5_7  segment_load_conservation_927  1
    load_0_5_7  segment_load_conservation_941  -1
    load_0_5_7  segment_prefix_lb_942  1
    load_0_5_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_534  -30
    arc_0_5_8  connected_order_arc_535  -17
    arc_0_5_8  out_degree_923  1
    arc_0_5_8  in_degree_945  1
    arc_0_5_8  original_T_including_depot_unload_1006  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_534  1
    load_0_5_8  segment_load_conservation_927  1
    load_0_5_8  segment_load_conservation_948  -1
    load_0_5_8  segment_prefix_lb_949  1
    load_0_5_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_536  -30
    arc_0_5_9  connected_order_arc_537  -17
    arc_0_5_9  out_degree_923  1
    arc_0_5_9  in_degree_952  1
    arc_0_5_9  original_T_including_depot_unload_1006  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_536  1
    load_0_5_9  segment_load_conservation_927  1
    load_0_5_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_538  -30
    arc_0_5_10  connected_order_arc_539  -17
    arc_0_5_10  out_degree_923  1
    arc_0_5_10  in_degree_958  1
    arc_0_5_10  original_T_including_depot_unload_1006  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_538  1
    load_0_5_10  segment_load_conservation_927  1
    load_0_5_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_540  -30
    arc_0_5_11  connected_order_arc_541  -17
    arc_0_5_11  out_degree_923  1
    arc_0_5_11  in_degree_964  1
    arc_0_5_11  original_T_including_depot_unload_1006  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_540  1
    load_0_5_11  segment_load_conservation_927  1
    load_0_5_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_542  -30
    arc_0_5_12  connected_order_arc_543  -17
    arc_0_5_12  out_degree_923  1
    arc_0_5_12  in_degree_970  1
    arc_0_5_12  original_T_including_depot_unload_1006  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_542  1
    load_0_5_12  segment_load_conservation_927  1
    load_0_5_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_544  -30
    arc_0_5_13  connected_order_arc_545  -17
    arc_0_5_13  out_degree_923  1
    arc_0_5_13  in_degree_976  1
    arc_0_5_13  original_T_including_depot_unload_1006  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_544  1
    load_0_5_13  segment_load_conservation_927  1
    load_0_5_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_546  -30
    arc_0_5_14  connected_order_arc_547  -17
    arc_0_5_14  out_degree_923  1
    arc_0_5_14  in_degree_982  1
    arc_0_5_14  original_T_including_depot_unload_1006  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_546  1
    load_0_5_14  segment_load_conservation_927  1
    load_0_5_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_548  -30
    arc_0_5_15  connected_order_arc_549  -17
    arc_0_5_15  out_degree_923  1
    arc_0_5_15  in_degree_988  1
    arc_0_5_15  original_T_including_depot_unload_1006  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_548  1
    load_0_5_15  segment_load_conservation_927  1
    load_0_5_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_550  -30
    arc_0_5_16  connected_order_arc_551  -17
    arc_0_5_16  out_degree_923  1
    arc_0_5_16  in_degree_994  1
    arc_0_5_16  original_T_including_depot_unload_1006  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_550  1
    load_0_5_16  segment_load_conservation_927  1
    load_0_5_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_0  arc_capacity_552  -30
    arc_0_6_0  depot_return_or_bypass_894  1
    arc_0_6_0  out_degree_930  1
    arc_0_6_0  original_T_including_depot_unload_1006  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_0  arc_capacity_552  1
    load_0_6_0  segment_load_conservation_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_1  arc_capacity_553  -30
    arc_0_6_1  connected_order_arc_554  -17
    arc_0_6_1  in_degree_896  1
    arc_0_6_1  out_degree_930  1
    arc_0_6_1  original_T_including_depot_unload_1006  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_1  arc_capacity_553  1
    load_0_6_1  segment_load_conservation_899  -1
    load_0_6_1  segment_prefix_lb_900  1
    load_0_6_1  segment_prefix_ub_901  1
    load_0_6_1  segment_load_conservation_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_2  arc_capacity_555  -30
    arc_0_6_2  connected_order_arc_556  -17
    arc_0_6_2  in_degree_903  1
    arc_0_6_2  out_degree_930  1
    arc_0_6_2  original_T_including_depot_unload_1006  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_2  arc_capacity_555  1
    load_0_6_2  segment_load_conservation_906  -1
    load_0_6_2  segment_prefix_lb_907  1
    load_0_6_2  segment_prefix_ub_908  1
    load_0_6_2  segment_load_conservation_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_3  arc_capacity_557  -30
    arc_0_6_3  connected_order_arc_558  -17
    arc_0_6_3  in_degree_910  1
    arc_0_6_3  out_degree_930  1
    arc_0_6_3  original_T_including_depot_unload_1006  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_3  arc_capacity_557  1
    load_0_6_3  segment_load_conservation_913  -1
    load_0_6_3  segment_prefix_lb_914  1
    load_0_6_3  segment_prefix_ub_915  1
    load_0_6_3  segment_load_conservation_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_4  arc_capacity_559  -30
    arc_0_6_4  connected_order_arc_560  -17
    arc_0_6_4  in_degree_917  1
    arc_0_6_4  out_degree_930  1
    arc_0_6_4  original_T_including_depot_unload_1006  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_4  arc_capacity_559  1
    load_0_6_4  segment_load_conservation_920  -1
    load_0_6_4  segment_prefix_lb_921  1
    load_0_6_4  segment_prefix_ub_922  1
    load_0_6_4  segment_load_conservation_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_5  arc_capacity_561  -30
    arc_0_6_5  connected_order_arc_562  -17
    arc_0_6_5  in_degree_924  1
    arc_0_6_5  out_degree_930  1
    arc_0_6_5  original_T_including_depot_unload_1006  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_5  arc_capacity_561  1
    load_0_6_5  segment_load_conservation_927  -1
    load_0_6_5  segment_prefix_lb_928  1
    load_0_6_5  segment_prefix_ub_929  1
    load_0_6_5  segment_load_conservation_934  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_7  arc_capacity_563  -30
    arc_0_6_7  connected_order_arc_564  -17
    arc_0_6_7  out_degree_930  1
    arc_0_6_7  in_degree_938  1
    arc_0_6_7  original_T_including_depot_unload_1006  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_7  arc_capacity_563  1
    load_0_6_7  segment_load_conservation_934  1
    load_0_6_7  segment_load_conservation_941  -1
    load_0_6_7  segment_prefix_lb_942  1
    load_0_6_7  segment_prefix_ub_943  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_8  arc_capacity_565  -30
    arc_0_6_8  connected_order_arc_566  -17
    arc_0_6_8  out_degree_930  1
    arc_0_6_8  in_degree_945  1
    arc_0_6_8  original_T_including_depot_unload_1006  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_8  arc_capacity_565  1
    load_0_6_8  segment_load_conservation_934  1
    load_0_6_8  segment_load_conservation_948  -1
    load_0_6_8  segment_prefix_lb_949  1
    load_0_6_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_9  arc_capacity_567  -30
    arc_0_6_9  connected_order_arc_568  -17
    arc_0_6_9  out_degree_930  1
    arc_0_6_9  in_degree_952  1
    arc_0_6_9  original_T_including_depot_unload_1006  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_9  arc_capacity_567  1
    load_0_6_9  segment_load_conservation_934  1
    load_0_6_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_10  arc_capacity_569  -30
    arc_0_6_10  connected_order_arc_570  -17
    arc_0_6_10  out_degree_930  1
    arc_0_6_10  in_degree_958  1
    arc_0_6_10  original_T_including_depot_unload_1006  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_10  arc_capacity_569  1
    load_0_6_10  segment_load_conservation_934  1
    load_0_6_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_11  arc_capacity_571  -30
    arc_0_6_11  connected_order_arc_572  -17
    arc_0_6_11  out_degree_930  1
    arc_0_6_11  in_degree_964  1
    arc_0_6_11  original_T_including_depot_unload_1006  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_11  arc_capacity_571  1
    load_0_6_11  segment_load_conservation_934  1
    load_0_6_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_12  arc_capacity_573  -30
    arc_0_6_12  connected_order_arc_574  -17
    arc_0_6_12  out_degree_930  1
    arc_0_6_12  in_degree_970  1
    arc_0_6_12  original_T_including_depot_unload_1006  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_12  arc_capacity_573  1
    load_0_6_12  segment_load_conservation_934  1
    load_0_6_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_13  arc_capacity_575  -30
    arc_0_6_13  connected_order_arc_576  -17
    arc_0_6_13  out_degree_930  1
    arc_0_6_13  in_degree_976  1
    arc_0_6_13  original_T_including_depot_unload_1006  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_6_13  arc_capacity_575  1
    load_0_6_13  segment_load_conservation_934  1
    load_0_6_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_14  arc_capacity_577  -30
    arc_0_6_14  connected_order_arc_578  -17
    arc_0_6_14  out_degree_930  1
    arc_0_6_14  in_degree_982  1
    arc_0_6_14  original_T_including_depot_unload_1006  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_14  arc_capacity_577  1
    load_0_6_14  segment_load_conservation_934  1
    load_0_6_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_15  arc_capacity_579  -30
    arc_0_6_15  connected_order_arc_580  -17
    arc_0_6_15  out_degree_930  1
    arc_0_6_15  in_degree_988  1
    arc_0_6_15  original_T_including_depot_unload_1006  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_6_15  arc_capacity_579  1
    load_0_6_15  segment_load_conservation_934  1
    load_0_6_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_6_16  arc_capacity_581  -30
    arc_0_6_16  connected_order_arc_582  -17
    arc_0_6_16  out_degree_930  1
    arc_0_6_16  in_degree_994  1
    arc_0_6_16  original_T_including_depot_unload_1006  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_6_16  arc_capacity_581  1
    load_0_6_16  segment_load_conservation_934  1
    load_0_6_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_0  arc_capacity_583  -30
    arc_0_7_0  depot_return_or_bypass_894  1
    arc_0_7_0  out_degree_937  1
    arc_0_7_0  original_T_including_depot_unload_1006  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_0  arc_capacity_583  1
    load_0_7_0  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_1  arc_capacity_584  -30
    arc_0_7_1  connected_order_arc_585  -17
    arc_0_7_1  in_degree_896  1
    arc_0_7_1  out_degree_937  1
    arc_0_7_1  original_T_including_depot_unload_1006  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_1  arc_capacity_584  1
    load_0_7_1  segment_load_conservation_899  -1
    load_0_7_1  segment_prefix_lb_900  1
    load_0_7_1  segment_prefix_ub_901  1
    load_0_7_1  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_2  arc_capacity_586  -30
    arc_0_7_2  connected_order_arc_587  -17
    arc_0_7_2  in_degree_903  1
    arc_0_7_2  out_degree_937  1
    arc_0_7_2  original_T_including_depot_unload_1006  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_2  arc_capacity_586  1
    load_0_7_2  segment_load_conservation_906  -1
    load_0_7_2  segment_prefix_lb_907  1
    load_0_7_2  segment_prefix_ub_908  1
    load_0_7_2  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_3  arc_capacity_588  -30
    arc_0_7_3  connected_order_arc_589  -17
    arc_0_7_3  in_degree_910  1
    arc_0_7_3  out_degree_937  1
    arc_0_7_3  original_T_including_depot_unload_1006  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_3  arc_capacity_588  1
    load_0_7_3  segment_load_conservation_913  -1
    load_0_7_3  segment_prefix_lb_914  1
    load_0_7_3  segment_prefix_ub_915  1
    load_0_7_3  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_4  arc_capacity_590  -30
    arc_0_7_4  connected_order_arc_591  -17
    arc_0_7_4  in_degree_917  1
    arc_0_7_4  out_degree_937  1
    arc_0_7_4  original_T_including_depot_unload_1006  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_4  arc_capacity_590  1
    load_0_7_4  segment_load_conservation_920  -1
    load_0_7_4  segment_prefix_lb_921  1
    load_0_7_4  segment_prefix_ub_922  1
    load_0_7_4  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_5  arc_capacity_592  -30
    arc_0_7_5  connected_order_arc_593  -17
    arc_0_7_5  in_degree_924  1
    arc_0_7_5  out_degree_937  1
    arc_0_7_5  original_T_including_depot_unload_1006  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_5  arc_capacity_592  1
    load_0_7_5  segment_load_conservation_927  -1
    load_0_7_5  segment_prefix_lb_928  1
    load_0_7_5  segment_prefix_ub_929  1
    load_0_7_5  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_6  arc_capacity_594  -30
    arc_0_7_6  connected_order_arc_595  -17
    arc_0_7_6  in_degree_931  1
    arc_0_7_6  out_degree_937  1
    arc_0_7_6  original_T_including_depot_unload_1006  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_6  arc_capacity_594  1
    load_0_7_6  segment_load_conservation_934  -1
    load_0_7_6  segment_prefix_lb_935  1
    load_0_7_6  segment_prefix_ub_936  1
    load_0_7_6  segment_load_conservation_941  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_8  arc_capacity_596  -30
    arc_0_7_8  connected_order_arc_597  -17
    arc_0_7_8  out_degree_937  1
    arc_0_7_8  in_degree_945  1
    arc_0_7_8  original_T_including_depot_unload_1006  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_8  arc_capacity_596  1
    load_0_7_8  segment_load_conservation_941  1
    load_0_7_8  segment_load_conservation_948  -1
    load_0_7_8  segment_prefix_lb_949  1
    load_0_7_8  segment_prefix_ub_950  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_9  arc_capacity_598  -30
    arc_0_7_9  connected_order_arc_599  -17
    arc_0_7_9  out_degree_937  1
    arc_0_7_9  in_degree_952  1
    arc_0_7_9  original_T_including_depot_unload_1006  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_9  arc_capacity_598  1
    load_0_7_9  segment_load_conservation_941  1
    load_0_7_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_10  arc_capacity_600  -30
    arc_0_7_10  connected_order_arc_601  -17
    arc_0_7_10  out_degree_937  1
    arc_0_7_10  in_degree_958  1
    arc_0_7_10  original_T_including_depot_unload_1006  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_10  arc_capacity_600  1
    load_0_7_10  segment_load_conservation_941  1
    load_0_7_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_11  arc_capacity_602  -30
    arc_0_7_11  connected_order_arc_603  -17
    arc_0_7_11  out_degree_937  1
    arc_0_7_11  in_degree_964  1
    arc_0_7_11  original_T_including_depot_unload_1006  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_11  arc_capacity_602  1
    load_0_7_11  segment_load_conservation_941  1
    load_0_7_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_12  arc_capacity_604  -30
    arc_0_7_12  connected_order_arc_605  -17
    arc_0_7_12  out_degree_937  1
    arc_0_7_12  in_degree_970  1
    arc_0_7_12  original_T_including_depot_unload_1006  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_12  arc_capacity_604  1
    load_0_7_12  segment_load_conservation_941  1
    load_0_7_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_13  arc_capacity_606  -30
    arc_0_7_13  connected_order_arc_607  -17
    arc_0_7_13  out_degree_937  1
    arc_0_7_13  in_degree_976  1
    arc_0_7_13  original_T_including_depot_unload_1006  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_13  arc_capacity_606  1
    load_0_7_13  segment_load_conservation_941  1
    load_0_7_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_14  arc_capacity_608  -30
    arc_0_7_14  connected_order_arc_609  -17
    arc_0_7_14  out_degree_937  1
    arc_0_7_14  in_degree_982  1
    arc_0_7_14  original_T_including_depot_unload_1006  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_14  arc_capacity_608  1
    load_0_7_14  segment_load_conservation_941  1
    load_0_7_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_15  arc_capacity_610  -30
    arc_0_7_15  connected_order_arc_611  -17
    arc_0_7_15  out_degree_937  1
    arc_0_7_15  in_degree_988  1
    arc_0_7_15  original_T_including_depot_unload_1006  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_7_15  arc_capacity_610  1
    load_0_7_15  segment_load_conservation_941  1
    load_0_7_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_7_16  arc_capacity_612  -30
    arc_0_7_16  connected_order_arc_613  -17
    arc_0_7_16  out_degree_937  1
    arc_0_7_16  in_degree_994  1
    arc_0_7_16  original_T_including_depot_unload_1006  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_7_16  arc_capacity_612  1
    load_0_7_16  segment_load_conservation_941  1
    load_0_7_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_614  -30
    arc_0_8_0  depot_return_or_bypass_894  1
    arc_0_8_0  out_degree_944  1
    arc_0_8_0  original_T_including_depot_unload_1006  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_614  1
    load_0_8_0  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_615  -30
    arc_0_8_1  connected_order_arc_616  -17
    arc_0_8_1  in_degree_896  1
    arc_0_8_1  out_degree_944  1
    arc_0_8_1  original_T_including_depot_unload_1006  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_615  1
    load_0_8_1  segment_load_conservation_899  -1
    load_0_8_1  segment_prefix_lb_900  1
    load_0_8_1  segment_prefix_ub_901  1
    load_0_8_1  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_617  -30
    arc_0_8_2  connected_order_arc_618  -17
    arc_0_8_2  in_degree_903  1
    arc_0_8_2  out_degree_944  1
    arc_0_8_2  original_T_including_depot_unload_1006  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_617  1
    load_0_8_2  segment_load_conservation_906  -1
    load_0_8_2  segment_prefix_lb_907  1
    load_0_8_2  segment_prefix_ub_908  1
    load_0_8_2  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_619  -30
    arc_0_8_3  connected_order_arc_620  -17
    arc_0_8_3  in_degree_910  1
    arc_0_8_3  out_degree_944  1
    arc_0_8_3  original_T_including_depot_unload_1006  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_619  1
    load_0_8_3  segment_load_conservation_913  -1
    load_0_8_3  segment_prefix_lb_914  1
    load_0_8_3  segment_prefix_ub_915  1
    load_0_8_3  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_621  -30
    arc_0_8_4  connected_order_arc_622  -17
    arc_0_8_4  in_degree_917  1
    arc_0_8_4  out_degree_944  1
    arc_0_8_4  original_T_including_depot_unload_1006  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_621  1
    load_0_8_4  segment_load_conservation_920  -1
    load_0_8_4  segment_prefix_lb_921  1
    load_0_8_4  segment_prefix_ub_922  1
    load_0_8_4  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_623  -30
    arc_0_8_5  connected_order_arc_624  -17
    arc_0_8_5  in_degree_924  1
    arc_0_8_5  out_degree_944  1
    arc_0_8_5  original_T_including_depot_unload_1006  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_623  1
    load_0_8_5  segment_load_conservation_927  -1
    load_0_8_5  segment_prefix_lb_928  1
    load_0_8_5  segment_prefix_ub_929  1
    load_0_8_5  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_6  arc_capacity_625  -30
    arc_0_8_6  connected_order_arc_626  -17
    arc_0_8_6  in_degree_931  1
    arc_0_8_6  out_degree_944  1
    arc_0_8_6  original_T_including_depot_unload_1006  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_6  arc_capacity_625  1
    load_0_8_6  segment_load_conservation_934  -1
    load_0_8_6  segment_prefix_lb_935  1
    load_0_8_6  segment_prefix_ub_936  1
    load_0_8_6  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_7  arc_capacity_627  -30
    arc_0_8_7  connected_order_arc_628  -17
    arc_0_8_7  in_degree_938  1
    arc_0_8_7  out_degree_944  1
    arc_0_8_7  original_T_including_depot_unload_1006  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_7  arc_capacity_627  1
    load_0_8_7  segment_load_conservation_941  -1
    load_0_8_7  segment_prefix_lb_942  1
    load_0_8_7  segment_prefix_ub_943  1
    load_0_8_7  segment_load_conservation_948  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_9  arc_capacity_629  -30
    arc_0_8_9  connected_order_arc_630  -17
    arc_0_8_9  out_degree_944  1
    arc_0_8_9  in_degree_952  1
    arc_0_8_9  original_T_including_depot_unload_1006  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_9  arc_capacity_629  1
    load_0_8_9  segment_load_conservation_948  1
    load_0_8_9  free_load_conservation_956  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_10  arc_capacity_631  -30
    arc_0_8_10  connected_order_arc_632  -17
    arc_0_8_10  out_degree_944  1
    arc_0_8_10  in_degree_958  1
    arc_0_8_10  original_T_including_depot_unload_1006  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_10  arc_capacity_631  1
    load_0_8_10  segment_load_conservation_948  1
    load_0_8_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_633  -30
    arc_0_8_11  connected_order_arc_634  -17
    arc_0_8_11  out_degree_944  1
    arc_0_8_11  in_degree_964  1
    arc_0_8_11  original_T_including_depot_unload_1006  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_633  1
    load_0_8_11  segment_load_conservation_948  1
    load_0_8_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_635  -30
    arc_0_8_12  connected_order_arc_636  -17
    arc_0_8_12  out_degree_944  1
    arc_0_8_12  in_degree_970  1
    arc_0_8_12  original_T_including_depot_unload_1006  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_635  1
    load_0_8_12  segment_load_conservation_948  1
    load_0_8_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_637  -30
    arc_0_8_13  connected_order_arc_638  -17
    arc_0_8_13  out_degree_944  1
    arc_0_8_13  in_degree_976  1
    arc_0_8_13  original_T_including_depot_unload_1006  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_637  1
    load_0_8_13  segment_load_conservation_948  1
    load_0_8_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_639  -30
    arc_0_8_14  connected_order_arc_640  -17
    arc_0_8_14  out_degree_944  1
    arc_0_8_14  in_degree_982  1
    arc_0_8_14  original_T_including_depot_unload_1006  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_639  1
    load_0_8_14  segment_load_conservation_948  1
    load_0_8_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_641  -30
    arc_0_8_15  connected_order_arc_642  -17
    arc_0_8_15  out_degree_944  1
    arc_0_8_15  in_degree_988  1
    arc_0_8_15  original_T_including_depot_unload_1006  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_641  1
    load_0_8_15  segment_load_conservation_948  1
    load_0_8_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_16  arc_capacity_643  -30
    arc_0_8_16  connected_order_arc_644  -17
    arc_0_8_16  out_degree_944  1
    arc_0_8_16  in_degree_994  1
    arc_0_8_16  original_T_including_depot_unload_1006  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_16  arc_capacity_643  1
    load_0_8_16  segment_load_conservation_948  1
    load_0_8_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_645  -30
    arc_0_9_0  depot_return_or_bypass_894  1
    arc_0_9_0  out_degree_951  1
    arc_0_9_0  original_T_including_depot_unload_1006  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_645  1
    load_0_9_0  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_646  -30
    arc_0_9_1  connected_order_arc_647  -17
    arc_0_9_1  in_degree_896  1
    arc_0_9_1  out_degree_951  1
    arc_0_9_1  original_T_including_depot_unload_1006  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_646  1
    load_0_9_1  segment_load_conservation_899  -1
    load_0_9_1  segment_prefix_lb_900  1
    load_0_9_1  segment_prefix_ub_901  1
    load_0_9_1  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_648  -30
    arc_0_9_2  connected_order_arc_649  -17
    arc_0_9_2  in_degree_903  1
    arc_0_9_2  out_degree_951  1
    arc_0_9_2  original_T_including_depot_unload_1006  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_648  1
    load_0_9_2  segment_load_conservation_906  -1
    load_0_9_2  segment_prefix_lb_907  1
    load_0_9_2  segment_prefix_ub_908  1
    load_0_9_2  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_650  -30
    arc_0_9_3  connected_order_arc_651  -17
    arc_0_9_3  in_degree_910  1
    arc_0_9_3  out_degree_951  1
    arc_0_9_3  original_T_including_depot_unload_1006  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_650  1
    load_0_9_3  segment_load_conservation_913  -1
    load_0_9_3  segment_prefix_lb_914  1
    load_0_9_3  segment_prefix_ub_915  1
    load_0_9_3  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_652  -30
    arc_0_9_4  connected_order_arc_653  -17
    arc_0_9_4  in_degree_917  1
    arc_0_9_4  out_degree_951  1
    arc_0_9_4  original_T_including_depot_unload_1006  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_652  1
    load_0_9_4  segment_load_conservation_920  -1
    load_0_9_4  segment_prefix_lb_921  1
    load_0_9_4  segment_prefix_ub_922  1
    load_0_9_4  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_654  -30
    arc_0_9_5  connected_order_arc_655  -17
    arc_0_9_5  in_degree_924  1
    arc_0_9_5  out_degree_951  1
    arc_0_9_5  original_T_including_depot_unload_1006  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_654  1
    load_0_9_5  segment_load_conservation_927  -1
    load_0_9_5  segment_prefix_lb_928  1
    load_0_9_5  segment_prefix_ub_929  1
    load_0_9_5  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_6  arc_capacity_656  -30
    arc_0_9_6  connected_order_arc_657  -17
    arc_0_9_6  in_degree_931  1
    arc_0_9_6  out_degree_951  1
    arc_0_9_6  original_T_including_depot_unload_1006  1.9548039027038737e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_6  arc_capacity_656  1
    load_0_9_6  segment_load_conservation_934  -1
    load_0_9_6  segment_prefix_lb_935  1
    load_0_9_6  segment_prefix_ub_936  1
    load_0_9_6  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_7  arc_capacity_658  -30
    arc_0_9_7  connected_order_arc_659  -17
    arc_0_9_7  in_degree_938  1
    arc_0_9_7  out_degree_951  1
    arc_0_9_7  original_T_including_depot_unload_1006  1.8467456333549035e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_7  arc_capacity_658  1
    load_0_9_7  segment_load_conservation_941  -1
    load_0_9_7  segment_prefix_lb_942  1
    load_0_9_7  segment_prefix_ub_943  1
    load_0_9_7  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_8  arc_capacity_660  -30
    arc_0_9_8  connected_order_arc_661  -17
    arc_0_9_8  in_degree_945  1
    arc_0_9_8  out_degree_951  1
    arc_0_9_8  original_T_including_depot_unload_1006  1.9007789738787540e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_8  arc_capacity_660  1
    load_0_9_8  segment_load_conservation_948  -1
    load_0_9_8  segment_prefix_lb_949  1
    load_0_9_8  segment_prefix_ub_950  1
    load_0_9_8  free_load_conservation_956  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_662  -30
    arc_0_9_10  connected_order_arc_663  -17
    arc_0_9_10  out_degree_951  1
    arc_0_9_10  in_degree_958  1
    arc_0_9_10  original_T_including_depot_unload_1006  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_662  1
    load_0_9_10  free_load_conservation_956  1
    load_0_9_10  free_load_conservation_962  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_664  -30
    arc_0_9_11  connected_order_arc_665  -17
    arc_0_9_11  out_degree_951  1
    arc_0_9_11  in_degree_964  1
    arc_0_9_11  original_T_including_depot_unload_1006  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_664  1
    load_0_9_11  free_load_conservation_956  1
    load_0_9_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_666  -30
    arc_0_9_12  connected_order_arc_667  -17
    arc_0_9_12  out_degree_951  1
    arc_0_9_12  in_degree_970  1
    arc_0_9_12  original_T_including_depot_unload_1006  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_666  1
    load_0_9_12  free_load_conservation_956  1
    load_0_9_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_668  -30
    arc_0_9_13  connected_order_arc_669  -17
    arc_0_9_13  out_degree_951  1
    arc_0_9_13  in_degree_976  1
    arc_0_9_13  original_T_including_depot_unload_1006  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_668  1
    load_0_9_13  free_load_conservation_956  1
    load_0_9_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_670  -30
    arc_0_9_14  connected_order_arc_671  -17
    arc_0_9_14  out_degree_951  1
    arc_0_9_14  in_degree_982  1
    arc_0_9_14  original_T_including_depot_unload_1006  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_670  1
    load_0_9_14  free_load_conservation_956  1
    load_0_9_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_672  -30
    arc_0_9_15  connected_order_arc_673  -17
    arc_0_9_15  out_degree_951  1
    arc_0_9_15  in_degree_988  1
    arc_0_9_15  original_T_including_depot_unload_1006  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_672  1
    load_0_9_15  free_load_conservation_956  1
    load_0_9_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_16  arc_capacity_674  -30
    arc_0_9_16  connected_order_arc_675  -17
    arc_0_9_16  out_degree_951  1
    arc_0_9_16  in_degree_994  1
    arc_0_9_16  original_T_including_depot_unload_1006  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_16  arc_capacity_674  1
    load_0_9_16  free_load_conservation_956  1
    load_0_9_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_676  -30
    arc_0_10_0  depot_return_or_bypass_894  1
    arc_0_10_0  out_degree_957  1
    arc_0_10_0  original_T_including_depot_unload_1006  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_676  1
    load_0_10_0  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_677  -30
    arc_0_10_1  connected_order_arc_678  -17
    arc_0_10_1  in_degree_896  1
    arc_0_10_1  out_degree_957  1
    arc_0_10_1  original_T_including_depot_unload_1006  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_677  1
    load_0_10_1  segment_load_conservation_899  -1
    load_0_10_1  segment_prefix_lb_900  1
    load_0_10_1  segment_prefix_ub_901  1
    load_0_10_1  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_679  -30
    arc_0_10_2  connected_order_arc_680  -17
    arc_0_10_2  in_degree_903  1
    arc_0_10_2  out_degree_957  1
    arc_0_10_2  original_T_including_depot_unload_1006  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_679  1
    load_0_10_2  segment_load_conservation_906  -1
    load_0_10_2  segment_prefix_lb_907  1
    load_0_10_2  segment_prefix_ub_908  1
    load_0_10_2  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_681  -30
    arc_0_10_3  connected_order_arc_682  -17
    arc_0_10_3  in_degree_910  1
    arc_0_10_3  out_degree_957  1
    arc_0_10_3  original_T_including_depot_unload_1006  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_681  1
    load_0_10_3  segment_load_conservation_913  -1
    load_0_10_3  segment_prefix_lb_914  1
    load_0_10_3  segment_prefix_ub_915  1
    load_0_10_3  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_683  -30
    arc_0_10_4  connected_order_arc_684  -17
    arc_0_10_4  in_degree_917  1
    arc_0_10_4  out_degree_957  1
    arc_0_10_4  original_T_including_depot_unload_1006  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_683  1
    load_0_10_4  segment_load_conservation_920  -1
    load_0_10_4  segment_prefix_lb_921  1
    load_0_10_4  segment_prefix_ub_922  1
    load_0_10_4  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_685  -30
    arc_0_10_5  connected_order_arc_686  -17
    arc_0_10_5  in_degree_924  1
    arc_0_10_5  out_degree_957  1
    arc_0_10_5  original_T_including_depot_unload_1006  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_685  1
    load_0_10_5  segment_load_conservation_927  -1
    load_0_10_5  segment_prefix_lb_928  1
    load_0_10_5  segment_prefix_ub_929  1
    load_0_10_5  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_6  arc_capacity_687  -30
    arc_0_10_6  connected_order_arc_688  -17
    arc_0_10_6  in_degree_931  1
    arc_0_10_6  out_degree_957  1
    arc_0_10_6  original_T_including_depot_unload_1006  1.9740618091449423e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_6  arc_capacity_687  1
    load_0_10_6  segment_load_conservation_934  -1
    load_0_10_6  segment_prefix_lb_935  1
    load_0_10_6  segment_prefix_ub_936  1
    load_0_10_6  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_7  arc_capacity_689  -30
    arc_0_10_7  connected_order_arc_690  -17
    arc_0_10_7  in_degree_938  1
    arc_0_10_7  out_degree_957  1
    arc_0_10_7  original_T_including_depot_unload_1006  1.8739441025189553e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_7  arc_capacity_689  1
    load_0_10_7  segment_load_conservation_941  -1
    load_0_10_7  segment_prefix_lb_942  1
    load_0_10_7  segment_prefix_ub_943  1
    load_0_10_7  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_8  arc_capacity_691  -30
    arc_0_10_8  connected_order_arc_692  -17
    arc_0_10_8  in_degree_945  1
    arc_0_10_8  out_degree_957  1
    arc_0_10_8  original_T_including_depot_unload_1006  1.9425880448191174e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_8  arc_capacity_691  1
    load_0_10_8  segment_load_conservation_948  -1
    load_0_10_8  segment_prefix_lb_949  1
    load_0_10_8  segment_prefix_ub_950  1
    load_0_10_8  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_693  -30
    arc_0_10_9  connected_order_arc_694  -17
    arc_0_10_9  in_degree_952  1
    arc_0_10_9  out_degree_957  1
    arc_0_10_9  original_T_including_depot_unload_1006  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_693  1
    load_0_10_9  free_load_conservation_956  -1
    load_0_10_9  free_load_conservation_962  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_695  -30
    arc_0_10_11  connected_order_arc_696  -17
    arc_0_10_11  out_degree_957  1
    arc_0_10_11  in_degree_964  1
    arc_0_10_11  original_T_including_depot_unload_1006  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_695  1
    load_0_10_11  free_load_conservation_962  1
    load_0_10_11  free_load_conservation_968  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_697  -30
    arc_0_10_12  connected_order_arc_698  -17
    arc_0_10_12  out_degree_957  1
    arc_0_10_12  in_degree_970  1
    arc_0_10_12  original_T_including_depot_unload_1006  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_697  1
    load_0_10_12  free_load_conservation_962  1
    load_0_10_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_699  -30
    arc_0_10_13  connected_order_arc_700  -17
    arc_0_10_13  out_degree_957  1
    arc_0_10_13  in_degree_976  1
    arc_0_10_13  original_T_including_depot_unload_1006  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_699  1
    load_0_10_13  free_load_conservation_962  1
    load_0_10_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_701  -30
    arc_0_10_14  connected_order_arc_702  -17
    arc_0_10_14  out_degree_957  1
    arc_0_10_14  in_degree_982  1
    arc_0_10_14  original_T_including_depot_unload_1006  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_701  1
    load_0_10_14  free_load_conservation_962  1
    load_0_10_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_703  -30
    arc_0_10_15  connected_order_arc_704  -17
    arc_0_10_15  out_degree_957  1
    arc_0_10_15  in_degree_988  1
    arc_0_10_15  original_T_including_depot_unload_1006  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_703  1
    load_0_10_15  free_load_conservation_962  1
    load_0_10_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_16  arc_capacity_705  -30
    arc_0_10_16  connected_order_arc_706  -17
    arc_0_10_16  out_degree_957  1
    arc_0_10_16  in_degree_994  1
    arc_0_10_16  original_T_including_depot_unload_1006  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_16  arc_capacity_705  1
    load_0_10_16  free_load_conservation_962  1
    load_0_10_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_707  -30
    arc_0_11_0  depot_return_or_bypass_894  1
    arc_0_11_0  out_degree_963  1
    arc_0_11_0  original_T_including_depot_unload_1006  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_707  1
    load_0_11_0  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_708  -30
    arc_0_11_1  connected_order_arc_709  -17
    arc_0_11_1  in_degree_896  1
    arc_0_11_1  out_degree_963  1
    arc_0_11_1  original_T_including_depot_unload_1006  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_708  1
    load_0_11_1  segment_load_conservation_899  -1
    load_0_11_1  segment_prefix_lb_900  1
    load_0_11_1  segment_prefix_ub_901  1
    load_0_11_1  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_710  -30
    arc_0_11_2  connected_order_arc_711  -17
    arc_0_11_2  in_degree_903  1
    arc_0_11_2  out_degree_963  1
    arc_0_11_2  original_T_including_depot_unload_1006  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_710  1
    load_0_11_2  segment_load_conservation_906  -1
    load_0_11_2  segment_prefix_lb_907  1
    load_0_11_2  segment_prefix_ub_908  1
    load_0_11_2  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_712  -30
    arc_0_11_3  connected_order_arc_713  -17
    arc_0_11_3  in_degree_910  1
    arc_0_11_3  out_degree_963  1
    arc_0_11_3  original_T_including_depot_unload_1006  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_712  1
    load_0_11_3  segment_load_conservation_913  -1
    load_0_11_3  segment_prefix_lb_914  1
    load_0_11_3  segment_prefix_ub_915  1
    load_0_11_3  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_714  -30
    arc_0_11_4  connected_order_arc_715  -17
    arc_0_11_4  in_degree_917  1
    arc_0_11_4  out_degree_963  1
    arc_0_11_4  original_T_including_depot_unload_1006  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_714  1
    load_0_11_4  segment_load_conservation_920  -1
    load_0_11_4  segment_prefix_lb_921  1
    load_0_11_4  segment_prefix_ub_922  1
    load_0_11_4  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_716  -30
    arc_0_11_5  connected_order_arc_717  -17
    arc_0_11_5  in_degree_924  1
    arc_0_11_5  out_degree_963  1
    arc_0_11_5  original_T_including_depot_unload_1006  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_716  1
    load_0_11_5  segment_load_conservation_927  -1
    load_0_11_5  segment_prefix_lb_928  1
    load_0_11_5  segment_prefix_ub_929  1
    load_0_11_5  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_6  arc_capacity_718  -30
    arc_0_11_6  connected_order_arc_719  -17
    arc_0_11_6  in_degree_931  1
    arc_0_11_6  out_degree_963  1
    arc_0_11_6  original_T_including_depot_unload_1006  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_6  arc_capacity_718  1
    load_0_11_6  segment_load_conservation_934  -1
    load_0_11_6  segment_prefix_lb_935  1
    load_0_11_6  segment_prefix_ub_936  1
    load_0_11_6  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_7  arc_capacity_720  -30
    arc_0_11_7  connected_order_arc_721  -17
    arc_0_11_7  in_degree_938  1
    arc_0_11_7  out_degree_963  1
    arc_0_11_7  original_T_including_depot_unload_1006  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_7  arc_capacity_720  1
    load_0_11_7  segment_load_conservation_941  -1
    load_0_11_7  segment_prefix_lb_942  1
    load_0_11_7  segment_prefix_ub_943  1
    load_0_11_7  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_722  -30
    arc_0_11_8  connected_order_arc_723  -17
    arc_0_11_8  in_degree_945  1
    arc_0_11_8  out_degree_963  1
    arc_0_11_8  original_T_including_depot_unload_1006  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_722  1
    load_0_11_8  segment_load_conservation_948  -1
    load_0_11_8  segment_prefix_lb_949  1
    load_0_11_8  segment_prefix_ub_950  1
    load_0_11_8  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_724  -30
    arc_0_11_9  connected_order_arc_725  -17
    arc_0_11_9  in_degree_952  1
    arc_0_11_9  out_degree_963  1
    arc_0_11_9  original_T_including_depot_unload_1006  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_724  1
    load_0_11_9  free_load_conservation_956  -1
    load_0_11_9  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_726  -30
    arc_0_11_10  connected_order_arc_727  -17
    arc_0_11_10  in_degree_958  1
    arc_0_11_10  out_degree_963  1
    arc_0_11_10  original_T_including_depot_unload_1006  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_726  1
    load_0_11_10  free_load_conservation_962  -1
    load_0_11_10  free_load_conservation_968  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_728  -30
    arc_0_11_12  connected_order_arc_729  -17
    arc_0_11_12  out_degree_963  1
    arc_0_11_12  in_degree_970  1
    arc_0_11_12  original_T_including_depot_unload_1006  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_728  1
    load_0_11_12  free_load_conservation_968  1
    load_0_11_12  free_load_conservation_974  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_730  -30
    arc_0_11_13  connected_order_arc_731  -17
    arc_0_11_13  out_degree_963  1
    arc_0_11_13  in_degree_976  1
    arc_0_11_13  original_T_including_depot_unload_1006  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_730  1
    load_0_11_13  free_load_conservation_968  1
    load_0_11_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_732  -30
    arc_0_11_14  connected_order_arc_733  -17
    arc_0_11_14  out_degree_963  1
    arc_0_11_14  in_degree_982  1
    arc_0_11_14  original_T_including_depot_unload_1006  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_732  1
    load_0_11_14  free_load_conservation_968  1
    load_0_11_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_734  -30
    arc_0_11_15  connected_order_arc_735  -17
    arc_0_11_15  out_degree_963  1
    arc_0_11_15  in_degree_988  1
    arc_0_11_15  original_T_including_depot_unload_1006  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_734  1
    load_0_11_15  free_load_conservation_968  1
    load_0_11_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_16  arc_capacity_736  -30
    arc_0_11_16  connected_order_arc_737  -17
    arc_0_11_16  out_degree_963  1
    arc_0_11_16  in_degree_994  1
    arc_0_11_16  original_T_including_depot_unload_1006  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_16  arc_capacity_736  1
    load_0_11_16  free_load_conservation_968  1
    load_0_11_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_738  -30
    arc_0_12_0  depot_return_or_bypass_894  1
    arc_0_12_0  out_degree_969  1
    arc_0_12_0  original_T_including_depot_unload_1006  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_738  1
    load_0_12_0  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_739  -30
    arc_0_12_1  connected_order_arc_740  -17
    arc_0_12_1  in_degree_896  1
    arc_0_12_1  out_degree_969  1
    arc_0_12_1  original_T_including_depot_unload_1006  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_739  1
    load_0_12_1  segment_load_conservation_899  -1
    load_0_12_1  segment_prefix_lb_900  1
    load_0_12_1  segment_prefix_ub_901  1
    load_0_12_1  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_741  -30
    arc_0_12_2  connected_order_arc_742  -17
    arc_0_12_2  in_degree_903  1
    arc_0_12_2  out_degree_969  1
    arc_0_12_2  original_T_including_depot_unload_1006  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_741  1
    load_0_12_2  segment_load_conservation_906  -1
    load_0_12_2  segment_prefix_lb_907  1
    load_0_12_2  segment_prefix_ub_908  1
    load_0_12_2  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_743  -30
    arc_0_12_3  connected_order_arc_744  -17
    arc_0_12_3  in_degree_910  1
    arc_0_12_3  out_degree_969  1
    arc_0_12_3  original_T_including_depot_unload_1006  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_743  1
    load_0_12_3  segment_load_conservation_913  -1
    load_0_12_3  segment_prefix_lb_914  1
    load_0_12_3  segment_prefix_ub_915  1
    load_0_12_3  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_745  -30
    arc_0_12_4  connected_order_arc_746  -17
    arc_0_12_4  in_degree_917  1
    arc_0_12_4  out_degree_969  1
    arc_0_12_4  original_T_including_depot_unload_1006  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_745  1
    load_0_12_4  segment_load_conservation_920  -1
    load_0_12_4  segment_prefix_lb_921  1
    load_0_12_4  segment_prefix_ub_922  1
    load_0_12_4  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_747  -30
    arc_0_12_5  connected_order_arc_748  -17
    arc_0_12_5  in_degree_924  1
    arc_0_12_5  out_degree_969  1
    arc_0_12_5  original_T_including_depot_unload_1006  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_747  1
    load_0_12_5  segment_load_conservation_927  -1
    load_0_12_5  segment_prefix_lb_928  1
    load_0_12_5  segment_prefix_ub_929  1
    load_0_12_5  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_6  arc_capacity_749  -30
    arc_0_12_6  connected_order_arc_750  -17
    arc_0_12_6  in_degree_931  1
    arc_0_12_6  out_degree_969  1
    arc_0_12_6  original_T_including_depot_unload_1006  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_6  arc_capacity_749  1
    load_0_12_6  segment_load_conservation_934  -1
    load_0_12_6  segment_prefix_lb_935  1
    load_0_12_6  segment_prefix_ub_936  1
    load_0_12_6  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_7  arc_capacity_751  -30
    arc_0_12_7  connected_order_arc_752  -17
    arc_0_12_7  in_degree_938  1
    arc_0_12_7  out_degree_969  1
    arc_0_12_7  original_T_including_depot_unload_1006  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_7  arc_capacity_751  1
    load_0_12_7  segment_load_conservation_941  -1
    load_0_12_7  segment_prefix_lb_942  1
    load_0_12_7  segment_prefix_ub_943  1
    load_0_12_7  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_753  -30
    arc_0_12_8  connected_order_arc_754  -17
    arc_0_12_8  in_degree_945  1
    arc_0_12_8  out_degree_969  1
    arc_0_12_8  original_T_including_depot_unload_1006  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_753  1
    load_0_12_8  segment_load_conservation_948  -1
    load_0_12_8  segment_prefix_lb_949  1
    load_0_12_8  segment_prefix_ub_950  1
    load_0_12_8  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_755  -30
    arc_0_12_9  connected_order_arc_756  -17
    arc_0_12_9  in_degree_952  1
    arc_0_12_9  out_degree_969  1
    arc_0_12_9  original_T_including_depot_unload_1006  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_755  1
    load_0_12_9  free_load_conservation_956  -1
    load_0_12_9  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_757  -30
    arc_0_12_10  connected_order_arc_758  -17
    arc_0_12_10  in_degree_958  1
    arc_0_12_10  out_degree_969  1
    arc_0_12_10  original_T_including_depot_unload_1006  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_757  1
    load_0_12_10  free_load_conservation_962  -1
    load_0_12_10  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_759  -30
    arc_0_12_11  connected_order_arc_760  -17
    arc_0_12_11  in_degree_964  1
    arc_0_12_11  out_degree_969  1
    arc_0_12_11  original_T_including_depot_unload_1006  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_759  1
    load_0_12_11  free_load_conservation_968  -1
    load_0_12_11  free_load_conservation_974  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_761  -30
    arc_0_12_13  connected_order_arc_762  -17
    arc_0_12_13  out_degree_969  1
    arc_0_12_13  in_degree_976  1
    arc_0_12_13  original_T_including_depot_unload_1006  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_761  1
    load_0_12_13  free_load_conservation_974  1
    load_0_12_13  free_load_conservation_980  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_763  -30
    arc_0_12_14  connected_order_arc_764  -17
    arc_0_12_14  out_degree_969  1
    arc_0_12_14  in_degree_982  1
    arc_0_12_14  original_T_including_depot_unload_1006  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_763  1
    load_0_12_14  free_load_conservation_974  1
    load_0_12_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_765  -30
    arc_0_12_15  connected_order_arc_766  -17
    arc_0_12_15  out_degree_969  1
    arc_0_12_15  in_degree_988  1
    arc_0_12_15  original_T_including_depot_unload_1006  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_765  1
    load_0_12_15  free_load_conservation_974  1
    load_0_12_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_767  -30
    arc_0_12_16  connected_order_arc_768  -17
    arc_0_12_16  out_degree_969  1
    arc_0_12_16  in_degree_994  1
    arc_0_12_16  original_T_including_depot_unload_1006  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_767  1
    load_0_12_16  free_load_conservation_974  1
    load_0_12_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_769  -30
    arc_0_13_0  depot_return_or_bypass_894  1
    arc_0_13_0  out_degree_975  1
    arc_0_13_0  original_T_including_depot_unload_1006  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_769  1
    load_0_13_0  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_770  -30
    arc_0_13_1  connected_order_arc_771  -17
    arc_0_13_1  in_degree_896  1
    arc_0_13_1  out_degree_975  1
    arc_0_13_1  original_T_including_depot_unload_1006  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_770  1
    load_0_13_1  segment_load_conservation_899  -1
    load_0_13_1  segment_prefix_lb_900  1
    load_0_13_1  segment_prefix_ub_901  1
    load_0_13_1  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_772  -30
    arc_0_13_2  connected_order_arc_773  -17
    arc_0_13_2  in_degree_903  1
    arc_0_13_2  out_degree_975  1
    arc_0_13_2  original_T_including_depot_unload_1006  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_772  1
    load_0_13_2  segment_load_conservation_906  -1
    load_0_13_2  segment_prefix_lb_907  1
    load_0_13_2  segment_prefix_ub_908  1
    load_0_13_2  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_774  -30
    arc_0_13_3  connected_order_arc_775  -17
    arc_0_13_3  in_degree_910  1
    arc_0_13_3  out_degree_975  1
    arc_0_13_3  original_T_including_depot_unload_1006  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_774  1
    load_0_13_3  segment_load_conservation_913  -1
    load_0_13_3  segment_prefix_lb_914  1
    load_0_13_3  segment_prefix_ub_915  1
    load_0_13_3  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_776  -30
    arc_0_13_4  connected_order_arc_777  -17
    arc_0_13_4  in_degree_917  1
    arc_0_13_4  out_degree_975  1
    arc_0_13_4  original_T_including_depot_unload_1006  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_776  1
    load_0_13_4  segment_load_conservation_920  -1
    load_0_13_4  segment_prefix_lb_921  1
    load_0_13_4  segment_prefix_ub_922  1
    load_0_13_4  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_778  -30
    arc_0_13_5  connected_order_arc_779  -17
    arc_0_13_5  in_degree_924  1
    arc_0_13_5  out_degree_975  1
    arc_0_13_5  original_T_including_depot_unload_1006  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_778  1
    load_0_13_5  segment_load_conservation_927  -1
    load_0_13_5  segment_prefix_lb_928  1
    load_0_13_5  segment_prefix_ub_929  1
    load_0_13_5  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_6  arc_capacity_780  -30
    arc_0_13_6  connected_order_arc_781  -17
    arc_0_13_6  in_degree_931  1
    arc_0_13_6  out_degree_975  1
    arc_0_13_6  original_T_including_depot_unload_1006  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_6  arc_capacity_780  1
    load_0_13_6  segment_load_conservation_934  -1
    load_0_13_6  segment_prefix_lb_935  1
    load_0_13_6  segment_prefix_ub_936  1
    load_0_13_6  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_7  arc_capacity_782  -30
    arc_0_13_7  connected_order_arc_783  -17
    arc_0_13_7  in_degree_938  1
    arc_0_13_7  out_degree_975  1
    arc_0_13_7  original_T_including_depot_unload_1006  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_7  arc_capacity_782  1
    load_0_13_7  segment_load_conservation_941  -1
    load_0_13_7  segment_prefix_lb_942  1
    load_0_13_7  segment_prefix_ub_943  1
    load_0_13_7  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_784  -30
    arc_0_13_8  connected_order_arc_785  -17
    arc_0_13_8  in_degree_945  1
    arc_0_13_8  out_degree_975  1
    arc_0_13_8  original_T_including_depot_unload_1006  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_784  1
    load_0_13_8  segment_load_conservation_948  -1
    load_0_13_8  segment_prefix_lb_949  1
    load_0_13_8  segment_prefix_ub_950  1
    load_0_13_8  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_786  -30
    arc_0_13_9  connected_order_arc_787  -17
    arc_0_13_9  in_degree_952  1
    arc_0_13_9  out_degree_975  1
    arc_0_13_9  original_T_including_depot_unload_1006  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_786  1
    load_0_13_9  free_load_conservation_956  -1
    load_0_13_9  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_788  -30
    arc_0_13_10  connected_order_arc_789  -17
    arc_0_13_10  in_degree_958  1
    arc_0_13_10  out_degree_975  1
    arc_0_13_10  original_T_including_depot_unload_1006  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_788  1
    load_0_13_10  free_load_conservation_962  -1
    load_0_13_10  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_790  -30
    arc_0_13_11  connected_order_arc_791  -17
    arc_0_13_11  in_degree_964  1
    arc_0_13_11  out_degree_975  1
    arc_0_13_11  original_T_including_depot_unload_1006  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_790  1
    load_0_13_11  free_load_conservation_968  -1
    load_0_13_11  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_792  -30
    arc_0_13_12  connected_order_arc_793  -17
    arc_0_13_12  in_degree_970  1
    arc_0_13_12  out_degree_975  1
    arc_0_13_12  original_T_including_depot_unload_1006  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_792  1
    load_0_13_12  free_load_conservation_974  -1
    load_0_13_12  free_load_conservation_980  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_794  -30
    arc_0_13_14  connected_order_arc_795  -17
    arc_0_13_14  out_degree_975  1
    arc_0_13_14  in_degree_982  1
    arc_0_13_14  original_T_including_depot_unload_1006  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_794  1
    load_0_13_14  free_load_conservation_980  1
    load_0_13_14  free_load_conservation_986  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_796  -30
    arc_0_13_15  connected_order_arc_797  -17
    arc_0_13_15  out_degree_975  1
    arc_0_13_15  in_degree_988  1
    arc_0_13_15  original_T_including_depot_unload_1006  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_796  1
    load_0_13_15  free_load_conservation_980  1
    load_0_13_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_798  -30
    arc_0_13_16  connected_order_arc_799  -17
    arc_0_13_16  out_degree_975  1
    arc_0_13_16  in_degree_994  1
    arc_0_13_16  original_T_including_depot_unload_1006  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_798  1
    load_0_13_16  free_load_conservation_980  1
    load_0_13_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_800  -30
    arc_0_14_0  depot_return_or_bypass_894  1
    arc_0_14_0  out_degree_981  1
    arc_0_14_0  original_T_including_depot_unload_1006  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_800  1
    load_0_14_0  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_801  -30
    arc_0_14_1  connected_order_arc_802  -17
    arc_0_14_1  in_degree_896  1
    arc_0_14_1  out_degree_981  1
    arc_0_14_1  original_T_including_depot_unload_1006  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_801  1
    load_0_14_1  segment_load_conservation_899  -1
    load_0_14_1  segment_prefix_lb_900  1
    load_0_14_1  segment_prefix_ub_901  1
    load_0_14_1  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_803  -30
    arc_0_14_2  connected_order_arc_804  -17
    arc_0_14_2  in_degree_903  1
    arc_0_14_2  out_degree_981  1
    arc_0_14_2  original_T_including_depot_unload_1006  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_803  1
    load_0_14_2  segment_load_conservation_906  -1
    load_0_14_2  segment_prefix_lb_907  1
    load_0_14_2  segment_prefix_ub_908  1
    load_0_14_2  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_805  -30
    arc_0_14_3  connected_order_arc_806  -17
    arc_0_14_3  in_degree_910  1
    arc_0_14_3  out_degree_981  1
    arc_0_14_3  original_T_including_depot_unload_1006  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_805  1
    load_0_14_3  segment_load_conservation_913  -1
    load_0_14_3  segment_prefix_lb_914  1
    load_0_14_3  segment_prefix_ub_915  1
    load_0_14_3  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_807  -30
    arc_0_14_4  connected_order_arc_808  -17
    arc_0_14_4  in_degree_917  1
    arc_0_14_4  out_degree_981  1
    arc_0_14_4  original_T_including_depot_unload_1006  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_807  1
    load_0_14_4  segment_load_conservation_920  -1
    load_0_14_4  segment_prefix_lb_921  1
    load_0_14_4  segment_prefix_ub_922  1
    load_0_14_4  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_809  -30
    arc_0_14_5  connected_order_arc_810  -17
    arc_0_14_5  in_degree_924  1
    arc_0_14_5  out_degree_981  1
    arc_0_14_5  original_T_including_depot_unload_1006  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_809  1
    load_0_14_5  segment_load_conservation_927  -1
    load_0_14_5  segment_prefix_lb_928  1
    load_0_14_5  segment_prefix_ub_929  1
    load_0_14_5  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_6  arc_capacity_811  -30
    arc_0_14_6  connected_order_arc_812  -17
    arc_0_14_6  in_degree_931  1
    arc_0_14_6  out_degree_981  1
    arc_0_14_6  original_T_including_depot_unload_1006  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_6  arc_capacity_811  1
    load_0_14_6  segment_load_conservation_934  -1
    load_0_14_6  segment_prefix_lb_935  1
    load_0_14_6  segment_prefix_ub_936  1
    load_0_14_6  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_7  arc_capacity_813  -30
    arc_0_14_7  connected_order_arc_814  -17
    arc_0_14_7  in_degree_938  1
    arc_0_14_7  out_degree_981  1
    arc_0_14_7  original_T_including_depot_unload_1006  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_7  arc_capacity_813  1
    load_0_14_7  segment_load_conservation_941  -1
    load_0_14_7  segment_prefix_lb_942  1
    load_0_14_7  segment_prefix_ub_943  1
    load_0_14_7  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_815  -30
    arc_0_14_8  connected_order_arc_816  -17
    arc_0_14_8  in_degree_945  1
    arc_0_14_8  out_degree_981  1
    arc_0_14_8  original_T_including_depot_unload_1006  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_815  1
    load_0_14_8  segment_load_conservation_948  -1
    load_0_14_8  segment_prefix_lb_949  1
    load_0_14_8  segment_prefix_ub_950  1
    load_0_14_8  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_817  -30
    arc_0_14_9  connected_order_arc_818  -17
    arc_0_14_9  in_degree_952  1
    arc_0_14_9  out_degree_981  1
    arc_0_14_9  original_T_including_depot_unload_1006  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_817  1
    load_0_14_9  free_load_conservation_956  -1
    load_0_14_9  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_819  -30
    arc_0_14_10  connected_order_arc_820  -17
    arc_0_14_10  in_degree_958  1
    arc_0_14_10  out_degree_981  1
    arc_0_14_10  original_T_including_depot_unload_1006  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_819  1
    load_0_14_10  free_load_conservation_962  -1
    load_0_14_10  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_821  -30
    arc_0_14_11  connected_order_arc_822  -17
    arc_0_14_11  in_degree_964  1
    arc_0_14_11  out_degree_981  1
    arc_0_14_11  original_T_including_depot_unload_1006  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_821  1
    load_0_14_11  free_load_conservation_968  -1
    load_0_14_11  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_823  -30
    arc_0_14_12  connected_order_arc_824  -17
    arc_0_14_12  in_degree_970  1
    arc_0_14_12  out_degree_981  1
    arc_0_14_12  original_T_including_depot_unload_1006  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_823  1
    load_0_14_12  free_load_conservation_974  -1
    load_0_14_12  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_825  -30
    arc_0_14_13  connected_order_arc_826  -17
    arc_0_14_13  in_degree_976  1
    arc_0_14_13  out_degree_981  1
    arc_0_14_13  original_T_including_depot_unload_1006  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_825  1
    load_0_14_13  free_load_conservation_980  -1
    load_0_14_13  free_load_conservation_986  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_827  -30
    arc_0_14_15  connected_order_arc_828  -17
    arc_0_14_15  out_degree_981  1
    arc_0_14_15  in_degree_988  1
    arc_0_14_15  original_T_including_depot_unload_1006  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_827  1
    load_0_14_15  free_load_conservation_986  1
    load_0_14_15  free_load_conservation_992  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_829  -30
    arc_0_14_16  connected_order_arc_830  -17
    arc_0_14_16  out_degree_981  1
    arc_0_14_16  in_degree_994  1
    arc_0_14_16  original_T_including_depot_unload_1006  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_829  1
    load_0_14_16  free_load_conservation_986  1
    load_0_14_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_831  -30
    arc_0_15_0  depot_return_or_bypass_894  1
    arc_0_15_0  out_degree_987  1
    arc_0_15_0  original_T_including_depot_unload_1006  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_831  1
    load_0_15_0  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_832  -30
    arc_0_15_1  connected_order_arc_833  -17
    arc_0_15_1  in_degree_896  1
    arc_0_15_1  out_degree_987  1
    arc_0_15_1  original_T_including_depot_unload_1006  2.8800138602390562e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_832  1
    load_0_15_1  segment_load_conservation_899  -1
    load_0_15_1  segment_prefix_lb_900  1
    load_0_15_1  segment_prefix_ub_901  1
    load_0_15_1  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_834  -30
    arc_0_15_2  connected_order_arc_835  -17
    arc_0_15_2  in_degree_903  1
    arc_0_15_2  out_degree_987  1
    arc_0_15_2  original_T_including_depot_unload_1006  3.1528795137337825e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_834  1
    load_0_15_2  segment_load_conservation_906  -1
    load_0_15_2  segment_prefix_lb_907  1
    load_0_15_2  segment_prefix_ub_908  1
    load_0_15_2  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_836  -30
    arc_0_15_3  connected_order_arc_837  -17
    arc_0_15_3  in_degree_910  1
    arc_0_15_3  out_degree_987  1
    arc_0_15_3  original_T_including_depot_unload_1006  3.1658582590062310e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_836  1
    load_0_15_3  segment_load_conservation_913  -1
    load_0_15_3  segment_prefix_lb_914  1
    load_0_15_3  segment_prefix_ub_915  1
    load_0_15_3  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_838  -30
    arc_0_15_4  connected_order_arc_839  -17
    arc_0_15_4  in_degree_917  1
    arc_0_15_4  out_degree_987  1
    arc_0_15_4  original_T_including_depot_unload_1006  2.9442201339702592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_838  1
    load_0_15_4  segment_load_conservation_920  -1
    load_0_15_4  segment_prefix_lb_921  1
    load_0_15_4  segment_prefix_ub_922  1
    load_0_15_4  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_840  -30
    arc_0_15_5  connected_order_arc_841  -17
    arc_0_15_5  in_degree_924  1
    arc_0_15_5  out_degree_987  1
    arc_0_15_5  original_T_including_depot_unload_1006  2820.94140713384
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_840  1
    load_0_15_5  segment_load_conservation_927  -1
    load_0_15_5  segment_prefix_lb_928  1
    load_0_15_5  segment_prefix_ub_929  1
    load_0_15_5  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_6  arc_capacity_842  -30
    arc_0_15_6  connected_order_arc_843  -17
    arc_0_15_6  in_degree_931  1
    arc_0_15_6  out_degree_987  1
    arc_0_15_6  original_T_including_depot_unload_1006  2.7168118802834592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_6  arc_capacity_842  1
    load_0_15_6  segment_load_conservation_934  -1
    load_0_15_6  segment_prefix_lb_935  1
    load_0_15_6  segment_prefix_ub_936  1
    load_0_15_6  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_7  arc_capacity_844  -30
    arc_0_15_7  connected_order_arc_845  -17
    arc_0_15_7  in_degree_938  1
    arc_0_15_7  out_degree_987  1
    arc_0_15_7  original_T_including_depot_unload_1006  2.5598105628601829e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_7  arc_capacity_844  1
    load_0_15_7  segment_load_conservation_941  -1
    load_0_15_7  segment_prefix_lb_942  1
    load_0_15_7  segment_prefix_ub_943  1
    load_0_15_7  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_846  -30
    arc_0_15_8  connected_order_arc_847  -17
    arc_0_15_8  in_degree_945  1
    arc_0_15_8  out_degree_987  1
    arc_0_15_8  original_T_including_depot_unload_1006  2.4295946549751052e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_846  1
    load_0_15_8  segment_load_conservation_948  -1
    load_0_15_8  segment_prefix_lb_949  1
    load_0_15_8  segment_prefix_ub_950  1
    load_0_15_8  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_848  -30
    arc_0_15_9  connected_order_arc_849  -17
    arc_0_15_9  in_degree_952  1
    arc_0_15_9  out_degree_987  1
    arc_0_15_9  original_T_including_depot_unload_1006  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_848  1
    load_0_15_9  free_load_conservation_956  -1
    load_0_15_9  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_850  -30
    arc_0_15_10  connected_order_arc_851  -17
    arc_0_15_10  in_degree_958  1
    arc_0_15_10  out_degree_987  1
    arc_0_15_10  original_T_including_depot_unload_1006  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_850  1
    load_0_15_10  free_load_conservation_962  -1
    load_0_15_10  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_852  -30
    arc_0_15_11  connected_order_arc_853  -17
    arc_0_15_11  in_degree_964  1
    arc_0_15_11  out_degree_987  1
    arc_0_15_11  original_T_including_depot_unload_1006  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_852  1
    load_0_15_11  free_load_conservation_968  -1
    load_0_15_11  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_854  -30
    arc_0_15_12  connected_order_arc_855  -17
    arc_0_15_12  in_degree_970  1
    arc_0_15_12  out_degree_987  1
    arc_0_15_12  original_T_including_depot_unload_1006  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_854  1
    load_0_15_12  free_load_conservation_974  -1
    load_0_15_12  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_856  -30
    arc_0_15_13  connected_order_arc_857  -17
    arc_0_15_13  in_degree_976  1
    arc_0_15_13  out_degree_987  1
    arc_0_15_13  original_T_including_depot_unload_1006  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_856  1
    load_0_15_13  free_load_conservation_980  -1
    load_0_15_13  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_858  -30
    arc_0_15_14  connected_order_arc_859  -17
    arc_0_15_14  in_degree_982  1
    arc_0_15_14  out_degree_987  1
    arc_0_15_14  original_T_including_depot_unload_1006  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_858  1
    load_0_15_14  free_load_conservation_986  -1
    load_0_15_14  free_load_conservation_992  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_860  -30
    arc_0_15_16  connected_order_arc_861  -17
    arc_0_15_16  out_degree_987  1
    arc_0_15_16  in_degree_994  1
    arc_0_15_16  original_T_including_depot_unload_1006  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_860  1
    load_0_15_16  free_load_conservation_992  1
    load_0_15_16  free_load_conservation_998  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_862  -30
    arc_0_16_0  depot_return_or_bypass_894  1
    arc_0_16_0  out_degree_993  1
    arc_0_16_0  original_T_including_depot_unload_1006  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_862  1
    load_0_16_0  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_863  -30
    arc_0_16_1  connected_order_arc_864  -17
    arc_0_16_1  in_degree_896  1
    arc_0_16_1  out_degree_993  1
    arc_0_16_1  original_T_including_depot_unload_1006  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_863  1
    load_0_16_1  segment_load_conservation_899  -1
    load_0_16_1  segment_prefix_lb_900  1
    load_0_16_1  segment_prefix_ub_901  1
    load_0_16_1  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_865  -30
    arc_0_16_2  connected_order_arc_866  -17
    arc_0_16_2  in_degree_903  1
    arc_0_16_2  out_degree_993  1
    arc_0_16_2  original_T_including_depot_unload_1006  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_865  1
    load_0_16_2  segment_load_conservation_906  -1
    load_0_16_2  segment_prefix_lb_907  1
    load_0_16_2  segment_prefix_ub_908  1
    load_0_16_2  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_867  -30
    arc_0_16_3  connected_order_arc_868  -17
    arc_0_16_3  in_degree_910  1
    arc_0_16_3  out_degree_993  1
    arc_0_16_3  original_T_including_depot_unload_1006  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_867  1
    load_0_16_3  segment_load_conservation_913  -1
    load_0_16_3  segment_prefix_lb_914  1
    load_0_16_3  segment_prefix_ub_915  1
    load_0_16_3  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_869  -30
    arc_0_16_4  connected_order_arc_870  -17
    arc_0_16_4  in_degree_917  1
    arc_0_16_4  out_degree_993  1
    arc_0_16_4  original_T_including_depot_unload_1006  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_869  1
    load_0_16_4  segment_load_conservation_920  -1
    load_0_16_4  segment_prefix_lb_921  1
    load_0_16_4  segment_prefix_ub_922  1
    load_0_16_4  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_871  -30
    arc_0_16_5  connected_order_arc_872  -17
    arc_0_16_5  in_degree_924  1
    arc_0_16_5  out_degree_993  1
    arc_0_16_5  original_T_including_depot_unload_1006  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_871  1
    load_0_16_5  segment_load_conservation_927  -1
    load_0_16_5  segment_prefix_lb_928  1
    load_0_16_5  segment_prefix_ub_929  1
    load_0_16_5  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_6  arc_capacity_873  -30
    arc_0_16_6  connected_order_arc_874  -17
    arc_0_16_6  in_degree_931  1
    arc_0_16_6  out_degree_993  1
    arc_0_16_6  original_T_including_depot_unload_1006  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_16_6  arc_capacity_873  1
    load_0_16_6  segment_load_conservation_934  -1
    load_0_16_6  segment_prefix_lb_935  1
    load_0_16_6  segment_prefix_ub_936  1
    load_0_16_6  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_7  arc_capacity_875  -30
    arc_0_16_7  connected_order_arc_876  -17
    arc_0_16_7  in_degree_938  1
    arc_0_16_7  out_degree_993  1
    arc_0_16_7  original_T_including_depot_unload_1006  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_7  arc_capacity_875  1
    load_0_16_7  segment_load_conservation_941  -1
    load_0_16_7  segment_prefix_lb_942  1
    load_0_16_7  segment_prefix_ub_943  1
    load_0_16_7  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_8  arc_capacity_877  -30
    arc_0_16_8  connected_order_arc_878  -17
    arc_0_16_8  in_degree_945  1
    arc_0_16_8  out_degree_993  1
    arc_0_16_8  original_T_including_depot_unload_1006  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_8  arc_capacity_877  1
    load_0_16_8  segment_load_conservation_948  -1
    load_0_16_8  segment_prefix_lb_949  1
    load_0_16_8  segment_prefix_ub_950  1
    load_0_16_8  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_9  arc_capacity_879  -30
    arc_0_16_9  connected_order_arc_880  -17
    arc_0_16_9  in_degree_952  1
    arc_0_16_9  out_degree_993  1
    arc_0_16_9  original_T_including_depot_unload_1006  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_9  arc_capacity_879  1
    load_0_16_9  free_load_conservation_956  -1
    load_0_16_9  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_10  arc_capacity_881  -30
    arc_0_16_10  connected_order_arc_882  -17
    arc_0_16_10  in_degree_958  1
    arc_0_16_10  out_degree_993  1
    arc_0_16_10  original_T_including_depot_unload_1006  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_10  arc_capacity_881  1
    load_0_16_10  free_load_conservation_962  -1
    load_0_16_10  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_11  arc_capacity_883  -30
    arc_0_16_11  connected_order_arc_884  -17
    arc_0_16_11  in_degree_964  1
    arc_0_16_11  out_degree_993  1
    arc_0_16_11  original_T_including_depot_unload_1006  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_11  arc_capacity_883  1
    load_0_16_11  free_load_conservation_968  -1
    load_0_16_11  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_885  -30
    arc_0_16_12  connected_order_arc_886  -17
    arc_0_16_12  in_degree_970  1
    arc_0_16_12  out_degree_993  1
    arc_0_16_12  original_T_including_depot_unload_1006  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_885  1
    load_0_16_12  free_load_conservation_974  -1
    load_0_16_12  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_887  -30
    arc_0_16_13  connected_order_arc_888  -17
    arc_0_16_13  in_degree_976  1
    arc_0_16_13  out_degree_993  1
    arc_0_16_13  original_T_including_depot_unload_1006  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_887  1
    load_0_16_13  free_load_conservation_980  -1
    load_0_16_13  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_889  -30
    arc_0_16_14  connected_order_arc_890  -17
    arc_0_16_14  in_degree_982  1
    arc_0_16_14  out_degree_993  1
    arc_0_16_14  original_T_including_depot_unload_1006  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_889  1
    load_0_16_14  free_load_conservation_986  -1
    load_0_16_14  free_load_conservation_998  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_891  -30
    arc_0_16_15  connected_order_arc_892  -17
    arc_0_16_15  in_degree_988  1
    arc_0_16_15  out_degree_993  1
    arc_0_16_15  original_T_including_depot_unload_1006  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_891  1
    load_0_16_15  free_load_conservation_992  -1
    load_0_16_15  free_load_conservation_998  1
    visit_1_9  out_degree_1138  -1
    visit_1_9  in_degree_1139  -1
    visit_1_9  order_active_lb_1140  -1
    visit_1_9  order_active_ub_1141  -8
    visit_1_9  service_visit_def_1142  -1
    order_1_9  connected_order_arc_1018  -1
    order_1_9  connected_order_arc_1020  -1
    order_1_9  connected_order_arc_1022  -1
    order_1_9  connected_order_arc_1024  -1
    order_1_9  connected_order_arc_1026  -1
    order_1_9  connected_order_arc_1028  -1
    order_1_9  connected_order_arc_1030  -1
    order_1_9  connected_order_arc_1033  1
    order_1_9  connected_order_arc_1048  1
    order_1_9  connected_order_arc_1063  1
    order_1_9  connected_order_arc_1078  1
    order_1_9  connected_order_arc_1093  1
    order_1_9  connected_order_arc_1108  1
    order_1_9  connected_order_arc_1123  1
    order_1_9  order_active_lb_1140  1
    order_1_9  order_active_ub_1141  1
    visit_1_10  out_degree_1144  -1
    visit_1_10  in_degree_1145  -1
    visit_1_10  order_active_lb_1146  -1
    visit_1_10  order_active_ub_1147  -8
    visit_1_10  service_visit_def_1148  -1
    order_1_10  connected_order_arc_1018  1
    order_1_10  connected_order_arc_1033  -1
    order_1_10  connected_order_arc_1035  -1
    order_1_10  connected_order_arc_1037  -1
    order_1_10  connected_order_arc_1039  -1
    order_1_10  connected_order_arc_1041  -1
    order_1_10  connected_order_arc_1043  -1
    order_1_10  connected_order_arc_1045  -1
    order_1_10  connected_order_arc_1050  1
    order_1_10  connected_order_arc_1065  1
    order_1_10  connected_order_arc_1080  1
    order_1_10  connected_order_arc_1095  1
    order_1_10  connected_order_arc_1110  1
    order_1_10  connected_order_arc_1125  1
    order_1_10  order_active_lb_1146  1
    order_1_10  order_active_ub_1147  1
    visit_1_11  out_degree_1150  -1
    visit_1_11  in_degree_1151  -1
    visit_1_11  order_active_lb_1152  -1
    visit_1_11  order_active_ub_1153  -8
    visit_1_11  service_visit_def_1154  -1
    order_1_11  connected_order_arc_1020  1
    order_1_11  connected_order_arc_1035  1
    order_1_11  connected_order_arc_1048  -1
    order_1_11  connected_order_arc_1050  -1
    order_1_11  connected_order_arc_1052  -1
    order_1_11  connected_order_arc_1054  -1
    order_1_11  connected_order_arc_1056  -1
    order_1_11  connected_order_arc_1058  -1
    order_1_11  connected_order_arc_1060  -1
    order_1_11  connected_order_arc_1067  1
    order_1_11  connected_order_arc_1082  1
    order_1_11  connected_order_arc_1097  1
    order_1_11  connected_order_arc_1112  1
    order_1_11  connected_order_arc_1127  1
    order_1_11  order_active_lb_1152  1
    order_1_11  order_active_ub_1153  1
    visit_1_12  out_degree_1156  -1
    visit_1_12  in_degree_1157  -1
    visit_1_12  order_active_lb_1158  -1
    visit_1_12  order_active_ub_1159  -8
    visit_1_12  service_visit_def_1160  -1
    order_1_12  connected_order_arc_1022  1
    order_1_12  connected_order_arc_1037  1
    order_1_12  connected_order_arc_1052  1
    order_1_12  connected_order_arc_1063  -1
    order_1_12  connected_order_arc_1065  -1
    order_1_12  connected_order_arc_1067  -1
    order_1_12  connected_order_arc_1069  -1
    order_1_12  connected_order_arc_1071  -1
    order_1_12  connected_order_arc_1073  -1
    order_1_12  connected_order_arc_1075  -1
    order_1_12  connected_order_arc_1084  1
    order_1_12  connected_order_arc_1099  1
    order_1_12  connected_order_arc_1114  1
    order_1_12  connected_order_arc_1129  1
    order_1_12  order_active_lb_1158  1
    order_1_12  order_active_ub_1159  1
    visit_1_13  out_degree_1162  -1
    visit_1_13  in_degree_1163  -1
    visit_1_13  order_active_lb_1164  -1
    visit_1_13  order_active_ub_1165  -8
    visit_1_13  service_visit_def_1166  -1
    order_1_13  connected_order_arc_1024  1
    order_1_13  connected_order_arc_1039  1
    order_1_13  connected_order_arc_1054  1
    order_1_13  connected_order_arc_1069  1
    order_1_13  connected_order_arc_1078  -1
    order_1_13  connected_order_arc_1080  -1
    order_1_13  connected_order_arc_1082  -1
    order_1_13  connected_order_arc_1084  -1
    order_1_13  connected_order_arc_1086  -1
    order_1_13  connected_order_arc_1088  -1
    order_1_13  connected_order_arc_1090  -1
    order_1_13  connected_order_arc_1101  1
    order_1_13  connected_order_arc_1116  1
    order_1_13  connected_order_arc_1131  1
    order_1_13  order_active_lb_1164  1
    order_1_13  order_active_ub_1165  1
    visit_1_14  out_degree_1168  -1
    visit_1_14  in_degree_1169  -1
    visit_1_14  order_active_lb_1170  -1
    visit_1_14  order_active_ub_1171  -8
    visit_1_14  service_visit_def_1172  -1
    order_1_14  connected_order_arc_1026  1
    order_1_14  connected_order_arc_1041  1
    order_1_14  connected_order_arc_1056  1
    order_1_14  connected_order_arc_1071  1
    order_1_14  connected_order_arc_1086  1
    order_1_14  connected_order_arc_1093  -1
    order_1_14  connected_order_arc_1095  -1
    order_1_14  connected_order_arc_1097  -1
    order_1_14  connected_order_arc_1099  -1
    order_1_14  connected_order_arc_1101  -1
    order_1_14  connected_order_arc_1103  -1
    order_1_14  connected_order_arc_1105  -1
    order_1_14  connected_order_arc_1118  1
    order_1_14  connected_order_arc_1133  1
    order_1_14  order_active_lb_1170  1
    order_1_14  order_active_ub_1171  1
    visit_1_15  out_degree_1174  -1
    visit_1_15  in_degree_1175  -1
    visit_1_15  order_active_lb_1176  -1
    visit_1_15  order_active_ub_1177  -8
    visit_1_15  service_visit_def_1178  -1
    order_1_15  connected_order_arc_1028  1
    order_1_15  connected_order_arc_1043  1
    order_1_15  connected_order_arc_1058  1
    order_1_15  connected_order_arc_1073  1
    order_1_15  connected_order_arc_1088  1
    order_1_15  connected_order_arc_1103  1
    order_1_15  connected_order_arc_1108  -1
    order_1_15  connected_order_arc_1110  -1
    order_1_15  connected_order_arc_1112  -1
    order_1_15  connected_order_arc_1114  -1
    order_1_15  connected_order_arc_1116  -1
    order_1_15  connected_order_arc_1118  -1
    order_1_15  connected_order_arc_1120  -1
    order_1_15  connected_order_arc_1135  1
    order_1_15  order_active_lb_1176  1
    order_1_15  order_active_ub_1177  1
    visit_1_16  out_degree_1180  -1
    visit_1_16  in_degree_1181  -1
    visit_1_16  order_active_lb_1182  -1
    visit_1_16  order_active_ub_1183  -8
    visit_1_16  service_visit_def_1184  -1
    order_1_16  connected_order_arc_1030  1
    order_1_16  connected_order_arc_1045  1
    order_1_16  connected_order_arc_1060  1
    order_1_16  connected_order_arc_1075  1
    order_1_16  connected_order_arc_1090  1
    order_1_16  connected_order_arc_1105  1
    order_1_16  connected_order_arc_1120  1
    order_1_16  connected_order_arc_1123  -1
    order_1_16  connected_order_arc_1125  -1
    order_1_16  connected_order_arc_1127  -1
    order_1_16  connected_order_arc_1129  -1
    order_1_16  connected_order_arc_1131  -1
    order_1_16  connected_order_arc_1133  -1
    order_1_16  connected_order_arc_1135  -1
    order_1_16  order_active_lb_1182  1
    order_1_16  order_active_ub_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_1007  -30
    arc_1_0_0  depot_departure_or_bypass_1136  1
    arc_1_0_0  depot_return_or_bypass_1137  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_1007  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_1008  -30
    arc_1_0_9  depot_departure_or_bypass_1136  1
    arc_1_0_9  in_degree_1139  1
    arc_1_0_9  original_T_including_depot_unload_1186  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_1008  1
    load_1_0_9  free_load_conservation_1143  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_1009  -30
    arc_1_0_10  depot_departure_or_bypass_1136  1
    arc_1_0_10  in_degree_1145  1
    arc_1_0_10  original_T_including_depot_unload_1186  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_1009  1
    load_1_0_10  free_load_conservation_1149  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_1010  -30
    arc_1_0_11  depot_departure_or_bypass_1136  1
    arc_1_0_11  in_degree_1151  1
    arc_1_0_11  original_T_including_depot_unload_1186  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_1010  1
    load_1_0_11  free_load_conservation_1155  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_1011  -30
    arc_1_0_12  depot_departure_or_bypass_1136  1
    arc_1_0_12  in_degree_1157  1
    arc_1_0_12  original_T_including_depot_unload_1186  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_1011  1
    load_1_0_12  free_load_conservation_1161  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_1012  -30
    arc_1_0_13  depot_departure_or_bypass_1136  1
    arc_1_0_13  in_degree_1163  1
    arc_1_0_13  original_T_including_depot_unload_1186  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_1012  1
    load_1_0_13  free_load_conservation_1167  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_1013  -30
    arc_1_0_14  depot_departure_or_bypass_1136  1
    arc_1_0_14  in_degree_1169  1
    arc_1_0_14  original_T_including_depot_unload_1186  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_1013  1
    load_1_0_14  free_load_conservation_1173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_1014  -30
    arc_1_0_15  depot_departure_or_bypass_1136  1
    arc_1_0_15  in_degree_1175  1
    arc_1_0_15  original_T_including_depot_unload_1186  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_1014  1
    load_1_0_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_1015  -30
    arc_1_0_16  depot_departure_or_bypass_1136  1
    arc_1_0_16  in_degree_1181  1
    arc_1_0_16  original_T_including_depot_unload_1186  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_1015  1
    load_1_0_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_1016  -30
    arc_1_9_0  depot_return_or_bypass_1137  1
    arc_1_9_0  out_degree_1138  1
    arc_1_9_0  original_T_including_depot_unload_1186  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_1016  1
    load_1_9_0  free_load_conservation_1143  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_1017  -30
    arc_1_9_10  connected_order_arc_1018  -9
    arc_1_9_10  out_degree_1138  1
    arc_1_9_10  in_degree_1145  1
    arc_1_9_10  original_T_including_depot_unload_1186  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_1017  1
    load_1_9_10  free_load_conservation_1143  1
    load_1_9_10  free_load_conservation_1149  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_1019  -30
    arc_1_9_11  connected_order_arc_1020  -9
    arc_1_9_11  out_degree_1138  1
    arc_1_9_11  in_degree_1151  1
    arc_1_9_11  original_T_including_depot_unload_1186  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_1019  1
    load_1_9_11  free_load_conservation_1143  1
    load_1_9_11  free_load_conservation_1155  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_1021  -30
    arc_1_9_12  connected_order_arc_1022  -9
    arc_1_9_12  out_degree_1138  1
    arc_1_9_12  in_degree_1157  1
    arc_1_9_12  original_T_including_depot_unload_1186  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_1021  1
    load_1_9_12  free_load_conservation_1143  1
    load_1_9_12  free_load_conservation_1161  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_1023  -30
    arc_1_9_13  connected_order_arc_1024  -9
    arc_1_9_13  out_degree_1138  1
    arc_1_9_13  in_degree_1163  1
    arc_1_9_13  original_T_including_depot_unload_1186  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_1023  1
    load_1_9_13  free_load_conservation_1143  1
    load_1_9_13  free_load_conservation_1167  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_1025  -30
    arc_1_9_14  connected_order_arc_1026  -9
    arc_1_9_14  out_degree_1138  1
    arc_1_9_14  in_degree_1169  1
    arc_1_9_14  original_T_including_depot_unload_1186  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_1025  1
    load_1_9_14  free_load_conservation_1143  1
    load_1_9_14  free_load_conservation_1173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_1027  -30
    arc_1_9_15  connected_order_arc_1028  -9
    arc_1_9_15  out_degree_1138  1
    arc_1_9_15  in_degree_1175  1
    arc_1_9_15  original_T_including_depot_unload_1186  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_1027  1
    load_1_9_15  free_load_conservation_1143  1
    load_1_9_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_1029  -30
    arc_1_9_16  connected_order_arc_1030  -9
    arc_1_9_16  out_degree_1138  1
    arc_1_9_16  in_degree_1181  1
    arc_1_9_16  original_T_including_depot_unload_1186  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_1029  1
    load_1_9_16  free_load_conservation_1143  1
    load_1_9_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1031  -30
    arc_1_10_0  depot_return_or_bypass_1137  1
    arc_1_10_0  out_degree_1144  1
    arc_1_10_0  original_T_including_depot_unload_1186  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1031  1
    load_1_10_0  free_load_conservation_1149  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1032  -30
    arc_1_10_9  connected_order_arc_1033  -9
    arc_1_10_9  in_degree_1139  1
    arc_1_10_9  out_degree_1144  1
    arc_1_10_9  original_T_including_depot_unload_1186  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1032  1
    load_1_10_9  free_load_conservation_1143  -1
    load_1_10_9  free_load_conservation_1149  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_1034  -30
    arc_1_10_11  connected_order_arc_1035  -9
    arc_1_10_11  out_degree_1144  1
    arc_1_10_11  in_degree_1151  1
    arc_1_10_11  original_T_including_depot_unload_1186  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_1034  1
    load_1_10_11  free_load_conservation_1149  1
    load_1_10_11  free_load_conservation_1155  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_1036  -30
    arc_1_10_12  connected_order_arc_1037  -9
    arc_1_10_12  out_degree_1144  1
    arc_1_10_12  in_degree_1157  1
    arc_1_10_12  original_T_including_depot_unload_1186  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_1036  1
    load_1_10_12  free_load_conservation_1149  1
    load_1_10_12  free_load_conservation_1161  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_1038  -30
    arc_1_10_13  connected_order_arc_1039  -9
    arc_1_10_13  out_degree_1144  1
    arc_1_10_13  in_degree_1163  1
    arc_1_10_13  original_T_including_depot_unload_1186  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_1038  1
    load_1_10_13  free_load_conservation_1149  1
    load_1_10_13  free_load_conservation_1167  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_1040  -30
    arc_1_10_14  connected_order_arc_1041  -9
    arc_1_10_14  out_degree_1144  1
    arc_1_10_14  in_degree_1169  1
    arc_1_10_14  original_T_including_depot_unload_1186  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_1040  1
    load_1_10_14  free_load_conservation_1149  1
    load_1_10_14  free_load_conservation_1173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1042  -30
    arc_1_10_15  connected_order_arc_1043  -9
    arc_1_10_15  out_degree_1144  1
    arc_1_10_15  in_degree_1175  1
    arc_1_10_15  original_T_including_depot_unload_1186  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1042  1
    load_1_10_15  free_load_conservation_1149  1
    load_1_10_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1044  -30
    arc_1_10_16  connected_order_arc_1045  -9
    arc_1_10_16  out_degree_1144  1
    arc_1_10_16  in_degree_1181  1
    arc_1_10_16  original_T_including_depot_unload_1186  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1044  1
    load_1_10_16  free_load_conservation_1149  1
    load_1_10_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_1046  -30
    arc_1_11_0  depot_return_or_bypass_1137  1
    arc_1_11_0  out_degree_1150  1
    arc_1_11_0  original_T_including_depot_unload_1186  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_1046  1
    load_1_11_0  free_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_1047  -30
    arc_1_11_9  connected_order_arc_1048  -9
    arc_1_11_9  in_degree_1139  1
    arc_1_11_9  out_degree_1150  1
    arc_1_11_9  original_T_including_depot_unload_1186  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_1047  1
    load_1_11_9  free_load_conservation_1143  -1
    load_1_11_9  free_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_1049  -30
    arc_1_11_10  connected_order_arc_1050  -9
    arc_1_11_10  in_degree_1145  1
    arc_1_11_10  out_degree_1150  1
    arc_1_11_10  original_T_including_depot_unload_1186  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_1049  1
    load_1_11_10  free_load_conservation_1149  -1
    load_1_11_10  free_load_conservation_1155  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_1051  -30
    arc_1_11_12  connected_order_arc_1052  -9
    arc_1_11_12  out_degree_1150  1
    arc_1_11_12  in_degree_1157  1
    arc_1_11_12  original_T_including_depot_unload_1186  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_1051  1
    load_1_11_12  free_load_conservation_1155  1
    load_1_11_12  free_load_conservation_1161  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_1053  -30
    arc_1_11_13  connected_order_arc_1054  -9
    arc_1_11_13  out_degree_1150  1
    arc_1_11_13  in_degree_1163  1
    arc_1_11_13  original_T_including_depot_unload_1186  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_1053  1
    load_1_11_13  free_load_conservation_1155  1
    load_1_11_13  free_load_conservation_1167  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_1055  -30
    arc_1_11_14  connected_order_arc_1056  -9
    arc_1_11_14  out_degree_1150  1
    arc_1_11_14  in_degree_1169  1
    arc_1_11_14  original_T_including_depot_unload_1186  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_1055  1
    load_1_11_14  free_load_conservation_1155  1
    load_1_11_14  free_load_conservation_1173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_1057  -30
    arc_1_11_15  connected_order_arc_1058  -9
    arc_1_11_15  out_degree_1150  1
    arc_1_11_15  in_degree_1175  1
    arc_1_11_15  original_T_including_depot_unload_1186  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_1057  1
    load_1_11_15  free_load_conservation_1155  1
    load_1_11_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_16  arc_capacity_1059  -30
    arc_1_11_16  connected_order_arc_1060  -9
    arc_1_11_16  out_degree_1150  1
    arc_1_11_16  in_degree_1181  1
    arc_1_11_16  original_T_including_depot_unload_1186  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_16  arc_capacity_1059  1
    load_1_11_16  free_load_conservation_1155  1
    load_1_11_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_1061  -30
    arc_1_12_0  depot_return_or_bypass_1137  1
    arc_1_12_0  out_degree_1156  1
    arc_1_12_0  original_T_including_depot_unload_1186  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_1061  1
    load_1_12_0  free_load_conservation_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_1062  -30
    arc_1_12_9  connected_order_arc_1063  -9
    arc_1_12_9  in_degree_1139  1
    arc_1_12_9  out_degree_1156  1
    arc_1_12_9  original_T_including_depot_unload_1186  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_1062  1
    load_1_12_9  free_load_conservation_1143  -1
    load_1_12_9  free_load_conservation_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_1064  -30
    arc_1_12_10  connected_order_arc_1065  -9
    arc_1_12_10  in_degree_1145  1
    arc_1_12_10  out_degree_1156  1
    arc_1_12_10  original_T_including_depot_unload_1186  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_1064  1
    load_1_12_10  free_load_conservation_1149  -1
    load_1_12_10  free_load_conservation_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_1066  -30
    arc_1_12_11  connected_order_arc_1067  -9
    arc_1_12_11  in_degree_1151  1
    arc_1_12_11  out_degree_1156  1
    arc_1_12_11  original_T_including_depot_unload_1186  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_1066  1
    load_1_12_11  free_load_conservation_1155  -1
    load_1_12_11  free_load_conservation_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_1068  -30
    arc_1_12_13  connected_order_arc_1069  -9
    arc_1_12_13  out_degree_1156  1
    arc_1_12_13  in_degree_1163  1
    arc_1_12_13  original_T_including_depot_unload_1186  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_1068  1
    load_1_12_13  free_load_conservation_1161  1
    load_1_12_13  free_load_conservation_1167  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_1070  -30
    arc_1_12_14  connected_order_arc_1071  -9
    arc_1_12_14  out_degree_1156  1
    arc_1_12_14  in_degree_1169  1
    arc_1_12_14  original_T_including_depot_unload_1186  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_1070  1
    load_1_12_14  free_load_conservation_1161  1
    load_1_12_14  free_load_conservation_1173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_1072  -30
    arc_1_12_15  connected_order_arc_1073  -9
    arc_1_12_15  out_degree_1156  1
    arc_1_12_15  in_degree_1175  1
    arc_1_12_15  original_T_including_depot_unload_1186  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_1072  1
    load_1_12_15  free_load_conservation_1161  1
    load_1_12_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_1074  -30
    arc_1_12_16  connected_order_arc_1075  -9
    arc_1_12_16  out_degree_1156  1
    arc_1_12_16  in_degree_1181  1
    arc_1_12_16  original_T_including_depot_unload_1186  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_1074  1
    load_1_12_16  free_load_conservation_1161  1
    load_1_12_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_1076  -30
    arc_1_13_0  depot_return_or_bypass_1137  1
    arc_1_13_0  out_degree_1162  1
    arc_1_13_0  original_T_including_depot_unload_1186  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_1076  1
    load_1_13_0  free_load_conservation_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_1077  -30
    arc_1_13_9  connected_order_arc_1078  -9
    arc_1_13_9  in_degree_1139  1
    arc_1_13_9  out_degree_1162  1
    arc_1_13_9  original_T_including_depot_unload_1186  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_1077  1
    load_1_13_9  free_load_conservation_1143  -1
    load_1_13_9  free_load_conservation_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_1079  -30
    arc_1_13_10  connected_order_arc_1080  -9
    arc_1_13_10  in_degree_1145  1
    arc_1_13_10  out_degree_1162  1
    arc_1_13_10  original_T_including_depot_unload_1186  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_1079  1
    load_1_13_10  free_load_conservation_1149  -1
    load_1_13_10  free_load_conservation_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_1081  -30
    arc_1_13_11  connected_order_arc_1082  -9
    arc_1_13_11  in_degree_1151  1
    arc_1_13_11  out_degree_1162  1
    arc_1_13_11  original_T_including_depot_unload_1186  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_1081  1
    load_1_13_11  free_load_conservation_1155  -1
    load_1_13_11  free_load_conservation_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_1083  -30
    arc_1_13_12  connected_order_arc_1084  -9
    arc_1_13_12  in_degree_1157  1
    arc_1_13_12  out_degree_1162  1
    arc_1_13_12  original_T_including_depot_unload_1186  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_1083  1
    load_1_13_12  free_load_conservation_1161  -1
    load_1_13_12  free_load_conservation_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_1085  -30
    arc_1_13_14  connected_order_arc_1086  -9
    arc_1_13_14  out_degree_1162  1
    arc_1_13_14  in_degree_1169  1
    arc_1_13_14  original_T_including_depot_unload_1186  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_1085  1
    load_1_13_14  free_load_conservation_1167  1
    load_1_13_14  free_load_conservation_1173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_1087  -30
    arc_1_13_15  connected_order_arc_1088  -9
    arc_1_13_15  out_degree_1162  1
    arc_1_13_15  in_degree_1175  1
    arc_1_13_15  original_T_including_depot_unload_1186  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_1087  1
    load_1_13_15  free_load_conservation_1167  1
    load_1_13_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_1089  -30
    arc_1_13_16  connected_order_arc_1090  -9
    arc_1_13_16  out_degree_1162  1
    arc_1_13_16  in_degree_1181  1
    arc_1_13_16  original_T_including_depot_unload_1186  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_1089  1
    load_1_13_16  free_load_conservation_1167  1
    load_1_13_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1091  -30
    arc_1_14_0  depot_return_or_bypass_1137  1
    arc_1_14_0  out_degree_1168  1
    arc_1_14_0  original_T_including_depot_unload_1186  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1091  1
    load_1_14_0  free_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1092  -30
    arc_1_14_9  connected_order_arc_1093  -9
    arc_1_14_9  in_degree_1139  1
    arc_1_14_9  out_degree_1168  1
    arc_1_14_9  original_T_including_depot_unload_1186  1.4443513852547251e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1092  1
    load_1_14_9  free_load_conservation_1143  -1
    load_1_14_9  free_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1094  -30
    arc_1_14_10  connected_order_arc_1095  -9
    arc_1_14_10  in_degree_1145  1
    arc_1_14_10  out_degree_1168  1
    arc_1_14_10  original_T_including_depot_unload_1186  1.5255932363401953e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1094  1
    load_1_14_10  free_load_conservation_1149  -1
    load_1_14_10  free_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_1096  -30
    arc_1_14_11  connected_order_arc_1097  -9
    arc_1_14_11  in_degree_1151  1
    arc_1_14_11  out_degree_1168  1
    arc_1_14_11  original_T_including_depot_unload_1186  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_1096  1
    load_1_14_11  free_load_conservation_1155  -1
    load_1_14_11  free_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_1098  -30
    arc_1_14_12  connected_order_arc_1099  -9
    arc_1_14_12  in_degree_1157  1
    arc_1_14_12  out_degree_1168  1
    arc_1_14_12  original_T_including_depot_unload_1186  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_1098  1
    load_1_14_12  free_load_conservation_1161  -1
    load_1_14_12  free_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1100  -30
    arc_1_14_13  connected_order_arc_1101  -9
    arc_1_14_13  in_degree_1163  1
    arc_1_14_13  out_degree_1168  1
    arc_1_14_13  original_T_including_depot_unload_1186  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1100  1
    load_1_14_13  free_load_conservation_1167  -1
    load_1_14_13  free_load_conservation_1173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1102  -30
    arc_1_14_15  connected_order_arc_1103  -9
    arc_1_14_15  out_degree_1168  1
    arc_1_14_15  in_degree_1175  1
    arc_1_14_15  original_T_including_depot_unload_1186  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1102  1
    load_1_14_15  free_load_conservation_1173  1
    load_1_14_15  free_load_conservation_1179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1104  -30
    arc_1_14_16  connected_order_arc_1105  -9
    arc_1_14_16  out_degree_1168  1
    arc_1_14_16  in_degree_1181  1
    arc_1_14_16  original_T_including_depot_unload_1186  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1104  1
    load_1_14_16  free_load_conservation_1173  1
    load_1_14_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1106  -30
    arc_1_15_0  depot_return_or_bypass_1137  1
    arc_1_15_0  out_degree_1174  1
    arc_1_15_0  original_T_including_depot_unload_1186  2.0232971184291544e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1106  1
    load_1_15_0  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1107  -30
    arc_1_15_9  connected_order_arc_1108  -9
    arc_1_15_9  in_degree_1139  1
    arc_1_15_9  out_degree_1174  1
    arc_1_15_9  original_T_including_depot_unload_1186  1.8934642770867222e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1107  1
    load_1_15_9  free_load_conservation_1143  -1
    load_1_15_9  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1109  -30
    arc_1_15_10  connected_order_arc_1110  -9
    arc_1_15_10  in_degree_1145  1
    arc_1_15_10  out_degree_1174  1
    arc_1_15_10  original_T_including_depot_unload_1186  2.0239755898835604e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1109  1
    load_1_15_10  free_load_conservation_1149  -1
    load_1_15_10  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1111  -30
    arc_1_15_11  connected_order_arc_1112  -9
    arc_1_15_11  in_degree_1151  1
    arc_1_15_11  out_degree_1174  1
    arc_1_15_11  original_T_including_depot_unload_1186  2.5683172431027456e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1111  1
    load_1_15_11  free_load_conservation_1155  -1
    load_1_15_11  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1113  -30
    arc_1_15_12  connected_order_arc_1114  -9
    arc_1_15_12  in_degree_1157  1
    arc_1_15_12  out_degree_1174  1
    arc_1_15_12  original_T_including_depot_unload_1186  2.0819438297758261e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1113  1
    load_1_15_12  free_load_conservation_1161  -1
    load_1_15_12  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1115  -30
    arc_1_15_13  connected_order_arc_1116  -9
    arc_1_15_13  in_degree_1163  1
    arc_1_15_13  out_degree_1174  1
    arc_1_15_13  original_T_including_depot_unload_1186  2.3561201725625019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1115  1
    load_1_15_13  free_load_conservation_1167  -1
    load_1_15_13  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1117  -30
    arc_1_15_14  connected_order_arc_1118  -9
    arc_1_15_14  in_degree_1169  1
    arc_1_15_14  out_degree_1174  1
    arc_1_15_14  original_T_including_depot_unload_1186  1.7165475198920165e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1117  1
    load_1_15_14  free_load_conservation_1173  -1
    load_1_15_14  free_load_conservation_1179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1119  -30
    arc_1_15_16  connected_order_arc_1120  -9
    arc_1_15_16  out_degree_1174  1
    arc_1_15_16  in_degree_1181  1
    arc_1_15_16  original_T_including_depot_unload_1186  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1119  1
    load_1_15_16  free_load_conservation_1179  1
    load_1_15_16  free_load_conservation_1185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1121  -30
    arc_1_16_0  depot_return_or_bypass_1137  1
    arc_1_16_0  out_degree_1180  1
    arc_1_16_0  original_T_including_depot_unload_1186  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1121  1
    load_1_16_0  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1122  -30
    arc_1_16_9  connected_order_arc_1123  -9
    arc_1_16_9  in_degree_1139  1
    arc_1_16_9  out_degree_1180  1
    arc_1_16_9  original_T_including_depot_unload_1186  1.7037372759708057e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1122  1
    load_1_16_9  free_load_conservation_1143  -1
    load_1_16_9  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1124  -30
    arc_1_16_10  connected_order_arc_1125  -9
    arc_1_16_10  in_degree_1145  1
    arc_1_16_10  out_degree_1180  1
    arc_1_16_10  original_T_including_depot_unload_1186  1.7340603255343296e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1124  1
    load_1_16_10  free_load_conservation_1149  -1
    load_1_16_10  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_11  arc_capacity_1126  -30
    arc_1_16_11  connected_order_arc_1127  -9
    arc_1_16_11  in_degree_1151  1
    arc_1_16_11  out_degree_1180  1
    arc_1_16_11  original_T_including_depot_unload_1186  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_11  arc_capacity_1126  1
    load_1_16_11  free_load_conservation_1155  -1
    load_1_16_11  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_1128  -30
    arc_1_16_12  connected_order_arc_1129  -9
    arc_1_16_12  in_degree_1157  1
    arc_1_16_12  out_degree_1180  1
    arc_1_16_12  original_T_including_depot_unload_1186  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_1128  1
    load_1_16_12  free_load_conservation_1161  -1
    load_1_16_12  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1130  -30
    arc_1_16_13  connected_order_arc_1131  -9
    arc_1_16_13  in_degree_1163  1
    arc_1_16_13  out_degree_1180  1
    arc_1_16_13  original_T_including_depot_unload_1186  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1130  1
    load_1_16_13  free_load_conservation_1167  -1
    load_1_16_13  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1132  -30
    arc_1_16_14  connected_order_arc_1133  -9
    arc_1_16_14  in_degree_1169  1
    arc_1_16_14  out_degree_1180  1
    arc_1_16_14  original_T_including_depot_unload_1186  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1132  1
    load_1_16_14  free_load_conservation_1173  -1
    load_1_16_14  free_load_conservation_1185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1134  -30
    arc_1_16_15  connected_order_arc_1135  -9
    arc_1_16_15  in_degree_1175  1
    arc_1_16_15  out_degree_1180  1
    arc_1_16_15  original_T_including_depot_unload_1186  2.4370949895474209e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1134  1
    load_1_16_15  free_load_conservation_1179  -1
    load_1_16_15  free_load_conservation_1185  1
RHS
    RHS1      OBJ       -4.0985916180959242e-01
    RHS1      onehot_13_4  1
    RHS1      onehot_14_39  1
    RHS1      onehot_18_74  1
    RHS1      onehot_17_111  1
    RHS1      onehot_11_146  1
    RHS1      onehot_12_181  1
    RHS1      onehot_20_216  1
    RHS1      onehot_10_223  1
    RHS1      stock_ub_227  36
    RHS1      parent_nonstrict_scope_228  5.9185976588580869e-01
    RHS1      normalization_285  1
    RHS1      connected_order_arc_399  -16
    RHS1      connected_order_arc_401  -16
    RHS1      connected_order_arc_403  -16
    RHS1      connected_order_arc_405  -16
    RHS1      connected_order_arc_407  -16
    RHS1      connected_order_arc_409  -16
    RHS1      connected_order_arc_411  -16
    RHS1      connected_order_arc_413  -16
    RHS1      connected_order_arc_415  -16
    RHS1      connected_order_arc_417  -16
    RHS1      connected_order_arc_419  -16
    RHS1      connected_order_arc_421  -16
    RHS1      connected_order_arc_423  -16
    RHS1      connected_order_arc_425  -16
    RHS1      connected_order_arc_427  -16
    RHS1      connected_order_arc_430  -16
    RHS1      connected_order_arc_432  -16
    RHS1      connected_order_arc_434  -16
    RHS1      connected_order_arc_436  -16
    RHS1      connected_order_arc_438  -16
    RHS1      connected_order_arc_440  -16
    RHS1      connected_order_arc_442  -16
    RHS1      connected_order_arc_444  -16
    RHS1      connected_order_arc_446  -16
    RHS1      connected_order_arc_448  -16
    RHS1      connected_order_arc_450  -16
    RHS1      connected_order_arc_452  -16
    RHS1      connected_order_arc_454  -16
    RHS1      connected_order_arc_456  -16
    RHS1      connected_order_arc_458  -16
    RHS1      connected_order_arc_461  -16
    RHS1      connected_order_arc_463  -16
    RHS1      connected_order_arc_465  -16
    RHS1      connected_order_arc_467  -16
    RHS1      connected_order_arc_469  -16
    RHS1      connected_order_arc_471  -16
    RHS1      connected_order_arc_473  -16
    RHS1      connected_order_arc_475  -16
    RHS1      connected_order_arc_477  -16
    RHS1      connected_order_arc_479  -16
    RHS1      connected_order_arc_481  -16
    RHS1      connected_order_arc_483  -16
    RHS1      connected_order_arc_485  -16
    RHS1      connected_order_arc_487  -16
    RHS1      connected_order_arc_489  -16
    RHS1      connected_order_arc_492  -16
    RHS1      connected_order_arc_494  -16
    RHS1      connected_order_arc_496  -16
    RHS1      connected_order_arc_498  -16
    RHS1      connected_order_arc_500  -16
    RHS1      connected_order_arc_502  -16
    RHS1      connected_order_arc_504  -16
    RHS1      connected_order_arc_506  -16
    RHS1      connected_order_arc_508  -16
    RHS1      connected_order_arc_510  -16
    RHS1      connected_order_arc_512  -16
    RHS1      connected_order_arc_514  -16
    RHS1      connected_order_arc_516  -16
    RHS1      connected_order_arc_518  -16
    RHS1      connected_order_arc_520  -16
    RHS1      connected_order_arc_523  -16
    RHS1      connected_order_arc_525  -16
    RHS1      connected_order_arc_527  -16
    RHS1      connected_order_arc_529  -16
    RHS1      connected_order_arc_531  -16
    RHS1      connected_order_arc_533  -16
    RHS1      connected_order_arc_535  -16
    RHS1      connected_order_arc_537  -16
    RHS1      connected_order_arc_539  -16
    RHS1      connected_order_arc_541  -16
    RHS1      connected_order_arc_543  -16
    RHS1      connected_order_arc_545  -16
    RHS1      connected_order_arc_547  -16
    RHS1      connected_order_arc_549  -16
    RHS1      connected_order_arc_551  -16
    RHS1      connected_order_arc_554  -16
    RHS1      connected_order_arc_556  -16
    RHS1      connected_order_arc_558  -16
    RHS1      connected_order_arc_560  -16
    RHS1      connected_order_arc_562  -16
    RHS1      connected_order_arc_564  -16
    RHS1      connected_order_arc_566  -16
    RHS1      connected_order_arc_568  -16
    RHS1      connected_order_arc_570  -16
    RHS1      connected_order_arc_572  -16
    RHS1      connected_order_arc_574  -16
    RHS1      connected_order_arc_576  -16
    RHS1      connected_order_arc_578  -16
    RHS1      connected_order_arc_580  -16
    RHS1      connected_order_arc_582  -16
    RHS1      connected_order_arc_585  -16
    RHS1      connected_order_arc_587  -16
    RHS1      connected_order_arc_589  -16
    RHS1      connected_order_arc_591  -16
    RHS1      connected_order_arc_593  -16
    RHS1      connected_order_arc_595  -16
    RHS1      connected_order_arc_597  -16
    RHS1      connected_order_arc_599  -16
    RHS1      connected_order_arc_601  -16
    RHS1      connected_order_arc_603  -16
    RHS1      connected_order_arc_605  -16
    RHS1      connected_order_arc_607  -16
    RHS1      connected_order_arc_609  -16
    RHS1      connected_order_arc_611  -16
    RHS1      connected_order_arc_613  -16
    RHS1      connected_order_arc_616  -16
    RHS1      connected_order_arc_618  -16
    RHS1      connected_order_arc_620  -16
    RHS1      connected_order_arc_622  -16
    RHS1      connected_order_arc_624  -16
    RHS1      connected_order_arc_626  -16
    RHS1      connected_order_arc_628  -16
    RHS1      connected_order_arc_630  -16
    RHS1      connected_order_arc_632  -16
    RHS1      connected_order_arc_634  -16
    RHS1      connected_order_arc_636  -16
    RHS1      connected_order_arc_638  -16
    RHS1      connected_order_arc_640  -16
    RHS1      connected_order_arc_642  -16
    RHS1      connected_order_arc_644  -16
    RHS1      connected_order_arc_647  -16
    RHS1      connected_order_arc_649  -16
    RHS1      connected_order_arc_651  -16
    RHS1      connected_order_arc_653  -16
    RHS1      connected_order_arc_655  -16
    RHS1      connected_order_arc_657  -16
    RHS1      connected_order_arc_659  -16
    RHS1      connected_order_arc_661  -16
    RHS1      connected_order_arc_663  -16
    RHS1      connected_order_arc_665  -16
    RHS1      connected_order_arc_667  -16
    RHS1      connected_order_arc_669  -16
    RHS1      connected_order_arc_671  -16
    RHS1      connected_order_arc_673  -16
    RHS1      connected_order_arc_675  -16
    RHS1      connected_order_arc_678  -16
    RHS1      connected_order_arc_680  -16
    RHS1      connected_order_arc_682  -16
    RHS1      connected_order_arc_684  -16
    RHS1      connected_order_arc_686  -16
    RHS1      connected_order_arc_688  -16
    RHS1      connected_order_arc_690  -16
    RHS1      connected_order_arc_692  -16
    RHS1      connected_order_arc_694  -16
    RHS1      connected_order_arc_696  -16
    RHS1      connected_order_arc_698  -16
    RHS1      connected_order_arc_700  -16
    RHS1      connected_order_arc_702  -16
    RHS1      connected_order_arc_704  -16
    RHS1      connected_order_arc_706  -16
    RHS1      connected_order_arc_709  -16
    RHS1      connected_order_arc_711  -16
    RHS1      connected_order_arc_713  -16
    RHS1      connected_order_arc_715  -16
    RHS1      connected_order_arc_717  -16
    RHS1      connected_order_arc_719  -16
    RHS1      connected_order_arc_721  -16
    RHS1      connected_order_arc_723  -16
    RHS1      connected_order_arc_725  -16
    RHS1      connected_order_arc_727  -16
    RHS1      connected_order_arc_729  -16
    RHS1      connected_order_arc_731  -16
    RHS1      connected_order_arc_733  -16
    RHS1      connected_order_arc_735  -16
    RHS1      connected_order_arc_737  -16
    RHS1      connected_order_arc_740  -16
    RHS1      connected_order_arc_742  -16
    RHS1      connected_order_arc_744  -16
    RHS1      connected_order_arc_746  -16
    RHS1      connected_order_arc_748  -16
    RHS1      connected_order_arc_750  -16
    RHS1      connected_order_arc_752  -16
    RHS1      connected_order_arc_754  -16
    RHS1      connected_order_arc_756  -16
    RHS1      connected_order_arc_758  -16
    RHS1      connected_order_arc_760  -16
    RHS1      connected_order_arc_762  -16
    RHS1      connected_order_arc_764  -16
    RHS1      connected_order_arc_766  -16
    RHS1      connected_order_arc_768  -16
    RHS1      connected_order_arc_771  -16
    RHS1      connected_order_arc_773  -16
    RHS1      connected_order_arc_775  -16
    RHS1      connected_order_arc_777  -16
    RHS1      connected_order_arc_779  -16
    RHS1      connected_order_arc_781  -16
    RHS1      connected_order_arc_783  -16
    RHS1      connected_order_arc_785  -16
    RHS1      connected_order_arc_787  -16
    RHS1      connected_order_arc_789  -16
    RHS1      connected_order_arc_791  -16
    RHS1      connected_order_arc_793  -16
    RHS1      connected_order_arc_795  -16
    RHS1      connected_order_arc_797  -16
    RHS1      connected_order_arc_799  -16
    RHS1      connected_order_arc_802  -16
    RHS1      connected_order_arc_804  -16
    RHS1      connected_order_arc_806  -16
    RHS1      connected_order_arc_808  -16
    RHS1      connected_order_arc_810  -16
    RHS1      connected_order_arc_812  -16
    RHS1      connected_order_arc_814  -16
    RHS1      connected_order_arc_816  -16
    RHS1      connected_order_arc_818  -16
    RHS1      connected_order_arc_820  -16
    RHS1      connected_order_arc_822  -16
    RHS1      connected_order_arc_824  -16
    RHS1      connected_order_arc_826  -16
    RHS1      connected_order_arc_828  -16
    RHS1      connected_order_arc_830  -16
    RHS1      connected_order_arc_833  -16
    RHS1      connected_order_arc_835  -16
    RHS1      connected_order_arc_837  -16
    RHS1      connected_order_arc_839  -16
    RHS1      connected_order_arc_841  -16
    RHS1      connected_order_arc_843  -16
    RHS1      connected_order_arc_845  -16
    RHS1      connected_order_arc_847  -16
    RHS1      connected_order_arc_849  -16
    RHS1      connected_order_arc_851  -16
    RHS1      connected_order_arc_853  -16
    RHS1      connected_order_arc_855  -16
    RHS1      connected_order_arc_857  -16
    RHS1      connected_order_arc_859  -16
    RHS1      connected_order_arc_861  -16
    RHS1      connected_order_arc_864  -16
    RHS1      connected_order_arc_866  -16
    RHS1      connected_order_arc_868  -16
    RHS1      connected_order_arc_870  -16
    RHS1      connected_order_arc_872  -16
    RHS1      connected_order_arc_874  -16
    RHS1      connected_order_arc_876  -16
    RHS1      connected_order_arc_878  -16
    RHS1      connected_order_arc_880  -16
    RHS1      connected_order_arc_882  -16
    RHS1      connected_order_arc_884  -16
    RHS1      connected_order_arc_886  -16
    RHS1      connected_order_arc_888  -16
    RHS1      connected_order_arc_890  -16
    RHS1      connected_order_arc_892  -16
    RHS1      depot_departure_or_bypass_893  1
    RHS1      depot_return_or_bypass_894  1
    RHS1      segment_load_conservation_899  -1
    RHS1      segment_prefix_lb_900  1
    RHS1      segment_prefix_ub_901  30
    RHS1      segment_load_conservation_906  4
    RHS1      segment_prefix_ub_908  26
    RHS1      segment_load_conservation_913  -2
    RHS1      segment_prefix_lb_914  2
    RHS1      segment_prefix_ub_915  30
    RHS1      segment_load_conservation_920  -1
    RHS1      segment_prefix_lb_921  1
    RHS1      segment_prefix_ub_922  30
    RHS1      segment_load_conservation_927  3
    RHS1      segment_prefix_ub_929  27
    RHS1      segment_load_conservation_934  -1
    RHS1      segment_prefix_lb_935  1
    RHS1      segment_prefix_ub_936  30
    RHS1      segment_load_conservation_941  -3
    RHS1      segment_prefix_lb_942  3
    RHS1      segment_prefix_ub_943  30
    RHS1      segment_load_conservation_948  -1
    RHS1      segment_prefix_lb_949  1
    RHS1      segment_prefix_ub_950  30
    RHS1      fixed_segment_relative_order_999  1
    RHS1      fixed_segment_relative_order_1000  1
    RHS1      fixed_segment_relative_order_1001  1
    RHS1      fixed_segment_relative_order_1002  1
    RHS1      fixed_segment_relative_order_1003  1
    RHS1      fixed_segment_relative_order_1004  1
    RHS1      fixed_segment_relative_order_1005  1
    RHS1      original_T_including_depot_unload_1006  3960
    RHS1      connected_order_arc_1018  -8
    RHS1      connected_order_arc_1020  -8
    RHS1      connected_order_arc_1022  -8
    RHS1      connected_order_arc_1024  -8
    RHS1      connected_order_arc_1026  -8
    RHS1      connected_order_arc_1028  -8
    RHS1      connected_order_arc_1030  -8
    RHS1      connected_order_arc_1033  -8
    RHS1      connected_order_arc_1035  -8
    RHS1      connected_order_arc_1037  -8
    RHS1      connected_order_arc_1039  -8
    RHS1      connected_order_arc_1041  -8
    RHS1      connected_order_arc_1043  -8
    RHS1      connected_order_arc_1045  -8
    RHS1      connected_order_arc_1048  -8
    RHS1      connected_order_arc_1050  -8
    RHS1      connected_order_arc_1052  -8
    RHS1      connected_order_arc_1054  -8
    RHS1      connected_order_arc_1056  -8
    RHS1      connected_order_arc_1058  -8
    RHS1      connected_order_arc_1060  -8
    RHS1      connected_order_arc_1063  -8
    RHS1      connected_order_arc_1065  -8
    RHS1      connected_order_arc_1067  -8
    RHS1      connected_order_arc_1069  -8
    RHS1      connected_order_arc_1071  -8
    RHS1      connected_order_arc_1073  -8
    RHS1      connected_order_arc_1075  -8
    RHS1      connected_order_arc_1078  -8
    RHS1      connected_order_arc_1080  -8
    RHS1      connected_order_arc_1082  -8
    RHS1      connected_order_arc_1084  -8
    RHS1      connected_order_arc_1086  -8
    RHS1      connected_order_arc_1088  -8
    RHS1      connected_order_arc_1090  -8
    RHS1      connected_order_arc_1093  -8
    RHS1      connected_order_arc_1095  -8
    RHS1      connected_order_arc_1097  -8
    RHS1      connected_order_arc_1099  -8
    RHS1      connected_order_arc_1101  -8
    RHS1      connected_order_arc_1103  -8
    RHS1      connected_order_arc_1105  -8
    RHS1      connected_order_arc_1108  -8
    RHS1      connected_order_arc_1110  -8
    RHS1      connected_order_arc_1112  -8
    RHS1      connected_order_arc_1114  -8
    RHS1      connected_order_arc_1116  -8
    RHS1      connected_order_arc_1118  -8
    RHS1      connected_order_arc_1120  -8
    RHS1      connected_order_arc_1123  -8
    RHS1      connected_order_arc_1125  -8
    RHS1      connected_order_arc_1127  -8
    RHS1      connected_order_arc_1129  -8
    RHS1      connected_order_arc_1131  -8
    RHS1      connected_order_arc_1133  -8
    RHS1      connected_order_arc_1135  -8
    RHS1      depot_departure_or_bypass_1136  1
    RHS1      depot_return_or_bypass_1137  1
    RHS1      original_T_including_depot_unload_1186  4800
BOUNDS
 LO BND1      t         4.4823108802715707e-02
 UP BND1      t         1.1970927746912360e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_13_0  
 UP BND1      w_13_0    1.1970927746912360e-01
 BV BND1      x_13_1  
 UP BND1      w_13_1    1.1970927746912360e-01
 UP BND1      rho_13    1
 BV BND1      x_14_0  
 UP BND1      w_14_0    1.1970927746912360e-01
 BV BND1      x_14_1  
 UP BND1      w_14_1    1.1970927746912360e-01
 BV BND1      x_14_2  
 UP BND1      w_14_2    1.1970927746912360e-01
 BV BND1      x_14_3  
 UP BND1      w_14_3    1.1970927746912360e-01
 BV BND1      x_14_4  
 UP BND1      w_14_4    1.1970927746912360e-01
 BV BND1      x_14_5  
 UP BND1      w_14_5    1.1970927746912360e-01
 BV BND1      x_14_6  
 UP BND1      w_14_6    1.1970927746912360e-01
 BV BND1      x_14_7  
 UP BND1      w_14_7    1.1970927746912360e-01
 BV BND1      x_14_8  
 UP BND1      w_14_8    1.1970927746912360e-01
 BV BND1      x_14_9  
 UP BND1      w_14_9    1.1970927746912360e-01
 BV BND1      x_14_10 
 UP BND1      w_14_10   1.1970927746912360e-01
 BV BND1      x_14_11 
 UP BND1      w_14_11   1.1970927746912360e-01
 BV BND1      x_14_12 
 UP BND1      w_14_12   1.1970927746912360e-01
 BV BND1      x_14_13 
 UP BND1      w_14_13   1.1970927746912360e-01
 BV BND1      x_14_14 
 UP BND1      w_14_14   1.1970927746912360e-01
 BV BND1      x_14_15 
 UP BND1      w_14_15   1.1970927746912360e-01
 UP BND1      rho_14    1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.1970927746912360e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.1970927746912360e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.1970927746912360e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.1970927746912360e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.1970927746912360e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.1970927746912360e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.1970927746912360e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.1970927746912360e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.1970927746912360e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.1970927746912360e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.1970927746912360e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.1970927746912360e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.1970927746912360e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.1970927746912360e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.1970927746912360e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.1970927746912360e-01
 UP BND1      rho_18    1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.1970927746912360e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.1970927746912360e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.1970927746912360e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.1970927746912360e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.1970927746912360e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.1970927746912360e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.1970927746912360e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.1970927746912360e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.1970927746912360e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.1970927746912360e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.1970927746912360e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.1970927746912360e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.1970927746912360e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.1970927746912360e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.1970927746912360e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.1970927746912360e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.1970927746912360e-01
 UP BND1      rho_17    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.1970927746912360e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.1970927746912360e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.1970927746912360e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.1970927746912360e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.1970927746912360e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.1970927746912360e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.1970927746912360e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.1970927746912360e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.1970927746912360e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.1970927746912360e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.1970927746912360e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.1970927746912360e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.1970927746912360e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.1970927746912360e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.1970927746912360e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.1970927746912360e-01
 UP BND1      rho_11    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    1.1970927746912360e-01
 BV BND1      x_12_1  
 UP BND1      w_12_1    1.1970927746912360e-01
 BV BND1      x_12_2  
 UP BND1      w_12_2    1.1970927746912360e-01
 BV BND1      x_12_3  
 UP BND1      w_12_3    1.1970927746912360e-01
 BV BND1      x_12_4  
 UP BND1      w_12_4    1.1970927746912360e-01
 BV BND1      x_12_5  
 UP BND1      w_12_5    1.1970927746912360e-01
 BV BND1      x_12_6  
 UP BND1      w_12_6    1.1970927746912360e-01
 BV BND1      x_12_7  
 UP BND1      w_12_7    1.1970927746912360e-01
 BV BND1      x_12_8  
 UP BND1      w_12_8    1.1970927746912360e-01
 BV BND1      x_12_9  
 UP BND1      w_12_9    1.1970927746912360e-01
 BV BND1      x_12_10 
 UP BND1      w_12_10   1.1970927746912360e-01
 BV BND1      x_12_11 
 UP BND1      w_12_11   1.1970927746912360e-01
 BV BND1      x_12_12 
 UP BND1      w_12_12   1.1970927746912360e-01
 BV BND1      x_12_13 
 UP BND1      w_12_13   1.1970927746912360e-01
 BV BND1      x_12_14 
 UP BND1      w_12_14   1.1970927746912360e-01
 BV BND1      x_12_15 
 UP BND1      w_12_15   1.1970927746912360e-01
 UP BND1      rho_12    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    1.1970927746912360e-01
 BV BND1      x_20_1  
 UP BND1      w_20_1    1.1970927746912360e-01
 BV BND1      x_20_2  
 UP BND1      w_20_2    1.1970927746912360e-01
 BV BND1      x_20_3  
 UP BND1      w_20_3    1.1970927746912360e-01
 BV BND1      x_20_4  
 UP BND1      w_20_4    1.1970927746912360e-01
 BV BND1      x_20_5  
 UP BND1      w_20_5    1.1970927746912360e-01
 BV BND1      x_20_6  
 UP BND1      w_20_6    1.1970927746912360e-01
 BV BND1      x_20_7  
 UP BND1      w_20_7    1.1970927746912360e-01
 BV BND1      x_20_8  
 UP BND1      w_20_8    1.1970927746912360e-01
 BV BND1      x_20_9  
 UP BND1      w_20_9    1.1970927746912360e-01
 BV BND1      x_20_10 
 UP BND1      w_20_10   1.1970927746912360e-01
 BV BND1      x_20_11 
 UP BND1      w_20_11   1.1970927746912360e-01
 BV BND1      x_20_12 
 UP BND1      w_20_12   1.1970927746912360e-01
 BV BND1      x_20_13 
 UP BND1      w_20_13   1.1970927746912360e-01
 BV BND1      x_20_14 
 UP BND1      w_20_14   1.1970927746912360e-01
 BV BND1      x_20_15 
 UP BND1      w_20_15   1.1970927746912360e-01
 UP BND1      rho_20    1
 BV BND1      x_10_0  
 UP BND1      w_10_0    1.1970927746912360e-01
 BV BND1      x_10_1  
 UP BND1      w_10_1    1.1970927746912360e-01
 UP BND1      rho_10    1
 UP BND1      a_13_14   1
 UP BND1      a_13_18   1
 UP BND1      a_13_17   1
 UP BND1      a_13_11   1
 UP BND1      a_13_12   1
 UP BND1      a_13_20   1
 UP BND1      a_13_10   1
 UP BND1      a_14_18   1
 UP BND1      a_14_17   1
 UP BND1      a_14_11   1
 UP BND1      a_14_12   1
 UP BND1      a_14_20   1
 UP BND1      a_14_10   1
 UP BND1      a_18_17   1
 UP BND1      a_18_11   1
 UP BND1      a_18_12   1
 UP BND1      a_18_20   1
 UP BND1      a_18_10   1
 UP BND1      a_17_11   1
 UP BND1      a_17_12   1
 UP BND1      a_17_20   1
 UP BND1      a_17_10   1
 UP BND1      a_11_12   1
 UP BND1      a_11_20   1
 UP BND1      a_11_10   1
 UP BND1      a_12_20   1
 UP BND1      a_12_10   1
 UP BND1      a_20_10   1
 BV BND1      service_0_13_1
 BV BND1      service_1_13_1
 BV BND1      service_0_14_0
 BV BND1      service_0_14_1
 BV BND1      service_0_14_2
 BV BND1      service_0_14_3
 BV BND1      service_0_14_4
 BV BND1      service_0_14_5
 BV BND1      service_0_14_6
 BV BND1      service_0_14_7
 BV BND1      service_0_14_8
 BV BND1      service_0_14_9
 BV BND1      service_0_14_10
 BV BND1      service_0_14_12
 BV BND1      service_0_14_13
 BV BND1      service_0_14_14
 BV BND1      service_0_14_15
 BV BND1      service_1_14_0
 BV BND1      service_1_14_1
 BV BND1      service_1_14_2
 BV BND1      service_1_14_3
 BV BND1      service_1_14_4
 BV BND1      service_1_14_5
 BV BND1      service_1_14_6
 BV BND1      service_1_14_7
 BV BND1      service_1_14_8
 BV BND1      service_1_14_9
 BV BND1      service_1_14_10
 BV BND1      service_1_14_12
 BV BND1      service_1_14_13
 BV BND1      service_1_14_14
 BV BND1      service_1_14_15
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_12_0
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_0
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_9
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_13
 BV BND1      service_0_20_14
 BV BND1      service_0_20_15
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_9
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_13
 BV BND1      service_1_20_14
 BV BND1      service_1_20_15
 BV BND1      service_0_10_1
 BV BND1      service_1_10_1
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  16
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  16
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  16
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  16
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  16
 FX BND1      visit_0_6  1
 UP BND1      order_0_6  16
 FX BND1      visit_0_7  1
 UP BND1      order_0_7  16
 FX BND1      visit_0_8  1
 UP BND1      order_0_8  16
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  16
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  16
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  16
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  16
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  16
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  16
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  16
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  16
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_6
 FX BND1      load_0_0_6  0
 BV BND1      arc_0_0_7
 FX BND1      load_0_0_7  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_6
 UP BND1      load_0_1_6  30
 BV BND1      arc_0_1_7
 UP BND1      load_0_1_7  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_6
 UP BND1      load_0_2_6  30
 BV BND1      arc_0_2_7
 UP BND1      load_0_2_7  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_6
 UP BND1      load_0_3_6  30
 BV BND1      arc_0_3_7
 UP BND1      load_0_3_7  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_6
 UP BND1      load_0_4_6  30
 BV BND1      arc_0_4_7
 UP BND1      load_0_4_7  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_6
 UP BND1      load_0_5_6  30
 BV BND1      arc_0_5_7
 UP BND1      load_0_5_7  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  30
 BV BND1      arc_0_6_0
 UP BND1      load_0_6_0  30
 BV BND1      arc_0_6_1
 UP BND1      load_0_6_1  30
 BV BND1      arc_0_6_2
 UP BND1      load_0_6_2  30
 BV BND1      arc_0_6_3
 UP BND1      load_0_6_3  30
 BV BND1      arc_0_6_4
 UP BND1      load_0_6_4  30
 BV BND1      arc_0_6_5
 UP BND1      load_0_6_5  30
 BV BND1      arc_0_6_7
 UP BND1      load_0_6_7  30
 BV BND1      arc_0_6_8
 UP BND1      load_0_6_8  30
 BV BND1      arc_0_6_9
 UP BND1      load_0_6_9  30
 BV BND1      arc_0_6_10
 UP BND1      load_0_6_10  30
 BV BND1      arc_0_6_11
 UP BND1      load_0_6_11  30
 BV BND1      arc_0_6_12
 UP BND1      load_0_6_12  30
 BV BND1      arc_0_6_13
 UP BND1      load_0_6_13  30
 BV BND1      arc_0_6_14
 UP BND1      load_0_6_14  30
 BV BND1      arc_0_6_15
 UP BND1      load_0_6_15  30
 BV BND1      arc_0_6_16
 UP BND1      load_0_6_16  30
 BV BND1      arc_0_7_0
 UP BND1      load_0_7_0  30
 BV BND1      arc_0_7_1
 UP BND1      load_0_7_1  30
 BV BND1      arc_0_7_2
 UP BND1      load_0_7_2  30
 BV BND1      arc_0_7_3
 UP BND1      load_0_7_3  30
 BV BND1      arc_0_7_4
 UP BND1      load_0_7_4  30
 BV BND1      arc_0_7_5
 UP BND1      load_0_7_5  30
 BV BND1      arc_0_7_6
 UP BND1      load_0_7_6  30
 BV BND1      arc_0_7_8
 UP BND1      load_0_7_8  30
 BV BND1      arc_0_7_9
 UP BND1      load_0_7_9  30
 BV BND1      arc_0_7_10
 UP BND1      load_0_7_10  30
 BV BND1      arc_0_7_11
 UP BND1      load_0_7_11  30
 BV BND1      arc_0_7_12
 UP BND1      load_0_7_12  30
 BV BND1      arc_0_7_13
 UP BND1      load_0_7_13  30
 BV BND1      arc_0_7_14
 UP BND1      load_0_7_14  30
 BV BND1      arc_0_7_15
 UP BND1      load_0_7_15  30
 BV BND1      arc_0_7_16
 UP BND1      load_0_7_16  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_6
 UP BND1      load_0_8_6  30
 BV BND1      arc_0_8_7
 UP BND1      load_0_8_7  30
 BV BND1      arc_0_8_9
 UP BND1      load_0_8_9  30
 BV BND1      arc_0_8_10
 UP BND1      load_0_8_10  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_8_16
 UP BND1      load_0_8_16  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_6
 UP BND1      load_0_9_6  30
 BV BND1      arc_0_9_7
 UP BND1      load_0_9_7  30
 BV BND1      arc_0_9_8
 UP BND1      load_0_9_8  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_9_16
 UP BND1      load_0_9_16  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_6
 UP BND1      load_0_10_6  30
 BV BND1      arc_0_10_7
 UP BND1      load_0_10_7  30
 BV BND1      arc_0_10_8
 UP BND1      load_0_10_8  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_10_16
 UP BND1      load_0_10_16  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_6
 UP BND1      load_0_11_6  30
 BV BND1      arc_0_11_7
 UP BND1      load_0_11_7  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_11_16
 UP BND1      load_0_11_16  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_6
 UP BND1      load_0_12_6  30
 BV BND1      arc_0_12_7
 UP BND1      load_0_12_7  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_6
 UP BND1      load_0_13_6  30
 BV BND1      arc_0_13_7
 UP BND1      load_0_13_7  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_6
 UP BND1      load_0_14_6  30
 BV BND1      arc_0_14_7
 UP BND1      load_0_14_7  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_6
 UP BND1      load_0_15_6  30
 BV BND1      arc_0_15_7
 UP BND1      load_0_15_7  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  30
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  30
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  30
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  30
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  30
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  30
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  30
 BV BND1      arc_0_16_6
 UP BND1      load_0_16_6  30
 BV BND1      arc_0_16_7
 UP BND1      load_0_16_7  30
 BV BND1      arc_0_16_8
 UP BND1      load_0_16_8  30
 BV BND1      arc_0_16_9
 UP BND1      load_0_16_9  30
 BV BND1      arc_0_16_10
 UP BND1      load_0_16_10  30
 BV BND1      arc_0_16_11
 UP BND1      load_0_16_11  30
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  30
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  30
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  30
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  30
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  8
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  8
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  8
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  8
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  8
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  8
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  8
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  8
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_11_16
 UP BND1      load_1_11_16  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  30
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  30
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  30
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  30
 BV BND1      arc_1_16_11
 UP BND1      load_1_16_11  30
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  30
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  30
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  30
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  30
ENDATA
