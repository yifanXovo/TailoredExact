* Signature: 0x7e02ef7ddc72efa3
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_4_32
 E  normalized_mass_4_33
 E  normalized_ratio_4_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 E  onehot_7_71
 E  normalized_mass_7_72
 E  normalized_ratio_7_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 E  onehot_31_100
 E  normalized_mass_31_101
 E  normalized_ratio_31_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 E  onehot_1_143
 E  normalized_mass_1_144
 E  normalized_ratio_1_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 E  onehot_2_178
 E  normalized_mass_2_179
 E  normalized_ratio_2_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 E  onehot_3_217
 E  normalized_mass_3_218
 E  normalized_ratio_3_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 G  product_lb_228
 L  product_ub_229
 G  product_lb_230
 L  product_ub_231
 G  product_lb_232
 L  product_ub_233
 G  product_lb_234
 L  product_ub_235
 G  product_lb_236
 L  product_ub_237
 G  product_lb_238
 L  product_ub_239
 G  product_lb_240
 L  product_ub_241
 G  product_lb_242
 L  product_ub_243
 G  product_lb_244
 L  product_ub_245
 E  onehot_16_246
 E  normalized_mass_16_247
 E  normalized_ratio_16_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 G  product_lb_265
 L  product_ub_266
 G  product_lb_267
 L  product_ub_268
 G  product_lb_269
 L  product_ub_270
 G  product_lb_271
 L  product_ub_272
 G  product_lb_273
 L  product_ub_274
 E  onehot_11_275
 E  normalized_mass_11_276
 E  normalized_ratio_11_277
 G  stock_lb_278
 L  stock_ub_279
 L  parent_nonstrict_scope_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 G  block_pair_pos_327
 G  block_pair_neg_328
 G  block_pair_pos_329
 G  block_pair_neg_330
 G  block_pair_pos_331
 G  block_pair_neg_332
 G  block_pair_pos_333
 G  block_pair_neg_334
 G  block_pair_pos_335
 G  block_pair_neg_336
 E  normalization_337
 G  full_original_Gini_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 E  unique_nonzero_owner_443
 E  unique_nonzero_owner_444
 E  unique_nonzero_owner_445
 E  unique_nonzero_owner_446
 E  unique_nonzero_owner_447
 E  unique_nonzero_owner_448
 E  unique_nonzero_owner_449
 E  unique_nonzero_owner_450
 E  unique_nonzero_owner_451
 E  unique_nonzero_owner_452
 E  unique_nonzero_owner_453
 E  unique_nonzero_owner_454
 E  unique_nonzero_owner_455
 E  unique_nonzero_owner_456
 E  unique_nonzero_owner_457
 L  arc_capacity_458
 L  arc_capacity_459
 L  arc_capacity_460
 L  arc_capacity_461
 L  arc_capacity_462
 L  arc_capacity_463
 L  arc_capacity_464
 L  arc_capacity_465
 L  arc_capacity_466
 L  arc_capacity_467
 L  arc_capacity_468
 L  arc_capacity_469
 L  arc_capacity_470
 L  arc_capacity_471
 L  arc_capacity_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 G  connected_order_arc_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 G  connected_order_arc_580
 L  arc_capacity_581
 G  connected_order_arc_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 G  connected_order_arc_603
 L  arc_capacity_604
 G  connected_order_arc_605
 L  arc_capacity_606
 G  connected_order_arc_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 G  connected_order_arc_628
 L  arc_capacity_629
 G  connected_order_arc_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 G  connected_order_arc_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 G  connected_order_arc_703
 L  arc_capacity_704
 G  connected_order_arc_705
 L  arc_capacity_706
 G  connected_order_arc_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 G  connected_order_arc_728
 L  arc_capacity_729
 G  connected_order_arc_730
 L  arc_capacity_731
 G  connected_order_arc_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 L  arc_capacity_752
 G  connected_order_arc_753
 L  arc_capacity_754
 G  connected_order_arc_755
 L  arc_capacity_756
 G  connected_order_arc_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 L  arc_capacity_773
 G  connected_order_arc_774
 L  arc_capacity_775
 G  connected_order_arc_776
 L  arc_capacity_777
 G  connected_order_arc_778
 L  arc_capacity_779
 G  connected_order_arc_780
 L  arc_capacity_781
 G  connected_order_arc_782
 L  arc_capacity_783
 G  connected_order_arc_784
 L  arc_capacity_785
 G  connected_order_arc_786
 L  arc_capacity_787
 G  connected_order_arc_788
 L  arc_capacity_789
 G  connected_order_arc_790
 L  arc_capacity_791
 G  connected_order_arc_792
 L  arc_capacity_793
 G  connected_order_arc_794
 L  arc_capacity_795
 G  connected_order_arc_796
 E  depot_departure_or_bypass_797
 E  depot_return_or_bypass_798
 E  out_degree_799
 E  in_degree_800
 G  order_active_lb_801
 L  order_active_ub_802
 E  segment_load_conservation_803
 G  segment_prefix_lb_804
 L  segment_prefix_ub_805
 E  out_degree_806
 E  in_degree_807
 G  order_active_lb_808
 L  order_active_ub_809
 E  segment_load_conservation_810
 G  segment_prefix_lb_811
 L  segment_prefix_ub_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  segment_load_conservation_817
 G  segment_prefix_lb_818
 L  segment_prefix_ub_819
 E  out_degree_820
 E  in_degree_821
 G  order_active_lb_822
 L  order_active_ub_823
 E  segment_load_conservation_824
 G  segment_prefix_lb_825
 L  segment_prefix_ub_826
 E  out_degree_827
 E  in_degree_828
 G  order_active_lb_829
 L  order_active_ub_830
 E  segment_load_conservation_831
 G  segment_prefix_lb_832
 L  segment_prefix_ub_833
 E  out_degree_834
 E  in_degree_835
 G  order_active_lb_836
 L  order_active_ub_837
 E  service_visit_def_838
 E  free_load_conservation_839
 E  out_degree_840
 E  in_degree_841
 G  order_active_lb_842
 L  order_active_ub_843
 E  service_visit_def_844
 E  free_load_conservation_845
 E  out_degree_846
 E  in_degree_847
 G  order_active_lb_848
 L  order_active_ub_849
 E  service_visit_def_850
 E  free_load_conservation_851
 E  out_degree_852
 E  in_degree_853
 G  order_active_lb_854
 L  order_active_ub_855
 E  service_visit_def_856
 E  free_load_conservation_857
 E  out_degree_858
 E  in_degree_859
 G  order_active_lb_860
 L  order_active_ub_861
 E  service_visit_def_862
 E  free_load_conservation_863
 E  out_degree_864
 E  in_degree_865
 G  order_active_lb_866
 L  order_active_ub_867
 E  service_visit_def_868
 E  free_load_conservation_869
 E  out_degree_870
 E  in_degree_871
 G  order_active_lb_872
 L  order_active_ub_873
 E  service_visit_def_874
 E  free_load_conservation_875
 E  out_degree_876
 E  in_degree_877
 G  order_active_lb_878
 L  order_active_ub_879
 E  service_visit_def_880
 E  free_load_conservation_881
 G  fixed_segment_relative_order_882
 G  fixed_segment_relative_order_883
 G  fixed_segment_relative_order_884
 G  fixed_segment_relative_order_885
 L  original_T_including_depot_unload_886
 L  arc_capacity_887
 L  arc_capacity_888
 L  arc_capacity_889
 L  arc_capacity_890
 L  arc_capacity_891
 L  arc_capacity_892
 L  arc_capacity_893
 L  arc_capacity_894
 L  arc_capacity_895
 L  arc_capacity_896
 L  arc_capacity_897
 L  arc_capacity_898
 L  arc_capacity_899
 L  arc_capacity_900
 L  arc_capacity_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 G  connected_order_arc_1086
 L  arc_capacity_1087
 G  connected_order_arc_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 G  connected_order_arc_1109
 L  arc_capacity_1110
 G  connected_order_arc_1111
 L  arc_capacity_1112
 G  connected_order_arc_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 L  arc_capacity_1131
 G  connected_order_arc_1132
 L  arc_capacity_1133
 G  connected_order_arc_1134
 L  arc_capacity_1135
 G  connected_order_arc_1136
 L  arc_capacity_1137
 G  connected_order_arc_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 L  arc_capacity_1152
 G  connected_order_arc_1153
 L  arc_capacity_1154
 G  connected_order_arc_1155
 L  arc_capacity_1156
 G  connected_order_arc_1157
 L  arc_capacity_1158
 G  connected_order_arc_1159
 L  arc_capacity_1160
 G  connected_order_arc_1161
 L  arc_capacity_1162
 G  connected_order_arc_1163
 L  arc_capacity_1164
 G  connected_order_arc_1165
 L  arc_capacity_1166
 G  connected_order_arc_1167
 L  arc_capacity_1168
 G  connected_order_arc_1169
 L  arc_capacity_1170
 G  connected_order_arc_1171
 L  arc_capacity_1172
 G  connected_order_arc_1173
 L  arc_capacity_1174
 G  connected_order_arc_1175
 L  arc_capacity_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 G  connected_order_arc_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 E  depot_departure_or_bypass_1226
 E  depot_return_or_bypass_1227
 E  out_degree_1228
 E  in_degree_1229
 G  order_active_lb_1230
 L  order_active_ub_1231
 E  segment_load_conservation_1232
 G  segment_prefix_lb_1233
 L  segment_prefix_ub_1234
 E  out_degree_1235
 E  in_degree_1236
 G  order_active_lb_1237
 L  order_active_ub_1238
 E  segment_load_conservation_1239
 G  segment_prefix_lb_1240
 L  segment_prefix_ub_1241
 E  out_degree_1242
 E  in_degree_1243
 G  order_active_lb_1244
 L  order_active_ub_1245
 E  segment_load_conservation_1246
 G  segment_prefix_lb_1247
 L  segment_prefix_ub_1248
 E  out_degree_1249
 E  in_degree_1250
 G  order_active_lb_1251
 L  order_active_ub_1252
 E  segment_load_conservation_1253
 G  segment_prefix_lb_1254
 L  segment_prefix_ub_1255
 E  out_degree_1256
 E  in_degree_1257
 G  order_active_lb_1258
 L  order_active_ub_1259
 E  segment_load_conservation_1260
 G  segment_prefix_lb_1261
 L  segment_prefix_ub_1262
 E  out_degree_1263
 E  in_degree_1264
 G  order_active_lb_1265
 L  order_active_ub_1266
 E  service_visit_def_1267
 E  free_load_conservation_1268
 E  out_degree_1269
 E  in_degree_1270
 G  order_active_lb_1271
 L  order_active_ub_1272
 E  service_visit_def_1273
 E  free_load_conservation_1274
 E  out_degree_1275
 E  in_degree_1276
 G  order_active_lb_1277
 L  order_active_ub_1278
 E  service_visit_def_1279
 E  free_load_conservation_1280
 E  out_degree_1281
 E  in_degree_1282
 G  order_active_lb_1283
 L  order_active_ub_1284
 E  service_visit_def_1285
 E  free_load_conservation_1286
 E  out_degree_1287
 E  in_degree_1288
 G  order_active_lb_1289
 L  order_active_ub_1290
 E  service_visit_def_1291
 E  free_load_conservation_1292
 E  out_degree_1293
 E  in_degree_1294
 G  order_active_lb_1295
 L  order_active_ub_1296
 E  service_visit_def_1297
 E  free_load_conservation_1298
 E  out_degree_1299
 E  in_degree_1300
 G  order_active_lb_1301
 L  order_active_ub_1302
 E  service_visit_def_1303
 E  free_load_conservation_1304
 E  out_degree_1305
 E  in_degree_1306
 G  order_active_lb_1307
 L  order_active_ub_1308
 E  service_visit_def_1309
 E  free_load_conservation_1310
 G  fixed_segment_relative_order_1311
 G  fixed_segment_relative_order_1312
 G  fixed_segment_relative_order_1313
 G  fixed_segment_relative_order_1314
 L  original_T_including_depot_unload_1315
 L  arc_capacity_1316
 L  arc_capacity_1317
 L  arc_capacity_1318
 L  arc_capacity_1319
 L  arc_capacity_1320
 L  arc_capacity_1321
 L  arc_capacity_1322
 L  arc_capacity_1323
 L  arc_capacity_1324
 L  arc_capacity_1325
 L  arc_capacity_1326
 L  arc_capacity_1327
 L  arc_capacity_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 G  connected_order_arc_1472
 L  arc_capacity_1473
 G  connected_order_arc_1474
 L  arc_capacity_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 G  connected_order_arc_1495
 L  arc_capacity_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 L  arc_capacity_1517
 L  arc_capacity_1518
 G  connected_order_arc_1519
 L  arc_capacity_1520
 G  connected_order_arc_1521
 L  arc_capacity_1522
 G  connected_order_arc_1523
 L  arc_capacity_1524
 G  connected_order_arc_1525
 L  arc_capacity_1526
 G  connected_order_arc_1527
 L  arc_capacity_1528
 G  connected_order_arc_1529
 L  arc_capacity_1530
 G  connected_order_arc_1531
 L  arc_capacity_1532
 G  connected_order_arc_1533
 L  arc_capacity_1534
 G  connected_order_arc_1535
 L  arc_capacity_1536
 G  connected_order_arc_1537
 L  arc_capacity_1538
 L  arc_capacity_1539
 G  connected_order_arc_1540
 L  arc_capacity_1541
 G  connected_order_arc_1542
 L  arc_capacity_1543
 G  connected_order_arc_1544
 L  arc_capacity_1545
 G  connected_order_arc_1546
 L  arc_capacity_1547
 G  connected_order_arc_1548
 L  arc_capacity_1549
 G  connected_order_arc_1550
 L  arc_capacity_1551
 G  connected_order_arc_1552
 L  arc_capacity_1553
 G  connected_order_arc_1554
 L  arc_capacity_1555
 G  connected_order_arc_1556
 L  arc_capacity_1557
 G  connected_order_arc_1558
 E  depot_departure_or_bypass_1559
 E  depot_return_or_bypass_1560
 E  out_degree_1561
 E  in_degree_1562
 G  order_active_lb_1563
 L  order_active_ub_1564
 E  segment_load_conservation_1565
 G  segment_prefix_lb_1566
 L  segment_prefix_ub_1567
 E  out_degree_1568
 E  in_degree_1569
 G  order_active_lb_1570
 L  order_active_ub_1571
 E  segment_load_conservation_1572
 G  segment_prefix_lb_1573
 L  segment_prefix_ub_1574
 E  out_degree_1575
 E  in_degree_1576
 G  order_active_lb_1577
 L  order_active_ub_1578
 E  segment_load_conservation_1579
 G  segment_prefix_lb_1580
 L  segment_prefix_ub_1581
 E  out_degree_1582
 E  in_degree_1583
 G  order_active_lb_1584
 L  order_active_ub_1585
 E  service_visit_def_1586
 E  free_load_conservation_1587
 E  out_degree_1588
 E  in_degree_1589
 G  order_active_lb_1590
 L  order_active_ub_1591
 E  service_visit_def_1592
 E  free_load_conservation_1593
 E  out_degree_1594
 E  in_degree_1595
 G  order_active_lb_1596
 L  order_active_ub_1597
 E  service_visit_def_1598
 E  free_load_conservation_1599
 E  out_degree_1600
 E  in_degree_1601
 G  order_active_lb_1602
 L  order_active_ub_1603
 E  service_visit_def_1604
 E  free_load_conservation_1605
 E  out_degree_1606
 E  in_degree_1607
 G  order_active_lb_1608
 L  order_active_ub_1609
 E  service_visit_def_1610
 E  free_load_conservation_1611
 E  out_degree_1612
 E  in_degree_1613
 G  order_active_lb_1614
 L  order_active_ub_1615
 E  service_visit_def_1616
 E  free_load_conservation_1617
 E  out_degree_1618
 E  in_degree_1619
 G  order_active_lb_1620
 L  order_active_ub_1621
 E  service_visit_def_1622
 E  free_load_conservation_1623
 E  out_degree_1624
 E  in_degree_1625
 G  order_active_lb_1626
 L  order_active_ub_1627
 E  service_visit_def_1628
 E  free_load_conservation_1629
 G  fixed_segment_relative_order_1630
 G  fixed_segment_relative_order_1631
 L  original_T_including_depot_unload_1632
COLUMNS
    t         normalized_mass_4_33  -1
    t         normalized_mass_7_72  -1
    t         normalized_mass_31_101  -1
    t         normalized_mass_1_144  -1
    t         normalized_mass_2_179  -1
    t         normalized_mass_3_218  -1
    t         normalized_mass_16_247  -1
    t         normalized_mass_11_276  -1
    t         normalization_337  2.3226190476190482e+01
    t         full_original_Gini_338  -9.4466666666666768e+01
    q         OBJ       1
    q         parent_nonstrict_scope_280  1
    q         full_original_Gini_338  35
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       0.0315
    x_4_0     product_lb_0  -2.5140668023439477e-02
    x_4_0     product_ub_1  -4.3054843669955919e-02
    x_4_0     onehot_4_32  1
    x_4_0     parent_nonstrict_scope_280  0.0735
    x_4_0     unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_0  1
    w_4_0     product_ub_1  1
    w_4_0     normalized_mass_4_33  1
    w_4_0     full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       2.1000000000000005e-02
    x_4_1     product_lb_2  -2.5140668023439477e-02
    x_4_1     product_ub_3  -4.3054843669955919e-02
    x_4_1     onehot_4_32  1
    x_4_1     stock_lb_278  1
    x_4_1     stock_ub_279  1
    x_4_1     parent_nonstrict_scope_280  0.063
    x_4_1     unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_2  1
    w_4_1     product_ub_3  1
    w_4_1     normalized_mass_4_33  1
    w_4_1     normalized_ratio_4_34  -1.4285714285714285e-01
    w_4_1     full_original_Gini_338  -1.9369047619047624e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       1.0500000000000002e-02
    x_4_2     product_lb_4  -2.5140668023439477e-02
    x_4_2     product_ub_5  -4.3054843669955919e-02
    x_4_2     onehot_4_32  1
    x_4_2     stock_lb_278  2
    x_4_2     stock_ub_279  2
    x_4_2     parent_nonstrict_scope_280  0.0525
    x_4_2     unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_4  1
    w_4_2     product_ub_5  1
    w_4_2     normalized_mass_4_33  1
    w_4_2     normalized_ratio_4_34  -2.8571428571428570e-01
    w_4_2     full_original_Gini_338  -1.5583333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_6  -2.5140668023439477e-02
    x_4_3     product_ub_7  -4.3054843669955919e-02
    x_4_3     onehot_4_32  1
    x_4_3     stock_lb_278  3
    x_4_3     stock_ub_279  3
    x_4_3     parent_nonstrict_scope_280  4.1999999999999996e-02
    x_4_3     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_6  1
    w_4_3     product_ub_7  1
    w_4_3     normalized_mass_4_33  1
    w_4_3     normalized_ratio_4_34  -4.2857142857142855e-01
    w_4_3     full_original_Gini_338  -1.2069047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -1.0499999999999995e-02
    x_4_4     product_lb_8  -2.5140668023439477e-02
    x_4_4     product_ub_9  -4.3054843669955919e-02
    x_4_4     onehot_4_32  1
    x_4_4     stock_lb_278  4
    x_4_4     stock_ub_279  4
    x_4_4     parent_nonstrict_scope_280  0.0315
    x_4_4     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_8  1
    w_4_4     product_ub_9  1
    w_4_4     normalized_mass_4_33  1
    w_4_4     normalized_ratio_4_34  -5.7142857142857140e-01
    w_4_4     full_original_Gini_338  -8.9261904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -2.0999999999999991e-02
    x_4_5     product_lb_10  -2.5140668023439477e-02
    x_4_5     product_ub_11  -4.3054843669955919e-02
    x_4_5     onehot_4_32  1
    x_4_5     stock_lb_278  5
    x_4_5     stock_ub_279  5
    x_4_5     parent_nonstrict_scope_280  2.1000000000000005e-02
    x_4_5     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_10  1
    w_4_5     product_ub_11  1
    w_4_5     normalized_mass_4_33  1
    w_4_5     normalized_ratio_4_34  -7.1428571428571419e-01
    w_4_5     full_original_Gini_338  -6.3833333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -3.1499999999999993e-02
    x_4_6     product_lb_12  -2.5140668023439477e-02
    x_4_6     product_ub_13  -4.3054843669955919e-02
    x_4_6     onehot_4_32  1
    x_4_6     stock_lb_278  6
    x_4_6     stock_ub_279  6
    x_4_6     parent_nonstrict_scope_280  1.0500000000000002e-02
    x_4_6     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_12  1
    w_4_6     product_ub_13  1
    w_4_6     normalized_mass_4_33  1
    w_4_6     normalized_ratio_4_34  -8.5714285714285710e-01
    w_4_6     full_original_Gini_338  -5.5023809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -4.1999999999999996e-02
    x_4_7     product_lb_14  -2.5140668023439477e-02
    x_4_7     product_ub_15  -4.3054843669955919e-02
    x_4_7     onehot_4_32  1
    x_4_7     stock_lb_278  7
    x_4_7     stock_ub_279  7
    x_4_7     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_14  1
    w_4_7     product_ub_15  1
    w_4_7     normalized_mass_4_33  1
    w_4_7     normalized_ratio_4_34  -1
    w_4_7     full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -0.0315
    x_4_8     product_lb_16  -2.5140668023439477e-02
    x_4_8     product_ub_17  -4.3054843669955919e-02
    x_4_8     onehot_4_32  1
    x_4_8     stock_lb_278  8
    x_4_8     stock_ub_279  8
    x_4_8     parent_nonstrict_scope_280  1.0499999999999995e-02
    x_4_8     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_16  1
    w_4_8     product_ub_17  1
    w_4_8     normalized_mass_4_33  1
    w_4_8     normalized_ratio_4_34  -1.1428571428571428e+00
    w_4_8     full_original_Gini_338  -8.0738095238095227e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -2.1000000000000005e-02
    x_4_9     product_lb_18  -2.5140668023439477e-02
    x_4_9     product_ub_19  -4.3054843669955919e-02
    x_4_9     onehot_4_32  1
    x_4_9     stock_lb_278  9
    x_4_9     stock_ub_279  9
    x_4_9     parent_nonstrict_scope_280  2.0999999999999991e-02
    x_4_9     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_18  1
    w_4_9     product_ub_19  1
    w_4_9     normalized_mass_4_33  1
    w_4_9     normalized_ratio_4_34  -1.2857142857142856e+00
    w_4_9     full_original_Gini_338  -1.1488095238095230e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -1.0500000000000009e-02
    x_4_10    product_lb_20  -2.5140668023439477e-02
    x_4_10    product_ub_21  -4.3054843669955919e-02
    x_4_10    onehot_4_32  1
    x_4_10    stock_lb_278  10
    x_4_10    stock_ub_279  10
    x_4_10    parent_nonstrict_scope_280  3.1499999999999986e-02
    x_4_10    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_20  1
    w_4_10    product_ub_21  1
    w_4_10    normalized_mass_4_33  1
    w_4_10    normalized_ratio_4_34  -1.4285714285714284e+00
    w_4_10    full_original_Gini_338  -1.5345238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_22  -2.5140668023439477e-02
    x_4_11    product_ub_23  -4.3054843669955919e-02
    x_4_11    onehot_4_32  1
    x_4_11    stock_lb_278  11
    x_4_11    stock_ub_279  11
    x_4_11    parent_nonstrict_scope_280  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_22  1
    w_4_11    product_ub_23  1
    w_4_11    normalized_mass_4_33  1
    w_4_11    normalized_ratio_4_34  -1.5714285714285714e+00
    w_4_11    full_original_Gini_338  -1.9202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       1.0499999999999995e-02
    x_4_12    product_lb_24  -2.5140668023439477e-02
    x_4_12    product_ub_25  -4.3054843669955919e-02
    x_4_12    onehot_4_32  1
    x_4_12    stock_lb_278  12
    x_4_12    stock_ub_279  12
    x_4_12    parent_nonstrict_scope_280  5.2499999999999991e-02
    x_4_12    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_24  1
    w_4_12    product_ub_25  1
    w_4_12    normalized_mass_4_33  1
    w_4_12    normalized_ratio_4_34  -1.7142857142857142e+00
    w_4_12    full_original_Gini_338  -2.3059523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       2.0999999999999991e-02
    x_4_13    product_lb_26  -2.5140668023439477e-02
    x_4_13    product_ub_27  -4.3054843669955919e-02
    x_4_13    onehot_4_32  1
    x_4_13    stock_lb_278  13
    x_4_13    stock_ub_279  13
    x_4_13    parent_nonstrict_scope_280  6.2999999999999987e-02
    x_4_13    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_26  1
    w_4_13    product_ub_27  1
    w_4_13    normalized_mass_4_33  1
    w_4_13    normalized_ratio_4_34  -1.8571428571428570e+00
    w_4_13    full_original_Gini_338  -2.6916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       0.0315
    x_4_14    product_lb_28  -2.5140668023439477e-02
    x_4_14    product_ub_29  -4.3054843669955919e-02
    x_4_14    onehot_4_32  1
    x_4_14    stock_lb_278  14
    x_4_14    stock_ub_279  14
    x_4_14    parent_nonstrict_scope_280  0.0735
    x_4_14    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_28  1
    w_4_14    product_ub_29  1
    w_4_14    normalized_mass_4_33  1
    w_4_14    normalized_ratio_4_34  -2
    w_4_14    full_original_Gini_338  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       4.1999999999999996e-02
    x_4_15    product_lb_30  -2.5140668023439477e-02
    x_4_15    product_ub_31  -4.3054843669955919e-02
    x_4_15    onehot_4_32  1
    x_4_15    stock_lb_278  15
    x_4_15    stock_ub_279  15
    x_4_15    parent_nonstrict_scope_280  8.3999999999999991e-02
    x_4_15    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_30  1
    w_4_15    product_ub_31  1
    w_4_15    normalized_mass_4_33  1
    w_4_15    normalized_ratio_4_34  -2.1428571428571428e+00
    w_4_15    full_original_Gini_338  -3.4630952380952372e+01
    rho_4     normalized_ratio_4_34  1
    rho_4     block_pair_pos_299  -1
    rho_4     block_pair_neg_300  1
    rho_4     block_pair_pos_301  -1
    rho_4     block_pair_neg_302  1
    rho_4     block_pair_pos_303  -1
    rho_4     block_pair_neg_304  1
    rho_4     block_pair_pos_305  -1
    rho_4     block_pair_neg_306  1
    rho_4     block_pair_pos_307  -1
    rho_4     block_pair_neg_308  1
    rho_4     block_pair_pos_309  -1
    rho_4     block_pair_neg_310  1
    rho_4     block_pair_pos_311  -1
    rho_4     block_pair_neg_312  1
    rho_4     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_7_0     OBJ       0.042
    x_7_0     product_lb_35  -2.5140668023439477e-02
    x_7_0     product_ub_36  -4.3054843669955919e-02
    x_7_0     onehot_7_71  1
    x_7_0     parent_nonstrict_scope_280  0.096
    x_7_0     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_0     product_lb_35  1
    w_7_0     product_ub_36  1
    w_7_0     normalized_mass_7_72  1
    w_7_0     full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_1     OBJ       3.0000000000000006e-02
    x_7_1     product_lb_37  -2.5140668023439477e-02
    x_7_1     product_ub_38  -4.3054843669955919e-02
    x_7_1     onehot_7_71  1
    x_7_1     stock_lb_278  1
    x_7_1     stock_ub_279  1
    x_7_1     parent_nonstrict_scope_280  0.084
    x_7_1     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_1     product_lb_37  1
    w_7_1     product_ub_38  1
    w_7_1     normalized_mass_7_72  1
    w_7_1     normalized_ratio_7_73  -0.125
    w_7_1     full_original_Gini_338  -1.9851190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_2     OBJ       1.8000000000000009e-02
    x_7_2     product_lb_39  -2.5140668023439477e-02
    x_7_2     product_ub_40  -4.3054843669955919e-02
    x_7_2     onehot_7_71  1
    x_7_2     stock_lb_278  2
    x_7_2     stock_ub_279  2
    x_7_2     parent_nonstrict_scope_280  7.2000000000000008e-02
    x_7_2     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_2     product_lb_39  1
    w_7_2     product_ub_40  1
    w_7_2     normalized_mass_7_72  1
    w_7_2     normalized_ratio_7_73  -0.25
    w_7_2     full_original_Gini_338  -1.6476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_3     OBJ       5.9999999999999984e-03
    x_7_3     product_lb_41  -2.5140668023439477e-02
    x_7_3     product_ub_42  -4.3054843669955919e-02
    x_7_3     onehot_7_71  1
    x_7_3     stock_lb_278  3
    x_7_3     stock_ub_279  3
    x_7_3     parent_nonstrict_scope_280  0.06
    x_7_3     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_3     product_lb_41  1
    w_7_3     product_ub_42  1
    w_7_3     normalized_mass_7_72  1
    w_7_3     normalized_ratio_7_73  -0.375
    w_7_3     full_original_Gini_338  -1.3351190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_4     OBJ       -5.9999999999999984e-03
    x_7_4     product_lb_43  -2.5140668023439477e-02
    x_7_4     product_ub_44  -4.3054843669955919e-02
    x_7_4     onehot_7_71  1
    x_7_4     stock_lb_278  4
    x_7_4     stock_ub_279  4
    x_7_4     parent_nonstrict_scope_280  0.048
    x_7_4     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_4     product_lb_43  1
    w_7_4     product_ub_44  1
    w_7_4     normalized_mass_7_72  1
    w_7_4     normalized_ratio_7_73  -0.5
    w_7_4     full_original_Gini_338  -1.0426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_5     OBJ       -1.7999999999999995e-02
    x_7_5     product_lb_45  -2.5140668023439477e-02
    x_7_5     product_ub_46  -4.3054843669955919e-02
    x_7_5     onehot_7_71  1
    x_7_5     stock_lb_278  5
    x_7_5     stock_ub_279  5
    x_7_5     parent_nonstrict_scope_280  3.6000000000000004e-02
    x_7_5     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_5     product_lb_45  1
    w_7_5     product_ub_46  1
    w_7_5     normalized_mass_7_72  1
    w_7_5     normalized_ratio_7_73  -0.625
    w_7_5     full_original_Gini_338  -7.9011904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_6     OBJ       -0.03
    x_7_6     product_lb_47  -2.5140668023439477e-02
    x_7_6     product_ub_48  -4.3054843669955919e-02
    x_7_6     onehot_7_71  1
    x_7_6     stock_lb_278  6
    x_7_6     stock_ub_279  6
    x_7_6     parent_nonstrict_scope_280  0.024
    x_7_6     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_6     product_lb_47  1
    w_7_6     product_ub_48  1
    w_7_6     normalized_mass_7_72  1
    w_7_6     normalized_ratio_7_73  -0.75
    w_7_6     full_original_Gini_338  -5.9904761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_7     OBJ       -4.1999999999999996e-02
    x_7_7     product_lb_49  -2.5140668023439477e-02
    x_7_7     product_ub_50  -4.3054843669955919e-02
    x_7_7     onehot_7_71  1
    x_7_7     stock_lb_278  7
    x_7_7     stock_ub_279  7
    x_7_7     parent_nonstrict_scope_280  0.012
    x_7_7     unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_7     product_lb_49  1
    w_7_7     product_ub_50  1
    w_7_7     normalized_mass_7_72  1
    w_7_7     normalized_ratio_7_73  -0.875
    w_7_7     full_original_Gini_338  -5.4488095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_8     OBJ       -0.054
    x_7_8     product_lb_51  -2.5140668023439477e-02
    x_7_8     product_ub_52  -4.3054843669955919e-02
    x_7_8     onehot_7_71  1
    x_7_8     stock_lb_278  8
    x_7_8     stock_ub_279  8
    x_7_8     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_8     product_lb_51  1
    w_7_8     product_ub_52  1
    w_7_8     normalized_mass_7_72  1
    w_7_8     normalized_ratio_7_73  -1
    w_7_8     full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_9     OBJ       -4.1999999999999996e-02
    x_7_9     product_lb_53  -2.5140668023439477e-02
    x_7_9     product_ub_54  -4.3054843669955919e-02
    x_7_9     onehot_7_71  1
    x_7_9     stock_lb_278  9
    x_7_9     stock_ub_279  9
    x_7_9     parent_nonstrict_scope_280  0.012
    x_7_9     unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_9     product_lb_53  1
    w_7_9     product_ub_54  1
    w_7_9     normalized_mass_7_72  1
    w_7_9     normalized_ratio_7_73  -1.125
    w_7_9     full_original_Gini_338  -7.6988095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_7_10    OBJ       -0.03
    x_7_10    product_lb_55  -2.5140668023439477e-02
    x_7_10    product_ub_56  -4.3054843669955919e-02
    x_7_10    onehot_7_71  1
    x_7_10    stock_lb_278  10
    x_7_10    stock_ub_279  10
    x_7_10    parent_nonstrict_scope_280  0.024
    x_7_10    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_10    product_lb_55  1
    w_7_10    product_ub_56  1
    w_7_10    normalized_mass_7_72  1
    w_7_10    normalized_ratio_7_73  -1.25
    w_7_10    full_original_Gini_338  -1.0523809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_11    OBJ       -1.7999999999999995e-02
    x_7_11    product_lb_57  -2.5140668023439477e-02
    x_7_11    product_ub_58  -4.3054843669955919e-02
    x_7_11    onehot_7_71  1
    x_7_11    stock_lb_278  11
    x_7_11    stock_ub_279  11
    x_7_11    parent_nonstrict_scope_280  3.6000000000000004e-02
    x_7_11    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_11    product_lb_57  1
    w_7_11    product_ub_58  1
    w_7_11    normalized_mass_7_72  1
    w_7_11    normalized_ratio_7_73  -1.375
    w_7_11    full_original_Gini_338  -1.3898809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_12    OBJ       -5.9999999999999984e-03
    x_7_12    product_lb_59  -2.5140668023439477e-02
    x_7_12    product_ub_60  -4.3054843669955919e-02
    x_7_12    onehot_7_71  1
    x_7_12    stock_lb_278  12
    x_7_12    stock_ub_279  12
    x_7_12    parent_nonstrict_scope_280  0.048
    MARKER    'MARKER'                 'INTEND'
    w_7_12    product_lb_59  1
    w_7_12    product_ub_60  1
    w_7_12    normalized_mass_7_72  1
    w_7_12    normalized_ratio_7_73  -1.5
    w_7_12    full_original_Gini_338  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_13    OBJ       5.9999999999999984e-03
    x_7_13    product_lb_61  -2.5140668023439477e-02
    x_7_13    product_ub_62  -4.3054843669955919e-02
    x_7_13    onehot_7_71  1
    x_7_13    stock_lb_278  13
    x_7_13    stock_ub_279  13
    x_7_13    parent_nonstrict_scope_280  0.06
    x_7_13    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_13    product_lb_61  1
    w_7_13    product_ub_62  1
    w_7_13    normalized_mass_7_72  1
    w_7_13    normalized_ratio_7_73  -1.625
    w_7_13    full_original_Gini_338  -2.0648809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_14    OBJ       1.8000000000000009e-02
    x_7_14    product_lb_63  -2.5140668023439477e-02
    x_7_14    product_ub_64  -4.3054843669955919e-02
    x_7_14    onehot_7_71  1
    x_7_14    stock_lb_278  14
    x_7_14    stock_ub_279  14
    x_7_14    parent_nonstrict_scope_280  7.2000000000000008e-02
    x_7_14    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_14    product_lb_63  1
    w_7_14    product_ub_64  1
    w_7_14    normalized_mass_7_72  1
    w_7_14    normalized_ratio_7_73  -1.75
    w_7_14    full_original_Gini_338  -2.4023809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_15    OBJ       3.0000000000000006e-02
    x_7_15    product_lb_65  -2.5140668023439477e-02
    x_7_15    product_ub_66  -4.3054843669955919e-02
    x_7_15    onehot_7_71  1
    x_7_15    stock_lb_278  15
    x_7_15    stock_ub_279  15
    x_7_15    parent_nonstrict_scope_280  0.084
    x_7_15    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_15    product_lb_65  1
    w_7_15    product_ub_66  1
    w_7_15    normalized_mass_7_72  1
    w_7_15    normalized_ratio_7_73  -1.875
    w_7_15    full_original_Gini_338  -2.7398809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_16    OBJ       0.042
    x_7_16    product_lb_67  -2.5140668023439477e-02
    x_7_16    product_ub_68  -4.3054843669955919e-02
    x_7_16    onehot_7_71  1
    x_7_16    stock_lb_278  16
    x_7_16    stock_ub_279  16
    x_7_16    parent_nonstrict_scope_280  0.096
    x_7_16    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_16    product_lb_67  1
    w_7_16    product_ub_68  1
    w_7_16    normalized_mass_7_72  1
    w_7_16    normalized_ratio_7_73  -2
    w_7_16    full_original_Gini_338  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_7_17    OBJ       0.054
    x_7_17    product_lb_69  -2.5140668023439477e-02
    x_7_17    product_ub_70  -4.3054843669955919e-02
    x_7_17    onehot_7_71  1
    x_7_17    stock_lb_278  17
    x_7_17    stock_ub_279  17
    x_7_17    parent_nonstrict_scope_280  0.108
    x_7_17    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_7_17    product_lb_69  1
    w_7_17    product_ub_70  1
    w_7_17    normalized_mass_7_72  1
    w_7_17    normalized_ratio_7_73  -2.125
    w_7_17    full_original_Gini_338  -3.4148809523809526e+01
    rho_7     normalized_ratio_7_73  1
    rho_7     block_pair_pos_305  1
    rho_7     block_pair_neg_306  -1
    rho_7     block_pair_pos_313  -1
    rho_7     block_pair_neg_314  1
    rho_7     block_pair_pos_315  -1
    rho_7     block_pair_neg_316  1
    rho_7     block_pair_pos_317  -1
    rho_7     block_pair_neg_318  1
    rho_7     block_pair_pos_319  -1
    rho_7     block_pair_neg_320  1
    rho_7     block_pair_pos_321  -1
    rho_7     block_pair_neg_322  1
    rho_7     block_pair_pos_323  -1
    rho_7     block_pair_neg_324  1
    rho_7     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_74  -2.5140668023439477e-02
    x_31_0    product_ub_75  -4.3054843669955919e-02
    x_31_0    onehot_31_100  1
    x_31_0    parent_nonstrict_scope_280  0.0735
    x_31_0    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_74  1
    w_31_0    product_ub_75  1
    w_31_0    normalized_mass_31_101  1
    w_31_0    full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_76  -2.5140668023439477e-02
    x_31_1    product_ub_77  -4.3054843669955919e-02
    x_31_1    onehot_31_100  1
    x_31_1    stock_lb_278  1
    x_31_1    stock_ub_279  1
    x_31_1    parent_nonstrict_scope_280  0.063
    x_31_1    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_76  1
    w_31_1    product_ub_77  1
    w_31_1    normalized_mass_31_101  1
    w_31_1    normalized_ratio_31_102  -1.4285714285714285e-01
    w_31_1    full_original_Gini_338  -1.9369047619047624e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_78  -2.5140668023439477e-02
    x_31_2    product_ub_79  -4.3054843669955919e-02
    x_31_2    onehot_31_100  1
    x_31_2    stock_lb_278  2
    x_31_2    stock_ub_279  2
    x_31_2    parent_nonstrict_scope_280  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_78  1
    w_31_2    product_ub_79  1
    w_31_2    normalized_mass_31_101  1
    w_31_2    normalized_ratio_31_102  -2.8571428571428570e-01
    w_31_2    full_original_Gini_338  -1.5583333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_80  -2.5140668023439477e-02
    x_31_3    product_ub_81  -4.3054843669955919e-02
    x_31_3    onehot_31_100  1
    x_31_3    stock_lb_278  3
    x_31_3    stock_ub_279  3
    x_31_3    parent_nonstrict_scope_280  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_80  1
    w_31_3    product_ub_81  1
    w_31_3    normalized_mass_31_101  1
    w_31_3    normalized_ratio_31_102  -4.2857142857142855e-01
    w_31_3    full_original_Gini_338  -1.2069047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_82  -2.5140668023439477e-02
    x_31_4    product_ub_83  -4.3054843669955919e-02
    x_31_4    onehot_31_100  1
    x_31_4    stock_lb_278  4
    x_31_4    stock_ub_279  4
    x_31_4    parent_nonstrict_scope_280  0.0315
    x_31_4    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_82  1
    w_31_4    product_ub_83  1
    w_31_4    normalized_mass_31_101  1
    w_31_4    normalized_ratio_31_102  -5.7142857142857140e-01
    w_31_4    full_original_Gini_338  -8.9261904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_84  -2.5140668023439477e-02
    x_31_5    product_ub_85  -4.3054843669955919e-02
    x_31_5    onehot_31_100  1
    x_31_5    stock_lb_278  5
    x_31_5    stock_ub_279  5
    x_31_5    parent_nonstrict_scope_280  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_84  1
    w_31_5    product_ub_85  1
    w_31_5    normalized_mass_31_101  1
    w_31_5    normalized_ratio_31_102  -7.1428571428571419e-01
    w_31_5    full_original_Gini_338  -6.3833333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_86  -2.5140668023439477e-02
    x_31_6    product_ub_87  -4.3054843669955919e-02
    x_31_6    onehot_31_100  1
    x_31_6    stock_lb_278  6
    x_31_6    stock_ub_279  6
    x_31_6    parent_nonstrict_scope_280  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_86  1
    w_31_6    product_ub_87  1
    w_31_6    normalized_mass_31_101  1
    w_31_6    normalized_ratio_31_102  -8.5714285714285710e-01
    w_31_6    full_original_Gini_338  -5.5023809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_88  -2.5140668023439477e-02
    x_31_7    product_ub_89  -4.3054843669955919e-02
    x_31_7    onehot_31_100  1
    x_31_7    stock_lb_278  7
    x_31_7    stock_ub_279  7
    x_31_7    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_88  1
    w_31_7    product_ub_89  1
    w_31_7    normalized_mass_31_101  1
    w_31_7    normalized_ratio_31_102  -1
    w_31_7    full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_90  -2.5140668023439477e-02
    x_31_8    product_ub_91  -4.3054843669955919e-02
    x_31_8    onehot_31_100  1
    x_31_8    stock_lb_278  8
    x_31_8    stock_ub_279  8
    x_31_8    parent_nonstrict_scope_280  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_90  1
    w_31_8    product_ub_91  1
    w_31_8    normalized_mass_31_101  1
    w_31_8    normalized_ratio_31_102  -1.1428571428571428e+00
    w_31_8    full_original_Gini_338  -8.0738095238095227e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_92  -2.5140668023439477e-02
    x_31_9    product_ub_93  -4.3054843669955919e-02
    x_31_9    onehot_31_100  1
    x_31_9    stock_lb_278  9
    x_31_9    stock_ub_279  9
    x_31_9    parent_nonstrict_scope_280  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_92  1
    w_31_9    product_ub_93  1
    w_31_9    normalized_mass_31_101  1
    w_31_9    normalized_ratio_31_102  -1.2857142857142856e+00
    w_31_9    full_original_Gini_338  -1.1488095238095230e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_94  -2.5140668023439477e-02
    x_31_10   product_ub_95  -4.3054843669955919e-02
    x_31_10   onehot_31_100  1
    x_31_10   stock_lb_278  10
    x_31_10   stock_ub_279  10
    x_31_10   parent_nonstrict_scope_280  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_94  1
    w_31_10   product_ub_95  1
    w_31_10   normalized_mass_31_101  1
    w_31_10   normalized_ratio_31_102  -1.4285714285714284e+00
    w_31_10   full_original_Gini_338  -1.5345238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_96  -2.5140668023439477e-02
    x_31_11   product_ub_97  -4.3054843669955919e-02
    x_31_11   onehot_31_100  1
    x_31_11   stock_lb_278  11
    x_31_11   stock_ub_279  11
    x_31_11   parent_nonstrict_scope_280  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_96  1
    w_31_11   product_ub_97  1
    w_31_11   normalized_mass_31_101  1
    w_31_11   normalized_ratio_31_102  -1.5714285714285714e+00
    w_31_11   full_original_Gini_338  -1.9202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_98  -2.5140668023439477e-02
    x_31_12   product_ub_99  -4.3054843669955919e-02
    x_31_12   onehot_31_100  1
    x_31_12   stock_lb_278  12
    x_31_12   stock_ub_279  12
    x_31_12   parent_nonstrict_scope_280  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_98  1
    w_31_12   product_ub_99  1
    w_31_12   normalized_mass_31_101  1
    w_31_12   normalized_ratio_31_102  -1.7142857142857142e+00
    w_31_12   full_original_Gini_338  -2.3059523809523810e+01
    rho_31    normalized_ratio_31_102  1
    rho_31    block_pair_pos_311  1
    rho_31    block_pair_neg_312  -1
    rho_31    block_pair_pos_323  1
    rho_31    block_pair_neg_324  -1
    rho_31    block_pair_pos_327  -1
    rho_31    block_pair_neg_328  1
    rho_31    block_pair_pos_329  -1
    rho_31    block_pair_neg_330  1
    rho_31    block_pair_pos_331  -1
    rho_31    block_pair_neg_332  1
    rho_31    block_pair_pos_333  -1
    rho_31    block_pair_neg_334  1
    rho_31    block_pair_pos_335  -1
    rho_31    block_pair_neg_336  1
    rho_31    normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_103  -2.5140668023439477e-02
    x_1_0     product_ub_104  -4.3054843669955919e-02
    x_1_0     onehot_1_143  1
    x_1_0     parent_nonstrict_scope_280  0.15
    x_1_0     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_103  1
    w_1_0     product_ub_104  1
    w_1_0     normalized_mass_1_144  1
    w_1_0     full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       6.0000000000000012e-02
    x_1_1     product_lb_105  -2.5140668023439477e-02
    x_1_1     product_ub_106  -4.3054843669955919e-02
    x_1_1     onehot_1_143  1
    x_1_1     stock_lb_278  1
    x_1_1     stock_ub_279  1
    x_1_1     parent_nonstrict_scope_280  0.135
    x_1_1     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_105  1
    w_1_1     product_ub_106  1
    w_1_1     normalized_mass_1_144  1
    w_1_1     normalized_ratio_1_145  -0.1
    w_1_1     full_original_Gini_338  -2.0526190476190475e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.045
    x_1_2     product_lb_107  -2.5140668023439477e-02
    x_1_2     product_ub_108  -4.3054843669955919e-02
    x_1_2     onehot_1_143  1
    x_1_2     stock_lb_278  2
    x_1_2     stock_ub_279  2
    x_1_2     parent_nonstrict_scope_280  0.12
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_107  1
    w_1_2     product_ub_108  1
    w_1_2     normalized_mass_1_144  1
    w_1_2     normalized_ratio_1_145  -0.2
    w_1_2     full_original_Gini_338  -1.7826190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       0.03
    x_1_3     product_lb_109  -2.5140668023439477e-02
    x_1_3     product_ub_110  -4.3054843669955919e-02
    x_1_3     onehot_1_143  1
    x_1_3     stock_lb_278  3
    x_1_3     stock_ub_279  3
    x_1_3     parent_nonstrict_scope_280  0.105
    x_1_3     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_109  1
    w_1_3     product_ub_110  1
    w_1_3     normalized_mass_1_144  1
    w_1_3     normalized_ratio_1_145  -3.0000000000000004e-01
    w_1_3     full_original_Gini_338  -1.5226190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       0.015
    x_1_4     product_lb_111  -2.5140668023439477e-02
    x_1_4     product_ub_112  -4.3054843669955919e-02
    x_1_4     onehot_1_143  1
    x_1_4     stock_lb_278  4
    x_1_4     stock_ub_279  4
    x_1_4     parent_nonstrict_scope_280  0.09
    x_1_4     unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_111  1
    w_1_4     product_ub_112  1
    w_1_4     normalized_mass_1_144  1
    w_1_4     normalized_ratio_1_145  -0.4
    w_1_4     full_original_Gini_338  -1.2726190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_5     product_lb_113  -2.5140668023439477e-02
    x_1_5     product_ub_114  -4.3054843669955919e-02
    x_1_5     onehot_1_143  1
    x_1_5     stock_lb_278  5
    x_1_5     stock_ub_279  5
    x_1_5     parent_nonstrict_scope_280  0.075
    x_1_5     unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_113  1
    w_1_5     product_ub_114  1
    w_1_5     normalized_mass_1_144  1
    w_1_5     normalized_ratio_1_145  -0.5
    w_1_5     full_original_Gini_338  -1.0426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -1.5000000000000013e-02
    x_1_6     product_lb_115  -2.5140668023439477e-02
    x_1_6     product_ub_116  -4.3054843669955919e-02
    x_1_6     onehot_1_143  1
    x_1_6     stock_lb_278  6
    x_1_6     stock_ub_279  6
    x_1_6     parent_nonstrict_scope_280  5.9999999999999984e-02
    x_1_6     unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_115  1
    w_1_6     product_ub_116  1
    w_1_6     normalized_mass_1_144  1
    w_1_6     normalized_ratio_1_145  -6.0000000000000009e-01
    w_1_6     full_original_Gini_338  -8.3261904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -3.0000000000000006e-02
    x_1_7     product_lb_117  -2.5140668023439477e-02
    x_1_7     product_ub_118  -4.3054843669955919e-02
    x_1_7     onehot_1_143  1
    x_1_7     stock_lb_278  7
    x_1_7     stock_ub_279  7
    x_1_7     parent_nonstrict_scope_280  4.4999999999999991e-02
    x_1_7     unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_117  1
    w_1_7     product_ub_118  1
    w_1_7     normalized_mass_1_144  1
    w_1_7     normalized_ratio_1_145  -7.0000000000000007e-01
    w_1_7     full_original_Gini_338  -6.6261904761904731e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -4.5000000000000005e-02
    x_1_8     product_lb_119  -2.5140668023439477e-02
    x_1_8     product_ub_120  -4.3054843669955919e-02
    x_1_8     onehot_1_143  1
    x_1_8     stock_lb_278  8
    x_1_8     stock_ub_279  8
    x_1_8     parent_nonstrict_scope_280  2.9999999999999992e-02
    x_1_8     unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_119  1
    w_1_8     product_ub_120  1
    w_1_8     normalized_mass_1_144  1
    w_1_8     normalized_ratio_1_145  -0.8
    w_1_8     full_original_Gini_338  -5.7404761904761923e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -0.06
    x_1_9     product_lb_121  -2.5140668023439477e-02
    x_1_9     product_ub_122  -4.3054843669955919e-02
    x_1_9     onehot_1_143  1
    x_1_9     stock_lb_278  9
    x_1_9     stock_ub_279  9
    x_1_9     parent_nonstrict_scope_280  1.4999999999999996e-02
    x_1_9     unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_121  1
    w_1_9     product_ub_122  1
    w_1_9     normalized_mass_1_144  1
    w_1_9     normalized_ratio_1_145  -0.9
    w_1_9     full_original_Gini_338  -5.3738095238095243e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -0.075
    x_1_10    product_lb_123  -2.5140668023439477e-02
    x_1_10    product_ub_124  -4.3054843669955919e-02
    x_1_10    onehot_1_143  1
    x_1_10    stock_lb_278  10
    x_1_10    stock_ub_279  10
    x_1_10    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_123  1
    w_1_10    product_ub_124  1
    w_1_10    normalized_mass_1_144  1
    w_1_10    normalized_ratio_1_145  -1
    w_1_10    full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    OBJ       -5.9999999999999984e-02
    x_1_11    product_lb_125  -2.5140668023439477e-02
    x_1_11    product_ub_126  -4.3054843669955919e-02
    x_1_11    onehot_1_143  1
    x_1_11    stock_lb_278  11
    x_1_11    stock_ub_279  11
    x_1_11    parent_nonstrict_scope_280  1.5000000000000013e-02
    x_1_11    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_125  1
    w_1_11    product_ub_126  1
    w_1_11    normalized_mass_1_144  1
    w_1_11    normalized_ratio_1_145  -1.1
    w_1_11    full_original_Gini_338  -7.1738095238095259e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       -4.4999999999999971e-02
    x_1_12    product_lb_127  -2.5140668023439477e-02
    x_1_12    product_ub_128  -4.3054843669955919e-02
    x_1_12    onehot_1_143  1
    x_1_12    stock_lb_278  12
    x_1_12    stock_ub_279  12
    x_1_12    parent_nonstrict_scope_280  3.0000000000000027e-02
    x_1_12    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_127  1
    w_1_12    product_ub_128  1
    w_1_12    normalized_mass_1_144  1
    w_1_12    normalized_ratio_1_145  -1.2000000000000002e+00
    w_1_12    full_original_Gini_338  -9.2738095238095291e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       -2.9999999999999992e-02
    x_1_13    product_lb_129  -2.5140668023439477e-02
    x_1_13    product_ub_130  -4.3054843669955919e-02
    x_1_13    onehot_1_143  1
    x_1_13    stock_lb_278  13
    x_1_13    stock_ub_279  13
    x_1_13    parent_nonstrict_scope_280  4.5000000000000005e-02
    x_1_13    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_129  1
    w_1_13    product_ub_130  1
    w_1_13    normalized_mass_1_144  1
    w_1_13    normalized_ratio_1_145  -1.3
    w_1_13    full_original_Gini_338  -1.1873809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       -1.4999999999999979e-02
    x_1_14    product_lb_131  -2.5140668023439477e-02
    x_1_14    product_ub_132  -4.3054843669955919e-02
    x_1_14    onehot_1_143  1
    x_1_14    stock_lb_278  14
    x_1_14    stock_ub_279  14
    x_1_14    parent_nonstrict_scope_280  6.0000000000000019e-02
    x_1_14    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_131  1
    w_1_14    product_ub_132  1
    w_1_14    normalized_mass_1_144  1
    w_1_14    normalized_ratio_1_145  -1.4000000000000001e+00
    w_1_14    full_original_Gini_338  -1.4573809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    product_lb_133  -2.5140668023439477e-02
    x_1_15    product_ub_134  -4.3054843669955919e-02
    x_1_15    onehot_1_143  1
    x_1_15    stock_lb_278  15
    x_1_15    stock_ub_279  15
    x_1_15    parent_nonstrict_scope_280  0.075
    x_1_15    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_133  1
    w_1_15    product_ub_134  1
    w_1_15    normalized_mass_1_144  1
    w_1_15    normalized_ratio_1_145  -1.5
    w_1_15    full_original_Gini_338  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_16    OBJ       1.5000000000000013e-02
    x_1_16    product_lb_135  -2.5140668023439477e-02
    x_1_16    product_ub_136  -4.3054843669955919e-02
    x_1_16    onehot_1_143  1
    x_1_16    stock_lb_278  16
    x_1_16    stock_ub_279  16
    x_1_16    parent_nonstrict_scope_280  9.0000000000000011e-02
    x_1_16    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_16    product_lb_135  1
    w_1_16    product_ub_136  1
    w_1_16    normalized_mass_1_144  1
    w_1_16    normalized_ratio_1_145  -1.6
    w_1_16    full_original_Gini_338  -1.9973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_17    OBJ       3.0000000000000027e-02
    x_1_17    product_lb_137  -2.5140668023439477e-02
    x_1_17    product_ub_138  -4.3054843669955919e-02
    x_1_17    onehot_1_143  1
    x_1_17    stock_lb_278  17
    x_1_17    stock_ub_279  17
    x_1_17    parent_nonstrict_scope_280  1.0500000000000002e-01
    x_1_17    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_17    product_lb_137  1
    w_1_17    product_ub_138  1
    w_1_17    normalized_mass_1_144  1
    w_1_17    normalized_ratio_1_145  -1.7000000000000002e+00
    w_1_17    full_original_Gini_338  -2.2673809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_18    OBJ       0.045
    x_1_18    product_lb_139  -2.5140668023439477e-02
    x_1_18    product_ub_140  -4.3054843669955919e-02
    x_1_18    onehot_1_143  1
    x_1_18    stock_lb_278  18
    x_1_18    stock_ub_279  18
    x_1_18    parent_nonstrict_scope_280  0.12
    x_1_18    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_18    product_lb_139  1
    w_1_18    product_ub_140  1
    w_1_18    normalized_mass_1_144  1
    w_1_18    normalized_ratio_1_145  -1.8
    w_1_18    full_original_Gini_338  -2.5373809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_19    OBJ       6.0000000000000012e-02
    x_1_19    product_lb_141  -2.5140668023439477e-02
    x_1_19    product_ub_142  -4.3054843669955919e-02
    x_1_19    onehot_1_143  1
    x_1_19    stock_lb_278  19
    x_1_19    stock_ub_279  19
    x_1_19    parent_nonstrict_scope_280  0.135
    x_1_19    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_19    product_lb_141  1
    w_1_19    product_ub_142  1
    w_1_19    normalized_mass_1_144  1
    w_1_19    normalized_ratio_1_145  -1.9000000000000001e+00
    w_1_19    full_original_Gini_338  -2.8073809523809519e+01
    rho_1     normalized_ratio_1_145  1
    rho_1     block_pair_pos_281  -1
    rho_1     block_pair_neg_282  1
    rho_1     block_pair_pos_283  -1
    rho_1     block_pair_neg_284  1
    rho_1     block_pair_pos_285  -1
    rho_1     block_pair_neg_286  1
    rho_1     block_pair_pos_287  -1
    rho_1     block_pair_neg_288  1
    rho_1     block_pair_pos_299  1
    rho_1     block_pair_neg_300  -1
    rho_1     block_pair_pos_313  1
    rho_1     block_pair_neg_314  -1
    rho_1     block_pair_pos_327  1
    rho_1     block_pair_neg_328  -1
    rho_1     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_146  -2.5140668023439477e-02
    x_2_0     product_ub_147  -4.3054843669955919e-02
    x_2_0     onehot_2_178  1
    x_2_0     parent_nonstrict_scope_280  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_146  1
    w_2_0     product_ub_147  1
    w_2_0     normalized_mass_2_179  1
    w_2_0     full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_148  -2.5140668023439477e-02
    x_2_1     product_ub_149  -4.3054843669955919e-02
    x_2_1     onehot_2_178  1
    x_2_1     stock_lb_278  1
    x_2_1     stock_ub_279  1
    x_2_1     parent_nonstrict_scope_280  0.063
    x_2_1     unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_148  1
    w_2_1     product_ub_149  1
    w_2_1     normalized_mass_2_179  1
    w_2_1     normalized_ratio_2_180  -1.4285714285714285e-01
    w_2_1     full_original_Gini_338  -1.9369047619047624e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_150  -2.5140668023439477e-02
    x_2_2     product_ub_151  -4.3054843669955919e-02
    x_2_2     onehot_2_178  1
    x_2_2     stock_lb_278  2
    x_2_2     stock_ub_279  2
    x_2_2     parent_nonstrict_scope_280  0.0525
    x_2_2     unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_150  1
    w_2_2     product_ub_151  1
    w_2_2     normalized_mass_2_179  1
    w_2_2     normalized_ratio_2_180  -2.8571428571428570e-01
    w_2_2     full_original_Gini_338  -1.5583333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_152  -2.5140668023439477e-02
    x_2_3     product_ub_153  -4.3054843669955919e-02
    x_2_3     onehot_2_178  1
    x_2_3     stock_lb_278  3
    x_2_3     stock_ub_279  3
    x_2_3     parent_nonstrict_scope_280  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_152  1
    w_2_3     product_ub_153  1
    w_2_3     normalized_mass_2_179  1
    w_2_3     normalized_ratio_2_180  -4.2857142857142855e-01
    w_2_3     full_original_Gini_338  -1.2069047619047618e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_154  -2.5140668023439477e-02
    x_2_4     product_ub_155  -4.3054843669955919e-02
    x_2_4     onehot_2_178  1
    x_2_4     stock_lb_278  4
    x_2_4     stock_ub_279  4
    x_2_4     parent_nonstrict_scope_280  0.0315
    x_2_4     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_154  1
    w_2_4     product_ub_155  1
    w_2_4     normalized_mass_2_179  1
    w_2_4     normalized_ratio_2_180  -5.7142857142857140e-01
    w_2_4     full_original_Gini_338  -8.9261904761904773e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_156  -2.5140668023439477e-02
    x_2_5     product_ub_157  -4.3054843669955919e-02
    x_2_5     onehot_2_178  1
    x_2_5     stock_lb_278  5
    x_2_5     stock_ub_279  5
    x_2_5     parent_nonstrict_scope_280  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_156  1
    w_2_5     product_ub_157  1
    w_2_5     normalized_mass_2_179  1
    w_2_5     normalized_ratio_2_180  -7.1428571428571419e-01
    w_2_5     full_original_Gini_338  -6.3833333333333329e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_158  -2.5140668023439477e-02
    x_2_6     product_ub_159  -4.3054843669955919e-02
    x_2_6     onehot_2_178  1
    x_2_6     stock_lb_278  6
    x_2_6     stock_ub_279  6
    x_2_6     parent_nonstrict_scope_280  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_158  1
    w_2_6     product_ub_159  1
    w_2_6     normalized_mass_2_179  1
    w_2_6     normalized_ratio_2_180  -8.5714285714285710e-01
    w_2_6     full_original_Gini_338  -5.5023809523809541e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_160  -2.5140668023439477e-02
    x_2_7     product_ub_161  -4.3054843669955919e-02
    x_2_7     onehot_2_178  1
    x_2_7     stock_lb_278  7
    x_2_7     stock_ub_279  7
    x_2_7     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_160  1
    w_2_7     product_ub_161  1
    w_2_7     normalized_mass_2_179  1
    w_2_7     normalized_ratio_2_180  -1
    w_2_7     full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_162  -2.5140668023439477e-02
    x_2_8     product_ub_163  -4.3054843669955919e-02
    x_2_8     onehot_2_178  1
    x_2_8     stock_lb_278  8
    x_2_8     stock_ub_279  8
    x_2_8     parent_nonstrict_scope_280  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_162  1
    w_2_8     product_ub_163  1
    w_2_8     normalized_mass_2_179  1
    w_2_8     normalized_ratio_2_180  -1.1428571428571428e+00
    w_2_8     full_original_Gini_338  -8.0738095238095227e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_164  -2.5140668023439477e-02
    x_2_9     product_ub_165  -4.3054843669955919e-02
    x_2_9     onehot_2_178  1
    x_2_9     stock_lb_278  9
    x_2_9     stock_ub_279  9
    x_2_9     parent_nonstrict_scope_280  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_164  1
    w_2_9     product_ub_165  1
    w_2_9     normalized_mass_2_179  1
    w_2_9     normalized_ratio_2_180  -1.2857142857142856e+00
    w_2_9     full_original_Gini_338  -1.1488095238095230e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_166  -2.5140668023439477e-02
    x_2_10    product_ub_167  -4.3054843669955919e-02
    x_2_10    onehot_2_178  1
    x_2_10    stock_lb_278  10
    x_2_10    stock_ub_279  10
    x_2_10    parent_nonstrict_scope_280  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_166  1
    w_2_10    product_ub_167  1
    w_2_10    normalized_mass_2_179  1
    w_2_10    normalized_ratio_2_180  -1.4285714285714284e+00
    w_2_10    full_original_Gini_338  -1.5345238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_168  -2.5140668023439477e-02
    x_2_11    product_ub_169  -4.3054843669955919e-02
    x_2_11    onehot_2_178  1
    x_2_11    stock_lb_278  11
    x_2_11    stock_ub_279  11
    x_2_11    parent_nonstrict_scope_280  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_168  1
    w_2_11    product_ub_169  1
    w_2_11    normalized_mass_2_179  1
    w_2_11    normalized_ratio_2_180  -1.5714285714285714e+00
    w_2_11    full_original_Gini_338  -1.9202380952380953e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_170  -2.5140668023439477e-02
    x_2_12    product_ub_171  -4.3054843669955919e-02
    x_2_12    onehot_2_178  1
    x_2_12    stock_lb_278  12
    x_2_12    stock_ub_279  12
    x_2_12    parent_nonstrict_scope_280  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_170  1
    w_2_12    product_ub_171  1
    w_2_12    normalized_mass_2_179  1
    w_2_12    normalized_ratio_2_180  -1.7142857142857142e+00
    w_2_12    full_original_Gini_338  -2.3059523809523810e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_172  -2.5140668023439477e-02
    x_2_13    product_ub_173  -4.3054843669955919e-02
    x_2_13    onehot_2_178  1
    x_2_13    stock_lb_278  13
    x_2_13    stock_ub_279  13
    x_2_13    parent_nonstrict_scope_280  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_172  1
    w_2_13    product_ub_173  1
    w_2_13    normalized_mass_2_179  1
    w_2_13    normalized_ratio_2_180  -1.8571428571428570e+00
    w_2_13    full_original_Gini_338  -2.6916666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_174  -2.5140668023439477e-02
    x_2_14    product_ub_175  -4.3054843669955919e-02
    x_2_14    onehot_2_178  1
    x_2_14    stock_lb_278  14
    x_2_14    stock_ub_279  14
    x_2_14    parent_nonstrict_scope_280  0.0735
    x_2_14    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_174  1
    w_2_14    product_ub_175  1
    w_2_14    normalized_mass_2_179  1
    w_2_14    normalized_ratio_2_180  -2
    w_2_14    full_original_Gini_338  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_176  -2.5140668023439477e-02
    x_2_15    product_ub_177  -4.3054843669955919e-02
    x_2_15    onehot_2_178  1
    x_2_15    stock_lb_278  15
    x_2_15    stock_ub_279  15
    x_2_15    parent_nonstrict_scope_280  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_176  1
    w_2_15    product_ub_177  1
    w_2_15    normalized_mass_2_179  1
    w_2_15    normalized_ratio_2_180  -2.1428571428571428e+00
    w_2_15    full_original_Gini_338  -3.4630952380952372e+01
    rho_2     normalized_ratio_2_180  1
    rho_2     block_pair_pos_281  1
    rho_2     block_pair_neg_282  -1
    rho_2     block_pair_pos_289  -1
    rho_2     block_pair_neg_290  1
    rho_2     block_pair_pos_291  -1
    rho_2     block_pair_neg_292  1
    rho_2     block_pair_pos_293  -1
    rho_2     block_pair_neg_294  1
    rho_2     block_pair_pos_301  1
    rho_2     block_pair_neg_302  -1
    rho_2     block_pair_pos_315  1
    rho_2     block_pair_neg_316  -1
    rho_2     block_pair_pos_329  1
    rho_2     block_pair_neg_330  -1
    rho_2     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_181  -2.5140668023439477e-02
    x_3_0     product_ub_182  -4.3054843669955919e-02
    x_3_0     onehot_3_217  1
    x_3_0     parent_nonstrict_scope_280  0.096
    x_3_0     unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_181  1
    w_3_0     product_ub_182  1
    w_3_0     normalized_mass_3_218  1
    w_3_0     full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_183  -2.5140668023439477e-02
    x_3_1     product_ub_184  -4.3054843669955919e-02
    x_3_1     onehot_3_217  1
    x_3_1     stock_lb_278  1
    x_3_1     stock_ub_279  1
    x_3_1     parent_nonstrict_scope_280  0.084
    x_3_1     unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_183  1
    w_3_1     product_ub_184  1
    w_3_1     normalized_mass_3_218  1
    w_3_1     normalized_ratio_3_219  -0.125
    w_3_1     full_original_Gini_338  -1.9851190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_185  -2.5140668023439477e-02
    x_3_2     product_ub_186  -4.3054843669955919e-02
    x_3_2     onehot_3_217  1
    x_3_2     stock_lb_278  2
    x_3_2     stock_ub_279  2
    x_3_2     parent_nonstrict_scope_280  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_185  1
    w_3_2     product_ub_186  1
    w_3_2     normalized_mass_3_218  1
    w_3_2     normalized_ratio_3_219  -0.25
    w_3_2     full_original_Gini_338  -1.6476190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_187  -2.5140668023439477e-02
    x_3_3     product_ub_188  -4.3054843669955919e-02
    x_3_3     onehot_3_217  1
    x_3_3     stock_lb_278  3
    x_3_3     stock_ub_279  3
    x_3_3     parent_nonstrict_scope_280  0.06
    x_3_3     unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_187  1
    w_3_3     product_ub_188  1
    w_3_3     normalized_mass_3_218  1
    w_3_3     normalized_ratio_3_219  -0.375
    w_3_3     full_original_Gini_338  -1.3351190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_189  -2.5140668023439477e-02
    x_3_4     product_ub_190  -4.3054843669955919e-02
    x_3_4     onehot_3_217  1
    x_3_4     stock_lb_278  4
    x_3_4     stock_ub_279  4
    x_3_4     parent_nonstrict_scope_280  0.048
    x_3_4     unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_189  1
    w_3_4     product_ub_190  1
    w_3_4     normalized_mass_3_218  1
    w_3_4     normalized_ratio_3_219  -0.5
    w_3_4     full_original_Gini_338  -1.0426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_191  -2.5140668023439477e-02
    x_3_5     product_ub_192  -4.3054843669955919e-02
    x_3_5     onehot_3_217  1
    x_3_5     stock_lb_278  5
    x_3_5     stock_ub_279  5
    x_3_5     parent_nonstrict_scope_280  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_191  1
    w_3_5     product_ub_192  1
    w_3_5     normalized_mass_3_218  1
    w_3_5     normalized_ratio_3_219  -0.625
    w_3_5     full_original_Gini_338  -7.9011904761904752e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_193  -2.5140668023439477e-02
    x_3_6     product_ub_194  -4.3054843669955919e-02
    x_3_6     onehot_3_217  1
    x_3_6     stock_lb_278  6
    x_3_6     stock_ub_279  6
    x_3_6     parent_nonstrict_scope_280  0.024
    x_3_6     unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_193  1
    w_3_6     product_ub_194  1
    w_3_6     normalized_mass_3_218  1
    w_3_6     normalized_ratio_3_219  -0.75
    w_3_6     full_original_Gini_338  -5.9904761904761905e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_195  -2.5140668023439477e-02
    x_3_7     product_ub_196  -4.3054843669955919e-02
    x_3_7     onehot_3_217  1
    x_3_7     stock_lb_278  7
    x_3_7     stock_ub_279  7
    x_3_7     parent_nonstrict_scope_280  0.012
    x_3_7     unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_195  1
    w_3_7     product_ub_196  1
    w_3_7     normalized_mass_3_218  1
    w_3_7     normalized_ratio_3_219  -0.875
    w_3_7     full_original_Gini_338  -5.4488095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_197  -2.5140668023439477e-02
    x_3_8     product_ub_198  -4.3054843669955919e-02
    x_3_8     onehot_3_217  1
    x_3_8     stock_lb_278  8
    x_3_8     stock_ub_279  8
    x_3_8     unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_197  1
    w_3_8     product_ub_198  1
    w_3_8     normalized_mass_3_218  1
    w_3_8     normalized_ratio_3_219  -1
    w_3_8     full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_199  -2.5140668023439477e-02
    x_3_9     product_ub_200  -4.3054843669955919e-02
    x_3_9     onehot_3_217  1
    x_3_9     stock_lb_278  9
    x_3_9     stock_ub_279  9
    x_3_9     parent_nonstrict_scope_280  0.012
    x_3_9     unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_199  1
    w_3_9     product_ub_200  1
    w_3_9     normalized_mass_3_218  1
    w_3_9     normalized_ratio_3_219  -1.125
    w_3_9     full_original_Gini_338  -7.6988095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_201  -2.5140668023439477e-02
    x_3_10    product_ub_202  -4.3054843669955919e-02
    x_3_10    onehot_3_217  1
    x_3_10    stock_lb_278  10
    x_3_10    stock_ub_279  10
    x_3_10    parent_nonstrict_scope_280  0.024
    x_3_10    unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_201  1
    w_3_10    product_ub_202  1
    w_3_10    normalized_mass_3_218  1
    w_3_10    normalized_ratio_3_219  -1.25
    w_3_10    full_original_Gini_338  -1.0523809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_203  -2.5140668023439477e-02
    x_3_11    product_ub_204  -4.3054843669955919e-02
    x_3_11    onehot_3_217  1
    x_3_11    stock_lb_278  11
    x_3_11    stock_ub_279  11
    x_3_11    parent_nonstrict_scope_280  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_203  1
    w_3_11    product_ub_204  1
    w_3_11    normalized_mass_3_218  1
    w_3_11    normalized_ratio_3_219  -1.375
    w_3_11    full_original_Gini_338  -1.3898809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_205  -2.5140668023439477e-02
    x_3_12    product_ub_206  -4.3054843669955919e-02
    x_3_12    onehot_3_217  1
    x_3_12    stock_lb_278  12
    x_3_12    stock_ub_279  12
    x_3_12    parent_nonstrict_scope_280  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_205  1
    w_3_12    product_ub_206  1
    w_3_12    normalized_mass_3_218  1
    w_3_12    normalized_ratio_3_219  -1.5
    w_3_12    full_original_Gini_338  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_207  -2.5140668023439477e-02
    x_3_13    product_ub_208  -4.3054843669955919e-02
    x_3_13    onehot_3_217  1
    x_3_13    stock_lb_278  13
    x_3_13    stock_ub_279  13
    x_3_13    parent_nonstrict_scope_280  0.06
    x_3_13    unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_207  1
    w_3_13    product_ub_208  1
    w_3_13    normalized_mass_3_218  1
    w_3_13    normalized_ratio_3_219  -1.625
    w_3_13    full_original_Gini_338  -2.0648809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_209  -2.5140668023439477e-02
    x_3_14    product_ub_210  -4.3054843669955919e-02
    x_3_14    onehot_3_217  1
    x_3_14    stock_lb_278  14
    x_3_14    stock_ub_279  14
    x_3_14    parent_nonstrict_scope_280  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_209  1
    w_3_14    product_ub_210  1
    w_3_14    normalized_mass_3_218  1
    w_3_14    normalized_ratio_3_219  -1.75
    w_3_14    full_original_Gini_338  -2.4023809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_211  -2.5140668023439477e-02
    x_3_15    product_ub_212  -4.3054843669955919e-02
    x_3_15    onehot_3_217  1
    x_3_15    stock_lb_278  15
    x_3_15    stock_ub_279  15
    x_3_15    parent_nonstrict_scope_280  0.084
    x_3_15    unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_211  1
    w_3_15    product_ub_212  1
    w_3_15    normalized_mass_3_218  1
    w_3_15    normalized_ratio_3_219  -1.875
    w_3_15    full_original_Gini_338  -2.7398809523809518e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_213  -2.5140668023439477e-02
    x_3_16    product_ub_214  -4.3054843669955919e-02
    x_3_16    onehot_3_217  1
    x_3_16    stock_lb_278  16
    x_3_16    stock_ub_279  16
    x_3_16    parent_nonstrict_scope_280  0.096
    x_3_16    unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_213  1
    w_3_16    product_ub_214  1
    w_3_16    normalized_mass_3_218  1
    w_3_16    normalized_ratio_3_219  -2
    w_3_16    full_original_Gini_338  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_215  -2.5140668023439477e-02
    x_3_17    product_ub_216  -4.3054843669955919e-02
    x_3_17    onehot_3_217  1
    x_3_17    stock_lb_278  17
    x_3_17    stock_ub_279  17
    x_3_17    parent_nonstrict_scope_280  0.108
    x_3_17    unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_215  1
    w_3_17    product_ub_216  1
    w_3_17    normalized_mass_3_218  1
    w_3_17    normalized_ratio_3_219  -2.125
    w_3_17    full_original_Gini_338  -3.4148809523809526e+01
    rho_3     normalized_ratio_3_219  1
    rho_3     block_pair_pos_283  1
    rho_3     block_pair_neg_284  -1
    rho_3     block_pair_pos_289  1
    rho_3     block_pair_neg_290  -1
    rho_3     block_pair_pos_295  -1
    rho_3     block_pair_neg_296  1
    rho_3     block_pair_pos_297  -1
    rho_3     block_pair_neg_298  1
    rho_3     block_pair_pos_303  1
    rho_3     block_pair_neg_304  -1
    rho_3     block_pair_pos_317  1
    rho_3     block_pair_neg_318  -1
    rho_3     block_pair_pos_331  1
    rho_3     block_pair_neg_332  -1
    rho_3     normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_220  -2.5140668023439477e-02
    x_16_0    product_ub_221  -4.3054843669955919e-02
    x_16_0    onehot_16_246  1
    x_16_0    parent_nonstrict_scope_280  0.054
    x_16_0    unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_220  1
    w_16_0    product_ub_221  1
    w_16_0    normalized_mass_16_247  1
    w_16_0    full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_222  -2.5140668023439477e-02
    x_16_1    product_ub_223  -4.3054843669955919e-02
    x_16_1    onehot_16_246  1
    x_16_1    stock_lb_278  1
    x_16_1    stock_ub_279  1
    x_16_1    parent_nonstrict_scope_280  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_222  1
    w_16_1    product_ub_223  1
    w_16_1    normalized_mass_16_247  1
    w_16_1    normalized_ratio_16_248  -1.6666666666666666e-01
    w_16_1    full_original_Gini_338  -1.8726190476190478e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_224  -2.5140668023439477e-02
    x_16_2    product_ub_225  -4.3054843669955919e-02
    x_16_2    onehot_16_246  1
    x_16_2    stock_lb_278  2
    x_16_2    stock_ub_279  2
    x_16_2    parent_nonstrict_scope_280  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_224  1
    w_16_2    product_ub_225  1
    w_16_2    normalized_mass_16_247  1
    w_16_2    normalized_ratio_16_248  -3.3333333333333331e-01
    w_16_2    full_original_Gini_338  -1.4392857142857144e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_226  -2.5140668023439477e-02
    x_16_3    product_ub_227  -4.3054843669955919e-02
    x_16_3    onehot_16_246  1
    x_16_3    stock_lb_278  3
    x_16_3    stock_ub_279  3
    x_16_3    parent_nonstrict_scope_280  0.027
    x_16_3    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_226  1
    w_16_3    product_ub_227  1
    w_16_3    normalized_mass_16_247  1
    w_16_3    normalized_ratio_16_248  -0.5
    w_16_3    full_original_Gini_338  -1.0426190476190476e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_228  -2.5140668023439477e-02
    x_16_4    product_ub_229  -4.3054843669955919e-02
    x_16_4    onehot_16_246  1
    x_16_4    stock_lb_278  4
    x_16_4    stock_ub_279  4
    x_16_4    parent_nonstrict_scope_280  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_228  1
    w_16_4    product_ub_229  1
    w_16_4    normalized_mass_16_247  1
    w_16_4    normalized_ratio_16_248  -6.6666666666666663e-01
    w_16_4    full_original_Gini_338  -7.1928571428571413e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_230  -2.5140668023439477e-02
    x_16_5    product_ub_231  -4.3054843669955919e-02
    x_16_5    onehot_16_246  1
    x_16_5    stock_lb_278  5
    x_16_5    stock_ub_279  5
    x_16_5    parent_nonstrict_scope_280  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_230  1
    w_16_5    product_ub_231  1
    w_16_5    normalized_mass_16_247  1
    w_16_5    normalized_ratio_16_248  -8.3333333333333326e-01
    w_16_5    full_original_Gini_338  -5.5738095238095262e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_232  -2.5140668023439477e-02
    x_16_6    product_ub_233  -4.3054843669955919e-02
    x_16_6    onehot_16_246  1
    x_16_6    stock_lb_278  6
    x_16_6    stock_ub_279  6
    x_16_6    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_232  1
    w_16_6    product_ub_233  1
    w_16_6    normalized_mass_16_247  1
    w_16_6    normalized_ratio_16_248  -1
    w_16_6    full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_234  -2.5140668023439477e-02
    x_16_7    product_ub_235  -4.3054843669955919e-02
    x_16_7    onehot_16_246  1
    x_16_7    stock_lb_278  7
    x_16_7    stock_ub_279  7
    x_16_7    parent_nonstrict_scope_280  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_234  1
    w_16_7    product_ub_235  1
    w_16_7    normalized_mass_16_247  1
    w_16_7    normalized_ratio_16_248  -1.1666666666666665e+00
    w_16_7    full_original_Gini_338  -8.57380952380952
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_236  -2.5140668023439477e-02
    x_16_8    product_ub_237  -4.3054843669955919e-02
    x_16_8    onehot_16_246  1
    x_16_8    stock_lb_278  8
    x_16_8    stock_ub_279  8
    x_16_8    parent_nonstrict_scope_280  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_236  1
    w_16_8    product_ub_237  1
    w_16_8    normalized_mass_16_247  1
    w_16_8    normalized_ratio_16_248  -1.3333333333333333e+00
    w_16_8    full_original_Gini_338  -1.2773809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_238  -2.5140668023439477e-02
    x_16_9    product_ub_239  -4.3054843669955919e-02
    x_16_9    onehot_16_246  1
    x_16_9    stock_lb_278  9
    x_16_9    stock_ub_279  9
    x_16_9    parent_nonstrict_scope_280  0.027
    x_16_9    unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_238  1
    w_16_9    product_ub_239  1
    w_16_9    normalized_mass_16_247  1
    w_16_9    normalized_ratio_16_248  -1.5
    w_16_9    full_original_Gini_338  -1.7273809523809526e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_240  -2.5140668023439477e-02
    x_16_10   product_ub_241  -4.3054843669955919e-02
    x_16_10   onehot_16_246  1
    x_16_10   stock_lb_278  10
    x_16_10   stock_ub_279  10
    x_16_10   parent_nonstrict_scope_280  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_443  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_240  1
    w_16_10   product_ub_241  1
    w_16_10   normalized_mass_16_247  1
    w_16_10   normalized_ratio_16_248  -1.6666666666666665e+00
    w_16_10   full_original_Gini_338  -2.1773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_242  -2.5140668023439477e-02
    x_16_11   product_ub_243  -4.3054843669955919e-02
    x_16_11   onehot_16_246  1
    x_16_11   stock_lb_278  11
    x_16_11   stock_ub_279  11
    x_16_11   parent_nonstrict_scope_280  0.045
    x_16_11   unique_nonzero_owner_444  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_242  1
    w_16_11   product_ub_243  1
    w_16_11   normalized_mass_16_247  1
    w_16_11   normalized_ratio_16_248  -1.8333333333333333e+00
    w_16_11   full_original_Gini_338  -2.6273809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_244  -2.5140668023439477e-02
    x_16_12   product_ub_245  -4.3054843669955919e-02
    x_16_12   onehot_16_246  1
    x_16_12   stock_lb_278  12
    x_16_12   stock_ub_279  12
    x_16_12   parent_nonstrict_scope_280  0.054
    x_16_12   unique_nonzero_owner_445  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_244  1
    w_16_12   product_ub_245  1
    w_16_12   normalized_mass_16_247  1
    w_16_12   normalized_ratio_16_248  -2
    w_16_12   full_original_Gini_338  -3.0773809523809522e+01
    rho_16    normalized_ratio_16_248  1
    rho_16    block_pair_pos_287  1
    rho_16    block_pair_neg_288  -1
    rho_16    block_pair_pos_293  1
    rho_16    block_pair_neg_294  -1
    rho_16    block_pair_pos_297  1
    rho_16    block_pair_neg_298  -1
    rho_16    block_pair_pos_309  1
    rho_16    block_pair_neg_310  -1
    rho_16    block_pair_pos_321  1
    rho_16    block_pair_neg_322  -1
    rho_16    block_pair_pos_325  -1
    rho_16    block_pair_neg_326  1
    rho_16    block_pair_pos_335  1
    rho_16    block_pair_neg_336  -1
    rho_16    normalization_337  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       1.1249999999999993e-02
    x_11_0    product_lb_249  -2.5140668023439477e-02
    x_11_0    product_ub_250  -4.3054843669955919e-02
    x_11_0    onehot_11_275  1
    x_11_0    parent_nonstrict_scope_280  0.0375
    x_11_0    unique_nonzero_owner_446  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_249  1
    w_11_0    product_ub_250  1
    w_11_0    normalized_mass_11_276  1
    w_11_0    full_original_Gini_338  -2.3226190476190482e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7499999999999929e-03
    x_11_1    product_lb_251  -2.5140668023439477e-02
    x_11_1    product_ub_252  -4.3054843669955919e-02
    x_11_1    onehot_11_275  1
    x_11_1    stock_lb_278  1
    x_11_1    stock_ub_279  1
    x_11_1    parent_nonstrict_scope_280  0.03
    x_11_1    unique_nonzero_owner_447  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_251  1
    w_11_1    product_ub_252  1
    w_11_1    normalized_mass_11_276  1
    w_11_1    normalized_ratio_11_277  -0.2
    w_11_1    full_original_Gini_338  -1.7826190476190479e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       -3.7500000000000068e-03
    x_11_2    product_lb_253  -2.5140668023439477e-02
    x_11_2    product_ub_254  -4.3054843669955919e-02
    x_11_2    onehot_11_275  1
    x_11_2    stock_lb_278  2
    x_11_2    stock_ub_279  2
    x_11_2    parent_nonstrict_scope_280  0.0225
    x_11_2    unique_nonzero_owner_448  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_253  1
    w_11_2    product_ub_254  1
    w_11_2    normalized_mass_11_276  1
    w_11_2    normalized_ratio_11_277  -0.4
    w_11_2    full_original_Gini_338  -1.2726190476190474e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       -1.1250000000000010e-02
    x_11_3    product_lb_255  -2.5140668023439477e-02
    x_11_3    product_ub_256  -4.3054843669955919e-02
    x_11_3    onehot_11_275  1
    x_11_3    stock_lb_278  3
    x_11_3    stock_ub_279  3
    x_11_3    parent_nonstrict_scope_280  1.4999999999999996e-02
    x_11_3    unique_nonzero_owner_449  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_255  1
    w_11_3    product_ub_256  1
    w_11_3    normalized_mass_11_276  1
    w_11_3    normalized_ratio_11_277  -6.0000000000000009e-01
    w_11_3    full_original_Gini_338  -8.3261904761904759e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    OBJ       -1.8750000000000010e-02
    x_11_4    product_lb_257  -2.5140668023439477e-02
    x_11_4    product_ub_258  -4.3054843669955919e-02
    x_11_4    onehot_11_275  1
    x_11_4    stock_lb_278  4
    x_11_4    stock_ub_279  4
    x_11_4    parent_nonstrict_scope_280  7.4999999999999980e-03
    x_11_4    unique_nonzero_owner_450  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_257  1
    w_11_4    product_ub_258  1
    w_11_4    normalized_mass_11_276  1
    w_11_4    normalized_ratio_11_277  -0.8
    w_11_4    full_original_Gini_338  -5.7404761904761923e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -2.6250000000000006e-02
    x_11_5    product_lb_259  -2.5140668023439477e-02
    x_11_5    product_ub_260  -4.3054843669955919e-02
    x_11_5    onehot_11_275  1
    x_11_5    stock_lb_278  5
    x_11_5    stock_ub_279  5
    x_11_5    unique_nonzero_owner_451  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_259  1
    w_11_5    product_ub_260  1
    w_11_5    normalized_mass_11_276  1
    w_11_5    normalized_ratio_11_277  -1
    w_11_5    full_original_Gini_338  -5.0738095238095244e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -0.01875
    x_11_6    product_lb_261  -2.5140668023439477e-02
    x_11_6    product_ub_262  -4.3054843669955919e-02
    x_11_6    onehot_11_275  1
    x_11_6    stock_lb_278  6
    x_11_6    stock_ub_279  6
    x_11_6    parent_nonstrict_scope_280  7.5000000000000067e-03
    x_11_6    unique_nonzero_owner_452  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_261  1
    w_11_6    product_ub_262  1
    w_11_6    normalized_mass_11_276  1
    w_11_6    normalized_ratio_11_277  -1.2000000000000002e+00
    w_11_6    full_original_Gini_338  -9.2738095238095291e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -1.1250000000000001e-02
    x_11_7    product_lb_263  -2.5140668023439477e-02
    x_11_7    product_ub_264  -4.3054843669955919e-02
    x_11_7    onehot_11_275  1
    x_11_7    stock_lb_278  7
    x_11_7    stock_ub_279  7
    x_11_7    parent_nonstrict_scope_280  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_263  1
    w_11_7    product_ub_264  1
    w_11_7    normalized_mass_11_276  1
    w_11_7    normalized_ratio_11_277  -1.4000000000000001e+00
    w_11_7    full_original_Gini_338  -1.4573809523809528e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -3.7500000000000033e-03
    x_11_8    product_lb_265  -2.5140668023439477e-02
    x_11_8    product_ub_266  -4.3054843669955919e-02
    x_11_8    onehot_11_275  1
    x_11_8    stock_lb_278  8
    x_11_8    stock_ub_279  8
    x_11_8    parent_nonstrict_scope_280  2.2500000000000003e-02
    x_11_8    unique_nonzero_owner_453  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_265  1
    w_11_8    product_ub_266  1
    w_11_8    normalized_mass_11_276  1
    w_11_8    normalized_ratio_11_277  -1.6
    w_11_8    full_original_Gini_338  -1.9973809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       3.7499999999999929e-03
    x_11_9    product_lb_267  -2.5140668023439477e-02
    x_11_9    product_ub_268  -4.3054843669955919e-02
    x_11_9    onehot_11_275  1
    x_11_9    stock_lb_278  9
    x_11_9    stock_ub_279  9
    x_11_9    parent_nonstrict_scope_280  0.03
    x_11_9    unique_nonzero_owner_454  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_267  1
    w_11_9    product_ub_268  1
    w_11_9    normalized_mass_11_276  1
    w_11_9    normalized_ratio_11_277  -1.8
    w_11_9    full_original_Gini_338  -2.5373809523809530e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       1.1249999999999993e-02
    x_11_10   product_lb_269  -2.5140668023439477e-02
    x_11_10   product_ub_270  -4.3054843669955919e-02
    x_11_10   onehot_11_275  1
    x_11_10   stock_lb_278  10
    x_11_10   stock_ub_279  10
    x_11_10   parent_nonstrict_scope_280  0.0375
    x_11_10   unique_nonzero_owner_455  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_269  1
    w_11_10   product_ub_270  1
    w_11_10   normalized_mass_11_276  1
    w_11_10   normalized_ratio_11_277  -2
    w_11_10   full_original_Gini_338  -3.0773809523809522e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       0.01875
    x_11_11   product_lb_271  -2.5140668023439477e-02
    x_11_11   product_ub_272  -4.3054843669955919e-02
    x_11_11   onehot_11_275  1
    x_11_11   stock_lb_278  11
    x_11_11   stock_ub_279  11
    x_11_11   parent_nonstrict_scope_280  4.5000000000000005e-02
    x_11_11   unique_nonzero_owner_456  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_271  1
    w_11_11   product_ub_272  1
    w_11_11   normalized_mass_11_276  1
    w_11_11   normalized_ratio_11_277  -2.2
    w_11_11   full_original_Gini_338  -3.6173809523809524e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_12   OBJ       2.6250000000000006e-02
    x_11_12   product_lb_273  -2.5140668023439477e-02
    x_11_12   product_ub_274  -4.3054843669955919e-02
    x_11_12   onehot_11_275  1
    x_11_12   stock_lb_278  12
    x_11_12   stock_ub_279  12
    x_11_12   parent_nonstrict_scope_280  5.2500000000000012e-02
    x_11_12   unique_nonzero_owner_457  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_273  1
    w_11_12   product_ub_274  1
    w_11_12   normalized_mass_11_276  1
    w_11_12   normalized_ratio_11_277  -2.4000000000000004e+00
    w_11_12   full_original_Gini_338  -4.1573809523809516e+01
    rho_11    normalized_ratio_11_277  1
    rho_11    block_pair_pos_285  1
    rho_11    block_pair_neg_286  -1
    rho_11    block_pair_pos_291  1
    rho_11    block_pair_neg_292  -1
    rho_11    block_pair_pos_295  1
    rho_11    block_pair_neg_296  -1
    rho_11    block_pair_pos_307  1
    rho_11    block_pair_neg_308  -1
    rho_11    block_pair_pos_319  1
    rho_11    block_pair_neg_320  -1
    rho_11    block_pair_pos_325  1
    rho_11    block_pair_neg_326  -1
    rho_11    block_pair_pos_333  1
    rho_11    block_pair_neg_334  -1
    rho_11    normalization_337  1
    a_4_7     block_pair_pos_305  1
    a_4_7     block_pair_neg_306  1
    a_4_7     full_original_Gini_338  -1
    a_4_31    block_pair_pos_311  1
    a_4_31    block_pair_neg_312  1
    a_4_31    full_original_Gini_338  -1
    a_4_1     block_pair_pos_299  1
    a_4_1     block_pair_neg_300  1
    a_4_1     full_original_Gini_338  -1
    a_4_2     block_pair_pos_301  1
    a_4_2     block_pair_neg_302  1
    a_4_2     full_original_Gini_338  -1
    a_4_3     block_pair_pos_303  1
    a_4_3     block_pair_neg_304  1
    a_4_3     full_original_Gini_338  -1
    a_4_16    block_pair_pos_309  1
    a_4_16    block_pair_neg_310  1
    a_4_16    full_original_Gini_338  -1
    a_4_11    block_pair_pos_307  1
    a_4_11    block_pair_neg_308  1
    a_4_11    full_original_Gini_338  -1
    a_7_31    block_pair_pos_323  1
    a_7_31    block_pair_neg_324  1
    a_7_31    full_original_Gini_338  -1
    a_7_1     block_pair_pos_313  1
    a_7_1     block_pair_neg_314  1
    a_7_1     full_original_Gini_338  -1
    a_7_2     block_pair_pos_315  1
    a_7_2     block_pair_neg_316  1
    a_7_2     full_original_Gini_338  -1
    a_7_3     block_pair_pos_317  1
    a_7_3     block_pair_neg_318  1
    a_7_3     full_original_Gini_338  -1
    a_7_16    block_pair_pos_321  1
    a_7_16    block_pair_neg_322  1
    a_7_16    full_original_Gini_338  -1
    a_7_11    block_pair_pos_319  1
    a_7_11    block_pair_neg_320  1
    a_7_11    full_original_Gini_338  -1
    a_31_1    block_pair_pos_327  1
    a_31_1    block_pair_neg_328  1
    a_31_1    full_original_Gini_338  -1
    a_31_2    block_pair_pos_329  1
    a_31_2    block_pair_neg_330  1
    a_31_2    full_original_Gini_338  -1
    a_31_3    block_pair_pos_331  1
    a_31_3    block_pair_neg_332  1
    a_31_3    full_original_Gini_338  -1
    a_31_16   block_pair_pos_335  1
    a_31_16   block_pair_neg_336  1
    a_31_16   full_original_Gini_338  -1
    a_31_11   block_pair_pos_333  1
    a_31_11   block_pair_neg_334  1
    a_31_11   full_original_Gini_338  -1
    a_1_2     block_pair_pos_281  1
    a_1_2     block_pair_neg_282  1
    a_1_2     full_original_Gini_338  -1
    a_1_3     block_pair_pos_283  1
    a_1_3     block_pair_neg_284  1
    a_1_3     full_original_Gini_338  -1
    a_1_16    block_pair_pos_287  1
    a_1_16    block_pair_neg_288  1
    a_1_16    full_original_Gini_338  -1
    a_1_11    block_pair_pos_285  1
    a_1_11    block_pair_neg_286  1
    a_1_11    full_original_Gini_338  -1
    a_2_3     block_pair_pos_289  1
    a_2_3     block_pair_neg_290  1
    a_2_3     full_original_Gini_338  -1
    a_2_16    block_pair_pos_293  1
    a_2_16    block_pair_neg_294  1
    a_2_16    full_original_Gini_338  -1
    a_2_11    block_pair_pos_291  1
    a_2_11    block_pair_neg_292  1
    a_2_11    full_original_Gini_338  -1
    a_3_16    block_pair_pos_297  1
    a_3_16    block_pair_neg_298  1
    a_3_16    full_original_Gini_338  -1
    a_3_11    block_pair_pos_295  1
    a_3_11    block_pair_neg_296  1
    a_3_11    full_original_Gini_338  -1
    a_16_11   block_pair_pos_325  1
    a_16_11   block_pair_neg_326  1
    a_16_11   full_original_Gini_338  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_4_0  unique_nonzero_owner_339  1
    service_0_4_0  service_visit_def_838  1
    service_0_4_0  free_load_conservation_839  -11
    service_0_4_0  original_T_including_depot_unload_886  1320
    service_0_4_1  unique_nonzero_owner_340  1
    service_0_4_1  service_visit_def_838  1
    service_0_4_1  free_load_conservation_839  -10
    service_0_4_1  original_T_including_depot_unload_886  1200
    service_0_4_2  unique_nonzero_owner_341  1
    service_0_4_2  service_visit_def_838  1
    service_0_4_2  free_load_conservation_839  -9
    service_0_4_2  original_T_including_depot_unload_886  1080
    service_0_4_3  unique_nonzero_owner_342  1
    service_0_4_3  service_visit_def_838  1
    service_0_4_3  free_load_conservation_839  -8
    service_0_4_3  original_T_including_depot_unload_886  960
    service_0_4_4  unique_nonzero_owner_343  1
    service_0_4_4  service_visit_def_838  1
    service_0_4_4  free_load_conservation_839  -7
    service_0_4_4  original_T_including_depot_unload_886  840
    service_0_4_5  unique_nonzero_owner_344  1
    service_0_4_5  service_visit_def_838  1
    service_0_4_5  free_load_conservation_839  -6
    service_0_4_5  original_T_including_depot_unload_886  720
    service_0_4_6  unique_nonzero_owner_345  1
    service_0_4_6  service_visit_def_838  1
    service_0_4_6  free_load_conservation_839  -5
    service_0_4_6  original_T_including_depot_unload_886  600
    service_0_4_7  unique_nonzero_owner_346  1
    service_0_4_7  service_visit_def_838  1
    service_0_4_7  free_load_conservation_839  -4
    service_0_4_7  original_T_including_depot_unload_886  480
    service_0_4_8  unique_nonzero_owner_347  1
    service_0_4_8  service_visit_def_838  1
    service_0_4_8  free_load_conservation_839  -3
    service_0_4_8  original_T_including_depot_unload_886  360
    service_0_4_9  unique_nonzero_owner_348  1
    service_0_4_9  service_visit_def_838  1
    service_0_4_9  free_load_conservation_839  -2
    service_0_4_9  original_T_including_depot_unload_886  240
    service_0_4_10  unique_nonzero_owner_349  1
    service_0_4_10  service_visit_def_838  1
    service_0_4_10  free_load_conservation_839  -1
    service_0_4_10  original_T_including_depot_unload_886  120
    service_0_4_12  unique_nonzero_owner_350  1
    service_0_4_12  service_visit_def_838  1
    service_0_4_12  free_load_conservation_839  1
    service_0_4_13  unique_nonzero_owner_351  1
    service_0_4_13  service_visit_def_838  1
    service_0_4_13  free_load_conservation_839  2
    service_0_4_14  unique_nonzero_owner_352  1
    service_0_4_14  service_visit_def_838  1
    service_0_4_14  free_load_conservation_839  3
    service_0_4_15  unique_nonzero_owner_353  1
    service_0_4_15  service_visit_def_838  1
    service_0_4_15  free_load_conservation_839  4
    service_1_4_0  unique_nonzero_owner_339  1
    service_1_4_0  service_visit_def_1267  1
    service_1_4_0  free_load_conservation_1268  -11
    service_1_4_0  original_T_including_depot_unload_1315  1320
    service_1_4_1  unique_nonzero_owner_340  1
    service_1_4_1  service_visit_def_1267  1
    service_1_4_1  free_load_conservation_1268  -10
    service_1_4_1  original_T_including_depot_unload_1315  1200
    service_1_4_2  unique_nonzero_owner_341  1
    service_1_4_2  service_visit_def_1267  1
    service_1_4_2  free_load_conservation_1268  -9
    service_1_4_2  original_T_including_depot_unload_1315  1080
    service_1_4_3  unique_nonzero_owner_342  1
    service_1_4_3  service_visit_def_1267  1
    service_1_4_3  free_load_conservation_1268  -8
    service_1_4_3  original_T_including_depot_unload_1315  960
    service_1_4_4  unique_nonzero_owner_343  1
    service_1_4_4  service_visit_def_1267  1
    service_1_4_4  free_load_conservation_1268  -7
    service_1_4_4  original_T_including_depot_unload_1315  840
    service_1_4_5  unique_nonzero_owner_344  1
    service_1_4_5  service_visit_def_1267  1
    service_1_4_5  free_load_conservation_1268  -6
    service_1_4_5  original_T_including_depot_unload_1315  720
    service_1_4_6  unique_nonzero_owner_345  1
    service_1_4_6  service_visit_def_1267  1
    service_1_4_6  free_load_conservation_1268  -5
    service_1_4_6  original_T_including_depot_unload_1315  600
    service_1_4_7  unique_nonzero_owner_346  1
    service_1_4_7  service_visit_def_1267  1
    service_1_4_7  free_load_conservation_1268  -4
    service_1_4_7  original_T_including_depot_unload_1315  480
    service_1_4_8  unique_nonzero_owner_347  1
    service_1_4_8  service_visit_def_1267  1
    service_1_4_8  free_load_conservation_1268  -3
    service_1_4_8  original_T_including_depot_unload_1315  360
    service_1_4_9  unique_nonzero_owner_348  1
    service_1_4_9  service_visit_def_1267  1
    service_1_4_9  free_load_conservation_1268  -2
    service_1_4_9  original_T_including_depot_unload_1315  240
    service_1_4_10  unique_nonzero_owner_349  1
    service_1_4_10  service_visit_def_1267  1
    service_1_4_10  free_load_conservation_1268  -1
    service_1_4_10  original_T_including_depot_unload_1315  120
    service_1_4_12  unique_nonzero_owner_350  1
    service_1_4_12  service_visit_def_1267  1
    service_1_4_12  free_load_conservation_1268  1
    service_1_4_13  unique_nonzero_owner_351  1
    service_1_4_13  service_visit_def_1267  1
    service_1_4_13  free_load_conservation_1268  2
    service_1_4_14  unique_nonzero_owner_352  1
    service_1_4_14  service_visit_def_1267  1
    service_1_4_14  free_load_conservation_1268  3
    service_1_4_15  unique_nonzero_owner_353  1
    service_1_4_15  service_visit_def_1267  1
    service_1_4_15  free_load_conservation_1268  4
    service_2_4_0  unique_nonzero_owner_339  1
    service_2_4_0  service_visit_def_1586  1
    service_2_4_0  free_load_conservation_1587  -11
    service_2_4_0  original_T_including_depot_unload_1632  1320
    service_2_4_1  unique_nonzero_owner_340  1
    service_2_4_1  service_visit_def_1586  1
    service_2_4_1  free_load_conservation_1587  -10
    service_2_4_1  original_T_including_depot_unload_1632  1200
    service_2_4_2  unique_nonzero_owner_341  1
    service_2_4_2  service_visit_def_1586  1
    service_2_4_2  free_load_conservation_1587  -9
    service_2_4_2  original_T_including_depot_unload_1632  1080
    service_2_4_3  unique_nonzero_owner_342  1
    service_2_4_3  service_visit_def_1586  1
    service_2_4_3  free_load_conservation_1587  -8
    service_2_4_3  original_T_including_depot_unload_1632  960
    service_2_4_4  unique_nonzero_owner_343  1
    service_2_4_4  service_visit_def_1586  1
    service_2_4_4  free_load_conservation_1587  -7
    service_2_4_4  original_T_including_depot_unload_1632  840
    service_2_4_5  unique_nonzero_owner_344  1
    service_2_4_5  service_visit_def_1586  1
    service_2_4_5  free_load_conservation_1587  -6
    service_2_4_5  original_T_including_depot_unload_1632  720
    service_2_4_6  unique_nonzero_owner_345  1
    service_2_4_6  service_visit_def_1586  1
    service_2_4_6  free_load_conservation_1587  -5
    service_2_4_6  original_T_including_depot_unload_1632  600
    service_2_4_7  unique_nonzero_owner_346  1
    service_2_4_7  service_visit_def_1586  1
    service_2_4_7  free_load_conservation_1587  -4
    service_2_4_7  original_T_including_depot_unload_1632  480
    service_2_4_8  unique_nonzero_owner_347  1
    service_2_4_8  service_visit_def_1586  1
    service_2_4_8  free_load_conservation_1587  -3
    service_2_4_8  original_T_including_depot_unload_1632  360
    service_2_4_9  unique_nonzero_owner_348  1
    service_2_4_9  service_visit_def_1586  1
    service_2_4_9  free_load_conservation_1587  -2
    service_2_4_9  original_T_including_depot_unload_1632  240
    service_2_4_10  unique_nonzero_owner_349  1
    service_2_4_10  service_visit_def_1586  1
    service_2_4_10  free_load_conservation_1587  -1
    service_2_4_10  original_T_including_depot_unload_1632  120
    service_2_4_12  unique_nonzero_owner_350  1
    service_2_4_12  service_visit_def_1586  1
    service_2_4_12  free_load_conservation_1587  1
    service_2_4_13  unique_nonzero_owner_351  1
    service_2_4_13  service_visit_def_1586  1
    service_2_4_13  free_load_conservation_1587  2
    service_2_4_14  unique_nonzero_owner_352  1
    service_2_4_14  service_visit_def_1586  1
    service_2_4_14  free_load_conservation_1587  3
    service_2_4_15  unique_nonzero_owner_353  1
    service_2_4_15  service_visit_def_1586  1
    service_2_4_15  free_load_conservation_1587  4
    service_0_7_0  unique_nonzero_owner_354  1
    service_0_7_0  service_visit_def_844  1
    service_0_7_0  free_load_conservation_845  -12
    service_0_7_0  original_T_including_depot_unload_886  1440
    service_0_7_1  unique_nonzero_owner_355  1
    service_0_7_1  service_visit_def_844  1
    service_0_7_1  free_load_conservation_845  -11
    service_0_7_1  original_T_including_depot_unload_886  1320
    service_0_7_2  unique_nonzero_owner_356  1
    service_0_7_2  service_visit_def_844  1
    service_0_7_2  free_load_conservation_845  -10
    service_0_7_2  original_T_including_depot_unload_886  1200
    service_0_7_3  unique_nonzero_owner_357  1
    service_0_7_3  service_visit_def_844  1
    service_0_7_3  free_load_conservation_845  -9
    service_0_7_3  original_T_including_depot_unload_886  1080
    service_0_7_4  unique_nonzero_owner_358  1
    service_0_7_4  service_visit_def_844  1
    service_0_7_4  free_load_conservation_845  -8
    service_0_7_4  original_T_including_depot_unload_886  960
    service_0_7_5  unique_nonzero_owner_359  1
    service_0_7_5  service_visit_def_844  1
    service_0_7_5  free_load_conservation_845  -7
    service_0_7_5  original_T_including_depot_unload_886  840
    service_0_7_6  unique_nonzero_owner_360  1
    service_0_7_6  service_visit_def_844  1
    service_0_7_6  free_load_conservation_845  -6
    service_0_7_6  original_T_including_depot_unload_886  720
    service_0_7_7  unique_nonzero_owner_361  1
    service_0_7_7  service_visit_def_844  1
    service_0_7_7  free_load_conservation_845  -5
    service_0_7_7  original_T_including_depot_unload_886  600
    service_0_7_8  unique_nonzero_owner_362  1
    service_0_7_8  service_visit_def_844  1
    service_0_7_8  free_load_conservation_845  -4
    service_0_7_8  original_T_including_depot_unload_886  480
    service_0_7_9  unique_nonzero_owner_363  1
    service_0_7_9  service_visit_def_844  1
    service_0_7_9  free_load_conservation_845  -3
    service_0_7_9  original_T_including_depot_unload_886  360
    service_0_7_10  unique_nonzero_owner_364  1
    service_0_7_10  service_visit_def_844  1
    service_0_7_10  free_load_conservation_845  -2
    service_0_7_10  original_T_including_depot_unload_886  240
    service_0_7_11  unique_nonzero_owner_365  1
    service_0_7_11  service_visit_def_844  1
    service_0_7_11  free_load_conservation_845  -1
    service_0_7_11  original_T_including_depot_unload_886  120
    service_0_7_13  unique_nonzero_owner_366  1
    service_0_7_13  service_visit_def_844  1
    service_0_7_13  free_load_conservation_845  1
    service_0_7_14  unique_nonzero_owner_367  1
    service_0_7_14  service_visit_def_844  1
    service_0_7_14  free_load_conservation_845  2
    service_0_7_15  unique_nonzero_owner_368  1
    service_0_7_15  service_visit_def_844  1
    service_0_7_15  free_load_conservation_845  3
    service_0_7_16  unique_nonzero_owner_369  1
    service_0_7_16  service_visit_def_844  1
    service_0_7_16  free_load_conservation_845  4
    service_0_7_17  unique_nonzero_owner_370  1
    service_0_7_17  service_visit_def_844  1
    service_0_7_17  free_load_conservation_845  5
    service_1_7_0  unique_nonzero_owner_354  1
    service_1_7_0  service_visit_def_1273  1
    service_1_7_0  free_load_conservation_1274  -12
    service_1_7_0  original_T_including_depot_unload_1315  1440
    service_1_7_1  unique_nonzero_owner_355  1
    service_1_7_1  service_visit_def_1273  1
    service_1_7_1  free_load_conservation_1274  -11
    service_1_7_1  original_T_including_depot_unload_1315  1320
    service_1_7_2  unique_nonzero_owner_356  1
    service_1_7_2  service_visit_def_1273  1
    service_1_7_2  free_load_conservation_1274  -10
    service_1_7_2  original_T_including_depot_unload_1315  1200
    service_1_7_3  unique_nonzero_owner_357  1
    service_1_7_3  service_visit_def_1273  1
    service_1_7_3  free_load_conservation_1274  -9
    service_1_7_3  original_T_including_depot_unload_1315  1080
    service_1_7_4  unique_nonzero_owner_358  1
    service_1_7_4  service_visit_def_1273  1
    service_1_7_4  free_load_conservation_1274  -8
    service_1_7_4  original_T_including_depot_unload_1315  960
    service_1_7_5  unique_nonzero_owner_359  1
    service_1_7_5  service_visit_def_1273  1
    service_1_7_5  free_load_conservation_1274  -7
    service_1_7_5  original_T_including_depot_unload_1315  840
    service_1_7_6  unique_nonzero_owner_360  1
    service_1_7_6  service_visit_def_1273  1
    service_1_7_6  free_load_conservation_1274  -6
    service_1_7_6  original_T_including_depot_unload_1315  720
    service_1_7_7  unique_nonzero_owner_361  1
    service_1_7_7  service_visit_def_1273  1
    service_1_7_7  free_load_conservation_1274  -5
    service_1_7_7  original_T_including_depot_unload_1315  600
    service_1_7_8  unique_nonzero_owner_362  1
    service_1_7_8  service_visit_def_1273  1
    service_1_7_8  free_load_conservation_1274  -4
    service_1_7_8  original_T_including_depot_unload_1315  480
    service_1_7_9  unique_nonzero_owner_363  1
    service_1_7_9  service_visit_def_1273  1
    service_1_7_9  free_load_conservation_1274  -3
    service_1_7_9  original_T_including_depot_unload_1315  360
    service_1_7_10  unique_nonzero_owner_364  1
    service_1_7_10  service_visit_def_1273  1
    service_1_7_10  free_load_conservation_1274  -2
    service_1_7_10  original_T_including_depot_unload_1315  240
    service_1_7_11  unique_nonzero_owner_365  1
    service_1_7_11  service_visit_def_1273  1
    service_1_7_11  free_load_conservation_1274  -1
    service_1_7_11  original_T_including_depot_unload_1315  120
    service_1_7_13  unique_nonzero_owner_366  1
    service_1_7_13  service_visit_def_1273  1
    service_1_7_13  free_load_conservation_1274  1
    service_1_7_14  unique_nonzero_owner_367  1
    service_1_7_14  service_visit_def_1273  1
    service_1_7_14  free_load_conservation_1274  2
    service_1_7_15  unique_nonzero_owner_368  1
    service_1_7_15  service_visit_def_1273  1
    service_1_7_15  free_load_conservation_1274  3
    service_1_7_16  unique_nonzero_owner_369  1
    service_1_7_16  service_visit_def_1273  1
    service_1_7_16  free_load_conservation_1274  4
    service_1_7_17  unique_nonzero_owner_370  1
    service_1_7_17  service_visit_def_1273  1
    service_1_7_17  free_load_conservation_1274  5
    service_2_7_0  unique_nonzero_owner_354  1
    service_2_7_0  service_visit_def_1592  1
    service_2_7_0  free_load_conservation_1593  -12
    service_2_7_0  original_T_including_depot_unload_1632  1440
    service_2_7_1  unique_nonzero_owner_355  1
    service_2_7_1  service_visit_def_1592  1
    service_2_7_1  free_load_conservation_1593  -11
    service_2_7_1  original_T_including_depot_unload_1632  1320
    service_2_7_2  unique_nonzero_owner_356  1
    service_2_7_2  service_visit_def_1592  1
    service_2_7_2  free_load_conservation_1593  -10
    service_2_7_2  original_T_including_depot_unload_1632  1200
    service_2_7_3  unique_nonzero_owner_357  1
    service_2_7_3  service_visit_def_1592  1
    service_2_7_3  free_load_conservation_1593  -9
    service_2_7_3  original_T_including_depot_unload_1632  1080
    service_2_7_4  unique_nonzero_owner_358  1
    service_2_7_4  service_visit_def_1592  1
    service_2_7_4  free_load_conservation_1593  -8
    service_2_7_4  original_T_including_depot_unload_1632  960
    service_2_7_5  unique_nonzero_owner_359  1
    service_2_7_5  service_visit_def_1592  1
    service_2_7_5  free_load_conservation_1593  -7
    service_2_7_5  original_T_including_depot_unload_1632  840
    service_2_7_6  unique_nonzero_owner_360  1
    service_2_7_6  service_visit_def_1592  1
    service_2_7_6  free_load_conservation_1593  -6
    service_2_7_6  original_T_including_depot_unload_1632  720
    service_2_7_7  unique_nonzero_owner_361  1
    service_2_7_7  service_visit_def_1592  1
    service_2_7_7  free_load_conservation_1593  -5
    service_2_7_7  original_T_including_depot_unload_1632  600
    service_2_7_8  unique_nonzero_owner_362  1
    service_2_7_8  service_visit_def_1592  1
    service_2_7_8  free_load_conservation_1593  -4
    service_2_7_8  original_T_including_depot_unload_1632  480
    service_2_7_9  unique_nonzero_owner_363  1
    service_2_7_9  service_visit_def_1592  1
    service_2_7_9  free_load_conservation_1593  -3
    service_2_7_9  original_T_including_depot_unload_1632  360
    service_2_7_10  unique_nonzero_owner_364  1
    service_2_7_10  service_visit_def_1592  1
    service_2_7_10  free_load_conservation_1593  -2
    service_2_7_10  original_T_including_depot_unload_1632  240
    service_2_7_11  unique_nonzero_owner_365  1
    service_2_7_11  service_visit_def_1592  1
    service_2_7_11  free_load_conservation_1593  -1
    service_2_7_11  original_T_including_depot_unload_1632  120
    service_2_7_13  unique_nonzero_owner_366  1
    service_2_7_13  service_visit_def_1592  1
    service_2_7_13  free_load_conservation_1593  1
    service_2_7_14  unique_nonzero_owner_367  1
    service_2_7_14  service_visit_def_1592  1
    service_2_7_14  free_load_conservation_1593  2
    service_2_7_15  unique_nonzero_owner_368  1
    service_2_7_15  service_visit_def_1592  1
    service_2_7_15  free_load_conservation_1593  3
    service_2_7_16  unique_nonzero_owner_369  1
    service_2_7_16  service_visit_def_1592  1
    service_2_7_16  free_load_conservation_1593  4
    service_2_7_17  unique_nonzero_owner_370  1
    service_2_7_17  service_visit_def_1592  1
    service_2_7_17  free_load_conservation_1593  5
    service_0_31_0  unique_nonzero_owner_371  1
    service_0_31_0  service_visit_def_850  1
    service_0_31_0  free_load_conservation_851  -2
    service_0_31_0  original_T_including_depot_unload_886  240
    service_0_31_1  unique_nonzero_owner_372  1
    service_0_31_1  service_visit_def_850  1
    service_0_31_1  free_load_conservation_851  -1
    service_0_31_1  original_T_including_depot_unload_886  120
    service_0_31_3  unique_nonzero_owner_373  1
    service_0_31_3  service_visit_def_850  1
    service_0_31_3  free_load_conservation_851  1
    service_0_31_4  unique_nonzero_owner_374  1
    service_0_31_4  service_visit_def_850  1
    service_0_31_4  free_load_conservation_851  2
    service_0_31_5  unique_nonzero_owner_375  1
    service_0_31_5  service_visit_def_850  1
    service_0_31_5  free_load_conservation_851  3
    service_0_31_6  unique_nonzero_owner_376  1
    service_0_31_6  service_visit_def_850  1
    service_0_31_6  free_load_conservation_851  4
    service_0_31_7  unique_nonzero_owner_377  1
    service_0_31_7  service_visit_def_850  1
    service_0_31_7  free_load_conservation_851  5
    service_0_31_8  unique_nonzero_owner_378  1
    service_0_31_8  service_visit_def_850  1
    service_0_31_8  free_load_conservation_851  6
    service_0_31_9  unique_nonzero_owner_379  1
    service_0_31_9  service_visit_def_850  1
    service_0_31_9  free_load_conservation_851  7
    service_0_31_10  unique_nonzero_owner_380  1
    service_0_31_10  service_visit_def_850  1
    service_0_31_10  free_load_conservation_851  8
    service_0_31_11  unique_nonzero_owner_381  1
    service_0_31_11  service_visit_def_850  1
    service_0_31_11  free_load_conservation_851  9
    service_0_31_12  unique_nonzero_owner_382  1
    service_0_31_12  service_visit_def_850  1
    service_0_31_12  free_load_conservation_851  10
    service_1_31_0  unique_nonzero_owner_371  1
    service_1_31_0  service_visit_def_1279  1
    service_1_31_0  free_load_conservation_1280  -2
    service_1_31_0  original_T_including_depot_unload_1315  240
    service_1_31_1  unique_nonzero_owner_372  1
    service_1_31_1  service_visit_def_1279  1
    service_1_31_1  free_load_conservation_1280  -1
    service_1_31_1  original_T_including_depot_unload_1315  120
    service_1_31_3  unique_nonzero_owner_373  1
    service_1_31_3  service_visit_def_1279  1
    service_1_31_3  free_load_conservation_1280  1
    service_1_31_4  unique_nonzero_owner_374  1
    service_1_31_4  service_visit_def_1279  1
    service_1_31_4  free_load_conservation_1280  2
    service_1_31_5  unique_nonzero_owner_375  1
    service_1_31_5  service_visit_def_1279  1
    service_1_31_5  free_load_conservation_1280  3
    service_1_31_6  unique_nonzero_owner_376  1
    service_1_31_6  service_visit_def_1279  1
    service_1_31_6  free_load_conservation_1280  4
    service_1_31_7  unique_nonzero_owner_377  1
    service_1_31_7  service_visit_def_1279  1
    service_1_31_7  free_load_conservation_1280  5
    service_1_31_8  unique_nonzero_owner_378  1
    service_1_31_8  service_visit_def_1279  1
    service_1_31_8  free_load_conservation_1280  6
    service_1_31_9  unique_nonzero_owner_379  1
    service_1_31_9  service_visit_def_1279  1
    service_1_31_9  free_load_conservation_1280  7
    service_1_31_10  unique_nonzero_owner_380  1
    service_1_31_10  service_visit_def_1279  1
    service_1_31_10  free_load_conservation_1280  8
    service_1_31_11  unique_nonzero_owner_381  1
    service_1_31_11  service_visit_def_1279  1
    service_1_31_11  free_load_conservation_1280  9
    service_1_31_12  unique_nonzero_owner_382  1
    service_1_31_12  service_visit_def_1279  1
    service_1_31_12  free_load_conservation_1280  10
    service_2_31_0  unique_nonzero_owner_371  1
    service_2_31_0  service_visit_def_1598  1
    service_2_31_0  free_load_conservation_1599  -2
    service_2_31_0  original_T_including_depot_unload_1632  240
    service_2_31_1  unique_nonzero_owner_372  1
    service_2_31_1  service_visit_def_1598  1
    service_2_31_1  free_load_conservation_1599  -1
    service_2_31_1  original_T_including_depot_unload_1632  120
    service_2_31_3  unique_nonzero_owner_373  1
    service_2_31_3  service_visit_def_1598  1
    service_2_31_3  free_load_conservation_1599  1
    service_2_31_4  unique_nonzero_owner_374  1
    service_2_31_4  service_visit_def_1598  1
    service_2_31_4  free_load_conservation_1599  2
    service_2_31_5  unique_nonzero_owner_375  1
    service_2_31_5  service_visit_def_1598  1
    service_2_31_5  free_load_conservation_1599  3
    service_2_31_6  unique_nonzero_owner_376  1
    service_2_31_6  service_visit_def_1598  1
    service_2_31_6  free_load_conservation_1599  4
    service_2_31_7  unique_nonzero_owner_377  1
    service_2_31_7  service_visit_def_1598  1
    service_2_31_7  free_load_conservation_1599  5
    service_2_31_8  unique_nonzero_owner_378  1
    service_2_31_8  service_visit_def_1598  1
    service_2_31_8  free_load_conservation_1599  6
    service_2_31_9  unique_nonzero_owner_379  1
    service_2_31_9  service_visit_def_1598  1
    service_2_31_9  free_load_conservation_1599  7
    service_2_31_10  unique_nonzero_owner_380  1
    service_2_31_10  service_visit_def_1598  1
    service_2_31_10  free_load_conservation_1599  8
    service_2_31_11  unique_nonzero_owner_381  1
    service_2_31_11  service_visit_def_1598  1
    service_2_31_11  free_load_conservation_1599  9
    service_2_31_12  unique_nonzero_owner_382  1
    service_2_31_12  service_visit_def_1598  1
    service_2_31_12  free_load_conservation_1599  10
    service_0_1_0  unique_nonzero_owner_383  1
    service_0_1_0  service_visit_def_856  1
    service_0_1_0  free_load_conservation_857  -2
    service_0_1_0  original_T_including_depot_unload_886  240
    service_0_1_1  unique_nonzero_owner_384  1
    service_0_1_1  service_visit_def_856  1
    service_0_1_1  free_load_conservation_857  -1
    service_0_1_1  original_T_including_depot_unload_886  120
    service_0_1_3  unique_nonzero_owner_385  1
    service_0_1_3  service_visit_def_856  1
    service_0_1_3  free_load_conservation_857  1
    service_0_1_4  unique_nonzero_owner_386  1
    service_0_1_4  service_visit_def_856  1
    service_0_1_4  free_load_conservation_857  2
    service_0_1_5  unique_nonzero_owner_387  1
    service_0_1_5  service_visit_def_856  1
    service_0_1_5  free_load_conservation_857  3
    service_0_1_6  unique_nonzero_owner_388  1
    service_0_1_6  service_visit_def_856  1
    service_0_1_6  free_load_conservation_857  4
    service_0_1_7  unique_nonzero_owner_389  1
    service_0_1_7  service_visit_def_856  1
    service_0_1_7  free_load_conservation_857  5
    service_0_1_8  unique_nonzero_owner_390  1
    service_0_1_8  service_visit_def_856  1
    service_0_1_8  free_load_conservation_857  6
    service_0_1_9  unique_nonzero_owner_391  1
    service_0_1_9  service_visit_def_856  1
    service_0_1_9  free_load_conservation_857  7
    service_0_1_10  unique_nonzero_owner_392  1
    service_0_1_10  service_visit_def_856  1
    service_0_1_10  free_load_conservation_857  8
    service_0_1_11  unique_nonzero_owner_393  1
    service_0_1_11  service_visit_def_856  1
    service_0_1_11  free_load_conservation_857  9
    service_0_1_12  unique_nonzero_owner_394  1
    service_0_1_12  service_visit_def_856  1
    service_0_1_12  free_load_conservation_857  10
    service_0_1_13  unique_nonzero_owner_395  1
    service_0_1_13  service_visit_def_856  1
    service_0_1_13  free_load_conservation_857  11
    service_0_1_14  unique_nonzero_owner_396  1
    service_0_1_14  service_visit_def_856  1
    service_0_1_14  free_load_conservation_857  12
    service_0_1_15  unique_nonzero_owner_397  1
    service_0_1_15  service_visit_def_856  1
    service_0_1_15  free_load_conservation_857  13
    service_0_1_16  unique_nonzero_owner_398  1
    service_0_1_16  service_visit_def_856  1
    service_0_1_16  free_load_conservation_857  14
    service_0_1_17  unique_nonzero_owner_399  1
    service_0_1_17  service_visit_def_856  1
    service_0_1_17  free_load_conservation_857  15
    service_0_1_18  unique_nonzero_owner_400  1
    service_0_1_18  service_visit_def_856  1
    service_0_1_18  free_load_conservation_857  16
    service_0_1_19  unique_nonzero_owner_401  1
    service_0_1_19  service_visit_def_856  1
    service_0_1_19  free_load_conservation_857  17
    service_1_1_0  unique_nonzero_owner_383  1
    service_1_1_0  service_visit_def_1285  1
    service_1_1_0  free_load_conservation_1286  -2
    service_1_1_0  original_T_including_depot_unload_1315  240
    service_1_1_1  unique_nonzero_owner_384  1
    service_1_1_1  service_visit_def_1285  1
    service_1_1_1  free_load_conservation_1286  -1
    service_1_1_1  original_T_including_depot_unload_1315  120
    service_1_1_3  unique_nonzero_owner_385  1
    service_1_1_3  service_visit_def_1285  1
    service_1_1_3  free_load_conservation_1286  1
    service_1_1_4  unique_nonzero_owner_386  1
    service_1_1_4  service_visit_def_1285  1
    service_1_1_4  free_load_conservation_1286  2
    service_1_1_5  unique_nonzero_owner_387  1
    service_1_1_5  service_visit_def_1285  1
    service_1_1_5  free_load_conservation_1286  3
    service_1_1_6  unique_nonzero_owner_388  1
    service_1_1_6  service_visit_def_1285  1
    service_1_1_6  free_load_conservation_1286  4
    service_1_1_7  unique_nonzero_owner_389  1
    service_1_1_7  service_visit_def_1285  1
    service_1_1_7  free_load_conservation_1286  5
    service_1_1_8  unique_nonzero_owner_390  1
    service_1_1_8  service_visit_def_1285  1
    service_1_1_8  free_load_conservation_1286  6
    service_1_1_9  unique_nonzero_owner_391  1
    service_1_1_9  service_visit_def_1285  1
    service_1_1_9  free_load_conservation_1286  7
    service_1_1_10  unique_nonzero_owner_392  1
    service_1_1_10  service_visit_def_1285  1
    service_1_1_10  free_load_conservation_1286  8
    service_1_1_11  unique_nonzero_owner_393  1
    service_1_1_11  service_visit_def_1285  1
    service_1_1_11  free_load_conservation_1286  9
    service_1_1_12  unique_nonzero_owner_394  1
    service_1_1_12  service_visit_def_1285  1
    service_1_1_12  free_load_conservation_1286  10
    service_1_1_13  unique_nonzero_owner_395  1
    service_1_1_13  service_visit_def_1285  1
    service_1_1_13  free_load_conservation_1286  11
    service_1_1_14  unique_nonzero_owner_396  1
    service_1_1_14  service_visit_def_1285  1
    service_1_1_14  free_load_conservation_1286  12
    service_1_1_15  unique_nonzero_owner_397  1
    service_1_1_15  service_visit_def_1285  1
    service_1_1_15  free_load_conservation_1286  13
    service_1_1_16  unique_nonzero_owner_398  1
    service_1_1_16  service_visit_def_1285  1
    service_1_1_16  free_load_conservation_1286  14
    service_1_1_17  unique_nonzero_owner_399  1
    service_1_1_17  service_visit_def_1285  1
    service_1_1_17  free_load_conservation_1286  15
    service_1_1_18  unique_nonzero_owner_400  1
    service_1_1_18  service_visit_def_1285  1
    service_1_1_18  free_load_conservation_1286  16
    service_1_1_19  unique_nonzero_owner_401  1
    service_1_1_19  service_visit_def_1285  1
    service_1_1_19  free_load_conservation_1286  17
    service_2_1_0  unique_nonzero_owner_383  1
    service_2_1_0  service_visit_def_1604  1
    service_2_1_0  free_load_conservation_1605  -2
    service_2_1_0  original_T_including_depot_unload_1632  240
    service_2_1_1  unique_nonzero_owner_384  1
    service_2_1_1  service_visit_def_1604  1
    service_2_1_1  free_load_conservation_1605  -1
    service_2_1_1  original_T_including_depot_unload_1632  120
    service_2_1_3  unique_nonzero_owner_385  1
    service_2_1_3  service_visit_def_1604  1
    service_2_1_3  free_load_conservation_1605  1
    service_2_1_4  unique_nonzero_owner_386  1
    service_2_1_4  service_visit_def_1604  1
    service_2_1_4  free_load_conservation_1605  2
    service_2_1_5  unique_nonzero_owner_387  1
    service_2_1_5  service_visit_def_1604  1
    service_2_1_5  free_load_conservation_1605  3
    service_2_1_6  unique_nonzero_owner_388  1
    service_2_1_6  service_visit_def_1604  1
    service_2_1_6  free_load_conservation_1605  4
    service_2_1_7  unique_nonzero_owner_389  1
    service_2_1_7  service_visit_def_1604  1
    service_2_1_7  free_load_conservation_1605  5
    service_2_1_8  unique_nonzero_owner_390  1
    service_2_1_8  service_visit_def_1604  1
    service_2_1_8  free_load_conservation_1605  6
    service_2_1_9  unique_nonzero_owner_391  1
    service_2_1_9  service_visit_def_1604  1
    service_2_1_9  free_load_conservation_1605  7
    service_2_1_10  unique_nonzero_owner_392  1
    service_2_1_10  service_visit_def_1604  1
    service_2_1_10  free_load_conservation_1605  8
    service_2_1_11  unique_nonzero_owner_393  1
    service_2_1_11  service_visit_def_1604  1
    service_2_1_11  free_load_conservation_1605  9
    service_2_1_12  unique_nonzero_owner_394  1
    service_2_1_12  service_visit_def_1604  1
    service_2_1_12  free_load_conservation_1605  10
    service_2_1_13  unique_nonzero_owner_395  1
    service_2_1_13  service_visit_def_1604  1
    service_2_1_13  free_load_conservation_1605  11
    service_2_1_14  unique_nonzero_owner_396  1
    service_2_1_14  service_visit_def_1604  1
    service_2_1_14  free_load_conservation_1605  12
    service_2_1_15  unique_nonzero_owner_397  1
    service_2_1_15  service_visit_def_1604  1
    service_2_1_15  free_load_conservation_1605  13
    service_2_1_16  unique_nonzero_owner_398  1
    service_2_1_16  service_visit_def_1604  1
    service_2_1_16  free_load_conservation_1605  14
    service_2_1_17  unique_nonzero_owner_399  1
    service_2_1_17  service_visit_def_1604  1
    service_2_1_17  free_load_conservation_1605  15
    service_2_1_18  unique_nonzero_owner_400  1
    service_2_1_18  service_visit_def_1604  1
    service_2_1_18  free_load_conservation_1605  16
    service_2_1_19  unique_nonzero_owner_401  1
    service_2_1_19  service_visit_def_1604  1
    service_2_1_19  free_load_conservation_1605  17
    service_0_2_1  unique_nonzero_owner_402  1
    service_0_2_1  service_visit_def_862  1
    service_0_2_1  free_load_conservation_863  1
    service_0_2_2  unique_nonzero_owner_403  1
    service_0_2_2  service_visit_def_862  1
    service_0_2_2  free_load_conservation_863  2
    service_0_2_3  unique_nonzero_owner_404  1
    service_0_2_3  service_visit_def_862  1
    service_0_2_3  free_load_conservation_863  3
    service_0_2_4  unique_nonzero_owner_405  1
    service_0_2_4  service_visit_def_862  1
    service_0_2_4  free_load_conservation_863  4
    service_0_2_5  unique_nonzero_owner_406  1
    service_0_2_5  service_visit_def_862  1
    service_0_2_5  free_load_conservation_863  5
    service_0_2_6  unique_nonzero_owner_407  1
    service_0_2_6  service_visit_def_862  1
    service_0_2_6  free_load_conservation_863  6
    service_0_2_7  unique_nonzero_owner_408  1
    service_0_2_7  service_visit_def_862  1
    service_0_2_7  free_load_conservation_863  7
    service_0_2_8  unique_nonzero_owner_409  1
    service_0_2_8  service_visit_def_862  1
    service_0_2_8  free_load_conservation_863  8
    service_0_2_9  unique_nonzero_owner_410  1
    service_0_2_9  service_visit_def_862  1
    service_0_2_9  free_load_conservation_863  9
    service_0_2_10  unique_nonzero_owner_411  1
    service_0_2_10  service_visit_def_862  1
    service_0_2_10  free_load_conservation_863  10
    service_0_2_11  unique_nonzero_owner_412  1
    service_0_2_11  service_visit_def_862  1
    service_0_2_11  free_load_conservation_863  11
    service_0_2_12  unique_nonzero_owner_413  1
    service_0_2_12  service_visit_def_862  1
    service_0_2_12  free_load_conservation_863  12
    service_0_2_13  unique_nonzero_owner_414  1
    service_0_2_13  service_visit_def_862  1
    service_0_2_13  free_load_conservation_863  13
    service_0_2_14  unique_nonzero_owner_415  1
    service_0_2_14  service_visit_def_862  1
    service_0_2_14  free_load_conservation_863  14
    service_0_2_15  unique_nonzero_owner_416  1
    service_0_2_15  service_visit_def_862  1
    service_0_2_15  free_load_conservation_863  15
    service_1_2_1  unique_nonzero_owner_402  1
    service_1_2_1  service_visit_def_1291  1
    service_1_2_1  free_load_conservation_1292  1
    service_1_2_2  unique_nonzero_owner_403  1
    service_1_2_2  service_visit_def_1291  1
    service_1_2_2  free_load_conservation_1292  2
    service_1_2_3  unique_nonzero_owner_404  1
    service_1_2_3  service_visit_def_1291  1
    service_1_2_3  free_load_conservation_1292  3
    service_1_2_4  unique_nonzero_owner_405  1
    service_1_2_4  service_visit_def_1291  1
    service_1_2_4  free_load_conservation_1292  4
    service_1_2_5  unique_nonzero_owner_406  1
    service_1_2_5  service_visit_def_1291  1
    service_1_2_5  free_load_conservation_1292  5
    service_1_2_6  unique_nonzero_owner_407  1
    service_1_2_6  service_visit_def_1291  1
    service_1_2_6  free_load_conservation_1292  6
    service_1_2_7  unique_nonzero_owner_408  1
    service_1_2_7  service_visit_def_1291  1
    service_1_2_7  free_load_conservation_1292  7
    service_1_2_8  unique_nonzero_owner_409  1
    service_1_2_8  service_visit_def_1291  1
    service_1_2_8  free_load_conservation_1292  8
    service_1_2_9  unique_nonzero_owner_410  1
    service_1_2_9  service_visit_def_1291  1
    service_1_2_9  free_load_conservation_1292  9
    service_1_2_10  unique_nonzero_owner_411  1
    service_1_2_10  service_visit_def_1291  1
    service_1_2_10  free_load_conservation_1292  10
    service_1_2_11  unique_nonzero_owner_412  1
    service_1_2_11  service_visit_def_1291  1
    service_1_2_11  free_load_conservation_1292  11
    service_1_2_12  unique_nonzero_owner_413  1
    service_1_2_12  service_visit_def_1291  1
    service_1_2_12  free_load_conservation_1292  12
    service_1_2_13  unique_nonzero_owner_414  1
    service_1_2_13  service_visit_def_1291  1
    service_1_2_13  free_load_conservation_1292  13
    service_1_2_14  unique_nonzero_owner_415  1
    service_1_2_14  service_visit_def_1291  1
    service_1_2_14  free_load_conservation_1292  14
    service_1_2_15  unique_nonzero_owner_416  1
    service_1_2_15  service_visit_def_1291  1
    service_1_2_15  free_load_conservation_1292  15
    service_2_2_1  unique_nonzero_owner_402  1
    service_2_2_1  service_visit_def_1610  1
    service_2_2_1  free_load_conservation_1611  1
    service_2_2_2  unique_nonzero_owner_403  1
    service_2_2_2  service_visit_def_1610  1
    service_2_2_2  free_load_conservation_1611  2
    service_2_2_3  unique_nonzero_owner_404  1
    service_2_2_3  service_visit_def_1610  1
    service_2_2_3  free_load_conservation_1611  3
    service_2_2_4  unique_nonzero_owner_405  1
    service_2_2_4  service_visit_def_1610  1
    service_2_2_4  free_load_conservation_1611  4
    service_2_2_5  unique_nonzero_owner_406  1
    service_2_2_5  service_visit_def_1610  1
    service_2_2_5  free_load_conservation_1611  5
    service_2_2_6  unique_nonzero_owner_407  1
    service_2_2_6  service_visit_def_1610  1
    service_2_2_6  free_load_conservation_1611  6
    service_2_2_7  unique_nonzero_owner_408  1
    service_2_2_7  service_visit_def_1610  1
    service_2_2_7  free_load_conservation_1611  7
    service_2_2_8  unique_nonzero_owner_409  1
    service_2_2_8  service_visit_def_1610  1
    service_2_2_8  free_load_conservation_1611  8
    service_2_2_9  unique_nonzero_owner_410  1
    service_2_2_9  service_visit_def_1610  1
    service_2_2_9  free_load_conservation_1611  9
    service_2_2_10  unique_nonzero_owner_411  1
    service_2_2_10  service_visit_def_1610  1
    service_2_2_10  free_load_conservation_1611  10
    service_2_2_11  unique_nonzero_owner_412  1
    service_2_2_11  service_visit_def_1610  1
    service_2_2_11  free_load_conservation_1611  11
    service_2_2_12  unique_nonzero_owner_413  1
    service_2_2_12  service_visit_def_1610  1
    service_2_2_12  free_load_conservation_1611  12
    service_2_2_13  unique_nonzero_owner_414  1
    service_2_2_13  service_visit_def_1610  1
    service_2_2_13  free_load_conservation_1611  13
    service_2_2_14  unique_nonzero_owner_415  1
    service_2_2_14  service_visit_def_1610  1
    service_2_2_14  free_load_conservation_1611  14
    service_2_2_15  unique_nonzero_owner_416  1
    service_2_2_15  service_visit_def_1610  1
    service_2_2_15  free_load_conservation_1611  15
    service_0_3_0  unique_nonzero_owner_417  1
    service_0_3_0  service_visit_def_868  1
    service_0_3_0  free_load_conservation_869  -12
    service_0_3_0  original_T_including_depot_unload_886  1440
    service_0_3_1  unique_nonzero_owner_418  1
    service_0_3_1  service_visit_def_868  1
    service_0_3_1  free_load_conservation_869  -11
    service_0_3_1  original_T_including_depot_unload_886  1320
    service_0_3_2  unique_nonzero_owner_419  1
    service_0_3_2  service_visit_def_868  1
    service_0_3_2  free_load_conservation_869  -10
    service_0_3_2  original_T_including_depot_unload_886  1200
    service_0_3_3  unique_nonzero_owner_420  1
    service_0_3_3  service_visit_def_868  1
    service_0_3_3  free_load_conservation_869  -9
    service_0_3_3  original_T_including_depot_unload_886  1080
    service_0_3_4  unique_nonzero_owner_421  1
    service_0_3_4  service_visit_def_868  1
    service_0_3_4  free_load_conservation_869  -8
    service_0_3_4  original_T_including_depot_unload_886  960
    service_0_3_5  unique_nonzero_owner_422  1
    service_0_3_5  service_visit_def_868  1
    service_0_3_5  free_load_conservation_869  -7
    service_0_3_5  original_T_including_depot_unload_886  840
    service_0_3_6  unique_nonzero_owner_423  1
    service_0_3_6  service_visit_def_868  1
    service_0_3_6  free_load_conservation_869  -6
    service_0_3_6  original_T_including_depot_unload_886  720
    service_0_3_7  unique_nonzero_owner_424  1
    service_0_3_7  service_visit_def_868  1
    service_0_3_7  free_load_conservation_869  -5
    service_0_3_7  original_T_including_depot_unload_886  600
    service_0_3_8  unique_nonzero_owner_425  1
    service_0_3_8  service_visit_def_868  1
    service_0_3_8  free_load_conservation_869  -4
    service_0_3_8  original_T_including_depot_unload_886  480
    service_0_3_9  unique_nonzero_owner_426  1
    service_0_3_9  service_visit_def_868  1
    service_0_3_9  free_load_conservation_869  -3
    service_0_3_9  original_T_including_depot_unload_886  360
    service_0_3_10  unique_nonzero_owner_427  1
    service_0_3_10  service_visit_def_868  1
    service_0_3_10  free_load_conservation_869  -2
    service_0_3_10  original_T_including_depot_unload_886  240
    service_0_3_11  unique_nonzero_owner_428  1
    service_0_3_11  service_visit_def_868  1
    service_0_3_11  free_load_conservation_869  -1
    service_0_3_11  original_T_including_depot_unload_886  120
    service_0_3_13  unique_nonzero_owner_429  1
    service_0_3_13  service_visit_def_868  1
    service_0_3_13  free_load_conservation_869  1
    service_0_3_14  unique_nonzero_owner_430  1
    service_0_3_14  service_visit_def_868  1
    service_0_3_14  free_load_conservation_869  2
    service_0_3_15  unique_nonzero_owner_431  1
    service_0_3_15  service_visit_def_868  1
    service_0_3_15  free_load_conservation_869  3
    service_0_3_16  unique_nonzero_owner_432  1
    service_0_3_16  service_visit_def_868  1
    service_0_3_16  free_load_conservation_869  4
    service_0_3_17  unique_nonzero_owner_433  1
    service_0_3_17  service_visit_def_868  1
    service_0_3_17  free_load_conservation_869  5
    service_1_3_0  unique_nonzero_owner_417  1
    service_1_3_0  service_visit_def_1297  1
    service_1_3_0  free_load_conservation_1298  -12
    service_1_3_0  original_T_including_depot_unload_1315  1440
    service_1_3_1  unique_nonzero_owner_418  1
    service_1_3_1  service_visit_def_1297  1
    service_1_3_1  free_load_conservation_1298  -11
    service_1_3_1  original_T_including_depot_unload_1315  1320
    service_1_3_2  unique_nonzero_owner_419  1
    service_1_3_2  service_visit_def_1297  1
    service_1_3_2  free_load_conservation_1298  -10
    service_1_3_2  original_T_including_depot_unload_1315  1200
    service_1_3_3  unique_nonzero_owner_420  1
    service_1_3_3  service_visit_def_1297  1
    service_1_3_3  free_load_conservation_1298  -9
    service_1_3_3  original_T_including_depot_unload_1315  1080
    service_1_3_4  unique_nonzero_owner_421  1
    service_1_3_4  service_visit_def_1297  1
    service_1_3_4  free_load_conservation_1298  -8
    service_1_3_4  original_T_including_depot_unload_1315  960
    service_1_3_5  unique_nonzero_owner_422  1
    service_1_3_5  service_visit_def_1297  1
    service_1_3_5  free_load_conservation_1298  -7
    service_1_3_5  original_T_including_depot_unload_1315  840
    service_1_3_6  unique_nonzero_owner_423  1
    service_1_3_6  service_visit_def_1297  1
    service_1_3_6  free_load_conservation_1298  -6
    service_1_3_6  original_T_including_depot_unload_1315  720
    service_1_3_7  unique_nonzero_owner_424  1
    service_1_3_7  service_visit_def_1297  1
    service_1_3_7  free_load_conservation_1298  -5
    service_1_3_7  original_T_including_depot_unload_1315  600
    service_1_3_8  unique_nonzero_owner_425  1
    service_1_3_8  service_visit_def_1297  1
    service_1_3_8  free_load_conservation_1298  -4
    service_1_3_8  original_T_including_depot_unload_1315  480
    service_1_3_9  unique_nonzero_owner_426  1
    service_1_3_9  service_visit_def_1297  1
    service_1_3_9  free_load_conservation_1298  -3
    service_1_3_9  original_T_including_depot_unload_1315  360
    service_1_3_10  unique_nonzero_owner_427  1
    service_1_3_10  service_visit_def_1297  1
    service_1_3_10  free_load_conservation_1298  -2
    service_1_3_10  original_T_including_depot_unload_1315  240
    service_1_3_11  unique_nonzero_owner_428  1
    service_1_3_11  service_visit_def_1297  1
    service_1_3_11  free_load_conservation_1298  -1
    service_1_3_11  original_T_including_depot_unload_1315  120
    service_1_3_13  unique_nonzero_owner_429  1
    service_1_3_13  service_visit_def_1297  1
    service_1_3_13  free_load_conservation_1298  1
    service_1_3_14  unique_nonzero_owner_430  1
    service_1_3_14  service_visit_def_1297  1
    service_1_3_14  free_load_conservation_1298  2
    service_1_3_15  unique_nonzero_owner_431  1
    service_1_3_15  service_visit_def_1297  1
    service_1_3_15  free_load_conservation_1298  3
    service_1_3_16  unique_nonzero_owner_432  1
    service_1_3_16  service_visit_def_1297  1
    service_1_3_16  free_load_conservation_1298  4
    service_1_3_17  unique_nonzero_owner_433  1
    service_1_3_17  service_visit_def_1297  1
    service_1_3_17  free_load_conservation_1298  5
    service_2_3_0  unique_nonzero_owner_417  1
    service_2_3_0  service_visit_def_1616  1
    service_2_3_0  free_load_conservation_1617  -12
    service_2_3_0  original_T_including_depot_unload_1632  1440
    service_2_3_1  unique_nonzero_owner_418  1
    service_2_3_1  service_visit_def_1616  1
    service_2_3_1  free_load_conservation_1617  -11
    service_2_3_1  original_T_including_depot_unload_1632  1320
    service_2_3_2  unique_nonzero_owner_419  1
    service_2_3_2  service_visit_def_1616  1
    service_2_3_2  free_load_conservation_1617  -10
    service_2_3_2  original_T_including_depot_unload_1632  1200
    service_2_3_3  unique_nonzero_owner_420  1
    service_2_3_3  service_visit_def_1616  1
    service_2_3_3  free_load_conservation_1617  -9
    service_2_3_3  original_T_including_depot_unload_1632  1080
    service_2_3_4  unique_nonzero_owner_421  1
    service_2_3_4  service_visit_def_1616  1
    service_2_3_4  free_load_conservation_1617  -8
    service_2_3_4  original_T_including_depot_unload_1632  960
    service_2_3_5  unique_nonzero_owner_422  1
    service_2_3_5  service_visit_def_1616  1
    service_2_3_5  free_load_conservation_1617  -7
    service_2_3_5  original_T_including_depot_unload_1632  840
    service_2_3_6  unique_nonzero_owner_423  1
    service_2_3_6  service_visit_def_1616  1
    service_2_3_6  free_load_conservation_1617  -6
    service_2_3_6  original_T_including_depot_unload_1632  720
    service_2_3_7  unique_nonzero_owner_424  1
    service_2_3_7  service_visit_def_1616  1
    service_2_3_7  free_load_conservation_1617  -5
    service_2_3_7  original_T_including_depot_unload_1632  600
    service_2_3_8  unique_nonzero_owner_425  1
    service_2_3_8  service_visit_def_1616  1
    service_2_3_8  free_load_conservation_1617  -4
    service_2_3_8  original_T_including_depot_unload_1632  480
    service_2_3_9  unique_nonzero_owner_426  1
    service_2_3_9  service_visit_def_1616  1
    service_2_3_9  free_load_conservation_1617  -3
    service_2_3_9  original_T_including_depot_unload_1632  360
    service_2_3_10  unique_nonzero_owner_427  1
    service_2_3_10  service_visit_def_1616  1
    service_2_3_10  free_load_conservation_1617  -2
    service_2_3_10  original_T_including_depot_unload_1632  240
    service_2_3_11  unique_nonzero_owner_428  1
    service_2_3_11  service_visit_def_1616  1
    service_2_3_11  free_load_conservation_1617  -1
    service_2_3_11  original_T_including_depot_unload_1632  120
    service_2_3_13  unique_nonzero_owner_429  1
    service_2_3_13  service_visit_def_1616  1
    service_2_3_13  free_load_conservation_1617  1
    service_2_3_14  unique_nonzero_owner_430  1
    service_2_3_14  service_visit_def_1616  1
    service_2_3_14  free_load_conservation_1617  2
    service_2_3_15  unique_nonzero_owner_431  1
    service_2_3_15  service_visit_def_1616  1
    service_2_3_15  free_load_conservation_1617  3
    service_2_3_16  unique_nonzero_owner_432  1
    service_2_3_16  service_visit_def_1616  1
    service_2_3_16  free_load_conservation_1617  4
    service_2_3_17  unique_nonzero_owner_433  1
    service_2_3_17  service_visit_def_1616  1
    service_2_3_17  free_load_conservation_1617  5
    service_0_16_0  unique_nonzero_owner_434  1
    service_0_16_0  service_visit_def_874  1
    service_0_16_0  free_load_conservation_875  -1
    service_0_16_0  original_T_including_depot_unload_886  120
    service_0_16_2  unique_nonzero_owner_435  1
    service_0_16_2  service_visit_def_874  1
    service_0_16_2  free_load_conservation_875  1
    service_0_16_3  unique_nonzero_owner_436  1
    service_0_16_3  service_visit_def_874  1
    service_0_16_3  free_load_conservation_875  2
    service_0_16_4  unique_nonzero_owner_437  1
    service_0_16_4  service_visit_def_874  1
    service_0_16_4  free_load_conservation_875  3
    service_0_16_5  unique_nonzero_owner_438  1
    service_0_16_5  service_visit_def_874  1
    service_0_16_5  free_load_conservation_875  4
    service_0_16_6  unique_nonzero_owner_439  1
    service_0_16_6  service_visit_def_874  1
    service_0_16_6  free_load_conservation_875  5
    service_0_16_7  unique_nonzero_owner_440  1
    service_0_16_7  service_visit_def_874  1
    service_0_16_7  free_load_conservation_875  6
    service_0_16_8  unique_nonzero_owner_441  1
    service_0_16_8  service_visit_def_874  1
    service_0_16_8  free_load_conservation_875  7
    service_0_16_9  unique_nonzero_owner_442  1
    service_0_16_9  service_visit_def_874  1
    service_0_16_9  free_load_conservation_875  8
    service_0_16_10  unique_nonzero_owner_443  1
    service_0_16_10  service_visit_def_874  1
    service_0_16_10  free_load_conservation_875  9
    service_0_16_11  unique_nonzero_owner_444  1
    service_0_16_11  service_visit_def_874  1
    service_0_16_11  free_load_conservation_875  10
    service_0_16_12  unique_nonzero_owner_445  1
    service_0_16_12  service_visit_def_874  1
    service_0_16_12  free_load_conservation_875  11
    service_1_16_0  unique_nonzero_owner_434  1
    service_1_16_0  service_visit_def_1303  1
    service_1_16_0  free_load_conservation_1304  -1
    service_1_16_0  original_T_including_depot_unload_1315  120
    service_1_16_2  unique_nonzero_owner_435  1
    service_1_16_2  service_visit_def_1303  1
    service_1_16_2  free_load_conservation_1304  1
    service_1_16_3  unique_nonzero_owner_436  1
    service_1_16_3  service_visit_def_1303  1
    service_1_16_3  free_load_conservation_1304  2
    service_1_16_4  unique_nonzero_owner_437  1
    service_1_16_4  service_visit_def_1303  1
    service_1_16_4  free_load_conservation_1304  3
    service_1_16_5  unique_nonzero_owner_438  1
    service_1_16_5  service_visit_def_1303  1
    service_1_16_5  free_load_conservation_1304  4
    service_1_16_6  unique_nonzero_owner_439  1
    service_1_16_6  service_visit_def_1303  1
    service_1_16_6  free_load_conservation_1304  5
    service_1_16_7  unique_nonzero_owner_440  1
    service_1_16_7  service_visit_def_1303  1
    service_1_16_7  free_load_conservation_1304  6
    service_1_16_8  unique_nonzero_owner_441  1
    service_1_16_8  service_visit_def_1303  1
    service_1_16_8  free_load_conservation_1304  7
    service_1_16_9  unique_nonzero_owner_442  1
    service_1_16_9  service_visit_def_1303  1
    service_1_16_9  free_load_conservation_1304  8
    service_1_16_10  unique_nonzero_owner_443  1
    service_1_16_10  service_visit_def_1303  1
    service_1_16_10  free_load_conservation_1304  9
    service_1_16_11  unique_nonzero_owner_444  1
    service_1_16_11  service_visit_def_1303  1
    service_1_16_11  free_load_conservation_1304  10
    service_1_16_12  unique_nonzero_owner_445  1
    service_1_16_12  service_visit_def_1303  1
    service_1_16_12  free_load_conservation_1304  11
    service_2_16_0  unique_nonzero_owner_434  1
    service_2_16_0  service_visit_def_1622  1
    service_2_16_0  free_load_conservation_1623  -1
    service_2_16_0  original_T_including_depot_unload_1632  120
    service_2_16_2  unique_nonzero_owner_435  1
    service_2_16_2  service_visit_def_1622  1
    service_2_16_2  free_load_conservation_1623  1
    service_2_16_3  unique_nonzero_owner_436  1
    service_2_16_3  service_visit_def_1622  1
    service_2_16_3  free_load_conservation_1623  2
    service_2_16_4  unique_nonzero_owner_437  1
    service_2_16_4  service_visit_def_1622  1
    service_2_16_4  free_load_conservation_1623  3
    service_2_16_5  unique_nonzero_owner_438  1
    service_2_16_5  service_visit_def_1622  1
    service_2_16_5  free_load_conservation_1623  4
    service_2_16_6  unique_nonzero_owner_439  1
    service_2_16_6  service_visit_def_1622  1
    service_2_16_6  free_load_conservation_1623  5
    service_2_16_7  unique_nonzero_owner_440  1
    service_2_16_7  service_visit_def_1622  1
    service_2_16_7  free_load_conservation_1623  6
    service_2_16_8  unique_nonzero_owner_441  1
    service_2_16_8  service_visit_def_1622  1
    service_2_16_8  free_load_conservation_1623  7
    service_2_16_9  unique_nonzero_owner_442  1
    service_2_16_9  service_visit_def_1622  1
    service_2_16_9  free_load_conservation_1623  8
    service_2_16_10  unique_nonzero_owner_443  1
    service_2_16_10  service_visit_def_1622  1
    service_2_16_10  free_load_conservation_1623  9
    service_2_16_11  unique_nonzero_owner_444  1
    service_2_16_11  service_visit_def_1622  1
    service_2_16_11  free_load_conservation_1623  10
    service_2_16_12  unique_nonzero_owner_445  1
    service_2_16_12  service_visit_def_1622  1
    service_2_16_12  free_load_conservation_1623  11
    service_0_11_0  unique_nonzero_owner_446  1
    service_0_11_0  service_visit_def_880  1
    service_0_11_0  free_load_conservation_881  -7
    service_0_11_0  original_T_including_depot_unload_886  840
    service_0_11_1  unique_nonzero_owner_447  1
    service_0_11_1  service_visit_def_880  1
    service_0_11_1  free_load_conservation_881  -6
    service_0_11_1  original_T_including_depot_unload_886  720
    service_0_11_2  unique_nonzero_owner_448  1
    service_0_11_2  service_visit_def_880  1
    service_0_11_2  free_load_conservation_881  -5
    service_0_11_2  original_T_including_depot_unload_886  600
    service_0_11_3  unique_nonzero_owner_449  1
    service_0_11_3  service_visit_def_880  1
    service_0_11_3  free_load_conservation_881  -4
    service_0_11_3  original_T_including_depot_unload_886  480
    service_0_11_4  unique_nonzero_owner_450  1
    service_0_11_4  service_visit_def_880  1
    service_0_11_4  free_load_conservation_881  -3
    service_0_11_4  original_T_including_depot_unload_886  360
    service_0_11_5  unique_nonzero_owner_451  1
    service_0_11_5  service_visit_def_880  1
    service_0_11_5  free_load_conservation_881  -2
    service_0_11_5  original_T_including_depot_unload_886  240
    service_0_11_6  unique_nonzero_owner_452  1
    service_0_11_6  service_visit_def_880  1
    service_0_11_6  free_load_conservation_881  -1
    service_0_11_6  original_T_including_depot_unload_886  120
    service_0_11_8  unique_nonzero_owner_453  1
    service_0_11_8  service_visit_def_880  1
    service_0_11_8  free_load_conservation_881  1
    service_0_11_9  unique_nonzero_owner_454  1
    service_0_11_9  service_visit_def_880  1
    service_0_11_9  free_load_conservation_881  2
    service_0_11_10  unique_nonzero_owner_455  1
    service_0_11_10  service_visit_def_880  1
    service_0_11_10  free_load_conservation_881  3
    service_0_11_11  unique_nonzero_owner_456  1
    service_0_11_11  service_visit_def_880  1
    service_0_11_11  free_load_conservation_881  4
    service_0_11_12  unique_nonzero_owner_457  1
    service_0_11_12  service_visit_def_880  1
    service_0_11_12  free_load_conservation_881  5
    service_1_11_0  unique_nonzero_owner_446  1
    service_1_11_0  service_visit_def_1309  1
    service_1_11_0  free_load_conservation_1310  -7
    service_1_11_0  original_T_including_depot_unload_1315  840
    service_1_11_1  unique_nonzero_owner_447  1
    service_1_11_1  service_visit_def_1309  1
    service_1_11_1  free_load_conservation_1310  -6
    service_1_11_1  original_T_including_depot_unload_1315  720
    service_1_11_2  unique_nonzero_owner_448  1
    service_1_11_2  service_visit_def_1309  1
    service_1_11_2  free_load_conservation_1310  -5
    service_1_11_2  original_T_including_depot_unload_1315  600
    service_1_11_3  unique_nonzero_owner_449  1
    service_1_11_3  service_visit_def_1309  1
    service_1_11_3  free_load_conservation_1310  -4
    service_1_11_3  original_T_including_depot_unload_1315  480
    service_1_11_4  unique_nonzero_owner_450  1
    service_1_11_4  service_visit_def_1309  1
    service_1_11_4  free_load_conservation_1310  -3
    service_1_11_4  original_T_including_depot_unload_1315  360
    service_1_11_5  unique_nonzero_owner_451  1
    service_1_11_5  service_visit_def_1309  1
    service_1_11_5  free_load_conservation_1310  -2
    service_1_11_5  original_T_including_depot_unload_1315  240
    service_1_11_6  unique_nonzero_owner_452  1
    service_1_11_6  service_visit_def_1309  1
    service_1_11_6  free_load_conservation_1310  -1
    service_1_11_6  original_T_including_depot_unload_1315  120
    service_1_11_8  unique_nonzero_owner_453  1
    service_1_11_8  service_visit_def_1309  1
    service_1_11_8  free_load_conservation_1310  1
    service_1_11_9  unique_nonzero_owner_454  1
    service_1_11_9  service_visit_def_1309  1
    service_1_11_9  free_load_conservation_1310  2
    service_1_11_10  unique_nonzero_owner_455  1
    service_1_11_10  service_visit_def_1309  1
    service_1_11_10  free_load_conservation_1310  3
    service_1_11_11  unique_nonzero_owner_456  1
    service_1_11_11  service_visit_def_1309  1
    service_1_11_11  free_load_conservation_1310  4
    service_1_11_12  unique_nonzero_owner_457  1
    service_1_11_12  service_visit_def_1309  1
    service_1_11_12  free_load_conservation_1310  5
    service_2_11_0  unique_nonzero_owner_446  1
    service_2_11_0  service_visit_def_1628  1
    service_2_11_0  free_load_conservation_1629  -7
    service_2_11_0  original_T_including_depot_unload_1632  840
    service_2_11_1  unique_nonzero_owner_447  1
    service_2_11_1  service_visit_def_1628  1
    service_2_11_1  free_load_conservation_1629  -6
    service_2_11_1  original_T_including_depot_unload_1632  720
    service_2_11_2  unique_nonzero_owner_448  1
    service_2_11_2  service_visit_def_1628  1
    service_2_11_2  free_load_conservation_1629  -5
    service_2_11_2  original_T_including_depot_unload_1632  600
    service_2_11_3  unique_nonzero_owner_449  1
    service_2_11_3  service_visit_def_1628  1
    service_2_11_3  free_load_conservation_1629  -4
    service_2_11_3  original_T_including_depot_unload_1632  480
    service_2_11_4  unique_nonzero_owner_450  1
    service_2_11_4  service_visit_def_1628  1
    service_2_11_4  free_load_conservation_1629  -3
    service_2_11_4  original_T_including_depot_unload_1632  360
    service_2_11_5  unique_nonzero_owner_451  1
    service_2_11_5  service_visit_def_1628  1
    service_2_11_5  free_load_conservation_1629  -2
    service_2_11_5  original_T_including_depot_unload_1632  240
    service_2_11_6  unique_nonzero_owner_452  1
    service_2_11_6  service_visit_def_1628  1
    service_2_11_6  free_load_conservation_1629  -1
    service_2_11_6  original_T_including_depot_unload_1632  120
    service_2_11_8  unique_nonzero_owner_453  1
    service_2_11_8  service_visit_def_1628  1
    service_2_11_8  free_load_conservation_1629  1
    service_2_11_9  unique_nonzero_owner_454  1
    service_2_11_9  service_visit_def_1628  1
    service_2_11_9  free_load_conservation_1629  2
    service_2_11_10  unique_nonzero_owner_455  1
    service_2_11_10  service_visit_def_1628  1
    service_2_11_10  free_load_conservation_1629  3
    service_2_11_11  unique_nonzero_owner_456  1
    service_2_11_11  service_visit_def_1628  1
    service_2_11_11  free_load_conservation_1629  4
    service_2_11_12  unique_nonzero_owner_457  1
    service_2_11_12  service_visit_def_1628  1
    service_2_11_12  free_load_conservation_1629  5
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_799  -1
    visit_0_1  in_degree_800  -1
    visit_0_1  order_active_lb_801  -1
    visit_0_1  order_active_ub_802  -13
    order_0_1  connected_order_arc_474  -1
    order_0_1  connected_order_arc_476  -1
    order_0_1  connected_order_arc_478  -1
    order_0_1  connected_order_arc_480  -1
    order_0_1  connected_order_arc_482  -1
    order_0_1  connected_order_arc_484  -1
    order_0_1  connected_order_arc_486  -1
    order_0_1  connected_order_arc_488  -1
    order_0_1  connected_order_arc_490  -1
    order_0_1  connected_order_arc_492  -1
    order_0_1  connected_order_arc_494  -1
    order_0_1  connected_order_arc_496  -1
    order_0_1  connected_order_arc_499  1
    order_0_1  connected_order_arc_524  1
    order_0_1  connected_order_arc_549  1
    order_0_1  connected_order_arc_574  1
    order_0_1  connected_order_arc_599  1
    order_0_1  connected_order_arc_624  1
    order_0_1  connected_order_arc_649  1
    order_0_1  connected_order_arc_674  1
    order_0_1  connected_order_arc_699  1
    order_0_1  connected_order_arc_724  1
    order_0_1  connected_order_arc_749  1
    order_0_1  connected_order_arc_774  1
    order_0_1  order_active_lb_801  1
    order_0_1  order_active_ub_802  1
    order_0_1  fixed_segment_relative_order_882  -1
    visit_0_2  out_degree_806  -1
    visit_0_2  in_degree_807  -1
    visit_0_2  order_active_lb_808  -1
    visit_0_2  order_active_ub_809  -13
    order_0_2  connected_order_arc_474  1
    order_0_2  connected_order_arc_499  -1
    order_0_2  connected_order_arc_501  -1
    order_0_2  connected_order_arc_503  -1
    order_0_2  connected_order_arc_505  -1
    order_0_2  connected_order_arc_507  -1
    order_0_2  connected_order_arc_509  -1
    order_0_2  connected_order_arc_511  -1
    order_0_2  connected_order_arc_513  -1
    order_0_2  connected_order_arc_515  -1
    order_0_2  connected_order_arc_517  -1
    order_0_2  connected_order_arc_519  -1
    order_0_2  connected_order_arc_521  -1
    order_0_2  connected_order_arc_526  1
    order_0_2  connected_order_arc_551  1
    order_0_2  connected_order_arc_576  1
    order_0_2  connected_order_arc_601  1
    order_0_2  connected_order_arc_626  1
    order_0_2  connected_order_arc_651  1
    order_0_2  connected_order_arc_676  1
    order_0_2  connected_order_arc_701  1
    order_0_2  connected_order_arc_726  1
    order_0_2  connected_order_arc_751  1
    order_0_2  connected_order_arc_776  1
    order_0_2  order_active_lb_808  1
    order_0_2  order_active_ub_809  1
    order_0_2  fixed_segment_relative_order_882  1
    order_0_2  fixed_segment_relative_order_883  -1
    visit_0_3  out_degree_813  -1
    visit_0_3  in_degree_814  -1
    visit_0_3  order_active_lb_815  -1
    visit_0_3  order_active_ub_816  -13
    order_0_3  connected_order_arc_476  1
    order_0_3  connected_order_arc_501  1
    order_0_3  connected_order_arc_524  -1
    order_0_3  connected_order_arc_526  -1
    order_0_3  connected_order_arc_528  -1
    order_0_3  connected_order_arc_530  -1
    order_0_3  connected_order_arc_532  -1
    order_0_3  connected_order_arc_534  -1
    order_0_3  connected_order_arc_536  -1
    order_0_3  connected_order_arc_538  -1
    order_0_3  connected_order_arc_540  -1
    order_0_3  connected_order_arc_542  -1
    order_0_3  connected_order_arc_544  -1
    order_0_3  connected_order_arc_546  -1
    order_0_3  connected_order_arc_553  1
    order_0_3  connected_order_arc_578  1
    order_0_3  connected_order_arc_603  1
    order_0_3  connected_order_arc_628  1
    order_0_3  connected_order_arc_653  1
    order_0_3  connected_order_arc_678  1
    order_0_3  connected_order_arc_703  1
    order_0_3  connected_order_arc_728  1
    order_0_3  connected_order_arc_753  1
    order_0_3  connected_order_arc_778  1
    order_0_3  order_active_lb_815  1
    order_0_3  order_active_ub_816  1
    order_0_3  fixed_segment_relative_order_883  1
    order_0_3  fixed_segment_relative_order_884  -1
    visit_0_4  out_degree_820  -1
    visit_0_4  in_degree_821  -1
    visit_0_4  order_active_lb_822  -1
    visit_0_4  order_active_ub_823  -13
    order_0_4  connected_order_arc_478  1
    order_0_4  connected_order_arc_503  1
    order_0_4  connected_order_arc_528  1
    order_0_4  connected_order_arc_549  -1
    order_0_4  connected_order_arc_551  -1
    order_0_4  connected_order_arc_553  -1
    order_0_4  connected_order_arc_555  -1
    order_0_4  connected_order_arc_557  -1
    order_0_4  connected_order_arc_559  -1
    order_0_4  connected_order_arc_561  -1
    order_0_4  connected_order_arc_563  -1
    order_0_4  connected_order_arc_565  -1
    order_0_4  connected_order_arc_567  -1
    order_0_4  connected_order_arc_569  -1
    order_0_4  connected_order_arc_571  -1
    order_0_4  connected_order_arc_580  1
    order_0_4  connected_order_arc_605  1
    order_0_4  connected_order_arc_630  1
    order_0_4  connected_order_arc_655  1
    order_0_4  connected_order_arc_680  1
    order_0_4  connected_order_arc_705  1
    order_0_4  connected_order_arc_730  1
    order_0_4  connected_order_arc_755  1
    order_0_4  connected_order_arc_780  1
    order_0_4  order_active_lb_822  1
    order_0_4  order_active_ub_823  1
    order_0_4  fixed_segment_relative_order_884  1
    order_0_4  fixed_segment_relative_order_885  -1
    visit_0_5  out_degree_827  -1
    visit_0_5  in_degree_828  -1
    visit_0_5  order_active_lb_829  -1
    visit_0_5  order_active_ub_830  -13
    order_0_5  connected_order_arc_480  1
    order_0_5  connected_order_arc_505  1
    order_0_5  connected_order_arc_530  1
    order_0_5  connected_order_arc_555  1
    order_0_5  connected_order_arc_574  -1
    order_0_5  connected_order_arc_576  -1
    order_0_5  connected_order_arc_578  -1
    order_0_5  connected_order_arc_580  -1
    order_0_5  connected_order_arc_582  -1
    order_0_5  connected_order_arc_584  -1
    order_0_5  connected_order_arc_586  -1
    order_0_5  connected_order_arc_588  -1
    order_0_5  connected_order_arc_590  -1
    order_0_5  connected_order_arc_592  -1
    order_0_5  connected_order_arc_594  -1
    order_0_5  connected_order_arc_596  -1
    order_0_5  connected_order_arc_607  1
    order_0_5  connected_order_arc_632  1
    order_0_5  connected_order_arc_657  1
    order_0_5  connected_order_arc_682  1
    order_0_5  connected_order_arc_707  1
    order_0_5  connected_order_arc_732  1
    order_0_5  connected_order_arc_757  1
    order_0_5  connected_order_arc_782  1
    order_0_5  order_active_lb_829  1
    order_0_5  order_active_ub_830  1
    order_0_5  fixed_segment_relative_order_885  1
    visit_0_14  out_degree_834  -1
    visit_0_14  in_degree_835  -1
    visit_0_14  order_active_lb_836  -1
    visit_0_14  order_active_ub_837  -13
    visit_0_14  service_visit_def_838  -1
    order_0_14  connected_order_arc_482  1
    order_0_14  connected_order_arc_507  1
    order_0_14  connected_order_arc_532  1
    order_0_14  connected_order_arc_557  1
    order_0_14  connected_order_arc_582  1
    order_0_14  connected_order_arc_599  -1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_603  -1
    order_0_14  connected_order_arc_605  -1
    order_0_14  connected_order_arc_607  -1
    order_0_14  connected_order_arc_609  -1
    order_0_14  connected_order_arc_611  -1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_619  -1
    order_0_14  connected_order_arc_621  -1
    order_0_14  connected_order_arc_634  1
    order_0_14  connected_order_arc_659  1
    order_0_14  connected_order_arc_684  1
    order_0_14  connected_order_arc_709  1
    order_0_14  connected_order_arc_734  1
    order_0_14  connected_order_arc_759  1
    order_0_14  connected_order_arc_784  1
    order_0_14  order_active_lb_836  1
    order_0_14  order_active_ub_837  1
    visit_0_15  out_degree_840  -1
    visit_0_15  in_degree_841  -1
    visit_0_15  order_active_lb_842  -1
    visit_0_15  order_active_ub_843  -13
    visit_0_15  service_visit_def_844  -1
    order_0_15  connected_order_arc_484  1
    order_0_15  connected_order_arc_509  1
    order_0_15  connected_order_arc_534  1
    order_0_15  connected_order_arc_559  1
    order_0_15  connected_order_arc_584  1
    order_0_15  connected_order_arc_609  1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_628  -1
    order_0_15  connected_order_arc_630  -1
    order_0_15  connected_order_arc_632  -1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_646  -1
    order_0_15  connected_order_arc_661  1
    order_0_15  connected_order_arc_686  1
    order_0_15  connected_order_arc_711  1
    order_0_15  connected_order_arc_736  1
    order_0_15  connected_order_arc_761  1
    order_0_15  connected_order_arc_786  1
    order_0_15  order_active_lb_842  1
    order_0_15  order_active_ub_843  1
    visit_0_16  out_degree_846  -1
    visit_0_16  in_degree_847  -1
    visit_0_16  order_active_lb_848  -1
    visit_0_16  order_active_ub_849  -13
    visit_0_16  service_visit_def_850  -1
    order_0_16  connected_order_arc_486  1
    order_0_16  connected_order_arc_511  1
    order_0_16  connected_order_arc_536  1
    order_0_16  connected_order_arc_561  1
    order_0_16  connected_order_arc_586  1
    order_0_16  connected_order_arc_611  1
    order_0_16  connected_order_arc_636  1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_653  -1
    order_0_16  connected_order_arc_655  -1
    order_0_16  connected_order_arc_657  -1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_665  -1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_671  -1
    order_0_16  connected_order_arc_688  1
    order_0_16  connected_order_arc_713  1
    order_0_16  connected_order_arc_738  1
    order_0_16  connected_order_arc_763  1
    order_0_16  connected_order_arc_788  1
    order_0_16  order_active_lb_848  1
    order_0_16  order_active_ub_849  1
    visit_0_17  out_degree_852  -1
    visit_0_17  in_degree_853  -1
    visit_0_17  order_active_lb_854  -1
    visit_0_17  order_active_ub_855  -13
    visit_0_17  service_visit_def_856  -1
    order_0_17  connected_order_arc_488  1
    order_0_17  connected_order_arc_513  1
    order_0_17  connected_order_arc_538  1
    order_0_17  connected_order_arc_563  1
    order_0_17  connected_order_arc_588  1
    order_0_17  connected_order_arc_613  1
    order_0_17  connected_order_arc_638  1
    order_0_17  connected_order_arc_663  1
    order_0_17  connected_order_arc_674  -1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_678  -1
    order_0_17  connected_order_arc_680  -1
    order_0_17  connected_order_arc_682  -1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_690  -1
    order_0_17  connected_order_arc_692  -1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_696  -1
    order_0_17  connected_order_arc_715  1
    order_0_17  connected_order_arc_740  1
    order_0_17  connected_order_arc_765  1
    order_0_17  connected_order_arc_790  1
    order_0_17  order_active_lb_854  1
    order_0_17  order_active_ub_855  1
    visit_0_18  out_degree_858  -1
    visit_0_18  in_degree_859  -1
    visit_0_18  order_active_lb_860  -1
    visit_0_18  order_active_ub_861  -13
    visit_0_18  service_visit_def_862  -1
    order_0_18  connected_order_arc_490  1
    order_0_18  connected_order_arc_515  1
    order_0_18  connected_order_arc_540  1
    order_0_18  connected_order_arc_565  1
    order_0_18  connected_order_arc_590  1
    order_0_18  connected_order_arc_615  1
    order_0_18  connected_order_arc_640  1
    order_0_18  connected_order_arc_665  1
    order_0_18  connected_order_arc_690  1
    order_0_18  connected_order_arc_699  -1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_703  -1
    order_0_18  connected_order_arc_705  -1
    order_0_18  connected_order_arc_707  -1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_717  -1
    order_0_18  connected_order_arc_719  -1
    order_0_18  connected_order_arc_721  -1
    order_0_18  connected_order_arc_742  1
    order_0_18  connected_order_arc_767  1
    order_0_18  connected_order_arc_792  1
    order_0_18  order_active_lb_860  1
    order_0_18  order_active_ub_861  1
    visit_0_19  out_degree_864  -1
    visit_0_19  in_degree_865  -1
    visit_0_19  order_active_lb_866  -1
    visit_0_19  order_active_ub_867  -13
    visit_0_19  service_visit_def_868  -1
    order_0_19  connected_order_arc_492  1
    order_0_19  connected_order_arc_517  1
    order_0_19  connected_order_arc_542  1
    order_0_19  connected_order_arc_567  1
    order_0_19  connected_order_arc_592  1
    order_0_19  connected_order_arc_617  1
    order_0_19  connected_order_arc_642  1
    order_0_19  connected_order_arc_667  1
    order_0_19  connected_order_arc_692  1
    order_0_19  connected_order_arc_717  1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_728  -1
    order_0_19  connected_order_arc_730  -1
    order_0_19  connected_order_arc_732  -1
    order_0_19  connected_order_arc_734  -1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_744  -1
    order_0_19  connected_order_arc_746  -1
    order_0_19  connected_order_arc_769  1
    order_0_19  connected_order_arc_794  1
    order_0_19  order_active_lb_866  1
    order_0_19  order_active_ub_867  1
    visit_0_20  out_degree_870  -1
    visit_0_20  in_degree_871  -1
    visit_0_20  order_active_lb_872  -1
    visit_0_20  order_active_ub_873  -13
    visit_0_20  service_visit_def_874  -1
    order_0_20  connected_order_arc_494  1
    order_0_20  connected_order_arc_519  1
    order_0_20  connected_order_arc_544  1
    order_0_20  connected_order_arc_569  1
    order_0_20  connected_order_arc_594  1
    order_0_20  connected_order_arc_619  1
    order_0_20  connected_order_arc_644  1
    order_0_20  connected_order_arc_669  1
    order_0_20  connected_order_arc_694  1
    order_0_20  connected_order_arc_719  1
    order_0_20  connected_order_arc_744  1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  connected_order_arc_753  -1
    order_0_20  connected_order_arc_755  -1
    order_0_20  connected_order_arc_757  -1
    order_0_20  connected_order_arc_759  -1
    order_0_20  connected_order_arc_761  -1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  connected_order_arc_769  -1
    order_0_20  connected_order_arc_771  -1
    order_0_20  connected_order_arc_796  1
    order_0_20  order_active_lb_872  1
    order_0_20  order_active_ub_873  1
    visit_0_21  out_degree_876  -1
    visit_0_21  in_degree_877  -1
    visit_0_21  order_active_lb_878  -1
    visit_0_21  order_active_ub_879  -13
    visit_0_21  service_visit_def_880  -1
    order_0_21  connected_order_arc_496  1
    order_0_21  connected_order_arc_521  1
    order_0_21  connected_order_arc_546  1
    order_0_21  connected_order_arc_571  1
    order_0_21  connected_order_arc_596  1
    order_0_21  connected_order_arc_621  1
    order_0_21  connected_order_arc_646  1
    order_0_21  connected_order_arc_671  1
    order_0_21  connected_order_arc_696  1
    order_0_21  connected_order_arc_721  1
    order_0_21  connected_order_arc_746  1
    order_0_21  connected_order_arc_771  1
    order_0_21  connected_order_arc_774  -1
    order_0_21  connected_order_arc_776  -1
    order_0_21  connected_order_arc_778  -1
    order_0_21  connected_order_arc_780  -1
    order_0_21  connected_order_arc_782  -1
    order_0_21  connected_order_arc_784  -1
    order_0_21  connected_order_arc_786  -1
    order_0_21  connected_order_arc_788  -1
    order_0_21  connected_order_arc_790  -1
    order_0_21  connected_order_arc_792  -1
    order_0_21  connected_order_arc_794  -1
    order_0_21  connected_order_arc_796  -1
    order_0_21  order_active_lb_878  1
    order_0_21  order_active_ub_879  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_458  -20
    arc_0_0_0  depot_departure_or_bypass_797  1
    arc_0_0_0  depot_return_or_bypass_798  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_458  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_459  -20
    arc_0_0_1  depot_departure_or_bypass_797  1
    arc_0_0_1  in_degree_800  1
    arc_0_0_1  original_T_including_depot_unload_886  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_459  1
    load_0_0_1  segment_load_conservation_803  -1
    load_0_0_1  segment_prefix_lb_804  1
    load_0_0_1  segment_prefix_ub_805  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_460  -20
    arc_0_0_2  depot_departure_or_bypass_797  1
    arc_0_0_2  in_degree_807  1
    arc_0_0_2  original_T_including_depot_unload_886  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_460  1
    load_0_0_2  segment_load_conservation_810  -1
    load_0_0_2  segment_prefix_lb_811  1
    load_0_0_2  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_461  -20
    arc_0_0_3  depot_departure_or_bypass_797  1
    arc_0_0_3  in_degree_814  1
    arc_0_0_3  original_T_including_depot_unload_886  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_461  1
    load_0_0_3  segment_load_conservation_817  -1
    load_0_0_3  segment_prefix_lb_818  1
    load_0_0_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_462  -20
    arc_0_0_4  depot_departure_or_bypass_797  1
    arc_0_0_4  in_degree_821  1
    arc_0_0_4  original_T_including_depot_unload_886  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_462  1
    load_0_0_4  segment_load_conservation_824  -1
    load_0_0_4  segment_prefix_lb_825  1
    load_0_0_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_463  -20
    arc_0_0_5  depot_departure_or_bypass_797  1
    arc_0_0_5  in_degree_828  1
    arc_0_0_5  original_T_including_depot_unload_886  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_463  1
    load_0_0_5  segment_load_conservation_831  -1
    load_0_0_5  segment_prefix_lb_832  1
    load_0_0_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_464  -20
    arc_0_0_14  depot_departure_or_bypass_797  1
    arc_0_0_14  in_degree_835  1
    arc_0_0_14  original_T_including_depot_unload_886  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_464  1
    load_0_0_14  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_465  -20
    arc_0_0_15  depot_departure_or_bypass_797  1
    arc_0_0_15  in_degree_841  1
    arc_0_0_15  original_T_including_depot_unload_886  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_465  1
    load_0_0_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_466  -20
    arc_0_0_16  depot_departure_or_bypass_797  1
    arc_0_0_16  in_degree_847  1
    arc_0_0_16  original_T_including_depot_unload_886  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_466  1
    load_0_0_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_467  -20
    arc_0_0_17  depot_departure_or_bypass_797  1
    arc_0_0_17  in_degree_853  1
    arc_0_0_17  original_T_including_depot_unload_886  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_467  1
    load_0_0_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_468  -20
    arc_0_0_18  depot_departure_or_bypass_797  1
    arc_0_0_18  in_degree_859  1
    arc_0_0_18  original_T_including_depot_unload_886  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_468  1
    load_0_0_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_469  -20
    arc_0_0_19  depot_departure_or_bypass_797  1
    arc_0_0_19  in_degree_865  1
    arc_0_0_19  original_T_including_depot_unload_886  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_469  1
    load_0_0_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_470  -20
    arc_0_0_20  depot_departure_or_bypass_797  1
    arc_0_0_20  in_degree_871  1
    arc_0_0_20  original_T_including_depot_unload_886  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_470  1
    load_0_0_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_471  -20
    arc_0_0_21  depot_departure_or_bypass_797  1
    arc_0_0_21  in_degree_877  1
    arc_0_0_21  original_T_including_depot_unload_886  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_471  1
    load_0_0_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_472  -20
    arc_0_1_0  depot_return_or_bypass_798  1
    arc_0_1_0  out_degree_799  1
    arc_0_1_0  original_T_including_depot_unload_886  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_472  1
    load_0_1_0  segment_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_473  -20
    arc_0_1_2  connected_order_arc_474  -14
    arc_0_1_2  out_degree_799  1
    arc_0_1_2  in_degree_807  1
    arc_0_1_2  original_T_including_depot_unload_886  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_473  1
    load_0_1_2  segment_load_conservation_803  1
    load_0_1_2  segment_load_conservation_810  -1
    load_0_1_2  segment_prefix_lb_811  1
    load_0_1_2  segment_prefix_ub_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_475  -20
    arc_0_1_3  connected_order_arc_476  -14
    arc_0_1_3  out_degree_799  1
    arc_0_1_3  in_degree_814  1
    arc_0_1_3  original_T_including_depot_unload_886  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_475  1
    load_0_1_3  segment_load_conservation_803  1
    load_0_1_3  segment_load_conservation_817  -1
    load_0_1_3  segment_prefix_lb_818  1
    load_0_1_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_477  -20
    arc_0_1_4  connected_order_arc_478  -14
    arc_0_1_4  out_degree_799  1
    arc_0_1_4  in_degree_821  1
    arc_0_1_4  original_T_including_depot_unload_886  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_477  1
    load_0_1_4  segment_load_conservation_803  1
    load_0_1_4  segment_load_conservation_824  -1
    load_0_1_4  segment_prefix_lb_825  1
    load_0_1_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_479  -20
    arc_0_1_5  connected_order_arc_480  -14
    arc_0_1_5  out_degree_799  1
    arc_0_1_5  in_degree_828  1
    arc_0_1_5  original_T_including_depot_unload_886  1.0687086794720833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_479  1
    load_0_1_5  segment_load_conservation_803  1
    load_0_1_5  segment_load_conservation_831  -1
    load_0_1_5  segment_prefix_lb_832  1
    load_0_1_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_481  -20
    arc_0_1_14  connected_order_arc_482  -14
    arc_0_1_14  out_degree_799  1
    arc_0_1_14  in_degree_835  1
    arc_0_1_14  original_T_including_depot_unload_886  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_481  1
    load_0_1_14  segment_load_conservation_803  1
    load_0_1_14  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_483  -20
    arc_0_1_15  connected_order_arc_484  -14
    arc_0_1_15  out_degree_799  1
    arc_0_1_15  in_degree_841  1
    arc_0_1_15  original_T_including_depot_unload_886  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_483  1
    load_0_1_15  segment_load_conservation_803  1
    load_0_1_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_485  -20
    arc_0_1_16  connected_order_arc_486  -14
    arc_0_1_16  out_degree_799  1
    arc_0_1_16  in_degree_847  1
    arc_0_1_16  original_T_including_depot_unload_886  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_485  1
    load_0_1_16  segment_load_conservation_803  1
    load_0_1_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_487  -20
    arc_0_1_17  connected_order_arc_488  -14
    arc_0_1_17  out_degree_799  1
    arc_0_1_17  in_degree_853  1
    arc_0_1_17  original_T_including_depot_unload_886  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_487  1
    load_0_1_17  segment_load_conservation_803  1
    load_0_1_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_489  -20
    arc_0_1_18  connected_order_arc_490  -14
    arc_0_1_18  out_degree_799  1
    arc_0_1_18  in_degree_859  1
    arc_0_1_18  original_T_including_depot_unload_886  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_489  1
    load_0_1_18  segment_load_conservation_803  1
    load_0_1_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_491  -20
    arc_0_1_19  connected_order_arc_492  -14
    arc_0_1_19  out_degree_799  1
    arc_0_1_19  in_degree_865  1
    arc_0_1_19  original_T_including_depot_unload_886  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_491  1
    load_0_1_19  segment_load_conservation_803  1
    load_0_1_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_493  -20
    arc_0_1_20  connected_order_arc_494  -14
    arc_0_1_20  out_degree_799  1
    arc_0_1_20  in_degree_871  1
    arc_0_1_20  original_T_including_depot_unload_886  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_493  1
    load_0_1_20  segment_load_conservation_803  1
    load_0_1_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_495  -20
    arc_0_1_21  connected_order_arc_496  -14
    arc_0_1_21  out_degree_799  1
    arc_0_1_21  in_degree_877  1
    arc_0_1_21  original_T_including_depot_unload_886  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_495  1
    load_0_1_21  segment_load_conservation_803  1
    load_0_1_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_497  -20
    arc_0_2_0  depot_return_or_bypass_798  1
    arc_0_2_0  out_degree_806  1
    arc_0_2_0  original_T_including_depot_unload_886  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_497  1
    load_0_2_0  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_498  -20
    arc_0_2_1  connected_order_arc_499  -14
    arc_0_2_1  in_degree_800  1
    arc_0_2_1  out_degree_806  1
    arc_0_2_1  original_T_including_depot_unload_886  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_498  1
    load_0_2_1  segment_load_conservation_803  -1
    load_0_2_1  segment_prefix_lb_804  1
    load_0_2_1  segment_prefix_ub_805  1
    load_0_2_1  segment_load_conservation_810  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_500  -20
    arc_0_2_3  connected_order_arc_501  -14
    arc_0_2_3  out_degree_806  1
    arc_0_2_3  in_degree_814  1
    arc_0_2_3  original_T_including_depot_unload_886  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_500  1
    load_0_2_3  segment_load_conservation_810  1
    load_0_2_3  segment_load_conservation_817  -1
    load_0_2_3  segment_prefix_lb_818  1
    load_0_2_3  segment_prefix_ub_819  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_502  -20
    arc_0_2_4  connected_order_arc_503  -14
    arc_0_2_4  out_degree_806  1
    arc_0_2_4  in_degree_821  1
    arc_0_2_4  original_T_including_depot_unload_886  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_502  1
    load_0_2_4  segment_load_conservation_810  1
    load_0_2_4  segment_load_conservation_824  -1
    load_0_2_4  segment_prefix_lb_825  1
    load_0_2_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_504  -20
    arc_0_2_5  connected_order_arc_505  -14
    arc_0_2_5  out_degree_806  1
    arc_0_2_5  in_degree_828  1
    arc_0_2_5  original_T_including_depot_unload_886  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_504  1
    load_0_2_5  segment_load_conservation_810  1
    load_0_2_5  segment_load_conservation_831  -1
    load_0_2_5  segment_prefix_lb_832  1
    load_0_2_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_506  -20
    arc_0_2_14  connected_order_arc_507  -14
    arc_0_2_14  out_degree_806  1
    arc_0_2_14  in_degree_835  1
    arc_0_2_14  original_T_including_depot_unload_886  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_506  1
    load_0_2_14  segment_load_conservation_810  1
    load_0_2_14  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_508  -20
    arc_0_2_15  connected_order_arc_509  -14
    arc_0_2_15  out_degree_806  1
    arc_0_2_15  in_degree_841  1
    arc_0_2_15  original_T_including_depot_unload_886  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_508  1
    load_0_2_15  segment_load_conservation_810  1
    load_0_2_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_510  -20
    arc_0_2_16  connected_order_arc_511  -14
    arc_0_2_16  out_degree_806  1
    arc_0_2_16  in_degree_847  1
    arc_0_2_16  original_T_including_depot_unload_886  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_510  1
    load_0_2_16  segment_load_conservation_810  1
    load_0_2_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_512  -20
    arc_0_2_17  connected_order_arc_513  -14
    arc_0_2_17  out_degree_806  1
    arc_0_2_17  in_degree_853  1
    arc_0_2_17  original_T_including_depot_unload_886  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_512  1
    load_0_2_17  segment_load_conservation_810  1
    load_0_2_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_514  -20
    arc_0_2_18  connected_order_arc_515  -14
    arc_0_2_18  out_degree_806  1
    arc_0_2_18  in_degree_859  1
    arc_0_2_18  original_T_including_depot_unload_886  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_514  1
    load_0_2_18  segment_load_conservation_810  1
    load_0_2_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_516  -20
    arc_0_2_19  connected_order_arc_517  -14
    arc_0_2_19  out_degree_806  1
    arc_0_2_19  in_degree_865  1
    arc_0_2_19  original_T_including_depot_unload_886  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_516  1
    load_0_2_19  segment_load_conservation_810  1
    load_0_2_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_518  -20
    arc_0_2_20  connected_order_arc_519  -14
    arc_0_2_20  out_degree_806  1
    arc_0_2_20  in_degree_871  1
    arc_0_2_20  original_T_including_depot_unload_886  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_518  1
    load_0_2_20  segment_load_conservation_810  1
    load_0_2_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_520  -20
    arc_0_2_21  connected_order_arc_521  -14
    arc_0_2_21  out_degree_806  1
    arc_0_2_21  in_degree_877  1
    arc_0_2_21  original_T_including_depot_unload_886  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_520  1
    load_0_2_21  segment_load_conservation_810  1
    load_0_2_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_522  -20
    arc_0_3_0  depot_return_or_bypass_798  1
    arc_0_3_0  out_degree_813  1
    arc_0_3_0  original_T_including_depot_unload_886  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_522  1
    load_0_3_0  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_523  -20
    arc_0_3_1  connected_order_arc_524  -14
    arc_0_3_1  in_degree_800  1
    arc_0_3_1  out_degree_813  1
    arc_0_3_1  original_T_including_depot_unload_886  7.7772825846942942e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_523  1
    load_0_3_1  segment_load_conservation_803  -1
    load_0_3_1  segment_prefix_lb_804  1
    load_0_3_1  segment_prefix_ub_805  1
    load_0_3_1  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_525  -20
    arc_0_3_2  connected_order_arc_526  -14
    arc_0_3_2  in_degree_807  1
    arc_0_3_2  out_degree_813  1
    arc_0_3_2  original_T_including_depot_unload_886  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_525  1
    load_0_3_2  segment_load_conservation_810  -1
    load_0_3_2  segment_prefix_lb_811  1
    load_0_3_2  segment_prefix_ub_812  1
    load_0_3_2  segment_load_conservation_817  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_527  -20
    arc_0_3_4  connected_order_arc_528  -14
    arc_0_3_4  out_degree_813  1
    arc_0_3_4  in_degree_821  1
    arc_0_3_4  original_T_including_depot_unload_886  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_527  1
    load_0_3_4  segment_load_conservation_817  1
    load_0_3_4  segment_load_conservation_824  -1
    load_0_3_4  segment_prefix_lb_825  1
    load_0_3_4  segment_prefix_ub_826  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_529  -20
    arc_0_3_5  connected_order_arc_530  -14
    arc_0_3_5  out_degree_813  1
    arc_0_3_5  in_degree_828  1
    arc_0_3_5  original_T_including_depot_unload_886  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_529  1
    load_0_3_5  segment_load_conservation_817  1
    load_0_3_5  segment_load_conservation_831  -1
    load_0_3_5  segment_prefix_lb_832  1
    load_0_3_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_531  -20
    arc_0_3_14  connected_order_arc_532  -14
    arc_0_3_14  out_degree_813  1
    arc_0_3_14  in_degree_835  1
    arc_0_3_14  original_T_including_depot_unload_886  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_531  1
    load_0_3_14  segment_load_conservation_817  1
    load_0_3_14  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_533  -20
    arc_0_3_15  connected_order_arc_534  -14
    arc_0_3_15  out_degree_813  1
    arc_0_3_15  in_degree_841  1
    arc_0_3_15  original_T_including_depot_unload_886  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_533  1
    load_0_3_15  segment_load_conservation_817  1
    load_0_3_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_535  -20
    arc_0_3_16  connected_order_arc_536  -14
    arc_0_3_16  out_degree_813  1
    arc_0_3_16  in_degree_847  1
    arc_0_3_16  original_T_including_depot_unload_886  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_535  1
    load_0_3_16  segment_load_conservation_817  1
    load_0_3_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_537  -20
    arc_0_3_17  connected_order_arc_538  -14
    arc_0_3_17  out_degree_813  1
    arc_0_3_17  in_degree_853  1
    arc_0_3_17  original_T_including_depot_unload_886  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_537  1
    load_0_3_17  segment_load_conservation_817  1
    load_0_3_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_539  -20
    arc_0_3_18  connected_order_arc_540  -14
    arc_0_3_18  out_degree_813  1
    arc_0_3_18  in_degree_859  1
    arc_0_3_18  original_T_including_depot_unload_886  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_539  1
    load_0_3_18  segment_load_conservation_817  1
    load_0_3_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_541  -20
    arc_0_3_19  connected_order_arc_542  -14
    arc_0_3_19  out_degree_813  1
    arc_0_3_19  in_degree_865  1
    arc_0_3_19  original_T_including_depot_unload_886  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_541  1
    load_0_3_19  segment_load_conservation_817  1
    load_0_3_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_543  -20
    arc_0_3_20  connected_order_arc_544  -14
    arc_0_3_20  out_degree_813  1
    arc_0_3_20  in_degree_871  1
    arc_0_3_20  original_T_including_depot_unload_886  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_543  1
    load_0_3_20  segment_load_conservation_817  1
    load_0_3_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_545  -20
    arc_0_3_21  connected_order_arc_546  -14
    arc_0_3_21  out_degree_813  1
    arc_0_3_21  in_degree_877  1
    arc_0_3_21  original_T_including_depot_unload_886  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_545  1
    load_0_3_21  segment_load_conservation_817  1
    load_0_3_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_547  -20
    arc_0_4_0  depot_return_or_bypass_798  1
    arc_0_4_0  out_degree_820  1
    arc_0_4_0  original_T_including_depot_unload_886  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_547  1
    load_0_4_0  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_548  -20
    arc_0_4_1  connected_order_arc_549  -14
    arc_0_4_1  in_degree_800  1
    arc_0_4_1  out_degree_820  1
    arc_0_4_1  original_T_including_depot_unload_886  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_548  1
    load_0_4_1  segment_load_conservation_803  -1
    load_0_4_1  segment_prefix_lb_804  1
    load_0_4_1  segment_prefix_ub_805  1
    load_0_4_1  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_550  -20
    arc_0_4_2  connected_order_arc_551  -14
    arc_0_4_2  in_degree_807  1
    arc_0_4_2  out_degree_820  1
    arc_0_4_2  original_T_including_depot_unload_886  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_550  1
    load_0_4_2  segment_load_conservation_810  -1
    load_0_4_2  segment_prefix_lb_811  1
    load_0_4_2  segment_prefix_ub_812  1
    load_0_4_2  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_552  -20
    arc_0_4_3  connected_order_arc_553  -14
    arc_0_4_3  in_degree_814  1
    arc_0_4_3  out_degree_820  1
    arc_0_4_3  original_T_including_depot_unload_886  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_552  1
    load_0_4_3  segment_load_conservation_817  -1
    load_0_4_3  segment_prefix_lb_818  1
    load_0_4_3  segment_prefix_ub_819  1
    load_0_4_3  segment_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_554  -20
    arc_0_4_5  connected_order_arc_555  -14
    arc_0_4_5  out_degree_820  1
    arc_0_4_5  in_degree_828  1
    arc_0_4_5  original_T_including_depot_unload_886  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_554  1
    load_0_4_5  segment_load_conservation_824  1
    load_0_4_5  segment_load_conservation_831  -1
    load_0_4_5  segment_prefix_lb_832  1
    load_0_4_5  segment_prefix_ub_833  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_556  -20
    arc_0_4_14  connected_order_arc_557  -14
    arc_0_4_14  out_degree_820  1
    arc_0_4_14  in_degree_835  1
    arc_0_4_14  original_T_including_depot_unload_886  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_556  1
    load_0_4_14  segment_load_conservation_824  1
    load_0_4_14  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_558  -20
    arc_0_4_15  connected_order_arc_559  -14
    arc_0_4_15  out_degree_820  1
    arc_0_4_15  in_degree_841  1
    arc_0_4_15  original_T_including_depot_unload_886  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_558  1
    load_0_4_15  segment_load_conservation_824  1
    load_0_4_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_560  -20
    arc_0_4_16  connected_order_arc_561  -14
    arc_0_4_16  out_degree_820  1
    arc_0_4_16  in_degree_847  1
    arc_0_4_16  original_T_including_depot_unload_886  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_560  1
    load_0_4_16  segment_load_conservation_824  1
    load_0_4_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_562  -20
    arc_0_4_17  connected_order_arc_563  -14
    arc_0_4_17  out_degree_820  1
    arc_0_4_17  in_degree_853  1
    arc_0_4_17  original_T_including_depot_unload_886  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_562  1
    load_0_4_17  segment_load_conservation_824  1
    load_0_4_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_564  -20
    arc_0_4_18  connected_order_arc_565  -14
    arc_0_4_18  out_degree_820  1
    arc_0_4_18  in_degree_859  1
    arc_0_4_18  original_T_including_depot_unload_886  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_564  1
    load_0_4_18  segment_load_conservation_824  1
    load_0_4_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_566  -20
    arc_0_4_19  connected_order_arc_567  -14
    arc_0_4_19  out_degree_820  1
    arc_0_4_19  in_degree_865  1
    arc_0_4_19  original_T_including_depot_unload_886  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_566  1
    load_0_4_19  segment_load_conservation_824  1
    load_0_4_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_568  -20
    arc_0_4_20  connected_order_arc_569  -14
    arc_0_4_20  out_degree_820  1
    arc_0_4_20  in_degree_871  1
    arc_0_4_20  original_T_including_depot_unload_886  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_568  1
    load_0_4_20  segment_load_conservation_824  1
    load_0_4_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_570  -20
    arc_0_4_21  connected_order_arc_571  -14
    arc_0_4_21  out_degree_820  1
    arc_0_4_21  in_degree_877  1
    arc_0_4_21  original_T_including_depot_unload_886  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_570  1
    load_0_4_21  segment_load_conservation_824  1
    load_0_4_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_572  -20
    arc_0_5_0  depot_return_or_bypass_798  1
    arc_0_5_0  out_degree_827  1
    arc_0_5_0  original_T_including_depot_unload_886  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_572  1
    load_0_5_0  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_573  -20
    arc_0_5_1  connected_order_arc_574  -14
    arc_0_5_1  in_degree_800  1
    arc_0_5_1  out_degree_827  1
    arc_0_5_1  original_T_including_depot_unload_886  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_573  1
    load_0_5_1  segment_load_conservation_803  -1
    load_0_5_1  segment_prefix_lb_804  1
    load_0_5_1  segment_prefix_ub_805  1
    load_0_5_1  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_575  -20
    arc_0_5_2  connected_order_arc_576  -14
    arc_0_5_2  in_degree_807  1
    arc_0_5_2  out_degree_827  1
    arc_0_5_2  original_T_including_depot_unload_886  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_575  1
    load_0_5_2  segment_load_conservation_810  -1
    load_0_5_2  segment_prefix_lb_811  1
    load_0_5_2  segment_prefix_ub_812  1
    load_0_5_2  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_577  -20
    arc_0_5_3  connected_order_arc_578  -14
    arc_0_5_3  in_degree_814  1
    arc_0_5_3  out_degree_827  1
    arc_0_5_3  original_T_including_depot_unload_886  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_577  1
    load_0_5_3  segment_load_conservation_817  -1
    load_0_5_3  segment_prefix_lb_818  1
    load_0_5_3  segment_prefix_ub_819  1
    load_0_5_3  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_579  -20
    arc_0_5_4  connected_order_arc_580  -14
    arc_0_5_4  in_degree_821  1
    arc_0_5_4  out_degree_827  1
    arc_0_5_4  original_T_including_depot_unload_886  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_579  1
    load_0_5_4  segment_load_conservation_824  -1
    load_0_5_4  segment_prefix_lb_825  1
    load_0_5_4  segment_prefix_ub_826  1
    load_0_5_4  segment_load_conservation_831  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_581  -20
    arc_0_5_14  connected_order_arc_582  -14
    arc_0_5_14  out_degree_827  1
    arc_0_5_14  in_degree_835  1
    arc_0_5_14  original_T_including_depot_unload_886  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_581  1
    load_0_5_14  segment_load_conservation_831  1
    load_0_5_14  free_load_conservation_839  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_583  -20
    arc_0_5_15  connected_order_arc_584  -14
    arc_0_5_15  out_degree_827  1
    arc_0_5_15  in_degree_841  1
    arc_0_5_15  original_T_including_depot_unload_886  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_583  1
    load_0_5_15  segment_load_conservation_831  1
    load_0_5_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_585  -20
    arc_0_5_16  connected_order_arc_586  -14
    arc_0_5_16  out_degree_827  1
    arc_0_5_16  in_degree_847  1
    arc_0_5_16  original_T_including_depot_unload_886  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_585  1
    load_0_5_16  segment_load_conservation_831  1
    load_0_5_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_587  -20
    arc_0_5_17  connected_order_arc_588  -14
    arc_0_5_17  out_degree_827  1
    arc_0_5_17  in_degree_853  1
    arc_0_5_17  original_T_including_depot_unload_886  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_587  1
    load_0_5_17  segment_load_conservation_831  1
    load_0_5_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_589  -20
    arc_0_5_18  connected_order_arc_590  -14
    arc_0_5_18  out_degree_827  1
    arc_0_5_18  in_degree_859  1
    arc_0_5_18  original_T_including_depot_unload_886  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_589  1
    load_0_5_18  segment_load_conservation_831  1
    load_0_5_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_591  -20
    arc_0_5_19  connected_order_arc_592  -14
    arc_0_5_19  out_degree_827  1
    arc_0_5_19  in_degree_865  1
    arc_0_5_19  original_T_including_depot_unload_886  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_591  1
    load_0_5_19  segment_load_conservation_831  1
    load_0_5_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_593  -20
    arc_0_5_20  connected_order_arc_594  -14
    arc_0_5_20  out_degree_827  1
    arc_0_5_20  in_degree_871  1
    arc_0_5_20  original_T_including_depot_unload_886  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_593  1
    load_0_5_20  segment_load_conservation_831  1
    load_0_5_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_595  -20
    arc_0_5_21  connected_order_arc_596  -14
    arc_0_5_21  out_degree_827  1
    arc_0_5_21  in_degree_877  1
    arc_0_5_21  original_T_including_depot_unload_886  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_595  1
    load_0_5_21  segment_load_conservation_831  1
    load_0_5_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_597  -20
    arc_0_14_0  depot_return_or_bypass_798  1
    arc_0_14_0  out_degree_834  1
    arc_0_14_0  original_T_including_depot_unload_886  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_597  1
    load_0_14_0  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_598  -20
    arc_0_14_1  connected_order_arc_599  -14
    arc_0_14_1  in_degree_800  1
    arc_0_14_1  out_degree_834  1
    arc_0_14_1  original_T_including_depot_unload_886  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_598  1
    load_0_14_1  segment_load_conservation_803  -1
    load_0_14_1  segment_prefix_lb_804  1
    load_0_14_1  segment_prefix_ub_805  1
    load_0_14_1  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_600  -20
    arc_0_14_2  connected_order_arc_601  -14
    arc_0_14_2  in_degree_807  1
    arc_0_14_2  out_degree_834  1
    arc_0_14_2  original_T_including_depot_unload_886  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_600  1
    load_0_14_2  segment_load_conservation_810  -1
    load_0_14_2  segment_prefix_lb_811  1
    load_0_14_2  segment_prefix_ub_812  1
    load_0_14_2  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_602  -20
    arc_0_14_3  connected_order_arc_603  -14
    arc_0_14_3  in_degree_814  1
    arc_0_14_3  out_degree_834  1
    arc_0_14_3  original_T_including_depot_unload_886  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_602  1
    load_0_14_3  segment_load_conservation_817  -1
    load_0_14_3  segment_prefix_lb_818  1
    load_0_14_3  segment_prefix_ub_819  1
    load_0_14_3  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_604  -20
    arc_0_14_4  connected_order_arc_605  -14
    arc_0_14_4  in_degree_821  1
    arc_0_14_4  out_degree_834  1
    arc_0_14_4  original_T_including_depot_unload_886  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_604  1
    load_0_14_4  segment_load_conservation_824  -1
    load_0_14_4  segment_prefix_lb_825  1
    load_0_14_4  segment_prefix_ub_826  1
    load_0_14_4  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_606  -20
    arc_0_14_5  connected_order_arc_607  -14
    arc_0_14_5  in_degree_828  1
    arc_0_14_5  out_degree_834  1
    arc_0_14_5  original_T_including_depot_unload_886  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_606  1
    load_0_14_5  segment_load_conservation_831  -1
    load_0_14_5  segment_prefix_lb_832  1
    load_0_14_5  segment_prefix_ub_833  1
    load_0_14_5  free_load_conservation_839  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_608  -20
    arc_0_14_15  connected_order_arc_609  -14
    arc_0_14_15  out_degree_834  1
    arc_0_14_15  in_degree_841  1
    arc_0_14_15  original_T_including_depot_unload_886  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_608  1
    load_0_14_15  free_load_conservation_839  1
    load_0_14_15  free_load_conservation_845  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_610  -20
    arc_0_14_16  connected_order_arc_611  -14
    arc_0_14_16  out_degree_834  1
    arc_0_14_16  in_degree_847  1
    arc_0_14_16  original_T_including_depot_unload_886  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_610  1
    load_0_14_16  free_load_conservation_839  1
    load_0_14_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_612  -20
    arc_0_14_17  connected_order_arc_613  -14
    arc_0_14_17  out_degree_834  1
    arc_0_14_17  in_degree_853  1
    arc_0_14_17  original_T_including_depot_unload_886  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_612  1
    load_0_14_17  free_load_conservation_839  1
    load_0_14_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_614  -20
    arc_0_14_18  connected_order_arc_615  -14
    arc_0_14_18  out_degree_834  1
    arc_0_14_18  in_degree_859  1
    arc_0_14_18  original_T_including_depot_unload_886  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_614  1
    load_0_14_18  free_load_conservation_839  1
    load_0_14_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_616  -20
    arc_0_14_19  connected_order_arc_617  -14
    arc_0_14_19  out_degree_834  1
    arc_0_14_19  in_degree_865  1
    arc_0_14_19  original_T_including_depot_unload_886  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_616  1
    load_0_14_19  free_load_conservation_839  1
    load_0_14_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_618  -20
    arc_0_14_20  connected_order_arc_619  -14
    arc_0_14_20  out_degree_834  1
    arc_0_14_20  in_degree_871  1
    arc_0_14_20  original_T_including_depot_unload_886  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_618  1
    load_0_14_20  free_load_conservation_839  1
    load_0_14_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_620  -20
    arc_0_14_21  connected_order_arc_621  -14
    arc_0_14_21  out_degree_834  1
    arc_0_14_21  in_degree_877  1
    arc_0_14_21  original_T_including_depot_unload_886  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_620  1
    load_0_14_21  free_load_conservation_839  1
    load_0_14_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_622  -20
    arc_0_15_0  depot_return_or_bypass_798  1
    arc_0_15_0  out_degree_840  1
    arc_0_15_0  original_T_including_depot_unload_886  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_622  1
    load_0_15_0  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_623  -20
    arc_0_15_1  connected_order_arc_624  -14
    arc_0_15_1  in_degree_800  1
    arc_0_15_1  out_degree_840  1
    arc_0_15_1  original_T_including_depot_unload_886  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_623  1
    load_0_15_1  segment_load_conservation_803  -1
    load_0_15_1  segment_prefix_lb_804  1
    load_0_15_1  segment_prefix_ub_805  1
    load_0_15_1  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_625  -20
    arc_0_15_2  connected_order_arc_626  -14
    arc_0_15_2  in_degree_807  1
    arc_0_15_2  out_degree_840  1
    arc_0_15_2  original_T_including_depot_unload_886  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_625  1
    load_0_15_2  segment_load_conservation_810  -1
    load_0_15_2  segment_prefix_lb_811  1
    load_0_15_2  segment_prefix_ub_812  1
    load_0_15_2  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_627  -20
    arc_0_15_3  connected_order_arc_628  -14
    arc_0_15_3  in_degree_814  1
    arc_0_15_3  out_degree_840  1
    arc_0_15_3  original_T_including_depot_unload_886  5.9934197761098949e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_627  1
    load_0_15_3  segment_load_conservation_817  -1
    load_0_15_3  segment_prefix_lb_818  1
    load_0_15_3  segment_prefix_ub_819  1
    load_0_15_3  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_629  -20
    arc_0_15_4  connected_order_arc_630  -14
    arc_0_15_4  in_degree_821  1
    arc_0_15_4  out_degree_840  1
    arc_0_15_4  original_T_including_depot_unload_886  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_629  1
    load_0_15_4  segment_load_conservation_824  -1
    load_0_15_4  segment_prefix_lb_825  1
    load_0_15_4  segment_prefix_ub_826  1
    load_0_15_4  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_631  -20
    arc_0_15_5  connected_order_arc_632  -14
    arc_0_15_5  in_degree_828  1
    arc_0_15_5  out_degree_840  1
    arc_0_15_5  original_T_including_depot_unload_886  8.8588784481112123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_631  1
    load_0_15_5  segment_load_conservation_831  -1
    load_0_15_5  segment_prefix_lb_832  1
    load_0_15_5  segment_prefix_ub_833  1
    load_0_15_5  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_633  -20
    arc_0_15_14  connected_order_arc_634  -14
    arc_0_15_14  in_degree_835  1
    arc_0_15_14  out_degree_840  1
    arc_0_15_14  original_T_including_depot_unload_886  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_633  1
    load_0_15_14  free_load_conservation_839  -1
    load_0_15_14  free_load_conservation_845  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_635  -20
    arc_0_15_16  connected_order_arc_636  -14
    arc_0_15_16  out_degree_840  1
    arc_0_15_16  in_degree_847  1
    arc_0_15_16  original_T_including_depot_unload_886  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_635  1
    load_0_15_16  free_load_conservation_845  1
    load_0_15_16  free_load_conservation_851  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_637  -20
    arc_0_15_17  connected_order_arc_638  -14
    arc_0_15_17  out_degree_840  1
    arc_0_15_17  in_degree_853  1
    arc_0_15_17  original_T_including_depot_unload_886  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_637  1
    load_0_15_17  free_load_conservation_845  1
    load_0_15_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_639  -20
    arc_0_15_18  connected_order_arc_640  -14
    arc_0_15_18  out_degree_840  1
    arc_0_15_18  in_degree_859  1
    arc_0_15_18  original_T_including_depot_unload_886  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_639  1
    load_0_15_18  free_load_conservation_845  1
    load_0_15_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_641  -20
    arc_0_15_19  connected_order_arc_642  -14
    arc_0_15_19  out_degree_840  1
    arc_0_15_19  in_degree_865  1
    arc_0_15_19  original_T_including_depot_unload_886  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_641  1
    load_0_15_19  free_load_conservation_845  1
    load_0_15_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_643  -20
    arc_0_15_20  connected_order_arc_644  -14
    arc_0_15_20  out_degree_840  1
    arc_0_15_20  in_degree_871  1
    arc_0_15_20  original_T_including_depot_unload_886  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_643  1
    load_0_15_20  free_load_conservation_845  1
    load_0_15_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_645  -20
    arc_0_15_21  connected_order_arc_646  -14
    arc_0_15_21  out_degree_840  1
    arc_0_15_21  in_degree_877  1
    arc_0_15_21  original_T_including_depot_unload_886  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_645  1
    load_0_15_21  free_load_conservation_845  1
    load_0_15_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_647  -20
    arc_0_16_0  depot_return_or_bypass_798  1
    arc_0_16_0  out_degree_846  1
    arc_0_16_0  original_T_including_depot_unload_886  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_647  1
    load_0_16_0  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_648  -20
    arc_0_16_1  connected_order_arc_649  -14
    arc_0_16_1  in_degree_800  1
    arc_0_16_1  out_degree_846  1
    arc_0_16_1  original_T_including_depot_unload_886  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_648  1
    load_0_16_1  segment_load_conservation_803  -1
    load_0_16_1  segment_prefix_lb_804  1
    load_0_16_1  segment_prefix_ub_805  1
    load_0_16_1  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_650  -20
    arc_0_16_2  connected_order_arc_651  -14
    arc_0_16_2  in_degree_807  1
    arc_0_16_2  out_degree_846  1
    arc_0_16_2  original_T_including_depot_unload_886  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_650  1
    load_0_16_2  segment_load_conservation_810  -1
    load_0_16_2  segment_prefix_lb_811  1
    load_0_16_2  segment_prefix_ub_812  1
    load_0_16_2  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_652  -20
    arc_0_16_3  connected_order_arc_653  -14
    arc_0_16_3  in_degree_814  1
    arc_0_16_3  out_degree_846  1
    arc_0_16_3  original_T_including_depot_unload_886  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_652  1
    load_0_16_3  segment_load_conservation_817  -1
    load_0_16_3  segment_prefix_lb_818  1
    load_0_16_3  segment_prefix_ub_819  1
    load_0_16_3  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_654  -20
    arc_0_16_4  connected_order_arc_655  -14
    arc_0_16_4  in_degree_821  1
    arc_0_16_4  out_degree_846  1
    arc_0_16_4  original_T_including_depot_unload_886  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_654  1
    load_0_16_4  segment_load_conservation_824  -1
    load_0_16_4  segment_prefix_lb_825  1
    load_0_16_4  segment_prefix_ub_826  1
    load_0_16_4  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_656  -20
    arc_0_16_5  connected_order_arc_657  -14
    arc_0_16_5  in_degree_828  1
    arc_0_16_5  out_degree_846  1
    arc_0_16_5  original_T_including_depot_unload_886  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_656  1
    load_0_16_5  segment_load_conservation_831  -1
    load_0_16_5  segment_prefix_lb_832  1
    load_0_16_5  segment_prefix_ub_833  1
    load_0_16_5  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_658  -20
    arc_0_16_14  connected_order_arc_659  -14
    arc_0_16_14  in_degree_835  1
    arc_0_16_14  out_degree_846  1
    arc_0_16_14  original_T_including_depot_unload_886  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_658  1
    load_0_16_14  free_load_conservation_839  -1
    load_0_16_14  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_660  -20
    arc_0_16_15  connected_order_arc_661  -14
    arc_0_16_15  in_degree_841  1
    arc_0_16_15  out_degree_846  1
    arc_0_16_15  original_T_including_depot_unload_886  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_660  1
    load_0_16_15  free_load_conservation_845  -1
    load_0_16_15  free_load_conservation_851  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_662  -20
    arc_0_16_17  connected_order_arc_663  -14
    arc_0_16_17  out_degree_846  1
    arc_0_16_17  in_degree_853  1
    arc_0_16_17  original_T_including_depot_unload_886  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_662  1
    load_0_16_17  free_load_conservation_851  1
    load_0_16_17  free_load_conservation_857  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_664  -20
    arc_0_16_18  connected_order_arc_665  -14
    arc_0_16_18  out_degree_846  1
    arc_0_16_18  in_degree_859  1
    arc_0_16_18  original_T_including_depot_unload_886  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_664  1
    load_0_16_18  free_load_conservation_851  1
    load_0_16_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_666  -20
    arc_0_16_19  connected_order_arc_667  -14
    arc_0_16_19  out_degree_846  1
    arc_0_16_19  in_degree_865  1
    arc_0_16_19  original_T_including_depot_unload_886  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_666  1
    load_0_16_19  free_load_conservation_851  1
    load_0_16_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_668  -20
    arc_0_16_20  connected_order_arc_669  -14
    arc_0_16_20  out_degree_846  1
    arc_0_16_20  in_degree_871  1
    arc_0_16_20  original_T_including_depot_unload_886  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_668  1
    load_0_16_20  free_load_conservation_851  1
    load_0_16_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_670  -20
    arc_0_16_21  connected_order_arc_671  -14
    arc_0_16_21  out_degree_846  1
    arc_0_16_21  in_degree_877  1
    arc_0_16_21  original_T_including_depot_unload_886  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_670  1
    load_0_16_21  free_load_conservation_851  1
    load_0_16_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_672  -20
    arc_0_17_0  depot_return_or_bypass_798  1
    arc_0_17_0  out_degree_852  1
    arc_0_17_0  original_T_including_depot_unload_886  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_672  1
    load_0_17_0  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_673  -20
    arc_0_17_1  connected_order_arc_674  -14
    arc_0_17_1  in_degree_800  1
    arc_0_17_1  out_degree_852  1
    arc_0_17_1  original_T_including_depot_unload_886  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_673  1
    load_0_17_1  segment_load_conservation_803  -1
    load_0_17_1  segment_prefix_lb_804  1
    load_0_17_1  segment_prefix_ub_805  1
    load_0_17_1  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_675  -20
    arc_0_17_2  connected_order_arc_676  -14
    arc_0_17_2  in_degree_807  1
    arc_0_17_2  out_degree_852  1
    arc_0_17_2  original_T_including_depot_unload_886  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_675  1
    load_0_17_2  segment_load_conservation_810  -1
    load_0_17_2  segment_prefix_lb_811  1
    load_0_17_2  segment_prefix_ub_812  1
    load_0_17_2  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_677  -20
    arc_0_17_3  connected_order_arc_678  -14
    arc_0_17_3  in_degree_814  1
    arc_0_17_3  out_degree_852  1
    arc_0_17_3  original_T_including_depot_unload_886  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_677  1
    load_0_17_3  segment_load_conservation_817  -1
    load_0_17_3  segment_prefix_lb_818  1
    load_0_17_3  segment_prefix_ub_819  1
    load_0_17_3  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_679  -20
    arc_0_17_4  connected_order_arc_680  -14
    arc_0_17_4  in_degree_821  1
    arc_0_17_4  out_degree_852  1
    arc_0_17_4  original_T_including_depot_unload_886  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_679  1
    load_0_17_4  segment_load_conservation_824  -1
    load_0_17_4  segment_prefix_lb_825  1
    load_0_17_4  segment_prefix_ub_826  1
    load_0_17_4  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_681  -20
    arc_0_17_5  connected_order_arc_682  -14
    arc_0_17_5  in_degree_828  1
    arc_0_17_5  out_degree_852  1
    arc_0_17_5  original_T_including_depot_unload_886  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_681  1
    load_0_17_5  segment_load_conservation_831  -1
    load_0_17_5  segment_prefix_lb_832  1
    load_0_17_5  segment_prefix_ub_833  1
    load_0_17_5  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_683  -20
    arc_0_17_14  connected_order_arc_684  -14
    arc_0_17_14  in_degree_835  1
    arc_0_17_14  out_degree_852  1
    arc_0_17_14  original_T_including_depot_unload_886  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_683  1
    load_0_17_14  free_load_conservation_839  -1
    load_0_17_14  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_685  -20
    arc_0_17_15  connected_order_arc_686  -14
    arc_0_17_15  in_degree_841  1
    arc_0_17_15  out_degree_852  1
    arc_0_17_15  original_T_including_depot_unload_886  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_685  1
    load_0_17_15  free_load_conservation_845  -1
    load_0_17_15  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_687  -20
    arc_0_17_16  connected_order_arc_688  -14
    arc_0_17_16  in_degree_847  1
    arc_0_17_16  out_degree_852  1
    arc_0_17_16  original_T_including_depot_unload_886  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_687  1
    load_0_17_16  free_load_conservation_851  -1
    load_0_17_16  free_load_conservation_857  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_689  -20
    arc_0_17_18  connected_order_arc_690  -14
    arc_0_17_18  out_degree_852  1
    arc_0_17_18  in_degree_859  1
    arc_0_17_18  original_T_including_depot_unload_886  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_689  1
    load_0_17_18  free_load_conservation_857  1
    load_0_17_18  free_load_conservation_863  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_691  -20
    arc_0_17_19  connected_order_arc_692  -14
    arc_0_17_19  out_degree_852  1
    arc_0_17_19  in_degree_865  1
    arc_0_17_19  original_T_including_depot_unload_886  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_691  1
    load_0_17_19  free_load_conservation_857  1
    load_0_17_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_693  -20
    arc_0_17_20  connected_order_arc_694  -14
    arc_0_17_20  out_degree_852  1
    arc_0_17_20  in_degree_871  1
    arc_0_17_20  original_T_including_depot_unload_886  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_693  1
    load_0_17_20  free_load_conservation_857  1
    load_0_17_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_695  -20
    arc_0_17_21  connected_order_arc_696  -14
    arc_0_17_21  out_degree_852  1
    arc_0_17_21  in_degree_877  1
    arc_0_17_21  original_T_including_depot_unload_886  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_695  1
    load_0_17_21  free_load_conservation_857  1
    load_0_17_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_697  -20
    arc_0_18_0  depot_return_or_bypass_798  1
    arc_0_18_0  out_degree_858  1
    arc_0_18_0  original_T_including_depot_unload_886  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_697  1
    load_0_18_0  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_698  -20
    arc_0_18_1  connected_order_arc_699  -14
    arc_0_18_1  in_degree_800  1
    arc_0_18_1  out_degree_858  1
    arc_0_18_1  original_T_including_depot_unload_886  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_698  1
    load_0_18_1  segment_load_conservation_803  -1
    load_0_18_1  segment_prefix_lb_804  1
    load_0_18_1  segment_prefix_ub_805  1
    load_0_18_1  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_700  -20
    arc_0_18_2  connected_order_arc_701  -14
    arc_0_18_2  in_degree_807  1
    arc_0_18_2  out_degree_858  1
    arc_0_18_2  original_T_including_depot_unload_886  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_700  1
    load_0_18_2  segment_load_conservation_810  -1
    load_0_18_2  segment_prefix_lb_811  1
    load_0_18_2  segment_prefix_ub_812  1
    load_0_18_2  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_702  -20
    arc_0_18_3  connected_order_arc_703  -14
    arc_0_18_3  in_degree_814  1
    arc_0_18_3  out_degree_858  1
    arc_0_18_3  original_T_including_depot_unload_886  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_702  1
    load_0_18_3  segment_load_conservation_817  -1
    load_0_18_3  segment_prefix_lb_818  1
    load_0_18_3  segment_prefix_ub_819  1
    load_0_18_3  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_704  -20
    arc_0_18_4  connected_order_arc_705  -14
    arc_0_18_4  in_degree_821  1
    arc_0_18_4  out_degree_858  1
    arc_0_18_4  original_T_including_depot_unload_886  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_704  1
    load_0_18_4  segment_load_conservation_824  -1
    load_0_18_4  segment_prefix_lb_825  1
    load_0_18_4  segment_prefix_ub_826  1
    load_0_18_4  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_706  -20
    arc_0_18_5  connected_order_arc_707  -14
    arc_0_18_5  in_degree_828  1
    arc_0_18_5  out_degree_858  1
    arc_0_18_5  original_T_including_depot_unload_886  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_706  1
    load_0_18_5  segment_load_conservation_831  -1
    load_0_18_5  segment_prefix_lb_832  1
    load_0_18_5  segment_prefix_ub_833  1
    load_0_18_5  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_708  -20
    arc_0_18_14  connected_order_arc_709  -14
    arc_0_18_14  in_degree_835  1
    arc_0_18_14  out_degree_858  1
    arc_0_18_14  original_T_including_depot_unload_886  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_708  1
    load_0_18_14  free_load_conservation_839  -1
    load_0_18_14  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_710  -20
    arc_0_18_15  connected_order_arc_711  -14
    arc_0_18_15  in_degree_841  1
    arc_0_18_15  out_degree_858  1
    arc_0_18_15  original_T_including_depot_unload_886  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_710  1
    load_0_18_15  free_load_conservation_845  -1
    load_0_18_15  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_712  -20
    arc_0_18_16  connected_order_arc_713  -14
    arc_0_18_16  in_degree_847  1
    arc_0_18_16  out_degree_858  1
    arc_0_18_16  original_T_including_depot_unload_886  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_712  1
    load_0_18_16  free_load_conservation_851  -1
    load_0_18_16  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_714  -20
    arc_0_18_17  connected_order_arc_715  -14
    arc_0_18_17  in_degree_853  1
    arc_0_18_17  out_degree_858  1
    arc_0_18_17  original_T_including_depot_unload_886  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_714  1
    load_0_18_17  free_load_conservation_857  -1
    load_0_18_17  free_load_conservation_863  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_716  -20
    arc_0_18_19  connected_order_arc_717  -14
    arc_0_18_19  out_degree_858  1
    arc_0_18_19  in_degree_865  1
    arc_0_18_19  original_T_including_depot_unload_886  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_716  1
    load_0_18_19  free_load_conservation_863  1
    load_0_18_19  free_load_conservation_869  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_718  -20
    arc_0_18_20  connected_order_arc_719  -14
    arc_0_18_20  out_degree_858  1
    arc_0_18_20  in_degree_871  1
    arc_0_18_20  original_T_including_depot_unload_886  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_718  1
    load_0_18_20  free_load_conservation_863  1
    load_0_18_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_720  -20
    arc_0_18_21  connected_order_arc_721  -14
    arc_0_18_21  out_degree_858  1
    arc_0_18_21  in_degree_877  1
    arc_0_18_21  original_T_including_depot_unload_886  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_720  1
    load_0_18_21  free_load_conservation_863  1
    load_0_18_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_722  -20
    arc_0_19_0  depot_return_or_bypass_798  1
    arc_0_19_0  out_degree_864  1
    arc_0_19_0  original_T_including_depot_unload_886  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_722  1
    load_0_19_0  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_723  -20
    arc_0_19_1  connected_order_arc_724  -14
    arc_0_19_1  in_degree_800  1
    arc_0_19_1  out_degree_864  1
    arc_0_19_1  original_T_including_depot_unload_886  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_723  1
    load_0_19_1  segment_load_conservation_803  -1
    load_0_19_1  segment_prefix_lb_804  1
    load_0_19_1  segment_prefix_ub_805  1
    load_0_19_1  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_725  -20
    arc_0_19_2  connected_order_arc_726  -14
    arc_0_19_2  in_degree_807  1
    arc_0_19_2  out_degree_864  1
    arc_0_19_2  original_T_including_depot_unload_886  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_725  1
    load_0_19_2  segment_load_conservation_810  -1
    load_0_19_2  segment_prefix_lb_811  1
    load_0_19_2  segment_prefix_ub_812  1
    load_0_19_2  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_727  -20
    arc_0_19_3  connected_order_arc_728  -14
    arc_0_19_3  in_degree_814  1
    arc_0_19_3  out_degree_864  1
    arc_0_19_3  original_T_including_depot_unload_886  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_727  1
    load_0_19_3  segment_load_conservation_817  -1
    load_0_19_3  segment_prefix_lb_818  1
    load_0_19_3  segment_prefix_ub_819  1
    load_0_19_3  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_729  -20
    arc_0_19_4  connected_order_arc_730  -14
    arc_0_19_4  in_degree_821  1
    arc_0_19_4  out_degree_864  1
    arc_0_19_4  original_T_including_depot_unload_886  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_729  1
    load_0_19_4  segment_load_conservation_824  -1
    load_0_19_4  segment_prefix_lb_825  1
    load_0_19_4  segment_prefix_ub_826  1
    load_0_19_4  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_731  -20
    arc_0_19_5  connected_order_arc_732  -14
    arc_0_19_5  in_degree_828  1
    arc_0_19_5  out_degree_864  1
    arc_0_19_5  original_T_including_depot_unload_886  7.5688558078083690e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_731  1
    load_0_19_5  segment_load_conservation_831  -1
    load_0_19_5  segment_prefix_lb_832  1
    load_0_19_5  segment_prefix_ub_833  1
    load_0_19_5  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_733  -20
    arc_0_19_14  connected_order_arc_734  -14
    arc_0_19_14  in_degree_835  1
    arc_0_19_14  out_degree_864  1
    arc_0_19_14  original_T_including_depot_unload_886  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_733  1
    load_0_19_14  free_load_conservation_839  -1
    load_0_19_14  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_735  -20
    arc_0_19_15  connected_order_arc_736  -14
    arc_0_19_15  in_degree_841  1
    arc_0_19_15  out_degree_864  1
    arc_0_19_15  original_T_including_depot_unload_886  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_735  1
    load_0_19_15  free_load_conservation_845  -1
    load_0_19_15  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_737  -20
    arc_0_19_16  connected_order_arc_738  -14
    arc_0_19_16  in_degree_847  1
    arc_0_19_16  out_degree_864  1
    arc_0_19_16  original_T_including_depot_unload_886  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_737  1
    load_0_19_16  free_load_conservation_851  -1
    load_0_19_16  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_739  -20
    arc_0_19_17  connected_order_arc_740  -14
    arc_0_19_17  in_degree_853  1
    arc_0_19_17  out_degree_864  1
    arc_0_19_17  original_T_including_depot_unload_886  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_739  1
    load_0_19_17  free_load_conservation_857  -1
    load_0_19_17  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_741  -20
    arc_0_19_18  connected_order_arc_742  -14
    arc_0_19_18  in_degree_859  1
    arc_0_19_18  out_degree_864  1
    arc_0_19_18  original_T_including_depot_unload_886  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_741  1
    load_0_19_18  free_load_conservation_863  -1
    load_0_19_18  free_load_conservation_869  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_743  -20
    arc_0_19_20  connected_order_arc_744  -14
    arc_0_19_20  out_degree_864  1
    arc_0_19_20  in_degree_871  1
    arc_0_19_20  original_T_including_depot_unload_886  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_743  1
    load_0_19_20  free_load_conservation_869  1
    load_0_19_20  free_load_conservation_875  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_745  -20
    arc_0_19_21  connected_order_arc_746  -14
    arc_0_19_21  out_degree_864  1
    arc_0_19_21  in_degree_877  1
    arc_0_19_21  original_T_including_depot_unload_886  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_745  1
    load_0_19_21  free_load_conservation_869  1
    load_0_19_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_747  -20
    arc_0_20_0  depot_return_or_bypass_798  1
    arc_0_20_0  out_degree_870  1
    arc_0_20_0  original_T_including_depot_unload_886  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_747  1
    load_0_20_0  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_748  -20
    arc_0_20_1  connected_order_arc_749  -14
    arc_0_20_1  in_degree_800  1
    arc_0_20_1  out_degree_870  1
    arc_0_20_1  original_T_including_depot_unload_886  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_748  1
    load_0_20_1  segment_load_conservation_803  -1
    load_0_20_1  segment_prefix_lb_804  1
    load_0_20_1  segment_prefix_ub_805  1
    load_0_20_1  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_750  -20
    arc_0_20_2  connected_order_arc_751  -14
    arc_0_20_2  in_degree_807  1
    arc_0_20_2  out_degree_870  1
    arc_0_20_2  original_T_including_depot_unload_886  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_750  1
    load_0_20_2  segment_load_conservation_810  -1
    load_0_20_2  segment_prefix_lb_811  1
    load_0_20_2  segment_prefix_ub_812  1
    load_0_20_2  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_752  -20
    arc_0_20_3  connected_order_arc_753  -14
    arc_0_20_3  in_degree_814  1
    arc_0_20_3  out_degree_870  1
    arc_0_20_3  original_T_including_depot_unload_886  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_752  1
    load_0_20_3  segment_load_conservation_817  -1
    load_0_20_3  segment_prefix_lb_818  1
    load_0_20_3  segment_prefix_ub_819  1
    load_0_20_3  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_754  -20
    arc_0_20_4  connected_order_arc_755  -14
    arc_0_20_4  in_degree_821  1
    arc_0_20_4  out_degree_870  1
    arc_0_20_4  original_T_including_depot_unload_886  1.0758099325648966e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_754  1
    load_0_20_4  segment_load_conservation_824  -1
    load_0_20_4  segment_prefix_lb_825  1
    load_0_20_4  segment_prefix_ub_826  1
    load_0_20_4  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_756  -20
    arc_0_20_5  connected_order_arc_757  -14
    arc_0_20_5  in_degree_828  1
    arc_0_20_5  out_degree_870  1
    arc_0_20_5  original_T_including_depot_unload_886  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_756  1
    load_0_20_5  segment_load_conservation_831  -1
    load_0_20_5  segment_prefix_lb_832  1
    load_0_20_5  segment_prefix_ub_833  1
    load_0_20_5  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_758  -20
    arc_0_20_14  connected_order_arc_759  -14
    arc_0_20_14  in_degree_835  1
    arc_0_20_14  out_degree_870  1
    arc_0_20_14  original_T_including_depot_unload_886  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_758  1
    load_0_20_14  free_load_conservation_839  -1
    load_0_20_14  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_760  -20
    arc_0_20_15  connected_order_arc_761  -14
    arc_0_20_15  in_degree_841  1
    arc_0_20_15  out_degree_870  1
    arc_0_20_15  original_T_including_depot_unload_886  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_760  1
    load_0_20_15  free_load_conservation_845  -1
    load_0_20_15  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_762  -20
    arc_0_20_16  connected_order_arc_763  -14
    arc_0_20_16  in_degree_847  1
    arc_0_20_16  out_degree_870  1
    arc_0_20_16  original_T_including_depot_unload_886  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_762  1
    load_0_20_16  free_load_conservation_851  -1
    load_0_20_16  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_764  -20
    arc_0_20_17  connected_order_arc_765  -14
    arc_0_20_17  in_degree_853  1
    arc_0_20_17  out_degree_870  1
    arc_0_20_17  original_T_including_depot_unload_886  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_764  1
    load_0_20_17  free_load_conservation_857  -1
    load_0_20_17  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_766  -20
    arc_0_20_18  connected_order_arc_767  -14
    arc_0_20_18  in_degree_859  1
    arc_0_20_18  out_degree_870  1
    arc_0_20_18  original_T_including_depot_unload_886  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_766  1
    load_0_20_18  free_load_conservation_863  -1
    load_0_20_18  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_768  -20
    arc_0_20_19  connected_order_arc_769  -14
    arc_0_20_19  in_degree_865  1
    arc_0_20_19  out_degree_870  1
    arc_0_20_19  original_T_including_depot_unload_886  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_768  1
    load_0_20_19  free_load_conservation_869  -1
    load_0_20_19  free_load_conservation_875  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_770  -20
    arc_0_20_21  connected_order_arc_771  -14
    arc_0_20_21  out_degree_870  1
    arc_0_20_21  in_degree_877  1
    arc_0_20_21  original_T_including_depot_unload_886  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_770  1
    load_0_20_21  free_load_conservation_875  1
    load_0_20_21  free_load_conservation_881  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_772  -20
    arc_0_21_0  depot_return_or_bypass_798  1
    arc_0_21_0  out_degree_876  1
    arc_0_21_0  original_T_including_depot_unload_886  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_772  1
    load_0_21_0  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_773  -20
    arc_0_21_1  connected_order_arc_774  -14
    arc_0_21_1  in_degree_800  1
    arc_0_21_1  out_degree_876  1
    arc_0_21_1  original_T_including_depot_unload_886  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_773  1
    load_0_21_1  segment_load_conservation_803  -1
    load_0_21_1  segment_prefix_lb_804  1
    load_0_21_1  segment_prefix_ub_805  1
    load_0_21_1  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_775  -20
    arc_0_21_2  connected_order_arc_776  -14
    arc_0_21_2  in_degree_807  1
    arc_0_21_2  out_degree_876  1
    arc_0_21_2  original_T_including_depot_unload_886  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_775  1
    load_0_21_2  segment_load_conservation_810  -1
    load_0_21_2  segment_prefix_lb_811  1
    load_0_21_2  segment_prefix_ub_812  1
    load_0_21_2  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_777  -20
    arc_0_21_3  connected_order_arc_778  -14
    arc_0_21_3  in_degree_814  1
    arc_0_21_3  out_degree_876  1
    arc_0_21_3  original_T_including_depot_unload_886  7.2171835955896984e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_777  1
    load_0_21_3  segment_load_conservation_817  -1
    load_0_21_3  segment_prefix_lb_818  1
    load_0_21_3  segment_prefix_ub_819  1
    load_0_21_3  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_779  -20
    arc_0_21_4  connected_order_arc_780  -14
    arc_0_21_4  in_degree_821  1
    arc_0_21_4  out_degree_876  1
    arc_0_21_4  original_T_including_depot_unload_886  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_779  1
    load_0_21_4  segment_load_conservation_824  -1
    load_0_21_4  segment_prefix_lb_825  1
    load_0_21_4  segment_prefix_ub_826  1
    load_0_21_4  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_781  -20
    arc_0_21_5  connected_order_arc_782  -14
    arc_0_21_5  in_degree_828  1
    arc_0_21_5  out_degree_876  1
    arc_0_21_5  original_T_including_depot_unload_886  987.973588780524
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_781  1
    load_0_21_5  segment_load_conservation_831  -1
    load_0_21_5  segment_prefix_lb_832  1
    load_0_21_5  segment_prefix_ub_833  1
    load_0_21_5  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_783  -20
    arc_0_21_14  connected_order_arc_784  -14
    arc_0_21_14  in_degree_835  1
    arc_0_21_14  out_degree_876  1
    arc_0_21_14  original_T_including_depot_unload_886  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_783  1
    load_0_21_14  free_load_conservation_839  -1
    load_0_21_14  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_785  -20
    arc_0_21_15  connected_order_arc_786  -14
    arc_0_21_15  in_degree_841  1
    arc_0_21_15  out_degree_876  1
    arc_0_21_15  original_T_including_depot_unload_886  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_785  1
    load_0_21_15  free_load_conservation_845  -1
    load_0_21_15  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_787  -20
    arc_0_21_16  connected_order_arc_788  -14
    arc_0_21_16  in_degree_847  1
    arc_0_21_16  out_degree_876  1
    arc_0_21_16  original_T_including_depot_unload_886  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_787  1
    load_0_21_16  free_load_conservation_851  -1
    load_0_21_16  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_789  -20
    arc_0_21_17  connected_order_arc_790  -14
    arc_0_21_17  in_degree_853  1
    arc_0_21_17  out_degree_876  1
    arc_0_21_17  original_T_including_depot_unload_886  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_789  1
    load_0_21_17  free_load_conservation_857  -1
    load_0_21_17  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_791  -20
    arc_0_21_18  connected_order_arc_792  -14
    arc_0_21_18  in_degree_859  1
    arc_0_21_18  out_degree_876  1
    arc_0_21_18  original_T_including_depot_unload_886  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_791  1
    load_0_21_18  free_load_conservation_863  -1
    load_0_21_18  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_793  -20
    arc_0_21_19  connected_order_arc_794  -14
    arc_0_21_19  in_degree_865  1
    arc_0_21_19  out_degree_876  1
    arc_0_21_19  original_T_including_depot_unload_886  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_793  1
    load_0_21_19  free_load_conservation_869  -1
    load_0_21_19  free_load_conservation_881  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_795  -20
    arc_0_21_20  connected_order_arc_796  -14
    arc_0_21_20  in_degree_871  1
    arc_0_21_20  out_degree_876  1
    arc_0_21_20  original_T_including_depot_unload_886  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_795  1
    load_0_21_20  free_load_conservation_875  -1
    load_0_21_20  free_load_conservation_881  1
    visit_1_6  out_degree_1228  -1
    visit_1_6  in_degree_1229  -1
    visit_1_6  order_active_lb_1230  -1
    visit_1_6  order_active_ub_1231  -13
    order_1_6  connected_order_arc_903  -1
    order_1_6  connected_order_arc_905  -1
    order_1_6  connected_order_arc_907  -1
    order_1_6  connected_order_arc_909  -1
    order_1_6  connected_order_arc_911  -1
    order_1_6  connected_order_arc_913  -1
    order_1_6  connected_order_arc_915  -1
    order_1_6  connected_order_arc_917  -1
    order_1_6  connected_order_arc_919  -1
    order_1_6  connected_order_arc_921  -1
    order_1_6  connected_order_arc_923  -1
    order_1_6  connected_order_arc_925  -1
    order_1_6  connected_order_arc_928  1
    order_1_6  connected_order_arc_953  1
    order_1_6  connected_order_arc_978  1
    order_1_6  connected_order_arc_1003  1
    order_1_6  connected_order_arc_1028  1
    order_1_6  connected_order_arc_1053  1
    order_1_6  connected_order_arc_1078  1
    order_1_6  connected_order_arc_1103  1
    order_1_6  connected_order_arc_1128  1
    order_1_6  connected_order_arc_1153  1
    order_1_6  connected_order_arc_1178  1
    order_1_6  connected_order_arc_1203  1
    order_1_6  order_active_lb_1230  1
    order_1_6  order_active_ub_1231  1
    order_1_6  fixed_segment_relative_order_1311  -1
    visit_1_7  out_degree_1235  -1
    visit_1_7  in_degree_1236  -1
    visit_1_7  order_active_lb_1237  -1
    visit_1_7  order_active_ub_1238  -13
    order_1_7  connected_order_arc_903  1
    order_1_7  connected_order_arc_928  -1
    order_1_7  connected_order_arc_930  -1
    order_1_7  connected_order_arc_932  -1
    order_1_7  connected_order_arc_934  -1
    order_1_7  connected_order_arc_936  -1
    order_1_7  connected_order_arc_938  -1
    order_1_7  connected_order_arc_940  -1
    order_1_7  connected_order_arc_942  -1
    order_1_7  connected_order_arc_944  -1
    order_1_7  connected_order_arc_946  -1
    order_1_7  connected_order_arc_948  -1
    order_1_7  connected_order_arc_950  -1
    order_1_7  connected_order_arc_955  1
    order_1_7  connected_order_arc_980  1
    order_1_7  connected_order_arc_1005  1
    order_1_7  connected_order_arc_1030  1
    order_1_7  connected_order_arc_1055  1
    order_1_7  connected_order_arc_1080  1
    order_1_7  connected_order_arc_1105  1
    order_1_7  connected_order_arc_1130  1
    order_1_7  connected_order_arc_1155  1
    order_1_7  connected_order_arc_1180  1
    order_1_7  connected_order_arc_1205  1
    order_1_7  order_active_lb_1237  1
    order_1_7  order_active_ub_1238  1
    order_1_7  fixed_segment_relative_order_1311  1
    order_1_7  fixed_segment_relative_order_1312  -1
    visit_1_8  out_degree_1242  -1
    visit_1_8  in_degree_1243  -1
    visit_1_8  order_active_lb_1244  -1
    visit_1_8  order_active_ub_1245  -13
    order_1_8  connected_order_arc_905  1
    order_1_8  connected_order_arc_930  1
    order_1_8  connected_order_arc_953  -1
    order_1_8  connected_order_arc_955  -1
    order_1_8  connected_order_arc_957  -1
    order_1_8  connected_order_arc_959  -1
    order_1_8  connected_order_arc_961  -1
    order_1_8  connected_order_arc_963  -1
    order_1_8  connected_order_arc_965  -1
    order_1_8  connected_order_arc_967  -1
    order_1_8  connected_order_arc_969  -1
    order_1_8  connected_order_arc_971  -1
    order_1_8  connected_order_arc_973  -1
    order_1_8  connected_order_arc_975  -1
    order_1_8  connected_order_arc_982  1
    order_1_8  connected_order_arc_1007  1
    order_1_8  connected_order_arc_1032  1
    order_1_8  connected_order_arc_1057  1
    order_1_8  connected_order_arc_1082  1
    order_1_8  connected_order_arc_1107  1
    order_1_8  connected_order_arc_1132  1
    order_1_8  connected_order_arc_1157  1
    order_1_8  connected_order_arc_1182  1
    order_1_8  connected_order_arc_1207  1
    order_1_8  order_active_lb_1244  1
    order_1_8  order_active_ub_1245  1
    order_1_8  fixed_segment_relative_order_1312  1
    order_1_8  fixed_segment_relative_order_1313  -1
    visit_1_9  out_degree_1249  -1
    visit_1_9  in_degree_1250  -1
    visit_1_9  order_active_lb_1251  -1
    visit_1_9  order_active_ub_1252  -13
    order_1_9  connected_order_arc_907  1
    order_1_9  connected_order_arc_932  1
    order_1_9  connected_order_arc_957  1
    order_1_9  connected_order_arc_978  -1
    order_1_9  connected_order_arc_980  -1
    order_1_9  connected_order_arc_982  -1
    order_1_9  connected_order_arc_984  -1
    order_1_9  connected_order_arc_986  -1
    order_1_9  connected_order_arc_988  -1
    order_1_9  connected_order_arc_990  -1
    order_1_9  connected_order_arc_992  -1
    order_1_9  connected_order_arc_994  -1
    order_1_9  connected_order_arc_996  -1
    order_1_9  connected_order_arc_998  -1
    order_1_9  connected_order_arc_1000  -1
    order_1_9  connected_order_arc_1009  1
    order_1_9  connected_order_arc_1034  1
    order_1_9  connected_order_arc_1059  1
    order_1_9  connected_order_arc_1084  1
    order_1_9  connected_order_arc_1109  1
    order_1_9  connected_order_arc_1134  1
    order_1_9  connected_order_arc_1159  1
    order_1_9  connected_order_arc_1184  1
    order_1_9  connected_order_arc_1209  1
    order_1_9  order_active_lb_1251  1
    order_1_9  order_active_ub_1252  1
    order_1_9  fixed_segment_relative_order_1313  1
    order_1_9  fixed_segment_relative_order_1314  -1
    visit_1_10  out_degree_1256  -1
    visit_1_10  in_degree_1257  -1
    visit_1_10  order_active_lb_1258  -1
    visit_1_10  order_active_ub_1259  -13
    order_1_10  connected_order_arc_909  1
    order_1_10  connected_order_arc_934  1
    order_1_10  connected_order_arc_959  1
    order_1_10  connected_order_arc_984  1
    order_1_10  connected_order_arc_1003  -1
    order_1_10  connected_order_arc_1005  -1
    order_1_10  connected_order_arc_1007  -1
    order_1_10  connected_order_arc_1009  -1
    order_1_10  connected_order_arc_1011  -1
    order_1_10  connected_order_arc_1013  -1
    order_1_10  connected_order_arc_1015  -1
    order_1_10  connected_order_arc_1017  -1
    order_1_10  connected_order_arc_1019  -1
    order_1_10  connected_order_arc_1021  -1
    order_1_10  connected_order_arc_1023  -1
    order_1_10  connected_order_arc_1025  -1
    order_1_10  connected_order_arc_1036  1
    order_1_10  connected_order_arc_1061  1
    order_1_10  connected_order_arc_1086  1
    order_1_10  connected_order_arc_1111  1
    order_1_10  connected_order_arc_1136  1
    order_1_10  connected_order_arc_1161  1
    order_1_10  connected_order_arc_1186  1
    order_1_10  connected_order_arc_1211  1
    order_1_10  order_active_lb_1258  1
    order_1_10  order_active_ub_1259  1
    order_1_10  fixed_segment_relative_order_1314  1
    visit_1_14  out_degree_1263  -1
    visit_1_14  in_degree_1264  -1
    visit_1_14  order_active_lb_1265  -1
    visit_1_14  order_active_ub_1266  -13
    visit_1_14  service_visit_def_1267  -1
    order_1_14  connected_order_arc_911  1
    order_1_14  connected_order_arc_936  1
    order_1_14  connected_order_arc_961  1
    order_1_14  connected_order_arc_986  1
    order_1_14  connected_order_arc_1011  1
    order_1_14  connected_order_arc_1028  -1
    order_1_14  connected_order_arc_1030  -1
    order_1_14  connected_order_arc_1032  -1
    order_1_14  connected_order_arc_1034  -1
    order_1_14  connected_order_arc_1036  -1
    order_1_14  connected_order_arc_1038  -1
    order_1_14  connected_order_arc_1040  -1
    order_1_14  connected_order_arc_1042  -1
    order_1_14  connected_order_arc_1044  -1
    order_1_14  connected_order_arc_1046  -1
    order_1_14  connected_order_arc_1048  -1
    order_1_14  connected_order_arc_1050  -1
    order_1_14  connected_order_arc_1063  1
    order_1_14  connected_order_arc_1088  1
    order_1_14  connected_order_arc_1113  1
    order_1_14  connected_order_arc_1138  1
    order_1_14  connected_order_arc_1163  1
    order_1_14  connected_order_arc_1188  1
    order_1_14  connected_order_arc_1213  1
    order_1_14  order_active_lb_1265  1
    order_1_14  order_active_ub_1266  1
    visit_1_15  out_degree_1269  -1
    visit_1_15  in_degree_1270  -1
    visit_1_15  order_active_lb_1271  -1
    visit_1_15  order_active_ub_1272  -13
    visit_1_15  service_visit_def_1273  -1
    order_1_15  connected_order_arc_913  1
    order_1_15  connected_order_arc_938  1
    order_1_15  connected_order_arc_963  1
    order_1_15  connected_order_arc_988  1
    order_1_15  connected_order_arc_1013  1
    order_1_15  connected_order_arc_1038  1
    order_1_15  connected_order_arc_1053  -1
    order_1_15  connected_order_arc_1055  -1
    order_1_15  connected_order_arc_1057  -1
    order_1_15  connected_order_arc_1059  -1
    order_1_15  connected_order_arc_1061  -1
    order_1_15  connected_order_arc_1063  -1
    order_1_15  connected_order_arc_1065  -1
    order_1_15  connected_order_arc_1067  -1
    order_1_15  connected_order_arc_1069  -1
    order_1_15  connected_order_arc_1071  -1
    order_1_15  connected_order_arc_1073  -1
    order_1_15  connected_order_arc_1075  -1
    order_1_15  connected_order_arc_1090  1
    order_1_15  connected_order_arc_1115  1
    order_1_15  connected_order_arc_1140  1
    order_1_15  connected_order_arc_1165  1
    order_1_15  connected_order_arc_1190  1
    order_1_15  connected_order_arc_1215  1
    order_1_15  order_active_lb_1271  1
    order_1_15  order_active_ub_1272  1
    visit_1_16  out_degree_1275  -1
    visit_1_16  in_degree_1276  -1
    visit_1_16  order_active_lb_1277  -1
    visit_1_16  order_active_ub_1278  -13
    visit_1_16  service_visit_def_1279  -1
    order_1_16  connected_order_arc_915  1
    order_1_16  connected_order_arc_940  1
    order_1_16  connected_order_arc_965  1
    order_1_16  connected_order_arc_990  1
    order_1_16  connected_order_arc_1015  1
    order_1_16  connected_order_arc_1040  1
    order_1_16  connected_order_arc_1065  1
    order_1_16  connected_order_arc_1078  -1
    order_1_16  connected_order_arc_1080  -1
    order_1_16  connected_order_arc_1082  -1
    order_1_16  connected_order_arc_1084  -1
    order_1_16  connected_order_arc_1086  -1
    order_1_16  connected_order_arc_1088  -1
    order_1_16  connected_order_arc_1090  -1
    order_1_16  connected_order_arc_1092  -1
    order_1_16  connected_order_arc_1094  -1
    order_1_16  connected_order_arc_1096  -1
    order_1_16  connected_order_arc_1098  -1
    order_1_16  connected_order_arc_1100  -1
    order_1_16  connected_order_arc_1117  1
    order_1_16  connected_order_arc_1142  1
    order_1_16  connected_order_arc_1167  1
    order_1_16  connected_order_arc_1192  1
    order_1_16  connected_order_arc_1217  1
    order_1_16  order_active_lb_1277  1
    order_1_16  order_active_ub_1278  1
    visit_1_17  out_degree_1281  -1
    visit_1_17  in_degree_1282  -1
    visit_1_17  order_active_lb_1283  -1
    visit_1_17  order_active_ub_1284  -13
    visit_1_17  service_visit_def_1285  -1
    order_1_17  connected_order_arc_917  1
    order_1_17  connected_order_arc_942  1
    order_1_17  connected_order_arc_967  1
    order_1_17  connected_order_arc_992  1
    order_1_17  connected_order_arc_1017  1
    order_1_17  connected_order_arc_1042  1
    order_1_17  connected_order_arc_1067  1
    order_1_17  connected_order_arc_1092  1
    order_1_17  connected_order_arc_1103  -1
    order_1_17  connected_order_arc_1105  -1
    order_1_17  connected_order_arc_1107  -1
    order_1_17  connected_order_arc_1109  -1
    order_1_17  connected_order_arc_1111  -1
    order_1_17  connected_order_arc_1113  -1
    order_1_17  connected_order_arc_1115  -1
    order_1_17  connected_order_arc_1117  -1
    order_1_17  connected_order_arc_1119  -1
    order_1_17  connected_order_arc_1121  -1
    order_1_17  connected_order_arc_1123  -1
    order_1_17  connected_order_arc_1125  -1
    order_1_17  connected_order_arc_1144  1
    order_1_17  connected_order_arc_1169  1
    order_1_17  connected_order_arc_1194  1
    order_1_17  connected_order_arc_1219  1
    order_1_17  order_active_lb_1283  1
    order_1_17  order_active_ub_1284  1
    visit_1_18  out_degree_1287  -1
    visit_1_18  in_degree_1288  -1
    visit_1_18  order_active_lb_1289  -1
    visit_1_18  order_active_ub_1290  -13
    visit_1_18  service_visit_def_1291  -1
    order_1_18  connected_order_arc_919  1
    order_1_18  connected_order_arc_944  1
    order_1_18  connected_order_arc_969  1
    order_1_18  connected_order_arc_994  1
    order_1_18  connected_order_arc_1019  1
    order_1_18  connected_order_arc_1044  1
    order_1_18  connected_order_arc_1069  1
    order_1_18  connected_order_arc_1094  1
    order_1_18  connected_order_arc_1119  1
    order_1_18  connected_order_arc_1128  -1
    order_1_18  connected_order_arc_1130  -1
    order_1_18  connected_order_arc_1132  -1
    order_1_18  connected_order_arc_1134  -1
    order_1_18  connected_order_arc_1136  -1
    order_1_18  connected_order_arc_1138  -1
    order_1_18  connected_order_arc_1140  -1
    order_1_18  connected_order_arc_1142  -1
    order_1_18  connected_order_arc_1144  -1
    order_1_18  connected_order_arc_1146  -1
    order_1_18  connected_order_arc_1148  -1
    order_1_18  connected_order_arc_1150  -1
    order_1_18  connected_order_arc_1171  1
    order_1_18  connected_order_arc_1196  1
    order_1_18  connected_order_arc_1221  1
    order_1_18  order_active_lb_1289  1
    order_1_18  order_active_ub_1290  1
    visit_1_19  out_degree_1293  -1
    visit_1_19  in_degree_1294  -1
    visit_1_19  order_active_lb_1295  -1
    visit_1_19  order_active_ub_1296  -13
    visit_1_19  service_visit_def_1297  -1
    order_1_19  connected_order_arc_921  1
    order_1_19  connected_order_arc_946  1
    order_1_19  connected_order_arc_971  1
    order_1_19  connected_order_arc_996  1
    order_1_19  connected_order_arc_1021  1
    order_1_19  connected_order_arc_1046  1
    order_1_19  connected_order_arc_1071  1
    order_1_19  connected_order_arc_1096  1
    order_1_19  connected_order_arc_1121  1
    order_1_19  connected_order_arc_1146  1
    order_1_19  connected_order_arc_1153  -1
    order_1_19  connected_order_arc_1155  -1
    order_1_19  connected_order_arc_1157  -1
    order_1_19  connected_order_arc_1159  -1
    order_1_19  connected_order_arc_1161  -1
    order_1_19  connected_order_arc_1163  -1
    order_1_19  connected_order_arc_1165  -1
    order_1_19  connected_order_arc_1167  -1
    order_1_19  connected_order_arc_1169  -1
    order_1_19  connected_order_arc_1171  -1
    order_1_19  connected_order_arc_1173  -1
    order_1_19  connected_order_arc_1175  -1
    order_1_19  connected_order_arc_1198  1
    order_1_19  connected_order_arc_1223  1
    order_1_19  order_active_lb_1295  1
    order_1_19  order_active_ub_1296  1
    visit_1_20  out_degree_1299  -1
    visit_1_20  in_degree_1300  -1
    visit_1_20  order_active_lb_1301  -1
    visit_1_20  order_active_ub_1302  -13
    visit_1_20  service_visit_def_1303  -1
    order_1_20  connected_order_arc_923  1
    order_1_20  connected_order_arc_948  1
    order_1_20  connected_order_arc_973  1
    order_1_20  connected_order_arc_998  1
    order_1_20  connected_order_arc_1023  1
    order_1_20  connected_order_arc_1048  1
    order_1_20  connected_order_arc_1073  1
    order_1_20  connected_order_arc_1098  1
    order_1_20  connected_order_arc_1123  1
    order_1_20  connected_order_arc_1148  1
    order_1_20  connected_order_arc_1173  1
    order_1_20  connected_order_arc_1178  -1
    order_1_20  connected_order_arc_1180  -1
    order_1_20  connected_order_arc_1182  -1
    order_1_20  connected_order_arc_1184  -1
    order_1_20  connected_order_arc_1186  -1
    order_1_20  connected_order_arc_1188  -1
    order_1_20  connected_order_arc_1190  -1
    order_1_20  connected_order_arc_1192  -1
    order_1_20  connected_order_arc_1194  -1
    order_1_20  connected_order_arc_1196  -1
    order_1_20  connected_order_arc_1198  -1
    order_1_20  connected_order_arc_1200  -1
    order_1_20  connected_order_arc_1225  1
    order_1_20  order_active_lb_1301  1
    order_1_20  order_active_ub_1302  1
    visit_1_21  out_degree_1305  -1
    visit_1_21  in_degree_1306  -1
    visit_1_21  order_active_lb_1307  -1
    visit_1_21  order_active_ub_1308  -13
    visit_1_21  service_visit_def_1309  -1
    order_1_21  connected_order_arc_925  1
    order_1_21  connected_order_arc_950  1
    order_1_21  connected_order_arc_975  1
    order_1_21  connected_order_arc_1000  1
    order_1_21  connected_order_arc_1025  1
    order_1_21  connected_order_arc_1050  1
    order_1_21  connected_order_arc_1075  1
    order_1_21  connected_order_arc_1100  1
    order_1_21  connected_order_arc_1125  1
    order_1_21  connected_order_arc_1150  1
    order_1_21  connected_order_arc_1175  1
    order_1_21  connected_order_arc_1200  1
    order_1_21  connected_order_arc_1203  -1
    order_1_21  connected_order_arc_1205  -1
    order_1_21  connected_order_arc_1207  -1
    order_1_21  connected_order_arc_1209  -1
    order_1_21  connected_order_arc_1211  -1
    order_1_21  connected_order_arc_1213  -1
    order_1_21  connected_order_arc_1215  -1
    order_1_21  connected_order_arc_1217  -1
    order_1_21  connected_order_arc_1219  -1
    order_1_21  connected_order_arc_1221  -1
    order_1_21  connected_order_arc_1223  -1
    order_1_21  connected_order_arc_1225  -1
    order_1_21  order_active_lb_1307  1
    order_1_21  order_active_ub_1308  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_887  -25
    arc_1_0_0  depot_departure_or_bypass_1226  1
    arc_1_0_0  depot_return_or_bypass_1227  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_887  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_888  -25
    arc_1_0_6  depot_departure_or_bypass_1226  1
    arc_1_0_6  in_degree_1229  1
    arc_1_0_6  original_T_including_depot_unload_1315  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_888  1
    load_1_0_6  segment_load_conservation_1232  -1
    load_1_0_6  segment_prefix_lb_1233  1
    load_1_0_6  segment_prefix_ub_1234  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_889  -25
    arc_1_0_7  depot_departure_or_bypass_1226  1
    arc_1_0_7  in_degree_1236  1
    arc_1_0_7  original_T_including_depot_unload_1315  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_889  1
    load_1_0_7  segment_load_conservation_1239  -1
    load_1_0_7  segment_prefix_lb_1240  1
    load_1_0_7  segment_prefix_ub_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_890  -25
    arc_1_0_8  depot_departure_or_bypass_1226  1
    arc_1_0_8  in_degree_1243  1
    arc_1_0_8  original_T_including_depot_unload_1315  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_890  1
    load_1_0_8  segment_load_conservation_1246  -1
    load_1_0_8  segment_prefix_lb_1247  1
    load_1_0_8  segment_prefix_ub_1248  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_891  -25
    arc_1_0_9  depot_departure_or_bypass_1226  1
    arc_1_0_9  in_degree_1250  1
    arc_1_0_9  original_T_including_depot_unload_1315  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_891  1
    load_1_0_9  segment_load_conservation_1253  -1
    load_1_0_9  segment_prefix_lb_1254  1
    load_1_0_9  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_892  -25
    arc_1_0_10  depot_departure_or_bypass_1226  1
    arc_1_0_10  in_degree_1257  1
    arc_1_0_10  original_T_including_depot_unload_1315  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_892  1
    load_1_0_10  segment_load_conservation_1260  -1
    load_1_0_10  segment_prefix_lb_1261  1
    load_1_0_10  segment_prefix_ub_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_893  -25
    arc_1_0_14  depot_departure_or_bypass_1226  1
    arc_1_0_14  in_degree_1264  1
    arc_1_0_14  original_T_including_depot_unload_1315  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_893  1
    load_1_0_14  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_894  -25
    arc_1_0_15  depot_departure_or_bypass_1226  1
    arc_1_0_15  in_degree_1270  1
    arc_1_0_15  original_T_including_depot_unload_1315  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_894  1
    load_1_0_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_895  -25
    arc_1_0_16  depot_departure_or_bypass_1226  1
    arc_1_0_16  in_degree_1276  1
    arc_1_0_16  original_T_including_depot_unload_1315  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_895  1
    load_1_0_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_896  -25
    arc_1_0_17  depot_departure_or_bypass_1226  1
    arc_1_0_17  in_degree_1282  1
    arc_1_0_17  original_T_including_depot_unload_1315  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_896  1
    load_1_0_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_897  -25
    arc_1_0_18  depot_departure_or_bypass_1226  1
    arc_1_0_18  in_degree_1288  1
    arc_1_0_18  original_T_including_depot_unload_1315  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_897  1
    load_1_0_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_898  -25
    arc_1_0_19  depot_departure_or_bypass_1226  1
    arc_1_0_19  in_degree_1294  1
    arc_1_0_19  original_T_including_depot_unload_1315  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_898  1
    load_1_0_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_899  -25
    arc_1_0_20  depot_departure_or_bypass_1226  1
    arc_1_0_20  in_degree_1300  1
    arc_1_0_20  original_T_including_depot_unload_1315  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_899  1
    load_1_0_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_900  -25
    arc_1_0_21  depot_departure_or_bypass_1226  1
    arc_1_0_21  in_degree_1306  1
    arc_1_0_21  original_T_including_depot_unload_1315  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_900  1
    load_1_0_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_901  -25
    arc_1_6_0  depot_return_or_bypass_1227  1
    arc_1_6_0  out_degree_1228  1
    arc_1_6_0  original_T_including_depot_unload_1315  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_901  1
    load_1_6_0  segment_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_902  -25
    arc_1_6_7  connected_order_arc_903  -14
    arc_1_6_7  out_degree_1228  1
    arc_1_6_7  in_degree_1236  1
    arc_1_6_7  original_T_including_depot_unload_1315  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_902  1
    load_1_6_7  segment_load_conservation_1232  1
    load_1_6_7  segment_load_conservation_1239  -1
    load_1_6_7  segment_prefix_lb_1240  1
    load_1_6_7  segment_prefix_ub_1241  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_904  -25
    arc_1_6_8  connected_order_arc_905  -14
    arc_1_6_8  out_degree_1228  1
    arc_1_6_8  in_degree_1243  1
    arc_1_6_8  original_T_including_depot_unload_1315  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_904  1
    load_1_6_8  segment_load_conservation_1232  1
    load_1_6_8  segment_load_conservation_1246  -1
    load_1_6_8  segment_prefix_lb_1247  1
    load_1_6_8  segment_prefix_ub_1248  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_906  -25
    arc_1_6_9  connected_order_arc_907  -14
    arc_1_6_9  out_degree_1228  1
    arc_1_6_9  in_degree_1250  1
    arc_1_6_9  original_T_including_depot_unload_1315  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_906  1
    load_1_6_9  segment_load_conservation_1232  1
    load_1_6_9  segment_load_conservation_1253  -1
    load_1_6_9  segment_prefix_lb_1254  1
    load_1_6_9  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_908  -25
    arc_1_6_10  connected_order_arc_909  -14
    arc_1_6_10  out_degree_1228  1
    arc_1_6_10  in_degree_1257  1
    arc_1_6_10  original_T_including_depot_unload_1315  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_908  1
    load_1_6_10  segment_load_conservation_1232  1
    load_1_6_10  segment_load_conservation_1260  -1
    load_1_6_10  segment_prefix_lb_1261  1
    load_1_6_10  segment_prefix_ub_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_910  -25
    arc_1_6_14  connected_order_arc_911  -14
    arc_1_6_14  out_degree_1228  1
    arc_1_6_14  in_degree_1264  1
    arc_1_6_14  original_T_including_depot_unload_1315  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_910  1
    load_1_6_14  segment_load_conservation_1232  1
    load_1_6_14  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_912  -25
    arc_1_6_15  connected_order_arc_913  -14
    arc_1_6_15  out_degree_1228  1
    arc_1_6_15  in_degree_1270  1
    arc_1_6_15  original_T_including_depot_unload_1315  1.3473071485321755e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_912  1
    load_1_6_15  segment_load_conservation_1232  1
    load_1_6_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_914  -25
    arc_1_6_16  connected_order_arc_915  -14
    arc_1_6_16  out_degree_1228  1
    arc_1_6_16  in_degree_1276  1
    arc_1_6_16  original_T_including_depot_unload_1315  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_914  1
    load_1_6_16  segment_load_conservation_1232  1
    load_1_6_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_916  -25
    arc_1_6_17  connected_order_arc_917  -14
    arc_1_6_17  out_degree_1228  1
    arc_1_6_17  in_degree_1282  1
    arc_1_6_17  original_T_including_depot_unload_1315  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_916  1
    load_1_6_17  segment_load_conservation_1232  1
    load_1_6_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_918  -25
    arc_1_6_18  connected_order_arc_919  -14
    arc_1_6_18  out_degree_1228  1
    arc_1_6_18  in_degree_1288  1
    arc_1_6_18  original_T_including_depot_unload_1315  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_918  1
    load_1_6_18  segment_load_conservation_1232  1
    load_1_6_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_920  -25
    arc_1_6_19  connected_order_arc_921  -14
    arc_1_6_19  out_degree_1228  1
    arc_1_6_19  in_degree_1294  1
    arc_1_6_19  original_T_including_depot_unload_1315  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_920  1
    load_1_6_19  segment_load_conservation_1232  1
    load_1_6_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_922  -25
    arc_1_6_20  connected_order_arc_923  -14
    arc_1_6_20  out_degree_1228  1
    arc_1_6_20  in_degree_1300  1
    arc_1_6_20  original_T_including_depot_unload_1315  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_922  1
    load_1_6_20  segment_load_conservation_1232  1
    load_1_6_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_924  -25
    arc_1_6_21  connected_order_arc_925  -14
    arc_1_6_21  out_degree_1228  1
    arc_1_6_21  in_degree_1306  1
    arc_1_6_21  original_T_including_depot_unload_1315  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_924  1
    load_1_6_21  segment_load_conservation_1232  1
    load_1_6_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_926  -25
    arc_1_7_0  depot_return_or_bypass_1227  1
    arc_1_7_0  out_degree_1235  1
    arc_1_7_0  original_T_including_depot_unload_1315  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_926  1
    load_1_7_0  segment_load_conservation_1239  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_927  -25
    arc_1_7_6  connected_order_arc_928  -14
    arc_1_7_6  in_degree_1229  1
    arc_1_7_6  out_degree_1235  1
    arc_1_7_6  original_T_including_depot_unload_1315  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_927  1
    load_1_7_6  segment_load_conservation_1232  -1
    load_1_7_6  segment_prefix_lb_1233  1
    load_1_7_6  segment_prefix_ub_1234  1
    load_1_7_6  segment_load_conservation_1239  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_929  -25
    arc_1_7_8  connected_order_arc_930  -14
    arc_1_7_8  out_degree_1235  1
    arc_1_7_8  in_degree_1243  1
    arc_1_7_8  original_T_including_depot_unload_1315  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_929  1
    load_1_7_8  segment_load_conservation_1239  1
    load_1_7_8  segment_load_conservation_1246  -1
    load_1_7_8  segment_prefix_lb_1247  1
    load_1_7_8  segment_prefix_ub_1248  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_931  -25
    arc_1_7_9  connected_order_arc_932  -14
    arc_1_7_9  out_degree_1235  1
    arc_1_7_9  in_degree_1250  1
    arc_1_7_9  original_T_including_depot_unload_1315  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_931  1
    load_1_7_9  segment_load_conservation_1239  1
    load_1_7_9  segment_load_conservation_1253  -1
    load_1_7_9  segment_prefix_lb_1254  1
    load_1_7_9  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_933  -25
    arc_1_7_10  connected_order_arc_934  -14
    arc_1_7_10  out_degree_1235  1
    arc_1_7_10  in_degree_1257  1
    arc_1_7_10  original_T_including_depot_unload_1315  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_933  1
    load_1_7_10  segment_load_conservation_1239  1
    load_1_7_10  segment_load_conservation_1260  -1
    load_1_7_10  segment_prefix_lb_1261  1
    load_1_7_10  segment_prefix_ub_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_935  -25
    arc_1_7_14  connected_order_arc_936  -14
    arc_1_7_14  out_degree_1235  1
    arc_1_7_14  in_degree_1264  1
    arc_1_7_14  original_T_including_depot_unload_1315  8.9144012844276767e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_935  1
    load_1_7_14  segment_load_conservation_1239  1
    load_1_7_14  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_937  -25
    arc_1_7_15  connected_order_arc_938  -14
    arc_1_7_15  out_degree_1235  1
    arc_1_7_15  in_degree_1270  1
    arc_1_7_15  original_T_including_depot_unload_1315  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_937  1
    load_1_7_15  segment_load_conservation_1239  1
    load_1_7_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_939  -25
    arc_1_7_16  connected_order_arc_940  -14
    arc_1_7_16  out_degree_1235  1
    arc_1_7_16  in_degree_1276  1
    arc_1_7_16  original_T_including_depot_unload_1315  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_939  1
    load_1_7_16  segment_load_conservation_1239  1
    load_1_7_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_941  -25
    arc_1_7_17  connected_order_arc_942  -14
    arc_1_7_17  out_degree_1235  1
    arc_1_7_17  in_degree_1282  1
    arc_1_7_17  original_T_including_depot_unload_1315  1.1271509405745085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_941  1
    load_1_7_17  segment_load_conservation_1239  1
    load_1_7_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_943  -25
    arc_1_7_18  connected_order_arc_944  -14
    arc_1_7_18  out_degree_1235  1
    arc_1_7_18  in_degree_1288  1
    arc_1_7_18  original_T_including_depot_unload_1315  1.2814005706654932e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_943  1
    load_1_7_18  segment_load_conservation_1239  1
    load_1_7_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_945  -25
    arc_1_7_19  connected_order_arc_946  -14
    arc_1_7_19  out_degree_1235  1
    arc_1_7_19  in_degree_1294  1
    arc_1_7_19  original_T_including_depot_unload_1315  1.0246875893625959e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_945  1
    load_1_7_19  segment_load_conservation_1239  1
    load_1_7_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_947  -25
    arc_1_7_20  connected_order_arc_948  -14
    arc_1_7_20  out_degree_1235  1
    arc_1_7_20  in_degree_1300  1
    arc_1_7_20  original_T_including_depot_unload_1315  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_947  1
    load_1_7_20  segment_load_conservation_1239  1
    load_1_7_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_949  -25
    arc_1_7_21  connected_order_arc_950  -14
    arc_1_7_21  out_degree_1235  1
    arc_1_7_21  in_degree_1306  1
    arc_1_7_21  original_T_including_depot_unload_1315  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_949  1
    load_1_7_21  segment_load_conservation_1239  1
    load_1_7_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_951  -25
    arc_1_8_0  depot_return_or_bypass_1227  1
    arc_1_8_0  out_degree_1242  1
    arc_1_8_0  original_T_including_depot_unload_1315  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_951  1
    load_1_8_0  segment_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_952  -25
    arc_1_8_6  connected_order_arc_953  -14
    arc_1_8_6  in_degree_1229  1
    arc_1_8_6  out_degree_1242  1
    arc_1_8_6  original_T_including_depot_unload_1315  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_952  1
    load_1_8_6  segment_load_conservation_1232  -1
    load_1_8_6  segment_prefix_lb_1233  1
    load_1_8_6  segment_prefix_ub_1234  1
    load_1_8_6  segment_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_954  -25
    arc_1_8_7  connected_order_arc_955  -14
    arc_1_8_7  in_degree_1236  1
    arc_1_8_7  out_degree_1242  1
    arc_1_8_7  original_T_including_depot_unload_1315  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_954  1
    load_1_8_7  segment_load_conservation_1239  -1
    load_1_8_7  segment_prefix_lb_1240  1
    load_1_8_7  segment_prefix_ub_1241  1
    load_1_8_7  segment_load_conservation_1246  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_956  -25
    arc_1_8_9  connected_order_arc_957  -14
    arc_1_8_9  out_degree_1242  1
    arc_1_8_9  in_degree_1250  1
    arc_1_8_9  original_T_including_depot_unload_1315  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_956  1
    load_1_8_9  segment_load_conservation_1246  1
    load_1_8_9  segment_load_conservation_1253  -1
    load_1_8_9  segment_prefix_lb_1254  1
    load_1_8_9  segment_prefix_ub_1255  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_958  -25
    arc_1_8_10  connected_order_arc_959  -14
    arc_1_8_10  out_degree_1242  1
    arc_1_8_10  in_degree_1257  1
    arc_1_8_10  original_T_including_depot_unload_1315  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_958  1
    load_1_8_10  segment_load_conservation_1246  1
    load_1_8_10  segment_load_conservation_1260  -1
    load_1_8_10  segment_prefix_lb_1261  1
    load_1_8_10  segment_prefix_ub_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_960  -25
    arc_1_8_14  connected_order_arc_961  -14
    arc_1_8_14  out_degree_1242  1
    arc_1_8_14  in_degree_1264  1
    arc_1_8_14  original_T_including_depot_unload_1315  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_960  1
    load_1_8_14  segment_load_conservation_1246  1
    load_1_8_14  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_962  -25
    arc_1_8_15  connected_order_arc_963  -14
    arc_1_8_15  out_degree_1242  1
    arc_1_8_15  in_degree_1270  1
    arc_1_8_15  original_T_including_depot_unload_1315  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_962  1
    load_1_8_15  segment_load_conservation_1246  1
    load_1_8_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_964  -25
    arc_1_8_16  connected_order_arc_965  -14
    arc_1_8_16  out_degree_1242  1
    arc_1_8_16  in_degree_1276  1
    arc_1_8_16  original_T_including_depot_unload_1315  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_964  1
    load_1_8_16  segment_load_conservation_1246  1
    load_1_8_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_966  -25
    arc_1_8_17  connected_order_arc_967  -14
    arc_1_8_17  out_degree_1242  1
    arc_1_8_17  in_degree_1282  1
    arc_1_8_17  original_T_including_depot_unload_1315  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_966  1
    load_1_8_17  segment_load_conservation_1246  1
    load_1_8_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_968  -25
    arc_1_8_18  connected_order_arc_969  -14
    arc_1_8_18  out_degree_1242  1
    arc_1_8_18  in_degree_1288  1
    arc_1_8_18  original_T_including_depot_unload_1315  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_968  1
    load_1_8_18  segment_load_conservation_1246  1
    load_1_8_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_970  -25
    arc_1_8_19  connected_order_arc_971  -14
    arc_1_8_19  out_degree_1242  1
    arc_1_8_19  in_degree_1294  1
    arc_1_8_19  original_T_including_depot_unload_1315  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_970  1
    load_1_8_19  segment_load_conservation_1246  1
    load_1_8_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_972  -25
    arc_1_8_20  connected_order_arc_973  -14
    arc_1_8_20  out_degree_1242  1
    arc_1_8_20  in_degree_1300  1
    arc_1_8_20  original_T_including_depot_unload_1315  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_972  1
    load_1_8_20  segment_load_conservation_1246  1
    load_1_8_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_974  -25
    arc_1_8_21  connected_order_arc_975  -14
    arc_1_8_21  out_degree_1242  1
    arc_1_8_21  in_degree_1306  1
    arc_1_8_21  original_T_including_depot_unload_1315  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_974  1
    load_1_8_21  segment_load_conservation_1246  1
    load_1_8_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_976  -25
    arc_1_9_0  depot_return_or_bypass_1227  1
    arc_1_9_0  out_degree_1249  1
    arc_1_9_0  original_T_including_depot_unload_1315  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_976  1
    load_1_9_0  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_977  -25
    arc_1_9_6  connected_order_arc_978  -14
    arc_1_9_6  in_degree_1229  1
    arc_1_9_6  out_degree_1249  1
    arc_1_9_6  original_T_including_depot_unload_1315  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_977  1
    load_1_9_6  segment_load_conservation_1232  -1
    load_1_9_6  segment_prefix_lb_1233  1
    load_1_9_6  segment_prefix_ub_1234  1
    load_1_9_6  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_979  -25
    arc_1_9_7  connected_order_arc_980  -14
    arc_1_9_7  in_degree_1236  1
    arc_1_9_7  out_degree_1249  1
    arc_1_9_7  original_T_including_depot_unload_1315  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_979  1
    load_1_9_7  segment_load_conservation_1239  -1
    load_1_9_7  segment_prefix_lb_1240  1
    load_1_9_7  segment_prefix_ub_1241  1
    load_1_9_7  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_981  -25
    arc_1_9_8  connected_order_arc_982  -14
    arc_1_9_8  in_degree_1243  1
    arc_1_9_8  out_degree_1249  1
    arc_1_9_8  original_T_including_depot_unload_1315  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_981  1
    load_1_9_8  segment_load_conservation_1246  -1
    load_1_9_8  segment_prefix_lb_1247  1
    load_1_9_8  segment_prefix_ub_1248  1
    load_1_9_8  segment_load_conservation_1253  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_983  -25
    arc_1_9_10  connected_order_arc_984  -14
    arc_1_9_10  out_degree_1249  1
    arc_1_9_10  in_degree_1257  1
    arc_1_9_10  original_T_including_depot_unload_1315  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_983  1
    load_1_9_10  segment_load_conservation_1253  1
    load_1_9_10  segment_load_conservation_1260  -1
    load_1_9_10  segment_prefix_lb_1261  1
    load_1_9_10  segment_prefix_ub_1262  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_985  -25
    arc_1_9_14  connected_order_arc_986  -14
    arc_1_9_14  out_degree_1249  1
    arc_1_9_14  in_degree_1264  1
    arc_1_9_14  original_T_including_depot_unload_1315  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_985  1
    load_1_9_14  segment_load_conservation_1253  1
    load_1_9_14  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_987  -25
    arc_1_9_15  connected_order_arc_988  -14
    arc_1_9_15  out_degree_1249  1
    arc_1_9_15  in_degree_1270  1
    arc_1_9_15  original_T_including_depot_unload_1315  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_987  1
    load_1_9_15  segment_load_conservation_1253  1
    load_1_9_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_989  -25
    arc_1_9_16  connected_order_arc_990  -14
    arc_1_9_16  out_degree_1249  1
    arc_1_9_16  in_degree_1276  1
    arc_1_9_16  original_T_including_depot_unload_1315  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_989  1
    load_1_9_16  segment_load_conservation_1253  1
    load_1_9_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_991  -25
    arc_1_9_17  connected_order_arc_992  -14
    arc_1_9_17  out_degree_1249  1
    arc_1_9_17  in_degree_1282  1
    arc_1_9_17  original_T_including_depot_unload_1315  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_991  1
    load_1_9_17  segment_load_conservation_1253  1
    load_1_9_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_993  -25
    arc_1_9_18  connected_order_arc_994  -14
    arc_1_9_18  out_degree_1249  1
    arc_1_9_18  in_degree_1288  1
    arc_1_9_18  original_T_including_depot_unload_1315  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_993  1
    load_1_9_18  segment_load_conservation_1253  1
    load_1_9_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_995  -25
    arc_1_9_19  connected_order_arc_996  -14
    arc_1_9_19  out_degree_1249  1
    arc_1_9_19  in_degree_1294  1
    arc_1_9_19  original_T_including_depot_unload_1315  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_995  1
    load_1_9_19  segment_load_conservation_1253  1
    load_1_9_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_997  -25
    arc_1_9_20  connected_order_arc_998  -14
    arc_1_9_20  out_degree_1249  1
    arc_1_9_20  in_degree_1300  1
    arc_1_9_20  original_T_including_depot_unload_1315  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_997  1
    load_1_9_20  segment_load_conservation_1253  1
    load_1_9_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_999  -25
    arc_1_9_21  connected_order_arc_1000  -14
    arc_1_9_21  out_degree_1249  1
    arc_1_9_21  in_degree_1306  1
    arc_1_9_21  original_T_including_depot_unload_1315  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_999  1
    load_1_9_21  segment_load_conservation_1253  1
    load_1_9_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_1001  -25
    arc_1_10_0  depot_return_or_bypass_1227  1
    arc_1_10_0  out_degree_1256  1
    arc_1_10_0  original_T_including_depot_unload_1315  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_1001  1
    load_1_10_0  segment_load_conservation_1260  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_1002  -25
    arc_1_10_6  connected_order_arc_1003  -14
    arc_1_10_6  in_degree_1229  1
    arc_1_10_6  out_degree_1256  1
    arc_1_10_6  original_T_including_depot_unload_1315  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_1002  1
    load_1_10_6  segment_load_conservation_1232  -1
    load_1_10_6  segment_prefix_lb_1233  1
    load_1_10_6  segment_prefix_ub_1234  1
    load_1_10_6  segment_load_conservation_1260  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_1004  -25
    arc_1_10_7  connected_order_arc_1005  -14
    arc_1_10_7  in_degree_1236  1
    arc_1_10_7  out_degree_1256  1
    arc_1_10_7  original_T_including_depot_unload_1315  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_1004  1
    load_1_10_7  segment_load_conservation_1239  -1
    load_1_10_7  segment_prefix_lb_1240  1
    load_1_10_7  segment_prefix_ub_1241  1
    load_1_10_7  segment_load_conservation_1260  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_1006  -25
    arc_1_10_8  connected_order_arc_1007  -14
    arc_1_10_8  in_degree_1243  1
    arc_1_10_8  out_degree_1256  1
    arc_1_10_8  original_T_including_depot_unload_1315  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_1006  1
    load_1_10_8  segment_load_conservation_1246  -1
    load_1_10_8  segment_prefix_lb_1247  1
    load_1_10_8  segment_prefix_ub_1248  1
    load_1_10_8  segment_load_conservation_1260  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_1008  -25
    arc_1_10_9  connected_order_arc_1009  -14
    arc_1_10_9  in_degree_1250  1
    arc_1_10_9  out_degree_1256  1
    arc_1_10_9  original_T_including_depot_unload_1315  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_1008  1
    load_1_10_9  segment_load_conservation_1253  -1
    load_1_10_9  segment_prefix_lb_1254  1
    load_1_10_9  segment_prefix_ub_1255  1
    load_1_10_9  segment_load_conservation_1260  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_1010  -25
    arc_1_10_14  connected_order_arc_1011  -14
    arc_1_10_14  out_degree_1256  1
    arc_1_10_14  in_degree_1264  1
    arc_1_10_14  original_T_including_depot_unload_1315  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_1010  1
    load_1_10_14  segment_load_conservation_1260  1
    load_1_10_14  free_load_conservation_1268  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_1012  -25
    arc_1_10_15  connected_order_arc_1013  -14
    arc_1_10_15  out_degree_1256  1
    arc_1_10_15  in_degree_1270  1
    arc_1_10_15  original_T_including_depot_unload_1315  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_1012  1
    load_1_10_15  segment_load_conservation_1260  1
    load_1_10_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_16  arc_capacity_1014  -25
    arc_1_10_16  connected_order_arc_1015  -14
    arc_1_10_16  out_degree_1256  1
    arc_1_10_16  in_degree_1276  1
    arc_1_10_16  original_T_including_depot_unload_1315  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_16  arc_capacity_1014  1
    load_1_10_16  segment_load_conservation_1260  1
    load_1_10_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_17  arc_capacity_1016  -25
    arc_1_10_17  connected_order_arc_1017  -14
    arc_1_10_17  out_degree_1256  1
    arc_1_10_17  in_degree_1282  1
    arc_1_10_17  original_T_including_depot_unload_1315  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_17  arc_capacity_1016  1
    load_1_10_17  segment_load_conservation_1260  1
    load_1_10_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_18  arc_capacity_1018  -25
    arc_1_10_18  connected_order_arc_1019  -14
    arc_1_10_18  out_degree_1256  1
    arc_1_10_18  in_degree_1288  1
    arc_1_10_18  original_T_including_depot_unload_1315  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_18  arc_capacity_1018  1
    load_1_10_18  segment_load_conservation_1260  1
    load_1_10_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_19  arc_capacity_1020  -25
    arc_1_10_19  connected_order_arc_1021  -14
    arc_1_10_19  out_degree_1256  1
    arc_1_10_19  in_degree_1294  1
    arc_1_10_19  original_T_including_depot_unload_1315  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_19  arc_capacity_1020  1
    load_1_10_19  segment_load_conservation_1260  1
    load_1_10_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_20  arc_capacity_1022  -25
    arc_1_10_20  connected_order_arc_1023  -14
    arc_1_10_20  out_degree_1256  1
    arc_1_10_20  in_degree_1300  1
    arc_1_10_20  original_T_including_depot_unload_1315  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_20  arc_capacity_1022  1
    load_1_10_20  segment_load_conservation_1260  1
    load_1_10_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_21  arc_capacity_1024  -25
    arc_1_10_21  connected_order_arc_1025  -14
    arc_1_10_21  out_degree_1256  1
    arc_1_10_21  in_degree_1306  1
    arc_1_10_21  original_T_including_depot_unload_1315  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_10_21  arc_capacity_1024  1
    load_1_10_21  segment_load_conservation_1260  1
    load_1_10_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1026  -25
    arc_1_14_0  depot_return_or_bypass_1227  1
    arc_1_14_0  out_degree_1263  1
    arc_1_14_0  original_T_including_depot_unload_1315  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1026  1
    load_1_14_0  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_1027  -25
    arc_1_14_6  connected_order_arc_1028  -14
    arc_1_14_6  in_degree_1229  1
    arc_1_14_6  out_degree_1263  1
    arc_1_14_6  original_T_including_depot_unload_1315  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_1027  1
    load_1_14_6  segment_load_conservation_1232  -1
    load_1_14_6  segment_prefix_lb_1233  1
    load_1_14_6  segment_prefix_ub_1234  1
    load_1_14_6  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1029  -25
    arc_1_14_7  connected_order_arc_1030  -14
    arc_1_14_7  in_degree_1236  1
    arc_1_14_7  out_degree_1263  1
    arc_1_14_7  original_T_including_depot_unload_1315  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1029  1
    load_1_14_7  segment_load_conservation_1239  -1
    load_1_14_7  segment_prefix_lb_1240  1
    load_1_14_7  segment_prefix_ub_1241  1
    load_1_14_7  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1031  -25
    arc_1_14_8  connected_order_arc_1032  -14
    arc_1_14_8  in_degree_1243  1
    arc_1_14_8  out_degree_1263  1
    arc_1_14_8  original_T_including_depot_unload_1315  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1031  1
    load_1_14_8  segment_load_conservation_1246  -1
    load_1_14_8  segment_prefix_lb_1247  1
    load_1_14_8  segment_prefix_ub_1248  1
    load_1_14_8  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1033  -25
    arc_1_14_9  connected_order_arc_1034  -14
    arc_1_14_9  in_degree_1250  1
    arc_1_14_9  out_degree_1263  1
    arc_1_14_9  original_T_including_depot_unload_1315  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1033  1
    load_1_14_9  segment_load_conservation_1253  -1
    load_1_14_9  segment_prefix_lb_1254  1
    load_1_14_9  segment_prefix_ub_1255  1
    load_1_14_9  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_1035  -25
    arc_1_14_10  connected_order_arc_1036  -14
    arc_1_14_10  in_degree_1257  1
    arc_1_14_10  out_degree_1263  1
    arc_1_14_10  original_T_including_depot_unload_1315  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_1035  1
    load_1_14_10  segment_load_conservation_1260  -1
    load_1_14_10  segment_prefix_lb_1261  1
    load_1_14_10  segment_prefix_ub_1262  1
    load_1_14_10  free_load_conservation_1268  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1037  -25
    arc_1_14_15  connected_order_arc_1038  -14
    arc_1_14_15  out_degree_1263  1
    arc_1_14_15  in_degree_1270  1
    arc_1_14_15  original_T_including_depot_unload_1315  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1037  1
    load_1_14_15  free_load_conservation_1268  1
    load_1_14_15  free_load_conservation_1274  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1039  -25
    arc_1_14_16  connected_order_arc_1040  -14
    arc_1_14_16  out_degree_1263  1
    arc_1_14_16  in_degree_1276  1
    arc_1_14_16  original_T_including_depot_unload_1315  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1039  1
    load_1_14_16  free_load_conservation_1268  1
    load_1_14_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1041  -25
    arc_1_14_17  connected_order_arc_1042  -14
    arc_1_14_17  out_degree_1263  1
    arc_1_14_17  in_degree_1282  1
    arc_1_14_17  original_T_including_depot_unload_1315  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1041  1
    load_1_14_17  free_load_conservation_1268  1
    load_1_14_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1043  -25
    arc_1_14_18  connected_order_arc_1044  -14
    arc_1_14_18  out_degree_1263  1
    arc_1_14_18  in_degree_1288  1
    arc_1_14_18  original_T_including_depot_unload_1315  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1043  1
    load_1_14_18  free_load_conservation_1268  1
    load_1_14_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1045  -25
    arc_1_14_19  connected_order_arc_1046  -14
    arc_1_14_19  out_degree_1263  1
    arc_1_14_19  in_degree_1294  1
    arc_1_14_19  original_T_including_depot_unload_1315  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1045  1
    load_1_14_19  free_load_conservation_1268  1
    load_1_14_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1047  -25
    arc_1_14_20  connected_order_arc_1048  -14
    arc_1_14_20  out_degree_1263  1
    arc_1_14_20  in_degree_1300  1
    arc_1_14_20  original_T_including_depot_unload_1315  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1047  1
    load_1_14_20  free_load_conservation_1268  1
    load_1_14_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_1049  -25
    arc_1_14_21  connected_order_arc_1050  -14
    arc_1_14_21  out_degree_1263  1
    arc_1_14_21  in_degree_1306  1
    arc_1_14_21  original_T_including_depot_unload_1315  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_1049  1
    load_1_14_21  free_load_conservation_1268  1
    load_1_14_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1051  -25
    arc_1_15_0  depot_return_or_bypass_1227  1
    arc_1_15_0  out_degree_1269  1
    arc_1_15_0  original_T_including_depot_unload_1315  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1051  1
    load_1_15_0  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1052  -25
    arc_1_15_6  connected_order_arc_1053  -14
    arc_1_15_6  in_degree_1229  1
    arc_1_15_6  out_degree_1269  1
    arc_1_15_6  original_T_including_depot_unload_1315  1.1017171222416982e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1052  1
    load_1_15_6  segment_load_conservation_1232  -1
    load_1_15_6  segment_prefix_lb_1233  1
    load_1_15_6  segment_prefix_ub_1234  1
    load_1_15_6  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1054  -25
    arc_1_15_7  connected_order_arc_1055  -14
    arc_1_15_7  in_degree_1236  1
    arc_1_15_7  out_degree_1269  1
    arc_1_15_7  original_T_including_depot_unload_1315  1.2434091529834902e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1054  1
    load_1_15_7  segment_load_conservation_1239  -1
    load_1_15_7  segment_prefix_lb_1240  1
    load_1_15_7  segment_prefix_ub_1241  1
    load_1_15_7  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1056  -25
    arc_1_15_8  connected_order_arc_1057  -14
    arc_1_15_8  in_degree_1243  1
    arc_1_15_8  out_degree_1269  1
    arc_1_15_8  original_T_including_depot_unload_1315  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1056  1
    load_1_15_8  segment_load_conservation_1246  -1
    load_1_15_8  segment_prefix_lb_1247  1
    load_1_15_8  segment_prefix_ub_1248  1
    load_1_15_8  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1058  -25
    arc_1_15_9  connected_order_arc_1059  -14
    arc_1_15_9  in_degree_1250  1
    arc_1_15_9  out_degree_1269  1
    arc_1_15_9  original_T_including_depot_unload_1315  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1058  1
    load_1_15_9  segment_load_conservation_1253  -1
    load_1_15_9  segment_prefix_lb_1254  1
    load_1_15_9  segment_prefix_ub_1255  1
    load_1_15_9  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1060  -25
    arc_1_15_10  connected_order_arc_1061  -14
    arc_1_15_10  in_degree_1257  1
    arc_1_15_10  out_degree_1269  1
    arc_1_15_10  original_T_including_depot_unload_1315  5.6127522609820687e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1060  1
    load_1_15_10  segment_load_conservation_1260  -1
    load_1_15_10  segment_prefix_lb_1261  1
    load_1_15_10  segment_prefix_ub_1262  1
    load_1_15_10  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1062  -25
    arc_1_15_14  connected_order_arc_1063  -14
    arc_1_15_14  in_degree_1264  1
    arc_1_15_14  out_degree_1269  1
    arc_1_15_14  original_T_including_depot_unload_1315  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1062  1
    load_1_15_14  free_load_conservation_1268  -1
    load_1_15_14  free_load_conservation_1274  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1064  -25
    arc_1_15_16  connected_order_arc_1065  -14
    arc_1_15_16  out_degree_1269  1
    arc_1_15_16  in_degree_1276  1
    arc_1_15_16  original_T_including_depot_unload_1315  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1064  1
    load_1_15_16  free_load_conservation_1274  1
    load_1_15_16  free_load_conservation_1280  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1066  -25
    arc_1_15_17  connected_order_arc_1067  -14
    arc_1_15_17  out_degree_1269  1
    arc_1_15_17  in_degree_1282  1
    arc_1_15_17  original_T_including_depot_unload_1315  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1066  1
    load_1_15_17  free_load_conservation_1274  1
    load_1_15_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1068  -25
    arc_1_15_18  connected_order_arc_1069  -14
    arc_1_15_18  out_degree_1269  1
    arc_1_15_18  in_degree_1288  1
    arc_1_15_18  original_T_including_depot_unload_1315  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1068  1
    load_1_15_18  free_load_conservation_1274  1
    load_1_15_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1070  -25
    arc_1_15_19  connected_order_arc_1071  -14
    arc_1_15_19  out_degree_1269  1
    arc_1_15_19  in_degree_1294  1
    arc_1_15_19  original_T_including_depot_unload_1315  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1070  1
    load_1_15_19  free_load_conservation_1274  1
    load_1_15_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1072  -25
    arc_1_15_20  connected_order_arc_1073  -14
    arc_1_15_20  out_degree_1269  1
    arc_1_15_20  in_degree_1300  1
    arc_1_15_20  original_T_including_depot_unload_1315  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1072  1
    load_1_15_20  free_load_conservation_1274  1
    load_1_15_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_1074  -25
    arc_1_15_21  connected_order_arc_1075  -14
    arc_1_15_21  out_degree_1269  1
    arc_1_15_21  in_degree_1306  1
    arc_1_15_21  original_T_including_depot_unload_1315  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_1074  1
    load_1_15_21  free_load_conservation_1274  1
    load_1_15_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1076  -25
    arc_1_16_0  depot_return_or_bypass_1227  1
    arc_1_16_0  out_degree_1275  1
    arc_1_16_0  original_T_including_depot_unload_1315  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1076  1
    load_1_16_0  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1077  -25
    arc_1_16_6  connected_order_arc_1078  -14
    arc_1_16_6  in_degree_1229  1
    arc_1_16_6  out_degree_1275  1
    arc_1_16_6  original_T_including_depot_unload_1315  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1077  1
    load_1_16_6  segment_load_conservation_1232  -1
    load_1_16_6  segment_prefix_lb_1233  1
    load_1_16_6  segment_prefix_ub_1234  1
    load_1_16_6  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1079  -25
    arc_1_16_7  connected_order_arc_1080  -14
    arc_1_16_7  in_degree_1236  1
    arc_1_16_7  out_degree_1275  1
    arc_1_16_7  original_T_including_depot_unload_1315  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1079  1
    load_1_16_7  segment_load_conservation_1239  -1
    load_1_16_7  segment_prefix_lb_1240  1
    load_1_16_7  segment_prefix_ub_1241  1
    load_1_16_7  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1081  -25
    arc_1_16_8  connected_order_arc_1082  -14
    arc_1_16_8  in_degree_1243  1
    arc_1_16_8  out_degree_1275  1
    arc_1_16_8  original_T_including_depot_unload_1315  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1081  1
    load_1_16_8  segment_load_conservation_1246  -1
    load_1_16_8  segment_prefix_lb_1247  1
    load_1_16_8  segment_prefix_ub_1248  1
    load_1_16_8  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1083  -25
    arc_1_16_9  connected_order_arc_1084  -14
    arc_1_16_9  in_degree_1250  1
    arc_1_16_9  out_degree_1275  1
    arc_1_16_9  original_T_including_depot_unload_1315  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1083  1
    load_1_16_9  segment_load_conservation_1253  -1
    load_1_16_9  segment_prefix_lb_1254  1
    load_1_16_9  segment_prefix_ub_1255  1
    load_1_16_9  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_10  arc_capacity_1085  -25
    arc_1_16_10  connected_order_arc_1086  -14
    arc_1_16_10  in_degree_1257  1
    arc_1_16_10  out_degree_1275  1
    arc_1_16_10  original_T_including_depot_unload_1315  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_10  arc_capacity_1085  1
    load_1_16_10  segment_load_conservation_1260  -1
    load_1_16_10  segment_prefix_lb_1261  1
    load_1_16_10  segment_prefix_ub_1262  1
    load_1_16_10  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1087  -25
    arc_1_16_14  connected_order_arc_1088  -14
    arc_1_16_14  in_degree_1264  1
    arc_1_16_14  out_degree_1275  1
    arc_1_16_14  original_T_including_depot_unload_1315  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1087  1
    load_1_16_14  free_load_conservation_1268  -1
    load_1_16_14  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1089  -25
    arc_1_16_15  connected_order_arc_1090  -14
    arc_1_16_15  in_degree_1270  1
    arc_1_16_15  out_degree_1275  1
    arc_1_16_15  original_T_including_depot_unload_1315  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1089  1
    load_1_16_15  free_load_conservation_1274  -1
    load_1_16_15  free_load_conservation_1280  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1091  -25
    arc_1_16_17  connected_order_arc_1092  -14
    arc_1_16_17  out_degree_1275  1
    arc_1_16_17  in_degree_1282  1
    arc_1_16_17  original_T_including_depot_unload_1315  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1091  1
    load_1_16_17  free_load_conservation_1280  1
    load_1_16_17  free_load_conservation_1286  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1093  -25
    arc_1_16_18  connected_order_arc_1094  -14
    arc_1_16_18  out_degree_1275  1
    arc_1_16_18  in_degree_1288  1
    arc_1_16_18  original_T_including_depot_unload_1315  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1093  1
    load_1_16_18  free_load_conservation_1280  1
    load_1_16_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1095  -25
    arc_1_16_19  connected_order_arc_1096  -14
    arc_1_16_19  out_degree_1275  1
    arc_1_16_19  in_degree_1294  1
    arc_1_16_19  original_T_including_depot_unload_1315  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1095  1
    load_1_16_19  free_load_conservation_1280  1
    load_1_16_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1097  -25
    arc_1_16_20  connected_order_arc_1098  -14
    arc_1_16_20  out_degree_1275  1
    arc_1_16_20  in_degree_1300  1
    arc_1_16_20  original_T_including_depot_unload_1315  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1097  1
    load_1_16_20  free_load_conservation_1280  1
    load_1_16_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1099  -25
    arc_1_16_21  connected_order_arc_1100  -14
    arc_1_16_21  out_degree_1275  1
    arc_1_16_21  in_degree_1306  1
    arc_1_16_21  original_T_including_depot_unload_1315  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1099  1
    load_1_16_21  free_load_conservation_1280  1
    load_1_16_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1101  -25
    arc_1_17_0  depot_return_or_bypass_1227  1
    arc_1_17_0  out_degree_1281  1
    arc_1_17_0  original_T_including_depot_unload_1315  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1101  1
    load_1_17_0  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1102  -25
    arc_1_17_6  connected_order_arc_1103  -14
    arc_1_17_6  in_degree_1229  1
    arc_1_17_6  out_degree_1281  1
    arc_1_17_6  original_T_including_depot_unload_1315  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1102  1
    load_1_17_6  segment_load_conservation_1232  -1
    load_1_17_6  segment_prefix_lb_1233  1
    load_1_17_6  segment_prefix_ub_1234  1
    load_1_17_6  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1104  -25
    arc_1_17_7  connected_order_arc_1105  -14
    arc_1_17_7  in_degree_1236  1
    arc_1_17_7  out_degree_1281  1
    arc_1_17_7  original_T_including_depot_unload_1315  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1104  1
    load_1_17_7  segment_load_conservation_1239  -1
    load_1_17_7  segment_prefix_lb_1240  1
    load_1_17_7  segment_prefix_ub_1241  1
    load_1_17_7  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1106  -25
    arc_1_17_8  connected_order_arc_1107  -14
    arc_1_17_8  in_degree_1243  1
    arc_1_17_8  out_degree_1281  1
    arc_1_17_8  original_T_including_depot_unload_1315  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1106  1
    load_1_17_8  segment_load_conservation_1246  -1
    load_1_17_8  segment_prefix_lb_1247  1
    load_1_17_8  segment_prefix_ub_1248  1
    load_1_17_8  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1108  -25
    arc_1_17_9  connected_order_arc_1109  -14
    arc_1_17_9  in_degree_1250  1
    arc_1_17_9  out_degree_1281  1
    arc_1_17_9  original_T_including_depot_unload_1315  9.4424191477021122e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1108  1
    load_1_17_9  segment_load_conservation_1253  -1
    load_1_17_9  segment_prefix_lb_1254  1
    load_1_17_9  segment_prefix_ub_1255  1
    load_1_17_9  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_10  arc_capacity_1110  -25
    arc_1_17_10  connected_order_arc_1111  -14
    arc_1_17_10  in_degree_1257  1
    arc_1_17_10  out_degree_1281  1
    arc_1_17_10  original_T_including_depot_unload_1315  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_10  arc_capacity_1110  1
    load_1_17_10  segment_load_conservation_1260  -1
    load_1_17_10  segment_prefix_lb_1261  1
    load_1_17_10  segment_prefix_ub_1262  1
    load_1_17_10  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1112  -25
    arc_1_17_14  connected_order_arc_1113  -14
    arc_1_17_14  in_degree_1264  1
    arc_1_17_14  out_degree_1281  1
    arc_1_17_14  original_T_including_depot_unload_1315  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1112  1
    load_1_17_14  free_load_conservation_1268  -1
    load_1_17_14  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1114  -25
    arc_1_17_15  connected_order_arc_1115  -14
    arc_1_17_15  in_degree_1270  1
    arc_1_17_15  out_degree_1281  1
    arc_1_17_15  original_T_including_depot_unload_1315  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1114  1
    load_1_17_15  free_load_conservation_1274  -1
    load_1_17_15  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1116  -25
    arc_1_17_16  connected_order_arc_1117  -14
    arc_1_17_16  in_degree_1276  1
    arc_1_17_16  out_degree_1281  1
    arc_1_17_16  original_T_including_depot_unload_1315  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1116  1
    load_1_17_16  free_load_conservation_1280  -1
    load_1_17_16  free_load_conservation_1286  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1118  -25
    arc_1_17_18  connected_order_arc_1119  -14
    arc_1_17_18  out_degree_1281  1
    arc_1_17_18  in_degree_1288  1
    arc_1_17_18  original_T_including_depot_unload_1315  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1118  1
    load_1_17_18  free_load_conservation_1286  1
    load_1_17_18  free_load_conservation_1292  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1120  -25
    arc_1_17_19  connected_order_arc_1121  -14
    arc_1_17_19  out_degree_1281  1
    arc_1_17_19  in_degree_1294  1
    arc_1_17_19  original_T_including_depot_unload_1315  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1120  1
    load_1_17_19  free_load_conservation_1286  1
    load_1_17_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1122  -25
    arc_1_17_20  connected_order_arc_1123  -14
    arc_1_17_20  out_degree_1281  1
    arc_1_17_20  in_degree_1300  1
    arc_1_17_20  original_T_including_depot_unload_1315  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1122  1
    load_1_17_20  free_load_conservation_1286  1
    load_1_17_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1124  -25
    arc_1_17_21  connected_order_arc_1125  -14
    arc_1_17_21  out_degree_1281  1
    arc_1_17_21  in_degree_1306  1
    arc_1_17_21  original_T_including_depot_unload_1315  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1124  1
    load_1_17_21  free_load_conservation_1286  1
    load_1_17_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1126  -25
    arc_1_18_0  depot_return_or_bypass_1227  1
    arc_1_18_0  out_degree_1287  1
    arc_1_18_0  original_T_including_depot_unload_1315  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1126  1
    load_1_18_0  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1127  -25
    arc_1_18_6  connected_order_arc_1128  -14
    arc_1_18_6  in_degree_1229  1
    arc_1_18_6  out_degree_1287  1
    arc_1_18_6  original_T_including_depot_unload_1315  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1127  1
    load_1_18_6  segment_load_conservation_1232  -1
    load_1_18_6  segment_prefix_lb_1233  1
    load_1_18_6  segment_prefix_ub_1234  1
    load_1_18_6  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1129  -25
    arc_1_18_7  connected_order_arc_1130  -14
    arc_1_18_7  in_degree_1236  1
    arc_1_18_7  out_degree_1287  1
    arc_1_18_7  original_T_including_depot_unload_1315  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1129  1
    load_1_18_7  segment_load_conservation_1239  -1
    load_1_18_7  segment_prefix_lb_1240  1
    load_1_18_7  segment_prefix_ub_1241  1
    load_1_18_7  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1131  -25
    arc_1_18_8  connected_order_arc_1132  -14
    arc_1_18_8  in_degree_1243  1
    arc_1_18_8  out_degree_1287  1
    arc_1_18_8  original_T_including_depot_unload_1315  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1131  1
    load_1_18_8  segment_load_conservation_1246  -1
    load_1_18_8  segment_prefix_lb_1247  1
    load_1_18_8  segment_prefix_ub_1248  1
    load_1_18_8  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1133  -25
    arc_1_18_9  connected_order_arc_1134  -14
    arc_1_18_9  in_degree_1250  1
    arc_1_18_9  out_degree_1287  1
    arc_1_18_9  original_T_including_depot_unload_1315  1.0921272639748563e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1133  1
    load_1_18_9  segment_load_conservation_1253  -1
    load_1_18_9  segment_prefix_lb_1254  1
    load_1_18_9  segment_prefix_ub_1255  1
    load_1_18_9  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_10  arc_capacity_1135  -25
    arc_1_18_10  connected_order_arc_1136  -14
    arc_1_18_10  in_degree_1257  1
    arc_1_18_10  out_degree_1287  1
    arc_1_18_10  original_T_including_depot_unload_1315  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_10  arc_capacity_1135  1
    load_1_18_10  segment_load_conservation_1260  -1
    load_1_18_10  segment_prefix_lb_1261  1
    load_1_18_10  segment_prefix_ub_1262  1
    load_1_18_10  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1137  -25
    arc_1_18_14  connected_order_arc_1138  -14
    arc_1_18_14  in_degree_1264  1
    arc_1_18_14  out_degree_1287  1
    arc_1_18_14  original_T_including_depot_unload_1315  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1137  1
    load_1_18_14  free_load_conservation_1268  -1
    load_1_18_14  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1139  -25
    arc_1_18_15  connected_order_arc_1140  -14
    arc_1_18_15  in_degree_1270  1
    arc_1_18_15  out_degree_1287  1
    arc_1_18_15  original_T_including_depot_unload_1315  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1139  1
    load_1_18_15  free_load_conservation_1274  -1
    load_1_18_15  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1141  -25
    arc_1_18_16  connected_order_arc_1142  -14
    arc_1_18_16  in_degree_1276  1
    arc_1_18_16  out_degree_1287  1
    arc_1_18_16  original_T_including_depot_unload_1315  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1141  1
    load_1_18_16  free_load_conservation_1280  -1
    load_1_18_16  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1143  -25
    arc_1_18_17  connected_order_arc_1144  -14
    arc_1_18_17  in_degree_1282  1
    arc_1_18_17  out_degree_1287  1
    arc_1_18_17  original_T_including_depot_unload_1315  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1143  1
    load_1_18_17  free_load_conservation_1286  -1
    load_1_18_17  free_load_conservation_1292  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1145  -25
    arc_1_18_19  connected_order_arc_1146  -14
    arc_1_18_19  out_degree_1287  1
    arc_1_18_19  in_degree_1294  1
    arc_1_18_19  original_T_including_depot_unload_1315  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1145  1
    load_1_18_19  free_load_conservation_1292  1
    load_1_18_19  free_load_conservation_1298  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1147  -25
    arc_1_18_20  connected_order_arc_1148  -14
    arc_1_18_20  out_degree_1287  1
    arc_1_18_20  in_degree_1300  1
    arc_1_18_20  original_T_including_depot_unload_1315  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1147  1
    load_1_18_20  free_load_conservation_1292  1
    load_1_18_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1149  -25
    arc_1_18_21  connected_order_arc_1150  -14
    arc_1_18_21  out_degree_1287  1
    arc_1_18_21  in_degree_1306  1
    arc_1_18_21  original_T_including_depot_unload_1315  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1149  1
    load_1_18_21  free_load_conservation_1292  1
    load_1_18_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1151  -25
    arc_1_19_0  depot_return_or_bypass_1227  1
    arc_1_19_0  out_degree_1293  1
    arc_1_19_0  original_T_including_depot_unload_1315  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1151  1
    load_1_19_0  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1152  -25
    arc_1_19_6  connected_order_arc_1153  -14
    arc_1_19_6  in_degree_1229  1
    arc_1_19_6  out_degree_1293  1
    arc_1_19_6  original_T_including_depot_unload_1315  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1152  1
    load_1_19_6  segment_load_conservation_1232  -1
    load_1_19_6  segment_prefix_lb_1233  1
    load_1_19_6  segment_prefix_ub_1234  1
    load_1_19_6  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1154  -25
    arc_1_19_7  connected_order_arc_1155  -14
    arc_1_19_7  in_degree_1236  1
    arc_1_19_7  out_degree_1293  1
    arc_1_19_7  original_T_including_depot_unload_1315  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1154  1
    load_1_19_7  segment_load_conservation_1239  -1
    load_1_19_7  segment_prefix_lb_1240  1
    load_1_19_7  segment_prefix_ub_1241  1
    load_1_19_7  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1156  -25
    arc_1_19_8  connected_order_arc_1157  -14
    arc_1_19_8  in_degree_1243  1
    arc_1_19_8  out_degree_1293  1
    arc_1_19_8  original_T_including_depot_unload_1315  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1156  1
    load_1_19_8  segment_load_conservation_1246  -1
    load_1_19_8  segment_prefix_lb_1247  1
    load_1_19_8  segment_prefix_ub_1248  1
    load_1_19_8  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1158  -25
    arc_1_19_9  connected_order_arc_1159  -14
    arc_1_19_9  in_degree_1250  1
    arc_1_19_9  out_degree_1293  1
    arc_1_19_9  original_T_including_depot_unload_1315  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1158  1
    load_1_19_9  segment_load_conservation_1253  -1
    load_1_19_9  segment_prefix_lb_1254  1
    load_1_19_9  segment_prefix_ub_1255  1
    load_1_19_9  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_10  arc_capacity_1160  -25
    arc_1_19_10  connected_order_arc_1161  -14
    arc_1_19_10  in_degree_1257  1
    arc_1_19_10  out_degree_1293  1
    arc_1_19_10  original_T_including_depot_unload_1315  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_10  arc_capacity_1160  1
    load_1_19_10  segment_load_conservation_1260  -1
    load_1_19_10  segment_prefix_lb_1261  1
    load_1_19_10  segment_prefix_ub_1262  1
    load_1_19_10  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1162  -25
    arc_1_19_14  connected_order_arc_1163  -14
    arc_1_19_14  in_degree_1264  1
    arc_1_19_14  out_degree_1293  1
    arc_1_19_14  original_T_including_depot_unload_1315  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1162  1
    load_1_19_14  free_load_conservation_1268  -1
    load_1_19_14  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1164  -25
    arc_1_19_15  connected_order_arc_1165  -14
    arc_1_19_15  in_degree_1270  1
    arc_1_19_15  out_degree_1293  1
    arc_1_19_15  original_T_including_depot_unload_1315  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1164  1
    load_1_19_15  free_load_conservation_1274  -1
    load_1_19_15  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1166  -25
    arc_1_19_16  connected_order_arc_1167  -14
    arc_1_19_16  in_degree_1276  1
    arc_1_19_16  out_degree_1293  1
    arc_1_19_16  original_T_including_depot_unload_1315  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1166  1
    load_1_19_16  free_load_conservation_1280  -1
    load_1_19_16  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1168  -25
    arc_1_19_17  connected_order_arc_1169  -14
    arc_1_19_17  in_degree_1282  1
    arc_1_19_17  out_degree_1293  1
    arc_1_19_17  original_T_including_depot_unload_1315  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1168  1
    load_1_19_17  free_load_conservation_1286  -1
    load_1_19_17  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1170  -25
    arc_1_19_18  connected_order_arc_1171  -14
    arc_1_19_18  in_degree_1288  1
    arc_1_19_18  out_degree_1293  1
    arc_1_19_18  original_T_including_depot_unload_1315  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1170  1
    load_1_19_18  free_load_conservation_1292  -1
    load_1_19_18  free_load_conservation_1298  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1172  -25
    arc_1_19_20  connected_order_arc_1173  -14
    arc_1_19_20  out_degree_1293  1
    arc_1_19_20  in_degree_1300  1
    arc_1_19_20  original_T_including_depot_unload_1315  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1172  1
    load_1_19_20  free_load_conservation_1298  1
    load_1_19_20  free_load_conservation_1304  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1174  -25
    arc_1_19_21  connected_order_arc_1175  -14
    arc_1_19_21  out_degree_1293  1
    arc_1_19_21  in_degree_1306  1
    arc_1_19_21  original_T_including_depot_unload_1315  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1174  1
    load_1_19_21  free_load_conservation_1298  1
    load_1_19_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1176  -25
    arc_1_20_0  depot_return_or_bypass_1227  1
    arc_1_20_0  out_degree_1299  1
    arc_1_20_0  original_T_including_depot_unload_1315  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1176  1
    load_1_20_0  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1177  -25
    arc_1_20_6  connected_order_arc_1178  -14
    arc_1_20_6  in_degree_1229  1
    arc_1_20_6  out_degree_1299  1
    arc_1_20_6  original_T_including_depot_unload_1315  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1177  1
    load_1_20_6  segment_load_conservation_1232  -1
    load_1_20_6  segment_prefix_lb_1233  1
    load_1_20_6  segment_prefix_ub_1234  1
    load_1_20_6  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1179  -25
    arc_1_20_7  connected_order_arc_1180  -14
    arc_1_20_7  in_degree_1236  1
    arc_1_20_7  out_degree_1299  1
    arc_1_20_7  original_T_including_depot_unload_1315  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1179  1
    load_1_20_7  segment_load_conservation_1239  -1
    load_1_20_7  segment_prefix_lb_1240  1
    load_1_20_7  segment_prefix_ub_1241  1
    load_1_20_7  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1181  -25
    arc_1_20_8  connected_order_arc_1182  -14
    arc_1_20_8  in_degree_1243  1
    arc_1_20_8  out_degree_1299  1
    arc_1_20_8  original_T_including_depot_unload_1315  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1181  1
    load_1_20_8  segment_load_conservation_1246  -1
    load_1_20_8  segment_prefix_lb_1247  1
    load_1_20_8  segment_prefix_ub_1248  1
    load_1_20_8  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1183  -25
    arc_1_20_9  connected_order_arc_1184  -14
    arc_1_20_9  in_degree_1250  1
    arc_1_20_9  out_degree_1299  1
    arc_1_20_9  original_T_including_depot_unload_1315  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1183  1
    load_1_20_9  segment_load_conservation_1253  -1
    load_1_20_9  segment_prefix_lb_1254  1
    load_1_20_9  segment_prefix_ub_1255  1
    load_1_20_9  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_10  arc_capacity_1185  -25
    arc_1_20_10  connected_order_arc_1186  -14
    arc_1_20_10  in_degree_1257  1
    arc_1_20_10  out_degree_1299  1
    arc_1_20_10  original_T_including_depot_unload_1315  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_10  arc_capacity_1185  1
    load_1_20_10  segment_load_conservation_1260  -1
    load_1_20_10  segment_prefix_lb_1261  1
    load_1_20_10  segment_prefix_ub_1262  1
    load_1_20_10  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1187  -25
    arc_1_20_14  connected_order_arc_1188  -14
    arc_1_20_14  in_degree_1264  1
    arc_1_20_14  out_degree_1299  1
    arc_1_20_14  original_T_including_depot_unload_1315  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1187  1
    load_1_20_14  free_load_conservation_1268  -1
    load_1_20_14  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1189  -25
    arc_1_20_15  connected_order_arc_1190  -14
    arc_1_20_15  in_degree_1270  1
    arc_1_20_15  out_degree_1299  1
    arc_1_20_15  original_T_including_depot_unload_1315  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1189  1
    load_1_20_15  free_load_conservation_1274  -1
    load_1_20_15  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1191  -25
    arc_1_20_16  connected_order_arc_1192  -14
    arc_1_20_16  in_degree_1276  1
    arc_1_20_16  out_degree_1299  1
    arc_1_20_16  original_T_including_depot_unload_1315  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1191  1
    load_1_20_16  free_load_conservation_1280  -1
    load_1_20_16  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1193  -25
    arc_1_20_17  connected_order_arc_1194  -14
    arc_1_20_17  in_degree_1282  1
    arc_1_20_17  out_degree_1299  1
    arc_1_20_17  original_T_including_depot_unload_1315  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1193  1
    load_1_20_17  free_load_conservation_1286  -1
    load_1_20_17  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1195  -25
    arc_1_20_18  connected_order_arc_1196  -14
    arc_1_20_18  in_degree_1288  1
    arc_1_20_18  out_degree_1299  1
    arc_1_20_18  original_T_including_depot_unload_1315  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1195  1
    load_1_20_18  free_load_conservation_1292  -1
    load_1_20_18  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1197  -25
    arc_1_20_19  connected_order_arc_1198  -14
    arc_1_20_19  in_degree_1294  1
    arc_1_20_19  out_degree_1299  1
    arc_1_20_19  original_T_including_depot_unload_1315  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1197  1
    load_1_20_19  free_load_conservation_1298  -1
    load_1_20_19  free_load_conservation_1304  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1199  -25
    arc_1_20_21  connected_order_arc_1200  -14
    arc_1_20_21  out_degree_1299  1
    arc_1_20_21  in_degree_1306  1
    arc_1_20_21  original_T_including_depot_unload_1315  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1199  1
    load_1_20_21  free_load_conservation_1304  1
    load_1_20_21  free_load_conservation_1310  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1201  -25
    arc_1_21_0  depot_return_or_bypass_1227  1
    arc_1_21_0  out_degree_1305  1
    arc_1_21_0  original_T_including_depot_unload_1315  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1201  1
    load_1_21_0  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1202  -25
    arc_1_21_6  connected_order_arc_1203  -14
    arc_1_21_6  in_degree_1229  1
    arc_1_21_6  out_degree_1305  1
    arc_1_21_6  original_T_including_depot_unload_1315  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1202  1
    load_1_21_6  segment_load_conservation_1232  -1
    load_1_21_6  segment_prefix_lb_1233  1
    load_1_21_6  segment_prefix_ub_1234  1
    load_1_21_6  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1204  -25
    arc_1_21_7  connected_order_arc_1205  -14
    arc_1_21_7  in_degree_1236  1
    arc_1_21_7  out_degree_1305  1
    arc_1_21_7  original_T_including_depot_unload_1315  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1204  1
    load_1_21_7  segment_load_conservation_1239  -1
    load_1_21_7  segment_prefix_lb_1240  1
    load_1_21_7  segment_prefix_ub_1241  1
    load_1_21_7  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1206  -25
    arc_1_21_8  connected_order_arc_1207  -14
    arc_1_21_8  in_degree_1243  1
    arc_1_21_8  out_degree_1305  1
    arc_1_21_8  original_T_including_depot_unload_1315  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1206  1
    load_1_21_8  segment_load_conservation_1246  -1
    load_1_21_8  segment_prefix_lb_1247  1
    load_1_21_8  segment_prefix_ub_1248  1
    load_1_21_8  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1208  -25
    arc_1_21_9  connected_order_arc_1209  -14
    arc_1_21_9  in_degree_1250  1
    arc_1_21_9  out_degree_1305  1
    arc_1_21_9  original_T_including_depot_unload_1315  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1208  1
    load_1_21_9  segment_load_conservation_1253  -1
    load_1_21_9  segment_prefix_lb_1254  1
    load_1_21_9  segment_prefix_ub_1255  1
    load_1_21_9  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_10  arc_capacity_1210  -25
    arc_1_21_10  connected_order_arc_1211  -14
    arc_1_21_10  in_degree_1257  1
    arc_1_21_10  out_degree_1305  1
    arc_1_21_10  original_T_including_depot_unload_1315  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_10  arc_capacity_1210  1
    load_1_21_10  segment_load_conservation_1260  -1
    load_1_21_10  segment_prefix_lb_1261  1
    load_1_21_10  segment_prefix_ub_1262  1
    load_1_21_10  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1212  -25
    arc_1_21_14  connected_order_arc_1213  -14
    arc_1_21_14  in_degree_1264  1
    arc_1_21_14  out_degree_1305  1
    arc_1_21_14  original_T_including_depot_unload_1315  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1212  1
    load_1_21_14  free_load_conservation_1268  -1
    load_1_21_14  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1214  -25
    arc_1_21_15  connected_order_arc_1215  -14
    arc_1_21_15  in_degree_1270  1
    arc_1_21_15  out_degree_1305  1
    arc_1_21_15  original_T_including_depot_unload_1315  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1214  1
    load_1_21_15  free_load_conservation_1274  -1
    load_1_21_15  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1216  -25
    arc_1_21_16  connected_order_arc_1217  -14
    arc_1_21_16  in_degree_1276  1
    arc_1_21_16  out_degree_1305  1
    arc_1_21_16  original_T_including_depot_unload_1315  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1216  1
    load_1_21_16  free_load_conservation_1280  -1
    load_1_21_16  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1218  -25
    arc_1_21_17  connected_order_arc_1219  -14
    arc_1_21_17  in_degree_1282  1
    arc_1_21_17  out_degree_1305  1
    arc_1_21_17  original_T_including_depot_unload_1315  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1218  1
    load_1_21_17  free_load_conservation_1286  -1
    load_1_21_17  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1220  -25
    arc_1_21_18  connected_order_arc_1221  -14
    arc_1_21_18  in_degree_1288  1
    arc_1_21_18  out_degree_1305  1
    arc_1_21_18  original_T_including_depot_unload_1315  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1220  1
    load_1_21_18  free_load_conservation_1292  -1
    load_1_21_18  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1222  -25
    arc_1_21_19  connected_order_arc_1223  -14
    arc_1_21_19  in_degree_1294  1
    arc_1_21_19  out_degree_1305  1
    arc_1_21_19  original_T_including_depot_unload_1315  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1222  1
    load_1_21_19  free_load_conservation_1298  -1
    load_1_21_19  free_load_conservation_1310  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1224  -25
    arc_1_21_20  connected_order_arc_1225  -14
    arc_1_21_20  in_degree_1300  1
    arc_1_21_20  out_degree_1305  1
    arc_1_21_20  original_T_including_depot_unload_1315  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1224  1
    load_1_21_20  free_load_conservation_1304  -1
    load_1_21_20  free_load_conservation_1310  1
    visit_2_11  out_degree_1561  -1
    visit_2_11  in_degree_1562  -1
    visit_2_11  order_active_lb_1563  -1
    visit_2_11  order_active_ub_1564  -11
    order_2_11  connected_order_arc_1330  -1
    order_2_11  connected_order_arc_1332  -1
    order_2_11  connected_order_arc_1334  -1
    order_2_11  connected_order_arc_1336  -1
    order_2_11  connected_order_arc_1338  -1
    order_2_11  connected_order_arc_1340  -1
    order_2_11  connected_order_arc_1342  -1
    order_2_11  connected_order_arc_1344  -1
    order_2_11  connected_order_arc_1346  -1
    order_2_11  connected_order_arc_1348  -1
    order_2_11  connected_order_arc_1351  1
    order_2_11  connected_order_arc_1372  1
    order_2_11  connected_order_arc_1393  1
    order_2_11  connected_order_arc_1414  1
    order_2_11  connected_order_arc_1435  1
    order_2_11  connected_order_arc_1456  1
    order_2_11  connected_order_arc_1477  1
    order_2_11  connected_order_arc_1498  1
    order_2_11  connected_order_arc_1519  1
    order_2_11  connected_order_arc_1540  1
    order_2_11  order_active_lb_1563  1
    order_2_11  order_active_ub_1564  1
    order_2_11  fixed_segment_relative_order_1630  -1
    visit_2_12  out_degree_1568  -1
    visit_2_12  in_degree_1569  -1
    visit_2_12  order_active_lb_1570  -1
    visit_2_12  order_active_ub_1571  -11
    order_2_12  connected_order_arc_1330  1
    order_2_12  connected_order_arc_1351  -1
    order_2_12  connected_order_arc_1353  -1
    order_2_12  connected_order_arc_1355  -1
    order_2_12  connected_order_arc_1357  -1
    order_2_12  connected_order_arc_1359  -1
    order_2_12  connected_order_arc_1361  -1
    order_2_12  connected_order_arc_1363  -1
    order_2_12  connected_order_arc_1365  -1
    order_2_12  connected_order_arc_1367  -1
    order_2_12  connected_order_arc_1369  -1
    order_2_12  connected_order_arc_1374  1
    order_2_12  connected_order_arc_1395  1
    order_2_12  connected_order_arc_1416  1
    order_2_12  connected_order_arc_1437  1
    order_2_12  connected_order_arc_1458  1
    order_2_12  connected_order_arc_1479  1
    order_2_12  connected_order_arc_1500  1
    order_2_12  connected_order_arc_1521  1
    order_2_12  connected_order_arc_1542  1
    order_2_12  order_active_lb_1570  1
    order_2_12  order_active_ub_1571  1
    order_2_12  fixed_segment_relative_order_1630  1
    order_2_12  fixed_segment_relative_order_1631  -1
    visit_2_13  out_degree_1575  -1
    visit_2_13  in_degree_1576  -1
    visit_2_13  order_active_lb_1577  -1
    visit_2_13  order_active_ub_1578  -11
    order_2_13  connected_order_arc_1332  1
    order_2_13  connected_order_arc_1353  1
    order_2_13  connected_order_arc_1372  -1
    order_2_13  connected_order_arc_1374  -1
    order_2_13  connected_order_arc_1376  -1
    order_2_13  connected_order_arc_1378  -1
    order_2_13  connected_order_arc_1380  -1
    order_2_13  connected_order_arc_1382  -1
    order_2_13  connected_order_arc_1384  -1
    order_2_13  connected_order_arc_1386  -1
    order_2_13  connected_order_arc_1388  -1
    order_2_13  connected_order_arc_1390  -1
    order_2_13  connected_order_arc_1397  1
    order_2_13  connected_order_arc_1418  1
    order_2_13  connected_order_arc_1439  1
    order_2_13  connected_order_arc_1460  1
    order_2_13  connected_order_arc_1481  1
    order_2_13  connected_order_arc_1502  1
    order_2_13  connected_order_arc_1523  1
    order_2_13  connected_order_arc_1544  1
    order_2_13  order_active_lb_1577  1
    order_2_13  order_active_ub_1578  1
    order_2_13  fixed_segment_relative_order_1631  1
    visit_2_14  out_degree_1582  -1
    visit_2_14  in_degree_1583  -1
    visit_2_14  order_active_lb_1584  -1
    visit_2_14  order_active_ub_1585  -11
    visit_2_14  service_visit_def_1586  -1
    order_2_14  connected_order_arc_1334  1
    order_2_14  connected_order_arc_1355  1
    order_2_14  connected_order_arc_1376  1
    order_2_14  connected_order_arc_1393  -1
    order_2_14  connected_order_arc_1395  -1
    order_2_14  connected_order_arc_1397  -1
    order_2_14  connected_order_arc_1399  -1
    order_2_14  connected_order_arc_1401  -1
    order_2_14  connected_order_arc_1403  -1
    order_2_14  connected_order_arc_1405  -1
    order_2_14  connected_order_arc_1407  -1
    order_2_14  connected_order_arc_1409  -1
    order_2_14  connected_order_arc_1411  -1
    order_2_14  connected_order_arc_1420  1
    order_2_14  connected_order_arc_1441  1
    order_2_14  connected_order_arc_1462  1
    order_2_14  connected_order_arc_1483  1
    order_2_14  connected_order_arc_1504  1
    order_2_14  connected_order_arc_1525  1
    order_2_14  connected_order_arc_1546  1
    order_2_14  order_active_lb_1584  1
    order_2_14  order_active_ub_1585  1
    visit_2_15  out_degree_1588  -1
    visit_2_15  in_degree_1589  -1
    visit_2_15  order_active_lb_1590  -1
    visit_2_15  order_active_ub_1591  -11
    visit_2_15  service_visit_def_1592  -1
    order_2_15  connected_order_arc_1336  1
    order_2_15  connected_order_arc_1357  1
    order_2_15  connected_order_arc_1378  1
    order_2_15  connected_order_arc_1399  1
    order_2_15  connected_order_arc_1414  -1
    order_2_15  connected_order_arc_1416  -1
    order_2_15  connected_order_arc_1418  -1
    order_2_15  connected_order_arc_1420  -1
    order_2_15  connected_order_arc_1422  -1
    order_2_15  connected_order_arc_1424  -1
    order_2_15  connected_order_arc_1426  -1
    order_2_15  connected_order_arc_1428  -1
    order_2_15  connected_order_arc_1430  -1
    order_2_15  connected_order_arc_1432  -1
    order_2_15  connected_order_arc_1443  1
    order_2_15  connected_order_arc_1464  1
    order_2_15  connected_order_arc_1485  1
    order_2_15  connected_order_arc_1506  1
    order_2_15  connected_order_arc_1527  1
    order_2_15  connected_order_arc_1548  1
    order_2_15  order_active_lb_1590  1
    order_2_15  order_active_ub_1591  1
    visit_2_16  out_degree_1594  -1
    visit_2_16  in_degree_1595  -1
    visit_2_16  order_active_lb_1596  -1
    visit_2_16  order_active_ub_1597  -11
    visit_2_16  service_visit_def_1598  -1
    order_2_16  connected_order_arc_1338  1
    order_2_16  connected_order_arc_1359  1
    order_2_16  connected_order_arc_1380  1
    order_2_16  connected_order_arc_1401  1
    order_2_16  connected_order_arc_1422  1
    order_2_16  connected_order_arc_1435  -1
    order_2_16  connected_order_arc_1437  -1
    order_2_16  connected_order_arc_1439  -1
    order_2_16  connected_order_arc_1441  -1
    order_2_16  connected_order_arc_1443  -1
    order_2_16  connected_order_arc_1445  -1
    order_2_16  connected_order_arc_1447  -1
    order_2_16  connected_order_arc_1449  -1
    order_2_16  connected_order_arc_1451  -1
    order_2_16  connected_order_arc_1453  -1
    order_2_16  connected_order_arc_1466  1
    order_2_16  connected_order_arc_1487  1
    order_2_16  connected_order_arc_1508  1
    order_2_16  connected_order_arc_1529  1
    order_2_16  connected_order_arc_1550  1
    order_2_16  order_active_lb_1596  1
    order_2_16  order_active_ub_1597  1
    visit_2_17  out_degree_1600  -1
    visit_2_17  in_degree_1601  -1
    visit_2_17  order_active_lb_1602  -1
    visit_2_17  order_active_ub_1603  -11
    visit_2_17  service_visit_def_1604  -1
    order_2_17  connected_order_arc_1340  1
    order_2_17  connected_order_arc_1361  1
    order_2_17  connected_order_arc_1382  1
    order_2_17  connected_order_arc_1403  1
    order_2_17  connected_order_arc_1424  1
    order_2_17  connected_order_arc_1445  1
    order_2_17  connected_order_arc_1456  -1
    order_2_17  connected_order_arc_1458  -1
    order_2_17  connected_order_arc_1460  -1
    order_2_17  connected_order_arc_1462  -1
    order_2_17  connected_order_arc_1464  -1
    order_2_17  connected_order_arc_1466  -1
    order_2_17  connected_order_arc_1468  -1
    order_2_17  connected_order_arc_1470  -1
    order_2_17  connected_order_arc_1472  -1
    order_2_17  connected_order_arc_1474  -1
    order_2_17  connected_order_arc_1489  1
    order_2_17  connected_order_arc_1510  1
    order_2_17  connected_order_arc_1531  1
    order_2_17  connected_order_arc_1552  1
    order_2_17  order_active_lb_1602  1
    order_2_17  order_active_ub_1603  1
    visit_2_18  out_degree_1606  -1
    visit_2_18  in_degree_1607  -1
    visit_2_18  order_active_lb_1608  -1
    visit_2_18  order_active_ub_1609  -11
    visit_2_18  service_visit_def_1610  -1
    order_2_18  connected_order_arc_1342  1
    order_2_18  connected_order_arc_1363  1
    order_2_18  connected_order_arc_1384  1
    order_2_18  connected_order_arc_1405  1
    order_2_18  connected_order_arc_1426  1
    order_2_18  connected_order_arc_1447  1
    order_2_18  connected_order_arc_1468  1
    order_2_18  connected_order_arc_1477  -1
    order_2_18  connected_order_arc_1479  -1
    order_2_18  connected_order_arc_1481  -1
    order_2_18  connected_order_arc_1483  -1
    order_2_18  connected_order_arc_1485  -1
    order_2_18  connected_order_arc_1487  -1
    order_2_18  connected_order_arc_1489  -1
    order_2_18  connected_order_arc_1491  -1
    order_2_18  connected_order_arc_1493  -1
    order_2_18  connected_order_arc_1495  -1
    order_2_18  connected_order_arc_1512  1
    order_2_18  connected_order_arc_1533  1
    order_2_18  connected_order_arc_1554  1
    order_2_18  order_active_lb_1608  1
    order_2_18  order_active_ub_1609  1
    visit_2_19  out_degree_1612  -1
    visit_2_19  in_degree_1613  -1
    visit_2_19  order_active_lb_1614  -1
    visit_2_19  order_active_ub_1615  -11
    visit_2_19  service_visit_def_1616  -1
    order_2_19  connected_order_arc_1344  1
    order_2_19  connected_order_arc_1365  1
    order_2_19  connected_order_arc_1386  1
    order_2_19  connected_order_arc_1407  1
    order_2_19  connected_order_arc_1428  1
    order_2_19  connected_order_arc_1449  1
    order_2_19  connected_order_arc_1470  1
    order_2_19  connected_order_arc_1491  1
    order_2_19  connected_order_arc_1498  -1
    order_2_19  connected_order_arc_1500  -1
    order_2_19  connected_order_arc_1502  -1
    order_2_19  connected_order_arc_1504  -1
    order_2_19  connected_order_arc_1506  -1
    order_2_19  connected_order_arc_1508  -1
    order_2_19  connected_order_arc_1510  -1
    order_2_19  connected_order_arc_1512  -1
    order_2_19  connected_order_arc_1514  -1
    order_2_19  connected_order_arc_1516  -1
    order_2_19  connected_order_arc_1535  1
    order_2_19  connected_order_arc_1556  1
    order_2_19  order_active_lb_1614  1
    order_2_19  order_active_ub_1615  1
    visit_2_20  out_degree_1618  -1
    visit_2_20  in_degree_1619  -1
    visit_2_20  order_active_lb_1620  -1
    visit_2_20  order_active_ub_1621  -11
    visit_2_20  service_visit_def_1622  -1
    order_2_20  connected_order_arc_1346  1
    order_2_20  connected_order_arc_1367  1
    order_2_20  connected_order_arc_1388  1
    order_2_20  connected_order_arc_1409  1
    order_2_20  connected_order_arc_1430  1
    order_2_20  connected_order_arc_1451  1
    order_2_20  connected_order_arc_1472  1
    order_2_20  connected_order_arc_1493  1
    order_2_20  connected_order_arc_1514  1
    order_2_20  connected_order_arc_1519  -1
    order_2_20  connected_order_arc_1521  -1
    order_2_20  connected_order_arc_1523  -1
    order_2_20  connected_order_arc_1525  -1
    order_2_20  connected_order_arc_1527  -1
    order_2_20  connected_order_arc_1529  -1
    order_2_20  connected_order_arc_1531  -1
    order_2_20  connected_order_arc_1533  -1
    order_2_20  connected_order_arc_1535  -1
    order_2_20  connected_order_arc_1537  -1
    order_2_20  connected_order_arc_1558  1
    order_2_20  order_active_lb_1620  1
    order_2_20  order_active_ub_1621  1
    visit_2_21  out_degree_1624  -1
    visit_2_21  in_degree_1625  -1
    visit_2_21  order_active_lb_1626  -1
    visit_2_21  order_active_ub_1627  -11
    visit_2_21  service_visit_def_1628  -1
    order_2_21  connected_order_arc_1348  1
    order_2_21  connected_order_arc_1369  1
    order_2_21  connected_order_arc_1390  1
    order_2_21  connected_order_arc_1411  1
    order_2_21  connected_order_arc_1432  1
    order_2_21  connected_order_arc_1453  1
    order_2_21  connected_order_arc_1474  1
    order_2_21  connected_order_arc_1495  1
    order_2_21  connected_order_arc_1516  1
    order_2_21  connected_order_arc_1537  1
    order_2_21  connected_order_arc_1540  -1
    order_2_21  connected_order_arc_1542  -1
    order_2_21  connected_order_arc_1544  -1
    order_2_21  connected_order_arc_1546  -1
    order_2_21  connected_order_arc_1548  -1
    order_2_21  connected_order_arc_1550  -1
    order_2_21  connected_order_arc_1552  -1
    order_2_21  connected_order_arc_1554  -1
    order_2_21  connected_order_arc_1556  -1
    order_2_21  connected_order_arc_1558  -1
    order_2_21  order_active_lb_1626  1
    order_2_21  order_active_ub_1627  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1316  -30
    arc_2_0_0  depot_departure_or_bypass_1559  1
    arc_2_0_0  depot_return_or_bypass_1560  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1316  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1317  -30
    arc_2_0_11  depot_departure_or_bypass_1559  1
    arc_2_0_11  in_degree_1562  1
    arc_2_0_11  original_T_including_depot_unload_1632  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1317  1
    load_2_0_11  segment_load_conservation_1565  -1
    load_2_0_11  segment_prefix_lb_1566  1
    load_2_0_11  segment_prefix_ub_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1318  -30
    arc_2_0_12  depot_departure_or_bypass_1559  1
    arc_2_0_12  in_degree_1569  1
    arc_2_0_12  original_T_including_depot_unload_1632  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1318  1
    load_2_0_12  segment_load_conservation_1572  -1
    load_2_0_12  segment_prefix_lb_1573  1
    load_2_0_12  segment_prefix_ub_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1319  -30
    arc_2_0_13  depot_departure_or_bypass_1559  1
    arc_2_0_13  in_degree_1576  1
    arc_2_0_13  original_T_including_depot_unload_1632  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1319  1
    load_2_0_13  segment_load_conservation_1579  -1
    load_2_0_13  segment_prefix_lb_1580  1
    load_2_0_13  segment_prefix_ub_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1320  -30
    arc_2_0_14  depot_departure_or_bypass_1559  1
    arc_2_0_14  in_degree_1583  1
    arc_2_0_14  original_T_including_depot_unload_1632  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1320  1
    load_2_0_14  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1321  -30
    arc_2_0_15  depot_departure_or_bypass_1559  1
    arc_2_0_15  in_degree_1589  1
    arc_2_0_15  original_T_including_depot_unload_1632  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1321  1
    load_2_0_15  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1322  -30
    arc_2_0_16  depot_departure_or_bypass_1559  1
    arc_2_0_16  in_degree_1595  1
    arc_2_0_16  original_T_including_depot_unload_1632  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1322  1
    load_2_0_16  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1323  -30
    arc_2_0_17  depot_departure_or_bypass_1559  1
    arc_2_0_17  in_degree_1601  1
    arc_2_0_17  original_T_including_depot_unload_1632  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1323  1
    load_2_0_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1324  -30
    arc_2_0_18  depot_departure_or_bypass_1559  1
    arc_2_0_18  in_degree_1607  1
    arc_2_0_18  original_T_including_depot_unload_1632  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1324  1
    load_2_0_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1325  -30
    arc_2_0_19  depot_departure_or_bypass_1559  1
    arc_2_0_19  in_degree_1613  1
    arc_2_0_19  original_T_including_depot_unload_1632  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1325  1
    load_2_0_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1326  -30
    arc_2_0_20  depot_departure_or_bypass_1559  1
    arc_2_0_20  in_degree_1619  1
    arc_2_0_20  original_T_including_depot_unload_1632  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1326  1
    load_2_0_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1327  -30
    arc_2_0_21  depot_departure_or_bypass_1559  1
    arc_2_0_21  in_degree_1625  1
    arc_2_0_21  original_T_including_depot_unload_1632  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1327  1
    load_2_0_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1328  -30
    arc_2_11_0  depot_return_or_bypass_1560  1
    arc_2_11_0  out_degree_1561  1
    arc_2_11_0  original_T_including_depot_unload_1632  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1328  1
    load_2_11_0  segment_load_conservation_1565  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1329  -30
    arc_2_11_12  connected_order_arc_1330  -12
    arc_2_11_12  out_degree_1561  1
    arc_2_11_12  in_degree_1569  1
    arc_2_11_12  original_T_including_depot_unload_1632  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1329  1
    load_2_11_12  segment_load_conservation_1565  1
    load_2_11_12  segment_load_conservation_1572  -1
    load_2_11_12  segment_prefix_lb_1573  1
    load_2_11_12  segment_prefix_ub_1574  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1331  -30
    arc_2_11_13  connected_order_arc_1332  -12
    arc_2_11_13  out_degree_1561  1
    arc_2_11_13  in_degree_1576  1
    arc_2_11_13  original_T_including_depot_unload_1632  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1331  1
    load_2_11_13  segment_load_conservation_1565  1
    load_2_11_13  segment_load_conservation_1579  -1
    load_2_11_13  segment_prefix_lb_1580  1
    load_2_11_13  segment_prefix_ub_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1333  -30
    arc_2_11_14  connected_order_arc_1334  -12
    arc_2_11_14  out_degree_1561  1
    arc_2_11_14  in_degree_1583  1
    arc_2_11_14  original_T_including_depot_unload_1632  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1333  1
    load_2_11_14  segment_load_conservation_1565  1
    load_2_11_14  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1335  -30
    arc_2_11_15  connected_order_arc_1336  -12
    arc_2_11_15  out_degree_1561  1
    arc_2_11_15  in_degree_1589  1
    arc_2_11_15  original_T_including_depot_unload_1632  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1335  1
    load_2_11_15  segment_load_conservation_1565  1
    load_2_11_15  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1337  -30
    arc_2_11_16  connected_order_arc_1338  -12
    arc_2_11_16  out_degree_1561  1
    arc_2_11_16  in_degree_1595  1
    arc_2_11_16  original_T_including_depot_unload_1632  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1337  1
    load_2_11_16  segment_load_conservation_1565  1
    load_2_11_16  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1339  -30
    arc_2_11_17  connected_order_arc_1340  -12
    arc_2_11_17  out_degree_1561  1
    arc_2_11_17  in_degree_1601  1
    arc_2_11_17  original_T_including_depot_unload_1632  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1339  1
    load_2_11_17  segment_load_conservation_1565  1
    load_2_11_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1341  -30
    arc_2_11_18  connected_order_arc_1342  -12
    arc_2_11_18  out_degree_1561  1
    arc_2_11_18  in_degree_1607  1
    arc_2_11_18  original_T_including_depot_unload_1632  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1341  1
    load_2_11_18  segment_load_conservation_1565  1
    load_2_11_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1343  -30
    arc_2_11_19  connected_order_arc_1344  -12
    arc_2_11_19  out_degree_1561  1
    arc_2_11_19  in_degree_1613  1
    arc_2_11_19  original_T_including_depot_unload_1632  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1343  1
    load_2_11_19  segment_load_conservation_1565  1
    load_2_11_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1345  -30
    arc_2_11_20  connected_order_arc_1346  -12
    arc_2_11_20  out_degree_1561  1
    arc_2_11_20  in_degree_1619  1
    arc_2_11_20  original_T_including_depot_unload_1632  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1345  1
    load_2_11_20  segment_load_conservation_1565  1
    load_2_11_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1347  -30
    arc_2_11_21  connected_order_arc_1348  -12
    arc_2_11_21  out_degree_1561  1
    arc_2_11_21  in_degree_1625  1
    arc_2_11_21  original_T_including_depot_unload_1632  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1347  1
    load_2_11_21  segment_load_conservation_1565  1
    load_2_11_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1349  -30
    arc_2_12_0  depot_return_or_bypass_1560  1
    arc_2_12_0  out_degree_1568  1
    arc_2_12_0  original_T_including_depot_unload_1632  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1349  1
    load_2_12_0  segment_load_conservation_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1350  -30
    arc_2_12_11  connected_order_arc_1351  -12
    arc_2_12_11  in_degree_1562  1
    arc_2_12_11  out_degree_1568  1
    arc_2_12_11  original_T_including_depot_unload_1632  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1350  1
    load_2_12_11  segment_load_conservation_1565  -1
    load_2_12_11  segment_prefix_lb_1566  1
    load_2_12_11  segment_prefix_ub_1567  1
    load_2_12_11  segment_load_conservation_1572  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1352  -30
    arc_2_12_13  connected_order_arc_1353  -12
    arc_2_12_13  out_degree_1568  1
    arc_2_12_13  in_degree_1576  1
    arc_2_12_13  original_T_including_depot_unload_1632  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1352  1
    load_2_12_13  segment_load_conservation_1572  1
    load_2_12_13  segment_load_conservation_1579  -1
    load_2_12_13  segment_prefix_lb_1580  1
    load_2_12_13  segment_prefix_ub_1581  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1354  -30
    arc_2_12_14  connected_order_arc_1355  -12
    arc_2_12_14  out_degree_1568  1
    arc_2_12_14  in_degree_1583  1
    arc_2_12_14  original_T_including_depot_unload_1632  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1354  1
    load_2_12_14  segment_load_conservation_1572  1
    load_2_12_14  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1356  -30
    arc_2_12_15  connected_order_arc_1357  -12
    arc_2_12_15  out_degree_1568  1
    arc_2_12_15  in_degree_1589  1
    arc_2_12_15  original_T_including_depot_unload_1632  1.6583475127728254e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1356  1
    load_2_12_15  segment_load_conservation_1572  1
    load_2_12_15  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1358  -30
    arc_2_12_16  connected_order_arc_1359  -12
    arc_2_12_16  out_degree_1568  1
    arc_2_12_16  in_degree_1595  1
    arc_2_12_16  original_T_including_depot_unload_1632  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1358  1
    load_2_12_16  segment_load_conservation_1572  1
    load_2_12_16  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1360  -30
    arc_2_12_17  connected_order_arc_1361  -12
    arc_2_12_17  out_degree_1568  1
    arc_2_12_17  in_degree_1601  1
    arc_2_12_17  original_T_including_depot_unload_1632  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1360  1
    load_2_12_17  segment_load_conservation_1572  1
    load_2_12_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1362  -30
    arc_2_12_18  connected_order_arc_1363  -12
    arc_2_12_18  out_degree_1568  1
    arc_2_12_18  in_degree_1607  1
    arc_2_12_18  original_T_including_depot_unload_1632  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1362  1
    load_2_12_18  segment_load_conservation_1572  1
    load_2_12_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1364  -30
    arc_2_12_19  connected_order_arc_1365  -12
    arc_2_12_19  out_degree_1568  1
    arc_2_12_19  in_degree_1613  1
    arc_2_12_19  original_T_including_depot_unload_1632  1.5552905028977075e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1364  1
    load_2_12_19  segment_load_conservation_1572  1
    load_2_12_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1366  -30
    arc_2_12_20  connected_order_arc_1367  -12
    arc_2_12_20  out_degree_1568  1
    arc_2_12_20  in_degree_1619  1
    arc_2_12_20  original_T_including_depot_unload_1632  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1366  1
    load_2_12_20  segment_load_conservation_1572  1
    load_2_12_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1368  -30
    arc_2_12_21  connected_order_arc_1369  -12
    arc_2_12_21  out_degree_1568  1
    arc_2_12_21  in_degree_1625  1
    arc_2_12_21  original_T_including_depot_unload_1632  1.7151417164052370e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1368  1
    load_2_12_21  segment_load_conservation_1572  1
    load_2_12_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1370  -30
    arc_2_13_0  depot_return_or_bypass_1560  1
    arc_2_13_0  out_degree_1575  1
    arc_2_13_0  original_T_including_depot_unload_1632  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1370  1
    load_2_13_0  segment_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1371  -30
    arc_2_13_11  connected_order_arc_1372  -12
    arc_2_13_11  in_degree_1562  1
    arc_2_13_11  out_degree_1575  1
    arc_2_13_11  original_T_including_depot_unload_1632  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1371  1
    load_2_13_11  segment_load_conservation_1565  -1
    load_2_13_11  segment_prefix_lb_1566  1
    load_2_13_11  segment_prefix_ub_1567  1
    load_2_13_11  segment_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1373  -30
    arc_2_13_12  connected_order_arc_1374  -12
    arc_2_13_12  in_degree_1569  1
    arc_2_13_12  out_degree_1575  1
    arc_2_13_12  original_T_including_depot_unload_1632  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1373  1
    load_2_13_12  segment_load_conservation_1572  -1
    load_2_13_12  segment_prefix_lb_1573  1
    load_2_13_12  segment_prefix_ub_1574  1
    load_2_13_12  segment_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1375  -30
    arc_2_13_14  connected_order_arc_1376  -12
    arc_2_13_14  out_degree_1575  1
    arc_2_13_14  in_degree_1583  1
    arc_2_13_14  original_T_including_depot_unload_1632  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1375  1
    load_2_13_14  segment_load_conservation_1579  1
    load_2_13_14  free_load_conservation_1587  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1377  -30
    arc_2_13_15  connected_order_arc_1378  -12
    arc_2_13_15  out_degree_1575  1
    arc_2_13_15  in_degree_1589  1
    arc_2_13_15  original_T_including_depot_unload_1632  904.837890445026
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1377  1
    load_2_13_15  segment_load_conservation_1579  1
    load_2_13_15  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1379  -30
    arc_2_13_16  connected_order_arc_1380  -12
    arc_2_13_16  out_degree_1575  1
    arc_2_13_16  in_degree_1595  1
    arc_2_13_16  original_T_including_depot_unload_1632  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1379  1
    load_2_13_16  segment_load_conservation_1579  1
    load_2_13_16  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1381  -30
    arc_2_13_17  connected_order_arc_1382  -12
    arc_2_13_17  out_degree_1575  1
    arc_2_13_17  in_degree_1601  1
    arc_2_13_17  original_T_including_depot_unload_1632  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1381  1
    load_2_13_17  segment_load_conservation_1579  1
    load_2_13_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1383  -30
    arc_2_13_18  connected_order_arc_1384  -12
    arc_2_13_18  out_degree_1575  1
    arc_2_13_18  in_degree_1607  1
    arc_2_13_18  original_T_including_depot_unload_1632  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1383  1
    load_2_13_18  segment_load_conservation_1579  1
    load_2_13_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1385  -30
    arc_2_13_19  connected_order_arc_1386  -12
    arc_2_13_19  out_degree_1575  1
    arc_2_13_19  in_degree_1613  1
    arc_2_13_19  original_T_including_depot_unload_1632  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1385  1
    load_2_13_19  segment_load_conservation_1579  1
    load_2_13_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1387  -30
    arc_2_13_20  connected_order_arc_1388  -12
    arc_2_13_20  out_degree_1575  1
    arc_2_13_20  in_degree_1619  1
    arc_2_13_20  original_T_including_depot_unload_1632  1.2674827380665711e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1387  1
    load_2_13_20  segment_load_conservation_1579  1
    load_2_13_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1389  -30
    arc_2_13_21  connected_order_arc_1390  -12
    arc_2_13_21  out_degree_1575  1
    arc_2_13_21  in_degree_1625  1
    arc_2_13_21  original_T_including_depot_unload_1632  1.1034987922840380e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1389  1
    load_2_13_21  segment_load_conservation_1579  1
    load_2_13_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1391  -30
    arc_2_14_0  depot_return_or_bypass_1560  1
    arc_2_14_0  out_degree_1582  1
    arc_2_14_0  original_T_including_depot_unload_1632  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1391  1
    load_2_14_0  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1392  -30
    arc_2_14_11  connected_order_arc_1393  -12
    arc_2_14_11  in_degree_1562  1
    arc_2_14_11  out_degree_1582  1
    arc_2_14_11  original_T_including_depot_unload_1632  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1392  1
    load_2_14_11  segment_load_conservation_1565  -1
    load_2_14_11  segment_prefix_lb_1566  1
    load_2_14_11  segment_prefix_ub_1567  1
    load_2_14_11  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1394  -30
    arc_2_14_12  connected_order_arc_1395  -12
    arc_2_14_12  in_degree_1569  1
    arc_2_14_12  out_degree_1582  1
    arc_2_14_12  original_T_including_depot_unload_1632  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1394  1
    load_2_14_12  segment_load_conservation_1572  -1
    load_2_14_12  segment_prefix_lb_1573  1
    load_2_14_12  segment_prefix_ub_1574  1
    load_2_14_12  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1396  -30
    arc_2_14_13  connected_order_arc_1397  -12
    arc_2_14_13  in_degree_1576  1
    arc_2_14_13  out_degree_1582  1
    arc_2_14_13  original_T_including_depot_unload_1632  1.3132316623300278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1396  1
    load_2_14_13  segment_load_conservation_1579  -1
    load_2_14_13  segment_prefix_lb_1580  1
    load_2_14_13  segment_prefix_ub_1581  1
    load_2_14_13  free_load_conservation_1587  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1398  -30
    arc_2_14_15  connected_order_arc_1399  -12
    arc_2_14_15  out_degree_1582  1
    arc_2_14_15  in_degree_1589  1
    arc_2_14_15  original_T_including_depot_unload_1632  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1398  1
    load_2_14_15  free_load_conservation_1587  1
    load_2_14_15  free_load_conservation_1593  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1400  -30
    arc_2_14_16  connected_order_arc_1401  -12
    arc_2_14_16  out_degree_1582  1
    arc_2_14_16  in_degree_1595  1
    arc_2_14_16  original_T_including_depot_unload_1632  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1400  1
    load_2_14_16  free_load_conservation_1587  1
    load_2_14_16  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1402  -30
    arc_2_14_17  connected_order_arc_1403  -12
    arc_2_14_17  out_degree_1582  1
    arc_2_14_17  in_degree_1601  1
    arc_2_14_17  original_T_including_depot_unload_1632  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1402  1
    load_2_14_17  free_load_conservation_1587  1
    load_2_14_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1404  -30
    arc_2_14_18  connected_order_arc_1405  -12
    arc_2_14_18  out_degree_1582  1
    arc_2_14_18  in_degree_1607  1
    arc_2_14_18  original_T_including_depot_unload_1632  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1404  1
    load_2_14_18  free_load_conservation_1587  1
    load_2_14_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1406  -30
    arc_2_14_19  connected_order_arc_1407  -12
    arc_2_14_19  out_degree_1582  1
    arc_2_14_19  in_degree_1613  1
    arc_2_14_19  original_T_including_depot_unload_1632  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1406  1
    load_2_14_19  free_load_conservation_1587  1
    load_2_14_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1408  -30
    arc_2_14_20  connected_order_arc_1409  -12
    arc_2_14_20  out_degree_1582  1
    arc_2_14_20  in_degree_1619  1
    arc_2_14_20  original_T_including_depot_unload_1632  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1408  1
    load_2_14_20  free_load_conservation_1587  1
    load_2_14_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1410  -30
    arc_2_14_21  connected_order_arc_1411  -12
    arc_2_14_21  out_degree_1582  1
    arc_2_14_21  in_degree_1625  1
    arc_2_14_21  original_T_including_depot_unload_1632  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1410  1
    load_2_14_21  free_load_conservation_1587  1
    load_2_14_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1412  -30
    arc_2_15_0  depot_return_or_bypass_1560  1
    arc_2_15_0  out_degree_1588  1
    arc_2_15_0  original_T_including_depot_unload_1632  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1412  1
    load_2_15_0  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1413  -30
    arc_2_15_11  connected_order_arc_1414  -12
    arc_2_15_11  in_degree_1562  1
    arc_2_15_11  out_degree_1588  1
    arc_2_15_11  original_T_including_depot_unload_1632  6.5332321619697848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1413  1
    load_2_15_11  segment_load_conservation_1565  -1
    load_2_15_11  segment_prefix_lb_1566  1
    load_2_15_11  segment_prefix_ub_1567  1
    load_2_15_11  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1415  -30
    arc_2_15_12  connected_order_arc_1416  -12
    arc_2_15_12  in_degree_1569  1
    arc_2_15_12  out_degree_1588  1
    arc_2_15_12  original_T_including_depot_unload_1632  1.9292357601859349e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1415  1
    load_2_15_12  segment_load_conservation_1572  -1
    load_2_15_12  segment_prefix_lb_1573  1
    load_2_15_12  segment_prefix_ub_1574  1
    load_2_15_12  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1417  -30
    arc_2_15_13  connected_order_arc_1418  -12
    arc_2_15_13  in_degree_1576  1
    arc_2_15_13  out_degree_1588  1
    arc_2_15_13  original_T_including_depot_unload_1632  1.3174943724568802e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1417  1
    load_2_15_13  segment_load_conservation_1579  -1
    load_2_15_13  segment_prefix_lb_1580  1
    load_2_15_13  segment_prefix_ub_1581  1
    load_2_15_13  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1419  -30
    arc_2_15_14  connected_order_arc_1420  -12
    arc_2_15_14  in_degree_1583  1
    arc_2_15_14  out_degree_1588  1
    arc_2_15_14  original_T_including_depot_unload_1632  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1419  1
    load_2_15_14  free_load_conservation_1587  -1
    load_2_15_14  free_load_conservation_1593  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1421  -30
    arc_2_15_16  connected_order_arc_1422  -12
    arc_2_15_16  out_degree_1588  1
    arc_2_15_16  in_degree_1595  1
    arc_2_15_16  original_T_including_depot_unload_1632  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1421  1
    load_2_15_16  free_load_conservation_1593  1
    load_2_15_16  free_load_conservation_1599  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1423  -30
    arc_2_15_17  connected_order_arc_1424  -12
    arc_2_15_17  out_degree_1588  1
    arc_2_15_17  in_degree_1601  1
    arc_2_15_17  original_T_including_depot_unload_1632  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1423  1
    load_2_15_17  free_load_conservation_1593  1
    load_2_15_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1425  -30
    arc_2_15_18  connected_order_arc_1426  -12
    arc_2_15_18  out_degree_1588  1
    arc_2_15_18  in_degree_1607  1
    arc_2_15_18  original_T_including_depot_unload_1632  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1425  1
    load_2_15_18  free_load_conservation_1593  1
    load_2_15_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1427  -30
    arc_2_15_19  connected_order_arc_1428  -12
    arc_2_15_19  out_degree_1588  1
    arc_2_15_19  in_degree_1613  1
    arc_2_15_19  original_T_including_depot_unload_1632  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1427  1
    load_2_15_19  free_load_conservation_1593  1
    load_2_15_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1429  -30
    arc_2_15_20  connected_order_arc_1430  -12
    arc_2_15_20  out_degree_1588  1
    arc_2_15_20  in_degree_1619  1
    arc_2_15_20  original_T_including_depot_unload_1632  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1429  1
    load_2_15_20  free_load_conservation_1593  1
    load_2_15_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1431  -30
    arc_2_15_21  connected_order_arc_1432  -12
    arc_2_15_21  out_degree_1588  1
    arc_2_15_21  in_degree_1625  1
    arc_2_15_21  original_T_including_depot_unload_1632  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1431  1
    load_2_15_21  free_load_conservation_1593  1
    load_2_15_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1433  -30
    arc_2_16_0  depot_return_or_bypass_1560  1
    arc_2_16_0  out_degree_1594  1
    arc_2_16_0  original_T_including_depot_unload_1632  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1433  1
    load_2_16_0  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1434  -30
    arc_2_16_11  connected_order_arc_1435  -12
    arc_2_16_11  in_degree_1562  1
    arc_2_16_11  out_degree_1594  1
    arc_2_16_11  original_T_including_depot_unload_1632  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1434  1
    load_2_16_11  segment_load_conservation_1565  -1
    load_2_16_11  segment_prefix_lb_1566  1
    load_2_16_11  segment_prefix_ub_1567  1
    load_2_16_11  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1436  -30
    arc_2_16_12  connected_order_arc_1437  -12
    arc_2_16_12  in_degree_1569  1
    arc_2_16_12  out_degree_1594  1
    arc_2_16_12  original_T_including_depot_unload_1632  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1436  1
    load_2_16_12  segment_load_conservation_1572  -1
    load_2_16_12  segment_prefix_lb_1573  1
    load_2_16_12  segment_prefix_ub_1574  1
    load_2_16_12  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1438  -30
    arc_2_16_13  connected_order_arc_1439  -12
    arc_2_16_13  in_degree_1576  1
    arc_2_16_13  out_degree_1594  1
    arc_2_16_13  original_T_including_depot_unload_1632  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1438  1
    load_2_16_13  segment_load_conservation_1579  -1
    load_2_16_13  segment_prefix_lb_1580  1
    load_2_16_13  segment_prefix_ub_1581  1
    load_2_16_13  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1440  -30
    arc_2_16_14  connected_order_arc_1441  -12
    arc_2_16_14  in_degree_1583  1
    arc_2_16_14  out_degree_1594  1
    arc_2_16_14  original_T_including_depot_unload_1632  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1440  1
    load_2_16_14  free_load_conservation_1587  -1
    load_2_16_14  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1442  -30
    arc_2_16_15  connected_order_arc_1443  -12
    arc_2_16_15  in_degree_1589  1
    arc_2_16_15  out_degree_1594  1
    arc_2_16_15  original_T_including_depot_unload_1632  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1442  1
    load_2_16_15  free_load_conservation_1593  -1
    load_2_16_15  free_load_conservation_1599  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1444  -30
    arc_2_16_17  connected_order_arc_1445  -12
    arc_2_16_17  out_degree_1594  1
    arc_2_16_17  in_degree_1601  1
    arc_2_16_17  original_T_including_depot_unload_1632  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1444  1
    load_2_16_17  free_load_conservation_1599  1
    load_2_16_17  free_load_conservation_1605  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1446  -30
    arc_2_16_18  connected_order_arc_1447  -12
    arc_2_16_18  out_degree_1594  1
    arc_2_16_18  in_degree_1607  1
    arc_2_16_18  original_T_including_depot_unload_1632  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1446  1
    load_2_16_18  free_load_conservation_1599  1
    load_2_16_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1448  -30
    arc_2_16_19  connected_order_arc_1449  -12
    arc_2_16_19  out_degree_1594  1
    arc_2_16_19  in_degree_1613  1
    arc_2_16_19  original_T_including_depot_unload_1632  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1448  1
    load_2_16_19  free_load_conservation_1599  1
    load_2_16_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1450  -30
    arc_2_16_20  connected_order_arc_1451  -12
    arc_2_16_20  out_degree_1594  1
    arc_2_16_20  in_degree_1619  1
    arc_2_16_20  original_T_including_depot_unload_1632  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1450  1
    load_2_16_20  free_load_conservation_1599  1
    load_2_16_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1452  -30
    arc_2_16_21  connected_order_arc_1453  -12
    arc_2_16_21  out_degree_1594  1
    arc_2_16_21  in_degree_1625  1
    arc_2_16_21  original_T_including_depot_unload_1632  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1452  1
    load_2_16_21  free_load_conservation_1599  1
    load_2_16_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1454  -30
    arc_2_17_0  depot_return_or_bypass_1560  1
    arc_2_17_0  out_degree_1600  1
    arc_2_17_0  original_T_including_depot_unload_1632  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1454  1
    load_2_17_0  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1455  -30
    arc_2_17_11  connected_order_arc_1456  -12
    arc_2_17_11  in_degree_1562  1
    arc_2_17_11  out_degree_1600  1
    arc_2_17_11  original_T_including_depot_unload_1632  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1455  1
    load_2_17_11  segment_load_conservation_1565  -1
    load_2_17_11  segment_prefix_lb_1566  1
    load_2_17_11  segment_prefix_ub_1567  1
    load_2_17_11  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1457  -30
    arc_2_17_12  connected_order_arc_1458  -12
    arc_2_17_12  in_degree_1569  1
    arc_2_17_12  out_degree_1600  1
    arc_2_17_12  original_T_including_depot_unload_1632  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1457  1
    load_2_17_12  segment_load_conservation_1572  -1
    load_2_17_12  segment_prefix_lb_1573  1
    load_2_17_12  segment_prefix_ub_1574  1
    load_2_17_12  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1459  -30
    arc_2_17_13  connected_order_arc_1460  -12
    arc_2_17_13  in_degree_1576  1
    arc_2_17_13  out_degree_1600  1
    arc_2_17_13  original_T_including_depot_unload_1632  1.0428409649002836e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1459  1
    load_2_17_13  segment_load_conservation_1579  -1
    load_2_17_13  segment_prefix_lb_1580  1
    load_2_17_13  segment_prefix_ub_1581  1
    load_2_17_13  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1461  -30
    arc_2_17_14  connected_order_arc_1462  -12
    arc_2_17_14  in_degree_1583  1
    arc_2_17_14  out_degree_1600  1
    arc_2_17_14  original_T_including_depot_unload_1632  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1461  1
    load_2_17_14  free_load_conservation_1587  -1
    load_2_17_14  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1463  -30
    arc_2_17_15  connected_order_arc_1464  -12
    arc_2_17_15  in_degree_1589  1
    arc_2_17_15  out_degree_1600  1
    arc_2_17_15  original_T_including_depot_unload_1632  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1463  1
    load_2_17_15  free_load_conservation_1593  -1
    load_2_17_15  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1465  -30
    arc_2_17_16  connected_order_arc_1466  -12
    arc_2_17_16  in_degree_1595  1
    arc_2_17_16  out_degree_1600  1
    arc_2_17_16  original_T_including_depot_unload_1632  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1465  1
    load_2_17_16  free_load_conservation_1599  -1
    load_2_17_16  free_load_conservation_1605  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1467  -30
    arc_2_17_18  connected_order_arc_1468  -12
    arc_2_17_18  out_degree_1600  1
    arc_2_17_18  in_degree_1607  1
    arc_2_17_18  original_T_including_depot_unload_1632  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1467  1
    load_2_17_18  free_load_conservation_1605  1
    load_2_17_18  free_load_conservation_1611  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1469  -30
    arc_2_17_19  connected_order_arc_1470  -12
    arc_2_17_19  out_degree_1600  1
    arc_2_17_19  in_degree_1613  1
    arc_2_17_19  original_T_including_depot_unload_1632  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1469  1
    load_2_17_19  free_load_conservation_1605  1
    load_2_17_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1471  -30
    arc_2_17_20  connected_order_arc_1472  -12
    arc_2_17_20  out_degree_1600  1
    arc_2_17_20  in_degree_1619  1
    arc_2_17_20  original_T_including_depot_unload_1632  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1471  1
    load_2_17_20  free_load_conservation_1605  1
    load_2_17_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1473  -30
    arc_2_17_21  connected_order_arc_1474  -12
    arc_2_17_21  out_degree_1600  1
    arc_2_17_21  in_degree_1625  1
    arc_2_17_21  original_T_including_depot_unload_1632  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1473  1
    load_2_17_21  free_load_conservation_1605  1
    load_2_17_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1475  -30
    arc_2_18_0  depot_return_or_bypass_1560  1
    arc_2_18_0  out_degree_1606  1
    arc_2_18_0  original_T_including_depot_unload_1632  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1475  1
    load_2_18_0  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1476  -30
    arc_2_18_11  connected_order_arc_1477  -12
    arc_2_18_11  in_degree_1562  1
    arc_2_18_11  out_degree_1606  1
    arc_2_18_11  original_T_including_depot_unload_1632  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1476  1
    load_2_18_11  segment_load_conservation_1565  -1
    load_2_18_11  segment_prefix_lb_1566  1
    load_2_18_11  segment_prefix_ub_1567  1
    load_2_18_11  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1478  -30
    arc_2_18_12  connected_order_arc_1479  -12
    arc_2_18_12  in_degree_1569  1
    arc_2_18_12  out_degree_1606  1
    arc_2_18_12  original_T_including_depot_unload_1632  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1478  1
    load_2_18_12  segment_load_conservation_1572  -1
    load_2_18_12  segment_prefix_lb_1573  1
    load_2_18_12  segment_prefix_ub_1574  1
    load_2_18_12  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1480  -30
    arc_2_18_13  connected_order_arc_1481  -12
    arc_2_18_13  in_degree_1576  1
    arc_2_18_13  out_degree_1606  1
    arc_2_18_13  original_T_including_depot_unload_1632  9.5901863634429412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1480  1
    load_2_18_13  segment_load_conservation_1579  -1
    load_2_18_13  segment_prefix_lb_1580  1
    load_2_18_13  segment_prefix_ub_1581  1
    load_2_18_13  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1482  -30
    arc_2_18_14  connected_order_arc_1483  -12
    arc_2_18_14  in_degree_1583  1
    arc_2_18_14  out_degree_1606  1
    arc_2_18_14  original_T_including_depot_unload_1632  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1482  1
    load_2_18_14  free_load_conservation_1587  -1
    load_2_18_14  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1484  -30
    arc_2_18_15  connected_order_arc_1485  -12
    arc_2_18_15  in_degree_1589  1
    arc_2_18_15  out_degree_1606  1
    arc_2_18_15  original_T_including_depot_unload_1632  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1484  1
    load_2_18_15  free_load_conservation_1593  -1
    load_2_18_15  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1486  -30
    arc_2_18_16  connected_order_arc_1487  -12
    arc_2_18_16  in_degree_1595  1
    arc_2_18_16  out_degree_1606  1
    arc_2_18_16  original_T_including_depot_unload_1632  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1486  1
    load_2_18_16  free_load_conservation_1599  -1
    load_2_18_16  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1488  -30
    arc_2_18_17  connected_order_arc_1489  -12
    arc_2_18_17  in_degree_1601  1
    arc_2_18_17  out_degree_1606  1
    arc_2_18_17  original_T_including_depot_unload_1632  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1488  1
    load_2_18_17  free_load_conservation_1605  -1
    load_2_18_17  free_load_conservation_1611  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1490  -30
    arc_2_18_19  connected_order_arc_1491  -12
    arc_2_18_19  out_degree_1606  1
    arc_2_18_19  in_degree_1613  1
    arc_2_18_19  original_T_including_depot_unload_1632  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1490  1
    load_2_18_19  free_load_conservation_1611  1
    load_2_18_19  free_load_conservation_1617  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1492  -30
    arc_2_18_20  connected_order_arc_1493  -12
    arc_2_18_20  out_degree_1606  1
    arc_2_18_20  in_degree_1619  1
    arc_2_18_20  original_T_including_depot_unload_1632  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1492  1
    load_2_18_20  free_load_conservation_1611  1
    load_2_18_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1494  -30
    arc_2_18_21  connected_order_arc_1495  -12
    arc_2_18_21  out_degree_1606  1
    arc_2_18_21  in_degree_1625  1
    arc_2_18_21  original_T_including_depot_unload_1632  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1494  1
    load_2_18_21  free_load_conservation_1611  1
    load_2_18_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1496  -30
    arc_2_19_0  depot_return_or_bypass_1560  1
    arc_2_19_0  out_degree_1612  1
    arc_2_19_0  original_T_including_depot_unload_1632  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1496  1
    load_2_19_0  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1497  -30
    arc_2_19_11  connected_order_arc_1498  -12
    arc_2_19_11  in_degree_1562  1
    arc_2_19_11  out_degree_1612  1
    arc_2_19_11  original_T_including_depot_unload_1632  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1497  1
    load_2_19_11  segment_load_conservation_1565  -1
    load_2_19_11  segment_prefix_lb_1566  1
    load_2_19_11  segment_prefix_ub_1567  1
    load_2_19_11  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1499  -30
    arc_2_19_12  connected_order_arc_1500  -12
    arc_2_19_12  in_degree_1569  1
    arc_2_19_12  out_degree_1612  1
    arc_2_19_12  original_T_including_depot_unload_1632  1.8805180645589260e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1499  1
    load_2_19_12  segment_load_conservation_1572  -1
    load_2_19_12  segment_prefix_lb_1573  1
    load_2_19_12  segment_prefix_ub_1574  1
    load_2_19_12  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1501  -30
    arc_2_19_13  connected_order_arc_1502  -12
    arc_2_19_13  in_degree_1576  1
    arc_2_19_13  out_degree_1612  1
    arc_2_19_13  original_T_including_depot_unload_1632  1.0875821153726588e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1501  1
    load_2_19_13  segment_load_conservation_1579  -1
    load_2_19_13  segment_prefix_lb_1580  1
    load_2_19_13  segment_prefix_ub_1581  1
    load_2_19_13  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1503  -30
    arc_2_19_14  connected_order_arc_1504  -12
    arc_2_19_14  in_degree_1583  1
    arc_2_19_14  out_degree_1612  1
    arc_2_19_14  original_T_including_depot_unload_1632  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1503  1
    load_2_19_14  free_load_conservation_1587  -1
    load_2_19_14  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1505  -30
    arc_2_19_15  connected_order_arc_1506  -12
    arc_2_19_15  in_degree_1589  1
    arc_2_19_15  out_degree_1612  1
    arc_2_19_15  original_T_including_depot_unload_1632  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1505  1
    load_2_19_15  free_load_conservation_1593  -1
    load_2_19_15  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1507  -30
    arc_2_19_16  connected_order_arc_1508  -12
    arc_2_19_16  in_degree_1595  1
    arc_2_19_16  out_degree_1612  1
    arc_2_19_16  original_T_including_depot_unload_1632  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1507  1
    load_2_19_16  free_load_conservation_1599  -1
    load_2_19_16  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1509  -30
    arc_2_19_17  connected_order_arc_1510  -12
    arc_2_19_17  in_degree_1601  1
    arc_2_19_17  out_degree_1612  1
    arc_2_19_17  original_T_including_depot_unload_1632  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1509  1
    load_2_19_17  free_load_conservation_1605  -1
    load_2_19_17  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1511  -30
    arc_2_19_18  connected_order_arc_1512  -12
    arc_2_19_18  in_degree_1607  1
    arc_2_19_18  out_degree_1612  1
    arc_2_19_18  original_T_including_depot_unload_1632  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1511  1
    load_2_19_18  free_load_conservation_1611  -1
    load_2_19_18  free_load_conservation_1617  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1513  -30
    arc_2_19_20  connected_order_arc_1514  -12
    arc_2_19_20  out_degree_1612  1
    arc_2_19_20  in_degree_1619  1
    arc_2_19_20  original_T_including_depot_unload_1632  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1513  1
    load_2_19_20  free_load_conservation_1617  1
    load_2_19_20  free_load_conservation_1623  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1515  -30
    arc_2_19_21  connected_order_arc_1516  -12
    arc_2_19_21  out_degree_1612  1
    arc_2_19_21  in_degree_1625  1
    arc_2_19_21  original_T_including_depot_unload_1632  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1515  1
    load_2_19_21  free_load_conservation_1617  1
    load_2_19_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1517  -30
    arc_2_20_0  depot_return_or_bypass_1560  1
    arc_2_20_0  out_degree_1618  1
    arc_2_20_0  original_T_including_depot_unload_1632  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1517  1
    load_2_20_0  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1518  -30
    arc_2_20_11  connected_order_arc_1519  -12
    arc_2_20_11  in_degree_1562  1
    arc_2_20_11  out_degree_1618  1
    arc_2_20_11  original_T_including_depot_unload_1632  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1518  1
    load_2_20_11  segment_load_conservation_1565  -1
    load_2_20_11  segment_prefix_lb_1566  1
    load_2_20_11  segment_prefix_ub_1567  1
    load_2_20_11  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1520  -30
    arc_2_20_12  connected_order_arc_1521  -12
    arc_2_20_12  in_degree_1569  1
    arc_2_20_12  out_degree_1618  1
    arc_2_20_12  original_T_including_depot_unload_1632  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1520  1
    load_2_20_12  segment_load_conservation_1572  -1
    load_2_20_12  segment_prefix_lb_1573  1
    load_2_20_12  segment_prefix_ub_1574  1
    load_2_20_12  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1522  -30
    arc_2_20_13  connected_order_arc_1523  -12
    arc_2_20_13  in_degree_1576  1
    arc_2_20_13  out_degree_1618  1
    arc_2_20_13  original_T_including_depot_unload_1632  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1522  1
    load_2_20_13  segment_load_conservation_1579  -1
    load_2_20_13  segment_prefix_lb_1580  1
    load_2_20_13  segment_prefix_ub_1581  1
    load_2_20_13  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1524  -30
    arc_2_20_14  connected_order_arc_1525  -12
    arc_2_20_14  in_degree_1583  1
    arc_2_20_14  out_degree_1618  1
    arc_2_20_14  original_T_including_depot_unload_1632  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1524  1
    load_2_20_14  free_load_conservation_1587  -1
    load_2_20_14  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1526  -30
    arc_2_20_15  connected_order_arc_1527  -12
    arc_2_20_15  in_degree_1589  1
    arc_2_20_15  out_degree_1618  1
    arc_2_20_15  original_T_including_depot_unload_1632  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1526  1
    load_2_20_15  free_load_conservation_1593  -1
    load_2_20_15  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1528  -30
    arc_2_20_16  connected_order_arc_1529  -12
    arc_2_20_16  in_degree_1595  1
    arc_2_20_16  out_degree_1618  1
    arc_2_20_16  original_T_including_depot_unload_1632  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1528  1
    load_2_20_16  free_load_conservation_1599  -1
    load_2_20_16  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1530  -30
    arc_2_20_17  connected_order_arc_1531  -12
    arc_2_20_17  in_degree_1601  1
    arc_2_20_17  out_degree_1618  1
    arc_2_20_17  original_T_including_depot_unload_1632  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1530  1
    load_2_20_17  free_load_conservation_1605  -1
    load_2_20_17  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1532  -30
    arc_2_20_18  connected_order_arc_1533  -12
    arc_2_20_18  in_degree_1607  1
    arc_2_20_18  out_degree_1618  1
    arc_2_20_18  original_T_including_depot_unload_1632  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1532  1
    load_2_20_18  free_load_conservation_1611  -1
    load_2_20_18  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1534  -30
    arc_2_20_19  connected_order_arc_1535  -12
    arc_2_20_19  in_degree_1613  1
    arc_2_20_19  out_degree_1618  1
    arc_2_20_19  original_T_including_depot_unload_1632  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1534  1
    load_2_20_19  free_load_conservation_1617  -1
    load_2_20_19  free_load_conservation_1623  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1536  -30
    arc_2_20_21  connected_order_arc_1537  -12
    arc_2_20_21  out_degree_1618  1
    arc_2_20_21  in_degree_1625  1
    arc_2_20_21  original_T_including_depot_unload_1632  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1536  1
    load_2_20_21  free_load_conservation_1623  1
    load_2_20_21  free_load_conservation_1629  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1538  -30
    arc_2_21_0  depot_return_or_bypass_1560  1
    arc_2_21_0  out_degree_1624  1
    arc_2_21_0  original_T_including_depot_unload_1632  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1538  1
    load_2_21_0  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1539  -30
    arc_2_21_11  connected_order_arc_1540  -12
    arc_2_21_11  in_degree_1562  1
    arc_2_21_11  out_degree_1624  1
    arc_2_21_11  original_T_including_depot_unload_1632  7.0350721341213284e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1539  1
    load_2_21_11  segment_load_conservation_1565  -1
    load_2_21_11  segment_prefix_lb_1566  1
    load_2_21_11  segment_prefix_ub_1567  1
    load_2_21_11  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1541  -30
    arc_2_21_12  connected_order_arc_1542  -12
    arc_2_21_12  in_degree_1569  1
    arc_2_21_12  out_degree_1624  1
    arc_2_21_12  original_T_including_depot_unload_1632  1.9296708118526319e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1541  1
    load_2_21_12  segment_load_conservation_1572  -1
    load_2_21_12  segment_prefix_lb_1573  1
    load_2_21_12  segment_prefix_ub_1574  1
    load_2_21_12  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1543  -30
    arc_2_21_13  connected_order_arc_1544  -12
    arc_2_21_13  in_degree_1576  1
    arc_2_21_13  out_degree_1624  1
    arc_2_21_13  original_T_including_depot_unload_1632  1.5322275462532455e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1543  1
    load_2_21_13  segment_load_conservation_1579  -1
    load_2_21_13  segment_prefix_lb_1580  1
    load_2_21_13  segment_prefix_ub_1581  1
    load_2_21_13  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1545  -30
    arc_2_21_14  connected_order_arc_1546  -12
    arc_2_21_14  in_degree_1583  1
    arc_2_21_14  out_degree_1624  1
    arc_2_21_14  original_T_including_depot_unload_1632  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1545  1
    load_2_21_14  free_load_conservation_1587  -1
    load_2_21_14  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1547  -30
    arc_2_21_15  connected_order_arc_1548  -12
    arc_2_21_15  in_degree_1589  1
    arc_2_21_15  out_degree_1624  1
    arc_2_21_15  original_T_including_depot_unload_1632  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1547  1
    load_2_21_15  free_load_conservation_1593  -1
    load_2_21_15  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1549  -30
    arc_2_21_16  connected_order_arc_1550  -12
    arc_2_21_16  in_degree_1595  1
    arc_2_21_16  out_degree_1624  1
    arc_2_21_16  original_T_including_depot_unload_1632  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1549  1
    load_2_21_16  free_load_conservation_1599  -1
    load_2_21_16  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1551  -30
    arc_2_21_17  connected_order_arc_1552  -12
    arc_2_21_17  in_degree_1601  1
    arc_2_21_17  out_degree_1624  1
    arc_2_21_17  original_T_including_depot_unload_1632  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1551  1
    load_2_21_17  free_load_conservation_1605  -1
    load_2_21_17  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1553  -30
    arc_2_21_18  connected_order_arc_1554  -12
    arc_2_21_18  in_degree_1607  1
    arc_2_21_18  out_degree_1624  1
    arc_2_21_18  original_T_including_depot_unload_1632  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1553  1
    load_2_21_18  free_load_conservation_1611  -1
    load_2_21_18  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1555  -30
    arc_2_21_19  connected_order_arc_1556  -12
    arc_2_21_19  in_degree_1613  1
    arc_2_21_19  out_degree_1624  1
    arc_2_21_19  original_T_including_depot_unload_1632  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1555  1
    load_2_21_19  free_load_conservation_1617  -1
    load_2_21_19  free_load_conservation_1629  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1557  -30
    arc_2_21_20  connected_order_arc_1558  -12
    arc_2_21_20  in_degree_1619  1
    arc_2_21_20  out_degree_1624  1
    arc_2_21_20  original_T_including_depot_unload_1632  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1557  1
    load_2_21_20  free_load_conservation_1623  -1
    load_2_21_20  free_load_conservation_1629  1
RHS
    RHS1      OBJ       -0.6045
    RHS1      onehot_4_32  1
    RHS1      onehot_7_71  1
    RHS1      onehot_31_100  1
    RHS1      onehot_1_143  1
    RHS1      onehot_2_178  1
    RHS1      onehot_3_217  1
    RHS1      onehot_16_246  1
    RHS1      onehot_11_275  1
    RHS1      stock_ub_279  45
    RHS1      parent_nonstrict_scope_280  2.8994083613095734e-01
    RHS1      normalization_337  1
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_478  -13
    RHS1      connected_order_arc_480  -13
    RHS1      connected_order_arc_482  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_503  -13
    RHS1      connected_order_arc_505  -13
    RHS1      connected_order_arc_507  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_528  -13
    RHS1      connected_order_arc_530  -13
    RHS1      connected_order_arc_532  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_553  -13
    RHS1      connected_order_arc_555  -13
    RHS1      connected_order_arc_557  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_578  -13
    RHS1      connected_order_arc_580  -13
    RHS1      connected_order_arc_582  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_603  -13
    RHS1      connected_order_arc_605  -13
    RHS1      connected_order_arc_607  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_628  -13
    RHS1      connected_order_arc_630  -13
    RHS1      connected_order_arc_632  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_653  -13
    RHS1      connected_order_arc_655  -13
    RHS1      connected_order_arc_657  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_678  -13
    RHS1      connected_order_arc_680  -13
    RHS1      connected_order_arc_682  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_703  -13
    RHS1      connected_order_arc_705  -13
    RHS1      connected_order_arc_707  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_724  -13
    RHS1      connected_order_arc_726  -13
    RHS1      connected_order_arc_728  -13
    RHS1      connected_order_arc_730  -13
    RHS1      connected_order_arc_732  -13
    RHS1      connected_order_arc_734  -13
    RHS1      connected_order_arc_736  -13
    RHS1      connected_order_arc_738  -13
    RHS1      connected_order_arc_740  -13
    RHS1      connected_order_arc_742  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_746  -13
    RHS1      connected_order_arc_749  -13
    RHS1      connected_order_arc_751  -13
    RHS1      connected_order_arc_753  -13
    RHS1      connected_order_arc_755  -13
    RHS1      connected_order_arc_757  -13
    RHS1      connected_order_arc_759  -13
    RHS1      connected_order_arc_761  -13
    RHS1      connected_order_arc_763  -13
    RHS1      connected_order_arc_765  -13
    RHS1      connected_order_arc_767  -13
    RHS1      connected_order_arc_769  -13
    RHS1      connected_order_arc_771  -13
    RHS1      connected_order_arc_774  -13
    RHS1      connected_order_arc_776  -13
    RHS1      connected_order_arc_778  -13
    RHS1      connected_order_arc_780  -13
    RHS1      connected_order_arc_782  -13
    RHS1      connected_order_arc_784  -13
    RHS1      connected_order_arc_786  -13
    RHS1      connected_order_arc_788  -13
    RHS1      connected_order_arc_790  -13
    RHS1      connected_order_arc_792  -13
    RHS1      connected_order_arc_794  -13
    RHS1      connected_order_arc_796  -13
    RHS1      depot_departure_or_bypass_797  1
    RHS1      depot_return_or_bypass_798  1
    RHS1      segment_load_conservation_803  5
    RHS1      segment_prefix_ub_805  15
    RHS1      segment_load_conservation_810  -4
    RHS1      segment_prefix_lb_811  4
    RHS1      segment_prefix_ub_812  20
    RHS1      segment_load_conservation_817  -2
    RHS1      segment_prefix_lb_818  2
    RHS1      segment_prefix_ub_819  20
    RHS1      segment_load_conservation_824  5
    RHS1      segment_prefix_ub_826  15
    RHS1      segment_load_conservation_831  -9
    RHS1      segment_prefix_lb_832  9
    RHS1      segment_prefix_ub_833  15
    RHS1      fixed_segment_relative_order_882  1
    RHS1      fixed_segment_relative_order_883  1
    RHS1      fixed_segment_relative_order_884  1
    RHS1      fixed_segment_relative_order_885  1
    RHS1      original_T_including_depot_unload_886  4.6885578181927040e+03
    RHS1      connected_order_arc_903  -13
    RHS1      connected_order_arc_905  -13
    RHS1      connected_order_arc_907  -13
    RHS1      connected_order_arc_909  -13
    RHS1      connected_order_arc_911  -13
    RHS1      connected_order_arc_913  -13
    RHS1      connected_order_arc_915  -13
    RHS1      connected_order_arc_917  -13
    RHS1      connected_order_arc_919  -13
    RHS1      connected_order_arc_921  -13
    RHS1      connected_order_arc_923  -13
    RHS1      connected_order_arc_925  -13
    RHS1      connected_order_arc_928  -13
    RHS1      connected_order_arc_930  -13
    RHS1      connected_order_arc_932  -13
    RHS1      connected_order_arc_934  -13
    RHS1      connected_order_arc_936  -13
    RHS1      connected_order_arc_938  -13
    RHS1      connected_order_arc_940  -13
    RHS1      connected_order_arc_942  -13
    RHS1      connected_order_arc_944  -13
    RHS1      connected_order_arc_946  -13
    RHS1      connected_order_arc_948  -13
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_953  -13
    RHS1      connected_order_arc_955  -13
    RHS1      connected_order_arc_957  -13
    RHS1      connected_order_arc_959  -13
    RHS1      connected_order_arc_961  -13
    RHS1      connected_order_arc_963  -13
    RHS1      connected_order_arc_965  -13
    RHS1      connected_order_arc_967  -13
    RHS1      connected_order_arc_969  -13
    RHS1      connected_order_arc_971  -13
    RHS1      connected_order_arc_973  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_978  -13
    RHS1      connected_order_arc_980  -13
    RHS1      connected_order_arc_982  -13
    RHS1      connected_order_arc_984  -13
    RHS1      connected_order_arc_986  -13
    RHS1      connected_order_arc_988  -13
    RHS1      connected_order_arc_990  -13
    RHS1      connected_order_arc_992  -13
    RHS1      connected_order_arc_994  -13
    RHS1      connected_order_arc_996  -13
    RHS1      connected_order_arc_998  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1003  -13
    RHS1      connected_order_arc_1005  -13
    RHS1      connected_order_arc_1007  -13
    RHS1      connected_order_arc_1009  -13
    RHS1      connected_order_arc_1011  -13
    RHS1      connected_order_arc_1013  -13
    RHS1      connected_order_arc_1015  -13
    RHS1      connected_order_arc_1017  -13
    RHS1      connected_order_arc_1019  -13
    RHS1      connected_order_arc_1021  -13
    RHS1      connected_order_arc_1023  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1028  -13
    RHS1      connected_order_arc_1030  -13
    RHS1      connected_order_arc_1032  -13
    RHS1      connected_order_arc_1034  -13
    RHS1      connected_order_arc_1036  -13
    RHS1      connected_order_arc_1038  -13
    RHS1      connected_order_arc_1040  -13
    RHS1      connected_order_arc_1042  -13
    RHS1      connected_order_arc_1044  -13
    RHS1      connected_order_arc_1046  -13
    RHS1      connected_order_arc_1048  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1053  -13
    RHS1      connected_order_arc_1055  -13
    RHS1      connected_order_arc_1057  -13
    RHS1      connected_order_arc_1059  -13
    RHS1      connected_order_arc_1061  -13
    RHS1      connected_order_arc_1063  -13
    RHS1      connected_order_arc_1065  -13
    RHS1      connected_order_arc_1067  -13
    RHS1      connected_order_arc_1069  -13
    RHS1      connected_order_arc_1071  -13
    RHS1      connected_order_arc_1073  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1078  -13
    RHS1      connected_order_arc_1080  -13
    RHS1      connected_order_arc_1082  -13
    RHS1      connected_order_arc_1084  -13
    RHS1      connected_order_arc_1086  -13
    RHS1      connected_order_arc_1088  -13
    RHS1      connected_order_arc_1090  -13
    RHS1      connected_order_arc_1092  -13
    RHS1      connected_order_arc_1094  -13
    RHS1      connected_order_arc_1096  -13
    RHS1      connected_order_arc_1098  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1103  -13
    RHS1      connected_order_arc_1105  -13
    RHS1      connected_order_arc_1107  -13
    RHS1      connected_order_arc_1109  -13
    RHS1      connected_order_arc_1111  -13
    RHS1      connected_order_arc_1113  -13
    RHS1      connected_order_arc_1115  -13
    RHS1      connected_order_arc_1117  -13
    RHS1      connected_order_arc_1119  -13
    RHS1      connected_order_arc_1121  -13
    RHS1      connected_order_arc_1123  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1128  -13
    RHS1      connected_order_arc_1130  -13
    RHS1      connected_order_arc_1132  -13
    RHS1      connected_order_arc_1134  -13
    RHS1      connected_order_arc_1136  -13
    RHS1      connected_order_arc_1138  -13
    RHS1      connected_order_arc_1140  -13
    RHS1      connected_order_arc_1142  -13
    RHS1      connected_order_arc_1144  -13
    RHS1      connected_order_arc_1146  -13
    RHS1      connected_order_arc_1148  -13
    RHS1      connected_order_arc_1150  -13
    RHS1      connected_order_arc_1153  -13
    RHS1      connected_order_arc_1155  -13
    RHS1      connected_order_arc_1157  -13
    RHS1      connected_order_arc_1159  -13
    RHS1      connected_order_arc_1161  -13
    RHS1      connected_order_arc_1163  -13
    RHS1      connected_order_arc_1165  -13
    RHS1      connected_order_arc_1167  -13
    RHS1      connected_order_arc_1169  -13
    RHS1      connected_order_arc_1171  -13
    RHS1      connected_order_arc_1173  -13
    RHS1      connected_order_arc_1175  -13
    RHS1      connected_order_arc_1178  -13
    RHS1      connected_order_arc_1180  -13
    RHS1      connected_order_arc_1182  -13
    RHS1      connected_order_arc_1184  -13
    RHS1      connected_order_arc_1186  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      connected_order_arc_1190  -13
    RHS1      connected_order_arc_1192  -13
    RHS1      connected_order_arc_1194  -13
    RHS1      connected_order_arc_1196  -13
    RHS1      connected_order_arc_1198  -13
    RHS1      connected_order_arc_1200  -13
    RHS1      connected_order_arc_1203  -13
    RHS1      connected_order_arc_1205  -13
    RHS1      connected_order_arc_1207  -13
    RHS1      connected_order_arc_1209  -13
    RHS1      connected_order_arc_1211  -13
    RHS1      connected_order_arc_1213  -13
    RHS1      connected_order_arc_1215  -13
    RHS1      connected_order_arc_1217  -13
    RHS1      connected_order_arc_1219  -13
    RHS1      connected_order_arc_1221  -13
    RHS1      connected_order_arc_1223  -13
    RHS1      connected_order_arc_1225  -13
    RHS1      depot_departure_or_bypass_1226  1
    RHS1      depot_return_or_bypass_1227  1
    RHS1      segment_load_conservation_1232  6
    RHS1      segment_prefix_ub_1234  19
    RHS1      segment_prefix_lb_1240  6
    RHS1      segment_prefix_ub_1241  25
    RHS1      segment_load_conservation_1246  -5
    RHS1      segment_prefix_lb_1247  5
    RHS1      segment_prefix_ub_1248  25
    RHS1      segment_load_conservation_1253  3
    RHS1      segment_prefix_ub_1255  22
    RHS1      segment_load_conservation_1260  -5
    RHS1      segment_prefix_lb_1261  5
    RHS1      segment_prefix_ub_1262  25
    RHS1      fixed_segment_relative_order_1311  1
    RHS1      fixed_segment_relative_order_1312  1
    RHS1      fixed_segment_relative_order_1313  1
    RHS1      fixed_segment_relative_order_1314  1
    RHS1      original_T_including_depot_unload_1315  2.7599172580707964e+03
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1460  -11
    RHS1      connected_order_arc_1462  -11
    RHS1      connected_order_arc_1464  -11
    RHS1      connected_order_arc_1466  -11
    RHS1      connected_order_arc_1468  -11
    RHS1      connected_order_arc_1470  -11
    RHS1      connected_order_arc_1472  -11
    RHS1      connected_order_arc_1474  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1481  -11
    RHS1      connected_order_arc_1483  -11
    RHS1      connected_order_arc_1485  -11
    RHS1      connected_order_arc_1487  -11
    RHS1      connected_order_arc_1489  -11
    RHS1      connected_order_arc_1491  -11
    RHS1      connected_order_arc_1493  -11
    RHS1      connected_order_arc_1495  -11
    RHS1      connected_order_arc_1498  -11
    RHS1      connected_order_arc_1500  -11
    RHS1      connected_order_arc_1502  -11
    RHS1      connected_order_arc_1504  -11
    RHS1      connected_order_arc_1506  -11
    RHS1      connected_order_arc_1508  -11
    RHS1      connected_order_arc_1510  -11
    RHS1      connected_order_arc_1512  -11
    RHS1      connected_order_arc_1514  -11
    RHS1      connected_order_arc_1516  -11
    RHS1      connected_order_arc_1519  -11
    RHS1      connected_order_arc_1521  -11
    RHS1      connected_order_arc_1523  -11
    RHS1      connected_order_arc_1525  -11
    RHS1      connected_order_arc_1527  -11
    RHS1      connected_order_arc_1529  -11
    RHS1      connected_order_arc_1531  -11
    RHS1      connected_order_arc_1533  -11
    RHS1      connected_order_arc_1535  -11
    RHS1      connected_order_arc_1537  -11
    RHS1      connected_order_arc_1540  -11
    RHS1      connected_order_arc_1542  -11
    RHS1      connected_order_arc_1544  -11
    RHS1      connected_order_arc_1546  -11
    RHS1      connected_order_arc_1548  -11
    RHS1      connected_order_arc_1550  -11
    RHS1      connected_order_arc_1552  -11
    RHS1      connected_order_arc_1554  -11
    RHS1      connected_order_arc_1556  -11
    RHS1      connected_order_arc_1558  -11
    RHS1      depot_departure_or_bypass_1559  1
    RHS1      depot_return_or_bypass_1560  1
    RHS1      segment_load_conservation_1565  2
    RHS1      segment_prefix_ub_1567  28
    RHS1      segment_prefix_ub_1574  27
    RHS1      segment_load_conservation_1579  2
    RHS1      segment_prefix_ub_1581  24
    RHS1      fixed_segment_relative_order_1630  1
    RHS1      fixed_segment_relative_order_1631  1
    RHS1      original_T_including_depot_unload_1632  4.2424928979880842e+03
BOUNDS
 LO BND1      t         2.5140668023439477e-02
 UP BND1      t         4.3054843669955919e-02
 UP BND1      q         5.3744083613095739e-01
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.3054843669955919e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.3054843669955919e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.3054843669955919e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.3054843669955919e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.3054843669955919e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.3054843669955919e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.3054843669955919e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.3054843669955919e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.3054843669955919e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.3054843669955919e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.3054843669955919e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.3054843669955919e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.3054843669955919e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.3054843669955919e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.3054843669955919e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.3054843669955919e-02
 UP BND1      rho_4     1
 BV BND1      x_7_0   
 UP BND1      w_7_0     4.3054843669955919e-02
 BV BND1      x_7_1   
 UP BND1      w_7_1     4.3054843669955919e-02
 BV BND1      x_7_2   
 UP BND1      w_7_2     4.3054843669955919e-02
 BV BND1      x_7_3   
 UP BND1      w_7_3     4.3054843669955919e-02
 BV BND1      x_7_4   
 UP BND1      w_7_4     4.3054843669955919e-02
 BV BND1      x_7_5   
 UP BND1      w_7_5     4.3054843669955919e-02
 BV BND1      x_7_6   
 UP BND1      w_7_6     4.3054843669955919e-02
 BV BND1      x_7_7   
 UP BND1      w_7_7     4.3054843669955919e-02
 BV BND1      x_7_8   
 UP BND1      w_7_8     4.3054843669955919e-02
 BV BND1      x_7_9   
 UP BND1      w_7_9     4.3054843669955919e-02
 BV BND1      x_7_10  
 UP BND1      w_7_10    4.3054843669955919e-02
 BV BND1      x_7_11  
 UP BND1      w_7_11    4.3054843669955919e-02
 BV BND1      x_7_12  
 UP BND1      w_7_12    4.3054843669955919e-02
 BV BND1      x_7_13  
 UP BND1      w_7_13    4.3054843669955919e-02
 BV BND1      x_7_14  
 UP BND1      w_7_14    4.3054843669955919e-02
 BV BND1      x_7_15  
 UP BND1      w_7_15    4.3054843669955919e-02
 BV BND1      x_7_16  
 UP BND1      w_7_16    4.3054843669955919e-02
 BV BND1      x_7_17  
 UP BND1      w_7_17    4.3054843669955919e-02
 UP BND1      rho_7     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.3054843669955919e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.3054843669955919e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.3054843669955919e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.3054843669955919e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.3054843669955919e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.3054843669955919e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.3054843669955919e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.3054843669955919e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.3054843669955919e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.3054843669955919e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.3054843669955919e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.3054843669955919e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.3054843669955919e-02
 UP BND1      rho_31    1
 BV BND1      x_1_0   
 UP BND1      w_1_0     4.3054843669955919e-02
 BV BND1      x_1_1   
 UP BND1      w_1_1     4.3054843669955919e-02
 BV BND1      x_1_2   
 UP BND1      w_1_2     4.3054843669955919e-02
 BV BND1      x_1_3   
 UP BND1      w_1_3     4.3054843669955919e-02
 BV BND1      x_1_4   
 UP BND1      w_1_4     4.3054843669955919e-02
 BV BND1      x_1_5   
 UP BND1      w_1_5     4.3054843669955919e-02
 BV BND1      x_1_6   
 UP BND1      w_1_6     4.3054843669955919e-02
 BV BND1      x_1_7   
 UP BND1      w_1_7     4.3054843669955919e-02
 BV BND1      x_1_8   
 UP BND1      w_1_8     4.3054843669955919e-02
 BV BND1      x_1_9   
 UP BND1      w_1_9     4.3054843669955919e-02
 BV BND1      x_1_10  
 UP BND1      w_1_10    4.3054843669955919e-02
 BV BND1      x_1_11  
 UP BND1      w_1_11    4.3054843669955919e-02
 BV BND1      x_1_12  
 UP BND1      w_1_12    4.3054843669955919e-02
 BV BND1      x_1_13  
 UP BND1      w_1_13    4.3054843669955919e-02
 BV BND1      x_1_14  
 UP BND1      w_1_14    4.3054843669955919e-02
 BV BND1      x_1_15  
 UP BND1      w_1_15    4.3054843669955919e-02
 BV BND1      x_1_16  
 UP BND1      w_1_16    4.3054843669955919e-02
 BV BND1      x_1_17  
 UP BND1      w_1_17    4.3054843669955919e-02
 BV BND1      x_1_18  
 UP BND1      w_1_18    4.3054843669955919e-02
 BV BND1      x_1_19  
 UP BND1      w_1_19    4.3054843669955919e-02
 UP BND1      rho_1     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.3054843669955919e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.3054843669955919e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.3054843669955919e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.3054843669955919e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.3054843669955919e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.3054843669955919e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.3054843669955919e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.3054843669955919e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.3054843669955919e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.3054843669955919e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.3054843669955919e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.3054843669955919e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.3054843669955919e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.3054843669955919e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.3054843669955919e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.3054843669955919e-02
 UP BND1      rho_2     1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.3054843669955919e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.3054843669955919e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.3054843669955919e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.3054843669955919e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.3054843669955919e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.3054843669955919e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.3054843669955919e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.3054843669955919e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.3054843669955919e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.3054843669955919e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.3054843669955919e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.3054843669955919e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.3054843669955919e-02
 BV BND1      x_3_13  
 UP BND1      w_3_13    4.3054843669955919e-02
 BV BND1      x_3_14  
 UP BND1      w_3_14    4.3054843669955919e-02
 BV BND1      x_3_15  
 UP BND1      w_3_15    4.3054843669955919e-02
 BV BND1      x_3_16  
 UP BND1      w_3_16    4.3054843669955919e-02
 BV BND1      x_3_17  
 UP BND1      w_3_17    4.3054843669955919e-02
 UP BND1      rho_3     1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.3054843669955919e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.3054843669955919e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.3054843669955919e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.3054843669955919e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.3054843669955919e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.3054843669955919e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.3054843669955919e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.3054843669955919e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.3054843669955919e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.3054843669955919e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.3054843669955919e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.3054843669955919e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.3054843669955919e-02
 UP BND1      rho_16    1
 BV BND1      x_11_0  
 UP BND1      w_11_0    4.3054843669955919e-02
 BV BND1      x_11_1  
 UP BND1      w_11_1    4.3054843669955919e-02
 BV BND1      x_11_2  
 UP BND1      w_11_2    4.3054843669955919e-02
 BV BND1      x_11_3  
 UP BND1      w_11_3    4.3054843669955919e-02
 BV BND1      x_11_4  
 UP BND1      w_11_4    4.3054843669955919e-02
 BV BND1      x_11_5  
 UP BND1      w_11_5    4.3054843669955919e-02
 BV BND1      x_11_6  
 UP BND1      w_11_6    4.3054843669955919e-02
 BV BND1      x_11_7  
 UP BND1      w_11_7    4.3054843669955919e-02
 BV BND1      x_11_8  
 UP BND1      w_11_8    4.3054843669955919e-02
 BV BND1      x_11_9  
 UP BND1      w_11_9    4.3054843669955919e-02
 BV BND1      x_11_10 
 UP BND1      w_11_10   4.3054843669955919e-02
 BV BND1      x_11_11 
 UP BND1      w_11_11   4.3054843669955919e-02
 BV BND1      x_11_12 
 UP BND1      w_11_12   4.3054843669955919e-02
 UP BND1      rho_11    1
 UP BND1      a_4_7     1
 UP BND1      a_4_31    1
 UP BND1      a_4_1     1
 UP BND1      a_4_2     1
 UP BND1      a_4_3     1
 UP BND1      a_4_16    1
 UP BND1      a_4_11    1
 UP BND1      a_7_31    1
 UP BND1      a_7_1     1
 UP BND1      a_7_2     1
 UP BND1      a_7_3     1
 UP BND1      a_7_16    1
 UP BND1      a_7_11    1
 UP BND1      a_31_1    1
 UP BND1      a_31_2    1
 UP BND1      a_31_3    1
 UP BND1      a_31_16   1
 UP BND1      a_31_11   1
 UP BND1      a_1_2     1
 UP BND1      a_1_3     1
 UP BND1      a_1_16    1
 UP BND1      a_1_11    1
 UP BND1      a_2_3     1
 UP BND1      a_2_16    1
 UP BND1      a_2_11    1
 UP BND1      a_3_16    1
 UP BND1      a_3_11    1
 UP BND1      a_16_11   1
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_2
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_7_0
 BV BND1      service_0_7_1
 BV BND1      service_0_7_2
 BV BND1      service_0_7_3
 BV BND1      service_0_7_4
 BV BND1      service_0_7_5
 BV BND1      service_0_7_6
 BV BND1      service_0_7_7
 BV BND1      service_0_7_8
 BV BND1      service_0_7_9
 BV BND1      service_0_7_10
 BV BND1      service_0_7_11
 BV BND1      service_0_7_13
 BV BND1      service_0_7_14
 BV BND1      service_0_7_15
 BV BND1      service_0_7_16
 BV BND1      service_0_7_17
 BV BND1      service_1_7_0
 BV BND1      service_1_7_1
 BV BND1      service_1_7_2
 BV BND1      service_1_7_3
 BV BND1      service_1_7_4
 BV BND1      service_1_7_5
 BV BND1      service_1_7_6
 BV BND1      service_1_7_7
 BV BND1      service_1_7_8
 BV BND1      service_1_7_9
 BV BND1      service_1_7_10
 BV BND1      service_1_7_11
 BV BND1      service_1_7_13
 BV BND1      service_1_7_14
 BV BND1      service_1_7_15
 BV BND1      service_1_7_16
 BV BND1      service_1_7_17
 BV BND1      service_2_7_0
 BV BND1      service_2_7_1
 BV BND1      service_2_7_2
 BV BND1      service_2_7_3
 BV BND1      service_2_7_4
 BV BND1      service_2_7_5
 BV BND1      service_2_7_6
 BV BND1      service_2_7_7
 BV BND1      service_2_7_8
 BV BND1      service_2_7_9
 BV BND1      service_2_7_10
 BV BND1      service_2_7_11
 BV BND1      service_2_7_13
 BV BND1      service_2_7_14
 BV BND1      service_2_7_15
 BV BND1      service_2_7_16
 BV BND1      service_2_7_17
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_0_1_16
 BV BND1      service_0_1_17
 BV BND1      service_0_1_18
 BV BND1      service_0_1_19
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_1_1_16
 BV BND1      service_1_1_17
 BV BND1      service_1_1_18
 BV BND1      service_1_1_19
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_6
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_2_1_9
 BV BND1      service_2_1_10
 BV BND1      service_2_1_11
 BV BND1      service_2_1_12
 BV BND1      service_2_1_13
 BV BND1      service_2_1_14
 BV BND1      service_2_1_15
 BV BND1      service_2_1_16
 BV BND1      service_2_1_17
 BV BND1      service_2_1_18
 BV BND1      service_2_1_19
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_11_0
 BV BND1      service_0_11_1
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_1_11_0
 BV BND1      service_1_11_1
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_2_11_0
 BV BND1      service_2_11_1
 BV BND1      service_2_11_2
 BV BND1      service_2_11_3
 BV BND1      service_2_11_4
 BV BND1      service_2_11_5
 BV BND1      service_2_11_6
 BV BND1      service_2_11_8
 BV BND1      service_2_11_9
 BV BND1      service_2_11_10
 BV BND1      service_2_11_11
 BV BND1      service_2_11_12
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 FX BND1      visit_1_10  1
 UP BND1      order_1_10  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  25
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  25
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  25
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  25
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  25
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  25
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  25
 BV BND1      arc_1_10_16
 UP BND1      load_1_10_16  25
 BV BND1      arc_1_10_17
 UP BND1      load_1_10_17  25
 BV BND1      arc_1_10_18
 UP BND1      load_1_10_18  25
 BV BND1      arc_1_10_19
 UP BND1      load_1_10_19  25
 BV BND1      arc_1_10_20
 UP BND1      load_1_10_20  25
 BV BND1      arc_1_10_21
 UP BND1      load_1_10_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_10
 UP BND1      load_1_16_10  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_10
 UP BND1      load_1_17_10  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_10
 UP BND1      load_1_18_10  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_10
 UP BND1      load_1_19_10  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_10
 UP BND1      load_1_20_10  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_10
 UP BND1      load_1_21_10  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
