* Signature: 0xc7c795e61e5cb7a2
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 E  onehot_1_40
 E  normalized_mass_1_41
 E  normalized_ratio_1_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 G  product_lb_67
 L  product_ub_68
 G  product_lb_69
 L  product_ub_70
 G  product_lb_71
 L  product_ub_72
 G  product_lb_73
 L  product_ub_74
 E  onehot_2_75
 E  normalized_mass_2_76
 E  normalized_ratio_2_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 G  product_lb_96
 L  product_ub_97
 G  product_lb_98
 L  product_ub_99
 G  product_lb_100
 L  product_ub_101
 G  product_lb_102
 L  product_ub_103
 E  onehot_31_104
 E  normalized_mass_31_105
 E  normalized_ratio_31_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 G  product_lb_131
 L  product_ub_132
 G  product_lb_133
 L  product_ub_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 E  onehot_3_143
 E  normalized_mass_3_144
 E  normalized_ratio_3_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 E  onehot_32_172
 E  normalized_mass_32_173
 E  normalized_ratio_32_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 E  onehot_4_207
 E  normalized_mass_4_208
 E  normalized_ratio_4_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 G  product_lb_218
 L  product_ub_219
 G  product_lb_220
 L  product_ub_221
 G  product_lb_222
 L  product_ub_223
 G  product_lb_224
 L  product_ub_225
 G  product_lb_226
 L  product_ub_227
 E  onehot_19_228
 E  normalized_mass_19_229
 E  normalized_ratio_19_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 G  product_lb_255
 L  product_ub_256
 G  product_lb_257
 L  product_ub_258
 G  product_lb_259
 L  product_ub_260
 G  product_lb_261
 L  product_ub_262
 G  product_lb_263
 L  product_ub_264
 E  onehot_5_265
 E  normalized_mass_5_266
 E  normalized_ratio_5_267
 G  stock_lb_268
 L  stock_ub_269
 L  parent_nonstrict_scope_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 G  block_pair_pos_317
 G  block_pair_neg_318
 G  block_pair_pos_319
 G  block_pair_neg_320
 G  block_pair_pos_321
 G  block_pair_neg_322
 G  block_pair_pos_323
 G  block_pair_neg_324
 G  block_pair_pos_325
 G  block_pair_neg_326
 E  normalization_327
 G  full_original_Gini_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 E  unique_nonzero_owner_428
 E  unique_nonzero_owner_429
 E  unique_nonzero_owner_430
 E  unique_nonzero_owner_431
 E  unique_nonzero_owner_432
 E  unique_nonzero_owner_433
 E  unique_nonzero_owner_434
 E  unique_nonzero_owner_435
 E  unique_nonzero_owner_436
 E  unique_nonzero_owner_437
 E  unique_nonzero_owner_438
 E  unique_nonzero_owner_439
 E  unique_nonzero_owner_440
 E  unique_nonzero_owner_441
 E  unique_nonzero_owner_442
 L  arc_capacity_443
 L  arc_capacity_444
 L  arc_capacity_445
 L  arc_capacity_446
 L  arc_capacity_447
 L  arc_capacity_448
 L  arc_capacity_449
 L  arc_capacity_450
 L  arc_capacity_451
 L  arc_capacity_452
 L  arc_capacity_453
 L  arc_capacity_454
 L  arc_capacity_455
 L  arc_capacity_456
 L  arc_capacity_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 L  arc_capacity_708
 G  connected_order_arc_709
 L  arc_capacity_710
 G  connected_order_arc_711
 L  arc_capacity_712
 G  connected_order_arc_713
 L  arc_capacity_714
 G  connected_order_arc_715
 L  arc_capacity_716
 G  connected_order_arc_717
 L  arc_capacity_718
 G  connected_order_arc_719
 L  arc_capacity_720
 G  connected_order_arc_721
 L  arc_capacity_722
 G  connected_order_arc_723
 L  arc_capacity_724
 G  connected_order_arc_725
 L  arc_capacity_726
 G  connected_order_arc_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 L  arc_capacity_733
 G  connected_order_arc_734
 L  arc_capacity_735
 G  connected_order_arc_736
 L  arc_capacity_737
 G  connected_order_arc_738
 L  arc_capacity_739
 G  connected_order_arc_740
 L  arc_capacity_741
 G  connected_order_arc_742
 L  arc_capacity_743
 G  connected_order_arc_744
 L  arc_capacity_745
 G  connected_order_arc_746
 L  arc_capacity_747
 G  connected_order_arc_748
 L  arc_capacity_749
 G  connected_order_arc_750
 L  arc_capacity_751
 G  connected_order_arc_752
 L  arc_capacity_753
 G  connected_order_arc_754
 L  arc_capacity_755
 G  connected_order_arc_756
 L  arc_capacity_757
 L  arc_capacity_758
 G  connected_order_arc_759
 L  arc_capacity_760
 G  connected_order_arc_761
 L  arc_capacity_762
 G  connected_order_arc_763
 L  arc_capacity_764
 G  connected_order_arc_765
 L  arc_capacity_766
 G  connected_order_arc_767
 L  arc_capacity_768
 G  connected_order_arc_769
 L  arc_capacity_770
 G  connected_order_arc_771
 L  arc_capacity_772
 G  connected_order_arc_773
 L  arc_capacity_774
 G  connected_order_arc_775
 L  arc_capacity_776
 G  connected_order_arc_777
 L  arc_capacity_778
 G  connected_order_arc_779
 L  arc_capacity_780
 G  connected_order_arc_781
 E  depot_departure_or_bypass_782
 E  depot_return_or_bypass_783
 E  out_degree_784
 E  in_degree_785
 G  order_active_lb_786
 L  order_active_ub_787
 E  segment_load_conservation_788
 G  segment_prefix_lb_789
 L  segment_prefix_ub_790
 E  out_degree_791
 E  in_degree_792
 G  order_active_lb_793
 L  order_active_ub_794
 E  segment_load_conservation_795
 G  segment_prefix_lb_796
 L  segment_prefix_ub_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  segment_load_conservation_802
 G  segment_prefix_lb_803
 L  segment_prefix_ub_804
 E  out_degree_805
 E  in_degree_806
 G  order_active_lb_807
 L  order_active_ub_808
 E  segment_load_conservation_809
 G  segment_prefix_lb_810
 L  segment_prefix_ub_811
 E  out_degree_812
 E  in_degree_813
 G  order_active_lb_814
 L  order_active_ub_815
 E  segment_load_conservation_816
 G  segment_prefix_lb_817
 L  segment_prefix_ub_818
 E  out_degree_819
 E  in_degree_820
 G  order_active_lb_821
 L  order_active_ub_822
 E  service_visit_def_823
 E  free_load_conservation_824
 E  out_degree_825
 E  in_degree_826
 G  order_active_lb_827
 L  order_active_ub_828
 E  service_visit_def_829
 E  free_load_conservation_830
 E  out_degree_831
 E  in_degree_832
 G  order_active_lb_833
 L  order_active_ub_834
 E  service_visit_def_835
 E  free_load_conservation_836
 E  out_degree_837
 E  in_degree_838
 G  order_active_lb_839
 L  order_active_ub_840
 E  service_visit_def_841
 E  free_load_conservation_842
 E  out_degree_843
 E  in_degree_844
 G  order_active_lb_845
 L  order_active_ub_846
 E  service_visit_def_847
 E  free_load_conservation_848
 E  out_degree_849
 E  in_degree_850
 G  order_active_lb_851
 L  order_active_ub_852
 E  service_visit_def_853
 E  free_load_conservation_854
 E  out_degree_855
 E  in_degree_856
 G  order_active_lb_857
 L  order_active_ub_858
 E  service_visit_def_859
 E  free_load_conservation_860
 E  out_degree_861
 E  in_degree_862
 G  order_active_lb_863
 L  order_active_ub_864
 E  service_visit_def_865
 E  free_load_conservation_866
 G  fixed_segment_relative_order_867
 G  fixed_segment_relative_order_868
 G  fixed_segment_relative_order_869
 G  fixed_segment_relative_order_870
 L  original_T_including_depot_unload_871
 L  arc_capacity_872
 L  arc_capacity_873
 L  arc_capacity_874
 L  arc_capacity_875
 L  arc_capacity_876
 L  arc_capacity_877
 L  arc_capacity_878
 L  arc_capacity_879
 L  arc_capacity_880
 L  arc_capacity_881
 L  arc_capacity_882
 L  arc_capacity_883
 L  arc_capacity_884
 L  arc_capacity_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 L  arc_capacity_1138
 L  arc_capacity_1139
 G  connected_order_arc_1140
 L  arc_capacity_1141
 G  connected_order_arc_1142
 L  arc_capacity_1143
 G  connected_order_arc_1144
 L  arc_capacity_1145
 G  connected_order_arc_1146
 L  arc_capacity_1147
 G  connected_order_arc_1148
 L  arc_capacity_1149
 G  connected_order_arc_1150
 L  arc_capacity_1151
 G  connected_order_arc_1152
 L  arc_capacity_1153
 G  connected_order_arc_1154
 L  arc_capacity_1155
 G  connected_order_arc_1156
 L  arc_capacity_1157
 G  connected_order_arc_1158
 L  arc_capacity_1159
 G  connected_order_arc_1160
 E  depot_departure_or_bypass_1161
 E  depot_return_or_bypass_1162
 E  out_degree_1163
 E  in_degree_1164
 G  order_active_lb_1165
 L  order_active_ub_1166
 E  segment_load_conservation_1167
 G  segment_prefix_lb_1168
 L  segment_prefix_ub_1169
 E  out_degree_1170
 E  in_degree_1171
 G  order_active_lb_1172
 L  order_active_ub_1173
 E  segment_load_conservation_1174
 G  segment_prefix_lb_1175
 L  segment_prefix_ub_1176
 E  out_degree_1177
 E  in_degree_1178
 G  order_active_lb_1179
 L  order_active_ub_1180
 E  segment_load_conservation_1181
 G  segment_prefix_lb_1182
 L  segment_prefix_ub_1183
 E  out_degree_1184
 E  in_degree_1185
 G  order_active_lb_1186
 L  order_active_ub_1187
 E  segment_load_conservation_1188
 G  segment_prefix_lb_1189
 L  segment_prefix_ub_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  service_visit_def_1195
 E  free_load_conservation_1196
 E  out_degree_1197
 E  in_degree_1198
 G  order_active_lb_1199
 L  order_active_ub_1200
 E  service_visit_def_1201
 E  free_load_conservation_1202
 E  out_degree_1203
 E  in_degree_1204
 G  order_active_lb_1205
 L  order_active_ub_1206
 E  service_visit_def_1207
 E  free_load_conservation_1208
 E  out_degree_1209
 E  in_degree_1210
 G  order_active_lb_1211
 L  order_active_ub_1212
 E  service_visit_def_1213
 E  free_load_conservation_1214
 E  out_degree_1215
 E  in_degree_1216
 G  order_active_lb_1217
 L  order_active_ub_1218
 E  service_visit_def_1219
 E  free_load_conservation_1220
 E  out_degree_1221
 E  in_degree_1222
 G  order_active_lb_1223
 L  order_active_ub_1224
 E  service_visit_def_1225
 E  free_load_conservation_1226
 E  out_degree_1227
 E  in_degree_1228
 G  order_active_lb_1229
 L  order_active_ub_1230
 E  service_visit_def_1231
 E  free_load_conservation_1232
 E  out_degree_1233
 E  in_degree_1234
 G  order_active_lb_1235
 L  order_active_ub_1236
 E  service_visit_def_1237
 E  free_load_conservation_1238
 G  fixed_segment_relative_order_1239
 G  fixed_segment_relative_order_1240
 G  fixed_segment_relative_order_1241
 L  original_T_including_depot_unload_1242
 L  arc_capacity_1243
 L  arc_capacity_1244
 L  arc_capacity_1245
 L  arc_capacity_1246
 L  arc_capacity_1247
 L  arc_capacity_1248
 L  arc_capacity_1249
 L  arc_capacity_1250
 L  arc_capacity_1251
 L  arc_capacity_1252
 L  arc_capacity_1253
 L  arc_capacity_1254
 L  arc_capacity_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 E  depot_departure_or_bypass_1486
 E  depot_return_or_bypass_1487
 E  out_degree_1488
 E  in_degree_1489
 G  order_active_lb_1490
 L  order_active_ub_1491
 E  segment_load_conservation_1492
 G  segment_prefix_lb_1493
 L  segment_prefix_ub_1494
 E  out_degree_1495
 E  in_degree_1496
 G  order_active_lb_1497
 L  order_active_ub_1498
 E  segment_load_conservation_1499
 G  segment_prefix_lb_1500
 L  segment_prefix_ub_1501
 E  out_degree_1502
 E  in_degree_1503
 G  order_active_lb_1504
 L  order_active_ub_1505
 E  segment_load_conservation_1506
 G  segment_prefix_lb_1507
 L  segment_prefix_ub_1508
 E  out_degree_1509
 E  in_degree_1510
 G  order_active_lb_1511
 L  order_active_ub_1512
 E  service_visit_def_1513
 E  free_load_conservation_1514
 E  out_degree_1515
 E  in_degree_1516
 G  order_active_lb_1517
 L  order_active_ub_1518
 E  service_visit_def_1519
 E  free_load_conservation_1520
 E  out_degree_1521
 E  in_degree_1522
 G  order_active_lb_1523
 L  order_active_ub_1524
 E  service_visit_def_1525
 E  free_load_conservation_1526
 E  out_degree_1527
 E  in_degree_1528
 G  order_active_lb_1529
 L  order_active_ub_1530
 E  service_visit_def_1531
 E  free_load_conservation_1532
 E  out_degree_1533
 E  in_degree_1534
 G  order_active_lb_1535
 L  order_active_ub_1536
 E  service_visit_def_1537
 E  free_load_conservation_1538
 E  out_degree_1539
 E  in_degree_1540
 G  order_active_lb_1541
 L  order_active_ub_1542
 E  service_visit_def_1543
 E  free_load_conservation_1544
 E  out_degree_1545
 E  in_degree_1546
 G  order_active_lb_1547
 L  order_active_ub_1548
 E  service_visit_def_1549
 E  free_load_conservation_1550
 E  out_degree_1551
 E  in_degree_1552
 G  order_active_lb_1553
 L  order_active_ub_1554
 E  service_visit_def_1555
 E  free_load_conservation_1556
 G  fixed_segment_relative_order_1557
 G  fixed_segment_relative_order_1558
 L  original_T_including_depot_unload_1559
COLUMNS
    t         normalized_mass_1_41  -1
    t         normalized_mass_2_76  -1
    t         normalized_mass_31_105  -1
    t         normalized_mass_3_144  -1
    t         normalized_mass_32_173  -1
    t         normalized_mass_4_208  -1
    t         normalized_mass_19_229  -1
    t         normalized_mass_5_266  -1
    t         normalization_327  2.3686904761904763e+01
    t         full_original_Gini_328  -7.7495238095238079e+01
    q         OBJ       1
    q         parent_nonstrict_scope_270  1
    q         full_original_Gini_328  35
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_0  -2.4930254644718940e-02
    x_1_0     product_ub_1  -4.2217419711556528e-02
    x_1_0     onehot_1_40  1
    x_1_0     parent_nonstrict_scope_270  0.15
    x_1_0     unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_0  1
    w_1_0     product_ub_1  1
    w_1_0     normalized_mass_1_41  1
    w_1_0     full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       6.0000000000000012e-02
    x_1_1     product_lb_2  -2.4930254644718940e-02
    x_1_1     product_ub_3  -4.2217419711556528e-02
    x_1_1     onehot_1_40  1
    x_1_1     stock_lb_268  1
    x_1_1     stock_ub_269  1
    x_1_1     parent_nonstrict_scope_270  0.135
    x_1_1     unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_2  1
    w_1_1     product_ub_3  1
    w_1_1     normalized_mass_1_41  1
    w_1_1     normalized_ratio_1_42  -0.1
    w_1_1     full_original_Gini_328  -2.1186904761904756e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.045
    x_1_2     product_lb_4  -2.4930254644718940e-02
    x_1_2     product_ub_5  -4.2217419711556528e-02
    x_1_2     onehot_1_40  1
    x_1_2     stock_lb_268  2
    x_1_2     stock_ub_269  2
    x_1_2     parent_nonstrict_scope_270  0.12
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_4  1
    w_1_2     product_ub_5  1
    w_1_2     normalized_mass_1_41  1
    w_1_2     normalized_ratio_1_42  -0.2
    w_1_2     full_original_Gini_328  -1.8686904761904767e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_3     OBJ       0.03
    x_1_3     product_lb_6  -2.4930254644718940e-02
    x_1_3     product_ub_7  -4.2217419711556528e-02
    x_1_3     onehot_1_40  1
    x_1_3     stock_lb_268  3
    x_1_3     stock_ub_269  3
    x_1_3     parent_nonstrict_scope_270  0.105
    x_1_3     unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_6  1
    w_1_3     product_ub_7  1
    w_1_3     normalized_mass_1_41  1
    w_1_3     normalized_ratio_1_42  -3.0000000000000004e-01
    w_1_3     full_original_Gini_328  -1.6186904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       0.015
    x_1_4     product_lb_8  -2.4930254644718940e-02
    x_1_4     product_ub_9  -4.2217419711556528e-02
    x_1_4     onehot_1_40  1
    x_1_4     stock_lb_268  4
    x_1_4     stock_ub_269  4
    x_1_4     parent_nonstrict_scope_270  0.09
    x_1_4     unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_8  1
    w_1_4     product_ub_9  1
    w_1_4     normalized_mass_1_41  1
    w_1_4     normalized_ratio_1_42  -0.4
    w_1_4     full_original_Gini_328  -1.3686904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_5     product_lb_10  -2.4930254644718940e-02
    x_1_5     product_ub_11  -4.2217419711556528e-02
    x_1_5     onehot_1_40  1
    x_1_5     stock_lb_268  5
    x_1_5     stock_ub_269  5
    x_1_5     parent_nonstrict_scope_270  0.075
    x_1_5     unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_10  1
    w_1_5     product_ub_11  1
    w_1_5     normalized_mass_1_41  1
    w_1_5     normalized_ratio_1_42  -0.5
    w_1_5     full_original_Gini_328  -1.1586904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -1.5000000000000013e-02
    x_1_6     product_lb_12  -2.4930254644718940e-02
    x_1_6     product_ub_13  -4.2217419711556528e-02
    x_1_6     onehot_1_40  1
    x_1_6     stock_lb_268  6
    x_1_6     stock_ub_269  6
    x_1_6     parent_nonstrict_scope_270  5.9999999999999984e-02
    x_1_6     unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_12  1
    w_1_6     product_ub_13  1
    w_1_6     normalized_mass_1_41  1
    w_1_6     normalized_ratio_1_42  -6.0000000000000009e-01
    w_1_6     full_original_Gini_328  -9.4869047619047624e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -3.0000000000000006e-02
    x_1_7     product_lb_14  -2.4930254644718940e-02
    x_1_7     product_ub_15  -4.2217419711556528e-02
    x_1_7     onehot_1_40  1
    x_1_7     stock_lb_268  7
    x_1_7     stock_ub_269  7
    x_1_7     parent_nonstrict_scope_270  4.4999999999999991e-02
    x_1_7     unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_14  1
    w_1_7     product_ub_15  1
    w_1_7     normalized_mass_1_41  1
    w_1_7     normalized_ratio_1_42  -7.0000000000000007e-01
    w_1_7     full_original_Gini_328  -7.3869047619047592e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -4.5000000000000005e-02
    x_1_8     product_lb_16  -2.4930254644718940e-02
    x_1_8     product_ub_17  -4.2217419711556528e-02
    x_1_8     onehot_1_40  1
    x_1_8     stock_lb_268  8
    x_1_8     stock_ub_269  8
    x_1_8     parent_nonstrict_scope_270  2.9999999999999992e-02
    x_1_8     unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_16  1
    w_1_8     product_ub_17  1
    w_1_8     normalized_mass_1_41  1
    w_1_8     normalized_ratio_1_42  -0.8
    w_1_8     full_original_Gini_328  -5.4583333333333348e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -0.06
    x_1_9     product_lb_18  -2.4930254644718940e-02
    x_1_9     product_ub_19  -4.2217419711556528e-02
    x_1_9     onehot_1_40  1
    x_1_9     stock_lb_268  9
    x_1_9     stock_ub_269  9
    x_1_9     parent_nonstrict_scope_270  1.4999999999999996e-02
    x_1_9     unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_18  1
    w_1_9     product_ub_19  1
    w_1_9     normalized_mass_1_41  1
    w_1_9     normalized_ratio_1_42  -0.9
    w_1_9     full_original_Gini_328  -4.21309523809524
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -0.075
    x_1_10    product_lb_20  -2.4930254644718940e-02
    x_1_10    product_ub_21  -4.2217419711556528e-02
    x_1_10    onehot_1_40  1
    x_1_10    stock_lb_268  10
    x_1_10    stock_ub_269  10
    x_1_10    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_20  1
    w_1_10    product_ub_21  1
    w_1_10    normalized_mass_1_41  1
    w_1_10    normalized_ratio_1_42  -1
    w_1_10    full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    OBJ       -5.9999999999999984e-02
    x_1_11    product_lb_22  -2.4930254644718940e-02
    x_1_11    product_ub_23  -4.2217419711556528e-02
    x_1_11    onehot_1_40  1
    x_1_11    stock_lb_268  11
    x_1_11    stock_ub_269  11
    x_1_11    parent_nonstrict_scope_270  1.5000000000000013e-02
    x_1_11    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_22  1
    w_1_11    product_ub_23  1
    w_1_11    normalized_mass_1_41  1
    w_1_11    normalized_ratio_1_42  -1.1
    w_1_11    full_original_Gini_328  -6.2130952380952387e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       -4.4999999999999971e-02
    x_1_12    product_lb_24  -2.4930254644718940e-02
    x_1_12    product_ub_25  -4.2217419711556528e-02
    x_1_12    onehot_1_40  1
    x_1_12    stock_lb_268  12
    x_1_12    stock_ub_269  12
    x_1_12    parent_nonstrict_scope_270  3.0000000000000027e-02
    x_1_12    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_24  1
    w_1_12    product_ub_25  1
    w_1_12    normalized_mass_1_41  1
    w_1_12    normalized_ratio_1_42  -1.2000000000000002e+00
    w_1_12    full_original_Gini_328  -8.7130952380952458e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       -2.9999999999999992e-02
    x_1_13    product_lb_26  -2.4930254644718940e-02
    x_1_13    product_ub_27  -4.2217419711556528e-02
    x_1_13    onehot_1_40  1
    x_1_13    stock_lb_268  13
    x_1_13    stock_ub_269  13
    x_1_13    parent_nonstrict_scope_270  4.5000000000000005e-02
    x_1_13    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_26  1
    w_1_13    product_ub_27  1
    w_1_13    normalized_mass_1_41  1
    w_1_13    normalized_ratio_1_42  -1.3
    w_1_13    full_original_Gini_328  -1.1413095238095242e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       -1.4999999999999979e-02
    x_1_14    product_lb_28  -2.4930254644718940e-02
    x_1_14    product_ub_29  -4.2217419711556528e-02
    x_1_14    onehot_1_40  1
    x_1_14    stock_lb_268  14
    x_1_14    stock_ub_269  14
    x_1_14    parent_nonstrict_scope_270  6.0000000000000019e-02
    x_1_14    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_28  1
    w_1_14    product_ub_29  1
    w_1_14    normalized_mass_1_41  1
    w_1_14    normalized_ratio_1_42  -1.4000000000000001e+00
    w_1_14    full_original_Gini_328  -1.4113095238095244e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    product_lb_30  -2.4930254644718940e-02
    x_1_15    product_ub_31  -4.2217419711556528e-02
    x_1_15    onehot_1_40  1
    x_1_15    stock_lb_268  15
    x_1_15    stock_ub_269  15
    x_1_15    parent_nonstrict_scope_270  0.075
    x_1_15    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_30  1
    w_1_15    product_ub_31  1
    w_1_15    normalized_mass_1_41  1
    w_1_15    normalized_ratio_1_42  -1.5
    w_1_15    full_original_Gini_328  -1.6813095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_16    OBJ       1.5000000000000013e-02
    x_1_16    product_lb_32  -2.4930254644718940e-02
    x_1_16    product_ub_33  -4.2217419711556528e-02
    x_1_16    onehot_1_40  1
    x_1_16    stock_lb_268  16
    x_1_16    stock_ub_269  16
    x_1_16    parent_nonstrict_scope_270  9.0000000000000011e-02
    x_1_16    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_16    product_lb_32  1
    w_1_16    product_ub_33  1
    w_1_16    normalized_mass_1_41  1
    w_1_16    normalized_ratio_1_42  -1.6
    w_1_16    full_original_Gini_328  -1.9513095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_17    OBJ       3.0000000000000027e-02
    x_1_17    product_lb_34  -2.4930254644718940e-02
    x_1_17    product_ub_35  -4.2217419711556528e-02
    x_1_17    onehot_1_40  1
    x_1_17    stock_lb_268  17
    x_1_17    stock_ub_269  17
    x_1_17    parent_nonstrict_scope_270  1.0500000000000002e-01
    x_1_17    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_17    product_lb_34  1
    w_1_17    product_ub_35  1
    w_1_17    normalized_mass_1_41  1
    w_1_17    normalized_ratio_1_42  -1.7000000000000002e+00
    w_1_17    full_original_Gini_328  -2.2213095238095235e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_18    OBJ       0.045
    x_1_18    product_lb_36  -2.4930254644718940e-02
    x_1_18    product_ub_37  -4.2217419711556528e-02
    x_1_18    onehot_1_40  1
    x_1_18    stock_lb_268  18
    x_1_18    stock_ub_269  18
    x_1_18    parent_nonstrict_scope_270  0.12
    x_1_18    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_18    product_lb_36  1
    w_1_18    product_ub_37  1
    w_1_18    normalized_mass_1_41  1
    w_1_18    normalized_ratio_1_42  -1.8
    w_1_18    full_original_Gini_328  -2.4913095238095245e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_19    OBJ       6.0000000000000012e-02
    x_1_19    product_lb_38  -2.4930254644718940e-02
    x_1_19    product_ub_39  -4.2217419711556528e-02
    x_1_19    onehot_1_40  1
    x_1_19    stock_lb_268  19
    x_1_19    stock_ub_269  19
    x_1_19    parent_nonstrict_scope_270  0.135
    x_1_19    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_19    product_lb_38  1
    w_1_19    product_ub_39  1
    w_1_19    normalized_mass_1_41  1
    w_1_19    normalized_ratio_1_42  -1.9000000000000001e+00
    w_1_19    full_original_Gini_328  -2.7613095238095237e+01
    rho_1     normalized_ratio_1_42  1
    rho_1     block_pair_pos_271  -1
    rho_1     block_pair_neg_272  1
    rho_1     block_pair_pos_273  -1
    rho_1     block_pair_neg_274  1
    rho_1     block_pair_pos_275  -1
    rho_1     block_pair_neg_276  1
    rho_1     block_pair_pos_277  -1
    rho_1     block_pair_neg_278  1
    rho_1     block_pair_pos_279  -1
    rho_1     block_pair_neg_280  1
    rho_1     block_pair_pos_281  -1
    rho_1     block_pair_neg_282  1
    rho_1     block_pair_pos_283  -1
    rho_1     block_pair_neg_284  1
    rho_1     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.0315
    x_2_0     product_lb_43  -2.4930254644718940e-02
    x_2_0     product_ub_44  -4.2217419711556528e-02
    x_2_0     onehot_2_75  1
    x_2_0     parent_nonstrict_scope_270  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_43  1
    w_2_0     product_ub_44  1
    w_2_0     normalized_mass_2_76  1
    w_2_0     full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       2.1000000000000005e-02
    x_2_1     product_lb_45  -2.4930254644718940e-02
    x_2_1     product_ub_46  -4.2217419711556528e-02
    x_2_1     onehot_2_75  1
    x_2_1     stock_lb_268  1
    x_2_1     stock_ub_269  1
    x_2_1     parent_nonstrict_scope_270  0.063
    x_2_1     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_45  1
    w_2_1     product_ub_46  1
    w_2_1     normalized_mass_2_76  1
    w_2_1     normalized_ratio_2_77  -1.4285714285714285e-01
    w_2_1     full_original_Gini_328  -2.0115476190476194e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       1.0500000000000002e-02
    x_2_2     product_lb_47  -2.4930254644718940e-02
    x_2_2     product_ub_48  -4.2217419711556528e-02
    x_2_2     onehot_2_75  1
    x_2_2     stock_lb_268  2
    x_2_2     stock_ub_269  2
    x_2_2     parent_nonstrict_scope_270  0.0525
    x_2_2     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_47  1
    w_2_2     product_ub_48  1
    w_2_2     normalized_mass_2_76  1
    w_2_2     normalized_ratio_2_77  -2.8571428571428570e-01
    w_2_2     full_original_Gini_328  -1.6544047619047614e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_3     product_lb_49  -2.4930254644718940e-02
    x_2_3     product_ub_50  -4.2217419711556528e-02
    x_2_3     onehot_2_75  1
    x_2_3     stock_lb_268  3
    x_2_3     stock_ub_269  3
    x_2_3     parent_nonstrict_scope_270  4.1999999999999996e-02
    x_2_3     unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_3     product_lb_49  1
    w_2_3     product_ub_50  1
    w_2_3     normalized_mass_2_76  1
    w_2_3     normalized_ratio_2_77  -4.2857142857142855e-01
    w_2_3     full_original_Gini_328  -1.3086904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_4     OBJ       -1.0499999999999995e-02
    x_2_4     product_lb_51  -2.4930254644718940e-02
    x_2_4     product_ub_52  -4.2217419711556528e-02
    x_2_4     onehot_2_75  1
    x_2_4     stock_lb_268  4
    x_2_4     stock_ub_269  4
    x_2_4     parent_nonstrict_scope_270  0.0315
    x_2_4     unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_4     product_lb_51  1
    w_2_4     product_ub_52  1
    w_2_4     normalized_mass_2_76  1
    w_2_4     normalized_ratio_2_77  -5.7142857142857140e-01
    w_2_4     full_original_Gini_328  -1.0086904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_5     OBJ       -2.0999999999999991e-02
    x_2_5     product_lb_53  -2.4930254644718940e-02
    x_2_5     product_ub_54  -4.2217419711556528e-02
    x_2_5     onehot_2_75  1
    x_2_5     stock_lb_268  5
    x_2_5     stock_ub_269  5
    x_2_5     parent_nonstrict_scope_270  2.1000000000000005e-02
    x_2_5     unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_5     product_lb_53  1
    w_2_5     product_ub_54  1
    w_2_5     normalized_mass_2_76  1
    w_2_5     normalized_ratio_2_77  -7.1428571428571419e-01
    w_2_5     full_original_Gini_328  -7.0869047619047620e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_6     OBJ       -3.1499999999999993e-02
    x_2_6     product_lb_55  -2.4930254644718940e-02
    x_2_6     product_ub_56  -4.2217419711556528e-02
    x_2_6     onehot_2_75  1
    x_2_6     stock_lb_268  6
    x_2_6     stock_ub_269  6
    x_2_6     parent_nonstrict_scope_270  1.0500000000000002e-02
    x_2_6     unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_6     product_lb_55  1
    w_2_6     product_ub_56  1
    w_2_6     normalized_mass_2_76  1
    w_2_6     normalized_ratio_2_77  -8.5714285714285710e-01
    w_2_6     full_original_Gini_328  -4.5345238095238090e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_7     OBJ       -4.1999999999999996e-02
    x_2_7     product_lb_57  -2.4930254644718940e-02
    x_2_7     product_ub_58  -4.2217419711556528e-02
    x_2_7     onehot_2_75  1
    x_2_7     stock_lb_268  7
    x_2_7     stock_ub_269  7
    x_2_7     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_7     product_lb_57  1
    w_2_7     product_ub_58  1
    w_2_7     normalized_mass_2_76  1
    w_2_7     normalized_ratio_2_77  -1
    w_2_7     full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_8     OBJ       -0.0315
    x_2_8     product_lb_59  -2.4930254644718940e-02
    x_2_8     product_ub_60  -4.2217419711556528e-02
    x_2_8     onehot_2_75  1
    x_2_8     stock_lb_268  8
    x_2_8     stock_ub_269  8
    x_2_8     parent_nonstrict_scope_270  1.0499999999999995e-02
    x_2_8     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_8     product_lb_59  1
    w_2_8     product_ub_60  1
    w_2_8     normalized_mass_2_76  1
    w_2_8     normalized_ratio_2_77  -1.1428571428571428e+00
    w_2_8     full_original_Gini_328  -7.2845238095238063e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_9     OBJ       -2.1000000000000005e-02
    x_2_9     product_lb_61  -2.4930254644718940e-02
    x_2_9     product_ub_62  -4.2217419711556528e-02
    x_2_9     onehot_2_75  1
    x_2_9     stock_lb_268  9
    x_2_9     stock_ub_269  9
    x_2_9     parent_nonstrict_scope_270  2.0999999999999991e-02
    x_2_9     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_9     product_lb_61  1
    w_2_9     product_ub_62  1
    w_2_9     normalized_mass_2_76  1
    w_2_9     normalized_ratio_2_77  -1.2857142857142856e+00
    w_2_9     full_original_Gini_328  -1.1027380952380948e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_10    OBJ       -1.0500000000000009e-02
    x_2_10    product_lb_63  -2.4930254644718940e-02
    x_2_10    product_ub_64  -4.2217419711556528e-02
    x_2_10    onehot_2_75  1
    x_2_10    stock_lb_268  10
    x_2_10    stock_ub_269  10
    x_2_10    parent_nonstrict_scope_270  3.1499999999999986e-02
    x_2_10    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_10    product_lb_63  1
    w_2_10    product_ub_64  1
    w_2_10    normalized_mass_2_76  1
    w_2_10    normalized_ratio_2_77  -1.4285714285714284e+00
    w_2_10    full_original_Gini_328  -1.4884523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_11    product_lb_65  -2.4930254644718940e-02
    x_2_11    product_ub_66  -4.2217419711556528e-02
    x_2_11    onehot_2_75  1
    x_2_11    stock_lb_268  11
    x_2_11    stock_ub_269  11
    x_2_11    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_2_11    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_11    product_lb_65  1
    w_2_11    product_ub_66  1
    w_2_11    normalized_mass_2_76  1
    w_2_11    normalized_ratio_2_77  -1.5714285714285714e+00
    w_2_11    full_original_Gini_328  -1.8741666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_12    OBJ       1.0499999999999995e-02
    x_2_12    product_lb_67  -2.4930254644718940e-02
    x_2_12    product_ub_68  -4.2217419711556528e-02
    x_2_12    onehot_2_75  1
    x_2_12    stock_lb_268  12
    x_2_12    stock_ub_269  12
    x_2_12    parent_nonstrict_scope_270  5.2499999999999991e-02
    x_2_12    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_12    product_lb_67  1
    w_2_12    product_ub_68  1
    w_2_12    normalized_mass_2_76  1
    w_2_12    normalized_ratio_2_77  -1.7142857142857142e+00
    w_2_12    full_original_Gini_328  -2.2598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_13    OBJ       2.0999999999999991e-02
    x_2_13    product_lb_69  -2.4930254644718940e-02
    x_2_13    product_ub_70  -4.2217419711556528e-02
    x_2_13    onehot_2_75  1
    x_2_13    stock_lb_268  13
    x_2_13    stock_ub_269  13
    x_2_13    parent_nonstrict_scope_270  6.2999999999999987e-02
    x_2_13    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_13    product_lb_69  1
    w_2_13    product_ub_70  1
    w_2_13    normalized_mass_2_76  1
    w_2_13    normalized_ratio_2_77  -1.8571428571428570e+00
    w_2_13    full_original_Gini_328  -2.6455952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_14    OBJ       0.0315
    x_2_14    product_lb_71  -2.4930254644718940e-02
    x_2_14    product_ub_72  -4.2217419711556528e-02
    x_2_14    onehot_2_75  1
    x_2_14    stock_lb_268  14
    x_2_14    stock_ub_269  14
    x_2_14    parent_nonstrict_scope_270  0.0735
    x_2_14    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_14    product_lb_71  1
    w_2_14    product_ub_72  1
    w_2_14    normalized_mass_2_76  1
    w_2_14    normalized_ratio_2_77  -2
    w_2_14    full_original_Gini_328  -3.0313095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_2_15    OBJ       4.1999999999999996e-02
    x_2_15    product_lb_73  -2.4930254644718940e-02
    x_2_15    product_ub_74  -4.2217419711556528e-02
    x_2_15    onehot_2_75  1
    x_2_15    stock_lb_268  15
    x_2_15    stock_ub_269  15
    x_2_15    parent_nonstrict_scope_270  8.3999999999999991e-02
    x_2_15    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_15    product_lb_73  1
    w_2_15    product_ub_74  1
    w_2_15    normalized_mass_2_76  1
    w_2_15    normalized_ratio_2_77  -2.1428571428571428e+00
    w_2_15    full_original_Gini_328  -3.4170238095238091e+01
    rho_2     normalized_ratio_2_77  1
    rho_2     block_pair_pos_271  1
    rho_2     block_pair_neg_272  -1
    rho_2     block_pair_pos_285  -1
    rho_2     block_pair_neg_286  1
    rho_2     block_pair_pos_287  -1
    rho_2     block_pair_neg_288  1
    rho_2     block_pair_pos_289  -1
    rho_2     block_pair_neg_290  1
    rho_2     block_pair_pos_291  -1
    rho_2     block_pair_neg_292  1
    rho_2     block_pair_pos_293  -1
    rho_2     block_pair_neg_294  1
    rho_2     block_pair_pos_295  -1
    rho_2     block_pair_neg_296  1
    rho_2     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_78  -2.4930254644718940e-02
    x_31_0    product_ub_79  -4.2217419711556528e-02
    x_31_0    onehot_31_104  1
    x_31_0    parent_nonstrict_scope_270  0.0735
    x_31_0    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_78  1
    w_31_0    product_ub_79  1
    w_31_0    normalized_mass_31_105  1
    w_31_0    full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_80  -2.4930254644718940e-02
    x_31_1    product_ub_81  -4.2217419711556528e-02
    x_31_1    onehot_31_104  1
    x_31_1    stock_lb_268  1
    x_31_1    stock_ub_269  1
    x_31_1    parent_nonstrict_scope_270  0.063
    x_31_1    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_80  1
    w_31_1    product_ub_81  1
    w_31_1    normalized_mass_31_105  1
    w_31_1    normalized_ratio_31_106  -1.4285714285714285e-01
    w_31_1    full_original_Gini_328  -2.0115476190476194e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_82  -2.4930254644718940e-02
    x_31_2    product_ub_83  -4.2217419711556528e-02
    x_31_2    onehot_31_104  1
    x_31_2    stock_lb_268  2
    x_31_2    stock_ub_269  2
    x_31_2    parent_nonstrict_scope_270  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_82  1
    w_31_2    product_ub_83  1
    w_31_2    normalized_mass_31_105  1
    w_31_2    normalized_ratio_31_106  -2.8571428571428570e-01
    w_31_2    full_original_Gini_328  -1.6544047619047614e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_84  -2.4930254644718940e-02
    x_31_3    product_ub_85  -4.2217419711556528e-02
    x_31_3    onehot_31_104  1
    x_31_3    stock_lb_268  3
    x_31_3    stock_ub_269  3
    x_31_3    parent_nonstrict_scope_270  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_84  1
    w_31_3    product_ub_85  1
    w_31_3    normalized_mass_31_105  1
    w_31_3    normalized_ratio_31_106  -4.2857142857142855e-01
    w_31_3    full_original_Gini_328  -1.3086904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_86  -2.4930254644718940e-02
    x_31_4    product_ub_87  -4.2217419711556528e-02
    x_31_4    onehot_31_104  1
    x_31_4    stock_lb_268  4
    x_31_4    stock_ub_269  4
    x_31_4    parent_nonstrict_scope_270  0.0315
    x_31_4    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_86  1
    w_31_4    product_ub_87  1
    w_31_4    normalized_mass_31_105  1
    w_31_4    normalized_ratio_31_106  -5.7142857142857140e-01
    w_31_4    full_original_Gini_328  -1.0086904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_88  -2.4930254644718940e-02
    x_31_5    product_ub_89  -4.2217419711556528e-02
    x_31_5    onehot_31_104  1
    x_31_5    stock_lb_268  5
    x_31_5    stock_ub_269  5
    x_31_5    parent_nonstrict_scope_270  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_88  1
    w_31_5    product_ub_89  1
    w_31_5    normalized_mass_31_105  1
    w_31_5    normalized_ratio_31_106  -7.1428571428571419e-01
    w_31_5    full_original_Gini_328  -7.0869047619047620e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_90  -2.4930254644718940e-02
    x_31_6    product_ub_91  -4.2217419711556528e-02
    x_31_6    onehot_31_104  1
    x_31_6    stock_lb_268  6
    x_31_6    stock_ub_269  6
    x_31_6    parent_nonstrict_scope_270  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_90  1
    w_31_6    product_ub_91  1
    w_31_6    normalized_mass_31_105  1
    w_31_6    normalized_ratio_31_106  -8.5714285714285710e-01
    w_31_6    full_original_Gini_328  -4.5345238095238090e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_92  -2.4930254644718940e-02
    x_31_7    product_ub_93  -4.2217419711556528e-02
    x_31_7    onehot_31_104  1
    x_31_7    stock_lb_268  7
    x_31_7    stock_ub_269  7
    x_31_7    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_92  1
    w_31_7    product_ub_93  1
    w_31_7    normalized_mass_31_105  1
    w_31_7    normalized_ratio_31_106  -1
    w_31_7    full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_94  -2.4930254644718940e-02
    x_31_8    product_ub_95  -4.2217419711556528e-02
    x_31_8    onehot_31_104  1
    x_31_8    stock_lb_268  8
    x_31_8    stock_ub_269  8
    x_31_8    parent_nonstrict_scope_270  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_94  1
    w_31_8    product_ub_95  1
    w_31_8    normalized_mass_31_105  1
    w_31_8    normalized_ratio_31_106  -1.1428571428571428e+00
    w_31_8    full_original_Gini_328  -7.2845238095238063e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_96  -2.4930254644718940e-02
    x_31_9    product_ub_97  -4.2217419711556528e-02
    x_31_9    onehot_31_104  1
    x_31_9    stock_lb_268  9
    x_31_9    stock_ub_269  9
    x_31_9    parent_nonstrict_scope_270  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_96  1
    w_31_9    product_ub_97  1
    w_31_9    normalized_mass_31_105  1
    w_31_9    normalized_ratio_31_106  -1.2857142857142856e+00
    w_31_9    full_original_Gini_328  -1.1027380952380948e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_98  -2.4930254644718940e-02
    x_31_10   product_ub_99  -4.2217419711556528e-02
    x_31_10   onehot_31_104  1
    x_31_10   stock_lb_268  10
    x_31_10   stock_ub_269  10
    x_31_10   parent_nonstrict_scope_270  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_98  1
    w_31_10   product_ub_99  1
    w_31_10   normalized_mass_31_105  1
    w_31_10   normalized_ratio_31_106  -1.4285714285714284e+00
    w_31_10   full_original_Gini_328  -1.4884523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_100  -2.4930254644718940e-02
    x_31_11   product_ub_101  -4.2217419711556528e-02
    x_31_11   onehot_31_104  1
    x_31_11   stock_lb_268  11
    x_31_11   stock_ub_269  11
    x_31_11   parent_nonstrict_scope_270  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_100  1
    w_31_11   product_ub_101  1
    w_31_11   normalized_mass_31_105  1
    w_31_11   normalized_ratio_31_106  -1.5714285714285714e+00
    w_31_11   full_original_Gini_328  -1.8741666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_102  -2.4930254644718940e-02
    x_31_12   product_ub_103  -4.2217419711556528e-02
    x_31_12   onehot_31_104  1
    x_31_12   stock_lb_268  12
    x_31_12   stock_ub_269  12
    x_31_12   parent_nonstrict_scope_270  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_102  1
    w_31_12   product_ub_103  1
    w_31_12   normalized_mass_31_105  1
    w_31_12   normalized_ratio_31_106  -1.7142857142857142e+00
    w_31_12   full_original_Gini_328  -2.2598809523809525e+01
    rho_31    normalized_ratio_31_106  1
    rho_31    block_pair_pos_281  1
    rho_31    block_pair_neg_282  -1
    rho_31    block_pair_pos_293  1
    rho_31    block_pair_neg_294  -1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    block_pair_pos_315  -1
    rho_31    block_pair_neg_316  1
    rho_31    block_pair_pos_317  -1
    rho_31    block_pair_neg_318  1
    rho_31    block_pair_pos_319  -1
    rho_31    block_pair_neg_320  1
    rho_31    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       0.042
    x_3_0     product_lb_107  -2.4930254644718940e-02
    x_3_0     product_ub_108  -4.2217419711556528e-02
    x_3_0     onehot_3_143  1
    x_3_0     parent_nonstrict_scope_270  0.096
    x_3_0     unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_107  1
    w_3_0     product_ub_108  1
    w_3_0     normalized_mass_3_144  1
    w_3_0     full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.0000000000000006e-02
    x_3_1     product_lb_109  -2.4930254644718940e-02
    x_3_1     product_ub_110  -4.2217419711556528e-02
    x_3_1     onehot_3_143  1
    x_3_1     stock_lb_268  1
    x_3_1     stock_ub_269  1
    x_3_1     parent_nonstrict_scope_270  0.084
    x_3_1     unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_109  1
    w_3_1     product_ub_110  1
    w_3_1     normalized_mass_3_144  1
    w_3_1     normalized_ratio_3_145  -0.125
    w_3_1     full_original_Gini_328  -2.0561904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       1.8000000000000009e-02
    x_3_2     product_lb_111  -2.4930254644718940e-02
    x_3_2     product_ub_112  -4.2217419711556528e-02
    x_3_2     onehot_3_143  1
    x_3_2     stock_lb_268  2
    x_3_2     stock_ub_269  2
    x_3_2     parent_nonstrict_scope_270  7.2000000000000008e-02
    x_3_2     unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_111  1
    w_3_2     product_ub_112  1
    w_3_2     normalized_mass_3_144  1
    w_3_2     normalized_ratio_3_145  -0.25
    w_3_2     full_original_Gini_328  -1.7436904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       5.9999999999999984e-03
    x_3_3     product_lb_113  -2.4930254644718940e-02
    x_3_3     product_ub_114  -4.2217419711556528e-02
    x_3_3     onehot_3_143  1
    x_3_3     stock_lb_268  3
    x_3_3     stock_ub_269  3
    x_3_3     parent_nonstrict_scope_270  0.06
    x_3_3     unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_113  1
    w_3_3     product_ub_114  1
    w_3_3     normalized_mass_3_144  1
    w_3_3     normalized_ratio_3_145  -0.375
    w_3_3     full_original_Gini_328  -1.4311904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_4     OBJ       -5.9999999999999984e-03
    x_3_4     product_lb_115  -2.4930254644718940e-02
    x_3_4     product_ub_116  -4.2217419711556528e-02
    x_3_4     onehot_3_143  1
    x_3_4     stock_lb_268  4
    x_3_4     stock_ub_269  4
    x_3_4     parent_nonstrict_scope_270  0.048
    x_3_4     unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_115  1
    w_3_4     product_ub_116  1
    w_3_4     normalized_mass_3_144  1
    w_3_4     normalized_ratio_3_145  -0.5
    w_3_4     full_original_Gini_328  -1.1586904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.7999999999999995e-02
    x_3_5     product_lb_117  -2.4930254644718940e-02
    x_3_5     product_ub_118  -4.2217419711556528e-02
    x_3_5     onehot_3_143  1
    x_3_5     stock_lb_268  5
    x_3_5     stock_ub_269  5
    x_3_5     parent_nonstrict_scope_270  3.6000000000000004e-02
    x_3_5     unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_117  1
    w_3_5     product_ub_118  1
    w_3_5     normalized_mass_3_144  1
    w_3_5     normalized_ratio_3_145  -0.625
    w_3_5     full_original_Gini_328  -8.96190476190476
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -0.03
    x_3_6     product_lb_119  -2.4930254644718940e-02
    x_3_6     product_ub_120  -4.2217419711556528e-02
    x_3_6     onehot_3_143  1
    x_3_6     stock_lb_268  6
    x_3_6     stock_ub_269  6
    x_3_6     parent_nonstrict_scope_270  0.024
    x_3_6     unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_119  1
    w_3_6     product_ub_120  1
    w_3_6     normalized_mass_3_144  1
    w_3_6     normalized_ratio_3_145  -0.75
    w_3_6     full_original_Gini_328  -6.4083333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -4.1999999999999996e-02
    x_3_7     product_lb_121  -2.4930254644718940e-02
    x_3_7     product_ub_122  -4.2217419711556528e-02
    x_3_7     onehot_3_143  1
    x_3_7     stock_lb_268  7
    x_3_7     stock_ub_269  7
    x_3_7     parent_nonstrict_scope_270  0.012
    x_3_7     unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_121  1
    w_3_7     product_ub_122  1
    w_3_7     normalized_mass_3_144  1
    w_3_7     normalized_ratio_3_145  -0.875
    w_3_7     full_original_Gini_328  -4.3380952380952378e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -0.054
    x_3_8     product_lb_123  -2.4930254644718940e-02
    x_3_8     product_ub_124  -4.2217419711556528e-02
    x_3_8     onehot_3_143  1
    x_3_8     stock_lb_268  8
    x_3_8     stock_ub_269  8
    x_3_8     unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_123  1
    w_3_8     product_ub_124  1
    w_3_8     normalized_mass_3_144  1
    w_3_8     normalized_ratio_3_145  -1
    w_3_8     full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -4.1999999999999996e-02
    x_3_9     product_lb_125  -2.4930254644718940e-02
    x_3_9     product_ub_126  -4.2217419711556528e-02
    x_3_9     onehot_3_143  1
    x_3_9     stock_lb_268  9
    x_3_9     stock_ub_269  9
    x_3_9     parent_nonstrict_scope_270  0.012
    x_3_9     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_125  1
    w_3_9     product_ub_126  1
    w_3_9     normalized_mass_3_144  1
    w_3_9     normalized_ratio_3_145  -1.125
    w_3_9     full_original_Gini_328  -6.83809523809524
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -0.03
    x_3_10    product_lb_127  -2.4930254644718940e-02
    x_3_10    product_ub_128  -4.2217419711556528e-02
    x_3_10    onehot_3_143  1
    x_3_10    stock_lb_268  10
    x_3_10    stock_ub_269  10
    x_3_10    parent_nonstrict_scope_270  0.024
    x_3_10    unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_127  1
    w_3_10    product_ub_128  1
    w_3_10    normalized_mass_3_144  1
    w_3_10    normalized_ratio_3_145  -1.25
    w_3_10    full_original_Gini_328  -1.0063095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.7999999999999995e-02
    x_3_11    product_lb_129  -2.4930254644718940e-02
    x_3_11    product_ub_130  -4.2217419711556528e-02
    x_3_11    onehot_3_143  1
    x_3_11    stock_lb_268  11
    x_3_11    stock_ub_269  11
    x_3_11    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_3_11    unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_129  1
    w_3_11    product_ub_130  1
    w_3_11    normalized_mass_3_144  1
    w_3_11    normalized_ratio_3_145  -1.375
    w_3_11    full_original_Gini_328  -1.3438095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_12    OBJ       -5.9999999999999984e-03
    x_3_12    product_lb_131  -2.4930254644718940e-02
    x_3_12    product_ub_132  -4.2217419711556528e-02
    x_3_12    onehot_3_143  1
    x_3_12    stock_lb_268  12
    x_3_12    stock_ub_269  12
    x_3_12    parent_nonstrict_scope_270  0.048
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_131  1
    w_3_12    product_ub_132  1
    w_3_12    normalized_mass_3_144  1
    w_3_12    normalized_ratio_3_145  -1.5
    w_3_12    full_original_Gini_328  -1.6813095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       5.9999999999999984e-03
    x_3_13    product_lb_133  -2.4930254644718940e-02
    x_3_13    product_ub_134  -4.2217419711556528e-02
    x_3_13    onehot_3_143  1
    x_3_13    stock_lb_268  13
    x_3_13    stock_ub_269  13
    x_3_13    parent_nonstrict_scope_270  0.06
    x_3_13    unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_133  1
    w_3_13    product_ub_134  1
    w_3_13    normalized_mass_3_144  1
    w_3_13    normalized_ratio_3_145  -1.625
    w_3_13    full_original_Gini_328  -2.0188095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       1.8000000000000009e-02
    x_3_14    product_lb_135  -2.4930254644718940e-02
    x_3_14    product_ub_136  -4.2217419711556528e-02
    x_3_14    onehot_3_143  1
    x_3_14    stock_lb_268  14
    x_3_14    stock_ub_269  14
    x_3_14    parent_nonstrict_scope_270  7.2000000000000008e-02
    x_3_14    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_135  1
    w_3_14    product_ub_136  1
    w_3_14    normalized_mass_3_144  1
    w_3_14    normalized_ratio_3_145  -1.75
    w_3_14    full_original_Gini_328  -2.3563095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.0000000000000006e-02
    x_3_15    product_lb_137  -2.4930254644718940e-02
    x_3_15    product_ub_138  -4.2217419711556528e-02
    x_3_15    onehot_3_143  1
    x_3_15    stock_lb_268  15
    x_3_15    stock_ub_269  15
    x_3_15    parent_nonstrict_scope_270  0.084
    x_3_15    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_137  1
    w_3_15    product_ub_138  1
    w_3_15    normalized_mass_3_144  1
    w_3_15    normalized_ratio_3_145  -1.875
    w_3_15    full_original_Gini_328  -2.6938095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       0.042
    x_3_16    product_lb_139  -2.4930254644718940e-02
    x_3_16    product_ub_140  -4.2217419711556528e-02
    x_3_16    onehot_3_143  1
    x_3_16    stock_lb_268  16
    x_3_16    stock_ub_269  16
    x_3_16    parent_nonstrict_scope_270  0.096
    x_3_16    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_139  1
    w_3_16    product_ub_140  1
    w_3_16    normalized_mass_3_144  1
    w_3_16    normalized_ratio_3_145  -2
    w_3_16    full_original_Gini_328  -3.0313095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_17    OBJ       0.054
    x_3_17    product_lb_141  -2.4930254644718940e-02
    x_3_17    product_ub_142  -4.2217419711556528e-02
    x_3_17    onehot_3_143  1
    x_3_17    stock_lb_268  17
    x_3_17    stock_ub_269  17
    x_3_17    parent_nonstrict_scope_270  0.108
    x_3_17    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_17    product_lb_141  1
    w_3_17    product_ub_142  1
    w_3_17    normalized_mass_3_144  1
    w_3_17    normalized_ratio_3_145  -2.125
    w_3_17    full_original_Gini_328  -3.3688095238095237e+01
    rho_3     normalized_ratio_3_145  1
    rho_3     block_pair_pos_273  1
    rho_3     block_pair_neg_274  -1
    rho_3     block_pair_pos_285  1
    rho_3     block_pair_neg_286  -1
    rho_3     block_pair_pos_297  -1
    rho_3     block_pair_neg_298  1
    rho_3     block_pair_pos_299  -1
    rho_3     block_pair_neg_300  1
    rho_3     block_pair_pos_301  -1
    rho_3     block_pair_neg_302  1
    rho_3     block_pair_pos_303  -1
    rho_3     block_pair_neg_304  1
    rho_3     block_pair_pos_311  1
    rho_3     block_pair_neg_312  -1
    rho_3     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_146  -2.4930254644718940e-02
    x_32_0    product_ub_147  -4.2217419711556528e-02
    x_32_0    onehot_32_172  1
    x_32_0    parent_nonstrict_scope_270  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_146  1
    w_32_0    product_ub_147  1
    w_32_0    normalized_mass_32_173  1
    w_32_0    full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_148  -2.4930254644718940e-02
    x_32_1    product_ub_149  -4.2217419711556528e-02
    x_32_1    onehot_32_172  1
    x_32_1    stock_lb_268  1
    x_32_1    stock_ub_269  1
    x_32_1    parent_nonstrict_scope_270  0.03
    x_32_1    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_148  1
    w_32_1    product_ub_149  1
    w_32_1    normalized_mass_32_173  1
    w_32_1    normalized_ratio_32_174  -0.2
    w_32_1    full_original_Gini_328  -1.8686904761904767e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_150  -2.4930254644718940e-02
    x_32_2    product_ub_151  -4.2217419711556528e-02
    x_32_2    onehot_32_172  1
    x_32_2    stock_lb_268  2
    x_32_2    stock_ub_269  2
    x_32_2    parent_nonstrict_scope_270  0.0225
    x_32_2    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_150  1
    w_32_2    product_ub_151  1
    w_32_2    normalized_mass_32_173  1
    w_32_2    normalized_ratio_32_174  -0.4
    w_32_2    full_original_Gini_328  -1.3686904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_152  -2.4930254644718940e-02
    x_32_3    product_ub_153  -4.2217419711556528e-02
    x_32_3    onehot_32_172  1
    x_32_3    stock_lb_268  3
    x_32_3    stock_ub_269  3
    x_32_3    parent_nonstrict_scope_270  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_152  1
    w_32_3    product_ub_153  1
    w_32_3    normalized_mass_32_173  1
    w_32_3    normalized_ratio_32_174  -6.0000000000000009e-01
    w_32_3    full_original_Gini_328  -9.4869047619047624e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_154  -2.4930254644718940e-02
    x_32_4    product_ub_155  -4.2217419711556528e-02
    x_32_4    onehot_32_172  1
    x_32_4    stock_lb_268  4
    x_32_4    stock_ub_269  4
    x_32_4    parent_nonstrict_scope_270  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_154  1
    w_32_4    product_ub_155  1
    w_32_4    normalized_mass_32_173  1
    w_32_4    normalized_ratio_32_174  -0.8
    w_32_4    full_original_Gini_328  -5.4583333333333348e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_156  -2.4930254644718940e-02
    x_32_5    product_ub_157  -4.2217419711556528e-02
    x_32_5    onehot_32_172  1
    x_32_5    stock_lb_268  5
    x_32_5    stock_ub_269  5
    x_32_5    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_156  1
    w_32_5    product_ub_157  1
    w_32_5    normalized_mass_32_173  1
    w_32_5    normalized_ratio_32_174  -1
    w_32_5    full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_158  -2.4930254644718940e-02
    x_32_6    product_ub_159  -4.2217419711556528e-02
    x_32_6    onehot_32_172  1
    x_32_6    stock_lb_268  6
    x_32_6    stock_ub_269  6
    x_32_6    parent_nonstrict_scope_270  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_158  1
    w_32_6    product_ub_159  1
    w_32_6    normalized_mass_32_173  1
    w_32_6    normalized_ratio_32_174  -1.2000000000000002e+00
    w_32_6    full_original_Gini_328  -8.7130952380952458e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_160  -2.4930254644718940e-02
    x_32_7    product_ub_161  -4.2217419711556528e-02
    x_32_7    onehot_32_172  1
    x_32_7    stock_lb_268  7
    x_32_7    stock_ub_269  7
    x_32_7    parent_nonstrict_scope_270  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_160  1
    w_32_7    product_ub_161  1
    w_32_7    normalized_mass_32_173  1
    w_32_7    normalized_ratio_32_174  -1.4000000000000001e+00
    w_32_7    full_original_Gini_328  -1.4113095238095244e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_162  -2.4930254644718940e-02
    x_32_8    product_ub_163  -4.2217419711556528e-02
    x_32_8    onehot_32_172  1
    x_32_8    stock_lb_268  8
    x_32_8    stock_ub_269  8
    x_32_8    parent_nonstrict_scope_270  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_162  1
    w_32_8    product_ub_163  1
    w_32_8    normalized_mass_32_173  1
    w_32_8    normalized_ratio_32_174  -1.6
    w_32_8    full_original_Gini_328  -1.9513095238095239e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_164  -2.4930254644718940e-02
    x_32_9    product_ub_165  -4.2217419711556528e-02
    x_32_9    onehot_32_172  1
    x_32_9    stock_lb_268  9
    x_32_9    stock_ub_269  9
    x_32_9    parent_nonstrict_scope_270  0.03
    x_32_9    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_164  1
    w_32_9    product_ub_165  1
    w_32_9    normalized_mass_32_173  1
    w_32_9    normalized_ratio_32_174  -1.8
    w_32_9    full_original_Gini_328  -2.4913095238095245e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_166  -2.4930254644718940e-02
    x_32_10   product_ub_167  -4.2217419711556528e-02
    x_32_10   onehot_32_172  1
    x_32_10   stock_lb_268  10
    x_32_10   stock_ub_269  10
    x_32_10   parent_nonstrict_scope_270  0.0375
    x_32_10   unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_166  1
    w_32_10   product_ub_167  1
    w_32_10   normalized_mass_32_173  1
    w_32_10   normalized_ratio_32_174  -2
    w_32_10   full_original_Gini_328  -3.0313095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_168  -2.4930254644718940e-02
    x_32_11   product_ub_169  -4.2217419711556528e-02
    x_32_11   onehot_32_172  1
    x_32_11   stock_lb_268  11
    x_32_11   stock_ub_269  11
    x_32_11   parent_nonstrict_scope_270  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_168  1
    w_32_11   product_ub_169  1
    w_32_11   normalized_mass_32_173  1
    w_32_11   normalized_ratio_32_174  -2.2
    w_32_11   full_original_Gini_328  -3.5713095238095228e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_170  -2.4930254644718940e-02
    x_32_12   product_ub_171  -4.2217419711556528e-02
    x_32_12   onehot_32_172  1
    x_32_12   stock_lb_268  12
    x_32_12   stock_ub_269  12
    x_32_12   parent_nonstrict_scope_270  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_170  1
    w_32_12   product_ub_171  1
    w_32_12   normalized_mass_32_173  1
    w_32_12   normalized_ratio_32_174  -2.4000000000000004e+00
    w_32_12   full_original_Gini_328  -4.1113095238095234e+01
    rho_32    normalized_ratio_32_174  1
    rho_32    block_pair_pos_283  1
    rho_32    block_pair_neg_284  -1
    rho_32    block_pair_pos_295  1
    rho_32    block_pair_neg_296  -1
    rho_32    block_pair_pos_303  1
    rho_32    block_pair_neg_304  -1
    rho_32    block_pair_pos_319  1
    rho_32    block_pair_neg_320  -1
    rho_32    block_pair_pos_321  -1
    rho_32    block_pair_neg_322  1
    rho_32    block_pair_pos_323  -1
    rho_32    block_pair_neg_324  1
    rho_32    block_pair_pos_325  -1
    rho_32    block_pair_neg_326  1
    rho_32    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       0.0315
    x_4_0     product_lb_175  -2.4930254644718940e-02
    x_4_0     product_ub_176  -4.2217419711556528e-02
    x_4_0     onehot_4_207  1
    x_4_0     parent_nonstrict_scope_270  0.0735
    x_4_0     unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_175  1
    w_4_0     product_ub_176  1
    w_4_0     normalized_mass_4_208  1
    w_4_0     full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       2.1000000000000005e-02
    x_4_1     product_lb_177  -2.4930254644718940e-02
    x_4_1     product_ub_178  -4.2217419711556528e-02
    x_4_1     onehot_4_207  1
    x_4_1     stock_lb_268  1
    x_4_1     stock_ub_269  1
    x_4_1     parent_nonstrict_scope_270  0.063
    x_4_1     unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_177  1
    w_4_1     product_ub_178  1
    w_4_1     normalized_mass_4_208  1
    w_4_1     normalized_ratio_4_209  -1.4285714285714285e-01
    w_4_1     full_original_Gini_328  -2.0115476190476194e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       1.0500000000000002e-02
    x_4_2     product_lb_179  -2.4930254644718940e-02
    x_4_2     product_ub_180  -4.2217419711556528e-02
    x_4_2     onehot_4_207  1
    x_4_2     stock_lb_268  2
    x_4_2     stock_ub_269  2
    x_4_2     parent_nonstrict_scope_270  0.0525
    x_4_2     unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_179  1
    w_4_2     product_ub_180  1
    w_4_2     normalized_mass_4_208  1
    w_4_2     normalized_ratio_4_209  -2.8571428571428570e-01
    w_4_2     full_original_Gini_328  -1.6544047619047614e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_3     product_lb_181  -2.4930254644718940e-02
    x_4_3     product_ub_182  -4.2217419711556528e-02
    x_4_3     onehot_4_207  1
    x_4_3     stock_lb_268  3
    x_4_3     stock_ub_269  3
    x_4_3     parent_nonstrict_scope_270  4.1999999999999996e-02
    x_4_3     unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_181  1
    w_4_3     product_ub_182  1
    w_4_3     normalized_mass_4_208  1
    w_4_3     normalized_ratio_4_209  -4.2857142857142855e-01
    w_4_3     full_original_Gini_328  -1.3086904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_4     OBJ       -1.0499999999999995e-02
    x_4_4     product_lb_183  -2.4930254644718940e-02
    x_4_4     product_ub_184  -4.2217419711556528e-02
    x_4_4     onehot_4_207  1
    x_4_4     stock_lb_268  4
    x_4_4     stock_ub_269  4
    x_4_4     parent_nonstrict_scope_270  0.0315
    x_4_4     unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_183  1
    w_4_4     product_ub_184  1
    w_4_4     normalized_mass_4_208  1
    w_4_4     normalized_ratio_4_209  -5.7142857142857140e-01
    w_4_4     full_original_Gini_328  -1.0086904761904764e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -2.0999999999999991e-02
    x_4_5     product_lb_185  -2.4930254644718940e-02
    x_4_5     product_ub_186  -4.2217419711556528e-02
    x_4_5     onehot_4_207  1
    x_4_5     stock_lb_268  5
    x_4_5     stock_ub_269  5
    x_4_5     parent_nonstrict_scope_270  2.1000000000000005e-02
    x_4_5     unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_185  1
    w_4_5     product_ub_186  1
    w_4_5     normalized_mass_4_208  1
    w_4_5     normalized_ratio_4_209  -7.1428571428571419e-01
    w_4_5     full_original_Gini_328  -7.0869047619047620e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -3.1499999999999993e-02
    x_4_6     product_lb_187  -2.4930254644718940e-02
    x_4_6     product_ub_188  -4.2217419711556528e-02
    x_4_6     onehot_4_207  1
    x_4_6     stock_lb_268  6
    x_4_6     stock_ub_269  6
    x_4_6     parent_nonstrict_scope_270  1.0500000000000002e-02
    x_4_6     unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_187  1
    w_4_6     product_ub_188  1
    w_4_6     normalized_mass_4_208  1
    w_4_6     normalized_ratio_4_209  -8.5714285714285710e-01
    w_4_6     full_original_Gini_328  -4.5345238095238090e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -4.1999999999999996e-02
    x_4_7     product_lb_189  -2.4930254644718940e-02
    x_4_7     product_ub_190  -4.2217419711556528e-02
    x_4_7     onehot_4_207  1
    x_4_7     stock_lb_268  7
    x_4_7     stock_ub_269  7
    x_4_7     unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_189  1
    w_4_7     product_ub_190  1
    w_4_7     normalized_mass_4_208  1
    w_4_7     normalized_ratio_4_209  -1
    w_4_7     full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -0.0315
    x_4_8     product_lb_191  -2.4930254644718940e-02
    x_4_8     product_ub_192  -4.2217419711556528e-02
    x_4_8     onehot_4_207  1
    x_4_8     stock_lb_268  8
    x_4_8     stock_ub_269  8
    x_4_8     parent_nonstrict_scope_270  1.0499999999999995e-02
    x_4_8     unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_191  1
    w_4_8     product_ub_192  1
    w_4_8     normalized_mass_4_208  1
    w_4_8     normalized_ratio_4_209  -1.1428571428571428e+00
    w_4_8     full_original_Gini_328  -7.2845238095238063e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -2.1000000000000005e-02
    x_4_9     product_lb_193  -2.4930254644718940e-02
    x_4_9     product_ub_194  -4.2217419711556528e-02
    x_4_9     onehot_4_207  1
    x_4_9     stock_lb_268  9
    x_4_9     stock_ub_269  9
    x_4_9     parent_nonstrict_scope_270  2.0999999999999991e-02
    x_4_9     unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_193  1
    w_4_9     product_ub_194  1
    w_4_9     normalized_mass_4_208  1
    w_4_9     normalized_ratio_4_209  -1.2857142857142856e+00
    w_4_9     full_original_Gini_328  -1.1027380952380948e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -1.0500000000000009e-02
    x_4_10    product_lb_195  -2.4930254644718940e-02
    x_4_10    product_ub_196  -4.2217419711556528e-02
    x_4_10    onehot_4_207  1
    x_4_10    stock_lb_268  10
    x_4_10    stock_ub_269  10
    x_4_10    parent_nonstrict_scope_270  3.1499999999999986e-02
    x_4_10    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_195  1
    w_4_10    product_ub_196  1
    w_4_10    normalized_mass_4_208  1
    w_4_10    normalized_ratio_4_209  -1.4285714285714284e+00
    w_4_10    full_original_Gini_328  -1.4884523809523809e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_11    product_lb_197  -2.4930254644718940e-02
    x_4_11    product_ub_198  -4.2217419711556528e-02
    x_4_11    onehot_4_207  1
    x_4_11    stock_lb_268  11
    x_4_11    stock_ub_269  11
    x_4_11    parent_nonstrict_scope_270  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_197  1
    w_4_11    product_ub_198  1
    w_4_11    normalized_mass_4_208  1
    w_4_11    normalized_ratio_4_209  -1.5714285714285714e+00
    w_4_11    full_original_Gini_328  -1.8741666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_12    OBJ       1.0499999999999995e-02
    x_4_12    product_lb_199  -2.4930254644718940e-02
    x_4_12    product_ub_200  -4.2217419711556528e-02
    x_4_12    onehot_4_207  1
    x_4_12    stock_lb_268  12
    x_4_12    stock_ub_269  12
    x_4_12    parent_nonstrict_scope_270  5.2499999999999991e-02
    x_4_12    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_199  1
    w_4_12    product_ub_200  1
    w_4_12    normalized_mass_4_208  1
    w_4_12    normalized_ratio_4_209  -1.7142857142857142e+00
    w_4_12    full_original_Gini_328  -2.2598809523809525e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       2.0999999999999991e-02
    x_4_13    product_lb_201  -2.4930254644718940e-02
    x_4_13    product_ub_202  -4.2217419711556528e-02
    x_4_13    onehot_4_207  1
    x_4_13    stock_lb_268  13
    x_4_13    stock_ub_269  13
    x_4_13    parent_nonstrict_scope_270  6.2999999999999987e-02
    x_4_13    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_201  1
    w_4_13    product_ub_202  1
    w_4_13    normalized_mass_4_208  1
    w_4_13    normalized_ratio_4_209  -1.8571428571428570e+00
    w_4_13    full_original_Gini_328  -2.6455952380952382e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       0.0315
    x_4_14    product_lb_203  -2.4930254644718940e-02
    x_4_14    product_ub_204  -4.2217419711556528e-02
    x_4_14    onehot_4_207  1
    x_4_14    stock_lb_268  14
    x_4_14    stock_ub_269  14
    x_4_14    parent_nonstrict_scope_270  0.0735
    x_4_14    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_203  1
    w_4_14    product_ub_204  1
    w_4_14    normalized_mass_4_208  1
    w_4_14    normalized_ratio_4_209  -2
    w_4_14    full_original_Gini_328  -3.0313095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       4.1999999999999996e-02
    x_4_15    product_lb_205  -2.4930254644718940e-02
    x_4_15    product_ub_206  -4.2217419711556528e-02
    x_4_15    onehot_4_207  1
    x_4_15    stock_lb_268  15
    x_4_15    stock_ub_269  15
    x_4_15    parent_nonstrict_scope_270  8.3999999999999991e-02
    x_4_15    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_205  1
    w_4_15    product_ub_206  1
    w_4_15    normalized_mass_4_208  1
    w_4_15    normalized_ratio_4_209  -2.1428571428571428e+00
    w_4_15    full_original_Gini_328  -3.4170238095238091e+01
    rho_4     normalized_ratio_4_209  1
    rho_4     block_pair_pos_275  1
    rho_4     block_pair_neg_276  -1
    rho_4     block_pair_pos_287  1
    rho_4     block_pair_neg_288  -1
    rho_4     block_pair_pos_297  1
    rho_4     block_pair_neg_298  -1
    rho_4     block_pair_pos_305  -1
    rho_4     block_pair_neg_306  1
    rho_4     block_pair_pos_307  -1
    rho_4     block_pair_neg_308  1
    rho_4     block_pair_pos_313  1
    rho_4     block_pair_neg_314  -1
    rho_4     block_pair_pos_321  1
    rho_4     block_pair_neg_322  -1
    rho_4     normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_210  -2.4930254644718940e-02
    x_19_0    product_ub_211  -4.2217419711556528e-02
    x_19_0    onehot_19_228  1
    x_19_0    parent_nonstrict_scope_270  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_210  1
    w_19_0    product_ub_211  1
    w_19_0    normalized_mass_19_229  1
    w_19_0    full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_212  -2.4930254644718940e-02
    x_19_1    product_ub_213  -4.2217419711556528e-02
    x_19_1    onehot_19_228  1
    x_19_1    stock_lb_268  1
    x_19_1    stock_ub_269  1
    x_19_1    parent_nonstrict_scope_270  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_212  1
    w_19_1    product_ub_213  1
    w_19_1    normalized_mass_19_229  1
    w_19_1    normalized_ratio_19_230  -0.25
    w_19_1    full_original_Gini_328  -1.7436904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_214  -2.4930254644718940e-02
    x_19_2    product_ub_215  -4.2217419711556528e-02
    x_19_2    onehot_19_228  1
    x_19_2    stock_lb_268  2
    x_19_2    stock_ub_269  2
    x_19_2    parent_nonstrict_scope_270  0.012
    x_19_2    unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_214  1
    w_19_2    product_ub_215  1
    w_19_2    normalized_mass_19_229  1
    w_19_2    normalized_ratio_19_230  -0.5
    w_19_2    full_original_Gini_328  -1.1586904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_216  -2.4930254644718940e-02
    x_19_3    product_ub_217  -4.2217419711556528e-02
    x_19_3    onehot_19_228  1
    x_19_3    stock_lb_268  3
    x_19_3    stock_ub_269  3
    x_19_3    parent_nonstrict_scope_270  0.006
    x_19_3    unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_216  1
    w_19_3    product_ub_217  1
    w_19_3    normalized_mass_19_229  1
    w_19_3    normalized_ratio_19_230  -0.75
    w_19_3    full_original_Gini_328  -6.4083333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_218  -2.4930254644718940e-02
    x_19_4    product_ub_219  -4.2217419711556528e-02
    x_19_4    onehot_19_228  1
    x_19_4    stock_lb_268  4
    x_19_4    stock_ub_269  4
    x_19_4    unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_218  1
    w_19_4    product_ub_219  1
    w_19_4    normalized_mass_19_229  1
    w_19_4    normalized_ratio_19_230  -1
    w_19_4    full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_220  -2.4930254644718940e-02
    x_19_5    product_ub_221  -4.2217419711556528e-02
    x_19_5    onehot_19_228  1
    x_19_5    stock_lb_268  5
    x_19_5    stock_ub_269  5
    x_19_5    parent_nonstrict_scope_270  0.006
    x_19_5    unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_220  1
    w_19_5    product_ub_221  1
    w_19_5    normalized_mass_19_229  1
    w_19_5    normalized_ratio_19_230  -1.25
    w_19_5    full_original_Gini_328  -1.0063095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_222  -2.4930254644718940e-02
    x_19_6    product_ub_223  -4.2217419711556528e-02
    x_19_6    onehot_19_228  1
    x_19_6    stock_lb_268  6
    x_19_6    stock_ub_269  6
    x_19_6    parent_nonstrict_scope_270  0.012
    x_19_6    unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_222  1
    w_19_6    product_ub_223  1
    w_19_6    normalized_mass_19_229  1
    w_19_6    normalized_ratio_19_230  -1.5
    w_19_6    full_original_Gini_328  -1.6813095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_224  -2.4930254644718940e-02
    x_19_7    product_ub_225  -4.2217419711556528e-02
    x_19_7    onehot_19_228  1
    x_19_7    stock_lb_268  7
    x_19_7    stock_ub_269  7
    x_19_7    parent_nonstrict_scope_270  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_224  1
    w_19_7    product_ub_225  1
    w_19_7    normalized_mass_19_229  1
    w_19_7    normalized_ratio_19_230  -1.75
    w_19_7    full_original_Gini_328  -2.3563095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_226  -2.4930254644718940e-02
    x_19_8    product_ub_227  -4.2217419711556528e-02
    x_19_8    onehot_19_228  1
    x_19_8    stock_lb_268  8
    x_19_8    stock_ub_269  8
    x_19_8    parent_nonstrict_scope_270  0.024
    x_19_8    unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_226  1
    w_19_8    product_ub_227  1
    w_19_8    normalized_mass_19_229  1
    w_19_8    normalized_ratio_19_230  -2
    w_19_8    full_original_Gini_328  -3.0313095238095240e+01
    rho_19    normalized_ratio_19_230  1
    rho_19    block_pair_pos_279  1
    rho_19    block_pair_neg_280  -1
    rho_19    block_pair_pos_291  1
    rho_19    block_pair_neg_292  -1
    rho_19    block_pair_pos_301  1
    rho_19    block_pair_neg_302  -1
    rho_19    block_pair_pos_307  1
    rho_19    block_pair_neg_308  -1
    rho_19    block_pair_pos_309  -1
    rho_19    block_pair_neg_310  1
    rho_19    block_pair_pos_317  1
    rho_19    block_pair_neg_318  -1
    rho_19    block_pair_pos_325  1
    rho_19    block_pair_neg_326  -1
    rho_19    normalization_327  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       0.048
    x_5_0     product_lb_231  -2.4930254644718940e-02
    x_5_0     product_ub_232  -4.2217419711556528e-02
    x_5_0     onehot_5_265  1
    x_5_0     parent_nonstrict_scope_270  0.096
    x_5_0     unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_231  1
    w_5_0     product_ub_232  1
    w_5_0     normalized_mass_5_266  1
    w_5_0     full_original_Gini_328  -2.3686904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       3.6000000000000004e-02
    x_5_1     product_lb_233  -2.4930254644718940e-02
    x_5_1     product_ub_234  -4.2217419711556528e-02
    x_5_1     onehot_5_265  1
    x_5_1     stock_lb_268  1
    x_5_1     stock_ub_269  1
    x_5_1     parent_nonstrict_scope_270  0.084
    x_5_1     unique_nonzero_owner_428  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_233  1
    w_5_1     product_ub_234  1
    w_5_1     normalized_mass_5_266  1
    w_5_1     normalized_ratio_5_267  -0.125
    w_5_1     full_original_Gini_328  -2.0561904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       2.4000000000000007e-02
    x_5_2     product_lb_235  -2.4930254644718940e-02
    x_5_2     product_ub_236  -4.2217419711556528e-02
    x_5_2     onehot_5_265  1
    x_5_2     stock_lb_268  2
    x_5_2     stock_ub_269  2
    x_5_2     parent_nonstrict_scope_270  7.2000000000000008e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_235  1
    w_5_2     product_ub_236  1
    w_5_2     normalized_mass_5_266  1
    w_5_2     normalized_ratio_5_267  -0.25
    w_5_2     full_original_Gini_328  -1.7436904761904760e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_3     OBJ       1.1999999999999997e-02
    x_5_3     product_lb_237  -2.4930254644718940e-02
    x_5_3     product_ub_238  -4.2217419711556528e-02
    x_5_3     onehot_5_265  1
    x_5_3     stock_lb_268  3
    x_5_3     stock_ub_269  3
    x_5_3     parent_nonstrict_scope_270  0.06
    x_5_3     unique_nonzero_owner_429  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_3     product_lb_237  1
    w_5_3     product_ub_238  1
    w_5_3     normalized_mass_5_266  1
    w_5_3     normalized_ratio_5_267  -0.375
    w_5_3     full_original_Gini_328  -1.4311904761904763e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_4     product_lb_239  -2.4930254644718940e-02
    x_5_4     product_ub_240  -4.2217419711556528e-02
    x_5_4     onehot_5_265  1
    x_5_4     stock_lb_268  4
    x_5_4     stock_ub_269  4
    x_5_4     parent_nonstrict_scope_270  0.048
    x_5_4     unique_nonzero_owner_430  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_4     product_lb_239  1
    w_5_4     product_ub_240  1
    w_5_4     normalized_mass_5_266  1
    w_5_4     normalized_ratio_5_267  -0.5
    w_5_4     full_original_Gini_328  -1.1586904761904762e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_5     OBJ       -1.1999999999999997e-02
    x_5_5     product_lb_241  -2.4930254644718940e-02
    x_5_5     product_ub_242  -4.2217419711556528e-02
    x_5_5     onehot_5_265  1
    x_5_5     stock_lb_268  5
    x_5_5     stock_ub_269  5
    x_5_5     parent_nonstrict_scope_270  3.6000000000000004e-02
    x_5_5     unique_nonzero_owner_431  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_5     product_lb_241  1
    w_5_5     product_ub_242  1
    w_5_5     normalized_mass_5_266  1
    w_5_5     normalized_ratio_5_267  -0.625
    w_5_5     full_original_Gini_328  -8.96190476190476
    MARKER    'MARKER'                 'INTORG'
    x_5_6     OBJ       -0.024
    x_5_6     product_lb_243  -2.4930254644718940e-02
    x_5_6     product_ub_244  -4.2217419711556528e-02
    x_5_6     onehot_5_265  1
    x_5_6     stock_lb_268  6
    x_5_6     stock_ub_269  6
    x_5_6     parent_nonstrict_scope_270  0.024
    x_5_6     unique_nonzero_owner_432  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_6     product_lb_243  1
    w_5_6     product_ub_244  1
    w_5_6     normalized_mass_5_266  1
    w_5_6     normalized_ratio_5_267  -0.75
    w_5_6     full_original_Gini_328  -6.4083333333333323e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_7     OBJ       -3.6000000000000004e-02
    x_5_7     product_lb_245  -2.4930254644718940e-02
    x_5_7     product_ub_246  -4.2217419711556528e-02
    x_5_7     onehot_5_265  1
    x_5_7     stock_lb_268  7
    x_5_7     stock_ub_269  7
    x_5_7     parent_nonstrict_scope_270  0.012
    x_5_7     unique_nonzero_owner_433  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_7     product_lb_245  1
    w_5_7     product_ub_246  1
    w_5_7     normalized_mass_5_266  1
    w_5_7     normalized_ratio_5_267  -0.875
    w_5_7     full_original_Gini_328  -4.3380952380952378e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_8     OBJ       -0.048
    x_5_8     product_lb_247  -2.4930254644718940e-02
    x_5_8     product_ub_248  -4.2217419711556528e-02
    x_5_8     onehot_5_265  1
    x_5_8     stock_lb_268  8
    x_5_8     stock_ub_269  8
    x_5_8     unique_nonzero_owner_434  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_8     product_lb_247  1
    w_5_8     product_ub_248  1
    w_5_8     normalized_mass_5_266  1
    w_5_8     normalized_ratio_5_267  -1
    w_5_8     full_original_Gini_328  -3.7130952380952382e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_9     OBJ       -3.6000000000000004e-02
    x_5_9     product_lb_249  -2.4930254644718940e-02
    x_5_9     product_ub_250  -4.2217419711556528e-02
    x_5_9     onehot_5_265  1
    x_5_9     stock_lb_268  9
    x_5_9     stock_ub_269  9
    x_5_9     parent_nonstrict_scope_270  0.012
    x_5_9     unique_nonzero_owner_435  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_9     product_lb_249  1
    w_5_9     product_ub_250  1
    w_5_9     normalized_mass_5_266  1
    w_5_9     normalized_ratio_5_267  -1.125
    w_5_9     full_original_Gini_328  -6.83809523809524
    MARKER    'MARKER'                 'INTORG'
    x_5_10    OBJ       -0.024
    x_5_10    product_lb_251  -2.4930254644718940e-02
    x_5_10    product_ub_252  -4.2217419711556528e-02
    x_5_10    onehot_5_265  1
    x_5_10    stock_lb_268  10
    x_5_10    stock_ub_269  10
    x_5_10    parent_nonstrict_scope_270  0.024
    x_5_10    unique_nonzero_owner_436  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_10    product_lb_251  1
    w_5_10    product_ub_252  1
    w_5_10    normalized_mass_5_266  1
    w_5_10    normalized_ratio_5_267  -1.25
    w_5_10    full_original_Gini_328  -1.0063095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_11    OBJ       -1.1999999999999997e-02
    x_5_11    product_lb_253  -2.4930254644718940e-02
    x_5_11    product_ub_254  -4.2217419711556528e-02
    x_5_11    onehot_5_265  1
    x_5_11    stock_lb_268  11
    x_5_11    stock_ub_269  11
    x_5_11    parent_nonstrict_scope_270  3.6000000000000004e-02
    x_5_11    unique_nonzero_owner_437  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_11    product_lb_253  1
    w_5_11    product_ub_254  1
    w_5_11    normalized_mass_5_266  1
    w_5_11    normalized_ratio_5_267  -1.375
    w_5_11    full_original_Gini_328  -1.3438095238095238e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_12    product_lb_255  -2.4930254644718940e-02
    x_5_12    product_ub_256  -4.2217419711556528e-02
    x_5_12    onehot_5_265  1
    x_5_12    stock_lb_268  12
    x_5_12    stock_ub_269  12
    x_5_12    parent_nonstrict_scope_270  0.048
    x_5_12    unique_nonzero_owner_438  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_12    product_lb_255  1
    w_5_12    product_ub_256  1
    w_5_12    normalized_mass_5_266  1
    w_5_12    normalized_ratio_5_267  -1.5
    w_5_12    full_original_Gini_328  -1.6813095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_13    OBJ       1.1999999999999997e-02
    x_5_13    product_lb_257  -2.4930254644718940e-02
    x_5_13    product_ub_258  -4.2217419711556528e-02
    x_5_13    onehot_5_265  1
    x_5_13    stock_lb_268  13
    x_5_13    stock_ub_269  13
    x_5_13    parent_nonstrict_scope_270  0.06
    x_5_13    unique_nonzero_owner_439  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_13    product_lb_257  1
    w_5_13    product_ub_258  1
    w_5_13    normalized_mass_5_266  1
    w_5_13    normalized_ratio_5_267  -1.625
    w_5_13    full_original_Gini_328  -2.0188095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_14    OBJ       2.4000000000000007e-02
    x_5_14    product_lb_259  -2.4930254644718940e-02
    x_5_14    product_ub_260  -4.2217419711556528e-02
    x_5_14    onehot_5_265  1
    x_5_14    stock_lb_268  14
    x_5_14    stock_ub_269  14
    x_5_14    parent_nonstrict_scope_270  7.2000000000000008e-02
    x_5_14    unique_nonzero_owner_440  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_14    product_lb_259  1
    w_5_14    product_ub_260  1
    w_5_14    normalized_mass_5_266  1
    w_5_14    normalized_ratio_5_267  -1.75
    w_5_14    full_original_Gini_328  -2.3563095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_15    OBJ       3.6000000000000004e-02
    x_5_15    product_lb_261  -2.4930254644718940e-02
    x_5_15    product_ub_262  -4.2217419711556528e-02
    x_5_15    onehot_5_265  1
    x_5_15    stock_lb_268  15
    x_5_15    stock_ub_269  15
    x_5_15    parent_nonstrict_scope_270  0.084
    x_5_15    unique_nonzero_owner_441  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_15    product_lb_261  1
    w_5_15    product_ub_262  1
    w_5_15    normalized_mass_5_266  1
    w_5_15    normalized_ratio_5_267  -1.875
    w_5_15    full_original_Gini_328  -2.6938095238095240e+01
    MARKER    'MARKER'                 'INTORG'
    x_5_16    OBJ       0.048
    x_5_16    product_lb_263  -2.4930254644718940e-02
    x_5_16    product_ub_264  -4.2217419711556528e-02
    x_5_16    onehot_5_265  1
    x_5_16    stock_lb_268  16
    x_5_16    stock_ub_269  16
    x_5_16    parent_nonstrict_scope_270  0.096
    x_5_16    unique_nonzero_owner_442  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_16    product_lb_263  1
    w_5_16    product_ub_264  1
    w_5_16    normalized_mass_5_266  1
    w_5_16    normalized_ratio_5_267  -2
    w_5_16    full_original_Gini_328  -3.0313095238095240e+01
    rho_5     normalized_ratio_5_267  1
    rho_5     block_pair_pos_277  1
    rho_5     block_pair_neg_278  -1
    rho_5     block_pair_pos_289  1
    rho_5     block_pair_neg_290  -1
    rho_5     block_pair_pos_299  1
    rho_5     block_pair_neg_300  -1
    rho_5     block_pair_pos_305  1
    rho_5     block_pair_neg_306  -1
    rho_5     block_pair_pos_309  1
    rho_5     block_pair_neg_310  -1
    rho_5     block_pair_pos_315  1
    rho_5     block_pair_neg_316  -1
    rho_5     block_pair_pos_323  1
    rho_5     block_pair_neg_324  -1
    rho_5     normalization_327  1
    a_1_2     block_pair_pos_271  1
    a_1_2     block_pair_neg_272  1
    a_1_2     full_original_Gini_328  -1
    a_1_31    block_pair_pos_281  1
    a_1_31    block_pair_neg_282  1
    a_1_31    full_original_Gini_328  -1
    a_1_3     block_pair_pos_273  1
    a_1_3     block_pair_neg_274  1
    a_1_3     full_original_Gini_328  -1
    a_1_32    block_pair_pos_283  1
    a_1_32    block_pair_neg_284  1
    a_1_32    full_original_Gini_328  -1
    a_1_4     block_pair_pos_275  1
    a_1_4     block_pair_neg_276  1
    a_1_4     full_original_Gini_328  -1
    a_1_19    block_pair_pos_279  1
    a_1_19    block_pair_neg_280  1
    a_1_19    full_original_Gini_328  -1
    a_1_5     block_pair_pos_277  1
    a_1_5     block_pair_neg_278  1
    a_1_5     full_original_Gini_328  -1
    a_2_31    block_pair_pos_293  1
    a_2_31    block_pair_neg_294  1
    a_2_31    full_original_Gini_328  -1
    a_2_3     block_pair_pos_285  1
    a_2_3     block_pair_neg_286  1
    a_2_3     full_original_Gini_328  -1
    a_2_32    block_pair_pos_295  1
    a_2_32    block_pair_neg_296  1
    a_2_32    full_original_Gini_328  -1
    a_2_4     block_pair_pos_287  1
    a_2_4     block_pair_neg_288  1
    a_2_4     full_original_Gini_328  -1
    a_2_19    block_pair_pos_291  1
    a_2_19    block_pair_neg_292  1
    a_2_19    full_original_Gini_328  -1
    a_2_5     block_pair_pos_289  1
    a_2_5     block_pair_neg_290  1
    a_2_5     full_original_Gini_328  -1
    a_31_3    block_pair_pos_311  1
    a_31_3    block_pair_neg_312  1
    a_31_3    full_original_Gini_328  -1
    a_31_32   block_pair_pos_319  1
    a_31_32   block_pair_neg_320  1
    a_31_32   full_original_Gini_328  -1
    a_31_4    block_pair_pos_313  1
    a_31_4    block_pair_neg_314  1
    a_31_4    full_original_Gini_328  -1
    a_31_19   block_pair_pos_317  1
    a_31_19   block_pair_neg_318  1
    a_31_19   full_original_Gini_328  -1
    a_31_5    block_pair_pos_315  1
    a_31_5    block_pair_neg_316  1
    a_31_5    full_original_Gini_328  -1
    a_3_32    block_pair_pos_303  1
    a_3_32    block_pair_neg_304  1
    a_3_32    full_original_Gini_328  -1
    a_3_4     block_pair_pos_297  1
    a_3_4     block_pair_neg_298  1
    a_3_4     full_original_Gini_328  -1
    a_3_19    block_pair_pos_301  1
    a_3_19    block_pair_neg_302  1
    a_3_19    full_original_Gini_328  -1
    a_3_5     block_pair_pos_299  1
    a_3_5     block_pair_neg_300  1
    a_3_5     full_original_Gini_328  -1
    a_32_4    block_pair_pos_321  1
    a_32_4    block_pair_neg_322  1
    a_32_4    full_original_Gini_328  -1
    a_32_19   block_pair_pos_325  1
    a_32_19   block_pair_neg_326  1
    a_32_19   full_original_Gini_328  -1
    a_32_5    block_pair_pos_323  1
    a_32_5    block_pair_neg_324  1
    a_32_5    full_original_Gini_328  -1
    a_4_19    block_pair_pos_307  1
    a_4_19    block_pair_neg_308  1
    a_4_19    full_original_Gini_328  -1
    a_4_5     block_pair_pos_305  1
    a_4_5     block_pair_neg_306  1
    a_4_5     full_original_Gini_328  -1
    a_19_5    block_pair_pos_309  1
    a_19_5    block_pair_neg_310  1
    a_19_5    full_original_Gini_328  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_1_0  unique_nonzero_owner_329  1
    service_0_1_0  service_visit_def_823  1
    service_0_1_0  free_load_conservation_824  -2
    service_0_1_0  original_T_including_depot_unload_871  240
    service_0_1_1  unique_nonzero_owner_330  1
    service_0_1_1  service_visit_def_823  1
    service_0_1_1  free_load_conservation_824  -1
    service_0_1_1  original_T_including_depot_unload_871  120
    service_0_1_3  unique_nonzero_owner_331  1
    service_0_1_3  service_visit_def_823  1
    service_0_1_3  free_load_conservation_824  1
    service_0_1_4  unique_nonzero_owner_332  1
    service_0_1_4  service_visit_def_823  1
    service_0_1_4  free_load_conservation_824  2
    service_0_1_5  unique_nonzero_owner_333  1
    service_0_1_5  service_visit_def_823  1
    service_0_1_5  free_load_conservation_824  3
    service_0_1_6  unique_nonzero_owner_334  1
    service_0_1_6  service_visit_def_823  1
    service_0_1_6  free_load_conservation_824  4
    service_0_1_7  unique_nonzero_owner_335  1
    service_0_1_7  service_visit_def_823  1
    service_0_1_7  free_load_conservation_824  5
    service_0_1_8  unique_nonzero_owner_336  1
    service_0_1_8  service_visit_def_823  1
    service_0_1_8  free_load_conservation_824  6
    service_0_1_9  unique_nonzero_owner_337  1
    service_0_1_9  service_visit_def_823  1
    service_0_1_9  free_load_conservation_824  7
    service_0_1_10  unique_nonzero_owner_338  1
    service_0_1_10  service_visit_def_823  1
    service_0_1_10  free_load_conservation_824  8
    service_0_1_11  unique_nonzero_owner_339  1
    service_0_1_11  service_visit_def_823  1
    service_0_1_11  free_load_conservation_824  9
    service_0_1_12  unique_nonzero_owner_340  1
    service_0_1_12  service_visit_def_823  1
    service_0_1_12  free_load_conservation_824  10
    service_0_1_13  unique_nonzero_owner_341  1
    service_0_1_13  service_visit_def_823  1
    service_0_1_13  free_load_conservation_824  11
    service_0_1_14  unique_nonzero_owner_342  1
    service_0_1_14  service_visit_def_823  1
    service_0_1_14  free_load_conservation_824  12
    service_0_1_15  unique_nonzero_owner_343  1
    service_0_1_15  service_visit_def_823  1
    service_0_1_15  free_load_conservation_824  13
    service_0_1_16  unique_nonzero_owner_344  1
    service_0_1_16  service_visit_def_823  1
    service_0_1_16  free_load_conservation_824  14
    service_0_1_17  unique_nonzero_owner_345  1
    service_0_1_17  service_visit_def_823  1
    service_0_1_17  free_load_conservation_824  15
    service_0_1_18  unique_nonzero_owner_346  1
    service_0_1_18  service_visit_def_823  1
    service_0_1_18  free_load_conservation_824  16
    service_0_1_19  unique_nonzero_owner_347  1
    service_0_1_19  service_visit_def_823  1
    service_0_1_19  free_load_conservation_824  17
    service_1_1_0  unique_nonzero_owner_329  1
    service_1_1_0  service_visit_def_1195  1
    service_1_1_0  free_load_conservation_1196  -2
    service_1_1_0  original_T_including_depot_unload_1242  240
    service_1_1_1  unique_nonzero_owner_330  1
    service_1_1_1  service_visit_def_1195  1
    service_1_1_1  free_load_conservation_1196  -1
    service_1_1_1  original_T_including_depot_unload_1242  120
    service_1_1_3  unique_nonzero_owner_331  1
    service_1_1_3  service_visit_def_1195  1
    service_1_1_3  free_load_conservation_1196  1
    service_1_1_4  unique_nonzero_owner_332  1
    service_1_1_4  service_visit_def_1195  1
    service_1_1_4  free_load_conservation_1196  2
    service_1_1_5  unique_nonzero_owner_333  1
    service_1_1_5  service_visit_def_1195  1
    service_1_1_5  free_load_conservation_1196  3
    service_1_1_6  unique_nonzero_owner_334  1
    service_1_1_6  service_visit_def_1195  1
    service_1_1_6  free_load_conservation_1196  4
    service_1_1_7  unique_nonzero_owner_335  1
    service_1_1_7  service_visit_def_1195  1
    service_1_1_7  free_load_conservation_1196  5
    service_1_1_8  unique_nonzero_owner_336  1
    service_1_1_8  service_visit_def_1195  1
    service_1_1_8  free_load_conservation_1196  6
    service_1_1_9  unique_nonzero_owner_337  1
    service_1_1_9  service_visit_def_1195  1
    service_1_1_9  free_load_conservation_1196  7
    service_1_1_10  unique_nonzero_owner_338  1
    service_1_1_10  service_visit_def_1195  1
    service_1_1_10  free_load_conservation_1196  8
    service_1_1_11  unique_nonzero_owner_339  1
    service_1_1_11  service_visit_def_1195  1
    service_1_1_11  free_load_conservation_1196  9
    service_1_1_12  unique_nonzero_owner_340  1
    service_1_1_12  service_visit_def_1195  1
    service_1_1_12  free_load_conservation_1196  10
    service_1_1_13  unique_nonzero_owner_341  1
    service_1_1_13  service_visit_def_1195  1
    service_1_1_13  free_load_conservation_1196  11
    service_1_1_14  unique_nonzero_owner_342  1
    service_1_1_14  service_visit_def_1195  1
    service_1_1_14  free_load_conservation_1196  12
    service_1_1_15  unique_nonzero_owner_343  1
    service_1_1_15  service_visit_def_1195  1
    service_1_1_15  free_load_conservation_1196  13
    service_1_1_16  unique_nonzero_owner_344  1
    service_1_1_16  service_visit_def_1195  1
    service_1_1_16  free_load_conservation_1196  14
    service_1_1_17  unique_nonzero_owner_345  1
    service_1_1_17  service_visit_def_1195  1
    service_1_1_17  free_load_conservation_1196  15
    service_1_1_18  unique_nonzero_owner_346  1
    service_1_1_18  service_visit_def_1195  1
    service_1_1_18  free_load_conservation_1196  16
    service_1_1_19  unique_nonzero_owner_347  1
    service_1_1_19  service_visit_def_1195  1
    service_1_1_19  free_load_conservation_1196  17
    service_2_1_0  unique_nonzero_owner_329  1
    service_2_1_0  service_visit_def_1513  1
    service_2_1_0  free_load_conservation_1514  -2
    service_2_1_0  original_T_including_depot_unload_1559  240
    service_2_1_1  unique_nonzero_owner_330  1
    service_2_1_1  service_visit_def_1513  1
    service_2_1_1  free_load_conservation_1514  -1
    service_2_1_1  original_T_including_depot_unload_1559  120
    service_2_1_3  unique_nonzero_owner_331  1
    service_2_1_3  service_visit_def_1513  1
    service_2_1_3  free_load_conservation_1514  1
    service_2_1_4  unique_nonzero_owner_332  1
    service_2_1_4  service_visit_def_1513  1
    service_2_1_4  free_load_conservation_1514  2
    service_2_1_5  unique_nonzero_owner_333  1
    service_2_1_5  service_visit_def_1513  1
    service_2_1_5  free_load_conservation_1514  3
    service_2_1_6  unique_nonzero_owner_334  1
    service_2_1_6  service_visit_def_1513  1
    service_2_1_6  free_load_conservation_1514  4
    service_2_1_7  unique_nonzero_owner_335  1
    service_2_1_7  service_visit_def_1513  1
    service_2_1_7  free_load_conservation_1514  5
    service_2_1_8  unique_nonzero_owner_336  1
    service_2_1_8  service_visit_def_1513  1
    service_2_1_8  free_load_conservation_1514  6
    service_2_1_9  unique_nonzero_owner_337  1
    service_2_1_9  service_visit_def_1513  1
    service_2_1_9  free_load_conservation_1514  7
    service_2_1_10  unique_nonzero_owner_338  1
    service_2_1_10  service_visit_def_1513  1
    service_2_1_10  free_load_conservation_1514  8
    service_2_1_11  unique_nonzero_owner_339  1
    service_2_1_11  service_visit_def_1513  1
    service_2_1_11  free_load_conservation_1514  9
    service_2_1_12  unique_nonzero_owner_340  1
    service_2_1_12  service_visit_def_1513  1
    service_2_1_12  free_load_conservation_1514  10
    service_2_1_13  unique_nonzero_owner_341  1
    service_2_1_13  service_visit_def_1513  1
    service_2_1_13  free_load_conservation_1514  11
    service_2_1_14  unique_nonzero_owner_342  1
    service_2_1_14  service_visit_def_1513  1
    service_2_1_14  free_load_conservation_1514  12
    service_2_1_15  unique_nonzero_owner_343  1
    service_2_1_15  service_visit_def_1513  1
    service_2_1_15  free_load_conservation_1514  13
    service_2_1_16  unique_nonzero_owner_344  1
    service_2_1_16  service_visit_def_1513  1
    service_2_1_16  free_load_conservation_1514  14
    service_2_1_17  unique_nonzero_owner_345  1
    service_2_1_17  service_visit_def_1513  1
    service_2_1_17  free_load_conservation_1514  15
    service_2_1_18  unique_nonzero_owner_346  1
    service_2_1_18  service_visit_def_1513  1
    service_2_1_18  free_load_conservation_1514  16
    service_2_1_19  unique_nonzero_owner_347  1
    service_2_1_19  service_visit_def_1513  1
    service_2_1_19  free_load_conservation_1514  17
    service_0_2_1  unique_nonzero_owner_348  1
    service_0_2_1  service_visit_def_829  1
    service_0_2_1  free_load_conservation_830  1
    service_0_2_2  unique_nonzero_owner_349  1
    service_0_2_2  service_visit_def_829  1
    service_0_2_2  free_load_conservation_830  2
    service_0_2_3  unique_nonzero_owner_350  1
    service_0_2_3  service_visit_def_829  1
    service_0_2_3  free_load_conservation_830  3
    service_0_2_4  unique_nonzero_owner_351  1
    service_0_2_4  service_visit_def_829  1
    service_0_2_4  free_load_conservation_830  4
    service_0_2_5  unique_nonzero_owner_352  1
    service_0_2_5  service_visit_def_829  1
    service_0_2_5  free_load_conservation_830  5
    service_0_2_6  unique_nonzero_owner_353  1
    service_0_2_6  service_visit_def_829  1
    service_0_2_6  free_load_conservation_830  6
    service_0_2_7  unique_nonzero_owner_354  1
    service_0_2_7  service_visit_def_829  1
    service_0_2_7  free_load_conservation_830  7
    service_0_2_8  unique_nonzero_owner_355  1
    service_0_2_8  service_visit_def_829  1
    service_0_2_8  free_load_conservation_830  8
    service_0_2_9  unique_nonzero_owner_356  1
    service_0_2_9  service_visit_def_829  1
    service_0_2_9  free_load_conservation_830  9
    service_0_2_10  unique_nonzero_owner_357  1
    service_0_2_10  service_visit_def_829  1
    service_0_2_10  free_load_conservation_830  10
    service_0_2_11  unique_nonzero_owner_358  1
    service_0_2_11  service_visit_def_829  1
    service_0_2_11  free_load_conservation_830  11
    service_0_2_12  unique_nonzero_owner_359  1
    service_0_2_12  service_visit_def_829  1
    service_0_2_12  free_load_conservation_830  12
    service_0_2_13  unique_nonzero_owner_360  1
    service_0_2_13  service_visit_def_829  1
    service_0_2_13  free_load_conservation_830  13
    service_0_2_14  unique_nonzero_owner_361  1
    service_0_2_14  service_visit_def_829  1
    service_0_2_14  free_load_conservation_830  14
    service_0_2_15  unique_nonzero_owner_362  1
    service_0_2_15  service_visit_def_829  1
    service_0_2_15  free_load_conservation_830  15
    service_1_2_1  unique_nonzero_owner_348  1
    service_1_2_1  service_visit_def_1201  1
    service_1_2_1  free_load_conservation_1202  1
    service_1_2_2  unique_nonzero_owner_349  1
    service_1_2_2  service_visit_def_1201  1
    service_1_2_2  free_load_conservation_1202  2
    service_1_2_3  unique_nonzero_owner_350  1
    service_1_2_3  service_visit_def_1201  1
    service_1_2_3  free_load_conservation_1202  3
    service_1_2_4  unique_nonzero_owner_351  1
    service_1_2_4  service_visit_def_1201  1
    service_1_2_4  free_load_conservation_1202  4
    service_1_2_5  unique_nonzero_owner_352  1
    service_1_2_5  service_visit_def_1201  1
    service_1_2_5  free_load_conservation_1202  5
    service_1_2_6  unique_nonzero_owner_353  1
    service_1_2_6  service_visit_def_1201  1
    service_1_2_6  free_load_conservation_1202  6
    service_1_2_7  unique_nonzero_owner_354  1
    service_1_2_7  service_visit_def_1201  1
    service_1_2_7  free_load_conservation_1202  7
    service_1_2_8  unique_nonzero_owner_355  1
    service_1_2_8  service_visit_def_1201  1
    service_1_2_8  free_load_conservation_1202  8
    service_1_2_9  unique_nonzero_owner_356  1
    service_1_2_9  service_visit_def_1201  1
    service_1_2_9  free_load_conservation_1202  9
    service_1_2_10  unique_nonzero_owner_357  1
    service_1_2_10  service_visit_def_1201  1
    service_1_2_10  free_load_conservation_1202  10
    service_1_2_11  unique_nonzero_owner_358  1
    service_1_2_11  service_visit_def_1201  1
    service_1_2_11  free_load_conservation_1202  11
    service_1_2_12  unique_nonzero_owner_359  1
    service_1_2_12  service_visit_def_1201  1
    service_1_2_12  free_load_conservation_1202  12
    service_1_2_13  unique_nonzero_owner_360  1
    service_1_2_13  service_visit_def_1201  1
    service_1_2_13  free_load_conservation_1202  13
    service_1_2_14  unique_nonzero_owner_361  1
    service_1_2_14  service_visit_def_1201  1
    service_1_2_14  free_load_conservation_1202  14
    service_1_2_15  unique_nonzero_owner_362  1
    service_1_2_15  service_visit_def_1201  1
    service_1_2_15  free_load_conservation_1202  15
    service_2_2_1  unique_nonzero_owner_348  1
    service_2_2_1  service_visit_def_1519  1
    service_2_2_1  free_load_conservation_1520  1
    service_2_2_2  unique_nonzero_owner_349  1
    service_2_2_2  service_visit_def_1519  1
    service_2_2_2  free_load_conservation_1520  2
    service_2_2_3  unique_nonzero_owner_350  1
    service_2_2_3  service_visit_def_1519  1
    service_2_2_3  free_load_conservation_1520  3
    service_2_2_4  unique_nonzero_owner_351  1
    service_2_2_4  service_visit_def_1519  1
    service_2_2_4  free_load_conservation_1520  4
    service_2_2_5  unique_nonzero_owner_352  1
    service_2_2_5  service_visit_def_1519  1
    service_2_2_5  free_load_conservation_1520  5
    service_2_2_6  unique_nonzero_owner_353  1
    service_2_2_6  service_visit_def_1519  1
    service_2_2_6  free_load_conservation_1520  6
    service_2_2_7  unique_nonzero_owner_354  1
    service_2_2_7  service_visit_def_1519  1
    service_2_2_7  free_load_conservation_1520  7
    service_2_2_8  unique_nonzero_owner_355  1
    service_2_2_8  service_visit_def_1519  1
    service_2_2_8  free_load_conservation_1520  8
    service_2_2_9  unique_nonzero_owner_356  1
    service_2_2_9  service_visit_def_1519  1
    service_2_2_9  free_load_conservation_1520  9
    service_2_2_10  unique_nonzero_owner_357  1
    service_2_2_10  service_visit_def_1519  1
    service_2_2_10  free_load_conservation_1520  10
    service_2_2_11  unique_nonzero_owner_358  1
    service_2_2_11  service_visit_def_1519  1
    service_2_2_11  free_load_conservation_1520  11
    service_2_2_12  unique_nonzero_owner_359  1
    service_2_2_12  service_visit_def_1519  1
    service_2_2_12  free_load_conservation_1520  12
    service_2_2_13  unique_nonzero_owner_360  1
    service_2_2_13  service_visit_def_1519  1
    service_2_2_13  free_load_conservation_1520  13
    service_2_2_14  unique_nonzero_owner_361  1
    service_2_2_14  service_visit_def_1519  1
    service_2_2_14  free_load_conservation_1520  14
    service_2_2_15  unique_nonzero_owner_362  1
    service_2_2_15  service_visit_def_1519  1
    service_2_2_15  free_load_conservation_1520  15
    service_0_31_0  unique_nonzero_owner_363  1
    service_0_31_0  service_visit_def_835  1
    service_0_31_0  free_load_conservation_836  -2
    service_0_31_0  original_T_including_depot_unload_871  240
    service_0_31_1  unique_nonzero_owner_364  1
    service_0_31_1  service_visit_def_835  1
    service_0_31_1  free_load_conservation_836  -1
    service_0_31_1  original_T_including_depot_unload_871  120
    service_0_31_3  unique_nonzero_owner_365  1
    service_0_31_3  service_visit_def_835  1
    service_0_31_3  free_load_conservation_836  1
    service_0_31_4  unique_nonzero_owner_366  1
    service_0_31_4  service_visit_def_835  1
    service_0_31_4  free_load_conservation_836  2
    service_0_31_5  unique_nonzero_owner_367  1
    service_0_31_5  service_visit_def_835  1
    service_0_31_5  free_load_conservation_836  3
    service_0_31_6  unique_nonzero_owner_368  1
    service_0_31_6  service_visit_def_835  1
    service_0_31_6  free_load_conservation_836  4
    service_0_31_7  unique_nonzero_owner_369  1
    service_0_31_7  service_visit_def_835  1
    service_0_31_7  free_load_conservation_836  5
    service_0_31_8  unique_nonzero_owner_370  1
    service_0_31_8  service_visit_def_835  1
    service_0_31_8  free_load_conservation_836  6
    service_0_31_9  unique_nonzero_owner_371  1
    service_0_31_9  service_visit_def_835  1
    service_0_31_9  free_load_conservation_836  7
    service_0_31_10  unique_nonzero_owner_372  1
    service_0_31_10  service_visit_def_835  1
    service_0_31_10  free_load_conservation_836  8
    service_0_31_11  unique_nonzero_owner_373  1
    service_0_31_11  service_visit_def_835  1
    service_0_31_11  free_load_conservation_836  9
    service_0_31_12  unique_nonzero_owner_374  1
    service_0_31_12  service_visit_def_835  1
    service_0_31_12  free_load_conservation_836  10
    service_1_31_0  unique_nonzero_owner_363  1
    service_1_31_0  service_visit_def_1207  1
    service_1_31_0  free_load_conservation_1208  -2
    service_1_31_0  original_T_including_depot_unload_1242  240
    service_1_31_1  unique_nonzero_owner_364  1
    service_1_31_1  service_visit_def_1207  1
    service_1_31_1  free_load_conservation_1208  -1
    service_1_31_1  original_T_including_depot_unload_1242  120
    service_1_31_3  unique_nonzero_owner_365  1
    service_1_31_3  service_visit_def_1207  1
    service_1_31_3  free_load_conservation_1208  1
    service_1_31_4  unique_nonzero_owner_366  1
    service_1_31_4  service_visit_def_1207  1
    service_1_31_4  free_load_conservation_1208  2
    service_1_31_5  unique_nonzero_owner_367  1
    service_1_31_5  service_visit_def_1207  1
    service_1_31_5  free_load_conservation_1208  3
    service_1_31_6  unique_nonzero_owner_368  1
    service_1_31_6  service_visit_def_1207  1
    service_1_31_6  free_load_conservation_1208  4
    service_1_31_7  unique_nonzero_owner_369  1
    service_1_31_7  service_visit_def_1207  1
    service_1_31_7  free_load_conservation_1208  5
    service_1_31_8  unique_nonzero_owner_370  1
    service_1_31_8  service_visit_def_1207  1
    service_1_31_8  free_load_conservation_1208  6
    service_1_31_9  unique_nonzero_owner_371  1
    service_1_31_9  service_visit_def_1207  1
    service_1_31_9  free_load_conservation_1208  7
    service_1_31_10  unique_nonzero_owner_372  1
    service_1_31_10  service_visit_def_1207  1
    service_1_31_10  free_load_conservation_1208  8
    service_1_31_11  unique_nonzero_owner_373  1
    service_1_31_11  service_visit_def_1207  1
    service_1_31_11  free_load_conservation_1208  9
    service_1_31_12  unique_nonzero_owner_374  1
    service_1_31_12  service_visit_def_1207  1
    service_1_31_12  free_load_conservation_1208  10
    service_2_31_0  unique_nonzero_owner_363  1
    service_2_31_0  service_visit_def_1525  1
    service_2_31_0  free_load_conservation_1526  -2
    service_2_31_0  original_T_including_depot_unload_1559  240
    service_2_31_1  unique_nonzero_owner_364  1
    service_2_31_1  service_visit_def_1525  1
    service_2_31_1  free_load_conservation_1526  -1
    service_2_31_1  original_T_including_depot_unload_1559  120
    service_2_31_3  unique_nonzero_owner_365  1
    service_2_31_3  service_visit_def_1525  1
    service_2_31_3  free_load_conservation_1526  1
    service_2_31_4  unique_nonzero_owner_366  1
    service_2_31_4  service_visit_def_1525  1
    service_2_31_4  free_load_conservation_1526  2
    service_2_31_5  unique_nonzero_owner_367  1
    service_2_31_5  service_visit_def_1525  1
    service_2_31_5  free_load_conservation_1526  3
    service_2_31_6  unique_nonzero_owner_368  1
    service_2_31_6  service_visit_def_1525  1
    service_2_31_6  free_load_conservation_1526  4
    service_2_31_7  unique_nonzero_owner_369  1
    service_2_31_7  service_visit_def_1525  1
    service_2_31_7  free_load_conservation_1526  5
    service_2_31_8  unique_nonzero_owner_370  1
    service_2_31_8  service_visit_def_1525  1
    service_2_31_8  free_load_conservation_1526  6
    service_2_31_9  unique_nonzero_owner_371  1
    service_2_31_9  service_visit_def_1525  1
    service_2_31_9  free_load_conservation_1526  7
    service_2_31_10  unique_nonzero_owner_372  1
    service_2_31_10  service_visit_def_1525  1
    service_2_31_10  free_load_conservation_1526  8
    service_2_31_11  unique_nonzero_owner_373  1
    service_2_31_11  service_visit_def_1525  1
    service_2_31_11  free_load_conservation_1526  9
    service_2_31_12  unique_nonzero_owner_374  1
    service_2_31_12  service_visit_def_1525  1
    service_2_31_12  free_load_conservation_1526  10
    service_0_3_0  unique_nonzero_owner_375  1
    service_0_3_0  service_visit_def_841  1
    service_0_3_0  free_load_conservation_842  -12
    service_0_3_0  original_T_including_depot_unload_871  1440
    service_0_3_1  unique_nonzero_owner_376  1
    service_0_3_1  service_visit_def_841  1
    service_0_3_1  free_load_conservation_842  -11
    service_0_3_1  original_T_including_depot_unload_871  1320
    service_0_3_2  unique_nonzero_owner_377  1
    service_0_3_2  service_visit_def_841  1
    service_0_3_2  free_load_conservation_842  -10
    service_0_3_2  original_T_including_depot_unload_871  1200
    service_0_3_3  unique_nonzero_owner_378  1
    service_0_3_3  service_visit_def_841  1
    service_0_3_3  free_load_conservation_842  -9
    service_0_3_3  original_T_including_depot_unload_871  1080
    service_0_3_4  unique_nonzero_owner_379  1
    service_0_3_4  service_visit_def_841  1
    service_0_3_4  free_load_conservation_842  -8
    service_0_3_4  original_T_including_depot_unload_871  960
    service_0_3_5  unique_nonzero_owner_380  1
    service_0_3_5  service_visit_def_841  1
    service_0_3_5  free_load_conservation_842  -7
    service_0_3_5  original_T_including_depot_unload_871  840
    service_0_3_6  unique_nonzero_owner_381  1
    service_0_3_6  service_visit_def_841  1
    service_0_3_6  free_load_conservation_842  -6
    service_0_3_6  original_T_including_depot_unload_871  720
    service_0_3_7  unique_nonzero_owner_382  1
    service_0_3_7  service_visit_def_841  1
    service_0_3_7  free_load_conservation_842  -5
    service_0_3_7  original_T_including_depot_unload_871  600
    service_0_3_8  unique_nonzero_owner_383  1
    service_0_3_8  service_visit_def_841  1
    service_0_3_8  free_load_conservation_842  -4
    service_0_3_8  original_T_including_depot_unload_871  480
    service_0_3_9  unique_nonzero_owner_384  1
    service_0_3_9  service_visit_def_841  1
    service_0_3_9  free_load_conservation_842  -3
    service_0_3_9  original_T_including_depot_unload_871  360
    service_0_3_10  unique_nonzero_owner_385  1
    service_0_3_10  service_visit_def_841  1
    service_0_3_10  free_load_conservation_842  -2
    service_0_3_10  original_T_including_depot_unload_871  240
    service_0_3_11  unique_nonzero_owner_386  1
    service_0_3_11  service_visit_def_841  1
    service_0_3_11  free_load_conservation_842  -1
    service_0_3_11  original_T_including_depot_unload_871  120
    service_0_3_13  unique_nonzero_owner_387  1
    service_0_3_13  service_visit_def_841  1
    service_0_3_13  free_load_conservation_842  1
    service_0_3_14  unique_nonzero_owner_388  1
    service_0_3_14  service_visit_def_841  1
    service_0_3_14  free_load_conservation_842  2
    service_0_3_15  unique_nonzero_owner_389  1
    service_0_3_15  service_visit_def_841  1
    service_0_3_15  free_load_conservation_842  3
    service_0_3_16  unique_nonzero_owner_390  1
    service_0_3_16  service_visit_def_841  1
    service_0_3_16  free_load_conservation_842  4
    service_0_3_17  unique_nonzero_owner_391  1
    service_0_3_17  service_visit_def_841  1
    service_0_3_17  free_load_conservation_842  5
    service_1_3_0  unique_nonzero_owner_375  1
    service_1_3_0  service_visit_def_1213  1
    service_1_3_0  free_load_conservation_1214  -12
    service_1_3_0  original_T_including_depot_unload_1242  1440
    service_1_3_1  unique_nonzero_owner_376  1
    service_1_3_1  service_visit_def_1213  1
    service_1_3_1  free_load_conservation_1214  -11
    service_1_3_1  original_T_including_depot_unload_1242  1320
    service_1_3_2  unique_nonzero_owner_377  1
    service_1_3_2  service_visit_def_1213  1
    service_1_3_2  free_load_conservation_1214  -10
    service_1_3_2  original_T_including_depot_unload_1242  1200
    service_1_3_3  unique_nonzero_owner_378  1
    service_1_3_3  service_visit_def_1213  1
    service_1_3_3  free_load_conservation_1214  -9
    service_1_3_3  original_T_including_depot_unload_1242  1080
    service_1_3_4  unique_nonzero_owner_379  1
    service_1_3_4  service_visit_def_1213  1
    service_1_3_4  free_load_conservation_1214  -8
    service_1_3_4  original_T_including_depot_unload_1242  960
    service_1_3_5  unique_nonzero_owner_380  1
    service_1_3_5  service_visit_def_1213  1
    service_1_3_5  free_load_conservation_1214  -7
    service_1_3_5  original_T_including_depot_unload_1242  840
    service_1_3_6  unique_nonzero_owner_381  1
    service_1_3_6  service_visit_def_1213  1
    service_1_3_6  free_load_conservation_1214  -6
    service_1_3_6  original_T_including_depot_unload_1242  720
    service_1_3_7  unique_nonzero_owner_382  1
    service_1_3_7  service_visit_def_1213  1
    service_1_3_7  free_load_conservation_1214  -5
    service_1_3_7  original_T_including_depot_unload_1242  600
    service_1_3_8  unique_nonzero_owner_383  1
    service_1_3_8  service_visit_def_1213  1
    service_1_3_8  free_load_conservation_1214  -4
    service_1_3_8  original_T_including_depot_unload_1242  480
    service_1_3_9  unique_nonzero_owner_384  1
    service_1_3_9  service_visit_def_1213  1
    service_1_3_9  free_load_conservation_1214  -3
    service_1_3_9  original_T_including_depot_unload_1242  360
    service_1_3_10  unique_nonzero_owner_385  1
    service_1_3_10  service_visit_def_1213  1
    service_1_3_10  free_load_conservation_1214  -2
    service_1_3_10  original_T_including_depot_unload_1242  240
    service_1_3_11  unique_nonzero_owner_386  1
    service_1_3_11  service_visit_def_1213  1
    service_1_3_11  free_load_conservation_1214  -1
    service_1_3_11  original_T_including_depot_unload_1242  120
    service_1_3_13  unique_nonzero_owner_387  1
    service_1_3_13  service_visit_def_1213  1
    service_1_3_13  free_load_conservation_1214  1
    service_1_3_14  unique_nonzero_owner_388  1
    service_1_3_14  service_visit_def_1213  1
    service_1_3_14  free_load_conservation_1214  2
    service_1_3_15  unique_nonzero_owner_389  1
    service_1_3_15  service_visit_def_1213  1
    service_1_3_15  free_load_conservation_1214  3
    service_1_3_16  unique_nonzero_owner_390  1
    service_1_3_16  service_visit_def_1213  1
    service_1_3_16  free_load_conservation_1214  4
    service_1_3_17  unique_nonzero_owner_391  1
    service_1_3_17  service_visit_def_1213  1
    service_1_3_17  free_load_conservation_1214  5
    service_2_3_0  unique_nonzero_owner_375  1
    service_2_3_0  service_visit_def_1531  1
    service_2_3_0  free_load_conservation_1532  -12
    service_2_3_0  original_T_including_depot_unload_1559  1440
    service_2_3_1  unique_nonzero_owner_376  1
    service_2_3_1  service_visit_def_1531  1
    service_2_3_1  free_load_conservation_1532  -11
    service_2_3_1  original_T_including_depot_unload_1559  1320
    service_2_3_2  unique_nonzero_owner_377  1
    service_2_3_2  service_visit_def_1531  1
    service_2_3_2  free_load_conservation_1532  -10
    service_2_3_2  original_T_including_depot_unload_1559  1200
    service_2_3_3  unique_nonzero_owner_378  1
    service_2_3_3  service_visit_def_1531  1
    service_2_3_3  free_load_conservation_1532  -9
    service_2_3_3  original_T_including_depot_unload_1559  1080
    service_2_3_4  unique_nonzero_owner_379  1
    service_2_3_4  service_visit_def_1531  1
    service_2_3_4  free_load_conservation_1532  -8
    service_2_3_4  original_T_including_depot_unload_1559  960
    service_2_3_5  unique_nonzero_owner_380  1
    service_2_3_5  service_visit_def_1531  1
    service_2_3_5  free_load_conservation_1532  -7
    service_2_3_5  original_T_including_depot_unload_1559  840
    service_2_3_6  unique_nonzero_owner_381  1
    service_2_3_6  service_visit_def_1531  1
    service_2_3_6  free_load_conservation_1532  -6
    service_2_3_6  original_T_including_depot_unload_1559  720
    service_2_3_7  unique_nonzero_owner_382  1
    service_2_3_7  service_visit_def_1531  1
    service_2_3_7  free_load_conservation_1532  -5
    service_2_3_7  original_T_including_depot_unload_1559  600
    service_2_3_8  unique_nonzero_owner_383  1
    service_2_3_8  service_visit_def_1531  1
    service_2_3_8  free_load_conservation_1532  -4
    service_2_3_8  original_T_including_depot_unload_1559  480
    service_2_3_9  unique_nonzero_owner_384  1
    service_2_3_9  service_visit_def_1531  1
    service_2_3_9  free_load_conservation_1532  -3
    service_2_3_9  original_T_including_depot_unload_1559  360
    service_2_3_10  unique_nonzero_owner_385  1
    service_2_3_10  service_visit_def_1531  1
    service_2_3_10  free_load_conservation_1532  -2
    service_2_3_10  original_T_including_depot_unload_1559  240
    service_2_3_11  unique_nonzero_owner_386  1
    service_2_3_11  service_visit_def_1531  1
    service_2_3_11  free_load_conservation_1532  -1
    service_2_3_11  original_T_including_depot_unload_1559  120
    service_2_3_13  unique_nonzero_owner_387  1
    service_2_3_13  service_visit_def_1531  1
    service_2_3_13  free_load_conservation_1532  1
    service_2_3_14  unique_nonzero_owner_388  1
    service_2_3_14  service_visit_def_1531  1
    service_2_3_14  free_load_conservation_1532  2
    service_2_3_15  unique_nonzero_owner_389  1
    service_2_3_15  service_visit_def_1531  1
    service_2_3_15  free_load_conservation_1532  3
    service_2_3_16  unique_nonzero_owner_390  1
    service_2_3_16  service_visit_def_1531  1
    service_2_3_16  free_load_conservation_1532  4
    service_2_3_17  unique_nonzero_owner_391  1
    service_2_3_17  service_visit_def_1531  1
    service_2_3_17  free_load_conservation_1532  5
    service_0_32_1  unique_nonzero_owner_392  1
    service_0_32_1  service_visit_def_847  1
    service_0_32_1  free_load_conservation_848  1
    service_0_32_2  unique_nonzero_owner_393  1
    service_0_32_2  service_visit_def_847  1
    service_0_32_2  free_load_conservation_848  2
    service_0_32_3  unique_nonzero_owner_394  1
    service_0_32_3  service_visit_def_847  1
    service_0_32_3  free_load_conservation_848  3
    service_0_32_4  unique_nonzero_owner_395  1
    service_0_32_4  service_visit_def_847  1
    service_0_32_4  free_load_conservation_848  4
    service_0_32_5  unique_nonzero_owner_396  1
    service_0_32_5  service_visit_def_847  1
    service_0_32_5  free_load_conservation_848  5
    service_0_32_6  unique_nonzero_owner_397  1
    service_0_32_6  service_visit_def_847  1
    service_0_32_6  free_load_conservation_848  6
    service_0_32_7  unique_nonzero_owner_398  1
    service_0_32_7  service_visit_def_847  1
    service_0_32_7  free_load_conservation_848  7
    service_0_32_8  unique_nonzero_owner_399  1
    service_0_32_8  service_visit_def_847  1
    service_0_32_8  free_load_conservation_848  8
    service_0_32_9  unique_nonzero_owner_400  1
    service_0_32_9  service_visit_def_847  1
    service_0_32_9  free_load_conservation_848  9
    service_0_32_10  unique_nonzero_owner_401  1
    service_0_32_10  service_visit_def_847  1
    service_0_32_10  free_load_conservation_848  10
    service_0_32_11  unique_nonzero_owner_402  1
    service_0_32_11  service_visit_def_847  1
    service_0_32_11  free_load_conservation_848  11
    service_0_32_12  unique_nonzero_owner_403  1
    service_0_32_12  service_visit_def_847  1
    service_0_32_12  free_load_conservation_848  12
    service_1_32_1  unique_nonzero_owner_392  1
    service_1_32_1  service_visit_def_1219  1
    service_1_32_1  free_load_conservation_1220  1
    service_1_32_2  unique_nonzero_owner_393  1
    service_1_32_2  service_visit_def_1219  1
    service_1_32_2  free_load_conservation_1220  2
    service_1_32_3  unique_nonzero_owner_394  1
    service_1_32_3  service_visit_def_1219  1
    service_1_32_3  free_load_conservation_1220  3
    service_1_32_4  unique_nonzero_owner_395  1
    service_1_32_4  service_visit_def_1219  1
    service_1_32_4  free_load_conservation_1220  4
    service_1_32_5  unique_nonzero_owner_396  1
    service_1_32_5  service_visit_def_1219  1
    service_1_32_5  free_load_conservation_1220  5
    service_1_32_6  unique_nonzero_owner_397  1
    service_1_32_6  service_visit_def_1219  1
    service_1_32_6  free_load_conservation_1220  6
    service_1_32_7  unique_nonzero_owner_398  1
    service_1_32_7  service_visit_def_1219  1
    service_1_32_7  free_load_conservation_1220  7
    service_1_32_8  unique_nonzero_owner_399  1
    service_1_32_8  service_visit_def_1219  1
    service_1_32_8  free_load_conservation_1220  8
    service_1_32_9  unique_nonzero_owner_400  1
    service_1_32_9  service_visit_def_1219  1
    service_1_32_9  free_load_conservation_1220  9
    service_1_32_10  unique_nonzero_owner_401  1
    service_1_32_10  service_visit_def_1219  1
    service_1_32_10  free_load_conservation_1220  10
    service_1_32_11  unique_nonzero_owner_402  1
    service_1_32_11  service_visit_def_1219  1
    service_1_32_11  free_load_conservation_1220  11
    service_1_32_12  unique_nonzero_owner_403  1
    service_1_32_12  service_visit_def_1219  1
    service_1_32_12  free_load_conservation_1220  12
    service_2_32_1  unique_nonzero_owner_392  1
    service_2_32_1  service_visit_def_1537  1
    service_2_32_1  free_load_conservation_1538  1
    service_2_32_2  unique_nonzero_owner_393  1
    service_2_32_2  service_visit_def_1537  1
    service_2_32_2  free_load_conservation_1538  2
    service_2_32_3  unique_nonzero_owner_394  1
    service_2_32_3  service_visit_def_1537  1
    service_2_32_3  free_load_conservation_1538  3
    service_2_32_4  unique_nonzero_owner_395  1
    service_2_32_4  service_visit_def_1537  1
    service_2_32_4  free_load_conservation_1538  4
    service_2_32_5  unique_nonzero_owner_396  1
    service_2_32_5  service_visit_def_1537  1
    service_2_32_5  free_load_conservation_1538  5
    service_2_32_6  unique_nonzero_owner_397  1
    service_2_32_6  service_visit_def_1537  1
    service_2_32_6  free_load_conservation_1538  6
    service_2_32_7  unique_nonzero_owner_398  1
    service_2_32_7  service_visit_def_1537  1
    service_2_32_7  free_load_conservation_1538  7
    service_2_32_8  unique_nonzero_owner_399  1
    service_2_32_8  service_visit_def_1537  1
    service_2_32_8  free_load_conservation_1538  8
    service_2_32_9  unique_nonzero_owner_400  1
    service_2_32_9  service_visit_def_1537  1
    service_2_32_9  free_load_conservation_1538  9
    service_2_32_10  unique_nonzero_owner_401  1
    service_2_32_10  service_visit_def_1537  1
    service_2_32_10  free_load_conservation_1538  10
    service_2_32_11  unique_nonzero_owner_402  1
    service_2_32_11  service_visit_def_1537  1
    service_2_32_11  free_load_conservation_1538  11
    service_2_32_12  unique_nonzero_owner_403  1
    service_2_32_12  service_visit_def_1537  1
    service_2_32_12  free_load_conservation_1538  12
    service_0_4_0  unique_nonzero_owner_404  1
    service_0_4_0  service_visit_def_853  1
    service_0_4_0  free_load_conservation_854  -11
    service_0_4_0  original_T_including_depot_unload_871  1320
    service_0_4_1  unique_nonzero_owner_405  1
    service_0_4_1  service_visit_def_853  1
    service_0_4_1  free_load_conservation_854  -10
    service_0_4_1  original_T_including_depot_unload_871  1200
    service_0_4_2  unique_nonzero_owner_406  1
    service_0_4_2  service_visit_def_853  1
    service_0_4_2  free_load_conservation_854  -9
    service_0_4_2  original_T_including_depot_unload_871  1080
    service_0_4_3  unique_nonzero_owner_407  1
    service_0_4_3  service_visit_def_853  1
    service_0_4_3  free_load_conservation_854  -8
    service_0_4_3  original_T_including_depot_unload_871  960
    service_0_4_4  unique_nonzero_owner_408  1
    service_0_4_4  service_visit_def_853  1
    service_0_4_4  free_load_conservation_854  -7
    service_0_4_4  original_T_including_depot_unload_871  840
    service_0_4_5  unique_nonzero_owner_409  1
    service_0_4_5  service_visit_def_853  1
    service_0_4_5  free_load_conservation_854  -6
    service_0_4_5  original_T_including_depot_unload_871  720
    service_0_4_6  unique_nonzero_owner_410  1
    service_0_4_6  service_visit_def_853  1
    service_0_4_6  free_load_conservation_854  -5
    service_0_4_6  original_T_including_depot_unload_871  600
    service_0_4_7  unique_nonzero_owner_411  1
    service_0_4_7  service_visit_def_853  1
    service_0_4_7  free_load_conservation_854  -4
    service_0_4_7  original_T_including_depot_unload_871  480
    service_0_4_8  unique_nonzero_owner_412  1
    service_0_4_8  service_visit_def_853  1
    service_0_4_8  free_load_conservation_854  -3
    service_0_4_8  original_T_including_depot_unload_871  360
    service_0_4_9  unique_nonzero_owner_413  1
    service_0_4_9  service_visit_def_853  1
    service_0_4_9  free_load_conservation_854  -2
    service_0_4_9  original_T_including_depot_unload_871  240
    service_0_4_10  unique_nonzero_owner_414  1
    service_0_4_10  service_visit_def_853  1
    service_0_4_10  free_load_conservation_854  -1
    service_0_4_10  original_T_including_depot_unload_871  120
    service_0_4_12  unique_nonzero_owner_415  1
    service_0_4_12  service_visit_def_853  1
    service_0_4_12  free_load_conservation_854  1
    service_0_4_13  unique_nonzero_owner_416  1
    service_0_4_13  service_visit_def_853  1
    service_0_4_13  free_load_conservation_854  2
    service_0_4_14  unique_nonzero_owner_417  1
    service_0_4_14  service_visit_def_853  1
    service_0_4_14  free_load_conservation_854  3
    service_0_4_15  unique_nonzero_owner_418  1
    service_0_4_15  service_visit_def_853  1
    service_0_4_15  free_load_conservation_854  4
    service_1_4_0  unique_nonzero_owner_404  1
    service_1_4_0  service_visit_def_1225  1
    service_1_4_0  free_load_conservation_1226  -11
    service_1_4_0  original_T_including_depot_unload_1242  1320
    service_1_4_1  unique_nonzero_owner_405  1
    service_1_4_1  service_visit_def_1225  1
    service_1_4_1  free_load_conservation_1226  -10
    service_1_4_1  original_T_including_depot_unload_1242  1200
    service_1_4_2  unique_nonzero_owner_406  1
    service_1_4_2  service_visit_def_1225  1
    service_1_4_2  free_load_conservation_1226  -9
    service_1_4_2  original_T_including_depot_unload_1242  1080
    service_1_4_3  unique_nonzero_owner_407  1
    service_1_4_3  service_visit_def_1225  1
    service_1_4_3  free_load_conservation_1226  -8
    service_1_4_3  original_T_including_depot_unload_1242  960
    service_1_4_4  unique_nonzero_owner_408  1
    service_1_4_4  service_visit_def_1225  1
    service_1_4_4  free_load_conservation_1226  -7
    service_1_4_4  original_T_including_depot_unload_1242  840
    service_1_4_5  unique_nonzero_owner_409  1
    service_1_4_5  service_visit_def_1225  1
    service_1_4_5  free_load_conservation_1226  -6
    service_1_4_5  original_T_including_depot_unload_1242  720
    service_1_4_6  unique_nonzero_owner_410  1
    service_1_4_6  service_visit_def_1225  1
    service_1_4_6  free_load_conservation_1226  -5
    service_1_4_6  original_T_including_depot_unload_1242  600
    service_1_4_7  unique_nonzero_owner_411  1
    service_1_4_7  service_visit_def_1225  1
    service_1_4_7  free_load_conservation_1226  -4
    service_1_4_7  original_T_including_depot_unload_1242  480
    service_1_4_8  unique_nonzero_owner_412  1
    service_1_4_8  service_visit_def_1225  1
    service_1_4_8  free_load_conservation_1226  -3
    service_1_4_8  original_T_including_depot_unload_1242  360
    service_1_4_9  unique_nonzero_owner_413  1
    service_1_4_9  service_visit_def_1225  1
    service_1_4_9  free_load_conservation_1226  -2
    service_1_4_9  original_T_including_depot_unload_1242  240
    service_1_4_10  unique_nonzero_owner_414  1
    service_1_4_10  service_visit_def_1225  1
    service_1_4_10  free_load_conservation_1226  -1
    service_1_4_10  original_T_including_depot_unload_1242  120
    service_1_4_12  unique_nonzero_owner_415  1
    service_1_4_12  service_visit_def_1225  1
    service_1_4_12  free_load_conservation_1226  1
    service_1_4_13  unique_nonzero_owner_416  1
    service_1_4_13  service_visit_def_1225  1
    service_1_4_13  free_load_conservation_1226  2
    service_1_4_14  unique_nonzero_owner_417  1
    service_1_4_14  service_visit_def_1225  1
    service_1_4_14  free_load_conservation_1226  3
    service_1_4_15  unique_nonzero_owner_418  1
    service_1_4_15  service_visit_def_1225  1
    service_1_4_15  free_load_conservation_1226  4
    service_2_4_0  unique_nonzero_owner_404  1
    service_2_4_0  service_visit_def_1543  1
    service_2_4_0  free_load_conservation_1544  -11
    service_2_4_0  original_T_including_depot_unload_1559  1320
    service_2_4_1  unique_nonzero_owner_405  1
    service_2_4_1  service_visit_def_1543  1
    service_2_4_1  free_load_conservation_1544  -10
    service_2_4_1  original_T_including_depot_unload_1559  1200
    service_2_4_2  unique_nonzero_owner_406  1
    service_2_4_2  service_visit_def_1543  1
    service_2_4_2  free_load_conservation_1544  -9
    service_2_4_2  original_T_including_depot_unload_1559  1080
    service_2_4_3  unique_nonzero_owner_407  1
    service_2_4_3  service_visit_def_1543  1
    service_2_4_3  free_load_conservation_1544  -8
    service_2_4_3  original_T_including_depot_unload_1559  960
    service_2_4_4  unique_nonzero_owner_408  1
    service_2_4_4  service_visit_def_1543  1
    service_2_4_4  free_load_conservation_1544  -7
    service_2_4_4  original_T_including_depot_unload_1559  840
    service_2_4_5  unique_nonzero_owner_409  1
    service_2_4_5  service_visit_def_1543  1
    service_2_4_5  free_load_conservation_1544  -6
    service_2_4_5  original_T_including_depot_unload_1559  720
    service_2_4_6  unique_nonzero_owner_410  1
    service_2_4_6  service_visit_def_1543  1
    service_2_4_6  free_load_conservation_1544  -5
    service_2_4_6  original_T_including_depot_unload_1559  600
    service_2_4_7  unique_nonzero_owner_411  1
    service_2_4_7  service_visit_def_1543  1
    service_2_4_7  free_load_conservation_1544  -4
    service_2_4_7  original_T_including_depot_unload_1559  480
    service_2_4_8  unique_nonzero_owner_412  1
    service_2_4_8  service_visit_def_1543  1
    service_2_4_8  free_load_conservation_1544  -3
    service_2_4_8  original_T_including_depot_unload_1559  360
    service_2_4_9  unique_nonzero_owner_413  1
    service_2_4_9  service_visit_def_1543  1
    service_2_4_9  free_load_conservation_1544  -2
    service_2_4_9  original_T_including_depot_unload_1559  240
    service_2_4_10  unique_nonzero_owner_414  1
    service_2_4_10  service_visit_def_1543  1
    service_2_4_10  free_load_conservation_1544  -1
    service_2_4_10  original_T_including_depot_unload_1559  120
    service_2_4_12  unique_nonzero_owner_415  1
    service_2_4_12  service_visit_def_1543  1
    service_2_4_12  free_load_conservation_1544  1
    service_2_4_13  unique_nonzero_owner_416  1
    service_2_4_13  service_visit_def_1543  1
    service_2_4_13  free_load_conservation_1544  2
    service_2_4_14  unique_nonzero_owner_417  1
    service_2_4_14  service_visit_def_1543  1
    service_2_4_14  free_load_conservation_1544  3
    service_2_4_15  unique_nonzero_owner_418  1
    service_2_4_15  service_visit_def_1543  1
    service_2_4_15  free_load_conservation_1544  4
    service_0_19_1  unique_nonzero_owner_419  1
    service_0_19_1  service_visit_def_859  1
    service_0_19_1  free_load_conservation_860  1
    service_0_19_2  unique_nonzero_owner_420  1
    service_0_19_2  service_visit_def_859  1
    service_0_19_2  free_load_conservation_860  2
    service_0_19_3  unique_nonzero_owner_421  1
    service_0_19_3  service_visit_def_859  1
    service_0_19_3  free_load_conservation_860  3
    service_0_19_4  unique_nonzero_owner_422  1
    service_0_19_4  service_visit_def_859  1
    service_0_19_4  free_load_conservation_860  4
    service_0_19_5  unique_nonzero_owner_423  1
    service_0_19_5  service_visit_def_859  1
    service_0_19_5  free_load_conservation_860  5
    service_0_19_6  unique_nonzero_owner_424  1
    service_0_19_6  service_visit_def_859  1
    service_0_19_6  free_load_conservation_860  6
    service_0_19_7  unique_nonzero_owner_425  1
    service_0_19_7  service_visit_def_859  1
    service_0_19_7  free_load_conservation_860  7
    service_0_19_8  unique_nonzero_owner_426  1
    service_0_19_8  service_visit_def_859  1
    service_0_19_8  free_load_conservation_860  8
    service_1_19_1  unique_nonzero_owner_419  1
    service_1_19_1  service_visit_def_1231  1
    service_1_19_1  free_load_conservation_1232  1
    service_1_19_2  unique_nonzero_owner_420  1
    service_1_19_2  service_visit_def_1231  1
    service_1_19_2  free_load_conservation_1232  2
    service_1_19_3  unique_nonzero_owner_421  1
    service_1_19_3  service_visit_def_1231  1
    service_1_19_3  free_load_conservation_1232  3
    service_1_19_4  unique_nonzero_owner_422  1
    service_1_19_4  service_visit_def_1231  1
    service_1_19_4  free_load_conservation_1232  4
    service_1_19_5  unique_nonzero_owner_423  1
    service_1_19_5  service_visit_def_1231  1
    service_1_19_5  free_load_conservation_1232  5
    service_1_19_6  unique_nonzero_owner_424  1
    service_1_19_6  service_visit_def_1231  1
    service_1_19_6  free_load_conservation_1232  6
    service_1_19_7  unique_nonzero_owner_425  1
    service_1_19_7  service_visit_def_1231  1
    service_1_19_7  free_load_conservation_1232  7
    service_1_19_8  unique_nonzero_owner_426  1
    service_1_19_8  service_visit_def_1231  1
    service_1_19_8  free_load_conservation_1232  8
    service_2_19_1  unique_nonzero_owner_419  1
    service_2_19_1  service_visit_def_1549  1
    service_2_19_1  free_load_conservation_1550  1
    service_2_19_2  unique_nonzero_owner_420  1
    service_2_19_2  service_visit_def_1549  1
    service_2_19_2  free_load_conservation_1550  2
    service_2_19_3  unique_nonzero_owner_421  1
    service_2_19_3  service_visit_def_1549  1
    service_2_19_3  free_load_conservation_1550  3
    service_2_19_4  unique_nonzero_owner_422  1
    service_2_19_4  service_visit_def_1549  1
    service_2_19_4  free_load_conservation_1550  4
    service_2_19_5  unique_nonzero_owner_423  1
    service_2_19_5  service_visit_def_1549  1
    service_2_19_5  free_load_conservation_1550  5
    service_2_19_6  unique_nonzero_owner_424  1
    service_2_19_6  service_visit_def_1549  1
    service_2_19_6  free_load_conservation_1550  6
    service_2_19_7  unique_nonzero_owner_425  1
    service_2_19_7  service_visit_def_1549  1
    service_2_19_7  free_load_conservation_1550  7
    service_2_19_8  unique_nonzero_owner_426  1
    service_2_19_8  service_visit_def_1549  1
    service_2_19_8  free_load_conservation_1550  8
    service_0_5_0  unique_nonzero_owner_427  1
    service_0_5_0  service_visit_def_865  1
    service_0_5_0  free_load_conservation_866  -2
    service_0_5_0  original_T_including_depot_unload_871  240
    service_0_5_1  unique_nonzero_owner_428  1
    service_0_5_1  service_visit_def_865  1
    service_0_5_1  free_load_conservation_866  -1
    service_0_5_1  original_T_including_depot_unload_871  120
    service_0_5_3  unique_nonzero_owner_429  1
    service_0_5_3  service_visit_def_865  1
    service_0_5_3  free_load_conservation_866  1
    service_0_5_4  unique_nonzero_owner_430  1
    service_0_5_4  service_visit_def_865  1
    service_0_5_4  free_load_conservation_866  2
    service_0_5_5  unique_nonzero_owner_431  1
    service_0_5_5  service_visit_def_865  1
    service_0_5_5  free_load_conservation_866  3
    service_0_5_6  unique_nonzero_owner_432  1
    service_0_5_6  service_visit_def_865  1
    service_0_5_6  free_load_conservation_866  4
    service_0_5_7  unique_nonzero_owner_433  1
    service_0_5_7  service_visit_def_865  1
    service_0_5_7  free_load_conservation_866  5
    service_0_5_8  unique_nonzero_owner_434  1
    service_0_5_8  service_visit_def_865  1
    service_0_5_8  free_load_conservation_866  6
    service_0_5_9  unique_nonzero_owner_435  1
    service_0_5_9  service_visit_def_865  1
    service_0_5_9  free_load_conservation_866  7
    service_0_5_10  unique_nonzero_owner_436  1
    service_0_5_10  service_visit_def_865  1
    service_0_5_10  free_load_conservation_866  8
    service_0_5_11  unique_nonzero_owner_437  1
    service_0_5_11  service_visit_def_865  1
    service_0_5_11  free_load_conservation_866  9
    service_0_5_12  unique_nonzero_owner_438  1
    service_0_5_12  service_visit_def_865  1
    service_0_5_12  free_load_conservation_866  10
    service_0_5_13  unique_nonzero_owner_439  1
    service_0_5_13  service_visit_def_865  1
    service_0_5_13  free_load_conservation_866  11
    service_0_5_14  unique_nonzero_owner_440  1
    service_0_5_14  service_visit_def_865  1
    service_0_5_14  free_load_conservation_866  12
    service_0_5_15  unique_nonzero_owner_441  1
    service_0_5_15  service_visit_def_865  1
    service_0_5_15  free_load_conservation_866  13
    service_0_5_16  unique_nonzero_owner_442  1
    service_0_5_16  service_visit_def_865  1
    service_0_5_16  free_load_conservation_866  14
    service_1_5_0  unique_nonzero_owner_427  1
    service_1_5_0  service_visit_def_1237  1
    service_1_5_0  free_load_conservation_1238  -2
    service_1_5_0  original_T_including_depot_unload_1242  240
    service_1_5_1  unique_nonzero_owner_428  1
    service_1_5_1  service_visit_def_1237  1
    service_1_5_1  free_load_conservation_1238  -1
    service_1_5_1  original_T_including_depot_unload_1242  120
    service_1_5_3  unique_nonzero_owner_429  1
    service_1_5_3  service_visit_def_1237  1
    service_1_5_3  free_load_conservation_1238  1
    service_1_5_4  unique_nonzero_owner_430  1
    service_1_5_4  service_visit_def_1237  1
    service_1_5_4  free_load_conservation_1238  2
    service_1_5_5  unique_nonzero_owner_431  1
    service_1_5_5  service_visit_def_1237  1
    service_1_5_5  free_load_conservation_1238  3
    service_1_5_6  unique_nonzero_owner_432  1
    service_1_5_6  service_visit_def_1237  1
    service_1_5_6  free_load_conservation_1238  4
    service_1_5_7  unique_nonzero_owner_433  1
    service_1_5_7  service_visit_def_1237  1
    service_1_5_7  free_load_conservation_1238  5
    service_1_5_8  unique_nonzero_owner_434  1
    service_1_5_8  service_visit_def_1237  1
    service_1_5_8  free_load_conservation_1238  6
    service_1_5_9  unique_nonzero_owner_435  1
    service_1_5_9  service_visit_def_1237  1
    service_1_5_9  free_load_conservation_1238  7
    service_1_5_10  unique_nonzero_owner_436  1
    service_1_5_10  service_visit_def_1237  1
    service_1_5_10  free_load_conservation_1238  8
    service_1_5_11  unique_nonzero_owner_437  1
    service_1_5_11  service_visit_def_1237  1
    service_1_5_11  free_load_conservation_1238  9
    service_1_5_12  unique_nonzero_owner_438  1
    service_1_5_12  service_visit_def_1237  1
    service_1_5_12  free_load_conservation_1238  10
    service_1_5_13  unique_nonzero_owner_439  1
    service_1_5_13  service_visit_def_1237  1
    service_1_5_13  free_load_conservation_1238  11
    service_1_5_14  unique_nonzero_owner_440  1
    service_1_5_14  service_visit_def_1237  1
    service_1_5_14  free_load_conservation_1238  12
    service_1_5_15  unique_nonzero_owner_441  1
    service_1_5_15  service_visit_def_1237  1
    service_1_5_15  free_load_conservation_1238  13
    service_1_5_16  unique_nonzero_owner_442  1
    service_1_5_16  service_visit_def_1237  1
    service_1_5_16  free_load_conservation_1238  14
    service_2_5_0  unique_nonzero_owner_427  1
    service_2_5_0  service_visit_def_1555  1
    service_2_5_0  free_load_conservation_1556  -2
    service_2_5_0  original_T_including_depot_unload_1559  240
    service_2_5_1  unique_nonzero_owner_428  1
    service_2_5_1  service_visit_def_1555  1
    service_2_5_1  free_load_conservation_1556  -1
    service_2_5_1  original_T_including_depot_unload_1559  120
    service_2_5_3  unique_nonzero_owner_429  1
    service_2_5_3  service_visit_def_1555  1
    service_2_5_3  free_load_conservation_1556  1
    service_2_5_4  unique_nonzero_owner_430  1
    service_2_5_4  service_visit_def_1555  1
    service_2_5_4  free_load_conservation_1556  2
    service_2_5_5  unique_nonzero_owner_431  1
    service_2_5_5  service_visit_def_1555  1
    service_2_5_5  free_load_conservation_1556  3
    service_2_5_6  unique_nonzero_owner_432  1
    service_2_5_6  service_visit_def_1555  1
    service_2_5_6  free_load_conservation_1556  4
    service_2_5_7  unique_nonzero_owner_433  1
    service_2_5_7  service_visit_def_1555  1
    service_2_5_7  free_load_conservation_1556  5
    service_2_5_8  unique_nonzero_owner_434  1
    service_2_5_8  service_visit_def_1555  1
    service_2_5_8  free_load_conservation_1556  6
    service_2_5_9  unique_nonzero_owner_435  1
    service_2_5_9  service_visit_def_1555  1
    service_2_5_9  free_load_conservation_1556  7
    service_2_5_10  unique_nonzero_owner_436  1
    service_2_5_10  service_visit_def_1555  1
    service_2_5_10  free_load_conservation_1556  8
    service_2_5_11  unique_nonzero_owner_437  1
    service_2_5_11  service_visit_def_1555  1
    service_2_5_11  free_load_conservation_1556  9
    service_2_5_12  unique_nonzero_owner_438  1
    service_2_5_12  service_visit_def_1555  1
    service_2_5_12  free_load_conservation_1556  10
    service_2_5_13  unique_nonzero_owner_439  1
    service_2_5_13  service_visit_def_1555  1
    service_2_5_13  free_load_conservation_1556  11
    service_2_5_14  unique_nonzero_owner_440  1
    service_2_5_14  service_visit_def_1555  1
    service_2_5_14  free_load_conservation_1556  12
    service_2_5_15  unique_nonzero_owner_441  1
    service_2_5_15  service_visit_def_1555  1
    service_2_5_15  free_load_conservation_1556  13
    service_2_5_16  unique_nonzero_owner_442  1
    service_2_5_16  service_visit_def_1555  1
    service_2_5_16  free_load_conservation_1556  14
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_784  -1
    visit_0_1  in_degree_785  -1
    visit_0_1  order_active_lb_786  -1
    visit_0_1  order_active_ub_787  -13
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_465  -1
    order_0_1  connected_order_arc_467  -1
    order_0_1  connected_order_arc_469  -1
    order_0_1  connected_order_arc_471  -1
    order_0_1  connected_order_arc_473  -1
    order_0_1  connected_order_arc_475  -1
    order_0_1  connected_order_arc_477  -1
    order_0_1  connected_order_arc_479  -1
    order_0_1  connected_order_arc_481  -1
    order_0_1  connected_order_arc_484  1
    order_0_1  connected_order_arc_509  1
    order_0_1  connected_order_arc_534  1
    order_0_1  connected_order_arc_559  1
    order_0_1  connected_order_arc_584  1
    order_0_1  connected_order_arc_609  1
    order_0_1  connected_order_arc_634  1
    order_0_1  connected_order_arc_659  1
    order_0_1  connected_order_arc_684  1
    order_0_1  connected_order_arc_709  1
    order_0_1  connected_order_arc_734  1
    order_0_1  connected_order_arc_759  1
    order_0_1  order_active_lb_786  1
    order_0_1  order_active_ub_787  1
    order_0_1  fixed_segment_relative_order_867  -1
    visit_0_2  out_degree_791  -1
    visit_0_2  in_degree_792  -1
    visit_0_2  order_active_lb_793  -1
    visit_0_2  order_active_ub_794  -13
    order_0_2  connected_order_arc_459  1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_488  -1
    order_0_2  connected_order_arc_490  -1
    order_0_2  connected_order_arc_492  -1
    order_0_2  connected_order_arc_494  -1
    order_0_2  connected_order_arc_496  -1
    order_0_2  connected_order_arc_498  -1
    order_0_2  connected_order_arc_500  -1
    order_0_2  connected_order_arc_502  -1
    order_0_2  connected_order_arc_504  -1
    order_0_2  connected_order_arc_506  -1
    order_0_2  connected_order_arc_511  1
    order_0_2  connected_order_arc_536  1
    order_0_2  connected_order_arc_561  1
    order_0_2  connected_order_arc_586  1
    order_0_2  connected_order_arc_611  1
    order_0_2  connected_order_arc_636  1
    order_0_2  connected_order_arc_661  1
    order_0_2  connected_order_arc_686  1
    order_0_2  connected_order_arc_711  1
    order_0_2  connected_order_arc_736  1
    order_0_2  connected_order_arc_761  1
    order_0_2  order_active_lb_793  1
    order_0_2  order_active_ub_794  1
    order_0_2  fixed_segment_relative_order_867  1
    order_0_2  fixed_segment_relative_order_868  -1
    visit_0_3  out_degree_798  -1
    visit_0_3  in_degree_799  -1
    visit_0_3  order_active_lb_800  -1
    visit_0_3  order_active_ub_801  -13
    order_0_3  connected_order_arc_461  1
    order_0_3  connected_order_arc_486  1
    order_0_3  connected_order_arc_509  -1
    order_0_3  connected_order_arc_511  -1
    order_0_3  connected_order_arc_513  -1
    order_0_3  connected_order_arc_515  -1
    order_0_3  connected_order_arc_517  -1
    order_0_3  connected_order_arc_519  -1
    order_0_3  connected_order_arc_521  -1
    order_0_3  connected_order_arc_523  -1
    order_0_3  connected_order_arc_525  -1
    order_0_3  connected_order_arc_527  -1
    order_0_3  connected_order_arc_529  -1
    order_0_3  connected_order_arc_531  -1
    order_0_3  connected_order_arc_538  1
    order_0_3  connected_order_arc_563  1
    order_0_3  connected_order_arc_588  1
    order_0_3  connected_order_arc_613  1
    order_0_3  connected_order_arc_638  1
    order_0_3  connected_order_arc_663  1
    order_0_3  connected_order_arc_688  1
    order_0_3  connected_order_arc_713  1
    order_0_3  connected_order_arc_738  1
    order_0_3  connected_order_arc_763  1
    order_0_3  order_active_lb_800  1
    order_0_3  order_active_ub_801  1
    order_0_3  fixed_segment_relative_order_868  1
    order_0_3  fixed_segment_relative_order_869  -1
    visit_0_4  out_degree_805  -1
    visit_0_4  in_degree_806  -1
    visit_0_4  order_active_lb_807  -1
    visit_0_4  order_active_ub_808  -13
    order_0_4  connected_order_arc_463  1
    order_0_4  connected_order_arc_488  1
    order_0_4  connected_order_arc_513  1
    order_0_4  connected_order_arc_534  -1
    order_0_4  connected_order_arc_536  -1
    order_0_4  connected_order_arc_538  -1
    order_0_4  connected_order_arc_540  -1
    order_0_4  connected_order_arc_542  -1
    order_0_4  connected_order_arc_544  -1
    order_0_4  connected_order_arc_546  -1
    order_0_4  connected_order_arc_548  -1
    order_0_4  connected_order_arc_550  -1
    order_0_4  connected_order_arc_552  -1
    order_0_4  connected_order_arc_554  -1
    order_0_4  connected_order_arc_556  -1
    order_0_4  connected_order_arc_565  1
    order_0_4  connected_order_arc_590  1
    order_0_4  connected_order_arc_615  1
    order_0_4  connected_order_arc_640  1
    order_0_4  connected_order_arc_665  1
    order_0_4  connected_order_arc_690  1
    order_0_4  connected_order_arc_715  1
    order_0_4  connected_order_arc_740  1
    order_0_4  connected_order_arc_765  1
    order_0_4  order_active_lb_807  1
    order_0_4  order_active_ub_808  1
    order_0_4  fixed_segment_relative_order_869  1
    order_0_4  fixed_segment_relative_order_870  -1
    visit_0_5  out_degree_812  -1
    visit_0_5  in_degree_813  -1
    visit_0_5  order_active_lb_814  -1
    visit_0_5  order_active_ub_815  -13
    order_0_5  connected_order_arc_465  1
    order_0_5  connected_order_arc_490  1
    order_0_5  connected_order_arc_515  1
    order_0_5  connected_order_arc_540  1
    order_0_5  connected_order_arc_559  -1
    order_0_5  connected_order_arc_561  -1
    order_0_5  connected_order_arc_563  -1
    order_0_5  connected_order_arc_565  -1
    order_0_5  connected_order_arc_567  -1
    order_0_5  connected_order_arc_569  -1
    order_0_5  connected_order_arc_571  -1
    order_0_5  connected_order_arc_573  -1
    order_0_5  connected_order_arc_575  -1
    order_0_5  connected_order_arc_577  -1
    order_0_5  connected_order_arc_579  -1
    order_0_5  connected_order_arc_581  -1
    order_0_5  connected_order_arc_592  1
    order_0_5  connected_order_arc_617  1
    order_0_5  connected_order_arc_642  1
    order_0_5  connected_order_arc_667  1
    order_0_5  connected_order_arc_692  1
    order_0_5  connected_order_arc_717  1
    order_0_5  connected_order_arc_742  1
    order_0_5  connected_order_arc_767  1
    order_0_5  order_active_lb_814  1
    order_0_5  order_active_ub_815  1
    order_0_5  fixed_segment_relative_order_870  1
    visit_0_13  out_degree_819  -1
    visit_0_13  in_degree_820  -1
    visit_0_13  order_active_lb_821  -1
    visit_0_13  order_active_ub_822  -13
    visit_0_13  service_visit_def_823  -1
    order_0_13  connected_order_arc_467  1
    order_0_13  connected_order_arc_492  1
    order_0_13  connected_order_arc_517  1
    order_0_13  connected_order_arc_542  1
    order_0_13  connected_order_arc_567  1
    order_0_13  connected_order_arc_584  -1
    order_0_13  connected_order_arc_586  -1
    order_0_13  connected_order_arc_588  -1
    order_0_13  connected_order_arc_590  -1
    order_0_13  connected_order_arc_592  -1
    order_0_13  connected_order_arc_594  -1
    order_0_13  connected_order_arc_596  -1
    order_0_13  connected_order_arc_598  -1
    order_0_13  connected_order_arc_600  -1
    order_0_13  connected_order_arc_602  -1
    order_0_13  connected_order_arc_604  -1
    order_0_13  connected_order_arc_606  -1
    order_0_13  connected_order_arc_619  1
    order_0_13  connected_order_arc_644  1
    order_0_13  connected_order_arc_669  1
    order_0_13  connected_order_arc_694  1
    order_0_13  connected_order_arc_719  1
    order_0_13  connected_order_arc_744  1
    order_0_13  connected_order_arc_769  1
    order_0_13  order_active_lb_821  1
    order_0_13  order_active_ub_822  1
    visit_0_14  out_degree_825  -1
    visit_0_14  in_degree_826  -1
    visit_0_14  order_active_lb_827  -1
    visit_0_14  order_active_ub_828  -13
    visit_0_14  service_visit_def_829  -1
    order_0_14  connected_order_arc_469  1
    order_0_14  connected_order_arc_494  1
    order_0_14  connected_order_arc_519  1
    order_0_14  connected_order_arc_544  1
    order_0_14  connected_order_arc_569  1
    order_0_14  connected_order_arc_594  1
    order_0_14  connected_order_arc_609  -1
    order_0_14  connected_order_arc_611  -1
    order_0_14  connected_order_arc_613  -1
    order_0_14  connected_order_arc_615  -1
    order_0_14  connected_order_arc_617  -1
    order_0_14  connected_order_arc_619  -1
    order_0_14  connected_order_arc_621  -1
    order_0_14  connected_order_arc_623  -1
    order_0_14  connected_order_arc_625  -1
    order_0_14  connected_order_arc_627  -1
    order_0_14  connected_order_arc_629  -1
    order_0_14  connected_order_arc_631  -1
    order_0_14  connected_order_arc_646  1
    order_0_14  connected_order_arc_671  1
    order_0_14  connected_order_arc_696  1
    order_0_14  connected_order_arc_721  1
    order_0_14  connected_order_arc_746  1
    order_0_14  connected_order_arc_771  1
    order_0_14  order_active_lb_827  1
    order_0_14  order_active_ub_828  1
    visit_0_15  out_degree_831  -1
    visit_0_15  in_degree_832  -1
    visit_0_15  order_active_lb_833  -1
    visit_0_15  order_active_ub_834  -13
    visit_0_15  service_visit_def_835  -1
    order_0_15  connected_order_arc_471  1
    order_0_15  connected_order_arc_496  1
    order_0_15  connected_order_arc_521  1
    order_0_15  connected_order_arc_546  1
    order_0_15  connected_order_arc_571  1
    order_0_15  connected_order_arc_596  1
    order_0_15  connected_order_arc_621  1
    order_0_15  connected_order_arc_634  -1
    order_0_15  connected_order_arc_636  -1
    order_0_15  connected_order_arc_638  -1
    order_0_15  connected_order_arc_640  -1
    order_0_15  connected_order_arc_642  -1
    order_0_15  connected_order_arc_644  -1
    order_0_15  connected_order_arc_646  -1
    order_0_15  connected_order_arc_648  -1
    order_0_15  connected_order_arc_650  -1
    order_0_15  connected_order_arc_652  -1
    order_0_15  connected_order_arc_654  -1
    order_0_15  connected_order_arc_656  -1
    order_0_15  connected_order_arc_673  1
    order_0_15  connected_order_arc_698  1
    order_0_15  connected_order_arc_723  1
    order_0_15  connected_order_arc_748  1
    order_0_15  connected_order_arc_773  1
    order_0_15  order_active_lb_833  1
    order_0_15  order_active_ub_834  1
    visit_0_16  out_degree_837  -1
    visit_0_16  in_degree_838  -1
    visit_0_16  order_active_lb_839  -1
    visit_0_16  order_active_ub_840  -13
    visit_0_16  service_visit_def_841  -1
    order_0_16  connected_order_arc_473  1
    order_0_16  connected_order_arc_498  1
    order_0_16  connected_order_arc_523  1
    order_0_16  connected_order_arc_548  1
    order_0_16  connected_order_arc_573  1
    order_0_16  connected_order_arc_598  1
    order_0_16  connected_order_arc_623  1
    order_0_16  connected_order_arc_648  1
    order_0_16  connected_order_arc_659  -1
    order_0_16  connected_order_arc_661  -1
    order_0_16  connected_order_arc_663  -1
    order_0_16  connected_order_arc_665  -1
    order_0_16  connected_order_arc_667  -1
    order_0_16  connected_order_arc_669  -1
    order_0_16  connected_order_arc_671  -1
    order_0_16  connected_order_arc_673  -1
    order_0_16  connected_order_arc_675  -1
    order_0_16  connected_order_arc_677  -1
    order_0_16  connected_order_arc_679  -1
    order_0_16  connected_order_arc_681  -1
    order_0_16  connected_order_arc_700  1
    order_0_16  connected_order_arc_725  1
    order_0_16  connected_order_arc_750  1
    order_0_16  connected_order_arc_775  1
    order_0_16  order_active_lb_839  1
    order_0_16  order_active_ub_840  1
    visit_0_17  out_degree_843  -1
    visit_0_17  in_degree_844  -1
    visit_0_17  order_active_lb_845  -1
    visit_0_17  order_active_ub_846  -13
    visit_0_17  service_visit_def_847  -1
    order_0_17  connected_order_arc_475  1
    order_0_17  connected_order_arc_500  1
    order_0_17  connected_order_arc_525  1
    order_0_17  connected_order_arc_550  1
    order_0_17  connected_order_arc_575  1
    order_0_17  connected_order_arc_600  1
    order_0_17  connected_order_arc_625  1
    order_0_17  connected_order_arc_650  1
    order_0_17  connected_order_arc_675  1
    order_0_17  connected_order_arc_684  -1
    order_0_17  connected_order_arc_686  -1
    order_0_17  connected_order_arc_688  -1
    order_0_17  connected_order_arc_690  -1
    order_0_17  connected_order_arc_692  -1
    order_0_17  connected_order_arc_694  -1
    order_0_17  connected_order_arc_696  -1
    order_0_17  connected_order_arc_698  -1
    order_0_17  connected_order_arc_700  -1
    order_0_17  connected_order_arc_702  -1
    order_0_17  connected_order_arc_704  -1
    order_0_17  connected_order_arc_706  -1
    order_0_17  connected_order_arc_727  1
    order_0_17  connected_order_arc_752  1
    order_0_17  connected_order_arc_777  1
    order_0_17  order_active_lb_845  1
    order_0_17  order_active_ub_846  1
    visit_0_18  out_degree_849  -1
    visit_0_18  in_degree_850  -1
    visit_0_18  order_active_lb_851  -1
    visit_0_18  order_active_ub_852  -13
    visit_0_18  service_visit_def_853  -1
    order_0_18  connected_order_arc_477  1
    order_0_18  connected_order_arc_502  1
    order_0_18  connected_order_arc_527  1
    order_0_18  connected_order_arc_552  1
    order_0_18  connected_order_arc_577  1
    order_0_18  connected_order_arc_602  1
    order_0_18  connected_order_arc_627  1
    order_0_18  connected_order_arc_652  1
    order_0_18  connected_order_arc_677  1
    order_0_18  connected_order_arc_702  1
    order_0_18  connected_order_arc_709  -1
    order_0_18  connected_order_arc_711  -1
    order_0_18  connected_order_arc_713  -1
    order_0_18  connected_order_arc_715  -1
    order_0_18  connected_order_arc_717  -1
    order_0_18  connected_order_arc_719  -1
    order_0_18  connected_order_arc_721  -1
    order_0_18  connected_order_arc_723  -1
    order_0_18  connected_order_arc_725  -1
    order_0_18  connected_order_arc_727  -1
    order_0_18  connected_order_arc_729  -1
    order_0_18  connected_order_arc_731  -1
    order_0_18  connected_order_arc_754  1
    order_0_18  connected_order_arc_779  1
    order_0_18  order_active_lb_851  1
    order_0_18  order_active_ub_852  1
    visit_0_19  out_degree_855  -1
    visit_0_19  in_degree_856  -1
    visit_0_19  order_active_lb_857  -1
    visit_0_19  order_active_ub_858  -13
    visit_0_19  service_visit_def_859  -1
    order_0_19  connected_order_arc_479  1
    order_0_19  connected_order_arc_504  1
    order_0_19  connected_order_arc_529  1
    order_0_19  connected_order_arc_554  1
    order_0_19  connected_order_arc_579  1
    order_0_19  connected_order_arc_604  1
    order_0_19  connected_order_arc_629  1
    order_0_19  connected_order_arc_654  1
    order_0_19  connected_order_arc_679  1
    order_0_19  connected_order_arc_704  1
    order_0_19  connected_order_arc_729  1
    order_0_19  connected_order_arc_734  -1
    order_0_19  connected_order_arc_736  -1
    order_0_19  connected_order_arc_738  -1
    order_0_19  connected_order_arc_740  -1
    order_0_19  connected_order_arc_742  -1
    order_0_19  connected_order_arc_744  -1
    order_0_19  connected_order_arc_746  -1
    order_0_19  connected_order_arc_748  -1
    order_0_19  connected_order_arc_750  -1
    order_0_19  connected_order_arc_752  -1
    order_0_19  connected_order_arc_754  -1
    order_0_19  connected_order_arc_756  -1
    order_0_19  connected_order_arc_781  1
    order_0_19  order_active_lb_857  1
    order_0_19  order_active_ub_858  1
    visit_0_20  out_degree_861  -1
    visit_0_20  in_degree_862  -1
    visit_0_20  order_active_lb_863  -1
    visit_0_20  order_active_ub_864  -13
    visit_0_20  service_visit_def_865  -1
    order_0_20  connected_order_arc_481  1
    order_0_20  connected_order_arc_506  1
    order_0_20  connected_order_arc_531  1
    order_0_20  connected_order_arc_556  1
    order_0_20  connected_order_arc_581  1
    order_0_20  connected_order_arc_606  1
    order_0_20  connected_order_arc_631  1
    order_0_20  connected_order_arc_656  1
    order_0_20  connected_order_arc_681  1
    order_0_20  connected_order_arc_706  1
    order_0_20  connected_order_arc_731  1
    order_0_20  connected_order_arc_756  1
    order_0_20  connected_order_arc_759  -1
    order_0_20  connected_order_arc_761  -1
    order_0_20  connected_order_arc_763  -1
    order_0_20  connected_order_arc_765  -1
    order_0_20  connected_order_arc_767  -1
    order_0_20  connected_order_arc_769  -1
    order_0_20  connected_order_arc_771  -1
    order_0_20  connected_order_arc_773  -1
    order_0_20  connected_order_arc_775  -1
    order_0_20  connected_order_arc_777  -1
    order_0_20  connected_order_arc_779  -1
    order_0_20  connected_order_arc_781  -1
    order_0_20  order_active_lb_863  1
    order_0_20  order_active_ub_864  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_443  -20
    arc_0_0_0  depot_departure_or_bypass_782  1
    arc_0_0_0  depot_return_or_bypass_783  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_443  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_444  -20
    arc_0_0_1  depot_departure_or_bypass_782  1
    arc_0_0_1  in_degree_785  1
    arc_0_0_1  original_T_including_depot_unload_871  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_444  1
    load_0_0_1  segment_load_conservation_788  -1
    load_0_0_1  segment_prefix_lb_789  1
    load_0_0_1  segment_prefix_ub_790  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_445  -20
    arc_0_0_2  depot_departure_or_bypass_782  1
    arc_0_0_2  in_degree_792  1
    arc_0_0_2  original_T_including_depot_unload_871  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_445  1
    load_0_0_2  segment_load_conservation_795  -1
    load_0_0_2  segment_prefix_lb_796  1
    load_0_0_2  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_446  -20
    arc_0_0_3  depot_departure_or_bypass_782  1
    arc_0_0_3  in_degree_799  1
    arc_0_0_3  original_T_including_depot_unload_871  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_446  1
    load_0_0_3  segment_load_conservation_802  -1
    load_0_0_3  segment_prefix_lb_803  1
    load_0_0_3  segment_prefix_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_447  -20
    arc_0_0_4  depot_departure_or_bypass_782  1
    arc_0_0_4  in_degree_806  1
    arc_0_0_4  original_T_including_depot_unload_871  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_447  1
    load_0_0_4  segment_load_conservation_809  -1
    load_0_0_4  segment_prefix_lb_810  1
    load_0_0_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_448  -20
    arc_0_0_5  depot_departure_or_bypass_782  1
    arc_0_0_5  in_degree_813  1
    arc_0_0_5  original_T_including_depot_unload_871  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_448  1
    load_0_0_5  segment_load_conservation_816  -1
    load_0_0_5  segment_prefix_lb_817  1
    load_0_0_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_449  -20
    arc_0_0_13  depot_departure_or_bypass_782  1
    arc_0_0_13  in_degree_820  1
    arc_0_0_13  original_T_including_depot_unload_871  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_449  1
    load_0_0_13  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_450  -20
    arc_0_0_14  depot_departure_or_bypass_782  1
    arc_0_0_14  in_degree_826  1
    arc_0_0_14  original_T_including_depot_unload_871  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_450  1
    load_0_0_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_451  -20
    arc_0_0_15  depot_departure_or_bypass_782  1
    arc_0_0_15  in_degree_832  1
    arc_0_0_15  original_T_including_depot_unload_871  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_451  1
    load_0_0_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_452  -20
    arc_0_0_16  depot_departure_or_bypass_782  1
    arc_0_0_16  in_degree_838  1
    arc_0_0_16  original_T_including_depot_unload_871  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_452  1
    load_0_0_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_453  -20
    arc_0_0_17  depot_departure_or_bypass_782  1
    arc_0_0_17  in_degree_844  1
    arc_0_0_17  original_T_including_depot_unload_871  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_453  1
    load_0_0_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_454  -20
    arc_0_0_18  depot_departure_or_bypass_782  1
    arc_0_0_18  in_degree_850  1
    arc_0_0_18  original_T_including_depot_unload_871  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_454  1
    load_0_0_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_455  -20
    arc_0_0_19  depot_departure_or_bypass_782  1
    arc_0_0_19  in_degree_856  1
    arc_0_0_19  original_T_including_depot_unload_871  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_455  1
    load_0_0_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_456  -20
    arc_0_0_20  depot_departure_or_bypass_782  1
    arc_0_0_20  in_degree_862  1
    arc_0_0_20  original_T_including_depot_unload_871  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_456  1
    load_0_0_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_457  -20
    arc_0_1_0  depot_return_or_bypass_783  1
    arc_0_1_0  out_degree_784  1
    arc_0_1_0  original_T_including_depot_unload_871  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_457  1
    load_0_1_0  segment_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_458  -20
    arc_0_1_2  connected_order_arc_459  -14
    arc_0_1_2  out_degree_784  1
    arc_0_1_2  in_degree_792  1
    arc_0_1_2  original_T_including_depot_unload_871  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_458  1
    load_0_1_2  segment_load_conservation_788  1
    load_0_1_2  segment_load_conservation_795  -1
    load_0_1_2  segment_prefix_lb_796  1
    load_0_1_2  segment_prefix_ub_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_460  -20
    arc_0_1_3  connected_order_arc_461  -14
    arc_0_1_3  out_degree_784  1
    arc_0_1_3  in_degree_799  1
    arc_0_1_3  original_T_including_depot_unload_871  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_460  1
    load_0_1_3  segment_load_conservation_788  1
    load_0_1_3  segment_load_conservation_802  -1
    load_0_1_3  segment_prefix_lb_803  1
    load_0_1_3  segment_prefix_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_462  -20
    arc_0_1_4  connected_order_arc_463  -14
    arc_0_1_4  out_degree_784  1
    arc_0_1_4  in_degree_806  1
    arc_0_1_4  original_T_including_depot_unload_871  9.1345700487521981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_462  1
    load_0_1_4  segment_load_conservation_788  1
    load_0_1_4  segment_load_conservation_809  -1
    load_0_1_4  segment_prefix_lb_810  1
    load_0_1_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_464  -20
    arc_0_1_5  connected_order_arc_465  -14
    arc_0_1_5  out_degree_784  1
    arc_0_1_5  in_degree_813  1
    arc_0_1_5  original_T_including_depot_unload_871  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_464  1
    load_0_1_5  segment_load_conservation_788  1
    load_0_1_5  segment_load_conservation_816  -1
    load_0_1_5  segment_prefix_lb_817  1
    load_0_1_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_466  -20
    arc_0_1_13  connected_order_arc_467  -14
    arc_0_1_13  out_degree_784  1
    arc_0_1_13  in_degree_820  1
    arc_0_1_13  original_T_including_depot_unload_871  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_466  1
    load_0_1_13  segment_load_conservation_788  1
    load_0_1_13  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_468  -20
    arc_0_1_14  connected_order_arc_469  -14
    arc_0_1_14  out_degree_784  1
    arc_0_1_14  in_degree_826  1
    arc_0_1_14  original_T_including_depot_unload_871  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_468  1
    load_0_1_14  segment_load_conservation_788  1
    load_0_1_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_470  -20
    arc_0_1_15  connected_order_arc_471  -14
    arc_0_1_15  out_degree_784  1
    arc_0_1_15  in_degree_832  1
    arc_0_1_15  original_T_including_depot_unload_871  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_470  1
    load_0_1_15  segment_load_conservation_788  1
    load_0_1_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_472  -20
    arc_0_1_16  connected_order_arc_473  -14
    arc_0_1_16  out_degree_784  1
    arc_0_1_16  in_degree_838  1
    arc_0_1_16  original_T_including_depot_unload_871  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_472  1
    load_0_1_16  segment_load_conservation_788  1
    load_0_1_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_474  -20
    arc_0_1_17  connected_order_arc_475  -14
    arc_0_1_17  out_degree_784  1
    arc_0_1_17  in_degree_844  1
    arc_0_1_17  original_T_including_depot_unload_871  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_474  1
    load_0_1_17  segment_load_conservation_788  1
    load_0_1_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_476  -20
    arc_0_1_18  connected_order_arc_477  -14
    arc_0_1_18  out_degree_784  1
    arc_0_1_18  in_degree_850  1
    arc_0_1_18  original_T_including_depot_unload_871  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_476  1
    load_0_1_18  segment_load_conservation_788  1
    load_0_1_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_478  -20
    arc_0_1_19  connected_order_arc_479  -14
    arc_0_1_19  out_degree_784  1
    arc_0_1_19  in_degree_856  1
    arc_0_1_19  original_T_including_depot_unload_871  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_478  1
    load_0_1_19  segment_load_conservation_788  1
    load_0_1_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_480  -20
    arc_0_1_20  connected_order_arc_481  -14
    arc_0_1_20  out_degree_784  1
    arc_0_1_20  in_degree_862  1
    arc_0_1_20  original_T_including_depot_unload_871  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_480  1
    load_0_1_20  segment_load_conservation_788  1
    load_0_1_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_482  -20
    arc_0_2_0  depot_return_or_bypass_783  1
    arc_0_2_0  out_degree_791  1
    arc_0_2_0  original_T_including_depot_unload_871  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_482  1
    load_0_2_0  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_483  -20
    arc_0_2_1  connected_order_arc_484  -14
    arc_0_2_1  in_degree_785  1
    arc_0_2_1  out_degree_791  1
    arc_0_2_1  original_T_including_depot_unload_871  2.1911621128640562e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_483  1
    load_0_2_1  segment_load_conservation_788  -1
    load_0_2_1  segment_prefix_lb_789  1
    load_0_2_1  segment_prefix_ub_790  1
    load_0_2_1  segment_load_conservation_795  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_485  -20
    arc_0_2_3  connected_order_arc_486  -14
    arc_0_2_3  out_degree_791  1
    arc_0_2_3  in_degree_799  1
    arc_0_2_3  original_T_including_depot_unload_871  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_485  1
    load_0_2_3  segment_load_conservation_795  1
    load_0_2_3  segment_load_conservation_802  -1
    load_0_2_3  segment_prefix_lb_803  1
    load_0_2_3  segment_prefix_ub_804  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_487  -20
    arc_0_2_4  connected_order_arc_488  -14
    arc_0_2_4  out_degree_791  1
    arc_0_2_4  in_degree_806  1
    arc_0_2_4  original_T_including_depot_unload_871  750.067997850428
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_487  1
    load_0_2_4  segment_load_conservation_795  1
    load_0_2_4  segment_load_conservation_809  -1
    load_0_2_4  segment_prefix_lb_810  1
    load_0_2_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_489  -20
    arc_0_2_5  connected_order_arc_490  -14
    arc_0_2_5  out_degree_791  1
    arc_0_2_5  in_degree_813  1
    arc_0_2_5  original_T_including_depot_unload_871  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_489  1
    load_0_2_5  segment_load_conservation_795  1
    load_0_2_5  segment_load_conservation_816  -1
    load_0_2_5  segment_prefix_lb_817  1
    load_0_2_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_491  -20
    arc_0_2_13  connected_order_arc_492  -14
    arc_0_2_13  out_degree_791  1
    arc_0_2_13  in_degree_820  1
    arc_0_2_13  original_T_including_depot_unload_871  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_491  1
    load_0_2_13  segment_load_conservation_795  1
    load_0_2_13  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_493  -20
    arc_0_2_14  connected_order_arc_494  -14
    arc_0_2_14  out_degree_791  1
    arc_0_2_14  in_degree_826  1
    arc_0_2_14  original_T_including_depot_unload_871  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_493  1
    load_0_2_14  segment_load_conservation_795  1
    load_0_2_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_495  -20
    arc_0_2_15  connected_order_arc_496  -14
    arc_0_2_15  out_degree_791  1
    arc_0_2_15  in_degree_832  1
    arc_0_2_15  original_T_including_depot_unload_871  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_495  1
    load_0_2_15  segment_load_conservation_795  1
    load_0_2_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_497  -20
    arc_0_2_16  connected_order_arc_498  -14
    arc_0_2_16  out_degree_791  1
    arc_0_2_16  in_degree_838  1
    arc_0_2_16  original_T_including_depot_unload_871  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_497  1
    load_0_2_16  segment_load_conservation_795  1
    load_0_2_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_499  -20
    arc_0_2_17  connected_order_arc_500  -14
    arc_0_2_17  out_degree_791  1
    arc_0_2_17  in_degree_844  1
    arc_0_2_17  original_T_including_depot_unload_871  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_499  1
    load_0_2_17  segment_load_conservation_795  1
    load_0_2_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_501  -20
    arc_0_2_18  connected_order_arc_502  -14
    arc_0_2_18  out_degree_791  1
    arc_0_2_18  in_degree_850  1
    arc_0_2_18  original_T_including_depot_unload_871  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_501  1
    load_0_2_18  segment_load_conservation_795  1
    load_0_2_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_503  -20
    arc_0_2_19  connected_order_arc_504  -14
    arc_0_2_19  out_degree_791  1
    arc_0_2_19  in_degree_856  1
    arc_0_2_19  original_T_including_depot_unload_871  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_503  1
    load_0_2_19  segment_load_conservation_795  1
    load_0_2_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_505  -20
    arc_0_2_20  connected_order_arc_506  -14
    arc_0_2_20  out_degree_791  1
    arc_0_2_20  in_degree_862  1
    arc_0_2_20  original_T_including_depot_unload_871  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_505  1
    load_0_2_20  segment_load_conservation_795  1
    load_0_2_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_507  -20
    arc_0_3_0  depot_return_or_bypass_783  1
    arc_0_3_0  out_degree_798  1
    arc_0_3_0  original_T_including_depot_unload_871  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_507  1
    load_0_3_0  segment_load_conservation_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_508  -20
    arc_0_3_1  connected_order_arc_509  -14
    arc_0_3_1  in_degree_785  1
    arc_0_3_1  out_degree_798  1
    arc_0_3_1  original_T_including_depot_unload_871  3.6338251321041224e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_508  1
    load_0_3_1  segment_load_conservation_788  -1
    load_0_3_1  segment_prefix_lb_789  1
    load_0_3_1  segment_prefix_ub_790  1
    load_0_3_1  segment_load_conservation_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_510  -20
    arc_0_3_2  connected_order_arc_511  -14
    arc_0_3_2  in_degree_792  1
    arc_0_3_2  out_degree_798  1
    arc_0_3_2  original_T_including_depot_unload_871  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_510  1
    load_0_3_2  segment_load_conservation_795  -1
    load_0_3_2  segment_prefix_lb_796  1
    load_0_3_2  segment_prefix_ub_797  1
    load_0_3_2  segment_load_conservation_802  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_512  -20
    arc_0_3_4  connected_order_arc_513  -14
    arc_0_3_4  out_degree_798  1
    arc_0_3_4  in_degree_806  1
    arc_0_3_4  original_T_including_depot_unload_871  880.352897387315
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_512  1
    load_0_3_4  segment_load_conservation_802  1
    load_0_3_4  segment_load_conservation_809  -1
    load_0_3_4  segment_prefix_lb_810  1
    load_0_3_4  segment_prefix_ub_811  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_514  -20
    arc_0_3_5  connected_order_arc_515  -14
    arc_0_3_5  out_degree_798  1
    arc_0_3_5  in_degree_813  1
    arc_0_3_5  original_T_including_depot_unload_871  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_514  1
    load_0_3_5  segment_load_conservation_802  1
    load_0_3_5  segment_load_conservation_816  -1
    load_0_3_5  segment_prefix_lb_817  1
    load_0_3_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_516  -20
    arc_0_3_13  connected_order_arc_517  -14
    arc_0_3_13  out_degree_798  1
    arc_0_3_13  in_degree_820  1
    arc_0_3_13  original_T_including_depot_unload_871  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_516  1
    load_0_3_13  segment_load_conservation_802  1
    load_0_3_13  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_518  -20
    arc_0_3_14  connected_order_arc_519  -14
    arc_0_3_14  out_degree_798  1
    arc_0_3_14  in_degree_826  1
    arc_0_3_14  original_T_including_depot_unload_871  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_518  1
    load_0_3_14  segment_load_conservation_802  1
    load_0_3_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_520  -20
    arc_0_3_15  connected_order_arc_521  -14
    arc_0_3_15  out_degree_798  1
    arc_0_3_15  in_degree_832  1
    arc_0_3_15  original_T_including_depot_unload_871  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_520  1
    load_0_3_15  segment_load_conservation_802  1
    load_0_3_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_522  -20
    arc_0_3_16  connected_order_arc_523  -14
    arc_0_3_16  out_degree_798  1
    arc_0_3_16  in_degree_838  1
    arc_0_3_16  original_T_including_depot_unload_871  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_522  1
    load_0_3_16  segment_load_conservation_802  1
    load_0_3_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_524  -20
    arc_0_3_17  connected_order_arc_525  -14
    arc_0_3_17  out_degree_798  1
    arc_0_3_17  in_degree_844  1
    arc_0_3_17  original_T_including_depot_unload_871  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_524  1
    load_0_3_17  segment_load_conservation_802  1
    load_0_3_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_526  -20
    arc_0_3_18  connected_order_arc_527  -14
    arc_0_3_18  out_degree_798  1
    arc_0_3_18  in_degree_850  1
    arc_0_3_18  original_T_including_depot_unload_871  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_526  1
    load_0_3_18  segment_load_conservation_802  1
    load_0_3_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_528  -20
    arc_0_3_19  connected_order_arc_529  -14
    arc_0_3_19  out_degree_798  1
    arc_0_3_19  in_degree_856  1
    arc_0_3_19  original_T_including_depot_unload_871  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_528  1
    load_0_3_19  segment_load_conservation_802  1
    load_0_3_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_530  -20
    arc_0_3_20  connected_order_arc_531  -14
    arc_0_3_20  out_degree_798  1
    arc_0_3_20  in_degree_862  1
    arc_0_3_20  original_T_including_depot_unload_871  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_530  1
    load_0_3_20  segment_load_conservation_802  1
    load_0_3_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_532  -20
    arc_0_4_0  depot_return_or_bypass_783  1
    arc_0_4_0  out_degree_805  1
    arc_0_4_0  original_T_including_depot_unload_871  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_532  1
    load_0_4_0  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_533  -20
    arc_0_4_1  connected_order_arc_534  -14
    arc_0_4_1  in_degree_785  1
    arc_0_4_1  out_degree_805  1
    arc_0_4_1  original_T_including_depot_unload_871  1.1605914703789122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_533  1
    load_0_4_1  segment_load_conservation_788  -1
    load_0_4_1  segment_prefix_lb_789  1
    load_0_4_1  segment_prefix_ub_790  1
    load_0_4_1  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_535  -20
    arc_0_4_2  connected_order_arc_536  -14
    arc_0_4_2  in_degree_792  1
    arc_0_4_2  out_degree_805  1
    arc_0_4_2  original_T_including_depot_unload_871  1.0799954902659535e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_535  1
    load_0_4_2  segment_load_conservation_795  -1
    load_0_4_2  segment_prefix_lb_796  1
    load_0_4_2  segment_prefix_ub_797  1
    load_0_4_2  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_537  -20
    arc_0_4_3  connected_order_arc_538  -14
    arc_0_4_3  in_degree_799  1
    arc_0_4_3  out_degree_805  1
    arc_0_4_3  original_T_including_depot_unload_871  1.2724370432148053e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_537  1
    load_0_4_3  segment_load_conservation_802  -1
    load_0_4_3  segment_prefix_lb_803  1
    load_0_4_3  segment_prefix_ub_804  1
    load_0_4_3  segment_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_539  -20
    arc_0_4_5  connected_order_arc_540  -14
    arc_0_4_5  out_degree_805  1
    arc_0_4_5  in_degree_813  1
    arc_0_4_5  original_T_including_depot_unload_871  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_539  1
    load_0_4_5  segment_load_conservation_809  1
    load_0_4_5  segment_load_conservation_816  -1
    load_0_4_5  segment_prefix_lb_817  1
    load_0_4_5  segment_prefix_ub_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_541  -20
    arc_0_4_13  connected_order_arc_542  -14
    arc_0_4_13  out_degree_805  1
    arc_0_4_13  in_degree_820  1
    arc_0_4_13  original_T_including_depot_unload_871  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_541  1
    load_0_4_13  segment_load_conservation_809  1
    load_0_4_13  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_543  -20
    arc_0_4_14  connected_order_arc_544  -14
    arc_0_4_14  out_degree_805  1
    arc_0_4_14  in_degree_826  1
    arc_0_4_14  original_T_including_depot_unload_871  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_543  1
    load_0_4_14  segment_load_conservation_809  1
    load_0_4_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_545  -20
    arc_0_4_15  connected_order_arc_546  -14
    arc_0_4_15  out_degree_805  1
    arc_0_4_15  in_degree_832  1
    arc_0_4_15  original_T_including_depot_unload_871  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_545  1
    load_0_4_15  segment_load_conservation_809  1
    load_0_4_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_547  -20
    arc_0_4_16  connected_order_arc_548  -14
    arc_0_4_16  out_degree_805  1
    arc_0_4_16  in_degree_838  1
    arc_0_4_16  original_T_including_depot_unload_871  9.6620394708383776e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_547  1
    load_0_4_16  segment_load_conservation_809  1
    load_0_4_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_549  -20
    arc_0_4_17  connected_order_arc_550  -14
    arc_0_4_17  out_degree_805  1
    arc_0_4_17  in_degree_844  1
    arc_0_4_17  original_T_including_depot_unload_871  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_549  1
    load_0_4_17  segment_load_conservation_809  1
    load_0_4_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_551  -20
    arc_0_4_18  connected_order_arc_552  -14
    arc_0_4_18  out_degree_805  1
    arc_0_4_18  in_degree_850  1
    arc_0_4_18  original_T_including_depot_unload_871  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_551  1
    load_0_4_18  segment_load_conservation_809  1
    load_0_4_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_553  -20
    arc_0_4_19  connected_order_arc_554  -14
    arc_0_4_19  out_degree_805  1
    arc_0_4_19  in_degree_856  1
    arc_0_4_19  original_T_including_depot_unload_871  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_553  1
    load_0_4_19  segment_load_conservation_809  1
    load_0_4_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_555  -20
    arc_0_4_20  connected_order_arc_556  -14
    arc_0_4_20  out_degree_805  1
    arc_0_4_20  in_degree_862  1
    arc_0_4_20  original_T_including_depot_unload_871  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_555  1
    load_0_4_20  segment_load_conservation_809  1
    load_0_4_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_557  -20
    arc_0_5_0  depot_return_or_bypass_783  1
    arc_0_5_0  out_degree_812  1
    arc_0_5_0  original_T_including_depot_unload_871  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_557  1
    load_0_5_0  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_558  -20
    arc_0_5_1  connected_order_arc_559  -14
    arc_0_5_1  in_degree_785  1
    arc_0_5_1  out_degree_812  1
    arc_0_5_1  original_T_including_depot_unload_871  9.2985081319651772e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_558  1
    load_0_5_1  segment_load_conservation_788  -1
    load_0_5_1  segment_prefix_lb_789  1
    load_0_5_1  segment_prefix_ub_790  1
    load_0_5_1  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_560  -20
    arc_0_5_2  connected_order_arc_561  -14
    arc_0_5_2  in_degree_792  1
    arc_0_5_2  out_degree_812  1
    arc_0_5_2  original_T_including_depot_unload_871  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_560  1
    load_0_5_2  segment_load_conservation_795  -1
    load_0_5_2  segment_prefix_lb_796  1
    load_0_5_2  segment_prefix_ub_797  1
    load_0_5_2  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_562  -20
    arc_0_5_3  connected_order_arc_563  -14
    arc_0_5_3  in_degree_799  1
    arc_0_5_3  out_degree_812  1
    arc_0_5_3  original_T_including_depot_unload_871  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_562  1
    load_0_5_3  segment_load_conservation_802  -1
    load_0_5_3  segment_prefix_lb_803  1
    load_0_5_3  segment_prefix_ub_804  1
    load_0_5_3  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_564  -20
    arc_0_5_4  connected_order_arc_565  -14
    arc_0_5_4  in_degree_806  1
    arc_0_5_4  out_degree_812  1
    arc_0_5_4  original_T_including_depot_unload_871  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_564  1
    load_0_5_4  segment_load_conservation_809  -1
    load_0_5_4  segment_prefix_lb_810  1
    load_0_5_4  segment_prefix_ub_811  1
    load_0_5_4  segment_load_conservation_816  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_566  -20
    arc_0_5_13  connected_order_arc_567  -14
    arc_0_5_13  out_degree_812  1
    arc_0_5_13  in_degree_820  1
    arc_0_5_13  original_T_including_depot_unload_871  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_566  1
    load_0_5_13  segment_load_conservation_816  1
    load_0_5_13  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_568  -20
    arc_0_5_14  connected_order_arc_569  -14
    arc_0_5_14  out_degree_812  1
    arc_0_5_14  in_degree_826  1
    arc_0_5_14  original_T_including_depot_unload_871  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_568  1
    load_0_5_14  segment_load_conservation_816  1
    load_0_5_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_570  -20
    arc_0_5_15  connected_order_arc_571  -14
    arc_0_5_15  out_degree_812  1
    arc_0_5_15  in_degree_832  1
    arc_0_5_15  original_T_including_depot_unload_871  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_570  1
    load_0_5_15  segment_load_conservation_816  1
    load_0_5_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_572  -20
    arc_0_5_16  connected_order_arc_573  -14
    arc_0_5_16  out_degree_812  1
    arc_0_5_16  in_degree_838  1
    arc_0_5_16  original_T_including_depot_unload_871  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_572  1
    load_0_5_16  segment_load_conservation_816  1
    load_0_5_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_574  -20
    arc_0_5_17  connected_order_arc_575  -14
    arc_0_5_17  out_degree_812  1
    arc_0_5_17  in_degree_844  1
    arc_0_5_17  original_T_including_depot_unload_871  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_574  1
    load_0_5_17  segment_load_conservation_816  1
    load_0_5_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_576  -20
    arc_0_5_18  connected_order_arc_577  -14
    arc_0_5_18  out_degree_812  1
    arc_0_5_18  in_degree_850  1
    arc_0_5_18  original_T_including_depot_unload_871  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_576  1
    load_0_5_18  segment_load_conservation_816  1
    load_0_5_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_578  -20
    arc_0_5_19  connected_order_arc_579  -14
    arc_0_5_19  out_degree_812  1
    arc_0_5_19  in_degree_856  1
    arc_0_5_19  original_T_including_depot_unload_871  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_578  1
    load_0_5_19  segment_load_conservation_816  1
    load_0_5_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_580  -20
    arc_0_5_20  connected_order_arc_581  -14
    arc_0_5_20  out_degree_812  1
    arc_0_5_20  in_degree_862  1
    arc_0_5_20  original_T_including_depot_unload_871  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_580  1
    load_0_5_20  segment_load_conservation_816  1
    load_0_5_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_582  -20
    arc_0_13_0  depot_return_or_bypass_783  1
    arc_0_13_0  out_degree_819  1
    arc_0_13_0  original_T_including_depot_unload_871  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_582  1
    load_0_13_0  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_583  -20
    arc_0_13_1  connected_order_arc_584  -14
    arc_0_13_1  in_degree_785  1
    arc_0_13_1  out_degree_819  1
    arc_0_13_1  original_T_including_depot_unload_871  5.2534086948364859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_583  1
    load_0_13_1  segment_load_conservation_788  -1
    load_0_13_1  segment_prefix_lb_789  1
    load_0_13_1  segment_prefix_ub_790  1
    load_0_13_1  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_585  -20
    arc_0_13_2  connected_order_arc_586  -14
    arc_0_13_2  in_degree_792  1
    arc_0_13_2  out_degree_819  1
    arc_0_13_2  original_T_including_depot_unload_871  3.4754938304534517e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_585  1
    load_0_13_2  segment_load_conservation_795  -1
    load_0_13_2  segment_prefix_lb_796  1
    load_0_13_2  segment_prefix_ub_797  1
    load_0_13_2  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_587  -20
    arc_0_13_3  connected_order_arc_588  -14
    arc_0_13_3  in_degree_799  1
    arc_0_13_3  out_degree_819  1
    arc_0_13_3  original_T_including_depot_unload_871  4.9242827332511274e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_587  1
    load_0_13_3  segment_load_conservation_802  -1
    load_0_13_3  segment_prefix_lb_803  1
    load_0_13_3  segment_prefix_ub_804  1
    load_0_13_3  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_589  -20
    arc_0_13_4  connected_order_arc_590  -14
    arc_0_13_4  in_degree_806  1
    arc_0_13_4  out_degree_819  1
    arc_0_13_4  original_T_including_depot_unload_871  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_589  1
    load_0_13_4  segment_load_conservation_809  -1
    load_0_13_4  segment_prefix_lb_810  1
    load_0_13_4  segment_prefix_ub_811  1
    load_0_13_4  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_591  -20
    arc_0_13_5  connected_order_arc_592  -14
    arc_0_13_5  in_degree_813  1
    arc_0_13_5  out_degree_819  1
    arc_0_13_5  original_T_including_depot_unload_871  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_591  1
    load_0_13_5  segment_load_conservation_816  -1
    load_0_13_5  segment_prefix_lb_817  1
    load_0_13_5  segment_prefix_ub_818  1
    load_0_13_5  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_593  -20
    arc_0_13_14  connected_order_arc_594  -14
    arc_0_13_14  out_degree_819  1
    arc_0_13_14  in_degree_826  1
    arc_0_13_14  original_T_including_depot_unload_871  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_593  1
    load_0_13_14  free_load_conservation_824  1
    load_0_13_14  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_595  -20
    arc_0_13_15  connected_order_arc_596  -14
    arc_0_13_15  out_degree_819  1
    arc_0_13_15  in_degree_832  1
    arc_0_13_15  original_T_including_depot_unload_871  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_595  1
    load_0_13_15  free_load_conservation_824  1
    load_0_13_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_597  -20
    arc_0_13_16  connected_order_arc_598  -14
    arc_0_13_16  out_degree_819  1
    arc_0_13_16  in_degree_838  1
    arc_0_13_16  original_T_including_depot_unload_871  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_597  1
    load_0_13_16  free_load_conservation_824  1
    load_0_13_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_599  -20
    arc_0_13_17  connected_order_arc_600  -14
    arc_0_13_17  out_degree_819  1
    arc_0_13_17  in_degree_844  1
    arc_0_13_17  original_T_including_depot_unload_871  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_599  1
    load_0_13_17  free_load_conservation_824  1
    load_0_13_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_601  -20
    arc_0_13_18  connected_order_arc_602  -14
    arc_0_13_18  out_degree_819  1
    arc_0_13_18  in_degree_850  1
    arc_0_13_18  original_T_including_depot_unload_871  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_601  1
    load_0_13_18  free_load_conservation_824  1
    load_0_13_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_603  -20
    arc_0_13_19  connected_order_arc_604  -14
    arc_0_13_19  out_degree_819  1
    arc_0_13_19  in_degree_856  1
    arc_0_13_19  original_T_including_depot_unload_871  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_603  1
    load_0_13_19  free_load_conservation_824  1
    load_0_13_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_605  -20
    arc_0_13_20  connected_order_arc_606  -14
    arc_0_13_20  out_degree_819  1
    arc_0_13_20  in_degree_862  1
    arc_0_13_20  original_T_including_depot_unload_871  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_605  1
    load_0_13_20  free_load_conservation_824  1
    load_0_13_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_607  -20
    arc_0_14_0  depot_return_or_bypass_783  1
    arc_0_14_0  out_degree_825  1
    arc_0_14_0  original_T_including_depot_unload_871  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_607  1
    load_0_14_0  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_608  -20
    arc_0_14_1  connected_order_arc_609  -14
    arc_0_14_1  in_degree_785  1
    arc_0_14_1  out_degree_825  1
    arc_0_14_1  original_T_including_depot_unload_871  6.7803521648175558e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_608  1
    load_0_14_1  segment_load_conservation_788  -1
    load_0_14_1  segment_prefix_lb_789  1
    load_0_14_1  segment_prefix_ub_790  1
    load_0_14_1  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_610  -20
    arc_0_14_2  connected_order_arc_611  -14
    arc_0_14_2  in_degree_792  1
    arc_0_14_2  out_degree_825  1
    arc_0_14_2  original_T_including_depot_unload_871  5.1510428418120409e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_610  1
    load_0_14_2  segment_load_conservation_795  -1
    load_0_14_2  segment_prefix_lb_796  1
    load_0_14_2  segment_prefix_ub_797  1
    load_0_14_2  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_612  -20
    arc_0_14_3  connected_order_arc_613  -14
    arc_0_14_3  in_degree_799  1
    arc_0_14_3  out_degree_825  1
    arc_0_14_3  original_T_including_depot_unload_871  6.6047504008669523e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_612  1
    load_0_14_3  segment_load_conservation_802  -1
    load_0_14_3  segment_prefix_lb_803  1
    load_0_14_3  segment_prefix_ub_804  1
    load_0_14_3  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_614  -20
    arc_0_14_4  connected_order_arc_615  -14
    arc_0_14_4  in_degree_806  1
    arc_0_14_4  out_degree_825  1
    arc_0_14_4  original_T_including_depot_unload_871  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_614  1
    load_0_14_4  segment_load_conservation_809  -1
    load_0_14_4  segment_prefix_lb_810  1
    load_0_14_4  segment_prefix_ub_811  1
    load_0_14_4  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_616  -20
    arc_0_14_5  connected_order_arc_617  -14
    arc_0_14_5  in_degree_813  1
    arc_0_14_5  out_degree_825  1
    arc_0_14_5  original_T_including_depot_unload_871  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_616  1
    load_0_14_5  segment_load_conservation_816  -1
    load_0_14_5  segment_prefix_lb_817  1
    load_0_14_5  segment_prefix_ub_818  1
    load_0_14_5  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_618  -20
    arc_0_14_13  connected_order_arc_619  -14
    arc_0_14_13  in_degree_820  1
    arc_0_14_13  out_degree_825  1
    arc_0_14_13  original_T_including_depot_unload_871  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_618  1
    load_0_14_13  free_load_conservation_824  -1
    load_0_14_13  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_620  -20
    arc_0_14_15  connected_order_arc_621  -14
    arc_0_14_15  out_degree_825  1
    arc_0_14_15  in_degree_832  1
    arc_0_14_15  original_T_including_depot_unload_871  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_620  1
    load_0_14_15  free_load_conservation_830  1
    load_0_14_15  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_622  -20
    arc_0_14_16  connected_order_arc_623  -14
    arc_0_14_16  out_degree_825  1
    arc_0_14_16  in_degree_838  1
    arc_0_14_16  original_T_including_depot_unload_871  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_622  1
    load_0_14_16  free_load_conservation_830  1
    load_0_14_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_624  -20
    arc_0_14_17  connected_order_arc_625  -14
    arc_0_14_17  out_degree_825  1
    arc_0_14_17  in_degree_844  1
    arc_0_14_17  original_T_including_depot_unload_871  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_624  1
    load_0_14_17  free_load_conservation_830  1
    load_0_14_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_626  -20
    arc_0_14_18  connected_order_arc_627  -14
    arc_0_14_18  out_degree_825  1
    arc_0_14_18  in_degree_850  1
    arc_0_14_18  original_T_including_depot_unload_871  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_626  1
    load_0_14_18  free_load_conservation_830  1
    load_0_14_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_628  -20
    arc_0_14_19  connected_order_arc_629  -14
    arc_0_14_19  out_degree_825  1
    arc_0_14_19  in_degree_856  1
    arc_0_14_19  original_T_including_depot_unload_871  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_628  1
    load_0_14_19  free_load_conservation_830  1
    load_0_14_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_630  -20
    arc_0_14_20  connected_order_arc_631  -14
    arc_0_14_20  out_degree_825  1
    arc_0_14_20  in_degree_862  1
    arc_0_14_20  original_T_including_depot_unload_871  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_630  1
    load_0_14_20  free_load_conservation_830  1
    load_0_14_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_632  -20
    arc_0_15_0  depot_return_or_bypass_783  1
    arc_0_15_0  out_degree_831  1
    arc_0_15_0  original_T_including_depot_unload_871  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_632  1
    load_0_15_0  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_633  -20
    arc_0_15_1  connected_order_arc_634  -14
    arc_0_15_1  in_degree_785  1
    arc_0_15_1  out_degree_831  1
    arc_0_15_1  original_T_including_depot_unload_871  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_633  1
    load_0_15_1  segment_load_conservation_788  -1
    load_0_15_1  segment_prefix_lb_789  1
    load_0_15_1  segment_prefix_ub_790  1
    load_0_15_1  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_635  -20
    arc_0_15_2  connected_order_arc_636  -14
    arc_0_15_2  in_degree_792  1
    arc_0_15_2  out_degree_831  1
    arc_0_15_2  original_T_including_depot_unload_871  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_635  1
    load_0_15_2  segment_load_conservation_795  -1
    load_0_15_2  segment_prefix_lb_796  1
    load_0_15_2  segment_prefix_ub_797  1
    load_0_15_2  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_637  -20
    arc_0_15_3  connected_order_arc_638  -14
    arc_0_15_3  in_degree_799  1
    arc_0_15_3  out_degree_831  1
    arc_0_15_3  original_T_including_depot_unload_871  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_637  1
    load_0_15_3  segment_load_conservation_802  -1
    load_0_15_3  segment_prefix_lb_803  1
    load_0_15_3  segment_prefix_ub_804  1
    load_0_15_3  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_639  -20
    arc_0_15_4  connected_order_arc_640  -14
    arc_0_15_4  in_degree_806  1
    arc_0_15_4  out_degree_831  1
    arc_0_15_4  original_T_including_depot_unload_871  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_639  1
    load_0_15_4  segment_load_conservation_809  -1
    load_0_15_4  segment_prefix_lb_810  1
    load_0_15_4  segment_prefix_ub_811  1
    load_0_15_4  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_641  -20
    arc_0_15_5  connected_order_arc_642  -14
    arc_0_15_5  in_degree_813  1
    arc_0_15_5  out_degree_831  1
    arc_0_15_5  original_T_including_depot_unload_871  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_641  1
    load_0_15_5  segment_load_conservation_816  -1
    load_0_15_5  segment_prefix_lb_817  1
    load_0_15_5  segment_prefix_ub_818  1
    load_0_15_5  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_643  -20
    arc_0_15_13  connected_order_arc_644  -14
    arc_0_15_13  in_degree_820  1
    arc_0_15_13  out_degree_831  1
    arc_0_15_13  original_T_including_depot_unload_871  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_643  1
    load_0_15_13  free_load_conservation_824  -1
    load_0_15_13  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_645  -20
    arc_0_15_14  connected_order_arc_646  -14
    arc_0_15_14  in_degree_826  1
    arc_0_15_14  out_degree_831  1
    arc_0_15_14  original_T_including_depot_unload_871  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_645  1
    load_0_15_14  free_load_conservation_830  -1
    load_0_15_14  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_647  -20
    arc_0_15_16  connected_order_arc_648  -14
    arc_0_15_16  out_degree_831  1
    arc_0_15_16  in_degree_838  1
    arc_0_15_16  original_T_including_depot_unload_871  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_647  1
    load_0_15_16  free_load_conservation_836  1
    load_0_15_16  free_load_conservation_842  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_649  -20
    arc_0_15_17  connected_order_arc_650  -14
    arc_0_15_17  out_degree_831  1
    arc_0_15_17  in_degree_844  1
    arc_0_15_17  original_T_including_depot_unload_871  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_649  1
    load_0_15_17  free_load_conservation_836  1
    load_0_15_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_651  -20
    arc_0_15_18  connected_order_arc_652  -14
    arc_0_15_18  out_degree_831  1
    arc_0_15_18  in_degree_850  1
    arc_0_15_18  original_T_including_depot_unload_871  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_651  1
    load_0_15_18  free_load_conservation_836  1
    load_0_15_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_653  -20
    arc_0_15_19  connected_order_arc_654  -14
    arc_0_15_19  out_degree_831  1
    arc_0_15_19  in_degree_856  1
    arc_0_15_19  original_T_including_depot_unload_871  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_653  1
    load_0_15_19  free_load_conservation_836  1
    load_0_15_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_655  -20
    arc_0_15_20  connected_order_arc_656  -14
    arc_0_15_20  out_degree_831  1
    arc_0_15_20  in_degree_862  1
    arc_0_15_20  original_T_including_depot_unload_871  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_655  1
    load_0_15_20  free_load_conservation_836  1
    load_0_15_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_657  -20
    arc_0_16_0  depot_return_or_bypass_783  1
    arc_0_16_0  out_degree_837  1
    arc_0_16_0  original_T_including_depot_unload_871  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_657  1
    load_0_16_0  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_658  -20
    arc_0_16_1  connected_order_arc_659  -14
    arc_0_16_1  in_degree_785  1
    arc_0_16_1  out_degree_837  1
    arc_0_16_1  original_T_including_depot_unload_871  4.4474809771996007e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_658  1
    load_0_16_1  segment_load_conservation_788  -1
    load_0_16_1  segment_prefix_lb_789  1
    load_0_16_1  segment_prefix_ub_790  1
    load_0_16_1  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_660  -20
    arc_0_16_2  connected_order_arc_661  -14
    arc_0_16_2  in_degree_792  1
    arc_0_16_2  out_degree_837  1
    arc_0_16_2  original_T_including_depot_unload_871  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_660  1
    load_0_16_2  segment_load_conservation_795  -1
    load_0_16_2  segment_prefix_lb_796  1
    load_0_16_2  segment_prefix_ub_797  1
    load_0_16_2  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_662  -20
    arc_0_16_3  connected_order_arc_663  -14
    arc_0_16_3  in_degree_799  1
    arc_0_16_3  out_degree_837  1
    arc_0_16_3  original_T_including_depot_unload_871  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_662  1
    load_0_16_3  segment_load_conservation_802  -1
    load_0_16_3  segment_prefix_lb_803  1
    load_0_16_3  segment_prefix_ub_804  1
    load_0_16_3  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_664  -20
    arc_0_16_4  connected_order_arc_665  -14
    arc_0_16_4  in_degree_806  1
    arc_0_16_4  out_degree_837  1
    arc_0_16_4  original_T_including_depot_unload_871  5.5739415765733247e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_664  1
    load_0_16_4  segment_load_conservation_809  -1
    load_0_16_4  segment_prefix_lb_810  1
    load_0_16_4  segment_prefix_ub_811  1
    load_0_16_4  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_666  -20
    arc_0_16_5  connected_order_arc_667  -14
    arc_0_16_5  in_degree_813  1
    arc_0_16_5  out_degree_837  1
    arc_0_16_5  original_T_including_depot_unload_871  839.148853987777
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_666  1
    load_0_16_5  segment_load_conservation_816  -1
    load_0_16_5  segment_prefix_lb_817  1
    load_0_16_5  segment_prefix_ub_818  1
    load_0_16_5  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_668  -20
    arc_0_16_13  connected_order_arc_669  -14
    arc_0_16_13  in_degree_820  1
    arc_0_16_13  out_degree_837  1
    arc_0_16_13  original_T_including_depot_unload_871  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_668  1
    load_0_16_13  free_load_conservation_824  -1
    load_0_16_13  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_670  -20
    arc_0_16_14  connected_order_arc_671  -14
    arc_0_16_14  in_degree_826  1
    arc_0_16_14  out_degree_837  1
    arc_0_16_14  original_T_including_depot_unload_871  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_670  1
    load_0_16_14  free_load_conservation_830  -1
    load_0_16_14  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_672  -20
    arc_0_16_15  connected_order_arc_673  -14
    arc_0_16_15  in_degree_832  1
    arc_0_16_15  out_degree_837  1
    arc_0_16_15  original_T_including_depot_unload_871  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_672  1
    load_0_16_15  free_load_conservation_836  -1
    load_0_16_15  free_load_conservation_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_674  -20
    arc_0_16_17  connected_order_arc_675  -14
    arc_0_16_17  out_degree_837  1
    arc_0_16_17  in_degree_844  1
    arc_0_16_17  original_T_including_depot_unload_871  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_674  1
    load_0_16_17  free_load_conservation_842  1
    load_0_16_17  free_load_conservation_848  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_676  -20
    arc_0_16_18  connected_order_arc_677  -14
    arc_0_16_18  out_degree_837  1
    arc_0_16_18  in_degree_850  1
    arc_0_16_18  original_T_including_depot_unload_871  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_676  1
    load_0_16_18  free_load_conservation_842  1
    load_0_16_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_678  -20
    arc_0_16_19  connected_order_arc_679  -14
    arc_0_16_19  out_degree_837  1
    arc_0_16_19  in_degree_856  1
    arc_0_16_19  original_T_including_depot_unload_871  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_678  1
    load_0_16_19  free_load_conservation_842  1
    load_0_16_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_680  -20
    arc_0_16_20  connected_order_arc_681  -14
    arc_0_16_20  out_degree_837  1
    arc_0_16_20  in_degree_862  1
    arc_0_16_20  original_T_including_depot_unload_871  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_680  1
    load_0_16_20  free_load_conservation_842  1
    load_0_16_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_682  -20
    arc_0_17_0  depot_return_or_bypass_783  1
    arc_0_17_0  out_degree_843  1
    arc_0_17_0  original_T_including_depot_unload_871  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_682  1
    load_0_17_0  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_683  -20
    arc_0_17_1  connected_order_arc_684  -14
    arc_0_17_1  in_degree_785  1
    arc_0_17_1  out_degree_843  1
    arc_0_17_1  original_T_including_depot_unload_871  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_683  1
    load_0_17_1  segment_load_conservation_788  -1
    load_0_17_1  segment_prefix_lb_789  1
    load_0_17_1  segment_prefix_ub_790  1
    load_0_17_1  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_685  -20
    arc_0_17_2  connected_order_arc_686  -14
    arc_0_17_2  in_degree_792  1
    arc_0_17_2  out_degree_843  1
    arc_0_17_2  original_T_including_depot_unload_871  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_685  1
    load_0_17_2  segment_load_conservation_795  -1
    load_0_17_2  segment_prefix_lb_796  1
    load_0_17_2  segment_prefix_ub_797  1
    load_0_17_2  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_687  -20
    arc_0_17_3  connected_order_arc_688  -14
    arc_0_17_3  in_degree_799  1
    arc_0_17_3  out_degree_843  1
    arc_0_17_3  original_T_including_depot_unload_871  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_687  1
    load_0_17_3  segment_load_conservation_802  -1
    load_0_17_3  segment_prefix_lb_803  1
    load_0_17_3  segment_prefix_ub_804  1
    load_0_17_3  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_689  -20
    arc_0_17_4  connected_order_arc_690  -14
    arc_0_17_4  in_degree_806  1
    arc_0_17_4  out_degree_843  1
    arc_0_17_4  original_T_including_depot_unload_871  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_689  1
    load_0_17_4  segment_load_conservation_809  -1
    load_0_17_4  segment_prefix_lb_810  1
    load_0_17_4  segment_prefix_ub_811  1
    load_0_17_4  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_691  -20
    arc_0_17_5  connected_order_arc_692  -14
    arc_0_17_5  in_degree_813  1
    arc_0_17_5  out_degree_843  1
    arc_0_17_5  original_T_including_depot_unload_871  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_691  1
    load_0_17_5  segment_load_conservation_816  -1
    load_0_17_5  segment_prefix_lb_817  1
    load_0_17_5  segment_prefix_ub_818  1
    load_0_17_5  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_693  -20
    arc_0_17_13  connected_order_arc_694  -14
    arc_0_17_13  in_degree_820  1
    arc_0_17_13  out_degree_843  1
    arc_0_17_13  original_T_including_depot_unload_871  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_693  1
    load_0_17_13  free_load_conservation_824  -1
    load_0_17_13  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_695  -20
    arc_0_17_14  connected_order_arc_696  -14
    arc_0_17_14  in_degree_826  1
    arc_0_17_14  out_degree_843  1
    arc_0_17_14  original_T_including_depot_unload_871  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_695  1
    load_0_17_14  free_load_conservation_830  -1
    load_0_17_14  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_697  -20
    arc_0_17_15  connected_order_arc_698  -14
    arc_0_17_15  in_degree_832  1
    arc_0_17_15  out_degree_843  1
    arc_0_17_15  original_T_including_depot_unload_871  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_697  1
    load_0_17_15  free_load_conservation_836  -1
    load_0_17_15  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_699  -20
    arc_0_17_16  connected_order_arc_700  -14
    arc_0_17_16  in_degree_838  1
    arc_0_17_16  out_degree_843  1
    arc_0_17_16  original_T_including_depot_unload_871  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_699  1
    load_0_17_16  free_load_conservation_842  -1
    load_0_17_16  free_load_conservation_848  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_701  -20
    arc_0_17_18  connected_order_arc_702  -14
    arc_0_17_18  out_degree_843  1
    arc_0_17_18  in_degree_850  1
    arc_0_17_18  original_T_including_depot_unload_871  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_701  1
    load_0_17_18  free_load_conservation_848  1
    load_0_17_18  free_load_conservation_854  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_703  -20
    arc_0_17_19  connected_order_arc_704  -14
    arc_0_17_19  out_degree_843  1
    arc_0_17_19  in_degree_856  1
    arc_0_17_19  original_T_including_depot_unload_871  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_703  1
    load_0_17_19  free_load_conservation_848  1
    load_0_17_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_705  -20
    arc_0_17_20  connected_order_arc_706  -14
    arc_0_17_20  out_degree_843  1
    arc_0_17_20  in_degree_862  1
    arc_0_17_20  original_T_including_depot_unload_871  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_705  1
    load_0_17_20  free_load_conservation_848  1
    load_0_17_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_707  -20
    arc_0_18_0  depot_return_or_bypass_783  1
    arc_0_18_0  out_degree_849  1
    arc_0_18_0  original_T_including_depot_unload_871  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_707  1
    load_0_18_0  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_708  -20
    arc_0_18_1  connected_order_arc_709  -14
    arc_0_18_1  in_degree_785  1
    arc_0_18_1  out_degree_849  1
    arc_0_18_1  original_T_including_depot_unload_871  2.9438424317501273e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_708  1
    load_0_18_1  segment_load_conservation_788  -1
    load_0_18_1  segment_prefix_lb_789  1
    load_0_18_1  segment_prefix_ub_790  1
    load_0_18_1  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_710  -20
    arc_0_18_2  connected_order_arc_711  -14
    arc_0_18_2  in_degree_792  1
    arc_0_18_2  out_degree_849  1
    arc_0_18_2  original_T_including_depot_unload_871  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_710  1
    load_0_18_2  segment_load_conservation_795  -1
    load_0_18_2  segment_prefix_lb_796  1
    load_0_18_2  segment_prefix_ub_797  1
    load_0_18_2  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_712  -20
    arc_0_18_3  connected_order_arc_713  -14
    arc_0_18_3  in_degree_799  1
    arc_0_18_3  out_degree_849  1
    arc_0_18_3  original_T_including_depot_unload_871  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_712  1
    load_0_18_3  segment_load_conservation_802  -1
    load_0_18_3  segment_prefix_lb_803  1
    load_0_18_3  segment_prefix_ub_804  1
    load_0_18_3  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_714  -20
    arc_0_18_4  connected_order_arc_715  -14
    arc_0_18_4  in_degree_806  1
    arc_0_18_4  out_degree_849  1
    arc_0_18_4  original_T_including_depot_unload_871  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_714  1
    load_0_18_4  segment_load_conservation_809  -1
    load_0_18_4  segment_prefix_lb_810  1
    load_0_18_4  segment_prefix_ub_811  1
    load_0_18_4  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_716  -20
    arc_0_18_5  connected_order_arc_717  -14
    arc_0_18_5  in_degree_813  1
    arc_0_18_5  out_degree_849  1
    arc_0_18_5  original_T_including_depot_unload_871  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_716  1
    load_0_18_5  segment_load_conservation_816  -1
    load_0_18_5  segment_prefix_lb_817  1
    load_0_18_5  segment_prefix_ub_818  1
    load_0_18_5  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_718  -20
    arc_0_18_13  connected_order_arc_719  -14
    arc_0_18_13  in_degree_820  1
    arc_0_18_13  out_degree_849  1
    arc_0_18_13  original_T_including_depot_unload_871  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_718  1
    load_0_18_13  free_load_conservation_824  -1
    load_0_18_13  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_720  -20
    arc_0_18_14  connected_order_arc_721  -14
    arc_0_18_14  in_degree_826  1
    arc_0_18_14  out_degree_849  1
    arc_0_18_14  original_T_including_depot_unload_871  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_720  1
    load_0_18_14  free_load_conservation_830  -1
    load_0_18_14  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_722  -20
    arc_0_18_15  connected_order_arc_723  -14
    arc_0_18_15  in_degree_832  1
    arc_0_18_15  out_degree_849  1
    arc_0_18_15  original_T_including_depot_unload_871  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_722  1
    load_0_18_15  free_load_conservation_836  -1
    load_0_18_15  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_724  -20
    arc_0_18_16  connected_order_arc_725  -14
    arc_0_18_16  in_degree_838  1
    arc_0_18_16  out_degree_849  1
    arc_0_18_16  original_T_including_depot_unload_871  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_724  1
    load_0_18_16  free_load_conservation_842  -1
    load_0_18_16  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_726  -20
    arc_0_18_17  connected_order_arc_727  -14
    arc_0_18_17  in_degree_844  1
    arc_0_18_17  out_degree_849  1
    arc_0_18_17  original_T_including_depot_unload_871  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_726  1
    load_0_18_17  free_load_conservation_848  -1
    load_0_18_17  free_load_conservation_854  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_728  -20
    arc_0_18_19  connected_order_arc_729  -14
    arc_0_18_19  out_degree_849  1
    arc_0_18_19  in_degree_856  1
    arc_0_18_19  original_T_including_depot_unload_871  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_728  1
    load_0_18_19  free_load_conservation_854  1
    load_0_18_19  free_load_conservation_860  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_730  -20
    arc_0_18_20  connected_order_arc_731  -14
    arc_0_18_20  out_degree_849  1
    arc_0_18_20  in_degree_862  1
    arc_0_18_20  original_T_including_depot_unload_871  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_730  1
    load_0_18_20  free_load_conservation_854  1
    load_0_18_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_732  -20
    arc_0_19_0  depot_return_or_bypass_783  1
    arc_0_19_0  out_degree_855  1
    arc_0_19_0  original_T_including_depot_unload_871  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_732  1
    load_0_19_0  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_733  -20
    arc_0_19_1  connected_order_arc_734  -14
    arc_0_19_1  in_degree_785  1
    arc_0_19_1  out_degree_855  1
    arc_0_19_1  original_T_including_depot_unload_871  1.1957430085580884e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_733  1
    load_0_19_1  segment_load_conservation_788  -1
    load_0_19_1  segment_prefix_lb_789  1
    load_0_19_1  segment_prefix_ub_790  1
    load_0_19_1  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_735  -20
    arc_0_19_2  connected_order_arc_736  -14
    arc_0_19_2  in_degree_792  1
    arc_0_19_2  out_degree_855  1
    arc_0_19_2  original_T_including_depot_unload_871  1.1562172312295786e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_735  1
    load_0_19_2  segment_load_conservation_795  -1
    load_0_19_2  segment_prefix_lb_796  1
    load_0_19_2  segment_prefix_ub_797  1
    load_0_19_2  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_737  -20
    arc_0_19_3  connected_order_arc_738  -14
    arc_0_19_3  in_degree_799  1
    arc_0_19_3  out_degree_855  1
    arc_0_19_3  original_T_including_depot_unload_871  1.3669225770244122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_737  1
    load_0_19_3  segment_load_conservation_802  -1
    load_0_19_3  segment_prefix_lb_803  1
    load_0_19_3  segment_prefix_ub_804  1
    load_0_19_3  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_739  -20
    arc_0_19_4  connected_order_arc_740  -14
    arc_0_19_4  in_degree_806  1
    arc_0_19_4  out_degree_855  1
    arc_0_19_4  original_T_including_depot_unload_871  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_739  1
    load_0_19_4  segment_load_conservation_809  -1
    load_0_19_4  segment_prefix_lb_810  1
    load_0_19_4  segment_prefix_ub_811  1
    load_0_19_4  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_741  -20
    arc_0_19_5  connected_order_arc_742  -14
    arc_0_19_5  in_degree_813  1
    arc_0_19_5  out_degree_855  1
    arc_0_19_5  original_T_including_depot_unload_871  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_741  1
    load_0_19_5  segment_load_conservation_816  -1
    load_0_19_5  segment_prefix_lb_817  1
    load_0_19_5  segment_prefix_ub_818  1
    load_0_19_5  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_743  -20
    arc_0_19_13  connected_order_arc_744  -14
    arc_0_19_13  in_degree_820  1
    arc_0_19_13  out_degree_855  1
    arc_0_19_13  original_T_including_depot_unload_871  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_743  1
    load_0_19_13  free_load_conservation_824  -1
    load_0_19_13  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_745  -20
    arc_0_19_14  connected_order_arc_746  -14
    arc_0_19_14  in_degree_826  1
    arc_0_19_14  out_degree_855  1
    arc_0_19_14  original_T_including_depot_unload_871  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_745  1
    load_0_19_14  free_load_conservation_830  -1
    load_0_19_14  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_747  -20
    arc_0_19_15  connected_order_arc_748  -14
    arc_0_19_15  in_degree_832  1
    arc_0_19_15  out_degree_855  1
    arc_0_19_15  original_T_including_depot_unload_871  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_747  1
    load_0_19_15  free_load_conservation_836  -1
    load_0_19_15  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_749  -20
    arc_0_19_16  connected_order_arc_750  -14
    arc_0_19_16  in_degree_838  1
    arc_0_19_16  out_degree_855  1
    arc_0_19_16  original_T_including_depot_unload_871  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_749  1
    load_0_19_16  free_load_conservation_842  -1
    load_0_19_16  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_751  -20
    arc_0_19_17  connected_order_arc_752  -14
    arc_0_19_17  in_degree_844  1
    arc_0_19_17  out_degree_855  1
    arc_0_19_17  original_T_including_depot_unload_871  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_751  1
    load_0_19_17  free_load_conservation_848  -1
    load_0_19_17  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_753  -20
    arc_0_19_18  connected_order_arc_754  -14
    arc_0_19_18  in_degree_850  1
    arc_0_19_18  out_degree_855  1
    arc_0_19_18  original_T_including_depot_unload_871  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_753  1
    load_0_19_18  free_load_conservation_854  -1
    load_0_19_18  free_load_conservation_860  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_755  -20
    arc_0_19_20  connected_order_arc_756  -14
    arc_0_19_20  out_degree_855  1
    arc_0_19_20  in_degree_862  1
    arc_0_19_20  original_T_including_depot_unload_871  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_755  1
    load_0_19_20  free_load_conservation_860  1
    load_0_19_20  free_load_conservation_866  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_757  -20
    arc_0_20_0  depot_return_or_bypass_783  1
    arc_0_20_0  out_degree_861  1
    arc_0_20_0  original_T_including_depot_unload_871  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_757  1
    load_0_20_0  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_758  -20
    arc_0_20_1  connected_order_arc_759  -14
    arc_0_20_1  in_degree_785  1
    arc_0_20_1  out_degree_861  1
    arc_0_20_1  original_T_including_depot_unload_871  7.7690262287132452e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_758  1
    load_0_20_1  segment_load_conservation_788  -1
    load_0_20_1  segment_prefix_lb_789  1
    load_0_20_1  segment_prefix_ub_790  1
    load_0_20_1  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_760  -20
    arc_0_20_2  connected_order_arc_761  -14
    arc_0_20_2  in_degree_792  1
    arc_0_20_2  out_degree_861  1
    arc_0_20_2  original_T_including_depot_unload_871  5.7237486782756332e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_760  1
    load_0_20_2  segment_load_conservation_795  -1
    load_0_20_2  segment_prefix_lb_796  1
    load_0_20_2  segment_prefix_ub_797  1
    load_0_20_2  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_762  -20
    arc_0_20_3  connected_order_arc_763  -14
    arc_0_20_3  in_degree_799  1
    arc_0_20_3  out_degree_861  1
    arc_0_20_3  original_T_including_depot_unload_871  6.3648699141452130e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_762  1
    load_0_20_3  segment_load_conservation_802  -1
    load_0_20_3  segment_prefix_lb_803  1
    load_0_20_3  segment_prefix_ub_804  1
    load_0_20_3  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_764  -20
    arc_0_20_4  connected_order_arc_765  -14
    arc_0_20_4  in_degree_806  1
    arc_0_20_4  out_degree_861  1
    arc_0_20_4  original_T_including_depot_unload_871  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_764  1
    load_0_20_4  segment_load_conservation_809  -1
    load_0_20_4  segment_prefix_lb_810  1
    load_0_20_4  segment_prefix_ub_811  1
    load_0_20_4  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_766  -20
    arc_0_20_5  connected_order_arc_767  -14
    arc_0_20_5  in_degree_813  1
    arc_0_20_5  out_degree_861  1
    arc_0_20_5  original_T_including_depot_unload_871  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_766  1
    load_0_20_5  segment_load_conservation_816  -1
    load_0_20_5  segment_prefix_lb_817  1
    load_0_20_5  segment_prefix_ub_818  1
    load_0_20_5  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_768  -20
    arc_0_20_13  connected_order_arc_769  -14
    arc_0_20_13  in_degree_820  1
    arc_0_20_13  out_degree_861  1
    arc_0_20_13  original_T_including_depot_unload_871  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_768  1
    load_0_20_13  free_load_conservation_824  -1
    load_0_20_13  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_770  -20
    arc_0_20_14  connected_order_arc_771  -14
    arc_0_20_14  in_degree_826  1
    arc_0_20_14  out_degree_861  1
    arc_0_20_14  original_T_including_depot_unload_871  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_770  1
    load_0_20_14  free_load_conservation_830  -1
    load_0_20_14  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_772  -20
    arc_0_20_15  connected_order_arc_773  -14
    arc_0_20_15  in_degree_832  1
    arc_0_20_15  out_degree_861  1
    arc_0_20_15  original_T_including_depot_unload_871  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_772  1
    load_0_20_15  free_load_conservation_836  -1
    load_0_20_15  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_774  -20
    arc_0_20_16  connected_order_arc_775  -14
    arc_0_20_16  in_degree_838  1
    arc_0_20_16  out_degree_861  1
    arc_0_20_16  original_T_including_depot_unload_871  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_774  1
    load_0_20_16  free_load_conservation_842  -1
    load_0_20_16  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_776  -20
    arc_0_20_17  connected_order_arc_777  -14
    arc_0_20_17  in_degree_844  1
    arc_0_20_17  out_degree_861  1
    arc_0_20_17  original_T_including_depot_unload_871  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_776  1
    load_0_20_17  free_load_conservation_848  -1
    load_0_20_17  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_778  -20
    arc_0_20_18  connected_order_arc_779  -14
    arc_0_20_18  in_degree_850  1
    arc_0_20_18  out_degree_861  1
    arc_0_20_18  original_T_including_depot_unload_871  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_778  1
    load_0_20_18  free_load_conservation_854  -1
    load_0_20_18  free_load_conservation_866  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_780  -20
    arc_0_20_19  connected_order_arc_781  -14
    arc_0_20_19  in_degree_856  1
    arc_0_20_19  out_degree_861  1
    arc_0_20_19  original_T_including_depot_unload_871  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_780  1
    load_0_20_19  free_load_conservation_860  -1
    load_0_20_19  free_load_conservation_866  1
    visit_1_6  out_degree_1163  -1
    visit_1_6  in_degree_1164  -1
    visit_1_6  order_active_lb_1165  -1
    visit_1_6  order_active_ub_1166  -12
    order_1_6  connected_order_arc_887  -1
    order_1_6  connected_order_arc_889  -1
    order_1_6  connected_order_arc_891  -1
    order_1_6  connected_order_arc_893  -1
    order_1_6  connected_order_arc_895  -1
    order_1_6  connected_order_arc_897  -1
    order_1_6  connected_order_arc_899  -1
    order_1_6  connected_order_arc_901  -1
    order_1_6  connected_order_arc_903  -1
    order_1_6  connected_order_arc_905  -1
    order_1_6  connected_order_arc_907  -1
    order_1_6  connected_order_arc_910  1
    order_1_6  connected_order_arc_933  1
    order_1_6  connected_order_arc_956  1
    order_1_6  connected_order_arc_979  1
    order_1_6  connected_order_arc_1002  1
    order_1_6  connected_order_arc_1025  1
    order_1_6  connected_order_arc_1048  1
    order_1_6  connected_order_arc_1071  1
    order_1_6  connected_order_arc_1094  1
    order_1_6  connected_order_arc_1117  1
    order_1_6  connected_order_arc_1140  1
    order_1_6  order_active_lb_1165  1
    order_1_6  order_active_ub_1166  1
    order_1_6  fixed_segment_relative_order_1239  -1
    visit_1_7  out_degree_1170  -1
    visit_1_7  in_degree_1171  -1
    visit_1_7  order_active_lb_1172  -1
    visit_1_7  order_active_ub_1173  -12
    order_1_7  connected_order_arc_887  1
    order_1_7  connected_order_arc_910  -1
    order_1_7  connected_order_arc_912  -1
    order_1_7  connected_order_arc_914  -1
    order_1_7  connected_order_arc_916  -1
    order_1_7  connected_order_arc_918  -1
    order_1_7  connected_order_arc_920  -1
    order_1_7  connected_order_arc_922  -1
    order_1_7  connected_order_arc_924  -1
    order_1_7  connected_order_arc_926  -1
    order_1_7  connected_order_arc_928  -1
    order_1_7  connected_order_arc_930  -1
    order_1_7  connected_order_arc_935  1
    order_1_7  connected_order_arc_958  1
    order_1_7  connected_order_arc_981  1
    order_1_7  connected_order_arc_1004  1
    order_1_7  connected_order_arc_1027  1
    order_1_7  connected_order_arc_1050  1
    order_1_7  connected_order_arc_1073  1
    order_1_7  connected_order_arc_1096  1
    order_1_7  connected_order_arc_1119  1
    order_1_7  connected_order_arc_1142  1
    order_1_7  order_active_lb_1172  1
    order_1_7  order_active_ub_1173  1
    order_1_7  fixed_segment_relative_order_1239  1
    order_1_7  fixed_segment_relative_order_1240  -1
    visit_1_8  out_degree_1177  -1
    visit_1_8  in_degree_1178  -1
    visit_1_8  order_active_lb_1179  -1
    visit_1_8  order_active_ub_1180  -12
    order_1_8  connected_order_arc_889  1
    order_1_8  connected_order_arc_912  1
    order_1_8  connected_order_arc_933  -1
    order_1_8  connected_order_arc_935  -1
    order_1_8  connected_order_arc_937  -1
    order_1_8  connected_order_arc_939  -1
    order_1_8  connected_order_arc_941  -1
    order_1_8  connected_order_arc_943  -1
    order_1_8  connected_order_arc_945  -1
    order_1_8  connected_order_arc_947  -1
    order_1_8  connected_order_arc_949  -1
    order_1_8  connected_order_arc_951  -1
    order_1_8  connected_order_arc_953  -1
    order_1_8  connected_order_arc_960  1
    order_1_8  connected_order_arc_983  1
    order_1_8  connected_order_arc_1006  1
    order_1_8  connected_order_arc_1029  1
    order_1_8  connected_order_arc_1052  1
    order_1_8  connected_order_arc_1075  1
    order_1_8  connected_order_arc_1098  1
    order_1_8  connected_order_arc_1121  1
    order_1_8  connected_order_arc_1144  1
    order_1_8  order_active_lb_1179  1
    order_1_8  order_active_ub_1180  1
    order_1_8  fixed_segment_relative_order_1240  1
    order_1_8  fixed_segment_relative_order_1241  -1
    visit_1_9  out_degree_1184  -1
    visit_1_9  in_degree_1185  -1
    visit_1_9  order_active_lb_1186  -1
    visit_1_9  order_active_ub_1187  -12
    order_1_9  connected_order_arc_891  1
    order_1_9  connected_order_arc_914  1
    order_1_9  connected_order_arc_937  1
    order_1_9  connected_order_arc_956  -1
    order_1_9  connected_order_arc_958  -1
    order_1_9  connected_order_arc_960  -1
    order_1_9  connected_order_arc_962  -1
    order_1_9  connected_order_arc_964  -1
    order_1_9  connected_order_arc_966  -1
    order_1_9  connected_order_arc_968  -1
    order_1_9  connected_order_arc_970  -1
    order_1_9  connected_order_arc_972  -1
    order_1_9  connected_order_arc_974  -1
    order_1_9  connected_order_arc_976  -1
    order_1_9  connected_order_arc_985  1
    order_1_9  connected_order_arc_1008  1
    order_1_9  connected_order_arc_1031  1
    order_1_9  connected_order_arc_1054  1
    order_1_9  connected_order_arc_1077  1
    order_1_9  connected_order_arc_1100  1
    order_1_9  connected_order_arc_1123  1
    order_1_9  connected_order_arc_1146  1
    order_1_9  order_active_lb_1186  1
    order_1_9  order_active_ub_1187  1
    order_1_9  fixed_segment_relative_order_1241  1
    visit_1_13  out_degree_1191  -1
    visit_1_13  in_degree_1192  -1
    visit_1_13  order_active_lb_1193  -1
    visit_1_13  order_active_ub_1194  -12
    visit_1_13  service_visit_def_1195  -1
    order_1_13  connected_order_arc_893  1
    order_1_13  connected_order_arc_916  1
    order_1_13  connected_order_arc_939  1
    order_1_13  connected_order_arc_962  1
    order_1_13  connected_order_arc_979  -1
    order_1_13  connected_order_arc_981  -1
    order_1_13  connected_order_arc_983  -1
    order_1_13  connected_order_arc_985  -1
    order_1_13  connected_order_arc_987  -1
    order_1_13  connected_order_arc_989  -1
    order_1_13  connected_order_arc_991  -1
    order_1_13  connected_order_arc_993  -1
    order_1_13  connected_order_arc_995  -1
    order_1_13  connected_order_arc_997  -1
    order_1_13  connected_order_arc_999  -1
    order_1_13  connected_order_arc_1010  1
    order_1_13  connected_order_arc_1033  1
    order_1_13  connected_order_arc_1056  1
    order_1_13  connected_order_arc_1079  1
    order_1_13  connected_order_arc_1102  1
    order_1_13  connected_order_arc_1125  1
    order_1_13  connected_order_arc_1148  1
    order_1_13  order_active_lb_1193  1
    order_1_13  order_active_ub_1194  1
    visit_1_14  out_degree_1197  -1
    visit_1_14  in_degree_1198  -1
    visit_1_14  order_active_lb_1199  -1
    visit_1_14  order_active_ub_1200  -12
    visit_1_14  service_visit_def_1201  -1
    order_1_14  connected_order_arc_895  1
    order_1_14  connected_order_arc_918  1
    order_1_14  connected_order_arc_941  1
    order_1_14  connected_order_arc_964  1
    order_1_14  connected_order_arc_987  1
    order_1_14  connected_order_arc_1002  -1
    order_1_14  connected_order_arc_1004  -1
    order_1_14  connected_order_arc_1006  -1
    order_1_14  connected_order_arc_1008  -1
    order_1_14  connected_order_arc_1010  -1
    order_1_14  connected_order_arc_1012  -1
    order_1_14  connected_order_arc_1014  -1
    order_1_14  connected_order_arc_1016  -1
    order_1_14  connected_order_arc_1018  -1
    order_1_14  connected_order_arc_1020  -1
    order_1_14  connected_order_arc_1022  -1
    order_1_14  connected_order_arc_1035  1
    order_1_14  connected_order_arc_1058  1
    order_1_14  connected_order_arc_1081  1
    order_1_14  connected_order_arc_1104  1
    order_1_14  connected_order_arc_1127  1
    order_1_14  connected_order_arc_1150  1
    order_1_14  order_active_lb_1199  1
    order_1_14  order_active_ub_1200  1
    visit_1_15  out_degree_1203  -1
    visit_1_15  in_degree_1204  -1
    visit_1_15  order_active_lb_1205  -1
    visit_1_15  order_active_ub_1206  -12
    visit_1_15  service_visit_def_1207  -1
    order_1_15  connected_order_arc_897  1
    order_1_15  connected_order_arc_920  1
    order_1_15  connected_order_arc_943  1
    order_1_15  connected_order_arc_966  1
    order_1_15  connected_order_arc_989  1
    order_1_15  connected_order_arc_1012  1
    order_1_15  connected_order_arc_1025  -1
    order_1_15  connected_order_arc_1027  -1
    order_1_15  connected_order_arc_1029  -1
    order_1_15  connected_order_arc_1031  -1
    order_1_15  connected_order_arc_1033  -1
    order_1_15  connected_order_arc_1035  -1
    order_1_15  connected_order_arc_1037  -1
    order_1_15  connected_order_arc_1039  -1
    order_1_15  connected_order_arc_1041  -1
    order_1_15  connected_order_arc_1043  -1
    order_1_15  connected_order_arc_1045  -1
    order_1_15  connected_order_arc_1060  1
    order_1_15  connected_order_arc_1083  1
    order_1_15  connected_order_arc_1106  1
    order_1_15  connected_order_arc_1129  1
    order_1_15  connected_order_arc_1152  1
    order_1_15  order_active_lb_1205  1
    order_1_15  order_active_ub_1206  1
    visit_1_16  out_degree_1209  -1
    visit_1_16  in_degree_1210  -1
    visit_1_16  order_active_lb_1211  -1
    visit_1_16  order_active_ub_1212  -12
    visit_1_16  service_visit_def_1213  -1
    order_1_16  connected_order_arc_899  1
    order_1_16  connected_order_arc_922  1
    order_1_16  connected_order_arc_945  1
    order_1_16  connected_order_arc_968  1
    order_1_16  connected_order_arc_991  1
    order_1_16  connected_order_arc_1014  1
    order_1_16  connected_order_arc_1037  1
    order_1_16  connected_order_arc_1048  -1
    order_1_16  connected_order_arc_1050  -1
    order_1_16  connected_order_arc_1052  -1
    order_1_16  connected_order_arc_1054  -1
    order_1_16  connected_order_arc_1056  -1
    order_1_16  connected_order_arc_1058  -1
    order_1_16  connected_order_arc_1060  -1
    order_1_16  connected_order_arc_1062  -1
    order_1_16  connected_order_arc_1064  -1
    order_1_16  connected_order_arc_1066  -1
    order_1_16  connected_order_arc_1068  -1
    order_1_16  connected_order_arc_1085  1
    order_1_16  connected_order_arc_1108  1
    order_1_16  connected_order_arc_1131  1
    order_1_16  connected_order_arc_1154  1
    order_1_16  order_active_lb_1211  1
    order_1_16  order_active_ub_1212  1
    visit_1_17  out_degree_1215  -1
    visit_1_17  in_degree_1216  -1
    visit_1_17  order_active_lb_1217  -1
    visit_1_17  order_active_ub_1218  -12
    visit_1_17  service_visit_def_1219  -1
    order_1_17  connected_order_arc_901  1
    order_1_17  connected_order_arc_924  1
    order_1_17  connected_order_arc_947  1
    order_1_17  connected_order_arc_970  1
    order_1_17  connected_order_arc_993  1
    order_1_17  connected_order_arc_1016  1
    order_1_17  connected_order_arc_1039  1
    order_1_17  connected_order_arc_1062  1
    order_1_17  connected_order_arc_1071  -1
    order_1_17  connected_order_arc_1073  -1
    order_1_17  connected_order_arc_1075  -1
    order_1_17  connected_order_arc_1077  -1
    order_1_17  connected_order_arc_1079  -1
    order_1_17  connected_order_arc_1081  -1
    order_1_17  connected_order_arc_1083  -1
    order_1_17  connected_order_arc_1085  -1
    order_1_17  connected_order_arc_1087  -1
    order_1_17  connected_order_arc_1089  -1
    order_1_17  connected_order_arc_1091  -1
    order_1_17  connected_order_arc_1110  1
    order_1_17  connected_order_arc_1133  1
    order_1_17  connected_order_arc_1156  1
    order_1_17  order_active_lb_1217  1
    order_1_17  order_active_ub_1218  1
    visit_1_18  out_degree_1221  -1
    visit_1_18  in_degree_1222  -1
    visit_1_18  order_active_lb_1223  -1
    visit_1_18  order_active_ub_1224  -12
    visit_1_18  service_visit_def_1225  -1
    order_1_18  connected_order_arc_903  1
    order_1_18  connected_order_arc_926  1
    order_1_18  connected_order_arc_949  1
    order_1_18  connected_order_arc_972  1
    order_1_18  connected_order_arc_995  1
    order_1_18  connected_order_arc_1018  1
    order_1_18  connected_order_arc_1041  1
    order_1_18  connected_order_arc_1064  1
    order_1_18  connected_order_arc_1087  1
    order_1_18  connected_order_arc_1094  -1
    order_1_18  connected_order_arc_1096  -1
    order_1_18  connected_order_arc_1098  -1
    order_1_18  connected_order_arc_1100  -1
    order_1_18  connected_order_arc_1102  -1
    order_1_18  connected_order_arc_1104  -1
    order_1_18  connected_order_arc_1106  -1
    order_1_18  connected_order_arc_1108  -1
    order_1_18  connected_order_arc_1110  -1
    order_1_18  connected_order_arc_1112  -1
    order_1_18  connected_order_arc_1114  -1
    order_1_18  connected_order_arc_1135  1
    order_1_18  connected_order_arc_1158  1
    order_1_18  order_active_lb_1223  1
    order_1_18  order_active_ub_1224  1
    visit_1_19  out_degree_1227  -1
    visit_1_19  in_degree_1228  -1
    visit_1_19  order_active_lb_1229  -1
    visit_1_19  order_active_ub_1230  -12
    visit_1_19  service_visit_def_1231  -1
    order_1_19  connected_order_arc_905  1
    order_1_19  connected_order_arc_928  1
    order_1_19  connected_order_arc_951  1
    order_1_19  connected_order_arc_974  1
    order_1_19  connected_order_arc_997  1
    order_1_19  connected_order_arc_1020  1
    order_1_19  connected_order_arc_1043  1
    order_1_19  connected_order_arc_1066  1
    order_1_19  connected_order_arc_1089  1
    order_1_19  connected_order_arc_1112  1
    order_1_19  connected_order_arc_1117  -1
    order_1_19  connected_order_arc_1119  -1
    order_1_19  connected_order_arc_1121  -1
    order_1_19  connected_order_arc_1123  -1
    order_1_19  connected_order_arc_1125  -1
    order_1_19  connected_order_arc_1127  -1
    order_1_19  connected_order_arc_1129  -1
    order_1_19  connected_order_arc_1131  -1
    order_1_19  connected_order_arc_1133  -1
    order_1_19  connected_order_arc_1135  -1
    order_1_19  connected_order_arc_1137  -1
    order_1_19  connected_order_arc_1160  1
    order_1_19  order_active_lb_1229  1
    order_1_19  order_active_ub_1230  1
    visit_1_20  out_degree_1233  -1
    visit_1_20  in_degree_1234  -1
    visit_1_20  order_active_lb_1235  -1
    visit_1_20  order_active_ub_1236  -12
    visit_1_20  service_visit_def_1237  -1
    order_1_20  connected_order_arc_907  1
    order_1_20  connected_order_arc_930  1
    order_1_20  connected_order_arc_953  1
    order_1_20  connected_order_arc_976  1
    order_1_20  connected_order_arc_999  1
    order_1_20  connected_order_arc_1022  1
    order_1_20  connected_order_arc_1045  1
    order_1_20  connected_order_arc_1068  1
    order_1_20  connected_order_arc_1091  1
    order_1_20  connected_order_arc_1114  1
    order_1_20  connected_order_arc_1137  1
    order_1_20  connected_order_arc_1140  -1
    order_1_20  connected_order_arc_1142  -1
    order_1_20  connected_order_arc_1144  -1
    order_1_20  connected_order_arc_1146  -1
    order_1_20  connected_order_arc_1148  -1
    order_1_20  connected_order_arc_1150  -1
    order_1_20  connected_order_arc_1152  -1
    order_1_20  connected_order_arc_1154  -1
    order_1_20  connected_order_arc_1156  -1
    order_1_20  connected_order_arc_1158  -1
    order_1_20  connected_order_arc_1160  -1
    order_1_20  order_active_lb_1235  1
    order_1_20  order_active_ub_1236  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_872  -25
    arc_1_0_0  depot_departure_or_bypass_1161  1
    arc_1_0_0  depot_return_or_bypass_1162  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_872  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_873  -25
    arc_1_0_6  depot_departure_or_bypass_1161  1
    arc_1_0_6  in_degree_1164  1
    arc_1_0_6  original_T_including_depot_unload_1242  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_873  1
    load_1_0_6  segment_load_conservation_1167  -1
    load_1_0_6  segment_prefix_lb_1168  1
    load_1_0_6  segment_prefix_ub_1169  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_874  -25
    arc_1_0_7  depot_departure_or_bypass_1161  1
    arc_1_0_7  in_degree_1171  1
    arc_1_0_7  original_T_including_depot_unload_1242  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_874  1
    load_1_0_7  segment_load_conservation_1174  -1
    load_1_0_7  segment_prefix_lb_1175  1
    load_1_0_7  segment_prefix_ub_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_875  -25
    arc_1_0_8  depot_departure_or_bypass_1161  1
    arc_1_0_8  in_degree_1178  1
    arc_1_0_8  original_T_including_depot_unload_1242  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_875  1
    load_1_0_8  segment_load_conservation_1181  -1
    load_1_0_8  segment_prefix_lb_1182  1
    load_1_0_8  segment_prefix_ub_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_876  -25
    arc_1_0_9  depot_departure_or_bypass_1161  1
    arc_1_0_9  in_degree_1185  1
    arc_1_0_9  original_T_including_depot_unload_1242  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_876  1
    load_1_0_9  segment_load_conservation_1188  -1
    load_1_0_9  segment_prefix_lb_1189  1
    load_1_0_9  segment_prefix_ub_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_877  -25
    arc_1_0_13  depot_departure_or_bypass_1161  1
    arc_1_0_13  in_degree_1192  1
    arc_1_0_13  original_T_including_depot_unload_1242  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_877  1
    load_1_0_13  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_878  -25
    arc_1_0_14  depot_departure_or_bypass_1161  1
    arc_1_0_14  in_degree_1198  1
    arc_1_0_14  original_T_including_depot_unload_1242  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_878  1
    load_1_0_14  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_879  -25
    arc_1_0_15  depot_departure_or_bypass_1161  1
    arc_1_0_15  in_degree_1204  1
    arc_1_0_15  original_T_including_depot_unload_1242  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_879  1
    load_1_0_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_880  -25
    arc_1_0_16  depot_departure_or_bypass_1161  1
    arc_1_0_16  in_degree_1210  1
    arc_1_0_16  original_T_including_depot_unload_1242  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_880  1
    load_1_0_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_881  -25
    arc_1_0_17  depot_departure_or_bypass_1161  1
    arc_1_0_17  in_degree_1216  1
    arc_1_0_17  original_T_including_depot_unload_1242  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_881  1
    load_1_0_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_882  -25
    arc_1_0_18  depot_departure_or_bypass_1161  1
    arc_1_0_18  in_degree_1222  1
    arc_1_0_18  original_T_including_depot_unload_1242  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_882  1
    load_1_0_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_883  -25
    arc_1_0_19  depot_departure_or_bypass_1161  1
    arc_1_0_19  in_degree_1228  1
    arc_1_0_19  original_T_including_depot_unload_1242  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_883  1
    load_1_0_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_884  -25
    arc_1_0_20  depot_departure_or_bypass_1161  1
    arc_1_0_20  in_degree_1234  1
    arc_1_0_20  original_T_including_depot_unload_1242  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_884  1
    load_1_0_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_885  -25
    arc_1_6_0  depot_return_or_bypass_1162  1
    arc_1_6_0  out_degree_1163  1
    arc_1_6_0  original_T_including_depot_unload_1242  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_885  1
    load_1_6_0  segment_load_conservation_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_886  -25
    arc_1_6_7  connected_order_arc_887  -13
    arc_1_6_7  out_degree_1163  1
    arc_1_6_7  in_degree_1171  1
    arc_1_6_7  original_T_including_depot_unload_1242  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_886  1
    load_1_6_7  segment_load_conservation_1167  1
    load_1_6_7  segment_load_conservation_1174  -1
    load_1_6_7  segment_prefix_lb_1175  1
    load_1_6_7  segment_prefix_ub_1176  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_888  -25
    arc_1_6_8  connected_order_arc_889  -13
    arc_1_6_8  out_degree_1163  1
    arc_1_6_8  in_degree_1178  1
    arc_1_6_8  original_T_including_depot_unload_1242  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_888  1
    load_1_6_8  segment_load_conservation_1167  1
    load_1_6_8  segment_load_conservation_1181  -1
    load_1_6_8  segment_prefix_lb_1182  1
    load_1_6_8  segment_prefix_ub_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_890  -25
    arc_1_6_9  connected_order_arc_891  -13
    arc_1_6_9  out_degree_1163  1
    arc_1_6_9  in_degree_1185  1
    arc_1_6_9  original_T_including_depot_unload_1242  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_890  1
    load_1_6_9  segment_load_conservation_1167  1
    load_1_6_9  segment_load_conservation_1188  -1
    load_1_6_9  segment_prefix_lb_1189  1
    load_1_6_9  segment_prefix_ub_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_892  -25
    arc_1_6_13  connected_order_arc_893  -13
    arc_1_6_13  out_degree_1163  1
    arc_1_6_13  in_degree_1192  1
    arc_1_6_13  original_T_including_depot_unload_1242  1.4829753176244692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_892  1
    load_1_6_13  segment_load_conservation_1167  1
    load_1_6_13  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_894  -25
    arc_1_6_14  connected_order_arc_895  -13
    arc_1_6_14  out_degree_1163  1
    arc_1_6_14  in_degree_1198  1
    arc_1_6_14  original_T_including_depot_unload_1242  1.5393904884690303e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_894  1
    load_1_6_14  segment_load_conservation_1167  1
    load_1_6_14  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_896  -25
    arc_1_6_15  connected_order_arc_897  -13
    arc_1_6_15  out_degree_1163  1
    arc_1_6_15  in_degree_1204  1
    arc_1_6_15  original_T_including_depot_unload_1242  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_896  1
    load_1_6_15  segment_load_conservation_1167  1
    load_1_6_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_898  -25
    arc_1_6_16  connected_order_arc_899  -13
    arc_1_6_16  out_degree_1163  1
    arc_1_6_16  in_degree_1210  1
    arc_1_6_16  original_T_including_depot_unload_1242  1.5145600125783847e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_898  1
    load_1_6_16  segment_load_conservation_1167  1
    load_1_6_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_900  -25
    arc_1_6_17  connected_order_arc_901  -13
    arc_1_6_17  out_degree_1163  1
    arc_1_6_17  in_degree_1216  1
    arc_1_6_17  original_T_including_depot_unload_1242  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_900  1
    load_1_6_17  segment_load_conservation_1167  1
    load_1_6_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_902  -25
    arc_1_6_18  connected_order_arc_903  -13
    arc_1_6_18  out_degree_1163  1
    arc_1_6_18  in_degree_1222  1
    arc_1_6_18  original_T_including_depot_unload_1242  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_902  1
    load_1_6_18  segment_load_conservation_1167  1
    load_1_6_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_904  -25
    arc_1_6_19  connected_order_arc_905  -13
    arc_1_6_19  out_degree_1163  1
    arc_1_6_19  in_degree_1228  1
    arc_1_6_19  original_T_including_depot_unload_1242  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_904  1
    load_1_6_19  segment_load_conservation_1167  1
    load_1_6_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_906  -25
    arc_1_6_20  connected_order_arc_907  -13
    arc_1_6_20  out_degree_1163  1
    arc_1_6_20  in_degree_1234  1
    arc_1_6_20  original_T_including_depot_unload_1242  1.7520337176349503e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_906  1
    load_1_6_20  segment_load_conservation_1167  1
    load_1_6_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_908  -25
    arc_1_7_0  depot_return_or_bypass_1162  1
    arc_1_7_0  out_degree_1170  1
    arc_1_7_0  original_T_including_depot_unload_1242  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_908  1
    load_1_7_0  segment_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_909  -25
    arc_1_7_6  connected_order_arc_910  -13
    arc_1_7_6  in_degree_1164  1
    arc_1_7_6  out_degree_1170  1
    arc_1_7_6  original_T_including_depot_unload_1242  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_909  1
    load_1_7_6  segment_load_conservation_1167  -1
    load_1_7_6  segment_prefix_lb_1168  1
    load_1_7_6  segment_prefix_ub_1169  1
    load_1_7_6  segment_load_conservation_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_911  -25
    arc_1_7_8  connected_order_arc_912  -13
    arc_1_7_8  out_degree_1170  1
    arc_1_7_8  in_degree_1178  1
    arc_1_7_8  original_T_including_depot_unload_1242  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_911  1
    load_1_7_8  segment_load_conservation_1174  1
    load_1_7_8  segment_load_conservation_1181  -1
    load_1_7_8  segment_prefix_lb_1182  1
    load_1_7_8  segment_prefix_ub_1183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_913  -25
    arc_1_7_9  connected_order_arc_914  -13
    arc_1_7_9  out_degree_1170  1
    arc_1_7_9  in_degree_1185  1
    arc_1_7_9  original_T_including_depot_unload_1242  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_913  1
    load_1_7_9  segment_load_conservation_1174  1
    load_1_7_9  segment_load_conservation_1188  -1
    load_1_7_9  segment_prefix_lb_1189  1
    load_1_7_9  segment_prefix_ub_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_915  -25
    arc_1_7_13  connected_order_arc_916  -13
    arc_1_7_13  out_degree_1170  1
    arc_1_7_13  in_degree_1192  1
    arc_1_7_13  original_T_including_depot_unload_1242  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_915  1
    load_1_7_13  segment_load_conservation_1174  1
    load_1_7_13  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_917  -25
    arc_1_7_14  connected_order_arc_918  -13
    arc_1_7_14  out_degree_1170  1
    arc_1_7_14  in_degree_1198  1
    arc_1_7_14  original_T_including_depot_unload_1242  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_917  1
    load_1_7_14  segment_load_conservation_1174  1
    load_1_7_14  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_919  -25
    arc_1_7_15  connected_order_arc_920  -13
    arc_1_7_15  out_degree_1170  1
    arc_1_7_15  in_degree_1204  1
    arc_1_7_15  original_T_including_depot_unload_1242  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_919  1
    load_1_7_15  segment_load_conservation_1174  1
    load_1_7_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_921  -25
    arc_1_7_16  connected_order_arc_922  -13
    arc_1_7_16  out_degree_1170  1
    arc_1_7_16  in_degree_1210  1
    arc_1_7_16  original_T_including_depot_unload_1242  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_921  1
    load_1_7_16  segment_load_conservation_1174  1
    load_1_7_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_923  -25
    arc_1_7_17  connected_order_arc_924  -13
    arc_1_7_17  out_degree_1170  1
    arc_1_7_17  in_degree_1216  1
    arc_1_7_17  original_T_including_depot_unload_1242  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_923  1
    load_1_7_17  segment_load_conservation_1174  1
    load_1_7_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_925  -25
    arc_1_7_18  connected_order_arc_926  -13
    arc_1_7_18  out_degree_1170  1
    arc_1_7_18  in_degree_1222  1
    arc_1_7_18  original_T_including_depot_unload_1242  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_925  1
    load_1_7_18  segment_load_conservation_1174  1
    load_1_7_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_927  -25
    arc_1_7_19  connected_order_arc_928  -13
    arc_1_7_19  out_degree_1170  1
    arc_1_7_19  in_degree_1228  1
    arc_1_7_19  original_T_including_depot_unload_1242  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_927  1
    load_1_7_19  segment_load_conservation_1174  1
    load_1_7_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_929  -25
    arc_1_7_20  connected_order_arc_930  -13
    arc_1_7_20  out_degree_1170  1
    arc_1_7_20  in_degree_1234  1
    arc_1_7_20  original_T_including_depot_unload_1242  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_929  1
    load_1_7_20  segment_load_conservation_1174  1
    load_1_7_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_931  -25
    arc_1_8_0  depot_return_or_bypass_1162  1
    arc_1_8_0  out_degree_1177  1
    arc_1_8_0  original_T_including_depot_unload_1242  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_931  1
    load_1_8_0  segment_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_932  -25
    arc_1_8_6  connected_order_arc_933  -13
    arc_1_8_6  in_degree_1164  1
    arc_1_8_6  out_degree_1177  1
    arc_1_8_6  original_T_including_depot_unload_1242  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_932  1
    load_1_8_6  segment_load_conservation_1167  -1
    load_1_8_6  segment_prefix_lb_1168  1
    load_1_8_6  segment_prefix_ub_1169  1
    load_1_8_6  segment_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_934  -25
    arc_1_8_7  connected_order_arc_935  -13
    arc_1_8_7  in_degree_1171  1
    arc_1_8_7  out_degree_1177  1
    arc_1_8_7  original_T_including_depot_unload_1242  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_934  1
    load_1_8_7  segment_load_conservation_1174  -1
    load_1_8_7  segment_prefix_lb_1175  1
    load_1_8_7  segment_prefix_ub_1176  1
    load_1_8_7  segment_load_conservation_1181  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_936  -25
    arc_1_8_9  connected_order_arc_937  -13
    arc_1_8_9  out_degree_1177  1
    arc_1_8_9  in_degree_1185  1
    arc_1_8_9  original_T_including_depot_unload_1242  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_936  1
    load_1_8_9  segment_load_conservation_1181  1
    load_1_8_9  segment_load_conservation_1188  -1
    load_1_8_9  segment_prefix_lb_1189  1
    load_1_8_9  segment_prefix_ub_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_938  -25
    arc_1_8_13  connected_order_arc_939  -13
    arc_1_8_13  out_degree_1177  1
    arc_1_8_13  in_degree_1192  1
    arc_1_8_13  original_T_including_depot_unload_1242  1.0213043329444467e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_938  1
    load_1_8_13  segment_load_conservation_1181  1
    load_1_8_13  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_940  -25
    arc_1_8_14  connected_order_arc_941  -13
    arc_1_8_14  out_degree_1177  1
    arc_1_8_14  in_degree_1198  1
    arc_1_8_14  original_T_including_depot_unload_1242  1.1750055851715294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_940  1
    load_1_8_14  segment_load_conservation_1181  1
    load_1_8_14  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_942  -25
    arc_1_8_15  connected_order_arc_943  -13
    arc_1_8_15  out_degree_1177  1
    arc_1_8_15  in_degree_1204  1
    arc_1_8_15  original_T_including_depot_unload_1242  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_942  1
    load_1_8_15  segment_load_conservation_1181  1
    load_1_8_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_944  -25
    arc_1_8_16  connected_order_arc_945  -13
    arc_1_8_16  out_degree_1177  1
    arc_1_8_16  in_degree_1210  1
    arc_1_8_16  original_T_including_depot_unload_1242  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_944  1
    load_1_8_16  segment_load_conservation_1181  1
    load_1_8_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_946  -25
    arc_1_8_17  connected_order_arc_947  -13
    arc_1_8_17  out_degree_1177  1
    arc_1_8_17  in_degree_1216  1
    arc_1_8_17  original_T_including_depot_unload_1242  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_946  1
    load_1_8_17  segment_load_conservation_1181  1
    load_1_8_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_948  -25
    arc_1_8_18  connected_order_arc_949  -13
    arc_1_8_18  out_degree_1177  1
    arc_1_8_18  in_degree_1222  1
    arc_1_8_18  original_T_including_depot_unload_1242  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_948  1
    load_1_8_18  segment_load_conservation_1181  1
    load_1_8_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_950  -25
    arc_1_8_19  connected_order_arc_951  -13
    arc_1_8_19  out_degree_1177  1
    arc_1_8_19  in_degree_1228  1
    arc_1_8_19  original_T_including_depot_unload_1242  1.6048175645110312e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_950  1
    load_1_8_19  segment_load_conservation_1181  1
    load_1_8_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_952  -25
    arc_1_8_20  connected_order_arc_953  -13
    arc_1_8_20  out_degree_1177  1
    arc_1_8_20  in_degree_1234  1
    arc_1_8_20  original_T_including_depot_unload_1242  1.2628291878233333e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_952  1
    load_1_8_20  segment_load_conservation_1181  1
    load_1_8_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_954  -25
    arc_1_9_0  depot_return_or_bypass_1162  1
    arc_1_9_0  out_degree_1184  1
    arc_1_9_0  original_T_including_depot_unload_1242  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_954  1
    load_1_9_0  segment_load_conservation_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_955  -25
    arc_1_9_6  connected_order_arc_956  -13
    arc_1_9_6  in_degree_1164  1
    arc_1_9_6  out_degree_1184  1
    arc_1_9_6  original_T_including_depot_unload_1242  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_955  1
    load_1_9_6  segment_load_conservation_1167  -1
    load_1_9_6  segment_prefix_lb_1168  1
    load_1_9_6  segment_prefix_ub_1169  1
    load_1_9_6  segment_load_conservation_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_957  -25
    arc_1_9_7  connected_order_arc_958  -13
    arc_1_9_7  in_degree_1171  1
    arc_1_9_7  out_degree_1184  1
    arc_1_9_7  original_T_including_depot_unload_1242  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_957  1
    load_1_9_7  segment_load_conservation_1174  -1
    load_1_9_7  segment_prefix_lb_1175  1
    load_1_9_7  segment_prefix_ub_1176  1
    load_1_9_7  segment_load_conservation_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_959  -25
    arc_1_9_8  connected_order_arc_960  -13
    arc_1_9_8  in_degree_1178  1
    arc_1_9_8  out_degree_1184  1
    arc_1_9_8  original_T_including_depot_unload_1242  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_959  1
    load_1_9_8  segment_load_conservation_1181  -1
    load_1_9_8  segment_prefix_lb_1182  1
    load_1_9_8  segment_prefix_ub_1183  1
    load_1_9_8  segment_load_conservation_1188  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_961  -25
    arc_1_9_13  connected_order_arc_962  -13
    arc_1_9_13  out_degree_1184  1
    arc_1_9_13  in_degree_1192  1
    arc_1_9_13  original_T_including_depot_unload_1242  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_961  1
    load_1_9_13  segment_load_conservation_1188  1
    load_1_9_13  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_963  -25
    arc_1_9_14  connected_order_arc_964  -13
    arc_1_9_14  out_degree_1184  1
    arc_1_9_14  in_degree_1198  1
    arc_1_9_14  original_T_including_depot_unload_1242  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_963  1
    load_1_9_14  segment_load_conservation_1188  1
    load_1_9_14  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_965  -25
    arc_1_9_15  connected_order_arc_966  -13
    arc_1_9_15  out_degree_1184  1
    arc_1_9_15  in_degree_1204  1
    arc_1_9_15  original_T_including_depot_unload_1242  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_965  1
    load_1_9_15  segment_load_conservation_1188  1
    load_1_9_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_967  -25
    arc_1_9_16  connected_order_arc_968  -13
    arc_1_9_16  out_degree_1184  1
    arc_1_9_16  in_degree_1210  1
    arc_1_9_16  original_T_including_depot_unload_1242  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_967  1
    load_1_9_16  segment_load_conservation_1188  1
    load_1_9_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_969  -25
    arc_1_9_17  connected_order_arc_970  -13
    arc_1_9_17  out_degree_1184  1
    arc_1_9_17  in_degree_1216  1
    arc_1_9_17  original_T_including_depot_unload_1242  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_969  1
    load_1_9_17  segment_load_conservation_1188  1
    load_1_9_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_971  -25
    arc_1_9_18  connected_order_arc_972  -13
    arc_1_9_18  out_degree_1184  1
    arc_1_9_18  in_degree_1222  1
    arc_1_9_18  original_T_including_depot_unload_1242  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_971  1
    load_1_9_18  segment_load_conservation_1188  1
    load_1_9_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_973  -25
    arc_1_9_19  connected_order_arc_974  -13
    arc_1_9_19  out_degree_1184  1
    arc_1_9_19  in_degree_1228  1
    arc_1_9_19  original_T_including_depot_unload_1242  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_973  1
    load_1_9_19  segment_load_conservation_1188  1
    load_1_9_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_975  -25
    arc_1_9_20  connected_order_arc_976  -13
    arc_1_9_20  out_degree_1184  1
    arc_1_9_20  in_degree_1234  1
    arc_1_9_20  original_T_including_depot_unload_1242  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_975  1
    load_1_9_20  segment_load_conservation_1188  1
    load_1_9_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_977  -25
    arc_1_13_0  depot_return_or_bypass_1162  1
    arc_1_13_0  out_degree_1191  1
    arc_1_13_0  original_T_including_depot_unload_1242  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_977  1
    load_1_13_0  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_978  -25
    arc_1_13_6  connected_order_arc_979  -13
    arc_1_13_6  in_degree_1164  1
    arc_1_13_6  out_degree_1191  1
    arc_1_13_6  original_T_including_depot_unload_1242  1.2798962893775918e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_978  1
    load_1_13_6  segment_load_conservation_1167  -1
    load_1_13_6  segment_prefix_lb_1168  1
    load_1_13_6  segment_prefix_ub_1169  1
    load_1_13_6  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_980  -25
    arc_1_13_7  connected_order_arc_981  -13
    arc_1_13_7  in_degree_1171  1
    arc_1_13_7  out_degree_1191  1
    arc_1_13_7  original_T_including_depot_unload_1242  1.3293032990949939e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_980  1
    load_1_13_7  segment_load_conservation_1174  -1
    load_1_13_7  segment_prefix_lb_1175  1
    load_1_13_7  segment_prefix_ub_1176  1
    load_1_13_7  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_982  -25
    arc_1_13_8  connected_order_arc_983  -13
    arc_1_13_8  in_degree_1178  1
    arc_1_13_8  out_degree_1191  1
    arc_1_13_8  original_T_including_depot_unload_1242  1.3874440214926751e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_982  1
    load_1_13_8  segment_load_conservation_1181  -1
    load_1_13_8  segment_prefix_lb_1182  1
    load_1_13_8  segment_prefix_ub_1183  1
    load_1_13_8  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_984  -25
    arc_1_13_9  connected_order_arc_985  -13
    arc_1_13_9  in_degree_1185  1
    arc_1_13_9  out_degree_1191  1
    arc_1_13_9  original_T_including_depot_unload_1242  6.8976718276177132e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_984  1
    load_1_13_9  segment_load_conservation_1188  -1
    load_1_13_9  segment_prefix_lb_1189  1
    load_1_13_9  segment_prefix_ub_1190  1
    load_1_13_9  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_986  -25
    arc_1_13_14  connected_order_arc_987  -13
    arc_1_13_14  out_degree_1191  1
    arc_1_13_14  in_degree_1198  1
    arc_1_13_14  original_T_including_depot_unload_1242  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_986  1
    load_1_13_14  free_load_conservation_1196  1
    load_1_13_14  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_988  -25
    arc_1_13_15  connected_order_arc_989  -13
    arc_1_13_15  out_degree_1191  1
    arc_1_13_15  in_degree_1204  1
    arc_1_13_15  original_T_including_depot_unload_1242  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_988  1
    load_1_13_15  free_load_conservation_1196  1
    load_1_13_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_990  -25
    arc_1_13_16  connected_order_arc_991  -13
    arc_1_13_16  out_degree_1191  1
    arc_1_13_16  in_degree_1210  1
    arc_1_13_16  original_T_including_depot_unload_1242  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_990  1
    load_1_13_16  free_load_conservation_1196  1
    load_1_13_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_992  -25
    arc_1_13_17  connected_order_arc_993  -13
    arc_1_13_17  out_degree_1191  1
    arc_1_13_17  in_degree_1216  1
    arc_1_13_17  original_T_including_depot_unload_1242  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_992  1
    load_1_13_17  free_load_conservation_1196  1
    load_1_13_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_994  -25
    arc_1_13_18  connected_order_arc_995  -13
    arc_1_13_18  out_degree_1191  1
    arc_1_13_18  in_degree_1222  1
    arc_1_13_18  original_T_including_depot_unload_1242  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_994  1
    load_1_13_18  free_load_conservation_1196  1
    load_1_13_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_996  -25
    arc_1_13_19  connected_order_arc_997  -13
    arc_1_13_19  out_degree_1191  1
    arc_1_13_19  in_degree_1228  1
    arc_1_13_19  original_T_including_depot_unload_1242  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_996  1
    load_1_13_19  free_load_conservation_1196  1
    load_1_13_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_998  -25
    arc_1_13_20  connected_order_arc_999  -13
    arc_1_13_20  out_degree_1191  1
    arc_1_13_20  in_degree_1234  1
    arc_1_13_20  original_T_including_depot_unload_1242  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_998  1
    load_1_13_20  free_load_conservation_1196  1
    load_1_13_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_1000  -25
    arc_1_14_0  depot_return_or_bypass_1162  1
    arc_1_14_0  out_degree_1197  1
    arc_1_14_0  original_T_including_depot_unload_1242  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_1000  1
    load_1_14_0  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_1001  -25
    arc_1_14_6  connected_order_arc_1002  -13
    arc_1_14_6  in_degree_1164  1
    arc_1_14_6  out_degree_1197  1
    arc_1_14_6  original_T_including_depot_unload_1242  1.3600272346134373e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_1001  1
    load_1_14_6  segment_load_conservation_1167  -1
    load_1_14_6  segment_prefix_lb_1168  1
    load_1_14_6  segment_prefix_ub_1169  1
    load_1_14_6  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_1003  -25
    arc_1_14_7  connected_order_arc_1004  -13
    arc_1_14_7  in_degree_1171  1
    arc_1_14_7  out_degree_1197  1
    arc_1_14_7  original_T_including_depot_unload_1242  1.3653307388496069e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_1003  1
    load_1_14_7  segment_load_conservation_1174  -1
    load_1_14_7  segment_prefix_lb_1175  1
    load_1_14_7  segment_prefix_ub_1176  1
    load_1_14_7  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_1005  -25
    arc_1_14_8  connected_order_arc_1006  -13
    arc_1_14_8  in_degree_1178  1
    arc_1_14_8  out_degree_1197  1
    arc_1_14_8  original_T_including_depot_unload_1242  1.4805184908215606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_1005  1
    load_1_14_8  segment_load_conservation_1181  -1
    load_1_14_8  segment_prefix_lb_1182  1
    load_1_14_8  segment_prefix_ub_1183  1
    load_1_14_8  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_1007  -25
    arc_1_14_9  connected_order_arc_1008  -13
    arc_1_14_9  in_degree_1185  1
    arc_1_14_9  out_degree_1197  1
    arc_1_14_9  original_T_including_depot_unload_1242  8.4109491500688637e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_1007  1
    load_1_14_9  segment_load_conservation_1188  -1
    load_1_14_9  segment_prefix_lb_1189  1
    load_1_14_9  segment_prefix_ub_1190  1
    load_1_14_9  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_1009  -25
    arc_1_14_13  connected_order_arc_1010  -13
    arc_1_14_13  in_degree_1192  1
    arc_1_14_13  out_degree_1197  1
    arc_1_14_13  original_T_including_depot_unload_1242  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_1009  1
    load_1_14_13  free_load_conservation_1196  -1
    load_1_14_13  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_1011  -25
    arc_1_14_15  connected_order_arc_1012  -13
    arc_1_14_15  out_degree_1197  1
    arc_1_14_15  in_degree_1204  1
    arc_1_14_15  original_T_including_depot_unload_1242  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_1011  1
    load_1_14_15  free_load_conservation_1202  1
    load_1_14_15  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_1013  -25
    arc_1_14_16  connected_order_arc_1014  -13
    arc_1_14_16  out_degree_1197  1
    arc_1_14_16  in_degree_1210  1
    arc_1_14_16  original_T_including_depot_unload_1242  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_1013  1
    load_1_14_16  free_load_conservation_1202  1
    load_1_14_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_1015  -25
    arc_1_14_17  connected_order_arc_1016  -13
    arc_1_14_17  out_degree_1197  1
    arc_1_14_17  in_degree_1216  1
    arc_1_14_17  original_T_including_depot_unload_1242  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_1015  1
    load_1_14_17  free_load_conservation_1202  1
    load_1_14_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_1017  -25
    arc_1_14_18  connected_order_arc_1018  -13
    arc_1_14_18  out_degree_1197  1
    arc_1_14_18  in_degree_1222  1
    arc_1_14_18  original_T_including_depot_unload_1242  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_1017  1
    load_1_14_18  free_load_conservation_1202  1
    load_1_14_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_1019  -25
    arc_1_14_19  connected_order_arc_1020  -13
    arc_1_14_19  out_degree_1197  1
    arc_1_14_19  in_degree_1228  1
    arc_1_14_19  original_T_including_depot_unload_1242  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_1019  1
    load_1_14_19  free_load_conservation_1202  1
    load_1_14_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_1021  -25
    arc_1_14_20  connected_order_arc_1022  -13
    arc_1_14_20  out_degree_1197  1
    arc_1_14_20  in_degree_1234  1
    arc_1_14_20  original_T_including_depot_unload_1242  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_1021  1
    load_1_14_20  free_load_conservation_1202  1
    load_1_14_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_1023  -25
    arc_1_15_0  depot_return_or_bypass_1162  1
    arc_1_15_0  out_degree_1203  1
    arc_1_15_0  original_T_including_depot_unload_1242  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_1023  1
    load_1_15_0  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_1024  -25
    arc_1_15_6  connected_order_arc_1025  -13
    arc_1_15_6  in_degree_1164  1
    arc_1_15_6  out_degree_1203  1
    arc_1_15_6  original_T_including_depot_unload_1242  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_1024  1
    load_1_15_6  segment_load_conservation_1167  -1
    load_1_15_6  segment_prefix_lb_1168  1
    load_1_15_6  segment_prefix_ub_1169  1
    load_1_15_6  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1026  -25
    arc_1_15_7  connected_order_arc_1027  -13
    arc_1_15_7  in_degree_1171  1
    arc_1_15_7  out_degree_1203  1
    arc_1_15_7  original_T_including_depot_unload_1242  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1026  1
    load_1_15_7  segment_load_conservation_1174  -1
    load_1_15_7  segment_prefix_lb_1175  1
    load_1_15_7  segment_prefix_ub_1176  1
    load_1_15_7  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1028  -25
    arc_1_15_8  connected_order_arc_1029  -13
    arc_1_15_8  in_degree_1178  1
    arc_1_15_8  out_degree_1203  1
    arc_1_15_8  original_T_including_depot_unload_1242  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1028  1
    load_1_15_8  segment_load_conservation_1181  -1
    load_1_15_8  segment_prefix_lb_1182  1
    load_1_15_8  segment_prefix_ub_1183  1
    load_1_15_8  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1030  -25
    arc_1_15_9  connected_order_arc_1031  -13
    arc_1_15_9  in_degree_1185  1
    arc_1_15_9  out_degree_1203  1
    arc_1_15_9  original_T_including_depot_unload_1242  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1030  1
    load_1_15_9  segment_load_conservation_1188  -1
    load_1_15_9  segment_prefix_lb_1189  1
    load_1_15_9  segment_prefix_ub_1190  1
    load_1_15_9  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1032  -25
    arc_1_15_13  connected_order_arc_1033  -13
    arc_1_15_13  in_degree_1192  1
    arc_1_15_13  out_degree_1203  1
    arc_1_15_13  original_T_including_depot_unload_1242  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1032  1
    load_1_15_13  free_load_conservation_1196  -1
    load_1_15_13  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1034  -25
    arc_1_15_14  connected_order_arc_1035  -13
    arc_1_15_14  in_degree_1198  1
    arc_1_15_14  out_degree_1203  1
    arc_1_15_14  original_T_including_depot_unload_1242  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1034  1
    load_1_15_14  free_load_conservation_1202  -1
    load_1_15_14  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1036  -25
    arc_1_15_16  connected_order_arc_1037  -13
    arc_1_15_16  out_degree_1203  1
    arc_1_15_16  in_degree_1210  1
    arc_1_15_16  original_T_including_depot_unload_1242  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1036  1
    load_1_15_16  free_load_conservation_1208  1
    load_1_15_16  free_load_conservation_1214  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1038  -25
    arc_1_15_17  connected_order_arc_1039  -13
    arc_1_15_17  out_degree_1203  1
    arc_1_15_17  in_degree_1216  1
    arc_1_15_17  original_T_including_depot_unload_1242  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1038  1
    load_1_15_17  free_load_conservation_1208  1
    load_1_15_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1040  -25
    arc_1_15_18  connected_order_arc_1041  -13
    arc_1_15_18  out_degree_1203  1
    arc_1_15_18  in_degree_1222  1
    arc_1_15_18  original_T_including_depot_unload_1242  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1040  1
    load_1_15_18  free_load_conservation_1208  1
    load_1_15_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1042  -25
    arc_1_15_19  connected_order_arc_1043  -13
    arc_1_15_19  out_degree_1203  1
    arc_1_15_19  in_degree_1228  1
    arc_1_15_19  original_T_including_depot_unload_1242  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1042  1
    load_1_15_19  free_load_conservation_1208  1
    load_1_15_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1044  -25
    arc_1_15_20  connected_order_arc_1045  -13
    arc_1_15_20  out_degree_1203  1
    arc_1_15_20  in_degree_1234  1
    arc_1_15_20  original_T_including_depot_unload_1242  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1044  1
    load_1_15_20  free_load_conservation_1208  1
    load_1_15_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1046  -25
    arc_1_16_0  depot_return_or_bypass_1162  1
    arc_1_16_0  out_degree_1209  1
    arc_1_16_0  original_T_including_depot_unload_1242  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1046  1
    load_1_16_0  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1047  -25
    arc_1_16_6  connected_order_arc_1048  -13
    arc_1_16_6  in_degree_1164  1
    arc_1_16_6  out_degree_1209  1
    arc_1_16_6  original_T_including_depot_unload_1242  1.2876689365561549e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1047  1
    load_1_16_6  segment_load_conservation_1167  -1
    load_1_16_6  segment_prefix_lb_1168  1
    load_1_16_6  segment_prefix_ub_1169  1
    load_1_16_6  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1049  -25
    arc_1_16_7  connected_order_arc_1050  -13
    arc_1_16_7  in_degree_1171  1
    arc_1_16_7  out_degree_1209  1
    arc_1_16_7  original_T_including_depot_unload_1242  1.3840439316159188e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1049  1
    load_1_16_7  segment_load_conservation_1174  -1
    load_1_16_7  segment_prefix_lb_1175  1
    load_1_16_7  segment_prefix_ub_1176  1
    load_1_16_7  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1051  -25
    arc_1_16_8  connected_order_arc_1052  -13
    arc_1_16_8  in_degree_1178  1
    arc_1_16_8  out_degree_1209  1
    arc_1_16_8  original_T_including_depot_unload_1242  1.3776676659817167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1051  1
    load_1_16_8  segment_load_conservation_1181  -1
    load_1_16_8  segment_prefix_lb_1182  1
    load_1_16_8  segment_prefix_ub_1183  1
    load_1_16_8  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1053  -25
    arc_1_16_9  connected_order_arc_1054  -13
    arc_1_16_9  in_degree_1185  1
    arc_1_16_9  out_degree_1209  1
    arc_1_16_9  original_T_including_depot_unload_1242  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1053  1
    load_1_16_9  segment_load_conservation_1188  -1
    load_1_16_9  segment_prefix_lb_1189  1
    load_1_16_9  segment_prefix_ub_1190  1
    load_1_16_9  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1055  -25
    arc_1_16_13  connected_order_arc_1056  -13
    arc_1_16_13  in_degree_1192  1
    arc_1_16_13  out_degree_1209  1
    arc_1_16_13  original_T_including_depot_unload_1242  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1055  1
    load_1_16_13  free_load_conservation_1196  -1
    load_1_16_13  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1057  -25
    arc_1_16_14  connected_order_arc_1058  -13
    arc_1_16_14  in_degree_1198  1
    arc_1_16_14  out_degree_1209  1
    arc_1_16_14  original_T_including_depot_unload_1242  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1057  1
    load_1_16_14  free_load_conservation_1202  -1
    load_1_16_14  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1059  -25
    arc_1_16_15  connected_order_arc_1060  -13
    arc_1_16_15  in_degree_1204  1
    arc_1_16_15  out_degree_1209  1
    arc_1_16_15  original_T_including_depot_unload_1242  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1059  1
    load_1_16_15  free_load_conservation_1208  -1
    load_1_16_15  free_load_conservation_1214  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1061  -25
    arc_1_16_17  connected_order_arc_1062  -13
    arc_1_16_17  out_degree_1209  1
    arc_1_16_17  in_degree_1216  1
    arc_1_16_17  original_T_including_depot_unload_1242  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1061  1
    load_1_16_17  free_load_conservation_1214  1
    load_1_16_17  free_load_conservation_1220  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1063  -25
    arc_1_16_18  connected_order_arc_1064  -13
    arc_1_16_18  out_degree_1209  1
    arc_1_16_18  in_degree_1222  1
    arc_1_16_18  original_T_including_depot_unload_1242  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1063  1
    load_1_16_18  free_load_conservation_1214  1
    load_1_16_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1065  -25
    arc_1_16_19  connected_order_arc_1066  -13
    arc_1_16_19  out_degree_1209  1
    arc_1_16_19  in_degree_1228  1
    arc_1_16_19  original_T_including_depot_unload_1242  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1065  1
    load_1_16_19  free_load_conservation_1214  1
    load_1_16_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1067  -25
    arc_1_16_20  connected_order_arc_1068  -13
    arc_1_16_20  out_degree_1209  1
    arc_1_16_20  in_degree_1234  1
    arc_1_16_20  original_T_including_depot_unload_1242  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1067  1
    load_1_16_20  free_load_conservation_1214  1
    load_1_16_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1069  -25
    arc_1_17_0  depot_return_or_bypass_1162  1
    arc_1_17_0  out_degree_1215  1
    arc_1_17_0  original_T_including_depot_unload_1242  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1069  1
    load_1_17_0  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1070  -25
    arc_1_17_6  connected_order_arc_1071  -13
    arc_1_17_6  in_degree_1164  1
    arc_1_17_6  out_degree_1215  1
    arc_1_17_6  original_T_including_depot_unload_1242  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1070  1
    load_1_17_6  segment_load_conservation_1167  -1
    load_1_17_6  segment_prefix_lb_1168  1
    load_1_17_6  segment_prefix_ub_1169  1
    load_1_17_6  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1072  -25
    arc_1_17_7  connected_order_arc_1073  -13
    arc_1_17_7  in_degree_1171  1
    arc_1_17_7  out_degree_1215  1
    arc_1_17_7  original_T_including_depot_unload_1242  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1072  1
    load_1_17_7  segment_load_conservation_1174  -1
    load_1_17_7  segment_prefix_lb_1175  1
    load_1_17_7  segment_prefix_ub_1176  1
    load_1_17_7  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1074  -25
    arc_1_17_8  connected_order_arc_1075  -13
    arc_1_17_8  in_degree_1178  1
    arc_1_17_8  out_degree_1215  1
    arc_1_17_8  original_T_including_depot_unload_1242  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1074  1
    load_1_17_8  segment_load_conservation_1181  -1
    load_1_17_8  segment_prefix_lb_1182  1
    load_1_17_8  segment_prefix_ub_1183  1
    load_1_17_8  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1076  -25
    arc_1_17_9  connected_order_arc_1077  -13
    arc_1_17_9  in_degree_1185  1
    arc_1_17_9  out_degree_1215  1
    arc_1_17_9  original_T_including_depot_unload_1242  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1076  1
    load_1_17_9  segment_load_conservation_1188  -1
    load_1_17_9  segment_prefix_lb_1189  1
    load_1_17_9  segment_prefix_ub_1190  1
    load_1_17_9  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1078  -25
    arc_1_17_13  connected_order_arc_1079  -13
    arc_1_17_13  in_degree_1192  1
    arc_1_17_13  out_degree_1215  1
    arc_1_17_13  original_T_including_depot_unload_1242  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1078  1
    load_1_17_13  free_load_conservation_1196  -1
    load_1_17_13  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1080  -25
    arc_1_17_14  connected_order_arc_1081  -13
    arc_1_17_14  in_degree_1198  1
    arc_1_17_14  out_degree_1215  1
    arc_1_17_14  original_T_including_depot_unload_1242  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1080  1
    load_1_17_14  free_load_conservation_1202  -1
    load_1_17_14  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1082  -25
    arc_1_17_15  connected_order_arc_1083  -13
    arc_1_17_15  in_degree_1204  1
    arc_1_17_15  out_degree_1215  1
    arc_1_17_15  original_T_including_depot_unload_1242  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1082  1
    load_1_17_15  free_load_conservation_1208  -1
    load_1_17_15  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1084  -25
    arc_1_17_16  connected_order_arc_1085  -13
    arc_1_17_16  in_degree_1210  1
    arc_1_17_16  out_degree_1215  1
    arc_1_17_16  original_T_including_depot_unload_1242  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1084  1
    load_1_17_16  free_load_conservation_1214  -1
    load_1_17_16  free_load_conservation_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1086  -25
    arc_1_17_18  connected_order_arc_1087  -13
    arc_1_17_18  out_degree_1215  1
    arc_1_17_18  in_degree_1222  1
    arc_1_17_18  original_T_including_depot_unload_1242  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1086  1
    load_1_17_18  free_load_conservation_1220  1
    load_1_17_18  free_load_conservation_1226  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1088  -25
    arc_1_17_19  connected_order_arc_1089  -13
    arc_1_17_19  out_degree_1215  1
    arc_1_17_19  in_degree_1228  1
    arc_1_17_19  original_T_including_depot_unload_1242  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1088  1
    load_1_17_19  free_load_conservation_1220  1
    load_1_17_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1090  -25
    arc_1_17_20  connected_order_arc_1091  -13
    arc_1_17_20  out_degree_1215  1
    arc_1_17_20  in_degree_1234  1
    arc_1_17_20  original_T_including_depot_unload_1242  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1090  1
    load_1_17_20  free_load_conservation_1220  1
    load_1_17_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1092  -25
    arc_1_18_0  depot_return_or_bypass_1162  1
    arc_1_18_0  out_degree_1221  1
    arc_1_18_0  original_T_including_depot_unload_1242  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1092  1
    load_1_18_0  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1093  -25
    arc_1_18_6  connected_order_arc_1094  -13
    arc_1_18_6  in_degree_1164  1
    arc_1_18_6  out_degree_1221  1
    arc_1_18_6  original_T_including_depot_unload_1242  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1093  1
    load_1_18_6  segment_load_conservation_1167  -1
    load_1_18_6  segment_prefix_lb_1168  1
    load_1_18_6  segment_prefix_ub_1169  1
    load_1_18_6  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1095  -25
    arc_1_18_7  connected_order_arc_1096  -13
    arc_1_18_7  in_degree_1171  1
    arc_1_18_7  out_degree_1221  1
    arc_1_18_7  original_T_including_depot_unload_1242  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1095  1
    load_1_18_7  segment_load_conservation_1174  -1
    load_1_18_7  segment_prefix_lb_1175  1
    load_1_18_7  segment_prefix_ub_1176  1
    load_1_18_7  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1097  -25
    arc_1_18_8  connected_order_arc_1098  -13
    arc_1_18_8  in_degree_1178  1
    arc_1_18_8  out_degree_1221  1
    arc_1_18_8  original_T_including_depot_unload_1242  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1097  1
    load_1_18_8  segment_load_conservation_1181  -1
    load_1_18_8  segment_prefix_lb_1182  1
    load_1_18_8  segment_prefix_ub_1183  1
    load_1_18_8  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1099  -25
    arc_1_18_9  connected_order_arc_1100  -13
    arc_1_18_9  in_degree_1185  1
    arc_1_18_9  out_degree_1221  1
    arc_1_18_9  original_T_including_depot_unload_1242  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1099  1
    load_1_18_9  segment_load_conservation_1188  -1
    load_1_18_9  segment_prefix_lb_1189  1
    load_1_18_9  segment_prefix_ub_1190  1
    load_1_18_9  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1101  -25
    arc_1_18_13  connected_order_arc_1102  -13
    arc_1_18_13  in_degree_1192  1
    arc_1_18_13  out_degree_1221  1
    arc_1_18_13  original_T_including_depot_unload_1242  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1101  1
    load_1_18_13  free_load_conservation_1196  -1
    load_1_18_13  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1103  -25
    arc_1_18_14  connected_order_arc_1104  -13
    arc_1_18_14  in_degree_1198  1
    arc_1_18_14  out_degree_1221  1
    arc_1_18_14  original_T_including_depot_unload_1242  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1103  1
    load_1_18_14  free_load_conservation_1202  -1
    load_1_18_14  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1105  -25
    arc_1_18_15  connected_order_arc_1106  -13
    arc_1_18_15  in_degree_1204  1
    arc_1_18_15  out_degree_1221  1
    arc_1_18_15  original_T_including_depot_unload_1242  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1105  1
    load_1_18_15  free_load_conservation_1208  -1
    load_1_18_15  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1107  -25
    arc_1_18_16  connected_order_arc_1108  -13
    arc_1_18_16  in_degree_1210  1
    arc_1_18_16  out_degree_1221  1
    arc_1_18_16  original_T_including_depot_unload_1242  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1107  1
    load_1_18_16  free_load_conservation_1214  -1
    load_1_18_16  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1109  -25
    arc_1_18_17  connected_order_arc_1110  -13
    arc_1_18_17  in_degree_1216  1
    arc_1_18_17  out_degree_1221  1
    arc_1_18_17  original_T_including_depot_unload_1242  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1109  1
    load_1_18_17  free_load_conservation_1220  -1
    load_1_18_17  free_load_conservation_1226  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1111  -25
    arc_1_18_19  connected_order_arc_1112  -13
    arc_1_18_19  out_degree_1221  1
    arc_1_18_19  in_degree_1228  1
    arc_1_18_19  original_T_including_depot_unload_1242  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1111  1
    load_1_18_19  free_load_conservation_1226  1
    load_1_18_19  free_load_conservation_1232  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1113  -25
    arc_1_18_20  connected_order_arc_1114  -13
    arc_1_18_20  out_degree_1221  1
    arc_1_18_20  in_degree_1234  1
    arc_1_18_20  original_T_including_depot_unload_1242  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1113  1
    load_1_18_20  free_load_conservation_1226  1
    load_1_18_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1115  -25
    arc_1_19_0  depot_return_or_bypass_1162  1
    arc_1_19_0  out_degree_1227  1
    arc_1_19_0  original_T_including_depot_unload_1242  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1115  1
    load_1_19_0  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1116  -25
    arc_1_19_6  connected_order_arc_1117  -13
    arc_1_19_6  in_degree_1164  1
    arc_1_19_6  out_degree_1227  1
    arc_1_19_6  original_T_including_depot_unload_1242  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1116  1
    load_1_19_6  segment_load_conservation_1167  -1
    load_1_19_6  segment_prefix_lb_1168  1
    load_1_19_6  segment_prefix_ub_1169  1
    load_1_19_6  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1118  -25
    arc_1_19_7  connected_order_arc_1119  -13
    arc_1_19_7  in_degree_1171  1
    arc_1_19_7  out_degree_1227  1
    arc_1_19_7  original_T_including_depot_unload_1242  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1118  1
    load_1_19_7  segment_load_conservation_1174  -1
    load_1_19_7  segment_prefix_lb_1175  1
    load_1_19_7  segment_prefix_ub_1176  1
    load_1_19_7  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1120  -25
    arc_1_19_8  connected_order_arc_1121  -13
    arc_1_19_8  in_degree_1178  1
    arc_1_19_8  out_degree_1227  1
    arc_1_19_8  original_T_including_depot_unload_1242  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1120  1
    load_1_19_8  segment_load_conservation_1181  -1
    load_1_19_8  segment_prefix_lb_1182  1
    load_1_19_8  segment_prefix_ub_1183  1
    load_1_19_8  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1122  -25
    arc_1_19_9  connected_order_arc_1123  -13
    arc_1_19_9  in_degree_1185  1
    arc_1_19_9  out_degree_1227  1
    arc_1_19_9  original_T_including_depot_unload_1242  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1122  1
    load_1_19_9  segment_load_conservation_1188  -1
    load_1_19_9  segment_prefix_lb_1189  1
    load_1_19_9  segment_prefix_ub_1190  1
    load_1_19_9  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1124  -25
    arc_1_19_13  connected_order_arc_1125  -13
    arc_1_19_13  in_degree_1192  1
    arc_1_19_13  out_degree_1227  1
    arc_1_19_13  original_T_including_depot_unload_1242  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1124  1
    load_1_19_13  free_load_conservation_1196  -1
    load_1_19_13  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1126  -25
    arc_1_19_14  connected_order_arc_1127  -13
    arc_1_19_14  in_degree_1198  1
    arc_1_19_14  out_degree_1227  1
    arc_1_19_14  original_T_including_depot_unload_1242  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1126  1
    load_1_19_14  free_load_conservation_1202  -1
    load_1_19_14  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1128  -25
    arc_1_19_15  connected_order_arc_1129  -13
    arc_1_19_15  in_degree_1204  1
    arc_1_19_15  out_degree_1227  1
    arc_1_19_15  original_T_including_depot_unload_1242  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1128  1
    load_1_19_15  free_load_conservation_1208  -1
    load_1_19_15  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1130  -25
    arc_1_19_16  connected_order_arc_1131  -13
    arc_1_19_16  in_degree_1210  1
    arc_1_19_16  out_degree_1227  1
    arc_1_19_16  original_T_including_depot_unload_1242  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1130  1
    load_1_19_16  free_load_conservation_1214  -1
    load_1_19_16  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1132  -25
    arc_1_19_17  connected_order_arc_1133  -13
    arc_1_19_17  in_degree_1216  1
    arc_1_19_17  out_degree_1227  1
    arc_1_19_17  original_T_including_depot_unload_1242  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1132  1
    load_1_19_17  free_load_conservation_1220  -1
    load_1_19_17  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1134  -25
    arc_1_19_18  connected_order_arc_1135  -13
    arc_1_19_18  in_degree_1222  1
    arc_1_19_18  out_degree_1227  1
    arc_1_19_18  original_T_including_depot_unload_1242  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1134  1
    load_1_19_18  free_load_conservation_1226  -1
    load_1_19_18  free_load_conservation_1232  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1136  -25
    arc_1_19_20  connected_order_arc_1137  -13
    arc_1_19_20  out_degree_1227  1
    arc_1_19_20  in_degree_1234  1
    arc_1_19_20  original_T_including_depot_unload_1242  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1136  1
    load_1_19_20  free_load_conservation_1232  1
    load_1_19_20  free_load_conservation_1238  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1138  -25
    arc_1_20_0  depot_return_or_bypass_1162  1
    arc_1_20_0  out_degree_1233  1
    arc_1_20_0  original_T_including_depot_unload_1242  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1138  1
    load_1_20_0  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1139  -25
    arc_1_20_6  connected_order_arc_1140  -13
    arc_1_20_6  in_degree_1164  1
    arc_1_20_6  out_degree_1233  1
    arc_1_20_6  original_T_including_depot_unload_1242  1.5546511874277910e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1139  1
    load_1_20_6  segment_load_conservation_1167  -1
    load_1_20_6  segment_prefix_lb_1168  1
    load_1_20_6  segment_prefix_ub_1169  1
    load_1_20_6  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1141  -25
    arc_1_20_7  connected_order_arc_1142  -13
    arc_1_20_7  in_degree_1171  1
    arc_1_20_7  out_degree_1233  1
    arc_1_20_7  original_T_including_depot_unload_1242  1.5892857916507662e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1141  1
    load_1_20_7  segment_load_conservation_1174  -1
    load_1_20_7  segment_prefix_lb_1175  1
    load_1_20_7  segment_prefix_ub_1176  1
    load_1_20_7  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1143  -25
    arc_1_20_8  connected_order_arc_1144  -13
    arc_1_20_8  in_degree_1178  1
    arc_1_20_8  out_degree_1233  1
    arc_1_20_8  original_T_including_depot_unload_1242  1.6631507094436240e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1143  1
    load_1_20_8  segment_load_conservation_1181  -1
    load_1_20_8  segment_prefix_lb_1182  1
    load_1_20_8  segment_prefix_ub_1183  1
    load_1_20_8  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1145  -25
    arc_1_20_9  connected_order_arc_1146  -13
    arc_1_20_9  in_degree_1185  1
    arc_1_20_9  out_degree_1233  1
    arc_1_20_9  original_T_including_depot_unload_1242  9.3962613467893414e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1145  1
    load_1_20_9  segment_load_conservation_1188  -1
    load_1_20_9  segment_prefix_lb_1189  1
    load_1_20_9  segment_prefix_ub_1190  1
    load_1_20_9  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1147  -25
    arc_1_20_13  connected_order_arc_1148  -13
    arc_1_20_13  in_degree_1192  1
    arc_1_20_13  out_degree_1233  1
    arc_1_20_13  original_T_including_depot_unload_1242  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1147  1
    load_1_20_13  free_load_conservation_1196  -1
    load_1_20_13  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1149  -25
    arc_1_20_14  connected_order_arc_1150  -13
    arc_1_20_14  in_degree_1198  1
    arc_1_20_14  out_degree_1233  1
    arc_1_20_14  original_T_including_depot_unload_1242  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1149  1
    load_1_20_14  free_load_conservation_1202  -1
    load_1_20_14  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1151  -25
    arc_1_20_15  connected_order_arc_1152  -13
    arc_1_20_15  in_degree_1204  1
    arc_1_20_15  out_degree_1233  1
    arc_1_20_15  original_T_including_depot_unload_1242  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1151  1
    load_1_20_15  free_load_conservation_1208  -1
    load_1_20_15  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1153  -25
    arc_1_20_16  connected_order_arc_1154  -13
    arc_1_20_16  in_degree_1210  1
    arc_1_20_16  out_degree_1233  1
    arc_1_20_16  original_T_including_depot_unload_1242  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1153  1
    load_1_20_16  free_load_conservation_1214  -1
    load_1_20_16  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1155  -25
    arc_1_20_17  connected_order_arc_1156  -13
    arc_1_20_17  in_degree_1216  1
    arc_1_20_17  out_degree_1233  1
    arc_1_20_17  original_T_including_depot_unload_1242  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1155  1
    load_1_20_17  free_load_conservation_1220  -1
    load_1_20_17  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1157  -25
    arc_1_20_18  connected_order_arc_1158  -13
    arc_1_20_18  in_degree_1222  1
    arc_1_20_18  out_degree_1233  1
    arc_1_20_18  original_T_including_depot_unload_1242  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1157  1
    load_1_20_18  free_load_conservation_1226  -1
    load_1_20_18  free_load_conservation_1238  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1159  -25
    arc_1_20_19  connected_order_arc_1160  -13
    arc_1_20_19  in_degree_1228  1
    arc_1_20_19  out_degree_1233  1
    arc_1_20_19  original_T_including_depot_unload_1242  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1159  1
    load_1_20_19  free_load_conservation_1232  -1
    load_1_20_19  free_load_conservation_1238  1
    visit_2_10  out_degree_1488  -1
    visit_2_10  in_degree_1489  -1
    visit_2_10  order_active_lb_1490  -1
    visit_2_10  order_active_ub_1491  -11
    order_2_10  connected_order_arc_1257  -1
    order_2_10  connected_order_arc_1259  -1
    order_2_10  connected_order_arc_1261  -1
    order_2_10  connected_order_arc_1263  -1
    order_2_10  connected_order_arc_1265  -1
    order_2_10  connected_order_arc_1267  -1
    order_2_10  connected_order_arc_1269  -1
    order_2_10  connected_order_arc_1271  -1
    order_2_10  connected_order_arc_1273  -1
    order_2_10  connected_order_arc_1275  -1
    order_2_10  connected_order_arc_1278  1
    order_2_10  connected_order_arc_1299  1
    order_2_10  connected_order_arc_1320  1
    order_2_10  connected_order_arc_1341  1
    order_2_10  connected_order_arc_1362  1
    order_2_10  connected_order_arc_1383  1
    order_2_10  connected_order_arc_1404  1
    order_2_10  connected_order_arc_1425  1
    order_2_10  connected_order_arc_1446  1
    order_2_10  connected_order_arc_1467  1
    order_2_10  order_active_lb_1490  1
    order_2_10  order_active_ub_1491  1
    order_2_10  fixed_segment_relative_order_1557  -1
    visit_2_11  out_degree_1495  -1
    visit_2_11  in_degree_1496  -1
    visit_2_11  order_active_lb_1497  -1
    visit_2_11  order_active_ub_1498  -11
    order_2_11  connected_order_arc_1257  1
    order_2_11  connected_order_arc_1278  -1
    order_2_11  connected_order_arc_1280  -1
    order_2_11  connected_order_arc_1282  -1
    order_2_11  connected_order_arc_1284  -1
    order_2_11  connected_order_arc_1286  -1
    order_2_11  connected_order_arc_1288  -1
    order_2_11  connected_order_arc_1290  -1
    order_2_11  connected_order_arc_1292  -1
    order_2_11  connected_order_arc_1294  -1
    order_2_11  connected_order_arc_1296  -1
    order_2_11  connected_order_arc_1301  1
    order_2_11  connected_order_arc_1322  1
    order_2_11  connected_order_arc_1343  1
    order_2_11  connected_order_arc_1364  1
    order_2_11  connected_order_arc_1385  1
    order_2_11  connected_order_arc_1406  1
    order_2_11  connected_order_arc_1427  1
    order_2_11  connected_order_arc_1448  1
    order_2_11  connected_order_arc_1469  1
    order_2_11  order_active_lb_1497  1
    order_2_11  order_active_ub_1498  1
    order_2_11  fixed_segment_relative_order_1557  1
    order_2_11  fixed_segment_relative_order_1558  -1
    visit_2_12  out_degree_1502  -1
    visit_2_12  in_degree_1503  -1
    visit_2_12  order_active_lb_1504  -1
    visit_2_12  order_active_ub_1505  -11
    order_2_12  connected_order_arc_1259  1
    order_2_12  connected_order_arc_1280  1
    order_2_12  connected_order_arc_1299  -1
    order_2_12  connected_order_arc_1301  -1
    order_2_12  connected_order_arc_1303  -1
    order_2_12  connected_order_arc_1305  -1
    order_2_12  connected_order_arc_1307  -1
    order_2_12  connected_order_arc_1309  -1
    order_2_12  connected_order_arc_1311  -1
    order_2_12  connected_order_arc_1313  -1
    order_2_12  connected_order_arc_1315  -1
    order_2_12  connected_order_arc_1317  -1
    order_2_12  connected_order_arc_1324  1
    order_2_12  connected_order_arc_1345  1
    order_2_12  connected_order_arc_1366  1
    order_2_12  connected_order_arc_1387  1
    order_2_12  connected_order_arc_1408  1
    order_2_12  connected_order_arc_1429  1
    order_2_12  connected_order_arc_1450  1
    order_2_12  connected_order_arc_1471  1
    order_2_12  order_active_lb_1504  1
    order_2_12  order_active_ub_1505  1
    order_2_12  fixed_segment_relative_order_1558  1
    visit_2_13  out_degree_1509  -1
    visit_2_13  in_degree_1510  -1
    visit_2_13  order_active_lb_1511  -1
    visit_2_13  order_active_ub_1512  -11
    visit_2_13  service_visit_def_1513  -1
    order_2_13  connected_order_arc_1261  1
    order_2_13  connected_order_arc_1282  1
    order_2_13  connected_order_arc_1303  1
    order_2_13  connected_order_arc_1320  -1
    order_2_13  connected_order_arc_1322  -1
    order_2_13  connected_order_arc_1324  -1
    order_2_13  connected_order_arc_1326  -1
    order_2_13  connected_order_arc_1328  -1
    order_2_13  connected_order_arc_1330  -1
    order_2_13  connected_order_arc_1332  -1
    order_2_13  connected_order_arc_1334  -1
    order_2_13  connected_order_arc_1336  -1
    order_2_13  connected_order_arc_1338  -1
    order_2_13  connected_order_arc_1347  1
    order_2_13  connected_order_arc_1368  1
    order_2_13  connected_order_arc_1389  1
    order_2_13  connected_order_arc_1410  1
    order_2_13  connected_order_arc_1431  1
    order_2_13  connected_order_arc_1452  1
    order_2_13  connected_order_arc_1473  1
    order_2_13  order_active_lb_1511  1
    order_2_13  order_active_ub_1512  1
    visit_2_14  out_degree_1515  -1
    visit_2_14  in_degree_1516  -1
    visit_2_14  order_active_lb_1517  -1
    visit_2_14  order_active_ub_1518  -11
    visit_2_14  service_visit_def_1519  -1
    order_2_14  connected_order_arc_1263  1
    order_2_14  connected_order_arc_1284  1
    order_2_14  connected_order_arc_1305  1
    order_2_14  connected_order_arc_1326  1
    order_2_14  connected_order_arc_1341  -1
    order_2_14  connected_order_arc_1343  -1
    order_2_14  connected_order_arc_1345  -1
    order_2_14  connected_order_arc_1347  -1
    order_2_14  connected_order_arc_1349  -1
    order_2_14  connected_order_arc_1351  -1
    order_2_14  connected_order_arc_1353  -1
    order_2_14  connected_order_arc_1355  -1
    order_2_14  connected_order_arc_1357  -1
    order_2_14  connected_order_arc_1359  -1
    order_2_14  connected_order_arc_1370  1
    order_2_14  connected_order_arc_1391  1
    order_2_14  connected_order_arc_1412  1
    order_2_14  connected_order_arc_1433  1
    order_2_14  connected_order_arc_1454  1
    order_2_14  connected_order_arc_1475  1
    order_2_14  order_active_lb_1517  1
    order_2_14  order_active_ub_1518  1
    visit_2_15  out_degree_1521  -1
    visit_2_15  in_degree_1522  -1
    visit_2_15  order_active_lb_1523  -1
    visit_2_15  order_active_ub_1524  -11
    visit_2_15  service_visit_def_1525  -1
    order_2_15  connected_order_arc_1265  1
    order_2_15  connected_order_arc_1286  1
    order_2_15  connected_order_arc_1307  1
    order_2_15  connected_order_arc_1328  1
    order_2_15  connected_order_arc_1349  1
    order_2_15  connected_order_arc_1362  -1
    order_2_15  connected_order_arc_1364  -1
    order_2_15  connected_order_arc_1366  -1
    order_2_15  connected_order_arc_1368  -1
    order_2_15  connected_order_arc_1370  -1
    order_2_15  connected_order_arc_1372  -1
    order_2_15  connected_order_arc_1374  -1
    order_2_15  connected_order_arc_1376  -1
    order_2_15  connected_order_arc_1378  -1
    order_2_15  connected_order_arc_1380  -1
    order_2_15  connected_order_arc_1393  1
    order_2_15  connected_order_arc_1414  1
    order_2_15  connected_order_arc_1435  1
    order_2_15  connected_order_arc_1456  1
    order_2_15  connected_order_arc_1477  1
    order_2_15  order_active_lb_1523  1
    order_2_15  order_active_ub_1524  1
    visit_2_16  out_degree_1527  -1
    visit_2_16  in_degree_1528  -1
    visit_2_16  order_active_lb_1529  -1
    visit_2_16  order_active_ub_1530  -11
    visit_2_16  service_visit_def_1531  -1
    order_2_16  connected_order_arc_1267  1
    order_2_16  connected_order_arc_1288  1
    order_2_16  connected_order_arc_1309  1
    order_2_16  connected_order_arc_1330  1
    order_2_16  connected_order_arc_1351  1
    order_2_16  connected_order_arc_1372  1
    order_2_16  connected_order_arc_1383  -1
    order_2_16  connected_order_arc_1385  -1
    order_2_16  connected_order_arc_1387  -1
    order_2_16  connected_order_arc_1389  -1
    order_2_16  connected_order_arc_1391  -1
    order_2_16  connected_order_arc_1393  -1
    order_2_16  connected_order_arc_1395  -1
    order_2_16  connected_order_arc_1397  -1
    order_2_16  connected_order_arc_1399  -1
    order_2_16  connected_order_arc_1401  -1
    order_2_16  connected_order_arc_1416  1
    order_2_16  connected_order_arc_1437  1
    order_2_16  connected_order_arc_1458  1
    order_2_16  connected_order_arc_1479  1
    order_2_16  order_active_lb_1529  1
    order_2_16  order_active_ub_1530  1
    visit_2_17  out_degree_1533  -1
    visit_2_17  in_degree_1534  -1
    visit_2_17  order_active_lb_1535  -1
    visit_2_17  order_active_ub_1536  -11
    visit_2_17  service_visit_def_1537  -1
    order_2_17  connected_order_arc_1269  1
    order_2_17  connected_order_arc_1290  1
    order_2_17  connected_order_arc_1311  1
    order_2_17  connected_order_arc_1332  1
    order_2_17  connected_order_arc_1353  1
    order_2_17  connected_order_arc_1374  1
    order_2_17  connected_order_arc_1395  1
    order_2_17  connected_order_arc_1404  -1
    order_2_17  connected_order_arc_1406  -1
    order_2_17  connected_order_arc_1408  -1
    order_2_17  connected_order_arc_1410  -1
    order_2_17  connected_order_arc_1412  -1
    order_2_17  connected_order_arc_1414  -1
    order_2_17  connected_order_arc_1416  -1
    order_2_17  connected_order_arc_1418  -1
    order_2_17  connected_order_arc_1420  -1
    order_2_17  connected_order_arc_1422  -1
    order_2_17  connected_order_arc_1439  1
    order_2_17  connected_order_arc_1460  1
    order_2_17  connected_order_arc_1481  1
    order_2_17  order_active_lb_1535  1
    order_2_17  order_active_ub_1536  1
    visit_2_18  out_degree_1539  -1
    visit_2_18  in_degree_1540  -1
    visit_2_18  order_active_lb_1541  -1
    visit_2_18  order_active_ub_1542  -11
    visit_2_18  service_visit_def_1543  -1
    order_2_18  connected_order_arc_1271  1
    order_2_18  connected_order_arc_1292  1
    order_2_18  connected_order_arc_1313  1
    order_2_18  connected_order_arc_1334  1
    order_2_18  connected_order_arc_1355  1
    order_2_18  connected_order_arc_1376  1
    order_2_18  connected_order_arc_1397  1
    order_2_18  connected_order_arc_1418  1
    order_2_18  connected_order_arc_1425  -1
    order_2_18  connected_order_arc_1427  -1
    order_2_18  connected_order_arc_1429  -1
    order_2_18  connected_order_arc_1431  -1
    order_2_18  connected_order_arc_1433  -1
    order_2_18  connected_order_arc_1435  -1
    order_2_18  connected_order_arc_1437  -1
    order_2_18  connected_order_arc_1439  -1
    order_2_18  connected_order_arc_1441  -1
    order_2_18  connected_order_arc_1443  -1
    order_2_18  connected_order_arc_1462  1
    order_2_18  connected_order_arc_1483  1
    order_2_18  order_active_lb_1541  1
    order_2_18  order_active_ub_1542  1
    visit_2_19  out_degree_1545  -1
    visit_2_19  in_degree_1546  -1
    visit_2_19  order_active_lb_1547  -1
    visit_2_19  order_active_ub_1548  -11
    visit_2_19  service_visit_def_1549  -1
    order_2_19  connected_order_arc_1273  1
    order_2_19  connected_order_arc_1294  1
    order_2_19  connected_order_arc_1315  1
    order_2_19  connected_order_arc_1336  1
    order_2_19  connected_order_arc_1357  1
    order_2_19  connected_order_arc_1378  1
    order_2_19  connected_order_arc_1399  1
    order_2_19  connected_order_arc_1420  1
    order_2_19  connected_order_arc_1441  1
    order_2_19  connected_order_arc_1446  -1
    order_2_19  connected_order_arc_1448  -1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1452  -1
    order_2_19  connected_order_arc_1454  -1
    order_2_19  connected_order_arc_1456  -1
    order_2_19  connected_order_arc_1458  -1
    order_2_19  connected_order_arc_1460  -1
    order_2_19  connected_order_arc_1462  -1
    order_2_19  connected_order_arc_1464  -1
    order_2_19  connected_order_arc_1485  1
    order_2_19  order_active_lb_1547  1
    order_2_19  order_active_ub_1548  1
    visit_2_20  out_degree_1551  -1
    visit_2_20  in_degree_1552  -1
    visit_2_20  order_active_lb_1553  -1
    visit_2_20  order_active_ub_1554  -11
    visit_2_20  service_visit_def_1555  -1
    order_2_20  connected_order_arc_1275  1
    order_2_20  connected_order_arc_1296  1
    order_2_20  connected_order_arc_1317  1
    order_2_20  connected_order_arc_1338  1
    order_2_20  connected_order_arc_1359  1
    order_2_20  connected_order_arc_1380  1
    order_2_20  connected_order_arc_1401  1
    order_2_20  connected_order_arc_1422  1
    order_2_20  connected_order_arc_1443  1
    order_2_20  connected_order_arc_1464  1
    order_2_20  connected_order_arc_1467  -1
    order_2_20  connected_order_arc_1469  -1
    order_2_20  connected_order_arc_1471  -1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  connected_order_arc_1475  -1
    order_2_20  connected_order_arc_1477  -1
    order_2_20  connected_order_arc_1479  -1
    order_2_20  connected_order_arc_1481  -1
    order_2_20  connected_order_arc_1483  -1
    order_2_20  connected_order_arc_1485  -1
    order_2_20  order_active_lb_1553  1
    order_2_20  order_active_ub_1554  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1243  -30
    arc_2_0_0  depot_departure_or_bypass_1486  1
    arc_2_0_0  depot_return_or_bypass_1487  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1243  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1244  -30
    arc_2_0_10  depot_departure_or_bypass_1486  1
    arc_2_0_10  in_degree_1489  1
    arc_2_0_10  original_T_including_depot_unload_1559  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1244  1
    load_2_0_10  segment_load_conservation_1492  -1
    load_2_0_10  segment_prefix_lb_1493  1
    load_2_0_10  segment_prefix_ub_1494  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1245  -30
    arc_2_0_11  depot_departure_or_bypass_1486  1
    arc_2_0_11  in_degree_1496  1
    arc_2_0_11  original_T_including_depot_unload_1559  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1245  1
    load_2_0_11  segment_load_conservation_1499  -1
    load_2_0_11  segment_prefix_lb_1500  1
    load_2_0_11  segment_prefix_ub_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1246  -30
    arc_2_0_12  depot_departure_or_bypass_1486  1
    arc_2_0_12  in_degree_1503  1
    arc_2_0_12  original_T_including_depot_unload_1559  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1246  1
    load_2_0_12  segment_load_conservation_1506  -1
    load_2_0_12  segment_prefix_lb_1507  1
    load_2_0_12  segment_prefix_ub_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1247  -30
    arc_2_0_13  depot_departure_or_bypass_1486  1
    arc_2_0_13  in_degree_1510  1
    arc_2_0_13  original_T_including_depot_unload_1559  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1247  1
    load_2_0_13  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1248  -30
    arc_2_0_14  depot_departure_or_bypass_1486  1
    arc_2_0_14  in_degree_1516  1
    arc_2_0_14  original_T_including_depot_unload_1559  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1248  1
    load_2_0_14  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1249  -30
    arc_2_0_15  depot_departure_or_bypass_1486  1
    arc_2_0_15  in_degree_1522  1
    arc_2_0_15  original_T_including_depot_unload_1559  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1249  1
    load_2_0_15  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1250  -30
    arc_2_0_16  depot_departure_or_bypass_1486  1
    arc_2_0_16  in_degree_1528  1
    arc_2_0_16  original_T_including_depot_unload_1559  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1250  1
    load_2_0_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1251  -30
    arc_2_0_17  depot_departure_or_bypass_1486  1
    arc_2_0_17  in_degree_1534  1
    arc_2_0_17  original_T_including_depot_unload_1559  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1251  1
    load_2_0_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1252  -30
    arc_2_0_18  depot_departure_or_bypass_1486  1
    arc_2_0_18  in_degree_1540  1
    arc_2_0_18  original_T_including_depot_unload_1559  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1252  1
    load_2_0_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1253  -30
    arc_2_0_19  depot_departure_or_bypass_1486  1
    arc_2_0_19  in_degree_1546  1
    arc_2_0_19  original_T_including_depot_unload_1559  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1253  1
    load_2_0_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1254  -30
    arc_2_0_20  depot_departure_or_bypass_1486  1
    arc_2_0_20  in_degree_1552  1
    arc_2_0_20  original_T_including_depot_unload_1559  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1254  1
    load_2_0_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1255  -30
    arc_2_10_0  depot_return_or_bypass_1487  1
    arc_2_10_0  out_degree_1488  1
    arc_2_10_0  original_T_including_depot_unload_1559  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1255  1
    load_2_10_0  segment_load_conservation_1492  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1256  -30
    arc_2_10_11  connected_order_arc_1257  -12
    arc_2_10_11  out_degree_1488  1
    arc_2_10_11  in_degree_1496  1
    arc_2_10_11  original_T_including_depot_unload_1559  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1256  1
    load_2_10_11  segment_load_conservation_1492  1
    load_2_10_11  segment_load_conservation_1499  -1
    load_2_10_11  segment_prefix_lb_1500  1
    load_2_10_11  segment_prefix_ub_1501  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1258  -30
    arc_2_10_12  connected_order_arc_1259  -12
    arc_2_10_12  out_degree_1488  1
    arc_2_10_12  in_degree_1503  1
    arc_2_10_12  original_T_including_depot_unload_1559  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1258  1
    load_2_10_12  segment_load_conservation_1492  1
    load_2_10_12  segment_load_conservation_1506  -1
    load_2_10_12  segment_prefix_lb_1507  1
    load_2_10_12  segment_prefix_ub_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1260  -30
    arc_2_10_13  connected_order_arc_1261  -12
    arc_2_10_13  out_degree_1488  1
    arc_2_10_13  in_degree_1510  1
    arc_2_10_13  original_T_including_depot_unload_1559  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1260  1
    load_2_10_13  segment_load_conservation_1492  1
    load_2_10_13  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1262  -30
    arc_2_10_14  connected_order_arc_1263  -12
    arc_2_10_14  out_degree_1488  1
    arc_2_10_14  in_degree_1516  1
    arc_2_10_14  original_T_including_depot_unload_1559  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1262  1
    load_2_10_14  segment_load_conservation_1492  1
    load_2_10_14  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1264  -30
    arc_2_10_15  connected_order_arc_1265  -12
    arc_2_10_15  out_degree_1488  1
    arc_2_10_15  in_degree_1522  1
    arc_2_10_15  original_T_including_depot_unload_1559  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1264  1
    load_2_10_15  segment_load_conservation_1492  1
    load_2_10_15  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1266  -30
    arc_2_10_16  connected_order_arc_1267  -12
    arc_2_10_16  out_degree_1488  1
    arc_2_10_16  in_degree_1528  1
    arc_2_10_16  original_T_including_depot_unload_1559  4.6789193623835109e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1266  1
    load_2_10_16  segment_load_conservation_1492  1
    load_2_10_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1268  -30
    arc_2_10_17  connected_order_arc_1269  -12
    arc_2_10_17  out_degree_1488  1
    arc_2_10_17  in_degree_1534  1
    arc_2_10_17  original_T_including_depot_unload_1559  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1268  1
    load_2_10_17  segment_load_conservation_1492  1
    load_2_10_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1270  -30
    arc_2_10_18  connected_order_arc_1271  -12
    arc_2_10_18  out_degree_1488  1
    arc_2_10_18  in_degree_1540  1
    arc_2_10_18  original_T_including_depot_unload_1559  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1270  1
    load_2_10_18  segment_load_conservation_1492  1
    load_2_10_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1272  -30
    arc_2_10_19  connected_order_arc_1273  -12
    arc_2_10_19  out_degree_1488  1
    arc_2_10_19  in_degree_1546  1
    arc_2_10_19  original_T_including_depot_unload_1559  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1272  1
    load_2_10_19  segment_load_conservation_1492  1
    load_2_10_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1274  -30
    arc_2_10_20  connected_order_arc_1275  -12
    arc_2_10_20  out_degree_1488  1
    arc_2_10_20  in_degree_1552  1
    arc_2_10_20  original_T_including_depot_unload_1559  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1274  1
    load_2_10_20  segment_load_conservation_1492  1
    load_2_10_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1276  -30
    arc_2_11_0  depot_return_or_bypass_1487  1
    arc_2_11_0  out_degree_1495  1
    arc_2_11_0  original_T_including_depot_unload_1559  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1276  1
    load_2_11_0  segment_load_conservation_1499  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1277  -30
    arc_2_11_10  connected_order_arc_1278  -12
    arc_2_11_10  in_degree_1489  1
    arc_2_11_10  out_degree_1495  1
    arc_2_11_10  original_T_including_depot_unload_1559  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1277  1
    load_2_11_10  segment_load_conservation_1492  -1
    load_2_11_10  segment_prefix_lb_1493  1
    load_2_11_10  segment_prefix_ub_1494  1
    load_2_11_10  segment_load_conservation_1499  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1279  -30
    arc_2_11_12  connected_order_arc_1280  -12
    arc_2_11_12  out_degree_1495  1
    arc_2_11_12  in_degree_1503  1
    arc_2_11_12  original_T_including_depot_unload_1559  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1279  1
    load_2_11_12  segment_load_conservation_1499  1
    load_2_11_12  segment_load_conservation_1506  -1
    load_2_11_12  segment_prefix_lb_1507  1
    load_2_11_12  segment_prefix_ub_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1281  -30
    arc_2_11_13  connected_order_arc_1282  -12
    arc_2_11_13  out_degree_1495  1
    arc_2_11_13  in_degree_1510  1
    arc_2_11_13  original_T_including_depot_unload_1559  5.8292761965990132e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1281  1
    load_2_11_13  segment_load_conservation_1499  1
    load_2_11_13  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1283  -30
    arc_2_11_14  connected_order_arc_1284  -12
    arc_2_11_14  out_degree_1495  1
    arc_2_11_14  in_degree_1516  1
    arc_2_11_14  original_T_including_depot_unload_1559  4.6772747357218117e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1283  1
    load_2_11_14  segment_load_conservation_1499  1
    load_2_11_14  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1285  -30
    arc_2_11_15  connected_order_arc_1286  -12
    arc_2_11_15  out_degree_1495  1
    arc_2_11_15  in_degree_1522  1
    arc_2_11_15  original_T_including_depot_unload_1559  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1285  1
    load_2_11_15  segment_load_conservation_1499  1
    load_2_11_15  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1287  -30
    arc_2_11_16  connected_order_arc_1288  -12
    arc_2_11_16  out_degree_1495  1
    arc_2_11_16  in_degree_1528  1
    arc_2_11_16  original_T_including_depot_unload_1559  6.7711923781893620e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1287  1
    load_2_11_16  segment_load_conservation_1499  1
    load_2_11_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1289  -30
    arc_2_11_17  connected_order_arc_1290  -12
    arc_2_11_17  out_degree_1495  1
    arc_2_11_17  in_degree_1534  1
    arc_2_11_17  original_T_including_depot_unload_1559  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1289  1
    load_2_11_17  segment_load_conservation_1499  1
    load_2_11_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1291  -30
    arc_2_11_18  connected_order_arc_1292  -12
    arc_2_11_18  out_degree_1495  1
    arc_2_11_18  in_degree_1540  1
    arc_2_11_18  original_T_including_depot_unload_1559  8.4968861461374138e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1291  1
    load_2_11_18  segment_load_conservation_1499  1
    load_2_11_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1293  -30
    arc_2_11_19  connected_order_arc_1294  -12
    arc_2_11_19  out_degree_1495  1
    arc_2_11_19  in_degree_1546  1
    arc_2_11_19  original_T_including_depot_unload_1559  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1293  1
    load_2_11_19  segment_load_conservation_1499  1
    load_2_11_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1295  -30
    arc_2_11_20  connected_order_arc_1296  -12
    arc_2_11_20  out_degree_1495  1
    arc_2_11_20  in_degree_1552  1
    arc_2_11_20  original_T_including_depot_unload_1559  3.3469758905462760e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1295  1
    load_2_11_20  segment_load_conservation_1499  1
    load_2_11_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1297  -30
    arc_2_12_0  depot_return_or_bypass_1487  1
    arc_2_12_0  out_degree_1502  1
    arc_2_12_0  original_T_including_depot_unload_1559  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1297  1
    load_2_12_0  segment_load_conservation_1506  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1298  -30
    arc_2_12_10  connected_order_arc_1299  -12
    arc_2_12_10  in_degree_1489  1
    arc_2_12_10  out_degree_1502  1
    arc_2_12_10  original_T_including_depot_unload_1559  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1298  1
    load_2_12_10  segment_load_conservation_1492  -1
    load_2_12_10  segment_prefix_lb_1493  1
    load_2_12_10  segment_prefix_ub_1494  1
    load_2_12_10  segment_load_conservation_1506  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1300  -30
    arc_2_12_11  connected_order_arc_1301  -12
    arc_2_12_11  in_degree_1496  1
    arc_2_12_11  out_degree_1502  1
    arc_2_12_11  original_T_including_depot_unload_1559  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1300  1
    load_2_12_11  segment_load_conservation_1499  -1
    load_2_12_11  segment_prefix_lb_1500  1
    load_2_12_11  segment_prefix_ub_1501  1
    load_2_12_11  segment_load_conservation_1506  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1302  -30
    arc_2_12_13  connected_order_arc_1303  -12
    arc_2_12_13  out_degree_1502  1
    arc_2_12_13  in_degree_1510  1
    arc_2_12_13  original_T_including_depot_unload_1559  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1302  1
    load_2_12_13  segment_load_conservation_1506  1
    load_2_12_13  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1304  -30
    arc_2_12_14  connected_order_arc_1305  -12
    arc_2_12_14  out_degree_1502  1
    arc_2_12_14  in_degree_1516  1
    arc_2_12_14  original_T_including_depot_unload_1559  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1304  1
    load_2_12_14  segment_load_conservation_1506  1
    load_2_12_14  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1306  -30
    arc_2_12_15  connected_order_arc_1307  -12
    arc_2_12_15  out_degree_1502  1
    arc_2_12_15  in_degree_1522  1
    arc_2_12_15  original_T_including_depot_unload_1559  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1306  1
    load_2_12_15  segment_load_conservation_1506  1
    load_2_12_15  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1308  -30
    arc_2_12_16  connected_order_arc_1309  -12
    arc_2_12_16  out_degree_1502  1
    arc_2_12_16  in_degree_1528  1
    arc_2_12_16  original_T_including_depot_unload_1559  6.4572843340219208e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1308  1
    load_2_12_16  segment_load_conservation_1506  1
    load_2_12_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1310  -30
    arc_2_12_17  connected_order_arc_1311  -12
    arc_2_12_17  out_degree_1502  1
    arc_2_12_17  in_degree_1534  1
    arc_2_12_17  original_T_including_depot_unload_1559  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1310  1
    load_2_12_17  segment_load_conservation_1506  1
    load_2_12_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1312  -30
    arc_2_12_18  connected_order_arc_1313  -12
    arc_2_12_18  out_degree_1502  1
    arc_2_12_18  in_degree_1540  1
    arc_2_12_18  original_T_including_depot_unload_1559  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1312  1
    load_2_12_18  segment_load_conservation_1506  1
    load_2_12_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1314  -30
    arc_2_12_19  connected_order_arc_1315  -12
    arc_2_12_19  out_degree_1502  1
    arc_2_12_19  in_degree_1546  1
    arc_2_12_19  original_T_including_depot_unload_1559  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1314  1
    load_2_12_19  segment_load_conservation_1506  1
    load_2_12_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1316  -30
    arc_2_12_20  connected_order_arc_1317  -12
    arc_2_12_20  out_degree_1502  1
    arc_2_12_20  in_degree_1552  1
    arc_2_12_20  original_T_including_depot_unload_1559  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1316  1
    load_2_12_20  segment_load_conservation_1506  1
    load_2_12_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1318  -30
    arc_2_13_0  depot_return_or_bypass_1487  1
    arc_2_13_0  out_degree_1509  1
    arc_2_13_0  original_T_including_depot_unload_1559  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1318  1
    load_2_13_0  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1319  -30
    arc_2_13_10  connected_order_arc_1320  -12
    arc_2_13_10  in_degree_1489  1
    arc_2_13_10  out_degree_1509  1
    arc_2_13_10  original_T_including_depot_unload_1559  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1319  1
    load_2_13_10  segment_load_conservation_1492  -1
    load_2_13_10  segment_prefix_lb_1493  1
    load_2_13_10  segment_prefix_ub_1494  1
    load_2_13_10  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1321  -30
    arc_2_13_11  connected_order_arc_1322  -12
    arc_2_13_11  in_degree_1496  1
    arc_2_13_11  out_degree_1509  1
    arc_2_13_11  original_T_including_depot_unload_1559  8.8580487162181055e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1321  1
    load_2_13_11  segment_load_conservation_1499  -1
    load_2_13_11  segment_prefix_lb_1500  1
    load_2_13_11  segment_prefix_ub_1501  1
    load_2_13_11  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1323  -30
    arc_2_13_12  connected_order_arc_1324  -12
    arc_2_13_12  in_degree_1503  1
    arc_2_13_12  out_degree_1509  1
    arc_2_13_12  original_T_including_depot_unload_1559  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1323  1
    load_2_13_12  segment_load_conservation_1506  -1
    load_2_13_12  segment_prefix_lb_1507  1
    load_2_13_12  segment_prefix_ub_1508  1
    load_2_13_12  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1325  -30
    arc_2_13_14  connected_order_arc_1326  -12
    arc_2_13_14  out_degree_1509  1
    arc_2_13_14  in_degree_1516  1
    arc_2_13_14  original_T_including_depot_unload_1559  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1325  1
    load_2_13_14  free_load_conservation_1514  1
    load_2_13_14  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1327  -30
    arc_2_13_15  connected_order_arc_1328  -12
    arc_2_13_15  out_degree_1509  1
    arc_2_13_15  in_degree_1522  1
    arc_2_13_15  original_T_including_depot_unload_1559  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1327  1
    load_2_13_15  free_load_conservation_1514  1
    load_2_13_15  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1329  -30
    arc_2_13_16  connected_order_arc_1330  -12
    arc_2_13_16  out_degree_1509  1
    arc_2_13_16  in_degree_1528  1
    arc_2_13_16  original_T_including_depot_unload_1559  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1329  1
    load_2_13_16  free_load_conservation_1514  1
    load_2_13_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1331  -30
    arc_2_13_17  connected_order_arc_1332  -12
    arc_2_13_17  out_degree_1509  1
    arc_2_13_17  in_degree_1534  1
    arc_2_13_17  original_T_including_depot_unload_1559  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1331  1
    load_2_13_17  free_load_conservation_1514  1
    load_2_13_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1333  -30
    arc_2_13_18  connected_order_arc_1334  -12
    arc_2_13_18  out_degree_1509  1
    arc_2_13_18  in_degree_1540  1
    arc_2_13_18  original_T_including_depot_unload_1559  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1333  1
    load_2_13_18  free_load_conservation_1514  1
    load_2_13_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1335  -30
    arc_2_13_19  connected_order_arc_1336  -12
    arc_2_13_19  out_degree_1509  1
    arc_2_13_19  in_degree_1546  1
    arc_2_13_19  original_T_including_depot_unload_1559  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1335  1
    load_2_13_19  free_load_conservation_1514  1
    load_2_13_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1337  -30
    arc_2_13_20  connected_order_arc_1338  -12
    arc_2_13_20  out_degree_1509  1
    arc_2_13_20  in_degree_1552  1
    arc_2_13_20  original_T_including_depot_unload_1559  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1337  1
    load_2_13_20  free_load_conservation_1514  1
    load_2_13_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1339  -30
    arc_2_14_0  depot_return_or_bypass_1487  1
    arc_2_14_0  out_degree_1515  1
    arc_2_14_0  original_T_including_depot_unload_1559  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1339  1
    load_2_14_0  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1340  -30
    arc_2_14_10  connected_order_arc_1341  -12
    arc_2_14_10  in_degree_1489  1
    arc_2_14_10  out_degree_1515  1
    arc_2_14_10  original_T_including_depot_unload_1559  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1340  1
    load_2_14_10  segment_load_conservation_1492  -1
    load_2_14_10  segment_prefix_lb_1493  1
    load_2_14_10  segment_prefix_ub_1494  1
    load_2_14_10  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1342  -30
    arc_2_14_11  connected_order_arc_1343  -12
    arc_2_14_11  in_degree_1496  1
    arc_2_14_11  out_degree_1515  1
    arc_2_14_11  original_T_including_depot_unload_1559  8.8496780902404032e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1342  1
    load_2_14_11  segment_load_conservation_1499  -1
    load_2_14_11  segment_prefix_lb_1500  1
    load_2_14_11  segment_prefix_ub_1501  1
    load_2_14_11  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1344  -30
    arc_2_14_12  connected_order_arc_1345  -12
    arc_2_14_12  in_degree_1503  1
    arc_2_14_12  out_degree_1515  1
    arc_2_14_12  original_T_including_depot_unload_1559  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1344  1
    load_2_14_12  segment_load_conservation_1506  -1
    load_2_14_12  segment_prefix_lb_1507  1
    load_2_14_12  segment_prefix_ub_1508  1
    load_2_14_12  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1346  -30
    arc_2_14_13  connected_order_arc_1347  -12
    arc_2_14_13  in_degree_1510  1
    arc_2_14_13  out_degree_1515  1
    arc_2_14_13  original_T_including_depot_unload_1559  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1346  1
    load_2_14_13  free_load_conservation_1514  -1
    load_2_14_13  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1348  -30
    arc_2_14_15  connected_order_arc_1349  -12
    arc_2_14_15  out_degree_1515  1
    arc_2_14_15  in_degree_1522  1
    arc_2_14_15  original_T_including_depot_unload_1559  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1348  1
    load_2_14_15  free_load_conservation_1520  1
    load_2_14_15  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1350  -30
    arc_2_14_16  connected_order_arc_1351  -12
    arc_2_14_16  out_degree_1515  1
    arc_2_14_16  in_degree_1528  1
    arc_2_14_16  original_T_including_depot_unload_1559  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1350  1
    load_2_14_16  free_load_conservation_1520  1
    load_2_14_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1352  -30
    arc_2_14_17  connected_order_arc_1353  -12
    arc_2_14_17  out_degree_1515  1
    arc_2_14_17  in_degree_1534  1
    arc_2_14_17  original_T_including_depot_unload_1559  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1352  1
    load_2_14_17  free_load_conservation_1520  1
    load_2_14_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1354  -30
    arc_2_14_18  connected_order_arc_1355  -12
    arc_2_14_18  out_degree_1515  1
    arc_2_14_18  in_degree_1540  1
    arc_2_14_18  original_T_including_depot_unload_1559  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1354  1
    load_2_14_18  free_load_conservation_1520  1
    load_2_14_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1356  -30
    arc_2_14_19  connected_order_arc_1357  -12
    arc_2_14_19  out_degree_1515  1
    arc_2_14_19  in_degree_1546  1
    arc_2_14_19  original_T_including_depot_unload_1559  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1356  1
    load_2_14_19  free_load_conservation_1520  1
    load_2_14_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1358  -30
    arc_2_14_20  connected_order_arc_1359  -12
    arc_2_14_20  out_degree_1515  1
    arc_2_14_20  in_degree_1552  1
    arc_2_14_20  original_T_including_depot_unload_1559  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1358  1
    load_2_14_20  free_load_conservation_1520  1
    load_2_14_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1360  -30
    arc_2_15_0  depot_return_or_bypass_1487  1
    arc_2_15_0  out_degree_1521  1
    arc_2_15_0  original_T_including_depot_unload_1559  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1360  1
    load_2_15_0  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1361  -30
    arc_2_15_10  connected_order_arc_1362  -12
    arc_2_15_10  in_degree_1489  1
    arc_2_15_10  out_degree_1521  1
    arc_2_15_10  original_T_including_depot_unload_1559  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1361  1
    load_2_15_10  segment_load_conservation_1492  -1
    load_2_15_10  segment_prefix_lb_1493  1
    load_2_15_10  segment_prefix_ub_1494  1
    load_2_15_10  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1363  -30
    arc_2_15_11  connected_order_arc_1364  -12
    arc_2_15_11  in_degree_1496  1
    arc_2_15_11  out_degree_1521  1
    arc_2_15_11  original_T_including_depot_unload_1559  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1363  1
    load_2_15_11  segment_load_conservation_1499  -1
    load_2_15_11  segment_prefix_lb_1500  1
    load_2_15_11  segment_prefix_ub_1501  1
    load_2_15_11  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1365  -30
    arc_2_15_12  connected_order_arc_1366  -12
    arc_2_15_12  in_degree_1503  1
    arc_2_15_12  out_degree_1521  1
    arc_2_15_12  original_T_including_depot_unload_1559  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1365  1
    load_2_15_12  segment_load_conservation_1506  -1
    load_2_15_12  segment_prefix_lb_1507  1
    load_2_15_12  segment_prefix_ub_1508  1
    load_2_15_12  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1367  -30
    arc_2_15_13  connected_order_arc_1368  -12
    arc_2_15_13  in_degree_1510  1
    arc_2_15_13  out_degree_1521  1
    arc_2_15_13  original_T_including_depot_unload_1559  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1367  1
    load_2_15_13  free_load_conservation_1514  -1
    load_2_15_13  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1369  -30
    arc_2_15_14  connected_order_arc_1370  -12
    arc_2_15_14  in_degree_1516  1
    arc_2_15_14  out_degree_1521  1
    arc_2_15_14  original_T_including_depot_unload_1559  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1369  1
    load_2_15_14  free_load_conservation_1520  -1
    load_2_15_14  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1371  -30
    arc_2_15_16  connected_order_arc_1372  -12
    arc_2_15_16  out_degree_1521  1
    arc_2_15_16  in_degree_1528  1
    arc_2_15_16  original_T_including_depot_unload_1559  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1371  1
    load_2_15_16  free_load_conservation_1526  1
    load_2_15_16  free_load_conservation_1532  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1373  -30
    arc_2_15_17  connected_order_arc_1374  -12
    arc_2_15_17  out_degree_1521  1
    arc_2_15_17  in_degree_1534  1
    arc_2_15_17  original_T_including_depot_unload_1559  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1373  1
    load_2_15_17  free_load_conservation_1526  1
    load_2_15_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1375  -30
    arc_2_15_18  connected_order_arc_1376  -12
    arc_2_15_18  out_degree_1521  1
    arc_2_15_18  in_degree_1540  1
    arc_2_15_18  original_T_including_depot_unload_1559  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1375  1
    load_2_15_18  free_load_conservation_1526  1
    load_2_15_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1377  -30
    arc_2_15_19  connected_order_arc_1378  -12
    arc_2_15_19  out_degree_1521  1
    arc_2_15_19  in_degree_1546  1
    arc_2_15_19  original_T_including_depot_unload_1559  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1377  1
    load_2_15_19  free_load_conservation_1526  1
    load_2_15_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1379  -30
    arc_2_15_20  connected_order_arc_1380  -12
    arc_2_15_20  out_degree_1521  1
    arc_2_15_20  in_degree_1552  1
    arc_2_15_20  original_T_including_depot_unload_1559  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1379  1
    load_2_15_20  free_load_conservation_1526  1
    load_2_15_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1381  -30
    arc_2_16_0  depot_return_or_bypass_1487  1
    arc_2_16_0  out_degree_1527  1
    arc_2_16_0  original_T_including_depot_unload_1559  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1381  1
    load_2_16_0  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1382  -30
    arc_2_16_10  connected_order_arc_1383  -12
    arc_2_16_10  in_degree_1489  1
    arc_2_16_10  out_degree_1527  1
    arc_2_16_10  original_T_including_depot_unload_1559  6.0309764600105484e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1382  1
    load_2_16_10  segment_load_conservation_1492  -1
    load_2_16_10  segment_prefix_lb_1493  1
    load_2_16_10  segment_prefix_ub_1494  1
    load_2_16_10  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1384  -30
    arc_2_16_11  connected_order_arc_1385  -12
    arc_2_16_11  in_degree_1496  1
    arc_2_16_11  out_degree_1527  1
    arc_2_16_11  original_T_including_depot_unload_1559  8.4962277657921186e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1384  1
    load_2_16_11  segment_load_conservation_1499  -1
    load_2_16_11  segment_prefix_lb_1500  1
    load_2_16_11  segment_prefix_ub_1501  1
    load_2_16_11  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1386  -30
    arc_2_16_12  connected_order_arc_1387  -12
    arc_2_16_12  in_degree_1503  1
    arc_2_16_12  out_degree_1527  1
    arc_2_16_12  original_T_including_depot_unload_1559  1.7022035239152008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1386  1
    load_2_16_12  segment_load_conservation_1506  -1
    load_2_16_12  segment_prefix_lb_1507  1
    load_2_16_12  segment_prefix_ub_1508  1
    load_2_16_12  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1388  -30
    arc_2_16_13  connected_order_arc_1389  -12
    arc_2_16_13  in_degree_1510  1
    arc_2_16_13  out_degree_1527  1
    arc_2_16_13  original_T_including_depot_unload_1559  1.7461252424213140e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1388  1
    load_2_16_13  free_load_conservation_1514  -1
    load_2_16_13  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1390  -30
    arc_2_16_14  connected_order_arc_1391  -12
    arc_2_16_14  in_degree_1516  1
    arc_2_16_14  out_degree_1527  1
    arc_2_16_14  original_T_including_depot_unload_1559  3.3800157717255917e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1390  1
    load_2_16_14  free_load_conservation_1520  -1
    load_2_16_14  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1392  -30
    arc_2_16_15  connected_order_arc_1393  -12
    arc_2_16_15  in_degree_1522  1
    arc_2_16_15  out_degree_1527  1
    arc_2_16_15  original_T_including_depot_unload_1559  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1392  1
    load_2_16_15  free_load_conservation_1526  -1
    load_2_16_15  free_load_conservation_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1394  -30
    arc_2_16_17  connected_order_arc_1395  -12
    arc_2_16_17  out_degree_1527  1
    arc_2_16_17  in_degree_1534  1
    arc_2_16_17  original_T_including_depot_unload_1559  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1394  1
    load_2_16_17  free_load_conservation_1532  1
    load_2_16_17  free_load_conservation_1538  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1396  -30
    arc_2_16_18  connected_order_arc_1397  -12
    arc_2_16_18  out_degree_1527  1
    arc_2_16_18  in_degree_1540  1
    arc_2_16_18  original_T_including_depot_unload_1559  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1396  1
    load_2_16_18  free_load_conservation_1532  1
    load_2_16_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1398  -30
    arc_2_16_19  connected_order_arc_1399  -12
    arc_2_16_19  out_degree_1527  1
    arc_2_16_19  in_degree_1546  1
    arc_2_16_19  original_T_including_depot_unload_1559  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1398  1
    load_2_16_19  free_load_conservation_1532  1
    load_2_16_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1400  -30
    arc_2_16_20  connected_order_arc_1401  -12
    arc_2_16_20  out_degree_1527  1
    arc_2_16_20  in_degree_1552  1
    arc_2_16_20  original_T_including_depot_unload_1559  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1400  1
    load_2_16_20  free_load_conservation_1532  1
    load_2_16_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1402  -30
    arc_2_17_0  depot_return_or_bypass_1487  1
    arc_2_17_0  out_degree_1533  1
    arc_2_17_0  original_T_including_depot_unload_1559  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1402  1
    load_2_17_0  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1403  -30
    arc_2_17_10  connected_order_arc_1404  -12
    arc_2_17_10  in_degree_1489  1
    arc_2_17_10  out_degree_1533  1
    arc_2_17_10  original_T_including_depot_unload_1559  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1403  1
    load_2_17_10  segment_load_conservation_1492  -1
    load_2_17_10  segment_prefix_lb_1493  1
    load_2_17_10  segment_prefix_ub_1494  1
    load_2_17_10  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1405  -30
    arc_2_17_11  connected_order_arc_1406  -12
    arc_2_17_11  in_degree_1496  1
    arc_2_17_11  out_degree_1533  1
    arc_2_17_11  original_T_including_depot_unload_1559  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1405  1
    load_2_17_11  segment_load_conservation_1499  -1
    load_2_17_11  segment_prefix_lb_1500  1
    load_2_17_11  segment_prefix_ub_1501  1
    load_2_17_11  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1407  -30
    arc_2_17_12  connected_order_arc_1408  -12
    arc_2_17_12  in_degree_1503  1
    arc_2_17_12  out_degree_1533  1
    arc_2_17_12  original_T_including_depot_unload_1559  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1407  1
    load_2_17_12  segment_load_conservation_1506  -1
    load_2_17_12  segment_prefix_lb_1507  1
    load_2_17_12  segment_prefix_ub_1508  1
    load_2_17_12  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1409  -30
    arc_2_17_13  connected_order_arc_1410  -12
    arc_2_17_13  in_degree_1510  1
    arc_2_17_13  out_degree_1533  1
    arc_2_17_13  original_T_including_depot_unload_1559  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1409  1
    load_2_17_13  free_load_conservation_1514  -1
    load_2_17_13  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1411  -30
    arc_2_17_14  connected_order_arc_1412  -12
    arc_2_17_14  in_degree_1516  1
    arc_2_17_14  out_degree_1533  1
    arc_2_17_14  original_T_including_depot_unload_1559  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1411  1
    load_2_17_14  free_load_conservation_1520  -1
    load_2_17_14  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1413  -30
    arc_2_17_15  connected_order_arc_1414  -12
    arc_2_17_15  in_degree_1522  1
    arc_2_17_15  out_degree_1533  1
    arc_2_17_15  original_T_including_depot_unload_1559  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1413  1
    load_2_17_15  free_load_conservation_1526  -1
    load_2_17_15  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1415  -30
    arc_2_17_16  connected_order_arc_1416  -12
    arc_2_17_16  in_degree_1528  1
    arc_2_17_16  out_degree_1533  1
    arc_2_17_16  original_T_including_depot_unload_1559  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1415  1
    load_2_17_16  free_load_conservation_1532  -1
    load_2_17_16  free_load_conservation_1538  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1417  -30
    arc_2_17_18  connected_order_arc_1418  -12
    arc_2_17_18  out_degree_1533  1
    arc_2_17_18  in_degree_1540  1
    arc_2_17_18  original_T_including_depot_unload_1559  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1417  1
    load_2_17_18  free_load_conservation_1538  1
    load_2_17_18  free_load_conservation_1544  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1419  -30
    arc_2_17_19  connected_order_arc_1420  -12
    arc_2_17_19  out_degree_1533  1
    arc_2_17_19  in_degree_1546  1
    arc_2_17_19  original_T_including_depot_unload_1559  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1419  1
    load_2_17_19  free_load_conservation_1538  1
    load_2_17_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1421  -30
    arc_2_17_20  connected_order_arc_1422  -12
    arc_2_17_20  out_degree_1533  1
    arc_2_17_20  in_degree_1552  1
    arc_2_17_20  original_T_including_depot_unload_1559  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1421  1
    load_2_17_20  free_load_conservation_1538  1
    load_2_17_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1423  -30
    arc_2_18_0  depot_return_or_bypass_1487  1
    arc_2_18_0  out_degree_1539  1
    arc_2_18_0  original_T_including_depot_unload_1559  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1423  1
    load_2_18_0  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1424  -30
    arc_2_18_10  connected_order_arc_1425  -12
    arc_2_18_10  in_degree_1489  1
    arc_2_18_10  out_degree_1539  1
    arc_2_18_10  original_T_including_depot_unload_1559  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1424  1
    load_2_18_10  segment_load_conservation_1492  -1
    load_2_18_10  segment_prefix_lb_1493  1
    load_2_18_10  segment_prefix_ub_1494  1
    load_2_18_10  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1426  -30
    arc_2_18_11  connected_order_arc_1427  -12
    arc_2_18_11  in_degree_1496  1
    arc_2_18_11  out_degree_1539  1
    arc_2_18_11  original_T_including_depot_unload_1559  1.1260666281343611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1426  1
    load_2_18_11  segment_load_conservation_1499  -1
    load_2_18_11  segment_prefix_lb_1500  1
    load_2_18_11  segment_prefix_ub_1501  1
    load_2_18_11  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1428  -30
    arc_2_18_12  connected_order_arc_1429  -12
    arc_2_18_12  in_degree_1503  1
    arc_2_18_12  out_degree_1539  1
    arc_2_18_12  original_T_including_depot_unload_1559  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1428  1
    load_2_18_12  segment_load_conservation_1506  -1
    load_2_18_12  segment_prefix_lb_1507  1
    load_2_18_12  segment_prefix_ub_1508  1
    load_2_18_12  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1430  -30
    arc_2_18_13  connected_order_arc_1431  -12
    arc_2_18_13  in_degree_1510  1
    arc_2_18_13  out_degree_1539  1
    arc_2_18_13  original_T_including_depot_unload_1559  2.7078292664437623e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1430  1
    load_2_18_13  free_load_conservation_1514  -1
    load_2_18_13  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1432  -30
    arc_2_18_14  connected_order_arc_1433  -12
    arc_2_18_14  in_degree_1516  1
    arc_2_18_14  out_degree_1539  1
    arc_2_18_14  original_T_including_depot_unload_1559  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1432  1
    load_2_18_14  free_load_conservation_1520  -1
    load_2_18_14  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1434  -30
    arc_2_18_15  connected_order_arc_1435  -12
    arc_2_18_15  in_degree_1522  1
    arc_2_18_15  out_degree_1539  1
    arc_2_18_15  original_T_including_depot_unload_1559  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1434  1
    load_2_18_15  free_load_conservation_1526  -1
    load_2_18_15  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1436  -30
    arc_2_18_16  connected_order_arc_1437  -12
    arc_2_18_16  in_degree_1528  1
    arc_2_18_16  out_degree_1539  1
    arc_2_18_16  original_T_including_depot_unload_1559  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1436  1
    load_2_18_16  free_load_conservation_1532  -1
    load_2_18_16  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1438  -30
    arc_2_18_17  connected_order_arc_1439  -12
    arc_2_18_17  in_degree_1534  1
    arc_2_18_17  out_degree_1539  1
    arc_2_18_17  original_T_including_depot_unload_1559  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1438  1
    load_2_18_17  free_load_conservation_1538  -1
    load_2_18_17  free_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1440  -30
    arc_2_18_19  connected_order_arc_1441  -12
    arc_2_18_19  out_degree_1539  1
    arc_2_18_19  in_degree_1546  1
    arc_2_18_19  original_T_including_depot_unload_1559  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1440  1
    load_2_18_19  free_load_conservation_1544  1
    load_2_18_19  free_load_conservation_1550  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1442  -30
    arc_2_18_20  connected_order_arc_1443  -12
    arc_2_18_20  out_degree_1539  1
    arc_2_18_20  in_degree_1552  1
    arc_2_18_20  original_T_including_depot_unload_1559  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1442  1
    load_2_18_20  free_load_conservation_1544  1
    load_2_18_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1444  -30
    arc_2_19_0  depot_return_or_bypass_1487  1
    arc_2_19_0  out_degree_1545  1
    arc_2_19_0  original_T_including_depot_unload_1559  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1444  1
    load_2_19_0  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1445  -30
    arc_2_19_10  connected_order_arc_1446  -12
    arc_2_19_10  in_degree_1489  1
    arc_2_19_10  out_degree_1545  1
    arc_2_19_10  original_T_including_depot_unload_1559  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1445  1
    load_2_19_10  segment_load_conservation_1492  -1
    load_2_19_10  segment_prefix_lb_1493  1
    load_2_19_10  segment_prefix_ub_1494  1
    load_2_19_10  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1447  -30
    arc_2_19_11  connected_order_arc_1448  -12
    arc_2_19_11  in_degree_1496  1
    arc_2_19_11  out_degree_1545  1
    arc_2_19_11  original_T_including_depot_unload_1559  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1447  1
    load_2_19_11  segment_load_conservation_1499  -1
    load_2_19_11  segment_prefix_lb_1500  1
    load_2_19_11  segment_prefix_ub_1501  1
    load_2_19_11  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1449  -30
    arc_2_19_12  connected_order_arc_1450  -12
    arc_2_19_12  in_degree_1503  1
    arc_2_19_12  out_degree_1545  1
    arc_2_19_12  original_T_including_depot_unload_1559  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1449  1
    load_2_19_12  segment_load_conservation_1506  -1
    load_2_19_12  segment_prefix_lb_1507  1
    load_2_19_12  segment_prefix_ub_1508  1
    load_2_19_12  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1451  -30
    arc_2_19_13  connected_order_arc_1452  -12
    arc_2_19_13  in_degree_1510  1
    arc_2_19_13  out_degree_1545  1
    arc_2_19_13  original_T_including_depot_unload_1559  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1451  1
    load_2_19_13  free_load_conservation_1514  -1
    load_2_19_13  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1453  -30
    arc_2_19_14  connected_order_arc_1454  -12
    arc_2_19_14  in_degree_1516  1
    arc_2_19_14  out_degree_1545  1
    arc_2_19_14  original_T_including_depot_unload_1559  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1453  1
    load_2_19_14  free_load_conservation_1520  -1
    load_2_19_14  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1455  -30
    arc_2_19_15  connected_order_arc_1456  -12
    arc_2_19_15  in_degree_1522  1
    arc_2_19_15  out_degree_1545  1
    arc_2_19_15  original_T_including_depot_unload_1559  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1455  1
    load_2_19_15  free_load_conservation_1526  -1
    load_2_19_15  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1457  -30
    arc_2_19_16  connected_order_arc_1458  -12
    arc_2_19_16  in_degree_1528  1
    arc_2_19_16  out_degree_1545  1
    arc_2_19_16  original_T_including_depot_unload_1559  1.0838347754693179e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1457  1
    load_2_19_16  free_load_conservation_1532  -1
    load_2_19_16  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1459  -30
    arc_2_19_17  connected_order_arc_1460  -12
    arc_2_19_17  in_degree_1534  1
    arc_2_19_17  out_degree_1545  1
    arc_2_19_17  original_T_including_depot_unload_1559  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1459  1
    load_2_19_17  free_load_conservation_1538  -1
    load_2_19_17  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1461  -30
    arc_2_19_18  connected_order_arc_1462  -12
    arc_2_19_18  in_degree_1540  1
    arc_2_19_18  out_degree_1545  1
    arc_2_19_18  original_T_including_depot_unload_1559  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1461  1
    load_2_19_18  free_load_conservation_1544  -1
    load_2_19_18  free_load_conservation_1550  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1463  -30
    arc_2_19_20  connected_order_arc_1464  -12
    arc_2_19_20  out_degree_1545  1
    arc_2_19_20  in_degree_1552  1
    arc_2_19_20  original_T_including_depot_unload_1559  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1463  1
    load_2_19_20  free_load_conservation_1550  1
    load_2_19_20  free_load_conservation_1556  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1465  -30
    arc_2_20_0  depot_return_or_bypass_1487  1
    arc_2_20_0  out_degree_1551  1
    arc_2_20_0  original_T_including_depot_unload_1559  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1465  1
    load_2_20_0  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1466  -30
    arc_2_20_10  connected_order_arc_1467  -12
    arc_2_20_10  in_degree_1489  1
    arc_2_20_10  out_degree_1551  1
    arc_2_20_10  original_T_including_depot_unload_1559  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1466  1
    load_2_20_10  segment_load_conservation_1492  -1
    load_2_20_10  segment_prefix_lb_1493  1
    load_2_20_10  segment_prefix_ub_1494  1
    load_2_20_10  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1468  -30
    arc_2_20_11  connected_order_arc_1469  -12
    arc_2_20_11  in_degree_1496  1
    arc_2_20_11  out_degree_1551  1
    arc_2_20_11  original_T_including_depot_unload_1559  6.4419272207888969e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1468  1
    load_2_20_11  segment_load_conservation_1499  -1
    load_2_20_11  segment_prefix_lb_1500  1
    load_2_20_11  segment_prefix_ub_1501  1
    load_2_20_11  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1470  -30
    arc_2_20_12  connected_order_arc_1471  -12
    arc_2_20_12  in_degree_1503  1
    arc_2_20_12  out_degree_1551  1
    arc_2_20_12  original_T_including_depot_unload_1559  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1470  1
    load_2_20_12  segment_load_conservation_1506  -1
    load_2_20_12  segment_prefix_lb_1507  1
    load_2_20_12  segment_prefix_ub_1508  1
    load_2_20_12  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1472  -30
    arc_2_20_13  connected_order_arc_1473  -12
    arc_2_20_13  in_degree_1510  1
    arc_2_20_13  out_degree_1551  1
    arc_2_20_13  original_T_including_depot_unload_1559  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1472  1
    load_2_20_13  free_load_conservation_1514  -1
    load_2_20_13  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1474  -30
    arc_2_20_14  connected_order_arc_1475  -12
    arc_2_20_14  in_degree_1516  1
    arc_2_20_14  out_degree_1551  1
    arc_2_20_14  original_T_including_depot_unload_1559  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1474  1
    load_2_20_14  free_load_conservation_1520  -1
    load_2_20_14  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1476  -30
    arc_2_20_15  connected_order_arc_1477  -12
    arc_2_20_15  in_degree_1522  1
    arc_2_20_15  out_degree_1551  1
    arc_2_20_15  original_T_including_depot_unload_1559  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1476  1
    load_2_20_15  free_load_conservation_1526  -1
    load_2_20_15  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1478  -30
    arc_2_20_16  connected_order_arc_1479  -12
    arc_2_20_16  in_degree_1528  1
    arc_2_20_16  out_degree_1551  1
    arc_2_20_16  original_T_including_depot_unload_1559  3.4289721135663990e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1478  1
    load_2_20_16  free_load_conservation_1532  -1
    load_2_20_16  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1480  -30
    arc_2_20_17  connected_order_arc_1481  -12
    arc_2_20_17  in_degree_1534  1
    arc_2_20_17  out_degree_1551  1
    arc_2_20_17  original_T_including_depot_unload_1559  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1480  1
    load_2_20_17  free_load_conservation_1538  -1
    load_2_20_17  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1482  -30
    arc_2_20_18  connected_order_arc_1483  -12
    arc_2_20_18  in_degree_1540  1
    arc_2_20_18  out_degree_1551  1
    arc_2_20_18  original_T_including_depot_unload_1559  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1482  1
    load_2_20_18  free_load_conservation_1544  -1
    load_2_20_18  free_load_conservation_1556  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1484  -30
    arc_2_20_19  connected_order_arc_1485  -12
    arc_2_20_19  in_degree_1546  1
    arc_2_20_19  out_degree_1551  1
    arc_2_20_19  original_T_including_depot_unload_1559  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1484  1
    load_2_20_19  free_load_conservation_1550  -1
    load_2_20_19  free_load_conservation_1556  1
RHS
    RHS1      OBJ       -0.507
    RHS1      onehot_1_40  1
    RHS1      onehot_2_75  1
    RHS1      onehot_31_104  1
    RHS1      onehot_3_143  1
    RHS1      onehot_32_172  1
    RHS1      onehot_4_207  1
    RHS1      onehot_19_228  1
    RHS1      onehot_5_265  1
    RHS1      stock_ub_269  39
    RHS1      parent_nonstrict_scope_270  3.2534040918067930e-01
    RHS1      normalization_327  1
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_700  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_709  -13
    RHS1      connected_order_arc_711  -13
    RHS1      connected_order_arc_713  -13
    RHS1      connected_order_arc_715  -13
    RHS1      connected_order_arc_717  -13
    RHS1      connected_order_arc_719  -13
    RHS1      connected_order_arc_721  -13
    RHS1      connected_order_arc_723  -13
    RHS1      connected_order_arc_725  -13
    RHS1      connected_order_arc_727  -13
    RHS1      connected_order_arc_729  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_734  -13
    RHS1      connected_order_arc_736  -13
    RHS1      connected_order_arc_738  -13
    RHS1      connected_order_arc_740  -13
    RHS1      connected_order_arc_742  -13
    RHS1      connected_order_arc_744  -13
    RHS1      connected_order_arc_746  -13
    RHS1      connected_order_arc_748  -13
    RHS1      connected_order_arc_750  -13
    RHS1      connected_order_arc_752  -13
    RHS1      connected_order_arc_754  -13
    RHS1      connected_order_arc_756  -13
    RHS1      connected_order_arc_759  -13
    RHS1      connected_order_arc_761  -13
    RHS1      connected_order_arc_763  -13
    RHS1      connected_order_arc_765  -13
    RHS1      connected_order_arc_767  -13
    RHS1      connected_order_arc_769  -13
    RHS1      connected_order_arc_771  -13
    RHS1      connected_order_arc_773  -13
    RHS1      connected_order_arc_775  -13
    RHS1      connected_order_arc_777  -13
    RHS1      connected_order_arc_779  -13
    RHS1      connected_order_arc_781  -13
    RHS1      depot_departure_or_bypass_782  1
    RHS1      depot_return_or_bypass_783  1
    RHS1      segment_load_conservation_788  2
    RHS1      segment_prefix_ub_790  18
    RHS1      segment_load_conservation_795  4
    RHS1      segment_prefix_ub_797  16
    RHS1      segment_load_conservation_802  5
    RHS1      segment_prefix_ub_804  15
    RHS1      segment_load_conservation_809  5
    RHS1      segment_prefix_ub_811  9
    RHS1      segment_load_conservation_816  -6
    RHS1      segment_prefix_lb_817  6
    RHS1      segment_prefix_ub_818  20
    RHS1      fixed_segment_relative_order_867  1
    RHS1      fixed_segment_relative_order_868  1
    RHS1      fixed_segment_relative_order_869  1
    RHS1      fixed_segment_relative_order_870  1
    RHS1      original_T_including_depot_unload_871  4.0153337810140947e+03
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1094  -12
    RHS1      connected_order_arc_1096  -12
    RHS1      connected_order_arc_1098  -12
    RHS1      connected_order_arc_1100  -12
    RHS1      connected_order_arc_1102  -12
    RHS1      connected_order_arc_1104  -12
    RHS1      connected_order_arc_1106  -12
    RHS1      connected_order_arc_1108  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1117  -12
    RHS1      connected_order_arc_1119  -12
    RHS1      connected_order_arc_1121  -12
    RHS1      connected_order_arc_1123  -12
    RHS1      connected_order_arc_1125  -12
    RHS1      connected_order_arc_1127  -12
    RHS1      connected_order_arc_1129  -12
    RHS1      connected_order_arc_1131  -12
    RHS1      connected_order_arc_1133  -12
    RHS1      connected_order_arc_1135  -12
    RHS1      connected_order_arc_1137  -12
    RHS1      connected_order_arc_1140  -12
    RHS1      connected_order_arc_1142  -12
    RHS1      connected_order_arc_1144  -12
    RHS1      connected_order_arc_1146  -12
    RHS1      connected_order_arc_1148  -12
    RHS1      connected_order_arc_1150  -12
    RHS1      connected_order_arc_1152  -12
    RHS1      connected_order_arc_1154  -12
    RHS1      connected_order_arc_1156  -12
    RHS1      connected_order_arc_1158  -12
    RHS1      connected_order_arc_1160  -12
    RHS1      depot_departure_or_bypass_1161  1
    RHS1      depot_return_or_bypass_1162  1
    RHS1      segment_load_conservation_1167  7
    RHS1      segment_prefix_ub_1169  18
    RHS1      segment_load_conservation_1174  -5
    RHS1      segment_prefix_lb_1175  5
    RHS1      segment_prefix_ub_1176  25
    RHS1      segment_load_conservation_1181  2
    RHS1      segment_prefix_lb_1182  2
    RHS1      segment_prefix_ub_1183  16
    RHS1      segment_load_conservation_1188  -4
    RHS1      segment_prefix_lb_1189  4
    RHS1      segment_prefix_ub_1190  25
    RHS1      fixed_segment_relative_order_1239  1
    RHS1      fixed_segment_relative_order_1240  1
    RHS1      fixed_segment_relative_order_1241  1
    RHS1      original_T_including_depot_unload_1242  2.5933514884265333e+03
    RHS1      connected_order_arc_1257  -11
    RHS1      connected_order_arc_1259  -11
    RHS1      connected_order_arc_1261  -11
    RHS1      connected_order_arc_1263  -11
    RHS1      connected_order_arc_1265  -11
    RHS1      connected_order_arc_1267  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1278  -11
    RHS1      connected_order_arc_1280  -11
    RHS1      connected_order_arc_1282  -11
    RHS1      connected_order_arc_1284  -11
    RHS1      connected_order_arc_1286  -11
    RHS1      connected_order_arc_1288  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1299  -11
    RHS1      connected_order_arc_1301  -11
    RHS1      connected_order_arc_1303  -11
    RHS1      connected_order_arc_1305  -11
    RHS1      connected_order_arc_1307  -11
    RHS1      connected_order_arc_1309  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1320  -11
    RHS1      connected_order_arc_1322  -11
    RHS1      connected_order_arc_1324  -11
    RHS1      connected_order_arc_1326  -11
    RHS1      connected_order_arc_1328  -11
    RHS1      connected_order_arc_1330  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1341  -11
    RHS1      connected_order_arc_1343  -11
    RHS1      connected_order_arc_1345  -11
    RHS1      connected_order_arc_1347  -11
    RHS1      connected_order_arc_1349  -11
    RHS1      connected_order_arc_1351  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1362  -11
    RHS1      connected_order_arc_1364  -11
    RHS1      connected_order_arc_1366  -11
    RHS1      connected_order_arc_1368  -11
    RHS1      connected_order_arc_1370  -11
    RHS1      connected_order_arc_1372  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1383  -11
    RHS1      connected_order_arc_1385  -11
    RHS1      connected_order_arc_1387  -11
    RHS1      connected_order_arc_1389  -11
    RHS1      connected_order_arc_1391  -11
    RHS1      connected_order_arc_1393  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1404  -11
    RHS1      connected_order_arc_1406  -11
    RHS1      connected_order_arc_1408  -11
    RHS1      connected_order_arc_1410  -11
    RHS1      connected_order_arc_1412  -11
    RHS1      connected_order_arc_1414  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1425  -11
    RHS1      connected_order_arc_1427  -11
    RHS1      connected_order_arc_1429  -11
    RHS1      connected_order_arc_1431  -11
    RHS1      connected_order_arc_1433  -11
    RHS1      connected_order_arc_1435  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1446  -11
    RHS1      connected_order_arc_1448  -11
    RHS1      connected_order_arc_1450  -11
    RHS1      connected_order_arc_1452  -11
    RHS1      connected_order_arc_1454  -11
    RHS1      connected_order_arc_1456  -11
    RHS1      connected_order_arc_1458  -11
    RHS1      connected_order_arc_1460  -11
    RHS1      connected_order_arc_1462  -11
    RHS1      connected_order_arc_1464  -11
    RHS1      connected_order_arc_1467  -11
    RHS1      connected_order_arc_1469  -11
    RHS1      connected_order_arc_1471  -11
    RHS1      connected_order_arc_1473  -11
    RHS1      connected_order_arc_1475  -11
    RHS1      connected_order_arc_1477  -11
    RHS1      connected_order_arc_1479  -11
    RHS1      connected_order_arc_1481  -11
    RHS1      connected_order_arc_1483  -11
    RHS1      connected_order_arc_1485  -11
    RHS1      depot_departure_or_bypass_1486  1
    RHS1      depot_return_or_bypass_1487  1
    RHS1      segment_load_conservation_1492  1
    RHS1      segment_prefix_ub_1494  28
    RHS1      segment_prefix_ub_1501  25
    RHS1      segment_load_conservation_1506  -1
    RHS1      segment_prefix_lb_1507  1
    RHS1      segment_prefix_ub_1508  26
    RHS1      fixed_segment_relative_order_1557  1
    RHS1      fixed_segment_relative_order_1558  1
    RHS1      original_T_including_depot_unload_1559  3.0176131259535950e+03
BOUNDS
 LO BND1      t         2.4930254644718940e-02
 UP BND1      t         4.2217419711556528e-02
 UP BND1      q         4.9634040918067934e-01
 BV BND1      x_1_0   
 UP BND1      w_1_0     4.2217419711556528e-02
 BV BND1      x_1_1   
 UP BND1      w_1_1     4.2217419711556528e-02
 BV BND1      x_1_2   
 UP BND1      w_1_2     4.2217419711556528e-02
 BV BND1      x_1_3   
 UP BND1      w_1_3     4.2217419711556528e-02
 BV BND1      x_1_4   
 UP BND1      w_1_4     4.2217419711556528e-02
 BV BND1      x_1_5   
 UP BND1      w_1_5     4.2217419711556528e-02
 BV BND1      x_1_6   
 UP BND1      w_1_6     4.2217419711556528e-02
 BV BND1      x_1_7   
 UP BND1      w_1_7     4.2217419711556528e-02
 BV BND1      x_1_8   
 UP BND1      w_1_8     4.2217419711556528e-02
 BV BND1      x_1_9   
 UP BND1      w_1_9     4.2217419711556528e-02
 BV BND1      x_1_10  
 UP BND1      w_1_10    4.2217419711556528e-02
 BV BND1      x_1_11  
 UP BND1      w_1_11    4.2217419711556528e-02
 BV BND1      x_1_12  
 UP BND1      w_1_12    4.2217419711556528e-02
 BV BND1      x_1_13  
 UP BND1      w_1_13    4.2217419711556528e-02
 BV BND1      x_1_14  
 UP BND1      w_1_14    4.2217419711556528e-02
 BV BND1      x_1_15  
 UP BND1      w_1_15    4.2217419711556528e-02
 BV BND1      x_1_16  
 UP BND1      w_1_16    4.2217419711556528e-02
 BV BND1      x_1_17  
 UP BND1      w_1_17    4.2217419711556528e-02
 BV BND1      x_1_18  
 UP BND1      w_1_18    4.2217419711556528e-02
 BV BND1      x_1_19  
 UP BND1      w_1_19    4.2217419711556528e-02
 UP BND1      rho_1     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     4.2217419711556528e-02
 BV BND1      x_2_1   
 UP BND1      w_2_1     4.2217419711556528e-02
 BV BND1      x_2_2   
 UP BND1      w_2_2     4.2217419711556528e-02
 BV BND1      x_2_3   
 UP BND1      w_2_3     4.2217419711556528e-02
 BV BND1      x_2_4   
 UP BND1      w_2_4     4.2217419711556528e-02
 BV BND1      x_2_5   
 UP BND1      w_2_5     4.2217419711556528e-02
 BV BND1      x_2_6   
 UP BND1      w_2_6     4.2217419711556528e-02
 BV BND1      x_2_7   
 UP BND1      w_2_7     4.2217419711556528e-02
 BV BND1      x_2_8   
 UP BND1      w_2_8     4.2217419711556528e-02
 BV BND1      x_2_9   
 UP BND1      w_2_9     4.2217419711556528e-02
 BV BND1      x_2_10  
 UP BND1      w_2_10    4.2217419711556528e-02
 BV BND1      x_2_11  
 UP BND1      w_2_11    4.2217419711556528e-02
 BV BND1      x_2_12  
 UP BND1      w_2_12    4.2217419711556528e-02
 BV BND1      x_2_13  
 UP BND1      w_2_13    4.2217419711556528e-02
 BV BND1      x_2_14  
 UP BND1      w_2_14    4.2217419711556528e-02
 BV BND1      x_2_15  
 UP BND1      w_2_15    4.2217419711556528e-02
 UP BND1      rho_2     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2217419711556528e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2217419711556528e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2217419711556528e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2217419711556528e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2217419711556528e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2217419711556528e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2217419711556528e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2217419711556528e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2217419711556528e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2217419711556528e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2217419711556528e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2217419711556528e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2217419711556528e-02
 UP BND1      rho_31    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     4.2217419711556528e-02
 BV BND1      x_3_1   
 UP BND1      w_3_1     4.2217419711556528e-02
 BV BND1      x_3_2   
 UP BND1      w_3_2     4.2217419711556528e-02
 BV BND1      x_3_3   
 UP BND1      w_3_3     4.2217419711556528e-02
 BV BND1      x_3_4   
 UP BND1      w_3_4     4.2217419711556528e-02
 BV BND1      x_3_5   
 UP BND1      w_3_5     4.2217419711556528e-02
 BV BND1      x_3_6   
 UP BND1      w_3_6     4.2217419711556528e-02
 BV BND1      x_3_7   
 UP BND1      w_3_7     4.2217419711556528e-02
 BV BND1      x_3_8   
 UP BND1      w_3_8     4.2217419711556528e-02
 BV BND1      x_3_9   
 UP BND1      w_3_9     4.2217419711556528e-02
 BV BND1      x_3_10  
 UP BND1      w_3_10    4.2217419711556528e-02
 BV BND1      x_3_11  
 UP BND1      w_3_11    4.2217419711556528e-02
 BV BND1      x_3_12  
 UP BND1      w_3_12    4.2217419711556528e-02
 BV BND1      x_3_13  
 UP BND1      w_3_13    4.2217419711556528e-02
 BV BND1      x_3_14  
 UP BND1      w_3_14    4.2217419711556528e-02
 BV BND1      x_3_15  
 UP BND1      w_3_15    4.2217419711556528e-02
 BV BND1      x_3_16  
 UP BND1      w_3_16    4.2217419711556528e-02
 BV BND1      x_3_17  
 UP BND1      w_3_17    4.2217419711556528e-02
 UP BND1      rho_3     1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.2217419711556528e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.2217419711556528e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.2217419711556528e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.2217419711556528e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.2217419711556528e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.2217419711556528e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.2217419711556528e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.2217419711556528e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.2217419711556528e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.2217419711556528e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.2217419711556528e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.2217419711556528e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.2217419711556528e-02
 UP BND1      rho_32    1
 BV BND1      x_4_0   
 UP BND1      w_4_0     4.2217419711556528e-02
 BV BND1      x_4_1   
 UP BND1      w_4_1     4.2217419711556528e-02
 BV BND1      x_4_2   
 UP BND1      w_4_2     4.2217419711556528e-02
 BV BND1      x_4_3   
 UP BND1      w_4_3     4.2217419711556528e-02
 BV BND1      x_4_4   
 UP BND1      w_4_4     4.2217419711556528e-02
 BV BND1      x_4_5   
 UP BND1      w_4_5     4.2217419711556528e-02
 BV BND1      x_4_6   
 UP BND1      w_4_6     4.2217419711556528e-02
 BV BND1      x_4_7   
 UP BND1      w_4_7     4.2217419711556528e-02
 BV BND1      x_4_8   
 UP BND1      w_4_8     4.2217419711556528e-02
 BV BND1      x_4_9   
 UP BND1      w_4_9     4.2217419711556528e-02
 BV BND1      x_4_10  
 UP BND1      w_4_10    4.2217419711556528e-02
 BV BND1      x_4_11  
 UP BND1      w_4_11    4.2217419711556528e-02
 BV BND1      x_4_12  
 UP BND1      w_4_12    4.2217419711556528e-02
 BV BND1      x_4_13  
 UP BND1      w_4_13    4.2217419711556528e-02
 BV BND1      x_4_14  
 UP BND1      w_4_14    4.2217419711556528e-02
 BV BND1      x_4_15  
 UP BND1      w_4_15    4.2217419711556528e-02
 UP BND1      rho_4     1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.2217419711556528e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.2217419711556528e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.2217419711556528e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.2217419711556528e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.2217419711556528e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.2217419711556528e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.2217419711556528e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.2217419711556528e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.2217419711556528e-02
 UP BND1      rho_19    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     4.2217419711556528e-02
 BV BND1      x_5_1   
 UP BND1      w_5_1     4.2217419711556528e-02
 BV BND1      x_5_2   
 UP BND1      w_5_2     4.2217419711556528e-02
 BV BND1      x_5_3   
 UP BND1      w_5_3     4.2217419711556528e-02
 BV BND1      x_5_4   
 UP BND1      w_5_4     4.2217419711556528e-02
 BV BND1      x_5_5   
 UP BND1      w_5_5     4.2217419711556528e-02
 BV BND1      x_5_6   
 UP BND1      w_5_6     4.2217419711556528e-02
 BV BND1      x_5_7   
 UP BND1      w_5_7     4.2217419711556528e-02
 BV BND1      x_5_8   
 UP BND1      w_5_8     4.2217419711556528e-02
 BV BND1      x_5_9   
 UP BND1      w_5_9     4.2217419711556528e-02
 BV BND1      x_5_10  
 UP BND1      w_5_10    4.2217419711556528e-02
 BV BND1      x_5_11  
 UP BND1      w_5_11    4.2217419711556528e-02
 BV BND1      x_5_12  
 UP BND1      w_5_12    4.2217419711556528e-02
 BV BND1      x_5_13  
 UP BND1      w_5_13    4.2217419711556528e-02
 BV BND1      x_5_14  
 UP BND1      w_5_14    4.2217419711556528e-02
 BV BND1      x_5_15  
 UP BND1      w_5_15    4.2217419711556528e-02
 BV BND1      x_5_16  
 UP BND1      w_5_16    4.2217419711556528e-02
 UP BND1      rho_5     1
 UP BND1      a_1_2     1
 UP BND1      a_1_31    1
 UP BND1      a_1_3     1
 UP BND1      a_1_32    1
 UP BND1      a_1_4     1
 UP BND1      a_1_19    1
 UP BND1      a_1_5     1
 UP BND1      a_2_31    1
 UP BND1      a_2_3     1
 UP BND1      a_2_32    1
 UP BND1      a_2_4     1
 UP BND1      a_2_19    1
 UP BND1      a_2_5     1
 UP BND1      a_31_3    1
 UP BND1      a_31_32   1
 UP BND1      a_31_4    1
 UP BND1      a_31_19   1
 UP BND1      a_31_5    1
 UP BND1      a_3_32    1
 UP BND1      a_3_4     1
 UP BND1      a_3_19    1
 UP BND1      a_3_5     1
 UP BND1      a_32_4    1
 UP BND1      a_32_19   1
 UP BND1      a_32_5    1
 UP BND1      a_4_19    1
 UP BND1      a_4_5     1
 UP BND1      a_19_5    1
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_0_1_16
 BV BND1      service_0_1_17
 BV BND1      service_0_1_18
 BV BND1      service_0_1_19
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_1_1_16
 BV BND1      service_1_1_17
 BV BND1      service_1_1_18
 BV BND1      service_1_1_19
 BV BND1      service_2_1_0
 BV BND1      service_2_1_1
 BV BND1      service_2_1_3
 BV BND1      service_2_1_4
 BV BND1      service_2_1_5
 BV BND1      service_2_1_6
 BV BND1      service_2_1_7
 BV BND1      service_2_1_8
 BV BND1      service_2_1_9
 BV BND1      service_2_1_10
 BV BND1      service_2_1_11
 BV BND1      service_2_1_12
 BV BND1      service_2_1_13
 BV BND1      service_2_1_14
 BV BND1      service_2_1_15
 BV BND1      service_2_1_16
 BV BND1      service_2_1_17
 BV BND1      service_2_1_18
 BV BND1      service_2_1_19
 BV BND1      service_0_2_1
 BV BND1      service_0_2_2
 BV BND1      service_0_2_3
 BV BND1      service_0_2_4
 BV BND1      service_0_2_5
 BV BND1      service_0_2_6
 BV BND1      service_0_2_7
 BV BND1      service_0_2_8
 BV BND1      service_0_2_9
 BV BND1      service_0_2_10
 BV BND1      service_0_2_11
 BV BND1      service_0_2_12
 BV BND1      service_0_2_13
 BV BND1      service_0_2_14
 BV BND1      service_0_2_15
 BV BND1      service_1_2_1
 BV BND1      service_1_2_2
 BV BND1      service_1_2_3
 BV BND1      service_1_2_4
 BV BND1      service_1_2_5
 BV BND1      service_1_2_6
 BV BND1      service_1_2_7
 BV BND1      service_1_2_8
 BV BND1      service_1_2_9
 BV BND1      service_1_2_10
 BV BND1      service_1_2_11
 BV BND1      service_1_2_12
 BV BND1      service_1_2_13
 BV BND1      service_1_2_14
 BV BND1      service_1_2_15
 BV BND1      service_2_2_1
 BV BND1      service_2_2_2
 BV BND1      service_2_2_3
 BV BND1      service_2_2_4
 BV BND1      service_2_2_5
 BV BND1      service_2_2_6
 BV BND1      service_2_2_7
 BV BND1      service_2_2_8
 BV BND1      service_2_2_9
 BV BND1      service_2_2_10
 BV BND1      service_2_2_11
 BV BND1      service_2_2_12
 BV BND1      service_2_2_13
 BV BND1      service_2_2_14
 BV BND1      service_2_2_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_0_3_17
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_1_3_17
 BV BND1      service_2_3_0
 BV BND1      service_2_3_1
 BV BND1      service_2_3_2
 BV BND1      service_2_3_3
 BV BND1      service_2_3_4
 BV BND1      service_2_3_5
 BV BND1      service_2_3_6
 BV BND1      service_2_3_7
 BV BND1      service_2_3_8
 BV BND1      service_2_3_9
 BV BND1      service_2_3_10
 BV BND1      service_2_3_11
 BV BND1      service_2_3_13
 BV BND1      service_2_3_14
 BV BND1      service_2_3_15
 BV BND1      service_2_3_16
 BV BND1      service_2_3_17
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_12
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_12
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_2_4_0
 BV BND1      service_2_4_1
 BV BND1      service_2_4_2
 BV BND1      service_2_4_3
 BV BND1      service_2_4_4
 BV BND1      service_2_4_5
 BV BND1      service_2_4_6
 BV BND1      service_2_4_7
 BV BND1      service_2_4_8
 BV BND1      service_2_4_9
 BV BND1      service_2_4_10
 BV BND1      service_2_4_12
 BV BND1      service_2_4_13
 BV BND1      service_2_4_14
 BV BND1      service_2_4_15
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_5_0
 BV BND1      service_0_5_1
 BV BND1      service_0_5_3
 BV BND1      service_0_5_4
 BV BND1      service_0_5_5
 BV BND1      service_0_5_6
 BV BND1      service_0_5_7
 BV BND1      service_0_5_8
 BV BND1      service_0_5_9
 BV BND1      service_0_5_10
 BV BND1      service_0_5_11
 BV BND1      service_0_5_12
 BV BND1      service_0_5_13
 BV BND1      service_0_5_14
 BV BND1      service_0_5_15
 BV BND1      service_0_5_16
 BV BND1      service_1_5_0
 BV BND1      service_1_5_1
 BV BND1      service_1_5_3
 BV BND1      service_1_5_4
 BV BND1      service_1_5_5
 BV BND1      service_1_5_6
 BV BND1      service_1_5_7
 BV BND1      service_1_5_8
 BV BND1      service_1_5_9
 BV BND1      service_1_5_10
 BV BND1      service_1_5_11
 BV BND1      service_1_5_12
 BV BND1      service_1_5_13
 BV BND1      service_1_5_14
 BV BND1      service_1_5_15
 BV BND1      service_1_5_16
 BV BND1      service_2_5_0
 BV BND1      service_2_5_1
 BV BND1      service_2_5_3
 BV BND1      service_2_5_4
 BV BND1      service_2_5_5
 BV BND1      service_2_5_6
 BV BND1      service_2_5_7
 BV BND1      service_2_5_8
 BV BND1      service_2_5_9
 BV BND1      service_2_5_10
 BV BND1      service_2_5_11
 BV BND1      service_2_5_12
 BV BND1      service_2_5_13
 BV BND1      service_2_5_14
 BV BND1      service_2_5_15
 BV BND1      service_2_5_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
