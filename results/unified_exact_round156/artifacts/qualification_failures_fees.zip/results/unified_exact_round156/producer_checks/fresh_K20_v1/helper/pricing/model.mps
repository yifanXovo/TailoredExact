* Signature: 0x934414d7b02ced1b
NAME 
ROWS
 N  OBJ
 E  onehot_1
 E  mass_1  
 G  w_lb_1_0
 L  w_ub_1_0
 G  w_lb_1_1
 L  w_ub_1_1
 G  w_lb_1_2
 L  w_ub_1_2
 G  w_lb_1_3
 L  w_ub_1_3
 G  w_lb_1_4
 L  w_ub_1_4
 G  w_lb_1_5
 L  w_ub_1_5
 G  w_lb_1_6
 L  w_ub_1_6
 G  w_lb_1_7
 L  w_ub_1_7
 G  w_lb_1_8
 L  w_ub_1_8
 G  w_lb_1_9
 L  w_ub_1_9
 G  w_lb_1_10
 L  w_ub_1_10
 G  w_lb_1_11
 L  w_ub_1_11
 G  w_lb_1_12
 L  w_ub_1_12
 G  w_lb_1_13
 L  w_ub_1_13
 G  w_lb_1_14
 L  w_ub_1_14
 G  w_lb_1_15
 L  w_ub_1_15
 G  w_lb_1_16
 L  w_ub_1_16
 G  w_lb_1_17
 L  w_ub_1_17
 G  w_lb_1_18
 L  w_ub_1_18
 E  normalized_inventory_1
 E  normalized_ratio_1
 E  onehot_2
 E  mass_2  
 G  w_lb_2_0
 L  w_ub_2_0
 G  w_lb_2_1
 L  w_ub_2_1
 G  w_lb_2_2
 L  w_ub_2_2
 G  w_lb_2_3
 L  w_ub_2_3
 G  w_lb_2_4
 L  w_ub_2_4
 G  w_lb_2_5
 L  w_ub_2_5
 G  w_lb_2_6
 L  w_ub_2_6
 G  w_lb_2_7
 L  w_ub_2_7
 G  w_lb_2_8
 L  w_ub_2_8
 G  w_lb_2_9
 L  w_ub_2_9
 G  w_lb_2_10
 L  w_ub_2_10
 G  w_lb_2_11
 L  w_ub_2_11
 G  w_lb_2_12
 L  w_ub_2_12
 G  w_lb_2_13
 L  w_ub_2_13
 G  w_lb_2_14
 L  w_ub_2_14
 G  w_lb_2_15
 L  w_ub_2_15
 G  w_lb_2_16
 L  w_ub_2_16
 G  w_lb_2_17
 L  w_ub_2_17
 G  w_lb_2_18
 L  w_ub_2_18
 G  w_lb_2_19
 L  w_ub_2_19
 G  w_lb_2_20
 L  w_ub_2_20
 G  w_lb_2_21
 L  w_ub_2_21
 G  w_lb_2_22
 L  w_ub_2_22
 G  w_lb_2_23
 L  w_ub_2_23
 G  w_lb_2_24
 L  w_ub_2_24
 G  w_lb_2_25
 L  w_ub_2_25
 G  w_lb_2_26
 L  w_ub_2_26
 G  w_lb_2_27
 L  w_ub_2_27
 G  w_lb_2_28
 L  w_ub_2_28
 G  w_lb_2_29
 L  w_ub_2_29
 E  normalized_inventory_2
 E  normalized_ratio_2
 E  onehot_3
 E  mass_3  
 G  w_lb_3_0
 L  w_ub_3_0
 G  w_lb_3_1
 L  w_ub_3_1
 G  w_lb_3_2
 L  w_ub_3_2
 G  w_lb_3_3
 L  w_ub_3_3
 G  w_lb_3_4
 L  w_ub_3_4
 G  w_lb_3_5
 L  w_ub_3_5
 G  w_lb_3_6
 L  w_ub_3_6
 G  w_lb_3_7
 L  w_ub_3_7
 G  w_lb_3_8
 L  w_ub_3_8
 G  w_lb_3_9
 L  w_ub_3_9
 G  w_lb_3_10
 L  w_ub_3_10
 G  w_lb_3_11
 L  w_ub_3_11
 G  w_lb_3_12
 L  w_ub_3_12
 G  w_lb_3_13
 L  w_ub_3_13
 G  w_lb_3_14
 L  w_ub_3_14
 G  w_lb_3_15
 L  w_ub_3_15
 G  w_lb_3_16
 L  w_ub_3_16
 G  w_lb_3_17
 L  w_ub_3_17
 G  w_lb_3_18
 L  w_ub_3_18
 G  w_lb_3_19
 L  w_ub_3_19
 G  w_lb_3_20
 L  w_ub_3_20
 G  w_lb_3_21
 L  w_ub_3_21
 E  normalized_inventory_3
 E  normalized_ratio_3
 E  onehot_4
 E  mass_4  
 G  w_lb_4_0
 L  w_ub_4_0
 G  w_lb_4_1
 L  w_ub_4_1
 G  w_lb_4_2
 L  w_ub_4_2
 G  w_lb_4_3
 L  w_ub_4_3
 G  w_lb_4_4
 L  w_ub_4_4
 G  w_lb_4_5
 L  w_ub_4_5
 G  w_lb_4_6
 L  w_ub_4_6
 G  w_lb_4_7
 L  w_ub_4_7
 G  w_lb_4_8
 L  w_ub_4_8
 G  w_lb_4_9
 L  w_ub_4_9
 G  w_lb_4_10
 L  w_ub_4_10
 G  w_lb_4_11
 L  w_ub_4_11
 G  w_lb_4_12
 L  w_ub_4_12
 G  w_lb_4_13
 L  w_ub_4_13
 G  w_lb_4_14
 L  w_ub_4_14
 G  w_lb_4_15
 L  w_ub_4_15
 G  w_lb_4_16
 L  w_ub_4_16
 G  w_lb_4_17
 L  w_ub_4_17
 G  w_lb_4_18
 L  w_ub_4_18
 G  w_lb_4_19
 L  w_ub_4_19
 G  w_lb_4_20
 L  w_ub_4_20
 E  normalized_inventory_4
 E  normalized_ratio_4
 E  onehot_5
 E  mass_5  
 G  w_lb_5_0
 L  w_ub_5_0
 G  w_lb_5_1
 L  w_ub_5_1
 G  w_lb_5_2
 L  w_ub_5_2
 G  w_lb_5_3
 L  w_ub_5_3
 G  w_lb_5_4
 L  w_ub_5_4
 G  w_lb_5_5
 L  w_ub_5_5
 G  w_lb_5_6
 L  w_ub_5_6
 G  w_lb_5_7
 L  w_ub_5_7
 G  w_lb_5_8
 L  w_ub_5_8
 G  w_lb_5_9
 L  w_ub_5_9
 G  w_lb_5_10
 L  w_ub_5_10
 G  w_lb_5_11
 L  w_ub_5_11
 G  w_lb_5_12
 L  w_ub_5_12
 G  w_lb_5_13
 L  w_ub_5_13
 G  w_lb_5_14
 L  w_ub_5_14
 G  w_lb_5_15
 L  w_ub_5_15
 G  w_lb_5_16
 L  w_ub_5_16
 G  w_lb_5_17
 L  w_ub_5_17
 G  w_lb_5_18
 L  w_ub_5_18
 G  w_lb_5_19
 L  w_ub_5_19
 G  w_lb_5_20
 L  w_ub_5_20
 G  w_lb_5_21
 L  w_ub_5_21
 G  w_lb_5_22
 L  w_ub_5_22
 G  w_lb_5_23
 L  w_ub_5_23
 E  normalized_inventory_5
 E  normalized_ratio_5
 E  onehot_6
 E  mass_6  
 G  w_lb_6_0
 L  w_ub_6_0
 G  w_lb_6_1
 L  w_ub_6_1
 G  w_lb_6_2
 L  w_ub_6_2
 G  w_lb_6_3
 L  w_ub_6_3
 G  w_lb_6_4
 L  w_ub_6_4
 G  w_lb_6_5
 L  w_ub_6_5
 G  w_lb_6_6
 L  w_ub_6_6
 G  w_lb_6_7
 L  w_ub_6_7
 G  w_lb_6_8
 L  w_ub_6_8
 G  w_lb_6_9
 L  w_ub_6_9
 G  w_lb_6_10
 L  w_ub_6_10
 G  w_lb_6_11
 L  w_ub_6_11
 G  w_lb_6_12
 L  w_ub_6_12
 G  w_lb_6_13
 L  w_ub_6_13
 G  w_lb_6_14
 L  w_ub_6_14
 G  w_lb_6_15
 L  w_ub_6_15
 G  w_lb_6_16
 L  w_ub_6_16
 G  w_lb_6_17
 L  w_ub_6_17
 G  w_lb_6_18
 L  w_ub_6_18
 G  w_lb_6_19
 L  w_ub_6_19
 G  w_lb_6_20
 L  w_ub_6_20
 G  w_lb_6_21
 L  w_ub_6_21
 G  w_lb_6_22
 L  w_ub_6_22
 E  normalized_inventory_6
 E  normalized_ratio_6
 E  onehot_7
 E  mass_7  
 G  w_lb_7_0
 L  w_ub_7_0
 G  w_lb_7_1
 L  w_ub_7_1
 G  w_lb_7_2
 L  w_ub_7_2
 G  w_lb_7_3
 L  w_ub_7_3
 G  w_lb_7_4
 L  w_ub_7_4
 G  w_lb_7_5
 L  w_ub_7_5
 G  w_lb_7_6
 L  w_ub_7_6
 G  w_lb_7_7
 L  w_ub_7_7
 G  w_lb_7_8
 L  w_ub_7_8
 G  w_lb_7_9
 L  w_ub_7_9
 G  w_lb_7_10
 L  w_ub_7_10
 G  w_lb_7_11
 L  w_ub_7_11
 G  w_lb_7_12
 L  w_ub_7_12
 G  w_lb_7_13
 L  w_ub_7_13
 G  w_lb_7_14
 L  w_ub_7_14
 G  w_lb_7_15
 L  w_ub_7_15
 G  w_lb_7_16
 L  w_ub_7_16
 G  w_lb_7_17
 L  w_ub_7_17
 G  w_lb_7_18
 L  w_ub_7_18
 G  w_lb_7_19
 L  w_ub_7_19
 E  normalized_inventory_7
 E  normalized_ratio_7
 E  onehot_8
 E  mass_8  
 G  w_lb_8_0
 L  w_ub_8_0
 G  w_lb_8_1
 L  w_ub_8_1
 G  w_lb_8_2
 L  w_ub_8_2
 G  w_lb_8_3
 L  w_ub_8_3
 G  w_lb_8_4
 L  w_ub_8_4
 G  w_lb_8_5
 L  w_ub_8_5
 G  w_lb_8_6
 L  w_ub_8_6
 G  w_lb_8_7
 L  w_ub_8_7
 G  w_lb_8_8
 L  w_ub_8_8
 G  w_lb_8_9
 L  w_ub_8_9
 G  w_lb_8_10
 L  w_ub_8_10
 G  w_lb_8_11
 L  w_ub_8_11
 G  w_lb_8_12
 L  w_ub_8_12
 G  w_lb_8_13
 L  w_ub_8_13
 G  w_lb_8_14
 L  w_ub_8_14
 G  w_lb_8_15
 L  w_ub_8_15
 G  w_lb_8_16
 L  w_ub_8_16
 G  w_lb_8_17
 L  w_ub_8_17
 G  w_lb_8_18
 L  w_ub_8_18
 G  w_lb_8_19
 L  w_ub_8_19
 G  w_lb_8_20
 L  w_ub_8_20
 E  normalized_inventory_8
 E  normalized_ratio_8
 E  onehot_9
 E  mass_9  
 G  w_lb_9_0
 L  w_ub_9_0
 G  w_lb_9_1
 L  w_ub_9_1
 G  w_lb_9_2
 L  w_ub_9_2
 G  w_lb_9_3
 L  w_ub_9_3
 G  w_lb_9_4
 L  w_ub_9_4
 G  w_lb_9_5
 L  w_ub_9_5
 G  w_lb_9_6
 L  w_ub_9_6
 G  w_lb_9_7
 L  w_ub_9_7
 G  w_lb_9_8
 L  w_ub_9_8
 G  w_lb_9_9
 L  w_ub_9_9
 G  w_lb_9_10
 L  w_ub_9_10
 G  w_lb_9_11
 L  w_ub_9_11
 G  w_lb_9_12
 L  w_ub_9_12
 G  w_lb_9_13
 L  w_ub_9_13
 G  w_lb_9_14
 L  w_ub_9_14
 G  w_lb_9_15
 L  w_ub_9_15
 G  w_lb_9_16
 L  w_ub_9_16
 G  w_lb_9_17
 L  w_ub_9_17
 G  w_lb_9_18
 L  w_ub_9_18
 G  w_lb_9_19
 L  w_ub_9_19
 G  w_lb_9_20
 L  w_ub_9_20
 G  w_lb_9_21
 L  w_ub_9_21
 G  w_lb_9_22
 L  w_ub_9_22
 G  w_lb_9_23
 L  w_ub_9_23
 G  w_lb_9_24
 L  w_ub_9_24
 G  w_lb_9_25
 L  w_ub_9_25
 G  w_lb_9_26
 L  w_ub_9_26
 G  w_lb_9_27
 L  w_ub_9_27
 G  w_lb_9_28
 L  w_ub_9_28
 G  w_lb_9_29
 L  w_ub_9_29
 G  w_lb_9_30
 L  w_ub_9_30
 G  w_lb_9_31
 L  w_ub_9_31
 E  normalized_inventory_9
 E  normalized_ratio_9
 E  onehot_10
 E  mass_10 
 G  w_lb_10_0
 L  w_ub_10_0
 G  w_lb_10_1
 L  w_ub_10_1
 G  w_lb_10_2
 L  w_ub_10_2
 G  w_lb_10_3
 L  w_ub_10_3
 G  w_lb_10_4
 L  w_ub_10_4
 G  w_lb_10_5
 L  w_ub_10_5
 G  w_lb_10_6
 L  w_ub_10_6
 G  w_lb_10_7
 L  w_ub_10_7
 G  w_lb_10_8
 L  w_ub_10_8
 G  w_lb_10_9
 L  w_ub_10_9
 G  w_lb_10_10
 L  w_ub_10_10
 G  w_lb_10_11
 L  w_ub_10_11
 G  w_lb_10_12
 L  w_ub_10_12
 G  w_lb_10_13
 L  w_ub_10_13
 G  w_lb_10_14
 L  w_ub_10_14
 G  w_lb_10_15
 L  w_ub_10_15
 G  w_lb_10_16
 L  w_ub_10_16
 G  w_lb_10_17
 L  w_ub_10_17
 G  w_lb_10_18
 L  w_ub_10_18
 G  w_lb_10_19
 L  w_ub_10_19
 E  normalized_inventory_10
 E  normalized_ratio_10
 E  onehot_11
 E  mass_11 
 G  w_lb_11_0
 L  w_ub_11_0
 G  w_lb_11_1
 L  w_ub_11_1
 G  w_lb_11_2
 L  w_ub_11_2
 G  w_lb_11_3
 L  w_ub_11_3
 G  w_lb_11_4
 L  w_ub_11_4
 G  w_lb_11_5
 L  w_ub_11_5
 G  w_lb_11_6
 L  w_ub_11_6
 G  w_lb_11_7
 L  w_ub_11_7
 G  w_lb_11_8
 L  w_ub_11_8
 G  w_lb_11_9
 L  w_ub_11_9
 G  w_lb_11_10
 L  w_ub_11_10
 G  w_lb_11_11
 L  w_ub_11_11
 G  w_lb_11_12
 L  w_ub_11_12
 G  w_lb_11_13
 L  w_ub_11_13
 G  w_lb_11_14
 L  w_ub_11_14
 G  w_lb_11_15
 L  w_ub_11_15
 G  w_lb_11_16
 L  w_ub_11_16
 G  w_lb_11_17
 L  w_ub_11_17
 G  w_lb_11_18
 L  w_ub_11_18
 G  w_lb_11_19
 L  w_ub_11_19
 G  w_lb_11_20
 L  w_ub_11_20
 E  normalized_inventory_11
 E  normalized_ratio_11
 E  onehot_12
 E  mass_12 
 G  w_lb_12_0
 L  w_ub_12_0
 G  w_lb_12_1
 L  w_ub_12_1
 G  w_lb_12_2
 L  w_ub_12_2
 G  w_lb_12_3
 L  w_ub_12_3
 G  w_lb_12_4
 L  w_ub_12_4
 G  w_lb_12_5
 L  w_ub_12_5
 G  w_lb_12_6
 L  w_ub_12_6
 G  w_lb_12_7
 L  w_ub_12_7
 G  w_lb_12_8
 L  w_ub_12_8
 G  w_lb_12_9
 L  w_ub_12_9
 G  w_lb_12_10
 L  w_ub_12_10
 G  w_lb_12_11
 L  w_ub_12_11
 G  w_lb_12_12
 L  w_ub_12_12
 G  w_lb_12_13
 L  w_ub_12_13
 G  w_lb_12_14
 L  w_ub_12_14
 G  w_lb_12_15
 L  w_ub_12_15
 G  w_lb_12_16
 L  w_ub_12_16
 G  w_lb_12_17
 L  w_ub_12_17
 G  w_lb_12_18
 L  w_ub_12_18
 G  w_lb_12_19
 L  w_ub_12_19
 G  w_lb_12_20
 L  w_ub_12_20
 G  w_lb_12_21
 L  w_ub_12_21
 G  w_lb_12_22
 L  w_ub_12_22
 G  w_lb_12_23
 L  w_ub_12_23
 G  w_lb_12_24
 L  w_ub_12_24
 E  normalized_inventory_12
 E  normalized_ratio_12
 E  onehot_13
 E  mass_13 
 G  w_lb_13_0
 L  w_ub_13_0
 G  w_lb_13_1
 L  w_ub_13_1
 G  w_lb_13_2
 L  w_ub_13_2
 G  w_lb_13_3
 L  w_ub_13_3
 G  w_lb_13_4
 L  w_ub_13_4
 G  w_lb_13_5
 L  w_ub_13_5
 G  w_lb_13_6
 L  w_ub_13_6
 G  w_lb_13_7
 L  w_ub_13_7
 G  w_lb_13_8
 L  w_ub_13_8
 G  w_lb_13_9
 L  w_ub_13_9
 G  w_lb_13_10
 L  w_ub_13_10
 G  w_lb_13_11
 L  w_ub_13_11
 G  w_lb_13_12
 L  w_ub_13_12
 G  w_lb_13_13
 L  w_ub_13_13
 G  w_lb_13_14
 L  w_ub_13_14
 G  w_lb_13_15
 L  w_ub_13_15
 G  w_lb_13_16
 L  w_ub_13_16
 G  w_lb_13_17
 L  w_ub_13_17
 G  w_lb_13_18
 L  w_ub_13_18
 G  w_lb_13_19
 L  w_ub_13_19
 G  w_lb_13_20
 L  w_ub_13_20
 G  w_lb_13_21
 L  w_ub_13_21
 G  w_lb_13_22
 L  w_ub_13_22
 G  w_lb_13_23
 L  w_ub_13_23
 G  w_lb_13_24
 L  w_ub_13_24
 G  w_lb_13_25
 L  w_ub_13_25
 G  w_lb_13_26
 L  w_ub_13_26
 G  w_lb_13_27
 L  w_ub_13_27
 G  w_lb_13_28
 L  w_ub_13_28
 G  w_lb_13_29
 L  w_ub_13_29
 E  normalized_inventory_13
 E  normalized_ratio_13
 E  onehot_14
 E  mass_14 
 G  w_lb_14_0
 L  w_ub_14_0
 G  w_lb_14_1
 L  w_ub_14_1
 G  w_lb_14_2
 L  w_ub_14_2
 G  w_lb_14_3
 L  w_ub_14_3
 G  w_lb_14_4
 L  w_ub_14_4
 G  w_lb_14_5
 L  w_ub_14_5
 G  w_lb_14_6
 L  w_ub_14_6
 G  w_lb_14_7
 L  w_ub_14_7
 G  w_lb_14_8
 L  w_ub_14_8
 G  w_lb_14_9
 L  w_ub_14_9
 G  w_lb_14_10
 L  w_ub_14_10
 G  w_lb_14_11
 L  w_ub_14_11
 G  w_lb_14_12
 L  w_ub_14_12
 G  w_lb_14_13
 L  w_ub_14_13
 G  w_lb_14_14
 L  w_ub_14_14
 G  w_lb_14_15
 L  w_ub_14_15
 G  w_lb_14_16
 L  w_ub_14_16
 G  w_lb_14_17
 L  w_ub_14_17
 G  w_lb_14_18
 L  w_ub_14_18
 G  w_lb_14_19
 L  w_ub_14_19
 G  w_lb_14_20
 L  w_ub_14_20
 E  normalized_inventory_14
 E  normalized_ratio_14
 E  onehot_15
 E  mass_15 
 G  w_lb_15_0
 L  w_ub_15_0
 G  w_lb_15_1
 L  w_ub_15_1
 G  w_lb_15_2
 L  w_ub_15_2
 G  w_lb_15_3
 L  w_ub_15_3
 G  w_lb_15_4
 L  w_ub_15_4
 G  w_lb_15_5
 L  w_ub_15_5
 G  w_lb_15_6
 L  w_ub_15_6
 G  w_lb_15_7
 L  w_ub_15_7
 G  w_lb_15_8
 L  w_ub_15_8
 G  w_lb_15_9
 L  w_ub_15_9
 G  w_lb_15_10
 L  w_ub_15_10
 G  w_lb_15_11
 L  w_ub_15_11
 G  w_lb_15_12
 L  w_ub_15_12
 G  w_lb_15_13
 L  w_ub_15_13
 G  w_lb_15_14
 L  w_ub_15_14
 G  w_lb_15_15
 L  w_ub_15_15
 G  w_lb_15_16
 L  w_ub_15_16
 G  w_lb_15_17
 L  w_ub_15_17
 G  w_lb_15_18
 L  w_ub_15_18
 G  w_lb_15_19
 L  w_ub_15_19
 G  w_lb_15_20
 L  w_ub_15_20
 E  normalized_inventory_15
 E  normalized_ratio_15
 E  onehot_16
 E  mass_16 
 G  w_lb_16_0
 L  w_ub_16_0
 G  w_lb_16_1
 L  w_ub_16_1
 G  w_lb_16_2
 L  w_ub_16_2
 G  w_lb_16_3
 L  w_ub_16_3
 G  w_lb_16_4
 L  w_ub_16_4
 G  w_lb_16_5
 L  w_ub_16_5
 G  w_lb_16_6
 L  w_ub_16_6
 G  w_lb_16_7
 L  w_ub_16_7
 G  w_lb_16_8
 L  w_ub_16_8
 G  w_lb_16_9
 L  w_ub_16_9
 G  w_lb_16_10
 L  w_ub_16_10
 G  w_lb_16_11
 L  w_ub_16_11
 G  w_lb_16_12
 L  w_ub_16_12
 G  w_lb_16_13
 L  w_ub_16_13
 G  w_lb_16_14
 L  w_ub_16_14
 G  w_lb_16_15
 L  w_ub_16_15
 G  w_lb_16_16
 L  w_ub_16_16
 G  w_lb_16_17
 L  w_ub_16_17
 G  w_lb_16_18
 L  w_ub_16_18
 G  w_lb_16_19
 L  w_ub_16_19
 G  w_lb_16_20
 L  w_ub_16_20
 G  w_lb_16_21
 L  w_ub_16_21
 G  w_lb_16_22
 L  w_ub_16_22
 G  w_lb_16_23
 L  w_ub_16_23
 G  w_lb_16_24
 L  w_ub_16_24
 G  w_lb_16_25
 L  w_ub_16_25
 G  w_lb_16_26
 L  w_ub_16_26
 G  w_lb_16_27
 L  w_ub_16_27
 E  normalized_inventory_16
 E  normalized_ratio_16
 E  onehot_17
 E  mass_17 
 G  w_lb_17_0
 L  w_ub_17_0
 G  w_lb_17_1
 L  w_ub_17_1
 G  w_lb_17_2
 L  w_ub_17_2
 G  w_lb_17_3
 L  w_ub_17_3
 G  w_lb_17_4
 L  w_ub_17_4
 G  w_lb_17_5
 L  w_ub_17_5
 G  w_lb_17_6
 L  w_ub_17_6
 G  w_lb_17_7
 L  w_ub_17_7
 G  w_lb_17_8
 L  w_ub_17_8
 G  w_lb_17_9
 L  w_ub_17_9
 G  w_lb_17_10
 L  w_ub_17_10
 G  w_lb_17_11
 L  w_ub_17_11
 G  w_lb_17_12
 L  w_ub_17_12
 G  w_lb_17_13
 L  w_ub_17_13
 G  w_lb_17_14
 L  w_ub_17_14
 G  w_lb_17_15
 L  w_ub_17_15
 G  w_lb_17_16
 L  w_ub_17_16
 G  w_lb_17_17
 L  w_ub_17_17
 G  w_lb_17_18
 L  w_ub_17_18
 G  w_lb_17_19
 L  w_ub_17_19
 G  w_lb_17_20
 L  w_ub_17_20
 E  normalized_inventory_17
 E  normalized_ratio_17
 E  onehot_18
 E  mass_18 
 G  w_lb_18_10
 L  w_ub_18_10
 G  w_lb_18_11
 L  w_ub_18_11
 G  w_lb_18_12
 L  w_ub_18_12
 G  w_lb_18_13
 L  w_ub_18_13
 G  w_lb_18_14
 L  w_ub_18_14
 G  w_lb_18_15
 L  w_ub_18_15
 G  w_lb_18_16
 L  w_ub_18_16
 G  w_lb_18_17
 L  w_ub_18_17
 G  w_lb_18_18
 L  w_ub_18_18
 G  w_lb_18_19
 L  w_ub_18_19
 G  w_lb_18_20
 L  w_ub_18_20
 G  w_lb_18_21
 L  w_ub_18_21
 G  w_lb_18_22
 L  w_ub_18_22
 G  w_lb_18_23
 L  w_ub_18_23
 G  w_lb_18_24
 L  w_ub_18_24
 G  w_lb_18_25
 L  w_ub_18_25
 G  w_lb_18_26
 L  w_ub_18_26
 G  w_lb_18_27
 L  w_ub_18_27
 G  w_lb_18_28
 L  w_ub_18_28
 G  w_lb_18_29
 L  w_ub_18_29
 G  w_lb_18_30
 L  w_ub_18_30
 E  normalized_inventory_18
 E  normalized_ratio_18
 E  onehot_19
 E  mass_19 
 G  w_lb_19_0
 L  w_ub_19_0
 G  w_lb_19_1
 L  w_ub_19_1
 G  w_lb_19_2
 L  w_ub_19_2
 G  w_lb_19_3
 L  w_ub_19_3
 G  w_lb_19_4
 L  w_ub_19_4
 G  w_lb_19_5
 L  w_ub_19_5
 G  w_lb_19_6
 L  w_ub_19_6
 G  w_lb_19_7
 L  w_ub_19_7
 G  w_lb_19_8
 L  w_ub_19_8
 G  w_lb_19_9
 L  w_ub_19_9
 G  w_lb_19_10
 L  w_ub_19_10
 G  w_lb_19_11
 L  w_ub_19_11
 G  w_lb_19_12
 L  w_ub_19_12
 G  w_lb_19_13
 L  w_ub_19_13
 E  normalized_inventory_19
 E  normalized_ratio_19
 E  onehot_20
 E  mass_20 
 G  w_lb_20_14
 L  w_ub_20_14
 G  w_lb_20_15
 L  w_ub_20_15
 G  w_lb_20_16
 L  w_ub_20_16
 G  w_lb_20_17
 L  w_ub_20_17
 G  w_lb_20_18
 L  w_ub_20_18
 G  w_lb_20_19
 L  w_ub_20_19
 G  w_lb_20_20
 L  w_ub_20_20
 G  w_lb_20_21
 L  w_ub_20_21
 G  w_lb_20_22
 L  w_ub_20_22
 G  w_lb_20_23
 L  w_ub_20_23
 G  w_lb_20_24
 L  w_ub_20_24
 G  w_lb_20_25
 L  w_ub_20_25
 G  w_lb_20_26
 L  w_ub_20_26
 G  w_lb_20_27
 L  w_ub_20_27
 G  w_lb_20_28
 L  w_ub_20_28
 G  w_lb_20_29
 L  w_ub_20_29
 G  w_lb_20_30
 L  w_ub_20_30
 E  normalized_inventory_20
 E  normalized_ratio_20
 G  hard_lower
 L  hard_upper
 E  normalization
 G  scaled_stock_lower
 L  scaled_stock_upper
 G  abs_p_1_2
 G  abs_m_1_2
 G  abs_p_1_3
 G  abs_m_1_3
 G  abs_p_1_4
 G  abs_m_1_4
 G  abs_p_1_5
 G  abs_m_1_5
 G  abs_p_1_6
 G  abs_m_1_6
 G  abs_p_1_7
 G  abs_m_1_7
 G  abs_p_1_8
 G  abs_m_1_8
 G  abs_p_1_9
 G  abs_m_1_9
 G  abs_p_1_10
 G  abs_m_1_10
 G  abs_p_1_11
 G  abs_m_1_11
 G  abs_p_1_12
 G  abs_m_1_12
 G  abs_p_1_13
 G  abs_m_1_13
 G  abs_p_1_14
 G  abs_m_1_14
 G  abs_p_1_15
 G  abs_m_1_15
 G  abs_p_1_16
 G  abs_m_1_16
 G  abs_p_1_17
 G  abs_m_1_17
 G  abs_p_1_18
 G  abs_m_1_18
 G  abs_p_1_19
 G  abs_m_1_19
 G  abs_p_1_20
 G  abs_m_1_20
 G  abs_p_2_3
 G  abs_m_2_3
 G  abs_p_2_4
 G  abs_m_2_4
 G  abs_p_2_5
 G  abs_m_2_5
 G  abs_p_2_6
 G  abs_m_2_6
 G  abs_p_2_7
 G  abs_m_2_7
 G  abs_p_2_8
 G  abs_m_2_8
 G  abs_p_2_9
 G  abs_m_2_9
 G  abs_p_2_10
 G  abs_m_2_10
 G  abs_p_2_11
 G  abs_m_2_11
 G  abs_p_2_12
 G  abs_m_2_12
 G  abs_p_2_13
 G  abs_m_2_13
 G  abs_p_2_14
 G  abs_m_2_14
 G  abs_p_2_15
 G  abs_m_2_15
 G  abs_p_2_16
 G  abs_m_2_16
 G  abs_p_2_17
 G  abs_m_2_17
 G  abs_p_2_18
 G  abs_m_2_18
 G  abs_p_2_19
 G  abs_m_2_19
 G  abs_p_2_20
 G  abs_m_2_20
 G  abs_p_3_4
 G  abs_m_3_4
 G  abs_p_3_5
 G  abs_m_3_5
 G  abs_p_3_6
 G  abs_m_3_6
 G  abs_p_3_7
 G  abs_m_3_7
 G  abs_p_3_8
 G  abs_m_3_8
 G  abs_p_3_9
 G  abs_m_3_9
 G  abs_p_3_10
 G  abs_m_3_10
 G  abs_p_3_11
 G  abs_m_3_11
 G  abs_p_3_12
 G  abs_m_3_12
 G  abs_p_3_13
 G  abs_m_3_13
 G  abs_p_3_14
 G  abs_m_3_14
 G  abs_p_3_15
 G  abs_m_3_15
 G  abs_p_3_16
 G  abs_m_3_16
 G  abs_p_3_17
 G  abs_m_3_17
 G  abs_p_3_18
 G  abs_m_3_18
 G  abs_p_3_19
 G  abs_m_3_19
 G  abs_p_3_20
 G  abs_m_3_20
 G  abs_p_4_5
 G  abs_m_4_5
 G  abs_p_4_6
 G  abs_m_4_6
 G  abs_p_4_7
 G  abs_m_4_7
 G  abs_p_4_8
 G  abs_m_4_8
 G  abs_p_4_9
 G  abs_m_4_9
 G  abs_p_4_10
 G  abs_m_4_10
 G  abs_p_4_11
 G  abs_m_4_11
 G  abs_p_4_12
 G  abs_m_4_12
 G  abs_p_4_13
 G  abs_m_4_13
 G  abs_p_4_14
 G  abs_m_4_14
 G  abs_p_4_15
 G  abs_m_4_15
 G  abs_p_4_16
 G  abs_m_4_16
 G  abs_p_4_17
 G  abs_m_4_17
 G  abs_p_4_18
 G  abs_m_4_18
 G  abs_p_4_19
 G  abs_m_4_19
 G  abs_p_4_20
 G  abs_m_4_20
 G  abs_p_5_6
 G  abs_m_5_6
 G  abs_p_5_7
 G  abs_m_5_7
 G  abs_p_5_8
 G  abs_m_5_8
 G  abs_p_5_9
 G  abs_m_5_9
 G  abs_p_5_10
 G  abs_m_5_10
 G  abs_p_5_11
 G  abs_m_5_11
 G  abs_p_5_12
 G  abs_m_5_12
 G  abs_p_5_13
 G  abs_m_5_13
 G  abs_p_5_14
 G  abs_m_5_14
 G  abs_p_5_15
 G  abs_m_5_15
 G  abs_p_5_16
 G  abs_m_5_16
 G  abs_p_5_17
 G  abs_m_5_17
 G  abs_p_5_18
 G  abs_m_5_18
 G  abs_p_5_19
 G  abs_m_5_19
 G  abs_p_5_20
 G  abs_m_5_20
 G  abs_p_6_7
 G  abs_m_6_7
 G  abs_p_6_8
 G  abs_m_6_8
 G  abs_p_6_9
 G  abs_m_6_9
 G  abs_p_6_10
 G  abs_m_6_10
 G  abs_p_6_11
 G  abs_m_6_11
 G  abs_p_6_12
 G  abs_m_6_12
 G  abs_p_6_13
 G  abs_m_6_13
 G  abs_p_6_14
 G  abs_m_6_14
 G  abs_p_6_15
 G  abs_m_6_15
 G  abs_p_6_16
 G  abs_m_6_16
 G  abs_p_6_17
 G  abs_m_6_17
 G  abs_p_6_18
 G  abs_m_6_18
 G  abs_p_6_19
 G  abs_m_6_19
 G  abs_p_6_20
 G  abs_m_6_20
 G  abs_p_7_8
 G  abs_m_7_8
 G  abs_p_7_9
 G  abs_m_7_9
 G  abs_p_7_10
 G  abs_m_7_10
 G  abs_p_7_11
 G  abs_m_7_11
 G  abs_p_7_12
 G  abs_m_7_12
 G  abs_p_7_13
 G  abs_m_7_13
 G  abs_p_7_14
 G  abs_m_7_14
 G  abs_p_7_15
 G  abs_m_7_15
 G  abs_p_7_16
 G  abs_m_7_16
 G  abs_p_7_17
 G  abs_m_7_17
 G  abs_p_7_18
 G  abs_m_7_18
 G  abs_p_7_19
 G  abs_m_7_19
 G  abs_p_7_20
 G  abs_m_7_20
 G  abs_p_8_9
 G  abs_m_8_9
 G  abs_p_8_10
 G  abs_m_8_10
 G  abs_p_8_11
 G  abs_m_8_11
 G  abs_p_8_12
 G  abs_m_8_12
 G  abs_p_8_13
 G  abs_m_8_13
 G  abs_p_8_14
 G  abs_m_8_14
 G  abs_p_8_15
 G  abs_m_8_15
 G  abs_p_8_16
 G  abs_m_8_16
 G  abs_p_8_17
 G  abs_m_8_17
 G  abs_p_8_18
 G  abs_m_8_18
 G  abs_p_8_19
 G  abs_m_8_19
 G  abs_p_8_20
 G  abs_m_8_20
 G  abs_p_9_10
 G  abs_m_9_10
 G  abs_p_9_11
 G  abs_m_9_11
 G  abs_p_9_12
 G  abs_m_9_12
 G  abs_p_9_13
 G  abs_m_9_13
 G  abs_p_9_14
 G  abs_m_9_14
 G  abs_p_9_15
 G  abs_m_9_15
 G  abs_p_9_16
 G  abs_m_9_16
 G  abs_p_9_17
 G  abs_m_9_17
 G  abs_p_9_18
 G  abs_m_9_18
 G  abs_p_9_19
 G  abs_m_9_19
 G  abs_p_9_20
 G  abs_m_9_20
 G  abs_p_10_11
 G  abs_m_10_11
 G  abs_p_10_12
 G  abs_m_10_12
 G  abs_p_10_13
 G  abs_m_10_13
 G  abs_p_10_14
 G  abs_m_10_14
 G  abs_p_10_15
 G  abs_m_10_15
 G  abs_p_10_16
 G  abs_m_10_16
 G  abs_p_10_17
 G  abs_m_10_17
 G  abs_p_10_18
 G  abs_m_10_18
 G  abs_p_10_19
 G  abs_m_10_19
 G  abs_p_10_20
 G  abs_m_10_20
 G  abs_p_11_12
 G  abs_m_11_12
 G  abs_p_11_13
 G  abs_m_11_13
 G  abs_p_11_14
 G  abs_m_11_14
 G  abs_p_11_15
 G  abs_m_11_15
 G  abs_p_11_16
 G  abs_m_11_16
 G  abs_p_11_17
 G  abs_m_11_17
 G  abs_p_11_18
 G  abs_m_11_18
 G  abs_p_11_19
 G  abs_m_11_19
 G  abs_p_11_20
 G  abs_m_11_20
 G  abs_p_12_13
 G  abs_m_12_13
 G  abs_p_12_14
 G  abs_m_12_14
 G  abs_p_12_15
 G  abs_m_12_15
 G  abs_p_12_16
 G  abs_m_12_16
 G  abs_p_12_17
 G  abs_m_12_17
 G  abs_p_12_18
 G  abs_m_12_18
 G  abs_p_12_19
 G  abs_m_12_19
 G  abs_p_12_20
 G  abs_m_12_20
 G  abs_p_13_14
 G  abs_m_13_14
 G  abs_p_13_15
 G  abs_m_13_15
 G  abs_p_13_16
 G  abs_m_13_16
 G  abs_p_13_17
 G  abs_m_13_17
 G  abs_p_13_18
 G  abs_m_13_18
 G  abs_p_13_19
 G  abs_m_13_19
 G  abs_p_13_20
 G  abs_m_13_20
 G  abs_p_14_15
 G  abs_m_14_15
 G  abs_p_14_16
 G  abs_m_14_16
 G  abs_p_14_17
 G  abs_m_14_17
 G  abs_p_14_18
 G  abs_m_14_18
 G  abs_p_14_19
 G  abs_m_14_19
 G  abs_p_14_20
 G  abs_m_14_20
 G  abs_p_15_16
 G  abs_m_15_16
 G  abs_p_15_17
 G  abs_m_15_17
 G  abs_p_15_18
 G  abs_m_15_18
 G  abs_p_15_19
 G  abs_m_15_19
 G  abs_p_15_20
 G  abs_m_15_20
 G  abs_p_16_17
 G  abs_m_16_17
 G  abs_p_16_18
 G  abs_m_16_18
 G  abs_p_16_19
 G  abs_m_16_19
 G  abs_p_16_20
 G  abs_m_16_20
 G  abs_p_17_18
 G  abs_m_17_18
 G  abs_p_17_19
 G  abs_m_17_19
 G  abs_p_17_20
 G  abs_m_17_20
 G  abs_p_18_19
 G  abs_m_18_19
 G  abs_p_18_20
 G  abs_m_18_20
 G  abs_p_19_20
 G  abs_m_19_20
 L  true_G_epigraph
 L  physical_G_upper
 G  old_normalized_TC
 G  old_normalized_TC2
 G  old_TS1 
 G  old_TS2 
 L  old_TS3 
 L  old_TS4 
COLUMNS
    MARKER    'MARKER'                 'INTORG'
    x[1,0]    OBJ       2.3730449999999997e-02
    x[1,0]    onehot_1  1
    x[1,0]    w_lb_1_0  -4.9025936701360941e-02
    x[1,0]    w_ub_1_0  -1.0218978102189782e-01
    x[1,1]    OBJ       1.8457016666666663e-02
    x[1,1]    onehot_1  1
    x[1,1]    w_lb_1_1  -4.9025936701360941e-02
    x[1,1]    w_ub_1_1  -1.0218978102189782e-01
    x[1,1]    hard_lower  1
    x[1,1]    hard_upper  1
    x[1,1]    old_TS1   -4.9025936701360941e-02
    x[1,1]    old_TS2   -1.0218978102189782e-01
    x[1,1]    old_TS3   -1.0218978102189782e-01
    x[1,1]    old_TS4   -4.9025936701360941e-02
    x[1,2]    OBJ       1.3183583333333332e-02
    x[1,2]    onehot_1  1
    x[1,2]    w_lb_1_2  -4.9025936701360941e-02
    x[1,2]    w_ub_1_2  -1.0218978102189782e-01
    x[1,2]    hard_lower  2
    x[1,2]    hard_upper  2
    x[1,2]    old_TS1   -9.8051873402721881e-02
    x[1,2]    old_TS2   -2.0437956204379565e-01
    x[1,2]    old_TS3   -2.0437956204379565e-01
    x[1,2]    old_TS4   -9.8051873402721881e-02
    x[1,3]    OBJ       0.00791015
    x[1,3]    onehot_1  1
    x[1,3]    w_lb_1_3  -4.9025936701360941e-02
    x[1,3]    w_ub_1_3  -1.0218978102189782e-01
    x[1,3]    hard_lower  3
    x[1,3]    hard_upper  3
    x[1,3]    old_TS1   -1.4707781010408283e-01
    x[1,3]    old_TS2   -3.0656934306569350e-01
    x[1,3]    old_TS3   -3.0656934306569350e-01
    x[1,3]    old_TS4   -1.4707781010408283e-01
    x[1,4]    OBJ       2.6367166666666662e-03
    x[1,4]    onehot_1  1
    x[1,4]    w_lb_1_4  -4.9025936701360941e-02
    x[1,4]    w_ub_1_4  -1.0218978102189782e-01
    x[1,4]    hard_lower  4
    x[1,4]    hard_upper  4
    x[1,4]    old_TS1   -1.9610374680544376e-01
    x[1,4]    old_TS2   -4.0875912408759130e-01
    x[1,4]    old_TS3   -4.0875912408759130e-01
    x[1,4]    old_TS4   -1.9610374680544376e-01
    x[1,5]    OBJ       -2.6367166666666666e-03
    x[1,5]    onehot_1  1
    x[1,5]    w_lb_1_5  -4.9025936701360941e-02
    x[1,5]    w_ub_1_5  -1.0218978102189782e-01
    x[1,5]    hard_lower  5
    x[1,5]    hard_upper  5
    x[1,5]    old_TS1   -2.4512968350680470e-01
    x[1,5]    old_TS2   -5.1094890510948909e-01
    x[1,5]    old_TS3   -5.1094890510948909e-01
    x[1,5]    old_TS4   -2.4512968350680470e-01
    x[1,6]    OBJ       -7.9101500000000012e-03
    x[1,6]    onehot_1  1
    x[1,6]    w_lb_1_6  -4.9025936701360941e-02
    x[1,6]    w_ub_1_6  -1.0218978102189782e-01
    x[1,6]    hard_lower  6
    x[1,6]    hard_upper  6
    x[1,6]    old_TS1   -2.9415562020816566e-01
    x[1,6]    old_TS2   -0.613138686131387
    x[1,6]    old_TS3   -0.613138686131387
    x[1,6]    old_TS4   -2.9415562020816566e-01
    x[1,7]    OBJ       -1.3183583333333334e-02
    x[1,7]    onehot_1  1
    x[1,7]    w_lb_1_7  -4.9025936701360941e-02
    x[1,7]    w_ub_1_7  -1.0218978102189782e-01
    x[1,7]    hard_lower  7
    x[1,7]    hard_upper  7
    x[1,7]    old_TS1   -3.4318155690952656e-01
    x[1,7]    old_TS2   -7.1532846715328480e-01
    x[1,7]    old_TS3   -7.1532846715328480e-01
    x[1,7]    old_TS4   -3.4318155690952656e-01
    x[1,8]    OBJ       -1.8457016666666666e-02
    x[1,8]    onehot_1  1
    x[1,8]    w_lb_1_8  -4.9025936701360941e-02
    x[1,8]    w_ub_1_8  -1.0218978102189782e-01
    x[1,8]    hard_lower  8
    x[1,8]    hard_upper  8
    x[1,8]    old_TS1   -3.9220749361088753e-01
    x[1,8]    old_TS2   -8.1751824817518259e-01
    x[1,8]    old_TS3   -8.1751824817518259e-01
    x[1,8]    old_TS4   -3.9220749361088753e-01
    x[1,9]    OBJ       -0.02373045
    x[1,9]    onehot_1  1
    x[1,9]    w_lb_1_9  -4.9025936701360941e-02
    x[1,9]    w_ub_1_9  -1.0218978102189782e-01
    x[1,9]    hard_lower  9
    x[1,9]    hard_upper  9
    x[1,9]    old_TS1   -4.4123343031224849e-01
    x[1,9]    old_TS2   -9.1970802919708039e-01
    x[1,9]    old_TS3   -9.1970802919708039e-01
    x[1,9]    old_TS4   -4.4123343031224849e-01
    x[1,10]   OBJ       -1.8457016666666673e-02
    x[1,10]   onehot_1  1
    x[1,10]   w_lb_1_10  -4.9025936701360941e-02
    x[1,10]   w_ub_1_10  -1.0218978102189782e-01
    x[1,10]   hard_lower  10
    x[1,10]   hard_upper  10
    x[1,10]   old_TS1   -4.9025936701360939e-01
    x[1,10]   old_TS2   -1.0218978102189782e+00
    x[1,10]   old_TS3   -1.0218978102189782e+00
    x[1,10]   old_TS4   -4.9025936701360939e-01
    x[1,11]   OBJ       -1.3183583333333339e-02
    x[1,11]   onehot_1  1
    x[1,11]   w_lb_1_11  -4.9025936701360941e-02
    x[1,11]   w_ub_1_11  -1.0218978102189782e-01
    x[1,11]   hard_lower  11
    x[1,11]   hard_upper  11
    x[1,11]   old_TS1   -5.3928530371497030e-01
    x[1,11]   old_TS2   -1.1240875912408761e+00
    x[1,11]   old_TS3   -1.1240875912408761e+00
    x[1,11]   old_TS4   -5.3928530371497030e-01
    x[1,12]   OBJ       -7.9101500000000064e-03
    x[1,12]   onehot_1  1
    x[1,12]   w_lb_1_12  -4.9025936701360941e-02
    x[1,12]   w_ub_1_12  -1.0218978102189782e-01
    x[1,12]   hard_lower  12
    x[1,12]   hard_upper  12
    x[1,12]   old_TS1   -5.8831124041633132e-01
    x[1,12]   old_TS2   -1.2262773722627740e+00
    x[1,12]   old_TS3   -1.2262773722627740e+00
    x[1,12]   old_TS4   -5.8831124041633132e-01
    x[1,13]   OBJ       -2.6367166666666718e-03
    x[1,13]   onehot_1  1
    x[1,13]   w_lb_1_13  -4.9025936701360941e-02
    x[1,13]   w_ub_1_13  -1.0218978102189782e-01
    x[1,13]   hard_lower  13
    x[1,13]   hard_upper  13
    x[1,13]   old_TS1   -6.3733717711769222e-01
    x[1,13]   old_TS2   -1.3284671532846717e+00
    x[1,13]   old_TS3   -1.3284671532846717e+00
    x[1,13]   old_TS4   -6.3733717711769222e-01
    x[1,14]   OBJ       2.6367166666666610e-03
    x[1,14]   onehot_1  1
    x[1,14]   w_lb_1_14  -4.9025936701360941e-02
    x[1,14]   w_ub_1_14  -1.0218978102189782e-01
    x[1,14]   hard_lower  14
    x[1,14]   hard_upper  14
    x[1,14]   old_TS1   -6.8636311381905313e-01
    x[1,14]   old_TS2   -1.4306569343065696e+00
    x[1,14]   old_TS3   -1.4306569343065696e+00
    x[1,14]   old_TS4   -6.8636311381905313e-01
    x[1,15]   OBJ       7.9101499999999943e-03
    x[1,15]   onehot_1  1
    x[1,15]   w_lb_1_15  -4.9025936701360941e-02
    x[1,15]   w_ub_1_15  -1.0218978102189782e-01
    x[1,15]   hard_lower  15
    x[1,15]   hard_upper  15
    x[1,15]   old_TS1   -7.3538905052041414e-01
    x[1,15]   old_TS2   -1.5328467153284673e+00
    x[1,15]   old_TS3   -1.5328467153284673e+00
    x[1,15]   old_TS4   -7.3538905052041414e-01
    x[1,16]   OBJ       1.3183583333333327e-02
    x[1,16]   onehot_1  1
    x[1,16]   w_lb_1_16  -4.9025936701360941e-02
    x[1,16]   w_ub_1_16  -1.0218978102189782e-01
    x[1,16]   hard_lower  16
    x[1,16]   hard_upper  16
    x[1,16]   old_TS1   -0.784414987221775
    x[1,16]   old_TS2   -1.6350364963503652e+00
    x[1,16]   old_TS3   -1.6350364963503652e+00
    x[1,16]   old_TS4   -0.784414987221775
    x[1,17]   OBJ       1.8457016666666659e-02
    x[1,17]   onehot_1  1
    x[1,17]   w_lb_1_17  -4.9025936701360941e-02
    x[1,17]   w_ub_1_17  -1.0218978102189782e-01
    x[1,17]   hard_lower  17
    x[1,17]   hard_upper  17
    x[1,17]   old_TS1   -0.833440923923136
    x[1,17]   old_TS2   -1.7372262773722631e+00
    x[1,17]   old_TS3   -1.7372262773722631e+00
    x[1,17]   old_TS4   -0.833440923923136
    x[1,18]   OBJ       2.3730449999999993e-02
    x[1,18]   onehot_1  1
    x[1,18]   w_lb_1_18  -4.9025936701360941e-02
    x[1,18]   w_ub_1_18  -1.0218978102189782e-01
    x[1,18]   hard_lower  18
    x[1,18]   hard_upper  18
    x[1,18]   old_TS1   -0.882466860624497
    x[1,18]   old_TS2   -1.8394160583941608e+00
    x[1,18]   old_TS3   -1.8394160583941608e+00
    x[1,18]   old_TS4   -0.882466860624497
    x[2,0]    OBJ       0.075
    x[2,0]    onehot_2  1
    x[2,0]    w_lb_2_0  -4.9025936701360941e-02
    x[2,0]    w_ub_2_0  -1.0218978102189782e-01
    x[2,1]    OBJ       6.5624999999999989e-02
    x[2,1]    onehot_2  1
    x[2,1]    w_lb_2_1  -4.9025936701360941e-02
    x[2,1]    w_ub_2_1  -1.0218978102189782e-01
    x[2,1]    hard_lower  1
    x[2,1]    hard_upper  1
    x[2,1]    old_TS1   -4.9025936701360941e-02
    x[2,1]    old_TS2   -1.0218978102189782e-01
    x[2,1]    old_TS3   -1.0218978102189782e-01
    x[2,1]    old_TS4   -4.9025936701360941e-02
    x[2,2]    OBJ       5.6249999999999994e-02
    x[2,2]    onehot_2  1
    x[2,2]    w_lb_2_2  -4.9025936701360941e-02
    x[2,2]    w_ub_2_2  -1.0218978102189782e-01
    x[2,2]    hard_lower  2
    x[2,2]    hard_upper  2
    x[2,2]    old_TS1   -9.8051873402721881e-02
    x[2,2]    old_TS2   -2.0437956204379565e-01
    x[2,2]    old_TS3   -2.0437956204379565e-01
    x[2,2]    old_TS4   -9.8051873402721881e-02
    x[2,3]    OBJ       4.6874999999999993e-02
    x[2,3]    onehot_2  1
    x[2,3]    w_lb_2_3  -4.9025936701360941e-02
    x[2,3]    w_ub_2_3  -1.0218978102189782e-01
    x[2,3]    hard_lower  3
    x[2,3]    hard_upper  3
    x[2,3]    old_TS1   -1.4707781010408283e-01
    x[2,3]    old_TS2   -3.0656934306569350e-01
    x[2,3]    old_TS3   -3.0656934306569350e-01
    x[2,3]    old_TS4   -1.4707781010408283e-01
    x[2,4]    OBJ       0.0375
    x[2,4]    onehot_2  1
    x[2,4]    w_lb_2_4  -4.9025936701360941e-02
    x[2,4]    w_ub_2_4  -1.0218978102189782e-01
    x[2,4]    hard_lower  4
    x[2,4]    hard_upper  4
    x[2,4]    old_TS1   -1.9610374680544376e-01
    x[2,4]    old_TS2   -4.0875912408759130e-01
    x[2,4]    old_TS3   -4.0875912408759130e-01
    x[2,4]    old_TS4   -1.9610374680544376e-01
    x[2,5]    OBJ       2.8124999999999997e-02
    x[2,5]    onehot_2  1
    x[2,5]    w_lb_2_5  -4.9025936701360941e-02
    x[2,5]    w_ub_2_5  -1.0218978102189782e-01
    x[2,5]    hard_lower  5
    x[2,5]    hard_upper  5
    x[2,5]    old_TS1   -2.4512968350680470e-01
    x[2,5]    old_TS2   -5.1094890510948909e-01
    x[2,5]    old_TS3   -5.1094890510948909e-01
    x[2,5]    old_TS4   -2.4512968350680470e-01
    x[2,6]    OBJ       0.01875
    x[2,6]    onehot_2  1
    x[2,6]    w_lb_2_6  -4.9025936701360941e-02
    x[2,6]    w_ub_2_6  -1.0218978102189782e-01
    x[2,6]    hard_lower  6
    x[2,6]    hard_upper  6
    x[2,6]    old_TS1   -2.9415562020816566e-01
    x[2,6]    old_TS2   -0.613138686131387
    x[2,6]    old_TS3   -0.613138686131387
    x[2,6]    old_TS4   -2.9415562020816566e-01
    x[2,7]    OBJ       0.009375
    x[2,7]    onehot_2  1
    x[2,7]    w_lb_2_7  -4.9025936701360941e-02
    x[2,7]    w_ub_2_7  -1.0218978102189782e-01
    x[2,7]    hard_lower  7
    x[2,7]    hard_upper  7
    x[2,7]    old_TS1   -3.4318155690952656e-01
    x[2,7]    old_TS2   -7.1532846715328480e-01
    x[2,7]    old_TS3   -7.1532846715328480e-01
    x[2,7]    old_TS4   -3.4318155690952656e-01
    x[2,8]    onehot_2  1
    x[2,8]    w_lb_2_8  -4.9025936701360941e-02
    x[2,8]    w_ub_2_8  -1.0218978102189782e-01
    x[2,8]    hard_lower  8
    x[2,8]    hard_upper  8
    x[2,8]    old_TS1   -3.9220749361088753e-01
    x[2,8]    old_TS2   -8.1751824817518259e-01
    x[2,8]    old_TS3   -8.1751824817518259e-01
    x[2,8]    old_TS4   -3.9220749361088753e-01
    x[2,9]    OBJ       -0.009375
    x[2,9]    onehot_2  1
    x[2,9]    w_lb_2_9  -4.9025936701360941e-02
    x[2,9]    w_ub_2_9  -1.0218978102189782e-01
    x[2,9]    hard_lower  9
    x[2,9]    hard_upper  9
    x[2,9]    old_TS1   -4.4123343031224849e-01
    x[2,9]    old_TS2   -9.1970802919708039e-01
    x[2,9]    old_TS3   -9.1970802919708039e-01
    x[2,9]    old_TS4   -4.4123343031224849e-01
    x[2,10]   OBJ       -0.01875
    x[2,10]   onehot_2  1
    x[2,10]   w_lb_2_10  -4.9025936701360941e-02
    x[2,10]   w_ub_2_10  -1.0218978102189782e-01
    x[2,10]   hard_lower  10
    x[2,10]   hard_upper  10
    x[2,10]   old_TS1   -4.9025936701360939e-01
    x[2,10]   old_TS2   -1.0218978102189782e+00
    x[2,10]   old_TS3   -1.0218978102189782e+00
    x[2,10]   old_TS4   -4.9025936701360939e-01
    x[2,11]   OBJ       -0.028125
    x[2,11]   onehot_2  1
    x[2,11]   w_lb_2_11  -4.9025936701360941e-02
    x[2,11]   w_ub_2_11  -1.0218978102189782e-01
    x[2,11]   hard_lower  11
    x[2,11]   hard_upper  11
    x[2,11]   old_TS1   -5.3928530371497030e-01
    x[2,11]   old_TS2   -1.1240875912408761e+00
    x[2,11]   old_TS3   -1.1240875912408761e+00
    x[2,11]   old_TS4   -5.3928530371497030e-01
    x[2,12]   OBJ       -0.0375
    x[2,12]   onehot_2  1
    x[2,12]   w_lb_2_12  -4.9025936701360941e-02
    x[2,12]   w_ub_2_12  -1.0218978102189782e-01
    x[2,12]   hard_lower  12
    x[2,12]   hard_upper  12
    x[2,12]   old_TS1   -5.8831124041633132e-01
    x[2,12]   old_TS2   -1.2262773722627740e+00
    x[2,12]   old_TS3   -1.2262773722627740e+00
    x[2,12]   old_TS4   -5.8831124041633132e-01
    x[2,13]   OBJ       -0.046875
    x[2,13]   onehot_2  1
    x[2,13]   w_lb_2_13  -4.9025936701360941e-02
    x[2,13]   w_ub_2_13  -1.0218978102189782e-01
    x[2,13]   hard_lower  13
    x[2,13]   hard_upper  13
    x[2,13]   old_TS1   -6.3733717711769222e-01
    x[2,13]   old_TS2   -1.3284671532846717e+00
    x[2,13]   old_TS3   -1.3284671532846717e+00
    x[2,13]   old_TS4   -6.3733717711769222e-01
    x[2,14]   OBJ       -0.05625
    x[2,14]   onehot_2  1
    x[2,14]   w_lb_2_14  -4.9025936701360941e-02
    x[2,14]   w_ub_2_14  -1.0218978102189782e-01
    x[2,14]   hard_lower  14
    x[2,14]   hard_upper  14
    x[2,14]   old_TS1   -6.8636311381905313e-01
    x[2,14]   old_TS2   -1.4306569343065696e+00
    x[2,14]   old_TS3   -1.4306569343065696e+00
    x[2,14]   old_TS4   -6.8636311381905313e-01
    x[2,15]   OBJ       -0.065625
    x[2,15]   onehot_2  1
    x[2,15]   w_lb_2_15  -4.9025936701360941e-02
    x[2,15]   w_ub_2_15  -1.0218978102189782e-01
    x[2,15]   hard_lower  15
    x[2,15]   hard_upper  15
    x[2,15]   old_TS1   -7.3538905052041414e-01
    x[2,15]   old_TS2   -1.5328467153284673e+00
    x[2,15]   old_TS3   -1.5328467153284673e+00
    x[2,15]   old_TS4   -7.3538905052041414e-01
    x[2,16]   OBJ       -0.075
    x[2,16]   onehot_2  1
    x[2,16]   w_lb_2_16  -4.9025936701360941e-02
    x[2,16]   w_ub_2_16  -1.0218978102189782e-01
    x[2,16]   hard_lower  16
    x[2,16]   hard_upper  16
    x[2,16]   old_TS1   -0.784414987221775
    x[2,16]   old_TS2   -1.6350364963503652e+00
    x[2,16]   old_TS3   -1.6350364963503652e+00
    x[2,16]   old_TS4   -0.784414987221775
    x[2,17]   OBJ       -0.065625
    x[2,17]   onehot_2  1
    x[2,17]   w_lb_2_17  -4.9025936701360941e-02
    x[2,17]   w_ub_2_17  -1.0218978102189782e-01
    x[2,17]   hard_lower  17
    x[2,17]   hard_upper  17
    x[2,17]   old_TS1   -0.833440923923136
    x[2,17]   old_TS2   -1.7372262773722631e+00
    x[2,17]   old_TS3   -1.7372262773722631e+00
    x[2,17]   old_TS4   -0.833440923923136
    x[2,18]   OBJ       -0.05625
    x[2,18]   onehot_2  1
    x[2,18]   w_lb_2_18  -4.9025936701360941e-02
    x[2,18]   w_ub_2_18  -1.0218978102189782e-01
    x[2,18]   hard_lower  18
    x[2,18]   hard_upper  18
    x[2,18]   old_TS1   -0.882466860624497
    x[2,18]   old_TS2   -1.8394160583941608e+00
    x[2,18]   old_TS3   -1.8394160583941608e+00
    x[2,18]   old_TS4   -0.882466860624497
    x[2,19]   OBJ       -0.046875
    x[2,19]   onehot_2  1
    x[2,19]   w_lb_2_19  -4.9025936701360941e-02
    x[2,19]   w_ub_2_19  -1.0218978102189782e-01
    x[2,19]   hard_lower  19
    x[2,19]   hard_upper  19
    x[2,19]   old_TS1   -9.3149279732585788e-01
    x[2,19]   old_TS2   -1.9416058394160587e+00
    x[2,19]   old_TS3   -1.9416058394160587e+00
    x[2,19]   old_TS4   -9.3149279732585788e-01
    x[2,20]   OBJ       -0.0375
    x[2,20]   onehot_2  1
    x[2,20]   w_lb_2_20  -4.9025936701360941e-02
    x[2,20]   w_ub_2_20  -1.0218978102189782e-01
    x[2,20]   hard_lower  20
    x[2,20]   hard_upper  20
    x[2,20]   old_TS1   -9.8051873402721879e-01
    x[2,20]   old_TS2   -2.0437956204379564e+00
    x[2,20]   old_TS3   -2.0437956204379564e+00
    x[2,20]   old_TS4   -9.8051873402721879e-01
    x[2,21]   OBJ       -0.028125
    x[2,21]   onehot_2  1
    x[2,21]   w_lb_2_21  -4.9025936701360941e-02
    x[2,21]   w_ub_2_21  -1.0218978102189782e-01
    x[2,21]   hard_lower  21
    x[2,21]   hard_upper  21
    x[2,21]   old_TS1   -1.0295446707285798e+00
    x[2,21]   old_TS2   -2.1459854014598543e+00
    x[2,21]   old_TS3   -2.1459854014598543e+00
    x[2,21]   old_TS4   -1.0295446707285798e+00
    x[2,22]   OBJ       -0.01875
    x[2,22]   onehot_2  1
    x[2,22]   w_lb_2_22  -4.9025936701360941e-02
    x[2,22]   w_ub_2_22  -1.0218978102189782e-01
    x[2,22]   hard_lower  22
    x[2,22]   hard_upper  22
    x[2,22]   old_TS1   -1.0785706074299406e+00
    x[2,22]   old_TS2   -2.2481751824817522e+00
    x[2,22]   old_TS3   -2.2481751824817522e+00
    x[2,22]   old_TS4   -1.0785706074299406e+00
    x[2,23]   OBJ       -0.009375
    x[2,23]   onehot_2  1
    x[2,23]   w_lb_2_23  -4.9025936701360941e-02
    x[2,23]   w_ub_2_23  -1.0218978102189782e-01
    x[2,23]   hard_lower  23
    x[2,23]   hard_upper  23
    x[2,23]   old_TS1   -1.1275965441313016e+00
    x[2,23]   old_TS2   -2.35036496350365
    x[2,23]   old_TS3   -2.35036496350365
    x[2,23]   old_TS4   -1.1275965441313016e+00
    x[2,24]   onehot_2  1
    x[2,24]   w_lb_2_24  -4.9025936701360941e-02
    x[2,24]   w_ub_2_24  -1.0218978102189782e-01
    x[2,24]   hard_lower  24
    x[2,24]   hard_upper  24
    x[2,24]   old_TS1   -1.1766224808326626e+00
    x[2,24]   old_TS2   -2.4525547445255480e+00
    x[2,24]   old_TS3   -2.4525547445255480e+00
    x[2,24]   old_TS4   -1.1766224808326626e+00
    x[2,25]   OBJ       0.009375
    x[2,25]   onehot_2  1
    x[2,25]   w_lb_2_25  -4.9025936701360941e-02
    x[2,25]   w_ub_2_25  -1.0218978102189782e-01
    x[2,25]   hard_lower  25
    x[2,25]   hard_upper  25
    x[2,25]   old_TS1   -1.2256484175340234e+00
    x[2,25]   old_TS2   -2.5547445255474455e+00
    x[2,25]   old_TS3   -2.5547445255474455e+00
    x[2,25]   old_TS4   -1.2256484175340234e+00
    x[2,26]   OBJ       0.01875
    x[2,26]   onehot_2  1
    x[2,26]   w_lb_2_26  -4.9025936701360941e-02
    x[2,26]   w_ub_2_26  -1.0218978102189782e-01
    x[2,26]   hard_lower  26
    x[2,26]   hard_upper  26
    x[2,26]   old_TS1   -1.2746743542353844e+00
    x[2,26]   old_TS2   -2.6569343065693434e+00
    x[2,26]   old_TS3   -2.6569343065693434e+00
    x[2,26]   old_TS4   -1.2746743542353844e+00
    x[2,27]   OBJ       2.8124999999999997e-02
    x[2,27]   onehot_2  1
    x[2,27]   w_lb_2_27  -4.9025936701360941e-02
    x[2,27]   w_ub_2_27  -1.0218978102189782e-01
    x[2,27]   hard_lower  27
    x[2,27]   hard_upper  27
    x[2,27]   old_TS1   -1.3237002909367455e+00
    x[2,27]   old_TS2   -2.7591240875912413e+00
    x[2,27]   old_TS3   -2.7591240875912413e+00
    x[2,27]   old_TS4   -1.3237002909367455e+00
    x[2,28]   OBJ       0.0375
    x[2,28]   onehot_2  1
    x[2,28]   w_lb_2_28  -4.9025936701360941e-02
    x[2,28]   w_ub_2_28  -1.0218978102189782e-01
    x[2,28]   hard_lower  28
    x[2,28]   hard_upper  28
    x[2,28]   old_TS1   -1.3727262276381063e+00
    x[2,28]   old_TS2   -2.8613138686131392e+00
    x[2,28]   old_TS3   -2.8613138686131392e+00
    x[2,28]   old_TS4   -1.3727262276381063e+00
    x[2,29]   OBJ       4.6874999999999993e-02
    x[2,29]   onehot_2  1
    x[2,29]   w_lb_2_29  -4.9025936701360941e-02
    x[2,29]   w_ub_2_29  -1.0218978102189782e-01
    x[2,29]   hard_lower  29
    x[2,29]   hard_upper  29
    x[2,29]   old_TS1   -1.4217521643394673e+00
    x[2,29]   old_TS2   -2.9635036496350371e+00
    x[2,29]   old_TS3   -2.9635036496350371e+00
    x[2,29]   old_TS4   -1.4217521643394673e+00
    x[3,0]    OBJ       3.5449199999999993e-02
    x[3,0]    onehot_3  1
    x[3,0]    w_lb_3_0  -4.9025936701360941e-02
    x[3,0]    w_ub_3_0  -1.0218978102189782e-01
    x[3,1]    OBJ       2.9003890909090908e-02
    x[3,1]    onehot_3  1
    x[3,1]    w_lb_3_1  -4.9025936701360941e-02
    x[3,1]    w_ub_3_1  -1.0218978102189782e-01
    x[3,1]    hard_lower  1
    x[3,1]    hard_upper  1
    x[3,1]    old_TS1   -4.9025936701360941e-02
    x[3,1]    old_TS2   -1.0218978102189782e-01
    x[3,1]    old_TS3   -1.0218978102189782e-01
    x[3,1]    old_TS4   -4.9025936701360941e-02
    x[3,2]    OBJ       2.2558581818181815e-02
    x[3,2]    onehot_3  1
    x[3,2]    w_lb_3_2  -4.9025936701360941e-02
    x[3,2]    w_ub_3_2  -1.0218978102189782e-01
    x[3,2]    hard_lower  2
    x[3,2]    hard_upper  2
    x[3,2]    old_TS1   -9.8051873402721881e-02
    x[3,2]    old_TS2   -2.0437956204379565e-01
    x[3,2]    old_TS3   -2.0437956204379565e-01
    x[3,2]    old_TS4   -9.8051873402721881e-02
    x[3,3]    OBJ       1.6113272727272723e-02
    x[3,3]    onehot_3  1
    x[3,3]    w_lb_3_3  -4.9025936701360941e-02
    x[3,3]    w_ub_3_3  -1.0218978102189782e-01
    x[3,3]    hard_lower  3
    x[3,3]    hard_upper  3
    x[3,3]    old_TS1   -1.4707781010408283e-01
    x[3,3]    old_TS2   -3.0656934306569350e-01
    x[3,3]    old_TS3   -3.0656934306569350e-01
    x[3,3]    old_TS4   -1.4707781010408283e-01
    x[3,4]    OBJ       9.6679636363636336e-03
    x[3,4]    onehot_3  1
    x[3,4]    w_lb_3_4  -4.9025936701360941e-02
    x[3,4]    w_ub_3_4  -1.0218978102189782e-01
    x[3,4]    hard_lower  4
    x[3,4]    hard_upper  4
    x[3,4]    old_TS1   -1.9610374680544376e-01
    x[3,4]    old_TS2   -4.0875912408759130e-01
    x[3,4]    old_TS3   -4.0875912408759130e-01
    x[3,4]    old_TS4   -1.9610374680544376e-01
    x[3,5]    OBJ       3.2226545454545432e-03
    x[3,5]    onehot_3  1
    x[3,5]    w_lb_3_5  -4.9025936701360941e-02
    x[3,5]    w_ub_3_5  -1.0218978102189782e-01
    x[3,5]    hard_lower  5
    x[3,5]    hard_upper  5
    x[3,5]    old_TS1   -2.4512968350680470e-01
    x[3,5]    old_TS2   -5.1094890510948909e-01
    x[3,5]    old_TS3   -5.1094890510948909e-01
    x[3,5]    old_TS4   -2.4512968350680470e-01
    x[3,6]    OBJ       -3.2226545454545476e-03
    x[3,6]    onehot_3  1
    x[3,6]    w_lb_3_6  -4.9025936701360941e-02
    x[3,6]    w_ub_3_6  -1.0218978102189782e-01
    x[3,6]    hard_lower  6
    x[3,6]    hard_upper  6
    x[3,6]    old_TS1   -2.9415562020816566e-01
    x[3,6]    old_TS2   -0.613138686131387
    x[3,6]    old_TS3   -0.613138686131387
    x[3,6]    old_TS4   -2.9415562020816566e-01
    x[3,7]    OBJ       -9.6679636363636388e-03
    x[3,7]    onehot_3  1
    x[3,7]    w_lb_3_7  -4.9025936701360941e-02
    x[3,7]    w_ub_3_7  -1.0218978102189782e-01
    x[3,7]    hard_lower  7
    x[3,7]    hard_upper  7
    x[3,7]    old_TS1   -3.4318155690952656e-01
    x[3,7]    old_TS2   -7.1532846715328480e-01
    x[3,7]    old_TS3   -7.1532846715328480e-01
    x[3,7]    old_TS4   -3.4318155690952656e-01
    x[3,8]    OBJ       -1.6113272727272733e-02
    x[3,8]    onehot_3  1
    x[3,8]    w_lb_3_8  -4.9025936701360941e-02
    x[3,8]    w_ub_3_8  -1.0218978102189782e-01
    x[3,8]    hard_lower  8
    x[3,8]    hard_upper  8
    x[3,8]    old_TS1   -3.9220749361088753e-01
    x[3,8]    old_TS2   -8.1751824817518259e-01
    x[3,8]    old_TS3   -8.1751824817518259e-01
    x[3,8]    old_TS4   -3.9220749361088753e-01
    x[3,9]    OBJ       -2.2558581818181822e-02
    x[3,9]    onehot_3  1
    x[3,9]    w_lb_3_9  -4.9025936701360941e-02
    x[3,9]    w_ub_3_9  -1.0218978102189782e-01
    x[3,9]    hard_lower  9
    x[3,9]    hard_upper  9
    x[3,9]    old_TS1   -4.4123343031224849e-01
    x[3,9]    old_TS2   -9.1970802919708039e-01
    x[3,9]    old_TS3   -9.1970802919708039e-01
    x[3,9]    old_TS4   -4.4123343031224849e-01
    x[3,10]   OBJ       -2.9003890909090915e-02
    x[3,10]   onehot_3  1
    x[3,10]   w_lb_3_10  -4.9025936701360941e-02
    x[3,10]   w_ub_3_10  -1.0218978102189782e-01
    x[3,10]   hard_lower  10
    x[3,10]   hard_upper  10
    x[3,10]   old_TS1   -4.9025936701360939e-01
    x[3,10]   old_TS2   -1.0218978102189782e+00
    x[3,10]   old_TS3   -1.0218978102189782e+00
    x[3,10]   old_TS4   -4.9025936701360939e-01
    x[3,11]   OBJ       -0.0354492
    x[3,11]   onehot_3  1
    x[3,11]   w_lb_3_11  -4.9025936701360941e-02
    x[3,11]   w_ub_3_11  -1.0218978102189782e-01
    x[3,11]   hard_lower  11
    x[3,11]   hard_upper  11
    x[3,11]   old_TS1   -5.3928530371497030e-01
    x[3,11]   old_TS2   -1.1240875912408761e+00
    x[3,11]   old_TS3   -1.1240875912408761e+00
    x[3,11]   old_TS4   -5.3928530371497030e-01
    x[3,12]   OBJ       -2.9003890909090911e-02
    x[3,12]   onehot_3  1
    x[3,12]   w_lb_3_12  -4.9025936701360941e-02
    x[3,12]   w_ub_3_12  -1.0218978102189782e-01
    x[3,12]   hard_lower  12
    x[3,12]   hard_upper  12
    x[3,12]   old_TS1   -5.8831124041633132e-01
    x[3,12]   old_TS2   -1.2262773722627740e+00
    x[3,12]   old_TS3   -1.2262773722627740e+00
    x[3,12]   old_TS4   -5.8831124041633132e-01
    x[3,13]   OBJ       -2.2558581818181819e-02
    x[3,13]   onehot_3  1
    x[3,13]   w_lb_3_13  -4.9025936701360941e-02
    x[3,13]   w_ub_3_13  -1.0218978102189782e-01
    x[3,13]   hard_lower  13
    x[3,13]   hard_upper  13
    x[3,13]   old_TS1   -6.3733717711769222e-01
    x[3,13]   old_TS2   -1.3284671532846717e+00
    x[3,13]   old_TS3   -1.3284671532846717e+00
    x[3,13]   old_TS4   -6.3733717711769222e-01
    x[3,14]   OBJ       -1.6113272727272726e-02
    x[3,14]   onehot_3  1
    x[3,14]   w_lb_3_14  -4.9025936701360941e-02
    x[3,14]   w_ub_3_14  -1.0218978102189782e-01
    x[3,14]   hard_lower  14
    x[3,14]   hard_upper  14
    x[3,14]   old_TS1   -6.8636311381905313e-01
    x[3,14]   old_TS2   -1.4306569343065696e+00
    x[3,14]   old_TS3   -1.4306569343065696e+00
    x[3,14]   old_TS4   -6.8636311381905313e-01
    x[3,15]   OBJ       -9.6679636363636353e-03
    x[3,15]   onehot_3  1
    x[3,15]   w_lb_3_15  -4.9025936701360941e-02
    x[3,15]   w_ub_3_15  -1.0218978102189782e-01
    x[3,15]   hard_lower  15
    x[3,15]   hard_upper  15
    x[3,15]   old_TS1   -7.3538905052041414e-01
    x[3,15]   old_TS2   -1.5328467153284673e+00
    x[3,15]   old_TS3   -1.5328467153284673e+00
    x[3,15]   old_TS4   -7.3538905052041414e-01
    x[3,16]   OBJ       -3.2226545454545437e-03
    x[3,16]   onehot_3  1
    x[3,16]   w_lb_3_16  -4.9025936701360941e-02
    x[3,16]   w_ub_3_16  -1.0218978102189782e-01
    x[3,16]   hard_lower  16
    x[3,16]   hard_upper  16
    x[3,16]   old_TS1   -0.784414987221775
    x[3,16]   old_TS2   -1.6350364963503652e+00
    x[3,16]   old_TS3   -1.6350364963503652e+00
    x[3,16]   old_TS4   -0.784414987221775
    x[3,17]   OBJ       3.2226545454545471e-03
    x[3,17]   onehot_3  1
    x[3,17]   w_lb_3_17  -4.9025936701360941e-02
    x[3,17]   w_ub_3_17  -1.0218978102189782e-01
    x[3,17]   hard_lower  17
    x[3,17]   hard_upper  17
    x[3,17]   old_TS1   -0.833440923923136
    x[3,17]   old_TS2   -1.7372262773722631e+00
    x[3,17]   old_TS3   -1.7372262773722631e+00
    x[3,17]   old_TS4   -0.833440923923136
    x[3,18]   OBJ       9.6679636363636370e-03
    x[3,18]   onehot_3  1
    x[3,18]   w_lb_3_18  -4.9025936701360941e-02
    x[3,18]   w_ub_3_18  -1.0218978102189782e-01
    x[3,18]   hard_lower  18
    x[3,18]   hard_upper  18
    x[3,18]   old_TS1   -0.882466860624497
    x[3,18]   old_TS2   -1.8394160583941608e+00
    x[3,18]   old_TS3   -1.8394160583941608e+00
    x[3,18]   old_TS4   -0.882466860624497
    x[3,19]   OBJ       1.6113272727272730e-02
    x[3,19]   onehot_3  1
    x[3,19]   w_lb_3_19  -4.9025936701360941e-02
    x[3,19]   w_ub_3_19  -1.0218978102189782e-01
    x[3,19]   hard_lower  19
    x[3,19]   hard_upper  19
    x[3,19]   old_TS1   -9.3149279732585788e-01
    x[3,19]   old_TS2   -1.9416058394160587e+00
    x[3,19]   old_TS3   -1.9416058394160587e+00
    x[3,19]   old_TS4   -9.3149279732585788e-01
    x[3,20]   OBJ       2.2558581818181819e-02
    x[3,20]   onehot_3  1
    x[3,20]   w_lb_3_20  -4.9025936701360941e-02
    x[3,20]   w_ub_3_20  -1.0218978102189782e-01
    x[3,20]   hard_lower  20
    x[3,20]   hard_upper  20
    x[3,20]   old_TS1   -9.8051873402721879e-01
    x[3,20]   old_TS2   -2.0437956204379564e+00
    x[3,20]   old_TS3   -2.0437956204379564e+00
    x[3,20]   old_TS4   -9.8051873402721879e-01
    x[3,21]   OBJ       2.9003890909090911e-02
    x[3,21]   onehot_3  1
    x[3,21]   w_lb_3_21  -4.9025936701360941e-02
    x[3,21]   w_ub_3_21  -1.0218978102189782e-01
    x[3,21]   hard_lower  21
    x[3,21]   hard_upper  21
    x[3,21]   old_TS1   -1.0295446707285798e+00
    x[3,21]   old_TS2   -2.1459854014598543e+00
    x[3,21]   old_TS3   -2.1459854014598543e+00
    x[3,21]   old_TS4   -1.0295446707285798e+00
    x[4,0]    OBJ       2.9296874999999993e-02
    x[4,0]    onehot_4  1
    x[4,0]    w_lb_4_0  -4.9025936701360941e-02
    x[4,0]    w_ub_4_0  -1.0218978102189782e-01
    x[4,1]    OBJ       2.3437499999999993e-02
    x[4,1]    onehot_4  1
    x[4,1]    w_lb_4_1  -4.9025936701360941e-02
    x[4,1]    w_ub_4_1  -1.0218978102189782e-01
    x[4,1]    hard_lower  1
    x[4,1]    hard_upper  1
    x[4,1]    old_TS1   -4.9025936701360941e-02
    x[4,1]    old_TS2   -1.0218978102189782e-01
    x[4,1]    old_TS3   -1.0218978102189782e-01
    x[4,1]    old_TS4   -4.9025936701360941e-02
    x[4,2]    OBJ       1.7578124999999993e-02
    x[4,2]    onehot_4  1
    x[4,2]    w_lb_4_2  -4.9025936701360941e-02
    x[4,2]    w_ub_4_2  -1.0218978102189782e-01
    x[4,2]    hard_lower  2
    x[4,2]    hard_upper  2
    x[4,2]    old_TS1   -9.8051873402721881e-02
    x[4,2]    old_TS2   -2.0437956204379565e-01
    x[4,2]    old_TS3   -2.0437956204379565e-01
    x[4,2]    old_TS4   -9.8051873402721881e-02
    x[4,3]    OBJ       1.1718749999999993e-02
    x[4,3]    onehot_4  1
    x[4,3]    w_lb_4_3  -4.9025936701360941e-02
    x[4,3]    w_ub_4_3  -1.0218978102189782e-01
    x[4,3]    hard_lower  3
    x[4,3]    hard_upper  3
    x[4,3]    old_TS1   -1.4707781010408283e-01
    x[4,3]    old_TS2   -3.0656934306569350e-01
    x[4,3]    old_TS3   -3.0656934306569350e-01
    x[4,3]    old_TS4   -1.4707781010408283e-01
    x[4,4]    OBJ       5.8593749999999931e-03
    x[4,4]    onehot_4  1
    x[4,4]    w_lb_4_4  -4.9025936701360941e-02
    x[4,4]    w_ub_4_4  -1.0218978102189782e-01
    x[4,4]    hard_lower  4
    x[4,4]    hard_upper  4
    x[4,4]    old_TS1   -1.9610374680544376e-01
    x[4,4]    old_TS2   -4.0875912408759130e-01
    x[4,4]    old_TS3   -4.0875912408759130e-01
    x[4,4]    old_TS4   -1.9610374680544376e-01
    x[4,5]    OBJ       -6.5052130349130266e-18
    x[4,5]    onehot_4  1
    x[4,5]    w_lb_4_5  -4.9025936701360941e-02
    x[4,5]    w_ub_4_5  -1.0218978102189782e-01
    x[4,5]    hard_lower  5
    x[4,5]    hard_upper  5
    x[4,5]    old_TS1   -2.4512968350680470e-01
    x[4,5]    old_TS2   -5.1094890510948909e-01
    x[4,5]    old_TS3   -5.1094890510948909e-01
    x[4,5]    old_TS4   -2.4512968350680470e-01
    x[4,6]    OBJ       -5.8593750000000069e-03
    x[4,6]    onehot_4  1
    x[4,6]    w_lb_4_6  -4.9025936701360941e-02
    x[4,6]    w_ub_4_6  -1.0218978102189782e-01
    x[4,6]    hard_lower  6
    x[4,6]    hard_upper  6
    x[4,6]    old_TS1   -2.9415562020816566e-01
    x[4,6]    old_TS2   -0.613138686131387
    x[4,6]    old_TS3   -0.613138686131387
    x[4,6]    old_TS4   -2.9415562020816566e-01
    x[4,7]    OBJ       -1.1718750000000009e-02
    x[4,7]    onehot_4  1
    x[4,7]    w_lb_4_7  -4.9025936701360941e-02
    x[4,7]    w_ub_4_7  -1.0218978102189782e-01
    x[4,7]    hard_lower  7
    x[4,7]    hard_upper  7
    x[4,7]    old_TS1   -3.4318155690952656e-01
    x[4,7]    old_TS2   -7.1532846715328480e-01
    x[4,7]    old_TS3   -7.1532846715328480e-01
    x[4,7]    old_TS4   -3.4318155690952656e-01
    x[4,8]    OBJ       -1.7578125000000010e-02
    x[4,8]    onehot_4  1
    x[4,8]    w_lb_4_8  -4.9025936701360941e-02
    x[4,8]    w_ub_4_8  -1.0218978102189782e-01
    x[4,8]    hard_lower  8
    x[4,8]    hard_upper  8
    x[4,8]    old_TS1   -3.9220749361088753e-01
    x[4,8]    old_TS2   -8.1751824817518259e-01
    x[4,8]    old_TS3   -8.1751824817518259e-01
    x[4,8]    old_TS4   -3.9220749361088753e-01
    x[4,9]    OBJ       -2.3437500000000010e-02
    x[4,9]    onehot_4  1
    x[4,9]    w_lb_4_9  -4.9025936701360941e-02
    x[4,9]    w_ub_4_9  -1.0218978102189782e-01
    x[4,9]    hard_lower  9
    x[4,9]    hard_upper  9
    x[4,9]    old_TS1   -4.4123343031224849e-01
    x[4,9]    old_TS2   -9.1970802919708039e-01
    x[4,9]    old_TS3   -9.1970802919708039e-01
    x[4,9]    old_TS4   -4.4123343031224849e-01
    x[4,10]   OBJ       -2.9296875000000003e-02
    x[4,10]   onehot_4  1
    x[4,10]   w_lb_4_10  -4.9025936701360941e-02
    x[4,10]   w_ub_4_10  -1.0218978102189782e-01
    x[4,10]   hard_lower  10
    x[4,10]   hard_upper  10
    x[4,10]   old_TS1   -4.9025936701360939e-01
    x[4,10]   old_TS2   -1.0218978102189782e+00
    x[4,10]   old_TS3   -1.0218978102189782e+00
    x[4,10]   old_TS4   -4.9025936701360939e-01
    x[4,11]   OBJ       -2.3437500000000003e-02
    x[4,11]   onehot_4  1
    x[4,11]   w_lb_4_11  -4.9025936701360941e-02
    x[4,11]   w_ub_4_11  -1.0218978102189782e-01
    x[4,11]   hard_lower  11
    x[4,11]   hard_upper  11
    x[4,11]   old_TS1   -5.3928530371497030e-01
    x[4,11]   old_TS2   -1.1240875912408761e+00
    x[4,11]   old_TS3   -1.1240875912408761e+00
    x[4,11]   old_TS4   -5.3928530371497030e-01
    x[4,12]   OBJ       -1.7578125000000003e-02
    x[4,12]   onehot_4  1
    x[4,12]   w_lb_4_12  -4.9025936701360941e-02
    x[4,12]   w_ub_4_12  -1.0218978102189782e-01
    x[4,12]   hard_lower  12
    x[4,12]   hard_upper  12
    x[4,12]   old_TS1   -5.8831124041633132e-01
    x[4,12]   old_TS2   -1.2262773722627740e+00
    x[4,12]   old_TS3   -1.2262773722627740e+00
    x[4,12]   old_TS4   -5.8831124041633132e-01
    x[4,13]   OBJ       -1.1718750000000002e-02
    x[4,13]   onehot_4  1
    x[4,13]   w_lb_4_13  -4.9025936701360941e-02
    x[4,13]   w_ub_4_13  -1.0218978102189782e-01
    x[4,13]   hard_lower  13
    x[4,13]   hard_upper  13
    x[4,13]   old_TS1   -6.3733717711769222e-01
    x[4,13]   old_TS2   -1.3284671532846717e+00
    x[4,13]   old_TS3   -1.3284671532846717e+00
    x[4,13]   old_TS4   -6.3733717711769222e-01
    x[4,14]   OBJ       -5.8593750000000009e-03
    x[4,14]   onehot_4  1
    x[4,14]   w_lb_4_14  -4.9025936701360941e-02
    x[4,14]   w_ub_4_14  -1.0218978102189782e-01
    x[4,14]   hard_lower  14
    x[4,14]   hard_upper  14
    x[4,14]   old_TS1   -6.8636311381905313e-01
    x[4,14]   old_TS2   -1.4306569343065696e+00
    x[4,14]   old_TS3   -1.4306569343065696e+00
    x[4,14]   old_TS4   -6.8636311381905313e-01
    x[4,15]   onehot_4  1
    x[4,15]   w_lb_4_15  -4.9025936701360941e-02
    x[4,15]   w_ub_4_15  -1.0218978102189782e-01
    x[4,15]   hard_lower  15
    x[4,15]   hard_upper  15
    x[4,15]   old_TS1   -7.3538905052041414e-01
    x[4,15]   old_TS2   -1.5328467153284673e+00
    x[4,15]   old_TS3   -1.5328467153284673e+00
    x[4,15]   old_TS4   -7.3538905052041414e-01
    x[4,16]   OBJ       0.005859375
    x[4,16]   onehot_4  1
    x[4,16]   w_lb_4_16  -4.9025936701360941e-02
    x[4,16]   w_ub_4_16  -1.0218978102189782e-01
    x[4,16]   hard_lower  16
    x[4,16]   hard_upper  16
    x[4,16]   old_TS1   -0.784414987221775
    x[4,16]   old_TS2   -1.6350364963503652e+00
    x[4,16]   old_TS3   -1.6350364963503652e+00
    x[4,16]   old_TS4   -0.784414987221775
    x[4,17]   OBJ       0.01171875
    x[4,17]   onehot_4  1
    x[4,17]   w_lb_4_17  -4.9025936701360941e-02
    x[4,17]   w_ub_4_17  -1.0218978102189782e-01
    x[4,17]   hard_lower  17
    x[4,17]   hard_upper  17
    x[4,17]   old_TS1   -0.833440923923136
    x[4,17]   old_TS2   -1.7372262773722631e+00
    x[4,17]   old_TS3   -1.7372262773722631e+00
    x[4,17]   old_TS4   -0.833440923923136
    x[4,18]   OBJ       0.017578125
    x[4,18]   onehot_4  1
    x[4,18]   w_lb_4_18  -4.9025936701360941e-02
    x[4,18]   w_ub_4_18  -1.0218978102189782e-01
    x[4,18]   hard_lower  18
    x[4,18]   hard_upper  18
    x[4,18]   old_TS1   -0.882466860624497
    x[4,18]   old_TS2   -1.8394160583941608e+00
    x[4,18]   old_TS3   -1.8394160583941608e+00
    x[4,18]   old_TS4   -0.882466860624497
    x[4,19]   OBJ       0.0234375
    x[4,19]   onehot_4  1
    x[4,19]   w_lb_4_19  -4.9025936701360941e-02
    x[4,19]   w_ub_4_19  -1.0218978102189782e-01
    x[4,19]   hard_lower  19
    x[4,19]   hard_upper  19
    x[4,19]   old_TS1   -9.3149279732585788e-01
    x[4,19]   old_TS2   -1.9416058394160587e+00
    x[4,19]   old_TS3   -1.9416058394160587e+00
    x[4,19]   old_TS4   -9.3149279732585788e-01
    x[4,20]   OBJ       0.029296875
    x[4,20]   onehot_4  1
    x[4,20]   w_lb_4_20  -4.9025936701360941e-02
    x[4,20]   w_ub_4_20  -1.0218978102189782e-01
    x[4,20]   hard_lower  20
    x[4,20]   hard_upper  20
    x[4,20]   old_TS1   -9.8051873402721879e-01
    x[4,20]   old_TS2   -2.0437956204379564e+00
    x[4,20]   old_TS3   -2.0437956204379564e+00
    x[4,20]   old_TS4   -9.8051873402721879e-01
    x[5,0]    OBJ       4.2187499999999989e-02
    x[5,0]    onehot_5  1
    x[5,0]    w_lb_5_0  -4.9025936701360941e-02
    x[5,0]    w_ub_5_0  -1.0218978102189782e-01
    x[5,1]    OBJ       3.5156249999999993e-02
    x[5,1]    onehot_5  1
    x[5,1]    w_lb_5_1  -4.9025936701360941e-02
    x[5,1]    w_ub_5_1  -1.0218978102189782e-01
    x[5,1]    hard_lower  1
    x[5,1]    hard_upper  1
    x[5,1]    old_TS1   -4.9025936701360941e-02
    x[5,1]    old_TS2   -1.0218978102189782e-01
    x[5,1]    old_TS3   -1.0218978102189782e-01
    x[5,1]    old_TS4   -4.9025936701360941e-02
    x[5,2]    OBJ       2.8124999999999994e-02
    x[5,2]    onehot_5  1
    x[5,2]    w_lb_5_2  -4.9025936701360941e-02
    x[5,2]    w_ub_5_2  -1.0218978102189782e-01
    x[5,2]    hard_lower  2
    x[5,2]    hard_upper  2
    x[5,2]    old_TS1   -9.8051873402721881e-02
    x[5,2]    old_TS2   -2.0437956204379565e-01
    x[5,2]    old_TS3   -2.0437956204379565e-01
    x[5,2]    old_TS4   -9.8051873402721881e-02
    x[5,3]    OBJ       2.1093749999999994e-02
    x[5,3]    onehot_5  1
    x[5,3]    w_lb_5_3  -4.9025936701360941e-02
    x[5,3]    w_ub_5_3  -1.0218978102189782e-01
    x[5,3]    hard_lower  3
    x[5,3]    hard_upper  3
    x[5,3]    old_TS1   -1.4707781010408283e-01
    x[5,3]    old_TS2   -3.0656934306569350e-01
    x[5,3]    old_TS3   -3.0656934306569350e-01
    x[5,3]    old_TS4   -1.4707781010408283e-01
    x[5,4]    OBJ       1.4062499999999997e-02
    x[5,4]    onehot_5  1
    x[5,4]    w_lb_5_4  -4.9025936701360941e-02
    x[5,4]    w_ub_5_4  -1.0218978102189782e-01
    x[5,4]    hard_lower  4
    x[5,4]    hard_upper  4
    x[5,4]    old_TS1   -1.9610374680544376e-01
    x[5,4]    old_TS2   -4.0875912408759130e-01
    x[5,4]    old_TS3   -4.0875912408759130e-01
    x[5,4]    old_TS4   -1.9610374680544376e-01
    x[5,5]    OBJ       7.0312499999999984e-03
    x[5,5]    onehot_5  1
    x[5,5]    w_lb_5_5  -4.9025936701360941e-02
    x[5,5]    w_ub_5_5  -1.0218978102189782e-01
    x[5,5]    hard_lower  5
    x[5,5]    hard_upper  5
    x[5,5]    old_TS1   -2.4512968350680470e-01
    x[5,5]    old_TS2   -5.1094890510948909e-01
    x[5,5]    old_TS3   -5.1094890510948909e-01
    x[5,5]    old_TS4   -2.4512968350680470e-01
    x[5,6]    onehot_5  1
    x[5,6]    w_lb_5_6  -4.9025936701360941e-02
    x[5,6]    w_ub_5_6  -1.0218978102189782e-01
    x[5,6]    hard_lower  6
    x[5,6]    hard_upper  6
    x[5,6]    old_TS1   -2.9415562020816566e-01
    x[5,6]    old_TS2   -0.613138686131387
    x[5,6]    old_TS3   -0.613138686131387
    x[5,6]    old_TS4   -2.9415562020816566e-01
    x[5,7]    OBJ       -7.0312499999999993e-03
    x[5,7]    onehot_5  1
    x[5,7]    w_lb_5_7  -4.9025936701360941e-02
    x[5,7]    w_ub_5_7  -1.0218978102189782e-01
    x[5,7]    hard_lower  7
    x[5,7]    hard_upper  7
    x[5,7]    old_TS1   -3.4318155690952656e-01
    x[5,7]    old_TS2   -7.1532846715328480e-01
    x[5,7]    old_TS3   -7.1532846715328480e-01
    x[5,7]    old_TS4   -3.4318155690952656e-01
    x[5,8]    OBJ       -1.4062499999999999e-02
    x[5,8]    onehot_5  1
    x[5,8]    w_lb_5_8  -4.9025936701360941e-02
    x[5,8]    w_ub_5_8  -1.0218978102189782e-01
    x[5,8]    hard_lower  8
    x[5,8]    hard_upper  8
    x[5,8]    old_TS1   -3.9220749361088753e-01
    x[5,8]    old_TS2   -8.1751824817518259e-01
    x[5,8]    old_TS3   -8.1751824817518259e-01
    x[5,8]    old_TS4   -3.9220749361088753e-01
    x[5,9]    OBJ       -2.1093749999999998e-02
    x[5,9]    onehot_5  1
    x[5,9]    w_lb_5_9  -4.9025936701360941e-02
    x[5,9]    w_ub_5_9  -1.0218978102189782e-01
    x[5,9]    hard_lower  9
    x[5,9]    hard_upper  9
    x[5,9]    old_TS1   -4.4123343031224849e-01
    x[5,9]    old_TS2   -9.1970802919708039e-01
    x[5,9]    old_TS3   -9.1970802919708039e-01
    x[5,9]    old_TS4   -4.4123343031224849e-01
    x[5,10]   OBJ       -2.8124999999999997e-02
    x[5,10]   onehot_5  1
    x[5,10]   w_lb_5_10  -4.9025936701360941e-02
    x[5,10]   w_ub_5_10  -1.0218978102189782e-01
    x[5,10]   hard_lower  10
    x[5,10]   hard_upper  10
    x[5,10]   old_TS1   -4.9025936701360939e-01
    x[5,10]   old_TS2   -1.0218978102189782e+00
    x[5,10]   old_TS3   -1.0218978102189782e+00
    x[5,10]   old_TS4   -4.9025936701360939e-01
    x[5,11]   OBJ       -0.03515625
    x[5,11]   onehot_5  1
    x[5,11]   w_lb_5_11  -4.9025936701360941e-02
    x[5,11]   w_ub_5_11  -1.0218978102189782e-01
    x[5,11]   hard_lower  11
    x[5,11]   hard_upper  11
    x[5,11]   old_TS1   -5.3928530371497030e-01
    x[5,11]   old_TS2   -1.1240875912408761e+00
    x[5,11]   old_TS3   -1.1240875912408761e+00
    x[5,11]   old_TS4   -5.3928530371497030e-01
    x[5,12]   OBJ       -4.2187499999999996e-02
    x[5,12]   onehot_5  1
    x[5,12]   w_lb_5_12  -4.9025936701360941e-02
    x[5,12]   w_ub_5_12  -1.0218978102189782e-01
    x[5,12]   hard_lower  12
    x[5,12]   hard_upper  12
    x[5,12]   old_TS1   -5.8831124041633132e-01
    x[5,12]   old_TS2   -1.2262773722627740e+00
    x[5,12]   old_TS3   -1.2262773722627740e+00
    x[5,12]   old_TS4   -5.8831124041633132e-01
    x[5,13]   OBJ       -3.5156250000000007e-02
    x[5,13]   onehot_5  1
    x[5,13]   w_lb_5_13  -4.9025936701360941e-02
    x[5,13]   w_ub_5_13  -1.0218978102189782e-01
    x[5,13]   hard_lower  13
    x[5,13]   hard_upper  13
    x[5,13]   old_TS1   -6.3733717711769222e-01
    x[5,13]   old_TS2   -1.3284671532846717e+00
    x[5,13]   old_TS3   -1.3284671532846717e+00
    x[5,13]   old_TS4   -6.3733717711769222e-01
    x[5,14]   OBJ       -2.8125000000000008e-02
    x[5,14]   onehot_5  1
    x[5,14]   w_lb_5_14  -4.9025936701360941e-02
    x[5,14]   w_ub_5_14  -1.0218978102189782e-01
    x[5,14]   hard_lower  14
    x[5,14]   hard_upper  14
    x[5,14]   old_TS1   -6.8636311381905313e-01
    x[5,14]   old_TS2   -1.4306569343065696e+00
    x[5,14]   old_TS3   -1.4306569343065696e+00
    x[5,14]   old_TS4   -6.8636311381905313e-01
    x[5,15]   OBJ       -2.1093750000000008e-02
    x[5,15]   onehot_5  1
    x[5,15]   w_lb_5_15  -4.9025936701360941e-02
    x[5,15]   w_ub_5_15  -1.0218978102189782e-01
    x[5,15]   hard_lower  15
    x[5,15]   hard_upper  15
    x[5,15]   old_TS1   -7.3538905052041414e-01
    x[5,15]   old_TS2   -1.5328467153284673e+00
    x[5,15]   old_TS3   -1.5328467153284673e+00
    x[5,15]   old_TS4   -7.3538905052041414e-01
    x[5,16]   OBJ       -1.4062500000000007e-02
    x[5,16]   onehot_5  1
    x[5,16]   w_lb_5_16  -4.9025936701360941e-02
    x[5,16]   w_ub_5_16  -1.0218978102189782e-01
    x[5,16]   hard_lower  16
    x[5,16]   hard_upper  16
    x[5,16]   old_TS1   -0.784414987221775
    x[5,16]   old_TS2   -1.6350364963503652e+00
    x[5,16]   old_TS3   -1.6350364963503652e+00
    x[5,16]   old_TS4   -0.784414987221775
    x[5,17]   OBJ       -7.0312500000000088e-03
    x[5,17]   onehot_5  1
    x[5,17]   w_lb_5_17  -4.9025936701360941e-02
    x[5,17]   w_ub_5_17  -1.0218978102189782e-01
    x[5,17]   hard_lower  17
    x[5,17]   hard_upper  17
    x[5,17]   old_TS1   -0.833440923923136
    x[5,17]   old_TS2   -1.7372262773722631e+00
    x[5,17]   old_TS3   -1.7372262773722631e+00
    x[5,17]   old_TS4   -0.833440923923136
    x[5,18]   OBJ       -9.3675067702747574e-18
    x[5,18]   onehot_5  1
    x[5,18]   w_lb_5_18  -4.9025936701360941e-02
    x[5,18]   w_ub_5_18  -1.0218978102189782e-01
    x[5,18]   hard_lower  18
    x[5,18]   hard_upper  18
    x[5,18]   old_TS1   -0.882466860624497
    x[5,18]   old_TS2   -1.8394160583941608e+00
    x[5,18]   old_TS3   -1.8394160583941608e+00
    x[5,18]   old_TS4   -0.882466860624497
    x[5,19]   OBJ       7.0312499999999889e-03
    x[5,19]   onehot_5  1
    x[5,19]   w_lb_5_19  -4.9025936701360941e-02
    x[5,19]   w_ub_5_19  -1.0218978102189782e-01
    x[5,19]   hard_lower  19
    x[5,19]   hard_upper  19
    x[5,19]   old_TS1   -9.3149279732585788e-01
    x[5,19]   old_TS2   -1.9416058394160587e+00
    x[5,19]   old_TS3   -1.9416058394160587e+00
    x[5,19]   old_TS4   -9.3149279732585788e-01
    x[5,20]   OBJ       1.4062499999999988e-02
    x[5,20]   onehot_5  1
    x[5,20]   w_lb_5_20  -4.9025936701360941e-02
    x[5,20]   w_ub_5_20  -1.0218978102189782e-01
    x[5,20]   hard_lower  20
    x[5,20]   hard_upper  20
    x[5,20]   old_TS1   -9.8051873402721879e-01
    x[5,20]   old_TS2   -2.0437956204379564e+00
    x[5,20]   old_TS3   -2.0437956204379564e+00
    x[5,20]   old_TS4   -9.8051873402721879e-01
    x[5,21]   OBJ       2.1093749999999984e-02
    x[5,21]   onehot_5  1
    x[5,21]   w_lb_5_21  -4.9025936701360941e-02
    x[5,21]   w_ub_5_21  -1.0218978102189782e-01
    x[5,21]   hard_lower  21
    x[5,21]   hard_upper  21
    x[5,21]   old_TS1   -1.0295446707285798e+00
    x[5,21]   old_TS2   -2.1459854014598543e+00
    x[5,21]   old_TS3   -2.1459854014598543e+00
    x[5,21]   old_TS4   -1.0295446707285798e+00
    x[5,22]   OBJ       2.8124999999999983e-02
    x[5,22]   onehot_5  1
    x[5,22]   w_lb_5_22  -4.9025936701360941e-02
    x[5,22]   w_ub_5_22  -1.0218978102189782e-01
    x[5,22]   hard_lower  22
    x[5,22]   hard_upper  22
    x[5,22]   old_TS1   -1.0785706074299406e+00
    x[5,22]   old_TS2   -2.2481751824817522e+00
    x[5,22]   old_TS3   -2.2481751824817522e+00
    x[5,22]   old_TS4   -1.0785706074299406e+00
    x[5,23]   OBJ       3.5156249999999979e-02
    x[5,23]   onehot_5  1
    x[5,23]   w_lb_5_23  -4.9025936701360941e-02
    x[5,23]   w_ub_5_23  -1.0218978102189782e-01
    x[5,23]   hard_lower  23
    x[5,23]   hard_upper  23
    x[5,23]   old_TS1   -1.1275965441313016e+00
    x[5,23]   old_TS2   -2.35036496350365
    x[5,23]   old_TS3   -2.35036496350365
    x[5,23]   old_TS4   -1.1275965441313016e+00
    x[6,0]    OBJ       3.5449199999999993e-02
    x[6,0]    onehot_6  1
    x[6,0]    w_lb_6_0  -4.9025936701360941e-02
    x[6,0]    w_ub_6_0  -1.0218978102189782e-01
    x[6,1]    OBJ       2.9003890909090904e-02
    x[6,1]    onehot_6  1
    x[6,1]    w_lb_6_1  -4.9025936701360941e-02
    x[6,1]    w_ub_6_1  -1.0218978102189782e-01
    x[6,1]    hard_lower  1
    x[6,1]    hard_upper  1
    x[6,1]    old_TS1   -4.9025936701360941e-02
    x[6,1]    old_TS2   -1.0218978102189782e-01
    x[6,1]    old_TS3   -1.0218978102189782e-01
    x[6,1]    old_TS4   -4.9025936701360941e-02
    x[6,2]    OBJ       2.2558581818181812e-02
    x[6,2]    onehot_6  1
    x[6,2]    w_lb_6_2  -4.9025936701360941e-02
    x[6,2]    w_ub_6_2  -1.0218978102189782e-01
    x[6,2]    hard_lower  2
    x[6,2]    hard_upper  2
    x[6,2]    old_TS1   -9.8051873402721881e-02
    x[6,2]    old_TS2   -2.0437956204379565e-01
    x[6,2]    old_TS3   -2.0437956204379565e-01
    x[6,2]    old_TS4   -9.8051873402721881e-02
    x[6,3]    OBJ       1.6113272727272723e-02
    x[6,3]    onehot_6  1
    x[6,3]    w_lb_6_3  -4.9025936701360941e-02
    x[6,3]    w_ub_6_3  -1.0218978102189782e-01
    x[6,3]    hard_lower  3
    x[6,3]    hard_upper  3
    x[6,3]    old_TS1   -1.4707781010408283e-01
    x[6,3]    old_TS2   -3.0656934306569350e-01
    x[6,3]    old_TS3   -3.0656934306569350e-01
    x[6,3]    old_TS4   -1.4707781010408283e-01
    x[6,4]    OBJ       9.6679636363636318e-03
    x[6,4]    onehot_6  1
    x[6,4]    w_lb_6_4  -4.9025936701360941e-02
    x[6,4]    w_ub_6_4  -1.0218978102189782e-01
    x[6,4]    hard_lower  4
    x[6,4]    hard_upper  4
    x[6,4]    old_TS1   -1.9610374680544376e-01
    x[6,4]    old_TS2   -4.0875912408759130e-01
    x[6,4]    old_TS3   -4.0875912408759130e-01
    x[6,4]    old_TS4   -1.9610374680544376e-01
    x[6,5]    OBJ       3.2226545454545415e-03
    x[6,5]    onehot_6  1
    x[6,5]    w_lb_6_5  -4.9025936701360941e-02
    x[6,5]    w_ub_6_5  -1.0218978102189782e-01
    x[6,5]    hard_lower  5
    x[6,5]    hard_upper  5
    x[6,5]    old_TS1   -2.4512968350680470e-01
    x[6,5]    old_TS2   -5.1094890510948909e-01
    x[6,5]    old_TS3   -5.1094890510948909e-01
    x[6,5]    old_TS4   -2.4512968350680470e-01
    x[6,6]    OBJ       -3.2226545454545497e-03
    x[6,6]    onehot_6  1
    x[6,6]    w_lb_6_6  -4.9025936701360941e-02
    x[6,6]    w_ub_6_6  -1.0218978102189782e-01
    x[6,6]    hard_lower  6
    x[6,6]    hard_upper  6
    x[6,6]    old_TS1   -2.9415562020816566e-01
    x[6,6]    old_TS2   -0.613138686131387
    x[6,6]    old_TS3   -0.613138686131387
    x[6,6]    old_TS4   -2.9415562020816566e-01
    x[6,7]    OBJ       -9.6679636363636422e-03
    x[6,7]    onehot_6  1
    x[6,7]    w_lb_6_7  -4.9025936701360941e-02
    x[6,7]    w_ub_6_7  -1.0218978102189782e-01
    x[6,7]    hard_lower  7
    x[6,7]    hard_upper  7
    x[6,7]    old_TS1   -3.4318155690952656e-01
    x[6,7]    old_TS2   -7.1532846715328480e-01
    x[6,7]    old_TS3   -7.1532846715328480e-01
    x[6,7]    old_TS4   -3.4318155690952656e-01
    x[6,8]    OBJ       -1.6113272727272733e-02
    x[6,8]    onehot_6  1
    x[6,8]    w_lb_6_8  -4.9025936701360941e-02
    x[6,8]    w_ub_6_8  -1.0218978102189782e-01
    x[6,8]    hard_lower  8
    x[6,8]    hard_upper  8
    x[6,8]    old_TS1   -3.9220749361088753e-01
    x[6,8]    old_TS2   -8.1751824817518259e-01
    x[6,8]    old_TS3   -8.1751824817518259e-01
    x[6,8]    old_TS4   -3.9220749361088753e-01
    x[6,9]    OBJ       -2.2558581818181826e-02
    x[6,9]    onehot_6  1
    x[6,9]    w_lb_6_9  -4.9025936701360941e-02
    x[6,9]    w_ub_6_9  -1.0218978102189782e-01
    x[6,9]    hard_lower  9
    x[6,9]    hard_upper  9
    x[6,9]    old_TS1   -4.4123343031224849e-01
    x[6,9]    old_TS2   -9.1970802919708039e-01
    x[6,9]    old_TS3   -9.1970802919708039e-01
    x[6,9]    old_TS4   -4.4123343031224849e-01
    x[6,10]   OBJ       -2.9003890909090915e-02
    x[6,10]   onehot_6  1
    x[6,10]   w_lb_6_10  -4.9025936701360941e-02
    x[6,10]   w_ub_6_10  -1.0218978102189782e-01
    x[6,10]   hard_lower  10
    x[6,10]   hard_upper  10
    x[6,10]   old_TS1   -4.9025936701360939e-01
    x[6,10]   old_TS2   -1.0218978102189782e+00
    x[6,10]   old_TS3   -1.0218978102189782e+00
    x[6,10]   old_TS4   -4.9025936701360939e-01
    x[6,11]   OBJ       -3.5449200000000007e-02
    x[6,11]   onehot_6  1
    x[6,11]   w_lb_6_11  -4.9025936701360941e-02
    x[6,11]   w_ub_6_11  -1.0218978102189782e-01
    x[6,11]   hard_lower  11
    x[6,11]   hard_upper  11
    x[6,11]   old_TS1   -5.3928530371497030e-01
    x[6,11]   old_TS2   -1.1240875912408761e+00
    x[6,11]   old_TS3   -1.1240875912408761e+00
    x[6,11]   old_TS4   -5.3928530371497030e-01
    x[6,12]   OBJ       -2.9003890909090911e-02
    x[6,12]   onehot_6  1
    x[6,12]   w_lb_6_12  -4.9025936701360941e-02
    x[6,12]   w_ub_6_12  -1.0218978102189782e-01
    x[6,12]   hard_lower  12
    x[6,12]   hard_upper  12
    x[6,12]   old_TS1   -5.8831124041633132e-01
    x[6,12]   old_TS2   -1.2262773722627740e+00
    x[6,12]   old_TS3   -1.2262773722627740e+00
    x[6,12]   old_TS4   -5.8831124041633132e-01
    x[6,13]   OBJ       -2.2558581818181822e-02
    x[6,13]   onehot_6  1
    x[6,13]   w_lb_6_13  -4.9025936701360941e-02
    x[6,13]   w_ub_6_13  -1.0218978102189782e-01
    x[6,13]   hard_lower  13
    x[6,13]   hard_upper  13
    x[6,13]   old_TS1   -6.3733717711769222e-01
    x[6,13]   old_TS2   -1.3284671532846717e+00
    x[6,13]   old_TS3   -1.3284671532846717e+00
    x[6,13]   old_TS4   -6.3733717711769222e-01
    x[6,14]   OBJ       -1.6113272727272730e-02
    x[6,14]   onehot_6  1
    x[6,14]   w_lb_6_14  -4.9025936701360941e-02
    x[6,14]   w_ub_6_14  -1.0218978102189782e-01
    x[6,14]   hard_lower  14
    x[6,14]   hard_upper  14
    x[6,14]   old_TS1   -6.8636311381905313e-01
    x[6,14]   old_TS2   -1.4306569343065696e+00
    x[6,14]   old_TS3   -1.4306569343065696e+00
    x[6,14]   old_TS4   -6.8636311381905313e-01
    x[6,15]   OBJ       -9.6679636363636370e-03
    x[6,15]   onehot_6  1
    x[6,15]   w_lb_6_15  -4.9025936701360941e-02
    x[6,15]   w_ub_6_15  -1.0218978102189782e-01
    x[6,15]   hard_lower  15
    x[6,15]   hard_upper  15
    x[6,15]   old_TS1   -7.3538905052041414e-01
    x[6,15]   old_TS2   -1.5328467153284673e+00
    x[6,15]   old_TS3   -1.5328467153284673e+00
    x[6,15]   old_TS4   -7.3538905052041414e-01
    x[6,16]   OBJ       -3.2226545454545458e-03
    x[6,16]   onehot_6  1
    x[6,16]   w_lb_6_16  -4.9025936701360941e-02
    x[6,16]   w_ub_6_16  -1.0218978102189782e-01
    x[6,16]   hard_lower  16
    x[6,16]   hard_upper  16
    x[6,16]   old_TS1   -0.784414987221775
    x[6,16]   old_TS2   -1.6350364963503652e+00
    x[6,16]   old_TS3   -1.6350364963503652e+00
    x[6,16]   old_TS4   -0.784414987221775
    x[6,17]   OBJ       3.2226545454545454e-03
    x[6,17]   onehot_6  1
    x[6,17]   w_lb_6_17  -4.9025936701360941e-02
    x[6,17]   w_ub_6_17  -1.0218978102189782e-01
    x[6,17]   hard_lower  17
    x[6,17]   hard_upper  17
    x[6,17]   old_TS1   -0.833440923923136
    x[6,17]   old_TS2   -1.7372262773722631e+00
    x[6,17]   old_TS3   -1.7372262773722631e+00
    x[6,17]   old_TS4   -0.833440923923136
    x[6,18]   OBJ       9.6679636363636353e-03
    x[6,18]   onehot_6  1
    x[6,18]   w_lb_6_18  -4.9025936701360941e-02
    x[6,18]   w_ub_6_18  -1.0218978102189782e-01
    x[6,18]   hard_lower  18
    x[6,18]   hard_upper  18
    x[6,18]   old_TS1   -0.882466860624497
    x[6,18]   old_TS2   -1.8394160583941608e+00
    x[6,18]   old_TS3   -1.8394160583941608e+00
    x[6,18]   old_TS4   -0.882466860624497
    x[6,19]   OBJ       1.6113272727272726e-02
    x[6,19]   onehot_6  1
    x[6,19]   w_lb_6_19  -4.9025936701360941e-02
    x[6,19]   w_ub_6_19  -1.0218978102189782e-01
    x[6,19]   hard_lower  19
    x[6,19]   hard_upper  19
    x[6,19]   old_TS1   -9.3149279732585788e-01
    x[6,19]   old_TS2   -1.9416058394160587e+00
    x[6,19]   old_TS3   -1.9416058394160587e+00
    x[6,19]   old_TS4   -9.3149279732585788e-01
    x[6,20]   OBJ       2.2558581818181819e-02
    x[6,20]   onehot_6  1
    x[6,20]   w_lb_6_20  -4.9025936701360941e-02
    x[6,20]   w_ub_6_20  -1.0218978102189782e-01
    x[6,20]   hard_lower  20
    x[6,20]   hard_upper  20
    x[6,20]   old_TS1   -9.8051873402721879e-01
    x[6,20]   old_TS2   -2.0437956204379564e+00
    x[6,20]   old_TS3   -2.0437956204379564e+00
    x[6,20]   old_TS4   -9.8051873402721879e-01
    x[6,21]   OBJ       2.9003890909090908e-02
    x[6,21]   onehot_6  1
    x[6,21]   w_lb_6_21  -4.9025936701360941e-02
    x[6,21]   w_ub_6_21  -1.0218978102189782e-01
    x[6,21]   hard_lower  21
    x[6,21]   hard_upper  21
    x[6,21]   old_TS1   -1.0295446707285798e+00
    x[6,21]   old_TS2   -2.1459854014598543e+00
    x[6,21]   old_TS3   -2.1459854014598543e+00
    x[6,21]   old_TS4   -1.0295446707285798e+00
    x[6,22]   OBJ       0.0354492
    x[6,22]   onehot_6  1
    x[6,22]   w_lb_6_22  -4.9025936701360941e-02
    x[6,22]   w_ub_6_22  -1.0218978102189782e-01
    x[6,22]   hard_lower  22
    x[6,22]   hard_upper  22
    x[6,22]   old_TS1   -1.0785706074299406e+00
    x[6,22]   old_TS2   -2.2481751824817522e+00
    x[6,22]   old_TS3   -2.2481751824817522e+00
    x[6,22]   old_TS4   -1.0785706074299406e+00
    x[7,0]    OBJ       2.1093733333333333e-02
    x[7,0]    onehot_7  1
    x[7,0]    w_lb_7_0  -4.9025936701360941e-02
    x[7,0]    w_ub_7_0  -1.0218978102189782e-01
    x[7,1]    OBJ       0.0158203
    x[7,1]    onehot_7  1
    x[7,1]    w_lb_7_1  -4.9025936701360941e-02
    x[7,1]    w_ub_7_1  -1.0218978102189782e-01
    x[7,1]    hard_lower  1
    x[7,1]    hard_upper  1
    x[7,1]    old_TS1   -4.9025936701360941e-02
    x[7,1]    old_TS2   -1.0218978102189782e-01
    x[7,1]    old_TS3   -1.0218978102189782e-01
    x[7,1]    old_TS4   -4.9025936701360941e-02
    x[7,2]    OBJ       1.0546866666666668e-02
    x[7,2]    onehot_7  1
    x[7,2]    w_lb_7_2  -4.9025936701360941e-02
    x[7,2]    w_ub_7_2  -1.0218978102189782e-01
    x[7,2]    hard_lower  2
    x[7,2]    hard_upper  2
    x[7,2]    old_TS1   -9.8051873402721881e-02
    x[7,2]    old_TS2   -2.0437956204379565e-01
    x[7,2]    old_TS3   -2.0437956204379565e-01
    x[7,2]    old_TS4   -9.8051873402721881e-02
    x[7,3]    OBJ       5.2734333333333350e-03
    x[7,3]    onehot_7  1
    x[7,3]    w_lb_7_3  -4.9025936701360941e-02
    x[7,3]    w_ub_7_3  -1.0218978102189782e-01
    x[7,3]    hard_lower  3
    x[7,3]    hard_upper  3
    x[7,3]    old_TS1   -1.4707781010408283e-01
    x[7,3]    old_TS2   -3.0656934306569350e-01
    x[7,3]    old_TS3   -3.0656934306569350e-01
    x[7,3]    old_TS4   -1.4707781010408283e-01
    x[7,4]    OBJ       2.6346091974716046e-18
    x[7,4]    onehot_7  1
    x[7,4]    w_lb_7_4  -4.9025936701360941e-02
    x[7,4]    w_ub_7_4  -1.0218978102189782e-01
    x[7,4]    hard_lower  4
    x[7,4]    hard_upper  4
    x[7,4]    old_TS1   -1.9610374680544376e-01
    x[7,4]    old_TS2   -4.0875912408759130e-01
    x[7,4]    old_TS3   -4.0875912408759130e-01
    x[7,4]    old_TS4   -1.9610374680544376e-01
    x[7,5]    OBJ       -5.2734333333333307e-03
    x[7,5]    onehot_7  1
    x[7,5]    w_lb_7_5  -4.9025936701360941e-02
    x[7,5]    w_ub_7_5  -1.0218978102189782e-01
    x[7,5]    hard_lower  5
    x[7,5]    hard_upper  5
    x[7,5]    old_TS1   -2.4512968350680470e-01
    x[7,5]    old_TS2   -5.1094890510948909e-01
    x[7,5]    old_TS3   -5.1094890510948909e-01
    x[7,5]    old_TS4   -2.4512968350680470e-01
    x[7,6]    OBJ       -1.0546866666666665e-02
    x[7,6]    onehot_7  1
    x[7,6]    w_lb_7_6  -4.9025936701360941e-02
    x[7,6]    w_ub_7_6  -1.0218978102189782e-01
    x[7,6]    hard_lower  6
    x[7,6]    hard_upper  6
    x[7,6]    old_TS1   -2.9415562020816566e-01
    x[7,6]    old_TS2   -0.613138686131387
    x[7,6]    old_TS3   -0.613138686131387
    x[7,6]    old_TS4   -2.9415562020816566e-01
    x[7,7]    OBJ       -0.0158203
    x[7,7]    onehot_7  1
    x[7,7]    w_lb_7_7  -4.9025936701360941e-02
    x[7,7]    w_ub_7_7  -1.0218978102189782e-01
    x[7,7]    hard_lower  7
    x[7,7]    hard_upper  7
    x[7,7]    old_TS1   -3.4318155690952656e-01
    x[7,7]    old_TS2   -7.1532846715328480e-01
    x[7,7]    old_TS3   -7.1532846715328480e-01
    x[7,7]    old_TS4   -3.4318155690952656e-01
    x[7,8]    OBJ       -2.1093733333333333e-02
    x[7,8]    onehot_7  1
    x[7,8]    w_lb_7_8  -4.9025936701360941e-02
    x[7,8]    w_ub_7_8  -1.0218978102189782e-01
    x[7,8]    hard_lower  8
    x[7,8]    hard_upper  8
    x[7,8]    old_TS1   -3.9220749361088753e-01
    x[7,8]    old_TS2   -8.1751824817518259e-01
    x[7,8]    old_TS3   -8.1751824817518259e-01
    x[7,8]    old_TS4   -3.9220749361088753e-01
    x[7,9]    OBJ       -2.6367166666666664e-02
    x[7,9]    onehot_7  1
    x[7,9]    w_lb_7_9  -4.9025936701360941e-02
    x[7,9]    w_ub_7_9  -1.0218978102189782e-01
    x[7,9]    hard_lower  9
    x[7,9]    hard_upper  9
    x[7,9]    old_TS1   -4.4123343031224849e-01
    x[7,9]    old_TS2   -9.1970802919708039e-01
    x[7,9]    old_TS3   -9.1970802919708039e-01
    x[7,9]    old_TS4   -4.4123343031224849e-01
    x[7,10]   OBJ       -2.1093733333333337e-02
    x[7,10]   onehot_7  1
    x[7,10]   w_lb_7_10  -4.9025936701360941e-02
    x[7,10]   w_ub_7_10  -1.0218978102189782e-01
    x[7,10]   hard_lower  10
    x[7,10]   hard_upper  10
    x[7,10]   old_TS1   -4.9025936701360939e-01
    x[7,10]   old_TS2   -1.0218978102189782e+00
    x[7,10]   old_TS3   -1.0218978102189782e+00
    x[7,10]   old_TS4   -4.9025936701360939e-01
    x[7,11]   OBJ       -1.5820300000000002e-02
    x[7,11]   onehot_7  1
    x[7,11]   w_lb_7_11  -4.9025936701360941e-02
    x[7,11]   w_ub_7_11  -1.0218978102189782e-01
    x[7,11]   hard_lower  11
    x[7,11]   hard_upper  11
    x[7,11]   old_TS1   -5.3928530371497030e-01
    x[7,11]   old_TS2   -1.1240875912408761e+00
    x[7,11]   old_TS3   -1.1240875912408761e+00
    x[7,11]   old_TS4   -5.3928530371497030e-01
    x[7,12]   OBJ       -1.0546866666666670e-02
    x[7,12]   onehot_7  1
    x[7,12]   w_lb_7_12  -4.9025936701360941e-02
    x[7,12]   w_ub_7_12  -1.0218978102189782e-01
    x[7,12]   hard_lower  12
    x[7,12]   hard_upper  12
    x[7,12]   old_TS1   -5.8831124041633132e-01
    x[7,12]   old_TS2   -1.2262773722627740e+00
    x[7,12]   old_TS3   -1.2262773722627740e+00
    x[7,12]   old_TS4   -5.8831124041633132e-01
    x[7,13]   OBJ       -5.2734333333333359e-03
    x[7,13]   onehot_7  1
    x[7,13]   w_lb_7_13  -4.9025936701360941e-02
    x[7,13]   w_ub_7_13  -1.0218978102189782e-01
    x[7,13]   hard_lower  13
    x[7,13]   hard_upper  13
    x[7,13]   old_TS1   -6.3733717711769222e-01
    x[7,13]   old_TS2   -1.3284671532846717e+00
    x[7,13]   old_TS3   -1.3284671532846717e+00
    x[7,13]   old_TS4   -6.3733717711769222e-01
    x[7,14]   OBJ       -2.6346091974716046e-18
    x[7,14]   onehot_7  1
    x[7,14]   w_lb_7_14  -4.9025936701360941e-02
    x[7,14]   w_ub_7_14  -1.0218978102189782e-01
    x[7,14]   hard_lower  14
    x[7,14]   hard_upper  14
    x[7,14]   old_TS1   -6.8636311381905313e-01
    x[7,14]   old_TS2   -1.4306569343065696e+00
    x[7,14]   old_TS3   -1.4306569343065696e+00
    x[7,14]   old_TS4   -6.8636311381905313e-01
    x[7,15]   OBJ       0.00527343333333333
    x[7,15]   onehot_7  1
    x[7,15]   w_lb_7_15  -4.9025936701360941e-02
    x[7,15]   w_ub_7_15  -1.0218978102189782e-01
    x[7,15]   hard_lower  15
    x[7,15]   hard_upper  15
    x[7,15]   old_TS1   -7.3538905052041414e-01
    x[7,15]   old_TS2   -1.5328467153284673e+00
    x[7,15]   old_TS3   -1.5328467153284673e+00
    x[7,15]   old_TS4   -7.3538905052041414e-01
    x[7,16]   OBJ       1.0546866666666663e-02
    x[7,16]   onehot_7  1
    x[7,16]   w_lb_7_16  -4.9025936701360941e-02
    x[7,16]   w_ub_7_16  -1.0218978102189782e-01
    x[7,16]   hard_lower  16
    x[7,16]   hard_upper  16
    x[7,16]   old_TS1   -0.784414987221775
    x[7,16]   old_TS2   -1.6350364963503652e+00
    x[7,16]   old_TS3   -1.6350364963503652e+00
    x[7,16]   old_TS4   -0.784414987221775
    x[7,17]   OBJ       1.5820299999999995e-02
    x[7,17]   onehot_7  1
    x[7,17]   w_lb_7_17  -4.9025936701360941e-02
    x[7,17]   w_ub_7_17  -1.0218978102189782e-01
    x[7,17]   hard_lower  17
    x[7,17]   hard_upper  17
    x[7,17]   old_TS1   -0.833440923923136
    x[7,17]   old_TS2   -1.7372262773722631e+00
    x[7,17]   old_TS3   -1.7372262773722631e+00
    x[7,17]   old_TS4   -0.833440923923136
    x[7,18]   OBJ       2.1093733333333330e-02
    x[7,18]   onehot_7  1
    x[7,18]   w_lb_7_18  -4.9025936701360941e-02
    x[7,18]   w_ub_7_18  -1.0218978102189782e-01
    x[7,18]   hard_lower  18
    x[7,18]   hard_upper  18
    x[7,18]   old_TS1   -0.882466860624497
    x[7,18]   old_TS2   -1.8394160583941608e+00
    x[7,18]   old_TS3   -1.8394160583941608e+00
    x[7,18]   old_TS4   -0.882466860624497
    x[7,19]   OBJ       2.6367166666666660e-02
    x[7,19]   onehot_7  1
    x[7,19]   w_lb_7_19  -4.9025936701360941e-02
    x[7,19]   w_ub_7_19  -1.0218978102189782e-01
    x[7,19]   hard_lower  19
    x[7,19]   hard_upper  19
    x[7,19]   old_TS1   -9.3149279732585788e-01
    x[7,19]   old_TS2   -1.9416058394160587e+00
    x[7,19]   old_TS3   -1.9416058394160587e+00
    x[7,19]   old_TS4   -9.3149279732585788e-01
    x[8,0]    OBJ       2.9296874999999993e-02
    x[8,0]    onehot_8  1
    x[8,0]    w_lb_8_0  -4.9025936701360941e-02
    x[8,0]    w_ub_8_0  -1.0218978102189782e-01
    x[8,1]    OBJ       2.3437499999999993e-02
    x[8,1]    onehot_8  1
    x[8,1]    w_lb_8_1  -4.9025936701360941e-02
    x[8,1]    w_ub_8_1  -1.0218978102189782e-01
    x[8,1]    hard_lower  1
    x[8,1]    hard_upper  1
    x[8,1]    old_TS1   -4.9025936701360941e-02
    x[8,1]    old_TS2   -1.0218978102189782e-01
    x[8,1]    old_TS3   -1.0218978102189782e-01
    x[8,1]    old_TS4   -4.9025936701360941e-02
    x[8,2]    OBJ       1.7578124999999993e-02
    x[8,2]    onehot_8  1
    x[8,2]    w_lb_8_2  -4.9025936701360941e-02
    x[8,2]    w_ub_8_2  -1.0218978102189782e-01
    x[8,2]    hard_lower  2
    x[8,2]    hard_upper  2
    x[8,2]    old_TS1   -9.8051873402721881e-02
    x[8,2]    old_TS2   -2.0437956204379565e-01
    x[8,2]    old_TS3   -2.0437956204379565e-01
    x[8,2]    old_TS4   -9.8051873402721881e-02
    x[8,3]    OBJ       1.1718749999999993e-02
    x[8,3]    onehot_8  1
    x[8,3]    w_lb_8_3  -4.9025936701360941e-02
    x[8,3]    w_ub_8_3  -1.0218978102189782e-01
    x[8,3]    hard_lower  3
    x[8,3]    hard_upper  3
    x[8,3]    old_TS1   -1.4707781010408283e-01
    x[8,3]    old_TS2   -3.0656934306569350e-01
    x[8,3]    old_TS3   -3.0656934306569350e-01
    x[8,3]    old_TS4   -1.4707781010408283e-01
    x[8,4]    OBJ       5.8593749999999931e-03
    x[8,4]    onehot_8  1
    x[8,4]    w_lb_8_4  -4.9025936701360941e-02
    x[8,4]    w_ub_8_4  -1.0218978102189782e-01
    x[8,4]    hard_lower  4
    x[8,4]    hard_upper  4
    x[8,4]    old_TS1   -1.9610374680544376e-01
    x[8,4]    old_TS2   -4.0875912408759130e-01
    x[8,4]    old_TS3   -4.0875912408759130e-01
    x[8,4]    old_TS4   -1.9610374680544376e-01
    x[8,5]    OBJ       -6.5052130349130266e-18
    x[8,5]    onehot_8  1
    x[8,5]    w_lb_8_5  -4.9025936701360941e-02
    x[8,5]    w_ub_8_5  -1.0218978102189782e-01
    x[8,5]    hard_lower  5
    x[8,5]    hard_upper  5
    x[8,5]    old_TS1   -2.4512968350680470e-01
    x[8,5]    old_TS2   -5.1094890510948909e-01
    x[8,5]    old_TS3   -5.1094890510948909e-01
    x[8,5]    old_TS4   -2.4512968350680470e-01
    x[8,6]    OBJ       -5.8593750000000069e-03
    x[8,6]    onehot_8  1
    x[8,6]    w_lb_8_6  -4.9025936701360941e-02
    x[8,6]    w_ub_8_6  -1.0218978102189782e-01
    x[8,6]    hard_lower  6
    x[8,6]    hard_upper  6
    x[8,6]    old_TS1   -2.9415562020816566e-01
    x[8,6]    old_TS2   -0.613138686131387
    x[8,6]    old_TS3   -0.613138686131387
    x[8,6]    old_TS4   -2.9415562020816566e-01
    x[8,7]    OBJ       -1.1718750000000009e-02
    x[8,7]    onehot_8  1
    x[8,7]    w_lb_8_7  -4.9025936701360941e-02
    x[8,7]    w_ub_8_7  -1.0218978102189782e-01
    x[8,7]    hard_lower  7
    x[8,7]    hard_upper  7
    x[8,7]    old_TS1   -3.4318155690952656e-01
    x[8,7]    old_TS2   -7.1532846715328480e-01
    x[8,7]    old_TS3   -7.1532846715328480e-01
    x[8,7]    old_TS4   -3.4318155690952656e-01
    x[8,8]    OBJ       -1.7578125000000010e-02
    x[8,8]    onehot_8  1
    x[8,8]    w_lb_8_8  -4.9025936701360941e-02
    x[8,8]    w_ub_8_8  -1.0218978102189782e-01
    x[8,8]    hard_lower  8
    x[8,8]    hard_upper  8
    x[8,8]    old_TS1   -3.9220749361088753e-01
    x[8,8]    old_TS2   -8.1751824817518259e-01
    x[8,8]    old_TS3   -8.1751824817518259e-01
    x[8,8]    old_TS4   -3.9220749361088753e-01
    x[8,9]    OBJ       -2.3437500000000010e-02
    x[8,9]    onehot_8  1
    x[8,9]    w_lb_8_9  -4.9025936701360941e-02
    x[8,9]    w_ub_8_9  -1.0218978102189782e-01
    x[8,9]    hard_lower  9
    x[8,9]    hard_upper  9
    x[8,9]    old_TS1   -4.4123343031224849e-01
    x[8,9]    old_TS2   -9.1970802919708039e-01
    x[8,9]    old_TS3   -9.1970802919708039e-01
    x[8,9]    old_TS4   -4.4123343031224849e-01
    x[8,10]   OBJ       -2.9296875000000003e-02
    x[8,10]   onehot_8  1
    x[8,10]   w_lb_8_10  -4.9025936701360941e-02
    x[8,10]   w_ub_8_10  -1.0218978102189782e-01
    x[8,10]   hard_lower  10
    x[8,10]   hard_upper  10
    x[8,10]   old_TS1   -4.9025936701360939e-01
    x[8,10]   old_TS2   -1.0218978102189782e+00
    x[8,10]   old_TS3   -1.0218978102189782e+00
    x[8,10]   old_TS4   -4.9025936701360939e-01
    x[8,11]   OBJ       -2.3437500000000003e-02
    x[8,11]   onehot_8  1
    x[8,11]   w_lb_8_11  -4.9025936701360941e-02
    x[8,11]   w_ub_8_11  -1.0218978102189782e-01
    x[8,11]   hard_lower  11
    x[8,11]   hard_upper  11
    x[8,11]   old_TS1   -5.3928530371497030e-01
    x[8,11]   old_TS2   -1.1240875912408761e+00
    x[8,11]   old_TS3   -1.1240875912408761e+00
    x[8,11]   old_TS4   -5.3928530371497030e-01
    x[8,12]   OBJ       -1.7578125000000003e-02
    x[8,12]   onehot_8  1
    x[8,12]   w_lb_8_12  -4.9025936701360941e-02
    x[8,12]   w_ub_8_12  -1.0218978102189782e-01
    x[8,12]   hard_lower  12
    x[8,12]   hard_upper  12
    x[8,12]   old_TS1   -5.8831124041633132e-01
    x[8,12]   old_TS2   -1.2262773722627740e+00
    x[8,12]   old_TS3   -1.2262773722627740e+00
    x[8,12]   old_TS4   -5.8831124041633132e-01
    x[8,13]   OBJ       -1.1718750000000002e-02
    x[8,13]   onehot_8  1
    x[8,13]   w_lb_8_13  -4.9025936701360941e-02
    x[8,13]   w_ub_8_13  -1.0218978102189782e-01
    x[8,13]   hard_lower  13
    x[8,13]   hard_upper  13
    x[8,13]   old_TS1   -6.3733717711769222e-01
    x[8,13]   old_TS2   -1.3284671532846717e+00
    x[8,13]   old_TS3   -1.3284671532846717e+00
    x[8,13]   old_TS4   -6.3733717711769222e-01
    x[8,14]   OBJ       -5.8593750000000009e-03
    x[8,14]   onehot_8  1
    x[8,14]   w_lb_8_14  -4.9025936701360941e-02
    x[8,14]   w_ub_8_14  -1.0218978102189782e-01
    x[8,14]   hard_lower  14
    x[8,14]   hard_upper  14
    x[8,14]   old_TS1   -6.8636311381905313e-01
    x[8,14]   old_TS2   -1.4306569343065696e+00
    x[8,14]   old_TS3   -1.4306569343065696e+00
    x[8,14]   old_TS4   -6.8636311381905313e-01
    x[8,15]   onehot_8  1
    x[8,15]   w_lb_8_15  -4.9025936701360941e-02
    x[8,15]   w_ub_8_15  -1.0218978102189782e-01
    x[8,15]   hard_lower  15
    x[8,15]   hard_upper  15
    x[8,15]   old_TS1   -7.3538905052041414e-01
    x[8,15]   old_TS2   -1.5328467153284673e+00
    x[8,15]   old_TS3   -1.5328467153284673e+00
    x[8,15]   old_TS4   -7.3538905052041414e-01
    x[8,16]   OBJ       0.005859375
    x[8,16]   onehot_8  1
    x[8,16]   w_lb_8_16  -4.9025936701360941e-02
    x[8,16]   w_ub_8_16  -1.0218978102189782e-01
    x[8,16]   hard_lower  16
    x[8,16]   hard_upper  16
    x[8,16]   old_TS1   -0.784414987221775
    x[8,16]   old_TS2   -1.6350364963503652e+00
    x[8,16]   old_TS3   -1.6350364963503652e+00
    x[8,16]   old_TS4   -0.784414987221775
    x[8,17]   OBJ       0.01171875
    x[8,17]   onehot_8  1
    x[8,17]   w_lb_8_17  -4.9025936701360941e-02
    x[8,17]   w_ub_8_17  -1.0218978102189782e-01
    x[8,17]   hard_lower  17
    x[8,17]   hard_upper  17
    x[8,17]   old_TS1   -0.833440923923136
    x[8,17]   old_TS2   -1.7372262773722631e+00
    x[8,17]   old_TS3   -1.7372262773722631e+00
    x[8,17]   old_TS4   -0.833440923923136
    x[8,18]   OBJ       0.017578125
    x[8,18]   onehot_8  1
    x[8,18]   w_lb_8_18  -4.9025936701360941e-02
    x[8,18]   w_ub_8_18  -1.0218978102189782e-01
    x[8,18]   hard_lower  18
    x[8,18]   hard_upper  18
    x[8,18]   old_TS1   -0.882466860624497
    x[8,18]   old_TS2   -1.8394160583941608e+00
    x[8,18]   old_TS3   -1.8394160583941608e+00
    x[8,18]   old_TS4   -0.882466860624497
    x[8,19]   OBJ       0.0234375
    x[8,19]   onehot_8  1
    x[8,19]   w_lb_8_19  -4.9025936701360941e-02
    x[8,19]   w_ub_8_19  -1.0218978102189782e-01
    x[8,19]   hard_lower  19
    x[8,19]   hard_upper  19
    x[8,19]   old_TS1   -9.3149279732585788e-01
    x[8,19]   old_TS2   -1.9416058394160587e+00
    x[8,19]   old_TS3   -1.9416058394160587e+00
    x[8,19]   old_TS4   -9.3149279732585788e-01
    x[8,20]   OBJ       0.029296875
    x[8,20]   onehot_8  1
    x[8,20]   w_lb_8_20  -4.9025936701360941e-02
    x[8,20]   w_ub_8_20  -1.0218978102189782e-01
    x[8,20]   hard_lower  20
    x[8,20]   hard_upper  20
    x[8,20]   old_TS1   -9.8051873402721879e-01
    x[8,20]   old_TS2   -2.0437956204379564e+00
    x[8,20]   old_TS3   -2.0437956204379564e+00
    x[8,20]   old_TS4   -9.8051873402721879e-01
    x[9,0]    OBJ       4.5117187499999996e-02
    x[9,0]    onehot_9  1
    x[9,0]    w_lb_9_0  -4.9025936701360941e-02
    x[9,0]    w_ub_9_0  -1.0218978102189782e-01
    x[9,1]    OBJ       0.0369140625
    x[9,1]    onehot_9  1
    x[9,1]    w_lb_9_1  -4.9025936701360941e-02
    x[9,1]    w_ub_9_1  -1.0218978102189782e-01
    x[9,1]    hard_lower  1
    x[9,1]    hard_upper  1
    x[9,1]    old_TS1   -4.9025936701360941e-02
    x[9,1]    old_TS2   -1.0218978102189782e-01
    x[9,1]    old_TS3   -1.0218978102189782e-01
    x[9,1]    old_TS4   -4.9025936701360941e-02
    x[9,2]    OBJ       2.8710937500000002e-02
    x[9,2]    onehot_9  1
    x[9,2]    w_lb_9_2  -4.9025936701360941e-02
    x[9,2]    w_ub_9_2  -1.0218978102189782e-01
    x[9,2]    hard_lower  2
    x[9,2]    hard_upper  2
    x[9,2]    old_TS1   -9.8051873402721881e-02
    x[9,2]    old_TS2   -2.0437956204379565e-01
    x[9,2]    old_TS3   -2.0437956204379565e-01
    x[9,2]    old_TS4   -9.8051873402721881e-02
    x[9,3]    OBJ       2.0507812500000003e-02
    x[9,3]    onehot_9  1
    x[9,3]    w_lb_9_3  -4.9025936701360941e-02
    x[9,3]    w_ub_9_3  -1.0218978102189782e-01
    x[9,3]    hard_lower  3
    x[9,3]    hard_upper  3
    x[9,3]    old_TS1   -1.4707781010408283e-01
    x[9,3]    old_TS2   -3.0656934306569350e-01
    x[9,3]    old_TS3   -3.0656934306569350e-01
    x[9,3]    old_TS4   -1.4707781010408283e-01
    x[9,4]    OBJ       1.2304687500000005e-02
    x[9,4]    onehot_9  1
    x[9,4]    w_lb_9_4  -4.9025936701360941e-02
    x[9,4]    w_ub_9_4  -1.0218978102189782e-01
    x[9,4]    hard_lower  4
    x[9,4]    hard_upper  4
    x[9,4]    old_TS1   -1.9610374680544376e-01
    x[9,4]    old_TS2   -4.0875912408759130e-01
    x[9,4]    old_TS3   -4.0875912408759130e-01
    x[9,4]    old_TS4   -1.9610374680544376e-01
    x[9,5]    OBJ       4.1015625000000054e-03
    x[9,5]    onehot_9  1
    x[9,5]    w_lb_9_5  -4.9025936701360941e-02
    x[9,5]    w_ub_9_5  -1.0218978102189782e-01
    x[9,5]    hard_lower  5
    x[9,5]    hard_upper  5
    x[9,5]    old_TS1   -2.4512968350680470e-01
    x[9,5]    old_TS2   -5.1094890510948909e-01
    x[9,5]    old_TS3   -5.1094890510948909e-01
    x[9,5]    old_TS4   -2.4512968350680470e-01
    x[9,6]    OBJ       -4.1015624999999932e-03
    x[9,6]    onehot_9  1
    x[9,6]    w_lb_9_6  -4.9025936701360941e-02
    x[9,6]    w_ub_9_6  -1.0218978102189782e-01
    x[9,6]    hard_lower  6
    x[9,6]    hard_upper  6
    x[9,6]    old_TS1   -2.9415562020816566e-01
    x[9,6]    old_TS2   -0.613138686131387
    x[9,6]    old_TS3   -0.613138686131387
    x[9,6]    old_TS4   -2.9415562020816566e-01
    x[9,7]    OBJ       -1.2304687499999993e-02
    x[9,7]    onehot_9  1
    x[9,7]    w_lb_9_7  -4.9025936701360941e-02
    x[9,7]    w_ub_9_7  -1.0218978102189782e-01
    x[9,7]    hard_lower  7
    x[9,7]    hard_upper  7
    x[9,7]    old_TS1   -3.4318155690952656e-01
    x[9,7]    old_TS2   -7.1532846715328480e-01
    x[9,7]    old_TS3   -7.1532846715328480e-01
    x[9,7]    old_TS4   -3.4318155690952656e-01
    x[9,8]    OBJ       -2.0507812499999993e-02
    x[9,8]    onehot_9  1
    x[9,8]    w_lb_9_8  -4.9025936701360941e-02
    x[9,8]    w_ub_9_8  -1.0218978102189782e-01
    x[9,8]    hard_lower  8
    x[9,8]    hard_upper  8
    x[9,8]    old_TS1   -3.9220749361088753e-01
    x[9,8]    old_TS2   -8.1751824817518259e-01
    x[9,8]    old_TS3   -8.1751824817518259e-01
    x[9,8]    old_TS4   -3.9220749361088753e-01
    x[9,9]    OBJ       -2.8710937499999992e-02
    x[9,9]    onehot_9  1
    x[9,9]    w_lb_9_9  -4.9025936701360941e-02
    x[9,9]    w_ub_9_9  -1.0218978102189782e-01
    x[9,9]    hard_lower  9
    x[9,9]    hard_upper  9
    x[9,9]    old_TS1   -4.4123343031224849e-01
    x[9,9]    old_TS2   -9.1970802919708039e-01
    x[9,9]    old_TS3   -9.1970802919708039e-01
    x[9,9]    old_TS4   -4.4123343031224849e-01
    x[9,10]   OBJ       -3.6914062499999990e-02
    x[9,10]   onehot_9  1
    x[9,10]   w_lb_9_10  -4.9025936701360941e-02
    x[9,10]   w_ub_9_10  -1.0218978102189782e-01
    x[9,10]   hard_lower  10
    x[9,10]   hard_upper  10
    x[9,10]   old_TS1   -4.9025936701360939e-01
    x[9,10]   old_TS2   -1.0218978102189782e+00
    x[9,10]   old_TS3   -1.0218978102189782e+00
    x[9,10]   old_TS4   -4.9025936701360939e-01
    x[9,11]   OBJ       -4.5117187499999996e-02
    x[9,11]   onehot_9  1
    x[9,11]   w_lb_9_11  -4.9025936701360941e-02
    x[9,11]   w_ub_9_11  -1.0218978102189782e-01
    x[9,11]   hard_lower  11
    x[9,11]   hard_upper  11
    x[9,11]   old_TS1   -5.3928530371497030e-01
    x[9,11]   old_TS2   -1.1240875912408761e+00
    x[9,11]   old_TS3   -1.1240875912408761e+00
    x[9,11]   old_TS4   -5.3928530371497030e-01
    x[9,12]   OBJ       -5.3320312499999994e-02
    x[9,12]   onehot_9  1
    x[9,12]   w_lb_9_12  -4.9025936701360941e-02
    x[9,12]   w_ub_9_12  -1.0218978102189782e-01
    x[9,12]   hard_lower  12
    x[9,12]   hard_upper  12
    x[9,12]   old_TS1   -5.8831124041633132e-01
    x[9,12]   old_TS2   -1.2262773722627740e+00
    x[9,12]   old_TS3   -1.2262773722627740e+00
    x[9,12]   old_TS4   -5.8831124041633132e-01
    x[9,13]   OBJ       -6.1523437499999993e-02
    x[9,13]   onehot_9  1
    x[9,13]   w_lb_9_13  -4.9025936701360941e-02
    x[9,13]   w_ub_9_13  -1.0218978102189782e-01
    x[9,13]   hard_lower  13
    x[9,13]   hard_upper  13
    x[9,13]   old_TS1   -6.3733717711769222e-01
    x[9,13]   old_TS2   -1.3284671532846717e+00
    x[9,13]   old_TS3   -1.3284671532846717e+00
    x[9,13]   old_TS4   -6.3733717711769222e-01
    x[9,14]   OBJ       -6.9726562499999992e-02
    x[9,14]   onehot_9  1
    x[9,14]   w_lb_9_14  -4.9025936701360941e-02
    x[9,14]   w_ub_9_14  -1.0218978102189782e-01
    x[9,14]   hard_lower  14
    x[9,14]   hard_upper  14
    x[9,14]   old_TS1   -6.8636311381905313e-01
    x[9,14]   old_TS2   -1.4306569343065696e+00
    x[9,14]   old_TS3   -1.4306569343065696e+00
    x[9,14]   old_TS4   -6.8636311381905313e-01
    x[9,15]   OBJ       -0.0615234375
    x[9,15]   onehot_9  1
    x[9,15]   w_lb_9_15  -4.9025936701360941e-02
    x[9,15]   w_ub_9_15  -1.0218978102189782e-01
    x[9,15]   hard_lower  15
    x[9,15]   hard_upper  15
    x[9,15]   old_TS1   -7.3538905052041414e-01
    x[9,15]   old_TS2   -1.5328467153284673e+00
    x[9,15]   old_TS3   -1.5328467153284673e+00
    x[9,15]   old_TS4   -7.3538905052041414e-01
    x[9,16]   OBJ       -0.0533203125
    x[9,16]   onehot_9  1
    x[9,16]   w_lb_9_16  -4.9025936701360941e-02
    x[9,16]   w_ub_9_16  -1.0218978102189782e-01
    x[9,16]   hard_lower  16
    x[9,16]   hard_upper  16
    x[9,16]   old_TS1   -0.784414987221775
    x[9,16]   old_TS2   -1.6350364963503652e+00
    x[9,16]   old_TS3   -1.6350364963503652e+00
    x[9,16]   old_TS4   -0.784414987221775
    x[9,17]   OBJ       -0.0451171875
    x[9,17]   onehot_9  1
    x[9,17]   w_lb_9_17  -4.9025936701360941e-02
    x[9,17]   w_ub_9_17  -1.0218978102189782e-01
    x[9,17]   hard_lower  17
    x[9,17]   hard_upper  17
    x[9,17]   old_TS1   -0.833440923923136
    x[9,17]   old_TS2   -1.7372262773722631e+00
    x[9,17]   old_TS3   -1.7372262773722631e+00
    x[9,17]   old_TS4   -0.833440923923136
    x[9,18]   OBJ       -3.6914062500000004e-02
    x[9,18]   onehot_9  1
    x[9,18]   w_lb_9_18  -4.9025936701360941e-02
    x[9,18]   w_ub_9_18  -1.0218978102189782e-01
    x[9,18]   hard_lower  18
    x[9,18]   hard_upper  18
    x[9,18]   old_TS1   -0.882466860624497
    x[9,18]   old_TS2   -1.8394160583941608e+00
    x[9,18]   old_TS3   -1.8394160583941608e+00
    x[9,18]   old_TS4   -0.882466860624497
    x[9,19]   OBJ       -2.8710937500000006e-02
    x[9,19]   onehot_9  1
    x[9,19]   w_lb_9_19  -4.9025936701360941e-02
    x[9,19]   w_ub_9_19  -1.0218978102189782e-01
    x[9,19]   hard_lower  19
    x[9,19]   hard_upper  19
    x[9,19]   old_TS1   -9.3149279732585788e-01
    x[9,19]   old_TS2   -1.9416058394160587e+00
    x[9,19]   old_TS3   -1.9416058394160587e+00
    x[9,19]   old_TS4   -9.3149279732585788e-01
    x[9,20]   OBJ       -2.0507812500000007e-02
    x[9,20]   onehot_9  1
    x[9,20]   w_lb_9_20  -4.9025936701360941e-02
    x[9,20]   w_ub_9_20  -1.0218978102189782e-01
    x[9,20]   hard_lower  20
    x[9,20]   hard_upper  20
    x[9,20]   old_TS1   -9.8051873402721879e-01
    x[9,20]   old_TS2   -2.0437956204379564e+00
    x[9,20]   old_TS3   -2.0437956204379564e+00
    x[9,20]   old_TS4   -9.8051873402721879e-01
    x[9,21]   OBJ       -1.2304687500000007e-02
    x[9,21]   onehot_9  1
    x[9,21]   w_lb_9_21  -4.9025936701360941e-02
    x[9,21]   w_ub_9_21  -1.0218978102189782e-01
    x[9,21]   hard_lower  21
    x[9,21]   hard_upper  21
    x[9,21]   old_TS1   -1.0295446707285798e+00
    x[9,21]   old_TS2   -2.1459854014598543e+00
    x[9,21]   old_TS3   -2.1459854014598543e+00
    x[9,21]   old_TS4   -1.0295446707285798e+00
    x[9,22]   OBJ       -4.1015625000000062e-03
    x[9,22]   onehot_9  1
    x[9,22]   w_lb_9_22  -4.9025936701360941e-02
    x[9,22]   w_ub_9_22  -1.0218978102189782e-01
    x[9,22]   hard_lower  22
    x[9,22]   hard_upper  22
    x[9,22]   old_TS1   -1.0785706074299406e+00
    x[9,22]   old_TS2   -2.2481751824817522e+00
    x[9,22]   old_TS3   -2.2481751824817522e+00
    x[9,22]   old_TS4   -1.0785706074299406e+00
    x[9,23]   OBJ       4.1015624999999924e-03
    x[9,23]   onehot_9  1
    x[9,23]   w_lb_9_23  -4.9025936701360941e-02
    x[9,23]   w_ub_9_23  -1.0218978102189782e-01
    x[9,23]   hard_lower  23
    x[9,23]   hard_upper  23
    x[9,23]   old_TS1   -1.1275965441313016e+00
    x[9,23]   old_TS2   -2.35036496350365
    x[9,23]   old_TS3   -2.35036496350365
    x[9,23]   old_TS4   -1.1275965441313016e+00
    x[9,24]   OBJ       1.2304687499999991e-02
    x[9,24]   onehot_9  1
    x[9,24]   w_lb_9_24  -4.9025936701360941e-02
    x[9,24]   w_ub_9_24  -1.0218978102189782e-01
    x[9,24]   hard_lower  24
    x[9,24]   hard_upper  24
    x[9,24]   old_TS1   -1.1766224808326626e+00
    x[9,24]   old_TS2   -2.4525547445255480e+00
    x[9,24]   old_TS3   -2.4525547445255480e+00
    x[9,24]   old_TS4   -1.1766224808326626e+00
    x[9,25]   OBJ       2.0507812499999990e-02
    x[9,25]   onehot_9  1
    x[9,25]   w_lb_9_25  -4.9025936701360941e-02
    x[9,25]   w_ub_9_25  -1.0218978102189782e-01
    x[9,25]   hard_lower  25
    x[9,25]   hard_upper  25
    x[9,25]   old_TS1   -1.2256484175340234e+00
    x[9,25]   old_TS2   -2.5547445255474455e+00
    x[9,25]   old_TS3   -2.5547445255474455e+00
    x[9,25]   old_TS4   -1.2256484175340234e+00
    x[9,26]   OBJ       2.8710937499999988e-02
    x[9,26]   onehot_9  1
    x[9,26]   w_lb_9_26  -4.9025936701360941e-02
    x[9,26]   w_ub_9_26  -1.0218978102189782e-01
    x[9,26]   hard_lower  26
    x[9,26]   hard_upper  26
    x[9,26]   old_TS1   -1.2746743542353844e+00
    x[9,26]   old_TS2   -2.6569343065693434e+00
    x[9,26]   old_TS3   -2.6569343065693434e+00
    x[9,26]   old_TS4   -1.2746743542353844e+00
    x[9,27]   OBJ       3.6914062499999983e-02
    x[9,27]   onehot_9  1
    x[9,27]   w_lb_9_27  -4.9025936701360941e-02
    x[9,27]   w_ub_9_27  -1.0218978102189782e-01
    x[9,27]   hard_lower  27
    x[9,27]   hard_upper  27
    x[9,27]   old_TS1   -1.3237002909367455e+00
    x[9,27]   old_TS2   -2.7591240875912413e+00
    x[9,27]   old_TS3   -2.7591240875912413e+00
    x[9,27]   old_TS4   -1.3237002909367455e+00
    x[9,28]   OBJ       4.5117187499999989e-02
    x[9,28]   onehot_9  1
    x[9,28]   w_lb_9_28  -4.9025936701360941e-02
    x[9,28]   w_ub_9_28  -1.0218978102189782e-01
    x[9,28]   hard_lower  28
    x[9,28]   hard_upper  28
    x[9,28]   old_TS1   -1.3727262276381063e+00
    x[9,28]   old_TS2   -2.8613138686131392e+00
    x[9,28]   old_TS3   -2.8613138686131392e+00
    x[9,28]   old_TS4   -1.3727262276381063e+00
    x[9,29]   OBJ       5.3320312499999988e-02
    x[9,29]   onehot_9  1
    x[9,29]   w_lb_9_29  -4.9025936701360941e-02
    x[9,29]   w_ub_9_29  -1.0218978102189782e-01
    x[9,29]   hard_lower  29
    x[9,29]   hard_upper  29
    x[9,29]   old_TS1   -1.4217521643394673e+00
    x[9,29]   old_TS2   -2.9635036496350371e+00
    x[9,29]   old_TS3   -2.9635036496350371e+00
    x[9,29]   old_TS4   -1.4217521643394673e+00
    x[9,30]   OBJ       6.1523437499999986e-02
    x[9,30]   onehot_9  1
    x[9,30]   w_lb_9_30  -4.9025936701360941e-02
    x[9,30]   w_ub_9_30  -1.0218978102189782e-01
    x[9,30]   hard_lower  30
    x[9,30]   hard_upper  30
    x[9,30]   old_TS1   -1.4707781010408283e+00
    x[9,30]   old_TS2   -3.0656934306569346e+00
    x[9,30]   old_TS3   -3.0656934306569346e+00
    x[9,30]   old_TS4   -1.4707781010408283e+00
    x[9,31]   OBJ       6.9726562499999978e-02
    x[9,31]   onehot_9  1
    x[9,31]   w_lb_9_31  -4.9025936701360941e-02
    x[9,31]   w_ub_9_31  -1.0218978102189782e-01
    x[9,31]   hard_lower  31
    x[9,31]   hard_upper  31
    x[9,31]   old_TS1   -1.5198040377421891e+00
    x[9,31]   old_TS2   -3.1678832116788325e+00
    x[9,31]   old_TS3   -3.1678832116788325e+00
    x[9,31]   old_TS4   -1.5198040377421891e+00
    x[10,0]   OBJ       2.1093733333333333e-02
    x[10,0]   onehot_10  1
    x[10,0]   w_lb_10_0  -4.9025936701360941e-02
    x[10,0]   w_ub_10_0  -1.0218978102189782e-01
    x[10,1]   OBJ       0.0158203
    x[10,1]   onehot_10  1
    x[10,1]   w_lb_10_1  -4.9025936701360941e-02
    x[10,1]   w_ub_10_1  -1.0218978102189782e-01
    x[10,1]   hard_lower  1
    x[10,1]   hard_upper  1
    x[10,1]   old_TS1   -4.9025936701360941e-02
    x[10,1]   old_TS2   -1.0218978102189782e-01
    x[10,1]   old_TS3   -1.0218978102189782e-01
    x[10,1]   old_TS4   -4.9025936701360941e-02
    x[10,2]   OBJ       1.0546866666666668e-02
    x[10,2]   onehot_10  1
    x[10,2]   w_lb_10_2  -4.9025936701360941e-02
    x[10,2]   w_ub_10_2  -1.0218978102189782e-01
    x[10,2]   hard_lower  2
    x[10,2]   hard_upper  2
    x[10,2]   old_TS1   -9.8051873402721881e-02
    x[10,2]   old_TS2   -2.0437956204379565e-01
    x[10,2]   old_TS3   -2.0437956204379565e-01
    x[10,2]   old_TS4   -9.8051873402721881e-02
    x[10,3]   OBJ       5.2734333333333350e-03
    x[10,3]   onehot_10  1
    x[10,3]   w_lb_10_3  -4.9025936701360941e-02
    x[10,3]   w_ub_10_3  -1.0218978102189782e-01
    x[10,3]   hard_lower  3
    x[10,3]   hard_upper  3
    x[10,3]   old_TS1   -1.4707781010408283e-01
    x[10,3]   old_TS2   -3.0656934306569350e-01
    x[10,3]   old_TS3   -3.0656934306569350e-01
    x[10,3]   old_TS4   -1.4707781010408283e-01
    x[10,4]   OBJ       2.6346091974716046e-18
    x[10,4]   onehot_10  1
    x[10,4]   w_lb_10_4  -4.9025936701360941e-02
    x[10,4]   w_ub_10_4  -1.0218978102189782e-01
    x[10,4]   hard_lower  4
    x[10,4]   hard_upper  4
    x[10,4]   old_TS1   -1.9610374680544376e-01
    x[10,4]   old_TS2   -4.0875912408759130e-01
    x[10,4]   old_TS3   -4.0875912408759130e-01
    x[10,4]   old_TS4   -1.9610374680544376e-01
    x[10,5]   OBJ       -5.2734333333333307e-03
    x[10,5]   onehot_10  1
    x[10,5]   w_lb_10_5  -4.9025936701360941e-02
    x[10,5]   w_ub_10_5  -1.0218978102189782e-01
    x[10,5]   hard_lower  5
    x[10,5]   hard_upper  5
    x[10,5]   old_TS1   -2.4512968350680470e-01
    x[10,5]   old_TS2   -5.1094890510948909e-01
    x[10,5]   old_TS3   -5.1094890510948909e-01
    x[10,5]   old_TS4   -2.4512968350680470e-01
    x[10,6]   OBJ       -1.0546866666666665e-02
    x[10,6]   onehot_10  1
    x[10,6]   w_lb_10_6  -4.9025936701360941e-02
    x[10,6]   w_ub_10_6  -1.0218978102189782e-01
    x[10,6]   hard_lower  6
    x[10,6]   hard_upper  6
    x[10,6]   old_TS1   -2.9415562020816566e-01
    x[10,6]   old_TS2   -0.613138686131387
    x[10,6]   old_TS3   -0.613138686131387
    x[10,6]   old_TS4   -2.9415562020816566e-01
    x[10,7]   OBJ       -0.0158203
    x[10,7]   onehot_10  1
    x[10,7]   w_lb_10_7  -4.9025936701360941e-02
    x[10,7]   w_ub_10_7  -1.0218978102189782e-01
    x[10,7]   hard_lower  7
    x[10,7]   hard_upper  7
    x[10,7]   old_TS1   -3.4318155690952656e-01
    x[10,7]   old_TS2   -7.1532846715328480e-01
    x[10,7]   old_TS3   -7.1532846715328480e-01
    x[10,7]   old_TS4   -3.4318155690952656e-01
    x[10,8]   OBJ       -2.1093733333333333e-02
    x[10,8]   onehot_10  1
    x[10,8]   w_lb_10_8  -4.9025936701360941e-02
    x[10,8]   w_ub_10_8  -1.0218978102189782e-01
    x[10,8]   hard_lower  8
    x[10,8]   hard_upper  8
    x[10,8]   old_TS1   -3.9220749361088753e-01
    x[10,8]   old_TS2   -8.1751824817518259e-01
    x[10,8]   old_TS3   -8.1751824817518259e-01
    x[10,8]   old_TS4   -3.9220749361088753e-01
    x[10,9]   OBJ       -2.6367166666666664e-02
    x[10,9]   onehot_10  1
    x[10,9]   w_lb_10_9  -4.9025936701360941e-02
    x[10,9]   w_ub_10_9  -1.0218978102189782e-01
    x[10,9]   hard_lower  9
    x[10,9]   hard_upper  9
    x[10,9]   old_TS1   -4.4123343031224849e-01
    x[10,9]   old_TS2   -9.1970802919708039e-01
    x[10,9]   old_TS3   -9.1970802919708039e-01
    x[10,9]   old_TS4   -4.4123343031224849e-01
    x[10,10]  OBJ       -2.1093733333333337e-02
    x[10,10]  onehot_10  1
    x[10,10]  w_lb_10_10  -4.9025936701360941e-02
    x[10,10]  w_ub_10_10  -1.0218978102189782e-01
    x[10,10]  hard_lower  10
    x[10,10]  hard_upper  10
    x[10,10]  old_TS1   -4.9025936701360939e-01
    x[10,10]  old_TS2   -1.0218978102189782e+00
    x[10,10]  old_TS3   -1.0218978102189782e+00
    x[10,10]  old_TS4   -4.9025936701360939e-01
    x[10,11]  OBJ       -1.5820300000000002e-02
    x[10,11]  onehot_10  1
    x[10,11]  w_lb_10_11  -4.9025936701360941e-02
    x[10,11]  w_ub_10_11  -1.0218978102189782e-01
    x[10,11]  hard_lower  11
    x[10,11]  hard_upper  11
    x[10,11]  old_TS1   -5.3928530371497030e-01
    x[10,11]  old_TS2   -1.1240875912408761e+00
    x[10,11]  old_TS3   -1.1240875912408761e+00
    x[10,11]  old_TS4   -5.3928530371497030e-01
    x[10,12]  OBJ       -1.0546866666666670e-02
    x[10,12]  onehot_10  1
    x[10,12]  w_lb_10_12  -4.9025936701360941e-02
    x[10,12]  w_ub_10_12  -1.0218978102189782e-01
    x[10,12]  hard_lower  12
    x[10,12]  hard_upper  12
    x[10,12]  old_TS1   -5.8831124041633132e-01
    x[10,12]  old_TS2   -1.2262773722627740e+00
    x[10,12]  old_TS3   -1.2262773722627740e+00
    x[10,12]  old_TS4   -5.8831124041633132e-01
    x[10,13]  OBJ       -5.2734333333333359e-03
    x[10,13]  onehot_10  1
    x[10,13]  w_lb_10_13  -4.9025936701360941e-02
    x[10,13]  w_ub_10_13  -1.0218978102189782e-01
    x[10,13]  hard_lower  13
    x[10,13]  hard_upper  13
    x[10,13]  old_TS1   -6.3733717711769222e-01
    x[10,13]  old_TS2   -1.3284671532846717e+00
    x[10,13]  old_TS3   -1.3284671532846717e+00
    x[10,13]  old_TS4   -6.3733717711769222e-01
    x[10,14]  OBJ       -2.6346091974716046e-18
    x[10,14]  onehot_10  1
    x[10,14]  w_lb_10_14  -4.9025936701360941e-02
    x[10,14]  w_ub_10_14  -1.0218978102189782e-01
    x[10,14]  hard_lower  14
    x[10,14]  hard_upper  14
    x[10,14]  old_TS1   -6.8636311381905313e-01
    x[10,14]  old_TS2   -1.4306569343065696e+00
    x[10,14]  old_TS3   -1.4306569343065696e+00
    x[10,14]  old_TS4   -6.8636311381905313e-01
    x[10,15]  OBJ       0.00527343333333333
    x[10,15]  onehot_10  1
    x[10,15]  w_lb_10_15  -4.9025936701360941e-02
    x[10,15]  w_ub_10_15  -1.0218978102189782e-01
    x[10,15]  hard_lower  15
    x[10,15]  hard_upper  15
    x[10,15]  old_TS1   -7.3538905052041414e-01
    x[10,15]  old_TS2   -1.5328467153284673e+00
    x[10,15]  old_TS3   -1.5328467153284673e+00
    x[10,15]  old_TS4   -7.3538905052041414e-01
    x[10,16]  OBJ       1.0546866666666663e-02
    x[10,16]  onehot_10  1
    x[10,16]  w_lb_10_16  -4.9025936701360941e-02
    x[10,16]  w_ub_10_16  -1.0218978102189782e-01
    x[10,16]  hard_lower  16
    x[10,16]  hard_upper  16
    x[10,16]  old_TS1   -0.784414987221775
    x[10,16]  old_TS2   -1.6350364963503652e+00
    x[10,16]  old_TS3   -1.6350364963503652e+00
    x[10,16]  old_TS4   -0.784414987221775
    x[10,17]  OBJ       1.5820299999999995e-02
    x[10,17]  onehot_10  1
    x[10,17]  w_lb_10_17  -4.9025936701360941e-02
    x[10,17]  w_ub_10_17  -1.0218978102189782e-01
    x[10,17]  hard_lower  17
    x[10,17]  hard_upper  17
    x[10,17]  old_TS1   -0.833440923923136
    x[10,17]  old_TS2   -1.7372262773722631e+00
    x[10,17]  old_TS3   -1.7372262773722631e+00
    x[10,17]  old_TS4   -0.833440923923136
    x[10,18]  OBJ       2.1093733333333330e-02
    x[10,18]  onehot_10  1
    x[10,18]  w_lb_10_18  -4.9025936701360941e-02
    x[10,18]  w_ub_10_18  -1.0218978102189782e-01
    x[10,18]  hard_lower  18
    x[10,18]  hard_upper  18
    x[10,18]  old_TS1   -0.882466860624497
    x[10,18]  old_TS2   -1.8394160583941608e+00
    x[10,18]  old_TS3   -1.8394160583941608e+00
    x[10,18]  old_TS4   -0.882466860624497
    x[10,19]  OBJ       2.6367166666666660e-02
    x[10,19]  onehot_10  1
    x[10,19]  w_lb_10_19  -4.9025936701360941e-02
    x[10,19]  w_ub_10_19  -1.0218978102189782e-01
    x[10,19]  hard_lower  19
    x[10,19]  hard_upper  19
    x[10,19]  old_TS1   -9.3149279732585788e-01
    x[10,19]  old_TS2   -1.9416058394160587e+00
    x[10,19]  old_TS3   -1.9416058394160587e+00
    x[10,19]  old_TS4   -9.3149279732585788e-01
    x[11,0]   OBJ       2.9296874999999993e-02
    x[11,0]   onehot_11  1
    x[11,0]   w_lb_11_0  -4.9025936701360941e-02
    x[11,0]   w_ub_11_0  -1.0218978102189782e-01
    x[11,1]   OBJ       2.3437499999999993e-02
    x[11,1]   onehot_11  1
    x[11,1]   w_lb_11_1  -4.9025936701360941e-02
    x[11,1]   w_ub_11_1  -1.0218978102189782e-01
    x[11,1]   hard_lower  1
    x[11,1]   hard_upper  1
    x[11,1]   old_TS1   -4.9025936701360941e-02
    x[11,1]   old_TS2   -1.0218978102189782e-01
    x[11,1]   old_TS3   -1.0218978102189782e-01
    x[11,1]   old_TS4   -4.9025936701360941e-02
    x[11,2]   OBJ       1.7578124999999993e-02
    x[11,2]   onehot_11  1
    x[11,2]   w_lb_11_2  -4.9025936701360941e-02
    x[11,2]   w_ub_11_2  -1.0218978102189782e-01
    x[11,2]   hard_lower  2
    x[11,2]   hard_upper  2
    x[11,2]   old_TS1   -9.8051873402721881e-02
    x[11,2]   old_TS2   -2.0437956204379565e-01
    x[11,2]   old_TS3   -2.0437956204379565e-01
    x[11,2]   old_TS4   -9.8051873402721881e-02
    x[11,3]   OBJ       1.1718749999999993e-02
    x[11,3]   onehot_11  1
    x[11,3]   w_lb_11_3  -4.9025936701360941e-02
    x[11,3]   w_ub_11_3  -1.0218978102189782e-01
    x[11,3]   hard_lower  3
    x[11,3]   hard_upper  3
    x[11,3]   old_TS1   -1.4707781010408283e-01
    x[11,3]   old_TS2   -3.0656934306569350e-01
    x[11,3]   old_TS3   -3.0656934306569350e-01
    x[11,3]   old_TS4   -1.4707781010408283e-01
    x[11,4]   OBJ       5.8593749999999931e-03
    x[11,4]   onehot_11  1
    x[11,4]   w_lb_11_4  -4.9025936701360941e-02
    x[11,4]   w_ub_11_4  -1.0218978102189782e-01
    x[11,4]   hard_lower  4
    x[11,4]   hard_upper  4
    x[11,4]   old_TS1   -1.9610374680544376e-01
    x[11,4]   old_TS2   -4.0875912408759130e-01
    x[11,4]   old_TS3   -4.0875912408759130e-01
    x[11,4]   old_TS4   -1.9610374680544376e-01
    x[11,5]   OBJ       -6.5052130349130266e-18
    x[11,5]   onehot_11  1
    x[11,5]   w_lb_11_5  -4.9025936701360941e-02
    x[11,5]   w_ub_11_5  -1.0218978102189782e-01
    x[11,5]   hard_lower  5
    x[11,5]   hard_upper  5
    x[11,5]   old_TS1   -2.4512968350680470e-01
    x[11,5]   old_TS2   -5.1094890510948909e-01
    x[11,5]   old_TS3   -5.1094890510948909e-01
    x[11,5]   old_TS4   -2.4512968350680470e-01
    x[11,6]   OBJ       -5.8593750000000069e-03
    x[11,6]   onehot_11  1
    x[11,6]   w_lb_11_6  -4.9025936701360941e-02
    x[11,6]   w_ub_11_6  -1.0218978102189782e-01
    x[11,6]   hard_lower  6
    x[11,6]   hard_upper  6
    x[11,6]   old_TS1   -2.9415562020816566e-01
    x[11,6]   old_TS2   -0.613138686131387
    x[11,6]   old_TS3   -0.613138686131387
    x[11,6]   old_TS4   -2.9415562020816566e-01
    x[11,7]   OBJ       -1.1718750000000009e-02
    x[11,7]   onehot_11  1
    x[11,7]   w_lb_11_7  -4.9025936701360941e-02
    x[11,7]   w_ub_11_7  -1.0218978102189782e-01
    x[11,7]   hard_lower  7
    x[11,7]   hard_upper  7
    x[11,7]   old_TS1   -3.4318155690952656e-01
    x[11,7]   old_TS2   -7.1532846715328480e-01
    x[11,7]   old_TS3   -7.1532846715328480e-01
    x[11,7]   old_TS4   -3.4318155690952656e-01
    x[11,8]   OBJ       -1.7578125000000010e-02
    x[11,8]   onehot_11  1
    x[11,8]   w_lb_11_8  -4.9025936701360941e-02
    x[11,8]   w_ub_11_8  -1.0218978102189782e-01
    x[11,8]   hard_lower  8
    x[11,8]   hard_upper  8
    x[11,8]   old_TS1   -3.9220749361088753e-01
    x[11,8]   old_TS2   -8.1751824817518259e-01
    x[11,8]   old_TS3   -8.1751824817518259e-01
    x[11,8]   old_TS4   -3.9220749361088753e-01
    x[11,9]   OBJ       -2.3437500000000010e-02
    x[11,9]   onehot_11  1
    x[11,9]   w_lb_11_9  -4.9025936701360941e-02
    x[11,9]   w_ub_11_9  -1.0218978102189782e-01
    x[11,9]   hard_lower  9
    x[11,9]   hard_upper  9
    x[11,9]   old_TS1   -4.4123343031224849e-01
    x[11,9]   old_TS2   -9.1970802919708039e-01
    x[11,9]   old_TS3   -9.1970802919708039e-01
    x[11,9]   old_TS4   -4.4123343031224849e-01
    x[11,10]  OBJ       -2.9296875000000003e-02
    x[11,10]  onehot_11  1
    x[11,10]  w_lb_11_10  -4.9025936701360941e-02
    x[11,10]  w_ub_11_10  -1.0218978102189782e-01
    x[11,10]  hard_lower  10
    x[11,10]  hard_upper  10
    x[11,10]  old_TS1   -4.9025936701360939e-01
    x[11,10]  old_TS2   -1.0218978102189782e+00
    x[11,10]  old_TS3   -1.0218978102189782e+00
    x[11,10]  old_TS4   -4.9025936701360939e-01
    x[11,11]  OBJ       -2.3437500000000003e-02
    x[11,11]  onehot_11  1
    x[11,11]  w_lb_11_11  -4.9025936701360941e-02
    x[11,11]  w_ub_11_11  -1.0218978102189782e-01
    x[11,11]  hard_lower  11
    x[11,11]  hard_upper  11
    x[11,11]  old_TS1   -5.3928530371497030e-01
    x[11,11]  old_TS2   -1.1240875912408761e+00
    x[11,11]  old_TS3   -1.1240875912408761e+00
    x[11,11]  old_TS4   -5.3928530371497030e-01
    x[11,12]  OBJ       -1.7578125000000003e-02
    x[11,12]  onehot_11  1
    x[11,12]  w_lb_11_12  -4.9025936701360941e-02
    x[11,12]  w_ub_11_12  -1.0218978102189782e-01
    x[11,12]  hard_lower  12
    x[11,12]  hard_upper  12
    x[11,12]  old_TS1   -5.8831124041633132e-01
    x[11,12]  old_TS2   -1.2262773722627740e+00
    x[11,12]  old_TS3   -1.2262773722627740e+00
    x[11,12]  old_TS4   -5.8831124041633132e-01
    x[11,13]  OBJ       -1.1718750000000002e-02
    x[11,13]  onehot_11  1
    x[11,13]  w_lb_11_13  -4.9025936701360941e-02
    x[11,13]  w_ub_11_13  -1.0218978102189782e-01
    x[11,13]  hard_lower  13
    x[11,13]  hard_upper  13
    x[11,13]  old_TS1   -6.3733717711769222e-01
    x[11,13]  old_TS2   -1.3284671532846717e+00
    x[11,13]  old_TS3   -1.3284671532846717e+00
    x[11,13]  old_TS4   -6.3733717711769222e-01
    x[11,14]  OBJ       -5.8593750000000009e-03
    x[11,14]  onehot_11  1
    x[11,14]  w_lb_11_14  -4.9025936701360941e-02
    x[11,14]  w_ub_11_14  -1.0218978102189782e-01
    x[11,14]  hard_lower  14
    x[11,14]  hard_upper  14
    x[11,14]  old_TS1   -6.8636311381905313e-01
    x[11,14]  old_TS2   -1.4306569343065696e+00
    x[11,14]  old_TS3   -1.4306569343065696e+00
    x[11,14]  old_TS4   -6.8636311381905313e-01
    x[11,15]  onehot_11  1
    x[11,15]  w_lb_11_15  -4.9025936701360941e-02
    x[11,15]  w_ub_11_15  -1.0218978102189782e-01
    x[11,15]  hard_lower  15
    x[11,15]  hard_upper  15
    x[11,15]  old_TS1   -7.3538905052041414e-01
    x[11,15]  old_TS2   -1.5328467153284673e+00
    x[11,15]  old_TS3   -1.5328467153284673e+00
    x[11,15]  old_TS4   -7.3538905052041414e-01
    x[11,16]  OBJ       0.005859375
    x[11,16]  onehot_11  1
    x[11,16]  w_lb_11_16  -4.9025936701360941e-02
    x[11,16]  w_ub_11_16  -1.0218978102189782e-01
    x[11,16]  hard_lower  16
    x[11,16]  hard_upper  16
    x[11,16]  old_TS1   -0.784414987221775
    x[11,16]  old_TS2   -1.6350364963503652e+00
    x[11,16]  old_TS3   -1.6350364963503652e+00
    x[11,16]  old_TS4   -0.784414987221775
    x[11,17]  OBJ       0.01171875
    x[11,17]  onehot_11  1
    x[11,17]  w_lb_11_17  -4.9025936701360941e-02
    x[11,17]  w_ub_11_17  -1.0218978102189782e-01
    x[11,17]  hard_lower  17
    x[11,17]  hard_upper  17
    x[11,17]  old_TS1   -0.833440923923136
    x[11,17]  old_TS2   -1.7372262773722631e+00
    x[11,17]  old_TS3   -1.7372262773722631e+00
    x[11,17]  old_TS4   -0.833440923923136
    x[11,18]  OBJ       0.017578125
    x[11,18]  onehot_11  1
    x[11,18]  w_lb_11_18  -4.9025936701360941e-02
    x[11,18]  w_ub_11_18  -1.0218978102189782e-01
    x[11,18]  hard_lower  18
    x[11,18]  hard_upper  18
    x[11,18]  old_TS1   -0.882466860624497
    x[11,18]  old_TS2   -1.8394160583941608e+00
    x[11,18]  old_TS3   -1.8394160583941608e+00
    x[11,18]  old_TS4   -0.882466860624497
    x[11,19]  OBJ       0.0234375
    x[11,19]  onehot_11  1
    x[11,19]  w_lb_11_19  -4.9025936701360941e-02
    x[11,19]  w_ub_11_19  -1.0218978102189782e-01
    x[11,19]  hard_lower  19
    x[11,19]  hard_upper  19
    x[11,19]  old_TS1   -9.3149279732585788e-01
    x[11,19]  old_TS2   -1.9416058394160587e+00
    x[11,19]  old_TS3   -1.9416058394160587e+00
    x[11,19]  old_TS4   -9.3149279732585788e-01
    x[11,20]  OBJ       0.029296875
    x[11,20]  onehot_11  1
    x[11,20]  w_lb_11_20  -4.9025936701360941e-02
    x[11,20]  w_ub_11_20  -1.0218978102189782e-01
    x[11,20]  hard_lower  20
    x[11,20]  hard_upper  20
    x[11,20]  old_TS1   -9.8051873402721879e-01
    x[11,20]  old_TS2   -2.0437956204379564e+00
    x[11,20]  old_TS3   -2.0437956204379564e+00
    x[11,20]  old_TS4   -9.8051873402721879e-01
    x[12,0]   OBJ       4.2187499999999989e-02
    x[12,0]   onehot_12  1
    x[12,0]   w_lb_12_0  -4.9025936701360941e-02
    x[12,0]   w_ub_12_0  -1.0218978102189782e-01
    x[12,1]   OBJ       3.5156249999999993e-02
    x[12,1]   onehot_12  1
    x[12,1]   w_lb_12_1  -4.9025936701360941e-02
    x[12,1]   w_ub_12_1  -1.0218978102189782e-01
    x[12,1]   hard_lower  1
    x[12,1]   hard_upper  1
    x[12,1]   old_TS1   -4.9025936701360941e-02
    x[12,1]   old_TS2   -1.0218978102189782e-01
    x[12,1]   old_TS3   -1.0218978102189782e-01
    x[12,1]   old_TS4   -4.9025936701360941e-02
    x[12,2]   OBJ       2.8124999999999994e-02
    x[12,2]   onehot_12  1
    x[12,2]   w_lb_12_2  -4.9025936701360941e-02
    x[12,2]   w_ub_12_2  -1.0218978102189782e-01
    x[12,2]   hard_lower  2
    x[12,2]   hard_upper  2
    x[12,2]   old_TS1   -9.8051873402721881e-02
    x[12,2]   old_TS2   -2.0437956204379565e-01
    x[12,2]   old_TS3   -2.0437956204379565e-01
    x[12,2]   old_TS4   -9.8051873402721881e-02
    x[12,3]   OBJ       2.1093749999999994e-02
    x[12,3]   onehot_12  1
    x[12,3]   w_lb_12_3  -4.9025936701360941e-02
    x[12,3]   w_ub_12_3  -1.0218978102189782e-01
    x[12,3]   hard_lower  3
    x[12,3]   hard_upper  3
    x[12,3]   old_TS1   -1.4707781010408283e-01
    x[12,3]   old_TS2   -3.0656934306569350e-01
    x[12,3]   old_TS3   -3.0656934306569350e-01
    x[12,3]   old_TS4   -1.4707781010408283e-01
    x[12,4]   OBJ       1.4062499999999997e-02
    x[12,4]   onehot_12  1
    x[12,4]   w_lb_12_4  -4.9025936701360941e-02
    x[12,4]   w_ub_12_4  -1.0218978102189782e-01
    x[12,4]   hard_lower  4
    x[12,4]   hard_upper  4
    x[12,4]   old_TS1   -1.9610374680544376e-01
    x[12,4]   old_TS2   -4.0875912408759130e-01
    x[12,4]   old_TS3   -4.0875912408759130e-01
    x[12,4]   old_TS4   -1.9610374680544376e-01
    x[12,5]   OBJ       7.0312499999999984e-03
    x[12,5]   onehot_12  1
    x[12,5]   w_lb_12_5  -4.9025936701360941e-02
    x[12,5]   w_ub_12_5  -1.0218978102189782e-01
    x[12,5]   hard_lower  5
    x[12,5]   hard_upper  5
    x[12,5]   old_TS1   -2.4512968350680470e-01
    x[12,5]   old_TS2   -5.1094890510948909e-01
    x[12,5]   old_TS3   -5.1094890510948909e-01
    x[12,5]   old_TS4   -2.4512968350680470e-01
    x[12,6]   onehot_12  1
    x[12,6]   w_lb_12_6  -4.9025936701360941e-02
    x[12,6]   w_ub_12_6  -1.0218978102189782e-01
    x[12,6]   hard_lower  6
    x[12,6]   hard_upper  6
    x[12,6]   old_TS1   -2.9415562020816566e-01
    x[12,6]   old_TS2   -0.613138686131387
    x[12,6]   old_TS3   -0.613138686131387
    x[12,6]   old_TS4   -2.9415562020816566e-01
    x[12,7]   OBJ       -7.0312499999999993e-03
    x[12,7]   onehot_12  1
    x[12,7]   w_lb_12_7  -4.9025936701360941e-02
    x[12,7]   w_ub_12_7  -1.0218978102189782e-01
    x[12,7]   hard_lower  7
    x[12,7]   hard_upper  7
    x[12,7]   old_TS1   -3.4318155690952656e-01
    x[12,7]   old_TS2   -7.1532846715328480e-01
    x[12,7]   old_TS3   -7.1532846715328480e-01
    x[12,7]   old_TS4   -3.4318155690952656e-01
    x[12,8]   OBJ       -1.4062499999999999e-02
    x[12,8]   onehot_12  1
    x[12,8]   w_lb_12_8  -4.9025936701360941e-02
    x[12,8]   w_ub_12_8  -1.0218978102189782e-01
    x[12,8]   hard_lower  8
    x[12,8]   hard_upper  8
    x[12,8]   old_TS1   -3.9220749361088753e-01
    x[12,8]   old_TS2   -8.1751824817518259e-01
    x[12,8]   old_TS3   -8.1751824817518259e-01
    x[12,8]   old_TS4   -3.9220749361088753e-01
    x[12,9]   OBJ       -2.1093749999999998e-02
    x[12,9]   onehot_12  1
    x[12,9]   w_lb_12_9  -4.9025936701360941e-02
    x[12,9]   w_ub_12_9  -1.0218978102189782e-01
    x[12,9]   hard_lower  9
    x[12,9]   hard_upper  9
    x[12,9]   old_TS1   -4.4123343031224849e-01
    x[12,9]   old_TS2   -9.1970802919708039e-01
    x[12,9]   old_TS3   -9.1970802919708039e-01
    x[12,9]   old_TS4   -4.4123343031224849e-01
    x[12,10]  OBJ       -2.8124999999999997e-02
    x[12,10]  onehot_12  1
    x[12,10]  w_lb_12_10  -4.9025936701360941e-02
    x[12,10]  w_ub_12_10  -1.0218978102189782e-01
    x[12,10]  hard_lower  10
    x[12,10]  hard_upper  10
    x[12,10]  old_TS1   -4.9025936701360939e-01
    x[12,10]  old_TS2   -1.0218978102189782e+00
    x[12,10]  old_TS3   -1.0218978102189782e+00
    x[12,10]  old_TS4   -4.9025936701360939e-01
    x[12,11]  OBJ       -0.03515625
    x[12,11]  onehot_12  1
    x[12,11]  w_lb_12_11  -4.9025936701360941e-02
    x[12,11]  w_ub_12_11  -1.0218978102189782e-01
    x[12,11]  hard_lower  11
    x[12,11]  hard_upper  11
    x[12,11]  old_TS1   -5.3928530371497030e-01
    x[12,11]  old_TS2   -1.1240875912408761e+00
    x[12,11]  old_TS3   -1.1240875912408761e+00
    x[12,11]  old_TS4   -5.3928530371497030e-01
    x[12,12]  OBJ       -4.2187499999999996e-02
    x[12,12]  onehot_12  1
    x[12,12]  w_lb_12_12  -4.9025936701360941e-02
    x[12,12]  w_ub_12_12  -1.0218978102189782e-01
    x[12,12]  hard_lower  12
    x[12,12]  hard_upper  12
    x[12,12]  old_TS1   -5.8831124041633132e-01
    x[12,12]  old_TS2   -1.2262773722627740e+00
    x[12,12]  old_TS3   -1.2262773722627740e+00
    x[12,12]  old_TS4   -5.8831124041633132e-01
    x[12,13]  OBJ       -3.5156250000000007e-02
    x[12,13]  onehot_12  1
    x[12,13]  w_lb_12_13  -4.9025936701360941e-02
    x[12,13]  w_ub_12_13  -1.0218978102189782e-01
    x[12,13]  hard_lower  13
    x[12,13]  hard_upper  13
    x[12,13]  old_TS1   -6.3733717711769222e-01
    x[12,13]  old_TS2   -1.3284671532846717e+00
    x[12,13]  old_TS3   -1.3284671532846717e+00
    x[12,13]  old_TS4   -6.3733717711769222e-01
    x[12,14]  OBJ       -2.8125000000000008e-02
    x[12,14]  onehot_12  1
    x[12,14]  w_lb_12_14  -4.9025936701360941e-02
    x[12,14]  w_ub_12_14  -1.0218978102189782e-01
    x[12,14]  hard_lower  14
    x[12,14]  hard_upper  14
    x[12,14]  old_TS1   -6.8636311381905313e-01
    x[12,14]  old_TS2   -1.4306569343065696e+00
    x[12,14]  old_TS3   -1.4306569343065696e+00
    x[12,14]  old_TS4   -6.8636311381905313e-01
    x[12,15]  OBJ       -2.1093750000000008e-02
    x[12,15]  onehot_12  1
    x[12,15]  w_lb_12_15  -4.9025936701360941e-02
    x[12,15]  w_ub_12_15  -1.0218978102189782e-01
    x[12,15]  hard_lower  15
    x[12,15]  hard_upper  15
    x[12,15]  old_TS1   -7.3538905052041414e-01
    x[12,15]  old_TS2   -1.5328467153284673e+00
    x[12,15]  old_TS3   -1.5328467153284673e+00
    x[12,15]  old_TS4   -7.3538905052041414e-01
    x[12,16]  OBJ       -1.4062500000000007e-02
    x[12,16]  onehot_12  1
    x[12,16]  w_lb_12_16  -4.9025936701360941e-02
    x[12,16]  w_ub_12_16  -1.0218978102189782e-01
    x[12,16]  hard_lower  16
    x[12,16]  hard_upper  16
    x[12,16]  old_TS1   -0.784414987221775
    x[12,16]  old_TS2   -1.6350364963503652e+00
    x[12,16]  old_TS3   -1.6350364963503652e+00
    x[12,16]  old_TS4   -0.784414987221775
    x[12,17]  OBJ       -7.0312500000000088e-03
    x[12,17]  onehot_12  1
    x[12,17]  w_lb_12_17  -4.9025936701360941e-02
    x[12,17]  w_ub_12_17  -1.0218978102189782e-01
    x[12,17]  hard_lower  17
    x[12,17]  hard_upper  17
    x[12,17]  old_TS1   -0.833440923923136
    x[12,17]  old_TS2   -1.7372262773722631e+00
    x[12,17]  old_TS3   -1.7372262773722631e+00
    x[12,17]  old_TS4   -0.833440923923136
    x[12,18]  OBJ       -9.3675067702747574e-18
    x[12,18]  onehot_12  1
    x[12,18]  w_lb_12_18  -4.9025936701360941e-02
    x[12,18]  w_ub_12_18  -1.0218978102189782e-01
    x[12,18]  hard_lower  18
    x[12,18]  hard_upper  18
    x[12,18]  old_TS1   -0.882466860624497
    x[12,18]  old_TS2   -1.8394160583941608e+00
    x[12,18]  old_TS3   -1.8394160583941608e+00
    x[12,18]  old_TS4   -0.882466860624497
    x[12,19]  OBJ       7.0312499999999889e-03
    x[12,19]  onehot_12  1
    x[12,19]  w_lb_12_19  -4.9025936701360941e-02
    x[12,19]  w_ub_12_19  -1.0218978102189782e-01
    x[12,19]  hard_lower  19
    x[12,19]  hard_upper  19
    x[12,19]  old_TS1   -9.3149279732585788e-01
    x[12,19]  old_TS2   -1.9416058394160587e+00
    x[12,19]  old_TS3   -1.9416058394160587e+00
    x[12,19]  old_TS4   -9.3149279732585788e-01
    x[12,20]  OBJ       1.4062499999999988e-02
    x[12,20]  onehot_12  1
    x[12,20]  w_lb_12_20  -4.9025936701360941e-02
    x[12,20]  w_ub_12_20  -1.0218978102189782e-01
    x[12,20]  hard_lower  20
    x[12,20]  hard_upper  20
    x[12,20]  old_TS1   -9.8051873402721879e-01
    x[12,20]  old_TS2   -2.0437956204379564e+00
    x[12,20]  old_TS3   -2.0437956204379564e+00
    x[12,20]  old_TS4   -9.8051873402721879e-01
    x[12,21]  OBJ       2.1093749999999984e-02
    x[12,21]  onehot_12  1
    x[12,21]  w_lb_12_21  -4.9025936701360941e-02
    x[12,21]  w_ub_12_21  -1.0218978102189782e-01
    x[12,21]  hard_lower  21
    x[12,21]  hard_upper  21
    x[12,21]  old_TS1   -1.0295446707285798e+00
    x[12,21]  old_TS2   -2.1459854014598543e+00
    x[12,21]  old_TS3   -2.1459854014598543e+00
    x[12,21]  old_TS4   -1.0295446707285798e+00
    x[12,22]  OBJ       2.8124999999999983e-02
    x[12,22]  onehot_12  1
    x[12,22]  w_lb_12_22  -4.9025936701360941e-02
    x[12,22]  w_ub_12_22  -1.0218978102189782e-01
    x[12,22]  hard_lower  22
    x[12,22]  hard_upper  22
    x[12,22]  old_TS1   -1.0785706074299406e+00
    x[12,22]  old_TS2   -2.2481751824817522e+00
    x[12,22]  old_TS3   -2.2481751824817522e+00
    x[12,22]  old_TS4   -1.0785706074299406e+00
    x[12,23]  OBJ       3.5156249999999979e-02
    x[12,23]  onehot_12  1
    x[12,23]  w_lb_12_23  -4.9025936701360941e-02
    x[12,23]  w_ub_12_23  -1.0218978102189782e-01
    x[12,23]  hard_lower  23
    x[12,23]  hard_upper  23
    x[12,23]  old_TS1   -1.1275965441313016e+00
    x[12,23]  old_TS2   -2.35036496350365
    x[12,23]  old_TS3   -2.35036496350365
    x[12,23]  old_TS4   -1.1275965441313016e+00
    x[12,24]  OBJ       4.2187499999999982e-02
    x[12,24]  onehot_12  1
    x[12,24]  w_lb_12_24  -4.9025936701360941e-02
    x[12,24]  w_ub_12_24  -1.0218978102189782e-01
    x[12,24]  hard_lower  24
    x[12,24]  hard_upper  24
    x[12,24]  old_TS1   -1.1766224808326626e+00
    x[12,24]  old_TS2   -2.4525547445255480e+00
    x[12,24]  old_TS3   -2.4525547445255480e+00
    x[12,24]  old_TS4   -1.1766224808326626e+00
    x[13,0]   OBJ       0.075
    x[13,0]   onehot_13  1
    x[13,0]   w_lb_13_0  -4.9025936701360941e-02
    x[13,0]   w_ub_13_0  -1.0218978102189782e-01
    x[13,1]   OBJ       6.5624999999999989e-02
    x[13,1]   onehot_13  1
    x[13,1]   w_lb_13_1  -4.9025936701360941e-02
    x[13,1]   w_ub_13_1  -1.0218978102189782e-01
    x[13,1]   hard_lower  1
    x[13,1]   hard_upper  1
    x[13,1]   old_TS1   -4.9025936701360941e-02
    x[13,1]   old_TS2   -1.0218978102189782e-01
    x[13,1]   old_TS3   -1.0218978102189782e-01
    x[13,1]   old_TS4   -4.9025936701360941e-02
    x[13,2]   OBJ       5.6249999999999994e-02
    x[13,2]   onehot_13  1
    x[13,2]   w_lb_13_2  -4.9025936701360941e-02
    x[13,2]   w_ub_13_2  -1.0218978102189782e-01
    x[13,2]   hard_lower  2
    x[13,2]   hard_upper  2
    x[13,2]   old_TS1   -9.8051873402721881e-02
    x[13,2]   old_TS2   -2.0437956204379565e-01
    x[13,2]   old_TS3   -2.0437956204379565e-01
    x[13,2]   old_TS4   -9.8051873402721881e-02
    x[13,3]   OBJ       4.6874999999999993e-02
    x[13,3]   onehot_13  1
    x[13,3]   w_lb_13_3  -4.9025936701360941e-02
    x[13,3]   w_ub_13_3  -1.0218978102189782e-01
    x[13,3]   hard_lower  3
    x[13,3]   hard_upper  3
    x[13,3]   old_TS1   -1.4707781010408283e-01
    x[13,3]   old_TS2   -3.0656934306569350e-01
    x[13,3]   old_TS3   -3.0656934306569350e-01
    x[13,3]   old_TS4   -1.4707781010408283e-01
    x[13,4]   OBJ       0.0375
    x[13,4]   onehot_13  1
    x[13,4]   w_lb_13_4  -4.9025936701360941e-02
    x[13,4]   w_ub_13_4  -1.0218978102189782e-01
    x[13,4]   hard_lower  4
    x[13,4]   hard_upper  4
    x[13,4]   old_TS1   -1.9610374680544376e-01
    x[13,4]   old_TS2   -4.0875912408759130e-01
    x[13,4]   old_TS3   -4.0875912408759130e-01
    x[13,4]   old_TS4   -1.9610374680544376e-01
    x[13,5]   OBJ       2.8124999999999997e-02
    x[13,5]   onehot_13  1
    x[13,5]   w_lb_13_5  -4.9025936701360941e-02
    x[13,5]   w_ub_13_5  -1.0218978102189782e-01
    x[13,5]   hard_lower  5
    x[13,5]   hard_upper  5
    x[13,5]   old_TS1   -2.4512968350680470e-01
    x[13,5]   old_TS2   -5.1094890510948909e-01
    x[13,5]   old_TS3   -5.1094890510948909e-01
    x[13,5]   old_TS4   -2.4512968350680470e-01
    x[13,6]   OBJ       0.01875
    x[13,6]   onehot_13  1
    x[13,6]   w_lb_13_6  -4.9025936701360941e-02
    x[13,6]   w_ub_13_6  -1.0218978102189782e-01
    x[13,6]   hard_lower  6
    x[13,6]   hard_upper  6
    x[13,6]   old_TS1   -2.9415562020816566e-01
    x[13,6]   old_TS2   -0.613138686131387
    x[13,6]   old_TS3   -0.613138686131387
    x[13,6]   old_TS4   -2.9415562020816566e-01
    x[13,7]   OBJ       0.009375
    x[13,7]   onehot_13  1
    x[13,7]   w_lb_13_7  -4.9025936701360941e-02
    x[13,7]   w_ub_13_7  -1.0218978102189782e-01
    x[13,7]   hard_lower  7
    x[13,7]   hard_upper  7
    x[13,7]   old_TS1   -3.4318155690952656e-01
    x[13,7]   old_TS2   -7.1532846715328480e-01
    x[13,7]   old_TS3   -7.1532846715328480e-01
    x[13,7]   old_TS4   -3.4318155690952656e-01
    x[13,8]   onehot_13  1
    x[13,8]   w_lb_13_8  -4.9025936701360941e-02
    x[13,8]   w_ub_13_8  -1.0218978102189782e-01
    x[13,8]   hard_lower  8
    x[13,8]   hard_upper  8
    x[13,8]   old_TS1   -3.9220749361088753e-01
    x[13,8]   old_TS2   -8.1751824817518259e-01
    x[13,8]   old_TS3   -8.1751824817518259e-01
    x[13,8]   old_TS4   -3.9220749361088753e-01
    x[13,9]   OBJ       -0.009375
    x[13,9]   onehot_13  1
    x[13,9]   w_lb_13_9  -4.9025936701360941e-02
    x[13,9]   w_ub_13_9  -1.0218978102189782e-01
    x[13,9]   hard_lower  9
    x[13,9]   hard_upper  9
    x[13,9]   old_TS1   -4.4123343031224849e-01
    x[13,9]   old_TS2   -9.1970802919708039e-01
    x[13,9]   old_TS3   -9.1970802919708039e-01
    x[13,9]   old_TS4   -4.4123343031224849e-01
    x[13,10]  OBJ       -0.01875
    x[13,10]  onehot_13  1
    x[13,10]  w_lb_13_10  -4.9025936701360941e-02
    x[13,10]  w_ub_13_10  -1.0218978102189782e-01
    x[13,10]  hard_lower  10
    x[13,10]  hard_upper  10
    x[13,10]  old_TS1   -4.9025936701360939e-01
    x[13,10]  old_TS2   -1.0218978102189782e+00
    x[13,10]  old_TS3   -1.0218978102189782e+00
    x[13,10]  old_TS4   -4.9025936701360939e-01
    x[13,11]  OBJ       -0.028125
    x[13,11]  onehot_13  1
    x[13,11]  w_lb_13_11  -4.9025936701360941e-02
    x[13,11]  w_ub_13_11  -1.0218978102189782e-01
    x[13,11]  hard_lower  11
    x[13,11]  hard_upper  11
    x[13,11]  old_TS1   -5.3928530371497030e-01
    x[13,11]  old_TS2   -1.1240875912408761e+00
    x[13,11]  old_TS3   -1.1240875912408761e+00
    x[13,11]  old_TS4   -5.3928530371497030e-01
    x[13,12]  OBJ       -0.0375
    x[13,12]  onehot_13  1
    x[13,12]  w_lb_13_12  -4.9025936701360941e-02
    x[13,12]  w_ub_13_12  -1.0218978102189782e-01
    x[13,12]  hard_lower  12
    x[13,12]  hard_upper  12
    x[13,12]  old_TS1   -5.8831124041633132e-01
    x[13,12]  old_TS2   -1.2262773722627740e+00
    x[13,12]  old_TS3   -1.2262773722627740e+00
    x[13,12]  old_TS4   -5.8831124041633132e-01
    x[13,13]  OBJ       -0.046875
    x[13,13]  onehot_13  1
    x[13,13]  w_lb_13_13  -4.9025936701360941e-02
    x[13,13]  w_ub_13_13  -1.0218978102189782e-01
    x[13,13]  hard_lower  13
    x[13,13]  hard_upper  13
    x[13,13]  old_TS1   -6.3733717711769222e-01
    x[13,13]  old_TS2   -1.3284671532846717e+00
    x[13,13]  old_TS3   -1.3284671532846717e+00
    x[13,13]  old_TS4   -6.3733717711769222e-01
    x[13,14]  OBJ       -0.05625
    x[13,14]  onehot_13  1
    x[13,14]  w_lb_13_14  -4.9025936701360941e-02
    x[13,14]  w_ub_13_14  -1.0218978102189782e-01
    x[13,14]  hard_lower  14
    x[13,14]  hard_upper  14
    x[13,14]  old_TS1   -6.8636311381905313e-01
    x[13,14]  old_TS2   -1.4306569343065696e+00
    x[13,14]  old_TS3   -1.4306569343065696e+00
    x[13,14]  old_TS4   -6.8636311381905313e-01
    x[13,15]  OBJ       -0.065625
    x[13,15]  onehot_13  1
    x[13,15]  w_lb_13_15  -4.9025936701360941e-02
    x[13,15]  w_ub_13_15  -1.0218978102189782e-01
    x[13,15]  hard_lower  15
    x[13,15]  hard_upper  15
    x[13,15]  old_TS1   -7.3538905052041414e-01
    x[13,15]  old_TS2   -1.5328467153284673e+00
    x[13,15]  old_TS3   -1.5328467153284673e+00
    x[13,15]  old_TS4   -7.3538905052041414e-01
    x[13,16]  OBJ       -0.075
    x[13,16]  onehot_13  1
    x[13,16]  w_lb_13_16  -4.9025936701360941e-02
    x[13,16]  w_ub_13_16  -1.0218978102189782e-01
    x[13,16]  hard_lower  16
    x[13,16]  hard_upper  16
    x[13,16]  old_TS1   -0.784414987221775
    x[13,16]  old_TS2   -1.6350364963503652e+00
    x[13,16]  old_TS3   -1.6350364963503652e+00
    x[13,16]  old_TS4   -0.784414987221775
    x[13,17]  OBJ       -0.065625
    x[13,17]  onehot_13  1
    x[13,17]  w_lb_13_17  -4.9025936701360941e-02
    x[13,17]  w_ub_13_17  -1.0218978102189782e-01
    x[13,17]  hard_lower  17
    x[13,17]  hard_upper  17
    x[13,17]  old_TS1   -0.833440923923136
    x[13,17]  old_TS2   -1.7372262773722631e+00
    x[13,17]  old_TS3   -1.7372262773722631e+00
    x[13,17]  old_TS4   -0.833440923923136
    x[13,18]  OBJ       -0.05625
    x[13,18]  onehot_13  1
    x[13,18]  w_lb_13_18  -4.9025936701360941e-02
    x[13,18]  w_ub_13_18  -1.0218978102189782e-01
    x[13,18]  hard_lower  18
    x[13,18]  hard_upper  18
    x[13,18]  old_TS1   -0.882466860624497
    x[13,18]  old_TS2   -1.8394160583941608e+00
    x[13,18]  old_TS3   -1.8394160583941608e+00
    x[13,18]  old_TS4   -0.882466860624497
    x[13,19]  OBJ       -0.046875
    x[13,19]  onehot_13  1
    x[13,19]  w_lb_13_19  -4.9025936701360941e-02
    x[13,19]  w_ub_13_19  -1.0218978102189782e-01
    x[13,19]  hard_lower  19
    x[13,19]  hard_upper  19
    x[13,19]  old_TS1   -9.3149279732585788e-01
    x[13,19]  old_TS2   -1.9416058394160587e+00
    x[13,19]  old_TS3   -1.9416058394160587e+00
    x[13,19]  old_TS4   -9.3149279732585788e-01
    x[13,20]  OBJ       -0.0375
    x[13,20]  onehot_13  1
    x[13,20]  w_lb_13_20  -4.9025936701360941e-02
    x[13,20]  w_ub_13_20  -1.0218978102189782e-01
    x[13,20]  hard_lower  20
    x[13,20]  hard_upper  20
    x[13,20]  old_TS1   -9.8051873402721879e-01
    x[13,20]  old_TS2   -2.0437956204379564e+00
    x[13,20]  old_TS3   -2.0437956204379564e+00
    x[13,20]  old_TS4   -9.8051873402721879e-01
    x[13,21]  OBJ       -0.028125
    x[13,21]  onehot_13  1
    x[13,21]  w_lb_13_21  -4.9025936701360941e-02
    x[13,21]  w_ub_13_21  -1.0218978102189782e-01
    x[13,21]  hard_lower  21
    x[13,21]  hard_upper  21
    x[13,21]  old_TS1   -1.0295446707285798e+00
    x[13,21]  old_TS2   -2.1459854014598543e+00
    x[13,21]  old_TS3   -2.1459854014598543e+00
    x[13,21]  old_TS4   -1.0295446707285798e+00
    x[13,22]  OBJ       -0.01875
    x[13,22]  onehot_13  1
    x[13,22]  w_lb_13_22  -4.9025936701360941e-02
    x[13,22]  w_ub_13_22  -1.0218978102189782e-01
    x[13,22]  hard_lower  22
    x[13,22]  hard_upper  22
    x[13,22]  old_TS1   -1.0785706074299406e+00
    x[13,22]  old_TS2   -2.2481751824817522e+00
    x[13,22]  old_TS3   -2.2481751824817522e+00
    x[13,22]  old_TS4   -1.0785706074299406e+00
    x[13,23]  OBJ       -0.009375
    x[13,23]  onehot_13  1
    x[13,23]  w_lb_13_23  -4.9025936701360941e-02
    x[13,23]  w_ub_13_23  -1.0218978102189782e-01
    x[13,23]  hard_lower  23
    x[13,23]  hard_upper  23
    x[13,23]  old_TS1   -1.1275965441313016e+00
    x[13,23]  old_TS2   -2.35036496350365
    x[13,23]  old_TS3   -2.35036496350365
    x[13,23]  old_TS4   -1.1275965441313016e+00
    x[13,24]  onehot_13  1
    x[13,24]  w_lb_13_24  -4.9025936701360941e-02
    x[13,24]  w_ub_13_24  -1.0218978102189782e-01
    x[13,24]  hard_lower  24
    x[13,24]  hard_upper  24
    x[13,24]  old_TS1   -1.1766224808326626e+00
    x[13,24]  old_TS2   -2.4525547445255480e+00
    x[13,24]  old_TS3   -2.4525547445255480e+00
    x[13,24]  old_TS4   -1.1766224808326626e+00
    x[13,25]  OBJ       0.009375
    x[13,25]  onehot_13  1
    x[13,25]  w_lb_13_25  -4.9025936701360941e-02
    x[13,25]  w_ub_13_25  -1.0218978102189782e-01
    x[13,25]  hard_lower  25
    x[13,25]  hard_upper  25
    x[13,25]  old_TS1   -1.2256484175340234e+00
    x[13,25]  old_TS2   -2.5547445255474455e+00
    x[13,25]  old_TS3   -2.5547445255474455e+00
    x[13,25]  old_TS4   -1.2256484175340234e+00
    x[13,26]  OBJ       0.01875
    x[13,26]  onehot_13  1
    x[13,26]  w_lb_13_26  -4.9025936701360941e-02
    x[13,26]  w_ub_13_26  -1.0218978102189782e-01
    x[13,26]  hard_lower  26
    x[13,26]  hard_upper  26
    x[13,26]  old_TS1   -1.2746743542353844e+00
    x[13,26]  old_TS2   -2.6569343065693434e+00
    x[13,26]  old_TS3   -2.6569343065693434e+00
    x[13,26]  old_TS4   -1.2746743542353844e+00
    x[13,27]  OBJ       2.8124999999999997e-02
    x[13,27]  onehot_13  1
    x[13,27]  w_lb_13_27  -4.9025936701360941e-02
    x[13,27]  w_ub_13_27  -1.0218978102189782e-01
    x[13,27]  hard_lower  27
    x[13,27]  hard_upper  27
    x[13,27]  old_TS1   -1.3237002909367455e+00
    x[13,27]  old_TS2   -2.7591240875912413e+00
    x[13,27]  old_TS3   -2.7591240875912413e+00
    x[13,27]  old_TS4   -1.3237002909367455e+00
    x[13,28]  OBJ       0.0375
    x[13,28]  onehot_13  1
    x[13,28]  w_lb_13_28  -4.9025936701360941e-02
    x[13,28]  w_ub_13_28  -1.0218978102189782e-01
    x[13,28]  hard_lower  28
    x[13,28]  hard_upper  28
    x[13,28]  old_TS1   -1.3727262276381063e+00
    x[13,28]  old_TS2   -2.8613138686131392e+00
    x[13,28]  old_TS3   -2.8613138686131392e+00
    x[13,28]  old_TS4   -1.3727262276381063e+00
    x[13,29]  OBJ       4.6874999999999993e-02
    x[13,29]  onehot_13  1
    x[13,29]  w_lb_13_29  -4.9025936701360941e-02
    x[13,29]  w_ub_13_29  -1.0218978102189782e-01
    x[13,29]  hard_lower  29
    x[13,29]  hard_upper  29
    x[13,29]  old_TS1   -1.4217521643394673e+00
    x[13,29]  old_TS2   -2.9635036496350371e+00
    x[13,29]  old_TS3   -2.9635036496350371e+00
    x[13,29]  old_TS4   -1.4217521643394673e+00
    x[14,0]   OBJ       3.5449199999999993e-02
    x[14,0]   onehot_14  1
    x[14,0]   w_lb_14_0  -4.9025936701360941e-02
    x[14,0]   w_ub_14_0  -1.0218978102189782e-01
    x[14,1]   OBJ       2.9003890909090908e-02
    x[14,1]   onehot_14  1
    x[14,1]   w_lb_14_1  -4.9025936701360941e-02
    x[14,1]   w_ub_14_1  -1.0218978102189782e-01
    x[14,1]   hard_lower  1
    x[14,1]   hard_upper  1
    x[14,1]   old_TS1   -4.9025936701360941e-02
    x[14,1]   old_TS2   -1.0218978102189782e-01
    x[14,1]   old_TS3   -1.0218978102189782e-01
    x[14,1]   old_TS4   -4.9025936701360941e-02
    x[14,2]   OBJ       2.2558581818181815e-02
    x[14,2]   onehot_14  1
    x[14,2]   w_lb_14_2  -4.9025936701360941e-02
    x[14,2]   w_ub_14_2  -1.0218978102189782e-01
    x[14,2]   hard_lower  2
    x[14,2]   hard_upper  2
    x[14,2]   old_TS1   -9.8051873402721881e-02
    x[14,2]   old_TS2   -2.0437956204379565e-01
    x[14,2]   old_TS3   -2.0437956204379565e-01
    x[14,2]   old_TS4   -9.8051873402721881e-02
    x[14,3]   OBJ       1.6113272727272723e-02
    x[14,3]   onehot_14  1
    x[14,3]   w_lb_14_3  -4.9025936701360941e-02
    x[14,3]   w_ub_14_3  -1.0218978102189782e-01
    x[14,3]   hard_lower  3
    x[14,3]   hard_upper  3
    x[14,3]   old_TS1   -1.4707781010408283e-01
    x[14,3]   old_TS2   -3.0656934306569350e-01
    x[14,3]   old_TS3   -3.0656934306569350e-01
    x[14,3]   old_TS4   -1.4707781010408283e-01
    x[14,4]   OBJ       9.6679636363636336e-03
    x[14,4]   onehot_14  1
    x[14,4]   w_lb_14_4  -4.9025936701360941e-02
    x[14,4]   w_ub_14_4  -1.0218978102189782e-01
    x[14,4]   hard_lower  4
    x[14,4]   hard_upper  4
    x[14,4]   old_TS1   -1.9610374680544376e-01
    x[14,4]   old_TS2   -4.0875912408759130e-01
    x[14,4]   old_TS3   -4.0875912408759130e-01
    x[14,4]   old_TS4   -1.9610374680544376e-01
    x[14,5]   OBJ       3.2226545454545432e-03
    x[14,5]   onehot_14  1
    x[14,5]   w_lb_14_5  -4.9025936701360941e-02
    x[14,5]   w_ub_14_5  -1.0218978102189782e-01
    x[14,5]   hard_lower  5
    x[14,5]   hard_upper  5
    x[14,5]   old_TS1   -2.4512968350680470e-01
    x[14,5]   old_TS2   -5.1094890510948909e-01
    x[14,5]   old_TS3   -5.1094890510948909e-01
    x[14,5]   old_TS4   -2.4512968350680470e-01
    x[14,6]   OBJ       -3.2226545454545476e-03
    x[14,6]   onehot_14  1
    x[14,6]   w_lb_14_6  -4.9025936701360941e-02
    x[14,6]   w_ub_14_6  -1.0218978102189782e-01
    x[14,6]   hard_lower  6
    x[14,6]   hard_upper  6
    x[14,6]   old_TS1   -2.9415562020816566e-01
    x[14,6]   old_TS2   -0.613138686131387
    x[14,6]   old_TS3   -0.613138686131387
    x[14,6]   old_TS4   -2.9415562020816566e-01
    x[14,7]   OBJ       -9.6679636363636388e-03
    x[14,7]   onehot_14  1
    x[14,7]   w_lb_14_7  -4.9025936701360941e-02
    x[14,7]   w_ub_14_7  -1.0218978102189782e-01
    x[14,7]   hard_lower  7
    x[14,7]   hard_upper  7
    x[14,7]   old_TS1   -3.4318155690952656e-01
    x[14,7]   old_TS2   -7.1532846715328480e-01
    x[14,7]   old_TS3   -7.1532846715328480e-01
    x[14,7]   old_TS4   -3.4318155690952656e-01
    x[14,8]   OBJ       -1.6113272727272733e-02
    x[14,8]   onehot_14  1
    x[14,8]   w_lb_14_8  -4.9025936701360941e-02
    x[14,8]   w_ub_14_8  -1.0218978102189782e-01
    x[14,8]   hard_lower  8
    x[14,8]   hard_upper  8
    x[14,8]   old_TS1   -3.9220749361088753e-01
    x[14,8]   old_TS2   -8.1751824817518259e-01
    x[14,8]   old_TS3   -8.1751824817518259e-01
    x[14,8]   old_TS4   -3.9220749361088753e-01
    x[14,9]   OBJ       -2.2558581818181822e-02
    x[14,9]   onehot_14  1
    x[14,9]   w_lb_14_9  -4.9025936701360941e-02
    x[14,9]   w_ub_14_9  -1.0218978102189782e-01
    x[14,9]   hard_lower  9
    x[14,9]   hard_upper  9
    x[14,9]   old_TS1   -4.4123343031224849e-01
    x[14,9]   old_TS2   -9.1970802919708039e-01
    x[14,9]   old_TS3   -9.1970802919708039e-01
    x[14,9]   old_TS4   -4.4123343031224849e-01
    x[14,10]  OBJ       -2.9003890909090915e-02
    x[14,10]  onehot_14  1
    x[14,10]  w_lb_14_10  -4.9025936701360941e-02
    x[14,10]  w_ub_14_10  -1.0218978102189782e-01
    x[14,10]  hard_lower  10
    x[14,10]  hard_upper  10
    x[14,10]  old_TS1   -4.9025936701360939e-01
    x[14,10]  old_TS2   -1.0218978102189782e+00
    x[14,10]  old_TS3   -1.0218978102189782e+00
    x[14,10]  old_TS4   -4.9025936701360939e-01
    x[14,11]  OBJ       -0.0354492
    x[14,11]  onehot_14  1
    x[14,11]  w_lb_14_11  -4.9025936701360941e-02
    x[14,11]  w_ub_14_11  -1.0218978102189782e-01
    x[14,11]  hard_lower  11
    x[14,11]  hard_upper  11
    x[14,11]  old_TS1   -5.3928530371497030e-01
    x[14,11]  old_TS2   -1.1240875912408761e+00
    x[14,11]  old_TS3   -1.1240875912408761e+00
    x[14,11]  old_TS4   -5.3928530371497030e-01
    x[14,12]  OBJ       -2.9003890909090911e-02
    x[14,12]  onehot_14  1
    x[14,12]  w_lb_14_12  -4.9025936701360941e-02
    x[14,12]  w_ub_14_12  -1.0218978102189782e-01
    x[14,12]  hard_lower  12
    x[14,12]  hard_upper  12
    x[14,12]  old_TS1   -5.8831124041633132e-01
    x[14,12]  old_TS2   -1.2262773722627740e+00
    x[14,12]  old_TS3   -1.2262773722627740e+00
    x[14,12]  old_TS4   -5.8831124041633132e-01
    x[14,13]  OBJ       -2.2558581818181819e-02
    x[14,13]  onehot_14  1
    x[14,13]  w_lb_14_13  -4.9025936701360941e-02
    x[14,13]  w_ub_14_13  -1.0218978102189782e-01
    x[14,13]  hard_lower  13
    x[14,13]  hard_upper  13
    x[14,13]  old_TS1   -6.3733717711769222e-01
    x[14,13]  old_TS2   -1.3284671532846717e+00
    x[14,13]  old_TS3   -1.3284671532846717e+00
    x[14,13]  old_TS4   -6.3733717711769222e-01
    x[14,14]  OBJ       -1.6113272727272726e-02
    x[14,14]  onehot_14  1
    x[14,14]  w_lb_14_14  -4.9025936701360941e-02
    x[14,14]  w_ub_14_14  -1.0218978102189782e-01
    x[14,14]  hard_lower  14
    x[14,14]  hard_upper  14
    x[14,14]  old_TS1   -6.8636311381905313e-01
    x[14,14]  old_TS2   -1.4306569343065696e+00
    x[14,14]  old_TS3   -1.4306569343065696e+00
    x[14,14]  old_TS4   -6.8636311381905313e-01
    x[14,15]  OBJ       -9.6679636363636353e-03
    x[14,15]  onehot_14  1
    x[14,15]  w_lb_14_15  -4.9025936701360941e-02
    x[14,15]  w_ub_14_15  -1.0218978102189782e-01
    x[14,15]  hard_lower  15
    x[14,15]  hard_upper  15
    x[14,15]  old_TS1   -7.3538905052041414e-01
    x[14,15]  old_TS2   -1.5328467153284673e+00
    x[14,15]  old_TS3   -1.5328467153284673e+00
    x[14,15]  old_TS4   -7.3538905052041414e-01
    x[14,16]  OBJ       -3.2226545454545437e-03
    x[14,16]  onehot_14  1
    x[14,16]  w_lb_14_16  -4.9025936701360941e-02
    x[14,16]  w_ub_14_16  -1.0218978102189782e-01
    x[14,16]  hard_lower  16
    x[14,16]  hard_upper  16
    x[14,16]  old_TS1   -0.784414987221775
    x[14,16]  old_TS2   -1.6350364963503652e+00
    x[14,16]  old_TS3   -1.6350364963503652e+00
    x[14,16]  old_TS4   -0.784414987221775
    x[14,17]  OBJ       3.2226545454545471e-03
    x[14,17]  onehot_14  1
    x[14,17]  w_lb_14_17  -4.9025936701360941e-02
    x[14,17]  w_ub_14_17  -1.0218978102189782e-01
    x[14,17]  hard_lower  17
    x[14,17]  hard_upper  17
    x[14,17]  old_TS1   -0.833440923923136
    x[14,17]  old_TS2   -1.7372262773722631e+00
    x[14,17]  old_TS3   -1.7372262773722631e+00
    x[14,17]  old_TS4   -0.833440923923136
    x[14,18]  OBJ       9.6679636363636370e-03
    x[14,18]  onehot_14  1
    x[14,18]  w_lb_14_18  -4.9025936701360941e-02
    x[14,18]  w_ub_14_18  -1.0218978102189782e-01
    x[14,18]  hard_lower  18
    x[14,18]  hard_upper  18
    x[14,18]  old_TS1   -0.882466860624497
    x[14,18]  old_TS2   -1.8394160583941608e+00
    x[14,18]  old_TS3   -1.8394160583941608e+00
    x[14,18]  old_TS4   -0.882466860624497
    x[14,19]  OBJ       1.6113272727272730e-02
    x[14,19]  onehot_14  1
    x[14,19]  w_lb_14_19  -4.9025936701360941e-02
    x[14,19]  w_ub_14_19  -1.0218978102189782e-01
    x[14,19]  hard_lower  19
    x[14,19]  hard_upper  19
    x[14,19]  old_TS1   -9.3149279732585788e-01
    x[14,19]  old_TS2   -1.9416058394160587e+00
    x[14,19]  old_TS3   -1.9416058394160587e+00
    x[14,19]  old_TS4   -9.3149279732585788e-01
    x[14,20]  OBJ       2.2558581818181819e-02
    x[14,20]  onehot_14  1
    x[14,20]  w_lb_14_20  -4.9025936701360941e-02
    x[14,20]  w_ub_14_20  -1.0218978102189782e-01
    x[14,20]  hard_lower  20
    x[14,20]  hard_upper  20
    x[14,20]  old_TS1   -9.8051873402721879e-01
    x[14,20]  old_TS2   -2.0437956204379564e+00
    x[14,20]  old_TS3   -2.0437956204379564e+00
    x[14,20]  old_TS4   -9.8051873402721879e-01
    x[15,0]   OBJ       3.5449199999999993e-02
    x[15,0]   onehot_15  1
    x[15,0]   w_lb_15_0  -4.9025936701360941e-02
    x[15,0]   w_ub_15_0  -1.0218978102189782e-01
    x[15,1]   OBJ       2.9003890909090908e-02
    x[15,1]   onehot_15  1
    x[15,1]   w_lb_15_1  -4.9025936701360941e-02
    x[15,1]   w_ub_15_1  -1.0218978102189782e-01
    x[15,1]   hard_lower  1
    x[15,1]   hard_upper  1
    x[15,1]   old_TS1   -4.9025936701360941e-02
    x[15,1]   old_TS2   -1.0218978102189782e-01
    x[15,1]   old_TS3   -1.0218978102189782e-01
    x[15,1]   old_TS4   -4.9025936701360941e-02
    x[15,2]   OBJ       2.2558581818181815e-02
    x[15,2]   onehot_15  1
    x[15,2]   w_lb_15_2  -4.9025936701360941e-02
    x[15,2]   w_ub_15_2  -1.0218978102189782e-01
    x[15,2]   hard_lower  2
    x[15,2]   hard_upper  2
    x[15,2]   old_TS1   -9.8051873402721881e-02
    x[15,2]   old_TS2   -2.0437956204379565e-01
    x[15,2]   old_TS3   -2.0437956204379565e-01
    x[15,2]   old_TS4   -9.8051873402721881e-02
    x[15,3]   OBJ       1.6113272727272723e-02
    x[15,3]   onehot_15  1
    x[15,3]   w_lb_15_3  -4.9025936701360941e-02
    x[15,3]   w_ub_15_3  -1.0218978102189782e-01
    x[15,3]   hard_lower  3
    x[15,3]   hard_upper  3
    x[15,3]   old_TS1   -1.4707781010408283e-01
    x[15,3]   old_TS2   -3.0656934306569350e-01
    x[15,3]   old_TS3   -3.0656934306569350e-01
    x[15,3]   old_TS4   -1.4707781010408283e-01
    x[15,4]   OBJ       9.6679636363636336e-03
    x[15,4]   onehot_15  1
    x[15,4]   w_lb_15_4  -4.9025936701360941e-02
    x[15,4]   w_ub_15_4  -1.0218978102189782e-01
    x[15,4]   hard_lower  4
    x[15,4]   hard_upper  4
    x[15,4]   old_TS1   -1.9610374680544376e-01
    x[15,4]   old_TS2   -4.0875912408759130e-01
    x[15,4]   old_TS3   -4.0875912408759130e-01
    x[15,4]   old_TS4   -1.9610374680544376e-01
    x[15,5]   OBJ       3.2226545454545432e-03
    x[15,5]   onehot_15  1
    x[15,5]   w_lb_15_5  -4.9025936701360941e-02
    x[15,5]   w_ub_15_5  -1.0218978102189782e-01
    x[15,5]   hard_lower  5
    x[15,5]   hard_upper  5
    x[15,5]   old_TS1   -2.4512968350680470e-01
    x[15,5]   old_TS2   -5.1094890510948909e-01
    x[15,5]   old_TS3   -5.1094890510948909e-01
    x[15,5]   old_TS4   -2.4512968350680470e-01
    x[15,6]   OBJ       -3.2226545454545476e-03
    x[15,6]   onehot_15  1
    x[15,6]   w_lb_15_6  -4.9025936701360941e-02
    x[15,6]   w_ub_15_6  -1.0218978102189782e-01
    x[15,6]   hard_lower  6
    x[15,6]   hard_upper  6
    x[15,6]   old_TS1   -2.9415562020816566e-01
    x[15,6]   old_TS2   -0.613138686131387
    x[15,6]   old_TS3   -0.613138686131387
    x[15,6]   old_TS4   -2.9415562020816566e-01
    x[15,7]   OBJ       -9.6679636363636388e-03
    x[15,7]   onehot_15  1
    x[15,7]   w_lb_15_7  -4.9025936701360941e-02
    x[15,7]   w_ub_15_7  -1.0218978102189782e-01
    x[15,7]   hard_lower  7
    x[15,7]   hard_upper  7
    x[15,7]   old_TS1   -3.4318155690952656e-01
    x[15,7]   old_TS2   -7.1532846715328480e-01
    x[15,7]   old_TS3   -7.1532846715328480e-01
    x[15,7]   old_TS4   -3.4318155690952656e-01
    x[15,8]   OBJ       -1.6113272727272733e-02
    x[15,8]   onehot_15  1
    x[15,8]   w_lb_15_8  -4.9025936701360941e-02
    x[15,8]   w_ub_15_8  -1.0218978102189782e-01
    x[15,8]   hard_lower  8
    x[15,8]   hard_upper  8
    x[15,8]   old_TS1   -3.9220749361088753e-01
    x[15,8]   old_TS2   -8.1751824817518259e-01
    x[15,8]   old_TS3   -8.1751824817518259e-01
    x[15,8]   old_TS4   -3.9220749361088753e-01
    x[15,9]   OBJ       -2.2558581818181822e-02
    x[15,9]   onehot_15  1
    x[15,9]   w_lb_15_9  -4.9025936701360941e-02
    x[15,9]   w_ub_15_9  -1.0218978102189782e-01
    x[15,9]   hard_lower  9
    x[15,9]   hard_upper  9
    x[15,9]   old_TS1   -4.4123343031224849e-01
    x[15,9]   old_TS2   -9.1970802919708039e-01
    x[15,9]   old_TS3   -9.1970802919708039e-01
    x[15,9]   old_TS4   -4.4123343031224849e-01
    x[15,10]  OBJ       -2.9003890909090915e-02
    x[15,10]  onehot_15  1
    x[15,10]  w_lb_15_10  -4.9025936701360941e-02
    x[15,10]  w_ub_15_10  -1.0218978102189782e-01
    x[15,10]  hard_lower  10
    x[15,10]  hard_upper  10
    x[15,10]  old_TS1   -4.9025936701360939e-01
    x[15,10]  old_TS2   -1.0218978102189782e+00
    x[15,10]  old_TS3   -1.0218978102189782e+00
    x[15,10]  old_TS4   -4.9025936701360939e-01
    x[15,11]  OBJ       -0.0354492
    x[15,11]  onehot_15  1
    x[15,11]  w_lb_15_11  -4.9025936701360941e-02
    x[15,11]  w_ub_15_11  -1.0218978102189782e-01
    x[15,11]  hard_lower  11
    x[15,11]  hard_upper  11
    x[15,11]  old_TS1   -5.3928530371497030e-01
    x[15,11]  old_TS2   -1.1240875912408761e+00
    x[15,11]  old_TS3   -1.1240875912408761e+00
    x[15,11]  old_TS4   -5.3928530371497030e-01
    x[15,12]  OBJ       -2.9003890909090911e-02
    x[15,12]  onehot_15  1
    x[15,12]  w_lb_15_12  -4.9025936701360941e-02
    x[15,12]  w_ub_15_12  -1.0218978102189782e-01
    x[15,12]  hard_lower  12
    x[15,12]  hard_upper  12
    x[15,12]  old_TS1   -5.8831124041633132e-01
    x[15,12]  old_TS2   -1.2262773722627740e+00
    x[15,12]  old_TS3   -1.2262773722627740e+00
    x[15,12]  old_TS4   -5.8831124041633132e-01
    x[15,13]  OBJ       -2.2558581818181819e-02
    x[15,13]  onehot_15  1
    x[15,13]  w_lb_15_13  -4.9025936701360941e-02
    x[15,13]  w_ub_15_13  -1.0218978102189782e-01
    x[15,13]  hard_lower  13
    x[15,13]  hard_upper  13
    x[15,13]  old_TS1   -6.3733717711769222e-01
    x[15,13]  old_TS2   -1.3284671532846717e+00
    x[15,13]  old_TS3   -1.3284671532846717e+00
    x[15,13]  old_TS4   -6.3733717711769222e-01
    x[15,14]  OBJ       -1.6113272727272726e-02
    x[15,14]  onehot_15  1
    x[15,14]  w_lb_15_14  -4.9025936701360941e-02
    x[15,14]  w_ub_15_14  -1.0218978102189782e-01
    x[15,14]  hard_lower  14
    x[15,14]  hard_upper  14
    x[15,14]  old_TS1   -6.8636311381905313e-01
    x[15,14]  old_TS2   -1.4306569343065696e+00
    x[15,14]  old_TS3   -1.4306569343065696e+00
    x[15,14]  old_TS4   -6.8636311381905313e-01
    x[15,15]  OBJ       -9.6679636363636353e-03
    x[15,15]  onehot_15  1
    x[15,15]  w_lb_15_15  -4.9025936701360941e-02
    x[15,15]  w_ub_15_15  -1.0218978102189782e-01
    x[15,15]  hard_lower  15
    x[15,15]  hard_upper  15
    x[15,15]  old_TS1   -7.3538905052041414e-01
    x[15,15]  old_TS2   -1.5328467153284673e+00
    x[15,15]  old_TS3   -1.5328467153284673e+00
    x[15,15]  old_TS4   -7.3538905052041414e-01
    x[15,16]  OBJ       -3.2226545454545437e-03
    x[15,16]  onehot_15  1
    x[15,16]  w_lb_15_16  -4.9025936701360941e-02
    x[15,16]  w_ub_15_16  -1.0218978102189782e-01
    x[15,16]  hard_lower  16
    x[15,16]  hard_upper  16
    x[15,16]  old_TS1   -0.784414987221775
    x[15,16]  old_TS2   -1.6350364963503652e+00
    x[15,16]  old_TS3   -1.6350364963503652e+00
    x[15,16]  old_TS4   -0.784414987221775
    x[15,17]  OBJ       3.2226545454545471e-03
    x[15,17]  onehot_15  1
    x[15,17]  w_lb_15_17  -4.9025936701360941e-02
    x[15,17]  w_ub_15_17  -1.0218978102189782e-01
    x[15,17]  hard_lower  17
    x[15,17]  hard_upper  17
    x[15,17]  old_TS1   -0.833440923923136
    x[15,17]  old_TS2   -1.7372262773722631e+00
    x[15,17]  old_TS3   -1.7372262773722631e+00
    x[15,17]  old_TS4   -0.833440923923136
    x[15,18]  OBJ       9.6679636363636370e-03
    x[15,18]  onehot_15  1
    x[15,18]  w_lb_15_18  -4.9025936701360941e-02
    x[15,18]  w_ub_15_18  -1.0218978102189782e-01
    x[15,18]  hard_lower  18
    x[15,18]  hard_upper  18
    x[15,18]  old_TS1   -0.882466860624497
    x[15,18]  old_TS2   -1.8394160583941608e+00
    x[15,18]  old_TS3   -1.8394160583941608e+00
    x[15,18]  old_TS4   -0.882466860624497
    x[15,19]  OBJ       1.6113272727272730e-02
    x[15,19]  onehot_15  1
    x[15,19]  w_lb_15_19  -4.9025936701360941e-02
    x[15,19]  w_ub_15_19  -1.0218978102189782e-01
    x[15,19]  hard_lower  19
    x[15,19]  hard_upper  19
    x[15,19]  old_TS1   -9.3149279732585788e-01
    x[15,19]  old_TS2   -1.9416058394160587e+00
    x[15,19]  old_TS3   -1.9416058394160587e+00
    x[15,19]  old_TS4   -9.3149279732585788e-01
    x[15,20]  OBJ       2.2558581818181819e-02
    x[15,20]  onehot_15  1
    x[15,20]  w_lb_15_20  -4.9025936701360941e-02
    x[15,20]  w_ub_15_20  -1.0218978102189782e-01
    x[15,20]  hard_lower  20
    x[15,20]  hard_upper  20
    x[15,20]  old_TS1   -9.8051873402721879e-01
    x[15,20]  old_TS2   -2.0437956204379564e+00
    x[15,20]  old_TS3   -2.0437956204379564e+00
    x[15,20]  old_TS4   -9.8051873402721879e-01
    x[16,0]   OBJ       5.7421874999999990e-02
    x[16,0]   onehot_16  1
    x[16,0]   w_lb_16_0  -4.9025936701360941e-02
    x[16,0]   w_ub_16_0  -1.0218978102189782e-01
    x[16,1]   OBJ       4.9218749999999992e-02
    x[16,1]   onehot_16  1
    x[16,1]   w_lb_16_1  -4.9025936701360941e-02
    x[16,1]   w_ub_16_1  -1.0218978102189782e-01
    x[16,1]   hard_lower  1
    x[16,1]   hard_upper  1
    x[16,1]   old_TS1   -4.9025936701360941e-02
    x[16,1]   old_TS2   -1.0218978102189782e-01
    x[16,1]   old_TS3   -1.0218978102189782e-01
    x[16,1]   old_TS4   -4.9025936701360941e-02
    x[16,2]   OBJ       4.1015624999999993e-02
    x[16,2]   onehot_16  1
    x[16,2]   w_lb_16_2  -4.9025936701360941e-02
    x[16,2]   w_ub_16_2  -1.0218978102189782e-01
    x[16,2]   hard_lower  2
    x[16,2]   hard_upper  2
    x[16,2]   old_TS1   -9.8051873402721881e-02
    x[16,2]   old_TS2   -2.0437956204379565e-01
    x[16,2]   old_TS3   -2.0437956204379565e-01
    x[16,2]   old_TS4   -9.8051873402721881e-02
    x[16,3]   OBJ       3.2812499999999994e-02
    x[16,3]   onehot_16  1
    x[16,3]   w_lb_16_3  -4.9025936701360941e-02
    x[16,3]   w_ub_16_3  -1.0218978102189782e-01
    x[16,3]   hard_lower  3
    x[16,3]   hard_upper  3
    x[16,3]   old_TS1   -1.4707781010408283e-01
    x[16,3]   old_TS2   -3.0656934306569350e-01
    x[16,3]   old_TS3   -3.0656934306569350e-01
    x[16,3]   old_TS4   -1.4707781010408283e-01
    x[16,4]   OBJ       2.4609374999999996e-02
    x[16,4]   onehot_16  1
    x[16,4]   w_lb_16_4  -4.9025936701360941e-02
    x[16,4]   w_ub_16_4  -1.0218978102189782e-01
    x[16,4]   hard_lower  4
    x[16,4]   hard_upper  4
    x[16,4]   old_TS1   -1.9610374680544376e-01
    x[16,4]   old_TS2   -4.0875912408759130e-01
    x[16,4]   old_TS3   -4.0875912408759130e-01
    x[16,4]   old_TS4   -1.9610374680544376e-01
    x[16,5]   OBJ       1.6406249999999997e-02
    x[16,5]   onehot_16  1
    x[16,5]   w_lb_16_5  -4.9025936701360941e-02
    x[16,5]   w_ub_16_5  -1.0218978102189782e-01
    x[16,5]   hard_lower  5
    x[16,5]   hard_upper  5
    x[16,5]   old_TS1   -2.4512968350680470e-01
    x[16,5]   old_TS2   -5.1094890510948909e-01
    x[16,5]   old_TS3   -5.1094890510948909e-01
    x[16,5]   old_TS4   -2.4512968350680470e-01
    x[16,6]   OBJ       8.2031249999999986e-03
    x[16,6]   onehot_16  1
    x[16,6]   w_lb_16_6  -4.9025936701360941e-02
    x[16,6]   w_ub_16_6  -1.0218978102189782e-01
    x[16,6]   hard_lower  6
    x[16,6]   hard_upper  6
    x[16,6]   old_TS1   -2.9415562020816566e-01
    x[16,6]   old_TS2   -0.613138686131387
    x[16,6]   old_TS3   -0.613138686131387
    x[16,6]   old_TS4   -2.9415562020816566e-01
    x[16,7]   onehot_16  1
    x[16,7]   w_lb_16_7  -4.9025936701360941e-02
    x[16,7]   w_ub_16_7  -1.0218978102189782e-01
    x[16,7]   hard_lower  7
    x[16,7]   hard_upper  7
    x[16,7]   old_TS1   -3.4318155690952656e-01
    x[16,7]   old_TS2   -7.1532846715328480e-01
    x[16,7]   old_TS3   -7.1532846715328480e-01
    x[16,7]   old_TS4   -3.4318155690952656e-01
    x[16,8]   OBJ       -0.008203125
    x[16,8]   onehot_16  1
    x[16,8]   w_lb_16_8  -4.9025936701360941e-02
    x[16,8]   w_ub_16_8  -1.0218978102189782e-01
    x[16,8]   hard_lower  8
    x[16,8]   hard_upper  8
    x[16,8]   old_TS1   -3.9220749361088753e-01
    x[16,8]   old_TS2   -8.1751824817518259e-01
    x[16,8]   old_TS3   -8.1751824817518259e-01
    x[16,8]   old_TS4   -3.9220749361088753e-01
    x[16,9]   OBJ       -0.01640625
    x[16,9]   onehot_16  1
    x[16,9]   w_lb_16_9  -4.9025936701360941e-02
    x[16,9]   w_ub_16_9  -1.0218978102189782e-01
    x[16,9]   hard_lower  9
    x[16,9]   hard_upper  9
    x[16,9]   old_TS1   -4.4123343031224849e-01
    x[16,9]   old_TS2   -9.1970802919708039e-01
    x[16,9]   old_TS3   -9.1970802919708039e-01
    x[16,9]   old_TS4   -4.4123343031224849e-01
    x[16,10]  OBJ       -0.024609375
    x[16,10]  onehot_16  1
    x[16,10]  w_lb_16_10  -4.9025936701360941e-02
    x[16,10]  w_ub_16_10  -1.0218978102189782e-01
    x[16,10]  hard_lower  10
    x[16,10]  hard_upper  10
    x[16,10]  old_TS1   -4.9025936701360939e-01
    x[16,10]  old_TS2   -1.0218978102189782e+00
    x[16,10]  old_TS3   -1.0218978102189782e+00
    x[16,10]  old_TS4   -4.9025936701360939e-01
    x[16,11]  OBJ       -0.0328125
    x[16,11]  onehot_16  1
    x[16,11]  w_lb_16_11  -4.9025936701360941e-02
    x[16,11]  w_ub_16_11  -1.0218978102189782e-01
    x[16,11]  hard_lower  11
    x[16,11]  hard_upper  11
    x[16,11]  old_TS1   -5.3928530371497030e-01
    x[16,11]  old_TS2   -1.1240875912408761e+00
    x[16,11]  old_TS3   -1.1240875912408761e+00
    x[16,11]  old_TS4   -5.3928530371497030e-01
    x[16,12]  OBJ       -0.041015625
    x[16,12]  onehot_16  1
    x[16,12]  w_lb_16_12  -4.9025936701360941e-02
    x[16,12]  w_ub_16_12  -1.0218978102189782e-01
    x[16,12]  hard_lower  12
    x[16,12]  hard_upper  12
    x[16,12]  old_TS1   -5.8831124041633132e-01
    x[16,12]  old_TS2   -1.2262773722627740e+00
    x[16,12]  old_TS3   -1.2262773722627740e+00
    x[16,12]  old_TS4   -5.8831124041633132e-01
    x[16,13]  OBJ       -0.04921875
    x[16,13]  onehot_16  1
    x[16,13]  w_lb_16_13  -4.9025936701360941e-02
    x[16,13]  w_ub_16_13  -1.0218978102189782e-01
    x[16,13]  hard_lower  13
    x[16,13]  hard_upper  13
    x[16,13]  old_TS1   -6.3733717711769222e-01
    x[16,13]  old_TS2   -1.3284671532846717e+00
    x[16,13]  old_TS3   -1.3284671532846717e+00
    x[16,13]  old_TS4   -6.3733717711769222e-01
    x[16,14]  OBJ       -0.057421875
    x[16,14]  onehot_16  1
    x[16,14]  w_lb_16_14  -4.9025936701360941e-02
    x[16,14]  w_ub_16_14  -1.0218978102189782e-01
    x[16,14]  hard_lower  14
    x[16,14]  hard_upper  14
    x[16,14]  old_TS1   -6.8636311381905313e-01
    x[16,14]  old_TS2   -1.4306569343065696e+00
    x[16,14]  old_TS3   -1.4306569343065696e+00
    x[16,14]  old_TS4   -6.8636311381905313e-01
    x[16,15]  OBJ       -4.9218750000000012e-02
    x[16,15]  onehot_16  1
    x[16,15]  w_lb_16_15  -4.9025936701360941e-02
    x[16,15]  w_ub_16_15  -1.0218978102189782e-01
    x[16,15]  hard_lower  15
    x[16,15]  hard_upper  15
    x[16,15]  old_TS1   -7.3538905052041414e-01
    x[16,15]  old_TS2   -1.5328467153284673e+00
    x[16,15]  old_TS3   -1.5328467153284673e+00
    x[16,15]  old_TS4   -7.3538905052041414e-01
    x[16,16]  OBJ       -4.1015625000000014e-02
    x[16,16]  onehot_16  1
    x[16,16]  w_lb_16_16  -4.9025936701360941e-02
    x[16,16]  w_ub_16_16  -1.0218978102189782e-01
    x[16,16]  hard_lower  16
    x[16,16]  hard_upper  16
    x[16,16]  old_TS1   -0.784414987221775
    x[16,16]  old_TS2   -1.6350364963503652e+00
    x[16,16]  old_TS3   -1.6350364963503652e+00
    x[16,16]  old_TS4   -0.784414987221775
    x[16,17]  OBJ       -3.2812500000000015e-02
    x[16,17]  onehot_16  1
    x[16,17]  w_lb_16_17  -4.9025936701360941e-02
    x[16,17]  w_ub_16_17  -1.0218978102189782e-01
    x[16,17]  hard_lower  17
    x[16,17]  hard_upper  17
    x[16,17]  old_TS1   -0.833440923923136
    x[16,17]  old_TS2   -1.7372262773722631e+00
    x[16,17]  old_TS3   -1.7372262773722631e+00
    x[16,17]  old_TS4   -0.833440923923136
    x[16,18]  OBJ       -2.4609375000000013e-02
    x[16,18]  onehot_16  1
    x[16,18]  w_lb_16_18  -4.9025936701360941e-02
    x[16,18]  w_ub_16_18  -1.0218978102189782e-01
    x[16,18]  hard_lower  18
    x[16,18]  hard_upper  18
    x[16,18]  old_TS1   -0.882466860624497
    x[16,18]  old_TS2   -1.8394160583941608e+00
    x[16,18]  old_TS3   -1.8394160583941608e+00
    x[16,18]  old_TS4   -0.882466860624497
    x[16,19]  OBJ       -1.6406250000000011e-02
    x[16,19]  onehot_16  1
    x[16,19]  w_lb_16_19  -4.9025936701360941e-02
    x[16,19]  w_ub_16_19  -1.0218978102189782e-01
    x[16,19]  hard_lower  19
    x[16,19]  hard_upper  19
    x[16,19]  old_TS1   -9.3149279732585788e-01
    x[16,19]  old_TS2   -1.9416058394160587e+00
    x[16,19]  old_TS3   -1.9416058394160587e+00
    x[16,19]  old_TS4   -9.3149279732585788e-01
    x[16,20]  OBJ       -8.2031250000000125e-03
    x[16,20]  onehot_16  1
    x[16,20]  w_lb_16_20  -4.9025936701360941e-02
    x[16,20]  w_ub_16_20  -1.0218978102189782e-01
    x[16,20]  hard_lower  20
    x[16,20]  hard_upper  20
    x[16,20]  old_TS1   -9.8051873402721879e-01
    x[16,20]  old_TS2   -2.0437956204379564e+00
    x[16,20]  old_TS3   -2.0437956204379564e+00
    x[16,20]  old_TS4   -9.8051873402721879e-01
    x[16,21]  OBJ       -1.2750217548429532e-17
    x[16,21]  onehot_16  1
    x[16,21]  w_lb_16_21  -4.9025936701360941e-02
    x[16,21]  w_ub_16_21  -1.0218978102189782e-01
    x[16,21]  hard_lower  21
    x[16,21]  hard_upper  21
    x[16,21]  old_TS1   -1.0295446707285798e+00
    x[16,21]  old_TS2   -2.1459854014598543e+00
    x[16,21]  old_TS3   -2.1459854014598543e+00
    x[16,21]  old_TS4   -1.0295446707285798e+00
    x[16,22]  OBJ       8.2031249999999847e-03
    x[16,22]  onehot_16  1
    x[16,22]  w_lb_16_22  -4.9025936701360941e-02
    x[16,22]  w_ub_16_22  -1.0218978102189782e-01
    x[16,22]  hard_lower  22
    x[16,22]  hard_upper  22
    x[16,22]  old_TS1   -1.0785706074299406e+00
    x[16,22]  old_TS2   -2.2481751824817522e+00
    x[16,22]  old_TS3   -2.2481751824817522e+00
    x[16,22]  old_TS4   -1.0785706074299406e+00
    x[16,23]  OBJ       1.6406249999999983e-02
    x[16,23]  onehot_16  1
    x[16,23]  w_lb_16_23  -4.9025936701360941e-02
    x[16,23]  w_ub_16_23  -1.0218978102189782e-01
    x[16,23]  hard_lower  23
    x[16,23]  hard_upper  23
    x[16,23]  old_TS1   -1.1275965441313016e+00
    x[16,23]  old_TS2   -2.35036496350365
    x[16,23]  old_TS3   -2.35036496350365
    x[16,23]  old_TS4   -1.1275965441313016e+00
    x[16,24]  OBJ       2.4609374999999982e-02
    x[16,24]  onehot_16  1
    x[16,24]  w_lb_16_24  -4.9025936701360941e-02
    x[16,24]  w_ub_16_24  -1.0218978102189782e-01
    x[16,24]  hard_lower  24
    x[16,24]  hard_upper  24
    x[16,24]  old_TS1   -1.1766224808326626e+00
    x[16,24]  old_TS2   -2.4525547445255480e+00
    x[16,24]  old_TS3   -2.4525547445255480e+00
    x[16,24]  old_TS4   -1.1766224808326626e+00
    x[16,25]  OBJ       3.2812499999999981e-02
    x[16,25]  onehot_16  1
    x[16,25]  w_lb_16_25  -4.9025936701360941e-02
    x[16,25]  w_ub_16_25  -1.0218978102189782e-01
    x[16,25]  hard_lower  25
    x[16,25]  hard_upper  25
    x[16,25]  old_TS1   -1.2256484175340234e+00
    x[16,25]  old_TS2   -2.5547445255474455e+00
    x[16,25]  old_TS3   -2.5547445255474455e+00
    x[16,25]  old_TS4   -1.2256484175340234e+00
    x[16,26]  OBJ       4.1015624999999979e-02
    x[16,26]  onehot_16  1
    x[16,26]  w_lb_16_26  -4.9025936701360941e-02
    x[16,26]  w_ub_16_26  -1.0218978102189782e-01
    x[16,26]  hard_lower  26
    x[16,26]  hard_upper  26
    x[16,26]  old_TS1   -1.2746743542353844e+00
    x[16,26]  old_TS2   -2.6569343065693434e+00
    x[16,26]  old_TS3   -2.6569343065693434e+00
    x[16,26]  old_TS4   -1.2746743542353844e+00
    x[16,27]  OBJ       4.9218749999999978e-02
    x[16,27]  onehot_16  1
    x[16,27]  w_lb_16_27  -4.9025936701360941e-02
    x[16,27]  w_ub_16_27  -1.0218978102189782e-01
    x[16,27]  hard_lower  27
    x[16,27]  hard_upper  27
    x[16,27]  old_TS1   -1.3237002909367455e+00
    x[16,27]  old_TS2   -2.7591240875912413e+00
    x[16,27]  old_TS3   -2.7591240875912413e+00
    x[16,27]  old_TS4   -1.3237002909367455e+00
    x[17,0]   OBJ       1.8457016666666666e-02
    x[17,0]   onehot_17  1
    x[17,0]   w_lb_17_0  -4.9025936701360941e-02
    x[17,0]   w_ub_17_0  -1.0218978102189782e-01
    x[17,1]   OBJ       1.3183583333333334e-02
    x[17,1]   onehot_17  1
    x[17,1]   w_lb_17_1  -4.9025936701360941e-02
    x[17,1]   w_ub_17_1  -1.0218978102189782e-01
    x[17,1]   hard_lower  1
    x[17,1]   hard_upper  1
    x[17,1]   old_TS1   -4.9025936701360941e-02
    x[17,1]   old_TS2   -1.0218978102189782e-01
    x[17,1]   old_TS3   -1.0218978102189782e-01
    x[17,1]   old_TS4   -4.9025936701360941e-02
    x[17,2]   OBJ       7.9101500000000012e-03
    x[17,2]   onehot_17  1
    x[17,2]   w_lb_17_2  -4.9025936701360941e-02
    x[17,2]   w_ub_17_2  -1.0218978102189782e-01
    x[17,2]   hard_lower  2
    x[17,2]   hard_upper  2
    x[17,2]   old_TS1   -9.8051873402721881e-02
    x[17,2]   old_TS2   -2.0437956204379565e-01
    x[17,2]   old_TS3   -2.0437956204379565e-01
    x[17,2]   old_TS4   -9.8051873402721881e-02
    x[17,3]   OBJ       2.6367166666666688e-03
    x[17,3]   onehot_17  1
    x[17,3]   w_lb_17_3  -4.9025936701360941e-02
    x[17,3]   w_ub_17_3  -1.0218978102189782e-01
    x[17,3]   hard_lower  3
    x[17,3]   hard_upper  3
    x[17,3]   old_TS1   -1.4707781010408283e-01
    x[17,3]   old_TS2   -3.0656934306569350e-01
    x[17,3]   old_TS3   -3.0656934306569350e-01
    x[17,3]   old_TS4   -1.4707781010408283e-01
    x[17,4]   OBJ       -2.6367166666666640e-03
    x[17,4]   onehot_17  1
    x[17,4]   w_lb_17_4  -4.9025936701360941e-02
    x[17,4]   w_ub_17_4  -1.0218978102189782e-01
    x[17,4]   hard_lower  4
    x[17,4]   hard_upper  4
    x[17,4]   old_TS1   -1.9610374680544376e-01
    x[17,4]   old_TS2   -4.0875912408759130e-01
    x[17,4]   old_TS3   -4.0875912408759130e-01
    x[17,4]   old_TS4   -1.9610374680544376e-01
    x[17,5]   OBJ       -7.9101499999999977e-03
    x[17,5]   onehot_17  1
    x[17,5]   w_lb_17_5  -4.9025936701360941e-02
    x[17,5]   w_ub_17_5  -1.0218978102189782e-01
    x[17,5]   hard_lower  5
    x[17,5]   hard_upper  5
    x[17,5]   old_TS1   -2.4512968350680470e-01
    x[17,5]   old_TS2   -5.1094890510948909e-01
    x[17,5]   old_TS3   -5.1094890510948909e-01
    x[17,5]   old_TS4   -2.4512968350680470e-01
    x[17,6]   OBJ       -1.3183583333333330e-02
    x[17,6]   onehot_17  1
    x[17,6]   w_lb_17_6  -4.9025936701360941e-02
    x[17,6]   w_ub_17_6  -1.0218978102189782e-01
    x[17,6]   hard_lower  6
    x[17,6]   hard_upper  6
    x[17,6]   old_TS1   -2.9415562020816566e-01
    x[17,6]   old_TS2   -0.613138686131387
    x[17,6]   old_TS3   -0.613138686131387
    x[17,6]   old_TS4   -2.9415562020816566e-01
    x[17,7]   OBJ       -1.8457016666666666e-02
    x[17,7]   onehot_17  1
    x[17,7]   w_lb_17_7  -4.9025936701360941e-02
    x[17,7]   w_ub_17_7  -1.0218978102189782e-01
    x[17,7]   hard_lower  7
    x[17,7]   hard_upper  7
    x[17,7]   old_TS1   -3.4318155690952656e-01
    x[17,7]   old_TS2   -7.1532846715328480e-01
    x[17,7]   old_TS3   -7.1532846715328480e-01
    x[17,7]   old_TS4   -3.4318155690952656e-01
    x[17,8]   OBJ       -2.3730449999999997e-02
    x[17,8]   onehot_17  1
    x[17,8]   w_lb_17_8  -4.9025936701360941e-02
    x[17,8]   w_ub_17_8  -1.0218978102189782e-01
    x[17,8]   hard_lower  8
    x[17,8]   hard_upper  8
    x[17,8]   old_TS1   -3.9220749361088753e-01
    x[17,8]   old_TS2   -8.1751824817518259e-01
    x[17,8]   old_TS3   -8.1751824817518259e-01
    x[17,8]   old_TS4   -3.9220749361088753e-01
    x[17,9]   OBJ       -2.9003883333333331e-02
    x[17,9]   onehot_17  1
    x[17,9]   w_lb_17_9  -4.9025936701360941e-02
    x[17,9]   w_ub_17_9  -1.0218978102189782e-01
    x[17,9]   hard_lower  9
    x[17,9]   hard_upper  9
    x[17,9]   old_TS1   -4.4123343031224849e-01
    x[17,9]   old_TS2   -9.1970802919708039e-01
    x[17,9]   old_TS3   -9.1970802919708039e-01
    x[17,9]   old_TS4   -4.4123343031224849e-01
    x[17,10]  OBJ       -2.3730450000000004e-02
    x[17,10]  onehot_17  1
    x[17,10]  w_lb_17_10  -4.9025936701360941e-02
    x[17,10]  w_ub_17_10  -1.0218978102189782e-01
    x[17,10]  hard_lower  10
    x[17,10]  hard_upper  10
    x[17,10]  old_TS1   -4.9025936701360939e-01
    x[17,10]  old_TS2   -1.0218978102189782e+00
    x[17,10]  old_TS3   -1.0218978102189782e+00
    x[17,10]  old_TS4   -4.9025936701360939e-01
    x[17,11]  OBJ       -1.8457016666666669e-02
    x[17,11]  onehot_17  1
    x[17,11]  w_lb_17_11  -4.9025936701360941e-02
    x[17,11]  w_ub_17_11  -1.0218978102189782e-01
    x[17,11]  hard_lower  11
    x[17,11]  hard_upper  11
    x[17,11]  old_TS1   -5.3928530371497030e-01
    x[17,11]  old_TS2   -1.1240875912408761e+00
    x[17,11]  old_TS3   -1.1240875912408761e+00
    x[17,11]  old_TS4   -5.3928530371497030e-01
    x[17,12]  OBJ       -1.3183583333333335e-02
    x[17,12]  onehot_17  1
    x[17,12]  w_lb_17_12  -4.9025936701360941e-02
    x[17,12]  w_ub_17_12  -1.0218978102189782e-01
    x[17,12]  hard_lower  12
    x[17,12]  hard_upper  12
    x[17,12]  old_TS1   -5.8831124041633132e-01
    x[17,12]  old_TS2   -1.2262773722627740e+00
    x[17,12]  old_TS3   -1.2262773722627740e+00
    x[17,12]  old_TS4   -5.8831124041633132e-01
    x[17,13]  OBJ       -7.9101500000000029e-03
    x[17,13]  onehot_17  1
    x[17,13]  w_lb_17_13  -4.9025936701360941e-02
    x[17,13]  w_ub_17_13  -1.0218978102189782e-01
    x[17,13]  hard_lower  13
    x[17,13]  hard_upper  13
    x[17,13]  old_TS1   -6.3733717711769222e-01
    x[17,13]  old_TS2   -1.3284671532846717e+00
    x[17,13]  old_TS3   -1.3284671532846717e+00
    x[17,13]  old_TS4   -6.3733717711769222e-01
    x[17,14]  OBJ       -2.6367166666666692e-03
    x[17,14]  onehot_17  1
    x[17,14]  w_lb_17_14  -4.9025936701360941e-02
    x[17,14]  w_ub_17_14  -1.0218978102189782e-01
    x[17,14]  hard_lower  14
    x[17,14]  hard_upper  14
    x[17,14]  old_TS1   -6.8636311381905313e-01
    x[17,14]  old_TS2   -1.4306569343065696e+00
    x[17,14]  old_TS3   -1.4306569343065696e+00
    x[17,14]  old_TS4   -6.8636311381905313e-01
    x[17,15]  OBJ       2.6367166666666636e-03
    x[17,15]  onehot_17  1
    x[17,15]  w_lb_17_15  -4.9025936701360941e-02
    x[17,15]  w_ub_17_15  -1.0218978102189782e-01
    x[17,15]  hard_lower  15
    x[17,15]  hard_upper  15
    x[17,15]  old_TS1   -7.3538905052041414e-01
    x[17,15]  old_TS2   -1.5328467153284673e+00
    x[17,15]  old_TS3   -1.5328467153284673e+00
    x[17,15]  old_TS4   -7.3538905052041414e-01
    x[17,16]  OBJ       7.9101499999999960e-03
    x[17,16]  onehot_17  1
    x[17,16]  w_lb_17_16  -4.9025936701360941e-02
    x[17,16]  w_ub_17_16  -1.0218978102189782e-01
    x[17,16]  hard_lower  16
    x[17,16]  hard_upper  16
    x[17,16]  old_TS1   -0.784414987221775
    x[17,16]  old_TS2   -1.6350364963503652e+00
    x[17,16]  old_TS3   -1.6350364963503652e+00
    x[17,16]  old_TS4   -0.784414987221775
    x[17,17]  OBJ       1.3183583333333328e-02
    x[17,17]  onehot_17  1
    x[17,17]  w_lb_17_17  -4.9025936701360941e-02
    x[17,17]  w_ub_17_17  -1.0218978102189782e-01
    x[17,17]  hard_lower  17
    x[17,17]  hard_upper  17
    x[17,17]  old_TS1   -0.833440923923136
    x[17,17]  old_TS2   -1.7372262773722631e+00
    x[17,17]  old_TS3   -1.7372262773722631e+00
    x[17,17]  old_TS4   -0.833440923923136
    x[17,18]  OBJ       1.8457016666666663e-02
    x[17,18]  onehot_17  1
    x[17,18]  w_lb_17_18  -4.9025936701360941e-02
    x[17,18]  w_ub_17_18  -1.0218978102189782e-01
    x[17,18]  hard_lower  18
    x[17,18]  hard_upper  18
    x[17,18]  old_TS1   -0.882466860624497
    x[17,18]  old_TS2   -1.8394160583941608e+00
    x[17,18]  old_TS3   -1.8394160583941608e+00
    x[17,18]  old_TS4   -0.882466860624497
    x[17,19]  OBJ       2.3730449999999993e-02
    x[17,19]  onehot_17  1
    x[17,19]  w_lb_17_19  -4.9025936701360941e-02
    x[17,19]  w_ub_17_19  -1.0218978102189782e-01
    x[17,19]  hard_lower  19
    x[17,19]  hard_upper  19
    x[17,19]  old_TS1   -9.3149279732585788e-01
    x[17,19]  old_TS2   -1.9416058394160587e+00
    x[17,19]  old_TS3   -1.9416058394160587e+00
    x[17,19]  old_TS4   -9.3149279732585788e-01
    x[17,20]  OBJ       2.9003883333333327e-02
    x[17,20]  onehot_17  1
    x[17,20]  w_lb_17_20  -4.9025936701360941e-02
    x[17,20]  w_ub_17_20  -1.0218978102189782e-01
    x[17,20]  hard_lower  20
    x[17,20]  hard_upper  20
    x[17,20]  old_TS1   -9.8051873402721879e-01
    x[17,20]  old_TS2   -2.0437956204379564e+00
    x[17,20]  old_TS3   -2.0437956204379564e+00
    x[17,20]  old_TS4   -9.8051873402721879e-01
    x[18,10]  OBJ       -3.2812499999999994e-02
    x[18,10]  onehot_18  1
    x[18,10]  w_lb_18_10  -4.9025936701360941e-02
    x[18,10]  w_ub_18_10  -1.0218978102189782e-01
    x[18,10]  hard_lower  10
    x[18,10]  hard_upper  10
    x[18,10]  old_TS1   -4.9025936701360939e-01
    x[18,10]  old_TS2   -1.0218978102189782e+00
    x[18,10]  old_TS3   -1.0218978102189782e+00
    x[18,10]  old_TS4   -4.9025936701360939e-01
    x[18,11]  OBJ       -4.1015624999999993e-02
    x[18,11]  onehot_18  1
    x[18,11]  w_lb_18_11  -4.9025936701360941e-02
    x[18,11]  w_ub_18_11  -1.0218978102189782e-01
    x[18,11]  hard_lower  11
    x[18,11]  hard_upper  11
    x[18,11]  old_TS1   -5.3928530371497030e-01
    x[18,11]  old_TS2   -1.1240875912408761e+00
    x[18,11]  old_TS3   -1.1240875912408761e+00
    x[18,11]  old_TS4   -5.3928530371497030e-01
    x[18,12]  OBJ       -4.9218749999999992e-02
    x[18,12]  onehot_18  1
    x[18,12]  w_lb_18_12  -4.9025936701360941e-02
    x[18,12]  w_ub_18_12  -1.0218978102189782e-01
    x[18,12]  hard_lower  12
    x[18,12]  hard_upper  12
    x[18,12]  old_TS1   -5.8831124041633132e-01
    x[18,12]  old_TS2   -1.2262773722627740e+00
    x[18,12]  old_TS3   -1.2262773722627740e+00
    x[18,12]  old_TS4   -5.8831124041633132e-01
    x[18,13]  OBJ       -5.7421874999999990e-02
    x[18,13]  onehot_18  1
    x[18,13]  w_lb_18_13  -4.9025936701360941e-02
    x[18,13]  w_ub_18_13  -1.0218978102189782e-01
    x[18,13]  hard_lower  13
    x[18,13]  hard_upper  13
    x[18,13]  old_TS1   -6.3733717711769222e-01
    x[18,13]  old_TS2   -1.3284671532846717e+00
    x[18,13]  old_TS3   -1.3284671532846717e+00
    x[18,13]  old_TS4   -6.3733717711769222e-01
    x[18,14]  OBJ       -6.5624999999999989e-02
    x[18,14]  onehot_18  1
    x[18,14]  w_lb_18_14  -4.9025936701360941e-02
    x[18,14]  w_ub_18_14  -1.0218978102189782e-01
    x[18,14]  hard_lower  14
    x[18,14]  hard_upper  14
    x[18,14]  old_TS1   -6.8636311381905313e-01
    x[18,14]  old_TS2   -1.4306569343065696e+00
    x[18,14]  old_TS3   -1.4306569343065696e+00
    x[18,14]  old_TS4   -6.8636311381905313e-01
    x[18,15]  OBJ       -5.7421875000000004e-02
    x[18,15]  onehot_18  1
    x[18,15]  w_lb_18_15  -4.9025936701360941e-02
    x[18,15]  w_ub_18_15  -1.0218978102189782e-01
    x[18,15]  hard_lower  15
    x[18,15]  hard_upper  15
    x[18,15]  old_TS1   -7.3538905052041414e-01
    x[18,15]  old_TS2   -1.5328467153284673e+00
    x[18,15]  old_TS3   -1.5328467153284673e+00
    x[18,15]  old_TS4   -7.3538905052041414e-01
    x[18,16]  OBJ       -4.9218750000000006e-02
    x[18,16]  onehot_18  1
    x[18,16]  w_lb_18_16  -4.9025936701360941e-02
    x[18,16]  w_ub_18_16  -1.0218978102189782e-01
    x[18,16]  hard_lower  16
    x[18,16]  hard_upper  16
    x[18,16]  old_TS1   -0.784414987221775
    x[18,16]  old_TS2   -1.6350364963503652e+00
    x[18,16]  old_TS3   -1.6350364963503652e+00
    x[18,16]  old_TS4   -0.784414987221775
    x[18,17]  OBJ       -4.1015625000000007e-02
    x[18,17]  onehot_18  1
    x[18,17]  w_lb_18_17  -4.9025936701360941e-02
    x[18,17]  w_ub_18_17  -1.0218978102189782e-01
    x[18,17]  hard_lower  17
    x[18,17]  hard_upper  17
    x[18,17]  old_TS1   -0.833440923923136
    x[18,17]  old_TS2   -1.7372262773722631e+00
    x[18,17]  old_TS3   -1.7372262773722631e+00
    x[18,17]  old_TS4   -0.833440923923136
    x[18,18]  OBJ       -3.2812500000000008e-02
    x[18,18]  onehot_18  1
    x[18,18]  w_lb_18_18  -4.9025936701360941e-02
    x[18,18]  w_ub_18_18  -1.0218978102189782e-01
    x[18,18]  hard_lower  18
    x[18,18]  hard_upper  18
    x[18,18]  old_TS1   -0.882466860624497
    x[18,18]  old_TS2   -1.8394160583941608e+00
    x[18,18]  old_TS3   -1.8394160583941608e+00
    x[18,18]  old_TS4   -0.882466860624497
    x[18,19]  OBJ       -2.4609375000000006e-02
    x[18,19]  onehot_18  1
    x[18,19]  w_lb_18_19  -4.9025936701360941e-02
    x[18,19]  w_ub_18_19  -1.0218978102189782e-01
    x[18,19]  hard_lower  19
    x[18,19]  hard_upper  19
    x[18,19]  old_TS1   -9.3149279732585788e-01
    x[18,19]  old_TS2   -1.9416058394160587e+00
    x[18,19]  old_TS3   -1.9416058394160587e+00
    x[18,19]  old_TS4   -9.3149279732585788e-01
    x[18,20]  OBJ       -1.6406250000000008e-02
    x[18,20]  onehot_18  1
    x[18,20]  w_lb_18_20  -4.9025936701360941e-02
    x[18,20]  w_ub_18_20  -1.0218978102189782e-01
    x[18,20]  hard_lower  20
    x[18,20]  hard_upper  20
    x[18,20]  old_TS1   -9.8051873402721879e-01
    x[18,20]  old_TS2   -2.0437956204379564e+00
    x[18,20]  old_TS3   -2.0437956204379564e+00
    x[18,20]  old_TS4   -9.8051873402721879e-01
    x[18,21]  OBJ       -8.2031250000000056e-03
    x[18,21]  onehot_18  1
    x[18,21]  w_lb_18_21  -4.9025936701360941e-02
    x[18,21]  w_ub_18_21  -1.0218978102189782e-01
    x[18,21]  hard_lower  21
    x[18,21]  hard_upper  21
    x[18,21]  old_TS1   -1.0295446707285798e+00
    x[18,21]  old_TS2   -2.1459854014598543e+00
    x[18,21]  old_TS3   -2.1459854014598543e+00
    x[18,21]  old_TS4   -1.0295446707285798e+00
    x[18,22]  OBJ       -6.3751087742147658e-18
    x[18,22]  onehot_18  1
    x[18,22]  w_lb_18_22  -4.9025936701360941e-02
    x[18,22]  w_ub_18_22  -1.0218978102189782e-01
    x[18,22]  hard_lower  22
    x[18,22]  hard_upper  22
    x[18,22]  old_TS1   -1.0785706074299406e+00
    x[18,22]  old_TS2   -2.2481751824817522e+00
    x[18,22]  old_TS3   -2.2481751824817522e+00
    x[18,22]  old_TS4   -1.0785706074299406e+00
    x[18,23]  OBJ       8.2031249999999917e-03
    x[18,23]  onehot_18  1
    x[18,23]  w_lb_18_23  -4.9025936701360941e-02
    x[18,23]  w_ub_18_23  -1.0218978102189782e-01
    x[18,23]  hard_lower  23
    x[18,23]  hard_upper  23
    x[18,23]  old_TS1   -1.1275965441313016e+00
    x[18,23]  old_TS2   -2.35036496350365
    x[18,23]  old_TS3   -2.35036496350365
    x[18,23]  old_TS4   -1.1275965441313016e+00
    x[18,24]  OBJ       1.6406249999999990e-02
    x[18,24]  onehot_18  1
    x[18,24]  w_lb_18_24  -4.9025936701360941e-02
    x[18,24]  w_ub_18_24  -1.0218978102189782e-01
    x[18,24]  hard_lower  24
    x[18,24]  hard_upper  24
    x[18,24]  old_TS1   -1.1766224808326626e+00
    x[18,24]  old_TS2   -2.4525547445255480e+00
    x[18,24]  old_TS3   -2.4525547445255480e+00
    x[18,24]  old_TS4   -1.1766224808326626e+00
    x[18,25]  OBJ       2.4609374999999989e-02
    x[18,25]  onehot_18  1
    x[18,25]  w_lb_18_25  -4.9025936701360941e-02
    x[18,25]  w_ub_18_25  -1.0218978102189782e-01
    x[18,25]  hard_lower  25
    x[18,25]  hard_upper  25
    x[18,25]  old_TS1   -1.2256484175340234e+00
    x[18,25]  old_TS2   -2.5547445255474455e+00
    x[18,25]  old_TS3   -2.5547445255474455e+00
    x[18,25]  old_TS4   -1.2256484175340234e+00
    x[18,26]  OBJ       3.2812499999999988e-02
    x[18,26]  onehot_18  1
    x[18,26]  w_lb_18_26  -4.9025936701360941e-02
    x[18,26]  w_ub_18_26  -1.0218978102189782e-01
    x[18,26]  hard_lower  26
    x[18,26]  hard_upper  26
    x[18,26]  old_TS1   -1.2746743542353844e+00
    x[18,26]  old_TS2   -2.6569343065693434e+00
    x[18,26]  old_TS3   -2.6569343065693434e+00
    x[18,26]  old_TS4   -1.2746743542353844e+00
    x[18,27]  OBJ       4.1015624999999986e-02
    x[18,27]  onehot_18  1
    x[18,27]  w_lb_18_27  -4.9025936701360941e-02
    x[18,27]  w_ub_18_27  -1.0218978102189782e-01
    x[18,27]  hard_lower  27
    x[18,27]  hard_upper  27
    x[18,27]  old_TS1   -1.3237002909367455e+00
    x[18,27]  old_TS2   -2.7591240875912413e+00
    x[18,27]  old_TS3   -2.7591240875912413e+00
    x[18,27]  old_TS4   -1.3237002909367455e+00
    x[18,28]  OBJ       4.9218749999999985e-02
    x[18,28]  onehot_18  1
    x[18,28]  w_lb_18_28  -4.9025936701360941e-02
    x[18,28]  w_ub_18_28  -1.0218978102189782e-01
    x[18,28]  hard_lower  28
    x[18,28]  hard_upper  28
    x[18,28]  old_TS1   -1.3727262276381063e+00
    x[18,28]  old_TS2   -2.8613138686131392e+00
    x[18,28]  old_TS3   -2.8613138686131392e+00
    x[18,28]  old_TS4   -1.3727262276381063e+00
    x[18,29]  OBJ       5.7421874999999983e-02
    x[18,29]  onehot_18  1
    x[18,29]  w_lb_18_29  -4.9025936701360941e-02
    x[18,29]  w_ub_18_29  -1.0218978102189782e-01
    x[18,29]  hard_lower  29
    x[18,29]  hard_upper  29
    x[18,29]  old_TS1   -1.4217521643394673e+00
    x[18,29]  old_TS2   -2.9635036496350371e+00
    x[18,29]  old_TS3   -2.9635036496350371e+00
    x[18,29]  old_TS4   -1.4217521643394673e+00
    x[18,30]  OBJ       6.5624999999999975e-02
    x[18,30]  onehot_18  1
    x[18,30]  w_lb_18_30  -4.9025936701360941e-02
    x[18,30]  w_ub_18_30  -1.0218978102189782e-01
    x[18,30]  hard_lower  30
    x[18,30]  hard_upper  30
    x[18,30]  old_TS1   -1.4707781010408283e+00
    x[18,30]  old_TS2   -3.0656934306569346e+00
    x[18,30]  old_TS3   -3.0656934306569346e+00
    x[18,30]  old_TS4   -1.4707781010408283e+00
    x[19,0]   OBJ       4.2187499999999989e-02
    x[19,0]   onehot_19  1
    x[19,0]   w_lb_19_0  -4.9025936701360941e-02
    x[19,0]   w_ub_19_0  -1.0218978102189782e-01
    x[19,1]   OBJ       3.5156249999999993e-02
    x[19,1]   onehot_19  1
    x[19,1]   w_lb_19_1  -4.9025936701360941e-02
    x[19,1]   w_ub_19_1  -1.0218978102189782e-01
    x[19,1]   hard_lower  1
    x[19,1]   hard_upper  1
    x[19,1]   old_TS1   -4.9025936701360941e-02
    x[19,1]   old_TS2   -1.0218978102189782e-01
    x[19,1]   old_TS3   -1.0218978102189782e-01
    x[19,1]   old_TS4   -4.9025936701360941e-02
    x[19,2]   OBJ       2.8124999999999994e-02
    x[19,2]   onehot_19  1
    x[19,2]   w_lb_19_2  -4.9025936701360941e-02
    x[19,2]   w_ub_19_2  -1.0218978102189782e-01
    x[19,2]   hard_lower  2
    x[19,2]   hard_upper  2
    x[19,2]   old_TS1   -9.8051873402721881e-02
    x[19,2]   old_TS2   -2.0437956204379565e-01
    x[19,2]   old_TS3   -2.0437956204379565e-01
    x[19,2]   old_TS4   -9.8051873402721881e-02
    x[19,3]   OBJ       2.1093749999999994e-02
    x[19,3]   onehot_19  1
    x[19,3]   w_lb_19_3  -4.9025936701360941e-02
    x[19,3]   w_ub_19_3  -1.0218978102189782e-01
    x[19,3]   hard_lower  3
    x[19,3]   hard_upper  3
    x[19,3]   old_TS1   -1.4707781010408283e-01
    x[19,3]   old_TS2   -3.0656934306569350e-01
    x[19,3]   old_TS3   -3.0656934306569350e-01
    x[19,3]   old_TS4   -1.4707781010408283e-01
    x[19,4]   OBJ       1.4062499999999997e-02
    x[19,4]   onehot_19  1
    x[19,4]   w_lb_19_4  -4.9025936701360941e-02
    x[19,4]   w_ub_19_4  -1.0218978102189782e-01
    x[19,4]   hard_lower  4
    x[19,4]   hard_upper  4
    x[19,4]   old_TS1   -1.9610374680544376e-01
    x[19,4]   old_TS2   -4.0875912408759130e-01
    x[19,4]   old_TS3   -4.0875912408759130e-01
    x[19,4]   old_TS4   -1.9610374680544376e-01
    x[19,5]   OBJ       7.0312499999999984e-03
    x[19,5]   onehot_19  1
    x[19,5]   w_lb_19_5  -4.9025936701360941e-02
    x[19,5]   w_ub_19_5  -1.0218978102189782e-01
    x[19,5]   hard_lower  5
    x[19,5]   hard_upper  5
    x[19,5]   old_TS1   -2.4512968350680470e-01
    x[19,5]   old_TS2   -5.1094890510948909e-01
    x[19,5]   old_TS3   -5.1094890510948909e-01
    x[19,5]   old_TS4   -2.4512968350680470e-01
    x[19,6]   onehot_19  1
    x[19,6]   w_lb_19_6  -4.9025936701360941e-02
    x[19,6]   w_ub_19_6  -1.0218978102189782e-01
    x[19,6]   hard_lower  6
    x[19,6]   hard_upper  6
    x[19,6]   old_TS1   -2.9415562020816566e-01
    x[19,6]   old_TS2   -0.613138686131387
    x[19,6]   old_TS3   -0.613138686131387
    x[19,6]   old_TS4   -2.9415562020816566e-01
    x[19,7]   OBJ       -7.0312499999999993e-03
    x[19,7]   onehot_19  1
    x[19,7]   w_lb_19_7  -4.9025936701360941e-02
    x[19,7]   w_ub_19_7  -1.0218978102189782e-01
    x[19,7]   hard_lower  7
    x[19,7]   hard_upper  7
    x[19,7]   old_TS1   -3.4318155690952656e-01
    x[19,7]   old_TS2   -7.1532846715328480e-01
    x[19,7]   old_TS3   -7.1532846715328480e-01
    x[19,7]   old_TS4   -3.4318155690952656e-01
    x[19,8]   OBJ       -1.4062499999999999e-02
    x[19,8]   onehot_19  1
    x[19,8]   w_lb_19_8  -4.9025936701360941e-02
    x[19,8]   w_ub_19_8  -1.0218978102189782e-01
    x[19,8]   hard_lower  8
    x[19,8]   hard_upper  8
    x[19,8]   old_TS1   -3.9220749361088753e-01
    x[19,8]   old_TS2   -8.1751824817518259e-01
    x[19,8]   old_TS3   -8.1751824817518259e-01
    x[19,8]   old_TS4   -3.9220749361088753e-01
    x[19,9]   OBJ       -2.1093749999999998e-02
    x[19,9]   onehot_19  1
    x[19,9]   w_lb_19_9  -4.9025936701360941e-02
    x[19,9]   w_ub_19_9  -1.0218978102189782e-01
    x[19,9]   hard_lower  9
    x[19,9]   hard_upper  9
    x[19,9]   old_TS1   -4.4123343031224849e-01
    x[19,9]   old_TS2   -9.1970802919708039e-01
    x[19,9]   old_TS3   -9.1970802919708039e-01
    x[19,9]   old_TS4   -4.4123343031224849e-01
    x[19,10]  OBJ       -2.8124999999999997e-02
    x[19,10]  onehot_19  1
    x[19,10]  w_lb_19_10  -4.9025936701360941e-02
    x[19,10]  w_ub_19_10  -1.0218978102189782e-01
    x[19,10]  hard_lower  10
    x[19,10]  hard_upper  10
    x[19,10]  old_TS1   -4.9025936701360939e-01
    x[19,10]  old_TS2   -1.0218978102189782e+00
    x[19,10]  old_TS3   -1.0218978102189782e+00
    x[19,10]  old_TS4   -4.9025936701360939e-01
    x[19,11]  OBJ       -0.03515625
    x[19,11]  onehot_19  1
    x[19,11]  w_lb_19_11  -4.9025936701360941e-02
    x[19,11]  w_ub_19_11  -1.0218978102189782e-01
    x[19,11]  hard_lower  11
    x[19,11]  hard_upper  11
    x[19,11]  old_TS1   -5.3928530371497030e-01
    x[19,11]  old_TS2   -1.1240875912408761e+00
    x[19,11]  old_TS3   -1.1240875912408761e+00
    x[19,11]  old_TS4   -5.3928530371497030e-01
    x[19,12]  OBJ       -4.2187499999999996e-02
    x[19,12]  onehot_19  1
    x[19,12]  w_lb_19_12  -4.9025936701360941e-02
    x[19,12]  w_ub_19_12  -1.0218978102189782e-01
    x[19,12]  hard_lower  12
    x[19,12]  hard_upper  12
    x[19,12]  old_TS1   -5.8831124041633132e-01
    x[19,12]  old_TS2   -1.2262773722627740e+00
    x[19,12]  old_TS3   -1.2262773722627740e+00
    x[19,12]  old_TS4   -5.8831124041633132e-01
    x[19,13]  OBJ       -3.5156250000000007e-02
    x[19,13]  onehot_19  1
    x[19,13]  w_lb_19_13  -4.9025936701360941e-02
    x[19,13]  w_ub_19_13  -1.0218978102189782e-01
    x[19,13]  hard_lower  13
    x[19,13]  hard_upper  13
    x[19,13]  old_TS1   -6.3733717711769222e-01
    x[19,13]  old_TS2   -1.3284671532846717e+00
    x[19,13]  old_TS3   -1.3284671532846717e+00
    x[19,13]  old_TS4   -6.3733717711769222e-01
    x[20,14]  OBJ       -0.046875
    x[20,14]  onehot_20  1
    x[20,14]  w_lb_20_14  -4.9025936701360941e-02
    x[20,14]  w_ub_20_14  -1.0218978102189782e-01
    x[20,14]  hard_lower  14
    x[20,14]  hard_upper  14
    x[20,14]  old_TS1   -6.8636311381905313e-01
    x[20,14]  old_TS2   -1.4306569343065696e+00
    x[20,14]  old_TS3   -1.4306569343065696e+00
    x[20,14]  old_TS4   -6.8636311381905313e-01
    x[20,15]  OBJ       -0.05625
    x[20,15]  onehot_20  1
    x[20,15]  w_lb_20_15  -4.9025936701360941e-02
    x[20,15]  w_ub_20_15  -1.0218978102189782e-01
    x[20,15]  hard_lower  15
    x[20,15]  hard_upper  15
    x[20,15]  old_TS1   -7.3538905052041414e-01
    x[20,15]  old_TS2   -1.5328467153284673e+00
    x[20,15]  old_TS3   -1.5328467153284673e+00
    x[20,15]  old_TS4   -7.3538905052041414e-01
    x[20,16]  OBJ       -0.065625
    x[20,16]  onehot_20  1
    x[20,16]  w_lb_20_16  -4.9025936701360941e-02
    x[20,16]  w_ub_20_16  -1.0218978102189782e-01
    x[20,16]  hard_lower  16
    x[20,16]  hard_upper  16
    x[20,16]  old_TS1   -0.784414987221775
    x[20,16]  old_TS2   -1.6350364963503652e+00
    x[20,16]  old_TS3   -1.6350364963503652e+00
    x[20,16]  old_TS4   -0.784414987221775
    x[20,17]  OBJ       -0.05625
    x[20,17]  onehot_20  1
    x[20,17]  w_lb_20_17  -4.9025936701360941e-02
    x[20,17]  w_ub_20_17  -1.0218978102189782e-01
    x[20,17]  hard_lower  17
    x[20,17]  hard_upper  17
    x[20,17]  old_TS1   -0.833440923923136
    x[20,17]  old_TS2   -1.7372262773722631e+00
    x[20,17]  old_TS3   -1.7372262773722631e+00
    x[20,17]  old_TS4   -0.833440923923136
    x[20,18]  OBJ       -0.046875
    x[20,18]  onehot_20  1
    x[20,18]  w_lb_20_18  -4.9025936701360941e-02
    x[20,18]  w_ub_20_18  -1.0218978102189782e-01
    x[20,18]  hard_lower  18
    x[20,18]  hard_upper  18
    x[20,18]  old_TS1   -0.882466860624497
    x[20,18]  old_TS2   -1.8394160583941608e+00
    x[20,18]  old_TS3   -1.8394160583941608e+00
    x[20,18]  old_TS4   -0.882466860624497
    x[20,19]  OBJ       -0.0375
    x[20,19]  onehot_20  1
    x[20,19]  w_lb_20_19  -4.9025936701360941e-02
    x[20,19]  w_ub_20_19  -1.0218978102189782e-01
    x[20,19]  hard_lower  19
    x[20,19]  hard_upper  19
    x[20,19]  old_TS1   -9.3149279732585788e-01
    x[20,19]  old_TS2   -1.9416058394160587e+00
    x[20,19]  old_TS3   -1.9416058394160587e+00
    x[20,19]  old_TS4   -9.3149279732585788e-01
    x[20,20]  OBJ       -0.028125
    x[20,20]  onehot_20  1
    x[20,20]  w_lb_20_20  -4.9025936701360941e-02
    x[20,20]  w_ub_20_20  -1.0218978102189782e-01
    x[20,20]  hard_lower  20
    x[20,20]  hard_upper  20
    x[20,20]  old_TS1   -9.8051873402721879e-01
    x[20,20]  old_TS2   -2.0437956204379564e+00
    x[20,20]  old_TS3   -2.0437956204379564e+00
    x[20,20]  old_TS4   -9.8051873402721879e-01
    x[20,21]  OBJ       -0.01875
    x[20,21]  onehot_20  1
    x[20,21]  w_lb_20_21  -4.9025936701360941e-02
    x[20,21]  w_ub_20_21  -1.0218978102189782e-01
    x[20,21]  hard_lower  21
    x[20,21]  hard_upper  21
    x[20,21]  old_TS1   -1.0295446707285798e+00
    x[20,21]  old_TS2   -2.1459854014598543e+00
    x[20,21]  old_TS3   -2.1459854014598543e+00
    x[20,21]  old_TS4   -1.0295446707285798e+00
    x[20,22]  OBJ       -0.009375
    x[20,22]  onehot_20  1
    x[20,22]  w_lb_20_22  -4.9025936701360941e-02
    x[20,22]  w_ub_20_22  -1.0218978102189782e-01
    x[20,22]  hard_lower  22
    x[20,22]  hard_upper  22
    x[20,22]  old_TS1   -1.0785706074299406e+00
    x[20,22]  old_TS2   -2.2481751824817522e+00
    x[20,22]  old_TS3   -2.2481751824817522e+00
    x[20,22]  old_TS4   -1.0785706074299406e+00
    x[20,23]  onehot_20  1
    x[20,23]  w_lb_20_23  -4.9025936701360941e-02
    x[20,23]  w_ub_20_23  -1.0218978102189782e-01
    x[20,23]  hard_lower  23
    x[20,23]  hard_upper  23
    x[20,23]  old_TS1   -1.1275965441313016e+00
    x[20,23]  old_TS2   -2.35036496350365
    x[20,23]  old_TS3   -2.35036496350365
    x[20,23]  old_TS4   -1.1275965441313016e+00
    x[20,24]  OBJ       0.009375
    x[20,24]  onehot_20  1
    x[20,24]  w_lb_20_24  -4.9025936701360941e-02
    x[20,24]  w_ub_20_24  -1.0218978102189782e-01
    x[20,24]  hard_lower  24
    x[20,24]  hard_upper  24
    x[20,24]  old_TS1   -1.1766224808326626e+00
    x[20,24]  old_TS2   -2.4525547445255480e+00
    x[20,24]  old_TS3   -2.4525547445255480e+00
    x[20,24]  old_TS4   -1.1766224808326626e+00
    x[20,25]  OBJ       0.01875
    x[20,25]  onehot_20  1
    x[20,25]  w_lb_20_25  -4.9025936701360941e-02
    x[20,25]  w_ub_20_25  -1.0218978102189782e-01
    x[20,25]  hard_lower  25
    x[20,25]  hard_upper  25
    x[20,25]  old_TS1   -1.2256484175340234e+00
    x[20,25]  old_TS2   -2.5547445255474455e+00
    x[20,25]  old_TS3   -2.5547445255474455e+00
    x[20,25]  old_TS4   -1.2256484175340234e+00
    x[20,26]  OBJ       2.8124999999999997e-02
    x[20,26]  onehot_20  1
    x[20,26]  w_lb_20_26  -4.9025936701360941e-02
    x[20,26]  w_ub_20_26  -1.0218978102189782e-01
    x[20,26]  hard_lower  26
    x[20,26]  hard_upper  26
    x[20,26]  old_TS1   -1.2746743542353844e+00
    x[20,26]  old_TS2   -2.6569343065693434e+00
    x[20,26]  old_TS3   -2.6569343065693434e+00
    x[20,26]  old_TS4   -1.2746743542353844e+00
    x[20,27]  OBJ       0.0375
    x[20,27]  onehot_20  1
    x[20,27]  w_lb_20_27  -4.9025936701360941e-02
    x[20,27]  w_ub_20_27  -1.0218978102189782e-01
    x[20,27]  hard_lower  27
    x[20,27]  hard_upper  27
    x[20,27]  old_TS1   -1.3237002909367455e+00
    x[20,27]  old_TS2   -2.7591240875912413e+00
    x[20,27]  old_TS3   -2.7591240875912413e+00
    x[20,27]  old_TS4   -1.3237002909367455e+00
    x[20,28]  OBJ       4.6874999999999993e-02
    x[20,28]  onehot_20  1
    x[20,28]  w_lb_20_28  -4.9025936701360941e-02
    x[20,28]  w_ub_20_28  -1.0218978102189782e-01
    x[20,28]  hard_lower  28
    x[20,28]  hard_upper  28
    x[20,28]  old_TS1   -1.3727262276381063e+00
    x[20,28]  old_TS2   -2.8613138686131392e+00
    x[20,28]  old_TS3   -2.8613138686131392e+00
    x[20,28]  old_TS4   -1.3727262276381063e+00
    x[20,29]  OBJ       5.6249999999999994e-02
    x[20,29]  onehot_20  1
    x[20,29]  w_lb_20_29  -4.9025936701360941e-02
    x[20,29]  w_ub_20_29  -1.0218978102189782e-01
    x[20,29]  hard_lower  29
    x[20,29]  hard_upper  29
    x[20,29]  old_TS1   -1.4217521643394673e+00
    x[20,29]  old_TS2   -2.9635036496350371e+00
    x[20,29]  old_TS3   -2.9635036496350371e+00
    x[20,29]  old_TS4   -1.4217521643394673e+00
    x[20,30]  OBJ       6.5624999999999989e-02
    x[20,30]  onehot_20  1
    x[20,30]  w_lb_20_30  -4.9025936701360941e-02
    x[20,30]  w_ub_20_30  -1.0218978102189782e-01
    x[20,30]  hard_lower  30
    x[20,30]  hard_upper  30
    x[20,30]  old_TS1   -1.4707781010408283e+00
    x[20,30]  old_TS2   -3.0656934306569346e+00
    x[20,30]  old_TS3   -3.0656934306569346e+00
    x[20,30]  old_TS4   -1.4707781010408283e+00
    MARKER    'MARKER'                 'INTEND'
    w[1,0]    mass_1    1
    w[1,0]    w_lb_1_0  1
    w[1,0]    w_ub_1_0  1
    w[1,1]    mass_1    1
    w[1,1]    w_lb_1_1  1
    w[1,1]    w_ub_1_1  1
    w[1,1]    normalized_inventory_1  -1
    w[1,1]    old_normalized_TC2  5.5555555555555558e-01
    w[1,2]    mass_1    1
    w[1,2]    w_lb_1_2  1
    w[1,2]    w_ub_1_2  1
    w[1,2]    normalized_inventory_1  -2
    w[1,2]    old_normalized_TC2  1.0888888888888890e+00
    w[1,3]    mass_1    1
    w[1,3]    w_lb_1_3  1
    w[1,3]    w_ub_1_3  1
    w[1,3]    normalized_inventory_1  -3
    w[1,3]    old_normalized_TC2  1.5333333333333334e+00
    w[1,4]    mass_1    1
    w[1,4]    w_lb_1_4  1
    w[1,4]    w_ub_1_4  1
    w[1,4]    normalized_inventory_1  -4
    w[1,4]    old_normalized_TC2  1.8666666666666667e+00
    w[1,5]    mass_1    1
    w[1,5]    w_lb_1_5  1
    w[1,5]    w_ub_1_5  1
    w[1,5]    normalized_inventory_1  -5
    w[1,5]    old_normalized_TC2  2.0989898989898990e+00
    w[1,6]    mass_1    1
    w[1,6]    w_lb_1_6  1
    w[1,6]    w_ub_1_6  1
    w[1,6]    normalized_inventory_1  -6
    w[1,6]    old_normalized_TC2  2.3212121212121213e+00
    w[1,7]    mass_1    1
    w[1,7]    w_lb_1_7  1
    w[1,7]    w_ub_1_7  1
    w[1,7]    normalized_inventory_1  -7
    w[1,7]    old_normalized_TC2  2.47994227994228
    w[1,8]    mass_1    1
    w[1,8]    w_lb_1_8  1
    w[1,8]    w_ub_1_8  1
    w[1,8]    normalized_inventory_1  -8
    w[1,8]    old_normalized_TC  -5.5555555555555552e-02
    w[1,8]    old_normalized_TC2  2.5216089466089469e+00
    w[1,9]    mass_1    1
    w[1,9]    w_lb_1_9  1
    w[1,9]    w_ub_1_9  1
    w[1,9]    normalized_inventory_1  -9
    w[1,9]    old_normalized_TC  -2.5757575757575746e-01
    w[1,9]    old_normalized_TC2  2.3195887445887449e+00
    w[1,10]   mass_1    1
    w[1,10]   w_lb_1_10  1
    w[1,10]   w_ub_1_10  1
    w[1,10]   normalized_inventory_1  -10
    w[1,10]   old_normalized_TC  -6.3059163059163048e-01
    w[1,10]   old_normalized_TC2  1.9465728715728718e+00
    w[1,11]   mass_1    1
    w[1,11]   w_lb_1_11  1
    w[1,11]   w_ub_1_11  1
    w[1,11]   normalized_inventory_1  -11
    w[1,11]   old_normalized_TC  -1.1861471861471860e+00
    w[1,11]   old_normalized_TC2  1.3910173160173163e+00
    w[1,12]   mass_1    1
    w[1,12]   w_lb_1_12  1
    w[1,12]   w_ub_1_12  1
    w[1,12]   normalized_inventory_1  -12
    w[1,12]   old_normalized_TC  -1.8528138528138525e+00
    w[1,12]   old_normalized_TC2  7.2435064935064952e-01
    w[1,13]   mass_1    1
    w[1,13]   w_lb_1_13  1
    w[1,13]   w_ub_1_13  1
    w[1,13]   normalized_inventory_1  -13
    w[1,13]   old_normalized_TC  -2.6305916305916304e+00
    w[1,13]   old_normalized_TC2  -5.3427128427128240e-02
    w[1,14]   mass_1    1
    w[1,14]   w_lb_1_14  1
    w[1,14]   w_ub_1_14  1
    w[1,14]   normalized_inventory_1  -14
    w[1,14]   old_normalized_TC  -3.5194805194805192e+00
    w[1,14]   old_normalized_TC2  -0.942316017316017
    w[1,15]   mass_1    1
    w[1,15]   w_lb_1_15  1
    w[1,15]   w_ub_1_15  1
    w[1,15]   normalized_inventory_1  -15
    w[1,15]   old_normalized_TC  -4.5194805194805188e+00
    w[1,15]   old_normalized_TC2  -1.9423160173160170e+00
    w[1,16]   mass_1    1
    w[1,16]   w_lb_1_16  1
    w[1,16]   w_ub_1_16  1
    w[1,16]   normalized_inventory_1  -16
    w[1,16]   old_normalized_TC  -5.5829725829725820e+00
    w[1,16]   old_normalized_TC2  -3.0058080808080803e+00
    w[1,17]   mass_1    1
    w[1,17]   w_lb_1_17  1
    w[1,17]   w_ub_1_17  1
    w[1,17]   normalized_inventory_1  -17
    w[1,17]   old_normalized_TC  -6.6940836940836936e+00
    w[1,17]   old_normalized_TC2  -4.1169191919191910e+00
    w[1,18]   mass_1    1
    w[1,18]   w_lb_1_18  1
    w[1,18]   w_ub_1_18  1
    w[1,18]   normalized_inventory_1  -18
    w[1,18]   old_normalized_TC  -7.9163059163059151e+00
    w[1,18]   old_normalized_TC2  -5.3391414141414133e+00
    w[2,0]    mass_2    1
    w[2,0]    w_lb_2_0  1
    w[2,0]    w_ub_2_0  1
    w[2,1]    mass_2    1
    w[2,1]    w_lb_2_1  1
    w[2,1]    w_ub_2_1  1
    w[2,1]    normalized_inventory_2  -1
    w[2,1]    old_normalized_TC2  0.3125
    w[2,2]    mass_2    1
    w[2,2]    w_lb_2_2  1
    w[2,2]    w_ub_2_2  1
    w[2,2]    normalized_inventory_2  -2
    w[2,2]    old_normalized_TC2  0.625
    w[2,3]    mass_2    1
    w[2,3]    w_lb_2_3  1
    w[2,3]    w_ub_2_3  1
    w[2,3]    normalized_inventory_2  -3
    w[2,3]    old_normalized_TC2  0.9375
    w[2,4]    mass_2    1
    w[2,4]    w_lb_2_4  1
    w[2,4]    w_ub_2_4  1
    w[2,4]    normalized_inventory_2  -4
    w[2,4]    old_normalized_TC2  1.2000000000000002e+00
    w[2,5]    mass_2    1
    w[2,5]    w_lb_2_5  1
    w[2,5]    w_ub_2_5  1
    w[2,5]    normalized_inventory_2  -5
    w[2,5]    old_normalized_TC2  1.4500000000000002e+00
    w[2,6]    mass_2    1
    w[2,6]    w_lb_2_6  1
    w[2,6]    w_ub_2_6  1
    w[2,6]    normalized_inventory_2  -6
    w[2,6]    old_normalized_TC2  1.6583333333333334e+00
    w[2,7]    mass_2    1
    w[2,7]    w_lb_2_7  1
    w[2,7]    w_ub_2_7  1
    w[2,7]    normalized_inventory_2  -7
    w[2,7]    old_normalized_TC2  1.8458333333333334e+00
    w[2,8]    mass_2    1
    w[2,8]    w_lb_2_8  1
    w[2,8]    w_ub_2_8  1
    w[2,8]    normalized_inventory_2  -8
    w[2,8]    old_normalized_TC2  1.9878787878787880e+00
    w[2,9]    mass_2    1
    w[2,9]    w_lb_2_9  1
    w[2,9]    w_ub_2_9  1
    w[2,9]    normalized_inventory_2  -9
    w[2,9]    old_normalized_TC2  2.1128787878787882e+00
    w[2,10]   mass_2    1
    w[2,10]   w_lb_2_10  1
    w[2,10]   w_ub_2_10  1
    w[2,10]   normalized_inventory_2  -10
    w[2,10]   old_normalized_TC2  2.2378787878787882e+00
    w[2,11]   mass_2    1
    w[2,11]   w_lb_2_11  1
    w[2,11]   w_ub_2_11  1
    w[2,11]   normalized_inventory_2  -11
    w[2,11]   old_normalized_TC2  2.3628787878787882e+00
    w[2,12]   mass_2    1
    w[2,12]   w_lb_2_12  1
    w[2,12]   w_ub_2_12  1
    w[2,12]   normalized_inventory_2  -12
    w[2,12]   old_normalized_TC2  2.4521645021645022e+00
    w[2,13]   mass_2    1
    w[2,13]   w_lb_2_13  1
    w[2,13]   w_ub_2_13  1
    w[2,13]   normalized_inventory_2  -13
    w[2,13]   old_normalized_TC2  2.5146645021645022e+00
    w[2,14]   mass_2    1
    w[2,14]   w_lb_2_14  1
    w[2,14]   w_ub_2_14  1
    w[2,14]   normalized_inventory_2  -14
    w[2,14]   old_normalized_TC  -4.1666666666666713e-02
    w[2,14]   old_normalized_TC2  2.5354978354978357e+00
    w[2,15]   mass_2    1
    w[2,15]   w_lb_2_15  1
    w[2,15]   w_ub_2_15  1
    w[2,15]   normalized_inventory_2  -15
    w[2,15]   old_normalized_TC  -1.3257575757575760e-01
    w[2,15]   old_normalized_TC2  2.4445887445887449e+00
    w[2,16]   mass_2    1
    w[2,16]   w_lb_2_16  1
    w[2,16]   w_ub_2_16  1
    w[2,16]   normalized_inventory_2  -16
    w[2,16]   old_normalized_TC  -2.5757575757575762e-01
    w[2,16]   old_normalized_TC2  2.3195887445887449e+00
    w[2,17]   mass_2    1
    w[2,17]   w_lb_2_17  1
    w[2,17]   w_ub_2_17  1
    w[2,17]   normalized_inventory_2  -17
    w[2,17]   old_normalized_TC  -4.4507575757575762e-01
    w[2,17]   old_normalized_TC2  2.1320887445887449e+00
    w[2,18]   mass_2    1
    w[2,18]   w_lb_2_18  1
    w[2,18]   w_ub_2_18  1
    w[2,18]   normalized_inventory_2  -18
    w[2,18]   old_normalized_TC  -7.0003607503607523e-01
    w[2,18]   old_normalized_TC2  1.8771284271284270e+00
    w[2,19]   mass_2    1
    w[2,19]   w_lb_2_19  1
    w[2,19]   w_ub_2_19  1
    w[2,19]   normalized_inventory_2  -19
    w[2,19]   old_normalized_TC  -1.0125360750360752e+00
    w[2,19]   old_normalized_TC2  1.5646284271284270e+00
    w[2,20]   mass_2    1
    w[2,20]   w_lb_2_20  1
    w[2,20]   w_ub_2_20  1
    w[2,20]   normalized_inventory_2  -20
    w[2,20]   old_normalized_TC  -1.3528138528138529e+00
    w[2,20]   old_normalized_TC2  1.2243506493506491e+00
    w[2,21]   mass_2    1
    w[2,21]   w_lb_2_21  1
    w[2,21]   w_ub_2_21  1
    w[2,21]   normalized_inventory_2  -21
    w[2,21]   old_normalized_TC  -1.7278138528138529e+00
    w[2,21]   old_normalized_TC2  8.4935064935064908e-01
    w[2,22]   mass_2    1
    w[2,22]   w_lb_2_22  1
    w[2,22]   w_ub_2_22  1
    w[2,22]   normalized_inventory_2  -22
    w[2,22]   old_normalized_TC  -2.1444805194805197e+00
    w[2,22]   old_normalized_TC2  4.3268398268398234e-01
    w[2,23]   mass_2    1
    w[2,23]   w_lb_2_23  1
    w[2,23]   w_ub_2_23  1
    w[2,23]   normalized_inventory_2  -23
    w[2,23]   old_normalized_TC  -2.5819805194805197e+00
    w[2,23]   old_normalized_TC2  -0.00481601731601769
    w[2,24]   mass_2    1
    w[2,24]   w_lb_2_24  1
    w[2,24]   w_ub_2_24  1
    w[2,24]   normalized_inventory_2  -24
    w[2,24]   old_normalized_TC  -3.0750360750360755e+00
    w[2,24]   old_normalized_TC2  -4.9787157287157330e-01
    w[2,25]   mass_2    1
    w[2,25]   w_lb_2_25  1
    w[2,25]   w_ub_2_25  1
    w[2,25]   normalized_inventory_2  -25
    w[2,25]   old_normalized_TC  -3.5819805194805197e+00
    w[2,25]   old_normalized_TC2  -1.0048160173160177e+00
    w[2,26]   mass_2    1
    w[2,26]   w_lb_2_26  1
    w[2,26]   w_ub_2_26  1
    w[2,26]   normalized_inventory_2  -26
    w[2,26]   old_normalized_TC  -4.14448051948052
    w[2,26]   old_normalized_TC2  -1.5673160173160177e+00
    w[2,27]   mass_2    1
    w[2,27]   w_lb_2_27  1
    w[2,27]   w_ub_2_27  1
    w[2,27]   normalized_inventory_2  -27
    w[2,27]   old_normalized_TC  -4.70698051948052
    w[2,27]   old_normalized_TC2  -2.1298160173160174e+00
    w[2,28]   mass_2    1
    w[2,28]   w_lb_2_28  1
    w[2,28]   w_ub_2_28  1
    w[2,28]   normalized_inventory_2  -28
    w[2,28]   old_normalized_TC  -5.3051948051948052e+00
    w[2,28]   old_normalized_TC2  -2.7280303030303035e+00
    w[2,29]   mass_2    1
    w[2,29]   w_lb_2_29  1
    w[2,29]   w_ub_2_29  1
    w[2,29]   normalized_inventory_2  -29
    w[2,29]   old_normalized_TC  -5.9301948051948052e+00
    w[2,29]   old_normalized_TC2  -3.3530303030303035e+00
    w[3,0]    mass_3    1
    w[3,0]    w_lb_3_0  1
    w[3,0]    w_ub_3_0  1
    w[3,1]    mass_3    1
    w[3,1]    w_lb_3_1  1
    w[3,1]    w_ub_3_1  1
    w[3,1]    normalized_inventory_3  -1
    w[3,1]    old_normalized_TC2  4.5454545454545459e-01
    w[3,2]    mass_3    1
    w[3,2]    w_lb_3_2  1
    w[3,2]    w_ub_3_2  1
    w[3,2]    normalized_inventory_3  -2
    w[3,2]    old_normalized_TC2  9.0909090909090917e-01
    w[3,3]    mass_3    1
    w[3,3]    w_lb_3_3  1
    w[3,3]    w_ub_3_3  1
    w[3,3]    normalized_inventory_3  -3
    w[3,3]    old_normalized_TC2  1.2909090909090910e+00
    w[3,4]    mass_3    1
    w[3,4]    w_lb_3_4  1
    w[3,4]    w_ub_3_4  1
    w[3,4]    normalized_inventory_3  -4
    w[3,4]    old_normalized_TC2  1.6242424242424243e+00
    w[3,5]    mass_3    1
    w[3,5]    w_lb_3_5  1
    w[3,5]    w_ub_3_5  1
    w[3,5]    normalized_inventory_3  -5
    w[3,5]    old_normalized_TC2  1.8969696969696972e+00
    w[3,6]    mass_3    1
    w[3,6]    w_lb_3_6  1
    w[3,6]    w_ub_3_6  1
    w[3,6]    normalized_inventory_3  -6
    w[3,6]    old_normalized_TC2  2.0787878787878791e+00
    w[3,7]    mass_3    1
    w[3,7]    w_lb_3_7  1
    w[3,7]    w_ub_3_7  1
    w[3,7]    normalized_inventory_3  -7
    w[3,7]    old_normalized_TC2  2.2606060606060607e+00
    w[3,8]    mass_3    1
    w[3,8]    w_lb_3_8  1
    w[3,8]    w_ub_3_8  1
    w[3,8]    normalized_inventory_3  -8
    w[3,8]    old_normalized_TC2  2.4294372294372297e+00
    w[3,9]    mass_3    1
    w[3,9]    w_lb_3_9  1
    w[3,9]    w_ub_3_9  1
    w[3,9]    normalized_inventory_3  -9
    w[3,9]    old_normalized_TC2  2.5203463203463206e+00
    w[3,10]   mass_3    1
    w[3,10]   w_lb_3_10  1
    w[3,10]   w_ub_3_10  1
    w[3,10]   normalized_inventory_3  -10
    w[3,10]   old_normalized_TC  -7.5757575757575829e-02
    w[3,10]   old_normalized_TC2  2.5014069264069265e+00
    w[3,11]   mass_3    1
    w[3,11]   w_lb_3_11  1
    w[3,11]   w_ub_3_11  1
    w[3,11]   normalized_inventory_3  -11
    w[3,11]   old_normalized_TC  -2.5757575757575774e-01
    w[3,11]   old_normalized_TC2  2.3195887445887444e+00
    w[3,12]   mass_3    1
    w[3,12]   w_lb_3_12  1
    w[3,12]   w_ub_3_12  1
    w[3,12]   normalized_inventory_3  -12
    w[3,12]   old_normalized_TC  -0.54978354978355
    w[3,12]   old_normalized_TC2  2.0273809523809523e+00
    w[3,13]   mass_3    1
    w[3,13]   w_lb_3_13  1
    w[3,13]   w_ub_3_13  1
    w[3,13]   normalized_inventory_3  -13
    w[3,13]   old_normalized_TC  -9.8412698412698441e-01
    w[3,13]   old_normalized_TC2  1.5930375180375178e+00
    w[3,14]   mass_3    1
    w[3,14]   w_lb_3_14  1
    w[3,14]   w_ub_3_14  1
    w[3,14]   normalized_inventory_3  -14
    w[3,14]   old_normalized_TC  -1.4891774891774896e+00
    w[3,14]   old_normalized_TC2  1.0879870129870126e+00
    w[3,15]   mass_3    1
    w[3,15]   w_lb_3_15  1
    w[3,15]   w_ub_3_15  1
    w[3,15]   normalized_inventory_3  -15
    w[3,15]   old_normalized_TC  -2.0649350649350655e+00
    w[3,15]   old_normalized_TC2  5.1222943722943659e-01
    w[3,16]   mass_3    1
    w[3,16]   w_lb_3_16  1
    w[3,16]   w_ub_3_16  1
    w[3,16]   normalized_inventory_3  -16
    w[3,16]   old_normalized_TC  -2.7113997113997121e+00
    w[3,16]   old_normalized_TC2  -0.13423520923521
    w[3,17]   mass_3    1
    w[3,17]   w_lb_3_17  1
    w[3,17]   w_ub_3_17  1
    w[3,17]   normalized_inventory_3  -17
    w[3,17]   old_normalized_TC  -3.4386724386724392e+00
    w[3,17]   old_normalized_TC2  -8.6150793650793722e-01
    w[3,18]   mass_3    1
    w[3,18]   w_lb_3_18  1
    w[3,18]   w_ub_3_18  1
    w[3,18]   normalized_inventory_3  -18
    w[3,18]   old_normalized_TC  -4.2467532467532472e+00
    w[3,18]   old_normalized_TC2  -1.6695887445887454e+00
    w[3,19]   mass_3    1
    w[3,19]   w_lb_3_19  1
    w[3,19]   w_ub_3_19  1
    w[3,19]   normalized_inventory_3  -19
    w[3,19]   old_normalized_TC  -5.0779220779220786e+00
    w[3,19]   old_normalized_TC2  -2.5007575757575768e+00
    w[3,20]   mass_3    1
    w[3,20]   w_lb_3_20  1
    w[3,20]   w_ub_3_20  1
    w[3,20]   normalized_inventory_3  -20
    w[3,20]   old_normalized_TC  -5.9870129870129878e+00
    w[3,20]   old_normalized_TC2  -3.4098484848484856e+00
    w[3,21]   mass_3    1
    w[3,21]   w_lb_3_21  1
    w[3,21]   w_ub_3_21  1
    w[3,21]   normalized_inventory_3  -21
    w[3,21]   old_normalized_TC  -6.9163059163059168e+00
    w[3,21]   old_normalized_TC2  -4.3391414141414151e+00
    w[4,0]    mass_4    1
    w[4,0]    w_lb_4_0  1
    w[4,0]    w_ub_4_0  1
    w[4,1]    mass_4    1
    w[4,1]    w_lb_4_1  1
    w[4,1]    w_ub_4_1  1
    w[4,1]    normalized_inventory_4  -1
    w[4,1]    old_normalized_TC2  5.0000000000000011e-01
    w[4,2]    mass_4    1
    w[4,2]    w_lb_4_2  1
    w[4,2]    w_ub_4_2  1
    w[4,2]    normalized_inventory_4  -2
    w[4,2]    old_normalized_TC2  1.0000000000000002e+00
    w[4,3]    mass_4    1
    w[4,3]    w_lb_4_3  1
    w[4,3]    w_ub_4_3  1
    w[4,3]    normalized_inventory_4  -3
    w[4,3]    old_normalized_TC2  1.4000000000000001e+00
    w[4,4]    mass_4    1
    w[4,4]    w_lb_4_4  1
    w[4,4]    w_ub_4_4  1
    w[4,4]    normalized_inventory_4  -4
    w[4,4]    old_normalized_TC2  1.7333333333333334e+00
    w[4,5]    mass_4    1
    w[4,5]    w_lb_4_5  1
    w[4,5]    w_ub_4_5  1
    w[4,5]    normalized_inventory_4  -5
    w[4,5]    old_normalized_TC2  1.9878787878787880e+00
    w[4,6]    mass_4    1
    w[4,6]    w_lb_4_6  1
    w[4,6]    w_ub_4_6  1
    w[4,6]    normalized_inventory_4  -6
    w[4,6]    old_normalized_TC2  2.1878787878787880e+00
    w[4,7]    mass_4    1
    w[4,7]    w_lb_4_7  1
    w[4,7]    w_ub_4_7  1
    w[4,7]    normalized_inventory_4  -7
    w[4,7]    old_normalized_TC2  2.3878787878787882e+00
    w[4,8]    mass_4    1
    w[4,8]    w_lb_4_8  1
    w[4,8]    w_ub_4_8  1
    w[4,8]    normalized_inventory_4  -8
    w[4,8]    old_normalized_TC2  2.5021645021645025e+00
    w[4,9]    mass_4    1
    w[4,9]    w_lb_4_9  1
    w[4,9]    w_ub_4_9  1
    w[4,9]    normalized_inventory_4  -9
    w[4,9]    old_normalized_TC  -6.6666666666666763e-02
    w[4,9]    old_normalized_TC2  2.5104978354978358e+00
    w[4,10]   mass_4    1
    w[4,10]   w_lb_4_10  1
    w[4,10]   w_ub_4_10  1
    w[4,10]   normalized_inventory_4  -10
    w[4,10]   old_normalized_TC  -2.5757575757575779e-01
    w[4,10]   old_normalized_TC2  2.3195887445887444e+00
    w[4,11]   mass_4    1
    w[4,11]   w_lb_4_11  1
    w[4,11]   w_ub_4_11  1
    w[4,11]   normalized_inventory_4  -11
    w[4,11]   old_normalized_TC  -5.8614718614718653e-01
    w[4,11]   old_normalized_TC2  1.9910173160173157e+00
    w[4,12]   mass_4    1
    w[4,12]   w_lb_4_12  1
    w[4,12]   w_ub_4_12  1
    w[4,12]   normalized_inventory_4  -12
    w[4,12]   old_normalized_TC  -1.0750360750360755e+00
    w[4,12]   old_normalized_TC2  1.5021284271284268e+00
    w[4,13]   mass_4    1
    w[4,13]   w_lb_4_13  1
    w[4,13]   w_ub_4_13  1
    w[4,13]   normalized_inventory_4  -13
    w[4,13]   old_normalized_TC  -1.6528138528138534e+00
    w[4,13]   old_normalized_TC2  9.2435064935064870e-01
    w[4,14]   mass_4    1
    w[4,14]   w_lb_4_14  1
    w[4,14]   w_ub_4_14  1
    w[4,14]   normalized_inventory_4  -14
    w[4,14]   old_normalized_TC  -2.3194805194805204e+00
    w[4,14]   old_normalized_TC2  2.5768398268398179e-01
    w[4,15]   mass_4    1
    w[4,15]   w_lb_4_15  1
    w[4,15]   w_ub_4_15  1
    w[4,15]   normalized_inventory_4  -15
    w[4,15]   old_normalized_TC  -3.0750360750360759e+00
    w[4,15]   old_normalized_TC2  -4.9787157287157396e-01
    w[4,16]   mass_4    1
    w[4,16]   w_lb_4_16  1
    w[4,16]   w_ub_4_16  1
    w[4,16]   normalized_inventory_4  -16
    w[4,16]   old_normalized_TC  -3.9194805194805205e+00
    w[4,16]   old_normalized_TC2  -1.3423160173160185e+00
    w[4,17]   mass_4    1
    w[4,17]   w_lb_4_17  1
    w[4,17]   w_ub_4_17  1
    w[4,17]   normalized_inventory_4  -17
    w[4,17]   old_normalized_TC  -4.81948051948052
    w[4,17]   old_normalized_TC2  -2.2423160173160186e+00
    w[4,18]   mass_4    1
    w[4,18]   w_lb_4_18  1
    w[4,18]   w_ub_4_18  1
    w[4,18]   normalized_inventory_4  -18
    w[4,18]   old_normalized_TC  -5.8051948051948061e+00
    w[4,18]   old_normalized_TC2  -3.2280303030303044e+00
    w[4,19]   mass_4    1
    w[4,19]   w_lb_4_19  1
    w[4,19]   w_ub_4_19  1
    w[4,19]   normalized_inventory_4  -19
    w[4,19]   old_normalized_TC  -6.8163059163059181e+00
    w[4,19]   old_normalized_TC2  -4.2391414141414154e+00
    w[4,20]   mass_4    1
    w[4,20]   w_lb_4_20  1
    w[4,20]   w_ub_4_20  1
    w[4,20]   normalized_inventory_4  -20
    w[4,20]   old_normalized_TC  -7.9163059163059177e+00
    w[4,20]   old_normalized_TC2  -5.3391414141414160e+00
    w[5,0]    mass_5    1
    w[5,0]    w_lb_5_0  1
    w[5,0]    w_ub_5_0  1
    w[5,1]    mass_5    1
    w[5,1]    w_lb_5_1  1
    w[5,1]    w_ub_5_1  1
    w[5,1]    normalized_inventory_5  -1
    w[5,1]    old_normalized_TC2  4.1666666666666669e-01
    w[5,2]    mass_5    1
    w[5,2]    w_lb_5_2  1
    w[5,2]    w_ub_5_2  1
    w[5,2]    normalized_inventory_5  -2
    w[5,2]    old_normalized_TC2  8.3333333333333337e-01
    w[5,3]    mass_5    1
    w[5,3]    w_lb_5_3  1
    w[5,3]    w_ub_5_3  1
    w[5,3]    normalized_inventory_5  -3
    w[5,3]    old_normalized_TC2  1.2
    w[5,4]    mass_5    1
    w[5,4]    w_lb_5_4  1
    w[5,4]    w_ub_5_4  1
    w[5,4]    normalized_inventory_5  -4
    w[5,4]    old_normalized_TC2  1.5333333333333334e+00
    w[5,5]    mass_5    1
    w[5,5]    w_lb_5_5  1
    w[5,5]    w_ub_5_5  1
    w[5,5]    normalized_inventory_5  -5
    w[5,5]    old_normalized_TC2  1.7833333333333334e+00
    w[5,6]    mass_5    1
    w[5,6]    w_lb_5_6  1
    w[5,6]    w_ub_5_6  1
    w[5,6]    normalized_inventory_5  -6
    w[5,6]    old_normalized_TC2  1.9878787878787880e+00
    w[5,7]    mass_5    1
    w[5,7]    w_lb_5_7  1
    w[5,7]    w_ub_5_7  1
    w[5,7]    normalized_inventory_5  -7
    w[5,7]    old_normalized_TC2  2.1545454545454548e+00
    w[5,8]    mass_5    1
    w[5,8]    w_lb_5_8  1
    w[5,8]    w_ub_5_8  1
    w[5,8]    normalized_inventory_5  -8
    w[5,8]    old_normalized_TC2  2.3212121212121213e+00
    w[5,9]    mass_5    1
    w[5,9]    w_lb_5_9  1
    w[5,9]    w_ub_5_9  1
    w[5,9]    normalized_inventory_5  -9
    w[5,9]    old_normalized_TC2  2.4521645021645022e+00
    w[5,10]   mass_5    1
    w[5,10]   w_lb_5_10  1
    w[5,10]   w_ub_5_10  1
    w[5,10]   normalized_inventory_5  -10
    w[5,10]   old_normalized_TC2  2.5354978354978357e+00
    w[5,11]   mass_5    1
    w[5,11]   w_lb_5_11  1
    w[5,11]   w_ub_5_11  1
    w[5,11]   normalized_inventory_5  -11
    w[5,11]   old_normalized_TC  -9.0909090909090828e-02
    w[5,11]   old_normalized_TC2  2.4862554112554114e+00
    w[5,12]   mass_5    1
    w[5,12]   w_lb_5_12  1
    w[5,12]   w_ub_5_12  1
    w[5,12]   normalized_inventory_5  -12
    w[5,12]   old_normalized_TC  -2.5757575757575746e-01
    w[5,12]   old_normalized_TC2  2.3195887445887449e+00
    w[5,13]   mass_5    1
    w[5,13]   w_lb_5_13  1
    w[5,13]   w_ub_5_13  1
    w[5,13]   normalized_inventory_5  -13
    w[5,13]   old_normalized_TC  -5.1948051948051932e-01
    w[5,13]   old_normalized_TC2  2.0576839826839830e+00
    w[5,14]   mass_5    1
    w[5,14]   w_lb_5_14  1
    w[5,14]   w_ub_5_14  1
    w[5,14]   normalized_inventory_5  -14
    w[5,14]   old_normalized_TC  -9.0836940836940816e-01
    w[5,14]   old_normalized_TC2  1.6687950937950939e+00
    w[5,15]   mass_5    1
    w[5,15]   w_lb_5_15  1
    w[5,15]   w_ub_5_15  1
    w[5,15]   normalized_inventory_5  -15
    w[5,15]   old_normalized_TC  -1.3528138528138525e+00
    w[5,15]   old_normalized_TC2  1.2243506493506495e+00
    w[5,16]   mass_5    1
    w[5,16]   w_lb_5_16  1
    w[5,16]   w_ub_5_16  1
    w[5,16]   normalized_inventory_5  -16
    w[5,16]   old_normalized_TC  -1.8528138528138525e+00
    w[5,16]   old_normalized_TC2  7.2435064935064952e-01
    w[5,17]   mass_5    1
    w[5,17]   w_lb_5_17  1
    w[5,17]   w_ub_5_17  1
    w[5,17]   normalized_inventory_5  -17
    w[5,17]   old_normalized_TC  -2.4361471861471857e+00
    w[5,17]   old_normalized_TC2  1.4101731601731621e-01
    w[5,18]   mass_5    1
    w[5,18]   w_lb_5_18  1
    w[5,18]   w_ub_5_18  1
    w[5,18]   normalized_inventory_5  -18
    w[5,18]   old_normalized_TC  -3.0750360750360746e+00
    w[5,18]   old_normalized_TC2  -4.9787157287157263e-01
    w[5,19]   mass_5    1
    w[5,19]   w_lb_5_19  1
    w[5,19]   w_ub_5_19  1
    w[5,19]   normalized_inventory_5  -19
    w[5,19]   old_normalized_TC  -3.7694805194805188e+00
    w[5,19]   old_normalized_TC2  -1.1923160173160170e+00
    w[5,20]   mass_5    1
    w[5,20]   w_lb_5_20  1
    w[5,20]   w_ub_5_20  1
    w[5,20]   normalized_inventory_5  -20
    w[5,20]   old_normalized_TC  -4.5194805194805188e+00
    w[5,20]   old_normalized_TC2  -1.9423160173160170e+00
    w[5,21]   mass_5    1
    w[5,21]   w_lb_5_21  1
    w[5,21]   w_ub_5_21  1
    w[5,21]   normalized_inventory_5  -21
    w[5,21]   old_normalized_TC  -5.3051948051948044e+00
    w[5,21]   old_normalized_TC2  -2.7280303030303026e+00
    w[5,22]   mass_5    1
    w[5,22]   w_lb_5_22  1
    w[5,22]   w_ub_5_22  1
    w[5,22]   normalized_inventory_5  -22
    w[5,22]   old_normalized_TC  -6.1385281385281374e+00
    w[5,22]   old_normalized_TC2  -3.5613636363636356e+00
    w[5,23]   mass_5    1
    w[5,23]   w_lb_5_23  1
    w[5,23]   w_ub_5_23  1
    w[5,23]   normalized_inventory_5  -23
    w[5,23]   old_normalized_TC  -6.9996392496392490e+00
    w[5,23]   old_normalized_TC2  -4.4224747474747463e+00
    w[6,0]    mass_6    1
    w[6,0]    w_lb_6_0  1
    w[6,0]    w_ub_6_0  1
    w[6,1]    mass_6    1
    w[6,1]    w_lb_6_1  1
    w[6,1]    w_ub_6_1  1
    w[6,1]    normalized_inventory_6  -1
    w[6,1]    old_normalized_TC2  4.5454545454545459e-01
    w[6,2]    mass_6    1
    w[6,2]    w_lb_6_2  1
    w[6,2]    w_ub_6_2  1
    w[6,2]    normalized_inventory_6  -2
    w[6,2]    old_normalized_TC2  9.0909090909090917e-01
    w[6,3]    mass_6    1
    w[6,3]    w_lb_6_3  1
    w[6,3]    w_ub_6_3  1
    w[6,3]    normalized_inventory_6  -3
    w[6,3]    old_normalized_TC2  1.2909090909090910e+00
    w[6,4]    mass_6    1
    w[6,4]    w_lb_6_4  1
    w[6,4]    w_ub_6_4  1
    w[6,4]    normalized_inventory_6  -4
    w[6,4]    old_normalized_TC2  1.6242424242424243e+00
    w[6,5]    mass_6    1
    w[6,5]    w_lb_6_5  1
    w[6,5]    w_ub_6_5  1
    w[6,5]    normalized_inventory_6  -5
    w[6,5]    old_normalized_TC2  1.8969696969696972e+00
    w[6,6]    mass_6    1
    w[6,6]    w_lb_6_6  1
    w[6,6]    w_ub_6_6  1
    w[6,6]    normalized_inventory_6  -6
    w[6,6]    old_normalized_TC2  2.0787878787878791e+00
    w[6,7]    mass_6    1
    w[6,7]    w_lb_6_7  1
    w[6,7]    w_ub_6_7  1
    w[6,7]    normalized_inventory_6  -7
    w[6,7]    old_normalized_TC2  2.2606060606060607e+00
    w[6,8]    mass_6    1
    w[6,8]    w_lb_6_8  1
    w[6,8]    w_ub_6_8  1
    w[6,8]    normalized_inventory_6  -8
    w[6,8]    old_normalized_TC2  2.4294372294372297e+00
    w[6,9]    mass_6    1
    w[6,9]    w_lb_6_9  1
    w[6,9]    w_ub_6_9  1
    w[6,9]    normalized_inventory_6  -9
    w[6,9]    old_normalized_TC2  2.5203463203463206e+00
    w[6,10]   mass_6    1
    w[6,10]   w_lb_6_10  1
    w[6,10]   w_ub_6_10  1
    w[6,10]   normalized_inventory_6  -10
    w[6,10]   old_normalized_TC  -7.5757575757575829e-02
    w[6,10]   old_normalized_TC2  2.5014069264069265e+00
    w[6,11]   mass_6    1
    w[6,11]   w_lb_6_11  1
    w[6,11]   w_ub_6_11  1
    w[6,11]   normalized_inventory_6  -11
    w[6,11]   old_normalized_TC  -2.5757575757575774e-01
    w[6,11]   old_normalized_TC2  2.3195887445887444e+00
    w[6,12]   mass_6    1
    w[6,12]   w_lb_6_12  1
    w[6,12]   w_ub_6_12  1
    w[6,12]   normalized_inventory_6  -12
    w[6,12]   old_normalized_TC  -0.54978354978355
    w[6,12]   old_normalized_TC2  2.0273809523809523e+00
    w[6,13]   mass_6    1
    w[6,13]   w_lb_6_13  1
    w[6,13]   w_ub_6_13  1
    w[6,13]   normalized_inventory_6  -13
    w[6,13]   old_normalized_TC  -9.8412698412698441e-01
    w[6,13]   old_normalized_TC2  1.5930375180375178e+00
    w[6,14]   mass_6    1
    w[6,14]   w_lb_6_14  1
    w[6,14]   w_ub_6_14  1
    w[6,14]   normalized_inventory_6  -14
    w[6,14]   old_normalized_TC  -1.4891774891774896e+00
    w[6,14]   old_normalized_TC2  1.0879870129870126e+00
    w[6,15]   mass_6    1
    w[6,15]   w_lb_6_15  1
    w[6,15]   w_ub_6_15  1
    w[6,15]   normalized_inventory_6  -15
    w[6,15]   old_normalized_TC  -2.0649350649350655e+00
    w[6,15]   old_normalized_TC2  5.1222943722943659e-01
    w[6,16]   mass_6    1
    w[6,16]   w_lb_6_16  1
    w[6,16]   w_ub_6_16  1
    w[6,16]   normalized_inventory_6  -16
    w[6,16]   old_normalized_TC  -2.7113997113997121e+00
    w[6,16]   old_normalized_TC2  -0.13423520923521
    w[6,17]   mass_6    1
    w[6,17]   w_lb_6_17  1
    w[6,17]   w_ub_6_17  1
    w[6,17]   normalized_inventory_6  -17
    w[6,17]   old_normalized_TC  -3.4386724386724392e+00
    w[6,17]   old_normalized_TC2  -8.6150793650793722e-01
    w[6,18]   mass_6    1
    w[6,18]   w_lb_6_18  1
    w[6,18]   w_ub_6_18  1
    w[6,18]   normalized_inventory_6  -18
    w[6,18]   old_normalized_TC  -4.2467532467532472e+00
    w[6,18]   old_normalized_TC2  -1.6695887445887454e+00
    w[6,19]   mass_6    1
    w[6,19]   w_lb_6_19  1
    w[6,19]   w_ub_6_19  1
    w[6,19]   normalized_inventory_6  -19
    w[6,19]   old_normalized_TC  -5.0779220779220786e+00
    w[6,19]   old_normalized_TC2  -2.5007575757575768e+00
    w[6,20]   mass_6    1
    w[6,20]   w_lb_6_20  1
    w[6,20]   w_ub_6_20  1
    w[6,20]   normalized_inventory_6  -20
    w[6,20]   old_normalized_TC  -5.9870129870129878e+00
    w[6,20]   old_normalized_TC2  -3.4098484848484856e+00
    w[6,21]   mass_6    1
    w[6,21]   w_lb_6_21  1
    w[6,21]   w_ub_6_21  1
    w[6,21]   normalized_inventory_6  -21
    w[6,21]   old_normalized_TC  -6.9163059163059168e+00
    w[6,21]   old_normalized_TC2  -4.3391414141414151e+00
    w[6,22]   mass_6    1
    w[6,22]   w_lb_6_22  1
    w[6,22]   w_ub_6_22  1
    w[6,22]   normalized_inventory_6  -22
    w[6,22]   old_normalized_TC  -7.9163059163059177e+00
    w[6,22]   old_normalized_TC2  -5.3391414141414151e+00
    w[7,0]    mass_7    1
    w[7,0]    w_lb_7_0  1
    w[7,0]    w_ub_7_0  1
    w[7,1]    mass_7    1
    w[7,1]    w_lb_7_1  1
    w[7,1]    w_ub_7_1  1
    w[7,1]    normalized_inventory_7  -1
    w[7,1]    old_normalized_TC2  5.5555555555555558e-01
    w[7,2]    mass_7    1
    w[7,2]    w_lb_7_2  1
    w[7,2]    w_ub_7_2  1
    w[7,2]    normalized_inventory_7  -2
    w[7,2]    old_normalized_TC2  1.0888888888888890e+00
    w[7,3]    mass_7    1
    w[7,3]    w_lb_7_3  1
    w[7,3]    w_ub_7_3  1
    w[7,3]    normalized_inventory_7  -3
    w[7,3]    old_normalized_TC2  1.5333333333333334e+00
    w[7,4]    mass_7    1
    w[7,4]    w_lb_7_4  1
    w[7,4]    w_ub_7_4  1
    w[7,4]    normalized_inventory_7  -4
    w[7,4]    old_normalized_TC2  1.8666666666666667e+00
    w[7,5]    mass_7    1
    w[7,5]    w_lb_7_5  1
    w[7,5]    w_ub_7_5  1
    w[7,5]    normalized_inventory_7  -5
    w[7,5]    old_normalized_TC2  2.0989898989898990e+00
    w[7,6]    mass_7    1
    w[7,6]    w_lb_7_6  1
    w[7,6]    w_ub_7_6  1
    w[7,6]    normalized_inventory_7  -6
    w[7,6]    old_normalized_TC2  2.3212121212121213e+00
    w[7,7]    mass_7    1
    w[7,7]    w_lb_7_7  1
    w[7,7]    w_ub_7_7  1
    w[7,7]    normalized_inventory_7  -7
    w[7,7]    old_normalized_TC2  2.47994227994228
    w[7,8]    mass_7    1
    w[7,8]    w_lb_7_8  1
    w[7,8]    w_ub_7_8  1
    w[7,8]    normalized_inventory_7  -8
    w[7,8]    old_normalized_TC  -5.5555555555555552e-02
    w[7,8]    old_normalized_TC2  2.5216089466089469e+00
    w[7,9]    mass_7    1
    w[7,9]    w_lb_7_9  1
    w[7,9]    w_ub_7_9  1
    w[7,9]    normalized_inventory_7  -9
    w[7,9]    old_normalized_TC  -2.5757575757575746e-01
    w[7,9]    old_normalized_TC2  2.3195887445887449e+00
    w[7,10]   mass_7    1
    w[7,10]   w_lb_7_10  1
    w[7,10]   w_ub_7_10  1
    w[7,10]   normalized_inventory_7  -10
    w[7,10]   old_normalized_TC  -6.3059163059163048e-01
    w[7,10]   old_normalized_TC2  1.9465728715728718e+00
    w[7,11]   mass_7    1
    w[7,11]   w_lb_7_11  1
    w[7,11]   w_ub_7_11  1
    w[7,11]   normalized_inventory_7  -11
    w[7,11]   old_normalized_TC  -1.1861471861471860e+00
    w[7,11]   old_normalized_TC2  1.3910173160173163e+00
    w[7,12]   mass_7    1
    w[7,12]   w_lb_7_12  1
    w[7,12]   w_ub_7_12  1
    w[7,12]   normalized_inventory_7  -12
    w[7,12]   old_normalized_TC  -1.8528138528138525e+00
    w[7,12]   old_normalized_TC2  7.2435064935064952e-01
    w[7,13]   mass_7    1
    w[7,13]   w_lb_7_13  1
    w[7,13]   w_ub_7_13  1
    w[7,13]   normalized_inventory_7  -13
    w[7,13]   old_normalized_TC  -2.6305916305916304e+00
    w[7,13]   old_normalized_TC2  -5.3427128427128240e-02
    w[7,14]   mass_7    1
    w[7,14]   w_lb_7_14  1
    w[7,14]   w_ub_7_14  1
    w[7,14]   normalized_inventory_7  -14
    w[7,14]   old_normalized_TC  -3.5194805194805192e+00
    w[7,14]   old_normalized_TC2  -0.942316017316017
    w[7,15]   mass_7    1
    w[7,15]   w_lb_7_15  1
    w[7,15]   w_ub_7_15  1
    w[7,15]   normalized_inventory_7  -15
    w[7,15]   old_normalized_TC  -4.5194805194805188e+00
    w[7,15]   old_normalized_TC2  -1.9423160173160170e+00
    w[7,16]   mass_7    1
    w[7,16]   w_lb_7_16  1
    w[7,16]   w_ub_7_16  1
    w[7,16]   normalized_inventory_7  -16
    w[7,16]   old_normalized_TC  -5.5829725829725820e+00
    w[7,16]   old_normalized_TC2  -3.0058080808080803e+00
    w[7,17]   mass_7    1
    w[7,17]   w_lb_7_17  1
    w[7,17]   w_ub_7_17  1
    w[7,17]   normalized_inventory_7  -17
    w[7,17]   old_normalized_TC  -6.6940836940836936e+00
    w[7,17]   old_normalized_TC2  -4.1169191919191910e+00
    w[7,18]   mass_7    1
    w[7,18]   w_lb_7_18  1
    w[7,18]   w_ub_7_18  1
    w[7,18]   normalized_inventory_7  -18
    w[7,18]   old_normalized_TC  -7.9163059163059151e+00
    w[7,18]   old_normalized_TC2  -5.3391414141414133e+00
    w[7,19]   mass_7    1
    w[7,19]   w_lb_7_19  1
    w[7,19]   w_ub_7_19  1
    w[7,19]   normalized_inventory_7  -19
    w[7,19]   old_normalized_TC  -9.58297258297258
    w[7,19]   old_normalized_TC2  -7.0058080808080794e+00
    w[8,0]    mass_8    1
    w[8,0]    w_lb_8_0  1
    w[8,0]    w_ub_8_0  1
    w[8,1]    mass_8    1
    w[8,1]    w_lb_8_1  1
    w[8,1]    w_ub_8_1  1
    w[8,1]    normalized_inventory_8  -1
    w[8,1]    old_normalized_TC2  5.0000000000000011e-01
    w[8,2]    mass_8    1
    w[8,2]    w_lb_8_2  1
    w[8,2]    w_ub_8_2  1
    w[8,2]    normalized_inventory_8  -2
    w[8,2]    old_normalized_TC2  1.0000000000000002e+00
    w[8,3]    mass_8    1
    w[8,3]    w_lb_8_3  1
    w[8,3]    w_ub_8_3  1
    w[8,3]    normalized_inventory_8  -3
    w[8,3]    old_normalized_TC2  1.4000000000000001e+00
    w[8,4]    mass_8    1
    w[8,4]    w_lb_8_4  1
    w[8,4]    w_ub_8_4  1
    w[8,4]    normalized_inventory_8  -4
    w[8,4]    old_normalized_TC2  1.7333333333333334e+00
    w[8,5]    mass_8    1
    w[8,5]    w_lb_8_5  1
    w[8,5]    w_ub_8_5  1
    w[8,5]    normalized_inventory_8  -5
    w[8,5]    old_normalized_TC2  1.9878787878787880e+00
    w[8,6]    mass_8    1
    w[8,6]    w_lb_8_6  1
    w[8,6]    w_ub_8_6  1
    w[8,6]    normalized_inventory_8  -6
    w[8,6]    old_normalized_TC2  2.1878787878787880e+00
    w[8,7]    mass_8    1
    w[8,7]    w_lb_8_7  1
    w[8,7]    w_ub_8_7  1
    w[8,7]    normalized_inventory_8  -7
    w[8,7]    old_normalized_TC2  2.3878787878787882e+00
    w[8,8]    mass_8    1
    w[8,8]    w_lb_8_8  1
    w[8,8]    w_ub_8_8  1
    w[8,8]    normalized_inventory_8  -8
    w[8,8]    old_normalized_TC2  2.5021645021645025e+00
    w[8,9]    mass_8    1
    w[8,9]    w_lb_8_9  1
    w[8,9]    w_ub_8_9  1
    w[8,9]    normalized_inventory_8  -9
    w[8,9]    old_normalized_TC  -6.6666666666666763e-02
    w[8,9]    old_normalized_TC2  2.5104978354978358e+00
    w[8,10]   mass_8    1
    w[8,10]   w_lb_8_10  1
    w[8,10]   w_ub_8_10  1
    w[8,10]   normalized_inventory_8  -10
    w[8,10]   old_normalized_TC  -2.5757575757575779e-01
    w[8,10]   old_normalized_TC2  2.3195887445887444e+00
    w[8,11]   mass_8    1
    w[8,11]   w_lb_8_11  1
    w[8,11]   w_ub_8_11  1
    w[8,11]   normalized_inventory_8  -11
    w[8,11]   old_normalized_TC  -5.8614718614718653e-01
    w[8,11]   old_normalized_TC2  1.9910173160173157e+00
    w[8,12]   mass_8    1
    w[8,12]   w_lb_8_12  1
    w[8,12]   w_ub_8_12  1
    w[8,12]   normalized_inventory_8  -12
    w[8,12]   old_normalized_TC  -1.0750360750360755e+00
    w[8,12]   old_normalized_TC2  1.5021284271284268e+00
    w[8,13]   mass_8    1
    w[8,13]   w_lb_8_13  1
    w[8,13]   w_ub_8_13  1
    w[8,13]   normalized_inventory_8  -13
    w[8,13]   old_normalized_TC  -1.6528138528138534e+00
    w[8,13]   old_normalized_TC2  9.2435064935064870e-01
    w[8,14]   mass_8    1
    w[8,14]   w_lb_8_14  1
    w[8,14]   w_ub_8_14  1
    w[8,14]   normalized_inventory_8  -14
    w[8,14]   old_normalized_TC  -2.3194805194805204e+00
    w[8,14]   old_normalized_TC2  2.5768398268398179e-01
    w[8,15]   mass_8    1
    w[8,15]   w_lb_8_15  1
    w[8,15]   w_ub_8_15  1
    w[8,15]   normalized_inventory_8  -15
    w[8,15]   old_normalized_TC  -3.0750360750360759e+00
    w[8,15]   old_normalized_TC2  -4.9787157287157396e-01
    w[8,16]   mass_8    1
    w[8,16]   w_lb_8_16  1
    w[8,16]   w_ub_8_16  1
    w[8,16]   normalized_inventory_8  -16
    w[8,16]   old_normalized_TC  -3.9194805194805205e+00
    w[8,16]   old_normalized_TC2  -1.3423160173160185e+00
    w[8,17]   mass_8    1
    w[8,17]   w_lb_8_17  1
    w[8,17]   w_ub_8_17  1
    w[8,17]   normalized_inventory_8  -17
    w[8,17]   old_normalized_TC  -4.81948051948052
    w[8,17]   old_normalized_TC2  -2.2423160173160186e+00
    w[8,18]   mass_8    1
    w[8,18]   w_lb_8_18  1
    w[8,18]   w_ub_8_18  1
    w[8,18]   normalized_inventory_8  -18
    w[8,18]   old_normalized_TC  -5.8051948051948061e+00
    w[8,18]   old_normalized_TC2  -3.2280303030303044e+00
    w[8,19]   mass_8    1
    w[8,19]   w_lb_8_19  1
    w[8,19]   w_ub_8_19  1
    w[8,19]   normalized_inventory_8  -19
    w[8,19]   old_normalized_TC  -6.8163059163059181e+00
    w[8,19]   old_normalized_TC2  -4.2391414141414154e+00
    w[8,20]   mass_8    1
    w[8,20]   w_lb_8_20  1
    w[8,20]   w_ub_8_20  1
    w[8,20]   normalized_inventory_8  -20
    w[8,20]   old_normalized_TC  -7.9163059163059177e+00
    w[8,20]   old_normalized_TC2  -5.3391414141414160e+00
    w[9,0]    mass_9    1
    w[9,0]    w_lb_9_0  1
    w[9,0]    w_ub_9_0  1
    w[9,1]    mass_9    1
    w[9,1]    w_lb_9_1  1
    w[9,1]    w_ub_9_1  1
    w[9,1]    normalized_inventory_9  -1
    w[9,1]    old_normalized_TC2  3.5714285714285715e-01
    w[9,2]    mass_9    1
    w[9,2]    w_lb_9_2  1
    w[9,2]    w_ub_9_2  1
    w[9,2]    normalized_inventory_9  -2
    w[9,2]    old_normalized_TC2  7.1428571428571430e-01
    w[9,3]    mass_9    1
    w[9,3]    w_lb_9_3  1
    w[9,3]    w_ub_9_3  1
    w[9,3]    normalized_inventory_9  -3
    w[9,3]    old_normalized_TC2  1.0571428571428572e+00
    w[9,4]    mass_9    1
    w[9,4]    w_lb_9_4  1
    w[9,4]    w_ub_9_4  1
    w[9,4]    normalized_inventory_9  -4
    w[9,4]    old_normalized_TC2  1.3428571428571430e+00
    w[9,5]    mass_9    1
    w[9,5]    w_lb_9_5  1
    w[9,5]    w_ub_9_5  1
    w[9,5]    normalized_inventory_9  -5
    w[9,5]    old_normalized_TC2  1.6047619047619048e+00
    w[9,6]    mass_9    1
    w[9,6]    w_lb_9_6  1
    w[9,6]    w_ub_9_6  1
    w[9,6]    normalized_inventory_9  -6
    w[9,6]    old_normalized_TC2  1.8190476190476190e+00
    w[9,7]    mass_9    1
    w[9,7]    w_lb_9_7  1
    w[9,7]    w_ub_9_7  1
    w[9,7]    normalized_inventory_9  -7
    w[9,7]    old_normalized_TC2  1.9878787878787880e+00
    w[9,8]    mass_9    1
    w[9,8]    w_lb_9_8  1
    w[9,8]    w_ub_9_8  1
    w[9,8]    normalized_inventory_9  -8
    w[9,8]    old_normalized_TC2  2.1307359307359310e+00
    w[9,9]    mass_9    1
    w[9,9]    w_lb_9_9  1
    w[9,9]    w_ub_9_9  1
    w[9,9]    normalized_inventory_9  -9
    w[9,9]    old_normalized_TC2  2.2735930735930738e+00
    w[9,10]   mass_9    1
    w[9,10]   w_lb_9_10  1
    w[9,10]   w_ub_9_10  1
    w[9,10]   normalized_inventory_9  -10
    w[9,10]   old_normalized_TC2  2.4164502164502166e+00
    w[9,11]   mass_9    1
    w[9,11]   w_lb_9_11  1
    w[9,11]   w_ub_9_11  1
    w[9,11]   normalized_inventory_9  -11
    w[9,11]   old_normalized_TC2  2.4878787878787878e+00
    w[9,12]   mass_9    1
    w[9,12]   w_lb_9_12  1
    w[9,12]   w_ub_9_12  1
    w[9,12]   normalized_inventory_9  -12
    w[9,12]   old_normalized_TC  -2.3809523809523808e-02
    w[9,12]   old_normalized_TC2  2.5354978354978357e+00
    w[9,13]   mass_9    1
    w[9,13]   w_lb_9_13  1
    w[9,13]   w_ub_9_13  1
    w[9,13]   normalized_inventory_9  -13
    w[9,13]   old_normalized_TC  -1.1471861471861464e-01
    w[9,13]   old_normalized_TC2  2.4624458874458877e+00
    w[9,14]   mass_9    1
    w[9,14]   w_lb_9_14  1
    w[9,14]   w_ub_9_14  1
    w[9,14]   normalized_inventory_9  -14
    w[9,14]   old_normalized_TC  -2.5757575757575746e-01
    w[9,14]   old_normalized_TC2  2.3195887445887449e+00
    w[9,15]   mass_9    1
    w[9,15]   w_lb_9_15  1
    w[9,15]   w_ub_9_15  1
    w[9,15]   normalized_inventory_9  -15
    w[9,15]   old_normalized_TC  -4.7186147186147176e-01
    w[9,15]   old_normalized_TC2  2.1053030303030305e+00
    w[9,16]   mass_9    1
    w[9,16]   w_lb_9_16  1
    w[9,16]   w_ub_9_16  1
    w[9,16]   normalized_inventory_9  -16
    w[9,16]   old_normalized_TC  -7.8932178932178920e-01
    w[9,16]   old_normalized_TC2  1.7878427128427130e+00
    w[9,17]   mass_9    1
    w[9,17]   w_lb_9_17  1
    w[9,17]   w_ub_9_17  1
    w[9,17]   normalized_inventory_9  -17
    w[9,17]   old_normalized_TC  -1.1464646464646462e+00
    w[9,17]   old_normalized_TC2  1.4306998556998558e+00
    w[9,18]   mass_9    1
    w[9,18]   w_lb_9_18  1
    w[9,18]   w_ub_9_18  1
    w[9,18]   normalized_inventory_9  -18
    w[9,18]   old_normalized_TC  -1.5670995670995669e+00
    w[9,18]   old_normalized_TC2  1.0100649350649353e+00
    w[9,19]   mass_9    1
    w[9,19]   w_lb_9_19  1
    w[9,19]   w_ub_9_19  1
    w[9,19]   normalized_inventory_9  -19
    w[9,19]   old_normalized_TC  -2.0194805194805192e+00
    w[9,19]   old_normalized_TC2  5.5768398268398289e-01
    w[9,20]   mass_9    1
    w[9,20]   w_lb_9_20  1
    w[9,20]   w_ub_9_20  1
    w[9,20]   normalized_inventory_9  -20
    w[9,20]   old_normalized_TC  -2.5194805194805192e+00
    w[9,20]   old_normalized_TC2  5.7683982683982865e-02
    w[9,21]   mass_9    1
    w[9,21]   w_lb_9_21  1
    w[9,21]   w_ub_9_21  1
    w[9,21]   normalized_inventory_9  -21
    w[9,21]   old_normalized_TC  -3.0750360750360746e+00
    w[9,21]   old_normalized_TC2  -4.9787157287157263e-01
    w[9,22]   mass_9    1
    w[9,22]   w_lb_9_22  1
    w[9,22]   w_ub_9_22  1
    w[9,22]   normalized_inventory_9  -22
    w[9,22]   old_normalized_TC  -3.6623376623376620e+00
    w[9,22]   old_normalized_TC2  -1.0851731601731598e+00
    w[9,23]   mass_9    1
    w[9,23]   w_lb_9_23  1
    w[9,23]   w_ub_9_23  1
    w[9,23]   normalized_inventory_9  -23
    w[9,23]   old_normalized_TC  -4.3051948051948044e+00
    w[9,23]   old_normalized_TC2  -1.7280303030303026e+00
    w[9,24]   mass_9    1
    w[9,24]   w_lb_9_24  1
    w[9,24]   w_ub_9_24  1
    w[9,24]   normalized_inventory_9  -24
    w[9,24]   old_normalized_TC  -4.9480519480519476e+00
    w[9,24]   old_normalized_TC2  -2.3708874458874454e+00
    w[9,25]   mass_9    1
    w[9,25]   w_lb_9_25  1
    w[9,25]   w_ub_9_25  1
    w[9,25]   normalized_inventory_9  -25
    w[9,25]   old_normalized_TC  -5.6623376623376611e+00
    w[9,25]   old_normalized_TC2  -3.08517316017316
    w[9,26]   mass_9    1
    w[9,26]   w_lb_9_26  1
    w[9,26]   w_ub_9_26  1
    w[9,26]   normalized_inventory_9  -26
    w[9,26]   old_normalized_TC  -6.3766233766233755e+00
    w[9,26]   old_normalized_TC2  -3.7994588744588738e+00
    w[9,27]   mass_9    1
    w[9,27]   w_lb_9_27  1
    w[9,27]   w_ub_9_27  1
    w[9,27]   normalized_inventory_9  -27
    w[9,27]   old_normalized_TC  -7.1305916305916295e+00
    w[9,27]   old_normalized_TC2  -4.5534271284271277e+00
    w[9,28]   mass_9    1
    w[9,28]   w_lb_9_28  1
    w[9,28]   w_ub_9_28  1
    w[9,28]   normalized_inventory_9  -28
    w[9,28]   old_normalized_TC  -7.9163059163059151e+00
    w[9,28]   old_normalized_TC2  -5.3391414141414133e+00
    w[9,29]   mass_9    1
    w[9,29]   w_lb_9_29  1
    w[9,29]   w_ub_9_29  1
    w[9,29]   normalized_inventory_9  -29
    w[9,29]   old_normalized_TC  -8.9877344877344854e+00
    w[9,29]   old_normalized_TC2  -6.4105699855699836e+00
    w[9,30]   mass_9    1
    w[9,30]   w_lb_9_30  1
    w[9,30]   w_ub_9_30  1
    w[9,30]   normalized_inventory_9  -30
    w[9,30]   old_normalized_TC  -1.0122655122655120e+01
    w[9,30]   old_normalized_TC2  -7.5454906204906189e+00
    w[9,31]   mass_9    1
    w[9,31]   w_lb_9_31  1
    w[9,31]   w_ub_9_31  1
    w[9,31]   normalized_inventory_9  -31
    w[9,31]   old_normalized_TC  -1.1408369408369406e+01
    w[9,31]   old_normalized_TC2  -8.8312049062049045e+00
    w[10,0]   mass_10   1
    w[10,0]   w_lb_10_0  1
    w[10,0]   w_ub_10_0  1
    w[10,1]   mass_10   1
    w[10,1]   w_lb_10_1  1
    w[10,1]   w_ub_10_1  1
    w[10,1]   normalized_inventory_10  -1
    w[10,1]   old_normalized_TC2  5.5555555555555558e-01
    w[10,2]   mass_10   1
    w[10,2]   w_lb_10_2  1
    w[10,2]   w_ub_10_2  1
    w[10,2]   normalized_inventory_10  -2
    w[10,2]   old_normalized_TC2  1.0888888888888890e+00
    w[10,3]   mass_10   1
    w[10,3]   w_lb_10_3  1
    w[10,3]   w_ub_10_3  1
    w[10,3]   normalized_inventory_10  -3
    w[10,3]   old_normalized_TC2  1.5333333333333334e+00
    w[10,4]   mass_10   1
    w[10,4]   w_lb_10_4  1
    w[10,4]   w_ub_10_4  1
    w[10,4]   normalized_inventory_10  -4
    w[10,4]   old_normalized_TC2  1.8666666666666667e+00
    w[10,5]   mass_10   1
    w[10,5]   w_lb_10_5  1
    w[10,5]   w_ub_10_5  1
    w[10,5]   normalized_inventory_10  -5
    w[10,5]   old_normalized_TC2  2.0989898989898990e+00
    w[10,6]   mass_10   1
    w[10,6]   w_lb_10_6  1
    w[10,6]   w_ub_10_6  1
    w[10,6]   normalized_inventory_10  -6
    w[10,6]   old_normalized_TC2  2.3212121212121213e+00
    w[10,7]   mass_10   1
    w[10,7]   w_lb_10_7  1
    w[10,7]   w_ub_10_7  1
    w[10,7]   normalized_inventory_10  -7
    w[10,7]   old_normalized_TC2  2.47994227994228
    w[10,8]   mass_10   1
    w[10,8]   w_lb_10_8  1
    w[10,8]   w_ub_10_8  1
    w[10,8]   normalized_inventory_10  -8
    w[10,8]   old_normalized_TC  -5.5555555555555552e-02
    w[10,8]   old_normalized_TC2  2.5216089466089469e+00
    w[10,9]   mass_10   1
    w[10,9]   w_lb_10_9  1
    w[10,9]   w_ub_10_9  1
    w[10,9]   normalized_inventory_10  -9
    w[10,9]   old_normalized_TC  -2.5757575757575746e-01
    w[10,9]   old_normalized_TC2  2.3195887445887449e+00
    w[10,10]  mass_10   1
    w[10,10]  w_lb_10_10  1
    w[10,10]  w_ub_10_10  1
    w[10,10]  normalized_inventory_10  -10
    w[10,10]  old_normalized_TC  -6.3059163059163048e-01
    w[10,10]  old_normalized_TC2  1.9465728715728718e+00
    w[10,11]  mass_10   1
    w[10,11]  w_lb_10_11  1
    w[10,11]  w_ub_10_11  1
    w[10,11]  normalized_inventory_10  -11
    w[10,11]  old_normalized_TC  -1.1861471861471860e+00
    w[10,11]  old_normalized_TC2  1.3910173160173163e+00
    w[10,12]  mass_10   1
    w[10,12]  w_lb_10_12  1
    w[10,12]  w_ub_10_12  1
    w[10,12]  normalized_inventory_10  -12
    w[10,12]  old_normalized_TC  -1.8528138528138525e+00
    w[10,12]  old_normalized_TC2  7.2435064935064952e-01
    w[10,13]  mass_10   1
    w[10,13]  w_lb_10_13  1
    w[10,13]  w_ub_10_13  1
    w[10,13]  normalized_inventory_10  -13
    w[10,13]  old_normalized_TC  -2.6305916305916304e+00
    w[10,13]  old_normalized_TC2  -5.3427128427128240e-02
    w[10,14]  mass_10   1
    w[10,14]  w_lb_10_14  1
    w[10,14]  w_ub_10_14  1
    w[10,14]  normalized_inventory_10  -14
    w[10,14]  old_normalized_TC  -3.5194805194805192e+00
    w[10,14]  old_normalized_TC2  -0.942316017316017
    w[10,15]  mass_10   1
    w[10,15]  w_lb_10_15  1
    w[10,15]  w_ub_10_15  1
    w[10,15]  normalized_inventory_10  -15
    w[10,15]  old_normalized_TC  -4.5194805194805188e+00
    w[10,15]  old_normalized_TC2  -1.9423160173160170e+00
    w[10,16]  mass_10   1
    w[10,16]  w_lb_10_16  1
    w[10,16]  w_ub_10_16  1
    w[10,16]  normalized_inventory_10  -16
    w[10,16]  old_normalized_TC  -5.5829725829725820e+00
    w[10,16]  old_normalized_TC2  -3.0058080808080803e+00
    w[10,17]  mass_10   1
    w[10,17]  w_lb_10_17  1
    w[10,17]  w_ub_10_17  1
    w[10,17]  normalized_inventory_10  -17
    w[10,17]  old_normalized_TC  -6.6940836940836936e+00
    w[10,17]  old_normalized_TC2  -4.1169191919191910e+00
    w[10,18]  mass_10   1
    w[10,18]  w_lb_10_18  1
    w[10,18]  w_ub_10_18  1
    w[10,18]  normalized_inventory_10  -18
    w[10,18]  old_normalized_TC  -7.9163059163059151e+00
    w[10,18]  old_normalized_TC2  -5.3391414141414133e+00
    w[10,19]  mass_10   1
    w[10,19]  w_lb_10_19  1
    w[10,19]  w_ub_10_19  1
    w[10,19]  normalized_inventory_10  -19
    w[10,19]  old_normalized_TC  -9.58297258297258
    w[10,19]  old_normalized_TC2  -7.0058080808080794e+00
    w[11,0]   mass_11   1
    w[11,0]   w_lb_11_0  1
    w[11,0]   w_ub_11_0  1
    w[11,1]   mass_11   1
    w[11,1]   w_lb_11_1  1
    w[11,1]   w_ub_11_1  1
    w[11,1]   normalized_inventory_11  -1
    w[11,1]   old_normalized_TC2  5.0000000000000011e-01
    w[11,2]   mass_11   1
    w[11,2]   w_lb_11_2  1
    w[11,2]   w_ub_11_2  1
    w[11,2]   normalized_inventory_11  -2
    w[11,2]   old_normalized_TC2  1.0000000000000002e+00
    w[11,3]   mass_11   1
    w[11,3]   w_lb_11_3  1
    w[11,3]   w_ub_11_3  1
    w[11,3]   normalized_inventory_11  -3
    w[11,3]   old_normalized_TC2  1.4000000000000001e+00
    w[11,4]   mass_11   1
    w[11,4]   w_lb_11_4  1
    w[11,4]   w_ub_11_4  1
    w[11,4]   normalized_inventory_11  -4
    w[11,4]   old_normalized_TC2  1.7333333333333334e+00
    w[11,5]   mass_11   1
    w[11,5]   w_lb_11_5  1
    w[11,5]   w_ub_11_5  1
    w[11,5]   normalized_inventory_11  -5
    w[11,5]   old_normalized_TC2  1.9878787878787880e+00
    w[11,6]   mass_11   1
    w[11,6]   w_lb_11_6  1
    w[11,6]   w_ub_11_6  1
    w[11,6]   normalized_inventory_11  -6
    w[11,6]   old_normalized_TC2  2.1878787878787880e+00
    w[11,7]   mass_11   1
    w[11,7]   w_lb_11_7  1
    w[11,7]   w_ub_11_7  1
    w[11,7]   normalized_inventory_11  -7
    w[11,7]   old_normalized_TC2  2.3878787878787882e+00
    w[11,8]   mass_11   1
    w[11,8]   w_lb_11_8  1
    w[11,8]   w_ub_11_8  1
    w[11,8]   normalized_inventory_11  -8
    w[11,8]   old_normalized_TC2  2.5021645021645025e+00
    w[11,9]   mass_11   1
    w[11,9]   w_lb_11_9  1
    w[11,9]   w_ub_11_9  1
    w[11,9]   normalized_inventory_11  -9
    w[11,9]   old_normalized_TC  -6.6666666666666763e-02
    w[11,9]   old_normalized_TC2  2.5104978354978358e+00
    w[11,10]  mass_11   1
    w[11,10]  w_lb_11_10  1
    w[11,10]  w_ub_11_10  1
    w[11,10]  normalized_inventory_11  -10
    w[11,10]  old_normalized_TC  -2.5757575757575779e-01
    w[11,10]  old_normalized_TC2  2.3195887445887444e+00
    w[11,11]  mass_11   1
    w[11,11]  w_lb_11_11  1
    w[11,11]  w_ub_11_11  1
    w[11,11]  normalized_inventory_11  -11
    w[11,11]  old_normalized_TC  -5.8614718614718653e-01
    w[11,11]  old_normalized_TC2  1.9910173160173157e+00
    w[11,12]  mass_11   1
    w[11,12]  w_lb_11_12  1
    w[11,12]  w_ub_11_12  1
    w[11,12]  normalized_inventory_11  -12
    w[11,12]  old_normalized_TC  -1.0750360750360755e+00
    w[11,12]  old_normalized_TC2  1.5021284271284268e+00
    w[11,13]  mass_11   1
    w[11,13]  w_lb_11_13  1
    w[11,13]  w_ub_11_13  1
    w[11,13]  normalized_inventory_11  -13
    w[11,13]  old_normalized_TC  -1.6528138528138534e+00
    w[11,13]  old_normalized_TC2  9.2435064935064870e-01
    w[11,14]  mass_11   1
    w[11,14]  w_lb_11_14  1
    w[11,14]  w_ub_11_14  1
    w[11,14]  normalized_inventory_11  -14
    w[11,14]  old_normalized_TC  -2.3194805194805204e+00
    w[11,14]  old_normalized_TC2  2.5768398268398179e-01
    w[11,15]  mass_11   1
    w[11,15]  w_lb_11_15  1
    w[11,15]  w_ub_11_15  1
    w[11,15]  normalized_inventory_11  -15
    w[11,15]  old_normalized_TC  -3.0750360750360759e+00
    w[11,15]  old_normalized_TC2  -4.9787157287157396e-01
    w[11,16]  mass_11   1
    w[11,16]  w_lb_11_16  1
    w[11,16]  w_ub_11_16  1
    w[11,16]  normalized_inventory_11  -16
    w[11,16]  old_normalized_TC  -3.9194805194805205e+00
    w[11,16]  old_normalized_TC2  -1.3423160173160185e+00
    w[11,17]  mass_11   1
    w[11,17]  w_lb_11_17  1
    w[11,17]  w_ub_11_17  1
    w[11,17]  normalized_inventory_11  -17
    w[11,17]  old_normalized_TC  -4.81948051948052
    w[11,17]  old_normalized_TC2  -2.2423160173160186e+00
    w[11,18]  mass_11   1
    w[11,18]  w_lb_11_18  1
    w[11,18]  w_ub_11_18  1
    w[11,18]  normalized_inventory_11  -18
    w[11,18]  old_normalized_TC  -5.8051948051948061e+00
    w[11,18]  old_normalized_TC2  -3.2280303030303044e+00
    w[11,19]  mass_11   1
    w[11,19]  w_lb_11_19  1
    w[11,19]  w_ub_11_19  1
    w[11,19]  normalized_inventory_11  -19
    w[11,19]  old_normalized_TC  -6.8163059163059181e+00
    w[11,19]  old_normalized_TC2  -4.2391414141414154e+00
    w[11,20]  mass_11   1
    w[11,20]  w_lb_11_20  1
    w[11,20]  w_ub_11_20  1
    w[11,20]  normalized_inventory_11  -20
    w[11,20]  old_normalized_TC  -7.9163059163059177e+00
    w[11,20]  old_normalized_TC2  -5.3391414141414160e+00
    w[12,0]   mass_12   1
    w[12,0]   w_lb_12_0  1
    w[12,0]   w_ub_12_0  1
    w[12,1]   mass_12   1
    w[12,1]   w_lb_12_1  1
    w[12,1]   w_ub_12_1  1
    w[12,1]   normalized_inventory_12  -1
    w[12,1]   old_normalized_TC2  4.1666666666666669e-01
    w[12,2]   mass_12   1
    w[12,2]   w_lb_12_2  1
    w[12,2]   w_ub_12_2  1
    w[12,2]   normalized_inventory_12  -2
    w[12,2]   old_normalized_TC2  8.3333333333333337e-01
    w[12,3]   mass_12   1
    w[12,3]   w_lb_12_3  1
    w[12,3]   w_ub_12_3  1
    w[12,3]   normalized_inventory_12  -3
    w[12,3]   old_normalized_TC2  1.2
    w[12,4]   mass_12   1
    w[12,4]   w_lb_12_4  1
    w[12,4]   w_ub_12_4  1
    w[12,4]   normalized_inventory_12  -4
    w[12,4]   old_normalized_TC2  1.5333333333333334e+00
    w[12,5]   mass_12   1
    w[12,5]   w_lb_12_5  1
    w[12,5]   w_ub_12_5  1
    w[12,5]   normalized_inventory_12  -5
    w[12,5]   old_normalized_TC2  1.7833333333333334e+00
    w[12,6]   mass_12   1
    w[12,6]   w_lb_12_6  1
    w[12,6]   w_ub_12_6  1
    w[12,6]   normalized_inventory_12  -6
    w[12,6]   old_normalized_TC2  1.9878787878787880e+00
    w[12,7]   mass_12   1
    w[12,7]   w_lb_12_7  1
    w[12,7]   w_ub_12_7  1
    w[12,7]   normalized_inventory_12  -7
    w[12,7]   old_normalized_TC2  2.1545454545454548e+00
    w[12,8]   mass_12   1
    w[12,8]   w_lb_12_8  1
    w[12,8]   w_ub_12_8  1
    w[12,8]   normalized_inventory_12  -8
    w[12,8]   old_normalized_TC2  2.3212121212121213e+00
    w[12,9]   mass_12   1
    w[12,9]   w_lb_12_9  1
    w[12,9]   w_ub_12_9  1
    w[12,9]   normalized_inventory_12  -9
    w[12,9]   old_normalized_TC2  2.4521645021645022e+00
    w[12,10]  mass_12   1
    w[12,10]  w_lb_12_10  1
    w[12,10]  w_ub_12_10  1
    w[12,10]  normalized_inventory_12  -10
    w[12,10]  old_normalized_TC2  2.5354978354978357e+00
    w[12,11]  mass_12   1
    w[12,11]  w_lb_12_11  1
    w[12,11]  w_ub_12_11  1
    w[12,11]  normalized_inventory_12  -11
    w[12,11]  old_normalized_TC  -9.0909090909090828e-02
    w[12,11]  old_normalized_TC2  2.4862554112554114e+00
    w[12,12]  mass_12   1
    w[12,12]  w_lb_12_12  1
    w[12,12]  w_ub_12_12  1
    w[12,12]  normalized_inventory_12  -12
    w[12,12]  old_normalized_TC  -2.5757575757575746e-01
    w[12,12]  old_normalized_TC2  2.3195887445887449e+00
    w[12,13]  mass_12   1
    w[12,13]  w_lb_12_13  1
    w[12,13]  w_ub_12_13  1
    w[12,13]  normalized_inventory_12  -13
    w[12,13]  old_normalized_TC  -5.1948051948051932e-01
    w[12,13]  old_normalized_TC2  2.0576839826839830e+00
    w[12,14]  mass_12   1
    w[12,14]  w_lb_12_14  1
    w[12,14]  w_ub_12_14  1
    w[12,14]  normalized_inventory_12  -14
    w[12,14]  old_normalized_TC  -9.0836940836940816e-01
    w[12,14]  old_normalized_TC2  1.6687950937950939e+00
    w[12,15]  mass_12   1
    w[12,15]  w_lb_12_15  1
    w[12,15]  w_ub_12_15  1
    w[12,15]  normalized_inventory_12  -15
    w[12,15]  old_normalized_TC  -1.3528138528138525e+00
    w[12,15]  old_normalized_TC2  1.2243506493506495e+00
    w[12,16]  mass_12   1
    w[12,16]  w_lb_12_16  1
    w[12,16]  w_ub_12_16  1
    w[12,16]  normalized_inventory_12  -16
    w[12,16]  old_normalized_TC  -1.8528138528138525e+00
    w[12,16]  old_normalized_TC2  7.2435064935064952e-01
    w[12,17]  mass_12   1
    w[12,17]  w_lb_12_17  1
    w[12,17]  w_ub_12_17  1
    w[12,17]  normalized_inventory_12  -17
    w[12,17]  old_normalized_TC  -2.4361471861471857e+00
    w[12,17]  old_normalized_TC2  1.4101731601731621e-01
    w[12,18]  mass_12   1
    w[12,18]  w_lb_12_18  1
    w[12,18]  w_ub_12_18  1
    w[12,18]  normalized_inventory_12  -18
    w[12,18]  old_normalized_TC  -3.0750360750360746e+00
    w[12,18]  old_normalized_TC2  -4.9787157287157263e-01
    w[12,19]  mass_12   1
    w[12,19]  w_lb_12_19  1
    w[12,19]  w_ub_12_19  1
    w[12,19]  normalized_inventory_12  -19
    w[12,19]  old_normalized_TC  -3.7694805194805188e+00
    w[12,19]  old_normalized_TC2  -1.1923160173160170e+00
    w[12,20]  mass_12   1
    w[12,20]  w_lb_12_20  1
    w[12,20]  w_ub_12_20  1
    w[12,20]  normalized_inventory_12  -20
    w[12,20]  old_normalized_TC  -4.5194805194805188e+00
    w[12,20]  old_normalized_TC2  -1.9423160173160170e+00
    w[12,21]  mass_12   1
    w[12,21]  w_lb_12_21  1
    w[12,21]  w_ub_12_21  1
    w[12,21]  normalized_inventory_12  -21
    w[12,21]  old_normalized_TC  -5.3051948051948044e+00
    w[12,21]  old_normalized_TC2  -2.7280303030303026e+00
    w[12,22]  mass_12   1
    w[12,22]  w_lb_12_22  1
    w[12,22]  w_ub_12_22  1
    w[12,22]  normalized_inventory_12  -22
    w[12,22]  old_normalized_TC  -6.1385281385281374e+00
    w[12,22]  old_normalized_TC2  -3.5613636363636356e+00
    w[12,23]  mass_12   1
    w[12,23]  w_lb_12_23  1
    w[12,23]  w_ub_12_23  1
    w[12,23]  normalized_inventory_12  -23
    w[12,23]  old_normalized_TC  -6.9996392496392490e+00
    w[12,23]  old_normalized_TC2  -4.4224747474747463e+00
    w[12,24]  mass_12   1
    w[12,24]  w_lb_12_24  1
    w[12,24]  w_ub_12_24  1
    w[12,24]  normalized_inventory_12  -24
    w[12,24]  old_normalized_TC  -7.9163059163059151e+00
    w[12,24]  old_normalized_TC2  -5.3391414141414133e+00
    w[13,0]   mass_13   1
    w[13,0]   w_lb_13_0  1
    w[13,0]   w_ub_13_0  1
    w[13,1]   mass_13   1
    w[13,1]   w_lb_13_1  1
    w[13,1]   w_ub_13_1  1
    w[13,1]   normalized_inventory_13  -1
    w[13,1]   old_normalized_TC2  0.3125
    w[13,2]   mass_13   1
    w[13,2]   w_lb_13_2  1
    w[13,2]   w_ub_13_2  1
    w[13,2]   normalized_inventory_13  -2
    w[13,2]   old_normalized_TC2  0.625
    w[13,3]   mass_13   1
    w[13,3]   w_lb_13_3  1
    w[13,3]   w_ub_13_3  1
    w[13,3]   normalized_inventory_13  -3
    w[13,3]   old_normalized_TC2  0.9375
    w[13,4]   mass_13   1
    w[13,4]   w_lb_13_4  1
    w[13,4]   w_ub_13_4  1
    w[13,4]   normalized_inventory_13  -4
    w[13,4]   old_normalized_TC2  1.2000000000000002e+00
    w[13,5]   mass_13   1
    w[13,5]   w_lb_13_5  1
    w[13,5]   w_ub_13_5  1
    w[13,5]   normalized_inventory_13  -5
    w[13,5]   old_normalized_TC2  1.4500000000000002e+00
    w[13,6]   mass_13   1
    w[13,6]   w_lb_13_6  1
    w[13,6]   w_ub_13_6  1
    w[13,6]   normalized_inventory_13  -6
    w[13,6]   old_normalized_TC2  1.6583333333333334e+00
    w[13,7]   mass_13   1
    w[13,7]   w_lb_13_7  1
    w[13,7]   w_ub_13_7  1
    w[13,7]   normalized_inventory_13  -7
    w[13,7]   old_normalized_TC2  1.8458333333333334e+00
    w[13,8]   mass_13   1
    w[13,8]   w_lb_13_8  1
    w[13,8]   w_ub_13_8  1
    w[13,8]   normalized_inventory_13  -8
    w[13,8]   old_normalized_TC2  1.9878787878787880e+00
    w[13,9]   mass_13   1
    w[13,9]   w_lb_13_9  1
    w[13,9]   w_ub_13_9  1
    w[13,9]   normalized_inventory_13  -9
    w[13,9]   old_normalized_TC2  2.1128787878787882e+00
    w[13,10]  mass_13   1
    w[13,10]  w_lb_13_10  1
    w[13,10]  w_ub_13_10  1
    w[13,10]  normalized_inventory_13  -10
    w[13,10]  old_normalized_TC2  2.2378787878787882e+00
    w[13,11]  mass_13   1
    w[13,11]  w_lb_13_11  1
    w[13,11]  w_ub_13_11  1
    w[13,11]  normalized_inventory_13  -11
    w[13,11]  old_normalized_TC2  2.3628787878787882e+00
    w[13,12]  mass_13   1
    w[13,12]  w_lb_13_12  1
    w[13,12]  w_ub_13_12  1
    w[13,12]  normalized_inventory_13  -12
    w[13,12]  old_normalized_TC2  2.4521645021645022e+00
    w[13,13]  mass_13   1
    w[13,13]  w_lb_13_13  1
    w[13,13]  w_ub_13_13  1
    w[13,13]  normalized_inventory_13  -13
    w[13,13]  old_normalized_TC2  2.5146645021645022e+00
    w[13,14]  mass_13   1
    w[13,14]  w_lb_13_14  1
    w[13,14]  w_ub_13_14  1
    w[13,14]  normalized_inventory_13  -14
    w[13,14]  old_normalized_TC  -4.1666666666666713e-02
    w[13,14]  old_normalized_TC2  2.5354978354978357e+00
    w[13,15]  mass_13   1
    w[13,15]  w_lb_13_15  1
    w[13,15]  w_ub_13_15  1
    w[13,15]  normalized_inventory_13  -15
    w[13,15]  old_normalized_TC  -1.3257575757575760e-01
    w[13,15]  old_normalized_TC2  2.4445887445887449e+00
    w[13,16]  mass_13   1
    w[13,16]  w_lb_13_16  1
    w[13,16]  w_ub_13_16  1
    w[13,16]  normalized_inventory_13  -16
    w[13,16]  old_normalized_TC  -2.5757575757575762e-01
    w[13,16]  old_normalized_TC2  2.3195887445887449e+00
    w[13,17]  mass_13   1
    w[13,17]  w_lb_13_17  1
    w[13,17]  w_ub_13_17  1
    w[13,17]  normalized_inventory_13  -17
    w[13,17]  old_normalized_TC  -4.4507575757575762e-01
    w[13,17]  old_normalized_TC2  2.1320887445887449e+00
    w[13,18]  mass_13   1
    w[13,18]  w_lb_13_18  1
    w[13,18]  w_ub_13_18  1
    w[13,18]  normalized_inventory_13  -18
    w[13,18]  old_normalized_TC  -7.0003607503607523e-01
    w[13,18]  old_normalized_TC2  1.8771284271284270e+00
    w[13,19]  mass_13   1
    w[13,19]  w_lb_13_19  1
    w[13,19]  w_ub_13_19  1
    w[13,19]  normalized_inventory_13  -19
    w[13,19]  old_normalized_TC  -1.0125360750360752e+00
    w[13,19]  old_normalized_TC2  1.5646284271284270e+00
    w[13,20]  mass_13   1
    w[13,20]  w_lb_13_20  1
    w[13,20]  w_ub_13_20  1
    w[13,20]  normalized_inventory_13  -20
    w[13,20]  old_normalized_TC  -1.3528138528138529e+00
    w[13,20]  old_normalized_TC2  1.2243506493506491e+00
    w[13,21]  mass_13   1
    w[13,21]  w_lb_13_21  1
    w[13,21]  w_ub_13_21  1
    w[13,21]  normalized_inventory_13  -21
    w[13,21]  old_normalized_TC  -1.7278138528138529e+00
    w[13,21]  old_normalized_TC2  8.4935064935064908e-01
    w[13,22]  mass_13   1
    w[13,22]  w_lb_13_22  1
    w[13,22]  w_ub_13_22  1
    w[13,22]  normalized_inventory_13  -22
    w[13,22]  old_normalized_TC  -2.1444805194805197e+00
    w[13,22]  old_normalized_TC2  4.3268398268398234e-01
    w[13,23]  mass_13   1
    w[13,23]  w_lb_13_23  1
    w[13,23]  w_ub_13_23  1
    w[13,23]  normalized_inventory_13  -23
    w[13,23]  old_normalized_TC  -2.5819805194805197e+00
    w[13,23]  old_normalized_TC2  -0.00481601731601769
    w[13,24]  mass_13   1
    w[13,24]  w_lb_13_24  1
    w[13,24]  w_ub_13_24  1
    w[13,24]  normalized_inventory_13  -24
    w[13,24]  old_normalized_TC  -3.0750360750360755e+00
    w[13,24]  old_normalized_TC2  -4.9787157287157330e-01
    w[13,25]  mass_13   1
    w[13,25]  w_lb_13_25  1
    w[13,25]  w_ub_13_25  1
    w[13,25]  normalized_inventory_13  -25
    w[13,25]  old_normalized_TC  -3.5819805194805197e+00
    w[13,25]  old_normalized_TC2  -1.0048160173160177e+00
    w[13,26]  mass_13   1
    w[13,26]  w_lb_13_26  1
    w[13,26]  w_ub_13_26  1
    w[13,26]  normalized_inventory_13  -26
    w[13,26]  old_normalized_TC  -4.14448051948052
    w[13,26]  old_normalized_TC2  -1.5673160173160177e+00
    w[13,27]  mass_13   1
    w[13,27]  w_lb_13_27  1
    w[13,27]  w_ub_13_27  1
    w[13,27]  normalized_inventory_13  -27
    w[13,27]  old_normalized_TC  -4.70698051948052
    w[13,27]  old_normalized_TC2  -2.1298160173160174e+00
    w[13,28]  mass_13   1
    w[13,28]  w_lb_13_28  1
    w[13,28]  w_ub_13_28  1
    w[13,28]  normalized_inventory_13  -28
    w[13,28]  old_normalized_TC  -5.3051948051948052e+00
    w[13,28]  old_normalized_TC2  -2.7280303030303035e+00
    w[13,29]  mass_13   1
    w[13,29]  w_lb_13_29  1
    w[13,29]  w_ub_13_29  1
    w[13,29]  normalized_inventory_13  -29
    w[13,29]  old_normalized_TC  -5.9301948051948052e+00
    w[13,29]  old_normalized_TC2  -3.3530303030303035e+00
    w[14,0]   mass_14   1
    w[14,0]   w_lb_14_0  1
    w[14,0]   w_ub_14_0  1
    w[14,1]   mass_14   1
    w[14,1]   w_lb_14_1  1
    w[14,1]   w_ub_14_1  1
    w[14,1]   normalized_inventory_14  -1
    w[14,1]   old_normalized_TC2  4.5454545454545459e-01
    w[14,2]   mass_14   1
    w[14,2]   w_lb_14_2  1
    w[14,2]   w_ub_14_2  1
    w[14,2]   normalized_inventory_14  -2
    w[14,2]   old_normalized_TC2  9.0909090909090917e-01
    w[14,3]   mass_14   1
    w[14,3]   w_lb_14_3  1
    w[14,3]   w_ub_14_3  1
    w[14,3]   normalized_inventory_14  -3
    w[14,3]   old_normalized_TC2  1.2909090909090910e+00
    w[14,4]   mass_14   1
    w[14,4]   w_lb_14_4  1
    w[14,4]   w_ub_14_4  1
    w[14,4]   normalized_inventory_14  -4
    w[14,4]   old_normalized_TC2  1.6242424242424243e+00
    w[14,5]   mass_14   1
    w[14,5]   w_lb_14_5  1
    w[14,5]   w_ub_14_5  1
    w[14,5]   normalized_inventory_14  -5
    w[14,5]   old_normalized_TC2  1.8969696969696972e+00
    w[14,6]   mass_14   1
    w[14,6]   w_lb_14_6  1
    w[14,6]   w_ub_14_6  1
    w[14,6]   normalized_inventory_14  -6
    w[14,6]   old_normalized_TC2  2.0787878787878791e+00
    w[14,7]   mass_14   1
    w[14,7]   w_lb_14_7  1
    w[14,7]   w_ub_14_7  1
    w[14,7]   normalized_inventory_14  -7
    w[14,7]   old_normalized_TC2  2.2606060606060607e+00
    w[14,8]   mass_14   1
    w[14,8]   w_lb_14_8  1
    w[14,8]   w_ub_14_8  1
    w[14,8]   normalized_inventory_14  -8
    w[14,8]   old_normalized_TC2  2.4294372294372297e+00
    w[14,9]   mass_14   1
    w[14,9]   w_lb_14_9  1
    w[14,9]   w_ub_14_9  1
    w[14,9]   normalized_inventory_14  -9
    w[14,9]   old_normalized_TC2  2.5203463203463206e+00
    w[14,10]  mass_14   1
    w[14,10]  w_lb_14_10  1
    w[14,10]  w_ub_14_10  1
    w[14,10]  normalized_inventory_14  -10
    w[14,10]  old_normalized_TC  -7.5757575757575829e-02
    w[14,10]  old_normalized_TC2  2.5014069264069265e+00
    w[14,11]  mass_14   1
    w[14,11]  w_lb_14_11  1
    w[14,11]  w_ub_14_11  1
    w[14,11]  normalized_inventory_14  -11
    w[14,11]  old_normalized_TC  -2.5757575757575774e-01
    w[14,11]  old_normalized_TC2  2.3195887445887444e+00
    w[14,12]  mass_14   1
    w[14,12]  w_lb_14_12  1
    w[14,12]  w_ub_14_12  1
    w[14,12]  normalized_inventory_14  -12
    w[14,12]  old_normalized_TC  -0.54978354978355
    w[14,12]  old_normalized_TC2  2.0273809523809523e+00
    w[14,13]  mass_14   1
    w[14,13]  w_lb_14_13  1
    w[14,13]  w_ub_14_13  1
    w[14,13]  normalized_inventory_14  -13
    w[14,13]  old_normalized_TC  -9.8412698412698441e-01
    w[14,13]  old_normalized_TC2  1.5930375180375178e+00
    w[14,14]  mass_14   1
    w[14,14]  w_lb_14_14  1
    w[14,14]  w_ub_14_14  1
    w[14,14]  normalized_inventory_14  -14
    w[14,14]  old_normalized_TC  -1.4891774891774896e+00
    w[14,14]  old_normalized_TC2  1.0879870129870126e+00
    w[14,15]  mass_14   1
    w[14,15]  w_lb_14_15  1
    w[14,15]  w_ub_14_15  1
    w[14,15]  normalized_inventory_14  -15
    w[14,15]  old_normalized_TC  -2.0649350649350655e+00
    w[14,15]  old_normalized_TC2  5.1222943722943659e-01
    w[14,16]  mass_14   1
    w[14,16]  w_lb_14_16  1
    w[14,16]  w_ub_14_16  1
    w[14,16]  normalized_inventory_14  -16
    w[14,16]  old_normalized_TC  -2.7113997113997121e+00
    w[14,16]  old_normalized_TC2  -0.13423520923521
    w[14,17]  mass_14   1
    w[14,17]  w_lb_14_17  1
    w[14,17]  w_ub_14_17  1
    w[14,17]  normalized_inventory_14  -17
    w[14,17]  old_normalized_TC  -3.4386724386724392e+00
    w[14,17]  old_normalized_TC2  -8.6150793650793722e-01
    w[14,18]  mass_14   1
    w[14,18]  w_lb_14_18  1
    w[14,18]  w_ub_14_18  1
    w[14,18]  normalized_inventory_14  -18
    w[14,18]  old_normalized_TC  -4.2467532467532472e+00
    w[14,18]  old_normalized_TC2  -1.6695887445887454e+00
    w[14,19]  mass_14   1
    w[14,19]  w_lb_14_19  1
    w[14,19]  w_ub_14_19  1
    w[14,19]  normalized_inventory_14  -19
    w[14,19]  old_normalized_TC  -5.0779220779220786e+00
    w[14,19]  old_normalized_TC2  -2.5007575757575768e+00
    w[14,20]  mass_14   1
    w[14,20]  w_lb_14_20  1
    w[14,20]  w_ub_14_20  1
    w[14,20]  normalized_inventory_14  -20
    w[14,20]  old_normalized_TC  -5.9870129870129878e+00
    w[14,20]  old_normalized_TC2  -3.4098484848484856e+00
    w[15,0]   mass_15   1
    w[15,0]   w_lb_15_0  1
    w[15,0]   w_ub_15_0  1
    w[15,1]   mass_15   1
    w[15,1]   w_lb_15_1  1
    w[15,1]   w_ub_15_1  1
    w[15,1]   normalized_inventory_15  -1
    w[15,1]   old_normalized_TC2  4.5454545454545459e-01
    w[15,2]   mass_15   1
    w[15,2]   w_lb_15_2  1
    w[15,2]   w_ub_15_2  1
    w[15,2]   normalized_inventory_15  -2
    w[15,2]   old_normalized_TC2  9.0909090909090917e-01
    w[15,3]   mass_15   1
    w[15,3]   w_lb_15_3  1
    w[15,3]   w_ub_15_3  1
    w[15,3]   normalized_inventory_15  -3
    w[15,3]   old_normalized_TC2  1.2909090909090910e+00
    w[15,4]   mass_15   1
    w[15,4]   w_lb_15_4  1
    w[15,4]   w_ub_15_4  1
    w[15,4]   normalized_inventory_15  -4
    w[15,4]   old_normalized_TC2  1.6242424242424243e+00
    w[15,5]   mass_15   1
    w[15,5]   w_lb_15_5  1
    w[15,5]   w_ub_15_5  1
    w[15,5]   normalized_inventory_15  -5
    w[15,5]   old_normalized_TC2  1.8969696969696972e+00
    w[15,6]   mass_15   1
    w[15,6]   w_lb_15_6  1
    w[15,6]   w_ub_15_6  1
    w[15,6]   normalized_inventory_15  -6
    w[15,6]   old_normalized_TC2  2.0787878787878791e+00
    w[15,7]   mass_15   1
    w[15,7]   w_lb_15_7  1
    w[15,7]   w_ub_15_7  1
    w[15,7]   normalized_inventory_15  -7
    w[15,7]   old_normalized_TC2  2.2606060606060607e+00
    w[15,8]   mass_15   1
    w[15,8]   w_lb_15_8  1
    w[15,8]   w_ub_15_8  1
    w[15,8]   normalized_inventory_15  -8
    w[15,8]   old_normalized_TC2  2.4294372294372297e+00
    w[15,9]   mass_15   1
    w[15,9]   w_lb_15_9  1
    w[15,9]   w_ub_15_9  1
    w[15,9]   normalized_inventory_15  -9
    w[15,9]   old_normalized_TC2  2.5203463203463206e+00
    w[15,10]  mass_15   1
    w[15,10]  w_lb_15_10  1
    w[15,10]  w_ub_15_10  1
    w[15,10]  normalized_inventory_15  -10
    w[15,10]  old_normalized_TC  -7.5757575757575829e-02
    w[15,10]  old_normalized_TC2  2.5014069264069265e+00
    w[15,11]  mass_15   1
    w[15,11]  w_lb_15_11  1
    w[15,11]  w_ub_15_11  1
    w[15,11]  normalized_inventory_15  -11
    w[15,11]  old_normalized_TC  -2.5757575757575774e-01
    w[15,11]  old_normalized_TC2  2.3195887445887444e+00
    w[15,12]  mass_15   1
    w[15,12]  w_lb_15_12  1
    w[15,12]  w_ub_15_12  1
    w[15,12]  normalized_inventory_15  -12
    w[15,12]  old_normalized_TC  -0.54978354978355
    w[15,12]  old_normalized_TC2  2.0273809523809523e+00
    w[15,13]  mass_15   1
    w[15,13]  w_lb_15_13  1
    w[15,13]  w_ub_15_13  1
    w[15,13]  normalized_inventory_15  -13
    w[15,13]  old_normalized_TC  -9.8412698412698441e-01
    w[15,13]  old_normalized_TC2  1.5930375180375178e+00
    w[15,14]  mass_15   1
    w[15,14]  w_lb_15_14  1
    w[15,14]  w_ub_15_14  1
    w[15,14]  normalized_inventory_15  -14
    w[15,14]  old_normalized_TC  -1.4891774891774896e+00
    w[15,14]  old_normalized_TC2  1.0879870129870126e+00
    w[15,15]  mass_15   1
    w[15,15]  w_lb_15_15  1
    w[15,15]  w_ub_15_15  1
    w[15,15]  normalized_inventory_15  -15
    w[15,15]  old_normalized_TC  -2.0649350649350655e+00
    w[15,15]  old_normalized_TC2  5.1222943722943659e-01
    w[15,16]  mass_15   1
    w[15,16]  w_lb_15_16  1
    w[15,16]  w_ub_15_16  1
    w[15,16]  normalized_inventory_15  -16
    w[15,16]  old_normalized_TC  -2.7113997113997121e+00
    w[15,16]  old_normalized_TC2  -0.13423520923521
    w[15,17]  mass_15   1
    w[15,17]  w_lb_15_17  1
    w[15,17]  w_ub_15_17  1
    w[15,17]  normalized_inventory_15  -17
    w[15,17]  old_normalized_TC  -3.4386724386724392e+00
    w[15,17]  old_normalized_TC2  -8.6150793650793722e-01
    w[15,18]  mass_15   1
    w[15,18]  w_lb_15_18  1
    w[15,18]  w_ub_15_18  1
    w[15,18]  normalized_inventory_15  -18
    w[15,18]  old_normalized_TC  -4.2467532467532472e+00
    w[15,18]  old_normalized_TC2  -1.6695887445887454e+00
    w[15,19]  mass_15   1
    w[15,19]  w_lb_15_19  1
    w[15,19]  w_ub_15_19  1
    w[15,19]  normalized_inventory_15  -19
    w[15,19]  old_normalized_TC  -5.0779220779220786e+00
    w[15,19]  old_normalized_TC2  -2.5007575757575768e+00
    w[15,20]  mass_15   1
    w[15,20]  w_lb_15_20  1
    w[15,20]  w_ub_15_20  1
    w[15,20]  normalized_inventory_15  -20
    w[15,20]  old_normalized_TC  -5.9870129870129878e+00
    w[15,20]  old_normalized_TC2  -3.4098484848484856e+00
    w[16,0]   mass_16   1
    w[16,0]   w_lb_16_0  1
    w[16,0]   w_ub_16_0  1
    w[16,1]   mass_16   1
    w[16,1]   w_lb_16_1  1
    w[16,1]   w_ub_16_1  1
    w[16,1]   normalized_inventory_16  -1
    w[16,1]   old_normalized_TC2  3.5714285714285715e-01
    w[16,2]   mass_16   1
    w[16,2]   w_lb_16_2  1
    w[16,2]   w_ub_16_2  1
    w[16,2]   normalized_inventory_16  -2
    w[16,2]   old_normalized_TC2  7.1428571428571430e-01
    w[16,3]   mass_16   1
    w[16,3]   w_lb_16_3  1
    w[16,3]   w_ub_16_3  1
    w[16,3]   normalized_inventory_16  -3
    w[16,3]   old_normalized_TC2  1.0571428571428572e+00
    w[16,4]   mass_16   1
    w[16,4]   w_lb_16_4  1
    w[16,4]   w_ub_16_4  1
    w[16,4]   normalized_inventory_16  -4
    w[16,4]   old_normalized_TC2  1.3428571428571430e+00
    w[16,5]   mass_16   1
    w[16,5]   w_lb_16_5  1
    w[16,5]   w_ub_16_5  1
    w[16,5]   normalized_inventory_16  -5
    w[16,5]   old_normalized_TC2  1.6047619047619048e+00
    w[16,6]   mass_16   1
    w[16,6]   w_lb_16_6  1
    w[16,6]   w_ub_16_6  1
    w[16,6]   normalized_inventory_16  -6
    w[16,6]   old_normalized_TC2  1.8190476190476190e+00
    w[16,7]   mass_16   1
    w[16,7]   w_lb_16_7  1
    w[16,7]   w_ub_16_7  1
    w[16,7]   normalized_inventory_16  -7
    w[16,7]   old_normalized_TC2  1.9878787878787880e+00
    w[16,8]   mass_16   1
    w[16,8]   w_lb_16_8  1
    w[16,8]   w_ub_16_8  1
    w[16,8]   normalized_inventory_16  -8
    w[16,8]   old_normalized_TC2  2.1307359307359310e+00
    w[16,9]   mass_16   1
    w[16,9]   w_lb_16_9  1
    w[16,9]   w_ub_16_9  1
    w[16,9]   normalized_inventory_16  -9
    w[16,9]   old_normalized_TC2  2.2735930735930738e+00
    w[16,10]  mass_16   1
    w[16,10]  w_lb_16_10  1
    w[16,10]  w_ub_16_10  1
    w[16,10]  normalized_inventory_16  -10
    w[16,10]  old_normalized_TC2  2.4164502164502166e+00
    w[16,11]  mass_16   1
    w[16,11]  w_lb_16_11  1
    w[16,11]  w_ub_16_11  1
    w[16,11]  normalized_inventory_16  -11
    w[16,11]  old_normalized_TC2  2.4878787878787878e+00
    w[16,12]  mass_16   1
    w[16,12]  w_lb_16_12  1
    w[16,12]  w_ub_16_12  1
    w[16,12]  normalized_inventory_16  -12
    w[16,12]  old_normalized_TC  -2.3809523809523808e-02
    w[16,12]  old_normalized_TC2  2.5354978354978357e+00
    w[16,13]  mass_16   1
    w[16,13]  w_lb_16_13  1
    w[16,13]  w_ub_16_13  1
    w[16,13]  normalized_inventory_16  -13
    w[16,13]  old_normalized_TC  -1.1471861471861464e-01
    w[16,13]  old_normalized_TC2  2.4624458874458877e+00
    w[16,14]  mass_16   1
    w[16,14]  w_lb_16_14  1
    w[16,14]  w_ub_16_14  1
    w[16,14]  normalized_inventory_16  -14
    w[16,14]  old_normalized_TC  -2.5757575757575746e-01
    w[16,14]  old_normalized_TC2  2.3195887445887449e+00
    w[16,15]  mass_16   1
    w[16,15]  w_lb_16_15  1
    w[16,15]  w_ub_16_15  1
    w[16,15]  normalized_inventory_16  -15
    w[16,15]  old_normalized_TC  -4.7186147186147176e-01
    w[16,15]  old_normalized_TC2  2.1053030303030305e+00
    w[16,16]  mass_16   1
    w[16,16]  w_lb_16_16  1
    w[16,16]  w_ub_16_16  1
    w[16,16]  normalized_inventory_16  -16
    w[16,16]  old_normalized_TC  -7.8932178932178920e-01
    w[16,16]  old_normalized_TC2  1.7878427128427130e+00
    w[16,17]  mass_16   1
    w[16,17]  w_lb_16_17  1
    w[16,17]  w_ub_16_17  1
    w[16,17]  normalized_inventory_16  -17
    w[16,17]  old_normalized_TC  -1.1464646464646462e+00
    w[16,17]  old_normalized_TC2  1.4306998556998558e+00
    w[16,18]  mass_16   1
    w[16,18]  w_lb_16_18  1
    w[16,18]  w_ub_16_18  1
    w[16,18]  normalized_inventory_16  -18
    w[16,18]  old_normalized_TC  -1.5670995670995669e+00
    w[16,18]  old_normalized_TC2  1.0100649350649353e+00
    w[16,19]  mass_16   1
    w[16,19]  w_lb_16_19  1
    w[16,19]  w_ub_16_19  1
    w[16,19]  normalized_inventory_16  -19
    w[16,19]  old_normalized_TC  -2.0194805194805192e+00
    w[16,19]  old_normalized_TC2  5.5768398268398289e-01
    w[16,20]  mass_16   1
    w[16,20]  w_lb_16_20  1
    w[16,20]  w_ub_16_20  1
    w[16,20]  normalized_inventory_16  -20
    w[16,20]  old_normalized_TC  -2.5194805194805192e+00
    w[16,20]  old_normalized_TC2  5.7683982683982865e-02
    w[16,21]  mass_16   1
    w[16,21]  w_lb_16_21  1
    w[16,21]  w_ub_16_21  1
    w[16,21]  normalized_inventory_16  -21
    w[16,21]  old_normalized_TC  -3.0750360750360746e+00
    w[16,21]  old_normalized_TC2  -4.9787157287157263e-01
    w[16,22]  mass_16   1
    w[16,22]  w_lb_16_22  1
    w[16,22]  w_ub_16_22  1
    w[16,22]  normalized_inventory_16  -22
    w[16,22]  old_normalized_TC  -3.6623376623376620e+00
    w[16,22]  old_normalized_TC2  -1.0851731601731598e+00
    w[16,23]  mass_16   1
    w[16,23]  w_lb_16_23  1
    w[16,23]  w_ub_16_23  1
    w[16,23]  normalized_inventory_16  -23
    w[16,23]  old_normalized_TC  -4.3051948051948044e+00
    w[16,23]  old_normalized_TC2  -1.7280303030303026e+00
    w[16,24]  mass_16   1
    w[16,24]  w_lb_16_24  1
    w[16,24]  w_ub_16_24  1
    w[16,24]  normalized_inventory_16  -24
    w[16,24]  old_normalized_TC  -4.9480519480519476e+00
    w[16,24]  old_normalized_TC2  -2.3708874458874454e+00
    w[16,25]  mass_16   1
    w[16,25]  w_lb_16_25  1
    w[16,25]  w_ub_16_25  1
    w[16,25]  normalized_inventory_16  -25
    w[16,25]  old_normalized_TC  -5.6623376623376611e+00
    w[16,25]  old_normalized_TC2  -3.08517316017316
    w[16,26]  mass_16   1
    w[16,26]  w_lb_16_26  1
    w[16,26]  w_ub_16_26  1
    w[16,26]  normalized_inventory_16  -26
    w[16,26]  old_normalized_TC  -6.3766233766233755e+00
    w[16,26]  old_normalized_TC2  -3.7994588744588738e+00
    w[16,27]  mass_16   1
    w[16,27]  w_lb_16_27  1
    w[16,27]  w_ub_16_27  1
    w[16,27]  normalized_inventory_16  -27
    w[16,27]  old_normalized_TC  -7.1305916305916295e+00
    w[16,27]  old_normalized_TC2  -4.5534271284271277e+00
    w[17,0]   mass_17   1
    w[17,0]   w_lb_17_0  1
    w[17,0]   w_ub_17_0  1
    w[17,1]   mass_17   1
    w[17,1]   w_lb_17_1  1
    w[17,1]   w_ub_17_1  1
    w[17,1]   normalized_inventory_17  -1
    w[17,1]   old_normalized_TC2  5.5555555555555558e-01
    w[17,2]   mass_17   1
    w[17,2]   w_lb_17_2  1
    w[17,2]   w_ub_17_2  1
    w[17,2]   normalized_inventory_17  -2
    w[17,2]   old_normalized_TC2  1.0888888888888890e+00
    w[17,3]   mass_17   1
    w[17,3]   w_lb_17_3  1
    w[17,3]   w_ub_17_3  1
    w[17,3]   normalized_inventory_17  -3
    w[17,3]   old_normalized_TC2  1.5333333333333334e+00
    w[17,4]   mass_17   1
    w[17,4]   w_lb_17_4  1
    w[17,4]   w_ub_17_4  1
    w[17,4]   normalized_inventory_17  -4
    w[17,4]   old_normalized_TC2  1.8666666666666667e+00
    w[17,5]   mass_17   1
    w[17,5]   w_lb_17_5  1
    w[17,5]   w_ub_17_5  1
    w[17,5]   normalized_inventory_17  -5
    w[17,5]   old_normalized_TC2  2.0989898989898990e+00
    w[17,6]   mass_17   1
    w[17,6]   w_lb_17_6  1
    w[17,6]   w_ub_17_6  1
    w[17,6]   normalized_inventory_17  -6
    w[17,6]   old_normalized_TC2  2.3212121212121213e+00
    w[17,7]   mass_17   1
    w[17,7]   w_lb_17_7  1
    w[17,7]   w_ub_17_7  1
    w[17,7]   normalized_inventory_17  -7
    w[17,7]   old_normalized_TC2  2.47994227994228
    w[17,8]   mass_17   1
    w[17,8]   w_lb_17_8  1
    w[17,8]   w_ub_17_8  1
    w[17,8]   normalized_inventory_17  -8
    w[17,8]   old_normalized_TC  -5.5555555555555552e-02
    w[17,8]   old_normalized_TC2  2.5216089466089469e+00
    w[17,9]   mass_17   1
    w[17,9]   w_lb_17_9  1
    w[17,9]   w_ub_17_9  1
    w[17,9]   normalized_inventory_17  -9
    w[17,9]   old_normalized_TC  -2.5757575757575746e-01
    w[17,9]   old_normalized_TC2  2.3195887445887449e+00
    w[17,10]  mass_17   1
    w[17,10]  w_lb_17_10  1
    w[17,10]  w_ub_17_10  1
    w[17,10]  normalized_inventory_17  -10
    w[17,10]  old_normalized_TC  -6.3059163059163048e-01
    w[17,10]  old_normalized_TC2  1.9465728715728718e+00
    w[17,11]  mass_17   1
    w[17,11]  w_lb_17_11  1
    w[17,11]  w_ub_17_11  1
    w[17,11]  normalized_inventory_17  -11
    w[17,11]  old_normalized_TC  -1.1861471861471860e+00
    w[17,11]  old_normalized_TC2  1.3910173160173163e+00
    w[17,12]  mass_17   1
    w[17,12]  w_lb_17_12  1
    w[17,12]  w_ub_17_12  1
    w[17,12]  normalized_inventory_17  -12
    w[17,12]  old_normalized_TC  -1.8528138528138525e+00
    w[17,12]  old_normalized_TC2  7.2435064935064952e-01
    w[17,13]  mass_17   1
    w[17,13]  w_lb_17_13  1
    w[17,13]  w_ub_17_13  1
    w[17,13]  normalized_inventory_17  -13
    w[17,13]  old_normalized_TC  -2.6305916305916304e+00
    w[17,13]  old_normalized_TC2  -5.3427128427128240e-02
    w[17,14]  mass_17   1
    w[17,14]  w_lb_17_14  1
    w[17,14]  w_ub_17_14  1
    w[17,14]  normalized_inventory_17  -14
    w[17,14]  old_normalized_TC  -3.5194805194805192e+00
    w[17,14]  old_normalized_TC2  -0.942316017316017
    w[17,15]  mass_17   1
    w[17,15]  w_lb_17_15  1
    w[17,15]  w_ub_17_15  1
    w[17,15]  normalized_inventory_17  -15
    w[17,15]  old_normalized_TC  -4.5194805194805188e+00
    w[17,15]  old_normalized_TC2  -1.9423160173160170e+00
    w[17,16]  mass_17   1
    w[17,16]  w_lb_17_16  1
    w[17,16]  w_ub_17_16  1
    w[17,16]  normalized_inventory_17  -16
    w[17,16]  old_normalized_TC  -5.5829725829725820e+00
    w[17,16]  old_normalized_TC2  -3.0058080808080803e+00
    w[17,17]  mass_17   1
    w[17,17]  w_lb_17_17  1
    w[17,17]  w_ub_17_17  1
    w[17,17]  normalized_inventory_17  -17
    w[17,17]  old_normalized_TC  -6.6940836940836936e+00
    w[17,17]  old_normalized_TC2  -4.1169191919191910e+00
    w[17,18]  mass_17   1
    w[17,18]  w_lb_17_18  1
    w[17,18]  w_ub_17_18  1
    w[17,18]  normalized_inventory_17  -18
    w[17,18]  old_normalized_TC  -7.9163059163059151e+00
    w[17,18]  old_normalized_TC2  -5.3391414141414133e+00
    w[17,19]  mass_17   1
    w[17,19]  w_lb_17_19  1
    w[17,19]  w_ub_17_19  1
    w[17,19]  normalized_inventory_17  -19
    w[17,19]  old_normalized_TC  -9.58297258297258
    w[17,19]  old_normalized_TC2  -7.0058080808080794e+00
    w[17,20]  mass_17   1
    w[17,20]  w_lb_17_20  1
    w[17,20]  w_ub_17_20  1
    w[17,20]  normalized_inventory_17  -20
    w[17,20]  old_normalized_TC  -1.1559163059163057e+01
    w[17,20]  old_normalized_TC2  -8.9819985569985548e+00
    w[18,10]  mass_18   1
    w[18,10]  w_lb_18_10  1
    w[18,10]  w_ub_18_10  1
    w[18,10]  normalized_inventory_18  -10
    w[18,10]  old_normalized_TC2  2.4164502164502166e+00
    w[18,11]  mass_18   1
    w[18,11]  w_lb_18_11  1
    w[18,11]  w_ub_18_11  1
    w[18,11]  normalized_inventory_18  -11
    w[18,11]  old_normalized_TC2  2.4878787878787878e+00
    w[18,12]  mass_18   1
    w[18,12]  w_lb_18_12  1
    w[18,12]  w_ub_18_12  1
    w[18,12]  normalized_inventory_18  -12
    w[18,12]  old_normalized_TC  -2.3809523809523808e-02
    w[18,12]  old_normalized_TC2  2.5354978354978357e+00
    w[18,13]  mass_18   1
    w[18,13]  w_lb_18_13  1
    w[18,13]  w_ub_18_13  1
    w[18,13]  normalized_inventory_18  -13
    w[18,13]  old_normalized_TC  -1.1471861471861464e-01
    w[18,13]  old_normalized_TC2  2.4624458874458877e+00
    w[18,14]  mass_18   1
    w[18,14]  w_lb_18_14  1
    w[18,14]  w_ub_18_14  1
    w[18,14]  normalized_inventory_18  -14
    w[18,14]  old_normalized_TC  -2.5757575757575746e-01
    w[18,14]  old_normalized_TC2  2.3195887445887449e+00
    w[18,15]  mass_18   1
    w[18,15]  w_lb_18_15  1
    w[18,15]  w_ub_18_15  1
    w[18,15]  normalized_inventory_18  -15
    w[18,15]  old_normalized_TC  -4.7186147186147176e-01
    w[18,15]  old_normalized_TC2  2.1053030303030305e+00
    w[18,16]  mass_18   1
    w[18,16]  w_lb_18_16  1
    w[18,16]  w_ub_18_16  1
    w[18,16]  normalized_inventory_18  -16
    w[18,16]  old_normalized_TC  -7.8932178932178920e-01
    w[18,16]  old_normalized_TC2  1.7878427128427130e+00
    w[18,17]  mass_18   1
    w[18,17]  w_lb_18_17  1
    w[18,17]  w_ub_18_17  1
    w[18,17]  normalized_inventory_18  -17
    w[18,17]  old_normalized_TC  -1.1464646464646462e+00
    w[18,17]  old_normalized_TC2  1.4306998556998558e+00
    w[18,18]  mass_18   1
    w[18,18]  w_lb_18_18  1
    w[18,18]  w_ub_18_18  1
    w[18,18]  normalized_inventory_18  -18
    w[18,18]  old_normalized_TC  -1.5670995670995669e+00
    w[18,18]  old_normalized_TC2  1.0100649350649353e+00
    w[18,19]  mass_18   1
    w[18,19]  w_lb_18_19  1
    w[18,19]  w_ub_18_19  1
    w[18,19]  normalized_inventory_18  -19
    w[18,19]  old_normalized_TC  -2.0194805194805192e+00
    w[18,19]  old_normalized_TC2  5.5768398268398289e-01
    w[18,20]  mass_18   1
    w[18,20]  w_lb_18_20  1
    w[18,20]  w_ub_18_20  1
    w[18,20]  normalized_inventory_18  -20
    w[18,20]  old_normalized_TC  -2.5194805194805192e+00
    w[18,20]  old_normalized_TC2  5.7683982683982865e-02
    w[18,21]  mass_18   1
    w[18,21]  w_lb_18_21  1
    w[18,21]  w_ub_18_21  1
    w[18,21]  normalized_inventory_18  -21
    w[18,21]  old_normalized_TC  -3.0750360750360746e+00
    w[18,21]  old_normalized_TC2  -4.9787157287157263e-01
    w[18,22]  mass_18   1
    w[18,22]  w_lb_18_22  1
    w[18,22]  w_ub_18_22  1
    w[18,22]  normalized_inventory_18  -22
    w[18,22]  old_normalized_TC  -3.6623376623376620e+00
    w[18,22]  old_normalized_TC2  -1.0851731601731598e+00
    w[18,23]  mass_18   1
    w[18,23]  w_lb_18_23  1
    w[18,23]  w_ub_18_23  1
    w[18,23]  normalized_inventory_18  -23
    w[18,23]  old_normalized_TC  -4.3051948051948044e+00
    w[18,23]  old_normalized_TC2  -1.7280303030303026e+00
    w[18,24]  mass_18   1
    w[18,24]  w_lb_18_24  1
    w[18,24]  w_ub_18_24  1
    w[18,24]  normalized_inventory_18  -24
    w[18,24]  old_normalized_TC  -4.9480519480519476e+00
    w[18,24]  old_normalized_TC2  -2.3708874458874454e+00
    w[18,25]  mass_18   1
    w[18,25]  w_lb_18_25  1
    w[18,25]  w_ub_18_25  1
    w[18,25]  normalized_inventory_18  -25
    w[18,25]  old_normalized_TC  -5.6623376623376611e+00
    w[18,25]  old_normalized_TC2  -3.08517316017316
    w[18,26]  mass_18   1
    w[18,26]  w_lb_18_26  1
    w[18,26]  w_ub_18_26  1
    w[18,26]  normalized_inventory_18  -26
    w[18,26]  old_normalized_TC  -6.3766233766233755e+00
    w[18,26]  old_normalized_TC2  -3.7994588744588738e+00
    w[18,27]  mass_18   1
    w[18,27]  w_lb_18_27  1
    w[18,27]  w_ub_18_27  1
    w[18,27]  normalized_inventory_18  -27
    w[18,27]  old_normalized_TC  -7.1305916305916295e+00
    w[18,27]  old_normalized_TC2  -4.5534271284271277e+00
    w[18,28]  mass_18   1
    w[18,28]  w_lb_18_28  1
    w[18,28]  w_ub_18_28  1
    w[18,28]  normalized_inventory_18  -28
    w[18,28]  old_normalized_TC  -7.9163059163059151e+00
    w[18,28]  old_normalized_TC2  -5.3391414141414133e+00
    w[18,29]  mass_18   1
    w[18,29]  w_lb_18_29  1
    w[18,29]  w_ub_18_29  1
    w[18,29]  normalized_inventory_18  -29
    w[18,29]  old_normalized_TC  -8.9877344877344854e+00
    w[18,29]  old_normalized_TC2  -6.4105699855699836e+00
    w[18,30]  mass_18   1
    w[18,30]  w_lb_18_30  1
    w[18,30]  w_ub_18_30  1
    w[18,30]  normalized_inventory_18  -30
    w[18,30]  old_normalized_TC  -1.0122655122655120e+01
    w[18,30]  old_normalized_TC2  -7.5454906204906189e+00
    w[19,0]   mass_19   1
    w[19,0]   w_lb_19_0  1
    w[19,0]   w_ub_19_0  1
    w[19,1]   mass_19   1
    w[19,1]   w_lb_19_1  1
    w[19,1]   w_ub_19_1  1
    w[19,1]   normalized_inventory_19  -1
    w[19,1]   old_normalized_TC2  4.1666666666666669e-01
    w[19,2]   mass_19   1
    w[19,2]   w_lb_19_2  1
    w[19,2]   w_ub_19_2  1
    w[19,2]   normalized_inventory_19  -2
    w[19,2]   old_normalized_TC2  8.3333333333333337e-01
    w[19,3]   mass_19   1
    w[19,3]   w_lb_19_3  1
    w[19,3]   w_ub_19_3  1
    w[19,3]   normalized_inventory_19  -3
    w[19,3]   old_normalized_TC2  1.2
    w[19,4]   mass_19   1
    w[19,4]   w_lb_19_4  1
    w[19,4]   w_ub_19_4  1
    w[19,4]   normalized_inventory_19  -4
    w[19,4]   old_normalized_TC2  1.5333333333333334e+00
    w[19,5]   mass_19   1
    w[19,5]   w_lb_19_5  1
    w[19,5]   w_ub_19_5  1
    w[19,5]   normalized_inventory_19  -5
    w[19,5]   old_normalized_TC2  1.7833333333333334e+00
    w[19,6]   mass_19   1
    w[19,6]   w_lb_19_6  1
    w[19,6]   w_ub_19_6  1
    w[19,6]   normalized_inventory_19  -6
    w[19,6]   old_normalized_TC2  1.9878787878787880e+00
    w[19,7]   mass_19   1
    w[19,7]   w_lb_19_7  1
    w[19,7]   w_ub_19_7  1
    w[19,7]   normalized_inventory_19  -7
    w[19,7]   old_normalized_TC2  2.1545454545454548e+00
    w[19,8]   mass_19   1
    w[19,8]   w_lb_19_8  1
    w[19,8]   w_ub_19_8  1
    w[19,8]   normalized_inventory_19  -8
    w[19,8]   old_normalized_TC2  2.3212121212121213e+00
    w[19,9]   mass_19   1
    w[19,9]   w_lb_19_9  1
    w[19,9]   w_ub_19_9  1
    w[19,9]   normalized_inventory_19  -9
    w[19,9]   old_normalized_TC2  2.4521645021645022e+00
    w[19,10]  mass_19   1
    w[19,10]  w_lb_19_10  1
    w[19,10]  w_ub_19_10  1
    w[19,10]  normalized_inventory_19  -10
    w[19,10]  old_normalized_TC2  2.5354978354978357e+00
    w[19,11]  mass_19   1
    w[19,11]  w_lb_19_11  1
    w[19,11]  w_ub_19_11  1
    w[19,11]  normalized_inventory_19  -11
    w[19,11]  old_normalized_TC  -9.0909090909090828e-02
    w[19,11]  old_normalized_TC2  2.4862554112554114e+00
    w[19,12]  mass_19   1
    w[19,12]  w_lb_19_12  1
    w[19,12]  w_ub_19_12  1
    w[19,12]  normalized_inventory_19  -12
    w[19,12]  old_normalized_TC  -2.5757575757575746e-01
    w[19,12]  old_normalized_TC2  2.3195887445887449e+00
    w[19,13]  mass_19   1
    w[19,13]  w_lb_19_13  1
    w[19,13]  w_ub_19_13  1
    w[19,13]  normalized_inventory_19  -13
    w[19,13]  old_normalized_TC  -5.1948051948051932e-01
    w[19,13]  old_normalized_TC2  2.0576839826839830e+00
    w[20,14]  mass_20   1
    w[20,14]  w_lb_20_14  1
    w[20,14]  w_ub_20_14  1
    w[20,14]  normalized_inventory_20  -14
    w[20,14]  old_normalized_TC  -4.1666666666666713e-02
    w[20,14]  old_normalized_TC2  2.5354978354978357e+00
    w[20,15]  mass_20   1
    w[20,15]  w_lb_20_15  1
    w[20,15]  w_ub_20_15  1
    w[20,15]  normalized_inventory_20  -15
    w[20,15]  old_normalized_TC  -1.3257575757575760e-01
    w[20,15]  old_normalized_TC2  2.4445887445887449e+00
    w[20,16]  mass_20   1
    w[20,16]  w_lb_20_16  1
    w[20,16]  w_ub_20_16  1
    w[20,16]  normalized_inventory_20  -16
    w[20,16]  old_normalized_TC  -2.5757575757575762e-01
    w[20,16]  old_normalized_TC2  2.3195887445887449e+00
    w[20,17]  mass_20   1
    w[20,17]  w_lb_20_17  1
    w[20,17]  w_ub_20_17  1
    w[20,17]  normalized_inventory_20  -17
    w[20,17]  old_normalized_TC  -4.4507575757575762e-01
    w[20,17]  old_normalized_TC2  2.1320887445887449e+00
    w[20,18]  mass_20   1
    w[20,18]  w_lb_20_18  1
    w[20,18]  w_ub_20_18  1
    w[20,18]  normalized_inventory_20  -18
    w[20,18]  old_normalized_TC  -7.0003607503607523e-01
    w[20,18]  old_normalized_TC2  1.8771284271284270e+00
    w[20,19]  mass_20   1
    w[20,19]  w_lb_20_19  1
    w[20,19]  w_ub_20_19  1
    w[20,19]  normalized_inventory_20  -19
    w[20,19]  old_normalized_TC  -1.0125360750360752e+00
    w[20,19]  old_normalized_TC2  1.5646284271284270e+00
    w[20,20]  mass_20   1
    w[20,20]  w_lb_20_20  1
    w[20,20]  w_ub_20_20  1
    w[20,20]  normalized_inventory_20  -20
    w[20,20]  old_normalized_TC  -1.3528138528138529e+00
    w[20,20]  old_normalized_TC2  1.2243506493506491e+00
    w[20,21]  mass_20   1
    w[20,21]  w_lb_20_21  1
    w[20,21]  w_ub_20_21  1
    w[20,21]  normalized_inventory_20  -21
    w[20,21]  old_normalized_TC  -1.7278138528138529e+00
    w[20,21]  old_normalized_TC2  8.4935064935064908e-01
    w[20,22]  mass_20   1
    w[20,22]  w_lb_20_22  1
    w[20,22]  w_ub_20_22  1
    w[20,22]  normalized_inventory_20  -22
    w[20,22]  old_normalized_TC  -2.1444805194805197e+00
    w[20,22]  old_normalized_TC2  4.3268398268398234e-01
    w[20,23]  mass_20   1
    w[20,23]  w_lb_20_23  1
    w[20,23]  w_ub_20_23  1
    w[20,23]  normalized_inventory_20  -23
    w[20,23]  old_normalized_TC  -2.5819805194805197e+00
    w[20,23]  old_normalized_TC2  -0.00481601731601769
    w[20,24]  mass_20   1
    w[20,24]  w_lb_20_24  1
    w[20,24]  w_ub_20_24  1
    w[20,24]  normalized_inventory_20  -24
    w[20,24]  old_normalized_TC  -3.0750360750360755e+00
    w[20,24]  old_normalized_TC2  -4.9787157287157330e-01
    w[20,25]  mass_20   1
    w[20,25]  w_lb_20_25  1
    w[20,25]  w_ub_20_25  1
    w[20,25]  normalized_inventory_20  -25
    w[20,25]  old_normalized_TC  -3.5819805194805197e+00
    w[20,25]  old_normalized_TC2  -1.0048160173160177e+00
    w[20,26]  mass_20   1
    w[20,26]  w_lb_20_26  1
    w[20,26]  w_ub_20_26  1
    w[20,26]  normalized_inventory_20  -26
    w[20,26]  old_normalized_TC  -4.14448051948052
    w[20,26]  old_normalized_TC2  -1.5673160173160177e+00
    w[20,27]  mass_20   1
    w[20,27]  w_lb_20_27  1
    w[20,27]  w_ub_20_27  1
    w[20,27]  normalized_inventory_20  -27
    w[20,27]  old_normalized_TC  -4.70698051948052
    w[20,27]  old_normalized_TC2  -2.1298160173160174e+00
    w[20,28]  mass_20   1
    w[20,28]  w_lb_20_28  1
    w[20,28]  w_ub_20_28  1
    w[20,28]  normalized_inventory_20  -28
    w[20,28]  old_normalized_TC  -5.3051948051948052e+00
    w[20,28]  old_normalized_TC2  -2.7280303030303035e+00
    w[20,29]  mass_20   1
    w[20,29]  w_lb_20_29  1
    w[20,29]  w_ub_20_29  1
    w[20,29]  normalized_inventory_20  -29
    w[20,29]  old_normalized_TC  -5.9301948051948052e+00
    w[20,29]  old_normalized_TC2  -3.3530303030303035e+00
    w[20,30]  mass_20   1
    w[20,30]  w_lb_20_30  1
    w[20,30]  w_ub_20_30  1
    w[20,30]  normalized_inventory_20  -30
    w[20,30]  old_normalized_TC  -6.5551948051948052e+00
    w[20,30]  old_normalized_TC2  -3.9780303030303035e+00
    t         mass_1    -1
    t         mass_2    -1
    t         mass_3    -1
    t         mass_4    -1
    t         mass_5    -1
    t         mass_6    -1
    t         mass_7    -1
    t         mass_8    -1
    t         mass_9    -1
    t         mass_10   -1
    t         mass_11   -1
    t         mass_12   -1
    t         mass_13   -1
    t         mass_14   -1
    t         mass_15   -1
    t         mass_16   -1
    t         mass_17   -1
    t         mass_18   -1
    t         mass_19   -1
    t         mass_20   -1
    t         scaled_stock_lower  -148
    t         scaled_stock_upper  -208
    t         old_normalized_TC2  -5.1501623376623371e+01
    t         old_TS1   -148
    t         old_TS2   -208
    t         old_TS3   -148
    t         old_TS4   -208
    z[1]      normalized_inventory_1  1
    z[1]      normalized_ratio_1  -1.1111111111111110e-01
    z[1]      scaled_stock_lower  1
    z[1]      scaled_stock_upper  1
    z[1]      old_TS1   1
    z[1]      old_TS2   1
    z[1]      old_TS3   1
    z[1]      old_TS4   1
    z[2]      normalized_inventory_2  1
    z[2]      normalized_ratio_2  -0.0625
    z[2]      scaled_stock_lower  1
    z[2]      scaled_stock_upper  1
    z[2]      old_TS1   1
    z[2]      old_TS2   1
    z[2]      old_TS3   1
    z[2]      old_TS4   1
    z[3]      normalized_inventory_3  1
    z[3]      normalized_ratio_3  -9.0909090909090912e-02
    z[3]      scaled_stock_lower  1
    z[3]      scaled_stock_upper  1
    z[3]      old_TS1   1
    z[3]      old_TS2   1
    z[3]      old_TS3   1
    z[3]      old_TS4   1
    z[4]      normalized_inventory_4  1
    z[4]      normalized_ratio_4  -0.1
    z[4]      scaled_stock_lower  1
    z[4]      scaled_stock_upper  1
    z[4]      old_TS1   1
    z[4]      old_TS2   1
    z[4]      old_TS3   1
    z[4]      old_TS4   1
    z[5]      normalized_inventory_5  1
    z[5]      normalized_ratio_5  -8.3333333333333329e-02
    z[5]      scaled_stock_lower  1
    z[5]      scaled_stock_upper  1
    z[5]      old_TS1   1
    z[5]      old_TS2   1
    z[5]      old_TS3   1
    z[5]      old_TS4   1
    z[6]      normalized_inventory_6  1
    z[6]      normalized_ratio_6  -9.0909090909090912e-02
    z[6]      scaled_stock_lower  1
    z[6]      scaled_stock_upper  1
    z[6]      old_TS1   1
    z[6]      old_TS2   1
    z[6]      old_TS3   1
    z[6]      old_TS4   1
    z[7]      normalized_inventory_7  1
    z[7]      normalized_ratio_7  -1.1111111111111110e-01
    z[7]      scaled_stock_lower  1
    z[7]      scaled_stock_upper  1
    z[7]      old_TS1   1
    z[7]      old_TS2   1
    z[7]      old_TS3   1
    z[7]      old_TS4   1
    z[8]      normalized_inventory_8  1
    z[8]      normalized_ratio_8  -0.1
    z[8]      scaled_stock_lower  1
    z[8]      scaled_stock_upper  1
    z[8]      old_TS1   1
    z[8]      old_TS2   1
    z[8]      old_TS3   1
    z[8]      old_TS4   1
    z[9]      normalized_inventory_9  1
    z[9]      normalized_ratio_9  -7.1428571428571425e-02
    z[9]      scaled_stock_lower  1
    z[9]      scaled_stock_upper  1
    z[9]      old_TS1   1
    z[9]      old_TS2   1
    z[9]      old_TS3   1
    z[9]      old_TS4   1
    z[10]     normalized_inventory_10  1
    z[10]     normalized_ratio_10  -1.1111111111111110e-01
    z[10]     scaled_stock_lower  1
    z[10]     scaled_stock_upper  1
    z[10]     old_TS1   1
    z[10]     old_TS2   1
    z[10]     old_TS3   1
    z[10]     old_TS4   1
    z[11]     normalized_inventory_11  1
    z[11]     normalized_ratio_11  -0.1
    z[11]     scaled_stock_lower  1
    z[11]     scaled_stock_upper  1
    z[11]     old_TS1   1
    z[11]     old_TS2   1
    z[11]     old_TS3   1
    z[11]     old_TS4   1
    z[12]     normalized_inventory_12  1
    z[12]     normalized_ratio_12  -8.3333333333333329e-02
    z[12]     scaled_stock_lower  1
    z[12]     scaled_stock_upper  1
    z[12]     old_TS1   1
    z[12]     old_TS2   1
    z[12]     old_TS3   1
    z[12]     old_TS4   1
    z[13]     normalized_inventory_13  1
    z[13]     normalized_ratio_13  -0.0625
    z[13]     scaled_stock_lower  1
    z[13]     scaled_stock_upper  1
    z[13]     old_TS1   1
    z[13]     old_TS2   1
    z[13]     old_TS3   1
    z[13]     old_TS4   1
    z[14]     normalized_inventory_14  1
    z[14]     normalized_ratio_14  -9.0909090909090912e-02
    z[14]     scaled_stock_lower  1
    z[14]     scaled_stock_upper  1
    z[14]     old_TS1   1
    z[14]     old_TS2   1
    z[14]     old_TS3   1
    z[14]     old_TS4   1
    z[15]     normalized_inventory_15  1
    z[15]     normalized_ratio_15  -9.0909090909090912e-02
    z[15]     scaled_stock_lower  1
    z[15]     scaled_stock_upper  1
    z[15]     old_TS1   1
    z[15]     old_TS2   1
    z[15]     old_TS3   1
    z[15]     old_TS4   1
    z[16]     normalized_inventory_16  1
    z[16]     normalized_ratio_16  -7.1428571428571425e-02
    z[16]     scaled_stock_lower  1
    z[16]     scaled_stock_upper  1
    z[16]     old_TS1   1
    z[16]     old_TS2   1
    z[16]     old_TS3   1
    z[16]     old_TS4   1
    z[17]     normalized_inventory_17  1
    z[17]     normalized_ratio_17  -1.1111111111111110e-01
    z[17]     scaled_stock_lower  1
    z[17]     scaled_stock_upper  1
    z[17]     old_TS1   1
    z[17]     old_TS2   1
    z[17]     old_TS3   1
    z[17]     old_TS4   1
    z[18]     normalized_inventory_18  1
    z[18]     normalized_ratio_18  -7.1428571428571425e-02
    z[18]     scaled_stock_lower  1
    z[18]     scaled_stock_upper  1
    z[18]     old_TS1   1
    z[18]     old_TS2   1
    z[18]     old_TS3   1
    z[18]     old_TS4   1
    z[19]     normalized_inventory_19  1
    z[19]     normalized_ratio_19  -8.3333333333333329e-02
    z[19]     scaled_stock_lower  1
    z[19]     scaled_stock_upper  1
    z[19]     old_TS1   1
    z[19]     old_TS2   1
    z[19]     old_TS3   1
    z[19]     old_TS4   1
    z[20]     normalized_inventory_20  1
    z[20]     normalized_ratio_20  -0.0625
    z[20]     scaled_stock_lower  1
    z[20]     scaled_stock_upper  1
    z[20]     old_TS1   1
    z[20]     old_TS2   1
    z[20]     old_TS3   1
    z[20]     old_TS4   1
    r[1]      normalized_ratio_1  1
    r[1]      normalization  1
    r[1]      abs_p_1_2  -1
    r[1]      abs_m_1_2  1
    r[1]      abs_p_1_3  -1
    r[1]      abs_m_1_3  1
    r[1]      abs_p_1_4  -1
    r[1]      abs_m_1_4  1
    r[1]      abs_p_1_5  -1
    r[1]      abs_m_1_5  1
    r[1]      abs_p_1_6  -1
    r[1]      abs_m_1_6  1
    r[1]      abs_p_1_7  -1
    r[1]      abs_m_1_7  1
    r[1]      abs_p_1_8  -1
    r[1]      abs_m_1_8  1
    r[1]      abs_p_1_9  -1
    r[1]      abs_m_1_9  1
    r[1]      abs_p_1_10  -1
    r[1]      abs_m_1_10  1
    r[1]      abs_p_1_11  -1
    r[1]      abs_m_1_11  1
    r[1]      abs_p_1_12  -1
    r[1]      abs_m_1_12  1
    r[1]      abs_p_1_13  -1
    r[1]      abs_m_1_13  1
    r[1]      abs_p_1_14  -1
    r[1]      abs_m_1_14  1
    r[1]      abs_p_1_15  -1
    r[1]      abs_m_1_15  1
    r[1]      abs_p_1_16  -1
    r[1]      abs_m_1_16  1
    r[1]      abs_p_1_17  -1
    r[1]      abs_m_1_17  1
    r[1]      abs_p_1_18  -1
    r[1]      abs_m_1_18  1
    r[1]      abs_p_1_19  -1
    r[1]      abs_m_1_19  1
    r[1]      abs_p_1_20  -1
    r[1]      abs_m_1_20  1
    r[2]      normalized_ratio_2  1
    r[2]      normalization  1
    r[2]      abs_p_1_2  1
    r[2]      abs_m_1_2  -1
    r[2]      abs_p_2_3  -1
    r[2]      abs_m_2_3  1
    r[2]      abs_p_2_4  -1
    r[2]      abs_m_2_4  1
    r[2]      abs_p_2_5  -1
    r[2]      abs_m_2_5  1
    r[2]      abs_p_2_6  -1
    r[2]      abs_m_2_6  1
    r[2]      abs_p_2_7  -1
    r[2]      abs_m_2_7  1
    r[2]      abs_p_2_8  -1
    r[2]      abs_m_2_8  1
    r[2]      abs_p_2_9  -1
    r[2]      abs_m_2_9  1
    r[2]      abs_p_2_10  -1
    r[2]      abs_m_2_10  1
    r[2]      abs_p_2_11  -1
    r[2]      abs_m_2_11  1
    r[2]      abs_p_2_12  -1
    r[2]      abs_m_2_12  1
    r[2]      abs_p_2_13  -1
    r[2]      abs_m_2_13  1
    r[2]      abs_p_2_14  -1
    r[2]      abs_m_2_14  1
    r[2]      abs_p_2_15  -1
    r[2]      abs_m_2_15  1
    r[2]      abs_p_2_16  -1
    r[2]      abs_m_2_16  1
    r[2]      abs_p_2_17  -1
    r[2]      abs_m_2_17  1
    r[2]      abs_p_2_18  -1
    r[2]      abs_m_2_18  1
    r[2]      abs_p_2_19  -1
    r[2]      abs_m_2_19  1
    r[2]      abs_p_2_20  -1
    r[2]      abs_m_2_20  1
    r[3]      normalized_ratio_3  1
    r[3]      normalization  1
    r[3]      abs_p_1_3  1
    r[3]      abs_m_1_3  -1
    r[3]      abs_p_2_3  1
    r[3]      abs_m_2_3  -1
    r[3]      abs_p_3_4  -1
    r[3]      abs_m_3_4  1
    r[3]      abs_p_3_5  -1
    r[3]      abs_m_3_5  1
    r[3]      abs_p_3_6  -1
    r[3]      abs_m_3_6  1
    r[3]      abs_p_3_7  -1
    r[3]      abs_m_3_7  1
    r[3]      abs_p_3_8  -1
    r[3]      abs_m_3_8  1
    r[3]      abs_p_3_9  -1
    r[3]      abs_m_3_9  1
    r[3]      abs_p_3_10  -1
    r[3]      abs_m_3_10  1
    r[3]      abs_p_3_11  -1
    r[3]      abs_m_3_11  1
    r[3]      abs_p_3_12  -1
    r[3]      abs_m_3_12  1
    r[3]      abs_p_3_13  -1
    r[3]      abs_m_3_13  1
    r[3]      abs_p_3_14  -1
    r[3]      abs_m_3_14  1
    r[3]      abs_p_3_15  -1
    r[3]      abs_m_3_15  1
    r[3]      abs_p_3_16  -1
    r[3]      abs_m_3_16  1
    r[3]      abs_p_3_17  -1
    r[3]      abs_m_3_17  1
    r[3]      abs_p_3_18  -1
    r[3]      abs_m_3_18  1
    r[3]      abs_p_3_19  -1
    r[3]      abs_m_3_19  1
    r[3]      abs_p_3_20  -1
    r[3]      abs_m_3_20  1
    r[4]      normalized_ratio_4  1
    r[4]      normalization  1
    r[4]      abs_p_1_4  1
    r[4]      abs_m_1_4  -1
    r[4]      abs_p_2_4  1
    r[4]      abs_m_2_4  -1
    r[4]      abs_p_3_4  1
    r[4]      abs_m_3_4  -1
    r[4]      abs_p_4_5  -1
    r[4]      abs_m_4_5  1
    r[4]      abs_p_4_6  -1
    r[4]      abs_m_4_6  1
    r[4]      abs_p_4_7  -1
    r[4]      abs_m_4_7  1
    r[4]      abs_p_4_8  -1
    r[4]      abs_m_4_8  1
    r[4]      abs_p_4_9  -1
    r[4]      abs_m_4_9  1
    r[4]      abs_p_4_10  -1
    r[4]      abs_m_4_10  1
    r[4]      abs_p_4_11  -1
    r[4]      abs_m_4_11  1
    r[4]      abs_p_4_12  -1
    r[4]      abs_m_4_12  1
    r[4]      abs_p_4_13  -1
    r[4]      abs_m_4_13  1
    r[4]      abs_p_4_14  -1
    r[4]      abs_m_4_14  1
    r[4]      abs_p_4_15  -1
    r[4]      abs_m_4_15  1
    r[4]      abs_p_4_16  -1
    r[4]      abs_m_4_16  1
    r[4]      abs_p_4_17  -1
    r[4]      abs_m_4_17  1
    r[4]      abs_p_4_18  -1
    r[4]      abs_m_4_18  1
    r[4]      abs_p_4_19  -1
    r[4]      abs_m_4_19  1
    r[4]      abs_p_4_20  -1
    r[4]      abs_m_4_20  1
    r[5]      normalized_ratio_5  1
    r[5]      normalization  1
    r[5]      abs_p_1_5  1
    r[5]      abs_m_1_5  -1
    r[5]      abs_p_2_5  1
    r[5]      abs_m_2_5  -1
    r[5]      abs_p_3_5  1
    r[5]      abs_m_3_5  -1
    r[5]      abs_p_4_5  1
    r[5]      abs_m_4_5  -1
    r[5]      abs_p_5_6  -1
    r[5]      abs_m_5_6  1
    r[5]      abs_p_5_7  -1
    r[5]      abs_m_5_7  1
    r[5]      abs_p_5_8  -1
    r[5]      abs_m_5_8  1
    r[5]      abs_p_5_9  -1
    r[5]      abs_m_5_9  1
    r[5]      abs_p_5_10  -1
    r[5]      abs_m_5_10  1
    r[5]      abs_p_5_11  -1
    r[5]      abs_m_5_11  1
    r[5]      abs_p_5_12  -1
    r[5]      abs_m_5_12  1
    r[5]      abs_p_5_13  -1
    r[5]      abs_m_5_13  1
    r[5]      abs_p_5_14  -1
    r[5]      abs_m_5_14  1
    r[5]      abs_p_5_15  -1
    r[5]      abs_m_5_15  1
    r[5]      abs_p_5_16  -1
    r[5]      abs_m_5_16  1
    r[5]      abs_p_5_17  -1
    r[5]      abs_m_5_17  1
    r[5]      abs_p_5_18  -1
    r[5]      abs_m_5_18  1
    r[5]      abs_p_5_19  -1
    r[5]      abs_m_5_19  1
    r[5]      abs_p_5_20  -1
    r[5]      abs_m_5_20  1
    r[6]      normalized_ratio_6  1
    r[6]      normalization  1
    r[6]      abs_p_1_6  1
    r[6]      abs_m_1_6  -1
    r[6]      abs_p_2_6  1
    r[6]      abs_m_2_6  -1
    r[6]      abs_p_3_6  1
    r[6]      abs_m_3_6  -1
    r[6]      abs_p_4_6  1
    r[6]      abs_m_4_6  -1
    r[6]      abs_p_5_6  1
    r[6]      abs_m_5_6  -1
    r[6]      abs_p_6_7  -1
    r[6]      abs_m_6_7  1
    r[6]      abs_p_6_8  -1
    r[6]      abs_m_6_8  1
    r[6]      abs_p_6_9  -1
    r[6]      abs_m_6_9  1
    r[6]      abs_p_6_10  -1
    r[6]      abs_m_6_10  1
    r[6]      abs_p_6_11  -1
    r[6]      abs_m_6_11  1
    r[6]      abs_p_6_12  -1
    r[6]      abs_m_6_12  1
    r[6]      abs_p_6_13  -1
    r[6]      abs_m_6_13  1
    r[6]      abs_p_6_14  -1
    r[6]      abs_m_6_14  1
    r[6]      abs_p_6_15  -1
    r[6]      abs_m_6_15  1
    r[6]      abs_p_6_16  -1
    r[6]      abs_m_6_16  1
    r[6]      abs_p_6_17  -1
    r[6]      abs_m_6_17  1
    r[6]      abs_p_6_18  -1
    r[6]      abs_m_6_18  1
    r[6]      abs_p_6_19  -1
    r[6]      abs_m_6_19  1
    r[6]      abs_p_6_20  -1
    r[6]      abs_m_6_20  1
    r[7]      normalized_ratio_7  1
    r[7]      normalization  1
    r[7]      abs_p_1_7  1
    r[7]      abs_m_1_7  -1
    r[7]      abs_p_2_7  1
    r[7]      abs_m_2_7  -1
    r[7]      abs_p_3_7  1
    r[7]      abs_m_3_7  -1
    r[7]      abs_p_4_7  1
    r[7]      abs_m_4_7  -1
    r[7]      abs_p_5_7  1
    r[7]      abs_m_5_7  -1
    r[7]      abs_p_6_7  1
    r[7]      abs_m_6_7  -1
    r[7]      abs_p_7_8  -1
    r[7]      abs_m_7_8  1
    r[7]      abs_p_7_9  -1
    r[7]      abs_m_7_9  1
    r[7]      abs_p_7_10  -1
    r[7]      abs_m_7_10  1
    r[7]      abs_p_7_11  -1
    r[7]      abs_m_7_11  1
    r[7]      abs_p_7_12  -1
    r[7]      abs_m_7_12  1
    r[7]      abs_p_7_13  -1
    r[7]      abs_m_7_13  1
    r[7]      abs_p_7_14  -1
    r[7]      abs_m_7_14  1
    r[7]      abs_p_7_15  -1
    r[7]      abs_m_7_15  1
    r[7]      abs_p_7_16  -1
    r[7]      abs_m_7_16  1
    r[7]      abs_p_7_17  -1
    r[7]      abs_m_7_17  1
    r[7]      abs_p_7_18  -1
    r[7]      abs_m_7_18  1
    r[7]      abs_p_7_19  -1
    r[7]      abs_m_7_19  1
    r[7]      abs_p_7_20  -1
    r[7]      abs_m_7_20  1
    r[8]      normalized_ratio_8  1
    r[8]      normalization  1
    r[8]      abs_p_1_8  1
    r[8]      abs_m_1_8  -1
    r[8]      abs_p_2_8  1
    r[8]      abs_m_2_8  -1
    r[8]      abs_p_3_8  1
    r[8]      abs_m_3_8  -1
    r[8]      abs_p_4_8  1
    r[8]      abs_m_4_8  -1
    r[8]      abs_p_5_8  1
    r[8]      abs_m_5_8  -1
    r[8]      abs_p_6_8  1
    r[8]      abs_m_6_8  -1
    r[8]      abs_p_7_8  1
    r[8]      abs_m_7_8  -1
    r[8]      abs_p_8_9  -1
    r[8]      abs_m_8_9  1
    r[8]      abs_p_8_10  -1
    r[8]      abs_m_8_10  1
    r[8]      abs_p_8_11  -1
    r[8]      abs_m_8_11  1
    r[8]      abs_p_8_12  -1
    r[8]      abs_m_8_12  1
    r[8]      abs_p_8_13  -1
    r[8]      abs_m_8_13  1
    r[8]      abs_p_8_14  -1
    r[8]      abs_m_8_14  1
    r[8]      abs_p_8_15  -1
    r[8]      abs_m_8_15  1
    r[8]      abs_p_8_16  -1
    r[8]      abs_m_8_16  1
    r[8]      abs_p_8_17  -1
    r[8]      abs_m_8_17  1
    r[8]      abs_p_8_18  -1
    r[8]      abs_m_8_18  1
    r[8]      abs_p_8_19  -1
    r[8]      abs_m_8_19  1
    r[8]      abs_p_8_20  -1
    r[8]      abs_m_8_20  1
    r[9]      normalized_ratio_9  1
    r[9]      normalization  1
    r[9]      abs_p_1_9  1
    r[9]      abs_m_1_9  -1
    r[9]      abs_p_2_9  1
    r[9]      abs_m_2_9  -1
    r[9]      abs_p_3_9  1
    r[9]      abs_m_3_9  -1
    r[9]      abs_p_4_9  1
    r[9]      abs_m_4_9  -1
    r[9]      abs_p_5_9  1
    r[9]      abs_m_5_9  -1
    r[9]      abs_p_6_9  1
    r[9]      abs_m_6_9  -1
    r[9]      abs_p_7_9  1
    r[9]      abs_m_7_9  -1
    r[9]      abs_p_8_9  1
    r[9]      abs_m_8_9  -1
    r[9]      abs_p_9_10  -1
    r[9]      abs_m_9_10  1
    r[9]      abs_p_9_11  -1
    r[9]      abs_m_9_11  1
    r[9]      abs_p_9_12  -1
    r[9]      abs_m_9_12  1
    r[9]      abs_p_9_13  -1
    r[9]      abs_m_9_13  1
    r[9]      abs_p_9_14  -1
    r[9]      abs_m_9_14  1
    r[9]      abs_p_9_15  -1
    r[9]      abs_m_9_15  1
    r[9]      abs_p_9_16  -1
    r[9]      abs_m_9_16  1
    r[9]      abs_p_9_17  -1
    r[9]      abs_m_9_17  1
    r[9]      abs_p_9_18  -1
    r[9]      abs_m_9_18  1
    r[9]      abs_p_9_19  -1
    r[9]      abs_m_9_19  1
    r[9]      abs_p_9_20  -1
    r[9]      abs_m_9_20  1
    r[10]     normalized_ratio_10  1
    r[10]     normalization  1
    r[10]     abs_p_1_10  1
    r[10]     abs_m_1_10  -1
    r[10]     abs_p_2_10  1
    r[10]     abs_m_2_10  -1
    r[10]     abs_p_3_10  1
    r[10]     abs_m_3_10  -1
    r[10]     abs_p_4_10  1
    r[10]     abs_m_4_10  -1
    r[10]     abs_p_5_10  1
    r[10]     abs_m_5_10  -1
    r[10]     abs_p_6_10  1
    r[10]     abs_m_6_10  -1
    r[10]     abs_p_7_10  1
    r[10]     abs_m_7_10  -1
    r[10]     abs_p_8_10  1
    r[10]     abs_m_8_10  -1
    r[10]     abs_p_9_10  1
    r[10]     abs_m_9_10  -1
    r[10]     abs_p_10_11  -1
    r[10]     abs_m_10_11  1
    r[10]     abs_p_10_12  -1
    r[10]     abs_m_10_12  1
    r[10]     abs_p_10_13  -1
    r[10]     abs_m_10_13  1
    r[10]     abs_p_10_14  -1
    r[10]     abs_m_10_14  1
    r[10]     abs_p_10_15  -1
    r[10]     abs_m_10_15  1
    r[10]     abs_p_10_16  -1
    r[10]     abs_m_10_16  1
    r[10]     abs_p_10_17  -1
    r[10]     abs_m_10_17  1
    r[10]     abs_p_10_18  -1
    r[10]     abs_m_10_18  1
    r[10]     abs_p_10_19  -1
    r[10]     abs_m_10_19  1
    r[10]     abs_p_10_20  -1
    r[10]     abs_m_10_20  1
    r[11]     normalized_ratio_11  1
    r[11]     normalization  1
    r[11]     abs_p_1_11  1
    r[11]     abs_m_1_11  -1
    r[11]     abs_p_2_11  1
    r[11]     abs_m_2_11  -1
    r[11]     abs_p_3_11  1
    r[11]     abs_m_3_11  -1
    r[11]     abs_p_4_11  1
    r[11]     abs_m_4_11  -1
    r[11]     abs_p_5_11  1
    r[11]     abs_m_5_11  -1
    r[11]     abs_p_6_11  1
    r[11]     abs_m_6_11  -1
    r[11]     abs_p_7_11  1
    r[11]     abs_m_7_11  -1
    r[11]     abs_p_8_11  1
    r[11]     abs_m_8_11  -1
    r[11]     abs_p_9_11  1
    r[11]     abs_m_9_11  -1
    r[11]     abs_p_10_11  1
    r[11]     abs_m_10_11  -1
    r[11]     abs_p_11_12  -1
    r[11]     abs_m_11_12  1
    r[11]     abs_p_11_13  -1
    r[11]     abs_m_11_13  1
    r[11]     abs_p_11_14  -1
    r[11]     abs_m_11_14  1
    r[11]     abs_p_11_15  -1
    r[11]     abs_m_11_15  1
    r[11]     abs_p_11_16  -1
    r[11]     abs_m_11_16  1
    r[11]     abs_p_11_17  -1
    r[11]     abs_m_11_17  1
    r[11]     abs_p_11_18  -1
    r[11]     abs_m_11_18  1
    r[11]     abs_p_11_19  -1
    r[11]     abs_m_11_19  1
    r[11]     abs_p_11_20  -1
    r[11]     abs_m_11_20  1
    r[12]     normalized_ratio_12  1
    r[12]     normalization  1
    r[12]     abs_p_1_12  1
    r[12]     abs_m_1_12  -1
    r[12]     abs_p_2_12  1
    r[12]     abs_m_2_12  -1
    r[12]     abs_p_3_12  1
    r[12]     abs_m_3_12  -1
    r[12]     abs_p_4_12  1
    r[12]     abs_m_4_12  -1
    r[12]     abs_p_5_12  1
    r[12]     abs_m_5_12  -1
    r[12]     abs_p_6_12  1
    r[12]     abs_m_6_12  -1
    r[12]     abs_p_7_12  1
    r[12]     abs_m_7_12  -1
    r[12]     abs_p_8_12  1
    r[12]     abs_m_8_12  -1
    r[12]     abs_p_9_12  1
    r[12]     abs_m_9_12  -1
    r[12]     abs_p_10_12  1
    r[12]     abs_m_10_12  -1
    r[12]     abs_p_11_12  1
    r[12]     abs_m_11_12  -1
    r[12]     abs_p_12_13  -1
    r[12]     abs_m_12_13  1
    r[12]     abs_p_12_14  -1
    r[12]     abs_m_12_14  1
    r[12]     abs_p_12_15  -1
    r[12]     abs_m_12_15  1
    r[12]     abs_p_12_16  -1
    r[12]     abs_m_12_16  1
    r[12]     abs_p_12_17  -1
    r[12]     abs_m_12_17  1
    r[12]     abs_p_12_18  -1
    r[12]     abs_m_12_18  1
    r[12]     abs_p_12_19  -1
    r[12]     abs_m_12_19  1
    r[12]     abs_p_12_20  -1
    r[12]     abs_m_12_20  1
    r[13]     normalized_ratio_13  1
    r[13]     normalization  1
    r[13]     abs_p_1_13  1
    r[13]     abs_m_1_13  -1
    r[13]     abs_p_2_13  1
    r[13]     abs_m_2_13  -1
    r[13]     abs_p_3_13  1
    r[13]     abs_m_3_13  -1
    r[13]     abs_p_4_13  1
    r[13]     abs_m_4_13  -1
    r[13]     abs_p_5_13  1
    r[13]     abs_m_5_13  -1
    r[13]     abs_p_6_13  1
    r[13]     abs_m_6_13  -1
    r[13]     abs_p_7_13  1
    r[13]     abs_m_7_13  -1
    r[13]     abs_p_8_13  1
    r[13]     abs_m_8_13  -1
    r[13]     abs_p_9_13  1
    r[13]     abs_m_9_13  -1
    r[13]     abs_p_10_13  1
    r[13]     abs_m_10_13  -1
    r[13]     abs_p_11_13  1
    r[13]     abs_m_11_13  -1
    r[13]     abs_p_12_13  1
    r[13]     abs_m_12_13  -1
    r[13]     abs_p_13_14  -1
    r[13]     abs_m_13_14  1
    r[13]     abs_p_13_15  -1
    r[13]     abs_m_13_15  1
    r[13]     abs_p_13_16  -1
    r[13]     abs_m_13_16  1
    r[13]     abs_p_13_17  -1
    r[13]     abs_m_13_17  1
    r[13]     abs_p_13_18  -1
    r[13]     abs_m_13_18  1
    r[13]     abs_p_13_19  -1
    r[13]     abs_m_13_19  1
    r[13]     abs_p_13_20  -1
    r[13]     abs_m_13_20  1
    r[14]     normalized_ratio_14  1
    r[14]     normalization  1
    r[14]     abs_p_1_14  1
    r[14]     abs_m_1_14  -1
    r[14]     abs_p_2_14  1
    r[14]     abs_m_2_14  -1
    r[14]     abs_p_3_14  1
    r[14]     abs_m_3_14  -1
    r[14]     abs_p_4_14  1
    r[14]     abs_m_4_14  -1
    r[14]     abs_p_5_14  1
    r[14]     abs_m_5_14  -1
    r[14]     abs_p_6_14  1
    r[14]     abs_m_6_14  -1
    r[14]     abs_p_7_14  1
    r[14]     abs_m_7_14  -1
    r[14]     abs_p_8_14  1
    r[14]     abs_m_8_14  -1
    r[14]     abs_p_9_14  1
    r[14]     abs_m_9_14  -1
    r[14]     abs_p_10_14  1
    r[14]     abs_m_10_14  -1
    r[14]     abs_p_11_14  1
    r[14]     abs_m_11_14  -1
    r[14]     abs_p_12_14  1
    r[14]     abs_m_12_14  -1
    r[14]     abs_p_13_14  1
    r[14]     abs_m_13_14  -1
    r[14]     abs_p_14_15  -1
    r[14]     abs_m_14_15  1
    r[14]     abs_p_14_16  -1
    r[14]     abs_m_14_16  1
    r[14]     abs_p_14_17  -1
    r[14]     abs_m_14_17  1
    r[14]     abs_p_14_18  -1
    r[14]     abs_m_14_18  1
    r[14]     abs_p_14_19  -1
    r[14]     abs_m_14_19  1
    r[14]     abs_p_14_20  -1
    r[14]     abs_m_14_20  1
    r[15]     normalized_ratio_15  1
    r[15]     normalization  1
    r[15]     abs_p_1_15  1
    r[15]     abs_m_1_15  -1
    r[15]     abs_p_2_15  1
    r[15]     abs_m_2_15  -1
    r[15]     abs_p_3_15  1
    r[15]     abs_m_3_15  -1
    r[15]     abs_p_4_15  1
    r[15]     abs_m_4_15  -1
    r[15]     abs_p_5_15  1
    r[15]     abs_m_5_15  -1
    r[15]     abs_p_6_15  1
    r[15]     abs_m_6_15  -1
    r[15]     abs_p_7_15  1
    r[15]     abs_m_7_15  -1
    r[15]     abs_p_8_15  1
    r[15]     abs_m_8_15  -1
    r[15]     abs_p_9_15  1
    r[15]     abs_m_9_15  -1
    r[15]     abs_p_10_15  1
    r[15]     abs_m_10_15  -1
    r[15]     abs_p_11_15  1
    r[15]     abs_m_11_15  -1
    r[15]     abs_p_12_15  1
    r[15]     abs_m_12_15  -1
    r[15]     abs_p_13_15  1
    r[15]     abs_m_13_15  -1
    r[15]     abs_p_14_15  1
    r[15]     abs_m_14_15  -1
    r[15]     abs_p_15_16  -1
    r[15]     abs_m_15_16  1
    r[15]     abs_p_15_17  -1
    r[15]     abs_m_15_17  1
    r[15]     abs_p_15_18  -1
    r[15]     abs_m_15_18  1
    r[15]     abs_p_15_19  -1
    r[15]     abs_m_15_19  1
    r[15]     abs_p_15_20  -1
    r[15]     abs_m_15_20  1
    r[16]     normalized_ratio_16  1
    r[16]     normalization  1
    r[16]     abs_p_1_16  1
    r[16]     abs_m_1_16  -1
    r[16]     abs_p_2_16  1
    r[16]     abs_m_2_16  -1
    r[16]     abs_p_3_16  1
    r[16]     abs_m_3_16  -1
    r[16]     abs_p_4_16  1
    r[16]     abs_m_4_16  -1
    r[16]     abs_p_5_16  1
    r[16]     abs_m_5_16  -1
    r[16]     abs_p_6_16  1
    r[16]     abs_m_6_16  -1
    r[16]     abs_p_7_16  1
    r[16]     abs_m_7_16  -1
    r[16]     abs_p_8_16  1
    r[16]     abs_m_8_16  -1
    r[16]     abs_p_9_16  1
    r[16]     abs_m_9_16  -1
    r[16]     abs_p_10_16  1
    r[16]     abs_m_10_16  -1
    r[16]     abs_p_11_16  1
    r[16]     abs_m_11_16  -1
    r[16]     abs_p_12_16  1
    r[16]     abs_m_12_16  -1
    r[16]     abs_p_13_16  1
    r[16]     abs_m_13_16  -1
    r[16]     abs_p_14_16  1
    r[16]     abs_m_14_16  -1
    r[16]     abs_p_15_16  1
    r[16]     abs_m_15_16  -1
    r[16]     abs_p_16_17  -1
    r[16]     abs_m_16_17  1
    r[16]     abs_p_16_18  -1
    r[16]     abs_m_16_18  1
    r[16]     abs_p_16_19  -1
    r[16]     abs_m_16_19  1
    r[16]     abs_p_16_20  -1
    r[16]     abs_m_16_20  1
    r[17]     normalized_ratio_17  1
    r[17]     normalization  1
    r[17]     abs_p_1_17  1
    r[17]     abs_m_1_17  -1
    r[17]     abs_p_2_17  1
    r[17]     abs_m_2_17  -1
    r[17]     abs_p_3_17  1
    r[17]     abs_m_3_17  -1
    r[17]     abs_p_4_17  1
    r[17]     abs_m_4_17  -1
    r[17]     abs_p_5_17  1
    r[17]     abs_m_5_17  -1
    r[17]     abs_p_6_17  1
    r[17]     abs_m_6_17  -1
    r[17]     abs_p_7_17  1
    r[17]     abs_m_7_17  -1
    r[17]     abs_p_8_17  1
    r[17]     abs_m_8_17  -1
    r[17]     abs_p_9_17  1
    r[17]     abs_m_9_17  -1
    r[17]     abs_p_10_17  1
    r[17]     abs_m_10_17  -1
    r[17]     abs_p_11_17  1
    r[17]     abs_m_11_17  -1
    r[17]     abs_p_12_17  1
    r[17]     abs_m_12_17  -1
    r[17]     abs_p_13_17  1
    r[17]     abs_m_13_17  -1
    r[17]     abs_p_14_17  1
    r[17]     abs_m_14_17  -1
    r[17]     abs_p_15_17  1
    r[17]     abs_m_15_17  -1
    r[17]     abs_p_16_17  1
    r[17]     abs_m_16_17  -1
    r[17]     abs_p_17_18  -1
    r[17]     abs_m_17_18  1
    r[17]     abs_p_17_19  -1
    r[17]     abs_m_17_19  1
    r[17]     abs_p_17_20  -1
    r[17]     abs_m_17_20  1
    r[18]     normalized_ratio_18  1
    r[18]     normalization  1
    r[18]     abs_p_1_18  1
    r[18]     abs_m_1_18  -1
    r[18]     abs_p_2_18  1
    r[18]     abs_m_2_18  -1
    r[18]     abs_p_3_18  1
    r[18]     abs_m_3_18  -1
    r[18]     abs_p_4_18  1
    r[18]     abs_m_4_18  -1
    r[18]     abs_p_5_18  1
    r[18]     abs_m_5_18  -1
    r[18]     abs_p_6_18  1
    r[18]     abs_m_6_18  -1
    r[18]     abs_p_7_18  1
    r[18]     abs_m_7_18  -1
    r[18]     abs_p_8_18  1
    r[18]     abs_m_8_18  -1
    r[18]     abs_p_9_18  1
    r[18]     abs_m_9_18  -1
    r[18]     abs_p_10_18  1
    r[18]     abs_m_10_18  -1
    r[18]     abs_p_11_18  1
    r[18]     abs_m_11_18  -1
    r[18]     abs_p_12_18  1
    r[18]     abs_m_12_18  -1
    r[18]     abs_p_13_18  1
    r[18]     abs_m_13_18  -1
    r[18]     abs_p_14_18  1
    r[18]     abs_m_14_18  -1
    r[18]     abs_p_15_18  1
    r[18]     abs_m_15_18  -1
    r[18]     abs_p_16_18  1
    r[18]     abs_m_16_18  -1
    r[18]     abs_p_17_18  1
    r[18]     abs_m_17_18  -1
    r[18]     abs_p_18_19  -1
    r[18]     abs_m_18_19  1
    r[18]     abs_p_18_20  -1
    r[18]     abs_m_18_20  1
    r[19]     normalized_ratio_19  1
    r[19]     normalization  1
    r[19]     abs_p_1_19  1
    r[19]     abs_m_1_19  -1
    r[19]     abs_p_2_19  1
    r[19]     abs_m_2_19  -1
    r[19]     abs_p_3_19  1
    r[19]     abs_m_3_19  -1
    r[19]     abs_p_4_19  1
    r[19]     abs_m_4_19  -1
    r[19]     abs_p_5_19  1
    r[19]     abs_m_5_19  -1
    r[19]     abs_p_6_19  1
    r[19]     abs_m_6_19  -1
    r[19]     abs_p_7_19  1
    r[19]     abs_m_7_19  -1
    r[19]     abs_p_8_19  1
    r[19]     abs_m_8_19  -1
    r[19]     abs_p_9_19  1
    r[19]     abs_m_9_19  -1
    r[19]     abs_p_10_19  1
    r[19]     abs_m_10_19  -1
    r[19]     abs_p_11_19  1
    r[19]     abs_m_11_19  -1
    r[19]     abs_p_12_19  1
    r[19]     abs_m_12_19  -1
    r[19]     abs_p_13_19  1
    r[19]     abs_m_13_19  -1
    r[19]     abs_p_14_19  1
    r[19]     abs_m_14_19  -1
    r[19]     abs_p_15_19  1
    r[19]     abs_m_15_19  -1
    r[19]     abs_p_16_19  1
    r[19]     abs_m_16_19  -1
    r[19]     abs_p_17_19  1
    r[19]     abs_m_17_19  -1
    r[19]     abs_p_18_19  1
    r[19]     abs_m_18_19  -1
    r[19]     abs_p_19_20  -1
    r[19]     abs_m_19_20  1
    r[20]     normalized_ratio_20  1
    r[20]     normalization  1
    r[20]     abs_p_1_20  1
    r[20]     abs_m_1_20  -1
    r[20]     abs_p_2_20  1
    r[20]     abs_m_2_20  -1
    r[20]     abs_p_3_20  1
    r[20]     abs_m_3_20  -1
    r[20]     abs_p_4_20  1
    r[20]     abs_m_4_20  -1
    r[20]     abs_p_5_20  1
    r[20]     abs_m_5_20  -1
    r[20]     abs_p_6_20  1
    r[20]     abs_m_6_20  -1
    r[20]     abs_p_7_20  1
    r[20]     abs_m_7_20  -1
    r[20]     abs_p_8_20  1
    r[20]     abs_m_8_20  -1
    r[20]     abs_p_9_20  1
    r[20]     abs_m_9_20  -1
    r[20]     abs_p_10_20  1
    r[20]     abs_m_10_20  -1
    r[20]     abs_p_11_20  1
    r[20]     abs_m_11_20  -1
    r[20]     abs_p_12_20  1
    r[20]     abs_m_12_20  -1
    r[20]     abs_p_13_20  1
    r[20]     abs_m_13_20  -1
    r[20]     abs_p_14_20  1
    r[20]     abs_m_14_20  -1
    r[20]     abs_p_15_20  1
    r[20]     abs_m_15_20  -1
    r[20]     abs_p_16_20  1
    r[20]     abs_m_16_20  -1
    r[20]     abs_p_17_20  1
    r[20]     abs_m_17_20  -1
    r[20]     abs_p_18_20  1
    r[20]     abs_m_18_20  -1
    r[20]     abs_p_19_20  1
    r[20]     abs_m_19_20  -1
    a[1,2]    abs_p_1_2  1
    a[1,2]    abs_m_1_2  1
    a[1,2]    true_G_epigraph  1
    a[1,2]    physical_G_upper  1
    a[1,2]    old_normalized_TC  1
    a[1,2]    old_normalized_TC2  1
    a[1,3]    abs_p_1_3  1
    a[1,3]    abs_m_1_3  1
    a[1,3]    true_G_epigraph  1
    a[1,3]    physical_G_upper  1
    a[1,3]    old_normalized_TC  1
    a[1,3]    old_normalized_TC2  1
    a[1,4]    abs_p_1_4  1
    a[1,4]    abs_m_1_4  1
    a[1,4]    true_G_epigraph  1
    a[1,4]    physical_G_upper  1
    a[1,4]    old_normalized_TC  1
    a[1,4]    old_normalized_TC2  1
    a[1,5]    abs_p_1_5  1
    a[1,5]    abs_m_1_5  1
    a[1,5]    true_G_epigraph  1
    a[1,5]    physical_G_upper  1
    a[1,5]    old_normalized_TC  1
    a[1,5]    old_normalized_TC2  1
    a[1,6]    abs_p_1_6  1
    a[1,6]    abs_m_1_6  1
    a[1,6]    true_G_epigraph  1
    a[1,6]    physical_G_upper  1
    a[1,6]    old_normalized_TC  1
    a[1,6]    old_normalized_TC2  1
    a[1,7]    abs_p_1_7  1
    a[1,7]    abs_m_1_7  1
    a[1,7]    true_G_epigraph  1
    a[1,7]    physical_G_upper  1
    a[1,7]    old_normalized_TC  1
    a[1,7]    old_normalized_TC2  1
    a[1,8]    abs_p_1_8  1
    a[1,8]    abs_m_1_8  1
    a[1,8]    true_G_epigraph  1
    a[1,8]    physical_G_upper  1
    a[1,8]    old_normalized_TC  1
    a[1,8]    old_normalized_TC2  1
    a[1,9]    abs_p_1_9  1
    a[1,9]    abs_m_1_9  1
    a[1,9]    true_G_epigraph  1
    a[1,9]    physical_G_upper  1
    a[1,9]    old_normalized_TC  1
    a[1,9]    old_normalized_TC2  1
    a[1,10]   abs_p_1_10  1
    a[1,10]   abs_m_1_10  1
    a[1,10]   true_G_epigraph  1
    a[1,10]   physical_G_upper  1
    a[1,10]   old_normalized_TC  1
    a[1,10]   old_normalized_TC2  1
    a[1,11]   abs_p_1_11  1
    a[1,11]   abs_m_1_11  1
    a[1,11]   true_G_epigraph  1
    a[1,11]   physical_G_upper  1
    a[1,11]   old_normalized_TC  1
    a[1,11]   old_normalized_TC2  1
    a[1,12]   abs_p_1_12  1
    a[1,12]   abs_m_1_12  1
    a[1,12]   true_G_epigraph  1
    a[1,12]   physical_G_upper  1
    a[1,12]   old_normalized_TC  1
    a[1,12]   old_normalized_TC2  1
    a[1,13]   abs_p_1_13  1
    a[1,13]   abs_m_1_13  1
    a[1,13]   true_G_epigraph  1
    a[1,13]   physical_G_upper  1
    a[1,13]   old_normalized_TC  1
    a[1,13]   old_normalized_TC2  1
    a[1,14]   abs_p_1_14  1
    a[1,14]   abs_m_1_14  1
    a[1,14]   true_G_epigraph  1
    a[1,14]   physical_G_upper  1
    a[1,14]   old_normalized_TC  1
    a[1,14]   old_normalized_TC2  1
    a[1,15]   abs_p_1_15  1
    a[1,15]   abs_m_1_15  1
    a[1,15]   true_G_epigraph  1
    a[1,15]   physical_G_upper  1
    a[1,15]   old_normalized_TC  1
    a[1,15]   old_normalized_TC2  1
    a[1,16]   abs_p_1_16  1
    a[1,16]   abs_m_1_16  1
    a[1,16]   true_G_epigraph  1
    a[1,16]   physical_G_upper  1
    a[1,16]   old_normalized_TC  1
    a[1,16]   old_normalized_TC2  1
    a[1,17]   abs_p_1_17  1
    a[1,17]   abs_m_1_17  1
    a[1,17]   true_G_epigraph  1
    a[1,17]   physical_G_upper  1
    a[1,17]   old_normalized_TC  1
    a[1,17]   old_normalized_TC2  1
    a[1,18]   abs_p_1_18  1
    a[1,18]   abs_m_1_18  1
    a[1,18]   true_G_epigraph  1
    a[1,18]   physical_G_upper  1
    a[1,18]   old_normalized_TC  1
    a[1,18]   old_normalized_TC2  1
    a[1,19]   abs_p_1_19  1
    a[1,19]   abs_m_1_19  1
    a[1,19]   true_G_epigraph  1
    a[1,19]   physical_G_upper  1
    a[1,19]   old_normalized_TC  1
    a[1,19]   old_normalized_TC2  1
    a[1,20]   abs_p_1_20  1
    a[1,20]   abs_m_1_20  1
    a[1,20]   true_G_epigraph  1
    a[1,20]   physical_G_upper  1
    a[1,20]   old_normalized_TC  1
    a[1,20]   old_normalized_TC2  1
    a[2,3]    abs_p_2_3  1
    a[2,3]    abs_m_2_3  1
    a[2,3]    true_G_epigraph  1
    a[2,3]    physical_G_upper  1
    a[2,3]    old_normalized_TC  1
    a[2,3]    old_normalized_TC2  1
    a[2,4]    abs_p_2_4  1
    a[2,4]    abs_m_2_4  1
    a[2,4]    true_G_epigraph  1
    a[2,4]    physical_G_upper  1
    a[2,4]    old_normalized_TC  1
    a[2,4]    old_normalized_TC2  1
    a[2,5]    abs_p_2_5  1
    a[2,5]    abs_m_2_5  1
    a[2,5]    true_G_epigraph  1
    a[2,5]    physical_G_upper  1
    a[2,5]    old_normalized_TC  1
    a[2,5]    old_normalized_TC2  1
    a[2,6]    abs_p_2_6  1
    a[2,6]    abs_m_2_6  1
    a[2,6]    true_G_epigraph  1
    a[2,6]    physical_G_upper  1
    a[2,6]    old_normalized_TC  1
    a[2,6]    old_normalized_TC2  1
    a[2,7]    abs_p_2_7  1
    a[2,7]    abs_m_2_7  1
    a[2,7]    true_G_epigraph  1
    a[2,7]    physical_G_upper  1
    a[2,7]    old_normalized_TC  1
    a[2,7]    old_normalized_TC2  1
    a[2,8]    abs_p_2_8  1
    a[2,8]    abs_m_2_8  1
    a[2,8]    true_G_epigraph  1
    a[2,8]    physical_G_upper  1
    a[2,8]    old_normalized_TC  1
    a[2,8]    old_normalized_TC2  1
    a[2,9]    abs_p_2_9  1
    a[2,9]    abs_m_2_9  1
    a[2,9]    true_G_epigraph  1
    a[2,9]    physical_G_upper  1
    a[2,9]    old_normalized_TC  1
    a[2,9]    old_normalized_TC2  1
    a[2,10]   abs_p_2_10  1
    a[2,10]   abs_m_2_10  1
    a[2,10]   true_G_epigraph  1
    a[2,10]   physical_G_upper  1
    a[2,10]   old_normalized_TC  1
    a[2,10]   old_normalized_TC2  1
    a[2,11]   abs_p_2_11  1
    a[2,11]   abs_m_2_11  1
    a[2,11]   true_G_epigraph  1
    a[2,11]   physical_G_upper  1
    a[2,11]   old_normalized_TC  1
    a[2,11]   old_normalized_TC2  1
    a[2,12]   abs_p_2_12  1
    a[2,12]   abs_m_2_12  1
    a[2,12]   true_G_epigraph  1
    a[2,12]   physical_G_upper  1
    a[2,12]   old_normalized_TC  1
    a[2,12]   old_normalized_TC2  1
    a[2,13]   abs_p_2_13  1
    a[2,13]   abs_m_2_13  1
    a[2,13]   true_G_epigraph  1
    a[2,13]   physical_G_upper  1
    a[2,13]   old_normalized_TC  1
    a[2,13]   old_normalized_TC2  1
    a[2,14]   abs_p_2_14  1
    a[2,14]   abs_m_2_14  1
    a[2,14]   true_G_epigraph  1
    a[2,14]   physical_G_upper  1
    a[2,14]   old_normalized_TC  1
    a[2,14]   old_normalized_TC2  1
    a[2,15]   abs_p_2_15  1
    a[2,15]   abs_m_2_15  1
    a[2,15]   true_G_epigraph  1
    a[2,15]   physical_G_upper  1
    a[2,15]   old_normalized_TC  1
    a[2,15]   old_normalized_TC2  1
    a[2,16]   abs_p_2_16  1
    a[2,16]   abs_m_2_16  1
    a[2,16]   true_G_epigraph  1
    a[2,16]   physical_G_upper  1
    a[2,16]   old_normalized_TC  1
    a[2,16]   old_normalized_TC2  1
    a[2,17]   abs_p_2_17  1
    a[2,17]   abs_m_2_17  1
    a[2,17]   true_G_epigraph  1
    a[2,17]   physical_G_upper  1
    a[2,17]   old_normalized_TC  1
    a[2,17]   old_normalized_TC2  1
    a[2,18]   abs_p_2_18  1
    a[2,18]   abs_m_2_18  1
    a[2,18]   true_G_epigraph  1
    a[2,18]   physical_G_upper  1
    a[2,18]   old_normalized_TC  1
    a[2,18]   old_normalized_TC2  1
    a[2,19]   abs_p_2_19  1
    a[2,19]   abs_m_2_19  1
    a[2,19]   true_G_epigraph  1
    a[2,19]   physical_G_upper  1
    a[2,19]   old_normalized_TC  1
    a[2,19]   old_normalized_TC2  1
    a[2,20]   abs_p_2_20  1
    a[2,20]   abs_m_2_20  1
    a[2,20]   true_G_epigraph  1
    a[2,20]   physical_G_upper  1
    a[2,20]   old_normalized_TC  1
    a[2,20]   old_normalized_TC2  1
    a[3,4]    abs_p_3_4  1
    a[3,4]    abs_m_3_4  1
    a[3,4]    true_G_epigraph  1
    a[3,4]    physical_G_upper  1
    a[3,4]    old_normalized_TC  1
    a[3,4]    old_normalized_TC2  1
    a[3,5]    abs_p_3_5  1
    a[3,5]    abs_m_3_5  1
    a[3,5]    true_G_epigraph  1
    a[3,5]    physical_G_upper  1
    a[3,5]    old_normalized_TC  1
    a[3,5]    old_normalized_TC2  1
    a[3,6]    abs_p_3_6  1
    a[3,6]    abs_m_3_6  1
    a[3,6]    true_G_epigraph  1
    a[3,6]    physical_G_upper  1
    a[3,6]    old_normalized_TC  1
    a[3,6]    old_normalized_TC2  1
    a[3,7]    abs_p_3_7  1
    a[3,7]    abs_m_3_7  1
    a[3,7]    true_G_epigraph  1
    a[3,7]    physical_G_upper  1
    a[3,7]    old_normalized_TC  1
    a[3,7]    old_normalized_TC2  1
    a[3,8]    abs_p_3_8  1
    a[3,8]    abs_m_3_8  1
    a[3,8]    true_G_epigraph  1
    a[3,8]    physical_G_upper  1
    a[3,8]    old_normalized_TC  1
    a[3,8]    old_normalized_TC2  1
    a[3,9]    abs_p_3_9  1
    a[3,9]    abs_m_3_9  1
    a[3,9]    true_G_epigraph  1
    a[3,9]    physical_G_upper  1
    a[3,9]    old_normalized_TC  1
    a[3,9]    old_normalized_TC2  1
    a[3,10]   abs_p_3_10  1
    a[3,10]   abs_m_3_10  1
    a[3,10]   true_G_epigraph  1
    a[3,10]   physical_G_upper  1
    a[3,10]   old_normalized_TC  1
    a[3,10]   old_normalized_TC2  1
    a[3,11]   abs_p_3_11  1
    a[3,11]   abs_m_3_11  1
    a[3,11]   true_G_epigraph  1
    a[3,11]   physical_G_upper  1
    a[3,11]   old_normalized_TC  1
    a[3,11]   old_normalized_TC2  1
    a[3,12]   abs_p_3_12  1
    a[3,12]   abs_m_3_12  1
    a[3,12]   true_G_epigraph  1
    a[3,12]   physical_G_upper  1
    a[3,12]   old_normalized_TC  1
    a[3,12]   old_normalized_TC2  1
    a[3,13]   abs_p_3_13  1
    a[3,13]   abs_m_3_13  1
    a[3,13]   true_G_epigraph  1
    a[3,13]   physical_G_upper  1
    a[3,13]   old_normalized_TC  1
    a[3,13]   old_normalized_TC2  1
    a[3,14]   abs_p_3_14  1
    a[3,14]   abs_m_3_14  1
    a[3,14]   true_G_epigraph  1
    a[3,14]   physical_G_upper  1
    a[3,14]   old_normalized_TC  1
    a[3,14]   old_normalized_TC2  1
    a[3,15]   abs_p_3_15  1
    a[3,15]   abs_m_3_15  1
    a[3,15]   true_G_epigraph  1
    a[3,15]   physical_G_upper  1
    a[3,15]   old_normalized_TC  1
    a[3,15]   old_normalized_TC2  1
    a[3,16]   abs_p_3_16  1
    a[3,16]   abs_m_3_16  1
    a[3,16]   true_G_epigraph  1
    a[3,16]   physical_G_upper  1
    a[3,16]   old_normalized_TC  1
    a[3,16]   old_normalized_TC2  1
    a[3,17]   abs_p_3_17  1
    a[3,17]   abs_m_3_17  1
    a[3,17]   true_G_epigraph  1
    a[3,17]   physical_G_upper  1
    a[3,17]   old_normalized_TC  1
    a[3,17]   old_normalized_TC2  1
    a[3,18]   abs_p_3_18  1
    a[3,18]   abs_m_3_18  1
    a[3,18]   true_G_epigraph  1
    a[3,18]   physical_G_upper  1
    a[3,18]   old_normalized_TC  1
    a[3,18]   old_normalized_TC2  1
    a[3,19]   abs_p_3_19  1
    a[3,19]   abs_m_3_19  1
    a[3,19]   true_G_epigraph  1
    a[3,19]   physical_G_upper  1
    a[3,19]   old_normalized_TC  1
    a[3,19]   old_normalized_TC2  1
    a[3,20]   abs_p_3_20  1
    a[3,20]   abs_m_3_20  1
    a[3,20]   true_G_epigraph  1
    a[3,20]   physical_G_upper  1
    a[3,20]   old_normalized_TC  1
    a[3,20]   old_normalized_TC2  1
    a[4,5]    abs_p_4_5  1
    a[4,5]    abs_m_4_5  1
    a[4,5]    true_G_epigraph  1
    a[4,5]    physical_G_upper  1
    a[4,5]    old_normalized_TC  1
    a[4,5]    old_normalized_TC2  1
    a[4,6]    abs_p_4_6  1
    a[4,6]    abs_m_4_6  1
    a[4,6]    true_G_epigraph  1
    a[4,6]    physical_G_upper  1
    a[4,6]    old_normalized_TC  1
    a[4,6]    old_normalized_TC2  1
    a[4,7]    abs_p_4_7  1
    a[4,7]    abs_m_4_7  1
    a[4,7]    true_G_epigraph  1
    a[4,7]    physical_G_upper  1
    a[4,7]    old_normalized_TC  1
    a[4,7]    old_normalized_TC2  1
    a[4,8]    abs_p_4_8  1
    a[4,8]    abs_m_4_8  1
    a[4,8]    true_G_epigraph  1
    a[4,8]    physical_G_upper  1
    a[4,8]    old_normalized_TC  1
    a[4,8]    old_normalized_TC2  1
    a[4,9]    abs_p_4_9  1
    a[4,9]    abs_m_4_9  1
    a[4,9]    true_G_epigraph  1
    a[4,9]    physical_G_upper  1
    a[4,9]    old_normalized_TC  1
    a[4,9]    old_normalized_TC2  1
    a[4,10]   abs_p_4_10  1
    a[4,10]   abs_m_4_10  1
    a[4,10]   true_G_epigraph  1
    a[4,10]   physical_G_upper  1
    a[4,10]   old_normalized_TC  1
    a[4,10]   old_normalized_TC2  1
    a[4,11]   abs_p_4_11  1
    a[4,11]   abs_m_4_11  1
    a[4,11]   true_G_epigraph  1
    a[4,11]   physical_G_upper  1
    a[4,11]   old_normalized_TC  1
    a[4,11]   old_normalized_TC2  1
    a[4,12]   abs_p_4_12  1
    a[4,12]   abs_m_4_12  1
    a[4,12]   true_G_epigraph  1
    a[4,12]   physical_G_upper  1
    a[4,12]   old_normalized_TC  1
    a[4,12]   old_normalized_TC2  1
    a[4,13]   abs_p_4_13  1
    a[4,13]   abs_m_4_13  1
    a[4,13]   true_G_epigraph  1
    a[4,13]   physical_G_upper  1
    a[4,13]   old_normalized_TC  1
    a[4,13]   old_normalized_TC2  1
    a[4,14]   abs_p_4_14  1
    a[4,14]   abs_m_4_14  1
    a[4,14]   true_G_epigraph  1
    a[4,14]   physical_G_upper  1
    a[4,14]   old_normalized_TC  1
    a[4,14]   old_normalized_TC2  1
    a[4,15]   abs_p_4_15  1
    a[4,15]   abs_m_4_15  1
    a[4,15]   true_G_epigraph  1
    a[4,15]   physical_G_upper  1
    a[4,15]   old_normalized_TC  1
    a[4,15]   old_normalized_TC2  1
    a[4,16]   abs_p_4_16  1
    a[4,16]   abs_m_4_16  1
    a[4,16]   true_G_epigraph  1
    a[4,16]   physical_G_upper  1
    a[4,16]   old_normalized_TC  1
    a[4,16]   old_normalized_TC2  1
    a[4,17]   abs_p_4_17  1
    a[4,17]   abs_m_4_17  1
    a[4,17]   true_G_epigraph  1
    a[4,17]   physical_G_upper  1
    a[4,17]   old_normalized_TC  1
    a[4,17]   old_normalized_TC2  1
    a[4,18]   abs_p_4_18  1
    a[4,18]   abs_m_4_18  1
    a[4,18]   true_G_epigraph  1
    a[4,18]   physical_G_upper  1
    a[4,18]   old_normalized_TC  1
    a[4,18]   old_normalized_TC2  1
    a[4,19]   abs_p_4_19  1
    a[4,19]   abs_m_4_19  1
    a[4,19]   true_G_epigraph  1
    a[4,19]   physical_G_upper  1
    a[4,19]   old_normalized_TC  1
    a[4,19]   old_normalized_TC2  1
    a[4,20]   abs_p_4_20  1
    a[4,20]   abs_m_4_20  1
    a[4,20]   true_G_epigraph  1
    a[4,20]   physical_G_upper  1
    a[4,20]   old_normalized_TC  1
    a[4,20]   old_normalized_TC2  1
    a[5,6]    abs_p_5_6  1
    a[5,6]    abs_m_5_6  1
    a[5,6]    true_G_epigraph  1
    a[5,6]    physical_G_upper  1
    a[5,6]    old_normalized_TC  1
    a[5,6]    old_normalized_TC2  1
    a[5,7]    abs_p_5_7  1
    a[5,7]    abs_m_5_7  1
    a[5,7]    true_G_epigraph  1
    a[5,7]    physical_G_upper  1
    a[5,7]    old_normalized_TC  1
    a[5,7]    old_normalized_TC2  1
    a[5,8]    abs_p_5_8  1
    a[5,8]    abs_m_5_8  1
    a[5,8]    true_G_epigraph  1
    a[5,8]    physical_G_upper  1
    a[5,8]    old_normalized_TC  1
    a[5,8]    old_normalized_TC2  1
    a[5,9]    abs_p_5_9  1
    a[5,9]    abs_m_5_9  1
    a[5,9]    true_G_epigraph  1
    a[5,9]    physical_G_upper  1
    a[5,9]    old_normalized_TC  1
    a[5,9]    old_normalized_TC2  1
    a[5,10]   abs_p_5_10  1
    a[5,10]   abs_m_5_10  1
    a[5,10]   true_G_epigraph  1
    a[5,10]   physical_G_upper  1
    a[5,10]   old_normalized_TC  1
    a[5,10]   old_normalized_TC2  1
    a[5,11]   abs_p_5_11  1
    a[5,11]   abs_m_5_11  1
    a[5,11]   true_G_epigraph  1
    a[5,11]   physical_G_upper  1
    a[5,11]   old_normalized_TC  1
    a[5,11]   old_normalized_TC2  1
    a[5,12]   abs_p_5_12  1
    a[5,12]   abs_m_5_12  1
    a[5,12]   true_G_epigraph  1
    a[5,12]   physical_G_upper  1
    a[5,12]   old_normalized_TC  1
    a[5,12]   old_normalized_TC2  1
    a[5,13]   abs_p_5_13  1
    a[5,13]   abs_m_5_13  1
    a[5,13]   true_G_epigraph  1
    a[5,13]   physical_G_upper  1
    a[5,13]   old_normalized_TC  1
    a[5,13]   old_normalized_TC2  1
    a[5,14]   abs_p_5_14  1
    a[5,14]   abs_m_5_14  1
    a[5,14]   true_G_epigraph  1
    a[5,14]   physical_G_upper  1
    a[5,14]   old_normalized_TC  1
    a[5,14]   old_normalized_TC2  1
    a[5,15]   abs_p_5_15  1
    a[5,15]   abs_m_5_15  1
    a[5,15]   true_G_epigraph  1
    a[5,15]   physical_G_upper  1
    a[5,15]   old_normalized_TC  1
    a[5,15]   old_normalized_TC2  1
    a[5,16]   abs_p_5_16  1
    a[5,16]   abs_m_5_16  1
    a[5,16]   true_G_epigraph  1
    a[5,16]   physical_G_upper  1
    a[5,16]   old_normalized_TC  1
    a[5,16]   old_normalized_TC2  1
    a[5,17]   abs_p_5_17  1
    a[5,17]   abs_m_5_17  1
    a[5,17]   true_G_epigraph  1
    a[5,17]   physical_G_upper  1
    a[5,17]   old_normalized_TC  1
    a[5,17]   old_normalized_TC2  1
    a[5,18]   abs_p_5_18  1
    a[5,18]   abs_m_5_18  1
    a[5,18]   true_G_epigraph  1
    a[5,18]   physical_G_upper  1
    a[5,18]   old_normalized_TC  1
    a[5,18]   old_normalized_TC2  1
    a[5,19]   abs_p_5_19  1
    a[5,19]   abs_m_5_19  1
    a[5,19]   true_G_epigraph  1
    a[5,19]   physical_G_upper  1
    a[5,19]   old_normalized_TC  1
    a[5,19]   old_normalized_TC2  1
    a[5,20]   abs_p_5_20  1
    a[5,20]   abs_m_5_20  1
    a[5,20]   true_G_epigraph  1
    a[5,20]   physical_G_upper  1
    a[5,20]   old_normalized_TC  1
    a[5,20]   old_normalized_TC2  1
    a[6,7]    abs_p_6_7  1
    a[6,7]    abs_m_6_7  1
    a[6,7]    true_G_epigraph  1
    a[6,7]    physical_G_upper  1
    a[6,7]    old_normalized_TC  1
    a[6,7]    old_normalized_TC2  1
    a[6,8]    abs_p_6_8  1
    a[6,8]    abs_m_6_8  1
    a[6,8]    true_G_epigraph  1
    a[6,8]    physical_G_upper  1
    a[6,8]    old_normalized_TC  1
    a[6,8]    old_normalized_TC2  1
    a[6,9]    abs_p_6_9  1
    a[6,9]    abs_m_6_9  1
    a[6,9]    true_G_epigraph  1
    a[6,9]    physical_G_upper  1
    a[6,9]    old_normalized_TC  1
    a[6,9]    old_normalized_TC2  1
    a[6,10]   abs_p_6_10  1
    a[6,10]   abs_m_6_10  1
    a[6,10]   true_G_epigraph  1
    a[6,10]   physical_G_upper  1
    a[6,10]   old_normalized_TC  1
    a[6,10]   old_normalized_TC2  1
    a[6,11]   abs_p_6_11  1
    a[6,11]   abs_m_6_11  1
    a[6,11]   true_G_epigraph  1
    a[6,11]   physical_G_upper  1
    a[6,11]   old_normalized_TC  1
    a[6,11]   old_normalized_TC2  1
    a[6,12]   abs_p_6_12  1
    a[6,12]   abs_m_6_12  1
    a[6,12]   true_G_epigraph  1
    a[6,12]   physical_G_upper  1
    a[6,12]   old_normalized_TC  1
    a[6,12]   old_normalized_TC2  1
    a[6,13]   abs_p_6_13  1
    a[6,13]   abs_m_6_13  1
    a[6,13]   true_G_epigraph  1
    a[6,13]   physical_G_upper  1
    a[6,13]   old_normalized_TC  1
    a[6,13]   old_normalized_TC2  1
    a[6,14]   abs_p_6_14  1
    a[6,14]   abs_m_6_14  1
    a[6,14]   true_G_epigraph  1
    a[6,14]   physical_G_upper  1
    a[6,14]   old_normalized_TC  1
    a[6,14]   old_normalized_TC2  1
    a[6,15]   abs_p_6_15  1
    a[6,15]   abs_m_6_15  1
    a[6,15]   true_G_epigraph  1
    a[6,15]   physical_G_upper  1
    a[6,15]   old_normalized_TC  1
    a[6,15]   old_normalized_TC2  1
    a[6,16]   abs_p_6_16  1
    a[6,16]   abs_m_6_16  1
    a[6,16]   true_G_epigraph  1
    a[6,16]   physical_G_upper  1
    a[6,16]   old_normalized_TC  1
    a[6,16]   old_normalized_TC2  1
    a[6,17]   abs_p_6_17  1
    a[6,17]   abs_m_6_17  1
    a[6,17]   true_G_epigraph  1
    a[6,17]   physical_G_upper  1
    a[6,17]   old_normalized_TC  1
    a[6,17]   old_normalized_TC2  1
    a[6,18]   abs_p_6_18  1
    a[6,18]   abs_m_6_18  1
    a[6,18]   true_G_epigraph  1
    a[6,18]   physical_G_upper  1
    a[6,18]   old_normalized_TC  1
    a[6,18]   old_normalized_TC2  1
    a[6,19]   abs_p_6_19  1
    a[6,19]   abs_m_6_19  1
    a[6,19]   true_G_epigraph  1
    a[6,19]   physical_G_upper  1
    a[6,19]   old_normalized_TC  1
    a[6,19]   old_normalized_TC2  1
    a[6,20]   abs_p_6_20  1
    a[6,20]   abs_m_6_20  1
    a[6,20]   true_G_epigraph  1
    a[6,20]   physical_G_upper  1
    a[6,20]   old_normalized_TC  1
    a[6,20]   old_normalized_TC2  1
    a[7,8]    abs_p_7_8  1
    a[7,8]    abs_m_7_8  1
    a[7,8]    true_G_epigraph  1
    a[7,8]    physical_G_upper  1
    a[7,8]    old_normalized_TC  1
    a[7,8]    old_normalized_TC2  1
    a[7,9]    abs_p_7_9  1
    a[7,9]    abs_m_7_9  1
    a[7,9]    true_G_epigraph  1
    a[7,9]    physical_G_upper  1
    a[7,9]    old_normalized_TC  1
    a[7,9]    old_normalized_TC2  1
    a[7,10]   abs_p_7_10  1
    a[7,10]   abs_m_7_10  1
    a[7,10]   true_G_epigraph  1
    a[7,10]   physical_G_upper  1
    a[7,10]   old_normalized_TC  1
    a[7,10]   old_normalized_TC2  1
    a[7,11]   abs_p_7_11  1
    a[7,11]   abs_m_7_11  1
    a[7,11]   true_G_epigraph  1
    a[7,11]   physical_G_upper  1
    a[7,11]   old_normalized_TC  1
    a[7,11]   old_normalized_TC2  1
    a[7,12]   abs_p_7_12  1
    a[7,12]   abs_m_7_12  1
    a[7,12]   true_G_epigraph  1
    a[7,12]   physical_G_upper  1
    a[7,12]   old_normalized_TC  1
    a[7,12]   old_normalized_TC2  1
    a[7,13]   abs_p_7_13  1
    a[7,13]   abs_m_7_13  1
    a[7,13]   true_G_epigraph  1
    a[7,13]   physical_G_upper  1
    a[7,13]   old_normalized_TC  1
    a[7,13]   old_normalized_TC2  1
    a[7,14]   abs_p_7_14  1
    a[7,14]   abs_m_7_14  1
    a[7,14]   true_G_epigraph  1
    a[7,14]   physical_G_upper  1
    a[7,14]   old_normalized_TC  1
    a[7,14]   old_normalized_TC2  1
    a[7,15]   abs_p_7_15  1
    a[7,15]   abs_m_7_15  1
    a[7,15]   true_G_epigraph  1
    a[7,15]   physical_G_upper  1
    a[7,15]   old_normalized_TC  1
    a[7,15]   old_normalized_TC2  1
    a[7,16]   abs_p_7_16  1
    a[7,16]   abs_m_7_16  1
    a[7,16]   true_G_epigraph  1
    a[7,16]   physical_G_upper  1
    a[7,16]   old_normalized_TC  1
    a[7,16]   old_normalized_TC2  1
    a[7,17]   abs_p_7_17  1
    a[7,17]   abs_m_7_17  1
    a[7,17]   true_G_epigraph  1
    a[7,17]   physical_G_upper  1
    a[7,17]   old_normalized_TC  1
    a[7,17]   old_normalized_TC2  1
    a[7,18]   abs_p_7_18  1
    a[7,18]   abs_m_7_18  1
    a[7,18]   true_G_epigraph  1
    a[7,18]   physical_G_upper  1
    a[7,18]   old_normalized_TC  1
    a[7,18]   old_normalized_TC2  1
    a[7,19]   abs_p_7_19  1
    a[7,19]   abs_m_7_19  1
    a[7,19]   true_G_epigraph  1
    a[7,19]   physical_G_upper  1
    a[7,19]   old_normalized_TC  1
    a[7,19]   old_normalized_TC2  1
    a[7,20]   abs_p_7_20  1
    a[7,20]   abs_m_7_20  1
    a[7,20]   true_G_epigraph  1
    a[7,20]   physical_G_upper  1
    a[7,20]   old_normalized_TC  1
    a[7,20]   old_normalized_TC2  1
    a[8,9]    abs_p_8_9  1
    a[8,9]    abs_m_8_9  1
    a[8,9]    true_G_epigraph  1
    a[8,9]    physical_G_upper  1
    a[8,9]    old_normalized_TC  1
    a[8,9]    old_normalized_TC2  1
    a[8,10]   abs_p_8_10  1
    a[8,10]   abs_m_8_10  1
    a[8,10]   true_G_epigraph  1
    a[8,10]   physical_G_upper  1
    a[8,10]   old_normalized_TC  1
    a[8,10]   old_normalized_TC2  1
    a[8,11]   abs_p_8_11  1
    a[8,11]   abs_m_8_11  1
    a[8,11]   true_G_epigraph  1
    a[8,11]   physical_G_upper  1
    a[8,11]   old_normalized_TC  1
    a[8,11]   old_normalized_TC2  1
    a[8,12]   abs_p_8_12  1
    a[8,12]   abs_m_8_12  1
    a[8,12]   true_G_epigraph  1
    a[8,12]   physical_G_upper  1
    a[8,12]   old_normalized_TC  1
    a[8,12]   old_normalized_TC2  1
    a[8,13]   abs_p_8_13  1
    a[8,13]   abs_m_8_13  1
    a[8,13]   true_G_epigraph  1
    a[8,13]   physical_G_upper  1
    a[8,13]   old_normalized_TC  1
    a[8,13]   old_normalized_TC2  1
    a[8,14]   abs_p_8_14  1
    a[8,14]   abs_m_8_14  1
    a[8,14]   true_G_epigraph  1
    a[8,14]   physical_G_upper  1
    a[8,14]   old_normalized_TC  1
    a[8,14]   old_normalized_TC2  1
    a[8,15]   abs_p_8_15  1
    a[8,15]   abs_m_8_15  1
    a[8,15]   true_G_epigraph  1
    a[8,15]   physical_G_upper  1
    a[8,15]   old_normalized_TC  1
    a[8,15]   old_normalized_TC2  1
    a[8,16]   abs_p_8_16  1
    a[8,16]   abs_m_8_16  1
    a[8,16]   true_G_epigraph  1
    a[8,16]   physical_G_upper  1
    a[8,16]   old_normalized_TC  1
    a[8,16]   old_normalized_TC2  1
    a[8,17]   abs_p_8_17  1
    a[8,17]   abs_m_8_17  1
    a[8,17]   true_G_epigraph  1
    a[8,17]   physical_G_upper  1
    a[8,17]   old_normalized_TC  1
    a[8,17]   old_normalized_TC2  1
    a[8,18]   abs_p_8_18  1
    a[8,18]   abs_m_8_18  1
    a[8,18]   true_G_epigraph  1
    a[8,18]   physical_G_upper  1
    a[8,18]   old_normalized_TC  1
    a[8,18]   old_normalized_TC2  1
    a[8,19]   abs_p_8_19  1
    a[8,19]   abs_m_8_19  1
    a[8,19]   true_G_epigraph  1
    a[8,19]   physical_G_upper  1
    a[8,19]   old_normalized_TC  1
    a[8,19]   old_normalized_TC2  1
    a[8,20]   abs_p_8_20  1
    a[8,20]   abs_m_8_20  1
    a[8,20]   true_G_epigraph  1
    a[8,20]   physical_G_upper  1
    a[8,20]   old_normalized_TC  1
    a[8,20]   old_normalized_TC2  1
    a[9,10]   abs_p_9_10  1
    a[9,10]   abs_m_9_10  1
    a[9,10]   true_G_epigraph  1
    a[9,10]   physical_G_upper  1
    a[9,10]   old_normalized_TC  1
    a[9,10]   old_normalized_TC2  1
    a[9,11]   abs_p_9_11  1
    a[9,11]   abs_m_9_11  1
    a[9,11]   true_G_epigraph  1
    a[9,11]   physical_G_upper  1
    a[9,11]   old_normalized_TC  1
    a[9,11]   old_normalized_TC2  1
    a[9,12]   abs_p_9_12  1
    a[9,12]   abs_m_9_12  1
    a[9,12]   true_G_epigraph  1
    a[9,12]   physical_G_upper  1
    a[9,12]   old_normalized_TC  1
    a[9,12]   old_normalized_TC2  1
    a[9,13]   abs_p_9_13  1
    a[9,13]   abs_m_9_13  1
    a[9,13]   true_G_epigraph  1
    a[9,13]   physical_G_upper  1
    a[9,13]   old_normalized_TC  1
    a[9,13]   old_normalized_TC2  1
    a[9,14]   abs_p_9_14  1
    a[9,14]   abs_m_9_14  1
    a[9,14]   true_G_epigraph  1
    a[9,14]   physical_G_upper  1
    a[9,14]   old_normalized_TC  1
    a[9,14]   old_normalized_TC2  1
    a[9,15]   abs_p_9_15  1
    a[9,15]   abs_m_9_15  1
    a[9,15]   true_G_epigraph  1
    a[9,15]   physical_G_upper  1
    a[9,15]   old_normalized_TC  1
    a[9,15]   old_normalized_TC2  1
    a[9,16]   abs_p_9_16  1
    a[9,16]   abs_m_9_16  1
    a[9,16]   true_G_epigraph  1
    a[9,16]   physical_G_upper  1
    a[9,16]   old_normalized_TC  1
    a[9,16]   old_normalized_TC2  1
    a[9,17]   abs_p_9_17  1
    a[9,17]   abs_m_9_17  1
    a[9,17]   true_G_epigraph  1
    a[9,17]   physical_G_upper  1
    a[9,17]   old_normalized_TC  1
    a[9,17]   old_normalized_TC2  1
    a[9,18]   abs_p_9_18  1
    a[9,18]   abs_m_9_18  1
    a[9,18]   true_G_epigraph  1
    a[9,18]   physical_G_upper  1
    a[9,18]   old_normalized_TC  1
    a[9,18]   old_normalized_TC2  1
    a[9,19]   abs_p_9_19  1
    a[9,19]   abs_m_9_19  1
    a[9,19]   true_G_epigraph  1
    a[9,19]   physical_G_upper  1
    a[9,19]   old_normalized_TC  1
    a[9,19]   old_normalized_TC2  1
    a[9,20]   abs_p_9_20  1
    a[9,20]   abs_m_9_20  1
    a[9,20]   true_G_epigraph  1
    a[9,20]   physical_G_upper  1
    a[9,20]   old_normalized_TC  1
    a[9,20]   old_normalized_TC2  1
    a[10,11]  abs_p_10_11  1
    a[10,11]  abs_m_10_11  1
    a[10,11]  true_G_epigraph  1
    a[10,11]  physical_G_upper  1
    a[10,11]  old_normalized_TC  1
    a[10,11]  old_normalized_TC2  1
    a[10,12]  abs_p_10_12  1
    a[10,12]  abs_m_10_12  1
    a[10,12]  true_G_epigraph  1
    a[10,12]  physical_G_upper  1
    a[10,12]  old_normalized_TC  1
    a[10,12]  old_normalized_TC2  1
    a[10,13]  abs_p_10_13  1
    a[10,13]  abs_m_10_13  1
    a[10,13]  true_G_epigraph  1
    a[10,13]  physical_G_upper  1
    a[10,13]  old_normalized_TC  1
    a[10,13]  old_normalized_TC2  1
    a[10,14]  abs_p_10_14  1
    a[10,14]  abs_m_10_14  1
    a[10,14]  true_G_epigraph  1
    a[10,14]  physical_G_upper  1
    a[10,14]  old_normalized_TC  1
    a[10,14]  old_normalized_TC2  1
    a[10,15]  abs_p_10_15  1
    a[10,15]  abs_m_10_15  1
    a[10,15]  true_G_epigraph  1
    a[10,15]  physical_G_upper  1
    a[10,15]  old_normalized_TC  1
    a[10,15]  old_normalized_TC2  1
    a[10,16]  abs_p_10_16  1
    a[10,16]  abs_m_10_16  1
    a[10,16]  true_G_epigraph  1
    a[10,16]  physical_G_upper  1
    a[10,16]  old_normalized_TC  1
    a[10,16]  old_normalized_TC2  1
    a[10,17]  abs_p_10_17  1
    a[10,17]  abs_m_10_17  1
    a[10,17]  true_G_epigraph  1
    a[10,17]  physical_G_upper  1
    a[10,17]  old_normalized_TC  1
    a[10,17]  old_normalized_TC2  1
    a[10,18]  abs_p_10_18  1
    a[10,18]  abs_m_10_18  1
    a[10,18]  true_G_epigraph  1
    a[10,18]  physical_G_upper  1
    a[10,18]  old_normalized_TC  1
    a[10,18]  old_normalized_TC2  1
    a[10,19]  abs_p_10_19  1
    a[10,19]  abs_m_10_19  1
    a[10,19]  true_G_epigraph  1
    a[10,19]  physical_G_upper  1
    a[10,19]  old_normalized_TC  1
    a[10,19]  old_normalized_TC2  1
    a[10,20]  abs_p_10_20  1
    a[10,20]  abs_m_10_20  1
    a[10,20]  true_G_epigraph  1
    a[10,20]  physical_G_upper  1
    a[10,20]  old_normalized_TC  1
    a[10,20]  old_normalized_TC2  1
    a[11,12]  abs_p_11_12  1
    a[11,12]  abs_m_11_12  1
    a[11,12]  true_G_epigraph  1
    a[11,12]  physical_G_upper  1
    a[11,12]  old_normalized_TC  1
    a[11,12]  old_normalized_TC2  1
    a[11,13]  abs_p_11_13  1
    a[11,13]  abs_m_11_13  1
    a[11,13]  true_G_epigraph  1
    a[11,13]  physical_G_upper  1
    a[11,13]  old_normalized_TC  1
    a[11,13]  old_normalized_TC2  1
    a[11,14]  abs_p_11_14  1
    a[11,14]  abs_m_11_14  1
    a[11,14]  true_G_epigraph  1
    a[11,14]  physical_G_upper  1
    a[11,14]  old_normalized_TC  1
    a[11,14]  old_normalized_TC2  1
    a[11,15]  abs_p_11_15  1
    a[11,15]  abs_m_11_15  1
    a[11,15]  true_G_epigraph  1
    a[11,15]  physical_G_upper  1
    a[11,15]  old_normalized_TC  1
    a[11,15]  old_normalized_TC2  1
    a[11,16]  abs_p_11_16  1
    a[11,16]  abs_m_11_16  1
    a[11,16]  true_G_epigraph  1
    a[11,16]  physical_G_upper  1
    a[11,16]  old_normalized_TC  1
    a[11,16]  old_normalized_TC2  1
    a[11,17]  abs_p_11_17  1
    a[11,17]  abs_m_11_17  1
    a[11,17]  true_G_epigraph  1
    a[11,17]  physical_G_upper  1
    a[11,17]  old_normalized_TC  1
    a[11,17]  old_normalized_TC2  1
    a[11,18]  abs_p_11_18  1
    a[11,18]  abs_m_11_18  1
    a[11,18]  true_G_epigraph  1
    a[11,18]  physical_G_upper  1
    a[11,18]  old_normalized_TC  1
    a[11,18]  old_normalized_TC2  1
    a[11,19]  abs_p_11_19  1
    a[11,19]  abs_m_11_19  1
    a[11,19]  true_G_epigraph  1
    a[11,19]  physical_G_upper  1
    a[11,19]  old_normalized_TC  1
    a[11,19]  old_normalized_TC2  1
    a[11,20]  abs_p_11_20  1
    a[11,20]  abs_m_11_20  1
    a[11,20]  true_G_epigraph  1
    a[11,20]  physical_G_upper  1
    a[11,20]  old_normalized_TC  1
    a[11,20]  old_normalized_TC2  1
    a[12,13]  abs_p_12_13  1
    a[12,13]  abs_m_12_13  1
    a[12,13]  true_G_epigraph  1
    a[12,13]  physical_G_upper  1
    a[12,13]  old_normalized_TC  1
    a[12,13]  old_normalized_TC2  1
    a[12,14]  abs_p_12_14  1
    a[12,14]  abs_m_12_14  1
    a[12,14]  true_G_epigraph  1
    a[12,14]  physical_G_upper  1
    a[12,14]  old_normalized_TC  1
    a[12,14]  old_normalized_TC2  1
    a[12,15]  abs_p_12_15  1
    a[12,15]  abs_m_12_15  1
    a[12,15]  true_G_epigraph  1
    a[12,15]  physical_G_upper  1
    a[12,15]  old_normalized_TC  1
    a[12,15]  old_normalized_TC2  1
    a[12,16]  abs_p_12_16  1
    a[12,16]  abs_m_12_16  1
    a[12,16]  true_G_epigraph  1
    a[12,16]  physical_G_upper  1
    a[12,16]  old_normalized_TC  1
    a[12,16]  old_normalized_TC2  1
    a[12,17]  abs_p_12_17  1
    a[12,17]  abs_m_12_17  1
    a[12,17]  true_G_epigraph  1
    a[12,17]  physical_G_upper  1
    a[12,17]  old_normalized_TC  1
    a[12,17]  old_normalized_TC2  1
    a[12,18]  abs_p_12_18  1
    a[12,18]  abs_m_12_18  1
    a[12,18]  true_G_epigraph  1
    a[12,18]  physical_G_upper  1
    a[12,18]  old_normalized_TC  1
    a[12,18]  old_normalized_TC2  1
    a[12,19]  abs_p_12_19  1
    a[12,19]  abs_m_12_19  1
    a[12,19]  true_G_epigraph  1
    a[12,19]  physical_G_upper  1
    a[12,19]  old_normalized_TC  1
    a[12,19]  old_normalized_TC2  1
    a[12,20]  abs_p_12_20  1
    a[12,20]  abs_m_12_20  1
    a[12,20]  true_G_epigraph  1
    a[12,20]  physical_G_upper  1
    a[12,20]  old_normalized_TC  1
    a[12,20]  old_normalized_TC2  1
    a[13,14]  abs_p_13_14  1
    a[13,14]  abs_m_13_14  1
    a[13,14]  true_G_epigraph  1
    a[13,14]  physical_G_upper  1
    a[13,14]  old_normalized_TC  1
    a[13,14]  old_normalized_TC2  1
    a[13,15]  abs_p_13_15  1
    a[13,15]  abs_m_13_15  1
    a[13,15]  true_G_epigraph  1
    a[13,15]  physical_G_upper  1
    a[13,15]  old_normalized_TC  1
    a[13,15]  old_normalized_TC2  1
    a[13,16]  abs_p_13_16  1
    a[13,16]  abs_m_13_16  1
    a[13,16]  true_G_epigraph  1
    a[13,16]  physical_G_upper  1
    a[13,16]  old_normalized_TC  1
    a[13,16]  old_normalized_TC2  1
    a[13,17]  abs_p_13_17  1
    a[13,17]  abs_m_13_17  1
    a[13,17]  true_G_epigraph  1
    a[13,17]  physical_G_upper  1
    a[13,17]  old_normalized_TC  1
    a[13,17]  old_normalized_TC2  1
    a[13,18]  abs_p_13_18  1
    a[13,18]  abs_m_13_18  1
    a[13,18]  true_G_epigraph  1
    a[13,18]  physical_G_upper  1
    a[13,18]  old_normalized_TC  1
    a[13,18]  old_normalized_TC2  1
    a[13,19]  abs_p_13_19  1
    a[13,19]  abs_m_13_19  1
    a[13,19]  true_G_epigraph  1
    a[13,19]  physical_G_upper  1
    a[13,19]  old_normalized_TC  1
    a[13,19]  old_normalized_TC2  1
    a[13,20]  abs_p_13_20  1
    a[13,20]  abs_m_13_20  1
    a[13,20]  true_G_epigraph  1
    a[13,20]  physical_G_upper  1
    a[13,20]  old_normalized_TC  1
    a[13,20]  old_normalized_TC2  1
    a[14,15]  abs_p_14_15  1
    a[14,15]  abs_m_14_15  1
    a[14,15]  true_G_epigraph  1
    a[14,15]  physical_G_upper  1
    a[14,15]  old_normalized_TC  1
    a[14,15]  old_normalized_TC2  1
    a[14,16]  abs_p_14_16  1
    a[14,16]  abs_m_14_16  1
    a[14,16]  true_G_epigraph  1
    a[14,16]  physical_G_upper  1
    a[14,16]  old_normalized_TC  1
    a[14,16]  old_normalized_TC2  1
    a[14,17]  abs_p_14_17  1
    a[14,17]  abs_m_14_17  1
    a[14,17]  true_G_epigraph  1
    a[14,17]  physical_G_upper  1
    a[14,17]  old_normalized_TC  1
    a[14,17]  old_normalized_TC2  1
    a[14,18]  abs_p_14_18  1
    a[14,18]  abs_m_14_18  1
    a[14,18]  true_G_epigraph  1
    a[14,18]  physical_G_upper  1
    a[14,18]  old_normalized_TC  1
    a[14,18]  old_normalized_TC2  1
    a[14,19]  abs_p_14_19  1
    a[14,19]  abs_m_14_19  1
    a[14,19]  true_G_epigraph  1
    a[14,19]  physical_G_upper  1
    a[14,19]  old_normalized_TC  1
    a[14,19]  old_normalized_TC2  1
    a[14,20]  abs_p_14_20  1
    a[14,20]  abs_m_14_20  1
    a[14,20]  true_G_epigraph  1
    a[14,20]  physical_G_upper  1
    a[14,20]  old_normalized_TC  1
    a[14,20]  old_normalized_TC2  1
    a[15,16]  abs_p_15_16  1
    a[15,16]  abs_m_15_16  1
    a[15,16]  true_G_epigraph  1
    a[15,16]  physical_G_upper  1
    a[15,16]  old_normalized_TC  1
    a[15,16]  old_normalized_TC2  1
    a[15,17]  abs_p_15_17  1
    a[15,17]  abs_m_15_17  1
    a[15,17]  true_G_epigraph  1
    a[15,17]  physical_G_upper  1
    a[15,17]  old_normalized_TC  1
    a[15,17]  old_normalized_TC2  1
    a[15,18]  abs_p_15_18  1
    a[15,18]  abs_m_15_18  1
    a[15,18]  true_G_epigraph  1
    a[15,18]  physical_G_upper  1
    a[15,18]  old_normalized_TC  1
    a[15,18]  old_normalized_TC2  1
    a[15,19]  abs_p_15_19  1
    a[15,19]  abs_m_15_19  1
    a[15,19]  true_G_epigraph  1
    a[15,19]  physical_G_upper  1
    a[15,19]  old_normalized_TC  1
    a[15,19]  old_normalized_TC2  1
    a[15,20]  abs_p_15_20  1
    a[15,20]  abs_m_15_20  1
    a[15,20]  true_G_epigraph  1
    a[15,20]  physical_G_upper  1
    a[15,20]  old_normalized_TC  1
    a[15,20]  old_normalized_TC2  1
    a[16,17]  abs_p_16_17  1
    a[16,17]  abs_m_16_17  1
    a[16,17]  true_G_epigraph  1
    a[16,17]  physical_G_upper  1
    a[16,17]  old_normalized_TC  1
    a[16,17]  old_normalized_TC2  1
    a[16,18]  abs_p_16_18  1
    a[16,18]  abs_m_16_18  1
    a[16,18]  true_G_epigraph  1
    a[16,18]  physical_G_upper  1
    a[16,18]  old_normalized_TC  1
    a[16,18]  old_normalized_TC2  1
    a[16,19]  abs_p_16_19  1
    a[16,19]  abs_m_16_19  1
    a[16,19]  true_G_epigraph  1
    a[16,19]  physical_G_upper  1
    a[16,19]  old_normalized_TC  1
    a[16,19]  old_normalized_TC2  1
    a[16,20]  abs_p_16_20  1
    a[16,20]  abs_m_16_20  1
    a[16,20]  true_G_epigraph  1
    a[16,20]  physical_G_upper  1
    a[16,20]  old_normalized_TC  1
    a[16,20]  old_normalized_TC2  1
    a[17,18]  abs_p_17_18  1
    a[17,18]  abs_m_17_18  1
    a[17,18]  true_G_epigraph  1
    a[17,18]  physical_G_upper  1
    a[17,18]  old_normalized_TC  1
    a[17,18]  old_normalized_TC2  1
    a[17,19]  abs_p_17_19  1
    a[17,19]  abs_m_17_19  1
    a[17,19]  true_G_epigraph  1
    a[17,19]  physical_G_upper  1
    a[17,19]  old_normalized_TC  1
    a[17,19]  old_normalized_TC2  1
    a[17,20]  abs_p_17_20  1
    a[17,20]  abs_m_17_20  1
    a[17,20]  true_G_epigraph  1
    a[17,20]  physical_G_upper  1
    a[17,20]  old_normalized_TC  1
    a[17,20]  old_normalized_TC2  1
    a[18,19]  abs_p_18_19  1
    a[18,19]  abs_m_18_19  1
    a[18,19]  true_G_epigraph  1
    a[18,19]  physical_G_upper  1
    a[18,19]  old_normalized_TC  1
    a[18,19]  old_normalized_TC2  1
    a[18,20]  abs_p_18_20  1
    a[18,20]  abs_m_18_20  1
    a[18,20]  true_G_epigraph  1
    a[18,20]  physical_G_upper  1
    a[18,20]  old_normalized_TC  1
    a[18,20]  old_normalized_TC2  1
    a[19,20]  abs_p_19_20  1
    a[19,20]  abs_m_19_20  1
    a[19,20]  true_G_epigraph  1
    a[19,20]  physical_G_upper  1
    a[19,20]  old_normalized_TC  1
    a[19,20]  old_normalized_TC2  1
    q         OBJ       1
    q         true_G_epigraph  -20
RHS
    RHS1      onehot_1  1
    RHS1      onehot_2  1
    RHS1      onehot_3  1
    RHS1      onehot_4  1
    RHS1      onehot_5  1
    RHS1      onehot_6  1
    RHS1      onehot_7  1
    RHS1      onehot_8  1
    RHS1      onehot_9  1
    RHS1      onehot_10  1
    RHS1      onehot_11  1
    RHS1      onehot_12  1
    RHS1      onehot_13  1
    RHS1      onehot_14  1
    RHS1      onehot_15  1
    RHS1      onehot_16  1
    RHS1      onehot_17  1
    RHS1      onehot_18  1
    RHS1      onehot_19  1
    RHS1      onehot_20  1
    RHS1      hard_lower  148
    RHS1      hard_upper  208
    RHS1      normalization  1
    RHS1      physical_G_upper  1.5504255156050437e+01
    RHS1      old_TS1   -7.2558386318014207e+00
    RHS1      old_TS2   -2.1255474452554751e+01
    RHS1      old_TS3   -1.5124087591240874e+01
    RHS1      old_TS4   -1.0197394833883074e+01
BOUNDS
 BV BND1      x[1,0]  
 BV BND1      x[1,1]  
 BV BND1      x[1,2]  
 BV BND1      x[1,3]  
 BV BND1      x[1,4]  
 BV BND1      x[1,5]  
 BV BND1      x[1,6]  
 BV BND1      x[1,7]  
 BV BND1      x[1,8]  
 BV BND1      x[1,9]  
 BV BND1      x[1,10] 
 BV BND1      x[1,11] 
 BV BND1      x[1,12] 
 BV BND1      x[1,13] 
 BV BND1      x[1,14] 
 BV BND1      x[1,15] 
 BV BND1      x[1,16] 
 BV BND1      x[1,17] 
 BV BND1      x[1,18] 
 BV BND1      x[2,0]  
 BV BND1      x[2,1]  
 BV BND1      x[2,2]  
 BV BND1      x[2,3]  
 BV BND1      x[2,4]  
 BV BND1      x[2,5]  
 BV BND1      x[2,6]  
 BV BND1      x[2,7]  
 BV BND1      x[2,8]  
 BV BND1      x[2,9]  
 BV BND1      x[2,10] 
 BV BND1      x[2,11] 
 BV BND1      x[2,12] 
 BV BND1      x[2,13] 
 BV BND1      x[2,14] 
 BV BND1      x[2,15] 
 BV BND1      x[2,16] 
 BV BND1      x[2,17] 
 BV BND1      x[2,18] 
 BV BND1      x[2,19] 
 BV BND1      x[2,20] 
 BV BND1      x[2,21] 
 BV BND1      x[2,22] 
 BV BND1      x[2,23] 
 BV BND1      x[2,24] 
 BV BND1      x[2,25] 
 BV BND1      x[2,26] 
 BV BND1      x[2,27] 
 BV BND1      x[2,28] 
 BV BND1      x[2,29] 
 BV BND1      x[3,0]  
 BV BND1      x[3,1]  
 BV BND1      x[3,2]  
 BV BND1      x[3,3]  
 BV BND1      x[3,4]  
 BV BND1      x[3,5]  
 BV BND1      x[3,6]  
 BV BND1      x[3,7]  
 BV BND1      x[3,8]  
 BV BND1      x[3,9]  
 BV BND1      x[3,10] 
 BV BND1      x[3,11] 
 BV BND1      x[3,12] 
 BV BND1      x[3,13] 
 BV BND1      x[3,14] 
 BV BND1      x[3,15] 
 BV BND1      x[3,16] 
 BV BND1      x[3,17] 
 BV BND1      x[3,18] 
 BV BND1      x[3,19] 
 BV BND1      x[3,20] 
 BV BND1      x[3,21] 
 BV BND1      x[4,0]  
 BV BND1      x[4,1]  
 BV BND1      x[4,2]  
 BV BND1      x[4,3]  
 BV BND1      x[4,4]  
 BV BND1      x[4,5]  
 BV BND1      x[4,6]  
 BV BND1      x[4,7]  
 BV BND1      x[4,8]  
 BV BND1      x[4,9]  
 BV BND1      x[4,10] 
 BV BND1      x[4,11] 
 BV BND1      x[4,12] 
 BV BND1      x[4,13] 
 BV BND1      x[4,14] 
 BV BND1      x[4,15] 
 BV BND1      x[4,16] 
 BV BND1      x[4,17] 
 BV BND1      x[4,18] 
 BV BND1      x[4,19] 
 BV BND1      x[4,20] 
 BV BND1      x[5,0]  
 BV BND1      x[5,1]  
 BV BND1      x[5,2]  
 BV BND1      x[5,3]  
 BV BND1      x[5,4]  
 BV BND1      x[5,5]  
 BV BND1      x[5,6]  
 BV BND1      x[5,7]  
 BV BND1      x[5,8]  
 BV BND1      x[5,9]  
 BV BND1      x[5,10] 
 BV BND1      x[5,11] 
 BV BND1      x[5,12] 
 BV BND1      x[5,13] 
 BV BND1      x[5,14] 
 BV BND1      x[5,15] 
 BV BND1      x[5,16] 
 BV BND1      x[5,17] 
 BV BND1      x[5,18] 
 BV BND1      x[5,19] 
 BV BND1      x[5,20] 
 BV BND1      x[5,21] 
 BV BND1      x[5,22] 
 BV BND1      x[5,23] 
 BV BND1      x[6,0]  
 BV BND1      x[6,1]  
 BV BND1      x[6,2]  
 BV BND1      x[6,3]  
 BV BND1      x[6,4]  
 BV BND1      x[6,5]  
 BV BND1      x[6,6]  
 BV BND1      x[6,7]  
 BV BND1      x[6,8]  
 BV BND1      x[6,9]  
 BV BND1      x[6,10] 
 BV BND1      x[6,11] 
 BV BND1      x[6,12] 
 BV BND1      x[6,13] 
 BV BND1      x[6,14] 
 BV BND1      x[6,15] 
 BV BND1      x[6,16] 
 BV BND1      x[6,17] 
 BV BND1      x[6,18] 
 BV BND1      x[6,19] 
 BV BND1      x[6,20] 
 BV BND1      x[6,21] 
 BV BND1      x[6,22] 
 BV BND1      x[7,0]  
 BV BND1      x[7,1]  
 BV BND1      x[7,2]  
 BV BND1      x[7,3]  
 BV BND1      x[7,4]  
 BV BND1      x[7,5]  
 BV BND1      x[7,6]  
 BV BND1      x[7,7]  
 BV BND1      x[7,8]  
 BV BND1      x[7,9]  
 BV BND1      x[7,10] 
 BV BND1      x[7,11] 
 BV BND1      x[7,12] 
 BV BND1      x[7,13] 
 BV BND1      x[7,14] 
 BV BND1      x[7,15] 
 BV BND1      x[7,16] 
 BV BND1      x[7,17] 
 BV BND1      x[7,18] 
 BV BND1      x[7,19] 
 BV BND1      x[8,0]  
 BV BND1      x[8,1]  
 BV BND1      x[8,2]  
 BV BND1      x[8,3]  
 BV BND1      x[8,4]  
 BV BND1      x[8,5]  
 BV BND1      x[8,6]  
 BV BND1      x[8,7]  
 BV BND1      x[8,8]  
 BV BND1      x[8,9]  
 BV BND1      x[8,10] 
 BV BND1      x[8,11] 
 BV BND1      x[8,12] 
 BV BND1      x[8,13] 
 BV BND1      x[8,14] 
 BV BND1      x[8,15] 
 BV BND1      x[8,16] 
 BV BND1      x[8,17] 
 BV BND1      x[8,18] 
 BV BND1      x[8,19] 
 BV BND1      x[8,20] 
 BV BND1      x[9,0]  
 BV BND1      x[9,1]  
 BV BND1      x[9,2]  
 BV BND1      x[9,3]  
 BV BND1      x[9,4]  
 BV BND1      x[9,5]  
 BV BND1      x[9,6]  
 BV BND1      x[9,7]  
 BV BND1      x[9,8]  
 BV BND1      x[9,9]  
 BV BND1      x[9,10] 
 BV BND1      x[9,11] 
 BV BND1      x[9,12] 
 BV BND1      x[9,13] 
 BV BND1      x[9,14] 
 BV BND1      x[9,15] 
 BV BND1      x[9,16] 
 BV BND1      x[9,17] 
 BV BND1      x[9,18] 
 BV BND1      x[9,19] 
 BV BND1      x[9,20] 
 BV BND1      x[9,21] 
 BV BND1      x[9,22] 
 BV BND1      x[9,23] 
 BV BND1      x[9,24] 
 BV BND1      x[9,25] 
 BV BND1      x[9,26] 
 BV BND1      x[9,27] 
 BV BND1      x[9,28] 
 BV BND1      x[9,29] 
 BV BND1      x[9,30] 
 BV BND1      x[9,31] 
 BV BND1      x[10,0] 
 BV BND1      x[10,1] 
 BV BND1      x[10,2] 
 BV BND1      x[10,3] 
 BV BND1      x[10,4] 
 BV BND1      x[10,5] 
 BV BND1      x[10,6] 
 BV BND1      x[10,7] 
 BV BND1      x[10,8] 
 BV BND1      x[10,9] 
 BV BND1      x[10,10]
 BV BND1      x[10,11]
 BV BND1      x[10,12]
 BV BND1      x[10,13]
 BV BND1      x[10,14]
 BV BND1      x[10,15]
 BV BND1      x[10,16]
 BV BND1      x[10,17]
 BV BND1      x[10,18]
 BV BND1      x[10,19]
 BV BND1      x[11,0] 
 BV BND1      x[11,1] 
 BV BND1      x[11,2] 
 BV BND1      x[11,3] 
 BV BND1      x[11,4] 
 BV BND1      x[11,5] 
 BV BND1      x[11,6] 
 BV BND1      x[11,7] 
 BV BND1      x[11,8] 
 BV BND1      x[11,9] 
 BV BND1      x[11,10]
 BV BND1      x[11,11]
 BV BND1      x[11,12]
 BV BND1      x[11,13]
 BV BND1      x[11,14]
 BV BND1      x[11,15]
 BV BND1      x[11,16]
 BV BND1      x[11,17]
 BV BND1      x[11,18]
 BV BND1      x[11,19]
 BV BND1      x[11,20]
 BV BND1      x[12,0] 
 BV BND1      x[12,1] 
 BV BND1      x[12,2] 
 BV BND1      x[12,3] 
 BV BND1      x[12,4] 
 BV BND1      x[12,5] 
 BV BND1      x[12,6] 
 BV BND1      x[12,7] 
 BV BND1      x[12,8] 
 BV BND1      x[12,9] 
 BV BND1      x[12,10]
 BV BND1      x[12,11]
 BV BND1      x[12,12]
 BV BND1      x[12,13]
 BV BND1      x[12,14]
 BV BND1      x[12,15]
 BV BND1      x[12,16]
 BV BND1      x[12,17]
 BV BND1      x[12,18]
 BV BND1      x[12,19]
 BV BND1      x[12,20]
 BV BND1      x[12,21]
 BV BND1      x[12,22]
 BV BND1      x[12,23]
 BV BND1      x[12,24]
 BV BND1      x[13,0] 
 BV BND1      x[13,1] 
 BV BND1      x[13,2] 
 BV BND1      x[13,3] 
 BV BND1      x[13,4] 
 BV BND1      x[13,5] 
 BV BND1      x[13,6] 
 BV BND1      x[13,7] 
 BV BND1      x[13,8] 
 BV BND1      x[13,9] 
 BV BND1      x[13,10]
 BV BND1      x[13,11]
 BV BND1      x[13,12]
 BV BND1      x[13,13]
 BV BND1      x[13,14]
 BV BND1      x[13,15]
 BV BND1      x[13,16]
 BV BND1      x[13,17]
 BV BND1      x[13,18]
 BV BND1      x[13,19]
 BV BND1      x[13,20]
 BV BND1      x[13,21]
 BV BND1      x[13,22]
 BV BND1      x[13,23]
 BV BND1      x[13,24]
 BV BND1      x[13,25]
 BV BND1      x[13,26]
 BV BND1      x[13,27]
 BV BND1      x[13,28]
 BV BND1      x[13,29]
 BV BND1      x[14,0] 
 BV BND1      x[14,1] 
 BV BND1      x[14,2] 
 BV BND1      x[14,3] 
 BV BND1      x[14,4] 
 BV BND1      x[14,5] 
 BV BND1      x[14,6] 
 BV BND1      x[14,7] 
 BV BND1      x[14,8] 
 BV BND1      x[14,9] 
 BV BND1      x[14,10]
 BV BND1      x[14,11]
 BV BND1      x[14,12]
 BV BND1      x[14,13]
 BV BND1      x[14,14]
 BV BND1      x[14,15]
 BV BND1      x[14,16]
 BV BND1      x[14,17]
 BV BND1      x[14,18]
 BV BND1      x[14,19]
 BV BND1      x[14,20]
 BV BND1      x[15,0] 
 BV BND1      x[15,1] 
 BV BND1      x[15,2] 
 BV BND1      x[15,3] 
 BV BND1      x[15,4] 
 BV BND1      x[15,5] 
 BV BND1      x[15,6] 
 BV BND1      x[15,7] 
 BV BND1      x[15,8] 
 BV BND1      x[15,9] 
 BV BND1      x[15,10]
 BV BND1      x[15,11]
 BV BND1      x[15,12]
 BV BND1      x[15,13]
 BV BND1      x[15,14]
 BV BND1      x[15,15]
 BV BND1      x[15,16]
 BV BND1      x[15,17]
 BV BND1      x[15,18]
 BV BND1      x[15,19]
 BV BND1      x[15,20]
 BV BND1      x[16,0] 
 BV BND1      x[16,1] 
 BV BND1      x[16,2] 
 BV BND1      x[16,3] 
 BV BND1      x[16,4] 
 BV BND1      x[16,5] 
 BV BND1      x[16,6] 
 BV BND1      x[16,7] 
 BV BND1      x[16,8] 
 BV BND1      x[16,9] 
 BV BND1      x[16,10]
 BV BND1      x[16,11]
 BV BND1      x[16,12]
 BV BND1      x[16,13]
 BV BND1      x[16,14]
 BV BND1      x[16,15]
 BV BND1      x[16,16]
 BV BND1      x[16,17]
 BV BND1      x[16,18]
 BV BND1      x[16,19]
 BV BND1      x[16,20]
 BV BND1      x[16,21]
 BV BND1      x[16,22]
 BV BND1      x[16,23]
 BV BND1      x[16,24]
 BV BND1      x[16,25]
 BV BND1      x[16,26]
 BV BND1      x[16,27]
 BV BND1      x[17,0] 
 BV BND1      x[17,1] 
 BV BND1      x[17,2] 
 BV BND1      x[17,3] 
 BV BND1      x[17,4] 
 BV BND1      x[17,5] 
 BV BND1      x[17,6] 
 BV BND1      x[17,7] 
 BV BND1      x[17,8] 
 BV BND1      x[17,9] 
 BV BND1      x[17,10]
 BV BND1      x[17,11]
 BV BND1      x[17,12]
 BV BND1      x[17,13]
 BV BND1      x[17,14]
 BV BND1      x[17,15]
 BV BND1      x[17,16]
 BV BND1      x[17,17]
 BV BND1      x[17,18]
 BV BND1      x[17,19]
 BV BND1      x[17,20]
 BV BND1      x[18,10]
 BV BND1      x[18,11]
 BV BND1      x[18,12]
 BV BND1      x[18,13]
 BV BND1      x[18,14]
 BV BND1      x[18,15]
 BV BND1      x[18,16]
 BV BND1      x[18,17]
 BV BND1      x[18,18]
 BV BND1      x[18,19]
 BV BND1      x[18,20]
 BV BND1      x[18,21]
 BV BND1      x[18,22]
 BV BND1      x[18,23]
 BV BND1      x[18,24]
 BV BND1      x[18,25]
 BV BND1      x[18,26]
 BV BND1      x[18,27]
 BV BND1      x[18,28]
 BV BND1      x[18,29]
 BV BND1      x[18,30]
 BV BND1      x[19,0] 
 BV BND1      x[19,1] 
 BV BND1      x[19,2] 
 BV BND1      x[19,3] 
 BV BND1      x[19,4] 
 BV BND1      x[19,5] 
 BV BND1      x[19,6] 
 BV BND1      x[19,7] 
 BV BND1      x[19,8] 
 BV BND1      x[19,9] 
 BV BND1      x[19,10]
 BV BND1      x[19,11]
 BV BND1      x[19,12]
 BV BND1      x[19,13]
 BV BND1      x[20,14]
 BV BND1      x[20,15]
 BV BND1      x[20,16]
 BV BND1      x[20,17]
 BV BND1      x[20,18]
 BV BND1      x[20,19]
 BV BND1      x[20,20]
 BV BND1      x[20,21]
 BV BND1      x[20,22]
 BV BND1      x[20,23]
 BV BND1      x[20,24]
 BV BND1      x[20,25]
 BV BND1      x[20,26]
 BV BND1      x[20,27]
 BV BND1      x[20,28]
 BV BND1      x[20,29]
 BV BND1      x[20,30]
 UP BND1      w[1,0]    1.0218978102189782e-01
 UP BND1      w[1,1]    1.0218978102189782e-01
 UP BND1      w[1,2]    1.0218978102189782e-01
 UP BND1      w[1,3]    1.0218978102189782e-01
 UP BND1      w[1,4]    1.0218978102189782e-01
 UP BND1      w[1,5]    1.0218978102189782e-01
 UP BND1      w[1,6]    1.0218978102189782e-01
 UP BND1      w[1,7]    1.0218978102189782e-01
 UP BND1      w[1,8]    1.0218978102189782e-01
 UP BND1      w[1,9]    1.0218978102189782e-01
 UP BND1      w[1,10]   1.0218978102189782e-01
 UP BND1      w[1,11]   1.0218978102189782e-01
 UP BND1      w[1,12]   1.0218978102189782e-01
 UP BND1      w[1,13]   1.0218978102189782e-01
 UP BND1      w[1,14]   1.0218978102189782e-01
 UP BND1      w[1,15]   1.0218978102189782e-01
 UP BND1      w[1,16]   1.0218978102189782e-01
 UP BND1      w[1,17]   1.0218978102189782e-01
 UP BND1      w[1,18]   1.0218978102189782e-01
 UP BND1      w[2,0]    1.0218978102189782e-01
 UP BND1      w[2,1]    1.0218978102189782e-01
 UP BND1      w[2,2]    1.0218978102189782e-01
 UP BND1      w[2,3]    1.0218978102189782e-01
 UP BND1      w[2,4]    1.0218978102189782e-01
 UP BND1      w[2,5]    1.0218978102189782e-01
 UP BND1      w[2,6]    1.0218978102189782e-01
 UP BND1      w[2,7]    1.0218978102189782e-01
 UP BND1      w[2,8]    1.0218978102189782e-01
 UP BND1      w[2,9]    1.0218978102189782e-01
 UP BND1      w[2,10]   1.0218978102189782e-01
 UP BND1      w[2,11]   1.0218978102189782e-01
 UP BND1      w[2,12]   1.0218978102189782e-01
 UP BND1      w[2,13]   1.0218978102189782e-01
 UP BND1      w[2,14]   1.0218978102189782e-01
 UP BND1      w[2,15]   1.0218978102189782e-01
 UP BND1      w[2,16]   1.0218978102189782e-01
 UP BND1      w[2,17]   1.0218978102189782e-01
 UP BND1      w[2,18]   1.0218978102189782e-01
 UP BND1      w[2,19]   1.0218978102189782e-01
 UP BND1      w[2,20]   1.0218978102189782e-01
 UP BND1      w[2,21]   1.0218978102189782e-01
 UP BND1      w[2,22]   1.0218978102189782e-01
 UP BND1      w[2,23]   1.0218978102189782e-01
 UP BND1      w[2,24]   1.0218978102189782e-01
 UP BND1      w[2,25]   1.0218978102189782e-01
 UP BND1      w[2,26]   1.0218978102189782e-01
 UP BND1      w[2,27]   1.0218978102189782e-01
 UP BND1      w[2,28]   1.0218978102189782e-01
 UP BND1      w[2,29]   1.0218978102189782e-01
 UP BND1      w[3,0]    1.0218978102189782e-01
 UP BND1      w[3,1]    1.0218978102189782e-01
 UP BND1      w[3,2]    1.0218978102189782e-01
 UP BND1      w[3,3]    1.0218978102189782e-01
 UP BND1      w[3,4]    1.0218978102189782e-01
 UP BND1      w[3,5]    1.0218978102189782e-01
 UP BND1      w[3,6]    1.0218978102189782e-01
 UP BND1      w[3,7]    1.0218978102189782e-01
 UP BND1      w[3,8]    1.0218978102189782e-01
 UP BND1      w[3,9]    1.0218978102189782e-01
 UP BND1      w[3,10]   1.0218978102189782e-01
 UP BND1      w[3,11]   1.0218978102189782e-01
 UP BND1      w[3,12]   1.0218978102189782e-01
 UP BND1      w[3,13]   1.0218978102189782e-01
 UP BND1      w[3,14]   1.0218978102189782e-01
 UP BND1      w[3,15]   1.0218978102189782e-01
 UP BND1      w[3,16]   1.0218978102189782e-01
 UP BND1      w[3,17]   1.0218978102189782e-01
 UP BND1      w[3,18]   1.0218978102189782e-01
 UP BND1      w[3,19]   1.0218978102189782e-01
 UP BND1      w[3,20]   1.0218978102189782e-01
 UP BND1      w[3,21]   1.0218978102189782e-01
 UP BND1      w[4,0]    1.0218978102189782e-01
 UP BND1      w[4,1]    1.0218978102189782e-01
 UP BND1      w[4,2]    1.0218978102189782e-01
 UP BND1      w[4,3]    1.0218978102189782e-01
 UP BND1      w[4,4]    1.0218978102189782e-01
 UP BND1      w[4,5]    1.0218978102189782e-01
 UP BND1      w[4,6]    1.0218978102189782e-01
 UP BND1      w[4,7]    1.0218978102189782e-01
 UP BND1      w[4,8]    1.0218978102189782e-01
 UP BND1      w[4,9]    1.0218978102189782e-01
 UP BND1      w[4,10]   1.0218978102189782e-01
 UP BND1      w[4,11]   1.0218978102189782e-01
 UP BND1      w[4,12]   1.0218978102189782e-01
 UP BND1      w[4,13]   1.0218978102189782e-01
 UP BND1      w[4,14]   1.0218978102189782e-01
 UP BND1      w[4,15]   1.0218978102189782e-01
 UP BND1      w[4,16]   1.0218978102189782e-01
 UP BND1      w[4,17]   1.0218978102189782e-01
 UP BND1      w[4,18]   1.0218978102189782e-01
 UP BND1      w[4,19]   1.0218978102189782e-01
 UP BND1      w[4,20]   1.0218978102189782e-01
 UP BND1      w[5,0]    1.0218978102189782e-01
 UP BND1      w[5,1]    1.0218978102189782e-01
 UP BND1      w[5,2]    1.0218978102189782e-01
 UP BND1      w[5,3]    1.0218978102189782e-01
 UP BND1      w[5,4]    1.0218978102189782e-01
 UP BND1      w[5,5]    1.0218978102189782e-01
 UP BND1      w[5,6]    1.0218978102189782e-01
 UP BND1      w[5,7]    1.0218978102189782e-01
 UP BND1      w[5,8]    1.0218978102189782e-01
 UP BND1      w[5,9]    1.0218978102189782e-01
 UP BND1      w[5,10]   1.0218978102189782e-01
 UP BND1      w[5,11]   1.0218978102189782e-01
 UP BND1      w[5,12]   1.0218978102189782e-01
 UP BND1      w[5,13]   1.0218978102189782e-01
 UP BND1      w[5,14]   1.0218978102189782e-01
 UP BND1      w[5,15]   1.0218978102189782e-01
 UP BND1      w[5,16]   1.0218978102189782e-01
 UP BND1      w[5,17]   1.0218978102189782e-01
 UP BND1      w[5,18]   1.0218978102189782e-01
 UP BND1      w[5,19]   1.0218978102189782e-01
 UP BND1      w[5,20]   1.0218978102189782e-01
 UP BND1      w[5,21]   1.0218978102189782e-01
 UP BND1      w[5,22]   1.0218978102189782e-01
 UP BND1      w[5,23]   1.0218978102189782e-01
 UP BND1      w[6,0]    1.0218978102189782e-01
 UP BND1      w[6,1]    1.0218978102189782e-01
 UP BND1      w[6,2]    1.0218978102189782e-01
 UP BND1      w[6,3]    1.0218978102189782e-01
 UP BND1      w[6,4]    1.0218978102189782e-01
 UP BND1      w[6,5]    1.0218978102189782e-01
 UP BND1      w[6,6]    1.0218978102189782e-01
 UP BND1      w[6,7]    1.0218978102189782e-01
 UP BND1      w[6,8]    1.0218978102189782e-01
 UP BND1      w[6,9]    1.0218978102189782e-01
 UP BND1      w[6,10]   1.0218978102189782e-01
 UP BND1      w[6,11]   1.0218978102189782e-01
 UP BND1      w[6,12]   1.0218978102189782e-01
 UP BND1      w[6,13]   1.0218978102189782e-01
 UP BND1      w[6,14]   1.0218978102189782e-01
 UP BND1      w[6,15]   1.0218978102189782e-01
 UP BND1      w[6,16]   1.0218978102189782e-01
 UP BND1      w[6,17]   1.0218978102189782e-01
 UP BND1      w[6,18]   1.0218978102189782e-01
 UP BND1      w[6,19]   1.0218978102189782e-01
 UP BND1      w[6,20]   1.0218978102189782e-01
 UP BND1      w[6,21]   1.0218978102189782e-01
 UP BND1      w[6,22]   1.0218978102189782e-01
 UP BND1      w[7,0]    1.0218978102189782e-01
 UP BND1      w[7,1]    1.0218978102189782e-01
 UP BND1      w[7,2]    1.0218978102189782e-01
 UP BND1      w[7,3]    1.0218978102189782e-01
 UP BND1      w[7,4]    1.0218978102189782e-01
 UP BND1      w[7,5]    1.0218978102189782e-01
 UP BND1      w[7,6]    1.0218978102189782e-01
 UP BND1      w[7,7]    1.0218978102189782e-01
 UP BND1      w[7,8]    1.0218978102189782e-01
 UP BND1      w[7,9]    1.0218978102189782e-01
 UP BND1      w[7,10]   1.0218978102189782e-01
 UP BND1      w[7,11]   1.0218978102189782e-01
 UP BND1      w[7,12]   1.0218978102189782e-01
 UP BND1      w[7,13]   1.0218978102189782e-01
 UP BND1      w[7,14]   1.0218978102189782e-01
 UP BND1      w[7,15]   1.0218978102189782e-01
 UP BND1      w[7,16]   1.0218978102189782e-01
 UP BND1      w[7,17]   1.0218978102189782e-01
 UP BND1      w[7,18]   1.0218978102189782e-01
 UP BND1      w[7,19]   1.0218978102189782e-01
 UP BND1      w[8,0]    1.0218978102189782e-01
 UP BND1      w[8,1]    1.0218978102189782e-01
 UP BND1      w[8,2]    1.0218978102189782e-01
 UP BND1      w[8,3]    1.0218978102189782e-01
 UP BND1      w[8,4]    1.0218978102189782e-01
 UP BND1      w[8,5]    1.0218978102189782e-01
 UP BND1      w[8,6]    1.0218978102189782e-01
 UP BND1      w[8,7]    1.0218978102189782e-01
 UP BND1      w[8,8]    1.0218978102189782e-01
 UP BND1      w[8,9]    1.0218978102189782e-01
 UP BND1      w[8,10]   1.0218978102189782e-01
 UP BND1      w[8,11]   1.0218978102189782e-01
 UP BND1      w[8,12]   1.0218978102189782e-01
 UP BND1      w[8,13]   1.0218978102189782e-01
 UP BND1      w[8,14]   1.0218978102189782e-01
 UP BND1      w[8,15]   1.0218978102189782e-01
 UP BND1      w[8,16]   1.0218978102189782e-01
 UP BND1      w[8,17]   1.0218978102189782e-01
 UP BND1      w[8,18]   1.0218978102189782e-01
 UP BND1      w[8,19]   1.0218978102189782e-01
 UP BND1      w[8,20]   1.0218978102189782e-01
 UP BND1      w[9,0]    1.0218978102189782e-01
 UP BND1      w[9,1]    1.0218978102189782e-01
 UP BND1      w[9,2]    1.0218978102189782e-01
 UP BND1      w[9,3]    1.0218978102189782e-01
 UP BND1      w[9,4]    1.0218978102189782e-01
 UP BND1      w[9,5]    1.0218978102189782e-01
 UP BND1      w[9,6]    1.0218978102189782e-01
 UP BND1      w[9,7]    1.0218978102189782e-01
 UP BND1      w[9,8]    1.0218978102189782e-01
 UP BND1      w[9,9]    1.0218978102189782e-01
 UP BND1      w[9,10]   1.0218978102189782e-01
 UP BND1      w[9,11]   1.0218978102189782e-01
 UP BND1      w[9,12]   1.0218978102189782e-01
 UP BND1      w[9,13]   1.0218978102189782e-01
 UP BND1      w[9,14]   1.0218978102189782e-01
 UP BND1      w[9,15]   1.0218978102189782e-01
 UP BND1      w[9,16]   1.0218978102189782e-01
 UP BND1      w[9,17]   1.0218978102189782e-01
 UP BND1      w[9,18]   1.0218978102189782e-01
 UP BND1      w[9,19]   1.0218978102189782e-01
 UP BND1      w[9,20]   1.0218978102189782e-01
 UP BND1      w[9,21]   1.0218978102189782e-01
 UP BND1      w[9,22]   1.0218978102189782e-01
 UP BND1      w[9,23]   1.0218978102189782e-01
 UP BND1      w[9,24]   1.0218978102189782e-01
 UP BND1      w[9,25]   1.0218978102189782e-01
 UP BND1      w[9,26]   1.0218978102189782e-01
 UP BND1      w[9,27]   1.0218978102189782e-01
 UP BND1      w[9,28]   1.0218978102189782e-01
 UP BND1      w[9,29]   1.0218978102189782e-01
 UP BND1      w[9,30]   1.0218978102189782e-01
 UP BND1      w[9,31]   1.0218978102189782e-01
 UP BND1      w[10,0]   1.0218978102189782e-01
 UP BND1      w[10,1]   1.0218978102189782e-01
 UP BND1      w[10,2]   1.0218978102189782e-01
 UP BND1      w[10,3]   1.0218978102189782e-01
 UP BND1      w[10,4]   1.0218978102189782e-01
 UP BND1      w[10,5]   1.0218978102189782e-01
 UP BND1      w[10,6]   1.0218978102189782e-01
 UP BND1      w[10,7]   1.0218978102189782e-01
 UP BND1      w[10,8]   1.0218978102189782e-01
 UP BND1      w[10,9]   1.0218978102189782e-01
 UP BND1      w[10,10]  1.0218978102189782e-01
 UP BND1      w[10,11]  1.0218978102189782e-01
 UP BND1      w[10,12]  1.0218978102189782e-01
 UP BND1      w[10,13]  1.0218978102189782e-01
 UP BND1      w[10,14]  1.0218978102189782e-01
 UP BND1      w[10,15]  1.0218978102189782e-01
 UP BND1      w[10,16]  1.0218978102189782e-01
 UP BND1      w[10,17]  1.0218978102189782e-01
 UP BND1      w[10,18]  1.0218978102189782e-01
 UP BND1      w[10,19]  1.0218978102189782e-01
 UP BND1      w[11,0]   1.0218978102189782e-01
 UP BND1      w[11,1]   1.0218978102189782e-01
 UP BND1      w[11,2]   1.0218978102189782e-01
 UP BND1      w[11,3]   1.0218978102189782e-01
 UP BND1      w[11,4]   1.0218978102189782e-01
 UP BND1      w[11,5]   1.0218978102189782e-01
 UP BND1      w[11,6]   1.0218978102189782e-01
 UP BND1      w[11,7]   1.0218978102189782e-01
 UP BND1      w[11,8]   1.0218978102189782e-01
 UP BND1      w[11,9]   1.0218978102189782e-01
 UP BND1      w[11,10]  1.0218978102189782e-01
 UP BND1      w[11,11]  1.0218978102189782e-01
 UP BND1      w[11,12]  1.0218978102189782e-01
 UP BND1      w[11,13]  1.0218978102189782e-01
 UP BND1      w[11,14]  1.0218978102189782e-01
 UP BND1      w[11,15]  1.0218978102189782e-01
 UP BND1      w[11,16]  1.0218978102189782e-01
 UP BND1      w[11,17]  1.0218978102189782e-01
 UP BND1      w[11,18]  1.0218978102189782e-01
 UP BND1      w[11,19]  1.0218978102189782e-01
 UP BND1      w[11,20]  1.0218978102189782e-01
 UP BND1      w[12,0]   1.0218978102189782e-01
 UP BND1      w[12,1]   1.0218978102189782e-01
 UP BND1      w[12,2]   1.0218978102189782e-01
 UP BND1      w[12,3]   1.0218978102189782e-01
 UP BND1      w[12,4]   1.0218978102189782e-01
 UP BND1      w[12,5]   1.0218978102189782e-01
 UP BND1      w[12,6]   1.0218978102189782e-01
 UP BND1      w[12,7]   1.0218978102189782e-01
 UP BND1      w[12,8]   1.0218978102189782e-01
 UP BND1      w[12,9]   1.0218978102189782e-01
 UP BND1      w[12,10]  1.0218978102189782e-01
 UP BND1      w[12,11]  1.0218978102189782e-01
 UP BND1      w[12,12]  1.0218978102189782e-01
 UP BND1      w[12,13]  1.0218978102189782e-01
 UP BND1      w[12,14]  1.0218978102189782e-01
 UP BND1      w[12,15]  1.0218978102189782e-01
 UP BND1      w[12,16]  1.0218978102189782e-01
 UP BND1      w[12,17]  1.0218978102189782e-01
 UP BND1      w[12,18]  1.0218978102189782e-01
 UP BND1      w[12,19]  1.0218978102189782e-01
 UP BND1      w[12,20]  1.0218978102189782e-01
 UP BND1      w[12,21]  1.0218978102189782e-01
 UP BND1      w[12,22]  1.0218978102189782e-01
 UP BND1      w[12,23]  1.0218978102189782e-01
 UP BND1      w[12,24]  1.0218978102189782e-01
 UP BND1      w[13,0]   1.0218978102189782e-01
 UP BND1      w[13,1]   1.0218978102189782e-01
 UP BND1      w[13,2]   1.0218978102189782e-01
 UP BND1      w[13,3]   1.0218978102189782e-01
 UP BND1      w[13,4]   1.0218978102189782e-01
 UP BND1      w[13,5]   1.0218978102189782e-01
 UP BND1      w[13,6]   1.0218978102189782e-01
 UP BND1      w[13,7]   1.0218978102189782e-01
 UP BND1      w[13,8]   1.0218978102189782e-01
 UP BND1      w[13,9]   1.0218978102189782e-01
 UP BND1      w[13,10]  1.0218978102189782e-01
 UP BND1      w[13,11]  1.0218978102189782e-01
 UP BND1      w[13,12]  1.0218978102189782e-01
 UP BND1      w[13,13]  1.0218978102189782e-01
 UP BND1      w[13,14]  1.0218978102189782e-01
 UP BND1      w[13,15]  1.0218978102189782e-01
 UP BND1      w[13,16]  1.0218978102189782e-01
 UP BND1      w[13,17]  1.0218978102189782e-01
 UP BND1      w[13,18]  1.0218978102189782e-01
 UP BND1      w[13,19]  1.0218978102189782e-01
 UP BND1      w[13,20]  1.0218978102189782e-01
 UP BND1      w[13,21]  1.0218978102189782e-01
 UP BND1      w[13,22]  1.0218978102189782e-01
 UP BND1      w[13,23]  1.0218978102189782e-01
 UP BND1      w[13,24]  1.0218978102189782e-01
 UP BND1      w[13,25]  1.0218978102189782e-01
 UP BND1      w[13,26]  1.0218978102189782e-01
 UP BND1      w[13,27]  1.0218978102189782e-01
 UP BND1      w[13,28]  1.0218978102189782e-01
 UP BND1      w[13,29]  1.0218978102189782e-01
 UP BND1      w[14,0]   1.0218978102189782e-01
 UP BND1      w[14,1]   1.0218978102189782e-01
 UP BND1      w[14,2]   1.0218978102189782e-01
 UP BND1      w[14,3]   1.0218978102189782e-01
 UP BND1      w[14,4]   1.0218978102189782e-01
 UP BND1      w[14,5]   1.0218978102189782e-01
 UP BND1      w[14,6]   1.0218978102189782e-01
 UP BND1      w[14,7]   1.0218978102189782e-01
 UP BND1      w[14,8]   1.0218978102189782e-01
 UP BND1      w[14,9]   1.0218978102189782e-01
 UP BND1      w[14,10]  1.0218978102189782e-01
 UP BND1      w[14,11]  1.0218978102189782e-01
 UP BND1      w[14,12]  1.0218978102189782e-01
 UP BND1      w[14,13]  1.0218978102189782e-01
 UP BND1      w[14,14]  1.0218978102189782e-01
 UP BND1      w[14,15]  1.0218978102189782e-01
 UP BND1      w[14,16]  1.0218978102189782e-01
 UP BND1      w[14,17]  1.0218978102189782e-01
 UP BND1      w[14,18]  1.0218978102189782e-01
 UP BND1      w[14,19]  1.0218978102189782e-01
 UP BND1      w[14,20]  1.0218978102189782e-01
 UP BND1      w[15,0]   1.0218978102189782e-01
 UP BND1      w[15,1]   1.0218978102189782e-01
 UP BND1      w[15,2]   1.0218978102189782e-01
 UP BND1      w[15,3]   1.0218978102189782e-01
 UP BND1      w[15,4]   1.0218978102189782e-01
 UP BND1      w[15,5]   1.0218978102189782e-01
 UP BND1      w[15,6]   1.0218978102189782e-01
 UP BND1      w[15,7]   1.0218978102189782e-01
 UP BND1      w[15,8]   1.0218978102189782e-01
 UP BND1      w[15,9]   1.0218978102189782e-01
 UP BND1      w[15,10]  1.0218978102189782e-01
 UP BND1      w[15,11]  1.0218978102189782e-01
 UP BND1      w[15,12]  1.0218978102189782e-01
 UP BND1      w[15,13]  1.0218978102189782e-01
 UP BND1      w[15,14]  1.0218978102189782e-01
 UP BND1      w[15,15]  1.0218978102189782e-01
 UP BND1      w[15,16]  1.0218978102189782e-01
 UP BND1      w[15,17]  1.0218978102189782e-01
 UP BND1      w[15,18]  1.0218978102189782e-01
 UP BND1      w[15,19]  1.0218978102189782e-01
 UP BND1      w[15,20]  1.0218978102189782e-01
 UP BND1      w[16,0]   1.0218978102189782e-01
 UP BND1      w[16,1]   1.0218978102189782e-01
 UP BND1      w[16,2]   1.0218978102189782e-01
 UP BND1      w[16,3]   1.0218978102189782e-01
 UP BND1      w[16,4]   1.0218978102189782e-01
 UP BND1      w[16,5]   1.0218978102189782e-01
 UP BND1      w[16,6]   1.0218978102189782e-01
 UP BND1      w[16,7]   1.0218978102189782e-01
 UP BND1      w[16,8]   1.0218978102189782e-01
 UP BND1      w[16,9]   1.0218978102189782e-01
 UP BND1      w[16,10]  1.0218978102189782e-01
 UP BND1      w[16,11]  1.0218978102189782e-01
 UP BND1      w[16,12]  1.0218978102189782e-01
 UP BND1      w[16,13]  1.0218978102189782e-01
 UP BND1      w[16,14]  1.0218978102189782e-01
 UP BND1      w[16,15]  1.0218978102189782e-01
 UP BND1      w[16,16]  1.0218978102189782e-01
 UP BND1      w[16,17]  1.0218978102189782e-01
 UP BND1      w[16,18]  1.0218978102189782e-01
 UP BND1      w[16,19]  1.0218978102189782e-01
 UP BND1      w[16,20]  1.0218978102189782e-01
 UP BND1      w[16,21]  1.0218978102189782e-01
 UP BND1      w[16,22]  1.0218978102189782e-01
 UP BND1      w[16,23]  1.0218978102189782e-01
 UP BND1      w[16,24]  1.0218978102189782e-01
 UP BND1      w[16,25]  1.0218978102189782e-01
 UP BND1      w[16,26]  1.0218978102189782e-01
 UP BND1      w[16,27]  1.0218978102189782e-01
 UP BND1      w[17,0]   1.0218978102189782e-01
 UP BND1      w[17,1]   1.0218978102189782e-01
 UP BND1      w[17,2]   1.0218978102189782e-01
 UP BND1      w[17,3]   1.0218978102189782e-01
 UP BND1      w[17,4]   1.0218978102189782e-01
 UP BND1      w[17,5]   1.0218978102189782e-01
 UP BND1      w[17,6]   1.0218978102189782e-01
 UP BND1      w[17,7]   1.0218978102189782e-01
 UP BND1      w[17,8]   1.0218978102189782e-01
 UP BND1      w[17,9]   1.0218978102189782e-01
 UP BND1      w[17,10]  1.0218978102189782e-01
 UP BND1      w[17,11]  1.0218978102189782e-01
 UP BND1      w[17,12]  1.0218978102189782e-01
 UP BND1      w[17,13]  1.0218978102189782e-01
 UP BND1      w[17,14]  1.0218978102189782e-01
 UP BND1      w[17,15]  1.0218978102189782e-01
 UP BND1      w[17,16]  1.0218978102189782e-01
 UP BND1      w[17,17]  1.0218978102189782e-01
 UP BND1      w[17,18]  1.0218978102189782e-01
 UP BND1      w[17,19]  1.0218978102189782e-01
 UP BND1      w[17,20]  1.0218978102189782e-01
 UP BND1      w[18,10]  1.0218978102189782e-01
 UP BND1      w[18,11]  1.0218978102189782e-01
 UP BND1      w[18,12]  1.0218978102189782e-01
 UP BND1      w[18,13]  1.0218978102189782e-01
 UP BND1      w[18,14]  1.0218978102189782e-01
 UP BND1      w[18,15]  1.0218978102189782e-01
 UP BND1      w[18,16]  1.0218978102189782e-01
 UP BND1      w[18,17]  1.0218978102189782e-01
 UP BND1      w[18,18]  1.0218978102189782e-01
 UP BND1      w[18,19]  1.0218978102189782e-01
 UP BND1      w[18,20]  1.0218978102189782e-01
 UP BND1      w[18,21]  1.0218978102189782e-01
 UP BND1      w[18,22]  1.0218978102189782e-01
 UP BND1      w[18,23]  1.0218978102189782e-01
 UP BND1      w[18,24]  1.0218978102189782e-01
 UP BND1      w[18,25]  1.0218978102189782e-01
 UP BND1      w[18,26]  1.0218978102189782e-01
 UP BND1      w[18,27]  1.0218978102189782e-01
 UP BND1      w[18,28]  1.0218978102189782e-01
 UP BND1      w[18,29]  1.0218978102189782e-01
 UP BND1      w[18,30]  1.0218978102189782e-01
 UP BND1      w[19,0]   1.0218978102189782e-01
 UP BND1      w[19,1]   1.0218978102189782e-01
 UP BND1      w[19,2]   1.0218978102189782e-01
 UP BND1      w[19,3]   1.0218978102189782e-01
 UP BND1      w[19,4]   1.0218978102189782e-01
 UP BND1      w[19,5]   1.0218978102189782e-01
 UP BND1      w[19,6]   1.0218978102189782e-01
 UP BND1      w[19,7]   1.0218978102189782e-01
 UP BND1      w[19,8]   1.0218978102189782e-01
 UP BND1      w[19,9]   1.0218978102189782e-01
 UP BND1      w[19,10]  1.0218978102189782e-01
 UP BND1      w[19,11]  1.0218978102189782e-01
 UP BND1      w[19,12]  1.0218978102189782e-01
 UP BND1      w[19,13]  1.0218978102189782e-01
 UP BND1      w[20,14]  1.0218978102189782e-01
 UP BND1      w[20,15]  1.0218978102189782e-01
 UP BND1      w[20,16]  1.0218978102189782e-01
 UP BND1      w[20,17]  1.0218978102189782e-01
 UP BND1      w[20,18]  1.0218978102189782e-01
 UP BND1      w[20,19]  1.0218978102189782e-01
 UP BND1      w[20,20]  1.0218978102189782e-01
 UP BND1      w[20,21]  1.0218978102189782e-01
 UP BND1      w[20,22]  1.0218978102189782e-01
 UP BND1      w[20,23]  1.0218978102189782e-01
 UP BND1      w[20,24]  1.0218978102189782e-01
 UP BND1      w[20,25]  1.0218978102189782e-01
 UP BND1      w[20,26]  1.0218978102189782e-01
 UP BND1      w[20,27]  1.0218978102189782e-01
 UP BND1      w[20,28]  1.0218978102189782e-01
 UP BND1      w[20,29]  1.0218978102189782e-01
 UP BND1      w[20,30]  1.0218978102189782e-01
 LO BND1      t         4.9025936701360941e-02
 UP BND1      t         1.0218978102189782e-01
 UP BND1      q         7.7521275780252186e-01
ENDATA
