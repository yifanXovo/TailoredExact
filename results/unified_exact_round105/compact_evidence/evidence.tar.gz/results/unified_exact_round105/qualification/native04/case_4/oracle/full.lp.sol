# Solution for model obj
# Objective value = 0
z_1 1
x_0_1 1
x_2_1 0
x_1_0 0
x_1_2 1
mode_1 1
p_1 3
d_1 0
load_1 3
ord_1 1
x_0_2 0
z_2 1
x_2_0 1
mode_2 0
p_2 0
d_2 1
load_2 2
ord_2 2
