* Signature: 0xf45323ad0176fe74
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 L  column_0
 L  column_1
 L  column_2
 L  column_3
 L  column_4
 L  column_5
 L  column_6
 L  column_7
 L  column_8
 L  column_9
 L  column_10
 L  column_11
 L  column_12
 L  column_13
COLUMNS
    psi[1,11]  OBJ       1
    psi[1,11]  column_0  1
    psi[1,11]  column_1  1
    psi[1,11]  column_2  1
    psi[1,11]  column_3  1
    psi[1,11]  column_4  1
    psi[1,11]  column_5  1
    psi[1,11]  column_6  1
    psi[1,11]  column_7  1
    psi[1,11]  column_8  1
    psi[1,11]  column_9  1
    psi[1,11]  column_10  1
    psi[1,11]  column_11  1
    psi[1,11]  column_12  1
    psi[1,11]  column_13  1
    psi[2,14]  OBJ       1
    psi[2,14]  column_0  1
    psi[2,14]  column_1  1
    psi[2,14]  column_2  1
    psi[2,14]  column_3  1
    psi[2,14]  column_4  1
    psi[2,14]  column_5  1
    psi[2,14]  column_6  1
    psi[2,14]  column_7  1
    psi[2,14]  column_8  1
    psi[2,14]  column_9  1
    psi[2,14]  column_10  1
    psi[2,14]  column_11  1
    psi[2,14]  column_12  1
    psi[2,14]  column_13  1
    psi[3,15]  OBJ       1
    psi[3,15]  column_0  1
    psi[3,15]  column_1  1
    psi[3,15]  column_2  1
    psi[3,15]  column_3  1
    psi[3,15]  column_4  1
    psi[3,15]  column_5  1
    psi[3,15]  column_6  1
    psi[3,15]  column_7  1
    psi[3,15]  column_8  1
    psi[3,15]  column_9  1
    psi[3,15]  column_10  1
    psi[3,15]  column_11  1
    psi[3,15]  column_12  1
    psi[3,15]  column_13  1
    psi[4,11]  OBJ       1
    psi[4,11]  column_0  1
    psi[4,11]  column_1  1
    psi[4,11]  column_2  1
    psi[4,11]  column_3  1
    psi[4,11]  column_4  1
    psi[4,11]  column_5  1
    psi[4,11]  column_6  1
    psi[4,11]  column_7  1
    psi[4,11]  column_8  1
    psi[4,11]  column_9  1
    psi[4,11]  column_10  1
    psi[4,11]  column_11  1
    psi[4,11]  column_12  1
    psi[4,11]  column_13  1
    psi[5,11]  OBJ       6.1869575159297852e-01
    psi[5,11]  column_0  1
    psi[5,11]  column_1  1
    psi[5,11]  column_2  1
    psi[5,11]  column_3  1
    psi[5,11]  column_4  1
    psi[5,11]  column_5  1
    psi[5,11]  column_6  1
    psi[5,11]  column_7  1
    psi[5,11]  column_8  1
    psi[5,18]  OBJ       3.8130424840702154e-01
    psi[5,18]  column_9  1
    psi[5,18]  column_10  1
    psi[5,18]  column_11  1
    psi[5,18]  column_12  1
    psi[5,18]  column_13  1
    psi[6,11]  OBJ       0.703430029016761
    psi[6,11]  column_0  1
    psi[6,11]  column_1  1
    psi[6,11]  column_2  1
    psi[6,11]  column_9  1
    psi[6,11]  column_10  1
    psi[6,11]  column_11  1
    psi[6,20]  OBJ       2.9656997098323895e-01
    psi[6,20]  column_3  1
    psi[6,20]  column_4  1
    psi[6,20]  column_5  1
    psi[6,20]  column_6  1
    psi[6,20]  column_7  1
    psi[6,20]  column_8  1
    psi[6,20]  column_12  1
    psi[6,20]  column_13  1
    psi[7,10]  OBJ       1
    psi[7,10]  column_0  1
    psi[7,10]  column_1  1
    psi[7,10]  column_2  1
    psi[7,10]  column_3  1
    psi[7,10]  column_4  1
    psi[7,10]  column_5  1
    psi[7,10]  column_6  1
    psi[7,10]  column_7  1
    psi[7,10]  column_8  1
    psi[7,10]  column_9  1
    psi[7,10]  column_10  1
    psi[7,10]  column_11  1
    psi[7,10]  column_12  1
    psi[7,10]  column_13  1
    psi[8,11]  OBJ       1
    psi[8,11]  column_0  1
    psi[8,11]  column_1  1
    psi[8,11]  column_2  1
    psi[8,11]  column_3  1
    psi[8,11]  column_4  1
    psi[8,11]  column_5  1
    psi[8,11]  column_6  1
    psi[8,11]  column_7  1
    psi[8,11]  column_8  1
    psi[8,11]  column_9  1
    psi[8,11]  column_10  1
    psi[8,11]  column_11  1
    psi[8,11]  column_12  1
    psi[8,11]  column_13  1
    psi[9,9]  OBJ       1
    psi[9,9]  column_0  1
    psi[9,9]  column_1  1
    psi[9,9]  column_2  1
    psi[9,9]  column_3  1
    psi[9,9]  column_4  1
    psi[9,9]  column_5  1
    psi[9,9]  column_6  1
    psi[9,9]  column_7  1
    psi[9,9]  column_8  1
    psi[9,9]  column_9  1
    psi[9,9]  column_10  1
    psi[9,9]  column_11  1
    psi[9,9]  column_12  1
    psi[9,9]  column_13  1
    psi[10,16]  OBJ       1
    psi[10,16]  column_0  1
    psi[10,16]  column_1  1
    psi[10,16]  column_2  1
    psi[10,16]  column_3  1
    psi[10,16]  column_4  1
    psi[10,16]  column_5  1
    psi[10,16]  column_6  1
    psi[10,16]  column_7  1
    psi[10,16]  column_8  1
    psi[10,16]  column_9  1
    psi[10,16]  column_10  1
    psi[10,16]  column_11  1
    psi[10,16]  column_12  1
    psi[10,16]  column_13  1
    psi[11,17]  OBJ       1
    psi[11,17]  column_0  1
    psi[11,17]  column_1  1
    psi[11,17]  column_2  1
    psi[11,17]  column_3  1
    psi[11,17]  column_4  1
    psi[11,17]  column_5  1
    psi[11,17]  column_6  1
    psi[11,17]  column_7  1
    psi[11,17]  column_8  1
    psi[11,17]  column_9  1
    psi[11,17]  column_10  1
    psi[11,17]  column_11  1
    psi[11,17]  column_12  1
    psi[11,17]  column_13  1
    psi[12,10]  OBJ       6.9668980240350553e-01
    psi[12,10]  column_0  1
    psi[12,10]  column_1  1
    psi[12,10]  column_3  1
    psi[12,10]  column_4  1
    psi[12,10]  column_5  1
    psi[12,10]  column_6  1
    psi[12,10]  column_7  1
    psi[12,10]  column_9  1
    psi[12,10]  column_10  1
    psi[12,10]  column_11  1
    psi[12,10]  column_12  1
    psi[12,10]  column_13  1
    psi[12,18]  OBJ       3.0331019759649447e-01
    psi[12,18]  column_2  1
    psi[12,18]  column_8  1
    psi[13,13]  OBJ       1
    psi[13,13]  column_0  1
    psi[13,13]  column_1  1
    psi[13,13]  column_2  1
    psi[13,13]  column_3  1
    psi[13,13]  column_4  1
    psi[13,13]  column_5  1
    psi[13,13]  column_6  1
    psi[13,13]  column_7  1
    psi[13,13]  column_8  1
    psi[13,13]  column_9  1
    psi[13,13]  column_10  1
    psi[13,13]  column_11  1
    psi[13,13]  column_12  1
    psi[13,13]  column_13  1
    psi[14,13]  OBJ       1
    psi[14,13]  column_0  1
    psi[14,13]  column_1  1
    psi[14,13]  column_2  1
    psi[14,13]  column_3  1
    psi[14,13]  column_4  1
    psi[14,13]  column_5  1
    psi[14,13]  column_6  1
    psi[14,13]  column_7  1
    psi[14,13]  column_8  1
    psi[14,13]  column_9  1
    psi[14,13]  column_10  1
    psi[14,13]  column_11  1
    psi[14,13]  column_12  1
    psi[14,13]  column_13  1
    psi[15,14]  OBJ       1
    psi[15,14]  column_0  1
    psi[15,14]  column_1  1
    psi[15,14]  column_2  1
    psi[15,14]  column_3  1
    psi[15,14]  column_4  1
    psi[15,14]  column_5  1
    psi[15,14]  column_6  1
    psi[15,14]  column_7  1
    psi[15,14]  column_8  1
    psi[15,14]  column_9  1
    psi[15,14]  column_10  1
    psi[15,14]  column_11  1
    psi[15,14]  column_12  1
    psi[15,14]  column_13  1
    psi[16,12]  OBJ       6.5561081695642309e-01
    psi[16,12]  column_0  1
    psi[16,12]  column_1  1
    psi[16,12]  column_2  1
    psi[16,12]  column_3  1
    psi[16,12]  column_4  1
    psi[16,12]  column_5  1
    psi[16,12]  column_6  1
    psi[16,12]  column_9  1
    psi[16,13]  OBJ       2.3465593808230878e-02
    psi[16,13]  column_7  1
    psi[16,13]  column_8  1
    psi[16,13]  column_12  1
    psi[16,13]  column_13  1
    psi[16,21]  OBJ       3.2092358923534603e-01
    psi[16,21]  column_10  1
    psi[16,21]  column_11  1
    psi[17,8]  OBJ       6.6878875841868946e-01
    psi[17,8]  column_0  1
    psi[17,8]  column_2  1
    psi[17,8]  column_3  1
    psi[17,8]  column_4  1
    psi[17,8]  column_10  1
    psi[17,8]  column_12  1
    psi[17,9]  OBJ       1.0121495257613145e-01
    psi[17,9]  column_5  1
    psi[17,9]  column_7  1
    psi[17,9]  column_11  1
    psi[17,9]  column_13  1
    psi[17,16]  OBJ       2.2999628900517910e-01
    psi[17,16]  column_1  1
    psi[17,16]  column_6  1
    psi[17,16]  column_8  1
    psi[17,16]  column_9  1
    psi[18,11]  OBJ       0.703430029016761
    psi[18,11]  column_0  1
    psi[18,11]  column_1  1
    psi[18,11]  column_2  1
    psi[18,11]  column_3  1
    psi[18,11]  column_5  1
    psi[18,11]  column_8  1
    psi[18,11]  column_9  1
    psi[18,11]  column_10  1
    psi[18,11]  column_12  1
    psi[18,11]  column_13  1
    psi[18,20]  OBJ       2.9656997098323895e-01
    psi[18,20]  column_4  1
    psi[18,20]  column_6  1
    psi[18,20]  column_7  1
    psi[18,20]  column_11  1
    psi[19,12]  OBJ       6.3602776288420682e-01
    psi[19,12]  column_0  1
    psi[19,12]  column_1  1
    psi[19,12]  column_2  1
    psi[19,12]  column_3  1
    psi[19,12]  column_4  1
    psi[19,12]  column_5  1
    psi[19,12]  column_6  1
    psi[19,12]  column_8  1
    psi[19,12]  column_11  1
    psi[19,12]  column_12  1
    psi[19,12]  column_13  1
    psi[19,20]  OBJ       3.6397223711579318e-01
    psi[19,20]  column_7  1
    psi[19,20]  column_9  1
    psi[19,20]  column_10  1
    psi[20,13]  OBJ       6.0569674312455746e-01
    psi[20,13]  column_0  1
    psi[20,13]  column_3  1
    psi[20,13]  column_5  1
    psi[20,13]  column_6  1
    psi[20,13]  column_7  1
    psi[20,13]  column_8  1
    psi[20,13]  column_9  1
    psi[20,13]  column_10  1
    psi[20,13]  column_11  1
    psi[20,21]  OBJ       3.9430325687544254e-01
    psi[20,21]  column_1  1
    psi[20,21]  column_2  1
    psi[20,21]  column_4  1
    psi[20,21]  column_12  1
    psi[20,21]  column_13  1
    a         OBJ       1
    a         column_0  1
    a         column_1  1
    a         column_2  1
    a         column_3  1
    a         column_4  1
    a         column_5  1
    a         column_6  1
    a         column_7  1
    a         column_8  1
    a         column_9  1
    a         column_10  1
    a         column_11  1
    a         column_12  1
    a         column_13  1
RHS
    RHS1      column_0  2.3037127760972e-17
    RHS1      column_1  6.8149466192170841e-02
    RHS1      column_2  5.9913793103448305e-02
    RHS1      column_3  3.7336244541484744e-02
    RHS1      column_4  8.6926461345066028e-02
    RHS1      column_5  4.2186652197504095e-02
    RHS1      column_6  9.9799196787148617e-02
    RHS1      column_7  9.3277805821975451e-02
    RHS1      column_8  1.0129813788960824e-01
    RHS1      column_9  0.0894021739130435
    RHS1      column_10  7.9646169701133640e-02
    RHS1      column_11  8.8371501272264646e-02
    RHS1      column_12  0.0827817966592135
    RHS1      column_13  0.0855903163787128
BOUNDS
 FX BND1      psi[1,11]  0
 FX BND1      psi[2,14]  0
 FX BND1      psi[3,15]  0
 FX BND1      psi[4,11]  0
 FX BND1      psi[5,11]  0
 LO BND1      psi[5,18]  -0.05
 UP BND1      psi[5,18]  0.05
 FX BND1      psi[6,11]  0
 LO BND1      psi[6,20]  -0.05
 UP BND1      psi[6,20]  0.05
 FX BND1      psi[7,10]  0
 FX BND1      psi[8,11]  0
 FX BND1      psi[9,9]  0
 FX BND1      psi[10,16]  0
 FX BND1      psi[11,17]  0
 FX BND1      psi[12,10]  0
 LO BND1      psi[12,18]  -0.05
 UP BND1      psi[12,18]  0.05
 FX BND1      psi[13,13]  0
 FX BND1      psi[14,13]  0
 FX BND1      psi[15,14]  0
 FX BND1      psi[16,12]  0
 LO BND1      psi[16,13]  -0.05
 UP BND1      psi[16,13]  0.05
 LO BND1      psi[16,21]  -0.05
 UP BND1      psi[16,21]  0.05
 FX BND1      psi[17,8]  0
 LO BND1      psi[17,9]  -0.05
 UP BND1      psi[17,9]  0.05
 LO BND1      psi[17,16]  -0.05
 UP BND1      psi[17,16]  0.05
 FX BND1      psi[18,11]  0
 LO BND1      psi[18,20]  -0.05
 UP BND1      psi[18,20]  0.05
 FX BND1      psi[19,12]  0
 LO BND1      psi[19,20]  -0.05
 UP BND1      psi[19,20]  0.05
 FX BND1      psi[20,13]  0
 LO BND1      psi[20,21]  -0.05
 UP BND1      psi[20,21]  0.05
 FR BND1      a       
ENDATA
