* Signature: 0x41de7688ff121982
NAME 
ROWS
 N  OBJ
 E  dual_original_0
 E  dual_original_1
 E  dual_original_2
 E  dual_original_3
 E  dual_original_4
 G  nominal_fixed_level
 G  dev_pos_1_1
 G  dev_neg_1_1
 G  dev_pos_2_1
 G  dev_neg_2_1
 G  dev_beta_pos
 G  dev_beta_neg
 L  dual_hull_lambda_00000
 L  dual_hull_lambda_00001
 L  dual_hull_lambda_00002
COLUMNS
    pi_0      dual_original_1  1
    pi_0      dual_original_2  1
    pi_0      nominal_fixed_level  1
    pi_1      dual_original_3  1
    pi_1      dual_original_4  1
    pi_1      nominal_fixed_level  1
    pi_2      dual_original_2  1
    pi_2      dual_original_4  1
    pi_2      nominal_fixed_level  1
    pi_3      nominal_fixed_level  1
    pi_3      dual_hull_lambda_00000  1
    pi_3      dual_hull_lambda_00001  1
    pi_3      dual_hull_lambda_00002  1
    pi_4      dual_original_2  -1
    pi_4      dev_pos_1_1  -1
    pi_4      dev_neg_1_1  1
    pi_4      dual_hull_lambda_00000  1
    pi_4      dual_hull_lambda_00002  1
    pi_5      dual_original_4  -1
    pi_5      dev_pos_2_1  -1
    pi_5      dev_neg_2_1  1
    pi_5      dual_hull_lambda_00001  1
    pi_5      dual_hull_lambda_00002  1
    pi_6      dual_original_0  1
    pi_6      nominal_fixed_level  1e-08
    pi_6      dev_beta_pos  -1
    pi_6      dev_beta_neg  1
    pi_6      dual_hull_lambda_00000  -0.5
    pi_6      dual_hull_lambda_00001  -0.5
    lb_0      dual_original_0  1
    ub_0      dual_original_0  1
    ub_0      nominal_fixed_level  1
    lb_1      dual_original_1  1
    ub_1      dual_original_1  1
    ub_1      nominal_fixed_level  1
    lb_2      dual_original_2  1
    ub_2      dual_original_2  1
    ub_2      nominal_fixed_level  1
    lb_3      dual_original_3  1
    ub_3      dual_original_3  1
    ub_3      nominal_fixed_level  1
    lb_4      dual_original_4  1
    ub_4      dual_original_4  1
    ub_4      nominal_fixed_level  1
    dev_1_1   OBJ       1
    dev_1_1   dev_pos_1_1  1
    dev_1_1   dev_neg_1_1  1
    dev_2_1   OBJ       1
    dev_2_1   dev_pos_2_1  1
    dev_2_1   dev_neg_2_1  1
    dev_beta  OBJ       1
    dev_beta  dev_beta_pos  1
    dev_beta  dev_beta_neg  1
RHS
    RHS1      dual_original_0  1
    RHS1      dual_original_2  0.2
    RHS1      dual_original_4  0.3
    RHS1      nominal_fixed_level  0.4900001
    RHS1      dev_pos_1_1  -0.125
    RHS1      dev_neg_1_1  0.125
    RHS1      dev_pos_2_1  -0.125
    RHS1      dev_neg_2_1  0.125
    RHS1      dev_beta_pos  -1
    RHS1      dev_beta_neg  1
BOUNDS
 FR BND1      pi_0    
 FR BND1      pi_1    
 FR BND1      pi_3    
 FR BND1      pi_4    
 FR BND1      pi_5    
 MI BND1      ub_0    
 UP BND1      ub_0      0
 MI BND1      ub_1    
 UP BND1      ub_1      0
 MI BND1      ub_2    
 UP BND1      ub_2      0
 MI BND1      ub_3    
 UP BND1      ub_3      0
 MI BND1      ub_4    
 UP BND1      ub_4      0
ENDATA
