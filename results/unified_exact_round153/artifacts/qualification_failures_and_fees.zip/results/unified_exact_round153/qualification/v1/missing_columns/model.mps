* Signature: 0x4dd94d06d416be02
NAME 
ROWS
 N  OBJ
 G  R0      
 L  R1      
 G  R2      
 L  R3      
 G  R4      
 L  R5      
 G  R6      
 L  R7      
 G  R8      
 L  R9      
 E  R10     
 E  R11     
 E  R12     
 G  R13     
 G  R14     
 E  R15     
 E  R16     
 G  R17     
 L  R18     
 G  R19     
 L  R20     
 G  R21     
 L  R22     
 G  R23     
 L  R24     
 G  R25     
 L  R26     
 E  R27     
 E  R28     
 E  R29     
 G  R30     
 G  R31     
 E  R32     
 E  R33     
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 G  R38     
 L  R39     
 G  R40     
 L  R41     
 G  R42     
 L  R43     
 E  R44     
 E  R45     
 E  R46     
 G  R47     
 G  R48     
 E  R49     
 E  R50     
 G  R51     
 G  R52     
 G  R53     
 G  R54     
 G  R55     
 G  R56     
 L  R57     
 G  R58     
 L  R59     
 G  r152_known_AP
 G  r152_known_GD_low
 G  r152_known_GD_high
 G  r152_known_stock_loL
 G  r152_known_stock_loU
 L  r152_known_stock_hiL
 L  r152_known_stock_hiU
 G  r152_known_TC
 G  r152_known_TC2
 G  r152_known_count_0_low
 L  r152_known_count_0_high
 G  r152_known_count_1_low
 L  r152_known_count_1_high
 G  r152_known_count_2_low
 L  r152_known_count_2_high
 G  r152_known_count_3_low
 L  r152_known_count_3_high
 G  r152_known_count_4_low
 L  r152_known_count_4_high
 G  r152_known_count_5_low
 L  r152_known_count_5_high
 G  r152_known_count_6_low
 L  r152_known_count_6_high
 G  r152_known_count_7_low
 L  r152_known_count_7_high
 G  r152_known_CP_0_loL
 G  r152_known_CP_0_loU
 L  r152_known_CP_0_hiL
 L  r152_known_CP_0_hiU
 G  r152_known_CP_1_loL
 G  r152_known_CP_1_loU
 L  r152_known_CP_1_hiL
 L  r152_known_CP_1_hiU
 G  r152_known_CP_2_loL
 G  r152_known_CP_2_loU
 L  r152_known_CP_2_hiL
 L  r152_known_CP_2_hiU
 G  r152_known_CP_3_loL
 G  r152_known_CP_3_loU
 L  r152_known_CP_3_hiL
 L  r152_known_CP_3_hiU
 G  r152_known_CP_4_loL
 G  r152_known_CP_4_loU
 L  r152_known_CP_4_hiL
 L  r152_known_CP_4_hiU
 G  r152_known_CP_5_loL
 G  r152_known_CP_5_loU
 L  r152_known_CP_5_hiL
 L  r152_known_CP_5_hiU
 G  r152_known_CP_6_loL
 G  r152_known_CP_6_loU
 L  r152_known_CP_6_hiL
 L  r152_known_CP_6_hiU
 G  r152_known_CP_7_loL
 G  r152_known_CP_7_loU
 L  r152_known_CP_7_hiL
 L  r152_known_CP_7_hiU
 E  R117    
 E  R118    
 E  R119    
 E  R120    
 E  R121    
 E  R122    
 E  R123    
 E  R124    
 E  R125    
 E  R126    
 E  R127    
 E  R128    
 E  R129    
 E  R130    
 E  R131    
 E  hull_convexity
 E  hull_link_1_1
 E  hull_link_1_2
 E  hull_link_1_3
 E  hull_link_1_4
 E  hull_link_2_1
 E  hull_link_2_2
 E  hull_link_2_3
 E  hull_link_2_4
 E  hull_link_3_1
 E  hull_link_3_2
 E  hull_link_3_3
 E  hull_link_3_4
 G  hull_gini
COLUMNS
    state_1_0  R1        -0.75
    state_1_0  R10       1
    state_1_0  r152_known_AP  -0.125
    state_1_0  r152_known_GD_low  -1
    state_1_0  R117      1
    state_1_1  R3        -0.75
    state_1_1  R10       1
    state_1_1  R11       -1
    state_1_1  r152_known_TC  -0.5
    state_1_1  r152_known_count_0_low  1
    state_1_1  r152_known_count_0_high  1
    state_1_1  r152_known_count_1_low  1
    state_1_1  r152_known_count_1_high  1
    state_1_1  r152_known_count_2_low  1
    state_1_1  r152_known_count_2_high  1
    state_1_1  r152_known_count_3_low  1
    state_1_1  r152_known_count_3_high  1
    state_1_1  r152_known_CP_0_loU  -0.75
    state_1_1  r152_known_CP_0_hiL  -0.75
    state_1_1  r152_known_CP_1_loU  -0.75
    state_1_1  r152_known_CP_1_hiL  -0.75
    state_1_1  r152_known_CP_2_loU  -0.75
    state_1_1  r152_known_CP_2_hiL  -0.75
    state_1_1  r152_known_CP_3_loU  -0.75
    state_1_1  r152_known_CP_3_hiL  -0.75
    state_1_1  R118      1
    state_1_1  hull_link_1_1  -1
    state_1_2  R5        -0.75
    state_1_2  R10       1
    state_1_2  R11       -2
    state_1_2  r152_known_AP  -0.125
    state_1_2  r152_known_GD_high  -7.1428571428571419e-01
    state_1_2  r152_known_TC  -2
    state_1_2  r152_known_TC2  -1.5
    state_1_2  r152_known_count_0_low  1
    state_1_2  r152_known_count_0_high  1
    state_1_2  r152_known_count_1_low  1
    state_1_2  r152_known_count_1_high  1
    state_1_2  r152_known_count_2_low  1
    state_1_2  r152_known_count_2_high  1
    state_1_2  r152_known_count_3_low  1
    state_1_2  r152_known_count_3_high  1
    state_1_2  r152_known_count_4_low  1
    state_1_2  r152_known_count_4_high  1
    state_1_2  r152_known_count_5_low  1
    state_1_2  r152_known_count_5_high  1
    state_1_2  r152_known_CP_0_loU  -0.75
    state_1_2  r152_known_CP_0_hiL  -0.75
    state_1_2  r152_known_CP_1_loU  -0.75
    state_1_2  r152_known_CP_1_hiL  -0.75
    state_1_2  r152_known_CP_2_loU  -0.75
    state_1_2  r152_known_CP_2_hiL  -0.75
    state_1_2  r152_known_CP_3_loU  -0.75
    state_1_2  r152_known_CP_3_hiL  -0.75
    state_1_2  r152_known_CP_4_loU  -0.75
    state_1_2  r152_known_CP_4_hiL  -0.75
    state_1_2  r152_known_CP_5_loU  -0.75
    state_1_2  r152_known_CP_5_hiL  -0.75
    state_1_2  R119      1
    state_1_2  hull_link_1_2  -1
    state_1_3  R7        -0.75
    state_1_3  R10       1
    state_1_3  R11       -3
    state_1_3  r152_known_AP  -0.25
    state_1_3  r152_known_GD_high  -1.25
    state_1_3  r152_known_TC  -4
    state_1_3  r152_known_TC2  -3.5
    state_1_3  r152_known_count_0_low  1
    state_1_3  r152_known_count_0_high  1
    state_1_3  r152_known_count_1_low  1
    state_1_3  r152_known_count_1_high  1
    state_1_3  r152_known_count_2_low  1
    state_1_3  r152_known_count_2_high  1
    state_1_3  r152_known_count_3_low  1
    state_1_3  r152_known_count_3_high  1
    state_1_3  r152_known_count_4_low  1
    state_1_3  r152_known_count_4_high  1
    state_1_3  r152_known_count_5_low  1
    state_1_3  r152_known_count_5_high  1
    state_1_3  r152_known_count_6_low  1
    state_1_3  r152_known_count_6_high  1
    state_1_3  r152_known_CP_0_loU  -0.75
    state_1_3  r152_known_CP_0_hiL  -0.75
    state_1_3  r152_known_CP_1_loU  -0.75
    state_1_3  r152_known_CP_1_hiL  -0.75
    state_1_3  r152_known_CP_2_loU  -0.75
    state_1_3  r152_known_CP_2_hiL  -0.75
    state_1_3  r152_known_CP_3_loU  -0.75
    state_1_3  r152_known_CP_3_hiL  -0.75
    state_1_3  r152_known_CP_4_loU  -0.75
    state_1_3  r152_known_CP_4_hiL  -0.75
    state_1_3  r152_known_CP_5_loU  -0.75
    state_1_3  r152_known_CP_5_hiL  -0.75
    state_1_3  r152_known_CP_6_loU  -0.75
    state_1_3  r152_known_CP_6_hiL  -0.75
    state_1_3  R120      1
    state_1_3  hull_link_1_3  -1
    state_1_4  R9        -0.75
    state_1_4  R10       1
    state_1_4  R11       -4
    state_1_4  r152_known_AP  -0.375
    state_1_4  r152_known_GD_high  -1.6666666666666665e+00
    state_1_4  r152_known_TC  -6
    state_1_4  r152_known_TC2  -5.5
    state_1_4  r152_known_count_0_low  1
    state_1_4  r152_known_count_0_high  1
    state_1_4  r152_known_count_1_low  1
    state_1_4  r152_known_count_1_high  1
    state_1_4  r152_known_count_2_low  1
    state_1_4  r152_known_count_2_high  1
    state_1_4  r152_known_count_3_low  1
    state_1_4  r152_known_count_3_high  1
    state_1_4  r152_known_count_4_low  1
    state_1_4  r152_known_count_4_high  1
    state_1_4  r152_known_count_5_low  1
    state_1_4  r152_known_count_5_high  1
    state_1_4  r152_known_count_6_low  1
    state_1_4  r152_known_count_6_high  1
    state_1_4  r152_known_count_7_low  1
    state_1_4  r152_known_count_7_high  1
    state_1_4  r152_known_CP_0_loU  -0.75
    state_1_4  r152_known_CP_0_hiL  -0.75
    state_1_4  r152_known_CP_1_loU  -0.75
    state_1_4  r152_known_CP_1_hiL  -0.75
    state_1_4  r152_known_CP_2_loU  -0.75
    state_1_4  r152_known_CP_2_hiL  -0.75
    state_1_4  r152_known_CP_3_loU  -0.75
    state_1_4  r152_known_CP_3_hiL  -0.75
    state_1_4  r152_known_CP_4_loU  -0.75
    state_1_4  r152_known_CP_4_hiL  -0.75
    state_1_4  r152_known_CP_5_loU  -0.75
    state_1_4  r152_known_CP_5_hiL  -0.75
    state_1_4  r152_known_CP_6_loU  -0.75
    state_1_4  r152_known_CP_6_hiL  -0.75
    state_1_4  r152_known_CP_7_loU  -0.75
    state_1_4  r152_known_CP_7_hiL  -0.75
    state_1_4  R121      1
    state_1_4  hull_link_1_4  -1
    state_2_0  R18       -0.75
    state_2_0  R27       1
    state_2_0  r152_known_AP  -0.125
    state_2_0  r152_known_GD_low  -1
    state_2_0  R122      1
    state_2_1  R20       -0.75
    state_2_1  R27       1
    state_2_1  R28       -1
    state_2_1  r152_known_AP  -0.0625
    state_2_1  r152_known_TC2  0.5
    state_2_1  r152_known_count_0_low  1
    state_2_1  r152_known_count_0_high  1
    state_2_1  r152_known_count_1_low  1
    state_2_1  r152_known_count_1_high  1
    state_2_1  r152_known_CP_0_loU  -0.75
    state_2_1  r152_known_CP_0_hiL  -0.75
    state_2_1  r152_known_CP_1_loU  -0.75
    state_2_1  r152_known_CP_1_hiL  -0.75
    state_2_1  R123      1
    state_2_1  hull_link_2_1  -1
    state_2_2  R22       -0.75
    state_2_2  R27       1
    state_2_2  R28       -2
    state_2_2  r152_known_TC  -0.5
    state_2_2  r152_known_count_0_low  1
    state_2_2  r152_known_count_0_high  1
    state_2_2  r152_known_count_1_low  1
    state_2_2  r152_known_count_1_high  1
    state_2_2  r152_known_count_2_low  1
    state_2_2  r152_known_count_2_high  1
    state_2_2  r152_known_count_3_low  1
    state_2_2  r152_known_count_3_high  1
    state_2_2  r152_known_CP_0_loU  -0.75
    state_2_2  r152_known_CP_0_hiL  -0.75
    state_2_2  r152_known_CP_1_loU  -0.75
    state_2_2  r152_known_CP_1_hiL  -0.75
    state_2_2  r152_known_CP_2_loU  -0.75
    state_2_2  r152_known_CP_2_hiL  -0.75
    state_2_2  r152_known_CP_3_loU  -0.75
    state_2_2  r152_known_CP_3_hiL  -0.75
    state_2_2  R124      1
    state_2_2  hull_link_2_2  -1
    state_2_3  R24       -0.75
    state_2_3  R27       1
    state_2_3  R28       -3
    state_2_3  r152_known_AP  -0.0625
    state_2_3  r152_known_GD_high  -2.8571428571428570e-01
    state_2_3  r152_known_TC  -1
    state_2_3  r152_known_TC2  -0.5
    state_2_3  r152_known_count_0_low  1
    state_2_3  r152_known_count_0_high  1
    state_2_3  r152_known_count_1_low  1
    state_2_3  r152_known_count_1_high  1
    state_2_3  r152_known_count_2_low  1
    state_2_3  r152_known_count_2_high  1
    state_2_3  r152_known_count_3_low  1
    state_2_3  r152_known_count_3_high  1
    state_2_3  r152_known_count_4_low  1
    state_2_3  r152_known_count_4_high  1
    state_2_3  r152_known_CP_0_loU  -0.75
    state_2_3  r152_known_CP_0_hiL  -0.75
    state_2_3  r152_known_CP_1_loU  -0.75
    state_2_3  r152_known_CP_1_hiL  -0.75
    state_2_3  r152_known_CP_2_loU  -0.75
    state_2_3  r152_known_CP_2_hiL  -0.75
    state_2_3  r152_known_CP_3_loU  -0.75
    state_2_3  r152_known_CP_3_hiL  -0.75
    state_2_3  r152_known_CP_4_loU  -0.75
    state_2_3  r152_known_CP_4_hiL  -0.75
    state_2_3  R125      1
    state_2_3  hull_link_2_3  -1
    state_2_4  R26       -0.75
    state_2_4  R27       1
    state_2_4  R28       -4
    state_2_4  r152_known_AP  -0.125
    state_2_4  r152_known_GD_high  -1
    state_2_4  r152_known_TC  -2
    state_2_4  r152_known_TC2  -1.5
    state_2_4  r152_known_count_0_low  1
    state_2_4  r152_known_count_0_high  1
    state_2_4  r152_known_count_1_low  1
    state_2_4  r152_known_count_1_high  1
    state_2_4  r152_known_count_2_low  1
    state_2_4  r152_known_count_2_high  1
    state_2_4  r152_known_count_3_low  1
    state_2_4  r152_known_count_3_high  1
    state_2_4  r152_known_count_4_low  1
    state_2_4  r152_known_count_4_high  1
    state_2_4  r152_known_count_5_low  1
    state_2_4  r152_known_count_5_high  1
    state_2_4  r152_known_CP_0_loU  -0.75
    state_2_4  r152_known_CP_0_hiL  -0.75
    state_2_4  r152_known_CP_1_loU  -0.75
    state_2_4  r152_known_CP_1_hiL  -0.75
    state_2_4  r152_known_CP_2_loU  -0.75
    state_2_4  r152_known_CP_2_hiL  -0.75
    state_2_4  r152_known_CP_3_loU  -0.75
    state_2_4  r152_known_CP_3_hiL  -0.75
    state_2_4  r152_known_CP_4_loU  -0.75
    state_2_4  r152_known_CP_4_hiL  -0.75
    state_2_4  r152_known_CP_5_loU  -0.75
    state_2_4  r152_known_CP_5_hiL  -0.75
    state_2_4  R126      1
    state_2_4  hull_link_2_4  -1
    state_3_0  R35       -0.75
    state_3_0  R44       1
    state_3_0  r152_known_AP  -0.125
    state_3_0  r152_known_GD_low  -1
    state_3_0  R127      1
    state_3_1  R37       -0.75
    state_3_1  R44       1
    state_3_1  R45       -1
    state_3_1  r152_known_AP  -0.09375
    state_3_1  r152_known_TC2  0.25
    state_3_1  r152_known_count_0_low  1
    state_3_1  r152_known_count_0_high  1
    state_3_1  r152_known_CP_0_loU  -0.75
    state_3_1  r152_known_CP_0_hiL  -0.75
    state_3_1  R128      1
    state_3_1  hull_link_3_1  -1
    state_3_2  R39       -0.75
    state_3_2  R44       1
    state_3_2  R45       -2
    state_3_2  r152_known_AP  -0.0625
    state_3_2  r152_known_TC2  0.5
    state_3_2  r152_known_count_0_low  1
    state_3_2  r152_known_count_0_high  1
    state_3_2  r152_known_count_1_low  1
    state_3_2  r152_known_count_1_high  1
    state_3_2  r152_known_CP_0_loU  -0.75
    state_3_2  r152_known_CP_0_hiL  -0.75
    state_3_2  r152_known_CP_1_loU  -0.75
    state_3_2  r152_known_CP_1_hiL  -0.75
    state_3_2  R129      1
    state_3_2  hull_link_3_2  -1
    state_3_3  R41       -0.75
    state_3_3  R44       1
    state_3_3  R45       -3
    state_3_3  r152_known_AP  -0.03125
    state_3_3  r152_known_TC  -0.25
    state_3_3  r152_known_TC2  0.25
    state_3_3  r152_known_count_0_low  1
    state_3_3  r152_known_count_0_high  1
    state_3_3  r152_known_count_1_low  1
    state_3_3  r152_known_count_1_high  1
    state_3_3  r152_known_count_2_low  1
    state_3_3  r152_known_count_2_high  1
    state_3_3  r152_known_CP_0_loU  -0.75
    state_3_3  r152_known_CP_0_hiL  -0.75
    state_3_3  r152_known_CP_1_loU  -0.75
    state_3_3  r152_known_CP_1_hiL  -0.75
    state_3_3  r152_known_CP_2_loU  -0.75
    state_3_3  r152_known_CP_2_hiL  -0.75
    state_3_3  R130      1
    state_3_3  hull_link_3_3  -1
    state_3_4  R43       -0.75
    state_3_4  R44       1
    state_3_4  R45       -4
    state_3_4  r152_known_GD_high  -0.5
    state_3_4  r152_known_TC  -0.5
    state_3_4  r152_known_count_0_low  1
    state_3_4  r152_known_count_0_high  1
    state_3_4  r152_known_count_1_low  1
    state_3_4  r152_known_count_1_high  1
    state_3_4  r152_known_count_2_low  1
    state_3_4  r152_known_count_2_high  1
    state_3_4  r152_known_count_3_low  1
    state_3_4  r152_known_count_3_high  1
    state_3_4  r152_known_CP_0_loU  -0.75
    state_3_4  r152_known_CP_0_hiL  -0.75
    state_3_4  r152_known_CP_1_loU  -0.75
    state_3_4  r152_known_CP_1_hiL  -0.75
    state_3_4  r152_known_CP_2_loU  -0.75
    state_3_4  r152_known_CP_2_hiL  -0.75
    state_3_4  r152_known_CP_3_loU  -0.75
    state_3_4  r152_known_CP_3_hiL  -0.75
    state_3_4  R131      1
    state_3_4  hull_link_3_4  -1
    G         OBJ       1
    G         R15       -1
    G         R32       -1
    G         R49       -1
    G         r152_known_GD_low  3
    G         r152_known_GD_high  3
    G         r152_known_stock_loL  -2
    G         r152_known_stock_loU  -5
    G         r152_known_stock_hiL  -2
    G         r152_known_stock_hiU  -5
    G         r152_known_CP_0_loL  -1
    G         r152_known_CP_0_loU  -3
    G         r152_known_CP_0_hiL  -1
    G         r152_known_CP_0_hiU  -3
    G         r152_known_CP_1_loL  -1
    G         r152_known_CP_1_loU  -3
    G         r152_known_CP_1_hiL  -1
    G         r152_known_CP_1_hiU  -3
    G         r152_known_CP_2_loU  -2
    G         r152_known_CP_2_hiU  -2
    G         r152_known_CP_3_loU  -2
    G         r152_known_CP_3_hiU  -2
    G         r152_known_CP_4_loU  -2
    G         r152_known_CP_4_hiU  -2
    G         r152_known_CP_5_loU  -1
    G         r152_known_CP_5_hiU  -1
    G         r152_known_CP_6_loU  -1
    G         r152_known_CP_6_hiU  -1
    G         r152_known_CP_7_loU  -1
    G         r152_known_CP_7_hiU  -1
    G         hull_gini  1
    Y_1       R11       1
    Y_1       R12       -1
    Y_1       R58       1
    Y_1       R59       1
    Y_1       r152_known_stock_loU  -0.75
    Y_1       r152_known_stock_hiL  -0.75
    r_1       R12       1
    r_1       R13       -1
    r_1       R14       1
    r_1       R51       -1
    r_1       R52       1
    r_1       R53       -1
    r_1       R54       1
    e_1       OBJ       0.125
    e_1       R13       1
    e_1       R14       1
    e_1       r152_known_AP  0.125
    zprod_1   R16       1
    zprod_1   R57       -3
    zprod_1   r152_known_stock_loL  1
    zprod_1   r152_known_stock_loU  1
    zprod_1   r152_known_stock_hiL  1
    zprod_1   r152_known_stock_hiU  1
    state_g_1_0  R0        1
    state_g_1_0  R1        1
    state_g_1_0  R15       1
    state_g_1_1  R2        1
    state_g_1_1  R3        1
    state_g_1_1  R15       1
    state_g_1_1  R16       -1
    state_g_1_1  r152_known_CP_0_loL  1
    state_g_1_1  r152_known_CP_0_loU  1
    state_g_1_1  r152_known_CP_0_hiL  1
    state_g_1_1  r152_known_CP_0_hiU  1
    state_g_1_1  r152_known_CP_1_loL  1
    state_g_1_1  r152_known_CP_1_loU  1
    state_g_1_1  r152_known_CP_1_hiL  1
    state_g_1_1  r152_known_CP_1_hiU  1
    state_g_1_1  r152_known_CP_2_loL  1
    state_g_1_1  r152_known_CP_2_loU  1
    state_g_1_1  r152_known_CP_2_hiL  1
    state_g_1_1  r152_known_CP_2_hiU  1
    state_g_1_1  r152_known_CP_3_loL  1
    state_g_1_1  r152_known_CP_3_loU  1
    state_g_1_1  r152_known_CP_3_hiL  1
    state_g_1_1  r152_known_CP_3_hiU  1
    state_g_1_2  R4        1
    state_g_1_2  R5        1
    state_g_1_2  R15       1
    state_g_1_2  R16       -2
    state_g_1_2  r152_known_CP_0_loL  1
    state_g_1_2  r152_known_CP_0_loU  1
    state_g_1_2  r152_known_CP_0_hiL  1
    state_g_1_2  r152_known_CP_0_hiU  1
    state_g_1_2  r152_known_CP_1_loL  1
    state_g_1_2  r152_known_CP_1_loU  1
    state_g_1_2  r152_known_CP_1_hiL  1
    state_g_1_2  r152_known_CP_1_hiU  1
    state_g_1_2  r152_known_CP_2_loL  1
    state_g_1_2  r152_known_CP_2_loU  1
    state_g_1_2  r152_known_CP_2_hiL  1
    state_g_1_2  r152_known_CP_2_hiU  1
    state_g_1_2  r152_known_CP_3_loL  1
    state_g_1_2  r152_known_CP_3_loU  1
    state_g_1_2  r152_known_CP_3_hiL  1
    state_g_1_2  r152_known_CP_3_hiU  1
    state_g_1_2  r152_known_CP_4_loL  1
    state_g_1_2  r152_known_CP_4_loU  1
    state_g_1_2  r152_known_CP_4_hiL  1
    state_g_1_2  r152_known_CP_4_hiU  1
    state_g_1_2  r152_known_CP_5_loL  1
    state_g_1_2  r152_known_CP_5_loU  1
    state_g_1_2  r152_known_CP_5_hiL  1
    state_g_1_2  r152_known_CP_5_hiU  1
    state_g_1_3  R6        1
    state_g_1_3  R7        1
    state_g_1_3  R15       1
    state_g_1_3  R16       -3
    state_g_1_3  r152_known_CP_0_loL  1
    state_g_1_3  r152_known_CP_0_loU  1
    state_g_1_3  r152_known_CP_0_hiL  1
    state_g_1_3  r152_known_CP_0_hiU  1
    state_g_1_3  r152_known_CP_1_loL  1
    state_g_1_3  r152_known_CP_1_loU  1
    state_g_1_3  r152_known_CP_1_hiL  1
    state_g_1_3  r152_known_CP_1_hiU  1
    state_g_1_3  r152_known_CP_2_loL  1
    state_g_1_3  r152_known_CP_2_loU  1
    state_g_1_3  r152_known_CP_2_hiL  1
    state_g_1_3  r152_known_CP_2_hiU  1
    state_g_1_3  r152_known_CP_3_loL  1
    state_g_1_3  r152_known_CP_3_loU  1
    state_g_1_3  r152_known_CP_3_hiL  1
    state_g_1_3  r152_known_CP_3_hiU  1
    state_g_1_3  r152_known_CP_4_loL  1
    state_g_1_3  r152_known_CP_4_loU  1
    state_g_1_3  r152_known_CP_4_hiL  1
    state_g_1_3  r152_known_CP_4_hiU  1
    state_g_1_3  r152_known_CP_5_loL  1
    state_g_1_3  r152_known_CP_5_loU  1
    state_g_1_3  r152_known_CP_5_hiL  1
    state_g_1_3  r152_known_CP_5_hiU  1
    state_g_1_3  r152_known_CP_6_loL  1
    state_g_1_3  r152_known_CP_6_loU  1
    state_g_1_3  r152_known_CP_6_hiL  1
    state_g_1_3  r152_known_CP_6_hiU  1
    state_g_1_4  R8        1
    state_g_1_4  R9        1
    state_g_1_4  R15       1
    state_g_1_4  R16       -4
    state_g_1_4  r152_known_CP_0_loL  1
    state_g_1_4  r152_known_CP_0_loU  1
    state_g_1_4  r152_known_CP_0_hiL  1
    state_g_1_4  r152_known_CP_0_hiU  1
    state_g_1_4  r152_known_CP_1_loL  1
    state_g_1_4  r152_known_CP_1_loU  1
    state_g_1_4  r152_known_CP_1_hiL  1
    state_g_1_4  r152_known_CP_1_hiU  1
    state_g_1_4  r152_known_CP_2_loL  1
    state_g_1_4  r152_known_CP_2_loU  1
    state_g_1_4  r152_known_CP_2_hiL  1
    state_g_1_4  r152_known_CP_2_hiU  1
    state_g_1_4  r152_known_CP_3_loL  1
    state_g_1_4  r152_known_CP_3_loU  1
    state_g_1_4  r152_known_CP_3_hiL  1
    state_g_1_4  r152_known_CP_3_hiU  1
    state_g_1_4  r152_known_CP_4_loL  1
    state_g_1_4  r152_known_CP_4_loU  1
    state_g_1_4  r152_known_CP_4_hiL  1
    state_g_1_4  r152_known_CP_4_hiU  1
    state_g_1_4  r152_known_CP_5_loL  1
    state_g_1_4  r152_known_CP_5_loU  1
    state_g_1_4  r152_known_CP_5_hiL  1
    state_g_1_4  r152_known_CP_5_hiU  1
    state_g_1_4  r152_known_CP_6_loL  1
    state_g_1_4  r152_known_CP_6_loU  1
    state_g_1_4  r152_known_CP_6_hiL  1
    state_g_1_4  r152_known_CP_6_hiU  1
    state_g_1_4  r152_known_CP_7_loL  1
    state_g_1_4  r152_known_CP_7_loU  1
    state_g_1_4  r152_known_CP_7_hiL  1
    state_g_1_4  r152_known_CP_7_hiU  1
    Y_2       R28       1
    Y_2       R29       -0.5
    Y_2       R58       1
    Y_2       R59       1
    Y_2       r152_known_stock_loU  -0.75
    Y_2       r152_known_stock_hiL  -0.75
    r_2       R29       1
    r_2       R30       -1
    r_2       R31       1
    r_2       R51       1
    r_2       R52       -1
    r_2       R55       -1
    r_2       R56       1
    e_2       OBJ       0.125
    e_2       R30       1
    e_2       R31       1
    e_2       r152_known_AP  0.125
    zprod_2   R33       1
    zprod_2   R57       -1.5
    zprod_2   r152_known_stock_loL  1
    zprod_2   r152_known_stock_loU  1
    zprod_2   r152_known_stock_hiL  1
    zprod_2   r152_known_stock_hiU  1
    state_g_2_0  R17       1
    state_g_2_0  R18       1
    state_g_2_0  R32       1
    state_g_2_1  R19       1
    state_g_2_1  R20       1
    state_g_2_1  R32       1
    state_g_2_1  R33       -1
    state_g_2_1  r152_known_CP_0_loL  1
    state_g_2_1  r152_known_CP_0_loU  1
    state_g_2_1  r152_known_CP_0_hiL  1
    state_g_2_1  r152_known_CP_0_hiU  1
    state_g_2_1  r152_known_CP_1_loL  1
    state_g_2_1  r152_known_CP_1_loU  1
    state_g_2_1  r152_known_CP_1_hiL  1
    state_g_2_1  r152_known_CP_1_hiU  1
    state_g_2_2  R21       1
    state_g_2_2  R22       1
    state_g_2_2  R32       1
    state_g_2_2  R33       -2
    state_g_2_2  r152_known_CP_0_loL  1
    state_g_2_2  r152_known_CP_0_loU  1
    state_g_2_2  r152_known_CP_0_hiL  1
    state_g_2_2  r152_known_CP_0_hiU  1
    state_g_2_2  r152_known_CP_1_loL  1
    state_g_2_2  r152_known_CP_1_loU  1
    state_g_2_2  r152_known_CP_1_hiL  1
    state_g_2_2  r152_known_CP_1_hiU  1
    state_g_2_2  r152_known_CP_2_loL  1
    state_g_2_2  r152_known_CP_2_loU  1
    state_g_2_2  r152_known_CP_2_hiL  1
    state_g_2_2  r152_known_CP_2_hiU  1
    state_g_2_2  r152_known_CP_3_loL  1
    state_g_2_2  r152_known_CP_3_loU  1
    state_g_2_2  r152_known_CP_3_hiL  1
    state_g_2_2  r152_known_CP_3_hiU  1
    state_g_2_3  R23       1
    state_g_2_3  R24       1
    state_g_2_3  R32       1
    state_g_2_3  R33       -3
    state_g_2_3  r152_known_CP_0_loL  1
    state_g_2_3  r152_known_CP_0_loU  1
    state_g_2_3  r152_known_CP_0_hiL  1
    state_g_2_3  r152_known_CP_0_hiU  1
    state_g_2_3  r152_known_CP_1_loL  1
    state_g_2_3  r152_known_CP_1_loU  1
    state_g_2_3  r152_known_CP_1_hiL  1
    state_g_2_3  r152_known_CP_1_hiU  1
    state_g_2_3  r152_known_CP_2_loL  1
    state_g_2_3  r152_known_CP_2_loU  1
    state_g_2_3  r152_known_CP_2_hiL  1
    state_g_2_3  r152_known_CP_2_hiU  1
    state_g_2_3  r152_known_CP_3_loL  1
    state_g_2_3  r152_known_CP_3_loU  1
    state_g_2_3  r152_known_CP_3_hiL  1
    state_g_2_3  r152_known_CP_3_hiU  1
    state_g_2_3  r152_known_CP_4_loL  1
    state_g_2_3  r152_known_CP_4_loU  1
    state_g_2_3  r152_known_CP_4_hiL  1
    state_g_2_3  r152_known_CP_4_hiU  1
    state_g_2_4  R25       1
    state_g_2_4  R26       1
    state_g_2_4  R32       1
    state_g_2_4  R33       -4
    state_g_2_4  r152_known_CP_0_loL  1
    state_g_2_4  r152_known_CP_0_loU  1
    state_g_2_4  r152_known_CP_0_hiL  1
    state_g_2_4  r152_known_CP_0_hiU  1
    state_g_2_4  r152_known_CP_1_loL  1
    state_g_2_4  r152_known_CP_1_loU  1
    state_g_2_4  r152_known_CP_1_hiL  1
    state_g_2_4  r152_known_CP_1_hiU  1
    state_g_2_4  r152_known_CP_2_loL  1
    state_g_2_4  r152_known_CP_2_loU  1
    state_g_2_4  r152_known_CP_2_hiL  1
    state_g_2_4  r152_known_CP_2_hiU  1
    state_g_2_4  r152_known_CP_3_loL  1
    state_g_2_4  r152_known_CP_3_loU  1
    state_g_2_4  r152_known_CP_3_hiL  1
    state_g_2_4  r152_known_CP_3_hiU  1
    state_g_2_4  r152_known_CP_4_loL  1
    state_g_2_4  r152_known_CP_4_loU  1
    state_g_2_4  r152_known_CP_4_hiL  1
    state_g_2_4  r152_known_CP_4_hiU  1
    state_g_2_4  r152_known_CP_5_loL  1
    state_g_2_4  r152_known_CP_5_loU  1
    state_g_2_4  r152_known_CP_5_hiL  1
    state_g_2_4  r152_known_CP_5_hiU  1
    Y_3       R45       1
    Y_3       R46       -0.25
    Y_3       R58       1
    Y_3       R59       1
    Y_3       r152_known_stock_loU  -0.75
    Y_3       r152_known_stock_hiL  -0.75
    r_3       R46       1
    r_3       R47       -1
    r_3       R48       1
    r_3       R53       1
    r_3       R54       -1
    r_3       R55       1
    r_3       R56       -1
    e_3       OBJ       0.125
    e_3       R47       1
    e_3       R48       1
    e_3       r152_known_AP  0.125
    zprod_3   R50       1
    zprod_3   R57       -0.75
    zprod_3   r152_known_stock_loL  1
    zprod_3   r152_known_stock_loU  1
    zprod_3   r152_known_stock_hiL  1
    zprod_3   r152_known_stock_hiU  1
    state_g_3_0  R34       1
    state_g_3_0  R35       1
    state_g_3_0  R49       1
    state_g_3_1  R36       1
    state_g_3_1  R37       1
    state_g_3_1  R49       1
    state_g_3_1  R50       -1
    state_g_3_1  r152_known_CP_0_loL  1
    state_g_3_1  r152_known_CP_0_loU  1
    state_g_3_1  r152_known_CP_0_hiL  1
    state_g_3_1  r152_known_CP_0_hiU  1
    state_g_3_2  R38       1
    state_g_3_2  R39       1
    state_g_3_2  R49       1
    state_g_3_2  R50       -2
    state_g_3_2  r152_known_CP_0_loL  1
    state_g_3_2  r152_known_CP_0_loU  1
    state_g_3_2  r152_known_CP_0_hiL  1
    state_g_3_2  r152_known_CP_0_hiU  1
    state_g_3_2  r152_known_CP_1_loL  1
    state_g_3_2  r152_known_CP_1_loU  1
    state_g_3_2  r152_known_CP_1_hiL  1
    state_g_3_2  r152_known_CP_1_hiU  1
    state_g_3_3  R40       1
    state_g_3_3  R41       1
    state_g_3_3  R49       1
    state_g_3_3  R50       -3
    state_g_3_3  r152_known_CP_0_loL  1
    state_g_3_3  r152_known_CP_0_loU  1
    state_g_3_3  r152_known_CP_0_hiL  1
    state_g_3_3  r152_known_CP_0_hiU  1
    state_g_3_3  r152_known_CP_1_loL  1
    state_g_3_3  r152_known_CP_1_loU  1
    state_g_3_3  r152_known_CP_1_hiL  1
    state_g_3_3  r152_known_CP_1_hiU  1
    state_g_3_3  r152_known_CP_2_loL  1
    state_g_3_3  r152_known_CP_2_loU  1
    state_g_3_3  r152_known_CP_2_hiL  1
    state_g_3_3  r152_known_CP_2_hiU  1
    state_g_3_4  R42       1
    state_g_3_4  R43       1
    state_g_3_4  R49       1
    state_g_3_4  R50       -4
    state_g_3_4  r152_known_CP_0_loL  1
    state_g_3_4  r152_known_CP_0_loU  1
    state_g_3_4  r152_known_CP_0_hiL  1
    state_g_3_4  r152_known_CP_0_hiU  1
    state_g_3_4  r152_known_CP_1_loL  1
    state_g_3_4  r152_known_CP_1_loU  1
    state_g_3_4  r152_known_CP_1_hiL  1
    state_g_3_4  r152_known_CP_1_hiU  1
    state_g_3_4  r152_known_CP_2_loL  1
    state_g_3_4  r152_known_CP_2_loU  1
    state_g_3_4  r152_known_CP_2_hiL  1
    state_g_3_4  r152_known_CP_2_hiU  1
    state_g_3_4  r152_known_CP_3_loL  1
    state_g_3_4  r152_known_CP_3_loU  1
    state_g_3_4  r152_known_CP_3_hiL  1
    state_g_3_4  r152_known_CP_3_hiU  1
    h_1_2     R51       1
    h_1_2     R52       1
    h_1_2     R57       1
    h_1_2     r152_known_TC  1
    h_1_2     r152_known_TC2  1
    h_1_3     R53       1
    h_1_3     R54       1
    h_1_3     R57       1
    h_1_3     r152_known_TC  1
    h_1_3     r152_known_TC2  1
    h_2_3     R55       1
    h_2_3     R56       1
    h_2_3     R57       1
    h_2_3     r152_known_TC  1
    h_2_3     r152_known_TC2  1
    hull_lambda_00000  hull_convexity  1
    hull_lambda_00000  hull_gini  -1.6666666666666669e-01
    hull_lambda_00000  hull_link_1_1  1
    hull_lambda_00000  hull_link_2_1  1
    hull_lambda_00000  hull_link_3_2  1
RHS
    RHS1      R10       1
    RHS1      R13       -1
    RHS1      R14       1
    RHS1      R27       1
    RHS1      R30       -1
    RHS1      R31       1
    RHS1      R44       1
    RHS1      R47       -1
    RHS1      R48       1
    RHS1      R58       2
    RHS1      R59       5
    RHS1      r152_known_stock_loU  -3.75
    RHS1      r152_known_stock_hiL  -1.5
    RHS1      r152_known_TC2  1.5
    RHS1      r152_known_count_0_low  1
    RHS1      r152_known_count_0_high  3
    RHS1      r152_known_count_1_low  1
    RHS1      r152_known_count_1_high  3
    RHS1      r152_known_count_2_high  2
    RHS1      r152_known_count_3_high  2
    RHS1      r152_known_count_4_high  2
    RHS1      r152_known_count_5_high  1
    RHS1      r152_known_count_6_high  1
    RHS1      r152_known_count_7_high  1
    RHS1      r152_known_CP_0_loU  -2.25
    RHS1      r152_known_CP_0_hiL  -0.75
    RHS1      r152_known_CP_1_loU  -2.25
    RHS1      r152_known_CP_1_hiL  -0.75
    RHS1      r152_known_CP_2_loU  -1.5
    RHS1      r152_known_CP_3_loU  -1.5
    RHS1      r152_known_CP_4_loU  -1.5
    RHS1      r152_known_CP_5_loU  -0.75
    RHS1      r152_known_CP_6_loU  -0.75
    RHS1      r152_known_CP_7_loU  -0.75
    RHS1      R118      1
    RHS1      R123      0.75
    RHS1      R124      0.25
    RHS1      R129      0.5
    RHS1      R130      0.5
    RHS1      hull_convexity  1
    RHS1      hull_gini  1e-08
BOUNDS
 UP BND1      state_1_0  1
 UP BND1      state_1_1  1
 UP BND1      state_1_2  1
 UP BND1      state_1_3  1
 UP BND1      state_1_4  1
 UP BND1      state_2_0  1
 UP BND1      state_2_1  1
 UP BND1      state_2_2  1
 UP BND1      state_2_3  1
 UP BND1      state_2_4  1
 UP BND1      state_3_0  1
 UP BND1      state_3_1  1
 UP BND1      state_3_2  1
 UP BND1      state_3_3  1
 UP BND1      state_3_4  1
 UP BND1      G         0.75
 UP BND1      Y_1       4
 UP BND1      Y_2       4
 UP BND1      Y_3       4
ENDATA
