# Round144 continuation

The user explicitly requested strict execution of `goal.md` on 2026-11-01
(Asia/Shanghai). The active goal covers scientific execution, qualified full
tests where warranted, independent review, incremental paper, Draft PR,
bounded anonymous recovery and current-round cleanup. It is not complete.

The clean active tree starts at verified R143 head
066fdb672b4330f4de9e9778308f07f1752152f1. Actual main remains
b2b940c1e517a72e226ec60fc49ff19651737632 and does not contain R143; temporary
PR base is `codex/round143-reciprocal-normalization` (Open Draft PR205).
All new assets stay inside `E:/codes/ExactEBRP-work`. The original
`E:/codes/ExactEBRP`, its dirty/untracked user files and all old rounds are
protected. No applicable AGENTS.md was found in the active tree or ancestors.

The two source/compact pairs are complete. Exact Fraction PCs retain the RN
root gains to 1.7e-16/1.0e-15; actual compiled interval PCs retain them to
3.8e-15/1.4e-14. Native transport, actual writer, Start, off and containment
fixtures pass. Six offline Rank-PC witnesses were finitely reconstructed with
the goal's violation decimals; their selected station subgradients have their
own certificate identities. One saved actual RX20 upper AM-lookahead child is
also measured: inherited root-PC and full RN both give .5881075999053572.
Seven standalone LP optimizations have returned.

The CMake core now explicitly links the existing round104_compression library,
which owns the new projection arithmetic function. The measured hybrid PE
already linked that exact ObjectiveResourceCompression.o explicitly. This is
a clean-build recipe correction, with no measured production source/PE or
frozen-helper change and no repeated health experiment. Check the build recipe
while idle if further validation is needed; do not compile during the pilot.

The production candidate is V5: source commit
0b5858544 (read the full SHA in candidate_manifest.json), PE
SHA256 180126ae1ecf7db892c3fbb92faa73b517d19029e9824f62cd922e0d9e277d7b.
All four affected units were rebuilt, with the final lifecycle correction
rebuilding only PaperExternalGiniTree and relinking the verified objects.
The separate entry is scripts/paper_s2_rnp.py / config/gi_tbc_rnp_round144.json.

Qualification history must be preserved. The initial K20 qualifier failed
on a zero RN dual aggregate before Pi serialization; do not claim a full
durable dual file for that failure. Zero/tautological PC omission is now a
uniform mathematical rule. qualification02's producer returned but failed
the existing LP type-restoration/lifecycle count; it is not qualified and is
not rerun or retroactively waived. Its failed reader recovery is retained.
V5 restores the disposable source's integer types, then explicitly discards
it. qualification03 RX20 returns and passes all complete checks; its first
postverify attempts exposed the formal-proof reader's old assumption that
every LP has a formal lp_status row. A local cloned reader now excludes only
the bound source_call/source_SHA from formal cover proofs, retaining all five
source/formal Native calls in quality, lifecycle and cost checks. Recovery
uses sealed raw with zero Optimize. Delayed qualification T_verify/T_total
remain actual; they are not performance observations.

Independent non-implementer review accepts pilot_matrix.json (gate in
review/pilot_admission.json). Four frozen full-window Seed0 same-PE positions
are K35 OFF/RNP cap2400, then RX20-T1 OFF/RNP cap1200. The current running
command has advanced to round144_campaign.py run pilot 2 (K35 RN-P).
K35 OFF completed and qualified: U=.6928543586313136,
L=.558227874948532, relative gap=.19430704592625647,
T_produce=2371.082621667767, T_verify=3.985027599846944,
T_total=2375.067649267614. Its outer fee is 2375.1812990999315 seconds;
Native terminal nodes=17076, Work=4724.216965084689 and presolved columns=7647.
The first full/LP aggregates are present; pilot positions 3/4 remain unentered.
K35 RN-P is now closed and qualified: U=.6609236371735803,
L=.5454122941853422, T_produce=2371.138355425792,
T_verify=5.189243299886584, T_total=2376.3275987256784.
Its outer fee is 2376.4436512000393 seconds. U improves about 4.61%,
L falls about 2.30%, and relative gap improves from .19430704592625647
to about .17477. This is useful mixed evidence, not a stop after one endpoint.
The current command has advanced to `round144_campaign.py run pilot`, which
skips the sealed K35 pair and enters RX20-T1 OFF then RNP at full cap1200.
Use durable active_position.json/fee PID/receipt and round144_status.py.
After these two close, run the full aggregation and prioritize the RB35-T2
pair, then core K20 as warranted. Freeze its matrix and get independent
admission from the existing round144_independent_review agent first.
The same-PE K35 full-RN bridge is now attribution-relevant because RN-P keeps
the source information with no persistent RN columns and gives a stronger
incumbent/relative-gap tradeoff than historical full RN. Decide the bridge
after actual primary/resource evidence. A paid-floor control is conditional
on a real attribution/adoption question; no floor implementation exists yet.
Do not add a grid. Closed experiment cost after K35 pair is
4860.527953299694 seconds (before the active RX20 pair).

The full primary pilot is now complete: RX20 OFF/RNP both prove
.6453250303858205. Their producer/certificate times are
20.633591620717198 and 18.913826857693493 seconds; RNP total is lower by
1.4245519628748298 seconds. Closed experimental cost is
4902.70472499961 seconds before the resource pair. Independent interim review
accepts this mixed positive signal and the unchanged V5 candidate.

resource_matrix.json freezes only RB35-T2 OFF/RNP at cap2400 each;
review/resource_admission.json independently ACCEPTs actual matrix SHA,
input/lambda/T/Q/own-H/Seed0/single-thread/same-PE. K20 is not pre-entered.
Current command is `round144_campaign.py run resource 1`, exec session 7152,
which enters only RB35 OFF; inspect durable fees/resource_001 PID/receipt and
round144_status.py --brief. Once closed and qualified, run resource 2 to enter
RNP, then review the pair before deciding K20 or bridge/control work.

The physical-U trajectory CSV and K35 figure have been generated while idle.
Optional Matplotlib dependencies/cache are local under temp/round144
(document-deps, pip-cache, matplotlib-cache); no global interpreter/app
configuration was changed. Plot creation uses only qualified committed
witnesses and producer availability, not Native log time. CMake/source-entry
byte attributes and authoring/delivery scripts are prepared but not all
committed; do not accidentally stage raw or build binaries. PDF creation,
carrier compression and public recovery remain unexecuted and must wait for
timed work to be idle. PDF skill has been read; run its one operation marker
immediately before first PDF authoring, then render/inspect every page.
Use scripts/round144_status.py for small live metadata/bounded tails. Inspect
fees/pilot_001/PID.json and receipt.json before any action; never restart a
healthy or sealed producer. After position 1 completes, analyze while idle,
then run `round144_campaign.py run pilot 2` (skips closed position 1), followed
by the remaining positions. Do not edit any helper listed in the frozen
matrix during this pilot. New authoring/report scripts are separate.

Closed new experiment cost before pilot is 108.9030029997 seconds; builds are
151.5509066004 seconds separately. Inspect the durable fee ledger for current
totals. The single 28800-second experimental ceiling includes qualification,
failures, sources and all required verification; nested H/LP/MIP/Work is not
added again. No compiled/PDF/heavy-I/O work overlaps a timed producer.

After the primary pair, decide whether important regressions justify stopping
or mild mixed results warrant RB35-T2 and remaining core K20. Optional same-PE
RN bridge, paid floor, K15/RX35 or Seed1 need an actual attribution/adoption
reason and available budget. No automatic grids. All planned but unentered
positions remain explicitly unentered. Continue through decision, reports,
paper increment/PDF QA, final independent review, bounded carriers, English
Draft PR with actual base/head readback, anonymous byte/member recovery and
current-round cleanup. Never mark the active goal complete before delivery.

Source: one full RN-block dual combination; finite box support absorbs all
new-column residuals. Final transport/deletion uses signed compensation.
Same-root optimal-value preservation is conditional on exact optimal duality,
same objective and domain. It does not imply full projection or descendant
equivalence. R104's prior principle and negative full results must remain.

Latest live continuation (2026-11-01, UTC about 01:50): RB35-T2 OFF/RNP
both completed and fully qualified. OFF U=.34464262559194814,
L=.2189859496034747, relative gap=.36459992658380314; RNP
U=.36213682657245494, L=.21889565866877544, gap=.39554432853301746.
The adverse RNP U (+5.07604%) and gap (+3.09444 percentage points) must remain.
The actual RN aggregate is exactly 0<=0, so no PC is emitted; independent
small-record review verifies identical formal model hashes and own-H assets.
Do not attribute this endpoint difference to a submitted structural cut or
infer global RN redundancy. Source preparation is 2.3387603 seconds.

Independent review admits resource_k20_matrix.json, the remaining core
K20 OFF/RNP pair, full caps1200. Active exec session is 25685, command
round144_campaign.py run resource_k20. K20 OFF is closed/qualified:
U=.7168065462777502, L=.7053634485966306, gap=.01596399717684165,
T_produce=1172.3779342081398, T_cert=null, T_verify=286.738826100016,
T_total=1459.1167603081558, outer fee=1459.2913784000557; all five Native
calls returned. Its longer pure verification finished naturally with no
reader changes or waivers; retain the full actual cost. K20 RNP is now
active, about ten minutes into its full window. Source is OPTIMAL,
preparation=.4785896 seconds, source_RN_columns=662, PC_emitted=false,
formal_RN_columns=0, source_solves=1. Never restart the closed OFF or
healthy RNP. Poll durable active_position/fees/PID and round144_status.py.
Closed experiment cost before active K20 RNP is 11113.178028799593 seconds;
the authoritative ledger, not older cost aggregates, governs the balance.

Exact local_floor_witness.json now fixes the selector LP cross-section and
proves the same-objective g+p RN optimum 5/12, an attaining extension, old
row feasibility and a floor-feasible point violating PC by 1/4. The new
local_floor function in round144_offline.py executed PASS while idle and
the independent local_floor_review.md accepts the precise limited scope.
No full-routing floor dominance or paid-floor implementation is claimed.
round144_bindings.py completed successfully while idle: actual compiler
bytes and all frozen helper versions, including failed qualifiers, are bound.
The trajectory/report scripts are prepared for both K35 and RB35 figures,
and a same-PE RN line if the bridge is entered; regenerate only when timed
work is idle. Do not edit any frozen imported helper during this active pair.

After K20 closes, refresh full aggregation and obtain concrete stage review.
The reviewer still finds one K35 same-PE full-RN bridge attribution-relevant,
without treating it as a rescue of RB35. Freeze/admit it before Native.
Further floor/Seed1/optional roles require a decision-changing reason; the
current important RB35 adverse result limits stable promotion. All final
report/decision, PDF marker/export/every-page QA, final science review,
carrier packing, Draft PR, anonymous member recovery and bounded cleanup
remain required and unexecuted. Current delivered source remains V5/0b585854;
authoring changes and the CMake link recipe do not change the measured PE.

Latest continuation (UTC about 02:25): all eight core formal positions are
now fully qualified. K20 RNP closed naturally with U=.7168065462777502,
L=.7053467691454535, gap=.015987266287961977,
T_produce=1173.519130968256, T_verify=61.68774339999072,
T_total=1235.2068743682466; outer fee=1235.3950748001225. Its pure reader
completed substantially faster than OFF's 286.7388261 seconds; do not alter
these actual clocks or attribute this no-PC role's verification variation to
structural search strength. Closed G1 before the bridge is
12348.573103599716 seconds (remaining16451.426896400284).

The independent review accepts the single bridge_matrix.json
(SHA76e3aa483447e387a9ee862af23c4b029150f4b0f2afcfc3d94c4a5ead845531).
The current active exec session is 21611, command
round144_campaign.py run bridge: K35 full R143 RN, same V5 PE/source,
Seed0/own-H/full cap2400, R144 off and R143 on. It has run about20 minutes,
still healthy and open; preserve the complete window. No further Native
experiment is currently planned. The reviewer endorses research-only closure
from the full core mixed panel, with this bridge retained for representation
attribution. Floor/Seed1/extensions are not automatically added to use budget.

Figures for K35 and RB35 have been generated from all eight qualified core
positions (160 improvement events) and visually checked. They are readable
and show the late OFF RB35 improvement. Regenerate after the bridge to add
the actual same-PE full-RN K35 curve. Use the bundled Windows CPython, not
the MSYS process Python, for local Windows NumPy/Matplotlib wheels. One
ordinary failed plotting attempt used the wrong interpreter; the corrected
run succeeds and engineering/plot_dependency_setup.json records the facts,
local packages/cache and the initial installer's unset TEMP/TMP caveat.
Plot/authoring work is separate from G1. No PDF marker/authoring yet.

round144_analyze.py now also validates the actual bridge's matching
input/T/lambda/cap/source/PE/DLL/H semantics/fleet and emits RN_bridges plus
same_PE_RN_bridges.csv. Run full only when the bridge fee closes. Then make
the concrete candidate_decision study_complete=true if no required work
remains, generate final report/LP summary, update docs, final independent
science review, PDF marker/export/render/every-page QA, bounded carriers,
English Draft PR, fixed-commit anonymous bytes/members and bounded cleanup.
Do not declare the overall goal complete before those delivery steps.
