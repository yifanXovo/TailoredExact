* Signature: 0xd0367cdbaf6b0ed6
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_35_32
 E  normalized_mass_35_33
 E  normalized_ratio_35_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 E  onehot_30_53
 E  normalized_mass_30_54
 E  normalized_ratio_30_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 E  onehot_31_82
 E  normalized_mass_31_83
 E  normalized_ratio_31_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_32_111
 E  normalized_mass_32_112
 E  normalized_ratio_32_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 E  onehot_19_132
 E  normalized_mass_19_133
 E  normalized_ratio_19_134
 G  product_lb_135
 L  product_ub_136
 G  product_lb_137
 L  product_ub_138
 G  product_lb_139
 L  product_ub_140
 G  product_lb_141
 L  product_ub_142
 G  product_lb_143
 L  product_ub_144
 G  product_lb_145
 L  product_ub_146
 G  product_lb_147
 L  product_ub_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 E  onehot_26_153
 E  normalized_mass_26_154
 E  normalized_ratio_26_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 G  product_lb_160
 L  product_ub_161
 G  product_lb_162
 L  product_ub_163
 G  product_lb_164
 L  product_ub_165
 G  product_lb_166
 L  product_ub_167
 G  product_lb_168
 L  product_ub_169
 G  product_lb_170
 L  product_ub_171
 G  product_lb_172
 L  product_ub_173
 G  product_lb_174
 L  product_ub_175
 G  product_lb_176
 L  product_ub_177
 E  onehot_6_178
 E  normalized_mass_6_179
 E  normalized_ratio_6_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 G  product_lb_195
 L  product_ub_196
 G  product_lb_197
 L  product_ub_198
 G  product_lb_199
 L  product_ub_200
 G  product_lb_201
 L  product_ub_202
 G  product_lb_203
 L  product_ub_204
 G  product_lb_205
 L  product_ub_206
 G  product_lb_207
 L  product_ub_208
 G  product_lb_209
 L  product_ub_210
 G  product_lb_211
 L  product_ub_212
 G  product_lb_213
 L  product_ub_214
 E  onehot_17_215
 E  normalized_mass_17_216
 E  normalized_ratio_17_217
 G  stock_lb_218
 L  stock_ub_219
 L  parent_nonstrict_scope_220
 G  block_pair_pos_221
 G  block_pair_neg_222
 G  block_pair_pos_223
 G  block_pair_neg_224
 G  block_pair_pos_225
 G  block_pair_neg_226
 G  block_pair_pos_227
 G  block_pair_neg_228
 G  block_pair_pos_229
 G  block_pair_neg_230
 G  block_pair_pos_231
 G  block_pair_neg_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 E  normalization_277
 G  full_original_Gini_278
 E  unique_nonzero_owner_279
 E  unique_nonzero_owner_280
 E  unique_nonzero_owner_281
 E  unique_nonzero_owner_282
 E  unique_nonzero_owner_283
 E  unique_nonzero_owner_284
 E  unique_nonzero_owner_285
 E  unique_nonzero_owner_286
 E  unique_nonzero_owner_287
 E  unique_nonzero_owner_288
 E  unique_nonzero_owner_289
 E  unique_nonzero_owner_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 L  arc_capacity_368
 L  arc_capacity_369
 L  arc_capacity_370
 L  arc_capacity_371
 L  arc_capacity_372
 L  arc_capacity_373
 L  arc_capacity_374
 L  arc_capacity_375
 L  arc_capacity_376
 L  arc_capacity_377
 L  arc_capacity_378
 L  arc_capacity_379
 L  arc_capacity_380
 L  arc_capacity_381
 L  arc_capacity_382
 L  arc_capacity_383
 G  connected_order_arc_384
 L  arc_capacity_385
 G  connected_order_arc_386
 L  arc_capacity_387
 G  connected_order_arc_388
 L  arc_capacity_389
 G  connected_order_arc_390
 L  arc_capacity_391
 G  connected_order_arc_392
 L  arc_capacity_393
 G  connected_order_arc_394
 L  arc_capacity_395
 G  connected_order_arc_396
 L  arc_capacity_397
 G  connected_order_arc_398
 L  arc_capacity_399
 G  connected_order_arc_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 L  arc_capacity_408
 G  connected_order_arc_409
 L  arc_capacity_410
 G  connected_order_arc_411
 L  arc_capacity_412
 G  connected_order_arc_413
 L  arc_capacity_414
 G  connected_order_arc_415
 L  arc_capacity_416
 G  connected_order_arc_417
 L  arc_capacity_418
 G  connected_order_arc_419
 L  arc_capacity_420
 G  connected_order_arc_421
 L  arc_capacity_422
 G  connected_order_arc_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 L  arc_capacity_433
 G  connected_order_arc_434
 L  arc_capacity_435
 G  connected_order_arc_436
 L  arc_capacity_437
 G  connected_order_arc_438
 L  arc_capacity_439
 G  connected_order_arc_440
 L  arc_capacity_441
 G  connected_order_arc_442
 L  arc_capacity_443
 G  connected_order_arc_444
 L  arc_capacity_445
 G  connected_order_arc_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 G  connected_order_arc_465
 L  arc_capacity_466
 G  connected_order_arc_467
 L  arc_capacity_468
 G  connected_order_arc_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 G  connected_order_arc_488
 L  arc_capacity_489
 G  connected_order_arc_490
 L  arc_capacity_491
 G  connected_order_arc_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 G  connected_order_arc_511
 L  arc_capacity_512
 G  connected_order_arc_513
 L  arc_capacity_514
 G  connected_order_arc_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 L  arc_capacity_533
 G  connected_order_arc_534
 L  arc_capacity_535
 G  connected_order_arc_536
 L  arc_capacity_537
 G  connected_order_arc_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 L  arc_capacity_558
 G  connected_order_arc_559
 L  arc_capacity_560
 G  connected_order_arc_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 L  arc_capacity_583
 G  connected_order_arc_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 E  depot_departure_or_bypass_707
 E  depot_return_or_bypass_708
 E  out_degree_709
 E  in_degree_710
 G  order_active_lb_711
 L  order_active_ub_712
 E  segment_load_conservation_713
 G  segment_prefix_lb_714
 L  segment_prefix_ub_715
 E  out_degree_716
 E  in_degree_717
 G  order_active_lb_718
 L  order_active_ub_719
 E  segment_load_conservation_720
 G  segment_prefix_lb_721
 L  segment_prefix_ub_722
 E  out_degree_723
 E  in_degree_724
 G  order_active_lb_725
 L  order_active_ub_726
 E  segment_load_conservation_727
 G  segment_prefix_lb_728
 L  segment_prefix_ub_729
 E  out_degree_730
 E  in_degree_731
 G  order_active_lb_732
 L  order_active_ub_733
 E  segment_load_conservation_734
 G  segment_prefix_lb_735
 L  segment_prefix_ub_736
 E  out_degree_737
 E  in_degree_738
 G  order_active_lb_739
 L  order_active_ub_740
 E  segment_load_conservation_741
 G  segment_prefix_lb_742
 L  segment_prefix_ub_743
 E  out_degree_744
 E  in_degree_745
 G  order_active_lb_746
 L  order_active_ub_747
 E  service_visit_def_748
 E  free_load_conservation_749
 E  out_degree_750
 E  in_degree_751
 G  order_active_lb_752
 L  order_active_ub_753
 E  service_visit_def_754
 E  free_load_conservation_755
 E  out_degree_756
 E  in_degree_757
 G  order_active_lb_758
 L  order_active_ub_759
 E  service_visit_def_760
 E  free_load_conservation_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 E  out_degree_780
 E  in_degree_781
 G  order_active_lb_782
 L  order_active_ub_783
 E  service_visit_def_784
 E  free_load_conservation_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 G  fixed_segment_relative_order_792
 G  fixed_segment_relative_order_793
 G  fixed_segment_relative_order_794
 G  fixed_segment_relative_order_795
 L  original_T_including_depot_unload_796
 L  arc_capacity_797
 L  arc_capacity_798
 L  arc_capacity_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 L  arc_capacity_803
 L  arc_capacity_804
 L  arc_capacity_805
 L  arc_capacity_806
 L  arc_capacity_807
 L  arc_capacity_808
 L  arc_capacity_809
 L  arc_capacity_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 G  connected_order_arc_818
 L  arc_capacity_819
 G  connected_order_arc_820
 L  arc_capacity_821
 G  connected_order_arc_822
 L  arc_capacity_823
 G  connected_order_arc_824
 L  arc_capacity_825
 G  connected_order_arc_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 G  connected_order_arc_841
 L  arc_capacity_842
 G  connected_order_arc_843
 L  arc_capacity_844
 G  connected_order_arc_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 G  connected_order_arc_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 G  connected_order_arc_922
 L  arc_capacity_923
 G  connected_order_arc_924
 L  arc_capacity_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 G  connected_order_arc_941
 L  arc_capacity_942
 G  connected_order_arc_943
 L  arc_capacity_944
 G  connected_order_arc_945
 L  arc_capacity_946
 G  connected_order_arc_947
 L  arc_capacity_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 G  connected_order_arc_964
 L  arc_capacity_965
 G  connected_order_arc_966
 L  arc_capacity_967
 G  connected_order_arc_968
 L  arc_capacity_969
 G  connected_order_arc_970
 L  arc_capacity_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 G  connected_order_arc_989
 L  arc_capacity_990
 G  connected_order_arc_991
 L  arc_capacity_992
 G  connected_order_arc_993
 L  arc_capacity_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 G  connected_order_arc_1014
 L  arc_capacity_1015
 G  connected_order_arc_1016
 L  arc_capacity_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 G  connected_order_arc_1039
 L  arc_capacity_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 E  depot_departure_or_bypass_1086
 E  depot_return_or_bypass_1087
 E  out_degree_1088
 E  in_degree_1089
 G  order_active_lb_1090
 L  order_active_ub_1091
 E  segment_load_conservation_1092
 G  segment_prefix_lb_1093
 L  segment_prefix_ub_1094
 E  out_degree_1095
 E  in_degree_1096
 G  order_active_lb_1097
 L  order_active_ub_1098
 E  segment_load_conservation_1099
 G  segment_prefix_lb_1100
 L  segment_prefix_ub_1101
 E  out_degree_1102
 E  in_degree_1103
 G  order_active_lb_1104
 L  order_active_ub_1105
 E  segment_load_conservation_1106
 G  segment_prefix_lb_1107
 L  segment_prefix_ub_1108
 E  out_degree_1109
 E  in_degree_1110
 G  order_active_lb_1111
 L  order_active_ub_1112
 E  segment_load_conservation_1113
 G  segment_prefix_lb_1114
 L  segment_prefix_ub_1115
 E  out_degree_1116
 E  in_degree_1117
 G  order_active_lb_1118
 L  order_active_ub_1119
 E  service_visit_def_1120
 E  free_load_conservation_1121
 E  out_degree_1122
 E  in_degree_1123
 G  order_active_lb_1124
 L  order_active_ub_1125
 E  service_visit_def_1126
 E  free_load_conservation_1127
 E  out_degree_1128
 E  in_degree_1129
 G  order_active_lb_1130
 L  order_active_ub_1131
 E  service_visit_def_1132
 E  free_load_conservation_1133
 E  out_degree_1134
 E  in_degree_1135
 G  order_active_lb_1136
 L  order_active_ub_1137
 E  service_visit_def_1138
 E  free_load_conservation_1139
 E  out_degree_1140
 E  in_degree_1141
 G  order_active_lb_1142
 L  order_active_ub_1143
 E  service_visit_def_1144
 E  free_load_conservation_1145
 E  out_degree_1146
 E  in_degree_1147
 G  order_active_lb_1148
 L  order_active_ub_1149
 E  service_visit_def_1150
 E  free_load_conservation_1151
 E  out_degree_1152
 E  in_degree_1153
 G  order_active_lb_1154
 L  order_active_ub_1155
 E  service_visit_def_1156
 E  free_load_conservation_1157
 E  out_degree_1158
 E  in_degree_1159
 G  order_active_lb_1160
 L  order_active_ub_1161
 E  service_visit_def_1162
 E  free_load_conservation_1163
 G  fixed_segment_relative_order_1164
 G  fixed_segment_relative_order_1165
 G  fixed_segment_relative_order_1166
 L  original_T_including_depot_unload_1167
 L  arc_capacity_1168
 L  arc_capacity_1169
 L  arc_capacity_1170
 L  arc_capacity_1171
 L  arc_capacity_1172
 L  arc_capacity_1173
 L  arc_capacity_1174
 L  arc_capacity_1175
 L  arc_capacity_1176
 L  arc_capacity_1177
 L  arc_capacity_1178
 L  arc_capacity_1179
 L  arc_capacity_1180
 L  arc_capacity_1181
 L  arc_capacity_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 G  connected_order_arc_1186
 L  arc_capacity_1187
 G  connected_order_arc_1188
 L  arc_capacity_1189
 G  connected_order_arc_1190
 L  arc_capacity_1191
 G  connected_order_arc_1192
 L  arc_capacity_1193
 G  connected_order_arc_1194
 L  arc_capacity_1195
 G  connected_order_arc_1196
 L  arc_capacity_1197
 G  connected_order_arc_1198
 L  arc_capacity_1199
 G  connected_order_arc_1200
 L  arc_capacity_1201
 G  connected_order_arc_1202
 L  arc_capacity_1203
 G  connected_order_arc_1204
 L  arc_capacity_1205
 G  connected_order_arc_1206
 L  arc_capacity_1207
 L  arc_capacity_1208
 G  connected_order_arc_1209
 L  arc_capacity_1210
 G  connected_order_arc_1211
 L  arc_capacity_1212
 G  connected_order_arc_1213
 L  arc_capacity_1214
 G  connected_order_arc_1215
 L  arc_capacity_1216
 G  connected_order_arc_1217
 L  arc_capacity_1218
 G  connected_order_arc_1219
 L  arc_capacity_1220
 G  connected_order_arc_1221
 L  arc_capacity_1222
 G  connected_order_arc_1223
 L  arc_capacity_1224
 G  connected_order_arc_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 L  arc_capacity_1233
 G  connected_order_arc_1234
 L  arc_capacity_1235
 G  connected_order_arc_1236
 L  arc_capacity_1237
 G  connected_order_arc_1238
 L  arc_capacity_1239
 G  connected_order_arc_1240
 L  arc_capacity_1241
 G  connected_order_arc_1242
 L  arc_capacity_1243
 G  connected_order_arc_1244
 L  arc_capacity_1245
 G  connected_order_arc_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 G  connected_order_arc_1265
 L  arc_capacity_1266
 G  connected_order_arc_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 G  connected_order_arc_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 G  connected_order_arc_1354
 L  arc_capacity_1355
 G  connected_order_arc_1356
 L  arc_capacity_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 G  connected_order_arc_1375
 L  arc_capacity_1376
 G  connected_order_arc_1377
 L  arc_capacity_1378
 G  connected_order_arc_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 L  arc_capacity_1395
 G  connected_order_arc_1396
 L  arc_capacity_1397
 G  connected_order_arc_1398
 L  arc_capacity_1399
 G  connected_order_arc_1400
 L  arc_capacity_1401
 G  connected_order_arc_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 G  connected_order_arc_1415
 L  arc_capacity_1416
 G  connected_order_arc_1417
 L  arc_capacity_1418
 G  connected_order_arc_1419
 L  arc_capacity_1420
 G  connected_order_arc_1421
 L  arc_capacity_1422
 G  connected_order_arc_1423
 L  arc_capacity_1424
 G  connected_order_arc_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 G  connected_order_arc_1436
 L  arc_capacity_1437
 G  connected_order_arc_1438
 L  arc_capacity_1439
 G  connected_order_arc_1440
 L  arc_capacity_1441
 G  connected_order_arc_1442
 L  arc_capacity_1443
 G  connected_order_arc_1444
 L  arc_capacity_1445
 G  connected_order_arc_1446
 L  arc_capacity_1447
 G  connected_order_arc_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 L  arc_capacity_1458
 G  connected_order_arc_1459
 L  arc_capacity_1460
 G  connected_order_arc_1461
 L  arc_capacity_1462
 G  connected_order_arc_1463
 L  arc_capacity_1464
 G  connected_order_arc_1465
 L  arc_capacity_1466
 G  connected_order_arc_1467
 L  arc_capacity_1468
 G  connected_order_arc_1469
 L  arc_capacity_1470
 G  connected_order_arc_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 L  arc_capacity_1483
 G  connected_order_arc_1484
 L  arc_capacity_1485
 G  connected_order_arc_1486
 L  arc_capacity_1487
 G  connected_order_arc_1488
 L  arc_capacity_1489
 G  connected_order_arc_1490
 L  arc_capacity_1491
 G  connected_order_arc_1492
 L  arc_capacity_1493
 G  connected_order_arc_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 E  depot_departure_or_bypass_1507
 E  depot_return_or_bypass_1508
 E  out_degree_1509
 E  in_degree_1510
 G  order_active_lb_1511
 L  order_active_ub_1512
 E  segment_load_conservation_1513
 G  segment_prefix_lb_1514
 L  segment_prefix_ub_1515
 E  out_degree_1516
 E  in_degree_1517
 G  order_active_lb_1518
 L  order_active_ub_1519
 E  segment_load_conservation_1520
 G  segment_prefix_lb_1521
 L  segment_prefix_ub_1522
 E  out_degree_1523
 E  in_degree_1524
 G  order_active_lb_1525
 L  order_active_ub_1526
 E  segment_load_conservation_1527
 G  segment_prefix_lb_1528
 L  segment_prefix_ub_1529
 E  out_degree_1530
 E  in_degree_1531
 G  order_active_lb_1532
 L  order_active_ub_1533
 E  segment_load_conservation_1534
 G  segment_prefix_lb_1535
 L  segment_prefix_ub_1536
 E  out_degree_1537
 E  in_degree_1538
 G  order_active_lb_1539
 L  order_active_ub_1540
 E  segment_load_conservation_1541
 G  segment_prefix_lb_1542
 L  segment_prefix_ub_1543
 E  out_degree_1544
 E  in_degree_1545
 G  order_active_lb_1546
 L  order_active_ub_1547
 E  service_visit_def_1548
 E  free_load_conservation_1549
 E  out_degree_1550
 E  in_degree_1551
 G  order_active_lb_1552
 L  order_active_ub_1553
 E  service_visit_def_1554
 E  free_load_conservation_1555
 E  out_degree_1556
 E  in_degree_1557
 G  order_active_lb_1558
 L  order_active_ub_1559
 E  service_visit_def_1560
 E  free_load_conservation_1561
 E  out_degree_1562
 E  in_degree_1563
 G  order_active_lb_1564
 L  order_active_ub_1565
 E  service_visit_def_1566
 E  free_load_conservation_1567
 E  out_degree_1568
 E  in_degree_1569
 G  order_active_lb_1570
 L  order_active_ub_1571
 E  service_visit_def_1572
 E  free_load_conservation_1573
 E  out_degree_1574
 E  in_degree_1575
 G  order_active_lb_1576
 L  order_active_ub_1577
 E  service_visit_def_1578
 E  free_load_conservation_1579
 E  out_degree_1580
 E  in_degree_1581
 G  order_active_lb_1582
 L  order_active_ub_1583
 E  service_visit_def_1584
 E  free_load_conservation_1585
 E  out_degree_1586
 E  in_degree_1587
 G  order_active_lb_1588
 L  order_active_ub_1589
 E  service_visit_def_1590
 E  free_load_conservation_1591
 G  fixed_segment_relative_order_1592
 G  fixed_segment_relative_order_1593
 G  fixed_segment_relative_order_1594
 G  fixed_segment_relative_order_1595
 L  original_T_including_depot_unload_1596
COLUMNS
    t         normalized_mass_35_33  -1
    t         normalized_mass_30_54  -1
    t         normalized_mass_31_83  -1
    t         normalized_mass_32_112  -1
    t         normalized_mass_19_133  -1
    t         normalized_mass_26_154  -1
    t         normalized_mass_6_179  -1
    t         normalized_mass_17_216  -1
    t         normalization_277  2.4858333333333334e+01
    t         full_original_Gini_278  -4.9942857142857228e+01
    q         OBJ       1
    q         parent_nonstrict_scope_220  1
    q         full_original_Gini_278  35
    MARKER    'MARKER'                 'INTORG'
    x_35_0    OBJ       0.048
    x_35_0    product_lb_0  -2.4615144174391260e-02
    x_35_0    product_ub_1  -4.0227958431149860e-02
    x_35_0    onehot_35_32  1
    x_35_0    parent_nonstrict_scope_220  0.096
    x_35_0    unique_nonzero_owner_279  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_0    product_lb_0  1
    w_35_0    product_ub_1  1
    w_35_0    normalized_mass_35_33  1
    w_35_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_1    OBJ       3.6000000000000004e-02
    x_35_1    product_lb_2  -2.4615144174391260e-02
    x_35_1    product_ub_3  -4.0227958431149860e-02
    x_35_1    onehot_35_32  1
    x_35_1    stock_lb_218  1
    x_35_1    stock_ub_219  1
    x_35_1    parent_nonstrict_scope_220  0.084
    x_35_1    unique_nonzero_owner_280  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_1    product_lb_2  1
    w_35_1    product_ub_3  1
    w_35_1    normalized_mass_35_33  1
    w_35_1    normalized_ratio_35_34  -0.125
    w_35_1    full_original_Gini_278  -2.1483333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_2    OBJ       2.4000000000000007e-02
    x_35_2    product_lb_4  -2.4615144174391260e-02
    x_35_2    product_ub_5  -4.0227958431149860e-02
    x_35_2    onehot_35_32  1
    x_35_2    stock_lb_218  2
    x_35_2    stock_ub_219  2
    x_35_2    parent_nonstrict_scope_220  7.2000000000000008e-02
    x_35_2    unique_nonzero_owner_281  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_2    product_lb_4  1
    w_35_2    product_ub_5  1
    w_35_2    normalized_mass_35_33  1
    w_35_2    normalized_ratio_35_34  -0.25
    w_35_2    full_original_Gini_278  -1.8108333333333338e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_3    OBJ       1.1999999999999997e-02
    x_35_3    product_lb_6  -2.4615144174391260e-02
    x_35_3    product_ub_7  -4.0227958431149860e-02
    x_35_3    onehot_35_32  1
    x_35_3    stock_lb_218  3
    x_35_3    stock_ub_219  3
    x_35_3    parent_nonstrict_scope_220  0.06
    x_35_3    unique_nonzero_owner_282  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_3    product_lb_6  1
    w_35_3    product_ub_7  1
    w_35_3    normalized_mass_35_33  1
    w_35_3    normalized_ratio_35_34  -0.375
    w_35_3    full_original_Gini_278  -1.4733333333333338e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_4    product_lb_8  -2.4615144174391260e-02
    x_35_4    product_ub_9  -4.0227958431149860e-02
    x_35_4    onehot_35_32  1
    x_35_4    stock_lb_218  4
    x_35_4    stock_ub_219  4
    x_35_4    parent_nonstrict_scope_220  0.048
    x_35_4    unique_nonzero_owner_283  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_4    product_lb_8  1
    w_35_4    product_ub_9  1
    w_35_4    normalized_mass_35_33  1
    w_35_4    normalized_ratio_35_34  -0.5
    w_35_4    full_original_Gini_278  -1.1558333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_5    OBJ       -1.1999999999999997e-02
    x_35_5    product_lb_10  -2.4615144174391260e-02
    x_35_5    product_ub_11  -4.0227958431149860e-02
    x_35_5    onehot_35_32  1
    x_35_5    stock_lb_218  5
    x_35_5    stock_ub_219  5
    x_35_5    parent_nonstrict_scope_220  3.6000000000000004e-02
    x_35_5    unique_nonzero_owner_284  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_5    product_lb_10  1
    w_35_5    product_ub_11  1
    w_35_5    normalized_mass_35_33  1
    w_35_5    normalized_ratio_35_34  -0.625
    w_35_5    full_original_Gini_278  -8.4333333333333318e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_6    OBJ       -0.024
    x_35_6    product_lb_12  -2.4615144174391260e-02
    x_35_6    product_ub_13  -4.0227958431149860e-02
    x_35_6    onehot_35_32  1
    x_35_6    stock_lb_218  6
    x_35_6    stock_ub_219  6
    x_35_6    parent_nonstrict_scope_220  0.024
    x_35_6    unique_nonzero_owner_285  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_6    product_lb_12  1
    w_35_6    product_ub_13  1
    w_35_6    normalized_mass_35_33  1
    w_35_6    normalized_ratio_35_34  -0.75
    w_35_6    full_original_Gini_278  -5.4511904761904741e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_7    OBJ       -3.6000000000000004e-02
    x_35_7    product_lb_14  -2.4615144174391260e-02
    x_35_7    product_ub_15  -4.0227958431149860e-02
    x_35_7    onehot_35_32  1
    x_35_7    stock_lb_218  7
    x_35_7    stock_ub_219  7
    x_35_7    parent_nonstrict_scope_220  0.012
    x_35_7    unique_nonzero_owner_286  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_7    product_lb_14  1
    w_35_7    product_ub_15  1
    w_35_7    normalized_mass_35_33  1
    w_35_7    normalized_ratio_35_34  -0.875
    w_35_7    full_original_Gini_278  -3.1666666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_8    OBJ       -0.048
    x_35_8    product_lb_16  -2.4615144174391260e-02
    x_35_8    product_ub_17  -4.0227958431149860e-02
    x_35_8    onehot_35_32  1
    x_35_8    stock_lb_218  8
    x_35_8    stock_ub_219  8
    x_35_8    unique_nonzero_owner_287  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_8    product_lb_16  1
    w_35_8    product_ub_17  1
    w_35_8    normalized_mass_35_33  1
    w_35_8    normalized_ratio_35_34  -1
    w_35_8    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_9    OBJ       -3.6000000000000004e-02
    x_35_9    product_lb_18  -2.4615144174391260e-02
    x_35_9    product_ub_19  -4.0227958431149860e-02
    x_35_9    onehot_35_32  1
    x_35_9    stock_lb_218  9
    x_35_9    stock_ub_219  9
    x_35_9    parent_nonstrict_scope_220  0.012
    x_35_9    unique_nonzero_owner_288  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_9    product_lb_18  1
    w_35_9    product_ub_19  1
    w_35_9    normalized_mass_35_33  1
    w_35_9    normalized_ratio_35_34  -1.125
    w_35_9    full_original_Gini_278  -5.6666666666666679e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_10   OBJ       -0.024
    x_35_10   product_lb_20  -2.4615144174391260e-02
    x_35_10   product_ub_21  -4.0227958431149860e-02
    x_35_10   onehot_35_32  1
    x_35_10   stock_lb_218  10
    x_35_10   stock_ub_219  10
    x_35_10   parent_nonstrict_scope_220  0.024
    x_35_10   unique_nonzero_owner_289  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_10   product_lb_20  1
    w_35_10   product_ub_21  1
    w_35_10   normalized_mass_35_33  1
    w_35_10   normalized_ratio_35_34  -1.25
    w_35_10   full_original_Gini_278  -8.8916666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_35_11   OBJ       -1.1999999999999997e-02
    x_35_11   product_lb_22  -2.4615144174391260e-02
    x_35_11   product_ub_23  -4.0227958431149860e-02
    x_35_11   onehot_35_32  1
    x_35_11   stock_lb_218  11
    x_35_11   stock_ub_219  11
    x_35_11   parent_nonstrict_scope_220  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_35_11   product_lb_22  1
    w_35_11   product_ub_23  1
    w_35_11   normalized_mass_35_33  1
    w_35_11   normalized_ratio_35_34  -1.375
    w_35_11   full_original_Gini_278  -1.2266666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_12   product_lb_24  -2.4615144174391260e-02
    x_35_12   product_ub_25  -4.0227958431149860e-02
    x_35_12   onehot_35_32  1
    x_35_12   stock_lb_218  12
    x_35_12   stock_ub_219  12
    x_35_12   parent_nonstrict_scope_220  0.048
    x_35_12   unique_nonzero_owner_290  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_12   product_lb_24  1
    w_35_12   product_ub_25  1
    w_35_12   normalized_mass_35_33  1
    w_35_12   normalized_ratio_35_34  -1.5
    w_35_12   full_original_Gini_278  -1.5641666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_13   OBJ       1.1999999999999997e-02
    x_35_13   product_lb_26  -2.4615144174391260e-02
    x_35_13   product_ub_27  -4.0227958431149860e-02
    x_35_13   onehot_35_32  1
    x_35_13   stock_lb_218  13
    x_35_13   stock_ub_219  13
    x_35_13   parent_nonstrict_scope_220  0.06
    x_35_13   unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_13   product_lb_26  1
    w_35_13   product_ub_27  1
    w_35_13   normalized_mass_35_33  1
    w_35_13   normalized_ratio_35_34  -1.625
    w_35_13   full_original_Gini_278  -1.9016666666666662e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_14   OBJ       2.4000000000000007e-02
    x_35_14   product_lb_28  -2.4615144174391260e-02
    x_35_14   product_ub_29  -4.0227958431149860e-02
    x_35_14   onehot_35_32  1
    x_35_14   stock_lb_218  14
    x_35_14   stock_ub_219  14
    x_35_14   parent_nonstrict_scope_220  7.2000000000000008e-02
    x_35_14   unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_14   product_lb_28  1
    w_35_14   product_ub_29  1
    w_35_14   normalized_mass_35_33  1
    w_35_14   normalized_ratio_35_34  -1.75
    w_35_14   full_original_Gini_278  -2.2391666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_35_15   OBJ       3.6000000000000004e-02
    x_35_15   product_lb_30  -2.4615144174391260e-02
    x_35_15   product_ub_31  -4.0227958431149860e-02
    x_35_15   onehot_35_32  1
    x_35_15   stock_lb_218  15
    x_35_15   stock_ub_219  15
    x_35_15   parent_nonstrict_scope_220  0.084
    x_35_15   unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_35_15   product_lb_30  1
    w_35_15   product_ub_31  1
    w_35_15   normalized_mass_35_33  1
    w_35_15   normalized_ratio_35_34  -1.875
    w_35_15   full_original_Gini_278  -2.5766666666666666e+01
    rho_35    normalized_ratio_35_34  1
    rho_35    block_pair_pos_263  -1
    rho_35    block_pair_neg_264  1
    rho_35    block_pair_pos_265  -1
    rho_35    block_pair_neg_266  1
    rho_35    block_pair_pos_267  -1
    rho_35    block_pair_neg_268  1
    rho_35    block_pair_pos_269  -1
    rho_35    block_pair_neg_270  1
    rho_35    block_pair_pos_271  -1
    rho_35    block_pair_neg_272  1
    rho_35    block_pair_pos_273  -1
    rho_35    block_pair_neg_274  1
    rho_35    block_pair_pos_275  -1
    rho_35    block_pair_neg_276  1
    rho_35    normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_30_0    OBJ       0.012
    x_30_0    product_lb_35  -2.4615144174391260e-02
    x_30_0    product_ub_36  -4.0227958431149860e-02
    x_30_0    onehot_30_53  1
    x_30_0    parent_nonstrict_scope_220  0.024
    x_30_0    unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_0    product_lb_35  1
    w_30_0    product_ub_36  1
    w_30_0    normalized_mass_30_54  1
    w_30_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_1    OBJ       6.0000000000000019e-03
    x_30_1    product_lb_37  -2.4615144174391260e-02
    x_30_1    product_ub_38  -4.0227958431149860e-02
    x_30_1    onehot_30_53  1
    x_30_1    stock_lb_218  1
    x_30_1    stock_ub_219  1
    x_30_1    parent_nonstrict_scope_220  1.8000000000000002e-02
    x_30_1    unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_1    product_lb_37  1
    w_30_1    product_ub_38  1
    w_30_1    normalized_mass_30_54  1
    w_30_1    normalized_ratio_30_55  -0.25
    w_30_1    full_original_Gini_278  -1.8108333333333338e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_2    product_lb_39  -2.4615144174391260e-02
    x_30_2    product_ub_40  -4.0227958431149860e-02
    x_30_2    onehot_30_53  1
    x_30_2    stock_lb_218  2
    x_30_2    stock_ub_219  2
    x_30_2    parent_nonstrict_scope_220  0.012
    x_30_2    unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_2    product_lb_39  1
    w_30_2    product_ub_40  1
    w_30_2    normalized_mass_30_54  1
    w_30_2    normalized_ratio_30_55  -0.5
    w_30_2    full_original_Gini_278  -1.1558333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_3    OBJ       -0.006
    x_30_3    product_lb_41  -2.4615144174391260e-02
    x_30_3    product_ub_42  -4.0227958431149860e-02
    x_30_3    onehot_30_53  1
    x_30_3    stock_lb_218  3
    x_30_3    stock_ub_219  3
    x_30_3    parent_nonstrict_scope_220  0.006
    x_30_3    unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_3    product_lb_41  1
    w_30_3    product_ub_42  1
    w_30_3    normalized_mass_30_54  1
    w_30_3    normalized_ratio_30_55  -0.75
    w_30_3    full_original_Gini_278  -5.4511904761904741e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_4    OBJ       -0.012
    x_30_4    product_lb_43  -2.4615144174391260e-02
    x_30_4    product_ub_44  -4.0227958431149860e-02
    x_30_4    onehot_30_53  1
    x_30_4    stock_lb_218  4
    x_30_4    stock_ub_219  4
    x_30_4    unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_4    product_lb_43  1
    w_30_4    product_ub_44  1
    w_30_4    normalized_mass_30_54  1
    w_30_4    normalized_ratio_30_55  -1
    w_30_4    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_5    OBJ       -0.006
    x_30_5    product_lb_45  -2.4615144174391260e-02
    x_30_5    product_ub_46  -4.0227958431149860e-02
    x_30_5    onehot_30_53  1
    x_30_5    stock_lb_218  5
    x_30_5    stock_ub_219  5
    x_30_5    parent_nonstrict_scope_220  0.006
    MARKER    'MARKER'                 'INTEND'
    w_30_5    product_lb_45  1
    w_30_5    product_ub_46  1
    w_30_5    normalized_mass_30_54  1
    w_30_5    normalized_ratio_30_55  -1.25
    w_30_5    full_original_Gini_278  -8.8916666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_30_6    product_lb_47  -2.4615144174391260e-02
    x_30_6    product_ub_48  -4.0227958431149860e-02
    x_30_6    onehot_30_53  1
    x_30_6    stock_lb_218  6
    x_30_6    stock_ub_219  6
    x_30_6    parent_nonstrict_scope_220  0.012
    x_30_6    unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_6    product_lb_47  1
    w_30_6    product_ub_48  1
    w_30_6    normalized_mass_30_54  1
    w_30_6    normalized_ratio_30_55  -1.5
    w_30_6    full_original_Gini_278  -1.5641666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_7    OBJ       6.0000000000000019e-03
    x_30_7    product_lb_49  -2.4615144174391260e-02
    x_30_7    product_ub_50  -4.0227958431149860e-02
    x_30_7    onehot_30_53  1
    x_30_7    stock_lb_218  7
    x_30_7    stock_ub_219  7
    x_30_7    parent_nonstrict_scope_220  1.8000000000000002e-02
    x_30_7    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_7    product_lb_49  1
    w_30_7    product_ub_50  1
    w_30_7    normalized_mass_30_54  1
    w_30_7    normalized_ratio_30_55  -1.75
    w_30_7    full_original_Gini_278  -2.2391666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_30_8    OBJ       0.012
    x_30_8    product_lb_51  -2.4615144174391260e-02
    x_30_8    product_ub_52  -4.0227958431149860e-02
    x_30_8    onehot_30_53  1
    x_30_8    stock_lb_218  8
    x_30_8    stock_ub_219  8
    x_30_8    parent_nonstrict_scope_220  0.024
    x_30_8    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_30_8    product_lb_51  1
    w_30_8    product_ub_52  1
    w_30_8    normalized_mass_30_54  1
    w_30_8    normalized_ratio_30_55  -2
    w_30_8    full_original_Gini_278  -2.9141666666666666e+01
    rho_30    normalized_ratio_30_55  1
    rho_30    block_pair_pos_233  -1
    rho_30    block_pair_neg_234  1
    rho_30    block_pair_pos_235  -1
    rho_30    block_pair_neg_236  1
    rho_30    block_pair_pos_237  -1
    rho_30    block_pair_neg_238  1
    rho_30    block_pair_pos_239  -1
    rho_30    block_pair_neg_240  1
    rho_30    block_pair_pos_241  -1
    rho_30    block_pair_neg_242  1
    rho_30    block_pair_pos_243  -1
    rho_30    block_pair_neg_244  1
    rho_30    block_pair_pos_271  1
    rho_30    block_pair_neg_272  -1
    rho_30    normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_56  -2.4615144174391260e-02
    x_31_0    product_ub_57  -4.0227958431149860e-02
    x_31_0    onehot_31_82  1
    x_31_0    parent_nonstrict_scope_220  0.0735
    x_31_0    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_56  1
    w_31_0    product_ub_57  1
    w_31_0    normalized_mass_31_83  1
    w_31_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_58  -2.4615144174391260e-02
    x_31_1    product_ub_59  -4.0227958431149860e-02
    x_31_1    onehot_31_82  1
    x_31_1    stock_lb_218  1
    x_31_1    stock_ub_219  1
    x_31_1    parent_nonstrict_scope_220  0.063
    x_31_1    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_58  1
    w_31_1    product_ub_59  1
    w_31_1    normalized_mass_31_83  1
    w_31_1    normalized_ratio_31_84  -1.4285714285714285e-01
    w_31_1    full_original_Gini_278  -2.1001190476190484e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_60  -2.4615144174391260e-02
    x_31_2    product_ub_61  -4.0227958431149860e-02
    x_31_2    onehot_31_82  1
    x_31_2    stock_lb_218  2
    x_31_2    stock_ub_219  2
    x_31_2    parent_nonstrict_scope_220  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_60  1
    w_31_2    product_ub_61  1
    w_31_2    normalized_mass_31_83  1
    w_31_2    normalized_ratio_31_84  -2.8571428571428570e-01
    w_31_2    full_original_Gini_278  -1.7144047619047615e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_62  -2.4615144174391260e-02
    x_31_3    product_ub_63  -4.0227958431149860e-02
    x_31_3    onehot_31_82  1
    x_31_3    stock_lb_218  3
    x_31_3    stock_ub_219  3
    x_31_3    parent_nonstrict_scope_220  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_62  1
    w_31_3    product_ub_63  1
    w_31_3    normalized_mass_31_83  1
    w_31_3    normalized_ratio_31_84  -4.2857142857142855e-01
    w_31_3    full_original_Gini_278  -1.3344047619047616e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_64  -2.4615144174391260e-02
    x_31_4    product_ub_65  -4.0227958431149860e-02
    x_31_4    onehot_31_82  1
    x_31_4    stock_lb_218  4
    x_31_4    stock_ub_219  4
    x_31_4    parent_nonstrict_scope_220  0.0315
    x_31_4    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_64  1
    w_31_4    product_ub_65  1
    w_31_4    normalized_mass_31_83  1
    w_31_4    normalized_ratio_31_84  -5.7142857142857140e-01
    w_31_4    full_original_Gini_278  -9.7726190476190524e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_66  -2.4615144174391260e-02
    x_31_5    product_ub_67  -4.0227958431149860e-02
    x_31_5    onehot_31_82  1
    x_31_5    stock_lb_218  5
    x_31_5    stock_ub_219  5
    x_31_5    parent_nonstrict_scope_220  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_66  1
    w_31_5    product_ub_67  1
    w_31_5    normalized_mass_31_83  1
    w_31_5    normalized_ratio_31_84  -7.1428571428571419e-01
    w_31_5    full_original_Gini_278  -6.2011904761904768e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_68  -2.4615144174391260e-02
    x_31_6    product_ub_69  -4.0227958431149860e-02
    x_31_6    onehot_31_82  1
    x_31_6    stock_lb_218  6
    x_31_6    stock_ub_219  6
    x_31_6    parent_nonstrict_scope_220  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_68  1
    w_31_6    product_ub_69  1
    w_31_6    normalized_mass_31_83  1
    w_31_6    normalized_ratio_31_84  -8.5714285714285710e-01
    w_31_6    full_original_Gini_278  -3.3630952380952372e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_70  -2.4615144174391260e-02
    x_31_7    product_ub_71  -4.0227958431149860e-02
    x_31_7    onehot_31_82  1
    x_31_7    stock_lb_218  7
    x_31_7    stock_ub_219  7
    x_31_7    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_70  1
    w_31_7    product_ub_71  1
    w_31_7    normalized_mass_31_83  1
    w_31_7    normalized_ratio_31_84  -1
    w_31_7    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_72  -2.4615144174391260e-02
    x_31_8    product_ub_73  -4.0227958431149860e-02
    x_31_8    onehot_31_82  1
    x_31_8    stock_lb_218  8
    x_31_8    stock_ub_219  8
    x_31_8    parent_nonstrict_scope_220  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_72  1
    w_31_8    product_ub_73  1
    w_31_8    normalized_mass_31_83  1
    w_31_8    normalized_ratio_31_84  -1.1428571428571428e+00
    w_31_8    full_original_Gini_278  -6.1130952380952355e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_74  -2.4615144174391260e-02
    x_31_9    product_ub_75  -4.0227958431149860e-02
    x_31_9    onehot_31_82  1
    x_31_9    stock_lb_218  9
    x_31_9    stock_ub_219  9
    x_31_9    parent_nonstrict_scope_220  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_74  1
    w_31_9    product_ub_75  1
    w_31_9    normalized_mass_31_83  1
    w_31_9    normalized_ratio_31_84  -1.2857142857142856e+00
    w_31_9    full_original_Gini_278  -9.85595238095238
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_76  -2.4615144174391260e-02
    x_31_10   product_ub_77  -4.0227958431149860e-02
    x_31_10   onehot_31_82  1
    x_31_10   stock_lb_218  10
    x_31_10   stock_ub_219  10
    x_31_10   parent_nonstrict_scope_220  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_76  1
    w_31_10   product_ub_77  1
    w_31_10   normalized_mass_31_83  1
    w_31_10   normalized_ratio_31_84  -1.4285714285714284e+00
    w_31_10   full_original_Gini_278  -1.3713095238095237e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_78  -2.4615144174391260e-02
    x_31_11   product_ub_79  -4.0227958431149860e-02
    x_31_11   onehot_31_82  1
    x_31_11   stock_lb_218  11
    x_31_11   stock_ub_219  11
    x_31_11   parent_nonstrict_scope_220  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_78  1
    w_31_11   product_ub_79  1
    w_31_11   normalized_mass_31_83  1
    w_31_11   normalized_ratio_31_84  -1.5714285714285714e+00
    w_31_11   full_original_Gini_278  -1.7570238095238089e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_80  -2.4615144174391260e-02
    x_31_12   product_ub_81  -4.0227958431149860e-02
    x_31_12   onehot_31_82  1
    x_31_12   stock_lb_218  12
    x_31_12   stock_ub_219  12
    x_31_12   parent_nonstrict_scope_220  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_80  1
    w_31_12   product_ub_81  1
    w_31_12   normalized_mass_31_83  1
    w_31_12   normalized_ratio_31_84  -1.7142857142857142e+00
    w_31_12   full_original_Gini_278  -2.1427380952380950e+01
    rho_31    normalized_ratio_31_84  1
    rho_31    block_pair_pos_241  1
    rho_31    block_pair_neg_242  -1
    rho_31    block_pair_pos_245  -1
    rho_31    block_pair_neg_246  1
    rho_31    block_pair_pos_247  -1
    rho_31    block_pair_neg_248  1
    rho_31    block_pair_pos_249  -1
    rho_31    block_pair_neg_250  1
    rho_31    block_pair_pos_251  -1
    rho_31    block_pair_neg_252  1
    rho_31    block_pair_pos_253  -1
    rho_31    block_pair_neg_254  1
    rho_31    block_pair_pos_273  1
    rho_31    block_pair_neg_274  -1
    rho_31    normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_85  -2.4615144174391260e-02
    x_32_0    product_ub_86  -4.0227958431149860e-02
    x_32_0    onehot_32_111  1
    x_32_0    parent_nonstrict_scope_220  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_85  1
    w_32_0    product_ub_86  1
    w_32_0    normalized_mass_32_112  1
    w_32_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_87  -2.4615144174391260e-02
    x_32_1    product_ub_88  -4.0227958431149860e-02
    x_32_1    onehot_32_111  1
    x_32_1    stock_lb_218  1
    x_32_1    stock_ub_219  1
    x_32_1    parent_nonstrict_scope_220  0.03
    x_32_1    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_87  1
    w_32_1    product_ub_88  1
    w_32_1    normalized_mass_32_112  1
    w_32_1    normalized_ratio_32_113  -0.2
    w_32_1    full_original_Gini_278  -1.9458333333333339e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_89  -2.4615144174391260e-02
    x_32_2    product_ub_90  -4.0227958431149860e-02
    x_32_2    onehot_32_111  1
    x_32_2    stock_lb_218  2
    x_32_2    stock_ub_219  2
    x_32_2    parent_nonstrict_scope_220  0.0225
    x_32_2    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_89  1
    w_32_2    product_ub_90  1
    w_32_2    normalized_mass_32_112  1
    w_32_2    normalized_ratio_32_113  -0.4
    w_32_2    full_original_Gini_278  -1.4058333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_91  -2.4615144174391260e-02
    x_32_3    product_ub_92  -4.0227958431149860e-02
    x_32_3    onehot_32_111  1
    x_32_3    stock_lb_218  3
    x_32_3    stock_ub_219  3
    x_32_3    parent_nonstrict_scope_220  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_91  1
    w_32_3    product_ub_92  1
    w_32_3    normalized_mass_32_112  1
    w_32_3    normalized_ratio_32_113  -6.0000000000000009e-01
    w_32_3    full_original_Gini_278  -9.0583333333333318e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_93  -2.4615144174391260e-02
    x_32_4    product_ub_94  -4.0227958431149860e-02
    x_32_4    onehot_32_111  1
    x_32_4    stock_lb_218  4
    x_32_4    stock_ub_219  4
    x_32_4    parent_nonstrict_scope_220  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_93  1
    w_32_4    product_ub_94  1
    w_32_4    normalized_mass_32_112  1
    w_32_4    normalized_ratio_32_113  -0.8
    w_32_4    full_original_Gini_278  -4.4011904761904779e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_95  -2.4615144174391260e-02
    x_32_5    product_ub_96  -4.0227958431149860e-02
    x_32_5    onehot_32_111  1
    x_32_5    stock_lb_218  5
    x_32_5    stock_ub_219  5
    x_32_5    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_95  1
    w_32_5    product_ub_96  1
    w_32_5    normalized_mass_32_112  1
    w_32_5    normalized_ratio_32_113  -1
    w_32_5    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_97  -2.4615144174391260e-02
    x_32_6    product_ub_98  -4.0227958431149860e-02
    x_32_6    onehot_32_111  1
    x_32_6    stock_lb_218  6
    x_32_6    stock_ub_219  6
    x_32_6    parent_nonstrict_scope_220  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_97  1
    w_32_6    product_ub_98  1
    w_32_6    normalized_mass_32_112  1
    w_32_6    normalized_ratio_32_113  -1.2000000000000002e+00
    w_32_6    full_original_Gini_278  -7.5416666666666723e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_99  -2.4615144174391260e-02
    x_32_7    product_ub_100  -4.0227958431149860e-02
    x_32_7    onehot_32_111  1
    x_32_7    stock_lb_218  7
    x_32_7    stock_ub_219  7
    x_32_7    parent_nonstrict_scope_220  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_99  1
    w_32_7    product_ub_100  1
    w_32_7    normalized_mass_32_112  1
    w_32_7    normalized_ratio_32_113  -1.4000000000000001e+00
    w_32_7    full_original_Gini_278  -1.2941666666666672e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_101  -2.4615144174391260e-02
    x_32_8    product_ub_102  -4.0227958431149860e-02
    x_32_8    onehot_32_111  1
    x_32_8    stock_lb_218  8
    x_32_8    stock_ub_219  8
    x_32_8    parent_nonstrict_scope_220  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_101  1
    w_32_8    product_ub_102  1
    w_32_8    normalized_mass_32_112  1
    w_32_8    normalized_ratio_32_113  -1.6
    w_32_8    full_original_Gini_278  -1.8341666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_103  -2.4615144174391260e-02
    x_32_9    product_ub_104  -4.0227958431149860e-02
    x_32_9    onehot_32_111  1
    x_32_9    stock_lb_218  9
    x_32_9    stock_ub_219  9
    x_32_9    parent_nonstrict_scope_220  0.03
    x_32_9    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_103  1
    w_32_9    product_ub_104  1
    w_32_9    normalized_mass_32_112  1
    w_32_9    normalized_ratio_32_113  -1.8
    w_32_9    full_original_Gini_278  -2.3741666666666671e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_105  -2.4615144174391260e-02
    x_32_10   product_ub_106  -4.0227958431149860e-02
    x_32_10   onehot_32_111  1
    x_32_10   stock_lb_218  10
    x_32_10   stock_ub_219  10
    x_32_10   parent_nonstrict_scope_220  0.0375
    x_32_10   unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_105  1
    w_32_10   product_ub_106  1
    w_32_10   normalized_mass_32_112  1
    w_32_10   normalized_ratio_32_113  -2
    w_32_10   full_original_Gini_278  -2.9141666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_107  -2.4615144174391260e-02
    x_32_11   product_ub_108  -4.0227958431149860e-02
    x_32_11   onehot_32_111  1
    x_32_11   stock_lb_218  11
    x_32_11   stock_ub_219  11
    x_32_11   parent_nonstrict_scope_220  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_107  1
    w_32_11   product_ub_108  1
    w_32_11   normalized_mass_32_112  1
    w_32_11   normalized_ratio_32_113  -2.2
    w_32_11   full_original_Gini_278  -3.4541666666666657e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_109  -2.4615144174391260e-02
    x_32_12   product_ub_110  -4.0227958431149860e-02
    x_32_12   onehot_32_111  1
    x_32_12   stock_lb_218  12
    x_32_12   stock_ub_219  12
    x_32_12   parent_nonstrict_scope_220  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_109  1
    w_32_12   product_ub_110  1
    w_32_12   normalized_mass_32_112  1
    w_32_12   normalized_ratio_32_113  -2.4000000000000004e+00
    w_32_12   full_original_Gini_278  -3.9941666666666670e+01
    rho_32    normalized_ratio_32_113  1
    rho_32    block_pair_pos_243  1
    rho_32    block_pair_neg_244  -1
    rho_32    block_pair_pos_253  1
    rho_32    block_pair_neg_254  -1
    rho_32    block_pair_pos_255  -1
    rho_32    block_pair_neg_256  1
    rho_32    block_pair_pos_257  -1
    rho_32    block_pair_neg_258  1
    rho_32    block_pair_pos_259  -1
    rho_32    block_pair_neg_260  1
    rho_32    block_pair_pos_261  -1
    rho_32    block_pair_neg_262  1
    rho_32    block_pair_pos_275  1
    rho_32    block_pair_neg_276  -1
    rho_32    normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_114  -2.4615144174391260e-02
    x_19_0    product_ub_115  -4.0227958431149860e-02
    x_19_0    onehot_19_132  1
    x_19_0    parent_nonstrict_scope_220  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_114  1
    w_19_0    product_ub_115  1
    w_19_0    normalized_mass_19_133  1
    w_19_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_116  -2.4615144174391260e-02
    x_19_1    product_ub_117  -4.0227958431149860e-02
    x_19_1    onehot_19_132  1
    x_19_1    stock_lb_218  1
    x_19_1    stock_ub_219  1
    x_19_1    parent_nonstrict_scope_220  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_116  1
    w_19_1    product_ub_117  1
    w_19_1    normalized_mass_19_133  1
    w_19_1    normalized_ratio_19_134  -0.25
    w_19_1    full_original_Gini_278  -1.8108333333333338e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_118  -2.4615144174391260e-02
    x_19_2    product_ub_119  -4.0227958431149860e-02
    x_19_2    onehot_19_132  1
    x_19_2    stock_lb_218  2
    x_19_2    stock_ub_219  2
    x_19_2    parent_nonstrict_scope_220  0.012
    x_19_2    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_118  1
    w_19_2    product_ub_119  1
    w_19_2    normalized_mass_19_133  1
    w_19_2    normalized_ratio_19_134  -0.5
    w_19_2    full_original_Gini_278  -1.1558333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_120  -2.4615144174391260e-02
    x_19_3    product_ub_121  -4.0227958431149860e-02
    x_19_3    onehot_19_132  1
    x_19_3    stock_lb_218  3
    x_19_3    stock_ub_219  3
    x_19_3    parent_nonstrict_scope_220  0.006
    x_19_3    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_120  1
    w_19_3    product_ub_121  1
    w_19_3    normalized_mass_19_133  1
    w_19_3    normalized_ratio_19_134  -0.75
    w_19_3    full_original_Gini_278  -5.4511904761904741e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_122  -2.4615144174391260e-02
    x_19_4    product_ub_123  -4.0227958431149860e-02
    x_19_4    onehot_19_132  1
    x_19_4    stock_lb_218  4
    x_19_4    stock_ub_219  4
    x_19_4    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_122  1
    w_19_4    product_ub_123  1
    w_19_4    normalized_mass_19_133  1
    w_19_4    normalized_ratio_19_134  -1
    w_19_4    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_124  -2.4615144174391260e-02
    x_19_5    product_ub_125  -4.0227958431149860e-02
    x_19_5    onehot_19_132  1
    x_19_5    stock_lb_218  5
    x_19_5    stock_ub_219  5
    x_19_5    parent_nonstrict_scope_220  0.006
    x_19_5    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_124  1
    w_19_5    product_ub_125  1
    w_19_5    normalized_mass_19_133  1
    w_19_5    normalized_ratio_19_134  -1.25
    w_19_5    full_original_Gini_278  -8.8916666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_126  -2.4615144174391260e-02
    x_19_6    product_ub_127  -4.0227958431149860e-02
    x_19_6    onehot_19_132  1
    x_19_6    stock_lb_218  6
    x_19_6    stock_ub_219  6
    x_19_6    parent_nonstrict_scope_220  0.012
    x_19_6    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_126  1
    w_19_6    product_ub_127  1
    w_19_6    normalized_mass_19_133  1
    w_19_6    normalized_ratio_19_134  -1.5
    w_19_6    full_original_Gini_278  -1.5641666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_128  -2.4615144174391260e-02
    x_19_7    product_ub_129  -4.0227958431149860e-02
    x_19_7    onehot_19_132  1
    x_19_7    stock_lb_218  7
    x_19_7    stock_ub_219  7
    x_19_7    parent_nonstrict_scope_220  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_128  1
    w_19_7    product_ub_129  1
    w_19_7    normalized_mass_19_133  1
    w_19_7    normalized_ratio_19_134  -1.75
    w_19_7    full_original_Gini_278  -2.2391666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_130  -2.4615144174391260e-02
    x_19_8    product_ub_131  -4.0227958431149860e-02
    x_19_8    onehot_19_132  1
    x_19_8    stock_lb_218  8
    x_19_8    stock_ub_219  8
    x_19_8    parent_nonstrict_scope_220  0.024
    x_19_8    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_130  1
    w_19_8    product_ub_131  1
    w_19_8    normalized_mass_19_133  1
    w_19_8    normalized_ratio_19_134  -2
    w_19_8    full_original_Gini_278  -2.9141666666666666e+01
    rho_19    normalized_ratio_19_134  1
    rho_19    block_pair_pos_223  -1
    rho_19    block_pair_neg_224  1
    rho_19    block_pair_pos_225  -1
    rho_19    block_pair_neg_226  1
    rho_19    block_pair_pos_227  -1
    rho_19    block_pair_neg_228  1
    rho_19    block_pair_pos_237  1
    rho_19    block_pair_neg_238  -1
    rho_19    block_pair_pos_249  1
    rho_19    block_pair_neg_250  -1
    rho_19    block_pair_pos_259  1
    rho_19    block_pair_neg_260  -1
    rho_19    block_pair_pos_267  1
    rho_19    block_pair_neg_268  -1
    rho_19    normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_26_0    OBJ       0.012
    x_26_0    product_lb_135  -2.4615144174391260e-02
    x_26_0    product_ub_136  -4.0227958431149860e-02
    x_26_0    onehot_26_153  1
    x_26_0    parent_nonstrict_scope_220  0.024
    MARKER    'MARKER'                 'INTEND'
    w_26_0    product_lb_135  1
    w_26_0    product_ub_136  1
    w_26_0    normalized_mass_26_154  1
    w_26_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_1    OBJ       6.0000000000000019e-03
    x_26_1    product_lb_137  -2.4615144174391260e-02
    x_26_1    product_ub_138  -4.0227958431149860e-02
    x_26_1    onehot_26_153  1
    x_26_1    stock_lb_218  1
    x_26_1    stock_ub_219  1
    x_26_1    parent_nonstrict_scope_220  1.8000000000000002e-02
    x_26_1    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_1    product_lb_137  1
    w_26_1    product_ub_138  1
    w_26_1    normalized_mass_26_154  1
    w_26_1    normalized_ratio_26_155  -0.25
    w_26_1    full_original_Gini_278  -1.8108333333333338e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_2    product_lb_139  -2.4615144174391260e-02
    x_26_2    product_ub_140  -4.0227958431149860e-02
    x_26_2    onehot_26_153  1
    x_26_2    stock_lb_218  2
    x_26_2    stock_ub_219  2
    x_26_2    parent_nonstrict_scope_220  0.012
    x_26_2    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_2    product_lb_139  1
    w_26_2    product_ub_140  1
    w_26_2    normalized_mass_26_154  1
    w_26_2    normalized_ratio_26_155  -0.5
    w_26_2    full_original_Gini_278  -1.1558333333333335e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_3    OBJ       -0.006
    x_26_3    product_lb_141  -2.4615144174391260e-02
    x_26_3    product_ub_142  -4.0227958431149860e-02
    x_26_3    onehot_26_153  1
    x_26_3    stock_lb_218  3
    x_26_3    stock_ub_219  3
    x_26_3    parent_nonstrict_scope_220  0.006
    x_26_3    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_3    product_lb_141  1
    w_26_3    product_ub_142  1
    w_26_3    normalized_mass_26_154  1
    w_26_3    normalized_ratio_26_155  -0.75
    w_26_3    full_original_Gini_278  -5.4511904761904741e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_4    OBJ       -0.012
    x_26_4    product_lb_143  -2.4615144174391260e-02
    x_26_4    product_ub_144  -4.0227958431149860e-02
    x_26_4    onehot_26_153  1
    x_26_4    stock_lb_218  4
    x_26_4    stock_ub_219  4
    x_26_4    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_4    product_lb_143  1
    w_26_4    product_ub_144  1
    w_26_4    normalized_mass_26_154  1
    w_26_4    normalized_ratio_26_155  -1
    w_26_4    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_5    OBJ       -0.006
    x_26_5    product_lb_145  -2.4615144174391260e-02
    x_26_5    product_ub_146  -4.0227958431149860e-02
    x_26_5    onehot_26_153  1
    x_26_5    stock_lb_218  5
    x_26_5    stock_ub_219  5
    x_26_5    parent_nonstrict_scope_220  0.006
    x_26_5    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_5    product_lb_145  1
    w_26_5    product_ub_146  1
    w_26_5    normalized_mass_26_154  1
    w_26_5    normalized_ratio_26_155  -1.25
    w_26_5    full_original_Gini_278  -8.8916666666666675e+00
    MARKER    'MARKER'                 'INTORG'
    x_26_6    product_lb_147  -2.4615144174391260e-02
    x_26_6    product_ub_148  -4.0227958431149860e-02
    x_26_6    onehot_26_153  1
    x_26_6    stock_lb_218  6
    x_26_6    stock_ub_219  6
    x_26_6    parent_nonstrict_scope_220  0.012
    x_26_6    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_6    product_lb_147  1
    w_26_6    product_ub_148  1
    w_26_6    normalized_mass_26_154  1
    w_26_6    normalized_ratio_26_155  -1.5
    w_26_6    full_original_Gini_278  -1.5641666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_7    OBJ       6.0000000000000019e-03
    x_26_7    product_lb_149  -2.4615144174391260e-02
    x_26_7    product_ub_150  -4.0227958431149860e-02
    x_26_7    onehot_26_153  1
    x_26_7    stock_lb_218  7
    x_26_7    stock_ub_219  7
    x_26_7    parent_nonstrict_scope_220  1.8000000000000002e-02
    x_26_7    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_7    product_lb_149  1
    w_26_7    product_ub_150  1
    w_26_7    normalized_mass_26_154  1
    w_26_7    normalized_ratio_26_155  -1.75
    w_26_7    full_original_Gini_278  -2.2391666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_26_8    OBJ       0.012
    x_26_8    product_lb_151  -2.4615144174391260e-02
    x_26_8    product_ub_152  -4.0227958431149860e-02
    x_26_8    onehot_26_153  1
    x_26_8    stock_lb_218  8
    x_26_8    stock_ub_219  8
    x_26_8    parent_nonstrict_scope_220  0.024
    x_26_8    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_26_8    product_lb_151  1
    w_26_8    product_ub_152  1
    w_26_8    normalized_mass_26_154  1
    w_26_8    normalized_ratio_26_155  -2
    w_26_8    full_original_Gini_278  -2.9141666666666666e+01
    rho_26    normalized_ratio_26_155  1
    rho_26    block_pair_pos_227  1
    rho_26    block_pair_neg_228  -1
    rho_26    block_pair_pos_229  -1
    rho_26    block_pair_neg_230  1
    rho_26    block_pair_pos_231  -1
    rho_26    block_pair_neg_232  1
    rho_26    block_pair_pos_239  1
    rho_26    block_pair_neg_240  -1
    rho_26    block_pair_pos_251  1
    rho_26    block_pair_neg_252  -1
    rho_26    block_pair_pos_261  1
    rho_26    block_pair_neg_262  -1
    rho_26    block_pair_pos_269  1
    rho_26    block_pair_neg_270  -1
    rho_26    normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_156  -2.4615144174391260e-02
    x_6_0     product_ub_157  -4.0227958431149860e-02
    x_6_0     onehot_6_178  1
    x_6_0     parent_nonstrict_scope_220  0.0375
    x_6_0     unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_156  1
    w_6_0     product_ub_157  1
    w_6_0     normalized_mass_6_179  1
    w_6_0     full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_158  -2.4615144174391260e-02
    x_6_1     product_ub_159  -4.0227958431149860e-02
    x_6_1     onehot_6_178  1
    x_6_1     stock_lb_218  1
    x_6_1     stock_ub_219  1
    x_6_1     parent_nonstrict_scope_220  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_158  1
    w_6_1     product_ub_159  1
    w_6_1     normalized_mass_6_179  1
    w_6_1     normalized_ratio_6_180  -0.2
    w_6_1     full_original_Gini_278  -1.9458333333333339e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_160  -2.4615144174391260e-02
    x_6_2     product_ub_161  -4.0227958431149860e-02
    x_6_2     onehot_6_178  1
    x_6_2     stock_lb_218  2
    x_6_2     stock_ub_219  2
    x_6_2     parent_nonstrict_scope_220  0.0225
    x_6_2     unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_160  1
    w_6_2     product_ub_161  1
    w_6_2     normalized_mass_6_179  1
    w_6_2     normalized_ratio_6_180  -0.4
    w_6_2     full_original_Gini_278  -1.4058333333333330e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_162  -2.4615144174391260e-02
    x_6_3     product_ub_163  -4.0227958431149860e-02
    x_6_3     onehot_6_178  1
    x_6_3     stock_lb_218  3
    x_6_3     stock_ub_219  3
    x_6_3     parent_nonstrict_scope_220  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_162  1
    w_6_3     product_ub_163  1
    w_6_3     normalized_mass_6_179  1
    w_6_3     normalized_ratio_6_180  -6.0000000000000009e-01
    w_6_3     full_original_Gini_278  -9.0583333333333318e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_164  -2.4615144174391260e-02
    x_6_4     product_ub_165  -4.0227958431149860e-02
    x_6_4     onehot_6_178  1
    x_6_4     stock_lb_218  4
    x_6_4     stock_ub_219  4
    x_6_4     parent_nonstrict_scope_220  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_164  1
    w_6_4     product_ub_165  1
    w_6_4     normalized_mass_6_179  1
    w_6_4     normalized_ratio_6_180  -0.8
    w_6_4     full_original_Gini_278  -4.4011904761904779e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_166  -2.4615144174391260e-02
    x_6_5     product_ub_167  -4.0227958431149860e-02
    x_6_5     onehot_6_178  1
    x_6_5     stock_lb_218  5
    x_6_5     stock_ub_219  5
    x_6_5     unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_166  1
    w_6_5     product_ub_167  1
    w_6_5     normalized_mass_6_179  1
    w_6_5     normalized_ratio_6_180  -1
    w_6_5     full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_168  -2.4615144174391260e-02
    x_6_6     product_ub_169  -4.0227958431149860e-02
    x_6_6     onehot_6_178  1
    x_6_6     stock_lb_218  6
    x_6_6     stock_ub_219  6
    x_6_6     parent_nonstrict_scope_220  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_168  1
    w_6_6     product_ub_169  1
    w_6_6     normalized_mass_6_179  1
    w_6_6     normalized_ratio_6_180  -1.2000000000000002e+00
    w_6_6     full_original_Gini_278  -7.5416666666666723e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_170  -2.4615144174391260e-02
    x_6_7     product_ub_171  -4.0227958431149860e-02
    x_6_7     onehot_6_178  1
    x_6_7     stock_lb_218  7
    x_6_7     stock_ub_219  7
    x_6_7     parent_nonstrict_scope_220  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_170  1
    w_6_7     product_ub_171  1
    w_6_7     normalized_mass_6_179  1
    w_6_7     normalized_ratio_6_180  -1.4000000000000001e+00
    w_6_7     full_original_Gini_278  -1.2941666666666672e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_172  -2.4615144174391260e-02
    x_6_8     product_ub_173  -4.0227958431149860e-02
    x_6_8     onehot_6_178  1
    x_6_8     stock_lb_218  8
    x_6_8     stock_ub_219  8
    x_6_8     parent_nonstrict_scope_220  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_172  1
    w_6_8     product_ub_173  1
    w_6_8     normalized_mass_6_179  1
    w_6_8     normalized_ratio_6_180  -1.6
    w_6_8     full_original_Gini_278  -1.8341666666666669e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_174  -2.4615144174391260e-02
    x_6_9     product_ub_175  -4.0227958431149860e-02
    x_6_9     onehot_6_178  1
    x_6_9     stock_lb_218  9
    x_6_9     stock_ub_219  9
    x_6_9     parent_nonstrict_scope_220  0.03
    x_6_9     unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_174  1
    w_6_9     product_ub_175  1
    w_6_9     normalized_mass_6_179  1
    w_6_9     normalized_ratio_6_180  -1.8
    w_6_9     full_original_Gini_278  -2.3741666666666671e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_176  -2.4615144174391260e-02
    x_6_10    product_ub_177  -4.0227958431149860e-02
    x_6_10    onehot_6_178  1
    x_6_10    stock_lb_218  10
    x_6_10    stock_ub_219  10
    x_6_10    parent_nonstrict_scope_220  0.0375
    x_6_10    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_176  1
    w_6_10    product_ub_177  1
    w_6_10    normalized_mass_6_179  1
    w_6_10    normalized_ratio_6_180  -2
    w_6_10    full_original_Gini_278  -2.9141666666666666e+01
    rho_6     normalized_ratio_6_180  1
    rho_6     block_pair_pos_221  -1
    rho_6     block_pair_neg_222  1
    rho_6     block_pair_pos_223  1
    rho_6     block_pair_neg_224  -1
    rho_6     block_pair_pos_229  1
    rho_6     block_pair_neg_230  -1
    rho_6     block_pair_pos_233  1
    rho_6     block_pair_neg_234  -1
    rho_6     block_pair_pos_245  1
    rho_6     block_pair_neg_246  -1
    rho_6     block_pair_pos_255  1
    rho_6     block_pair_neg_256  -1
    rho_6     block_pair_pos_263  1
    rho_6     block_pair_neg_264  -1
    rho_6     normalization_277  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       0.06075
    x_17_0    product_lb_181  -2.4615144174391260e-02
    x_17_0    product_ub_182  -4.0227958431149860e-02
    x_17_0    onehot_17_215  1
    x_17_0    parent_nonstrict_scope_220  0.1215
    x_17_0    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_181  1
    w_17_0    product_ub_182  1
    w_17_0    normalized_mass_17_216  1
    w_17_0    full_original_Gini_278  -2.4858333333333334e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.7249999999999986e-02
    x_17_1    product_lb_183  -2.4615144174391260e-02
    x_17_1    product_ub_184  -4.0227958431149860e-02
    x_17_1    onehot_17_215  1
    x_17_1    stock_lb_218  1
    x_17_1    stock_ub_219  1
    x_17_1    parent_nonstrict_scope_220  1.0799999999999998e-01
    x_17_1    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_183  1
    w_17_1    product_ub_184  1
    w_17_1    normalized_mass_17_216  1
    w_17_1    normalized_ratio_17_217  -1.1111111111111110e-01
    w_17_1    full_original_Gini_278  -2.1858333333333338e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       0.03375
    x_17_2    product_lb_185  -2.4615144174391260e-02
    x_17_2    product_ub_186  -4.0227958431149860e-02
    x_17_2    onehot_17_215  1
    x_17_2    stock_lb_218  2
    x_17_2    stock_ub_219  2
    x_17_2    parent_nonstrict_scope_220  0.0945
    x_17_2    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_185  1
    w_17_2    product_ub_186  1
    w_17_2    normalized_mass_17_216  1
    w_17_2    normalized_ratio_17_217  -2.2222222222222221e-01
    w_17_2    full_original_Gini_278  -1.8858333333333341e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.0250000000000004e-02
    x_17_3    product_lb_187  -2.4615144174391260e-02
    x_17_3    product_ub_188  -4.0227958431149860e-02
    x_17_3    onehot_17_215  1
    x_17_3    stock_lb_218  3
    x_17_3    stock_ub_219  3
    x_17_3    parent_nonstrict_scope_220  0.081
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_187  1
    w_17_3    product_ub_188  1
    w_17_3    normalized_mass_17_216  1
    w_17_3    normalized_ratio_17_217  -3.3333333333333331e-01
    w_17_3    full_original_Gini_278  -1.5858333333333331e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       6.7500000000000060e-03
    x_17_4    product_lb_189  -2.4615144174391260e-02
    x_17_4    product_ub_190  -4.0227958431149860e-02
    x_17_4    onehot_17_215  1
    x_17_4    stock_lb_218  4
    x_17_4    stock_ub_219  4
    x_17_4    parent_nonstrict_scope_220  0.0675
    x_17_4    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_189  1
    w_17_4    product_ub_190  1
    w_17_4    normalized_mass_17_216  1
    w_17_4    normalized_ratio_17_217  -4.4444444444444442e-01
    w_17_4    full_original_Gini_278  -1.2947222222222221e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -6.7500000000000060e-03
    x_17_5    product_lb_191  -2.4615144174391260e-02
    x_17_5    product_ub_192  -4.0227958431149860e-02
    x_17_5    onehot_17_215  1
    x_17_5    stock_lb_218  5
    x_17_5    stock_ub_219  5
    x_17_5    parent_nonstrict_scope_220  5.3999999999999992e-02
    x_17_5    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_191  1
    w_17_5    product_ub_192  1
    w_17_5    normalized_mass_17_216  1
    w_17_5    normalized_ratio_17_217  -5.5555555555555558e-01
    w_17_5    full_original_Gini_278  -1.0169444444444448e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.0249999999999997e-02
    x_17_6    product_lb_193  -2.4615144174391260e-02
    x_17_6    product_ub_194  -4.0227958431149860e-02
    x_17_6    onehot_17_215  1
    x_17_6    stock_lb_218  6
    x_17_6    stock_ub_219  6
    x_17_6    parent_nonstrict_scope_220  0.0405
    x_17_6    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_193  1
    w_17_6    product_ub_194  1
    w_17_6    normalized_mass_17_216  1
    w_17_6    normalized_ratio_17_217  -6.6666666666666663e-01
    w_17_6    full_original_Gini_278  -7.3916666666666666e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.3749999999999988e-02
    x_17_7    product_lb_195  -2.4615144174391260e-02
    x_17_7    product_ub_196  -4.0227958431149860e-02
    x_17_7    onehot_17_215  1
    x_17_7    stock_lb_218  7
    x_17_7    stock_ub_219  7
    x_17_7    parent_nonstrict_scope_220  2.7000000000000010e-02
    x_17_7    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_195  1
    w_17_7    product_ub_196  1
    w_17_7    normalized_mass_17_216  1
    w_17_7    normalized_ratio_17_217  -7.7777777777777768e-01
    w_17_7    full_original_Gini_278  -4.8678571428571438e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.7249999999999993e-02
    x_17_8    product_lb_197  -2.4615144174391260e-02
    x_17_8    product_ub_198  -4.0227958431149860e-02
    x_17_8    onehot_17_215  1
    x_17_8    stock_lb_218  8
    x_17_8    stock_ub_219  8
    x_17_8    parent_nonstrict_scope_220  1.3500000000000005e-02
    x_17_8    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_197  1
    w_17_8    product_ub_198  1
    w_17_8    normalized_mass_17_216  1
    w_17_8    normalized_ratio_17_217  -8.8888888888888884e-01
    w_17_8    full_original_Gini_278  -3.0972222222222228e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -0.06075
    x_17_9    product_lb_199  -2.4615144174391260e-02
    x_17_9    product_ub_200  -4.0227958431149860e-02
    x_17_9    onehot_17_215  1
    x_17_9    stock_lb_218  9
    x_17_9    stock_ub_219  9
    x_17_9    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_199  1
    w_17_9    product_ub_200  1
    w_17_9    normalized_mass_17_216  1
    w_17_9    normalized_ratio_17_217  -1
    w_17_9    full_original_Gini_278  -2.5416666666666670e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.7249999999999993e-02
    x_17_10   product_lb_201  -2.4615144174391260e-02
    x_17_10   product_ub_202  -4.0227958431149860e-02
    x_17_10   onehot_17_215  1
    x_17_10   stock_lb_218  10
    x_17_10   stock_ub_219  10
    x_17_10   parent_nonstrict_scope_220  1.3500000000000005e-02
    x_17_10   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_201  1
    w_17_10   product_ub_202  1
    w_17_10   normalized_mass_17_216  1
    w_17_10   normalized_ratio_17_217  -1.1111111111111112e+00
    w_17_10   full_original_Gini_278  -5.3194444444444464e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.3750000000000016e-02
    x_17_11   product_lb_203  -2.4615144174391260e-02
    x_17_11   product_ub_204  -4.0227958431149860e-02
    x_17_11   onehot_17_215  1
    x_17_11   stock_lb_218  11
    x_17_11   stock_ub_219  11
    x_17_11   parent_nonstrict_scope_220  2.6999999999999986e-02
    x_17_11   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_203  1
    w_17_11   product_ub_204  1
    w_17_11   normalized_mass_17_216  1
    w_17_11   normalized_ratio_17_217  -1.2222222222222221e+00
    w_17_11   full_original_Gini_278  -8.1416666666666657e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.0250000000000011e-02
    x_17_12   product_lb_205  -2.4615144174391260e-02
    x_17_12   product_ub_206  -4.0227958431149860e-02
    x_17_12   onehot_17_215  1
    x_17_12   stock_lb_218  12
    x_17_12   stock_ub_219  12
    x_17_12   parent_nonstrict_scope_220  4.0499999999999987e-02
    x_17_12   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_205  1
    w_17_12   product_ub_206  1
    w_17_12   normalized_mass_17_216  1
    w_17_12   normalized_ratio_17_217  -1.3333333333333333e+00
    w_17_12   full_original_Gini_278  -1.1141666666666664e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -6.7500000000000060e-03
    x_17_13   product_lb_207  -2.4615144174391260e-02
    x_17_13   product_ub_208  -4.0227958431149860e-02
    x_17_13   onehot_17_215  1
    x_17_13   stock_lb_218  13
    x_17_13   stock_ub_219  13
    x_17_13   parent_nonstrict_scope_220  5.3999999999999992e-02
    x_17_13   unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_207  1
    w_17_13   product_ub_208  1
    w_17_13   normalized_mass_17_216  1
    w_17_13   normalized_ratio_17_217  -1.4444444444444444e+00
    w_17_13   full_original_Gini_278  -1.4141666666666667e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       6.7499999999999782e-03
    x_17_14   product_lb_209  -2.4615144174391260e-02
    x_17_14   product_ub_210  -4.0227958431149860e-02
    x_17_14   onehot_17_215  1
    x_17_14   stock_lb_218  14
    x_17_14   stock_ub_219  14
    x_17_14   parent_nonstrict_scope_220  6.7499999999999977e-02
    x_17_14   unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_209  1
    w_17_14   product_ub_210  1
    w_17_14   normalized_mass_17_216  1
    w_17_14   normalized_ratio_17_217  -1.5555555555555554e+00
    w_17_14   full_original_Gini_278  -1.7141666666666659e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.0249999999999976e-02
    x_17_15   product_lb_211  -2.4615144174391260e-02
    x_17_15   product_ub_212  -4.0227958431149860e-02
    x_17_15   onehot_17_215  1
    x_17_15   stock_lb_218  15
    x_17_15   stock_ub_219  15
    x_17_15   parent_nonstrict_scope_220  8.0999999999999975e-02
    x_17_15   unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_211  1
    w_17_15   product_ub_212  1
    w_17_15   normalized_mass_17_216  1
    w_17_15   normalized_ratio_17_217  -1.6666666666666665e+00
    w_17_15   full_original_Gini_278  -2.0141666666666662e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.3749999999999988e-02
    x_17_16   product_lb_213  -2.4615144174391260e-02
    x_17_16   product_ub_214  -4.0227958431149860e-02
    x_17_16   onehot_17_215  1
    x_17_16   stock_lb_218  16
    x_17_16   stock_ub_219  16
    x_17_16   parent_nonstrict_scope_220  9.4499999999999987e-02
    x_17_16   unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_213  1
    w_17_16   product_ub_214  1
    w_17_16   normalized_mass_17_216  1
    w_17_16   normalized_ratio_17_217  -1.7777777777777777e+00
    w_17_16   full_original_Gini_278  -2.3141666666666669e+01
    rho_17    normalized_ratio_17_217  1
    rho_17    block_pair_pos_221  1
    rho_17    block_pair_neg_222  -1
    rho_17    block_pair_pos_225  1
    rho_17    block_pair_neg_226  -1
    rho_17    block_pair_pos_231  1
    rho_17    block_pair_neg_232  -1
    rho_17    block_pair_pos_235  1
    rho_17    block_pair_neg_236  -1
    rho_17    block_pair_pos_247  1
    rho_17    block_pair_neg_248  -1
    rho_17    block_pair_pos_257  1
    rho_17    block_pair_neg_258  -1
    rho_17    block_pair_pos_265  1
    rho_17    block_pair_neg_266  -1
    rho_17    normalization_277  1
    a_35_30   block_pair_pos_271  1
    a_35_30   block_pair_neg_272  1
    a_35_30   full_original_Gini_278  -1
    a_35_31   block_pair_pos_273  1
    a_35_31   block_pair_neg_274  1
    a_35_31   full_original_Gini_278  -1
    a_35_32   block_pair_pos_275  1
    a_35_32   block_pair_neg_276  1
    a_35_32   full_original_Gini_278  -1
    a_35_19   block_pair_pos_267  1
    a_35_19   block_pair_neg_268  1
    a_35_19   full_original_Gini_278  -1
    a_35_26   block_pair_pos_269  1
    a_35_26   block_pair_neg_270  1
    a_35_26   full_original_Gini_278  -1
    a_35_6    block_pair_pos_263  1
    a_35_6    block_pair_neg_264  1
    a_35_6    full_original_Gini_278  -1
    a_35_17   block_pair_pos_265  1
    a_35_17   block_pair_neg_266  1
    a_35_17   full_original_Gini_278  -1
    a_30_31   block_pair_pos_241  1
    a_30_31   block_pair_neg_242  1
    a_30_31   full_original_Gini_278  -1
    a_30_32   block_pair_pos_243  1
    a_30_32   block_pair_neg_244  1
    a_30_32   full_original_Gini_278  -1
    a_30_19   block_pair_pos_237  1
    a_30_19   block_pair_neg_238  1
    a_30_19   full_original_Gini_278  -1
    a_30_26   block_pair_pos_239  1
    a_30_26   block_pair_neg_240  1
    a_30_26   full_original_Gini_278  -1
    a_30_6    block_pair_pos_233  1
    a_30_6    block_pair_neg_234  1
    a_30_6    full_original_Gini_278  -1
    a_30_17   block_pair_pos_235  1
    a_30_17   block_pair_neg_236  1
    a_30_17   full_original_Gini_278  -1
    a_31_32   block_pair_pos_253  1
    a_31_32   block_pair_neg_254  1
    a_31_32   full_original_Gini_278  -1
    a_31_19   block_pair_pos_249  1
    a_31_19   block_pair_neg_250  1
    a_31_19   full_original_Gini_278  -1
    a_31_26   block_pair_pos_251  1
    a_31_26   block_pair_neg_252  1
    a_31_26   full_original_Gini_278  -1
    a_31_6    block_pair_pos_245  1
    a_31_6    block_pair_neg_246  1
    a_31_6    full_original_Gini_278  -1
    a_31_17   block_pair_pos_247  1
    a_31_17   block_pair_neg_248  1
    a_31_17   full_original_Gini_278  -1
    a_32_19   block_pair_pos_259  1
    a_32_19   block_pair_neg_260  1
    a_32_19   full_original_Gini_278  -1
    a_32_26   block_pair_pos_261  1
    a_32_26   block_pair_neg_262  1
    a_32_26   full_original_Gini_278  -1
    a_32_6    block_pair_pos_255  1
    a_32_6    block_pair_neg_256  1
    a_32_6    full_original_Gini_278  -1
    a_32_17   block_pair_pos_257  1
    a_32_17   block_pair_neg_258  1
    a_32_17   full_original_Gini_278  -1
    a_19_26   block_pair_pos_227  1
    a_19_26   block_pair_neg_228  1
    a_19_26   full_original_Gini_278  -1
    a_19_6    block_pair_pos_223  1
    a_19_6    block_pair_neg_224  1
    a_19_6    full_original_Gini_278  -1
    a_19_17   block_pair_pos_225  1
    a_19_17   block_pair_neg_226  1
    a_19_17   full_original_Gini_278  -1
    a_26_6    block_pair_pos_229  1
    a_26_6    block_pair_neg_230  1
    a_26_6    full_original_Gini_278  -1
    a_26_17   block_pair_pos_231  1
    a_26_17   block_pair_neg_232  1
    a_26_17   full_original_Gini_278  -1
    a_6_17    block_pair_pos_221  1
    a_6_17    block_pair_neg_222  1
    a_6_17    full_original_Gini_278  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_35_0  unique_nonzero_owner_279  1
    service_0_35_0  service_visit_def_748  1
    service_0_35_0  free_load_conservation_749  -11
    service_0_35_0  original_T_including_depot_unload_796  1320
    service_0_35_1  unique_nonzero_owner_280  1
    service_0_35_1  service_visit_def_748  1
    service_0_35_1  free_load_conservation_749  -10
    service_0_35_1  original_T_including_depot_unload_796  1200
    service_0_35_2  unique_nonzero_owner_281  1
    service_0_35_2  service_visit_def_748  1
    service_0_35_2  free_load_conservation_749  -9
    service_0_35_2  original_T_including_depot_unload_796  1080
    service_0_35_3  unique_nonzero_owner_282  1
    service_0_35_3  service_visit_def_748  1
    service_0_35_3  free_load_conservation_749  -8
    service_0_35_3  original_T_including_depot_unload_796  960
    service_0_35_4  unique_nonzero_owner_283  1
    service_0_35_4  service_visit_def_748  1
    service_0_35_4  free_load_conservation_749  -7
    service_0_35_4  original_T_including_depot_unload_796  840
    service_0_35_5  unique_nonzero_owner_284  1
    service_0_35_5  service_visit_def_748  1
    service_0_35_5  free_load_conservation_749  -6
    service_0_35_5  original_T_including_depot_unload_796  720
    service_0_35_6  unique_nonzero_owner_285  1
    service_0_35_6  service_visit_def_748  1
    service_0_35_6  free_load_conservation_749  -5
    service_0_35_6  original_T_including_depot_unload_796  600
    service_0_35_7  unique_nonzero_owner_286  1
    service_0_35_7  service_visit_def_748  1
    service_0_35_7  free_load_conservation_749  -4
    service_0_35_7  original_T_including_depot_unload_796  480
    service_0_35_8  unique_nonzero_owner_287  1
    service_0_35_8  service_visit_def_748  1
    service_0_35_8  free_load_conservation_749  -3
    service_0_35_8  original_T_including_depot_unload_796  360
    service_0_35_9  unique_nonzero_owner_288  1
    service_0_35_9  service_visit_def_748  1
    service_0_35_9  free_load_conservation_749  -2
    service_0_35_9  original_T_including_depot_unload_796  240
    service_0_35_10  unique_nonzero_owner_289  1
    service_0_35_10  service_visit_def_748  1
    service_0_35_10  free_load_conservation_749  -1
    service_0_35_10  original_T_including_depot_unload_796  120
    service_0_35_12  unique_nonzero_owner_290  1
    service_0_35_12  service_visit_def_748  1
    service_0_35_12  free_load_conservation_749  1
    service_0_35_13  unique_nonzero_owner_291  1
    service_0_35_13  service_visit_def_748  1
    service_0_35_13  free_load_conservation_749  2
    service_0_35_14  unique_nonzero_owner_292  1
    service_0_35_14  service_visit_def_748  1
    service_0_35_14  free_load_conservation_749  3
    service_0_35_15  unique_nonzero_owner_293  1
    service_0_35_15  service_visit_def_748  1
    service_0_35_15  free_load_conservation_749  4
    service_1_35_0  unique_nonzero_owner_279  1
    service_1_35_0  service_visit_def_1120  1
    service_1_35_0  free_load_conservation_1121  -11
    service_1_35_0  original_T_including_depot_unload_1167  1320
    service_1_35_1  unique_nonzero_owner_280  1
    service_1_35_1  service_visit_def_1120  1
    service_1_35_1  free_load_conservation_1121  -10
    service_1_35_1  original_T_including_depot_unload_1167  1200
    service_1_35_2  unique_nonzero_owner_281  1
    service_1_35_2  service_visit_def_1120  1
    service_1_35_2  free_load_conservation_1121  -9
    service_1_35_2  original_T_including_depot_unload_1167  1080
    service_1_35_3  unique_nonzero_owner_282  1
    service_1_35_3  service_visit_def_1120  1
    service_1_35_3  free_load_conservation_1121  -8
    service_1_35_3  original_T_including_depot_unload_1167  960
    service_1_35_4  unique_nonzero_owner_283  1
    service_1_35_4  service_visit_def_1120  1
    service_1_35_4  free_load_conservation_1121  -7
    service_1_35_4  original_T_including_depot_unload_1167  840
    service_1_35_5  unique_nonzero_owner_284  1
    service_1_35_5  service_visit_def_1120  1
    service_1_35_5  free_load_conservation_1121  -6
    service_1_35_5  original_T_including_depot_unload_1167  720
    service_1_35_6  unique_nonzero_owner_285  1
    service_1_35_6  service_visit_def_1120  1
    service_1_35_6  free_load_conservation_1121  -5
    service_1_35_6  original_T_including_depot_unload_1167  600
    service_1_35_7  unique_nonzero_owner_286  1
    service_1_35_7  service_visit_def_1120  1
    service_1_35_7  free_load_conservation_1121  -4
    service_1_35_7  original_T_including_depot_unload_1167  480
    service_1_35_8  unique_nonzero_owner_287  1
    service_1_35_8  service_visit_def_1120  1
    service_1_35_8  free_load_conservation_1121  -3
    service_1_35_8  original_T_including_depot_unload_1167  360
    service_1_35_9  unique_nonzero_owner_288  1
    service_1_35_9  service_visit_def_1120  1
    service_1_35_9  free_load_conservation_1121  -2
    service_1_35_9  original_T_including_depot_unload_1167  240
    service_1_35_10  unique_nonzero_owner_289  1
    service_1_35_10  service_visit_def_1120  1
    service_1_35_10  free_load_conservation_1121  -1
    service_1_35_10  original_T_including_depot_unload_1167  120
    service_1_35_12  unique_nonzero_owner_290  1
    service_1_35_12  service_visit_def_1120  1
    service_1_35_12  free_load_conservation_1121  1
    service_1_35_13  unique_nonzero_owner_291  1
    service_1_35_13  service_visit_def_1120  1
    service_1_35_13  free_load_conservation_1121  2
    service_1_35_14  unique_nonzero_owner_292  1
    service_1_35_14  service_visit_def_1120  1
    service_1_35_14  free_load_conservation_1121  3
    service_1_35_15  unique_nonzero_owner_293  1
    service_1_35_15  service_visit_def_1120  1
    service_1_35_15  free_load_conservation_1121  4
    service_2_35_0  unique_nonzero_owner_279  1
    service_2_35_0  service_visit_def_1548  1
    service_2_35_0  free_load_conservation_1549  -11
    service_2_35_0  original_T_including_depot_unload_1596  1320
    service_2_35_1  unique_nonzero_owner_280  1
    service_2_35_1  service_visit_def_1548  1
    service_2_35_1  free_load_conservation_1549  -10
    service_2_35_1  original_T_including_depot_unload_1596  1200
    service_2_35_2  unique_nonzero_owner_281  1
    service_2_35_2  service_visit_def_1548  1
    service_2_35_2  free_load_conservation_1549  -9
    service_2_35_2  original_T_including_depot_unload_1596  1080
    service_2_35_3  unique_nonzero_owner_282  1
    service_2_35_3  service_visit_def_1548  1
    service_2_35_3  free_load_conservation_1549  -8
    service_2_35_3  original_T_including_depot_unload_1596  960
    service_2_35_4  unique_nonzero_owner_283  1
    service_2_35_4  service_visit_def_1548  1
    service_2_35_4  free_load_conservation_1549  -7
    service_2_35_4  original_T_including_depot_unload_1596  840
    service_2_35_5  unique_nonzero_owner_284  1
    service_2_35_5  service_visit_def_1548  1
    service_2_35_5  free_load_conservation_1549  -6
    service_2_35_5  original_T_including_depot_unload_1596  720
    service_2_35_6  unique_nonzero_owner_285  1
    service_2_35_6  service_visit_def_1548  1
    service_2_35_6  free_load_conservation_1549  -5
    service_2_35_6  original_T_including_depot_unload_1596  600
    service_2_35_7  unique_nonzero_owner_286  1
    service_2_35_7  service_visit_def_1548  1
    service_2_35_7  free_load_conservation_1549  -4
    service_2_35_7  original_T_including_depot_unload_1596  480
    service_2_35_8  unique_nonzero_owner_287  1
    service_2_35_8  service_visit_def_1548  1
    service_2_35_8  free_load_conservation_1549  -3
    service_2_35_8  original_T_including_depot_unload_1596  360
    service_2_35_9  unique_nonzero_owner_288  1
    service_2_35_9  service_visit_def_1548  1
    service_2_35_9  free_load_conservation_1549  -2
    service_2_35_9  original_T_including_depot_unload_1596  240
    service_2_35_10  unique_nonzero_owner_289  1
    service_2_35_10  service_visit_def_1548  1
    service_2_35_10  free_load_conservation_1549  -1
    service_2_35_10  original_T_including_depot_unload_1596  120
    service_2_35_12  unique_nonzero_owner_290  1
    service_2_35_12  service_visit_def_1548  1
    service_2_35_12  free_load_conservation_1549  1
    service_2_35_13  unique_nonzero_owner_291  1
    service_2_35_13  service_visit_def_1548  1
    service_2_35_13  free_load_conservation_1549  2
    service_2_35_14  unique_nonzero_owner_292  1
    service_2_35_14  service_visit_def_1548  1
    service_2_35_14  free_load_conservation_1549  3
    service_2_35_15  unique_nonzero_owner_293  1
    service_2_35_15  service_visit_def_1548  1
    service_2_35_15  free_load_conservation_1549  4
    service_0_30_0  unique_nonzero_owner_294  1
    service_0_30_0  service_visit_def_754  1
    service_0_30_0  free_load_conservation_755  -5
    service_0_30_0  original_T_including_depot_unload_796  600
    service_0_30_1  unique_nonzero_owner_295  1
    service_0_30_1  service_visit_def_754  1
    service_0_30_1  free_load_conservation_755  -4
    service_0_30_1  original_T_including_depot_unload_796  480
    service_0_30_2  unique_nonzero_owner_296  1
    service_0_30_2  service_visit_def_754  1
    service_0_30_2  free_load_conservation_755  -3
    service_0_30_2  original_T_including_depot_unload_796  360
    service_0_30_3  unique_nonzero_owner_297  1
    service_0_30_3  service_visit_def_754  1
    service_0_30_3  free_load_conservation_755  -2
    service_0_30_3  original_T_including_depot_unload_796  240
    service_0_30_4  unique_nonzero_owner_298  1
    service_0_30_4  service_visit_def_754  1
    service_0_30_4  free_load_conservation_755  -1
    service_0_30_4  original_T_including_depot_unload_796  120
    service_0_30_6  unique_nonzero_owner_299  1
    service_0_30_6  service_visit_def_754  1
    service_0_30_6  free_load_conservation_755  1
    service_0_30_7  unique_nonzero_owner_300  1
    service_0_30_7  service_visit_def_754  1
    service_0_30_7  free_load_conservation_755  2
    service_0_30_8  unique_nonzero_owner_301  1
    service_0_30_8  service_visit_def_754  1
    service_0_30_8  free_load_conservation_755  3
    service_1_30_0  unique_nonzero_owner_294  1
    service_1_30_0  service_visit_def_1126  1
    service_1_30_0  free_load_conservation_1127  -5
    service_1_30_0  original_T_including_depot_unload_1167  600
    service_1_30_1  unique_nonzero_owner_295  1
    service_1_30_1  service_visit_def_1126  1
    service_1_30_1  free_load_conservation_1127  -4
    service_1_30_1  original_T_including_depot_unload_1167  480
    service_1_30_2  unique_nonzero_owner_296  1
    service_1_30_2  service_visit_def_1126  1
    service_1_30_2  free_load_conservation_1127  -3
    service_1_30_2  original_T_including_depot_unload_1167  360
    service_1_30_3  unique_nonzero_owner_297  1
    service_1_30_3  service_visit_def_1126  1
    service_1_30_3  free_load_conservation_1127  -2
    service_1_30_3  original_T_including_depot_unload_1167  240
    service_1_30_4  unique_nonzero_owner_298  1
    service_1_30_4  service_visit_def_1126  1
    service_1_30_4  free_load_conservation_1127  -1
    service_1_30_4  original_T_including_depot_unload_1167  120
    service_1_30_6  unique_nonzero_owner_299  1
    service_1_30_6  service_visit_def_1126  1
    service_1_30_6  free_load_conservation_1127  1
    service_1_30_7  unique_nonzero_owner_300  1
    service_1_30_7  service_visit_def_1126  1
    service_1_30_7  free_load_conservation_1127  2
    service_1_30_8  unique_nonzero_owner_301  1
    service_1_30_8  service_visit_def_1126  1
    service_1_30_8  free_load_conservation_1127  3
    service_2_30_0  unique_nonzero_owner_294  1
    service_2_30_0  service_visit_def_1554  1
    service_2_30_0  free_load_conservation_1555  -5
    service_2_30_0  original_T_including_depot_unload_1596  600
    service_2_30_1  unique_nonzero_owner_295  1
    service_2_30_1  service_visit_def_1554  1
    service_2_30_1  free_load_conservation_1555  -4
    service_2_30_1  original_T_including_depot_unload_1596  480
    service_2_30_2  unique_nonzero_owner_296  1
    service_2_30_2  service_visit_def_1554  1
    service_2_30_2  free_load_conservation_1555  -3
    service_2_30_2  original_T_including_depot_unload_1596  360
    service_2_30_3  unique_nonzero_owner_297  1
    service_2_30_3  service_visit_def_1554  1
    service_2_30_3  free_load_conservation_1555  -2
    service_2_30_3  original_T_including_depot_unload_1596  240
    service_2_30_4  unique_nonzero_owner_298  1
    service_2_30_4  service_visit_def_1554  1
    service_2_30_4  free_load_conservation_1555  -1
    service_2_30_4  original_T_including_depot_unload_1596  120
    service_2_30_6  unique_nonzero_owner_299  1
    service_2_30_6  service_visit_def_1554  1
    service_2_30_6  free_load_conservation_1555  1
    service_2_30_7  unique_nonzero_owner_300  1
    service_2_30_7  service_visit_def_1554  1
    service_2_30_7  free_load_conservation_1555  2
    service_2_30_8  unique_nonzero_owner_301  1
    service_2_30_8  service_visit_def_1554  1
    service_2_30_8  free_load_conservation_1555  3
    service_0_31_0  unique_nonzero_owner_302  1
    service_0_31_0  service_visit_def_760  1
    service_0_31_0  free_load_conservation_761  -2
    service_0_31_0  original_T_including_depot_unload_796  240
    service_0_31_1  unique_nonzero_owner_303  1
    service_0_31_1  service_visit_def_760  1
    service_0_31_1  free_load_conservation_761  -1
    service_0_31_1  original_T_including_depot_unload_796  120
    service_0_31_3  unique_nonzero_owner_304  1
    service_0_31_3  service_visit_def_760  1
    service_0_31_3  free_load_conservation_761  1
    service_0_31_4  unique_nonzero_owner_305  1
    service_0_31_4  service_visit_def_760  1
    service_0_31_4  free_load_conservation_761  2
    service_0_31_5  unique_nonzero_owner_306  1
    service_0_31_5  service_visit_def_760  1
    service_0_31_5  free_load_conservation_761  3
    service_0_31_6  unique_nonzero_owner_307  1
    service_0_31_6  service_visit_def_760  1
    service_0_31_6  free_load_conservation_761  4
    service_0_31_7  unique_nonzero_owner_308  1
    service_0_31_7  service_visit_def_760  1
    service_0_31_7  free_load_conservation_761  5
    service_0_31_8  unique_nonzero_owner_309  1
    service_0_31_8  service_visit_def_760  1
    service_0_31_8  free_load_conservation_761  6
    service_0_31_9  unique_nonzero_owner_310  1
    service_0_31_9  service_visit_def_760  1
    service_0_31_9  free_load_conservation_761  7
    service_0_31_10  unique_nonzero_owner_311  1
    service_0_31_10  service_visit_def_760  1
    service_0_31_10  free_load_conservation_761  8
    service_0_31_11  unique_nonzero_owner_312  1
    service_0_31_11  service_visit_def_760  1
    service_0_31_11  free_load_conservation_761  9
    service_0_31_12  unique_nonzero_owner_313  1
    service_0_31_12  service_visit_def_760  1
    service_0_31_12  free_load_conservation_761  10
    service_1_31_0  unique_nonzero_owner_302  1
    service_1_31_0  service_visit_def_1132  1
    service_1_31_0  free_load_conservation_1133  -2
    service_1_31_0  original_T_including_depot_unload_1167  240
    service_1_31_1  unique_nonzero_owner_303  1
    service_1_31_1  service_visit_def_1132  1
    service_1_31_1  free_load_conservation_1133  -1
    service_1_31_1  original_T_including_depot_unload_1167  120
    service_1_31_3  unique_nonzero_owner_304  1
    service_1_31_3  service_visit_def_1132  1
    service_1_31_3  free_load_conservation_1133  1
    service_1_31_4  unique_nonzero_owner_305  1
    service_1_31_4  service_visit_def_1132  1
    service_1_31_4  free_load_conservation_1133  2
    service_1_31_5  unique_nonzero_owner_306  1
    service_1_31_5  service_visit_def_1132  1
    service_1_31_5  free_load_conservation_1133  3
    service_1_31_6  unique_nonzero_owner_307  1
    service_1_31_6  service_visit_def_1132  1
    service_1_31_6  free_load_conservation_1133  4
    service_1_31_7  unique_nonzero_owner_308  1
    service_1_31_7  service_visit_def_1132  1
    service_1_31_7  free_load_conservation_1133  5
    service_1_31_8  unique_nonzero_owner_309  1
    service_1_31_8  service_visit_def_1132  1
    service_1_31_8  free_load_conservation_1133  6
    service_1_31_9  unique_nonzero_owner_310  1
    service_1_31_9  service_visit_def_1132  1
    service_1_31_9  free_load_conservation_1133  7
    service_1_31_10  unique_nonzero_owner_311  1
    service_1_31_10  service_visit_def_1132  1
    service_1_31_10  free_load_conservation_1133  8
    service_1_31_11  unique_nonzero_owner_312  1
    service_1_31_11  service_visit_def_1132  1
    service_1_31_11  free_load_conservation_1133  9
    service_1_31_12  unique_nonzero_owner_313  1
    service_1_31_12  service_visit_def_1132  1
    service_1_31_12  free_load_conservation_1133  10
    service_2_31_0  unique_nonzero_owner_302  1
    service_2_31_0  service_visit_def_1560  1
    service_2_31_0  free_load_conservation_1561  -2
    service_2_31_0  original_T_including_depot_unload_1596  240
    service_2_31_1  unique_nonzero_owner_303  1
    service_2_31_1  service_visit_def_1560  1
    service_2_31_1  free_load_conservation_1561  -1
    service_2_31_1  original_T_including_depot_unload_1596  120
    service_2_31_3  unique_nonzero_owner_304  1
    service_2_31_3  service_visit_def_1560  1
    service_2_31_3  free_load_conservation_1561  1
    service_2_31_4  unique_nonzero_owner_305  1
    service_2_31_4  service_visit_def_1560  1
    service_2_31_4  free_load_conservation_1561  2
    service_2_31_5  unique_nonzero_owner_306  1
    service_2_31_5  service_visit_def_1560  1
    service_2_31_5  free_load_conservation_1561  3
    service_2_31_6  unique_nonzero_owner_307  1
    service_2_31_6  service_visit_def_1560  1
    service_2_31_6  free_load_conservation_1561  4
    service_2_31_7  unique_nonzero_owner_308  1
    service_2_31_7  service_visit_def_1560  1
    service_2_31_7  free_load_conservation_1561  5
    service_2_31_8  unique_nonzero_owner_309  1
    service_2_31_8  service_visit_def_1560  1
    service_2_31_8  free_load_conservation_1561  6
    service_2_31_9  unique_nonzero_owner_310  1
    service_2_31_9  service_visit_def_1560  1
    service_2_31_9  free_load_conservation_1561  7
    service_2_31_10  unique_nonzero_owner_311  1
    service_2_31_10  service_visit_def_1560  1
    service_2_31_10  free_load_conservation_1561  8
    service_2_31_11  unique_nonzero_owner_312  1
    service_2_31_11  service_visit_def_1560  1
    service_2_31_11  free_load_conservation_1561  9
    service_2_31_12  unique_nonzero_owner_313  1
    service_2_31_12  service_visit_def_1560  1
    service_2_31_12  free_load_conservation_1561  10
    service_0_32_1  unique_nonzero_owner_314  1
    service_0_32_1  service_visit_def_766  1
    service_0_32_1  free_load_conservation_767  1
    service_0_32_2  unique_nonzero_owner_315  1
    service_0_32_2  service_visit_def_766  1
    service_0_32_2  free_load_conservation_767  2
    service_0_32_3  unique_nonzero_owner_316  1
    service_0_32_3  service_visit_def_766  1
    service_0_32_3  free_load_conservation_767  3
    service_0_32_4  unique_nonzero_owner_317  1
    service_0_32_4  service_visit_def_766  1
    service_0_32_4  free_load_conservation_767  4
    service_0_32_5  unique_nonzero_owner_318  1
    service_0_32_5  service_visit_def_766  1
    service_0_32_5  free_load_conservation_767  5
    service_0_32_6  unique_nonzero_owner_319  1
    service_0_32_6  service_visit_def_766  1
    service_0_32_6  free_load_conservation_767  6
    service_0_32_7  unique_nonzero_owner_320  1
    service_0_32_7  service_visit_def_766  1
    service_0_32_7  free_load_conservation_767  7
    service_0_32_8  unique_nonzero_owner_321  1
    service_0_32_8  service_visit_def_766  1
    service_0_32_8  free_load_conservation_767  8
    service_0_32_9  unique_nonzero_owner_322  1
    service_0_32_9  service_visit_def_766  1
    service_0_32_9  free_load_conservation_767  9
    service_0_32_10  unique_nonzero_owner_323  1
    service_0_32_10  service_visit_def_766  1
    service_0_32_10  free_load_conservation_767  10
    service_0_32_11  unique_nonzero_owner_324  1
    service_0_32_11  service_visit_def_766  1
    service_0_32_11  free_load_conservation_767  11
    service_0_32_12  unique_nonzero_owner_325  1
    service_0_32_12  service_visit_def_766  1
    service_0_32_12  free_load_conservation_767  12
    service_1_32_1  unique_nonzero_owner_314  1
    service_1_32_1  service_visit_def_1138  1
    service_1_32_1  free_load_conservation_1139  1
    service_1_32_2  unique_nonzero_owner_315  1
    service_1_32_2  service_visit_def_1138  1
    service_1_32_2  free_load_conservation_1139  2
    service_1_32_3  unique_nonzero_owner_316  1
    service_1_32_3  service_visit_def_1138  1
    service_1_32_3  free_load_conservation_1139  3
    service_1_32_4  unique_nonzero_owner_317  1
    service_1_32_4  service_visit_def_1138  1
    service_1_32_4  free_load_conservation_1139  4
    service_1_32_5  unique_nonzero_owner_318  1
    service_1_32_5  service_visit_def_1138  1
    service_1_32_5  free_load_conservation_1139  5
    service_1_32_6  unique_nonzero_owner_319  1
    service_1_32_6  service_visit_def_1138  1
    service_1_32_6  free_load_conservation_1139  6
    service_1_32_7  unique_nonzero_owner_320  1
    service_1_32_7  service_visit_def_1138  1
    service_1_32_7  free_load_conservation_1139  7
    service_1_32_8  unique_nonzero_owner_321  1
    service_1_32_8  service_visit_def_1138  1
    service_1_32_8  free_load_conservation_1139  8
    service_1_32_9  unique_nonzero_owner_322  1
    service_1_32_9  service_visit_def_1138  1
    service_1_32_9  free_load_conservation_1139  9
    service_1_32_10  unique_nonzero_owner_323  1
    service_1_32_10  service_visit_def_1138  1
    service_1_32_10  free_load_conservation_1139  10
    service_1_32_11  unique_nonzero_owner_324  1
    service_1_32_11  service_visit_def_1138  1
    service_1_32_11  free_load_conservation_1139  11
    service_1_32_12  unique_nonzero_owner_325  1
    service_1_32_12  service_visit_def_1138  1
    service_1_32_12  free_load_conservation_1139  12
    service_2_32_1  unique_nonzero_owner_314  1
    service_2_32_1  service_visit_def_1566  1
    service_2_32_1  free_load_conservation_1567  1
    service_2_32_2  unique_nonzero_owner_315  1
    service_2_32_2  service_visit_def_1566  1
    service_2_32_2  free_load_conservation_1567  2
    service_2_32_3  unique_nonzero_owner_316  1
    service_2_32_3  service_visit_def_1566  1
    service_2_32_3  free_load_conservation_1567  3
    service_2_32_4  unique_nonzero_owner_317  1
    service_2_32_4  service_visit_def_1566  1
    service_2_32_4  free_load_conservation_1567  4
    service_2_32_5  unique_nonzero_owner_318  1
    service_2_32_5  service_visit_def_1566  1
    service_2_32_5  free_load_conservation_1567  5
    service_2_32_6  unique_nonzero_owner_319  1
    service_2_32_6  service_visit_def_1566  1
    service_2_32_6  free_load_conservation_1567  6
    service_2_32_7  unique_nonzero_owner_320  1
    service_2_32_7  service_visit_def_1566  1
    service_2_32_7  free_load_conservation_1567  7
    service_2_32_8  unique_nonzero_owner_321  1
    service_2_32_8  service_visit_def_1566  1
    service_2_32_8  free_load_conservation_1567  8
    service_2_32_9  unique_nonzero_owner_322  1
    service_2_32_9  service_visit_def_1566  1
    service_2_32_9  free_load_conservation_1567  9
    service_2_32_10  unique_nonzero_owner_323  1
    service_2_32_10  service_visit_def_1566  1
    service_2_32_10  free_load_conservation_1567  10
    service_2_32_11  unique_nonzero_owner_324  1
    service_2_32_11  service_visit_def_1566  1
    service_2_32_11  free_load_conservation_1567  11
    service_2_32_12  unique_nonzero_owner_325  1
    service_2_32_12  service_visit_def_1566  1
    service_2_32_12  free_load_conservation_1567  12
    service_0_19_1  unique_nonzero_owner_326  1
    service_0_19_1  service_visit_def_772  1
    service_0_19_1  free_load_conservation_773  1
    service_0_19_2  unique_nonzero_owner_327  1
    service_0_19_2  service_visit_def_772  1
    service_0_19_2  free_load_conservation_773  2
    service_0_19_3  unique_nonzero_owner_328  1
    service_0_19_3  service_visit_def_772  1
    service_0_19_3  free_load_conservation_773  3
    service_0_19_4  unique_nonzero_owner_329  1
    service_0_19_4  service_visit_def_772  1
    service_0_19_4  free_load_conservation_773  4
    service_0_19_5  unique_nonzero_owner_330  1
    service_0_19_5  service_visit_def_772  1
    service_0_19_5  free_load_conservation_773  5
    service_0_19_6  unique_nonzero_owner_331  1
    service_0_19_6  service_visit_def_772  1
    service_0_19_6  free_load_conservation_773  6
    service_0_19_7  unique_nonzero_owner_332  1
    service_0_19_7  service_visit_def_772  1
    service_0_19_7  free_load_conservation_773  7
    service_0_19_8  unique_nonzero_owner_333  1
    service_0_19_8  service_visit_def_772  1
    service_0_19_8  free_load_conservation_773  8
    service_1_19_1  unique_nonzero_owner_326  1
    service_1_19_1  service_visit_def_1144  1
    service_1_19_1  free_load_conservation_1145  1
    service_1_19_2  unique_nonzero_owner_327  1
    service_1_19_2  service_visit_def_1144  1
    service_1_19_2  free_load_conservation_1145  2
    service_1_19_3  unique_nonzero_owner_328  1
    service_1_19_3  service_visit_def_1144  1
    service_1_19_3  free_load_conservation_1145  3
    service_1_19_4  unique_nonzero_owner_329  1
    service_1_19_4  service_visit_def_1144  1
    service_1_19_4  free_load_conservation_1145  4
    service_1_19_5  unique_nonzero_owner_330  1
    service_1_19_5  service_visit_def_1144  1
    service_1_19_5  free_load_conservation_1145  5
    service_1_19_6  unique_nonzero_owner_331  1
    service_1_19_6  service_visit_def_1144  1
    service_1_19_6  free_load_conservation_1145  6
    service_1_19_7  unique_nonzero_owner_332  1
    service_1_19_7  service_visit_def_1144  1
    service_1_19_7  free_load_conservation_1145  7
    service_1_19_8  unique_nonzero_owner_333  1
    service_1_19_8  service_visit_def_1144  1
    service_1_19_8  free_load_conservation_1145  8
    service_2_19_1  unique_nonzero_owner_326  1
    service_2_19_1  service_visit_def_1572  1
    service_2_19_1  free_load_conservation_1573  1
    service_2_19_2  unique_nonzero_owner_327  1
    service_2_19_2  service_visit_def_1572  1
    service_2_19_2  free_load_conservation_1573  2
    service_2_19_3  unique_nonzero_owner_328  1
    service_2_19_3  service_visit_def_1572  1
    service_2_19_3  free_load_conservation_1573  3
    service_2_19_4  unique_nonzero_owner_329  1
    service_2_19_4  service_visit_def_1572  1
    service_2_19_4  free_load_conservation_1573  4
    service_2_19_5  unique_nonzero_owner_330  1
    service_2_19_5  service_visit_def_1572  1
    service_2_19_5  free_load_conservation_1573  5
    service_2_19_6  unique_nonzero_owner_331  1
    service_2_19_6  service_visit_def_1572  1
    service_2_19_6  free_load_conservation_1573  6
    service_2_19_7  unique_nonzero_owner_332  1
    service_2_19_7  service_visit_def_1572  1
    service_2_19_7  free_load_conservation_1573  7
    service_2_19_8  unique_nonzero_owner_333  1
    service_2_19_8  service_visit_def_1572  1
    service_2_19_8  free_load_conservation_1573  8
    service_0_26_1  unique_nonzero_owner_334  1
    service_0_26_1  service_visit_def_778  1
    service_0_26_1  free_load_conservation_779  1
    service_0_26_2  unique_nonzero_owner_335  1
    service_0_26_2  service_visit_def_778  1
    service_0_26_2  free_load_conservation_779  2
    service_0_26_3  unique_nonzero_owner_336  1
    service_0_26_3  service_visit_def_778  1
    service_0_26_3  free_load_conservation_779  3
    service_0_26_4  unique_nonzero_owner_337  1
    service_0_26_4  service_visit_def_778  1
    service_0_26_4  free_load_conservation_779  4
    service_0_26_5  unique_nonzero_owner_338  1
    service_0_26_5  service_visit_def_778  1
    service_0_26_5  free_load_conservation_779  5
    service_0_26_6  unique_nonzero_owner_339  1
    service_0_26_6  service_visit_def_778  1
    service_0_26_6  free_load_conservation_779  6
    service_0_26_7  unique_nonzero_owner_340  1
    service_0_26_7  service_visit_def_778  1
    service_0_26_7  free_load_conservation_779  7
    service_0_26_8  unique_nonzero_owner_341  1
    service_0_26_8  service_visit_def_778  1
    service_0_26_8  free_load_conservation_779  8
    service_1_26_1  unique_nonzero_owner_334  1
    service_1_26_1  service_visit_def_1150  1
    service_1_26_1  free_load_conservation_1151  1
    service_1_26_2  unique_nonzero_owner_335  1
    service_1_26_2  service_visit_def_1150  1
    service_1_26_2  free_load_conservation_1151  2
    service_1_26_3  unique_nonzero_owner_336  1
    service_1_26_3  service_visit_def_1150  1
    service_1_26_3  free_load_conservation_1151  3
    service_1_26_4  unique_nonzero_owner_337  1
    service_1_26_4  service_visit_def_1150  1
    service_1_26_4  free_load_conservation_1151  4
    service_1_26_5  unique_nonzero_owner_338  1
    service_1_26_5  service_visit_def_1150  1
    service_1_26_5  free_load_conservation_1151  5
    service_1_26_6  unique_nonzero_owner_339  1
    service_1_26_6  service_visit_def_1150  1
    service_1_26_6  free_load_conservation_1151  6
    service_1_26_7  unique_nonzero_owner_340  1
    service_1_26_7  service_visit_def_1150  1
    service_1_26_7  free_load_conservation_1151  7
    service_1_26_8  unique_nonzero_owner_341  1
    service_1_26_8  service_visit_def_1150  1
    service_1_26_8  free_load_conservation_1151  8
    service_2_26_1  unique_nonzero_owner_334  1
    service_2_26_1  service_visit_def_1578  1
    service_2_26_1  free_load_conservation_1579  1
    service_2_26_2  unique_nonzero_owner_335  1
    service_2_26_2  service_visit_def_1578  1
    service_2_26_2  free_load_conservation_1579  2
    service_2_26_3  unique_nonzero_owner_336  1
    service_2_26_3  service_visit_def_1578  1
    service_2_26_3  free_load_conservation_1579  3
    service_2_26_4  unique_nonzero_owner_337  1
    service_2_26_4  service_visit_def_1578  1
    service_2_26_4  free_load_conservation_1579  4
    service_2_26_5  unique_nonzero_owner_338  1
    service_2_26_5  service_visit_def_1578  1
    service_2_26_5  free_load_conservation_1579  5
    service_2_26_6  unique_nonzero_owner_339  1
    service_2_26_6  service_visit_def_1578  1
    service_2_26_6  free_load_conservation_1579  6
    service_2_26_7  unique_nonzero_owner_340  1
    service_2_26_7  service_visit_def_1578  1
    service_2_26_7  free_load_conservation_1579  7
    service_2_26_8  unique_nonzero_owner_341  1
    service_2_26_8  service_visit_def_1578  1
    service_2_26_8  free_load_conservation_1579  8
    service_0_6_0  unique_nonzero_owner_342  1
    service_0_6_0  service_visit_def_784  1
    service_0_6_0  free_load_conservation_785  -1
    service_0_6_0  original_T_including_depot_unload_796  120
    service_0_6_2  unique_nonzero_owner_343  1
    service_0_6_2  service_visit_def_784  1
    service_0_6_2  free_load_conservation_785  1
    service_0_6_3  unique_nonzero_owner_344  1
    service_0_6_3  service_visit_def_784  1
    service_0_6_3  free_load_conservation_785  2
    service_0_6_4  unique_nonzero_owner_345  1
    service_0_6_4  service_visit_def_784  1
    service_0_6_4  free_load_conservation_785  3
    service_0_6_5  unique_nonzero_owner_346  1
    service_0_6_5  service_visit_def_784  1
    service_0_6_5  free_load_conservation_785  4
    service_0_6_6  unique_nonzero_owner_347  1
    service_0_6_6  service_visit_def_784  1
    service_0_6_6  free_load_conservation_785  5
    service_0_6_7  unique_nonzero_owner_348  1
    service_0_6_7  service_visit_def_784  1
    service_0_6_7  free_load_conservation_785  6
    service_0_6_8  unique_nonzero_owner_349  1
    service_0_6_8  service_visit_def_784  1
    service_0_6_8  free_load_conservation_785  7
    service_0_6_9  unique_nonzero_owner_350  1
    service_0_6_9  service_visit_def_784  1
    service_0_6_9  free_load_conservation_785  8
    service_0_6_10  unique_nonzero_owner_351  1
    service_0_6_10  service_visit_def_784  1
    service_0_6_10  free_load_conservation_785  9
    service_1_6_0  unique_nonzero_owner_342  1
    service_1_6_0  service_visit_def_1156  1
    service_1_6_0  free_load_conservation_1157  -1
    service_1_6_0  original_T_including_depot_unload_1167  120
    service_1_6_2  unique_nonzero_owner_343  1
    service_1_6_2  service_visit_def_1156  1
    service_1_6_2  free_load_conservation_1157  1
    service_1_6_3  unique_nonzero_owner_344  1
    service_1_6_3  service_visit_def_1156  1
    service_1_6_3  free_load_conservation_1157  2
    service_1_6_4  unique_nonzero_owner_345  1
    service_1_6_4  service_visit_def_1156  1
    service_1_6_4  free_load_conservation_1157  3
    service_1_6_5  unique_nonzero_owner_346  1
    service_1_6_5  service_visit_def_1156  1
    service_1_6_5  free_load_conservation_1157  4
    service_1_6_6  unique_nonzero_owner_347  1
    service_1_6_6  service_visit_def_1156  1
    service_1_6_6  free_load_conservation_1157  5
    service_1_6_7  unique_nonzero_owner_348  1
    service_1_6_7  service_visit_def_1156  1
    service_1_6_7  free_load_conservation_1157  6
    service_1_6_8  unique_nonzero_owner_349  1
    service_1_6_8  service_visit_def_1156  1
    service_1_6_8  free_load_conservation_1157  7
    service_1_6_9  unique_nonzero_owner_350  1
    service_1_6_9  service_visit_def_1156  1
    service_1_6_9  free_load_conservation_1157  8
    service_1_6_10  unique_nonzero_owner_351  1
    service_1_6_10  service_visit_def_1156  1
    service_1_6_10  free_load_conservation_1157  9
    service_2_6_0  unique_nonzero_owner_342  1
    service_2_6_0  service_visit_def_1584  1
    service_2_6_0  free_load_conservation_1585  -1
    service_2_6_0  original_T_including_depot_unload_1596  120
    service_2_6_2  unique_nonzero_owner_343  1
    service_2_6_2  service_visit_def_1584  1
    service_2_6_2  free_load_conservation_1585  1
    service_2_6_3  unique_nonzero_owner_344  1
    service_2_6_3  service_visit_def_1584  1
    service_2_6_3  free_load_conservation_1585  2
    service_2_6_4  unique_nonzero_owner_345  1
    service_2_6_4  service_visit_def_1584  1
    service_2_6_4  free_load_conservation_1585  3
    service_2_6_5  unique_nonzero_owner_346  1
    service_2_6_5  service_visit_def_1584  1
    service_2_6_5  free_load_conservation_1585  4
    service_2_6_6  unique_nonzero_owner_347  1
    service_2_6_6  service_visit_def_1584  1
    service_2_6_6  free_load_conservation_1585  5
    service_2_6_7  unique_nonzero_owner_348  1
    service_2_6_7  service_visit_def_1584  1
    service_2_6_7  free_load_conservation_1585  6
    service_2_6_8  unique_nonzero_owner_349  1
    service_2_6_8  service_visit_def_1584  1
    service_2_6_8  free_load_conservation_1585  7
    service_2_6_9  unique_nonzero_owner_350  1
    service_2_6_9  service_visit_def_1584  1
    service_2_6_9  free_load_conservation_1585  8
    service_2_6_10  unique_nonzero_owner_351  1
    service_2_6_10  service_visit_def_1584  1
    service_2_6_10  free_load_conservation_1585  9
    service_0_17_0  unique_nonzero_owner_352  1
    service_0_17_0  service_visit_def_790  1
    service_0_17_0  free_load_conservation_791  -3
    service_0_17_0  original_T_including_depot_unload_796  360
    service_0_17_1  unique_nonzero_owner_353  1
    service_0_17_1  service_visit_def_790  1
    service_0_17_1  free_load_conservation_791  -2
    service_0_17_1  original_T_including_depot_unload_796  240
    service_0_17_2  unique_nonzero_owner_354  1
    service_0_17_2  service_visit_def_790  1
    service_0_17_2  free_load_conservation_791  -1
    service_0_17_2  original_T_including_depot_unload_796  120
    service_0_17_4  unique_nonzero_owner_355  1
    service_0_17_4  service_visit_def_790  1
    service_0_17_4  free_load_conservation_791  1
    service_0_17_5  unique_nonzero_owner_356  1
    service_0_17_5  service_visit_def_790  1
    service_0_17_5  free_load_conservation_791  2
    service_0_17_6  unique_nonzero_owner_357  1
    service_0_17_6  service_visit_def_790  1
    service_0_17_6  free_load_conservation_791  3
    service_0_17_7  unique_nonzero_owner_358  1
    service_0_17_7  service_visit_def_790  1
    service_0_17_7  free_load_conservation_791  4
    service_0_17_8  unique_nonzero_owner_359  1
    service_0_17_8  service_visit_def_790  1
    service_0_17_8  free_load_conservation_791  5
    service_0_17_9  unique_nonzero_owner_360  1
    service_0_17_9  service_visit_def_790  1
    service_0_17_9  free_load_conservation_791  6
    service_0_17_10  unique_nonzero_owner_361  1
    service_0_17_10  service_visit_def_790  1
    service_0_17_10  free_load_conservation_791  7
    service_0_17_11  unique_nonzero_owner_362  1
    service_0_17_11  service_visit_def_790  1
    service_0_17_11  free_load_conservation_791  8
    service_0_17_12  unique_nonzero_owner_363  1
    service_0_17_12  service_visit_def_790  1
    service_0_17_12  free_load_conservation_791  9
    service_0_17_13  unique_nonzero_owner_364  1
    service_0_17_13  service_visit_def_790  1
    service_0_17_13  free_load_conservation_791  10
    service_0_17_14  unique_nonzero_owner_365  1
    service_0_17_14  service_visit_def_790  1
    service_0_17_14  free_load_conservation_791  11
    service_0_17_15  unique_nonzero_owner_366  1
    service_0_17_15  service_visit_def_790  1
    service_0_17_15  free_load_conservation_791  12
    service_0_17_16  unique_nonzero_owner_367  1
    service_0_17_16  service_visit_def_790  1
    service_0_17_16  free_load_conservation_791  13
    service_1_17_0  unique_nonzero_owner_352  1
    service_1_17_0  service_visit_def_1162  1
    service_1_17_0  free_load_conservation_1163  -3
    service_1_17_0  original_T_including_depot_unload_1167  360
    service_1_17_1  unique_nonzero_owner_353  1
    service_1_17_1  service_visit_def_1162  1
    service_1_17_1  free_load_conservation_1163  -2
    service_1_17_1  original_T_including_depot_unload_1167  240
    service_1_17_2  unique_nonzero_owner_354  1
    service_1_17_2  service_visit_def_1162  1
    service_1_17_2  free_load_conservation_1163  -1
    service_1_17_2  original_T_including_depot_unload_1167  120
    service_1_17_4  unique_nonzero_owner_355  1
    service_1_17_4  service_visit_def_1162  1
    service_1_17_4  free_load_conservation_1163  1
    service_1_17_5  unique_nonzero_owner_356  1
    service_1_17_5  service_visit_def_1162  1
    service_1_17_5  free_load_conservation_1163  2
    service_1_17_6  unique_nonzero_owner_357  1
    service_1_17_6  service_visit_def_1162  1
    service_1_17_6  free_load_conservation_1163  3
    service_1_17_7  unique_nonzero_owner_358  1
    service_1_17_7  service_visit_def_1162  1
    service_1_17_7  free_load_conservation_1163  4
    service_1_17_8  unique_nonzero_owner_359  1
    service_1_17_8  service_visit_def_1162  1
    service_1_17_8  free_load_conservation_1163  5
    service_1_17_9  unique_nonzero_owner_360  1
    service_1_17_9  service_visit_def_1162  1
    service_1_17_9  free_load_conservation_1163  6
    service_1_17_10  unique_nonzero_owner_361  1
    service_1_17_10  service_visit_def_1162  1
    service_1_17_10  free_load_conservation_1163  7
    service_1_17_11  unique_nonzero_owner_362  1
    service_1_17_11  service_visit_def_1162  1
    service_1_17_11  free_load_conservation_1163  8
    service_1_17_12  unique_nonzero_owner_363  1
    service_1_17_12  service_visit_def_1162  1
    service_1_17_12  free_load_conservation_1163  9
    service_1_17_13  unique_nonzero_owner_364  1
    service_1_17_13  service_visit_def_1162  1
    service_1_17_13  free_load_conservation_1163  10
    service_1_17_14  unique_nonzero_owner_365  1
    service_1_17_14  service_visit_def_1162  1
    service_1_17_14  free_load_conservation_1163  11
    service_1_17_15  unique_nonzero_owner_366  1
    service_1_17_15  service_visit_def_1162  1
    service_1_17_15  free_load_conservation_1163  12
    service_1_17_16  unique_nonzero_owner_367  1
    service_1_17_16  service_visit_def_1162  1
    service_1_17_16  free_load_conservation_1163  13
    service_2_17_0  unique_nonzero_owner_352  1
    service_2_17_0  service_visit_def_1590  1
    service_2_17_0  free_load_conservation_1591  -3
    service_2_17_0  original_T_including_depot_unload_1596  360
    service_2_17_1  unique_nonzero_owner_353  1
    service_2_17_1  service_visit_def_1590  1
    service_2_17_1  free_load_conservation_1591  -2
    service_2_17_1  original_T_including_depot_unload_1596  240
    service_2_17_2  unique_nonzero_owner_354  1
    service_2_17_2  service_visit_def_1590  1
    service_2_17_2  free_load_conservation_1591  -1
    service_2_17_2  original_T_including_depot_unload_1596  120
    service_2_17_4  unique_nonzero_owner_355  1
    service_2_17_4  service_visit_def_1590  1
    service_2_17_4  free_load_conservation_1591  1
    service_2_17_5  unique_nonzero_owner_356  1
    service_2_17_5  service_visit_def_1590  1
    service_2_17_5  free_load_conservation_1591  2
    service_2_17_6  unique_nonzero_owner_357  1
    service_2_17_6  service_visit_def_1590  1
    service_2_17_6  free_load_conservation_1591  3
    service_2_17_7  unique_nonzero_owner_358  1
    service_2_17_7  service_visit_def_1590  1
    service_2_17_7  free_load_conservation_1591  4
    service_2_17_8  unique_nonzero_owner_359  1
    service_2_17_8  service_visit_def_1590  1
    service_2_17_8  free_load_conservation_1591  5
    service_2_17_9  unique_nonzero_owner_360  1
    service_2_17_9  service_visit_def_1590  1
    service_2_17_9  free_load_conservation_1591  6
    service_2_17_10  unique_nonzero_owner_361  1
    service_2_17_10  service_visit_def_1590  1
    service_2_17_10  free_load_conservation_1591  7
    service_2_17_11  unique_nonzero_owner_362  1
    service_2_17_11  service_visit_def_1590  1
    service_2_17_11  free_load_conservation_1591  8
    service_2_17_12  unique_nonzero_owner_363  1
    service_2_17_12  service_visit_def_1590  1
    service_2_17_12  free_load_conservation_1591  9
    service_2_17_13  unique_nonzero_owner_364  1
    service_2_17_13  service_visit_def_1590  1
    service_2_17_13  free_load_conservation_1591  10
    service_2_17_14  unique_nonzero_owner_365  1
    service_2_17_14  service_visit_def_1590  1
    service_2_17_14  free_load_conservation_1591  11
    service_2_17_15  unique_nonzero_owner_366  1
    service_2_17_15  service_visit_def_1590  1
    service_2_17_15  free_load_conservation_1591  12
    service_2_17_16  unique_nonzero_owner_367  1
    service_2_17_16  service_visit_def_1590  1
    service_2_17_16  free_load_conservation_1591  13
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_709  -1
    visit_0_1  in_degree_710  -1
    visit_0_1  order_active_lb_711  -1
    visit_0_1  order_active_ub_712  -13
    order_0_1  connected_order_arc_384  -1
    order_0_1  connected_order_arc_386  -1
    order_0_1  connected_order_arc_388  -1
    order_0_1  connected_order_arc_390  -1
    order_0_1  connected_order_arc_392  -1
    order_0_1  connected_order_arc_394  -1
    order_0_1  connected_order_arc_396  -1
    order_0_1  connected_order_arc_398  -1
    order_0_1  connected_order_arc_400  -1
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_409  1
    order_0_1  connected_order_arc_434  1
    order_0_1  connected_order_arc_459  1
    order_0_1  connected_order_arc_484  1
    order_0_1  connected_order_arc_509  1
    order_0_1  connected_order_arc_534  1
    order_0_1  connected_order_arc_559  1
    order_0_1  connected_order_arc_584  1
    order_0_1  connected_order_arc_609  1
    order_0_1  connected_order_arc_634  1
    order_0_1  connected_order_arc_659  1
    order_0_1  connected_order_arc_684  1
    order_0_1  order_active_lb_711  1
    order_0_1  order_active_ub_712  1
    order_0_1  fixed_segment_relative_order_792  -1
    visit_0_2  out_degree_716  -1
    visit_0_2  in_degree_717  -1
    visit_0_2  order_active_lb_718  -1
    visit_0_2  order_active_ub_719  -13
    order_0_2  connected_order_arc_384  1
    order_0_2  connected_order_arc_409  -1
    order_0_2  connected_order_arc_411  -1
    order_0_2  connected_order_arc_413  -1
    order_0_2  connected_order_arc_415  -1
    order_0_2  connected_order_arc_417  -1
    order_0_2  connected_order_arc_419  -1
    order_0_2  connected_order_arc_421  -1
    order_0_2  connected_order_arc_423  -1
    order_0_2  connected_order_arc_425  -1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_436  1
    order_0_2  connected_order_arc_461  1
    order_0_2  connected_order_arc_486  1
    order_0_2  connected_order_arc_511  1
    order_0_2  connected_order_arc_536  1
    order_0_2  connected_order_arc_561  1
    order_0_2  connected_order_arc_586  1
    order_0_2  connected_order_arc_611  1
    order_0_2  connected_order_arc_636  1
    order_0_2  connected_order_arc_661  1
    order_0_2  connected_order_arc_686  1
    order_0_2  order_active_lb_718  1
    order_0_2  order_active_ub_719  1
    order_0_2  fixed_segment_relative_order_792  1
    order_0_2  fixed_segment_relative_order_793  -1
    visit_0_3  out_degree_723  -1
    visit_0_3  in_degree_724  -1
    visit_0_3  order_active_lb_725  -1
    visit_0_3  order_active_ub_726  -13
    order_0_3  connected_order_arc_386  1
    order_0_3  connected_order_arc_411  1
    order_0_3  connected_order_arc_434  -1
    order_0_3  connected_order_arc_436  -1
    order_0_3  connected_order_arc_438  -1
    order_0_3  connected_order_arc_440  -1
    order_0_3  connected_order_arc_442  -1
    order_0_3  connected_order_arc_444  -1
    order_0_3  connected_order_arc_446  -1
    order_0_3  connected_order_arc_448  -1
    order_0_3  connected_order_arc_450  -1
    order_0_3  connected_order_arc_452  -1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_463  1
    order_0_3  connected_order_arc_488  1
    order_0_3  connected_order_arc_513  1
    order_0_3  connected_order_arc_538  1
    order_0_3  connected_order_arc_563  1
    order_0_3  connected_order_arc_588  1
    order_0_3  connected_order_arc_613  1
    order_0_3  connected_order_arc_638  1
    order_0_3  connected_order_arc_663  1
    order_0_3  connected_order_arc_688  1
    order_0_3  order_active_lb_725  1
    order_0_3  order_active_ub_726  1
    order_0_3  fixed_segment_relative_order_793  1
    order_0_3  fixed_segment_relative_order_794  -1
    visit_0_4  out_degree_730  -1
    visit_0_4  in_degree_731  -1
    visit_0_4  order_active_lb_732  -1
    visit_0_4  order_active_ub_733  -13
    order_0_4  connected_order_arc_388  1
    order_0_4  connected_order_arc_413  1
    order_0_4  connected_order_arc_438  1
    order_0_4  connected_order_arc_459  -1
    order_0_4  connected_order_arc_461  -1
    order_0_4  connected_order_arc_463  -1
    order_0_4  connected_order_arc_465  -1
    order_0_4  connected_order_arc_467  -1
    order_0_4  connected_order_arc_469  -1
    order_0_4  connected_order_arc_471  -1
    order_0_4  connected_order_arc_473  -1
    order_0_4  connected_order_arc_475  -1
    order_0_4  connected_order_arc_477  -1
    order_0_4  connected_order_arc_479  -1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_490  1
    order_0_4  connected_order_arc_515  1
    order_0_4  connected_order_arc_540  1
    order_0_4  connected_order_arc_565  1
    order_0_4  connected_order_arc_590  1
    order_0_4  connected_order_arc_615  1
    order_0_4  connected_order_arc_640  1
    order_0_4  connected_order_arc_665  1
    order_0_4  connected_order_arc_690  1
    order_0_4  order_active_lb_732  1
    order_0_4  order_active_ub_733  1
    order_0_4  fixed_segment_relative_order_794  1
    order_0_4  fixed_segment_relative_order_795  -1
    visit_0_5  out_degree_737  -1
    visit_0_5  in_degree_738  -1
    visit_0_5  order_active_lb_739  -1
    visit_0_5  order_active_ub_740  -13
    order_0_5  connected_order_arc_390  1
    order_0_5  connected_order_arc_415  1
    order_0_5  connected_order_arc_440  1
    order_0_5  connected_order_arc_465  1
    order_0_5  connected_order_arc_484  -1
    order_0_5  connected_order_arc_486  -1
    order_0_5  connected_order_arc_488  -1
    order_0_5  connected_order_arc_490  -1
    order_0_5  connected_order_arc_492  -1
    order_0_5  connected_order_arc_494  -1
    order_0_5  connected_order_arc_496  -1
    order_0_5  connected_order_arc_498  -1
    order_0_5  connected_order_arc_500  -1
    order_0_5  connected_order_arc_502  -1
    order_0_5  connected_order_arc_504  -1
    order_0_5  connected_order_arc_506  -1
    order_0_5  connected_order_arc_517  1
    order_0_5  connected_order_arc_542  1
    order_0_5  connected_order_arc_567  1
    order_0_5  connected_order_arc_592  1
    order_0_5  connected_order_arc_617  1
    order_0_5  connected_order_arc_642  1
    order_0_5  connected_order_arc_667  1
    order_0_5  connected_order_arc_692  1
    order_0_5  order_active_lb_739  1
    order_0_5  order_active_ub_740  1
    order_0_5  fixed_segment_relative_order_795  1
    visit_0_15  out_degree_744  -1
    visit_0_15  in_degree_745  -1
    visit_0_15  order_active_lb_746  -1
    visit_0_15  order_active_ub_747  -13
    visit_0_15  service_visit_def_748  -1
    order_0_15  connected_order_arc_392  1
    order_0_15  connected_order_arc_417  1
    order_0_15  connected_order_arc_442  1
    order_0_15  connected_order_arc_467  1
    order_0_15  connected_order_arc_492  1
    order_0_15  connected_order_arc_509  -1
    order_0_15  connected_order_arc_511  -1
    order_0_15  connected_order_arc_513  -1
    order_0_15  connected_order_arc_515  -1
    order_0_15  connected_order_arc_517  -1
    order_0_15  connected_order_arc_519  -1
    order_0_15  connected_order_arc_521  -1
    order_0_15  connected_order_arc_523  -1
    order_0_15  connected_order_arc_525  -1
    order_0_15  connected_order_arc_527  -1
    order_0_15  connected_order_arc_529  -1
    order_0_15  connected_order_arc_531  -1
    order_0_15  connected_order_arc_544  1
    order_0_15  connected_order_arc_569  1
    order_0_15  connected_order_arc_594  1
    order_0_15  connected_order_arc_619  1
    order_0_15  connected_order_arc_644  1
    order_0_15  connected_order_arc_669  1
    order_0_15  connected_order_arc_694  1
    order_0_15  order_active_lb_746  1
    order_0_15  order_active_ub_747  1
    visit_0_16  out_degree_750  -1
    visit_0_16  in_degree_751  -1
    visit_0_16  order_active_lb_752  -1
    visit_0_16  order_active_ub_753  -13
    visit_0_16  service_visit_def_754  -1
    order_0_16  connected_order_arc_394  1
    order_0_16  connected_order_arc_419  1
    order_0_16  connected_order_arc_444  1
    order_0_16  connected_order_arc_469  1
    order_0_16  connected_order_arc_494  1
    order_0_16  connected_order_arc_519  1
    order_0_16  connected_order_arc_534  -1
    order_0_16  connected_order_arc_536  -1
    order_0_16  connected_order_arc_538  -1
    order_0_16  connected_order_arc_540  -1
    order_0_16  connected_order_arc_542  -1
    order_0_16  connected_order_arc_544  -1
    order_0_16  connected_order_arc_546  -1
    order_0_16  connected_order_arc_548  -1
    order_0_16  connected_order_arc_550  -1
    order_0_16  connected_order_arc_552  -1
    order_0_16  connected_order_arc_554  -1
    order_0_16  connected_order_arc_556  -1
    order_0_16  connected_order_arc_571  1
    order_0_16  connected_order_arc_596  1
    order_0_16  connected_order_arc_621  1
    order_0_16  connected_order_arc_646  1
    order_0_16  connected_order_arc_671  1
    order_0_16  connected_order_arc_696  1
    order_0_16  order_active_lb_752  1
    order_0_16  order_active_ub_753  1
    visit_0_17  out_degree_756  -1
    visit_0_17  in_degree_757  -1
    visit_0_17  order_active_lb_758  -1
    visit_0_17  order_active_ub_759  -13
    visit_0_17  service_visit_def_760  -1
    order_0_17  connected_order_arc_396  1
    order_0_17  connected_order_arc_421  1
    order_0_17  connected_order_arc_446  1
    order_0_17  connected_order_arc_471  1
    order_0_17  connected_order_arc_496  1
    order_0_17  connected_order_arc_521  1
    order_0_17  connected_order_arc_546  1
    order_0_17  connected_order_arc_559  -1
    order_0_17  connected_order_arc_561  -1
    order_0_17  connected_order_arc_563  -1
    order_0_17  connected_order_arc_565  -1
    order_0_17  connected_order_arc_567  -1
    order_0_17  connected_order_arc_569  -1
    order_0_17  connected_order_arc_571  -1
    order_0_17  connected_order_arc_573  -1
    order_0_17  connected_order_arc_575  -1
    order_0_17  connected_order_arc_577  -1
    order_0_17  connected_order_arc_579  -1
    order_0_17  connected_order_arc_581  -1
    order_0_17  connected_order_arc_598  1
    order_0_17  connected_order_arc_623  1
    order_0_17  connected_order_arc_648  1
    order_0_17  connected_order_arc_673  1
    order_0_17  connected_order_arc_698  1
    order_0_17  order_active_lb_758  1
    order_0_17  order_active_ub_759  1
    visit_0_18  out_degree_762  -1
    visit_0_18  in_degree_763  -1
    visit_0_18  order_active_lb_764  -1
    visit_0_18  order_active_ub_765  -13
    visit_0_18  service_visit_def_766  -1
    order_0_18  connected_order_arc_398  1
    order_0_18  connected_order_arc_423  1
    order_0_18  connected_order_arc_448  1
    order_0_18  connected_order_arc_473  1
    order_0_18  connected_order_arc_498  1
    order_0_18  connected_order_arc_523  1
    order_0_18  connected_order_arc_548  1
    order_0_18  connected_order_arc_573  1
    order_0_18  connected_order_arc_584  -1
    order_0_18  connected_order_arc_586  -1
    order_0_18  connected_order_arc_588  -1
    order_0_18  connected_order_arc_590  -1
    order_0_18  connected_order_arc_592  -1
    order_0_18  connected_order_arc_594  -1
    order_0_18  connected_order_arc_596  -1
    order_0_18  connected_order_arc_598  -1
    order_0_18  connected_order_arc_600  -1
    order_0_18  connected_order_arc_602  -1
    order_0_18  connected_order_arc_604  -1
    order_0_18  connected_order_arc_606  -1
    order_0_18  connected_order_arc_625  1
    order_0_18  connected_order_arc_650  1
    order_0_18  connected_order_arc_675  1
    order_0_18  connected_order_arc_700  1
    order_0_18  order_active_lb_764  1
    order_0_18  order_active_ub_765  1
    visit_0_19  out_degree_768  -1
    visit_0_19  in_degree_769  -1
    visit_0_19  order_active_lb_770  -1
    visit_0_19  order_active_ub_771  -13
    visit_0_19  service_visit_def_772  -1
    order_0_19  connected_order_arc_400  1
    order_0_19  connected_order_arc_425  1
    order_0_19  connected_order_arc_450  1
    order_0_19  connected_order_arc_475  1
    order_0_19  connected_order_arc_500  1
    order_0_19  connected_order_arc_525  1
    order_0_19  connected_order_arc_550  1
    order_0_19  connected_order_arc_575  1
    order_0_19  connected_order_arc_600  1
    order_0_19  connected_order_arc_609  -1
    order_0_19  connected_order_arc_611  -1
    order_0_19  connected_order_arc_613  -1
    order_0_19  connected_order_arc_615  -1
    order_0_19  connected_order_arc_617  -1
    order_0_19  connected_order_arc_619  -1
    order_0_19  connected_order_arc_621  -1
    order_0_19  connected_order_arc_623  -1
    order_0_19  connected_order_arc_625  -1
    order_0_19  connected_order_arc_627  -1
    order_0_19  connected_order_arc_629  -1
    order_0_19  connected_order_arc_631  -1
    order_0_19  connected_order_arc_652  1
    order_0_19  connected_order_arc_677  1
    order_0_19  connected_order_arc_702  1
    order_0_19  order_active_lb_770  1
    order_0_19  order_active_ub_771  1
    visit_0_20  out_degree_774  -1
    visit_0_20  in_degree_775  -1
    visit_0_20  order_active_lb_776  -1
    visit_0_20  order_active_ub_777  -13
    visit_0_20  service_visit_def_778  -1
    order_0_20  connected_order_arc_402  1
    order_0_20  connected_order_arc_427  1
    order_0_20  connected_order_arc_452  1
    order_0_20  connected_order_arc_477  1
    order_0_20  connected_order_arc_502  1
    order_0_20  connected_order_arc_527  1
    order_0_20  connected_order_arc_552  1
    order_0_20  connected_order_arc_577  1
    order_0_20  connected_order_arc_602  1
    order_0_20  connected_order_arc_627  1
    order_0_20  connected_order_arc_634  -1
    order_0_20  connected_order_arc_636  -1
    order_0_20  connected_order_arc_638  -1
    order_0_20  connected_order_arc_640  -1
    order_0_20  connected_order_arc_642  -1
    order_0_20  connected_order_arc_644  -1
    order_0_20  connected_order_arc_646  -1
    order_0_20  connected_order_arc_648  -1
    order_0_20  connected_order_arc_650  -1
    order_0_20  connected_order_arc_652  -1
    order_0_20  connected_order_arc_654  -1
    order_0_20  connected_order_arc_656  -1
    order_0_20  connected_order_arc_679  1
    order_0_20  connected_order_arc_704  1
    order_0_20  order_active_lb_776  1
    order_0_20  order_active_ub_777  1
    visit_0_21  out_degree_780  -1
    visit_0_21  in_degree_781  -1
    visit_0_21  order_active_lb_782  -1
    visit_0_21  order_active_ub_783  -13
    visit_0_21  service_visit_def_784  -1
    order_0_21  connected_order_arc_404  1
    order_0_21  connected_order_arc_429  1
    order_0_21  connected_order_arc_454  1
    order_0_21  connected_order_arc_479  1
    order_0_21  connected_order_arc_504  1
    order_0_21  connected_order_arc_529  1
    order_0_21  connected_order_arc_554  1
    order_0_21  connected_order_arc_579  1
    order_0_21  connected_order_arc_604  1
    order_0_21  connected_order_arc_629  1
    order_0_21  connected_order_arc_654  1
    order_0_21  connected_order_arc_659  -1
    order_0_21  connected_order_arc_661  -1
    order_0_21  connected_order_arc_663  -1
    order_0_21  connected_order_arc_665  -1
    order_0_21  connected_order_arc_667  -1
    order_0_21  connected_order_arc_669  -1
    order_0_21  connected_order_arc_671  -1
    order_0_21  connected_order_arc_673  -1
    order_0_21  connected_order_arc_675  -1
    order_0_21  connected_order_arc_677  -1
    order_0_21  connected_order_arc_679  -1
    order_0_21  connected_order_arc_681  -1
    order_0_21  connected_order_arc_706  1
    order_0_21  order_active_lb_782  1
    order_0_21  order_active_ub_783  1
    visit_0_22  out_degree_786  -1
    visit_0_22  in_degree_787  -1
    visit_0_22  order_active_lb_788  -1
    visit_0_22  order_active_ub_789  -13
    visit_0_22  service_visit_def_790  -1
    order_0_22  connected_order_arc_406  1
    order_0_22  connected_order_arc_431  1
    order_0_22  connected_order_arc_456  1
    order_0_22  connected_order_arc_481  1
    order_0_22  connected_order_arc_506  1
    order_0_22  connected_order_arc_531  1
    order_0_22  connected_order_arc_556  1
    order_0_22  connected_order_arc_581  1
    order_0_22  connected_order_arc_606  1
    order_0_22  connected_order_arc_631  1
    order_0_22  connected_order_arc_656  1
    order_0_22  connected_order_arc_681  1
    order_0_22  connected_order_arc_684  -1
    order_0_22  connected_order_arc_686  -1
    order_0_22  connected_order_arc_688  -1
    order_0_22  connected_order_arc_690  -1
    order_0_22  connected_order_arc_692  -1
    order_0_22  connected_order_arc_694  -1
    order_0_22  connected_order_arc_696  -1
    order_0_22  connected_order_arc_698  -1
    order_0_22  connected_order_arc_700  -1
    order_0_22  connected_order_arc_702  -1
    order_0_22  connected_order_arc_704  -1
    order_0_22  connected_order_arc_706  -1
    order_0_22  order_active_lb_788  1
    order_0_22  order_active_ub_789  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_368  -20
    arc_0_0_0  depot_departure_or_bypass_707  1
    arc_0_0_0  depot_return_or_bypass_708  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_368  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_369  -20
    arc_0_0_1  depot_departure_or_bypass_707  1
    arc_0_0_1  in_degree_710  1
    arc_0_0_1  original_T_including_depot_unload_796  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_369  1
    load_0_0_1  segment_load_conservation_713  -1
    load_0_0_1  segment_prefix_lb_714  1
    load_0_0_1  segment_prefix_ub_715  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_370  -20
    arc_0_0_2  depot_departure_or_bypass_707  1
    arc_0_0_2  in_degree_717  1
    arc_0_0_2  original_T_including_depot_unload_796  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_370  1
    load_0_0_2  segment_load_conservation_720  -1
    load_0_0_2  segment_prefix_lb_721  1
    load_0_0_2  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_371  -20
    arc_0_0_3  depot_departure_or_bypass_707  1
    arc_0_0_3  in_degree_724  1
    arc_0_0_3  original_T_including_depot_unload_796  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_371  1
    load_0_0_3  segment_load_conservation_727  -1
    load_0_0_3  segment_prefix_lb_728  1
    load_0_0_3  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_372  -20
    arc_0_0_4  depot_departure_or_bypass_707  1
    arc_0_0_4  in_degree_731  1
    arc_0_0_4  original_T_including_depot_unload_796  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_372  1
    load_0_0_4  segment_load_conservation_734  -1
    load_0_0_4  segment_prefix_lb_735  1
    load_0_0_4  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_373  -20
    arc_0_0_5  depot_departure_or_bypass_707  1
    arc_0_0_5  in_degree_738  1
    arc_0_0_5  original_T_including_depot_unload_796  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_373  1
    load_0_0_5  segment_load_conservation_741  -1
    load_0_0_5  segment_prefix_lb_742  1
    load_0_0_5  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_374  -20
    arc_0_0_15  depot_departure_or_bypass_707  1
    arc_0_0_15  in_degree_745  1
    arc_0_0_15  original_T_including_depot_unload_796  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_374  1
    load_0_0_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_375  -20
    arc_0_0_16  depot_departure_or_bypass_707  1
    arc_0_0_16  in_degree_751  1
    arc_0_0_16  original_T_including_depot_unload_796  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_375  1
    load_0_0_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_376  -20
    arc_0_0_17  depot_departure_or_bypass_707  1
    arc_0_0_17  in_degree_757  1
    arc_0_0_17  original_T_including_depot_unload_796  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_376  1
    load_0_0_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_377  -20
    arc_0_0_18  depot_departure_or_bypass_707  1
    arc_0_0_18  in_degree_763  1
    arc_0_0_18  original_T_including_depot_unload_796  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_377  1
    load_0_0_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_378  -20
    arc_0_0_19  depot_departure_or_bypass_707  1
    arc_0_0_19  in_degree_769  1
    arc_0_0_19  original_T_including_depot_unload_796  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_378  1
    load_0_0_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_379  -20
    arc_0_0_20  depot_departure_or_bypass_707  1
    arc_0_0_20  in_degree_775  1
    arc_0_0_20  original_T_including_depot_unload_796  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_379  1
    load_0_0_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_380  -20
    arc_0_0_21  depot_departure_or_bypass_707  1
    arc_0_0_21  in_degree_781  1
    arc_0_0_21  original_T_including_depot_unload_796  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_380  1
    load_0_0_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_22  arc_capacity_381  -20
    arc_0_0_22  depot_departure_or_bypass_707  1
    arc_0_0_22  in_degree_787  1
    arc_0_0_22  original_T_including_depot_unload_796  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_22  arc_capacity_381  1
    load_0_0_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_382  -20
    arc_0_1_0  depot_return_or_bypass_708  1
    arc_0_1_0  out_degree_709  1
    arc_0_1_0  original_T_including_depot_unload_796  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_382  1
    load_0_1_0  segment_load_conservation_713  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_383  -20
    arc_0_1_2  connected_order_arc_384  -14
    arc_0_1_2  out_degree_709  1
    arc_0_1_2  in_degree_717  1
    arc_0_1_2  original_T_including_depot_unload_796  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_383  1
    load_0_1_2  segment_load_conservation_713  1
    load_0_1_2  segment_load_conservation_720  -1
    load_0_1_2  segment_prefix_lb_721  1
    load_0_1_2  segment_prefix_ub_722  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_385  -20
    arc_0_1_3  connected_order_arc_386  -14
    arc_0_1_3  out_degree_709  1
    arc_0_1_3  in_degree_724  1
    arc_0_1_3  original_T_including_depot_unload_796  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_385  1
    load_0_1_3  segment_load_conservation_713  1
    load_0_1_3  segment_load_conservation_727  -1
    load_0_1_3  segment_prefix_lb_728  1
    load_0_1_3  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_387  -20
    arc_0_1_4  connected_order_arc_388  -14
    arc_0_1_4  out_degree_709  1
    arc_0_1_4  in_degree_731  1
    arc_0_1_4  original_T_including_depot_unload_796  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_387  1
    load_0_1_4  segment_load_conservation_713  1
    load_0_1_4  segment_load_conservation_734  -1
    load_0_1_4  segment_prefix_lb_735  1
    load_0_1_4  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_389  -20
    arc_0_1_5  connected_order_arc_390  -14
    arc_0_1_5  out_degree_709  1
    arc_0_1_5  in_degree_738  1
    arc_0_1_5  original_T_including_depot_unload_796  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_389  1
    load_0_1_5  segment_load_conservation_713  1
    load_0_1_5  segment_load_conservation_741  -1
    load_0_1_5  segment_prefix_lb_742  1
    load_0_1_5  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_391  -20
    arc_0_1_15  connected_order_arc_392  -14
    arc_0_1_15  out_degree_709  1
    arc_0_1_15  in_degree_745  1
    arc_0_1_15  original_T_including_depot_unload_796  1.7155529120526971e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_391  1
    load_0_1_15  segment_load_conservation_713  1
    load_0_1_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_393  -20
    arc_0_1_16  connected_order_arc_394  -14
    arc_0_1_16  out_degree_709  1
    arc_0_1_16  in_degree_751  1
    arc_0_1_16  original_T_including_depot_unload_796  1.5362659379368008e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_393  1
    load_0_1_16  segment_load_conservation_713  1
    load_0_1_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_395  -20
    arc_0_1_17  connected_order_arc_396  -14
    arc_0_1_17  out_degree_709  1
    arc_0_1_17  in_degree_757  1
    arc_0_1_17  original_T_including_depot_unload_796  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_395  1
    load_0_1_17  segment_load_conservation_713  1
    load_0_1_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_397  -20
    arc_0_1_18  connected_order_arc_398  -14
    arc_0_1_18  out_degree_709  1
    arc_0_1_18  in_degree_763  1
    arc_0_1_18  original_T_including_depot_unload_796  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_397  1
    load_0_1_18  segment_load_conservation_713  1
    load_0_1_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_399  -20
    arc_0_1_19  connected_order_arc_400  -14
    arc_0_1_19  out_degree_709  1
    arc_0_1_19  in_degree_769  1
    arc_0_1_19  original_T_including_depot_unload_796  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_399  1
    load_0_1_19  segment_load_conservation_713  1
    load_0_1_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_401  -20
    arc_0_1_20  connected_order_arc_402  -14
    arc_0_1_20  out_degree_709  1
    arc_0_1_20  in_degree_775  1
    arc_0_1_20  original_T_including_depot_unload_796  1.3812305438169078e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_401  1
    load_0_1_20  segment_load_conservation_713  1
    load_0_1_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_403  -20
    arc_0_1_21  connected_order_arc_404  -14
    arc_0_1_21  out_degree_709  1
    arc_0_1_21  in_degree_781  1
    arc_0_1_21  original_T_including_depot_unload_796  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_403  1
    load_0_1_21  segment_load_conservation_713  1
    load_0_1_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_22  arc_capacity_405  -20
    arc_0_1_22  connected_order_arc_406  -14
    arc_0_1_22  out_degree_709  1
    arc_0_1_22  in_degree_787  1
    arc_0_1_22  original_T_including_depot_unload_796  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_22  arc_capacity_405  1
    load_0_1_22  segment_load_conservation_713  1
    load_0_1_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_407  -20
    arc_0_2_0  depot_return_or_bypass_708  1
    arc_0_2_0  out_degree_716  1
    arc_0_2_0  original_T_including_depot_unload_796  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_407  1
    load_0_2_0  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_408  -20
    arc_0_2_1  connected_order_arc_409  -14
    arc_0_2_1  in_degree_710  1
    arc_0_2_1  out_degree_716  1
    arc_0_2_1  original_T_including_depot_unload_796  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_408  1
    load_0_2_1  segment_load_conservation_713  -1
    load_0_2_1  segment_prefix_lb_714  1
    load_0_2_1  segment_prefix_ub_715  1
    load_0_2_1  segment_load_conservation_720  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_410  -20
    arc_0_2_3  connected_order_arc_411  -14
    arc_0_2_3  out_degree_716  1
    arc_0_2_3  in_degree_724  1
    arc_0_2_3  original_T_including_depot_unload_796  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_410  1
    load_0_2_3  segment_load_conservation_720  1
    load_0_2_3  segment_load_conservation_727  -1
    load_0_2_3  segment_prefix_lb_728  1
    load_0_2_3  segment_prefix_ub_729  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_412  -20
    arc_0_2_4  connected_order_arc_413  -14
    arc_0_2_4  out_degree_716  1
    arc_0_2_4  in_degree_731  1
    arc_0_2_4  original_T_including_depot_unload_796  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_412  1
    load_0_2_4  segment_load_conservation_720  1
    load_0_2_4  segment_load_conservation_734  -1
    load_0_2_4  segment_prefix_lb_735  1
    load_0_2_4  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_414  -20
    arc_0_2_5  connected_order_arc_415  -14
    arc_0_2_5  out_degree_716  1
    arc_0_2_5  in_degree_738  1
    arc_0_2_5  original_T_including_depot_unload_796  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_414  1
    load_0_2_5  segment_load_conservation_720  1
    load_0_2_5  segment_load_conservation_741  -1
    load_0_2_5  segment_prefix_lb_742  1
    load_0_2_5  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_416  -20
    arc_0_2_15  connected_order_arc_417  -14
    arc_0_2_15  out_degree_716  1
    arc_0_2_15  in_degree_745  1
    arc_0_2_15  original_T_including_depot_unload_796  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_416  1
    load_0_2_15  segment_load_conservation_720  1
    load_0_2_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_418  -20
    arc_0_2_16  connected_order_arc_419  -14
    arc_0_2_16  out_degree_716  1
    arc_0_2_16  in_degree_751  1
    arc_0_2_16  original_T_including_depot_unload_796  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_418  1
    load_0_2_16  segment_load_conservation_720  1
    load_0_2_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_420  -20
    arc_0_2_17  connected_order_arc_421  -14
    arc_0_2_17  out_degree_716  1
    arc_0_2_17  in_degree_757  1
    arc_0_2_17  original_T_including_depot_unload_796  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_420  1
    load_0_2_17  segment_load_conservation_720  1
    load_0_2_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_422  -20
    arc_0_2_18  connected_order_arc_423  -14
    arc_0_2_18  out_degree_716  1
    arc_0_2_18  in_degree_763  1
    arc_0_2_18  original_T_including_depot_unload_796  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_422  1
    load_0_2_18  segment_load_conservation_720  1
    load_0_2_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_424  -20
    arc_0_2_19  connected_order_arc_425  -14
    arc_0_2_19  out_degree_716  1
    arc_0_2_19  in_degree_769  1
    arc_0_2_19  original_T_including_depot_unload_796  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_424  1
    load_0_2_19  segment_load_conservation_720  1
    load_0_2_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_426  -20
    arc_0_2_20  connected_order_arc_427  -14
    arc_0_2_20  out_degree_716  1
    arc_0_2_20  in_degree_775  1
    arc_0_2_20  original_T_including_depot_unload_796  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_426  1
    load_0_2_20  segment_load_conservation_720  1
    load_0_2_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_428  -20
    arc_0_2_21  connected_order_arc_429  -14
    arc_0_2_21  out_degree_716  1
    arc_0_2_21  in_degree_781  1
    arc_0_2_21  original_T_including_depot_unload_796  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_428  1
    load_0_2_21  segment_load_conservation_720  1
    load_0_2_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_22  arc_capacity_430  -20
    arc_0_2_22  connected_order_arc_431  -14
    arc_0_2_22  out_degree_716  1
    arc_0_2_22  in_degree_787  1
    arc_0_2_22  original_T_including_depot_unload_796  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_22  arc_capacity_430  1
    load_0_2_22  segment_load_conservation_720  1
    load_0_2_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_432  -20
    arc_0_3_0  depot_return_or_bypass_708  1
    arc_0_3_0  out_degree_723  1
    arc_0_3_0  original_T_including_depot_unload_796  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_432  1
    load_0_3_0  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_433  -20
    arc_0_3_1  connected_order_arc_434  -14
    arc_0_3_1  in_degree_710  1
    arc_0_3_1  out_degree_723  1
    arc_0_3_1  original_T_including_depot_unload_796  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_433  1
    load_0_3_1  segment_load_conservation_713  -1
    load_0_3_1  segment_prefix_lb_714  1
    load_0_3_1  segment_prefix_ub_715  1
    load_0_3_1  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_435  -20
    arc_0_3_2  connected_order_arc_436  -14
    arc_0_3_2  in_degree_717  1
    arc_0_3_2  out_degree_723  1
    arc_0_3_2  original_T_including_depot_unload_796  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_435  1
    load_0_3_2  segment_load_conservation_720  -1
    load_0_3_2  segment_prefix_lb_721  1
    load_0_3_2  segment_prefix_ub_722  1
    load_0_3_2  segment_load_conservation_727  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_437  -20
    arc_0_3_4  connected_order_arc_438  -14
    arc_0_3_4  out_degree_723  1
    arc_0_3_4  in_degree_731  1
    arc_0_3_4  original_T_including_depot_unload_796  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_437  1
    load_0_3_4  segment_load_conservation_727  1
    load_0_3_4  segment_load_conservation_734  -1
    load_0_3_4  segment_prefix_lb_735  1
    load_0_3_4  segment_prefix_ub_736  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_439  -20
    arc_0_3_5  connected_order_arc_440  -14
    arc_0_3_5  out_degree_723  1
    arc_0_3_5  in_degree_738  1
    arc_0_3_5  original_T_including_depot_unload_796  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_439  1
    load_0_3_5  segment_load_conservation_727  1
    load_0_3_5  segment_load_conservation_741  -1
    load_0_3_5  segment_prefix_lb_742  1
    load_0_3_5  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_441  -20
    arc_0_3_15  connected_order_arc_442  -14
    arc_0_3_15  out_degree_723  1
    arc_0_3_15  in_degree_745  1
    arc_0_3_15  original_T_including_depot_unload_796  1.5086201853425566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_441  1
    load_0_3_15  segment_load_conservation_727  1
    load_0_3_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_443  -20
    arc_0_3_16  connected_order_arc_444  -14
    arc_0_3_16  out_degree_723  1
    arc_0_3_16  in_degree_751  1
    arc_0_3_16  original_T_including_depot_unload_796  1.3279253844180159e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_443  1
    load_0_3_16  segment_load_conservation_727  1
    load_0_3_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_445  -20
    arc_0_3_17  connected_order_arc_446  -14
    arc_0_3_17  out_degree_723  1
    arc_0_3_17  in_degree_757  1
    arc_0_3_17  original_T_including_depot_unload_796  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_445  1
    load_0_3_17  segment_load_conservation_727  1
    load_0_3_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_447  -20
    arc_0_3_18  connected_order_arc_448  -14
    arc_0_3_18  out_degree_723  1
    arc_0_3_18  in_degree_763  1
    arc_0_3_18  original_T_including_depot_unload_796  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_447  1
    load_0_3_18  segment_load_conservation_727  1
    load_0_3_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_449  -20
    arc_0_3_19  connected_order_arc_450  -14
    arc_0_3_19  out_degree_723  1
    arc_0_3_19  in_degree_769  1
    arc_0_3_19  original_T_including_depot_unload_796  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_449  1
    load_0_3_19  segment_load_conservation_727  1
    load_0_3_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_451  -20
    arc_0_3_20  connected_order_arc_452  -14
    arc_0_3_20  out_degree_723  1
    arc_0_3_20  in_degree_775  1
    arc_0_3_20  original_T_including_depot_unload_796  1.0917254946216958e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_451  1
    load_0_3_20  segment_load_conservation_727  1
    load_0_3_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_453  -20
    arc_0_3_21  connected_order_arc_454  -14
    arc_0_3_21  out_degree_723  1
    arc_0_3_21  in_degree_781  1
    arc_0_3_21  original_T_including_depot_unload_796  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_453  1
    load_0_3_21  segment_load_conservation_727  1
    load_0_3_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_22  arc_capacity_455  -20
    arc_0_3_22  connected_order_arc_456  -14
    arc_0_3_22  out_degree_723  1
    arc_0_3_22  in_degree_787  1
    arc_0_3_22  original_T_including_depot_unload_796  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_22  arc_capacity_455  1
    load_0_3_22  segment_load_conservation_727  1
    load_0_3_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_457  -20
    arc_0_4_0  depot_return_or_bypass_708  1
    arc_0_4_0  out_degree_730  1
    arc_0_4_0  original_T_including_depot_unload_796  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_457  1
    load_0_4_0  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_458  -20
    arc_0_4_1  connected_order_arc_459  -14
    arc_0_4_1  in_degree_710  1
    arc_0_4_1  out_degree_730  1
    arc_0_4_1  original_T_including_depot_unload_796  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_458  1
    load_0_4_1  segment_load_conservation_713  -1
    load_0_4_1  segment_prefix_lb_714  1
    load_0_4_1  segment_prefix_ub_715  1
    load_0_4_1  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_460  -20
    arc_0_4_2  connected_order_arc_461  -14
    arc_0_4_2  in_degree_717  1
    arc_0_4_2  out_degree_730  1
    arc_0_4_2  original_T_including_depot_unload_796  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_460  1
    load_0_4_2  segment_load_conservation_720  -1
    load_0_4_2  segment_prefix_lb_721  1
    load_0_4_2  segment_prefix_ub_722  1
    load_0_4_2  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_462  -20
    arc_0_4_3  connected_order_arc_463  -14
    arc_0_4_3  in_degree_724  1
    arc_0_4_3  out_degree_730  1
    arc_0_4_3  original_T_including_depot_unload_796  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_462  1
    load_0_4_3  segment_load_conservation_727  -1
    load_0_4_3  segment_prefix_lb_728  1
    load_0_4_3  segment_prefix_ub_729  1
    load_0_4_3  segment_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_464  -20
    arc_0_4_5  connected_order_arc_465  -14
    arc_0_4_5  out_degree_730  1
    arc_0_4_5  in_degree_738  1
    arc_0_4_5  original_T_including_depot_unload_796  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_464  1
    load_0_4_5  segment_load_conservation_734  1
    load_0_4_5  segment_load_conservation_741  -1
    load_0_4_5  segment_prefix_lb_742  1
    load_0_4_5  segment_prefix_ub_743  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_466  -20
    arc_0_4_15  connected_order_arc_467  -14
    arc_0_4_15  out_degree_730  1
    arc_0_4_15  in_degree_745  1
    arc_0_4_15  original_T_including_depot_unload_796  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_466  1
    load_0_4_15  segment_load_conservation_734  1
    load_0_4_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_468  -20
    arc_0_4_16  connected_order_arc_469  -14
    arc_0_4_16  out_degree_730  1
    arc_0_4_16  in_degree_751  1
    arc_0_4_16  original_T_including_depot_unload_796  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_468  1
    load_0_4_16  segment_load_conservation_734  1
    load_0_4_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_470  -20
    arc_0_4_17  connected_order_arc_471  -14
    arc_0_4_17  out_degree_730  1
    arc_0_4_17  in_degree_757  1
    arc_0_4_17  original_T_including_depot_unload_796  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_470  1
    load_0_4_17  segment_load_conservation_734  1
    load_0_4_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_472  -20
    arc_0_4_18  connected_order_arc_473  -14
    arc_0_4_18  out_degree_730  1
    arc_0_4_18  in_degree_763  1
    arc_0_4_18  original_T_including_depot_unload_796  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_472  1
    load_0_4_18  segment_load_conservation_734  1
    load_0_4_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_474  -20
    arc_0_4_19  connected_order_arc_475  -14
    arc_0_4_19  out_degree_730  1
    arc_0_4_19  in_degree_769  1
    arc_0_4_19  original_T_including_depot_unload_796  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_474  1
    load_0_4_19  segment_load_conservation_734  1
    load_0_4_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_476  -20
    arc_0_4_20  connected_order_arc_477  -14
    arc_0_4_20  out_degree_730  1
    arc_0_4_20  in_degree_775  1
    arc_0_4_20  original_T_including_depot_unload_796  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_476  1
    load_0_4_20  segment_load_conservation_734  1
    load_0_4_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_478  -20
    arc_0_4_21  connected_order_arc_479  -14
    arc_0_4_21  out_degree_730  1
    arc_0_4_21  in_degree_781  1
    arc_0_4_21  original_T_including_depot_unload_796  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_478  1
    load_0_4_21  segment_load_conservation_734  1
    load_0_4_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_22  arc_capacity_480  -20
    arc_0_4_22  connected_order_arc_481  -14
    arc_0_4_22  out_degree_730  1
    arc_0_4_22  in_degree_787  1
    arc_0_4_22  original_T_including_depot_unload_796  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_22  arc_capacity_480  1
    load_0_4_22  segment_load_conservation_734  1
    load_0_4_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_482  -20
    arc_0_5_0  depot_return_or_bypass_708  1
    arc_0_5_0  out_degree_737  1
    arc_0_5_0  original_T_including_depot_unload_796  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_482  1
    load_0_5_0  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_483  -20
    arc_0_5_1  connected_order_arc_484  -14
    arc_0_5_1  in_degree_710  1
    arc_0_5_1  out_degree_737  1
    arc_0_5_1  original_T_including_depot_unload_796  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_483  1
    load_0_5_1  segment_load_conservation_713  -1
    load_0_5_1  segment_prefix_lb_714  1
    load_0_5_1  segment_prefix_ub_715  1
    load_0_5_1  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_485  -20
    arc_0_5_2  connected_order_arc_486  -14
    arc_0_5_2  in_degree_717  1
    arc_0_5_2  out_degree_737  1
    arc_0_5_2  original_T_including_depot_unload_796  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_485  1
    load_0_5_2  segment_load_conservation_720  -1
    load_0_5_2  segment_prefix_lb_721  1
    load_0_5_2  segment_prefix_ub_722  1
    load_0_5_2  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_487  -20
    arc_0_5_3  connected_order_arc_488  -14
    arc_0_5_3  in_degree_724  1
    arc_0_5_3  out_degree_737  1
    arc_0_5_3  original_T_including_depot_unload_796  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_487  1
    load_0_5_3  segment_load_conservation_727  -1
    load_0_5_3  segment_prefix_lb_728  1
    load_0_5_3  segment_prefix_ub_729  1
    load_0_5_3  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_489  -20
    arc_0_5_4  connected_order_arc_490  -14
    arc_0_5_4  in_degree_731  1
    arc_0_5_4  out_degree_737  1
    arc_0_5_4  original_T_including_depot_unload_796  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_489  1
    load_0_5_4  segment_load_conservation_734  -1
    load_0_5_4  segment_prefix_lb_735  1
    load_0_5_4  segment_prefix_ub_736  1
    load_0_5_4  segment_load_conservation_741  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_491  -20
    arc_0_5_15  connected_order_arc_492  -14
    arc_0_5_15  out_degree_737  1
    arc_0_5_15  in_degree_745  1
    arc_0_5_15  original_T_including_depot_unload_796  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_491  1
    load_0_5_15  segment_load_conservation_741  1
    load_0_5_15  free_load_conservation_749  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_493  -20
    arc_0_5_16  connected_order_arc_494  -14
    arc_0_5_16  out_degree_737  1
    arc_0_5_16  in_degree_751  1
    arc_0_5_16  original_T_including_depot_unload_796  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_493  1
    load_0_5_16  segment_load_conservation_741  1
    load_0_5_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_495  -20
    arc_0_5_17  connected_order_arc_496  -14
    arc_0_5_17  out_degree_737  1
    arc_0_5_17  in_degree_757  1
    arc_0_5_17  original_T_including_depot_unload_796  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_495  1
    load_0_5_17  segment_load_conservation_741  1
    load_0_5_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_497  -20
    arc_0_5_18  connected_order_arc_498  -14
    arc_0_5_18  out_degree_737  1
    arc_0_5_18  in_degree_763  1
    arc_0_5_18  original_T_including_depot_unload_796  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_497  1
    load_0_5_18  segment_load_conservation_741  1
    load_0_5_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_499  -20
    arc_0_5_19  connected_order_arc_500  -14
    arc_0_5_19  out_degree_737  1
    arc_0_5_19  in_degree_769  1
    arc_0_5_19  original_T_including_depot_unload_796  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_499  1
    load_0_5_19  segment_load_conservation_741  1
    load_0_5_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_501  -20
    arc_0_5_20  connected_order_arc_502  -14
    arc_0_5_20  out_degree_737  1
    arc_0_5_20  in_degree_775  1
    arc_0_5_20  original_T_including_depot_unload_796  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_501  1
    load_0_5_20  segment_load_conservation_741  1
    load_0_5_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_21  arc_capacity_503  -20
    arc_0_5_21  connected_order_arc_504  -14
    arc_0_5_21  out_degree_737  1
    arc_0_5_21  in_degree_781  1
    arc_0_5_21  original_T_including_depot_unload_796  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_21  arc_capacity_503  1
    load_0_5_21  segment_load_conservation_741  1
    load_0_5_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_22  arc_capacity_505  -20
    arc_0_5_22  connected_order_arc_506  -14
    arc_0_5_22  out_degree_737  1
    arc_0_5_22  in_degree_787  1
    arc_0_5_22  original_T_including_depot_unload_796  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_22  arc_capacity_505  1
    load_0_5_22  segment_load_conservation_741  1
    load_0_5_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_507  -20
    arc_0_15_0  depot_return_or_bypass_708  1
    arc_0_15_0  out_degree_744  1
    arc_0_15_0  original_T_including_depot_unload_796  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_507  1
    load_0_15_0  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_508  -20
    arc_0_15_1  connected_order_arc_509  -14
    arc_0_15_1  in_degree_710  1
    arc_0_15_1  out_degree_744  1
    arc_0_15_1  original_T_including_depot_unload_796  1.7069358358556344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_508  1
    load_0_15_1  segment_load_conservation_713  -1
    load_0_15_1  segment_prefix_lb_714  1
    load_0_15_1  segment_prefix_ub_715  1
    load_0_15_1  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_510  -20
    arc_0_15_2  connected_order_arc_511  -14
    arc_0_15_2  in_degree_717  1
    arc_0_15_2  out_degree_744  1
    arc_0_15_2  original_T_including_depot_unload_796  1.5960107821452696e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_510  1
    load_0_15_2  segment_load_conservation_720  -1
    load_0_15_2  segment_prefix_lb_721  1
    load_0_15_2  segment_prefix_ub_722  1
    load_0_15_2  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_512  -20
    arc_0_15_3  connected_order_arc_513  -14
    arc_0_15_3  in_degree_724  1
    arc_0_15_3  out_degree_744  1
    arc_0_15_3  original_T_including_depot_unload_796  1.7998334548300843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_512  1
    load_0_15_3  segment_load_conservation_727  -1
    load_0_15_3  segment_prefix_lb_728  1
    load_0_15_3  segment_prefix_ub_729  1
    load_0_15_3  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_514  -20
    arc_0_15_4  connected_order_arc_515  -14
    arc_0_15_4  in_degree_731  1
    arc_0_15_4  out_degree_744  1
    arc_0_15_4  original_T_including_depot_unload_796  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_514  1
    load_0_15_4  segment_load_conservation_734  -1
    load_0_15_4  segment_prefix_lb_735  1
    load_0_15_4  segment_prefix_ub_736  1
    load_0_15_4  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_516  -20
    arc_0_15_5  connected_order_arc_517  -14
    arc_0_15_5  in_degree_738  1
    arc_0_15_5  out_degree_744  1
    arc_0_15_5  original_T_including_depot_unload_796  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_516  1
    load_0_15_5  segment_load_conservation_741  -1
    load_0_15_5  segment_prefix_lb_742  1
    load_0_15_5  segment_prefix_ub_743  1
    load_0_15_5  free_load_conservation_749  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_518  -20
    arc_0_15_16  connected_order_arc_519  -14
    arc_0_15_16  out_degree_744  1
    arc_0_15_16  in_degree_751  1
    arc_0_15_16  original_T_including_depot_unload_796  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_518  1
    load_0_15_16  free_load_conservation_749  1
    load_0_15_16  free_load_conservation_755  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_520  -20
    arc_0_15_17  connected_order_arc_521  -14
    arc_0_15_17  out_degree_744  1
    arc_0_15_17  in_degree_757  1
    arc_0_15_17  original_T_including_depot_unload_796  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_520  1
    load_0_15_17  free_load_conservation_749  1
    load_0_15_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_522  -20
    arc_0_15_18  connected_order_arc_523  -14
    arc_0_15_18  out_degree_744  1
    arc_0_15_18  in_degree_763  1
    arc_0_15_18  original_T_including_depot_unload_796  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_522  1
    load_0_15_18  free_load_conservation_749  1
    load_0_15_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_524  -20
    arc_0_15_19  connected_order_arc_525  -14
    arc_0_15_19  out_degree_744  1
    arc_0_15_19  in_degree_769  1
    arc_0_15_19  original_T_including_depot_unload_796  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_524  1
    load_0_15_19  free_load_conservation_749  1
    load_0_15_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_526  -20
    arc_0_15_20  connected_order_arc_527  -14
    arc_0_15_20  out_degree_744  1
    arc_0_15_20  in_degree_775  1
    arc_0_15_20  original_T_including_depot_unload_796  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_526  1
    load_0_15_20  free_load_conservation_749  1
    load_0_15_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_528  -20
    arc_0_15_21  connected_order_arc_529  -14
    arc_0_15_21  out_degree_744  1
    arc_0_15_21  in_degree_781  1
    arc_0_15_21  original_T_including_depot_unload_796  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_528  1
    load_0_15_21  free_load_conservation_749  1
    load_0_15_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_22  arc_capacity_530  -20
    arc_0_15_22  connected_order_arc_531  -14
    arc_0_15_22  out_degree_744  1
    arc_0_15_22  in_degree_787  1
    arc_0_15_22  original_T_including_depot_unload_796  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_22  arc_capacity_530  1
    load_0_15_22  free_load_conservation_749  1
    load_0_15_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_532  -20
    arc_0_16_0  depot_return_or_bypass_708  1
    arc_0_16_0  out_degree_750  1
    arc_0_16_0  original_T_including_depot_unload_796  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_532  1
    load_0_16_0  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_533  -20
    arc_0_16_1  connected_order_arc_534  -14
    arc_0_16_1  in_degree_710  1
    arc_0_16_1  out_degree_750  1
    arc_0_16_1  original_T_including_depot_unload_796  1.5346053834915313e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_533  1
    load_0_16_1  segment_load_conservation_713  -1
    load_0_16_1  segment_prefix_lb_714  1
    load_0_16_1  segment_prefix_ub_715  1
    load_0_16_1  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_535  -20
    arc_0_16_2  connected_order_arc_536  -14
    arc_0_16_2  in_degree_717  1
    arc_0_16_2  out_degree_750  1
    arc_0_16_2  original_T_including_depot_unload_796  1.4151906470783242e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_535  1
    load_0_16_2  segment_load_conservation_720  -1
    load_0_16_2  segment_prefix_lb_721  1
    load_0_16_2  segment_prefix_ub_722  1
    load_0_16_2  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_537  -20
    arc_0_16_3  connected_order_arc_538  -14
    arc_0_16_3  in_degree_724  1
    arc_0_16_3  out_degree_750  1
    arc_0_16_3  original_T_including_depot_unload_796  1.6185675384860760e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_537  1
    load_0_16_3  segment_load_conservation_727  -1
    load_0_16_3  segment_prefix_lb_728  1
    load_0_16_3  segment_prefix_ub_729  1
    load_0_16_3  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_539  -20
    arc_0_16_4  connected_order_arc_540  -14
    arc_0_16_4  in_degree_731  1
    arc_0_16_4  out_degree_750  1
    arc_0_16_4  original_T_including_depot_unload_796  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_539  1
    load_0_16_4  segment_load_conservation_734  -1
    load_0_16_4  segment_prefix_lb_735  1
    load_0_16_4  segment_prefix_ub_736  1
    load_0_16_4  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_541  -20
    arc_0_16_5  connected_order_arc_542  -14
    arc_0_16_5  in_degree_738  1
    arc_0_16_5  out_degree_750  1
    arc_0_16_5  original_T_including_depot_unload_796  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_541  1
    load_0_16_5  segment_load_conservation_741  -1
    load_0_16_5  segment_prefix_lb_742  1
    load_0_16_5  segment_prefix_ub_743  1
    load_0_16_5  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_543  -20
    arc_0_16_15  connected_order_arc_544  -14
    arc_0_16_15  in_degree_745  1
    arc_0_16_15  out_degree_750  1
    arc_0_16_15  original_T_including_depot_unload_796  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_543  1
    load_0_16_15  free_load_conservation_749  -1
    load_0_16_15  free_load_conservation_755  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_545  -20
    arc_0_16_17  connected_order_arc_546  -14
    arc_0_16_17  out_degree_750  1
    arc_0_16_17  in_degree_757  1
    arc_0_16_17  original_T_including_depot_unload_796  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_545  1
    load_0_16_17  free_load_conservation_755  1
    load_0_16_17  free_load_conservation_761  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_547  -20
    arc_0_16_18  connected_order_arc_548  -14
    arc_0_16_18  out_degree_750  1
    arc_0_16_18  in_degree_763  1
    arc_0_16_18  original_T_including_depot_unload_796  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_547  1
    load_0_16_18  free_load_conservation_755  1
    load_0_16_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_549  -20
    arc_0_16_19  connected_order_arc_550  -14
    arc_0_16_19  out_degree_750  1
    arc_0_16_19  in_degree_769  1
    arc_0_16_19  original_T_including_depot_unload_796  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_549  1
    load_0_16_19  free_load_conservation_755  1
    load_0_16_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_551  -20
    arc_0_16_20  connected_order_arc_552  -14
    arc_0_16_20  out_degree_750  1
    arc_0_16_20  in_degree_775  1
    arc_0_16_20  original_T_including_depot_unload_796  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_551  1
    load_0_16_20  free_load_conservation_755  1
    load_0_16_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_553  -20
    arc_0_16_21  connected_order_arc_554  -14
    arc_0_16_21  out_degree_750  1
    arc_0_16_21  in_degree_781  1
    arc_0_16_21  original_T_including_depot_unload_796  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_553  1
    load_0_16_21  free_load_conservation_755  1
    load_0_16_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_22  arc_capacity_555  -20
    arc_0_16_22  connected_order_arc_556  -14
    arc_0_16_22  out_degree_750  1
    arc_0_16_22  in_degree_787  1
    arc_0_16_22  original_T_including_depot_unload_796  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_22  arc_capacity_555  1
    load_0_16_22  free_load_conservation_755  1
    load_0_16_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_557  -20
    arc_0_17_0  depot_return_or_bypass_708  1
    arc_0_17_0  out_degree_756  1
    arc_0_17_0  original_T_including_depot_unload_796  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_557  1
    load_0_17_0  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_558  -20
    arc_0_17_1  connected_order_arc_559  -14
    arc_0_17_1  in_degree_710  1
    arc_0_17_1  out_degree_756  1
    arc_0_17_1  original_T_including_depot_unload_796  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_558  1
    load_0_17_1  segment_load_conservation_713  -1
    load_0_17_1  segment_prefix_lb_714  1
    load_0_17_1  segment_prefix_ub_715  1
    load_0_17_1  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_560  -20
    arc_0_17_2  connected_order_arc_561  -14
    arc_0_17_2  in_degree_717  1
    arc_0_17_2  out_degree_756  1
    arc_0_17_2  original_T_including_depot_unload_796  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_560  1
    load_0_17_2  segment_load_conservation_720  -1
    load_0_17_2  segment_prefix_lb_721  1
    load_0_17_2  segment_prefix_ub_722  1
    load_0_17_2  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_562  -20
    arc_0_17_3  connected_order_arc_563  -14
    arc_0_17_3  in_degree_724  1
    arc_0_17_3  out_degree_756  1
    arc_0_17_3  original_T_including_depot_unload_796  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_562  1
    load_0_17_3  segment_load_conservation_727  -1
    load_0_17_3  segment_prefix_lb_728  1
    load_0_17_3  segment_prefix_ub_729  1
    load_0_17_3  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_564  -20
    arc_0_17_4  connected_order_arc_565  -14
    arc_0_17_4  in_degree_731  1
    arc_0_17_4  out_degree_756  1
    arc_0_17_4  original_T_including_depot_unload_796  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_564  1
    load_0_17_4  segment_load_conservation_734  -1
    load_0_17_4  segment_prefix_lb_735  1
    load_0_17_4  segment_prefix_ub_736  1
    load_0_17_4  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_566  -20
    arc_0_17_5  connected_order_arc_567  -14
    arc_0_17_5  in_degree_738  1
    arc_0_17_5  out_degree_756  1
    arc_0_17_5  original_T_including_depot_unload_796  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_566  1
    load_0_17_5  segment_load_conservation_741  -1
    load_0_17_5  segment_prefix_lb_742  1
    load_0_17_5  segment_prefix_ub_743  1
    load_0_17_5  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_568  -20
    arc_0_17_15  connected_order_arc_569  -14
    arc_0_17_15  in_degree_745  1
    arc_0_17_15  out_degree_756  1
    arc_0_17_15  original_T_including_depot_unload_796  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_568  1
    load_0_17_15  free_load_conservation_749  -1
    load_0_17_15  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_570  -20
    arc_0_17_16  connected_order_arc_571  -14
    arc_0_17_16  in_degree_751  1
    arc_0_17_16  out_degree_756  1
    arc_0_17_16  original_T_including_depot_unload_796  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_570  1
    load_0_17_16  free_load_conservation_755  -1
    load_0_17_16  free_load_conservation_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_572  -20
    arc_0_17_18  connected_order_arc_573  -14
    arc_0_17_18  out_degree_756  1
    arc_0_17_18  in_degree_763  1
    arc_0_17_18  original_T_including_depot_unload_796  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_572  1
    load_0_17_18  free_load_conservation_761  1
    load_0_17_18  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_574  -20
    arc_0_17_19  connected_order_arc_575  -14
    arc_0_17_19  out_degree_756  1
    arc_0_17_19  in_degree_769  1
    arc_0_17_19  original_T_including_depot_unload_796  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_574  1
    load_0_17_19  free_load_conservation_761  1
    load_0_17_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_576  -20
    arc_0_17_20  connected_order_arc_577  -14
    arc_0_17_20  out_degree_756  1
    arc_0_17_20  in_degree_775  1
    arc_0_17_20  original_T_including_depot_unload_796  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_576  1
    load_0_17_20  free_load_conservation_761  1
    load_0_17_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_578  -20
    arc_0_17_21  connected_order_arc_579  -14
    arc_0_17_21  out_degree_756  1
    arc_0_17_21  in_degree_781  1
    arc_0_17_21  original_T_including_depot_unload_796  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_578  1
    load_0_17_21  free_load_conservation_761  1
    load_0_17_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_22  arc_capacity_580  -20
    arc_0_17_22  connected_order_arc_581  -14
    arc_0_17_22  out_degree_756  1
    arc_0_17_22  in_degree_787  1
    arc_0_17_22  original_T_including_depot_unload_796  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_22  arc_capacity_580  1
    load_0_17_22  free_load_conservation_761  1
    load_0_17_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_582  -20
    arc_0_18_0  depot_return_or_bypass_708  1
    arc_0_18_0  out_degree_762  1
    arc_0_18_0  original_T_including_depot_unload_796  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_582  1
    load_0_18_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_583  -20
    arc_0_18_1  connected_order_arc_584  -14
    arc_0_18_1  in_degree_710  1
    arc_0_18_1  out_degree_762  1
    arc_0_18_1  original_T_including_depot_unload_796  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_583  1
    load_0_18_1  segment_load_conservation_713  -1
    load_0_18_1  segment_prefix_lb_714  1
    load_0_18_1  segment_prefix_ub_715  1
    load_0_18_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_585  -20
    arc_0_18_2  connected_order_arc_586  -14
    arc_0_18_2  in_degree_717  1
    arc_0_18_2  out_degree_762  1
    arc_0_18_2  original_T_including_depot_unload_796  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_585  1
    load_0_18_2  segment_load_conservation_720  -1
    load_0_18_2  segment_prefix_lb_721  1
    load_0_18_2  segment_prefix_ub_722  1
    load_0_18_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_587  -20
    arc_0_18_3  connected_order_arc_588  -14
    arc_0_18_3  in_degree_724  1
    arc_0_18_3  out_degree_762  1
    arc_0_18_3  original_T_including_depot_unload_796  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_587  1
    load_0_18_3  segment_load_conservation_727  -1
    load_0_18_3  segment_prefix_lb_728  1
    load_0_18_3  segment_prefix_ub_729  1
    load_0_18_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_589  -20
    arc_0_18_4  connected_order_arc_590  -14
    arc_0_18_4  in_degree_731  1
    arc_0_18_4  out_degree_762  1
    arc_0_18_4  original_T_including_depot_unload_796  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_589  1
    load_0_18_4  segment_load_conservation_734  -1
    load_0_18_4  segment_prefix_lb_735  1
    load_0_18_4  segment_prefix_ub_736  1
    load_0_18_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_591  -20
    arc_0_18_5  connected_order_arc_592  -14
    arc_0_18_5  in_degree_738  1
    arc_0_18_5  out_degree_762  1
    arc_0_18_5  original_T_including_depot_unload_796  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_591  1
    load_0_18_5  segment_load_conservation_741  -1
    load_0_18_5  segment_prefix_lb_742  1
    load_0_18_5  segment_prefix_ub_743  1
    load_0_18_5  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_593  -20
    arc_0_18_15  connected_order_arc_594  -14
    arc_0_18_15  in_degree_745  1
    arc_0_18_15  out_degree_762  1
    arc_0_18_15  original_T_including_depot_unload_796  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_593  1
    load_0_18_15  free_load_conservation_749  -1
    load_0_18_15  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_595  -20
    arc_0_18_16  connected_order_arc_596  -14
    arc_0_18_16  in_degree_751  1
    arc_0_18_16  out_degree_762  1
    arc_0_18_16  original_T_including_depot_unload_796  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_595  1
    load_0_18_16  free_load_conservation_755  -1
    load_0_18_16  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_597  -20
    arc_0_18_17  connected_order_arc_598  -14
    arc_0_18_17  in_degree_757  1
    arc_0_18_17  out_degree_762  1
    arc_0_18_17  original_T_including_depot_unload_796  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_597  1
    load_0_18_17  free_load_conservation_761  -1
    load_0_18_17  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_599  -20
    arc_0_18_19  connected_order_arc_600  -14
    arc_0_18_19  out_degree_762  1
    arc_0_18_19  in_degree_769  1
    arc_0_18_19  original_T_including_depot_unload_796  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_599  1
    load_0_18_19  free_load_conservation_767  1
    load_0_18_19  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_601  -20
    arc_0_18_20  connected_order_arc_602  -14
    arc_0_18_20  out_degree_762  1
    arc_0_18_20  in_degree_775  1
    arc_0_18_20  original_T_including_depot_unload_796  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_601  1
    load_0_18_20  free_load_conservation_767  1
    load_0_18_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_603  -20
    arc_0_18_21  connected_order_arc_604  -14
    arc_0_18_21  out_degree_762  1
    arc_0_18_21  in_degree_781  1
    arc_0_18_21  original_T_including_depot_unload_796  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_603  1
    load_0_18_21  free_load_conservation_767  1
    load_0_18_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_22  arc_capacity_605  -20
    arc_0_18_22  connected_order_arc_606  -14
    arc_0_18_22  out_degree_762  1
    arc_0_18_22  in_degree_787  1
    arc_0_18_22  original_T_including_depot_unload_796  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_22  arc_capacity_605  1
    load_0_18_22  free_load_conservation_767  1
    load_0_18_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_607  -20
    arc_0_19_0  depot_return_or_bypass_708  1
    arc_0_19_0  out_degree_768  1
    arc_0_19_0  original_T_including_depot_unload_796  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_607  1
    load_0_19_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_608  -20
    arc_0_19_1  connected_order_arc_609  -14
    arc_0_19_1  in_degree_710  1
    arc_0_19_1  out_degree_768  1
    arc_0_19_1  original_T_including_depot_unload_796  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_608  1
    load_0_19_1  segment_load_conservation_713  -1
    load_0_19_1  segment_prefix_lb_714  1
    load_0_19_1  segment_prefix_ub_715  1
    load_0_19_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_610  -20
    arc_0_19_2  connected_order_arc_611  -14
    arc_0_19_2  in_degree_717  1
    arc_0_19_2  out_degree_768  1
    arc_0_19_2  original_T_including_depot_unload_796  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_610  1
    load_0_19_2  segment_load_conservation_720  -1
    load_0_19_2  segment_prefix_lb_721  1
    load_0_19_2  segment_prefix_ub_722  1
    load_0_19_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_612  -20
    arc_0_19_3  connected_order_arc_613  -14
    arc_0_19_3  in_degree_724  1
    arc_0_19_3  out_degree_768  1
    arc_0_19_3  original_T_including_depot_unload_796  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_612  1
    load_0_19_3  segment_load_conservation_727  -1
    load_0_19_3  segment_prefix_lb_728  1
    load_0_19_3  segment_prefix_ub_729  1
    load_0_19_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_614  -20
    arc_0_19_4  connected_order_arc_615  -14
    arc_0_19_4  in_degree_731  1
    arc_0_19_4  out_degree_768  1
    arc_0_19_4  original_T_including_depot_unload_796  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_614  1
    load_0_19_4  segment_load_conservation_734  -1
    load_0_19_4  segment_prefix_lb_735  1
    load_0_19_4  segment_prefix_ub_736  1
    load_0_19_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_616  -20
    arc_0_19_5  connected_order_arc_617  -14
    arc_0_19_5  in_degree_738  1
    arc_0_19_5  out_degree_768  1
    arc_0_19_5  original_T_including_depot_unload_796  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_616  1
    load_0_19_5  segment_load_conservation_741  -1
    load_0_19_5  segment_prefix_lb_742  1
    load_0_19_5  segment_prefix_ub_743  1
    load_0_19_5  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_618  -20
    arc_0_19_15  connected_order_arc_619  -14
    arc_0_19_15  in_degree_745  1
    arc_0_19_15  out_degree_768  1
    arc_0_19_15  original_T_including_depot_unload_796  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_618  1
    load_0_19_15  free_load_conservation_749  -1
    load_0_19_15  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_620  -20
    arc_0_19_16  connected_order_arc_621  -14
    arc_0_19_16  in_degree_751  1
    arc_0_19_16  out_degree_768  1
    arc_0_19_16  original_T_including_depot_unload_796  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_620  1
    load_0_19_16  free_load_conservation_755  -1
    load_0_19_16  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_622  -20
    arc_0_19_17  connected_order_arc_623  -14
    arc_0_19_17  in_degree_757  1
    arc_0_19_17  out_degree_768  1
    arc_0_19_17  original_T_including_depot_unload_796  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_622  1
    load_0_19_17  free_load_conservation_761  -1
    load_0_19_17  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_624  -20
    arc_0_19_18  connected_order_arc_625  -14
    arc_0_19_18  in_degree_763  1
    arc_0_19_18  out_degree_768  1
    arc_0_19_18  original_T_including_depot_unload_796  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_624  1
    load_0_19_18  free_load_conservation_767  -1
    load_0_19_18  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_626  -20
    arc_0_19_20  connected_order_arc_627  -14
    arc_0_19_20  out_degree_768  1
    arc_0_19_20  in_degree_775  1
    arc_0_19_20  original_T_including_depot_unload_796  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_626  1
    load_0_19_20  free_load_conservation_773  1
    load_0_19_20  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_628  -20
    arc_0_19_21  connected_order_arc_629  -14
    arc_0_19_21  out_degree_768  1
    arc_0_19_21  in_degree_781  1
    arc_0_19_21  original_T_including_depot_unload_796  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_628  1
    load_0_19_21  free_load_conservation_773  1
    load_0_19_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_22  arc_capacity_630  -20
    arc_0_19_22  connected_order_arc_631  -14
    arc_0_19_22  out_degree_768  1
    arc_0_19_22  in_degree_787  1
    arc_0_19_22  original_T_including_depot_unload_796  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_22  arc_capacity_630  1
    load_0_19_22  free_load_conservation_773  1
    load_0_19_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_632  -20
    arc_0_20_0  depot_return_or_bypass_708  1
    arc_0_20_0  out_degree_774  1
    arc_0_20_0  original_T_including_depot_unload_796  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_632  1
    load_0_20_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_633  -20
    arc_0_20_1  connected_order_arc_634  -14
    arc_0_20_1  in_degree_710  1
    arc_0_20_1  out_degree_774  1
    arc_0_20_1  original_T_including_depot_unload_796  1.4479451378803963e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_633  1
    load_0_20_1  segment_load_conservation_713  -1
    load_0_20_1  segment_prefix_lb_714  1
    load_0_20_1  segment_prefix_ub_715  1
    load_0_20_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_635  -20
    arc_0_20_2  connected_order_arc_636  -14
    arc_0_20_2  in_degree_717  1
    arc_0_20_2  out_degree_774  1
    arc_0_20_2  original_T_including_depot_unload_796  1.2335670980381785e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_635  1
    load_0_20_2  segment_load_conservation_720  -1
    load_0_20_2  segment_prefix_lb_721  1
    load_0_20_2  segment_prefix_ub_722  1
    load_0_20_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_637  -20
    arc_0_20_3  connected_order_arc_638  -14
    arc_0_20_3  in_degree_724  1
    arc_0_20_3  out_degree_774  1
    arc_0_20_3  original_T_including_depot_unload_796  1.4001236472738528e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_637  1
    load_0_20_3  segment_load_conservation_727  -1
    load_0_20_3  segment_prefix_lb_728  1
    load_0_20_3  segment_prefix_ub_729  1
    load_0_20_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_639  -20
    arc_0_20_4  connected_order_arc_640  -14
    arc_0_20_4  in_degree_731  1
    arc_0_20_4  out_degree_774  1
    arc_0_20_4  original_T_including_depot_unload_796  8.0231446125927152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_639  1
    load_0_20_4  segment_load_conservation_734  -1
    load_0_20_4  segment_prefix_lb_735  1
    load_0_20_4  segment_prefix_ub_736  1
    load_0_20_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_641  -20
    arc_0_20_5  connected_order_arc_642  -14
    arc_0_20_5  in_degree_738  1
    arc_0_20_5  out_degree_774  1
    arc_0_20_5  original_T_including_depot_unload_796  7.8724938919046190e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_641  1
    load_0_20_5  segment_load_conservation_741  -1
    load_0_20_5  segment_prefix_lb_742  1
    load_0_20_5  segment_prefix_ub_743  1
    load_0_20_5  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_643  -20
    arc_0_20_15  connected_order_arc_644  -14
    arc_0_20_15  in_degree_745  1
    arc_0_20_15  out_degree_774  1
    arc_0_20_15  original_T_including_depot_unload_796  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_643  1
    load_0_20_15  free_load_conservation_749  -1
    load_0_20_15  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_645  -20
    arc_0_20_16  connected_order_arc_646  -14
    arc_0_20_16  in_degree_751  1
    arc_0_20_16  out_degree_774  1
    arc_0_20_16  original_T_including_depot_unload_796  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_645  1
    load_0_20_16  free_load_conservation_755  -1
    load_0_20_16  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_647  -20
    arc_0_20_17  connected_order_arc_648  -14
    arc_0_20_17  in_degree_757  1
    arc_0_20_17  out_degree_774  1
    arc_0_20_17  original_T_including_depot_unload_796  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_647  1
    load_0_20_17  free_load_conservation_761  -1
    load_0_20_17  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_649  -20
    arc_0_20_18  connected_order_arc_650  -14
    arc_0_20_18  in_degree_763  1
    arc_0_20_18  out_degree_774  1
    arc_0_20_18  original_T_including_depot_unload_796  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_649  1
    load_0_20_18  free_load_conservation_767  -1
    load_0_20_18  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_651  -20
    arc_0_20_19  connected_order_arc_652  -14
    arc_0_20_19  in_degree_769  1
    arc_0_20_19  out_degree_774  1
    arc_0_20_19  original_T_including_depot_unload_796  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_651  1
    load_0_20_19  free_load_conservation_773  -1
    load_0_20_19  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_653  -20
    arc_0_20_21  connected_order_arc_654  -14
    arc_0_20_21  out_degree_774  1
    arc_0_20_21  in_degree_781  1
    arc_0_20_21  original_T_including_depot_unload_796  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_653  1
    load_0_20_21  free_load_conservation_779  1
    load_0_20_21  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_22  arc_capacity_655  -20
    arc_0_20_22  connected_order_arc_656  -14
    arc_0_20_22  out_degree_774  1
    arc_0_20_22  in_degree_787  1
    arc_0_20_22  original_T_including_depot_unload_796  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_22  arc_capacity_655  1
    load_0_20_22  free_load_conservation_779  1
    load_0_20_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_657  -20
    arc_0_21_0  depot_return_or_bypass_708  1
    arc_0_21_0  out_degree_780  1
    arc_0_21_0  original_T_including_depot_unload_796  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_657  1
    load_0_21_0  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_658  -20
    arc_0_21_1  connected_order_arc_659  -14
    arc_0_21_1  in_degree_710  1
    arc_0_21_1  out_degree_780  1
    arc_0_21_1  original_T_including_depot_unload_796  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_658  1
    load_0_21_1  segment_load_conservation_713  -1
    load_0_21_1  segment_prefix_lb_714  1
    load_0_21_1  segment_prefix_ub_715  1
    load_0_21_1  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_660  -20
    arc_0_21_2  connected_order_arc_661  -14
    arc_0_21_2  in_degree_717  1
    arc_0_21_2  out_degree_780  1
    arc_0_21_2  original_T_including_depot_unload_796  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_660  1
    load_0_21_2  segment_load_conservation_720  -1
    load_0_21_2  segment_prefix_lb_721  1
    load_0_21_2  segment_prefix_ub_722  1
    load_0_21_2  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_662  -20
    arc_0_21_3  connected_order_arc_663  -14
    arc_0_21_3  in_degree_724  1
    arc_0_21_3  out_degree_780  1
    arc_0_21_3  original_T_including_depot_unload_796  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_662  1
    load_0_21_3  segment_load_conservation_727  -1
    load_0_21_3  segment_prefix_lb_728  1
    load_0_21_3  segment_prefix_ub_729  1
    load_0_21_3  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_664  -20
    arc_0_21_4  connected_order_arc_665  -14
    arc_0_21_4  in_degree_731  1
    arc_0_21_4  out_degree_780  1
    arc_0_21_4  original_T_including_depot_unload_796  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_664  1
    load_0_21_4  segment_load_conservation_734  -1
    load_0_21_4  segment_prefix_lb_735  1
    load_0_21_4  segment_prefix_ub_736  1
    load_0_21_4  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_5  arc_capacity_666  -20
    arc_0_21_5  connected_order_arc_667  -14
    arc_0_21_5  in_degree_738  1
    arc_0_21_5  out_degree_780  1
    arc_0_21_5  original_T_including_depot_unload_796  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_5  arc_capacity_666  1
    load_0_21_5  segment_load_conservation_741  -1
    load_0_21_5  segment_prefix_lb_742  1
    load_0_21_5  segment_prefix_ub_743  1
    load_0_21_5  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_668  -20
    arc_0_21_15  connected_order_arc_669  -14
    arc_0_21_15  in_degree_745  1
    arc_0_21_15  out_degree_780  1
    arc_0_21_15  original_T_including_depot_unload_796  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_668  1
    load_0_21_15  free_load_conservation_749  -1
    load_0_21_15  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_670  -20
    arc_0_21_16  connected_order_arc_671  -14
    arc_0_21_16  in_degree_751  1
    arc_0_21_16  out_degree_780  1
    arc_0_21_16  original_T_including_depot_unload_796  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_670  1
    load_0_21_16  free_load_conservation_755  -1
    load_0_21_16  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_672  -20
    arc_0_21_17  connected_order_arc_673  -14
    arc_0_21_17  in_degree_757  1
    arc_0_21_17  out_degree_780  1
    arc_0_21_17  original_T_including_depot_unload_796  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_672  1
    load_0_21_17  free_load_conservation_761  -1
    load_0_21_17  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_674  -20
    arc_0_21_18  connected_order_arc_675  -14
    arc_0_21_18  in_degree_763  1
    arc_0_21_18  out_degree_780  1
    arc_0_21_18  original_T_including_depot_unload_796  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_674  1
    load_0_21_18  free_load_conservation_767  -1
    load_0_21_18  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_676  -20
    arc_0_21_19  connected_order_arc_677  -14
    arc_0_21_19  in_degree_769  1
    arc_0_21_19  out_degree_780  1
    arc_0_21_19  original_T_including_depot_unload_796  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_676  1
    load_0_21_19  free_load_conservation_773  -1
    load_0_21_19  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_678  -20
    arc_0_21_20  connected_order_arc_679  -14
    arc_0_21_20  in_degree_775  1
    arc_0_21_20  out_degree_780  1
    arc_0_21_20  original_T_including_depot_unload_796  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_678  1
    load_0_21_20  free_load_conservation_779  -1
    load_0_21_20  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_22  arc_capacity_680  -20
    arc_0_21_22  connected_order_arc_681  -14
    arc_0_21_22  out_degree_780  1
    arc_0_21_22  in_degree_787  1
    arc_0_21_22  original_T_including_depot_unload_796  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_22  arc_capacity_680  1
    load_0_21_22  free_load_conservation_785  1
    load_0_21_22  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_0  arc_capacity_682  -20
    arc_0_22_0  depot_return_or_bypass_708  1
    arc_0_22_0  out_degree_786  1
    arc_0_22_0  original_T_including_depot_unload_796  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_0  arc_capacity_682  1
    load_0_22_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_1  arc_capacity_683  -20
    arc_0_22_1  connected_order_arc_684  -14
    arc_0_22_1  in_degree_710  1
    arc_0_22_1  out_degree_786  1
    arc_0_22_1  original_T_including_depot_unload_796  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_1  arc_capacity_683  1
    load_0_22_1  segment_load_conservation_713  -1
    load_0_22_1  segment_prefix_lb_714  1
    load_0_22_1  segment_prefix_ub_715  1
    load_0_22_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_2  arc_capacity_685  -20
    arc_0_22_2  connected_order_arc_686  -14
    arc_0_22_2  in_degree_717  1
    arc_0_22_2  out_degree_786  1
    arc_0_22_2  original_T_including_depot_unload_796  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_2  arc_capacity_685  1
    load_0_22_2  segment_load_conservation_720  -1
    load_0_22_2  segment_prefix_lb_721  1
    load_0_22_2  segment_prefix_ub_722  1
    load_0_22_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_3  arc_capacity_687  -20
    arc_0_22_3  connected_order_arc_688  -14
    arc_0_22_3  in_degree_724  1
    arc_0_22_3  out_degree_786  1
    arc_0_22_3  original_T_including_depot_unload_796  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_3  arc_capacity_687  1
    load_0_22_3  segment_load_conservation_727  -1
    load_0_22_3  segment_prefix_lb_728  1
    load_0_22_3  segment_prefix_ub_729  1
    load_0_22_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_4  arc_capacity_689  -20
    arc_0_22_4  connected_order_arc_690  -14
    arc_0_22_4  in_degree_731  1
    arc_0_22_4  out_degree_786  1
    arc_0_22_4  original_T_including_depot_unload_796  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_4  arc_capacity_689  1
    load_0_22_4  segment_load_conservation_734  -1
    load_0_22_4  segment_prefix_lb_735  1
    load_0_22_4  segment_prefix_ub_736  1
    load_0_22_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_5  arc_capacity_691  -20
    arc_0_22_5  connected_order_arc_692  -14
    arc_0_22_5  in_degree_738  1
    arc_0_22_5  out_degree_786  1
    arc_0_22_5  original_T_including_depot_unload_796  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_5  arc_capacity_691  1
    load_0_22_5  segment_load_conservation_741  -1
    load_0_22_5  segment_prefix_lb_742  1
    load_0_22_5  segment_prefix_ub_743  1
    load_0_22_5  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_15  arc_capacity_693  -20
    arc_0_22_15  connected_order_arc_694  -14
    arc_0_22_15  in_degree_745  1
    arc_0_22_15  out_degree_786  1
    arc_0_22_15  original_T_including_depot_unload_796  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_15  arc_capacity_693  1
    load_0_22_15  free_load_conservation_749  -1
    load_0_22_15  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_16  arc_capacity_695  -20
    arc_0_22_16  connected_order_arc_696  -14
    arc_0_22_16  in_degree_751  1
    arc_0_22_16  out_degree_786  1
    arc_0_22_16  original_T_including_depot_unload_796  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_16  arc_capacity_695  1
    load_0_22_16  free_load_conservation_755  -1
    load_0_22_16  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_17  arc_capacity_697  -20
    arc_0_22_17  connected_order_arc_698  -14
    arc_0_22_17  in_degree_757  1
    arc_0_22_17  out_degree_786  1
    arc_0_22_17  original_T_including_depot_unload_796  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_22_17  arc_capacity_697  1
    load_0_22_17  free_load_conservation_761  -1
    load_0_22_17  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_18  arc_capacity_699  -20
    arc_0_22_18  connected_order_arc_700  -14
    arc_0_22_18  in_degree_763  1
    arc_0_22_18  out_degree_786  1
    arc_0_22_18  original_T_including_depot_unload_796  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_18  arc_capacity_699  1
    load_0_22_18  free_load_conservation_767  -1
    load_0_22_18  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_19  arc_capacity_701  -20
    arc_0_22_19  connected_order_arc_702  -14
    arc_0_22_19  in_degree_769  1
    arc_0_22_19  out_degree_786  1
    arc_0_22_19  original_T_including_depot_unload_796  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_19  arc_capacity_701  1
    load_0_22_19  free_load_conservation_773  -1
    load_0_22_19  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_20  arc_capacity_703  -20
    arc_0_22_20  connected_order_arc_704  -14
    arc_0_22_20  in_degree_775  1
    arc_0_22_20  out_degree_786  1
    arc_0_22_20  original_T_including_depot_unload_796  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_20  arc_capacity_703  1
    load_0_22_20  free_load_conservation_779  -1
    load_0_22_20  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_22_21  arc_capacity_705  -20
    arc_0_22_21  connected_order_arc_706  -14
    arc_0_22_21  in_degree_781  1
    arc_0_22_21  out_degree_786  1
    arc_0_22_21  original_T_including_depot_unload_796  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_22_21  arc_capacity_705  1
    load_0_22_21  free_load_conservation_785  -1
    load_0_22_21  free_load_conservation_791  1
    visit_1_6  out_degree_1088  -1
    visit_1_6  in_degree_1089  -1
    visit_1_6  order_active_lb_1090  -1
    visit_1_6  order_active_ub_1091  -12
    order_1_6  connected_order_arc_812  -1
    order_1_6  connected_order_arc_814  -1
    order_1_6  connected_order_arc_816  -1
    order_1_6  connected_order_arc_818  -1
    order_1_6  connected_order_arc_820  -1
    order_1_6  connected_order_arc_822  -1
    order_1_6  connected_order_arc_824  -1
    order_1_6  connected_order_arc_826  -1
    order_1_6  connected_order_arc_828  -1
    order_1_6  connected_order_arc_830  -1
    order_1_6  connected_order_arc_832  -1
    order_1_6  connected_order_arc_835  1
    order_1_6  connected_order_arc_858  1
    order_1_6  connected_order_arc_881  1
    order_1_6  connected_order_arc_904  1
    order_1_6  connected_order_arc_927  1
    order_1_6  connected_order_arc_950  1
    order_1_6  connected_order_arc_973  1
    order_1_6  connected_order_arc_996  1
    order_1_6  connected_order_arc_1019  1
    order_1_6  connected_order_arc_1042  1
    order_1_6  connected_order_arc_1065  1
    order_1_6  order_active_lb_1090  1
    order_1_6  order_active_ub_1091  1
    order_1_6  fixed_segment_relative_order_1164  -1
    visit_1_7  out_degree_1095  -1
    visit_1_7  in_degree_1096  -1
    visit_1_7  order_active_lb_1097  -1
    visit_1_7  order_active_ub_1098  -12
    order_1_7  connected_order_arc_812  1
    order_1_7  connected_order_arc_835  -1
    order_1_7  connected_order_arc_837  -1
    order_1_7  connected_order_arc_839  -1
    order_1_7  connected_order_arc_841  -1
    order_1_7  connected_order_arc_843  -1
    order_1_7  connected_order_arc_845  -1
    order_1_7  connected_order_arc_847  -1
    order_1_7  connected_order_arc_849  -1
    order_1_7  connected_order_arc_851  -1
    order_1_7  connected_order_arc_853  -1
    order_1_7  connected_order_arc_855  -1
    order_1_7  connected_order_arc_860  1
    order_1_7  connected_order_arc_883  1
    order_1_7  connected_order_arc_906  1
    order_1_7  connected_order_arc_929  1
    order_1_7  connected_order_arc_952  1
    order_1_7  connected_order_arc_975  1
    order_1_7  connected_order_arc_998  1
    order_1_7  connected_order_arc_1021  1
    order_1_7  connected_order_arc_1044  1
    order_1_7  connected_order_arc_1067  1
    order_1_7  order_active_lb_1097  1
    order_1_7  order_active_ub_1098  1
    order_1_7  fixed_segment_relative_order_1164  1
    order_1_7  fixed_segment_relative_order_1165  -1
    visit_1_8  out_degree_1102  -1
    visit_1_8  in_degree_1103  -1
    visit_1_8  order_active_lb_1104  -1
    visit_1_8  order_active_ub_1105  -12
    order_1_8  connected_order_arc_814  1
    order_1_8  connected_order_arc_837  1
    order_1_8  connected_order_arc_858  -1
    order_1_8  connected_order_arc_860  -1
    order_1_8  connected_order_arc_862  -1
    order_1_8  connected_order_arc_864  -1
    order_1_8  connected_order_arc_866  -1
    order_1_8  connected_order_arc_868  -1
    order_1_8  connected_order_arc_870  -1
    order_1_8  connected_order_arc_872  -1
    order_1_8  connected_order_arc_874  -1
    order_1_8  connected_order_arc_876  -1
    order_1_8  connected_order_arc_878  -1
    order_1_8  connected_order_arc_885  1
    order_1_8  connected_order_arc_908  1
    order_1_8  connected_order_arc_931  1
    order_1_8  connected_order_arc_954  1
    order_1_8  connected_order_arc_977  1
    order_1_8  connected_order_arc_1000  1
    order_1_8  connected_order_arc_1023  1
    order_1_8  connected_order_arc_1046  1
    order_1_8  connected_order_arc_1069  1
    order_1_8  order_active_lb_1104  1
    order_1_8  order_active_ub_1105  1
    order_1_8  fixed_segment_relative_order_1165  1
    order_1_8  fixed_segment_relative_order_1166  -1
    visit_1_9  out_degree_1109  -1
    visit_1_9  in_degree_1110  -1
    visit_1_9  order_active_lb_1111  -1
    visit_1_9  order_active_ub_1112  -12
    order_1_9  connected_order_arc_816  1
    order_1_9  connected_order_arc_839  1
    order_1_9  connected_order_arc_862  1
    order_1_9  connected_order_arc_881  -1
    order_1_9  connected_order_arc_883  -1
    order_1_9  connected_order_arc_885  -1
    order_1_9  connected_order_arc_887  -1
    order_1_9  connected_order_arc_889  -1
    order_1_9  connected_order_arc_891  -1
    order_1_9  connected_order_arc_893  -1
    order_1_9  connected_order_arc_895  -1
    order_1_9  connected_order_arc_897  -1
    order_1_9  connected_order_arc_899  -1
    order_1_9  connected_order_arc_901  -1
    order_1_9  connected_order_arc_910  1
    order_1_9  connected_order_arc_933  1
    order_1_9  connected_order_arc_956  1
    order_1_9  connected_order_arc_979  1
    order_1_9  connected_order_arc_1002  1
    order_1_9  connected_order_arc_1025  1
    order_1_9  connected_order_arc_1048  1
    order_1_9  connected_order_arc_1071  1
    order_1_9  order_active_lb_1111  1
    order_1_9  order_active_ub_1112  1
    order_1_9  fixed_segment_relative_order_1166  1
    visit_1_15  out_degree_1116  -1
    visit_1_15  in_degree_1117  -1
    visit_1_15  order_active_lb_1118  -1
    visit_1_15  order_active_ub_1119  -12
    visit_1_15  service_visit_def_1120  -1
    order_1_15  connected_order_arc_818  1
    order_1_15  connected_order_arc_841  1
    order_1_15  connected_order_arc_864  1
    order_1_15  connected_order_arc_887  1
    order_1_15  connected_order_arc_904  -1
    order_1_15  connected_order_arc_906  -1
    order_1_15  connected_order_arc_908  -1
    order_1_15  connected_order_arc_910  -1
    order_1_15  connected_order_arc_912  -1
    order_1_15  connected_order_arc_914  -1
    order_1_15  connected_order_arc_916  -1
    order_1_15  connected_order_arc_918  -1
    order_1_15  connected_order_arc_920  -1
    order_1_15  connected_order_arc_922  -1
    order_1_15  connected_order_arc_924  -1
    order_1_15  connected_order_arc_935  1
    order_1_15  connected_order_arc_958  1
    order_1_15  connected_order_arc_981  1
    order_1_15  connected_order_arc_1004  1
    order_1_15  connected_order_arc_1027  1
    order_1_15  connected_order_arc_1050  1
    order_1_15  connected_order_arc_1073  1
    order_1_15  order_active_lb_1118  1
    order_1_15  order_active_ub_1119  1
    visit_1_16  out_degree_1122  -1
    visit_1_16  in_degree_1123  -1
    visit_1_16  order_active_lb_1124  -1
    visit_1_16  order_active_ub_1125  -12
    visit_1_16  service_visit_def_1126  -1
    order_1_16  connected_order_arc_820  1
    order_1_16  connected_order_arc_843  1
    order_1_16  connected_order_arc_866  1
    order_1_16  connected_order_arc_889  1
    order_1_16  connected_order_arc_912  1
    order_1_16  connected_order_arc_927  -1
    order_1_16  connected_order_arc_929  -1
    order_1_16  connected_order_arc_931  -1
    order_1_16  connected_order_arc_933  -1
    order_1_16  connected_order_arc_935  -1
    order_1_16  connected_order_arc_937  -1
    order_1_16  connected_order_arc_939  -1
    order_1_16  connected_order_arc_941  -1
    order_1_16  connected_order_arc_943  -1
    order_1_16  connected_order_arc_945  -1
    order_1_16  connected_order_arc_947  -1
    order_1_16  connected_order_arc_960  1
    order_1_16  connected_order_arc_983  1
    order_1_16  connected_order_arc_1006  1
    order_1_16  connected_order_arc_1029  1
    order_1_16  connected_order_arc_1052  1
    order_1_16  connected_order_arc_1075  1
    order_1_16  order_active_lb_1124  1
    order_1_16  order_active_ub_1125  1
    visit_1_17  out_degree_1128  -1
    visit_1_17  in_degree_1129  -1
    visit_1_17  order_active_lb_1130  -1
    visit_1_17  order_active_ub_1131  -12
    visit_1_17  service_visit_def_1132  -1
    order_1_17  connected_order_arc_822  1
    order_1_17  connected_order_arc_845  1
    order_1_17  connected_order_arc_868  1
    order_1_17  connected_order_arc_891  1
    order_1_17  connected_order_arc_914  1
    order_1_17  connected_order_arc_937  1
    order_1_17  connected_order_arc_950  -1
    order_1_17  connected_order_arc_952  -1
    order_1_17  connected_order_arc_954  -1
    order_1_17  connected_order_arc_956  -1
    order_1_17  connected_order_arc_958  -1
    order_1_17  connected_order_arc_960  -1
    order_1_17  connected_order_arc_962  -1
    order_1_17  connected_order_arc_964  -1
    order_1_17  connected_order_arc_966  -1
    order_1_17  connected_order_arc_968  -1
    order_1_17  connected_order_arc_970  -1
    order_1_17  connected_order_arc_985  1
    order_1_17  connected_order_arc_1008  1
    order_1_17  connected_order_arc_1031  1
    order_1_17  connected_order_arc_1054  1
    order_1_17  connected_order_arc_1077  1
    order_1_17  order_active_lb_1130  1
    order_1_17  order_active_ub_1131  1
    visit_1_18  out_degree_1134  -1
    visit_1_18  in_degree_1135  -1
    visit_1_18  order_active_lb_1136  -1
    visit_1_18  order_active_ub_1137  -12
    visit_1_18  service_visit_def_1138  -1
    order_1_18  connected_order_arc_824  1
    order_1_18  connected_order_arc_847  1
    order_1_18  connected_order_arc_870  1
    order_1_18  connected_order_arc_893  1
    order_1_18  connected_order_arc_916  1
    order_1_18  connected_order_arc_939  1
    order_1_18  connected_order_arc_962  1
    order_1_18  connected_order_arc_973  -1
    order_1_18  connected_order_arc_975  -1
    order_1_18  connected_order_arc_977  -1
    order_1_18  connected_order_arc_979  -1
    order_1_18  connected_order_arc_981  -1
    order_1_18  connected_order_arc_983  -1
    order_1_18  connected_order_arc_985  -1
    order_1_18  connected_order_arc_987  -1
    order_1_18  connected_order_arc_989  -1
    order_1_18  connected_order_arc_991  -1
    order_1_18  connected_order_arc_993  -1
    order_1_18  connected_order_arc_1010  1
    order_1_18  connected_order_arc_1033  1
    order_1_18  connected_order_arc_1056  1
    order_1_18  connected_order_arc_1079  1
    order_1_18  order_active_lb_1136  1
    order_1_18  order_active_ub_1137  1
    visit_1_19  out_degree_1140  -1
    visit_1_19  in_degree_1141  -1
    visit_1_19  order_active_lb_1142  -1
    visit_1_19  order_active_ub_1143  -12
    visit_1_19  service_visit_def_1144  -1
    order_1_19  connected_order_arc_826  1
    order_1_19  connected_order_arc_849  1
    order_1_19  connected_order_arc_872  1
    order_1_19  connected_order_arc_895  1
    order_1_19  connected_order_arc_918  1
    order_1_19  connected_order_arc_941  1
    order_1_19  connected_order_arc_964  1
    order_1_19  connected_order_arc_987  1
    order_1_19  connected_order_arc_996  -1
    order_1_19  connected_order_arc_998  -1
    order_1_19  connected_order_arc_1000  -1
    order_1_19  connected_order_arc_1002  -1
    order_1_19  connected_order_arc_1004  -1
    order_1_19  connected_order_arc_1006  -1
    order_1_19  connected_order_arc_1008  -1
    order_1_19  connected_order_arc_1010  -1
    order_1_19  connected_order_arc_1012  -1
    order_1_19  connected_order_arc_1014  -1
    order_1_19  connected_order_arc_1016  -1
    order_1_19  connected_order_arc_1035  1
    order_1_19  connected_order_arc_1058  1
    order_1_19  connected_order_arc_1081  1
    order_1_19  order_active_lb_1142  1
    order_1_19  order_active_ub_1143  1
    visit_1_20  out_degree_1146  -1
    visit_1_20  in_degree_1147  -1
    visit_1_20  order_active_lb_1148  -1
    visit_1_20  order_active_ub_1149  -12
    visit_1_20  service_visit_def_1150  -1
    order_1_20  connected_order_arc_828  1
    order_1_20  connected_order_arc_851  1
    order_1_20  connected_order_arc_874  1
    order_1_20  connected_order_arc_897  1
    order_1_20  connected_order_arc_920  1
    order_1_20  connected_order_arc_943  1
    order_1_20  connected_order_arc_966  1
    order_1_20  connected_order_arc_989  1
    order_1_20  connected_order_arc_1012  1
    order_1_20  connected_order_arc_1019  -1
    order_1_20  connected_order_arc_1021  -1
    order_1_20  connected_order_arc_1023  -1
    order_1_20  connected_order_arc_1025  -1
    order_1_20  connected_order_arc_1027  -1
    order_1_20  connected_order_arc_1029  -1
    order_1_20  connected_order_arc_1031  -1
    order_1_20  connected_order_arc_1033  -1
    order_1_20  connected_order_arc_1035  -1
    order_1_20  connected_order_arc_1037  -1
    order_1_20  connected_order_arc_1039  -1
    order_1_20  connected_order_arc_1060  1
    order_1_20  connected_order_arc_1083  1
    order_1_20  order_active_lb_1148  1
    order_1_20  order_active_ub_1149  1
    visit_1_21  out_degree_1152  -1
    visit_1_21  in_degree_1153  -1
    visit_1_21  order_active_lb_1154  -1
    visit_1_21  order_active_ub_1155  -12
    visit_1_21  service_visit_def_1156  -1
    order_1_21  connected_order_arc_830  1
    order_1_21  connected_order_arc_853  1
    order_1_21  connected_order_arc_876  1
    order_1_21  connected_order_arc_899  1
    order_1_21  connected_order_arc_922  1
    order_1_21  connected_order_arc_945  1
    order_1_21  connected_order_arc_968  1
    order_1_21  connected_order_arc_991  1
    order_1_21  connected_order_arc_1014  1
    order_1_21  connected_order_arc_1037  1
    order_1_21  connected_order_arc_1042  -1
    order_1_21  connected_order_arc_1044  -1
    order_1_21  connected_order_arc_1046  -1
    order_1_21  connected_order_arc_1048  -1
    order_1_21  connected_order_arc_1050  -1
    order_1_21  connected_order_arc_1052  -1
    order_1_21  connected_order_arc_1054  -1
    order_1_21  connected_order_arc_1056  -1
    order_1_21  connected_order_arc_1058  -1
    order_1_21  connected_order_arc_1060  -1
    order_1_21  connected_order_arc_1062  -1
    order_1_21  connected_order_arc_1085  1
    order_1_21  order_active_lb_1154  1
    order_1_21  order_active_ub_1155  1
    visit_1_22  out_degree_1158  -1
    visit_1_22  in_degree_1159  -1
    visit_1_22  order_active_lb_1160  -1
    visit_1_22  order_active_ub_1161  -12
    visit_1_22  service_visit_def_1162  -1
    order_1_22  connected_order_arc_832  1
    order_1_22  connected_order_arc_855  1
    order_1_22  connected_order_arc_878  1
    order_1_22  connected_order_arc_901  1
    order_1_22  connected_order_arc_924  1
    order_1_22  connected_order_arc_947  1
    order_1_22  connected_order_arc_970  1
    order_1_22  connected_order_arc_993  1
    order_1_22  connected_order_arc_1016  1
    order_1_22  connected_order_arc_1039  1
    order_1_22  connected_order_arc_1062  1
    order_1_22  connected_order_arc_1065  -1
    order_1_22  connected_order_arc_1067  -1
    order_1_22  connected_order_arc_1069  -1
    order_1_22  connected_order_arc_1071  -1
    order_1_22  connected_order_arc_1073  -1
    order_1_22  connected_order_arc_1075  -1
    order_1_22  connected_order_arc_1077  -1
    order_1_22  connected_order_arc_1079  -1
    order_1_22  connected_order_arc_1081  -1
    order_1_22  connected_order_arc_1083  -1
    order_1_22  connected_order_arc_1085  -1
    order_1_22  order_active_lb_1160  1
    order_1_22  order_active_ub_1161  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_797  -25
    arc_1_0_0  depot_departure_or_bypass_1086  1
    arc_1_0_0  depot_return_or_bypass_1087  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_798  -25
    arc_1_0_6  depot_departure_or_bypass_1086  1
    arc_1_0_6  in_degree_1089  1
    arc_1_0_6  original_T_including_depot_unload_1167  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_798  1
    load_1_0_6  segment_load_conservation_1092  -1
    load_1_0_6  segment_prefix_lb_1093  1
    load_1_0_6  segment_prefix_ub_1094  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_799  -25
    arc_1_0_7  depot_departure_or_bypass_1086  1
    arc_1_0_7  in_degree_1096  1
    arc_1_0_7  original_T_including_depot_unload_1167  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_799  1
    load_1_0_7  segment_load_conservation_1099  -1
    load_1_0_7  segment_prefix_lb_1100  1
    load_1_0_7  segment_prefix_ub_1101  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_800  -25
    arc_1_0_8  depot_departure_or_bypass_1086  1
    arc_1_0_8  in_degree_1103  1
    arc_1_0_8  original_T_including_depot_unload_1167  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_800  1
    load_1_0_8  segment_load_conservation_1106  -1
    load_1_0_8  segment_prefix_lb_1107  1
    load_1_0_8  segment_prefix_ub_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_801  -25
    arc_1_0_9  depot_departure_or_bypass_1086  1
    arc_1_0_9  in_degree_1110  1
    arc_1_0_9  original_T_including_depot_unload_1167  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_801  1
    load_1_0_9  segment_load_conservation_1113  -1
    load_1_0_9  segment_prefix_lb_1114  1
    load_1_0_9  segment_prefix_ub_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_802  -25
    arc_1_0_15  depot_departure_or_bypass_1086  1
    arc_1_0_15  in_degree_1117  1
    arc_1_0_15  original_T_including_depot_unload_1167  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_802  1
    load_1_0_15  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_803  -25
    arc_1_0_16  depot_departure_or_bypass_1086  1
    arc_1_0_16  in_degree_1123  1
    arc_1_0_16  original_T_including_depot_unload_1167  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_803  1
    load_1_0_16  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_804  -25
    arc_1_0_17  depot_departure_or_bypass_1086  1
    arc_1_0_17  in_degree_1129  1
    arc_1_0_17  original_T_including_depot_unload_1167  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_804  1
    load_1_0_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_805  -25
    arc_1_0_18  depot_departure_or_bypass_1086  1
    arc_1_0_18  in_degree_1135  1
    arc_1_0_18  original_T_including_depot_unload_1167  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_805  1
    load_1_0_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_806  -25
    arc_1_0_19  depot_departure_or_bypass_1086  1
    arc_1_0_19  in_degree_1141  1
    arc_1_0_19  original_T_including_depot_unload_1167  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_806  1
    load_1_0_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_807  -25
    arc_1_0_20  depot_departure_or_bypass_1086  1
    arc_1_0_20  in_degree_1147  1
    arc_1_0_20  original_T_including_depot_unload_1167  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_807  1
    load_1_0_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_808  -25
    arc_1_0_21  depot_departure_or_bypass_1086  1
    arc_1_0_21  in_degree_1153  1
    arc_1_0_21  original_T_including_depot_unload_1167  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_808  1
    load_1_0_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_22  arc_capacity_809  -25
    arc_1_0_22  depot_departure_or_bypass_1086  1
    arc_1_0_22  in_degree_1159  1
    arc_1_0_22  original_T_including_depot_unload_1167  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_22  arc_capacity_809  1
    load_1_0_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_810  -25
    arc_1_6_0  depot_return_or_bypass_1087  1
    arc_1_6_0  out_degree_1088  1
    arc_1_6_0  original_T_including_depot_unload_1167  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_810  1
    load_1_6_0  segment_load_conservation_1092  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_811  -25
    arc_1_6_7  connected_order_arc_812  -13
    arc_1_6_7  out_degree_1088  1
    arc_1_6_7  in_degree_1096  1
    arc_1_6_7  original_T_including_depot_unload_1167  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_811  1
    load_1_6_7  segment_load_conservation_1092  1
    load_1_6_7  segment_load_conservation_1099  -1
    load_1_6_7  segment_prefix_lb_1100  1
    load_1_6_7  segment_prefix_ub_1101  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_813  -25
    arc_1_6_8  connected_order_arc_814  -13
    arc_1_6_8  out_degree_1088  1
    arc_1_6_8  in_degree_1103  1
    arc_1_6_8  original_T_including_depot_unload_1167  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_813  1
    load_1_6_8  segment_load_conservation_1092  1
    load_1_6_8  segment_load_conservation_1106  -1
    load_1_6_8  segment_prefix_lb_1107  1
    load_1_6_8  segment_prefix_ub_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_815  -25
    arc_1_6_9  connected_order_arc_816  -13
    arc_1_6_9  out_degree_1088  1
    arc_1_6_9  in_degree_1110  1
    arc_1_6_9  original_T_including_depot_unload_1167  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_815  1
    load_1_6_9  segment_load_conservation_1092  1
    load_1_6_9  segment_load_conservation_1113  -1
    load_1_6_9  segment_prefix_lb_1114  1
    load_1_6_9  segment_prefix_ub_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_817  -25
    arc_1_6_15  connected_order_arc_818  -13
    arc_1_6_15  out_degree_1088  1
    arc_1_6_15  in_degree_1117  1
    arc_1_6_15  original_T_including_depot_unload_1167  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_817  1
    load_1_6_15  segment_load_conservation_1092  1
    load_1_6_15  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_819  -25
    arc_1_6_16  connected_order_arc_820  -13
    arc_1_6_16  out_degree_1088  1
    arc_1_6_16  in_degree_1123  1
    arc_1_6_16  original_T_including_depot_unload_1167  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_819  1
    load_1_6_16  segment_load_conservation_1092  1
    load_1_6_16  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_821  -25
    arc_1_6_17  connected_order_arc_822  -13
    arc_1_6_17  out_degree_1088  1
    arc_1_6_17  in_degree_1129  1
    arc_1_6_17  original_T_including_depot_unload_1167  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_821  1
    load_1_6_17  segment_load_conservation_1092  1
    load_1_6_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_823  -25
    arc_1_6_18  connected_order_arc_824  -13
    arc_1_6_18  out_degree_1088  1
    arc_1_6_18  in_degree_1135  1
    arc_1_6_18  original_T_including_depot_unload_1167  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_823  1
    load_1_6_18  segment_load_conservation_1092  1
    load_1_6_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_825  -25
    arc_1_6_19  connected_order_arc_826  -13
    arc_1_6_19  out_degree_1088  1
    arc_1_6_19  in_degree_1141  1
    arc_1_6_19  original_T_including_depot_unload_1167  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_825  1
    load_1_6_19  segment_load_conservation_1092  1
    load_1_6_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_827  -25
    arc_1_6_20  connected_order_arc_828  -13
    arc_1_6_20  out_degree_1088  1
    arc_1_6_20  in_degree_1147  1
    arc_1_6_20  original_T_including_depot_unload_1167  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_827  1
    load_1_6_20  segment_load_conservation_1092  1
    load_1_6_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_829  -25
    arc_1_6_21  connected_order_arc_830  -13
    arc_1_6_21  out_degree_1088  1
    arc_1_6_21  in_degree_1153  1
    arc_1_6_21  original_T_including_depot_unload_1167  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_829  1
    load_1_6_21  segment_load_conservation_1092  1
    load_1_6_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_22  arc_capacity_831  -25
    arc_1_6_22  connected_order_arc_832  -13
    arc_1_6_22  out_degree_1088  1
    arc_1_6_22  in_degree_1159  1
    arc_1_6_22  original_T_including_depot_unload_1167  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_22  arc_capacity_831  1
    load_1_6_22  segment_load_conservation_1092  1
    load_1_6_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_833  -25
    arc_1_7_0  depot_return_or_bypass_1087  1
    arc_1_7_0  out_degree_1095  1
    arc_1_7_0  original_T_including_depot_unload_1167  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_833  1
    load_1_7_0  segment_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_834  -25
    arc_1_7_6  connected_order_arc_835  -13
    arc_1_7_6  in_degree_1089  1
    arc_1_7_6  out_degree_1095  1
    arc_1_7_6  original_T_including_depot_unload_1167  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_834  1
    load_1_7_6  segment_load_conservation_1092  -1
    load_1_7_6  segment_prefix_lb_1093  1
    load_1_7_6  segment_prefix_ub_1094  1
    load_1_7_6  segment_load_conservation_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_836  -25
    arc_1_7_8  connected_order_arc_837  -13
    arc_1_7_8  out_degree_1095  1
    arc_1_7_8  in_degree_1103  1
    arc_1_7_8  original_T_including_depot_unload_1167  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_836  1
    load_1_7_8  segment_load_conservation_1099  1
    load_1_7_8  segment_load_conservation_1106  -1
    load_1_7_8  segment_prefix_lb_1107  1
    load_1_7_8  segment_prefix_ub_1108  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_838  -25
    arc_1_7_9  connected_order_arc_839  -13
    arc_1_7_9  out_degree_1095  1
    arc_1_7_9  in_degree_1110  1
    arc_1_7_9  original_T_including_depot_unload_1167  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_838  1
    load_1_7_9  segment_load_conservation_1099  1
    load_1_7_9  segment_load_conservation_1113  -1
    load_1_7_9  segment_prefix_lb_1114  1
    load_1_7_9  segment_prefix_ub_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_840  -25
    arc_1_7_15  connected_order_arc_841  -13
    arc_1_7_15  out_degree_1095  1
    arc_1_7_15  in_degree_1117  1
    arc_1_7_15  original_T_including_depot_unload_1167  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_840  1
    load_1_7_15  segment_load_conservation_1099  1
    load_1_7_15  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_842  -25
    arc_1_7_16  connected_order_arc_843  -13
    arc_1_7_16  out_degree_1095  1
    arc_1_7_16  in_degree_1123  1
    arc_1_7_16  original_T_including_depot_unload_1167  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_842  1
    load_1_7_16  segment_load_conservation_1099  1
    load_1_7_16  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_844  -25
    arc_1_7_17  connected_order_arc_845  -13
    arc_1_7_17  out_degree_1095  1
    arc_1_7_17  in_degree_1129  1
    arc_1_7_17  original_T_including_depot_unload_1167  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_844  1
    load_1_7_17  segment_load_conservation_1099  1
    load_1_7_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_846  -25
    arc_1_7_18  connected_order_arc_847  -13
    arc_1_7_18  out_degree_1095  1
    arc_1_7_18  in_degree_1135  1
    arc_1_7_18  original_T_including_depot_unload_1167  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_846  1
    load_1_7_18  segment_load_conservation_1099  1
    load_1_7_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_848  -25
    arc_1_7_19  connected_order_arc_849  -13
    arc_1_7_19  out_degree_1095  1
    arc_1_7_19  in_degree_1141  1
    arc_1_7_19  original_T_including_depot_unload_1167  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_848  1
    load_1_7_19  segment_load_conservation_1099  1
    load_1_7_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_850  -25
    arc_1_7_20  connected_order_arc_851  -13
    arc_1_7_20  out_degree_1095  1
    arc_1_7_20  in_degree_1147  1
    arc_1_7_20  original_T_including_depot_unload_1167  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_850  1
    load_1_7_20  segment_load_conservation_1099  1
    load_1_7_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_852  -25
    arc_1_7_21  connected_order_arc_853  -13
    arc_1_7_21  out_degree_1095  1
    arc_1_7_21  in_degree_1153  1
    arc_1_7_21  original_T_including_depot_unload_1167  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_852  1
    load_1_7_21  segment_load_conservation_1099  1
    load_1_7_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_22  arc_capacity_854  -25
    arc_1_7_22  connected_order_arc_855  -13
    arc_1_7_22  out_degree_1095  1
    arc_1_7_22  in_degree_1159  1
    arc_1_7_22  original_T_including_depot_unload_1167  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_22  arc_capacity_854  1
    load_1_7_22  segment_load_conservation_1099  1
    load_1_7_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_856  -25
    arc_1_8_0  depot_return_or_bypass_1087  1
    arc_1_8_0  out_degree_1102  1
    arc_1_8_0  original_T_including_depot_unload_1167  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_856  1
    load_1_8_0  segment_load_conservation_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_857  -25
    arc_1_8_6  connected_order_arc_858  -13
    arc_1_8_6  in_degree_1089  1
    arc_1_8_6  out_degree_1102  1
    arc_1_8_6  original_T_including_depot_unload_1167  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_857  1
    load_1_8_6  segment_load_conservation_1092  -1
    load_1_8_6  segment_prefix_lb_1093  1
    load_1_8_6  segment_prefix_ub_1094  1
    load_1_8_6  segment_load_conservation_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_859  -25
    arc_1_8_7  connected_order_arc_860  -13
    arc_1_8_7  in_degree_1096  1
    arc_1_8_7  out_degree_1102  1
    arc_1_8_7  original_T_including_depot_unload_1167  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_859  1
    load_1_8_7  segment_load_conservation_1099  -1
    load_1_8_7  segment_prefix_lb_1100  1
    load_1_8_7  segment_prefix_ub_1101  1
    load_1_8_7  segment_load_conservation_1106  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_861  -25
    arc_1_8_9  connected_order_arc_862  -13
    arc_1_8_9  out_degree_1102  1
    arc_1_8_9  in_degree_1110  1
    arc_1_8_9  original_T_including_depot_unload_1167  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_861  1
    load_1_8_9  segment_load_conservation_1106  1
    load_1_8_9  segment_load_conservation_1113  -1
    load_1_8_9  segment_prefix_lb_1114  1
    load_1_8_9  segment_prefix_ub_1115  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_863  -25
    arc_1_8_15  connected_order_arc_864  -13
    arc_1_8_15  out_degree_1102  1
    arc_1_8_15  in_degree_1117  1
    arc_1_8_15  original_T_including_depot_unload_1167  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_863  1
    load_1_8_15  segment_load_conservation_1106  1
    load_1_8_15  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_865  -25
    arc_1_8_16  connected_order_arc_866  -13
    arc_1_8_16  out_degree_1102  1
    arc_1_8_16  in_degree_1123  1
    arc_1_8_16  original_T_including_depot_unload_1167  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_865  1
    load_1_8_16  segment_load_conservation_1106  1
    load_1_8_16  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_867  -25
    arc_1_8_17  connected_order_arc_868  -13
    arc_1_8_17  out_degree_1102  1
    arc_1_8_17  in_degree_1129  1
    arc_1_8_17  original_T_including_depot_unload_1167  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_867  1
    load_1_8_17  segment_load_conservation_1106  1
    load_1_8_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_869  -25
    arc_1_8_18  connected_order_arc_870  -13
    arc_1_8_18  out_degree_1102  1
    arc_1_8_18  in_degree_1135  1
    arc_1_8_18  original_T_including_depot_unload_1167  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_869  1
    load_1_8_18  segment_load_conservation_1106  1
    load_1_8_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_871  -25
    arc_1_8_19  connected_order_arc_872  -13
    arc_1_8_19  out_degree_1102  1
    arc_1_8_19  in_degree_1141  1
    arc_1_8_19  original_T_including_depot_unload_1167  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_871  1
    load_1_8_19  segment_load_conservation_1106  1
    load_1_8_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_873  -25
    arc_1_8_20  connected_order_arc_874  -13
    arc_1_8_20  out_degree_1102  1
    arc_1_8_20  in_degree_1147  1
    arc_1_8_20  original_T_including_depot_unload_1167  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_873  1
    load_1_8_20  segment_load_conservation_1106  1
    load_1_8_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_875  -25
    arc_1_8_21  connected_order_arc_876  -13
    arc_1_8_21  out_degree_1102  1
    arc_1_8_21  in_degree_1153  1
    arc_1_8_21  original_T_including_depot_unload_1167  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_875  1
    load_1_8_21  segment_load_conservation_1106  1
    load_1_8_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_22  arc_capacity_877  -25
    arc_1_8_22  connected_order_arc_878  -13
    arc_1_8_22  out_degree_1102  1
    arc_1_8_22  in_degree_1159  1
    arc_1_8_22  original_T_including_depot_unload_1167  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_22  arc_capacity_877  1
    load_1_8_22  segment_load_conservation_1106  1
    load_1_8_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_879  -25
    arc_1_9_0  depot_return_or_bypass_1087  1
    arc_1_9_0  out_degree_1109  1
    arc_1_9_0  original_T_including_depot_unload_1167  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_879  1
    load_1_9_0  segment_load_conservation_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_880  -25
    arc_1_9_6  connected_order_arc_881  -13
    arc_1_9_6  in_degree_1089  1
    arc_1_9_6  out_degree_1109  1
    arc_1_9_6  original_T_including_depot_unload_1167  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_880  1
    load_1_9_6  segment_load_conservation_1092  -1
    load_1_9_6  segment_prefix_lb_1093  1
    load_1_9_6  segment_prefix_ub_1094  1
    load_1_9_6  segment_load_conservation_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_882  -25
    arc_1_9_7  connected_order_arc_883  -13
    arc_1_9_7  in_degree_1096  1
    arc_1_9_7  out_degree_1109  1
    arc_1_9_7  original_T_including_depot_unload_1167  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_882  1
    load_1_9_7  segment_load_conservation_1099  -1
    load_1_9_7  segment_prefix_lb_1100  1
    load_1_9_7  segment_prefix_ub_1101  1
    load_1_9_7  segment_load_conservation_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_884  -25
    arc_1_9_8  connected_order_arc_885  -13
    arc_1_9_8  in_degree_1103  1
    arc_1_9_8  out_degree_1109  1
    arc_1_9_8  original_T_including_depot_unload_1167  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_884  1
    load_1_9_8  segment_load_conservation_1106  -1
    load_1_9_8  segment_prefix_lb_1107  1
    load_1_9_8  segment_prefix_ub_1108  1
    load_1_9_8  segment_load_conservation_1113  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_886  -25
    arc_1_9_15  connected_order_arc_887  -13
    arc_1_9_15  out_degree_1109  1
    arc_1_9_15  in_degree_1117  1
    arc_1_9_15  original_T_including_depot_unload_1167  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_886  1
    load_1_9_15  segment_load_conservation_1113  1
    load_1_9_15  free_load_conservation_1121  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_888  -25
    arc_1_9_16  connected_order_arc_889  -13
    arc_1_9_16  out_degree_1109  1
    arc_1_9_16  in_degree_1123  1
    arc_1_9_16  original_T_including_depot_unload_1167  1.8585304557894076e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_888  1
    load_1_9_16  segment_load_conservation_1113  1
    load_1_9_16  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_890  -25
    arc_1_9_17  connected_order_arc_891  -13
    arc_1_9_17  out_degree_1109  1
    arc_1_9_17  in_degree_1129  1
    arc_1_9_17  original_T_including_depot_unload_1167  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_890  1
    load_1_9_17  segment_load_conservation_1113  1
    load_1_9_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_892  -25
    arc_1_9_18  connected_order_arc_893  -13
    arc_1_9_18  out_degree_1109  1
    arc_1_9_18  in_degree_1135  1
    arc_1_9_18  original_T_including_depot_unload_1167  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_892  1
    load_1_9_18  segment_load_conservation_1113  1
    load_1_9_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_894  -25
    arc_1_9_19  connected_order_arc_895  -13
    arc_1_9_19  out_degree_1109  1
    arc_1_9_19  in_degree_1141  1
    arc_1_9_19  original_T_including_depot_unload_1167  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_894  1
    load_1_9_19  segment_load_conservation_1113  1
    load_1_9_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_896  -25
    arc_1_9_20  connected_order_arc_897  -13
    arc_1_9_20  out_degree_1109  1
    arc_1_9_20  in_degree_1147  1
    arc_1_9_20  original_T_including_depot_unload_1167  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_896  1
    load_1_9_20  segment_load_conservation_1113  1
    load_1_9_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_898  -25
    arc_1_9_21  connected_order_arc_899  -13
    arc_1_9_21  out_degree_1109  1
    arc_1_9_21  in_degree_1153  1
    arc_1_9_21  original_T_including_depot_unload_1167  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_898  1
    load_1_9_21  segment_load_conservation_1113  1
    load_1_9_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_22  arc_capacity_900  -25
    arc_1_9_22  connected_order_arc_901  -13
    arc_1_9_22  out_degree_1109  1
    arc_1_9_22  in_degree_1159  1
    arc_1_9_22  original_T_including_depot_unload_1167  1.2968499029957554e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_22  arc_capacity_900  1
    load_1_9_22  segment_load_conservation_1113  1
    load_1_9_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_902  -25
    arc_1_15_0  depot_return_or_bypass_1087  1
    arc_1_15_0  out_degree_1116  1
    arc_1_15_0  original_T_including_depot_unload_1167  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_902  1
    load_1_15_0  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_903  -25
    arc_1_15_6  connected_order_arc_904  -13
    arc_1_15_6  in_degree_1089  1
    arc_1_15_6  out_degree_1116  1
    arc_1_15_6  original_T_including_depot_unload_1167  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_903  1
    load_1_15_6  segment_load_conservation_1092  -1
    load_1_15_6  segment_prefix_lb_1093  1
    load_1_15_6  segment_prefix_ub_1094  1
    load_1_15_6  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_905  -25
    arc_1_15_7  connected_order_arc_906  -13
    arc_1_15_7  in_degree_1096  1
    arc_1_15_7  out_degree_1116  1
    arc_1_15_7  original_T_including_depot_unload_1167  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_905  1
    load_1_15_7  segment_load_conservation_1099  -1
    load_1_15_7  segment_prefix_lb_1100  1
    load_1_15_7  segment_prefix_ub_1101  1
    load_1_15_7  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_907  -25
    arc_1_15_8  connected_order_arc_908  -13
    arc_1_15_8  in_degree_1103  1
    arc_1_15_8  out_degree_1116  1
    arc_1_15_8  original_T_including_depot_unload_1167  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_907  1
    load_1_15_8  segment_load_conservation_1106  -1
    load_1_15_8  segment_prefix_lb_1107  1
    load_1_15_8  segment_prefix_ub_1108  1
    load_1_15_8  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_909  -25
    arc_1_15_9  connected_order_arc_910  -13
    arc_1_15_9  in_degree_1110  1
    arc_1_15_9  out_degree_1116  1
    arc_1_15_9  original_T_including_depot_unload_1167  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_909  1
    load_1_15_9  segment_load_conservation_1113  -1
    load_1_15_9  segment_prefix_lb_1114  1
    load_1_15_9  segment_prefix_ub_1115  1
    load_1_15_9  free_load_conservation_1121  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_911  -25
    arc_1_15_16  connected_order_arc_912  -13
    arc_1_15_16  out_degree_1116  1
    arc_1_15_16  in_degree_1123  1
    arc_1_15_16  original_T_including_depot_unload_1167  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_911  1
    load_1_15_16  free_load_conservation_1121  1
    load_1_15_16  free_load_conservation_1127  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_913  -25
    arc_1_15_17  connected_order_arc_914  -13
    arc_1_15_17  out_degree_1116  1
    arc_1_15_17  in_degree_1129  1
    arc_1_15_17  original_T_including_depot_unload_1167  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_913  1
    load_1_15_17  free_load_conservation_1121  1
    load_1_15_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_915  -25
    arc_1_15_18  connected_order_arc_916  -13
    arc_1_15_18  out_degree_1116  1
    arc_1_15_18  in_degree_1135  1
    arc_1_15_18  original_T_including_depot_unload_1167  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_915  1
    load_1_15_18  free_load_conservation_1121  1
    load_1_15_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_917  -25
    arc_1_15_19  connected_order_arc_918  -13
    arc_1_15_19  out_degree_1116  1
    arc_1_15_19  in_degree_1141  1
    arc_1_15_19  original_T_including_depot_unload_1167  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_917  1
    load_1_15_19  free_load_conservation_1121  1
    load_1_15_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_919  -25
    arc_1_15_20  connected_order_arc_920  -13
    arc_1_15_20  out_degree_1116  1
    arc_1_15_20  in_degree_1147  1
    arc_1_15_20  original_T_including_depot_unload_1167  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_919  1
    load_1_15_20  free_load_conservation_1121  1
    load_1_15_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_921  -25
    arc_1_15_21  connected_order_arc_922  -13
    arc_1_15_21  out_degree_1116  1
    arc_1_15_21  in_degree_1153  1
    arc_1_15_21  original_T_including_depot_unload_1167  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_921  1
    load_1_15_21  free_load_conservation_1121  1
    load_1_15_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_22  arc_capacity_923  -25
    arc_1_15_22  connected_order_arc_924  -13
    arc_1_15_22  out_degree_1116  1
    arc_1_15_22  in_degree_1159  1
    arc_1_15_22  original_T_including_depot_unload_1167  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_22  arc_capacity_923  1
    load_1_15_22  free_load_conservation_1121  1
    load_1_15_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_925  -25
    arc_1_16_0  depot_return_or_bypass_1087  1
    arc_1_16_0  out_degree_1122  1
    arc_1_16_0  original_T_including_depot_unload_1167  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_925  1
    load_1_16_0  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_926  -25
    arc_1_16_6  connected_order_arc_927  -13
    arc_1_16_6  in_degree_1089  1
    arc_1_16_6  out_degree_1122  1
    arc_1_16_6  original_T_including_depot_unload_1167  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_926  1
    load_1_16_6  segment_load_conservation_1092  -1
    load_1_16_6  segment_prefix_lb_1093  1
    load_1_16_6  segment_prefix_ub_1094  1
    load_1_16_6  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_928  -25
    arc_1_16_7  connected_order_arc_929  -13
    arc_1_16_7  in_degree_1096  1
    arc_1_16_7  out_degree_1122  1
    arc_1_16_7  original_T_including_depot_unload_1167  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_928  1
    load_1_16_7  segment_load_conservation_1099  -1
    load_1_16_7  segment_prefix_lb_1100  1
    load_1_16_7  segment_prefix_ub_1101  1
    load_1_16_7  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_930  -25
    arc_1_16_8  connected_order_arc_931  -13
    arc_1_16_8  in_degree_1103  1
    arc_1_16_8  out_degree_1122  1
    arc_1_16_8  original_T_including_depot_unload_1167  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_930  1
    load_1_16_8  segment_load_conservation_1106  -1
    load_1_16_8  segment_prefix_lb_1107  1
    load_1_16_8  segment_prefix_ub_1108  1
    load_1_16_8  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_932  -25
    arc_1_16_9  connected_order_arc_933  -13
    arc_1_16_9  in_degree_1110  1
    arc_1_16_9  out_degree_1122  1
    arc_1_16_9  original_T_including_depot_unload_1167  1.8375396100269363e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_932  1
    load_1_16_9  segment_load_conservation_1113  -1
    load_1_16_9  segment_prefix_lb_1114  1
    load_1_16_9  segment_prefix_ub_1115  1
    load_1_16_9  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_934  -25
    arc_1_16_15  connected_order_arc_935  -13
    arc_1_16_15  in_degree_1117  1
    arc_1_16_15  out_degree_1122  1
    arc_1_16_15  original_T_including_depot_unload_1167  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_934  1
    load_1_16_15  free_load_conservation_1121  -1
    load_1_16_15  free_load_conservation_1127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_936  -25
    arc_1_16_17  connected_order_arc_937  -13
    arc_1_16_17  out_degree_1122  1
    arc_1_16_17  in_degree_1129  1
    arc_1_16_17  original_T_including_depot_unload_1167  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_936  1
    load_1_16_17  free_load_conservation_1127  1
    load_1_16_17  free_load_conservation_1133  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_938  -25
    arc_1_16_18  connected_order_arc_939  -13
    arc_1_16_18  out_degree_1122  1
    arc_1_16_18  in_degree_1135  1
    arc_1_16_18  original_T_including_depot_unload_1167  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_938  1
    load_1_16_18  free_load_conservation_1127  1
    load_1_16_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_940  -25
    arc_1_16_19  connected_order_arc_941  -13
    arc_1_16_19  out_degree_1122  1
    arc_1_16_19  in_degree_1141  1
    arc_1_16_19  original_T_including_depot_unload_1167  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_940  1
    load_1_16_19  free_load_conservation_1127  1
    load_1_16_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_942  -25
    arc_1_16_20  connected_order_arc_943  -13
    arc_1_16_20  out_degree_1122  1
    arc_1_16_20  in_degree_1147  1
    arc_1_16_20  original_T_including_depot_unload_1167  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_942  1
    load_1_16_20  free_load_conservation_1127  1
    load_1_16_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_944  -25
    arc_1_16_21  connected_order_arc_945  -13
    arc_1_16_21  out_degree_1122  1
    arc_1_16_21  in_degree_1153  1
    arc_1_16_21  original_T_including_depot_unload_1167  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_944  1
    load_1_16_21  free_load_conservation_1127  1
    load_1_16_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_22  arc_capacity_946  -25
    arc_1_16_22  connected_order_arc_947  -13
    arc_1_16_22  out_degree_1122  1
    arc_1_16_22  in_degree_1159  1
    arc_1_16_22  original_T_including_depot_unload_1167  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_22  arc_capacity_946  1
    load_1_16_22  free_load_conservation_1127  1
    load_1_16_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_948  -25
    arc_1_17_0  depot_return_or_bypass_1087  1
    arc_1_17_0  out_degree_1128  1
    arc_1_17_0  original_T_including_depot_unload_1167  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_948  1
    load_1_17_0  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_949  -25
    arc_1_17_6  connected_order_arc_950  -13
    arc_1_17_6  in_degree_1089  1
    arc_1_17_6  out_degree_1128  1
    arc_1_17_6  original_T_including_depot_unload_1167  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_949  1
    load_1_17_6  segment_load_conservation_1092  -1
    load_1_17_6  segment_prefix_lb_1093  1
    load_1_17_6  segment_prefix_ub_1094  1
    load_1_17_6  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_951  -25
    arc_1_17_7  connected_order_arc_952  -13
    arc_1_17_7  in_degree_1096  1
    arc_1_17_7  out_degree_1128  1
    arc_1_17_7  original_T_including_depot_unload_1167  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_951  1
    load_1_17_7  segment_load_conservation_1099  -1
    load_1_17_7  segment_prefix_lb_1100  1
    load_1_17_7  segment_prefix_ub_1101  1
    load_1_17_7  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_953  -25
    arc_1_17_8  connected_order_arc_954  -13
    arc_1_17_8  in_degree_1103  1
    arc_1_17_8  out_degree_1128  1
    arc_1_17_8  original_T_including_depot_unload_1167  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_953  1
    load_1_17_8  segment_load_conservation_1106  -1
    load_1_17_8  segment_prefix_lb_1107  1
    load_1_17_8  segment_prefix_ub_1108  1
    load_1_17_8  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_955  -25
    arc_1_17_9  connected_order_arc_956  -13
    arc_1_17_9  in_degree_1110  1
    arc_1_17_9  out_degree_1128  1
    arc_1_17_9  original_T_including_depot_unload_1167  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_955  1
    load_1_17_9  segment_load_conservation_1113  -1
    load_1_17_9  segment_prefix_lb_1114  1
    load_1_17_9  segment_prefix_ub_1115  1
    load_1_17_9  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_957  -25
    arc_1_17_15  connected_order_arc_958  -13
    arc_1_17_15  in_degree_1117  1
    arc_1_17_15  out_degree_1128  1
    arc_1_17_15  original_T_including_depot_unload_1167  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_957  1
    load_1_17_15  free_load_conservation_1121  -1
    load_1_17_15  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_959  -25
    arc_1_17_16  connected_order_arc_960  -13
    arc_1_17_16  in_degree_1123  1
    arc_1_17_16  out_degree_1128  1
    arc_1_17_16  original_T_including_depot_unload_1167  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_959  1
    load_1_17_16  free_load_conservation_1127  -1
    load_1_17_16  free_load_conservation_1133  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_961  -25
    arc_1_17_18  connected_order_arc_962  -13
    arc_1_17_18  out_degree_1128  1
    arc_1_17_18  in_degree_1135  1
    arc_1_17_18  original_T_including_depot_unload_1167  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_961  1
    load_1_17_18  free_load_conservation_1133  1
    load_1_17_18  free_load_conservation_1139  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_963  -25
    arc_1_17_19  connected_order_arc_964  -13
    arc_1_17_19  out_degree_1128  1
    arc_1_17_19  in_degree_1141  1
    arc_1_17_19  original_T_including_depot_unload_1167  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_963  1
    load_1_17_19  free_load_conservation_1133  1
    load_1_17_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_965  -25
    arc_1_17_20  connected_order_arc_966  -13
    arc_1_17_20  out_degree_1128  1
    arc_1_17_20  in_degree_1147  1
    arc_1_17_20  original_T_including_depot_unload_1167  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_965  1
    load_1_17_20  free_load_conservation_1133  1
    load_1_17_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_967  -25
    arc_1_17_21  connected_order_arc_968  -13
    arc_1_17_21  out_degree_1128  1
    arc_1_17_21  in_degree_1153  1
    arc_1_17_21  original_T_including_depot_unload_1167  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_967  1
    load_1_17_21  free_load_conservation_1133  1
    load_1_17_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_22  arc_capacity_969  -25
    arc_1_17_22  connected_order_arc_970  -13
    arc_1_17_22  out_degree_1128  1
    arc_1_17_22  in_degree_1159  1
    arc_1_17_22  original_T_including_depot_unload_1167  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_22  arc_capacity_969  1
    load_1_17_22  free_load_conservation_1133  1
    load_1_17_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_971  -25
    arc_1_18_0  depot_return_or_bypass_1087  1
    arc_1_18_0  out_degree_1134  1
    arc_1_18_0  original_T_including_depot_unload_1167  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_971  1
    load_1_18_0  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_972  -25
    arc_1_18_6  connected_order_arc_973  -13
    arc_1_18_6  in_degree_1089  1
    arc_1_18_6  out_degree_1134  1
    arc_1_18_6  original_T_including_depot_unload_1167  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_972  1
    load_1_18_6  segment_load_conservation_1092  -1
    load_1_18_6  segment_prefix_lb_1093  1
    load_1_18_6  segment_prefix_ub_1094  1
    load_1_18_6  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_974  -25
    arc_1_18_7  connected_order_arc_975  -13
    arc_1_18_7  in_degree_1096  1
    arc_1_18_7  out_degree_1134  1
    arc_1_18_7  original_T_including_depot_unload_1167  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_974  1
    load_1_18_7  segment_load_conservation_1099  -1
    load_1_18_7  segment_prefix_lb_1100  1
    load_1_18_7  segment_prefix_ub_1101  1
    load_1_18_7  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_976  -25
    arc_1_18_8  connected_order_arc_977  -13
    arc_1_18_8  in_degree_1103  1
    arc_1_18_8  out_degree_1134  1
    arc_1_18_8  original_T_including_depot_unload_1167  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_976  1
    load_1_18_8  segment_load_conservation_1106  -1
    load_1_18_8  segment_prefix_lb_1107  1
    load_1_18_8  segment_prefix_ub_1108  1
    load_1_18_8  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_978  -25
    arc_1_18_9  connected_order_arc_979  -13
    arc_1_18_9  in_degree_1110  1
    arc_1_18_9  out_degree_1134  1
    arc_1_18_9  original_T_including_depot_unload_1167  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_978  1
    load_1_18_9  segment_load_conservation_1113  -1
    load_1_18_9  segment_prefix_lb_1114  1
    load_1_18_9  segment_prefix_ub_1115  1
    load_1_18_9  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_980  -25
    arc_1_18_15  connected_order_arc_981  -13
    arc_1_18_15  in_degree_1117  1
    arc_1_18_15  out_degree_1134  1
    arc_1_18_15  original_T_including_depot_unload_1167  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_980  1
    load_1_18_15  free_load_conservation_1121  -1
    load_1_18_15  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_982  -25
    arc_1_18_16  connected_order_arc_983  -13
    arc_1_18_16  in_degree_1123  1
    arc_1_18_16  out_degree_1134  1
    arc_1_18_16  original_T_including_depot_unload_1167  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_982  1
    load_1_18_16  free_load_conservation_1127  -1
    load_1_18_16  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_984  -25
    arc_1_18_17  connected_order_arc_985  -13
    arc_1_18_17  in_degree_1129  1
    arc_1_18_17  out_degree_1134  1
    arc_1_18_17  original_T_including_depot_unload_1167  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_984  1
    load_1_18_17  free_load_conservation_1133  -1
    load_1_18_17  free_load_conservation_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_986  -25
    arc_1_18_19  connected_order_arc_987  -13
    arc_1_18_19  out_degree_1134  1
    arc_1_18_19  in_degree_1141  1
    arc_1_18_19  original_T_including_depot_unload_1167  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_986  1
    load_1_18_19  free_load_conservation_1139  1
    load_1_18_19  free_load_conservation_1145  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_988  -25
    arc_1_18_20  connected_order_arc_989  -13
    arc_1_18_20  out_degree_1134  1
    arc_1_18_20  in_degree_1147  1
    arc_1_18_20  original_T_including_depot_unload_1167  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_988  1
    load_1_18_20  free_load_conservation_1139  1
    load_1_18_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_990  -25
    arc_1_18_21  connected_order_arc_991  -13
    arc_1_18_21  out_degree_1134  1
    arc_1_18_21  in_degree_1153  1
    arc_1_18_21  original_T_including_depot_unload_1167  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_990  1
    load_1_18_21  free_load_conservation_1139  1
    load_1_18_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_22  arc_capacity_992  -25
    arc_1_18_22  connected_order_arc_993  -13
    arc_1_18_22  out_degree_1134  1
    arc_1_18_22  in_degree_1159  1
    arc_1_18_22  original_T_including_depot_unload_1167  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_22  arc_capacity_992  1
    load_1_18_22  free_load_conservation_1139  1
    load_1_18_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_994  -25
    arc_1_19_0  depot_return_or_bypass_1087  1
    arc_1_19_0  out_degree_1140  1
    arc_1_19_0  original_T_including_depot_unload_1167  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_994  1
    load_1_19_0  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_995  -25
    arc_1_19_6  connected_order_arc_996  -13
    arc_1_19_6  in_degree_1089  1
    arc_1_19_6  out_degree_1140  1
    arc_1_19_6  original_T_including_depot_unload_1167  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_995  1
    load_1_19_6  segment_load_conservation_1092  -1
    load_1_19_6  segment_prefix_lb_1093  1
    load_1_19_6  segment_prefix_ub_1094  1
    load_1_19_6  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_997  -25
    arc_1_19_7  connected_order_arc_998  -13
    arc_1_19_7  in_degree_1096  1
    arc_1_19_7  out_degree_1140  1
    arc_1_19_7  original_T_including_depot_unload_1167  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_997  1
    load_1_19_7  segment_load_conservation_1099  -1
    load_1_19_7  segment_prefix_lb_1100  1
    load_1_19_7  segment_prefix_ub_1101  1
    load_1_19_7  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_999  -25
    arc_1_19_8  connected_order_arc_1000  -13
    arc_1_19_8  in_degree_1103  1
    arc_1_19_8  out_degree_1140  1
    arc_1_19_8  original_T_including_depot_unload_1167  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_999  1
    load_1_19_8  segment_load_conservation_1106  -1
    load_1_19_8  segment_prefix_lb_1107  1
    load_1_19_8  segment_prefix_ub_1108  1
    load_1_19_8  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1001  -25
    arc_1_19_9  connected_order_arc_1002  -13
    arc_1_19_9  in_degree_1110  1
    arc_1_19_9  out_degree_1140  1
    arc_1_19_9  original_T_including_depot_unload_1167  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1001  1
    load_1_19_9  segment_load_conservation_1113  -1
    load_1_19_9  segment_prefix_lb_1114  1
    load_1_19_9  segment_prefix_ub_1115  1
    load_1_19_9  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1003  -25
    arc_1_19_15  connected_order_arc_1004  -13
    arc_1_19_15  in_degree_1117  1
    arc_1_19_15  out_degree_1140  1
    arc_1_19_15  original_T_including_depot_unload_1167  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1003  1
    load_1_19_15  free_load_conservation_1121  -1
    load_1_19_15  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1005  -25
    arc_1_19_16  connected_order_arc_1006  -13
    arc_1_19_16  in_degree_1123  1
    arc_1_19_16  out_degree_1140  1
    arc_1_19_16  original_T_including_depot_unload_1167  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1005  1
    load_1_19_16  free_load_conservation_1127  -1
    load_1_19_16  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1007  -25
    arc_1_19_17  connected_order_arc_1008  -13
    arc_1_19_17  in_degree_1129  1
    arc_1_19_17  out_degree_1140  1
    arc_1_19_17  original_T_including_depot_unload_1167  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1007  1
    load_1_19_17  free_load_conservation_1133  -1
    load_1_19_17  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1009  -25
    arc_1_19_18  connected_order_arc_1010  -13
    arc_1_19_18  in_degree_1135  1
    arc_1_19_18  out_degree_1140  1
    arc_1_19_18  original_T_including_depot_unload_1167  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1009  1
    load_1_19_18  free_load_conservation_1139  -1
    load_1_19_18  free_load_conservation_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1011  -25
    arc_1_19_20  connected_order_arc_1012  -13
    arc_1_19_20  out_degree_1140  1
    arc_1_19_20  in_degree_1147  1
    arc_1_19_20  original_T_including_depot_unload_1167  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1011  1
    load_1_19_20  free_load_conservation_1145  1
    load_1_19_20  free_load_conservation_1151  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1013  -25
    arc_1_19_21  connected_order_arc_1014  -13
    arc_1_19_21  out_degree_1140  1
    arc_1_19_21  in_degree_1153  1
    arc_1_19_21  original_T_including_depot_unload_1167  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1013  1
    load_1_19_21  free_load_conservation_1145  1
    load_1_19_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_22  arc_capacity_1015  -25
    arc_1_19_22  connected_order_arc_1016  -13
    arc_1_19_22  out_degree_1140  1
    arc_1_19_22  in_degree_1159  1
    arc_1_19_22  original_T_including_depot_unload_1167  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_22  arc_capacity_1015  1
    load_1_19_22  free_load_conservation_1145  1
    load_1_19_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1017  -25
    arc_1_20_0  depot_return_or_bypass_1087  1
    arc_1_20_0  out_degree_1146  1
    arc_1_20_0  original_T_including_depot_unload_1167  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1017  1
    load_1_20_0  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1018  -25
    arc_1_20_6  connected_order_arc_1019  -13
    arc_1_20_6  in_degree_1089  1
    arc_1_20_6  out_degree_1146  1
    arc_1_20_6  original_T_including_depot_unload_1167  1.8250469514445369e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1018  1
    load_1_20_6  segment_load_conservation_1092  -1
    load_1_20_6  segment_prefix_lb_1093  1
    load_1_20_6  segment_prefix_ub_1094  1
    load_1_20_6  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1020  -25
    arc_1_20_7  connected_order_arc_1021  -13
    arc_1_20_7  in_degree_1096  1
    arc_1_20_7  out_degree_1146  1
    arc_1_20_7  original_T_including_depot_unload_1167  1.8050468619497597e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1020  1
    load_1_20_7  segment_load_conservation_1099  -1
    load_1_20_7  segment_prefix_lb_1100  1
    load_1_20_7  segment_prefix_ub_1101  1
    load_1_20_7  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1022  -25
    arc_1_20_8  connected_order_arc_1023  -13
    arc_1_20_8  in_degree_1103  1
    arc_1_20_8  out_degree_1146  1
    arc_1_20_8  original_T_including_depot_unload_1167  1.5636076207019653e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1022  1
    load_1_20_8  segment_load_conservation_1106  -1
    load_1_20_8  segment_prefix_lb_1107  1
    load_1_20_8  segment_prefix_ub_1108  1
    load_1_20_8  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1024  -25
    arc_1_20_9  connected_order_arc_1025  -13
    arc_1_20_9  in_degree_1110  1
    arc_1_20_9  out_degree_1146  1
    arc_1_20_9  original_T_including_depot_unload_1167  1.9912760202020529e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1024  1
    load_1_20_9  segment_load_conservation_1113  -1
    load_1_20_9  segment_prefix_lb_1114  1
    load_1_20_9  segment_prefix_ub_1115  1
    load_1_20_9  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1026  -25
    arc_1_20_15  connected_order_arc_1027  -13
    arc_1_20_15  in_degree_1117  1
    arc_1_20_15  out_degree_1146  1
    arc_1_20_15  original_T_including_depot_unload_1167  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1026  1
    load_1_20_15  free_load_conservation_1121  -1
    load_1_20_15  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1028  -25
    arc_1_20_16  connected_order_arc_1029  -13
    arc_1_20_16  in_degree_1123  1
    arc_1_20_16  out_degree_1146  1
    arc_1_20_16  original_T_including_depot_unload_1167  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1028  1
    load_1_20_16  free_load_conservation_1127  -1
    load_1_20_16  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1030  -25
    arc_1_20_17  connected_order_arc_1031  -13
    arc_1_20_17  in_degree_1129  1
    arc_1_20_17  out_degree_1146  1
    arc_1_20_17  original_T_including_depot_unload_1167  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1030  1
    load_1_20_17  free_load_conservation_1133  -1
    load_1_20_17  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1032  -25
    arc_1_20_18  connected_order_arc_1033  -13
    arc_1_20_18  in_degree_1135  1
    arc_1_20_18  out_degree_1146  1
    arc_1_20_18  original_T_including_depot_unload_1167  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1032  1
    load_1_20_18  free_load_conservation_1139  -1
    load_1_20_18  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1034  -25
    arc_1_20_19  connected_order_arc_1035  -13
    arc_1_20_19  in_degree_1141  1
    arc_1_20_19  out_degree_1146  1
    arc_1_20_19  original_T_including_depot_unload_1167  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1034  1
    load_1_20_19  free_load_conservation_1145  -1
    load_1_20_19  free_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1036  -25
    arc_1_20_21  connected_order_arc_1037  -13
    arc_1_20_21  out_degree_1146  1
    arc_1_20_21  in_degree_1153  1
    arc_1_20_21  original_T_including_depot_unload_1167  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1036  1
    load_1_20_21  free_load_conservation_1151  1
    load_1_20_21  free_load_conservation_1157  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_22  arc_capacity_1038  -25
    arc_1_20_22  connected_order_arc_1039  -13
    arc_1_20_22  out_degree_1146  1
    arc_1_20_22  in_degree_1159  1
    arc_1_20_22  original_T_including_depot_unload_1167  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_22  arc_capacity_1038  1
    load_1_20_22  free_load_conservation_1151  1
    load_1_20_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1040  -25
    arc_1_21_0  depot_return_or_bypass_1087  1
    arc_1_21_0  out_degree_1152  1
    arc_1_21_0  original_T_including_depot_unload_1167  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1040  1
    load_1_21_0  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1041  -25
    arc_1_21_6  connected_order_arc_1042  -13
    arc_1_21_6  in_degree_1089  1
    arc_1_21_6  out_degree_1152  1
    arc_1_21_6  original_T_including_depot_unload_1167  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1041  1
    load_1_21_6  segment_load_conservation_1092  -1
    load_1_21_6  segment_prefix_lb_1093  1
    load_1_21_6  segment_prefix_ub_1094  1
    load_1_21_6  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1043  -25
    arc_1_21_7  connected_order_arc_1044  -13
    arc_1_21_7  in_degree_1096  1
    arc_1_21_7  out_degree_1152  1
    arc_1_21_7  original_T_including_depot_unload_1167  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1043  1
    load_1_21_7  segment_load_conservation_1099  -1
    load_1_21_7  segment_prefix_lb_1100  1
    load_1_21_7  segment_prefix_ub_1101  1
    load_1_21_7  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1045  -25
    arc_1_21_8  connected_order_arc_1046  -13
    arc_1_21_8  in_degree_1103  1
    arc_1_21_8  out_degree_1152  1
    arc_1_21_8  original_T_including_depot_unload_1167  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1045  1
    load_1_21_8  segment_load_conservation_1106  -1
    load_1_21_8  segment_prefix_lb_1107  1
    load_1_21_8  segment_prefix_ub_1108  1
    load_1_21_8  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1047  -25
    arc_1_21_9  connected_order_arc_1048  -13
    arc_1_21_9  in_degree_1110  1
    arc_1_21_9  out_degree_1152  1
    arc_1_21_9  original_T_including_depot_unload_1167  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1047  1
    load_1_21_9  segment_load_conservation_1113  -1
    load_1_21_9  segment_prefix_lb_1114  1
    load_1_21_9  segment_prefix_ub_1115  1
    load_1_21_9  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1049  -25
    arc_1_21_15  connected_order_arc_1050  -13
    arc_1_21_15  in_degree_1117  1
    arc_1_21_15  out_degree_1152  1
    arc_1_21_15  original_T_including_depot_unload_1167  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1049  1
    load_1_21_15  free_load_conservation_1121  -1
    load_1_21_15  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1051  -25
    arc_1_21_16  connected_order_arc_1052  -13
    arc_1_21_16  in_degree_1123  1
    arc_1_21_16  out_degree_1152  1
    arc_1_21_16  original_T_including_depot_unload_1167  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1051  1
    load_1_21_16  free_load_conservation_1127  -1
    load_1_21_16  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1053  -25
    arc_1_21_17  connected_order_arc_1054  -13
    arc_1_21_17  in_degree_1129  1
    arc_1_21_17  out_degree_1152  1
    arc_1_21_17  original_T_including_depot_unload_1167  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1053  1
    load_1_21_17  free_load_conservation_1133  -1
    load_1_21_17  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1055  -25
    arc_1_21_18  connected_order_arc_1056  -13
    arc_1_21_18  in_degree_1135  1
    arc_1_21_18  out_degree_1152  1
    arc_1_21_18  original_T_including_depot_unload_1167  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1055  1
    load_1_21_18  free_load_conservation_1139  -1
    load_1_21_18  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1057  -25
    arc_1_21_19  connected_order_arc_1058  -13
    arc_1_21_19  in_degree_1141  1
    arc_1_21_19  out_degree_1152  1
    arc_1_21_19  original_T_including_depot_unload_1167  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1057  1
    load_1_21_19  free_load_conservation_1145  -1
    load_1_21_19  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1059  -25
    arc_1_21_20  connected_order_arc_1060  -13
    arc_1_21_20  in_degree_1147  1
    arc_1_21_20  out_degree_1152  1
    arc_1_21_20  original_T_including_depot_unload_1167  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1059  1
    load_1_21_20  free_load_conservation_1151  -1
    load_1_21_20  free_load_conservation_1157  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_22  arc_capacity_1061  -25
    arc_1_21_22  connected_order_arc_1062  -13
    arc_1_21_22  out_degree_1152  1
    arc_1_21_22  in_degree_1159  1
    arc_1_21_22  original_T_including_depot_unload_1167  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_22  arc_capacity_1061  1
    load_1_21_22  free_load_conservation_1157  1
    load_1_21_22  free_load_conservation_1163  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_0  arc_capacity_1063  -25
    arc_1_22_0  depot_return_or_bypass_1087  1
    arc_1_22_0  out_degree_1158  1
    arc_1_22_0  original_T_including_depot_unload_1167  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_0  arc_capacity_1063  1
    load_1_22_0  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_6  arc_capacity_1064  -25
    arc_1_22_6  connected_order_arc_1065  -13
    arc_1_22_6  in_degree_1089  1
    arc_1_22_6  out_degree_1158  1
    arc_1_22_6  original_T_including_depot_unload_1167  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_6  arc_capacity_1064  1
    load_1_22_6  segment_load_conservation_1092  -1
    load_1_22_6  segment_prefix_lb_1093  1
    load_1_22_6  segment_prefix_ub_1094  1
    load_1_22_6  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_7  arc_capacity_1066  -25
    arc_1_22_7  connected_order_arc_1067  -13
    arc_1_22_7  in_degree_1096  1
    arc_1_22_7  out_degree_1158  1
    arc_1_22_7  original_T_including_depot_unload_1167  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_7  arc_capacity_1066  1
    load_1_22_7  segment_load_conservation_1099  -1
    load_1_22_7  segment_prefix_lb_1100  1
    load_1_22_7  segment_prefix_ub_1101  1
    load_1_22_7  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_8  arc_capacity_1068  -25
    arc_1_22_8  connected_order_arc_1069  -13
    arc_1_22_8  in_degree_1103  1
    arc_1_22_8  out_degree_1158  1
    arc_1_22_8  original_T_including_depot_unload_1167  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_8  arc_capacity_1068  1
    load_1_22_8  segment_load_conservation_1106  -1
    load_1_22_8  segment_prefix_lb_1107  1
    load_1_22_8  segment_prefix_ub_1108  1
    load_1_22_8  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_9  arc_capacity_1070  -25
    arc_1_22_9  connected_order_arc_1071  -13
    arc_1_22_9  in_degree_1110  1
    arc_1_22_9  out_degree_1158  1
    arc_1_22_9  original_T_including_depot_unload_1167  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_9  arc_capacity_1070  1
    load_1_22_9  segment_load_conservation_1113  -1
    load_1_22_9  segment_prefix_lb_1114  1
    load_1_22_9  segment_prefix_ub_1115  1
    load_1_22_9  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_15  arc_capacity_1072  -25
    arc_1_22_15  connected_order_arc_1073  -13
    arc_1_22_15  in_degree_1117  1
    arc_1_22_15  out_degree_1158  1
    arc_1_22_15  original_T_including_depot_unload_1167  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_15  arc_capacity_1072  1
    load_1_22_15  free_load_conservation_1121  -1
    load_1_22_15  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_16  arc_capacity_1074  -25
    arc_1_22_16  connected_order_arc_1075  -13
    arc_1_22_16  in_degree_1123  1
    arc_1_22_16  out_degree_1158  1
    arc_1_22_16  original_T_including_depot_unload_1167  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_16  arc_capacity_1074  1
    load_1_22_16  free_load_conservation_1127  -1
    load_1_22_16  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_17  arc_capacity_1076  -25
    arc_1_22_17  connected_order_arc_1077  -13
    arc_1_22_17  in_degree_1129  1
    arc_1_22_17  out_degree_1158  1
    arc_1_22_17  original_T_including_depot_unload_1167  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_22_17  arc_capacity_1076  1
    load_1_22_17  free_load_conservation_1133  -1
    load_1_22_17  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_18  arc_capacity_1078  -25
    arc_1_22_18  connected_order_arc_1079  -13
    arc_1_22_18  in_degree_1135  1
    arc_1_22_18  out_degree_1158  1
    arc_1_22_18  original_T_including_depot_unload_1167  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_18  arc_capacity_1078  1
    load_1_22_18  free_load_conservation_1139  -1
    load_1_22_18  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_19  arc_capacity_1080  -25
    arc_1_22_19  connected_order_arc_1081  -13
    arc_1_22_19  in_degree_1141  1
    arc_1_22_19  out_degree_1158  1
    arc_1_22_19  original_T_including_depot_unload_1167  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_19  arc_capacity_1080  1
    load_1_22_19  free_load_conservation_1145  -1
    load_1_22_19  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_20  arc_capacity_1082  -25
    arc_1_22_20  connected_order_arc_1083  -13
    arc_1_22_20  in_degree_1147  1
    arc_1_22_20  out_degree_1158  1
    arc_1_22_20  original_T_including_depot_unload_1167  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_20  arc_capacity_1082  1
    load_1_22_20  free_load_conservation_1151  -1
    load_1_22_20  free_load_conservation_1163  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_22_21  arc_capacity_1084  -25
    arc_1_22_21  connected_order_arc_1085  -13
    arc_1_22_21  in_degree_1153  1
    arc_1_22_21  out_degree_1158  1
    arc_1_22_21  original_T_including_depot_unload_1167  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_22_21  arc_capacity_1084  1
    load_1_22_21  free_load_conservation_1157  -1
    load_1_22_21  free_load_conservation_1163  1
    visit_2_10  out_degree_1509  -1
    visit_2_10  in_degree_1510  -1
    visit_2_10  order_active_lb_1511  -1
    visit_2_10  order_active_ub_1512  -13
    order_2_10  connected_order_arc_1184  -1
    order_2_10  connected_order_arc_1186  -1
    order_2_10  connected_order_arc_1188  -1
    order_2_10  connected_order_arc_1190  -1
    order_2_10  connected_order_arc_1192  -1
    order_2_10  connected_order_arc_1194  -1
    order_2_10  connected_order_arc_1196  -1
    order_2_10  connected_order_arc_1198  -1
    order_2_10  connected_order_arc_1200  -1
    order_2_10  connected_order_arc_1202  -1
    order_2_10  connected_order_arc_1204  -1
    order_2_10  connected_order_arc_1206  -1
    order_2_10  connected_order_arc_1209  1
    order_2_10  connected_order_arc_1234  1
    order_2_10  connected_order_arc_1259  1
    order_2_10  connected_order_arc_1284  1
    order_2_10  connected_order_arc_1309  1
    order_2_10  connected_order_arc_1334  1
    order_2_10  connected_order_arc_1359  1
    order_2_10  connected_order_arc_1384  1
    order_2_10  connected_order_arc_1409  1
    order_2_10  connected_order_arc_1434  1
    order_2_10  connected_order_arc_1459  1
    order_2_10  connected_order_arc_1484  1
    order_2_10  order_active_lb_1511  1
    order_2_10  order_active_ub_1512  1
    order_2_10  fixed_segment_relative_order_1592  -1
    visit_2_11  out_degree_1516  -1
    visit_2_11  in_degree_1517  -1
    visit_2_11  order_active_lb_1518  -1
    visit_2_11  order_active_ub_1519  -13
    order_2_11  connected_order_arc_1184  1
    order_2_11  connected_order_arc_1209  -1
    order_2_11  connected_order_arc_1211  -1
    order_2_11  connected_order_arc_1213  -1
    order_2_11  connected_order_arc_1215  -1
    order_2_11  connected_order_arc_1217  -1
    order_2_11  connected_order_arc_1219  -1
    order_2_11  connected_order_arc_1221  -1
    order_2_11  connected_order_arc_1223  -1
    order_2_11  connected_order_arc_1225  -1
    order_2_11  connected_order_arc_1227  -1
    order_2_11  connected_order_arc_1229  -1
    order_2_11  connected_order_arc_1231  -1
    order_2_11  connected_order_arc_1236  1
    order_2_11  connected_order_arc_1261  1
    order_2_11  connected_order_arc_1286  1
    order_2_11  connected_order_arc_1311  1
    order_2_11  connected_order_arc_1336  1
    order_2_11  connected_order_arc_1361  1
    order_2_11  connected_order_arc_1386  1
    order_2_11  connected_order_arc_1411  1
    order_2_11  connected_order_arc_1436  1
    order_2_11  connected_order_arc_1461  1
    order_2_11  connected_order_arc_1486  1
    order_2_11  order_active_lb_1518  1
    order_2_11  order_active_ub_1519  1
    order_2_11  fixed_segment_relative_order_1592  1
    order_2_11  fixed_segment_relative_order_1593  -1
    visit_2_12  out_degree_1523  -1
    visit_2_12  in_degree_1524  -1
    visit_2_12  order_active_lb_1525  -1
    visit_2_12  order_active_ub_1526  -13
    order_2_12  connected_order_arc_1186  1
    order_2_12  connected_order_arc_1211  1
    order_2_12  connected_order_arc_1234  -1
    order_2_12  connected_order_arc_1236  -1
    order_2_12  connected_order_arc_1238  -1
    order_2_12  connected_order_arc_1240  -1
    order_2_12  connected_order_arc_1242  -1
    order_2_12  connected_order_arc_1244  -1
    order_2_12  connected_order_arc_1246  -1
    order_2_12  connected_order_arc_1248  -1
    order_2_12  connected_order_arc_1250  -1
    order_2_12  connected_order_arc_1252  -1
    order_2_12  connected_order_arc_1254  -1
    order_2_12  connected_order_arc_1256  -1
    order_2_12  connected_order_arc_1263  1
    order_2_12  connected_order_arc_1288  1
    order_2_12  connected_order_arc_1313  1
    order_2_12  connected_order_arc_1338  1
    order_2_12  connected_order_arc_1363  1
    order_2_12  connected_order_arc_1388  1
    order_2_12  connected_order_arc_1413  1
    order_2_12  connected_order_arc_1438  1
    order_2_12  connected_order_arc_1463  1
    order_2_12  connected_order_arc_1488  1
    order_2_12  order_active_lb_1525  1
    order_2_12  order_active_ub_1526  1
    order_2_12  fixed_segment_relative_order_1593  1
    order_2_12  fixed_segment_relative_order_1594  -1
    visit_2_13  out_degree_1530  -1
    visit_2_13  in_degree_1531  -1
    visit_2_13  order_active_lb_1532  -1
    visit_2_13  order_active_ub_1533  -13
    order_2_13  connected_order_arc_1188  1
    order_2_13  connected_order_arc_1213  1
    order_2_13  connected_order_arc_1238  1
    order_2_13  connected_order_arc_1259  -1
    order_2_13  connected_order_arc_1261  -1
    order_2_13  connected_order_arc_1263  -1
    order_2_13  connected_order_arc_1265  -1
    order_2_13  connected_order_arc_1267  -1
    order_2_13  connected_order_arc_1269  -1
    order_2_13  connected_order_arc_1271  -1
    order_2_13  connected_order_arc_1273  -1
    order_2_13  connected_order_arc_1275  -1
    order_2_13  connected_order_arc_1277  -1
    order_2_13  connected_order_arc_1279  -1
    order_2_13  connected_order_arc_1281  -1
    order_2_13  connected_order_arc_1290  1
    order_2_13  connected_order_arc_1315  1
    order_2_13  connected_order_arc_1340  1
    order_2_13  connected_order_arc_1365  1
    order_2_13  connected_order_arc_1390  1
    order_2_13  connected_order_arc_1415  1
    order_2_13  connected_order_arc_1440  1
    order_2_13  connected_order_arc_1465  1
    order_2_13  connected_order_arc_1490  1
    order_2_13  order_active_lb_1532  1
    order_2_13  order_active_ub_1533  1
    order_2_13  fixed_segment_relative_order_1594  1
    order_2_13  fixed_segment_relative_order_1595  -1
    visit_2_14  out_degree_1537  -1
    visit_2_14  in_degree_1538  -1
    visit_2_14  order_active_lb_1539  -1
    visit_2_14  order_active_ub_1540  -13
    order_2_14  connected_order_arc_1190  1
    order_2_14  connected_order_arc_1215  1
    order_2_14  connected_order_arc_1240  1
    order_2_14  connected_order_arc_1265  1
    order_2_14  connected_order_arc_1284  -1
    order_2_14  connected_order_arc_1286  -1
    order_2_14  connected_order_arc_1288  -1
    order_2_14  connected_order_arc_1290  -1
    order_2_14  connected_order_arc_1292  -1
    order_2_14  connected_order_arc_1294  -1
    order_2_14  connected_order_arc_1296  -1
    order_2_14  connected_order_arc_1298  -1
    order_2_14  connected_order_arc_1300  -1
    order_2_14  connected_order_arc_1302  -1
    order_2_14  connected_order_arc_1304  -1
    order_2_14  connected_order_arc_1306  -1
    order_2_14  connected_order_arc_1317  1
    order_2_14  connected_order_arc_1342  1
    order_2_14  connected_order_arc_1367  1
    order_2_14  connected_order_arc_1392  1
    order_2_14  connected_order_arc_1417  1
    order_2_14  connected_order_arc_1442  1
    order_2_14  connected_order_arc_1467  1
    order_2_14  connected_order_arc_1492  1
    order_2_14  order_active_lb_1539  1
    order_2_14  order_active_ub_1540  1
    order_2_14  fixed_segment_relative_order_1595  1
    visit_2_15  out_degree_1544  -1
    visit_2_15  in_degree_1545  -1
    visit_2_15  order_active_lb_1546  -1
    visit_2_15  order_active_ub_1547  -13
    visit_2_15  service_visit_def_1548  -1
    order_2_15  connected_order_arc_1192  1
    order_2_15  connected_order_arc_1217  1
    order_2_15  connected_order_arc_1242  1
    order_2_15  connected_order_arc_1267  1
    order_2_15  connected_order_arc_1292  1
    order_2_15  connected_order_arc_1309  -1
    order_2_15  connected_order_arc_1311  -1
    order_2_15  connected_order_arc_1313  -1
    order_2_15  connected_order_arc_1315  -1
    order_2_15  connected_order_arc_1317  -1
    order_2_15  connected_order_arc_1319  -1
    order_2_15  connected_order_arc_1321  -1
    order_2_15  connected_order_arc_1323  -1
    order_2_15  connected_order_arc_1325  -1
    order_2_15  connected_order_arc_1327  -1
    order_2_15  connected_order_arc_1329  -1
    order_2_15  connected_order_arc_1331  -1
    order_2_15  connected_order_arc_1344  1
    order_2_15  connected_order_arc_1369  1
    order_2_15  connected_order_arc_1394  1
    order_2_15  connected_order_arc_1419  1
    order_2_15  connected_order_arc_1444  1
    order_2_15  connected_order_arc_1469  1
    order_2_15  connected_order_arc_1494  1
    order_2_15  order_active_lb_1546  1
    order_2_15  order_active_ub_1547  1
    visit_2_16  out_degree_1550  -1
    visit_2_16  in_degree_1551  -1
    visit_2_16  order_active_lb_1552  -1
    visit_2_16  order_active_ub_1553  -13
    visit_2_16  service_visit_def_1554  -1
    order_2_16  connected_order_arc_1194  1
    order_2_16  connected_order_arc_1219  1
    order_2_16  connected_order_arc_1244  1
    order_2_16  connected_order_arc_1269  1
    order_2_16  connected_order_arc_1294  1
    order_2_16  connected_order_arc_1319  1
    order_2_16  connected_order_arc_1334  -1
    order_2_16  connected_order_arc_1336  -1
    order_2_16  connected_order_arc_1338  -1
    order_2_16  connected_order_arc_1340  -1
    order_2_16  connected_order_arc_1342  -1
    order_2_16  connected_order_arc_1344  -1
    order_2_16  connected_order_arc_1346  -1
    order_2_16  connected_order_arc_1348  -1
    order_2_16  connected_order_arc_1350  -1
    order_2_16  connected_order_arc_1352  -1
    order_2_16  connected_order_arc_1354  -1
    order_2_16  connected_order_arc_1356  -1
    order_2_16  connected_order_arc_1371  1
    order_2_16  connected_order_arc_1396  1
    order_2_16  connected_order_arc_1421  1
    order_2_16  connected_order_arc_1446  1
    order_2_16  connected_order_arc_1471  1
    order_2_16  connected_order_arc_1496  1
    order_2_16  order_active_lb_1552  1
    order_2_16  order_active_ub_1553  1
    visit_2_17  out_degree_1556  -1
    visit_2_17  in_degree_1557  -1
    visit_2_17  order_active_lb_1558  -1
    visit_2_17  order_active_ub_1559  -13
    visit_2_17  service_visit_def_1560  -1
    order_2_17  connected_order_arc_1196  1
    order_2_17  connected_order_arc_1221  1
    order_2_17  connected_order_arc_1246  1
    order_2_17  connected_order_arc_1271  1
    order_2_17  connected_order_arc_1296  1
    order_2_17  connected_order_arc_1321  1
    order_2_17  connected_order_arc_1346  1
    order_2_17  connected_order_arc_1359  -1
    order_2_17  connected_order_arc_1361  -1
    order_2_17  connected_order_arc_1363  -1
    order_2_17  connected_order_arc_1365  -1
    order_2_17  connected_order_arc_1367  -1
    order_2_17  connected_order_arc_1369  -1
    order_2_17  connected_order_arc_1371  -1
    order_2_17  connected_order_arc_1373  -1
    order_2_17  connected_order_arc_1375  -1
    order_2_17  connected_order_arc_1377  -1
    order_2_17  connected_order_arc_1379  -1
    order_2_17  connected_order_arc_1381  -1
    order_2_17  connected_order_arc_1398  1
    order_2_17  connected_order_arc_1423  1
    order_2_17  connected_order_arc_1448  1
    order_2_17  connected_order_arc_1473  1
    order_2_17  connected_order_arc_1498  1
    order_2_17  order_active_lb_1558  1
    order_2_17  order_active_ub_1559  1
    visit_2_18  out_degree_1562  -1
    visit_2_18  in_degree_1563  -1
    visit_2_18  order_active_lb_1564  -1
    visit_2_18  order_active_ub_1565  -13
    visit_2_18  service_visit_def_1566  -1
    order_2_18  connected_order_arc_1198  1
    order_2_18  connected_order_arc_1223  1
    order_2_18  connected_order_arc_1248  1
    order_2_18  connected_order_arc_1273  1
    order_2_18  connected_order_arc_1298  1
    order_2_18  connected_order_arc_1323  1
    order_2_18  connected_order_arc_1348  1
    order_2_18  connected_order_arc_1373  1
    order_2_18  connected_order_arc_1384  -1
    order_2_18  connected_order_arc_1386  -1
    order_2_18  connected_order_arc_1388  -1
    order_2_18  connected_order_arc_1390  -1
    order_2_18  connected_order_arc_1392  -1
    order_2_18  connected_order_arc_1394  -1
    order_2_18  connected_order_arc_1396  -1
    order_2_18  connected_order_arc_1398  -1
    order_2_18  connected_order_arc_1400  -1
    order_2_18  connected_order_arc_1402  -1
    order_2_18  connected_order_arc_1404  -1
    order_2_18  connected_order_arc_1406  -1
    order_2_18  connected_order_arc_1425  1
    order_2_18  connected_order_arc_1450  1
    order_2_18  connected_order_arc_1475  1
    order_2_18  connected_order_arc_1500  1
    order_2_18  order_active_lb_1564  1
    order_2_18  order_active_ub_1565  1
    visit_2_19  out_degree_1568  -1
    visit_2_19  in_degree_1569  -1
    visit_2_19  order_active_lb_1570  -1
    visit_2_19  order_active_ub_1571  -13
    visit_2_19  service_visit_def_1572  -1
    order_2_19  connected_order_arc_1200  1
    order_2_19  connected_order_arc_1225  1
    order_2_19  connected_order_arc_1250  1
    order_2_19  connected_order_arc_1275  1
    order_2_19  connected_order_arc_1300  1
    order_2_19  connected_order_arc_1325  1
    order_2_19  connected_order_arc_1350  1
    order_2_19  connected_order_arc_1375  1
    order_2_19  connected_order_arc_1400  1
    order_2_19  connected_order_arc_1409  -1
    order_2_19  connected_order_arc_1411  -1
    order_2_19  connected_order_arc_1413  -1
    order_2_19  connected_order_arc_1415  -1
    order_2_19  connected_order_arc_1417  -1
    order_2_19  connected_order_arc_1419  -1
    order_2_19  connected_order_arc_1421  -1
    order_2_19  connected_order_arc_1423  -1
    order_2_19  connected_order_arc_1425  -1
    order_2_19  connected_order_arc_1427  -1
    order_2_19  connected_order_arc_1429  -1
    order_2_19  connected_order_arc_1431  -1
    order_2_19  connected_order_arc_1452  1
    order_2_19  connected_order_arc_1477  1
    order_2_19  connected_order_arc_1502  1
    order_2_19  order_active_lb_1570  1
    order_2_19  order_active_ub_1571  1
    visit_2_20  out_degree_1574  -1
    visit_2_20  in_degree_1575  -1
    visit_2_20  order_active_lb_1576  -1
    visit_2_20  order_active_ub_1577  -13
    visit_2_20  service_visit_def_1578  -1
    order_2_20  connected_order_arc_1202  1
    order_2_20  connected_order_arc_1227  1
    order_2_20  connected_order_arc_1252  1
    order_2_20  connected_order_arc_1277  1
    order_2_20  connected_order_arc_1302  1
    order_2_20  connected_order_arc_1327  1
    order_2_20  connected_order_arc_1352  1
    order_2_20  connected_order_arc_1377  1
    order_2_20  connected_order_arc_1402  1
    order_2_20  connected_order_arc_1427  1
    order_2_20  connected_order_arc_1434  -1
    order_2_20  connected_order_arc_1436  -1
    order_2_20  connected_order_arc_1438  -1
    order_2_20  connected_order_arc_1440  -1
    order_2_20  connected_order_arc_1442  -1
    order_2_20  connected_order_arc_1444  -1
    order_2_20  connected_order_arc_1446  -1
    order_2_20  connected_order_arc_1448  -1
    order_2_20  connected_order_arc_1450  -1
    order_2_20  connected_order_arc_1452  -1
    order_2_20  connected_order_arc_1454  -1
    order_2_20  connected_order_arc_1456  -1
    order_2_20  connected_order_arc_1479  1
    order_2_20  connected_order_arc_1504  1
    order_2_20  order_active_lb_1576  1
    order_2_20  order_active_ub_1577  1
    visit_2_21  out_degree_1580  -1
    visit_2_21  in_degree_1581  -1
    visit_2_21  order_active_lb_1582  -1
    visit_2_21  order_active_ub_1583  -13
    visit_2_21  service_visit_def_1584  -1
    order_2_21  connected_order_arc_1204  1
    order_2_21  connected_order_arc_1229  1
    order_2_21  connected_order_arc_1254  1
    order_2_21  connected_order_arc_1279  1
    order_2_21  connected_order_arc_1304  1
    order_2_21  connected_order_arc_1329  1
    order_2_21  connected_order_arc_1354  1
    order_2_21  connected_order_arc_1379  1
    order_2_21  connected_order_arc_1404  1
    order_2_21  connected_order_arc_1429  1
    order_2_21  connected_order_arc_1454  1
    order_2_21  connected_order_arc_1459  -1
    order_2_21  connected_order_arc_1461  -1
    order_2_21  connected_order_arc_1463  -1
    order_2_21  connected_order_arc_1465  -1
    order_2_21  connected_order_arc_1467  -1
    order_2_21  connected_order_arc_1469  -1
    order_2_21  connected_order_arc_1471  -1
    order_2_21  connected_order_arc_1473  -1
    order_2_21  connected_order_arc_1475  -1
    order_2_21  connected_order_arc_1477  -1
    order_2_21  connected_order_arc_1479  -1
    order_2_21  connected_order_arc_1481  -1
    order_2_21  connected_order_arc_1506  1
    order_2_21  order_active_lb_1582  1
    order_2_21  order_active_ub_1583  1
    visit_2_22  out_degree_1586  -1
    visit_2_22  in_degree_1587  -1
    visit_2_22  order_active_lb_1588  -1
    visit_2_22  order_active_ub_1589  -13
    visit_2_22  service_visit_def_1590  -1
    order_2_22  connected_order_arc_1206  1
    order_2_22  connected_order_arc_1231  1
    order_2_22  connected_order_arc_1256  1
    order_2_22  connected_order_arc_1281  1
    order_2_22  connected_order_arc_1306  1
    order_2_22  connected_order_arc_1331  1
    order_2_22  connected_order_arc_1356  1
    order_2_22  connected_order_arc_1381  1
    order_2_22  connected_order_arc_1406  1
    order_2_22  connected_order_arc_1431  1
    order_2_22  connected_order_arc_1456  1
    order_2_22  connected_order_arc_1481  1
    order_2_22  connected_order_arc_1484  -1
    order_2_22  connected_order_arc_1486  -1
    order_2_22  connected_order_arc_1488  -1
    order_2_22  connected_order_arc_1490  -1
    order_2_22  connected_order_arc_1492  -1
    order_2_22  connected_order_arc_1494  -1
    order_2_22  connected_order_arc_1496  -1
    order_2_22  connected_order_arc_1498  -1
    order_2_22  connected_order_arc_1500  -1
    order_2_22  connected_order_arc_1502  -1
    order_2_22  connected_order_arc_1504  -1
    order_2_22  connected_order_arc_1506  -1
    order_2_22  order_active_lb_1588  1
    order_2_22  order_active_ub_1589  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1168  -30
    arc_2_0_0  depot_departure_or_bypass_1507  1
    arc_2_0_0  depot_return_or_bypass_1508  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1168  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1169  -30
    arc_2_0_10  depot_departure_or_bypass_1507  1
    arc_2_0_10  in_degree_1510  1
    arc_2_0_10  original_T_including_depot_unload_1596  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1169  1
    load_2_0_10  segment_load_conservation_1513  -1
    load_2_0_10  segment_prefix_lb_1514  1
    load_2_0_10  segment_prefix_ub_1515  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1170  -30
    arc_2_0_11  depot_departure_or_bypass_1507  1
    arc_2_0_11  in_degree_1517  1
    arc_2_0_11  original_T_including_depot_unload_1596  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1170  1
    load_2_0_11  segment_load_conservation_1520  -1
    load_2_0_11  segment_prefix_lb_1521  1
    load_2_0_11  segment_prefix_ub_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1171  -30
    arc_2_0_12  depot_departure_or_bypass_1507  1
    arc_2_0_12  in_degree_1524  1
    arc_2_0_12  original_T_including_depot_unload_1596  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1171  1
    load_2_0_12  segment_load_conservation_1527  -1
    load_2_0_12  segment_prefix_lb_1528  1
    load_2_0_12  segment_prefix_ub_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1172  -30
    arc_2_0_13  depot_departure_or_bypass_1507  1
    arc_2_0_13  in_degree_1531  1
    arc_2_0_13  original_T_including_depot_unload_1596  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1172  1
    load_2_0_13  segment_load_conservation_1534  -1
    load_2_0_13  segment_prefix_lb_1535  1
    load_2_0_13  segment_prefix_ub_1536  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1173  -30
    arc_2_0_14  depot_departure_or_bypass_1507  1
    arc_2_0_14  in_degree_1538  1
    arc_2_0_14  original_T_including_depot_unload_1596  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1173  1
    load_2_0_14  segment_load_conservation_1541  -1
    load_2_0_14  segment_prefix_lb_1542  1
    load_2_0_14  segment_prefix_ub_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1174  -30
    arc_2_0_15  depot_departure_or_bypass_1507  1
    arc_2_0_15  in_degree_1545  1
    arc_2_0_15  original_T_including_depot_unload_1596  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1174  1
    load_2_0_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1175  -30
    arc_2_0_16  depot_departure_or_bypass_1507  1
    arc_2_0_16  in_degree_1551  1
    arc_2_0_16  original_T_including_depot_unload_1596  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1175  1
    load_2_0_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1176  -30
    arc_2_0_17  depot_departure_or_bypass_1507  1
    arc_2_0_17  in_degree_1557  1
    arc_2_0_17  original_T_including_depot_unload_1596  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1176  1
    load_2_0_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1177  -30
    arc_2_0_18  depot_departure_or_bypass_1507  1
    arc_2_0_18  in_degree_1563  1
    arc_2_0_18  original_T_including_depot_unload_1596  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1177  1
    load_2_0_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1178  -30
    arc_2_0_19  depot_departure_or_bypass_1507  1
    arc_2_0_19  in_degree_1569  1
    arc_2_0_19  original_T_including_depot_unload_1596  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1178  1
    load_2_0_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1179  -30
    arc_2_0_20  depot_departure_or_bypass_1507  1
    arc_2_0_20  in_degree_1575  1
    arc_2_0_20  original_T_including_depot_unload_1596  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1179  1
    load_2_0_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1180  -30
    arc_2_0_21  depot_departure_or_bypass_1507  1
    arc_2_0_21  in_degree_1581  1
    arc_2_0_21  original_T_including_depot_unload_1596  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1180  1
    load_2_0_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_22  arc_capacity_1181  -30
    arc_2_0_22  depot_departure_or_bypass_1507  1
    arc_2_0_22  in_degree_1587  1
    arc_2_0_22  original_T_including_depot_unload_1596  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_22  arc_capacity_1181  1
    load_2_0_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1182  -30
    arc_2_10_0  depot_return_or_bypass_1508  1
    arc_2_10_0  out_degree_1509  1
    arc_2_10_0  original_T_including_depot_unload_1596  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1182  1
    load_2_10_0  segment_load_conservation_1513  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1183  -30
    arc_2_10_11  connected_order_arc_1184  -14
    arc_2_10_11  out_degree_1509  1
    arc_2_10_11  in_degree_1517  1
    arc_2_10_11  original_T_including_depot_unload_1596  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1183  1
    load_2_10_11  segment_load_conservation_1513  1
    load_2_10_11  segment_load_conservation_1520  -1
    load_2_10_11  segment_prefix_lb_1521  1
    load_2_10_11  segment_prefix_ub_1522  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1185  -30
    arc_2_10_12  connected_order_arc_1186  -14
    arc_2_10_12  out_degree_1509  1
    arc_2_10_12  in_degree_1524  1
    arc_2_10_12  original_T_including_depot_unload_1596  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1185  1
    load_2_10_12  segment_load_conservation_1513  1
    load_2_10_12  segment_load_conservation_1527  -1
    load_2_10_12  segment_prefix_lb_1528  1
    load_2_10_12  segment_prefix_ub_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1187  -30
    arc_2_10_13  connected_order_arc_1188  -14
    arc_2_10_13  out_degree_1509  1
    arc_2_10_13  in_degree_1531  1
    arc_2_10_13  original_T_including_depot_unload_1596  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1187  1
    load_2_10_13  segment_load_conservation_1513  1
    load_2_10_13  segment_load_conservation_1534  -1
    load_2_10_13  segment_prefix_lb_1535  1
    load_2_10_13  segment_prefix_ub_1536  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1189  -30
    arc_2_10_14  connected_order_arc_1190  -14
    arc_2_10_14  out_degree_1509  1
    arc_2_10_14  in_degree_1538  1
    arc_2_10_14  original_T_including_depot_unload_1596  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1189  1
    load_2_10_14  segment_load_conservation_1513  1
    load_2_10_14  segment_load_conservation_1541  -1
    load_2_10_14  segment_prefix_lb_1542  1
    load_2_10_14  segment_prefix_ub_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1191  -30
    arc_2_10_15  connected_order_arc_1192  -14
    arc_2_10_15  out_degree_1509  1
    arc_2_10_15  in_degree_1545  1
    arc_2_10_15  original_T_including_depot_unload_1596  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1191  1
    load_2_10_15  segment_load_conservation_1513  1
    load_2_10_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1193  -30
    arc_2_10_16  connected_order_arc_1194  -14
    arc_2_10_16  out_degree_1509  1
    arc_2_10_16  in_degree_1551  1
    arc_2_10_16  original_T_including_depot_unload_1596  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1193  1
    load_2_10_16  segment_load_conservation_1513  1
    load_2_10_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1195  -30
    arc_2_10_17  connected_order_arc_1196  -14
    arc_2_10_17  out_degree_1509  1
    arc_2_10_17  in_degree_1557  1
    arc_2_10_17  original_T_including_depot_unload_1596  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1195  1
    load_2_10_17  segment_load_conservation_1513  1
    load_2_10_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1197  -30
    arc_2_10_18  connected_order_arc_1198  -14
    arc_2_10_18  out_degree_1509  1
    arc_2_10_18  in_degree_1563  1
    arc_2_10_18  original_T_including_depot_unload_1596  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1197  1
    load_2_10_18  segment_load_conservation_1513  1
    load_2_10_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1199  -30
    arc_2_10_19  connected_order_arc_1200  -14
    arc_2_10_19  out_degree_1509  1
    arc_2_10_19  in_degree_1569  1
    arc_2_10_19  original_T_including_depot_unload_1596  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1199  1
    load_2_10_19  segment_load_conservation_1513  1
    load_2_10_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1201  -30
    arc_2_10_20  connected_order_arc_1202  -14
    arc_2_10_20  out_degree_1509  1
    arc_2_10_20  in_degree_1575  1
    arc_2_10_20  original_T_including_depot_unload_1596  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1201  1
    load_2_10_20  segment_load_conservation_1513  1
    load_2_10_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1203  -30
    arc_2_10_21  connected_order_arc_1204  -14
    arc_2_10_21  out_degree_1509  1
    arc_2_10_21  in_degree_1581  1
    arc_2_10_21  original_T_including_depot_unload_1596  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1203  1
    load_2_10_21  segment_load_conservation_1513  1
    load_2_10_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_22  arc_capacity_1205  -30
    arc_2_10_22  connected_order_arc_1206  -14
    arc_2_10_22  out_degree_1509  1
    arc_2_10_22  in_degree_1587  1
    arc_2_10_22  original_T_including_depot_unload_1596  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_22  arc_capacity_1205  1
    load_2_10_22  segment_load_conservation_1513  1
    load_2_10_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1207  -30
    arc_2_11_0  depot_return_or_bypass_1508  1
    arc_2_11_0  out_degree_1516  1
    arc_2_11_0  original_T_including_depot_unload_1596  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1207  1
    load_2_11_0  segment_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1208  -30
    arc_2_11_10  connected_order_arc_1209  -14
    arc_2_11_10  in_degree_1510  1
    arc_2_11_10  out_degree_1516  1
    arc_2_11_10  original_T_including_depot_unload_1596  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1208  1
    load_2_11_10  segment_load_conservation_1513  -1
    load_2_11_10  segment_prefix_lb_1514  1
    load_2_11_10  segment_prefix_ub_1515  1
    load_2_11_10  segment_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1210  -30
    arc_2_11_12  connected_order_arc_1211  -14
    arc_2_11_12  out_degree_1516  1
    arc_2_11_12  in_degree_1524  1
    arc_2_11_12  original_T_including_depot_unload_1596  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1210  1
    load_2_11_12  segment_load_conservation_1520  1
    load_2_11_12  segment_load_conservation_1527  -1
    load_2_11_12  segment_prefix_lb_1528  1
    load_2_11_12  segment_prefix_ub_1529  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1212  -30
    arc_2_11_13  connected_order_arc_1213  -14
    arc_2_11_13  out_degree_1516  1
    arc_2_11_13  in_degree_1531  1
    arc_2_11_13  original_T_including_depot_unload_1596  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1212  1
    load_2_11_13  segment_load_conservation_1520  1
    load_2_11_13  segment_load_conservation_1534  -1
    load_2_11_13  segment_prefix_lb_1535  1
    load_2_11_13  segment_prefix_ub_1536  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1214  -30
    arc_2_11_14  connected_order_arc_1215  -14
    arc_2_11_14  out_degree_1516  1
    arc_2_11_14  in_degree_1538  1
    arc_2_11_14  original_T_including_depot_unload_1596  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1214  1
    load_2_11_14  segment_load_conservation_1520  1
    load_2_11_14  segment_load_conservation_1541  -1
    load_2_11_14  segment_prefix_lb_1542  1
    load_2_11_14  segment_prefix_ub_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1216  -30
    arc_2_11_15  connected_order_arc_1217  -14
    arc_2_11_15  out_degree_1516  1
    arc_2_11_15  in_degree_1545  1
    arc_2_11_15  original_T_including_depot_unload_1596  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1216  1
    load_2_11_15  segment_load_conservation_1520  1
    load_2_11_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1218  -30
    arc_2_11_16  connected_order_arc_1219  -14
    arc_2_11_16  out_degree_1516  1
    arc_2_11_16  in_degree_1551  1
    arc_2_11_16  original_T_including_depot_unload_1596  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1218  1
    load_2_11_16  segment_load_conservation_1520  1
    load_2_11_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1220  -30
    arc_2_11_17  connected_order_arc_1221  -14
    arc_2_11_17  out_degree_1516  1
    arc_2_11_17  in_degree_1557  1
    arc_2_11_17  original_T_including_depot_unload_1596  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1220  1
    load_2_11_17  segment_load_conservation_1520  1
    load_2_11_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1222  -30
    arc_2_11_18  connected_order_arc_1223  -14
    arc_2_11_18  out_degree_1516  1
    arc_2_11_18  in_degree_1563  1
    arc_2_11_18  original_T_including_depot_unload_1596  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1222  1
    load_2_11_18  segment_load_conservation_1520  1
    load_2_11_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1224  -30
    arc_2_11_19  connected_order_arc_1225  -14
    arc_2_11_19  out_degree_1516  1
    arc_2_11_19  in_degree_1569  1
    arc_2_11_19  original_T_including_depot_unload_1596  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1224  1
    load_2_11_19  segment_load_conservation_1520  1
    load_2_11_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1226  -30
    arc_2_11_20  connected_order_arc_1227  -14
    arc_2_11_20  out_degree_1516  1
    arc_2_11_20  in_degree_1575  1
    arc_2_11_20  original_T_including_depot_unload_1596  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1226  1
    load_2_11_20  segment_load_conservation_1520  1
    load_2_11_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1228  -30
    arc_2_11_21  connected_order_arc_1229  -14
    arc_2_11_21  out_degree_1516  1
    arc_2_11_21  in_degree_1581  1
    arc_2_11_21  original_T_including_depot_unload_1596  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1228  1
    load_2_11_21  segment_load_conservation_1520  1
    load_2_11_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_22  arc_capacity_1230  -30
    arc_2_11_22  connected_order_arc_1231  -14
    arc_2_11_22  out_degree_1516  1
    arc_2_11_22  in_degree_1587  1
    arc_2_11_22  original_T_including_depot_unload_1596  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_22  arc_capacity_1230  1
    load_2_11_22  segment_load_conservation_1520  1
    load_2_11_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1232  -30
    arc_2_12_0  depot_return_or_bypass_1508  1
    arc_2_12_0  out_degree_1523  1
    arc_2_12_0  original_T_including_depot_unload_1596  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1232  1
    load_2_12_0  segment_load_conservation_1527  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1233  -30
    arc_2_12_10  connected_order_arc_1234  -14
    arc_2_12_10  in_degree_1510  1
    arc_2_12_10  out_degree_1523  1
    arc_2_12_10  original_T_including_depot_unload_1596  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1233  1
    load_2_12_10  segment_load_conservation_1513  -1
    load_2_12_10  segment_prefix_lb_1514  1
    load_2_12_10  segment_prefix_ub_1515  1
    load_2_12_10  segment_load_conservation_1527  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1235  -30
    arc_2_12_11  connected_order_arc_1236  -14
    arc_2_12_11  in_degree_1517  1
    arc_2_12_11  out_degree_1523  1
    arc_2_12_11  original_T_including_depot_unload_1596  4.8781034218421996e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1235  1
    load_2_12_11  segment_load_conservation_1520  -1
    load_2_12_11  segment_prefix_lb_1521  1
    load_2_12_11  segment_prefix_ub_1522  1
    load_2_12_11  segment_load_conservation_1527  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1237  -30
    arc_2_12_13  connected_order_arc_1238  -14
    arc_2_12_13  out_degree_1523  1
    arc_2_12_13  in_degree_1531  1
    arc_2_12_13  original_T_including_depot_unload_1596  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1237  1
    load_2_12_13  segment_load_conservation_1527  1
    load_2_12_13  segment_load_conservation_1534  -1
    load_2_12_13  segment_prefix_lb_1535  1
    load_2_12_13  segment_prefix_ub_1536  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1239  -30
    arc_2_12_14  connected_order_arc_1240  -14
    arc_2_12_14  out_degree_1523  1
    arc_2_12_14  in_degree_1538  1
    arc_2_12_14  original_T_including_depot_unload_1596  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1239  1
    load_2_12_14  segment_load_conservation_1527  1
    load_2_12_14  segment_load_conservation_1541  -1
    load_2_12_14  segment_prefix_lb_1542  1
    load_2_12_14  segment_prefix_ub_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1241  -30
    arc_2_12_15  connected_order_arc_1242  -14
    arc_2_12_15  out_degree_1523  1
    arc_2_12_15  in_degree_1545  1
    arc_2_12_15  original_T_including_depot_unload_1596  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1241  1
    load_2_12_15  segment_load_conservation_1527  1
    load_2_12_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1243  -30
    arc_2_12_16  connected_order_arc_1244  -14
    arc_2_12_16  out_degree_1523  1
    arc_2_12_16  in_degree_1551  1
    arc_2_12_16  original_T_including_depot_unload_1596  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1243  1
    load_2_12_16  segment_load_conservation_1527  1
    load_2_12_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1245  -30
    arc_2_12_17  connected_order_arc_1246  -14
    arc_2_12_17  out_degree_1523  1
    arc_2_12_17  in_degree_1557  1
    arc_2_12_17  original_T_including_depot_unload_1596  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1245  1
    load_2_12_17  segment_load_conservation_1527  1
    load_2_12_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1247  -30
    arc_2_12_18  connected_order_arc_1248  -14
    arc_2_12_18  out_degree_1523  1
    arc_2_12_18  in_degree_1563  1
    arc_2_12_18  original_T_including_depot_unload_1596  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1247  1
    load_2_12_18  segment_load_conservation_1527  1
    load_2_12_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1249  -30
    arc_2_12_19  connected_order_arc_1250  -14
    arc_2_12_19  out_degree_1523  1
    arc_2_12_19  in_degree_1569  1
    arc_2_12_19  original_T_including_depot_unload_1596  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1249  1
    load_2_12_19  segment_load_conservation_1527  1
    load_2_12_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1251  -30
    arc_2_12_20  connected_order_arc_1252  -14
    arc_2_12_20  out_degree_1523  1
    arc_2_12_20  in_degree_1575  1
    arc_2_12_20  original_T_including_depot_unload_1596  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1251  1
    load_2_12_20  segment_load_conservation_1527  1
    load_2_12_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1253  -30
    arc_2_12_21  connected_order_arc_1254  -14
    arc_2_12_21  out_degree_1523  1
    arc_2_12_21  in_degree_1581  1
    arc_2_12_21  original_T_including_depot_unload_1596  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1253  1
    load_2_12_21  segment_load_conservation_1527  1
    load_2_12_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_22  arc_capacity_1255  -30
    arc_2_12_22  connected_order_arc_1256  -14
    arc_2_12_22  out_degree_1523  1
    arc_2_12_22  in_degree_1587  1
    arc_2_12_22  original_T_including_depot_unload_1596  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_22  arc_capacity_1255  1
    load_2_12_22  segment_load_conservation_1527  1
    load_2_12_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1257  -30
    arc_2_13_0  depot_return_or_bypass_1508  1
    arc_2_13_0  out_degree_1530  1
    arc_2_13_0  original_T_including_depot_unload_1596  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1257  1
    load_2_13_0  segment_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1258  -30
    arc_2_13_10  connected_order_arc_1259  -14
    arc_2_13_10  in_degree_1510  1
    arc_2_13_10  out_degree_1530  1
    arc_2_13_10  original_T_including_depot_unload_1596  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1258  1
    load_2_13_10  segment_load_conservation_1513  -1
    load_2_13_10  segment_prefix_lb_1514  1
    load_2_13_10  segment_prefix_ub_1515  1
    load_2_13_10  segment_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1260  -30
    arc_2_13_11  connected_order_arc_1261  -14
    arc_2_13_11  in_degree_1517  1
    arc_2_13_11  out_degree_1530  1
    arc_2_13_11  original_T_including_depot_unload_1596  6.0985881995898160e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1260  1
    load_2_13_11  segment_load_conservation_1520  -1
    load_2_13_11  segment_prefix_lb_1521  1
    load_2_13_11  segment_prefix_ub_1522  1
    load_2_13_11  segment_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1262  -30
    arc_2_13_12  connected_order_arc_1263  -14
    arc_2_13_12  in_degree_1524  1
    arc_2_13_12  out_degree_1530  1
    arc_2_13_12  original_T_including_depot_unload_1596  5.0525672969651123e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1262  1
    load_2_13_12  segment_load_conservation_1527  -1
    load_2_13_12  segment_prefix_lb_1528  1
    load_2_13_12  segment_prefix_ub_1529  1
    load_2_13_12  segment_load_conservation_1534  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1264  -30
    arc_2_13_14  connected_order_arc_1265  -14
    arc_2_13_14  out_degree_1530  1
    arc_2_13_14  in_degree_1538  1
    arc_2_13_14  original_T_including_depot_unload_1596  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1264  1
    load_2_13_14  segment_load_conservation_1534  1
    load_2_13_14  segment_load_conservation_1541  -1
    load_2_13_14  segment_prefix_lb_1542  1
    load_2_13_14  segment_prefix_ub_1543  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1266  -30
    arc_2_13_15  connected_order_arc_1267  -14
    arc_2_13_15  out_degree_1530  1
    arc_2_13_15  in_degree_1545  1
    arc_2_13_15  original_T_including_depot_unload_1596  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1266  1
    load_2_13_15  segment_load_conservation_1534  1
    load_2_13_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1268  -30
    arc_2_13_16  connected_order_arc_1269  -14
    arc_2_13_16  out_degree_1530  1
    arc_2_13_16  in_degree_1551  1
    arc_2_13_16  original_T_including_depot_unload_1596  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1268  1
    load_2_13_16  segment_load_conservation_1534  1
    load_2_13_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1270  -30
    arc_2_13_17  connected_order_arc_1271  -14
    arc_2_13_17  out_degree_1530  1
    arc_2_13_17  in_degree_1557  1
    arc_2_13_17  original_T_including_depot_unload_1596  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1270  1
    load_2_13_17  segment_load_conservation_1534  1
    load_2_13_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1272  -30
    arc_2_13_18  connected_order_arc_1273  -14
    arc_2_13_18  out_degree_1530  1
    arc_2_13_18  in_degree_1563  1
    arc_2_13_18  original_T_including_depot_unload_1596  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1272  1
    load_2_13_18  segment_load_conservation_1534  1
    load_2_13_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1274  -30
    arc_2_13_19  connected_order_arc_1275  -14
    arc_2_13_19  out_degree_1530  1
    arc_2_13_19  in_degree_1569  1
    arc_2_13_19  original_T_including_depot_unload_1596  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1274  1
    load_2_13_19  segment_load_conservation_1534  1
    load_2_13_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1276  -30
    arc_2_13_20  connected_order_arc_1277  -14
    arc_2_13_20  out_degree_1530  1
    arc_2_13_20  in_degree_1575  1
    arc_2_13_20  original_T_including_depot_unload_1596  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1276  1
    load_2_13_20  segment_load_conservation_1534  1
    load_2_13_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1278  -30
    arc_2_13_21  connected_order_arc_1279  -14
    arc_2_13_21  out_degree_1530  1
    arc_2_13_21  in_degree_1581  1
    arc_2_13_21  original_T_including_depot_unload_1596  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1278  1
    load_2_13_21  segment_load_conservation_1534  1
    load_2_13_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_22  arc_capacity_1280  -30
    arc_2_13_22  connected_order_arc_1281  -14
    arc_2_13_22  out_degree_1530  1
    arc_2_13_22  in_degree_1587  1
    arc_2_13_22  original_T_including_depot_unload_1596  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_22  arc_capacity_1280  1
    load_2_13_22  segment_load_conservation_1534  1
    load_2_13_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1282  -30
    arc_2_14_0  depot_return_or_bypass_1508  1
    arc_2_14_0  out_degree_1537  1
    arc_2_14_0  original_T_including_depot_unload_1596  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1282  1
    load_2_14_0  segment_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1283  -30
    arc_2_14_10  connected_order_arc_1284  -14
    arc_2_14_10  in_degree_1510  1
    arc_2_14_10  out_degree_1537  1
    arc_2_14_10  original_T_including_depot_unload_1596  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1283  1
    load_2_14_10  segment_load_conservation_1513  -1
    load_2_14_10  segment_prefix_lb_1514  1
    load_2_14_10  segment_prefix_ub_1515  1
    load_2_14_10  segment_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1285  -30
    arc_2_14_11  connected_order_arc_1286  -14
    arc_2_14_11  in_degree_1517  1
    arc_2_14_11  out_degree_1537  1
    arc_2_14_11  original_T_including_depot_unload_1596  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1285  1
    load_2_14_11  segment_load_conservation_1520  -1
    load_2_14_11  segment_prefix_lb_1521  1
    load_2_14_11  segment_prefix_ub_1522  1
    load_2_14_11  segment_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1287  -30
    arc_2_14_12  connected_order_arc_1288  -14
    arc_2_14_12  in_degree_1524  1
    arc_2_14_12  out_degree_1537  1
    arc_2_14_12  original_T_including_depot_unload_1596  1.5757088859257728e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1287  1
    load_2_14_12  segment_load_conservation_1527  -1
    load_2_14_12  segment_prefix_lb_1528  1
    load_2_14_12  segment_prefix_ub_1529  1
    load_2_14_12  segment_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1289  -30
    arc_2_14_13  connected_order_arc_1290  -14
    arc_2_14_13  in_degree_1531  1
    arc_2_14_13  out_degree_1537  1
    arc_2_14_13  original_T_including_depot_unload_1596  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1289  1
    load_2_14_13  segment_load_conservation_1534  -1
    load_2_14_13  segment_prefix_lb_1535  1
    load_2_14_13  segment_prefix_ub_1536  1
    load_2_14_13  segment_load_conservation_1541  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1291  -30
    arc_2_14_15  connected_order_arc_1292  -14
    arc_2_14_15  out_degree_1537  1
    arc_2_14_15  in_degree_1545  1
    arc_2_14_15  original_T_including_depot_unload_1596  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1291  1
    load_2_14_15  segment_load_conservation_1541  1
    load_2_14_15  free_load_conservation_1549  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1293  -30
    arc_2_14_16  connected_order_arc_1294  -14
    arc_2_14_16  out_degree_1537  1
    arc_2_14_16  in_degree_1551  1
    arc_2_14_16  original_T_including_depot_unload_1596  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1293  1
    load_2_14_16  segment_load_conservation_1541  1
    load_2_14_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1295  -30
    arc_2_14_17  connected_order_arc_1296  -14
    arc_2_14_17  out_degree_1537  1
    arc_2_14_17  in_degree_1557  1
    arc_2_14_17  original_T_including_depot_unload_1596  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1295  1
    load_2_14_17  segment_load_conservation_1541  1
    load_2_14_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1297  -30
    arc_2_14_18  connected_order_arc_1298  -14
    arc_2_14_18  out_degree_1537  1
    arc_2_14_18  in_degree_1563  1
    arc_2_14_18  original_T_including_depot_unload_1596  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1297  1
    load_2_14_18  segment_load_conservation_1541  1
    load_2_14_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1299  -30
    arc_2_14_19  connected_order_arc_1300  -14
    arc_2_14_19  out_degree_1537  1
    arc_2_14_19  in_degree_1569  1
    arc_2_14_19  original_T_including_depot_unload_1596  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1299  1
    load_2_14_19  segment_load_conservation_1541  1
    load_2_14_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1301  -30
    arc_2_14_20  connected_order_arc_1302  -14
    arc_2_14_20  out_degree_1537  1
    arc_2_14_20  in_degree_1575  1
    arc_2_14_20  original_T_including_depot_unload_1596  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1301  1
    load_2_14_20  segment_load_conservation_1541  1
    load_2_14_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1303  -30
    arc_2_14_21  connected_order_arc_1304  -14
    arc_2_14_21  out_degree_1537  1
    arc_2_14_21  in_degree_1581  1
    arc_2_14_21  original_T_including_depot_unload_1596  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1303  1
    load_2_14_21  segment_load_conservation_1541  1
    load_2_14_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_22  arc_capacity_1305  -30
    arc_2_14_22  connected_order_arc_1306  -14
    arc_2_14_22  out_degree_1537  1
    arc_2_14_22  in_degree_1587  1
    arc_2_14_22  original_T_including_depot_unload_1596  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_22  arc_capacity_1305  1
    load_2_14_22  segment_load_conservation_1541  1
    load_2_14_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1307  -30
    arc_2_15_0  depot_return_or_bypass_1508  1
    arc_2_15_0  out_degree_1544  1
    arc_2_15_0  original_T_including_depot_unload_1596  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1307  1
    load_2_15_0  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1308  -30
    arc_2_15_10  connected_order_arc_1309  -14
    arc_2_15_10  in_degree_1510  1
    arc_2_15_10  out_degree_1544  1
    arc_2_15_10  original_T_including_depot_unload_1596  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1308  1
    load_2_15_10  segment_load_conservation_1513  -1
    load_2_15_10  segment_prefix_lb_1514  1
    load_2_15_10  segment_prefix_ub_1515  1
    load_2_15_10  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1310  -30
    arc_2_15_11  connected_order_arc_1311  -14
    arc_2_15_11  in_degree_1517  1
    arc_2_15_11  out_degree_1544  1
    arc_2_15_11  original_T_including_depot_unload_1596  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1310  1
    load_2_15_11  segment_load_conservation_1520  -1
    load_2_15_11  segment_prefix_lb_1521  1
    load_2_15_11  segment_prefix_ub_1522  1
    load_2_15_11  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1312  -30
    arc_2_15_12  connected_order_arc_1313  -14
    arc_2_15_12  in_degree_1524  1
    arc_2_15_12  out_degree_1544  1
    arc_2_15_12  original_T_including_depot_unload_1596  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1312  1
    load_2_15_12  segment_load_conservation_1527  -1
    load_2_15_12  segment_prefix_lb_1528  1
    load_2_15_12  segment_prefix_ub_1529  1
    load_2_15_12  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1314  -30
    arc_2_15_13  connected_order_arc_1315  -14
    arc_2_15_13  in_degree_1531  1
    arc_2_15_13  out_degree_1544  1
    arc_2_15_13  original_T_including_depot_unload_1596  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1314  1
    load_2_15_13  segment_load_conservation_1534  -1
    load_2_15_13  segment_prefix_lb_1535  1
    load_2_15_13  segment_prefix_ub_1536  1
    load_2_15_13  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1316  -30
    arc_2_15_14  connected_order_arc_1317  -14
    arc_2_15_14  in_degree_1538  1
    arc_2_15_14  out_degree_1544  1
    arc_2_15_14  original_T_including_depot_unload_1596  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1316  1
    load_2_15_14  segment_load_conservation_1541  -1
    load_2_15_14  segment_prefix_lb_1542  1
    load_2_15_14  segment_prefix_ub_1543  1
    load_2_15_14  free_load_conservation_1549  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1318  -30
    arc_2_15_16  connected_order_arc_1319  -14
    arc_2_15_16  out_degree_1544  1
    arc_2_15_16  in_degree_1551  1
    arc_2_15_16  original_T_including_depot_unload_1596  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1318  1
    load_2_15_16  free_load_conservation_1549  1
    load_2_15_16  free_load_conservation_1555  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1320  -30
    arc_2_15_17  connected_order_arc_1321  -14
    arc_2_15_17  out_degree_1544  1
    arc_2_15_17  in_degree_1557  1
    arc_2_15_17  original_T_including_depot_unload_1596  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1320  1
    load_2_15_17  free_load_conservation_1549  1
    load_2_15_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1322  -30
    arc_2_15_18  connected_order_arc_1323  -14
    arc_2_15_18  out_degree_1544  1
    arc_2_15_18  in_degree_1563  1
    arc_2_15_18  original_T_including_depot_unload_1596  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1322  1
    load_2_15_18  free_load_conservation_1549  1
    load_2_15_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1324  -30
    arc_2_15_19  connected_order_arc_1325  -14
    arc_2_15_19  out_degree_1544  1
    arc_2_15_19  in_degree_1569  1
    arc_2_15_19  original_T_including_depot_unload_1596  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1324  1
    load_2_15_19  free_load_conservation_1549  1
    load_2_15_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1326  -30
    arc_2_15_20  connected_order_arc_1327  -14
    arc_2_15_20  out_degree_1544  1
    arc_2_15_20  in_degree_1575  1
    arc_2_15_20  original_T_including_depot_unload_1596  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1326  1
    load_2_15_20  free_load_conservation_1549  1
    load_2_15_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1328  -30
    arc_2_15_21  connected_order_arc_1329  -14
    arc_2_15_21  out_degree_1544  1
    arc_2_15_21  in_degree_1581  1
    arc_2_15_21  original_T_including_depot_unload_1596  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1328  1
    load_2_15_21  free_load_conservation_1549  1
    load_2_15_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_22  arc_capacity_1330  -30
    arc_2_15_22  connected_order_arc_1331  -14
    arc_2_15_22  out_degree_1544  1
    arc_2_15_22  in_degree_1587  1
    arc_2_15_22  original_T_including_depot_unload_1596  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_22  arc_capacity_1330  1
    load_2_15_22  free_load_conservation_1549  1
    load_2_15_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1332  -30
    arc_2_16_0  depot_return_or_bypass_1508  1
    arc_2_16_0  out_degree_1550  1
    arc_2_16_0  original_T_including_depot_unload_1596  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1332  1
    load_2_16_0  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1333  -30
    arc_2_16_10  connected_order_arc_1334  -14
    arc_2_16_10  in_degree_1510  1
    arc_2_16_10  out_degree_1550  1
    arc_2_16_10  original_T_including_depot_unload_1596  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1333  1
    load_2_16_10  segment_load_conservation_1513  -1
    load_2_16_10  segment_prefix_lb_1514  1
    load_2_16_10  segment_prefix_ub_1515  1
    load_2_16_10  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1335  -30
    arc_2_16_11  connected_order_arc_1336  -14
    arc_2_16_11  in_degree_1517  1
    arc_2_16_11  out_degree_1550  1
    arc_2_16_11  original_T_including_depot_unload_1596  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1335  1
    load_2_16_11  segment_load_conservation_1520  -1
    load_2_16_11  segment_prefix_lb_1521  1
    load_2_16_11  segment_prefix_ub_1522  1
    load_2_16_11  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1337  -30
    arc_2_16_12  connected_order_arc_1338  -14
    arc_2_16_12  in_degree_1524  1
    arc_2_16_12  out_degree_1550  1
    arc_2_16_12  original_T_including_depot_unload_1596  1.9853708143200565e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1337  1
    load_2_16_12  segment_load_conservation_1527  -1
    load_2_16_12  segment_prefix_lb_1528  1
    load_2_16_12  segment_prefix_ub_1529  1
    load_2_16_12  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1339  -30
    arc_2_16_13  connected_order_arc_1340  -14
    arc_2_16_13  in_degree_1531  1
    arc_2_16_13  out_degree_1550  1
    arc_2_16_13  original_T_including_depot_unload_1596  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1339  1
    load_2_16_13  segment_load_conservation_1534  -1
    load_2_16_13  segment_prefix_lb_1535  1
    load_2_16_13  segment_prefix_ub_1536  1
    load_2_16_13  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1341  -30
    arc_2_16_14  connected_order_arc_1342  -14
    arc_2_16_14  in_degree_1538  1
    arc_2_16_14  out_degree_1550  1
    arc_2_16_14  original_T_including_depot_unload_1596  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1341  1
    load_2_16_14  segment_load_conservation_1541  -1
    load_2_16_14  segment_prefix_lb_1542  1
    load_2_16_14  segment_prefix_ub_1543  1
    load_2_16_14  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1343  -30
    arc_2_16_15  connected_order_arc_1344  -14
    arc_2_16_15  in_degree_1545  1
    arc_2_16_15  out_degree_1550  1
    arc_2_16_15  original_T_including_depot_unload_1596  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1343  1
    load_2_16_15  free_load_conservation_1549  -1
    load_2_16_15  free_load_conservation_1555  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1345  -30
    arc_2_16_17  connected_order_arc_1346  -14
    arc_2_16_17  out_degree_1550  1
    arc_2_16_17  in_degree_1557  1
    arc_2_16_17  original_T_including_depot_unload_1596  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1345  1
    load_2_16_17  free_load_conservation_1555  1
    load_2_16_17  free_load_conservation_1561  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1347  -30
    arc_2_16_18  connected_order_arc_1348  -14
    arc_2_16_18  out_degree_1550  1
    arc_2_16_18  in_degree_1563  1
    arc_2_16_18  original_T_including_depot_unload_1596  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1347  1
    load_2_16_18  free_load_conservation_1555  1
    load_2_16_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1349  -30
    arc_2_16_19  connected_order_arc_1350  -14
    arc_2_16_19  out_degree_1550  1
    arc_2_16_19  in_degree_1569  1
    arc_2_16_19  original_T_including_depot_unload_1596  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1349  1
    load_2_16_19  free_load_conservation_1555  1
    load_2_16_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1351  -30
    arc_2_16_20  connected_order_arc_1352  -14
    arc_2_16_20  out_degree_1550  1
    arc_2_16_20  in_degree_1575  1
    arc_2_16_20  original_T_including_depot_unload_1596  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1351  1
    load_2_16_20  free_load_conservation_1555  1
    load_2_16_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1353  -30
    arc_2_16_21  connected_order_arc_1354  -14
    arc_2_16_21  out_degree_1550  1
    arc_2_16_21  in_degree_1581  1
    arc_2_16_21  original_T_including_depot_unload_1596  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1353  1
    load_2_16_21  free_load_conservation_1555  1
    load_2_16_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_22  arc_capacity_1355  -30
    arc_2_16_22  connected_order_arc_1356  -14
    arc_2_16_22  out_degree_1550  1
    arc_2_16_22  in_degree_1587  1
    arc_2_16_22  original_T_including_depot_unload_1596  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_22  arc_capacity_1355  1
    load_2_16_22  free_load_conservation_1555  1
    load_2_16_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1357  -30
    arc_2_17_0  depot_return_or_bypass_1508  1
    arc_2_17_0  out_degree_1556  1
    arc_2_17_0  original_T_including_depot_unload_1596  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1357  1
    load_2_17_0  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1358  -30
    arc_2_17_10  connected_order_arc_1359  -14
    arc_2_17_10  in_degree_1510  1
    arc_2_17_10  out_degree_1556  1
    arc_2_17_10  original_T_including_depot_unload_1596  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1358  1
    load_2_17_10  segment_load_conservation_1513  -1
    load_2_17_10  segment_prefix_lb_1514  1
    load_2_17_10  segment_prefix_ub_1515  1
    load_2_17_10  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1360  -30
    arc_2_17_11  connected_order_arc_1361  -14
    arc_2_17_11  in_degree_1517  1
    arc_2_17_11  out_degree_1556  1
    arc_2_17_11  original_T_including_depot_unload_1596  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1360  1
    load_2_17_11  segment_load_conservation_1520  -1
    load_2_17_11  segment_prefix_lb_1521  1
    load_2_17_11  segment_prefix_ub_1522  1
    load_2_17_11  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1362  -30
    arc_2_17_12  connected_order_arc_1363  -14
    arc_2_17_12  in_degree_1524  1
    arc_2_17_12  out_degree_1556  1
    arc_2_17_12  original_T_including_depot_unload_1596  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1362  1
    load_2_17_12  segment_load_conservation_1527  -1
    load_2_17_12  segment_prefix_lb_1528  1
    load_2_17_12  segment_prefix_ub_1529  1
    load_2_17_12  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1364  -30
    arc_2_17_13  connected_order_arc_1365  -14
    arc_2_17_13  in_degree_1531  1
    arc_2_17_13  out_degree_1556  1
    arc_2_17_13  original_T_including_depot_unload_1596  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1364  1
    load_2_17_13  segment_load_conservation_1534  -1
    load_2_17_13  segment_prefix_lb_1535  1
    load_2_17_13  segment_prefix_ub_1536  1
    load_2_17_13  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1366  -30
    arc_2_17_14  connected_order_arc_1367  -14
    arc_2_17_14  in_degree_1538  1
    arc_2_17_14  out_degree_1556  1
    arc_2_17_14  original_T_including_depot_unload_1596  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1366  1
    load_2_17_14  segment_load_conservation_1541  -1
    load_2_17_14  segment_prefix_lb_1542  1
    load_2_17_14  segment_prefix_ub_1543  1
    load_2_17_14  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1368  -30
    arc_2_17_15  connected_order_arc_1369  -14
    arc_2_17_15  in_degree_1545  1
    arc_2_17_15  out_degree_1556  1
    arc_2_17_15  original_T_including_depot_unload_1596  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1368  1
    load_2_17_15  free_load_conservation_1549  -1
    load_2_17_15  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1370  -30
    arc_2_17_16  connected_order_arc_1371  -14
    arc_2_17_16  in_degree_1551  1
    arc_2_17_16  out_degree_1556  1
    arc_2_17_16  original_T_including_depot_unload_1596  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1370  1
    load_2_17_16  free_load_conservation_1555  -1
    load_2_17_16  free_load_conservation_1561  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1372  -30
    arc_2_17_18  connected_order_arc_1373  -14
    arc_2_17_18  out_degree_1556  1
    arc_2_17_18  in_degree_1563  1
    arc_2_17_18  original_T_including_depot_unload_1596  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1372  1
    load_2_17_18  free_load_conservation_1561  1
    load_2_17_18  free_load_conservation_1567  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1374  -30
    arc_2_17_19  connected_order_arc_1375  -14
    arc_2_17_19  out_degree_1556  1
    arc_2_17_19  in_degree_1569  1
    arc_2_17_19  original_T_including_depot_unload_1596  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1374  1
    load_2_17_19  free_load_conservation_1561  1
    load_2_17_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1376  -30
    arc_2_17_20  connected_order_arc_1377  -14
    arc_2_17_20  out_degree_1556  1
    arc_2_17_20  in_degree_1575  1
    arc_2_17_20  original_T_including_depot_unload_1596  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1376  1
    load_2_17_20  free_load_conservation_1561  1
    load_2_17_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1378  -30
    arc_2_17_21  connected_order_arc_1379  -14
    arc_2_17_21  out_degree_1556  1
    arc_2_17_21  in_degree_1581  1
    arc_2_17_21  original_T_including_depot_unload_1596  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1378  1
    load_2_17_21  free_load_conservation_1561  1
    load_2_17_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_22  arc_capacity_1380  -30
    arc_2_17_22  connected_order_arc_1381  -14
    arc_2_17_22  out_degree_1556  1
    arc_2_17_22  in_degree_1587  1
    arc_2_17_22  original_T_including_depot_unload_1596  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_22  arc_capacity_1380  1
    load_2_17_22  free_load_conservation_1561  1
    load_2_17_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1382  -30
    arc_2_18_0  depot_return_or_bypass_1508  1
    arc_2_18_0  out_degree_1562  1
    arc_2_18_0  original_T_including_depot_unload_1596  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1382  1
    load_2_18_0  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1383  -30
    arc_2_18_10  connected_order_arc_1384  -14
    arc_2_18_10  in_degree_1510  1
    arc_2_18_10  out_degree_1562  1
    arc_2_18_10  original_T_including_depot_unload_1596  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1383  1
    load_2_18_10  segment_load_conservation_1513  -1
    load_2_18_10  segment_prefix_lb_1514  1
    load_2_18_10  segment_prefix_ub_1515  1
    load_2_18_10  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1385  -30
    arc_2_18_11  connected_order_arc_1386  -14
    arc_2_18_11  in_degree_1517  1
    arc_2_18_11  out_degree_1562  1
    arc_2_18_11  original_T_including_depot_unload_1596  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1385  1
    load_2_18_11  segment_load_conservation_1520  -1
    load_2_18_11  segment_prefix_lb_1521  1
    load_2_18_11  segment_prefix_ub_1522  1
    load_2_18_11  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1387  -30
    arc_2_18_12  connected_order_arc_1388  -14
    arc_2_18_12  in_degree_1524  1
    arc_2_18_12  out_degree_1562  1
    arc_2_18_12  original_T_including_depot_unload_1596  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1387  1
    load_2_18_12  segment_load_conservation_1527  -1
    load_2_18_12  segment_prefix_lb_1528  1
    load_2_18_12  segment_prefix_ub_1529  1
    load_2_18_12  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1389  -30
    arc_2_18_13  connected_order_arc_1390  -14
    arc_2_18_13  in_degree_1531  1
    arc_2_18_13  out_degree_1562  1
    arc_2_18_13  original_T_including_depot_unload_1596  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1389  1
    load_2_18_13  segment_load_conservation_1534  -1
    load_2_18_13  segment_prefix_lb_1535  1
    load_2_18_13  segment_prefix_ub_1536  1
    load_2_18_13  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1391  -30
    arc_2_18_14  connected_order_arc_1392  -14
    arc_2_18_14  in_degree_1538  1
    arc_2_18_14  out_degree_1562  1
    arc_2_18_14  original_T_including_depot_unload_1596  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1391  1
    load_2_18_14  segment_load_conservation_1541  -1
    load_2_18_14  segment_prefix_lb_1542  1
    load_2_18_14  segment_prefix_ub_1543  1
    load_2_18_14  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1393  -30
    arc_2_18_15  connected_order_arc_1394  -14
    arc_2_18_15  in_degree_1545  1
    arc_2_18_15  out_degree_1562  1
    arc_2_18_15  original_T_including_depot_unload_1596  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1393  1
    load_2_18_15  free_load_conservation_1549  -1
    load_2_18_15  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1395  -30
    arc_2_18_16  connected_order_arc_1396  -14
    arc_2_18_16  in_degree_1551  1
    arc_2_18_16  out_degree_1562  1
    arc_2_18_16  original_T_including_depot_unload_1596  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1395  1
    load_2_18_16  free_load_conservation_1555  -1
    load_2_18_16  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1397  -30
    arc_2_18_17  connected_order_arc_1398  -14
    arc_2_18_17  in_degree_1557  1
    arc_2_18_17  out_degree_1562  1
    arc_2_18_17  original_T_including_depot_unload_1596  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1397  1
    load_2_18_17  free_load_conservation_1561  -1
    load_2_18_17  free_load_conservation_1567  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1399  -30
    arc_2_18_19  connected_order_arc_1400  -14
    arc_2_18_19  out_degree_1562  1
    arc_2_18_19  in_degree_1569  1
    arc_2_18_19  original_T_including_depot_unload_1596  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1399  1
    load_2_18_19  free_load_conservation_1567  1
    load_2_18_19  free_load_conservation_1573  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1401  -30
    arc_2_18_20  connected_order_arc_1402  -14
    arc_2_18_20  out_degree_1562  1
    arc_2_18_20  in_degree_1575  1
    arc_2_18_20  original_T_including_depot_unload_1596  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1401  1
    load_2_18_20  free_load_conservation_1567  1
    load_2_18_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1403  -30
    arc_2_18_21  connected_order_arc_1404  -14
    arc_2_18_21  out_degree_1562  1
    arc_2_18_21  in_degree_1581  1
    arc_2_18_21  original_T_including_depot_unload_1596  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1403  1
    load_2_18_21  free_load_conservation_1567  1
    load_2_18_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_22  arc_capacity_1405  -30
    arc_2_18_22  connected_order_arc_1406  -14
    arc_2_18_22  out_degree_1562  1
    arc_2_18_22  in_degree_1587  1
    arc_2_18_22  original_T_including_depot_unload_1596  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_22  arc_capacity_1405  1
    load_2_18_22  free_load_conservation_1567  1
    load_2_18_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1407  -30
    arc_2_19_0  depot_return_or_bypass_1508  1
    arc_2_19_0  out_degree_1568  1
    arc_2_19_0  original_T_including_depot_unload_1596  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1407  1
    load_2_19_0  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1408  -30
    arc_2_19_10  connected_order_arc_1409  -14
    arc_2_19_10  in_degree_1510  1
    arc_2_19_10  out_degree_1568  1
    arc_2_19_10  original_T_including_depot_unload_1596  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1408  1
    load_2_19_10  segment_load_conservation_1513  -1
    load_2_19_10  segment_prefix_lb_1514  1
    load_2_19_10  segment_prefix_ub_1515  1
    load_2_19_10  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1410  -30
    arc_2_19_11  connected_order_arc_1411  -14
    arc_2_19_11  in_degree_1517  1
    arc_2_19_11  out_degree_1568  1
    arc_2_19_11  original_T_including_depot_unload_1596  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1410  1
    load_2_19_11  segment_load_conservation_1520  -1
    load_2_19_11  segment_prefix_lb_1521  1
    load_2_19_11  segment_prefix_ub_1522  1
    load_2_19_11  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1412  -30
    arc_2_19_12  connected_order_arc_1413  -14
    arc_2_19_12  in_degree_1524  1
    arc_2_19_12  out_degree_1568  1
    arc_2_19_12  original_T_including_depot_unload_1596  1.4688211749637876e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1412  1
    load_2_19_12  segment_load_conservation_1527  -1
    load_2_19_12  segment_prefix_lb_1528  1
    load_2_19_12  segment_prefix_ub_1529  1
    load_2_19_12  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1414  -30
    arc_2_19_13  connected_order_arc_1415  -14
    arc_2_19_13  in_degree_1531  1
    arc_2_19_13  out_degree_1568  1
    arc_2_19_13  original_T_including_depot_unload_1596  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1414  1
    load_2_19_13  segment_load_conservation_1534  -1
    load_2_19_13  segment_prefix_lb_1535  1
    load_2_19_13  segment_prefix_ub_1536  1
    load_2_19_13  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1416  -30
    arc_2_19_14  connected_order_arc_1417  -14
    arc_2_19_14  in_degree_1538  1
    arc_2_19_14  out_degree_1568  1
    arc_2_19_14  original_T_including_depot_unload_1596  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1416  1
    load_2_19_14  segment_load_conservation_1541  -1
    load_2_19_14  segment_prefix_lb_1542  1
    load_2_19_14  segment_prefix_ub_1543  1
    load_2_19_14  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1418  -30
    arc_2_19_15  connected_order_arc_1419  -14
    arc_2_19_15  in_degree_1545  1
    arc_2_19_15  out_degree_1568  1
    arc_2_19_15  original_T_including_depot_unload_1596  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1418  1
    load_2_19_15  free_load_conservation_1549  -1
    load_2_19_15  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1420  -30
    arc_2_19_16  connected_order_arc_1421  -14
    arc_2_19_16  in_degree_1551  1
    arc_2_19_16  out_degree_1568  1
    arc_2_19_16  original_T_including_depot_unload_1596  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1420  1
    load_2_19_16  free_load_conservation_1555  -1
    load_2_19_16  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1422  -30
    arc_2_19_17  connected_order_arc_1423  -14
    arc_2_19_17  in_degree_1557  1
    arc_2_19_17  out_degree_1568  1
    arc_2_19_17  original_T_including_depot_unload_1596  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1422  1
    load_2_19_17  free_load_conservation_1561  -1
    load_2_19_17  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1424  -30
    arc_2_19_18  connected_order_arc_1425  -14
    arc_2_19_18  in_degree_1563  1
    arc_2_19_18  out_degree_1568  1
    arc_2_19_18  original_T_including_depot_unload_1596  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1424  1
    load_2_19_18  free_load_conservation_1567  -1
    load_2_19_18  free_load_conservation_1573  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1426  -30
    arc_2_19_20  connected_order_arc_1427  -14
    arc_2_19_20  out_degree_1568  1
    arc_2_19_20  in_degree_1575  1
    arc_2_19_20  original_T_including_depot_unload_1596  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1426  1
    load_2_19_20  free_load_conservation_1573  1
    load_2_19_20  free_load_conservation_1579  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1428  -30
    arc_2_19_21  connected_order_arc_1429  -14
    arc_2_19_21  out_degree_1568  1
    arc_2_19_21  in_degree_1581  1
    arc_2_19_21  original_T_including_depot_unload_1596  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1428  1
    load_2_19_21  free_load_conservation_1573  1
    load_2_19_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_22  arc_capacity_1430  -30
    arc_2_19_22  connected_order_arc_1431  -14
    arc_2_19_22  out_degree_1568  1
    arc_2_19_22  in_degree_1587  1
    arc_2_19_22  original_T_including_depot_unload_1596  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_22  arc_capacity_1430  1
    load_2_19_22  free_load_conservation_1573  1
    load_2_19_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1432  -30
    arc_2_20_0  depot_return_or_bypass_1508  1
    arc_2_20_0  out_degree_1574  1
    arc_2_20_0  original_T_including_depot_unload_1596  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1432  1
    load_2_20_0  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1433  -30
    arc_2_20_10  connected_order_arc_1434  -14
    arc_2_20_10  in_degree_1510  1
    arc_2_20_10  out_degree_1574  1
    arc_2_20_10  original_T_including_depot_unload_1596  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1433  1
    load_2_20_10  segment_load_conservation_1513  -1
    load_2_20_10  segment_prefix_lb_1514  1
    load_2_20_10  segment_prefix_ub_1515  1
    load_2_20_10  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1435  -30
    arc_2_20_11  connected_order_arc_1436  -14
    arc_2_20_11  in_degree_1517  1
    arc_2_20_11  out_degree_1574  1
    arc_2_20_11  original_T_including_depot_unload_1596  1.9038107656775676e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1435  1
    load_2_20_11  segment_load_conservation_1520  -1
    load_2_20_11  segment_prefix_lb_1521  1
    load_2_20_11  segment_prefix_ub_1522  1
    load_2_20_11  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1437  -30
    arc_2_20_12  connected_order_arc_1438  -14
    arc_2_20_12  in_degree_1524  1
    arc_2_20_12  out_degree_1574  1
    arc_2_20_12  original_T_including_depot_unload_1596  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1437  1
    load_2_20_12  segment_load_conservation_1527  -1
    load_2_20_12  segment_prefix_lb_1528  1
    load_2_20_12  segment_prefix_ub_1529  1
    load_2_20_12  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1439  -30
    arc_2_20_13  connected_order_arc_1440  -14
    arc_2_20_13  in_degree_1531  1
    arc_2_20_13  out_degree_1574  1
    arc_2_20_13  original_T_including_depot_unload_1596  1.2941622036935485e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1439  1
    load_2_20_13  segment_load_conservation_1534  -1
    load_2_20_13  segment_prefix_lb_1535  1
    load_2_20_13  segment_prefix_ub_1536  1
    load_2_20_13  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1441  -30
    arc_2_20_14  connected_order_arc_1442  -14
    arc_2_20_14  in_degree_1538  1
    arc_2_20_14  out_degree_1574  1
    arc_2_20_14  original_T_including_depot_unload_1596  1.2866008878928703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1441  1
    load_2_20_14  segment_load_conservation_1541  -1
    load_2_20_14  segment_prefix_lb_1542  1
    load_2_20_14  segment_prefix_ub_1543  1
    load_2_20_14  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1443  -30
    arc_2_20_15  connected_order_arc_1444  -14
    arc_2_20_15  in_degree_1545  1
    arc_2_20_15  out_degree_1574  1
    arc_2_20_15  original_T_including_depot_unload_1596  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1443  1
    load_2_20_15  free_load_conservation_1549  -1
    load_2_20_15  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1445  -30
    arc_2_20_16  connected_order_arc_1446  -14
    arc_2_20_16  in_degree_1551  1
    arc_2_20_16  out_degree_1574  1
    arc_2_20_16  original_T_including_depot_unload_1596  3.9402760365832432e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1445  1
    load_2_20_16  free_load_conservation_1555  -1
    load_2_20_16  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1447  -30
    arc_2_20_17  connected_order_arc_1448  -14
    arc_2_20_17  in_degree_1557  1
    arc_2_20_17  out_degree_1574  1
    arc_2_20_17  original_T_including_depot_unload_1596  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1447  1
    load_2_20_17  free_load_conservation_1561  -1
    load_2_20_17  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1449  -30
    arc_2_20_18  connected_order_arc_1450  -14
    arc_2_20_18  in_degree_1563  1
    arc_2_20_18  out_degree_1574  1
    arc_2_20_18  original_T_including_depot_unload_1596  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1449  1
    load_2_20_18  free_load_conservation_1567  -1
    load_2_20_18  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1451  -30
    arc_2_20_19  connected_order_arc_1452  -14
    arc_2_20_19  in_degree_1569  1
    arc_2_20_19  out_degree_1574  1
    arc_2_20_19  original_T_including_depot_unload_1596  5.2472086221481925e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1451  1
    load_2_20_19  free_load_conservation_1573  -1
    load_2_20_19  free_load_conservation_1579  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1453  -30
    arc_2_20_21  connected_order_arc_1454  -14
    arc_2_20_21  out_degree_1574  1
    arc_2_20_21  in_degree_1581  1
    arc_2_20_21  original_T_including_depot_unload_1596  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1453  1
    load_2_20_21  free_load_conservation_1579  1
    load_2_20_21  free_load_conservation_1585  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_22  arc_capacity_1455  -30
    arc_2_20_22  connected_order_arc_1456  -14
    arc_2_20_22  out_degree_1574  1
    arc_2_20_22  in_degree_1587  1
    arc_2_20_22  original_T_including_depot_unload_1596  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_22  arc_capacity_1455  1
    load_2_20_22  free_load_conservation_1579  1
    load_2_20_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1457  -30
    arc_2_21_0  depot_return_or_bypass_1508  1
    arc_2_21_0  out_degree_1580  1
    arc_2_21_0  original_T_including_depot_unload_1596  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1457  1
    load_2_21_0  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1458  -30
    arc_2_21_10  connected_order_arc_1459  -14
    arc_2_21_10  in_degree_1510  1
    arc_2_21_10  out_degree_1580  1
    arc_2_21_10  original_T_including_depot_unload_1596  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1458  1
    load_2_21_10  segment_load_conservation_1513  -1
    load_2_21_10  segment_prefix_lb_1514  1
    load_2_21_10  segment_prefix_ub_1515  1
    load_2_21_10  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1460  -30
    arc_2_21_11  connected_order_arc_1461  -14
    arc_2_21_11  in_degree_1517  1
    arc_2_21_11  out_degree_1580  1
    arc_2_21_11  original_T_including_depot_unload_1596  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1460  1
    load_2_21_11  segment_load_conservation_1520  -1
    load_2_21_11  segment_prefix_lb_1521  1
    load_2_21_11  segment_prefix_ub_1522  1
    load_2_21_11  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1462  -30
    arc_2_21_12  connected_order_arc_1463  -14
    arc_2_21_12  in_degree_1524  1
    arc_2_21_12  out_degree_1580  1
    arc_2_21_12  original_T_including_depot_unload_1596  1.0592524244968324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1462  1
    load_2_21_12  segment_load_conservation_1527  -1
    load_2_21_12  segment_prefix_lb_1528  1
    load_2_21_12  segment_prefix_ub_1529  1
    load_2_21_12  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1464  -30
    arc_2_21_13  connected_order_arc_1465  -14
    arc_2_21_13  in_degree_1531  1
    arc_2_21_13  out_degree_1580  1
    arc_2_21_13  original_T_including_depot_unload_1596  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1464  1
    load_2_21_13  segment_load_conservation_1534  -1
    load_2_21_13  segment_prefix_lb_1535  1
    load_2_21_13  segment_prefix_ub_1536  1
    load_2_21_13  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1466  -30
    arc_2_21_14  connected_order_arc_1467  -14
    arc_2_21_14  in_degree_1538  1
    arc_2_21_14  out_degree_1580  1
    arc_2_21_14  original_T_including_depot_unload_1596  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1466  1
    load_2_21_14  segment_load_conservation_1541  -1
    load_2_21_14  segment_prefix_lb_1542  1
    load_2_21_14  segment_prefix_ub_1543  1
    load_2_21_14  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1468  -30
    arc_2_21_15  connected_order_arc_1469  -14
    arc_2_21_15  in_degree_1545  1
    arc_2_21_15  out_degree_1580  1
    arc_2_21_15  original_T_including_depot_unload_1596  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1468  1
    load_2_21_15  free_load_conservation_1549  -1
    load_2_21_15  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1470  -30
    arc_2_21_16  connected_order_arc_1471  -14
    arc_2_21_16  in_degree_1551  1
    arc_2_21_16  out_degree_1580  1
    arc_2_21_16  original_T_including_depot_unload_1596  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1470  1
    load_2_21_16  free_load_conservation_1555  -1
    load_2_21_16  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1472  -30
    arc_2_21_17  connected_order_arc_1473  -14
    arc_2_21_17  in_degree_1557  1
    arc_2_21_17  out_degree_1580  1
    arc_2_21_17  original_T_including_depot_unload_1596  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1472  1
    load_2_21_17  free_load_conservation_1561  -1
    load_2_21_17  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1474  -30
    arc_2_21_18  connected_order_arc_1475  -14
    arc_2_21_18  in_degree_1563  1
    arc_2_21_18  out_degree_1580  1
    arc_2_21_18  original_T_including_depot_unload_1596  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1474  1
    load_2_21_18  free_load_conservation_1567  -1
    load_2_21_18  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1476  -30
    arc_2_21_19  connected_order_arc_1477  -14
    arc_2_21_19  in_degree_1569  1
    arc_2_21_19  out_degree_1580  1
    arc_2_21_19  original_T_including_depot_unload_1596  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1476  1
    load_2_21_19  free_load_conservation_1573  -1
    load_2_21_19  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1478  -30
    arc_2_21_20  connected_order_arc_1479  -14
    arc_2_21_20  in_degree_1575  1
    arc_2_21_20  out_degree_1580  1
    arc_2_21_20  original_T_including_depot_unload_1596  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1478  1
    load_2_21_20  free_load_conservation_1579  -1
    load_2_21_20  free_load_conservation_1585  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_22  arc_capacity_1480  -30
    arc_2_21_22  connected_order_arc_1481  -14
    arc_2_21_22  out_degree_1580  1
    arc_2_21_22  in_degree_1587  1
    arc_2_21_22  original_T_including_depot_unload_1596  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_22  arc_capacity_1480  1
    load_2_21_22  free_load_conservation_1585  1
    load_2_21_22  free_load_conservation_1591  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_0  arc_capacity_1482  -30
    arc_2_22_0  depot_return_or_bypass_1508  1
    arc_2_22_0  out_degree_1586  1
    arc_2_22_0  original_T_including_depot_unload_1596  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_0  arc_capacity_1482  1
    load_2_22_0  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_10  arc_capacity_1483  -30
    arc_2_22_10  connected_order_arc_1484  -14
    arc_2_22_10  in_degree_1510  1
    arc_2_22_10  out_degree_1586  1
    arc_2_22_10  original_T_including_depot_unload_1596  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_10  arc_capacity_1483  1
    load_2_22_10  segment_load_conservation_1513  -1
    load_2_22_10  segment_prefix_lb_1514  1
    load_2_22_10  segment_prefix_ub_1515  1
    load_2_22_10  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_11  arc_capacity_1485  -30
    arc_2_22_11  connected_order_arc_1486  -14
    arc_2_22_11  in_degree_1517  1
    arc_2_22_11  out_degree_1586  1
    arc_2_22_11  original_T_including_depot_unload_1596  1.3889860796771311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_11  arc_capacity_1485  1
    load_2_22_11  segment_load_conservation_1520  -1
    load_2_22_11  segment_prefix_lb_1521  1
    load_2_22_11  segment_prefix_ub_1522  1
    load_2_22_11  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_12  arc_capacity_1487  -30
    arc_2_22_12  connected_order_arc_1488  -14
    arc_2_22_12  in_degree_1524  1
    arc_2_22_12  out_degree_1586  1
    arc_2_22_12  original_T_including_depot_unload_1596  1.2399174881238241e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_12  arc_capacity_1487  1
    load_2_22_12  segment_load_conservation_1527  -1
    load_2_22_12  segment_prefix_lb_1528  1
    load_2_22_12  segment_prefix_ub_1529  1
    load_2_22_12  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_13  arc_capacity_1489  -30
    arc_2_22_13  connected_order_arc_1490  -14
    arc_2_22_13  in_degree_1531  1
    arc_2_22_13  out_degree_1586  1
    arc_2_22_13  original_T_including_depot_unload_1596  7.9206888044020991e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_13  arc_capacity_1489  1
    load_2_22_13  segment_load_conservation_1534  -1
    load_2_22_13  segment_prefix_lb_1535  1
    load_2_22_13  segment_prefix_ub_1536  1
    load_2_22_13  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_14  arc_capacity_1491  -30
    arc_2_22_14  connected_order_arc_1492  -14
    arc_2_22_14  in_degree_1538  1
    arc_2_22_14  out_degree_1586  1
    arc_2_22_14  original_T_including_depot_unload_1596  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_14  arc_capacity_1491  1
    load_2_22_14  segment_load_conservation_1541  -1
    load_2_22_14  segment_prefix_lb_1542  1
    load_2_22_14  segment_prefix_ub_1543  1
    load_2_22_14  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_15  arc_capacity_1493  -30
    arc_2_22_15  connected_order_arc_1494  -14
    arc_2_22_15  in_degree_1545  1
    arc_2_22_15  out_degree_1586  1
    arc_2_22_15  original_T_including_depot_unload_1596  9.7877495286142823e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_15  arc_capacity_1493  1
    load_2_22_15  free_load_conservation_1549  -1
    load_2_22_15  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_16  arc_capacity_1495  -30
    arc_2_22_16  connected_order_arc_1496  -14
    arc_2_22_16  in_degree_1551  1
    arc_2_22_16  out_degree_1586  1
    arc_2_22_16  original_T_including_depot_unload_1596  7.9829177317292124e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_16  arc_capacity_1495  1
    load_2_22_16  free_load_conservation_1555  -1
    load_2_22_16  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_17  arc_capacity_1497  -30
    arc_2_22_17  connected_order_arc_1498  -14
    arc_2_22_17  in_degree_1557  1
    arc_2_22_17  out_degree_1586  1
    arc_2_22_17  original_T_including_depot_unload_1596  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_22_17  arc_capacity_1497  1
    load_2_22_17  free_load_conservation_1561  -1
    load_2_22_17  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_18  arc_capacity_1499  -30
    arc_2_22_18  connected_order_arc_1500  -14
    arc_2_22_18  in_degree_1563  1
    arc_2_22_18  out_degree_1586  1
    arc_2_22_18  original_T_including_depot_unload_1596  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_18  arc_capacity_1499  1
    load_2_22_18  free_load_conservation_1567  -1
    load_2_22_18  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_19  arc_capacity_1501  -30
    arc_2_22_19  connected_order_arc_1502  -14
    arc_2_22_19  in_degree_1569  1
    arc_2_22_19  out_degree_1586  1
    arc_2_22_19  original_T_including_depot_unload_1596  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_19  arc_capacity_1501  1
    load_2_22_19  free_load_conservation_1573  -1
    load_2_22_19  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_20  arc_capacity_1503  -30
    arc_2_22_20  connected_order_arc_1504  -14
    arc_2_22_20  in_degree_1575  1
    arc_2_22_20  out_degree_1586  1
    arc_2_22_20  original_T_including_depot_unload_1596  5.8943244236516807e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_20  arc_capacity_1503  1
    load_2_22_20  free_load_conservation_1579  -1
    load_2_22_20  free_load_conservation_1591  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_22_21  arc_capacity_1505  -30
    arc_2_22_21  connected_order_arc_1506  -14
    arc_2_22_21  in_degree_1581  1
    arc_2_22_21  out_degree_1586  1
    arc_2_22_21  original_T_including_depot_unload_1596  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_22_21  arc_capacity_1505  1
    load_2_22_21  free_load_conservation_1585  -1
    load_2_22_21  free_load_conservation_1591  1
RHS
    RHS1      OBJ       -3.8250000000000006e-01
    RHS1      onehot_35_32  1
    RHS1      onehot_30_53  1
    RHS1      onehot_31_82  1
    RHS1      onehot_32_111  1
    RHS1      onehot_19_132  1
    RHS1      onehot_26_153  1
    RHS1      onehot_6_178  1
    RHS1      onehot_17_215  1
    RHS1      stock_ub_219  25
    RHS1      parent_nonstrict_scope_220  0.339130721574783
    RHS1      normalization_277  1
    RHS1      connected_order_arc_384  -13
    RHS1      connected_order_arc_386  -13
    RHS1      connected_order_arc_388  -13
    RHS1      connected_order_arc_390  -13
    RHS1      connected_order_arc_392  -13
    RHS1      connected_order_arc_394  -13
    RHS1      connected_order_arc_396  -13
    RHS1      connected_order_arc_398  -13
    RHS1      connected_order_arc_400  -13
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_409  -13
    RHS1      connected_order_arc_411  -13
    RHS1      connected_order_arc_413  -13
    RHS1      connected_order_arc_415  -13
    RHS1      connected_order_arc_417  -13
    RHS1      connected_order_arc_419  -13
    RHS1      connected_order_arc_421  -13
    RHS1      connected_order_arc_423  -13
    RHS1      connected_order_arc_425  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_434  -13
    RHS1      connected_order_arc_436  -13
    RHS1      connected_order_arc_438  -13
    RHS1      connected_order_arc_440  -13
    RHS1      connected_order_arc_442  -13
    RHS1      connected_order_arc_444  -13
    RHS1      connected_order_arc_446  -13
    RHS1      connected_order_arc_448  -13
    RHS1      connected_order_arc_450  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_459  -13
    RHS1      connected_order_arc_461  -13
    RHS1      connected_order_arc_463  -13
    RHS1      connected_order_arc_465  -13
    RHS1      connected_order_arc_467  -13
    RHS1      connected_order_arc_469  -13
    RHS1      connected_order_arc_471  -13
    RHS1      connected_order_arc_473  -13
    RHS1      connected_order_arc_475  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_484  -13
    RHS1      connected_order_arc_486  -13
    RHS1      connected_order_arc_488  -13
    RHS1      connected_order_arc_490  -13
    RHS1      connected_order_arc_492  -13
    RHS1      connected_order_arc_494  -13
    RHS1      connected_order_arc_496  -13
    RHS1      connected_order_arc_498  -13
    RHS1      connected_order_arc_500  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_509  -13
    RHS1      connected_order_arc_511  -13
    RHS1      connected_order_arc_513  -13
    RHS1      connected_order_arc_515  -13
    RHS1      connected_order_arc_517  -13
    RHS1      connected_order_arc_519  -13
    RHS1      connected_order_arc_521  -13
    RHS1      connected_order_arc_523  -13
    RHS1      connected_order_arc_525  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_534  -13
    RHS1      connected_order_arc_536  -13
    RHS1      connected_order_arc_538  -13
    RHS1      connected_order_arc_540  -13
    RHS1      connected_order_arc_542  -13
    RHS1      connected_order_arc_544  -13
    RHS1      connected_order_arc_546  -13
    RHS1      connected_order_arc_548  -13
    RHS1      connected_order_arc_550  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_559  -13
    RHS1      connected_order_arc_561  -13
    RHS1      connected_order_arc_563  -13
    RHS1      connected_order_arc_565  -13
    RHS1      connected_order_arc_567  -13
    RHS1      connected_order_arc_569  -13
    RHS1      connected_order_arc_571  -13
    RHS1      connected_order_arc_573  -13
    RHS1      connected_order_arc_575  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_584  -13
    RHS1      connected_order_arc_586  -13
    RHS1      connected_order_arc_588  -13
    RHS1      connected_order_arc_590  -13
    RHS1      connected_order_arc_592  -13
    RHS1      connected_order_arc_594  -13
    RHS1      connected_order_arc_596  -13
    RHS1      connected_order_arc_598  -13
    RHS1      connected_order_arc_600  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_609  -13
    RHS1      connected_order_arc_611  -13
    RHS1      connected_order_arc_613  -13
    RHS1      connected_order_arc_615  -13
    RHS1      connected_order_arc_617  -13
    RHS1      connected_order_arc_619  -13
    RHS1      connected_order_arc_621  -13
    RHS1      connected_order_arc_623  -13
    RHS1      connected_order_arc_625  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_634  -13
    RHS1      connected_order_arc_636  -13
    RHS1      connected_order_arc_638  -13
    RHS1      connected_order_arc_640  -13
    RHS1      connected_order_arc_642  -13
    RHS1      connected_order_arc_644  -13
    RHS1      connected_order_arc_646  -13
    RHS1      connected_order_arc_648  -13
    RHS1      connected_order_arc_650  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_659  -13
    RHS1      connected_order_arc_661  -13
    RHS1      connected_order_arc_663  -13
    RHS1      connected_order_arc_665  -13
    RHS1      connected_order_arc_667  -13
    RHS1      connected_order_arc_669  -13
    RHS1      connected_order_arc_671  -13
    RHS1      connected_order_arc_673  -13
    RHS1      connected_order_arc_675  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_684  -13
    RHS1      connected_order_arc_686  -13
    RHS1      connected_order_arc_688  -13
    RHS1      connected_order_arc_690  -13
    RHS1      connected_order_arc_692  -13
    RHS1      connected_order_arc_694  -13
    RHS1      connected_order_arc_696  -13
    RHS1      connected_order_arc_698  -13
    RHS1      connected_order_arc_700  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      depot_departure_or_bypass_707  1
    RHS1      depot_return_or_bypass_708  1
    RHS1      segment_load_conservation_713  11
    RHS1      segment_prefix_ub_715  1
    RHS1      segment_load_conservation_720  -5
    RHS1      segment_prefix_lb_721  5
    RHS1      segment_prefix_ub_722  20
    RHS1      segment_prefix_lb_728  5
    RHS1      segment_prefix_ub_729  20
    RHS1      segment_load_conservation_734  6
    RHS1      segment_prefix_ub_736  14
    RHS1      segment_load_conservation_741  -6
    RHS1      segment_prefix_lb_742  6
    RHS1      segment_prefix_ub_743  20
    RHS1      fixed_segment_relative_order_792  1
    RHS1      fixed_segment_relative_order_793  1
    RHS1      fixed_segment_relative_order_794  1
    RHS1      fixed_segment_relative_order_795  1
    RHS1      original_T_including_depot_unload_796  2.0502217062831596e+03
    RHS1      connected_order_arc_812  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_818  -12
    RHS1      connected_order_arc_820  -12
    RHS1      connected_order_arc_822  -12
    RHS1      connected_order_arc_824  -12
    RHS1      connected_order_arc_826  -12
    RHS1      connected_order_arc_828  -12
    RHS1      connected_order_arc_830  -12
    RHS1      connected_order_arc_832  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_841  -12
    RHS1      connected_order_arc_843  -12
    RHS1      connected_order_arc_845  -12
    RHS1      connected_order_arc_847  -12
    RHS1      connected_order_arc_849  -12
    RHS1      connected_order_arc_851  -12
    RHS1      connected_order_arc_853  -12
    RHS1      connected_order_arc_855  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_864  -12
    RHS1      connected_order_arc_866  -12
    RHS1      connected_order_arc_868  -12
    RHS1      connected_order_arc_870  -12
    RHS1      connected_order_arc_872  -12
    RHS1      connected_order_arc_874  -12
    RHS1      connected_order_arc_876  -12
    RHS1      connected_order_arc_878  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_887  -12
    RHS1      connected_order_arc_889  -12
    RHS1      connected_order_arc_891  -12
    RHS1      connected_order_arc_893  -12
    RHS1      connected_order_arc_895  -12
    RHS1      connected_order_arc_897  -12
    RHS1      connected_order_arc_899  -12
    RHS1      connected_order_arc_901  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_910  -12
    RHS1      connected_order_arc_912  -12
    RHS1      connected_order_arc_914  -12
    RHS1      connected_order_arc_916  -12
    RHS1      connected_order_arc_918  -12
    RHS1      connected_order_arc_920  -12
    RHS1      connected_order_arc_922  -12
    RHS1      connected_order_arc_924  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_933  -12
    RHS1      connected_order_arc_935  -12
    RHS1      connected_order_arc_937  -12
    RHS1      connected_order_arc_939  -12
    RHS1      connected_order_arc_941  -12
    RHS1      connected_order_arc_943  -12
    RHS1      connected_order_arc_945  -12
    RHS1      connected_order_arc_947  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_956  -12
    RHS1      connected_order_arc_958  -12
    RHS1      connected_order_arc_960  -12
    RHS1      connected_order_arc_962  -12
    RHS1      connected_order_arc_964  -12
    RHS1      connected_order_arc_966  -12
    RHS1      connected_order_arc_968  -12
    RHS1      connected_order_arc_970  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_979  -12
    RHS1      connected_order_arc_981  -12
    RHS1      connected_order_arc_983  -12
    RHS1      connected_order_arc_985  -12
    RHS1      connected_order_arc_987  -12
    RHS1      connected_order_arc_989  -12
    RHS1      connected_order_arc_991  -12
    RHS1      connected_order_arc_993  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1002  -12
    RHS1      connected_order_arc_1004  -12
    RHS1      connected_order_arc_1006  -12
    RHS1      connected_order_arc_1008  -12
    RHS1      connected_order_arc_1010  -12
    RHS1      connected_order_arc_1012  -12
    RHS1      connected_order_arc_1014  -12
    RHS1      connected_order_arc_1016  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1025  -12
    RHS1      connected_order_arc_1027  -12
    RHS1      connected_order_arc_1029  -12
    RHS1      connected_order_arc_1031  -12
    RHS1      connected_order_arc_1033  -12
    RHS1      connected_order_arc_1035  -12
    RHS1      connected_order_arc_1037  -12
    RHS1      connected_order_arc_1039  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1048  -12
    RHS1      connected_order_arc_1050  -12
    RHS1      connected_order_arc_1052  -12
    RHS1      connected_order_arc_1054  -12
    RHS1      connected_order_arc_1056  -12
    RHS1      connected_order_arc_1058  -12
    RHS1      connected_order_arc_1060  -12
    RHS1      connected_order_arc_1062  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      connected_order_arc_1071  -12
    RHS1      connected_order_arc_1073  -12
    RHS1      connected_order_arc_1075  -12
    RHS1      connected_order_arc_1077  -12
    RHS1      connected_order_arc_1079  -12
    RHS1      connected_order_arc_1081  -12
    RHS1      connected_order_arc_1083  -12
    RHS1      connected_order_arc_1085  -12
    RHS1      depot_departure_or_bypass_1086  1
    RHS1      depot_return_or_bypass_1087  1
    RHS1      segment_load_conservation_1092  3
    RHS1      segment_prefix_ub_1094  22
    RHS1      segment_load_conservation_1099  3
    RHS1      segment_prefix_ub_1101  22
    RHS1      segment_load_conservation_1106  -5
    RHS1      segment_prefix_lb_1107  5
    RHS1      segment_prefix_ub_1108  25
    RHS1      segment_load_conservation_1113  -1
    RHS1      segment_prefix_lb_1114  1
    RHS1      segment_prefix_ub_1115  15
    RHS1      fixed_segment_relative_order_1164  1
    RHS1      fixed_segment_relative_order_1165  1
    RHS1      fixed_segment_relative_order_1166  1
    RHS1      original_T_including_depot_unload_1167  2.5466013138995804e+03
    RHS1      connected_order_arc_1184  -13
    RHS1      connected_order_arc_1186  -13
    RHS1      connected_order_arc_1188  -13
    RHS1      connected_order_arc_1190  -13
    RHS1      connected_order_arc_1192  -13
    RHS1      connected_order_arc_1194  -13
    RHS1      connected_order_arc_1196  -13
    RHS1      connected_order_arc_1198  -13
    RHS1      connected_order_arc_1200  -13
    RHS1      connected_order_arc_1202  -13
    RHS1      connected_order_arc_1204  -13
    RHS1      connected_order_arc_1206  -13
    RHS1      connected_order_arc_1209  -13
    RHS1      connected_order_arc_1211  -13
    RHS1      connected_order_arc_1213  -13
    RHS1      connected_order_arc_1215  -13
    RHS1      connected_order_arc_1217  -13
    RHS1      connected_order_arc_1219  -13
    RHS1      connected_order_arc_1221  -13
    RHS1      connected_order_arc_1223  -13
    RHS1      connected_order_arc_1225  -13
    RHS1      connected_order_arc_1227  -13
    RHS1      connected_order_arc_1229  -13
    RHS1      connected_order_arc_1231  -13
    RHS1      connected_order_arc_1234  -13
    RHS1      connected_order_arc_1236  -13
    RHS1      connected_order_arc_1238  -13
    RHS1      connected_order_arc_1240  -13
    RHS1      connected_order_arc_1242  -13
    RHS1      connected_order_arc_1244  -13
    RHS1      connected_order_arc_1246  -13
    RHS1      connected_order_arc_1248  -13
    RHS1      connected_order_arc_1250  -13
    RHS1      connected_order_arc_1252  -13
    RHS1      connected_order_arc_1254  -13
    RHS1      connected_order_arc_1256  -13
    RHS1      connected_order_arc_1259  -13
    RHS1      connected_order_arc_1261  -13
    RHS1      connected_order_arc_1263  -13
    RHS1      connected_order_arc_1265  -13
    RHS1      connected_order_arc_1267  -13
    RHS1      connected_order_arc_1269  -13
    RHS1      connected_order_arc_1271  -13
    RHS1      connected_order_arc_1273  -13
    RHS1      connected_order_arc_1275  -13
    RHS1      connected_order_arc_1277  -13
    RHS1      connected_order_arc_1279  -13
    RHS1      connected_order_arc_1281  -13
    RHS1      connected_order_arc_1284  -13
    RHS1      connected_order_arc_1286  -13
    RHS1      connected_order_arc_1288  -13
    RHS1      connected_order_arc_1290  -13
    RHS1      connected_order_arc_1292  -13
    RHS1      connected_order_arc_1294  -13
    RHS1      connected_order_arc_1296  -13
    RHS1      connected_order_arc_1298  -13
    RHS1      connected_order_arc_1300  -13
    RHS1      connected_order_arc_1302  -13
    RHS1      connected_order_arc_1304  -13
    RHS1      connected_order_arc_1306  -13
    RHS1      connected_order_arc_1309  -13
    RHS1      connected_order_arc_1311  -13
    RHS1      connected_order_arc_1313  -13
    RHS1      connected_order_arc_1315  -13
    RHS1      connected_order_arc_1317  -13
    RHS1      connected_order_arc_1319  -13
    RHS1      connected_order_arc_1321  -13
    RHS1      connected_order_arc_1323  -13
    RHS1      connected_order_arc_1325  -13
    RHS1      connected_order_arc_1327  -13
    RHS1      connected_order_arc_1329  -13
    RHS1      connected_order_arc_1331  -13
    RHS1      connected_order_arc_1334  -13
    RHS1      connected_order_arc_1336  -13
    RHS1      connected_order_arc_1338  -13
    RHS1      connected_order_arc_1340  -13
    RHS1      connected_order_arc_1342  -13
    RHS1      connected_order_arc_1344  -13
    RHS1      connected_order_arc_1346  -13
    RHS1      connected_order_arc_1348  -13
    RHS1      connected_order_arc_1350  -13
    RHS1      connected_order_arc_1352  -13
    RHS1      connected_order_arc_1354  -13
    RHS1      connected_order_arc_1356  -13
    RHS1      connected_order_arc_1359  -13
    RHS1      connected_order_arc_1361  -13
    RHS1      connected_order_arc_1363  -13
    RHS1      connected_order_arc_1365  -13
    RHS1      connected_order_arc_1367  -13
    RHS1      connected_order_arc_1369  -13
    RHS1      connected_order_arc_1371  -13
    RHS1      connected_order_arc_1373  -13
    RHS1      connected_order_arc_1375  -13
    RHS1      connected_order_arc_1377  -13
    RHS1      connected_order_arc_1379  -13
    RHS1      connected_order_arc_1381  -13
    RHS1      connected_order_arc_1384  -13
    RHS1      connected_order_arc_1386  -13
    RHS1      connected_order_arc_1388  -13
    RHS1      connected_order_arc_1390  -13
    RHS1      connected_order_arc_1392  -13
    RHS1      connected_order_arc_1394  -13
    RHS1      connected_order_arc_1396  -13
    RHS1      connected_order_arc_1398  -13
    RHS1      connected_order_arc_1400  -13
    RHS1      connected_order_arc_1402  -13
    RHS1      connected_order_arc_1404  -13
    RHS1      connected_order_arc_1406  -13
    RHS1      connected_order_arc_1409  -13
    RHS1      connected_order_arc_1411  -13
    RHS1      connected_order_arc_1413  -13
    RHS1      connected_order_arc_1415  -13
    RHS1      connected_order_arc_1417  -13
    RHS1      connected_order_arc_1419  -13
    RHS1      connected_order_arc_1421  -13
    RHS1      connected_order_arc_1423  -13
    RHS1      connected_order_arc_1425  -13
    RHS1      connected_order_arc_1427  -13
    RHS1      connected_order_arc_1429  -13
    RHS1      connected_order_arc_1431  -13
    RHS1      connected_order_arc_1434  -13
    RHS1      connected_order_arc_1436  -13
    RHS1      connected_order_arc_1438  -13
    RHS1      connected_order_arc_1440  -13
    RHS1      connected_order_arc_1442  -13
    RHS1      connected_order_arc_1444  -13
    RHS1      connected_order_arc_1446  -13
    RHS1      connected_order_arc_1448  -13
    RHS1      connected_order_arc_1450  -13
    RHS1      connected_order_arc_1452  -13
    RHS1      connected_order_arc_1454  -13
    RHS1      connected_order_arc_1456  -13
    RHS1      connected_order_arc_1459  -13
    RHS1      connected_order_arc_1461  -13
    RHS1      connected_order_arc_1463  -13
    RHS1      connected_order_arc_1465  -13
    RHS1      connected_order_arc_1467  -13
    RHS1      connected_order_arc_1469  -13
    RHS1      connected_order_arc_1471  -13
    RHS1      connected_order_arc_1473  -13
    RHS1      connected_order_arc_1475  -13
    RHS1      connected_order_arc_1477  -13
    RHS1      connected_order_arc_1479  -13
    RHS1      connected_order_arc_1481  -13
    RHS1      connected_order_arc_1484  -13
    RHS1      connected_order_arc_1486  -13
    RHS1      connected_order_arc_1488  -13
    RHS1      connected_order_arc_1490  -13
    RHS1      connected_order_arc_1492  -13
    RHS1      connected_order_arc_1494  -13
    RHS1      connected_order_arc_1496  -13
    RHS1      connected_order_arc_1498  -13
    RHS1      connected_order_arc_1500  -13
    RHS1      connected_order_arc_1502  -13
    RHS1      connected_order_arc_1504  -13
    RHS1      connected_order_arc_1506  -13
    RHS1      depot_departure_or_bypass_1507  1
    RHS1      depot_return_or_bypass_1508  1
    RHS1      segment_load_conservation_1513  2
    RHS1      segment_prefix_ub_1515  28
    RHS1      segment_load_conservation_1520  3
    RHS1      segment_prefix_ub_1522  27
    RHS1      segment_load_conservation_1527  2
    RHS1      segment_prefix_ub_1529  28
    RHS1      segment_load_conservation_1534  -5
    RHS1      segment_prefix_lb_1535  5
    RHS1      segment_prefix_ub_1536  30
    RHS1      segment_load_conservation_1541  -5
    RHS1      segment_prefix_lb_1542  5
    RHS1      segment_prefix_ub_1543  30
    RHS1      fixed_segment_relative_order_1592  1
    RHS1      fixed_segment_relative_order_1593  1
    RHS1      fixed_segment_relative_order_1594  1
    RHS1      fixed_segment_relative_order_1595  1
    RHS1      original_T_including_depot_unload_1596  6360
BOUNDS
 LO BND1      t         2.4615144174391260e-02
 UP BND1      t         4.0227958431149860e-02
 UP BND1      q         4.9513072157478305e-01
 BV BND1      x_35_0  
 UP BND1      w_35_0    4.0227958431149860e-02
 BV BND1      x_35_1  
 UP BND1      w_35_1    4.0227958431149860e-02
 BV BND1      x_35_2  
 UP BND1      w_35_2    4.0227958431149860e-02
 BV BND1      x_35_3  
 UP BND1      w_35_3    4.0227958431149860e-02
 BV BND1      x_35_4  
 UP BND1      w_35_4    4.0227958431149860e-02
 BV BND1      x_35_5  
 UP BND1      w_35_5    4.0227958431149860e-02
 BV BND1      x_35_6  
 UP BND1      w_35_6    4.0227958431149860e-02
 BV BND1      x_35_7  
 UP BND1      w_35_7    4.0227958431149860e-02
 BV BND1      x_35_8  
 UP BND1      w_35_8    4.0227958431149860e-02
 BV BND1      x_35_9  
 UP BND1      w_35_9    4.0227958431149860e-02
 BV BND1      x_35_10 
 UP BND1      w_35_10   4.0227958431149860e-02
 BV BND1      x_35_11 
 UP BND1      w_35_11   4.0227958431149860e-02
 BV BND1      x_35_12 
 UP BND1      w_35_12   4.0227958431149860e-02
 BV BND1      x_35_13 
 UP BND1      w_35_13   4.0227958431149860e-02
 BV BND1      x_35_14 
 UP BND1      w_35_14   4.0227958431149860e-02
 BV BND1      x_35_15 
 UP BND1      w_35_15   4.0227958431149860e-02
 UP BND1      rho_35    1
 BV BND1      x_30_0  
 UP BND1      w_30_0    4.0227958431149860e-02
 BV BND1      x_30_1  
 UP BND1      w_30_1    4.0227958431149860e-02
 BV BND1      x_30_2  
 UP BND1      w_30_2    4.0227958431149860e-02
 BV BND1      x_30_3  
 UP BND1      w_30_3    4.0227958431149860e-02
 BV BND1      x_30_4  
 UP BND1      w_30_4    4.0227958431149860e-02
 BV BND1      x_30_5  
 UP BND1      w_30_5    4.0227958431149860e-02
 BV BND1      x_30_6  
 UP BND1      w_30_6    4.0227958431149860e-02
 BV BND1      x_30_7  
 UP BND1      w_30_7    4.0227958431149860e-02
 BV BND1      x_30_8  
 UP BND1      w_30_8    4.0227958431149860e-02
 UP BND1      rho_30    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.0227958431149860e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.0227958431149860e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.0227958431149860e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.0227958431149860e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.0227958431149860e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.0227958431149860e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.0227958431149860e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.0227958431149860e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.0227958431149860e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.0227958431149860e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.0227958431149860e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.0227958431149860e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.0227958431149860e-02
 UP BND1      rho_31    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.0227958431149860e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.0227958431149860e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.0227958431149860e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.0227958431149860e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.0227958431149860e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.0227958431149860e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.0227958431149860e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.0227958431149860e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.0227958431149860e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.0227958431149860e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.0227958431149860e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.0227958431149860e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.0227958431149860e-02
 UP BND1      rho_32    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.0227958431149860e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.0227958431149860e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.0227958431149860e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.0227958431149860e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.0227958431149860e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.0227958431149860e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.0227958431149860e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.0227958431149860e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.0227958431149860e-02
 UP BND1      rho_19    1
 BV BND1      x_26_0  
 UP BND1      w_26_0    4.0227958431149860e-02
 BV BND1      x_26_1  
 UP BND1      w_26_1    4.0227958431149860e-02
 BV BND1      x_26_2  
 UP BND1      w_26_2    4.0227958431149860e-02
 BV BND1      x_26_3  
 UP BND1      w_26_3    4.0227958431149860e-02
 BV BND1      x_26_4  
 UP BND1      w_26_4    4.0227958431149860e-02
 BV BND1      x_26_5  
 UP BND1      w_26_5    4.0227958431149860e-02
 BV BND1      x_26_6  
 UP BND1      w_26_6    4.0227958431149860e-02
 BV BND1      x_26_7  
 UP BND1      w_26_7    4.0227958431149860e-02
 BV BND1      x_26_8  
 UP BND1      w_26_8    4.0227958431149860e-02
 UP BND1      rho_26    1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.0227958431149860e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.0227958431149860e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.0227958431149860e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.0227958431149860e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.0227958431149860e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.0227958431149860e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.0227958431149860e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.0227958431149860e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.0227958431149860e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.0227958431149860e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.0227958431149860e-02
 UP BND1      rho_6     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    4.0227958431149860e-02
 BV BND1      x_17_1  
 UP BND1      w_17_1    4.0227958431149860e-02
 BV BND1      x_17_2  
 UP BND1      w_17_2    4.0227958431149860e-02
 BV BND1      x_17_3  
 UP BND1      w_17_3    4.0227958431149860e-02
 BV BND1      x_17_4  
 UP BND1      w_17_4    4.0227958431149860e-02
 BV BND1      x_17_5  
 UP BND1      w_17_5    4.0227958431149860e-02
 BV BND1      x_17_6  
 UP BND1      w_17_6    4.0227958431149860e-02
 BV BND1      x_17_7  
 UP BND1      w_17_7    4.0227958431149860e-02
 BV BND1      x_17_8  
 UP BND1      w_17_8    4.0227958431149860e-02
 BV BND1      x_17_9  
 UP BND1      w_17_9    4.0227958431149860e-02
 BV BND1      x_17_10 
 UP BND1      w_17_10   4.0227958431149860e-02
 BV BND1      x_17_11 
 UP BND1      w_17_11   4.0227958431149860e-02
 BV BND1      x_17_12 
 UP BND1      w_17_12   4.0227958431149860e-02
 BV BND1      x_17_13 
 UP BND1      w_17_13   4.0227958431149860e-02
 BV BND1      x_17_14 
 UP BND1      w_17_14   4.0227958431149860e-02
 BV BND1      x_17_15 
 UP BND1      w_17_15   4.0227958431149860e-02
 BV BND1      x_17_16 
 UP BND1      w_17_16   4.0227958431149860e-02
 UP BND1      rho_17    1
 UP BND1      a_35_30   1
 UP BND1      a_35_31   1
 UP BND1      a_35_32   1
 UP BND1      a_35_19   1
 UP BND1      a_35_26   1
 UP BND1      a_35_6    1
 UP BND1      a_35_17   1
 UP BND1      a_30_31   1
 UP BND1      a_30_32   1
 UP BND1      a_30_19   1
 UP BND1      a_30_26   1
 UP BND1      a_30_6    1
 UP BND1      a_30_17   1
 UP BND1      a_31_32   1
 UP BND1      a_31_19   1
 UP BND1      a_31_26   1
 UP BND1      a_31_6    1
 UP BND1      a_31_17   1
 UP BND1      a_32_19   1
 UP BND1      a_32_26   1
 UP BND1      a_32_6    1
 UP BND1      a_32_17   1
 UP BND1      a_19_26   1
 UP BND1      a_19_6    1
 UP BND1      a_19_17   1
 UP BND1      a_26_6    1
 UP BND1      a_26_17   1
 UP BND1      a_6_17    1
 BV BND1      service_0_35_0
 BV BND1      service_0_35_1
 BV BND1      service_0_35_2
 BV BND1      service_0_35_3
 BV BND1      service_0_35_4
 BV BND1      service_0_35_5
 BV BND1      service_0_35_6
 BV BND1      service_0_35_7
 BV BND1      service_0_35_8
 BV BND1      service_0_35_9
 BV BND1      service_0_35_10
 BV BND1      service_0_35_12
 BV BND1      service_0_35_13
 BV BND1      service_0_35_14
 BV BND1      service_0_35_15
 BV BND1      service_1_35_0
 BV BND1      service_1_35_1
 BV BND1      service_1_35_2
 BV BND1      service_1_35_3
 BV BND1      service_1_35_4
 BV BND1      service_1_35_5
 BV BND1      service_1_35_6
 BV BND1      service_1_35_7
 BV BND1      service_1_35_8
 BV BND1      service_1_35_9
 BV BND1      service_1_35_10
 BV BND1      service_1_35_12
 BV BND1      service_1_35_13
 BV BND1      service_1_35_14
 BV BND1      service_1_35_15
 BV BND1      service_2_35_0
 BV BND1      service_2_35_1
 BV BND1      service_2_35_2
 BV BND1      service_2_35_3
 BV BND1      service_2_35_4
 BV BND1      service_2_35_5
 BV BND1      service_2_35_6
 BV BND1      service_2_35_7
 BV BND1      service_2_35_8
 BV BND1      service_2_35_9
 BV BND1      service_2_35_10
 BV BND1      service_2_35_12
 BV BND1      service_2_35_13
 BV BND1      service_2_35_14
 BV BND1      service_2_35_15
 BV BND1      service_0_30_0
 BV BND1      service_0_30_1
 BV BND1      service_0_30_2
 BV BND1      service_0_30_3
 BV BND1      service_0_30_4
 BV BND1      service_0_30_6
 BV BND1      service_0_30_7
 BV BND1      service_0_30_8
 BV BND1      service_1_30_0
 BV BND1      service_1_30_1
 BV BND1      service_1_30_2
 BV BND1      service_1_30_3
 BV BND1      service_1_30_4
 BV BND1      service_1_30_6
 BV BND1      service_1_30_7
 BV BND1      service_1_30_8
 BV BND1      service_2_30_0
 BV BND1      service_2_30_1
 BV BND1      service_2_30_2
 BV BND1      service_2_30_3
 BV BND1      service_2_30_4
 BV BND1      service_2_30_6
 BV BND1      service_2_30_7
 BV BND1      service_2_30_8
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_26_1
 BV BND1      service_0_26_2
 BV BND1      service_0_26_3
 BV BND1      service_0_26_4
 BV BND1      service_0_26_5
 BV BND1      service_0_26_6
 BV BND1      service_0_26_7
 BV BND1      service_0_26_8
 BV BND1      service_1_26_1
 BV BND1      service_1_26_2
 BV BND1      service_1_26_3
 BV BND1      service_1_26_4
 BV BND1      service_1_26_5
 BV BND1      service_1_26_6
 BV BND1      service_1_26_7
 BV BND1      service_1_26_8
 BV BND1      service_2_26_1
 BV BND1      service_2_26_2
 BV BND1      service_2_26_3
 BV BND1      service_2_26_4
 BV BND1      service_2_26_5
 BV BND1      service_2_26_6
 BV BND1      service_2_26_7
 BV BND1      service_2_26_8
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_2_17_0
 BV BND1      service_2_17_1
 BV BND1      service_2_17_2
 BV BND1      service_2_17_4
 BV BND1      service_2_17_5
 BV BND1      service_2_17_6
 BV BND1      service_2_17_7
 BV BND1      service_2_17_8
 BV BND1      service_2_17_9
 BV BND1      service_2_17_10
 BV BND1      service_2_17_11
 BV BND1      service_2_17_12
 BV BND1      service_2_17_13
 BV BND1      service_2_17_14
 BV BND1      service_2_17_15
 BV BND1      service_2_17_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  13
 UP BND1      visit_0_22  1
 UP BND1      order_0_22  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_0_22
 FX BND1      load_0_0_22  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_1_22
 UP BND1      load_0_1_22  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_2_22
 UP BND1      load_0_2_22  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_3_22
 UP BND1      load_0_3_22  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_4_22
 UP BND1      load_0_4_22  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_5_21
 UP BND1      load_0_5_21  20
 BV BND1      arc_0_5_22
 UP BND1      load_0_5_22  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_15_22
 UP BND1      load_0_15_22  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_16_22
 UP BND1      load_0_16_22  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_17_22
 UP BND1      load_0_17_22  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_18_22
 UP BND1      load_0_18_22  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_19_22
 UP BND1      load_0_19_22  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_20_22
 UP BND1      load_0_20_22  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_5
 UP BND1      load_0_21_5  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 BV BND1      arc_0_21_22
 UP BND1      load_0_21_22  20
 BV BND1      arc_0_22_0
 UP BND1      load_0_22_0  20
 BV BND1      arc_0_22_1
 UP BND1      load_0_22_1  20
 BV BND1      arc_0_22_2
 UP BND1      load_0_22_2  20
 BV BND1      arc_0_22_3
 UP BND1      load_0_22_3  20
 BV BND1      arc_0_22_4
 UP BND1      load_0_22_4  20
 BV BND1      arc_0_22_5
 UP BND1      load_0_22_5  20
 BV BND1      arc_0_22_15
 UP BND1      load_0_22_15  20
 BV BND1      arc_0_22_16
 UP BND1      load_0_22_16  20
 BV BND1      arc_0_22_17
 UP BND1      load_0_22_17  20
 BV BND1      arc_0_22_18
 UP BND1      load_0_22_18  20
 BV BND1      arc_0_22_19
 UP BND1      load_0_22_19  20
 BV BND1      arc_0_22_20
 UP BND1      load_0_22_20  20
 BV BND1      arc_0_22_21
 UP BND1      load_0_22_21  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  12
 UP BND1      visit_1_22  1
 UP BND1      order_1_22  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_0_22
 FX BND1      load_1_0_22  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_6_22
 UP BND1      load_1_6_22  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_7_22
 UP BND1      load_1_7_22  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_8_22
 UP BND1      load_1_8_22  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_9_22
 UP BND1      load_1_9_22  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_15_22
 UP BND1      load_1_15_22  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_16_22
 UP BND1      load_1_16_22  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_17_22
 UP BND1      load_1_17_22  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_18_22
 UP BND1      load_1_18_22  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_19_22
 UP BND1      load_1_19_22  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_20_22
 UP BND1      load_1_20_22  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 BV BND1      arc_1_21_22
 UP BND1      load_1_21_22  25
 BV BND1      arc_1_22_0
 UP BND1      load_1_22_0  25
 BV BND1      arc_1_22_6
 UP BND1      load_1_22_6  25
 BV BND1      arc_1_22_7
 UP BND1      load_1_22_7  25
 BV BND1      arc_1_22_8
 UP BND1      load_1_22_8  25
 BV BND1      arc_1_22_9
 UP BND1      load_1_22_9  25
 BV BND1      arc_1_22_15
 UP BND1      load_1_22_15  25
 BV BND1      arc_1_22_16
 UP BND1      load_1_22_16  25
 BV BND1      arc_1_22_17
 UP BND1      load_1_22_17  25
 BV BND1      arc_1_22_18
 UP BND1      load_1_22_18  25
 BV BND1      arc_1_22_19
 UP BND1      load_1_22_19  25
 BV BND1      arc_1_22_20
 UP BND1      load_1_22_20  25
 BV BND1      arc_1_22_21
 UP BND1      load_1_22_21  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  13
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  13
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  13
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  13
 FX BND1      visit_2_14  1
 UP BND1      order_2_14  13
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  13
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  13
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  13
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  13
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  13
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  13
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  13
 UP BND1      visit_2_22  1
 UP BND1      order_2_22  13
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_0_22
 FX BND1      load_2_0_22  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_10_22
 UP BND1      load_2_10_22  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_11_22
 UP BND1      load_2_11_22  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_12_22
 UP BND1      load_2_12_22  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_13_22
 UP BND1      load_2_13_22  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_14_22
 UP BND1      load_2_14_22  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_15_22
 UP BND1      load_2_15_22  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_16_22
 UP BND1      load_2_16_22  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_17_22
 UP BND1      load_2_17_22  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_18_22
 UP BND1      load_2_18_22  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_19_22
 UP BND1      load_2_19_22  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_20_22
 UP BND1      load_2_20_22  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
 BV BND1      arc_2_21_22
 UP BND1      load_2_21_22  30
 BV BND1      arc_2_22_0
 UP BND1      load_2_22_0  30
 BV BND1      arc_2_22_10
 UP BND1      load_2_22_10  30
 BV BND1      arc_2_22_11
 UP BND1      load_2_22_11  30
 BV BND1      arc_2_22_12
 UP BND1      load_2_22_12  30
 BV BND1      arc_2_22_13
 UP BND1      load_2_22_13  30
 BV BND1      arc_2_22_14
 UP BND1      load_2_22_14  30
 BV BND1      arc_2_22_15
 UP BND1      load_2_22_15  30
 BV BND1      arc_2_22_16
 UP BND1      load_2_22_16  30
 BV BND1      arc_2_22_17
 UP BND1      load_2_22_17  30
 BV BND1      arc_2_22_18
 UP BND1      load_2_22_18  30
 BV BND1      arc_2_22_19
 UP BND1      load_2_22_19  30
 BV BND1      arc_2_22_20
 UP BND1      load_2_22_20  30
 BV BND1      arc_2_22_21
 UP BND1      load_2_22_21  30
ENDATA
