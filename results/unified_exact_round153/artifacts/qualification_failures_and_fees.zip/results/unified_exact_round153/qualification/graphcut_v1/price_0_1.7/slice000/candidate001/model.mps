* Signature: 0x4881251700690f
NAME 
OBJSENSE MAX
ROWS
 N  OBJ
 G  R0      
 G  R1      
 G  R2      
 G  R3      
 L  label_0 
 L  label_1 
 L  label_2 
 L  label_3 
 L  label_4 
 L  label_5 
 L  label_6 
COLUMNS
    p         R0        -2
    p         R1        -5
    p         label_0   -5
    p         label_1   -2
    p         label_2   -3
    p         label_4   -12
    p         label_5   -9
    p         label_6   -3
    r         R2        -0.5
    r         R3        -1.8333333333333333e+00
    r         label_0   -1.5
    r         label_1   -0.5
    r         label_2   -0.75
    r         label_4   -7
    r         label_5   -4.5
    r         label_6   -1
    eta       label_0   1.375
    eta       label_1   0.125
    eta       label_2   0.1875
    eta       label_4   9.75
    eta       label_5   8.125
    eta       label_6   1.25
    theta     OBJ       1
    theta     label_0   1
    theta     label_1   1
    theta     label_2   1
    theta     label_3   1
    theta     label_4   1
    theta     label_5   1
    theta     label_6   1
    support_T  OBJ       -1
    support_T  R0        1
    support_T  R1        1
    support_S  OBJ       -1
    support_S  R2        1
    support_S  R3        1
RHS
    RHS1      label_0   -3.8181818181818183e-01
    RHS1      label_1   -6.5909090909090917e-02
    RHS1      label_2   9.6363636363636362e-01
    RHS1      label_3   -0.125
    RHS1      label_4   1.2295454545454545e+00
    RHS1      label_5   -8.8181818181818183e-01
    RHS1      label_6   -4.4090909090909092e-01
BOUNDS
 LO BND1      p         -5.075
 UP BND1      p         5.075
 LO BND1      r         -5.075
 UP BND1      r         5.075
 UP BND1      eta       5.075
 FR BND1      theta   
 FR BND1      support_T
 FR BND1      support_S
ENDATA
