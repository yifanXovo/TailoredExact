* Signature: 0x4f9eeef7eccbcd56
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_9_26
 E  normalized_mass_9_27
 E  normalized_ratio_9_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 E  onehot_6_51
 E  normalized_mass_6_52
 E  normalized_ratio_6_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 E  onehot_31_80
 E  normalized_mass_31_81
 E  normalized_ratio_31_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 E  onehot_15_117
 E  normalized_mass_15_118
 E  normalized_ratio_15_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 E  onehot_32_146
 E  normalized_mass_32_147
 E  normalized_ratio_32_148
 G  product_lb_149
 L  product_ub_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 E  onehot_13_189
 E  normalized_mass_13_190
 E  normalized_ratio_13_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 E  onehot_19_210
 E  normalized_mass_19_211
 E  normalized_ratio_19_212
 G  product_lb_213
 L  product_ub_214
 G  product_lb_215
 L  product_ub_216
 G  product_lb_217
 L  product_ub_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 E  onehot_12_245
 E  normalized_mass_12_246
 E  normalized_ratio_12_247
 G  stock_lb_248
 L  stock_ub_249
 L  parent_nonstrict_scope_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 E  normalization_307
 G  full_original_Gini_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 L  arc_capacity_413
 L  arc_capacity_414
 L  arc_capacity_415
 L  arc_capacity_416
 L  arc_capacity_417
 L  arc_capacity_418
 L  arc_capacity_419
 L  arc_capacity_420
 L  arc_capacity_421
 L  arc_capacity_422
 L  arc_capacity_423
 L  arc_capacity_424
 L  arc_capacity_425
 L  arc_capacity_426
 L  arc_capacity_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 G  connected_order_arc_626
 L  arc_capacity_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 G  connected_order_arc_651
 L  arc_capacity_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 G  connected_order_arc_676
 L  arc_capacity_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 G  connected_order_arc_701
 L  arc_capacity_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 L  arc_capacity_725
 G  connected_order_arc_726
 L  arc_capacity_727
 L  arc_capacity_728
 G  connected_order_arc_729
 L  arc_capacity_730
 G  connected_order_arc_731
 L  arc_capacity_732
 G  connected_order_arc_733
 L  arc_capacity_734
 G  connected_order_arc_735
 L  arc_capacity_736
 G  connected_order_arc_737
 L  arc_capacity_738
 G  connected_order_arc_739
 L  arc_capacity_740
 G  connected_order_arc_741
 L  arc_capacity_742
 G  connected_order_arc_743
 L  arc_capacity_744
 G  connected_order_arc_745
 L  arc_capacity_746
 G  connected_order_arc_747
 L  arc_capacity_748
 G  connected_order_arc_749
 L  arc_capacity_750
 G  connected_order_arc_751
 E  depot_departure_or_bypass_752
 E  depot_return_or_bypass_753
 E  out_degree_754
 E  in_degree_755
 G  order_active_lb_756
 L  order_active_ub_757
 E  segment_load_conservation_758
 G  segment_prefix_lb_759
 L  segment_prefix_ub_760
 E  out_degree_761
 E  in_degree_762
 G  order_active_lb_763
 L  order_active_ub_764
 E  segment_load_conservation_765
 G  segment_prefix_lb_766
 L  segment_prefix_ub_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  segment_load_conservation_772
 G  segment_prefix_lb_773
 L  segment_prefix_ub_774
 E  out_degree_775
 E  in_degree_776
 G  order_active_lb_777
 L  order_active_ub_778
 E  segment_load_conservation_779
 G  segment_prefix_lb_780
 L  segment_prefix_ub_781
 E  out_degree_782
 E  in_degree_783
 G  order_active_lb_784
 L  order_active_ub_785
 E  segment_load_conservation_786
 G  segment_prefix_lb_787
 L  segment_prefix_ub_788
 E  out_degree_789
 E  in_degree_790
 G  order_active_lb_791
 L  order_active_ub_792
 E  service_visit_def_793
 E  free_load_conservation_794
 E  out_degree_795
 E  in_degree_796
 G  order_active_lb_797
 L  order_active_ub_798
 E  service_visit_def_799
 E  free_load_conservation_800
 E  out_degree_801
 E  in_degree_802
 G  order_active_lb_803
 L  order_active_ub_804
 E  service_visit_def_805
 E  free_load_conservation_806
 E  out_degree_807
 E  in_degree_808
 G  order_active_lb_809
 L  order_active_ub_810
 E  service_visit_def_811
 E  free_load_conservation_812
 E  out_degree_813
 E  in_degree_814
 G  order_active_lb_815
 L  order_active_ub_816
 E  service_visit_def_817
 E  free_load_conservation_818
 E  out_degree_819
 E  in_degree_820
 G  order_active_lb_821
 L  order_active_ub_822
 E  service_visit_def_823
 E  free_load_conservation_824
 E  out_degree_825
 E  in_degree_826
 G  order_active_lb_827
 L  order_active_ub_828
 E  service_visit_def_829
 E  free_load_conservation_830
 E  out_degree_831
 E  in_degree_832
 G  order_active_lb_833
 L  order_active_ub_834
 E  service_visit_def_835
 E  free_load_conservation_836
 G  fixed_segment_relative_order_837
 G  fixed_segment_relative_order_838
 G  fixed_segment_relative_order_839
 G  fixed_segment_relative_order_840
 L  original_T_including_depot_unload_841
 L  arc_capacity_842
 L  arc_capacity_843
 L  arc_capacity_844
 L  arc_capacity_845
 L  arc_capacity_846
 L  arc_capacity_847
 L  arc_capacity_848
 L  arc_capacity_849
 L  arc_capacity_850
 L  arc_capacity_851
 L  arc_capacity_852
 L  arc_capacity_853
 L  arc_capacity_854
 L  arc_capacity_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 G  connected_order_arc_884
 L  arc_capacity_885
 G  connected_order_arc_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 L  arc_capacity_902
 G  connected_order_arc_903
 L  arc_capacity_904
 G  connected_order_arc_905
 L  arc_capacity_906
 G  connected_order_arc_907
 L  arc_capacity_908
 G  connected_order_arc_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 L  arc_capacity_925
 G  connected_order_arc_926
 L  arc_capacity_927
 G  connected_order_arc_928
 L  arc_capacity_929
 G  connected_order_arc_930
 L  arc_capacity_931
 G  connected_order_arc_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 L  arc_capacity_948
 G  connected_order_arc_949
 L  arc_capacity_950
 G  connected_order_arc_951
 L  arc_capacity_952
 G  connected_order_arc_953
 L  arc_capacity_954
 G  connected_order_arc_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 L  arc_capacity_971
 G  connected_order_arc_972
 L  arc_capacity_973
 G  connected_order_arc_974
 L  arc_capacity_975
 G  connected_order_arc_976
 L  arc_capacity_977
 G  connected_order_arc_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 L  arc_capacity_994
 G  connected_order_arc_995
 L  arc_capacity_996
 G  connected_order_arc_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 L  arc_capacity_1017
 G  connected_order_arc_1018
 L  arc_capacity_1019
 G  connected_order_arc_1020
 L  arc_capacity_1021
 G  connected_order_arc_1022
 L  arc_capacity_1023
 G  connected_order_arc_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 L  arc_capacity_1040
 G  connected_order_arc_1041
 L  arc_capacity_1042
 G  connected_order_arc_1043
 L  arc_capacity_1044
 G  connected_order_arc_1045
 L  arc_capacity_1046
 G  connected_order_arc_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 L  arc_capacity_1063
 G  connected_order_arc_1064
 L  arc_capacity_1065
 G  connected_order_arc_1066
 L  arc_capacity_1067
 G  connected_order_arc_1068
 L  arc_capacity_1069
 G  connected_order_arc_1070
 L  arc_capacity_1071
 G  connected_order_arc_1072
 L  arc_capacity_1073
 G  connected_order_arc_1074
 L  arc_capacity_1075
 G  connected_order_arc_1076
 L  arc_capacity_1077
 G  connected_order_arc_1078
 L  arc_capacity_1079
 G  connected_order_arc_1080
 L  arc_capacity_1081
 G  connected_order_arc_1082
 L  arc_capacity_1083
 G  connected_order_arc_1084
 L  arc_capacity_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 G  connected_order_arc_1089
 L  arc_capacity_1090
 G  connected_order_arc_1091
 L  arc_capacity_1092
 G  connected_order_arc_1093
 L  arc_capacity_1094
 G  connected_order_arc_1095
 L  arc_capacity_1096
 G  connected_order_arc_1097
 L  arc_capacity_1098
 G  connected_order_arc_1099
 L  arc_capacity_1100
 G  connected_order_arc_1101
 L  arc_capacity_1102
 G  connected_order_arc_1103
 L  arc_capacity_1104
 G  connected_order_arc_1105
 L  arc_capacity_1106
 G  connected_order_arc_1107
 L  arc_capacity_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 G  connected_order_arc_1114
 L  arc_capacity_1115
 G  connected_order_arc_1116
 L  arc_capacity_1117
 G  connected_order_arc_1118
 L  arc_capacity_1119
 G  connected_order_arc_1120
 L  arc_capacity_1121
 G  connected_order_arc_1122
 L  arc_capacity_1123
 G  connected_order_arc_1124
 L  arc_capacity_1125
 G  connected_order_arc_1126
 L  arc_capacity_1127
 G  connected_order_arc_1128
 L  arc_capacity_1129
 G  connected_order_arc_1130
 E  depot_departure_or_bypass_1131
 E  depot_return_or_bypass_1132
 E  out_degree_1133
 E  in_degree_1134
 G  order_active_lb_1135
 L  order_active_ub_1136
 E  segment_load_conservation_1137
 G  segment_prefix_lb_1138
 L  segment_prefix_ub_1139
 E  out_degree_1140
 E  in_degree_1141
 G  order_active_lb_1142
 L  order_active_ub_1143
 E  segment_load_conservation_1144
 G  segment_prefix_lb_1145
 L  segment_prefix_ub_1146
 E  out_degree_1147
 E  in_degree_1148
 G  order_active_lb_1149
 L  order_active_ub_1150
 E  segment_load_conservation_1151
 G  segment_prefix_lb_1152
 L  segment_prefix_ub_1153
 E  out_degree_1154
 E  in_degree_1155
 G  order_active_lb_1156
 L  order_active_ub_1157
 E  segment_load_conservation_1158
 G  segment_prefix_lb_1159
 L  segment_prefix_ub_1160
 E  out_degree_1161
 E  in_degree_1162
 G  order_active_lb_1163
 L  order_active_ub_1164
 E  service_visit_def_1165
 E  free_load_conservation_1166
 E  out_degree_1167
 E  in_degree_1168
 G  order_active_lb_1169
 L  order_active_ub_1170
 E  service_visit_def_1171
 E  free_load_conservation_1172
 E  out_degree_1173
 E  in_degree_1174
 G  order_active_lb_1175
 L  order_active_ub_1176
 E  service_visit_def_1177
 E  free_load_conservation_1178
 E  out_degree_1179
 E  in_degree_1180
 G  order_active_lb_1181
 L  order_active_ub_1182
 E  service_visit_def_1183
 E  free_load_conservation_1184
 E  out_degree_1185
 E  in_degree_1186
 G  order_active_lb_1187
 L  order_active_ub_1188
 E  service_visit_def_1189
 E  free_load_conservation_1190
 E  out_degree_1191
 E  in_degree_1192
 G  order_active_lb_1193
 L  order_active_ub_1194
 E  service_visit_def_1195
 E  free_load_conservation_1196
 E  out_degree_1197
 E  in_degree_1198
 G  order_active_lb_1199
 L  order_active_ub_1200
 E  service_visit_def_1201
 E  free_load_conservation_1202
 E  out_degree_1203
 E  in_degree_1204
 G  order_active_lb_1205
 L  order_active_ub_1206
 E  service_visit_def_1207
 E  free_load_conservation_1208
 G  fixed_segment_relative_order_1209
 G  fixed_segment_relative_order_1210
 G  fixed_segment_relative_order_1211
 L  original_T_including_depot_unload_1212
 L  arc_capacity_1213
 L  arc_capacity_1214
 L  arc_capacity_1215
 L  arc_capacity_1216
 L  arc_capacity_1217
 L  arc_capacity_1218
 L  arc_capacity_1219
 L  arc_capacity_1220
 L  arc_capacity_1221
 L  arc_capacity_1222
 L  arc_capacity_1223
 L  arc_capacity_1224
 L  arc_capacity_1225
 L  arc_capacity_1226
 G  connected_order_arc_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 L  arc_capacity_1247
 G  connected_order_arc_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 L  arc_capacity_1268
 G  connected_order_arc_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 L  arc_capacity_1289
 G  connected_order_arc_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 L  arc_capacity_1310
 G  connected_order_arc_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 G  connected_order_arc_1403
 L  arc_capacity_1404
 G  connected_order_arc_1405
 L  arc_capacity_1406
 G  connected_order_arc_1407
 L  arc_capacity_1408
 G  connected_order_arc_1409
 L  arc_capacity_1410
 G  connected_order_arc_1411
 L  arc_capacity_1412
 G  connected_order_arc_1413
 L  arc_capacity_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 G  connected_order_arc_1426
 L  arc_capacity_1427
 G  connected_order_arc_1428
 L  arc_capacity_1429
 G  connected_order_arc_1430
 L  arc_capacity_1431
 G  connected_order_arc_1432
 L  arc_capacity_1433
 G  connected_order_arc_1434
 L  arc_capacity_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 G  connected_order_arc_1449
 L  arc_capacity_1450
 G  connected_order_arc_1451
 L  arc_capacity_1452
 G  connected_order_arc_1453
 L  arc_capacity_1454
 G  connected_order_arc_1455
 E  depot_departure_or_bypass_1456
 E  depot_return_or_bypass_1457
 E  out_degree_1458
 E  in_degree_1459
 G  order_active_lb_1460
 L  order_active_ub_1461
 E  segment_load_conservation_1462
 G  segment_prefix_lb_1463
 L  segment_prefix_ub_1464
 E  out_degree_1465
 E  in_degree_1466
 G  order_active_lb_1467
 L  order_active_ub_1468
 E  segment_load_conservation_1469
 G  segment_prefix_lb_1470
 L  segment_prefix_ub_1471
 E  out_degree_1472
 E  in_degree_1473
 G  order_active_lb_1474
 L  order_active_ub_1475
 E  segment_load_conservation_1476
 G  segment_prefix_lb_1477
 L  segment_prefix_ub_1478
 E  out_degree_1479
 E  in_degree_1480
 G  order_active_lb_1481
 L  order_active_ub_1482
 E  service_visit_def_1483
 E  free_load_conservation_1484
 E  out_degree_1485
 E  in_degree_1486
 G  order_active_lb_1487
 L  order_active_ub_1488
 E  service_visit_def_1489
 E  free_load_conservation_1490
 E  out_degree_1491
 E  in_degree_1492
 G  order_active_lb_1493
 L  order_active_ub_1494
 E  service_visit_def_1495
 E  free_load_conservation_1496
 E  out_degree_1497
 E  in_degree_1498
 G  order_active_lb_1499
 L  order_active_ub_1500
 E  service_visit_def_1501
 E  free_load_conservation_1502
 E  out_degree_1503
 E  in_degree_1504
 G  order_active_lb_1505
 L  order_active_ub_1506
 E  service_visit_def_1507
 E  free_load_conservation_1508
 E  out_degree_1509
 E  in_degree_1510
 G  order_active_lb_1511
 L  order_active_ub_1512
 E  service_visit_def_1513
 E  free_load_conservation_1514
 E  out_degree_1515
 E  in_degree_1516
 G  order_active_lb_1517
 L  order_active_ub_1518
 E  service_visit_def_1519
 E  free_load_conservation_1520
 E  out_degree_1521
 E  in_degree_1522
 G  order_active_lb_1523
 L  order_active_ub_1524
 E  service_visit_def_1525
 E  free_load_conservation_1526
 G  fixed_segment_relative_order_1527
 G  fixed_segment_relative_order_1528
 L  original_T_including_depot_unload_1529
COLUMNS
    t         normalized_mass_9_27  -1
    t         normalized_mass_6_52  -1
    t         normalized_mass_31_81  -1
    t         normalized_mass_15_118  -1
    t         normalized_mass_32_147  -1
    t         normalized_mass_13_190  -1
    t         normalized_mass_19_211  -1
    t         normalized_mass_12_246  -1
    t         normalization_307  2.4010714285714286e+01
    t         full_original_Gini_308  -7.2730952380952431e+01
    q         OBJ       1
    q         parent_nonstrict_scope_250  1
    q         full_original_Gini_308  35
    MARKER    'MARKER'                 'INTORG'
    x_9_0     OBJ       1.1249999999999993e-02
    x_9_0     product_lb_0  -2.4497414161813971e-02
    x_9_0     product_ub_1  -4.1648073776629491e-02
    x_9_0     onehot_9_26  1
    x_9_0     parent_nonstrict_scope_250  0.0375
    x_9_0     unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_0     product_lb_0  1
    w_9_0     product_ub_1  1
    w_9_0     normalized_mass_9_27  1
    w_9_0     full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_1     OBJ       3.7499999999999929e-03
    x_9_1     product_lb_2  -2.4497414161813971e-02
    x_9_1     product_ub_3  -4.1648073776629491e-02
    x_9_1     onehot_9_26  1
    x_9_1     stock_lb_248  1
    x_9_1     stock_ub_249  1
    x_9_1     parent_nonstrict_scope_250  0.03
    x_9_1     unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_1     product_lb_2  1
    w_9_1     product_ub_3  1
    w_9_1     normalized_mass_9_27  1
    w_9_1     normalized_ratio_9_28  -0.2
    w_9_1     full_original_Gini_308  -1.9010714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_2     OBJ       -3.7500000000000068e-03
    x_9_2     product_lb_4  -2.4497414161813971e-02
    x_9_2     product_ub_5  -4.1648073776629491e-02
    x_9_2     onehot_9_26  1
    x_9_2     stock_lb_248  2
    x_9_2     stock_ub_249  2
    x_9_2     parent_nonstrict_scope_250  0.0225
    x_9_2     unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_2     product_lb_4  1
    w_9_2     product_ub_5  1
    w_9_2     normalized_mass_9_27  1
    w_9_2     normalized_ratio_9_28  -0.4
    w_9_2     full_original_Gini_308  -1.4010714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_3     OBJ       -1.1250000000000010e-02
    x_9_3     product_lb_6  -2.4497414161813971e-02
    x_9_3     product_ub_7  -4.1648073776629491e-02
    x_9_3     onehot_9_26  1
    x_9_3     stock_lb_248  3
    x_9_3     stock_ub_249  3
    x_9_3     parent_nonstrict_scope_250  1.4999999999999996e-02
    x_9_3     unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_3     product_lb_6  1
    w_9_3     product_ub_7  1
    w_9_3     normalized_mass_9_27  1
    w_9_3     normalized_ratio_9_28  -6.0000000000000009e-01
    w_9_3     full_original_Gini_308  -9.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_4     OBJ       -1.8750000000000010e-02
    x_9_4     product_lb_8  -2.4497414161813971e-02
    x_9_4     product_ub_9  -4.1648073776629491e-02
    x_9_4     onehot_9_26  1
    x_9_4     stock_lb_248  4
    x_9_4     stock_ub_249  4
    x_9_4     parent_nonstrict_scope_250  7.4999999999999980e-03
    x_9_4     unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_4     product_lb_8  1
    w_9_4     product_ub_9  1
    w_9_4     normalized_mass_9_27  1
    w_9_4     normalized_ratio_9_28  -0.8
    w_9_4     full_original_Gini_308  -5.5345238095238107e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_5     OBJ       -2.6250000000000006e-02
    x_9_5     product_lb_10  -2.4497414161813971e-02
    x_9_5     product_ub_11  -4.1648073776629491e-02
    x_9_5     onehot_9_26  1
    x_9_5     stock_lb_248  5
    x_9_5     stock_ub_249  5
    x_9_5     unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_5     product_lb_10  1
    w_9_5     product_ub_11  1
    w_9_5     normalized_mass_9_27  1
    w_9_5     normalized_ratio_9_28  -1
    w_9_5     full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_9_6     OBJ       -0.01875
    x_9_6     product_lb_12  -2.4497414161813971e-02
    x_9_6     product_ub_13  -4.1648073776629491e-02
    x_9_6     onehot_9_26  1
    x_9_6     stock_lb_248  6
    x_9_6     stock_ub_249  6
    x_9_6     parent_nonstrict_scope_250  7.5000000000000067e-03
    x_9_6     unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_6     product_lb_12  1
    w_9_6     product_ub_13  1
    w_9_6     normalized_mass_9_27  1
    w_9_6     normalized_ratio_9_28  -1.2000000000000002e+00
    w_9_6     full_original_Gini_308  -8.38928571428572
    MARKER    'MARKER'                 'INTORG'
    x_9_7     OBJ       -1.1250000000000001e-02
    x_9_7     product_lb_14  -2.4497414161813971e-02
    x_9_7     product_ub_15  -4.1648073776629491e-02
    x_9_7     onehot_9_26  1
    x_9_7     stock_lb_248  7
    x_9_7     stock_ub_249  7
    x_9_7     parent_nonstrict_scope_250  1.5000000000000005e-02
    x_9_7     unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_7     product_lb_14  1
    w_9_7     product_ub_15  1
    w_9_7     normalized_mass_9_27  1
    w_9_7     normalized_ratio_9_28  -1.4000000000000001e+00
    w_9_7     full_original_Gini_308  -1.3789285714285722e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_8     OBJ       -3.7500000000000033e-03
    x_9_8     product_lb_16  -2.4497414161813971e-02
    x_9_8     product_ub_17  -4.1648073776629491e-02
    x_9_8     onehot_9_26  1
    x_9_8     stock_lb_248  8
    x_9_8     stock_ub_249  8
    x_9_8     parent_nonstrict_scope_250  2.2500000000000003e-02
    MARKER    'MARKER'                 'INTEND'
    w_9_8     product_lb_16  1
    w_9_8     product_ub_17  1
    w_9_8     normalized_mass_9_27  1
    w_9_8     normalized_ratio_9_28  -1.6
    w_9_8     full_original_Gini_308  -1.9189285714285717e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_9     OBJ       3.7499999999999929e-03
    x_9_9     product_lb_18  -2.4497414161813971e-02
    x_9_9     product_ub_19  -4.1648073776629491e-02
    x_9_9     onehot_9_26  1
    x_9_9     stock_lb_248  9
    x_9_9     stock_ub_249  9
    x_9_9     parent_nonstrict_scope_250  0.03
    x_9_9     unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_9     product_lb_18  1
    w_9_9     product_ub_19  1
    w_9_9     normalized_mass_9_27  1
    w_9_9     normalized_ratio_9_28  -1.8
    w_9_9     full_original_Gini_308  -2.4589285714285719e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_10    OBJ       1.1249999999999993e-02
    x_9_10    product_lb_20  -2.4497414161813971e-02
    x_9_10    product_ub_21  -4.1648073776629491e-02
    x_9_10    onehot_9_26  1
    x_9_10    stock_lb_248  10
    x_9_10    stock_ub_249  10
    x_9_10    parent_nonstrict_scope_250  0.0375
    x_9_10    unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_10    product_lb_20  1
    w_9_10    product_ub_21  1
    w_9_10    normalized_mass_9_27  1
    w_9_10    normalized_ratio_9_28  -2
    w_9_10    full_original_Gini_308  -2.9989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_11    OBJ       0.01875
    x_9_11    product_lb_22  -2.4497414161813971e-02
    x_9_11    product_ub_23  -4.1648073776629491e-02
    x_9_11    onehot_9_26  1
    x_9_11    stock_lb_248  11
    x_9_11    stock_ub_249  11
    x_9_11    parent_nonstrict_scope_250  4.5000000000000005e-02
    x_9_11    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_11    product_lb_22  1
    w_9_11    product_ub_23  1
    w_9_11    normalized_mass_9_27  1
    w_9_11    normalized_ratio_9_28  -2.2
    w_9_11    full_original_Gini_308  -3.5389285714285705e+01
    MARKER    'MARKER'                 'INTORG'
    x_9_12    OBJ       2.6250000000000006e-02
    x_9_12    product_lb_24  -2.4497414161813971e-02
    x_9_12    product_ub_25  -4.1648073776629491e-02
    x_9_12    onehot_9_26  1
    x_9_12    stock_lb_248  12
    x_9_12    stock_ub_249  12
    x_9_12    parent_nonstrict_scope_250  5.2500000000000012e-02
    x_9_12    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_9_12    product_lb_24  1
    w_9_12    product_ub_25  1
    w_9_12    normalized_mass_9_27  1
    w_9_12    normalized_ratio_9_28  -2.4000000000000004e+00
    w_9_12    full_original_Gini_308  -4.0789285714285711e+01
    rho_9     normalized_ratio_9_28  1
    rho_9     block_pair_pos_263  -1
    rho_9     block_pair_neg_264  1
    rho_9     block_pair_pos_265  -1
    rho_9     block_pair_neg_266  1
    rho_9     block_pair_pos_267  -1
    rho_9     block_pair_neg_268  1
    rho_9     block_pair_pos_269  -1
    rho_9     block_pair_neg_270  1
    rho_9     block_pair_pos_271  -1
    rho_9     block_pair_neg_272  1
    rho_9     block_pair_pos_273  -1
    rho_9     block_pair_neg_274  1
    rho_9     block_pair_pos_275  -1
    rho_9     block_pair_neg_276  1
    rho_9     normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_6_0     OBJ       0.01875
    x_6_0     product_lb_29  -2.4497414161813971e-02
    x_6_0     product_ub_30  -4.1648073776629491e-02
    x_6_0     onehot_6_51  1
    x_6_0     parent_nonstrict_scope_250  0.0375
    x_6_0     unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_0     product_lb_29  1
    w_6_0     product_ub_30  1
    w_6_0     normalized_mass_6_52  1
    w_6_0     full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_1     OBJ       0.01125
    x_6_1     product_lb_31  -2.4497414161813971e-02
    x_6_1     product_ub_32  -4.1648073776629491e-02
    x_6_1     onehot_6_51  1
    x_6_1     stock_lb_248  1
    x_6_1     stock_ub_249  1
    x_6_1     parent_nonstrict_scope_250  0.03
    MARKER    'MARKER'                 'INTEND'
    w_6_1     product_lb_31  1
    w_6_1     product_ub_32  1
    w_6_1     normalized_mass_6_52  1
    w_6_1     normalized_ratio_6_53  -0.2
    w_6_1     full_original_Gini_308  -1.9010714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_2     OBJ       0.00375
    x_6_2     product_lb_33  -2.4497414161813971e-02
    x_6_2     product_ub_34  -4.1648073776629491e-02
    x_6_2     onehot_6_51  1
    x_6_2     stock_lb_248  2
    x_6_2     stock_ub_249  2
    x_6_2     parent_nonstrict_scope_250  0.0225
    x_6_2     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_2     product_lb_33  1
    w_6_2     product_ub_34  1
    w_6_2     normalized_mass_6_52  1
    w_6_2     normalized_ratio_6_53  -0.4
    w_6_2     full_original_Gini_308  -1.4010714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_3     OBJ       -3.7500000000000033e-03
    x_6_3     product_lb_35  -2.4497414161813971e-02
    x_6_3     product_ub_36  -4.1648073776629491e-02
    x_6_3     onehot_6_51  1
    x_6_3     stock_lb_248  3
    x_6_3     stock_ub_249  3
    x_6_3     parent_nonstrict_scope_250  1.4999999999999996e-02
    x_6_3     unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_3     product_lb_35  1
    w_6_3     product_ub_36  1
    w_6_3     normalized_mass_6_52  1
    w_6_3     normalized_ratio_6_53  -6.0000000000000009e-01
    w_6_3     full_original_Gini_308  -9.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_4     OBJ       -1.1250000000000001e-02
    x_6_4     product_lb_37  -2.4497414161813971e-02
    x_6_4     product_ub_38  -4.1648073776629491e-02
    x_6_4     onehot_6_51  1
    x_6_4     stock_lb_248  4
    x_6_4     stock_ub_249  4
    x_6_4     parent_nonstrict_scope_250  7.4999999999999980e-03
    x_6_4     unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_4     product_lb_37  1
    w_6_4     product_ub_38  1
    w_6_4     normalized_mass_6_52  1
    w_6_4     normalized_ratio_6_53  -0.8
    w_6_4     full_original_Gini_308  -5.5345238095238107e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_5     OBJ       -0.01875
    x_6_5     product_lb_39  -2.4497414161813971e-02
    x_6_5     product_ub_40  -4.1648073776629491e-02
    x_6_5     onehot_6_51  1
    x_6_5     stock_lb_248  5
    x_6_5     stock_ub_249  5
    x_6_5     unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_5     product_lb_39  1
    w_6_5     product_ub_40  1
    w_6_5     normalized_mass_6_52  1
    w_6_5     normalized_ratio_6_53  -1
    w_6_5     full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_6_6     OBJ       -1.1249999999999993e-02
    x_6_6     product_lb_41  -2.4497414161813971e-02
    x_6_6     product_ub_42  -4.1648073776629491e-02
    x_6_6     onehot_6_51  1
    x_6_6     stock_lb_248  6
    x_6_6     stock_ub_249  6
    x_6_6     parent_nonstrict_scope_250  7.5000000000000067e-03
    x_6_6     unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_6     product_lb_41  1
    w_6_6     product_ub_42  1
    w_6_6     normalized_mass_6_52  1
    w_6_6     normalized_ratio_6_53  -1.2000000000000002e+00
    w_6_6     full_original_Gini_308  -8.38928571428572
    MARKER    'MARKER'                 'INTORG'
    x_6_7     OBJ       -3.7499999999999947e-03
    x_6_7     product_lb_43  -2.4497414161813971e-02
    x_6_7     product_ub_44  -4.1648073776629491e-02
    x_6_7     onehot_6_51  1
    x_6_7     stock_lb_248  7
    x_6_7     stock_ub_249  7
    x_6_7     parent_nonstrict_scope_250  1.5000000000000005e-02
    x_6_7     unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_7     product_lb_43  1
    w_6_7     product_ub_44  1
    w_6_7     normalized_mass_6_52  1
    w_6_7     normalized_ratio_6_53  -1.4000000000000001e+00
    w_6_7     full_original_Gini_308  -1.3789285714285722e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_8     OBJ       3.7500000000000033e-03
    x_6_8     product_lb_45  -2.4497414161813971e-02
    x_6_8     product_ub_46  -4.1648073776629491e-02
    x_6_8     onehot_6_51  1
    x_6_8     stock_lb_248  8
    x_6_8     stock_ub_249  8
    x_6_8     parent_nonstrict_scope_250  2.2500000000000003e-02
    x_6_8     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_8     product_lb_45  1
    w_6_8     product_ub_46  1
    w_6_8     normalized_mass_6_52  1
    w_6_8     normalized_ratio_6_53  -1.6
    w_6_8     full_original_Gini_308  -1.9189285714285717e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_9     OBJ       0.01125
    x_6_9     product_lb_47  -2.4497414161813971e-02
    x_6_9     product_ub_48  -4.1648073776629491e-02
    x_6_9     onehot_6_51  1
    x_6_9     stock_lb_248  9
    x_6_9     stock_ub_249  9
    x_6_9     parent_nonstrict_scope_250  0.03
    x_6_9     unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_9     product_lb_47  1
    w_6_9     product_ub_48  1
    w_6_9     normalized_mass_6_52  1
    w_6_9     normalized_ratio_6_53  -1.8
    w_6_9     full_original_Gini_308  -2.4589285714285719e+01
    MARKER    'MARKER'                 'INTORG'
    x_6_10    OBJ       0.01875
    x_6_10    product_lb_49  -2.4497414161813971e-02
    x_6_10    product_ub_50  -4.1648073776629491e-02
    x_6_10    onehot_6_51  1
    x_6_10    stock_lb_248  10
    x_6_10    stock_ub_249  10
    x_6_10    parent_nonstrict_scope_250  0.0375
    x_6_10    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_6_10    product_lb_49  1
    w_6_10    product_ub_50  1
    w_6_10    normalized_mass_6_52  1
    w_6_10    normalized_ratio_6_53  -2
    w_6_10    full_original_Gini_308  -2.9989285714285714e+01
    rho_6     normalized_ratio_6_53  1
    rho_6     block_pair_pos_251  -1
    rho_6     block_pair_neg_252  1
    rho_6     block_pair_pos_253  -1
    rho_6     block_pair_neg_254  1
    rho_6     block_pair_pos_255  -1
    rho_6     block_pair_neg_256  1
    rho_6     block_pair_pos_257  -1
    rho_6     block_pair_neg_258  1
    rho_6     block_pair_pos_259  -1
    rho_6     block_pair_neg_260  1
    rho_6     block_pair_pos_261  -1
    rho_6     block_pair_neg_262  1
    rho_6     block_pair_pos_263  1
    rho_6     block_pair_neg_264  -1
    rho_6     normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_54  -2.4497414161813971e-02
    x_31_0    product_ub_55  -4.1648073776629491e-02
    x_31_0    onehot_31_80  1
    x_31_0    parent_nonstrict_scope_250  0.0735
    x_31_0    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_54  1
    w_31_0    product_ub_55  1
    w_31_0    normalized_mass_31_81  1
    w_31_0    full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_56  -2.4497414161813971e-02
    x_31_1    product_ub_57  -4.1648073776629491e-02
    x_31_1    onehot_31_80  1
    x_31_1    stock_lb_248  1
    x_31_1    stock_ub_249  1
    x_31_1    parent_nonstrict_scope_250  0.063
    x_31_1    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_56  1
    w_31_1    product_ub_57  1
    w_31_1    normalized_mass_31_81  1
    w_31_1    normalized_ratio_31_82  -1.4285714285714285e-01
    w_31_1    full_original_Gini_308  -2.0439285714285720e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_58  -2.4497414161813971e-02
    x_31_2    product_ub_59  -4.1648073776629491e-02
    x_31_2    onehot_31_80  1
    x_31_2    stock_lb_248  2
    x_31_2    stock_ub_249  2
    x_31_2    parent_nonstrict_scope_250  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_58  1
    w_31_2    product_ub_59  1
    w_31_2    normalized_mass_31_81  1
    w_31_2    normalized_ratio_31_82  -2.8571428571428570e-01
    w_31_2    full_original_Gini_308  -1.6867857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_60  -2.4497414161813971e-02
    x_31_3    product_ub_61  -4.1648073776629491e-02
    x_31_3    onehot_31_80  1
    x_31_3    stock_lb_248  3
    x_31_3    stock_ub_249  3
    x_31_3    parent_nonstrict_scope_250  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_60  1
    w_31_3    product_ub_61  1
    w_31_3    normalized_mass_31_81  1
    w_31_3    normalized_ratio_31_82  -4.2857142857142855e-01
    w_31_3    full_original_Gini_308  -1.3353571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_62  -2.4497414161813971e-02
    x_31_4    product_ub_63  -4.1648073776629491e-02
    x_31_4    onehot_31_80  1
    x_31_4    stock_lb_248  4
    x_31_4    stock_ub_249  4
    x_31_4    parent_nonstrict_scope_250  0.0315
    x_31_4    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_62  1
    w_31_4    product_ub_63  1
    w_31_4    normalized_mass_31_81  1
    w_31_4    normalized_ratio_31_82  -5.7142857142857140e-01
    w_31_4    full_original_Gini_308  -1.0067857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_64  -2.4497414161813971e-02
    x_31_5    product_ub_65  -4.1648073776629491e-02
    x_31_5    onehot_31_80  1
    x_31_5    stock_lb_248  5
    x_31_5    stock_ub_249  5
    x_31_5    parent_nonstrict_scope_250  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_64  1
    w_31_5    product_ub_65  1
    w_31_5    normalized_mass_31_81  1
    w_31_5    normalized_ratio_31_82  -7.1428571428571419e-01
    w_31_5    full_original_Gini_308  -7.1630952380952380e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_66  -2.4497414161813971e-02
    x_31_6    product_ub_67  -4.1648073776629491e-02
    x_31_6    onehot_31_80  1
    x_31_6    stock_lb_248  6
    x_31_6    stock_ub_249  6
    x_31_6    parent_nonstrict_scope_250  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_66  1
    w_31_6    product_ub_67  1
    w_31_6    normalized_mass_31_81  1
    w_31_6    normalized_ratio_31_82  -8.5714285714285710e-01
    w_31_6    full_original_Gini_308  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_68  -2.4497414161813971e-02
    x_31_7    product_ub_69  -4.1648073776629491e-02
    x_31_7    onehot_31_80  1
    x_31_7    stock_lb_248  7
    x_31_7    stock_ub_249  7
    x_31_7    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_68  1
    w_31_7    product_ub_69  1
    w_31_7    normalized_mass_31_81  1
    w_31_7    normalized_ratio_31_82  -1
    w_31_7    full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_70  -2.4497414161813971e-02
    x_31_8    product_ub_71  -4.1648073776629491e-02
    x_31_8    onehot_31_80  1
    x_31_8    stock_lb_248  8
    x_31_8    stock_ub_249  8
    x_31_8    parent_nonstrict_scope_250  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_70  1
    w_31_8    product_ub_71  1
    w_31_8    normalized_mass_31_81  1
    w_31_8    normalized_ratio_31_82  -1.1428571428571428e+00
    w_31_8    full_original_Gini_308  -6.9607142857142819e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_72  -2.4497414161813971e-02
    x_31_9    product_ub_73  -4.1648073776629491e-02
    x_31_9    onehot_31_80  1
    x_31_9    stock_lb_248  9
    x_31_9    stock_ub_249  9
    x_31_9    parent_nonstrict_scope_250  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_72  1
    w_31_9    product_ub_73  1
    w_31_9    normalized_mass_31_81  1
    w_31_9    normalized_ratio_31_82  -1.2857142857142856e+00
    w_31_9    full_original_Gini_308  -1.0703571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_74  -2.4497414161813971e-02
    x_31_10   product_ub_75  -4.1648073776629491e-02
    x_31_10   onehot_31_80  1
    x_31_10   stock_lb_248  10
    x_31_10   stock_ub_249  10
    x_31_10   parent_nonstrict_scope_250  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_74  1
    w_31_10   product_ub_75  1
    w_31_10   normalized_mass_31_81  1
    w_31_10   normalized_ratio_31_82  -1.4285714285714284e+00
    w_31_10   full_original_Gini_308  -1.4560714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_76  -2.4497414161813971e-02
    x_31_11   product_ub_77  -4.1648073776629491e-02
    x_31_11   onehot_31_80  1
    x_31_11   stock_lb_248  11
    x_31_11   stock_ub_249  11
    x_31_11   parent_nonstrict_scope_250  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_76  1
    w_31_11   product_ub_77  1
    w_31_11   normalized_mass_31_81  1
    w_31_11   normalized_ratio_31_82  -1.5714285714285714e+00
    w_31_11   full_original_Gini_308  -1.8417857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_78  -2.4497414161813971e-02
    x_31_12   product_ub_79  -4.1648073776629491e-02
    x_31_12   onehot_31_80  1
    x_31_12   stock_lb_248  12
    x_31_12   stock_ub_249  12
    x_31_12   parent_nonstrict_scope_250  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_78  1
    w_31_12   product_ub_79  1
    w_31_12   normalized_mass_31_81  1
    w_31_12   normalized_ratio_31_82  -1.7142857142857142e+00
    w_31_12   full_original_Gini_308  -2.2275000000000002e+01
    rho_31    normalized_ratio_31_82  1
    rho_31    block_pair_pos_259  1
    rho_31    block_pair_neg_260  -1
    rho_31    block_pair_pos_273  1
    rho_31    block_pair_neg_274  -1
    rho_31    block_pair_pos_291  -1
    rho_31    block_pair_neg_292  1
    rho_31    block_pair_pos_293  -1
    rho_31    block_pair_neg_294  1
    rho_31    block_pair_pos_295  -1
    rho_31    block_pair_neg_296  1
    rho_31    block_pair_pos_297  -1
    rho_31    block_pair_neg_298  1
    rho_31    block_pair_pos_299  -1
    rho_31    block_pair_neg_300  1
    rho_31    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_15_0    OBJ       0.06075
    x_15_0    product_lb_83  -2.4497414161813971e-02
    x_15_0    product_ub_84  -4.1648073776629491e-02
    x_15_0    onehot_15_117  1
    x_15_0    parent_nonstrict_scope_250  0.1215
    x_15_0    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_0    product_lb_83  1
    w_15_0    product_ub_84  1
    w_15_0    normalized_mass_15_118  1
    w_15_0    full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_1    OBJ       4.7249999999999986e-02
    x_15_1    product_lb_85  -2.4497414161813971e-02
    x_15_1    product_ub_86  -4.1648073776629491e-02
    x_15_1    onehot_15_117  1
    x_15_1    stock_lb_248  1
    x_15_1    stock_ub_249  1
    x_15_1    parent_nonstrict_scope_250  1.0799999999999998e-01
    x_15_1    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_1    product_lb_85  1
    w_15_1    product_ub_86  1
    w_15_1    normalized_mass_15_118  1
    w_15_1    normalized_ratio_15_119  -1.1111111111111110e-01
    w_15_1    full_original_Gini_308  -2.1232936507936511e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_2    OBJ       0.03375
    x_15_2    product_lb_87  -2.4497414161813971e-02
    x_15_2    product_ub_88  -4.1648073776629491e-02
    x_15_2    onehot_15_117  1
    x_15_2    stock_lb_248  2
    x_15_2    stock_ub_249  2
    x_15_2    parent_nonstrict_scope_250  0.0945
    x_15_2    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_2    product_lb_87  1
    w_15_2    product_ub_88  1
    w_15_2    normalized_mass_15_118  1
    w_15_2    normalized_ratio_15_119  -2.2222222222222221e-01
    w_15_2    full_original_Gini_308  -1.8455158730158736e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_3    OBJ       2.0250000000000004e-02
    x_15_3    product_lb_89  -2.4497414161813971e-02
    x_15_3    product_ub_90  -4.1648073776629491e-02
    x_15_3    onehot_15_117  1
    x_15_3    stock_lb_248  3
    x_15_3    stock_ub_249  3
    x_15_3    parent_nonstrict_scope_250  0.081
    MARKER    'MARKER'                 'INTEND'
    w_15_3    product_lb_89  1
    w_15_3    product_ub_90  1
    w_15_3    normalized_mass_15_118  1
    w_15_3    normalized_ratio_15_119  -3.3333333333333331e-01
    w_15_3    full_original_Gini_308  -1.5677380952380949e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_4    OBJ       6.7500000000000060e-03
    x_15_4    product_lb_91  -2.4497414161813971e-02
    x_15_4    product_ub_92  -4.1648073776629491e-02
    x_15_4    onehot_15_117  1
    x_15_4    stock_lb_248  4
    x_15_4    stock_ub_249  4
    x_15_4    parent_nonstrict_scope_250  0.0675
    x_15_4    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_4    product_lb_91  1
    w_15_4    product_ub_92  1
    w_15_4    normalized_mass_15_118  1
    w_15_4    normalized_ratio_15_119  -4.4444444444444442e-01
    w_15_4    full_original_Gini_308  -1.2988492063492062e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_5    OBJ       -6.7500000000000060e-03
    x_15_5    product_lb_93  -2.4497414161813971e-02
    x_15_5    product_ub_94  -4.1648073776629491e-02
    x_15_5    onehot_15_117  1
    x_15_5    stock_lb_248  5
    x_15_5    stock_ub_249  5
    x_15_5    parent_nonstrict_scope_250  5.3999999999999992e-02
    x_15_5    unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_5    product_lb_93  1
    w_15_5    product_ub_94  1
    w_15_5    normalized_mass_15_118  1
    w_15_5    normalized_ratio_15_119  -5.5555555555555558e-01
    w_15_5    full_original_Gini_308  -1.0432936507936510e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_6    OBJ       -2.0249999999999997e-02
    x_15_6    product_lb_95  -2.4497414161813971e-02
    x_15_6    product_ub_96  -4.1648073776629491e-02
    x_15_6    onehot_15_117  1
    x_15_6    stock_lb_248  6
    x_15_6    stock_ub_249  6
    x_15_6    parent_nonstrict_scope_250  0.0405
    x_15_6    unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_6    product_lb_95  1
    w_15_6    product_ub_96  1
    w_15_6    normalized_mass_15_118  1
    w_15_6    normalized_ratio_15_119  -6.6666666666666663e-01
    w_15_6    full_original_Gini_308  -8.0678571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_7    OBJ       -3.3749999999999988e-02
    x_15_7    product_lb_97  -2.4497414161813971e-02
    x_15_7    product_ub_98  -4.1648073776629491e-02
    x_15_7    onehot_15_117  1
    x_15_7    stock_lb_248  7
    x_15_7    stock_ub_249  7
    x_15_7    parent_nonstrict_scope_250  2.7000000000000010e-02
    x_15_7    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_7    product_lb_97  1
    w_15_7    product_ub_98  1
    w_15_7    normalized_mass_15_118  1
    w_15_7    normalized_ratio_15_119  -7.7777777777777768e-01
    w_15_7    full_original_Gini_308  -5.9567460317460341e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_8    OBJ       -4.7249999999999993e-02
    x_15_8    product_lb_99  -2.4497414161813971e-02
    x_15_8    product_ub_100  -4.1648073776629491e-02
    x_15_8    onehot_15_117  1
    x_15_8    stock_lb_248  8
    x_15_8    stock_ub_249  8
    x_15_8    parent_nonstrict_scope_250  1.3500000000000005e-02
    x_15_8    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_8    product_lb_99  1
    w_15_8    product_ub_100  1
    w_15_8    normalized_mass_15_118  1
    w_15_8    normalized_ratio_15_119  -8.8888888888888884e-01
    w_15_8    full_original_Gini_308  -4.1670634920634928e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_9    OBJ       -0.06075
    x_15_9    product_lb_101  -2.4497414161813971e-02
    x_15_9    product_ub_102  -4.1648073776629491e-02
    x_15_9    onehot_15_117  1
    x_15_9    stock_lb_248  9
    x_15_9    stock_ub_249  9
    x_15_9    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_9    product_lb_101  1
    w_15_9    product_ub_102  1
    w_15_9    normalized_mass_15_118  1
    w_15_9    normalized_ratio_15_119  -1
    w_15_9    full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_10   OBJ       -4.7249999999999993e-02
    x_15_10   product_lb_103  -2.4497414161813971e-02
    x_15_10   product_ub_104  -4.1648073776629491e-02
    x_15_10   onehot_15_117  1
    x_15_10   stock_lb_248  10
    x_15_10   stock_ub_249  10
    x_15_10   parent_nonstrict_scope_250  1.3500000000000005e-02
    x_15_10   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_10   product_lb_103  1
    w_15_10   product_ub_104  1
    w_15_10   normalized_mass_15_118  1
    w_15_10   normalized_ratio_15_119  -1.1111111111111112e+00
    w_15_10   full_original_Gini_308  -6.1670634920634910e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_11   OBJ       -3.3750000000000016e-02
    x_15_11   product_lb_105  -2.4497414161813971e-02
    x_15_11   product_ub_106  -4.1648073776629491e-02
    x_15_11   onehot_15_117  1
    x_15_11   stock_lb_248  11
    x_15_11   stock_ub_249  11
    x_15_11   parent_nonstrict_scope_250  2.6999999999999986e-02
    x_15_11   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_11   product_lb_105  1
    w_15_11   product_ub_106  1
    w_15_11   normalized_mass_15_118  1
    w_15_11   normalized_ratio_15_119  -1.2222222222222221e+00
    w_15_11   full_original_Gini_308  -8.9892857142857121e+00
    MARKER    'MARKER'                 'INTORG'
    x_15_12   OBJ       -2.0250000000000011e-02
    x_15_12   product_lb_107  -2.4497414161813971e-02
    x_15_12   product_ub_108  -4.1648073776629491e-02
    x_15_12   onehot_15_117  1
    x_15_12   stock_lb_248  12
    x_15_12   stock_ub_249  12
    x_15_12   parent_nonstrict_scope_250  4.0499999999999987e-02
    x_15_12   unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_12   product_lb_107  1
    w_15_12   product_ub_108  1
    w_15_12   normalized_mass_15_118  1
    w_15_12   normalized_ratio_15_119  -1.3333333333333333e+00
    w_15_12   full_original_Gini_308  -1.1989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_13   OBJ       -6.7500000000000060e-03
    x_15_13   product_lb_109  -2.4497414161813971e-02
    x_15_13   product_ub_110  -4.1648073776629491e-02
    x_15_13   onehot_15_117  1
    x_15_13   stock_lb_248  13
    x_15_13   stock_ub_249  13
    x_15_13   parent_nonstrict_scope_250  5.3999999999999992e-02
    x_15_13   unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_13   product_lb_109  1
    w_15_13   product_ub_110  1
    w_15_13   normalized_mass_15_118  1
    w_15_13   normalized_ratio_15_119  -1.4444444444444444e+00
    w_15_13   full_original_Gini_308  -1.4989285714285717e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_14   OBJ       6.7499999999999782e-03
    x_15_14   product_lb_111  -2.4497414161813971e-02
    x_15_14   product_ub_112  -4.1648073776629491e-02
    x_15_14   onehot_15_117  1
    x_15_14   stock_lb_248  14
    x_15_14   stock_ub_249  14
    x_15_14   parent_nonstrict_scope_250  6.7499999999999977e-02
    x_15_14   unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_14   product_lb_111  1
    w_15_14   product_ub_112  1
    w_15_14   normalized_mass_15_118  1
    w_15_14   normalized_ratio_15_119  -1.5555555555555554e+00
    w_15_14   full_original_Gini_308  -1.7989285714285707e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_15   OBJ       2.0249999999999976e-02
    x_15_15   product_lb_113  -2.4497414161813971e-02
    x_15_15   product_ub_114  -4.1648073776629491e-02
    x_15_15   onehot_15_117  1
    x_15_15   stock_lb_248  15
    x_15_15   stock_ub_249  15
    x_15_15   parent_nonstrict_scope_250  8.0999999999999975e-02
    x_15_15   unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_15   product_lb_113  1
    w_15_15   product_ub_114  1
    w_15_15   normalized_mass_15_118  1
    w_15_15   normalized_ratio_15_119  -1.6666666666666665e+00
    w_15_15   full_original_Gini_308  -2.0989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_15_16   OBJ       3.3749999999999988e-02
    x_15_16   product_lb_115  -2.4497414161813971e-02
    x_15_16   product_ub_116  -4.1648073776629491e-02
    x_15_16   onehot_15_117  1
    x_15_16   stock_lb_248  16
    x_15_16   stock_ub_249  16
    x_15_16   parent_nonstrict_scope_250  9.4499999999999987e-02
    x_15_16   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_15_16   product_lb_115  1
    w_15_16   product_ub_116  1
    w_15_16   normalized_mass_15_118  1
    w_15_16   normalized_ratio_15_119  -1.7777777777777777e+00
    w_15_16   full_original_Gini_308  -2.3989285714285721e+01
    rho_15    normalized_ratio_15_119  1
    rho_15    block_pair_pos_255  1
    rho_15    block_pair_neg_256  -1
    rho_15    block_pair_pos_269  1
    rho_15    block_pair_neg_270  -1
    rho_15    block_pair_pos_281  -1
    rho_15    block_pair_neg_282  1
    rho_15    block_pair_pos_283  -1
    rho_15    block_pair_neg_284  1
    rho_15    block_pair_pos_285  -1
    rho_15    block_pair_neg_286  1
    rho_15    block_pair_pos_287  -1
    rho_15    block_pair_neg_288  1
    rho_15    block_pair_pos_295  1
    rho_15    block_pair_neg_296  -1
    rho_15    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_120  -2.4497414161813971e-02
    x_32_0    product_ub_121  -4.1648073776629491e-02
    x_32_0    onehot_32_146  1
    x_32_0    parent_nonstrict_scope_250  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_120  1
    w_32_0    product_ub_121  1
    w_32_0    normalized_mass_32_147  1
    w_32_0    full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_122  -2.4497414161813971e-02
    x_32_1    product_ub_123  -4.1648073776629491e-02
    x_32_1    onehot_32_146  1
    x_32_1    stock_lb_248  1
    x_32_1    stock_ub_249  1
    x_32_1    parent_nonstrict_scope_250  0.03
    x_32_1    unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_122  1
    w_32_1    product_ub_123  1
    w_32_1    normalized_mass_32_147  1
    w_32_1    normalized_ratio_32_148  -0.2
    w_32_1    full_original_Gini_308  -1.9010714285714290e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_124  -2.4497414161813971e-02
    x_32_2    product_ub_125  -4.1648073776629491e-02
    x_32_2    onehot_32_146  1
    x_32_2    stock_lb_248  2
    x_32_2    stock_ub_249  2
    x_32_2    parent_nonstrict_scope_250  0.0225
    x_32_2    unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_124  1
    w_32_2    product_ub_125  1
    w_32_2    normalized_mass_32_147  1
    w_32_2    normalized_ratio_32_148  -0.4
    w_32_2    full_original_Gini_308  -1.4010714285714283e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_126  -2.4497414161813971e-02
    x_32_3    product_ub_127  -4.1648073776629491e-02
    x_32_3    onehot_32_146  1
    x_32_3    stock_lb_248  3
    x_32_3    stock_ub_249  3
    x_32_3    parent_nonstrict_scope_250  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_126  1
    w_32_3    product_ub_127  1
    w_32_3    normalized_mass_32_147  1
    w_32_3    normalized_ratio_32_148  -6.0000000000000009e-01
    w_32_3    full_original_Gini_308  -9.4678571428571434e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_128  -2.4497414161813971e-02
    x_32_4    product_ub_129  -4.1648073776629491e-02
    x_32_4    onehot_32_146  1
    x_32_4    stock_lb_248  4
    x_32_4    stock_ub_249  4
    x_32_4    parent_nonstrict_scope_250  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_128  1
    w_32_4    product_ub_129  1
    w_32_4    normalized_mass_32_147  1
    w_32_4    normalized_ratio_32_148  -0.8
    w_32_4    full_original_Gini_308  -5.5345238095238107e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_130  -2.4497414161813971e-02
    x_32_5    product_ub_131  -4.1648073776629491e-02
    x_32_5    onehot_32_146  1
    x_32_5    stock_lb_248  5
    x_32_5    stock_ub_249  5
    x_32_5    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_130  1
    w_32_5    product_ub_131  1
    w_32_5    normalized_mass_32_147  1
    w_32_5    normalized_ratio_32_148  -1
    w_32_5    full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_132  -2.4497414161813971e-02
    x_32_6    product_ub_133  -4.1648073776629491e-02
    x_32_6    onehot_32_146  1
    x_32_6    stock_lb_248  6
    x_32_6    stock_ub_249  6
    x_32_6    parent_nonstrict_scope_250  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_132  1
    w_32_6    product_ub_133  1
    w_32_6    normalized_mass_32_147  1
    w_32_6    normalized_ratio_32_148  -1.2000000000000002e+00
    w_32_6    full_original_Gini_308  -8.38928571428572
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_134  -2.4497414161813971e-02
    x_32_7    product_ub_135  -4.1648073776629491e-02
    x_32_7    onehot_32_146  1
    x_32_7    stock_lb_248  7
    x_32_7    stock_ub_249  7
    x_32_7    parent_nonstrict_scope_250  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_134  1
    w_32_7    product_ub_135  1
    w_32_7    normalized_mass_32_147  1
    w_32_7    normalized_ratio_32_148  -1.4000000000000001e+00
    w_32_7    full_original_Gini_308  -1.3789285714285722e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_136  -2.4497414161813971e-02
    x_32_8    product_ub_137  -4.1648073776629491e-02
    x_32_8    onehot_32_146  1
    x_32_8    stock_lb_248  8
    x_32_8    stock_ub_249  8
    x_32_8    parent_nonstrict_scope_250  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_136  1
    w_32_8    product_ub_137  1
    w_32_8    normalized_mass_32_147  1
    w_32_8    normalized_ratio_32_148  -1.6
    w_32_8    full_original_Gini_308  -1.9189285714285717e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_138  -2.4497414161813971e-02
    x_32_9    product_ub_139  -4.1648073776629491e-02
    x_32_9    onehot_32_146  1
    x_32_9    stock_lb_248  9
    x_32_9    stock_ub_249  9
    x_32_9    parent_nonstrict_scope_250  0.03
    x_32_9    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_138  1
    w_32_9    product_ub_139  1
    w_32_9    normalized_mass_32_147  1
    w_32_9    normalized_ratio_32_148  -1.8
    w_32_9    full_original_Gini_308  -2.4589285714285719e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_140  -2.4497414161813971e-02
    x_32_10   product_ub_141  -4.1648073776629491e-02
    x_32_10   onehot_32_146  1
    x_32_10   stock_lb_248  10
    x_32_10   stock_ub_249  10
    x_32_10   parent_nonstrict_scope_250  0.0375
    x_32_10   unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_140  1
    w_32_10   product_ub_141  1
    w_32_10   normalized_mass_32_147  1
    w_32_10   normalized_ratio_32_148  -2
    w_32_10   full_original_Gini_308  -2.9989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_142  -2.4497414161813971e-02
    x_32_11   product_ub_143  -4.1648073776629491e-02
    x_32_11   onehot_32_146  1
    x_32_11   stock_lb_248  11
    x_32_11   stock_ub_249  11
    x_32_11   parent_nonstrict_scope_250  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_142  1
    w_32_11   product_ub_143  1
    w_32_11   normalized_mass_32_147  1
    w_32_11   normalized_ratio_32_148  -2.2
    w_32_11   full_original_Gini_308  -3.5389285714285705e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_144  -2.4497414161813971e-02
    x_32_12   product_ub_145  -4.1648073776629491e-02
    x_32_12   onehot_32_146  1
    x_32_12   stock_lb_248  12
    x_32_12   stock_ub_249  12
    x_32_12   parent_nonstrict_scope_250  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_144  1
    w_32_12   product_ub_145  1
    w_32_12   normalized_mass_32_147  1
    w_32_12   normalized_ratio_32_148  -2.4000000000000004e+00
    w_32_12   full_original_Gini_308  -4.0789285714285711e+01
    rho_32    normalized_ratio_32_148  1
    rho_32    block_pair_pos_261  1
    rho_32    block_pair_neg_262  -1
    rho_32    block_pair_pos_275  1
    rho_32    block_pair_neg_276  -1
    rho_32    block_pair_pos_287  1
    rho_32    block_pair_neg_288  -1
    rho_32    block_pair_pos_299  1
    rho_32    block_pair_neg_300  -1
    rho_32    block_pair_pos_301  -1
    rho_32    block_pair_neg_302  1
    rho_32    block_pair_pos_303  -1
    rho_32    block_pair_neg_304  1
    rho_32    block_pair_pos_305  -1
    rho_32    block_pair_neg_306  1
    rho_32    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_13_0    OBJ       0.03
    x_13_0    product_lb_149  -2.4497414161813971e-02
    x_13_0    product_ub_150  -4.1648073776629491e-02
    x_13_0    onehot_13_189  1
    x_13_0    parent_nonstrict_scope_250  0.096
    x_13_0    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_0    product_lb_149  1
    w_13_0    product_ub_150  1
    w_13_0    normalized_mass_13_190  1
    w_13_0    full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_1    OBJ       1.8000000000000002e-02
    x_13_1    product_lb_151  -2.4497414161813971e-02
    x_13_1    product_ub_152  -4.1648073776629491e-02
    x_13_1    onehot_13_189  1
    x_13_1    stock_lb_248  1
    x_13_1    stock_ub_249  1
    x_13_1    parent_nonstrict_scope_250  0.084
    x_13_1    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_1    product_lb_151  1
    w_13_1    product_ub_152  1
    w_13_1    normalized_mass_13_190  1
    w_13_1    normalized_ratio_13_191  -0.125
    w_13_1    full_original_Gini_308  -2.0885714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_2    OBJ       6.0000000000000053e-03
    x_13_2    product_lb_153  -2.4497414161813971e-02
    x_13_2    product_ub_154  -4.1648073776629491e-02
    x_13_2    onehot_13_189  1
    x_13_2    stock_lb_248  2
    x_13_2    stock_ub_249  2
    x_13_2    parent_nonstrict_scope_250  7.2000000000000008e-02
    x_13_2    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_2    product_lb_153  1
    w_13_2    product_ub_154  1
    w_13_2    normalized_mass_13_190  1
    w_13_2    normalized_ratio_13_191  -0.25
    w_13_2    full_original_Gini_308  -1.7760714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_3    OBJ       -6.0000000000000053e-03
    x_13_3    product_lb_155  -2.4497414161813971e-02
    x_13_3    product_ub_156  -4.1648073776629491e-02
    x_13_3    onehot_13_189  1
    x_13_3    stock_lb_248  3
    x_13_3    stock_ub_249  3
    x_13_3    parent_nonstrict_scope_250  0.06
    x_13_3    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_3    product_lb_155  1
    w_13_3    product_ub_156  1
    w_13_3    normalized_mass_13_190  1
    w_13_3    normalized_ratio_13_191  -0.375
    w_13_3    full_original_Gini_308  -1.4635714285714288e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_4    OBJ       -1.8000000000000002e-02
    x_13_4    product_lb_157  -2.4497414161813971e-02
    x_13_4    product_ub_158  -4.1648073776629491e-02
    x_13_4    onehot_13_189  1
    x_13_4    stock_lb_248  4
    x_13_4    stock_ub_249  4
    x_13_4    parent_nonstrict_scope_250  0.048
    x_13_4    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_4    product_lb_157  1
    w_13_4    product_ub_158  1
    w_13_4    normalized_mass_13_190  1
    w_13_4    normalized_ratio_13_191  -0.5
    w_13_4    full_original_Gini_308  -1.1710714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_5    OBJ       -0.03
    x_13_5    product_lb_159  -2.4497414161813971e-02
    x_13_5    product_ub_160  -4.1648073776629491e-02
    x_13_5    onehot_13_189  1
    x_13_5    stock_lb_248  5
    x_13_5    stock_ub_249  5
    x_13_5    parent_nonstrict_scope_250  3.6000000000000004e-02
    x_13_5    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_5    product_lb_159  1
    w_13_5    product_ub_160  1
    w_13_5    normalized_mass_13_190  1
    w_13_5    normalized_ratio_13_191  -0.625
    w_13_5    full_original_Gini_308  -8.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_6    OBJ       -0.042
    x_13_6    product_lb_161  -2.4497414161813971e-02
    x_13_6    product_ub_162  -4.1648073776629491e-02
    x_13_6    onehot_13_189  1
    x_13_6    stock_lb_248  6
    x_13_6    stock_ub_249  6
    x_13_6    parent_nonstrict_scope_250  0.024
    x_13_6    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_6    product_lb_161  1
    w_13_6    product_ub_162  1
    w_13_6    normalized_mass_13_190  1
    w_13_6    normalized_ratio_13_191  -0.75
    w_13_6    full_original_Gini_308  -6.4845238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_7    OBJ       -5.4000000000000006e-02
    x_13_7    product_lb_163  -2.4497414161813971e-02
    x_13_7    product_ub_164  -4.1648073776629491e-02
    x_13_7    onehot_13_189  1
    x_13_7    stock_lb_248  7
    x_13_7    stock_ub_249  7
    x_13_7    parent_nonstrict_scope_250  0.012
    x_13_7    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_7    product_lb_163  1
    w_13_7    product_ub_164  1
    w_13_7    normalized_mass_13_190  1
    w_13_7    normalized_ratio_13_191  -0.875
    w_13_7    full_original_Gini_308  -4.2642857142857142e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_8    OBJ       -0.066
    x_13_8    product_lb_165  -2.4497414161813971e-02
    x_13_8    product_ub_166  -4.1648073776629491e-02
    x_13_8    onehot_13_189  1
    x_13_8    stock_lb_248  8
    x_13_8    stock_ub_249  8
    x_13_8    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_8    product_lb_165  1
    w_13_8    product_ub_166  1
    w_13_8    normalized_mass_13_190  1
    w_13_8    normalized_ratio_13_191  -1
    w_13_8    full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_9    OBJ       -5.4000000000000006e-02
    x_13_9    product_lb_167  -2.4497414161813971e-02
    x_13_9    product_ub_168  -4.1648073776629491e-02
    x_13_9    onehot_13_189  1
    x_13_9    stock_lb_248  9
    x_13_9    stock_ub_249  9
    x_13_9    parent_nonstrict_scope_250  0.012
    x_13_9    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_9    product_lb_167  1
    w_13_9    product_ub_168  1
    w_13_9    normalized_mass_13_190  1
    w_13_9    normalized_ratio_13_191  -1.125
    w_13_9    full_original_Gini_308  -6.5142857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_10   OBJ       -0.042
    x_13_10   product_lb_169  -2.4497414161813971e-02
    x_13_10   product_ub_170  -4.1648073776629491e-02
    x_13_10   onehot_13_189  1
    x_13_10   stock_lb_248  10
    x_13_10   stock_ub_249  10
    x_13_10   parent_nonstrict_scope_250  0.024
    x_13_10   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_10   product_lb_169  1
    w_13_10   product_ub_170  1
    w_13_10   normalized_mass_13_190  1
    w_13_10   normalized_ratio_13_191  -1.25
    w_13_10   full_original_Gini_308  -9.7392857142857139e+00
    MARKER    'MARKER'                 'INTORG'
    x_13_11   OBJ       -0.03
    x_13_11   product_lb_171  -2.4497414161813971e-02
    x_13_11   product_ub_172  -4.1648073776629491e-02
    x_13_11   onehot_13_189  1
    x_13_11   stock_lb_248  11
    x_13_11   stock_ub_249  11
    x_13_11   parent_nonstrict_scope_250  3.6000000000000004e-02
    x_13_11   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_11   product_lb_171  1
    w_13_11   product_ub_172  1
    w_13_11   normalized_mass_13_190  1
    w_13_11   normalized_ratio_13_191  -1.375
    w_13_11   full_original_Gini_308  -1.3114285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_12   OBJ       -1.8000000000000002e-02
    x_13_12   product_lb_173  -2.4497414161813971e-02
    x_13_12   product_ub_174  -4.1648073776629491e-02
    x_13_12   onehot_13_189  1
    x_13_12   stock_lb_248  12
    x_13_12   stock_ub_249  12
    x_13_12   parent_nonstrict_scope_250  0.048
    x_13_12   unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_12   product_lb_173  1
    w_13_12   product_ub_174  1
    w_13_12   normalized_mass_13_190  1
    w_13_12   normalized_ratio_13_191  -1.5
    w_13_12   full_original_Gini_308  -1.6489285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_13   OBJ       -6.0000000000000053e-03
    x_13_13   product_lb_175  -2.4497414161813971e-02
    x_13_13   product_ub_176  -4.1648073776629491e-02
    x_13_13   onehot_13_189  1
    x_13_13   stock_lb_248  13
    x_13_13   stock_ub_249  13
    x_13_13   parent_nonstrict_scope_250  0.06
    MARKER    'MARKER'                 'INTEND'
    w_13_13   product_lb_175  1
    w_13_13   product_ub_176  1
    w_13_13   normalized_mass_13_190  1
    w_13_13   normalized_ratio_13_191  -1.625
    w_13_13   full_original_Gini_308  -1.9864285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_14   OBJ       6.0000000000000053e-03
    x_13_14   product_lb_177  -2.4497414161813971e-02
    x_13_14   product_ub_178  -4.1648073776629491e-02
    x_13_14   onehot_13_189  1
    x_13_14   stock_lb_248  14
    x_13_14   stock_ub_249  14
    x_13_14   parent_nonstrict_scope_250  7.2000000000000008e-02
    x_13_14   unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_14   product_lb_177  1
    w_13_14   product_ub_178  1
    w_13_14   normalized_mass_13_190  1
    w_13_14   normalized_ratio_13_191  -1.75
    w_13_14   full_original_Gini_308  -2.3239285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_15   OBJ       1.8000000000000002e-02
    x_13_15   product_lb_179  -2.4497414161813971e-02
    x_13_15   product_ub_180  -4.1648073776629491e-02
    x_13_15   onehot_13_189  1
    x_13_15   stock_lb_248  15
    x_13_15   stock_ub_249  15
    x_13_15   parent_nonstrict_scope_250  0.084
    x_13_15   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_15   product_lb_179  1
    w_13_15   product_ub_180  1
    w_13_15   normalized_mass_13_190  1
    w_13_15   normalized_ratio_13_191  -1.875
    w_13_15   full_original_Gini_308  -2.6614285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_16   OBJ       0.03
    x_13_16   product_lb_181  -2.4497414161813971e-02
    x_13_16   product_ub_182  -4.1648073776629491e-02
    x_13_16   onehot_13_189  1
    x_13_16   stock_lb_248  16
    x_13_16   stock_ub_249  16
    x_13_16   parent_nonstrict_scope_250  0.096
    x_13_16   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_16   product_lb_181  1
    w_13_16   product_ub_182  1
    w_13_16   normalized_mass_13_190  1
    w_13_16   normalized_ratio_13_191  -2
    w_13_16   full_original_Gini_308  -2.9989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_17   OBJ       4.1999999999999996e-02
    x_13_17   product_lb_183  -2.4497414161813971e-02
    x_13_17   product_ub_184  -4.1648073776629491e-02
    x_13_17   onehot_13_189  1
    x_13_17   stock_lb_248  17
    x_13_17   stock_ub_249  17
    x_13_17   parent_nonstrict_scope_250  0.108
    x_13_17   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_17   product_lb_183  1
    w_13_17   product_ub_184  1
    w_13_17   normalized_mass_13_190  1
    w_13_17   normalized_ratio_13_191  -2.125
    w_13_17   full_original_Gini_308  -3.3364285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_18   OBJ       5.3999999999999992e-02
    x_13_18   product_lb_185  -2.4497414161813971e-02
    x_13_18   product_ub_186  -4.1648073776629491e-02
    x_13_18   onehot_13_189  1
    x_13_18   stock_lb_248  18
    x_13_18   stock_ub_249  18
    x_13_18   parent_nonstrict_scope_250  0.12
    x_13_18   unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_18   product_lb_185  1
    w_13_18   product_ub_186  1
    w_13_18   normalized_mass_13_190  1
    w_13_18   normalized_ratio_13_191  -2.25
    w_13_18   full_original_Gini_308  -3.6739285714285721e+01
    MARKER    'MARKER'                 'INTORG'
    x_13_19   OBJ       0.066
    x_13_19   product_lb_187  -2.4497414161813971e-02
    x_13_19   product_ub_188  -4.1648073776629491e-02
    x_13_19   onehot_13_189  1
    x_13_19   stock_lb_248  19
    x_13_19   stock_ub_249  19
    x_13_19   parent_nonstrict_scope_250  0.132
    x_13_19   unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_13_19   product_lb_187  1
    w_13_19   product_ub_188  1
    w_13_19   normalized_mass_13_190  1
    w_13_19   normalized_ratio_13_191  -2.375
    w_13_19   full_original_Gini_308  -4.0114285714285721e+01
    rho_13    normalized_ratio_13_191  1
    rho_13    block_pair_pos_253  1
    rho_13    block_pair_neg_254  -1
    rho_13    block_pair_pos_267  1
    rho_13    block_pair_neg_268  -1
    rho_13    block_pair_pos_277  -1
    rho_13    block_pair_neg_278  1
    rho_13    block_pair_pos_279  -1
    rho_13    block_pair_neg_280  1
    rho_13    block_pair_pos_283  1
    rho_13    block_pair_neg_284  -1
    rho_13    block_pair_pos_293  1
    rho_13    block_pair_neg_294  -1
    rho_13    block_pair_pos_303  1
    rho_13    block_pair_neg_304  -1
    rho_13    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_192  -2.4497414161813971e-02
    x_19_0    product_ub_193  -4.1648073776629491e-02
    x_19_0    onehot_19_210  1
    x_19_0    parent_nonstrict_scope_250  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_192  1
    w_19_0    product_ub_193  1
    w_19_0    normalized_mass_19_211  1
    w_19_0    full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_194  -2.4497414161813971e-02
    x_19_1    product_ub_195  -4.1648073776629491e-02
    x_19_1    onehot_19_210  1
    x_19_1    stock_lb_248  1
    x_19_1    stock_ub_249  1
    x_19_1    parent_nonstrict_scope_250  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_194  1
    w_19_1    product_ub_195  1
    w_19_1    normalized_mass_19_211  1
    w_19_1    normalized_ratio_19_212  -0.25
    w_19_1    full_original_Gini_308  -1.7760714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_196  -2.4497414161813971e-02
    x_19_2    product_ub_197  -4.1648073776629491e-02
    x_19_2    onehot_19_210  1
    x_19_2    stock_lb_248  2
    x_19_2    stock_ub_249  2
    x_19_2    parent_nonstrict_scope_250  0.012
    x_19_2    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_196  1
    w_19_2    product_ub_197  1
    w_19_2    normalized_mass_19_211  1
    w_19_2    normalized_ratio_19_212  -0.5
    w_19_2    full_original_Gini_308  -1.1710714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_198  -2.4497414161813971e-02
    x_19_3    product_ub_199  -4.1648073776629491e-02
    x_19_3    onehot_19_210  1
    x_19_3    stock_lb_248  3
    x_19_3    stock_ub_249  3
    x_19_3    parent_nonstrict_scope_250  0.006
    x_19_3    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_198  1
    w_19_3    product_ub_199  1
    w_19_3    normalized_mass_19_211  1
    w_19_3    normalized_ratio_19_212  -0.75
    w_19_3    full_original_Gini_308  -6.4845238095238091e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_200  -2.4497414161813971e-02
    x_19_4    product_ub_201  -4.1648073776629491e-02
    x_19_4    onehot_19_210  1
    x_19_4    stock_lb_248  4
    x_19_4    stock_ub_249  4
    x_19_4    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_200  1
    w_19_4    product_ub_201  1
    w_19_4    normalized_mass_19_211  1
    w_19_4    normalized_ratio_19_212  -1
    w_19_4    full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_202  -2.4497414161813971e-02
    x_19_5    product_ub_203  -4.1648073776629491e-02
    x_19_5    onehot_19_210  1
    x_19_5    stock_lb_248  5
    x_19_5    stock_ub_249  5
    x_19_5    parent_nonstrict_scope_250  0.006
    x_19_5    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_202  1
    w_19_5    product_ub_203  1
    w_19_5    normalized_mass_19_211  1
    w_19_5    normalized_ratio_19_212  -1.25
    w_19_5    full_original_Gini_308  -9.7392857142857139e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_204  -2.4497414161813971e-02
    x_19_6    product_ub_205  -4.1648073776629491e-02
    x_19_6    onehot_19_210  1
    x_19_6    stock_lb_248  6
    x_19_6    stock_ub_249  6
    x_19_6    parent_nonstrict_scope_250  0.012
    x_19_6    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_204  1
    w_19_6    product_ub_205  1
    w_19_6    normalized_mass_19_211  1
    w_19_6    normalized_ratio_19_212  -1.5
    w_19_6    full_original_Gini_308  -1.6489285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_206  -2.4497414161813971e-02
    x_19_7    product_ub_207  -4.1648073776629491e-02
    x_19_7    onehot_19_210  1
    x_19_7    stock_lb_248  7
    x_19_7    stock_ub_249  7
    x_19_7    parent_nonstrict_scope_250  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_206  1
    w_19_7    product_ub_207  1
    w_19_7    normalized_mass_19_211  1
    w_19_7    normalized_ratio_19_212  -1.75
    w_19_7    full_original_Gini_308  -2.3239285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_208  -2.4497414161813971e-02
    x_19_8    product_ub_209  -4.1648073776629491e-02
    x_19_8    onehot_19_210  1
    x_19_8    stock_lb_248  8
    x_19_8    stock_ub_249  8
    x_19_8    parent_nonstrict_scope_250  0.024
    x_19_8    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_208  1
    w_19_8    product_ub_209  1
    w_19_8    normalized_mass_19_211  1
    w_19_8    normalized_ratio_19_212  -2
    w_19_8    full_original_Gini_308  -2.9989285714285714e+01
    rho_19    normalized_ratio_19_212  1
    rho_19    block_pair_pos_257  1
    rho_19    block_pair_neg_258  -1
    rho_19    block_pair_pos_271  1
    rho_19    block_pair_neg_272  -1
    rho_19    block_pair_pos_279  1
    rho_19    block_pair_neg_280  -1
    rho_19    block_pair_pos_285  1
    rho_19    block_pair_neg_286  -1
    rho_19    block_pair_pos_289  -1
    rho_19    block_pair_neg_290  1
    rho_19    block_pair_pos_297  1
    rho_19    block_pair_neg_298  -1
    rho_19    block_pair_pos_305  1
    rho_19    block_pair_neg_306  -1
    rho_19    normalization_307  1
    MARKER    'MARKER'                 'INTORG'
    x_12_0    OBJ       0.0315
    x_12_0    product_lb_213  -2.4497414161813971e-02
    x_12_0    product_ub_214  -4.1648073776629491e-02
    x_12_0    onehot_12_245  1
    x_12_0    parent_nonstrict_scope_250  0.0735
    MARKER    'MARKER'                 'INTEND'
    w_12_0    product_lb_213  1
    w_12_0    product_ub_214  1
    w_12_0    normalized_mass_12_246  1
    w_12_0    full_original_Gini_308  -2.4010714285714286e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_1    OBJ       2.1000000000000005e-02
    x_12_1    product_lb_215  -2.4497414161813971e-02
    x_12_1    product_ub_216  -4.1648073776629491e-02
    x_12_1    onehot_12_245  1
    x_12_1    stock_lb_248  1
    x_12_1    stock_ub_249  1
    x_12_1    parent_nonstrict_scope_250  0.063
    x_12_1    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_1    product_lb_215  1
    w_12_1    product_ub_216  1
    w_12_1    normalized_mass_12_246  1
    w_12_1    normalized_ratio_12_247  -1.4285714285714285e-01
    w_12_1    full_original_Gini_308  -2.0439285714285720e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_2    OBJ       1.0500000000000002e-02
    x_12_2    product_lb_217  -2.4497414161813971e-02
    x_12_2    product_ub_218  -4.1648073776629491e-02
    x_12_2    onehot_12_245  1
    x_12_2    stock_lb_248  2
    x_12_2    stock_ub_249  2
    x_12_2    parent_nonstrict_scope_250  0.0525
    x_12_2    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_2    product_lb_217  1
    w_12_2    product_ub_218  1
    w_12_2    normalized_mass_12_246  1
    w_12_2    normalized_ratio_12_247  -2.8571428571428570e-01
    w_12_2    full_original_Gini_308  -1.6867857142857140e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_3    product_lb_219  -2.4497414161813971e-02
    x_12_3    product_ub_220  -4.1648073776629491e-02
    x_12_3    onehot_12_245  1
    x_12_3    stock_lb_248  3
    x_12_3    stock_ub_249  3
    x_12_3    parent_nonstrict_scope_250  4.1999999999999996e-02
    x_12_3    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_3    product_lb_219  1
    w_12_3    product_ub_220  1
    w_12_3    normalized_mass_12_246  1
    w_12_3    normalized_ratio_12_247  -4.2857142857142855e-01
    w_12_3    full_original_Gini_308  -1.3353571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_4    OBJ       -1.0499999999999995e-02
    x_12_4    product_lb_221  -2.4497414161813971e-02
    x_12_4    product_ub_222  -4.1648073776629491e-02
    x_12_4    onehot_12_245  1
    x_12_4    stock_lb_248  4
    x_12_4    stock_ub_249  4
    x_12_4    parent_nonstrict_scope_250  0.0315
    x_12_4    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_4    product_lb_221  1
    w_12_4    product_ub_222  1
    w_12_4    normalized_mass_12_246  1
    w_12_4    normalized_ratio_12_247  -5.7142857142857140e-01
    w_12_4    full_original_Gini_308  -1.0067857142857147e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_5    OBJ       -2.0999999999999991e-02
    x_12_5    product_lb_223  -2.4497414161813971e-02
    x_12_5    product_ub_224  -4.1648073776629491e-02
    x_12_5    onehot_12_245  1
    x_12_5    stock_lb_248  5
    x_12_5    stock_ub_249  5
    x_12_5    parent_nonstrict_scope_250  2.1000000000000005e-02
    x_12_5    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_5    product_lb_223  1
    w_12_5    product_ub_224  1
    w_12_5    normalized_mass_12_246  1
    w_12_5    normalized_ratio_12_247  -7.1428571428571419e-01
    w_12_5    full_original_Gini_308  -7.1630952380952380e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_6    OBJ       -3.1499999999999993e-02
    x_12_6    product_lb_225  -2.4497414161813971e-02
    x_12_6    product_ub_226  -4.1648073776629491e-02
    x_12_6    onehot_12_245  1
    x_12_6    stock_lb_248  6
    x_12_6    stock_ub_249  6
    x_12_6    parent_nonstrict_scope_250  1.0500000000000002e-02
    x_12_6    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_6    product_lb_225  1
    w_12_6    product_ub_226  1
    w_12_6    normalized_mass_12_246  1
    w_12_6    normalized_ratio_12_247  -8.5714285714285710e-01
    w_12_6    full_original_Gini_308  -4.4964285714285719e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_7    OBJ       -4.1999999999999996e-02
    x_12_7    product_lb_227  -2.4497414161813971e-02
    x_12_7    product_ub_228  -4.1648073776629491e-02
    x_12_7    onehot_12_245  1
    x_12_7    stock_lb_248  7
    x_12_7    stock_ub_249  7
    x_12_7    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_7    product_lb_227  1
    w_12_7    product_ub_228  1
    w_12_7    normalized_mass_12_246  1
    w_12_7    normalized_ratio_12_247  -1
    w_12_7    full_original_Gini_308  -3.3892857142857147e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_8    OBJ       -0.0315
    x_12_8    product_lb_229  -2.4497414161813971e-02
    x_12_8    product_ub_230  -4.1648073776629491e-02
    x_12_8    onehot_12_245  1
    x_12_8    stock_lb_248  8
    x_12_8    stock_ub_249  8
    x_12_8    parent_nonstrict_scope_250  1.0499999999999995e-02
    x_12_8    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_8    product_lb_229  1
    w_12_8    product_ub_230  1
    w_12_8    normalized_mass_12_246  1
    w_12_8    normalized_ratio_12_247  -1.1428571428571428e+00
    w_12_8    full_original_Gini_308  -6.9607142857142819e+00
    MARKER    'MARKER'                 'INTORG'
    x_12_9    OBJ       -2.1000000000000005e-02
    x_12_9    product_lb_231  -2.4497414161813971e-02
    x_12_9    product_ub_232  -4.1648073776629491e-02
    x_12_9    onehot_12_245  1
    x_12_9    stock_lb_248  9
    x_12_9    stock_ub_249  9
    x_12_9    parent_nonstrict_scope_250  2.0999999999999991e-02
    x_12_9    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_9    product_lb_231  1
    w_12_9    product_ub_232  1
    w_12_9    normalized_mass_12_246  1
    w_12_9    normalized_ratio_12_247  -1.2857142857142856e+00
    w_12_9    full_original_Gini_308  -1.0703571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_10   OBJ       -1.0500000000000009e-02
    x_12_10   product_lb_233  -2.4497414161813971e-02
    x_12_10   product_ub_234  -4.1648073776629491e-02
    x_12_10   onehot_12_245  1
    x_12_10   stock_lb_248  10
    x_12_10   stock_ub_249  10
    x_12_10   parent_nonstrict_scope_250  3.1499999999999986e-02
    x_12_10   unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_10   product_lb_233  1
    w_12_10   product_ub_234  1
    w_12_10   normalized_mass_12_246  1
    w_12_10   normalized_ratio_12_247  -1.4285714285714284e+00
    w_12_10   full_original_Gini_308  -1.4560714285714285e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_11   product_lb_235  -2.4497414161813971e-02
    x_12_11   product_ub_236  -4.1648073776629491e-02
    x_12_11   onehot_12_245  1
    x_12_11   stock_lb_248  11
    x_12_11   stock_ub_249  11
    x_12_11   parent_nonstrict_scope_250  4.1999999999999996e-02
    x_12_11   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_11   product_lb_235  1
    w_12_11   product_ub_236  1
    w_12_11   normalized_mass_12_246  1
    w_12_11   normalized_ratio_12_247  -1.5714285714285714e+00
    w_12_11   full_original_Gini_308  -1.8417857142857141e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_12   OBJ       1.0499999999999995e-02
    x_12_12   product_lb_237  -2.4497414161813971e-02
    x_12_12   product_ub_238  -4.1648073776629491e-02
    x_12_12   onehot_12_245  1
    x_12_12   stock_lb_248  12
    x_12_12   stock_ub_249  12
    x_12_12   parent_nonstrict_scope_250  5.2499999999999991e-02
    x_12_12   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_12   product_lb_237  1
    w_12_12   product_ub_238  1
    w_12_12   normalized_mass_12_246  1
    w_12_12   normalized_ratio_12_247  -1.7142857142857142e+00
    w_12_12   full_original_Gini_308  -2.2275000000000002e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_13   OBJ       2.0999999999999991e-02
    x_12_13   product_lb_239  -2.4497414161813971e-02
    x_12_13   product_ub_240  -4.1648073776629491e-02
    x_12_13   onehot_12_245  1
    x_12_13   stock_lb_248  13
    x_12_13   stock_ub_249  13
    x_12_13   parent_nonstrict_scope_250  6.2999999999999987e-02
    x_12_13   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_13   product_lb_239  1
    w_12_13   product_ub_240  1
    w_12_13   normalized_mass_12_246  1
    w_12_13   normalized_ratio_12_247  -1.8571428571428570e+00
    w_12_13   full_original_Gini_308  -2.6132142857142856e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_14   OBJ       0.0315
    x_12_14   product_lb_241  -2.4497414161813971e-02
    x_12_14   product_ub_242  -4.1648073776629491e-02
    x_12_14   onehot_12_245  1
    x_12_14   stock_lb_248  14
    x_12_14   stock_ub_249  14
    x_12_14   parent_nonstrict_scope_250  0.0735
    x_12_14   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_14   product_lb_241  1
    w_12_14   product_ub_242  1
    w_12_14   normalized_mass_12_246  1
    w_12_14   normalized_ratio_12_247  -2
    w_12_14   full_original_Gini_308  -2.9989285714285714e+01
    MARKER    'MARKER'                 'INTORG'
    x_12_15   OBJ       4.1999999999999996e-02
    x_12_15   product_lb_243  -2.4497414161813971e-02
    x_12_15   product_ub_244  -4.1648073776629491e-02
    x_12_15   onehot_12_245  1
    x_12_15   stock_lb_248  15
    x_12_15   stock_ub_249  15
    x_12_15   parent_nonstrict_scope_250  8.3999999999999991e-02
    x_12_15   unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_12_15   product_lb_243  1
    w_12_15   product_ub_244  1
    w_12_15   normalized_mass_12_246  1
    w_12_15   normalized_ratio_12_247  -2.1428571428571428e+00
    w_12_15   full_original_Gini_308  -3.3846428571428561e+01
    rho_12    normalized_ratio_12_247  1
    rho_12    block_pair_pos_251  1
    rho_12    block_pair_neg_252  -1
    rho_12    block_pair_pos_265  1
    rho_12    block_pair_neg_266  -1
    rho_12    block_pair_pos_277  1
    rho_12    block_pair_neg_278  -1
    rho_12    block_pair_pos_281  1
    rho_12    block_pair_neg_282  -1
    rho_12    block_pair_pos_289  1
    rho_12    block_pair_neg_290  -1
    rho_12    block_pair_pos_291  1
    rho_12    block_pair_neg_292  -1
    rho_12    block_pair_pos_301  1
    rho_12    block_pair_neg_302  -1
    rho_12    normalization_307  1
    a_9_6     block_pair_pos_263  1
    a_9_6     block_pair_neg_264  1
    a_9_6     full_original_Gini_308  -1
    a_9_31    block_pair_pos_273  1
    a_9_31    block_pair_neg_274  1
    a_9_31    full_original_Gini_308  -1
    a_9_15    block_pair_pos_269  1
    a_9_15    block_pair_neg_270  1
    a_9_15    full_original_Gini_308  -1
    a_9_32    block_pair_pos_275  1
    a_9_32    block_pair_neg_276  1
    a_9_32    full_original_Gini_308  -1
    a_9_13    block_pair_pos_267  1
    a_9_13    block_pair_neg_268  1
    a_9_13    full_original_Gini_308  -1
    a_9_19    block_pair_pos_271  1
    a_9_19    block_pair_neg_272  1
    a_9_19    full_original_Gini_308  -1
    a_9_12    block_pair_pos_265  1
    a_9_12    block_pair_neg_266  1
    a_9_12    full_original_Gini_308  -1
    a_6_31    block_pair_pos_259  1
    a_6_31    block_pair_neg_260  1
    a_6_31    full_original_Gini_308  -1
    a_6_15    block_pair_pos_255  1
    a_6_15    block_pair_neg_256  1
    a_6_15    full_original_Gini_308  -1
    a_6_32    block_pair_pos_261  1
    a_6_32    block_pair_neg_262  1
    a_6_32    full_original_Gini_308  -1
    a_6_13    block_pair_pos_253  1
    a_6_13    block_pair_neg_254  1
    a_6_13    full_original_Gini_308  -1
    a_6_19    block_pair_pos_257  1
    a_6_19    block_pair_neg_258  1
    a_6_19    full_original_Gini_308  -1
    a_6_12    block_pair_pos_251  1
    a_6_12    block_pair_neg_252  1
    a_6_12    full_original_Gini_308  -1
    a_31_15   block_pair_pos_295  1
    a_31_15   block_pair_neg_296  1
    a_31_15   full_original_Gini_308  -1
    a_31_32   block_pair_pos_299  1
    a_31_32   block_pair_neg_300  1
    a_31_32   full_original_Gini_308  -1
    a_31_13   block_pair_pos_293  1
    a_31_13   block_pair_neg_294  1
    a_31_13   full_original_Gini_308  -1
    a_31_19   block_pair_pos_297  1
    a_31_19   block_pair_neg_298  1
    a_31_19   full_original_Gini_308  -1
    a_31_12   block_pair_pos_291  1
    a_31_12   block_pair_neg_292  1
    a_31_12   full_original_Gini_308  -1
    a_15_32   block_pair_pos_287  1
    a_15_32   block_pair_neg_288  1
    a_15_32   full_original_Gini_308  -1
    a_15_13   block_pair_pos_283  1
    a_15_13   block_pair_neg_284  1
    a_15_13   full_original_Gini_308  -1
    a_15_19   block_pair_pos_285  1
    a_15_19   block_pair_neg_286  1
    a_15_19   full_original_Gini_308  -1
    a_15_12   block_pair_pos_281  1
    a_15_12   block_pair_neg_282  1
    a_15_12   full_original_Gini_308  -1
    a_32_13   block_pair_pos_303  1
    a_32_13   block_pair_neg_304  1
    a_32_13   full_original_Gini_308  -1
    a_32_19   block_pair_pos_305  1
    a_32_19   block_pair_neg_306  1
    a_32_19   full_original_Gini_308  -1
    a_32_12   block_pair_pos_301  1
    a_32_12   block_pair_neg_302  1
    a_32_12   full_original_Gini_308  -1
    a_13_19   block_pair_pos_279  1
    a_13_19   block_pair_neg_280  1
    a_13_19   full_original_Gini_308  -1
    a_13_12   block_pair_pos_277  1
    a_13_12   block_pair_neg_278  1
    a_13_12   full_original_Gini_308  -1
    a_19_12   block_pair_pos_289  1
    a_19_12   block_pair_neg_290  1
    a_19_12   full_original_Gini_308  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_9_0  unique_nonzero_owner_309  1
    service_0_9_0  service_visit_def_793  1
    service_0_9_0  free_load_conservation_794  -8
    service_0_9_0  original_T_including_depot_unload_841  960
    service_0_9_1  unique_nonzero_owner_310  1
    service_0_9_1  service_visit_def_793  1
    service_0_9_1  free_load_conservation_794  -7
    service_0_9_1  original_T_including_depot_unload_841  840
    service_0_9_2  unique_nonzero_owner_311  1
    service_0_9_2  service_visit_def_793  1
    service_0_9_2  free_load_conservation_794  -6
    service_0_9_2  original_T_including_depot_unload_841  720
    service_0_9_3  unique_nonzero_owner_312  1
    service_0_9_3  service_visit_def_793  1
    service_0_9_3  free_load_conservation_794  -5
    service_0_9_3  original_T_including_depot_unload_841  600
    service_0_9_4  unique_nonzero_owner_313  1
    service_0_9_4  service_visit_def_793  1
    service_0_9_4  free_load_conservation_794  -4
    service_0_9_4  original_T_including_depot_unload_841  480
    service_0_9_5  unique_nonzero_owner_314  1
    service_0_9_5  service_visit_def_793  1
    service_0_9_5  free_load_conservation_794  -3
    service_0_9_5  original_T_including_depot_unload_841  360
    service_0_9_6  unique_nonzero_owner_315  1
    service_0_9_6  service_visit_def_793  1
    service_0_9_6  free_load_conservation_794  -2
    service_0_9_6  original_T_including_depot_unload_841  240
    service_0_9_7  unique_nonzero_owner_316  1
    service_0_9_7  service_visit_def_793  1
    service_0_9_7  free_load_conservation_794  -1
    service_0_9_7  original_T_including_depot_unload_841  120
    service_0_9_9  unique_nonzero_owner_317  1
    service_0_9_9  service_visit_def_793  1
    service_0_9_9  free_load_conservation_794  1
    service_0_9_10  unique_nonzero_owner_318  1
    service_0_9_10  service_visit_def_793  1
    service_0_9_10  free_load_conservation_794  2
    service_0_9_11  unique_nonzero_owner_319  1
    service_0_9_11  service_visit_def_793  1
    service_0_9_11  free_load_conservation_794  3
    service_0_9_12  unique_nonzero_owner_320  1
    service_0_9_12  service_visit_def_793  1
    service_0_9_12  free_load_conservation_794  4
    service_1_9_0  unique_nonzero_owner_309  1
    service_1_9_0  service_visit_def_1165  1
    service_1_9_0  free_load_conservation_1166  -8
    service_1_9_0  original_T_including_depot_unload_1212  960
    service_1_9_1  unique_nonzero_owner_310  1
    service_1_9_1  service_visit_def_1165  1
    service_1_9_1  free_load_conservation_1166  -7
    service_1_9_1  original_T_including_depot_unload_1212  840
    service_1_9_2  unique_nonzero_owner_311  1
    service_1_9_2  service_visit_def_1165  1
    service_1_9_2  free_load_conservation_1166  -6
    service_1_9_2  original_T_including_depot_unload_1212  720
    service_1_9_3  unique_nonzero_owner_312  1
    service_1_9_3  service_visit_def_1165  1
    service_1_9_3  free_load_conservation_1166  -5
    service_1_9_3  original_T_including_depot_unload_1212  600
    service_1_9_4  unique_nonzero_owner_313  1
    service_1_9_4  service_visit_def_1165  1
    service_1_9_4  free_load_conservation_1166  -4
    service_1_9_4  original_T_including_depot_unload_1212  480
    service_1_9_5  unique_nonzero_owner_314  1
    service_1_9_5  service_visit_def_1165  1
    service_1_9_5  free_load_conservation_1166  -3
    service_1_9_5  original_T_including_depot_unload_1212  360
    service_1_9_6  unique_nonzero_owner_315  1
    service_1_9_6  service_visit_def_1165  1
    service_1_9_6  free_load_conservation_1166  -2
    service_1_9_6  original_T_including_depot_unload_1212  240
    service_1_9_7  unique_nonzero_owner_316  1
    service_1_9_7  service_visit_def_1165  1
    service_1_9_7  free_load_conservation_1166  -1
    service_1_9_7  original_T_including_depot_unload_1212  120
    service_1_9_9  unique_nonzero_owner_317  1
    service_1_9_9  service_visit_def_1165  1
    service_1_9_9  free_load_conservation_1166  1
    service_1_9_10  unique_nonzero_owner_318  1
    service_1_9_10  service_visit_def_1165  1
    service_1_9_10  free_load_conservation_1166  2
    service_1_9_11  unique_nonzero_owner_319  1
    service_1_9_11  service_visit_def_1165  1
    service_1_9_11  free_load_conservation_1166  3
    service_1_9_12  unique_nonzero_owner_320  1
    service_1_9_12  service_visit_def_1165  1
    service_1_9_12  free_load_conservation_1166  4
    service_2_9_0  unique_nonzero_owner_309  1
    service_2_9_0  service_visit_def_1483  1
    service_2_9_0  free_load_conservation_1484  -8
    service_2_9_0  original_T_including_depot_unload_1529  960
    service_2_9_1  unique_nonzero_owner_310  1
    service_2_9_1  service_visit_def_1483  1
    service_2_9_1  free_load_conservation_1484  -7
    service_2_9_1  original_T_including_depot_unload_1529  840
    service_2_9_2  unique_nonzero_owner_311  1
    service_2_9_2  service_visit_def_1483  1
    service_2_9_2  free_load_conservation_1484  -6
    service_2_9_2  original_T_including_depot_unload_1529  720
    service_2_9_3  unique_nonzero_owner_312  1
    service_2_9_3  service_visit_def_1483  1
    service_2_9_3  free_load_conservation_1484  -5
    service_2_9_3  original_T_including_depot_unload_1529  600
    service_2_9_4  unique_nonzero_owner_313  1
    service_2_9_4  service_visit_def_1483  1
    service_2_9_4  free_load_conservation_1484  -4
    service_2_9_4  original_T_including_depot_unload_1529  480
    service_2_9_5  unique_nonzero_owner_314  1
    service_2_9_5  service_visit_def_1483  1
    service_2_9_5  free_load_conservation_1484  -3
    service_2_9_5  original_T_including_depot_unload_1529  360
    service_2_9_6  unique_nonzero_owner_315  1
    service_2_9_6  service_visit_def_1483  1
    service_2_9_6  free_load_conservation_1484  -2
    service_2_9_6  original_T_including_depot_unload_1529  240
    service_2_9_7  unique_nonzero_owner_316  1
    service_2_9_7  service_visit_def_1483  1
    service_2_9_7  free_load_conservation_1484  -1
    service_2_9_7  original_T_including_depot_unload_1529  120
    service_2_9_9  unique_nonzero_owner_317  1
    service_2_9_9  service_visit_def_1483  1
    service_2_9_9  free_load_conservation_1484  1
    service_2_9_10  unique_nonzero_owner_318  1
    service_2_9_10  service_visit_def_1483  1
    service_2_9_10  free_load_conservation_1484  2
    service_2_9_11  unique_nonzero_owner_319  1
    service_2_9_11  service_visit_def_1483  1
    service_2_9_11  free_load_conservation_1484  3
    service_2_9_12  unique_nonzero_owner_320  1
    service_2_9_12  service_visit_def_1483  1
    service_2_9_12  free_load_conservation_1484  4
    service_0_6_0  unique_nonzero_owner_321  1
    service_0_6_0  service_visit_def_799  1
    service_0_6_0  free_load_conservation_800  -1
    service_0_6_0  original_T_including_depot_unload_841  120
    service_0_6_2  unique_nonzero_owner_322  1
    service_0_6_2  service_visit_def_799  1
    service_0_6_2  free_load_conservation_800  1
    service_0_6_3  unique_nonzero_owner_323  1
    service_0_6_3  service_visit_def_799  1
    service_0_6_3  free_load_conservation_800  2
    service_0_6_4  unique_nonzero_owner_324  1
    service_0_6_4  service_visit_def_799  1
    service_0_6_4  free_load_conservation_800  3
    service_0_6_5  unique_nonzero_owner_325  1
    service_0_6_5  service_visit_def_799  1
    service_0_6_5  free_load_conservation_800  4
    service_0_6_6  unique_nonzero_owner_326  1
    service_0_6_6  service_visit_def_799  1
    service_0_6_6  free_load_conservation_800  5
    service_0_6_7  unique_nonzero_owner_327  1
    service_0_6_7  service_visit_def_799  1
    service_0_6_7  free_load_conservation_800  6
    service_0_6_8  unique_nonzero_owner_328  1
    service_0_6_8  service_visit_def_799  1
    service_0_6_8  free_load_conservation_800  7
    service_0_6_9  unique_nonzero_owner_329  1
    service_0_6_9  service_visit_def_799  1
    service_0_6_9  free_load_conservation_800  8
    service_0_6_10  unique_nonzero_owner_330  1
    service_0_6_10  service_visit_def_799  1
    service_0_6_10  free_load_conservation_800  9
    service_1_6_0  unique_nonzero_owner_321  1
    service_1_6_0  service_visit_def_1171  1
    service_1_6_0  free_load_conservation_1172  -1
    service_1_6_0  original_T_including_depot_unload_1212  120
    service_1_6_2  unique_nonzero_owner_322  1
    service_1_6_2  service_visit_def_1171  1
    service_1_6_2  free_load_conservation_1172  1
    service_1_6_3  unique_nonzero_owner_323  1
    service_1_6_3  service_visit_def_1171  1
    service_1_6_3  free_load_conservation_1172  2
    service_1_6_4  unique_nonzero_owner_324  1
    service_1_6_4  service_visit_def_1171  1
    service_1_6_4  free_load_conservation_1172  3
    service_1_6_5  unique_nonzero_owner_325  1
    service_1_6_5  service_visit_def_1171  1
    service_1_6_5  free_load_conservation_1172  4
    service_1_6_6  unique_nonzero_owner_326  1
    service_1_6_6  service_visit_def_1171  1
    service_1_6_6  free_load_conservation_1172  5
    service_1_6_7  unique_nonzero_owner_327  1
    service_1_6_7  service_visit_def_1171  1
    service_1_6_7  free_load_conservation_1172  6
    service_1_6_8  unique_nonzero_owner_328  1
    service_1_6_8  service_visit_def_1171  1
    service_1_6_8  free_load_conservation_1172  7
    service_1_6_9  unique_nonzero_owner_329  1
    service_1_6_9  service_visit_def_1171  1
    service_1_6_9  free_load_conservation_1172  8
    service_1_6_10  unique_nonzero_owner_330  1
    service_1_6_10  service_visit_def_1171  1
    service_1_6_10  free_load_conservation_1172  9
    service_2_6_0  unique_nonzero_owner_321  1
    service_2_6_0  service_visit_def_1489  1
    service_2_6_0  free_load_conservation_1490  -1
    service_2_6_0  original_T_including_depot_unload_1529  120
    service_2_6_2  unique_nonzero_owner_322  1
    service_2_6_2  service_visit_def_1489  1
    service_2_6_2  free_load_conservation_1490  1
    service_2_6_3  unique_nonzero_owner_323  1
    service_2_6_3  service_visit_def_1489  1
    service_2_6_3  free_load_conservation_1490  2
    service_2_6_4  unique_nonzero_owner_324  1
    service_2_6_4  service_visit_def_1489  1
    service_2_6_4  free_load_conservation_1490  3
    service_2_6_5  unique_nonzero_owner_325  1
    service_2_6_5  service_visit_def_1489  1
    service_2_6_5  free_load_conservation_1490  4
    service_2_6_6  unique_nonzero_owner_326  1
    service_2_6_6  service_visit_def_1489  1
    service_2_6_6  free_load_conservation_1490  5
    service_2_6_7  unique_nonzero_owner_327  1
    service_2_6_7  service_visit_def_1489  1
    service_2_6_7  free_load_conservation_1490  6
    service_2_6_8  unique_nonzero_owner_328  1
    service_2_6_8  service_visit_def_1489  1
    service_2_6_8  free_load_conservation_1490  7
    service_2_6_9  unique_nonzero_owner_329  1
    service_2_6_9  service_visit_def_1489  1
    service_2_6_9  free_load_conservation_1490  8
    service_2_6_10  unique_nonzero_owner_330  1
    service_2_6_10  service_visit_def_1489  1
    service_2_6_10  free_load_conservation_1490  9
    service_0_31_0  unique_nonzero_owner_331  1
    service_0_31_0  service_visit_def_805  1
    service_0_31_0  free_load_conservation_806  -2
    service_0_31_0  original_T_including_depot_unload_841  240
    service_0_31_1  unique_nonzero_owner_332  1
    service_0_31_1  service_visit_def_805  1
    service_0_31_1  free_load_conservation_806  -1
    service_0_31_1  original_T_including_depot_unload_841  120
    service_0_31_3  unique_nonzero_owner_333  1
    service_0_31_3  service_visit_def_805  1
    service_0_31_3  free_load_conservation_806  1
    service_0_31_4  unique_nonzero_owner_334  1
    service_0_31_4  service_visit_def_805  1
    service_0_31_4  free_load_conservation_806  2
    service_0_31_5  unique_nonzero_owner_335  1
    service_0_31_5  service_visit_def_805  1
    service_0_31_5  free_load_conservation_806  3
    service_0_31_6  unique_nonzero_owner_336  1
    service_0_31_6  service_visit_def_805  1
    service_0_31_6  free_load_conservation_806  4
    service_0_31_7  unique_nonzero_owner_337  1
    service_0_31_7  service_visit_def_805  1
    service_0_31_7  free_load_conservation_806  5
    service_0_31_8  unique_nonzero_owner_338  1
    service_0_31_8  service_visit_def_805  1
    service_0_31_8  free_load_conservation_806  6
    service_0_31_9  unique_nonzero_owner_339  1
    service_0_31_9  service_visit_def_805  1
    service_0_31_9  free_load_conservation_806  7
    service_0_31_10  unique_nonzero_owner_340  1
    service_0_31_10  service_visit_def_805  1
    service_0_31_10  free_load_conservation_806  8
    service_0_31_11  unique_nonzero_owner_341  1
    service_0_31_11  service_visit_def_805  1
    service_0_31_11  free_load_conservation_806  9
    service_0_31_12  unique_nonzero_owner_342  1
    service_0_31_12  service_visit_def_805  1
    service_0_31_12  free_load_conservation_806  10
    service_1_31_0  unique_nonzero_owner_331  1
    service_1_31_0  service_visit_def_1177  1
    service_1_31_0  free_load_conservation_1178  -2
    service_1_31_0  original_T_including_depot_unload_1212  240
    service_1_31_1  unique_nonzero_owner_332  1
    service_1_31_1  service_visit_def_1177  1
    service_1_31_1  free_load_conservation_1178  -1
    service_1_31_1  original_T_including_depot_unload_1212  120
    service_1_31_3  unique_nonzero_owner_333  1
    service_1_31_3  service_visit_def_1177  1
    service_1_31_3  free_load_conservation_1178  1
    service_1_31_4  unique_nonzero_owner_334  1
    service_1_31_4  service_visit_def_1177  1
    service_1_31_4  free_load_conservation_1178  2
    service_1_31_5  unique_nonzero_owner_335  1
    service_1_31_5  service_visit_def_1177  1
    service_1_31_5  free_load_conservation_1178  3
    service_1_31_6  unique_nonzero_owner_336  1
    service_1_31_6  service_visit_def_1177  1
    service_1_31_6  free_load_conservation_1178  4
    service_1_31_7  unique_nonzero_owner_337  1
    service_1_31_7  service_visit_def_1177  1
    service_1_31_7  free_load_conservation_1178  5
    service_1_31_8  unique_nonzero_owner_338  1
    service_1_31_8  service_visit_def_1177  1
    service_1_31_8  free_load_conservation_1178  6
    service_1_31_9  unique_nonzero_owner_339  1
    service_1_31_9  service_visit_def_1177  1
    service_1_31_9  free_load_conservation_1178  7
    service_1_31_10  unique_nonzero_owner_340  1
    service_1_31_10  service_visit_def_1177  1
    service_1_31_10  free_load_conservation_1178  8
    service_1_31_11  unique_nonzero_owner_341  1
    service_1_31_11  service_visit_def_1177  1
    service_1_31_11  free_load_conservation_1178  9
    service_1_31_12  unique_nonzero_owner_342  1
    service_1_31_12  service_visit_def_1177  1
    service_1_31_12  free_load_conservation_1178  10
    service_2_31_0  unique_nonzero_owner_331  1
    service_2_31_0  service_visit_def_1495  1
    service_2_31_0  free_load_conservation_1496  -2
    service_2_31_0  original_T_including_depot_unload_1529  240
    service_2_31_1  unique_nonzero_owner_332  1
    service_2_31_1  service_visit_def_1495  1
    service_2_31_1  free_load_conservation_1496  -1
    service_2_31_1  original_T_including_depot_unload_1529  120
    service_2_31_3  unique_nonzero_owner_333  1
    service_2_31_3  service_visit_def_1495  1
    service_2_31_3  free_load_conservation_1496  1
    service_2_31_4  unique_nonzero_owner_334  1
    service_2_31_4  service_visit_def_1495  1
    service_2_31_4  free_load_conservation_1496  2
    service_2_31_5  unique_nonzero_owner_335  1
    service_2_31_5  service_visit_def_1495  1
    service_2_31_5  free_load_conservation_1496  3
    service_2_31_6  unique_nonzero_owner_336  1
    service_2_31_6  service_visit_def_1495  1
    service_2_31_6  free_load_conservation_1496  4
    service_2_31_7  unique_nonzero_owner_337  1
    service_2_31_7  service_visit_def_1495  1
    service_2_31_7  free_load_conservation_1496  5
    service_2_31_8  unique_nonzero_owner_338  1
    service_2_31_8  service_visit_def_1495  1
    service_2_31_8  free_load_conservation_1496  6
    service_2_31_9  unique_nonzero_owner_339  1
    service_2_31_9  service_visit_def_1495  1
    service_2_31_9  free_load_conservation_1496  7
    service_2_31_10  unique_nonzero_owner_340  1
    service_2_31_10  service_visit_def_1495  1
    service_2_31_10  free_load_conservation_1496  8
    service_2_31_11  unique_nonzero_owner_341  1
    service_2_31_11  service_visit_def_1495  1
    service_2_31_11  free_load_conservation_1496  9
    service_2_31_12  unique_nonzero_owner_342  1
    service_2_31_12  service_visit_def_1495  1
    service_2_31_12  free_load_conservation_1496  10
    service_0_15_0  unique_nonzero_owner_343  1
    service_0_15_0  service_visit_def_811  1
    service_0_15_0  free_load_conservation_812  -3
    service_0_15_0  original_T_including_depot_unload_841  360
    service_0_15_1  unique_nonzero_owner_344  1
    service_0_15_1  service_visit_def_811  1
    service_0_15_1  free_load_conservation_812  -2
    service_0_15_1  original_T_including_depot_unload_841  240
    service_0_15_2  unique_nonzero_owner_345  1
    service_0_15_2  service_visit_def_811  1
    service_0_15_2  free_load_conservation_812  -1
    service_0_15_2  original_T_including_depot_unload_841  120
    service_0_15_4  unique_nonzero_owner_346  1
    service_0_15_4  service_visit_def_811  1
    service_0_15_4  free_load_conservation_812  1
    service_0_15_5  unique_nonzero_owner_347  1
    service_0_15_5  service_visit_def_811  1
    service_0_15_5  free_load_conservation_812  2
    service_0_15_6  unique_nonzero_owner_348  1
    service_0_15_6  service_visit_def_811  1
    service_0_15_6  free_load_conservation_812  3
    service_0_15_7  unique_nonzero_owner_349  1
    service_0_15_7  service_visit_def_811  1
    service_0_15_7  free_load_conservation_812  4
    service_0_15_8  unique_nonzero_owner_350  1
    service_0_15_8  service_visit_def_811  1
    service_0_15_8  free_load_conservation_812  5
    service_0_15_9  unique_nonzero_owner_351  1
    service_0_15_9  service_visit_def_811  1
    service_0_15_9  free_load_conservation_812  6
    service_0_15_10  unique_nonzero_owner_352  1
    service_0_15_10  service_visit_def_811  1
    service_0_15_10  free_load_conservation_812  7
    service_0_15_11  unique_nonzero_owner_353  1
    service_0_15_11  service_visit_def_811  1
    service_0_15_11  free_load_conservation_812  8
    service_0_15_12  unique_nonzero_owner_354  1
    service_0_15_12  service_visit_def_811  1
    service_0_15_12  free_load_conservation_812  9
    service_0_15_13  unique_nonzero_owner_355  1
    service_0_15_13  service_visit_def_811  1
    service_0_15_13  free_load_conservation_812  10
    service_0_15_14  unique_nonzero_owner_356  1
    service_0_15_14  service_visit_def_811  1
    service_0_15_14  free_load_conservation_812  11
    service_0_15_15  unique_nonzero_owner_357  1
    service_0_15_15  service_visit_def_811  1
    service_0_15_15  free_load_conservation_812  12
    service_0_15_16  unique_nonzero_owner_358  1
    service_0_15_16  service_visit_def_811  1
    service_0_15_16  free_load_conservation_812  13
    service_1_15_0  unique_nonzero_owner_343  1
    service_1_15_0  service_visit_def_1183  1
    service_1_15_0  free_load_conservation_1184  -3
    service_1_15_0  original_T_including_depot_unload_1212  360
    service_1_15_1  unique_nonzero_owner_344  1
    service_1_15_1  service_visit_def_1183  1
    service_1_15_1  free_load_conservation_1184  -2
    service_1_15_1  original_T_including_depot_unload_1212  240
    service_1_15_2  unique_nonzero_owner_345  1
    service_1_15_2  service_visit_def_1183  1
    service_1_15_2  free_load_conservation_1184  -1
    service_1_15_2  original_T_including_depot_unload_1212  120
    service_1_15_4  unique_nonzero_owner_346  1
    service_1_15_4  service_visit_def_1183  1
    service_1_15_4  free_load_conservation_1184  1
    service_1_15_5  unique_nonzero_owner_347  1
    service_1_15_5  service_visit_def_1183  1
    service_1_15_5  free_load_conservation_1184  2
    service_1_15_6  unique_nonzero_owner_348  1
    service_1_15_6  service_visit_def_1183  1
    service_1_15_6  free_load_conservation_1184  3
    service_1_15_7  unique_nonzero_owner_349  1
    service_1_15_7  service_visit_def_1183  1
    service_1_15_7  free_load_conservation_1184  4
    service_1_15_8  unique_nonzero_owner_350  1
    service_1_15_8  service_visit_def_1183  1
    service_1_15_8  free_load_conservation_1184  5
    service_1_15_9  unique_nonzero_owner_351  1
    service_1_15_9  service_visit_def_1183  1
    service_1_15_9  free_load_conservation_1184  6
    service_1_15_10  unique_nonzero_owner_352  1
    service_1_15_10  service_visit_def_1183  1
    service_1_15_10  free_load_conservation_1184  7
    service_1_15_11  unique_nonzero_owner_353  1
    service_1_15_11  service_visit_def_1183  1
    service_1_15_11  free_load_conservation_1184  8
    service_1_15_12  unique_nonzero_owner_354  1
    service_1_15_12  service_visit_def_1183  1
    service_1_15_12  free_load_conservation_1184  9
    service_1_15_13  unique_nonzero_owner_355  1
    service_1_15_13  service_visit_def_1183  1
    service_1_15_13  free_load_conservation_1184  10
    service_1_15_14  unique_nonzero_owner_356  1
    service_1_15_14  service_visit_def_1183  1
    service_1_15_14  free_load_conservation_1184  11
    service_1_15_15  unique_nonzero_owner_357  1
    service_1_15_15  service_visit_def_1183  1
    service_1_15_15  free_load_conservation_1184  12
    service_1_15_16  unique_nonzero_owner_358  1
    service_1_15_16  service_visit_def_1183  1
    service_1_15_16  free_load_conservation_1184  13
    service_2_15_0  unique_nonzero_owner_343  1
    service_2_15_0  service_visit_def_1501  1
    service_2_15_0  free_load_conservation_1502  -3
    service_2_15_0  original_T_including_depot_unload_1529  360
    service_2_15_1  unique_nonzero_owner_344  1
    service_2_15_1  service_visit_def_1501  1
    service_2_15_1  free_load_conservation_1502  -2
    service_2_15_1  original_T_including_depot_unload_1529  240
    service_2_15_2  unique_nonzero_owner_345  1
    service_2_15_2  service_visit_def_1501  1
    service_2_15_2  free_load_conservation_1502  -1
    service_2_15_2  original_T_including_depot_unload_1529  120
    service_2_15_4  unique_nonzero_owner_346  1
    service_2_15_4  service_visit_def_1501  1
    service_2_15_4  free_load_conservation_1502  1
    service_2_15_5  unique_nonzero_owner_347  1
    service_2_15_5  service_visit_def_1501  1
    service_2_15_5  free_load_conservation_1502  2
    service_2_15_6  unique_nonzero_owner_348  1
    service_2_15_6  service_visit_def_1501  1
    service_2_15_6  free_load_conservation_1502  3
    service_2_15_7  unique_nonzero_owner_349  1
    service_2_15_7  service_visit_def_1501  1
    service_2_15_7  free_load_conservation_1502  4
    service_2_15_8  unique_nonzero_owner_350  1
    service_2_15_8  service_visit_def_1501  1
    service_2_15_8  free_load_conservation_1502  5
    service_2_15_9  unique_nonzero_owner_351  1
    service_2_15_9  service_visit_def_1501  1
    service_2_15_9  free_load_conservation_1502  6
    service_2_15_10  unique_nonzero_owner_352  1
    service_2_15_10  service_visit_def_1501  1
    service_2_15_10  free_load_conservation_1502  7
    service_2_15_11  unique_nonzero_owner_353  1
    service_2_15_11  service_visit_def_1501  1
    service_2_15_11  free_load_conservation_1502  8
    service_2_15_12  unique_nonzero_owner_354  1
    service_2_15_12  service_visit_def_1501  1
    service_2_15_12  free_load_conservation_1502  9
    service_2_15_13  unique_nonzero_owner_355  1
    service_2_15_13  service_visit_def_1501  1
    service_2_15_13  free_load_conservation_1502  10
    service_2_15_14  unique_nonzero_owner_356  1
    service_2_15_14  service_visit_def_1501  1
    service_2_15_14  free_load_conservation_1502  11
    service_2_15_15  unique_nonzero_owner_357  1
    service_2_15_15  service_visit_def_1501  1
    service_2_15_15  free_load_conservation_1502  12
    service_2_15_16  unique_nonzero_owner_358  1
    service_2_15_16  service_visit_def_1501  1
    service_2_15_16  free_load_conservation_1502  13
    service_0_32_1  unique_nonzero_owner_359  1
    service_0_32_1  service_visit_def_817  1
    service_0_32_1  free_load_conservation_818  1
    service_0_32_2  unique_nonzero_owner_360  1
    service_0_32_2  service_visit_def_817  1
    service_0_32_2  free_load_conservation_818  2
    service_0_32_3  unique_nonzero_owner_361  1
    service_0_32_3  service_visit_def_817  1
    service_0_32_3  free_load_conservation_818  3
    service_0_32_4  unique_nonzero_owner_362  1
    service_0_32_4  service_visit_def_817  1
    service_0_32_4  free_load_conservation_818  4
    service_0_32_5  unique_nonzero_owner_363  1
    service_0_32_5  service_visit_def_817  1
    service_0_32_5  free_load_conservation_818  5
    service_0_32_6  unique_nonzero_owner_364  1
    service_0_32_6  service_visit_def_817  1
    service_0_32_6  free_load_conservation_818  6
    service_0_32_7  unique_nonzero_owner_365  1
    service_0_32_7  service_visit_def_817  1
    service_0_32_7  free_load_conservation_818  7
    service_0_32_8  unique_nonzero_owner_366  1
    service_0_32_8  service_visit_def_817  1
    service_0_32_8  free_load_conservation_818  8
    service_0_32_9  unique_nonzero_owner_367  1
    service_0_32_9  service_visit_def_817  1
    service_0_32_9  free_load_conservation_818  9
    service_0_32_10  unique_nonzero_owner_368  1
    service_0_32_10  service_visit_def_817  1
    service_0_32_10  free_load_conservation_818  10
    service_0_32_11  unique_nonzero_owner_369  1
    service_0_32_11  service_visit_def_817  1
    service_0_32_11  free_load_conservation_818  11
    service_0_32_12  unique_nonzero_owner_370  1
    service_0_32_12  service_visit_def_817  1
    service_0_32_12  free_load_conservation_818  12
    service_1_32_1  unique_nonzero_owner_359  1
    service_1_32_1  service_visit_def_1189  1
    service_1_32_1  free_load_conservation_1190  1
    service_1_32_2  unique_nonzero_owner_360  1
    service_1_32_2  service_visit_def_1189  1
    service_1_32_2  free_load_conservation_1190  2
    service_1_32_3  unique_nonzero_owner_361  1
    service_1_32_3  service_visit_def_1189  1
    service_1_32_3  free_load_conservation_1190  3
    service_1_32_4  unique_nonzero_owner_362  1
    service_1_32_4  service_visit_def_1189  1
    service_1_32_4  free_load_conservation_1190  4
    service_1_32_5  unique_nonzero_owner_363  1
    service_1_32_5  service_visit_def_1189  1
    service_1_32_5  free_load_conservation_1190  5
    service_1_32_6  unique_nonzero_owner_364  1
    service_1_32_6  service_visit_def_1189  1
    service_1_32_6  free_load_conservation_1190  6
    service_1_32_7  unique_nonzero_owner_365  1
    service_1_32_7  service_visit_def_1189  1
    service_1_32_7  free_load_conservation_1190  7
    service_1_32_8  unique_nonzero_owner_366  1
    service_1_32_8  service_visit_def_1189  1
    service_1_32_8  free_load_conservation_1190  8
    service_1_32_9  unique_nonzero_owner_367  1
    service_1_32_9  service_visit_def_1189  1
    service_1_32_9  free_load_conservation_1190  9
    service_1_32_10  unique_nonzero_owner_368  1
    service_1_32_10  service_visit_def_1189  1
    service_1_32_10  free_load_conservation_1190  10
    service_1_32_11  unique_nonzero_owner_369  1
    service_1_32_11  service_visit_def_1189  1
    service_1_32_11  free_load_conservation_1190  11
    service_1_32_12  unique_nonzero_owner_370  1
    service_1_32_12  service_visit_def_1189  1
    service_1_32_12  free_load_conservation_1190  12
    service_2_32_1  unique_nonzero_owner_359  1
    service_2_32_1  service_visit_def_1507  1
    service_2_32_1  free_load_conservation_1508  1
    service_2_32_2  unique_nonzero_owner_360  1
    service_2_32_2  service_visit_def_1507  1
    service_2_32_2  free_load_conservation_1508  2
    service_2_32_3  unique_nonzero_owner_361  1
    service_2_32_3  service_visit_def_1507  1
    service_2_32_3  free_load_conservation_1508  3
    service_2_32_4  unique_nonzero_owner_362  1
    service_2_32_4  service_visit_def_1507  1
    service_2_32_4  free_load_conservation_1508  4
    service_2_32_5  unique_nonzero_owner_363  1
    service_2_32_5  service_visit_def_1507  1
    service_2_32_5  free_load_conservation_1508  5
    service_2_32_6  unique_nonzero_owner_364  1
    service_2_32_6  service_visit_def_1507  1
    service_2_32_6  free_load_conservation_1508  6
    service_2_32_7  unique_nonzero_owner_365  1
    service_2_32_7  service_visit_def_1507  1
    service_2_32_7  free_load_conservation_1508  7
    service_2_32_8  unique_nonzero_owner_366  1
    service_2_32_8  service_visit_def_1507  1
    service_2_32_8  free_load_conservation_1508  8
    service_2_32_9  unique_nonzero_owner_367  1
    service_2_32_9  service_visit_def_1507  1
    service_2_32_9  free_load_conservation_1508  9
    service_2_32_10  unique_nonzero_owner_368  1
    service_2_32_10  service_visit_def_1507  1
    service_2_32_10  free_load_conservation_1508  10
    service_2_32_11  unique_nonzero_owner_369  1
    service_2_32_11  service_visit_def_1507  1
    service_2_32_11  free_load_conservation_1508  11
    service_2_32_12  unique_nonzero_owner_370  1
    service_2_32_12  service_visit_def_1507  1
    service_2_32_12  free_load_conservation_1508  12
    service_0_13_0  unique_nonzero_owner_371  1
    service_0_13_0  service_visit_def_823  1
    service_0_13_0  free_load_conservation_824  -13
    service_0_13_0  original_T_including_depot_unload_841  1560
    service_0_13_1  unique_nonzero_owner_372  1
    service_0_13_1  service_visit_def_823  1
    service_0_13_1  free_load_conservation_824  -12
    service_0_13_1  original_T_including_depot_unload_841  1440
    service_0_13_2  unique_nonzero_owner_373  1
    service_0_13_2  service_visit_def_823  1
    service_0_13_2  free_load_conservation_824  -11
    service_0_13_2  original_T_including_depot_unload_841  1320
    service_0_13_3  unique_nonzero_owner_374  1
    service_0_13_3  service_visit_def_823  1
    service_0_13_3  free_load_conservation_824  -10
    service_0_13_3  original_T_including_depot_unload_841  1200
    service_0_13_4  unique_nonzero_owner_375  1
    service_0_13_4  service_visit_def_823  1
    service_0_13_4  free_load_conservation_824  -9
    service_0_13_4  original_T_including_depot_unload_841  1080
    service_0_13_5  unique_nonzero_owner_376  1
    service_0_13_5  service_visit_def_823  1
    service_0_13_5  free_load_conservation_824  -8
    service_0_13_5  original_T_including_depot_unload_841  960
    service_0_13_6  unique_nonzero_owner_377  1
    service_0_13_6  service_visit_def_823  1
    service_0_13_6  free_load_conservation_824  -7
    service_0_13_6  original_T_including_depot_unload_841  840
    service_0_13_7  unique_nonzero_owner_378  1
    service_0_13_7  service_visit_def_823  1
    service_0_13_7  free_load_conservation_824  -6
    service_0_13_7  original_T_including_depot_unload_841  720
    service_0_13_8  unique_nonzero_owner_379  1
    service_0_13_8  service_visit_def_823  1
    service_0_13_8  free_load_conservation_824  -5
    service_0_13_8  original_T_including_depot_unload_841  600
    service_0_13_9  unique_nonzero_owner_380  1
    service_0_13_9  service_visit_def_823  1
    service_0_13_9  free_load_conservation_824  -4
    service_0_13_9  original_T_including_depot_unload_841  480
    service_0_13_10  unique_nonzero_owner_381  1
    service_0_13_10  service_visit_def_823  1
    service_0_13_10  free_load_conservation_824  -3
    service_0_13_10  original_T_including_depot_unload_841  360
    service_0_13_11  unique_nonzero_owner_382  1
    service_0_13_11  service_visit_def_823  1
    service_0_13_11  free_load_conservation_824  -2
    service_0_13_11  original_T_including_depot_unload_841  240
    service_0_13_12  unique_nonzero_owner_383  1
    service_0_13_12  service_visit_def_823  1
    service_0_13_12  free_load_conservation_824  -1
    service_0_13_12  original_T_including_depot_unload_841  120
    service_0_13_14  unique_nonzero_owner_384  1
    service_0_13_14  service_visit_def_823  1
    service_0_13_14  free_load_conservation_824  1
    service_0_13_15  unique_nonzero_owner_385  1
    service_0_13_15  service_visit_def_823  1
    service_0_13_15  free_load_conservation_824  2
    service_0_13_16  unique_nonzero_owner_386  1
    service_0_13_16  service_visit_def_823  1
    service_0_13_16  free_load_conservation_824  3
    service_0_13_17  unique_nonzero_owner_387  1
    service_0_13_17  service_visit_def_823  1
    service_0_13_17  free_load_conservation_824  4
    service_0_13_18  unique_nonzero_owner_388  1
    service_0_13_18  service_visit_def_823  1
    service_0_13_18  free_load_conservation_824  5
    service_0_13_19  unique_nonzero_owner_389  1
    service_0_13_19  service_visit_def_823  1
    service_0_13_19  free_load_conservation_824  6
    service_1_13_0  unique_nonzero_owner_371  1
    service_1_13_0  service_visit_def_1195  1
    service_1_13_0  free_load_conservation_1196  -13
    service_1_13_0  original_T_including_depot_unload_1212  1560
    service_1_13_1  unique_nonzero_owner_372  1
    service_1_13_1  service_visit_def_1195  1
    service_1_13_1  free_load_conservation_1196  -12
    service_1_13_1  original_T_including_depot_unload_1212  1440
    service_1_13_2  unique_nonzero_owner_373  1
    service_1_13_2  service_visit_def_1195  1
    service_1_13_2  free_load_conservation_1196  -11
    service_1_13_2  original_T_including_depot_unload_1212  1320
    service_1_13_3  unique_nonzero_owner_374  1
    service_1_13_3  service_visit_def_1195  1
    service_1_13_3  free_load_conservation_1196  -10
    service_1_13_3  original_T_including_depot_unload_1212  1200
    service_1_13_4  unique_nonzero_owner_375  1
    service_1_13_4  service_visit_def_1195  1
    service_1_13_4  free_load_conservation_1196  -9
    service_1_13_4  original_T_including_depot_unload_1212  1080
    service_1_13_5  unique_nonzero_owner_376  1
    service_1_13_5  service_visit_def_1195  1
    service_1_13_5  free_load_conservation_1196  -8
    service_1_13_5  original_T_including_depot_unload_1212  960
    service_1_13_6  unique_nonzero_owner_377  1
    service_1_13_6  service_visit_def_1195  1
    service_1_13_6  free_load_conservation_1196  -7
    service_1_13_6  original_T_including_depot_unload_1212  840
    service_1_13_7  unique_nonzero_owner_378  1
    service_1_13_7  service_visit_def_1195  1
    service_1_13_7  free_load_conservation_1196  -6
    service_1_13_7  original_T_including_depot_unload_1212  720
    service_1_13_8  unique_nonzero_owner_379  1
    service_1_13_8  service_visit_def_1195  1
    service_1_13_8  free_load_conservation_1196  -5
    service_1_13_8  original_T_including_depot_unload_1212  600
    service_1_13_9  unique_nonzero_owner_380  1
    service_1_13_9  service_visit_def_1195  1
    service_1_13_9  free_load_conservation_1196  -4
    service_1_13_9  original_T_including_depot_unload_1212  480
    service_1_13_10  unique_nonzero_owner_381  1
    service_1_13_10  service_visit_def_1195  1
    service_1_13_10  free_load_conservation_1196  -3
    service_1_13_10  original_T_including_depot_unload_1212  360
    service_1_13_11  unique_nonzero_owner_382  1
    service_1_13_11  service_visit_def_1195  1
    service_1_13_11  free_load_conservation_1196  -2
    service_1_13_11  original_T_including_depot_unload_1212  240
    service_1_13_12  unique_nonzero_owner_383  1
    service_1_13_12  service_visit_def_1195  1
    service_1_13_12  free_load_conservation_1196  -1
    service_1_13_12  original_T_including_depot_unload_1212  120
    service_1_13_14  unique_nonzero_owner_384  1
    service_1_13_14  service_visit_def_1195  1
    service_1_13_14  free_load_conservation_1196  1
    service_1_13_15  unique_nonzero_owner_385  1
    service_1_13_15  service_visit_def_1195  1
    service_1_13_15  free_load_conservation_1196  2
    service_1_13_16  unique_nonzero_owner_386  1
    service_1_13_16  service_visit_def_1195  1
    service_1_13_16  free_load_conservation_1196  3
    service_1_13_17  unique_nonzero_owner_387  1
    service_1_13_17  service_visit_def_1195  1
    service_1_13_17  free_load_conservation_1196  4
    service_1_13_18  unique_nonzero_owner_388  1
    service_1_13_18  service_visit_def_1195  1
    service_1_13_18  free_load_conservation_1196  5
    service_1_13_19  unique_nonzero_owner_389  1
    service_1_13_19  service_visit_def_1195  1
    service_1_13_19  free_load_conservation_1196  6
    service_2_13_0  unique_nonzero_owner_371  1
    service_2_13_0  service_visit_def_1513  1
    service_2_13_0  free_load_conservation_1514  -13
    service_2_13_0  original_T_including_depot_unload_1529  1560
    service_2_13_1  unique_nonzero_owner_372  1
    service_2_13_1  service_visit_def_1513  1
    service_2_13_1  free_load_conservation_1514  -12
    service_2_13_1  original_T_including_depot_unload_1529  1440
    service_2_13_2  unique_nonzero_owner_373  1
    service_2_13_2  service_visit_def_1513  1
    service_2_13_2  free_load_conservation_1514  -11
    service_2_13_2  original_T_including_depot_unload_1529  1320
    service_2_13_3  unique_nonzero_owner_374  1
    service_2_13_3  service_visit_def_1513  1
    service_2_13_3  free_load_conservation_1514  -10
    service_2_13_3  original_T_including_depot_unload_1529  1200
    service_2_13_4  unique_nonzero_owner_375  1
    service_2_13_4  service_visit_def_1513  1
    service_2_13_4  free_load_conservation_1514  -9
    service_2_13_4  original_T_including_depot_unload_1529  1080
    service_2_13_5  unique_nonzero_owner_376  1
    service_2_13_5  service_visit_def_1513  1
    service_2_13_5  free_load_conservation_1514  -8
    service_2_13_5  original_T_including_depot_unload_1529  960
    service_2_13_6  unique_nonzero_owner_377  1
    service_2_13_6  service_visit_def_1513  1
    service_2_13_6  free_load_conservation_1514  -7
    service_2_13_6  original_T_including_depot_unload_1529  840
    service_2_13_7  unique_nonzero_owner_378  1
    service_2_13_7  service_visit_def_1513  1
    service_2_13_7  free_load_conservation_1514  -6
    service_2_13_7  original_T_including_depot_unload_1529  720
    service_2_13_8  unique_nonzero_owner_379  1
    service_2_13_8  service_visit_def_1513  1
    service_2_13_8  free_load_conservation_1514  -5
    service_2_13_8  original_T_including_depot_unload_1529  600
    service_2_13_9  unique_nonzero_owner_380  1
    service_2_13_9  service_visit_def_1513  1
    service_2_13_9  free_load_conservation_1514  -4
    service_2_13_9  original_T_including_depot_unload_1529  480
    service_2_13_10  unique_nonzero_owner_381  1
    service_2_13_10  service_visit_def_1513  1
    service_2_13_10  free_load_conservation_1514  -3
    service_2_13_10  original_T_including_depot_unload_1529  360
    service_2_13_11  unique_nonzero_owner_382  1
    service_2_13_11  service_visit_def_1513  1
    service_2_13_11  free_load_conservation_1514  -2
    service_2_13_11  original_T_including_depot_unload_1529  240
    service_2_13_12  unique_nonzero_owner_383  1
    service_2_13_12  service_visit_def_1513  1
    service_2_13_12  free_load_conservation_1514  -1
    service_2_13_12  original_T_including_depot_unload_1529  120
    service_2_13_14  unique_nonzero_owner_384  1
    service_2_13_14  service_visit_def_1513  1
    service_2_13_14  free_load_conservation_1514  1
    service_2_13_15  unique_nonzero_owner_385  1
    service_2_13_15  service_visit_def_1513  1
    service_2_13_15  free_load_conservation_1514  2
    service_2_13_16  unique_nonzero_owner_386  1
    service_2_13_16  service_visit_def_1513  1
    service_2_13_16  free_load_conservation_1514  3
    service_2_13_17  unique_nonzero_owner_387  1
    service_2_13_17  service_visit_def_1513  1
    service_2_13_17  free_load_conservation_1514  4
    service_2_13_18  unique_nonzero_owner_388  1
    service_2_13_18  service_visit_def_1513  1
    service_2_13_18  free_load_conservation_1514  5
    service_2_13_19  unique_nonzero_owner_389  1
    service_2_13_19  service_visit_def_1513  1
    service_2_13_19  free_load_conservation_1514  6
    service_0_19_1  unique_nonzero_owner_390  1
    service_0_19_1  service_visit_def_829  1
    service_0_19_1  free_load_conservation_830  1
    service_0_19_2  unique_nonzero_owner_391  1
    service_0_19_2  service_visit_def_829  1
    service_0_19_2  free_load_conservation_830  2
    service_0_19_3  unique_nonzero_owner_392  1
    service_0_19_3  service_visit_def_829  1
    service_0_19_3  free_load_conservation_830  3
    service_0_19_4  unique_nonzero_owner_393  1
    service_0_19_4  service_visit_def_829  1
    service_0_19_4  free_load_conservation_830  4
    service_0_19_5  unique_nonzero_owner_394  1
    service_0_19_5  service_visit_def_829  1
    service_0_19_5  free_load_conservation_830  5
    service_0_19_6  unique_nonzero_owner_395  1
    service_0_19_6  service_visit_def_829  1
    service_0_19_6  free_load_conservation_830  6
    service_0_19_7  unique_nonzero_owner_396  1
    service_0_19_7  service_visit_def_829  1
    service_0_19_7  free_load_conservation_830  7
    service_0_19_8  unique_nonzero_owner_397  1
    service_0_19_8  service_visit_def_829  1
    service_0_19_8  free_load_conservation_830  8
    service_1_19_1  unique_nonzero_owner_390  1
    service_1_19_1  service_visit_def_1201  1
    service_1_19_1  free_load_conservation_1202  1
    service_1_19_2  unique_nonzero_owner_391  1
    service_1_19_2  service_visit_def_1201  1
    service_1_19_2  free_load_conservation_1202  2
    service_1_19_3  unique_nonzero_owner_392  1
    service_1_19_3  service_visit_def_1201  1
    service_1_19_3  free_load_conservation_1202  3
    service_1_19_4  unique_nonzero_owner_393  1
    service_1_19_4  service_visit_def_1201  1
    service_1_19_4  free_load_conservation_1202  4
    service_1_19_5  unique_nonzero_owner_394  1
    service_1_19_5  service_visit_def_1201  1
    service_1_19_5  free_load_conservation_1202  5
    service_1_19_6  unique_nonzero_owner_395  1
    service_1_19_6  service_visit_def_1201  1
    service_1_19_6  free_load_conservation_1202  6
    service_1_19_7  unique_nonzero_owner_396  1
    service_1_19_7  service_visit_def_1201  1
    service_1_19_7  free_load_conservation_1202  7
    service_1_19_8  unique_nonzero_owner_397  1
    service_1_19_8  service_visit_def_1201  1
    service_1_19_8  free_load_conservation_1202  8
    service_2_19_1  unique_nonzero_owner_390  1
    service_2_19_1  service_visit_def_1519  1
    service_2_19_1  free_load_conservation_1520  1
    service_2_19_2  unique_nonzero_owner_391  1
    service_2_19_2  service_visit_def_1519  1
    service_2_19_2  free_load_conservation_1520  2
    service_2_19_3  unique_nonzero_owner_392  1
    service_2_19_3  service_visit_def_1519  1
    service_2_19_3  free_load_conservation_1520  3
    service_2_19_4  unique_nonzero_owner_393  1
    service_2_19_4  service_visit_def_1519  1
    service_2_19_4  free_load_conservation_1520  4
    service_2_19_5  unique_nonzero_owner_394  1
    service_2_19_5  service_visit_def_1519  1
    service_2_19_5  free_load_conservation_1520  5
    service_2_19_6  unique_nonzero_owner_395  1
    service_2_19_6  service_visit_def_1519  1
    service_2_19_6  free_load_conservation_1520  6
    service_2_19_7  unique_nonzero_owner_396  1
    service_2_19_7  service_visit_def_1519  1
    service_2_19_7  free_load_conservation_1520  7
    service_2_19_8  unique_nonzero_owner_397  1
    service_2_19_8  service_visit_def_1519  1
    service_2_19_8  free_load_conservation_1520  8
    service_0_12_1  unique_nonzero_owner_398  1
    service_0_12_1  service_visit_def_835  1
    service_0_12_1  free_load_conservation_836  1
    service_0_12_2  unique_nonzero_owner_399  1
    service_0_12_2  service_visit_def_835  1
    service_0_12_2  free_load_conservation_836  2
    service_0_12_3  unique_nonzero_owner_400  1
    service_0_12_3  service_visit_def_835  1
    service_0_12_3  free_load_conservation_836  3
    service_0_12_4  unique_nonzero_owner_401  1
    service_0_12_4  service_visit_def_835  1
    service_0_12_4  free_load_conservation_836  4
    service_0_12_5  unique_nonzero_owner_402  1
    service_0_12_5  service_visit_def_835  1
    service_0_12_5  free_load_conservation_836  5
    service_0_12_6  unique_nonzero_owner_403  1
    service_0_12_6  service_visit_def_835  1
    service_0_12_6  free_load_conservation_836  6
    service_0_12_7  unique_nonzero_owner_404  1
    service_0_12_7  service_visit_def_835  1
    service_0_12_7  free_load_conservation_836  7
    service_0_12_8  unique_nonzero_owner_405  1
    service_0_12_8  service_visit_def_835  1
    service_0_12_8  free_load_conservation_836  8
    service_0_12_9  unique_nonzero_owner_406  1
    service_0_12_9  service_visit_def_835  1
    service_0_12_9  free_load_conservation_836  9
    service_0_12_10  unique_nonzero_owner_407  1
    service_0_12_10  service_visit_def_835  1
    service_0_12_10  free_load_conservation_836  10
    service_0_12_11  unique_nonzero_owner_408  1
    service_0_12_11  service_visit_def_835  1
    service_0_12_11  free_load_conservation_836  11
    service_0_12_12  unique_nonzero_owner_409  1
    service_0_12_12  service_visit_def_835  1
    service_0_12_12  free_load_conservation_836  12
    service_0_12_13  unique_nonzero_owner_410  1
    service_0_12_13  service_visit_def_835  1
    service_0_12_13  free_load_conservation_836  13
    service_0_12_14  unique_nonzero_owner_411  1
    service_0_12_14  service_visit_def_835  1
    service_0_12_14  free_load_conservation_836  14
    service_0_12_15  unique_nonzero_owner_412  1
    service_0_12_15  service_visit_def_835  1
    service_0_12_15  free_load_conservation_836  15
    service_1_12_1  unique_nonzero_owner_398  1
    service_1_12_1  service_visit_def_1207  1
    service_1_12_1  free_load_conservation_1208  1
    service_1_12_2  unique_nonzero_owner_399  1
    service_1_12_2  service_visit_def_1207  1
    service_1_12_2  free_load_conservation_1208  2
    service_1_12_3  unique_nonzero_owner_400  1
    service_1_12_3  service_visit_def_1207  1
    service_1_12_3  free_load_conservation_1208  3
    service_1_12_4  unique_nonzero_owner_401  1
    service_1_12_4  service_visit_def_1207  1
    service_1_12_4  free_load_conservation_1208  4
    service_1_12_5  unique_nonzero_owner_402  1
    service_1_12_5  service_visit_def_1207  1
    service_1_12_5  free_load_conservation_1208  5
    service_1_12_6  unique_nonzero_owner_403  1
    service_1_12_6  service_visit_def_1207  1
    service_1_12_6  free_load_conservation_1208  6
    service_1_12_7  unique_nonzero_owner_404  1
    service_1_12_7  service_visit_def_1207  1
    service_1_12_7  free_load_conservation_1208  7
    service_1_12_8  unique_nonzero_owner_405  1
    service_1_12_8  service_visit_def_1207  1
    service_1_12_8  free_load_conservation_1208  8
    service_1_12_9  unique_nonzero_owner_406  1
    service_1_12_9  service_visit_def_1207  1
    service_1_12_9  free_load_conservation_1208  9
    service_1_12_10  unique_nonzero_owner_407  1
    service_1_12_10  service_visit_def_1207  1
    service_1_12_10  free_load_conservation_1208  10
    service_1_12_11  unique_nonzero_owner_408  1
    service_1_12_11  service_visit_def_1207  1
    service_1_12_11  free_load_conservation_1208  11
    service_1_12_12  unique_nonzero_owner_409  1
    service_1_12_12  service_visit_def_1207  1
    service_1_12_12  free_load_conservation_1208  12
    service_1_12_13  unique_nonzero_owner_410  1
    service_1_12_13  service_visit_def_1207  1
    service_1_12_13  free_load_conservation_1208  13
    service_1_12_14  unique_nonzero_owner_411  1
    service_1_12_14  service_visit_def_1207  1
    service_1_12_14  free_load_conservation_1208  14
    service_1_12_15  unique_nonzero_owner_412  1
    service_1_12_15  service_visit_def_1207  1
    service_1_12_15  free_load_conservation_1208  15
    service_2_12_1  unique_nonzero_owner_398  1
    service_2_12_1  service_visit_def_1525  1
    service_2_12_1  free_load_conservation_1526  1
    service_2_12_2  unique_nonzero_owner_399  1
    service_2_12_2  service_visit_def_1525  1
    service_2_12_2  free_load_conservation_1526  2
    service_2_12_3  unique_nonzero_owner_400  1
    service_2_12_3  service_visit_def_1525  1
    service_2_12_3  free_load_conservation_1526  3
    service_2_12_4  unique_nonzero_owner_401  1
    service_2_12_4  service_visit_def_1525  1
    service_2_12_4  free_load_conservation_1526  4
    service_2_12_5  unique_nonzero_owner_402  1
    service_2_12_5  service_visit_def_1525  1
    service_2_12_5  free_load_conservation_1526  5
    service_2_12_6  unique_nonzero_owner_403  1
    service_2_12_6  service_visit_def_1525  1
    service_2_12_6  free_load_conservation_1526  6
    service_2_12_7  unique_nonzero_owner_404  1
    service_2_12_7  service_visit_def_1525  1
    service_2_12_7  free_load_conservation_1526  7
    service_2_12_8  unique_nonzero_owner_405  1
    service_2_12_8  service_visit_def_1525  1
    service_2_12_8  free_load_conservation_1526  8
    service_2_12_9  unique_nonzero_owner_406  1
    service_2_12_9  service_visit_def_1525  1
    service_2_12_9  free_load_conservation_1526  9
    service_2_12_10  unique_nonzero_owner_407  1
    service_2_12_10  service_visit_def_1525  1
    service_2_12_10  free_load_conservation_1526  10
    service_2_12_11  unique_nonzero_owner_408  1
    service_2_12_11  service_visit_def_1525  1
    service_2_12_11  free_load_conservation_1526  11
    service_2_12_12  unique_nonzero_owner_409  1
    service_2_12_12  service_visit_def_1525  1
    service_2_12_12  free_load_conservation_1526  12
    service_2_12_13  unique_nonzero_owner_410  1
    service_2_12_13  service_visit_def_1525  1
    service_2_12_13  free_load_conservation_1526  13
    service_2_12_14  unique_nonzero_owner_411  1
    service_2_12_14  service_visit_def_1525  1
    service_2_12_14  free_load_conservation_1526  14
    service_2_12_15  unique_nonzero_owner_412  1
    service_2_12_15  service_visit_def_1525  1
    service_2_12_15  free_load_conservation_1526  15
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_754  -1
    visit_0_1  in_degree_755  -1
    visit_0_1  order_active_lb_756  -1
    visit_0_1  order_active_ub_757  -13
    order_0_1  connected_order_arc_429  -1
    order_0_1  connected_order_arc_431  -1
    order_0_1  connected_order_arc_433  -1
    order_0_1  connected_order_arc_435  -1
    order_0_1  connected_order_arc_437  -1
    order_0_1  connected_order_arc_439  -1
    order_0_1  connected_order_arc_441  -1
    order_0_1  connected_order_arc_443  -1
    order_0_1  connected_order_arc_445  -1
    order_0_1  connected_order_arc_447  -1
    order_0_1  connected_order_arc_449  -1
    order_0_1  connected_order_arc_451  -1
    order_0_1  connected_order_arc_454  1
    order_0_1  connected_order_arc_479  1
    order_0_1  connected_order_arc_504  1
    order_0_1  connected_order_arc_529  1
    order_0_1  connected_order_arc_554  1
    order_0_1  connected_order_arc_579  1
    order_0_1  connected_order_arc_604  1
    order_0_1  connected_order_arc_629  1
    order_0_1  connected_order_arc_654  1
    order_0_1  connected_order_arc_679  1
    order_0_1  connected_order_arc_704  1
    order_0_1  connected_order_arc_729  1
    order_0_1  order_active_lb_756  1
    order_0_1  order_active_ub_757  1
    order_0_1  fixed_segment_relative_order_837  -1
    visit_0_2  out_degree_761  -1
    visit_0_2  in_degree_762  -1
    visit_0_2  order_active_lb_763  -1
    visit_0_2  order_active_ub_764  -13
    order_0_2  connected_order_arc_429  1
    order_0_2  connected_order_arc_454  -1
    order_0_2  connected_order_arc_456  -1
    order_0_2  connected_order_arc_458  -1
    order_0_2  connected_order_arc_460  -1
    order_0_2  connected_order_arc_462  -1
    order_0_2  connected_order_arc_464  -1
    order_0_2  connected_order_arc_466  -1
    order_0_2  connected_order_arc_468  -1
    order_0_2  connected_order_arc_470  -1
    order_0_2  connected_order_arc_472  -1
    order_0_2  connected_order_arc_474  -1
    order_0_2  connected_order_arc_476  -1
    order_0_2  connected_order_arc_481  1
    order_0_2  connected_order_arc_506  1
    order_0_2  connected_order_arc_531  1
    order_0_2  connected_order_arc_556  1
    order_0_2  connected_order_arc_581  1
    order_0_2  connected_order_arc_606  1
    order_0_2  connected_order_arc_631  1
    order_0_2  connected_order_arc_656  1
    order_0_2  connected_order_arc_681  1
    order_0_2  connected_order_arc_706  1
    order_0_2  connected_order_arc_731  1
    order_0_2  order_active_lb_763  1
    order_0_2  order_active_ub_764  1
    order_0_2  fixed_segment_relative_order_837  1
    order_0_2  fixed_segment_relative_order_838  -1
    visit_0_3  out_degree_768  -1
    visit_0_3  in_degree_769  -1
    visit_0_3  order_active_lb_770  -1
    visit_0_3  order_active_ub_771  -13
    order_0_3  connected_order_arc_431  1
    order_0_3  connected_order_arc_456  1
    order_0_3  connected_order_arc_479  -1
    order_0_3  connected_order_arc_481  -1
    order_0_3  connected_order_arc_483  -1
    order_0_3  connected_order_arc_485  -1
    order_0_3  connected_order_arc_487  -1
    order_0_3  connected_order_arc_489  -1
    order_0_3  connected_order_arc_491  -1
    order_0_3  connected_order_arc_493  -1
    order_0_3  connected_order_arc_495  -1
    order_0_3  connected_order_arc_497  -1
    order_0_3  connected_order_arc_499  -1
    order_0_3  connected_order_arc_501  -1
    order_0_3  connected_order_arc_508  1
    order_0_3  connected_order_arc_533  1
    order_0_3  connected_order_arc_558  1
    order_0_3  connected_order_arc_583  1
    order_0_3  connected_order_arc_608  1
    order_0_3  connected_order_arc_633  1
    order_0_3  connected_order_arc_658  1
    order_0_3  connected_order_arc_683  1
    order_0_3  connected_order_arc_708  1
    order_0_3  connected_order_arc_733  1
    order_0_3  order_active_lb_770  1
    order_0_3  order_active_ub_771  1
    order_0_3  fixed_segment_relative_order_838  1
    order_0_3  fixed_segment_relative_order_839  -1
    visit_0_4  out_degree_775  -1
    visit_0_4  in_degree_776  -1
    visit_0_4  order_active_lb_777  -1
    visit_0_4  order_active_ub_778  -13
    order_0_4  connected_order_arc_433  1
    order_0_4  connected_order_arc_458  1
    order_0_4  connected_order_arc_483  1
    order_0_4  connected_order_arc_504  -1
    order_0_4  connected_order_arc_506  -1
    order_0_4  connected_order_arc_508  -1
    order_0_4  connected_order_arc_510  -1
    order_0_4  connected_order_arc_512  -1
    order_0_4  connected_order_arc_514  -1
    order_0_4  connected_order_arc_516  -1
    order_0_4  connected_order_arc_518  -1
    order_0_4  connected_order_arc_520  -1
    order_0_4  connected_order_arc_522  -1
    order_0_4  connected_order_arc_524  -1
    order_0_4  connected_order_arc_526  -1
    order_0_4  connected_order_arc_535  1
    order_0_4  connected_order_arc_560  1
    order_0_4  connected_order_arc_585  1
    order_0_4  connected_order_arc_610  1
    order_0_4  connected_order_arc_635  1
    order_0_4  connected_order_arc_660  1
    order_0_4  connected_order_arc_685  1
    order_0_4  connected_order_arc_710  1
    order_0_4  connected_order_arc_735  1
    order_0_4  order_active_lb_777  1
    order_0_4  order_active_ub_778  1
    order_0_4  fixed_segment_relative_order_839  1
    order_0_4  fixed_segment_relative_order_840  -1
    visit_0_5  out_degree_782  -1
    visit_0_5  in_degree_783  -1
    visit_0_5  order_active_lb_784  -1
    visit_0_5  order_active_ub_785  -13
    order_0_5  connected_order_arc_435  1
    order_0_5  connected_order_arc_460  1
    order_0_5  connected_order_arc_485  1
    order_0_5  connected_order_arc_510  1
    order_0_5  connected_order_arc_529  -1
    order_0_5  connected_order_arc_531  -1
    order_0_5  connected_order_arc_533  -1
    order_0_5  connected_order_arc_535  -1
    order_0_5  connected_order_arc_537  -1
    order_0_5  connected_order_arc_539  -1
    order_0_5  connected_order_arc_541  -1
    order_0_5  connected_order_arc_543  -1
    order_0_5  connected_order_arc_545  -1
    order_0_5  connected_order_arc_547  -1
    order_0_5  connected_order_arc_549  -1
    order_0_5  connected_order_arc_551  -1
    order_0_5  connected_order_arc_562  1
    order_0_5  connected_order_arc_587  1
    order_0_5  connected_order_arc_612  1
    order_0_5  connected_order_arc_637  1
    order_0_5  connected_order_arc_662  1
    order_0_5  connected_order_arc_687  1
    order_0_5  connected_order_arc_712  1
    order_0_5  connected_order_arc_737  1
    order_0_5  order_active_lb_784  1
    order_0_5  order_active_ub_785  1
    order_0_5  fixed_segment_relative_order_840  1
    visit_0_13  out_degree_789  -1
    visit_0_13  in_degree_790  -1
    visit_0_13  order_active_lb_791  -1
    visit_0_13  order_active_ub_792  -13
    visit_0_13  service_visit_def_793  -1
    order_0_13  connected_order_arc_437  1
    order_0_13  connected_order_arc_462  1
    order_0_13  connected_order_arc_487  1
    order_0_13  connected_order_arc_512  1
    order_0_13  connected_order_arc_537  1
    order_0_13  connected_order_arc_554  -1
    order_0_13  connected_order_arc_556  -1
    order_0_13  connected_order_arc_558  -1
    order_0_13  connected_order_arc_560  -1
    order_0_13  connected_order_arc_562  -1
    order_0_13  connected_order_arc_564  -1
    order_0_13  connected_order_arc_566  -1
    order_0_13  connected_order_arc_568  -1
    order_0_13  connected_order_arc_570  -1
    order_0_13  connected_order_arc_572  -1
    order_0_13  connected_order_arc_574  -1
    order_0_13  connected_order_arc_576  -1
    order_0_13  connected_order_arc_589  1
    order_0_13  connected_order_arc_614  1
    order_0_13  connected_order_arc_639  1
    order_0_13  connected_order_arc_664  1
    order_0_13  connected_order_arc_689  1
    order_0_13  connected_order_arc_714  1
    order_0_13  connected_order_arc_739  1
    order_0_13  order_active_lb_791  1
    order_0_13  order_active_ub_792  1
    visit_0_14  out_degree_795  -1
    visit_0_14  in_degree_796  -1
    visit_0_14  order_active_lb_797  -1
    visit_0_14  order_active_ub_798  -13
    visit_0_14  service_visit_def_799  -1
    order_0_14  connected_order_arc_439  1
    order_0_14  connected_order_arc_464  1
    order_0_14  connected_order_arc_489  1
    order_0_14  connected_order_arc_514  1
    order_0_14  connected_order_arc_539  1
    order_0_14  connected_order_arc_564  1
    order_0_14  connected_order_arc_579  -1
    order_0_14  connected_order_arc_581  -1
    order_0_14  connected_order_arc_583  -1
    order_0_14  connected_order_arc_585  -1
    order_0_14  connected_order_arc_587  -1
    order_0_14  connected_order_arc_589  -1
    order_0_14  connected_order_arc_591  -1
    order_0_14  connected_order_arc_593  -1
    order_0_14  connected_order_arc_595  -1
    order_0_14  connected_order_arc_597  -1
    order_0_14  connected_order_arc_599  -1
    order_0_14  connected_order_arc_601  -1
    order_0_14  connected_order_arc_616  1
    order_0_14  connected_order_arc_641  1
    order_0_14  connected_order_arc_666  1
    order_0_14  connected_order_arc_691  1
    order_0_14  connected_order_arc_716  1
    order_0_14  connected_order_arc_741  1
    order_0_14  order_active_lb_797  1
    order_0_14  order_active_ub_798  1
    visit_0_15  out_degree_801  -1
    visit_0_15  in_degree_802  -1
    visit_0_15  order_active_lb_803  -1
    visit_0_15  order_active_ub_804  -13
    visit_0_15  service_visit_def_805  -1
    order_0_15  connected_order_arc_441  1
    order_0_15  connected_order_arc_466  1
    order_0_15  connected_order_arc_491  1
    order_0_15  connected_order_arc_516  1
    order_0_15  connected_order_arc_541  1
    order_0_15  connected_order_arc_566  1
    order_0_15  connected_order_arc_591  1
    order_0_15  connected_order_arc_604  -1
    order_0_15  connected_order_arc_606  -1
    order_0_15  connected_order_arc_608  -1
    order_0_15  connected_order_arc_610  -1
    order_0_15  connected_order_arc_612  -1
    order_0_15  connected_order_arc_614  -1
    order_0_15  connected_order_arc_616  -1
    order_0_15  connected_order_arc_618  -1
    order_0_15  connected_order_arc_620  -1
    order_0_15  connected_order_arc_622  -1
    order_0_15  connected_order_arc_624  -1
    order_0_15  connected_order_arc_626  -1
    order_0_15  connected_order_arc_643  1
    order_0_15  connected_order_arc_668  1
    order_0_15  connected_order_arc_693  1
    order_0_15  connected_order_arc_718  1
    order_0_15  connected_order_arc_743  1
    order_0_15  order_active_lb_803  1
    order_0_15  order_active_ub_804  1
    visit_0_16  out_degree_807  -1
    visit_0_16  in_degree_808  -1
    visit_0_16  order_active_lb_809  -1
    visit_0_16  order_active_ub_810  -13
    visit_0_16  service_visit_def_811  -1
    order_0_16  connected_order_arc_443  1
    order_0_16  connected_order_arc_468  1
    order_0_16  connected_order_arc_493  1
    order_0_16  connected_order_arc_518  1
    order_0_16  connected_order_arc_543  1
    order_0_16  connected_order_arc_568  1
    order_0_16  connected_order_arc_593  1
    order_0_16  connected_order_arc_618  1
    order_0_16  connected_order_arc_629  -1
    order_0_16  connected_order_arc_631  -1
    order_0_16  connected_order_arc_633  -1
    order_0_16  connected_order_arc_635  -1
    order_0_16  connected_order_arc_637  -1
    order_0_16  connected_order_arc_639  -1
    order_0_16  connected_order_arc_641  -1
    order_0_16  connected_order_arc_643  -1
    order_0_16  connected_order_arc_645  -1
    order_0_16  connected_order_arc_647  -1
    order_0_16  connected_order_arc_649  -1
    order_0_16  connected_order_arc_651  -1
    order_0_16  connected_order_arc_670  1
    order_0_16  connected_order_arc_695  1
    order_0_16  connected_order_arc_720  1
    order_0_16  connected_order_arc_745  1
    order_0_16  order_active_lb_809  1
    order_0_16  order_active_ub_810  1
    visit_0_17  out_degree_813  -1
    visit_0_17  in_degree_814  -1
    visit_0_17  order_active_lb_815  -1
    visit_0_17  order_active_ub_816  -13
    visit_0_17  service_visit_def_817  -1
    order_0_17  connected_order_arc_445  1
    order_0_17  connected_order_arc_470  1
    order_0_17  connected_order_arc_495  1
    order_0_17  connected_order_arc_520  1
    order_0_17  connected_order_arc_545  1
    order_0_17  connected_order_arc_570  1
    order_0_17  connected_order_arc_595  1
    order_0_17  connected_order_arc_620  1
    order_0_17  connected_order_arc_645  1
    order_0_17  connected_order_arc_654  -1
    order_0_17  connected_order_arc_656  -1
    order_0_17  connected_order_arc_658  -1
    order_0_17  connected_order_arc_660  -1
    order_0_17  connected_order_arc_662  -1
    order_0_17  connected_order_arc_664  -1
    order_0_17  connected_order_arc_666  -1
    order_0_17  connected_order_arc_668  -1
    order_0_17  connected_order_arc_670  -1
    order_0_17  connected_order_arc_672  -1
    order_0_17  connected_order_arc_674  -1
    order_0_17  connected_order_arc_676  -1
    order_0_17  connected_order_arc_697  1
    order_0_17  connected_order_arc_722  1
    order_0_17  connected_order_arc_747  1
    order_0_17  order_active_lb_815  1
    order_0_17  order_active_ub_816  1
    visit_0_18  out_degree_819  -1
    visit_0_18  in_degree_820  -1
    visit_0_18  order_active_lb_821  -1
    visit_0_18  order_active_ub_822  -13
    visit_0_18  service_visit_def_823  -1
    order_0_18  connected_order_arc_447  1
    order_0_18  connected_order_arc_472  1
    order_0_18  connected_order_arc_497  1
    order_0_18  connected_order_arc_522  1
    order_0_18  connected_order_arc_547  1
    order_0_18  connected_order_arc_572  1
    order_0_18  connected_order_arc_597  1
    order_0_18  connected_order_arc_622  1
    order_0_18  connected_order_arc_647  1
    order_0_18  connected_order_arc_672  1
    order_0_18  connected_order_arc_679  -1
    order_0_18  connected_order_arc_681  -1
    order_0_18  connected_order_arc_683  -1
    order_0_18  connected_order_arc_685  -1
    order_0_18  connected_order_arc_687  -1
    order_0_18  connected_order_arc_689  -1
    order_0_18  connected_order_arc_691  -1
    order_0_18  connected_order_arc_693  -1
    order_0_18  connected_order_arc_695  -1
    order_0_18  connected_order_arc_697  -1
    order_0_18  connected_order_arc_699  -1
    order_0_18  connected_order_arc_701  -1
    order_0_18  connected_order_arc_724  1
    order_0_18  connected_order_arc_749  1
    order_0_18  order_active_lb_821  1
    order_0_18  order_active_ub_822  1
    visit_0_19  out_degree_825  -1
    visit_0_19  in_degree_826  -1
    visit_0_19  order_active_lb_827  -1
    visit_0_19  order_active_ub_828  -13
    visit_0_19  service_visit_def_829  -1
    order_0_19  connected_order_arc_449  1
    order_0_19  connected_order_arc_474  1
    order_0_19  connected_order_arc_499  1
    order_0_19  connected_order_arc_524  1
    order_0_19  connected_order_arc_549  1
    order_0_19  connected_order_arc_574  1
    order_0_19  connected_order_arc_599  1
    order_0_19  connected_order_arc_624  1
    order_0_19  connected_order_arc_649  1
    order_0_19  connected_order_arc_674  1
    order_0_19  connected_order_arc_699  1
    order_0_19  connected_order_arc_704  -1
    order_0_19  connected_order_arc_706  -1
    order_0_19  connected_order_arc_708  -1
    order_0_19  connected_order_arc_710  -1
    order_0_19  connected_order_arc_712  -1
    order_0_19  connected_order_arc_714  -1
    order_0_19  connected_order_arc_716  -1
    order_0_19  connected_order_arc_718  -1
    order_0_19  connected_order_arc_720  -1
    order_0_19  connected_order_arc_722  -1
    order_0_19  connected_order_arc_724  -1
    order_0_19  connected_order_arc_726  -1
    order_0_19  connected_order_arc_751  1
    order_0_19  order_active_lb_827  1
    order_0_19  order_active_ub_828  1
    visit_0_20  out_degree_831  -1
    visit_0_20  in_degree_832  -1
    visit_0_20  order_active_lb_833  -1
    visit_0_20  order_active_ub_834  -13
    visit_0_20  service_visit_def_835  -1
    order_0_20  connected_order_arc_451  1
    order_0_20  connected_order_arc_476  1
    order_0_20  connected_order_arc_501  1
    order_0_20  connected_order_arc_526  1
    order_0_20  connected_order_arc_551  1
    order_0_20  connected_order_arc_576  1
    order_0_20  connected_order_arc_601  1
    order_0_20  connected_order_arc_626  1
    order_0_20  connected_order_arc_651  1
    order_0_20  connected_order_arc_676  1
    order_0_20  connected_order_arc_701  1
    order_0_20  connected_order_arc_726  1
    order_0_20  connected_order_arc_729  -1
    order_0_20  connected_order_arc_731  -1
    order_0_20  connected_order_arc_733  -1
    order_0_20  connected_order_arc_735  -1
    order_0_20  connected_order_arc_737  -1
    order_0_20  connected_order_arc_739  -1
    order_0_20  connected_order_arc_741  -1
    order_0_20  connected_order_arc_743  -1
    order_0_20  connected_order_arc_745  -1
    order_0_20  connected_order_arc_747  -1
    order_0_20  connected_order_arc_749  -1
    order_0_20  connected_order_arc_751  -1
    order_0_20  order_active_lb_833  1
    order_0_20  order_active_ub_834  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_413  -20
    arc_0_0_0  depot_departure_or_bypass_752  1
    arc_0_0_0  depot_return_or_bypass_753  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_413  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_414  -20
    arc_0_0_1  depot_departure_or_bypass_752  1
    arc_0_0_1  in_degree_755  1
    arc_0_0_1  original_T_including_depot_unload_841  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_414  1
    load_0_0_1  segment_load_conservation_758  -1
    load_0_0_1  segment_prefix_lb_759  1
    load_0_0_1  segment_prefix_ub_760  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_415  -20
    arc_0_0_2  depot_departure_or_bypass_752  1
    arc_0_0_2  in_degree_762  1
    arc_0_0_2  original_T_including_depot_unload_841  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_415  1
    load_0_0_2  segment_load_conservation_765  -1
    load_0_0_2  segment_prefix_lb_766  1
    load_0_0_2  segment_prefix_ub_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_416  -20
    arc_0_0_3  depot_departure_or_bypass_752  1
    arc_0_0_3  in_degree_769  1
    arc_0_0_3  original_T_including_depot_unload_841  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_416  1
    load_0_0_3  segment_load_conservation_772  -1
    load_0_0_3  segment_prefix_lb_773  1
    load_0_0_3  segment_prefix_ub_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_417  -20
    arc_0_0_4  depot_departure_or_bypass_752  1
    arc_0_0_4  in_degree_776  1
    arc_0_0_4  original_T_including_depot_unload_841  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_417  1
    load_0_0_4  segment_load_conservation_779  -1
    load_0_0_4  segment_prefix_lb_780  1
    load_0_0_4  segment_prefix_ub_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_418  -20
    arc_0_0_5  depot_departure_or_bypass_752  1
    arc_0_0_5  in_degree_783  1
    arc_0_0_5  original_T_including_depot_unload_841  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_418  1
    load_0_0_5  segment_load_conservation_786  -1
    load_0_0_5  segment_prefix_lb_787  1
    load_0_0_5  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_419  -20
    arc_0_0_13  depot_departure_or_bypass_752  1
    arc_0_0_13  in_degree_790  1
    arc_0_0_13  original_T_including_depot_unload_841  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_419  1
    load_0_0_13  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_420  -20
    arc_0_0_14  depot_departure_or_bypass_752  1
    arc_0_0_14  in_degree_796  1
    arc_0_0_14  original_T_including_depot_unload_841  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_420  1
    load_0_0_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_421  -20
    arc_0_0_15  depot_departure_or_bypass_752  1
    arc_0_0_15  in_degree_802  1
    arc_0_0_15  original_T_including_depot_unload_841  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_421  1
    load_0_0_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_422  -20
    arc_0_0_16  depot_departure_or_bypass_752  1
    arc_0_0_16  in_degree_808  1
    arc_0_0_16  original_T_including_depot_unload_841  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_422  1
    load_0_0_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_423  -20
    arc_0_0_17  depot_departure_or_bypass_752  1
    arc_0_0_17  in_degree_814  1
    arc_0_0_17  original_T_including_depot_unload_841  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_423  1
    load_0_0_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_424  -20
    arc_0_0_18  depot_departure_or_bypass_752  1
    arc_0_0_18  in_degree_820  1
    arc_0_0_18  original_T_including_depot_unload_841  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_424  1
    load_0_0_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_425  -20
    arc_0_0_19  depot_departure_or_bypass_752  1
    arc_0_0_19  in_degree_826  1
    arc_0_0_19  original_T_including_depot_unload_841  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_425  1
    load_0_0_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_426  -20
    arc_0_0_20  depot_departure_or_bypass_752  1
    arc_0_0_20  in_degree_832  1
    arc_0_0_20  original_T_including_depot_unload_841  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_426  1
    load_0_0_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_427  -20
    arc_0_1_0  depot_return_or_bypass_753  1
    arc_0_1_0  out_degree_754  1
    arc_0_1_0  original_T_including_depot_unload_841  4.5445020320724507e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_427  1
    load_0_1_0  segment_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_428  -20
    arc_0_1_2  connected_order_arc_429  -14
    arc_0_1_2  out_degree_754  1
    arc_0_1_2  in_degree_762  1
    arc_0_1_2  original_T_including_depot_unload_841  2.7570828838654035e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_428  1
    load_0_1_2  segment_load_conservation_758  1
    load_0_1_2  segment_load_conservation_765  -1
    load_0_1_2  segment_prefix_lb_766  1
    load_0_1_2  segment_prefix_ub_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_430  -20
    arc_0_1_3  connected_order_arc_431  -14
    arc_0_1_3  out_degree_754  1
    arc_0_1_3  in_degree_769  1
    arc_0_1_3  original_T_including_depot_unload_841  1.7053268374267958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_430  1
    load_0_1_3  segment_load_conservation_758  1
    load_0_1_3  segment_load_conservation_772  -1
    load_0_1_3  segment_prefix_lb_773  1
    load_0_1_3  segment_prefix_ub_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_432  -20
    arc_0_1_4  connected_order_arc_433  -14
    arc_0_1_4  out_degree_754  1
    arc_0_1_4  in_degree_776  1
    arc_0_1_4  original_T_including_depot_unload_841  4.0284428834016438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_432  1
    load_0_1_4  segment_load_conservation_758  1
    load_0_1_4  segment_load_conservation_779  -1
    load_0_1_4  segment_prefix_lb_780  1
    load_0_1_4  segment_prefix_ub_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_434  -20
    arc_0_1_5  connected_order_arc_435  -14
    arc_0_1_5  out_degree_754  1
    arc_0_1_5  in_degree_783  1
    arc_0_1_5  original_T_including_depot_unload_841  7.9195606724980928e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_434  1
    load_0_1_5  segment_load_conservation_758  1
    load_0_1_5  segment_load_conservation_786  -1
    load_0_1_5  segment_prefix_lb_787  1
    load_0_1_5  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_436  -20
    arc_0_1_13  connected_order_arc_437  -14
    arc_0_1_13  out_degree_754  1
    arc_0_1_13  in_degree_790  1
    arc_0_1_13  original_T_including_depot_unload_841  4.5094949828949649e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_436  1
    load_0_1_13  segment_load_conservation_758  1
    load_0_1_13  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_438  -20
    arc_0_1_14  connected_order_arc_439  -14
    arc_0_1_14  out_degree_754  1
    arc_0_1_14  in_degree_796  1
    arc_0_1_14  original_T_including_depot_unload_841  2.9376641610717382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_438  1
    load_0_1_14  segment_load_conservation_758  1
    load_0_1_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_440  -20
    arc_0_1_15  connected_order_arc_441  -14
    arc_0_1_15  out_degree_754  1
    arc_0_1_15  in_degree_802  1
    arc_0_1_15  original_T_including_depot_unload_841  1.5365129533603906e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_440  1
    load_0_1_15  segment_load_conservation_758  1
    load_0_1_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_442  -20
    arc_0_1_16  connected_order_arc_443  -14
    arc_0_1_16  out_degree_754  1
    arc_0_1_16  in_degree_808  1
    arc_0_1_16  original_T_including_depot_unload_841  6.7868877694996661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_442  1
    load_0_1_16  segment_load_conservation_758  1
    load_0_1_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_444  -20
    arc_0_1_17  connected_order_arc_445  -14
    arc_0_1_17  out_degree_754  1
    arc_0_1_17  in_degree_814  1
    arc_0_1_17  original_T_including_depot_unload_841  1.5530568652263394e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_444  1
    load_0_1_17  segment_load_conservation_758  1
    load_0_1_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_446  -20
    arc_0_1_18  connected_order_arc_447  -14
    arc_0_1_18  out_degree_754  1
    arc_0_1_18  in_degree_820  1
    arc_0_1_18  original_T_including_depot_unload_841  5.8227353503177085e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_446  1
    load_0_1_18  segment_load_conservation_758  1
    load_0_1_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_448  -20
    arc_0_1_19  connected_order_arc_449  -14
    arc_0_1_19  out_degree_754  1
    arc_0_1_19  in_degree_826  1
    arc_0_1_19  original_T_including_depot_unload_841  9.1580557259044724e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_448  1
    load_0_1_19  segment_load_conservation_758  1
    load_0_1_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_450  -20
    arc_0_1_20  connected_order_arc_451  -14
    arc_0_1_20  out_degree_754  1
    arc_0_1_20  in_degree_832  1
    arc_0_1_20  original_T_including_depot_unload_841  5.7354473845222140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_450  1
    load_0_1_20  segment_load_conservation_758  1
    load_0_1_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_452  -20
    arc_0_2_0  depot_return_or_bypass_753  1
    arc_0_2_0  out_degree_761  1
    arc_0_2_0  original_T_including_depot_unload_841  7.1012749626611151e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_452  1
    load_0_2_0  segment_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_453  -20
    arc_0_2_1  connected_order_arc_454  -14
    arc_0_2_1  in_degree_755  1
    arc_0_2_1  out_degree_761  1
    arc_0_2_1  original_T_including_depot_unload_841  545.439458844012
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_453  1
    load_0_2_1  segment_load_conservation_758  -1
    load_0_2_1  segment_prefix_lb_759  1
    load_0_2_1  segment_prefix_ub_760  1
    load_0_2_1  segment_load_conservation_765  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_455  -20
    arc_0_2_3  connected_order_arc_456  -14
    arc_0_2_3  out_degree_761  1
    arc_0_2_3  in_degree_769  1
    arc_0_2_3  original_T_including_depot_unload_841  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_455  1
    load_0_2_3  segment_load_conservation_765  1
    load_0_2_3  segment_load_conservation_772  -1
    load_0_2_3  segment_prefix_lb_773  1
    load_0_2_3  segment_prefix_ub_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_457  -20
    arc_0_2_4  connected_order_arc_458  -14
    arc_0_2_4  out_degree_761  1
    arc_0_2_4  in_degree_776  1
    arc_0_2_4  original_T_including_depot_unload_841  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_457  1
    load_0_2_4  segment_load_conservation_765  1
    load_0_2_4  segment_load_conservation_779  -1
    load_0_2_4  segment_prefix_lb_780  1
    load_0_2_4  segment_prefix_ub_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_459  -20
    arc_0_2_5  connected_order_arc_460  -14
    arc_0_2_5  out_degree_761  1
    arc_0_2_5  in_degree_783  1
    arc_0_2_5  original_T_including_depot_unload_841  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_459  1
    load_0_2_5  segment_load_conservation_765  1
    load_0_2_5  segment_load_conservation_786  -1
    load_0_2_5  segment_prefix_lb_787  1
    load_0_2_5  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_461  -20
    arc_0_2_13  connected_order_arc_462  -14
    arc_0_2_13  out_degree_761  1
    arc_0_2_13  in_degree_790  1
    arc_0_2_13  original_T_including_depot_unload_841  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_461  1
    load_0_2_13  segment_load_conservation_765  1
    load_0_2_13  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_463  -20
    arc_0_2_14  connected_order_arc_464  -14
    arc_0_2_14  out_degree_761  1
    arc_0_2_14  in_degree_796  1
    arc_0_2_14  original_T_including_depot_unload_841  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_463  1
    load_0_2_14  segment_load_conservation_765  1
    load_0_2_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_465  -20
    arc_0_2_15  connected_order_arc_466  -14
    arc_0_2_15  out_degree_761  1
    arc_0_2_15  in_degree_802  1
    arc_0_2_15  original_T_including_depot_unload_841  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_465  1
    load_0_2_15  segment_load_conservation_765  1
    load_0_2_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_467  -20
    arc_0_2_16  connected_order_arc_468  -14
    arc_0_2_16  out_degree_761  1
    arc_0_2_16  in_degree_808  1
    arc_0_2_16  original_T_including_depot_unload_841  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_467  1
    load_0_2_16  segment_load_conservation_765  1
    load_0_2_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_469  -20
    arc_0_2_17  connected_order_arc_470  -14
    arc_0_2_17  out_degree_761  1
    arc_0_2_17  in_degree_814  1
    arc_0_2_17  original_T_including_depot_unload_841  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_469  1
    load_0_2_17  segment_load_conservation_765  1
    load_0_2_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_471  -20
    arc_0_2_18  connected_order_arc_472  -14
    arc_0_2_18  out_degree_761  1
    arc_0_2_18  in_degree_820  1
    arc_0_2_18  original_T_including_depot_unload_841  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_471  1
    load_0_2_18  segment_load_conservation_765  1
    load_0_2_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_473  -20
    arc_0_2_19  connected_order_arc_474  -14
    arc_0_2_19  out_degree_761  1
    arc_0_2_19  in_degree_826  1
    arc_0_2_19  original_T_including_depot_unload_841  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_473  1
    load_0_2_19  segment_load_conservation_765  1
    load_0_2_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_475  -20
    arc_0_2_20  connected_order_arc_476  -14
    arc_0_2_20  out_degree_761  1
    arc_0_2_20  in_degree_832  1
    arc_0_2_20  original_T_including_depot_unload_841  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_475  1
    load_0_2_20  segment_load_conservation_765  1
    load_0_2_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_477  -20
    arc_0_3_0  depot_return_or_bypass_753  1
    arc_0_3_0  out_degree_768  1
    arc_0_3_0  original_T_including_depot_unload_841  4.9147437974424480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_477  1
    load_0_3_0  segment_load_conservation_772  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_478  -20
    arc_0_3_1  connected_order_arc_479  -14
    arc_0_3_1  in_degree_755  1
    arc_0_3_1  out_degree_768  1
    arc_0_3_1  original_T_including_depot_unload_841  3.9758967496529505e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_478  1
    load_0_3_1  segment_load_conservation_758  -1
    load_0_3_1  segment_prefix_lb_759  1
    load_0_3_1  segment_prefix_ub_760  1
    load_0_3_1  segment_load_conservation_772  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_480  -20
    arc_0_3_2  connected_order_arc_481  -14
    arc_0_3_2  in_degree_762  1
    arc_0_3_2  out_degree_768  1
    arc_0_3_2  original_T_including_depot_unload_841  2.4111148152767828e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_480  1
    load_0_3_2  segment_load_conservation_765  -1
    load_0_3_2  segment_prefix_lb_766  1
    load_0_3_2  segment_prefix_ub_767  1
    load_0_3_2  segment_load_conservation_772  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_482  -20
    arc_0_3_4  connected_order_arc_483  -14
    arc_0_3_4  out_degree_768  1
    arc_0_3_4  in_degree_776  1
    arc_0_3_4  original_T_including_depot_unload_841  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_482  1
    load_0_3_4  segment_load_conservation_772  1
    load_0_3_4  segment_load_conservation_779  -1
    load_0_3_4  segment_prefix_lb_780  1
    load_0_3_4  segment_prefix_ub_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_484  -20
    arc_0_3_5  connected_order_arc_485  -14
    arc_0_3_5  out_degree_768  1
    arc_0_3_5  in_degree_783  1
    arc_0_3_5  original_T_including_depot_unload_841  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_484  1
    load_0_3_5  segment_load_conservation_772  1
    load_0_3_5  segment_load_conservation_786  -1
    load_0_3_5  segment_prefix_lb_787  1
    load_0_3_5  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_486  -20
    arc_0_3_13  connected_order_arc_487  -14
    arc_0_3_13  out_degree_768  1
    arc_0_3_13  in_degree_790  1
    arc_0_3_13  original_T_including_depot_unload_841  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_486  1
    load_0_3_13  segment_load_conservation_772  1
    load_0_3_13  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_488  -20
    arc_0_3_14  connected_order_arc_489  -14
    arc_0_3_14  out_degree_768  1
    arc_0_3_14  in_degree_796  1
    arc_0_3_14  original_T_including_depot_unload_841  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_488  1
    load_0_3_14  segment_load_conservation_772  1
    load_0_3_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_490  -20
    arc_0_3_15  connected_order_arc_491  -14
    arc_0_3_15  out_degree_768  1
    arc_0_3_15  in_degree_802  1
    arc_0_3_15  original_T_including_depot_unload_841  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_490  1
    load_0_3_15  segment_load_conservation_772  1
    load_0_3_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_492  -20
    arc_0_3_16  connected_order_arc_493  -14
    arc_0_3_16  out_degree_768  1
    arc_0_3_16  in_degree_808  1
    arc_0_3_16  original_T_including_depot_unload_841  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_492  1
    load_0_3_16  segment_load_conservation_772  1
    load_0_3_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_494  -20
    arc_0_3_17  connected_order_arc_495  -14
    arc_0_3_17  out_degree_768  1
    arc_0_3_17  in_degree_814  1
    arc_0_3_17  original_T_including_depot_unload_841  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_494  1
    load_0_3_17  segment_load_conservation_772  1
    load_0_3_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_496  -20
    arc_0_3_18  connected_order_arc_497  -14
    arc_0_3_18  out_degree_768  1
    arc_0_3_18  in_degree_820  1
    arc_0_3_18  original_T_including_depot_unload_841  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_496  1
    load_0_3_18  segment_load_conservation_772  1
    load_0_3_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_498  -20
    arc_0_3_19  connected_order_arc_499  -14
    arc_0_3_19  out_degree_768  1
    arc_0_3_19  in_degree_826  1
    arc_0_3_19  original_T_including_depot_unload_841  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_498  1
    load_0_3_19  segment_load_conservation_772  1
    load_0_3_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_500  -20
    arc_0_3_20  connected_order_arc_501  -14
    arc_0_3_20  out_degree_768  1
    arc_0_3_20  in_degree_832  1
    arc_0_3_20  original_T_including_depot_unload_841  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_500  1
    load_0_3_20  segment_load_conservation_772  1
    load_0_3_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_502  -20
    arc_0_4_0  depot_return_or_bypass_753  1
    arc_0_4_0  out_degree_775  1
    arc_0_4_0  original_T_including_depot_unload_841  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_502  1
    load_0_4_0  segment_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_503  -20
    arc_0_4_1  connected_order_arc_504  -14
    arc_0_4_1  in_degree_755  1
    arc_0_4_1  out_degree_775  1
    arc_0_4_1  original_T_including_depot_unload_841  628.141943094385
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_503  1
    load_0_4_1  segment_load_conservation_758  -1
    load_0_4_1  segment_prefix_lb_759  1
    load_0_4_1  segment_prefix_ub_760  1
    load_0_4_1  segment_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_505  -20
    arc_0_4_2  connected_order_arc_506  -14
    arc_0_4_2  in_degree_762  1
    arc_0_4_2  out_degree_775  1
    arc_0_4_2  original_T_including_depot_unload_841  3.1069481377857926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_505  1
    load_0_4_2  segment_load_conservation_765  -1
    load_0_4_2  segment_prefix_lb_766  1
    load_0_4_2  segment_prefix_ub_767  1
    load_0_4_2  segment_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_507  -20
    arc_0_4_3  connected_order_arc_508  -14
    arc_0_4_3  in_degree_769  1
    arc_0_4_3  out_degree_775  1
    arc_0_4_3  original_T_including_depot_unload_841  2.3649901674897566e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_507  1
    load_0_4_3  segment_load_conservation_772  -1
    load_0_4_3  segment_prefix_lb_773  1
    load_0_4_3  segment_prefix_ub_774  1
    load_0_4_3  segment_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_509  -20
    arc_0_4_5  connected_order_arc_510  -14
    arc_0_4_5  out_degree_775  1
    arc_0_4_5  in_degree_783  1
    arc_0_4_5  original_T_including_depot_unload_841  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_509  1
    load_0_4_5  segment_load_conservation_779  1
    load_0_4_5  segment_load_conservation_786  -1
    load_0_4_5  segment_prefix_lb_787  1
    load_0_4_5  segment_prefix_ub_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_511  -20
    arc_0_4_13  connected_order_arc_512  -14
    arc_0_4_13  out_degree_775  1
    arc_0_4_13  in_degree_790  1
    arc_0_4_13  original_T_including_depot_unload_841  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_511  1
    load_0_4_13  segment_load_conservation_779  1
    load_0_4_13  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_513  -20
    arc_0_4_14  connected_order_arc_514  -14
    arc_0_4_14  out_degree_775  1
    arc_0_4_14  in_degree_796  1
    arc_0_4_14  original_T_including_depot_unload_841  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_513  1
    load_0_4_14  segment_load_conservation_779  1
    load_0_4_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_515  -20
    arc_0_4_15  connected_order_arc_516  -14
    arc_0_4_15  out_degree_775  1
    arc_0_4_15  in_degree_802  1
    arc_0_4_15  original_T_including_depot_unload_841  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_515  1
    load_0_4_15  segment_load_conservation_779  1
    load_0_4_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_517  -20
    arc_0_4_16  connected_order_arc_518  -14
    arc_0_4_16  out_degree_775  1
    arc_0_4_16  in_degree_808  1
    arc_0_4_16  original_T_including_depot_unload_841  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_517  1
    load_0_4_16  segment_load_conservation_779  1
    load_0_4_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_519  -20
    arc_0_4_17  connected_order_arc_520  -14
    arc_0_4_17  out_degree_775  1
    arc_0_4_17  in_degree_814  1
    arc_0_4_17  original_T_including_depot_unload_841  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_519  1
    load_0_4_17  segment_load_conservation_779  1
    load_0_4_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_521  -20
    arc_0_4_18  connected_order_arc_522  -14
    arc_0_4_18  out_degree_775  1
    arc_0_4_18  in_degree_820  1
    arc_0_4_18  original_T_including_depot_unload_841  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_521  1
    load_0_4_18  segment_load_conservation_779  1
    load_0_4_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_523  -20
    arc_0_4_19  connected_order_arc_524  -14
    arc_0_4_19  out_degree_775  1
    arc_0_4_19  in_degree_826  1
    arc_0_4_19  original_T_including_depot_unload_841  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_523  1
    load_0_4_19  segment_load_conservation_779  1
    load_0_4_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_525  -20
    arc_0_4_20  connected_order_arc_526  -14
    arc_0_4_20  out_degree_775  1
    arc_0_4_20  in_degree_832  1
    arc_0_4_20  original_T_including_depot_unload_841  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_525  1
    load_0_4_20  segment_load_conservation_779  1
    load_0_4_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_527  -20
    arc_0_5_0  depot_return_or_bypass_753  1
    arc_0_5_0  out_degree_782  1
    arc_0_5_0  original_T_including_depot_unload_841  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_527  1
    load_0_5_0  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_528  -20
    arc_0_5_1  connected_order_arc_529  -14
    arc_0_5_1  in_degree_755  1
    arc_0_5_1  out_degree_782  1
    arc_0_5_1  original_T_including_depot_unload_841  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_528  1
    load_0_5_1  segment_load_conservation_758  -1
    load_0_5_1  segment_prefix_lb_759  1
    load_0_5_1  segment_prefix_ub_760  1
    load_0_5_1  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_530  -20
    arc_0_5_2  connected_order_arc_531  -14
    arc_0_5_2  in_degree_762  1
    arc_0_5_2  out_degree_782  1
    arc_0_5_2  original_T_including_depot_unload_841  8.2707974701454475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_530  1
    load_0_5_2  segment_load_conservation_765  -1
    load_0_5_2  segment_prefix_lb_766  1
    load_0_5_2  segment_prefix_ub_767  1
    load_0_5_2  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_532  -20
    arc_0_5_3  connected_order_arc_533  -14
    arc_0_5_3  in_degree_769  1
    arc_0_5_3  out_degree_782  1
    arc_0_5_3  original_T_including_depot_unload_841  6.4542450829473034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_532  1
    load_0_5_3  segment_load_conservation_772  -1
    load_0_5_3  segment_prefix_lb_773  1
    load_0_5_3  segment_prefix_ub_774  1
    load_0_5_3  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_534  -20
    arc_0_5_4  connected_order_arc_535  -14
    arc_0_5_4  in_degree_776  1
    arc_0_5_4  out_degree_782  1
    arc_0_5_4  original_T_including_depot_unload_841  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_534  1
    load_0_5_4  segment_load_conservation_779  -1
    load_0_5_4  segment_prefix_lb_780  1
    load_0_5_4  segment_prefix_ub_781  1
    load_0_5_4  segment_load_conservation_786  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_536  -20
    arc_0_5_13  connected_order_arc_537  -14
    arc_0_5_13  out_degree_782  1
    arc_0_5_13  in_degree_790  1
    arc_0_5_13  original_T_including_depot_unload_841  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_536  1
    load_0_5_13  segment_load_conservation_786  1
    load_0_5_13  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_538  -20
    arc_0_5_14  connected_order_arc_539  -14
    arc_0_5_14  out_degree_782  1
    arc_0_5_14  in_degree_796  1
    arc_0_5_14  original_T_including_depot_unload_841  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_538  1
    load_0_5_14  segment_load_conservation_786  1
    load_0_5_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_540  -20
    arc_0_5_15  connected_order_arc_541  -14
    arc_0_5_15  out_degree_782  1
    arc_0_5_15  in_degree_802  1
    arc_0_5_15  original_T_including_depot_unload_841  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_540  1
    load_0_5_15  segment_load_conservation_786  1
    load_0_5_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_16  arc_capacity_542  -20
    arc_0_5_16  connected_order_arc_543  -14
    arc_0_5_16  out_degree_782  1
    arc_0_5_16  in_degree_808  1
    arc_0_5_16  original_T_including_depot_unload_841  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_16  arc_capacity_542  1
    load_0_5_16  segment_load_conservation_786  1
    load_0_5_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_17  arc_capacity_544  -20
    arc_0_5_17  connected_order_arc_545  -14
    arc_0_5_17  out_degree_782  1
    arc_0_5_17  in_degree_814  1
    arc_0_5_17  original_T_including_depot_unload_841  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_17  arc_capacity_544  1
    load_0_5_17  segment_load_conservation_786  1
    load_0_5_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_18  arc_capacity_546  -20
    arc_0_5_18  connected_order_arc_547  -14
    arc_0_5_18  out_degree_782  1
    arc_0_5_18  in_degree_820  1
    arc_0_5_18  original_T_including_depot_unload_841  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_18  arc_capacity_546  1
    load_0_5_18  segment_load_conservation_786  1
    load_0_5_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_19  arc_capacity_548  -20
    arc_0_5_19  connected_order_arc_549  -14
    arc_0_5_19  out_degree_782  1
    arc_0_5_19  in_degree_826  1
    arc_0_5_19  original_T_including_depot_unload_841  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_19  arc_capacity_548  1
    load_0_5_19  segment_load_conservation_786  1
    load_0_5_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_20  arc_capacity_550  -20
    arc_0_5_20  connected_order_arc_551  -14
    arc_0_5_20  out_degree_782  1
    arc_0_5_20  in_degree_832  1
    arc_0_5_20  original_T_including_depot_unload_841  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_20  arc_capacity_550  1
    load_0_5_20  segment_load_conservation_786  1
    load_0_5_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_552  -20
    arc_0_13_0  depot_return_or_bypass_753  1
    arc_0_13_0  out_degree_789  1
    arc_0_13_0  original_T_including_depot_unload_841  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_552  1
    load_0_13_0  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_553  -20
    arc_0_13_1  connected_order_arc_554  -14
    arc_0_13_1  in_degree_755  1
    arc_0_13_1  out_degree_789  1
    arc_0_13_1  original_T_including_depot_unload_841  4.3618991857210159e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_553  1
    load_0_13_1  segment_load_conservation_758  -1
    load_0_13_1  segment_prefix_lb_759  1
    load_0_13_1  segment_prefix_ub_760  1
    load_0_13_1  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_555  -20
    arc_0_13_2  connected_order_arc_556  -14
    arc_0_13_2  in_degree_762  1
    arc_0_13_2  out_degree_789  1
    arc_0_13_2  original_T_including_depot_unload_841  6.2886632383683013e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_555  1
    load_0_13_2  segment_load_conservation_765  -1
    load_0_13_2  segment_prefix_lb_766  1
    load_0_13_2  segment_prefix_ub_767  1
    load_0_13_2  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_557  -20
    arc_0_13_3  connected_order_arc_558  -14
    arc_0_13_3  in_degree_769  1
    arc_0_13_3  out_degree_789  1
    arc_0_13_3  original_T_including_depot_unload_841  3.8790073962518773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_557  1
    load_0_13_3  segment_load_conservation_772  -1
    load_0_13_3  segment_prefix_lb_773  1
    load_0_13_3  segment_prefix_ub_774  1
    load_0_13_3  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_559  -20
    arc_0_13_4  connected_order_arc_560  -14
    arc_0_13_4  in_degree_776  1
    arc_0_13_4  out_degree_789  1
    arc_0_13_4  original_T_including_depot_unload_841  4.7597588586788925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_559  1
    load_0_13_4  segment_load_conservation_779  -1
    load_0_13_4  segment_prefix_lb_780  1
    load_0_13_4  segment_prefix_ub_781  1
    load_0_13_4  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_561  -20
    arc_0_13_5  connected_order_arc_562  -14
    arc_0_13_5  in_degree_783  1
    arc_0_13_5  out_degree_789  1
    arc_0_13_5  original_T_including_depot_unload_841  4.6276703023336785e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_561  1
    load_0_13_5  segment_load_conservation_786  -1
    load_0_13_5  segment_prefix_lb_787  1
    load_0_13_5  segment_prefix_ub_788  1
    load_0_13_5  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_563  -20
    arc_0_13_14  connected_order_arc_564  -14
    arc_0_13_14  out_degree_789  1
    arc_0_13_14  in_degree_796  1
    arc_0_13_14  original_T_including_depot_unload_841  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_563  1
    load_0_13_14  free_load_conservation_794  1
    load_0_13_14  free_load_conservation_800  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_565  -20
    arc_0_13_15  connected_order_arc_566  -14
    arc_0_13_15  out_degree_789  1
    arc_0_13_15  in_degree_802  1
    arc_0_13_15  original_T_including_depot_unload_841  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_565  1
    load_0_13_15  free_load_conservation_794  1
    load_0_13_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_567  -20
    arc_0_13_16  connected_order_arc_568  -14
    arc_0_13_16  out_degree_789  1
    arc_0_13_16  in_degree_808  1
    arc_0_13_16  original_T_including_depot_unload_841  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_567  1
    load_0_13_16  free_load_conservation_794  1
    load_0_13_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_569  -20
    arc_0_13_17  connected_order_arc_570  -14
    arc_0_13_17  out_degree_789  1
    arc_0_13_17  in_degree_814  1
    arc_0_13_17  original_T_including_depot_unload_841  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_569  1
    load_0_13_17  free_load_conservation_794  1
    load_0_13_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_571  -20
    arc_0_13_18  connected_order_arc_572  -14
    arc_0_13_18  out_degree_789  1
    arc_0_13_18  in_degree_820  1
    arc_0_13_18  original_T_including_depot_unload_841  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_571  1
    load_0_13_18  free_load_conservation_794  1
    load_0_13_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_573  -20
    arc_0_13_19  connected_order_arc_574  -14
    arc_0_13_19  out_degree_789  1
    arc_0_13_19  in_degree_826  1
    arc_0_13_19  original_T_including_depot_unload_841  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_573  1
    load_0_13_19  free_load_conservation_794  1
    load_0_13_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_20  arc_capacity_575  -20
    arc_0_13_20  connected_order_arc_576  -14
    arc_0_13_20  out_degree_789  1
    arc_0_13_20  in_degree_832  1
    arc_0_13_20  original_T_including_depot_unload_841  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_0_13_20  arc_capacity_575  1
    load_0_13_20  free_load_conservation_794  1
    load_0_13_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_577  -20
    arc_0_14_0  depot_return_or_bypass_753  1
    arc_0_14_0  out_degree_795  1
    arc_0_14_0  original_T_including_depot_unload_841  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_577  1
    load_0_14_0  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_578  -20
    arc_0_14_1  connected_order_arc_579  -14
    arc_0_14_1  in_degree_755  1
    arc_0_14_1  out_degree_795  1
    arc_0_14_1  original_T_including_depot_unload_841  4.2733962838090457e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_578  1
    load_0_14_1  segment_load_conservation_758  -1
    load_0_14_1  segment_prefix_lb_759  1
    load_0_14_1  segment_prefix_ub_760  1
    load_0_14_1  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_580  -20
    arc_0_14_2  connected_order_arc_581  -14
    arc_0_14_2  in_degree_762  1
    arc_0_14_2  out_degree_795  1
    arc_0_14_2  original_T_including_depot_unload_841  3.9864800790786632e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_580  1
    load_0_14_2  segment_load_conservation_765  -1
    load_0_14_2  segment_prefix_lb_766  1
    load_0_14_2  segment_prefix_ub_767  1
    load_0_14_2  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_582  -20
    arc_0_14_3  connected_order_arc_583  -14
    arc_0_14_3  in_degree_769  1
    arc_0_14_3  out_degree_795  1
    arc_0_14_3  original_T_including_depot_unload_841  1.6597164064313077e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_582  1
    load_0_14_3  segment_load_conservation_772  -1
    load_0_14_3  segment_prefix_lb_773  1
    load_0_14_3  segment_prefix_ub_774  1
    load_0_14_3  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_584  -20
    arc_0_14_4  connected_order_arc_585  -14
    arc_0_14_4  in_degree_776  1
    arc_0_14_4  out_degree_795  1
    arc_0_14_4  original_T_including_depot_unload_841  2.5147997402163108e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_584  1
    load_0_14_4  segment_load_conservation_779  -1
    load_0_14_4  segment_prefix_lb_780  1
    load_0_14_4  segment_prefix_ub_781  1
    load_0_14_4  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_586  -20
    arc_0_14_5  connected_order_arc_587  -14
    arc_0_14_5  in_degree_783  1
    arc_0_14_5  out_degree_795  1
    arc_0_14_5  original_T_including_depot_unload_841  4.9831220386775891e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_586  1
    load_0_14_5  segment_load_conservation_786  -1
    load_0_14_5  segment_prefix_lb_787  1
    load_0_14_5  segment_prefix_ub_788  1
    load_0_14_5  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_588  -20
    arc_0_14_13  connected_order_arc_589  -14
    arc_0_14_13  in_degree_790  1
    arc_0_14_13  out_degree_795  1
    arc_0_14_13  original_T_including_depot_unload_841  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_588  1
    load_0_14_13  free_load_conservation_794  -1
    load_0_14_13  free_load_conservation_800  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_590  -20
    arc_0_14_15  connected_order_arc_591  -14
    arc_0_14_15  out_degree_795  1
    arc_0_14_15  in_degree_802  1
    arc_0_14_15  original_T_including_depot_unload_841  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_590  1
    load_0_14_15  free_load_conservation_800  1
    load_0_14_15  free_load_conservation_806  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_592  -20
    arc_0_14_16  connected_order_arc_593  -14
    arc_0_14_16  out_degree_795  1
    arc_0_14_16  in_degree_808  1
    arc_0_14_16  original_T_including_depot_unload_841  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_592  1
    load_0_14_16  free_load_conservation_800  1
    load_0_14_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_594  -20
    arc_0_14_17  connected_order_arc_595  -14
    arc_0_14_17  out_degree_795  1
    arc_0_14_17  in_degree_814  1
    arc_0_14_17  original_T_including_depot_unload_841  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_594  1
    load_0_14_17  free_load_conservation_800  1
    load_0_14_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_596  -20
    arc_0_14_18  connected_order_arc_597  -14
    arc_0_14_18  out_degree_795  1
    arc_0_14_18  in_degree_820  1
    arc_0_14_18  original_T_including_depot_unload_841  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_596  1
    load_0_14_18  free_load_conservation_800  1
    load_0_14_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_598  -20
    arc_0_14_19  connected_order_arc_599  -14
    arc_0_14_19  out_degree_795  1
    arc_0_14_19  in_degree_826  1
    arc_0_14_19  original_T_including_depot_unload_841  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_598  1
    load_0_14_19  free_load_conservation_800  1
    load_0_14_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_600  -20
    arc_0_14_20  connected_order_arc_601  -14
    arc_0_14_20  out_degree_795  1
    arc_0_14_20  in_degree_832  1
    arc_0_14_20  original_T_including_depot_unload_841  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_600  1
    load_0_14_20  free_load_conservation_800  1
    load_0_14_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_602  -20
    arc_0_15_0  depot_return_or_bypass_753  1
    arc_0_15_0  out_degree_801  1
    arc_0_15_0  original_T_including_depot_unload_841  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_602  1
    load_0_15_0  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_603  -20
    arc_0_15_1  connected_order_arc_604  -14
    arc_0_15_1  in_degree_755  1
    arc_0_15_1  out_degree_801  1
    arc_0_15_1  original_T_including_depot_unload_841  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_603  1
    load_0_15_1  segment_load_conservation_758  -1
    load_0_15_1  segment_prefix_lb_759  1
    load_0_15_1  segment_prefix_ub_760  1
    load_0_15_1  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_605  -20
    arc_0_15_2  connected_order_arc_606  -14
    arc_0_15_2  in_degree_762  1
    arc_0_15_2  out_degree_801  1
    arc_0_15_2  original_T_including_depot_unload_841  1.7728207593496934e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_605  1
    load_0_15_2  segment_load_conservation_765  -1
    load_0_15_2  segment_prefix_lb_766  1
    load_0_15_2  segment_prefix_ub_767  1
    load_0_15_2  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_607  -20
    arc_0_15_3  connected_order_arc_608  -14
    arc_0_15_3  in_degree_769  1
    arc_0_15_3  out_degree_801  1
    arc_0_15_3  original_T_including_depot_unload_841  1.5352632777598149e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_607  1
    load_0_15_3  segment_load_conservation_772  -1
    load_0_15_3  segment_prefix_lb_773  1
    load_0_15_3  segment_prefix_ub_774  1
    load_0_15_3  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_609  -20
    arc_0_15_4  connected_order_arc_610  -14
    arc_0_15_4  in_degree_776  1
    arc_0_15_4  out_degree_801  1
    arc_0_15_4  original_T_including_depot_unload_841  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_609  1
    load_0_15_4  segment_load_conservation_779  -1
    load_0_15_4  segment_prefix_lb_780  1
    load_0_15_4  segment_prefix_ub_781  1
    load_0_15_4  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_611  -20
    arc_0_15_5  connected_order_arc_612  -14
    arc_0_15_5  in_degree_783  1
    arc_0_15_5  out_degree_801  1
    arc_0_15_5  original_T_including_depot_unload_841  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_611  1
    load_0_15_5  segment_load_conservation_786  -1
    load_0_15_5  segment_prefix_lb_787  1
    load_0_15_5  segment_prefix_ub_788  1
    load_0_15_5  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_613  -20
    arc_0_15_13  connected_order_arc_614  -14
    arc_0_15_13  in_degree_790  1
    arc_0_15_13  out_degree_801  1
    arc_0_15_13  original_T_including_depot_unload_841  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_613  1
    load_0_15_13  free_load_conservation_794  -1
    load_0_15_13  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_615  -20
    arc_0_15_14  connected_order_arc_616  -14
    arc_0_15_14  in_degree_796  1
    arc_0_15_14  out_degree_801  1
    arc_0_15_14  original_T_including_depot_unload_841  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_615  1
    load_0_15_14  free_load_conservation_800  -1
    load_0_15_14  free_load_conservation_806  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_617  -20
    arc_0_15_16  connected_order_arc_618  -14
    arc_0_15_16  out_degree_801  1
    arc_0_15_16  in_degree_808  1
    arc_0_15_16  original_T_including_depot_unload_841  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_617  1
    load_0_15_16  free_load_conservation_806  1
    load_0_15_16  free_load_conservation_812  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_619  -20
    arc_0_15_17  connected_order_arc_620  -14
    arc_0_15_17  out_degree_801  1
    arc_0_15_17  in_degree_814  1
    arc_0_15_17  original_T_including_depot_unload_841  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_619  1
    load_0_15_17  free_load_conservation_806  1
    load_0_15_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_621  -20
    arc_0_15_18  connected_order_arc_622  -14
    arc_0_15_18  out_degree_801  1
    arc_0_15_18  in_degree_820  1
    arc_0_15_18  original_T_including_depot_unload_841  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_621  1
    load_0_15_18  free_load_conservation_806  1
    load_0_15_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_623  -20
    arc_0_15_19  connected_order_arc_624  -14
    arc_0_15_19  out_degree_801  1
    arc_0_15_19  in_degree_826  1
    arc_0_15_19  original_T_including_depot_unload_841  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_623  1
    load_0_15_19  free_load_conservation_806  1
    load_0_15_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_625  -20
    arc_0_15_20  connected_order_arc_626  -14
    arc_0_15_20  out_degree_801  1
    arc_0_15_20  in_degree_832  1
    arc_0_15_20  original_T_including_depot_unload_841  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_625  1
    load_0_15_20  free_load_conservation_806  1
    load_0_15_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_627  -20
    arc_0_16_0  depot_return_or_bypass_753  1
    arc_0_16_0  out_degree_807  1
    arc_0_16_0  original_T_including_depot_unload_841  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_627  1
    load_0_16_0  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_628  -20
    arc_0_16_1  connected_order_arc_629  -14
    arc_0_16_1  in_degree_755  1
    arc_0_16_1  out_degree_807  1
    arc_0_16_1  original_T_including_depot_unload_841  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_628  1
    load_0_16_1  segment_load_conservation_758  -1
    load_0_16_1  segment_prefix_lb_759  1
    load_0_16_1  segment_prefix_ub_760  1
    load_0_16_1  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_630  -20
    arc_0_16_2  connected_order_arc_631  -14
    arc_0_16_2  in_degree_762  1
    arc_0_16_2  out_degree_807  1
    arc_0_16_2  original_T_including_depot_unload_841  8.1289340937717509e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_630  1
    load_0_16_2  segment_load_conservation_765  -1
    load_0_16_2  segment_prefix_lb_766  1
    load_0_16_2  segment_prefix_ub_767  1
    load_0_16_2  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_632  -20
    arc_0_16_3  connected_order_arc_633  -14
    arc_0_16_3  in_degree_769  1
    arc_0_16_3  out_degree_807  1
    arc_0_16_3  original_T_including_depot_unload_841  5.8212369880329140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_632  1
    load_0_16_3  segment_load_conservation_772  -1
    load_0_16_3  segment_prefix_lb_773  1
    load_0_16_3  segment_prefix_ub_774  1
    load_0_16_3  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_634  -20
    arc_0_16_4  connected_order_arc_635  -14
    arc_0_16_4  in_degree_776  1
    arc_0_16_4  out_degree_807  1
    arc_0_16_4  original_T_including_depot_unload_841  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_634  1
    load_0_16_4  segment_load_conservation_779  -1
    load_0_16_4  segment_prefix_lb_780  1
    load_0_16_4  segment_prefix_ub_781  1
    load_0_16_4  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_5  arc_capacity_636  -20
    arc_0_16_5  connected_order_arc_637  -14
    arc_0_16_5  in_degree_783  1
    arc_0_16_5  out_degree_807  1
    arc_0_16_5  original_T_including_depot_unload_841  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_5  arc_capacity_636  1
    load_0_16_5  segment_load_conservation_786  -1
    load_0_16_5  segment_prefix_lb_787  1
    load_0_16_5  segment_prefix_ub_788  1
    load_0_16_5  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_638  -20
    arc_0_16_13  connected_order_arc_639  -14
    arc_0_16_13  in_degree_790  1
    arc_0_16_13  out_degree_807  1
    arc_0_16_13  original_T_including_depot_unload_841  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_638  1
    load_0_16_13  free_load_conservation_794  -1
    load_0_16_13  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_640  -20
    arc_0_16_14  connected_order_arc_641  -14
    arc_0_16_14  in_degree_796  1
    arc_0_16_14  out_degree_807  1
    arc_0_16_14  original_T_including_depot_unload_841  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_640  1
    load_0_16_14  free_load_conservation_800  -1
    load_0_16_14  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_642  -20
    arc_0_16_15  connected_order_arc_643  -14
    arc_0_16_15  in_degree_802  1
    arc_0_16_15  out_degree_807  1
    arc_0_16_15  original_T_including_depot_unload_841  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_642  1
    load_0_16_15  free_load_conservation_806  -1
    load_0_16_15  free_load_conservation_812  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_644  -20
    arc_0_16_17  connected_order_arc_645  -14
    arc_0_16_17  out_degree_807  1
    arc_0_16_17  in_degree_814  1
    arc_0_16_17  original_T_including_depot_unload_841  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_644  1
    load_0_16_17  free_load_conservation_812  1
    load_0_16_17  free_load_conservation_818  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_646  -20
    arc_0_16_18  connected_order_arc_647  -14
    arc_0_16_18  out_degree_807  1
    arc_0_16_18  in_degree_820  1
    arc_0_16_18  original_T_including_depot_unload_841  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_646  1
    load_0_16_18  free_load_conservation_812  1
    load_0_16_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_648  -20
    arc_0_16_19  connected_order_arc_649  -14
    arc_0_16_19  out_degree_807  1
    arc_0_16_19  in_degree_826  1
    arc_0_16_19  original_T_including_depot_unload_841  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_648  1
    load_0_16_19  free_load_conservation_812  1
    load_0_16_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_650  -20
    arc_0_16_20  connected_order_arc_651  -14
    arc_0_16_20  out_degree_807  1
    arc_0_16_20  in_degree_832  1
    arc_0_16_20  original_T_including_depot_unload_841  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_650  1
    load_0_16_20  free_load_conservation_812  1
    load_0_16_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_652  -20
    arc_0_17_0  depot_return_or_bypass_753  1
    arc_0_17_0  out_degree_813  1
    arc_0_17_0  original_T_including_depot_unload_841  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_652  1
    load_0_17_0  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_653  -20
    arc_0_17_1  connected_order_arc_654  -14
    arc_0_17_1  in_degree_755  1
    arc_0_17_1  out_degree_813  1
    arc_0_17_1  original_T_including_depot_unload_841  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_653  1
    load_0_17_1  segment_load_conservation_758  -1
    load_0_17_1  segment_prefix_lb_759  1
    load_0_17_1  segment_prefix_ub_760  1
    load_0_17_1  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_655  -20
    arc_0_17_2  connected_order_arc_656  -14
    arc_0_17_2  in_degree_762  1
    arc_0_17_2  out_degree_813  1
    arc_0_17_2  original_T_including_depot_unload_841  1.5968108380866881e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_655  1
    load_0_17_2  segment_load_conservation_765  -1
    load_0_17_2  segment_prefix_lb_766  1
    load_0_17_2  segment_prefix_ub_767  1
    load_0_17_2  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_657  -20
    arc_0_17_3  connected_order_arc_658  -14
    arc_0_17_3  in_degree_769  1
    arc_0_17_3  out_degree_813  1
    arc_0_17_3  original_T_including_depot_unload_841  1.4150780419437449e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_657  1
    load_0_17_3  segment_load_conservation_772  -1
    load_0_17_3  segment_prefix_lb_773  1
    load_0_17_3  segment_prefix_ub_774  1
    load_0_17_3  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_659  -20
    arc_0_17_4  connected_order_arc_660  -14
    arc_0_17_4  in_degree_776  1
    arc_0_17_4  out_degree_813  1
    arc_0_17_4  original_T_including_depot_unload_841  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_659  1
    load_0_17_4  segment_load_conservation_779  -1
    load_0_17_4  segment_prefix_lb_780  1
    load_0_17_4  segment_prefix_ub_781  1
    load_0_17_4  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_5  arc_capacity_661  -20
    arc_0_17_5  connected_order_arc_662  -14
    arc_0_17_5  in_degree_783  1
    arc_0_17_5  out_degree_813  1
    arc_0_17_5  original_T_including_depot_unload_841  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_5  arc_capacity_661  1
    load_0_17_5  segment_load_conservation_786  -1
    load_0_17_5  segment_prefix_lb_787  1
    load_0_17_5  segment_prefix_ub_788  1
    load_0_17_5  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_663  -20
    arc_0_17_13  connected_order_arc_664  -14
    arc_0_17_13  in_degree_790  1
    arc_0_17_13  out_degree_813  1
    arc_0_17_13  original_T_including_depot_unload_841  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_663  1
    load_0_17_13  free_load_conservation_794  -1
    load_0_17_13  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_665  -20
    arc_0_17_14  connected_order_arc_666  -14
    arc_0_17_14  in_degree_796  1
    arc_0_17_14  out_degree_813  1
    arc_0_17_14  original_T_including_depot_unload_841  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_665  1
    load_0_17_14  free_load_conservation_800  -1
    load_0_17_14  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_667  -20
    arc_0_17_15  connected_order_arc_668  -14
    arc_0_17_15  in_degree_802  1
    arc_0_17_15  out_degree_813  1
    arc_0_17_15  original_T_including_depot_unload_841  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_667  1
    load_0_17_15  free_load_conservation_806  -1
    load_0_17_15  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_669  -20
    arc_0_17_16  connected_order_arc_670  -14
    arc_0_17_16  in_degree_808  1
    arc_0_17_16  out_degree_813  1
    arc_0_17_16  original_T_including_depot_unload_841  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_669  1
    load_0_17_16  free_load_conservation_812  -1
    load_0_17_16  free_load_conservation_818  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_671  -20
    arc_0_17_18  connected_order_arc_672  -14
    arc_0_17_18  out_degree_813  1
    arc_0_17_18  in_degree_820  1
    arc_0_17_18  original_T_including_depot_unload_841  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_671  1
    load_0_17_18  free_load_conservation_818  1
    load_0_17_18  free_load_conservation_824  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_673  -20
    arc_0_17_19  connected_order_arc_674  -14
    arc_0_17_19  out_degree_813  1
    arc_0_17_19  in_degree_826  1
    arc_0_17_19  original_T_including_depot_unload_841  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_673  1
    load_0_17_19  free_load_conservation_818  1
    load_0_17_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_675  -20
    arc_0_17_20  connected_order_arc_676  -14
    arc_0_17_20  out_degree_813  1
    arc_0_17_20  in_degree_832  1
    arc_0_17_20  original_T_including_depot_unload_841  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_675  1
    load_0_17_20  free_load_conservation_818  1
    load_0_17_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_677  -20
    arc_0_18_0  depot_return_or_bypass_753  1
    arc_0_18_0  out_degree_819  1
    arc_0_18_0  original_T_including_depot_unload_841  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_677  1
    load_0_18_0  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_678  -20
    arc_0_18_1  connected_order_arc_679  -14
    arc_0_18_1  in_degree_755  1
    arc_0_18_1  out_degree_819  1
    arc_0_18_1  original_T_including_depot_unload_841  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_678  1
    load_0_18_1  segment_load_conservation_758  -1
    load_0_18_1  segment_prefix_lb_759  1
    load_0_18_1  segment_prefix_ub_760  1
    load_0_18_1  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_680  -20
    arc_0_18_2  connected_order_arc_681  -14
    arc_0_18_2  in_degree_762  1
    arc_0_18_2  out_degree_819  1
    arc_0_18_2  original_T_including_depot_unload_841  6.1561452832791758e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_680  1
    load_0_18_2  segment_load_conservation_765  -1
    load_0_18_2  segment_prefix_lb_766  1
    load_0_18_2  segment_prefix_ub_767  1
    load_0_18_2  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_682  -20
    arc_0_18_3  connected_order_arc_683  -14
    arc_0_18_3  in_degree_769  1
    arc_0_18_3  out_degree_819  1
    arc_0_18_3  original_T_including_depot_unload_841  4.3129452098285111e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_682  1
    load_0_18_3  segment_load_conservation_772  -1
    load_0_18_3  segment_prefix_lb_773  1
    load_0_18_3  segment_prefix_ub_774  1
    load_0_18_3  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_684  -20
    arc_0_18_4  connected_order_arc_685  -14
    arc_0_18_4  in_degree_776  1
    arc_0_18_4  out_degree_819  1
    arc_0_18_4  original_T_including_depot_unload_841  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_684  1
    load_0_18_4  segment_load_conservation_779  -1
    load_0_18_4  segment_prefix_lb_780  1
    load_0_18_4  segment_prefix_ub_781  1
    load_0_18_4  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_5  arc_capacity_686  -20
    arc_0_18_5  connected_order_arc_687  -14
    arc_0_18_5  in_degree_783  1
    arc_0_18_5  out_degree_819  1
    arc_0_18_5  original_T_including_depot_unload_841  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_5  arc_capacity_686  1
    load_0_18_5  segment_load_conservation_786  -1
    load_0_18_5  segment_prefix_lb_787  1
    load_0_18_5  segment_prefix_ub_788  1
    load_0_18_5  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_688  -20
    arc_0_18_13  connected_order_arc_689  -14
    arc_0_18_13  in_degree_790  1
    arc_0_18_13  out_degree_819  1
    arc_0_18_13  original_T_including_depot_unload_841  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_688  1
    load_0_18_13  free_load_conservation_794  -1
    load_0_18_13  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_690  -20
    arc_0_18_14  connected_order_arc_691  -14
    arc_0_18_14  in_degree_796  1
    arc_0_18_14  out_degree_819  1
    arc_0_18_14  original_T_including_depot_unload_841  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_690  1
    load_0_18_14  free_load_conservation_800  -1
    load_0_18_14  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_692  -20
    arc_0_18_15  connected_order_arc_693  -14
    arc_0_18_15  in_degree_802  1
    arc_0_18_15  out_degree_819  1
    arc_0_18_15  original_T_including_depot_unload_841  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_692  1
    load_0_18_15  free_load_conservation_806  -1
    load_0_18_15  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_694  -20
    arc_0_18_16  connected_order_arc_695  -14
    arc_0_18_16  in_degree_808  1
    arc_0_18_16  out_degree_819  1
    arc_0_18_16  original_T_including_depot_unload_841  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_694  1
    load_0_18_16  free_load_conservation_812  -1
    load_0_18_16  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_696  -20
    arc_0_18_17  connected_order_arc_697  -14
    arc_0_18_17  in_degree_814  1
    arc_0_18_17  out_degree_819  1
    arc_0_18_17  original_T_including_depot_unload_841  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_696  1
    load_0_18_17  free_load_conservation_818  -1
    load_0_18_17  free_load_conservation_824  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_698  -20
    arc_0_18_19  connected_order_arc_699  -14
    arc_0_18_19  out_degree_819  1
    arc_0_18_19  in_degree_826  1
    arc_0_18_19  original_T_including_depot_unload_841  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_698  1
    load_0_18_19  free_load_conservation_824  1
    load_0_18_19  free_load_conservation_830  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_700  -20
    arc_0_18_20  connected_order_arc_701  -14
    arc_0_18_20  out_degree_819  1
    arc_0_18_20  in_degree_832  1
    arc_0_18_20  original_T_including_depot_unload_841  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_700  1
    load_0_18_20  free_load_conservation_824  1
    load_0_18_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_702  -20
    arc_0_19_0  depot_return_or_bypass_753  1
    arc_0_19_0  out_degree_825  1
    arc_0_19_0  original_T_including_depot_unload_841  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_702  1
    load_0_19_0  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_703  -20
    arc_0_19_1  connected_order_arc_704  -14
    arc_0_19_1  in_degree_755  1
    arc_0_19_1  out_degree_825  1
    arc_0_19_1  original_T_including_depot_unload_841  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_703  1
    load_0_19_1  segment_load_conservation_758  -1
    load_0_19_1  segment_prefix_lb_759  1
    load_0_19_1  segment_prefix_ub_760  1
    load_0_19_1  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_705  -20
    arc_0_19_2  connected_order_arc_706  -14
    arc_0_19_2  in_degree_762  1
    arc_0_19_2  out_degree_825  1
    arc_0_19_2  original_T_including_depot_unload_841  1.0038065985492663e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_705  1
    load_0_19_2  segment_load_conservation_765  -1
    load_0_19_2  segment_prefix_lb_766  1
    load_0_19_2  segment_prefix_ub_767  1
    load_0_19_2  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_707  -20
    arc_0_19_3  connected_order_arc_708  -14
    arc_0_19_3  in_degree_769  1
    arc_0_19_3  out_degree_825  1
    arc_0_19_3  original_T_including_depot_unload_841  7.9403551275216375e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_707  1
    load_0_19_3  segment_load_conservation_772  -1
    load_0_19_3  segment_prefix_lb_773  1
    load_0_19_3  segment_prefix_ub_774  1
    load_0_19_3  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_709  -20
    arc_0_19_4  connected_order_arc_710  -14
    arc_0_19_4  in_degree_776  1
    arc_0_19_4  out_degree_825  1
    arc_0_19_4  original_T_including_depot_unload_841  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_709  1
    load_0_19_4  segment_load_conservation_779  -1
    load_0_19_4  segment_prefix_lb_780  1
    load_0_19_4  segment_prefix_ub_781  1
    load_0_19_4  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_5  arc_capacity_711  -20
    arc_0_19_5  connected_order_arc_712  -14
    arc_0_19_5  in_degree_783  1
    arc_0_19_5  out_degree_825  1
    arc_0_19_5  original_T_including_depot_unload_841  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_5  arc_capacity_711  1
    load_0_19_5  segment_load_conservation_786  -1
    load_0_19_5  segment_prefix_lb_787  1
    load_0_19_5  segment_prefix_ub_788  1
    load_0_19_5  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_713  -20
    arc_0_19_13  connected_order_arc_714  -14
    arc_0_19_13  in_degree_790  1
    arc_0_19_13  out_degree_825  1
    arc_0_19_13  original_T_including_depot_unload_841  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_713  1
    load_0_19_13  free_load_conservation_794  -1
    load_0_19_13  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_715  -20
    arc_0_19_14  connected_order_arc_716  -14
    arc_0_19_14  in_degree_796  1
    arc_0_19_14  out_degree_825  1
    arc_0_19_14  original_T_including_depot_unload_841  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_715  1
    load_0_19_14  free_load_conservation_800  -1
    load_0_19_14  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_717  -20
    arc_0_19_15  connected_order_arc_718  -14
    arc_0_19_15  in_degree_802  1
    arc_0_19_15  out_degree_825  1
    arc_0_19_15  original_T_including_depot_unload_841  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_717  1
    load_0_19_15  free_load_conservation_806  -1
    load_0_19_15  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_719  -20
    arc_0_19_16  connected_order_arc_720  -14
    arc_0_19_16  in_degree_808  1
    arc_0_19_16  out_degree_825  1
    arc_0_19_16  original_T_including_depot_unload_841  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_719  1
    load_0_19_16  free_load_conservation_812  -1
    load_0_19_16  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_721  -20
    arc_0_19_17  connected_order_arc_722  -14
    arc_0_19_17  in_degree_814  1
    arc_0_19_17  out_degree_825  1
    arc_0_19_17  original_T_including_depot_unload_841  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_721  1
    load_0_19_17  free_load_conservation_818  -1
    load_0_19_17  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_723  -20
    arc_0_19_18  connected_order_arc_724  -14
    arc_0_19_18  in_degree_820  1
    arc_0_19_18  out_degree_825  1
    arc_0_19_18  original_T_including_depot_unload_841  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_723  1
    load_0_19_18  free_load_conservation_824  -1
    load_0_19_18  free_load_conservation_830  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_725  -20
    arc_0_19_20  connected_order_arc_726  -14
    arc_0_19_20  out_degree_825  1
    arc_0_19_20  in_degree_832  1
    arc_0_19_20  original_T_including_depot_unload_841  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_725  1
    load_0_19_20  free_load_conservation_830  1
    load_0_19_20  free_load_conservation_836  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_727  -20
    arc_0_20_0  depot_return_or_bypass_753  1
    arc_0_20_0  out_degree_831  1
    arc_0_20_0  original_T_including_depot_unload_841  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_727  1
    load_0_20_0  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_728  -20
    arc_0_20_1  connected_order_arc_729  -14
    arc_0_20_1  in_degree_755  1
    arc_0_20_1  out_degree_831  1
    arc_0_20_1  original_T_including_depot_unload_841  3.6658228437834981e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_728  1
    load_0_20_1  segment_load_conservation_758  -1
    load_0_20_1  segment_prefix_lb_759  1
    load_0_20_1  segment_prefix_ub_760  1
    load_0_20_1  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_730  -20
    arc_0_20_2  connected_order_arc_731  -14
    arc_0_20_2  in_degree_762  1
    arc_0_20_2  out_degree_831  1
    arc_0_20_2  original_T_including_depot_unload_841  8.3393751072629220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_730  1
    load_0_20_2  segment_load_conservation_765  -1
    load_0_20_2  segment_prefix_lb_766  1
    load_0_20_2  segment_prefix_ub_767  1
    load_0_20_2  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_732  -20
    arc_0_20_3  connected_order_arc_733  -14
    arc_0_20_3  in_degree_769  1
    arc_0_20_3  out_degree_831  1
    arc_0_20_3  original_T_including_depot_unload_841  6.1704611580490348e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_732  1
    load_0_20_3  segment_load_conservation_772  -1
    load_0_20_3  segment_prefix_lb_773  1
    load_0_20_3  segment_prefix_ub_774  1
    load_0_20_3  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_734  -20
    arc_0_20_4  connected_order_arc_735  -14
    arc_0_20_4  in_degree_776  1
    arc_0_20_4  out_degree_831  1
    arc_0_20_4  original_T_including_depot_unload_841  7.8830763320343567e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_734  1
    load_0_20_4  segment_load_conservation_779  -1
    load_0_20_4  segment_prefix_lb_780  1
    load_0_20_4  segment_prefix_ub_781  1
    load_0_20_4  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_5  arc_capacity_736  -20
    arc_0_20_5  connected_order_arc_737  -14
    arc_0_20_5  in_degree_783  1
    arc_0_20_5  out_degree_831  1
    arc_0_20_5  original_T_including_depot_unload_841  7.9613989083692911e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_5  arc_capacity_736  1
    load_0_20_5  segment_load_conservation_786  -1
    load_0_20_5  segment_prefix_lb_787  1
    load_0_20_5  segment_prefix_ub_788  1
    load_0_20_5  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_13  arc_capacity_738  -20
    arc_0_20_13  connected_order_arc_739  -14
    arc_0_20_13  in_degree_790  1
    arc_0_20_13  out_degree_831  1
    arc_0_20_13  original_T_including_depot_unload_841  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_0_20_13  arc_capacity_738  1
    load_0_20_13  free_load_conservation_794  -1
    load_0_20_13  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_740  -20
    arc_0_20_14  connected_order_arc_741  -14
    arc_0_20_14  in_degree_796  1
    arc_0_20_14  out_degree_831  1
    arc_0_20_14  original_T_including_depot_unload_841  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_740  1
    load_0_20_14  free_load_conservation_800  -1
    load_0_20_14  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_742  -20
    arc_0_20_15  connected_order_arc_743  -14
    arc_0_20_15  in_degree_802  1
    arc_0_20_15  out_degree_831  1
    arc_0_20_15  original_T_including_depot_unload_841  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_742  1
    load_0_20_15  free_load_conservation_806  -1
    load_0_20_15  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_744  -20
    arc_0_20_16  connected_order_arc_745  -14
    arc_0_20_16  in_degree_808  1
    arc_0_20_16  out_degree_831  1
    arc_0_20_16  original_T_including_depot_unload_841  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_744  1
    load_0_20_16  free_load_conservation_812  -1
    load_0_20_16  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_746  -20
    arc_0_20_17  connected_order_arc_747  -14
    arc_0_20_17  in_degree_814  1
    arc_0_20_17  out_degree_831  1
    arc_0_20_17  original_T_including_depot_unload_841  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_746  1
    load_0_20_17  free_load_conservation_818  -1
    load_0_20_17  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_748  -20
    arc_0_20_18  connected_order_arc_749  -14
    arc_0_20_18  in_degree_820  1
    arc_0_20_18  out_degree_831  1
    arc_0_20_18  original_T_including_depot_unload_841  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_748  1
    load_0_20_18  free_load_conservation_824  -1
    load_0_20_18  free_load_conservation_836  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_750  -20
    arc_0_20_19  connected_order_arc_751  -14
    arc_0_20_19  in_degree_826  1
    arc_0_20_19  out_degree_831  1
    arc_0_20_19  original_T_including_depot_unload_841  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_750  1
    load_0_20_19  free_load_conservation_830  -1
    load_0_20_19  free_load_conservation_836  1
    visit_1_6  out_degree_1133  -1
    visit_1_6  in_degree_1134  -1
    visit_1_6  order_active_lb_1135  -1
    visit_1_6  order_active_ub_1136  -12
    order_1_6  connected_order_arc_857  -1
    order_1_6  connected_order_arc_859  -1
    order_1_6  connected_order_arc_861  -1
    order_1_6  connected_order_arc_863  -1
    order_1_6  connected_order_arc_865  -1
    order_1_6  connected_order_arc_867  -1
    order_1_6  connected_order_arc_869  -1
    order_1_6  connected_order_arc_871  -1
    order_1_6  connected_order_arc_873  -1
    order_1_6  connected_order_arc_875  -1
    order_1_6  connected_order_arc_877  -1
    order_1_6  connected_order_arc_880  1
    order_1_6  connected_order_arc_903  1
    order_1_6  connected_order_arc_926  1
    order_1_6  connected_order_arc_949  1
    order_1_6  connected_order_arc_972  1
    order_1_6  connected_order_arc_995  1
    order_1_6  connected_order_arc_1018  1
    order_1_6  connected_order_arc_1041  1
    order_1_6  connected_order_arc_1064  1
    order_1_6  connected_order_arc_1087  1
    order_1_6  connected_order_arc_1110  1
    order_1_6  order_active_lb_1135  1
    order_1_6  order_active_ub_1136  1
    order_1_6  fixed_segment_relative_order_1209  -1
    visit_1_7  out_degree_1140  -1
    visit_1_7  in_degree_1141  -1
    visit_1_7  order_active_lb_1142  -1
    visit_1_7  order_active_ub_1143  -12
    order_1_7  connected_order_arc_857  1
    order_1_7  connected_order_arc_880  -1
    order_1_7  connected_order_arc_882  -1
    order_1_7  connected_order_arc_884  -1
    order_1_7  connected_order_arc_886  -1
    order_1_7  connected_order_arc_888  -1
    order_1_7  connected_order_arc_890  -1
    order_1_7  connected_order_arc_892  -1
    order_1_7  connected_order_arc_894  -1
    order_1_7  connected_order_arc_896  -1
    order_1_7  connected_order_arc_898  -1
    order_1_7  connected_order_arc_900  -1
    order_1_7  connected_order_arc_905  1
    order_1_7  connected_order_arc_928  1
    order_1_7  connected_order_arc_951  1
    order_1_7  connected_order_arc_974  1
    order_1_7  connected_order_arc_997  1
    order_1_7  connected_order_arc_1020  1
    order_1_7  connected_order_arc_1043  1
    order_1_7  connected_order_arc_1066  1
    order_1_7  connected_order_arc_1089  1
    order_1_7  connected_order_arc_1112  1
    order_1_7  order_active_lb_1142  1
    order_1_7  order_active_ub_1143  1
    order_1_7  fixed_segment_relative_order_1209  1
    order_1_7  fixed_segment_relative_order_1210  -1
    visit_1_8  out_degree_1147  -1
    visit_1_8  in_degree_1148  -1
    visit_1_8  order_active_lb_1149  -1
    visit_1_8  order_active_ub_1150  -12
    order_1_8  connected_order_arc_859  1
    order_1_8  connected_order_arc_882  1
    order_1_8  connected_order_arc_903  -1
    order_1_8  connected_order_arc_905  -1
    order_1_8  connected_order_arc_907  -1
    order_1_8  connected_order_arc_909  -1
    order_1_8  connected_order_arc_911  -1
    order_1_8  connected_order_arc_913  -1
    order_1_8  connected_order_arc_915  -1
    order_1_8  connected_order_arc_917  -1
    order_1_8  connected_order_arc_919  -1
    order_1_8  connected_order_arc_921  -1
    order_1_8  connected_order_arc_923  -1
    order_1_8  connected_order_arc_930  1
    order_1_8  connected_order_arc_953  1
    order_1_8  connected_order_arc_976  1
    order_1_8  connected_order_arc_999  1
    order_1_8  connected_order_arc_1022  1
    order_1_8  connected_order_arc_1045  1
    order_1_8  connected_order_arc_1068  1
    order_1_8  connected_order_arc_1091  1
    order_1_8  connected_order_arc_1114  1
    order_1_8  order_active_lb_1149  1
    order_1_8  order_active_ub_1150  1
    order_1_8  fixed_segment_relative_order_1210  1
    order_1_8  fixed_segment_relative_order_1211  -1
    visit_1_9  out_degree_1154  -1
    visit_1_9  in_degree_1155  -1
    visit_1_9  order_active_lb_1156  -1
    visit_1_9  order_active_ub_1157  -12
    order_1_9  connected_order_arc_861  1
    order_1_9  connected_order_arc_884  1
    order_1_9  connected_order_arc_907  1
    order_1_9  connected_order_arc_926  -1
    order_1_9  connected_order_arc_928  -1
    order_1_9  connected_order_arc_930  -1
    order_1_9  connected_order_arc_932  -1
    order_1_9  connected_order_arc_934  -1
    order_1_9  connected_order_arc_936  -1
    order_1_9  connected_order_arc_938  -1
    order_1_9  connected_order_arc_940  -1
    order_1_9  connected_order_arc_942  -1
    order_1_9  connected_order_arc_944  -1
    order_1_9  connected_order_arc_946  -1
    order_1_9  connected_order_arc_955  1
    order_1_9  connected_order_arc_978  1
    order_1_9  connected_order_arc_1001  1
    order_1_9  connected_order_arc_1024  1
    order_1_9  connected_order_arc_1047  1
    order_1_9  connected_order_arc_1070  1
    order_1_9  connected_order_arc_1093  1
    order_1_9  connected_order_arc_1116  1
    order_1_9  order_active_lb_1156  1
    order_1_9  order_active_ub_1157  1
    order_1_9  fixed_segment_relative_order_1211  1
    visit_1_13  out_degree_1161  -1
    visit_1_13  in_degree_1162  -1
    visit_1_13  order_active_lb_1163  -1
    visit_1_13  order_active_ub_1164  -12
    visit_1_13  service_visit_def_1165  -1
    order_1_13  connected_order_arc_863  1
    order_1_13  connected_order_arc_886  1
    order_1_13  connected_order_arc_909  1
    order_1_13  connected_order_arc_932  1
    order_1_13  connected_order_arc_949  -1
    order_1_13  connected_order_arc_951  -1
    order_1_13  connected_order_arc_953  -1
    order_1_13  connected_order_arc_955  -1
    order_1_13  connected_order_arc_957  -1
    order_1_13  connected_order_arc_959  -1
    order_1_13  connected_order_arc_961  -1
    order_1_13  connected_order_arc_963  -1
    order_1_13  connected_order_arc_965  -1
    order_1_13  connected_order_arc_967  -1
    order_1_13  connected_order_arc_969  -1
    order_1_13  connected_order_arc_980  1
    order_1_13  connected_order_arc_1003  1
    order_1_13  connected_order_arc_1026  1
    order_1_13  connected_order_arc_1049  1
    order_1_13  connected_order_arc_1072  1
    order_1_13  connected_order_arc_1095  1
    order_1_13  connected_order_arc_1118  1
    order_1_13  order_active_lb_1163  1
    order_1_13  order_active_ub_1164  1
    visit_1_14  out_degree_1167  -1
    visit_1_14  in_degree_1168  -1
    visit_1_14  order_active_lb_1169  -1
    visit_1_14  order_active_ub_1170  -12
    visit_1_14  service_visit_def_1171  -1
    order_1_14  connected_order_arc_865  1
    order_1_14  connected_order_arc_888  1
    order_1_14  connected_order_arc_911  1
    order_1_14  connected_order_arc_934  1
    order_1_14  connected_order_arc_957  1
    order_1_14  connected_order_arc_972  -1
    order_1_14  connected_order_arc_974  -1
    order_1_14  connected_order_arc_976  -1
    order_1_14  connected_order_arc_978  -1
    order_1_14  connected_order_arc_980  -1
    order_1_14  connected_order_arc_982  -1
    order_1_14  connected_order_arc_984  -1
    order_1_14  connected_order_arc_986  -1
    order_1_14  connected_order_arc_988  -1
    order_1_14  connected_order_arc_990  -1
    order_1_14  connected_order_arc_992  -1
    order_1_14  connected_order_arc_1005  1
    order_1_14  connected_order_arc_1028  1
    order_1_14  connected_order_arc_1051  1
    order_1_14  connected_order_arc_1074  1
    order_1_14  connected_order_arc_1097  1
    order_1_14  connected_order_arc_1120  1
    order_1_14  order_active_lb_1169  1
    order_1_14  order_active_ub_1170  1
    visit_1_15  out_degree_1173  -1
    visit_1_15  in_degree_1174  -1
    visit_1_15  order_active_lb_1175  -1
    visit_1_15  order_active_ub_1176  -12
    visit_1_15  service_visit_def_1177  -1
    order_1_15  connected_order_arc_867  1
    order_1_15  connected_order_arc_890  1
    order_1_15  connected_order_arc_913  1
    order_1_15  connected_order_arc_936  1
    order_1_15  connected_order_arc_959  1
    order_1_15  connected_order_arc_982  1
    order_1_15  connected_order_arc_995  -1
    order_1_15  connected_order_arc_997  -1
    order_1_15  connected_order_arc_999  -1
    order_1_15  connected_order_arc_1001  -1
    order_1_15  connected_order_arc_1003  -1
    order_1_15  connected_order_arc_1005  -1
    order_1_15  connected_order_arc_1007  -1
    order_1_15  connected_order_arc_1009  -1
    order_1_15  connected_order_arc_1011  -1
    order_1_15  connected_order_arc_1013  -1
    order_1_15  connected_order_arc_1015  -1
    order_1_15  connected_order_arc_1030  1
    order_1_15  connected_order_arc_1053  1
    order_1_15  connected_order_arc_1076  1
    order_1_15  connected_order_arc_1099  1
    order_1_15  connected_order_arc_1122  1
    order_1_15  order_active_lb_1175  1
    order_1_15  order_active_ub_1176  1
    visit_1_16  out_degree_1179  -1
    visit_1_16  in_degree_1180  -1
    visit_1_16  order_active_lb_1181  -1
    visit_1_16  order_active_ub_1182  -12
    visit_1_16  service_visit_def_1183  -1
    order_1_16  connected_order_arc_869  1
    order_1_16  connected_order_arc_892  1
    order_1_16  connected_order_arc_915  1
    order_1_16  connected_order_arc_938  1
    order_1_16  connected_order_arc_961  1
    order_1_16  connected_order_arc_984  1
    order_1_16  connected_order_arc_1007  1
    order_1_16  connected_order_arc_1018  -1
    order_1_16  connected_order_arc_1020  -1
    order_1_16  connected_order_arc_1022  -1
    order_1_16  connected_order_arc_1024  -1
    order_1_16  connected_order_arc_1026  -1
    order_1_16  connected_order_arc_1028  -1
    order_1_16  connected_order_arc_1030  -1
    order_1_16  connected_order_arc_1032  -1
    order_1_16  connected_order_arc_1034  -1
    order_1_16  connected_order_arc_1036  -1
    order_1_16  connected_order_arc_1038  -1
    order_1_16  connected_order_arc_1055  1
    order_1_16  connected_order_arc_1078  1
    order_1_16  connected_order_arc_1101  1
    order_1_16  connected_order_arc_1124  1
    order_1_16  order_active_lb_1181  1
    order_1_16  order_active_ub_1182  1
    visit_1_17  out_degree_1185  -1
    visit_1_17  in_degree_1186  -1
    visit_1_17  order_active_lb_1187  -1
    visit_1_17  order_active_ub_1188  -12
    visit_1_17  service_visit_def_1189  -1
    order_1_17  connected_order_arc_871  1
    order_1_17  connected_order_arc_894  1
    order_1_17  connected_order_arc_917  1
    order_1_17  connected_order_arc_940  1
    order_1_17  connected_order_arc_963  1
    order_1_17  connected_order_arc_986  1
    order_1_17  connected_order_arc_1009  1
    order_1_17  connected_order_arc_1032  1
    order_1_17  connected_order_arc_1041  -1
    order_1_17  connected_order_arc_1043  -1
    order_1_17  connected_order_arc_1045  -1
    order_1_17  connected_order_arc_1047  -1
    order_1_17  connected_order_arc_1049  -1
    order_1_17  connected_order_arc_1051  -1
    order_1_17  connected_order_arc_1053  -1
    order_1_17  connected_order_arc_1055  -1
    order_1_17  connected_order_arc_1057  -1
    order_1_17  connected_order_arc_1059  -1
    order_1_17  connected_order_arc_1061  -1
    order_1_17  connected_order_arc_1080  1
    order_1_17  connected_order_arc_1103  1
    order_1_17  connected_order_arc_1126  1
    order_1_17  order_active_lb_1187  1
    order_1_17  order_active_ub_1188  1
    visit_1_18  out_degree_1191  -1
    visit_1_18  in_degree_1192  -1
    visit_1_18  order_active_lb_1193  -1
    visit_1_18  order_active_ub_1194  -12
    visit_1_18  service_visit_def_1195  -1
    order_1_18  connected_order_arc_873  1
    order_1_18  connected_order_arc_896  1
    order_1_18  connected_order_arc_919  1
    order_1_18  connected_order_arc_942  1
    order_1_18  connected_order_arc_965  1
    order_1_18  connected_order_arc_988  1
    order_1_18  connected_order_arc_1011  1
    order_1_18  connected_order_arc_1034  1
    order_1_18  connected_order_arc_1057  1
    order_1_18  connected_order_arc_1064  -1
    order_1_18  connected_order_arc_1066  -1
    order_1_18  connected_order_arc_1068  -1
    order_1_18  connected_order_arc_1070  -1
    order_1_18  connected_order_arc_1072  -1
    order_1_18  connected_order_arc_1074  -1
    order_1_18  connected_order_arc_1076  -1
    order_1_18  connected_order_arc_1078  -1
    order_1_18  connected_order_arc_1080  -1
    order_1_18  connected_order_arc_1082  -1
    order_1_18  connected_order_arc_1084  -1
    order_1_18  connected_order_arc_1105  1
    order_1_18  connected_order_arc_1128  1
    order_1_18  order_active_lb_1193  1
    order_1_18  order_active_ub_1194  1
    visit_1_19  out_degree_1197  -1
    visit_1_19  in_degree_1198  -1
    visit_1_19  order_active_lb_1199  -1
    visit_1_19  order_active_ub_1200  -12
    visit_1_19  service_visit_def_1201  -1
    order_1_19  connected_order_arc_875  1
    order_1_19  connected_order_arc_898  1
    order_1_19  connected_order_arc_921  1
    order_1_19  connected_order_arc_944  1
    order_1_19  connected_order_arc_967  1
    order_1_19  connected_order_arc_990  1
    order_1_19  connected_order_arc_1013  1
    order_1_19  connected_order_arc_1036  1
    order_1_19  connected_order_arc_1059  1
    order_1_19  connected_order_arc_1082  1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1089  -1
    order_1_19  connected_order_arc_1091  -1
    order_1_19  connected_order_arc_1093  -1
    order_1_19  connected_order_arc_1095  -1
    order_1_19  connected_order_arc_1097  -1
    order_1_19  connected_order_arc_1099  -1
    order_1_19  connected_order_arc_1101  -1
    order_1_19  connected_order_arc_1103  -1
    order_1_19  connected_order_arc_1105  -1
    order_1_19  connected_order_arc_1107  -1
    order_1_19  connected_order_arc_1130  1
    order_1_19  order_active_lb_1199  1
    order_1_19  order_active_ub_1200  1
    visit_1_20  out_degree_1203  -1
    visit_1_20  in_degree_1204  -1
    visit_1_20  order_active_lb_1205  -1
    visit_1_20  order_active_ub_1206  -12
    visit_1_20  service_visit_def_1207  -1
    order_1_20  connected_order_arc_877  1
    order_1_20  connected_order_arc_900  1
    order_1_20  connected_order_arc_923  1
    order_1_20  connected_order_arc_946  1
    order_1_20  connected_order_arc_969  1
    order_1_20  connected_order_arc_992  1
    order_1_20  connected_order_arc_1015  1
    order_1_20  connected_order_arc_1038  1
    order_1_20  connected_order_arc_1061  1
    order_1_20  connected_order_arc_1084  1
    order_1_20  connected_order_arc_1107  1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  connected_order_arc_1114  -1
    order_1_20  connected_order_arc_1116  -1
    order_1_20  connected_order_arc_1118  -1
    order_1_20  connected_order_arc_1120  -1
    order_1_20  connected_order_arc_1122  -1
    order_1_20  connected_order_arc_1124  -1
    order_1_20  connected_order_arc_1126  -1
    order_1_20  connected_order_arc_1128  -1
    order_1_20  connected_order_arc_1130  -1
    order_1_20  order_active_lb_1205  1
    order_1_20  order_active_ub_1206  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_842  -25
    arc_1_0_0  depot_departure_or_bypass_1131  1
    arc_1_0_0  depot_return_or_bypass_1132  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_842  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_843  -25
    arc_1_0_6  depot_departure_or_bypass_1131  1
    arc_1_0_6  in_degree_1134  1
    arc_1_0_6  original_T_including_depot_unload_1212  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_843  1
    load_1_0_6  segment_load_conservation_1137  -1
    load_1_0_6  segment_prefix_lb_1138  1
    load_1_0_6  segment_prefix_ub_1139  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_844  -25
    arc_1_0_7  depot_departure_or_bypass_1131  1
    arc_1_0_7  in_degree_1141  1
    arc_1_0_7  original_T_including_depot_unload_1212  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_844  1
    load_1_0_7  segment_load_conservation_1144  -1
    load_1_0_7  segment_prefix_lb_1145  1
    load_1_0_7  segment_prefix_ub_1146  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_845  -25
    arc_1_0_8  depot_departure_or_bypass_1131  1
    arc_1_0_8  in_degree_1148  1
    arc_1_0_8  original_T_including_depot_unload_1212  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_845  1
    load_1_0_8  segment_load_conservation_1151  -1
    load_1_0_8  segment_prefix_lb_1152  1
    load_1_0_8  segment_prefix_ub_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_846  -25
    arc_1_0_9  depot_departure_or_bypass_1131  1
    arc_1_0_9  in_degree_1155  1
    arc_1_0_9  original_T_including_depot_unload_1212  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_846  1
    load_1_0_9  segment_load_conservation_1158  -1
    load_1_0_9  segment_prefix_lb_1159  1
    load_1_0_9  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_847  -25
    arc_1_0_13  depot_departure_or_bypass_1131  1
    arc_1_0_13  in_degree_1162  1
    arc_1_0_13  original_T_including_depot_unload_1212  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_847  1
    load_1_0_13  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_848  -25
    arc_1_0_14  depot_departure_or_bypass_1131  1
    arc_1_0_14  in_degree_1168  1
    arc_1_0_14  original_T_including_depot_unload_1212  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_848  1
    load_1_0_14  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_849  -25
    arc_1_0_15  depot_departure_or_bypass_1131  1
    arc_1_0_15  in_degree_1174  1
    arc_1_0_15  original_T_including_depot_unload_1212  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_849  1
    load_1_0_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_850  -25
    arc_1_0_16  depot_departure_or_bypass_1131  1
    arc_1_0_16  in_degree_1180  1
    arc_1_0_16  original_T_including_depot_unload_1212  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_850  1
    load_1_0_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_851  -25
    arc_1_0_17  depot_departure_or_bypass_1131  1
    arc_1_0_17  in_degree_1186  1
    arc_1_0_17  original_T_including_depot_unload_1212  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_851  1
    load_1_0_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_852  -25
    arc_1_0_18  depot_departure_or_bypass_1131  1
    arc_1_0_18  in_degree_1192  1
    arc_1_0_18  original_T_including_depot_unload_1212  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_852  1
    load_1_0_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_853  -25
    arc_1_0_19  depot_departure_or_bypass_1131  1
    arc_1_0_19  in_degree_1198  1
    arc_1_0_19  original_T_including_depot_unload_1212  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_853  1
    load_1_0_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_854  -25
    arc_1_0_20  depot_departure_or_bypass_1131  1
    arc_1_0_20  in_degree_1204  1
    arc_1_0_20  original_T_including_depot_unload_1212  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_854  1
    load_1_0_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_855  -25
    arc_1_6_0  depot_return_or_bypass_1132  1
    arc_1_6_0  out_degree_1133  1
    arc_1_6_0  original_T_including_depot_unload_1212  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_855  1
    load_1_6_0  segment_load_conservation_1137  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_856  -25
    arc_1_6_7  connected_order_arc_857  -13
    arc_1_6_7  out_degree_1133  1
    arc_1_6_7  in_degree_1141  1
    arc_1_6_7  original_T_including_depot_unload_1212  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_856  1
    load_1_6_7  segment_load_conservation_1137  1
    load_1_6_7  segment_load_conservation_1144  -1
    load_1_6_7  segment_prefix_lb_1145  1
    load_1_6_7  segment_prefix_ub_1146  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_858  -25
    arc_1_6_8  connected_order_arc_859  -13
    arc_1_6_8  out_degree_1133  1
    arc_1_6_8  in_degree_1148  1
    arc_1_6_8  original_T_including_depot_unload_1212  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_858  1
    load_1_6_8  segment_load_conservation_1137  1
    load_1_6_8  segment_load_conservation_1151  -1
    load_1_6_8  segment_prefix_lb_1152  1
    load_1_6_8  segment_prefix_ub_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_860  -25
    arc_1_6_9  connected_order_arc_861  -13
    arc_1_6_9  out_degree_1133  1
    arc_1_6_9  in_degree_1155  1
    arc_1_6_9  original_T_including_depot_unload_1212  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_860  1
    load_1_6_9  segment_load_conservation_1137  1
    load_1_6_9  segment_load_conservation_1158  -1
    load_1_6_9  segment_prefix_lb_1159  1
    load_1_6_9  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_862  -25
    arc_1_6_13  connected_order_arc_863  -13
    arc_1_6_13  out_degree_1133  1
    arc_1_6_13  in_degree_1162  1
    arc_1_6_13  original_T_including_depot_unload_1212  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_862  1
    load_1_6_13  segment_load_conservation_1137  1
    load_1_6_13  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_864  -25
    arc_1_6_14  connected_order_arc_865  -13
    arc_1_6_14  out_degree_1133  1
    arc_1_6_14  in_degree_1168  1
    arc_1_6_14  original_T_including_depot_unload_1212  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_864  1
    load_1_6_14  segment_load_conservation_1137  1
    load_1_6_14  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_866  -25
    arc_1_6_15  connected_order_arc_867  -13
    arc_1_6_15  out_degree_1133  1
    arc_1_6_15  in_degree_1174  1
    arc_1_6_15  original_T_including_depot_unload_1212  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_866  1
    load_1_6_15  segment_load_conservation_1137  1
    load_1_6_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_868  -25
    arc_1_6_16  connected_order_arc_869  -13
    arc_1_6_16  out_degree_1133  1
    arc_1_6_16  in_degree_1180  1
    arc_1_6_16  original_T_including_depot_unload_1212  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_868  1
    load_1_6_16  segment_load_conservation_1137  1
    load_1_6_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_870  -25
    arc_1_6_17  connected_order_arc_871  -13
    arc_1_6_17  out_degree_1133  1
    arc_1_6_17  in_degree_1186  1
    arc_1_6_17  original_T_including_depot_unload_1212  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_870  1
    load_1_6_17  segment_load_conservation_1137  1
    load_1_6_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_872  -25
    arc_1_6_18  connected_order_arc_873  -13
    arc_1_6_18  out_degree_1133  1
    arc_1_6_18  in_degree_1192  1
    arc_1_6_18  original_T_including_depot_unload_1212  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_872  1
    load_1_6_18  segment_load_conservation_1137  1
    load_1_6_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_874  -25
    arc_1_6_19  connected_order_arc_875  -13
    arc_1_6_19  out_degree_1133  1
    arc_1_6_19  in_degree_1198  1
    arc_1_6_19  original_T_including_depot_unload_1212  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_874  1
    load_1_6_19  segment_load_conservation_1137  1
    load_1_6_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_876  -25
    arc_1_6_20  connected_order_arc_877  -13
    arc_1_6_20  out_degree_1133  1
    arc_1_6_20  in_degree_1204  1
    arc_1_6_20  original_T_including_depot_unload_1212  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_876  1
    load_1_6_20  segment_load_conservation_1137  1
    load_1_6_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_878  -25
    arc_1_7_0  depot_return_or_bypass_1132  1
    arc_1_7_0  out_degree_1140  1
    arc_1_7_0  original_T_including_depot_unload_1212  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_878  1
    load_1_7_0  segment_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_879  -25
    arc_1_7_6  connected_order_arc_880  -13
    arc_1_7_6  in_degree_1134  1
    arc_1_7_6  out_degree_1140  1
    arc_1_7_6  original_T_including_depot_unload_1212  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_879  1
    load_1_7_6  segment_load_conservation_1137  -1
    load_1_7_6  segment_prefix_lb_1138  1
    load_1_7_6  segment_prefix_ub_1139  1
    load_1_7_6  segment_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_881  -25
    arc_1_7_8  connected_order_arc_882  -13
    arc_1_7_8  out_degree_1140  1
    arc_1_7_8  in_degree_1148  1
    arc_1_7_8  original_T_including_depot_unload_1212  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_881  1
    load_1_7_8  segment_load_conservation_1144  1
    load_1_7_8  segment_load_conservation_1151  -1
    load_1_7_8  segment_prefix_lb_1152  1
    load_1_7_8  segment_prefix_ub_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_883  -25
    arc_1_7_9  connected_order_arc_884  -13
    arc_1_7_9  out_degree_1140  1
    arc_1_7_9  in_degree_1155  1
    arc_1_7_9  original_T_including_depot_unload_1212  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_883  1
    load_1_7_9  segment_load_conservation_1144  1
    load_1_7_9  segment_load_conservation_1158  -1
    load_1_7_9  segment_prefix_lb_1159  1
    load_1_7_9  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_885  -25
    arc_1_7_13  connected_order_arc_886  -13
    arc_1_7_13  out_degree_1140  1
    arc_1_7_13  in_degree_1162  1
    arc_1_7_13  original_T_including_depot_unload_1212  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_885  1
    load_1_7_13  segment_load_conservation_1144  1
    load_1_7_13  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_887  -25
    arc_1_7_14  connected_order_arc_888  -13
    arc_1_7_14  out_degree_1140  1
    arc_1_7_14  in_degree_1168  1
    arc_1_7_14  original_T_including_depot_unload_1212  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_887  1
    load_1_7_14  segment_load_conservation_1144  1
    load_1_7_14  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_889  -25
    arc_1_7_15  connected_order_arc_890  -13
    arc_1_7_15  out_degree_1140  1
    arc_1_7_15  in_degree_1174  1
    arc_1_7_15  original_T_including_depot_unload_1212  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_889  1
    load_1_7_15  segment_load_conservation_1144  1
    load_1_7_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_891  -25
    arc_1_7_16  connected_order_arc_892  -13
    arc_1_7_16  out_degree_1140  1
    arc_1_7_16  in_degree_1180  1
    arc_1_7_16  original_T_including_depot_unload_1212  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_891  1
    load_1_7_16  segment_load_conservation_1144  1
    load_1_7_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_893  -25
    arc_1_7_17  connected_order_arc_894  -13
    arc_1_7_17  out_degree_1140  1
    arc_1_7_17  in_degree_1186  1
    arc_1_7_17  original_T_including_depot_unload_1212  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_893  1
    load_1_7_17  segment_load_conservation_1144  1
    load_1_7_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_895  -25
    arc_1_7_18  connected_order_arc_896  -13
    arc_1_7_18  out_degree_1140  1
    arc_1_7_18  in_degree_1192  1
    arc_1_7_18  original_T_including_depot_unload_1212  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_895  1
    load_1_7_18  segment_load_conservation_1144  1
    load_1_7_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_897  -25
    arc_1_7_19  connected_order_arc_898  -13
    arc_1_7_19  out_degree_1140  1
    arc_1_7_19  in_degree_1198  1
    arc_1_7_19  original_T_including_depot_unload_1212  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_897  1
    load_1_7_19  segment_load_conservation_1144  1
    load_1_7_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_899  -25
    arc_1_7_20  connected_order_arc_900  -13
    arc_1_7_20  out_degree_1140  1
    arc_1_7_20  in_degree_1204  1
    arc_1_7_20  original_T_including_depot_unload_1212  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_899  1
    load_1_7_20  segment_load_conservation_1144  1
    load_1_7_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_901  -25
    arc_1_8_0  depot_return_or_bypass_1132  1
    arc_1_8_0  out_degree_1147  1
    arc_1_8_0  original_T_including_depot_unload_1212  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_901  1
    load_1_8_0  segment_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_902  -25
    arc_1_8_6  connected_order_arc_903  -13
    arc_1_8_6  in_degree_1134  1
    arc_1_8_6  out_degree_1147  1
    arc_1_8_6  original_T_including_depot_unload_1212  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_902  1
    load_1_8_6  segment_load_conservation_1137  -1
    load_1_8_6  segment_prefix_lb_1138  1
    load_1_8_6  segment_prefix_ub_1139  1
    load_1_8_6  segment_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_904  -25
    arc_1_8_7  connected_order_arc_905  -13
    arc_1_8_7  in_degree_1141  1
    arc_1_8_7  out_degree_1147  1
    arc_1_8_7  original_T_including_depot_unload_1212  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_904  1
    load_1_8_7  segment_load_conservation_1144  -1
    load_1_8_7  segment_prefix_lb_1145  1
    load_1_8_7  segment_prefix_ub_1146  1
    load_1_8_7  segment_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_906  -25
    arc_1_8_9  connected_order_arc_907  -13
    arc_1_8_9  out_degree_1147  1
    arc_1_8_9  in_degree_1155  1
    arc_1_8_9  original_T_including_depot_unload_1212  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_906  1
    load_1_8_9  segment_load_conservation_1151  1
    load_1_8_9  segment_load_conservation_1158  -1
    load_1_8_9  segment_prefix_lb_1159  1
    load_1_8_9  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_908  -25
    arc_1_8_13  connected_order_arc_909  -13
    arc_1_8_13  out_degree_1147  1
    arc_1_8_13  in_degree_1162  1
    arc_1_8_13  original_T_including_depot_unload_1212  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_908  1
    load_1_8_13  segment_load_conservation_1151  1
    load_1_8_13  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_910  -25
    arc_1_8_14  connected_order_arc_911  -13
    arc_1_8_14  out_degree_1147  1
    arc_1_8_14  in_degree_1168  1
    arc_1_8_14  original_T_including_depot_unload_1212  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_910  1
    load_1_8_14  segment_load_conservation_1151  1
    load_1_8_14  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_912  -25
    arc_1_8_15  connected_order_arc_913  -13
    arc_1_8_15  out_degree_1147  1
    arc_1_8_15  in_degree_1174  1
    arc_1_8_15  original_T_including_depot_unload_1212  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_912  1
    load_1_8_15  segment_load_conservation_1151  1
    load_1_8_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_914  -25
    arc_1_8_16  connected_order_arc_915  -13
    arc_1_8_16  out_degree_1147  1
    arc_1_8_16  in_degree_1180  1
    arc_1_8_16  original_T_including_depot_unload_1212  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_914  1
    load_1_8_16  segment_load_conservation_1151  1
    load_1_8_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_916  -25
    arc_1_8_17  connected_order_arc_917  -13
    arc_1_8_17  out_degree_1147  1
    arc_1_8_17  in_degree_1186  1
    arc_1_8_17  original_T_including_depot_unload_1212  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_916  1
    load_1_8_17  segment_load_conservation_1151  1
    load_1_8_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_918  -25
    arc_1_8_18  connected_order_arc_919  -13
    arc_1_8_18  out_degree_1147  1
    arc_1_8_18  in_degree_1192  1
    arc_1_8_18  original_T_including_depot_unload_1212  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_918  1
    load_1_8_18  segment_load_conservation_1151  1
    load_1_8_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_920  -25
    arc_1_8_19  connected_order_arc_921  -13
    arc_1_8_19  out_degree_1147  1
    arc_1_8_19  in_degree_1198  1
    arc_1_8_19  original_T_including_depot_unload_1212  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_920  1
    load_1_8_19  segment_load_conservation_1151  1
    load_1_8_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_922  -25
    arc_1_8_20  connected_order_arc_923  -13
    arc_1_8_20  out_degree_1147  1
    arc_1_8_20  in_degree_1204  1
    arc_1_8_20  original_T_including_depot_unload_1212  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_922  1
    load_1_8_20  segment_load_conservation_1151  1
    load_1_8_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_924  -25
    arc_1_9_0  depot_return_or_bypass_1132  1
    arc_1_9_0  out_degree_1154  1
    arc_1_9_0  original_T_including_depot_unload_1212  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_924  1
    load_1_9_0  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_925  -25
    arc_1_9_6  connected_order_arc_926  -13
    arc_1_9_6  in_degree_1134  1
    arc_1_9_6  out_degree_1154  1
    arc_1_9_6  original_T_including_depot_unload_1212  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_925  1
    load_1_9_6  segment_load_conservation_1137  -1
    load_1_9_6  segment_prefix_lb_1138  1
    load_1_9_6  segment_prefix_ub_1139  1
    load_1_9_6  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_927  -25
    arc_1_9_7  connected_order_arc_928  -13
    arc_1_9_7  in_degree_1141  1
    arc_1_9_7  out_degree_1154  1
    arc_1_9_7  original_T_including_depot_unload_1212  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_927  1
    load_1_9_7  segment_load_conservation_1144  -1
    load_1_9_7  segment_prefix_lb_1145  1
    load_1_9_7  segment_prefix_ub_1146  1
    load_1_9_7  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_929  -25
    arc_1_9_8  connected_order_arc_930  -13
    arc_1_9_8  in_degree_1148  1
    arc_1_9_8  out_degree_1154  1
    arc_1_9_8  original_T_including_depot_unload_1212  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_929  1
    load_1_9_8  segment_load_conservation_1151  -1
    load_1_9_8  segment_prefix_lb_1152  1
    load_1_9_8  segment_prefix_ub_1153  1
    load_1_9_8  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_931  -25
    arc_1_9_13  connected_order_arc_932  -13
    arc_1_9_13  out_degree_1154  1
    arc_1_9_13  in_degree_1162  1
    arc_1_9_13  original_T_including_depot_unload_1212  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_931  1
    load_1_9_13  segment_load_conservation_1158  1
    load_1_9_13  free_load_conservation_1166  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_933  -25
    arc_1_9_14  connected_order_arc_934  -13
    arc_1_9_14  out_degree_1154  1
    arc_1_9_14  in_degree_1168  1
    arc_1_9_14  original_T_including_depot_unload_1212  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_933  1
    load_1_9_14  segment_load_conservation_1158  1
    load_1_9_14  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_935  -25
    arc_1_9_15  connected_order_arc_936  -13
    arc_1_9_15  out_degree_1154  1
    arc_1_9_15  in_degree_1174  1
    arc_1_9_15  original_T_including_depot_unload_1212  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_935  1
    load_1_9_15  segment_load_conservation_1158  1
    load_1_9_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_937  -25
    arc_1_9_16  connected_order_arc_938  -13
    arc_1_9_16  out_degree_1154  1
    arc_1_9_16  in_degree_1180  1
    arc_1_9_16  original_T_including_depot_unload_1212  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_937  1
    load_1_9_16  segment_load_conservation_1158  1
    load_1_9_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_939  -25
    arc_1_9_17  connected_order_arc_940  -13
    arc_1_9_17  out_degree_1154  1
    arc_1_9_17  in_degree_1186  1
    arc_1_9_17  original_T_including_depot_unload_1212  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_939  1
    load_1_9_17  segment_load_conservation_1158  1
    load_1_9_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_941  -25
    arc_1_9_18  connected_order_arc_942  -13
    arc_1_9_18  out_degree_1154  1
    arc_1_9_18  in_degree_1192  1
    arc_1_9_18  original_T_including_depot_unload_1212  1.1341050580477483e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_941  1
    load_1_9_18  segment_load_conservation_1158  1
    load_1_9_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_943  -25
    arc_1_9_19  connected_order_arc_944  -13
    arc_1_9_19  out_degree_1154  1
    arc_1_9_19  in_degree_1198  1
    arc_1_9_19  original_T_including_depot_unload_1212  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_943  1
    load_1_9_19  segment_load_conservation_1158  1
    load_1_9_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_945  -25
    arc_1_9_20  connected_order_arc_946  -13
    arc_1_9_20  out_degree_1154  1
    arc_1_9_20  in_degree_1204  1
    arc_1_9_20  original_T_including_depot_unload_1212  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_945  1
    load_1_9_20  segment_load_conservation_1158  1
    load_1_9_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_947  -25
    arc_1_13_0  depot_return_or_bypass_1132  1
    arc_1_13_0  out_degree_1161  1
    arc_1_13_0  original_T_including_depot_unload_1212  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_947  1
    load_1_13_0  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_948  -25
    arc_1_13_6  connected_order_arc_949  -13
    arc_1_13_6  in_degree_1134  1
    arc_1_13_6  out_degree_1161  1
    arc_1_13_6  original_T_including_depot_unload_1212  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_948  1
    load_1_13_6  segment_load_conservation_1137  -1
    load_1_13_6  segment_prefix_lb_1138  1
    load_1_13_6  segment_prefix_ub_1139  1
    load_1_13_6  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_950  -25
    arc_1_13_7  connected_order_arc_951  -13
    arc_1_13_7  in_degree_1141  1
    arc_1_13_7  out_degree_1161  1
    arc_1_13_7  original_T_including_depot_unload_1212  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_950  1
    load_1_13_7  segment_load_conservation_1144  -1
    load_1_13_7  segment_prefix_lb_1145  1
    load_1_13_7  segment_prefix_ub_1146  1
    load_1_13_7  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_952  -25
    arc_1_13_8  connected_order_arc_953  -13
    arc_1_13_8  in_degree_1148  1
    arc_1_13_8  out_degree_1161  1
    arc_1_13_8  original_T_including_depot_unload_1212  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_952  1
    load_1_13_8  segment_load_conservation_1151  -1
    load_1_13_8  segment_prefix_lb_1152  1
    load_1_13_8  segment_prefix_ub_1153  1
    load_1_13_8  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_954  -25
    arc_1_13_9  connected_order_arc_955  -13
    arc_1_13_9  in_degree_1155  1
    arc_1_13_9  out_degree_1161  1
    arc_1_13_9  original_T_including_depot_unload_1212  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_954  1
    load_1_13_9  segment_load_conservation_1158  -1
    load_1_13_9  segment_prefix_lb_1159  1
    load_1_13_9  segment_prefix_ub_1160  1
    load_1_13_9  free_load_conservation_1166  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_956  -25
    arc_1_13_14  connected_order_arc_957  -13
    arc_1_13_14  out_degree_1161  1
    arc_1_13_14  in_degree_1168  1
    arc_1_13_14  original_T_including_depot_unload_1212  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_956  1
    load_1_13_14  free_load_conservation_1166  1
    load_1_13_14  free_load_conservation_1172  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_958  -25
    arc_1_13_15  connected_order_arc_959  -13
    arc_1_13_15  out_degree_1161  1
    arc_1_13_15  in_degree_1174  1
    arc_1_13_15  original_T_including_depot_unload_1212  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_958  1
    load_1_13_15  free_load_conservation_1166  1
    load_1_13_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_960  -25
    arc_1_13_16  connected_order_arc_961  -13
    arc_1_13_16  out_degree_1161  1
    arc_1_13_16  in_degree_1180  1
    arc_1_13_16  original_T_including_depot_unload_1212  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_960  1
    load_1_13_16  free_load_conservation_1166  1
    load_1_13_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_962  -25
    arc_1_13_17  connected_order_arc_963  -13
    arc_1_13_17  out_degree_1161  1
    arc_1_13_17  in_degree_1186  1
    arc_1_13_17  original_T_including_depot_unload_1212  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_962  1
    load_1_13_17  free_load_conservation_1166  1
    load_1_13_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_964  -25
    arc_1_13_18  connected_order_arc_965  -13
    arc_1_13_18  out_degree_1161  1
    arc_1_13_18  in_degree_1192  1
    arc_1_13_18  original_T_including_depot_unload_1212  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_964  1
    load_1_13_18  free_load_conservation_1166  1
    load_1_13_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_966  -25
    arc_1_13_19  connected_order_arc_967  -13
    arc_1_13_19  out_degree_1161  1
    arc_1_13_19  in_degree_1198  1
    arc_1_13_19  original_T_including_depot_unload_1212  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_966  1
    load_1_13_19  free_load_conservation_1166  1
    load_1_13_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_20  arc_capacity_968  -25
    arc_1_13_20  connected_order_arc_969  -13
    arc_1_13_20  out_degree_1161  1
    arc_1_13_20  in_degree_1204  1
    arc_1_13_20  original_T_including_depot_unload_1212  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_13_20  arc_capacity_968  1
    load_1_13_20  free_load_conservation_1166  1
    load_1_13_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_970  -25
    arc_1_14_0  depot_return_or_bypass_1132  1
    arc_1_14_0  out_degree_1167  1
    arc_1_14_0  original_T_including_depot_unload_1212  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_970  1
    load_1_14_0  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_971  -25
    arc_1_14_6  connected_order_arc_972  -13
    arc_1_14_6  in_degree_1134  1
    arc_1_14_6  out_degree_1167  1
    arc_1_14_6  original_T_including_depot_unload_1212  1.2927779971523576e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_971  1
    load_1_14_6  segment_load_conservation_1137  -1
    load_1_14_6  segment_prefix_lb_1138  1
    load_1_14_6  segment_prefix_ub_1139  1
    load_1_14_6  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_973  -25
    arc_1_14_7  connected_order_arc_974  -13
    arc_1_14_7  in_degree_1141  1
    arc_1_14_7  out_degree_1167  1
    arc_1_14_7  original_T_including_depot_unload_1212  1.4479585101303876e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_973  1
    load_1_14_7  segment_load_conservation_1144  -1
    load_1_14_7  segment_prefix_lb_1145  1
    load_1_14_7  segment_prefix_ub_1146  1
    load_1_14_7  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_975  -25
    arc_1_14_8  connected_order_arc_976  -13
    arc_1_14_8  in_degree_1148  1
    arc_1_14_8  out_degree_1167  1
    arc_1_14_8  original_T_including_depot_unload_1212  1.2587701383314870e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_975  1
    load_1_14_8  segment_load_conservation_1151  -1
    load_1_14_8  segment_prefix_lb_1152  1
    load_1_14_8  segment_prefix_ub_1153  1
    load_1_14_8  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_977  -25
    arc_1_14_9  connected_order_arc_978  -13
    arc_1_14_9  in_degree_1155  1
    arc_1_14_9  out_degree_1167  1
    arc_1_14_9  original_T_including_depot_unload_1212  1.4252778892498145e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_977  1
    load_1_14_9  segment_load_conservation_1158  -1
    load_1_14_9  segment_prefix_lb_1159  1
    load_1_14_9  segment_prefix_ub_1160  1
    load_1_14_9  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_979  -25
    arc_1_14_13  connected_order_arc_980  -13
    arc_1_14_13  in_degree_1162  1
    arc_1_14_13  out_degree_1167  1
    arc_1_14_13  original_T_including_depot_unload_1212  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_979  1
    load_1_14_13  free_load_conservation_1166  -1
    load_1_14_13  free_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_981  -25
    arc_1_14_15  connected_order_arc_982  -13
    arc_1_14_15  out_degree_1167  1
    arc_1_14_15  in_degree_1174  1
    arc_1_14_15  original_T_including_depot_unload_1212  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_981  1
    load_1_14_15  free_load_conservation_1172  1
    load_1_14_15  free_load_conservation_1178  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_983  -25
    arc_1_14_16  connected_order_arc_984  -13
    arc_1_14_16  out_degree_1167  1
    arc_1_14_16  in_degree_1180  1
    arc_1_14_16  original_T_including_depot_unload_1212  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_983  1
    load_1_14_16  free_load_conservation_1172  1
    load_1_14_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_985  -25
    arc_1_14_17  connected_order_arc_986  -13
    arc_1_14_17  out_degree_1167  1
    arc_1_14_17  in_degree_1186  1
    arc_1_14_17  original_T_including_depot_unload_1212  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_985  1
    load_1_14_17  free_load_conservation_1172  1
    load_1_14_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_987  -25
    arc_1_14_18  connected_order_arc_988  -13
    arc_1_14_18  out_degree_1167  1
    arc_1_14_18  in_degree_1192  1
    arc_1_14_18  original_T_including_depot_unload_1212  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_987  1
    load_1_14_18  free_load_conservation_1172  1
    load_1_14_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_989  -25
    arc_1_14_19  connected_order_arc_990  -13
    arc_1_14_19  out_degree_1167  1
    arc_1_14_19  in_degree_1198  1
    arc_1_14_19  original_T_including_depot_unload_1212  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_989  1
    load_1_14_19  free_load_conservation_1172  1
    load_1_14_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_991  -25
    arc_1_14_20  connected_order_arc_992  -13
    arc_1_14_20  out_degree_1167  1
    arc_1_14_20  in_degree_1204  1
    arc_1_14_20  original_T_including_depot_unload_1212  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_991  1
    load_1_14_20  free_load_conservation_1172  1
    load_1_14_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_993  -25
    arc_1_15_0  depot_return_or_bypass_1132  1
    arc_1_15_0  out_degree_1173  1
    arc_1_15_0  original_T_including_depot_unload_1212  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_993  1
    load_1_15_0  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_994  -25
    arc_1_15_6  connected_order_arc_995  -13
    arc_1_15_6  in_degree_1134  1
    arc_1_15_6  out_degree_1173  1
    arc_1_15_6  original_T_including_depot_unload_1212  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_994  1
    load_1_15_6  segment_load_conservation_1137  -1
    load_1_15_6  segment_prefix_lb_1138  1
    load_1_15_6  segment_prefix_ub_1139  1
    load_1_15_6  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_996  -25
    arc_1_15_7  connected_order_arc_997  -13
    arc_1_15_7  in_degree_1141  1
    arc_1_15_7  out_degree_1173  1
    arc_1_15_7  original_T_including_depot_unload_1212  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_996  1
    load_1_15_7  segment_load_conservation_1144  -1
    load_1_15_7  segment_prefix_lb_1145  1
    load_1_15_7  segment_prefix_ub_1146  1
    load_1_15_7  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_998  -25
    arc_1_15_8  connected_order_arc_999  -13
    arc_1_15_8  in_degree_1148  1
    arc_1_15_8  out_degree_1173  1
    arc_1_15_8  original_T_including_depot_unload_1212  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_998  1
    load_1_15_8  segment_load_conservation_1151  -1
    load_1_15_8  segment_prefix_lb_1152  1
    load_1_15_8  segment_prefix_ub_1153  1
    load_1_15_8  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1000  -25
    arc_1_15_9  connected_order_arc_1001  -13
    arc_1_15_9  in_degree_1155  1
    arc_1_15_9  out_degree_1173  1
    arc_1_15_9  original_T_including_depot_unload_1212  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1000  1
    load_1_15_9  segment_load_conservation_1158  -1
    load_1_15_9  segment_prefix_lb_1159  1
    load_1_15_9  segment_prefix_ub_1160  1
    load_1_15_9  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1002  -25
    arc_1_15_13  connected_order_arc_1003  -13
    arc_1_15_13  in_degree_1162  1
    arc_1_15_13  out_degree_1173  1
    arc_1_15_13  original_T_including_depot_unload_1212  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1002  1
    load_1_15_13  free_load_conservation_1166  -1
    load_1_15_13  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1004  -25
    arc_1_15_14  connected_order_arc_1005  -13
    arc_1_15_14  in_degree_1168  1
    arc_1_15_14  out_degree_1173  1
    arc_1_15_14  original_T_including_depot_unload_1212  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1004  1
    load_1_15_14  free_load_conservation_1172  -1
    load_1_15_14  free_load_conservation_1178  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_1006  -25
    arc_1_15_16  connected_order_arc_1007  -13
    arc_1_15_16  out_degree_1173  1
    arc_1_15_16  in_degree_1180  1
    arc_1_15_16  original_T_including_depot_unload_1212  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_1006  1
    load_1_15_16  free_load_conservation_1178  1
    load_1_15_16  free_load_conservation_1184  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_1008  -25
    arc_1_15_17  connected_order_arc_1009  -13
    arc_1_15_17  out_degree_1173  1
    arc_1_15_17  in_degree_1186  1
    arc_1_15_17  original_T_including_depot_unload_1212  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_1008  1
    load_1_15_17  free_load_conservation_1178  1
    load_1_15_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_1010  -25
    arc_1_15_18  connected_order_arc_1011  -13
    arc_1_15_18  out_degree_1173  1
    arc_1_15_18  in_degree_1192  1
    arc_1_15_18  original_T_including_depot_unload_1212  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_1010  1
    load_1_15_18  free_load_conservation_1178  1
    load_1_15_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_1012  -25
    arc_1_15_19  connected_order_arc_1013  -13
    arc_1_15_19  out_degree_1173  1
    arc_1_15_19  in_degree_1198  1
    arc_1_15_19  original_T_including_depot_unload_1212  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_1012  1
    load_1_15_19  free_load_conservation_1178  1
    load_1_15_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_1014  -25
    arc_1_15_20  connected_order_arc_1015  -13
    arc_1_15_20  out_degree_1173  1
    arc_1_15_20  in_degree_1204  1
    arc_1_15_20  original_T_including_depot_unload_1212  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_1014  1
    load_1_15_20  free_load_conservation_1178  1
    load_1_15_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_1016  -25
    arc_1_16_0  depot_return_or_bypass_1132  1
    arc_1_16_0  out_degree_1179  1
    arc_1_16_0  original_T_including_depot_unload_1212  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_1016  1
    load_1_16_0  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_1017  -25
    arc_1_16_6  connected_order_arc_1018  -13
    arc_1_16_6  in_degree_1134  1
    arc_1_16_6  out_degree_1179  1
    arc_1_16_6  original_T_including_depot_unload_1212  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_1017  1
    load_1_16_6  segment_load_conservation_1137  -1
    load_1_16_6  segment_prefix_lb_1138  1
    load_1_16_6  segment_prefix_ub_1139  1
    load_1_16_6  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_1019  -25
    arc_1_16_7  connected_order_arc_1020  -13
    arc_1_16_7  in_degree_1141  1
    arc_1_16_7  out_degree_1179  1
    arc_1_16_7  original_T_including_depot_unload_1212  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_1019  1
    load_1_16_7  segment_load_conservation_1144  -1
    load_1_16_7  segment_prefix_lb_1145  1
    load_1_16_7  segment_prefix_ub_1146  1
    load_1_16_7  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_1021  -25
    arc_1_16_8  connected_order_arc_1022  -13
    arc_1_16_8  in_degree_1148  1
    arc_1_16_8  out_degree_1179  1
    arc_1_16_8  original_T_including_depot_unload_1212  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_1021  1
    load_1_16_8  segment_load_conservation_1151  -1
    load_1_16_8  segment_prefix_lb_1152  1
    load_1_16_8  segment_prefix_ub_1153  1
    load_1_16_8  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_1023  -25
    arc_1_16_9  connected_order_arc_1024  -13
    arc_1_16_9  in_degree_1155  1
    arc_1_16_9  out_degree_1179  1
    arc_1_16_9  original_T_including_depot_unload_1212  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_1023  1
    load_1_16_9  segment_load_conservation_1158  -1
    load_1_16_9  segment_prefix_lb_1159  1
    load_1_16_9  segment_prefix_ub_1160  1
    load_1_16_9  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_1025  -25
    arc_1_16_13  connected_order_arc_1026  -13
    arc_1_16_13  in_degree_1162  1
    arc_1_16_13  out_degree_1179  1
    arc_1_16_13  original_T_including_depot_unload_1212  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_1025  1
    load_1_16_13  free_load_conservation_1166  -1
    load_1_16_13  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_1027  -25
    arc_1_16_14  connected_order_arc_1028  -13
    arc_1_16_14  in_degree_1168  1
    arc_1_16_14  out_degree_1179  1
    arc_1_16_14  original_T_including_depot_unload_1212  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_1027  1
    load_1_16_14  free_load_conservation_1172  -1
    load_1_16_14  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1029  -25
    arc_1_16_15  connected_order_arc_1030  -13
    arc_1_16_15  in_degree_1174  1
    arc_1_16_15  out_degree_1179  1
    arc_1_16_15  original_T_including_depot_unload_1212  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1029  1
    load_1_16_15  free_load_conservation_1178  -1
    load_1_16_15  free_load_conservation_1184  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1031  -25
    arc_1_16_17  connected_order_arc_1032  -13
    arc_1_16_17  out_degree_1179  1
    arc_1_16_17  in_degree_1186  1
    arc_1_16_17  original_T_including_depot_unload_1212  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1031  1
    load_1_16_17  free_load_conservation_1184  1
    load_1_16_17  free_load_conservation_1190  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1033  -25
    arc_1_16_18  connected_order_arc_1034  -13
    arc_1_16_18  out_degree_1179  1
    arc_1_16_18  in_degree_1192  1
    arc_1_16_18  original_T_including_depot_unload_1212  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1033  1
    load_1_16_18  free_load_conservation_1184  1
    load_1_16_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1035  -25
    arc_1_16_19  connected_order_arc_1036  -13
    arc_1_16_19  out_degree_1179  1
    arc_1_16_19  in_degree_1198  1
    arc_1_16_19  original_T_including_depot_unload_1212  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1035  1
    load_1_16_19  free_load_conservation_1184  1
    load_1_16_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1037  -25
    arc_1_16_20  connected_order_arc_1038  -13
    arc_1_16_20  out_degree_1179  1
    arc_1_16_20  in_degree_1204  1
    arc_1_16_20  original_T_including_depot_unload_1212  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1037  1
    load_1_16_20  free_load_conservation_1184  1
    load_1_16_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1039  -25
    arc_1_17_0  depot_return_or_bypass_1132  1
    arc_1_17_0  out_degree_1185  1
    arc_1_17_0  original_T_including_depot_unload_1212  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1039  1
    load_1_17_0  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1040  -25
    arc_1_17_6  connected_order_arc_1041  -13
    arc_1_17_6  in_degree_1134  1
    arc_1_17_6  out_degree_1185  1
    arc_1_17_6  original_T_including_depot_unload_1212  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1040  1
    load_1_17_6  segment_load_conservation_1137  -1
    load_1_17_6  segment_prefix_lb_1138  1
    load_1_17_6  segment_prefix_ub_1139  1
    load_1_17_6  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1042  -25
    arc_1_17_7  connected_order_arc_1043  -13
    arc_1_17_7  in_degree_1141  1
    arc_1_17_7  out_degree_1185  1
    arc_1_17_7  original_T_including_depot_unload_1212  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1042  1
    load_1_17_7  segment_load_conservation_1144  -1
    load_1_17_7  segment_prefix_lb_1145  1
    load_1_17_7  segment_prefix_ub_1146  1
    load_1_17_7  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1044  -25
    arc_1_17_8  connected_order_arc_1045  -13
    arc_1_17_8  in_degree_1148  1
    arc_1_17_8  out_degree_1185  1
    arc_1_17_8  original_T_including_depot_unload_1212  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1044  1
    load_1_17_8  segment_load_conservation_1151  -1
    load_1_17_8  segment_prefix_lb_1152  1
    load_1_17_8  segment_prefix_ub_1153  1
    load_1_17_8  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1046  -25
    arc_1_17_9  connected_order_arc_1047  -13
    arc_1_17_9  in_degree_1155  1
    arc_1_17_9  out_degree_1185  1
    arc_1_17_9  original_T_including_depot_unload_1212  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1046  1
    load_1_17_9  segment_load_conservation_1158  -1
    load_1_17_9  segment_prefix_lb_1159  1
    load_1_17_9  segment_prefix_ub_1160  1
    load_1_17_9  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1048  -25
    arc_1_17_13  connected_order_arc_1049  -13
    arc_1_17_13  in_degree_1162  1
    arc_1_17_13  out_degree_1185  1
    arc_1_17_13  original_T_including_depot_unload_1212  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1048  1
    load_1_17_13  free_load_conservation_1166  -1
    load_1_17_13  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1050  -25
    arc_1_17_14  connected_order_arc_1051  -13
    arc_1_17_14  in_degree_1168  1
    arc_1_17_14  out_degree_1185  1
    arc_1_17_14  original_T_including_depot_unload_1212  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1050  1
    load_1_17_14  free_load_conservation_1172  -1
    load_1_17_14  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1052  -25
    arc_1_17_15  connected_order_arc_1053  -13
    arc_1_17_15  in_degree_1174  1
    arc_1_17_15  out_degree_1185  1
    arc_1_17_15  original_T_including_depot_unload_1212  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1052  1
    load_1_17_15  free_load_conservation_1178  -1
    load_1_17_15  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1054  -25
    arc_1_17_16  connected_order_arc_1055  -13
    arc_1_17_16  in_degree_1180  1
    arc_1_17_16  out_degree_1185  1
    arc_1_17_16  original_T_including_depot_unload_1212  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1054  1
    load_1_17_16  free_load_conservation_1184  -1
    load_1_17_16  free_load_conservation_1190  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1056  -25
    arc_1_17_18  connected_order_arc_1057  -13
    arc_1_17_18  out_degree_1185  1
    arc_1_17_18  in_degree_1192  1
    arc_1_17_18  original_T_including_depot_unload_1212  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1056  1
    load_1_17_18  free_load_conservation_1190  1
    load_1_17_18  free_load_conservation_1196  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1058  -25
    arc_1_17_19  connected_order_arc_1059  -13
    arc_1_17_19  out_degree_1185  1
    arc_1_17_19  in_degree_1198  1
    arc_1_17_19  original_T_including_depot_unload_1212  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1058  1
    load_1_17_19  free_load_conservation_1190  1
    load_1_17_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1060  -25
    arc_1_17_20  connected_order_arc_1061  -13
    arc_1_17_20  out_degree_1185  1
    arc_1_17_20  in_degree_1204  1
    arc_1_17_20  original_T_including_depot_unload_1212  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1060  1
    load_1_17_20  free_load_conservation_1190  1
    load_1_17_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1062  -25
    arc_1_18_0  depot_return_or_bypass_1132  1
    arc_1_18_0  out_degree_1191  1
    arc_1_18_0  original_T_including_depot_unload_1212  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1062  1
    load_1_18_0  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1063  -25
    arc_1_18_6  connected_order_arc_1064  -13
    arc_1_18_6  in_degree_1134  1
    arc_1_18_6  out_degree_1191  1
    arc_1_18_6  original_T_including_depot_unload_1212  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1063  1
    load_1_18_6  segment_load_conservation_1137  -1
    load_1_18_6  segment_prefix_lb_1138  1
    load_1_18_6  segment_prefix_ub_1139  1
    load_1_18_6  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1065  -25
    arc_1_18_7  connected_order_arc_1066  -13
    arc_1_18_7  in_degree_1141  1
    arc_1_18_7  out_degree_1191  1
    arc_1_18_7  original_T_including_depot_unload_1212  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1065  1
    load_1_18_7  segment_load_conservation_1144  -1
    load_1_18_7  segment_prefix_lb_1145  1
    load_1_18_7  segment_prefix_ub_1146  1
    load_1_18_7  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1067  -25
    arc_1_18_8  connected_order_arc_1068  -13
    arc_1_18_8  in_degree_1148  1
    arc_1_18_8  out_degree_1191  1
    arc_1_18_8  original_T_including_depot_unload_1212  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1067  1
    load_1_18_8  segment_load_conservation_1151  -1
    load_1_18_8  segment_prefix_lb_1152  1
    load_1_18_8  segment_prefix_ub_1153  1
    load_1_18_8  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1069  -25
    arc_1_18_9  connected_order_arc_1070  -13
    arc_1_18_9  in_degree_1155  1
    arc_1_18_9  out_degree_1191  1
    arc_1_18_9  original_T_including_depot_unload_1212  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1069  1
    load_1_18_9  segment_load_conservation_1158  -1
    load_1_18_9  segment_prefix_lb_1159  1
    load_1_18_9  segment_prefix_ub_1160  1
    load_1_18_9  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1071  -25
    arc_1_18_13  connected_order_arc_1072  -13
    arc_1_18_13  in_degree_1162  1
    arc_1_18_13  out_degree_1191  1
    arc_1_18_13  original_T_including_depot_unload_1212  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1071  1
    load_1_18_13  free_load_conservation_1166  -1
    load_1_18_13  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1073  -25
    arc_1_18_14  connected_order_arc_1074  -13
    arc_1_18_14  in_degree_1168  1
    arc_1_18_14  out_degree_1191  1
    arc_1_18_14  original_T_including_depot_unload_1212  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1073  1
    load_1_18_14  free_load_conservation_1172  -1
    load_1_18_14  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1075  -25
    arc_1_18_15  connected_order_arc_1076  -13
    arc_1_18_15  in_degree_1174  1
    arc_1_18_15  out_degree_1191  1
    arc_1_18_15  original_T_including_depot_unload_1212  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1075  1
    load_1_18_15  free_load_conservation_1178  -1
    load_1_18_15  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1077  -25
    arc_1_18_16  connected_order_arc_1078  -13
    arc_1_18_16  in_degree_1180  1
    arc_1_18_16  out_degree_1191  1
    arc_1_18_16  original_T_including_depot_unload_1212  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1077  1
    load_1_18_16  free_load_conservation_1184  -1
    load_1_18_16  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1079  -25
    arc_1_18_17  connected_order_arc_1080  -13
    arc_1_18_17  in_degree_1186  1
    arc_1_18_17  out_degree_1191  1
    arc_1_18_17  original_T_including_depot_unload_1212  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1079  1
    load_1_18_17  free_load_conservation_1190  -1
    load_1_18_17  free_load_conservation_1196  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1081  -25
    arc_1_18_19  connected_order_arc_1082  -13
    arc_1_18_19  out_degree_1191  1
    arc_1_18_19  in_degree_1198  1
    arc_1_18_19  original_T_including_depot_unload_1212  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1081  1
    load_1_18_19  free_load_conservation_1196  1
    load_1_18_19  free_load_conservation_1202  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1083  -25
    arc_1_18_20  connected_order_arc_1084  -13
    arc_1_18_20  out_degree_1191  1
    arc_1_18_20  in_degree_1204  1
    arc_1_18_20  original_T_including_depot_unload_1212  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1083  1
    load_1_18_20  free_load_conservation_1196  1
    load_1_18_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1085  -25
    arc_1_19_0  depot_return_or_bypass_1132  1
    arc_1_19_0  out_degree_1197  1
    arc_1_19_0  original_T_including_depot_unload_1212  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1085  1
    load_1_19_0  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1086  -25
    arc_1_19_6  connected_order_arc_1087  -13
    arc_1_19_6  in_degree_1134  1
    arc_1_19_6  out_degree_1197  1
    arc_1_19_6  original_T_including_depot_unload_1212  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1086  1
    load_1_19_6  segment_load_conservation_1137  -1
    load_1_19_6  segment_prefix_lb_1138  1
    load_1_19_6  segment_prefix_ub_1139  1
    load_1_19_6  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1088  -25
    arc_1_19_7  connected_order_arc_1089  -13
    arc_1_19_7  in_degree_1141  1
    arc_1_19_7  out_degree_1197  1
    arc_1_19_7  original_T_including_depot_unload_1212  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1088  1
    load_1_19_7  segment_load_conservation_1144  -1
    load_1_19_7  segment_prefix_lb_1145  1
    load_1_19_7  segment_prefix_ub_1146  1
    load_1_19_7  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1090  -25
    arc_1_19_8  connected_order_arc_1091  -13
    arc_1_19_8  in_degree_1148  1
    arc_1_19_8  out_degree_1197  1
    arc_1_19_8  original_T_including_depot_unload_1212  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1090  1
    load_1_19_8  segment_load_conservation_1151  -1
    load_1_19_8  segment_prefix_lb_1152  1
    load_1_19_8  segment_prefix_ub_1153  1
    load_1_19_8  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1092  -25
    arc_1_19_9  connected_order_arc_1093  -13
    arc_1_19_9  in_degree_1155  1
    arc_1_19_9  out_degree_1197  1
    arc_1_19_9  original_T_including_depot_unload_1212  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1092  1
    load_1_19_9  segment_load_conservation_1158  -1
    load_1_19_9  segment_prefix_lb_1159  1
    load_1_19_9  segment_prefix_ub_1160  1
    load_1_19_9  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1094  -25
    arc_1_19_13  connected_order_arc_1095  -13
    arc_1_19_13  in_degree_1162  1
    arc_1_19_13  out_degree_1197  1
    arc_1_19_13  original_T_including_depot_unload_1212  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1094  1
    load_1_19_13  free_load_conservation_1166  -1
    load_1_19_13  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1096  -25
    arc_1_19_14  connected_order_arc_1097  -13
    arc_1_19_14  in_degree_1168  1
    arc_1_19_14  out_degree_1197  1
    arc_1_19_14  original_T_including_depot_unload_1212  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1096  1
    load_1_19_14  free_load_conservation_1172  -1
    load_1_19_14  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1098  -25
    arc_1_19_15  connected_order_arc_1099  -13
    arc_1_19_15  in_degree_1174  1
    arc_1_19_15  out_degree_1197  1
    arc_1_19_15  original_T_including_depot_unload_1212  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1098  1
    load_1_19_15  free_load_conservation_1178  -1
    load_1_19_15  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1100  -25
    arc_1_19_16  connected_order_arc_1101  -13
    arc_1_19_16  in_degree_1180  1
    arc_1_19_16  out_degree_1197  1
    arc_1_19_16  original_T_including_depot_unload_1212  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1100  1
    load_1_19_16  free_load_conservation_1184  -1
    load_1_19_16  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1102  -25
    arc_1_19_17  connected_order_arc_1103  -13
    arc_1_19_17  in_degree_1186  1
    arc_1_19_17  out_degree_1197  1
    arc_1_19_17  original_T_including_depot_unload_1212  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1102  1
    load_1_19_17  free_load_conservation_1190  -1
    load_1_19_17  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1104  -25
    arc_1_19_18  connected_order_arc_1105  -13
    arc_1_19_18  in_degree_1192  1
    arc_1_19_18  out_degree_1197  1
    arc_1_19_18  original_T_including_depot_unload_1212  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1104  1
    load_1_19_18  free_load_conservation_1196  -1
    load_1_19_18  free_load_conservation_1202  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1106  -25
    arc_1_19_20  connected_order_arc_1107  -13
    arc_1_19_20  out_degree_1197  1
    arc_1_19_20  in_degree_1204  1
    arc_1_19_20  original_T_including_depot_unload_1212  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1106  1
    load_1_19_20  free_load_conservation_1202  1
    load_1_19_20  free_load_conservation_1208  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1108  -25
    arc_1_20_0  depot_return_or_bypass_1132  1
    arc_1_20_0  out_degree_1203  1
    arc_1_20_0  original_T_including_depot_unload_1212  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1108  1
    load_1_20_0  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1109  -25
    arc_1_20_6  connected_order_arc_1110  -13
    arc_1_20_6  in_degree_1134  1
    arc_1_20_6  out_degree_1203  1
    arc_1_20_6  original_T_including_depot_unload_1212  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1109  1
    load_1_20_6  segment_load_conservation_1137  -1
    load_1_20_6  segment_prefix_lb_1138  1
    load_1_20_6  segment_prefix_ub_1139  1
    load_1_20_6  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1111  -25
    arc_1_20_7  connected_order_arc_1112  -13
    arc_1_20_7  in_degree_1141  1
    arc_1_20_7  out_degree_1203  1
    arc_1_20_7  original_T_including_depot_unload_1212  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1111  1
    load_1_20_7  segment_load_conservation_1144  -1
    load_1_20_7  segment_prefix_lb_1145  1
    load_1_20_7  segment_prefix_ub_1146  1
    load_1_20_7  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1113  -25
    arc_1_20_8  connected_order_arc_1114  -13
    arc_1_20_8  in_degree_1148  1
    arc_1_20_8  out_degree_1203  1
    arc_1_20_8  original_T_including_depot_unload_1212  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1113  1
    load_1_20_8  segment_load_conservation_1151  -1
    load_1_20_8  segment_prefix_lb_1152  1
    load_1_20_8  segment_prefix_ub_1153  1
    load_1_20_8  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1115  -25
    arc_1_20_9  connected_order_arc_1116  -13
    arc_1_20_9  in_degree_1155  1
    arc_1_20_9  out_degree_1203  1
    arc_1_20_9  original_T_including_depot_unload_1212  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1115  1
    load_1_20_9  segment_load_conservation_1158  -1
    load_1_20_9  segment_prefix_lb_1159  1
    load_1_20_9  segment_prefix_ub_1160  1
    load_1_20_9  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_13  arc_capacity_1117  -25
    arc_1_20_13  connected_order_arc_1118  -13
    arc_1_20_13  in_degree_1162  1
    arc_1_20_13  out_degree_1203  1
    arc_1_20_13  original_T_including_depot_unload_1212  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_1_20_13  arc_capacity_1117  1
    load_1_20_13  free_load_conservation_1166  -1
    load_1_20_13  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1119  -25
    arc_1_20_14  connected_order_arc_1120  -13
    arc_1_20_14  in_degree_1168  1
    arc_1_20_14  out_degree_1203  1
    arc_1_20_14  original_T_including_depot_unload_1212  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1119  1
    load_1_20_14  free_load_conservation_1172  -1
    load_1_20_14  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1121  -25
    arc_1_20_15  connected_order_arc_1122  -13
    arc_1_20_15  in_degree_1174  1
    arc_1_20_15  out_degree_1203  1
    arc_1_20_15  original_T_including_depot_unload_1212  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1121  1
    load_1_20_15  free_load_conservation_1178  -1
    load_1_20_15  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1123  -25
    arc_1_20_16  connected_order_arc_1124  -13
    arc_1_20_16  in_degree_1180  1
    arc_1_20_16  out_degree_1203  1
    arc_1_20_16  original_T_including_depot_unload_1212  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1123  1
    load_1_20_16  free_load_conservation_1184  -1
    load_1_20_16  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1125  -25
    arc_1_20_17  connected_order_arc_1126  -13
    arc_1_20_17  in_degree_1186  1
    arc_1_20_17  out_degree_1203  1
    arc_1_20_17  original_T_including_depot_unload_1212  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1125  1
    load_1_20_17  free_load_conservation_1190  -1
    load_1_20_17  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1127  -25
    arc_1_20_18  connected_order_arc_1128  -13
    arc_1_20_18  in_degree_1192  1
    arc_1_20_18  out_degree_1203  1
    arc_1_20_18  original_T_including_depot_unload_1212  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1127  1
    load_1_20_18  free_load_conservation_1196  -1
    load_1_20_18  free_load_conservation_1208  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1129  -25
    arc_1_20_19  connected_order_arc_1130  -13
    arc_1_20_19  in_degree_1198  1
    arc_1_20_19  out_degree_1203  1
    arc_1_20_19  original_T_including_depot_unload_1212  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1129  1
    load_1_20_19  free_load_conservation_1202  -1
    load_1_20_19  free_load_conservation_1208  1
    visit_2_10  out_degree_1458  -1
    visit_2_10  in_degree_1459  -1
    visit_2_10  order_active_lb_1460  -1
    visit_2_10  order_active_ub_1461  -11
    order_2_10  connected_order_arc_1227  -1
    order_2_10  connected_order_arc_1229  -1
    order_2_10  connected_order_arc_1231  -1
    order_2_10  connected_order_arc_1233  -1
    order_2_10  connected_order_arc_1235  -1
    order_2_10  connected_order_arc_1237  -1
    order_2_10  connected_order_arc_1239  -1
    order_2_10  connected_order_arc_1241  -1
    order_2_10  connected_order_arc_1243  -1
    order_2_10  connected_order_arc_1245  -1
    order_2_10  connected_order_arc_1248  1
    order_2_10  connected_order_arc_1269  1
    order_2_10  connected_order_arc_1290  1
    order_2_10  connected_order_arc_1311  1
    order_2_10  connected_order_arc_1332  1
    order_2_10  connected_order_arc_1353  1
    order_2_10  connected_order_arc_1374  1
    order_2_10  connected_order_arc_1395  1
    order_2_10  connected_order_arc_1416  1
    order_2_10  connected_order_arc_1437  1
    order_2_10  order_active_lb_1460  1
    order_2_10  order_active_ub_1461  1
    order_2_10  fixed_segment_relative_order_1527  -1
    visit_2_11  out_degree_1465  -1
    visit_2_11  in_degree_1466  -1
    visit_2_11  order_active_lb_1467  -1
    visit_2_11  order_active_ub_1468  -11
    order_2_11  connected_order_arc_1227  1
    order_2_11  connected_order_arc_1248  -1
    order_2_11  connected_order_arc_1250  -1
    order_2_11  connected_order_arc_1252  -1
    order_2_11  connected_order_arc_1254  -1
    order_2_11  connected_order_arc_1256  -1
    order_2_11  connected_order_arc_1258  -1
    order_2_11  connected_order_arc_1260  -1
    order_2_11  connected_order_arc_1262  -1
    order_2_11  connected_order_arc_1264  -1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1271  1
    order_2_11  connected_order_arc_1292  1
    order_2_11  connected_order_arc_1313  1
    order_2_11  connected_order_arc_1334  1
    order_2_11  connected_order_arc_1355  1
    order_2_11  connected_order_arc_1376  1
    order_2_11  connected_order_arc_1397  1
    order_2_11  connected_order_arc_1418  1
    order_2_11  connected_order_arc_1439  1
    order_2_11  order_active_lb_1467  1
    order_2_11  order_active_ub_1468  1
    order_2_11  fixed_segment_relative_order_1527  1
    order_2_11  fixed_segment_relative_order_1528  -1
    visit_2_12  out_degree_1472  -1
    visit_2_12  in_degree_1473  -1
    visit_2_12  order_active_lb_1474  -1
    visit_2_12  order_active_ub_1475  -11
    order_2_12  connected_order_arc_1229  1
    order_2_12  connected_order_arc_1250  1
    order_2_12  connected_order_arc_1269  -1
    order_2_12  connected_order_arc_1271  -1
    order_2_12  connected_order_arc_1273  -1
    order_2_12  connected_order_arc_1275  -1
    order_2_12  connected_order_arc_1277  -1
    order_2_12  connected_order_arc_1279  -1
    order_2_12  connected_order_arc_1281  -1
    order_2_12  connected_order_arc_1283  -1
    order_2_12  connected_order_arc_1285  -1
    order_2_12  connected_order_arc_1287  -1
    order_2_12  connected_order_arc_1294  1
    order_2_12  connected_order_arc_1315  1
    order_2_12  connected_order_arc_1336  1
    order_2_12  connected_order_arc_1357  1
    order_2_12  connected_order_arc_1378  1
    order_2_12  connected_order_arc_1399  1
    order_2_12  connected_order_arc_1420  1
    order_2_12  connected_order_arc_1441  1
    order_2_12  order_active_lb_1474  1
    order_2_12  order_active_ub_1475  1
    order_2_12  fixed_segment_relative_order_1528  1
    visit_2_13  out_degree_1479  -1
    visit_2_13  in_degree_1480  -1
    visit_2_13  order_active_lb_1481  -1
    visit_2_13  order_active_ub_1482  -11
    visit_2_13  service_visit_def_1483  -1
    order_2_13  connected_order_arc_1231  1
    order_2_13  connected_order_arc_1252  1
    order_2_13  connected_order_arc_1273  1
    order_2_13  connected_order_arc_1290  -1
    order_2_13  connected_order_arc_1292  -1
    order_2_13  connected_order_arc_1294  -1
    order_2_13  connected_order_arc_1296  -1
    order_2_13  connected_order_arc_1298  -1
    order_2_13  connected_order_arc_1300  -1
    order_2_13  connected_order_arc_1302  -1
    order_2_13  connected_order_arc_1304  -1
    order_2_13  connected_order_arc_1306  -1
    order_2_13  connected_order_arc_1308  -1
    order_2_13  connected_order_arc_1317  1
    order_2_13  connected_order_arc_1338  1
    order_2_13  connected_order_arc_1359  1
    order_2_13  connected_order_arc_1380  1
    order_2_13  connected_order_arc_1401  1
    order_2_13  connected_order_arc_1422  1
    order_2_13  connected_order_arc_1443  1
    order_2_13  order_active_lb_1481  1
    order_2_13  order_active_ub_1482  1
    visit_2_14  out_degree_1485  -1
    visit_2_14  in_degree_1486  -1
    visit_2_14  order_active_lb_1487  -1
    visit_2_14  order_active_ub_1488  -11
    visit_2_14  service_visit_def_1489  -1
    order_2_14  connected_order_arc_1233  1
    order_2_14  connected_order_arc_1254  1
    order_2_14  connected_order_arc_1275  1
    order_2_14  connected_order_arc_1296  1
    order_2_14  connected_order_arc_1311  -1
    order_2_14  connected_order_arc_1313  -1
    order_2_14  connected_order_arc_1315  -1
    order_2_14  connected_order_arc_1317  -1
    order_2_14  connected_order_arc_1319  -1
    order_2_14  connected_order_arc_1321  -1
    order_2_14  connected_order_arc_1323  -1
    order_2_14  connected_order_arc_1325  -1
    order_2_14  connected_order_arc_1327  -1
    order_2_14  connected_order_arc_1329  -1
    order_2_14  connected_order_arc_1340  1
    order_2_14  connected_order_arc_1361  1
    order_2_14  connected_order_arc_1382  1
    order_2_14  connected_order_arc_1403  1
    order_2_14  connected_order_arc_1424  1
    order_2_14  connected_order_arc_1445  1
    order_2_14  order_active_lb_1487  1
    order_2_14  order_active_ub_1488  1
    visit_2_15  out_degree_1491  -1
    visit_2_15  in_degree_1492  -1
    visit_2_15  order_active_lb_1493  -1
    visit_2_15  order_active_ub_1494  -11
    visit_2_15  service_visit_def_1495  -1
    order_2_15  connected_order_arc_1235  1
    order_2_15  connected_order_arc_1256  1
    order_2_15  connected_order_arc_1277  1
    order_2_15  connected_order_arc_1298  1
    order_2_15  connected_order_arc_1319  1
    order_2_15  connected_order_arc_1332  -1
    order_2_15  connected_order_arc_1334  -1
    order_2_15  connected_order_arc_1336  -1
    order_2_15  connected_order_arc_1338  -1
    order_2_15  connected_order_arc_1340  -1
    order_2_15  connected_order_arc_1342  -1
    order_2_15  connected_order_arc_1344  -1
    order_2_15  connected_order_arc_1346  -1
    order_2_15  connected_order_arc_1348  -1
    order_2_15  connected_order_arc_1350  -1
    order_2_15  connected_order_arc_1363  1
    order_2_15  connected_order_arc_1384  1
    order_2_15  connected_order_arc_1405  1
    order_2_15  connected_order_arc_1426  1
    order_2_15  connected_order_arc_1447  1
    order_2_15  order_active_lb_1493  1
    order_2_15  order_active_ub_1494  1
    visit_2_16  out_degree_1497  -1
    visit_2_16  in_degree_1498  -1
    visit_2_16  order_active_lb_1499  -1
    visit_2_16  order_active_ub_1500  -11
    visit_2_16  service_visit_def_1501  -1
    order_2_16  connected_order_arc_1237  1
    order_2_16  connected_order_arc_1258  1
    order_2_16  connected_order_arc_1279  1
    order_2_16  connected_order_arc_1300  1
    order_2_16  connected_order_arc_1321  1
    order_2_16  connected_order_arc_1342  1
    order_2_16  connected_order_arc_1353  -1
    order_2_16  connected_order_arc_1355  -1
    order_2_16  connected_order_arc_1357  -1
    order_2_16  connected_order_arc_1359  -1
    order_2_16  connected_order_arc_1361  -1
    order_2_16  connected_order_arc_1363  -1
    order_2_16  connected_order_arc_1365  -1
    order_2_16  connected_order_arc_1367  -1
    order_2_16  connected_order_arc_1369  -1
    order_2_16  connected_order_arc_1371  -1
    order_2_16  connected_order_arc_1386  1
    order_2_16  connected_order_arc_1407  1
    order_2_16  connected_order_arc_1428  1
    order_2_16  connected_order_arc_1449  1
    order_2_16  order_active_lb_1499  1
    order_2_16  order_active_ub_1500  1
    visit_2_17  out_degree_1503  -1
    visit_2_17  in_degree_1504  -1
    visit_2_17  order_active_lb_1505  -1
    visit_2_17  order_active_ub_1506  -11
    visit_2_17  service_visit_def_1507  -1
    order_2_17  connected_order_arc_1239  1
    order_2_17  connected_order_arc_1260  1
    order_2_17  connected_order_arc_1281  1
    order_2_17  connected_order_arc_1302  1
    order_2_17  connected_order_arc_1323  1
    order_2_17  connected_order_arc_1344  1
    order_2_17  connected_order_arc_1365  1
    order_2_17  connected_order_arc_1374  -1
    order_2_17  connected_order_arc_1376  -1
    order_2_17  connected_order_arc_1378  -1
    order_2_17  connected_order_arc_1380  -1
    order_2_17  connected_order_arc_1382  -1
    order_2_17  connected_order_arc_1384  -1
    order_2_17  connected_order_arc_1386  -1
    order_2_17  connected_order_arc_1388  -1
    order_2_17  connected_order_arc_1390  -1
    order_2_17  connected_order_arc_1392  -1
    order_2_17  connected_order_arc_1409  1
    order_2_17  connected_order_arc_1430  1
    order_2_17  connected_order_arc_1451  1
    order_2_17  order_active_lb_1505  1
    order_2_17  order_active_ub_1506  1
    visit_2_18  out_degree_1509  -1
    visit_2_18  in_degree_1510  -1
    visit_2_18  order_active_lb_1511  -1
    visit_2_18  order_active_ub_1512  -11
    visit_2_18  service_visit_def_1513  -1
    order_2_18  connected_order_arc_1241  1
    order_2_18  connected_order_arc_1262  1
    order_2_18  connected_order_arc_1283  1
    order_2_18  connected_order_arc_1304  1
    order_2_18  connected_order_arc_1325  1
    order_2_18  connected_order_arc_1346  1
    order_2_18  connected_order_arc_1367  1
    order_2_18  connected_order_arc_1388  1
    order_2_18  connected_order_arc_1395  -1
    order_2_18  connected_order_arc_1397  -1
    order_2_18  connected_order_arc_1399  -1
    order_2_18  connected_order_arc_1401  -1
    order_2_18  connected_order_arc_1403  -1
    order_2_18  connected_order_arc_1405  -1
    order_2_18  connected_order_arc_1407  -1
    order_2_18  connected_order_arc_1409  -1
    order_2_18  connected_order_arc_1411  -1
    order_2_18  connected_order_arc_1413  -1
    order_2_18  connected_order_arc_1432  1
    order_2_18  connected_order_arc_1453  1
    order_2_18  order_active_lb_1511  1
    order_2_18  order_active_ub_1512  1
    visit_2_19  out_degree_1515  -1
    visit_2_19  in_degree_1516  -1
    visit_2_19  order_active_lb_1517  -1
    visit_2_19  order_active_ub_1518  -11
    visit_2_19  service_visit_def_1519  -1
    order_2_19  connected_order_arc_1243  1
    order_2_19  connected_order_arc_1264  1
    order_2_19  connected_order_arc_1285  1
    order_2_19  connected_order_arc_1306  1
    order_2_19  connected_order_arc_1327  1
    order_2_19  connected_order_arc_1348  1
    order_2_19  connected_order_arc_1369  1
    order_2_19  connected_order_arc_1390  1
    order_2_19  connected_order_arc_1411  1
    order_2_19  connected_order_arc_1416  -1
    order_2_19  connected_order_arc_1418  -1
    order_2_19  connected_order_arc_1420  -1
    order_2_19  connected_order_arc_1422  -1
    order_2_19  connected_order_arc_1424  -1
    order_2_19  connected_order_arc_1426  -1
    order_2_19  connected_order_arc_1428  -1
    order_2_19  connected_order_arc_1430  -1
    order_2_19  connected_order_arc_1432  -1
    order_2_19  connected_order_arc_1434  -1
    order_2_19  connected_order_arc_1455  1
    order_2_19  order_active_lb_1517  1
    order_2_19  order_active_ub_1518  1
    visit_2_20  out_degree_1521  -1
    visit_2_20  in_degree_1522  -1
    visit_2_20  order_active_lb_1523  -1
    visit_2_20  order_active_ub_1524  -11
    visit_2_20  service_visit_def_1525  -1
    order_2_20  connected_order_arc_1245  1
    order_2_20  connected_order_arc_1266  1
    order_2_20  connected_order_arc_1287  1
    order_2_20  connected_order_arc_1308  1
    order_2_20  connected_order_arc_1329  1
    order_2_20  connected_order_arc_1350  1
    order_2_20  connected_order_arc_1371  1
    order_2_20  connected_order_arc_1392  1
    order_2_20  connected_order_arc_1413  1
    order_2_20  connected_order_arc_1434  1
    order_2_20  connected_order_arc_1437  -1
    order_2_20  connected_order_arc_1439  -1
    order_2_20  connected_order_arc_1441  -1
    order_2_20  connected_order_arc_1443  -1
    order_2_20  connected_order_arc_1445  -1
    order_2_20  connected_order_arc_1447  -1
    order_2_20  connected_order_arc_1449  -1
    order_2_20  connected_order_arc_1451  -1
    order_2_20  connected_order_arc_1453  -1
    order_2_20  connected_order_arc_1455  -1
    order_2_20  order_active_lb_1523  1
    order_2_20  order_active_ub_1524  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1213  -30
    arc_2_0_0  depot_departure_or_bypass_1456  1
    arc_2_0_0  depot_return_or_bypass_1457  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1213  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1214  -30
    arc_2_0_10  depot_departure_or_bypass_1456  1
    arc_2_0_10  in_degree_1459  1
    arc_2_0_10  original_T_including_depot_unload_1529  1.3396590612935172e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1214  1
    load_2_0_10  segment_load_conservation_1462  -1
    load_2_0_10  segment_prefix_lb_1463  1
    load_2_0_10  segment_prefix_ub_1464  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1215  -30
    arc_2_0_11  depot_departure_or_bypass_1456  1
    arc_2_0_11  in_degree_1466  1
    arc_2_0_11  original_T_including_depot_unload_1529  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1215  1
    load_2_0_11  segment_load_conservation_1469  -1
    load_2_0_11  segment_prefix_lb_1470  1
    load_2_0_11  segment_prefix_ub_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1216  -30
    arc_2_0_12  depot_departure_or_bypass_1456  1
    arc_2_0_12  in_degree_1473  1
    arc_2_0_12  original_T_including_depot_unload_1529  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1216  1
    load_2_0_12  segment_load_conservation_1476  -1
    load_2_0_12  segment_prefix_lb_1477  1
    load_2_0_12  segment_prefix_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1217  -30
    arc_2_0_13  depot_departure_or_bypass_1456  1
    arc_2_0_13  in_degree_1480  1
    arc_2_0_13  original_T_including_depot_unload_1529  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1217  1
    load_2_0_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1218  -30
    arc_2_0_14  depot_departure_or_bypass_1456  1
    arc_2_0_14  in_degree_1486  1
    arc_2_0_14  original_T_including_depot_unload_1529  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1218  1
    load_2_0_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1219  -30
    arc_2_0_15  depot_departure_or_bypass_1456  1
    arc_2_0_15  in_degree_1492  1
    arc_2_0_15  original_T_including_depot_unload_1529  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1219  1
    load_2_0_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1220  -30
    arc_2_0_16  depot_departure_or_bypass_1456  1
    arc_2_0_16  in_degree_1498  1
    arc_2_0_16  original_T_including_depot_unload_1529  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1220  1
    load_2_0_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1221  -30
    arc_2_0_17  depot_departure_or_bypass_1456  1
    arc_2_0_17  in_degree_1504  1
    arc_2_0_17  original_T_including_depot_unload_1529  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1221  1
    load_2_0_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1222  -30
    arc_2_0_18  depot_departure_or_bypass_1456  1
    arc_2_0_18  in_degree_1510  1
    arc_2_0_18  original_T_including_depot_unload_1529  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1222  1
    load_2_0_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1223  -30
    arc_2_0_19  depot_departure_or_bypass_1456  1
    arc_2_0_19  in_degree_1516  1
    arc_2_0_19  original_T_including_depot_unload_1529  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1223  1
    load_2_0_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1224  -30
    arc_2_0_20  depot_departure_or_bypass_1456  1
    arc_2_0_20  in_degree_1522  1
    arc_2_0_20  original_T_including_depot_unload_1529  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1224  1
    load_2_0_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1225  -30
    arc_2_10_0  depot_return_or_bypass_1457  1
    arc_2_10_0  out_degree_1458  1
    arc_2_10_0  original_T_including_depot_unload_1529  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1225  1
    load_2_10_0  segment_load_conservation_1462  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1226  -30
    arc_2_10_11  connected_order_arc_1227  -12
    arc_2_10_11  out_degree_1458  1
    arc_2_10_11  in_degree_1466  1
    arc_2_10_11  original_T_including_depot_unload_1529  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1226  1
    load_2_10_11  segment_load_conservation_1462  1
    load_2_10_11  segment_load_conservation_1469  -1
    load_2_10_11  segment_prefix_lb_1470  1
    load_2_10_11  segment_prefix_ub_1471  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1228  -30
    arc_2_10_12  connected_order_arc_1229  -12
    arc_2_10_12  out_degree_1458  1
    arc_2_10_12  in_degree_1473  1
    arc_2_10_12  original_T_including_depot_unload_1529  1.7571531345240103e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1228  1
    load_2_10_12  segment_load_conservation_1462  1
    load_2_10_12  segment_load_conservation_1476  -1
    load_2_10_12  segment_prefix_lb_1477  1
    load_2_10_12  segment_prefix_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1230  -30
    arc_2_10_13  connected_order_arc_1231  -12
    arc_2_10_13  out_degree_1458  1
    arc_2_10_13  in_degree_1480  1
    arc_2_10_13  original_T_including_depot_unload_1529  7.8947565022471792e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1230  1
    load_2_10_13  segment_load_conservation_1462  1
    load_2_10_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1232  -30
    arc_2_10_14  connected_order_arc_1233  -12
    arc_2_10_14  out_degree_1458  1
    arc_2_10_14  in_degree_1486  1
    arc_2_10_14  original_T_including_depot_unload_1529  5.5448403235604167e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1232  1
    load_2_10_14  segment_load_conservation_1462  1
    load_2_10_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1234  -30
    arc_2_10_15  connected_order_arc_1235  -12
    arc_2_10_15  out_degree_1458  1
    arc_2_10_15  in_degree_1492  1
    arc_2_10_15  original_T_including_depot_unload_1529  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1234  1
    load_2_10_15  segment_load_conservation_1462  1
    load_2_10_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1236  -30
    arc_2_10_16  connected_order_arc_1237  -12
    arc_2_10_16  out_degree_1458  1
    arc_2_10_16  in_degree_1498  1
    arc_2_10_16  original_T_including_depot_unload_1529  897.031483121361
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1236  1
    load_2_10_16  segment_load_conservation_1462  1
    load_2_10_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1238  -30
    arc_2_10_17  connected_order_arc_1239  -12
    arc_2_10_17  out_degree_1458  1
    arc_2_10_17  in_degree_1504  1
    arc_2_10_17  original_T_including_depot_unload_1529  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1238  1
    load_2_10_17  segment_load_conservation_1462  1
    load_2_10_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1240  -30
    arc_2_10_18  connected_order_arc_1241  -12
    arc_2_10_18  out_degree_1458  1
    arc_2_10_18  in_degree_1510  1
    arc_2_10_18  original_T_including_depot_unload_1529  6.2159179673866879e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1240  1
    load_2_10_18  segment_load_conservation_1462  1
    load_2_10_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1242  -30
    arc_2_10_19  connected_order_arc_1243  -12
    arc_2_10_19  out_degree_1458  1
    arc_2_10_19  in_degree_1516  1
    arc_2_10_19  original_T_including_depot_unload_1529  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1242  1
    load_2_10_19  segment_load_conservation_1462  1
    load_2_10_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1244  -30
    arc_2_10_20  connected_order_arc_1245  -12
    arc_2_10_20  out_degree_1458  1
    arc_2_10_20  in_degree_1522  1
    arc_2_10_20  original_T_including_depot_unload_1529  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1244  1
    load_2_10_20  segment_load_conservation_1462  1
    load_2_10_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1246  -30
    arc_2_11_0  depot_return_or_bypass_1457  1
    arc_2_11_0  out_degree_1465  1
    arc_2_11_0  original_T_including_depot_unload_1529  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1246  1
    load_2_11_0  segment_load_conservation_1469  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1247  -30
    arc_2_11_10  connected_order_arc_1248  -12
    arc_2_11_10  in_degree_1459  1
    arc_2_11_10  out_degree_1465  1
    arc_2_11_10  original_T_including_depot_unload_1529  2184.10509638866
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1247  1
    load_2_11_10  segment_load_conservation_1462  -1
    load_2_11_10  segment_prefix_lb_1463  1
    load_2_11_10  segment_prefix_ub_1464  1
    load_2_11_10  segment_load_conservation_1469  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1249  -30
    arc_2_11_12  connected_order_arc_1250  -12
    arc_2_11_12  out_degree_1465  1
    arc_2_11_12  in_degree_1473  1
    arc_2_11_12  original_T_including_depot_unload_1529  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1249  1
    load_2_11_12  segment_load_conservation_1469  1
    load_2_11_12  segment_load_conservation_1476  -1
    load_2_11_12  segment_prefix_lb_1477  1
    load_2_11_12  segment_prefix_ub_1478  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1251  -30
    arc_2_11_13  connected_order_arc_1252  -12
    arc_2_11_13  out_degree_1465  1
    arc_2_11_13  in_degree_1480  1
    arc_2_11_13  original_T_including_depot_unload_1529  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1251  1
    load_2_11_13  segment_load_conservation_1469  1
    load_2_11_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1253  -30
    arc_2_11_14  connected_order_arc_1254  -12
    arc_2_11_14  out_degree_1465  1
    arc_2_11_14  in_degree_1486  1
    arc_2_11_14  original_T_including_depot_unload_1529  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1253  1
    load_2_11_14  segment_load_conservation_1469  1
    load_2_11_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1255  -30
    arc_2_11_15  connected_order_arc_1256  -12
    arc_2_11_15  out_degree_1465  1
    arc_2_11_15  in_degree_1492  1
    arc_2_11_15  original_T_including_depot_unload_1529  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1255  1
    load_2_11_15  segment_load_conservation_1469  1
    load_2_11_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1257  -30
    arc_2_11_16  connected_order_arc_1258  -12
    arc_2_11_16  out_degree_1465  1
    arc_2_11_16  in_degree_1498  1
    arc_2_11_16  original_T_including_depot_unload_1529  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1257  1
    load_2_11_16  segment_load_conservation_1469  1
    load_2_11_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1259  -30
    arc_2_11_17  connected_order_arc_1260  -12
    arc_2_11_17  out_degree_1465  1
    arc_2_11_17  in_degree_1504  1
    arc_2_11_17  original_T_including_depot_unload_1529  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1259  1
    load_2_11_17  segment_load_conservation_1469  1
    load_2_11_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1261  -30
    arc_2_11_18  connected_order_arc_1262  -12
    arc_2_11_18  out_degree_1465  1
    arc_2_11_18  in_degree_1510  1
    arc_2_11_18  original_T_including_depot_unload_1529  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1261  1
    load_2_11_18  segment_load_conservation_1469  1
    load_2_11_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1263  -30
    arc_2_11_19  connected_order_arc_1264  -12
    arc_2_11_19  out_degree_1465  1
    arc_2_11_19  in_degree_1516  1
    arc_2_11_19  original_T_including_depot_unload_1529  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1263  1
    load_2_11_19  segment_load_conservation_1469  1
    load_2_11_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1265  -30
    arc_2_11_20  connected_order_arc_1266  -12
    arc_2_11_20  out_degree_1465  1
    arc_2_11_20  in_degree_1522  1
    arc_2_11_20  original_T_including_depot_unload_1529  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1265  1
    load_2_11_20  segment_load_conservation_1469  1
    load_2_11_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1267  -30
    arc_2_12_0  depot_return_or_bypass_1457  1
    arc_2_12_0  out_degree_1472  1
    arc_2_12_0  original_T_including_depot_unload_1529  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1267  1
    load_2_12_0  segment_load_conservation_1476  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1268  -30
    arc_2_12_10  connected_order_arc_1269  -12
    arc_2_12_10  in_degree_1459  1
    arc_2_12_10  out_degree_1472  1
    arc_2_12_10  original_T_including_depot_unload_1529  2362.83310343652
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1268  1
    load_2_12_10  segment_load_conservation_1462  -1
    load_2_12_10  segment_prefix_lb_1463  1
    load_2_12_10  segment_prefix_ub_1464  1
    load_2_12_10  segment_load_conservation_1476  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1270  -30
    arc_2_12_11  connected_order_arc_1271  -12
    arc_2_12_11  in_degree_1466  1
    arc_2_12_11  out_degree_1472  1
    arc_2_12_11  original_T_including_depot_unload_1529  1.8127468038796721e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1270  1
    load_2_12_11  segment_load_conservation_1469  -1
    load_2_12_11  segment_prefix_lb_1470  1
    load_2_12_11  segment_prefix_ub_1471  1
    load_2_12_11  segment_load_conservation_1476  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1272  -30
    arc_2_12_13  connected_order_arc_1273  -12
    arc_2_12_13  out_degree_1472  1
    arc_2_12_13  in_degree_1480  1
    arc_2_12_13  original_T_including_depot_unload_1529  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1272  1
    load_2_12_13  segment_load_conservation_1476  1
    load_2_12_13  free_load_conservation_1484  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1274  -30
    arc_2_12_14  connected_order_arc_1275  -12
    arc_2_12_14  out_degree_1472  1
    arc_2_12_14  in_degree_1486  1
    arc_2_12_14  original_T_including_depot_unload_1529  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1274  1
    load_2_12_14  segment_load_conservation_1476  1
    load_2_12_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1276  -30
    arc_2_12_15  connected_order_arc_1277  -12
    arc_2_12_15  out_degree_1472  1
    arc_2_12_15  in_degree_1492  1
    arc_2_12_15  original_T_including_depot_unload_1529  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1276  1
    load_2_12_15  segment_load_conservation_1476  1
    load_2_12_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1278  -30
    arc_2_12_16  connected_order_arc_1279  -12
    arc_2_12_16  out_degree_1472  1
    arc_2_12_16  in_degree_1498  1
    arc_2_12_16  original_T_including_depot_unload_1529  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1278  1
    load_2_12_16  segment_load_conservation_1476  1
    load_2_12_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1280  -30
    arc_2_12_17  connected_order_arc_1281  -12
    arc_2_12_17  out_degree_1472  1
    arc_2_12_17  in_degree_1504  1
    arc_2_12_17  original_T_including_depot_unload_1529  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1280  1
    load_2_12_17  segment_load_conservation_1476  1
    load_2_12_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1282  -30
    arc_2_12_18  connected_order_arc_1283  -12
    arc_2_12_18  out_degree_1472  1
    arc_2_12_18  in_degree_1510  1
    arc_2_12_18  original_T_including_depot_unload_1529  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1282  1
    load_2_12_18  segment_load_conservation_1476  1
    load_2_12_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1284  -30
    arc_2_12_19  connected_order_arc_1285  -12
    arc_2_12_19  out_degree_1472  1
    arc_2_12_19  in_degree_1516  1
    arc_2_12_19  original_T_including_depot_unload_1529  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1284  1
    load_2_12_19  segment_load_conservation_1476  1
    load_2_12_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1286  -30
    arc_2_12_20  connected_order_arc_1287  -12
    arc_2_12_20  out_degree_1472  1
    arc_2_12_20  in_degree_1522  1
    arc_2_12_20  original_T_including_depot_unload_1529  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1286  1
    load_2_12_20  segment_load_conservation_1476  1
    load_2_12_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1288  -30
    arc_2_13_0  depot_return_or_bypass_1457  1
    arc_2_13_0  out_degree_1479  1
    arc_2_13_0  original_T_including_depot_unload_1529  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1288  1
    load_2_13_0  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1289  -30
    arc_2_13_10  connected_order_arc_1290  -12
    arc_2_13_10  in_degree_1459  1
    arc_2_13_10  out_degree_1479  1
    arc_2_13_10  original_T_including_depot_unload_1529  1.2717918724165304e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1289  1
    load_2_13_10  segment_load_conservation_1462  -1
    load_2_13_10  segment_prefix_lb_1463  1
    load_2_13_10  segment_prefix_ub_1464  1
    load_2_13_10  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1291  -30
    arc_2_13_11  connected_order_arc_1292  -12
    arc_2_13_11  in_degree_1466  1
    arc_2_13_11  out_degree_1479  1
    arc_2_13_11  original_T_including_depot_unload_1529  1.1077505469776054e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1291  1
    load_2_13_11  segment_load_conservation_1469  -1
    load_2_13_11  segment_prefix_lb_1470  1
    load_2_13_11  segment_prefix_ub_1471  1
    load_2_13_11  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1293  -30
    arc_2_13_12  connected_order_arc_1294  -12
    arc_2_13_12  in_degree_1473  1
    arc_2_13_12  out_degree_1479  1
    arc_2_13_12  original_T_including_depot_unload_1529  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1293  1
    load_2_13_12  segment_load_conservation_1476  -1
    load_2_13_12  segment_prefix_lb_1477  1
    load_2_13_12  segment_prefix_ub_1478  1
    load_2_13_12  free_load_conservation_1484  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1295  -30
    arc_2_13_14  connected_order_arc_1296  -12
    arc_2_13_14  out_degree_1479  1
    arc_2_13_14  in_degree_1486  1
    arc_2_13_14  original_T_including_depot_unload_1529  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1295  1
    load_2_13_14  free_load_conservation_1484  1
    load_2_13_14  free_load_conservation_1490  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1297  -30
    arc_2_13_15  connected_order_arc_1298  -12
    arc_2_13_15  out_degree_1479  1
    arc_2_13_15  in_degree_1492  1
    arc_2_13_15  original_T_including_depot_unload_1529  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1297  1
    load_2_13_15  free_load_conservation_1484  1
    load_2_13_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1299  -30
    arc_2_13_16  connected_order_arc_1300  -12
    arc_2_13_16  out_degree_1479  1
    arc_2_13_16  in_degree_1498  1
    arc_2_13_16  original_T_including_depot_unload_1529  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1299  1
    load_2_13_16  free_load_conservation_1484  1
    load_2_13_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1301  -30
    arc_2_13_17  connected_order_arc_1302  -12
    arc_2_13_17  out_degree_1479  1
    arc_2_13_17  in_degree_1504  1
    arc_2_13_17  original_T_including_depot_unload_1529  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1301  1
    load_2_13_17  free_load_conservation_1484  1
    load_2_13_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1303  -30
    arc_2_13_18  connected_order_arc_1304  -12
    arc_2_13_18  out_degree_1479  1
    arc_2_13_18  in_degree_1510  1
    arc_2_13_18  original_T_including_depot_unload_1529  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1303  1
    load_2_13_18  free_load_conservation_1484  1
    load_2_13_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1305  -30
    arc_2_13_19  connected_order_arc_1306  -12
    arc_2_13_19  out_degree_1479  1
    arc_2_13_19  in_degree_1516  1
    arc_2_13_19  original_T_including_depot_unload_1529  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1305  1
    load_2_13_19  free_load_conservation_1484  1
    load_2_13_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1307  -30
    arc_2_13_20  connected_order_arc_1308  -12
    arc_2_13_20  out_degree_1479  1
    arc_2_13_20  in_degree_1522  1
    arc_2_13_20  original_T_including_depot_unload_1529  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1307  1
    load_2_13_20  free_load_conservation_1484  1
    load_2_13_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1309  -30
    arc_2_14_0  depot_return_or_bypass_1457  1
    arc_2_14_0  out_degree_1485  1
    arc_2_14_0  original_T_including_depot_unload_1529  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1309  1
    load_2_14_0  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1310  -30
    arc_2_14_10  connected_order_arc_1311  -12
    arc_2_14_10  in_degree_1459  1
    arc_2_14_10  out_degree_1485  1
    arc_2_14_10  original_T_including_depot_unload_1529  1.0363003610648061e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1310  1
    load_2_14_10  segment_load_conservation_1462  -1
    load_2_14_10  segment_prefix_lb_1463  1
    load_2_14_10  segment_prefix_ub_1464  1
    load_2_14_10  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1312  -30
    arc_2_14_11  connected_order_arc_1313  -12
    arc_2_14_11  in_degree_1466  1
    arc_2_14_11  out_degree_1485  1
    arc_2_14_11  original_T_including_depot_unload_1529  1.2528205851183418e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1312  1
    load_2_14_11  segment_load_conservation_1469  -1
    load_2_14_11  segment_prefix_lb_1470  1
    load_2_14_11  segment_prefix_ub_1471  1
    load_2_14_11  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1314  -30
    arc_2_14_12  connected_order_arc_1315  -12
    arc_2_14_12  in_degree_1473  1
    arc_2_14_12  out_degree_1485  1
    arc_2_14_12  original_T_including_depot_unload_1529  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1314  1
    load_2_14_12  segment_load_conservation_1476  -1
    load_2_14_12  segment_prefix_lb_1477  1
    load_2_14_12  segment_prefix_ub_1478  1
    load_2_14_12  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1316  -30
    arc_2_14_13  connected_order_arc_1317  -12
    arc_2_14_13  in_degree_1480  1
    arc_2_14_13  out_degree_1485  1
    arc_2_14_13  original_T_including_depot_unload_1529  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1316  1
    load_2_14_13  free_load_conservation_1484  -1
    load_2_14_13  free_load_conservation_1490  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1318  -30
    arc_2_14_15  connected_order_arc_1319  -12
    arc_2_14_15  out_degree_1485  1
    arc_2_14_15  in_degree_1492  1
    arc_2_14_15  original_T_including_depot_unload_1529  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1318  1
    load_2_14_15  free_load_conservation_1490  1
    load_2_14_15  free_load_conservation_1496  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1320  -30
    arc_2_14_16  connected_order_arc_1321  -12
    arc_2_14_16  out_degree_1485  1
    arc_2_14_16  in_degree_1498  1
    arc_2_14_16  original_T_including_depot_unload_1529  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1320  1
    load_2_14_16  free_load_conservation_1490  1
    load_2_14_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1322  -30
    arc_2_14_17  connected_order_arc_1323  -12
    arc_2_14_17  out_degree_1485  1
    arc_2_14_17  in_degree_1504  1
    arc_2_14_17  original_T_including_depot_unload_1529  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1322  1
    load_2_14_17  free_load_conservation_1490  1
    load_2_14_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1324  -30
    arc_2_14_18  connected_order_arc_1325  -12
    arc_2_14_18  out_degree_1485  1
    arc_2_14_18  in_degree_1510  1
    arc_2_14_18  original_T_including_depot_unload_1529  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1324  1
    load_2_14_18  free_load_conservation_1490  1
    load_2_14_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1326  -30
    arc_2_14_19  connected_order_arc_1327  -12
    arc_2_14_19  out_degree_1485  1
    arc_2_14_19  in_degree_1516  1
    arc_2_14_19  original_T_including_depot_unload_1529  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1326  1
    load_2_14_19  free_load_conservation_1490  1
    load_2_14_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1328  -30
    arc_2_14_20  connected_order_arc_1329  -12
    arc_2_14_20  out_degree_1485  1
    arc_2_14_20  in_degree_1522  1
    arc_2_14_20  original_T_including_depot_unload_1529  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1328  1
    load_2_14_20  free_load_conservation_1490  1
    load_2_14_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1330  -30
    arc_2_15_0  depot_return_or_bypass_1457  1
    arc_2_15_0  out_degree_1491  1
    arc_2_15_0  original_T_including_depot_unload_1529  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1330  1
    load_2_15_0  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1331  -30
    arc_2_15_10  connected_order_arc_1332  -12
    arc_2_15_10  in_degree_1459  1
    arc_2_15_10  out_degree_1491  1
    arc_2_15_10  original_T_including_depot_unload_1529  2.4147485851762935e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1331  1
    load_2_15_10  segment_load_conservation_1462  -1
    load_2_15_10  segment_prefix_lb_1463  1
    load_2_15_10  segment_prefix_ub_1464  1
    load_2_15_10  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1333  -30
    arc_2_15_11  connected_order_arc_1334  -12
    arc_2_15_11  in_degree_1466  1
    arc_2_15_11  out_degree_1491  1
    arc_2_15_11  original_T_including_depot_unload_1529  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1333  1
    load_2_15_11  segment_load_conservation_1469  -1
    load_2_15_11  segment_prefix_lb_1470  1
    load_2_15_11  segment_prefix_ub_1471  1
    load_2_15_11  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1335  -30
    arc_2_15_12  connected_order_arc_1336  -12
    arc_2_15_12  in_degree_1473  1
    arc_2_15_12  out_degree_1491  1
    arc_2_15_12  original_T_including_depot_unload_1529  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1335  1
    load_2_15_12  segment_load_conservation_1476  -1
    load_2_15_12  segment_prefix_lb_1477  1
    load_2_15_12  segment_prefix_ub_1478  1
    load_2_15_12  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1337  -30
    arc_2_15_13  connected_order_arc_1338  -12
    arc_2_15_13  in_degree_1480  1
    arc_2_15_13  out_degree_1491  1
    arc_2_15_13  original_T_including_depot_unload_1529  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1337  1
    load_2_15_13  free_load_conservation_1484  -1
    load_2_15_13  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1339  -30
    arc_2_15_14  connected_order_arc_1340  -12
    arc_2_15_14  in_degree_1486  1
    arc_2_15_14  out_degree_1491  1
    arc_2_15_14  original_T_including_depot_unload_1529  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1339  1
    load_2_15_14  free_load_conservation_1490  -1
    load_2_15_14  free_load_conservation_1496  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1341  -30
    arc_2_15_16  connected_order_arc_1342  -12
    arc_2_15_16  out_degree_1491  1
    arc_2_15_16  in_degree_1498  1
    arc_2_15_16  original_T_including_depot_unload_1529  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1341  1
    load_2_15_16  free_load_conservation_1496  1
    load_2_15_16  free_load_conservation_1502  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1343  -30
    arc_2_15_17  connected_order_arc_1344  -12
    arc_2_15_17  out_degree_1491  1
    arc_2_15_17  in_degree_1504  1
    arc_2_15_17  original_T_including_depot_unload_1529  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1343  1
    load_2_15_17  free_load_conservation_1496  1
    load_2_15_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1345  -30
    arc_2_15_18  connected_order_arc_1346  -12
    arc_2_15_18  out_degree_1491  1
    arc_2_15_18  in_degree_1510  1
    arc_2_15_18  original_T_including_depot_unload_1529  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1345  1
    load_2_15_18  free_load_conservation_1496  1
    load_2_15_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1347  -30
    arc_2_15_19  connected_order_arc_1348  -12
    arc_2_15_19  out_degree_1491  1
    arc_2_15_19  in_degree_1516  1
    arc_2_15_19  original_T_including_depot_unload_1529  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1347  1
    load_2_15_19  free_load_conservation_1496  1
    load_2_15_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1349  -30
    arc_2_15_20  connected_order_arc_1350  -12
    arc_2_15_20  out_degree_1491  1
    arc_2_15_20  in_degree_1522  1
    arc_2_15_20  original_T_including_depot_unload_1529  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1349  1
    load_2_15_20  free_load_conservation_1496  1
    load_2_15_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1351  -30
    arc_2_16_0  depot_return_or_bypass_1457  1
    arc_2_16_0  out_degree_1497  1
    arc_2_16_0  original_T_including_depot_unload_1529  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1351  1
    load_2_16_0  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1352  -30
    arc_2_16_10  connected_order_arc_1353  -12
    arc_2_16_10  in_degree_1459  1
    arc_2_16_10  out_degree_1497  1
    arc_2_16_10  original_T_including_depot_unload_1529  1.4399299780980639e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1352  1
    load_2_16_10  segment_load_conservation_1462  -1
    load_2_16_10  segment_prefix_lb_1463  1
    load_2_16_10  segment_prefix_ub_1464  1
    load_2_16_10  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1354  -30
    arc_2_16_11  connected_order_arc_1355  -12
    arc_2_16_11  in_degree_1466  1
    arc_2_16_11  out_degree_1497  1
    arc_2_16_11  original_T_including_depot_unload_1529  8.6622936529310709e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1354  1
    load_2_16_11  segment_load_conservation_1469  -1
    load_2_16_11  segment_prefix_lb_1470  1
    load_2_16_11  segment_prefix_ub_1471  1
    load_2_16_11  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1356  -30
    arc_2_16_12  connected_order_arc_1357  -12
    arc_2_16_12  in_degree_1473  1
    arc_2_16_12  out_degree_1497  1
    arc_2_16_12  original_T_including_depot_unload_1529  1.0428195034234207e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1356  1
    load_2_16_12  segment_load_conservation_1476  -1
    load_2_16_12  segment_prefix_lb_1477  1
    load_2_16_12  segment_prefix_ub_1478  1
    load_2_16_12  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1358  -30
    arc_2_16_13  connected_order_arc_1359  -12
    arc_2_16_13  in_degree_1480  1
    arc_2_16_13  out_degree_1497  1
    arc_2_16_13  original_T_including_depot_unload_1529  2.4191291221621205e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1358  1
    load_2_16_13  free_load_conservation_1484  -1
    load_2_16_13  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1360  -30
    arc_2_16_14  connected_order_arc_1361  -12
    arc_2_16_14  in_degree_1486  1
    arc_2_16_14  out_degree_1497  1
    arc_2_16_14  original_T_including_depot_unload_1529  4.1665889045115779e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1360  1
    load_2_16_14  free_load_conservation_1490  -1
    load_2_16_14  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1362  -30
    arc_2_16_15  connected_order_arc_1363  -12
    arc_2_16_15  in_degree_1492  1
    arc_2_16_15  out_degree_1497  1
    arc_2_16_15  original_T_including_depot_unload_1529  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1362  1
    load_2_16_15  free_load_conservation_1496  -1
    load_2_16_15  free_load_conservation_1502  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1364  -30
    arc_2_16_17  connected_order_arc_1365  -12
    arc_2_16_17  out_degree_1497  1
    arc_2_16_17  in_degree_1504  1
    arc_2_16_17  original_T_including_depot_unload_1529  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1364  1
    load_2_16_17  free_load_conservation_1502  1
    load_2_16_17  free_load_conservation_1508  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1366  -30
    arc_2_16_18  connected_order_arc_1367  -12
    arc_2_16_18  out_degree_1497  1
    arc_2_16_18  in_degree_1510  1
    arc_2_16_18  original_T_including_depot_unload_1529  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1366  1
    load_2_16_18  free_load_conservation_1502  1
    load_2_16_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1368  -30
    arc_2_16_19  connected_order_arc_1369  -12
    arc_2_16_19  out_degree_1497  1
    arc_2_16_19  in_degree_1516  1
    arc_2_16_19  original_T_including_depot_unload_1529  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1368  1
    load_2_16_19  free_load_conservation_1502  1
    load_2_16_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1370  -30
    arc_2_16_20  connected_order_arc_1371  -12
    arc_2_16_20  out_degree_1497  1
    arc_2_16_20  in_degree_1522  1
    arc_2_16_20  original_T_including_depot_unload_1529  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1370  1
    load_2_16_20  free_load_conservation_1502  1
    load_2_16_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1372  -30
    arc_2_17_0  depot_return_or_bypass_1457  1
    arc_2_17_0  out_degree_1503  1
    arc_2_17_0  original_T_including_depot_unload_1529  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1372  1
    load_2_17_0  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1373  -30
    arc_2_17_10  connected_order_arc_1374  -12
    arc_2_17_10  in_degree_1459  1
    arc_2_17_10  out_degree_1503  1
    arc_2_17_10  original_T_including_depot_unload_1529  2.1214998192647863e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1373  1
    load_2_17_10  segment_load_conservation_1462  -1
    load_2_17_10  segment_prefix_lb_1463  1
    load_2_17_10  segment_prefix_ub_1464  1
    load_2_17_10  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1375  -30
    arc_2_17_11  connected_order_arc_1376  -12
    arc_2_17_11  in_degree_1466  1
    arc_2_17_11  out_degree_1503  1
    arc_2_17_11  original_T_including_depot_unload_1529  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1375  1
    load_2_17_11  segment_load_conservation_1469  -1
    load_2_17_11  segment_prefix_lb_1470  1
    load_2_17_11  segment_prefix_ub_1471  1
    load_2_17_11  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1377  -30
    arc_2_17_12  connected_order_arc_1378  -12
    arc_2_17_12  in_degree_1473  1
    arc_2_17_12  out_degree_1503  1
    arc_2_17_12  original_T_including_depot_unload_1529  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1377  1
    load_2_17_12  segment_load_conservation_1476  -1
    load_2_17_12  segment_prefix_lb_1477  1
    load_2_17_12  segment_prefix_ub_1478  1
    load_2_17_12  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1379  -30
    arc_2_17_13  connected_order_arc_1380  -12
    arc_2_17_13  in_degree_1480  1
    arc_2_17_13  out_degree_1503  1
    arc_2_17_13  original_T_including_depot_unload_1529  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1379  1
    load_2_17_13  free_load_conservation_1484  -1
    load_2_17_13  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1381  -30
    arc_2_17_14  connected_order_arc_1382  -12
    arc_2_17_14  in_degree_1486  1
    arc_2_17_14  out_degree_1503  1
    arc_2_17_14  original_T_including_depot_unload_1529  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1381  1
    load_2_17_14  free_load_conservation_1490  -1
    load_2_17_14  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1383  -30
    arc_2_17_15  connected_order_arc_1384  -12
    arc_2_17_15  in_degree_1492  1
    arc_2_17_15  out_degree_1503  1
    arc_2_17_15  original_T_including_depot_unload_1529  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1383  1
    load_2_17_15  free_load_conservation_1496  -1
    load_2_17_15  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1385  -30
    arc_2_17_16  connected_order_arc_1386  -12
    arc_2_17_16  in_degree_1498  1
    arc_2_17_16  out_degree_1503  1
    arc_2_17_16  original_T_including_depot_unload_1529  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1385  1
    load_2_17_16  free_load_conservation_1502  -1
    load_2_17_16  free_load_conservation_1508  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1387  -30
    arc_2_17_18  connected_order_arc_1388  -12
    arc_2_17_18  out_degree_1503  1
    arc_2_17_18  in_degree_1510  1
    arc_2_17_18  original_T_including_depot_unload_1529  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1387  1
    load_2_17_18  free_load_conservation_1508  1
    load_2_17_18  free_load_conservation_1514  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1389  -30
    arc_2_17_19  connected_order_arc_1390  -12
    arc_2_17_19  out_degree_1503  1
    arc_2_17_19  in_degree_1516  1
    arc_2_17_19  original_T_including_depot_unload_1529  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1389  1
    load_2_17_19  free_load_conservation_1508  1
    load_2_17_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1391  -30
    arc_2_17_20  connected_order_arc_1392  -12
    arc_2_17_20  out_degree_1503  1
    arc_2_17_20  in_degree_1522  1
    arc_2_17_20  original_T_including_depot_unload_1529  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1391  1
    load_2_17_20  free_load_conservation_1508  1
    load_2_17_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1393  -30
    arc_2_18_0  depot_return_or_bypass_1457  1
    arc_2_18_0  out_degree_1509  1
    arc_2_18_0  original_T_including_depot_unload_1529  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1393  1
    load_2_18_0  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1394  -30
    arc_2_18_10  connected_order_arc_1395  -12
    arc_2_18_10  in_degree_1459  1
    arc_2_18_10  out_degree_1509  1
    arc_2_18_10  original_T_including_depot_unload_1529  1.1989066345879348e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1394  1
    load_2_18_10  segment_load_conservation_1462  -1
    load_2_18_10  segment_prefix_lb_1463  1
    load_2_18_10  segment_prefix_ub_1464  1
    load_2_18_10  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1396  -30
    arc_2_18_11  connected_order_arc_1397  -12
    arc_2_18_11  in_degree_1466  1
    arc_2_18_11  out_degree_1509  1
    arc_2_18_11  original_T_including_depot_unload_1529  1.0036317427965961e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1396  1
    load_2_18_11  segment_load_conservation_1469  -1
    load_2_18_11  segment_prefix_lb_1470  1
    load_2_18_11  segment_prefix_ub_1471  1
    load_2_18_11  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1398  -30
    arc_2_18_12  connected_order_arc_1399  -12
    arc_2_18_12  in_degree_1473  1
    arc_2_18_12  out_degree_1509  1
    arc_2_18_12  original_T_including_depot_unload_1529  1.1848225970179703e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1398  1
    load_2_18_12  segment_load_conservation_1476  -1
    load_2_18_12  segment_prefix_lb_1477  1
    load_2_18_12  segment_prefix_ub_1478  1
    load_2_18_12  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1400  -30
    arc_2_18_13  connected_order_arc_1401  -12
    arc_2_18_13  in_degree_1480  1
    arc_2_18_13  out_degree_1509  1
    arc_2_18_13  original_T_including_depot_unload_1529  3.2938591738444967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1400  1
    load_2_18_13  free_load_conservation_1484  -1
    load_2_18_13  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1402  -30
    arc_2_18_14  connected_order_arc_1403  -12
    arc_2_18_14  in_degree_1486  1
    arc_2_18_14  out_degree_1509  1
    arc_2_18_14  original_T_including_depot_unload_1529  2.9098466309579254e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1402  1
    load_2_18_14  free_load_conservation_1490  -1
    load_2_18_14  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1404  -30
    arc_2_18_15  connected_order_arc_1405  -12
    arc_2_18_15  in_degree_1492  1
    arc_2_18_15  out_degree_1509  1
    arc_2_18_15  original_T_including_depot_unload_1529  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1404  1
    load_2_18_15  free_load_conservation_1496  -1
    load_2_18_15  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1406  -30
    arc_2_18_16  connected_order_arc_1407  -12
    arc_2_18_16  in_degree_1498  1
    arc_2_18_16  out_degree_1509  1
    arc_2_18_16  original_T_including_depot_unload_1529  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1406  1
    load_2_18_16  free_load_conservation_1502  -1
    load_2_18_16  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1408  -30
    arc_2_18_17  connected_order_arc_1409  -12
    arc_2_18_17  in_degree_1504  1
    arc_2_18_17  out_degree_1509  1
    arc_2_18_17  original_T_including_depot_unload_1529  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1408  1
    load_2_18_17  free_load_conservation_1508  -1
    load_2_18_17  free_load_conservation_1514  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1410  -30
    arc_2_18_19  connected_order_arc_1411  -12
    arc_2_18_19  out_degree_1509  1
    arc_2_18_19  in_degree_1516  1
    arc_2_18_19  original_T_including_depot_unload_1529  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1410  1
    load_2_18_19  free_load_conservation_1514  1
    load_2_18_19  free_load_conservation_1520  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1412  -30
    arc_2_18_20  connected_order_arc_1413  -12
    arc_2_18_20  out_degree_1509  1
    arc_2_18_20  in_degree_1522  1
    arc_2_18_20  original_T_including_depot_unload_1529  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1412  1
    load_2_18_20  free_load_conservation_1514  1
    load_2_18_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1414  -30
    arc_2_19_0  depot_return_or_bypass_1457  1
    arc_2_19_0  out_degree_1515  1
    arc_2_19_0  original_T_including_depot_unload_1529  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1414  1
    load_2_19_0  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1415  -30
    arc_2_19_10  connected_order_arc_1416  -12
    arc_2_19_10  in_degree_1459  1
    arc_2_19_10  out_degree_1515  1
    arc_2_19_10  original_T_including_depot_unload_1529  1.5963399698511002e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1415  1
    load_2_19_10  segment_load_conservation_1462  -1
    load_2_19_10  segment_prefix_lb_1463  1
    load_2_19_10  segment_prefix_ub_1464  1
    load_2_19_10  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1417  -30
    arc_2_19_11  connected_order_arc_1418  -12
    arc_2_19_11  in_degree_1466  1
    arc_2_19_11  out_degree_1515  1
    arc_2_19_11  original_T_including_depot_unload_1529  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1417  1
    load_2_19_11  segment_load_conservation_1469  -1
    load_2_19_11  segment_prefix_lb_1470  1
    load_2_19_11  segment_prefix_ub_1471  1
    load_2_19_11  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1419  -30
    arc_2_19_12  connected_order_arc_1420  -12
    arc_2_19_12  in_degree_1473  1
    arc_2_19_12  out_degree_1515  1
    arc_2_19_12  original_T_including_depot_unload_1529  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1419  1
    load_2_19_12  segment_load_conservation_1476  -1
    load_2_19_12  segment_prefix_lb_1477  1
    load_2_19_12  segment_prefix_ub_1478  1
    load_2_19_12  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1421  -30
    arc_2_19_13  connected_order_arc_1422  -12
    arc_2_19_13  in_degree_1480  1
    arc_2_19_13  out_degree_1515  1
    arc_2_19_13  original_T_including_depot_unload_1529  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1421  1
    load_2_19_13  free_load_conservation_1484  -1
    load_2_19_13  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1423  -30
    arc_2_19_14  connected_order_arc_1424  -12
    arc_2_19_14  in_degree_1486  1
    arc_2_19_14  out_degree_1515  1
    arc_2_19_14  original_T_including_depot_unload_1529  6.3111682574558915e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1423  1
    load_2_19_14  free_load_conservation_1490  -1
    load_2_19_14  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1425  -30
    arc_2_19_15  connected_order_arc_1426  -12
    arc_2_19_15  in_degree_1492  1
    arc_2_19_15  out_degree_1515  1
    arc_2_19_15  original_T_including_depot_unload_1529  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1425  1
    load_2_19_15  free_load_conservation_1496  -1
    load_2_19_15  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1427  -30
    arc_2_19_16  connected_order_arc_1428  -12
    arc_2_19_16  in_degree_1498  1
    arc_2_19_16  out_degree_1515  1
    arc_2_19_16  original_T_including_depot_unload_1529  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1427  1
    load_2_19_16  free_load_conservation_1502  -1
    load_2_19_16  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1429  -30
    arc_2_19_17  connected_order_arc_1430  -12
    arc_2_19_17  in_degree_1504  1
    arc_2_19_17  out_degree_1515  1
    arc_2_19_17  original_T_including_depot_unload_1529  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1429  1
    load_2_19_17  free_load_conservation_1508  -1
    load_2_19_17  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1431  -30
    arc_2_19_18  connected_order_arc_1432  -12
    arc_2_19_18  in_degree_1510  1
    arc_2_19_18  out_degree_1515  1
    arc_2_19_18  original_T_including_depot_unload_1529  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1431  1
    load_2_19_18  free_load_conservation_1514  -1
    load_2_19_18  free_load_conservation_1520  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1433  -30
    arc_2_19_20  connected_order_arc_1434  -12
    arc_2_19_20  out_degree_1515  1
    arc_2_19_20  in_degree_1522  1
    arc_2_19_20  original_T_including_depot_unload_1529  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1433  1
    load_2_19_20  free_load_conservation_1520  1
    load_2_19_20  free_load_conservation_1526  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1435  -30
    arc_2_20_0  depot_return_or_bypass_1457  1
    arc_2_20_0  out_degree_1521  1
    arc_2_20_0  original_T_including_depot_unload_1529  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1435  1
    load_2_20_0  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1436  -30
    arc_2_20_10  connected_order_arc_1437  -12
    arc_2_20_10  in_degree_1459  1
    arc_2_20_10  out_degree_1521  1
    arc_2_20_10  original_T_including_depot_unload_1529  1.4593103211867947e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1436  1
    load_2_20_10  segment_load_conservation_1462  -1
    load_2_20_10  segment_prefix_lb_1463  1
    load_2_20_10  segment_prefix_ub_1464  1
    load_2_20_10  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1438  -30
    arc_2_20_11  connected_order_arc_1439  -12
    arc_2_20_11  in_degree_1466  1
    arc_2_20_11  out_degree_1521  1
    arc_2_20_11  original_T_including_depot_unload_1529  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1438  1
    load_2_20_11  segment_load_conservation_1469  -1
    load_2_20_11  segment_prefix_lb_1470  1
    load_2_20_11  segment_prefix_ub_1471  1
    load_2_20_11  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1440  -30
    arc_2_20_12  connected_order_arc_1441  -12
    arc_2_20_12  in_degree_1473  1
    arc_2_20_12  out_degree_1521  1
    arc_2_20_12  original_T_including_depot_unload_1529  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1440  1
    load_2_20_12  segment_load_conservation_1476  -1
    load_2_20_12  segment_prefix_lb_1477  1
    load_2_20_12  segment_prefix_ub_1478  1
    load_2_20_12  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1442  -30
    arc_2_20_13  connected_order_arc_1443  -12
    arc_2_20_13  in_degree_1480  1
    arc_2_20_13  out_degree_1521  1
    arc_2_20_13  original_T_including_depot_unload_1529  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1442  1
    load_2_20_13  free_load_conservation_1484  -1
    load_2_20_13  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1444  -30
    arc_2_20_14  connected_order_arc_1445  -12
    arc_2_20_14  in_degree_1486  1
    arc_2_20_14  out_degree_1521  1
    arc_2_20_14  original_T_including_depot_unload_1529  5.3713048648006088e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1444  1
    load_2_20_14  free_load_conservation_1490  -1
    load_2_20_14  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1446  -30
    arc_2_20_15  connected_order_arc_1447  -12
    arc_2_20_15  in_degree_1492  1
    arc_2_20_15  out_degree_1521  1
    arc_2_20_15  original_T_including_depot_unload_1529  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1446  1
    load_2_20_15  free_load_conservation_1496  -1
    load_2_20_15  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1448  -30
    arc_2_20_16  connected_order_arc_1449  -12
    arc_2_20_16  in_degree_1498  1
    arc_2_20_16  out_degree_1521  1
    arc_2_20_16  original_T_including_depot_unload_1529  5.1177250003741761e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1448  1
    load_2_20_16  free_load_conservation_1502  -1
    load_2_20_16  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1450  -30
    arc_2_20_17  connected_order_arc_1451  -12
    arc_2_20_17  in_degree_1504  1
    arc_2_20_17  out_degree_1521  1
    arc_2_20_17  original_T_including_depot_unload_1529  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1450  1
    load_2_20_17  free_load_conservation_1508  -1
    load_2_20_17  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1452  -30
    arc_2_20_18  connected_order_arc_1453  -12
    arc_2_20_18  in_degree_1510  1
    arc_2_20_18  out_degree_1521  1
    arc_2_20_18  original_T_including_depot_unload_1529  6.8881953094806647e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1452  1
    load_2_20_18  free_load_conservation_1514  -1
    load_2_20_18  free_load_conservation_1526  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1454  -30
    arc_2_20_19  connected_order_arc_1455  -12
    arc_2_20_19  in_degree_1516  1
    arc_2_20_19  out_degree_1521  1
    arc_2_20_19  original_T_including_depot_unload_1529  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1454  1
    load_2_20_19  free_load_conservation_1520  -1
    load_2_20_19  free_load_conservation_1526  1
RHS
    RHS1      OBJ       -4.5824999999999994e-01
    RHS1      onehot_9_26  1
    RHS1      onehot_6_51  1
    RHS1      onehot_31_80  1
    RHS1      onehot_15_117  1
    RHS1      onehot_32_146  1
    RHS1      onehot_13_189  1
    RHS1      onehot_19_210  1
    RHS1      onehot_12_245  1
    RHS1      stock_ub_249  32
    RHS1      parent_nonstrict_scope_250  3.6813736343383596e-01
    RHS1      normalization_307  1
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_451  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_476  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_501  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_526  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_551  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_576  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_601  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_626  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_651  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_676  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_695  -13
    RHS1      connected_order_arc_697  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_701  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_710  -13
    RHS1      connected_order_arc_712  -13
    RHS1      connected_order_arc_714  -13
    RHS1      connected_order_arc_716  -13
    RHS1      connected_order_arc_718  -13
    RHS1      connected_order_arc_720  -13
    RHS1      connected_order_arc_722  -13
    RHS1      connected_order_arc_724  -13
    RHS1      connected_order_arc_726  -13
    RHS1      connected_order_arc_729  -13
    RHS1      connected_order_arc_731  -13
    RHS1      connected_order_arc_733  -13
    RHS1      connected_order_arc_735  -13
    RHS1      connected_order_arc_737  -13
    RHS1      connected_order_arc_739  -13
    RHS1      connected_order_arc_741  -13
    RHS1      connected_order_arc_743  -13
    RHS1      connected_order_arc_745  -13
    RHS1      connected_order_arc_747  -13
    RHS1      connected_order_arc_749  -13
    RHS1      connected_order_arc_751  -13
    RHS1      depot_departure_or_bypass_752  1
    RHS1      depot_return_or_bypass_753  1
    RHS1      segment_load_conservation_758  10
    RHS1      segment_prefix_ub_760  2
    RHS1      segment_load_conservation_765  -5
    RHS1      segment_prefix_lb_766  5
    RHS1      segment_prefix_ub_767  20
    RHS1      segment_load_conservation_772  -4
    RHS1      segment_prefix_lb_773  4
    RHS1      segment_prefix_ub_774  20
    RHS1      segment_load_conservation_779  5
    RHS1      segment_prefix_ub_781  15
    RHS1      segment_load_conservation_786  -6
    RHS1      segment_prefix_lb_787  6
    RHS1      segment_prefix_ub_788  20
    RHS1      fixed_segment_relative_order_837  1
    RHS1      fixed_segment_relative_order_838  1
    RHS1      fixed_segment_relative_order_839  1
    RHS1      fixed_segment_relative_order_840  1
    RHS1      original_T_including_depot_unload_841  3.2009165200617390e+03
    RHS1      connected_order_arc_857  -12
    RHS1      connected_order_arc_859  -12
    RHS1      connected_order_arc_861  -12
    RHS1      connected_order_arc_863  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_880  -12
    RHS1      connected_order_arc_882  -12
    RHS1      connected_order_arc_884  -12
    RHS1      connected_order_arc_886  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_903  -12
    RHS1      connected_order_arc_905  -12
    RHS1      connected_order_arc_907  -12
    RHS1      connected_order_arc_909  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_926  -12
    RHS1      connected_order_arc_928  -12
    RHS1      connected_order_arc_930  -12
    RHS1      connected_order_arc_932  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_949  -12
    RHS1      connected_order_arc_951  -12
    RHS1      connected_order_arc_953  -12
    RHS1      connected_order_arc_955  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_972  -12
    RHS1      connected_order_arc_974  -12
    RHS1      connected_order_arc_976  -12
    RHS1      connected_order_arc_978  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_995  -12
    RHS1      connected_order_arc_997  -12
    RHS1      connected_order_arc_999  -12
    RHS1      connected_order_arc_1001  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1018  -12
    RHS1      connected_order_arc_1020  -12
    RHS1      connected_order_arc_1022  -12
    RHS1      connected_order_arc_1024  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1041  -12
    RHS1      connected_order_arc_1043  -12
    RHS1      connected_order_arc_1045  -12
    RHS1      connected_order_arc_1047  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1064  -12
    RHS1      connected_order_arc_1066  -12
    RHS1      connected_order_arc_1068  -12
    RHS1      connected_order_arc_1070  -12
    RHS1      connected_order_arc_1072  -12
    RHS1      connected_order_arc_1074  -12
    RHS1      connected_order_arc_1076  -12
    RHS1      connected_order_arc_1078  -12
    RHS1      connected_order_arc_1080  -12
    RHS1      connected_order_arc_1082  -12
    RHS1      connected_order_arc_1084  -12
    RHS1      connected_order_arc_1087  -12
    RHS1      connected_order_arc_1089  -12
    RHS1      connected_order_arc_1091  -12
    RHS1      connected_order_arc_1093  -12
    RHS1      connected_order_arc_1095  -12
    RHS1      connected_order_arc_1097  -12
    RHS1      connected_order_arc_1099  -12
    RHS1      connected_order_arc_1101  -12
    RHS1      connected_order_arc_1103  -12
    RHS1      connected_order_arc_1105  -12
    RHS1      connected_order_arc_1107  -12
    RHS1      connected_order_arc_1110  -12
    RHS1      connected_order_arc_1112  -12
    RHS1      connected_order_arc_1114  -12
    RHS1      connected_order_arc_1116  -12
    RHS1      connected_order_arc_1118  -12
    RHS1      connected_order_arc_1120  -12
    RHS1      connected_order_arc_1122  -12
    RHS1      connected_order_arc_1124  -12
    RHS1      connected_order_arc_1126  -12
    RHS1      connected_order_arc_1128  -12
    RHS1      connected_order_arc_1130  -12
    RHS1      depot_departure_or_bypass_1131  1
    RHS1      depot_return_or_bypass_1132  1
    RHS1      segment_load_conservation_1137  4
    RHS1      segment_prefix_ub_1139  21
    RHS1      segment_load_conservation_1144  3
    RHS1      segment_prefix_ub_1146  22
    RHS1      segment_load_conservation_1151  -5
    RHS1      segment_prefix_lb_1152  5
    RHS1      segment_prefix_ub_1153  25
    RHS1      segment_load_conservation_1158  -1
    RHS1      segment_prefix_lb_1159  2
    RHS1      segment_prefix_ub_1160  16
    RHS1      fixed_segment_relative_order_1209  1
    RHS1      fixed_segment_relative_order_1210  1
    RHS1      fixed_segment_relative_order_1211  1
    RHS1      original_T_including_depot_unload_1212  2.5466013138995804e+03
    RHS1      connected_order_arc_1227  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1248  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1269  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1290  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1311  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1332  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1353  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1374  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1395  -11
    RHS1      connected_order_arc_1397  -11
    RHS1      connected_order_arc_1399  -11
    RHS1      connected_order_arc_1401  -11
    RHS1      connected_order_arc_1403  -11
    RHS1      connected_order_arc_1405  -11
    RHS1      connected_order_arc_1407  -11
    RHS1      connected_order_arc_1409  -11
    RHS1      connected_order_arc_1411  -11
    RHS1      connected_order_arc_1413  -11
    RHS1      connected_order_arc_1416  -11
    RHS1      connected_order_arc_1418  -11
    RHS1      connected_order_arc_1420  -11
    RHS1      connected_order_arc_1422  -11
    RHS1      connected_order_arc_1424  -11
    RHS1      connected_order_arc_1426  -11
    RHS1      connected_order_arc_1428  -11
    RHS1      connected_order_arc_1430  -11
    RHS1      connected_order_arc_1432  -11
    RHS1      connected_order_arc_1434  -11
    RHS1      connected_order_arc_1437  -11
    RHS1      connected_order_arc_1439  -11
    RHS1      connected_order_arc_1441  -11
    RHS1      connected_order_arc_1443  -11
    RHS1      connected_order_arc_1445  -11
    RHS1      connected_order_arc_1447  -11
    RHS1      connected_order_arc_1449  -11
    RHS1      connected_order_arc_1451  -11
    RHS1      connected_order_arc_1453  -11
    RHS1      connected_order_arc_1455  -11
    RHS1      depot_departure_or_bypass_1456  1
    RHS1      depot_return_or_bypass_1457  1
    RHS1      segment_prefix_ub_1464  25
    RHS1      segment_load_conservation_1469  1
    RHS1      segment_prefix_ub_1471  29
    RHS1      segment_load_conservation_1476  3
    RHS1      segment_prefix_ub_1478  27
    RHS1      fixed_segment_relative_order_1527  1
    RHS1      fixed_segment_relative_order_1528  1
    RHS1      original_T_including_depot_unload_1529  5.1269329281192686e+03
BOUNDS
 LO BND1      t         2.4497414161813971e-02
 UP BND1      t         4.1648073776629491e-02
 UP BND1      q         0.537637363433836
 BV BND1      x_9_0   
 UP BND1      w_9_0     4.1648073776629491e-02
 BV BND1      x_9_1   
 UP BND1      w_9_1     4.1648073776629491e-02
 BV BND1      x_9_2   
 UP BND1      w_9_2     4.1648073776629491e-02
 BV BND1      x_9_3   
 UP BND1      w_9_3     4.1648073776629491e-02
 BV BND1      x_9_4   
 UP BND1      w_9_4     4.1648073776629491e-02
 BV BND1      x_9_5   
 UP BND1      w_9_5     4.1648073776629491e-02
 BV BND1      x_9_6   
 UP BND1      w_9_6     4.1648073776629491e-02
 BV BND1      x_9_7   
 UP BND1      w_9_7     4.1648073776629491e-02
 BV BND1      x_9_8   
 UP BND1      w_9_8     4.1648073776629491e-02
 BV BND1      x_9_9   
 UP BND1      w_9_9     4.1648073776629491e-02
 BV BND1      x_9_10  
 UP BND1      w_9_10    4.1648073776629491e-02
 BV BND1      x_9_11  
 UP BND1      w_9_11    4.1648073776629491e-02
 BV BND1      x_9_12  
 UP BND1      w_9_12    4.1648073776629491e-02
 UP BND1      rho_9     1
 BV BND1      x_6_0   
 UP BND1      w_6_0     4.1648073776629491e-02
 BV BND1      x_6_1   
 UP BND1      w_6_1     4.1648073776629491e-02
 BV BND1      x_6_2   
 UP BND1      w_6_2     4.1648073776629491e-02
 BV BND1      x_6_3   
 UP BND1      w_6_3     4.1648073776629491e-02
 BV BND1      x_6_4   
 UP BND1      w_6_4     4.1648073776629491e-02
 BV BND1      x_6_5   
 UP BND1      w_6_5     4.1648073776629491e-02
 BV BND1      x_6_6   
 UP BND1      w_6_6     4.1648073776629491e-02
 BV BND1      x_6_7   
 UP BND1      w_6_7     4.1648073776629491e-02
 BV BND1      x_6_8   
 UP BND1      w_6_8     4.1648073776629491e-02
 BV BND1      x_6_9   
 UP BND1      w_6_9     4.1648073776629491e-02
 BV BND1      x_6_10  
 UP BND1      w_6_10    4.1648073776629491e-02
 UP BND1      rho_6     1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1648073776629491e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1648073776629491e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1648073776629491e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1648073776629491e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1648073776629491e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1648073776629491e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1648073776629491e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1648073776629491e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1648073776629491e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1648073776629491e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1648073776629491e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1648073776629491e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1648073776629491e-02
 UP BND1      rho_31    1
 BV BND1      x_15_0  
 UP BND1      w_15_0    4.1648073776629491e-02
 BV BND1      x_15_1  
 UP BND1      w_15_1    4.1648073776629491e-02
 BV BND1      x_15_2  
 UP BND1      w_15_2    4.1648073776629491e-02
 BV BND1      x_15_3  
 UP BND1      w_15_3    4.1648073776629491e-02
 BV BND1      x_15_4  
 UP BND1      w_15_4    4.1648073776629491e-02
 BV BND1      x_15_5  
 UP BND1      w_15_5    4.1648073776629491e-02
 BV BND1      x_15_6  
 UP BND1      w_15_6    4.1648073776629491e-02
 BV BND1      x_15_7  
 UP BND1      w_15_7    4.1648073776629491e-02
 BV BND1      x_15_8  
 UP BND1      w_15_8    4.1648073776629491e-02
 BV BND1      x_15_9  
 UP BND1      w_15_9    4.1648073776629491e-02
 BV BND1      x_15_10 
 UP BND1      w_15_10   4.1648073776629491e-02
 BV BND1      x_15_11 
 UP BND1      w_15_11   4.1648073776629491e-02
 BV BND1      x_15_12 
 UP BND1      w_15_12   4.1648073776629491e-02
 BV BND1      x_15_13 
 UP BND1      w_15_13   4.1648073776629491e-02
 BV BND1      x_15_14 
 UP BND1      w_15_14   4.1648073776629491e-02
 BV BND1      x_15_15 
 UP BND1      w_15_15   4.1648073776629491e-02
 BV BND1      x_15_16 
 UP BND1      w_15_16   4.1648073776629491e-02
 UP BND1      rho_15    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1648073776629491e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1648073776629491e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1648073776629491e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1648073776629491e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1648073776629491e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1648073776629491e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1648073776629491e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1648073776629491e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1648073776629491e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1648073776629491e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1648073776629491e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1648073776629491e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1648073776629491e-02
 UP BND1      rho_32    1
 BV BND1      x_13_0  
 UP BND1      w_13_0    4.1648073776629491e-02
 BV BND1      x_13_1  
 UP BND1      w_13_1    4.1648073776629491e-02
 BV BND1      x_13_2  
 UP BND1      w_13_2    4.1648073776629491e-02
 BV BND1      x_13_3  
 UP BND1      w_13_3    4.1648073776629491e-02
 BV BND1      x_13_4  
 UP BND1      w_13_4    4.1648073776629491e-02
 BV BND1      x_13_5  
 UP BND1      w_13_5    4.1648073776629491e-02
 BV BND1      x_13_6  
 UP BND1      w_13_6    4.1648073776629491e-02
 BV BND1      x_13_7  
 UP BND1      w_13_7    4.1648073776629491e-02
 BV BND1      x_13_8  
 UP BND1      w_13_8    4.1648073776629491e-02
 BV BND1      x_13_9  
 UP BND1      w_13_9    4.1648073776629491e-02
 BV BND1      x_13_10 
 UP BND1      w_13_10   4.1648073776629491e-02
 BV BND1      x_13_11 
 UP BND1      w_13_11   4.1648073776629491e-02
 BV BND1      x_13_12 
 UP BND1      w_13_12   4.1648073776629491e-02
 BV BND1      x_13_13 
 UP BND1      w_13_13   4.1648073776629491e-02
 BV BND1      x_13_14 
 UP BND1      w_13_14   4.1648073776629491e-02
 BV BND1      x_13_15 
 UP BND1      w_13_15   4.1648073776629491e-02
 BV BND1      x_13_16 
 UP BND1      w_13_16   4.1648073776629491e-02
 BV BND1      x_13_17 
 UP BND1      w_13_17   4.1648073776629491e-02
 BV BND1      x_13_18 
 UP BND1      w_13_18   4.1648073776629491e-02
 BV BND1      x_13_19 
 UP BND1      w_13_19   4.1648073776629491e-02
 UP BND1      rho_13    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.1648073776629491e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.1648073776629491e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.1648073776629491e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.1648073776629491e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.1648073776629491e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.1648073776629491e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.1648073776629491e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.1648073776629491e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.1648073776629491e-02
 UP BND1      rho_19    1
 BV BND1      x_12_0  
 UP BND1      w_12_0    4.1648073776629491e-02
 BV BND1      x_12_1  
 UP BND1      w_12_1    4.1648073776629491e-02
 BV BND1      x_12_2  
 UP BND1      w_12_2    4.1648073776629491e-02
 BV BND1      x_12_3  
 UP BND1      w_12_3    4.1648073776629491e-02
 BV BND1      x_12_4  
 UP BND1      w_12_4    4.1648073776629491e-02
 BV BND1      x_12_5  
 UP BND1      w_12_5    4.1648073776629491e-02
 BV BND1      x_12_6  
 UP BND1      w_12_6    4.1648073776629491e-02
 BV BND1      x_12_7  
 UP BND1      w_12_7    4.1648073776629491e-02
 BV BND1      x_12_8  
 UP BND1      w_12_8    4.1648073776629491e-02
 BV BND1      x_12_9  
 UP BND1      w_12_9    4.1648073776629491e-02
 BV BND1      x_12_10 
 UP BND1      w_12_10   4.1648073776629491e-02
 BV BND1      x_12_11 
 UP BND1      w_12_11   4.1648073776629491e-02
 BV BND1      x_12_12 
 UP BND1      w_12_12   4.1648073776629491e-02
 BV BND1      x_12_13 
 UP BND1      w_12_13   4.1648073776629491e-02
 BV BND1      x_12_14 
 UP BND1      w_12_14   4.1648073776629491e-02
 BV BND1      x_12_15 
 UP BND1      w_12_15   4.1648073776629491e-02
 UP BND1      rho_12    1
 UP BND1      a_9_6     1
 UP BND1      a_9_31    1
 UP BND1      a_9_15    1
 UP BND1      a_9_32    1
 UP BND1      a_9_13    1
 UP BND1      a_9_19    1
 UP BND1      a_9_12    1
 UP BND1      a_6_31    1
 UP BND1      a_6_15    1
 UP BND1      a_6_32    1
 UP BND1      a_6_13    1
 UP BND1      a_6_19    1
 UP BND1      a_6_12    1
 UP BND1      a_31_15   1
 UP BND1      a_31_32   1
 UP BND1      a_31_13   1
 UP BND1      a_31_19   1
 UP BND1      a_31_12   1
 UP BND1      a_15_32   1
 UP BND1      a_15_13   1
 UP BND1      a_15_19   1
 UP BND1      a_15_12   1
 UP BND1      a_32_13   1
 UP BND1      a_32_19   1
 UP BND1      a_32_12   1
 UP BND1      a_13_19   1
 UP BND1      a_13_12   1
 UP BND1      a_19_12   1
 BV BND1      service_0_9_0
 BV BND1      service_0_9_1
 BV BND1      service_0_9_2
 BV BND1      service_0_9_3
 BV BND1      service_0_9_4
 BV BND1      service_0_9_5
 BV BND1      service_0_9_6
 BV BND1      service_0_9_7
 BV BND1      service_0_9_9
 BV BND1      service_0_9_10
 BV BND1      service_0_9_11
 BV BND1      service_0_9_12
 BV BND1      service_1_9_0
 BV BND1      service_1_9_1
 BV BND1      service_1_9_2
 BV BND1      service_1_9_3
 BV BND1      service_1_9_4
 BV BND1      service_1_9_5
 BV BND1      service_1_9_6
 BV BND1      service_1_9_7
 BV BND1      service_1_9_9
 BV BND1      service_1_9_10
 BV BND1      service_1_9_11
 BV BND1      service_1_9_12
 BV BND1      service_2_9_0
 BV BND1      service_2_9_1
 BV BND1      service_2_9_2
 BV BND1      service_2_9_3
 BV BND1      service_2_9_4
 BV BND1      service_2_9_5
 BV BND1      service_2_9_6
 BV BND1      service_2_9_7
 BV BND1      service_2_9_9
 BV BND1      service_2_9_10
 BV BND1      service_2_9_11
 BV BND1      service_2_9_12
 BV BND1      service_0_6_0
 BV BND1      service_0_6_2
 BV BND1      service_0_6_3
 BV BND1      service_0_6_4
 BV BND1      service_0_6_5
 BV BND1      service_0_6_6
 BV BND1      service_0_6_7
 BV BND1      service_0_6_8
 BV BND1      service_0_6_9
 BV BND1      service_0_6_10
 BV BND1      service_1_6_0
 BV BND1      service_1_6_2
 BV BND1      service_1_6_3
 BV BND1      service_1_6_4
 BV BND1      service_1_6_5
 BV BND1      service_1_6_6
 BV BND1      service_1_6_7
 BV BND1      service_1_6_8
 BV BND1      service_1_6_9
 BV BND1      service_1_6_10
 BV BND1      service_2_6_0
 BV BND1      service_2_6_2
 BV BND1      service_2_6_3
 BV BND1      service_2_6_4
 BV BND1      service_2_6_5
 BV BND1      service_2_6_6
 BV BND1      service_2_6_7
 BV BND1      service_2_6_8
 BV BND1      service_2_6_9
 BV BND1      service_2_6_10
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_15_0
 BV BND1      service_0_15_1
 BV BND1      service_0_15_2
 BV BND1      service_0_15_4
 BV BND1      service_0_15_5
 BV BND1      service_0_15_6
 BV BND1      service_0_15_7
 BV BND1      service_0_15_8
 BV BND1      service_0_15_9
 BV BND1      service_0_15_10
 BV BND1      service_0_15_11
 BV BND1      service_0_15_12
 BV BND1      service_0_15_13
 BV BND1      service_0_15_14
 BV BND1      service_0_15_15
 BV BND1      service_0_15_16
 BV BND1      service_1_15_0
 BV BND1      service_1_15_1
 BV BND1      service_1_15_2
 BV BND1      service_1_15_4
 BV BND1      service_1_15_5
 BV BND1      service_1_15_6
 BV BND1      service_1_15_7
 BV BND1      service_1_15_8
 BV BND1      service_1_15_9
 BV BND1      service_1_15_10
 BV BND1      service_1_15_11
 BV BND1      service_1_15_12
 BV BND1      service_1_15_13
 BV BND1      service_1_15_14
 BV BND1      service_1_15_15
 BV BND1      service_1_15_16
 BV BND1      service_2_15_0
 BV BND1      service_2_15_1
 BV BND1      service_2_15_2
 BV BND1      service_2_15_4
 BV BND1      service_2_15_5
 BV BND1      service_2_15_6
 BV BND1      service_2_15_7
 BV BND1      service_2_15_8
 BV BND1      service_2_15_9
 BV BND1      service_2_15_10
 BV BND1      service_2_15_11
 BV BND1      service_2_15_12
 BV BND1      service_2_15_13
 BV BND1      service_2_15_14
 BV BND1      service_2_15_15
 BV BND1      service_2_15_16
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_13_0
 BV BND1      service_0_13_1
 BV BND1      service_0_13_2
 BV BND1      service_0_13_3
 BV BND1      service_0_13_4
 BV BND1      service_0_13_5
 BV BND1      service_0_13_6
 BV BND1      service_0_13_7
 BV BND1      service_0_13_8
 BV BND1      service_0_13_9
 BV BND1      service_0_13_10
 BV BND1      service_0_13_11
 BV BND1      service_0_13_12
 BV BND1      service_0_13_14
 BV BND1      service_0_13_15
 BV BND1      service_0_13_16
 BV BND1      service_0_13_17
 BV BND1      service_0_13_18
 BV BND1      service_0_13_19
 BV BND1      service_1_13_0
 BV BND1      service_1_13_1
 BV BND1      service_1_13_2
 BV BND1      service_1_13_3
 BV BND1      service_1_13_4
 BV BND1      service_1_13_5
 BV BND1      service_1_13_6
 BV BND1      service_1_13_7
 BV BND1      service_1_13_8
 BV BND1      service_1_13_9
 BV BND1      service_1_13_10
 BV BND1      service_1_13_11
 BV BND1      service_1_13_12
 BV BND1      service_1_13_14
 BV BND1      service_1_13_15
 BV BND1      service_1_13_16
 BV BND1      service_1_13_17
 BV BND1      service_1_13_18
 BV BND1      service_1_13_19
 BV BND1      service_2_13_0
 BV BND1      service_2_13_1
 BV BND1      service_2_13_2
 BV BND1      service_2_13_3
 BV BND1      service_2_13_4
 BV BND1      service_2_13_5
 BV BND1      service_2_13_6
 BV BND1      service_2_13_7
 BV BND1      service_2_13_8
 BV BND1      service_2_13_9
 BV BND1      service_2_13_10
 BV BND1      service_2_13_11
 BV BND1      service_2_13_12
 BV BND1      service_2_13_14
 BV BND1      service_2_13_15
 BV BND1      service_2_13_16
 BV BND1      service_2_13_17
 BV BND1      service_2_13_18
 BV BND1      service_2_13_19
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_12_1
 BV BND1      service_0_12_2
 BV BND1      service_0_12_3
 BV BND1      service_0_12_4
 BV BND1      service_0_12_5
 BV BND1      service_0_12_6
 BV BND1      service_0_12_7
 BV BND1      service_0_12_8
 BV BND1      service_0_12_9
 BV BND1      service_0_12_10
 BV BND1      service_0_12_11
 BV BND1      service_0_12_12
 BV BND1      service_0_12_13
 BV BND1      service_0_12_14
 BV BND1      service_0_12_15
 BV BND1      service_1_12_1
 BV BND1      service_1_12_2
 BV BND1      service_1_12_3
 BV BND1      service_1_12_4
 BV BND1      service_1_12_5
 BV BND1      service_1_12_6
 BV BND1      service_1_12_7
 BV BND1      service_1_12_8
 BV BND1      service_1_12_9
 BV BND1      service_1_12_10
 BV BND1      service_1_12_11
 BV BND1      service_1_12_12
 BV BND1      service_1_12_13
 BV BND1      service_1_12_14
 BV BND1      service_1_12_15
 BV BND1      service_2_12_1
 BV BND1      service_2_12_2
 BV BND1      service_2_12_3
 BV BND1      service_2_12_4
 BV BND1      service_2_12_5
 BV BND1      service_2_12_6
 BV BND1      service_2_12_7
 BV BND1      service_2_12_8
 BV BND1      service_2_12_9
 BV BND1      service_2_12_10
 BV BND1      service_2_12_11
 BV BND1      service_2_12_12
 BV BND1      service_2_12_13
 BV BND1      service_2_12_14
 BV BND1      service_2_12_15
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  13
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  13
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  13
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  13
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  20
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  20
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  20
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  20
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  20
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  20
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  20
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  20
 BV BND1      arc_0_5_16
 UP BND1      load_0_5_16  20
 BV BND1      arc_0_5_17
 UP BND1      load_0_5_17  20
 BV BND1      arc_0_5_18
 UP BND1      load_0_5_18  20
 BV BND1      arc_0_5_19
 UP BND1      load_0_5_19  20
 BV BND1      arc_0_5_20
 UP BND1      load_0_5_20  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_13_20
 UP BND1      load_0_13_20  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_5
 UP BND1      load_0_16_5  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_5
 UP BND1      load_0_17_5  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_5
 UP BND1      load_0_18_5  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_5
 UP BND1      load_0_19_5  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_5
 UP BND1      load_0_20_5  20
 BV BND1      arc_0_20_13
 UP BND1      load_0_20_13  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_13_20
 UP BND1      load_1_13_20  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_13
 UP BND1      load_1_20_13  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
ENDATA
