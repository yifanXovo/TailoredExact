* Signature: 0x7e3de77ac78d73a9
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_24_32
 E  normalized_mass_24_33
 E  normalized_ratio_24_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 G  product_lb_39
 L  product_ub_40
 G  product_lb_41
 L  product_ub_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_27_67
 E  normalized_mass_27_68
 E  normalized_ratio_27_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 E  onehot_31_96
 E  normalized_mass_31_97
 E  normalized_ratio_31_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 E  onehot_29_131
 E  normalized_mass_29_132
 E  normalized_ratio_29_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 E  onehot_32_160
 E  normalized_mass_32_161
 E  normalized_ratio_32_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 G  product_lb_189
 L  product_ub_190
 G  product_lb_191
 L  product_ub_192
 G  product_lb_193
 L  product_ub_194
 E  onehot_25_195
 E  normalized_mass_25_196
 E  normalized_ratio_25_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 E  onehot_19_216
 E  normalized_mass_19_217
 E  normalized_ratio_19_218
 G  product_lb_219
 L  product_ub_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 E  onehot_34_243
 E  normalized_mass_34_244
 E  normalized_ratio_34_245
 G  stock_lb_246
 L  stock_ub_247
 L  parent_nonstrict_scope_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 E  normalization_305
 G  full_original_Gini_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 L  arc_capacity_410
 L  arc_capacity_411
 L  arc_capacity_412
 L  arc_capacity_413
 L  arc_capacity_414
 L  arc_capacity_415
 L  arc_capacity_416
 L  arc_capacity_417
 L  arc_capacity_418
 L  arc_capacity_419
 L  arc_capacity_420
 L  arc_capacity_421
 L  arc_capacity_422
 L  arc_capacity_423
 L  arc_capacity_424
 G  connected_order_arc_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 L  arc_capacity_447
 G  connected_order_arc_448
 L  arc_capacity_449
 G  connected_order_arc_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 L  arc_capacity_470
 G  connected_order_arc_471
 L  arc_capacity_472
 G  connected_order_arc_473
 L  arc_capacity_474
 G  connected_order_arc_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 L  arc_capacity_493
 G  connected_order_arc_494
 L  arc_capacity_495
 G  connected_order_arc_496
 L  arc_capacity_497
 G  connected_order_arc_498
 L  arc_capacity_499
 G  connected_order_arc_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 L  arc_capacity_516
 G  connected_order_arc_517
 L  arc_capacity_518
 G  connected_order_arc_519
 L  arc_capacity_520
 G  connected_order_arc_521
 L  arc_capacity_522
 G  connected_order_arc_523
 L  arc_capacity_524
 G  connected_order_arc_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 L  arc_capacity_539
 G  connected_order_arc_540
 L  arc_capacity_541
 G  connected_order_arc_542
 L  arc_capacity_543
 G  connected_order_arc_544
 L  arc_capacity_545
 G  connected_order_arc_546
 L  arc_capacity_547
 G  connected_order_arc_548
 L  arc_capacity_549
 G  connected_order_arc_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 L  arc_capacity_562
 G  connected_order_arc_563
 L  arc_capacity_564
 G  connected_order_arc_565
 L  arc_capacity_566
 G  connected_order_arc_567
 L  arc_capacity_568
 G  connected_order_arc_569
 L  arc_capacity_570
 G  connected_order_arc_571
 L  arc_capacity_572
 G  connected_order_arc_573
 L  arc_capacity_574
 G  connected_order_arc_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 L  arc_capacity_585
 G  connected_order_arc_586
 L  arc_capacity_587
 G  connected_order_arc_588
 L  arc_capacity_589
 G  connected_order_arc_590
 L  arc_capacity_591
 G  connected_order_arc_592
 L  arc_capacity_593
 G  connected_order_arc_594
 L  arc_capacity_595
 G  connected_order_arc_596
 L  arc_capacity_597
 G  connected_order_arc_598
 L  arc_capacity_599
 G  connected_order_arc_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 L  arc_capacity_608
 G  connected_order_arc_609
 L  arc_capacity_610
 G  connected_order_arc_611
 L  arc_capacity_612
 G  connected_order_arc_613
 L  arc_capacity_614
 G  connected_order_arc_615
 L  arc_capacity_616
 G  connected_order_arc_617
 L  arc_capacity_618
 G  connected_order_arc_619
 L  arc_capacity_620
 G  connected_order_arc_621
 L  arc_capacity_622
 G  connected_order_arc_623
 L  arc_capacity_624
 G  connected_order_arc_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 L  arc_capacity_631
 G  connected_order_arc_632
 L  arc_capacity_633
 G  connected_order_arc_634
 L  arc_capacity_635
 G  connected_order_arc_636
 L  arc_capacity_637
 G  connected_order_arc_638
 L  arc_capacity_639
 G  connected_order_arc_640
 L  arc_capacity_641
 G  connected_order_arc_642
 L  arc_capacity_643
 G  connected_order_arc_644
 L  arc_capacity_645
 G  connected_order_arc_646
 L  arc_capacity_647
 G  connected_order_arc_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 L  arc_capacity_654
 G  connected_order_arc_655
 L  arc_capacity_656
 G  connected_order_arc_657
 L  arc_capacity_658
 G  connected_order_arc_659
 L  arc_capacity_660
 G  connected_order_arc_661
 L  arc_capacity_662
 G  connected_order_arc_663
 L  arc_capacity_664
 G  connected_order_arc_665
 L  arc_capacity_666
 G  connected_order_arc_667
 L  arc_capacity_668
 G  connected_order_arc_669
 L  arc_capacity_670
 G  connected_order_arc_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 L  arc_capacity_677
 G  connected_order_arc_678
 L  arc_capacity_679
 G  connected_order_arc_680
 L  arc_capacity_681
 G  connected_order_arc_682
 L  arc_capacity_683
 G  connected_order_arc_684
 L  arc_capacity_685
 G  connected_order_arc_686
 L  arc_capacity_687
 G  connected_order_arc_688
 L  arc_capacity_689
 G  connected_order_arc_690
 L  arc_capacity_691
 G  connected_order_arc_692
 L  arc_capacity_693
 G  connected_order_arc_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 E  depot_departure_or_bypass_699
 E  depot_return_or_bypass_700
 E  out_degree_701
 E  in_degree_702
 G  order_active_lb_703
 L  order_active_ub_704
 E  segment_load_conservation_705
 G  segment_prefix_lb_706
 L  segment_prefix_ub_707
 E  out_degree_708
 E  in_degree_709
 G  order_active_lb_710
 L  order_active_ub_711
 E  segment_load_conservation_712
 G  segment_prefix_lb_713
 L  segment_prefix_ub_714
 E  out_degree_715
 E  in_degree_716
 G  order_active_lb_717
 L  order_active_ub_718
 E  segment_load_conservation_719
 G  segment_prefix_lb_720
 L  segment_prefix_ub_721
 E  out_degree_722
 E  in_degree_723
 G  order_active_lb_724
 L  order_active_ub_725
 E  segment_load_conservation_726
 G  segment_prefix_lb_727
 L  segment_prefix_ub_728
 E  out_degree_729
 E  in_degree_730
 G  order_active_lb_731
 L  order_active_ub_732
 E  service_visit_def_733
 E  free_load_conservation_734
 E  out_degree_735
 E  in_degree_736
 G  order_active_lb_737
 L  order_active_ub_738
 E  service_visit_def_739
 E  free_load_conservation_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  service_visit_def_745
 E  free_load_conservation_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  service_visit_def_757
 E  free_load_conservation_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 G  fixed_segment_relative_order_777
 G  fixed_segment_relative_order_778
 G  fixed_segment_relative_order_779
 L  original_T_including_depot_unload_780
 L  arc_capacity_781
 L  arc_capacity_782
 L  arc_capacity_783
 L  arc_capacity_784
 L  arc_capacity_785
 L  arc_capacity_786
 L  arc_capacity_787
 L  arc_capacity_788
 L  arc_capacity_789
 L  arc_capacity_790
 L  arc_capacity_791
 L  arc_capacity_792
 L  arc_capacity_793
 L  arc_capacity_794
 L  arc_capacity_795
 G  connected_order_arc_796
 L  arc_capacity_797
 G  connected_order_arc_798
 L  arc_capacity_799
 G  connected_order_arc_800
 L  arc_capacity_801
 G  connected_order_arc_802
 L  arc_capacity_803
 G  connected_order_arc_804
 L  arc_capacity_805
 G  connected_order_arc_806
 L  arc_capacity_807
 G  connected_order_arc_808
 L  arc_capacity_809
 G  connected_order_arc_810
 L  arc_capacity_811
 G  connected_order_arc_812
 L  arc_capacity_813
 G  connected_order_arc_814
 L  arc_capacity_815
 G  connected_order_arc_816
 L  arc_capacity_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 G  connected_order_arc_839
 L  arc_capacity_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 L  arc_capacity_887
 G  connected_order_arc_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 L  arc_capacity_910
 G  connected_order_arc_911
 L  arc_capacity_912
 G  connected_order_arc_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 L  arc_capacity_933
 G  connected_order_arc_934
 L  arc_capacity_935
 G  connected_order_arc_936
 L  arc_capacity_937
 G  connected_order_arc_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 L  arc_capacity_956
 G  connected_order_arc_957
 L  arc_capacity_958
 G  connected_order_arc_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 L  arc_capacity_1025
 G  connected_order_arc_1026
 L  arc_capacity_1027
 G  connected_order_arc_1028
 L  arc_capacity_1029
 G  connected_order_arc_1030
 L  arc_capacity_1031
 G  connected_order_arc_1032
 L  arc_capacity_1033
 G  connected_order_arc_1034
 L  arc_capacity_1035
 G  connected_order_arc_1036
 L  arc_capacity_1037
 G  connected_order_arc_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 L  arc_capacity_1048
 G  connected_order_arc_1049
 L  arc_capacity_1050
 G  connected_order_arc_1051
 L  arc_capacity_1052
 G  connected_order_arc_1053
 L  arc_capacity_1054
 G  connected_order_arc_1055
 L  arc_capacity_1056
 G  connected_order_arc_1057
 L  arc_capacity_1058
 G  connected_order_arc_1059
 L  arc_capacity_1060
 G  connected_order_arc_1061
 L  arc_capacity_1062
 G  connected_order_arc_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 E  depot_departure_or_bypass_1070
 E  depot_return_or_bypass_1071
 E  out_degree_1072
 E  in_degree_1073
 G  order_active_lb_1074
 L  order_active_ub_1075
 E  segment_load_conservation_1076
 G  segment_prefix_lb_1077
 L  segment_prefix_ub_1078
 E  out_degree_1079
 E  in_degree_1080
 G  order_active_lb_1081
 L  order_active_ub_1082
 E  segment_load_conservation_1083
 G  segment_prefix_lb_1084
 L  segment_prefix_ub_1085
 E  out_degree_1086
 E  in_degree_1087
 G  order_active_lb_1088
 L  order_active_ub_1089
 E  segment_load_conservation_1090
 G  segment_prefix_lb_1091
 L  segment_prefix_ub_1092
 E  out_degree_1093
 E  in_degree_1094
 G  order_active_lb_1095
 L  order_active_ub_1096
 E  segment_load_conservation_1097
 G  segment_prefix_lb_1098
 L  segment_prefix_ub_1099
 E  out_degree_1100
 E  in_degree_1101
 G  order_active_lb_1102
 L  order_active_ub_1103
 E  service_visit_def_1104
 E  free_load_conservation_1105
 E  out_degree_1106
 E  in_degree_1107
 G  order_active_lb_1108
 L  order_active_ub_1109
 E  service_visit_def_1110
 E  free_load_conservation_1111
 E  out_degree_1112
 E  in_degree_1113
 G  order_active_lb_1114
 L  order_active_ub_1115
 E  service_visit_def_1116
 E  free_load_conservation_1117
 E  out_degree_1118
 E  in_degree_1119
 G  order_active_lb_1120
 L  order_active_ub_1121
 E  service_visit_def_1122
 E  free_load_conservation_1123
 E  out_degree_1124
 E  in_degree_1125
 G  order_active_lb_1126
 L  order_active_ub_1127
 E  service_visit_def_1128
 E  free_load_conservation_1129
 E  out_degree_1130
 E  in_degree_1131
 G  order_active_lb_1132
 L  order_active_ub_1133
 E  service_visit_def_1134
 E  free_load_conservation_1135
 E  out_degree_1136
 E  in_degree_1137
 G  order_active_lb_1138
 L  order_active_ub_1139
 E  service_visit_def_1140
 E  free_load_conservation_1141
 E  out_degree_1142
 E  in_degree_1143
 G  order_active_lb_1144
 L  order_active_ub_1145
 E  service_visit_def_1146
 E  free_load_conservation_1147
 G  fixed_segment_relative_order_1148
 G  fixed_segment_relative_order_1149
 G  fixed_segment_relative_order_1150
 L  original_T_including_depot_unload_1151
 L  arc_capacity_1152
 L  arc_capacity_1153
 L  arc_capacity_1154
 L  arc_capacity_1155
 L  arc_capacity_1156
 L  arc_capacity_1157
 L  arc_capacity_1158
 L  arc_capacity_1159
 L  arc_capacity_1160
 L  arc_capacity_1161
 L  arc_capacity_1162
 L  arc_capacity_1163
 L  arc_capacity_1164
 L  arc_capacity_1165
 G  connected_order_arc_1166
 L  arc_capacity_1167
 G  connected_order_arc_1168
 L  arc_capacity_1169
 G  connected_order_arc_1170
 L  arc_capacity_1171
 G  connected_order_arc_1172
 L  arc_capacity_1173
 G  connected_order_arc_1174
 L  arc_capacity_1175
 G  connected_order_arc_1176
 L  arc_capacity_1177
 G  connected_order_arc_1178
 L  arc_capacity_1179
 G  connected_order_arc_1180
 L  arc_capacity_1181
 G  connected_order_arc_1182
 L  arc_capacity_1183
 G  connected_order_arc_1184
 L  arc_capacity_1185
 L  arc_capacity_1186
 G  connected_order_arc_1187
 L  arc_capacity_1188
 G  connected_order_arc_1189
 L  arc_capacity_1190
 G  connected_order_arc_1191
 L  arc_capacity_1192
 G  connected_order_arc_1193
 L  arc_capacity_1194
 G  connected_order_arc_1195
 L  arc_capacity_1196
 G  connected_order_arc_1197
 L  arc_capacity_1198
 G  connected_order_arc_1199
 L  arc_capacity_1200
 G  connected_order_arc_1201
 L  arc_capacity_1202
 G  connected_order_arc_1203
 L  arc_capacity_1204
 G  connected_order_arc_1205
 L  arc_capacity_1206
 L  arc_capacity_1207
 G  connected_order_arc_1208
 L  arc_capacity_1209
 G  connected_order_arc_1210
 L  arc_capacity_1211
 G  connected_order_arc_1212
 L  arc_capacity_1213
 G  connected_order_arc_1214
 L  arc_capacity_1215
 G  connected_order_arc_1216
 L  arc_capacity_1217
 G  connected_order_arc_1218
 L  arc_capacity_1219
 G  connected_order_arc_1220
 L  arc_capacity_1221
 G  connected_order_arc_1222
 L  arc_capacity_1223
 G  connected_order_arc_1224
 L  arc_capacity_1225
 G  connected_order_arc_1226
 L  arc_capacity_1227
 L  arc_capacity_1228
 G  connected_order_arc_1229
 L  arc_capacity_1230
 G  connected_order_arc_1231
 L  arc_capacity_1232
 G  connected_order_arc_1233
 L  arc_capacity_1234
 G  connected_order_arc_1235
 L  arc_capacity_1236
 G  connected_order_arc_1237
 L  arc_capacity_1238
 G  connected_order_arc_1239
 L  arc_capacity_1240
 G  connected_order_arc_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 L  arc_capacity_1249
 G  connected_order_arc_1250
 L  arc_capacity_1251
 G  connected_order_arc_1252
 L  arc_capacity_1253
 G  connected_order_arc_1254
 L  arc_capacity_1255
 G  connected_order_arc_1256
 L  arc_capacity_1257
 G  connected_order_arc_1258
 L  arc_capacity_1259
 G  connected_order_arc_1260
 L  arc_capacity_1261
 G  connected_order_arc_1262
 L  arc_capacity_1263
 G  connected_order_arc_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 L  arc_capacity_1270
 G  connected_order_arc_1271
 L  arc_capacity_1272
 G  connected_order_arc_1273
 L  arc_capacity_1274
 G  connected_order_arc_1275
 L  arc_capacity_1276
 G  connected_order_arc_1277
 L  arc_capacity_1278
 G  connected_order_arc_1279
 L  arc_capacity_1280
 G  connected_order_arc_1281
 L  arc_capacity_1282
 G  connected_order_arc_1283
 L  arc_capacity_1284
 G  connected_order_arc_1285
 L  arc_capacity_1286
 G  connected_order_arc_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 L  arc_capacity_1291
 G  connected_order_arc_1292
 L  arc_capacity_1293
 G  connected_order_arc_1294
 L  arc_capacity_1295
 G  connected_order_arc_1296
 L  arc_capacity_1297
 G  connected_order_arc_1298
 L  arc_capacity_1299
 G  connected_order_arc_1300
 L  arc_capacity_1301
 G  connected_order_arc_1302
 L  arc_capacity_1303
 G  connected_order_arc_1304
 L  arc_capacity_1305
 G  connected_order_arc_1306
 L  arc_capacity_1307
 G  connected_order_arc_1308
 L  arc_capacity_1309
 G  connected_order_arc_1310
 L  arc_capacity_1311
 L  arc_capacity_1312
 G  connected_order_arc_1313
 L  arc_capacity_1314
 G  connected_order_arc_1315
 L  arc_capacity_1316
 G  connected_order_arc_1317
 L  arc_capacity_1318
 G  connected_order_arc_1319
 L  arc_capacity_1320
 G  connected_order_arc_1321
 L  arc_capacity_1322
 G  connected_order_arc_1323
 L  arc_capacity_1324
 G  connected_order_arc_1325
 L  arc_capacity_1326
 G  connected_order_arc_1327
 L  arc_capacity_1328
 G  connected_order_arc_1329
 L  arc_capacity_1330
 G  connected_order_arc_1331
 L  arc_capacity_1332
 L  arc_capacity_1333
 G  connected_order_arc_1334
 L  arc_capacity_1335
 G  connected_order_arc_1336
 L  arc_capacity_1337
 G  connected_order_arc_1338
 L  arc_capacity_1339
 G  connected_order_arc_1340
 L  arc_capacity_1341
 G  connected_order_arc_1342
 L  arc_capacity_1343
 G  connected_order_arc_1344
 L  arc_capacity_1345
 G  connected_order_arc_1346
 L  arc_capacity_1347
 G  connected_order_arc_1348
 L  arc_capacity_1349
 G  connected_order_arc_1350
 L  arc_capacity_1351
 G  connected_order_arc_1352
 L  arc_capacity_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 G  connected_order_arc_1357
 L  arc_capacity_1358
 G  connected_order_arc_1359
 L  arc_capacity_1360
 G  connected_order_arc_1361
 L  arc_capacity_1362
 G  connected_order_arc_1363
 L  arc_capacity_1364
 G  connected_order_arc_1365
 L  arc_capacity_1366
 G  connected_order_arc_1367
 L  arc_capacity_1368
 G  connected_order_arc_1369
 L  arc_capacity_1370
 G  connected_order_arc_1371
 L  arc_capacity_1372
 G  connected_order_arc_1373
 L  arc_capacity_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 G  connected_order_arc_1380
 L  arc_capacity_1381
 G  connected_order_arc_1382
 L  arc_capacity_1383
 G  connected_order_arc_1384
 L  arc_capacity_1385
 G  connected_order_arc_1386
 L  arc_capacity_1387
 G  connected_order_arc_1388
 L  arc_capacity_1389
 G  connected_order_arc_1390
 L  arc_capacity_1391
 G  connected_order_arc_1392
 L  arc_capacity_1393
 G  connected_order_arc_1394
 E  depot_departure_or_bypass_1395
 E  depot_return_or_bypass_1396
 E  out_degree_1397
 E  in_degree_1398
 G  order_active_lb_1399
 L  order_active_ub_1400
 E  segment_load_conservation_1401
 G  segment_prefix_lb_1402
 L  segment_prefix_ub_1403
 E  out_degree_1404
 E  in_degree_1405
 G  order_active_lb_1406
 L  order_active_ub_1407
 E  segment_load_conservation_1408
 G  segment_prefix_lb_1409
 L  segment_prefix_ub_1410
 E  out_degree_1411
 E  in_degree_1412
 G  order_active_lb_1413
 L  order_active_ub_1414
 E  segment_load_conservation_1415
 G  segment_prefix_lb_1416
 L  segment_prefix_ub_1417
 E  out_degree_1418
 E  in_degree_1419
 G  order_active_lb_1420
 L  order_active_ub_1421
 E  service_visit_def_1422
 E  free_load_conservation_1423
 E  out_degree_1424
 E  in_degree_1425
 G  order_active_lb_1426
 L  order_active_ub_1427
 E  service_visit_def_1428
 E  free_load_conservation_1429
 E  out_degree_1430
 E  in_degree_1431
 G  order_active_lb_1432
 L  order_active_ub_1433
 E  service_visit_def_1434
 E  free_load_conservation_1435
 E  out_degree_1436
 E  in_degree_1437
 G  order_active_lb_1438
 L  order_active_ub_1439
 E  service_visit_def_1440
 E  free_load_conservation_1441
 E  out_degree_1442
 E  in_degree_1443
 G  order_active_lb_1444
 L  order_active_ub_1445
 E  service_visit_def_1446
 E  free_load_conservation_1447
 E  out_degree_1448
 E  in_degree_1449
 G  order_active_lb_1450
 L  order_active_ub_1451
 E  service_visit_def_1452
 E  free_load_conservation_1453
 E  out_degree_1454
 E  in_degree_1455
 G  order_active_lb_1456
 L  order_active_ub_1457
 E  service_visit_def_1458
 E  free_load_conservation_1459
 E  out_degree_1460
 E  in_degree_1461
 G  order_active_lb_1462
 L  order_active_ub_1463
 E  service_visit_def_1464
 E  free_load_conservation_1465
 G  fixed_segment_relative_order_1466
 G  fixed_segment_relative_order_1467
 L  original_T_including_depot_unload_1468
COLUMNS
    t         normalized_mass_24_33  -1
    t         normalized_mass_27_68  -1
    t         normalized_mass_31_97  -1
    t         normalized_mass_29_132  -1
    t         normalized_mass_32_161  -1
    t         normalized_mass_25_196  -1
    t         normalized_mass_19_217  -1
    t         normalized_mass_34_244  -1
    t         normalization_305  2.4144047619047619e+01
    t         full_original_Gini_306  -6.9616666666666760e+01
    q         OBJ       1
    q         parent_nonstrict_scope_248  1
    q         full_original_Gini_306  35
    MARKER    'MARKER'                 'INTORG'
    x_24_0    OBJ       0.048
    x_24_0    product_lb_0  -2.4694987505487574e-02
    x_24_0    product_ub_1  -4.1418076031795294e-02
    x_24_0    onehot_24_32  1
    x_24_0    parent_nonstrict_scope_248  0.096
    x_24_0    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_0    product_lb_0  1
    w_24_0    product_ub_1  1
    w_24_0    normalized_mass_24_33  1
    w_24_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_1    OBJ       3.6000000000000004e-02
    x_24_1    product_lb_2  -2.4694987505487574e-02
    x_24_1    product_ub_3  -4.1418076031795294e-02
    x_24_1    onehot_24_32  1
    x_24_1    stock_lb_246  1
    x_24_1    stock_ub_247  1
    x_24_1    parent_nonstrict_scope_248  0.084
    x_24_1    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_1    product_lb_2  1
    w_24_1    product_ub_3  1
    w_24_1    normalized_mass_24_33  1
    w_24_1    normalized_ratio_24_34  -0.125
    w_24_1    full_original_Gini_306  -2.1019047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_2    OBJ       2.4000000000000007e-02
    x_24_2    product_lb_4  -2.4694987505487574e-02
    x_24_2    product_ub_5  -4.1418076031795294e-02
    x_24_2    onehot_24_32  1
    x_24_2    stock_lb_246  2
    x_24_2    stock_ub_247  2
    x_24_2    parent_nonstrict_scope_248  7.2000000000000008e-02
    x_24_2    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_2    product_lb_4  1
    w_24_2    product_ub_5  1
    w_24_2    normalized_mass_24_33  1
    w_24_2    normalized_ratio_24_34  -0.25
    w_24_2    full_original_Gini_306  -1.7894047619047623e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_3    OBJ       1.1999999999999997e-02
    x_24_3    product_lb_6  -2.4694987505487574e-02
    x_24_3    product_ub_7  -4.1418076031795294e-02
    x_24_3    onehot_24_32  1
    x_24_3    stock_lb_246  3
    x_24_3    stock_ub_247  3
    x_24_3    parent_nonstrict_scope_248  0.06
    x_24_3    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_3    product_lb_6  1
    w_24_3    product_ub_7  1
    w_24_3    normalized_mass_24_33  1
    w_24_3    normalized_ratio_24_34  -0.375
    w_24_3    full_original_Gini_306  -1.4769047619047621e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_4    product_lb_8  -2.4694987505487574e-02
    x_24_4    product_ub_9  -4.1418076031795294e-02
    x_24_4    onehot_24_32  1
    x_24_4    stock_lb_246  4
    x_24_4    stock_ub_247  4
    x_24_4    parent_nonstrict_scope_248  0.048
    x_24_4    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_4    product_lb_8  1
    w_24_4    product_ub_9  1
    w_24_4    normalized_mass_24_33  1
    w_24_4    normalized_ratio_24_34  -0.5
    w_24_4    full_original_Gini_306  -1.1844047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_5    OBJ       -1.1999999999999997e-02
    x_24_5    product_lb_10  -2.4694987505487574e-02
    x_24_5    product_ub_11  -4.1418076031795294e-02
    x_24_5    onehot_24_32  1
    x_24_5    stock_lb_246  5
    x_24_5    stock_ub_247  5
    x_24_5    parent_nonstrict_scope_248  3.6000000000000004e-02
    x_24_5    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_5    product_lb_10  1
    w_24_5    product_ub_11  1
    w_24_5    normalized_mass_24_33  1
    w_24_5    normalized_ratio_24_34  -0.625
    w_24_5    full_original_Gini_306  -8.9690476190476183e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_6    OBJ       -0.024
    x_24_6    product_lb_12  -2.4694987505487574e-02
    x_24_6    product_ub_13  -4.1418076031795294e-02
    x_24_6    onehot_24_32  1
    x_24_6    stock_lb_246  6
    x_24_6    stock_ub_247  6
    x_24_6    parent_nonstrict_scope_248  0.024
    x_24_6    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_6    product_lb_12  1
    w_24_6    product_ub_13  1
    w_24_6    normalized_mass_24_33  1
    w_24_6    normalized_ratio_24_34  -0.75
    w_24_6    full_original_Gini_306  -6.2369047619047615e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_7    OBJ       -3.6000000000000004e-02
    x_24_7    product_lb_14  -2.4694987505487574e-02
    x_24_7    product_ub_15  -4.1418076031795294e-02
    x_24_7    onehot_24_32  1
    x_24_7    stock_lb_246  7
    x_24_7    stock_ub_247  7
    x_24_7    parent_nonstrict_scope_248  0.012
    x_24_7    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_7    product_lb_14  1
    w_24_7    product_ub_15  1
    w_24_7    normalized_mass_24_33  1
    w_24_7    normalized_ratio_24_34  -0.875
    w_24_7    full_original_Gini_306  -4.1309523809523823e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_8    OBJ       -0.048
    x_24_8    product_lb_16  -2.4694987505487574e-02
    x_24_8    product_ub_17  -4.1418076031795294e-02
    x_24_8    onehot_24_32  1
    x_24_8    stock_lb_246  8
    x_24_8    stock_ub_247  8
    x_24_8    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_8    product_lb_16  1
    w_24_8    product_ub_17  1
    w_24_8    normalized_mass_24_33  1
    w_24_8    normalized_ratio_24_34  -1
    w_24_8    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_9    OBJ       -3.6000000000000004e-02
    x_24_9    product_lb_18  -2.4694987505487574e-02
    x_24_9    product_ub_19  -4.1418076031795294e-02
    x_24_9    onehot_24_32  1
    x_24_9    stock_lb_246  9
    x_24_9    stock_ub_247  9
    x_24_9    parent_nonstrict_scope_248  0.012
    x_24_9    unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_9    product_lb_18  1
    w_24_9    product_ub_19  1
    w_24_9    normalized_mass_24_33  1
    w_24_9    normalized_ratio_24_34  -1.125
    w_24_9    full_original_Gini_306  -6.3809523809523823e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_10   OBJ       -0.024
    x_24_10   product_lb_20  -2.4694987505487574e-02
    x_24_10   product_ub_21  -4.1418076031795294e-02
    x_24_10   onehot_24_32  1
    x_24_10   stock_lb_246  10
    x_24_10   stock_ub_247  10
    x_24_10   parent_nonstrict_scope_248  0.024
    x_24_10   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_10   product_lb_20  1
    w_24_10   product_ub_21  1
    w_24_10   normalized_mass_24_33  1
    w_24_10   normalized_ratio_24_34  -1.25
    w_24_10   full_original_Gini_306  -9.6059523809523810e+00
    MARKER    'MARKER'                 'INTORG'
    x_24_11   OBJ       -1.1999999999999997e-02
    x_24_11   product_lb_22  -2.4694987505487574e-02
    x_24_11   product_ub_23  -4.1418076031795294e-02
    x_24_11   onehot_24_32  1
    x_24_11   stock_lb_246  11
    x_24_11   stock_ub_247  11
    x_24_11   parent_nonstrict_scope_248  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_24_11   product_lb_22  1
    w_24_11   product_ub_23  1
    w_24_11   normalized_mass_24_33  1
    w_24_11   normalized_ratio_24_34  -1.375
    w_24_11   full_original_Gini_306  -1.2980952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_12   product_lb_24  -2.4694987505487574e-02
    x_24_12   product_ub_25  -4.1418076031795294e-02
    x_24_12   onehot_24_32  1
    x_24_12   stock_lb_246  12
    x_24_12   stock_ub_247  12
    x_24_12   parent_nonstrict_scope_248  0.048
    x_24_12   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_12   product_lb_24  1
    w_24_12   product_ub_25  1
    w_24_12   normalized_mass_24_33  1
    w_24_12   normalized_ratio_24_34  -1.5
    w_24_12   full_original_Gini_306  -1.6355952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_13   OBJ       1.1999999999999997e-02
    x_24_13   product_lb_26  -2.4694987505487574e-02
    x_24_13   product_ub_27  -4.1418076031795294e-02
    x_24_13   onehot_24_32  1
    x_24_13   stock_lb_246  13
    x_24_13   stock_ub_247  13
    x_24_13   parent_nonstrict_scope_248  0.06
    x_24_13   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_13   product_lb_26  1
    w_24_13   product_ub_27  1
    w_24_13   normalized_mass_24_33  1
    w_24_13   normalized_ratio_24_34  -1.625
    w_24_13   full_original_Gini_306  -1.9730952380952377e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_14   OBJ       2.4000000000000007e-02
    x_24_14   product_lb_28  -2.4694987505487574e-02
    x_24_14   product_ub_29  -4.1418076031795294e-02
    x_24_14   onehot_24_32  1
    x_24_14   stock_lb_246  14
    x_24_14   stock_ub_247  14
    x_24_14   parent_nonstrict_scope_248  7.2000000000000008e-02
    x_24_14   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_14   product_lb_28  1
    w_24_14   product_ub_29  1
    w_24_14   normalized_mass_24_33  1
    w_24_14   normalized_ratio_24_34  -1.75
    w_24_14   full_original_Gini_306  -2.3105952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_24_15   OBJ       3.6000000000000004e-02
    x_24_15   product_lb_30  -2.4694987505487574e-02
    x_24_15   product_ub_31  -4.1418076031795294e-02
    x_24_15   onehot_24_32  1
    x_24_15   stock_lb_246  15
    x_24_15   stock_ub_247  15
    x_24_15   parent_nonstrict_scope_248  0.084
    x_24_15   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_24_15   product_lb_30  1
    w_24_15   product_ub_31  1
    w_24_15   normalized_mass_24_33  1
    w_24_15   normalized_ratio_24_34  -1.875
    w_24_15   full_original_Gini_306  -2.6480952380952381e+01
    rho_24    normalized_ratio_24_34  1
    rho_24    block_pair_pos_251  -1
    rho_24    block_pair_neg_252  1
    rho_24    block_pair_pos_253  -1
    rho_24    block_pair_neg_254  1
    rho_24    block_pair_pos_255  -1
    rho_24    block_pair_neg_256  1
    rho_24    block_pair_pos_257  -1
    rho_24    block_pair_neg_258  1
    rho_24    block_pair_pos_259  -1
    rho_24    block_pair_neg_260  1
    rho_24    block_pair_pos_261  -1
    rho_24    block_pair_neg_262  1
    rho_24    block_pair_pos_263  -1
    rho_24    block_pair_neg_264  1
    rho_24    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_27_0    OBJ       0.0315
    x_27_0    product_lb_35  -2.4694987505487574e-02
    x_27_0    product_ub_36  -4.1418076031795294e-02
    x_27_0    onehot_27_67  1
    x_27_0    parent_nonstrict_scope_248  0.0735
    x_27_0    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_0    product_lb_35  1
    w_27_0    product_ub_36  1
    w_27_0    normalized_mass_27_68  1
    w_27_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_1    OBJ       2.1000000000000005e-02
    x_27_1    product_lb_37  -2.4694987505487574e-02
    x_27_1    product_ub_38  -4.1418076031795294e-02
    x_27_1    onehot_27_67  1
    x_27_1    stock_lb_246  1
    x_27_1    stock_ub_247  1
    x_27_1    parent_nonstrict_scope_248  0.063
    x_27_1    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_1    product_lb_37  1
    w_27_1    product_ub_38  1
    w_27_1    normalized_mass_27_68  1
    w_27_1    normalized_ratio_27_69  -1.4285714285714285e-01
    w_27_1    full_original_Gini_306  -2.0572619047619053e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_2    OBJ       1.0500000000000002e-02
    x_27_2    product_lb_39  -2.4694987505487574e-02
    x_27_2    product_ub_40  -4.1418076031795294e-02
    x_27_2    onehot_27_67  1
    x_27_2    stock_lb_246  2
    x_27_2    stock_ub_247  2
    x_27_2    parent_nonstrict_scope_248  0.0525
    x_27_2    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_2    product_lb_39  1
    w_27_2    product_ub_40  1
    w_27_2    normalized_mass_27_68  1
    w_27_2    normalized_ratio_27_69  -2.8571428571428570e-01
    w_27_2    full_original_Gini_306  -1.7001190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_3    product_lb_41  -2.4694987505487574e-02
    x_27_3    product_ub_42  -4.1418076031795294e-02
    x_27_3    onehot_27_67  1
    x_27_3    stock_lb_246  3
    x_27_3    stock_ub_247  3
    x_27_3    parent_nonstrict_scope_248  4.1999999999999996e-02
    x_27_3    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_3    product_lb_41  1
    w_27_3    product_ub_42  1
    w_27_3    normalized_mass_27_68  1
    w_27_3    normalized_ratio_27_69  -4.2857142857142855e-01
    w_27_3    full_original_Gini_306  -1.3486904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_4    OBJ       -1.0499999999999995e-02
    x_27_4    product_lb_43  -2.4694987505487574e-02
    x_27_4    product_ub_44  -4.1418076031795294e-02
    x_27_4    onehot_27_67  1
    x_27_4    stock_lb_246  4
    x_27_4    stock_ub_247  4
    x_27_4    parent_nonstrict_scope_248  0.0315
    x_27_4    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_4    product_lb_43  1
    w_27_4    product_ub_44  1
    w_27_4    normalized_mass_27_68  1
    w_27_4    normalized_ratio_27_69  -5.7142857142857140e-01
    w_27_4    full_original_Gini_306  -1.0201190476190481e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_5    OBJ       -2.0999999999999991e-02
    x_27_5    product_lb_45  -2.4694987505487574e-02
    x_27_5    product_ub_46  -4.1418076031795294e-02
    x_27_5    onehot_27_67  1
    x_27_5    stock_lb_246  5
    x_27_5    stock_ub_247  5
    x_27_5    parent_nonstrict_scope_248  2.1000000000000005e-02
    x_27_5    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_5    product_lb_45  1
    w_27_5    product_ub_46  1
    w_27_5    normalized_mass_27_68  1
    w_27_5    normalized_ratio_27_69  -7.1428571428571419e-01
    w_27_5    full_original_Gini_306  -6.91547619047619
    MARKER    'MARKER'                 'INTORG'
    x_27_6    OBJ       -3.1499999999999993e-02
    x_27_6    product_lb_47  -2.4694987505487574e-02
    x_27_6    product_ub_48  -4.1418076031795294e-02
    x_27_6    onehot_27_67  1
    x_27_6    stock_lb_246  6
    x_27_6    stock_ub_247  6
    x_27_6    parent_nonstrict_scope_248  1.0500000000000002e-02
    x_27_6    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_6    product_lb_47  1
    w_27_6    product_ub_48  1
    w_27_6    normalized_mass_27_68  1
    w_27_6    normalized_ratio_27_69  -8.5714285714285710e-01
    w_27_6    full_original_Gini_306  -4.3630952380952381e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_7    OBJ       -4.1999999999999996e-02
    x_27_7    product_lb_49  -2.4694987505487574e-02
    x_27_7    product_ub_50  -4.1418076031795294e-02
    x_27_7    onehot_27_67  1
    x_27_7    stock_lb_246  7
    x_27_7    stock_ub_247  7
    x_27_7    unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_7    product_lb_49  1
    w_27_7    product_ub_50  1
    w_27_7    normalized_mass_27_68  1
    w_27_7    normalized_ratio_27_69  -1
    w_27_7    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_8    OBJ       -0.0315
    x_27_8    product_lb_51  -2.4694987505487574e-02
    x_27_8    product_ub_52  -4.1418076031795294e-02
    x_27_8    onehot_27_67  1
    x_27_8    stock_lb_246  8
    x_27_8    stock_ub_247  8
    x_27_8    parent_nonstrict_scope_248  1.0499999999999995e-02
    x_27_8    unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_8    product_lb_51  1
    w_27_8    product_ub_52  1
    w_27_8    normalized_mass_27_68  1
    w_27_8    normalized_ratio_27_69  -1.1428571428571428e+00
    w_27_8    full_original_Gini_306  -6.8273809523809490e+00
    MARKER    'MARKER'                 'INTORG'
    x_27_9    OBJ       -2.1000000000000005e-02
    x_27_9    product_lb_53  -2.4694987505487574e-02
    x_27_9    product_ub_54  -4.1418076031795294e-02
    x_27_9    onehot_27_67  1
    x_27_9    stock_lb_246  9
    x_27_9    stock_ub_247  9
    x_27_9    parent_nonstrict_scope_248  2.0999999999999991e-02
    x_27_9    unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_9    product_lb_53  1
    w_27_9    product_ub_54  1
    w_27_9    normalized_mass_27_68  1
    w_27_9    normalized_ratio_27_69  -1.2857142857142856e+00
    w_27_9    full_original_Gini_306  -1.0570238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_10   OBJ       -1.0500000000000009e-02
    x_27_10   product_lb_55  -2.4694987505487574e-02
    x_27_10   product_ub_56  -4.1418076031795294e-02
    x_27_10   onehot_27_67  1
    x_27_10   stock_lb_246  10
    x_27_10   stock_ub_247  10
    x_27_10   parent_nonstrict_scope_248  3.1499999999999986e-02
    x_27_10   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_10   product_lb_55  1
    w_27_10   product_ub_56  1
    w_27_10   normalized_mass_27_68  1
    w_27_10   normalized_ratio_27_69  -1.4285714285714284e+00
    w_27_10   full_original_Gini_306  -1.4427380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_11   product_lb_57  -2.4694987505487574e-02
    x_27_11   product_ub_58  -4.1418076031795294e-02
    x_27_11   onehot_27_67  1
    x_27_11   stock_lb_246  11
    x_27_11   stock_ub_247  11
    x_27_11   parent_nonstrict_scope_248  4.1999999999999996e-02
    MARKER    'MARKER'                 'INTEND'
    w_27_11   product_lb_57  1
    w_27_11   product_ub_58  1
    w_27_11   normalized_mass_27_68  1
    w_27_11   normalized_ratio_27_69  -1.5714285714285714e+00
    w_27_11   full_original_Gini_306  -1.8284523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_12   OBJ       1.0499999999999995e-02
    x_27_12   product_lb_59  -2.4694987505487574e-02
    x_27_12   product_ub_60  -4.1418076031795294e-02
    x_27_12   onehot_27_67  1
    x_27_12   stock_lb_246  12
    x_27_12   stock_ub_247  12
    x_27_12   parent_nonstrict_scope_248  5.2499999999999991e-02
    x_27_12   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_12   product_lb_59  1
    w_27_12   product_ub_60  1
    w_27_12   normalized_mass_27_68  1
    w_27_12   normalized_ratio_27_69  -1.7142857142857142e+00
    w_27_12   full_original_Gini_306  -2.2141666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_13   OBJ       2.0999999999999991e-02
    x_27_13   product_lb_61  -2.4694987505487574e-02
    x_27_13   product_ub_62  -4.1418076031795294e-02
    x_27_13   onehot_27_67  1
    x_27_13   stock_lb_246  13
    x_27_13   stock_ub_247  13
    x_27_13   parent_nonstrict_scope_248  6.2999999999999987e-02
    x_27_13   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_13   product_lb_61  1
    w_27_13   product_ub_62  1
    w_27_13   normalized_mass_27_68  1
    w_27_13   normalized_ratio_27_69  -1.8571428571428570e+00
    w_27_13   full_original_Gini_306  -2.5998809523809527e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_14   OBJ       0.0315
    x_27_14   product_lb_63  -2.4694987505487574e-02
    x_27_14   product_ub_64  -4.1418076031795294e-02
    x_27_14   onehot_27_67  1
    x_27_14   stock_lb_246  14
    x_27_14   stock_ub_247  14
    x_27_14   parent_nonstrict_scope_248  0.0735
    x_27_14   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_14   product_lb_63  1
    w_27_14   product_ub_64  1
    w_27_14   normalized_mass_27_68  1
    w_27_14   normalized_ratio_27_69  -2
    w_27_14   full_original_Gini_306  -2.9855952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_27_15   OBJ       4.1999999999999996e-02
    x_27_15   product_lb_65  -2.4694987505487574e-02
    x_27_15   product_ub_66  -4.1418076031795294e-02
    x_27_15   onehot_27_67  1
    x_27_15   stock_lb_246  15
    x_27_15   stock_ub_247  15
    x_27_15   parent_nonstrict_scope_248  8.3999999999999991e-02
    x_27_15   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_27_15   product_lb_65  1
    w_27_15   product_ub_66  1
    w_27_15   normalized_mass_27_68  1
    w_27_15   normalized_ratio_27_69  -2.1428571428571428e+00
    w_27_15   full_original_Gini_306  -3.3713095238095235e+01
    rho_27    normalized_ratio_27_69  1
    rho_27    block_pair_pos_255  1
    rho_27    block_pair_neg_256  -1
    rho_27    block_pair_pos_269  -1
    rho_27    block_pair_neg_270  1
    rho_27    block_pair_pos_271  -1
    rho_27    block_pair_neg_272  1
    rho_27    block_pair_pos_273  -1
    rho_27    block_pair_neg_274  1
    rho_27    block_pair_pos_275  -1
    rho_27    block_pair_neg_276  1
    rho_27    block_pair_pos_277  -1
    rho_27    block_pair_neg_278  1
    rho_27    block_pair_pos_279  -1
    rho_27    block_pair_neg_280  1
    rho_27    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_70  -2.4694987505487574e-02
    x_31_0    product_ub_71  -4.1418076031795294e-02
    x_31_0    onehot_31_96  1
    x_31_0    parent_nonstrict_scope_248  0.0735
    x_31_0    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_70  1
    w_31_0    product_ub_71  1
    w_31_0    normalized_mass_31_97  1
    w_31_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_72  -2.4694987505487574e-02
    x_31_1    product_ub_73  -4.1418076031795294e-02
    x_31_1    onehot_31_96  1
    x_31_1    stock_lb_246  1
    x_31_1    stock_ub_247  1
    x_31_1    parent_nonstrict_scope_248  0.063
    x_31_1    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_72  1
    w_31_1    product_ub_73  1
    w_31_1    normalized_mass_31_97  1
    w_31_1    normalized_ratio_31_98  -1.4285714285714285e-01
    w_31_1    full_original_Gini_306  -2.0572619047619053e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_74  -2.4694987505487574e-02
    x_31_2    product_ub_75  -4.1418076031795294e-02
    x_31_2    onehot_31_96  1
    x_31_2    stock_lb_246  2
    x_31_2    stock_ub_247  2
    x_31_2    parent_nonstrict_scope_248  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_74  1
    w_31_2    product_ub_75  1
    w_31_2    normalized_mass_31_97  1
    w_31_2    normalized_ratio_31_98  -2.8571428571428570e-01
    w_31_2    full_original_Gini_306  -1.7001190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_76  -2.4694987505487574e-02
    x_31_3    product_ub_77  -4.1418076031795294e-02
    x_31_3    onehot_31_96  1
    x_31_3    stock_lb_246  3
    x_31_3    stock_ub_247  3
    x_31_3    parent_nonstrict_scope_248  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_76  1
    w_31_3    product_ub_77  1
    w_31_3    normalized_mass_31_97  1
    w_31_3    normalized_ratio_31_98  -4.2857142857142855e-01
    w_31_3    full_original_Gini_306  -1.3486904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_78  -2.4694987505487574e-02
    x_31_4    product_ub_79  -4.1418076031795294e-02
    x_31_4    onehot_31_96  1
    x_31_4    stock_lb_246  4
    x_31_4    stock_ub_247  4
    x_31_4    parent_nonstrict_scope_248  0.0315
    x_31_4    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_78  1
    w_31_4    product_ub_79  1
    w_31_4    normalized_mass_31_97  1
    w_31_4    normalized_ratio_31_98  -5.7142857142857140e-01
    w_31_4    full_original_Gini_306  -1.0201190476190481e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_80  -2.4694987505487574e-02
    x_31_5    product_ub_81  -4.1418076031795294e-02
    x_31_5    onehot_31_96  1
    x_31_5    stock_lb_246  5
    x_31_5    stock_ub_247  5
    x_31_5    parent_nonstrict_scope_248  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_80  1
    w_31_5    product_ub_81  1
    w_31_5    normalized_mass_31_97  1
    w_31_5    normalized_ratio_31_98  -7.1428571428571419e-01
    w_31_5    full_original_Gini_306  -6.91547619047619
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_82  -2.4694987505487574e-02
    x_31_6    product_ub_83  -4.1418076031795294e-02
    x_31_6    onehot_31_96  1
    x_31_6    stock_lb_246  6
    x_31_6    stock_ub_247  6
    x_31_6    parent_nonstrict_scope_248  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_82  1
    w_31_6    product_ub_83  1
    w_31_6    normalized_mass_31_97  1
    w_31_6    normalized_ratio_31_98  -8.5714285714285710e-01
    w_31_6    full_original_Gini_306  -4.3630952380952381e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_84  -2.4694987505487574e-02
    x_31_7    product_ub_85  -4.1418076031795294e-02
    x_31_7    onehot_31_96  1
    x_31_7    stock_lb_246  7
    x_31_7    stock_ub_247  7
    x_31_7    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_84  1
    w_31_7    product_ub_85  1
    w_31_7    normalized_mass_31_97  1
    w_31_7    normalized_ratio_31_98  -1
    w_31_7    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_86  -2.4694987505487574e-02
    x_31_8    product_ub_87  -4.1418076031795294e-02
    x_31_8    onehot_31_96  1
    x_31_8    stock_lb_246  8
    x_31_8    stock_ub_247  8
    x_31_8    parent_nonstrict_scope_248  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_86  1
    w_31_8    product_ub_87  1
    w_31_8    normalized_mass_31_97  1
    w_31_8    normalized_ratio_31_98  -1.1428571428571428e+00
    w_31_8    full_original_Gini_306  -6.8273809523809490e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_88  -2.4694987505487574e-02
    x_31_9    product_ub_89  -4.1418076031795294e-02
    x_31_9    onehot_31_96  1
    x_31_9    stock_lb_246  9
    x_31_9    stock_ub_247  9
    x_31_9    parent_nonstrict_scope_248  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_88  1
    w_31_9    product_ub_89  1
    w_31_9    normalized_mass_31_97  1
    w_31_9    normalized_ratio_31_98  -1.2857142857142856e+00
    w_31_9    full_original_Gini_306  -1.0570238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_90  -2.4694987505487574e-02
    x_31_10   product_ub_91  -4.1418076031795294e-02
    x_31_10   onehot_31_96  1
    x_31_10   stock_lb_246  10
    x_31_10   stock_ub_247  10
    x_31_10   parent_nonstrict_scope_248  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_90  1
    w_31_10   product_ub_91  1
    w_31_10   normalized_mass_31_97  1
    w_31_10   normalized_ratio_31_98  -1.4285714285714284e+00
    w_31_10   full_original_Gini_306  -1.4427380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_92  -2.4694987505487574e-02
    x_31_11   product_ub_93  -4.1418076031795294e-02
    x_31_11   onehot_31_96  1
    x_31_11   stock_lb_246  11
    x_31_11   stock_ub_247  11
    x_31_11   parent_nonstrict_scope_248  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_92  1
    w_31_11   product_ub_93  1
    w_31_11   normalized_mass_31_97  1
    w_31_11   normalized_ratio_31_98  -1.5714285714285714e+00
    w_31_11   full_original_Gini_306  -1.8284523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_94  -2.4694987505487574e-02
    x_31_12   product_ub_95  -4.1418076031795294e-02
    x_31_12   onehot_31_96  1
    x_31_12   stock_lb_246  12
    x_31_12   stock_ub_247  12
    x_31_12   parent_nonstrict_scope_248  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_94  1
    w_31_12   product_ub_95  1
    w_31_12   normalized_mass_31_97  1
    w_31_12   normalized_ratio_31_98  -1.7142857142857142e+00
    w_31_12   full_original_Gini_306  -2.2141666666666666e+01
    rho_31    normalized_ratio_31_98  1
    rho_31    block_pair_pos_259  1
    rho_31    block_pair_neg_260  -1
    rho_31    block_pair_pos_275  1
    rho_31    block_pair_neg_276  -1
    rho_31    block_pair_pos_289  -1
    rho_31    block_pair_neg_290  1
    rho_31    block_pair_pos_291  -1
    rho_31    block_pair_neg_292  1
    rho_31    block_pair_pos_293  -1
    rho_31    block_pair_neg_294  1
    rho_31    block_pair_pos_295  -1
    rho_31    block_pair_neg_296  1
    rho_31    block_pair_pos_297  -1
    rho_31    block_pair_neg_298  1
    rho_31    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_29_0    OBJ       0.048
    x_29_0    product_lb_99  -2.4694987505487574e-02
    x_29_0    product_ub_100  -4.1418076031795294e-02
    x_29_0    onehot_29_131  1
    x_29_0    parent_nonstrict_scope_248  0.096
    x_29_0    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_0    product_lb_99  1
    w_29_0    product_ub_100  1
    w_29_0    normalized_mass_29_132  1
    w_29_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_1    OBJ       3.6000000000000004e-02
    x_29_1    product_lb_101  -2.4694987505487574e-02
    x_29_1    product_ub_102  -4.1418076031795294e-02
    x_29_1    onehot_29_131  1
    x_29_1    stock_lb_246  1
    x_29_1    stock_ub_247  1
    x_29_1    parent_nonstrict_scope_248  0.084
    x_29_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_1    product_lb_101  1
    w_29_1    product_ub_102  1
    w_29_1    normalized_mass_29_132  1
    w_29_1    normalized_ratio_29_133  -0.125
    w_29_1    full_original_Gini_306  -2.1019047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_2    OBJ       2.4000000000000007e-02
    x_29_2    product_lb_103  -2.4694987505487574e-02
    x_29_2    product_ub_104  -4.1418076031795294e-02
    x_29_2    onehot_29_131  1
    x_29_2    stock_lb_246  2
    x_29_2    stock_ub_247  2
    x_29_2    parent_nonstrict_scope_248  7.2000000000000008e-02
    x_29_2    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_2    product_lb_103  1
    w_29_2    product_ub_104  1
    w_29_2    normalized_mass_29_132  1
    w_29_2    normalized_ratio_29_133  -0.25
    w_29_2    full_original_Gini_306  -1.7894047619047623e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_3    OBJ       1.1999999999999997e-02
    x_29_3    product_lb_105  -2.4694987505487574e-02
    x_29_3    product_ub_106  -4.1418076031795294e-02
    x_29_3    onehot_29_131  1
    x_29_3    stock_lb_246  3
    x_29_3    stock_ub_247  3
    x_29_3    parent_nonstrict_scope_248  0.06
    x_29_3    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_3    product_lb_105  1
    w_29_3    product_ub_106  1
    w_29_3    normalized_mass_29_132  1
    w_29_3    normalized_ratio_29_133  -0.375
    w_29_3    full_original_Gini_306  -1.4769047619047621e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_4    product_lb_107  -2.4694987505487574e-02
    x_29_4    product_ub_108  -4.1418076031795294e-02
    x_29_4    onehot_29_131  1
    x_29_4    stock_lb_246  4
    x_29_4    stock_ub_247  4
    x_29_4    parent_nonstrict_scope_248  0.048
    x_29_4    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_4    product_lb_107  1
    w_29_4    product_ub_108  1
    w_29_4    normalized_mass_29_132  1
    w_29_4    normalized_ratio_29_133  -0.5
    w_29_4    full_original_Gini_306  -1.1844047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_5    OBJ       -1.1999999999999997e-02
    x_29_5    product_lb_109  -2.4694987505487574e-02
    x_29_5    product_ub_110  -4.1418076031795294e-02
    x_29_5    onehot_29_131  1
    x_29_5    stock_lb_246  5
    x_29_5    stock_ub_247  5
    x_29_5    parent_nonstrict_scope_248  3.6000000000000004e-02
    x_29_5    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_5    product_lb_109  1
    w_29_5    product_ub_110  1
    w_29_5    normalized_mass_29_132  1
    w_29_5    normalized_ratio_29_133  -0.625
    w_29_5    full_original_Gini_306  -8.9690476190476183e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_6    OBJ       -0.024
    x_29_6    product_lb_111  -2.4694987505487574e-02
    x_29_6    product_ub_112  -4.1418076031795294e-02
    x_29_6    onehot_29_131  1
    x_29_6    stock_lb_246  6
    x_29_6    stock_ub_247  6
    x_29_6    parent_nonstrict_scope_248  0.024
    x_29_6    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_6    product_lb_111  1
    w_29_6    product_ub_112  1
    w_29_6    normalized_mass_29_132  1
    w_29_6    normalized_ratio_29_133  -0.75
    w_29_6    full_original_Gini_306  -6.2369047619047615e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_7    OBJ       -3.6000000000000004e-02
    x_29_7    product_lb_113  -2.4694987505487574e-02
    x_29_7    product_ub_114  -4.1418076031795294e-02
    x_29_7    onehot_29_131  1
    x_29_7    stock_lb_246  7
    x_29_7    stock_ub_247  7
    x_29_7    parent_nonstrict_scope_248  0.012
    x_29_7    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_7    product_lb_113  1
    w_29_7    product_ub_114  1
    w_29_7    normalized_mass_29_132  1
    w_29_7    normalized_ratio_29_133  -0.875
    w_29_7    full_original_Gini_306  -4.1309523809523823e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_8    OBJ       -0.048
    x_29_8    product_lb_115  -2.4694987505487574e-02
    x_29_8    product_ub_116  -4.1418076031795294e-02
    x_29_8    onehot_29_131  1
    x_29_8    stock_lb_246  8
    x_29_8    stock_ub_247  8
    x_29_8    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_8    product_lb_115  1
    w_29_8    product_ub_116  1
    w_29_8    normalized_mass_29_132  1
    w_29_8    normalized_ratio_29_133  -1
    w_29_8    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_9    OBJ       -3.6000000000000004e-02
    x_29_9    product_lb_117  -2.4694987505487574e-02
    x_29_9    product_ub_118  -4.1418076031795294e-02
    x_29_9    onehot_29_131  1
    x_29_9    stock_lb_246  9
    x_29_9    stock_ub_247  9
    x_29_9    parent_nonstrict_scope_248  0.012
    x_29_9    unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_9    product_lb_117  1
    w_29_9    product_ub_118  1
    w_29_9    normalized_mass_29_132  1
    w_29_9    normalized_ratio_29_133  -1.125
    w_29_9    full_original_Gini_306  -6.3809523809523823e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_10   OBJ       -0.024
    x_29_10   product_lb_119  -2.4694987505487574e-02
    x_29_10   product_ub_120  -4.1418076031795294e-02
    x_29_10   onehot_29_131  1
    x_29_10   stock_lb_246  10
    x_29_10   stock_ub_247  10
    x_29_10   parent_nonstrict_scope_248  0.024
    x_29_10   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_10   product_lb_119  1
    w_29_10   product_ub_120  1
    w_29_10   normalized_mass_29_132  1
    w_29_10   normalized_ratio_29_133  -1.25
    w_29_10   full_original_Gini_306  -9.6059523809523810e+00
    MARKER    'MARKER'                 'INTORG'
    x_29_11   OBJ       -1.1999999999999997e-02
    x_29_11   product_lb_121  -2.4694987505487574e-02
    x_29_11   product_ub_122  -4.1418076031795294e-02
    x_29_11   onehot_29_131  1
    x_29_11   stock_lb_246  11
    x_29_11   stock_ub_247  11
    x_29_11   parent_nonstrict_scope_248  3.6000000000000004e-02
    MARKER    'MARKER'                 'INTEND'
    w_29_11   product_lb_121  1
    w_29_11   product_ub_122  1
    w_29_11   normalized_mass_29_132  1
    w_29_11   normalized_ratio_29_133  -1.375
    w_29_11   full_original_Gini_306  -1.2980952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_12   product_lb_123  -2.4694987505487574e-02
    x_29_12   product_ub_124  -4.1418076031795294e-02
    x_29_12   onehot_29_131  1
    x_29_12   stock_lb_246  12
    x_29_12   stock_ub_247  12
    x_29_12   parent_nonstrict_scope_248  0.048
    x_29_12   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_12   product_lb_123  1
    w_29_12   product_ub_124  1
    w_29_12   normalized_mass_29_132  1
    w_29_12   normalized_ratio_29_133  -1.5
    w_29_12   full_original_Gini_306  -1.6355952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_13   OBJ       1.1999999999999997e-02
    x_29_13   product_lb_125  -2.4694987505487574e-02
    x_29_13   product_ub_126  -4.1418076031795294e-02
    x_29_13   onehot_29_131  1
    x_29_13   stock_lb_246  13
    x_29_13   stock_ub_247  13
    x_29_13   parent_nonstrict_scope_248  0.06
    x_29_13   unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_13   product_lb_125  1
    w_29_13   product_ub_126  1
    w_29_13   normalized_mass_29_132  1
    w_29_13   normalized_ratio_29_133  -1.625
    w_29_13   full_original_Gini_306  -1.9730952380952377e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_14   OBJ       2.4000000000000007e-02
    x_29_14   product_lb_127  -2.4694987505487574e-02
    x_29_14   product_ub_128  -4.1418076031795294e-02
    x_29_14   onehot_29_131  1
    x_29_14   stock_lb_246  14
    x_29_14   stock_ub_247  14
    x_29_14   parent_nonstrict_scope_248  7.2000000000000008e-02
    x_29_14   unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_14   product_lb_127  1
    w_29_14   product_ub_128  1
    w_29_14   normalized_mass_29_132  1
    w_29_14   normalized_ratio_29_133  -1.75
    w_29_14   full_original_Gini_306  -2.3105952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_29_15   OBJ       3.6000000000000004e-02
    x_29_15   product_lb_129  -2.4694987505487574e-02
    x_29_15   product_ub_130  -4.1418076031795294e-02
    x_29_15   onehot_29_131  1
    x_29_15   stock_lb_246  15
    x_29_15   stock_ub_247  15
    x_29_15   parent_nonstrict_scope_248  0.084
    x_29_15   unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_29_15   product_lb_129  1
    w_29_15   product_ub_130  1
    w_29_15   normalized_mass_29_132  1
    w_29_15   normalized_ratio_29_133  -1.875
    w_29_15   full_original_Gini_306  -2.6480952380952381e+01
    rho_29    normalized_ratio_29_133  1
    rho_29    block_pair_pos_257  1
    rho_29    block_pair_neg_258  -1
    rho_29    block_pair_pos_273  1
    rho_29    block_pair_neg_274  -1
    rho_29    block_pair_pos_281  -1
    rho_29    block_pair_neg_282  1
    rho_29    block_pair_pos_283  -1
    rho_29    block_pair_neg_284  1
    rho_29    block_pair_pos_285  -1
    rho_29    block_pair_neg_286  1
    rho_29    block_pair_pos_287  -1
    rho_29    block_pair_neg_288  1
    rho_29    block_pair_pos_293  1
    rho_29    block_pair_neg_294  -1
    rho_29    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_134  -2.4694987505487574e-02
    x_32_0    product_ub_135  -4.1418076031795294e-02
    x_32_0    onehot_32_160  1
    x_32_0    parent_nonstrict_scope_248  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_134  1
    w_32_0    product_ub_135  1
    w_32_0    normalized_mass_32_161  1
    w_32_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_136  -2.4694987505487574e-02
    x_32_1    product_ub_137  -4.1418076031795294e-02
    x_32_1    onehot_32_160  1
    x_32_1    stock_lb_246  1
    x_32_1    stock_ub_247  1
    x_32_1    parent_nonstrict_scope_248  0.03
    x_32_1    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_136  1
    w_32_1    product_ub_137  1
    w_32_1    normalized_mass_32_161  1
    w_32_1    normalized_ratio_32_162  -0.2
    w_32_1    full_original_Gini_306  -1.9144047619047626e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_138  -2.4694987505487574e-02
    x_32_2    product_ub_139  -4.1418076031795294e-02
    x_32_2    onehot_32_160  1
    x_32_2    stock_lb_246  2
    x_32_2    stock_ub_247  2
    x_32_2    parent_nonstrict_scope_248  0.0225
    x_32_2    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_138  1
    w_32_2    product_ub_139  1
    w_32_2    normalized_mass_32_161  1
    w_32_2    normalized_ratio_32_162  -0.4
    w_32_2    full_original_Gini_306  -1.4144047619047615e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_140  -2.4694987505487574e-02
    x_32_3    product_ub_141  -4.1418076031795294e-02
    x_32_3    onehot_32_160  1
    x_32_3    stock_lb_246  3
    x_32_3    stock_ub_247  3
    x_32_3    parent_nonstrict_scope_248  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_140  1
    w_32_3    product_ub_141  1
    w_32_3    normalized_mass_32_161  1
    w_32_3    normalized_ratio_32_162  -6.0000000000000009e-01
    w_32_3    full_original_Gini_306  -9.5440476190476211e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_142  -2.4694987505487574e-02
    x_32_4    product_ub_143  -4.1418076031795294e-02
    x_32_4    onehot_32_160  1
    x_32_4    stock_lb_246  4
    x_32_4    stock_ub_247  4
    x_32_4    parent_nonstrict_scope_248  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_142  1
    w_32_4    product_ub_143  1
    w_32_4    normalized_mass_32_161  1
    w_32_4    normalized_ratio_32_162  -0.8
    w_32_4    full_original_Gini_306  -5.2869047619047631e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_144  -2.4694987505487574e-02
    x_32_5    product_ub_145  -4.1418076031795294e-02
    x_32_5    onehot_32_160  1
    x_32_5    stock_lb_246  5
    x_32_5    stock_ub_247  5
    x_32_5    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_144  1
    w_32_5    product_ub_145  1
    w_32_5    normalized_mass_32_161  1
    w_32_5    normalized_ratio_32_162  -1
    w_32_5    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_146  -2.4694987505487574e-02
    x_32_6    product_ub_147  -4.1418076031795294e-02
    x_32_6    onehot_32_160  1
    x_32_6    stock_lb_246  6
    x_32_6    stock_ub_247  6
    x_32_6    parent_nonstrict_scope_248  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_146  1
    w_32_6    product_ub_147  1
    w_32_6    normalized_mass_32_161  1
    w_32_6    normalized_ratio_32_162  -1.2000000000000002e+00
    w_32_6    full_original_Gini_306  -8.2559523809523867e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_148  -2.4694987505487574e-02
    x_32_7    product_ub_149  -4.1418076031795294e-02
    x_32_7    onehot_32_160  1
    x_32_7    stock_lb_246  7
    x_32_7    stock_ub_247  7
    x_32_7    parent_nonstrict_scope_248  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_148  1
    w_32_7    product_ub_149  1
    w_32_7    normalized_mass_32_161  1
    w_32_7    normalized_ratio_32_162  -1.4000000000000001e+00
    w_32_7    full_original_Gini_306  -1.3655952380952387e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_150  -2.4694987505487574e-02
    x_32_8    product_ub_151  -4.1418076031795294e-02
    x_32_8    onehot_32_160  1
    x_32_8    stock_lb_246  8
    x_32_8    stock_ub_247  8
    x_32_8    parent_nonstrict_scope_248  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_150  1
    w_32_8    product_ub_151  1
    w_32_8    normalized_mass_32_161  1
    w_32_8    normalized_ratio_32_162  -1.6
    w_32_8    full_original_Gini_306  -1.9055952380952387e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_152  -2.4694987505487574e-02
    x_32_9    product_ub_153  -4.1418076031795294e-02
    x_32_9    onehot_32_160  1
    x_32_9    stock_lb_246  9
    x_32_9    stock_ub_247  9
    x_32_9    parent_nonstrict_scope_248  0.03
    x_32_9    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_152  1
    w_32_9    product_ub_153  1
    w_32_9    normalized_mass_32_161  1
    w_32_9    normalized_ratio_32_162  -1.8
    w_32_9    full_original_Gini_306  -2.4455952380952390e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_154  -2.4694987505487574e-02
    x_32_10   product_ub_155  -4.1418076031795294e-02
    x_32_10   onehot_32_160  1
    x_32_10   stock_lb_246  10
    x_32_10   stock_ub_247  10
    x_32_10   parent_nonstrict_scope_248  0.0375
    x_32_10   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_154  1
    w_32_10   product_ub_155  1
    w_32_10   normalized_mass_32_161  1
    w_32_10   normalized_ratio_32_162  -2
    w_32_10   full_original_Gini_306  -2.9855952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_156  -2.4694987505487574e-02
    x_32_11   product_ub_157  -4.1418076031795294e-02
    x_32_11   onehot_32_160  1
    x_32_11   stock_lb_246  11
    x_32_11   stock_ub_247  11
    x_32_11   parent_nonstrict_scope_248  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_156  1
    w_32_11   product_ub_157  1
    w_32_11   normalized_mass_32_161  1
    w_32_11   normalized_ratio_32_162  -2.2
    w_32_11   full_original_Gini_306  -3.5255952380952380e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_158  -2.4694987505487574e-02
    x_32_12   product_ub_159  -4.1418076031795294e-02
    x_32_12   onehot_32_160  1
    x_32_12   stock_lb_246  12
    x_32_12   stock_ub_247  12
    x_32_12   parent_nonstrict_scope_248  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_158  1
    w_32_12   product_ub_159  1
    w_32_12   normalized_mass_32_161  1
    w_32_12   normalized_ratio_32_162  -2.4000000000000004e+00
    w_32_12   full_original_Gini_306  -4.0655952380952378e+01
    rho_32    normalized_ratio_32_162  1
    rho_32    block_pair_pos_261  1
    rho_32    block_pair_neg_262  -1
    rho_32    block_pair_pos_277  1
    rho_32    block_pair_neg_278  -1
    rho_32    block_pair_pos_285  1
    rho_32    block_pair_neg_286  -1
    rho_32    block_pair_pos_295  1
    rho_32    block_pair_neg_296  -1
    rho_32    block_pair_pos_299  -1
    rho_32    block_pair_neg_300  1
    rho_32    block_pair_pos_301  -1
    rho_32    block_pair_neg_302  1
    rho_32    block_pair_pos_303  -1
    rho_32    block_pair_neg_304  1
    rho_32    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_25_0    OBJ       0.0315
    x_25_0    product_lb_163  -2.4694987505487574e-02
    x_25_0    product_ub_164  -4.1418076031795294e-02
    x_25_0    onehot_25_195  1
    x_25_0    parent_nonstrict_scope_248  0.0735
    x_25_0    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_0    product_lb_163  1
    w_25_0    product_ub_164  1
    w_25_0    normalized_mass_25_196  1
    w_25_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_1    OBJ       2.1000000000000005e-02
    x_25_1    product_lb_165  -2.4694987505487574e-02
    x_25_1    product_ub_166  -4.1418076031795294e-02
    x_25_1    onehot_25_195  1
    x_25_1    stock_lb_246  1
    x_25_1    stock_ub_247  1
    x_25_1    parent_nonstrict_scope_248  0.063
    MARKER    'MARKER'                 'INTEND'
    w_25_1    product_lb_165  1
    w_25_1    product_ub_166  1
    w_25_1    normalized_mass_25_196  1
    w_25_1    normalized_ratio_25_197  -1.4285714285714285e-01
    w_25_1    full_original_Gini_306  -2.0572619047619053e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_2    OBJ       1.0500000000000002e-02
    x_25_2    product_lb_167  -2.4694987505487574e-02
    x_25_2    product_ub_168  -4.1418076031795294e-02
    x_25_2    onehot_25_195  1
    x_25_2    stock_lb_246  2
    x_25_2    stock_ub_247  2
    x_25_2    parent_nonstrict_scope_248  0.0525
    x_25_2    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_2    product_lb_167  1
    w_25_2    product_ub_168  1
    w_25_2    normalized_mass_25_196  1
    w_25_2    normalized_ratio_25_197  -2.8571428571428570e-01
    w_25_2    full_original_Gini_306  -1.7001190476190473e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_3    product_lb_169  -2.4694987505487574e-02
    x_25_3    product_ub_170  -4.1418076031795294e-02
    x_25_3    onehot_25_195  1
    x_25_3    stock_lb_246  3
    x_25_3    stock_ub_247  3
    x_25_3    parent_nonstrict_scope_248  4.1999999999999996e-02
    x_25_3    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_3    product_lb_169  1
    w_25_3    product_ub_170  1
    w_25_3    normalized_mass_25_196  1
    w_25_3    normalized_ratio_25_197  -4.2857142857142855e-01
    w_25_3    full_original_Gini_306  -1.3486904761904759e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_4    OBJ       -1.0499999999999995e-02
    x_25_4    product_lb_171  -2.4694987505487574e-02
    x_25_4    product_ub_172  -4.1418076031795294e-02
    x_25_4    onehot_25_195  1
    x_25_4    stock_lb_246  4
    x_25_4    stock_ub_247  4
    x_25_4    parent_nonstrict_scope_248  0.0315
    x_25_4    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_4    product_lb_171  1
    w_25_4    product_ub_172  1
    w_25_4    normalized_mass_25_196  1
    w_25_4    normalized_ratio_25_197  -5.7142857142857140e-01
    w_25_4    full_original_Gini_306  -1.0201190476190481e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_5    OBJ       -2.0999999999999991e-02
    x_25_5    product_lb_173  -2.4694987505487574e-02
    x_25_5    product_ub_174  -4.1418076031795294e-02
    x_25_5    onehot_25_195  1
    x_25_5    stock_lb_246  5
    x_25_5    stock_ub_247  5
    x_25_5    parent_nonstrict_scope_248  2.1000000000000005e-02
    x_25_5    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_5    product_lb_173  1
    w_25_5    product_ub_174  1
    w_25_5    normalized_mass_25_196  1
    w_25_5    normalized_ratio_25_197  -7.1428571428571419e-01
    w_25_5    full_original_Gini_306  -6.91547619047619
    MARKER    'MARKER'                 'INTORG'
    x_25_6    OBJ       -3.1499999999999993e-02
    x_25_6    product_lb_175  -2.4694987505487574e-02
    x_25_6    product_ub_176  -4.1418076031795294e-02
    x_25_6    onehot_25_195  1
    x_25_6    stock_lb_246  6
    x_25_6    stock_ub_247  6
    x_25_6    parent_nonstrict_scope_248  1.0500000000000002e-02
    x_25_6    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_6    product_lb_175  1
    w_25_6    product_ub_176  1
    w_25_6    normalized_mass_25_196  1
    w_25_6    normalized_ratio_25_197  -8.5714285714285710e-01
    w_25_6    full_original_Gini_306  -4.3630952380952381e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_7    OBJ       -4.1999999999999996e-02
    x_25_7    product_lb_177  -2.4694987505487574e-02
    x_25_7    product_ub_178  -4.1418076031795294e-02
    x_25_7    onehot_25_195  1
    x_25_7    stock_lb_246  7
    x_25_7    stock_ub_247  7
    x_25_7    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_7    product_lb_177  1
    w_25_7    product_ub_178  1
    w_25_7    normalized_mass_25_196  1
    w_25_7    normalized_ratio_25_197  -1
    w_25_7    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_8    OBJ       -0.0315
    x_25_8    product_lb_179  -2.4694987505487574e-02
    x_25_8    product_ub_180  -4.1418076031795294e-02
    x_25_8    onehot_25_195  1
    x_25_8    stock_lb_246  8
    x_25_8    stock_ub_247  8
    x_25_8    parent_nonstrict_scope_248  1.0499999999999995e-02
    x_25_8    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_8    product_lb_179  1
    w_25_8    product_ub_180  1
    w_25_8    normalized_mass_25_196  1
    w_25_8    normalized_ratio_25_197  -1.1428571428571428e+00
    w_25_8    full_original_Gini_306  -6.8273809523809490e+00
    MARKER    'MARKER'                 'INTORG'
    x_25_9    OBJ       -2.1000000000000005e-02
    x_25_9    product_lb_181  -2.4694987505487574e-02
    x_25_9    product_ub_182  -4.1418076031795294e-02
    x_25_9    onehot_25_195  1
    x_25_9    stock_lb_246  9
    x_25_9    stock_ub_247  9
    x_25_9    parent_nonstrict_scope_248  2.0999999999999991e-02
    x_25_9    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_9    product_lb_181  1
    w_25_9    product_ub_182  1
    w_25_9    normalized_mass_25_196  1
    w_25_9    normalized_ratio_25_197  -1.2857142857142856e+00
    w_25_9    full_original_Gini_306  -1.0570238095238093e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_10   OBJ       -1.0500000000000009e-02
    x_25_10   product_lb_183  -2.4694987505487574e-02
    x_25_10   product_ub_184  -4.1418076031795294e-02
    x_25_10   onehot_25_195  1
    x_25_10   stock_lb_246  10
    x_25_10   stock_ub_247  10
    x_25_10   parent_nonstrict_scope_248  3.1499999999999986e-02
    x_25_10   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_10   product_lb_183  1
    w_25_10   product_ub_184  1
    w_25_10   normalized_mass_25_196  1
    w_25_10   normalized_ratio_25_197  -1.4285714285714284e+00
    w_25_10   full_original_Gini_306  -1.4427380952380952e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_11   product_lb_185  -2.4694987505487574e-02
    x_25_11   product_ub_186  -4.1418076031795294e-02
    x_25_11   onehot_25_195  1
    x_25_11   stock_lb_246  11
    x_25_11   stock_ub_247  11
    x_25_11   parent_nonstrict_scope_248  4.1999999999999996e-02
    x_25_11   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_11   product_lb_185  1
    w_25_11   product_ub_186  1
    w_25_11   normalized_mass_25_196  1
    w_25_11   normalized_ratio_25_197  -1.5714285714285714e+00
    w_25_11   full_original_Gini_306  -1.8284523809523808e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_12   OBJ       1.0499999999999995e-02
    x_25_12   product_lb_187  -2.4694987505487574e-02
    x_25_12   product_ub_188  -4.1418076031795294e-02
    x_25_12   onehot_25_195  1
    x_25_12   stock_lb_246  12
    x_25_12   stock_ub_247  12
    x_25_12   parent_nonstrict_scope_248  5.2499999999999991e-02
    x_25_12   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_12   product_lb_187  1
    w_25_12   product_ub_188  1
    w_25_12   normalized_mass_25_196  1
    w_25_12   normalized_ratio_25_197  -1.7142857142857142e+00
    w_25_12   full_original_Gini_306  -2.2141666666666666e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_13   OBJ       2.0999999999999991e-02
    x_25_13   product_lb_189  -2.4694987505487574e-02
    x_25_13   product_ub_190  -4.1418076031795294e-02
    x_25_13   onehot_25_195  1
    x_25_13   stock_lb_246  13
    x_25_13   stock_ub_247  13
    x_25_13   parent_nonstrict_scope_248  6.2999999999999987e-02
    x_25_13   unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_13   product_lb_189  1
    w_25_13   product_ub_190  1
    w_25_13   normalized_mass_25_196  1
    w_25_13   normalized_ratio_25_197  -1.8571428571428570e+00
    w_25_13   full_original_Gini_306  -2.5998809523809527e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_14   OBJ       0.0315
    x_25_14   product_lb_191  -2.4694987505487574e-02
    x_25_14   product_ub_192  -4.1418076031795294e-02
    x_25_14   onehot_25_195  1
    x_25_14   stock_lb_246  14
    x_25_14   stock_ub_247  14
    x_25_14   parent_nonstrict_scope_248  0.0735
    x_25_14   unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_14   product_lb_191  1
    w_25_14   product_ub_192  1
    w_25_14   normalized_mass_25_196  1
    w_25_14   normalized_ratio_25_197  -2
    w_25_14   full_original_Gini_306  -2.9855952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_25_15   OBJ       4.1999999999999996e-02
    x_25_15   product_lb_193  -2.4694987505487574e-02
    x_25_15   product_ub_194  -4.1418076031795294e-02
    x_25_15   onehot_25_195  1
    x_25_15   stock_lb_246  15
    x_25_15   stock_ub_247  15
    x_25_15   parent_nonstrict_scope_248  8.3999999999999991e-02
    x_25_15   unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_25_15   product_lb_193  1
    w_25_15   product_ub_194  1
    w_25_15   normalized_mass_25_196  1
    w_25_15   normalized_ratio_25_197  -2.1428571428571428e+00
    w_25_15   full_original_Gini_306  -3.3713095238095235e+01
    rho_25    normalized_ratio_25_197  1
    rho_25    block_pair_pos_253  1
    rho_25    block_pair_neg_254  -1
    rho_25    block_pair_pos_265  -1
    rho_25    block_pair_neg_266  1
    rho_25    block_pair_pos_267  -1
    rho_25    block_pair_neg_268  1
    rho_25    block_pair_pos_271  1
    rho_25    block_pair_neg_272  -1
    rho_25    block_pair_pos_283  1
    rho_25    block_pair_neg_284  -1
    rho_25    block_pair_pos_291  1
    rho_25    block_pair_neg_292  -1
    rho_25    block_pair_pos_301  1
    rho_25    block_pair_neg_302  -1
    rho_25    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_19_0    OBJ       0.012
    x_19_0    product_lb_198  -2.4694987505487574e-02
    x_19_0    product_ub_199  -4.1418076031795294e-02
    x_19_0    onehot_19_216  1
    x_19_0    parent_nonstrict_scope_248  0.024
    MARKER    'MARKER'                 'INTEND'
    w_19_0    product_lb_198  1
    w_19_0    product_ub_199  1
    w_19_0    normalized_mass_19_217  1
    w_19_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_1    OBJ       6.0000000000000019e-03
    x_19_1    product_lb_200  -2.4694987505487574e-02
    x_19_1    product_ub_201  -4.1418076031795294e-02
    x_19_1    onehot_19_216  1
    x_19_1    stock_lb_246  1
    x_19_1    stock_ub_247  1
    x_19_1    parent_nonstrict_scope_248  1.8000000000000002e-02
    x_19_1    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_1    product_lb_200  1
    w_19_1    product_ub_201  1
    w_19_1    normalized_mass_19_217  1
    w_19_1    normalized_ratio_19_218  -0.25
    w_19_1    full_original_Gini_306  -1.7894047619047623e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_2    product_lb_202  -2.4694987505487574e-02
    x_19_2    product_ub_203  -4.1418076031795294e-02
    x_19_2    onehot_19_216  1
    x_19_2    stock_lb_246  2
    x_19_2    stock_ub_247  2
    x_19_2    parent_nonstrict_scope_248  0.012
    x_19_2    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_2    product_lb_202  1
    w_19_2    product_ub_203  1
    w_19_2    normalized_mass_19_217  1
    w_19_2    normalized_ratio_19_218  -0.5
    w_19_2    full_original_Gini_306  -1.1844047619047620e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_3    OBJ       -0.006
    x_19_3    product_lb_204  -2.4694987505487574e-02
    x_19_3    product_ub_205  -4.1418076031795294e-02
    x_19_3    onehot_19_216  1
    x_19_3    stock_lb_246  3
    x_19_3    stock_ub_247  3
    x_19_3    parent_nonstrict_scope_248  0.006
    x_19_3    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_3    product_lb_204  1
    w_19_3    product_ub_205  1
    w_19_3    normalized_mass_19_217  1
    w_19_3    normalized_ratio_19_218  -0.75
    w_19_3    full_original_Gini_306  -6.2369047619047615e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_4    OBJ       -0.012
    x_19_4    product_lb_206  -2.4694987505487574e-02
    x_19_4    product_ub_207  -4.1418076031795294e-02
    x_19_4    onehot_19_216  1
    x_19_4    stock_lb_246  4
    x_19_4    stock_ub_247  4
    x_19_4    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_4    product_lb_206  1
    w_19_4    product_ub_207  1
    w_19_4    normalized_mass_19_217  1
    w_19_4    normalized_ratio_19_218  -1
    w_19_4    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_5    OBJ       -0.006
    x_19_5    product_lb_208  -2.4694987505487574e-02
    x_19_5    product_ub_209  -4.1418076031795294e-02
    x_19_5    onehot_19_216  1
    x_19_5    stock_lb_246  5
    x_19_5    stock_ub_247  5
    x_19_5    parent_nonstrict_scope_248  0.006
    x_19_5    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_5    product_lb_208  1
    w_19_5    product_ub_209  1
    w_19_5    normalized_mass_19_217  1
    w_19_5    normalized_ratio_19_218  -1.25
    w_19_5    full_original_Gini_306  -9.6059523809523810e+00
    MARKER    'MARKER'                 'INTORG'
    x_19_6    product_lb_210  -2.4694987505487574e-02
    x_19_6    product_ub_211  -4.1418076031795294e-02
    x_19_6    onehot_19_216  1
    x_19_6    stock_lb_246  6
    x_19_6    stock_ub_247  6
    x_19_6    parent_nonstrict_scope_248  0.012
    x_19_6    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_6    product_lb_210  1
    w_19_6    product_ub_211  1
    w_19_6    normalized_mass_19_217  1
    w_19_6    normalized_ratio_19_218  -1.5
    w_19_6    full_original_Gini_306  -1.6355952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_7    OBJ       6.0000000000000019e-03
    x_19_7    product_lb_212  -2.4694987505487574e-02
    x_19_7    product_ub_213  -4.1418076031795294e-02
    x_19_7    onehot_19_216  1
    x_19_7    stock_lb_246  7
    x_19_7    stock_ub_247  7
    x_19_7    parent_nonstrict_scope_248  1.8000000000000002e-02
    x_19_7    unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_7    product_lb_212  1
    w_19_7    product_ub_213  1
    w_19_7    normalized_mass_19_217  1
    w_19_7    normalized_ratio_19_218  -1.75
    w_19_7    full_original_Gini_306  -2.3105952380952381e+01
    MARKER    'MARKER'                 'INTORG'
    x_19_8    OBJ       0.012
    x_19_8    product_lb_214  -2.4694987505487574e-02
    x_19_8    product_ub_215  -4.1418076031795294e-02
    x_19_8    onehot_19_216  1
    x_19_8    stock_lb_246  8
    x_19_8    stock_ub_247  8
    x_19_8    parent_nonstrict_scope_248  0.024
    x_19_8    unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_19_8    product_lb_214  1
    w_19_8    product_ub_215  1
    w_19_8    normalized_mass_19_217  1
    w_19_8    normalized_ratio_19_218  -2
    w_19_8    full_original_Gini_306  -2.9855952380952385e+01
    rho_19    normalized_ratio_19_218  1
    rho_19    block_pair_pos_249  -1
    rho_19    block_pair_neg_250  1
    rho_19    block_pair_pos_251  1
    rho_19    block_pair_neg_252  -1
    rho_19    block_pair_pos_265  1
    rho_19    block_pair_neg_266  -1
    rho_19    block_pair_pos_269  1
    rho_19    block_pair_neg_270  -1
    rho_19    block_pair_pos_281  1
    rho_19    block_pair_neg_282  -1
    rho_19    block_pair_pos_289  1
    rho_19    block_pair_neg_290  -1
    rho_19    block_pair_pos_299  1
    rho_19    block_pair_neg_300  -1
    rho_19    normalization_305  1
    MARKER    'MARKER'                 'INTORG'
    x_34_0    OBJ       1.4999999999999996e-02
    x_34_0    product_lb_219  -2.4694987505487574e-02
    x_34_0    product_ub_220  -4.1418076031795294e-02
    x_34_0    onehot_34_243  1
    x_34_0    parent_nonstrict_scope_248  0.0375
    x_34_0    unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_0    product_lb_219  1
    w_34_0    product_ub_220  1
    w_34_0    normalized_mass_34_244  1
    w_34_0    full_original_Gini_306  -2.4144047619047619e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_1    OBJ       7.4999999999999963e-03
    x_34_1    product_lb_221  -2.4694987505487574e-02
    x_34_1    product_ub_222  -4.1418076031795294e-02
    x_34_1    onehot_34_243  1
    x_34_1    stock_lb_246  1
    x_34_1    stock_ub_247  1
    x_34_1    parent_nonstrict_scope_248  0.03
    MARKER    'MARKER'                 'INTEND'
    w_34_1    product_lb_221  1
    w_34_1    product_ub_222  1
    w_34_1    normalized_mass_34_244  1
    w_34_1    normalized_ratio_34_245  -0.2
    w_34_1    full_original_Gini_306  -1.9144047619047626e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_2    OBJ       -3.4694469519536142e-18
    x_34_2    product_lb_223  -2.4694987505487574e-02
    x_34_2    product_ub_224  -4.1418076031795294e-02
    x_34_2    onehot_34_243  1
    x_34_2    stock_lb_246  2
    x_34_2    stock_ub_247  2
    x_34_2    parent_nonstrict_scope_248  0.0225
    x_34_2    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_2    product_lb_223  1
    w_34_2    product_ub_224  1
    w_34_2    normalized_mass_34_244  1
    w_34_2    normalized_ratio_34_245  -0.4
    w_34_2    full_original_Gini_306  -1.4144047619047615e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_3    OBJ       -7.5000000000000067e-03
    x_34_3    product_lb_225  -2.4694987505487574e-02
    x_34_3    product_ub_226  -4.1418076031795294e-02
    x_34_3    onehot_34_243  1
    x_34_3    stock_lb_246  3
    x_34_3    stock_ub_247  3
    x_34_3    parent_nonstrict_scope_248  1.4999999999999996e-02
    x_34_3    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_3    product_lb_225  1
    w_34_3    product_ub_226  1
    w_34_3    normalized_mass_34_244  1
    w_34_3    normalized_ratio_34_245  -6.0000000000000009e-01
    w_34_3    full_original_Gini_306  -9.5440476190476211e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_4    OBJ       -1.5000000000000005e-02
    x_34_4    product_lb_227  -2.4694987505487574e-02
    x_34_4    product_ub_228  -4.1418076031795294e-02
    x_34_4    onehot_34_243  1
    x_34_4    stock_lb_246  4
    x_34_4    stock_ub_247  4
    x_34_4    parent_nonstrict_scope_248  7.4999999999999980e-03
    x_34_4    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_4    product_lb_227  1
    w_34_4    product_ub_228  1
    w_34_4    normalized_mass_34_244  1
    w_34_4    normalized_ratio_34_245  -0.8
    w_34_4    full_original_Gini_306  -5.2869047619047631e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_5    OBJ       -2.2500000000000003e-02
    x_34_5    product_lb_229  -2.4694987505487574e-02
    x_34_5    product_ub_230  -4.1418076031795294e-02
    x_34_5    onehot_34_243  1
    x_34_5    stock_lb_246  5
    x_34_5    stock_ub_247  5
    x_34_5    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_5    product_lb_229  1
    w_34_5    product_ub_230  1
    w_34_5    normalized_mass_34_244  1
    w_34_5    normalized_ratio_34_245  -1
    w_34_5    full_original_Gini_306  -3.2559523809523809e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_6    OBJ       -1.4999999999999996e-02
    x_34_6    product_lb_231  -2.4694987505487574e-02
    x_34_6    product_ub_232  -4.1418076031795294e-02
    x_34_6    onehot_34_243  1
    x_34_6    stock_lb_246  6
    x_34_6    stock_ub_247  6
    x_34_6    parent_nonstrict_scope_248  7.5000000000000067e-03
    x_34_6    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_6    product_lb_231  1
    w_34_6    product_ub_232  1
    w_34_6    normalized_mass_34_244  1
    w_34_6    normalized_ratio_34_245  -1.2000000000000002e+00
    w_34_6    full_original_Gini_306  -8.2559523809523867e+00
    MARKER    'MARKER'                 'INTORG'
    x_34_7    OBJ       -7.4999999999999980e-03
    x_34_7    product_lb_233  -2.4694987505487574e-02
    x_34_7    product_ub_234  -4.1418076031795294e-02
    x_34_7    onehot_34_243  1
    x_34_7    stock_lb_246  7
    x_34_7    stock_ub_247  7
    x_34_7    parent_nonstrict_scope_248  1.5000000000000005e-02
    x_34_7    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_7    product_lb_233  1
    w_34_7    product_ub_234  1
    w_34_7    normalized_mass_34_244  1
    w_34_7    normalized_ratio_34_245  -1.4000000000000001e+00
    w_34_7    full_original_Gini_306  -1.3655952380952387e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_8    product_lb_235  -2.4694987505487574e-02
    x_34_8    product_ub_236  -4.1418076031795294e-02
    x_34_8    onehot_34_243  1
    x_34_8    stock_lb_246  8
    x_34_8    stock_ub_247  8
    x_34_8    parent_nonstrict_scope_248  2.2500000000000003e-02
    x_34_8    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_8    product_lb_235  1
    w_34_8    product_ub_236  1
    w_34_8    normalized_mass_34_244  1
    w_34_8    normalized_ratio_34_245  -1.6
    w_34_8    full_original_Gini_306  -1.9055952380952387e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_9    OBJ       7.4999999999999963e-03
    x_34_9    product_lb_237  -2.4694987505487574e-02
    x_34_9    product_ub_238  -4.1418076031795294e-02
    x_34_9    onehot_34_243  1
    x_34_9    stock_lb_246  9
    x_34_9    stock_ub_247  9
    x_34_9    parent_nonstrict_scope_248  0.03
    x_34_9    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_9    product_lb_237  1
    w_34_9    product_ub_238  1
    w_34_9    normalized_mass_34_244  1
    w_34_9    normalized_ratio_34_245  -1.8
    w_34_9    full_original_Gini_306  -2.4455952380952390e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_10   OBJ       1.4999999999999996e-02
    x_34_10   product_lb_239  -2.4694987505487574e-02
    x_34_10   product_ub_240  -4.1418076031795294e-02
    x_34_10   onehot_34_243  1
    x_34_10   stock_lb_246  10
    x_34_10   stock_ub_247  10
    x_34_10   parent_nonstrict_scope_248  0.0375
    x_34_10   unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_10   product_lb_239  1
    w_34_10   product_ub_240  1
    w_34_10   normalized_mass_34_244  1
    w_34_10   normalized_ratio_34_245  -2
    w_34_10   full_original_Gini_306  -2.9855952380952385e+01
    MARKER    'MARKER'                 'INTORG'
    x_34_11   OBJ       2.2500000000000003e-02
    x_34_11   product_lb_241  -2.4694987505487574e-02
    x_34_11   product_ub_242  -4.1418076031795294e-02
    x_34_11   onehot_34_243  1
    x_34_11   stock_lb_246  11
    x_34_11   stock_ub_247  11
    x_34_11   parent_nonstrict_scope_248  4.5000000000000005e-02
    x_34_11   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_34_11   product_lb_241  1
    w_34_11   product_ub_242  1
    w_34_11   normalized_mass_34_244  1
    w_34_11   normalized_ratio_34_245  -2.2
    w_34_11   full_original_Gini_306  -3.5255952380952380e+01
    rho_34    normalized_ratio_34_245  1
    rho_34    block_pair_pos_249  1
    rho_34    block_pair_neg_250  -1
    rho_34    block_pair_pos_263  1
    rho_34    block_pair_neg_264  -1
    rho_34    block_pair_pos_267  1
    rho_34    block_pair_neg_268  -1
    rho_34    block_pair_pos_279  1
    rho_34    block_pair_neg_280  -1
    rho_34    block_pair_pos_287  1
    rho_34    block_pair_neg_288  -1
    rho_34    block_pair_pos_297  1
    rho_34    block_pair_neg_298  -1
    rho_34    block_pair_pos_303  1
    rho_34    block_pair_neg_304  -1
    rho_34    normalization_305  1
    a_24_27   block_pair_pos_255  1
    a_24_27   block_pair_neg_256  1
    a_24_27   full_original_Gini_306  -1
    a_24_31   block_pair_pos_259  1
    a_24_31   block_pair_neg_260  1
    a_24_31   full_original_Gini_306  -1
    a_24_29   block_pair_pos_257  1
    a_24_29   block_pair_neg_258  1
    a_24_29   full_original_Gini_306  -1
    a_24_32   block_pair_pos_261  1
    a_24_32   block_pair_neg_262  1
    a_24_32   full_original_Gini_306  -1
    a_24_25   block_pair_pos_253  1
    a_24_25   block_pair_neg_254  1
    a_24_25   full_original_Gini_306  -1
    a_24_19   block_pair_pos_251  1
    a_24_19   block_pair_neg_252  1
    a_24_19   full_original_Gini_306  -1
    a_24_34   block_pair_pos_263  1
    a_24_34   block_pair_neg_264  1
    a_24_34   full_original_Gini_306  -1
    a_27_31   block_pair_pos_275  1
    a_27_31   block_pair_neg_276  1
    a_27_31   full_original_Gini_306  -1
    a_27_29   block_pair_pos_273  1
    a_27_29   block_pair_neg_274  1
    a_27_29   full_original_Gini_306  -1
    a_27_32   block_pair_pos_277  1
    a_27_32   block_pair_neg_278  1
    a_27_32   full_original_Gini_306  -1
    a_27_25   block_pair_pos_271  1
    a_27_25   block_pair_neg_272  1
    a_27_25   full_original_Gini_306  -1
    a_27_19   block_pair_pos_269  1
    a_27_19   block_pair_neg_270  1
    a_27_19   full_original_Gini_306  -1
    a_27_34   block_pair_pos_279  1
    a_27_34   block_pair_neg_280  1
    a_27_34   full_original_Gini_306  -1
    a_31_29   block_pair_pos_293  1
    a_31_29   block_pair_neg_294  1
    a_31_29   full_original_Gini_306  -1
    a_31_32   block_pair_pos_295  1
    a_31_32   block_pair_neg_296  1
    a_31_32   full_original_Gini_306  -1
    a_31_25   block_pair_pos_291  1
    a_31_25   block_pair_neg_292  1
    a_31_25   full_original_Gini_306  -1
    a_31_19   block_pair_pos_289  1
    a_31_19   block_pair_neg_290  1
    a_31_19   full_original_Gini_306  -1
    a_31_34   block_pair_pos_297  1
    a_31_34   block_pair_neg_298  1
    a_31_34   full_original_Gini_306  -1
    a_29_32   block_pair_pos_285  1
    a_29_32   block_pair_neg_286  1
    a_29_32   full_original_Gini_306  -1
    a_29_25   block_pair_pos_283  1
    a_29_25   block_pair_neg_284  1
    a_29_25   full_original_Gini_306  -1
    a_29_19   block_pair_pos_281  1
    a_29_19   block_pair_neg_282  1
    a_29_19   full_original_Gini_306  -1
    a_29_34   block_pair_pos_287  1
    a_29_34   block_pair_neg_288  1
    a_29_34   full_original_Gini_306  -1
    a_32_25   block_pair_pos_301  1
    a_32_25   block_pair_neg_302  1
    a_32_25   full_original_Gini_306  -1
    a_32_19   block_pair_pos_299  1
    a_32_19   block_pair_neg_300  1
    a_32_19   full_original_Gini_306  -1
    a_32_34   block_pair_pos_303  1
    a_32_34   block_pair_neg_304  1
    a_32_34   full_original_Gini_306  -1
    a_25_19   block_pair_pos_265  1
    a_25_19   block_pair_neg_266  1
    a_25_19   full_original_Gini_306  -1
    a_25_34   block_pair_pos_267  1
    a_25_34   block_pair_neg_268  1
    a_25_34   full_original_Gini_306  -1
    a_19_34   block_pair_pos_249  1
    a_19_34   block_pair_neg_250  1
    a_19_34   full_original_Gini_306  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_24_0  unique_nonzero_owner_307  1
    service_0_24_0  service_visit_def_733  1
    service_0_24_0  free_load_conservation_734  -11
    service_0_24_0  original_T_including_depot_unload_780  1320
    service_0_24_1  unique_nonzero_owner_308  1
    service_0_24_1  service_visit_def_733  1
    service_0_24_1  free_load_conservation_734  -10
    service_0_24_1  original_T_including_depot_unload_780  1200
    service_0_24_2  unique_nonzero_owner_309  1
    service_0_24_2  service_visit_def_733  1
    service_0_24_2  free_load_conservation_734  -9
    service_0_24_2  original_T_including_depot_unload_780  1080
    service_0_24_3  unique_nonzero_owner_310  1
    service_0_24_3  service_visit_def_733  1
    service_0_24_3  free_load_conservation_734  -8
    service_0_24_3  original_T_including_depot_unload_780  960
    service_0_24_4  unique_nonzero_owner_311  1
    service_0_24_4  service_visit_def_733  1
    service_0_24_4  free_load_conservation_734  -7
    service_0_24_4  original_T_including_depot_unload_780  840
    service_0_24_5  unique_nonzero_owner_312  1
    service_0_24_5  service_visit_def_733  1
    service_0_24_5  free_load_conservation_734  -6
    service_0_24_5  original_T_including_depot_unload_780  720
    service_0_24_6  unique_nonzero_owner_313  1
    service_0_24_6  service_visit_def_733  1
    service_0_24_6  free_load_conservation_734  -5
    service_0_24_6  original_T_including_depot_unload_780  600
    service_0_24_7  unique_nonzero_owner_314  1
    service_0_24_7  service_visit_def_733  1
    service_0_24_7  free_load_conservation_734  -4
    service_0_24_7  original_T_including_depot_unload_780  480
    service_0_24_8  unique_nonzero_owner_315  1
    service_0_24_8  service_visit_def_733  1
    service_0_24_8  free_load_conservation_734  -3
    service_0_24_8  original_T_including_depot_unload_780  360
    service_0_24_9  unique_nonzero_owner_316  1
    service_0_24_9  service_visit_def_733  1
    service_0_24_9  free_load_conservation_734  -2
    service_0_24_9  original_T_including_depot_unload_780  240
    service_0_24_10  unique_nonzero_owner_317  1
    service_0_24_10  service_visit_def_733  1
    service_0_24_10  free_load_conservation_734  -1
    service_0_24_10  original_T_including_depot_unload_780  120
    service_0_24_12  unique_nonzero_owner_318  1
    service_0_24_12  service_visit_def_733  1
    service_0_24_12  free_load_conservation_734  1
    service_0_24_13  unique_nonzero_owner_319  1
    service_0_24_13  service_visit_def_733  1
    service_0_24_13  free_load_conservation_734  2
    service_0_24_14  unique_nonzero_owner_320  1
    service_0_24_14  service_visit_def_733  1
    service_0_24_14  free_load_conservation_734  3
    service_0_24_15  unique_nonzero_owner_321  1
    service_0_24_15  service_visit_def_733  1
    service_0_24_15  free_load_conservation_734  4
    service_1_24_0  unique_nonzero_owner_307  1
    service_1_24_0  service_visit_def_1104  1
    service_1_24_0  free_load_conservation_1105  -11
    service_1_24_0  original_T_including_depot_unload_1151  1320
    service_1_24_1  unique_nonzero_owner_308  1
    service_1_24_1  service_visit_def_1104  1
    service_1_24_1  free_load_conservation_1105  -10
    service_1_24_1  original_T_including_depot_unload_1151  1200
    service_1_24_2  unique_nonzero_owner_309  1
    service_1_24_2  service_visit_def_1104  1
    service_1_24_2  free_load_conservation_1105  -9
    service_1_24_2  original_T_including_depot_unload_1151  1080
    service_1_24_3  unique_nonzero_owner_310  1
    service_1_24_3  service_visit_def_1104  1
    service_1_24_3  free_load_conservation_1105  -8
    service_1_24_3  original_T_including_depot_unload_1151  960
    service_1_24_4  unique_nonzero_owner_311  1
    service_1_24_4  service_visit_def_1104  1
    service_1_24_4  free_load_conservation_1105  -7
    service_1_24_4  original_T_including_depot_unload_1151  840
    service_1_24_5  unique_nonzero_owner_312  1
    service_1_24_5  service_visit_def_1104  1
    service_1_24_5  free_load_conservation_1105  -6
    service_1_24_5  original_T_including_depot_unload_1151  720
    service_1_24_6  unique_nonzero_owner_313  1
    service_1_24_6  service_visit_def_1104  1
    service_1_24_6  free_load_conservation_1105  -5
    service_1_24_6  original_T_including_depot_unload_1151  600
    service_1_24_7  unique_nonzero_owner_314  1
    service_1_24_7  service_visit_def_1104  1
    service_1_24_7  free_load_conservation_1105  -4
    service_1_24_7  original_T_including_depot_unload_1151  480
    service_1_24_8  unique_nonzero_owner_315  1
    service_1_24_8  service_visit_def_1104  1
    service_1_24_8  free_load_conservation_1105  -3
    service_1_24_8  original_T_including_depot_unload_1151  360
    service_1_24_9  unique_nonzero_owner_316  1
    service_1_24_9  service_visit_def_1104  1
    service_1_24_9  free_load_conservation_1105  -2
    service_1_24_9  original_T_including_depot_unload_1151  240
    service_1_24_10  unique_nonzero_owner_317  1
    service_1_24_10  service_visit_def_1104  1
    service_1_24_10  free_load_conservation_1105  -1
    service_1_24_10  original_T_including_depot_unload_1151  120
    service_1_24_12  unique_nonzero_owner_318  1
    service_1_24_12  service_visit_def_1104  1
    service_1_24_12  free_load_conservation_1105  1
    service_1_24_13  unique_nonzero_owner_319  1
    service_1_24_13  service_visit_def_1104  1
    service_1_24_13  free_load_conservation_1105  2
    service_1_24_14  unique_nonzero_owner_320  1
    service_1_24_14  service_visit_def_1104  1
    service_1_24_14  free_load_conservation_1105  3
    service_1_24_15  unique_nonzero_owner_321  1
    service_1_24_15  service_visit_def_1104  1
    service_1_24_15  free_load_conservation_1105  4
    service_2_24_0  unique_nonzero_owner_307  1
    service_2_24_0  service_visit_def_1422  1
    service_2_24_0  free_load_conservation_1423  -11
    service_2_24_0  original_T_including_depot_unload_1468  1320
    service_2_24_1  unique_nonzero_owner_308  1
    service_2_24_1  service_visit_def_1422  1
    service_2_24_1  free_load_conservation_1423  -10
    service_2_24_1  original_T_including_depot_unload_1468  1200
    service_2_24_2  unique_nonzero_owner_309  1
    service_2_24_2  service_visit_def_1422  1
    service_2_24_2  free_load_conservation_1423  -9
    service_2_24_2  original_T_including_depot_unload_1468  1080
    service_2_24_3  unique_nonzero_owner_310  1
    service_2_24_3  service_visit_def_1422  1
    service_2_24_3  free_load_conservation_1423  -8
    service_2_24_3  original_T_including_depot_unload_1468  960
    service_2_24_4  unique_nonzero_owner_311  1
    service_2_24_4  service_visit_def_1422  1
    service_2_24_4  free_load_conservation_1423  -7
    service_2_24_4  original_T_including_depot_unload_1468  840
    service_2_24_5  unique_nonzero_owner_312  1
    service_2_24_5  service_visit_def_1422  1
    service_2_24_5  free_load_conservation_1423  -6
    service_2_24_5  original_T_including_depot_unload_1468  720
    service_2_24_6  unique_nonzero_owner_313  1
    service_2_24_6  service_visit_def_1422  1
    service_2_24_6  free_load_conservation_1423  -5
    service_2_24_6  original_T_including_depot_unload_1468  600
    service_2_24_7  unique_nonzero_owner_314  1
    service_2_24_7  service_visit_def_1422  1
    service_2_24_7  free_load_conservation_1423  -4
    service_2_24_7  original_T_including_depot_unload_1468  480
    service_2_24_8  unique_nonzero_owner_315  1
    service_2_24_8  service_visit_def_1422  1
    service_2_24_8  free_load_conservation_1423  -3
    service_2_24_8  original_T_including_depot_unload_1468  360
    service_2_24_9  unique_nonzero_owner_316  1
    service_2_24_9  service_visit_def_1422  1
    service_2_24_9  free_load_conservation_1423  -2
    service_2_24_9  original_T_including_depot_unload_1468  240
    service_2_24_10  unique_nonzero_owner_317  1
    service_2_24_10  service_visit_def_1422  1
    service_2_24_10  free_load_conservation_1423  -1
    service_2_24_10  original_T_including_depot_unload_1468  120
    service_2_24_12  unique_nonzero_owner_318  1
    service_2_24_12  service_visit_def_1422  1
    service_2_24_12  free_load_conservation_1423  1
    service_2_24_13  unique_nonzero_owner_319  1
    service_2_24_13  service_visit_def_1422  1
    service_2_24_13  free_load_conservation_1423  2
    service_2_24_14  unique_nonzero_owner_320  1
    service_2_24_14  service_visit_def_1422  1
    service_2_24_14  free_load_conservation_1423  3
    service_2_24_15  unique_nonzero_owner_321  1
    service_2_24_15  service_visit_def_1422  1
    service_2_24_15  free_load_conservation_1423  4
    service_0_27_0  unique_nonzero_owner_322  1
    service_0_27_0  service_visit_def_739  1
    service_0_27_0  free_load_conservation_740  -11
    service_0_27_0  original_T_including_depot_unload_780  1320
    service_0_27_1  unique_nonzero_owner_323  1
    service_0_27_1  service_visit_def_739  1
    service_0_27_1  free_load_conservation_740  -10
    service_0_27_1  original_T_including_depot_unload_780  1200
    service_0_27_2  unique_nonzero_owner_324  1
    service_0_27_2  service_visit_def_739  1
    service_0_27_2  free_load_conservation_740  -9
    service_0_27_2  original_T_including_depot_unload_780  1080
    service_0_27_3  unique_nonzero_owner_325  1
    service_0_27_3  service_visit_def_739  1
    service_0_27_3  free_load_conservation_740  -8
    service_0_27_3  original_T_including_depot_unload_780  960
    service_0_27_4  unique_nonzero_owner_326  1
    service_0_27_4  service_visit_def_739  1
    service_0_27_4  free_load_conservation_740  -7
    service_0_27_4  original_T_including_depot_unload_780  840
    service_0_27_5  unique_nonzero_owner_327  1
    service_0_27_5  service_visit_def_739  1
    service_0_27_5  free_load_conservation_740  -6
    service_0_27_5  original_T_including_depot_unload_780  720
    service_0_27_6  unique_nonzero_owner_328  1
    service_0_27_6  service_visit_def_739  1
    service_0_27_6  free_load_conservation_740  -5
    service_0_27_6  original_T_including_depot_unload_780  600
    service_0_27_7  unique_nonzero_owner_329  1
    service_0_27_7  service_visit_def_739  1
    service_0_27_7  free_load_conservation_740  -4
    service_0_27_7  original_T_including_depot_unload_780  480
    service_0_27_8  unique_nonzero_owner_330  1
    service_0_27_8  service_visit_def_739  1
    service_0_27_8  free_load_conservation_740  -3
    service_0_27_8  original_T_including_depot_unload_780  360
    service_0_27_9  unique_nonzero_owner_331  1
    service_0_27_9  service_visit_def_739  1
    service_0_27_9  free_load_conservation_740  -2
    service_0_27_9  original_T_including_depot_unload_780  240
    service_0_27_10  unique_nonzero_owner_332  1
    service_0_27_10  service_visit_def_739  1
    service_0_27_10  free_load_conservation_740  -1
    service_0_27_10  original_T_including_depot_unload_780  120
    service_0_27_12  unique_nonzero_owner_333  1
    service_0_27_12  service_visit_def_739  1
    service_0_27_12  free_load_conservation_740  1
    service_0_27_13  unique_nonzero_owner_334  1
    service_0_27_13  service_visit_def_739  1
    service_0_27_13  free_load_conservation_740  2
    service_0_27_14  unique_nonzero_owner_335  1
    service_0_27_14  service_visit_def_739  1
    service_0_27_14  free_load_conservation_740  3
    service_0_27_15  unique_nonzero_owner_336  1
    service_0_27_15  service_visit_def_739  1
    service_0_27_15  free_load_conservation_740  4
    service_1_27_0  unique_nonzero_owner_322  1
    service_1_27_0  service_visit_def_1110  1
    service_1_27_0  free_load_conservation_1111  -11
    service_1_27_0  original_T_including_depot_unload_1151  1320
    service_1_27_1  unique_nonzero_owner_323  1
    service_1_27_1  service_visit_def_1110  1
    service_1_27_1  free_load_conservation_1111  -10
    service_1_27_1  original_T_including_depot_unload_1151  1200
    service_1_27_2  unique_nonzero_owner_324  1
    service_1_27_2  service_visit_def_1110  1
    service_1_27_2  free_load_conservation_1111  -9
    service_1_27_2  original_T_including_depot_unload_1151  1080
    service_1_27_3  unique_nonzero_owner_325  1
    service_1_27_3  service_visit_def_1110  1
    service_1_27_3  free_load_conservation_1111  -8
    service_1_27_3  original_T_including_depot_unload_1151  960
    service_1_27_4  unique_nonzero_owner_326  1
    service_1_27_4  service_visit_def_1110  1
    service_1_27_4  free_load_conservation_1111  -7
    service_1_27_4  original_T_including_depot_unload_1151  840
    service_1_27_5  unique_nonzero_owner_327  1
    service_1_27_5  service_visit_def_1110  1
    service_1_27_5  free_load_conservation_1111  -6
    service_1_27_5  original_T_including_depot_unload_1151  720
    service_1_27_6  unique_nonzero_owner_328  1
    service_1_27_6  service_visit_def_1110  1
    service_1_27_6  free_load_conservation_1111  -5
    service_1_27_6  original_T_including_depot_unload_1151  600
    service_1_27_7  unique_nonzero_owner_329  1
    service_1_27_7  service_visit_def_1110  1
    service_1_27_7  free_load_conservation_1111  -4
    service_1_27_7  original_T_including_depot_unload_1151  480
    service_1_27_8  unique_nonzero_owner_330  1
    service_1_27_8  service_visit_def_1110  1
    service_1_27_8  free_load_conservation_1111  -3
    service_1_27_8  original_T_including_depot_unload_1151  360
    service_1_27_9  unique_nonzero_owner_331  1
    service_1_27_9  service_visit_def_1110  1
    service_1_27_9  free_load_conservation_1111  -2
    service_1_27_9  original_T_including_depot_unload_1151  240
    service_1_27_10  unique_nonzero_owner_332  1
    service_1_27_10  service_visit_def_1110  1
    service_1_27_10  free_load_conservation_1111  -1
    service_1_27_10  original_T_including_depot_unload_1151  120
    service_1_27_12  unique_nonzero_owner_333  1
    service_1_27_12  service_visit_def_1110  1
    service_1_27_12  free_load_conservation_1111  1
    service_1_27_13  unique_nonzero_owner_334  1
    service_1_27_13  service_visit_def_1110  1
    service_1_27_13  free_load_conservation_1111  2
    service_1_27_14  unique_nonzero_owner_335  1
    service_1_27_14  service_visit_def_1110  1
    service_1_27_14  free_load_conservation_1111  3
    service_1_27_15  unique_nonzero_owner_336  1
    service_1_27_15  service_visit_def_1110  1
    service_1_27_15  free_load_conservation_1111  4
    service_2_27_0  unique_nonzero_owner_322  1
    service_2_27_0  service_visit_def_1428  1
    service_2_27_0  free_load_conservation_1429  -11
    service_2_27_0  original_T_including_depot_unload_1468  1320
    service_2_27_1  unique_nonzero_owner_323  1
    service_2_27_1  service_visit_def_1428  1
    service_2_27_1  free_load_conservation_1429  -10
    service_2_27_1  original_T_including_depot_unload_1468  1200
    service_2_27_2  unique_nonzero_owner_324  1
    service_2_27_2  service_visit_def_1428  1
    service_2_27_2  free_load_conservation_1429  -9
    service_2_27_2  original_T_including_depot_unload_1468  1080
    service_2_27_3  unique_nonzero_owner_325  1
    service_2_27_3  service_visit_def_1428  1
    service_2_27_3  free_load_conservation_1429  -8
    service_2_27_3  original_T_including_depot_unload_1468  960
    service_2_27_4  unique_nonzero_owner_326  1
    service_2_27_4  service_visit_def_1428  1
    service_2_27_4  free_load_conservation_1429  -7
    service_2_27_4  original_T_including_depot_unload_1468  840
    service_2_27_5  unique_nonzero_owner_327  1
    service_2_27_5  service_visit_def_1428  1
    service_2_27_5  free_load_conservation_1429  -6
    service_2_27_5  original_T_including_depot_unload_1468  720
    service_2_27_6  unique_nonzero_owner_328  1
    service_2_27_6  service_visit_def_1428  1
    service_2_27_6  free_load_conservation_1429  -5
    service_2_27_6  original_T_including_depot_unload_1468  600
    service_2_27_7  unique_nonzero_owner_329  1
    service_2_27_7  service_visit_def_1428  1
    service_2_27_7  free_load_conservation_1429  -4
    service_2_27_7  original_T_including_depot_unload_1468  480
    service_2_27_8  unique_nonzero_owner_330  1
    service_2_27_8  service_visit_def_1428  1
    service_2_27_8  free_load_conservation_1429  -3
    service_2_27_8  original_T_including_depot_unload_1468  360
    service_2_27_9  unique_nonzero_owner_331  1
    service_2_27_9  service_visit_def_1428  1
    service_2_27_9  free_load_conservation_1429  -2
    service_2_27_9  original_T_including_depot_unload_1468  240
    service_2_27_10  unique_nonzero_owner_332  1
    service_2_27_10  service_visit_def_1428  1
    service_2_27_10  free_load_conservation_1429  -1
    service_2_27_10  original_T_including_depot_unload_1468  120
    service_2_27_12  unique_nonzero_owner_333  1
    service_2_27_12  service_visit_def_1428  1
    service_2_27_12  free_load_conservation_1429  1
    service_2_27_13  unique_nonzero_owner_334  1
    service_2_27_13  service_visit_def_1428  1
    service_2_27_13  free_load_conservation_1429  2
    service_2_27_14  unique_nonzero_owner_335  1
    service_2_27_14  service_visit_def_1428  1
    service_2_27_14  free_load_conservation_1429  3
    service_2_27_15  unique_nonzero_owner_336  1
    service_2_27_15  service_visit_def_1428  1
    service_2_27_15  free_load_conservation_1429  4
    service_0_31_0  unique_nonzero_owner_337  1
    service_0_31_0  service_visit_def_745  1
    service_0_31_0  free_load_conservation_746  -2
    service_0_31_0  original_T_including_depot_unload_780  240
    service_0_31_1  unique_nonzero_owner_338  1
    service_0_31_1  service_visit_def_745  1
    service_0_31_1  free_load_conservation_746  -1
    service_0_31_1  original_T_including_depot_unload_780  120
    service_0_31_3  unique_nonzero_owner_339  1
    service_0_31_3  service_visit_def_745  1
    service_0_31_3  free_load_conservation_746  1
    service_0_31_4  unique_nonzero_owner_340  1
    service_0_31_4  service_visit_def_745  1
    service_0_31_4  free_load_conservation_746  2
    service_0_31_5  unique_nonzero_owner_341  1
    service_0_31_5  service_visit_def_745  1
    service_0_31_5  free_load_conservation_746  3
    service_0_31_6  unique_nonzero_owner_342  1
    service_0_31_6  service_visit_def_745  1
    service_0_31_6  free_load_conservation_746  4
    service_0_31_7  unique_nonzero_owner_343  1
    service_0_31_7  service_visit_def_745  1
    service_0_31_7  free_load_conservation_746  5
    service_0_31_8  unique_nonzero_owner_344  1
    service_0_31_8  service_visit_def_745  1
    service_0_31_8  free_load_conservation_746  6
    service_0_31_9  unique_nonzero_owner_345  1
    service_0_31_9  service_visit_def_745  1
    service_0_31_9  free_load_conservation_746  7
    service_0_31_10  unique_nonzero_owner_346  1
    service_0_31_10  service_visit_def_745  1
    service_0_31_10  free_load_conservation_746  8
    service_0_31_11  unique_nonzero_owner_347  1
    service_0_31_11  service_visit_def_745  1
    service_0_31_11  free_load_conservation_746  9
    service_0_31_12  unique_nonzero_owner_348  1
    service_0_31_12  service_visit_def_745  1
    service_0_31_12  free_load_conservation_746  10
    service_1_31_0  unique_nonzero_owner_337  1
    service_1_31_0  service_visit_def_1116  1
    service_1_31_0  free_load_conservation_1117  -2
    service_1_31_0  original_T_including_depot_unload_1151  240
    service_1_31_1  unique_nonzero_owner_338  1
    service_1_31_1  service_visit_def_1116  1
    service_1_31_1  free_load_conservation_1117  -1
    service_1_31_1  original_T_including_depot_unload_1151  120
    service_1_31_3  unique_nonzero_owner_339  1
    service_1_31_3  service_visit_def_1116  1
    service_1_31_3  free_load_conservation_1117  1
    service_1_31_4  unique_nonzero_owner_340  1
    service_1_31_4  service_visit_def_1116  1
    service_1_31_4  free_load_conservation_1117  2
    service_1_31_5  unique_nonzero_owner_341  1
    service_1_31_5  service_visit_def_1116  1
    service_1_31_5  free_load_conservation_1117  3
    service_1_31_6  unique_nonzero_owner_342  1
    service_1_31_6  service_visit_def_1116  1
    service_1_31_6  free_load_conservation_1117  4
    service_1_31_7  unique_nonzero_owner_343  1
    service_1_31_7  service_visit_def_1116  1
    service_1_31_7  free_load_conservation_1117  5
    service_1_31_8  unique_nonzero_owner_344  1
    service_1_31_8  service_visit_def_1116  1
    service_1_31_8  free_load_conservation_1117  6
    service_1_31_9  unique_nonzero_owner_345  1
    service_1_31_9  service_visit_def_1116  1
    service_1_31_9  free_load_conservation_1117  7
    service_1_31_10  unique_nonzero_owner_346  1
    service_1_31_10  service_visit_def_1116  1
    service_1_31_10  free_load_conservation_1117  8
    service_1_31_11  unique_nonzero_owner_347  1
    service_1_31_11  service_visit_def_1116  1
    service_1_31_11  free_load_conservation_1117  9
    service_1_31_12  unique_nonzero_owner_348  1
    service_1_31_12  service_visit_def_1116  1
    service_1_31_12  free_load_conservation_1117  10
    service_2_31_0  unique_nonzero_owner_337  1
    service_2_31_0  service_visit_def_1434  1
    service_2_31_0  free_load_conservation_1435  -2
    service_2_31_0  original_T_including_depot_unload_1468  240
    service_2_31_1  unique_nonzero_owner_338  1
    service_2_31_1  service_visit_def_1434  1
    service_2_31_1  free_load_conservation_1435  -1
    service_2_31_1  original_T_including_depot_unload_1468  120
    service_2_31_3  unique_nonzero_owner_339  1
    service_2_31_3  service_visit_def_1434  1
    service_2_31_3  free_load_conservation_1435  1
    service_2_31_4  unique_nonzero_owner_340  1
    service_2_31_4  service_visit_def_1434  1
    service_2_31_4  free_load_conservation_1435  2
    service_2_31_5  unique_nonzero_owner_341  1
    service_2_31_5  service_visit_def_1434  1
    service_2_31_5  free_load_conservation_1435  3
    service_2_31_6  unique_nonzero_owner_342  1
    service_2_31_6  service_visit_def_1434  1
    service_2_31_6  free_load_conservation_1435  4
    service_2_31_7  unique_nonzero_owner_343  1
    service_2_31_7  service_visit_def_1434  1
    service_2_31_7  free_load_conservation_1435  5
    service_2_31_8  unique_nonzero_owner_344  1
    service_2_31_8  service_visit_def_1434  1
    service_2_31_8  free_load_conservation_1435  6
    service_2_31_9  unique_nonzero_owner_345  1
    service_2_31_9  service_visit_def_1434  1
    service_2_31_9  free_load_conservation_1435  7
    service_2_31_10  unique_nonzero_owner_346  1
    service_2_31_10  service_visit_def_1434  1
    service_2_31_10  free_load_conservation_1435  8
    service_2_31_11  unique_nonzero_owner_347  1
    service_2_31_11  service_visit_def_1434  1
    service_2_31_11  free_load_conservation_1435  9
    service_2_31_12  unique_nonzero_owner_348  1
    service_2_31_12  service_visit_def_1434  1
    service_2_31_12  free_load_conservation_1435  10
    service_0_29_0  unique_nonzero_owner_349  1
    service_0_29_0  service_visit_def_751  1
    service_0_29_0  free_load_conservation_752  -11
    service_0_29_0  original_T_including_depot_unload_780  1320
    service_0_29_1  unique_nonzero_owner_350  1
    service_0_29_1  service_visit_def_751  1
    service_0_29_1  free_load_conservation_752  -10
    service_0_29_1  original_T_including_depot_unload_780  1200
    service_0_29_2  unique_nonzero_owner_351  1
    service_0_29_2  service_visit_def_751  1
    service_0_29_2  free_load_conservation_752  -9
    service_0_29_2  original_T_including_depot_unload_780  1080
    service_0_29_3  unique_nonzero_owner_352  1
    service_0_29_3  service_visit_def_751  1
    service_0_29_3  free_load_conservation_752  -8
    service_0_29_3  original_T_including_depot_unload_780  960
    service_0_29_4  unique_nonzero_owner_353  1
    service_0_29_4  service_visit_def_751  1
    service_0_29_4  free_load_conservation_752  -7
    service_0_29_4  original_T_including_depot_unload_780  840
    service_0_29_5  unique_nonzero_owner_354  1
    service_0_29_5  service_visit_def_751  1
    service_0_29_5  free_load_conservation_752  -6
    service_0_29_5  original_T_including_depot_unload_780  720
    service_0_29_6  unique_nonzero_owner_355  1
    service_0_29_6  service_visit_def_751  1
    service_0_29_6  free_load_conservation_752  -5
    service_0_29_6  original_T_including_depot_unload_780  600
    service_0_29_7  unique_nonzero_owner_356  1
    service_0_29_7  service_visit_def_751  1
    service_0_29_7  free_load_conservation_752  -4
    service_0_29_7  original_T_including_depot_unload_780  480
    service_0_29_8  unique_nonzero_owner_357  1
    service_0_29_8  service_visit_def_751  1
    service_0_29_8  free_load_conservation_752  -3
    service_0_29_8  original_T_including_depot_unload_780  360
    service_0_29_9  unique_nonzero_owner_358  1
    service_0_29_9  service_visit_def_751  1
    service_0_29_9  free_load_conservation_752  -2
    service_0_29_9  original_T_including_depot_unload_780  240
    service_0_29_10  unique_nonzero_owner_359  1
    service_0_29_10  service_visit_def_751  1
    service_0_29_10  free_load_conservation_752  -1
    service_0_29_10  original_T_including_depot_unload_780  120
    service_0_29_12  unique_nonzero_owner_360  1
    service_0_29_12  service_visit_def_751  1
    service_0_29_12  free_load_conservation_752  1
    service_0_29_13  unique_nonzero_owner_361  1
    service_0_29_13  service_visit_def_751  1
    service_0_29_13  free_load_conservation_752  2
    service_0_29_14  unique_nonzero_owner_362  1
    service_0_29_14  service_visit_def_751  1
    service_0_29_14  free_load_conservation_752  3
    service_0_29_15  unique_nonzero_owner_363  1
    service_0_29_15  service_visit_def_751  1
    service_0_29_15  free_load_conservation_752  4
    service_1_29_0  unique_nonzero_owner_349  1
    service_1_29_0  service_visit_def_1122  1
    service_1_29_0  free_load_conservation_1123  -11
    service_1_29_0  original_T_including_depot_unload_1151  1320
    service_1_29_1  unique_nonzero_owner_350  1
    service_1_29_1  service_visit_def_1122  1
    service_1_29_1  free_load_conservation_1123  -10
    service_1_29_1  original_T_including_depot_unload_1151  1200
    service_1_29_2  unique_nonzero_owner_351  1
    service_1_29_2  service_visit_def_1122  1
    service_1_29_2  free_load_conservation_1123  -9
    service_1_29_2  original_T_including_depot_unload_1151  1080
    service_1_29_3  unique_nonzero_owner_352  1
    service_1_29_3  service_visit_def_1122  1
    service_1_29_3  free_load_conservation_1123  -8
    service_1_29_3  original_T_including_depot_unload_1151  960
    service_1_29_4  unique_nonzero_owner_353  1
    service_1_29_4  service_visit_def_1122  1
    service_1_29_4  free_load_conservation_1123  -7
    service_1_29_4  original_T_including_depot_unload_1151  840
    service_1_29_5  unique_nonzero_owner_354  1
    service_1_29_5  service_visit_def_1122  1
    service_1_29_5  free_load_conservation_1123  -6
    service_1_29_5  original_T_including_depot_unload_1151  720
    service_1_29_6  unique_nonzero_owner_355  1
    service_1_29_6  service_visit_def_1122  1
    service_1_29_6  free_load_conservation_1123  -5
    service_1_29_6  original_T_including_depot_unload_1151  600
    service_1_29_7  unique_nonzero_owner_356  1
    service_1_29_7  service_visit_def_1122  1
    service_1_29_7  free_load_conservation_1123  -4
    service_1_29_7  original_T_including_depot_unload_1151  480
    service_1_29_8  unique_nonzero_owner_357  1
    service_1_29_8  service_visit_def_1122  1
    service_1_29_8  free_load_conservation_1123  -3
    service_1_29_8  original_T_including_depot_unload_1151  360
    service_1_29_9  unique_nonzero_owner_358  1
    service_1_29_9  service_visit_def_1122  1
    service_1_29_9  free_load_conservation_1123  -2
    service_1_29_9  original_T_including_depot_unload_1151  240
    service_1_29_10  unique_nonzero_owner_359  1
    service_1_29_10  service_visit_def_1122  1
    service_1_29_10  free_load_conservation_1123  -1
    service_1_29_10  original_T_including_depot_unload_1151  120
    service_1_29_12  unique_nonzero_owner_360  1
    service_1_29_12  service_visit_def_1122  1
    service_1_29_12  free_load_conservation_1123  1
    service_1_29_13  unique_nonzero_owner_361  1
    service_1_29_13  service_visit_def_1122  1
    service_1_29_13  free_load_conservation_1123  2
    service_1_29_14  unique_nonzero_owner_362  1
    service_1_29_14  service_visit_def_1122  1
    service_1_29_14  free_load_conservation_1123  3
    service_1_29_15  unique_nonzero_owner_363  1
    service_1_29_15  service_visit_def_1122  1
    service_1_29_15  free_load_conservation_1123  4
    service_2_29_0  unique_nonzero_owner_349  1
    service_2_29_0  service_visit_def_1440  1
    service_2_29_0  free_load_conservation_1441  -11
    service_2_29_0  original_T_including_depot_unload_1468  1320
    service_2_29_1  unique_nonzero_owner_350  1
    service_2_29_1  service_visit_def_1440  1
    service_2_29_1  free_load_conservation_1441  -10
    service_2_29_1  original_T_including_depot_unload_1468  1200
    service_2_29_2  unique_nonzero_owner_351  1
    service_2_29_2  service_visit_def_1440  1
    service_2_29_2  free_load_conservation_1441  -9
    service_2_29_2  original_T_including_depot_unload_1468  1080
    service_2_29_3  unique_nonzero_owner_352  1
    service_2_29_3  service_visit_def_1440  1
    service_2_29_3  free_load_conservation_1441  -8
    service_2_29_3  original_T_including_depot_unload_1468  960
    service_2_29_4  unique_nonzero_owner_353  1
    service_2_29_4  service_visit_def_1440  1
    service_2_29_4  free_load_conservation_1441  -7
    service_2_29_4  original_T_including_depot_unload_1468  840
    service_2_29_5  unique_nonzero_owner_354  1
    service_2_29_5  service_visit_def_1440  1
    service_2_29_5  free_load_conservation_1441  -6
    service_2_29_5  original_T_including_depot_unload_1468  720
    service_2_29_6  unique_nonzero_owner_355  1
    service_2_29_6  service_visit_def_1440  1
    service_2_29_6  free_load_conservation_1441  -5
    service_2_29_6  original_T_including_depot_unload_1468  600
    service_2_29_7  unique_nonzero_owner_356  1
    service_2_29_7  service_visit_def_1440  1
    service_2_29_7  free_load_conservation_1441  -4
    service_2_29_7  original_T_including_depot_unload_1468  480
    service_2_29_8  unique_nonzero_owner_357  1
    service_2_29_8  service_visit_def_1440  1
    service_2_29_8  free_load_conservation_1441  -3
    service_2_29_8  original_T_including_depot_unload_1468  360
    service_2_29_9  unique_nonzero_owner_358  1
    service_2_29_9  service_visit_def_1440  1
    service_2_29_9  free_load_conservation_1441  -2
    service_2_29_9  original_T_including_depot_unload_1468  240
    service_2_29_10  unique_nonzero_owner_359  1
    service_2_29_10  service_visit_def_1440  1
    service_2_29_10  free_load_conservation_1441  -1
    service_2_29_10  original_T_including_depot_unload_1468  120
    service_2_29_12  unique_nonzero_owner_360  1
    service_2_29_12  service_visit_def_1440  1
    service_2_29_12  free_load_conservation_1441  1
    service_2_29_13  unique_nonzero_owner_361  1
    service_2_29_13  service_visit_def_1440  1
    service_2_29_13  free_load_conservation_1441  2
    service_2_29_14  unique_nonzero_owner_362  1
    service_2_29_14  service_visit_def_1440  1
    service_2_29_14  free_load_conservation_1441  3
    service_2_29_15  unique_nonzero_owner_363  1
    service_2_29_15  service_visit_def_1440  1
    service_2_29_15  free_load_conservation_1441  4
    service_0_32_1  unique_nonzero_owner_364  1
    service_0_32_1  service_visit_def_757  1
    service_0_32_1  free_load_conservation_758  1
    service_0_32_2  unique_nonzero_owner_365  1
    service_0_32_2  service_visit_def_757  1
    service_0_32_2  free_load_conservation_758  2
    service_0_32_3  unique_nonzero_owner_366  1
    service_0_32_3  service_visit_def_757  1
    service_0_32_3  free_load_conservation_758  3
    service_0_32_4  unique_nonzero_owner_367  1
    service_0_32_4  service_visit_def_757  1
    service_0_32_4  free_load_conservation_758  4
    service_0_32_5  unique_nonzero_owner_368  1
    service_0_32_5  service_visit_def_757  1
    service_0_32_5  free_load_conservation_758  5
    service_0_32_6  unique_nonzero_owner_369  1
    service_0_32_6  service_visit_def_757  1
    service_0_32_6  free_load_conservation_758  6
    service_0_32_7  unique_nonzero_owner_370  1
    service_0_32_7  service_visit_def_757  1
    service_0_32_7  free_load_conservation_758  7
    service_0_32_8  unique_nonzero_owner_371  1
    service_0_32_8  service_visit_def_757  1
    service_0_32_8  free_load_conservation_758  8
    service_0_32_9  unique_nonzero_owner_372  1
    service_0_32_9  service_visit_def_757  1
    service_0_32_9  free_load_conservation_758  9
    service_0_32_10  unique_nonzero_owner_373  1
    service_0_32_10  service_visit_def_757  1
    service_0_32_10  free_load_conservation_758  10
    service_0_32_11  unique_nonzero_owner_374  1
    service_0_32_11  service_visit_def_757  1
    service_0_32_11  free_load_conservation_758  11
    service_0_32_12  unique_nonzero_owner_375  1
    service_0_32_12  service_visit_def_757  1
    service_0_32_12  free_load_conservation_758  12
    service_1_32_1  unique_nonzero_owner_364  1
    service_1_32_1  service_visit_def_1128  1
    service_1_32_1  free_load_conservation_1129  1
    service_1_32_2  unique_nonzero_owner_365  1
    service_1_32_2  service_visit_def_1128  1
    service_1_32_2  free_load_conservation_1129  2
    service_1_32_3  unique_nonzero_owner_366  1
    service_1_32_3  service_visit_def_1128  1
    service_1_32_3  free_load_conservation_1129  3
    service_1_32_4  unique_nonzero_owner_367  1
    service_1_32_4  service_visit_def_1128  1
    service_1_32_4  free_load_conservation_1129  4
    service_1_32_5  unique_nonzero_owner_368  1
    service_1_32_5  service_visit_def_1128  1
    service_1_32_5  free_load_conservation_1129  5
    service_1_32_6  unique_nonzero_owner_369  1
    service_1_32_6  service_visit_def_1128  1
    service_1_32_6  free_load_conservation_1129  6
    service_1_32_7  unique_nonzero_owner_370  1
    service_1_32_7  service_visit_def_1128  1
    service_1_32_7  free_load_conservation_1129  7
    service_1_32_8  unique_nonzero_owner_371  1
    service_1_32_8  service_visit_def_1128  1
    service_1_32_8  free_load_conservation_1129  8
    service_1_32_9  unique_nonzero_owner_372  1
    service_1_32_9  service_visit_def_1128  1
    service_1_32_9  free_load_conservation_1129  9
    service_1_32_10  unique_nonzero_owner_373  1
    service_1_32_10  service_visit_def_1128  1
    service_1_32_10  free_load_conservation_1129  10
    service_1_32_11  unique_nonzero_owner_374  1
    service_1_32_11  service_visit_def_1128  1
    service_1_32_11  free_load_conservation_1129  11
    service_1_32_12  unique_nonzero_owner_375  1
    service_1_32_12  service_visit_def_1128  1
    service_1_32_12  free_load_conservation_1129  12
    service_2_32_1  unique_nonzero_owner_364  1
    service_2_32_1  service_visit_def_1446  1
    service_2_32_1  free_load_conservation_1447  1
    service_2_32_2  unique_nonzero_owner_365  1
    service_2_32_2  service_visit_def_1446  1
    service_2_32_2  free_load_conservation_1447  2
    service_2_32_3  unique_nonzero_owner_366  1
    service_2_32_3  service_visit_def_1446  1
    service_2_32_3  free_load_conservation_1447  3
    service_2_32_4  unique_nonzero_owner_367  1
    service_2_32_4  service_visit_def_1446  1
    service_2_32_4  free_load_conservation_1447  4
    service_2_32_5  unique_nonzero_owner_368  1
    service_2_32_5  service_visit_def_1446  1
    service_2_32_5  free_load_conservation_1447  5
    service_2_32_6  unique_nonzero_owner_369  1
    service_2_32_6  service_visit_def_1446  1
    service_2_32_6  free_load_conservation_1447  6
    service_2_32_7  unique_nonzero_owner_370  1
    service_2_32_7  service_visit_def_1446  1
    service_2_32_7  free_load_conservation_1447  7
    service_2_32_8  unique_nonzero_owner_371  1
    service_2_32_8  service_visit_def_1446  1
    service_2_32_8  free_load_conservation_1447  8
    service_2_32_9  unique_nonzero_owner_372  1
    service_2_32_9  service_visit_def_1446  1
    service_2_32_9  free_load_conservation_1447  9
    service_2_32_10  unique_nonzero_owner_373  1
    service_2_32_10  service_visit_def_1446  1
    service_2_32_10  free_load_conservation_1447  10
    service_2_32_11  unique_nonzero_owner_374  1
    service_2_32_11  service_visit_def_1446  1
    service_2_32_11  free_load_conservation_1447  11
    service_2_32_12  unique_nonzero_owner_375  1
    service_2_32_12  service_visit_def_1446  1
    service_2_32_12  free_load_conservation_1447  12
    service_0_25_0  unique_nonzero_owner_376  1
    service_0_25_0  service_visit_def_763  1
    service_0_25_0  free_load_conservation_764  -1
    service_0_25_0  original_T_including_depot_unload_780  120
    service_0_25_2  unique_nonzero_owner_377  1
    service_0_25_2  service_visit_def_763  1
    service_0_25_2  free_load_conservation_764  1
    service_0_25_3  unique_nonzero_owner_378  1
    service_0_25_3  service_visit_def_763  1
    service_0_25_3  free_load_conservation_764  2
    service_0_25_4  unique_nonzero_owner_379  1
    service_0_25_4  service_visit_def_763  1
    service_0_25_4  free_load_conservation_764  3
    service_0_25_5  unique_nonzero_owner_380  1
    service_0_25_5  service_visit_def_763  1
    service_0_25_5  free_load_conservation_764  4
    service_0_25_6  unique_nonzero_owner_381  1
    service_0_25_6  service_visit_def_763  1
    service_0_25_6  free_load_conservation_764  5
    service_0_25_7  unique_nonzero_owner_382  1
    service_0_25_7  service_visit_def_763  1
    service_0_25_7  free_load_conservation_764  6
    service_0_25_8  unique_nonzero_owner_383  1
    service_0_25_8  service_visit_def_763  1
    service_0_25_8  free_load_conservation_764  7
    service_0_25_9  unique_nonzero_owner_384  1
    service_0_25_9  service_visit_def_763  1
    service_0_25_9  free_load_conservation_764  8
    service_0_25_10  unique_nonzero_owner_385  1
    service_0_25_10  service_visit_def_763  1
    service_0_25_10  free_load_conservation_764  9
    service_0_25_11  unique_nonzero_owner_386  1
    service_0_25_11  service_visit_def_763  1
    service_0_25_11  free_load_conservation_764  10
    service_0_25_12  unique_nonzero_owner_387  1
    service_0_25_12  service_visit_def_763  1
    service_0_25_12  free_load_conservation_764  11
    service_0_25_13  unique_nonzero_owner_388  1
    service_0_25_13  service_visit_def_763  1
    service_0_25_13  free_load_conservation_764  12
    service_0_25_14  unique_nonzero_owner_389  1
    service_0_25_14  service_visit_def_763  1
    service_0_25_14  free_load_conservation_764  13
    service_0_25_15  unique_nonzero_owner_390  1
    service_0_25_15  service_visit_def_763  1
    service_0_25_15  free_load_conservation_764  14
    service_1_25_0  unique_nonzero_owner_376  1
    service_1_25_0  service_visit_def_1134  1
    service_1_25_0  free_load_conservation_1135  -1
    service_1_25_0  original_T_including_depot_unload_1151  120
    service_1_25_2  unique_nonzero_owner_377  1
    service_1_25_2  service_visit_def_1134  1
    service_1_25_2  free_load_conservation_1135  1
    service_1_25_3  unique_nonzero_owner_378  1
    service_1_25_3  service_visit_def_1134  1
    service_1_25_3  free_load_conservation_1135  2
    service_1_25_4  unique_nonzero_owner_379  1
    service_1_25_4  service_visit_def_1134  1
    service_1_25_4  free_load_conservation_1135  3
    service_1_25_5  unique_nonzero_owner_380  1
    service_1_25_5  service_visit_def_1134  1
    service_1_25_5  free_load_conservation_1135  4
    service_1_25_6  unique_nonzero_owner_381  1
    service_1_25_6  service_visit_def_1134  1
    service_1_25_6  free_load_conservation_1135  5
    service_1_25_7  unique_nonzero_owner_382  1
    service_1_25_7  service_visit_def_1134  1
    service_1_25_7  free_load_conservation_1135  6
    service_1_25_8  unique_nonzero_owner_383  1
    service_1_25_8  service_visit_def_1134  1
    service_1_25_8  free_load_conservation_1135  7
    service_1_25_9  unique_nonzero_owner_384  1
    service_1_25_9  service_visit_def_1134  1
    service_1_25_9  free_load_conservation_1135  8
    service_1_25_10  unique_nonzero_owner_385  1
    service_1_25_10  service_visit_def_1134  1
    service_1_25_10  free_load_conservation_1135  9
    service_1_25_11  unique_nonzero_owner_386  1
    service_1_25_11  service_visit_def_1134  1
    service_1_25_11  free_load_conservation_1135  10
    service_1_25_12  unique_nonzero_owner_387  1
    service_1_25_12  service_visit_def_1134  1
    service_1_25_12  free_load_conservation_1135  11
    service_1_25_13  unique_nonzero_owner_388  1
    service_1_25_13  service_visit_def_1134  1
    service_1_25_13  free_load_conservation_1135  12
    service_1_25_14  unique_nonzero_owner_389  1
    service_1_25_14  service_visit_def_1134  1
    service_1_25_14  free_load_conservation_1135  13
    service_1_25_15  unique_nonzero_owner_390  1
    service_1_25_15  service_visit_def_1134  1
    service_1_25_15  free_load_conservation_1135  14
    service_2_25_0  unique_nonzero_owner_376  1
    service_2_25_0  service_visit_def_1452  1
    service_2_25_0  free_load_conservation_1453  -1
    service_2_25_0  original_T_including_depot_unload_1468  120
    service_2_25_2  unique_nonzero_owner_377  1
    service_2_25_2  service_visit_def_1452  1
    service_2_25_2  free_load_conservation_1453  1
    service_2_25_3  unique_nonzero_owner_378  1
    service_2_25_3  service_visit_def_1452  1
    service_2_25_3  free_load_conservation_1453  2
    service_2_25_4  unique_nonzero_owner_379  1
    service_2_25_4  service_visit_def_1452  1
    service_2_25_4  free_load_conservation_1453  3
    service_2_25_5  unique_nonzero_owner_380  1
    service_2_25_5  service_visit_def_1452  1
    service_2_25_5  free_load_conservation_1453  4
    service_2_25_6  unique_nonzero_owner_381  1
    service_2_25_6  service_visit_def_1452  1
    service_2_25_6  free_load_conservation_1453  5
    service_2_25_7  unique_nonzero_owner_382  1
    service_2_25_7  service_visit_def_1452  1
    service_2_25_7  free_load_conservation_1453  6
    service_2_25_8  unique_nonzero_owner_383  1
    service_2_25_8  service_visit_def_1452  1
    service_2_25_8  free_load_conservation_1453  7
    service_2_25_9  unique_nonzero_owner_384  1
    service_2_25_9  service_visit_def_1452  1
    service_2_25_9  free_load_conservation_1453  8
    service_2_25_10  unique_nonzero_owner_385  1
    service_2_25_10  service_visit_def_1452  1
    service_2_25_10  free_load_conservation_1453  9
    service_2_25_11  unique_nonzero_owner_386  1
    service_2_25_11  service_visit_def_1452  1
    service_2_25_11  free_load_conservation_1453  10
    service_2_25_12  unique_nonzero_owner_387  1
    service_2_25_12  service_visit_def_1452  1
    service_2_25_12  free_load_conservation_1453  11
    service_2_25_13  unique_nonzero_owner_388  1
    service_2_25_13  service_visit_def_1452  1
    service_2_25_13  free_load_conservation_1453  12
    service_2_25_14  unique_nonzero_owner_389  1
    service_2_25_14  service_visit_def_1452  1
    service_2_25_14  free_load_conservation_1453  13
    service_2_25_15  unique_nonzero_owner_390  1
    service_2_25_15  service_visit_def_1452  1
    service_2_25_15  free_load_conservation_1453  14
    service_0_19_1  unique_nonzero_owner_391  1
    service_0_19_1  service_visit_def_769  1
    service_0_19_1  free_load_conservation_770  1
    service_0_19_2  unique_nonzero_owner_392  1
    service_0_19_2  service_visit_def_769  1
    service_0_19_2  free_load_conservation_770  2
    service_0_19_3  unique_nonzero_owner_393  1
    service_0_19_3  service_visit_def_769  1
    service_0_19_3  free_load_conservation_770  3
    service_0_19_4  unique_nonzero_owner_394  1
    service_0_19_4  service_visit_def_769  1
    service_0_19_4  free_load_conservation_770  4
    service_0_19_5  unique_nonzero_owner_395  1
    service_0_19_5  service_visit_def_769  1
    service_0_19_5  free_load_conservation_770  5
    service_0_19_6  unique_nonzero_owner_396  1
    service_0_19_6  service_visit_def_769  1
    service_0_19_6  free_load_conservation_770  6
    service_0_19_7  unique_nonzero_owner_397  1
    service_0_19_7  service_visit_def_769  1
    service_0_19_7  free_load_conservation_770  7
    service_0_19_8  unique_nonzero_owner_398  1
    service_0_19_8  service_visit_def_769  1
    service_0_19_8  free_load_conservation_770  8
    service_1_19_1  unique_nonzero_owner_391  1
    service_1_19_1  service_visit_def_1140  1
    service_1_19_1  free_load_conservation_1141  1
    service_1_19_2  unique_nonzero_owner_392  1
    service_1_19_2  service_visit_def_1140  1
    service_1_19_2  free_load_conservation_1141  2
    service_1_19_3  unique_nonzero_owner_393  1
    service_1_19_3  service_visit_def_1140  1
    service_1_19_3  free_load_conservation_1141  3
    service_1_19_4  unique_nonzero_owner_394  1
    service_1_19_4  service_visit_def_1140  1
    service_1_19_4  free_load_conservation_1141  4
    service_1_19_5  unique_nonzero_owner_395  1
    service_1_19_5  service_visit_def_1140  1
    service_1_19_5  free_load_conservation_1141  5
    service_1_19_6  unique_nonzero_owner_396  1
    service_1_19_6  service_visit_def_1140  1
    service_1_19_6  free_load_conservation_1141  6
    service_1_19_7  unique_nonzero_owner_397  1
    service_1_19_7  service_visit_def_1140  1
    service_1_19_7  free_load_conservation_1141  7
    service_1_19_8  unique_nonzero_owner_398  1
    service_1_19_8  service_visit_def_1140  1
    service_1_19_8  free_load_conservation_1141  8
    service_2_19_1  unique_nonzero_owner_391  1
    service_2_19_1  service_visit_def_1458  1
    service_2_19_1  free_load_conservation_1459  1
    service_2_19_2  unique_nonzero_owner_392  1
    service_2_19_2  service_visit_def_1458  1
    service_2_19_2  free_load_conservation_1459  2
    service_2_19_3  unique_nonzero_owner_393  1
    service_2_19_3  service_visit_def_1458  1
    service_2_19_3  free_load_conservation_1459  3
    service_2_19_4  unique_nonzero_owner_394  1
    service_2_19_4  service_visit_def_1458  1
    service_2_19_4  free_load_conservation_1459  4
    service_2_19_5  unique_nonzero_owner_395  1
    service_2_19_5  service_visit_def_1458  1
    service_2_19_5  free_load_conservation_1459  5
    service_2_19_6  unique_nonzero_owner_396  1
    service_2_19_6  service_visit_def_1458  1
    service_2_19_6  free_load_conservation_1459  6
    service_2_19_7  unique_nonzero_owner_397  1
    service_2_19_7  service_visit_def_1458  1
    service_2_19_7  free_load_conservation_1459  7
    service_2_19_8  unique_nonzero_owner_398  1
    service_2_19_8  service_visit_def_1458  1
    service_2_19_8  free_load_conservation_1459  8
    service_0_34_0  unique_nonzero_owner_399  1
    service_0_34_0  service_visit_def_775  1
    service_0_34_0  free_load_conservation_776  -1
    service_0_34_0  original_T_including_depot_unload_780  120
    service_0_34_2  unique_nonzero_owner_400  1
    service_0_34_2  service_visit_def_775  1
    service_0_34_2  free_load_conservation_776  1
    service_0_34_3  unique_nonzero_owner_401  1
    service_0_34_3  service_visit_def_775  1
    service_0_34_3  free_load_conservation_776  2
    service_0_34_4  unique_nonzero_owner_402  1
    service_0_34_4  service_visit_def_775  1
    service_0_34_4  free_load_conservation_776  3
    service_0_34_5  unique_nonzero_owner_403  1
    service_0_34_5  service_visit_def_775  1
    service_0_34_5  free_load_conservation_776  4
    service_0_34_6  unique_nonzero_owner_404  1
    service_0_34_6  service_visit_def_775  1
    service_0_34_6  free_load_conservation_776  5
    service_0_34_7  unique_nonzero_owner_405  1
    service_0_34_7  service_visit_def_775  1
    service_0_34_7  free_load_conservation_776  6
    service_0_34_8  unique_nonzero_owner_406  1
    service_0_34_8  service_visit_def_775  1
    service_0_34_8  free_load_conservation_776  7
    service_0_34_9  unique_nonzero_owner_407  1
    service_0_34_9  service_visit_def_775  1
    service_0_34_9  free_load_conservation_776  8
    service_0_34_10  unique_nonzero_owner_408  1
    service_0_34_10  service_visit_def_775  1
    service_0_34_10  free_load_conservation_776  9
    service_0_34_11  unique_nonzero_owner_409  1
    service_0_34_11  service_visit_def_775  1
    service_0_34_11  free_load_conservation_776  10
    service_1_34_0  unique_nonzero_owner_399  1
    service_1_34_0  service_visit_def_1146  1
    service_1_34_0  free_load_conservation_1147  -1
    service_1_34_0  original_T_including_depot_unload_1151  120
    service_1_34_2  unique_nonzero_owner_400  1
    service_1_34_2  service_visit_def_1146  1
    service_1_34_2  free_load_conservation_1147  1
    service_1_34_3  unique_nonzero_owner_401  1
    service_1_34_3  service_visit_def_1146  1
    service_1_34_3  free_load_conservation_1147  2
    service_1_34_4  unique_nonzero_owner_402  1
    service_1_34_4  service_visit_def_1146  1
    service_1_34_4  free_load_conservation_1147  3
    service_1_34_5  unique_nonzero_owner_403  1
    service_1_34_5  service_visit_def_1146  1
    service_1_34_5  free_load_conservation_1147  4
    service_1_34_6  unique_nonzero_owner_404  1
    service_1_34_6  service_visit_def_1146  1
    service_1_34_6  free_load_conservation_1147  5
    service_1_34_7  unique_nonzero_owner_405  1
    service_1_34_7  service_visit_def_1146  1
    service_1_34_7  free_load_conservation_1147  6
    service_1_34_8  unique_nonzero_owner_406  1
    service_1_34_8  service_visit_def_1146  1
    service_1_34_8  free_load_conservation_1147  7
    service_1_34_9  unique_nonzero_owner_407  1
    service_1_34_9  service_visit_def_1146  1
    service_1_34_9  free_load_conservation_1147  8
    service_1_34_10  unique_nonzero_owner_408  1
    service_1_34_10  service_visit_def_1146  1
    service_1_34_10  free_load_conservation_1147  9
    service_1_34_11  unique_nonzero_owner_409  1
    service_1_34_11  service_visit_def_1146  1
    service_1_34_11  free_load_conservation_1147  10
    service_2_34_0  unique_nonzero_owner_399  1
    service_2_34_0  service_visit_def_1464  1
    service_2_34_0  free_load_conservation_1465  -1
    service_2_34_0  original_T_including_depot_unload_1468  120
    service_2_34_2  unique_nonzero_owner_400  1
    service_2_34_2  service_visit_def_1464  1
    service_2_34_2  free_load_conservation_1465  1
    service_2_34_3  unique_nonzero_owner_401  1
    service_2_34_3  service_visit_def_1464  1
    service_2_34_3  free_load_conservation_1465  2
    service_2_34_4  unique_nonzero_owner_402  1
    service_2_34_4  service_visit_def_1464  1
    service_2_34_4  free_load_conservation_1465  3
    service_2_34_5  unique_nonzero_owner_403  1
    service_2_34_5  service_visit_def_1464  1
    service_2_34_5  free_load_conservation_1465  4
    service_2_34_6  unique_nonzero_owner_404  1
    service_2_34_6  service_visit_def_1464  1
    service_2_34_6  free_load_conservation_1465  5
    service_2_34_7  unique_nonzero_owner_405  1
    service_2_34_7  service_visit_def_1464  1
    service_2_34_7  free_load_conservation_1465  6
    service_2_34_8  unique_nonzero_owner_406  1
    service_2_34_8  service_visit_def_1464  1
    service_2_34_8  free_load_conservation_1465  7
    service_2_34_9  unique_nonzero_owner_407  1
    service_2_34_9  service_visit_def_1464  1
    service_2_34_9  free_load_conservation_1465  8
    service_2_34_10  unique_nonzero_owner_408  1
    service_2_34_10  service_visit_def_1464  1
    service_2_34_10  free_load_conservation_1465  9
    service_2_34_11  unique_nonzero_owner_409  1
    service_2_34_11  service_visit_def_1464  1
    service_2_34_11  free_load_conservation_1465  10
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_701  -1
    visit_0_1  in_degree_702  -1
    visit_0_1  order_active_lb_703  -1
    visit_0_1  order_active_ub_704  -12
    order_0_1  connected_order_arc_425  -1
    order_0_1  connected_order_arc_427  -1
    order_0_1  connected_order_arc_429  -1
    order_0_1  connected_order_arc_431  -1
    order_0_1  connected_order_arc_433  -1
    order_0_1  connected_order_arc_435  -1
    order_0_1  connected_order_arc_437  -1
    order_0_1  connected_order_arc_439  -1
    order_0_1  connected_order_arc_441  -1
    order_0_1  connected_order_arc_443  -1
    order_0_1  connected_order_arc_445  -1
    order_0_1  connected_order_arc_448  1
    order_0_1  connected_order_arc_471  1
    order_0_1  connected_order_arc_494  1
    order_0_1  connected_order_arc_517  1
    order_0_1  connected_order_arc_540  1
    order_0_1  connected_order_arc_563  1
    order_0_1  connected_order_arc_586  1
    order_0_1  connected_order_arc_609  1
    order_0_1  connected_order_arc_632  1
    order_0_1  connected_order_arc_655  1
    order_0_1  connected_order_arc_678  1
    order_0_1  order_active_lb_703  1
    order_0_1  order_active_ub_704  1
    order_0_1  fixed_segment_relative_order_777  -1
    visit_0_2  out_degree_708  -1
    visit_0_2  in_degree_709  -1
    visit_0_2  order_active_lb_710  -1
    visit_0_2  order_active_ub_711  -12
    order_0_2  connected_order_arc_425  1
    order_0_2  connected_order_arc_448  -1
    order_0_2  connected_order_arc_450  -1
    order_0_2  connected_order_arc_452  -1
    order_0_2  connected_order_arc_454  -1
    order_0_2  connected_order_arc_456  -1
    order_0_2  connected_order_arc_458  -1
    order_0_2  connected_order_arc_460  -1
    order_0_2  connected_order_arc_462  -1
    order_0_2  connected_order_arc_464  -1
    order_0_2  connected_order_arc_466  -1
    order_0_2  connected_order_arc_468  -1
    order_0_2  connected_order_arc_473  1
    order_0_2  connected_order_arc_496  1
    order_0_2  connected_order_arc_519  1
    order_0_2  connected_order_arc_542  1
    order_0_2  connected_order_arc_565  1
    order_0_2  connected_order_arc_588  1
    order_0_2  connected_order_arc_611  1
    order_0_2  connected_order_arc_634  1
    order_0_2  connected_order_arc_657  1
    order_0_2  connected_order_arc_680  1
    order_0_2  order_active_lb_710  1
    order_0_2  order_active_ub_711  1
    order_0_2  fixed_segment_relative_order_777  1
    order_0_2  fixed_segment_relative_order_778  -1
    visit_0_3  out_degree_715  -1
    visit_0_3  in_degree_716  -1
    visit_0_3  order_active_lb_717  -1
    visit_0_3  order_active_ub_718  -12
    order_0_3  connected_order_arc_427  1
    order_0_3  connected_order_arc_450  1
    order_0_3  connected_order_arc_471  -1
    order_0_3  connected_order_arc_473  -1
    order_0_3  connected_order_arc_475  -1
    order_0_3  connected_order_arc_477  -1
    order_0_3  connected_order_arc_479  -1
    order_0_3  connected_order_arc_481  -1
    order_0_3  connected_order_arc_483  -1
    order_0_3  connected_order_arc_485  -1
    order_0_3  connected_order_arc_487  -1
    order_0_3  connected_order_arc_489  -1
    order_0_3  connected_order_arc_491  -1
    order_0_3  connected_order_arc_498  1
    order_0_3  connected_order_arc_521  1
    order_0_3  connected_order_arc_544  1
    order_0_3  connected_order_arc_567  1
    order_0_3  connected_order_arc_590  1
    order_0_3  connected_order_arc_613  1
    order_0_3  connected_order_arc_636  1
    order_0_3  connected_order_arc_659  1
    order_0_3  connected_order_arc_682  1
    order_0_3  order_active_lb_717  1
    order_0_3  order_active_ub_718  1
    order_0_3  fixed_segment_relative_order_778  1
    order_0_3  fixed_segment_relative_order_779  -1
    visit_0_4  out_degree_722  -1
    visit_0_4  in_degree_723  -1
    visit_0_4  order_active_lb_724  -1
    visit_0_4  order_active_ub_725  -12
    order_0_4  connected_order_arc_429  1
    order_0_4  connected_order_arc_452  1
    order_0_4  connected_order_arc_475  1
    order_0_4  connected_order_arc_494  -1
    order_0_4  connected_order_arc_496  -1
    order_0_4  connected_order_arc_498  -1
    order_0_4  connected_order_arc_500  -1
    order_0_4  connected_order_arc_502  -1
    order_0_4  connected_order_arc_504  -1
    order_0_4  connected_order_arc_506  -1
    order_0_4  connected_order_arc_508  -1
    order_0_4  connected_order_arc_510  -1
    order_0_4  connected_order_arc_512  -1
    order_0_4  connected_order_arc_514  -1
    order_0_4  connected_order_arc_523  1
    order_0_4  connected_order_arc_546  1
    order_0_4  connected_order_arc_569  1
    order_0_4  connected_order_arc_592  1
    order_0_4  connected_order_arc_615  1
    order_0_4  connected_order_arc_638  1
    order_0_4  connected_order_arc_661  1
    order_0_4  connected_order_arc_684  1
    order_0_4  order_active_lb_724  1
    order_0_4  order_active_ub_725  1
    order_0_4  fixed_segment_relative_order_779  1
    visit_0_12  out_degree_729  -1
    visit_0_12  in_degree_730  -1
    visit_0_12  order_active_lb_731  -1
    visit_0_12  order_active_ub_732  -12
    visit_0_12  service_visit_def_733  -1
    order_0_12  connected_order_arc_431  1
    order_0_12  connected_order_arc_454  1
    order_0_12  connected_order_arc_477  1
    order_0_12  connected_order_arc_500  1
    order_0_12  connected_order_arc_517  -1
    order_0_12  connected_order_arc_519  -1
    order_0_12  connected_order_arc_521  -1
    order_0_12  connected_order_arc_523  -1
    order_0_12  connected_order_arc_525  -1
    order_0_12  connected_order_arc_527  -1
    order_0_12  connected_order_arc_529  -1
    order_0_12  connected_order_arc_531  -1
    order_0_12  connected_order_arc_533  -1
    order_0_12  connected_order_arc_535  -1
    order_0_12  connected_order_arc_537  -1
    order_0_12  connected_order_arc_548  1
    order_0_12  connected_order_arc_571  1
    order_0_12  connected_order_arc_594  1
    order_0_12  connected_order_arc_617  1
    order_0_12  connected_order_arc_640  1
    order_0_12  connected_order_arc_663  1
    order_0_12  connected_order_arc_686  1
    order_0_12  order_active_lb_731  1
    order_0_12  order_active_ub_732  1
    visit_0_13  out_degree_735  -1
    visit_0_13  in_degree_736  -1
    visit_0_13  order_active_lb_737  -1
    visit_0_13  order_active_ub_738  -12
    visit_0_13  service_visit_def_739  -1
    order_0_13  connected_order_arc_433  1
    order_0_13  connected_order_arc_456  1
    order_0_13  connected_order_arc_479  1
    order_0_13  connected_order_arc_502  1
    order_0_13  connected_order_arc_525  1
    order_0_13  connected_order_arc_540  -1
    order_0_13  connected_order_arc_542  -1
    order_0_13  connected_order_arc_544  -1
    order_0_13  connected_order_arc_546  -1
    order_0_13  connected_order_arc_548  -1
    order_0_13  connected_order_arc_550  -1
    order_0_13  connected_order_arc_552  -1
    order_0_13  connected_order_arc_554  -1
    order_0_13  connected_order_arc_556  -1
    order_0_13  connected_order_arc_558  -1
    order_0_13  connected_order_arc_560  -1
    order_0_13  connected_order_arc_573  1
    order_0_13  connected_order_arc_596  1
    order_0_13  connected_order_arc_619  1
    order_0_13  connected_order_arc_642  1
    order_0_13  connected_order_arc_665  1
    order_0_13  connected_order_arc_688  1
    order_0_13  order_active_lb_737  1
    order_0_13  order_active_ub_738  1
    visit_0_14  out_degree_741  -1
    visit_0_14  in_degree_742  -1
    visit_0_14  order_active_lb_743  -1
    visit_0_14  order_active_ub_744  -12
    visit_0_14  service_visit_def_745  -1
    order_0_14  connected_order_arc_435  1
    order_0_14  connected_order_arc_458  1
    order_0_14  connected_order_arc_481  1
    order_0_14  connected_order_arc_504  1
    order_0_14  connected_order_arc_527  1
    order_0_14  connected_order_arc_550  1
    order_0_14  connected_order_arc_563  -1
    order_0_14  connected_order_arc_565  -1
    order_0_14  connected_order_arc_567  -1
    order_0_14  connected_order_arc_569  -1
    order_0_14  connected_order_arc_571  -1
    order_0_14  connected_order_arc_573  -1
    order_0_14  connected_order_arc_575  -1
    order_0_14  connected_order_arc_577  -1
    order_0_14  connected_order_arc_579  -1
    order_0_14  connected_order_arc_581  -1
    order_0_14  connected_order_arc_583  -1
    order_0_14  connected_order_arc_598  1
    order_0_14  connected_order_arc_621  1
    order_0_14  connected_order_arc_644  1
    order_0_14  connected_order_arc_667  1
    order_0_14  connected_order_arc_690  1
    order_0_14  order_active_lb_743  1
    order_0_14  order_active_ub_744  1
    visit_0_15  out_degree_747  -1
    visit_0_15  in_degree_748  -1
    visit_0_15  order_active_lb_749  -1
    visit_0_15  order_active_ub_750  -12
    visit_0_15  service_visit_def_751  -1
    order_0_15  connected_order_arc_437  1
    order_0_15  connected_order_arc_460  1
    order_0_15  connected_order_arc_483  1
    order_0_15  connected_order_arc_506  1
    order_0_15  connected_order_arc_529  1
    order_0_15  connected_order_arc_552  1
    order_0_15  connected_order_arc_575  1
    order_0_15  connected_order_arc_586  -1
    order_0_15  connected_order_arc_588  -1
    order_0_15  connected_order_arc_590  -1
    order_0_15  connected_order_arc_592  -1
    order_0_15  connected_order_arc_594  -1
    order_0_15  connected_order_arc_596  -1
    order_0_15  connected_order_arc_598  -1
    order_0_15  connected_order_arc_600  -1
    order_0_15  connected_order_arc_602  -1
    order_0_15  connected_order_arc_604  -1
    order_0_15  connected_order_arc_606  -1
    order_0_15  connected_order_arc_623  1
    order_0_15  connected_order_arc_646  1
    order_0_15  connected_order_arc_669  1
    order_0_15  connected_order_arc_692  1
    order_0_15  order_active_lb_749  1
    order_0_15  order_active_ub_750  1
    visit_0_16  out_degree_753  -1
    visit_0_16  in_degree_754  -1
    visit_0_16  order_active_lb_755  -1
    visit_0_16  order_active_ub_756  -12
    visit_0_16  service_visit_def_757  -1
    order_0_16  connected_order_arc_439  1
    order_0_16  connected_order_arc_462  1
    order_0_16  connected_order_arc_485  1
    order_0_16  connected_order_arc_508  1
    order_0_16  connected_order_arc_531  1
    order_0_16  connected_order_arc_554  1
    order_0_16  connected_order_arc_577  1
    order_0_16  connected_order_arc_600  1
    order_0_16  connected_order_arc_609  -1
    order_0_16  connected_order_arc_611  -1
    order_0_16  connected_order_arc_613  -1
    order_0_16  connected_order_arc_615  -1
    order_0_16  connected_order_arc_617  -1
    order_0_16  connected_order_arc_619  -1
    order_0_16  connected_order_arc_621  -1
    order_0_16  connected_order_arc_623  -1
    order_0_16  connected_order_arc_625  -1
    order_0_16  connected_order_arc_627  -1
    order_0_16  connected_order_arc_629  -1
    order_0_16  connected_order_arc_648  1
    order_0_16  connected_order_arc_671  1
    order_0_16  connected_order_arc_694  1
    order_0_16  order_active_lb_755  1
    order_0_16  order_active_ub_756  1
    visit_0_17  out_degree_759  -1
    visit_0_17  in_degree_760  -1
    visit_0_17  order_active_lb_761  -1
    visit_0_17  order_active_ub_762  -12
    visit_0_17  service_visit_def_763  -1
    order_0_17  connected_order_arc_441  1
    order_0_17  connected_order_arc_464  1
    order_0_17  connected_order_arc_487  1
    order_0_17  connected_order_arc_510  1
    order_0_17  connected_order_arc_533  1
    order_0_17  connected_order_arc_556  1
    order_0_17  connected_order_arc_579  1
    order_0_17  connected_order_arc_602  1
    order_0_17  connected_order_arc_625  1
    order_0_17  connected_order_arc_632  -1
    order_0_17  connected_order_arc_634  -1
    order_0_17  connected_order_arc_636  -1
    order_0_17  connected_order_arc_638  -1
    order_0_17  connected_order_arc_640  -1
    order_0_17  connected_order_arc_642  -1
    order_0_17  connected_order_arc_644  -1
    order_0_17  connected_order_arc_646  -1
    order_0_17  connected_order_arc_648  -1
    order_0_17  connected_order_arc_650  -1
    order_0_17  connected_order_arc_652  -1
    order_0_17  connected_order_arc_673  1
    order_0_17  connected_order_arc_696  1
    order_0_17  order_active_lb_761  1
    order_0_17  order_active_ub_762  1
    visit_0_18  out_degree_765  -1
    visit_0_18  in_degree_766  -1
    visit_0_18  order_active_lb_767  -1
    visit_0_18  order_active_ub_768  -12
    visit_0_18  service_visit_def_769  -1
    order_0_18  connected_order_arc_443  1
    order_0_18  connected_order_arc_466  1
    order_0_18  connected_order_arc_489  1
    order_0_18  connected_order_arc_512  1
    order_0_18  connected_order_arc_535  1
    order_0_18  connected_order_arc_558  1
    order_0_18  connected_order_arc_581  1
    order_0_18  connected_order_arc_604  1
    order_0_18  connected_order_arc_627  1
    order_0_18  connected_order_arc_650  1
    order_0_18  connected_order_arc_655  -1
    order_0_18  connected_order_arc_657  -1
    order_0_18  connected_order_arc_659  -1
    order_0_18  connected_order_arc_661  -1
    order_0_18  connected_order_arc_663  -1
    order_0_18  connected_order_arc_665  -1
    order_0_18  connected_order_arc_667  -1
    order_0_18  connected_order_arc_669  -1
    order_0_18  connected_order_arc_671  -1
    order_0_18  connected_order_arc_673  -1
    order_0_18  connected_order_arc_675  -1
    order_0_18  connected_order_arc_698  1
    order_0_18  order_active_lb_767  1
    order_0_18  order_active_ub_768  1
    visit_0_19  out_degree_771  -1
    visit_0_19  in_degree_772  -1
    visit_0_19  order_active_lb_773  -1
    visit_0_19  order_active_ub_774  -12
    visit_0_19  service_visit_def_775  -1
    order_0_19  connected_order_arc_445  1
    order_0_19  connected_order_arc_468  1
    order_0_19  connected_order_arc_491  1
    order_0_19  connected_order_arc_514  1
    order_0_19  connected_order_arc_537  1
    order_0_19  connected_order_arc_560  1
    order_0_19  connected_order_arc_583  1
    order_0_19  connected_order_arc_606  1
    order_0_19  connected_order_arc_629  1
    order_0_19  connected_order_arc_652  1
    order_0_19  connected_order_arc_675  1
    order_0_19  connected_order_arc_678  -1
    order_0_19  connected_order_arc_680  -1
    order_0_19  connected_order_arc_682  -1
    order_0_19  connected_order_arc_684  -1
    order_0_19  connected_order_arc_686  -1
    order_0_19  connected_order_arc_688  -1
    order_0_19  connected_order_arc_690  -1
    order_0_19  connected_order_arc_692  -1
    order_0_19  connected_order_arc_694  -1
    order_0_19  connected_order_arc_696  -1
    order_0_19  connected_order_arc_698  -1
    order_0_19  order_active_lb_773  1
    order_0_19  order_active_ub_774  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_410  -20
    arc_0_0_0  depot_departure_or_bypass_699  1
    arc_0_0_0  depot_return_or_bypass_700  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_410  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_411  -20
    arc_0_0_1  depot_departure_or_bypass_699  1
    arc_0_0_1  in_degree_702  1
    arc_0_0_1  original_T_including_depot_unload_780  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_411  1
    load_0_0_1  segment_load_conservation_705  -1
    load_0_0_1  segment_prefix_lb_706  1
    load_0_0_1  segment_prefix_ub_707  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_412  -20
    arc_0_0_2  depot_departure_or_bypass_699  1
    arc_0_0_2  in_degree_709  1
    arc_0_0_2  original_T_including_depot_unload_780  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_412  1
    load_0_0_2  segment_load_conservation_712  -1
    load_0_0_2  segment_prefix_lb_713  1
    load_0_0_2  segment_prefix_ub_714  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_413  -20
    arc_0_0_3  depot_departure_or_bypass_699  1
    arc_0_0_3  in_degree_716  1
    arc_0_0_3  original_T_including_depot_unload_780  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_413  1
    load_0_0_3  segment_load_conservation_719  -1
    load_0_0_3  segment_prefix_lb_720  1
    load_0_0_3  segment_prefix_ub_721  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_414  -20
    arc_0_0_4  depot_departure_or_bypass_699  1
    arc_0_0_4  in_degree_723  1
    arc_0_0_4  original_T_including_depot_unload_780  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_414  1
    load_0_0_4  segment_load_conservation_726  -1
    load_0_0_4  segment_prefix_lb_727  1
    load_0_0_4  segment_prefix_ub_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_415  -20
    arc_0_0_12  depot_departure_or_bypass_699  1
    arc_0_0_12  in_degree_730  1
    arc_0_0_12  original_T_including_depot_unload_780  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_415  1
    load_0_0_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_416  -20
    arc_0_0_13  depot_departure_or_bypass_699  1
    arc_0_0_13  in_degree_736  1
    arc_0_0_13  original_T_including_depot_unload_780  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_416  1
    load_0_0_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_417  -20
    arc_0_0_14  depot_departure_or_bypass_699  1
    arc_0_0_14  in_degree_742  1
    arc_0_0_14  original_T_including_depot_unload_780  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_417  1
    load_0_0_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_418  -20
    arc_0_0_15  depot_departure_or_bypass_699  1
    arc_0_0_15  in_degree_748  1
    arc_0_0_15  original_T_including_depot_unload_780  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_418  1
    load_0_0_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_419  -20
    arc_0_0_16  depot_departure_or_bypass_699  1
    arc_0_0_16  in_degree_754  1
    arc_0_0_16  original_T_including_depot_unload_780  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_419  1
    load_0_0_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_420  -20
    arc_0_0_17  depot_departure_or_bypass_699  1
    arc_0_0_17  in_degree_760  1
    arc_0_0_17  original_T_including_depot_unload_780  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_420  1
    load_0_0_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_421  -20
    arc_0_0_18  depot_departure_or_bypass_699  1
    arc_0_0_18  in_degree_766  1
    arc_0_0_18  original_T_including_depot_unload_780  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_421  1
    load_0_0_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_422  -20
    arc_0_0_19  depot_departure_or_bypass_699  1
    arc_0_0_19  in_degree_772  1
    arc_0_0_19  original_T_including_depot_unload_780  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_422  1
    load_0_0_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_423  -20
    arc_0_1_0  depot_return_or_bypass_700  1
    arc_0_1_0  out_degree_701  1
    arc_0_1_0  original_T_including_depot_unload_780  6.6653528395596720e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_423  1
    load_0_1_0  segment_load_conservation_705  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_424  -20
    arc_0_1_2  connected_order_arc_425  -13
    arc_0_1_2  out_degree_701  1
    arc_0_1_2  in_degree_709  1
    arc_0_1_2  original_T_including_depot_unload_780  3.2985327387120213e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_424  1
    load_0_1_2  segment_load_conservation_705  1
    load_0_1_2  segment_load_conservation_712  -1
    load_0_1_2  segment_prefix_lb_713  1
    load_0_1_2  segment_prefix_ub_714  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_426  -20
    arc_0_1_3  connected_order_arc_427  -13
    arc_0_1_3  out_degree_701  1
    arc_0_1_3  in_degree_716  1
    arc_0_1_3  original_T_including_depot_unload_780  5.2996691306068044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_426  1
    load_0_1_3  segment_load_conservation_705  1
    load_0_1_3  segment_load_conservation_719  -1
    load_0_1_3  segment_prefix_lb_720  1
    load_0_1_3  segment_prefix_ub_721  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_428  -20
    arc_0_1_4  connected_order_arc_429  -13
    arc_0_1_4  out_degree_701  1
    arc_0_1_4  in_degree_723  1
    arc_0_1_4  original_T_including_depot_unload_780  5.8442598457899078e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_428  1
    load_0_1_4  segment_load_conservation_705  1
    load_0_1_4  segment_load_conservation_726  -1
    load_0_1_4  segment_prefix_lb_727  1
    load_0_1_4  segment_prefix_ub_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_430  -20
    arc_0_1_12  connected_order_arc_431  -13
    arc_0_1_12  out_degree_701  1
    arc_0_1_12  in_degree_730  1
    arc_0_1_12  original_T_including_depot_unload_780  1.5437191441012344e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_430  1
    load_0_1_12  segment_load_conservation_705  1
    load_0_1_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_432  -20
    arc_0_1_13  connected_order_arc_433  -13
    arc_0_1_13  out_degree_701  1
    arc_0_1_13  in_degree_736  1
    arc_0_1_13  original_T_including_depot_unload_780  1.6744862285014353e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_432  1
    load_0_1_13  segment_load_conservation_705  1
    load_0_1_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_434  -20
    arc_0_1_14  connected_order_arc_435  -13
    arc_0_1_14  out_degree_701  1
    arc_0_1_14  in_degree_742  1
    arc_0_1_14  original_T_including_depot_unload_780  1.6292966848558842e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_434  1
    load_0_1_14  segment_load_conservation_705  1
    load_0_1_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_436  -20
    arc_0_1_15  connected_order_arc_437  -13
    arc_0_1_15  out_degree_701  1
    arc_0_1_15  in_degree_748  1
    arc_0_1_15  original_T_including_depot_unload_780  1.6982456083268751e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_436  1
    load_0_1_15  segment_load_conservation_705  1
    load_0_1_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_438  -20
    arc_0_1_16  connected_order_arc_439  -13
    arc_0_1_16  out_degree_701  1
    arc_0_1_16  in_degree_754  1
    arc_0_1_16  original_T_including_depot_unload_780  1.2927075446362680e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_438  1
    load_0_1_16  segment_load_conservation_705  1
    load_0_1_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_440  -20
    arc_0_1_17  connected_order_arc_441  -13
    arc_0_1_17  out_degree_701  1
    arc_0_1_17  in_degree_760  1
    arc_0_1_17  original_T_including_depot_unload_780  1.5053327747786273e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_440  1
    load_0_1_17  segment_load_conservation_705  1
    load_0_1_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_442  -20
    arc_0_1_18  connected_order_arc_443  -13
    arc_0_1_18  out_degree_701  1
    arc_0_1_18  in_degree_766  1
    arc_0_1_18  original_T_including_depot_unload_780  7.2751050611121218e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_442  1
    load_0_1_18  segment_load_conservation_705  1
    load_0_1_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_444  -20
    arc_0_1_19  connected_order_arc_445  -13
    arc_0_1_19  out_degree_701  1
    arc_0_1_19  in_degree_772  1
    arc_0_1_19  original_T_including_depot_unload_780  1.9301430792362414e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_444  1
    load_0_1_19  segment_load_conservation_705  1
    load_0_1_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_446  -20
    arc_0_2_0  depot_return_or_bypass_700  1
    arc_0_2_0  out_degree_708  1
    arc_0_2_0  original_T_including_depot_unload_780  5.9431738885389052e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_446  1
    load_0_2_0  segment_load_conservation_712  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_447  -20
    arc_0_2_1  connected_order_arc_448  -13
    arc_0_2_1  in_degree_702  1
    arc_0_2_1  out_degree_708  1
    arc_0_2_1  original_T_including_depot_unload_780  6.9736186698570737e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_447  1
    load_0_2_1  segment_load_conservation_705  -1
    load_0_2_1  segment_prefix_lb_706  1
    load_0_2_1  segment_prefix_ub_707  1
    load_0_2_1  segment_load_conservation_712  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_449  -20
    arc_0_2_3  connected_order_arc_450  -13
    arc_0_2_3  out_degree_708  1
    arc_0_2_3  in_degree_716  1
    arc_0_2_3  original_T_including_depot_unload_780  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_449  1
    load_0_2_3  segment_load_conservation_712  1
    load_0_2_3  segment_load_conservation_719  -1
    load_0_2_3  segment_prefix_lb_720  1
    load_0_2_3  segment_prefix_ub_721  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_451  -20
    arc_0_2_4  connected_order_arc_452  -13
    arc_0_2_4  out_degree_708  1
    arc_0_2_4  in_degree_723  1
    arc_0_2_4  original_T_including_depot_unload_780  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_451  1
    load_0_2_4  segment_load_conservation_712  1
    load_0_2_4  segment_load_conservation_726  -1
    load_0_2_4  segment_prefix_lb_727  1
    load_0_2_4  segment_prefix_ub_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_453  -20
    arc_0_2_12  connected_order_arc_454  -13
    arc_0_2_12  out_degree_708  1
    arc_0_2_12  in_degree_730  1
    arc_0_2_12  original_T_including_depot_unload_780  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_453  1
    load_0_2_12  segment_load_conservation_712  1
    load_0_2_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_455  -20
    arc_0_2_13  connected_order_arc_456  -13
    arc_0_2_13  out_degree_708  1
    arc_0_2_13  in_degree_736  1
    arc_0_2_13  original_T_including_depot_unload_780  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_455  1
    load_0_2_13  segment_load_conservation_712  1
    load_0_2_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_457  -20
    arc_0_2_14  connected_order_arc_458  -13
    arc_0_2_14  out_degree_708  1
    arc_0_2_14  in_degree_742  1
    arc_0_2_14  original_T_including_depot_unload_780  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_457  1
    load_0_2_14  segment_load_conservation_712  1
    load_0_2_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_459  -20
    arc_0_2_15  connected_order_arc_460  -13
    arc_0_2_15  out_degree_708  1
    arc_0_2_15  in_degree_748  1
    arc_0_2_15  original_T_including_depot_unload_780  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_459  1
    load_0_2_15  segment_load_conservation_712  1
    load_0_2_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_461  -20
    arc_0_2_16  connected_order_arc_462  -13
    arc_0_2_16  out_degree_708  1
    arc_0_2_16  in_degree_754  1
    arc_0_2_16  original_T_including_depot_unload_780  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_461  1
    load_0_2_16  segment_load_conservation_712  1
    load_0_2_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_463  -20
    arc_0_2_17  connected_order_arc_464  -13
    arc_0_2_17  out_degree_708  1
    arc_0_2_17  in_degree_760  1
    arc_0_2_17  original_T_including_depot_unload_780  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_463  1
    load_0_2_17  segment_load_conservation_712  1
    load_0_2_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_465  -20
    arc_0_2_18  connected_order_arc_466  -13
    arc_0_2_18  out_degree_708  1
    arc_0_2_18  in_degree_766  1
    arc_0_2_18  original_T_including_depot_unload_780  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_465  1
    load_0_2_18  segment_load_conservation_712  1
    load_0_2_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_467  -20
    arc_0_2_19  connected_order_arc_468  -13
    arc_0_2_19  out_degree_708  1
    arc_0_2_19  in_degree_772  1
    arc_0_2_19  original_T_including_depot_unload_780  1.8527392017187374e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_467  1
    load_0_2_19  segment_load_conservation_712  1
    load_0_2_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_469  -20
    arc_0_3_0  depot_return_or_bypass_700  1
    arc_0_3_0  out_degree_715  1
    arc_0_3_0  original_T_including_depot_unload_780  7.2571167924583824e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_469  1
    load_0_3_0  segment_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_470  -20
    arc_0_3_1  connected_order_arc_471  -13
    arc_0_3_1  in_degree_702  1
    arc_0_3_1  out_degree_715  1
    arc_0_3_1  original_T_including_depot_unload_780  8.7876124407720954e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_470  1
    load_0_3_1  segment_load_conservation_705  -1
    load_0_3_1  segment_prefix_lb_706  1
    load_0_3_1  segment_prefix_ub_707  1
    load_0_3_1  segment_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_472  -20
    arc_0_3_2  connected_order_arc_473  -13
    arc_0_3_2  in_degree_709  1
    arc_0_3_2  out_degree_715  1
    arc_0_3_2  original_T_including_depot_unload_780  2.1481294511470344e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_472  1
    load_0_3_2  segment_load_conservation_712  -1
    load_0_3_2  segment_prefix_lb_713  1
    load_0_3_2  segment_prefix_ub_714  1
    load_0_3_2  segment_load_conservation_719  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_474  -20
    arc_0_3_4  connected_order_arc_475  -13
    arc_0_3_4  out_degree_715  1
    arc_0_3_4  in_degree_723  1
    arc_0_3_4  original_T_including_depot_unload_780  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_474  1
    load_0_3_4  segment_load_conservation_719  1
    load_0_3_4  segment_load_conservation_726  -1
    load_0_3_4  segment_prefix_lb_727  1
    load_0_3_4  segment_prefix_ub_728  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_476  -20
    arc_0_3_12  connected_order_arc_477  -13
    arc_0_3_12  out_degree_715  1
    arc_0_3_12  in_degree_730  1
    arc_0_3_12  original_T_including_depot_unload_780  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_476  1
    load_0_3_12  segment_load_conservation_719  1
    load_0_3_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_478  -20
    arc_0_3_13  connected_order_arc_479  -13
    arc_0_3_13  out_degree_715  1
    arc_0_3_13  in_degree_736  1
    arc_0_3_13  original_T_including_depot_unload_780  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_478  1
    load_0_3_13  segment_load_conservation_719  1
    load_0_3_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_480  -20
    arc_0_3_14  connected_order_arc_481  -13
    arc_0_3_14  out_degree_715  1
    arc_0_3_14  in_degree_742  1
    arc_0_3_14  original_T_including_depot_unload_780  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_480  1
    load_0_3_14  segment_load_conservation_719  1
    load_0_3_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_482  -20
    arc_0_3_15  connected_order_arc_483  -13
    arc_0_3_15  out_degree_715  1
    arc_0_3_15  in_degree_748  1
    arc_0_3_15  original_T_including_depot_unload_780  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_482  1
    load_0_3_15  segment_load_conservation_719  1
    load_0_3_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_484  -20
    arc_0_3_16  connected_order_arc_485  -13
    arc_0_3_16  out_degree_715  1
    arc_0_3_16  in_degree_754  1
    arc_0_3_16  original_T_including_depot_unload_780  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_484  1
    load_0_3_16  segment_load_conservation_719  1
    load_0_3_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_486  -20
    arc_0_3_17  connected_order_arc_487  -13
    arc_0_3_17  out_degree_715  1
    arc_0_3_17  in_degree_760  1
    arc_0_3_17  original_T_including_depot_unload_780  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_486  1
    load_0_3_17  segment_load_conservation_719  1
    load_0_3_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_488  -20
    arc_0_3_18  connected_order_arc_489  -13
    arc_0_3_18  out_degree_715  1
    arc_0_3_18  in_degree_766  1
    arc_0_3_18  original_T_including_depot_unload_780  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_488  1
    load_0_3_18  segment_load_conservation_719  1
    load_0_3_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_490  -20
    arc_0_3_19  connected_order_arc_491  -13
    arc_0_3_19  out_degree_715  1
    arc_0_3_19  in_degree_772  1
    arc_0_3_19  original_T_including_depot_unload_780  1.9321899152907124e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_490  1
    load_0_3_19  segment_load_conservation_719  1
    load_0_3_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_492  -20
    arc_0_4_0  depot_return_or_bypass_700  1
    arc_0_4_0  out_degree_722  1
    arc_0_4_0  original_T_including_depot_unload_780  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_492  1
    load_0_4_0  segment_load_conservation_726  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_493  -20
    arc_0_4_1  connected_order_arc_494  -13
    arc_0_4_1  in_degree_702  1
    arc_0_4_1  out_degree_722  1
    arc_0_4_1  original_T_including_depot_unload_780  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_493  1
    load_0_4_1  segment_load_conservation_705  -1
    load_0_4_1  segment_prefix_lb_706  1
    load_0_4_1  segment_prefix_ub_707  1
    load_0_4_1  segment_load_conservation_726  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_495  -20
    arc_0_4_2  connected_order_arc_496  -13
    arc_0_4_2  in_degree_709  1
    arc_0_4_2  out_degree_722  1
    arc_0_4_2  original_T_including_depot_unload_780  2.9706418113632907e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_495  1
    load_0_4_2  segment_load_conservation_712  -1
    load_0_4_2  segment_prefix_lb_713  1
    load_0_4_2  segment_prefix_ub_714  1
    load_0_4_2  segment_load_conservation_726  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_497  -20
    arc_0_4_3  connected_order_arc_498  -13
    arc_0_4_3  in_degree_716  1
    arc_0_4_3  out_degree_722  1
    arc_0_4_3  original_T_including_depot_unload_780  3.0055050459786975e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_497  1
    load_0_4_3  segment_load_conservation_719  -1
    load_0_4_3  segment_prefix_lb_720  1
    load_0_4_3  segment_prefix_ub_721  1
    load_0_4_3  segment_load_conservation_726  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_499  -20
    arc_0_4_12  connected_order_arc_500  -13
    arc_0_4_12  out_degree_722  1
    arc_0_4_12  in_degree_730  1
    arc_0_4_12  original_T_including_depot_unload_780  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_499  1
    load_0_4_12  segment_load_conservation_726  1
    load_0_4_12  free_load_conservation_734  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_501  -20
    arc_0_4_13  connected_order_arc_502  -13
    arc_0_4_13  out_degree_722  1
    arc_0_4_13  in_degree_736  1
    arc_0_4_13  original_T_including_depot_unload_780  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_501  1
    load_0_4_13  segment_load_conservation_726  1
    load_0_4_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_503  -20
    arc_0_4_14  connected_order_arc_504  -13
    arc_0_4_14  out_degree_722  1
    arc_0_4_14  in_degree_742  1
    arc_0_4_14  original_T_including_depot_unload_780  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_503  1
    load_0_4_14  segment_load_conservation_726  1
    load_0_4_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_505  -20
    arc_0_4_15  connected_order_arc_506  -13
    arc_0_4_15  out_degree_722  1
    arc_0_4_15  in_degree_748  1
    arc_0_4_15  original_T_including_depot_unload_780  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_505  1
    load_0_4_15  segment_load_conservation_726  1
    load_0_4_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_507  -20
    arc_0_4_16  connected_order_arc_508  -13
    arc_0_4_16  out_degree_722  1
    arc_0_4_16  in_degree_754  1
    arc_0_4_16  original_T_including_depot_unload_780  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_507  1
    load_0_4_16  segment_load_conservation_726  1
    load_0_4_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_509  -20
    arc_0_4_17  connected_order_arc_510  -13
    arc_0_4_17  out_degree_722  1
    arc_0_4_17  in_degree_760  1
    arc_0_4_17  original_T_including_depot_unload_780  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_509  1
    load_0_4_17  segment_load_conservation_726  1
    load_0_4_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_511  -20
    arc_0_4_18  connected_order_arc_512  -13
    arc_0_4_18  out_degree_722  1
    arc_0_4_18  in_degree_766  1
    arc_0_4_18  original_T_including_depot_unload_780  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_511  1
    load_0_4_18  segment_load_conservation_726  1
    load_0_4_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_513  -20
    arc_0_4_19  connected_order_arc_514  -13
    arc_0_4_19  out_degree_722  1
    arc_0_4_19  in_degree_772  1
    arc_0_4_19  original_T_including_depot_unload_780  1.6320542581729912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_513  1
    load_0_4_19  segment_load_conservation_726  1
    load_0_4_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_515  -20
    arc_0_12_0  depot_return_or_bypass_700  1
    arc_0_12_0  out_degree_729  1
    arc_0_12_0  original_T_including_depot_unload_780  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_515  1
    load_0_12_0  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_516  -20
    arc_0_12_1  connected_order_arc_517  -13
    arc_0_12_1  in_degree_702  1
    arc_0_12_1  out_degree_729  1
    arc_0_12_1  original_T_including_depot_unload_780  1.0170488276971105e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_516  1
    load_0_12_1  segment_load_conservation_705  -1
    load_0_12_1  segment_prefix_lb_706  1
    load_0_12_1  segment_prefix_ub_707  1
    load_0_12_1  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_518  -20
    arc_0_12_2  connected_order_arc_519  -13
    arc_0_12_2  in_degree_709  1
    arc_0_12_2  out_degree_729  1
    arc_0_12_2  original_T_including_depot_unload_780  1.4171530684324468e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_518  1
    load_0_12_2  segment_load_conservation_712  -1
    load_0_12_2  segment_prefix_lb_713  1
    load_0_12_2  segment_prefix_ub_714  1
    load_0_12_2  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_520  -20
    arc_0_12_3  connected_order_arc_521  -13
    arc_0_12_3  in_degree_716  1
    arc_0_12_3  out_degree_729  1
    arc_0_12_3  original_T_including_depot_unload_780  1.4725441282427828e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_520  1
    load_0_12_3  segment_load_conservation_719  -1
    load_0_12_3  segment_prefix_lb_720  1
    load_0_12_3  segment_prefix_ub_721  1
    load_0_12_3  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_522  -20
    arc_0_12_4  connected_order_arc_523  -13
    arc_0_12_4  in_degree_723  1
    arc_0_12_4  out_degree_729  1
    arc_0_12_4  original_T_including_depot_unload_780  1.1724800521319269e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_522  1
    load_0_12_4  segment_load_conservation_726  -1
    load_0_12_4  segment_prefix_lb_727  1
    load_0_12_4  segment_prefix_ub_728  1
    load_0_12_4  free_load_conservation_734  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_524  -20
    arc_0_12_13  connected_order_arc_525  -13
    arc_0_12_13  out_degree_729  1
    arc_0_12_13  in_degree_736  1
    arc_0_12_13  original_T_including_depot_unload_780  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_524  1
    load_0_12_13  free_load_conservation_734  1
    load_0_12_13  free_load_conservation_740  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_526  -20
    arc_0_12_14  connected_order_arc_527  -13
    arc_0_12_14  out_degree_729  1
    arc_0_12_14  in_degree_742  1
    arc_0_12_14  original_T_including_depot_unload_780  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_526  1
    load_0_12_14  free_load_conservation_734  1
    load_0_12_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_528  -20
    arc_0_12_15  connected_order_arc_529  -13
    arc_0_12_15  out_degree_729  1
    arc_0_12_15  in_degree_748  1
    arc_0_12_15  original_T_including_depot_unload_780  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_528  1
    load_0_12_15  free_load_conservation_734  1
    load_0_12_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_16  arc_capacity_530  -20
    arc_0_12_16  connected_order_arc_531  -13
    arc_0_12_16  out_degree_729  1
    arc_0_12_16  in_degree_754  1
    arc_0_12_16  original_T_including_depot_unload_780  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_16  arc_capacity_530  1
    load_0_12_16  free_load_conservation_734  1
    load_0_12_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_17  arc_capacity_532  -20
    arc_0_12_17  connected_order_arc_533  -13
    arc_0_12_17  out_degree_729  1
    arc_0_12_17  in_degree_760  1
    arc_0_12_17  original_T_including_depot_unload_780  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_17  arc_capacity_532  1
    load_0_12_17  free_load_conservation_734  1
    load_0_12_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_18  arc_capacity_534  -20
    arc_0_12_18  connected_order_arc_535  -13
    arc_0_12_18  out_degree_729  1
    arc_0_12_18  in_degree_766  1
    arc_0_12_18  original_T_including_depot_unload_780  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_18  arc_capacity_534  1
    load_0_12_18  free_load_conservation_734  1
    load_0_12_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_19  arc_capacity_536  -20
    arc_0_12_19  connected_order_arc_537  -13
    arc_0_12_19  out_degree_729  1
    arc_0_12_19  in_degree_772  1
    arc_0_12_19  original_T_including_depot_unload_780  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_12_19  arc_capacity_536  1
    load_0_12_19  free_load_conservation_734  1
    load_0_12_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_538  -20
    arc_0_13_0  depot_return_or_bypass_700  1
    arc_0_13_0  out_degree_735  1
    arc_0_13_0  original_T_including_depot_unload_780  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_538  1
    load_0_13_0  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_539  -20
    arc_0_13_1  connected_order_arc_540  -13
    arc_0_13_1  in_degree_702  1
    arc_0_13_1  out_degree_735  1
    arc_0_13_1  original_T_including_depot_unload_780  1.1190931627527086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_539  1
    load_0_13_1  segment_load_conservation_705  -1
    load_0_13_1  segment_prefix_lb_706  1
    load_0_13_1  segment_prefix_ub_707  1
    load_0_13_1  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_541  -20
    arc_0_13_2  connected_order_arc_542  -13
    arc_0_13_2  in_degree_709  1
    arc_0_13_2  out_degree_735  1
    arc_0_13_2  original_T_including_depot_unload_780  1.5657515083159024e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_541  1
    load_0_13_2  segment_load_conservation_712  -1
    load_0_13_2  segment_prefix_lb_713  1
    load_0_13_2  segment_prefix_ub_714  1
    load_0_13_2  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_543  -20
    arc_0_13_3  connected_order_arc_544  -13
    arc_0_13_3  in_degree_716  1
    arc_0_13_3  out_degree_735  1
    arc_0_13_3  original_T_including_depot_unload_780  1.6299527591666472e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_543  1
    load_0_13_3  segment_load_conservation_719  -1
    load_0_13_3  segment_prefix_lb_720  1
    load_0_13_3  segment_prefix_ub_721  1
    load_0_13_3  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_545  -20
    arc_0_13_4  connected_order_arc_546  -13
    arc_0_13_4  in_degree_723  1
    arc_0_13_4  out_degree_735  1
    arc_0_13_4  original_T_including_depot_unload_780  1.3294477435531232e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_545  1
    load_0_13_4  segment_load_conservation_726  -1
    load_0_13_4  segment_prefix_lb_727  1
    load_0_13_4  segment_prefix_ub_728  1
    load_0_13_4  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_547  -20
    arc_0_13_12  connected_order_arc_548  -13
    arc_0_13_12  in_degree_730  1
    arc_0_13_12  out_degree_735  1
    arc_0_13_12  original_T_including_depot_unload_780  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_547  1
    load_0_13_12  free_load_conservation_734  -1
    load_0_13_12  free_load_conservation_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_549  -20
    arc_0_13_14  connected_order_arc_550  -13
    arc_0_13_14  out_degree_735  1
    arc_0_13_14  in_degree_742  1
    arc_0_13_14  original_T_including_depot_unload_780  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_549  1
    load_0_13_14  free_load_conservation_740  1
    load_0_13_14  free_load_conservation_746  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_551  -20
    arc_0_13_15  connected_order_arc_552  -13
    arc_0_13_15  out_degree_735  1
    arc_0_13_15  in_degree_748  1
    arc_0_13_15  original_T_including_depot_unload_780  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_551  1
    load_0_13_15  free_load_conservation_740  1
    load_0_13_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_16  arc_capacity_553  -20
    arc_0_13_16  connected_order_arc_554  -13
    arc_0_13_16  out_degree_735  1
    arc_0_13_16  in_degree_754  1
    arc_0_13_16  original_T_including_depot_unload_780  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_16  arc_capacity_553  1
    load_0_13_16  free_load_conservation_740  1
    load_0_13_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_17  arc_capacity_555  -20
    arc_0_13_17  connected_order_arc_556  -13
    arc_0_13_17  out_degree_735  1
    arc_0_13_17  in_degree_760  1
    arc_0_13_17  original_T_including_depot_unload_780  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_17  arc_capacity_555  1
    load_0_13_17  free_load_conservation_740  1
    load_0_13_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_18  arc_capacity_557  -20
    arc_0_13_18  connected_order_arc_558  -13
    arc_0_13_18  out_degree_735  1
    arc_0_13_18  in_degree_766  1
    arc_0_13_18  original_T_including_depot_unload_780  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_18  arc_capacity_557  1
    load_0_13_18  free_load_conservation_740  1
    load_0_13_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_19  arc_capacity_559  -20
    arc_0_13_19  connected_order_arc_560  -13
    arc_0_13_19  out_degree_735  1
    arc_0_13_19  in_degree_772  1
    arc_0_13_19  original_T_including_depot_unload_780  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_19  arc_capacity_559  1
    load_0_13_19  free_load_conservation_740  1
    load_0_13_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_561  -20
    arc_0_14_0  depot_return_or_bypass_700  1
    arc_0_14_0  out_degree_741  1
    arc_0_14_0  original_T_including_depot_unload_780  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_561  1
    load_0_14_0  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_562  -20
    arc_0_14_1  connected_order_arc_563  -13
    arc_0_14_1  in_degree_702  1
    arc_0_14_1  out_degree_741  1
    arc_0_14_1  original_T_including_depot_unload_780  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_562  1
    load_0_14_1  segment_load_conservation_705  -1
    load_0_14_1  segment_prefix_lb_706  1
    load_0_14_1  segment_prefix_ub_707  1
    load_0_14_1  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_564  -20
    arc_0_14_2  connected_order_arc_565  -13
    arc_0_14_2  in_degree_709  1
    arc_0_14_2  out_degree_741  1
    arc_0_14_2  original_T_including_depot_unload_780  1.3727638439182763e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_564  1
    load_0_14_2  segment_load_conservation_712  -1
    load_0_14_2  segment_prefix_lb_713  1
    load_0_14_2  segment_prefix_ub_714  1
    load_0_14_2  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_566  -20
    arc_0_14_3  connected_order_arc_567  -13
    arc_0_14_3  in_degree_716  1
    arc_0_14_3  out_degree_741  1
    arc_0_14_3  original_T_including_depot_unload_780  1.3163662834239574e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_566  1
    load_0_14_3  segment_load_conservation_719  -1
    load_0_14_3  segment_prefix_lb_720  1
    load_0_14_3  segment_prefix_ub_721  1
    load_0_14_3  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_568  -20
    arc_0_14_4  connected_order_arc_569  -13
    arc_0_14_4  in_degree_723  1
    arc_0_14_4  out_degree_741  1
    arc_0_14_4  original_T_including_depot_unload_780  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_568  1
    load_0_14_4  segment_load_conservation_726  -1
    load_0_14_4  segment_prefix_lb_727  1
    load_0_14_4  segment_prefix_ub_728  1
    load_0_14_4  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_570  -20
    arc_0_14_12  connected_order_arc_571  -13
    arc_0_14_12  in_degree_730  1
    arc_0_14_12  out_degree_741  1
    arc_0_14_12  original_T_including_depot_unload_780  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_570  1
    load_0_14_12  free_load_conservation_734  -1
    load_0_14_12  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_572  -20
    arc_0_14_13  connected_order_arc_573  -13
    arc_0_14_13  in_degree_736  1
    arc_0_14_13  out_degree_741  1
    arc_0_14_13  original_T_including_depot_unload_780  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_572  1
    load_0_14_13  free_load_conservation_740  -1
    load_0_14_13  free_load_conservation_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_574  -20
    arc_0_14_15  connected_order_arc_575  -13
    arc_0_14_15  out_degree_741  1
    arc_0_14_15  in_degree_748  1
    arc_0_14_15  original_T_including_depot_unload_780  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_574  1
    load_0_14_15  free_load_conservation_746  1
    load_0_14_15  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_576  -20
    arc_0_14_16  connected_order_arc_577  -13
    arc_0_14_16  out_degree_741  1
    arc_0_14_16  in_degree_754  1
    arc_0_14_16  original_T_including_depot_unload_780  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_576  1
    load_0_14_16  free_load_conservation_746  1
    load_0_14_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_578  -20
    arc_0_14_17  connected_order_arc_579  -13
    arc_0_14_17  out_degree_741  1
    arc_0_14_17  in_degree_760  1
    arc_0_14_17  original_T_including_depot_unload_780  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_578  1
    load_0_14_17  free_load_conservation_746  1
    load_0_14_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_580  -20
    arc_0_14_18  connected_order_arc_581  -13
    arc_0_14_18  out_degree_741  1
    arc_0_14_18  in_degree_766  1
    arc_0_14_18  original_T_including_depot_unload_780  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_580  1
    load_0_14_18  free_load_conservation_746  1
    load_0_14_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_582  -20
    arc_0_14_19  connected_order_arc_583  -13
    arc_0_14_19  out_degree_741  1
    arc_0_14_19  in_degree_772  1
    arc_0_14_19  original_T_including_depot_unload_780  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_582  1
    load_0_14_19  free_load_conservation_746  1
    load_0_14_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_584  -20
    arc_0_15_0  depot_return_or_bypass_700  1
    arc_0_15_0  out_degree_747  1
    arc_0_15_0  original_T_including_depot_unload_780  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_584  1
    load_0_15_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_585  -20
    arc_0_15_1  connected_order_arc_586  -13
    arc_0_15_1  in_degree_702  1
    arc_0_15_1  out_degree_747  1
    arc_0_15_1  original_T_including_depot_unload_780  1.2336637947519732e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_585  1
    load_0_15_1  segment_load_conservation_705  -1
    load_0_15_1  segment_prefix_lb_706  1
    load_0_15_1  segment_prefix_ub_707  1
    load_0_15_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_587  -20
    arc_0_15_2  connected_order_arc_588  -13
    arc_0_15_2  in_degree_709  1
    arc_0_15_2  out_degree_747  1
    arc_0_15_2  original_T_including_depot_unload_780  1.5230377993795889e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_587  1
    load_0_15_2  segment_load_conservation_712  -1
    load_0_15_2  segment_prefix_lb_713  1
    load_0_15_2  segment_prefix_ub_714  1
    load_0_15_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_589  -20
    arc_0_15_3  connected_order_arc_590  -13
    arc_0_15_3  in_degree_716  1
    arc_0_15_3  out_degree_747  1
    arc_0_15_3  original_T_including_depot_unload_780  1.5393972350798747e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_589  1
    load_0_15_3  segment_load_conservation_719  -1
    load_0_15_3  segment_prefix_lb_720  1
    load_0_15_3  segment_prefix_ub_721  1
    load_0_15_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_591  -20
    arc_0_15_4  connected_order_arc_592  -13
    arc_0_15_4  in_degree_723  1
    arc_0_15_4  out_degree_747  1
    arc_0_15_4  original_T_including_depot_unload_780  1.2492199513695298e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_591  1
    load_0_15_4  segment_load_conservation_726  -1
    load_0_15_4  segment_prefix_lb_727  1
    load_0_15_4  segment_prefix_ub_728  1
    load_0_15_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_593  -20
    arc_0_15_12  connected_order_arc_594  -13
    arc_0_15_12  in_degree_730  1
    arc_0_15_12  out_degree_747  1
    arc_0_15_12  original_T_including_depot_unload_780  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_593  1
    load_0_15_12  free_load_conservation_734  -1
    load_0_15_12  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_595  -20
    arc_0_15_13  connected_order_arc_596  -13
    arc_0_15_13  in_degree_736  1
    arc_0_15_13  out_degree_747  1
    arc_0_15_13  original_T_including_depot_unload_780  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_595  1
    load_0_15_13  free_load_conservation_740  -1
    load_0_15_13  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_597  -20
    arc_0_15_14  connected_order_arc_598  -13
    arc_0_15_14  in_degree_742  1
    arc_0_15_14  out_degree_747  1
    arc_0_15_14  original_T_including_depot_unload_780  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_597  1
    load_0_15_14  free_load_conservation_746  -1
    load_0_15_14  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_599  -20
    arc_0_15_16  connected_order_arc_600  -13
    arc_0_15_16  out_degree_747  1
    arc_0_15_16  in_degree_754  1
    arc_0_15_16  original_T_including_depot_unload_780  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_599  1
    load_0_15_16  free_load_conservation_752  1
    load_0_15_16  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_601  -20
    arc_0_15_17  connected_order_arc_602  -13
    arc_0_15_17  out_degree_747  1
    arc_0_15_17  in_degree_760  1
    arc_0_15_17  original_T_including_depot_unload_780  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_601  1
    load_0_15_17  free_load_conservation_752  1
    load_0_15_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_603  -20
    arc_0_15_18  connected_order_arc_604  -13
    arc_0_15_18  out_degree_747  1
    arc_0_15_18  in_degree_766  1
    arc_0_15_18  original_T_including_depot_unload_780  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_603  1
    load_0_15_18  free_load_conservation_752  1
    load_0_15_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_605  -20
    arc_0_15_19  connected_order_arc_606  -13
    arc_0_15_19  out_degree_747  1
    arc_0_15_19  in_degree_772  1
    arc_0_15_19  original_T_including_depot_unload_780  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_605  1
    load_0_15_19  free_load_conservation_752  1
    load_0_15_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_607  -20
    arc_0_16_0  depot_return_or_bypass_700  1
    arc_0_16_0  out_degree_753  1
    arc_0_16_0  original_T_including_depot_unload_780  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_607  1
    load_0_16_0  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_608  -20
    arc_0_16_1  connected_order_arc_609  -13
    arc_0_16_1  in_degree_702  1
    arc_0_16_1  out_degree_753  1
    arc_0_16_1  original_T_including_depot_unload_780  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_608  1
    load_0_16_1  segment_load_conservation_705  -1
    load_0_16_1  segment_prefix_lb_706  1
    load_0_16_1  segment_prefix_ub_707  1
    load_0_16_1  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_610  -20
    arc_0_16_2  connected_order_arc_611  -13
    arc_0_16_2  in_degree_709  1
    arc_0_16_2  out_degree_753  1
    arc_0_16_2  original_T_including_depot_unload_780  9.8652191996938075e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_610  1
    load_0_16_2  segment_load_conservation_712  -1
    load_0_16_2  segment_prefix_lb_713  1
    load_0_16_2  segment_prefix_ub_714  1
    load_0_16_2  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_612  -20
    arc_0_16_3  connected_order_arc_613  -13
    arc_0_16_3  in_degree_716  1
    arc_0_16_3  out_degree_753  1
    arc_0_16_3  original_T_including_depot_unload_780  7.7190219995954919e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_612  1
    load_0_16_3  segment_load_conservation_719  -1
    load_0_16_3  segment_prefix_lb_720  1
    load_0_16_3  segment_prefix_ub_721  1
    load_0_16_3  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_614  -20
    arc_0_16_4  connected_order_arc_615  -13
    arc_0_16_4  in_degree_723  1
    arc_0_16_4  out_degree_753  1
    arc_0_16_4  original_T_including_depot_unload_780  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_614  1
    load_0_16_4  segment_load_conservation_726  -1
    load_0_16_4  segment_prefix_lb_727  1
    load_0_16_4  segment_prefix_ub_728  1
    load_0_16_4  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_12  arc_capacity_616  -20
    arc_0_16_12  connected_order_arc_617  -13
    arc_0_16_12  in_degree_730  1
    arc_0_16_12  out_degree_753  1
    arc_0_16_12  original_T_including_depot_unload_780  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_12  arc_capacity_616  1
    load_0_16_12  free_load_conservation_734  -1
    load_0_16_12  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_13  arc_capacity_618  -20
    arc_0_16_13  connected_order_arc_619  -13
    arc_0_16_13  in_degree_736  1
    arc_0_16_13  out_degree_753  1
    arc_0_16_13  original_T_including_depot_unload_780  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_13  arc_capacity_618  1
    load_0_16_13  free_load_conservation_740  -1
    load_0_16_13  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_620  -20
    arc_0_16_14  connected_order_arc_621  -13
    arc_0_16_14  in_degree_742  1
    arc_0_16_14  out_degree_753  1
    arc_0_16_14  original_T_including_depot_unload_780  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_620  1
    load_0_16_14  free_load_conservation_746  -1
    load_0_16_14  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_622  -20
    arc_0_16_15  connected_order_arc_623  -13
    arc_0_16_15  in_degree_748  1
    arc_0_16_15  out_degree_753  1
    arc_0_16_15  original_T_including_depot_unload_780  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_622  1
    load_0_16_15  free_load_conservation_752  -1
    load_0_16_15  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_624  -20
    arc_0_16_17  connected_order_arc_625  -13
    arc_0_16_17  out_degree_753  1
    arc_0_16_17  in_degree_760  1
    arc_0_16_17  original_T_including_depot_unload_780  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_624  1
    load_0_16_17  free_load_conservation_758  1
    load_0_16_17  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_626  -20
    arc_0_16_18  connected_order_arc_627  -13
    arc_0_16_18  out_degree_753  1
    arc_0_16_18  in_degree_766  1
    arc_0_16_18  original_T_including_depot_unload_780  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_626  1
    load_0_16_18  free_load_conservation_758  1
    load_0_16_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_628  -20
    arc_0_16_19  connected_order_arc_629  -13
    arc_0_16_19  out_degree_753  1
    arc_0_16_19  in_degree_772  1
    arc_0_16_19  original_T_including_depot_unload_780  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_628  1
    load_0_16_19  free_load_conservation_758  1
    load_0_16_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_630  -20
    arc_0_17_0  depot_return_or_bypass_700  1
    arc_0_17_0  out_degree_759  1
    arc_0_17_0  original_T_including_depot_unload_780  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_630  1
    load_0_17_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_631  -20
    arc_0_17_1  connected_order_arc_632  -13
    arc_0_17_1  in_degree_702  1
    arc_0_17_1  out_degree_759  1
    arc_0_17_1  original_T_including_depot_unload_780  1.0988088346747072e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_631  1
    load_0_17_1  segment_load_conservation_705  -1
    load_0_17_1  segment_prefix_lb_706  1
    load_0_17_1  segment_prefix_ub_707  1
    load_0_17_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_633  -20
    arc_0_17_2  connected_order_arc_634  -13
    arc_0_17_2  in_degree_709  1
    arc_0_17_2  out_degree_759  1
    arc_0_17_2  original_T_including_depot_unload_780  1.3070841601346692e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_633  1
    load_0_17_2  segment_load_conservation_712  -1
    load_0_17_2  segment_prefix_lb_713  1
    load_0_17_2  segment_prefix_ub_714  1
    load_0_17_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_635  -20
    arc_0_17_3  connected_order_arc_636  -13
    arc_0_17_3  in_degree_716  1
    arc_0_17_3  out_degree_759  1
    arc_0_17_3  original_T_including_depot_unload_780  1.3095620674514091e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_635  1
    load_0_17_3  segment_load_conservation_719  -1
    load_0_17_3  segment_prefix_lb_720  1
    load_0_17_3  segment_prefix_ub_721  1
    load_0_17_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_637  -20
    arc_0_17_4  connected_order_arc_638  -13
    arc_0_17_4  in_degree_723  1
    arc_0_17_4  out_degree_759  1
    arc_0_17_4  original_T_including_depot_unload_780  1.0250717569202773e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_637  1
    load_0_17_4  segment_load_conservation_726  -1
    load_0_17_4  segment_prefix_lb_727  1
    load_0_17_4  segment_prefix_ub_728  1
    load_0_17_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_12  arc_capacity_639  -20
    arc_0_17_12  connected_order_arc_640  -13
    arc_0_17_12  in_degree_730  1
    arc_0_17_12  out_degree_759  1
    arc_0_17_12  original_T_including_depot_unload_780  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_12  arc_capacity_639  1
    load_0_17_12  free_load_conservation_734  -1
    load_0_17_12  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_13  arc_capacity_641  -20
    arc_0_17_13  connected_order_arc_642  -13
    arc_0_17_13  in_degree_736  1
    arc_0_17_13  out_degree_759  1
    arc_0_17_13  original_T_including_depot_unload_780  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_13  arc_capacity_641  1
    load_0_17_13  free_load_conservation_740  -1
    load_0_17_13  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_643  -20
    arc_0_17_14  connected_order_arc_644  -13
    arc_0_17_14  in_degree_742  1
    arc_0_17_14  out_degree_759  1
    arc_0_17_14  original_T_including_depot_unload_780  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_643  1
    load_0_17_14  free_load_conservation_746  -1
    load_0_17_14  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_645  -20
    arc_0_17_15  connected_order_arc_646  -13
    arc_0_17_15  in_degree_748  1
    arc_0_17_15  out_degree_759  1
    arc_0_17_15  original_T_including_depot_unload_780  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_645  1
    load_0_17_15  free_load_conservation_752  -1
    load_0_17_15  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_647  -20
    arc_0_17_16  connected_order_arc_648  -13
    arc_0_17_16  in_degree_754  1
    arc_0_17_16  out_degree_759  1
    arc_0_17_16  original_T_including_depot_unload_780  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_647  1
    load_0_17_16  free_load_conservation_758  -1
    load_0_17_16  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_649  -20
    arc_0_17_18  connected_order_arc_650  -13
    arc_0_17_18  out_degree_759  1
    arc_0_17_18  in_degree_766  1
    arc_0_17_18  original_T_including_depot_unload_780  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_649  1
    load_0_17_18  free_load_conservation_764  1
    load_0_17_18  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_651  -20
    arc_0_17_19  connected_order_arc_652  -13
    arc_0_17_19  out_degree_759  1
    arc_0_17_19  in_degree_772  1
    arc_0_17_19  original_T_including_depot_unload_780  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_651  1
    load_0_17_19  free_load_conservation_764  1
    load_0_17_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_653  -20
    arc_0_18_0  depot_return_or_bypass_700  1
    arc_0_18_0  out_degree_765  1
    arc_0_18_0  original_T_including_depot_unload_780  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_653  1
    load_0_18_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_654  -20
    arc_0_18_1  connected_order_arc_655  -13
    arc_0_18_1  in_degree_702  1
    arc_0_18_1  out_degree_765  1
    arc_0_18_1  original_T_including_depot_unload_780  9.3905252655669165e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_654  1
    load_0_18_1  segment_load_conservation_705  -1
    load_0_18_1  segment_prefix_lb_706  1
    load_0_18_1  segment_prefix_ub_707  1
    load_0_18_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_656  -20
    arc_0_18_2  connected_order_arc_657  -13
    arc_0_18_2  in_degree_709  1
    arc_0_18_2  out_degree_765  1
    arc_0_18_2  original_T_including_depot_unload_780  3.9766425523492148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_656  1
    load_0_18_2  segment_load_conservation_712  -1
    load_0_18_2  segment_prefix_lb_713  1
    load_0_18_2  segment_prefix_ub_714  1
    load_0_18_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_658  -20
    arc_0_18_3  connected_order_arc_659  -13
    arc_0_18_3  in_degree_716  1
    arc_0_18_3  out_degree_765  1
    arc_0_18_3  original_T_including_depot_unload_780  2.3059951477332697e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_658  1
    load_0_18_3  segment_load_conservation_719  -1
    load_0_18_3  segment_prefix_lb_720  1
    load_0_18_3  segment_prefix_ub_721  1
    load_0_18_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_660  -20
    arc_0_18_4  connected_order_arc_661  -13
    arc_0_18_4  in_degree_723  1
    arc_0_18_4  out_degree_765  1
    arc_0_18_4  original_T_including_depot_unload_780  2.6602972191926557e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_660  1
    load_0_18_4  segment_load_conservation_726  -1
    load_0_18_4  segment_prefix_lb_727  1
    load_0_18_4  segment_prefix_ub_728  1
    load_0_18_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_12  arc_capacity_662  -20
    arc_0_18_12  connected_order_arc_663  -13
    arc_0_18_12  in_degree_730  1
    arc_0_18_12  out_degree_765  1
    arc_0_18_12  original_T_including_depot_unload_780  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_12  arc_capacity_662  1
    load_0_18_12  free_load_conservation_734  -1
    load_0_18_12  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_13  arc_capacity_664  -20
    arc_0_18_13  connected_order_arc_665  -13
    arc_0_18_13  in_degree_736  1
    arc_0_18_13  out_degree_765  1
    arc_0_18_13  original_T_including_depot_unload_780  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_13  arc_capacity_664  1
    load_0_18_13  free_load_conservation_740  -1
    load_0_18_13  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_666  -20
    arc_0_18_14  connected_order_arc_667  -13
    arc_0_18_14  in_degree_742  1
    arc_0_18_14  out_degree_765  1
    arc_0_18_14  original_T_including_depot_unload_780  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_666  1
    load_0_18_14  free_load_conservation_746  -1
    load_0_18_14  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_668  -20
    arc_0_18_15  connected_order_arc_669  -13
    arc_0_18_15  in_degree_748  1
    arc_0_18_15  out_degree_765  1
    arc_0_18_15  original_T_including_depot_unload_780  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_668  1
    load_0_18_15  free_load_conservation_752  -1
    load_0_18_15  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_670  -20
    arc_0_18_16  connected_order_arc_671  -13
    arc_0_18_16  in_degree_754  1
    arc_0_18_16  out_degree_765  1
    arc_0_18_16  original_T_including_depot_unload_780  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_670  1
    load_0_18_16  free_load_conservation_758  -1
    load_0_18_16  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_672  -20
    arc_0_18_17  connected_order_arc_673  -13
    arc_0_18_17  in_degree_760  1
    arc_0_18_17  out_degree_765  1
    arc_0_18_17  original_T_including_depot_unload_780  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_672  1
    load_0_18_17  free_load_conservation_764  -1
    load_0_18_17  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_674  -20
    arc_0_18_19  connected_order_arc_675  -13
    arc_0_18_19  out_degree_765  1
    arc_0_18_19  in_degree_772  1
    arc_0_18_19  original_T_including_depot_unload_780  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_674  1
    load_0_18_19  free_load_conservation_770  1
    load_0_18_19  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_676  -20
    arc_0_19_0  depot_return_or_bypass_700  1
    arc_0_19_0  out_degree_771  1
    arc_0_19_0  original_T_including_depot_unload_780  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_676  1
    load_0_19_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_677  -20
    arc_0_19_1  connected_order_arc_678  -13
    arc_0_19_1  in_degree_702  1
    arc_0_19_1  out_degree_771  1
    arc_0_19_1  original_T_including_depot_unload_780  1337.70453645659
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_677  1
    load_0_19_1  segment_load_conservation_705  -1
    load_0_19_1  segment_prefix_lb_706  1
    load_0_19_1  segment_prefix_ub_707  1
    load_0_19_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_679  -20
    arc_0_19_2  connected_order_arc_680  -13
    arc_0_19_2  in_degree_709  1
    arc_0_19_2  out_degree_771  1
    arc_0_19_2  original_T_including_depot_unload_780  1.8527392017187374e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_679  1
    load_0_19_2  segment_load_conservation_712  -1
    load_0_19_2  segment_prefix_lb_713  1
    load_0_19_2  segment_prefix_ub_714  1
    load_0_19_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_681  -20
    arc_0_19_3  connected_order_arc_682  -13
    arc_0_19_3  in_degree_716  1
    arc_0_19_3  out_degree_771  1
    arc_0_19_3  original_T_including_depot_unload_780  1.9321899152907124e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_681  1
    load_0_19_3  segment_load_conservation_719  -1
    load_0_19_3  segment_prefix_lb_720  1
    load_0_19_3  segment_prefix_ub_721  1
    load_0_19_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_683  -20
    arc_0_19_4  connected_order_arc_684  -13
    arc_0_19_4  in_degree_723  1
    arc_0_19_4  out_degree_771  1
    arc_0_19_4  original_T_including_depot_unload_780  1.6320542581729912e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_683  1
    load_0_19_4  segment_load_conservation_726  -1
    load_0_19_4  segment_prefix_lb_727  1
    load_0_19_4  segment_prefix_ub_728  1
    load_0_19_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_12  arc_capacity_685  -20
    arc_0_19_12  connected_order_arc_686  -13
    arc_0_19_12  in_degree_730  1
    arc_0_19_12  out_degree_771  1
    arc_0_19_12  original_T_including_depot_unload_780  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_12  arc_capacity_685  1
    load_0_19_12  free_load_conservation_734  -1
    load_0_19_12  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_13  arc_capacity_687  -20
    arc_0_19_13  connected_order_arc_688  -13
    arc_0_19_13  in_degree_736  1
    arc_0_19_13  out_degree_771  1
    arc_0_19_13  original_T_including_depot_unload_780  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_13  arc_capacity_687  1
    load_0_19_13  free_load_conservation_740  -1
    load_0_19_13  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_689  -20
    arc_0_19_14  connected_order_arc_690  -13
    arc_0_19_14  in_degree_742  1
    arc_0_19_14  out_degree_771  1
    arc_0_19_14  original_T_including_depot_unload_780  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_689  1
    load_0_19_14  free_load_conservation_746  -1
    load_0_19_14  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_691  -20
    arc_0_19_15  connected_order_arc_692  -13
    arc_0_19_15  in_degree_748  1
    arc_0_19_15  out_degree_771  1
    arc_0_19_15  original_T_including_depot_unload_780  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_691  1
    load_0_19_15  free_load_conservation_752  -1
    load_0_19_15  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_693  -20
    arc_0_19_16  connected_order_arc_694  -13
    arc_0_19_16  in_degree_754  1
    arc_0_19_16  out_degree_771  1
    arc_0_19_16  original_T_including_depot_unload_780  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_693  1
    load_0_19_16  free_load_conservation_758  -1
    load_0_19_16  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_695  -20
    arc_0_19_17  connected_order_arc_696  -13
    arc_0_19_17  in_degree_760  1
    arc_0_19_17  out_degree_771  1
    arc_0_19_17  original_T_including_depot_unload_780  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_695  1
    load_0_19_17  free_load_conservation_764  -1
    load_0_19_17  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_697  -20
    arc_0_19_18  connected_order_arc_698  -13
    arc_0_19_18  in_degree_766  1
    arc_0_19_18  out_degree_771  1
    arc_0_19_18  original_T_including_depot_unload_780  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_697  1
    load_0_19_18  free_load_conservation_770  -1
    load_0_19_18  free_load_conservation_776  1
    visit_1_5  out_degree_1072  -1
    visit_1_5  in_degree_1073  -1
    visit_1_5  order_active_lb_1074  -1
    visit_1_5  order_active_ub_1075  -12
    order_1_5  connected_order_arc_796  -1
    order_1_5  connected_order_arc_798  -1
    order_1_5  connected_order_arc_800  -1
    order_1_5  connected_order_arc_802  -1
    order_1_5  connected_order_arc_804  -1
    order_1_5  connected_order_arc_806  -1
    order_1_5  connected_order_arc_808  -1
    order_1_5  connected_order_arc_810  -1
    order_1_5  connected_order_arc_812  -1
    order_1_5  connected_order_arc_814  -1
    order_1_5  connected_order_arc_816  -1
    order_1_5  connected_order_arc_819  1
    order_1_5  connected_order_arc_842  1
    order_1_5  connected_order_arc_865  1
    order_1_5  connected_order_arc_888  1
    order_1_5  connected_order_arc_911  1
    order_1_5  connected_order_arc_934  1
    order_1_5  connected_order_arc_957  1
    order_1_5  connected_order_arc_980  1
    order_1_5  connected_order_arc_1003  1
    order_1_5  connected_order_arc_1026  1
    order_1_5  connected_order_arc_1049  1
    order_1_5  order_active_lb_1074  1
    order_1_5  order_active_ub_1075  1
    order_1_5  fixed_segment_relative_order_1148  -1
    visit_1_6  out_degree_1079  -1
    visit_1_6  in_degree_1080  -1
    visit_1_6  order_active_lb_1081  -1
    visit_1_6  order_active_ub_1082  -12
    order_1_6  connected_order_arc_796  1
    order_1_6  connected_order_arc_819  -1
    order_1_6  connected_order_arc_821  -1
    order_1_6  connected_order_arc_823  -1
    order_1_6  connected_order_arc_825  -1
    order_1_6  connected_order_arc_827  -1
    order_1_6  connected_order_arc_829  -1
    order_1_6  connected_order_arc_831  -1
    order_1_6  connected_order_arc_833  -1
    order_1_6  connected_order_arc_835  -1
    order_1_6  connected_order_arc_837  -1
    order_1_6  connected_order_arc_839  -1
    order_1_6  connected_order_arc_844  1
    order_1_6  connected_order_arc_867  1
    order_1_6  connected_order_arc_890  1
    order_1_6  connected_order_arc_913  1
    order_1_6  connected_order_arc_936  1
    order_1_6  connected_order_arc_959  1
    order_1_6  connected_order_arc_982  1
    order_1_6  connected_order_arc_1005  1
    order_1_6  connected_order_arc_1028  1
    order_1_6  connected_order_arc_1051  1
    order_1_6  order_active_lb_1081  1
    order_1_6  order_active_ub_1082  1
    order_1_6  fixed_segment_relative_order_1148  1
    order_1_6  fixed_segment_relative_order_1149  -1
    visit_1_7  out_degree_1086  -1
    visit_1_7  in_degree_1087  -1
    visit_1_7  order_active_lb_1088  -1
    visit_1_7  order_active_ub_1089  -12
    order_1_7  connected_order_arc_798  1
    order_1_7  connected_order_arc_821  1
    order_1_7  connected_order_arc_842  -1
    order_1_7  connected_order_arc_844  -1
    order_1_7  connected_order_arc_846  -1
    order_1_7  connected_order_arc_848  -1
    order_1_7  connected_order_arc_850  -1
    order_1_7  connected_order_arc_852  -1
    order_1_7  connected_order_arc_854  -1
    order_1_7  connected_order_arc_856  -1
    order_1_7  connected_order_arc_858  -1
    order_1_7  connected_order_arc_860  -1
    order_1_7  connected_order_arc_862  -1
    order_1_7  connected_order_arc_869  1
    order_1_7  connected_order_arc_892  1
    order_1_7  connected_order_arc_915  1
    order_1_7  connected_order_arc_938  1
    order_1_7  connected_order_arc_961  1
    order_1_7  connected_order_arc_984  1
    order_1_7  connected_order_arc_1007  1
    order_1_7  connected_order_arc_1030  1
    order_1_7  connected_order_arc_1053  1
    order_1_7  order_active_lb_1088  1
    order_1_7  order_active_ub_1089  1
    order_1_7  fixed_segment_relative_order_1149  1
    order_1_7  fixed_segment_relative_order_1150  -1
    visit_1_8  out_degree_1093  -1
    visit_1_8  in_degree_1094  -1
    visit_1_8  order_active_lb_1095  -1
    visit_1_8  order_active_ub_1096  -12
    order_1_8  connected_order_arc_800  1
    order_1_8  connected_order_arc_823  1
    order_1_8  connected_order_arc_846  1
    order_1_8  connected_order_arc_865  -1
    order_1_8  connected_order_arc_867  -1
    order_1_8  connected_order_arc_869  -1
    order_1_8  connected_order_arc_871  -1
    order_1_8  connected_order_arc_873  -1
    order_1_8  connected_order_arc_875  -1
    order_1_8  connected_order_arc_877  -1
    order_1_8  connected_order_arc_879  -1
    order_1_8  connected_order_arc_881  -1
    order_1_8  connected_order_arc_883  -1
    order_1_8  connected_order_arc_885  -1
    order_1_8  connected_order_arc_894  1
    order_1_8  connected_order_arc_917  1
    order_1_8  connected_order_arc_940  1
    order_1_8  connected_order_arc_963  1
    order_1_8  connected_order_arc_986  1
    order_1_8  connected_order_arc_1009  1
    order_1_8  connected_order_arc_1032  1
    order_1_8  connected_order_arc_1055  1
    order_1_8  order_active_lb_1095  1
    order_1_8  order_active_ub_1096  1
    order_1_8  fixed_segment_relative_order_1150  1
    visit_1_12  out_degree_1100  -1
    visit_1_12  in_degree_1101  -1
    visit_1_12  order_active_lb_1102  -1
    visit_1_12  order_active_ub_1103  -12
    visit_1_12  service_visit_def_1104  -1
    order_1_12  connected_order_arc_802  1
    order_1_12  connected_order_arc_825  1
    order_1_12  connected_order_arc_848  1
    order_1_12  connected_order_arc_871  1
    order_1_12  connected_order_arc_888  -1
    order_1_12  connected_order_arc_890  -1
    order_1_12  connected_order_arc_892  -1
    order_1_12  connected_order_arc_894  -1
    order_1_12  connected_order_arc_896  -1
    order_1_12  connected_order_arc_898  -1
    order_1_12  connected_order_arc_900  -1
    order_1_12  connected_order_arc_902  -1
    order_1_12  connected_order_arc_904  -1
    order_1_12  connected_order_arc_906  -1
    order_1_12  connected_order_arc_908  -1
    order_1_12  connected_order_arc_919  1
    order_1_12  connected_order_arc_942  1
    order_1_12  connected_order_arc_965  1
    order_1_12  connected_order_arc_988  1
    order_1_12  connected_order_arc_1011  1
    order_1_12  connected_order_arc_1034  1
    order_1_12  connected_order_arc_1057  1
    order_1_12  order_active_lb_1102  1
    order_1_12  order_active_ub_1103  1
    visit_1_13  out_degree_1106  -1
    visit_1_13  in_degree_1107  -1
    visit_1_13  order_active_lb_1108  -1
    visit_1_13  order_active_ub_1109  -12
    visit_1_13  service_visit_def_1110  -1
    order_1_13  connected_order_arc_804  1
    order_1_13  connected_order_arc_827  1
    order_1_13  connected_order_arc_850  1
    order_1_13  connected_order_arc_873  1
    order_1_13  connected_order_arc_896  1
    order_1_13  connected_order_arc_911  -1
    order_1_13  connected_order_arc_913  -1
    order_1_13  connected_order_arc_915  -1
    order_1_13  connected_order_arc_917  -1
    order_1_13  connected_order_arc_919  -1
    order_1_13  connected_order_arc_921  -1
    order_1_13  connected_order_arc_923  -1
    order_1_13  connected_order_arc_925  -1
    order_1_13  connected_order_arc_927  -1
    order_1_13  connected_order_arc_929  -1
    order_1_13  connected_order_arc_931  -1
    order_1_13  connected_order_arc_944  1
    order_1_13  connected_order_arc_967  1
    order_1_13  connected_order_arc_990  1
    order_1_13  connected_order_arc_1013  1
    order_1_13  connected_order_arc_1036  1
    order_1_13  connected_order_arc_1059  1
    order_1_13  order_active_lb_1108  1
    order_1_13  order_active_ub_1109  1
    visit_1_14  out_degree_1112  -1
    visit_1_14  in_degree_1113  -1
    visit_1_14  order_active_lb_1114  -1
    visit_1_14  order_active_ub_1115  -12
    visit_1_14  service_visit_def_1116  -1
    order_1_14  connected_order_arc_806  1
    order_1_14  connected_order_arc_829  1
    order_1_14  connected_order_arc_852  1
    order_1_14  connected_order_arc_875  1
    order_1_14  connected_order_arc_898  1
    order_1_14  connected_order_arc_921  1
    order_1_14  connected_order_arc_934  -1
    order_1_14  connected_order_arc_936  -1
    order_1_14  connected_order_arc_938  -1
    order_1_14  connected_order_arc_940  -1
    order_1_14  connected_order_arc_942  -1
    order_1_14  connected_order_arc_944  -1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_969  1
    order_1_14  connected_order_arc_992  1
    order_1_14  connected_order_arc_1015  1
    order_1_14  connected_order_arc_1038  1
    order_1_14  connected_order_arc_1061  1
    order_1_14  order_active_lb_1114  1
    order_1_14  order_active_ub_1115  1
    visit_1_15  out_degree_1118  -1
    visit_1_15  in_degree_1119  -1
    visit_1_15  order_active_lb_1120  -1
    visit_1_15  order_active_ub_1121  -12
    visit_1_15  service_visit_def_1122  -1
    order_1_15  connected_order_arc_808  1
    order_1_15  connected_order_arc_831  1
    order_1_15  connected_order_arc_854  1
    order_1_15  connected_order_arc_877  1
    order_1_15  connected_order_arc_900  1
    order_1_15  connected_order_arc_923  1
    order_1_15  connected_order_arc_946  1
    order_1_15  connected_order_arc_957  -1
    order_1_15  connected_order_arc_959  -1
    order_1_15  connected_order_arc_961  -1
    order_1_15  connected_order_arc_963  -1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_994  1
    order_1_15  connected_order_arc_1017  1
    order_1_15  connected_order_arc_1040  1
    order_1_15  connected_order_arc_1063  1
    order_1_15  order_active_lb_1120  1
    order_1_15  order_active_ub_1121  1
    visit_1_16  out_degree_1124  -1
    visit_1_16  in_degree_1125  -1
    visit_1_16  order_active_lb_1126  -1
    visit_1_16  order_active_ub_1127  -12
    visit_1_16  service_visit_def_1128  -1
    order_1_16  connected_order_arc_810  1
    order_1_16  connected_order_arc_833  1
    order_1_16  connected_order_arc_856  1
    order_1_16  connected_order_arc_879  1
    order_1_16  connected_order_arc_902  1
    order_1_16  connected_order_arc_925  1
    order_1_16  connected_order_arc_948  1
    order_1_16  connected_order_arc_971  1
    order_1_16  connected_order_arc_980  -1
    order_1_16  connected_order_arc_982  -1
    order_1_16  connected_order_arc_984  -1
    order_1_16  connected_order_arc_986  -1
    order_1_16  connected_order_arc_988  -1
    order_1_16  connected_order_arc_990  -1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1019  1
    order_1_16  connected_order_arc_1042  1
    order_1_16  connected_order_arc_1065  1
    order_1_16  order_active_lb_1126  1
    order_1_16  order_active_ub_1127  1
    visit_1_17  out_degree_1130  -1
    visit_1_17  in_degree_1131  -1
    visit_1_17  order_active_lb_1132  -1
    visit_1_17  order_active_ub_1133  -12
    visit_1_17  service_visit_def_1134  -1
    order_1_17  connected_order_arc_812  1
    order_1_17  connected_order_arc_835  1
    order_1_17  connected_order_arc_858  1
    order_1_17  connected_order_arc_881  1
    order_1_17  connected_order_arc_904  1
    order_1_17  connected_order_arc_927  1
    order_1_17  connected_order_arc_950  1
    order_1_17  connected_order_arc_973  1
    order_1_17  connected_order_arc_996  1
    order_1_17  connected_order_arc_1003  -1
    order_1_17  connected_order_arc_1005  -1
    order_1_17  connected_order_arc_1007  -1
    order_1_17  connected_order_arc_1009  -1
    order_1_17  connected_order_arc_1011  -1
    order_1_17  connected_order_arc_1013  -1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1021  -1
    order_1_17  connected_order_arc_1023  -1
    order_1_17  connected_order_arc_1044  1
    order_1_17  connected_order_arc_1067  1
    order_1_17  order_active_lb_1132  1
    order_1_17  order_active_ub_1133  1
    visit_1_18  out_degree_1136  -1
    visit_1_18  in_degree_1137  -1
    visit_1_18  order_active_lb_1138  -1
    visit_1_18  order_active_ub_1139  -12
    visit_1_18  service_visit_def_1140  -1
    order_1_18  connected_order_arc_814  1
    order_1_18  connected_order_arc_837  1
    order_1_18  connected_order_arc_860  1
    order_1_18  connected_order_arc_883  1
    order_1_18  connected_order_arc_906  1
    order_1_18  connected_order_arc_929  1
    order_1_18  connected_order_arc_952  1
    order_1_18  connected_order_arc_975  1
    order_1_18  connected_order_arc_998  1
    order_1_18  connected_order_arc_1021  1
    order_1_18  connected_order_arc_1026  -1
    order_1_18  connected_order_arc_1028  -1
    order_1_18  connected_order_arc_1030  -1
    order_1_18  connected_order_arc_1032  -1
    order_1_18  connected_order_arc_1034  -1
    order_1_18  connected_order_arc_1036  -1
    order_1_18  connected_order_arc_1038  -1
    order_1_18  connected_order_arc_1040  -1
    order_1_18  connected_order_arc_1042  -1
    order_1_18  connected_order_arc_1044  -1
    order_1_18  connected_order_arc_1046  -1
    order_1_18  connected_order_arc_1069  1
    order_1_18  order_active_lb_1138  1
    order_1_18  order_active_ub_1139  1
    visit_1_19  out_degree_1142  -1
    visit_1_19  in_degree_1143  -1
    visit_1_19  order_active_lb_1144  -1
    visit_1_19  order_active_ub_1145  -12
    visit_1_19  service_visit_def_1146  -1
    order_1_19  connected_order_arc_816  1
    order_1_19  connected_order_arc_839  1
    order_1_19  connected_order_arc_862  1
    order_1_19  connected_order_arc_885  1
    order_1_19  connected_order_arc_908  1
    order_1_19  connected_order_arc_931  1
    order_1_19  connected_order_arc_954  1
    order_1_19  connected_order_arc_977  1
    order_1_19  connected_order_arc_1000  1
    order_1_19  connected_order_arc_1023  1
    order_1_19  connected_order_arc_1046  1
    order_1_19  connected_order_arc_1049  -1
    order_1_19  connected_order_arc_1051  -1
    order_1_19  connected_order_arc_1053  -1
    order_1_19  connected_order_arc_1055  -1
    order_1_19  connected_order_arc_1057  -1
    order_1_19  connected_order_arc_1059  -1
    order_1_19  connected_order_arc_1061  -1
    order_1_19  connected_order_arc_1063  -1
    order_1_19  connected_order_arc_1065  -1
    order_1_19  connected_order_arc_1067  -1
    order_1_19  connected_order_arc_1069  -1
    order_1_19  order_active_lb_1144  1
    order_1_19  order_active_ub_1145  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_781  -25
    arc_1_0_0  depot_departure_or_bypass_1070  1
    arc_1_0_0  depot_return_or_bypass_1071  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_781  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_782  -25
    arc_1_0_5  depot_departure_or_bypass_1070  1
    arc_1_0_5  in_degree_1073  1
    arc_1_0_5  original_T_including_depot_unload_1151  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_782  1
    load_1_0_5  segment_load_conservation_1076  -1
    load_1_0_5  segment_prefix_lb_1077  1
    load_1_0_5  segment_prefix_ub_1078  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_783  -25
    arc_1_0_6  depot_departure_or_bypass_1070  1
    arc_1_0_6  in_degree_1080  1
    arc_1_0_6  original_T_including_depot_unload_1151  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_783  1
    load_1_0_6  segment_load_conservation_1083  -1
    load_1_0_6  segment_prefix_lb_1084  1
    load_1_0_6  segment_prefix_ub_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_784  -25
    arc_1_0_7  depot_departure_or_bypass_1070  1
    arc_1_0_7  in_degree_1087  1
    arc_1_0_7  original_T_including_depot_unload_1151  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_784  1
    load_1_0_7  segment_load_conservation_1090  -1
    load_1_0_7  segment_prefix_lb_1091  1
    load_1_0_7  segment_prefix_ub_1092  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_785  -25
    arc_1_0_8  depot_departure_or_bypass_1070  1
    arc_1_0_8  in_degree_1094  1
    arc_1_0_8  original_T_including_depot_unload_1151  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_785  1
    load_1_0_8  segment_load_conservation_1097  -1
    load_1_0_8  segment_prefix_lb_1098  1
    load_1_0_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_786  -25
    arc_1_0_12  depot_departure_or_bypass_1070  1
    arc_1_0_12  in_degree_1101  1
    arc_1_0_12  original_T_including_depot_unload_1151  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_786  1
    load_1_0_12  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_787  -25
    arc_1_0_13  depot_departure_or_bypass_1070  1
    arc_1_0_13  in_degree_1107  1
    arc_1_0_13  original_T_including_depot_unload_1151  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_787  1
    load_1_0_13  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_788  -25
    arc_1_0_14  depot_departure_or_bypass_1070  1
    arc_1_0_14  in_degree_1113  1
    arc_1_0_14  original_T_including_depot_unload_1151  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_788  1
    load_1_0_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_789  -25
    arc_1_0_15  depot_departure_or_bypass_1070  1
    arc_1_0_15  in_degree_1119  1
    arc_1_0_15  original_T_including_depot_unload_1151  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_789  1
    load_1_0_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_790  -25
    arc_1_0_16  depot_departure_or_bypass_1070  1
    arc_1_0_16  in_degree_1125  1
    arc_1_0_16  original_T_including_depot_unload_1151  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_790  1
    load_1_0_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_791  -25
    arc_1_0_17  depot_departure_or_bypass_1070  1
    arc_1_0_17  in_degree_1131  1
    arc_1_0_17  original_T_including_depot_unload_1151  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_791  1
    load_1_0_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_792  -25
    arc_1_0_18  depot_departure_or_bypass_1070  1
    arc_1_0_18  in_degree_1137  1
    arc_1_0_18  original_T_including_depot_unload_1151  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_792  1
    load_1_0_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_793  -25
    arc_1_0_19  depot_departure_or_bypass_1070  1
    arc_1_0_19  in_degree_1143  1
    arc_1_0_19  original_T_including_depot_unload_1151  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_793  1
    load_1_0_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_794  -25
    arc_1_5_0  depot_return_or_bypass_1071  1
    arc_1_5_0  out_degree_1072  1
    arc_1_5_0  original_T_including_depot_unload_1151  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_794  1
    load_1_5_0  segment_load_conservation_1076  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_795  -25
    arc_1_5_6  connected_order_arc_796  -13
    arc_1_5_6  out_degree_1072  1
    arc_1_5_6  in_degree_1080  1
    arc_1_5_6  original_T_including_depot_unload_1151  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_795  1
    load_1_5_6  segment_load_conservation_1076  1
    load_1_5_6  segment_load_conservation_1083  -1
    load_1_5_6  segment_prefix_lb_1084  1
    load_1_5_6  segment_prefix_ub_1085  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_797  -25
    arc_1_5_7  connected_order_arc_798  -13
    arc_1_5_7  out_degree_1072  1
    arc_1_5_7  in_degree_1087  1
    arc_1_5_7  original_T_including_depot_unload_1151  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_797  1
    load_1_5_7  segment_load_conservation_1076  1
    load_1_5_7  segment_load_conservation_1090  -1
    load_1_5_7  segment_prefix_lb_1091  1
    load_1_5_7  segment_prefix_ub_1092  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_799  -25
    arc_1_5_8  connected_order_arc_800  -13
    arc_1_5_8  out_degree_1072  1
    arc_1_5_8  in_degree_1094  1
    arc_1_5_8  original_T_including_depot_unload_1151  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_799  1
    load_1_5_8  segment_load_conservation_1076  1
    load_1_5_8  segment_load_conservation_1097  -1
    load_1_5_8  segment_prefix_lb_1098  1
    load_1_5_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_12  arc_capacity_801  -25
    arc_1_5_12  connected_order_arc_802  -13
    arc_1_5_12  out_degree_1072  1
    arc_1_5_12  in_degree_1101  1
    arc_1_5_12  original_T_including_depot_unload_1151  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_12  arc_capacity_801  1
    load_1_5_12  segment_load_conservation_1076  1
    load_1_5_12  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_13  arc_capacity_803  -25
    arc_1_5_13  connected_order_arc_804  -13
    arc_1_5_13  out_degree_1072  1
    arc_1_5_13  in_degree_1107  1
    arc_1_5_13  original_T_including_depot_unload_1151  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_13  arc_capacity_803  1
    load_1_5_13  segment_load_conservation_1076  1
    load_1_5_13  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_805  -25
    arc_1_5_14  connected_order_arc_806  -13
    arc_1_5_14  out_degree_1072  1
    arc_1_5_14  in_degree_1113  1
    arc_1_5_14  original_T_including_depot_unload_1151  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_805  1
    load_1_5_14  segment_load_conservation_1076  1
    load_1_5_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_807  -25
    arc_1_5_15  connected_order_arc_808  -13
    arc_1_5_15  out_degree_1072  1
    arc_1_5_15  in_degree_1119  1
    arc_1_5_15  original_T_including_depot_unload_1151  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_807  1
    load_1_5_15  segment_load_conservation_1076  1
    load_1_5_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_809  -25
    arc_1_5_16  connected_order_arc_810  -13
    arc_1_5_16  out_degree_1072  1
    arc_1_5_16  in_degree_1125  1
    arc_1_5_16  original_T_including_depot_unload_1151  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_809  1
    load_1_5_16  segment_load_conservation_1076  1
    load_1_5_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_811  -25
    arc_1_5_17  connected_order_arc_812  -13
    arc_1_5_17  out_degree_1072  1
    arc_1_5_17  in_degree_1131  1
    arc_1_5_17  original_T_including_depot_unload_1151  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_811  1
    load_1_5_17  segment_load_conservation_1076  1
    load_1_5_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_813  -25
    arc_1_5_18  connected_order_arc_814  -13
    arc_1_5_18  out_degree_1072  1
    arc_1_5_18  in_degree_1137  1
    arc_1_5_18  original_T_including_depot_unload_1151  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_813  1
    load_1_5_18  segment_load_conservation_1076  1
    load_1_5_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_815  -25
    arc_1_5_19  connected_order_arc_816  -13
    arc_1_5_19  out_degree_1072  1
    arc_1_5_19  in_degree_1143  1
    arc_1_5_19  original_T_including_depot_unload_1151  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_815  1
    load_1_5_19  segment_load_conservation_1076  1
    load_1_5_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_817  -25
    arc_1_6_0  depot_return_or_bypass_1071  1
    arc_1_6_0  out_degree_1079  1
    arc_1_6_0  original_T_including_depot_unload_1151  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_817  1
    load_1_6_0  segment_load_conservation_1083  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_818  -25
    arc_1_6_5  connected_order_arc_819  -13
    arc_1_6_5  in_degree_1073  1
    arc_1_6_5  out_degree_1079  1
    arc_1_6_5  original_T_including_depot_unload_1151  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_818  1
    load_1_6_5  segment_load_conservation_1076  -1
    load_1_6_5  segment_prefix_lb_1077  1
    load_1_6_5  segment_prefix_ub_1078  1
    load_1_6_5  segment_load_conservation_1083  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_820  -25
    arc_1_6_7  connected_order_arc_821  -13
    arc_1_6_7  out_degree_1079  1
    arc_1_6_7  in_degree_1087  1
    arc_1_6_7  original_T_including_depot_unload_1151  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_820  1
    load_1_6_7  segment_load_conservation_1083  1
    load_1_6_7  segment_load_conservation_1090  -1
    load_1_6_7  segment_prefix_lb_1091  1
    load_1_6_7  segment_prefix_ub_1092  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_822  -25
    arc_1_6_8  connected_order_arc_823  -13
    arc_1_6_8  out_degree_1079  1
    arc_1_6_8  in_degree_1094  1
    arc_1_6_8  original_T_including_depot_unload_1151  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_822  1
    load_1_6_8  segment_load_conservation_1083  1
    load_1_6_8  segment_load_conservation_1097  -1
    load_1_6_8  segment_prefix_lb_1098  1
    load_1_6_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_824  -25
    arc_1_6_12  connected_order_arc_825  -13
    arc_1_6_12  out_degree_1079  1
    arc_1_6_12  in_degree_1101  1
    arc_1_6_12  original_T_including_depot_unload_1151  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_824  1
    load_1_6_12  segment_load_conservation_1083  1
    load_1_6_12  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_826  -25
    arc_1_6_13  connected_order_arc_827  -13
    arc_1_6_13  out_degree_1079  1
    arc_1_6_13  in_degree_1107  1
    arc_1_6_13  original_T_including_depot_unload_1151  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_826  1
    load_1_6_13  segment_load_conservation_1083  1
    load_1_6_13  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_828  -25
    arc_1_6_14  connected_order_arc_829  -13
    arc_1_6_14  out_degree_1079  1
    arc_1_6_14  in_degree_1113  1
    arc_1_6_14  original_T_including_depot_unload_1151  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_828  1
    load_1_6_14  segment_load_conservation_1083  1
    load_1_6_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_830  -25
    arc_1_6_15  connected_order_arc_831  -13
    arc_1_6_15  out_degree_1079  1
    arc_1_6_15  in_degree_1119  1
    arc_1_6_15  original_T_including_depot_unload_1151  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_830  1
    load_1_6_15  segment_load_conservation_1083  1
    load_1_6_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_832  -25
    arc_1_6_16  connected_order_arc_833  -13
    arc_1_6_16  out_degree_1079  1
    arc_1_6_16  in_degree_1125  1
    arc_1_6_16  original_T_including_depot_unload_1151  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_832  1
    load_1_6_16  segment_load_conservation_1083  1
    load_1_6_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_834  -25
    arc_1_6_17  connected_order_arc_835  -13
    arc_1_6_17  out_degree_1079  1
    arc_1_6_17  in_degree_1131  1
    arc_1_6_17  original_T_including_depot_unload_1151  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_834  1
    load_1_6_17  segment_load_conservation_1083  1
    load_1_6_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_836  -25
    arc_1_6_18  connected_order_arc_837  -13
    arc_1_6_18  out_degree_1079  1
    arc_1_6_18  in_degree_1137  1
    arc_1_6_18  original_T_including_depot_unload_1151  1.9878052050440085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_836  1
    load_1_6_18  segment_load_conservation_1083  1
    load_1_6_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_838  -25
    arc_1_6_19  connected_order_arc_839  -13
    arc_1_6_19  out_degree_1079  1
    arc_1_6_19  in_degree_1143  1
    arc_1_6_19  original_T_including_depot_unload_1151  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_838  1
    load_1_6_19  segment_load_conservation_1083  1
    load_1_6_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_840  -25
    arc_1_7_0  depot_return_or_bypass_1071  1
    arc_1_7_0  out_degree_1086  1
    arc_1_7_0  original_T_including_depot_unload_1151  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_840  1
    load_1_7_0  segment_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_841  -25
    arc_1_7_5  connected_order_arc_842  -13
    arc_1_7_5  in_degree_1073  1
    arc_1_7_5  out_degree_1086  1
    arc_1_7_5  original_T_including_depot_unload_1151  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_841  1
    load_1_7_5  segment_load_conservation_1076  -1
    load_1_7_5  segment_prefix_lb_1077  1
    load_1_7_5  segment_prefix_ub_1078  1
    load_1_7_5  segment_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_843  -25
    arc_1_7_6  connected_order_arc_844  -13
    arc_1_7_6  in_degree_1080  1
    arc_1_7_6  out_degree_1086  1
    arc_1_7_6  original_T_including_depot_unload_1151  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_843  1
    load_1_7_6  segment_load_conservation_1083  -1
    load_1_7_6  segment_prefix_lb_1084  1
    load_1_7_6  segment_prefix_ub_1085  1
    load_1_7_6  segment_load_conservation_1090  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_845  -25
    arc_1_7_8  connected_order_arc_846  -13
    arc_1_7_8  out_degree_1086  1
    arc_1_7_8  in_degree_1094  1
    arc_1_7_8  original_T_including_depot_unload_1151  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_845  1
    load_1_7_8  segment_load_conservation_1090  1
    load_1_7_8  segment_load_conservation_1097  -1
    load_1_7_8  segment_prefix_lb_1098  1
    load_1_7_8  segment_prefix_ub_1099  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_847  -25
    arc_1_7_12  connected_order_arc_848  -13
    arc_1_7_12  out_degree_1086  1
    arc_1_7_12  in_degree_1101  1
    arc_1_7_12  original_T_including_depot_unload_1151  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_847  1
    load_1_7_12  segment_load_conservation_1090  1
    load_1_7_12  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_849  -25
    arc_1_7_13  connected_order_arc_850  -13
    arc_1_7_13  out_degree_1086  1
    arc_1_7_13  in_degree_1107  1
    arc_1_7_13  original_T_including_depot_unload_1151  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_849  1
    load_1_7_13  segment_load_conservation_1090  1
    load_1_7_13  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_851  -25
    arc_1_7_14  connected_order_arc_852  -13
    arc_1_7_14  out_degree_1086  1
    arc_1_7_14  in_degree_1113  1
    arc_1_7_14  original_T_including_depot_unload_1151  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_851  1
    load_1_7_14  segment_load_conservation_1090  1
    load_1_7_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_853  -25
    arc_1_7_15  connected_order_arc_854  -13
    arc_1_7_15  out_degree_1086  1
    arc_1_7_15  in_degree_1119  1
    arc_1_7_15  original_T_including_depot_unload_1151  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_853  1
    load_1_7_15  segment_load_conservation_1090  1
    load_1_7_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_855  -25
    arc_1_7_16  connected_order_arc_856  -13
    arc_1_7_16  out_degree_1086  1
    arc_1_7_16  in_degree_1125  1
    arc_1_7_16  original_T_including_depot_unload_1151  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_855  1
    load_1_7_16  segment_load_conservation_1090  1
    load_1_7_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_857  -25
    arc_1_7_17  connected_order_arc_858  -13
    arc_1_7_17  out_degree_1086  1
    arc_1_7_17  in_degree_1131  1
    arc_1_7_17  original_T_including_depot_unload_1151  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_857  1
    load_1_7_17  segment_load_conservation_1090  1
    load_1_7_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_859  -25
    arc_1_7_18  connected_order_arc_860  -13
    arc_1_7_18  out_degree_1086  1
    arc_1_7_18  in_degree_1137  1
    arc_1_7_18  original_T_including_depot_unload_1151  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_859  1
    load_1_7_18  segment_load_conservation_1090  1
    load_1_7_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_861  -25
    arc_1_7_19  connected_order_arc_862  -13
    arc_1_7_19  out_degree_1086  1
    arc_1_7_19  in_degree_1143  1
    arc_1_7_19  original_T_including_depot_unload_1151  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_861  1
    load_1_7_19  segment_load_conservation_1090  1
    load_1_7_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_863  -25
    arc_1_8_0  depot_return_or_bypass_1071  1
    arc_1_8_0  out_degree_1093  1
    arc_1_8_0  original_T_including_depot_unload_1151  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_863  1
    load_1_8_0  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_864  -25
    arc_1_8_5  connected_order_arc_865  -13
    arc_1_8_5  in_degree_1073  1
    arc_1_8_5  out_degree_1093  1
    arc_1_8_5  original_T_including_depot_unload_1151  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_864  1
    load_1_8_5  segment_load_conservation_1076  -1
    load_1_8_5  segment_prefix_lb_1077  1
    load_1_8_5  segment_prefix_ub_1078  1
    load_1_8_5  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_866  -25
    arc_1_8_6  connected_order_arc_867  -13
    arc_1_8_6  in_degree_1080  1
    arc_1_8_6  out_degree_1093  1
    arc_1_8_6  original_T_including_depot_unload_1151  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_866  1
    load_1_8_6  segment_load_conservation_1083  -1
    load_1_8_6  segment_prefix_lb_1084  1
    load_1_8_6  segment_prefix_ub_1085  1
    load_1_8_6  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_868  -25
    arc_1_8_7  connected_order_arc_869  -13
    arc_1_8_7  in_degree_1087  1
    arc_1_8_7  out_degree_1093  1
    arc_1_8_7  original_T_including_depot_unload_1151  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_868  1
    load_1_8_7  segment_load_conservation_1090  -1
    load_1_8_7  segment_prefix_lb_1091  1
    load_1_8_7  segment_prefix_ub_1092  1
    load_1_8_7  segment_load_conservation_1097  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_870  -25
    arc_1_8_12  connected_order_arc_871  -13
    arc_1_8_12  out_degree_1093  1
    arc_1_8_12  in_degree_1101  1
    arc_1_8_12  original_T_including_depot_unload_1151  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_870  1
    load_1_8_12  segment_load_conservation_1097  1
    load_1_8_12  free_load_conservation_1105  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_872  -25
    arc_1_8_13  connected_order_arc_873  -13
    arc_1_8_13  out_degree_1093  1
    arc_1_8_13  in_degree_1107  1
    arc_1_8_13  original_T_including_depot_unload_1151  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_872  1
    load_1_8_13  segment_load_conservation_1097  1
    load_1_8_13  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_874  -25
    arc_1_8_14  connected_order_arc_875  -13
    arc_1_8_14  out_degree_1093  1
    arc_1_8_14  in_degree_1113  1
    arc_1_8_14  original_T_including_depot_unload_1151  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_874  1
    load_1_8_14  segment_load_conservation_1097  1
    load_1_8_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_876  -25
    arc_1_8_15  connected_order_arc_877  -13
    arc_1_8_15  out_degree_1093  1
    arc_1_8_15  in_degree_1119  1
    arc_1_8_15  original_T_including_depot_unload_1151  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_876  1
    load_1_8_15  segment_load_conservation_1097  1
    load_1_8_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_878  -25
    arc_1_8_16  connected_order_arc_879  -13
    arc_1_8_16  out_degree_1093  1
    arc_1_8_16  in_degree_1125  1
    arc_1_8_16  original_T_including_depot_unload_1151  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_878  1
    load_1_8_16  segment_load_conservation_1097  1
    load_1_8_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_880  -25
    arc_1_8_17  connected_order_arc_881  -13
    arc_1_8_17  out_degree_1093  1
    arc_1_8_17  in_degree_1131  1
    arc_1_8_17  original_T_including_depot_unload_1151  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_880  1
    load_1_8_17  segment_load_conservation_1097  1
    load_1_8_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_882  -25
    arc_1_8_18  connected_order_arc_883  -13
    arc_1_8_18  out_degree_1093  1
    arc_1_8_18  in_degree_1137  1
    arc_1_8_18  original_T_including_depot_unload_1151  1.3127274783157229e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_882  1
    load_1_8_18  segment_load_conservation_1097  1
    load_1_8_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_884  -25
    arc_1_8_19  connected_order_arc_885  -13
    arc_1_8_19  out_degree_1093  1
    arc_1_8_19  in_degree_1143  1
    arc_1_8_19  original_T_including_depot_unload_1151  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_884  1
    load_1_8_19  segment_load_conservation_1097  1
    load_1_8_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_886  -25
    arc_1_12_0  depot_return_or_bypass_1071  1
    arc_1_12_0  out_degree_1100  1
    arc_1_12_0  original_T_including_depot_unload_1151  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_886  1
    load_1_12_0  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_5  arc_capacity_887  -25
    arc_1_12_5  connected_order_arc_888  -13
    arc_1_12_5  in_degree_1073  1
    arc_1_12_5  out_degree_1100  1
    arc_1_12_5  original_T_including_depot_unload_1151  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_5  arc_capacity_887  1
    load_1_12_5  segment_load_conservation_1076  -1
    load_1_12_5  segment_prefix_lb_1077  1
    load_1_12_5  segment_prefix_ub_1078  1
    load_1_12_5  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_889  -25
    arc_1_12_6  connected_order_arc_890  -13
    arc_1_12_6  in_degree_1080  1
    arc_1_12_6  out_degree_1100  1
    arc_1_12_6  original_T_including_depot_unload_1151  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_889  1
    load_1_12_6  segment_load_conservation_1083  -1
    load_1_12_6  segment_prefix_lb_1084  1
    load_1_12_6  segment_prefix_ub_1085  1
    load_1_12_6  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_891  -25
    arc_1_12_7  connected_order_arc_892  -13
    arc_1_12_7  in_degree_1087  1
    arc_1_12_7  out_degree_1100  1
    arc_1_12_7  original_T_including_depot_unload_1151  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_891  1
    load_1_12_7  segment_load_conservation_1090  -1
    load_1_12_7  segment_prefix_lb_1091  1
    load_1_12_7  segment_prefix_ub_1092  1
    load_1_12_7  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_893  -25
    arc_1_12_8  connected_order_arc_894  -13
    arc_1_12_8  in_degree_1094  1
    arc_1_12_8  out_degree_1100  1
    arc_1_12_8  original_T_including_depot_unload_1151  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_893  1
    load_1_12_8  segment_load_conservation_1097  -1
    load_1_12_8  segment_prefix_lb_1098  1
    load_1_12_8  segment_prefix_ub_1099  1
    load_1_12_8  free_load_conservation_1105  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_895  -25
    arc_1_12_13  connected_order_arc_896  -13
    arc_1_12_13  out_degree_1100  1
    arc_1_12_13  in_degree_1107  1
    arc_1_12_13  original_T_including_depot_unload_1151  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_895  1
    load_1_12_13  free_load_conservation_1105  1
    load_1_12_13  free_load_conservation_1111  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_897  -25
    arc_1_12_14  connected_order_arc_898  -13
    arc_1_12_14  out_degree_1100  1
    arc_1_12_14  in_degree_1113  1
    arc_1_12_14  original_T_including_depot_unload_1151  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_897  1
    load_1_12_14  free_load_conservation_1105  1
    load_1_12_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_899  -25
    arc_1_12_15  connected_order_arc_900  -13
    arc_1_12_15  out_degree_1100  1
    arc_1_12_15  in_degree_1119  1
    arc_1_12_15  original_T_including_depot_unload_1151  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_899  1
    load_1_12_15  free_load_conservation_1105  1
    load_1_12_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_16  arc_capacity_901  -25
    arc_1_12_16  connected_order_arc_902  -13
    arc_1_12_16  out_degree_1100  1
    arc_1_12_16  in_degree_1125  1
    arc_1_12_16  original_T_including_depot_unload_1151  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_16  arc_capacity_901  1
    load_1_12_16  free_load_conservation_1105  1
    load_1_12_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_17  arc_capacity_903  -25
    arc_1_12_17  connected_order_arc_904  -13
    arc_1_12_17  out_degree_1100  1
    arc_1_12_17  in_degree_1131  1
    arc_1_12_17  original_T_including_depot_unload_1151  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_17  arc_capacity_903  1
    load_1_12_17  free_load_conservation_1105  1
    load_1_12_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_18  arc_capacity_905  -25
    arc_1_12_18  connected_order_arc_906  -13
    arc_1_12_18  out_degree_1100  1
    arc_1_12_18  in_degree_1137  1
    arc_1_12_18  original_T_including_depot_unload_1151  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_18  arc_capacity_905  1
    load_1_12_18  free_load_conservation_1105  1
    load_1_12_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_19  arc_capacity_907  -25
    arc_1_12_19  connected_order_arc_908  -13
    arc_1_12_19  out_degree_1100  1
    arc_1_12_19  in_degree_1143  1
    arc_1_12_19  original_T_including_depot_unload_1151  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_19  arc_capacity_907  1
    load_1_12_19  free_load_conservation_1105  1
    load_1_12_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_909  -25
    arc_1_13_0  depot_return_or_bypass_1071  1
    arc_1_13_0  out_degree_1106  1
    arc_1_13_0  original_T_including_depot_unload_1151  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_909  1
    load_1_13_0  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_5  arc_capacity_910  -25
    arc_1_13_5  connected_order_arc_911  -13
    arc_1_13_5  in_degree_1073  1
    arc_1_13_5  out_degree_1106  1
    arc_1_13_5  original_T_including_depot_unload_1151  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_5  arc_capacity_910  1
    load_1_13_5  segment_load_conservation_1076  -1
    load_1_13_5  segment_prefix_lb_1077  1
    load_1_13_5  segment_prefix_ub_1078  1
    load_1_13_5  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_912  -25
    arc_1_13_6  connected_order_arc_913  -13
    arc_1_13_6  in_degree_1080  1
    arc_1_13_6  out_degree_1106  1
    arc_1_13_6  original_T_including_depot_unload_1151  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_912  1
    load_1_13_6  segment_load_conservation_1083  -1
    load_1_13_6  segment_prefix_lb_1084  1
    load_1_13_6  segment_prefix_ub_1085  1
    load_1_13_6  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_914  -25
    arc_1_13_7  connected_order_arc_915  -13
    arc_1_13_7  in_degree_1087  1
    arc_1_13_7  out_degree_1106  1
    arc_1_13_7  original_T_including_depot_unload_1151  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_914  1
    load_1_13_7  segment_load_conservation_1090  -1
    load_1_13_7  segment_prefix_lb_1091  1
    load_1_13_7  segment_prefix_ub_1092  1
    load_1_13_7  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_916  -25
    arc_1_13_8  connected_order_arc_917  -13
    arc_1_13_8  in_degree_1094  1
    arc_1_13_8  out_degree_1106  1
    arc_1_13_8  original_T_including_depot_unload_1151  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_916  1
    load_1_13_8  segment_load_conservation_1097  -1
    load_1_13_8  segment_prefix_lb_1098  1
    load_1_13_8  segment_prefix_ub_1099  1
    load_1_13_8  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_918  -25
    arc_1_13_12  connected_order_arc_919  -13
    arc_1_13_12  in_degree_1101  1
    arc_1_13_12  out_degree_1106  1
    arc_1_13_12  original_T_including_depot_unload_1151  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_918  1
    load_1_13_12  free_load_conservation_1105  -1
    load_1_13_12  free_load_conservation_1111  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_920  -25
    arc_1_13_14  connected_order_arc_921  -13
    arc_1_13_14  out_degree_1106  1
    arc_1_13_14  in_degree_1113  1
    arc_1_13_14  original_T_including_depot_unload_1151  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_920  1
    load_1_13_14  free_load_conservation_1111  1
    load_1_13_14  free_load_conservation_1117  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_922  -25
    arc_1_13_15  connected_order_arc_923  -13
    arc_1_13_15  out_degree_1106  1
    arc_1_13_15  in_degree_1119  1
    arc_1_13_15  original_T_including_depot_unload_1151  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_922  1
    load_1_13_15  free_load_conservation_1111  1
    load_1_13_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_16  arc_capacity_924  -25
    arc_1_13_16  connected_order_arc_925  -13
    arc_1_13_16  out_degree_1106  1
    arc_1_13_16  in_degree_1125  1
    arc_1_13_16  original_T_including_depot_unload_1151  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_16  arc_capacity_924  1
    load_1_13_16  free_load_conservation_1111  1
    load_1_13_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_17  arc_capacity_926  -25
    arc_1_13_17  connected_order_arc_927  -13
    arc_1_13_17  out_degree_1106  1
    arc_1_13_17  in_degree_1131  1
    arc_1_13_17  original_T_including_depot_unload_1151  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_17  arc_capacity_926  1
    load_1_13_17  free_load_conservation_1111  1
    load_1_13_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_18  arc_capacity_928  -25
    arc_1_13_18  connected_order_arc_929  -13
    arc_1_13_18  out_degree_1106  1
    arc_1_13_18  in_degree_1137  1
    arc_1_13_18  original_T_including_depot_unload_1151  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_18  arc_capacity_928  1
    load_1_13_18  free_load_conservation_1111  1
    load_1_13_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_19  arc_capacity_930  -25
    arc_1_13_19  connected_order_arc_931  -13
    arc_1_13_19  out_degree_1106  1
    arc_1_13_19  in_degree_1143  1
    arc_1_13_19  original_T_including_depot_unload_1151  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_19  arc_capacity_930  1
    load_1_13_19  free_load_conservation_1111  1
    load_1_13_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_932  -25
    arc_1_14_0  depot_return_or_bypass_1071  1
    arc_1_14_0  out_degree_1112  1
    arc_1_14_0  original_T_including_depot_unload_1151  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_932  1
    load_1_14_0  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_933  -25
    arc_1_14_5  connected_order_arc_934  -13
    arc_1_14_5  in_degree_1073  1
    arc_1_14_5  out_degree_1112  1
    arc_1_14_5  original_T_including_depot_unload_1151  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_933  1
    load_1_14_5  segment_load_conservation_1076  -1
    load_1_14_5  segment_prefix_lb_1077  1
    load_1_14_5  segment_prefix_ub_1078  1
    load_1_14_5  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_935  -25
    arc_1_14_6  connected_order_arc_936  -13
    arc_1_14_6  in_degree_1080  1
    arc_1_14_6  out_degree_1112  1
    arc_1_14_6  original_T_including_depot_unload_1151  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_935  1
    load_1_14_6  segment_load_conservation_1083  -1
    load_1_14_6  segment_prefix_lb_1084  1
    load_1_14_6  segment_prefix_ub_1085  1
    load_1_14_6  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_937  -25
    arc_1_14_7  connected_order_arc_938  -13
    arc_1_14_7  in_degree_1087  1
    arc_1_14_7  out_degree_1112  1
    arc_1_14_7  original_T_including_depot_unload_1151  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_937  1
    load_1_14_7  segment_load_conservation_1090  -1
    load_1_14_7  segment_prefix_lb_1091  1
    load_1_14_7  segment_prefix_ub_1092  1
    load_1_14_7  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_939  -25
    arc_1_14_8  connected_order_arc_940  -13
    arc_1_14_8  in_degree_1094  1
    arc_1_14_8  out_degree_1112  1
    arc_1_14_8  original_T_including_depot_unload_1151  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_939  1
    load_1_14_8  segment_load_conservation_1097  -1
    load_1_14_8  segment_prefix_lb_1098  1
    load_1_14_8  segment_prefix_ub_1099  1
    load_1_14_8  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_941  -25
    arc_1_14_12  connected_order_arc_942  -13
    arc_1_14_12  in_degree_1101  1
    arc_1_14_12  out_degree_1112  1
    arc_1_14_12  original_T_including_depot_unload_1151  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_941  1
    load_1_14_12  free_load_conservation_1105  -1
    load_1_14_12  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_943  -25
    arc_1_14_13  connected_order_arc_944  -13
    arc_1_14_13  in_degree_1107  1
    arc_1_14_13  out_degree_1112  1
    arc_1_14_13  original_T_including_depot_unload_1151  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_943  1
    load_1_14_13  free_load_conservation_1111  -1
    load_1_14_13  free_load_conservation_1117  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_945  -25
    arc_1_14_15  connected_order_arc_946  -13
    arc_1_14_15  out_degree_1112  1
    arc_1_14_15  in_degree_1119  1
    arc_1_14_15  original_T_including_depot_unload_1151  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_945  1
    load_1_14_15  free_load_conservation_1117  1
    load_1_14_15  free_load_conservation_1123  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_947  -25
    arc_1_14_16  connected_order_arc_948  -13
    arc_1_14_16  out_degree_1112  1
    arc_1_14_16  in_degree_1125  1
    arc_1_14_16  original_T_including_depot_unload_1151  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_947  1
    load_1_14_16  free_load_conservation_1117  1
    load_1_14_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_949  -25
    arc_1_14_17  connected_order_arc_950  -13
    arc_1_14_17  out_degree_1112  1
    arc_1_14_17  in_degree_1131  1
    arc_1_14_17  original_T_including_depot_unload_1151  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_949  1
    load_1_14_17  free_load_conservation_1117  1
    load_1_14_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_951  -25
    arc_1_14_18  connected_order_arc_952  -13
    arc_1_14_18  out_degree_1112  1
    arc_1_14_18  in_degree_1137  1
    arc_1_14_18  original_T_including_depot_unload_1151  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_951  1
    load_1_14_18  free_load_conservation_1117  1
    load_1_14_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_953  -25
    arc_1_14_19  connected_order_arc_954  -13
    arc_1_14_19  out_degree_1112  1
    arc_1_14_19  in_degree_1143  1
    arc_1_14_19  original_T_including_depot_unload_1151  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_953  1
    load_1_14_19  free_load_conservation_1117  1
    load_1_14_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_955  -25
    arc_1_15_0  depot_return_or_bypass_1071  1
    arc_1_15_0  out_degree_1118  1
    arc_1_15_0  original_T_including_depot_unload_1151  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_955  1
    load_1_15_0  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_956  -25
    arc_1_15_5  connected_order_arc_957  -13
    arc_1_15_5  in_degree_1073  1
    arc_1_15_5  out_degree_1118  1
    arc_1_15_5  original_T_including_depot_unload_1151  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_956  1
    load_1_15_5  segment_load_conservation_1076  -1
    load_1_15_5  segment_prefix_lb_1077  1
    load_1_15_5  segment_prefix_ub_1078  1
    load_1_15_5  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_958  -25
    arc_1_15_6  connected_order_arc_959  -13
    arc_1_15_6  in_degree_1080  1
    arc_1_15_6  out_degree_1118  1
    arc_1_15_6  original_T_including_depot_unload_1151  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_958  1
    load_1_15_6  segment_load_conservation_1083  -1
    load_1_15_6  segment_prefix_lb_1084  1
    load_1_15_6  segment_prefix_ub_1085  1
    load_1_15_6  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_960  -25
    arc_1_15_7  connected_order_arc_961  -13
    arc_1_15_7  in_degree_1087  1
    arc_1_15_7  out_degree_1118  1
    arc_1_15_7  original_T_including_depot_unload_1151  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_960  1
    load_1_15_7  segment_load_conservation_1090  -1
    load_1_15_7  segment_prefix_lb_1091  1
    load_1_15_7  segment_prefix_ub_1092  1
    load_1_15_7  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_962  -25
    arc_1_15_8  connected_order_arc_963  -13
    arc_1_15_8  in_degree_1094  1
    arc_1_15_8  out_degree_1118  1
    arc_1_15_8  original_T_including_depot_unload_1151  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_962  1
    load_1_15_8  segment_load_conservation_1097  -1
    load_1_15_8  segment_prefix_lb_1098  1
    load_1_15_8  segment_prefix_ub_1099  1
    load_1_15_8  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_964  -25
    arc_1_15_12  connected_order_arc_965  -13
    arc_1_15_12  in_degree_1101  1
    arc_1_15_12  out_degree_1118  1
    arc_1_15_12  original_T_including_depot_unload_1151  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_964  1
    load_1_15_12  free_load_conservation_1105  -1
    load_1_15_12  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_966  -25
    arc_1_15_13  connected_order_arc_967  -13
    arc_1_15_13  in_degree_1107  1
    arc_1_15_13  out_degree_1118  1
    arc_1_15_13  original_T_including_depot_unload_1151  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_966  1
    load_1_15_13  free_load_conservation_1111  -1
    load_1_15_13  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_968  -25
    arc_1_15_14  connected_order_arc_969  -13
    arc_1_15_14  in_degree_1113  1
    arc_1_15_14  out_degree_1118  1
    arc_1_15_14  original_T_including_depot_unload_1151  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_968  1
    load_1_15_14  free_load_conservation_1117  -1
    load_1_15_14  free_load_conservation_1123  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_970  -25
    arc_1_15_16  connected_order_arc_971  -13
    arc_1_15_16  out_degree_1118  1
    arc_1_15_16  in_degree_1125  1
    arc_1_15_16  original_T_including_depot_unload_1151  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_970  1
    load_1_15_16  free_load_conservation_1123  1
    load_1_15_16  free_load_conservation_1129  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_972  -25
    arc_1_15_17  connected_order_arc_973  -13
    arc_1_15_17  out_degree_1118  1
    arc_1_15_17  in_degree_1131  1
    arc_1_15_17  original_T_including_depot_unload_1151  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_972  1
    load_1_15_17  free_load_conservation_1123  1
    load_1_15_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_974  -25
    arc_1_15_18  connected_order_arc_975  -13
    arc_1_15_18  out_degree_1118  1
    arc_1_15_18  in_degree_1137  1
    arc_1_15_18  original_T_including_depot_unload_1151  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_974  1
    load_1_15_18  free_load_conservation_1123  1
    load_1_15_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_976  -25
    arc_1_15_19  connected_order_arc_977  -13
    arc_1_15_19  out_degree_1118  1
    arc_1_15_19  in_degree_1143  1
    arc_1_15_19  original_T_including_depot_unload_1151  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_976  1
    load_1_15_19  free_load_conservation_1123  1
    load_1_15_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_978  -25
    arc_1_16_0  depot_return_or_bypass_1071  1
    arc_1_16_0  out_degree_1124  1
    arc_1_16_0  original_T_including_depot_unload_1151  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_978  1
    load_1_16_0  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_979  -25
    arc_1_16_5  connected_order_arc_980  -13
    arc_1_16_5  in_degree_1073  1
    arc_1_16_5  out_degree_1124  1
    arc_1_16_5  original_T_including_depot_unload_1151  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_979  1
    load_1_16_5  segment_load_conservation_1076  -1
    load_1_16_5  segment_prefix_lb_1077  1
    load_1_16_5  segment_prefix_ub_1078  1
    load_1_16_5  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_981  -25
    arc_1_16_6  connected_order_arc_982  -13
    arc_1_16_6  in_degree_1080  1
    arc_1_16_6  out_degree_1124  1
    arc_1_16_6  original_T_including_depot_unload_1151  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_981  1
    load_1_16_6  segment_load_conservation_1083  -1
    load_1_16_6  segment_prefix_lb_1084  1
    load_1_16_6  segment_prefix_ub_1085  1
    load_1_16_6  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_983  -25
    arc_1_16_7  connected_order_arc_984  -13
    arc_1_16_7  in_degree_1087  1
    arc_1_16_7  out_degree_1124  1
    arc_1_16_7  original_T_including_depot_unload_1151  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_983  1
    load_1_16_7  segment_load_conservation_1090  -1
    load_1_16_7  segment_prefix_lb_1091  1
    load_1_16_7  segment_prefix_ub_1092  1
    load_1_16_7  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_985  -25
    arc_1_16_8  connected_order_arc_986  -13
    arc_1_16_8  in_degree_1094  1
    arc_1_16_8  out_degree_1124  1
    arc_1_16_8  original_T_including_depot_unload_1151  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_985  1
    load_1_16_8  segment_load_conservation_1097  -1
    load_1_16_8  segment_prefix_lb_1098  1
    load_1_16_8  segment_prefix_ub_1099  1
    load_1_16_8  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_12  arc_capacity_987  -25
    arc_1_16_12  connected_order_arc_988  -13
    arc_1_16_12  in_degree_1101  1
    arc_1_16_12  out_degree_1124  1
    arc_1_16_12  original_T_including_depot_unload_1151  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_12  arc_capacity_987  1
    load_1_16_12  free_load_conservation_1105  -1
    load_1_16_12  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_13  arc_capacity_989  -25
    arc_1_16_13  connected_order_arc_990  -13
    arc_1_16_13  in_degree_1107  1
    arc_1_16_13  out_degree_1124  1
    arc_1_16_13  original_T_including_depot_unload_1151  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_13  arc_capacity_989  1
    load_1_16_13  free_load_conservation_1111  -1
    load_1_16_13  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_991  -25
    arc_1_16_14  connected_order_arc_992  -13
    arc_1_16_14  in_degree_1113  1
    arc_1_16_14  out_degree_1124  1
    arc_1_16_14  original_T_including_depot_unload_1151  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_991  1
    load_1_16_14  free_load_conservation_1117  -1
    load_1_16_14  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_993  -25
    arc_1_16_15  connected_order_arc_994  -13
    arc_1_16_15  in_degree_1119  1
    arc_1_16_15  out_degree_1124  1
    arc_1_16_15  original_T_including_depot_unload_1151  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_993  1
    load_1_16_15  free_load_conservation_1123  -1
    load_1_16_15  free_load_conservation_1129  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_995  -25
    arc_1_16_17  connected_order_arc_996  -13
    arc_1_16_17  out_degree_1124  1
    arc_1_16_17  in_degree_1131  1
    arc_1_16_17  original_T_including_depot_unload_1151  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_995  1
    load_1_16_17  free_load_conservation_1129  1
    load_1_16_17  free_load_conservation_1135  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_997  -25
    arc_1_16_18  connected_order_arc_998  -13
    arc_1_16_18  out_degree_1124  1
    arc_1_16_18  in_degree_1137  1
    arc_1_16_18  original_T_including_depot_unload_1151  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_997  1
    load_1_16_18  free_load_conservation_1129  1
    load_1_16_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_999  -25
    arc_1_16_19  connected_order_arc_1000  -13
    arc_1_16_19  out_degree_1124  1
    arc_1_16_19  in_degree_1143  1
    arc_1_16_19  original_T_including_depot_unload_1151  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_999  1
    load_1_16_19  free_load_conservation_1129  1
    load_1_16_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1001  -25
    arc_1_17_0  depot_return_or_bypass_1071  1
    arc_1_17_0  out_degree_1130  1
    arc_1_17_0  original_T_including_depot_unload_1151  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1001  1
    load_1_17_0  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1002  -25
    arc_1_17_5  connected_order_arc_1003  -13
    arc_1_17_5  in_degree_1073  1
    arc_1_17_5  out_degree_1130  1
    arc_1_17_5  original_T_including_depot_unload_1151  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1002  1
    load_1_17_5  segment_load_conservation_1076  -1
    load_1_17_5  segment_prefix_lb_1077  1
    load_1_17_5  segment_prefix_ub_1078  1
    load_1_17_5  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1004  -25
    arc_1_17_6  connected_order_arc_1005  -13
    arc_1_17_6  in_degree_1080  1
    arc_1_17_6  out_degree_1130  1
    arc_1_17_6  original_T_including_depot_unload_1151  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1004  1
    load_1_17_6  segment_load_conservation_1083  -1
    load_1_17_6  segment_prefix_lb_1084  1
    load_1_17_6  segment_prefix_ub_1085  1
    load_1_17_6  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1006  -25
    arc_1_17_7  connected_order_arc_1007  -13
    arc_1_17_7  in_degree_1087  1
    arc_1_17_7  out_degree_1130  1
    arc_1_17_7  original_T_including_depot_unload_1151  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1006  1
    load_1_17_7  segment_load_conservation_1090  -1
    load_1_17_7  segment_prefix_lb_1091  1
    load_1_17_7  segment_prefix_ub_1092  1
    load_1_17_7  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1008  -25
    arc_1_17_8  connected_order_arc_1009  -13
    arc_1_17_8  in_degree_1094  1
    arc_1_17_8  out_degree_1130  1
    arc_1_17_8  original_T_including_depot_unload_1151  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1008  1
    load_1_17_8  segment_load_conservation_1097  -1
    load_1_17_8  segment_prefix_lb_1098  1
    load_1_17_8  segment_prefix_ub_1099  1
    load_1_17_8  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_12  arc_capacity_1010  -25
    arc_1_17_12  connected_order_arc_1011  -13
    arc_1_17_12  in_degree_1101  1
    arc_1_17_12  out_degree_1130  1
    arc_1_17_12  original_T_including_depot_unload_1151  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_12  arc_capacity_1010  1
    load_1_17_12  free_load_conservation_1105  -1
    load_1_17_12  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_13  arc_capacity_1012  -25
    arc_1_17_13  connected_order_arc_1013  -13
    arc_1_17_13  in_degree_1107  1
    arc_1_17_13  out_degree_1130  1
    arc_1_17_13  original_T_including_depot_unload_1151  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_13  arc_capacity_1012  1
    load_1_17_13  free_load_conservation_1111  -1
    load_1_17_13  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1014  -25
    arc_1_17_14  connected_order_arc_1015  -13
    arc_1_17_14  in_degree_1113  1
    arc_1_17_14  out_degree_1130  1
    arc_1_17_14  original_T_including_depot_unload_1151  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1014  1
    load_1_17_14  free_load_conservation_1117  -1
    load_1_17_14  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1016  -25
    arc_1_17_15  connected_order_arc_1017  -13
    arc_1_17_15  in_degree_1119  1
    arc_1_17_15  out_degree_1130  1
    arc_1_17_15  original_T_including_depot_unload_1151  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1016  1
    load_1_17_15  free_load_conservation_1123  -1
    load_1_17_15  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1018  -25
    arc_1_17_16  connected_order_arc_1019  -13
    arc_1_17_16  in_degree_1125  1
    arc_1_17_16  out_degree_1130  1
    arc_1_17_16  original_T_including_depot_unload_1151  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1018  1
    load_1_17_16  free_load_conservation_1129  -1
    load_1_17_16  free_load_conservation_1135  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1020  -25
    arc_1_17_18  connected_order_arc_1021  -13
    arc_1_17_18  out_degree_1130  1
    arc_1_17_18  in_degree_1137  1
    arc_1_17_18  original_T_including_depot_unload_1151  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1020  1
    load_1_17_18  free_load_conservation_1135  1
    load_1_17_18  free_load_conservation_1141  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1022  -25
    arc_1_17_19  connected_order_arc_1023  -13
    arc_1_17_19  out_degree_1130  1
    arc_1_17_19  in_degree_1143  1
    arc_1_17_19  original_T_including_depot_unload_1151  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1022  1
    load_1_17_19  free_load_conservation_1135  1
    load_1_17_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1024  -25
    arc_1_18_0  depot_return_or_bypass_1071  1
    arc_1_18_0  out_degree_1136  1
    arc_1_18_0  original_T_including_depot_unload_1151  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1024  1
    load_1_18_0  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1025  -25
    arc_1_18_5  connected_order_arc_1026  -13
    arc_1_18_5  in_degree_1073  1
    arc_1_18_5  out_degree_1136  1
    arc_1_18_5  original_T_including_depot_unload_1151  1.9170200697382236e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1025  1
    load_1_18_5  segment_load_conservation_1076  -1
    load_1_18_5  segment_prefix_lb_1077  1
    load_1_18_5  segment_prefix_ub_1078  1
    load_1_18_5  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1027  -25
    arc_1_18_6  connected_order_arc_1028  -13
    arc_1_18_6  in_degree_1080  1
    arc_1_18_6  out_degree_1136  1
    arc_1_18_6  original_T_including_depot_unload_1151  1.9878052050440085e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1027  1
    load_1_18_6  segment_load_conservation_1083  -1
    load_1_18_6  segment_prefix_lb_1084  1
    load_1_18_6  segment_prefix_ub_1085  1
    load_1_18_6  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1029  -25
    arc_1_18_7  connected_order_arc_1030  -13
    arc_1_18_7  in_degree_1087  1
    arc_1_18_7  out_degree_1136  1
    arc_1_18_7  original_T_including_depot_unload_1151  1.7017879962005411e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1029  1
    load_1_18_7  segment_load_conservation_1090  -1
    load_1_18_7  segment_prefix_lb_1091  1
    load_1_18_7  segment_prefix_ub_1092  1
    load_1_18_7  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1031  -25
    arc_1_18_8  connected_order_arc_1032  -13
    arc_1_18_8  in_degree_1094  1
    arc_1_18_8  out_degree_1136  1
    arc_1_18_8  original_T_including_depot_unload_1151  1.4961553163922974e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1031  1
    load_1_18_8  segment_load_conservation_1097  -1
    load_1_18_8  segment_prefix_lb_1098  1
    load_1_18_8  segment_prefix_ub_1099  1
    load_1_18_8  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_12  arc_capacity_1033  -25
    arc_1_18_12  connected_order_arc_1034  -13
    arc_1_18_12  in_degree_1101  1
    arc_1_18_12  out_degree_1136  1
    arc_1_18_12  original_T_including_depot_unload_1151  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_12  arc_capacity_1033  1
    load_1_18_12  free_load_conservation_1105  -1
    load_1_18_12  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_13  arc_capacity_1035  -25
    arc_1_18_13  connected_order_arc_1036  -13
    arc_1_18_13  in_degree_1107  1
    arc_1_18_13  out_degree_1136  1
    arc_1_18_13  original_T_including_depot_unload_1151  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_13  arc_capacity_1035  1
    load_1_18_13  free_load_conservation_1111  -1
    load_1_18_13  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1037  -25
    arc_1_18_14  connected_order_arc_1038  -13
    arc_1_18_14  in_degree_1113  1
    arc_1_18_14  out_degree_1136  1
    arc_1_18_14  original_T_including_depot_unload_1151  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1037  1
    load_1_18_14  free_load_conservation_1117  -1
    load_1_18_14  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1039  -25
    arc_1_18_15  connected_order_arc_1040  -13
    arc_1_18_15  in_degree_1119  1
    arc_1_18_15  out_degree_1136  1
    arc_1_18_15  original_T_including_depot_unload_1151  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1039  1
    load_1_18_15  free_load_conservation_1123  -1
    load_1_18_15  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1041  -25
    arc_1_18_16  connected_order_arc_1042  -13
    arc_1_18_16  in_degree_1125  1
    arc_1_18_16  out_degree_1136  1
    arc_1_18_16  original_T_including_depot_unload_1151  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1041  1
    load_1_18_16  free_load_conservation_1129  -1
    load_1_18_16  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1043  -25
    arc_1_18_17  connected_order_arc_1044  -13
    arc_1_18_17  in_degree_1131  1
    arc_1_18_17  out_degree_1136  1
    arc_1_18_17  original_T_including_depot_unload_1151  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1043  1
    load_1_18_17  free_load_conservation_1135  -1
    load_1_18_17  free_load_conservation_1141  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1045  -25
    arc_1_18_19  connected_order_arc_1046  -13
    arc_1_18_19  out_degree_1136  1
    arc_1_18_19  in_degree_1143  1
    arc_1_18_19  original_T_including_depot_unload_1151  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1045  1
    load_1_18_19  free_load_conservation_1141  1
    load_1_18_19  free_load_conservation_1147  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1047  -25
    arc_1_19_0  depot_return_or_bypass_1071  1
    arc_1_19_0  out_degree_1142  1
    arc_1_19_0  original_T_including_depot_unload_1151  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1047  1
    load_1_19_0  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1048  -25
    arc_1_19_5  connected_order_arc_1049  -13
    arc_1_19_5  in_degree_1073  1
    arc_1_19_5  out_degree_1142  1
    arc_1_19_5  original_T_including_depot_unload_1151  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1048  1
    load_1_19_5  segment_load_conservation_1076  -1
    load_1_19_5  segment_prefix_lb_1077  1
    load_1_19_5  segment_prefix_ub_1078  1
    load_1_19_5  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1050  -25
    arc_1_19_6  connected_order_arc_1051  -13
    arc_1_19_6  in_degree_1080  1
    arc_1_19_6  out_degree_1142  1
    arc_1_19_6  original_T_including_depot_unload_1151  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1050  1
    load_1_19_6  segment_load_conservation_1083  -1
    load_1_19_6  segment_prefix_lb_1084  1
    load_1_19_6  segment_prefix_ub_1085  1
    load_1_19_6  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1052  -25
    arc_1_19_7  connected_order_arc_1053  -13
    arc_1_19_7  in_degree_1087  1
    arc_1_19_7  out_degree_1142  1
    arc_1_19_7  original_T_including_depot_unload_1151  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1052  1
    load_1_19_7  segment_load_conservation_1090  -1
    load_1_19_7  segment_prefix_lb_1091  1
    load_1_19_7  segment_prefix_ub_1092  1
    load_1_19_7  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1054  -25
    arc_1_19_8  connected_order_arc_1055  -13
    arc_1_19_8  in_degree_1094  1
    arc_1_19_8  out_degree_1142  1
    arc_1_19_8  original_T_including_depot_unload_1151  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1054  1
    load_1_19_8  segment_load_conservation_1097  -1
    load_1_19_8  segment_prefix_lb_1098  1
    load_1_19_8  segment_prefix_ub_1099  1
    load_1_19_8  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_12  arc_capacity_1056  -25
    arc_1_19_12  connected_order_arc_1057  -13
    arc_1_19_12  in_degree_1101  1
    arc_1_19_12  out_degree_1142  1
    arc_1_19_12  original_T_including_depot_unload_1151  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_12  arc_capacity_1056  1
    load_1_19_12  free_load_conservation_1105  -1
    load_1_19_12  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_13  arc_capacity_1058  -25
    arc_1_19_13  connected_order_arc_1059  -13
    arc_1_19_13  in_degree_1107  1
    arc_1_19_13  out_degree_1142  1
    arc_1_19_13  original_T_including_depot_unload_1151  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_13  arc_capacity_1058  1
    load_1_19_13  free_load_conservation_1111  -1
    load_1_19_13  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1060  -25
    arc_1_19_14  connected_order_arc_1061  -13
    arc_1_19_14  in_degree_1113  1
    arc_1_19_14  out_degree_1142  1
    arc_1_19_14  original_T_including_depot_unload_1151  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1060  1
    load_1_19_14  free_load_conservation_1117  -1
    load_1_19_14  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1062  -25
    arc_1_19_15  connected_order_arc_1063  -13
    arc_1_19_15  in_degree_1119  1
    arc_1_19_15  out_degree_1142  1
    arc_1_19_15  original_T_including_depot_unload_1151  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1062  1
    load_1_19_15  free_load_conservation_1123  -1
    load_1_19_15  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1064  -25
    arc_1_19_16  connected_order_arc_1065  -13
    arc_1_19_16  in_degree_1125  1
    arc_1_19_16  out_degree_1142  1
    arc_1_19_16  original_T_including_depot_unload_1151  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1064  1
    load_1_19_16  free_load_conservation_1129  -1
    load_1_19_16  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1066  -25
    arc_1_19_17  connected_order_arc_1067  -13
    arc_1_19_17  in_degree_1131  1
    arc_1_19_17  out_degree_1142  1
    arc_1_19_17  original_T_including_depot_unload_1151  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1066  1
    load_1_19_17  free_load_conservation_1135  -1
    load_1_19_17  free_load_conservation_1147  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1068  -25
    arc_1_19_18  connected_order_arc_1069  -13
    arc_1_19_18  in_degree_1137  1
    arc_1_19_18  out_degree_1142  1
    arc_1_19_18  original_T_including_depot_unload_1151  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1068  1
    load_1_19_18  free_load_conservation_1141  -1
    load_1_19_18  free_load_conservation_1147  1
    visit_2_9  out_degree_1397  -1
    visit_2_9  in_degree_1398  -1
    visit_2_9  order_active_lb_1399  -1
    visit_2_9  order_active_ub_1400  -11
    order_2_9  connected_order_arc_1166  -1
    order_2_9  connected_order_arc_1168  -1
    order_2_9  connected_order_arc_1170  -1
    order_2_9  connected_order_arc_1172  -1
    order_2_9  connected_order_arc_1174  -1
    order_2_9  connected_order_arc_1176  -1
    order_2_9  connected_order_arc_1178  -1
    order_2_9  connected_order_arc_1180  -1
    order_2_9  connected_order_arc_1182  -1
    order_2_9  connected_order_arc_1184  -1
    order_2_9  connected_order_arc_1187  1
    order_2_9  connected_order_arc_1208  1
    order_2_9  connected_order_arc_1229  1
    order_2_9  connected_order_arc_1250  1
    order_2_9  connected_order_arc_1271  1
    order_2_9  connected_order_arc_1292  1
    order_2_9  connected_order_arc_1313  1
    order_2_9  connected_order_arc_1334  1
    order_2_9  connected_order_arc_1355  1
    order_2_9  connected_order_arc_1376  1
    order_2_9  order_active_lb_1399  1
    order_2_9  order_active_ub_1400  1
    order_2_9  fixed_segment_relative_order_1466  -1
    visit_2_10  out_degree_1404  -1
    visit_2_10  in_degree_1405  -1
    visit_2_10  order_active_lb_1406  -1
    visit_2_10  order_active_ub_1407  -11
    order_2_10  connected_order_arc_1166  1
    order_2_10  connected_order_arc_1187  -1
    order_2_10  connected_order_arc_1189  -1
    order_2_10  connected_order_arc_1191  -1
    order_2_10  connected_order_arc_1193  -1
    order_2_10  connected_order_arc_1195  -1
    order_2_10  connected_order_arc_1197  -1
    order_2_10  connected_order_arc_1199  -1
    order_2_10  connected_order_arc_1201  -1
    order_2_10  connected_order_arc_1203  -1
    order_2_10  connected_order_arc_1205  -1
    order_2_10  connected_order_arc_1210  1
    order_2_10  connected_order_arc_1231  1
    order_2_10  connected_order_arc_1252  1
    order_2_10  connected_order_arc_1273  1
    order_2_10  connected_order_arc_1294  1
    order_2_10  connected_order_arc_1315  1
    order_2_10  connected_order_arc_1336  1
    order_2_10  connected_order_arc_1357  1
    order_2_10  connected_order_arc_1378  1
    order_2_10  order_active_lb_1406  1
    order_2_10  order_active_ub_1407  1
    order_2_10  fixed_segment_relative_order_1466  1
    order_2_10  fixed_segment_relative_order_1467  -1
    visit_2_11  out_degree_1411  -1
    visit_2_11  in_degree_1412  -1
    visit_2_11  order_active_lb_1413  -1
    visit_2_11  order_active_ub_1414  -11
    order_2_11  connected_order_arc_1168  1
    order_2_11  connected_order_arc_1189  1
    order_2_11  connected_order_arc_1208  -1
    order_2_11  connected_order_arc_1210  -1
    order_2_11  connected_order_arc_1212  -1
    order_2_11  connected_order_arc_1214  -1
    order_2_11  connected_order_arc_1216  -1
    order_2_11  connected_order_arc_1218  -1
    order_2_11  connected_order_arc_1220  -1
    order_2_11  connected_order_arc_1222  -1
    order_2_11  connected_order_arc_1224  -1
    order_2_11  connected_order_arc_1226  -1
    order_2_11  connected_order_arc_1233  1
    order_2_11  connected_order_arc_1254  1
    order_2_11  connected_order_arc_1275  1
    order_2_11  connected_order_arc_1296  1
    order_2_11  connected_order_arc_1317  1
    order_2_11  connected_order_arc_1338  1
    order_2_11  connected_order_arc_1359  1
    order_2_11  connected_order_arc_1380  1
    order_2_11  order_active_lb_1413  1
    order_2_11  order_active_ub_1414  1
    order_2_11  fixed_segment_relative_order_1467  1
    visit_2_12  out_degree_1418  -1
    visit_2_12  in_degree_1419  -1
    visit_2_12  order_active_lb_1420  -1
    visit_2_12  order_active_ub_1421  -11
    visit_2_12  service_visit_def_1422  -1
    order_2_12  connected_order_arc_1170  1
    order_2_12  connected_order_arc_1191  1
    order_2_12  connected_order_arc_1212  1
    order_2_12  connected_order_arc_1229  -1
    order_2_12  connected_order_arc_1231  -1
    order_2_12  connected_order_arc_1233  -1
    order_2_12  connected_order_arc_1235  -1
    order_2_12  connected_order_arc_1237  -1
    order_2_12  connected_order_arc_1239  -1
    order_2_12  connected_order_arc_1241  -1
    order_2_12  connected_order_arc_1243  -1
    order_2_12  connected_order_arc_1245  -1
    order_2_12  connected_order_arc_1247  -1
    order_2_12  connected_order_arc_1256  1
    order_2_12  connected_order_arc_1277  1
    order_2_12  connected_order_arc_1298  1
    order_2_12  connected_order_arc_1319  1
    order_2_12  connected_order_arc_1340  1
    order_2_12  connected_order_arc_1361  1
    order_2_12  connected_order_arc_1382  1
    order_2_12  order_active_lb_1420  1
    order_2_12  order_active_ub_1421  1
    visit_2_13  out_degree_1424  -1
    visit_2_13  in_degree_1425  -1
    visit_2_13  order_active_lb_1426  -1
    visit_2_13  order_active_ub_1427  -11
    visit_2_13  service_visit_def_1428  -1
    order_2_13  connected_order_arc_1172  1
    order_2_13  connected_order_arc_1193  1
    order_2_13  connected_order_arc_1214  1
    order_2_13  connected_order_arc_1235  1
    order_2_13  connected_order_arc_1250  -1
    order_2_13  connected_order_arc_1252  -1
    order_2_13  connected_order_arc_1254  -1
    order_2_13  connected_order_arc_1256  -1
    order_2_13  connected_order_arc_1258  -1
    order_2_13  connected_order_arc_1260  -1
    order_2_13  connected_order_arc_1262  -1
    order_2_13  connected_order_arc_1264  -1
    order_2_13  connected_order_arc_1266  -1
    order_2_13  connected_order_arc_1268  -1
    order_2_13  connected_order_arc_1279  1
    order_2_13  connected_order_arc_1300  1
    order_2_13  connected_order_arc_1321  1
    order_2_13  connected_order_arc_1342  1
    order_2_13  connected_order_arc_1363  1
    order_2_13  connected_order_arc_1384  1
    order_2_13  order_active_lb_1426  1
    order_2_13  order_active_ub_1427  1
    visit_2_14  out_degree_1430  -1
    visit_2_14  in_degree_1431  -1
    visit_2_14  order_active_lb_1432  -1
    visit_2_14  order_active_ub_1433  -11
    visit_2_14  service_visit_def_1434  -1
    order_2_14  connected_order_arc_1174  1
    order_2_14  connected_order_arc_1195  1
    order_2_14  connected_order_arc_1216  1
    order_2_14  connected_order_arc_1237  1
    order_2_14  connected_order_arc_1258  1
    order_2_14  connected_order_arc_1271  -1
    order_2_14  connected_order_arc_1273  -1
    order_2_14  connected_order_arc_1275  -1
    order_2_14  connected_order_arc_1277  -1
    order_2_14  connected_order_arc_1279  -1
    order_2_14  connected_order_arc_1281  -1
    order_2_14  connected_order_arc_1283  -1
    order_2_14  connected_order_arc_1285  -1
    order_2_14  connected_order_arc_1287  -1
    order_2_14  connected_order_arc_1289  -1
    order_2_14  connected_order_arc_1302  1
    order_2_14  connected_order_arc_1323  1
    order_2_14  connected_order_arc_1344  1
    order_2_14  connected_order_arc_1365  1
    order_2_14  connected_order_arc_1386  1
    order_2_14  order_active_lb_1432  1
    order_2_14  order_active_ub_1433  1
    visit_2_15  out_degree_1436  -1
    visit_2_15  in_degree_1437  -1
    visit_2_15  order_active_lb_1438  -1
    visit_2_15  order_active_ub_1439  -11
    visit_2_15  service_visit_def_1440  -1
    order_2_15  connected_order_arc_1176  1
    order_2_15  connected_order_arc_1197  1
    order_2_15  connected_order_arc_1218  1
    order_2_15  connected_order_arc_1239  1
    order_2_15  connected_order_arc_1260  1
    order_2_15  connected_order_arc_1281  1
    order_2_15  connected_order_arc_1292  -1
    order_2_15  connected_order_arc_1294  -1
    order_2_15  connected_order_arc_1296  -1
    order_2_15  connected_order_arc_1298  -1
    order_2_15  connected_order_arc_1300  -1
    order_2_15  connected_order_arc_1302  -1
    order_2_15  connected_order_arc_1304  -1
    order_2_15  connected_order_arc_1306  -1
    order_2_15  connected_order_arc_1308  -1
    order_2_15  connected_order_arc_1310  -1
    order_2_15  connected_order_arc_1325  1
    order_2_15  connected_order_arc_1346  1
    order_2_15  connected_order_arc_1367  1
    order_2_15  connected_order_arc_1388  1
    order_2_15  order_active_lb_1438  1
    order_2_15  order_active_ub_1439  1
    visit_2_16  out_degree_1442  -1
    visit_2_16  in_degree_1443  -1
    visit_2_16  order_active_lb_1444  -1
    visit_2_16  order_active_ub_1445  -11
    visit_2_16  service_visit_def_1446  -1
    order_2_16  connected_order_arc_1178  1
    order_2_16  connected_order_arc_1199  1
    order_2_16  connected_order_arc_1220  1
    order_2_16  connected_order_arc_1241  1
    order_2_16  connected_order_arc_1262  1
    order_2_16  connected_order_arc_1283  1
    order_2_16  connected_order_arc_1304  1
    order_2_16  connected_order_arc_1313  -1
    order_2_16  connected_order_arc_1315  -1
    order_2_16  connected_order_arc_1317  -1
    order_2_16  connected_order_arc_1319  -1
    order_2_16  connected_order_arc_1321  -1
    order_2_16  connected_order_arc_1323  -1
    order_2_16  connected_order_arc_1325  -1
    order_2_16  connected_order_arc_1327  -1
    order_2_16  connected_order_arc_1329  -1
    order_2_16  connected_order_arc_1331  -1
    order_2_16  connected_order_arc_1348  1
    order_2_16  connected_order_arc_1369  1
    order_2_16  connected_order_arc_1390  1
    order_2_16  order_active_lb_1444  1
    order_2_16  order_active_ub_1445  1
    visit_2_17  out_degree_1448  -1
    visit_2_17  in_degree_1449  -1
    visit_2_17  order_active_lb_1450  -1
    visit_2_17  order_active_ub_1451  -11
    visit_2_17  service_visit_def_1452  -1
    order_2_17  connected_order_arc_1180  1
    order_2_17  connected_order_arc_1201  1
    order_2_17  connected_order_arc_1222  1
    order_2_17  connected_order_arc_1243  1
    order_2_17  connected_order_arc_1264  1
    order_2_17  connected_order_arc_1285  1
    order_2_17  connected_order_arc_1306  1
    order_2_17  connected_order_arc_1327  1
    order_2_17  connected_order_arc_1334  -1
    order_2_17  connected_order_arc_1336  -1
    order_2_17  connected_order_arc_1338  -1
    order_2_17  connected_order_arc_1340  -1
    order_2_17  connected_order_arc_1342  -1
    order_2_17  connected_order_arc_1344  -1
    order_2_17  connected_order_arc_1346  -1
    order_2_17  connected_order_arc_1348  -1
    order_2_17  connected_order_arc_1350  -1
    order_2_17  connected_order_arc_1352  -1
    order_2_17  connected_order_arc_1371  1
    order_2_17  connected_order_arc_1392  1
    order_2_17  order_active_lb_1450  1
    order_2_17  order_active_ub_1451  1
    visit_2_18  out_degree_1454  -1
    visit_2_18  in_degree_1455  -1
    visit_2_18  order_active_lb_1456  -1
    visit_2_18  order_active_ub_1457  -11
    visit_2_18  service_visit_def_1458  -1
    order_2_18  connected_order_arc_1182  1
    order_2_18  connected_order_arc_1203  1
    order_2_18  connected_order_arc_1224  1
    order_2_18  connected_order_arc_1245  1
    order_2_18  connected_order_arc_1266  1
    order_2_18  connected_order_arc_1287  1
    order_2_18  connected_order_arc_1308  1
    order_2_18  connected_order_arc_1329  1
    order_2_18  connected_order_arc_1350  1
    order_2_18  connected_order_arc_1355  -1
    order_2_18  connected_order_arc_1357  -1
    order_2_18  connected_order_arc_1359  -1
    order_2_18  connected_order_arc_1361  -1
    order_2_18  connected_order_arc_1363  -1
    order_2_18  connected_order_arc_1365  -1
    order_2_18  connected_order_arc_1367  -1
    order_2_18  connected_order_arc_1369  -1
    order_2_18  connected_order_arc_1371  -1
    order_2_18  connected_order_arc_1373  -1
    order_2_18  connected_order_arc_1394  1
    order_2_18  order_active_lb_1456  1
    order_2_18  order_active_ub_1457  1
    visit_2_19  out_degree_1460  -1
    visit_2_19  in_degree_1461  -1
    visit_2_19  order_active_lb_1462  -1
    visit_2_19  order_active_ub_1463  -11
    visit_2_19  service_visit_def_1464  -1
    order_2_19  connected_order_arc_1184  1
    order_2_19  connected_order_arc_1205  1
    order_2_19  connected_order_arc_1226  1
    order_2_19  connected_order_arc_1247  1
    order_2_19  connected_order_arc_1268  1
    order_2_19  connected_order_arc_1289  1
    order_2_19  connected_order_arc_1310  1
    order_2_19  connected_order_arc_1331  1
    order_2_19  connected_order_arc_1352  1
    order_2_19  connected_order_arc_1373  1
    order_2_19  connected_order_arc_1376  -1
    order_2_19  connected_order_arc_1378  -1
    order_2_19  connected_order_arc_1380  -1
    order_2_19  connected_order_arc_1382  -1
    order_2_19  connected_order_arc_1384  -1
    order_2_19  connected_order_arc_1386  -1
    order_2_19  connected_order_arc_1388  -1
    order_2_19  connected_order_arc_1390  -1
    order_2_19  connected_order_arc_1392  -1
    order_2_19  connected_order_arc_1394  -1
    order_2_19  order_active_lb_1462  1
    order_2_19  order_active_ub_1463  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1152  -30
    arc_2_0_0  depot_departure_or_bypass_1395  1
    arc_2_0_0  depot_return_or_bypass_1396  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1152  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_9  arc_capacity_1153  -30
    arc_2_0_9  depot_departure_or_bypass_1395  1
    arc_2_0_9  in_degree_1398  1
    arc_2_0_9  original_T_including_depot_unload_1468  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_9  arc_capacity_1153  1
    load_2_0_9  segment_load_conservation_1401  -1
    load_2_0_9  segment_prefix_lb_1402  1
    load_2_0_9  segment_prefix_ub_1403  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1154  -30
    arc_2_0_10  depot_departure_or_bypass_1395  1
    arc_2_0_10  in_degree_1405  1
    arc_2_0_10  original_T_including_depot_unload_1468  1.2898901502795654e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1154  1
    load_2_0_10  segment_load_conservation_1408  -1
    load_2_0_10  segment_prefix_lb_1409  1
    load_2_0_10  segment_prefix_ub_1410  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1155  -30
    arc_2_0_11  depot_departure_or_bypass_1395  1
    arc_2_0_11  in_degree_1412  1
    arc_2_0_11  original_T_including_depot_unload_1468  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1155  1
    load_2_0_11  segment_load_conservation_1415  -1
    load_2_0_11  segment_prefix_lb_1416  1
    load_2_0_11  segment_prefix_ub_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1156  -30
    arc_2_0_12  depot_departure_or_bypass_1395  1
    arc_2_0_12  in_degree_1419  1
    arc_2_0_12  original_T_including_depot_unload_1468  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1156  1
    load_2_0_12  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1157  -30
    arc_2_0_13  depot_departure_or_bypass_1395  1
    arc_2_0_13  in_degree_1425  1
    arc_2_0_13  original_T_including_depot_unload_1468  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1157  1
    load_2_0_13  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1158  -30
    arc_2_0_14  depot_departure_or_bypass_1395  1
    arc_2_0_14  in_degree_1431  1
    arc_2_0_14  original_T_including_depot_unload_1468  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1158  1
    load_2_0_14  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1159  -30
    arc_2_0_15  depot_departure_or_bypass_1395  1
    arc_2_0_15  in_degree_1437  1
    arc_2_0_15  original_T_including_depot_unload_1468  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1159  1
    load_2_0_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1160  -30
    arc_2_0_16  depot_departure_or_bypass_1395  1
    arc_2_0_16  in_degree_1443  1
    arc_2_0_16  original_T_including_depot_unload_1468  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1160  1
    load_2_0_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1161  -30
    arc_2_0_17  depot_departure_or_bypass_1395  1
    arc_2_0_17  in_degree_1449  1
    arc_2_0_17  original_T_including_depot_unload_1468  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1161  1
    load_2_0_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1162  -30
    arc_2_0_18  depot_departure_or_bypass_1395  1
    arc_2_0_18  in_degree_1455  1
    arc_2_0_18  original_T_including_depot_unload_1468  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1162  1
    load_2_0_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1163  -30
    arc_2_0_19  depot_departure_or_bypass_1395  1
    arc_2_0_19  in_degree_1461  1
    arc_2_0_19  original_T_including_depot_unload_1468  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1163  1
    load_2_0_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_0  arc_capacity_1164  -30
    arc_2_9_0  depot_return_or_bypass_1396  1
    arc_2_9_0  out_degree_1397  1
    arc_2_9_0  original_T_including_depot_unload_1468  9.5330620720858735e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_9_0  arc_capacity_1164  1
    load_2_9_0  segment_load_conservation_1401  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_10  arc_capacity_1165  -30
    arc_2_9_10  connected_order_arc_1166  -12
    arc_2_9_10  out_degree_1397  1
    arc_2_9_10  in_degree_1405  1
    arc_2_9_10  original_T_including_depot_unload_1468  1.5797541979515834e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_10  arc_capacity_1165  1
    load_2_9_10  segment_load_conservation_1401  1
    load_2_9_10  segment_load_conservation_1408  -1
    load_2_9_10  segment_prefix_lb_1409  1
    load_2_9_10  segment_prefix_ub_1410  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_11  arc_capacity_1167  -30
    arc_2_9_11  connected_order_arc_1168  -12
    arc_2_9_11  out_degree_1397  1
    arc_2_9_11  in_degree_1412  1
    arc_2_9_11  original_T_including_depot_unload_1468  1.0783470469841145e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_11  arc_capacity_1167  1
    load_2_9_11  segment_load_conservation_1401  1
    load_2_9_11  segment_load_conservation_1415  -1
    load_2_9_11  segment_prefix_lb_1416  1
    load_2_9_11  segment_prefix_ub_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_12  arc_capacity_1169  -30
    arc_2_9_12  connected_order_arc_1170  -12
    arc_2_9_12  out_degree_1397  1
    arc_2_9_12  in_degree_1419  1
    arc_2_9_12  original_T_including_depot_unload_1468  1.8269270746185791e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_12  arc_capacity_1169  1
    load_2_9_12  segment_load_conservation_1401  1
    load_2_9_12  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_13  arc_capacity_1171  -30
    arc_2_9_13  connected_order_arc_1172  -12
    arc_2_9_13  out_degree_1397  1
    arc_2_9_13  in_degree_1425  1
    arc_2_9_13  original_T_including_depot_unload_1468  1.9482201819157062e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_13  arc_capacity_1171  1
    load_2_9_13  segment_load_conservation_1401  1
    load_2_9_13  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_14  arc_capacity_1173  -30
    arc_2_9_14  connected_order_arc_1174  -12
    arc_2_9_14  out_degree_1397  1
    arc_2_9_14  in_degree_1431  1
    arc_2_9_14  original_T_including_depot_unload_1468  1.9462564869425171e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_14  arc_capacity_1173  1
    load_2_9_14  segment_load_conservation_1401  1
    load_2_9_14  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_15  arc_capacity_1175  -30
    arc_2_9_15  connected_order_arc_1176  -12
    arc_2_9_15  out_degree_1397  1
    arc_2_9_15  in_degree_1437  1
    arc_2_9_15  original_T_including_depot_unload_1468  1.9981042624472673e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_15  arc_capacity_1175  1
    load_2_9_15  segment_load_conservation_1401  1
    load_2_9_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_16  arc_capacity_1177  -30
    arc_2_9_16  connected_order_arc_1178  -12
    arc_2_9_16  out_degree_1397  1
    arc_2_9_16  in_degree_1443  1
    arc_2_9_16  original_T_including_depot_unload_1468  1.5117151439160034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_16  arc_capacity_1177  1
    load_2_9_16  segment_load_conservation_1401  1
    load_2_9_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_17  arc_capacity_1179  -30
    arc_2_9_17  connected_order_arc_1180  -12
    arc_2_9_17  out_degree_1397  1
    arc_2_9_17  in_degree_1449  1
    arc_2_9_17  original_T_including_depot_unload_1468  1.8130068061837439e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_17  arc_capacity_1179  1
    load_2_9_17  segment_load_conservation_1401  1
    load_2_9_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_18  arc_capacity_1181  -30
    arc_2_9_18  connected_order_arc_1182  -12
    arc_2_9_18  out_degree_1397  1
    arc_2_9_18  in_degree_1455  1
    arc_2_9_18  original_T_including_depot_unload_1468  1.0105932041904148e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_18  arc_capacity_1181  1
    load_2_9_18  segment_load_conservation_1401  1
    load_2_9_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_9_19  arc_capacity_1183  -30
    arc_2_9_19  connected_order_arc_1184  -12
    arc_2_9_19  out_degree_1397  1
    arc_2_9_19  in_degree_1461  1
    arc_2_9_19  original_T_including_depot_unload_1468  2.1849202034001414e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_9_19  arc_capacity_1183  1
    load_2_9_19  segment_load_conservation_1401  1
    load_2_9_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1185  -30
    arc_2_10_0  depot_return_or_bypass_1396  1
    arc_2_10_0  out_degree_1404  1
    arc_2_10_0  original_T_including_depot_unload_1468  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1185  1
    load_2_10_0  segment_load_conservation_1408  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_9  arc_capacity_1186  -30
    arc_2_10_9  connected_order_arc_1187  -12
    arc_2_10_9  in_degree_1398  1
    arc_2_10_9  out_degree_1404  1
    arc_2_10_9  original_T_including_depot_unload_1468  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_9  arc_capacity_1186  1
    load_2_10_9  segment_load_conservation_1401  -1
    load_2_10_9  segment_prefix_lb_1402  1
    load_2_10_9  segment_prefix_ub_1403  1
    load_2_10_9  segment_load_conservation_1408  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1188  -30
    arc_2_10_11  connected_order_arc_1189  -12
    arc_2_10_11  out_degree_1404  1
    arc_2_10_11  in_degree_1412  1
    arc_2_10_11  original_T_including_depot_unload_1468  1.4472076573979532e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1188  1
    load_2_10_11  segment_load_conservation_1408  1
    load_2_10_11  segment_load_conservation_1415  -1
    load_2_10_11  segment_prefix_lb_1416  1
    load_2_10_11  segment_prefix_ub_1417  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1190  -30
    arc_2_10_12  connected_order_arc_1191  -12
    arc_2_10_12  out_degree_1404  1
    arc_2_10_12  in_degree_1419  1
    arc_2_10_12  original_T_including_depot_unload_1468  1.7809992976396034e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1190  1
    load_2_10_12  segment_load_conservation_1408  1
    load_2_10_12  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1192  -30
    arc_2_10_13  connected_order_arc_1193  -12
    arc_2_10_13  out_degree_1404  1
    arc_2_10_13  in_degree_1425  1
    arc_2_10_13  original_T_including_depot_unload_1468  1.9434430494183746e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1192  1
    load_2_10_13  segment_load_conservation_1408  1
    load_2_10_13  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1194  -30
    arc_2_10_14  connected_order_arc_1195  -12
    arc_2_10_14  out_degree_1404  1
    arc_2_10_14  in_degree_1431  1
    arc_2_10_14  original_T_including_depot_unload_1468  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1194  1
    load_2_10_14  segment_load_conservation_1408  1
    load_2_10_14  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1196  -30
    arc_2_10_15  connected_order_arc_1197  -12
    arc_2_10_15  out_degree_1404  1
    arc_2_10_15  in_degree_1437  1
    arc_2_10_15  original_T_including_depot_unload_1468  1.6785246977297163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1196  1
    load_2_10_15  segment_load_conservation_1408  1
    load_2_10_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1198  -30
    arc_2_10_16  connected_order_arc_1199  -12
    arc_2_10_16  out_degree_1404  1
    arc_2_10_16  in_degree_1443  1
    arc_2_10_16  original_T_including_depot_unload_1468  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1198  1
    load_2_10_16  segment_load_conservation_1408  1
    load_2_10_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1200  -30
    arc_2_10_17  connected_order_arc_1201  -12
    arc_2_10_17  out_degree_1404  1
    arc_2_10_17  in_degree_1449  1
    arc_2_10_17  original_T_including_depot_unload_1468  1.4516198129136008e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1200  1
    load_2_10_17  segment_load_conservation_1408  1
    load_2_10_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1202  -30
    arc_2_10_18  connected_order_arc_1203  -12
    arc_2_10_18  out_degree_1404  1
    arc_2_10_18  in_degree_1455  1
    arc_2_10_18  original_T_including_depot_unload_1468  8.0219422833177862e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1202  1
    load_2_10_18  segment_load_conservation_1408  1
    load_2_10_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1204  -30
    arc_2_10_19  connected_order_arc_1205  -12
    arc_2_10_19  out_degree_1404  1
    arc_2_10_19  in_degree_1461  1
    arc_2_10_19  original_T_including_depot_unload_1468  2.2638184459267368e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1204  1
    load_2_10_19  segment_load_conservation_1408  1
    load_2_10_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1206  -30
    arc_2_11_0  depot_return_or_bypass_1396  1
    arc_2_11_0  out_degree_1411  1
    arc_2_11_0  original_T_including_depot_unload_1468  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1206  1
    load_2_11_0  segment_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_9  arc_capacity_1207  -30
    arc_2_11_9  connected_order_arc_1208  -12
    arc_2_11_9  in_degree_1398  1
    arc_2_11_9  out_degree_1411  1
    arc_2_11_9  original_T_including_depot_unload_1468  359.975566576564
    MARKER    'MARKER'                 'INTEND'
    load_2_11_9  arc_capacity_1207  1
    load_2_11_9  segment_load_conservation_1401  -1
    load_2_11_9  segment_prefix_lb_1402  1
    load_2_11_9  segment_prefix_ub_1403  1
    load_2_11_9  segment_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1209  -30
    arc_2_11_10  connected_order_arc_1210  -12
    arc_2_11_10  in_degree_1405  1
    arc_2_11_10  out_degree_1411  1
    arc_2_11_10  original_T_including_depot_unload_1468  1.2875945644569279e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1209  1
    load_2_11_10  segment_load_conservation_1408  -1
    load_2_11_10  segment_prefix_lb_1409  1
    load_2_11_10  segment_prefix_ub_1410  1
    load_2_11_10  segment_load_conservation_1415  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1211  -30
    arc_2_11_12  connected_order_arc_1212  -12
    arc_2_11_12  out_degree_1411  1
    arc_2_11_12  in_degree_1419  1
    arc_2_11_12  original_T_including_depot_unload_1468  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1211  1
    load_2_11_12  segment_load_conservation_1415  1
    load_2_11_12  free_load_conservation_1423  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1213  -30
    arc_2_11_13  connected_order_arc_1214  -12
    arc_2_11_13  out_degree_1411  1
    arc_2_11_13  in_degree_1425  1
    arc_2_11_13  original_T_including_depot_unload_1468  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1213  1
    load_2_11_13  segment_load_conservation_1415  1
    load_2_11_13  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1215  -30
    arc_2_11_14  connected_order_arc_1216  -12
    arc_2_11_14  out_degree_1411  1
    arc_2_11_14  in_degree_1431  1
    arc_2_11_14  original_T_including_depot_unload_1468  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1215  1
    load_2_11_14  segment_load_conservation_1415  1
    load_2_11_14  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1217  -30
    arc_2_11_15  connected_order_arc_1218  -12
    arc_2_11_15  out_degree_1411  1
    arc_2_11_15  in_degree_1437  1
    arc_2_11_15  original_T_including_depot_unload_1468  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1217  1
    load_2_11_15  segment_load_conservation_1415  1
    load_2_11_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1219  -30
    arc_2_11_16  connected_order_arc_1220  -12
    arc_2_11_16  out_degree_1411  1
    arc_2_11_16  in_degree_1443  1
    arc_2_11_16  original_T_including_depot_unload_1468  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1219  1
    load_2_11_16  segment_load_conservation_1415  1
    load_2_11_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1221  -30
    arc_2_11_17  connected_order_arc_1222  -12
    arc_2_11_17  out_degree_1411  1
    arc_2_11_17  in_degree_1449  1
    arc_2_11_17  original_T_including_depot_unload_1468  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1221  1
    load_2_11_17  segment_load_conservation_1415  1
    load_2_11_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1223  -30
    arc_2_11_18  connected_order_arc_1224  -12
    arc_2_11_18  out_degree_1411  1
    arc_2_11_18  in_degree_1455  1
    arc_2_11_18  original_T_including_depot_unload_1468  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1223  1
    load_2_11_18  segment_load_conservation_1415  1
    load_2_11_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1225  -30
    arc_2_11_19  connected_order_arc_1226  -12
    arc_2_11_19  out_degree_1411  1
    arc_2_11_19  in_degree_1461  1
    arc_2_11_19  original_T_including_depot_unload_1468  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1225  1
    load_2_11_19  segment_load_conservation_1415  1
    load_2_11_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1227  -30
    arc_2_12_0  depot_return_or_bypass_1396  1
    arc_2_12_0  out_degree_1418  1
    arc_2_12_0  original_T_including_depot_unload_1468  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1227  1
    load_2_12_0  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_9  arc_capacity_1228  -30
    arc_2_12_9  connected_order_arc_1229  -12
    arc_2_12_9  in_degree_1398  1
    arc_2_12_9  out_degree_1418  1
    arc_2_12_9  original_T_including_depot_unload_1468  1.1005939447212634e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_9  arc_capacity_1228  1
    load_2_12_9  segment_load_conservation_1401  -1
    load_2_12_9  segment_prefix_lb_1402  1
    load_2_12_9  segment_prefix_ub_1403  1
    load_2_12_9  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1230  -30
    arc_2_12_10  connected_order_arc_1231  -12
    arc_2_12_10  in_degree_1405  1
    arc_2_12_10  out_degree_1418  1
    arc_2_12_10  original_T_including_depot_unload_1468  1.6726682877661206e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1230  1
    load_2_12_10  segment_load_conservation_1408  -1
    load_2_12_10  segment_prefix_lb_1409  1
    load_2_12_10  segment_prefix_ub_1410  1
    load_2_12_10  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1232  -30
    arc_2_12_11  connected_order_arc_1233  -12
    arc_2_12_11  in_degree_1412  1
    arc_2_12_11  out_degree_1418  1
    arc_2_12_11  original_T_including_depot_unload_1468  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1232  1
    load_2_12_11  segment_load_conservation_1415  -1
    load_2_12_11  segment_prefix_lb_1416  1
    load_2_12_11  segment_prefix_ub_1417  1
    load_2_12_11  free_load_conservation_1423  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1234  -30
    arc_2_12_13  connected_order_arc_1235  -12
    arc_2_12_13  out_degree_1418  1
    arc_2_12_13  in_degree_1425  1
    arc_2_12_13  original_T_including_depot_unload_1468  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1234  1
    load_2_12_13  free_load_conservation_1423  1
    load_2_12_13  free_load_conservation_1429  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1236  -30
    arc_2_12_14  connected_order_arc_1237  -12
    arc_2_12_14  out_degree_1418  1
    arc_2_12_14  in_degree_1431  1
    arc_2_12_14  original_T_including_depot_unload_1468  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1236  1
    load_2_12_14  free_load_conservation_1423  1
    load_2_12_14  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1238  -30
    arc_2_12_15  connected_order_arc_1239  -12
    arc_2_12_15  out_degree_1418  1
    arc_2_12_15  in_degree_1437  1
    arc_2_12_15  original_T_including_depot_unload_1468  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1238  1
    load_2_12_15  free_load_conservation_1423  1
    load_2_12_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1240  -30
    arc_2_12_16  connected_order_arc_1241  -12
    arc_2_12_16  out_degree_1418  1
    arc_2_12_16  in_degree_1443  1
    arc_2_12_16  original_T_including_depot_unload_1468  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1240  1
    load_2_12_16  free_load_conservation_1423  1
    load_2_12_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1242  -30
    arc_2_12_17  connected_order_arc_1243  -12
    arc_2_12_17  out_degree_1418  1
    arc_2_12_17  in_degree_1449  1
    arc_2_12_17  original_T_including_depot_unload_1468  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1242  1
    load_2_12_17  free_load_conservation_1423  1
    load_2_12_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1244  -30
    arc_2_12_18  connected_order_arc_1245  -12
    arc_2_12_18  out_degree_1418  1
    arc_2_12_18  in_degree_1455  1
    arc_2_12_18  original_T_including_depot_unload_1468  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1244  1
    load_2_12_18  free_load_conservation_1423  1
    load_2_12_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1246  -30
    arc_2_12_19  connected_order_arc_1247  -12
    arc_2_12_19  out_degree_1418  1
    arc_2_12_19  in_degree_1461  1
    arc_2_12_19  original_T_including_depot_unload_1468  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1246  1
    load_2_12_19  free_load_conservation_1423  1
    load_2_12_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1248  -30
    arc_2_13_0  depot_return_or_bypass_1396  1
    arc_2_13_0  out_degree_1424  1
    arc_2_13_0  original_T_including_depot_unload_1468  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1248  1
    load_2_13_0  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_9  arc_capacity_1249  -30
    arc_2_13_9  connected_order_arc_1250  -12
    arc_2_13_9  in_degree_1398  1
    arc_2_13_9  out_degree_1424  1
    arc_2_13_9  original_T_including_depot_unload_1468  1.2442780266664952e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_9  arc_capacity_1249  1
    load_2_13_9  segment_load_conservation_1401  -1
    load_2_13_9  segment_prefix_lb_1402  1
    load_2_13_9  segment_prefix_ub_1403  1
    load_2_13_9  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1251  -30
    arc_2_13_10  connected_order_arc_1252  -12
    arc_2_13_10  in_degree_1405  1
    arc_2_13_10  out_degree_1424  1
    arc_2_13_10  original_T_including_depot_unload_1468  1.8375396100269363e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1251  1
    load_2_13_10  segment_load_conservation_1408  -1
    load_2_13_10  segment_prefix_lb_1409  1
    load_2_13_10  segment_prefix_ub_1410  1
    load_2_13_10  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1253  -30
    arc_2_13_11  connected_order_arc_1254  -12
    arc_2_13_11  in_degree_1412  1
    arc_2_13_11  out_degree_1424  1
    arc_2_13_11  original_T_including_depot_unload_1468  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1253  1
    load_2_13_11  segment_load_conservation_1415  -1
    load_2_13_11  segment_prefix_lb_1416  1
    load_2_13_11  segment_prefix_ub_1417  1
    load_2_13_11  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1255  -30
    arc_2_13_12  connected_order_arc_1256  -12
    arc_2_13_12  in_degree_1419  1
    arc_2_13_12  out_degree_1424  1
    arc_2_13_12  original_T_including_depot_unload_1468  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1255  1
    load_2_13_12  free_load_conservation_1423  -1
    load_2_13_12  free_load_conservation_1429  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1257  -30
    arc_2_13_14  connected_order_arc_1258  -12
    arc_2_13_14  out_degree_1424  1
    arc_2_13_14  in_degree_1431  1
    arc_2_13_14  original_T_including_depot_unload_1468  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1257  1
    load_2_13_14  free_load_conservation_1429  1
    load_2_13_14  free_load_conservation_1435  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1259  -30
    arc_2_13_15  connected_order_arc_1260  -12
    arc_2_13_15  out_degree_1424  1
    arc_2_13_15  in_degree_1437  1
    arc_2_13_15  original_T_including_depot_unload_1468  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1259  1
    load_2_13_15  free_load_conservation_1429  1
    load_2_13_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1261  -30
    arc_2_13_16  connected_order_arc_1262  -12
    arc_2_13_16  out_degree_1424  1
    arc_2_13_16  in_degree_1443  1
    arc_2_13_16  original_T_including_depot_unload_1468  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1261  1
    load_2_13_16  free_load_conservation_1429  1
    load_2_13_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1263  -30
    arc_2_13_17  connected_order_arc_1264  -12
    arc_2_13_17  out_degree_1424  1
    arc_2_13_17  in_degree_1449  1
    arc_2_13_17  original_T_including_depot_unload_1468  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1263  1
    load_2_13_17  free_load_conservation_1429  1
    load_2_13_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1265  -30
    arc_2_13_18  connected_order_arc_1266  -12
    arc_2_13_18  out_degree_1424  1
    arc_2_13_18  in_degree_1455  1
    arc_2_13_18  original_T_including_depot_unload_1468  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1265  1
    load_2_13_18  free_load_conservation_1429  1
    load_2_13_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1267  -30
    arc_2_13_19  connected_order_arc_1268  -12
    arc_2_13_19  out_degree_1424  1
    arc_2_13_19  in_degree_1461  1
    arc_2_13_19  original_T_including_depot_unload_1468  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1267  1
    load_2_13_19  free_load_conservation_1429  1
    load_2_13_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1269  -30
    arc_2_14_0  depot_return_or_bypass_1396  1
    arc_2_14_0  out_degree_1430  1
    arc_2_14_0  original_T_including_depot_unload_1468  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1269  1
    load_2_14_0  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_9  arc_capacity_1270  -30
    arc_2_14_9  connected_order_arc_1271  -12
    arc_2_14_9  in_degree_1398  1
    arc_2_14_9  out_degree_1430  1
    arc_2_14_9  original_T_including_depot_unload_1468  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_9  arc_capacity_1270  1
    load_2_14_9  segment_load_conservation_1401  -1
    load_2_14_9  segment_prefix_lb_1402  1
    load_2_14_9  segment_prefix_ub_1403  1
    load_2_14_9  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1272  -30
    arc_2_14_10  connected_order_arc_1273  -12
    arc_2_14_10  in_degree_1405  1
    arc_2_14_10  out_degree_1430  1
    arc_2_14_10  original_T_including_depot_unload_1468  1.1490429395374924e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1272  1
    load_2_14_10  segment_load_conservation_1408  -1
    load_2_14_10  segment_prefix_lb_1409  1
    load_2_14_10  segment_prefix_ub_1410  1
    load_2_14_10  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1274  -30
    arc_2_14_11  connected_order_arc_1275  -12
    arc_2_14_11  in_degree_1412  1
    arc_2_14_11  out_degree_1430  1
    arc_2_14_11  original_T_including_depot_unload_1468  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1274  1
    load_2_14_11  segment_load_conservation_1415  -1
    load_2_14_11  segment_prefix_lb_1416  1
    load_2_14_11  segment_prefix_ub_1417  1
    load_2_14_11  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1276  -30
    arc_2_14_12  connected_order_arc_1277  -12
    arc_2_14_12  in_degree_1419  1
    arc_2_14_12  out_degree_1430  1
    arc_2_14_12  original_T_including_depot_unload_1468  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1276  1
    load_2_14_12  free_load_conservation_1423  -1
    load_2_14_12  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1278  -30
    arc_2_14_13  connected_order_arc_1279  -12
    arc_2_14_13  in_degree_1425  1
    arc_2_14_13  out_degree_1430  1
    arc_2_14_13  original_T_including_depot_unload_1468  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1278  1
    load_2_14_13  free_load_conservation_1429  -1
    load_2_14_13  free_load_conservation_1435  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1280  -30
    arc_2_14_15  connected_order_arc_1281  -12
    arc_2_14_15  out_degree_1430  1
    arc_2_14_15  in_degree_1437  1
    arc_2_14_15  original_T_including_depot_unload_1468  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1280  1
    load_2_14_15  free_load_conservation_1435  1
    load_2_14_15  free_load_conservation_1441  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1282  -30
    arc_2_14_16  connected_order_arc_1283  -12
    arc_2_14_16  out_degree_1430  1
    arc_2_14_16  in_degree_1443  1
    arc_2_14_16  original_T_including_depot_unload_1468  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1282  1
    load_2_14_16  free_load_conservation_1435  1
    load_2_14_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1284  -30
    arc_2_14_17  connected_order_arc_1285  -12
    arc_2_14_17  out_degree_1430  1
    arc_2_14_17  in_degree_1449  1
    arc_2_14_17  original_T_including_depot_unload_1468  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1284  1
    load_2_14_17  free_load_conservation_1435  1
    load_2_14_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1286  -30
    arc_2_14_18  connected_order_arc_1287  -12
    arc_2_14_18  out_degree_1430  1
    arc_2_14_18  in_degree_1455  1
    arc_2_14_18  original_T_including_depot_unload_1468  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1286  1
    load_2_14_18  free_load_conservation_1435  1
    load_2_14_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1288  -30
    arc_2_14_19  connected_order_arc_1289  -12
    arc_2_14_19  out_degree_1430  1
    arc_2_14_19  in_degree_1461  1
    arc_2_14_19  original_T_including_depot_unload_1468  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1288  1
    load_2_14_19  free_load_conservation_1435  1
    load_2_14_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1290  -30
    arc_2_15_0  depot_return_or_bypass_1396  1
    arc_2_15_0  out_degree_1436  1
    arc_2_15_0  original_T_including_depot_unload_1468  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1290  1
    load_2_15_0  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_9  arc_capacity_1291  -30
    arc_2_15_9  connected_order_arc_1292  -12
    arc_2_15_9  in_degree_1398  1
    arc_2_15_9  out_degree_1436  1
    arc_2_15_9  original_T_including_depot_unload_1468  1.2309802293463208e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_9  arc_capacity_1291  1
    load_2_15_9  segment_load_conservation_1401  -1
    load_2_15_9  segment_prefix_lb_1402  1
    load_2_15_9  segment_prefix_ub_1403  1
    load_2_15_9  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1293  -30
    arc_2_15_10  connected_order_arc_1294  -12
    arc_2_15_10  in_degree_1405  1
    arc_2_15_10  out_degree_1436  1
    arc_2_15_10  original_T_including_depot_unload_1468  1.5951553402938971e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1293  1
    load_2_15_10  segment_load_conservation_1408  -1
    load_2_15_10  segment_prefix_lb_1409  1
    load_2_15_10  segment_prefix_ub_1410  1
    load_2_15_10  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1295  -30
    arc_2_15_11  connected_order_arc_1296  -12
    arc_2_15_11  in_degree_1412  1
    arc_2_15_11  out_degree_1436  1
    arc_2_15_11  original_T_including_depot_unload_1468  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1295  1
    load_2_15_11  segment_load_conservation_1415  -1
    load_2_15_11  segment_prefix_lb_1416  1
    load_2_15_11  segment_prefix_ub_1417  1
    load_2_15_11  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1297  -30
    arc_2_15_12  connected_order_arc_1298  -12
    arc_2_15_12  in_degree_1419  1
    arc_2_15_12  out_degree_1436  1
    arc_2_15_12  original_T_including_depot_unload_1468  2.8747557636937808e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1297  1
    load_2_15_12  free_load_conservation_1423  -1
    load_2_15_12  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1299  -30
    arc_2_15_13  connected_order_arc_1300  -12
    arc_2_15_13  in_degree_1425  1
    arc_2_15_13  out_degree_1436  1
    arc_2_15_13  original_T_including_depot_unload_1468  3.6094216796124527e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1299  1
    load_2_15_13  free_load_conservation_1429  -1
    load_2_15_13  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1301  -30
    arc_2_15_14  connected_order_arc_1302  -12
    arc_2_15_14  in_degree_1431  1
    arc_2_15_14  out_degree_1436  1
    arc_2_15_14  original_T_including_depot_unload_1468  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1301  1
    load_2_15_14  free_load_conservation_1435  -1
    load_2_15_14  free_load_conservation_1441  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1303  -30
    arc_2_15_16  connected_order_arc_1304  -12
    arc_2_15_16  out_degree_1436  1
    arc_2_15_16  in_degree_1443  1
    arc_2_15_16  original_T_including_depot_unload_1468  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1303  1
    load_2_15_16  free_load_conservation_1441  1
    load_2_15_16  free_load_conservation_1447  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1305  -30
    arc_2_15_17  connected_order_arc_1306  -12
    arc_2_15_17  out_degree_1436  1
    arc_2_15_17  in_degree_1449  1
    arc_2_15_17  original_T_including_depot_unload_1468  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1305  1
    load_2_15_17  free_load_conservation_1441  1
    load_2_15_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1307  -30
    arc_2_15_18  connected_order_arc_1308  -12
    arc_2_15_18  out_degree_1436  1
    arc_2_15_18  in_degree_1455  1
    arc_2_15_18  original_T_including_depot_unload_1468  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1307  1
    load_2_15_18  free_load_conservation_1441  1
    load_2_15_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1309  -30
    arc_2_15_19  connected_order_arc_1310  -12
    arc_2_15_19  out_degree_1436  1
    arc_2_15_19  in_degree_1461  1
    arc_2_15_19  original_T_including_depot_unload_1468  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1309  1
    load_2_15_19  free_load_conservation_1441  1
    load_2_15_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1311  -30
    arc_2_16_0  depot_return_or_bypass_1396  1
    arc_2_16_0  out_degree_1442  1
    arc_2_16_0  original_T_including_depot_unload_1468  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1311  1
    load_2_16_0  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_9  arc_capacity_1312  -30
    arc_2_16_9  connected_order_arc_1313  -12
    arc_2_16_9  in_degree_1398  1
    arc_2_16_9  out_degree_1442  1
    arc_2_16_9  original_T_including_depot_unload_1468  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_9  arc_capacity_1312  1
    load_2_16_9  segment_load_conservation_1401  -1
    load_2_16_9  segment_prefix_lb_1402  1
    load_2_16_9  segment_prefix_ub_1403  1
    load_2_16_9  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1314  -30
    arc_2_16_10  connected_order_arc_1315  -12
    arc_2_16_10  in_degree_1405  1
    arc_2_16_10  out_degree_1442  1
    arc_2_16_10  original_T_including_depot_unload_1468  2.2636464857275848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1314  1
    load_2_16_10  segment_load_conservation_1408  -1
    load_2_16_10  segment_prefix_lb_1409  1
    load_2_16_10  segment_prefix_ub_1410  1
    load_2_16_10  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1316  -30
    arc_2_16_11  connected_order_arc_1317  -12
    arc_2_16_11  in_degree_1412  1
    arc_2_16_11  out_degree_1442  1
    arc_2_16_11  original_T_including_depot_unload_1468  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1316  1
    load_2_16_11  segment_load_conservation_1415  -1
    load_2_16_11  segment_prefix_lb_1416  1
    load_2_16_11  segment_prefix_ub_1417  1
    load_2_16_11  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1318  -30
    arc_2_16_12  connected_order_arc_1319  -12
    arc_2_16_12  in_degree_1419  1
    arc_2_16_12  out_degree_1442  1
    arc_2_16_12  original_T_including_depot_unload_1468  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1318  1
    load_2_16_12  free_load_conservation_1423  -1
    load_2_16_12  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1320  -30
    arc_2_16_13  connected_order_arc_1321  -12
    arc_2_16_13  in_degree_1425  1
    arc_2_16_13  out_degree_1442  1
    arc_2_16_13  original_T_including_depot_unload_1468  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1320  1
    load_2_16_13  free_load_conservation_1429  -1
    load_2_16_13  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1322  -30
    arc_2_16_14  connected_order_arc_1323  -12
    arc_2_16_14  in_degree_1431  1
    arc_2_16_14  out_degree_1442  1
    arc_2_16_14  original_T_including_depot_unload_1468  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1322  1
    load_2_16_14  free_load_conservation_1435  -1
    load_2_16_14  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1324  -30
    arc_2_16_15  connected_order_arc_1325  -12
    arc_2_16_15  in_degree_1437  1
    arc_2_16_15  out_degree_1442  1
    arc_2_16_15  original_T_including_depot_unload_1468  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1324  1
    load_2_16_15  free_load_conservation_1441  -1
    load_2_16_15  free_load_conservation_1447  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1326  -30
    arc_2_16_17  connected_order_arc_1327  -12
    arc_2_16_17  out_degree_1442  1
    arc_2_16_17  in_degree_1449  1
    arc_2_16_17  original_T_including_depot_unload_1468  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1326  1
    load_2_16_17  free_load_conservation_1447  1
    load_2_16_17  free_load_conservation_1453  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1328  -30
    arc_2_16_18  connected_order_arc_1329  -12
    arc_2_16_18  out_degree_1442  1
    arc_2_16_18  in_degree_1455  1
    arc_2_16_18  original_T_including_depot_unload_1468  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1328  1
    load_2_16_18  free_load_conservation_1447  1
    load_2_16_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1330  -30
    arc_2_16_19  connected_order_arc_1331  -12
    arc_2_16_19  out_degree_1442  1
    arc_2_16_19  in_degree_1461  1
    arc_2_16_19  original_T_including_depot_unload_1468  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1330  1
    load_2_16_19  free_load_conservation_1447  1
    load_2_16_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1332  -30
    arc_2_17_0  depot_return_or_bypass_1396  1
    arc_2_17_0  out_degree_1448  1
    arc_2_17_0  original_T_including_depot_unload_1468  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1332  1
    load_2_17_0  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_9  arc_capacity_1333  -30
    arc_2_17_9  connected_order_arc_1334  -12
    arc_2_17_9  in_degree_1398  1
    arc_2_17_9  out_degree_1448  1
    arc_2_17_9  original_T_including_depot_unload_1468  1.0311494902403294e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_9  arc_capacity_1333  1
    load_2_17_9  segment_load_conservation_1401  -1
    load_2_17_9  segment_prefix_lb_1402  1
    load_2_17_9  segment_prefix_ub_1403  1
    load_2_17_9  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1335  -30
    arc_2_17_10  connected_order_arc_1336  -12
    arc_2_17_10  in_degree_1405  1
    arc_2_17_10  out_degree_1448  1
    arc_2_17_10  original_T_including_depot_unload_1468  1.3608236268862893e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1335  1
    load_2_17_10  segment_load_conservation_1408  -1
    load_2_17_10  segment_prefix_lb_1409  1
    load_2_17_10  segment_prefix_ub_1410  1
    load_2_17_10  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1337  -30
    arc_2_17_11  connected_order_arc_1338  -12
    arc_2_17_11  in_degree_1412  1
    arc_2_17_11  out_degree_1448  1
    arc_2_17_11  original_T_including_depot_unload_1468  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1337  1
    load_2_17_11  segment_load_conservation_1415  -1
    load_2_17_11  segment_prefix_lb_1416  1
    load_2_17_11  segment_prefix_ub_1417  1
    load_2_17_11  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1339  -30
    arc_2_17_12  connected_order_arc_1340  -12
    arc_2_17_12  in_degree_1419  1
    arc_2_17_12  out_degree_1448  1
    arc_2_17_12  original_T_including_depot_unload_1468  3.6821827312741834e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1339  1
    load_2_17_12  free_load_conservation_1423  -1
    load_2_17_12  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1341  -30
    arc_2_17_13  connected_order_arc_1342  -12
    arc_2_17_13  in_degree_1425  1
    arc_2_17_13  out_degree_1448  1
    arc_2_17_13  original_T_including_depot_unload_1468  5.1107432522690152e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1341  1
    load_2_17_13  free_load_conservation_1429  -1
    load_2_17_13  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1343  -30
    arc_2_17_14  connected_order_arc_1344  -12
    arc_2_17_14  in_degree_1431  1
    arc_2_17_14  out_degree_1448  1
    arc_2_17_14  original_T_including_depot_unload_1468  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1343  1
    load_2_17_14  free_load_conservation_1435  -1
    load_2_17_14  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1345  -30
    arc_2_17_15  connected_order_arc_1346  -12
    arc_2_17_15  in_degree_1437  1
    arc_2_17_15  out_degree_1448  1
    arc_2_17_15  original_T_including_depot_unload_1468  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1345  1
    load_2_17_15  free_load_conservation_1441  -1
    load_2_17_15  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1347  -30
    arc_2_17_16  connected_order_arc_1348  -12
    arc_2_17_16  in_degree_1443  1
    arc_2_17_16  out_degree_1448  1
    arc_2_17_16  original_T_including_depot_unload_1468  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1347  1
    load_2_17_16  free_load_conservation_1447  -1
    load_2_17_16  free_load_conservation_1453  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1349  -30
    arc_2_17_18  connected_order_arc_1350  -12
    arc_2_17_18  out_degree_1448  1
    arc_2_17_18  in_degree_1455  1
    arc_2_17_18  original_T_including_depot_unload_1468  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1349  1
    load_2_17_18  free_load_conservation_1453  1
    load_2_17_18  free_load_conservation_1459  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1351  -30
    arc_2_17_19  connected_order_arc_1352  -12
    arc_2_17_19  out_degree_1448  1
    arc_2_17_19  in_degree_1461  1
    arc_2_17_19  original_T_including_depot_unload_1468  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1351  1
    load_2_17_19  free_load_conservation_1453  1
    load_2_17_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1353  -30
    arc_2_18_0  depot_return_or_bypass_1396  1
    arc_2_18_0  out_degree_1454  1
    arc_2_18_0  original_T_including_depot_unload_1468  7.2703300826114480e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1353  1
    load_2_18_0  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_9  arc_capacity_1354  -30
    arc_2_18_9  connected_order_arc_1355  -12
    arc_2_18_9  in_degree_1398  1
    arc_2_18_9  out_degree_1454  1
    arc_2_18_9  original_T_including_depot_unload_1468  5.0315495126439691e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_9  arc_capacity_1354  1
    load_2_18_9  segment_load_conservation_1401  -1
    load_2_18_9  segment_prefix_lb_1402  1
    load_2_18_9  segment_prefix_ub_1403  1
    load_2_18_9  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1356  -30
    arc_2_18_10  connected_order_arc_1357  -12
    arc_2_18_10  in_degree_1405  1
    arc_2_18_10  out_degree_1454  1
    arc_2_18_10  original_T_including_depot_unload_1468  6.2172856448708023e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1356  1
    load_2_18_10  segment_load_conservation_1408  -1
    load_2_18_10  segment_prefix_lb_1409  1
    load_2_18_10  segment_prefix_ub_1410  1
    load_2_18_10  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1358  -30
    arc_2_18_11  connected_order_arc_1359  -12
    arc_2_18_11  in_degree_1412  1
    arc_2_18_11  out_degree_1454  1
    arc_2_18_11  original_T_including_depot_unload_1468  7.6275540057842773e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1358  1
    load_2_18_11  segment_load_conservation_1415  -1
    load_2_18_11  segment_prefix_lb_1416  1
    load_2_18_11  segment_prefix_ub_1417  1
    load_2_18_11  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1360  -30
    arc_2_18_12  connected_order_arc_1361  -12
    arc_2_18_12  in_degree_1419  1
    arc_2_18_12  out_degree_1454  1
    arc_2_18_12  original_T_including_depot_unload_1468  1.3551088510632424e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1360  1
    load_2_18_12  free_load_conservation_1423  -1
    load_2_18_12  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1362  -30
    arc_2_18_13  connected_order_arc_1363  -12
    arc_2_18_13  in_degree_1425  1
    arc_2_18_13  out_degree_1454  1
    arc_2_18_13  original_T_including_depot_unload_1468  1.5183735648810946e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1362  1
    load_2_18_13  free_load_conservation_1429  -1
    load_2_18_13  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1364  -30
    arc_2_18_14  connected_order_arc_1365  -12
    arc_2_18_14  in_degree_1431  1
    arc_2_18_14  out_degree_1454  1
    arc_2_18_14  original_T_including_depot_unload_1468  1.1130079072134317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1364  1
    load_2_18_14  free_load_conservation_1435  -1
    load_2_18_14  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1366  -30
    arc_2_18_15  connected_order_arc_1367  -12
    arc_2_18_15  in_degree_1437  1
    arc_2_18_15  out_degree_1454  1
    arc_2_18_15  original_T_including_depot_unload_1468  1.3852878731513219e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1366  1
    load_2_18_15  free_load_conservation_1441  -1
    load_2_18_15  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1368  -30
    arc_2_18_16  connected_order_arc_1369  -12
    arc_2_18_16  in_degree_1443  1
    arc_2_18_16  out_degree_1454  1
    arc_2_18_16  original_T_including_depot_unload_1468  6.5128400208171092e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1368  1
    load_2_18_16  free_load_conservation_1447  -1
    load_2_18_16  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1370  -30
    arc_2_18_17  connected_order_arc_1371  -12
    arc_2_18_17  in_degree_1449  1
    arc_2_18_17  out_degree_1454  1
    arc_2_18_17  original_T_including_depot_unload_1468  1.1479472058029019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1370  1
    load_2_18_17  free_load_conservation_1453  -1
    load_2_18_17  free_load_conservation_1459  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1372  -30
    arc_2_18_19  connected_order_arc_1373  -12
    arc_2_18_19  out_degree_1454  1
    arc_2_18_19  in_degree_1461  1
    arc_2_18_19  original_T_including_depot_unload_1468  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1372  1
    load_2_18_19  free_load_conservation_1459  1
    load_2_18_19  free_load_conservation_1465  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1374  -30
    arc_2_19_0  depot_return_or_bypass_1396  1
    arc_2_19_0  out_degree_1460  1
    arc_2_19_0  original_T_including_depot_unload_1468  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1374  1
    load_2_19_0  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_9  arc_capacity_1375  -30
    arc_2_19_9  connected_order_arc_1376  -12
    arc_2_19_9  in_degree_1398  1
    arc_2_19_9  out_degree_1460  1
    arc_2_19_9  original_T_including_depot_unload_1468  1.5257079162357311e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_9  arc_capacity_1375  1
    load_2_19_9  segment_load_conservation_1401  -1
    load_2_19_9  segment_prefix_lb_1402  1
    load_2_19_9  segment_prefix_ub_1403  1
    load_2_19_9  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1377  -30
    arc_2_19_10  connected_order_arc_1378  -12
    arc_2_19_10  in_degree_1405  1
    arc_2_19_10  out_degree_1460  1
    arc_2_19_10  original_T_including_depot_unload_1468  2.1599714728425283e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1377  1
    load_2_19_10  segment_load_conservation_1408  -1
    load_2_19_10  segment_prefix_lb_1409  1
    load_2_19_10  segment_prefix_ub_1410  1
    load_2_19_10  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1379  -30
    arc_2_19_11  connected_order_arc_1380  -12
    arc_2_19_11  in_degree_1412  1
    arc_2_19_11  out_degree_1460  1
    arc_2_19_11  original_T_including_depot_unload_1468  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1379  1
    load_2_19_11  segment_load_conservation_1415  -1
    load_2_19_11  segment_prefix_lb_1416  1
    load_2_19_11  segment_prefix_ub_1417  1
    load_2_19_11  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1381  -30
    arc_2_19_12  connected_order_arc_1382  -12
    arc_2_19_12  in_degree_1419  1
    arc_2_19_12  out_degree_1460  1
    arc_2_19_12  original_T_including_depot_unload_1468  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1381  1
    load_2_19_12  free_load_conservation_1423  -1
    load_2_19_12  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1383  -30
    arc_2_19_13  connected_order_arc_1384  -12
    arc_2_19_13  in_degree_1425  1
    arc_2_19_13  out_degree_1460  1
    arc_2_19_13  original_T_including_depot_unload_1468  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1383  1
    load_2_19_13  free_load_conservation_1429  -1
    load_2_19_13  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1385  -30
    arc_2_19_14  connected_order_arc_1386  -12
    arc_2_19_14  in_degree_1431  1
    arc_2_19_14  out_degree_1460  1
    arc_2_19_14  original_T_including_depot_unload_1468  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1385  1
    load_2_19_14  free_load_conservation_1435  -1
    load_2_19_14  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1387  -30
    arc_2_19_15  connected_order_arc_1388  -12
    arc_2_19_15  in_degree_1437  1
    arc_2_19_15  out_degree_1460  1
    arc_2_19_15  original_T_including_depot_unload_1468  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1387  1
    load_2_19_15  free_load_conservation_1441  -1
    load_2_19_15  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1389  -30
    arc_2_19_16  connected_order_arc_1390  -12
    arc_2_19_16  in_degree_1443  1
    arc_2_19_16  out_degree_1460  1
    arc_2_19_16  original_T_including_depot_unload_1468  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1389  1
    load_2_19_16  free_load_conservation_1447  -1
    load_2_19_16  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1391  -30
    arc_2_19_17  connected_order_arc_1392  -12
    arc_2_19_17  in_degree_1449  1
    arc_2_19_17  out_degree_1460  1
    arc_2_19_17  original_T_including_depot_unload_1468  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1391  1
    load_2_19_17  free_load_conservation_1453  -1
    load_2_19_17  free_load_conservation_1465  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1393  -30
    arc_2_19_18  connected_order_arc_1394  -12
    arc_2_19_18  in_degree_1455  1
    arc_2_19_18  out_degree_1460  1
    arc_2_19_18  original_T_including_depot_unload_1468  1.8319650761318992e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1393  1
    load_2_19_18  free_load_conservation_1459  -1
    load_2_19_18  free_load_conservation_1465  1
RHS
    RHS1      OBJ       -0.4365
    RHS1      onehot_24_32  1
    RHS1      onehot_27_67  1
    RHS1      onehot_31_96  1
    RHS1      onehot_29_131  1
    RHS1      onehot_32_160  1
    RHS1      onehot_25_195  1
    RHS1      onehot_19_216  1
    RHS1      onehot_34_243  1
    RHS1      stock_ub_247  32
    RHS1      parent_nonstrict_scope_248  3.3734040918067931e-01
    RHS1      normalization_305  1
    RHS1      connected_order_arc_425  -12
    RHS1      connected_order_arc_427  -12
    RHS1      connected_order_arc_429  -12
    RHS1      connected_order_arc_431  -12
    RHS1      connected_order_arc_433  -12
    RHS1      connected_order_arc_435  -12
    RHS1      connected_order_arc_437  -12
    RHS1      connected_order_arc_439  -12
    RHS1      connected_order_arc_441  -12
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_448  -12
    RHS1      connected_order_arc_450  -12
    RHS1      connected_order_arc_452  -12
    RHS1      connected_order_arc_454  -12
    RHS1      connected_order_arc_456  -12
    RHS1      connected_order_arc_458  -12
    RHS1      connected_order_arc_460  -12
    RHS1      connected_order_arc_462  -12
    RHS1      connected_order_arc_464  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_471  -12
    RHS1      connected_order_arc_473  -12
    RHS1      connected_order_arc_475  -12
    RHS1      connected_order_arc_477  -12
    RHS1      connected_order_arc_479  -12
    RHS1      connected_order_arc_481  -12
    RHS1      connected_order_arc_483  -12
    RHS1      connected_order_arc_485  -12
    RHS1      connected_order_arc_487  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_494  -12
    RHS1      connected_order_arc_496  -12
    RHS1      connected_order_arc_498  -12
    RHS1      connected_order_arc_500  -12
    RHS1      connected_order_arc_502  -12
    RHS1      connected_order_arc_504  -12
    RHS1      connected_order_arc_506  -12
    RHS1      connected_order_arc_508  -12
    RHS1      connected_order_arc_510  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_517  -12
    RHS1      connected_order_arc_519  -12
    RHS1      connected_order_arc_521  -12
    RHS1      connected_order_arc_523  -12
    RHS1      connected_order_arc_525  -12
    RHS1      connected_order_arc_527  -12
    RHS1      connected_order_arc_529  -12
    RHS1      connected_order_arc_531  -12
    RHS1      connected_order_arc_533  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_540  -12
    RHS1      connected_order_arc_542  -12
    RHS1      connected_order_arc_544  -12
    RHS1      connected_order_arc_546  -12
    RHS1      connected_order_arc_548  -12
    RHS1      connected_order_arc_550  -12
    RHS1      connected_order_arc_552  -12
    RHS1      connected_order_arc_554  -12
    RHS1      connected_order_arc_556  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_563  -12
    RHS1      connected_order_arc_565  -12
    RHS1      connected_order_arc_567  -12
    RHS1      connected_order_arc_569  -12
    RHS1      connected_order_arc_571  -12
    RHS1      connected_order_arc_573  -12
    RHS1      connected_order_arc_575  -12
    RHS1      connected_order_arc_577  -12
    RHS1      connected_order_arc_579  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_586  -12
    RHS1      connected_order_arc_588  -12
    RHS1      connected_order_arc_590  -12
    RHS1      connected_order_arc_592  -12
    RHS1      connected_order_arc_594  -12
    RHS1      connected_order_arc_596  -12
    RHS1      connected_order_arc_598  -12
    RHS1      connected_order_arc_600  -12
    RHS1      connected_order_arc_602  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_609  -12
    RHS1      connected_order_arc_611  -12
    RHS1      connected_order_arc_613  -12
    RHS1      connected_order_arc_615  -12
    RHS1      connected_order_arc_617  -12
    RHS1      connected_order_arc_619  -12
    RHS1      connected_order_arc_621  -12
    RHS1      connected_order_arc_623  -12
    RHS1      connected_order_arc_625  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_632  -12
    RHS1      connected_order_arc_634  -12
    RHS1      connected_order_arc_636  -12
    RHS1      connected_order_arc_638  -12
    RHS1      connected_order_arc_640  -12
    RHS1      connected_order_arc_642  -12
    RHS1      connected_order_arc_644  -12
    RHS1      connected_order_arc_646  -12
    RHS1      connected_order_arc_648  -12
    RHS1      connected_order_arc_650  -12
    RHS1      connected_order_arc_652  -12
    RHS1      connected_order_arc_655  -12
    RHS1      connected_order_arc_657  -12
    RHS1      connected_order_arc_659  -12
    RHS1      connected_order_arc_661  -12
    RHS1      connected_order_arc_663  -12
    RHS1      connected_order_arc_665  -12
    RHS1      connected_order_arc_667  -12
    RHS1      connected_order_arc_669  -12
    RHS1      connected_order_arc_671  -12
    RHS1      connected_order_arc_673  -12
    RHS1      connected_order_arc_675  -12
    RHS1      connected_order_arc_678  -12
    RHS1      connected_order_arc_680  -12
    RHS1      connected_order_arc_682  -12
    RHS1      connected_order_arc_684  -12
    RHS1      connected_order_arc_686  -12
    RHS1      connected_order_arc_688  -12
    RHS1      connected_order_arc_690  -12
    RHS1      connected_order_arc_692  -12
    RHS1      connected_order_arc_694  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_698  -12
    RHS1      depot_departure_or_bypass_699  1
    RHS1      depot_return_or_bypass_700  1
    RHS1      segment_load_conservation_705  6
    RHS1      segment_prefix_ub_707  1
    RHS1      segment_load_conservation_712  6
    RHS1      segment_prefix_ub_714  14
    RHS1      segment_load_conservation_719  -6
    RHS1      segment_prefix_lb_720  6
    RHS1      segment_prefix_ub_721  20
    RHS1      segment_load_conservation_726  -6
    RHS1      segment_prefix_lb_727  6
    RHS1      segment_prefix_ub_728  20
    RHS1      fixed_segment_relative_order_777  1
    RHS1      fixed_segment_relative_order_778  1
    RHS1      fixed_segment_relative_order_779  1
    RHS1      original_T_including_depot_unload_780  1.6385775410128017e+03
    RHS1      connected_order_arc_796  -12
    RHS1      connected_order_arc_798  -12
    RHS1      connected_order_arc_800  -12
    RHS1      connected_order_arc_802  -12
    RHS1      connected_order_arc_804  -12
    RHS1      connected_order_arc_806  -12
    RHS1      connected_order_arc_808  -12
    RHS1      connected_order_arc_810  -12
    RHS1      connected_order_arc_812  -12
    RHS1      connected_order_arc_814  -12
    RHS1      connected_order_arc_816  -12
    RHS1      connected_order_arc_819  -12
    RHS1      connected_order_arc_821  -12
    RHS1      connected_order_arc_823  -12
    RHS1      connected_order_arc_825  -12
    RHS1      connected_order_arc_827  -12
    RHS1      connected_order_arc_829  -12
    RHS1      connected_order_arc_831  -12
    RHS1      connected_order_arc_833  -12
    RHS1      connected_order_arc_835  -12
    RHS1      connected_order_arc_837  -12
    RHS1      connected_order_arc_839  -12
    RHS1      connected_order_arc_842  -12
    RHS1      connected_order_arc_844  -12
    RHS1      connected_order_arc_846  -12
    RHS1      connected_order_arc_848  -12
    RHS1      connected_order_arc_850  -12
    RHS1      connected_order_arc_852  -12
    RHS1      connected_order_arc_854  -12
    RHS1      connected_order_arc_856  -12
    RHS1      connected_order_arc_858  -12
    RHS1      connected_order_arc_860  -12
    RHS1      connected_order_arc_862  -12
    RHS1      connected_order_arc_865  -12
    RHS1      connected_order_arc_867  -12
    RHS1      connected_order_arc_869  -12
    RHS1      connected_order_arc_871  -12
    RHS1      connected_order_arc_873  -12
    RHS1      connected_order_arc_875  -12
    RHS1      connected_order_arc_877  -12
    RHS1      connected_order_arc_879  -12
    RHS1      connected_order_arc_881  -12
    RHS1      connected_order_arc_883  -12
    RHS1      connected_order_arc_885  -12
    RHS1      connected_order_arc_888  -12
    RHS1      connected_order_arc_890  -12
    RHS1      connected_order_arc_892  -12
    RHS1      connected_order_arc_894  -12
    RHS1      connected_order_arc_896  -12
    RHS1      connected_order_arc_898  -12
    RHS1      connected_order_arc_900  -12
    RHS1      connected_order_arc_902  -12
    RHS1      connected_order_arc_904  -12
    RHS1      connected_order_arc_906  -12
    RHS1      connected_order_arc_908  -12
    RHS1      connected_order_arc_911  -12
    RHS1      connected_order_arc_913  -12
    RHS1      connected_order_arc_915  -12
    RHS1      connected_order_arc_917  -12
    RHS1      connected_order_arc_919  -12
    RHS1      connected_order_arc_921  -12
    RHS1      connected_order_arc_923  -12
    RHS1      connected_order_arc_925  -12
    RHS1      connected_order_arc_927  -12
    RHS1      connected_order_arc_929  -12
    RHS1      connected_order_arc_931  -12
    RHS1      connected_order_arc_934  -12
    RHS1      connected_order_arc_936  -12
    RHS1      connected_order_arc_938  -12
    RHS1      connected_order_arc_940  -12
    RHS1      connected_order_arc_942  -12
    RHS1      connected_order_arc_944  -12
    RHS1      connected_order_arc_946  -12
    RHS1      connected_order_arc_948  -12
    RHS1      connected_order_arc_950  -12
    RHS1      connected_order_arc_952  -12
    RHS1      connected_order_arc_954  -12
    RHS1      connected_order_arc_957  -12
    RHS1      connected_order_arc_959  -12
    RHS1      connected_order_arc_961  -12
    RHS1      connected_order_arc_963  -12
    RHS1      connected_order_arc_965  -12
    RHS1      connected_order_arc_967  -12
    RHS1      connected_order_arc_969  -12
    RHS1      connected_order_arc_971  -12
    RHS1      connected_order_arc_973  -12
    RHS1      connected_order_arc_975  -12
    RHS1      connected_order_arc_977  -12
    RHS1      connected_order_arc_980  -12
    RHS1      connected_order_arc_982  -12
    RHS1      connected_order_arc_984  -12
    RHS1      connected_order_arc_986  -12
    RHS1      connected_order_arc_988  -12
    RHS1      connected_order_arc_990  -12
    RHS1      connected_order_arc_992  -12
    RHS1      connected_order_arc_994  -12
    RHS1      connected_order_arc_996  -12
    RHS1      connected_order_arc_998  -12
    RHS1      connected_order_arc_1000  -12
    RHS1      connected_order_arc_1003  -12
    RHS1      connected_order_arc_1005  -12
    RHS1      connected_order_arc_1007  -12
    RHS1      connected_order_arc_1009  -12
    RHS1      connected_order_arc_1011  -12
    RHS1      connected_order_arc_1013  -12
    RHS1      connected_order_arc_1015  -12
    RHS1      connected_order_arc_1017  -12
    RHS1      connected_order_arc_1019  -12
    RHS1      connected_order_arc_1021  -12
    RHS1      connected_order_arc_1023  -12
    RHS1      connected_order_arc_1026  -12
    RHS1      connected_order_arc_1028  -12
    RHS1      connected_order_arc_1030  -12
    RHS1      connected_order_arc_1032  -12
    RHS1      connected_order_arc_1034  -12
    RHS1      connected_order_arc_1036  -12
    RHS1      connected_order_arc_1038  -12
    RHS1      connected_order_arc_1040  -12
    RHS1      connected_order_arc_1042  -12
    RHS1      connected_order_arc_1044  -12
    RHS1      connected_order_arc_1046  -12
    RHS1      connected_order_arc_1049  -12
    RHS1      connected_order_arc_1051  -12
    RHS1      connected_order_arc_1053  -12
    RHS1      connected_order_arc_1055  -12
    RHS1      connected_order_arc_1057  -12
    RHS1      connected_order_arc_1059  -12
    RHS1      connected_order_arc_1061  -12
    RHS1      connected_order_arc_1063  -12
    RHS1      connected_order_arc_1065  -12
    RHS1      connected_order_arc_1067  -12
    RHS1      connected_order_arc_1069  -12
    RHS1      depot_departure_or_bypass_1070  1
    RHS1      depot_return_or_bypass_1071  1
    RHS1      segment_load_conservation_1076  -5
    RHS1      segment_prefix_lb_1077  5
    RHS1      segment_prefix_ub_1078  25
    RHS1      segment_load_conservation_1083  5
    RHS1      segment_prefix_ub_1085  20
    RHS1      segment_load_conservation_1090  3
    RHS1      segment_prefix_ub_1092  22
    RHS1      segment_load_conservation_1097  -8
    RHS1      segment_prefix_lb_1098  8
    RHS1      segment_prefix_ub_1099  22
    RHS1      fixed_segment_relative_order_1148  1
    RHS1      fixed_segment_relative_order_1149  1
    RHS1      fixed_segment_relative_order_1150  1
    RHS1      original_T_including_depot_unload_1151  5.4345747502938793e+03
    RHS1      connected_order_arc_1166  -11
    RHS1      connected_order_arc_1168  -11
    RHS1      connected_order_arc_1170  -11
    RHS1      connected_order_arc_1172  -11
    RHS1      connected_order_arc_1174  -11
    RHS1      connected_order_arc_1176  -11
    RHS1      connected_order_arc_1178  -11
    RHS1      connected_order_arc_1180  -11
    RHS1      connected_order_arc_1182  -11
    RHS1      connected_order_arc_1184  -11
    RHS1      connected_order_arc_1187  -11
    RHS1      connected_order_arc_1189  -11
    RHS1      connected_order_arc_1191  -11
    RHS1      connected_order_arc_1193  -11
    RHS1      connected_order_arc_1195  -11
    RHS1      connected_order_arc_1197  -11
    RHS1      connected_order_arc_1199  -11
    RHS1      connected_order_arc_1201  -11
    RHS1      connected_order_arc_1203  -11
    RHS1      connected_order_arc_1205  -11
    RHS1      connected_order_arc_1208  -11
    RHS1      connected_order_arc_1210  -11
    RHS1      connected_order_arc_1212  -11
    RHS1      connected_order_arc_1214  -11
    RHS1      connected_order_arc_1216  -11
    RHS1      connected_order_arc_1218  -11
    RHS1      connected_order_arc_1220  -11
    RHS1      connected_order_arc_1222  -11
    RHS1      connected_order_arc_1224  -11
    RHS1      connected_order_arc_1226  -11
    RHS1      connected_order_arc_1229  -11
    RHS1      connected_order_arc_1231  -11
    RHS1      connected_order_arc_1233  -11
    RHS1      connected_order_arc_1235  -11
    RHS1      connected_order_arc_1237  -11
    RHS1      connected_order_arc_1239  -11
    RHS1      connected_order_arc_1241  -11
    RHS1      connected_order_arc_1243  -11
    RHS1      connected_order_arc_1245  -11
    RHS1      connected_order_arc_1247  -11
    RHS1      connected_order_arc_1250  -11
    RHS1      connected_order_arc_1252  -11
    RHS1      connected_order_arc_1254  -11
    RHS1      connected_order_arc_1256  -11
    RHS1      connected_order_arc_1258  -11
    RHS1      connected_order_arc_1260  -11
    RHS1      connected_order_arc_1262  -11
    RHS1      connected_order_arc_1264  -11
    RHS1      connected_order_arc_1266  -11
    RHS1      connected_order_arc_1268  -11
    RHS1      connected_order_arc_1271  -11
    RHS1      connected_order_arc_1273  -11
    RHS1      connected_order_arc_1275  -11
    RHS1      connected_order_arc_1277  -11
    RHS1      connected_order_arc_1279  -11
    RHS1      connected_order_arc_1281  -11
    RHS1      connected_order_arc_1283  -11
    RHS1      connected_order_arc_1285  -11
    RHS1      connected_order_arc_1287  -11
    RHS1      connected_order_arc_1289  -11
    RHS1      connected_order_arc_1292  -11
    RHS1      connected_order_arc_1294  -11
    RHS1      connected_order_arc_1296  -11
    RHS1      connected_order_arc_1298  -11
    RHS1      connected_order_arc_1300  -11
    RHS1      connected_order_arc_1302  -11
    RHS1      connected_order_arc_1304  -11
    RHS1      connected_order_arc_1306  -11
    RHS1      connected_order_arc_1308  -11
    RHS1      connected_order_arc_1310  -11
    RHS1      connected_order_arc_1313  -11
    RHS1      connected_order_arc_1315  -11
    RHS1      connected_order_arc_1317  -11
    RHS1      connected_order_arc_1319  -11
    RHS1      connected_order_arc_1321  -11
    RHS1      connected_order_arc_1323  -11
    RHS1      connected_order_arc_1325  -11
    RHS1      connected_order_arc_1327  -11
    RHS1      connected_order_arc_1329  -11
    RHS1      connected_order_arc_1331  -11
    RHS1      connected_order_arc_1334  -11
    RHS1      connected_order_arc_1336  -11
    RHS1      connected_order_arc_1338  -11
    RHS1      connected_order_arc_1340  -11
    RHS1      connected_order_arc_1342  -11
    RHS1      connected_order_arc_1344  -11
    RHS1      connected_order_arc_1346  -11
    RHS1      connected_order_arc_1348  -11
    RHS1      connected_order_arc_1350  -11
    RHS1      connected_order_arc_1352  -11
    RHS1      connected_order_arc_1355  -11
    RHS1      connected_order_arc_1357  -11
    RHS1      connected_order_arc_1359  -11
    RHS1      connected_order_arc_1361  -11
    RHS1      connected_order_arc_1363  -11
    RHS1      connected_order_arc_1365  -11
    RHS1      connected_order_arc_1367  -11
    RHS1      connected_order_arc_1369  -11
    RHS1      connected_order_arc_1371  -11
    RHS1      connected_order_arc_1373  -11
    RHS1      connected_order_arc_1376  -11
    RHS1      connected_order_arc_1378  -11
    RHS1      connected_order_arc_1380  -11
    RHS1      connected_order_arc_1382  -11
    RHS1      connected_order_arc_1384  -11
    RHS1      connected_order_arc_1386  -11
    RHS1      connected_order_arc_1388  -11
    RHS1      connected_order_arc_1390  -11
    RHS1      connected_order_arc_1392  -11
    RHS1      connected_order_arc_1394  -11
    RHS1      depot_departure_or_bypass_1395  1
    RHS1      depot_return_or_bypass_1396  1
    RHS1      segment_load_conservation_1401  1
    RHS1      segment_prefix_ub_1403  24
    RHS1      segment_load_conservation_1408  4
    RHS1      segment_prefix_ub_1410  26
    RHS1      segment_load_conservation_1415  -5
    RHS1      segment_prefix_lb_1416  5
    RHS1      segment_prefix_ub_1417  30
    RHS1      fixed_segment_relative_order_1466  1
    RHS1      fixed_segment_relative_order_1467  1
    RHS1      original_T_including_depot_unload_1468  3.4285204222867415e+03
BOUNDS
 LO BND1      t         2.4694987505487574e-02
 UP BND1      t         4.1418076031795294e-02
 UP BND1      q         4.9634040918067934e-01
 BV BND1      x_24_0  
 UP BND1      w_24_0    4.1418076031795294e-02
 BV BND1      x_24_1  
 UP BND1      w_24_1    4.1418076031795294e-02
 BV BND1      x_24_2  
 UP BND1      w_24_2    4.1418076031795294e-02
 BV BND1      x_24_3  
 UP BND1      w_24_3    4.1418076031795294e-02
 BV BND1      x_24_4  
 UP BND1      w_24_4    4.1418076031795294e-02
 BV BND1      x_24_5  
 UP BND1      w_24_5    4.1418076031795294e-02
 BV BND1      x_24_6  
 UP BND1      w_24_6    4.1418076031795294e-02
 BV BND1      x_24_7  
 UP BND1      w_24_7    4.1418076031795294e-02
 BV BND1      x_24_8  
 UP BND1      w_24_8    4.1418076031795294e-02
 BV BND1      x_24_9  
 UP BND1      w_24_9    4.1418076031795294e-02
 BV BND1      x_24_10 
 UP BND1      w_24_10   4.1418076031795294e-02
 BV BND1      x_24_11 
 UP BND1      w_24_11   4.1418076031795294e-02
 BV BND1      x_24_12 
 UP BND1      w_24_12   4.1418076031795294e-02
 BV BND1      x_24_13 
 UP BND1      w_24_13   4.1418076031795294e-02
 BV BND1      x_24_14 
 UP BND1      w_24_14   4.1418076031795294e-02
 BV BND1      x_24_15 
 UP BND1      w_24_15   4.1418076031795294e-02
 UP BND1      rho_24    1
 BV BND1      x_27_0  
 UP BND1      w_27_0    4.1418076031795294e-02
 BV BND1      x_27_1  
 UP BND1      w_27_1    4.1418076031795294e-02
 BV BND1      x_27_2  
 UP BND1      w_27_2    4.1418076031795294e-02
 BV BND1      x_27_3  
 UP BND1      w_27_3    4.1418076031795294e-02
 BV BND1      x_27_4  
 UP BND1      w_27_4    4.1418076031795294e-02
 BV BND1      x_27_5  
 UP BND1      w_27_5    4.1418076031795294e-02
 BV BND1      x_27_6  
 UP BND1      w_27_6    4.1418076031795294e-02
 BV BND1      x_27_7  
 UP BND1      w_27_7    4.1418076031795294e-02
 BV BND1      x_27_8  
 UP BND1      w_27_8    4.1418076031795294e-02
 BV BND1      x_27_9  
 UP BND1      w_27_9    4.1418076031795294e-02
 BV BND1      x_27_10 
 UP BND1      w_27_10   4.1418076031795294e-02
 BV BND1      x_27_11 
 UP BND1      w_27_11   4.1418076031795294e-02
 BV BND1      x_27_12 
 UP BND1      w_27_12   4.1418076031795294e-02
 BV BND1      x_27_13 
 UP BND1      w_27_13   4.1418076031795294e-02
 BV BND1      x_27_14 
 UP BND1      w_27_14   4.1418076031795294e-02
 BV BND1      x_27_15 
 UP BND1      w_27_15   4.1418076031795294e-02
 UP BND1      rho_27    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.1418076031795294e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.1418076031795294e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.1418076031795294e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.1418076031795294e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.1418076031795294e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.1418076031795294e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.1418076031795294e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.1418076031795294e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.1418076031795294e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.1418076031795294e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.1418076031795294e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.1418076031795294e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.1418076031795294e-02
 UP BND1      rho_31    1
 BV BND1      x_29_0  
 UP BND1      w_29_0    4.1418076031795294e-02
 BV BND1      x_29_1  
 UP BND1      w_29_1    4.1418076031795294e-02
 BV BND1      x_29_2  
 UP BND1      w_29_2    4.1418076031795294e-02
 BV BND1      x_29_3  
 UP BND1      w_29_3    4.1418076031795294e-02
 BV BND1      x_29_4  
 UP BND1      w_29_4    4.1418076031795294e-02
 BV BND1      x_29_5  
 UP BND1      w_29_5    4.1418076031795294e-02
 BV BND1      x_29_6  
 UP BND1      w_29_6    4.1418076031795294e-02
 BV BND1      x_29_7  
 UP BND1      w_29_7    4.1418076031795294e-02
 BV BND1      x_29_8  
 UP BND1      w_29_8    4.1418076031795294e-02
 BV BND1      x_29_9  
 UP BND1      w_29_9    4.1418076031795294e-02
 BV BND1      x_29_10 
 UP BND1      w_29_10   4.1418076031795294e-02
 BV BND1      x_29_11 
 UP BND1      w_29_11   4.1418076031795294e-02
 BV BND1      x_29_12 
 UP BND1      w_29_12   4.1418076031795294e-02
 BV BND1      x_29_13 
 UP BND1      w_29_13   4.1418076031795294e-02
 BV BND1      x_29_14 
 UP BND1      w_29_14   4.1418076031795294e-02
 BV BND1      x_29_15 
 UP BND1      w_29_15   4.1418076031795294e-02
 UP BND1      rho_29    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.1418076031795294e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.1418076031795294e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.1418076031795294e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.1418076031795294e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.1418076031795294e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.1418076031795294e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.1418076031795294e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.1418076031795294e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.1418076031795294e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.1418076031795294e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.1418076031795294e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.1418076031795294e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.1418076031795294e-02
 UP BND1      rho_32    1
 BV BND1      x_25_0  
 UP BND1      w_25_0    4.1418076031795294e-02
 BV BND1      x_25_1  
 UP BND1      w_25_1    4.1418076031795294e-02
 BV BND1      x_25_2  
 UP BND1      w_25_2    4.1418076031795294e-02
 BV BND1      x_25_3  
 UP BND1      w_25_3    4.1418076031795294e-02
 BV BND1      x_25_4  
 UP BND1      w_25_4    4.1418076031795294e-02
 BV BND1      x_25_5  
 UP BND1      w_25_5    4.1418076031795294e-02
 BV BND1      x_25_6  
 UP BND1      w_25_6    4.1418076031795294e-02
 BV BND1      x_25_7  
 UP BND1      w_25_7    4.1418076031795294e-02
 BV BND1      x_25_8  
 UP BND1      w_25_8    4.1418076031795294e-02
 BV BND1      x_25_9  
 UP BND1      w_25_9    4.1418076031795294e-02
 BV BND1      x_25_10 
 UP BND1      w_25_10   4.1418076031795294e-02
 BV BND1      x_25_11 
 UP BND1      w_25_11   4.1418076031795294e-02
 BV BND1      x_25_12 
 UP BND1      w_25_12   4.1418076031795294e-02
 BV BND1      x_25_13 
 UP BND1      w_25_13   4.1418076031795294e-02
 BV BND1      x_25_14 
 UP BND1      w_25_14   4.1418076031795294e-02
 BV BND1      x_25_15 
 UP BND1      w_25_15   4.1418076031795294e-02
 UP BND1      rho_25    1
 BV BND1      x_19_0  
 UP BND1      w_19_0    4.1418076031795294e-02
 BV BND1      x_19_1  
 UP BND1      w_19_1    4.1418076031795294e-02
 BV BND1      x_19_2  
 UP BND1      w_19_2    4.1418076031795294e-02
 BV BND1      x_19_3  
 UP BND1      w_19_3    4.1418076031795294e-02
 BV BND1      x_19_4  
 UP BND1      w_19_4    4.1418076031795294e-02
 BV BND1      x_19_5  
 UP BND1      w_19_5    4.1418076031795294e-02
 BV BND1      x_19_6  
 UP BND1      w_19_6    4.1418076031795294e-02
 BV BND1      x_19_7  
 UP BND1      w_19_7    4.1418076031795294e-02
 BV BND1      x_19_8  
 UP BND1      w_19_8    4.1418076031795294e-02
 UP BND1      rho_19    1
 BV BND1      x_34_0  
 UP BND1      w_34_0    4.1418076031795294e-02
 BV BND1      x_34_1  
 UP BND1      w_34_1    4.1418076031795294e-02
 BV BND1      x_34_2  
 UP BND1      w_34_2    4.1418076031795294e-02
 BV BND1      x_34_3  
 UP BND1      w_34_3    4.1418076031795294e-02
 BV BND1      x_34_4  
 UP BND1      w_34_4    4.1418076031795294e-02
 BV BND1      x_34_5  
 UP BND1      w_34_5    4.1418076031795294e-02
 BV BND1      x_34_6  
 UP BND1      w_34_6    4.1418076031795294e-02
 BV BND1      x_34_7  
 UP BND1      w_34_7    4.1418076031795294e-02
 BV BND1      x_34_8  
 UP BND1      w_34_8    4.1418076031795294e-02
 BV BND1      x_34_9  
 UP BND1      w_34_9    4.1418076031795294e-02
 BV BND1      x_34_10 
 UP BND1      w_34_10   4.1418076031795294e-02
 BV BND1      x_34_11 
 UP BND1      w_34_11   4.1418076031795294e-02
 UP BND1      rho_34    1
 UP BND1      a_24_27   1
 UP BND1      a_24_31   1
 UP BND1      a_24_29   1
 UP BND1      a_24_32   1
 UP BND1      a_24_25   1
 UP BND1      a_24_19   1
 UP BND1      a_24_34   1
 UP BND1      a_27_31   1
 UP BND1      a_27_29   1
 UP BND1      a_27_32   1
 UP BND1      a_27_25   1
 UP BND1      a_27_19   1
 UP BND1      a_27_34   1
 UP BND1      a_31_29   1
 UP BND1      a_31_32   1
 UP BND1      a_31_25   1
 UP BND1      a_31_19   1
 UP BND1      a_31_34   1
 UP BND1      a_29_32   1
 UP BND1      a_29_25   1
 UP BND1      a_29_19   1
 UP BND1      a_29_34   1
 UP BND1      a_32_25   1
 UP BND1      a_32_19   1
 UP BND1      a_32_34   1
 UP BND1      a_25_19   1
 UP BND1      a_25_34   1
 UP BND1      a_19_34   1
 BV BND1      service_0_24_0
 BV BND1      service_0_24_1
 BV BND1      service_0_24_2
 BV BND1      service_0_24_3
 BV BND1      service_0_24_4
 BV BND1      service_0_24_5
 BV BND1      service_0_24_6
 BV BND1      service_0_24_7
 BV BND1      service_0_24_8
 BV BND1      service_0_24_9
 BV BND1      service_0_24_10
 BV BND1      service_0_24_12
 BV BND1      service_0_24_13
 BV BND1      service_0_24_14
 BV BND1      service_0_24_15
 BV BND1      service_1_24_0
 BV BND1      service_1_24_1
 BV BND1      service_1_24_2
 BV BND1      service_1_24_3
 BV BND1      service_1_24_4
 BV BND1      service_1_24_5
 BV BND1      service_1_24_6
 BV BND1      service_1_24_7
 BV BND1      service_1_24_8
 BV BND1      service_1_24_9
 BV BND1      service_1_24_10
 BV BND1      service_1_24_12
 BV BND1      service_1_24_13
 BV BND1      service_1_24_14
 BV BND1      service_1_24_15
 BV BND1      service_2_24_0
 BV BND1      service_2_24_1
 BV BND1      service_2_24_2
 BV BND1      service_2_24_3
 BV BND1      service_2_24_4
 BV BND1      service_2_24_5
 BV BND1      service_2_24_6
 BV BND1      service_2_24_7
 BV BND1      service_2_24_8
 BV BND1      service_2_24_9
 BV BND1      service_2_24_10
 BV BND1      service_2_24_12
 BV BND1      service_2_24_13
 BV BND1      service_2_24_14
 BV BND1      service_2_24_15
 BV BND1      service_0_27_0
 BV BND1      service_0_27_1
 BV BND1      service_0_27_2
 BV BND1      service_0_27_3
 BV BND1      service_0_27_4
 BV BND1      service_0_27_5
 BV BND1      service_0_27_6
 BV BND1      service_0_27_7
 BV BND1      service_0_27_8
 BV BND1      service_0_27_9
 BV BND1      service_0_27_10
 BV BND1      service_0_27_12
 BV BND1      service_0_27_13
 BV BND1      service_0_27_14
 BV BND1      service_0_27_15
 BV BND1      service_1_27_0
 BV BND1      service_1_27_1
 BV BND1      service_1_27_2
 BV BND1      service_1_27_3
 BV BND1      service_1_27_4
 BV BND1      service_1_27_5
 BV BND1      service_1_27_6
 BV BND1      service_1_27_7
 BV BND1      service_1_27_8
 BV BND1      service_1_27_9
 BV BND1      service_1_27_10
 BV BND1      service_1_27_12
 BV BND1      service_1_27_13
 BV BND1      service_1_27_14
 BV BND1      service_1_27_15
 BV BND1      service_2_27_0
 BV BND1      service_2_27_1
 BV BND1      service_2_27_2
 BV BND1      service_2_27_3
 BV BND1      service_2_27_4
 BV BND1      service_2_27_5
 BV BND1      service_2_27_6
 BV BND1      service_2_27_7
 BV BND1      service_2_27_8
 BV BND1      service_2_27_9
 BV BND1      service_2_27_10
 BV BND1      service_2_27_12
 BV BND1      service_2_27_13
 BV BND1      service_2_27_14
 BV BND1      service_2_27_15
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_29_0
 BV BND1      service_0_29_1
 BV BND1      service_0_29_2
 BV BND1      service_0_29_3
 BV BND1      service_0_29_4
 BV BND1      service_0_29_5
 BV BND1      service_0_29_6
 BV BND1      service_0_29_7
 BV BND1      service_0_29_8
 BV BND1      service_0_29_9
 BV BND1      service_0_29_10
 BV BND1      service_0_29_12
 BV BND1      service_0_29_13
 BV BND1      service_0_29_14
 BV BND1      service_0_29_15
 BV BND1      service_1_29_0
 BV BND1      service_1_29_1
 BV BND1      service_1_29_2
 BV BND1      service_1_29_3
 BV BND1      service_1_29_4
 BV BND1      service_1_29_5
 BV BND1      service_1_29_6
 BV BND1      service_1_29_7
 BV BND1      service_1_29_8
 BV BND1      service_1_29_9
 BV BND1      service_1_29_10
 BV BND1      service_1_29_12
 BV BND1      service_1_29_13
 BV BND1      service_1_29_14
 BV BND1      service_1_29_15
 BV BND1      service_2_29_0
 BV BND1      service_2_29_1
 BV BND1      service_2_29_2
 BV BND1      service_2_29_3
 BV BND1      service_2_29_4
 BV BND1      service_2_29_5
 BV BND1      service_2_29_6
 BV BND1      service_2_29_7
 BV BND1      service_2_29_8
 BV BND1      service_2_29_9
 BV BND1      service_2_29_10
 BV BND1      service_2_29_12
 BV BND1      service_2_29_13
 BV BND1      service_2_29_14
 BV BND1      service_2_29_15
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_25_0
 BV BND1      service_0_25_2
 BV BND1      service_0_25_3
 BV BND1      service_0_25_4
 BV BND1      service_0_25_5
 BV BND1      service_0_25_6
 BV BND1      service_0_25_7
 BV BND1      service_0_25_8
 BV BND1      service_0_25_9
 BV BND1      service_0_25_10
 BV BND1      service_0_25_11
 BV BND1      service_0_25_12
 BV BND1      service_0_25_13
 BV BND1      service_0_25_14
 BV BND1      service_0_25_15
 BV BND1      service_1_25_0
 BV BND1      service_1_25_2
 BV BND1      service_1_25_3
 BV BND1      service_1_25_4
 BV BND1      service_1_25_5
 BV BND1      service_1_25_6
 BV BND1      service_1_25_7
 BV BND1      service_1_25_8
 BV BND1      service_1_25_9
 BV BND1      service_1_25_10
 BV BND1      service_1_25_11
 BV BND1      service_1_25_12
 BV BND1      service_1_25_13
 BV BND1      service_1_25_14
 BV BND1      service_1_25_15
 BV BND1      service_2_25_0
 BV BND1      service_2_25_2
 BV BND1      service_2_25_3
 BV BND1      service_2_25_4
 BV BND1      service_2_25_5
 BV BND1      service_2_25_6
 BV BND1      service_2_25_7
 BV BND1      service_2_25_8
 BV BND1      service_2_25_9
 BV BND1      service_2_25_10
 BV BND1      service_2_25_11
 BV BND1      service_2_25_12
 BV BND1      service_2_25_13
 BV BND1      service_2_25_14
 BV BND1      service_2_25_15
 BV BND1      service_0_19_1
 BV BND1      service_0_19_2
 BV BND1      service_0_19_3
 BV BND1      service_0_19_4
 BV BND1      service_0_19_5
 BV BND1      service_0_19_6
 BV BND1      service_0_19_7
 BV BND1      service_0_19_8
 BV BND1      service_1_19_1
 BV BND1      service_1_19_2
 BV BND1      service_1_19_3
 BV BND1      service_1_19_4
 BV BND1      service_1_19_5
 BV BND1      service_1_19_6
 BV BND1      service_1_19_7
 BV BND1      service_1_19_8
 BV BND1      service_2_19_1
 BV BND1      service_2_19_2
 BV BND1      service_2_19_3
 BV BND1      service_2_19_4
 BV BND1      service_2_19_5
 BV BND1      service_2_19_6
 BV BND1      service_2_19_7
 BV BND1      service_2_19_8
 BV BND1      service_0_34_0
 BV BND1      service_0_34_2
 BV BND1      service_0_34_3
 BV BND1      service_0_34_4
 BV BND1      service_0_34_5
 BV BND1      service_0_34_6
 BV BND1      service_0_34_7
 BV BND1      service_0_34_8
 BV BND1      service_0_34_9
 BV BND1      service_0_34_10
 BV BND1      service_0_34_11
 BV BND1      service_1_34_0
 BV BND1      service_1_34_2
 BV BND1      service_1_34_3
 BV BND1      service_1_34_4
 BV BND1      service_1_34_5
 BV BND1      service_1_34_6
 BV BND1      service_1_34_7
 BV BND1      service_1_34_8
 BV BND1      service_1_34_9
 BV BND1      service_1_34_10
 BV BND1      service_1_34_11
 BV BND1      service_2_34_0
 BV BND1      service_2_34_2
 BV BND1      service_2_34_3
 BV BND1      service_2_34_4
 BV BND1      service_2_34_5
 BV BND1      service_2_34_6
 BV BND1      service_2_34_7
 BV BND1      service_2_34_8
 BV BND1      service_2_34_9
 BV BND1      service_2_34_10
 BV BND1      service_2_34_11
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  12
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  20
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  20
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  20
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  20
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  20
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  20
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  20
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  20
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  20
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  20
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  20
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  20
 BV BND1      arc_0_12_16
 UP BND1      load_0_12_16  20
 BV BND1      arc_0_12_17
 UP BND1      load_0_12_17  20
 BV BND1      arc_0_12_18
 UP BND1      load_0_12_18  20
 BV BND1      arc_0_12_19
 UP BND1      load_0_12_19  20
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  20
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  20
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  20
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  20
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  20
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  20
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  20
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  20
 BV BND1      arc_0_13_16
 UP BND1      load_0_13_16  20
 BV BND1      arc_0_13_17
 UP BND1      load_0_13_17  20
 BV BND1      arc_0_13_18
 UP BND1      load_0_13_18  20
 BV BND1      arc_0_13_19
 UP BND1      load_0_13_19  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  20
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  20
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_12
 UP BND1      load_0_16_12  20
 BV BND1      arc_0_16_13
 UP BND1      load_0_16_13  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_12
 UP BND1      load_0_17_12  20
 BV BND1      arc_0_17_13
 UP BND1      load_0_17_13  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_12
 UP BND1      load_0_18_12  20
 BV BND1      arc_0_18_13
 UP BND1      load_0_18_13  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_12
 UP BND1      load_0_19_12  20
 BV BND1      arc_0_19_13
 UP BND1      load_0_19_13  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  12
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  12
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  12
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  12
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  12
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  12
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  12
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  12
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  12
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  12
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  12
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  12
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_12
 UP BND1      load_1_5_12  25
 BV BND1      arc_1_5_13
 UP BND1      load_1_5_13  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  25
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  25
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  25
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  25
 BV BND1      arc_1_12_5
 UP BND1      load_1_12_5  25
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  25
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  25
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  25
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  25
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  25
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  25
 BV BND1      arc_1_12_16
 UP BND1      load_1_12_16  25
 BV BND1      arc_1_12_17
 UP BND1      load_1_12_17  25
 BV BND1      arc_1_12_18
 UP BND1      load_1_12_18  25
 BV BND1      arc_1_12_19
 UP BND1      load_1_12_19  25
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  25
 BV BND1      arc_1_13_5
 UP BND1      load_1_13_5  25
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  25
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  25
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  25
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  25
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  25
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  25
 BV BND1      arc_1_13_16
 UP BND1      load_1_13_16  25
 BV BND1      arc_1_13_17
 UP BND1      load_1_13_17  25
 BV BND1      arc_1_13_18
 UP BND1      load_1_13_18  25
 BV BND1      arc_1_13_19
 UP BND1      load_1_13_19  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  25
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  25
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_12
 UP BND1      load_1_16_12  25
 BV BND1      arc_1_16_13
 UP BND1      load_1_16_13  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_12
 UP BND1      load_1_17_12  25
 BV BND1      arc_1_17_13
 UP BND1      load_1_17_13  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_12
 UP BND1      load_1_18_12  25
 BV BND1      arc_1_18_13
 UP BND1      load_1_18_13  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_12
 UP BND1      load_1_19_12  25
 BV BND1      arc_1_19_13
 UP BND1      load_1_19_13  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 FX BND1      visit_2_9  1
 UP BND1      order_2_9  11
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  11
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  11
 UP BND1      visit_2_12  1
 UP BND1      order_2_12  11
 UP BND1      visit_2_13  1
 UP BND1      order_2_13  11
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  11
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  11
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  11
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  11
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  11
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  11
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_9
 FX BND1      load_2_0_9  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_9_0
 UP BND1      load_2_9_0  30
 BV BND1      arc_2_9_10
 UP BND1      load_2_9_10  30
 BV BND1      arc_2_9_11
 UP BND1      load_2_9_11  30
 BV BND1      arc_2_9_12
 UP BND1      load_2_9_12  30
 BV BND1      arc_2_9_13
 UP BND1      load_2_9_13  30
 BV BND1      arc_2_9_14
 UP BND1      load_2_9_14  30
 BV BND1      arc_2_9_15
 UP BND1      load_2_9_15  30
 BV BND1      arc_2_9_16
 UP BND1      load_2_9_16  30
 BV BND1      arc_2_9_17
 UP BND1      load_2_9_17  30
 BV BND1      arc_2_9_18
 UP BND1      load_2_9_18  30
 BV BND1      arc_2_9_19
 UP BND1      load_2_9_19  30
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_9
 UP BND1      load_2_10_9  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_9
 UP BND1      load_2_11_9  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_9
 UP BND1      load_2_12_9  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_9
 UP BND1      load_2_13_9  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_9
 UP BND1      load_2_14_9  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_9
 UP BND1      load_2_15_9  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_9
 UP BND1      load_2_16_9  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_9
 UP BND1      load_2_17_9  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_9
 UP BND1      load_2_18_9  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_9
 UP BND1      load_2_19_9  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
ENDATA
