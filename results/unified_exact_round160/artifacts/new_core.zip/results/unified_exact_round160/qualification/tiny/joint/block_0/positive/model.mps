* Signature: 0x77d2a0afe4817bc4
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 E  onehot_1_6
 E  normalized_mass_1_7
 E  normalized_ratio_1_8
 G  product_lb_9
 L  product_ub_10
 G  product_lb_11
 L  product_ub_12
 G  product_lb_13
 L  product_ub_14
 E  onehot_2_15
 E  normalized_mass_2_16
 E  normalized_ratio_2_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 E  onehot_3_26
 E  normalized_mass_3_27
 E  normalized_ratio_3_28
 G  product_lb_29
 L  product_ub_30
 G  product_lb_31
 L  product_ub_32
 G  product_lb_33
 L  product_ub_34
 G  product_lb_35
 L  product_ub_36
 E  onehot_4_37
 E  normalized_mass_4_38
 E  normalized_ratio_4_39
 G  stock_lb_40
 L  stock_ub_41
 L  parent_nonstrict_scope_42
 G  block_pair_pos_43
 G  block_pair_neg_44
 G  block_pair_pos_45
 G  block_pair_neg_46
 G  block_pair_pos_47
 G  block_pair_neg_48
 G  block_pair_pos_49
 G  block_pair_neg_50
 G  block_pair_pos_51
 G  block_pair_neg_52
 G  block_pair_pos_53
 G  block_pair_neg_54
 E  normalization_55
 G  full_original_Gini_56
 E  unique_nonzero_owner_57
 E  unique_nonzero_owner_58
 E  unique_nonzero_owner_59
 E  unique_nonzero_owner_60
 E  unique_nonzero_owner_61
 E  unique_nonzero_owner_62
 E  unique_nonzero_owner_63
 E  unique_nonzero_owner_64
 E  unique_nonzero_owner_65
 E  unique_nonzero_owner_66
 L  arc_capacity_67
 L  arc_capacity_68
 L  arc_capacity_69
 L  arc_capacity_70
 L  arc_capacity_71
 L  arc_capacity_72
 L  arc_capacity_73
 G  connected_order_arc_74
 L  arc_capacity_75
 G  connected_order_arc_76
 L  arc_capacity_77
 G  connected_order_arc_78
 L  arc_capacity_79
 L  arc_capacity_80
 G  connected_order_arc_81
 L  arc_capacity_82
 G  connected_order_arc_83
 L  arc_capacity_84
 G  connected_order_arc_85
 L  arc_capacity_86
 L  arc_capacity_87
 G  connected_order_arc_88
 L  arc_capacity_89
 G  connected_order_arc_90
 L  arc_capacity_91
 G  connected_order_arc_92
 L  arc_capacity_93
 L  arc_capacity_94
 G  connected_order_arc_95
 L  arc_capacity_96
 G  connected_order_arc_97
 L  arc_capacity_98
 G  connected_order_arc_99
 E  depot_departure_or_bypass_100
 E  depot_return_or_bypass_101
 E  out_degree_102
 E  in_degree_103
 G  order_active_lb_104
 L  order_active_ub_105
 E  service_visit_def_106
 E  free_load_conservation_107
 E  out_degree_108
 E  in_degree_109
 G  order_active_lb_110
 L  order_active_ub_111
 E  service_visit_def_112
 E  free_load_conservation_113
 E  out_degree_114
 E  in_degree_115
 G  order_active_lb_116
 L  order_active_ub_117
 E  service_visit_def_118
 E  free_load_conservation_119
 E  out_degree_120
 E  in_degree_121
 G  order_active_lb_122
 L  order_active_ub_123
 E  service_visit_def_124
 E  free_load_conservation_125
 L  original_T_including_depot_unload_126
 L  arc_capacity_127
 L  arc_capacity_128
 L  arc_capacity_129
 L  arc_capacity_130
 L  arc_capacity_131
 L  arc_capacity_132
 L  arc_capacity_133
 G  connected_order_arc_134
 L  arc_capacity_135
 G  connected_order_arc_136
 L  arc_capacity_137
 G  connected_order_arc_138
 L  arc_capacity_139
 L  arc_capacity_140
 G  connected_order_arc_141
 L  arc_capacity_142
 G  connected_order_arc_143
 L  arc_capacity_144
 G  connected_order_arc_145
 L  arc_capacity_146
 L  arc_capacity_147
 G  connected_order_arc_148
 L  arc_capacity_149
 G  connected_order_arc_150
 L  arc_capacity_151
 G  connected_order_arc_152
 L  arc_capacity_153
 L  arc_capacity_154
 G  connected_order_arc_155
 L  arc_capacity_156
 G  connected_order_arc_157
 L  arc_capacity_158
 G  connected_order_arc_159
 E  depot_departure_or_bypass_160
 E  depot_return_or_bypass_161
 E  out_degree_162
 E  in_degree_163
 G  order_active_lb_164
 L  order_active_ub_165
 E  service_visit_def_166
 E  free_load_conservation_167
 E  out_degree_168
 E  in_degree_169
 G  order_active_lb_170
 L  order_active_ub_171
 E  service_visit_def_172
 E  free_load_conservation_173
 E  out_degree_174
 E  in_degree_175
 G  order_active_lb_176
 L  order_active_ub_177
 E  service_visit_def_178
 E  free_load_conservation_179
 E  out_degree_180
 E  in_degree_181
 G  order_active_lb_182
 L  order_active_ub_183
 E  service_visit_def_184
 E  free_load_conservation_185
 L  original_T_including_depot_unload_186
COLUMNS
    t         normalized_mass_1_7  -1
    t         normalized_mass_2_16  -1
    t         normalized_mass_3_27  -1
    t         normalized_mass_4_38  -1
    q         OBJ       1
    q         parent_nonstrict_scope_42  1
    q         full_original_Gini_56  4
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       0.075
    x_1_0     product_lb_0  -9.9999999999899988e-02
    x_1_0     product_ub_1  -1.0000000000010003e+00
    x_1_0     onehot_1_6  1
    x_1_0     parent_nonstrict_scope_42  0.15
    x_1_0     unique_nonzero_owner_57  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_0  1
    w_1_0     product_ub_1  1
    w_1_0     normalized_mass_1_7  1
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       -0.075
    x_1_1     product_lb_2  -9.9999999999899988e-02
    x_1_1     product_ub_3  -1.0000000000010003e+00
    x_1_1     onehot_1_6  1
    x_1_1     stock_lb_40  1
    x_1_1     stock_ub_41  1
    x_1_1     unique_nonzero_owner_58  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_2  1
    w_1_1     product_ub_3  1
    w_1_1     normalized_mass_1_7  1
    w_1_1     normalized_ratio_1_8  -1
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       0.075
    x_1_2     product_lb_4  -9.9999999999899988e-02
    x_1_2     product_ub_5  -1.0000000000010003e+00
    x_1_2     onehot_1_6  1
    x_1_2     stock_lb_40  2
    x_1_2     stock_ub_41  2
    x_1_2     parent_nonstrict_scope_42  0.15
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_4  1
    w_1_2     product_ub_5  1
    w_1_2     normalized_mass_1_7  1
    w_1_2     normalized_ratio_1_8  -2
    rho_1     normalized_ratio_1_8  1
    rho_1     block_pair_pos_43  -1
    rho_1     block_pair_neg_44  1
    rho_1     block_pair_pos_45  -1
    rho_1     block_pair_neg_46  1
    rho_1     block_pair_pos_47  -1
    rho_1     block_pair_neg_48  1
    rho_1     normalization_55  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       0.075
    x_2_0     product_lb_9  -9.9999999999899988e-02
    x_2_0     product_ub_10  -1.0000000000010003e+00
    x_2_0     onehot_2_15  1
    x_2_0     parent_nonstrict_scope_42  0.15
    x_2_0     unique_nonzero_owner_59  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_9  1
    w_2_0     product_ub_10  1
    w_2_0     normalized_mass_2_16  1
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       -0.075
    x_2_1     product_lb_11  -9.9999999999899988e-02
    x_2_1     product_ub_12  -1.0000000000010003e+00
    x_2_1     onehot_2_15  1
    x_2_1     stock_lb_40  1
    x_2_1     stock_ub_41  1
    x_2_1     unique_nonzero_owner_60  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_11  1
    w_2_1     product_ub_12  1
    w_2_1     normalized_mass_2_16  1
    w_2_1     normalized_ratio_2_17  -1
    MARKER    'MARKER'                 'INTORG'
    x_2_2     OBJ       0.075
    x_2_2     product_lb_13  -9.9999999999899988e-02
    x_2_2     product_ub_14  -1.0000000000010003e+00
    x_2_2     onehot_2_15  1
    x_2_2     stock_lb_40  2
    x_2_2     stock_ub_41  2
    x_2_2     parent_nonstrict_scope_42  0.15
    MARKER    'MARKER'                 'INTEND'
    w_2_2     product_lb_13  1
    w_2_2     product_ub_14  1
    w_2_2     normalized_mass_2_16  1
    w_2_2     normalized_ratio_2_17  -2
    rho_2     normalized_ratio_2_17  1
    rho_2     block_pair_pos_43  1
    rho_2     block_pair_neg_44  -1
    rho_2     block_pair_pos_49  -1
    rho_2     block_pair_neg_50  1
    rho_2     block_pair_pos_51  -1
    rho_2     block_pair_neg_52  1
    rho_2     normalization_55  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     product_lb_18  -9.9999999999899988e-02
    x_3_0     product_ub_19  -1.0000000000010003e+00
    x_3_0     onehot_3_26  1
    x_3_0     parent_nonstrict_scope_42  0.15
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_18  1
    w_3_0     product_ub_19  1
    w_3_0     normalized_mass_3_27  1
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       -0.15
    x_3_1     product_lb_20  -9.9999999999899988e-02
    x_3_1     product_ub_21  -1.0000000000010003e+00
    x_3_1     onehot_3_26  1
    x_3_1     stock_lb_40  1
    x_3_1     stock_ub_41  1
    x_3_1     unique_nonzero_owner_61  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_20  1
    w_3_1     product_ub_21  1
    w_3_1     normalized_mass_3_27  1
    w_3_1     normalized_ratio_3_28  -1
    MARKER    'MARKER'                 'INTORG'
    x_3_2     product_lb_22  -9.9999999999899988e-02
    x_3_2     product_ub_23  -1.0000000000010003e+00
    x_3_2     onehot_3_26  1
    x_3_2     stock_lb_40  2
    x_3_2     stock_ub_41  2
    x_3_2     parent_nonstrict_scope_42  0.15
    x_3_2     unique_nonzero_owner_62  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_22  1
    w_3_2     product_ub_23  1
    w_3_2     normalized_mass_3_27  1
    w_3_2     normalized_ratio_3_28  -2
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       0.15
    x_3_3     product_lb_24  -9.9999999999899988e-02
    x_3_3     product_ub_25  -1.0000000000010003e+00
    x_3_3     onehot_3_26  1
    x_3_3     stock_lb_40  3
    x_3_3     stock_ub_41  3
    x_3_3     parent_nonstrict_scope_42  0.3
    x_3_3     unique_nonzero_owner_63  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_24  1
    w_3_3     product_ub_25  1
    w_3_3     normalized_mass_3_27  1
    w_3_3     normalized_ratio_3_28  -3
    rho_3     normalized_ratio_3_28  1
    rho_3     block_pair_pos_45  1
    rho_3     block_pair_neg_46  -1
    rho_3     block_pair_pos_49  1
    rho_3     block_pair_neg_50  -1
    rho_3     block_pair_pos_53  -1
    rho_3     block_pair_neg_54  1
    rho_3     normalization_55  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     product_lb_29  -9.9999999999899988e-02
    x_4_0     product_ub_30  -1.0000000000010003e+00
    x_4_0     onehot_4_37  1
    x_4_0     parent_nonstrict_scope_42  0.15
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_29  1
    w_4_0     product_ub_30  1
    w_4_0     normalized_mass_4_38  1
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       -0.15
    x_4_1     product_lb_31  -9.9999999999899988e-02
    x_4_1     product_ub_32  -1.0000000000010003e+00
    x_4_1     onehot_4_37  1
    x_4_1     stock_lb_40  1
    x_4_1     stock_ub_41  1
    x_4_1     unique_nonzero_owner_64  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_31  1
    w_4_1     product_ub_32  1
    w_4_1     normalized_mass_4_38  1
    w_4_1     normalized_ratio_4_39  -1
    MARKER    'MARKER'                 'INTORG'
    x_4_2     product_lb_33  -9.9999999999899988e-02
    x_4_2     product_ub_34  -1.0000000000010003e+00
    x_4_2     onehot_4_37  1
    x_4_2     stock_lb_40  2
    x_4_2     stock_ub_41  2
    x_4_2     parent_nonstrict_scope_42  0.15
    x_4_2     unique_nonzero_owner_65  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_33  1
    w_4_2     product_ub_34  1
    w_4_2     normalized_mass_4_38  1
    w_4_2     normalized_ratio_4_39  -2
    MARKER    'MARKER'                 'INTORG'
    x_4_3     OBJ       0.15
    x_4_3     product_lb_35  -9.9999999999899988e-02
    x_4_3     product_ub_36  -1.0000000000010003e+00
    x_4_3     onehot_4_37  1
    x_4_3     stock_lb_40  3
    x_4_3     stock_ub_41  3
    x_4_3     parent_nonstrict_scope_42  0.3
    x_4_3     unique_nonzero_owner_66  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_35  1
    w_4_3     product_ub_36  1
    w_4_3     normalized_mass_4_38  1
    w_4_3     normalized_ratio_4_39  -3
    rho_4     normalized_ratio_4_39  1
    rho_4     block_pair_pos_47  1
    rho_4     block_pair_neg_48  -1
    rho_4     block_pair_pos_51  1
    rho_4     block_pair_neg_52  -1
    rho_4     block_pair_pos_53  1
    rho_4     block_pair_neg_54  -1
    rho_4     normalization_55  1
    a_1_2     block_pair_pos_43  1
    a_1_2     block_pair_neg_44  1
    a_1_2     full_original_Gini_56  -1
    a_1_3     block_pair_pos_45  1
    a_1_3     block_pair_neg_46  1
    a_1_3     full_original_Gini_56  -1
    a_1_4     block_pair_pos_47  1
    a_1_4     block_pair_neg_48  1
    a_1_4     full_original_Gini_56  -1
    a_2_3     block_pair_pos_49  1
    a_2_3     block_pair_neg_50  1
    a_2_3     full_original_Gini_56  -1
    a_2_4     block_pair_pos_51  1
    a_2_4     block_pair_neg_52  1
    a_2_4     full_original_Gini_56  -1
    a_3_4     block_pair_pos_53  1
    a_3_4     block_pair_neg_54  1
    a_3_4     full_original_Gini_56  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_1_0  unique_nonzero_owner_57  1
    service_0_1_0  service_visit_def_106  1
    service_0_1_0  free_load_conservation_107  -2
    service_0_1_0  original_T_including_depot_unload_126  14
    service_0_1_1  unique_nonzero_owner_58  1
    service_0_1_1  service_visit_def_106  1
    service_0_1_1  free_load_conservation_107  -1
    service_0_1_1  original_T_including_depot_unload_126  7
    service_1_1_0  unique_nonzero_owner_57  1
    service_1_1_0  service_visit_def_166  1
    service_1_1_0  free_load_conservation_167  -2
    service_1_1_0  original_T_including_depot_unload_186  14
    service_1_1_1  unique_nonzero_owner_58  1
    service_1_1_1  service_visit_def_166  1
    service_1_1_1  free_load_conservation_167  -1
    service_1_1_1  original_T_including_depot_unload_186  7
    service_0_2_0  unique_nonzero_owner_59  1
    service_0_2_0  service_visit_def_112  1
    service_0_2_0  free_load_conservation_113  -2
    service_0_2_0  original_T_including_depot_unload_126  14
    service_0_2_1  unique_nonzero_owner_60  1
    service_0_2_1  service_visit_def_112  1
    service_0_2_1  free_load_conservation_113  -1
    service_0_2_1  original_T_including_depot_unload_126  7
    service_1_2_0  unique_nonzero_owner_59  1
    service_1_2_0  service_visit_def_172  1
    service_1_2_0  free_load_conservation_173  -2
    service_1_2_0  original_T_including_depot_unload_186  14
    service_1_2_1  unique_nonzero_owner_60  1
    service_1_2_1  service_visit_def_172  1
    service_1_2_1  free_load_conservation_173  -1
    service_1_2_1  original_T_including_depot_unload_186  7
    service_0_3_1  unique_nonzero_owner_61  1
    service_0_3_1  service_visit_def_118  1
    service_0_3_1  free_load_conservation_119  1
    service_0_3_2  unique_nonzero_owner_62  1
    service_0_3_2  service_visit_def_118  1
    service_0_3_2  free_load_conservation_119  2
    service_0_3_3  unique_nonzero_owner_63  1
    service_0_3_3  service_visit_def_118  1
    service_0_3_3  free_load_conservation_119  3
    service_1_3_1  unique_nonzero_owner_61  1
    service_1_3_1  service_visit_def_178  1
    service_1_3_1  free_load_conservation_179  1
    service_1_3_2  unique_nonzero_owner_62  1
    service_1_3_2  service_visit_def_178  1
    service_1_3_2  free_load_conservation_179  2
    service_1_3_3  unique_nonzero_owner_63  1
    service_1_3_3  service_visit_def_178  1
    service_1_3_3  free_load_conservation_179  3
    service_0_4_1  unique_nonzero_owner_64  1
    service_0_4_1  service_visit_def_124  1
    service_0_4_1  free_load_conservation_125  1
    service_0_4_2  unique_nonzero_owner_65  1
    service_0_4_2  service_visit_def_124  1
    service_0_4_2  free_load_conservation_125  2
    service_0_4_3  unique_nonzero_owner_66  1
    service_0_4_3  service_visit_def_124  1
    service_0_4_3  free_load_conservation_125  3
    service_1_4_1  unique_nonzero_owner_64  1
    service_1_4_1  service_visit_def_184  1
    service_1_4_1  free_load_conservation_185  1
    service_1_4_2  unique_nonzero_owner_65  1
    service_1_4_2  service_visit_def_184  1
    service_1_4_2  free_load_conservation_185  2
    service_1_4_3  unique_nonzero_owner_66  1
    service_1_4_3  service_visit_def_184  1
    service_1_4_3  free_load_conservation_185  3
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_102  -1
    visit_0_1  in_degree_103  -1
    visit_0_1  order_active_lb_104  -1
    visit_0_1  order_active_ub_105  -4
    visit_0_1  service_visit_def_106  -1
    order_0_1  connected_order_arc_74  -1
    order_0_1  connected_order_arc_76  -1
    order_0_1  connected_order_arc_78  -1
    order_0_1  connected_order_arc_81  1
    order_0_1  connected_order_arc_88  1
    order_0_1  connected_order_arc_95  1
    order_0_1  order_active_lb_104  1
    order_0_1  order_active_ub_105  1
    visit_0_2  out_degree_108  -1
    visit_0_2  in_degree_109  -1
    visit_0_2  order_active_lb_110  -1
    visit_0_2  order_active_ub_111  -4
    visit_0_2  service_visit_def_112  -1
    order_0_2  connected_order_arc_74  1
    order_0_2  connected_order_arc_81  -1
    order_0_2  connected_order_arc_83  -1
    order_0_2  connected_order_arc_85  -1
    order_0_2  connected_order_arc_90  1
    order_0_2  connected_order_arc_97  1
    order_0_2  order_active_lb_110  1
    order_0_2  order_active_ub_111  1
    visit_0_3  out_degree_114  -1
    visit_0_3  in_degree_115  -1
    visit_0_3  order_active_lb_116  -1
    visit_0_3  order_active_ub_117  -4
    visit_0_3  service_visit_def_118  -1
    order_0_3  connected_order_arc_76  1
    order_0_3  connected_order_arc_83  1
    order_0_3  connected_order_arc_88  -1
    order_0_3  connected_order_arc_90  -1
    order_0_3  connected_order_arc_92  -1
    order_0_3  connected_order_arc_99  1
    order_0_3  order_active_lb_116  1
    order_0_3  order_active_ub_117  1
    visit_0_4  out_degree_120  -1
    visit_0_4  in_degree_121  -1
    visit_0_4  order_active_lb_122  -1
    visit_0_4  order_active_ub_123  -4
    visit_0_4  service_visit_def_124  -1
    order_0_4  connected_order_arc_78  1
    order_0_4  connected_order_arc_85  1
    order_0_4  connected_order_arc_92  1
    order_0_4  connected_order_arc_95  -1
    order_0_4  connected_order_arc_97  -1
    order_0_4  connected_order_arc_99  -1
    order_0_4  order_active_lb_122  1
    order_0_4  order_active_ub_123  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_67  -3
    arc_0_0_0  depot_departure_or_bypass_100  1
    arc_0_0_0  depot_return_or_bypass_101  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_67  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_68  -3
    arc_0_0_1  depot_departure_or_bypass_100  1
    arc_0_0_1  in_degree_103  1
    arc_0_0_1  original_T_including_depot_unload_126  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_68  1
    load_0_0_1  free_load_conservation_107  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_69  -3
    arc_0_0_2  depot_departure_or_bypass_100  1
    arc_0_0_2  in_degree_109  1
    arc_0_0_2  original_T_including_depot_unload_126  2
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_69  1
    load_0_0_2  free_load_conservation_113  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_70  -3
    arc_0_0_3  depot_departure_or_bypass_100  1
    arc_0_0_3  in_degree_115  1
    arc_0_0_3  original_T_including_depot_unload_126  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_70  1
    load_0_0_3  free_load_conservation_119  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_71  -3
    arc_0_0_4  depot_departure_or_bypass_100  1
    arc_0_0_4  in_degree_121  1
    arc_0_0_4  original_T_including_depot_unload_126  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_71  1
    load_0_0_4  free_load_conservation_125  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_72  -3
    arc_0_1_0  depot_return_or_bypass_101  1
    arc_0_1_0  out_degree_102  1
    arc_0_1_0  original_T_including_depot_unload_126  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_72  1
    load_0_1_0  free_load_conservation_107  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_73  -3
    arc_0_1_2  connected_order_arc_74  -5
    arc_0_1_2  out_degree_102  1
    arc_0_1_2  in_degree_109  1
    arc_0_1_2  original_T_including_depot_unload_126  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_73  1
    load_0_1_2  free_load_conservation_107  1
    load_0_1_2  free_load_conservation_113  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_75  -3
    arc_0_1_3  connected_order_arc_76  -5
    arc_0_1_3  out_degree_102  1
    arc_0_1_3  in_degree_115  1
    arc_0_1_3  original_T_including_depot_unload_126  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_75  1
    load_0_1_3  free_load_conservation_107  1
    load_0_1_3  free_load_conservation_119  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_77  -3
    arc_0_1_4  connected_order_arc_78  -5
    arc_0_1_4  out_degree_102  1
    arc_0_1_4  in_degree_121  1
    arc_0_1_4  original_T_including_depot_unload_126  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_77  1
    load_0_1_4  free_load_conservation_107  1
    load_0_1_4  free_load_conservation_125  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_79  -3
    arc_0_2_0  depot_return_or_bypass_101  1
    arc_0_2_0  out_degree_108  1
    arc_0_2_0  original_T_including_depot_unload_126  2
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_79  1
    load_0_2_0  free_load_conservation_113  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_80  -3
    arc_0_2_1  connected_order_arc_81  -5
    arc_0_2_1  in_degree_103  1
    arc_0_2_1  out_degree_108  1
    arc_0_2_1  original_T_including_depot_unload_126  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_80  1
    load_0_2_1  free_load_conservation_107  -1
    load_0_2_1  free_load_conservation_113  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_82  -3
    arc_0_2_3  connected_order_arc_83  -5
    arc_0_2_3  out_degree_108  1
    arc_0_2_3  in_degree_115  1
    arc_0_2_3  original_T_including_depot_unload_126  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_82  1
    load_0_2_3  free_load_conservation_113  1
    load_0_2_3  free_load_conservation_119  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_84  -3
    arc_0_2_4  connected_order_arc_85  -5
    arc_0_2_4  out_degree_108  1
    arc_0_2_4  in_degree_121  1
    arc_0_2_4  original_T_including_depot_unload_126  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_84  1
    load_0_2_4  free_load_conservation_113  1
    load_0_2_4  free_load_conservation_125  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_86  -3
    arc_0_3_0  depot_return_or_bypass_101  1
    arc_0_3_0  out_degree_114  1
    arc_0_3_0  original_T_including_depot_unload_126  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_86  1
    load_0_3_0  free_load_conservation_119  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_87  -3
    arc_0_3_1  connected_order_arc_88  -5
    arc_0_3_1  in_degree_103  1
    arc_0_3_1  out_degree_114  1
    arc_0_3_1  original_T_including_depot_unload_126  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_87  1
    load_0_3_1  free_load_conservation_107  -1
    load_0_3_1  free_load_conservation_119  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_89  -3
    arc_0_3_2  connected_order_arc_90  -5
    arc_0_3_2  in_degree_109  1
    arc_0_3_2  out_degree_114  1
    arc_0_3_2  original_T_including_depot_unload_126  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_89  1
    load_0_3_2  free_load_conservation_113  -1
    load_0_3_2  free_load_conservation_119  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_91  -3
    arc_0_3_4  connected_order_arc_92  -5
    arc_0_3_4  out_degree_114  1
    arc_0_3_4  in_degree_121  1
    arc_0_3_4  original_T_including_depot_unload_126  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_91  1
    load_0_3_4  free_load_conservation_119  1
    load_0_3_4  free_load_conservation_125  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_93  -3
    arc_0_4_0  depot_return_or_bypass_101  1
    arc_0_4_0  out_degree_120  1
    arc_0_4_0  original_T_including_depot_unload_126  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_93  1
    load_0_4_0  free_load_conservation_125  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_94  -3
    arc_0_4_1  connected_order_arc_95  -5
    arc_0_4_1  in_degree_103  1
    arc_0_4_1  out_degree_120  1
    arc_0_4_1  original_T_including_depot_unload_126  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_94  1
    load_0_4_1  free_load_conservation_107  -1
    load_0_4_1  free_load_conservation_125  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_96  -3
    arc_0_4_2  connected_order_arc_97  -5
    arc_0_4_2  in_degree_109  1
    arc_0_4_2  out_degree_120  1
    arc_0_4_2  original_T_including_depot_unload_126  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_96  1
    load_0_4_2  free_load_conservation_113  -1
    load_0_4_2  free_load_conservation_125  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_98  -3
    arc_0_4_3  connected_order_arc_99  -5
    arc_0_4_3  in_degree_115  1
    arc_0_4_3  out_degree_120  1
    arc_0_4_3  original_T_including_depot_unload_126  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_98  1
    load_0_4_3  free_load_conservation_119  -1
    load_0_4_3  free_load_conservation_125  1
    visit_1_1  out_degree_162  -1
    visit_1_1  in_degree_163  -1
    visit_1_1  order_active_lb_164  -1
    visit_1_1  order_active_ub_165  -4
    visit_1_1  service_visit_def_166  -1
    order_1_1  connected_order_arc_134  -1
    order_1_1  connected_order_arc_136  -1
    order_1_1  connected_order_arc_138  -1
    order_1_1  connected_order_arc_141  1
    order_1_1  connected_order_arc_148  1
    order_1_1  connected_order_arc_155  1
    order_1_1  order_active_lb_164  1
    order_1_1  order_active_ub_165  1
    visit_1_2  out_degree_168  -1
    visit_1_2  in_degree_169  -1
    visit_1_2  order_active_lb_170  -1
    visit_1_2  order_active_ub_171  -4
    visit_1_2  service_visit_def_172  -1
    order_1_2  connected_order_arc_134  1
    order_1_2  connected_order_arc_141  -1
    order_1_2  connected_order_arc_143  -1
    order_1_2  connected_order_arc_145  -1
    order_1_2  connected_order_arc_150  1
    order_1_2  connected_order_arc_157  1
    order_1_2  order_active_lb_170  1
    order_1_2  order_active_ub_171  1
    visit_1_3  out_degree_174  -1
    visit_1_3  in_degree_175  -1
    visit_1_3  order_active_lb_176  -1
    visit_1_3  order_active_ub_177  -4
    visit_1_3  service_visit_def_178  -1
    order_1_3  connected_order_arc_136  1
    order_1_3  connected_order_arc_143  1
    order_1_3  connected_order_arc_148  -1
    order_1_3  connected_order_arc_150  -1
    order_1_3  connected_order_arc_152  -1
    order_1_3  connected_order_arc_159  1
    order_1_3  order_active_lb_176  1
    order_1_3  order_active_ub_177  1
    visit_1_4  out_degree_180  -1
    visit_1_4  in_degree_181  -1
    visit_1_4  order_active_lb_182  -1
    visit_1_4  order_active_ub_183  -4
    visit_1_4  service_visit_def_184  -1
    order_1_4  connected_order_arc_138  1
    order_1_4  connected_order_arc_145  1
    order_1_4  connected_order_arc_152  1
    order_1_4  connected_order_arc_155  -1
    order_1_4  connected_order_arc_157  -1
    order_1_4  connected_order_arc_159  -1
    order_1_4  order_active_lb_182  1
    order_1_4  order_active_ub_183  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_127  -3
    arc_1_0_0  depot_departure_or_bypass_160  1
    arc_1_0_0  depot_return_or_bypass_161  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_127  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_1  arc_capacity_128  -3
    arc_1_0_1  depot_departure_or_bypass_160  1
    arc_1_0_1  in_degree_163  1
    arc_1_0_1  original_T_including_depot_unload_186  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_0_1  arc_capacity_128  1
    load_1_0_1  free_load_conservation_167  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_2  arc_capacity_129  -3
    arc_1_0_2  depot_departure_or_bypass_160  1
    arc_1_0_2  in_degree_169  1
    arc_1_0_2  original_T_including_depot_unload_186  2
    MARKER    'MARKER'                 'INTEND'
    load_1_0_2  arc_capacity_129  1
    load_1_0_2  free_load_conservation_173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_3  arc_capacity_130  -3
    arc_1_0_3  depot_departure_or_bypass_160  1
    arc_1_0_3  in_degree_175  1
    arc_1_0_3  original_T_including_depot_unload_186  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_0_3  arc_capacity_130  1
    load_1_0_3  free_load_conservation_179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_4  arc_capacity_131  -3
    arc_1_0_4  depot_departure_or_bypass_160  1
    arc_1_0_4  in_degree_181  1
    arc_1_0_4  original_T_including_depot_unload_186  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_0_4  arc_capacity_131  1
    load_1_0_4  free_load_conservation_185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_0  arc_capacity_132  -3
    arc_1_1_0  depot_return_or_bypass_161  1
    arc_1_1_0  out_degree_162  1
    arc_1_1_0  original_T_including_depot_unload_186  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_1_0  arc_capacity_132  1
    load_1_1_0  free_load_conservation_167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_2  arc_capacity_133  -3
    arc_1_1_2  connected_order_arc_134  -5
    arc_1_1_2  out_degree_162  1
    arc_1_1_2  in_degree_169  1
    arc_1_1_2  original_T_including_depot_unload_186  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_1_2  arc_capacity_133  1
    load_1_1_2  free_load_conservation_167  1
    load_1_1_2  free_load_conservation_173  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_3  arc_capacity_135  -3
    arc_1_1_3  connected_order_arc_136  -5
    arc_1_1_3  out_degree_162  1
    arc_1_1_3  in_degree_175  1
    arc_1_1_3  original_T_including_depot_unload_186  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_1_3  arc_capacity_135  1
    load_1_1_3  free_load_conservation_167  1
    load_1_1_3  free_load_conservation_179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_1_4  arc_capacity_137  -3
    arc_1_1_4  connected_order_arc_138  -5
    arc_1_1_4  out_degree_162  1
    arc_1_1_4  in_degree_181  1
    arc_1_1_4  original_T_including_depot_unload_186  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_1_4  arc_capacity_137  1
    load_1_1_4  free_load_conservation_167  1
    load_1_1_4  free_load_conservation_185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_0  arc_capacity_139  -3
    arc_1_2_0  depot_return_or_bypass_161  1
    arc_1_2_0  out_degree_168  1
    arc_1_2_0  original_T_including_depot_unload_186  2
    MARKER    'MARKER'                 'INTEND'
    load_1_2_0  arc_capacity_139  1
    load_1_2_0  free_load_conservation_173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_1  arc_capacity_140  -3
    arc_1_2_1  connected_order_arc_141  -5
    arc_1_2_1  in_degree_163  1
    arc_1_2_1  out_degree_168  1
    arc_1_2_1  original_T_including_depot_unload_186  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_2_1  arc_capacity_140  1
    load_1_2_1  free_load_conservation_167  -1
    load_1_2_1  free_load_conservation_173  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_3  arc_capacity_142  -3
    arc_1_2_3  connected_order_arc_143  -5
    arc_1_2_3  out_degree_168  1
    arc_1_2_3  in_degree_175  1
    arc_1_2_3  original_T_including_depot_unload_186  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_2_3  arc_capacity_142  1
    load_1_2_3  free_load_conservation_173  1
    load_1_2_3  free_load_conservation_179  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_2_4  arc_capacity_144  -3
    arc_1_2_4  connected_order_arc_145  -5
    arc_1_2_4  out_degree_168  1
    arc_1_2_4  in_degree_181  1
    arc_1_2_4  original_T_including_depot_unload_186  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_2_4  arc_capacity_144  1
    load_1_2_4  free_load_conservation_173  1
    load_1_2_4  free_load_conservation_185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_0  arc_capacity_146  -3
    arc_1_3_0  depot_return_or_bypass_161  1
    arc_1_3_0  out_degree_174  1
    arc_1_3_0  original_T_including_depot_unload_186  2.1081851067789197e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_3_0  arc_capacity_146  1
    load_1_3_0  free_load_conservation_179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_1  arc_capacity_147  -3
    arc_1_3_1  connected_order_arc_148  -5
    arc_1_3_1  in_degree_163  1
    arc_1_3_1  out_degree_174  1
    arc_1_3_1  original_T_including_depot_unload_186  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_3_1  arc_capacity_147  1
    load_1_3_1  free_load_conservation_167  -1
    load_1_3_1  free_load_conservation_179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_2  arc_capacity_149  -3
    arc_1_3_2  connected_order_arc_150  -5
    arc_1_3_2  in_degree_169  1
    arc_1_3_2  out_degree_174  1
    arc_1_3_2  original_T_including_depot_unload_186  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_3_2  arc_capacity_149  1
    load_1_3_2  free_load_conservation_173  -1
    load_1_3_2  free_load_conservation_179  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_3_4  arc_capacity_151  -3
    arc_1_3_4  connected_order_arc_152  -5
    arc_1_3_4  out_degree_174  1
    arc_1_3_4  in_degree_181  1
    arc_1_3_4  original_T_including_depot_unload_186  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_3_4  arc_capacity_151  1
    load_1_3_4  free_load_conservation_179  1
    load_1_3_4  free_load_conservation_185  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_0  arc_capacity_153  -3
    arc_1_4_0  depot_return_or_bypass_161  1
    arc_1_4_0  out_degree_180  1
    arc_1_4_0  original_T_including_depot_unload_186  9.4280904158206347e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_4_0  arc_capacity_153  1
    load_1_4_0  free_load_conservation_185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_1  arc_capacity_154  -3
    arc_1_4_1  connected_order_arc_155  -5
    arc_1_4_1  in_degree_163  1
    arc_1_4_1  out_degree_180  1
    arc_1_4_1  original_T_including_depot_unload_186  6.6666666666666663e-01
    MARKER    'MARKER'                 'INTEND'
    load_1_4_1  arc_capacity_154  1
    load_1_4_1  free_load_conservation_167  -1
    load_1_4_1  free_load_conservation_185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_2  arc_capacity_156  -3
    arc_1_4_2  connected_order_arc_157  -5
    arc_1_4_2  in_degree_169  1
    arc_1_4_2  out_degree_180  1
    arc_1_4_2  original_T_including_depot_unload_186  1.4907119849998598e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_4_2  arc_capacity_156  1
    load_1_4_2  free_load_conservation_173  -1
    load_1_4_2  free_load_conservation_185  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_4_3  arc_capacity_158  -3
    arc_1_4_3  connected_order_arc_159  -5
    arc_1_4_3  in_degree_175  1
    arc_1_4_3  out_degree_180  1
    arc_1_4_3  original_T_including_depot_unload_186  1.3333333333333333e+00
    MARKER    'MARKER'                 'INTEND'
    load_1_4_3  arc_capacity_158  1
    load_1_4_3  free_load_conservation_179  -1
    load_1_4_3  free_load_conservation_185  1
RHS
    RHS1      OBJ       -4.4999999999999996e-01
    RHS1      onehot_1_6  1
    RHS1      onehot_2_15  1
    RHS1      onehot_3_26  1
    RHS1      onehot_4_37  1
    RHS1      stock_lb_40  1
    RHS1      stock_ub_41  4
    RHS1      parent_nonstrict_scope_42  1.22500001
    RHS1      normalization_55  1
    RHS1      connected_order_arc_74  -4
    RHS1      connected_order_arc_76  -4
    RHS1      connected_order_arc_78  -4
    RHS1      connected_order_arc_81  -4
    RHS1      connected_order_arc_83  -4
    RHS1      connected_order_arc_85  -4
    RHS1      connected_order_arc_88  -4
    RHS1      connected_order_arc_90  -4
    RHS1      connected_order_arc_92  -4
    RHS1      connected_order_arc_95  -4
    RHS1      connected_order_arc_97  -4
    RHS1      connected_order_arc_99  -4
    RHS1      depot_departure_or_bypass_100  1
    RHS1      depot_return_or_bypass_101  1
    RHS1      original_T_including_depot_unload_126  100
    RHS1      connected_order_arc_134  -4
    RHS1      connected_order_arc_136  -4
    RHS1      connected_order_arc_138  -4
    RHS1      connected_order_arc_141  -4
    RHS1      connected_order_arc_143  -4
    RHS1      connected_order_arc_145  -4
    RHS1      connected_order_arc_148  -4
    RHS1      connected_order_arc_150  -4
    RHS1      connected_order_arc_152  -4
    RHS1      connected_order_arc_155  -4
    RHS1      connected_order_arc_157  -4
    RHS1      connected_order_arc_159  -4
    RHS1      depot_departure_or_bypass_160  1
    RHS1      depot_return_or_bypass_161  1
    RHS1      original_T_including_depot_unload_186  100
BOUNDS
 LO BND1      t         9.9999999999899988e-02
 UP BND1      t         1.0000000000010003e+00
 UP BND1      q         1
 BV BND1      x_1_0   
 UP BND1      w_1_0     1.0000000000010003e+00
 BV BND1      x_1_1   
 UP BND1      w_1_1     1.0000000000010003e+00
 BV BND1      x_1_2   
 UP BND1      w_1_2     1.0000000000010003e+00
 UP BND1      rho_1     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     1.0000000000010003e+00
 BV BND1      x_2_1   
 UP BND1      w_2_1     1.0000000000010003e+00
 BV BND1      x_2_2   
 UP BND1      w_2_2     1.0000000000010003e+00
 UP BND1      rho_2     1
 BV BND1      x_3_0   
 UP BND1      w_3_0     1.0000000000010003e+00
 BV BND1      x_3_1   
 UP BND1      w_3_1     1.0000000000010003e+00
 BV BND1      x_3_2   
 UP BND1      w_3_2     1.0000000000010003e+00
 BV BND1      x_3_3   
 UP BND1      w_3_3     1.0000000000010003e+00
 UP BND1      rho_3     1
 BV BND1      x_4_0   
 UP BND1      w_4_0     1.0000000000010003e+00
 BV BND1      x_4_1   
 UP BND1      w_4_1     1.0000000000010003e+00
 BV BND1      x_4_2   
 UP BND1      w_4_2     1.0000000000010003e+00
 BV BND1      x_4_3   
 UP BND1      w_4_3     1.0000000000010003e+00
 UP BND1      rho_4     1
 UP BND1      a_1_2     1
 UP BND1      a_1_3     1
 UP BND1      a_1_4     1
 UP BND1      a_2_3     1
 UP BND1      a_2_4     1
 UP BND1      a_3_4     1
 BV BND1      service_0_1_0
 BV BND1      service_0_1_1
 BV BND1      service_1_1_0
 BV BND1      service_1_1_1
 BV BND1      service_0_2_0
 BV BND1      service_0_2_1
 BV BND1      service_1_2_0
 BV BND1      service_1_2_1
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 UP BND1      visit_0_1  1
 UP BND1      order_0_1  4
 UP BND1      visit_0_2  1
 UP BND1      order_0_2  4
 UP BND1      visit_0_3  1
 UP BND1      order_0_3  4
 UP BND1      visit_0_4  1
 UP BND1      order_0_4  4
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  3
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  3
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  3
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  3
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  3
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  3
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  3
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  3
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  3
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  3
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  3
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  3
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  3
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  3
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  3
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  3
 UP BND1      visit_1_1  1
 UP BND1      order_1_1  4
 UP BND1      visit_1_2  1
 UP BND1      order_1_2  4
 UP BND1      visit_1_3  1
 UP BND1      order_1_3  4
 UP BND1      visit_1_4  1
 UP BND1      order_1_4  4
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_1
 FX BND1      load_1_0_1  0
 BV BND1      arc_1_0_2
 FX BND1      load_1_0_2  0
 BV BND1      arc_1_0_3
 FX BND1      load_1_0_3  0
 BV BND1      arc_1_0_4
 FX BND1      load_1_0_4  0
 BV BND1      arc_1_1_0
 UP BND1      load_1_1_0  3
 BV BND1      arc_1_1_2
 UP BND1      load_1_1_2  3
 BV BND1      arc_1_1_3
 UP BND1      load_1_1_3  3
 BV BND1      arc_1_1_4
 UP BND1      load_1_1_4  3
 BV BND1      arc_1_2_0
 UP BND1      load_1_2_0  3
 BV BND1      arc_1_2_1
 UP BND1      load_1_2_1  3
 BV BND1      arc_1_2_3
 UP BND1      load_1_2_3  3
 BV BND1      arc_1_2_4
 UP BND1      load_1_2_4  3
 BV BND1      arc_1_3_0
 UP BND1      load_1_3_0  3
 BV BND1      arc_1_3_1
 UP BND1      load_1_3_1  3
 BV BND1      arc_1_3_2
 UP BND1      load_1_3_2  3
 BV BND1      arc_1_3_4
 UP BND1      load_1_3_4  3
 BV BND1      arc_1_4_0
 UP BND1      load_1_4_0  3
 BV BND1      arc_1_4_1
 UP BND1      load_1_4_1  3
 BV BND1      arc_1_4_2
 UP BND1      load_1_4_2  3
 BV BND1      arc_1_4_3
 UP BND1      load_1_4_3  3
ENDATA
