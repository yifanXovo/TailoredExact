# Latest checkpoint:all120 native positions complete; PDF46-page visual QA in progress

UTC:2026-10-28T07:48:07.372719+00:00

Active goal remains unfinished. All120 positions are sealed/performance eligible and original serial session11915 exited0; PID22868 original birth no longer exists. Read infra/native_idle_confirmation.json and run_loop_return.json. No native/observer process is needed now. G1=118955.40056290105s (33.043166823028066h), remaining=97044.59943709895s of216000s, no open fees. Do not rerun campaign or add a generic stability grid.

Full pure analyze succeeded; actual120 rows,126 paired comparisons,16 base inputs/20 physical/24 objective configurations. Stage decision RETAIN_ACCEPTED_GI_TBC is actual. Entry promotion and actual28 CLI+6refusal zero-native check passed: entry_check.json (219sources/93helpers), old config SHA unchanged, current profile config/gi_tbc_round137.json. No extra Optimize/build/vendorDLL load occurred.

Actual body/appendices/supplement/bibliography/figure and PDF exported. Current revision03 PDF SHA=6afcd39fce22f3226a3a4f7a47a053d4865b68000f26cbb938bdc83ff1c70a4c,46pages, no outside-page or replacement glyphs, no overfull boxes. Page PNGs/contact sheets in E:\codes\ExactEBRP-work\temp\round137\pdf\visual_QA_6afcd39fce22. review/pdf_visual_progress.json records actual reviewed current pages (including only exact-PNG carryover); actual_visual_inspection_complete is still FALSE. Finish every remaining page before acceptance. Prior draft PDFs/MD/TeX and all render/failure evidence are preserved under TEMP/pdf/attempt01-03 and SHA-specific QA folders. Marker already succeeded exactly once; do not invoke it again. Plotting Matplotlib3.11.2 was installed only under EWork/build-cache/round137/python-packages after native finished; initial missing-module failure and separate ordinary clocks remain.

Independent reviewer is completing review/final_science_review.md. Actual independent120 physical-witness recomputations,30 canonical models/24root pairs,126 pair/class/material/endpoint results, all AM/cost/guard CSVs and entry/source/PE/DLL hash bindings passed preliminarily. P28 coldP has rejected native source (3records,call1) but legitimate current-rule independent ownzero F=0 certificate; it does not restore native proof or retroactively re-count R132. Actual K15 all3 deletion-time directions reverse at Seed1; no visible CR/CG initial objective increments do NOT imply inactive/slack/redundant rows. That prose was narrowed without changing decision/entry binding or data. Both main Seeds have GI3/4 P1/4 PS1/4; hard opposed/open outcomes remain.

Remaining mandatory: finish current PDF actual all-page QA and final scientific/manuscript/entry review; apply/read final4docs plus reproducibility from TEMP/drafts with actual facts; current-only source/raw carriers and local strict pure preflight; freeze scientific manifest, normal commit/push; one owned anonymous fixed-commit public recovery (not R135 repeat); English base=main Draft PR/readback/attachment; concrete bounded current-only cleanup; final A-H completion audit and closeout commit. Source capsule requires actual entry receipts/current doc hashes. Ordinary operations are measured outside native fees in ordinary_operations.json and excluded from the immutable scientific manifest.

Protect original E:/codes/ExactEBRP and its user changes. All new assets remain under E:/codes/ExactEBRP-work. Keep unique raw/failures/runtime PE/DLL/build and plot dependencies/active tree/old rounds. Previous cleanup-script preparation was auto-review rejected before execution; no cleanup yet. After actual publicPASS+PR inspect real approved final-page PNG paths/SHA and perform only safe finite current-round reconstructible duplicate cleanup, recording bytes and observed free-space change. No merge/force-push/old PR cleanup/email/submission. Three author/source fact groups remain explicitly nonblocking in supplement/read-packet.

---

und137 GI-TBC consolidation

The goal is active. Scientific results, manuscript/PDF, public recovery and PR
are not yet complete. Do not turn planned positions into measured evidence.

Use `E:/codes/ExactEBRP-work/worktrees/paper-current`, branch
`codex/round137-gi-tbc-consolidation`. Verified base main is
`b2b940c1e517a72e226ec60fc49ff19651737632`; original
`E:/codes/ExactEBRP` remains protected. Explicitly inherit WORKSPACE_POLICY:
new assets remain under ExactEBRP-work and post-PR cleanup is bounded to this
round's reconstructible duplicates after evidence/public recovery acceptance.

Read goal.md, experiment_plan.json, input_manifest.json, candidate_manifest.json,
matrix_frozen.json, initialization.json and review/matrix_admission.json.
The plan is 120 new positions, 174600 cap-seconds, with a 216000-second total
new native computation ceiling. Metered native/diagnostic processes count once;
their nested H/LP/MIP do not count again. Build, pure readback and writing have
separate clocks. Normal default remains ms2, pair-only, AP off and tau=.08.

New source is frozen at commit779713ad9a0b01edc538ecb64df9438739127be3.
The final PE/source SHA set is in candidate_manifest.json. Default-off K15
export equals accepted R135 exactly; the three deletion exports retain all
shared variable bounds/types and objective. The first malformed A/B export
and every correction remain in qualification/ and infra/; none was optimized.
The AM CLI applies to the actual first-class split_threshold after presets.
Actual control readback is checked before qualification closeout.

The source recipe was committed before once-only generation. There are six
known representatives plus ten new base draws from archived CITI/CABI/Divvy
snapshots: 16 base inputs,20 physical configurations. B3 adds four objective
configurations. Seeds and variants are repeated measurements, not new inputs.
B3 floor metadata was corrected before native launch to scale with rho; old
plan/matrix and exact changes remain in infra/. No argv/input/order was changed.

Commands use `D:/msys64/ucrt64/bin/python.exe -B`:

```
scripts/round137_common.py budget
scripts/round137_campaign.py run
```

`run` requires exact independent matrix admission, never repeats any fee label,
and skips only successfully closed arms. It executes all native positions
serially with one thread/CPU-affinity mask4, including own complete H. Inspect
active_position.json, runtime_status.json and the relevant fees/arm_NNN/PID.json
and receipt.json. Live polling should read only these small durable records.
Use the OS PID plus creation time to distinguish running and dead processes.
Never automatically repeat an interrupted/unsealed native arm. If production
is sealed and pure verification failed, repair/replay only the affected pure
verification using a separately identified receipt and keep original clocks.

After the matrix, assemble complete evidence, derived scientific tables,
mechanism/cost/AM/Seed analysis and the stage decision. Maintain R135 body,
appendices, supplement and references as the sole manuscript lineage. Reorganize
the experiment narrative by questions and retain all adverse/open outcomes.
The PDF skill operation marker has ALREADY succeeded exactly once before first
document authoring; see document_operation.json. Do not invoke it again. Export
only outside timed solves, and visually inspect every page. Arrange the final
independent review, package current-only raw/source evidence, perform one finite
public restore without Optimize/build/native loading, push normally and create
an English Draft PR with base main. Attach the created PR and read back actual
base/head/Draft/open state. Do not merge or close old PRs. Finish bounded cleanup
and record retained unique raw/failures/runtime assets and observed free bytes.

Stage completion requires the actual science and delivery above, not only a
running process. Update this file at meaningful boundaries.

## Latest execution checkpoint (2026-10-28T01:22:46.254121+00:00)

The serial queue has sealed positions 1--93. Active position
94 is R137_094_K-35-U_S0_S2R, PID 65492 with verified birth
134376238020579900, in exec session11915. Settled native G1 is
99333.732675s (27.592704h), remaining
116666.267325s. The active reservation must fit that ceiling.
Inspect actual PID/birth and live session, not this static note; never start
another healthy runner. No native solve has been repeated.

B1/B2/B3/C1 Seed0 are complete with scoped reviews. B1 GI9/12C vsP7/12,PS7/12.
B2 GI4/8(alln20),P0/8,PS0/8; alln35 resource methods open. Four controlled T
pairs have strict value separation. Preserve PS X35 time reversal, K35 opposed
endpoints and conditional startup outcomes. B3 view18=12new+6shared,GI2/6C vs
P0/6,PS0/6, six within-weight full-H pairs match; n35 all9 methods open with
GI better finite endpoints at eachrho. Whole study stays16 base inputs,20
physical and24 objective configurations. See respective narrative reviews.

C1 has12 views=8new+4shared defaults, eachtau.04/.08/.16 certifies2/4roles
(K15/UC), K20/K35 open. All role triplets match input/PE/physical/cap/Seed and
independent full H; actual postpreset thresholds verified. Nine finite gates
(all below.04),12 no-strict terminals,9 UC logicalsplits (unscored, independent
tau). K35 only reaches a no-strict terminal, not an actual threshold gate;
this differs from having no child observations. The exact-close action label
is not a completed certificate. Main6.1 and C1_complete_AM_review.md retain
actual complete-run costs and scope. Depth8/width1e-4 recorded-guard analysis
is still deferred:12 audit/leaf/split sets total101292893B bystat, not read
during timing. Use actual audit source_rejections, not source_reduced proxy.
Do not infer global limit inactivity from shallow AM decisions. Seed1 pending.

C2 first3 roles complete15 views=12new+3shared. K15 allownC: full112.769303,
root112.648924,-AB128.324867,-CR75.106399,-CG143.150331s. Full beats AB/CG
deletion materially, loses to CR deletion materially, root difference is not
material. UC allownC in1.872062--4.917750s with allpair differences<10s; no
substantive full-cost ranking. Visible logicalsplits alone do not establish
net outer-package benefit. Every matched H/input/PE/physical/cap/Seed and
actual single-group readback is qualified. Do not assign additive component shares.

K20 all5 eligible/open at the identical U=.7168065462777502, Tcertnull. Final L:
full .7053557934942464; -CR .7034438462201227; -CG .7052959899997195;
root .7064051401819257; -AB .7041277559892903. Three deletions have lower
final L, but root-only has higher final L: retain this adverse endpoint for
full control. These are final qualified bounds, not initial LP optima or proof
time rankings. Production~1172s and actual verification36--62s remain separate.

New K35 CG pair14/93 is eligible/open/Tcertnull with same complete H/input/PE/
physical/cap2400/Seed0. Full U/L=.6928543586313136/.565765681464995;
-CG .6662619195893547/.5509797701128951. Deletion improves U, full improves L;
the smaller deleted gap is not endpoint dominance or a certificate-time win.
Only two tiny AM CSV pairs (1302/1219B) were read: each has one finite no-strict
terminal exact-close label and no finite gate. Coarse labels do not imply the
same native search trajectory. Main6.2 records the opposed result and assertions.
Current review/C2_review.md accepts the first3 roles plus this pair in its
scoped sections; other K35/Seed1/root/model/Work/final120/PDF remain pending.

Remaining C2:94 K35-root,95 K35-AB,96 K35-CR. D2 Seed1 runs97--120.
Full native-idle analyze/decision/plots/assembly/PDF have not run. Only small
sealed endpoints/AM CSV and AST checks ran while timing. Complete root-domain/
objective/cutoff/model/Work/node/physical decomposition/guard/Seed1 analysis
is still required. Rewrite scientific conclusions from actual full evidence;
passing all120 alone is not completion. Add the actual five-column mechanism/
math/experiment/supported-conclusion/boundary table (current note is definitions).

PDF source date is now fixed: pdf() computes the actual Asia/Shanghai date at
export, replaces the inherited nested export anchor once, and records the requested
date/timezone in pdf_export.json. AST/anchor checks passed (preview28 October2026),
no PDF export or operation-marker reinvocation occurred. Actual runtime export
and all-page visual QA still required. Check figure/table legibility and formal prose.

Remaining delivery: actual entry promotion/dry-run preserving old config bytes;
complete maintained paper/appendices/supplement/bibliography+checkedPDFs; final
independent integration; current-only carriers/local pure replay and one fixed-
commit public restore; normal push/English Draft PR+attachment/readback; bounded
post-PR cleanup. Goal active; author facts nonblocking; no new confirmation question.
Protect E:/codes/ExactEBRP, all new assets stay ExactEBRP-work. Last E free
135472099328B at27October23:56UTC. Read execution_state.json for current data.

## Active execution and directed repair (27 October2026)

The independent current admission is matrix SHA
`26f295da36097cd662b9c2ca049ab2452f0b295dfcdb12dd4b726ff25190c894`.
The serial `run` process is active in exec session11915. Never start another
runner while its PID/birth record is healthy; inspect active_position.json and
the current fee's launch.json/PID.json first. The root driver's PID is recorded
as the fee launch's parent_pid; owned native child birth is recorded under raw.

The first P producer completed normally and was sealed. Its first pure reader
attempt failed because R135's AP-state-only audit is inapplicable to original
compact P/PS. The scoped Round137 adapter now omits that inapplicable check for
P-GRB/P-S, asserts no state selectors/AP enablement, and retains every R134
canonical/type/physical/Start/lifecycle/proof check. M-B retains the full AP-off
audit. Pure replay of the original sealed P passed, and six raw primary hashes
did not change. No native solve was repeated. The old failure and repair work
are in repair/verification_001; independent review accepted the narrow amendment
and preserved the previous admission. Actual P production time571.702s and the
real142.568s verification delay remain; pure corrected audit work was2.509s.
Treat the old nonzero arm_001 fee exit as this resolved pure-reader error, not
an unresolved native failure or a reason to rerun P.

The first full triplet is qualified: K15 P/PS open at U=.5922648822560825,
L=.527662772138667/.5205834419787349; GI-TBC certifies in112.769303s at
U=.5922648822560825,L=.5922648792385111. PS/GI-TBC H semantic and fleet hashes
match, each complete and independently paid. Later results are in the active
queue; don't infer completion from this snapshot or partial reports/summary.

New offline scripts are prepared and have passed only an AST syntax check:
round137_analyze.py, round137_decision.py, round137_plots.py,
round137_documents.py, round137_release.py, round137_portable_check.py and the
inherited round137_public_restore.py. They are not all runtime-validated yet.
They do not change the measured solver graph. The manuscript method/model,
complete R135 appendices and bibliography are prepared; no PDF has been exported.

After the run, execute analyze, inspect all data and directed issues, then
decision; review/edit the scientific interpretations, use DOCUMENT_PYTHON for
plots, assemble the maintained complete paper, export PDF and visually inspect.
No incomplete panel is a completed draft. The release uses the established
archive/recovery format and closed-root engine; validate the new wrapper
transport locally before the one real public restore, fixing only pure/transport
errors. No commercial native assets may enter capsules. Don't rerun R135's
completed public restore. Final integration, Draft PR attachment/readback and
bounded current-round cleanup remain outstanding. Current additional source
edits/results are partly uncommitted; defer heavy Git/archive/PDF operations
until native work is idle and then commit them normally.

## Offline interim review fixes

The first independent offline-prototype review is saved in
review/offline_pipeline_interim.md. Its concrete issues are addressed in the
current prototypes and logged in review/offline_pipeline_fixes.json:

* Relative gap uses the accepted helper, including null plus reason at zero U.
* AM joins finite-score and all-child C6 ledgers by decision_sequence. Finite
  score gates, finite no-strict terminals, logical one/both-child infeasibility
  and unexposed runs remain distinct; legacy C6 rho is labelled separately.
* Final materialized-leaf geometry, decision-parent depth and evaluated/probed
  child depth are distinct. Recorded eligibility rows are now joined to geometry
  within retained scheduler epochs to audit depth8/width1e-4 conditions. A source
  rejection/reset or missing/other case is unknown. Eligible work can stop before
  its row, so missing rows do not prove no attempt; depth short-circuits width,
  and a width condition that would also fail is not another causal rejection.
  Never infer a trigger from a zero-width proof or max decision-parent depth.
* Root-LP attribution flags actual matched own H, shared domain, objective and
  cutoff, and requires complete observed OPTIMAL LP points. Optional incomplete
  root points remain unknown.
* Closed recovery admits only exact declared current input/progress paths,
  including known inputs outside R137; binds capsule/helper/matrix/plan/input
  hashes and complete identity/launch equality; recomputes stage denominators.
* Maintained method/appendix names and current parameter/source links are
  updated; historical R135 links/figures are pinned. The strict positive-floor
  statement now explicitly requires lambda>0/rho>0. Complete mathematical
  derivations and algorithm subprocedures remain, with changed metadata tracked.

Only lightweight source/small-closed-ledger checks and AST syntax checks have
run while the serial producer is active. Full aggregation, figure/PDF export,
closed-root runtime testing and final integrated acceptance remain deferred.
The additional known UC-B20-B triplet is qualified-certified: GI-TBC4.148974s,
P315.402757s, PS236.090507s, all at U=.5773330699702928. The queue is beyond
these first nine completed positions; consult live durable status and PID/birth.

The narrow eligibility reconstruction review and its applied qualifications are
in review/eligibility_limit_review.md and
review/eligibility_limit_review_applied.json. A bounded check of1486 indexed
historical input hashes found no exact match among the ten new base draws;
historical_input_identity_check.json pins the relevant index/manifests without
restoring old raw. Same-source station overlap remains a separate disclosed issue.

K-20-S now has a complete qualified all-open triplet: P U=.7277024349545519,
L=.5418678959314336; PS U=.7752127578025221,L=.5412332381072466;
GI-TBC U=.7168065462777502,L=.7053557934942464. Production costs are about1171s
per method (full actual clocks remain in the endpoint files). The GI-TBC pure
verification cost is61.14s and is separately measured. P/PS gives a finite
startup counterexample; GI-TBC improves both endpoints on this input but has no
certificate-time ranking because all remain open. The report prototype now
explicitly retains both-open endpoint dominance and opposing-U/L trade-offs.
The serial queue has entered n35. Public replay timeouts remain unvalidated;
profile the full local pure replay after native completion before deciding if
the inherited bounded recovery time window needs a directed adjustment.

The later source-only generator table correction is recorded in
infra/future_generator_table_fix.json. It replaces the generic regional1.5
multiplier by the explicit preregistered B1 table (n20 regional7200). The
historical recipe, generator SHA/commit and pre-run N-X20-B correction remain
unchanged. This setup helper is outside the measured frozen helper graph;
all six actual new B1 T values match the corrected table. No draw, native run,
input bytes, frozen identity or current runtime control was changed.

review/generator_and_entry_review.md independently accepts this narrow fix.
For final entry promotion after study completion, preserve config/paper_s2.json
bytes: candidate_manifest.config_SHA binds that historical configuration. The
smallest promotion is to point scripts/paper_s2.py CONFIG at the already prepared
config/gi_tbc_round137.json, update human labels, and qualify the inherited R135
argv provenance in that new config with the actual R137 source/matrix authority.
Neither entry nor config is in the measured helper/source graph. Do not mark
this future promotion or its dry-run argv validation as already done.

K-35-U positions13–15 are complete, qualified and all open. PS:
U=.7674566047247167,L=.33192176731164724,Tproduce2370.995625s;
GI-TBC: U=.6928543586313136,L=.565765681464995,Tproduce2371.151858s;
P: U=.6647466018182986,L=.33555561820120866,Tproduce2371.058098s.
All Tcert are null. PS/GI-TBC each paid complete H and have identical semantic
and fleet hashes; PS's final U equals its own startup objective. P improves
both endpoints relative to PS. GI-TBC versus P is an opposed-endpoint witness:
GI-TBC has better L, P has better U. Do not use GI-TBC's smaller gap as a full
dominance claim, certificate-time ranking or individual mechanism attribution.
The preselected D2 Seed1 K35 triplet already addresses this role; no additional
H-seed grid or result-dependent native rerun has been added.

X-35-B positions16–18 are qualified-certified at U=L=0. Tcert/Tproduce:
GI-TBC17.904565s, P158.584505s, PS7.450143s. PS/GI-TBC's independently paid
complete-H semantic/fleet hashes match. PS is10.454422s faster than GI-TBC,
which passes the declared max(10s,10% of faster time) material-difference rule.
Retain this adverse main-panel result; it is not a newly discovered absence of
prior PS reversals, and no result-dependent extra Seed/H grid has been added.
All six known B1 configurations (18positions) are complete. First new input
N-B15-B positions19–21 is also complete: all three qualify certificates at
F=.25049393794039065. P Tcert279.663094s, PS306.306815s, GI-TBC24.068387s;
PS/GI-TBC complete-H semantic/fleet hashes match. GI-TBC's time advantages
are substantive. PS versus P's26.643721s difference falls below10% of P's
279.663094s, so it is not substantive under the declared rule. Preserve tiny
floating signed U-L values (including negative near-roundoff), not forced0.
This B1 balanced input was not generated with the B2 shortage-floor guarantee.
Second new input N-X15-S positions22–24 is qualified-certified at
F=.6289860772978431: PS Tcert401.931190s, GI-TBC10.268252s, P538.867290s.
PS/GI-TBC's complete-H semantic/fleet hashes also match. This is another
new-input positive-objective benefit, not evidence for unmeasured n20/n35.
New n20 N-C20-U positions25–27 is complete: GI-TBC qualifies a certificate
at F=.24550506918249843 in265.529478s. P remains open at
U=.2485506937997089,L=.21771891484402986; PS remains open at
U=.2523085746005095,L=.21473285888120416. Both open Tcert stay null;
production clocks are1171.178888s/1171.144176s. PS/GI-TBC complete-H hashes
match; P improves both finite endpoints relative to PS. Do not compute a
certificate-time ratio by treating either open cap as a solution time.

New n20 N-X20-B positions28–30 is qualified-certified at U=L=0:
P24.089238s, PS6.085146s, GI-TBC7.455366s. PS/GI-TBC complete-H hashes
match. Their1.370220s difference is not substantive under the10s threshold.
All three actual physical T values are7200, matching preregistration and the
pre-run metadata correction, not the old generator multiplier8100.
New n35 N-B35-S positions31–33 is qualified-all-open. GI-TBC:
U=.450291503262878,L=.38931060164210607; PS:
U=.48601332274144055,L=.37334305051935857; P:
U=.8448740640910452,L=.3719077984346302. GI-TBC improves both endpoints
over both compact controls, but no certificate-time ranking exists. Each
production clock is about2371s; PS/GI-TBC's complete-H hashes match.
New n35 N-C35-B positions34–36 is qualified-certified at U=L=0:
GI-TBC59.623450s, P397.807241s, PS154.668136s; complete-H hashes match.

B1 is complete at36/36positions and12physical configurations, Seed0 only.
GI-TBC certifies9/12, P7/12 and PS7/12. All12 PS/GI-TBC complete-H semantic
and fleet hash pairs match; no own H is transferred. GI-TBC's three opens are
K-20-S,K-35-U,N-B35-S. Existing reversals, nonmaterial differences and opposed
endpoints above remain. The lightweight closed-endpoint checkpoint is in
execution_state.json; full analysis and all other stages are still incomplete.
B2's first configuration R-B20-S-T1 positions37–39 is complete, with
T3300,rho1,Omega13.47,lambda=.07423904974016332,shortage20 and prior
positive floor.10393466963622865. GI-TBC qualifies a certificate at
U=.4807354359737054,L=.4807354229937215 in784.143484s, with18.178927s
separate verification. P remains open at U=.5400846274202015,
L=.3581581080473884; PS remains open at U=.48663902305130596,
L=.3653241651989888. Open Tcert stay null; both production clocks are
about1171s. PS/GI-TBC complete-H semantic/fleet hashes match.
R-B20-S-T2 positions40–42 is also complete, with physical T5100 and all
other physical/objective data fixed. GI-TBC qualifies a certificate at
U=.19847344686459328,L=.19847344686456547 in538.602932s; verification5.738018s.
PS remains open at U=.20846500235200272,L=.14620273802344969;
P remains open at U=.26909520672934206,L=.14126238850787237. Both open
Tcert remain null, production about1171s. PS/GI-TBC own-H hashes match.
The first complete dual-T base thus has both GI-TBC certificates and four
compact opens. T1/T2's disjoint qualified value intervals establish a strict
resource value improvement; the lower certificate cost on this pair is an
observation, not a general runtime ordering. The earlier PS-T2-upper/T1-GI-lower
separation witness in execution_state.json is a timestamped intermediate
observation, not a claim that GI-TBC T2 still lacks a certificate.

R-X20-S-T1 positions43–45 is complete. All three feasible U values are
.6453250303858205. GI-TBC qualifies its own certificate at
L=.6453250303858202 in20.506462s; P/PS remain open with
L=.5891968575096277/.5903592226185386 and null Tcert. Both production
clocks are about1171s. This is a dual-proof-gap witness: equal final feasible
objectives do not transfer GI-TBC's proof or certificate time to either control.
R-X20-S-T2 positions46–48 is also complete. GI-TBC qualifies a certificate
at U=.43479563082126105,L=.43479562838276453 in337.304909s. P remains
open at U=.47673073748164757,L=.29110146755603816; PS remains open at
U=.5197195673449482,L=.28446966592056366. P improves both endpoints
relative to PS here. Complete-H hashes match within each PS/GI-TBC pair.
R-X20-S's larger T reduces the certified value while its observed GI-TBC
proof cost rises20.506462→337.304909s; R-B20-S had the opposite cost
direction784.143484→538.602932s. This is not a universal runtime law or an
isolated-component attribution.

All four n20 resource configurations (two bases,two T each;12positions) are
complete: GI-TBC4/4 certificates,P0/4,PS0/4, with all open Tcert null.
Independent interim review PASS is in review/B2_n20_narrative_review.md;
it also checks the design formula/floors, data identity, operation-table keys
and prose scope. Whole-B2/final120/PDF/recovery acceptance remains pending.
First n35 resource configuration R-B35-S-T1 positions49–51 is complete,
qualified and all open. GI-TBC U=.59151763477047,L=.45590389125187164;
P U=.6063114970947849,L=.33700238039283015;
PS U=.6317654945240879,L=.3345185347703226. GI-TBC improves both endpoints
over both compact controls, and P improves both over PS. No certificate-time
ranking exists. Tproduce is2376.072214s/2372.197055s/2371.038670s for
GI-TBC/P/PS; all are within the same2400s complete cap. Own-H PS/GI-TBC
semantic/fleet hashes match. The n35 proof gap remains a recorded limitation.
R-B35-S-T2 positions52–54 is complete, qualified and all open. GI-TBC:
U=.34464262559194814,L=.2189859496034747; P:
U=.4716371073327238,L=.15437564743813872; PS:
U=.43829121782230296,L=.15541565894279447. All Tcert remain null,
production clocks about2371s, own-H PS/GI-TBC hashes match. GI-TBC improves
both endpoints over both controls; PS improves both over P atT2, while P had
improved both over PS atT1. Do not claim a universal startup benefit.

The complete six-position R-B35-S base has no within-run certificate. Its
GI-TBC intervals [ .45590389125187164,.59151763477047 ] atT4800 and
[ .2189859496034747,.34464262559194814 ] atT7200 are separated:
L(T1)-U(T2)=.1112612656599235>1e-7. Matched other-data identity and both
open statuses were checked and saved in execution_state.json's
n35_strict_resource_value_witness. This supports strict value improvement
under the numerical policy without assigning either optimum an exact value
or creating a certificate-time ratio. The guarded manuscript source now
explains this witness; full assembly/PDF remain pending.

Final B2 base R-X35-S-T1 positions55–57 is complete, qualified and all open.
GI-TBC U=.5921904488701923,L=.46335799724827287;
P U=.6557126139481573,L=.2960087587984223;
PS U=.5932312305603193,L=.29883905992110465. GI-TBC improves both
endpoints over both controls, with its small primal advantage over PS and
larger dual improvement stated separately. All Tcert remain null. Tproduce
is2379.118504s/2371.094762s/2371.007752s for GI-TBC/P/PS, within the same
2400s complete cap; own-H PS/GI-TBC semantic/fleet hashes match.
The queue has entered position58 R-X35-S-T2 PS, last B2 configuration.
Its paired results are not yet available. Settled G1 is56973.675489s
(15.8260h), with159026.324511s remaining and a live2400s reservation.
Inspect durable live
state instead of treating this snapshot as the latest queue position.
No native arm has been repeated. Current-method names in the maintained
appendix now consistently say GI-TBC/GI-TBC-R while retaining historical
S2/S2R and implementation ms2/s2-root aliases. No mathematical or solver
configuration change accompanies these editorial corrections.
The maintained introduction now describes the current breadth/resource/weight,
AM/mechanism and limited-Seed questions explicitly. Complete-result claims,
full tables/plots, PDF and final discussion still require the complete matrix.
The assembled-paper source now includes data-bound B1 benefit/adverse/open
paragraphs and conditioned both-certified time statistics from the existing
pair summary. Assembly still requires all120 and native idle; only source/AST
work has run. Independent B1 narrative review PASS is in
review/B1_narrative_review.md: all36eligible; every open Tcert null; all12
own-H pairs complete/matching. Both-certified intersection n7 for each
comparator: material GI-TBC W/L6/0 versusP and4/1 versusPS; geometric
comparator/GI-TBC time ratios11.353394/4.225216, conditioned on those seven
certificate pairs only. Current prose, adverse cases and R132/R134 attribution
were independently checked. This is not final manuscript or whole-goal
acceptance; the final all120/math/PDF/recovery/delivery review remains required.
The document source now also gives the exact input-based dual-T design rule,
the four-base T/shortage/Omega/positive-floor table, the two preselected weight
configurations and explicit independence across physical T arms. It distinguishes
the pre-solve floor from reported solver L and avoids monotonic finite-endpoint
or guaranteed-binding claims. Syntax/escaped math were checked without assembling
or exporting the guarded full manuscript.
The current resource-results authoring source binds R-B20-S's two actual
certificates and clocks, and adds verified-incumbent G/P_avg/S, returned load
and route-duration utilization for all eight GI-TBC resource configurations.
It identifies operation details in reports/operations.json, distinguishes
near-unit displayed-route utilization from proven binding optimality, and
labels ineligible evidence UEV. These tables still await complete analysis,
full assembly and visual QA; no PDF/export has run.
The R-X20-S-T1 equal-U/dual-gap witness and the opposite n20 resource
proof-cost directions are now included in the guarded document-authoring
source, with actual-row assertions. They remain Seed0 observations and do not
claim source/size causality or a mathematical runtime ordering.

Offline accounting note for after native completion: analyze/plots/document/
release/local-replay functions deliberately require budget().unclosed to be
empty. Do not wrap these commands in round137_common.metered, because its own
engineering fee would appear as an unclosed process and trip the idle guard.
Measure finite offline commands with their existing receipts or a separate
stopwatch/process sidecar outside fees/, without loading native assets or
adding them to G1; keep native/diagnostic metering unchanged. Actual local pure
replay duration still determines any directed public-driver timeout adjustment.

Target-domain wording was clarified without changing any solver/data/matrix:
mathematics uses D_i>0; computational storage is integer, and all16 current
base inputs additionally satisfy D_i<=C_i as a data convention. The inherited
blanket target-capacity premise is not presented as an extra physical constraint.
review/target_domain_wording_check.json binds the16 input hashes and three
unchanged source hashes; review/target_domain_wording_review.md independently
accepts the wording and inspected proof scope. Parser namedIntVector rounds
literals via llround, so do not claim arbitrary fractional-target support or
blanket fractional-literal rejection. Existing integer computational semantics,
physical b/Y capacity bounds and all native evidence remain unchanged.
