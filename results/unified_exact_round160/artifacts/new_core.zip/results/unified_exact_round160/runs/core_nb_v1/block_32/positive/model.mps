* Signature: 0x91b297a088ee5d1f
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 G  product_lb_32
 L  product_ub_33
 G  product_lb_34
 L  product_ub_35
 G  product_lb_36
 L  product_ub_37
 G  product_lb_38
 L  product_ub_39
 E  onehot_28_40
 E  normalized_mass_28_41
 E  normalized_ratio_28_42
 G  product_lb_43
 L  product_ub_44
 G  product_lb_45
 L  product_ub_46
 G  product_lb_47
 L  product_ub_48
 G  product_lb_49
 L  product_ub_50
 G  product_lb_51
 L  product_ub_52
 G  product_lb_53
 L  product_ub_54
 G  product_lb_55
 L  product_ub_56
 G  product_lb_57
 L  product_ub_58
 G  product_lb_59
 L  product_ub_60
 G  product_lb_61
 L  product_ub_62
 G  product_lb_63
 L  product_ub_64
 G  product_lb_65
 L  product_ub_66
 E  onehot_23_67
 E  normalized_mass_23_68
 E  normalized_ratio_23_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 G  product_lb_74
 L  product_ub_75
 G  product_lb_76
 L  product_ub_77
 G  product_lb_78
 L  product_ub_79
 G  product_lb_80
 L  product_ub_81
 G  product_lb_82
 L  product_ub_83
 G  product_lb_84
 L  product_ub_85
 G  product_lb_86
 L  product_ub_87
 G  product_lb_88
 L  product_ub_89
 G  product_lb_90
 L  product_ub_91
 G  product_lb_92
 L  product_ub_93
 G  product_lb_94
 L  product_ub_95
 E  onehot_31_96
 E  normalized_mass_31_97
 E  normalized_ratio_31_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 G  product_lb_111
 L  product_ub_112
 G  product_lb_113
 L  product_ub_114
 G  product_lb_115
 L  product_ub_116
 G  product_lb_117
 L  product_ub_118
 G  product_lb_119
 L  product_ub_120
 G  product_lb_121
 L  product_ub_122
 G  product_lb_123
 L  product_ub_124
 G  product_lb_125
 L  product_ub_126
 G  product_lb_127
 L  product_ub_128
 G  product_lb_129
 L  product_ub_130
 E  onehot_21_131
 E  normalized_mass_21_132
 E  normalized_ratio_21_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 G  product_lb_148
 L  product_ub_149
 G  product_lb_150
 L  product_ub_151
 G  product_lb_152
 L  product_ub_153
 G  product_lb_154
 L  product_ub_155
 G  product_lb_156
 L  product_ub_157
 G  product_lb_158
 L  product_ub_159
 E  onehot_16_160
 E  normalized_mass_16_161
 E  normalized_ratio_16_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 G  product_lb_183
 L  product_ub_184
 G  product_lb_185
 L  product_ub_186
 G  product_lb_187
 L  product_ub_188
 E  onehot_20_189
 E  normalized_mass_20_190
 E  normalized_ratio_20_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 E  onehot_32_218
 E  normalized_mass_32_219
 E  normalized_ratio_32_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 G  product_lb_227
 L  product_ub_228
 G  product_lb_229
 L  product_ub_230
 G  product_lb_231
 L  product_ub_232
 G  product_lb_233
 L  product_ub_234
 G  product_lb_235
 L  product_ub_236
 G  product_lb_237
 L  product_ub_238
 G  product_lb_239
 L  product_ub_240
 G  product_lb_241
 L  product_ub_242
 G  product_lb_243
 L  product_ub_244
 G  product_lb_245
 L  product_ub_246
 G  product_lb_247
 L  product_ub_248
 G  product_lb_249
 L  product_ub_250
 G  product_lb_251
 L  product_ub_252
 G  product_lb_253
 L  product_ub_254
 E  onehot_33_255
 E  normalized_mass_33_256
 E  normalized_ratio_33_257
 G  stock_lb_258
 L  stock_ub_259
 L  parent_nonstrict_scope_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 G  block_pair_pos_289
 G  block_pair_neg_290
 G  block_pair_pos_291
 G  block_pair_neg_292
 G  block_pair_pos_293
 G  block_pair_neg_294
 G  block_pair_pos_295
 G  block_pair_neg_296
 G  block_pair_pos_297
 G  block_pair_neg_298
 G  block_pair_pos_299
 G  block_pair_neg_300
 G  block_pair_pos_301
 G  block_pair_neg_302
 G  block_pair_pos_303
 G  block_pair_neg_304
 G  block_pair_pos_305
 G  block_pair_neg_306
 G  block_pair_pos_307
 G  block_pair_neg_308
 G  block_pair_pos_309
 G  block_pair_neg_310
 G  block_pair_pos_311
 G  block_pair_neg_312
 G  block_pair_pos_313
 G  block_pair_neg_314
 G  block_pair_pos_315
 G  block_pair_neg_316
 E  normalization_317
 G  full_original_Gini_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 E  unique_nonzero_owner_386
 E  unique_nonzero_owner_387
 E  unique_nonzero_owner_388
 E  unique_nonzero_owner_389
 E  unique_nonzero_owner_390
 E  unique_nonzero_owner_391
 E  unique_nonzero_owner_392
 E  unique_nonzero_owner_393
 E  unique_nonzero_owner_394
 E  unique_nonzero_owner_395
 E  unique_nonzero_owner_396
 E  unique_nonzero_owner_397
 E  unique_nonzero_owner_398
 E  unique_nonzero_owner_399
 E  unique_nonzero_owner_400
 E  unique_nonzero_owner_401
 E  unique_nonzero_owner_402
 E  unique_nonzero_owner_403
 E  unique_nonzero_owner_404
 E  unique_nonzero_owner_405
 E  unique_nonzero_owner_406
 E  unique_nonzero_owner_407
 E  unique_nonzero_owner_408
 E  unique_nonzero_owner_409
 E  unique_nonzero_owner_410
 E  unique_nonzero_owner_411
 E  unique_nonzero_owner_412
 E  unique_nonzero_owner_413
 E  unique_nonzero_owner_414
 E  unique_nonzero_owner_415
 E  unique_nonzero_owner_416
 E  unique_nonzero_owner_417
 E  unique_nonzero_owner_418
 E  unique_nonzero_owner_419
 E  unique_nonzero_owner_420
 E  unique_nonzero_owner_421
 E  unique_nonzero_owner_422
 E  unique_nonzero_owner_423
 E  unique_nonzero_owner_424
 E  unique_nonzero_owner_425
 E  unique_nonzero_owner_426
 E  unique_nonzero_owner_427
 L  arc_capacity_428
 L  arc_capacity_429
 L  arc_capacity_430
 L  arc_capacity_431
 L  arc_capacity_432
 L  arc_capacity_433
 L  arc_capacity_434
 L  arc_capacity_435
 L  arc_capacity_436
 L  arc_capacity_437
 L  arc_capacity_438
 L  arc_capacity_439
 L  arc_capacity_440
 L  arc_capacity_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 G  connected_order_arc_451
 L  arc_capacity_452
 G  connected_order_arc_453
 L  arc_capacity_454
 G  connected_order_arc_455
 L  arc_capacity_456
 G  connected_order_arc_457
 L  arc_capacity_458
 G  connected_order_arc_459
 L  arc_capacity_460
 G  connected_order_arc_461
 L  arc_capacity_462
 G  connected_order_arc_463
 L  arc_capacity_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 G  connected_order_arc_476
 L  arc_capacity_477
 G  connected_order_arc_478
 L  arc_capacity_479
 G  connected_order_arc_480
 L  arc_capacity_481
 G  connected_order_arc_482
 L  arc_capacity_483
 G  connected_order_arc_484
 L  arc_capacity_485
 G  connected_order_arc_486
 L  arc_capacity_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 G  connected_order_arc_501
 L  arc_capacity_502
 G  connected_order_arc_503
 L  arc_capacity_504
 G  connected_order_arc_505
 L  arc_capacity_506
 G  connected_order_arc_507
 L  arc_capacity_508
 G  connected_order_arc_509
 L  arc_capacity_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 G  connected_order_arc_526
 L  arc_capacity_527
 G  connected_order_arc_528
 L  arc_capacity_529
 G  connected_order_arc_530
 L  arc_capacity_531
 G  connected_order_arc_532
 L  arc_capacity_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 G  connected_order_arc_551
 L  arc_capacity_552
 G  connected_order_arc_553
 L  arc_capacity_554
 G  connected_order_arc_555
 L  arc_capacity_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 G  connected_order_arc_576
 L  arc_capacity_577
 G  connected_order_arc_578
 L  arc_capacity_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 G  connected_order_arc_601
 L  arc_capacity_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 L  arc_capacity_649
 G  connected_order_arc_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 L  arc_capacity_672
 G  connected_order_arc_673
 L  arc_capacity_674
 G  connected_order_arc_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 L  arc_capacity_695
 G  connected_order_arc_696
 L  arc_capacity_697
 G  connected_order_arc_698
 L  arc_capacity_699
 G  connected_order_arc_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 E  depot_departure_or_bypass_717
 E  depot_return_or_bypass_718
 E  out_degree_719
 E  in_degree_720
 G  order_active_lb_721
 L  order_active_ub_722
 E  segment_load_conservation_723
 G  segment_prefix_lb_724
 L  segment_prefix_ub_725
 E  out_degree_726
 E  in_degree_727
 G  order_active_lb_728
 L  order_active_ub_729
 E  segment_load_conservation_730
 G  segment_prefix_lb_731
 L  segment_prefix_ub_732
 E  out_degree_733
 E  in_degree_734
 G  order_active_lb_735
 L  order_active_ub_736
 E  segment_load_conservation_737
 G  segment_prefix_lb_738
 L  segment_prefix_ub_739
 E  out_degree_740
 E  in_degree_741
 G  order_active_lb_742
 L  order_active_ub_743
 E  segment_load_conservation_744
 G  segment_prefix_lb_745
 L  segment_prefix_ub_746
 E  out_degree_747
 E  in_degree_748
 G  order_active_lb_749
 L  order_active_ub_750
 E  service_visit_def_751
 E  free_load_conservation_752
 E  out_degree_753
 E  in_degree_754
 G  order_active_lb_755
 L  order_active_ub_756
 E  service_visit_def_757
 E  free_load_conservation_758
 E  out_degree_759
 E  in_degree_760
 G  order_active_lb_761
 L  order_active_ub_762
 E  service_visit_def_763
 E  free_load_conservation_764
 E  out_degree_765
 E  in_degree_766
 G  order_active_lb_767
 L  order_active_ub_768
 E  service_visit_def_769
 E  free_load_conservation_770
 E  out_degree_771
 E  in_degree_772
 G  order_active_lb_773
 L  order_active_ub_774
 E  service_visit_def_775
 E  free_load_conservation_776
 E  out_degree_777
 E  in_degree_778
 G  order_active_lb_779
 L  order_active_ub_780
 E  service_visit_def_781
 E  free_load_conservation_782
 E  out_degree_783
 E  in_degree_784
 G  order_active_lb_785
 L  order_active_ub_786
 E  service_visit_def_787
 E  free_load_conservation_788
 E  out_degree_789
 E  in_degree_790
 G  order_active_lb_791
 L  order_active_ub_792
 E  service_visit_def_793
 E  free_load_conservation_794
 G  fixed_segment_relative_order_795
 G  fixed_segment_relative_order_796
 G  fixed_segment_relative_order_797
 L  original_T_including_depot_unload_798
 L  arc_capacity_799
 L  arc_capacity_800
 L  arc_capacity_801
 L  arc_capacity_802
 L  arc_capacity_803
 L  arc_capacity_804
 L  arc_capacity_805
 L  arc_capacity_806
 L  arc_capacity_807
 L  arc_capacity_808
 L  arc_capacity_809
 L  arc_capacity_810
 L  arc_capacity_811
 L  arc_capacity_812
 L  arc_capacity_813
 L  arc_capacity_814
 G  connected_order_arc_815
 L  arc_capacity_816
 G  connected_order_arc_817
 L  arc_capacity_818
 G  connected_order_arc_819
 L  arc_capacity_820
 G  connected_order_arc_821
 L  arc_capacity_822
 G  connected_order_arc_823
 L  arc_capacity_824
 G  connected_order_arc_825
 L  arc_capacity_826
 G  connected_order_arc_827
 L  arc_capacity_828
 G  connected_order_arc_829
 L  arc_capacity_830
 G  connected_order_arc_831
 L  arc_capacity_832
 G  connected_order_arc_833
 L  arc_capacity_834
 G  connected_order_arc_835
 L  arc_capacity_836
 G  connected_order_arc_837
 L  arc_capacity_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 G  connected_order_arc_846
 L  arc_capacity_847
 G  connected_order_arc_848
 L  arc_capacity_849
 G  connected_order_arc_850
 L  arc_capacity_851
 G  connected_order_arc_852
 L  arc_capacity_853
 G  connected_order_arc_854
 L  arc_capacity_855
 G  connected_order_arc_856
 L  arc_capacity_857
 G  connected_order_arc_858
 L  arc_capacity_859
 G  connected_order_arc_860
 L  arc_capacity_861
 G  connected_order_arc_862
 L  arc_capacity_863
 L  arc_capacity_864
 G  connected_order_arc_865
 L  arc_capacity_866
 G  connected_order_arc_867
 L  arc_capacity_868
 G  connected_order_arc_869
 L  arc_capacity_870
 G  connected_order_arc_871
 L  arc_capacity_872
 G  connected_order_arc_873
 L  arc_capacity_874
 G  connected_order_arc_875
 L  arc_capacity_876
 G  connected_order_arc_877
 L  arc_capacity_878
 G  connected_order_arc_879
 L  arc_capacity_880
 G  connected_order_arc_881
 L  arc_capacity_882
 G  connected_order_arc_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 L  arc_capacity_889
 G  connected_order_arc_890
 L  arc_capacity_891
 G  connected_order_arc_892
 L  arc_capacity_893
 G  connected_order_arc_894
 L  arc_capacity_895
 G  connected_order_arc_896
 L  arc_capacity_897
 G  connected_order_arc_898
 L  arc_capacity_899
 G  connected_order_arc_900
 L  arc_capacity_901
 G  connected_order_arc_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 L  arc_capacity_914
 G  connected_order_arc_915
 L  arc_capacity_916
 G  connected_order_arc_917
 L  arc_capacity_918
 G  connected_order_arc_919
 L  arc_capacity_920
 G  connected_order_arc_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 L  arc_capacity_939
 G  connected_order_arc_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 G  connected_order_arc_960
 L  arc_capacity_961
 G  connected_order_arc_962
 L  arc_capacity_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 G  connected_order_arc_979
 L  arc_capacity_980
 G  connected_order_arc_981
 L  arc_capacity_982
 G  connected_order_arc_983
 L  arc_capacity_984
 G  connected_order_arc_985
 L  arc_capacity_986
 G  connected_order_arc_987
 L  arc_capacity_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 G  connected_order_arc_998
 L  arc_capacity_999
 G  connected_order_arc_1000
 L  arc_capacity_1001
 G  connected_order_arc_1002
 L  arc_capacity_1003
 G  connected_order_arc_1004
 L  arc_capacity_1005
 G  connected_order_arc_1006
 L  arc_capacity_1007
 G  connected_order_arc_1008
 L  arc_capacity_1009
 G  connected_order_arc_1010
 L  arc_capacity_1011
 G  connected_order_arc_1012
 L  arc_capacity_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 L  arc_capacity_1016
 G  connected_order_arc_1017
 L  arc_capacity_1018
 G  connected_order_arc_1019
 L  arc_capacity_1020
 G  connected_order_arc_1021
 L  arc_capacity_1022
 G  connected_order_arc_1023
 L  arc_capacity_1024
 G  connected_order_arc_1025
 L  arc_capacity_1026
 G  connected_order_arc_1027
 L  arc_capacity_1028
 G  connected_order_arc_1029
 L  arc_capacity_1030
 G  connected_order_arc_1031
 L  arc_capacity_1032
 G  connected_order_arc_1033
 L  arc_capacity_1034
 G  connected_order_arc_1035
 L  arc_capacity_1036
 G  connected_order_arc_1037
 L  arc_capacity_1038
 L  arc_capacity_1039
 G  connected_order_arc_1040
 L  arc_capacity_1041
 G  connected_order_arc_1042
 L  arc_capacity_1043
 G  connected_order_arc_1044
 L  arc_capacity_1045
 G  connected_order_arc_1046
 L  arc_capacity_1047
 G  connected_order_arc_1048
 L  arc_capacity_1049
 G  connected_order_arc_1050
 L  arc_capacity_1051
 G  connected_order_arc_1052
 L  arc_capacity_1053
 G  connected_order_arc_1054
 L  arc_capacity_1055
 G  connected_order_arc_1056
 L  arc_capacity_1057
 G  connected_order_arc_1058
 L  arc_capacity_1059
 G  connected_order_arc_1060
 L  arc_capacity_1061
 G  connected_order_arc_1062
 L  arc_capacity_1063
 L  arc_capacity_1064
 G  connected_order_arc_1065
 L  arc_capacity_1066
 G  connected_order_arc_1067
 L  arc_capacity_1068
 G  connected_order_arc_1069
 L  arc_capacity_1070
 G  connected_order_arc_1071
 L  arc_capacity_1072
 G  connected_order_arc_1073
 L  arc_capacity_1074
 G  connected_order_arc_1075
 L  arc_capacity_1076
 G  connected_order_arc_1077
 L  arc_capacity_1078
 G  connected_order_arc_1079
 L  arc_capacity_1080
 G  connected_order_arc_1081
 L  arc_capacity_1082
 G  connected_order_arc_1083
 L  arc_capacity_1084
 G  connected_order_arc_1085
 L  arc_capacity_1086
 G  connected_order_arc_1087
 L  arc_capacity_1088
 L  arc_capacity_1089
 G  connected_order_arc_1090
 L  arc_capacity_1091
 G  connected_order_arc_1092
 L  arc_capacity_1093
 G  connected_order_arc_1094
 L  arc_capacity_1095
 G  connected_order_arc_1096
 L  arc_capacity_1097
 G  connected_order_arc_1098
 L  arc_capacity_1099
 G  connected_order_arc_1100
 L  arc_capacity_1101
 G  connected_order_arc_1102
 L  arc_capacity_1103
 G  connected_order_arc_1104
 L  arc_capacity_1105
 G  connected_order_arc_1106
 L  arc_capacity_1107
 G  connected_order_arc_1108
 L  arc_capacity_1109
 G  connected_order_arc_1110
 L  arc_capacity_1111
 G  connected_order_arc_1112
 L  arc_capacity_1113
 L  arc_capacity_1114
 G  connected_order_arc_1115
 L  arc_capacity_1116
 G  connected_order_arc_1117
 L  arc_capacity_1118
 G  connected_order_arc_1119
 L  arc_capacity_1120
 G  connected_order_arc_1121
 L  arc_capacity_1122
 G  connected_order_arc_1123
 L  arc_capacity_1124
 G  connected_order_arc_1125
 L  arc_capacity_1126
 G  connected_order_arc_1127
 L  arc_capacity_1128
 G  connected_order_arc_1129
 L  arc_capacity_1130
 G  connected_order_arc_1131
 L  arc_capacity_1132
 G  connected_order_arc_1133
 L  arc_capacity_1134
 G  connected_order_arc_1135
 L  arc_capacity_1136
 G  connected_order_arc_1137
 E  depot_departure_or_bypass_1138
 E  depot_return_or_bypass_1139
 E  out_degree_1140
 E  in_degree_1141
 G  order_active_lb_1142
 L  order_active_ub_1143
 E  segment_load_conservation_1144
 G  segment_prefix_lb_1145
 L  segment_prefix_ub_1146
 E  out_degree_1147
 E  in_degree_1148
 G  order_active_lb_1149
 L  order_active_ub_1150
 E  segment_load_conservation_1151
 G  segment_prefix_lb_1152
 L  segment_prefix_ub_1153
 E  out_degree_1154
 E  in_degree_1155
 G  order_active_lb_1156
 L  order_active_ub_1157
 E  segment_load_conservation_1158
 G  segment_prefix_lb_1159
 L  segment_prefix_ub_1160
 E  out_degree_1161
 E  in_degree_1162
 G  order_active_lb_1163
 L  order_active_ub_1164
 E  segment_load_conservation_1165
 G  segment_prefix_lb_1166
 L  segment_prefix_ub_1167
 E  out_degree_1168
 E  in_degree_1169
 G  order_active_lb_1170
 L  order_active_ub_1171
 E  segment_load_conservation_1172
 G  segment_prefix_lb_1173
 L  segment_prefix_ub_1174
 E  out_degree_1175
 E  in_degree_1176
 G  order_active_lb_1177
 L  order_active_ub_1178
 E  service_visit_def_1179
 E  free_load_conservation_1180
 E  out_degree_1181
 E  in_degree_1182
 G  order_active_lb_1183
 L  order_active_ub_1184
 E  service_visit_def_1185
 E  free_load_conservation_1186
 E  out_degree_1187
 E  in_degree_1188
 G  order_active_lb_1189
 L  order_active_ub_1190
 E  service_visit_def_1191
 E  free_load_conservation_1192
 E  out_degree_1193
 E  in_degree_1194
 G  order_active_lb_1195
 L  order_active_ub_1196
 E  service_visit_def_1197
 E  free_load_conservation_1198
 E  out_degree_1199
 E  in_degree_1200
 G  order_active_lb_1201
 L  order_active_ub_1202
 E  service_visit_def_1203
 E  free_load_conservation_1204
 E  out_degree_1205
 E  in_degree_1206
 G  order_active_lb_1207
 L  order_active_ub_1208
 E  service_visit_def_1209
 E  free_load_conservation_1210
 E  out_degree_1211
 E  in_degree_1212
 G  order_active_lb_1213
 L  order_active_ub_1214
 E  service_visit_def_1215
 E  free_load_conservation_1216
 E  out_degree_1217
 E  in_degree_1218
 G  order_active_lb_1219
 L  order_active_ub_1220
 E  service_visit_def_1221
 E  free_load_conservation_1222
 G  fixed_segment_relative_order_1223
 G  fixed_segment_relative_order_1224
 G  fixed_segment_relative_order_1225
 G  fixed_segment_relative_order_1226
 L  original_T_including_depot_unload_1227
 L  arc_capacity_1228
 L  arc_capacity_1229
 L  arc_capacity_1230
 L  arc_capacity_1231
 L  arc_capacity_1232
 L  arc_capacity_1233
 L  arc_capacity_1234
 L  arc_capacity_1235
 L  arc_capacity_1236
 L  arc_capacity_1237
 L  arc_capacity_1238
 L  arc_capacity_1239
 L  arc_capacity_1240
 L  arc_capacity_1241
 L  arc_capacity_1242
 G  connected_order_arc_1243
 L  arc_capacity_1244
 G  connected_order_arc_1245
 L  arc_capacity_1246
 G  connected_order_arc_1247
 L  arc_capacity_1248
 G  connected_order_arc_1249
 L  arc_capacity_1250
 G  connected_order_arc_1251
 L  arc_capacity_1252
 G  connected_order_arc_1253
 L  arc_capacity_1254
 G  connected_order_arc_1255
 L  arc_capacity_1256
 G  connected_order_arc_1257
 L  arc_capacity_1258
 G  connected_order_arc_1259
 L  arc_capacity_1260
 G  connected_order_arc_1261
 L  arc_capacity_1262
 G  connected_order_arc_1263
 L  arc_capacity_1264
 L  arc_capacity_1265
 G  connected_order_arc_1266
 L  arc_capacity_1267
 G  connected_order_arc_1268
 L  arc_capacity_1269
 G  connected_order_arc_1270
 L  arc_capacity_1271
 G  connected_order_arc_1272
 L  arc_capacity_1273
 G  connected_order_arc_1274
 L  arc_capacity_1275
 G  connected_order_arc_1276
 L  arc_capacity_1277
 G  connected_order_arc_1278
 L  arc_capacity_1279
 G  connected_order_arc_1280
 L  arc_capacity_1281
 G  connected_order_arc_1282
 L  arc_capacity_1283
 G  connected_order_arc_1284
 L  arc_capacity_1285
 G  connected_order_arc_1286
 L  arc_capacity_1287
 L  arc_capacity_1288
 G  connected_order_arc_1289
 L  arc_capacity_1290
 G  connected_order_arc_1291
 L  arc_capacity_1292
 G  connected_order_arc_1293
 L  arc_capacity_1294
 G  connected_order_arc_1295
 L  arc_capacity_1296
 G  connected_order_arc_1297
 L  arc_capacity_1298
 G  connected_order_arc_1299
 L  arc_capacity_1300
 G  connected_order_arc_1301
 L  arc_capacity_1302
 G  connected_order_arc_1303
 L  arc_capacity_1304
 G  connected_order_arc_1305
 L  arc_capacity_1306
 G  connected_order_arc_1307
 L  arc_capacity_1308
 G  connected_order_arc_1309
 L  arc_capacity_1310
 L  arc_capacity_1311
 G  connected_order_arc_1312
 L  arc_capacity_1313
 G  connected_order_arc_1314
 L  arc_capacity_1315
 G  connected_order_arc_1316
 L  arc_capacity_1317
 G  connected_order_arc_1318
 L  arc_capacity_1319
 G  connected_order_arc_1320
 L  arc_capacity_1321
 G  connected_order_arc_1322
 L  arc_capacity_1323
 G  connected_order_arc_1324
 L  arc_capacity_1325
 G  connected_order_arc_1326
 L  arc_capacity_1327
 G  connected_order_arc_1328
 L  arc_capacity_1329
 G  connected_order_arc_1330
 L  arc_capacity_1331
 G  connected_order_arc_1332
 L  arc_capacity_1333
 L  arc_capacity_1334
 G  connected_order_arc_1335
 L  arc_capacity_1336
 G  connected_order_arc_1337
 L  arc_capacity_1338
 G  connected_order_arc_1339
 L  arc_capacity_1340
 G  connected_order_arc_1341
 L  arc_capacity_1342
 G  connected_order_arc_1343
 L  arc_capacity_1344
 G  connected_order_arc_1345
 L  arc_capacity_1346
 G  connected_order_arc_1347
 L  arc_capacity_1348
 G  connected_order_arc_1349
 L  arc_capacity_1350
 G  connected_order_arc_1351
 L  arc_capacity_1352
 G  connected_order_arc_1353
 L  arc_capacity_1354
 G  connected_order_arc_1355
 L  arc_capacity_1356
 L  arc_capacity_1357
 G  connected_order_arc_1358
 L  arc_capacity_1359
 G  connected_order_arc_1360
 L  arc_capacity_1361
 G  connected_order_arc_1362
 L  arc_capacity_1363
 G  connected_order_arc_1364
 L  arc_capacity_1365
 G  connected_order_arc_1366
 L  arc_capacity_1367
 G  connected_order_arc_1368
 L  arc_capacity_1369
 G  connected_order_arc_1370
 L  arc_capacity_1371
 G  connected_order_arc_1372
 L  arc_capacity_1373
 G  connected_order_arc_1374
 L  arc_capacity_1375
 G  connected_order_arc_1376
 L  arc_capacity_1377
 G  connected_order_arc_1378
 L  arc_capacity_1379
 L  arc_capacity_1380
 G  connected_order_arc_1381
 L  arc_capacity_1382
 G  connected_order_arc_1383
 L  arc_capacity_1384
 G  connected_order_arc_1385
 L  arc_capacity_1386
 G  connected_order_arc_1387
 L  arc_capacity_1388
 G  connected_order_arc_1389
 L  arc_capacity_1390
 G  connected_order_arc_1391
 L  arc_capacity_1392
 G  connected_order_arc_1393
 L  arc_capacity_1394
 G  connected_order_arc_1395
 L  arc_capacity_1396
 G  connected_order_arc_1397
 L  arc_capacity_1398
 G  connected_order_arc_1399
 L  arc_capacity_1400
 G  connected_order_arc_1401
 L  arc_capacity_1402
 L  arc_capacity_1403
 G  connected_order_arc_1404
 L  arc_capacity_1405
 G  connected_order_arc_1406
 L  arc_capacity_1407
 G  connected_order_arc_1408
 L  arc_capacity_1409
 G  connected_order_arc_1410
 L  arc_capacity_1411
 G  connected_order_arc_1412
 L  arc_capacity_1413
 G  connected_order_arc_1414
 L  arc_capacity_1415
 G  connected_order_arc_1416
 L  arc_capacity_1417
 G  connected_order_arc_1418
 L  arc_capacity_1419
 G  connected_order_arc_1420
 L  arc_capacity_1421
 G  connected_order_arc_1422
 L  arc_capacity_1423
 G  connected_order_arc_1424
 L  arc_capacity_1425
 L  arc_capacity_1426
 G  connected_order_arc_1427
 L  arc_capacity_1428
 G  connected_order_arc_1429
 L  arc_capacity_1430
 G  connected_order_arc_1431
 L  arc_capacity_1432
 G  connected_order_arc_1433
 L  arc_capacity_1434
 G  connected_order_arc_1435
 L  arc_capacity_1436
 G  connected_order_arc_1437
 L  arc_capacity_1438
 G  connected_order_arc_1439
 L  arc_capacity_1440
 G  connected_order_arc_1441
 L  arc_capacity_1442
 G  connected_order_arc_1443
 L  arc_capacity_1444
 G  connected_order_arc_1445
 L  arc_capacity_1446
 G  connected_order_arc_1447
 L  arc_capacity_1448
 L  arc_capacity_1449
 G  connected_order_arc_1450
 L  arc_capacity_1451
 G  connected_order_arc_1452
 L  arc_capacity_1453
 G  connected_order_arc_1454
 L  arc_capacity_1455
 G  connected_order_arc_1456
 L  arc_capacity_1457
 G  connected_order_arc_1458
 L  arc_capacity_1459
 G  connected_order_arc_1460
 L  arc_capacity_1461
 G  connected_order_arc_1462
 L  arc_capacity_1463
 G  connected_order_arc_1464
 L  arc_capacity_1465
 G  connected_order_arc_1466
 L  arc_capacity_1467
 G  connected_order_arc_1468
 L  arc_capacity_1469
 G  connected_order_arc_1470
 L  arc_capacity_1471
 L  arc_capacity_1472
 G  connected_order_arc_1473
 L  arc_capacity_1474
 G  connected_order_arc_1475
 L  arc_capacity_1476
 G  connected_order_arc_1477
 L  arc_capacity_1478
 G  connected_order_arc_1479
 L  arc_capacity_1480
 G  connected_order_arc_1481
 L  arc_capacity_1482
 G  connected_order_arc_1483
 L  arc_capacity_1484
 G  connected_order_arc_1485
 L  arc_capacity_1486
 G  connected_order_arc_1487
 L  arc_capacity_1488
 G  connected_order_arc_1489
 L  arc_capacity_1490
 G  connected_order_arc_1491
 L  arc_capacity_1492
 G  connected_order_arc_1493
 L  arc_capacity_1494
 L  arc_capacity_1495
 G  connected_order_arc_1496
 L  arc_capacity_1497
 G  connected_order_arc_1498
 L  arc_capacity_1499
 G  connected_order_arc_1500
 L  arc_capacity_1501
 G  connected_order_arc_1502
 L  arc_capacity_1503
 G  connected_order_arc_1504
 L  arc_capacity_1505
 G  connected_order_arc_1506
 L  arc_capacity_1507
 G  connected_order_arc_1508
 L  arc_capacity_1509
 G  connected_order_arc_1510
 L  arc_capacity_1511
 G  connected_order_arc_1512
 L  arc_capacity_1513
 G  connected_order_arc_1514
 L  arc_capacity_1515
 G  connected_order_arc_1516
 E  depot_departure_or_bypass_1517
 E  depot_return_or_bypass_1518
 E  out_degree_1519
 E  in_degree_1520
 G  order_active_lb_1521
 L  order_active_ub_1522
 E  segment_load_conservation_1523
 G  segment_prefix_lb_1524
 L  segment_prefix_ub_1525
 E  out_degree_1526
 E  in_degree_1527
 G  order_active_lb_1528
 L  order_active_ub_1529
 E  segment_load_conservation_1530
 G  segment_prefix_lb_1531
 L  segment_prefix_ub_1532
 E  out_degree_1533
 E  in_degree_1534
 G  order_active_lb_1535
 L  order_active_ub_1536
 E  segment_load_conservation_1537
 G  segment_prefix_lb_1538
 L  segment_prefix_ub_1539
 E  out_degree_1540
 E  in_degree_1541
 G  order_active_lb_1542
 L  order_active_ub_1543
 E  segment_load_conservation_1544
 G  segment_prefix_lb_1545
 L  segment_prefix_ub_1546
 E  out_degree_1547
 E  in_degree_1548
 G  order_active_lb_1549
 L  order_active_ub_1550
 E  service_visit_def_1551
 E  free_load_conservation_1552
 E  out_degree_1553
 E  in_degree_1554
 G  order_active_lb_1555
 L  order_active_ub_1556
 E  service_visit_def_1557
 E  free_load_conservation_1558
 E  out_degree_1559
 E  in_degree_1560
 G  order_active_lb_1561
 L  order_active_ub_1562
 E  service_visit_def_1563
 E  free_load_conservation_1564
 E  out_degree_1565
 E  in_degree_1566
 G  order_active_lb_1567
 L  order_active_ub_1568
 E  service_visit_def_1569
 E  free_load_conservation_1570
 E  out_degree_1571
 E  in_degree_1572
 G  order_active_lb_1573
 L  order_active_ub_1574
 E  service_visit_def_1575
 E  free_load_conservation_1576
 E  out_degree_1577
 E  in_degree_1578
 G  order_active_lb_1579
 L  order_active_ub_1580
 E  service_visit_def_1581
 E  free_load_conservation_1582
 E  out_degree_1583
 E  in_degree_1584
 G  order_active_lb_1585
 L  order_active_ub_1586
 E  service_visit_def_1587
 E  free_load_conservation_1588
 E  out_degree_1589
 E  in_degree_1590
 G  order_active_lb_1591
 L  order_active_ub_1592
 E  service_visit_def_1593
 E  free_load_conservation_1594
 G  fixed_segment_relative_order_1595
 G  fixed_segment_relative_order_1596
 G  fixed_segment_relative_order_1597
 L  original_T_including_depot_unload_1598
COLUMNS
    t         normalized_mass_28_41  -1
    t         normalized_mass_23_68  -1
    t         normalized_mass_31_97  -1
    t         normalized_mass_21_132  -1
    t         normalized_mass_16_161  -1
    t         normalized_mass_20_190  -1
    t         normalized_mass_32_219  -1
    t         normalized_mass_33_256  -1
    t         normalization_317  2.3703968253968256e+01
    t         full_original_Gini_318  -6.8847619047619062e+01
    q         OBJ       1
    q         parent_nonstrict_scope_260  1
    q         full_original_Gini_318  35
    MARKER    'MARKER'                 'INTORG'
    x_28_0    OBJ       0.03
    x_28_0    product_lb_0  -2.4658499354157495e-02
    x_28_0    product_ub_1  -4.2187029162663148e-02
    x_28_0    onehot_28_40  1
    x_28_0    parent_nonstrict_scope_260  0.096
    x_28_0    unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_0    product_lb_0  1
    w_28_0    product_ub_1  1
    w_28_0    normalized_mass_28_41  1
    w_28_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_1    OBJ       1.8000000000000002e-02
    x_28_1    product_lb_2  -2.4658499354157495e-02
    x_28_1    product_ub_3  -4.2187029162663148e-02
    x_28_1    onehot_28_40  1
    x_28_1    stock_lb_258  1
    x_28_1    stock_ub_259  1
    x_28_1    parent_nonstrict_scope_260  0.084
    x_28_1    unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_1    product_lb_2  1
    w_28_1    product_ub_3  1
    w_28_1    normalized_mass_28_41  1
    w_28_1    normalized_ratio_28_42  -0.125
    w_28_1    full_original_Gini_318  -2.0328968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_2    OBJ       6.0000000000000053e-03
    x_28_2    product_lb_4  -2.4658499354157495e-02
    x_28_2    product_ub_5  -4.2187029162663148e-02
    x_28_2    onehot_28_40  1
    x_28_2    stock_lb_258  2
    x_28_2    stock_ub_259  2
    x_28_2    parent_nonstrict_scope_260  7.2000000000000008e-02
    x_28_2    unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_2    product_lb_4  1
    w_28_2    product_ub_5  1
    w_28_2    normalized_mass_28_41  1
    w_28_2    normalized_ratio_28_42  -0.25
    w_28_2    full_original_Gini_318  -1.6953968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_3    OBJ       -6.0000000000000053e-03
    x_28_3    product_lb_6  -2.4658499354157495e-02
    x_28_3    product_ub_7  -4.2187029162663148e-02
    x_28_3    onehot_28_40  1
    x_28_3    stock_lb_258  3
    x_28_3    stock_ub_259  3
    x_28_3    parent_nonstrict_scope_260  0.06
    x_28_3    unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_3    product_lb_6  1
    w_28_3    product_ub_7  1
    w_28_3    normalized_mass_28_41  1
    w_28_3    normalized_ratio_28_42  -0.375
    w_28_3    full_original_Gini_318  -1.3578968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_4    OBJ       -1.8000000000000002e-02
    x_28_4    product_lb_8  -2.4658499354157495e-02
    x_28_4    product_ub_9  -4.2187029162663148e-02
    x_28_4    onehot_28_40  1
    x_28_4    stock_lb_258  4
    x_28_4    stock_ub_259  4
    x_28_4    parent_nonstrict_scope_260  0.048
    x_28_4    unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_4    product_lb_8  1
    w_28_4    product_ub_9  1
    w_28_4    normalized_mass_28_41  1
    w_28_4    normalized_ratio_28_42  -0.5
    w_28_4    full_original_Gini_318  -1.0203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_5    OBJ       -0.03
    x_28_5    product_lb_10  -2.4658499354157495e-02
    x_28_5    product_ub_11  -4.2187029162663148e-02
    x_28_5    onehot_28_40  1
    x_28_5    stock_lb_258  5
    x_28_5    stock_ub_259  5
    x_28_5    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_28_5    unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_5    product_lb_10  1
    w_28_5    product_ub_11  1
    w_28_5    normalized_mass_28_41  1
    w_28_5    normalized_ratio_28_42  -0.625
    w_28_5    full_original_Gini_318  -7.4289682539682538e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_6    OBJ       -0.042
    x_28_6    product_lb_12  -2.4658499354157495e-02
    x_28_6    product_ub_13  -4.2187029162663148e-02
    x_28_6    onehot_28_40  1
    x_28_6    stock_lb_258  6
    x_28_6    stock_ub_259  6
    x_28_6    parent_nonstrict_scope_260  0.024
    x_28_6    unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_6    product_lb_12  1
    w_28_6    product_ub_13  1
    w_28_6    normalized_mass_28_41  1
    w_28_6    normalized_ratio_28_42  -0.75
    w_28_6    full_original_Gini_318  -5.1968253968253961e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_7    OBJ       -5.4000000000000006e-02
    x_28_7    product_lb_14  -2.4658499354157495e-02
    x_28_7    product_ub_15  -4.2187029162663148e-02
    x_28_7    onehot_28_40  1
    x_28_7    stock_lb_258  7
    x_28_7    stock_ub_259  7
    x_28_7    parent_nonstrict_scope_260  0.012
    x_28_7    unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_7    product_lb_14  1
    w_28_7    product_ub_15  1
    w_28_7    normalized_mass_28_41  1
    w_28_7    normalized_ratio_28_42  -0.875
    w_28_7    full_original_Gini_318  -3.9765873015873017e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_8    OBJ       -0.066
    x_28_8    product_lb_16  -2.4658499354157495e-02
    x_28_8    product_ub_17  -4.2187029162663148e-02
    x_28_8    onehot_28_40  1
    x_28_8    stock_lb_258  8
    x_28_8    stock_ub_259  8
    x_28_8    unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_8    product_lb_16  1
    w_28_8    product_ub_17  1
    w_28_8    normalized_mass_28_41  1
    w_28_8    normalized_ratio_28_42  -1
    w_28_8    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_9    OBJ       -5.4000000000000006e-02
    x_28_9    product_lb_18  -2.4658499354157495e-02
    x_28_9    product_ub_19  -4.2187029162663148e-02
    x_28_9    onehot_28_40  1
    x_28_9    stock_lb_258  9
    x_28_9    stock_ub_259  9
    x_28_9    parent_nonstrict_scope_260  0.012
    x_28_9    unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_9    product_lb_18  1
    w_28_9    product_ub_19  1
    w_28_9    normalized_mass_28_41  1
    w_28_9    normalized_ratio_28_42  -1.125
    w_28_9    full_original_Gini_318  -6.9210317460317459e+00
    MARKER    'MARKER'                 'INTORG'
    x_28_10   OBJ       -0.042
    x_28_10   product_lb_20  -2.4658499354157495e-02
    x_28_10   product_ub_21  -4.2187029162663148e-02
    x_28_10   onehot_28_40  1
    x_28_10   stock_lb_258  10
    x_28_10   stock_ub_259  10
    x_28_10   parent_nonstrict_scope_260  0.024
    x_28_10   unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_10   product_lb_20  1
    w_28_10   product_ub_21  1
    w_28_10   normalized_mass_28_41  1
    w_28_10   normalized_ratio_28_42  -1.25
    w_28_10   full_original_Gini_318  -1.0046031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_11   OBJ       -0.03
    x_28_11   product_lb_22  -2.4658499354157495e-02
    x_28_11   product_ub_23  -4.2187029162663148e-02
    x_28_11   onehot_28_40  1
    x_28_11   stock_lb_258  11
    x_28_11   stock_ub_259  11
    x_28_11   parent_nonstrict_scope_260  3.6000000000000004e-02
    x_28_11   unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_11   product_lb_22  1
    w_28_11   product_ub_23  1
    w_28_11   normalized_mass_28_41  1
    w_28_11   normalized_ratio_28_42  -1.375
    w_28_11   full_original_Gini_318  -1.3421031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_12   OBJ       -1.8000000000000002e-02
    x_28_12   product_lb_24  -2.4658499354157495e-02
    x_28_12   product_ub_25  -4.2187029162663148e-02
    x_28_12   onehot_28_40  1
    x_28_12   stock_lb_258  12
    x_28_12   stock_ub_259  12
    x_28_12   parent_nonstrict_scope_260  0.048
    x_28_12   unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_12   product_lb_24  1
    w_28_12   product_ub_25  1
    w_28_12   normalized_mass_28_41  1
    w_28_12   normalized_ratio_28_42  -1.5
    w_28_12   full_original_Gini_318  -1.6796031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_13   OBJ       -6.0000000000000053e-03
    x_28_13   product_lb_26  -2.4658499354157495e-02
    x_28_13   product_ub_27  -4.2187029162663148e-02
    x_28_13   onehot_28_40  1
    x_28_13   stock_lb_258  13
    x_28_13   stock_ub_259  13
    x_28_13   parent_nonstrict_scope_260  0.06
    MARKER    'MARKER'                 'INTEND'
    w_28_13   product_lb_26  1
    w_28_13   product_ub_27  1
    w_28_13   normalized_mass_28_41  1
    w_28_13   normalized_ratio_28_42  -1.625
    w_28_13   full_original_Gini_318  -2.0171031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_14   OBJ       6.0000000000000053e-03
    x_28_14   product_lb_28  -2.4658499354157495e-02
    x_28_14   product_ub_29  -4.2187029162663148e-02
    x_28_14   onehot_28_40  1
    x_28_14   stock_lb_258  14
    x_28_14   stock_ub_259  14
    x_28_14   parent_nonstrict_scope_260  7.2000000000000008e-02
    x_28_14   unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_14   product_lb_28  1
    w_28_14   product_ub_29  1
    w_28_14   normalized_mass_28_41  1
    w_28_14   normalized_ratio_28_42  -1.75
    w_28_14   full_original_Gini_318  -2.3546031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_15   OBJ       1.8000000000000002e-02
    x_28_15   product_lb_30  -2.4658499354157495e-02
    x_28_15   product_ub_31  -4.2187029162663148e-02
    x_28_15   onehot_28_40  1
    x_28_15   stock_lb_258  15
    x_28_15   stock_ub_259  15
    x_28_15   parent_nonstrict_scope_260  0.084
    x_28_15   unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_15   product_lb_30  1
    w_28_15   product_ub_31  1
    w_28_15   normalized_mass_28_41  1
    w_28_15   normalized_ratio_28_42  -1.875
    w_28_15   full_original_Gini_318  -2.6921031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_16   OBJ       0.03
    x_28_16   product_lb_32  -2.4658499354157495e-02
    x_28_16   product_ub_33  -4.2187029162663148e-02
    x_28_16   onehot_28_40  1
    x_28_16   stock_lb_258  16
    x_28_16   stock_ub_259  16
    x_28_16   parent_nonstrict_scope_260  0.096
    x_28_16   unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_16   product_lb_32  1
    w_28_16   product_ub_33  1
    w_28_16   normalized_mass_28_41  1
    w_28_16   normalized_ratio_28_42  -2
    w_28_16   full_original_Gini_318  -3.0296031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_17   OBJ       4.1999999999999996e-02
    x_28_17   product_lb_34  -2.4658499354157495e-02
    x_28_17   product_ub_35  -4.2187029162663148e-02
    x_28_17   onehot_28_40  1
    x_28_17   stock_lb_258  17
    x_28_17   stock_ub_259  17
    x_28_17   parent_nonstrict_scope_260  0.108
    x_28_17   unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_17   product_lb_34  1
    w_28_17   product_ub_35  1
    w_28_17   normalized_mass_28_41  1
    w_28_17   normalized_ratio_28_42  -2.125
    w_28_17   full_original_Gini_318  -3.3671031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_18   OBJ       5.3999999999999992e-02
    x_28_18   product_lb_36  -2.4658499354157495e-02
    x_28_18   product_ub_37  -4.2187029162663148e-02
    x_28_18   onehot_28_40  1
    x_28_18   stock_lb_258  18
    x_28_18   stock_ub_259  18
    x_28_18   parent_nonstrict_scope_260  0.12
    x_28_18   unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_18   product_lb_36  1
    w_28_18   product_ub_37  1
    w_28_18   normalized_mass_28_41  1
    w_28_18   normalized_ratio_28_42  -2.25
    w_28_18   full_original_Gini_318  -3.7046031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_28_19   OBJ       0.066
    x_28_19   product_lb_38  -2.4658499354157495e-02
    x_28_19   product_ub_39  -4.2187029162663148e-02
    x_28_19   onehot_28_40  1
    x_28_19   stock_lb_258  19
    x_28_19   stock_ub_259  19
    x_28_19   parent_nonstrict_scope_260  0.132
    x_28_19   unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_28_19   product_lb_38  1
    w_28_19   product_ub_39  1
    w_28_19   normalized_mass_28_41  1
    w_28_19   normalized_ratio_28_42  -2.375
    w_28_19   full_original_Gini_318  -4.0421031746031737e+01
    rho_28    normalized_ratio_28_42  1
    rho_28    block_pair_pos_291  -1
    rho_28    block_pair_neg_292  1
    rho_28    block_pair_pos_293  -1
    rho_28    block_pair_neg_294  1
    rho_28    block_pair_pos_295  -1
    rho_28    block_pair_neg_296  1
    rho_28    block_pair_pos_297  -1
    rho_28    block_pair_neg_298  1
    rho_28    block_pair_pos_299  -1
    rho_28    block_pair_neg_300  1
    rho_28    block_pair_pos_301  -1
    rho_28    block_pair_neg_302  1
    rho_28    block_pair_pos_303  -1
    rho_28    block_pair_neg_304  1
    rho_28    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_23_0    OBJ       1.4999999999999996e-02
    x_23_0    product_lb_43  -2.4658499354157495e-02
    x_23_0    product_ub_44  -4.2187029162663148e-02
    x_23_0    onehot_23_67  1
    x_23_0    parent_nonstrict_scope_260  0.0375
    x_23_0    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_0    product_lb_43  1
    w_23_0    product_ub_44  1
    w_23_0    normalized_mass_23_68  1
    w_23_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_1    OBJ       7.4999999999999963e-03
    x_23_1    product_lb_45  -2.4658499354157495e-02
    x_23_1    product_ub_46  -4.2187029162663148e-02
    x_23_1    onehot_23_67  1
    x_23_1    stock_lb_258  1
    x_23_1    stock_ub_259  1
    x_23_1    parent_nonstrict_scope_260  0.03
    x_23_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_1    product_lb_45  1
    w_23_1    product_ub_46  1
    w_23_1    normalized_mass_23_68  1
    w_23_1    normalized_ratio_23_69  -0.2
    w_23_1    full_original_Gini_318  -1.8303968253968257e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_2    OBJ       -3.4694469519536142e-18
    x_23_2    product_lb_47  -2.4658499354157495e-02
    x_23_2    product_ub_48  -4.2187029162663148e-02
    x_23_2    onehot_23_67  1
    x_23_2    stock_lb_258  2
    x_23_2    stock_ub_259  2
    x_23_2    parent_nonstrict_scope_260  0.0225
    x_23_2    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_2    product_lb_47  1
    w_23_2    product_ub_48  1
    w_23_2    normalized_mass_23_68  1
    w_23_2    normalized_ratio_23_69  -0.4
    w_23_2    full_original_Gini_318  -1.2903968253968250e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_3    OBJ       -7.5000000000000067e-03
    x_23_3    product_lb_49  -2.4658499354157495e-02
    x_23_3    product_ub_50  -4.2187029162663148e-02
    x_23_3    onehot_23_67  1
    x_23_3    stock_lb_258  3
    x_23_3    stock_ub_259  3
    x_23_3    parent_nonstrict_scope_260  1.4999999999999996e-02
    x_23_3    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_3    product_lb_49  1
    w_23_3    product_ub_50  1
    w_23_3    normalized_mass_23_68  1
    w_23_3    normalized_ratio_23_69  -6.0000000000000009e-01
    w_23_3    full_original_Gini_318  -7.9039682539682516e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_4    OBJ       -1.5000000000000005e-02
    x_23_4    product_lb_51  -2.4658499354157495e-02
    x_23_4    product_ub_52  -4.2187029162663148e-02
    x_23_4    onehot_23_67  1
    x_23_4    stock_lb_258  4
    x_23_4    stock_ub_259  4
    x_23_4    parent_nonstrict_scope_260  7.4999999999999980e-03
    x_23_4    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_4    product_lb_51  1
    w_23_4    product_ub_52  1
    w_23_4    normalized_mass_23_68  1
    w_23_4    normalized_ratio_23_69  -0.8
    w_23_4    full_original_Gini_318  -4.6468253968253972e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_5    OBJ       -2.2500000000000003e-02
    x_23_5    product_lb_53  -2.4658499354157495e-02
    x_23_5    product_ub_54  -4.2187029162663148e-02
    x_23_5    onehot_23_67  1
    x_23_5    stock_lb_258  5
    x_23_5    stock_ub_259  5
    x_23_5    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_5    product_lb_53  1
    w_23_5    product_ub_54  1
    w_23_5    normalized_mass_23_68  1
    w_23_5    normalized_ratio_23_69  -1
    w_23_5    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_6    OBJ       -1.4999999999999996e-02
    x_23_6    product_lb_55  -2.4658499354157495e-02
    x_23_6    product_ub_56  -4.2187029162663148e-02
    x_23_6    onehot_23_67  1
    x_23_6    stock_lb_258  6
    x_23_6    stock_ub_259  6
    x_23_6    parent_nonstrict_scope_260  7.5000000000000067e-03
    x_23_6    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_6    product_lb_55  1
    w_23_6    product_ub_56  1
    w_23_6    normalized_mass_23_68  1
    w_23_6    normalized_ratio_23_69  -1.2000000000000002e+00
    w_23_6    full_original_Gini_318  -8.7960317460317512e+00
    MARKER    'MARKER'                 'INTORG'
    x_23_7    OBJ       -7.4999999999999980e-03
    x_23_7    product_lb_57  -2.4658499354157495e-02
    x_23_7    product_ub_58  -4.2187029162663148e-02
    x_23_7    onehot_23_67  1
    x_23_7    stock_lb_258  7
    x_23_7    stock_ub_259  7
    x_23_7    parent_nonstrict_scope_260  1.5000000000000005e-02
    MARKER    'MARKER'                 'INTEND'
    w_23_7    product_lb_57  1
    w_23_7    product_ub_58  1
    w_23_7    normalized_mass_23_68  1
    w_23_7    normalized_ratio_23_69  -1.4000000000000001e+00
    w_23_7    full_original_Gini_318  -1.4096031746031754e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_8    product_lb_59  -2.4658499354157495e-02
    x_23_8    product_ub_60  -4.2187029162663148e-02
    x_23_8    onehot_23_67  1
    x_23_8    stock_lb_258  8
    x_23_8    stock_ub_259  8
    x_23_8    parent_nonstrict_scope_260  2.2500000000000003e-02
    x_23_8    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_8    product_lb_59  1
    w_23_8    product_ub_60  1
    w_23_8    normalized_mass_23_68  1
    w_23_8    normalized_ratio_23_69  -1.6
    w_23_8    full_original_Gini_318  -1.9496031746031754e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_9    OBJ       7.4999999999999963e-03
    x_23_9    product_lb_61  -2.4658499354157495e-02
    x_23_9    product_ub_62  -4.2187029162663148e-02
    x_23_9    onehot_23_67  1
    x_23_9    stock_lb_258  9
    x_23_9    stock_ub_259  9
    x_23_9    parent_nonstrict_scope_260  0.03
    x_23_9    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_9    product_lb_61  1
    w_23_9    product_ub_62  1
    w_23_9    normalized_mass_23_68  1
    w_23_9    normalized_ratio_23_69  -1.8
    w_23_9    full_original_Gini_318  -2.4896031746031753e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_10   OBJ       1.4999999999999996e-02
    x_23_10   product_lb_63  -2.4658499354157495e-02
    x_23_10   product_ub_64  -4.2187029162663148e-02
    x_23_10   onehot_23_67  1
    x_23_10   stock_lb_258  10
    x_23_10   stock_ub_259  10
    x_23_10   parent_nonstrict_scope_260  0.0375
    x_23_10   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_10   product_lb_63  1
    w_23_10   product_ub_64  1
    w_23_10   normalized_mass_23_68  1
    w_23_10   normalized_ratio_23_69  -2
    w_23_10   full_original_Gini_318  -3.0296031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_23_11   OBJ       2.2500000000000003e-02
    x_23_11   product_lb_65  -2.4658499354157495e-02
    x_23_11   product_ub_66  -4.2187029162663148e-02
    x_23_11   onehot_23_67  1
    x_23_11   stock_lb_258  11
    x_23_11   stock_ub_259  11
    x_23_11   parent_nonstrict_scope_260  4.5000000000000005e-02
    x_23_11   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_23_11   product_lb_65  1
    w_23_11   product_ub_66  1
    w_23_11   normalized_mass_23_68  1
    w_23_11   normalized_ratio_23_69  -2.2
    w_23_11   full_original_Gini_318  -3.5696031746031743e+01
    rho_23    normalized_ratio_23_69  1
    rho_23    block_pair_pos_279  -1
    rho_23    block_pair_neg_280  1
    rho_23    block_pair_pos_281  -1
    rho_23    block_pair_neg_282  1
    rho_23    block_pair_pos_283  -1
    rho_23    block_pair_neg_284  1
    rho_23    block_pair_pos_285  -1
    rho_23    block_pair_neg_286  1
    rho_23    block_pair_pos_287  -1
    rho_23    block_pair_neg_288  1
    rho_23    block_pair_pos_289  -1
    rho_23    block_pair_neg_290  1
    rho_23    block_pair_pos_297  1
    rho_23    block_pair_neg_298  -1
    rho_23    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_31_0    OBJ       0.03675
    x_31_0    product_lb_70  -2.4658499354157495e-02
    x_31_0    product_ub_71  -4.2187029162663148e-02
    x_31_0    onehot_31_96  1
    x_31_0    parent_nonstrict_scope_260  0.0735
    x_31_0    unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_0    product_lb_70  1
    w_31_0    product_ub_71  1
    w_31_0    normalized_mass_31_97  1
    w_31_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_1    OBJ       2.6250000000000002e-02
    x_31_1    product_lb_72  -2.4658499354157495e-02
    x_31_1    product_ub_73  -4.2187029162663148e-02
    x_31_1    onehot_31_96  1
    x_31_1    stock_lb_258  1
    x_31_1    stock_ub_259  1
    x_31_1    parent_nonstrict_scope_260  0.063
    x_31_1    unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_1    product_lb_72  1
    w_31_1    product_ub_73  1
    w_31_1    normalized_mass_31_97  1
    w_31_1    normalized_ratio_31_98  -1.4285714285714285e-01
    w_31_1    full_original_Gini_318  -1.9846825396825402e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_2    OBJ       0.01575
    x_31_2    product_lb_74  -2.4658499354157495e-02
    x_31_2    product_ub_75  -4.2187029162663148e-02
    x_31_2    onehot_31_96  1
    x_31_2    stock_lb_258  2
    x_31_2    stock_ub_259  2
    x_31_2    parent_nonstrict_scope_260  0.0525
    MARKER    'MARKER'                 'INTEND'
    w_31_2    product_lb_74  1
    w_31_2    product_ub_75  1
    w_31_2    normalized_mass_31_97  1
    w_31_2    normalized_ratio_31_98  -2.8571428571428570e-01
    w_31_2    full_original_Gini_318  -1.5989682539682534e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_3    OBJ       5.2499999999999977e-03
    x_31_3    product_lb_76  -2.4658499354157495e-02
    x_31_3    product_ub_77  -4.2187029162663148e-02
    x_31_3    onehot_31_96  1
    x_31_3    stock_lb_258  3
    x_31_3    stock_ub_259  3
    x_31_3    parent_nonstrict_scope_260  4.1999999999999996e-02
    x_31_3    unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_3    product_lb_76  1
    w_31_3    product_ub_77  1
    w_31_3    normalized_mass_31_97  1
    w_31_3    normalized_ratio_31_98  -4.2857142857142855e-01
    w_31_3    full_original_Gini_318  -1.2132539682539681e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_4    OBJ       -5.2499999999999977e-03
    x_31_4    product_lb_78  -2.4658499354157495e-02
    x_31_4    product_ub_79  -4.2187029162663148e-02
    x_31_4    onehot_31_96  1
    x_31_4    stock_lb_258  4
    x_31_4    stock_ub_259  4
    x_31_4    parent_nonstrict_scope_260  0.0315
    x_31_4    unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_4    product_lb_78  1
    w_31_4    product_ub_79  1
    w_31_4    normalized_mass_31_97  1
    w_31_4    normalized_ratio_31_98  -5.7142857142857140e-01
    w_31_4    full_original_Gini_318  -8.5611111111111118e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_5    OBJ       -1.5749999999999993e-02
    x_31_5    product_lb_80  -2.4658499354157495e-02
    x_31_5    product_ub_81  -4.2187029162663148e-02
    x_31_5    onehot_31_96  1
    x_31_5    stock_lb_258  5
    x_31_5    stock_ub_259  5
    x_31_5    parent_nonstrict_scope_260  2.1000000000000005e-02
    x_31_5    unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_5    product_lb_80  1
    w_31_5    product_ub_81  1
    w_31_5    normalized_mass_31_97  1
    w_31_5    normalized_ratio_31_98  -7.1428571428571419e-01
    w_31_5    full_original_Gini_318  -5.7325396825396826e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_6    OBJ       -2.6249999999999996e-02
    x_31_6    product_lb_82  -2.4658499354157495e-02
    x_31_6    product_ub_83  -4.2187029162663148e-02
    x_31_6    onehot_31_96  1
    x_31_6    stock_lb_258  6
    x_31_6    stock_ub_259  6
    x_31_6    parent_nonstrict_scope_260  1.0500000000000002e-02
    x_31_6    unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_6    product_lb_82  1
    w_31_6    product_ub_83  1
    w_31_6    normalized_mass_31_97  1
    w_31_6    normalized_ratio_31_98  -8.5714285714285710e-01
    w_31_6    full_original_Gini_318  -4.0658730158730156e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_7    OBJ       -0.03675
    x_31_7    product_lb_84  -2.4658499354157495e-02
    x_31_7    product_ub_85  -4.2187029162663148e-02
    x_31_7    onehot_31_96  1
    x_31_7    stock_lb_258  7
    x_31_7    stock_ub_259  7
    x_31_7    unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_7    product_lb_84  1
    w_31_7    product_ub_85  1
    w_31_7    normalized_mass_31_97  1
    w_31_7    normalized_ratio_31_98  -1
    w_31_7    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_8    OBJ       -2.6250000000000002e-02
    x_31_8    product_lb_86  -2.4658499354157495e-02
    x_31_8    product_ub_87  -4.2187029162663148e-02
    x_31_8    onehot_31_96  1
    x_31_8    stock_lb_258  8
    x_31_8    stock_ub_259  8
    x_31_8    parent_nonstrict_scope_260  1.0499999999999995e-02
    x_31_8    unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_8    product_lb_86  1
    w_31_8    product_ub_87  1
    w_31_8    normalized_mass_31_97  1
    w_31_8    normalized_ratio_31_98  -1.1428571428571428e+00
    w_31_8    full_original_Gini_318  -7.3674603174603153e+00
    MARKER    'MARKER'                 'INTORG'
    x_31_9    OBJ       -1.5750000000000007e-02
    x_31_9    product_lb_88  -2.4658499354157495e-02
    x_31_9    product_ub_89  -4.2187029162663148e-02
    x_31_9    onehot_31_96  1
    x_31_9    stock_lb_258  9
    x_31_9    stock_ub_259  9
    x_31_9    parent_nonstrict_scope_260  2.0999999999999991e-02
    x_31_9    unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_9    product_lb_88  1
    w_31_9    product_ub_89  1
    w_31_9    normalized_mass_31_97  1
    w_31_9    normalized_ratio_31_98  -1.2857142857142856e+00
    w_31_9    full_original_Gini_318  -1.1010317460317456e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_10   OBJ       -5.2500000000000116e-03
    x_31_10   product_lb_90  -2.4658499354157495e-02
    x_31_10   product_ub_91  -4.2187029162663148e-02
    x_31_10   onehot_31_96  1
    x_31_10   stock_lb_258  10
    x_31_10   stock_ub_259  10
    x_31_10   parent_nonstrict_scope_260  3.1499999999999986e-02
    x_31_10   unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_10   product_lb_90  1
    w_31_10   product_ub_91  1
    w_31_10   normalized_mass_31_97  1
    w_31_10   normalized_ratio_31_98  -1.4285714285714284e+00
    w_31_10   full_original_Gini_318  -1.4867460317460315e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_11   OBJ       5.2499999999999977e-03
    x_31_11   product_lb_92  -2.4658499354157495e-02
    x_31_11   product_ub_93  -4.2187029162663148e-02
    x_31_11   onehot_31_96  1
    x_31_11   stock_lb_258  11
    x_31_11   stock_ub_259  11
    x_31_11   parent_nonstrict_scope_260  4.1999999999999996e-02
    x_31_11   unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_11   product_lb_92  1
    w_31_11   product_ub_93  1
    w_31_11   normalized_mass_31_97  1
    w_31_11   normalized_ratio_31_98  -1.5714285714285714e+00
    w_31_11   full_original_Gini_318  -1.8724603174603178e+01
    MARKER    'MARKER'                 'INTORG'
    x_31_12   OBJ       1.5749999999999993e-02
    x_31_12   product_lb_94  -2.4658499354157495e-02
    x_31_12   product_ub_95  -4.2187029162663148e-02
    x_31_12   onehot_31_96  1
    x_31_12   stock_lb_258  12
    x_31_12   stock_ub_259  12
    x_31_12   parent_nonstrict_scope_260  5.2499999999999991e-02
    x_31_12   unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_31_12   product_lb_94  1
    w_31_12   product_ub_95  1
    w_31_12   normalized_mass_31_97  1
    w_31_12   normalized_ratio_31_98  -1.7142857142857142e+00
    w_31_12   full_original_Gini_318  -2.2581746031746032e+01
    rho_31    normalized_ratio_31_98  1
    rho_31    block_pair_pos_285  1
    rho_31    block_pair_neg_286  -1
    rho_31    block_pair_pos_299  1
    rho_31    block_pair_neg_300  -1
    rho_31    block_pair_pos_305  -1
    rho_31    block_pair_neg_306  1
    rho_31    block_pair_pos_307  -1
    rho_31    block_pair_neg_308  1
    rho_31    block_pair_pos_309  -1
    rho_31    block_pair_neg_310  1
    rho_31    block_pair_pos_311  -1
    rho_31    block_pair_neg_312  1
    rho_31    block_pair_pos_313  -1
    rho_31    block_pair_neg_314  1
    rho_31    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_21_0    OBJ       0.048
    x_21_0    product_lb_99  -2.4658499354157495e-02
    x_21_0    product_ub_100  -4.2187029162663148e-02
    x_21_0    onehot_21_131  1
    x_21_0    parent_nonstrict_scope_260  0.096
    x_21_0    unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_0    product_lb_99  1
    w_21_0    product_ub_100  1
    w_21_0    normalized_mass_21_132  1
    w_21_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_1    OBJ       3.6000000000000004e-02
    x_21_1    product_lb_101  -2.4658499354157495e-02
    x_21_1    product_ub_102  -4.2187029162663148e-02
    x_21_1    onehot_21_131  1
    x_21_1    stock_lb_258  1
    x_21_1    stock_ub_259  1
    x_21_1    parent_nonstrict_scope_260  0.084
    MARKER    'MARKER'                 'INTEND'
    w_21_1    product_lb_101  1
    w_21_1    product_ub_102  1
    w_21_1    normalized_mass_21_132  1
    w_21_1    normalized_ratio_21_133  -0.125
    w_21_1    full_original_Gini_318  -2.0328968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_2    OBJ       2.4000000000000007e-02
    x_21_2    product_lb_103  -2.4658499354157495e-02
    x_21_2    product_ub_104  -4.2187029162663148e-02
    x_21_2    onehot_21_131  1
    x_21_2    stock_lb_258  2
    x_21_2    stock_ub_259  2
    x_21_2    parent_nonstrict_scope_260  7.2000000000000008e-02
    x_21_2    unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_2    product_lb_103  1
    w_21_2    product_ub_104  1
    w_21_2    normalized_mass_21_132  1
    w_21_2    normalized_ratio_21_133  -0.25
    w_21_2    full_original_Gini_318  -1.6953968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_3    OBJ       1.1999999999999997e-02
    x_21_3    product_lb_105  -2.4658499354157495e-02
    x_21_3    product_ub_106  -4.2187029162663148e-02
    x_21_3    onehot_21_131  1
    x_21_3    stock_lb_258  3
    x_21_3    stock_ub_259  3
    x_21_3    parent_nonstrict_scope_260  0.06
    x_21_3    unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_3    product_lb_105  1
    w_21_3    product_ub_106  1
    w_21_3    normalized_mass_21_132  1
    w_21_3    normalized_ratio_21_133  -0.375
    w_21_3    full_original_Gini_318  -1.3578968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_4    product_lb_107  -2.4658499354157495e-02
    x_21_4    product_ub_108  -4.2187029162663148e-02
    x_21_4    onehot_21_131  1
    x_21_4    stock_lb_258  4
    x_21_4    stock_ub_259  4
    x_21_4    parent_nonstrict_scope_260  0.048
    x_21_4    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_4    product_lb_107  1
    w_21_4    product_ub_108  1
    w_21_4    normalized_mass_21_132  1
    w_21_4    normalized_ratio_21_133  -0.5
    w_21_4    full_original_Gini_318  -1.0203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_5    OBJ       -1.1999999999999997e-02
    x_21_5    product_lb_109  -2.4658499354157495e-02
    x_21_5    product_ub_110  -4.2187029162663148e-02
    x_21_5    onehot_21_131  1
    x_21_5    stock_lb_258  5
    x_21_5    stock_ub_259  5
    x_21_5    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_21_5    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_5    product_lb_109  1
    w_21_5    product_ub_110  1
    w_21_5    normalized_mass_21_132  1
    w_21_5    normalized_ratio_21_133  -0.625
    w_21_5    full_original_Gini_318  -7.4289682539682538e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_6    OBJ       -0.024
    x_21_6    product_lb_111  -2.4658499354157495e-02
    x_21_6    product_ub_112  -4.2187029162663148e-02
    x_21_6    onehot_21_131  1
    x_21_6    stock_lb_258  6
    x_21_6    stock_ub_259  6
    x_21_6    parent_nonstrict_scope_260  0.024
    x_21_6    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_6    product_lb_111  1
    w_21_6    product_ub_112  1
    w_21_6    normalized_mass_21_132  1
    w_21_6    normalized_ratio_21_133  -0.75
    w_21_6    full_original_Gini_318  -5.1968253968253961e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_7    OBJ       -3.6000000000000004e-02
    x_21_7    product_lb_113  -2.4658499354157495e-02
    x_21_7    product_ub_114  -4.2187029162663148e-02
    x_21_7    onehot_21_131  1
    x_21_7    stock_lb_258  7
    x_21_7    stock_ub_259  7
    x_21_7    parent_nonstrict_scope_260  0.012
    x_21_7    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_7    product_lb_113  1
    w_21_7    product_ub_114  1
    w_21_7    normalized_mass_21_132  1
    w_21_7    normalized_ratio_21_133  -0.875
    w_21_7    full_original_Gini_318  -3.9765873015873017e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_8    OBJ       -0.048
    x_21_8    product_lb_115  -2.4658499354157495e-02
    x_21_8    product_ub_116  -4.2187029162663148e-02
    x_21_8    onehot_21_131  1
    x_21_8    stock_lb_258  8
    x_21_8    stock_ub_259  8
    x_21_8    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_8    product_lb_115  1
    w_21_8    product_ub_116  1
    w_21_8    normalized_mass_21_132  1
    w_21_8    normalized_ratio_21_133  -1
    w_21_8    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_9    OBJ       -3.6000000000000004e-02
    x_21_9    product_lb_117  -2.4658499354157495e-02
    x_21_9    product_ub_118  -4.2187029162663148e-02
    x_21_9    onehot_21_131  1
    x_21_9    stock_lb_258  9
    x_21_9    stock_ub_259  9
    x_21_9    parent_nonstrict_scope_260  0.012
    x_21_9    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_9    product_lb_117  1
    w_21_9    product_ub_118  1
    w_21_9    normalized_mass_21_132  1
    w_21_9    normalized_ratio_21_133  -1.125
    w_21_9    full_original_Gini_318  -6.9210317460317459e+00
    MARKER    'MARKER'                 'INTORG'
    x_21_10   OBJ       -0.024
    x_21_10   product_lb_119  -2.4658499354157495e-02
    x_21_10   product_ub_120  -4.2187029162663148e-02
    x_21_10   onehot_21_131  1
    x_21_10   stock_lb_258  10
    x_21_10   stock_ub_259  10
    x_21_10   parent_nonstrict_scope_260  0.024
    x_21_10   unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_10   product_lb_119  1
    w_21_10   product_ub_120  1
    w_21_10   normalized_mass_21_132  1
    w_21_10   normalized_ratio_21_133  -1.25
    w_21_10   full_original_Gini_318  -1.0046031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_11   OBJ       -1.1999999999999997e-02
    x_21_11   product_lb_121  -2.4658499354157495e-02
    x_21_11   product_ub_122  -4.2187029162663148e-02
    x_21_11   onehot_21_131  1
    x_21_11   stock_lb_258  11
    x_21_11   stock_ub_259  11
    x_21_11   parent_nonstrict_scope_260  3.6000000000000004e-02
    x_21_11   unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_11   product_lb_121  1
    w_21_11   product_ub_122  1
    w_21_11   normalized_mass_21_132  1
    w_21_11   normalized_ratio_21_133  -1.375
    w_21_11   full_original_Gini_318  -1.3421031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_12   product_lb_123  -2.4658499354157495e-02
    x_21_12   product_ub_124  -4.2187029162663148e-02
    x_21_12   onehot_21_131  1
    x_21_12   stock_lb_258  12
    x_21_12   stock_ub_259  12
    x_21_12   parent_nonstrict_scope_260  0.048
    x_21_12   unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_12   product_lb_123  1
    w_21_12   product_ub_124  1
    w_21_12   normalized_mass_21_132  1
    w_21_12   normalized_ratio_21_133  -1.5
    w_21_12   full_original_Gini_318  -1.6796031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_13   OBJ       1.1999999999999997e-02
    x_21_13   product_lb_125  -2.4658499354157495e-02
    x_21_13   product_ub_126  -4.2187029162663148e-02
    x_21_13   onehot_21_131  1
    x_21_13   stock_lb_258  13
    x_21_13   stock_ub_259  13
    x_21_13   parent_nonstrict_scope_260  0.06
    x_21_13   unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_13   product_lb_125  1
    w_21_13   product_ub_126  1
    w_21_13   normalized_mass_21_132  1
    w_21_13   normalized_ratio_21_133  -1.625
    w_21_13   full_original_Gini_318  -2.0171031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_14   OBJ       2.4000000000000007e-02
    x_21_14   product_lb_127  -2.4658499354157495e-02
    x_21_14   product_ub_128  -4.2187029162663148e-02
    x_21_14   onehot_21_131  1
    x_21_14   stock_lb_258  14
    x_21_14   stock_ub_259  14
    x_21_14   parent_nonstrict_scope_260  7.2000000000000008e-02
    x_21_14   unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_14   product_lb_127  1
    w_21_14   product_ub_128  1
    w_21_14   normalized_mass_21_132  1
    w_21_14   normalized_ratio_21_133  -1.75
    w_21_14   full_original_Gini_318  -2.3546031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_21_15   OBJ       3.6000000000000004e-02
    x_21_15   product_lb_129  -2.4658499354157495e-02
    x_21_15   product_ub_130  -4.2187029162663148e-02
    x_21_15   onehot_21_131  1
    x_21_15   stock_lb_258  15
    x_21_15   stock_ub_259  15
    x_21_15   parent_nonstrict_scope_260  0.084
    x_21_15   unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_21_15   product_lb_129  1
    w_21_15   product_ub_130  1
    w_21_15   normalized_mass_21_132  1
    w_21_15   normalized_ratio_21_133  -1.875
    w_21_15   full_original_Gini_318  -2.6921031746031744e+01
    rho_21    normalized_ratio_21_133  1
    rho_21    block_pair_pos_271  -1
    rho_21    block_pair_neg_272  1
    rho_21    block_pair_pos_273  -1
    rho_21    block_pair_neg_274  1
    rho_21    block_pair_pos_275  -1
    rho_21    block_pair_neg_276  1
    rho_21    block_pair_pos_277  -1
    rho_21    block_pair_neg_278  1
    rho_21    block_pair_pos_283  1
    rho_21    block_pair_neg_284  -1
    rho_21    block_pair_pos_295  1
    rho_21    block_pair_neg_296  -1
    rho_21    block_pair_pos_309  1
    rho_21    block_pair_neg_310  -1
    rho_21    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_16_0    OBJ       0.027
    x_16_0    product_lb_134  -2.4658499354157495e-02
    x_16_0    product_ub_135  -4.2187029162663148e-02
    x_16_0    onehot_16_160  1
    x_16_0    parent_nonstrict_scope_260  0.054
    x_16_0    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_0    product_lb_134  1
    w_16_0    product_ub_135  1
    w_16_0    normalized_mass_16_161  1
    w_16_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_1    OBJ       0.018
    x_16_1    product_lb_136  -2.4658499354157495e-02
    x_16_1    product_ub_137  -4.2187029162663148e-02
    x_16_1    onehot_16_160  1
    x_16_1    stock_lb_258  1
    x_16_1    stock_ub_259  1
    x_16_1    parent_nonstrict_scope_260  0.045
    MARKER    'MARKER'                 'INTEND'
    w_16_1    product_lb_136  1
    w_16_1    product_ub_137  1
    w_16_1    normalized_mass_16_161  1
    w_16_1    normalized_ratio_16_162  -1.6666666666666666e-01
    w_16_1    full_original_Gini_318  -1.9203968253968249e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_2    OBJ       9.0000000000000045e-03
    x_16_2    product_lb_138  -2.4658499354157495e-02
    x_16_2    product_ub_139  -4.2187029162663148e-02
    x_16_2    onehot_16_160  1
    x_16_2    stock_lb_258  2
    x_16_2    stock_ub_259  2
    x_16_2    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_16_2    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_2    product_lb_138  1
    w_16_2    product_ub_139  1
    w_16_2    normalized_mass_16_161  1
    w_16_2    normalized_ratio_16_162  -3.3333333333333331e-01
    w_16_2    full_original_Gini_318  -1.4703968253968252e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_3    product_lb_140  -2.4658499354157495e-02
    x_16_3    product_ub_141  -4.2187029162663148e-02
    x_16_3    onehot_16_160  1
    x_16_3    stock_lb_258  3
    x_16_3    stock_ub_259  3
    x_16_3    parent_nonstrict_scope_260  0.027
    x_16_3    unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_3    product_lb_140  1
    w_16_3    product_ub_141  1
    w_16_3    normalized_mass_16_161  1
    w_16_3    normalized_ratio_16_162  -0.5
    w_16_3    full_original_Gini_318  -1.0203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_4    OBJ       -8.9999999999999976e-03
    x_16_4    product_lb_142  -2.4658499354157495e-02
    x_16_4    product_ub_143  -4.2187029162663148e-02
    x_16_4    onehot_16_160  1
    x_16_4    stock_lb_258  4
    x_16_4    stock_ub_259  4
    x_16_4    parent_nonstrict_scope_260  1.8000000000000002e-02
    x_16_4    unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_4    product_lb_142  1
    w_16_4    product_ub_143  1
    w_16_4    normalized_mass_16_161  1
    w_16_4    normalized_ratio_16_162  -6.6666666666666663e-01
    w_16_4    full_original_Gini_318  -6.6373015873015868e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_5    OBJ       -1.7999999999999995e-02
    x_16_5    product_lb_144  -2.4658499354157495e-02
    x_16_5    product_ub_145  -4.2187029162663148e-02
    x_16_5    onehot_16_160  1
    x_16_5    stock_lb_258  5
    x_16_5    stock_ub_259  5
    x_16_5    parent_nonstrict_scope_260  9.0000000000000045e-03
    x_16_5    unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_5    product_lb_144  1
    w_16_5    product_ub_145  1
    w_16_5    normalized_mass_16_161  1
    w_16_5    normalized_ratio_16_162  -8.3333333333333326e-01
    w_16_5    full_original_Gini_318  -4.2801587301587318e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_6    OBJ       -0.027
    x_16_6    product_lb_146  -2.4658499354157495e-02
    x_16_6    product_ub_147  -4.2187029162663148e-02
    x_16_6    onehot_16_160  1
    x_16_6    stock_lb_258  6
    x_16_6    stock_ub_259  6
    x_16_6    unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_6    product_lb_146  1
    w_16_6    product_ub_147  1
    w_16_6    normalized_mass_16_161  1
    w_16_6    normalized_ratio_16_162  -1
    w_16_6    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_7    OBJ       -1.8000000000000009e-02
    x_16_7    product_lb_148  -2.4658499354157495e-02
    x_16_7    product_ub_149  -4.2187029162663148e-02
    x_16_7    onehot_16_160  1
    x_16_7    stock_lb_258  7
    x_16_7    stock_ub_259  7
    x_16_7    parent_nonstrict_scope_260  8.9999999999999924e-03
    x_16_7    unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_7    product_lb_148  1
    w_16_7    product_ub_149  1
    w_16_7    normalized_mass_16_161  1
    w_16_7    normalized_ratio_16_162  -1.1666666666666665e+00
    w_16_7    full_original_Gini_318  -7.9626984126984084e+00
    MARKER    'MARKER'                 'INTORG'
    x_16_8    OBJ       -9.0000000000000045e-03
    x_16_8    product_lb_150  -2.4658499354157495e-02
    x_16_8    product_ub_151  -4.2187029162663148e-02
    x_16_8    onehot_16_160  1
    x_16_8    stock_lb_258  8
    x_16_8    stock_ub_259  8
    x_16_8    parent_nonstrict_scope_260  1.7999999999999995e-02
    x_16_8    unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_8    product_lb_150  1
    w_16_8    product_ub_151  1
    w_16_8    normalized_mass_16_161  1
    w_16_8    normalized_ratio_16_162  -1.3333333333333333e+00
    w_16_8    full_original_Gini_318  -1.2296031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_9    product_lb_152  -2.4658499354157495e-02
    x_16_9    product_ub_153  -4.2187029162663148e-02
    x_16_9    onehot_16_160  1
    x_16_9    stock_lb_258  9
    x_16_9    stock_ub_259  9
    x_16_9    parent_nonstrict_scope_260  0.027
    x_16_9    unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_9    product_lb_152  1
    w_16_9    product_ub_153  1
    w_16_9    normalized_mass_16_161  1
    w_16_9    normalized_ratio_16_162  -1.5
    w_16_9    full_original_Gini_318  -1.6796031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_10   OBJ       0.00899999999999999
    x_16_10   product_lb_154  -2.4658499354157495e-02
    x_16_10   product_ub_155  -4.2187029162663148e-02
    x_16_10   onehot_16_160  1
    x_16_10   stock_lb_258  10
    x_16_10   stock_ub_259  10
    x_16_10   parent_nonstrict_scope_260  3.5999999999999990e-02
    x_16_10   unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_10   product_lb_154  1
    w_16_10   product_ub_155  1
    w_16_10   normalized_mass_16_161  1
    w_16_10   normalized_ratio_16_162  -1.6666666666666665e+00
    w_16_10   full_original_Gini_318  -2.1296031746031748e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_11   OBJ       0.018
    x_16_11   product_lb_156  -2.4658499354157495e-02
    x_16_11   product_ub_157  -4.2187029162663148e-02
    x_16_11   onehot_16_160  1
    x_16_11   stock_lb_258  11
    x_16_11   stock_ub_259  11
    x_16_11   parent_nonstrict_scope_260  0.045
    x_16_11   unique_nonzero_owner_386  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_11   product_lb_156  1
    w_16_11   product_ub_157  1
    w_16_11   normalized_mass_16_161  1
    w_16_11   normalized_ratio_16_162  -1.8333333333333333e+00
    w_16_11   full_original_Gini_318  -2.5796031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_16_12   OBJ       0.027
    x_16_12   product_lb_158  -2.4658499354157495e-02
    x_16_12   product_ub_159  -4.2187029162663148e-02
    x_16_12   onehot_16_160  1
    x_16_12   stock_lb_258  12
    x_16_12   stock_ub_259  12
    x_16_12   parent_nonstrict_scope_260  0.054
    x_16_12   unique_nonzero_owner_387  -1
    MARKER    'MARKER'                 'INTEND'
    w_16_12   product_lb_158  1
    w_16_12   product_ub_159  1
    w_16_12   normalized_mass_16_161  1
    w_16_12   normalized_ratio_16_162  -2
    w_16_12   full_original_Gini_318  -3.0296031746031744e+01
    rho_16    normalized_ratio_16_162  1
    rho_16    block_pair_pos_261  -1
    rho_16    block_pair_neg_262  1
    rho_16    block_pair_pos_263  -1
    rho_16    block_pair_neg_264  1
    rho_16    block_pair_pos_265  -1
    rho_16    block_pair_neg_266  1
    rho_16    block_pair_pos_271  1
    rho_16    block_pair_neg_272  -1
    rho_16    block_pair_pos_279  1
    rho_16    block_pair_neg_280  -1
    rho_16    block_pair_pos_291  1
    rho_16    block_pair_neg_292  -1
    rho_16    block_pair_pos_305  1
    rho_16    block_pair_neg_306  -1
    rho_16    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_20_0    OBJ       0.027
    x_20_0    product_lb_163  -2.4658499354157495e-02
    x_20_0    product_ub_164  -4.2187029162663148e-02
    x_20_0    onehot_20_189  1
    x_20_0    parent_nonstrict_scope_260  0.054
    x_20_0    unique_nonzero_owner_388  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_0    product_lb_163  1
    w_20_0    product_ub_164  1
    w_20_0    normalized_mass_20_190  1
    w_20_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_1    OBJ       0.018
    x_20_1    product_lb_165  -2.4658499354157495e-02
    x_20_1    product_ub_166  -4.2187029162663148e-02
    x_20_1    onehot_20_189  1
    x_20_1    stock_lb_258  1
    x_20_1    stock_ub_259  1
    x_20_1    parent_nonstrict_scope_260  0.045
    x_20_1    unique_nonzero_owner_389  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_1    product_lb_165  1
    w_20_1    product_ub_166  1
    w_20_1    normalized_mass_20_190  1
    w_20_1    normalized_ratio_20_191  -1.6666666666666666e-01
    w_20_1    full_original_Gini_318  -1.9203968253968249e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_2    OBJ       9.0000000000000045e-03
    x_20_2    product_lb_167  -2.4658499354157495e-02
    x_20_2    product_ub_168  -4.2187029162663148e-02
    x_20_2    onehot_20_189  1
    x_20_2    stock_lb_258  2
    x_20_2    stock_ub_259  2
    x_20_2    parent_nonstrict_scope_260  3.6000000000000004e-02
    x_20_2    unique_nonzero_owner_390  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_2    product_lb_167  1
    w_20_2    product_ub_168  1
    w_20_2    normalized_mass_20_190  1
    w_20_2    normalized_ratio_20_191  -3.3333333333333331e-01
    w_20_2    full_original_Gini_318  -1.4703968253968252e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_3    product_lb_169  -2.4658499354157495e-02
    x_20_3    product_ub_170  -4.2187029162663148e-02
    x_20_3    onehot_20_189  1
    x_20_3    stock_lb_258  3
    x_20_3    stock_ub_259  3
    x_20_3    parent_nonstrict_scope_260  0.027
    x_20_3    unique_nonzero_owner_391  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_3    product_lb_169  1
    w_20_3    product_ub_170  1
    w_20_3    normalized_mass_20_190  1
    w_20_3    normalized_ratio_20_191  -0.5
    w_20_3    full_original_Gini_318  -1.0203968253968254e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_4    OBJ       -8.9999999999999976e-03
    x_20_4    product_lb_171  -2.4658499354157495e-02
    x_20_4    product_ub_172  -4.2187029162663148e-02
    x_20_4    onehot_20_189  1
    x_20_4    stock_lb_258  4
    x_20_4    stock_ub_259  4
    x_20_4    parent_nonstrict_scope_260  1.8000000000000002e-02
    x_20_4    unique_nonzero_owner_392  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_4    product_lb_171  1
    w_20_4    product_ub_172  1
    w_20_4    normalized_mass_20_190  1
    w_20_4    normalized_ratio_20_191  -6.6666666666666663e-01
    w_20_4    full_original_Gini_318  -6.6373015873015868e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_5    OBJ       -1.7999999999999995e-02
    x_20_5    product_lb_173  -2.4658499354157495e-02
    x_20_5    product_ub_174  -4.2187029162663148e-02
    x_20_5    onehot_20_189  1
    x_20_5    stock_lb_258  5
    x_20_5    stock_ub_259  5
    x_20_5    parent_nonstrict_scope_260  9.0000000000000045e-03
    x_20_5    unique_nonzero_owner_393  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_5    product_lb_173  1
    w_20_5    product_ub_174  1
    w_20_5    normalized_mass_20_190  1
    w_20_5    normalized_ratio_20_191  -8.3333333333333326e-01
    w_20_5    full_original_Gini_318  -4.2801587301587318e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_6    OBJ       -0.027
    x_20_6    product_lb_175  -2.4658499354157495e-02
    x_20_6    product_ub_176  -4.2187029162663148e-02
    x_20_6    onehot_20_189  1
    x_20_6    stock_lb_258  6
    x_20_6    stock_ub_259  6
    x_20_6    unique_nonzero_owner_394  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_6    product_lb_175  1
    w_20_6    product_ub_176  1
    w_20_6    normalized_mass_20_190  1
    w_20_6    normalized_ratio_20_191  -1
    w_20_6    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_7    OBJ       -1.8000000000000009e-02
    x_20_7    product_lb_177  -2.4658499354157495e-02
    x_20_7    product_ub_178  -4.2187029162663148e-02
    x_20_7    onehot_20_189  1
    x_20_7    stock_lb_258  7
    x_20_7    stock_ub_259  7
    x_20_7    parent_nonstrict_scope_260  8.9999999999999924e-03
    x_20_7    unique_nonzero_owner_395  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_7    product_lb_177  1
    w_20_7    product_ub_178  1
    w_20_7    normalized_mass_20_190  1
    w_20_7    normalized_ratio_20_191  -1.1666666666666665e+00
    w_20_7    full_original_Gini_318  -7.9626984126984084e+00
    MARKER    'MARKER'                 'INTORG'
    x_20_8    OBJ       -9.0000000000000045e-03
    x_20_8    product_lb_179  -2.4658499354157495e-02
    x_20_8    product_ub_180  -4.2187029162663148e-02
    x_20_8    onehot_20_189  1
    x_20_8    stock_lb_258  8
    x_20_8    stock_ub_259  8
    x_20_8    parent_nonstrict_scope_260  1.7999999999999995e-02
    x_20_8    unique_nonzero_owner_396  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_8    product_lb_179  1
    w_20_8    product_ub_180  1
    w_20_8    normalized_mass_20_190  1
    w_20_8    normalized_ratio_20_191  -1.3333333333333333e+00
    w_20_8    full_original_Gini_318  -1.2296031746031746e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_9    product_lb_181  -2.4658499354157495e-02
    x_20_9    product_ub_182  -4.2187029162663148e-02
    x_20_9    onehot_20_189  1
    x_20_9    stock_lb_258  9
    x_20_9    stock_ub_259  9
    x_20_9    parent_nonstrict_scope_260  0.027
    MARKER    'MARKER'                 'INTEND'
    w_20_9    product_lb_181  1
    w_20_9    product_ub_182  1
    w_20_9    normalized_mass_20_190  1
    w_20_9    normalized_ratio_20_191  -1.5
    w_20_9    full_original_Gini_318  -1.6796031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_10   OBJ       0.00899999999999999
    x_20_10   product_lb_183  -2.4658499354157495e-02
    x_20_10   product_ub_184  -4.2187029162663148e-02
    x_20_10   onehot_20_189  1
    x_20_10   stock_lb_258  10
    x_20_10   stock_ub_259  10
    x_20_10   parent_nonstrict_scope_260  3.5999999999999990e-02
    x_20_10   unique_nonzero_owner_397  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_10   product_lb_183  1
    w_20_10   product_ub_184  1
    w_20_10   normalized_mass_20_190  1
    w_20_10   normalized_ratio_20_191  -1.6666666666666665e+00
    w_20_10   full_original_Gini_318  -2.1296031746031748e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_11   OBJ       0.018
    x_20_11   product_lb_185  -2.4658499354157495e-02
    x_20_11   product_ub_186  -4.2187029162663148e-02
    x_20_11   onehot_20_189  1
    x_20_11   stock_lb_258  11
    x_20_11   stock_ub_259  11
    x_20_11   parent_nonstrict_scope_260  0.045
    x_20_11   unique_nonzero_owner_398  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_11   product_lb_185  1
    w_20_11   product_ub_186  1
    w_20_11   normalized_mass_20_190  1
    w_20_11   normalized_ratio_20_191  -1.8333333333333333e+00
    w_20_11   full_original_Gini_318  -2.5796031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_20_12   OBJ       0.027
    x_20_12   product_lb_187  -2.4658499354157495e-02
    x_20_12   product_ub_188  -4.2187029162663148e-02
    x_20_12   onehot_20_189  1
    x_20_12   stock_lb_258  12
    x_20_12   stock_ub_259  12
    x_20_12   parent_nonstrict_scope_260  0.054
    x_20_12   unique_nonzero_owner_399  -1
    MARKER    'MARKER'                 'INTEND'
    w_20_12   product_lb_187  1
    w_20_12   product_ub_188  1
    w_20_12   normalized_mass_20_190  1
    w_20_12   normalized_ratio_20_191  -2
    w_20_12   full_original_Gini_318  -3.0296031746031744e+01
    rho_20    normalized_ratio_20_191  1
    rho_20    block_pair_pos_261  1
    rho_20    block_pair_neg_262  -1
    rho_20    block_pair_pos_267  -1
    rho_20    block_pair_neg_268  1
    rho_20    block_pair_pos_269  -1
    rho_20    block_pair_neg_270  1
    rho_20    block_pair_pos_273  1
    rho_20    block_pair_neg_274  -1
    rho_20    block_pair_pos_281  1
    rho_20    block_pair_neg_282  -1
    rho_20    block_pair_pos_293  1
    rho_20    block_pair_neg_294  -1
    rho_20    block_pair_pos_307  1
    rho_20    block_pair_neg_308  -1
    rho_20    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_32_0    OBJ       1.1249999999999993e-02
    x_32_0    product_lb_192  -2.4658499354157495e-02
    x_32_0    product_ub_193  -4.2187029162663148e-02
    x_32_0    onehot_32_218  1
    x_32_0    parent_nonstrict_scope_260  0.0375
    MARKER    'MARKER'                 'INTEND'
    w_32_0    product_lb_192  1
    w_32_0    product_ub_193  1
    w_32_0    normalized_mass_32_219  1
    w_32_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_1    OBJ       3.7499999999999929e-03
    x_32_1    product_lb_194  -2.4658499354157495e-02
    x_32_1    product_ub_195  -4.2187029162663148e-02
    x_32_1    onehot_32_218  1
    x_32_1    stock_lb_258  1
    x_32_1    stock_ub_259  1
    x_32_1    parent_nonstrict_scope_260  0.03
    x_32_1    unique_nonzero_owner_400  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_1    product_lb_194  1
    w_32_1    product_ub_195  1
    w_32_1    normalized_mass_32_219  1
    w_32_1    normalized_ratio_32_220  -0.2
    w_32_1    full_original_Gini_318  -1.8303968253968257e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_2    OBJ       -3.7500000000000068e-03
    x_32_2    product_lb_196  -2.4658499354157495e-02
    x_32_2    product_ub_197  -4.2187029162663148e-02
    x_32_2    onehot_32_218  1
    x_32_2    stock_lb_258  2
    x_32_2    stock_ub_259  2
    x_32_2    parent_nonstrict_scope_260  0.0225
    x_32_2    unique_nonzero_owner_401  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_2    product_lb_196  1
    w_32_2    product_ub_197  1
    w_32_2    normalized_mass_32_219  1
    w_32_2    normalized_ratio_32_220  -0.4
    w_32_2    full_original_Gini_318  -1.2903968253968250e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_3    OBJ       -1.1250000000000010e-02
    x_32_3    product_lb_198  -2.4658499354157495e-02
    x_32_3    product_ub_199  -4.2187029162663148e-02
    x_32_3    onehot_32_218  1
    x_32_3    stock_lb_258  3
    x_32_3    stock_ub_259  3
    x_32_3    parent_nonstrict_scope_260  1.4999999999999996e-02
    x_32_3    unique_nonzero_owner_402  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_3    product_lb_198  1
    w_32_3    product_ub_199  1
    w_32_3    normalized_mass_32_219  1
    w_32_3    normalized_ratio_32_220  -6.0000000000000009e-01
    w_32_3    full_original_Gini_318  -7.9039682539682516e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_4    OBJ       -1.8750000000000010e-02
    x_32_4    product_lb_200  -2.4658499354157495e-02
    x_32_4    product_ub_201  -4.2187029162663148e-02
    x_32_4    onehot_32_218  1
    x_32_4    stock_lb_258  4
    x_32_4    stock_ub_259  4
    x_32_4    parent_nonstrict_scope_260  7.4999999999999980e-03
    x_32_4    unique_nonzero_owner_403  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_4    product_lb_200  1
    w_32_4    product_ub_201  1
    w_32_4    normalized_mass_32_219  1
    w_32_4    normalized_ratio_32_220  -0.8
    w_32_4    full_original_Gini_318  -4.6468253968253972e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_5    OBJ       -2.6250000000000006e-02
    x_32_5    product_lb_202  -2.4658499354157495e-02
    x_32_5    product_ub_203  -4.2187029162663148e-02
    x_32_5    onehot_32_218  1
    x_32_5    stock_lb_258  5
    x_32_5    stock_ub_259  5
    x_32_5    unique_nonzero_owner_404  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_5    product_lb_202  1
    w_32_5    product_ub_203  1
    w_32_5    normalized_mass_32_219  1
    w_32_5    normalized_ratio_32_220  -1
    w_32_5    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_6    OBJ       -0.01875
    x_32_6    product_lb_204  -2.4658499354157495e-02
    x_32_6    product_ub_205  -4.2187029162663148e-02
    x_32_6    onehot_32_218  1
    x_32_6    stock_lb_258  6
    x_32_6    stock_ub_259  6
    x_32_6    parent_nonstrict_scope_260  7.5000000000000067e-03
    x_32_6    unique_nonzero_owner_405  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_6    product_lb_204  1
    w_32_6    product_ub_205  1
    w_32_6    normalized_mass_32_219  1
    w_32_6    normalized_ratio_32_220  -1.2000000000000002e+00
    w_32_6    full_original_Gini_318  -8.7960317460317512e+00
    MARKER    'MARKER'                 'INTORG'
    x_32_7    OBJ       -1.1250000000000001e-02
    x_32_7    product_lb_206  -2.4658499354157495e-02
    x_32_7    product_ub_207  -4.2187029162663148e-02
    x_32_7    onehot_32_218  1
    x_32_7    stock_lb_258  7
    x_32_7    stock_ub_259  7
    x_32_7    parent_nonstrict_scope_260  1.5000000000000005e-02
    x_32_7    unique_nonzero_owner_406  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_7    product_lb_206  1
    w_32_7    product_ub_207  1
    w_32_7    normalized_mass_32_219  1
    w_32_7    normalized_ratio_32_220  -1.4000000000000001e+00
    w_32_7    full_original_Gini_318  -1.4096031746031754e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_8    OBJ       -3.7500000000000033e-03
    x_32_8    product_lb_208  -2.4658499354157495e-02
    x_32_8    product_ub_209  -4.2187029162663148e-02
    x_32_8    onehot_32_218  1
    x_32_8    stock_lb_258  8
    x_32_8    stock_ub_259  8
    x_32_8    parent_nonstrict_scope_260  2.2500000000000003e-02
    x_32_8    unique_nonzero_owner_407  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_8    product_lb_208  1
    w_32_8    product_ub_209  1
    w_32_8    normalized_mass_32_219  1
    w_32_8    normalized_ratio_32_220  -1.6
    w_32_8    full_original_Gini_318  -1.9496031746031754e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_9    OBJ       3.7499999999999929e-03
    x_32_9    product_lb_210  -2.4658499354157495e-02
    x_32_9    product_ub_211  -4.2187029162663148e-02
    x_32_9    onehot_32_218  1
    x_32_9    stock_lb_258  9
    x_32_9    stock_ub_259  9
    x_32_9    parent_nonstrict_scope_260  0.03
    x_32_9    unique_nonzero_owner_408  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_9    product_lb_210  1
    w_32_9    product_ub_211  1
    w_32_9    normalized_mass_32_219  1
    w_32_9    normalized_ratio_32_220  -1.8
    w_32_9    full_original_Gini_318  -2.4896031746031753e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_10   OBJ       1.1249999999999993e-02
    x_32_10   product_lb_212  -2.4658499354157495e-02
    x_32_10   product_ub_213  -4.2187029162663148e-02
    x_32_10   onehot_32_218  1
    x_32_10   stock_lb_258  10
    x_32_10   stock_ub_259  10
    x_32_10   parent_nonstrict_scope_260  0.0375
    x_32_10   unique_nonzero_owner_409  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_10   product_lb_212  1
    w_32_10   product_ub_213  1
    w_32_10   normalized_mass_32_219  1
    w_32_10   normalized_ratio_32_220  -2
    w_32_10   full_original_Gini_318  -3.0296031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_11   OBJ       0.01875
    x_32_11   product_lb_214  -2.4658499354157495e-02
    x_32_11   product_ub_215  -4.2187029162663148e-02
    x_32_11   onehot_32_218  1
    x_32_11   stock_lb_258  11
    x_32_11   stock_ub_259  11
    x_32_11   parent_nonstrict_scope_260  4.5000000000000005e-02
    x_32_11   unique_nonzero_owner_410  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_11   product_lb_214  1
    w_32_11   product_ub_215  1
    w_32_11   normalized_mass_32_219  1
    w_32_11   normalized_ratio_32_220  -2.2
    w_32_11   full_original_Gini_318  -3.5696031746031743e+01
    MARKER    'MARKER'                 'INTORG'
    x_32_12   OBJ       2.6250000000000006e-02
    x_32_12   product_lb_216  -2.4658499354157495e-02
    x_32_12   product_ub_217  -4.2187029162663148e-02
    x_32_12   onehot_32_218  1
    x_32_12   stock_lb_258  12
    x_32_12   stock_ub_259  12
    x_32_12   parent_nonstrict_scope_260  5.2500000000000012e-02
    x_32_12   unique_nonzero_owner_411  -1
    MARKER    'MARKER'                 'INTEND'
    w_32_12   product_lb_216  1
    w_32_12   product_ub_217  1
    w_32_12   normalized_mass_32_219  1
    w_32_12   normalized_ratio_32_220  -2.4000000000000004e+00
    w_32_12   full_original_Gini_318  -4.1096031746031741e+01
    rho_32    normalized_ratio_32_220  1
    rho_32    block_pair_pos_263  1
    rho_32    block_pair_neg_264  -1
    rho_32    block_pair_pos_267  1
    rho_32    block_pair_neg_268  -1
    rho_32    block_pair_pos_275  1
    rho_32    block_pair_neg_276  -1
    rho_32    block_pair_pos_287  1
    rho_32    block_pair_neg_288  -1
    rho_32    block_pair_pos_301  1
    rho_32    block_pair_neg_302  -1
    rho_32    block_pair_pos_311  1
    rho_32    block_pair_neg_312  -1
    rho_32    block_pair_pos_315  -1
    rho_32    block_pair_neg_316  1
    rho_32    normalization_317  1
    MARKER    'MARKER'                 'INTORG'
    x_33_0    OBJ       2.6250000000000002e-02
    x_33_0    product_lb_221  -2.4658499354157495e-02
    x_33_0    product_ub_222  -4.2187029162663148e-02
    x_33_0    onehot_33_255  1
    x_33_0    parent_nonstrict_scope_260  0.0735
    x_33_0    unique_nonzero_owner_412  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_0    product_lb_221  1
    w_33_0    product_ub_222  1
    w_33_0    normalized_mass_33_256  1
    w_33_0    full_original_Gini_318  -2.3703968253968256e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_1    OBJ       1.5750000000000007e-02
    x_33_1    product_lb_223  -2.4658499354157495e-02
    x_33_1    product_ub_224  -4.2187029162663148e-02
    x_33_1    onehot_33_255  1
    x_33_1    stock_lb_258  1
    x_33_1    stock_ub_259  1
    x_33_1    parent_nonstrict_scope_260  0.063
    MARKER    'MARKER'                 'INTEND'
    w_33_1    product_lb_223  1
    w_33_1    product_ub_224  1
    w_33_1    normalized_mass_33_256  1
    w_33_1    normalized_ratio_33_257  -1.4285714285714285e-01
    w_33_1    full_original_Gini_318  -1.9846825396825402e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_2    OBJ       5.2500000000000047e-03
    x_33_2    product_lb_225  -2.4658499354157495e-02
    x_33_2    product_ub_226  -4.2187029162663148e-02
    x_33_2    onehot_33_255  1
    x_33_2    stock_lb_258  2
    x_33_2    stock_ub_259  2
    x_33_2    parent_nonstrict_scope_260  0.0525
    x_33_2    unique_nonzero_owner_413  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_2    product_lb_225  1
    w_33_2    product_ub_226  1
    w_33_2    normalized_mass_33_256  1
    w_33_2    normalized_ratio_33_257  -2.8571428571428570e-01
    w_33_2    full_original_Gini_318  -1.5989682539682534e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_3    OBJ       -5.2499999999999977e-03
    x_33_3    product_lb_227  -2.4658499354157495e-02
    x_33_3    product_ub_228  -4.2187029162663148e-02
    x_33_3    onehot_33_255  1
    x_33_3    stock_lb_258  3
    x_33_3    stock_ub_259  3
    x_33_3    parent_nonstrict_scope_260  4.1999999999999996e-02
    x_33_3    unique_nonzero_owner_414  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_3    product_lb_227  1
    w_33_3    product_ub_228  1
    w_33_3    normalized_mass_33_256  1
    w_33_3    normalized_ratio_33_257  -4.2857142857142855e-01
    w_33_3    full_original_Gini_318  -1.2132539682539681e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_4    OBJ       -1.5749999999999993e-02
    x_33_4    product_lb_229  -2.4658499354157495e-02
    x_33_4    product_ub_230  -4.2187029162663148e-02
    x_33_4    onehot_33_255  1
    x_33_4    stock_lb_258  4
    x_33_4    stock_ub_259  4
    x_33_4    parent_nonstrict_scope_260  0.0315
    x_33_4    unique_nonzero_owner_415  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_4    product_lb_229  1
    w_33_4    product_ub_230  1
    w_33_4    normalized_mass_33_256  1
    w_33_4    normalized_ratio_33_257  -5.7142857142857140e-01
    w_33_4    full_original_Gini_318  -8.5611111111111118e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_5    OBJ       -2.6249999999999989e-02
    x_33_5    product_lb_231  -2.4658499354157495e-02
    x_33_5    product_ub_232  -4.2187029162663148e-02
    x_33_5    onehot_33_255  1
    x_33_5    stock_lb_258  5
    x_33_5    stock_ub_259  5
    x_33_5    parent_nonstrict_scope_260  2.1000000000000005e-02
    x_33_5    unique_nonzero_owner_416  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_5    product_lb_231  1
    w_33_5    product_ub_232  1
    w_33_5    normalized_mass_33_256  1
    w_33_5    normalized_ratio_33_257  -7.1428571428571419e-01
    w_33_5    full_original_Gini_318  -5.7325396825396826e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_6    OBJ       -3.6749999999999991e-02
    x_33_6    product_lb_233  -2.4658499354157495e-02
    x_33_6    product_ub_234  -4.2187029162663148e-02
    x_33_6    onehot_33_255  1
    x_33_6    stock_lb_258  6
    x_33_6    stock_ub_259  6
    x_33_6    parent_nonstrict_scope_260  1.0500000000000002e-02
    x_33_6    unique_nonzero_owner_417  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_6    product_lb_233  1
    w_33_6    product_ub_234  1
    w_33_6    normalized_mass_33_256  1
    w_33_6    normalized_ratio_33_257  -8.5714285714285710e-01
    w_33_6    full_original_Gini_318  -4.0658730158730156e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_7    OBJ       -4.7249999999999993e-02
    x_33_7    product_lb_235  -2.4658499354157495e-02
    x_33_7    product_ub_236  -4.2187029162663148e-02
    x_33_7    onehot_33_255  1
    x_33_7    stock_lb_258  7
    x_33_7    stock_ub_259  7
    x_33_7    unique_nonzero_owner_418  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_7    product_lb_235  1
    w_33_7    product_ub_236  1
    w_33_7    normalized_mass_33_256  1
    w_33_7    normalized_ratio_33_257  -1
    w_33_7    full_original_Gini_318  -3.7960317460317463e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_8    OBJ       -0.03675
    x_33_8    product_lb_237  -2.4658499354157495e-02
    x_33_8    product_ub_238  -4.2187029162663148e-02
    x_33_8    onehot_33_255  1
    x_33_8    stock_lb_258  8
    x_33_8    stock_ub_259  8
    x_33_8    parent_nonstrict_scope_260  1.0499999999999995e-02
    x_33_8    unique_nonzero_owner_419  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_8    product_lb_237  1
    w_33_8    product_ub_238  1
    w_33_8    normalized_mass_33_256  1
    w_33_8    normalized_ratio_33_257  -1.1428571428571428e+00
    w_33_8    full_original_Gini_318  -7.3674603174603153e+00
    MARKER    'MARKER'                 'INTORG'
    x_33_9    OBJ       -2.6250000000000002e-02
    x_33_9    product_lb_239  -2.4658499354157495e-02
    x_33_9    product_ub_240  -4.2187029162663148e-02
    x_33_9    onehot_33_255  1
    x_33_9    stock_lb_258  9
    x_33_9    stock_ub_259  9
    x_33_9    parent_nonstrict_scope_260  2.0999999999999991e-02
    x_33_9    unique_nonzero_owner_420  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_9    product_lb_239  1
    w_33_9    product_ub_240  1
    w_33_9    normalized_mass_33_256  1
    w_33_9    normalized_ratio_33_257  -1.2857142857142856e+00
    w_33_9    full_original_Gini_318  -1.1010317460317456e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_10   OBJ       -1.5750000000000007e-02
    x_33_10   product_lb_241  -2.4658499354157495e-02
    x_33_10   product_ub_242  -4.2187029162663148e-02
    x_33_10   onehot_33_255  1
    x_33_10   stock_lb_258  10
    x_33_10   stock_ub_259  10
    x_33_10   parent_nonstrict_scope_260  3.1499999999999986e-02
    x_33_10   unique_nonzero_owner_421  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_10   product_lb_241  1
    w_33_10   product_ub_242  1
    w_33_10   normalized_mass_33_256  1
    w_33_10   normalized_ratio_33_257  -1.4285714285714284e+00
    w_33_10   full_original_Gini_318  -1.4867460317460315e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_11   OBJ       -5.2499999999999977e-03
    x_33_11   product_lb_243  -2.4658499354157495e-02
    x_33_11   product_ub_244  -4.2187029162663148e-02
    x_33_11   onehot_33_255  1
    x_33_11   stock_lb_258  11
    x_33_11   stock_ub_259  11
    x_33_11   parent_nonstrict_scope_260  4.1999999999999996e-02
    x_33_11   unique_nonzero_owner_422  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_11   product_lb_243  1
    w_33_11   product_ub_244  1
    w_33_11   normalized_mass_33_256  1
    w_33_11   normalized_ratio_33_257  -1.5714285714285714e+00
    w_33_11   full_original_Gini_318  -1.8724603174603178e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_12   OBJ       5.2499999999999977e-03
    x_33_12   product_lb_245  -2.4658499354157495e-02
    x_33_12   product_ub_246  -4.2187029162663148e-02
    x_33_12   onehot_33_255  1
    x_33_12   stock_lb_258  12
    x_33_12   stock_ub_259  12
    x_33_12   parent_nonstrict_scope_260  5.2499999999999991e-02
    x_33_12   unique_nonzero_owner_423  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_12   product_lb_245  1
    w_33_12   product_ub_246  1
    w_33_12   normalized_mass_33_256  1
    w_33_12   normalized_ratio_33_257  -1.7142857142857142e+00
    w_33_12   full_original_Gini_318  -2.2581746031746032e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_13   OBJ       1.5749999999999993e-02
    x_33_13   product_lb_247  -2.4658499354157495e-02
    x_33_13   product_ub_248  -4.2187029162663148e-02
    x_33_13   onehot_33_255  1
    x_33_13   stock_lb_258  13
    x_33_13   stock_ub_259  13
    x_33_13   parent_nonstrict_scope_260  6.2999999999999987e-02
    x_33_13   unique_nonzero_owner_424  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_13   product_lb_247  1
    w_33_13   product_ub_248  1
    w_33_13   normalized_mass_33_256  1
    w_33_13   normalized_ratio_33_257  -1.8571428571428570e+00
    w_33_13   full_original_Gini_318  -2.6438888888888890e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_14   OBJ       2.6250000000000002e-02
    x_33_14   product_lb_249  -2.4658499354157495e-02
    x_33_14   product_ub_250  -4.2187029162663148e-02
    x_33_14   onehot_33_255  1
    x_33_14   stock_lb_258  14
    x_33_14   stock_ub_259  14
    x_33_14   parent_nonstrict_scope_260  0.0735
    x_33_14   unique_nonzero_owner_425  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_14   product_lb_249  1
    w_33_14   product_ub_250  1
    w_33_14   normalized_mass_33_256  1
    w_33_14   normalized_ratio_33_257  -2
    w_33_14   full_original_Gini_318  -3.0296031746031744e+01
    MARKER    'MARKER'                 'INTORG'
    x_33_15   OBJ       0.03675
    x_33_15   product_lb_251  -2.4658499354157495e-02
    x_33_15   product_ub_252  -4.2187029162663148e-02
    x_33_15   onehot_33_255  1
    x_33_15   stock_lb_258  15
    x_33_15   stock_ub_259  15
    x_33_15   parent_nonstrict_scope_260  8.3999999999999991e-02
    x_33_15   unique_nonzero_owner_426  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_15   product_lb_251  1
    w_33_15   product_ub_252  1
    w_33_15   normalized_mass_33_256  1
    w_33_15   normalized_ratio_33_257  -2.1428571428571428e+00
    w_33_15   full_original_Gini_318  -34.1531746031746
    MARKER    'MARKER'                 'INTORG'
    x_33_16   OBJ       4.7249999999999993e-02
    x_33_16   product_lb_253  -2.4658499354157495e-02
    x_33_16   product_ub_254  -4.2187029162663148e-02
    x_33_16   onehot_33_255  1
    x_33_16   stock_lb_258  16
    x_33_16   stock_ub_259  16
    x_33_16   parent_nonstrict_scope_260  9.4499999999999987e-02
    x_33_16   unique_nonzero_owner_427  -1
    MARKER    'MARKER'                 'INTEND'
    w_33_16   product_lb_253  1
    w_33_16   product_ub_254  1
    w_33_16   normalized_mass_33_256  1
    w_33_16   normalized_ratio_33_257  -2.2857142857142856e+00
    w_33_16   full_original_Gini_318  -3.8010317460317445e+01
    rho_33    normalized_ratio_33_257  1
    rho_33    block_pair_pos_265  1
    rho_33    block_pair_neg_266  -1
    rho_33    block_pair_pos_269  1
    rho_33    block_pair_neg_270  -1
    rho_33    block_pair_pos_277  1
    rho_33    block_pair_neg_278  -1
    rho_33    block_pair_pos_289  1
    rho_33    block_pair_neg_290  -1
    rho_33    block_pair_pos_303  1
    rho_33    block_pair_neg_304  -1
    rho_33    block_pair_pos_313  1
    rho_33    block_pair_neg_314  -1
    rho_33    block_pair_pos_315  1
    rho_33    block_pair_neg_316  -1
    rho_33    normalization_317  1
    a_28_23   block_pair_pos_297  1
    a_28_23   block_pair_neg_298  1
    a_28_23   full_original_Gini_318  -1
    a_28_31   block_pair_pos_299  1
    a_28_31   block_pair_neg_300  1
    a_28_31   full_original_Gini_318  -1
    a_28_21   block_pair_pos_295  1
    a_28_21   block_pair_neg_296  1
    a_28_21   full_original_Gini_318  -1
    a_28_16   block_pair_pos_291  1
    a_28_16   block_pair_neg_292  1
    a_28_16   full_original_Gini_318  -1
    a_28_20   block_pair_pos_293  1
    a_28_20   block_pair_neg_294  1
    a_28_20   full_original_Gini_318  -1
    a_28_32   block_pair_pos_301  1
    a_28_32   block_pair_neg_302  1
    a_28_32   full_original_Gini_318  -1
    a_28_33   block_pair_pos_303  1
    a_28_33   block_pair_neg_304  1
    a_28_33   full_original_Gini_318  -1
    a_23_31   block_pair_pos_285  1
    a_23_31   block_pair_neg_286  1
    a_23_31   full_original_Gini_318  -1
    a_23_21   block_pair_pos_283  1
    a_23_21   block_pair_neg_284  1
    a_23_21   full_original_Gini_318  -1
    a_23_16   block_pair_pos_279  1
    a_23_16   block_pair_neg_280  1
    a_23_16   full_original_Gini_318  -1
    a_23_20   block_pair_pos_281  1
    a_23_20   block_pair_neg_282  1
    a_23_20   full_original_Gini_318  -1
    a_23_32   block_pair_pos_287  1
    a_23_32   block_pair_neg_288  1
    a_23_32   full_original_Gini_318  -1
    a_23_33   block_pair_pos_289  1
    a_23_33   block_pair_neg_290  1
    a_23_33   full_original_Gini_318  -1
    a_31_21   block_pair_pos_309  1
    a_31_21   block_pair_neg_310  1
    a_31_21   full_original_Gini_318  -1
    a_31_16   block_pair_pos_305  1
    a_31_16   block_pair_neg_306  1
    a_31_16   full_original_Gini_318  -1
    a_31_20   block_pair_pos_307  1
    a_31_20   block_pair_neg_308  1
    a_31_20   full_original_Gini_318  -1
    a_31_32   block_pair_pos_311  1
    a_31_32   block_pair_neg_312  1
    a_31_32   full_original_Gini_318  -1
    a_31_33   block_pair_pos_313  1
    a_31_33   block_pair_neg_314  1
    a_31_33   full_original_Gini_318  -1
    a_21_16   block_pair_pos_271  1
    a_21_16   block_pair_neg_272  1
    a_21_16   full_original_Gini_318  -1
    a_21_20   block_pair_pos_273  1
    a_21_20   block_pair_neg_274  1
    a_21_20   full_original_Gini_318  -1
    a_21_32   block_pair_pos_275  1
    a_21_32   block_pair_neg_276  1
    a_21_32   full_original_Gini_318  -1
    a_21_33   block_pair_pos_277  1
    a_21_33   block_pair_neg_278  1
    a_21_33   full_original_Gini_318  -1
    a_16_20   block_pair_pos_261  1
    a_16_20   block_pair_neg_262  1
    a_16_20   full_original_Gini_318  -1
    a_16_32   block_pair_pos_263  1
    a_16_32   block_pair_neg_264  1
    a_16_32   full_original_Gini_318  -1
    a_16_33   block_pair_pos_265  1
    a_16_33   block_pair_neg_266  1
    a_16_33   full_original_Gini_318  -1
    a_20_32   block_pair_pos_267  1
    a_20_32   block_pair_neg_268  1
    a_20_32   full_original_Gini_318  -1
    a_20_33   block_pair_pos_269  1
    a_20_33   block_pair_neg_270  1
    a_20_33   full_original_Gini_318  -1
    a_32_33   block_pair_pos_315  1
    a_32_33   block_pair_neg_316  1
    a_32_33   full_original_Gini_318  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_28_0  unique_nonzero_owner_319  1
    service_0_28_0  service_visit_def_751  1
    service_0_28_0  free_load_conservation_752  -13
    service_0_28_0  original_T_including_depot_unload_798  1560
    service_0_28_1  unique_nonzero_owner_320  1
    service_0_28_1  service_visit_def_751  1
    service_0_28_1  free_load_conservation_752  -12
    service_0_28_1  original_T_including_depot_unload_798  1440
    service_0_28_2  unique_nonzero_owner_321  1
    service_0_28_2  service_visit_def_751  1
    service_0_28_2  free_load_conservation_752  -11
    service_0_28_2  original_T_including_depot_unload_798  1320
    service_0_28_3  unique_nonzero_owner_322  1
    service_0_28_3  service_visit_def_751  1
    service_0_28_3  free_load_conservation_752  -10
    service_0_28_3  original_T_including_depot_unload_798  1200
    service_0_28_4  unique_nonzero_owner_323  1
    service_0_28_4  service_visit_def_751  1
    service_0_28_4  free_load_conservation_752  -9
    service_0_28_4  original_T_including_depot_unload_798  1080
    service_0_28_5  unique_nonzero_owner_324  1
    service_0_28_5  service_visit_def_751  1
    service_0_28_5  free_load_conservation_752  -8
    service_0_28_5  original_T_including_depot_unload_798  960
    service_0_28_6  unique_nonzero_owner_325  1
    service_0_28_6  service_visit_def_751  1
    service_0_28_6  free_load_conservation_752  -7
    service_0_28_6  original_T_including_depot_unload_798  840
    service_0_28_7  unique_nonzero_owner_326  1
    service_0_28_7  service_visit_def_751  1
    service_0_28_7  free_load_conservation_752  -6
    service_0_28_7  original_T_including_depot_unload_798  720
    service_0_28_8  unique_nonzero_owner_327  1
    service_0_28_8  service_visit_def_751  1
    service_0_28_8  free_load_conservation_752  -5
    service_0_28_8  original_T_including_depot_unload_798  600
    service_0_28_9  unique_nonzero_owner_328  1
    service_0_28_9  service_visit_def_751  1
    service_0_28_9  free_load_conservation_752  -4
    service_0_28_9  original_T_including_depot_unload_798  480
    service_0_28_10  unique_nonzero_owner_329  1
    service_0_28_10  service_visit_def_751  1
    service_0_28_10  free_load_conservation_752  -3
    service_0_28_10  original_T_including_depot_unload_798  360
    service_0_28_11  unique_nonzero_owner_330  1
    service_0_28_11  service_visit_def_751  1
    service_0_28_11  free_load_conservation_752  -2
    service_0_28_11  original_T_including_depot_unload_798  240
    service_0_28_12  unique_nonzero_owner_331  1
    service_0_28_12  service_visit_def_751  1
    service_0_28_12  free_load_conservation_752  -1
    service_0_28_12  original_T_including_depot_unload_798  120
    service_0_28_14  unique_nonzero_owner_332  1
    service_0_28_14  service_visit_def_751  1
    service_0_28_14  free_load_conservation_752  1
    service_0_28_15  unique_nonzero_owner_333  1
    service_0_28_15  service_visit_def_751  1
    service_0_28_15  free_load_conservation_752  2
    service_0_28_16  unique_nonzero_owner_334  1
    service_0_28_16  service_visit_def_751  1
    service_0_28_16  free_load_conservation_752  3
    service_0_28_17  unique_nonzero_owner_335  1
    service_0_28_17  service_visit_def_751  1
    service_0_28_17  free_load_conservation_752  4
    service_0_28_18  unique_nonzero_owner_336  1
    service_0_28_18  service_visit_def_751  1
    service_0_28_18  free_load_conservation_752  5
    service_0_28_19  unique_nonzero_owner_337  1
    service_0_28_19  service_visit_def_751  1
    service_0_28_19  free_load_conservation_752  6
    service_1_28_0  unique_nonzero_owner_319  1
    service_1_28_0  service_visit_def_1179  1
    service_1_28_0  free_load_conservation_1180  -13
    service_1_28_0  original_T_including_depot_unload_1227  1560
    service_1_28_1  unique_nonzero_owner_320  1
    service_1_28_1  service_visit_def_1179  1
    service_1_28_1  free_load_conservation_1180  -12
    service_1_28_1  original_T_including_depot_unload_1227  1440
    service_1_28_2  unique_nonzero_owner_321  1
    service_1_28_2  service_visit_def_1179  1
    service_1_28_2  free_load_conservation_1180  -11
    service_1_28_2  original_T_including_depot_unload_1227  1320
    service_1_28_3  unique_nonzero_owner_322  1
    service_1_28_3  service_visit_def_1179  1
    service_1_28_3  free_load_conservation_1180  -10
    service_1_28_3  original_T_including_depot_unload_1227  1200
    service_1_28_4  unique_nonzero_owner_323  1
    service_1_28_4  service_visit_def_1179  1
    service_1_28_4  free_load_conservation_1180  -9
    service_1_28_4  original_T_including_depot_unload_1227  1080
    service_1_28_5  unique_nonzero_owner_324  1
    service_1_28_5  service_visit_def_1179  1
    service_1_28_5  free_load_conservation_1180  -8
    service_1_28_5  original_T_including_depot_unload_1227  960
    service_1_28_6  unique_nonzero_owner_325  1
    service_1_28_6  service_visit_def_1179  1
    service_1_28_6  free_load_conservation_1180  -7
    service_1_28_6  original_T_including_depot_unload_1227  840
    service_1_28_7  unique_nonzero_owner_326  1
    service_1_28_7  service_visit_def_1179  1
    service_1_28_7  free_load_conservation_1180  -6
    service_1_28_7  original_T_including_depot_unload_1227  720
    service_1_28_8  unique_nonzero_owner_327  1
    service_1_28_8  service_visit_def_1179  1
    service_1_28_8  free_load_conservation_1180  -5
    service_1_28_8  original_T_including_depot_unload_1227  600
    service_1_28_9  unique_nonzero_owner_328  1
    service_1_28_9  service_visit_def_1179  1
    service_1_28_9  free_load_conservation_1180  -4
    service_1_28_9  original_T_including_depot_unload_1227  480
    service_1_28_10  unique_nonzero_owner_329  1
    service_1_28_10  service_visit_def_1179  1
    service_1_28_10  free_load_conservation_1180  -3
    service_1_28_10  original_T_including_depot_unload_1227  360
    service_1_28_11  unique_nonzero_owner_330  1
    service_1_28_11  service_visit_def_1179  1
    service_1_28_11  free_load_conservation_1180  -2
    service_1_28_11  original_T_including_depot_unload_1227  240
    service_1_28_12  unique_nonzero_owner_331  1
    service_1_28_12  service_visit_def_1179  1
    service_1_28_12  free_load_conservation_1180  -1
    service_1_28_12  original_T_including_depot_unload_1227  120
    service_1_28_14  unique_nonzero_owner_332  1
    service_1_28_14  service_visit_def_1179  1
    service_1_28_14  free_load_conservation_1180  1
    service_1_28_15  unique_nonzero_owner_333  1
    service_1_28_15  service_visit_def_1179  1
    service_1_28_15  free_load_conservation_1180  2
    service_1_28_16  unique_nonzero_owner_334  1
    service_1_28_16  service_visit_def_1179  1
    service_1_28_16  free_load_conservation_1180  3
    service_1_28_17  unique_nonzero_owner_335  1
    service_1_28_17  service_visit_def_1179  1
    service_1_28_17  free_load_conservation_1180  4
    service_1_28_18  unique_nonzero_owner_336  1
    service_1_28_18  service_visit_def_1179  1
    service_1_28_18  free_load_conservation_1180  5
    service_1_28_19  unique_nonzero_owner_337  1
    service_1_28_19  service_visit_def_1179  1
    service_1_28_19  free_load_conservation_1180  6
    service_2_28_0  unique_nonzero_owner_319  1
    service_2_28_0  service_visit_def_1551  1
    service_2_28_0  free_load_conservation_1552  -13
    service_2_28_0  original_T_including_depot_unload_1598  1560
    service_2_28_1  unique_nonzero_owner_320  1
    service_2_28_1  service_visit_def_1551  1
    service_2_28_1  free_load_conservation_1552  -12
    service_2_28_1  original_T_including_depot_unload_1598  1440
    service_2_28_2  unique_nonzero_owner_321  1
    service_2_28_2  service_visit_def_1551  1
    service_2_28_2  free_load_conservation_1552  -11
    service_2_28_2  original_T_including_depot_unload_1598  1320
    service_2_28_3  unique_nonzero_owner_322  1
    service_2_28_3  service_visit_def_1551  1
    service_2_28_3  free_load_conservation_1552  -10
    service_2_28_3  original_T_including_depot_unload_1598  1200
    service_2_28_4  unique_nonzero_owner_323  1
    service_2_28_4  service_visit_def_1551  1
    service_2_28_4  free_load_conservation_1552  -9
    service_2_28_4  original_T_including_depot_unload_1598  1080
    service_2_28_5  unique_nonzero_owner_324  1
    service_2_28_5  service_visit_def_1551  1
    service_2_28_5  free_load_conservation_1552  -8
    service_2_28_5  original_T_including_depot_unload_1598  960
    service_2_28_6  unique_nonzero_owner_325  1
    service_2_28_6  service_visit_def_1551  1
    service_2_28_6  free_load_conservation_1552  -7
    service_2_28_6  original_T_including_depot_unload_1598  840
    service_2_28_7  unique_nonzero_owner_326  1
    service_2_28_7  service_visit_def_1551  1
    service_2_28_7  free_load_conservation_1552  -6
    service_2_28_7  original_T_including_depot_unload_1598  720
    service_2_28_8  unique_nonzero_owner_327  1
    service_2_28_8  service_visit_def_1551  1
    service_2_28_8  free_load_conservation_1552  -5
    service_2_28_8  original_T_including_depot_unload_1598  600
    service_2_28_9  unique_nonzero_owner_328  1
    service_2_28_9  service_visit_def_1551  1
    service_2_28_9  free_load_conservation_1552  -4
    service_2_28_9  original_T_including_depot_unload_1598  480
    service_2_28_10  unique_nonzero_owner_329  1
    service_2_28_10  service_visit_def_1551  1
    service_2_28_10  free_load_conservation_1552  -3
    service_2_28_10  original_T_including_depot_unload_1598  360
    service_2_28_11  unique_nonzero_owner_330  1
    service_2_28_11  service_visit_def_1551  1
    service_2_28_11  free_load_conservation_1552  -2
    service_2_28_11  original_T_including_depot_unload_1598  240
    service_2_28_12  unique_nonzero_owner_331  1
    service_2_28_12  service_visit_def_1551  1
    service_2_28_12  free_load_conservation_1552  -1
    service_2_28_12  original_T_including_depot_unload_1598  120
    service_2_28_14  unique_nonzero_owner_332  1
    service_2_28_14  service_visit_def_1551  1
    service_2_28_14  free_load_conservation_1552  1
    service_2_28_15  unique_nonzero_owner_333  1
    service_2_28_15  service_visit_def_1551  1
    service_2_28_15  free_load_conservation_1552  2
    service_2_28_16  unique_nonzero_owner_334  1
    service_2_28_16  service_visit_def_1551  1
    service_2_28_16  free_load_conservation_1552  3
    service_2_28_17  unique_nonzero_owner_335  1
    service_2_28_17  service_visit_def_1551  1
    service_2_28_17  free_load_conservation_1552  4
    service_2_28_18  unique_nonzero_owner_336  1
    service_2_28_18  service_visit_def_1551  1
    service_2_28_18  free_load_conservation_1552  5
    service_2_28_19  unique_nonzero_owner_337  1
    service_2_28_19  service_visit_def_1551  1
    service_2_28_19  free_load_conservation_1552  6
    service_0_23_0  unique_nonzero_owner_338  1
    service_0_23_0  service_visit_def_757  1
    service_0_23_0  free_load_conservation_758  -7
    service_0_23_0  original_T_including_depot_unload_798  840
    service_0_23_1  unique_nonzero_owner_339  1
    service_0_23_1  service_visit_def_757  1
    service_0_23_1  free_load_conservation_758  -6
    service_0_23_1  original_T_including_depot_unload_798  720
    service_0_23_2  unique_nonzero_owner_340  1
    service_0_23_2  service_visit_def_757  1
    service_0_23_2  free_load_conservation_758  -5
    service_0_23_2  original_T_including_depot_unload_798  600
    service_0_23_3  unique_nonzero_owner_341  1
    service_0_23_3  service_visit_def_757  1
    service_0_23_3  free_load_conservation_758  -4
    service_0_23_3  original_T_including_depot_unload_798  480
    service_0_23_4  unique_nonzero_owner_342  1
    service_0_23_4  service_visit_def_757  1
    service_0_23_4  free_load_conservation_758  -3
    service_0_23_4  original_T_including_depot_unload_798  360
    service_0_23_5  unique_nonzero_owner_343  1
    service_0_23_5  service_visit_def_757  1
    service_0_23_5  free_load_conservation_758  -2
    service_0_23_5  original_T_including_depot_unload_798  240
    service_0_23_6  unique_nonzero_owner_344  1
    service_0_23_6  service_visit_def_757  1
    service_0_23_6  free_load_conservation_758  -1
    service_0_23_6  original_T_including_depot_unload_798  120
    service_0_23_8  unique_nonzero_owner_345  1
    service_0_23_8  service_visit_def_757  1
    service_0_23_8  free_load_conservation_758  1
    service_0_23_9  unique_nonzero_owner_346  1
    service_0_23_9  service_visit_def_757  1
    service_0_23_9  free_load_conservation_758  2
    service_0_23_10  unique_nonzero_owner_347  1
    service_0_23_10  service_visit_def_757  1
    service_0_23_10  free_load_conservation_758  3
    service_0_23_11  unique_nonzero_owner_348  1
    service_0_23_11  service_visit_def_757  1
    service_0_23_11  free_load_conservation_758  4
    service_1_23_0  unique_nonzero_owner_338  1
    service_1_23_0  service_visit_def_1185  1
    service_1_23_0  free_load_conservation_1186  -7
    service_1_23_0  original_T_including_depot_unload_1227  840
    service_1_23_1  unique_nonzero_owner_339  1
    service_1_23_1  service_visit_def_1185  1
    service_1_23_1  free_load_conservation_1186  -6
    service_1_23_1  original_T_including_depot_unload_1227  720
    service_1_23_2  unique_nonzero_owner_340  1
    service_1_23_2  service_visit_def_1185  1
    service_1_23_2  free_load_conservation_1186  -5
    service_1_23_2  original_T_including_depot_unload_1227  600
    service_1_23_3  unique_nonzero_owner_341  1
    service_1_23_3  service_visit_def_1185  1
    service_1_23_3  free_load_conservation_1186  -4
    service_1_23_3  original_T_including_depot_unload_1227  480
    service_1_23_4  unique_nonzero_owner_342  1
    service_1_23_4  service_visit_def_1185  1
    service_1_23_4  free_load_conservation_1186  -3
    service_1_23_4  original_T_including_depot_unload_1227  360
    service_1_23_5  unique_nonzero_owner_343  1
    service_1_23_5  service_visit_def_1185  1
    service_1_23_5  free_load_conservation_1186  -2
    service_1_23_5  original_T_including_depot_unload_1227  240
    service_1_23_6  unique_nonzero_owner_344  1
    service_1_23_6  service_visit_def_1185  1
    service_1_23_6  free_load_conservation_1186  -1
    service_1_23_6  original_T_including_depot_unload_1227  120
    service_1_23_8  unique_nonzero_owner_345  1
    service_1_23_8  service_visit_def_1185  1
    service_1_23_8  free_load_conservation_1186  1
    service_1_23_9  unique_nonzero_owner_346  1
    service_1_23_9  service_visit_def_1185  1
    service_1_23_9  free_load_conservation_1186  2
    service_1_23_10  unique_nonzero_owner_347  1
    service_1_23_10  service_visit_def_1185  1
    service_1_23_10  free_load_conservation_1186  3
    service_1_23_11  unique_nonzero_owner_348  1
    service_1_23_11  service_visit_def_1185  1
    service_1_23_11  free_load_conservation_1186  4
    service_2_23_0  unique_nonzero_owner_338  1
    service_2_23_0  service_visit_def_1557  1
    service_2_23_0  free_load_conservation_1558  -7
    service_2_23_0  original_T_including_depot_unload_1598  840
    service_2_23_1  unique_nonzero_owner_339  1
    service_2_23_1  service_visit_def_1557  1
    service_2_23_1  free_load_conservation_1558  -6
    service_2_23_1  original_T_including_depot_unload_1598  720
    service_2_23_2  unique_nonzero_owner_340  1
    service_2_23_2  service_visit_def_1557  1
    service_2_23_2  free_load_conservation_1558  -5
    service_2_23_2  original_T_including_depot_unload_1598  600
    service_2_23_3  unique_nonzero_owner_341  1
    service_2_23_3  service_visit_def_1557  1
    service_2_23_3  free_load_conservation_1558  -4
    service_2_23_3  original_T_including_depot_unload_1598  480
    service_2_23_4  unique_nonzero_owner_342  1
    service_2_23_4  service_visit_def_1557  1
    service_2_23_4  free_load_conservation_1558  -3
    service_2_23_4  original_T_including_depot_unload_1598  360
    service_2_23_5  unique_nonzero_owner_343  1
    service_2_23_5  service_visit_def_1557  1
    service_2_23_5  free_load_conservation_1558  -2
    service_2_23_5  original_T_including_depot_unload_1598  240
    service_2_23_6  unique_nonzero_owner_344  1
    service_2_23_6  service_visit_def_1557  1
    service_2_23_6  free_load_conservation_1558  -1
    service_2_23_6  original_T_including_depot_unload_1598  120
    service_2_23_8  unique_nonzero_owner_345  1
    service_2_23_8  service_visit_def_1557  1
    service_2_23_8  free_load_conservation_1558  1
    service_2_23_9  unique_nonzero_owner_346  1
    service_2_23_9  service_visit_def_1557  1
    service_2_23_9  free_load_conservation_1558  2
    service_2_23_10  unique_nonzero_owner_347  1
    service_2_23_10  service_visit_def_1557  1
    service_2_23_10  free_load_conservation_1558  3
    service_2_23_11  unique_nonzero_owner_348  1
    service_2_23_11  service_visit_def_1557  1
    service_2_23_11  free_load_conservation_1558  4
    service_0_31_0  unique_nonzero_owner_349  1
    service_0_31_0  service_visit_def_763  1
    service_0_31_0  free_load_conservation_764  -2
    service_0_31_0  original_T_including_depot_unload_798  240
    service_0_31_1  unique_nonzero_owner_350  1
    service_0_31_1  service_visit_def_763  1
    service_0_31_1  free_load_conservation_764  -1
    service_0_31_1  original_T_including_depot_unload_798  120
    service_0_31_3  unique_nonzero_owner_351  1
    service_0_31_3  service_visit_def_763  1
    service_0_31_3  free_load_conservation_764  1
    service_0_31_4  unique_nonzero_owner_352  1
    service_0_31_4  service_visit_def_763  1
    service_0_31_4  free_load_conservation_764  2
    service_0_31_5  unique_nonzero_owner_353  1
    service_0_31_5  service_visit_def_763  1
    service_0_31_5  free_load_conservation_764  3
    service_0_31_6  unique_nonzero_owner_354  1
    service_0_31_6  service_visit_def_763  1
    service_0_31_6  free_load_conservation_764  4
    service_0_31_7  unique_nonzero_owner_355  1
    service_0_31_7  service_visit_def_763  1
    service_0_31_7  free_load_conservation_764  5
    service_0_31_8  unique_nonzero_owner_356  1
    service_0_31_8  service_visit_def_763  1
    service_0_31_8  free_load_conservation_764  6
    service_0_31_9  unique_nonzero_owner_357  1
    service_0_31_9  service_visit_def_763  1
    service_0_31_9  free_load_conservation_764  7
    service_0_31_10  unique_nonzero_owner_358  1
    service_0_31_10  service_visit_def_763  1
    service_0_31_10  free_load_conservation_764  8
    service_0_31_11  unique_nonzero_owner_359  1
    service_0_31_11  service_visit_def_763  1
    service_0_31_11  free_load_conservation_764  9
    service_0_31_12  unique_nonzero_owner_360  1
    service_0_31_12  service_visit_def_763  1
    service_0_31_12  free_load_conservation_764  10
    service_1_31_0  unique_nonzero_owner_349  1
    service_1_31_0  service_visit_def_1191  1
    service_1_31_0  free_load_conservation_1192  -2
    service_1_31_0  original_T_including_depot_unload_1227  240
    service_1_31_1  unique_nonzero_owner_350  1
    service_1_31_1  service_visit_def_1191  1
    service_1_31_1  free_load_conservation_1192  -1
    service_1_31_1  original_T_including_depot_unload_1227  120
    service_1_31_3  unique_nonzero_owner_351  1
    service_1_31_3  service_visit_def_1191  1
    service_1_31_3  free_load_conservation_1192  1
    service_1_31_4  unique_nonzero_owner_352  1
    service_1_31_4  service_visit_def_1191  1
    service_1_31_4  free_load_conservation_1192  2
    service_1_31_5  unique_nonzero_owner_353  1
    service_1_31_5  service_visit_def_1191  1
    service_1_31_5  free_load_conservation_1192  3
    service_1_31_6  unique_nonzero_owner_354  1
    service_1_31_6  service_visit_def_1191  1
    service_1_31_6  free_load_conservation_1192  4
    service_1_31_7  unique_nonzero_owner_355  1
    service_1_31_7  service_visit_def_1191  1
    service_1_31_7  free_load_conservation_1192  5
    service_1_31_8  unique_nonzero_owner_356  1
    service_1_31_8  service_visit_def_1191  1
    service_1_31_8  free_load_conservation_1192  6
    service_1_31_9  unique_nonzero_owner_357  1
    service_1_31_9  service_visit_def_1191  1
    service_1_31_9  free_load_conservation_1192  7
    service_1_31_10  unique_nonzero_owner_358  1
    service_1_31_10  service_visit_def_1191  1
    service_1_31_10  free_load_conservation_1192  8
    service_1_31_11  unique_nonzero_owner_359  1
    service_1_31_11  service_visit_def_1191  1
    service_1_31_11  free_load_conservation_1192  9
    service_1_31_12  unique_nonzero_owner_360  1
    service_1_31_12  service_visit_def_1191  1
    service_1_31_12  free_load_conservation_1192  10
    service_2_31_0  unique_nonzero_owner_349  1
    service_2_31_0  service_visit_def_1563  1
    service_2_31_0  free_load_conservation_1564  -2
    service_2_31_0  original_T_including_depot_unload_1598  240
    service_2_31_1  unique_nonzero_owner_350  1
    service_2_31_1  service_visit_def_1563  1
    service_2_31_1  free_load_conservation_1564  -1
    service_2_31_1  original_T_including_depot_unload_1598  120
    service_2_31_3  unique_nonzero_owner_351  1
    service_2_31_3  service_visit_def_1563  1
    service_2_31_3  free_load_conservation_1564  1
    service_2_31_4  unique_nonzero_owner_352  1
    service_2_31_4  service_visit_def_1563  1
    service_2_31_4  free_load_conservation_1564  2
    service_2_31_5  unique_nonzero_owner_353  1
    service_2_31_5  service_visit_def_1563  1
    service_2_31_5  free_load_conservation_1564  3
    service_2_31_6  unique_nonzero_owner_354  1
    service_2_31_6  service_visit_def_1563  1
    service_2_31_6  free_load_conservation_1564  4
    service_2_31_7  unique_nonzero_owner_355  1
    service_2_31_7  service_visit_def_1563  1
    service_2_31_7  free_load_conservation_1564  5
    service_2_31_8  unique_nonzero_owner_356  1
    service_2_31_8  service_visit_def_1563  1
    service_2_31_8  free_load_conservation_1564  6
    service_2_31_9  unique_nonzero_owner_357  1
    service_2_31_9  service_visit_def_1563  1
    service_2_31_9  free_load_conservation_1564  7
    service_2_31_10  unique_nonzero_owner_358  1
    service_2_31_10  service_visit_def_1563  1
    service_2_31_10  free_load_conservation_1564  8
    service_2_31_11  unique_nonzero_owner_359  1
    service_2_31_11  service_visit_def_1563  1
    service_2_31_11  free_load_conservation_1564  9
    service_2_31_12  unique_nonzero_owner_360  1
    service_2_31_12  service_visit_def_1563  1
    service_2_31_12  free_load_conservation_1564  10
    service_0_21_0  unique_nonzero_owner_361  1
    service_0_21_0  service_visit_def_769  1
    service_0_21_0  free_load_conservation_770  -1
    service_0_21_0  original_T_including_depot_unload_798  120
    service_0_21_2  unique_nonzero_owner_362  1
    service_0_21_2  service_visit_def_769  1
    service_0_21_2  free_load_conservation_770  1
    service_0_21_3  unique_nonzero_owner_363  1
    service_0_21_3  service_visit_def_769  1
    service_0_21_3  free_load_conservation_770  2
    service_0_21_4  unique_nonzero_owner_364  1
    service_0_21_4  service_visit_def_769  1
    service_0_21_4  free_load_conservation_770  3
    service_0_21_5  unique_nonzero_owner_365  1
    service_0_21_5  service_visit_def_769  1
    service_0_21_5  free_load_conservation_770  4
    service_0_21_6  unique_nonzero_owner_366  1
    service_0_21_6  service_visit_def_769  1
    service_0_21_6  free_load_conservation_770  5
    service_0_21_7  unique_nonzero_owner_367  1
    service_0_21_7  service_visit_def_769  1
    service_0_21_7  free_load_conservation_770  6
    service_0_21_8  unique_nonzero_owner_368  1
    service_0_21_8  service_visit_def_769  1
    service_0_21_8  free_load_conservation_770  7
    service_0_21_9  unique_nonzero_owner_369  1
    service_0_21_9  service_visit_def_769  1
    service_0_21_9  free_load_conservation_770  8
    service_0_21_10  unique_nonzero_owner_370  1
    service_0_21_10  service_visit_def_769  1
    service_0_21_10  free_load_conservation_770  9
    service_0_21_11  unique_nonzero_owner_371  1
    service_0_21_11  service_visit_def_769  1
    service_0_21_11  free_load_conservation_770  10
    service_0_21_12  unique_nonzero_owner_372  1
    service_0_21_12  service_visit_def_769  1
    service_0_21_12  free_load_conservation_770  11
    service_0_21_13  unique_nonzero_owner_373  1
    service_0_21_13  service_visit_def_769  1
    service_0_21_13  free_load_conservation_770  12
    service_0_21_14  unique_nonzero_owner_374  1
    service_0_21_14  service_visit_def_769  1
    service_0_21_14  free_load_conservation_770  13
    service_0_21_15  unique_nonzero_owner_375  1
    service_0_21_15  service_visit_def_769  1
    service_0_21_15  free_load_conservation_770  14
    service_1_21_0  unique_nonzero_owner_361  1
    service_1_21_0  service_visit_def_1197  1
    service_1_21_0  free_load_conservation_1198  -1
    service_1_21_0  original_T_including_depot_unload_1227  120
    service_1_21_2  unique_nonzero_owner_362  1
    service_1_21_2  service_visit_def_1197  1
    service_1_21_2  free_load_conservation_1198  1
    service_1_21_3  unique_nonzero_owner_363  1
    service_1_21_3  service_visit_def_1197  1
    service_1_21_3  free_load_conservation_1198  2
    service_1_21_4  unique_nonzero_owner_364  1
    service_1_21_4  service_visit_def_1197  1
    service_1_21_4  free_load_conservation_1198  3
    service_1_21_5  unique_nonzero_owner_365  1
    service_1_21_5  service_visit_def_1197  1
    service_1_21_5  free_load_conservation_1198  4
    service_1_21_6  unique_nonzero_owner_366  1
    service_1_21_6  service_visit_def_1197  1
    service_1_21_6  free_load_conservation_1198  5
    service_1_21_7  unique_nonzero_owner_367  1
    service_1_21_7  service_visit_def_1197  1
    service_1_21_7  free_load_conservation_1198  6
    service_1_21_8  unique_nonzero_owner_368  1
    service_1_21_8  service_visit_def_1197  1
    service_1_21_8  free_load_conservation_1198  7
    service_1_21_9  unique_nonzero_owner_369  1
    service_1_21_9  service_visit_def_1197  1
    service_1_21_9  free_load_conservation_1198  8
    service_1_21_10  unique_nonzero_owner_370  1
    service_1_21_10  service_visit_def_1197  1
    service_1_21_10  free_load_conservation_1198  9
    service_1_21_11  unique_nonzero_owner_371  1
    service_1_21_11  service_visit_def_1197  1
    service_1_21_11  free_load_conservation_1198  10
    service_1_21_12  unique_nonzero_owner_372  1
    service_1_21_12  service_visit_def_1197  1
    service_1_21_12  free_load_conservation_1198  11
    service_1_21_13  unique_nonzero_owner_373  1
    service_1_21_13  service_visit_def_1197  1
    service_1_21_13  free_load_conservation_1198  12
    service_1_21_14  unique_nonzero_owner_374  1
    service_1_21_14  service_visit_def_1197  1
    service_1_21_14  free_load_conservation_1198  13
    service_1_21_15  unique_nonzero_owner_375  1
    service_1_21_15  service_visit_def_1197  1
    service_1_21_15  free_load_conservation_1198  14
    service_2_21_0  unique_nonzero_owner_361  1
    service_2_21_0  service_visit_def_1569  1
    service_2_21_0  free_load_conservation_1570  -1
    service_2_21_0  original_T_including_depot_unload_1598  120
    service_2_21_2  unique_nonzero_owner_362  1
    service_2_21_2  service_visit_def_1569  1
    service_2_21_2  free_load_conservation_1570  1
    service_2_21_3  unique_nonzero_owner_363  1
    service_2_21_3  service_visit_def_1569  1
    service_2_21_3  free_load_conservation_1570  2
    service_2_21_4  unique_nonzero_owner_364  1
    service_2_21_4  service_visit_def_1569  1
    service_2_21_4  free_load_conservation_1570  3
    service_2_21_5  unique_nonzero_owner_365  1
    service_2_21_5  service_visit_def_1569  1
    service_2_21_5  free_load_conservation_1570  4
    service_2_21_6  unique_nonzero_owner_366  1
    service_2_21_6  service_visit_def_1569  1
    service_2_21_6  free_load_conservation_1570  5
    service_2_21_7  unique_nonzero_owner_367  1
    service_2_21_7  service_visit_def_1569  1
    service_2_21_7  free_load_conservation_1570  6
    service_2_21_8  unique_nonzero_owner_368  1
    service_2_21_8  service_visit_def_1569  1
    service_2_21_8  free_load_conservation_1570  7
    service_2_21_9  unique_nonzero_owner_369  1
    service_2_21_9  service_visit_def_1569  1
    service_2_21_9  free_load_conservation_1570  8
    service_2_21_10  unique_nonzero_owner_370  1
    service_2_21_10  service_visit_def_1569  1
    service_2_21_10  free_load_conservation_1570  9
    service_2_21_11  unique_nonzero_owner_371  1
    service_2_21_11  service_visit_def_1569  1
    service_2_21_11  free_load_conservation_1570  10
    service_2_21_12  unique_nonzero_owner_372  1
    service_2_21_12  service_visit_def_1569  1
    service_2_21_12  free_load_conservation_1570  11
    service_2_21_13  unique_nonzero_owner_373  1
    service_2_21_13  service_visit_def_1569  1
    service_2_21_13  free_load_conservation_1570  12
    service_2_21_14  unique_nonzero_owner_374  1
    service_2_21_14  service_visit_def_1569  1
    service_2_21_14  free_load_conservation_1570  13
    service_2_21_15  unique_nonzero_owner_375  1
    service_2_21_15  service_visit_def_1569  1
    service_2_21_15  free_load_conservation_1570  14
    service_0_16_0  unique_nonzero_owner_376  1
    service_0_16_0  service_visit_def_775  1
    service_0_16_0  free_load_conservation_776  -1
    service_0_16_0  original_T_including_depot_unload_798  120
    service_0_16_2  unique_nonzero_owner_377  1
    service_0_16_2  service_visit_def_775  1
    service_0_16_2  free_load_conservation_776  1
    service_0_16_3  unique_nonzero_owner_378  1
    service_0_16_3  service_visit_def_775  1
    service_0_16_3  free_load_conservation_776  2
    service_0_16_4  unique_nonzero_owner_379  1
    service_0_16_4  service_visit_def_775  1
    service_0_16_4  free_load_conservation_776  3
    service_0_16_5  unique_nonzero_owner_380  1
    service_0_16_5  service_visit_def_775  1
    service_0_16_5  free_load_conservation_776  4
    service_0_16_6  unique_nonzero_owner_381  1
    service_0_16_6  service_visit_def_775  1
    service_0_16_6  free_load_conservation_776  5
    service_0_16_7  unique_nonzero_owner_382  1
    service_0_16_7  service_visit_def_775  1
    service_0_16_7  free_load_conservation_776  6
    service_0_16_8  unique_nonzero_owner_383  1
    service_0_16_8  service_visit_def_775  1
    service_0_16_8  free_load_conservation_776  7
    service_0_16_9  unique_nonzero_owner_384  1
    service_0_16_9  service_visit_def_775  1
    service_0_16_9  free_load_conservation_776  8
    service_0_16_10  unique_nonzero_owner_385  1
    service_0_16_10  service_visit_def_775  1
    service_0_16_10  free_load_conservation_776  9
    service_0_16_11  unique_nonzero_owner_386  1
    service_0_16_11  service_visit_def_775  1
    service_0_16_11  free_load_conservation_776  10
    service_0_16_12  unique_nonzero_owner_387  1
    service_0_16_12  service_visit_def_775  1
    service_0_16_12  free_load_conservation_776  11
    service_1_16_0  unique_nonzero_owner_376  1
    service_1_16_0  service_visit_def_1203  1
    service_1_16_0  free_load_conservation_1204  -1
    service_1_16_0  original_T_including_depot_unload_1227  120
    service_1_16_2  unique_nonzero_owner_377  1
    service_1_16_2  service_visit_def_1203  1
    service_1_16_2  free_load_conservation_1204  1
    service_1_16_3  unique_nonzero_owner_378  1
    service_1_16_3  service_visit_def_1203  1
    service_1_16_3  free_load_conservation_1204  2
    service_1_16_4  unique_nonzero_owner_379  1
    service_1_16_4  service_visit_def_1203  1
    service_1_16_4  free_load_conservation_1204  3
    service_1_16_5  unique_nonzero_owner_380  1
    service_1_16_5  service_visit_def_1203  1
    service_1_16_5  free_load_conservation_1204  4
    service_1_16_6  unique_nonzero_owner_381  1
    service_1_16_6  service_visit_def_1203  1
    service_1_16_6  free_load_conservation_1204  5
    service_1_16_7  unique_nonzero_owner_382  1
    service_1_16_7  service_visit_def_1203  1
    service_1_16_7  free_load_conservation_1204  6
    service_1_16_8  unique_nonzero_owner_383  1
    service_1_16_8  service_visit_def_1203  1
    service_1_16_8  free_load_conservation_1204  7
    service_1_16_9  unique_nonzero_owner_384  1
    service_1_16_9  service_visit_def_1203  1
    service_1_16_9  free_load_conservation_1204  8
    service_1_16_10  unique_nonzero_owner_385  1
    service_1_16_10  service_visit_def_1203  1
    service_1_16_10  free_load_conservation_1204  9
    service_1_16_11  unique_nonzero_owner_386  1
    service_1_16_11  service_visit_def_1203  1
    service_1_16_11  free_load_conservation_1204  10
    service_1_16_12  unique_nonzero_owner_387  1
    service_1_16_12  service_visit_def_1203  1
    service_1_16_12  free_load_conservation_1204  11
    service_2_16_0  unique_nonzero_owner_376  1
    service_2_16_0  service_visit_def_1575  1
    service_2_16_0  free_load_conservation_1576  -1
    service_2_16_0  original_T_including_depot_unload_1598  120
    service_2_16_2  unique_nonzero_owner_377  1
    service_2_16_2  service_visit_def_1575  1
    service_2_16_2  free_load_conservation_1576  1
    service_2_16_3  unique_nonzero_owner_378  1
    service_2_16_3  service_visit_def_1575  1
    service_2_16_3  free_load_conservation_1576  2
    service_2_16_4  unique_nonzero_owner_379  1
    service_2_16_4  service_visit_def_1575  1
    service_2_16_4  free_load_conservation_1576  3
    service_2_16_5  unique_nonzero_owner_380  1
    service_2_16_5  service_visit_def_1575  1
    service_2_16_5  free_load_conservation_1576  4
    service_2_16_6  unique_nonzero_owner_381  1
    service_2_16_6  service_visit_def_1575  1
    service_2_16_6  free_load_conservation_1576  5
    service_2_16_7  unique_nonzero_owner_382  1
    service_2_16_7  service_visit_def_1575  1
    service_2_16_7  free_load_conservation_1576  6
    service_2_16_8  unique_nonzero_owner_383  1
    service_2_16_8  service_visit_def_1575  1
    service_2_16_8  free_load_conservation_1576  7
    service_2_16_9  unique_nonzero_owner_384  1
    service_2_16_9  service_visit_def_1575  1
    service_2_16_9  free_load_conservation_1576  8
    service_2_16_10  unique_nonzero_owner_385  1
    service_2_16_10  service_visit_def_1575  1
    service_2_16_10  free_load_conservation_1576  9
    service_2_16_11  unique_nonzero_owner_386  1
    service_2_16_11  service_visit_def_1575  1
    service_2_16_11  free_load_conservation_1576  10
    service_2_16_12  unique_nonzero_owner_387  1
    service_2_16_12  service_visit_def_1575  1
    service_2_16_12  free_load_conservation_1576  11
    service_0_20_0  unique_nonzero_owner_388  1
    service_0_20_0  service_visit_def_781  1
    service_0_20_0  free_load_conservation_782  -9
    service_0_20_0  original_T_including_depot_unload_798  1080
    service_0_20_1  unique_nonzero_owner_389  1
    service_0_20_1  service_visit_def_781  1
    service_0_20_1  free_load_conservation_782  -8
    service_0_20_1  original_T_including_depot_unload_798  960
    service_0_20_2  unique_nonzero_owner_390  1
    service_0_20_2  service_visit_def_781  1
    service_0_20_2  free_load_conservation_782  -7
    service_0_20_2  original_T_including_depot_unload_798  840
    service_0_20_3  unique_nonzero_owner_391  1
    service_0_20_3  service_visit_def_781  1
    service_0_20_3  free_load_conservation_782  -6
    service_0_20_3  original_T_including_depot_unload_798  720
    service_0_20_4  unique_nonzero_owner_392  1
    service_0_20_4  service_visit_def_781  1
    service_0_20_4  free_load_conservation_782  -5
    service_0_20_4  original_T_including_depot_unload_798  600
    service_0_20_5  unique_nonzero_owner_393  1
    service_0_20_5  service_visit_def_781  1
    service_0_20_5  free_load_conservation_782  -4
    service_0_20_5  original_T_including_depot_unload_798  480
    service_0_20_6  unique_nonzero_owner_394  1
    service_0_20_6  service_visit_def_781  1
    service_0_20_6  free_load_conservation_782  -3
    service_0_20_6  original_T_including_depot_unload_798  360
    service_0_20_7  unique_nonzero_owner_395  1
    service_0_20_7  service_visit_def_781  1
    service_0_20_7  free_load_conservation_782  -2
    service_0_20_7  original_T_including_depot_unload_798  240
    service_0_20_8  unique_nonzero_owner_396  1
    service_0_20_8  service_visit_def_781  1
    service_0_20_8  free_load_conservation_782  -1
    service_0_20_8  original_T_including_depot_unload_798  120
    service_0_20_10  unique_nonzero_owner_397  1
    service_0_20_10  service_visit_def_781  1
    service_0_20_10  free_load_conservation_782  1
    service_0_20_11  unique_nonzero_owner_398  1
    service_0_20_11  service_visit_def_781  1
    service_0_20_11  free_load_conservation_782  2
    service_0_20_12  unique_nonzero_owner_399  1
    service_0_20_12  service_visit_def_781  1
    service_0_20_12  free_load_conservation_782  3
    service_1_20_0  unique_nonzero_owner_388  1
    service_1_20_0  service_visit_def_1209  1
    service_1_20_0  free_load_conservation_1210  -9
    service_1_20_0  original_T_including_depot_unload_1227  1080
    service_1_20_1  unique_nonzero_owner_389  1
    service_1_20_1  service_visit_def_1209  1
    service_1_20_1  free_load_conservation_1210  -8
    service_1_20_1  original_T_including_depot_unload_1227  960
    service_1_20_2  unique_nonzero_owner_390  1
    service_1_20_2  service_visit_def_1209  1
    service_1_20_2  free_load_conservation_1210  -7
    service_1_20_2  original_T_including_depot_unload_1227  840
    service_1_20_3  unique_nonzero_owner_391  1
    service_1_20_3  service_visit_def_1209  1
    service_1_20_3  free_load_conservation_1210  -6
    service_1_20_3  original_T_including_depot_unload_1227  720
    service_1_20_4  unique_nonzero_owner_392  1
    service_1_20_4  service_visit_def_1209  1
    service_1_20_4  free_load_conservation_1210  -5
    service_1_20_4  original_T_including_depot_unload_1227  600
    service_1_20_5  unique_nonzero_owner_393  1
    service_1_20_5  service_visit_def_1209  1
    service_1_20_5  free_load_conservation_1210  -4
    service_1_20_5  original_T_including_depot_unload_1227  480
    service_1_20_6  unique_nonzero_owner_394  1
    service_1_20_6  service_visit_def_1209  1
    service_1_20_6  free_load_conservation_1210  -3
    service_1_20_6  original_T_including_depot_unload_1227  360
    service_1_20_7  unique_nonzero_owner_395  1
    service_1_20_7  service_visit_def_1209  1
    service_1_20_7  free_load_conservation_1210  -2
    service_1_20_7  original_T_including_depot_unload_1227  240
    service_1_20_8  unique_nonzero_owner_396  1
    service_1_20_8  service_visit_def_1209  1
    service_1_20_8  free_load_conservation_1210  -1
    service_1_20_8  original_T_including_depot_unload_1227  120
    service_1_20_10  unique_nonzero_owner_397  1
    service_1_20_10  service_visit_def_1209  1
    service_1_20_10  free_load_conservation_1210  1
    service_1_20_11  unique_nonzero_owner_398  1
    service_1_20_11  service_visit_def_1209  1
    service_1_20_11  free_load_conservation_1210  2
    service_1_20_12  unique_nonzero_owner_399  1
    service_1_20_12  service_visit_def_1209  1
    service_1_20_12  free_load_conservation_1210  3
    service_2_20_0  unique_nonzero_owner_388  1
    service_2_20_0  service_visit_def_1581  1
    service_2_20_0  free_load_conservation_1582  -9
    service_2_20_0  original_T_including_depot_unload_1598  1080
    service_2_20_1  unique_nonzero_owner_389  1
    service_2_20_1  service_visit_def_1581  1
    service_2_20_1  free_load_conservation_1582  -8
    service_2_20_1  original_T_including_depot_unload_1598  960
    service_2_20_2  unique_nonzero_owner_390  1
    service_2_20_2  service_visit_def_1581  1
    service_2_20_2  free_load_conservation_1582  -7
    service_2_20_2  original_T_including_depot_unload_1598  840
    service_2_20_3  unique_nonzero_owner_391  1
    service_2_20_3  service_visit_def_1581  1
    service_2_20_3  free_load_conservation_1582  -6
    service_2_20_3  original_T_including_depot_unload_1598  720
    service_2_20_4  unique_nonzero_owner_392  1
    service_2_20_4  service_visit_def_1581  1
    service_2_20_4  free_load_conservation_1582  -5
    service_2_20_4  original_T_including_depot_unload_1598  600
    service_2_20_5  unique_nonzero_owner_393  1
    service_2_20_5  service_visit_def_1581  1
    service_2_20_5  free_load_conservation_1582  -4
    service_2_20_5  original_T_including_depot_unload_1598  480
    service_2_20_6  unique_nonzero_owner_394  1
    service_2_20_6  service_visit_def_1581  1
    service_2_20_6  free_load_conservation_1582  -3
    service_2_20_6  original_T_including_depot_unload_1598  360
    service_2_20_7  unique_nonzero_owner_395  1
    service_2_20_7  service_visit_def_1581  1
    service_2_20_7  free_load_conservation_1582  -2
    service_2_20_7  original_T_including_depot_unload_1598  240
    service_2_20_8  unique_nonzero_owner_396  1
    service_2_20_8  service_visit_def_1581  1
    service_2_20_8  free_load_conservation_1582  -1
    service_2_20_8  original_T_including_depot_unload_1598  120
    service_2_20_10  unique_nonzero_owner_397  1
    service_2_20_10  service_visit_def_1581  1
    service_2_20_10  free_load_conservation_1582  1
    service_2_20_11  unique_nonzero_owner_398  1
    service_2_20_11  service_visit_def_1581  1
    service_2_20_11  free_load_conservation_1582  2
    service_2_20_12  unique_nonzero_owner_399  1
    service_2_20_12  service_visit_def_1581  1
    service_2_20_12  free_load_conservation_1582  3
    service_0_32_1  unique_nonzero_owner_400  1
    service_0_32_1  service_visit_def_787  1
    service_0_32_1  free_load_conservation_788  1
    service_0_32_2  unique_nonzero_owner_401  1
    service_0_32_2  service_visit_def_787  1
    service_0_32_2  free_load_conservation_788  2
    service_0_32_3  unique_nonzero_owner_402  1
    service_0_32_3  service_visit_def_787  1
    service_0_32_3  free_load_conservation_788  3
    service_0_32_4  unique_nonzero_owner_403  1
    service_0_32_4  service_visit_def_787  1
    service_0_32_4  free_load_conservation_788  4
    service_0_32_5  unique_nonzero_owner_404  1
    service_0_32_5  service_visit_def_787  1
    service_0_32_5  free_load_conservation_788  5
    service_0_32_6  unique_nonzero_owner_405  1
    service_0_32_6  service_visit_def_787  1
    service_0_32_6  free_load_conservation_788  6
    service_0_32_7  unique_nonzero_owner_406  1
    service_0_32_7  service_visit_def_787  1
    service_0_32_7  free_load_conservation_788  7
    service_0_32_8  unique_nonzero_owner_407  1
    service_0_32_8  service_visit_def_787  1
    service_0_32_8  free_load_conservation_788  8
    service_0_32_9  unique_nonzero_owner_408  1
    service_0_32_9  service_visit_def_787  1
    service_0_32_9  free_load_conservation_788  9
    service_0_32_10  unique_nonzero_owner_409  1
    service_0_32_10  service_visit_def_787  1
    service_0_32_10  free_load_conservation_788  10
    service_0_32_11  unique_nonzero_owner_410  1
    service_0_32_11  service_visit_def_787  1
    service_0_32_11  free_load_conservation_788  11
    service_0_32_12  unique_nonzero_owner_411  1
    service_0_32_12  service_visit_def_787  1
    service_0_32_12  free_load_conservation_788  12
    service_1_32_1  unique_nonzero_owner_400  1
    service_1_32_1  service_visit_def_1215  1
    service_1_32_1  free_load_conservation_1216  1
    service_1_32_2  unique_nonzero_owner_401  1
    service_1_32_2  service_visit_def_1215  1
    service_1_32_2  free_load_conservation_1216  2
    service_1_32_3  unique_nonzero_owner_402  1
    service_1_32_3  service_visit_def_1215  1
    service_1_32_3  free_load_conservation_1216  3
    service_1_32_4  unique_nonzero_owner_403  1
    service_1_32_4  service_visit_def_1215  1
    service_1_32_4  free_load_conservation_1216  4
    service_1_32_5  unique_nonzero_owner_404  1
    service_1_32_5  service_visit_def_1215  1
    service_1_32_5  free_load_conservation_1216  5
    service_1_32_6  unique_nonzero_owner_405  1
    service_1_32_6  service_visit_def_1215  1
    service_1_32_6  free_load_conservation_1216  6
    service_1_32_7  unique_nonzero_owner_406  1
    service_1_32_7  service_visit_def_1215  1
    service_1_32_7  free_load_conservation_1216  7
    service_1_32_8  unique_nonzero_owner_407  1
    service_1_32_8  service_visit_def_1215  1
    service_1_32_8  free_load_conservation_1216  8
    service_1_32_9  unique_nonzero_owner_408  1
    service_1_32_9  service_visit_def_1215  1
    service_1_32_9  free_load_conservation_1216  9
    service_1_32_10  unique_nonzero_owner_409  1
    service_1_32_10  service_visit_def_1215  1
    service_1_32_10  free_load_conservation_1216  10
    service_1_32_11  unique_nonzero_owner_410  1
    service_1_32_11  service_visit_def_1215  1
    service_1_32_11  free_load_conservation_1216  11
    service_1_32_12  unique_nonzero_owner_411  1
    service_1_32_12  service_visit_def_1215  1
    service_1_32_12  free_load_conservation_1216  12
    service_2_32_1  unique_nonzero_owner_400  1
    service_2_32_1  service_visit_def_1587  1
    service_2_32_1  free_load_conservation_1588  1
    service_2_32_2  unique_nonzero_owner_401  1
    service_2_32_2  service_visit_def_1587  1
    service_2_32_2  free_load_conservation_1588  2
    service_2_32_3  unique_nonzero_owner_402  1
    service_2_32_3  service_visit_def_1587  1
    service_2_32_3  free_load_conservation_1588  3
    service_2_32_4  unique_nonzero_owner_403  1
    service_2_32_4  service_visit_def_1587  1
    service_2_32_4  free_load_conservation_1588  4
    service_2_32_5  unique_nonzero_owner_404  1
    service_2_32_5  service_visit_def_1587  1
    service_2_32_5  free_load_conservation_1588  5
    service_2_32_6  unique_nonzero_owner_405  1
    service_2_32_6  service_visit_def_1587  1
    service_2_32_6  free_load_conservation_1588  6
    service_2_32_7  unique_nonzero_owner_406  1
    service_2_32_7  service_visit_def_1587  1
    service_2_32_7  free_load_conservation_1588  7
    service_2_32_8  unique_nonzero_owner_407  1
    service_2_32_8  service_visit_def_1587  1
    service_2_32_8  free_load_conservation_1588  8
    service_2_32_9  unique_nonzero_owner_408  1
    service_2_32_9  service_visit_def_1587  1
    service_2_32_9  free_load_conservation_1588  9
    service_2_32_10  unique_nonzero_owner_409  1
    service_2_32_10  service_visit_def_1587  1
    service_2_32_10  free_load_conservation_1588  10
    service_2_32_11  unique_nonzero_owner_410  1
    service_2_32_11  service_visit_def_1587  1
    service_2_32_11  free_load_conservation_1588  11
    service_2_32_12  unique_nonzero_owner_411  1
    service_2_32_12  service_visit_def_1587  1
    service_2_32_12  free_load_conservation_1588  12
    service_0_33_0  unique_nonzero_owner_412  1
    service_0_33_0  service_visit_def_793  1
    service_0_33_0  free_load_conservation_794  -1
    service_0_33_0  original_T_including_depot_unload_798  120
    service_0_33_2  unique_nonzero_owner_413  1
    service_0_33_2  service_visit_def_793  1
    service_0_33_2  free_load_conservation_794  1
    service_0_33_3  unique_nonzero_owner_414  1
    service_0_33_3  service_visit_def_793  1
    service_0_33_3  free_load_conservation_794  2
    service_0_33_4  unique_nonzero_owner_415  1
    service_0_33_4  service_visit_def_793  1
    service_0_33_4  free_load_conservation_794  3
    service_0_33_5  unique_nonzero_owner_416  1
    service_0_33_5  service_visit_def_793  1
    service_0_33_5  free_load_conservation_794  4
    service_0_33_6  unique_nonzero_owner_417  1
    service_0_33_6  service_visit_def_793  1
    service_0_33_6  free_load_conservation_794  5
    service_0_33_7  unique_nonzero_owner_418  1
    service_0_33_7  service_visit_def_793  1
    service_0_33_7  free_load_conservation_794  6
    service_0_33_8  unique_nonzero_owner_419  1
    service_0_33_8  service_visit_def_793  1
    service_0_33_8  free_load_conservation_794  7
    service_0_33_9  unique_nonzero_owner_420  1
    service_0_33_9  service_visit_def_793  1
    service_0_33_9  free_load_conservation_794  8
    service_0_33_10  unique_nonzero_owner_421  1
    service_0_33_10  service_visit_def_793  1
    service_0_33_10  free_load_conservation_794  9
    service_0_33_11  unique_nonzero_owner_422  1
    service_0_33_11  service_visit_def_793  1
    service_0_33_11  free_load_conservation_794  10
    service_0_33_12  unique_nonzero_owner_423  1
    service_0_33_12  service_visit_def_793  1
    service_0_33_12  free_load_conservation_794  11
    service_0_33_13  unique_nonzero_owner_424  1
    service_0_33_13  service_visit_def_793  1
    service_0_33_13  free_load_conservation_794  12
    service_0_33_14  unique_nonzero_owner_425  1
    service_0_33_14  service_visit_def_793  1
    service_0_33_14  free_load_conservation_794  13
    service_0_33_15  unique_nonzero_owner_426  1
    service_0_33_15  service_visit_def_793  1
    service_0_33_15  free_load_conservation_794  14
    service_0_33_16  unique_nonzero_owner_427  1
    service_0_33_16  service_visit_def_793  1
    service_0_33_16  free_load_conservation_794  15
    service_1_33_0  unique_nonzero_owner_412  1
    service_1_33_0  service_visit_def_1221  1
    service_1_33_0  free_load_conservation_1222  -1
    service_1_33_0  original_T_including_depot_unload_1227  120
    service_1_33_2  unique_nonzero_owner_413  1
    service_1_33_2  service_visit_def_1221  1
    service_1_33_2  free_load_conservation_1222  1
    service_1_33_3  unique_nonzero_owner_414  1
    service_1_33_3  service_visit_def_1221  1
    service_1_33_3  free_load_conservation_1222  2
    service_1_33_4  unique_nonzero_owner_415  1
    service_1_33_4  service_visit_def_1221  1
    service_1_33_4  free_load_conservation_1222  3
    service_1_33_5  unique_nonzero_owner_416  1
    service_1_33_5  service_visit_def_1221  1
    service_1_33_5  free_load_conservation_1222  4
    service_1_33_6  unique_nonzero_owner_417  1
    service_1_33_6  service_visit_def_1221  1
    service_1_33_6  free_load_conservation_1222  5
    service_1_33_7  unique_nonzero_owner_418  1
    service_1_33_7  service_visit_def_1221  1
    service_1_33_7  free_load_conservation_1222  6
    service_1_33_8  unique_nonzero_owner_419  1
    service_1_33_8  service_visit_def_1221  1
    service_1_33_8  free_load_conservation_1222  7
    service_1_33_9  unique_nonzero_owner_420  1
    service_1_33_9  service_visit_def_1221  1
    service_1_33_9  free_load_conservation_1222  8
    service_1_33_10  unique_nonzero_owner_421  1
    service_1_33_10  service_visit_def_1221  1
    service_1_33_10  free_load_conservation_1222  9
    service_1_33_11  unique_nonzero_owner_422  1
    service_1_33_11  service_visit_def_1221  1
    service_1_33_11  free_load_conservation_1222  10
    service_1_33_12  unique_nonzero_owner_423  1
    service_1_33_12  service_visit_def_1221  1
    service_1_33_12  free_load_conservation_1222  11
    service_1_33_13  unique_nonzero_owner_424  1
    service_1_33_13  service_visit_def_1221  1
    service_1_33_13  free_load_conservation_1222  12
    service_1_33_14  unique_nonzero_owner_425  1
    service_1_33_14  service_visit_def_1221  1
    service_1_33_14  free_load_conservation_1222  13
    service_1_33_15  unique_nonzero_owner_426  1
    service_1_33_15  service_visit_def_1221  1
    service_1_33_15  free_load_conservation_1222  14
    service_1_33_16  unique_nonzero_owner_427  1
    service_1_33_16  service_visit_def_1221  1
    service_1_33_16  free_load_conservation_1222  15
    service_2_33_0  unique_nonzero_owner_412  1
    service_2_33_0  service_visit_def_1593  1
    service_2_33_0  free_load_conservation_1594  -1
    service_2_33_0  original_T_including_depot_unload_1598  120
    service_2_33_2  unique_nonzero_owner_413  1
    service_2_33_2  service_visit_def_1593  1
    service_2_33_2  free_load_conservation_1594  1
    service_2_33_3  unique_nonzero_owner_414  1
    service_2_33_3  service_visit_def_1593  1
    service_2_33_3  free_load_conservation_1594  2
    service_2_33_4  unique_nonzero_owner_415  1
    service_2_33_4  service_visit_def_1593  1
    service_2_33_4  free_load_conservation_1594  3
    service_2_33_5  unique_nonzero_owner_416  1
    service_2_33_5  service_visit_def_1593  1
    service_2_33_5  free_load_conservation_1594  4
    service_2_33_6  unique_nonzero_owner_417  1
    service_2_33_6  service_visit_def_1593  1
    service_2_33_6  free_load_conservation_1594  5
    service_2_33_7  unique_nonzero_owner_418  1
    service_2_33_7  service_visit_def_1593  1
    service_2_33_7  free_load_conservation_1594  6
    service_2_33_8  unique_nonzero_owner_419  1
    service_2_33_8  service_visit_def_1593  1
    service_2_33_8  free_load_conservation_1594  7
    service_2_33_9  unique_nonzero_owner_420  1
    service_2_33_9  service_visit_def_1593  1
    service_2_33_9  free_load_conservation_1594  8
    service_2_33_10  unique_nonzero_owner_421  1
    service_2_33_10  service_visit_def_1593  1
    service_2_33_10  free_load_conservation_1594  9
    service_2_33_11  unique_nonzero_owner_422  1
    service_2_33_11  service_visit_def_1593  1
    service_2_33_11  free_load_conservation_1594  10
    service_2_33_12  unique_nonzero_owner_423  1
    service_2_33_12  service_visit_def_1593  1
    service_2_33_12  free_load_conservation_1594  11
    service_2_33_13  unique_nonzero_owner_424  1
    service_2_33_13  service_visit_def_1593  1
    service_2_33_13  free_load_conservation_1594  12
    service_2_33_14  unique_nonzero_owner_425  1
    service_2_33_14  service_visit_def_1593  1
    service_2_33_14  free_load_conservation_1594  13
    service_2_33_15  unique_nonzero_owner_426  1
    service_2_33_15  service_visit_def_1593  1
    service_2_33_15  free_load_conservation_1594  14
    service_2_33_16  unique_nonzero_owner_427  1
    service_2_33_16  service_visit_def_1593  1
    service_2_33_16  free_load_conservation_1594  15
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_719  -1
    visit_0_1  in_degree_720  -1
    visit_0_1  order_active_lb_721  -1
    visit_0_1  order_active_ub_722  -12
    order_0_1  connected_order_arc_443  -1
    order_0_1  connected_order_arc_445  -1
    order_0_1  connected_order_arc_447  -1
    order_0_1  connected_order_arc_449  -1
    order_0_1  connected_order_arc_451  -1
    order_0_1  connected_order_arc_453  -1
    order_0_1  connected_order_arc_455  -1
    order_0_1  connected_order_arc_457  -1
    order_0_1  connected_order_arc_459  -1
    order_0_1  connected_order_arc_461  -1
    order_0_1  connected_order_arc_463  -1
    order_0_1  connected_order_arc_466  1
    order_0_1  connected_order_arc_489  1
    order_0_1  connected_order_arc_512  1
    order_0_1  connected_order_arc_535  1
    order_0_1  connected_order_arc_558  1
    order_0_1  connected_order_arc_581  1
    order_0_1  connected_order_arc_604  1
    order_0_1  connected_order_arc_627  1
    order_0_1  connected_order_arc_650  1
    order_0_1  connected_order_arc_673  1
    order_0_1  connected_order_arc_696  1
    order_0_1  order_active_lb_721  1
    order_0_1  order_active_ub_722  1
    order_0_1  fixed_segment_relative_order_795  -1
    visit_0_2  out_degree_726  -1
    visit_0_2  in_degree_727  -1
    visit_0_2  order_active_lb_728  -1
    visit_0_2  order_active_ub_729  -12
    order_0_2  connected_order_arc_443  1
    order_0_2  connected_order_arc_466  -1
    order_0_2  connected_order_arc_468  -1
    order_0_2  connected_order_arc_470  -1
    order_0_2  connected_order_arc_472  -1
    order_0_2  connected_order_arc_474  -1
    order_0_2  connected_order_arc_476  -1
    order_0_2  connected_order_arc_478  -1
    order_0_2  connected_order_arc_480  -1
    order_0_2  connected_order_arc_482  -1
    order_0_2  connected_order_arc_484  -1
    order_0_2  connected_order_arc_486  -1
    order_0_2  connected_order_arc_491  1
    order_0_2  connected_order_arc_514  1
    order_0_2  connected_order_arc_537  1
    order_0_2  connected_order_arc_560  1
    order_0_2  connected_order_arc_583  1
    order_0_2  connected_order_arc_606  1
    order_0_2  connected_order_arc_629  1
    order_0_2  connected_order_arc_652  1
    order_0_2  connected_order_arc_675  1
    order_0_2  connected_order_arc_698  1
    order_0_2  order_active_lb_728  1
    order_0_2  order_active_ub_729  1
    order_0_2  fixed_segment_relative_order_795  1
    order_0_2  fixed_segment_relative_order_796  -1
    visit_0_3  out_degree_733  -1
    visit_0_3  in_degree_734  -1
    visit_0_3  order_active_lb_735  -1
    visit_0_3  order_active_ub_736  -12
    order_0_3  connected_order_arc_445  1
    order_0_3  connected_order_arc_468  1
    order_0_3  connected_order_arc_489  -1
    order_0_3  connected_order_arc_491  -1
    order_0_3  connected_order_arc_493  -1
    order_0_3  connected_order_arc_495  -1
    order_0_3  connected_order_arc_497  -1
    order_0_3  connected_order_arc_499  -1
    order_0_3  connected_order_arc_501  -1
    order_0_3  connected_order_arc_503  -1
    order_0_3  connected_order_arc_505  -1
    order_0_3  connected_order_arc_507  -1
    order_0_3  connected_order_arc_509  -1
    order_0_3  connected_order_arc_516  1
    order_0_3  connected_order_arc_539  1
    order_0_3  connected_order_arc_562  1
    order_0_3  connected_order_arc_585  1
    order_0_3  connected_order_arc_608  1
    order_0_3  connected_order_arc_631  1
    order_0_3  connected_order_arc_654  1
    order_0_3  connected_order_arc_677  1
    order_0_3  connected_order_arc_700  1
    order_0_3  order_active_lb_735  1
    order_0_3  order_active_ub_736  1
    order_0_3  fixed_segment_relative_order_796  1
    order_0_3  fixed_segment_relative_order_797  -1
    visit_0_4  out_degree_740  -1
    visit_0_4  in_degree_741  -1
    visit_0_4  order_active_lb_742  -1
    visit_0_4  order_active_ub_743  -12
    order_0_4  connected_order_arc_447  1
    order_0_4  connected_order_arc_470  1
    order_0_4  connected_order_arc_493  1
    order_0_4  connected_order_arc_512  -1
    order_0_4  connected_order_arc_514  -1
    order_0_4  connected_order_arc_516  -1
    order_0_4  connected_order_arc_518  -1
    order_0_4  connected_order_arc_520  -1
    order_0_4  connected_order_arc_522  -1
    order_0_4  connected_order_arc_524  -1
    order_0_4  connected_order_arc_526  -1
    order_0_4  connected_order_arc_528  -1
    order_0_4  connected_order_arc_530  -1
    order_0_4  connected_order_arc_532  -1
    order_0_4  connected_order_arc_541  1
    order_0_4  connected_order_arc_564  1
    order_0_4  connected_order_arc_587  1
    order_0_4  connected_order_arc_610  1
    order_0_4  connected_order_arc_633  1
    order_0_4  connected_order_arc_656  1
    order_0_4  connected_order_arc_679  1
    order_0_4  connected_order_arc_702  1
    order_0_4  order_active_lb_742  1
    order_0_4  order_active_ub_743  1
    order_0_4  fixed_segment_relative_order_797  1
    visit_0_14  out_degree_747  -1
    visit_0_14  in_degree_748  -1
    visit_0_14  order_active_lb_749  -1
    visit_0_14  order_active_ub_750  -12
    visit_0_14  service_visit_def_751  -1
    order_0_14  connected_order_arc_449  1
    order_0_14  connected_order_arc_472  1
    order_0_14  connected_order_arc_495  1
    order_0_14  connected_order_arc_518  1
    order_0_14  connected_order_arc_535  -1
    order_0_14  connected_order_arc_537  -1
    order_0_14  connected_order_arc_539  -1
    order_0_14  connected_order_arc_541  -1
    order_0_14  connected_order_arc_543  -1
    order_0_14  connected_order_arc_545  -1
    order_0_14  connected_order_arc_547  -1
    order_0_14  connected_order_arc_549  -1
    order_0_14  connected_order_arc_551  -1
    order_0_14  connected_order_arc_553  -1
    order_0_14  connected_order_arc_555  -1
    order_0_14  connected_order_arc_566  1
    order_0_14  connected_order_arc_589  1
    order_0_14  connected_order_arc_612  1
    order_0_14  connected_order_arc_635  1
    order_0_14  connected_order_arc_658  1
    order_0_14  connected_order_arc_681  1
    order_0_14  connected_order_arc_704  1
    order_0_14  order_active_lb_749  1
    order_0_14  order_active_ub_750  1
    visit_0_15  out_degree_753  -1
    visit_0_15  in_degree_754  -1
    visit_0_15  order_active_lb_755  -1
    visit_0_15  order_active_ub_756  -12
    visit_0_15  service_visit_def_757  -1
    order_0_15  connected_order_arc_451  1
    order_0_15  connected_order_arc_474  1
    order_0_15  connected_order_arc_497  1
    order_0_15  connected_order_arc_520  1
    order_0_15  connected_order_arc_543  1
    order_0_15  connected_order_arc_558  -1
    order_0_15  connected_order_arc_560  -1
    order_0_15  connected_order_arc_562  -1
    order_0_15  connected_order_arc_564  -1
    order_0_15  connected_order_arc_566  -1
    order_0_15  connected_order_arc_568  -1
    order_0_15  connected_order_arc_570  -1
    order_0_15  connected_order_arc_572  -1
    order_0_15  connected_order_arc_574  -1
    order_0_15  connected_order_arc_576  -1
    order_0_15  connected_order_arc_578  -1
    order_0_15  connected_order_arc_591  1
    order_0_15  connected_order_arc_614  1
    order_0_15  connected_order_arc_637  1
    order_0_15  connected_order_arc_660  1
    order_0_15  connected_order_arc_683  1
    order_0_15  connected_order_arc_706  1
    order_0_15  order_active_lb_755  1
    order_0_15  order_active_ub_756  1
    visit_0_16  out_degree_759  -1
    visit_0_16  in_degree_760  -1
    visit_0_16  order_active_lb_761  -1
    visit_0_16  order_active_ub_762  -12
    visit_0_16  service_visit_def_763  -1
    order_0_16  connected_order_arc_453  1
    order_0_16  connected_order_arc_476  1
    order_0_16  connected_order_arc_499  1
    order_0_16  connected_order_arc_522  1
    order_0_16  connected_order_arc_545  1
    order_0_16  connected_order_arc_568  1
    order_0_16  connected_order_arc_581  -1
    order_0_16  connected_order_arc_583  -1
    order_0_16  connected_order_arc_585  -1
    order_0_16  connected_order_arc_587  -1
    order_0_16  connected_order_arc_589  -1
    order_0_16  connected_order_arc_591  -1
    order_0_16  connected_order_arc_593  -1
    order_0_16  connected_order_arc_595  -1
    order_0_16  connected_order_arc_597  -1
    order_0_16  connected_order_arc_599  -1
    order_0_16  connected_order_arc_601  -1
    order_0_16  connected_order_arc_616  1
    order_0_16  connected_order_arc_639  1
    order_0_16  connected_order_arc_662  1
    order_0_16  connected_order_arc_685  1
    order_0_16  connected_order_arc_708  1
    order_0_16  order_active_lb_761  1
    order_0_16  order_active_ub_762  1
    visit_0_17  out_degree_765  -1
    visit_0_17  in_degree_766  -1
    visit_0_17  order_active_lb_767  -1
    visit_0_17  order_active_ub_768  -12
    visit_0_17  service_visit_def_769  -1
    order_0_17  connected_order_arc_455  1
    order_0_17  connected_order_arc_478  1
    order_0_17  connected_order_arc_501  1
    order_0_17  connected_order_arc_524  1
    order_0_17  connected_order_arc_547  1
    order_0_17  connected_order_arc_570  1
    order_0_17  connected_order_arc_593  1
    order_0_17  connected_order_arc_604  -1
    order_0_17  connected_order_arc_606  -1
    order_0_17  connected_order_arc_608  -1
    order_0_17  connected_order_arc_610  -1
    order_0_17  connected_order_arc_612  -1
    order_0_17  connected_order_arc_614  -1
    order_0_17  connected_order_arc_616  -1
    order_0_17  connected_order_arc_618  -1
    order_0_17  connected_order_arc_620  -1
    order_0_17  connected_order_arc_622  -1
    order_0_17  connected_order_arc_624  -1
    order_0_17  connected_order_arc_641  1
    order_0_17  connected_order_arc_664  1
    order_0_17  connected_order_arc_687  1
    order_0_17  connected_order_arc_710  1
    order_0_17  order_active_lb_767  1
    order_0_17  order_active_ub_768  1
    visit_0_18  out_degree_771  -1
    visit_0_18  in_degree_772  -1
    visit_0_18  order_active_lb_773  -1
    visit_0_18  order_active_ub_774  -12
    visit_0_18  service_visit_def_775  -1
    order_0_18  connected_order_arc_457  1
    order_0_18  connected_order_arc_480  1
    order_0_18  connected_order_arc_503  1
    order_0_18  connected_order_arc_526  1
    order_0_18  connected_order_arc_549  1
    order_0_18  connected_order_arc_572  1
    order_0_18  connected_order_arc_595  1
    order_0_18  connected_order_arc_618  1
    order_0_18  connected_order_arc_627  -1
    order_0_18  connected_order_arc_629  -1
    order_0_18  connected_order_arc_631  -1
    order_0_18  connected_order_arc_633  -1
    order_0_18  connected_order_arc_635  -1
    order_0_18  connected_order_arc_637  -1
    order_0_18  connected_order_arc_639  -1
    order_0_18  connected_order_arc_641  -1
    order_0_18  connected_order_arc_643  -1
    order_0_18  connected_order_arc_645  -1
    order_0_18  connected_order_arc_647  -1
    order_0_18  connected_order_arc_666  1
    order_0_18  connected_order_arc_689  1
    order_0_18  connected_order_arc_712  1
    order_0_18  order_active_lb_773  1
    order_0_18  order_active_ub_774  1
    visit_0_19  out_degree_777  -1
    visit_0_19  in_degree_778  -1
    visit_0_19  order_active_lb_779  -1
    visit_0_19  order_active_ub_780  -12
    visit_0_19  service_visit_def_781  -1
    order_0_19  connected_order_arc_459  1
    order_0_19  connected_order_arc_482  1
    order_0_19  connected_order_arc_505  1
    order_0_19  connected_order_arc_528  1
    order_0_19  connected_order_arc_551  1
    order_0_19  connected_order_arc_574  1
    order_0_19  connected_order_arc_597  1
    order_0_19  connected_order_arc_620  1
    order_0_19  connected_order_arc_643  1
    order_0_19  connected_order_arc_650  -1
    order_0_19  connected_order_arc_652  -1
    order_0_19  connected_order_arc_654  -1
    order_0_19  connected_order_arc_656  -1
    order_0_19  connected_order_arc_658  -1
    order_0_19  connected_order_arc_660  -1
    order_0_19  connected_order_arc_662  -1
    order_0_19  connected_order_arc_664  -1
    order_0_19  connected_order_arc_666  -1
    order_0_19  connected_order_arc_668  -1
    order_0_19  connected_order_arc_670  -1
    order_0_19  connected_order_arc_691  1
    order_0_19  connected_order_arc_714  1
    order_0_19  order_active_lb_779  1
    order_0_19  order_active_ub_780  1
    visit_0_20  out_degree_783  -1
    visit_0_20  in_degree_784  -1
    visit_0_20  order_active_lb_785  -1
    visit_0_20  order_active_ub_786  -12
    visit_0_20  service_visit_def_787  -1
    order_0_20  connected_order_arc_461  1
    order_0_20  connected_order_arc_484  1
    order_0_20  connected_order_arc_507  1
    order_0_20  connected_order_arc_530  1
    order_0_20  connected_order_arc_553  1
    order_0_20  connected_order_arc_576  1
    order_0_20  connected_order_arc_599  1
    order_0_20  connected_order_arc_622  1
    order_0_20  connected_order_arc_645  1
    order_0_20  connected_order_arc_668  1
    order_0_20  connected_order_arc_673  -1
    order_0_20  connected_order_arc_675  -1
    order_0_20  connected_order_arc_677  -1
    order_0_20  connected_order_arc_679  -1
    order_0_20  connected_order_arc_681  -1
    order_0_20  connected_order_arc_683  -1
    order_0_20  connected_order_arc_685  -1
    order_0_20  connected_order_arc_687  -1
    order_0_20  connected_order_arc_689  -1
    order_0_20  connected_order_arc_691  -1
    order_0_20  connected_order_arc_693  -1
    order_0_20  connected_order_arc_716  1
    order_0_20  order_active_lb_785  1
    order_0_20  order_active_ub_786  1
    visit_0_21  out_degree_789  -1
    visit_0_21  in_degree_790  -1
    visit_0_21  order_active_lb_791  -1
    visit_0_21  order_active_ub_792  -12
    visit_0_21  service_visit_def_793  -1
    order_0_21  connected_order_arc_463  1
    order_0_21  connected_order_arc_486  1
    order_0_21  connected_order_arc_509  1
    order_0_21  connected_order_arc_532  1
    order_0_21  connected_order_arc_555  1
    order_0_21  connected_order_arc_578  1
    order_0_21  connected_order_arc_601  1
    order_0_21  connected_order_arc_624  1
    order_0_21  connected_order_arc_647  1
    order_0_21  connected_order_arc_670  1
    order_0_21  connected_order_arc_693  1
    order_0_21  connected_order_arc_696  -1
    order_0_21  connected_order_arc_698  -1
    order_0_21  connected_order_arc_700  -1
    order_0_21  connected_order_arc_702  -1
    order_0_21  connected_order_arc_704  -1
    order_0_21  connected_order_arc_706  -1
    order_0_21  connected_order_arc_708  -1
    order_0_21  connected_order_arc_710  -1
    order_0_21  connected_order_arc_712  -1
    order_0_21  connected_order_arc_714  -1
    order_0_21  connected_order_arc_716  -1
    order_0_21  order_active_lb_791  1
    order_0_21  order_active_ub_792  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_428  -20
    arc_0_0_0  depot_departure_or_bypass_717  1
    arc_0_0_0  depot_return_or_bypass_718  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_428  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_429  -20
    arc_0_0_1  depot_departure_or_bypass_717  1
    arc_0_0_1  in_degree_720  1
    arc_0_0_1  original_T_including_depot_unload_798  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_429  1
    load_0_0_1  segment_load_conservation_723  -1
    load_0_0_1  segment_prefix_lb_724  1
    load_0_0_1  segment_prefix_ub_725  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_430  -20
    arc_0_0_2  depot_departure_or_bypass_717  1
    arc_0_0_2  in_degree_727  1
    arc_0_0_2  original_T_including_depot_unload_798  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_430  1
    load_0_0_2  segment_load_conservation_730  -1
    load_0_0_2  segment_prefix_lb_731  1
    load_0_0_2  segment_prefix_ub_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_431  -20
    arc_0_0_3  depot_departure_or_bypass_717  1
    arc_0_0_3  in_degree_734  1
    arc_0_0_3  original_T_including_depot_unload_798  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_431  1
    load_0_0_3  segment_load_conservation_737  -1
    load_0_0_3  segment_prefix_lb_738  1
    load_0_0_3  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_432  -20
    arc_0_0_4  depot_departure_or_bypass_717  1
    arc_0_0_4  in_degree_741  1
    arc_0_0_4  original_T_including_depot_unload_798  5.4249700630778887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_432  1
    load_0_0_4  segment_load_conservation_744  -1
    load_0_0_4  segment_prefix_lb_745  1
    load_0_0_4  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_433  -20
    arc_0_0_14  depot_departure_or_bypass_717  1
    arc_0_0_14  in_degree_748  1
    arc_0_0_14  original_T_including_depot_unload_798  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_433  1
    load_0_0_14  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_434  -20
    arc_0_0_15  depot_departure_or_bypass_717  1
    arc_0_0_15  in_degree_754  1
    arc_0_0_15  original_T_including_depot_unload_798  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_434  1
    load_0_0_15  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_16  arc_capacity_435  -20
    arc_0_0_16  depot_departure_or_bypass_717  1
    arc_0_0_16  in_degree_760  1
    arc_0_0_16  original_T_including_depot_unload_798  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_16  arc_capacity_435  1
    load_0_0_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_17  arc_capacity_436  -20
    arc_0_0_17  depot_departure_or_bypass_717  1
    arc_0_0_17  in_degree_766  1
    arc_0_0_17  original_T_including_depot_unload_798  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_0_17  arc_capacity_436  1
    load_0_0_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_18  arc_capacity_437  -20
    arc_0_0_18  depot_departure_or_bypass_717  1
    arc_0_0_18  in_degree_772  1
    arc_0_0_18  original_T_including_depot_unload_798  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_18  arc_capacity_437  1
    load_0_0_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_19  arc_capacity_438  -20
    arc_0_0_19  depot_departure_or_bypass_717  1
    arc_0_0_19  in_degree_778  1
    arc_0_0_19  original_T_including_depot_unload_798  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_19  arc_capacity_438  1
    load_0_0_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_20  arc_capacity_439  -20
    arc_0_0_20  depot_departure_or_bypass_717  1
    arc_0_0_20  in_degree_784  1
    arc_0_0_20  original_T_including_depot_unload_798  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_20  arc_capacity_439  1
    load_0_0_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_21  arc_capacity_440  -20
    arc_0_0_21  depot_departure_or_bypass_717  1
    arc_0_0_21  in_degree_790  1
    arc_0_0_21  original_T_including_depot_unload_798  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_21  arc_capacity_440  1
    load_0_0_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_441  -20
    arc_0_1_0  depot_return_or_bypass_718  1
    arc_0_1_0  out_degree_719  1
    arc_0_1_0  original_T_including_depot_unload_798  2.7917022344240587e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_441  1
    load_0_1_0  segment_load_conservation_723  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_442  -20
    arc_0_1_2  connected_order_arc_443  -13
    arc_0_1_2  out_degree_719  1
    arc_0_1_2  in_degree_727  1
    arc_0_1_2  original_T_including_depot_unload_798  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_442  1
    load_0_1_2  segment_load_conservation_723  1
    load_0_1_2  segment_load_conservation_730  -1
    load_0_1_2  segment_prefix_lb_731  1
    load_0_1_2  segment_prefix_ub_732  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_444  -20
    arc_0_1_3  connected_order_arc_445  -13
    arc_0_1_3  out_degree_719  1
    arc_0_1_3  in_degree_734  1
    arc_0_1_3  original_T_including_depot_unload_798  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_444  1
    load_0_1_3  segment_load_conservation_723  1
    load_0_1_3  segment_load_conservation_737  -1
    load_0_1_3  segment_prefix_lb_738  1
    load_0_1_3  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_446  -20
    arc_0_1_4  connected_order_arc_447  -13
    arc_0_1_4  out_degree_719  1
    arc_0_1_4  in_degree_741  1
    arc_0_1_4  original_T_including_depot_unload_798  2.8529311190414518e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_446  1
    load_0_1_4  segment_load_conservation_723  1
    load_0_1_4  segment_load_conservation_744  -1
    load_0_1_4  segment_prefix_lb_745  1
    load_0_1_4  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_448  -20
    arc_0_1_14  connected_order_arc_449  -13
    arc_0_1_14  out_degree_719  1
    arc_0_1_14  in_degree_748  1
    arc_0_1_14  original_T_including_depot_unload_798  1.1841534266111569e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_448  1
    load_0_1_14  segment_load_conservation_723  1
    load_0_1_14  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_450  -20
    arc_0_1_15  connected_order_arc_451  -13
    arc_0_1_15  out_degree_719  1
    arc_0_1_15  in_degree_754  1
    arc_0_1_15  original_T_including_depot_unload_798  8.9144012844276767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_450  1
    load_0_1_15  segment_load_conservation_723  1
    load_0_1_15  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_16  arc_capacity_452  -20
    arc_0_1_16  connected_order_arc_453  -13
    arc_0_1_16  out_degree_719  1
    arc_0_1_16  in_degree_760  1
    arc_0_1_16  original_T_including_depot_unload_798  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_16  arc_capacity_452  1
    load_0_1_16  segment_load_conservation_723  1
    load_0_1_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_17  arc_capacity_454  -20
    arc_0_1_17  connected_order_arc_455  -13
    arc_0_1_17  out_degree_719  1
    arc_0_1_17  in_degree_766  1
    arc_0_1_17  original_T_including_depot_unload_798  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_17  arc_capacity_454  1
    load_0_1_17  segment_load_conservation_723  1
    load_0_1_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_18  arc_capacity_456  -20
    arc_0_1_18  connected_order_arc_457  -13
    arc_0_1_18  out_degree_719  1
    arc_0_1_18  in_degree_772  1
    arc_0_1_18  original_T_including_depot_unload_798  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_18  arc_capacity_456  1
    load_0_1_18  segment_load_conservation_723  1
    load_0_1_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_19  arc_capacity_458  -20
    arc_0_1_19  connected_order_arc_459  -13
    arc_0_1_19  out_degree_719  1
    arc_0_1_19  in_degree_778  1
    arc_0_1_19  original_T_including_depot_unload_798  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_19  arc_capacity_458  1
    load_0_1_19  segment_load_conservation_723  1
    load_0_1_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_20  arc_capacity_460  -20
    arc_0_1_20  connected_order_arc_461  -13
    arc_0_1_20  out_degree_719  1
    arc_0_1_20  in_degree_784  1
    arc_0_1_20  original_T_including_depot_unload_798  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_20  arc_capacity_460  1
    load_0_1_20  segment_load_conservation_723  1
    load_0_1_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_21  arc_capacity_462  -20
    arc_0_1_21  connected_order_arc_463  -13
    arc_0_1_21  out_degree_719  1
    arc_0_1_21  in_degree_790  1
    arc_0_1_21  original_T_including_depot_unload_798  1.3286968036345565e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_21  arc_capacity_462  1
    load_0_1_21  segment_load_conservation_723  1
    load_0_1_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_464  -20
    arc_0_2_0  depot_return_or_bypass_718  1
    arc_0_2_0  out_degree_726  1
    arc_0_2_0  original_T_including_depot_unload_798  7.2130540230577469e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_464  1
    load_0_2_0  segment_load_conservation_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_465  -20
    arc_0_2_1  connected_order_arc_466  -13
    arc_0_2_1  in_degree_720  1
    arc_0_2_1  out_degree_726  1
    arc_0_2_1  original_T_including_depot_unload_798  4.4733407106545638e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_465  1
    load_0_2_1  segment_load_conservation_723  -1
    load_0_2_1  segment_prefix_lb_724  1
    load_0_2_1  segment_prefix_ub_725  1
    load_0_2_1  segment_load_conservation_730  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_467  -20
    arc_0_2_3  connected_order_arc_468  -13
    arc_0_2_3  out_degree_726  1
    arc_0_2_3  in_degree_734  1
    arc_0_2_3  original_T_including_depot_unload_798  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_467  1
    load_0_2_3  segment_load_conservation_730  1
    load_0_2_3  segment_load_conservation_737  -1
    load_0_2_3  segment_prefix_lb_738  1
    load_0_2_3  segment_prefix_ub_739  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_469  -20
    arc_0_2_4  connected_order_arc_470  -13
    arc_0_2_4  out_degree_726  1
    arc_0_2_4  in_degree_741  1
    arc_0_2_4  original_T_including_depot_unload_798  3.2367117212973966e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_469  1
    load_0_2_4  segment_load_conservation_730  1
    load_0_2_4  segment_load_conservation_744  -1
    load_0_2_4  segment_prefix_lb_745  1
    load_0_2_4  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_471  -20
    arc_0_2_14  connected_order_arc_472  -13
    arc_0_2_14  out_degree_726  1
    arc_0_2_14  in_degree_748  1
    arc_0_2_14  original_T_including_depot_unload_798  1.0512451758357363e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_471  1
    load_0_2_14  segment_load_conservation_730  1
    load_0_2_14  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_473  -20
    arc_0_2_15  connected_order_arc_474  -13
    arc_0_2_15  out_degree_726  1
    arc_0_2_15  in_degree_754  1
    arc_0_2_15  original_T_including_depot_unload_798  8.0179544138113431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_473  1
    load_0_2_15  segment_load_conservation_730  1
    load_0_2_15  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_16  arc_capacity_475  -20
    arc_0_2_16  connected_order_arc_476  -13
    arc_0_2_16  out_degree_726  1
    arc_0_2_16  in_degree_760  1
    arc_0_2_16  original_T_including_depot_unload_798  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_16  arc_capacity_475  1
    load_0_2_16  segment_load_conservation_730  1
    load_0_2_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_17  arc_capacity_477  -20
    arc_0_2_17  connected_order_arc_478  -13
    arc_0_2_17  out_degree_726  1
    arc_0_2_17  in_degree_766  1
    arc_0_2_17  original_T_including_depot_unload_798  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_17  arc_capacity_477  1
    load_0_2_17  segment_load_conservation_730  1
    load_0_2_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_18  arc_capacity_479  -20
    arc_0_2_18  connected_order_arc_480  -13
    arc_0_2_18  out_degree_726  1
    arc_0_2_18  in_degree_772  1
    arc_0_2_18  original_T_including_depot_unload_798  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_18  arc_capacity_479  1
    load_0_2_18  segment_load_conservation_730  1
    load_0_2_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_19  arc_capacity_481  -20
    arc_0_2_19  connected_order_arc_482  -13
    arc_0_2_19  out_degree_726  1
    arc_0_2_19  in_degree_778  1
    arc_0_2_19  original_T_including_depot_unload_798  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_19  arc_capacity_481  1
    load_0_2_19  segment_load_conservation_730  1
    load_0_2_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_20  arc_capacity_483  -20
    arc_0_2_20  connected_order_arc_484  -13
    arc_0_2_20  out_degree_726  1
    arc_0_2_20  in_degree_784  1
    arc_0_2_20  original_T_including_depot_unload_798  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_20  arc_capacity_483  1
    load_0_2_20  segment_load_conservation_730  1
    load_0_2_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_21  arc_capacity_485  -20
    arc_0_2_21  connected_order_arc_486  -13
    arc_0_2_21  out_degree_726  1
    arc_0_2_21  in_degree_790  1
    arc_0_2_21  original_T_including_depot_unload_798  1.3740068502263614e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_21  arc_capacity_485  1
    load_0_2_21  segment_load_conservation_730  1
    load_0_2_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_487  -20
    arc_0_3_0  depot_return_or_bypass_718  1
    arc_0_3_0  out_degree_733  1
    arc_0_3_0  original_T_including_depot_unload_798  4.9403722507151832e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_487  1
    load_0_3_0  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_488  -20
    arc_0_3_1  connected_order_arc_489  -13
    arc_0_3_1  in_degree_720  1
    arc_0_3_1  out_degree_733  1
    arc_0_3_1  original_T_including_depot_unload_798  2.2271784981792140e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_488  1
    load_0_3_1  segment_load_conservation_723  -1
    load_0_3_1  segment_prefix_lb_724  1
    load_0_3_1  segment_prefix_ub_725  1
    load_0_3_1  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_490  -20
    arc_0_3_2  connected_order_arc_491  -13
    arc_0_3_2  in_degree_727  1
    arc_0_3_2  out_degree_733  1
    arc_0_3_2  original_T_including_depot_unload_798  2.2729932910497158e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_490  1
    load_0_3_2  segment_load_conservation_730  -1
    load_0_3_2  segment_prefix_lb_731  1
    load_0_3_2  segment_prefix_ub_732  1
    load_0_3_2  segment_load_conservation_737  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_492  -20
    arc_0_3_4  connected_order_arc_493  -13
    arc_0_3_4  out_degree_733  1
    arc_0_3_4  in_degree_741  1
    arc_0_3_4  original_T_including_depot_unload_798  2.3159636865750136e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_492  1
    load_0_3_4  segment_load_conservation_737  1
    load_0_3_4  segment_load_conservation_744  -1
    load_0_3_4  segment_prefix_lb_745  1
    load_0_3_4  segment_prefix_ub_746  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_494  -20
    arc_0_3_14  connected_order_arc_495  -13
    arc_0_3_14  out_degree_733  1
    arc_0_3_14  in_degree_748  1
    arc_0_3_14  original_T_including_depot_unload_798  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_494  1
    load_0_3_14  segment_load_conservation_737  1
    load_0_3_14  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_496  -20
    arc_0_3_15  connected_order_arc_497  -13
    arc_0_3_15  out_degree_733  1
    arc_0_3_15  in_degree_754  1
    arc_0_3_15  original_T_including_depot_unload_798  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_496  1
    load_0_3_15  segment_load_conservation_737  1
    load_0_3_15  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_16  arc_capacity_498  -20
    arc_0_3_16  connected_order_arc_499  -13
    arc_0_3_16  out_degree_733  1
    arc_0_3_16  in_degree_760  1
    arc_0_3_16  original_T_including_depot_unload_798  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_16  arc_capacity_498  1
    load_0_3_16  segment_load_conservation_737  1
    load_0_3_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_17  arc_capacity_500  -20
    arc_0_3_17  connected_order_arc_501  -13
    arc_0_3_17  out_degree_733  1
    arc_0_3_17  in_degree_766  1
    arc_0_3_17  original_T_including_depot_unload_798  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_17  arc_capacity_500  1
    load_0_3_17  segment_load_conservation_737  1
    load_0_3_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_18  arc_capacity_502  -20
    arc_0_3_18  connected_order_arc_503  -13
    arc_0_3_18  out_degree_733  1
    arc_0_3_18  in_degree_772  1
    arc_0_3_18  original_T_including_depot_unload_798  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_18  arc_capacity_502  1
    load_0_3_18  segment_load_conservation_737  1
    load_0_3_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_19  arc_capacity_504  -20
    arc_0_3_19  connected_order_arc_505  -13
    arc_0_3_19  out_degree_733  1
    arc_0_3_19  in_degree_778  1
    arc_0_3_19  original_T_including_depot_unload_798  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_19  arc_capacity_504  1
    load_0_3_19  segment_load_conservation_737  1
    load_0_3_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_20  arc_capacity_506  -20
    arc_0_3_20  connected_order_arc_507  -13
    arc_0_3_20  out_degree_733  1
    arc_0_3_20  in_degree_784  1
    arc_0_3_20  original_T_including_depot_unload_798  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_20  arc_capacity_506  1
    load_0_3_20  segment_load_conservation_737  1
    load_0_3_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_21  arc_capacity_508  -20
    arc_0_3_21  connected_order_arc_509  -13
    arc_0_3_21  out_degree_733  1
    arc_0_3_21  in_degree_790  1
    arc_0_3_21  original_T_including_depot_unload_798  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_21  arc_capacity_508  1
    load_0_3_21  segment_load_conservation_737  1
    load_0_3_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_510  -20
    arc_0_4_0  depot_return_or_bypass_718  1
    arc_0_4_0  out_degree_740  1
    arc_0_4_0  original_T_including_depot_unload_798  4.6364706268001146e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_510  1
    load_0_4_0  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_511  -20
    arc_0_4_1  connected_order_arc_512  -13
    arc_0_4_1  in_degree_720  1
    arc_0_4_1  out_degree_740  1
    arc_0_4_1  original_T_including_depot_unload_798  6.7517249538835438e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_511  1
    load_0_4_1  segment_load_conservation_723  -1
    load_0_4_1  segment_prefix_lb_724  1
    load_0_4_1  segment_prefix_ub_725  1
    load_0_4_1  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_513  -20
    arc_0_4_2  connected_order_arc_514  -13
    arc_0_4_2  in_degree_727  1
    arc_0_4_2  out_degree_740  1
    arc_0_4_2  original_T_including_depot_unload_798  1.1090437276384578e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_513  1
    load_0_4_2  segment_load_conservation_730  -1
    load_0_4_2  segment_prefix_lb_731  1
    load_0_4_2  segment_prefix_ub_732  1
    load_0_4_2  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_515  -20
    arc_0_4_3  connected_order_arc_516  -13
    arc_0_4_3  in_degree_734  1
    arc_0_4_3  out_degree_740  1
    arc_0_4_3  original_T_including_depot_unload_798  8.9433085313747858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_515  1
    load_0_4_3  segment_load_conservation_737  -1
    load_0_4_3  segment_prefix_lb_738  1
    load_0_4_3  segment_prefix_ub_739  1
    load_0_4_3  segment_load_conservation_744  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_517  -20
    arc_0_4_14  connected_order_arc_518  -13
    arc_0_4_14  out_degree_740  1
    arc_0_4_14  in_degree_748  1
    arc_0_4_14  original_T_including_depot_unload_798  1.7352108528200517e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_517  1
    load_0_4_14  segment_load_conservation_744  1
    load_0_4_14  free_load_conservation_752  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_519  -20
    arc_0_4_15  connected_order_arc_520  -13
    arc_0_4_15  out_degree_740  1
    arc_0_4_15  in_degree_754  1
    arc_0_4_15  original_T_including_depot_unload_798  1.4462606207080505e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_519  1
    load_0_4_15  segment_load_conservation_744  1
    load_0_4_15  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_16  arc_capacity_521  -20
    arc_0_4_16  connected_order_arc_522  -13
    arc_0_4_16  out_degree_740  1
    arc_0_4_16  in_degree_760  1
    arc_0_4_16  original_T_including_depot_unload_798  1075.72043838369
    MARKER    'MARKER'                 'INTEND'
    load_0_4_16  arc_capacity_521  1
    load_0_4_16  segment_load_conservation_744  1
    load_0_4_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_17  arc_capacity_523  -20
    arc_0_4_17  connected_order_arc_524  -13
    arc_0_4_17  out_degree_740  1
    arc_0_4_17  in_degree_766  1
    arc_0_4_17  original_T_including_depot_unload_798  1.3473492742338772e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_17  arc_capacity_523  1
    load_0_4_17  segment_load_conservation_744  1
    load_0_4_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_18  arc_capacity_525  -20
    arc_0_4_18  connected_order_arc_526  -13
    arc_0_4_18  out_degree_740  1
    arc_0_4_18  in_degree_772  1
    arc_0_4_18  original_T_including_depot_unload_798  1.0491196843462671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_18  arc_capacity_525  1
    load_0_4_18  segment_load_conservation_744  1
    load_0_4_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_19  arc_capacity_527  -20
    arc_0_4_19  connected_order_arc_528  -13
    arc_0_4_19  out_degree_740  1
    arc_0_4_19  in_degree_778  1
    arc_0_4_19  original_T_including_depot_unload_798  1.2399741997148888e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_19  arc_capacity_527  1
    load_0_4_19  segment_load_conservation_744  1
    load_0_4_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_20  arc_capacity_529  -20
    arc_0_4_20  connected_order_arc_530  -13
    arc_0_4_20  out_degree_740  1
    arc_0_4_20  in_degree_784  1
    arc_0_4_20  original_T_including_depot_unload_798  9.1576870176747968e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_20  arc_capacity_529  1
    load_0_4_20  segment_load_conservation_744  1
    load_0_4_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_21  arc_capacity_531  -20
    arc_0_4_21  connected_order_arc_532  -13
    arc_0_4_21  out_degree_740  1
    arc_0_4_21  in_degree_790  1
    arc_0_4_21  original_T_including_depot_unload_798  1.7000764266516874e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_21  arc_capacity_531  1
    load_0_4_21  segment_load_conservation_744  1
    load_0_4_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_533  -20
    arc_0_14_0  depot_return_or_bypass_718  1
    arc_0_14_0  out_degree_747  1
    arc_0_14_0  original_T_including_depot_unload_798  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_533  1
    load_0_14_0  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_534  -20
    arc_0_14_1  connected_order_arc_535  -13
    arc_0_14_1  in_degree_720  1
    arc_0_14_1  out_degree_747  1
    arc_0_14_1  original_T_including_depot_unload_798  1.1841534266111569e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_534  1
    load_0_14_1  segment_load_conservation_723  -1
    load_0_14_1  segment_prefix_lb_724  1
    load_0_14_1  segment_prefix_ub_725  1
    load_0_14_1  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_536  -20
    arc_0_14_2  connected_order_arc_537  -13
    arc_0_14_2  in_degree_727  1
    arc_0_14_2  out_degree_747  1
    arc_0_14_2  original_T_including_depot_unload_798  1.0512451758357363e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_536  1
    load_0_14_2  segment_load_conservation_730  -1
    load_0_14_2  segment_prefix_lb_731  1
    load_0_14_2  segment_prefix_ub_732  1
    load_0_14_2  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_538  -20
    arc_0_14_3  connected_order_arc_539  -13
    arc_0_14_3  in_degree_734  1
    arc_0_14_3  out_degree_747  1
    arc_0_14_3  original_T_including_depot_unload_798  1.0744643606639036e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_538  1
    load_0_14_3  segment_load_conservation_737  -1
    load_0_14_3  segment_prefix_lb_738  1
    load_0_14_3  segment_prefix_ub_739  1
    load_0_14_3  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_540  -20
    arc_0_14_4  connected_order_arc_541  -13
    arc_0_14_4  in_degree_741  1
    arc_0_14_4  out_degree_747  1
    arc_0_14_4  original_T_including_depot_unload_798  1.3017299317625136e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_540  1
    load_0_14_4  segment_load_conservation_744  -1
    load_0_14_4  segment_prefix_lb_745  1
    load_0_14_4  segment_prefix_ub_746  1
    load_0_14_4  free_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_542  -20
    arc_0_14_15  connected_order_arc_543  -13
    arc_0_14_15  out_degree_747  1
    arc_0_14_15  in_degree_754  1
    arc_0_14_15  original_T_including_depot_unload_798  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_542  1
    load_0_14_15  free_load_conservation_752  1
    load_0_14_15  free_load_conservation_758  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_16  arc_capacity_544  -20
    arc_0_14_16  connected_order_arc_545  -13
    arc_0_14_16  out_degree_747  1
    arc_0_14_16  in_degree_760  1
    arc_0_14_16  original_T_including_depot_unload_798  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_16  arc_capacity_544  1
    load_0_14_16  free_load_conservation_752  1
    load_0_14_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_17  arc_capacity_546  -20
    arc_0_14_17  connected_order_arc_547  -13
    arc_0_14_17  out_degree_747  1
    arc_0_14_17  in_degree_766  1
    arc_0_14_17  original_T_including_depot_unload_798  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_17  arc_capacity_546  1
    load_0_14_17  free_load_conservation_752  1
    load_0_14_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_18  arc_capacity_548  -20
    arc_0_14_18  connected_order_arc_549  -13
    arc_0_14_18  out_degree_747  1
    arc_0_14_18  in_degree_772  1
    arc_0_14_18  original_T_including_depot_unload_798  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_18  arc_capacity_548  1
    load_0_14_18  free_load_conservation_752  1
    load_0_14_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_19  arc_capacity_550  -20
    arc_0_14_19  connected_order_arc_551  -13
    arc_0_14_19  out_degree_747  1
    arc_0_14_19  in_degree_778  1
    arc_0_14_19  original_T_including_depot_unload_798  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_19  arc_capacity_550  1
    load_0_14_19  free_load_conservation_752  1
    load_0_14_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_20  arc_capacity_552  -20
    arc_0_14_20  connected_order_arc_553  -13
    arc_0_14_20  out_degree_747  1
    arc_0_14_20  in_degree_784  1
    arc_0_14_20  original_T_including_depot_unload_798  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_20  arc_capacity_552  1
    load_0_14_20  free_load_conservation_752  1
    load_0_14_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_21  arc_capacity_554  -20
    arc_0_14_21  connected_order_arc_555  -13
    arc_0_14_21  out_degree_747  1
    arc_0_14_21  in_degree_790  1
    arc_0_14_21  original_T_including_depot_unload_798  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_21  arc_capacity_554  1
    load_0_14_21  free_load_conservation_752  1
    load_0_14_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_556  -20
    arc_0_15_0  depot_return_or_bypass_718  1
    arc_0_15_0  out_degree_753  1
    arc_0_15_0  original_T_including_depot_unload_798  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_556  1
    load_0_15_0  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_557  -20
    arc_0_15_1  connected_order_arc_558  -13
    arc_0_15_1  in_degree_720  1
    arc_0_15_1  out_degree_753  1
    arc_0_15_1  original_T_including_depot_unload_798  8.9144012844276767e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_557  1
    load_0_15_1  segment_load_conservation_723  -1
    load_0_15_1  segment_prefix_lb_724  1
    load_0_15_1  segment_prefix_ub_725  1
    load_0_15_1  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_559  -20
    arc_0_15_2  connected_order_arc_560  -13
    arc_0_15_2  in_degree_727  1
    arc_0_15_2  out_degree_753  1
    arc_0_15_2  original_T_including_depot_unload_798  8.0179544138113431e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_559  1
    load_0_15_2  segment_load_conservation_730  -1
    load_0_15_2  segment_prefix_lb_731  1
    load_0_15_2  segment_prefix_ub_732  1
    load_0_15_2  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_561  -20
    arc_0_15_3  connected_order_arc_562  -13
    arc_0_15_3  in_degree_734  1
    arc_0_15_3  out_degree_753  1
    arc_0_15_3  original_T_including_depot_unload_798  7.9428057689531045e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_561  1
    load_0_15_3  segment_load_conservation_737  -1
    load_0_15_3  segment_prefix_lb_738  1
    load_0_15_3  segment_prefix_ub_739  1
    load_0_15_3  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_563  -20
    arc_0_15_4  connected_order_arc_564  -13
    arc_0_15_4  in_degree_741  1
    arc_0_15_4  out_degree_753  1
    arc_0_15_4  original_T_including_depot_unload_798  1.0246875893625959e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_563  1
    load_0_15_4  segment_load_conservation_744  -1
    load_0_15_4  segment_prefix_lb_745  1
    load_0_15_4  segment_prefix_ub_746  1
    load_0_15_4  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_565  -20
    arc_0_15_14  connected_order_arc_566  -13
    arc_0_15_14  in_degree_748  1
    arc_0_15_14  out_degree_753  1
    arc_0_15_14  original_T_including_depot_unload_798  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_565  1
    load_0_15_14  free_load_conservation_752  -1
    load_0_15_14  free_load_conservation_758  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_16  arc_capacity_567  -20
    arc_0_15_16  connected_order_arc_568  -13
    arc_0_15_16  out_degree_753  1
    arc_0_15_16  in_degree_760  1
    arc_0_15_16  original_T_including_depot_unload_798  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_16  arc_capacity_567  1
    load_0_15_16  free_load_conservation_758  1
    load_0_15_16  free_load_conservation_764  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_17  arc_capacity_569  -20
    arc_0_15_17  connected_order_arc_570  -13
    arc_0_15_17  out_degree_753  1
    arc_0_15_17  in_degree_766  1
    arc_0_15_17  original_T_including_depot_unload_798  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_17  arc_capacity_569  1
    load_0_15_17  free_load_conservation_758  1
    load_0_15_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_18  arc_capacity_571  -20
    arc_0_15_18  connected_order_arc_572  -13
    arc_0_15_18  out_degree_753  1
    arc_0_15_18  in_degree_772  1
    arc_0_15_18  original_T_including_depot_unload_798  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_18  arc_capacity_571  1
    load_0_15_18  free_load_conservation_758  1
    load_0_15_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_19  arc_capacity_573  -20
    arc_0_15_19  connected_order_arc_574  -13
    arc_0_15_19  out_degree_753  1
    arc_0_15_19  in_degree_778  1
    arc_0_15_19  original_T_including_depot_unload_798  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_19  arc_capacity_573  1
    load_0_15_19  free_load_conservation_758  1
    load_0_15_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_20  arc_capacity_575  -20
    arc_0_15_20  connected_order_arc_576  -13
    arc_0_15_20  out_degree_753  1
    arc_0_15_20  in_degree_784  1
    arc_0_15_20  original_T_including_depot_unload_798  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_20  arc_capacity_575  1
    load_0_15_20  free_load_conservation_758  1
    load_0_15_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_21  arc_capacity_577  -20
    arc_0_15_21  connected_order_arc_578  -13
    arc_0_15_21  out_degree_753  1
    arc_0_15_21  in_degree_790  1
    arc_0_15_21  original_T_including_depot_unload_798  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_21  arc_capacity_577  1
    load_0_15_21  free_load_conservation_758  1
    load_0_15_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_0  arc_capacity_579  -20
    arc_0_16_0  depot_return_or_bypass_718  1
    arc_0_16_0  out_degree_759  1
    arc_0_16_0  original_T_including_depot_unload_798  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_0  arc_capacity_579  1
    load_0_16_0  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_1  arc_capacity_580  -20
    arc_0_16_1  connected_order_arc_581  -13
    arc_0_16_1  in_degree_720  1
    arc_0_16_1  out_degree_759  1
    arc_0_16_1  original_T_including_depot_unload_798  1.3427889817767334e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_1  arc_capacity_580  1
    load_0_16_1  segment_load_conservation_723  -1
    load_0_16_1  segment_prefix_lb_724  1
    load_0_16_1  segment_prefix_ub_725  1
    load_0_16_1  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_2  arc_capacity_582  -20
    arc_0_16_2  connected_order_arc_583  -13
    arc_0_16_2  in_degree_727  1
    arc_0_16_2  out_degree_759  1
    arc_0_16_2  original_T_including_depot_unload_798  1.7303231472353602e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_2  arc_capacity_582  1
    load_0_16_2  segment_load_conservation_730  -1
    load_0_16_2  segment_prefix_lb_731  1
    load_0_16_2  segment_prefix_ub_732  1
    load_0_16_2  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_3  arc_capacity_584  -20
    arc_0_16_3  connected_order_arc_585  -13
    arc_0_16_3  in_degree_734  1
    arc_0_16_3  out_degree_759  1
    arc_0_16_3  original_T_including_depot_unload_798  1.5184659007075070e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_3  arc_capacity_584  1
    load_0_16_3  segment_load_conservation_737  -1
    load_0_16_3  segment_prefix_lb_738  1
    load_0_16_3  segment_prefix_ub_739  1
    load_0_16_3  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_4  arc_capacity_586  -20
    arc_0_16_4  connected_order_arc_587  -13
    arc_0_16_4  in_degree_741  1
    arc_0_16_4  out_degree_759  1
    arc_0_16_4  original_T_including_depot_unload_798  1.6231508478292610e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_4  arc_capacity_586  1
    load_0_16_4  segment_load_conservation_744  -1
    load_0_16_4  segment_prefix_lb_745  1
    load_0_16_4  segment_prefix_ub_746  1
    load_0_16_4  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_14  arc_capacity_588  -20
    arc_0_16_14  connected_order_arc_589  -13
    arc_0_16_14  in_degree_748  1
    arc_0_16_14  out_degree_759  1
    arc_0_16_14  original_T_including_depot_unload_798  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_14  arc_capacity_588  1
    load_0_16_14  free_load_conservation_752  -1
    load_0_16_14  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_15  arc_capacity_590  -20
    arc_0_16_15  connected_order_arc_591  -13
    arc_0_16_15  in_degree_754  1
    arc_0_16_15  out_degree_759  1
    arc_0_16_15  original_T_including_depot_unload_798  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_15  arc_capacity_590  1
    load_0_16_15  free_load_conservation_758  -1
    load_0_16_15  free_load_conservation_764  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_17  arc_capacity_592  -20
    arc_0_16_17  connected_order_arc_593  -13
    arc_0_16_17  out_degree_759  1
    arc_0_16_17  in_degree_766  1
    arc_0_16_17  original_T_including_depot_unload_798  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_17  arc_capacity_592  1
    load_0_16_17  free_load_conservation_764  1
    load_0_16_17  free_load_conservation_770  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_18  arc_capacity_594  -20
    arc_0_16_18  connected_order_arc_595  -13
    arc_0_16_18  out_degree_759  1
    arc_0_16_18  in_degree_772  1
    arc_0_16_18  original_T_including_depot_unload_798  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_18  arc_capacity_594  1
    load_0_16_18  free_load_conservation_764  1
    load_0_16_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_19  arc_capacity_596  -20
    arc_0_16_19  connected_order_arc_597  -13
    arc_0_16_19  out_degree_759  1
    arc_0_16_19  in_degree_778  1
    arc_0_16_19  original_T_including_depot_unload_798  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_19  arc_capacity_596  1
    load_0_16_19  free_load_conservation_764  1
    load_0_16_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_20  arc_capacity_598  -20
    arc_0_16_20  connected_order_arc_599  -13
    arc_0_16_20  out_degree_759  1
    arc_0_16_20  in_degree_784  1
    arc_0_16_20  original_T_including_depot_unload_798  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_20  arc_capacity_598  1
    load_0_16_20  free_load_conservation_764  1
    load_0_16_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_16_21  arc_capacity_600  -20
    arc_0_16_21  connected_order_arc_601  -13
    arc_0_16_21  out_degree_759  1
    arc_0_16_21  in_degree_790  1
    arc_0_16_21  original_T_including_depot_unload_798  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_16_21  arc_capacity_600  1
    load_0_16_21  free_load_conservation_764  1
    load_0_16_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_0  arc_capacity_602  -20
    arc_0_17_0  depot_return_or_bypass_718  1
    arc_0_17_0  out_degree_765  1
    arc_0_17_0  original_T_including_depot_unload_798  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_0_17_0  arc_capacity_602  1
    load_0_17_0  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_1  arc_capacity_603  -20
    arc_0_17_1  connected_order_arc_604  -13
    arc_0_17_1  in_degree_720  1
    arc_0_17_1  out_degree_765  1
    arc_0_17_1  original_T_including_depot_unload_798  7.8495921746600118e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_1  arc_capacity_603  1
    load_0_17_1  segment_load_conservation_723  -1
    load_0_17_1  segment_prefix_lb_724  1
    load_0_17_1  segment_prefix_ub_725  1
    load_0_17_1  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_2  arc_capacity_605  -20
    arc_0_17_2  connected_order_arc_606  -13
    arc_0_17_2  in_degree_727  1
    arc_0_17_2  out_degree_765  1
    arc_0_17_2  original_T_including_depot_unload_798  7.1006591329511764e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_2  arc_capacity_605  1
    load_0_17_2  segment_load_conservation_730  -1
    load_0_17_2  segment_prefix_lb_731  1
    load_0_17_2  segment_prefix_ub_732  1
    load_0_17_2  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_3  arc_capacity_607  -20
    arc_0_17_3  connected_order_arc_608  -13
    arc_0_17_3  in_degree_734  1
    arc_0_17_3  out_degree_765  1
    arc_0_17_3  original_T_including_depot_unload_798  6.9052982730578867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_3  arc_capacity_607  1
    load_0_17_3  segment_load_conservation_737  -1
    load_0_17_3  segment_prefix_lb_738  1
    load_0_17_3  segment_prefix_ub_739  1
    load_0_17_3  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_4  arc_capacity_609  -20
    arc_0_17_4  connected_order_arc_610  -13
    arc_0_17_4  in_degree_741  1
    arc_0_17_4  out_degree_765  1
    arc_0_17_4  original_T_including_depot_unload_798  9.2153450304618127e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_4  arc_capacity_609  1
    load_0_17_4  segment_load_conservation_744  -1
    load_0_17_4  segment_prefix_lb_745  1
    load_0_17_4  segment_prefix_ub_746  1
    load_0_17_4  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_14  arc_capacity_611  -20
    arc_0_17_14  connected_order_arc_612  -13
    arc_0_17_14  in_degree_748  1
    arc_0_17_14  out_degree_765  1
    arc_0_17_14  original_T_including_depot_unload_798  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_14  arc_capacity_611  1
    load_0_17_14  free_load_conservation_752  -1
    load_0_17_14  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_15  arc_capacity_613  -20
    arc_0_17_15  connected_order_arc_614  -13
    arc_0_17_15  in_degree_754  1
    arc_0_17_15  out_degree_765  1
    arc_0_17_15  original_T_including_depot_unload_798  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_15  arc_capacity_613  1
    load_0_17_15  free_load_conservation_758  -1
    load_0_17_15  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_16  arc_capacity_615  -20
    arc_0_17_16  connected_order_arc_616  -13
    arc_0_17_16  in_degree_760  1
    arc_0_17_16  out_degree_765  1
    arc_0_17_16  original_T_including_depot_unload_798  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_17_16  arc_capacity_615  1
    load_0_17_16  free_load_conservation_764  -1
    load_0_17_16  free_load_conservation_770  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_18  arc_capacity_617  -20
    arc_0_17_18  connected_order_arc_618  -13
    arc_0_17_18  out_degree_765  1
    arc_0_17_18  in_degree_772  1
    arc_0_17_18  original_T_including_depot_unload_798  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_18  arc_capacity_617  1
    load_0_17_18  free_load_conservation_770  1
    load_0_17_18  free_load_conservation_776  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_19  arc_capacity_619  -20
    arc_0_17_19  connected_order_arc_620  -13
    arc_0_17_19  out_degree_765  1
    arc_0_17_19  in_degree_778  1
    arc_0_17_19  original_T_including_depot_unload_798  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_19  arc_capacity_619  1
    load_0_17_19  free_load_conservation_770  1
    load_0_17_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_20  arc_capacity_621  -20
    arc_0_17_20  connected_order_arc_622  -13
    arc_0_17_20  out_degree_765  1
    arc_0_17_20  in_degree_784  1
    arc_0_17_20  original_T_including_depot_unload_798  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_0_17_20  arc_capacity_621  1
    load_0_17_20  free_load_conservation_770  1
    load_0_17_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_17_21  arc_capacity_623  -20
    arc_0_17_21  connected_order_arc_624  -13
    arc_0_17_21  out_degree_765  1
    arc_0_17_21  in_degree_790  1
    arc_0_17_21  original_T_including_depot_unload_798  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_17_21  arc_capacity_623  1
    load_0_17_21  free_load_conservation_770  1
    load_0_17_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_0  arc_capacity_625  -20
    arc_0_18_0  depot_return_or_bypass_718  1
    arc_0_18_0  out_degree_771  1
    arc_0_18_0  original_T_including_depot_unload_798  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_0  arc_capacity_625  1
    load_0_18_0  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_1  arc_capacity_626  -20
    arc_0_18_1  connected_order_arc_627  -13
    arc_0_18_1  in_degree_720  1
    arc_0_18_1  out_degree_771  1
    arc_0_18_1  original_T_including_depot_unload_798  4.5128490093732506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_1  arc_capacity_626  1
    load_0_18_1  segment_load_conservation_723  -1
    load_0_18_1  segment_prefix_lb_724  1
    load_0_18_1  segment_prefix_ub_725  1
    load_0_18_1  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_2  arc_capacity_628  -20
    arc_0_18_2  connected_order_arc_629  -13
    arc_0_18_2  in_degree_727  1
    arc_0_18_2  out_degree_771  1
    arc_0_18_2  original_T_including_depot_unload_798  4.6128219015626763e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_2  arc_capacity_628  1
    load_0_18_2  segment_load_conservation_730  -1
    load_0_18_2  segment_prefix_lb_731  1
    load_0_18_2  segment_prefix_ub_732  1
    load_0_18_2  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_3  arc_capacity_630  -20
    arc_0_18_3  connected_order_arc_631  -13
    arc_0_18_3  in_degree_734  1
    arc_0_18_3  out_degree_771  1
    arc_0_18_3  original_T_including_depot_unload_798  3.7315439746742123e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_3  arc_capacity_630  1
    load_0_18_3  segment_load_conservation_737  -1
    load_0_18_3  segment_prefix_lb_738  1
    load_0_18_3  segment_prefix_ub_739  1
    load_0_18_3  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_4  arc_capacity_632  -20
    arc_0_18_4  connected_order_arc_633  -13
    arc_0_18_4  in_degree_741  1
    arc_0_18_4  out_degree_771  1
    arc_0_18_4  original_T_including_depot_unload_798  603.649383070884
    MARKER    'MARKER'                 'INTEND'
    load_0_18_4  arc_capacity_632  1
    load_0_18_4  segment_load_conservation_744  -1
    load_0_18_4  segment_prefix_lb_745  1
    load_0_18_4  segment_prefix_ub_746  1
    load_0_18_4  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_14  arc_capacity_634  -20
    arc_0_18_14  connected_order_arc_635  -13
    arc_0_18_14  in_degree_748  1
    arc_0_18_14  out_degree_771  1
    arc_0_18_14  original_T_including_depot_unload_798  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_14  arc_capacity_634  1
    load_0_18_14  free_load_conservation_752  -1
    load_0_18_14  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_15  arc_capacity_636  -20
    arc_0_18_15  connected_order_arc_637  -13
    arc_0_18_15  in_degree_754  1
    arc_0_18_15  out_degree_771  1
    arc_0_18_15  original_T_including_depot_unload_798  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_15  arc_capacity_636  1
    load_0_18_15  free_load_conservation_758  -1
    load_0_18_15  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_16  arc_capacity_638  -20
    arc_0_18_16  connected_order_arc_639  -13
    arc_0_18_16  in_degree_760  1
    arc_0_18_16  out_degree_771  1
    arc_0_18_16  original_T_including_depot_unload_798  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_16  arc_capacity_638  1
    load_0_18_16  free_load_conservation_764  -1
    load_0_18_16  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_17  arc_capacity_640  -20
    arc_0_18_17  connected_order_arc_641  -13
    arc_0_18_17  in_degree_766  1
    arc_0_18_17  out_degree_771  1
    arc_0_18_17  original_T_including_depot_unload_798  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_17  arc_capacity_640  1
    load_0_18_17  free_load_conservation_770  -1
    load_0_18_17  free_load_conservation_776  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_19  arc_capacity_642  -20
    arc_0_18_19  connected_order_arc_643  -13
    arc_0_18_19  out_degree_771  1
    arc_0_18_19  in_degree_778  1
    arc_0_18_19  original_T_including_depot_unload_798  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_19  arc_capacity_642  1
    load_0_18_19  free_load_conservation_776  1
    load_0_18_19  free_load_conservation_782  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_20  arc_capacity_644  -20
    arc_0_18_20  connected_order_arc_645  -13
    arc_0_18_20  out_degree_771  1
    arc_0_18_20  in_degree_784  1
    arc_0_18_20  original_T_including_depot_unload_798  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_18_20  arc_capacity_644  1
    load_0_18_20  free_load_conservation_776  1
    load_0_18_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_18_21  arc_capacity_646  -20
    arc_0_18_21  connected_order_arc_647  -13
    arc_0_18_21  out_degree_771  1
    arc_0_18_21  in_degree_790  1
    arc_0_18_21  original_T_including_depot_unload_798  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_18_21  arc_capacity_646  1
    load_0_18_21  free_load_conservation_776  1
    load_0_18_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_0  arc_capacity_648  -20
    arc_0_19_0  depot_return_or_bypass_718  1
    arc_0_19_0  out_degree_777  1
    arc_0_19_0  original_T_including_depot_unload_798  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_0  arc_capacity_648  1
    load_0_19_0  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_1  arc_capacity_649  -20
    arc_0_19_1  connected_order_arc_650  -13
    arc_0_19_1  in_degree_720  1
    arc_0_19_1  out_degree_777  1
    arc_0_19_1  original_T_including_depot_unload_798  6.9726539003798837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_1  arc_capacity_649  1
    load_0_19_1  segment_load_conservation_723  -1
    load_0_19_1  segment_prefix_lb_724  1
    load_0_19_1  segment_prefix_ub_725  1
    load_0_19_1  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_2  arc_capacity_651  -20
    arc_0_19_2  connected_order_arc_652  -13
    arc_0_19_2  in_degree_727  1
    arc_0_19_2  out_degree_777  1
    arc_0_19_2  original_T_including_depot_unload_798  6.7959844792905335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_2  arc_capacity_651  1
    load_0_19_2  segment_load_conservation_730  -1
    load_0_19_2  segment_prefix_lb_731  1
    load_0_19_2  segment_prefix_ub_732  1
    load_0_19_2  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_3  arc_capacity_653  -20
    arc_0_19_3  connected_order_arc_654  -13
    arc_0_19_3  in_degree_734  1
    arc_0_19_3  out_degree_777  1
    arc_0_19_3  original_T_including_depot_unload_798  6.2673846095782926e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_3  arc_capacity_653  1
    load_0_19_3  segment_load_conservation_737  -1
    load_0_19_3  segment_prefix_lb_738  1
    load_0_19_3  segment_prefix_ub_739  1
    load_0_19_3  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_4  arc_capacity_655  -20
    arc_0_19_4  connected_order_arc_656  -13
    arc_0_19_4  in_degree_741  1
    arc_0_19_4  out_degree_777  1
    arc_0_19_4  original_T_including_depot_unload_798  8.5807018379884664e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_4  arc_capacity_655  1
    load_0_19_4  segment_load_conservation_744  -1
    load_0_19_4  segment_prefix_lb_745  1
    load_0_19_4  segment_prefix_ub_746  1
    load_0_19_4  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_14  arc_capacity_657  -20
    arc_0_19_14  connected_order_arc_658  -13
    arc_0_19_14  in_degree_748  1
    arc_0_19_14  out_degree_777  1
    arc_0_19_14  original_T_including_depot_unload_798  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_14  arc_capacity_657  1
    load_0_19_14  free_load_conservation_752  -1
    load_0_19_14  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_15  arc_capacity_659  -20
    arc_0_19_15  connected_order_arc_660  -13
    arc_0_19_15  in_degree_754  1
    arc_0_19_15  out_degree_777  1
    arc_0_19_15  original_T_including_depot_unload_798  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_15  arc_capacity_659  1
    load_0_19_15  free_load_conservation_758  -1
    load_0_19_15  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_16  arc_capacity_661  -20
    arc_0_19_16  connected_order_arc_662  -13
    arc_0_19_16  in_degree_760  1
    arc_0_19_16  out_degree_777  1
    arc_0_19_16  original_T_including_depot_unload_798  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_19_16  arc_capacity_661  1
    load_0_19_16  free_load_conservation_764  -1
    load_0_19_16  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_17  arc_capacity_663  -20
    arc_0_19_17  connected_order_arc_664  -13
    arc_0_19_17  in_degree_766  1
    arc_0_19_17  out_degree_777  1
    arc_0_19_17  original_T_including_depot_unload_798  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_17  arc_capacity_663  1
    load_0_19_17  free_load_conservation_770  -1
    load_0_19_17  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_18  arc_capacity_665  -20
    arc_0_19_18  connected_order_arc_666  -13
    arc_0_19_18  in_degree_772  1
    arc_0_19_18  out_degree_777  1
    arc_0_19_18  original_T_including_depot_unload_798  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_18  arc_capacity_665  1
    load_0_19_18  free_load_conservation_776  -1
    load_0_19_18  free_load_conservation_782  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_20  arc_capacity_667  -20
    arc_0_19_20  connected_order_arc_668  -13
    arc_0_19_20  out_degree_777  1
    arc_0_19_20  in_degree_784  1
    arc_0_19_20  original_T_including_depot_unload_798  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_0_19_20  arc_capacity_667  1
    load_0_19_20  free_load_conservation_782  1
    load_0_19_20  free_load_conservation_788  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_19_21  arc_capacity_669  -20
    arc_0_19_21  connected_order_arc_670  -13
    arc_0_19_21  out_degree_777  1
    arc_0_19_21  in_degree_790  1
    arc_0_19_21  original_T_including_depot_unload_798  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_19_21  arc_capacity_669  1
    load_0_19_21  free_load_conservation_782  1
    load_0_19_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_0  arc_capacity_671  -20
    arc_0_20_0  depot_return_or_bypass_718  1
    arc_0_20_0  out_degree_783  1
    arc_0_20_0  original_T_including_depot_unload_798  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_0  arc_capacity_671  1
    load_0_20_0  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_1  arc_capacity_672  -20
    arc_0_20_1  connected_order_arc_673  -13
    arc_0_20_1  in_degree_720  1
    arc_0_20_1  out_degree_783  1
    arc_0_20_1  original_T_including_depot_unload_798  1.5902582434549993e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_1  arc_capacity_672  1
    load_0_20_1  segment_load_conservation_723  -1
    load_0_20_1  segment_prefix_lb_724  1
    load_0_20_1  segment_prefix_ub_725  1
    load_0_20_1  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_2  arc_capacity_674  -20
    arc_0_20_2  connected_order_arc_675  -13
    arc_0_20_2  in_degree_727  1
    arc_0_20_2  out_degree_783  1
    arc_0_20_2  original_T_including_depot_unload_798  2.0162129512771592e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_2  arc_capacity_674  1
    load_0_20_2  segment_load_conservation_730  -1
    load_0_20_2  segment_prefix_lb_731  1
    load_0_20_2  segment_prefix_ub_732  1
    load_0_20_2  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_3  arc_capacity_676  -20
    arc_0_20_3  connected_order_arc_677  -13
    arc_0_20_3  in_degree_734  1
    arc_0_20_3  out_degree_783  1
    arc_0_20_3  original_T_including_depot_unload_798  1.8073464544423741e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_3  arc_capacity_676  1
    load_0_20_3  segment_load_conservation_737  -1
    load_0_20_3  segment_prefix_lb_738  1
    load_0_20_3  segment_prefix_ub_739  1
    load_0_20_3  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_4  arc_capacity_678  -20
    arc_0_20_4  connected_order_arc_679  -13
    arc_0_20_4  in_degree_741  1
    arc_0_20_4  out_degree_783  1
    arc_0_20_4  original_T_including_depot_unload_798  1.7249161387293191e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_4  arc_capacity_678  1
    load_0_20_4  segment_load_conservation_744  -1
    load_0_20_4  segment_prefix_lb_745  1
    load_0_20_4  segment_prefix_ub_746  1
    load_0_20_4  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_14  arc_capacity_680  -20
    arc_0_20_14  connected_order_arc_681  -13
    arc_0_20_14  in_degree_748  1
    arc_0_20_14  out_degree_783  1
    arc_0_20_14  original_T_including_depot_unload_798  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_14  arc_capacity_680  1
    load_0_20_14  free_load_conservation_752  -1
    load_0_20_14  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_15  arc_capacity_682  -20
    arc_0_20_15  connected_order_arc_683  -13
    arc_0_20_15  in_degree_754  1
    arc_0_20_15  out_degree_783  1
    arc_0_20_15  original_T_including_depot_unload_798  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_15  arc_capacity_682  1
    load_0_20_15  free_load_conservation_758  -1
    load_0_20_15  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_16  arc_capacity_684  -20
    arc_0_20_16  connected_order_arc_685  -13
    arc_0_20_16  in_degree_760  1
    arc_0_20_16  out_degree_783  1
    arc_0_20_16  original_T_including_depot_unload_798  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_16  arc_capacity_684  1
    load_0_20_16  free_load_conservation_764  -1
    load_0_20_16  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_17  arc_capacity_686  -20
    arc_0_20_17  connected_order_arc_687  -13
    arc_0_20_17  in_degree_766  1
    arc_0_20_17  out_degree_783  1
    arc_0_20_17  original_T_including_depot_unload_798  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_0_20_17  arc_capacity_686  1
    load_0_20_17  free_load_conservation_770  -1
    load_0_20_17  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_18  arc_capacity_688  -20
    arc_0_20_18  connected_order_arc_689  -13
    arc_0_20_18  in_degree_772  1
    arc_0_20_18  out_degree_783  1
    arc_0_20_18  original_T_including_depot_unload_798  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_18  arc_capacity_688  1
    load_0_20_18  free_load_conservation_776  -1
    load_0_20_18  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_19  arc_capacity_690  -20
    arc_0_20_19  connected_order_arc_691  -13
    arc_0_20_19  in_degree_778  1
    arc_0_20_19  out_degree_783  1
    arc_0_20_19  original_T_including_depot_unload_798  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_0_20_19  arc_capacity_690  1
    load_0_20_19  free_load_conservation_782  -1
    load_0_20_19  free_load_conservation_788  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_20_21  arc_capacity_692  -20
    arc_0_20_21  connected_order_arc_693  -13
    arc_0_20_21  out_degree_783  1
    arc_0_20_21  in_degree_790  1
    arc_0_20_21  original_T_including_depot_unload_798  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_20_21  arc_capacity_692  1
    load_0_20_21  free_load_conservation_788  1
    load_0_20_21  free_load_conservation_794  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_0  arc_capacity_694  -20
    arc_0_21_0  depot_return_or_bypass_718  1
    arc_0_21_0  out_degree_789  1
    arc_0_21_0  original_T_including_depot_unload_798  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_0  arc_capacity_694  1
    load_0_21_0  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_1  arc_capacity_695  -20
    arc_0_21_1  connected_order_arc_696  -13
    arc_0_21_1  in_degree_720  1
    arc_0_21_1  out_degree_789  1
    arc_0_21_1  original_T_including_depot_unload_798  1.3286968036345565e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_1  arc_capacity_695  1
    load_0_21_1  segment_load_conservation_723  -1
    load_0_21_1  segment_prefix_lb_724  1
    load_0_21_1  segment_prefix_ub_725  1
    load_0_21_1  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_2  arc_capacity_697  -20
    arc_0_21_2  connected_order_arc_698  -13
    arc_0_21_2  in_degree_727  1
    arc_0_21_2  out_degree_789  1
    arc_0_21_2  original_T_including_depot_unload_798  1.3740068502263614e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_2  arc_capacity_697  1
    load_0_21_2  segment_load_conservation_730  -1
    load_0_21_2  segment_prefix_lb_731  1
    load_0_21_2  segment_prefix_ub_732  1
    load_0_21_2  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_3  arc_capacity_699  -20
    arc_0_21_3  connected_order_arc_700  -13
    arc_0_21_3  in_degree_734  1
    arc_0_21_3  out_degree_789  1
    arc_0_21_3  original_T_including_depot_unload_798  1.3082661182285894e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_3  arc_capacity_699  1
    load_0_21_3  segment_load_conservation_737  -1
    load_0_21_3  segment_prefix_lb_738  1
    load_0_21_3  segment_prefix_ub_739  1
    load_0_21_3  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_4  arc_capacity_701  -20
    arc_0_21_4  connected_order_arc_702  -13
    arc_0_21_4  in_degree_741  1
    arc_0_21_4  out_degree_789  1
    arc_0_21_4  original_T_including_depot_unload_798  1.5356938236745739e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_4  arc_capacity_701  1
    load_0_21_4  segment_load_conservation_744  -1
    load_0_21_4  segment_prefix_lb_745  1
    load_0_21_4  segment_prefix_ub_746  1
    load_0_21_4  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_14  arc_capacity_703  -20
    arc_0_21_14  connected_order_arc_704  -13
    arc_0_21_14  in_degree_748  1
    arc_0_21_14  out_degree_789  1
    arc_0_21_14  original_T_including_depot_unload_798  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_14  arc_capacity_703  1
    load_0_21_14  free_load_conservation_752  -1
    load_0_21_14  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_15  arc_capacity_705  -20
    arc_0_21_15  connected_order_arc_706  -13
    arc_0_21_15  in_degree_754  1
    arc_0_21_15  out_degree_789  1
    arc_0_21_15  original_T_including_depot_unload_798  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_15  arc_capacity_705  1
    load_0_21_15  free_load_conservation_758  -1
    load_0_21_15  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_16  arc_capacity_707  -20
    arc_0_21_16  connected_order_arc_708  -13
    arc_0_21_16  in_degree_760  1
    arc_0_21_16  out_degree_789  1
    arc_0_21_16  original_T_including_depot_unload_798  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_16  arc_capacity_707  1
    load_0_21_16  free_load_conservation_764  -1
    load_0_21_16  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_17  arc_capacity_709  -20
    arc_0_21_17  connected_order_arc_710  -13
    arc_0_21_17  in_degree_766  1
    arc_0_21_17  out_degree_789  1
    arc_0_21_17  original_T_including_depot_unload_798  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_17  arc_capacity_709  1
    load_0_21_17  free_load_conservation_770  -1
    load_0_21_17  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_18  arc_capacity_711  -20
    arc_0_21_18  connected_order_arc_712  -13
    arc_0_21_18  in_degree_772  1
    arc_0_21_18  out_degree_789  1
    arc_0_21_18  original_T_including_depot_unload_798  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_18  arc_capacity_711  1
    load_0_21_18  free_load_conservation_776  -1
    load_0_21_18  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_19  arc_capacity_713  -20
    arc_0_21_19  connected_order_arc_714  -13
    arc_0_21_19  in_degree_778  1
    arc_0_21_19  out_degree_789  1
    arc_0_21_19  original_T_including_depot_unload_798  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_21_19  arc_capacity_713  1
    load_0_21_19  free_load_conservation_782  -1
    load_0_21_19  free_load_conservation_794  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_21_20  arc_capacity_715  -20
    arc_0_21_20  connected_order_arc_716  -13
    arc_0_21_20  in_degree_784  1
    arc_0_21_20  out_degree_789  1
    arc_0_21_20  original_T_including_depot_unload_798  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_21_20  arc_capacity_715  1
    load_0_21_20  free_load_conservation_788  -1
    load_0_21_20  free_load_conservation_794  1
    visit_1_5  out_degree_1140  -1
    visit_1_5  in_degree_1141  -1
    visit_1_5  order_active_lb_1142  -1
    visit_1_5  order_active_ub_1143  -13
    order_1_5  connected_order_arc_815  -1
    order_1_5  connected_order_arc_817  -1
    order_1_5  connected_order_arc_819  -1
    order_1_5  connected_order_arc_821  -1
    order_1_5  connected_order_arc_823  -1
    order_1_5  connected_order_arc_825  -1
    order_1_5  connected_order_arc_827  -1
    order_1_5  connected_order_arc_829  -1
    order_1_5  connected_order_arc_831  -1
    order_1_5  connected_order_arc_833  -1
    order_1_5  connected_order_arc_835  -1
    order_1_5  connected_order_arc_837  -1
    order_1_5  connected_order_arc_840  1
    order_1_5  connected_order_arc_865  1
    order_1_5  connected_order_arc_890  1
    order_1_5  connected_order_arc_915  1
    order_1_5  connected_order_arc_940  1
    order_1_5  connected_order_arc_965  1
    order_1_5  connected_order_arc_990  1
    order_1_5  connected_order_arc_1015  1
    order_1_5  connected_order_arc_1040  1
    order_1_5  connected_order_arc_1065  1
    order_1_5  connected_order_arc_1090  1
    order_1_5  connected_order_arc_1115  1
    order_1_5  order_active_lb_1142  1
    order_1_5  order_active_ub_1143  1
    order_1_5  fixed_segment_relative_order_1223  -1
    visit_1_6  out_degree_1147  -1
    visit_1_6  in_degree_1148  -1
    visit_1_6  order_active_lb_1149  -1
    visit_1_6  order_active_ub_1150  -13
    order_1_6  connected_order_arc_815  1
    order_1_6  connected_order_arc_840  -1
    order_1_6  connected_order_arc_842  -1
    order_1_6  connected_order_arc_844  -1
    order_1_6  connected_order_arc_846  -1
    order_1_6  connected_order_arc_848  -1
    order_1_6  connected_order_arc_850  -1
    order_1_6  connected_order_arc_852  -1
    order_1_6  connected_order_arc_854  -1
    order_1_6  connected_order_arc_856  -1
    order_1_6  connected_order_arc_858  -1
    order_1_6  connected_order_arc_860  -1
    order_1_6  connected_order_arc_862  -1
    order_1_6  connected_order_arc_867  1
    order_1_6  connected_order_arc_892  1
    order_1_6  connected_order_arc_917  1
    order_1_6  connected_order_arc_942  1
    order_1_6  connected_order_arc_967  1
    order_1_6  connected_order_arc_992  1
    order_1_6  connected_order_arc_1017  1
    order_1_6  connected_order_arc_1042  1
    order_1_6  connected_order_arc_1067  1
    order_1_6  connected_order_arc_1092  1
    order_1_6  connected_order_arc_1117  1
    order_1_6  order_active_lb_1149  1
    order_1_6  order_active_ub_1150  1
    order_1_6  fixed_segment_relative_order_1223  1
    order_1_6  fixed_segment_relative_order_1224  -1
    visit_1_7  out_degree_1154  -1
    visit_1_7  in_degree_1155  -1
    visit_1_7  order_active_lb_1156  -1
    visit_1_7  order_active_ub_1157  -13
    order_1_7  connected_order_arc_817  1
    order_1_7  connected_order_arc_842  1
    order_1_7  connected_order_arc_865  -1
    order_1_7  connected_order_arc_867  -1
    order_1_7  connected_order_arc_869  -1
    order_1_7  connected_order_arc_871  -1
    order_1_7  connected_order_arc_873  -1
    order_1_7  connected_order_arc_875  -1
    order_1_7  connected_order_arc_877  -1
    order_1_7  connected_order_arc_879  -1
    order_1_7  connected_order_arc_881  -1
    order_1_7  connected_order_arc_883  -1
    order_1_7  connected_order_arc_885  -1
    order_1_7  connected_order_arc_887  -1
    order_1_7  connected_order_arc_894  1
    order_1_7  connected_order_arc_919  1
    order_1_7  connected_order_arc_944  1
    order_1_7  connected_order_arc_969  1
    order_1_7  connected_order_arc_994  1
    order_1_7  connected_order_arc_1019  1
    order_1_7  connected_order_arc_1044  1
    order_1_7  connected_order_arc_1069  1
    order_1_7  connected_order_arc_1094  1
    order_1_7  connected_order_arc_1119  1
    order_1_7  order_active_lb_1156  1
    order_1_7  order_active_ub_1157  1
    order_1_7  fixed_segment_relative_order_1224  1
    order_1_7  fixed_segment_relative_order_1225  -1
    visit_1_8  out_degree_1161  -1
    visit_1_8  in_degree_1162  -1
    visit_1_8  order_active_lb_1163  -1
    visit_1_8  order_active_ub_1164  -13
    order_1_8  connected_order_arc_819  1
    order_1_8  connected_order_arc_844  1
    order_1_8  connected_order_arc_869  1
    order_1_8  connected_order_arc_890  -1
    order_1_8  connected_order_arc_892  -1
    order_1_8  connected_order_arc_894  -1
    order_1_8  connected_order_arc_896  -1
    order_1_8  connected_order_arc_898  -1
    order_1_8  connected_order_arc_900  -1
    order_1_8  connected_order_arc_902  -1
    order_1_8  connected_order_arc_904  -1
    order_1_8  connected_order_arc_906  -1
    order_1_8  connected_order_arc_908  -1
    order_1_8  connected_order_arc_910  -1
    order_1_8  connected_order_arc_912  -1
    order_1_8  connected_order_arc_921  1
    order_1_8  connected_order_arc_946  1
    order_1_8  connected_order_arc_971  1
    order_1_8  connected_order_arc_996  1
    order_1_8  connected_order_arc_1021  1
    order_1_8  connected_order_arc_1046  1
    order_1_8  connected_order_arc_1071  1
    order_1_8  connected_order_arc_1096  1
    order_1_8  connected_order_arc_1121  1
    order_1_8  order_active_lb_1163  1
    order_1_8  order_active_ub_1164  1
    order_1_8  fixed_segment_relative_order_1225  1
    order_1_8  fixed_segment_relative_order_1226  -1
    visit_1_9  out_degree_1168  -1
    visit_1_9  in_degree_1169  -1
    visit_1_9  order_active_lb_1170  -1
    visit_1_9  order_active_ub_1171  -13
    order_1_9  connected_order_arc_821  1
    order_1_9  connected_order_arc_846  1
    order_1_9  connected_order_arc_871  1
    order_1_9  connected_order_arc_896  1
    order_1_9  connected_order_arc_915  -1
    order_1_9  connected_order_arc_917  -1
    order_1_9  connected_order_arc_919  -1
    order_1_9  connected_order_arc_921  -1
    order_1_9  connected_order_arc_923  -1
    order_1_9  connected_order_arc_925  -1
    order_1_9  connected_order_arc_927  -1
    order_1_9  connected_order_arc_929  -1
    order_1_9  connected_order_arc_931  -1
    order_1_9  connected_order_arc_933  -1
    order_1_9  connected_order_arc_935  -1
    order_1_9  connected_order_arc_937  -1
    order_1_9  connected_order_arc_948  1
    order_1_9  connected_order_arc_973  1
    order_1_9  connected_order_arc_998  1
    order_1_9  connected_order_arc_1023  1
    order_1_9  connected_order_arc_1048  1
    order_1_9  connected_order_arc_1073  1
    order_1_9  connected_order_arc_1098  1
    order_1_9  connected_order_arc_1123  1
    order_1_9  order_active_lb_1170  1
    order_1_9  order_active_ub_1171  1
    order_1_9  fixed_segment_relative_order_1226  1
    visit_1_14  out_degree_1175  -1
    visit_1_14  in_degree_1176  -1
    visit_1_14  order_active_lb_1177  -1
    visit_1_14  order_active_ub_1178  -13
    visit_1_14  service_visit_def_1179  -1
    order_1_14  connected_order_arc_823  1
    order_1_14  connected_order_arc_848  1
    order_1_14  connected_order_arc_873  1
    order_1_14  connected_order_arc_898  1
    order_1_14  connected_order_arc_923  1
    order_1_14  connected_order_arc_940  -1
    order_1_14  connected_order_arc_942  -1
    order_1_14  connected_order_arc_944  -1
    order_1_14  connected_order_arc_946  -1
    order_1_14  connected_order_arc_948  -1
    order_1_14  connected_order_arc_950  -1
    order_1_14  connected_order_arc_952  -1
    order_1_14  connected_order_arc_954  -1
    order_1_14  connected_order_arc_956  -1
    order_1_14  connected_order_arc_958  -1
    order_1_14  connected_order_arc_960  -1
    order_1_14  connected_order_arc_962  -1
    order_1_14  connected_order_arc_975  1
    order_1_14  connected_order_arc_1000  1
    order_1_14  connected_order_arc_1025  1
    order_1_14  connected_order_arc_1050  1
    order_1_14  connected_order_arc_1075  1
    order_1_14  connected_order_arc_1100  1
    order_1_14  connected_order_arc_1125  1
    order_1_14  order_active_lb_1177  1
    order_1_14  order_active_ub_1178  1
    visit_1_15  out_degree_1181  -1
    visit_1_15  in_degree_1182  -1
    visit_1_15  order_active_lb_1183  -1
    visit_1_15  order_active_ub_1184  -13
    visit_1_15  service_visit_def_1185  -1
    order_1_15  connected_order_arc_825  1
    order_1_15  connected_order_arc_850  1
    order_1_15  connected_order_arc_875  1
    order_1_15  connected_order_arc_900  1
    order_1_15  connected_order_arc_925  1
    order_1_15  connected_order_arc_950  1
    order_1_15  connected_order_arc_965  -1
    order_1_15  connected_order_arc_967  -1
    order_1_15  connected_order_arc_969  -1
    order_1_15  connected_order_arc_971  -1
    order_1_15  connected_order_arc_973  -1
    order_1_15  connected_order_arc_975  -1
    order_1_15  connected_order_arc_977  -1
    order_1_15  connected_order_arc_979  -1
    order_1_15  connected_order_arc_981  -1
    order_1_15  connected_order_arc_983  -1
    order_1_15  connected_order_arc_985  -1
    order_1_15  connected_order_arc_987  -1
    order_1_15  connected_order_arc_1002  1
    order_1_15  connected_order_arc_1027  1
    order_1_15  connected_order_arc_1052  1
    order_1_15  connected_order_arc_1077  1
    order_1_15  connected_order_arc_1102  1
    order_1_15  connected_order_arc_1127  1
    order_1_15  order_active_lb_1183  1
    order_1_15  order_active_ub_1184  1
    visit_1_16  out_degree_1187  -1
    visit_1_16  in_degree_1188  -1
    visit_1_16  order_active_lb_1189  -1
    visit_1_16  order_active_ub_1190  -13
    visit_1_16  service_visit_def_1191  -1
    order_1_16  connected_order_arc_827  1
    order_1_16  connected_order_arc_852  1
    order_1_16  connected_order_arc_877  1
    order_1_16  connected_order_arc_902  1
    order_1_16  connected_order_arc_927  1
    order_1_16  connected_order_arc_952  1
    order_1_16  connected_order_arc_977  1
    order_1_16  connected_order_arc_990  -1
    order_1_16  connected_order_arc_992  -1
    order_1_16  connected_order_arc_994  -1
    order_1_16  connected_order_arc_996  -1
    order_1_16  connected_order_arc_998  -1
    order_1_16  connected_order_arc_1000  -1
    order_1_16  connected_order_arc_1002  -1
    order_1_16  connected_order_arc_1004  -1
    order_1_16  connected_order_arc_1006  -1
    order_1_16  connected_order_arc_1008  -1
    order_1_16  connected_order_arc_1010  -1
    order_1_16  connected_order_arc_1012  -1
    order_1_16  connected_order_arc_1029  1
    order_1_16  connected_order_arc_1054  1
    order_1_16  connected_order_arc_1079  1
    order_1_16  connected_order_arc_1104  1
    order_1_16  connected_order_arc_1129  1
    order_1_16  order_active_lb_1189  1
    order_1_16  order_active_ub_1190  1
    visit_1_17  out_degree_1193  -1
    visit_1_17  in_degree_1194  -1
    visit_1_17  order_active_lb_1195  -1
    visit_1_17  order_active_ub_1196  -13
    visit_1_17  service_visit_def_1197  -1
    order_1_17  connected_order_arc_829  1
    order_1_17  connected_order_arc_854  1
    order_1_17  connected_order_arc_879  1
    order_1_17  connected_order_arc_904  1
    order_1_17  connected_order_arc_929  1
    order_1_17  connected_order_arc_954  1
    order_1_17  connected_order_arc_979  1
    order_1_17  connected_order_arc_1004  1
    order_1_17  connected_order_arc_1015  -1
    order_1_17  connected_order_arc_1017  -1
    order_1_17  connected_order_arc_1019  -1
    order_1_17  connected_order_arc_1021  -1
    order_1_17  connected_order_arc_1023  -1
    order_1_17  connected_order_arc_1025  -1
    order_1_17  connected_order_arc_1027  -1
    order_1_17  connected_order_arc_1029  -1
    order_1_17  connected_order_arc_1031  -1
    order_1_17  connected_order_arc_1033  -1
    order_1_17  connected_order_arc_1035  -1
    order_1_17  connected_order_arc_1037  -1
    order_1_17  connected_order_arc_1056  1
    order_1_17  connected_order_arc_1081  1
    order_1_17  connected_order_arc_1106  1
    order_1_17  connected_order_arc_1131  1
    order_1_17  order_active_lb_1195  1
    order_1_17  order_active_ub_1196  1
    visit_1_18  out_degree_1199  -1
    visit_1_18  in_degree_1200  -1
    visit_1_18  order_active_lb_1201  -1
    visit_1_18  order_active_ub_1202  -13
    visit_1_18  service_visit_def_1203  -1
    order_1_18  connected_order_arc_831  1
    order_1_18  connected_order_arc_856  1
    order_1_18  connected_order_arc_881  1
    order_1_18  connected_order_arc_906  1
    order_1_18  connected_order_arc_931  1
    order_1_18  connected_order_arc_956  1
    order_1_18  connected_order_arc_981  1
    order_1_18  connected_order_arc_1006  1
    order_1_18  connected_order_arc_1031  1
    order_1_18  connected_order_arc_1040  -1
    order_1_18  connected_order_arc_1042  -1
    order_1_18  connected_order_arc_1044  -1
    order_1_18  connected_order_arc_1046  -1
    order_1_18  connected_order_arc_1048  -1
    order_1_18  connected_order_arc_1050  -1
    order_1_18  connected_order_arc_1052  -1
    order_1_18  connected_order_arc_1054  -1
    order_1_18  connected_order_arc_1056  -1
    order_1_18  connected_order_arc_1058  -1
    order_1_18  connected_order_arc_1060  -1
    order_1_18  connected_order_arc_1062  -1
    order_1_18  connected_order_arc_1083  1
    order_1_18  connected_order_arc_1108  1
    order_1_18  connected_order_arc_1133  1
    order_1_18  order_active_lb_1201  1
    order_1_18  order_active_ub_1202  1
    visit_1_19  out_degree_1205  -1
    visit_1_19  in_degree_1206  -1
    visit_1_19  order_active_lb_1207  -1
    visit_1_19  order_active_ub_1208  -13
    visit_1_19  service_visit_def_1209  -1
    order_1_19  connected_order_arc_833  1
    order_1_19  connected_order_arc_858  1
    order_1_19  connected_order_arc_883  1
    order_1_19  connected_order_arc_908  1
    order_1_19  connected_order_arc_933  1
    order_1_19  connected_order_arc_958  1
    order_1_19  connected_order_arc_983  1
    order_1_19  connected_order_arc_1008  1
    order_1_19  connected_order_arc_1033  1
    order_1_19  connected_order_arc_1058  1
    order_1_19  connected_order_arc_1065  -1
    order_1_19  connected_order_arc_1067  -1
    order_1_19  connected_order_arc_1069  -1
    order_1_19  connected_order_arc_1071  -1
    order_1_19  connected_order_arc_1073  -1
    order_1_19  connected_order_arc_1075  -1
    order_1_19  connected_order_arc_1077  -1
    order_1_19  connected_order_arc_1079  -1
    order_1_19  connected_order_arc_1081  -1
    order_1_19  connected_order_arc_1083  -1
    order_1_19  connected_order_arc_1085  -1
    order_1_19  connected_order_arc_1087  -1
    order_1_19  connected_order_arc_1110  1
    order_1_19  connected_order_arc_1135  1
    order_1_19  order_active_lb_1207  1
    order_1_19  order_active_ub_1208  1
    visit_1_20  out_degree_1211  -1
    visit_1_20  in_degree_1212  -1
    visit_1_20  order_active_lb_1213  -1
    visit_1_20  order_active_ub_1214  -13
    visit_1_20  service_visit_def_1215  -1
    order_1_20  connected_order_arc_835  1
    order_1_20  connected_order_arc_860  1
    order_1_20  connected_order_arc_885  1
    order_1_20  connected_order_arc_910  1
    order_1_20  connected_order_arc_935  1
    order_1_20  connected_order_arc_960  1
    order_1_20  connected_order_arc_985  1
    order_1_20  connected_order_arc_1010  1
    order_1_20  connected_order_arc_1035  1
    order_1_20  connected_order_arc_1060  1
    order_1_20  connected_order_arc_1085  1
    order_1_20  connected_order_arc_1090  -1
    order_1_20  connected_order_arc_1092  -1
    order_1_20  connected_order_arc_1094  -1
    order_1_20  connected_order_arc_1096  -1
    order_1_20  connected_order_arc_1098  -1
    order_1_20  connected_order_arc_1100  -1
    order_1_20  connected_order_arc_1102  -1
    order_1_20  connected_order_arc_1104  -1
    order_1_20  connected_order_arc_1106  -1
    order_1_20  connected_order_arc_1108  -1
    order_1_20  connected_order_arc_1110  -1
    order_1_20  connected_order_arc_1112  -1
    order_1_20  connected_order_arc_1137  1
    order_1_20  order_active_lb_1213  1
    order_1_20  order_active_ub_1214  1
    visit_1_21  out_degree_1217  -1
    visit_1_21  in_degree_1218  -1
    visit_1_21  order_active_lb_1219  -1
    visit_1_21  order_active_ub_1220  -13
    visit_1_21  service_visit_def_1221  -1
    order_1_21  connected_order_arc_837  1
    order_1_21  connected_order_arc_862  1
    order_1_21  connected_order_arc_887  1
    order_1_21  connected_order_arc_912  1
    order_1_21  connected_order_arc_937  1
    order_1_21  connected_order_arc_962  1
    order_1_21  connected_order_arc_987  1
    order_1_21  connected_order_arc_1012  1
    order_1_21  connected_order_arc_1037  1
    order_1_21  connected_order_arc_1062  1
    order_1_21  connected_order_arc_1087  1
    order_1_21  connected_order_arc_1112  1
    order_1_21  connected_order_arc_1115  -1
    order_1_21  connected_order_arc_1117  -1
    order_1_21  connected_order_arc_1119  -1
    order_1_21  connected_order_arc_1121  -1
    order_1_21  connected_order_arc_1123  -1
    order_1_21  connected_order_arc_1125  -1
    order_1_21  connected_order_arc_1127  -1
    order_1_21  connected_order_arc_1129  -1
    order_1_21  connected_order_arc_1131  -1
    order_1_21  connected_order_arc_1133  -1
    order_1_21  connected_order_arc_1135  -1
    order_1_21  connected_order_arc_1137  -1
    order_1_21  order_active_lb_1219  1
    order_1_21  order_active_ub_1220  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_799  -25
    arc_1_0_0  depot_departure_or_bypass_1138  1
    arc_1_0_0  depot_return_or_bypass_1139  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_799  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_5  arc_capacity_800  -25
    arc_1_0_5  depot_departure_or_bypass_1138  1
    arc_1_0_5  in_degree_1141  1
    arc_1_0_5  original_T_including_depot_unload_1227  8.7749189782983967e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_5  arc_capacity_800  1
    load_1_0_5  segment_load_conservation_1144  -1
    load_1_0_5  segment_prefix_lb_1145  1
    load_1_0_5  segment_prefix_ub_1146  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_801  -25
    arc_1_0_6  depot_departure_or_bypass_1138  1
    arc_1_0_6  in_degree_1148  1
    arc_1_0_6  original_T_including_depot_unload_1227  8.7918533905669346e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_801  1
    load_1_0_6  segment_load_conservation_1151  -1
    load_1_0_6  segment_prefix_lb_1152  1
    load_1_0_6  segment_prefix_ub_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_802  -25
    arc_1_0_7  depot_departure_or_bypass_1138  1
    arc_1_0_7  in_degree_1155  1
    arc_1_0_7  original_T_including_depot_unload_1227  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_802  1
    load_1_0_7  segment_load_conservation_1158  -1
    load_1_0_7  segment_prefix_lb_1159  1
    load_1_0_7  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_803  -25
    arc_1_0_8  depot_departure_or_bypass_1138  1
    arc_1_0_8  in_degree_1162  1
    arc_1_0_8  original_T_including_depot_unload_1227  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_803  1
    load_1_0_8  segment_load_conservation_1165  -1
    load_1_0_8  segment_prefix_lb_1166  1
    load_1_0_8  segment_prefix_ub_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_804  -25
    arc_1_0_9  depot_departure_or_bypass_1138  1
    arc_1_0_9  in_degree_1169  1
    arc_1_0_9  original_T_including_depot_unload_1227  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_804  1
    load_1_0_9  segment_load_conservation_1172  -1
    load_1_0_9  segment_prefix_lb_1173  1
    load_1_0_9  segment_prefix_ub_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_805  -25
    arc_1_0_14  depot_departure_or_bypass_1138  1
    arc_1_0_14  in_degree_1176  1
    arc_1_0_14  original_T_including_depot_unload_1227  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_805  1
    load_1_0_14  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_806  -25
    arc_1_0_15  depot_departure_or_bypass_1138  1
    arc_1_0_15  in_degree_1182  1
    arc_1_0_15  original_T_including_depot_unload_1227  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_806  1
    load_1_0_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_16  arc_capacity_807  -25
    arc_1_0_16  depot_departure_or_bypass_1138  1
    arc_1_0_16  in_degree_1188  1
    arc_1_0_16  original_T_including_depot_unload_1227  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_16  arc_capacity_807  1
    load_1_0_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_17  arc_capacity_808  -25
    arc_1_0_17  depot_departure_or_bypass_1138  1
    arc_1_0_17  in_degree_1194  1
    arc_1_0_17  original_T_including_depot_unload_1227  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_0_17  arc_capacity_808  1
    load_1_0_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_18  arc_capacity_809  -25
    arc_1_0_18  depot_departure_or_bypass_1138  1
    arc_1_0_18  in_degree_1200  1
    arc_1_0_18  original_T_including_depot_unload_1227  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_18  arc_capacity_809  1
    load_1_0_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_19  arc_capacity_810  -25
    arc_1_0_19  depot_departure_or_bypass_1138  1
    arc_1_0_19  in_degree_1206  1
    arc_1_0_19  original_T_including_depot_unload_1227  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_19  arc_capacity_810  1
    load_1_0_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_20  arc_capacity_811  -25
    arc_1_0_20  depot_departure_or_bypass_1138  1
    arc_1_0_20  in_degree_1212  1
    arc_1_0_20  original_T_including_depot_unload_1227  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_20  arc_capacity_811  1
    load_1_0_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_21  arc_capacity_812  -25
    arc_1_0_21  depot_departure_or_bypass_1138  1
    arc_1_0_21  in_degree_1218  1
    arc_1_0_21  original_T_including_depot_unload_1227  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_21  arc_capacity_812  1
    load_1_0_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_0  arc_capacity_813  -25
    arc_1_5_0  depot_return_or_bypass_1139  1
    arc_1_5_0  out_degree_1140  1
    arc_1_5_0  original_T_including_depot_unload_1227  1.0479182987243917e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_0  arc_capacity_813  1
    load_1_5_0  segment_load_conservation_1144  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_6  arc_capacity_814  -25
    arc_1_5_6  connected_order_arc_815  -14
    arc_1_5_6  out_degree_1140  1
    arc_1_5_6  in_degree_1148  1
    arc_1_5_6  original_T_including_depot_unload_1227  2.4155873404211835e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_6  arc_capacity_814  1
    load_1_5_6  segment_load_conservation_1144  1
    load_1_5_6  segment_load_conservation_1151  -1
    load_1_5_6  segment_prefix_lb_1152  1
    load_1_5_6  segment_prefix_ub_1153  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_7  arc_capacity_816  -25
    arc_1_5_7  connected_order_arc_817  -14
    arc_1_5_7  out_degree_1140  1
    arc_1_5_7  in_degree_1155  1
    arc_1_5_7  original_T_including_depot_unload_1227  6.2793211180612207e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_7  arc_capacity_816  1
    load_1_5_7  segment_load_conservation_1144  1
    load_1_5_7  segment_load_conservation_1158  -1
    load_1_5_7  segment_prefix_lb_1159  1
    load_1_5_7  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_8  arc_capacity_818  -25
    arc_1_5_8  connected_order_arc_819  -14
    arc_1_5_8  out_degree_1140  1
    arc_1_5_8  in_degree_1162  1
    arc_1_5_8  original_T_including_depot_unload_1227  1.1592640472038677e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_8  arc_capacity_818  1
    load_1_5_8  segment_load_conservation_1144  1
    load_1_5_8  segment_load_conservation_1165  -1
    load_1_5_8  segment_prefix_lb_1166  1
    load_1_5_8  segment_prefix_ub_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_9  arc_capacity_820  -25
    arc_1_5_9  connected_order_arc_821  -14
    arc_1_5_9  out_degree_1140  1
    arc_1_5_9  in_degree_1169  1
    arc_1_5_9  original_T_including_depot_unload_1227  9.2235470209829464e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_9  arc_capacity_820  1
    load_1_5_9  segment_load_conservation_1144  1
    load_1_5_9  segment_load_conservation_1172  -1
    load_1_5_9  segment_prefix_lb_1173  1
    load_1_5_9  segment_prefix_ub_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_14  arc_capacity_822  -25
    arc_1_5_14  connected_order_arc_823  -14
    arc_1_5_14  out_degree_1140  1
    arc_1_5_14  in_degree_1176  1
    arc_1_5_14  original_T_including_depot_unload_1227  1.2213551686272770e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_14  arc_capacity_822  1
    load_1_5_14  segment_load_conservation_1144  1
    load_1_5_14  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_15  arc_capacity_824  -25
    arc_1_5_15  connected_order_arc_825  -14
    arc_1_5_15  out_degree_1140  1
    arc_1_5_15  in_degree_1182  1
    arc_1_5_15  original_T_including_depot_unload_1227  1.0854925215530507e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_15  arc_capacity_824  1
    load_1_5_15  segment_load_conservation_1144  1
    load_1_5_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_16  arc_capacity_826  -25
    arc_1_5_16  connected_order_arc_827  -14
    arc_1_5_16  out_degree_1140  1
    arc_1_5_16  in_degree_1188  1
    arc_1_5_16  original_T_including_depot_unload_1227  5.2280951376932137e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_16  arc_capacity_826  1
    load_1_5_16  segment_load_conservation_1144  1
    load_1_5_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_17  arc_capacity_828  -25
    arc_1_5_17  connected_order_arc_829  -14
    arc_1_5_17  out_degree_1140  1
    arc_1_5_17  in_degree_1194  1
    arc_1_5_17  original_T_including_depot_unload_1227  1.0684489086573428e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_17  arc_capacity_828  1
    load_1_5_17  segment_load_conservation_1144  1
    load_1_5_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_18  arc_capacity_830  -25
    arc_1_5_18  connected_order_arc_831  -14
    arc_1_5_18  out_degree_1140  1
    arc_1_5_18  in_degree_1200  1
    arc_1_5_18  original_T_including_depot_unload_1227  1.0880068546845516e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_18  arc_capacity_830  1
    load_1_5_18  segment_load_conservation_1144  1
    load_1_5_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_19  arc_capacity_832  -25
    arc_1_5_19  connected_order_arc_833  -14
    arc_1_5_19  out_degree_1140  1
    arc_1_5_19  in_degree_1206  1
    arc_1_5_19  original_T_including_depot_unload_1227  9.9524628735690555e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_19  arc_capacity_832  1
    load_1_5_19  segment_load_conservation_1144  1
    load_1_5_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_20  arc_capacity_834  -25
    arc_1_5_20  connected_order_arc_835  -14
    arc_1_5_20  out_degree_1140  1
    arc_1_5_20  in_degree_1212  1
    arc_1_5_20  original_T_including_depot_unload_1227  1.7883808204567979e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_5_20  arc_capacity_834  1
    load_1_5_20  segment_load_conservation_1144  1
    load_1_5_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_5_21  arc_capacity_836  -25
    arc_1_5_21  connected_order_arc_837  -14
    arc_1_5_21  out_degree_1140  1
    arc_1_5_21  in_degree_1218  1
    arc_1_5_21  original_T_including_depot_unload_1227  8.0531033344008677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_5_21  arc_capacity_836  1
    load_1_5_21  segment_load_conservation_1144  1
    load_1_5_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_838  -25
    arc_1_6_0  depot_return_or_bypass_1139  1
    arc_1_6_0  out_degree_1147  1
    arc_1_6_0  original_T_including_depot_unload_1227  1.0088905112952611e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_838  1
    load_1_6_0  segment_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_5  arc_capacity_839  -25
    arc_1_6_5  connected_order_arc_840  -14
    arc_1_6_5  in_degree_1141  1
    arc_1_6_5  out_degree_1147  1
    arc_1_6_5  original_T_including_depot_unload_1227  1.6651295535886251e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_5  arc_capacity_839  1
    load_1_6_5  segment_load_conservation_1144  -1
    load_1_6_5  segment_prefix_lb_1145  1
    load_1_6_5  segment_prefix_ub_1146  1
    load_1_6_5  segment_load_conservation_1151  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_841  -25
    arc_1_6_7  connected_order_arc_842  -14
    arc_1_6_7  out_degree_1147  1
    arc_1_6_7  in_degree_1155  1
    arc_1_6_7  original_T_including_depot_unload_1227  3.2286832955801827e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_841  1
    load_1_6_7  segment_load_conservation_1151  1
    load_1_6_7  segment_load_conservation_1158  -1
    load_1_6_7  segment_prefix_lb_1159  1
    load_1_6_7  segment_prefix_ub_1160  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_843  -25
    arc_1_6_8  connected_order_arc_844  -14
    arc_1_6_8  out_degree_1147  1
    arc_1_6_8  in_degree_1162  1
    arc_1_6_8  original_T_including_depot_unload_1227  9.6554407723795373e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_843  1
    load_1_6_8  segment_load_conservation_1151  1
    load_1_6_8  segment_load_conservation_1165  -1
    load_1_6_8  segment_prefix_lb_1166  1
    load_1_6_8  segment_prefix_ub_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_845  -25
    arc_1_6_9  connected_order_arc_846  -14
    arc_1_6_9  out_degree_1147  1
    arc_1_6_9  in_degree_1169  1
    arc_1_6_9  original_T_including_depot_unload_1227  8.9135689158237335e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_845  1
    load_1_6_9  segment_load_conservation_1151  1
    load_1_6_9  segment_load_conservation_1172  -1
    load_1_6_9  segment_prefix_lb_1173  1
    load_1_6_9  segment_prefix_ub_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_847  -25
    arc_1_6_14  connected_order_arc_848  -14
    arc_1_6_14  out_degree_1147  1
    arc_1_6_14  in_degree_1176  1
    arc_1_6_14  original_T_including_depot_unload_1227  8.6289703303586691e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_847  1
    load_1_6_14  segment_load_conservation_1151  1
    load_1_6_14  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_849  -25
    arc_1_6_15  connected_order_arc_850  -14
    arc_1_6_15  out_degree_1147  1
    arc_1_6_15  in_degree_1182  1
    arc_1_6_15  original_T_including_depot_unload_1227  7.5249256121297628e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_849  1
    load_1_6_15  segment_load_conservation_1151  1
    load_1_6_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_16  arc_capacity_851  -25
    arc_1_6_16  connected_order_arc_852  -14
    arc_1_6_16  out_degree_1147  1
    arc_1_6_16  in_degree_1188  1
    arc_1_6_16  original_T_including_depot_unload_1227  861.314419336229
    MARKER    'MARKER'                 'INTEND'
    load_1_6_16  arc_capacity_851  1
    load_1_6_16  segment_load_conservation_1151  1
    load_1_6_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_17  arc_capacity_853  -25
    arc_1_6_17  connected_order_arc_854  -14
    arc_1_6_17  out_degree_1147  1
    arc_1_6_17  in_degree_1194  1
    arc_1_6_17  original_T_including_depot_unload_1227  754.162661294669
    MARKER    'MARKER'                 'INTEND'
    load_1_6_17  arc_capacity_853  1
    load_1_6_17  segment_load_conservation_1151  1
    load_1_6_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_18  arc_capacity_855  -25
    arc_1_6_18  connected_order_arc_856  -14
    arc_1_6_18  out_degree_1147  1
    arc_1_6_18  in_degree_1200  1
    arc_1_6_18  original_T_including_depot_unload_1227  8.5502565124349769e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_18  arc_capacity_855  1
    load_1_6_18  segment_load_conservation_1151  1
    load_1_6_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_19  arc_capacity_857  -25
    arc_1_6_19  connected_order_arc_858  -14
    arc_1_6_19  out_degree_1147  1
    arc_1_6_19  in_degree_1206  1
    arc_1_6_19  original_T_including_depot_unload_1227  7.0141209816069022e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_19  arc_capacity_857  1
    load_1_6_19  segment_load_conservation_1151  1
    load_1_6_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_20  arc_capacity_859  -25
    arc_1_6_20  connected_order_arc_860  -14
    arc_1_6_20  out_degree_1147  1
    arc_1_6_20  in_degree_1212  1
    arc_1_6_20  original_T_including_depot_unload_1227  2.0104743468619281e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_20  arc_capacity_859  1
    load_1_6_20  segment_load_conservation_1151  1
    load_1_6_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_21  arc_capacity_861  -25
    arc_1_6_21  connected_order_arc_862  -14
    arc_1_6_21  out_degree_1147  1
    arc_1_6_21  in_degree_1218  1
    arc_1_6_21  original_T_including_depot_unload_1227  4.6588884124393707e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_21  arc_capacity_861  1
    load_1_6_21  segment_load_conservation_1151  1
    load_1_6_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_863  -25
    arc_1_7_0  depot_return_or_bypass_1139  1
    arc_1_7_0  out_degree_1154  1
    arc_1_7_0  original_T_including_depot_unload_1227  1.2751323166566442e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_863  1
    load_1_7_0  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_5  arc_capacity_864  -25
    arc_1_7_5  connected_order_arc_865  -14
    arc_1_7_5  in_degree_1141  1
    arc_1_7_5  out_degree_1154  1
    arc_1_7_5  original_T_including_depot_unload_1227  4.8905010520753694e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_5  arc_capacity_864  1
    load_1_7_5  segment_load_conservation_1144  -1
    load_1_7_5  segment_prefix_lb_1145  1
    load_1_7_5  segment_prefix_ub_1146  1
    load_1_7_5  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_866  -25
    arc_1_7_6  connected_order_arc_867  -14
    arc_1_7_6  in_degree_1148  1
    arc_1_7_6  out_degree_1154  1
    arc_1_7_6  original_T_including_depot_unload_1227  8.2035300709080423e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_866  1
    load_1_7_6  segment_load_conservation_1151  -1
    load_1_7_6  segment_prefix_lb_1152  1
    load_1_7_6  segment_prefix_ub_1153  1
    load_1_7_6  segment_load_conservation_1158  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_868  -25
    arc_1_7_8  connected_order_arc_869  -14
    arc_1_7_8  out_degree_1154  1
    arc_1_7_8  in_degree_1162  1
    arc_1_7_8  original_T_including_depot_unload_1227  1.1310682908759807e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_868  1
    load_1_7_8  segment_load_conservation_1158  1
    load_1_7_8  segment_load_conservation_1165  -1
    load_1_7_8  segment_prefix_lb_1166  1
    load_1_7_8  segment_prefix_ub_1167  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_870  -25
    arc_1_7_9  connected_order_arc_871  -14
    arc_1_7_9  out_degree_1154  1
    arc_1_7_9  in_degree_1169  1
    arc_1_7_9  original_T_including_depot_unload_1227  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_870  1
    load_1_7_9  segment_load_conservation_1158  1
    load_1_7_9  segment_load_conservation_1172  -1
    load_1_7_9  segment_prefix_lb_1173  1
    load_1_7_9  segment_prefix_ub_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_872  -25
    arc_1_7_14  connected_order_arc_873  -14
    arc_1_7_14  out_degree_1154  1
    arc_1_7_14  in_degree_1176  1
    arc_1_7_14  original_T_including_depot_unload_1227  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_872  1
    load_1_7_14  segment_load_conservation_1158  1
    load_1_7_14  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_874  -25
    arc_1_7_15  connected_order_arc_875  -14
    arc_1_7_15  out_degree_1154  1
    arc_1_7_15  in_degree_1182  1
    arc_1_7_15  original_T_including_depot_unload_1227  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_874  1
    load_1_7_15  segment_load_conservation_1158  1
    load_1_7_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_16  arc_capacity_876  -25
    arc_1_7_16  connected_order_arc_877  -14
    arc_1_7_16  out_degree_1154  1
    arc_1_7_16  in_degree_1188  1
    arc_1_7_16  original_T_including_depot_unload_1227  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_16  arc_capacity_876  1
    load_1_7_16  segment_load_conservation_1158  1
    load_1_7_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_17  arc_capacity_878  -25
    arc_1_7_17  connected_order_arc_879  -14
    arc_1_7_17  out_degree_1154  1
    arc_1_7_17  in_degree_1194  1
    arc_1_7_17  original_T_including_depot_unload_1227  7.7983683767935065e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_17  arc_capacity_878  1
    load_1_7_17  segment_load_conservation_1158  1
    load_1_7_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_18  arc_capacity_880  -25
    arc_1_7_18  connected_order_arc_881  -14
    arc_1_7_18  out_degree_1154  1
    arc_1_7_18  in_degree_1200  1
    arc_1_7_18  original_T_including_depot_unload_1227  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_7_18  arc_capacity_880  1
    load_1_7_18  segment_load_conservation_1158  1
    load_1_7_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_19  arc_capacity_882  -25
    arc_1_7_19  connected_order_arc_883  -14
    arc_1_7_19  out_degree_1154  1
    arc_1_7_19  in_degree_1206  1
    arc_1_7_19  original_T_including_depot_unload_1227  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_19  arc_capacity_882  1
    load_1_7_19  segment_load_conservation_1158  1
    load_1_7_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_20  arc_capacity_884  -25
    arc_1_7_20  connected_order_arc_885  -14
    arc_1_7_20  out_degree_1154  1
    arc_1_7_20  in_degree_1212  1
    arc_1_7_20  original_T_including_depot_unload_1227  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_20  arc_capacity_884  1
    load_1_7_20  segment_load_conservation_1158  1
    load_1_7_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_21  arc_capacity_886  -25
    arc_1_7_21  connected_order_arc_887  -14
    arc_1_7_21  out_degree_1154  1
    arc_1_7_21  in_degree_1218  1
    arc_1_7_21  original_T_including_depot_unload_1227  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_21  arc_capacity_886  1
    load_1_7_21  segment_load_conservation_1158  1
    load_1_7_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_888  -25
    arc_1_8_0  depot_return_or_bypass_1139  1
    arc_1_8_0  out_degree_1161  1
    arc_1_8_0  original_T_including_depot_unload_1227  4.7522445589173662e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_888  1
    load_1_8_0  segment_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_5  arc_capacity_889  -25
    arc_1_8_5  connected_order_arc_890  -14
    arc_1_8_5  in_degree_1141  1
    arc_1_8_5  out_degree_1161  1
    arc_1_8_5  original_T_including_depot_unload_1227  9.0121368945211725e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_5  arc_capacity_889  1
    load_1_8_5  segment_load_conservation_1144  -1
    load_1_8_5  segment_prefix_lb_1145  1
    load_1_8_5  segment_prefix_ub_1146  1
    load_1_8_5  segment_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_891  -25
    arc_1_8_6  connected_order_arc_892  -14
    arc_1_8_6  in_degree_1148  1
    arc_1_8_6  out_degree_1161  1
    arc_1_8_6  original_T_including_depot_unload_1227  1.0793944823036150e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_891  1
    load_1_8_6  segment_load_conservation_1151  -1
    load_1_8_6  segment_prefix_lb_1152  1
    load_1_8_6  segment_prefix_ub_1153  1
    load_1_8_6  segment_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_893  -25
    arc_1_8_7  connected_order_arc_894  -14
    arc_1_8_7  in_degree_1155  1
    arc_1_8_7  out_degree_1161  1
    arc_1_8_7  original_T_including_depot_unload_1227  1.1310682908759807e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_893  1
    load_1_8_7  segment_load_conservation_1158  -1
    load_1_8_7  segment_prefix_lb_1159  1
    load_1_8_7  segment_prefix_ub_1160  1
    load_1_8_7  segment_load_conservation_1165  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_895  -25
    arc_1_8_9  connected_order_arc_896  -14
    arc_1_8_9  out_degree_1161  1
    arc_1_8_9  in_degree_1169  1
    arc_1_8_9  original_T_including_depot_unload_1227  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_895  1
    load_1_8_9  segment_load_conservation_1165  1
    load_1_8_9  segment_load_conservation_1172  -1
    load_1_8_9  segment_prefix_lb_1173  1
    load_1_8_9  segment_prefix_ub_1174  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_897  -25
    arc_1_8_14  connected_order_arc_898  -14
    arc_1_8_14  out_degree_1161  1
    arc_1_8_14  in_degree_1176  1
    arc_1_8_14  original_T_including_depot_unload_1227  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_897  1
    load_1_8_14  segment_load_conservation_1165  1
    load_1_8_14  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_899  -25
    arc_1_8_15  connected_order_arc_900  -14
    arc_1_8_15  out_degree_1161  1
    arc_1_8_15  in_degree_1182  1
    arc_1_8_15  original_T_including_depot_unload_1227  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_899  1
    load_1_8_15  segment_load_conservation_1165  1
    load_1_8_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_16  arc_capacity_901  -25
    arc_1_8_16  connected_order_arc_902  -14
    arc_1_8_16  out_degree_1161  1
    arc_1_8_16  in_degree_1188  1
    arc_1_8_16  original_T_including_depot_unload_1227  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_16  arc_capacity_901  1
    load_1_8_16  segment_load_conservation_1165  1
    load_1_8_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_17  arc_capacity_903  -25
    arc_1_8_17  connected_order_arc_904  -14
    arc_1_8_17  out_degree_1161  1
    arc_1_8_17  in_degree_1194  1
    arc_1_8_17  original_T_including_depot_unload_1227  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_17  arc_capacity_903  1
    load_1_8_17  segment_load_conservation_1165  1
    load_1_8_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_18  arc_capacity_905  -25
    arc_1_8_18  connected_order_arc_906  -14
    arc_1_8_18  out_degree_1161  1
    arc_1_8_18  in_degree_1200  1
    arc_1_8_18  original_T_including_depot_unload_1227  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_18  arc_capacity_905  1
    load_1_8_18  segment_load_conservation_1165  1
    load_1_8_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_19  arc_capacity_907  -25
    arc_1_8_19  connected_order_arc_908  -14
    arc_1_8_19  out_degree_1161  1
    arc_1_8_19  in_degree_1206  1
    arc_1_8_19  original_T_including_depot_unload_1227  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_19  arc_capacity_907  1
    load_1_8_19  segment_load_conservation_1165  1
    load_1_8_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_20  arc_capacity_909  -25
    arc_1_8_20  connected_order_arc_910  -14
    arc_1_8_20  out_degree_1161  1
    arc_1_8_20  in_degree_1212  1
    arc_1_8_20  original_T_including_depot_unload_1227  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_20  arc_capacity_909  1
    load_1_8_20  segment_load_conservation_1165  1
    load_1_8_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_21  arc_capacity_911  -25
    arc_1_8_21  connected_order_arc_912  -14
    arc_1_8_21  out_degree_1161  1
    arc_1_8_21  in_degree_1218  1
    arc_1_8_21  original_T_including_depot_unload_1227  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_21  arc_capacity_911  1
    load_1_8_21  segment_load_conservation_1165  1
    load_1_8_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_913  -25
    arc_1_9_0  depot_return_or_bypass_1139  1
    arc_1_9_0  out_degree_1168  1
    arc_1_9_0  original_T_including_depot_unload_1227  1.2557664269902365e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_913  1
    load_1_9_0  segment_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_5  arc_capacity_914  -25
    arc_1_9_5  connected_order_arc_915  -14
    arc_1_9_5  in_degree_1141  1
    arc_1_9_5  out_degree_1168  1
    arc_1_9_5  original_T_including_depot_unload_1227  7.5571464781430223e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_5  arc_capacity_914  1
    load_1_9_5  segment_load_conservation_1144  -1
    load_1_9_5  segment_prefix_lb_1145  1
    load_1_9_5  segment_prefix_ub_1146  1
    load_1_9_5  segment_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_916  -25
    arc_1_9_6  connected_order_arc_917  -14
    arc_1_9_6  in_degree_1148  1
    arc_1_9_6  out_degree_1168  1
    arc_1_9_6  original_T_including_depot_unload_1227  7.5634788469878674e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_916  1
    load_1_9_6  segment_load_conservation_1151  -1
    load_1_9_6  segment_prefix_lb_1152  1
    load_1_9_6  segment_prefix_ub_1153  1
    load_1_9_6  segment_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_918  -25
    arc_1_9_7  connected_order_arc_919  -14
    arc_1_9_7  in_degree_1155  1
    arc_1_9_7  out_degree_1168  1
    arc_1_9_7  original_T_including_depot_unload_1227  1.1663816070445826e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_918  1
    load_1_9_7  segment_load_conservation_1158  -1
    load_1_9_7  segment_prefix_lb_1159  1
    load_1_9_7  segment_prefix_ub_1160  1
    load_1_9_7  segment_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_920  -25
    arc_1_9_8  connected_order_arc_921  -14
    arc_1_9_8  in_degree_1162  1
    arc_1_9_8  out_degree_1168  1
    arc_1_9_8  original_T_including_depot_unload_1227  4.9232225330062903e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_920  1
    load_1_9_8  segment_load_conservation_1165  -1
    load_1_9_8  segment_prefix_lb_1166  1
    load_1_9_8  segment_prefix_ub_1167  1
    load_1_9_8  segment_load_conservation_1172  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_922  -25
    arc_1_9_14  connected_order_arc_923  -14
    arc_1_9_14  out_degree_1168  1
    arc_1_9_14  in_degree_1176  1
    arc_1_9_14  original_T_including_depot_unload_1227  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_922  1
    load_1_9_14  segment_load_conservation_1172  1
    load_1_9_14  free_load_conservation_1180  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_924  -25
    arc_1_9_15  connected_order_arc_925  -14
    arc_1_9_15  out_degree_1168  1
    arc_1_9_15  in_degree_1182  1
    arc_1_9_15  original_T_including_depot_unload_1227  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_924  1
    load_1_9_15  segment_load_conservation_1172  1
    load_1_9_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_16  arc_capacity_926  -25
    arc_1_9_16  connected_order_arc_927  -14
    arc_1_9_16  out_degree_1168  1
    arc_1_9_16  in_degree_1188  1
    arc_1_9_16  original_T_including_depot_unload_1227  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_16  arc_capacity_926  1
    load_1_9_16  segment_load_conservation_1172  1
    load_1_9_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_17  arc_capacity_928  -25
    arc_1_9_17  connected_order_arc_929  -14
    arc_1_9_17  out_degree_1168  1
    arc_1_9_17  in_degree_1194  1
    arc_1_9_17  original_T_including_depot_unload_1227  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_17  arc_capacity_928  1
    load_1_9_17  segment_load_conservation_1172  1
    load_1_9_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_18  arc_capacity_930  -25
    arc_1_9_18  connected_order_arc_931  -14
    arc_1_9_18  out_degree_1168  1
    arc_1_9_18  in_degree_1200  1
    arc_1_9_18  original_T_including_depot_unload_1227  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_18  arc_capacity_930  1
    load_1_9_18  segment_load_conservation_1172  1
    load_1_9_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_19  arc_capacity_932  -25
    arc_1_9_19  connected_order_arc_933  -14
    arc_1_9_19  out_degree_1168  1
    arc_1_9_19  in_degree_1206  1
    arc_1_9_19  original_T_including_depot_unload_1227  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_19  arc_capacity_932  1
    load_1_9_19  segment_load_conservation_1172  1
    load_1_9_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_20  arc_capacity_934  -25
    arc_1_9_20  connected_order_arc_935  -14
    arc_1_9_20  out_degree_1168  1
    arc_1_9_20  in_degree_1212  1
    arc_1_9_20  original_T_including_depot_unload_1227  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_20  arc_capacity_934  1
    load_1_9_20  segment_load_conservation_1172  1
    load_1_9_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_21  arc_capacity_936  -25
    arc_1_9_21  connected_order_arc_937  -14
    arc_1_9_21  out_degree_1168  1
    arc_1_9_21  in_degree_1218  1
    arc_1_9_21  original_T_including_depot_unload_1227  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_21  arc_capacity_936  1
    load_1_9_21  segment_load_conservation_1172  1
    load_1_9_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_938  -25
    arc_1_14_0  depot_return_or_bypass_1139  1
    arc_1_14_0  out_degree_1175  1
    arc_1_14_0  original_T_including_depot_unload_1227  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_938  1
    load_1_14_0  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_5  arc_capacity_939  -25
    arc_1_14_5  connected_order_arc_940  -14
    arc_1_14_5  in_degree_1141  1
    arc_1_14_5  out_degree_1175  1
    arc_1_14_5  original_T_including_depot_unload_1227  9.5892865701726816e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_5  arc_capacity_939  1
    load_1_14_5  segment_load_conservation_1144  -1
    load_1_14_5  segment_prefix_lb_1145  1
    load_1_14_5  segment_prefix_ub_1146  1
    load_1_14_5  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_941  -25
    arc_1_14_6  connected_order_arc_942  -14
    arc_1_14_6  in_degree_1148  1
    arc_1_14_6  out_degree_1175  1
    arc_1_14_6  original_T_including_depot_unload_1227  1.3197014959146461e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_941  1
    load_1_14_6  segment_load_conservation_1151  -1
    load_1_14_6  segment_prefix_lb_1152  1
    load_1_14_6  segment_prefix_ub_1153  1
    load_1_14_6  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_943  -25
    arc_1_14_7  connected_order_arc_944  -14
    arc_1_14_7  in_degree_1155  1
    arc_1_14_7  out_degree_1175  1
    arc_1_14_7  original_T_including_depot_unload_1227  726.017738185843
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_943  1
    load_1_14_7  segment_load_conservation_1158  -1
    load_1_14_7  segment_prefix_lb_1159  1
    load_1_14_7  segment_prefix_ub_1160  1
    load_1_14_7  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_945  -25
    arc_1_14_8  connected_order_arc_946  -14
    arc_1_14_8  in_degree_1162  1
    arc_1_14_8  out_degree_1175  1
    arc_1_14_8  original_T_including_depot_unload_1227  8.9356126423557316e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_945  1
    load_1_14_8  segment_load_conservation_1165  -1
    load_1_14_8  segment_prefix_lb_1166  1
    load_1_14_8  segment_prefix_ub_1167  1
    load_1_14_8  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_947  -25
    arc_1_14_9  connected_order_arc_948  -14
    arc_1_14_9  in_degree_1169  1
    arc_1_14_9  out_degree_1175  1
    arc_1_14_9  original_T_including_depot_unload_1227  1.2253808824170035e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_947  1
    load_1_14_9  segment_load_conservation_1172  -1
    load_1_14_9  segment_prefix_lb_1173  1
    load_1_14_9  segment_prefix_ub_1174  1
    load_1_14_9  free_load_conservation_1180  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_949  -25
    arc_1_14_15  connected_order_arc_950  -14
    arc_1_14_15  out_degree_1175  1
    arc_1_14_15  in_degree_1182  1
    arc_1_14_15  original_T_including_depot_unload_1227  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_949  1
    load_1_14_15  free_load_conservation_1180  1
    load_1_14_15  free_load_conservation_1186  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_16  arc_capacity_951  -25
    arc_1_14_16  connected_order_arc_952  -14
    arc_1_14_16  out_degree_1175  1
    arc_1_14_16  in_degree_1188  1
    arc_1_14_16  original_T_including_depot_unload_1227  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_16  arc_capacity_951  1
    load_1_14_16  free_load_conservation_1180  1
    load_1_14_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_17  arc_capacity_953  -25
    arc_1_14_17  connected_order_arc_954  -14
    arc_1_14_17  out_degree_1175  1
    arc_1_14_17  in_degree_1194  1
    arc_1_14_17  original_T_including_depot_unload_1227  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_17  arc_capacity_953  1
    load_1_14_17  free_load_conservation_1180  1
    load_1_14_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_18  arc_capacity_955  -25
    arc_1_14_18  connected_order_arc_956  -14
    arc_1_14_18  out_degree_1175  1
    arc_1_14_18  in_degree_1200  1
    arc_1_14_18  original_T_including_depot_unload_1227  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_18  arc_capacity_955  1
    load_1_14_18  free_load_conservation_1180  1
    load_1_14_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_19  arc_capacity_957  -25
    arc_1_14_19  connected_order_arc_958  -14
    arc_1_14_19  out_degree_1175  1
    arc_1_14_19  in_degree_1206  1
    arc_1_14_19  original_T_including_depot_unload_1227  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_19  arc_capacity_957  1
    load_1_14_19  free_load_conservation_1180  1
    load_1_14_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_20  arc_capacity_959  -25
    arc_1_14_20  connected_order_arc_960  -14
    arc_1_14_20  out_degree_1175  1
    arc_1_14_20  in_degree_1212  1
    arc_1_14_20  original_T_including_depot_unload_1227  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_20  arc_capacity_959  1
    load_1_14_20  free_load_conservation_1180  1
    load_1_14_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_21  arc_capacity_961  -25
    arc_1_14_21  connected_order_arc_962  -14
    arc_1_14_21  out_degree_1175  1
    arc_1_14_21  in_degree_1218  1
    arc_1_14_21  original_T_including_depot_unload_1227  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_21  arc_capacity_961  1
    load_1_14_21  free_load_conservation_1180  1
    load_1_14_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_963  -25
    arc_1_15_0  depot_return_or_bypass_1139  1
    arc_1_15_0  out_degree_1181  1
    arc_1_15_0  original_T_including_depot_unload_1227  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_963  1
    load_1_15_0  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_5  arc_capacity_964  -25
    arc_1_15_5  connected_order_arc_965  -14
    arc_1_15_5  in_degree_1141  1
    arc_1_15_5  out_degree_1181  1
    arc_1_15_5  original_T_including_depot_unload_1227  8.0195161088934185e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_5  arc_capacity_964  1
    load_1_15_5  segment_load_conservation_1144  -1
    load_1_15_5  segment_prefix_lb_1145  1
    load_1_15_5  segment_prefix_ub_1146  1
    load_1_15_5  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_966  -25
    arc_1_15_6  connected_order_arc_967  -14
    arc_1_15_6  in_degree_1148  1
    arc_1_15_6  out_degree_1181  1
    arc_1_15_6  original_T_including_depot_unload_1227  1.1360772387139011e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_966  1
    load_1_15_6  segment_load_conservation_1151  -1
    load_1_15_6  segment_prefix_lb_1152  1
    load_1_15_6  segment_prefix_ub_1153  1
    load_1_15_6  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_968  -25
    arc_1_15_7  connected_order_arc_969  -14
    arc_1_15_7  in_degree_1155  1
    arc_1_15_7  out_degree_1181  1
    arc_1_15_7  original_T_including_depot_unload_1227  7.3382689952363592e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_968  1
    load_1_15_7  segment_load_conservation_1158  -1
    load_1_15_7  segment_prefix_lb_1159  1
    load_1_15_7  segment_prefix_ub_1160  1
    load_1_15_7  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_970  -25
    arc_1_15_8  connected_order_arc_971  -14
    arc_1_15_8  in_degree_1162  1
    arc_1_15_8  out_degree_1181  1
    arc_1_15_8  original_T_including_depot_unload_1227  6.0342879231962252e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_970  1
    load_1_15_8  segment_load_conservation_1165  -1
    load_1_15_8  segment_prefix_lb_1166  1
    load_1_15_8  segment_prefix_ub_1167  1
    load_1_15_8  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_972  -25
    arc_1_15_9  connected_order_arc_973  -14
    arc_1_15_9  in_degree_1169  1
    arc_1_15_9  out_degree_1181  1
    arc_1_15_9  original_T_including_depot_unload_1227  9.3918874471053675e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_972  1
    load_1_15_9  segment_load_conservation_1172  -1
    load_1_15_9  segment_prefix_lb_1173  1
    load_1_15_9  segment_prefix_ub_1174  1
    load_1_15_9  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_974  -25
    arc_1_15_14  connected_order_arc_975  -14
    arc_1_15_14  in_degree_1176  1
    arc_1_15_14  out_degree_1181  1
    arc_1_15_14  original_T_including_depot_unload_1227  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_974  1
    load_1_15_14  free_load_conservation_1180  -1
    load_1_15_14  free_load_conservation_1186  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_16  arc_capacity_976  -25
    arc_1_15_16  connected_order_arc_977  -14
    arc_1_15_16  out_degree_1181  1
    arc_1_15_16  in_degree_1188  1
    arc_1_15_16  original_T_including_depot_unload_1227  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_16  arc_capacity_976  1
    load_1_15_16  free_load_conservation_1186  1
    load_1_15_16  free_load_conservation_1192  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_17  arc_capacity_978  -25
    arc_1_15_17  connected_order_arc_979  -14
    arc_1_15_17  out_degree_1181  1
    arc_1_15_17  in_degree_1194  1
    arc_1_15_17  original_T_including_depot_unload_1227  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_17  arc_capacity_978  1
    load_1_15_17  free_load_conservation_1186  1
    load_1_15_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_18  arc_capacity_980  -25
    arc_1_15_18  connected_order_arc_981  -14
    arc_1_15_18  out_degree_1181  1
    arc_1_15_18  in_degree_1200  1
    arc_1_15_18  original_T_including_depot_unload_1227  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_18  arc_capacity_980  1
    load_1_15_18  free_load_conservation_1186  1
    load_1_15_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_19  arc_capacity_982  -25
    arc_1_15_19  connected_order_arc_983  -14
    arc_1_15_19  out_degree_1181  1
    arc_1_15_19  in_degree_1206  1
    arc_1_15_19  original_T_including_depot_unload_1227  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_19  arc_capacity_982  1
    load_1_15_19  free_load_conservation_1186  1
    load_1_15_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_20  arc_capacity_984  -25
    arc_1_15_20  connected_order_arc_985  -14
    arc_1_15_20  out_degree_1181  1
    arc_1_15_20  in_degree_1212  1
    arc_1_15_20  original_T_including_depot_unload_1227  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_20  arc_capacity_984  1
    load_1_15_20  free_load_conservation_1186  1
    load_1_15_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_21  arc_capacity_986  -25
    arc_1_15_21  connected_order_arc_987  -14
    arc_1_15_21  out_degree_1181  1
    arc_1_15_21  in_degree_1218  1
    arc_1_15_21  original_T_including_depot_unload_1227  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_21  arc_capacity_986  1
    load_1_15_21  free_load_conservation_1186  1
    load_1_15_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_0  arc_capacity_988  -25
    arc_1_16_0  depot_return_or_bypass_1139  1
    arc_1_16_0  out_degree_1187  1
    arc_1_16_0  original_T_including_depot_unload_1227  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_0  arc_capacity_988  1
    load_1_16_0  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_5  arc_capacity_989  -25
    arc_1_16_5  connected_order_arc_990  -14
    arc_1_16_5  in_degree_1141  1
    arc_1_16_5  out_degree_1187  1
    arc_1_16_5  original_T_including_depot_unload_1227  7.3227602527872671e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_5  arc_capacity_989  1
    load_1_16_5  segment_load_conservation_1144  -1
    load_1_16_5  segment_prefix_lb_1145  1
    load_1_16_5  segment_prefix_ub_1146  1
    load_1_16_5  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_6  arc_capacity_991  -25
    arc_1_16_6  connected_order_arc_992  -14
    arc_1_16_6  in_degree_1148  1
    arc_1_16_6  out_degree_1187  1
    arc_1_16_6  original_T_including_depot_unload_1227  3.6824909986567474e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_6  arc_capacity_991  1
    load_1_16_6  segment_load_conservation_1151  -1
    load_1_16_6  segment_prefix_lb_1152  1
    load_1_16_6  segment_prefix_ub_1153  1
    load_1_16_6  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_7  arc_capacity_993  -25
    arc_1_16_7  connected_order_arc_994  -14
    arc_1_16_7  in_degree_1155  1
    arc_1_16_7  out_degree_1187  1
    arc_1_16_7  original_T_including_depot_unload_1227  1.1499210972200315e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_7  arc_capacity_993  1
    load_1_16_7  segment_load_conservation_1158  -1
    load_1_16_7  segment_prefix_lb_1159  1
    load_1_16_7  segment_prefix_ub_1160  1
    load_1_16_7  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_8  arc_capacity_995  -25
    arc_1_16_8  connected_order_arc_996  -14
    arc_1_16_8  in_degree_1162  1
    arc_1_16_8  out_degree_1187  1
    arc_1_16_8  original_T_including_depot_unload_1227  1.3823927712314810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_8  arc_capacity_995  1
    load_1_16_8  segment_load_conservation_1165  -1
    load_1_16_8  segment_prefix_lb_1166  1
    load_1_16_8  segment_prefix_ub_1167  1
    load_1_16_8  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_9  arc_capacity_997  -25
    arc_1_16_9  connected_order_arc_998  -14
    arc_1_16_9  in_degree_1169  1
    arc_1_16_9  out_degree_1187  1
    arc_1_16_9  original_T_including_depot_unload_1227  9.7751651081612306e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_16_9  arc_capacity_997  1
    load_1_16_9  segment_load_conservation_1172  -1
    load_1_16_9  segment_prefix_lb_1173  1
    load_1_16_9  segment_prefix_ub_1174  1
    load_1_16_9  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_14  arc_capacity_999  -25
    arc_1_16_14  connected_order_arc_1000  -14
    arc_1_16_14  in_degree_1176  1
    arc_1_16_14  out_degree_1187  1
    arc_1_16_14  original_T_including_depot_unload_1227  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_14  arc_capacity_999  1
    load_1_16_14  free_load_conservation_1180  -1
    load_1_16_14  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_15  arc_capacity_1001  -25
    arc_1_16_15  connected_order_arc_1002  -14
    arc_1_16_15  in_degree_1182  1
    arc_1_16_15  out_degree_1187  1
    arc_1_16_15  original_T_including_depot_unload_1227  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_15  arc_capacity_1001  1
    load_1_16_15  free_load_conservation_1186  -1
    load_1_16_15  free_load_conservation_1192  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_17  arc_capacity_1003  -25
    arc_1_16_17  connected_order_arc_1004  -14
    arc_1_16_17  out_degree_1187  1
    arc_1_16_17  in_degree_1194  1
    arc_1_16_17  original_T_including_depot_unload_1227  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_17  arc_capacity_1003  1
    load_1_16_17  free_load_conservation_1192  1
    load_1_16_17  free_load_conservation_1198  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_18  arc_capacity_1005  -25
    arc_1_16_18  connected_order_arc_1006  -14
    arc_1_16_18  out_degree_1187  1
    arc_1_16_18  in_degree_1200  1
    arc_1_16_18  original_T_including_depot_unload_1227  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_18  arc_capacity_1005  1
    load_1_16_18  free_load_conservation_1192  1
    load_1_16_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_19  arc_capacity_1007  -25
    arc_1_16_19  connected_order_arc_1008  -14
    arc_1_16_19  out_degree_1187  1
    arc_1_16_19  in_degree_1206  1
    arc_1_16_19  original_T_including_depot_unload_1227  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_19  arc_capacity_1007  1
    load_1_16_19  free_load_conservation_1192  1
    load_1_16_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_20  arc_capacity_1009  -25
    arc_1_16_20  connected_order_arc_1010  -14
    arc_1_16_20  out_degree_1187  1
    arc_1_16_20  in_degree_1212  1
    arc_1_16_20  original_T_including_depot_unload_1227  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_20  arc_capacity_1009  1
    load_1_16_20  free_load_conservation_1192  1
    load_1_16_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_16_21  arc_capacity_1011  -25
    arc_1_16_21  connected_order_arc_1012  -14
    arc_1_16_21  out_degree_1187  1
    arc_1_16_21  in_degree_1218  1
    arc_1_16_21  original_T_including_depot_unload_1227  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_16_21  arc_capacity_1011  1
    load_1_16_21  free_load_conservation_1192  1
    load_1_16_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_0  arc_capacity_1013  -25
    arc_1_17_0  depot_return_or_bypass_1139  1
    arc_1_17_0  out_degree_1193  1
    arc_1_17_0  original_T_including_depot_unload_1227  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_1_17_0  arc_capacity_1013  1
    load_1_17_0  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_5  arc_capacity_1014  -25
    arc_1_17_5  connected_order_arc_1015  -14
    arc_1_17_5  in_degree_1141  1
    arc_1_17_5  out_degree_1193  1
    arc_1_17_5  original_T_including_depot_unload_1227  7.8136221151890174e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_5  arc_capacity_1014  1
    load_1_17_5  segment_load_conservation_1144  -1
    load_1_17_5  segment_prefix_lb_1145  1
    load_1_17_5  segment_prefix_ub_1146  1
    load_1_17_5  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_6  arc_capacity_1016  -25
    arc_1_17_6  connected_order_arc_1017  -14
    arc_1_17_6  in_degree_1148  1
    arc_1_17_6  out_degree_1193  1
    arc_1_17_6  original_T_including_depot_unload_1227  1.0967168052209140e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_6  arc_capacity_1016  1
    load_1_17_6  segment_load_conservation_1151  -1
    load_1_17_6  segment_prefix_lb_1152  1
    load_1_17_6  segment_prefix_ub_1153  1
    load_1_17_6  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_7  arc_capacity_1018  -25
    arc_1_17_7  connected_order_arc_1019  -14
    arc_1_17_7  in_degree_1155  1
    arc_1_17_7  out_degree_1193  1
    arc_1_17_7  original_T_including_depot_unload_1227  7.7983683767935065e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_7  arc_capacity_1018  1
    load_1_17_7  segment_load_conservation_1158  -1
    load_1_17_7  segment_prefix_lb_1159  1
    load_1_17_7  segment_prefix_ub_1160  1
    load_1_17_7  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_8  arc_capacity_1020  -25
    arc_1_17_8  connected_order_arc_1021  -14
    arc_1_17_8  in_degree_1162  1
    arc_1_17_8  out_degree_1193  1
    arc_1_17_8  original_T_including_depot_unload_1227  4.9711893625650669e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_8  arc_capacity_1020  1
    load_1_17_8  segment_load_conservation_1165  -1
    load_1_17_8  segment_prefix_lb_1166  1
    load_1_17_8  segment_prefix_ub_1167  1
    load_1_17_8  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_9  arc_capacity_1022  -25
    arc_1_17_9  connected_order_arc_1023  -14
    arc_1_17_9  in_degree_1169  1
    arc_1_17_9  out_degree_1193  1
    arc_1_17_9  original_T_including_depot_unload_1227  8.4332546654485930e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_9  arc_capacity_1022  1
    load_1_17_9  segment_load_conservation_1172  -1
    load_1_17_9  segment_prefix_lb_1173  1
    load_1_17_9  segment_prefix_ub_1174  1
    load_1_17_9  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_14  arc_capacity_1024  -25
    arc_1_17_14  connected_order_arc_1025  -14
    arc_1_17_14  in_degree_1176  1
    arc_1_17_14  out_degree_1193  1
    arc_1_17_14  original_T_including_depot_unload_1227  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_14  arc_capacity_1024  1
    load_1_17_14  free_load_conservation_1180  -1
    load_1_17_14  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_15  arc_capacity_1026  -25
    arc_1_17_15  connected_order_arc_1027  -14
    arc_1_17_15  in_degree_1182  1
    arc_1_17_15  out_degree_1193  1
    arc_1_17_15  original_T_including_depot_unload_1227  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_15  arc_capacity_1026  1
    load_1_17_15  free_load_conservation_1186  -1
    load_1_17_15  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_16  arc_capacity_1028  -25
    arc_1_17_16  connected_order_arc_1029  -14
    arc_1_17_16  in_degree_1188  1
    arc_1_17_16  out_degree_1193  1
    arc_1_17_16  original_T_including_depot_unload_1227  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_17_16  arc_capacity_1028  1
    load_1_17_16  free_load_conservation_1192  -1
    load_1_17_16  free_load_conservation_1198  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_18  arc_capacity_1030  -25
    arc_1_17_18  connected_order_arc_1031  -14
    arc_1_17_18  out_degree_1193  1
    arc_1_17_18  in_degree_1200  1
    arc_1_17_18  original_T_including_depot_unload_1227  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_18  arc_capacity_1030  1
    load_1_17_18  free_load_conservation_1198  1
    load_1_17_18  free_load_conservation_1204  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_19  arc_capacity_1032  -25
    arc_1_17_19  connected_order_arc_1033  -14
    arc_1_17_19  out_degree_1193  1
    arc_1_17_19  in_degree_1206  1
    arc_1_17_19  original_T_including_depot_unload_1227  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_19  arc_capacity_1032  1
    load_1_17_19  free_load_conservation_1198  1
    load_1_17_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_20  arc_capacity_1034  -25
    arc_1_17_20  connected_order_arc_1035  -14
    arc_1_17_20  out_degree_1193  1
    arc_1_17_20  in_degree_1212  1
    arc_1_17_20  original_T_including_depot_unload_1227  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_17_20  arc_capacity_1034  1
    load_1_17_20  free_load_conservation_1198  1
    load_1_17_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_17_21  arc_capacity_1036  -25
    arc_1_17_21  connected_order_arc_1037  -14
    arc_1_17_21  out_degree_1193  1
    arc_1_17_21  in_degree_1218  1
    arc_1_17_21  original_T_including_depot_unload_1227  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_17_21  arc_capacity_1036  1
    load_1_17_21  free_load_conservation_1198  1
    load_1_17_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_0  arc_capacity_1038  -25
    arc_1_18_0  depot_return_or_bypass_1139  1
    arc_1_18_0  out_degree_1199  1
    arc_1_18_0  original_T_including_depot_unload_1227  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_0  arc_capacity_1038  1
    load_1_18_0  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_5  arc_capacity_1039  -25
    arc_1_18_5  connected_order_arc_1040  -14
    arc_1_18_5  in_degree_1141  1
    arc_1_18_5  out_degree_1199  1
    arc_1_18_5  original_T_including_depot_unload_1227  8.1417957710766450e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_5  arc_capacity_1039  1
    load_1_18_5  segment_load_conservation_1144  -1
    load_1_18_5  segment_prefix_lb_1145  1
    load_1_18_5  segment_prefix_ub_1146  1
    load_1_18_5  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_6  arc_capacity_1041  -25
    arc_1_18_6  connected_order_arc_1042  -14
    arc_1_18_6  in_degree_1148  1
    arc_1_18_6  out_degree_1199  1
    arc_1_18_6  original_T_including_depot_unload_1227  1.0412376551742484e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_6  arc_capacity_1041  1
    load_1_18_6  segment_load_conservation_1151  -1
    load_1_18_6  segment_prefix_lb_1152  1
    load_1_18_6  segment_prefix_ub_1153  1
    load_1_18_6  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_7  arc_capacity_1043  -25
    arc_1_18_7  connected_order_arc_1044  -14
    arc_1_18_7  in_degree_1155  1
    arc_1_18_7  out_degree_1199  1
    arc_1_18_7  original_T_including_depot_unload_1227  990.144803963742
    MARKER    'MARKER'                 'INTEND'
    load_1_18_7  arc_capacity_1043  1
    load_1_18_7  segment_load_conservation_1158  -1
    load_1_18_7  segment_prefix_lb_1159  1
    load_1_18_7  segment_prefix_ub_1160  1
    load_1_18_7  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_8  arc_capacity_1045  -25
    arc_1_18_8  connected_order_arc_1046  -14
    arc_1_18_8  in_degree_1162  1
    arc_1_18_8  out_degree_1199  1
    arc_1_18_8  original_T_including_depot_unload_1227  1.6444540482789353e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_8  arc_capacity_1045  1
    load_1_18_8  segment_load_conservation_1165  -1
    load_1_18_8  segment_prefix_lb_1166  1
    load_1_18_8  segment_prefix_ub_1167  1
    load_1_18_8  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_9  arc_capacity_1047  -25
    arc_1_18_9  connected_order_arc_1048  -14
    arc_1_18_9  in_degree_1169  1
    arc_1_18_9  out_degree_1199  1
    arc_1_18_9  original_T_including_depot_unload_1227  5.7102904773674652e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_9  arc_capacity_1047  1
    load_1_18_9  segment_load_conservation_1172  -1
    load_1_18_9  segment_prefix_lb_1173  1
    load_1_18_9  segment_prefix_ub_1174  1
    load_1_18_9  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_14  arc_capacity_1049  -25
    arc_1_18_14  connected_order_arc_1050  -14
    arc_1_18_14  in_degree_1176  1
    arc_1_18_14  out_degree_1199  1
    arc_1_18_14  original_T_including_depot_unload_1227  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_14  arc_capacity_1049  1
    load_1_18_14  free_load_conservation_1180  -1
    load_1_18_14  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_15  arc_capacity_1051  -25
    arc_1_18_15  connected_order_arc_1052  -14
    arc_1_18_15  in_degree_1182  1
    arc_1_18_15  out_degree_1199  1
    arc_1_18_15  original_T_including_depot_unload_1227  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_15  arc_capacity_1051  1
    load_1_18_15  free_load_conservation_1186  -1
    load_1_18_15  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_16  arc_capacity_1053  -25
    arc_1_18_16  connected_order_arc_1054  -14
    arc_1_18_16  in_degree_1188  1
    arc_1_18_16  out_degree_1199  1
    arc_1_18_16  original_T_including_depot_unload_1227  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_16  arc_capacity_1053  1
    load_1_18_16  free_load_conservation_1192  -1
    load_1_18_16  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_17  arc_capacity_1055  -25
    arc_1_18_17  connected_order_arc_1056  -14
    arc_1_18_17  in_degree_1194  1
    arc_1_18_17  out_degree_1199  1
    arc_1_18_17  original_T_including_depot_unload_1227  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_17  arc_capacity_1055  1
    load_1_18_17  free_load_conservation_1198  -1
    load_1_18_17  free_load_conservation_1204  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_19  arc_capacity_1057  -25
    arc_1_18_19  connected_order_arc_1058  -14
    arc_1_18_19  out_degree_1199  1
    arc_1_18_19  in_degree_1206  1
    arc_1_18_19  original_T_including_depot_unload_1227  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_19  arc_capacity_1057  1
    load_1_18_19  free_load_conservation_1204  1
    load_1_18_19  free_load_conservation_1210  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_20  arc_capacity_1059  -25
    arc_1_18_20  connected_order_arc_1060  -14
    arc_1_18_20  out_degree_1199  1
    arc_1_18_20  in_degree_1212  1
    arc_1_18_20  original_T_including_depot_unload_1227  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_18_20  arc_capacity_1059  1
    load_1_18_20  free_load_conservation_1204  1
    load_1_18_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_18_21  arc_capacity_1061  -25
    arc_1_18_21  connected_order_arc_1062  -14
    arc_1_18_21  out_degree_1199  1
    arc_1_18_21  in_degree_1218  1
    arc_1_18_21  original_T_including_depot_unload_1227  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_18_21  arc_capacity_1061  1
    load_1_18_21  free_load_conservation_1204  1
    load_1_18_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_0  arc_capacity_1063  -25
    arc_1_19_0  depot_return_or_bypass_1139  1
    arc_1_19_0  out_degree_1205  1
    arc_1_19_0  original_T_including_depot_unload_1227  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_0  arc_capacity_1063  1
    load_1_19_0  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_5  arc_capacity_1064  -25
    arc_1_19_5  connected_order_arc_1065  -14
    arc_1_19_5  in_degree_1141  1
    arc_1_19_5  out_degree_1205  1
    arc_1_19_5  original_T_including_depot_unload_1227  7.0804311489116617e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_5  arc_capacity_1064  1
    load_1_19_5  segment_load_conservation_1144  -1
    load_1_19_5  segment_prefix_lb_1145  1
    load_1_19_5  segment_prefix_ub_1146  1
    load_1_19_5  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_6  arc_capacity_1066  -25
    arc_1_19_6  connected_order_arc_1067  -14
    arc_1_19_6  in_degree_1148  1
    arc_1_19_6  out_degree_1205  1
    arc_1_19_6  original_T_including_depot_unload_1227  1.0062397105603651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_6  arc_capacity_1066  1
    load_1_19_6  segment_load_conservation_1151  -1
    load_1_19_6  segment_prefix_lb_1152  1
    load_1_19_6  segment_prefix_ub_1153  1
    load_1_19_6  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_7  arc_capacity_1068  -25
    arc_1_19_7  connected_order_arc_1069  -14
    arc_1_19_7  in_degree_1155  1
    arc_1_19_7  out_degree_1205  1
    arc_1_19_7  original_T_including_depot_unload_1227  7.7248128224166851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_7  arc_capacity_1068  1
    load_1_19_7  segment_load_conservation_1158  -1
    load_1_19_7  segment_prefix_lb_1159  1
    load_1_19_7  segment_prefix_ub_1160  1
    load_1_19_7  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_8  arc_capacity_1070  -25
    arc_1_19_8  connected_order_arc_1071  -14
    arc_1_19_8  in_degree_1162  1
    arc_1_19_8  out_degree_1205  1
    arc_1_19_8  original_T_including_depot_unload_1227  4.1964259385165178e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_8  arc_capacity_1070  1
    load_1_19_8  segment_load_conservation_1165  -1
    load_1_19_8  segment_prefix_lb_1166  1
    load_1_19_8  segment_prefix_ub_1167  1
    load_1_19_8  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_9  arc_capacity_1072  -25
    arc_1_19_9  connected_order_arc_1073  -14
    arc_1_19_9  in_degree_1169  1
    arc_1_19_9  out_degree_1205  1
    arc_1_19_9  original_T_including_depot_unload_1227  7.3394466063263269e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_9  arc_capacity_1072  1
    load_1_19_9  segment_load_conservation_1172  -1
    load_1_19_9  segment_prefix_lb_1173  1
    load_1_19_9  segment_prefix_ub_1174  1
    load_1_19_9  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_14  arc_capacity_1074  -25
    arc_1_19_14  connected_order_arc_1075  -14
    arc_1_19_14  in_degree_1176  1
    arc_1_19_14  out_degree_1205  1
    arc_1_19_14  original_T_including_depot_unload_1227  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_14  arc_capacity_1074  1
    load_1_19_14  free_load_conservation_1180  -1
    load_1_19_14  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_15  arc_capacity_1076  -25
    arc_1_19_15  connected_order_arc_1077  -14
    arc_1_19_15  in_degree_1182  1
    arc_1_19_15  out_degree_1205  1
    arc_1_19_15  original_T_including_depot_unload_1227  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_15  arc_capacity_1076  1
    load_1_19_15  free_load_conservation_1186  -1
    load_1_19_15  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_16  arc_capacity_1078  -25
    arc_1_19_16  connected_order_arc_1079  -14
    arc_1_19_16  in_degree_1188  1
    arc_1_19_16  out_degree_1205  1
    arc_1_19_16  original_T_including_depot_unload_1227  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_19_16  arc_capacity_1078  1
    load_1_19_16  free_load_conservation_1192  -1
    load_1_19_16  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_17  arc_capacity_1080  -25
    arc_1_19_17  connected_order_arc_1081  -14
    arc_1_19_17  in_degree_1194  1
    arc_1_19_17  out_degree_1205  1
    arc_1_19_17  original_T_including_depot_unload_1227  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_17  arc_capacity_1080  1
    load_1_19_17  free_load_conservation_1198  -1
    load_1_19_17  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_18  arc_capacity_1082  -25
    arc_1_19_18  connected_order_arc_1083  -14
    arc_1_19_18  in_degree_1200  1
    arc_1_19_18  out_degree_1205  1
    arc_1_19_18  original_T_including_depot_unload_1227  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_18  arc_capacity_1082  1
    load_1_19_18  free_load_conservation_1204  -1
    load_1_19_18  free_load_conservation_1210  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_20  arc_capacity_1084  -25
    arc_1_19_20  connected_order_arc_1085  -14
    arc_1_19_20  out_degree_1205  1
    arc_1_19_20  in_degree_1212  1
    arc_1_19_20  original_T_including_depot_unload_1227  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_19_20  arc_capacity_1084  1
    load_1_19_20  free_load_conservation_1210  1
    load_1_19_20  free_load_conservation_1216  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_19_21  arc_capacity_1086  -25
    arc_1_19_21  connected_order_arc_1087  -14
    arc_1_19_21  out_degree_1205  1
    arc_1_19_21  in_degree_1218  1
    arc_1_19_21  original_T_including_depot_unload_1227  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_19_21  arc_capacity_1086  1
    load_1_19_21  free_load_conservation_1210  1
    load_1_19_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_0  arc_capacity_1088  -25
    arc_1_20_0  depot_return_or_bypass_1139  1
    arc_1_20_0  out_degree_1211  1
    arc_1_20_0  original_T_including_depot_unload_1227  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_0  arc_capacity_1088  1
    load_1_20_0  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_5  arc_capacity_1089  -25
    arc_1_20_5  connected_order_arc_1090  -14
    arc_1_20_5  in_degree_1141  1
    arc_1_20_5  out_degree_1211  1
    arc_1_20_5  original_T_including_depot_unload_1227  1.8442669473423912e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_5  arc_capacity_1089  1
    load_1_20_5  segment_load_conservation_1144  -1
    load_1_20_5  segment_prefix_lb_1145  1
    load_1_20_5  segment_prefix_ub_1146  1
    load_1_20_5  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_6  arc_capacity_1091  -25
    arc_1_20_6  connected_order_arc_1092  -14
    arc_1_20_6  in_degree_1148  1
    arc_1_20_6  out_degree_1211  1
    arc_1_20_6  original_T_including_depot_unload_1227  1.5502221880497036e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_6  arc_capacity_1091  1
    load_1_20_6  segment_load_conservation_1151  -1
    load_1_20_6  segment_prefix_lb_1152  1
    load_1_20_6  segment_prefix_ub_1153  1
    load_1_20_6  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_7  arc_capacity_1093  -25
    arc_1_20_7  connected_order_arc_1094  -14
    arc_1_20_7  in_degree_1155  1
    arc_1_20_7  out_degree_1211  1
    arc_1_20_7  original_T_including_depot_unload_1227  2.3332890980657526e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_7  arc_capacity_1093  1
    load_1_20_7  segment_load_conservation_1158  -1
    load_1_20_7  segment_prefix_lb_1159  1
    load_1_20_7  segment_prefix_ub_1160  1
    load_1_20_7  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_8  arc_capacity_1095  -25
    arc_1_20_8  connected_order_arc_1096  -14
    arc_1_20_8  in_degree_1162  1
    arc_1_20_8  out_degree_1211  1
    arc_1_20_8  original_T_including_depot_unload_1227  1.8418804985785646e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_8  arc_capacity_1095  1
    load_1_20_8  segment_load_conservation_1165  -1
    load_1_20_8  segment_prefix_lb_1166  1
    load_1_20_8  segment_prefix_ub_1167  1
    load_1_20_8  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_9  arc_capacity_1097  -25
    arc_1_20_9  connected_order_arc_1098  -14
    arc_1_20_9  in_degree_1169  1
    arc_1_20_9  out_degree_1211  1
    arc_1_20_9  original_T_including_depot_unload_1227  1.3857128117205509e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_9  arc_capacity_1097  1
    load_1_20_9  segment_load_conservation_1172  -1
    load_1_20_9  segment_prefix_lb_1173  1
    load_1_20_9  segment_prefix_ub_1174  1
    load_1_20_9  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_14  arc_capacity_1099  -25
    arc_1_20_14  connected_order_arc_1100  -14
    arc_1_20_14  in_degree_1176  1
    arc_1_20_14  out_degree_1211  1
    arc_1_20_14  original_T_including_depot_unload_1227  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_14  arc_capacity_1099  1
    load_1_20_14  free_load_conservation_1180  -1
    load_1_20_14  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_15  arc_capacity_1101  -25
    arc_1_20_15  connected_order_arc_1102  -14
    arc_1_20_15  in_degree_1182  1
    arc_1_20_15  out_degree_1211  1
    arc_1_20_15  original_T_including_depot_unload_1227  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_15  arc_capacity_1101  1
    load_1_20_15  free_load_conservation_1186  -1
    load_1_20_15  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_16  arc_capacity_1103  -25
    arc_1_20_16  connected_order_arc_1104  -14
    arc_1_20_16  in_degree_1188  1
    arc_1_20_16  out_degree_1211  1
    arc_1_20_16  original_T_including_depot_unload_1227  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_16  arc_capacity_1103  1
    load_1_20_16  free_load_conservation_1192  -1
    load_1_20_16  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_17  arc_capacity_1105  -25
    arc_1_20_17  connected_order_arc_1106  -14
    arc_1_20_17  in_degree_1194  1
    arc_1_20_17  out_degree_1211  1
    arc_1_20_17  original_T_including_depot_unload_1227  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_1_20_17  arc_capacity_1105  1
    load_1_20_17  free_load_conservation_1198  -1
    load_1_20_17  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_18  arc_capacity_1107  -25
    arc_1_20_18  connected_order_arc_1108  -14
    arc_1_20_18  in_degree_1200  1
    arc_1_20_18  out_degree_1211  1
    arc_1_20_18  original_T_including_depot_unload_1227  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_18  arc_capacity_1107  1
    load_1_20_18  free_load_conservation_1204  -1
    load_1_20_18  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_19  arc_capacity_1109  -25
    arc_1_20_19  connected_order_arc_1110  -14
    arc_1_20_19  in_degree_1206  1
    arc_1_20_19  out_degree_1211  1
    arc_1_20_19  original_T_including_depot_unload_1227  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_1_20_19  arc_capacity_1109  1
    load_1_20_19  free_load_conservation_1210  -1
    load_1_20_19  free_load_conservation_1216  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_20_21  arc_capacity_1111  -25
    arc_1_20_21  connected_order_arc_1112  -14
    arc_1_20_21  out_degree_1211  1
    arc_1_20_21  in_degree_1218  1
    arc_1_20_21  original_T_including_depot_unload_1227  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_20_21  arc_capacity_1111  1
    load_1_20_21  free_load_conservation_1216  1
    load_1_20_21  free_load_conservation_1222  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_0  arc_capacity_1113  -25
    arc_1_21_0  depot_return_or_bypass_1139  1
    arc_1_21_0  out_degree_1217  1
    arc_1_21_0  original_T_including_depot_unload_1227  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_0  arc_capacity_1113  1
    load_1_21_0  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_5  arc_capacity_1114  -25
    arc_1_21_5  connected_order_arc_1115  -14
    arc_1_21_5  in_degree_1141  1
    arc_1_21_5  out_degree_1217  1
    arc_1_21_5  original_T_including_depot_unload_1227  6.2102815646279714e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_5  arc_capacity_1114  1
    load_1_21_5  segment_load_conservation_1144  -1
    load_1_21_5  segment_prefix_lb_1145  1
    load_1_21_5  segment_prefix_ub_1146  1
    load_1_21_5  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_6  arc_capacity_1116  -25
    arc_1_21_6  connected_order_arc_1117  -14
    arc_1_21_6  in_degree_1148  1
    arc_1_21_6  out_degree_1217  1
    arc_1_21_6  original_T_including_depot_unload_1227  9.7692852841087415e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_6  arc_capacity_1116  1
    load_1_21_6  segment_load_conservation_1151  -1
    load_1_21_6  segment_prefix_lb_1152  1
    load_1_21_6  segment_prefix_ub_1153  1
    load_1_21_6  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_7  arc_capacity_1118  -25
    arc_1_21_7  connected_order_arc_1119  -14
    arc_1_21_7  in_degree_1155  1
    arc_1_21_7  out_degree_1217  1
    arc_1_21_7  original_T_including_depot_unload_1227  1.9785969874636677e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_7  arc_capacity_1118  1
    load_1_21_7  segment_load_conservation_1158  -1
    load_1_21_7  segment_prefix_lb_1159  1
    load_1_21_7  segment_prefix_ub_1160  1
    load_1_21_7  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_8  arc_capacity_1120  -25
    arc_1_21_8  connected_order_arc_1121  -14
    arc_1_21_8  in_degree_1162  1
    arc_1_21_8  out_degree_1217  1
    arc_1_21_8  original_T_including_depot_unload_1227  1.0910343836035740e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_8  arc_capacity_1120  1
    load_1_21_8  segment_load_conservation_1165  -1
    load_1_21_8  segment_prefix_lb_1166  1
    load_1_21_8  segment_prefix_ub_1167  1
    load_1_21_8  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_9  arc_capacity_1122  -25
    arc_1_21_9  connected_order_arc_1123  -14
    arc_1_21_9  in_degree_1169  1
    arc_1_21_9  out_degree_1217  1
    arc_1_21_9  original_T_including_depot_unload_1227  1.2100678255370710e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_9  arc_capacity_1122  1
    load_1_21_9  segment_load_conservation_1172  -1
    load_1_21_9  segment_prefix_lb_1173  1
    load_1_21_9  segment_prefix_ub_1174  1
    load_1_21_9  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_14  arc_capacity_1124  -25
    arc_1_21_14  connected_order_arc_1125  -14
    arc_1_21_14  in_degree_1176  1
    arc_1_21_14  out_degree_1217  1
    arc_1_21_14  original_T_including_depot_unload_1227  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_14  arc_capacity_1124  1
    load_1_21_14  free_load_conservation_1180  -1
    load_1_21_14  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_15  arc_capacity_1126  -25
    arc_1_21_15  connected_order_arc_1127  -14
    arc_1_21_15  in_degree_1182  1
    arc_1_21_15  out_degree_1217  1
    arc_1_21_15  original_T_including_depot_unload_1227  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_15  arc_capacity_1126  1
    load_1_21_15  free_load_conservation_1186  -1
    load_1_21_15  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_16  arc_capacity_1128  -25
    arc_1_21_16  connected_order_arc_1129  -14
    arc_1_21_16  in_degree_1188  1
    arc_1_21_16  out_degree_1217  1
    arc_1_21_16  original_T_including_depot_unload_1227  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_16  arc_capacity_1128  1
    load_1_21_16  free_load_conservation_1192  -1
    load_1_21_16  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_17  arc_capacity_1130  -25
    arc_1_21_17  connected_order_arc_1131  -14
    arc_1_21_17  in_degree_1194  1
    arc_1_21_17  out_degree_1217  1
    arc_1_21_17  original_T_including_depot_unload_1227  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_17  arc_capacity_1130  1
    load_1_21_17  free_load_conservation_1198  -1
    load_1_21_17  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_18  arc_capacity_1132  -25
    arc_1_21_18  connected_order_arc_1133  -14
    arc_1_21_18  in_degree_1200  1
    arc_1_21_18  out_degree_1217  1
    arc_1_21_18  original_T_including_depot_unload_1227  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_18  arc_capacity_1132  1
    load_1_21_18  free_load_conservation_1204  -1
    load_1_21_18  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_19  arc_capacity_1134  -25
    arc_1_21_19  connected_order_arc_1135  -14
    arc_1_21_19  in_degree_1206  1
    arc_1_21_19  out_degree_1217  1
    arc_1_21_19  original_T_including_depot_unload_1227  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_21_19  arc_capacity_1134  1
    load_1_21_19  free_load_conservation_1210  -1
    load_1_21_19  free_load_conservation_1222  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_21_20  arc_capacity_1136  -25
    arc_1_21_20  connected_order_arc_1137  -14
    arc_1_21_20  in_degree_1212  1
    arc_1_21_20  out_degree_1217  1
    arc_1_21_20  original_T_including_depot_unload_1227  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_21_20  arc_capacity_1136  1
    load_1_21_20  free_load_conservation_1216  -1
    load_1_21_20  free_load_conservation_1222  1
    visit_2_10  out_degree_1519  -1
    visit_2_10  in_degree_1520  -1
    visit_2_10  order_active_lb_1521  -1
    visit_2_10  order_active_ub_1522  -12
    order_2_10  connected_order_arc_1243  -1
    order_2_10  connected_order_arc_1245  -1
    order_2_10  connected_order_arc_1247  -1
    order_2_10  connected_order_arc_1249  -1
    order_2_10  connected_order_arc_1251  -1
    order_2_10  connected_order_arc_1253  -1
    order_2_10  connected_order_arc_1255  -1
    order_2_10  connected_order_arc_1257  -1
    order_2_10  connected_order_arc_1259  -1
    order_2_10  connected_order_arc_1261  -1
    order_2_10  connected_order_arc_1263  -1
    order_2_10  connected_order_arc_1266  1
    order_2_10  connected_order_arc_1289  1
    order_2_10  connected_order_arc_1312  1
    order_2_10  connected_order_arc_1335  1
    order_2_10  connected_order_arc_1358  1
    order_2_10  connected_order_arc_1381  1
    order_2_10  connected_order_arc_1404  1
    order_2_10  connected_order_arc_1427  1
    order_2_10  connected_order_arc_1450  1
    order_2_10  connected_order_arc_1473  1
    order_2_10  connected_order_arc_1496  1
    order_2_10  order_active_lb_1521  1
    order_2_10  order_active_ub_1522  1
    order_2_10  fixed_segment_relative_order_1595  -1
    visit_2_11  out_degree_1526  -1
    visit_2_11  in_degree_1527  -1
    visit_2_11  order_active_lb_1528  -1
    visit_2_11  order_active_ub_1529  -12
    order_2_11  connected_order_arc_1243  1
    order_2_11  connected_order_arc_1266  -1
    order_2_11  connected_order_arc_1268  -1
    order_2_11  connected_order_arc_1270  -1
    order_2_11  connected_order_arc_1272  -1
    order_2_11  connected_order_arc_1274  -1
    order_2_11  connected_order_arc_1276  -1
    order_2_11  connected_order_arc_1278  -1
    order_2_11  connected_order_arc_1280  -1
    order_2_11  connected_order_arc_1282  -1
    order_2_11  connected_order_arc_1284  -1
    order_2_11  connected_order_arc_1286  -1
    order_2_11  connected_order_arc_1291  1
    order_2_11  connected_order_arc_1314  1
    order_2_11  connected_order_arc_1337  1
    order_2_11  connected_order_arc_1360  1
    order_2_11  connected_order_arc_1383  1
    order_2_11  connected_order_arc_1406  1
    order_2_11  connected_order_arc_1429  1
    order_2_11  connected_order_arc_1452  1
    order_2_11  connected_order_arc_1475  1
    order_2_11  connected_order_arc_1498  1
    order_2_11  order_active_lb_1528  1
    order_2_11  order_active_ub_1529  1
    order_2_11  fixed_segment_relative_order_1595  1
    order_2_11  fixed_segment_relative_order_1596  -1
    visit_2_12  out_degree_1533  -1
    visit_2_12  in_degree_1534  -1
    visit_2_12  order_active_lb_1535  -1
    visit_2_12  order_active_ub_1536  -12
    order_2_12  connected_order_arc_1245  1
    order_2_12  connected_order_arc_1268  1
    order_2_12  connected_order_arc_1289  -1
    order_2_12  connected_order_arc_1291  -1
    order_2_12  connected_order_arc_1293  -1
    order_2_12  connected_order_arc_1295  -1
    order_2_12  connected_order_arc_1297  -1
    order_2_12  connected_order_arc_1299  -1
    order_2_12  connected_order_arc_1301  -1
    order_2_12  connected_order_arc_1303  -1
    order_2_12  connected_order_arc_1305  -1
    order_2_12  connected_order_arc_1307  -1
    order_2_12  connected_order_arc_1309  -1
    order_2_12  connected_order_arc_1316  1
    order_2_12  connected_order_arc_1339  1
    order_2_12  connected_order_arc_1362  1
    order_2_12  connected_order_arc_1385  1
    order_2_12  connected_order_arc_1408  1
    order_2_12  connected_order_arc_1431  1
    order_2_12  connected_order_arc_1454  1
    order_2_12  connected_order_arc_1477  1
    order_2_12  connected_order_arc_1500  1
    order_2_12  order_active_lb_1535  1
    order_2_12  order_active_ub_1536  1
    order_2_12  fixed_segment_relative_order_1596  1
    order_2_12  fixed_segment_relative_order_1597  -1
    visit_2_13  out_degree_1540  -1
    visit_2_13  in_degree_1541  -1
    visit_2_13  order_active_lb_1542  -1
    visit_2_13  order_active_ub_1543  -12
    order_2_13  connected_order_arc_1247  1
    order_2_13  connected_order_arc_1270  1
    order_2_13  connected_order_arc_1293  1
    order_2_13  connected_order_arc_1312  -1
    order_2_13  connected_order_arc_1314  -1
    order_2_13  connected_order_arc_1316  -1
    order_2_13  connected_order_arc_1318  -1
    order_2_13  connected_order_arc_1320  -1
    order_2_13  connected_order_arc_1322  -1
    order_2_13  connected_order_arc_1324  -1
    order_2_13  connected_order_arc_1326  -1
    order_2_13  connected_order_arc_1328  -1
    order_2_13  connected_order_arc_1330  -1
    order_2_13  connected_order_arc_1332  -1
    order_2_13  connected_order_arc_1341  1
    order_2_13  connected_order_arc_1364  1
    order_2_13  connected_order_arc_1387  1
    order_2_13  connected_order_arc_1410  1
    order_2_13  connected_order_arc_1433  1
    order_2_13  connected_order_arc_1456  1
    order_2_13  connected_order_arc_1479  1
    order_2_13  connected_order_arc_1502  1
    order_2_13  order_active_lb_1542  1
    order_2_13  order_active_ub_1543  1
    order_2_13  fixed_segment_relative_order_1597  1
    visit_2_14  out_degree_1547  -1
    visit_2_14  in_degree_1548  -1
    visit_2_14  order_active_lb_1549  -1
    visit_2_14  order_active_ub_1550  -12
    visit_2_14  service_visit_def_1551  -1
    order_2_14  connected_order_arc_1249  1
    order_2_14  connected_order_arc_1272  1
    order_2_14  connected_order_arc_1295  1
    order_2_14  connected_order_arc_1318  1
    order_2_14  connected_order_arc_1335  -1
    order_2_14  connected_order_arc_1337  -1
    order_2_14  connected_order_arc_1339  -1
    order_2_14  connected_order_arc_1341  -1
    order_2_14  connected_order_arc_1343  -1
    order_2_14  connected_order_arc_1345  -1
    order_2_14  connected_order_arc_1347  -1
    order_2_14  connected_order_arc_1349  -1
    order_2_14  connected_order_arc_1351  -1
    order_2_14  connected_order_arc_1353  -1
    order_2_14  connected_order_arc_1355  -1
    order_2_14  connected_order_arc_1366  1
    order_2_14  connected_order_arc_1389  1
    order_2_14  connected_order_arc_1412  1
    order_2_14  connected_order_arc_1435  1
    order_2_14  connected_order_arc_1458  1
    order_2_14  connected_order_arc_1481  1
    order_2_14  connected_order_arc_1504  1
    order_2_14  order_active_lb_1549  1
    order_2_14  order_active_ub_1550  1
    visit_2_15  out_degree_1553  -1
    visit_2_15  in_degree_1554  -1
    visit_2_15  order_active_lb_1555  -1
    visit_2_15  order_active_ub_1556  -12
    visit_2_15  service_visit_def_1557  -1
    order_2_15  connected_order_arc_1251  1
    order_2_15  connected_order_arc_1274  1
    order_2_15  connected_order_arc_1297  1
    order_2_15  connected_order_arc_1320  1
    order_2_15  connected_order_arc_1343  1
    order_2_15  connected_order_arc_1358  -1
    order_2_15  connected_order_arc_1360  -1
    order_2_15  connected_order_arc_1362  -1
    order_2_15  connected_order_arc_1364  -1
    order_2_15  connected_order_arc_1366  -1
    order_2_15  connected_order_arc_1368  -1
    order_2_15  connected_order_arc_1370  -1
    order_2_15  connected_order_arc_1372  -1
    order_2_15  connected_order_arc_1374  -1
    order_2_15  connected_order_arc_1376  -1
    order_2_15  connected_order_arc_1378  -1
    order_2_15  connected_order_arc_1391  1
    order_2_15  connected_order_arc_1414  1
    order_2_15  connected_order_arc_1437  1
    order_2_15  connected_order_arc_1460  1
    order_2_15  connected_order_arc_1483  1
    order_2_15  connected_order_arc_1506  1
    order_2_15  order_active_lb_1555  1
    order_2_15  order_active_ub_1556  1
    visit_2_16  out_degree_1559  -1
    visit_2_16  in_degree_1560  -1
    visit_2_16  order_active_lb_1561  -1
    visit_2_16  order_active_ub_1562  -12
    visit_2_16  service_visit_def_1563  -1
    order_2_16  connected_order_arc_1253  1
    order_2_16  connected_order_arc_1276  1
    order_2_16  connected_order_arc_1299  1
    order_2_16  connected_order_arc_1322  1
    order_2_16  connected_order_arc_1345  1
    order_2_16  connected_order_arc_1368  1
    order_2_16  connected_order_arc_1381  -1
    order_2_16  connected_order_arc_1383  -1
    order_2_16  connected_order_arc_1385  -1
    order_2_16  connected_order_arc_1387  -1
    order_2_16  connected_order_arc_1389  -1
    order_2_16  connected_order_arc_1391  -1
    order_2_16  connected_order_arc_1393  -1
    order_2_16  connected_order_arc_1395  -1
    order_2_16  connected_order_arc_1397  -1
    order_2_16  connected_order_arc_1399  -1
    order_2_16  connected_order_arc_1401  -1
    order_2_16  connected_order_arc_1416  1
    order_2_16  connected_order_arc_1439  1
    order_2_16  connected_order_arc_1462  1
    order_2_16  connected_order_arc_1485  1
    order_2_16  connected_order_arc_1508  1
    order_2_16  order_active_lb_1561  1
    order_2_16  order_active_ub_1562  1
    visit_2_17  out_degree_1565  -1
    visit_2_17  in_degree_1566  -1
    visit_2_17  order_active_lb_1567  -1
    visit_2_17  order_active_ub_1568  -12
    visit_2_17  service_visit_def_1569  -1
    order_2_17  connected_order_arc_1255  1
    order_2_17  connected_order_arc_1278  1
    order_2_17  connected_order_arc_1301  1
    order_2_17  connected_order_arc_1324  1
    order_2_17  connected_order_arc_1347  1
    order_2_17  connected_order_arc_1370  1
    order_2_17  connected_order_arc_1393  1
    order_2_17  connected_order_arc_1404  -1
    order_2_17  connected_order_arc_1406  -1
    order_2_17  connected_order_arc_1408  -1
    order_2_17  connected_order_arc_1410  -1
    order_2_17  connected_order_arc_1412  -1
    order_2_17  connected_order_arc_1414  -1
    order_2_17  connected_order_arc_1416  -1
    order_2_17  connected_order_arc_1418  -1
    order_2_17  connected_order_arc_1420  -1
    order_2_17  connected_order_arc_1422  -1
    order_2_17  connected_order_arc_1424  -1
    order_2_17  connected_order_arc_1441  1
    order_2_17  connected_order_arc_1464  1
    order_2_17  connected_order_arc_1487  1
    order_2_17  connected_order_arc_1510  1
    order_2_17  order_active_lb_1567  1
    order_2_17  order_active_ub_1568  1
    visit_2_18  out_degree_1571  -1
    visit_2_18  in_degree_1572  -1
    visit_2_18  order_active_lb_1573  -1
    visit_2_18  order_active_ub_1574  -12
    visit_2_18  service_visit_def_1575  -1
    order_2_18  connected_order_arc_1257  1
    order_2_18  connected_order_arc_1280  1
    order_2_18  connected_order_arc_1303  1
    order_2_18  connected_order_arc_1326  1
    order_2_18  connected_order_arc_1349  1
    order_2_18  connected_order_arc_1372  1
    order_2_18  connected_order_arc_1395  1
    order_2_18  connected_order_arc_1418  1
    order_2_18  connected_order_arc_1427  -1
    order_2_18  connected_order_arc_1429  -1
    order_2_18  connected_order_arc_1431  -1
    order_2_18  connected_order_arc_1433  -1
    order_2_18  connected_order_arc_1435  -1
    order_2_18  connected_order_arc_1437  -1
    order_2_18  connected_order_arc_1439  -1
    order_2_18  connected_order_arc_1441  -1
    order_2_18  connected_order_arc_1443  -1
    order_2_18  connected_order_arc_1445  -1
    order_2_18  connected_order_arc_1447  -1
    order_2_18  connected_order_arc_1466  1
    order_2_18  connected_order_arc_1489  1
    order_2_18  connected_order_arc_1512  1
    order_2_18  order_active_lb_1573  1
    order_2_18  order_active_ub_1574  1
    visit_2_19  out_degree_1577  -1
    visit_2_19  in_degree_1578  -1
    visit_2_19  order_active_lb_1579  -1
    visit_2_19  order_active_ub_1580  -12
    visit_2_19  service_visit_def_1581  -1
    order_2_19  connected_order_arc_1259  1
    order_2_19  connected_order_arc_1282  1
    order_2_19  connected_order_arc_1305  1
    order_2_19  connected_order_arc_1328  1
    order_2_19  connected_order_arc_1351  1
    order_2_19  connected_order_arc_1374  1
    order_2_19  connected_order_arc_1397  1
    order_2_19  connected_order_arc_1420  1
    order_2_19  connected_order_arc_1443  1
    order_2_19  connected_order_arc_1450  -1
    order_2_19  connected_order_arc_1452  -1
    order_2_19  connected_order_arc_1454  -1
    order_2_19  connected_order_arc_1456  -1
    order_2_19  connected_order_arc_1458  -1
    order_2_19  connected_order_arc_1460  -1
    order_2_19  connected_order_arc_1462  -1
    order_2_19  connected_order_arc_1464  -1
    order_2_19  connected_order_arc_1466  -1
    order_2_19  connected_order_arc_1468  -1
    order_2_19  connected_order_arc_1470  -1
    order_2_19  connected_order_arc_1491  1
    order_2_19  connected_order_arc_1514  1
    order_2_19  order_active_lb_1579  1
    order_2_19  order_active_ub_1580  1
    visit_2_20  out_degree_1583  -1
    visit_2_20  in_degree_1584  -1
    visit_2_20  order_active_lb_1585  -1
    visit_2_20  order_active_ub_1586  -12
    visit_2_20  service_visit_def_1587  -1
    order_2_20  connected_order_arc_1261  1
    order_2_20  connected_order_arc_1284  1
    order_2_20  connected_order_arc_1307  1
    order_2_20  connected_order_arc_1330  1
    order_2_20  connected_order_arc_1353  1
    order_2_20  connected_order_arc_1376  1
    order_2_20  connected_order_arc_1399  1
    order_2_20  connected_order_arc_1422  1
    order_2_20  connected_order_arc_1445  1
    order_2_20  connected_order_arc_1468  1
    order_2_20  connected_order_arc_1473  -1
    order_2_20  connected_order_arc_1475  -1
    order_2_20  connected_order_arc_1477  -1
    order_2_20  connected_order_arc_1479  -1
    order_2_20  connected_order_arc_1481  -1
    order_2_20  connected_order_arc_1483  -1
    order_2_20  connected_order_arc_1485  -1
    order_2_20  connected_order_arc_1487  -1
    order_2_20  connected_order_arc_1489  -1
    order_2_20  connected_order_arc_1491  -1
    order_2_20  connected_order_arc_1493  -1
    order_2_20  connected_order_arc_1516  1
    order_2_20  order_active_lb_1585  1
    order_2_20  order_active_ub_1586  1
    visit_2_21  out_degree_1589  -1
    visit_2_21  in_degree_1590  -1
    visit_2_21  order_active_lb_1591  -1
    visit_2_21  order_active_ub_1592  -12
    visit_2_21  service_visit_def_1593  -1
    order_2_21  connected_order_arc_1263  1
    order_2_21  connected_order_arc_1286  1
    order_2_21  connected_order_arc_1309  1
    order_2_21  connected_order_arc_1332  1
    order_2_21  connected_order_arc_1355  1
    order_2_21  connected_order_arc_1378  1
    order_2_21  connected_order_arc_1401  1
    order_2_21  connected_order_arc_1424  1
    order_2_21  connected_order_arc_1447  1
    order_2_21  connected_order_arc_1470  1
    order_2_21  connected_order_arc_1493  1
    order_2_21  connected_order_arc_1496  -1
    order_2_21  connected_order_arc_1498  -1
    order_2_21  connected_order_arc_1500  -1
    order_2_21  connected_order_arc_1502  -1
    order_2_21  connected_order_arc_1504  -1
    order_2_21  connected_order_arc_1506  -1
    order_2_21  connected_order_arc_1508  -1
    order_2_21  connected_order_arc_1510  -1
    order_2_21  connected_order_arc_1512  -1
    order_2_21  connected_order_arc_1514  -1
    order_2_21  connected_order_arc_1516  -1
    order_2_21  order_active_lb_1591  1
    order_2_21  order_active_ub_1592  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_0  arc_capacity_1228  -30
    arc_2_0_0  depot_departure_or_bypass_1517  1
    arc_2_0_0  depot_return_or_bypass_1518  1
    MARKER    'MARKER'                 'INTEND'
    load_2_0_0  arc_capacity_1228  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_10  arc_capacity_1229  -30
    arc_2_0_10  depot_departure_or_bypass_1517  1
    arc_2_0_10  in_degree_1520  1
    arc_2_0_10  original_T_including_depot_unload_1598  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_10  arc_capacity_1229  1
    load_2_0_10  segment_load_conservation_1523  -1
    load_2_0_10  segment_prefix_lb_1524  1
    load_2_0_10  segment_prefix_ub_1525  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_11  arc_capacity_1230  -30
    arc_2_0_11  depot_departure_or_bypass_1517  1
    arc_2_0_11  in_degree_1527  1
    arc_2_0_11  original_T_including_depot_unload_1598  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_11  arc_capacity_1230  1
    load_2_0_11  segment_load_conservation_1530  -1
    load_2_0_11  segment_prefix_lb_1531  1
    load_2_0_11  segment_prefix_ub_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_12  arc_capacity_1231  -30
    arc_2_0_12  depot_departure_or_bypass_1517  1
    arc_2_0_12  in_degree_1534  1
    arc_2_0_12  original_T_including_depot_unload_1598  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_12  arc_capacity_1231  1
    load_2_0_12  segment_load_conservation_1537  -1
    load_2_0_12  segment_prefix_lb_1538  1
    load_2_0_12  segment_prefix_ub_1539  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_13  arc_capacity_1232  -30
    arc_2_0_13  depot_departure_or_bypass_1517  1
    arc_2_0_13  in_degree_1541  1
    arc_2_0_13  original_T_including_depot_unload_1598  1.4501558573355060e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_13  arc_capacity_1232  1
    load_2_0_13  segment_load_conservation_1544  -1
    load_2_0_13  segment_prefix_lb_1545  1
    load_2_0_13  segment_prefix_ub_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_14  arc_capacity_1233  -30
    arc_2_0_14  depot_departure_or_bypass_1517  1
    arc_2_0_14  in_degree_1548  1
    arc_2_0_14  original_T_including_depot_unload_1598  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_14  arc_capacity_1233  1
    load_2_0_14  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_15  arc_capacity_1234  -30
    arc_2_0_15  depot_departure_or_bypass_1517  1
    arc_2_0_15  in_degree_1554  1
    arc_2_0_15  original_T_including_depot_unload_1598  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_15  arc_capacity_1234  1
    load_2_0_15  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_16  arc_capacity_1235  -30
    arc_2_0_16  depot_departure_or_bypass_1517  1
    arc_2_0_16  in_degree_1560  1
    arc_2_0_16  original_T_including_depot_unload_1598  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_16  arc_capacity_1235  1
    load_2_0_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_17  arc_capacity_1236  -30
    arc_2_0_17  depot_departure_or_bypass_1517  1
    arc_2_0_17  in_degree_1566  1
    arc_2_0_17  original_T_including_depot_unload_1598  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_0_17  arc_capacity_1236  1
    load_2_0_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_18  arc_capacity_1237  -30
    arc_2_0_18  depot_departure_or_bypass_1517  1
    arc_2_0_18  in_degree_1572  1
    arc_2_0_18  original_T_including_depot_unload_1598  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_18  arc_capacity_1237  1
    load_2_0_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_19  arc_capacity_1238  -30
    arc_2_0_19  depot_departure_or_bypass_1517  1
    arc_2_0_19  in_degree_1578  1
    arc_2_0_19  original_T_including_depot_unload_1598  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_0_19  arc_capacity_1238  1
    load_2_0_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_20  arc_capacity_1239  -30
    arc_2_0_20  depot_departure_or_bypass_1517  1
    arc_2_0_20  in_degree_1584  1
    arc_2_0_20  original_T_including_depot_unload_1598  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_20  arc_capacity_1239  1
    load_2_0_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_0_21  arc_capacity_1240  -30
    arc_2_0_21  depot_departure_or_bypass_1517  1
    arc_2_0_21  in_degree_1590  1
    arc_2_0_21  original_T_including_depot_unload_1598  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_0_21  arc_capacity_1240  1
    load_2_0_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_0  arc_capacity_1241  -30
    arc_2_10_0  depot_return_or_bypass_1518  1
    arc_2_10_0  out_degree_1519  1
    arc_2_10_0  original_T_including_depot_unload_1598  2.6776790063218442e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_0  arc_capacity_1241  1
    load_2_10_0  segment_load_conservation_1523  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_11  arc_capacity_1242  -30
    arc_2_10_11  connected_order_arc_1243  -13
    arc_2_10_11  out_degree_1519  1
    arc_2_10_11  in_degree_1527  1
    arc_2_10_11  original_T_including_depot_unload_1598  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_11  arc_capacity_1242  1
    load_2_10_11  segment_load_conservation_1523  1
    load_2_10_11  segment_load_conservation_1530  -1
    load_2_10_11  segment_prefix_lb_1531  1
    load_2_10_11  segment_prefix_ub_1532  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_12  arc_capacity_1244  -30
    arc_2_10_12  connected_order_arc_1245  -13
    arc_2_10_12  out_degree_1519  1
    arc_2_10_12  in_degree_1534  1
    arc_2_10_12  original_T_including_depot_unload_1598  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_12  arc_capacity_1244  1
    load_2_10_12  segment_load_conservation_1523  1
    load_2_10_12  segment_load_conservation_1537  -1
    load_2_10_12  segment_prefix_lb_1538  1
    load_2_10_12  segment_prefix_ub_1539  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_13  arc_capacity_1246  -30
    arc_2_10_13  connected_order_arc_1247  -13
    arc_2_10_13  out_degree_1519  1
    arc_2_10_13  in_degree_1541  1
    arc_2_10_13  original_T_including_depot_unload_1598  1.2946770575314561e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_13  arc_capacity_1246  1
    load_2_10_13  segment_load_conservation_1523  1
    load_2_10_13  segment_load_conservation_1544  -1
    load_2_10_13  segment_prefix_lb_1545  1
    load_2_10_13  segment_prefix_ub_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_14  arc_capacity_1248  -30
    arc_2_10_14  connected_order_arc_1249  -13
    arc_2_10_14  out_degree_1519  1
    arc_2_10_14  in_degree_1548  1
    arc_2_10_14  original_T_including_depot_unload_1598  1.5443427836332014e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_14  arc_capacity_1248  1
    load_2_10_14  segment_load_conservation_1523  1
    load_2_10_14  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_15  arc_capacity_1250  -30
    arc_2_10_15  connected_order_arc_1251  -13
    arc_2_10_15  out_degree_1519  1
    arc_2_10_15  in_degree_1554  1
    arc_2_10_15  original_T_including_depot_unload_1598  1.2512000734124169e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_15  arc_capacity_1250  1
    load_2_10_15  segment_load_conservation_1523  1
    load_2_10_15  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_16  arc_capacity_1252  -30
    arc_2_10_16  connected_order_arc_1253  -13
    arc_2_10_16  out_degree_1519  1
    arc_2_10_16  in_degree_1560  1
    arc_2_10_16  original_T_including_depot_unload_1598  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_16  arc_capacity_1252  1
    load_2_10_16  segment_load_conservation_1523  1
    load_2_10_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_17  arc_capacity_1254  -30
    arc_2_10_17  connected_order_arc_1255  -13
    arc_2_10_17  out_degree_1519  1
    arc_2_10_17  in_degree_1566  1
    arc_2_10_17  original_T_including_depot_unload_1598  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_17  arc_capacity_1254  1
    load_2_10_17  segment_load_conservation_1523  1
    load_2_10_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_18  arc_capacity_1256  -30
    arc_2_10_18  connected_order_arc_1257  -13
    arc_2_10_18  out_degree_1519  1
    arc_2_10_18  in_degree_1572  1
    arc_2_10_18  original_T_including_depot_unload_1598  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_10_18  arc_capacity_1256  1
    load_2_10_18  segment_load_conservation_1523  1
    load_2_10_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_19  arc_capacity_1258  -30
    arc_2_10_19  connected_order_arc_1259  -13
    arc_2_10_19  out_degree_1519  1
    arc_2_10_19  in_degree_1578  1
    arc_2_10_19  original_T_including_depot_unload_1598  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_19  arc_capacity_1258  1
    load_2_10_19  segment_load_conservation_1523  1
    load_2_10_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_20  arc_capacity_1260  -30
    arc_2_10_20  connected_order_arc_1261  -13
    arc_2_10_20  out_degree_1519  1
    arc_2_10_20  in_degree_1584  1
    arc_2_10_20  original_T_including_depot_unload_1598  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_20  arc_capacity_1260  1
    load_2_10_20  segment_load_conservation_1523  1
    load_2_10_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_10_21  arc_capacity_1262  -30
    arc_2_10_21  connected_order_arc_1263  -13
    arc_2_10_21  out_degree_1519  1
    arc_2_10_21  in_degree_1590  1
    arc_2_10_21  original_T_including_depot_unload_1598  1.5688206371681019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_10_21  arc_capacity_1262  1
    load_2_10_21  segment_load_conservation_1523  1
    load_2_10_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_0  arc_capacity_1264  -30
    arc_2_11_0  depot_return_or_bypass_1518  1
    arc_2_11_0  out_degree_1526  1
    arc_2_11_0  original_T_including_depot_unload_1598  1.4567038050199781e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_0  arc_capacity_1264  1
    load_2_11_0  segment_load_conservation_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_10  arc_capacity_1265  -30
    arc_2_11_10  connected_order_arc_1266  -13
    arc_2_11_10  in_degree_1520  1
    arc_2_11_10  out_degree_1526  1
    arc_2_11_10  original_T_including_depot_unload_1598  1.2835993572680911e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_10  arc_capacity_1265  1
    load_2_11_10  segment_load_conservation_1523  -1
    load_2_11_10  segment_prefix_lb_1524  1
    load_2_11_10  segment_prefix_ub_1525  1
    load_2_11_10  segment_load_conservation_1530  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_12  arc_capacity_1267  -30
    arc_2_11_12  connected_order_arc_1268  -13
    arc_2_11_12  out_degree_1526  1
    arc_2_11_12  in_degree_1534  1
    arc_2_11_12  original_T_including_depot_unload_1598  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_12  arc_capacity_1267  1
    load_2_11_12  segment_load_conservation_1530  1
    load_2_11_12  segment_load_conservation_1537  -1
    load_2_11_12  segment_prefix_lb_1538  1
    load_2_11_12  segment_prefix_ub_1539  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_13  arc_capacity_1269  -30
    arc_2_11_13  connected_order_arc_1270  -13
    arc_2_11_13  out_degree_1526  1
    arc_2_11_13  in_degree_1541  1
    arc_2_11_13  original_T_including_depot_unload_1598  2.1542021003680966e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_13  arc_capacity_1269  1
    load_2_11_13  segment_load_conservation_1530  1
    load_2_11_13  segment_load_conservation_1544  -1
    load_2_11_13  segment_prefix_lb_1545  1
    load_2_11_13  segment_prefix_ub_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_14  arc_capacity_1271  -30
    arc_2_11_14  connected_order_arc_1272  -13
    arc_2_11_14  out_degree_1526  1
    arc_2_11_14  in_degree_1548  1
    arc_2_11_14  original_T_including_depot_unload_1598  2.6090786084981669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_14  arc_capacity_1271  1
    load_2_11_14  segment_load_conservation_1530  1
    load_2_11_14  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_15  arc_capacity_1273  -30
    arc_2_11_15  connected_order_arc_1274  -13
    arc_2_11_15  out_degree_1526  1
    arc_2_11_15  in_degree_1554  1
    arc_2_11_15  original_T_including_depot_unload_1598  2.3467684203287868e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_15  arc_capacity_1273  1
    load_2_11_15  segment_load_conservation_1530  1
    load_2_11_15  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_16  arc_capacity_1275  -30
    arc_2_11_16  connected_order_arc_1276  -13
    arc_2_11_16  out_degree_1526  1
    arc_2_11_16  in_degree_1560  1
    arc_2_11_16  original_T_including_depot_unload_1598  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_16  arc_capacity_1275  1
    load_2_11_16  segment_load_conservation_1530  1
    load_2_11_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_17  arc_capacity_1277  -30
    arc_2_11_17  connected_order_arc_1278  -13
    arc_2_11_17  out_degree_1526  1
    arc_2_11_17  in_degree_1566  1
    arc_2_11_17  original_T_including_depot_unload_1598  2.2630748095713293e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_17  arc_capacity_1277  1
    load_2_11_17  segment_load_conservation_1530  1
    load_2_11_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_18  arc_capacity_1279  -30
    arc_2_11_18  connected_order_arc_1280  -13
    arc_2_11_18  out_degree_1526  1
    arc_2_11_18  in_degree_1572  1
    arc_2_11_18  original_T_including_depot_unload_1598  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_18  arc_capacity_1279  1
    load_2_11_18  segment_load_conservation_1530  1
    load_2_11_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_19  arc_capacity_1281  -30
    arc_2_11_19  connected_order_arc_1282  -13
    arc_2_11_19  out_degree_1526  1
    arc_2_11_19  in_degree_1578  1
    arc_2_11_19  original_T_including_depot_unload_1598  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_19  arc_capacity_1281  1
    load_2_11_19  segment_load_conservation_1530  1
    load_2_11_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_20  arc_capacity_1283  -30
    arc_2_11_20  connected_order_arc_1284  -13
    arc_2_11_20  out_degree_1526  1
    arc_2_11_20  in_degree_1584  1
    arc_2_11_20  original_T_including_depot_unload_1598  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_11_20  arc_capacity_1283  1
    load_2_11_20  segment_load_conservation_1530  1
    load_2_11_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_11_21  arc_capacity_1285  -30
    arc_2_11_21  connected_order_arc_1286  -13
    arc_2_11_21  out_degree_1526  1
    arc_2_11_21  in_degree_1590  1
    arc_2_11_21  original_T_including_depot_unload_1598  2.4002470706280069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_11_21  arc_capacity_1285  1
    load_2_11_21  segment_load_conservation_1530  1
    load_2_11_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_0  arc_capacity_1287  -30
    arc_2_12_0  depot_return_or_bypass_1518  1
    arc_2_12_0  out_degree_1533  1
    arc_2_12_0  original_T_including_depot_unload_1598  1.2506062209426416e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_0  arc_capacity_1287  1
    load_2_12_0  segment_load_conservation_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_10  arc_capacity_1288  -30
    arc_2_12_10  connected_order_arc_1289  -13
    arc_2_12_10  in_degree_1520  1
    arc_2_12_10  out_degree_1533  1
    arc_2_12_10  original_T_including_depot_unload_1598  1.0138993437494995e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_10  arc_capacity_1288  1
    load_2_12_10  segment_load_conservation_1523  -1
    load_2_12_10  segment_prefix_lb_1524  1
    load_2_12_10  segment_prefix_ub_1525  1
    load_2_12_10  segment_load_conservation_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_11  arc_capacity_1290  -30
    arc_2_12_11  connected_order_arc_1291  -13
    arc_2_12_11  in_degree_1527  1
    arc_2_12_11  out_degree_1533  1
    arc_2_12_11  original_T_including_depot_unload_1598  5.2746035265689818e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_11  arc_capacity_1290  1
    load_2_12_11  segment_load_conservation_1530  -1
    load_2_12_11  segment_prefix_lb_1531  1
    load_2_12_11  segment_prefix_ub_1532  1
    load_2_12_11  segment_load_conservation_1537  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_13  arc_capacity_1292  -30
    arc_2_12_13  connected_order_arc_1293  -13
    arc_2_12_13  out_degree_1533  1
    arc_2_12_13  in_degree_1541  1
    arc_2_12_13  original_T_including_depot_unload_1598  1.6502895430075375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_13  arc_capacity_1292  1
    load_2_12_13  segment_load_conservation_1537  1
    load_2_12_13  segment_load_conservation_1544  -1
    load_2_12_13  segment_prefix_lb_1545  1
    load_2_12_13  segment_prefix_ub_1546  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_14  arc_capacity_1294  -30
    arc_2_12_14  connected_order_arc_1295  -13
    arc_2_12_14  out_degree_1533  1
    arc_2_12_14  in_degree_1548  1
    arc_2_12_14  original_T_including_depot_unload_1598  2.5105259553106557e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_14  arc_capacity_1294  1
    load_2_12_14  segment_load_conservation_1537  1
    load_2_12_14  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_15  arc_capacity_1296  -30
    arc_2_12_15  connected_order_arc_1297  -13
    arc_2_12_15  out_degree_1533  1
    arc_2_12_15  in_degree_1554  1
    arc_2_12_15  original_T_including_depot_unload_1598  2.2257865950684204e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_15  arc_capacity_1296  1
    load_2_12_15  segment_load_conservation_1537  1
    load_2_12_15  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_16  arc_capacity_1298  -30
    arc_2_12_16  connected_order_arc_1299  -13
    arc_2_12_16  out_degree_1533  1
    arc_2_12_16  in_degree_1560  1
    arc_2_12_16  original_T_including_depot_unload_1598  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_16  arc_capacity_1298  1
    load_2_12_16  segment_load_conservation_1537  1
    load_2_12_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_17  arc_capacity_1300  -30
    arc_2_12_17  connected_order_arc_1301  -13
    arc_2_12_17  out_degree_1533  1
    arc_2_12_17  in_degree_1566  1
    arc_2_12_17  original_T_including_depot_unload_1598  2.1293186465553604e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_17  arc_capacity_1300  1
    load_2_12_17  segment_load_conservation_1537  1
    load_2_12_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_18  arc_capacity_1302  -30
    arc_2_12_18  connected_order_arc_1303  -13
    arc_2_12_18  out_degree_1533  1
    arc_2_12_18  in_degree_1572  1
    arc_2_12_18  original_T_including_depot_unload_1598  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_18  arc_capacity_1302  1
    load_2_12_18  segment_load_conservation_1537  1
    load_2_12_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_19  arc_capacity_1304  -30
    arc_2_12_19  connected_order_arc_1305  -13
    arc_2_12_19  out_degree_1533  1
    arc_2_12_19  in_degree_1578  1
    arc_2_12_19  original_T_including_depot_unload_1598  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_12_19  arc_capacity_1304  1
    load_2_12_19  segment_load_conservation_1537  1
    load_2_12_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_20  arc_capacity_1306  -30
    arc_2_12_20  connected_order_arc_1307  -13
    arc_2_12_20  out_degree_1533  1
    arc_2_12_20  in_degree_1584  1
    arc_2_12_20  original_T_including_depot_unload_1598  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_12_20  arc_capacity_1306  1
    load_2_12_20  segment_load_conservation_1537  1
    load_2_12_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_12_21  arc_capacity_1308  -30
    arc_2_12_21  connected_order_arc_1309  -13
    arc_2_12_21  out_degree_1533  1
    arc_2_12_21  in_degree_1590  1
    arc_2_12_21  original_T_including_depot_unload_1598  2412.70187975598
    MARKER    'MARKER'                 'INTEND'
    load_2_12_21  arc_capacity_1308  1
    load_2_12_21  segment_load_conservation_1537  1
    load_2_12_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_0  arc_capacity_1310  -30
    arc_2_13_0  depot_return_or_bypass_1518  1
    arc_2_13_0  out_degree_1540  1
    arc_2_13_0  original_T_including_depot_unload_1598  4.1643752251161544e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_0  arc_capacity_1310  1
    load_2_13_0  segment_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_10  arc_capacity_1311  -30
    arc_2_13_10  connected_order_arc_1312  -13
    arc_2_13_10  in_degree_1520  1
    arc_2_13_10  out_degree_1540  1
    arc_2_13_10  original_T_including_depot_unload_1598  2.4083746437975364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_10  arc_capacity_1311  1
    load_2_13_10  segment_load_conservation_1523  -1
    load_2_13_10  segment_prefix_lb_1524  1
    load_2_13_10  segment_prefix_ub_1525  1
    load_2_13_10  segment_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_11  arc_capacity_1313  -30
    arc_2_13_11  connected_order_arc_1314  -13
    arc_2_13_11  in_degree_1527  1
    arc_2_13_11  out_degree_1540  1
    arc_2_13_11  original_T_including_depot_unload_1598  1.4332871320059419e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_11  arc_capacity_1313  1
    load_2_13_11  segment_load_conservation_1530  -1
    load_2_13_11  segment_prefix_lb_1531  1
    load_2_13_11  segment_prefix_ub_1532  1
    load_2_13_11  segment_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_12  arc_capacity_1315  -30
    arc_2_13_12  connected_order_arc_1316  -13
    arc_2_13_12  in_degree_1534  1
    arc_2_13_12  out_degree_1540  1
    arc_2_13_12  original_T_including_depot_unload_1598  1.0874822831610163e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_12  arc_capacity_1315  1
    load_2_13_12  segment_load_conservation_1537  -1
    load_2_13_12  segment_prefix_lb_1538  1
    load_2_13_12  segment_prefix_ub_1539  1
    load_2_13_12  segment_load_conservation_1544  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_14  arc_capacity_1317  -30
    arc_2_13_14  connected_order_arc_1318  -13
    arc_2_13_14  out_degree_1540  1
    arc_2_13_14  in_degree_1548  1
    arc_2_13_14  original_T_including_depot_unload_1598  1.6087820579339759e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_14  arc_capacity_1317  1
    load_2_13_14  segment_load_conservation_1544  1
    load_2_13_14  free_load_conservation_1552  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_15  arc_capacity_1319  -30
    arc_2_13_15  connected_order_arc_1320  -13
    arc_2_13_15  out_degree_1540  1
    arc_2_13_15  in_degree_1554  1
    arc_2_13_15  original_T_including_depot_unload_1598  1.3149453181014030e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_15  arc_capacity_1319  1
    load_2_13_15  segment_load_conservation_1544  1
    load_2_13_15  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_16  arc_capacity_1321  -30
    arc_2_13_16  connected_order_arc_1322  -13
    arc_2_13_16  out_degree_1540  1
    arc_2_13_16  in_degree_1560  1
    arc_2_13_16  original_T_including_depot_unload_1598  1.4014121889708122e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_16  arc_capacity_1321  1
    load_2_13_16  segment_load_conservation_1544  1
    load_2_13_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_17  arc_capacity_1323  -30
    arc_2_13_17  connected_order_arc_1324  -13
    arc_2_13_17  out_degree_1540  1
    arc_2_13_17  in_degree_1566  1
    arc_2_13_17  original_T_including_depot_unload_1598  1.2087821033682005e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_17  arc_capacity_1323  1
    load_2_13_17  segment_load_conservation_1544  1
    load_2_13_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_18  arc_capacity_1325  -30
    arc_2_13_18  connected_order_arc_1326  -13
    arc_2_13_18  out_degree_1540  1
    arc_2_13_18  in_degree_1572  1
    arc_2_13_18  original_T_including_depot_unload_1598  8.7684829846426385e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_13_18  arc_capacity_1325  1
    load_2_13_18  segment_load_conservation_1544  1
    load_2_13_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_19  arc_capacity_1327  -30
    arc_2_13_19  connected_order_arc_1328  -13
    arc_2_13_19  out_degree_1540  1
    arc_2_13_19  in_degree_1578  1
    arc_2_13_19  original_T_including_depot_unload_1598  1.1162091303696777e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_19  arc_capacity_1327  1
    load_2_13_19  segment_load_conservation_1544  1
    load_2_13_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_20  arc_capacity_1329  -30
    arc_2_13_20  connected_order_arc_1330  -13
    arc_2_13_20  out_degree_1540  1
    arc_2_13_20  in_degree_1584  1
    arc_2_13_20  original_T_including_depot_unload_1598  1.2608612406747543e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_13_20  arc_capacity_1329  1
    load_2_13_20  segment_load_conservation_1544  1
    load_2_13_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_13_21  arc_capacity_1331  -30
    arc_2_13_21  connected_order_arc_1332  -13
    arc_2_13_21  out_degree_1540  1
    arc_2_13_21  in_degree_1590  1
    arc_2_13_21  original_T_including_depot_unload_1598  1706.88312024691
    MARKER    'MARKER'                 'INTEND'
    load_2_13_21  arc_capacity_1331  1
    load_2_13_21  segment_load_conservation_1544  1
    load_2_13_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_0  arc_capacity_1333  -30
    arc_2_14_0  depot_return_or_bypass_1518  1
    arc_2_14_0  out_degree_1547  1
    arc_2_14_0  original_T_including_depot_unload_1598  1.2801771486108735e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_0  arc_capacity_1333  1
    load_2_14_0  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_10  arc_capacity_1334  -30
    arc_2_14_10  connected_order_arc_1335  -13
    arc_2_14_10  in_degree_1520  1
    arc_2_14_10  out_degree_1547  1
    arc_2_14_10  original_T_including_depot_unload_1598  1.5443427836332014e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_10  arc_capacity_1334  1
    load_2_14_10  segment_load_conservation_1523  -1
    load_2_14_10  segment_prefix_lb_1524  1
    load_2_14_10  segment_prefix_ub_1525  1
    load_2_14_10  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_11  arc_capacity_1336  -30
    arc_2_14_11  connected_order_arc_1337  -13
    arc_2_14_11  in_degree_1527  1
    arc_2_14_11  out_degree_1547  1
    arc_2_14_11  original_T_including_depot_unload_1598  2.6090786084981669e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_11  arc_capacity_1336  1
    load_2_14_11  segment_load_conservation_1530  -1
    load_2_14_11  segment_prefix_lb_1531  1
    load_2_14_11  segment_prefix_ub_1532  1
    load_2_14_11  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_12  arc_capacity_1338  -30
    arc_2_14_12  connected_order_arc_1339  -13
    arc_2_14_12  in_degree_1534  1
    arc_2_14_12  out_degree_1547  1
    arc_2_14_12  original_T_including_depot_unload_1598  2.5105259553106557e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_12  arc_capacity_1338  1
    load_2_14_12  segment_load_conservation_1537  -1
    load_2_14_12  segment_prefix_lb_1538  1
    load_2_14_12  segment_prefix_ub_1539  1
    load_2_14_12  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_13  arc_capacity_1340  -30
    arc_2_14_13  connected_order_arc_1341  -13
    arc_2_14_13  in_degree_1541  1
    arc_2_14_13  out_degree_1547  1
    arc_2_14_13  original_T_including_depot_unload_1598  2.3611511320868203e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_13  arc_capacity_1340  1
    load_2_14_13  segment_load_conservation_1544  -1
    load_2_14_13  segment_prefix_lb_1545  1
    load_2_14_13  segment_prefix_ub_1546  1
    load_2_14_13  free_load_conservation_1552  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_15  arc_capacity_1342  -30
    arc_2_14_15  connected_order_arc_1343  -13
    arc_2_14_15  out_degree_1547  1
    arc_2_14_15  in_degree_1554  1
    arc_2_14_15  original_T_including_depot_unload_1598  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_15  arc_capacity_1342  1
    load_2_14_15  free_load_conservation_1552  1
    load_2_14_15  free_load_conservation_1558  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_16  arc_capacity_1344  -30
    arc_2_14_16  connected_order_arc_1345  -13
    arc_2_14_16  out_degree_1547  1
    arc_2_14_16  in_degree_1560  1
    arc_2_14_16  original_T_including_depot_unload_1598  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_16  arc_capacity_1344  1
    load_2_14_16  free_load_conservation_1552  1
    load_2_14_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_17  arc_capacity_1346  -30
    arc_2_14_17  connected_order_arc_1347  -13
    arc_2_14_17  out_degree_1547  1
    arc_2_14_17  in_degree_1566  1
    arc_2_14_17  original_T_including_depot_unload_1598  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_17  arc_capacity_1346  1
    load_2_14_17  free_load_conservation_1552  1
    load_2_14_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_18  arc_capacity_1348  -30
    arc_2_14_18  connected_order_arc_1349  -13
    arc_2_14_18  out_degree_1547  1
    arc_2_14_18  in_degree_1572  1
    arc_2_14_18  original_T_including_depot_unload_1598  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_18  arc_capacity_1348  1
    load_2_14_18  free_load_conservation_1552  1
    load_2_14_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_19  arc_capacity_1350  -30
    arc_2_14_19  connected_order_arc_1351  -13
    arc_2_14_19  out_degree_1547  1
    arc_2_14_19  in_degree_1578  1
    arc_2_14_19  original_T_including_depot_unload_1598  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_19  arc_capacity_1350  1
    load_2_14_19  free_load_conservation_1552  1
    load_2_14_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_20  arc_capacity_1352  -30
    arc_2_14_20  connected_order_arc_1353  -13
    arc_2_14_20  out_degree_1547  1
    arc_2_14_20  in_degree_1584  1
    arc_2_14_20  original_T_including_depot_unload_1598  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_14_20  arc_capacity_1352  1
    load_2_14_20  free_load_conservation_1552  1
    load_2_14_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_14_21  arc_capacity_1354  -30
    arc_2_14_21  connected_order_arc_1355  -13
    arc_2_14_21  out_degree_1547  1
    arc_2_14_21  in_degree_1590  1
    arc_2_14_21  original_T_including_depot_unload_1598  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_14_21  arc_capacity_1354  1
    load_2_14_21  free_load_conservation_1552  1
    load_2_14_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_0  arc_capacity_1356  -30
    arc_2_15_0  depot_return_or_bypass_1518  1
    arc_2_15_0  out_degree_1553  1
    arc_2_15_0  original_T_including_depot_unload_1598  9.8831482002326163e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_0  arc_capacity_1356  1
    load_2_15_0  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_10  arc_capacity_1357  -30
    arc_2_15_10  connected_order_arc_1358  -13
    arc_2_15_10  in_degree_1520  1
    arc_2_15_10  out_degree_1553  1
    arc_2_15_10  original_T_including_depot_unload_1598  1.2512000734124169e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_10  arc_capacity_1357  1
    load_2_15_10  segment_load_conservation_1523  -1
    load_2_15_10  segment_prefix_lb_1524  1
    load_2_15_10  segment_prefix_ub_1525  1
    load_2_15_10  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_11  arc_capacity_1359  -30
    arc_2_15_11  connected_order_arc_1360  -13
    arc_2_15_11  in_degree_1527  1
    arc_2_15_11  out_degree_1553  1
    arc_2_15_11  original_T_including_depot_unload_1598  2.3467684203287868e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_11  arc_capacity_1359  1
    load_2_15_11  segment_load_conservation_1530  -1
    load_2_15_11  segment_prefix_lb_1531  1
    load_2_15_11  segment_prefix_ub_1532  1
    load_2_15_11  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_12  arc_capacity_1361  -30
    arc_2_15_12  connected_order_arc_1362  -13
    arc_2_15_12  in_degree_1534  1
    arc_2_15_12  out_degree_1553  1
    arc_2_15_12  original_T_including_depot_unload_1598  2.2257865950684204e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_12  arc_capacity_1361  1
    load_2_15_12  segment_load_conservation_1537  -1
    load_2_15_12  segment_prefix_lb_1538  1
    load_2_15_12  segment_prefix_ub_1539  1
    load_2_15_12  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_13  arc_capacity_1363  -30
    arc_2_15_13  connected_order_arc_1364  -13
    arc_2_15_13  in_degree_1541  1
    arc_2_15_13  out_degree_1553  1
    arc_2_15_13  original_T_including_depot_unload_1598  2.0992707574322449e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_13  arc_capacity_1363  1
    load_2_15_13  segment_load_conservation_1544  -1
    load_2_15_13  segment_prefix_lb_1545  1
    load_2_15_13  segment_prefix_ub_1546  1
    load_2_15_13  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_14  arc_capacity_1365  -30
    arc_2_15_14  connected_order_arc_1366  -13
    arc_2_15_14  in_degree_1548  1
    arc_2_15_14  out_degree_1553  1
    arc_2_15_14  original_T_including_depot_unload_1598  2.9450332489480053e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_14  arc_capacity_1365  1
    load_2_15_14  free_load_conservation_1552  -1
    load_2_15_14  free_load_conservation_1558  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_16  arc_capacity_1367  -30
    arc_2_15_16  connected_order_arc_1368  -13
    arc_2_15_16  out_degree_1553  1
    arc_2_15_16  in_degree_1560  1
    arc_2_15_16  original_T_including_depot_unload_1598  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_16  arc_capacity_1367  1
    load_2_15_16  free_load_conservation_1558  1
    load_2_15_16  free_load_conservation_1564  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_17  arc_capacity_1369  -30
    arc_2_15_17  connected_order_arc_1370  -13
    arc_2_15_17  out_degree_1553  1
    arc_2_15_17  in_degree_1566  1
    arc_2_15_17  original_T_including_depot_unload_1598  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_17  arc_capacity_1369  1
    load_2_15_17  free_load_conservation_1558  1
    load_2_15_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_18  arc_capacity_1371  -30
    arc_2_15_18  connected_order_arc_1372  -13
    arc_2_15_18  out_degree_1553  1
    arc_2_15_18  in_degree_1572  1
    arc_2_15_18  original_T_including_depot_unload_1598  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_18  arc_capacity_1371  1
    load_2_15_18  free_load_conservation_1558  1
    load_2_15_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_19  arc_capacity_1373  -30
    arc_2_15_19  connected_order_arc_1374  -13
    arc_2_15_19  out_degree_1553  1
    arc_2_15_19  in_degree_1578  1
    arc_2_15_19  original_T_including_depot_unload_1598  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_19  arc_capacity_1373  1
    load_2_15_19  free_load_conservation_1558  1
    load_2_15_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_20  arc_capacity_1375  -30
    arc_2_15_20  connected_order_arc_1376  -13
    arc_2_15_20  out_degree_1553  1
    arc_2_15_20  in_degree_1584  1
    arc_2_15_20  original_T_including_depot_unload_1598  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_15_20  arc_capacity_1375  1
    load_2_15_20  free_load_conservation_1558  1
    load_2_15_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_15_21  arc_capacity_1377  -30
    arc_2_15_21  connected_order_arc_1378  -13
    arc_2_15_21  out_degree_1553  1
    arc_2_15_21  in_degree_1590  1
    arc_2_15_21  original_T_including_depot_unload_1598  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_15_21  arc_capacity_1377  1
    load_2_15_21  free_load_conservation_1558  1
    load_2_15_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_0  arc_capacity_1379  -30
    arc_2_16_0  depot_return_or_bypass_1518  1
    arc_2_16_0  out_degree_1559  1
    arc_2_16_0  original_T_including_depot_unload_1598  1.0853591755024938e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_0  arc_capacity_1379  1
    load_2_16_0  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_10  arc_capacity_1380  -30
    arc_2_16_10  connected_order_arc_1381  -13
    arc_2_16_10  in_degree_1520  1
    arc_2_16_10  out_degree_1559  1
    arc_2_16_10  original_T_including_depot_unload_1598  1.1608522866708593e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_10  arc_capacity_1380  1
    load_2_16_10  segment_load_conservation_1523  -1
    load_2_16_10  segment_prefix_lb_1524  1
    load_2_16_10  segment_prefix_ub_1525  1
    load_2_16_10  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_11  arc_capacity_1382  -30
    arc_2_16_11  connected_order_arc_1383  -13
    arc_2_16_11  in_degree_1527  1
    arc_2_16_11  out_degree_1559  1
    arc_2_16_11  original_T_including_depot_unload_1598  1.2027697073878232e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_11  arc_capacity_1382  1
    load_2_16_11  segment_load_conservation_1530  -1
    load_2_16_11  segment_prefix_lb_1531  1
    load_2_16_11  segment_prefix_ub_1532  1
    load_2_16_11  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_12  arc_capacity_1384  -30
    arc_2_16_12  connected_order_arc_1385  -13
    arc_2_16_12  in_degree_1534  1
    arc_2_16_12  out_degree_1559  1
    arc_2_16_12  original_T_including_depot_unload_1598  1.4255422670497167e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_12  arc_capacity_1384  1
    load_2_16_12  segment_load_conservation_1537  -1
    load_2_16_12  segment_prefix_lb_1538  1
    load_2_16_12  segment_prefix_ub_1539  1
    load_2_16_12  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_13  arc_capacity_1386  -30
    arc_2_16_13  connected_order_arc_1387  -13
    arc_2_16_13  in_degree_1541  1
    arc_2_16_13  out_degree_1559  1
    arc_2_16_13  original_T_including_depot_unload_1598  2.4496137598598170e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_13  arc_capacity_1386  1
    load_2_16_13  segment_load_conservation_1544  -1
    load_2_16_13  segment_prefix_lb_1545  1
    load_2_16_13  segment_prefix_ub_1546  1
    load_2_16_13  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_14  arc_capacity_1388  -30
    arc_2_16_14  connected_order_arc_1389  -13
    arc_2_16_14  in_degree_1548  1
    arc_2_16_14  out_degree_1559  1
    arc_2_16_14  original_T_including_depot_unload_1598  1.6876944916846833e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_14  arc_capacity_1388  1
    load_2_16_14  free_load_conservation_1552  -1
    load_2_16_14  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_15  arc_capacity_1390  -30
    arc_2_16_15  connected_order_arc_1391  -13
    arc_2_16_15  in_degree_1554  1
    arc_2_16_15  out_degree_1559  1
    arc_2_16_15  original_T_including_depot_unload_1598  1.5013589792907314e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_15  arc_capacity_1390  1
    load_2_16_15  free_load_conservation_1558  -1
    load_2_16_15  free_load_conservation_1564  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_17  arc_capacity_1392  -30
    arc_2_16_17  connected_order_arc_1393  -13
    arc_2_16_17  out_degree_1559  1
    arc_2_16_17  in_degree_1566  1
    arc_2_16_17  original_T_including_depot_unload_1598  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_17  arc_capacity_1392  1
    load_2_16_17  free_load_conservation_1564  1
    load_2_16_17  free_load_conservation_1570  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_18  arc_capacity_1394  -30
    arc_2_16_18  connected_order_arc_1395  -13
    arc_2_16_18  out_degree_1559  1
    arc_2_16_18  in_degree_1572  1
    arc_2_16_18  original_T_including_depot_unload_1598  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_18  arc_capacity_1394  1
    load_2_16_18  free_load_conservation_1564  1
    load_2_16_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_19  arc_capacity_1396  -30
    arc_2_16_19  connected_order_arc_1397  -13
    arc_2_16_19  out_degree_1559  1
    arc_2_16_19  in_degree_1578  1
    arc_2_16_19  original_T_including_depot_unload_1598  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_19  arc_capacity_1396  1
    load_2_16_19  free_load_conservation_1564  1
    load_2_16_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_20  arc_capacity_1398  -30
    arc_2_16_20  connected_order_arc_1399  -13
    arc_2_16_20  out_degree_1559  1
    arc_2_16_20  in_degree_1584  1
    arc_2_16_20  original_T_including_depot_unload_1598  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_20  arc_capacity_1398  1
    load_2_16_20  free_load_conservation_1564  1
    load_2_16_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_16_21  arc_capacity_1400  -30
    arc_2_16_21  connected_order_arc_1401  -13
    arc_2_16_21  out_degree_1559  1
    arc_2_16_21  in_degree_1590  1
    arc_2_16_21  original_T_including_depot_unload_1598  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_16_21  arc_capacity_1400  1
    load_2_16_21  free_load_conservation_1564  1
    load_2_16_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_0  arc_capacity_1402  -30
    arc_2_17_0  depot_return_or_bypass_1518  1
    arc_2_17_0  out_degree_1565  1
    arc_2_17_0  original_T_including_depot_unload_1598  887.312716328479
    MARKER    'MARKER'                 'INTEND'
    load_2_17_0  arc_capacity_1402  1
    load_2_17_0  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_10  arc_capacity_1403  -30
    arc_2_17_10  connected_order_arc_1404  -13
    arc_2_17_10  in_degree_1520  1
    arc_2_17_10  out_degree_1565  1
    arc_2_17_10  original_T_including_depot_unload_1598  1.1485840683203917e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_10  arc_capacity_1403  1
    load_2_17_10  segment_load_conservation_1523  -1
    load_2_17_10  segment_prefix_lb_1524  1
    load_2_17_10  segment_prefix_ub_1525  1
    load_2_17_10  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_11  arc_capacity_1405  -30
    arc_2_17_11  connected_order_arc_1406  -13
    arc_2_17_11  in_degree_1527  1
    arc_2_17_11  out_degree_1565  1
    arc_2_17_11  original_T_including_depot_unload_1598  2.2630748095713293e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_11  arc_capacity_1405  1
    load_2_17_11  segment_load_conservation_1530  -1
    load_2_17_11  segment_prefix_lb_1531  1
    load_2_17_11  segment_prefix_ub_1532  1
    load_2_17_11  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_12  arc_capacity_1407  -30
    arc_2_17_12  connected_order_arc_1408  -13
    arc_2_17_12  in_degree_1534  1
    arc_2_17_12  out_degree_1565  1
    arc_2_17_12  original_T_including_depot_unload_1598  2.1293186465553604e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_12  arc_capacity_1407  1
    load_2_17_12  segment_load_conservation_1537  -1
    load_2_17_12  segment_prefix_lb_1538  1
    load_2_17_12  segment_prefix_ub_1539  1
    load_2_17_12  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_13  arc_capacity_1409  -30
    arc_2_17_13  connected_order_arc_1410  -13
    arc_2_17_13  in_degree_1541  1
    arc_2_17_13  out_degree_1565  1
    arc_2_17_13  original_T_including_depot_unload_1598  1.9996644912858792e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_13  arc_capacity_1409  1
    load_2_17_13  segment_load_conservation_1544  -1
    load_2_17_13  segment_prefix_lb_1545  1
    load_2_17_13  segment_prefix_ub_1546  1
    load_2_17_13  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_14  arc_capacity_1411  -30
    arc_2_17_14  connected_order_arc_1412  -13
    arc_2_17_14  in_degree_1548  1
    arc_2_17_14  out_degree_1565  1
    arc_2_17_14  original_T_including_depot_unload_1598  4.0010881633455318e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_14  arc_capacity_1411  1
    load_2_17_14  free_load_conservation_1552  -1
    load_2_17_14  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_15  arc_capacity_1413  -30
    arc_2_17_15  connected_order_arc_1414  -13
    arc_2_17_15  in_degree_1554  1
    arc_2_17_15  out_degree_1565  1
    arc_2_17_15  original_T_including_depot_unload_1598  1.0652142597817847e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_15  arc_capacity_1413  1
    load_2_17_15  free_load_conservation_1558  -1
    load_2_17_15  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_16  arc_capacity_1415  -30
    arc_2_17_16  connected_order_arc_1416  -13
    arc_2_17_16  in_degree_1560  1
    arc_2_17_16  out_degree_1565  1
    arc_2_17_16  original_T_including_depot_unload_1598  1.4573788798892317e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_17_16  arc_capacity_1415  1
    load_2_17_16  free_load_conservation_1564  -1
    load_2_17_16  free_load_conservation_1570  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_18  arc_capacity_1417  -30
    arc_2_17_18  connected_order_arc_1418  -13
    arc_2_17_18  out_degree_1565  1
    arc_2_17_18  in_degree_1572  1
    arc_2_17_18  original_T_including_depot_unload_1598  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_18  arc_capacity_1417  1
    load_2_17_18  free_load_conservation_1570  1
    load_2_17_18  free_load_conservation_1576  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_19  arc_capacity_1419  -30
    arc_2_17_19  connected_order_arc_1420  -13
    arc_2_17_19  out_degree_1565  1
    arc_2_17_19  in_degree_1578  1
    arc_2_17_19  original_T_including_depot_unload_1598  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_19  arc_capacity_1419  1
    load_2_17_19  free_load_conservation_1570  1
    load_2_17_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_20  arc_capacity_1421  -30
    arc_2_17_20  connected_order_arc_1422  -13
    arc_2_17_20  out_degree_1565  1
    arc_2_17_20  in_degree_1584  1
    arc_2_17_20  original_T_including_depot_unload_1598  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_17_20  arc_capacity_1421  1
    load_2_17_20  free_load_conservation_1570  1
    load_2_17_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_17_21  arc_capacity_1423  -30
    arc_2_17_21  connected_order_arc_1424  -13
    arc_2_17_21  out_degree_1565  1
    arc_2_17_21  in_degree_1590  1
    arc_2_17_21  original_T_including_depot_unload_1598  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_17_21  arc_capacity_1423  1
    load_2_17_21  free_load_conservation_1570  1
    load_2_17_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_0  arc_capacity_1425  -30
    arc_2_18_0  depot_return_or_bypass_1518  1
    arc_2_18_0  out_degree_1571  1
    arc_2_18_0  original_T_including_depot_unload_1598  5.8574858985102867e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_0  arc_capacity_1425  1
    load_2_18_0  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_10  arc_capacity_1426  -30
    arc_2_18_10  connected_order_arc_1427  -13
    arc_2_18_10  in_degree_1520  1
    arc_2_18_10  out_degree_1571  1
    arc_2_18_10  original_T_including_depot_unload_1598  8.3486971116736720e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_10  arc_capacity_1426  1
    load_2_18_10  segment_load_conservation_1523  -1
    load_2_18_10  segment_prefix_lb_1524  1
    load_2_18_10  segment_prefix_ub_1525  1
    load_2_18_10  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_11  arc_capacity_1428  -30
    arc_2_18_11  connected_order_arc_1429  -13
    arc_2_18_11  in_degree_1527  1
    arc_2_18_11  out_degree_1571  1
    arc_2_18_11  original_T_including_depot_unload_1598  2.0178882184947397e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_11  arc_capacity_1428  1
    load_2_18_11  segment_load_conservation_1530  -1
    load_2_18_11  segment_prefix_lb_1531  1
    load_2_18_11  segment_prefix_ub_1532  1
    load_2_18_11  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_12  arc_capacity_1430  -30
    arc_2_18_12  connected_order_arc_1431  -13
    arc_2_18_12  in_degree_1534  1
    arc_2_18_12  out_degree_1571  1
    arc_2_18_12  original_T_including_depot_unload_1598  1.8362893893653638e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_12  arc_capacity_1430  1
    load_2_18_12  segment_load_conservation_1537  -1
    load_2_18_12  segment_prefix_lb_1538  1
    load_2_18_12  segment_prefix_ub_1539  1
    load_2_18_12  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_13  arc_capacity_1432  -30
    arc_2_18_13  connected_order_arc_1433  -13
    arc_2_18_13  in_degree_1541  1
    arc_2_18_13  out_degree_1571  1
    arc_2_18_13  original_T_including_depot_unload_1598  1.6906177970488723e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_13  arc_capacity_1432  1
    load_2_18_13  segment_load_conservation_1544  -1
    load_2_18_13  segment_prefix_lb_1545  1
    load_2_18_13  segment_prefix_ub_1546  1
    load_2_18_13  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_14  arc_capacity_1434  -30
    arc_2_18_14  connected_order_arc_1435  -13
    arc_2_18_14  in_degree_1548  1
    arc_2_18_14  out_degree_1571  1
    arc_2_18_14  original_T_including_depot_unload_1598  7.3287495843240220e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_14  arc_capacity_1434  1
    load_2_18_14  free_load_conservation_1552  -1
    load_2_18_14  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_15  arc_capacity_1436  -30
    arc_2_18_15  connected_order_arc_1437  -13
    arc_2_18_15  in_degree_1554  1
    arc_2_18_15  out_degree_1571  1
    arc_2_18_15  original_T_including_depot_unload_1598  4.4073908743473044e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_15  arc_capacity_1436  1
    load_2_18_15  free_load_conservation_1558  -1
    load_2_18_15  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_16  arc_capacity_1438  -30
    arc_2_18_16  connected_order_arc_1439  -13
    arc_2_18_16  in_degree_1560  1
    arc_2_18_16  out_degree_1571  1
    arc_2_18_16  original_T_including_depot_unload_1598  1.3695803923376043e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_16  arc_capacity_1438  1
    load_2_18_16  free_load_conservation_1564  -1
    load_2_18_16  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_17  arc_capacity_1440  -30
    arc_2_18_17  connected_order_arc_1441  -13
    arc_2_18_17  in_degree_1566  1
    arc_2_18_17  out_degree_1571  1
    arc_2_18_17  original_T_including_depot_unload_1598  3.3422575089633142e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_17  arc_capacity_1440  1
    load_2_18_17  free_load_conservation_1570  -1
    load_2_18_17  free_load_conservation_1576  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_19  arc_capacity_1442  -30
    arc_2_18_19  connected_order_arc_1443  -13
    arc_2_18_19  out_degree_1571  1
    arc_2_18_19  in_degree_1578  1
    arc_2_18_19  original_T_including_depot_unload_1598  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_19  arc_capacity_1442  1
    load_2_18_19  free_load_conservation_1576  1
    load_2_18_19  free_load_conservation_1582  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_20  arc_capacity_1444  -30
    arc_2_18_20  connected_order_arc_1445  -13
    arc_2_18_20  out_degree_1571  1
    arc_2_18_20  in_degree_1584  1
    arc_2_18_20  original_T_including_depot_unload_1598  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_18_20  arc_capacity_1444  1
    load_2_18_20  free_load_conservation_1576  1
    load_2_18_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_18_21  arc_capacity_1446  -30
    arc_2_18_21  connected_order_arc_1447  -13
    arc_2_18_21  out_degree_1571  1
    arc_2_18_21  in_degree_1590  1
    arc_2_18_21  original_T_including_depot_unload_1598  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_18_21  arc_capacity_1446  1
    load_2_18_21  free_load_conservation_1576  1
    load_2_18_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_0  arc_capacity_1448  -30
    arc_2_19_0  depot_return_or_bypass_1518  1
    arc_2_19_0  out_degree_1577  1
    arc_2_19_0  original_T_including_depot_unload_1598  7.8195480223834068e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_0  arc_capacity_1448  1
    load_2_19_0  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_10  arc_capacity_1449  -30
    arc_2_19_10  connected_order_arc_1450  -13
    arc_2_19_10  in_degree_1520  1
    arc_2_19_10  out_degree_1577  1
    arc_2_19_10  original_T_including_depot_unload_1598  1.0453757248865720e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_10  arc_capacity_1449  1
    load_2_19_10  segment_load_conservation_1523  -1
    load_2_19_10  segment_prefix_lb_1524  1
    load_2_19_10  segment_prefix_ub_1525  1
    load_2_19_10  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_11  arc_capacity_1451  -30
    arc_2_19_11  connected_order_arc_1452  -13
    arc_2_19_11  in_degree_1527  1
    arc_2_19_11  out_degree_1577  1
    arc_2_19_11  original_T_including_depot_unload_1598  2.1519454102199375e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_11  arc_capacity_1451  1
    load_2_19_11  segment_load_conservation_1530  -1
    load_2_19_11  segment_prefix_lb_1531  1
    load_2_19_11  segment_prefix_ub_1532  1
    load_2_19_11  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_12  arc_capacity_1453  -30
    arc_2_19_12  connected_order_arc_1454  -13
    arc_2_19_12  in_degree_1534  1
    arc_2_19_12  out_degree_1577  1
    arc_2_19_12  original_T_including_depot_unload_1598  2.0204177348160229e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_12  arc_capacity_1453  1
    load_2_19_12  segment_load_conservation_1537  -1
    load_2_19_12  segment_prefix_lb_1538  1
    load_2_19_12  segment_prefix_ub_1539  1
    load_2_19_12  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_13  arc_capacity_1455  -30
    arc_2_19_13  connected_order_arc_1456  -13
    arc_2_19_13  in_degree_1541  1
    arc_2_19_13  out_degree_1577  1
    arc_2_19_13  original_T_including_depot_unload_1598  1.9436220397684422e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_13  arc_capacity_1455  1
    load_2_19_13  segment_load_conservation_1544  -1
    load_2_19_13  segment_prefix_lb_1545  1
    load_2_19_13  segment_prefix_ub_1546  1
    load_2_19_13  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_14  arc_capacity_1457  -30
    arc_2_19_14  connected_order_arc_1458  -13
    arc_2_19_14  in_degree_1548  1
    arc_2_19_14  out_degree_1577  1
    arc_2_19_14  original_T_including_depot_unload_1598  4.9903342483612323e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_14  arc_capacity_1457  1
    load_2_19_14  free_load_conservation_1552  -1
    load_2_19_14  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_15  arc_capacity_1459  -30
    arc_2_19_15  connected_order_arc_1460  -13
    arc_2_19_15  in_degree_1554  1
    arc_2_19_15  out_degree_1577  1
    arc_2_19_15  original_T_including_depot_unload_1598  2.0644059606137412e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_15  arc_capacity_1459  1
    load_2_19_15  free_load_conservation_1558  -1
    load_2_19_15  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_16  arc_capacity_1461  -30
    arc_2_19_16  connected_order_arc_1462  -13
    arc_2_19_16  in_degree_1560  1
    arc_2_19_16  out_degree_1577  1
    arc_2_19_16  original_T_including_depot_unload_1598  1.3626829404511475e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_19_16  arc_capacity_1461  1
    load_2_19_16  free_load_conservation_1564  -1
    load_2_19_16  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_17  arc_capacity_1463  -30
    arc_2_19_17  connected_order_arc_1464  -13
    arc_2_19_17  in_degree_1566  1
    arc_2_19_17  out_degree_1577  1
    arc_2_19_17  original_T_including_depot_unload_1598  1.1119949880978965e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_17  arc_capacity_1463  1
    load_2_19_17  free_load_conservation_1570  -1
    load_2_19_17  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_18  arc_capacity_1465  -30
    arc_2_19_18  connected_order_arc_1466  -13
    arc_2_19_18  in_degree_1572  1
    arc_2_19_18  out_degree_1577  1
    arc_2_19_18  original_T_including_depot_unload_1598  2.5572087458878266e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_18  arc_capacity_1465  1
    load_2_19_18  free_load_conservation_1576  -1
    load_2_19_18  free_load_conservation_1582  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_20  arc_capacity_1467  -30
    arc_2_19_20  connected_order_arc_1468  -13
    arc_2_19_20  out_degree_1577  1
    arc_2_19_20  in_degree_1584  1
    arc_2_19_20  original_T_including_depot_unload_1598  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_19_20  arc_capacity_1467  1
    load_2_19_20  free_load_conservation_1582  1
    load_2_19_20  free_load_conservation_1588  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_19_21  arc_capacity_1469  -30
    arc_2_19_21  connected_order_arc_1470  -13
    arc_2_19_21  out_degree_1577  1
    arc_2_19_21  in_degree_1590  1
    arc_2_19_21  original_T_including_depot_unload_1598  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_19_21  arc_capacity_1469  1
    load_2_19_21  free_load_conservation_1582  1
    load_2_19_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_0  arc_capacity_1471  -30
    arc_2_20_0  depot_return_or_bypass_1518  1
    arc_2_20_0  out_degree_1583  1
    arc_2_20_0  original_T_including_depot_unload_1598  1.3684002807998324e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_0  arc_capacity_1471  1
    load_2_20_0  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_10  arc_capacity_1472  -30
    arc_2_20_10  connected_order_arc_1473  -13
    arc_2_20_10  in_degree_1520  1
    arc_2_20_10  out_degree_1583  1
    arc_2_20_10  original_T_including_depot_unload_1598  1.1544376314422677e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_10  arc_capacity_1472  1
    load_2_20_10  segment_load_conservation_1523  -1
    load_2_20_10  segment_prefix_lb_1524  1
    load_2_20_10  segment_prefix_ub_1525  1
    load_2_20_10  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_11  arc_capacity_1474  -30
    arc_2_20_11  connected_order_arc_1475  -13
    arc_2_20_11  in_degree_1527  1
    arc_2_20_11  out_degree_1583  1
    arc_2_20_11  original_T_including_depot_unload_1598  3.1118349756671438e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_11  arc_capacity_1474  1
    load_2_20_11  segment_load_conservation_1530  -1
    load_2_20_11  segment_prefix_lb_1531  1
    load_2_20_11  segment_prefix_ub_1532  1
    load_2_20_11  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_12  arc_capacity_1476  -30
    arc_2_20_12  connected_order_arc_1477  -13
    arc_2_20_12  in_degree_1534  1
    arc_2_20_12  out_degree_1583  1
    arc_2_20_12  original_T_including_depot_unload_1598  2.2865444230199981e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_20_12  arc_capacity_1476  1
    load_2_20_12  segment_load_conservation_1537  -1
    load_2_20_12  segment_prefix_lb_1538  1
    load_2_20_12  segment_prefix_ub_1539  1
    load_2_20_12  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_13  arc_capacity_1478  -30
    arc_2_20_13  connected_order_arc_1479  -13
    arc_2_20_13  in_degree_1541  1
    arc_2_20_13  out_degree_1583  1
    arc_2_20_13  original_T_including_depot_unload_1598  1.8780729343410642e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_13  arc_capacity_1478  1
    load_2_20_13  segment_load_conservation_1544  -1
    load_2_20_13  segment_prefix_lb_1545  1
    load_2_20_13  segment_prefix_ub_1546  1
    load_2_20_13  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_14  arc_capacity_1480  -30
    arc_2_20_14  connected_order_arc_1481  -13
    arc_2_20_14  in_degree_1548  1
    arc_2_20_14  out_degree_1583  1
    arc_2_20_14  original_T_including_depot_unload_1598  2.5950001064050621e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_14  arc_capacity_1480  1
    load_2_20_14  free_load_conservation_1552  -1
    load_2_20_14  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_15  arc_capacity_1482  -30
    arc_2_20_15  connected_order_arc_1483  -13
    arc_2_20_15  in_degree_1554  1
    arc_2_20_15  out_degree_1583  1
    arc_2_20_15  original_T_including_depot_unload_1598  2.3179341182261583e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_15  arc_capacity_1482  1
    load_2_20_15  free_load_conservation_1558  -1
    load_2_20_15  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_16  arc_capacity_1484  -30
    arc_2_20_16  connected_order_arc_1485  -13
    arc_2_20_16  in_degree_1560  1
    arc_2_20_16  out_degree_1583  1
    arc_2_20_16  original_T_including_depot_unload_1598  1.3616979273334366e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_16  arc_capacity_1484  1
    load_2_20_16  free_load_conservation_1564  -1
    load_2_20_16  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_17  arc_capacity_1486  -30
    arc_2_20_17  connected_order_arc_1487  -13
    arc_2_20_17  in_degree_1566  1
    arc_2_20_17  out_degree_1583  1
    arc_2_20_17  original_T_including_depot_unload_1598  2226.1143218952
    MARKER    'MARKER'                 'INTEND'
    load_2_20_17  arc_capacity_1486  1
    load_2_20_17  free_load_conservation_1570  -1
    load_2_20_17  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_18  arc_capacity_1488  -30
    arc_2_20_18  connected_order_arc_1489  -13
    arc_2_20_18  in_degree_1572  1
    arc_2_20_18  out_degree_1583  1
    arc_2_20_18  original_T_including_depot_unload_1598  1.9505860420753618e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_18  arc_capacity_1488  1
    load_2_20_18  free_load_conservation_1576  -1
    load_2_20_18  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_19  arc_capacity_1490  -30
    arc_2_20_19  connected_order_arc_1491  -13
    arc_2_20_19  in_degree_1578  1
    arc_2_20_19  out_degree_1583  1
    arc_2_20_19  original_T_including_depot_unload_1598  2115.53677476792
    MARKER    'MARKER'                 'INTEND'
    load_2_20_19  arc_capacity_1490  1
    load_2_20_19  free_load_conservation_1582  -1
    load_2_20_19  free_load_conservation_1588  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_20_21  arc_capacity_1492  -30
    arc_2_20_21  connected_order_arc_1493  -13
    arc_2_20_21  out_degree_1583  1
    arc_2_20_21  in_degree_1590  1
    arc_2_20_21  original_T_including_depot_unload_1598  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_20_21  arc_capacity_1492  1
    load_2_20_21  free_load_conservation_1588  1
    load_2_20_21  free_load_conservation_1594  -1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_0  arc_capacity_1494  -30
    arc_2_21_0  depot_return_or_bypass_1518  1
    arc_2_21_0  out_degree_1589  1
    arc_2_21_0  original_T_including_depot_unload_1598  1.3076700111397606e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_0  arc_capacity_1494  1
    load_2_21_0  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_10  arc_capacity_1495  -30
    arc_2_21_10  connected_order_arc_1496  -13
    arc_2_21_10  in_degree_1520  1
    arc_2_21_10  out_degree_1589  1
    arc_2_21_10  original_T_including_depot_unload_1598  1.5688206371681019e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_10  arc_capacity_1495  1
    load_2_21_10  segment_load_conservation_1523  -1
    load_2_21_10  segment_prefix_lb_1524  1
    load_2_21_10  segment_prefix_ub_1525  1
    load_2_21_10  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_11  arc_capacity_1497  -30
    arc_2_21_11  connected_order_arc_1498  -13
    arc_2_21_11  in_degree_1527  1
    arc_2_21_11  out_degree_1589  1
    arc_2_21_11  original_T_including_depot_unload_1598  2.4002470706280069e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_11  arc_capacity_1497  1
    load_2_21_11  segment_load_conservation_1530  -1
    load_2_21_11  segment_prefix_lb_1531  1
    load_2_21_11  segment_prefix_ub_1532  1
    load_2_21_11  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_12  arc_capacity_1499  -30
    arc_2_21_12  connected_order_arc_1500  -13
    arc_2_21_12  in_degree_1534  1
    arc_2_21_12  out_degree_1589  1
    arc_2_21_12  original_T_including_depot_unload_1598  2412.70187975598
    MARKER    'MARKER'                 'INTEND'
    load_2_21_12  arc_capacity_1499  1
    load_2_21_12  segment_load_conservation_1537  -1
    load_2_21_12  segment_prefix_lb_1538  1
    load_2_21_12  segment_prefix_ub_1539  1
    load_2_21_12  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_13  arc_capacity_1501  -30
    arc_2_21_13  connected_order_arc_1502  -13
    arc_2_21_13  in_degree_1541  1
    arc_2_21_13  out_degree_1589  1
    arc_2_21_13  original_T_including_depot_unload_1598  2.6227054239003946e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_13  arc_capacity_1501  1
    load_2_21_13  segment_load_conservation_1544  -1
    load_2_21_13  segment_prefix_lb_1545  1
    load_2_21_13  segment_prefix_ub_1546  1
    load_2_21_13  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_14  arc_capacity_1503  -30
    arc_2_21_14  connected_order_arc_1504  -13
    arc_2_21_14  in_degree_1548  1
    arc_2_21_14  out_degree_1589  1
    arc_2_21_14  original_T_including_depot_unload_1598  5.4630148713373910e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_14  arc_capacity_1503  1
    load_2_21_14  free_load_conservation_1552  -1
    load_2_21_14  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_15  arc_capacity_1505  -30
    arc_2_21_15  connected_order_arc_1506  -13
    arc_2_21_15  in_degree_1554  1
    arc_2_21_15  out_degree_1589  1
    arc_2_21_15  original_T_including_depot_unload_1598  6.0870346483367848e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_15  arc_capacity_1505  1
    load_2_21_15  free_load_conservation_1558  -1
    load_2_21_15  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_16  arc_capacity_1507  -30
    arc_2_21_16  connected_order_arc_1508  -13
    arc_2_21_16  in_degree_1560  1
    arc_2_21_16  out_degree_1589  1
    arc_2_21_16  original_T_including_depot_unload_1598  1.3218357148919101e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_16  arc_capacity_1507  1
    load_2_21_16  free_load_conservation_1564  -1
    load_2_21_16  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_17  arc_capacity_1509  -30
    arc_2_21_17  connected_order_arc_1510  -13
    arc_2_21_17  in_degree_1566  1
    arc_2_21_17  out_degree_1589  1
    arc_2_21_17  original_T_including_depot_unload_1598  6.7554763364087285e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_17  arc_capacity_1509  1
    load_2_21_17  free_load_conservation_1570  -1
    load_2_21_17  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_18  arc_capacity_1511  -30
    arc_2_21_18  connected_order_arc_1512  -13
    arc_2_21_18  in_degree_1572  1
    arc_2_21_18  out_degree_1589  1
    arc_2_21_18  original_T_including_depot_unload_1598  9.3685967675232439e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_18  arc_capacity_1511  1
    load_2_21_18  free_load_conservation_1576  -1
    load_2_21_18  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_19  arc_capacity_1513  -30
    arc_2_21_19  connected_order_arc_1514  -13
    arc_2_21_19  in_degree_1578  1
    arc_2_21_19  out_degree_1589  1
    arc_2_21_19  original_T_including_depot_unload_1598  6.9492720147205364e+02
    MARKER    'MARKER'                 'INTEND'
    load_2_21_19  arc_capacity_1513  1
    load_2_21_19  free_load_conservation_1582  -1
    load_2_21_19  free_load_conservation_1594  1
    MARKER    'MARKER'                 'INTORG'
    arc_2_21_20  arc_capacity_1515  -30
    arc_2_21_20  connected_order_arc_1516  -13
    arc_2_21_20  in_degree_1584  1
    arc_2_21_20  out_degree_1589  1
    arc_2_21_20  original_T_including_depot_unload_1598  2.4500766064196278e+03
    MARKER    'MARKER'                 'INTEND'
    load_2_21_20  arc_capacity_1515  1
    load_2_21_20  free_load_conservation_1588  -1
    load_2_21_20  free_load_conservation_1594  1
RHS
    RHS1      OBJ       -0.50775
    RHS1      onehot_28_40  1
    RHS1      onehot_23_67  1
    RHS1      onehot_31_96  1
    RHS1      onehot_21_131  1
    RHS1      onehot_16_160  1
    RHS1      onehot_20_189  1
    RHS1      onehot_32_218  1
    RHS1      onehot_33_255  1
    RHS1      stock_ub_259  37
    RHS1      parent_nonstrict_scope_260  2.8307157375771530e-01
    RHS1      normalization_317  1
    RHS1      connected_order_arc_443  -12
    RHS1      connected_order_arc_445  -12
    RHS1      connected_order_arc_447  -12
    RHS1      connected_order_arc_449  -12
    RHS1      connected_order_arc_451  -12
    RHS1      connected_order_arc_453  -12
    RHS1      connected_order_arc_455  -12
    RHS1      connected_order_arc_457  -12
    RHS1      connected_order_arc_459  -12
    RHS1      connected_order_arc_461  -12
    RHS1      connected_order_arc_463  -12
    RHS1      connected_order_arc_466  -12
    RHS1      connected_order_arc_468  -12
    RHS1      connected_order_arc_470  -12
    RHS1      connected_order_arc_472  -12
    RHS1      connected_order_arc_474  -12
    RHS1      connected_order_arc_476  -12
    RHS1      connected_order_arc_478  -12
    RHS1      connected_order_arc_480  -12
    RHS1      connected_order_arc_482  -12
    RHS1      connected_order_arc_484  -12
    RHS1      connected_order_arc_486  -12
    RHS1      connected_order_arc_489  -12
    RHS1      connected_order_arc_491  -12
    RHS1      connected_order_arc_493  -12
    RHS1      connected_order_arc_495  -12
    RHS1      connected_order_arc_497  -12
    RHS1      connected_order_arc_499  -12
    RHS1      connected_order_arc_501  -12
    RHS1      connected_order_arc_503  -12
    RHS1      connected_order_arc_505  -12
    RHS1      connected_order_arc_507  -12
    RHS1      connected_order_arc_509  -12
    RHS1      connected_order_arc_512  -12
    RHS1      connected_order_arc_514  -12
    RHS1      connected_order_arc_516  -12
    RHS1      connected_order_arc_518  -12
    RHS1      connected_order_arc_520  -12
    RHS1      connected_order_arc_522  -12
    RHS1      connected_order_arc_524  -12
    RHS1      connected_order_arc_526  -12
    RHS1      connected_order_arc_528  -12
    RHS1      connected_order_arc_530  -12
    RHS1      connected_order_arc_532  -12
    RHS1      connected_order_arc_535  -12
    RHS1      connected_order_arc_537  -12
    RHS1      connected_order_arc_539  -12
    RHS1      connected_order_arc_541  -12
    RHS1      connected_order_arc_543  -12
    RHS1      connected_order_arc_545  -12
    RHS1      connected_order_arc_547  -12
    RHS1      connected_order_arc_549  -12
    RHS1      connected_order_arc_551  -12
    RHS1      connected_order_arc_553  -12
    RHS1      connected_order_arc_555  -12
    RHS1      connected_order_arc_558  -12
    RHS1      connected_order_arc_560  -12
    RHS1      connected_order_arc_562  -12
    RHS1      connected_order_arc_564  -12
    RHS1      connected_order_arc_566  -12
    RHS1      connected_order_arc_568  -12
    RHS1      connected_order_arc_570  -12
    RHS1      connected_order_arc_572  -12
    RHS1      connected_order_arc_574  -12
    RHS1      connected_order_arc_576  -12
    RHS1      connected_order_arc_578  -12
    RHS1      connected_order_arc_581  -12
    RHS1      connected_order_arc_583  -12
    RHS1      connected_order_arc_585  -12
    RHS1      connected_order_arc_587  -12
    RHS1      connected_order_arc_589  -12
    RHS1      connected_order_arc_591  -12
    RHS1      connected_order_arc_593  -12
    RHS1      connected_order_arc_595  -12
    RHS1      connected_order_arc_597  -12
    RHS1      connected_order_arc_599  -12
    RHS1      connected_order_arc_601  -12
    RHS1      connected_order_arc_604  -12
    RHS1      connected_order_arc_606  -12
    RHS1      connected_order_arc_608  -12
    RHS1      connected_order_arc_610  -12
    RHS1      connected_order_arc_612  -12
    RHS1      connected_order_arc_614  -12
    RHS1      connected_order_arc_616  -12
    RHS1      connected_order_arc_618  -12
    RHS1      connected_order_arc_620  -12
    RHS1      connected_order_arc_622  -12
    RHS1      connected_order_arc_624  -12
    RHS1      connected_order_arc_627  -12
    RHS1      connected_order_arc_629  -12
    RHS1      connected_order_arc_631  -12
    RHS1      connected_order_arc_633  -12
    RHS1      connected_order_arc_635  -12
    RHS1      connected_order_arc_637  -12
    RHS1      connected_order_arc_639  -12
    RHS1      connected_order_arc_641  -12
    RHS1      connected_order_arc_643  -12
    RHS1      connected_order_arc_645  -12
    RHS1      connected_order_arc_647  -12
    RHS1      connected_order_arc_650  -12
    RHS1      connected_order_arc_652  -12
    RHS1      connected_order_arc_654  -12
    RHS1      connected_order_arc_656  -12
    RHS1      connected_order_arc_658  -12
    RHS1      connected_order_arc_660  -12
    RHS1      connected_order_arc_662  -12
    RHS1      connected_order_arc_664  -12
    RHS1      connected_order_arc_666  -12
    RHS1      connected_order_arc_668  -12
    RHS1      connected_order_arc_670  -12
    RHS1      connected_order_arc_673  -12
    RHS1      connected_order_arc_675  -12
    RHS1      connected_order_arc_677  -12
    RHS1      connected_order_arc_679  -12
    RHS1      connected_order_arc_681  -12
    RHS1      connected_order_arc_683  -12
    RHS1      connected_order_arc_685  -12
    RHS1      connected_order_arc_687  -12
    RHS1      connected_order_arc_689  -12
    RHS1      connected_order_arc_691  -12
    RHS1      connected_order_arc_693  -12
    RHS1      connected_order_arc_696  -12
    RHS1      connected_order_arc_698  -12
    RHS1      connected_order_arc_700  -12
    RHS1      connected_order_arc_702  -12
    RHS1      connected_order_arc_704  -12
    RHS1      connected_order_arc_706  -12
    RHS1      connected_order_arc_708  -12
    RHS1      connected_order_arc_710  -12
    RHS1      connected_order_arc_712  -12
    RHS1      connected_order_arc_714  -12
    RHS1      connected_order_arc_716  -12
    RHS1      depot_departure_or_bypass_717  1
    RHS1      depot_return_or_bypass_718  1
    RHS1      segment_load_conservation_723  5
    RHS1      segment_prefix_ub_725  15
    RHS1      segment_load_conservation_730  5
    RHS1      segment_prefix_ub_732  15
    RHS1      segment_load_conservation_737  4
    RHS1      segment_prefix_ub_739  16
    RHS1      segment_load_conservation_744  -14
    RHS1      segment_prefix_lb_745  14
    RHS1      segment_prefix_ub_746  16
    RHS1      fixed_segment_relative_order_795  1
    RHS1      fixed_segment_relative_order_796  1
    RHS1      fixed_segment_relative_order_797  1
    RHS1      original_T_including_depot_unload_798  1.6964019822822393e+03
    RHS1      connected_order_arc_815  -13
    RHS1      connected_order_arc_817  -13
    RHS1      connected_order_arc_819  -13
    RHS1      connected_order_arc_821  -13
    RHS1      connected_order_arc_823  -13
    RHS1      connected_order_arc_825  -13
    RHS1      connected_order_arc_827  -13
    RHS1      connected_order_arc_829  -13
    RHS1      connected_order_arc_831  -13
    RHS1      connected_order_arc_833  -13
    RHS1      connected_order_arc_835  -13
    RHS1      connected_order_arc_837  -13
    RHS1      connected_order_arc_840  -13
    RHS1      connected_order_arc_842  -13
    RHS1      connected_order_arc_844  -13
    RHS1      connected_order_arc_846  -13
    RHS1      connected_order_arc_848  -13
    RHS1      connected_order_arc_850  -13
    RHS1      connected_order_arc_852  -13
    RHS1      connected_order_arc_854  -13
    RHS1      connected_order_arc_856  -13
    RHS1      connected_order_arc_858  -13
    RHS1      connected_order_arc_860  -13
    RHS1      connected_order_arc_862  -13
    RHS1      connected_order_arc_865  -13
    RHS1      connected_order_arc_867  -13
    RHS1      connected_order_arc_869  -13
    RHS1      connected_order_arc_871  -13
    RHS1      connected_order_arc_873  -13
    RHS1      connected_order_arc_875  -13
    RHS1      connected_order_arc_877  -13
    RHS1      connected_order_arc_879  -13
    RHS1      connected_order_arc_881  -13
    RHS1      connected_order_arc_883  -13
    RHS1      connected_order_arc_885  -13
    RHS1      connected_order_arc_887  -13
    RHS1      connected_order_arc_890  -13
    RHS1      connected_order_arc_892  -13
    RHS1      connected_order_arc_894  -13
    RHS1      connected_order_arc_896  -13
    RHS1      connected_order_arc_898  -13
    RHS1      connected_order_arc_900  -13
    RHS1      connected_order_arc_902  -13
    RHS1      connected_order_arc_904  -13
    RHS1      connected_order_arc_906  -13
    RHS1      connected_order_arc_908  -13
    RHS1      connected_order_arc_910  -13
    RHS1      connected_order_arc_912  -13
    RHS1      connected_order_arc_915  -13
    RHS1      connected_order_arc_917  -13
    RHS1      connected_order_arc_919  -13
    RHS1      connected_order_arc_921  -13
    RHS1      connected_order_arc_923  -13
    RHS1      connected_order_arc_925  -13
    RHS1      connected_order_arc_927  -13
    RHS1      connected_order_arc_929  -13
    RHS1      connected_order_arc_931  -13
    RHS1      connected_order_arc_933  -13
    RHS1      connected_order_arc_935  -13
    RHS1      connected_order_arc_937  -13
    RHS1      connected_order_arc_940  -13
    RHS1      connected_order_arc_942  -13
    RHS1      connected_order_arc_944  -13
    RHS1      connected_order_arc_946  -13
    RHS1      connected_order_arc_948  -13
    RHS1      connected_order_arc_950  -13
    RHS1      connected_order_arc_952  -13
    RHS1      connected_order_arc_954  -13
    RHS1      connected_order_arc_956  -13
    RHS1      connected_order_arc_958  -13
    RHS1      connected_order_arc_960  -13
    RHS1      connected_order_arc_962  -13
    RHS1      connected_order_arc_965  -13
    RHS1      connected_order_arc_967  -13
    RHS1      connected_order_arc_969  -13
    RHS1      connected_order_arc_971  -13
    RHS1      connected_order_arc_973  -13
    RHS1      connected_order_arc_975  -13
    RHS1      connected_order_arc_977  -13
    RHS1      connected_order_arc_979  -13
    RHS1      connected_order_arc_981  -13
    RHS1      connected_order_arc_983  -13
    RHS1      connected_order_arc_985  -13
    RHS1      connected_order_arc_987  -13
    RHS1      connected_order_arc_990  -13
    RHS1      connected_order_arc_992  -13
    RHS1      connected_order_arc_994  -13
    RHS1      connected_order_arc_996  -13
    RHS1      connected_order_arc_998  -13
    RHS1      connected_order_arc_1000  -13
    RHS1      connected_order_arc_1002  -13
    RHS1      connected_order_arc_1004  -13
    RHS1      connected_order_arc_1006  -13
    RHS1      connected_order_arc_1008  -13
    RHS1      connected_order_arc_1010  -13
    RHS1      connected_order_arc_1012  -13
    RHS1      connected_order_arc_1015  -13
    RHS1      connected_order_arc_1017  -13
    RHS1      connected_order_arc_1019  -13
    RHS1      connected_order_arc_1021  -13
    RHS1      connected_order_arc_1023  -13
    RHS1      connected_order_arc_1025  -13
    RHS1      connected_order_arc_1027  -13
    RHS1      connected_order_arc_1029  -13
    RHS1      connected_order_arc_1031  -13
    RHS1      connected_order_arc_1033  -13
    RHS1      connected_order_arc_1035  -13
    RHS1      connected_order_arc_1037  -13
    RHS1      connected_order_arc_1040  -13
    RHS1      connected_order_arc_1042  -13
    RHS1      connected_order_arc_1044  -13
    RHS1      connected_order_arc_1046  -13
    RHS1      connected_order_arc_1048  -13
    RHS1      connected_order_arc_1050  -13
    RHS1      connected_order_arc_1052  -13
    RHS1      connected_order_arc_1054  -13
    RHS1      connected_order_arc_1056  -13
    RHS1      connected_order_arc_1058  -13
    RHS1      connected_order_arc_1060  -13
    RHS1      connected_order_arc_1062  -13
    RHS1      connected_order_arc_1065  -13
    RHS1      connected_order_arc_1067  -13
    RHS1      connected_order_arc_1069  -13
    RHS1      connected_order_arc_1071  -13
    RHS1      connected_order_arc_1073  -13
    RHS1      connected_order_arc_1075  -13
    RHS1      connected_order_arc_1077  -13
    RHS1      connected_order_arc_1079  -13
    RHS1      connected_order_arc_1081  -13
    RHS1      connected_order_arc_1083  -13
    RHS1      connected_order_arc_1085  -13
    RHS1      connected_order_arc_1087  -13
    RHS1      connected_order_arc_1090  -13
    RHS1      connected_order_arc_1092  -13
    RHS1      connected_order_arc_1094  -13
    RHS1      connected_order_arc_1096  -13
    RHS1      connected_order_arc_1098  -13
    RHS1      connected_order_arc_1100  -13
    RHS1      connected_order_arc_1102  -13
    RHS1      connected_order_arc_1104  -13
    RHS1      connected_order_arc_1106  -13
    RHS1      connected_order_arc_1108  -13
    RHS1      connected_order_arc_1110  -13
    RHS1      connected_order_arc_1112  -13
    RHS1      connected_order_arc_1115  -13
    RHS1      connected_order_arc_1117  -13
    RHS1      connected_order_arc_1119  -13
    RHS1      connected_order_arc_1121  -13
    RHS1      connected_order_arc_1123  -13
    RHS1      connected_order_arc_1125  -13
    RHS1      connected_order_arc_1127  -13
    RHS1      connected_order_arc_1129  -13
    RHS1      connected_order_arc_1131  -13
    RHS1      connected_order_arc_1133  -13
    RHS1      connected_order_arc_1135  -13
    RHS1      connected_order_arc_1137  -13
    RHS1      depot_departure_or_bypass_1138  1
    RHS1      depot_return_or_bypass_1139  1
    RHS1      segment_load_conservation_1144  6
    RHS1      segment_prefix_ub_1146  19
    RHS1      segment_prefix_lb_1152  4
    RHS1      segment_prefix_ub_1153  25
    RHS1      segment_load_conservation_1158  -2
    RHS1      segment_prefix_lb_1159  2
    RHS1      segment_prefix_ub_1160  25
    RHS1      segment_load_conservation_1165  2
    RHS1      segment_prefix_ub_1167  23
    RHS1      segment_load_conservation_1172  -5
    RHS1      segment_prefix_lb_1173  5
    RHS1      segment_prefix_ub_1174  25
    RHS1      fixed_segment_relative_order_1223  1
    RHS1      fixed_segment_relative_order_1224  1
    RHS1      fixed_segment_relative_order_1225  1
    RHS1      fixed_segment_relative_order_1226  1
    RHS1      original_T_including_depot_unload_1227  4961.45009840372
    RHS1      connected_order_arc_1243  -12
    RHS1      connected_order_arc_1245  -12
    RHS1      connected_order_arc_1247  -12
    RHS1      connected_order_arc_1249  -12
    RHS1      connected_order_arc_1251  -12
    RHS1      connected_order_arc_1253  -12
    RHS1      connected_order_arc_1255  -12
    RHS1      connected_order_arc_1257  -12
    RHS1      connected_order_arc_1259  -12
    RHS1      connected_order_arc_1261  -12
    RHS1      connected_order_arc_1263  -12
    RHS1      connected_order_arc_1266  -12
    RHS1      connected_order_arc_1268  -12
    RHS1      connected_order_arc_1270  -12
    RHS1      connected_order_arc_1272  -12
    RHS1      connected_order_arc_1274  -12
    RHS1      connected_order_arc_1276  -12
    RHS1      connected_order_arc_1278  -12
    RHS1      connected_order_arc_1280  -12
    RHS1      connected_order_arc_1282  -12
    RHS1      connected_order_arc_1284  -12
    RHS1      connected_order_arc_1286  -12
    RHS1      connected_order_arc_1289  -12
    RHS1      connected_order_arc_1291  -12
    RHS1      connected_order_arc_1293  -12
    RHS1      connected_order_arc_1295  -12
    RHS1      connected_order_arc_1297  -12
    RHS1      connected_order_arc_1299  -12
    RHS1      connected_order_arc_1301  -12
    RHS1      connected_order_arc_1303  -12
    RHS1      connected_order_arc_1305  -12
    RHS1      connected_order_arc_1307  -12
    RHS1      connected_order_arc_1309  -12
    RHS1      connected_order_arc_1312  -12
    RHS1      connected_order_arc_1314  -12
    RHS1      connected_order_arc_1316  -12
    RHS1      connected_order_arc_1318  -12
    RHS1      connected_order_arc_1320  -12
    RHS1      connected_order_arc_1322  -12
    RHS1      connected_order_arc_1324  -12
    RHS1      connected_order_arc_1326  -12
    RHS1      connected_order_arc_1328  -12
    RHS1      connected_order_arc_1330  -12
    RHS1      connected_order_arc_1332  -12
    RHS1      connected_order_arc_1335  -12
    RHS1      connected_order_arc_1337  -12
    RHS1      connected_order_arc_1339  -12
    RHS1      connected_order_arc_1341  -12
    RHS1      connected_order_arc_1343  -12
    RHS1      connected_order_arc_1345  -12
    RHS1      connected_order_arc_1347  -12
    RHS1      connected_order_arc_1349  -12
    RHS1      connected_order_arc_1351  -12
    RHS1      connected_order_arc_1353  -12
    RHS1      connected_order_arc_1355  -12
    RHS1      connected_order_arc_1358  -12
    RHS1      connected_order_arc_1360  -12
    RHS1      connected_order_arc_1362  -12
    RHS1      connected_order_arc_1364  -12
    RHS1      connected_order_arc_1366  -12
    RHS1      connected_order_arc_1368  -12
    RHS1      connected_order_arc_1370  -12
    RHS1      connected_order_arc_1372  -12
    RHS1      connected_order_arc_1374  -12
    RHS1      connected_order_arc_1376  -12
    RHS1      connected_order_arc_1378  -12
    RHS1      connected_order_arc_1381  -12
    RHS1      connected_order_arc_1383  -12
    RHS1      connected_order_arc_1385  -12
    RHS1      connected_order_arc_1387  -12
    RHS1      connected_order_arc_1389  -12
    RHS1      connected_order_arc_1391  -12
    RHS1      connected_order_arc_1393  -12
    RHS1      connected_order_arc_1395  -12
    RHS1      connected_order_arc_1397  -12
    RHS1      connected_order_arc_1399  -12
    RHS1      connected_order_arc_1401  -12
    RHS1      connected_order_arc_1404  -12
    RHS1      connected_order_arc_1406  -12
    RHS1      connected_order_arc_1408  -12
    RHS1      connected_order_arc_1410  -12
    RHS1      connected_order_arc_1412  -12
    RHS1      connected_order_arc_1414  -12
    RHS1      connected_order_arc_1416  -12
    RHS1      connected_order_arc_1418  -12
    RHS1      connected_order_arc_1420  -12
    RHS1      connected_order_arc_1422  -12
    RHS1      connected_order_arc_1424  -12
    RHS1      connected_order_arc_1427  -12
    RHS1      connected_order_arc_1429  -12
    RHS1      connected_order_arc_1431  -12
    RHS1      connected_order_arc_1433  -12
    RHS1      connected_order_arc_1435  -12
    RHS1      connected_order_arc_1437  -12
    RHS1      connected_order_arc_1439  -12
    RHS1      connected_order_arc_1441  -12
    RHS1      connected_order_arc_1443  -12
    RHS1      connected_order_arc_1445  -12
    RHS1      connected_order_arc_1447  -12
    RHS1      connected_order_arc_1450  -12
    RHS1      connected_order_arc_1452  -12
    RHS1      connected_order_arc_1454  -12
    RHS1      connected_order_arc_1456  -12
    RHS1      connected_order_arc_1458  -12
    RHS1      connected_order_arc_1460  -12
    RHS1      connected_order_arc_1462  -12
    RHS1      connected_order_arc_1464  -12
    RHS1      connected_order_arc_1466  -12
    RHS1      connected_order_arc_1468  -12
    RHS1      connected_order_arc_1470  -12
    RHS1      connected_order_arc_1473  -12
    RHS1      connected_order_arc_1475  -12
    RHS1      connected_order_arc_1477  -12
    RHS1      connected_order_arc_1479  -12
    RHS1      connected_order_arc_1481  -12
    RHS1      connected_order_arc_1483  -12
    RHS1      connected_order_arc_1485  -12
    RHS1      connected_order_arc_1487  -12
    RHS1      connected_order_arc_1489  -12
    RHS1      connected_order_arc_1491  -12
    RHS1      connected_order_arc_1493  -12
    RHS1      connected_order_arc_1496  -12
    RHS1      connected_order_arc_1498  -12
    RHS1      connected_order_arc_1500  -12
    RHS1      connected_order_arc_1502  -12
    RHS1      connected_order_arc_1504  -12
    RHS1      connected_order_arc_1506  -12
    RHS1      connected_order_arc_1508  -12
    RHS1      connected_order_arc_1510  -12
    RHS1      connected_order_arc_1512  -12
    RHS1      connected_order_arc_1514  -12
    RHS1      connected_order_arc_1516  -12
    RHS1      depot_departure_or_bypass_1517  1
    RHS1      depot_return_or_bypass_1518  1
    RHS1      segment_load_conservation_1523  3
    RHS1      segment_prefix_ub_1525  27
    RHS1      segment_load_conservation_1530  3
    RHS1      segment_prefix_ub_1532  27
    RHS1      segment_load_conservation_1537  -2
    RHS1      segment_prefix_lb_1538  2
    RHS1      segment_prefix_ub_1539  30
    RHS1      segment_load_conservation_1544  -2
    RHS1      segment_prefix_lb_1545  2
    RHS1      segment_prefix_ub_1546  24
    RHS1      fixed_segment_relative_order_1595  1
    RHS1      fixed_segment_relative_order_1596  1
    RHS1      fixed_segment_relative_order_1597  1
    RHS1      original_T_including_depot_unload_1598  4.2212502081486091e+03
BOUNDS
 LO BND1      t         2.4658499354157495e-02
 UP BND1      t         4.2187029162663148e-02
 UP BND1      q         4.9007157375771537e-01
 BV BND1      x_28_0  
 UP BND1      w_28_0    4.2187029162663148e-02
 BV BND1      x_28_1  
 UP BND1      w_28_1    4.2187029162663148e-02
 BV BND1      x_28_2  
 UP BND1      w_28_2    4.2187029162663148e-02
 BV BND1      x_28_3  
 UP BND1      w_28_3    4.2187029162663148e-02
 BV BND1      x_28_4  
 UP BND1      w_28_4    4.2187029162663148e-02
 BV BND1      x_28_5  
 UP BND1      w_28_5    4.2187029162663148e-02
 BV BND1      x_28_6  
 UP BND1      w_28_6    4.2187029162663148e-02
 BV BND1      x_28_7  
 UP BND1      w_28_7    4.2187029162663148e-02
 BV BND1      x_28_8  
 UP BND1      w_28_8    4.2187029162663148e-02
 BV BND1      x_28_9  
 UP BND1      w_28_9    4.2187029162663148e-02
 BV BND1      x_28_10 
 UP BND1      w_28_10   4.2187029162663148e-02
 BV BND1      x_28_11 
 UP BND1      w_28_11   4.2187029162663148e-02
 BV BND1      x_28_12 
 UP BND1      w_28_12   4.2187029162663148e-02
 BV BND1      x_28_13 
 UP BND1      w_28_13   4.2187029162663148e-02
 BV BND1      x_28_14 
 UP BND1      w_28_14   4.2187029162663148e-02
 BV BND1      x_28_15 
 UP BND1      w_28_15   4.2187029162663148e-02
 BV BND1      x_28_16 
 UP BND1      w_28_16   4.2187029162663148e-02
 BV BND1      x_28_17 
 UP BND1      w_28_17   4.2187029162663148e-02
 BV BND1      x_28_18 
 UP BND1      w_28_18   4.2187029162663148e-02
 BV BND1      x_28_19 
 UP BND1      w_28_19   4.2187029162663148e-02
 UP BND1      rho_28    1
 BV BND1      x_23_0  
 UP BND1      w_23_0    4.2187029162663148e-02
 BV BND1      x_23_1  
 UP BND1      w_23_1    4.2187029162663148e-02
 BV BND1      x_23_2  
 UP BND1      w_23_2    4.2187029162663148e-02
 BV BND1      x_23_3  
 UP BND1      w_23_3    4.2187029162663148e-02
 BV BND1      x_23_4  
 UP BND1      w_23_4    4.2187029162663148e-02
 BV BND1      x_23_5  
 UP BND1      w_23_5    4.2187029162663148e-02
 BV BND1      x_23_6  
 UP BND1      w_23_6    4.2187029162663148e-02
 BV BND1      x_23_7  
 UP BND1      w_23_7    4.2187029162663148e-02
 BV BND1      x_23_8  
 UP BND1      w_23_8    4.2187029162663148e-02
 BV BND1      x_23_9  
 UP BND1      w_23_9    4.2187029162663148e-02
 BV BND1      x_23_10 
 UP BND1      w_23_10   4.2187029162663148e-02
 BV BND1      x_23_11 
 UP BND1      w_23_11   4.2187029162663148e-02
 UP BND1      rho_23    1
 BV BND1      x_31_0  
 UP BND1      w_31_0    4.2187029162663148e-02
 BV BND1      x_31_1  
 UP BND1      w_31_1    4.2187029162663148e-02
 BV BND1      x_31_2  
 UP BND1      w_31_2    4.2187029162663148e-02
 BV BND1      x_31_3  
 UP BND1      w_31_3    4.2187029162663148e-02
 BV BND1      x_31_4  
 UP BND1      w_31_4    4.2187029162663148e-02
 BV BND1      x_31_5  
 UP BND1      w_31_5    4.2187029162663148e-02
 BV BND1      x_31_6  
 UP BND1      w_31_6    4.2187029162663148e-02
 BV BND1      x_31_7  
 UP BND1      w_31_7    4.2187029162663148e-02
 BV BND1      x_31_8  
 UP BND1      w_31_8    4.2187029162663148e-02
 BV BND1      x_31_9  
 UP BND1      w_31_9    4.2187029162663148e-02
 BV BND1      x_31_10 
 UP BND1      w_31_10   4.2187029162663148e-02
 BV BND1      x_31_11 
 UP BND1      w_31_11   4.2187029162663148e-02
 BV BND1      x_31_12 
 UP BND1      w_31_12   4.2187029162663148e-02
 UP BND1      rho_31    1
 BV BND1      x_21_0  
 UP BND1      w_21_0    4.2187029162663148e-02
 BV BND1      x_21_1  
 UP BND1      w_21_1    4.2187029162663148e-02
 BV BND1      x_21_2  
 UP BND1      w_21_2    4.2187029162663148e-02
 BV BND1      x_21_3  
 UP BND1      w_21_3    4.2187029162663148e-02
 BV BND1      x_21_4  
 UP BND1      w_21_4    4.2187029162663148e-02
 BV BND1      x_21_5  
 UP BND1      w_21_5    4.2187029162663148e-02
 BV BND1      x_21_6  
 UP BND1      w_21_6    4.2187029162663148e-02
 BV BND1      x_21_7  
 UP BND1      w_21_7    4.2187029162663148e-02
 BV BND1      x_21_8  
 UP BND1      w_21_8    4.2187029162663148e-02
 BV BND1      x_21_9  
 UP BND1      w_21_9    4.2187029162663148e-02
 BV BND1      x_21_10 
 UP BND1      w_21_10   4.2187029162663148e-02
 BV BND1      x_21_11 
 UP BND1      w_21_11   4.2187029162663148e-02
 BV BND1      x_21_12 
 UP BND1      w_21_12   4.2187029162663148e-02
 BV BND1      x_21_13 
 UP BND1      w_21_13   4.2187029162663148e-02
 BV BND1      x_21_14 
 UP BND1      w_21_14   4.2187029162663148e-02
 BV BND1      x_21_15 
 UP BND1      w_21_15   4.2187029162663148e-02
 UP BND1      rho_21    1
 BV BND1      x_16_0  
 UP BND1      w_16_0    4.2187029162663148e-02
 BV BND1      x_16_1  
 UP BND1      w_16_1    4.2187029162663148e-02
 BV BND1      x_16_2  
 UP BND1      w_16_2    4.2187029162663148e-02
 BV BND1      x_16_3  
 UP BND1      w_16_3    4.2187029162663148e-02
 BV BND1      x_16_4  
 UP BND1      w_16_4    4.2187029162663148e-02
 BV BND1      x_16_5  
 UP BND1      w_16_5    4.2187029162663148e-02
 BV BND1      x_16_6  
 UP BND1      w_16_6    4.2187029162663148e-02
 BV BND1      x_16_7  
 UP BND1      w_16_7    4.2187029162663148e-02
 BV BND1      x_16_8  
 UP BND1      w_16_8    4.2187029162663148e-02
 BV BND1      x_16_9  
 UP BND1      w_16_9    4.2187029162663148e-02
 BV BND1      x_16_10 
 UP BND1      w_16_10   4.2187029162663148e-02
 BV BND1      x_16_11 
 UP BND1      w_16_11   4.2187029162663148e-02
 BV BND1      x_16_12 
 UP BND1      w_16_12   4.2187029162663148e-02
 UP BND1      rho_16    1
 BV BND1      x_20_0  
 UP BND1      w_20_0    4.2187029162663148e-02
 BV BND1      x_20_1  
 UP BND1      w_20_1    4.2187029162663148e-02
 BV BND1      x_20_2  
 UP BND1      w_20_2    4.2187029162663148e-02
 BV BND1      x_20_3  
 UP BND1      w_20_3    4.2187029162663148e-02
 BV BND1      x_20_4  
 UP BND1      w_20_4    4.2187029162663148e-02
 BV BND1      x_20_5  
 UP BND1      w_20_5    4.2187029162663148e-02
 BV BND1      x_20_6  
 UP BND1      w_20_6    4.2187029162663148e-02
 BV BND1      x_20_7  
 UP BND1      w_20_7    4.2187029162663148e-02
 BV BND1      x_20_8  
 UP BND1      w_20_8    4.2187029162663148e-02
 BV BND1      x_20_9  
 UP BND1      w_20_9    4.2187029162663148e-02
 BV BND1      x_20_10 
 UP BND1      w_20_10   4.2187029162663148e-02
 BV BND1      x_20_11 
 UP BND1      w_20_11   4.2187029162663148e-02
 BV BND1      x_20_12 
 UP BND1      w_20_12   4.2187029162663148e-02
 UP BND1      rho_20    1
 BV BND1      x_32_0  
 UP BND1      w_32_0    4.2187029162663148e-02
 BV BND1      x_32_1  
 UP BND1      w_32_1    4.2187029162663148e-02
 BV BND1      x_32_2  
 UP BND1      w_32_2    4.2187029162663148e-02
 BV BND1      x_32_3  
 UP BND1      w_32_3    4.2187029162663148e-02
 BV BND1      x_32_4  
 UP BND1      w_32_4    4.2187029162663148e-02
 BV BND1      x_32_5  
 UP BND1      w_32_5    4.2187029162663148e-02
 BV BND1      x_32_6  
 UP BND1      w_32_6    4.2187029162663148e-02
 BV BND1      x_32_7  
 UP BND1      w_32_7    4.2187029162663148e-02
 BV BND1      x_32_8  
 UP BND1      w_32_8    4.2187029162663148e-02
 BV BND1      x_32_9  
 UP BND1      w_32_9    4.2187029162663148e-02
 BV BND1      x_32_10 
 UP BND1      w_32_10   4.2187029162663148e-02
 BV BND1      x_32_11 
 UP BND1      w_32_11   4.2187029162663148e-02
 BV BND1      x_32_12 
 UP BND1      w_32_12   4.2187029162663148e-02
 UP BND1      rho_32    1
 BV BND1      x_33_0  
 UP BND1      w_33_0    4.2187029162663148e-02
 BV BND1      x_33_1  
 UP BND1      w_33_1    4.2187029162663148e-02
 BV BND1      x_33_2  
 UP BND1      w_33_2    4.2187029162663148e-02
 BV BND1      x_33_3  
 UP BND1      w_33_3    4.2187029162663148e-02
 BV BND1      x_33_4  
 UP BND1      w_33_4    4.2187029162663148e-02
 BV BND1      x_33_5  
 UP BND1      w_33_5    4.2187029162663148e-02
 BV BND1      x_33_6  
 UP BND1      w_33_6    4.2187029162663148e-02
 BV BND1      x_33_7  
 UP BND1      w_33_7    4.2187029162663148e-02
 BV BND1      x_33_8  
 UP BND1      w_33_8    4.2187029162663148e-02
 BV BND1      x_33_9  
 UP BND1      w_33_9    4.2187029162663148e-02
 BV BND1      x_33_10 
 UP BND1      w_33_10   4.2187029162663148e-02
 BV BND1      x_33_11 
 UP BND1      w_33_11   4.2187029162663148e-02
 BV BND1      x_33_12 
 UP BND1      w_33_12   4.2187029162663148e-02
 BV BND1      x_33_13 
 UP BND1      w_33_13   4.2187029162663148e-02
 BV BND1      x_33_14 
 UP BND1      w_33_14   4.2187029162663148e-02
 BV BND1      x_33_15 
 UP BND1      w_33_15   4.2187029162663148e-02
 BV BND1      x_33_16 
 UP BND1      w_33_16   4.2187029162663148e-02
 UP BND1      rho_33    1
 UP BND1      a_28_23   1
 UP BND1      a_28_31   1
 UP BND1      a_28_21   1
 UP BND1      a_28_16   1
 UP BND1      a_28_20   1
 UP BND1      a_28_32   1
 UP BND1      a_28_33   1
 UP BND1      a_23_31   1
 UP BND1      a_23_21   1
 UP BND1      a_23_16   1
 UP BND1      a_23_20   1
 UP BND1      a_23_32   1
 UP BND1      a_23_33   1
 UP BND1      a_31_21   1
 UP BND1      a_31_16   1
 UP BND1      a_31_20   1
 UP BND1      a_31_32   1
 UP BND1      a_31_33   1
 UP BND1      a_21_16   1
 UP BND1      a_21_20   1
 UP BND1      a_21_32   1
 UP BND1      a_21_33   1
 UP BND1      a_16_20   1
 UP BND1      a_16_32   1
 UP BND1      a_16_33   1
 UP BND1      a_20_32   1
 UP BND1      a_20_33   1
 UP BND1      a_32_33   1
 BV BND1      service_0_28_0
 BV BND1      service_0_28_1
 BV BND1      service_0_28_2
 BV BND1      service_0_28_3
 BV BND1      service_0_28_4
 BV BND1      service_0_28_5
 BV BND1      service_0_28_6
 BV BND1      service_0_28_7
 BV BND1      service_0_28_8
 BV BND1      service_0_28_9
 BV BND1      service_0_28_10
 BV BND1      service_0_28_11
 BV BND1      service_0_28_12
 BV BND1      service_0_28_14
 BV BND1      service_0_28_15
 BV BND1      service_0_28_16
 BV BND1      service_0_28_17
 BV BND1      service_0_28_18
 BV BND1      service_0_28_19
 BV BND1      service_1_28_0
 BV BND1      service_1_28_1
 BV BND1      service_1_28_2
 BV BND1      service_1_28_3
 BV BND1      service_1_28_4
 BV BND1      service_1_28_5
 BV BND1      service_1_28_6
 BV BND1      service_1_28_7
 BV BND1      service_1_28_8
 BV BND1      service_1_28_9
 BV BND1      service_1_28_10
 BV BND1      service_1_28_11
 BV BND1      service_1_28_12
 BV BND1      service_1_28_14
 BV BND1      service_1_28_15
 BV BND1      service_1_28_16
 BV BND1      service_1_28_17
 BV BND1      service_1_28_18
 BV BND1      service_1_28_19
 BV BND1      service_2_28_0
 BV BND1      service_2_28_1
 BV BND1      service_2_28_2
 BV BND1      service_2_28_3
 BV BND1      service_2_28_4
 BV BND1      service_2_28_5
 BV BND1      service_2_28_6
 BV BND1      service_2_28_7
 BV BND1      service_2_28_8
 BV BND1      service_2_28_9
 BV BND1      service_2_28_10
 BV BND1      service_2_28_11
 BV BND1      service_2_28_12
 BV BND1      service_2_28_14
 BV BND1      service_2_28_15
 BV BND1      service_2_28_16
 BV BND1      service_2_28_17
 BV BND1      service_2_28_18
 BV BND1      service_2_28_19
 BV BND1      service_0_23_0
 BV BND1      service_0_23_1
 BV BND1      service_0_23_2
 BV BND1      service_0_23_3
 BV BND1      service_0_23_4
 BV BND1      service_0_23_5
 BV BND1      service_0_23_6
 BV BND1      service_0_23_8
 BV BND1      service_0_23_9
 BV BND1      service_0_23_10
 BV BND1      service_0_23_11
 BV BND1      service_1_23_0
 BV BND1      service_1_23_1
 BV BND1      service_1_23_2
 BV BND1      service_1_23_3
 BV BND1      service_1_23_4
 BV BND1      service_1_23_5
 BV BND1      service_1_23_6
 BV BND1      service_1_23_8
 BV BND1      service_1_23_9
 BV BND1      service_1_23_10
 BV BND1      service_1_23_11
 BV BND1      service_2_23_0
 BV BND1      service_2_23_1
 BV BND1      service_2_23_2
 BV BND1      service_2_23_3
 BV BND1      service_2_23_4
 BV BND1      service_2_23_5
 BV BND1      service_2_23_6
 BV BND1      service_2_23_8
 BV BND1      service_2_23_9
 BV BND1      service_2_23_10
 BV BND1      service_2_23_11
 BV BND1      service_0_31_0
 BV BND1      service_0_31_1
 BV BND1      service_0_31_3
 BV BND1      service_0_31_4
 BV BND1      service_0_31_5
 BV BND1      service_0_31_6
 BV BND1      service_0_31_7
 BV BND1      service_0_31_8
 BV BND1      service_0_31_9
 BV BND1      service_0_31_10
 BV BND1      service_0_31_11
 BV BND1      service_0_31_12
 BV BND1      service_1_31_0
 BV BND1      service_1_31_1
 BV BND1      service_1_31_3
 BV BND1      service_1_31_4
 BV BND1      service_1_31_5
 BV BND1      service_1_31_6
 BV BND1      service_1_31_7
 BV BND1      service_1_31_8
 BV BND1      service_1_31_9
 BV BND1      service_1_31_10
 BV BND1      service_1_31_11
 BV BND1      service_1_31_12
 BV BND1      service_2_31_0
 BV BND1      service_2_31_1
 BV BND1      service_2_31_3
 BV BND1      service_2_31_4
 BV BND1      service_2_31_5
 BV BND1      service_2_31_6
 BV BND1      service_2_31_7
 BV BND1      service_2_31_8
 BV BND1      service_2_31_9
 BV BND1      service_2_31_10
 BV BND1      service_2_31_11
 BV BND1      service_2_31_12
 BV BND1      service_0_21_0
 BV BND1      service_0_21_2
 BV BND1      service_0_21_3
 BV BND1      service_0_21_4
 BV BND1      service_0_21_5
 BV BND1      service_0_21_6
 BV BND1      service_0_21_7
 BV BND1      service_0_21_8
 BV BND1      service_0_21_9
 BV BND1      service_0_21_10
 BV BND1      service_0_21_11
 BV BND1      service_0_21_12
 BV BND1      service_0_21_13
 BV BND1      service_0_21_14
 BV BND1      service_0_21_15
 BV BND1      service_1_21_0
 BV BND1      service_1_21_2
 BV BND1      service_1_21_3
 BV BND1      service_1_21_4
 BV BND1      service_1_21_5
 BV BND1      service_1_21_6
 BV BND1      service_1_21_7
 BV BND1      service_1_21_8
 BV BND1      service_1_21_9
 BV BND1      service_1_21_10
 BV BND1      service_1_21_11
 BV BND1      service_1_21_12
 BV BND1      service_1_21_13
 BV BND1      service_1_21_14
 BV BND1      service_1_21_15
 BV BND1      service_2_21_0
 BV BND1      service_2_21_2
 BV BND1      service_2_21_3
 BV BND1      service_2_21_4
 BV BND1      service_2_21_5
 BV BND1      service_2_21_6
 BV BND1      service_2_21_7
 BV BND1      service_2_21_8
 BV BND1      service_2_21_9
 BV BND1      service_2_21_10
 BV BND1      service_2_21_11
 BV BND1      service_2_21_12
 BV BND1      service_2_21_13
 BV BND1      service_2_21_14
 BV BND1      service_2_21_15
 BV BND1      service_0_16_0
 BV BND1      service_0_16_2
 BV BND1      service_0_16_3
 BV BND1      service_0_16_4
 BV BND1      service_0_16_5
 BV BND1      service_0_16_6
 BV BND1      service_0_16_7
 BV BND1      service_0_16_8
 BV BND1      service_0_16_9
 BV BND1      service_0_16_10
 BV BND1      service_0_16_11
 BV BND1      service_0_16_12
 BV BND1      service_1_16_0
 BV BND1      service_1_16_2
 BV BND1      service_1_16_3
 BV BND1      service_1_16_4
 BV BND1      service_1_16_5
 BV BND1      service_1_16_6
 BV BND1      service_1_16_7
 BV BND1      service_1_16_8
 BV BND1      service_1_16_9
 BV BND1      service_1_16_10
 BV BND1      service_1_16_11
 BV BND1      service_1_16_12
 BV BND1      service_2_16_0
 BV BND1      service_2_16_2
 BV BND1      service_2_16_3
 BV BND1      service_2_16_4
 BV BND1      service_2_16_5
 BV BND1      service_2_16_6
 BV BND1      service_2_16_7
 BV BND1      service_2_16_8
 BV BND1      service_2_16_9
 BV BND1      service_2_16_10
 BV BND1      service_2_16_11
 BV BND1      service_2_16_12
 BV BND1      service_0_20_0
 BV BND1      service_0_20_1
 BV BND1      service_0_20_2
 BV BND1      service_0_20_3
 BV BND1      service_0_20_4
 BV BND1      service_0_20_5
 BV BND1      service_0_20_6
 BV BND1      service_0_20_7
 BV BND1      service_0_20_8
 BV BND1      service_0_20_10
 BV BND1      service_0_20_11
 BV BND1      service_0_20_12
 BV BND1      service_1_20_0
 BV BND1      service_1_20_1
 BV BND1      service_1_20_2
 BV BND1      service_1_20_3
 BV BND1      service_1_20_4
 BV BND1      service_1_20_5
 BV BND1      service_1_20_6
 BV BND1      service_1_20_7
 BV BND1      service_1_20_8
 BV BND1      service_1_20_10
 BV BND1      service_1_20_11
 BV BND1      service_1_20_12
 BV BND1      service_2_20_0
 BV BND1      service_2_20_1
 BV BND1      service_2_20_2
 BV BND1      service_2_20_3
 BV BND1      service_2_20_4
 BV BND1      service_2_20_5
 BV BND1      service_2_20_6
 BV BND1      service_2_20_7
 BV BND1      service_2_20_8
 BV BND1      service_2_20_10
 BV BND1      service_2_20_11
 BV BND1      service_2_20_12
 BV BND1      service_0_32_1
 BV BND1      service_0_32_2
 BV BND1      service_0_32_3
 BV BND1      service_0_32_4
 BV BND1      service_0_32_5
 BV BND1      service_0_32_6
 BV BND1      service_0_32_7
 BV BND1      service_0_32_8
 BV BND1      service_0_32_9
 BV BND1      service_0_32_10
 BV BND1      service_0_32_11
 BV BND1      service_0_32_12
 BV BND1      service_1_32_1
 BV BND1      service_1_32_2
 BV BND1      service_1_32_3
 BV BND1      service_1_32_4
 BV BND1      service_1_32_5
 BV BND1      service_1_32_6
 BV BND1      service_1_32_7
 BV BND1      service_1_32_8
 BV BND1      service_1_32_9
 BV BND1      service_1_32_10
 BV BND1      service_1_32_11
 BV BND1      service_1_32_12
 BV BND1      service_2_32_1
 BV BND1      service_2_32_2
 BV BND1      service_2_32_3
 BV BND1      service_2_32_4
 BV BND1      service_2_32_5
 BV BND1      service_2_32_6
 BV BND1      service_2_32_7
 BV BND1      service_2_32_8
 BV BND1      service_2_32_9
 BV BND1      service_2_32_10
 BV BND1      service_2_32_11
 BV BND1      service_2_32_12
 BV BND1      service_0_33_0
 BV BND1      service_0_33_2
 BV BND1      service_0_33_3
 BV BND1      service_0_33_4
 BV BND1      service_0_33_5
 BV BND1      service_0_33_6
 BV BND1      service_0_33_7
 BV BND1      service_0_33_8
 BV BND1      service_0_33_9
 BV BND1      service_0_33_10
 BV BND1      service_0_33_11
 BV BND1      service_0_33_12
 BV BND1      service_0_33_13
 BV BND1      service_0_33_14
 BV BND1      service_0_33_15
 BV BND1      service_0_33_16
 BV BND1      service_1_33_0
 BV BND1      service_1_33_2
 BV BND1      service_1_33_3
 BV BND1      service_1_33_4
 BV BND1      service_1_33_5
 BV BND1      service_1_33_6
 BV BND1      service_1_33_7
 BV BND1      service_1_33_8
 BV BND1      service_1_33_9
 BV BND1      service_1_33_10
 BV BND1      service_1_33_11
 BV BND1      service_1_33_12
 BV BND1      service_1_33_13
 BV BND1      service_1_33_14
 BV BND1      service_1_33_15
 BV BND1      service_1_33_16
 BV BND1      service_2_33_0
 BV BND1      service_2_33_2
 BV BND1      service_2_33_3
 BV BND1      service_2_33_4
 BV BND1      service_2_33_5
 BV BND1      service_2_33_6
 BV BND1      service_2_33_7
 BV BND1      service_2_33_8
 BV BND1      service_2_33_9
 BV BND1      service_2_33_10
 BV BND1      service_2_33_11
 BV BND1      service_2_33_12
 BV BND1      service_2_33_13
 BV BND1      service_2_33_14
 BV BND1      service_2_33_15
 BV BND1      service_2_33_16
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  12
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  12
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  12
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  12
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  12
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  12
 UP BND1      visit_0_16  1
 UP BND1      order_0_16  12
 UP BND1      visit_0_17  1
 UP BND1      order_0_17  12
 UP BND1      visit_0_18  1
 UP BND1      order_0_18  12
 UP BND1      visit_0_19  1
 UP BND1      order_0_19  12
 UP BND1      visit_0_20  1
 UP BND1      order_0_20  12
 UP BND1      visit_0_21  1
 UP BND1      order_0_21  12
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_0_16
 FX BND1      load_0_0_16  0
 BV BND1      arc_0_0_17
 FX BND1      load_0_0_17  0
 BV BND1      arc_0_0_18
 FX BND1      load_0_0_18  0
 BV BND1      arc_0_0_19
 FX BND1      load_0_0_19  0
 BV BND1      arc_0_0_20
 FX BND1      load_0_0_20  0
 BV BND1      arc_0_0_21
 FX BND1      load_0_0_21  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  20
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  20
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  20
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  20
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  20
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  20
 BV BND1      arc_0_1_16
 UP BND1      load_0_1_16  20
 BV BND1      arc_0_1_17
 UP BND1      load_0_1_17  20
 BV BND1      arc_0_1_18
 UP BND1      load_0_1_18  20
 BV BND1      arc_0_1_19
 UP BND1      load_0_1_19  20
 BV BND1      arc_0_1_20
 UP BND1      load_0_1_20  20
 BV BND1      arc_0_1_21
 UP BND1      load_0_1_21  20
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  20
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  20
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  20
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  20
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  20
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  20
 BV BND1      arc_0_2_16
 UP BND1      load_0_2_16  20
 BV BND1      arc_0_2_17
 UP BND1      load_0_2_17  20
 BV BND1      arc_0_2_18
 UP BND1      load_0_2_18  20
 BV BND1      arc_0_2_19
 UP BND1      load_0_2_19  20
 BV BND1      arc_0_2_20
 UP BND1      load_0_2_20  20
 BV BND1      arc_0_2_21
 UP BND1      load_0_2_21  20
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  20
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  20
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  20
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  20
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  20
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  20
 BV BND1      arc_0_3_16
 UP BND1      load_0_3_16  20
 BV BND1      arc_0_3_17
 UP BND1      load_0_3_17  20
 BV BND1      arc_0_3_18
 UP BND1      load_0_3_18  20
 BV BND1      arc_0_3_19
 UP BND1      load_0_3_19  20
 BV BND1      arc_0_3_20
 UP BND1      load_0_3_20  20
 BV BND1      arc_0_3_21
 UP BND1      load_0_3_21  20
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  20
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  20
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  20
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  20
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  20
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  20
 BV BND1      arc_0_4_16
 UP BND1      load_0_4_16  20
 BV BND1      arc_0_4_17
 UP BND1      load_0_4_17  20
 BV BND1      arc_0_4_18
 UP BND1      load_0_4_18  20
 BV BND1      arc_0_4_19
 UP BND1      load_0_4_19  20
 BV BND1      arc_0_4_20
 UP BND1      load_0_4_20  20
 BV BND1      arc_0_4_21
 UP BND1      load_0_4_21  20
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  20
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  20
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  20
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  20
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  20
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  20
 BV BND1      arc_0_14_16
 UP BND1      load_0_14_16  20
 BV BND1      arc_0_14_17
 UP BND1      load_0_14_17  20
 BV BND1      arc_0_14_18
 UP BND1      load_0_14_18  20
 BV BND1      arc_0_14_19
 UP BND1      load_0_14_19  20
 BV BND1      arc_0_14_20
 UP BND1      load_0_14_20  20
 BV BND1      arc_0_14_21
 UP BND1      load_0_14_21  20
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  20
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  20
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  20
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  20
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  20
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  20
 BV BND1      arc_0_15_16
 UP BND1      load_0_15_16  20
 BV BND1      arc_0_15_17
 UP BND1      load_0_15_17  20
 BV BND1      arc_0_15_18
 UP BND1      load_0_15_18  20
 BV BND1      arc_0_15_19
 UP BND1      load_0_15_19  20
 BV BND1      arc_0_15_20
 UP BND1      load_0_15_20  20
 BV BND1      arc_0_15_21
 UP BND1      load_0_15_21  20
 BV BND1      arc_0_16_0
 UP BND1      load_0_16_0  20
 BV BND1      arc_0_16_1
 UP BND1      load_0_16_1  20
 BV BND1      arc_0_16_2
 UP BND1      load_0_16_2  20
 BV BND1      arc_0_16_3
 UP BND1      load_0_16_3  20
 BV BND1      arc_0_16_4
 UP BND1      load_0_16_4  20
 BV BND1      arc_0_16_14
 UP BND1      load_0_16_14  20
 BV BND1      arc_0_16_15
 UP BND1      load_0_16_15  20
 BV BND1      arc_0_16_17
 UP BND1      load_0_16_17  20
 BV BND1      arc_0_16_18
 UP BND1      load_0_16_18  20
 BV BND1      arc_0_16_19
 UP BND1      load_0_16_19  20
 BV BND1      arc_0_16_20
 UP BND1      load_0_16_20  20
 BV BND1      arc_0_16_21
 UP BND1      load_0_16_21  20
 BV BND1      arc_0_17_0
 UP BND1      load_0_17_0  20
 BV BND1      arc_0_17_1
 UP BND1      load_0_17_1  20
 BV BND1      arc_0_17_2
 UP BND1      load_0_17_2  20
 BV BND1      arc_0_17_3
 UP BND1      load_0_17_3  20
 BV BND1      arc_0_17_4
 UP BND1      load_0_17_4  20
 BV BND1      arc_0_17_14
 UP BND1      load_0_17_14  20
 BV BND1      arc_0_17_15
 UP BND1      load_0_17_15  20
 BV BND1      arc_0_17_16
 UP BND1      load_0_17_16  20
 BV BND1      arc_0_17_18
 UP BND1      load_0_17_18  20
 BV BND1      arc_0_17_19
 UP BND1      load_0_17_19  20
 BV BND1      arc_0_17_20
 UP BND1      load_0_17_20  20
 BV BND1      arc_0_17_21
 UP BND1      load_0_17_21  20
 BV BND1      arc_0_18_0
 UP BND1      load_0_18_0  20
 BV BND1      arc_0_18_1
 UP BND1      load_0_18_1  20
 BV BND1      arc_0_18_2
 UP BND1      load_0_18_2  20
 BV BND1      arc_0_18_3
 UP BND1      load_0_18_3  20
 BV BND1      arc_0_18_4
 UP BND1      load_0_18_4  20
 BV BND1      arc_0_18_14
 UP BND1      load_0_18_14  20
 BV BND1      arc_0_18_15
 UP BND1      load_0_18_15  20
 BV BND1      arc_0_18_16
 UP BND1      load_0_18_16  20
 BV BND1      arc_0_18_17
 UP BND1      load_0_18_17  20
 BV BND1      arc_0_18_19
 UP BND1      load_0_18_19  20
 BV BND1      arc_0_18_20
 UP BND1      load_0_18_20  20
 BV BND1      arc_0_18_21
 UP BND1      load_0_18_21  20
 BV BND1      arc_0_19_0
 UP BND1      load_0_19_0  20
 BV BND1      arc_0_19_1
 UP BND1      load_0_19_1  20
 BV BND1      arc_0_19_2
 UP BND1      load_0_19_2  20
 BV BND1      arc_0_19_3
 UP BND1      load_0_19_3  20
 BV BND1      arc_0_19_4
 UP BND1      load_0_19_4  20
 BV BND1      arc_0_19_14
 UP BND1      load_0_19_14  20
 BV BND1      arc_0_19_15
 UP BND1      load_0_19_15  20
 BV BND1      arc_0_19_16
 UP BND1      load_0_19_16  20
 BV BND1      arc_0_19_17
 UP BND1      load_0_19_17  20
 BV BND1      arc_0_19_18
 UP BND1      load_0_19_18  20
 BV BND1      arc_0_19_20
 UP BND1      load_0_19_20  20
 BV BND1      arc_0_19_21
 UP BND1      load_0_19_21  20
 BV BND1      arc_0_20_0
 UP BND1      load_0_20_0  20
 BV BND1      arc_0_20_1
 UP BND1      load_0_20_1  20
 BV BND1      arc_0_20_2
 UP BND1      load_0_20_2  20
 BV BND1      arc_0_20_3
 UP BND1      load_0_20_3  20
 BV BND1      arc_0_20_4
 UP BND1      load_0_20_4  20
 BV BND1      arc_0_20_14
 UP BND1      load_0_20_14  20
 BV BND1      arc_0_20_15
 UP BND1      load_0_20_15  20
 BV BND1      arc_0_20_16
 UP BND1      load_0_20_16  20
 BV BND1      arc_0_20_17
 UP BND1      load_0_20_17  20
 BV BND1      arc_0_20_18
 UP BND1      load_0_20_18  20
 BV BND1      arc_0_20_19
 UP BND1      load_0_20_19  20
 BV BND1      arc_0_20_21
 UP BND1      load_0_20_21  20
 BV BND1      arc_0_21_0
 UP BND1      load_0_21_0  20
 BV BND1      arc_0_21_1
 UP BND1      load_0_21_1  20
 BV BND1      arc_0_21_2
 UP BND1      load_0_21_2  20
 BV BND1      arc_0_21_3
 UP BND1      load_0_21_3  20
 BV BND1      arc_0_21_4
 UP BND1      load_0_21_4  20
 BV BND1      arc_0_21_14
 UP BND1      load_0_21_14  20
 BV BND1      arc_0_21_15
 UP BND1      load_0_21_15  20
 BV BND1      arc_0_21_16
 UP BND1      load_0_21_16  20
 BV BND1      arc_0_21_17
 UP BND1      load_0_21_17  20
 BV BND1      arc_0_21_18
 UP BND1      load_0_21_18  20
 BV BND1      arc_0_21_19
 UP BND1      load_0_21_19  20
 BV BND1      arc_0_21_20
 UP BND1      load_0_21_20  20
 FX BND1      visit_1_5  1
 UP BND1      order_1_5  13
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  13
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  13
 FX BND1      visit_1_8  1
 UP BND1      order_1_8  13
 FX BND1      visit_1_9  1
 UP BND1      order_1_9  13
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  13
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  13
 UP BND1      visit_1_16  1
 UP BND1      order_1_16  13
 UP BND1      visit_1_17  1
 UP BND1      order_1_17  13
 UP BND1      visit_1_18  1
 UP BND1      order_1_18  13
 UP BND1      visit_1_19  1
 UP BND1      order_1_19  13
 UP BND1      visit_1_20  1
 UP BND1      order_1_20  13
 UP BND1      visit_1_21  1
 UP BND1      order_1_21  13
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_5
 FX BND1      load_1_0_5  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_0_16
 FX BND1      load_1_0_16  0
 BV BND1      arc_1_0_17
 FX BND1      load_1_0_17  0
 BV BND1      arc_1_0_18
 FX BND1      load_1_0_18  0
 BV BND1      arc_1_0_19
 FX BND1      load_1_0_19  0
 BV BND1      arc_1_0_20
 FX BND1      load_1_0_20  0
 BV BND1      arc_1_0_21
 FX BND1      load_1_0_21  0
 BV BND1      arc_1_5_0
 UP BND1      load_1_5_0  25
 BV BND1      arc_1_5_6
 UP BND1      load_1_5_6  25
 BV BND1      arc_1_5_7
 UP BND1      load_1_5_7  25
 BV BND1      arc_1_5_8
 UP BND1      load_1_5_8  25
 BV BND1      arc_1_5_9
 UP BND1      load_1_5_9  25
 BV BND1      arc_1_5_14
 UP BND1      load_1_5_14  25
 BV BND1      arc_1_5_15
 UP BND1      load_1_5_15  25
 BV BND1      arc_1_5_16
 UP BND1      load_1_5_16  25
 BV BND1      arc_1_5_17
 UP BND1      load_1_5_17  25
 BV BND1      arc_1_5_18
 UP BND1      load_1_5_18  25
 BV BND1      arc_1_5_19
 UP BND1      load_1_5_19  25
 BV BND1      arc_1_5_20
 UP BND1      load_1_5_20  25
 BV BND1      arc_1_5_21
 UP BND1      load_1_5_21  25
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  25
 BV BND1      arc_1_6_5
 UP BND1      load_1_6_5  25
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  25
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  25
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  25
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  25
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  25
 BV BND1      arc_1_6_16
 UP BND1      load_1_6_16  25
 BV BND1      arc_1_6_17
 UP BND1      load_1_6_17  25
 BV BND1      arc_1_6_18
 UP BND1      load_1_6_18  25
 BV BND1      arc_1_6_19
 UP BND1      load_1_6_19  25
 BV BND1      arc_1_6_20
 UP BND1      load_1_6_20  25
 BV BND1      arc_1_6_21
 UP BND1      load_1_6_21  25
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  25
 BV BND1      arc_1_7_5
 UP BND1      load_1_7_5  25
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  25
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  25
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  25
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  25
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  25
 BV BND1      arc_1_7_16
 UP BND1      load_1_7_16  25
 BV BND1      arc_1_7_17
 UP BND1      load_1_7_17  25
 BV BND1      arc_1_7_18
 UP BND1      load_1_7_18  25
 BV BND1      arc_1_7_19
 UP BND1      load_1_7_19  25
 BV BND1      arc_1_7_20
 UP BND1      load_1_7_20  25
 BV BND1      arc_1_7_21
 UP BND1      load_1_7_21  25
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  25
 BV BND1      arc_1_8_5
 UP BND1      load_1_8_5  25
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  25
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  25
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  25
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  25
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  25
 BV BND1      arc_1_8_16
 UP BND1      load_1_8_16  25
 BV BND1      arc_1_8_17
 UP BND1      load_1_8_17  25
 BV BND1      arc_1_8_18
 UP BND1      load_1_8_18  25
 BV BND1      arc_1_8_19
 UP BND1      load_1_8_19  25
 BV BND1      arc_1_8_20
 UP BND1      load_1_8_20  25
 BV BND1      arc_1_8_21
 UP BND1      load_1_8_21  25
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  25
 BV BND1      arc_1_9_5
 UP BND1      load_1_9_5  25
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  25
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  25
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  25
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  25
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  25
 BV BND1      arc_1_9_16
 UP BND1      load_1_9_16  25
 BV BND1      arc_1_9_17
 UP BND1      load_1_9_17  25
 BV BND1      arc_1_9_18
 UP BND1      load_1_9_18  25
 BV BND1      arc_1_9_19
 UP BND1      load_1_9_19  25
 BV BND1      arc_1_9_20
 UP BND1      load_1_9_20  25
 BV BND1      arc_1_9_21
 UP BND1      load_1_9_21  25
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  25
 BV BND1      arc_1_14_5
 UP BND1      load_1_14_5  25
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  25
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  25
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  25
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  25
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  25
 BV BND1      arc_1_14_16
 UP BND1      load_1_14_16  25
 BV BND1      arc_1_14_17
 UP BND1      load_1_14_17  25
 BV BND1      arc_1_14_18
 UP BND1      load_1_14_18  25
 BV BND1      arc_1_14_19
 UP BND1      load_1_14_19  25
 BV BND1      arc_1_14_20
 UP BND1      load_1_14_20  25
 BV BND1      arc_1_14_21
 UP BND1      load_1_14_21  25
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  25
 BV BND1      arc_1_15_5
 UP BND1      load_1_15_5  25
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  25
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  25
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  25
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  25
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  25
 BV BND1      arc_1_15_16
 UP BND1      load_1_15_16  25
 BV BND1      arc_1_15_17
 UP BND1      load_1_15_17  25
 BV BND1      arc_1_15_18
 UP BND1      load_1_15_18  25
 BV BND1      arc_1_15_19
 UP BND1      load_1_15_19  25
 BV BND1      arc_1_15_20
 UP BND1      load_1_15_20  25
 BV BND1      arc_1_15_21
 UP BND1      load_1_15_21  25
 BV BND1      arc_1_16_0
 UP BND1      load_1_16_0  25
 BV BND1      arc_1_16_5
 UP BND1      load_1_16_5  25
 BV BND1      arc_1_16_6
 UP BND1      load_1_16_6  25
 BV BND1      arc_1_16_7
 UP BND1      load_1_16_7  25
 BV BND1      arc_1_16_8
 UP BND1      load_1_16_8  25
 BV BND1      arc_1_16_9
 UP BND1      load_1_16_9  25
 BV BND1      arc_1_16_14
 UP BND1      load_1_16_14  25
 BV BND1      arc_1_16_15
 UP BND1      load_1_16_15  25
 BV BND1      arc_1_16_17
 UP BND1      load_1_16_17  25
 BV BND1      arc_1_16_18
 UP BND1      load_1_16_18  25
 BV BND1      arc_1_16_19
 UP BND1      load_1_16_19  25
 BV BND1      arc_1_16_20
 UP BND1      load_1_16_20  25
 BV BND1      arc_1_16_21
 UP BND1      load_1_16_21  25
 BV BND1      arc_1_17_0
 UP BND1      load_1_17_0  25
 BV BND1      arc_1_17_5
 UP BND1      load_1_17_5  25
 BV BND1      arc_1_17_6
 UP BND1      load_1_17_6  25
 BV BND1      arc_1_17_7
 UP BND1      load_1_17_7  25
 BV BND1      arc_1_17_8
 UP BND1      load_1_17_8  25
 BV BND1      arc_1_17_9
 UP BND1      load_1_17_9  25
 BV BND1      arc_1_17_14
 UP BND1      load_1_17_14  25
 BV BND1      arc_1_17_15
 UP BND1      load_1_17_15  25
 BV BND1      arc_1_17_16
 UP BND1      load_1_17_16  25
 BV BND1      arc_1_17_18
 UP BND1      load_1_17_18  25
 BV BND1      arc_1_17_19
 UP BND1      load_1_17_19  25
 BV BND1      arc_1_17_20
 UP BND1      load_1_17_20  25
 BV BND1      arc_1_17_21
 UP BND1      load_1_17_21  25
 BV BND1      arc_1_18_0
 UP BND1      load_1_18_0  25
 BV BND1      arc_1_18_5
 UP BND1      load_1_18_5  25
 BV BND1      arc_1_18_6
 UP BND1      load_1_18_6  25
 BV BND1      arc_1_18_7
 UP BND1      load_1_18_7  25
 BV BND1      arc_1_18_8
 UP BND1      load_1_18_8  25
 BV BND1      arc_1_18_9
 UP BND1      load_1_18_9  25
 BV BND1      arc_1_18_14
 UP BND1      load_1_18_14  25
 BV BND1      arc_1_18_15
 UP BND1      load_1_18_15  25
 BV BND1      arc_1_18_16
 UP BND1      load_1_18_16  25
 BV BND1      arc_1_18_17
 UP BND1      load_1_18_17  25
 BV BND1      arc_1_18_19
 UP BND1      load_1_18_19  25
 BV BND1      arc_1_18_20
 UP BND1      load_1_18_20  25
 BV BND1      arc_1_18_21
 UP BND1      load_1_18_21  25
 BV BND1      arc_1_19_0
 UP BND1      load_1_19_0  25
 BV BND1      arc_1_19_5
 UP BND1      load_1_19_5  25
 BV BND1      arc_1_19_6
 UP BND1      load_1_19_6  25
 BV BND1      arc_1_19_7
 UP BND1      load_1_19_7  25
 BV BND1      arc_1_19_8
 UP BND1      load_1_19_8  25
 BV BND1      arc_1_19_9
 UP BND1      load_1_19_9  25
 BV BND1      arc_1_19_14
 UP BND1      load_1_19_14  25
 BV BND1      arc_1_19_15
 UP BND1      load_1_19_15  25
 BV BND1      arc_1_19_16
 UP BND1      load_1_19_16  25
 BV BND1      arc_1_19_17
 UP BND1      load_1_19_17  25
 BV BND1      arc_1_19_18
 UP BND1      load_1_19_18  25
 BV BND1      arc_1_19_20
 UP BND1      load_1_19_20  25
 BV BND1      arc_1_19_21
 UP BND1      load_1_19_21  25
 BV BND1      arc_1_20_0
 UP BND1      load_1_20_0  25
 BV BND1      arc_1_20_5
 UP BND1      load_1_20_5  25
 BV BND1      arc_1_20_6
 UP BND1      load_1_20_6  25
 BV BND1      arc_1_20_7
 UP BND1      load_1_20_7  25
 BV BND1      arc_1_20_8
 UP BND1      load_1_20_8  25
 BV BND1      arc_1_20_9
 UP BND1      load_1_20_9  25
 BV BND1      arc_1_20_14
 UP BND1      load_1_20_14  25
 BV BND1      arc_1_20_15
 UP BND1      load_1_20_15  25
 BV BND1      arc_1_20_16
 UP BND1      load_1_20_16  25
 BV BND1      arc_1_20_17
 UP BND1      load_1_20_17  25
 BV BND1      arc_1_20_18
 UP BND1      load_1_20_18  25
 BV BND1      arc_1_20_19
 UP BND1      load_1_20_19  25
 BV BND1      arc_1_20_21
 UP BND1      load_1_20_21  25
 BV BND1      arc_1_21_0
 UP BND1      load_1_21_0  25
 BV BND1      arc_1_21_5
 UP BND1      load_1_21_5  25
 BV BND1      arc_1_21_6
 UP BND1      load_1_21_6  25
 BV BND1      arc_1_21_7
 UP BND1      load_1_21_7  25
 BV BND1      arc_1_21_8
 UP BND1      load_1_21_8  25
 BV BND1      arc_1_21_9
 UP BND1      load_1_21_9  25
 BV BND1      arc_1_21_14
 UP BND1      load_1_21_14  25
 BV BND1      arc_1_21_15
 UP BND1      load_1_21_15  25
 BV BND1      arc_1_21_16
 UP BND1      load_1_21_16  25
 BV BND1      arc_1_21_17
 UP BND1      load_1_21_17  25
 BV BND1      arc_1_21_18
 UP BND1      load_1_21_18  25
 BV BND1      arc_1_21_19
 UP BND1      load_1_21_19  25
 BV BND1      arc_1_21_20
 UP BND1      load_1_21_20  25
 FX BND1      visit_2_10  1
 UP BND1      order_2_10  12
 FX BND1      visit_2_11  1
 UP BND1      order_2_11  12
 FX BND1      visit_2_12  1
 UP BND1      order_2_12  12
 FX BND1      visit_2_13  1
 UP BND1      order_2_13  12
 UP BND1      visit_2_14  1
 UP BND1      order_2_14  12
 UP BND1      visit_2_15  1
 UP BND1      order_2_15  12
 UP BND1      visit_2_16  1
 UP BND1      order_2_16  12
 UP BND1      visit_2_17  1
 UP BND1      order_2_17  12
 UP BND1      visit_2_18  1
 UP BND1      order_2_18  12
 UP BND1      visit_2_19  1
 UP BND1      order_2_19  12
 UP BND1      visit_2_20  1
 UP BND1      order_2_20  12
 UP BND1      visit_2_21  1
 UP BND1      order_2_21  12
 BV BND1      arc_2_0_0
 FX BND1      load_2_0_0  0
 BV BND1      arc_2_0_10
 FX BND1      load_2_0_10  0
 BV BND1      arc_2_0_11
 FX BND1      load_2_0_11  0
 BV BND1      arc_2_0_12
 FX BND1      load_2_0_12  0
 BV BND1      arc_2_0_13
 FX BND1      load_2_0_13  0
 BV BND1      arc_2_0_14
 FX BND1      load_2_0_14  0
 BV BND1      arc_2_0_15
 FX BND1      load_2_0_15  0
 BV BND1      arc_2_0_16
 FX BND1      load_2_0_16  0
 BV BND1      arc_2_0_17
 FX BND1      load_2_0_17  0
 BV BND1      arc_2_0_18
 FX BND1      load_2_0_18  0
 BV BND1      arc_2_0_19
 FX BND1      load_2_0_19  0
 BV BND1      arc_2_0_20
 FX BND1      load_2_0_20  0
 BV BND1      arc_2_0_21
 FX BND1      load_2_0_21  0
 BV BND1      arc_2_10_0
 UP BND1      load_2_10_0  30
 BV BND1      arc_2_10_11
 UP BND1      load_2_10_11  30
 BV BND1      arc_2_10_12
 UP BND1      load_2_10_12  30
 BV BND1      arc_2_10_13
 UP BND1      load_2_10_13  30
 BV BND1      arc_2_10_14
 UP BND1      load_2_10_14  30
 BV BND1      arc_2_10_15
 UP BND1      load_2_10_15  30
 BV BND1      arc_2_10_16
 UP BND1      load_2_10_16  30
 BV BND1      arc_2_10_17
 UP BND1      load_2_10_17  30
 BV BND1      arc_2_10_18
 UP BND1      load_2_10_18  30
 BV BND1      arc_2_10_19
 UP BND1      load_2_10_19  30
 BV BND1      arc_2_10_20
 UP BND1      load_2_10_20  30
 BV BND1      arc_2_10_21
 UP BND1      load_2_10_21  30
 BV BND1      arc_2_11_0
 UP BND1      load_2_11_0  30
 BV BND1      arc_2_11_10
 UP BND1      load_2_11_10  30
 BV BND1      arc_2_11_12
 UP BND1      load_2_11_12  30
 BV BND1      arc_2_11_13
 UP BND1      load_2_11_13  30
 BV BND1      arc_2_11_14
 UP BND1      load_2_11_14  30
 BV BND1      arc_2_11_15
 UP BND1      load_2_11_15  30
 BV BND1      arc_2_11_16
 UP BND1      load_2_11_16  30
 BV BND1      arc_2_11_17
 UP BND1      load_2_11_17  30
 BV BND1      arc_2_11_18
 UP BND1      load_2_11_18  30
 BV BND1      arc_2_11_19
 UP BND1      load_2_11_19  30
 BV BND1      arc_2_11_20
 UP BND1      load_2_11_20  30
 BV BND1      arc_2_11_21
 UP BND1      load_2_11_21  30
 BV BND1      arc_2_12_0
 UP BND1      load_2_12_0  30
 BV BND1      arc_2_12_10
 UP BND1      load_2_12_10  30
 BV BND1      arc_2_12_11
 UP BND1      load_2_12_11  30
 BV BND1      arc_2_12_13
 UP BND1      load_2_12_13  30
 BV BND1      arc_2_12_14
 UP BND1      load_2_12_14  30
 BV BND1      arc_2_12_15
 UP BND1      load_2_12_15  30
 BV BND1      arc_2_12_16
 UP BND1      load_2_12_16  30
 BV BND1      arc_2_12_17
 UP BND1      load_2_12_17  30
 BV BND1      arc_2_12_18
 UP BND1      load_2_12_18  30
 BV BND1      arc_2_12_19
 UP BND1      load_2_12_19  30
 BV BND1      arc_2_12_20
 UP BND1      load_2_12_20  30
 BV BND1      arc_2_12_21
 UP BND1      load_2_12_21  30
 BV BND1      arc_2_13_0
 UP BND1      load_2_13_0  30
 BV BND1      arc_2_13_10
 UP BND1      load_2_13_10  30
 BV BND1      arc_2_13_11
 UP BND1      load_2_13_11  30
 BV BND1      arc_2_13_12
 UP BND1      load_2_13_12  30
 BV BND1      arc_2_13_14
 UP BND1      load_2_13_14  30
 BV BND1      arc_2_13_15
 UP BND1      load_2_13_15  30
 BV BND1      arc_2_13_16
 UP BND1      load_2_13_16  30
 BV BND1      arc_2_13_17
 UP BND1      load_2_13_17  30
 BV BND1      arc_2_13_18
 UP BND1      load_2_13_18  30
 BV BND1      arc_2_13_19
 UP BND1      load_2_13_19  30
 BV BND1      arc_2_13_20
 UP BND1      load_2_13_20  30
 BV BND1      arc_2_13_21
 UP BND1      load_2_13_21  30
 BV BND1      arc_2_14_0
 UP BND1      load_2_14_0  30
 BV BND1      arc_2_14_10
 UP BND1      load_2_14_10  30
 BV BND1      arc_2_14_11
 UP BND1      load_2_14_11  30
 BV BND1      arc_2_14_12
 UP BND1      load_2_14_12  30
 BV BND1      arc_2_14_13
 UP BND1      load_2_14_13  30
 BV BND1      arc_2_14_15
 UP BND1      load_2_14_15  30
 BV BND1      arc_2_14_16
 UP BND1      load_2_14_16  30
 BV BND1      arc_2_14_17
 UP BND1      load_2_14_17  30
 BV BND1      arc_2_14_18
 UP BND1      load_2_14_18  30
 BV BND1      arc_2_14_19
 UP BND1      load_2_14_19  30
 BV BND1      arc_2_14_20
 UP BND1      load_2_14_20  30
 BV BND1      arc_2_14_21
 UP BND1      load_2_14_21  30
 BV BND1      arc_2_15_0
 UP BND1      load_2_15_0  30
 BV BND1      arc_2_15_10
 UP BND1      load_2_15_10  30
 BV BND1      arc_2_15_11
 UP BND1      load_2_15_11  30
 BV BND1      arc_2_15_12
 UP BND1      load_2_15_12  30
 BV BND1      arc_2_15_13
 UP BND1      load_2_15_13  30
 BV BND1      arc_2_15_14
 UP BND1      load_2_15_14  30
 BV BND1      arc_2_15_16
 UP BND1      load_2_15_16  30
 BV BND1      arc_2_15_17
 UP BND1      load_2_15_17  30
 BV BND1      arc_2_15_18
 UP BND1      load_2_15_18  30
 BV BND1      arc_2_15_19
 UP BND1      load_2_15_19  30
 BV BND1      arc_2_15_20
 UP BND1      load_2_15_20  30
 BV BND1      arc_2_15_21
 UP BND1      load_2_15_21  30
 BV BND1      arc_2_16_0
 UP BND1      load_2_16_0  30
 BV BND1      arc_2_16_10
 UP BND1      load_2_16_10  30
 BV BND1      arc_2_16_11
 UP BND1      load_2_16_11  30
 BV BND1      arc_2_16_12
 UP BND1      load_2_16_12  30
 BV BND1      arc_2_16_13
 UP BND1      load_2_16_13  30
 BV BND1      arc_2_16_14
 UP BND1      load_2_16_14  30
 BV BND1      arc_2_16_15
 UP BND1      load_2_16_15  30
 BV BND1      arc_2_16_17
 UP BND1      load_2_16_17  30
 BV BND1      arc_2_16_18
 UP BND1      load_2_16_18  30
 BV BND1      arc_2_16_19
 UP BND1      load_2_16_19  30
 BV BND1      arc_2_16_20
 UP BND1      load_2_16_20  30
 BV BND1      arc_2_16_21
 UP BND1      load_2_16_21  30
 BV BND1      arc_2_17_0
 UP BND1      load_2_17_0  30
 BV BND1      arc_2_17_10
 UP BND1      load_2_17_10  30
 BV BND1      arc_2_17_11
 UP BND1      load_2_17_11  30
 BV BND1      arc_2_17_12
 UP BND1      load_2_17_12  30
 BV BND1      arc_2_17_13
 UP BND1      load_2_17_13  30
 BV BND1      arc_2_17_14
 UP BND1      load_2_17_14  30
 BV BND1      arc_2_17_15
 UP BND1      load_2_17_15  30
 BV BND1      arc_2_17_16
 UP BND1      load_2_17_16  30
 BV BND1      arc_2_17_18
 UP BND1      load_2_17_18  30
 BV BND1      arc_2_17_19
 UP BND1      load_2_17_19  30
 BV BND1      arc_2_17_20
 UP BND1      load_2_17_20  30
 BV BND1      arc_2_17_21
 UP BND1      load_2_17_21  30
 BV BND1      arc_2_18_0
 UP BND1      load_2_18_0  30
 BV BND1      arc_2_18_10
 UP BND1      load_2_18_10  30
 BV BND1      arc_2_18_11
 UP BND1      load_2_18_11  30
 BV BND1      arc_2_18_12
 UP BND1      load_2_18_12  30
 BV BND1      arc_2_18_13
 UP BND1      load_2_18_13  30
 BV BND1      arc_2_18_14
 UP BND1      load_2_18_14  30
 BV BND1      arc_2_18_15
 UP BND1      load_2_18_15  30
 BV BND1      arc_2_18_16
 UP BND1      load_2_18_16  30
 BV BND1      arc_2_18_17
 UP BND1      load_2_18_17  30
 BV BND1      arc_2_18_19
 UP BND1      load_2_18_19  30
 BV BND1      arc_2_18_20
 UP BND1      load_2_18_20  30
 BV BND1      arc_2_18_21
 UP BND1      load_2_18_21  30
 BV BND1      arc_2_19_0
 UP BND1      load_2_19_0  30
 BV BND1      arc_2_19_10
 UP BND1      load_2_19_10  30
 BV BND1      arc_2_19_11
 UP BND1      load_2_19_11  30
 BV BND1      arc_2_19_12
 UP BND1      load_2_19_12  30
 BV BND1      arc_2_19_13
 UP BND1      load_2_19_13  30
 BV BND1      arc_2_19_14
 UP BND1      load_2_19_14  30
 BV BND1      arc_2_19_15
 UP BND1      load_2_19_15  30
 BV BND1      arc_2_19_16
 UP BND1      load_2_19_16  30
 BV BND1      arc_2_19_17
 UP BND1      load_2_19_17  30
 BV BND1      arc_2_19_18
 UP BND1      load_2_19_18  30
 BV BND1      arc_2_19_20
 UP BND1      load_2_19_20  30
 BV BND1      arc_2_19_21
 UP BND1      load_2_19_21  30
 BV BND1      arc_2_20_0
 UP BND1      load_2_20_0  30
 BV BND1      arc_2_20_10
 UP BND1      load_2_20_10  30
 BV BND1      arc_2_20_11
 UP BND1      load_2_20_11  30
 BV BND1      arc_2_20_12
 UP BND1      load_2_20_12  30
 BV BND1      arc_2_20_13
 UP BND1      load_2_20_13  30
 BV BND1      arc_2_20_14
 UP BND1      load_2_20_14  30
 BV BND1      arc_2_20_15
 UP BND1      load_2_20_15  30
 BV BND1      arc_2_20_16
 UP BND1      load_2_20_16  30
 BV BND1      arc_2_20_17
 UP BND1      load_2_20_17  30
 BV BND1      arc_2_20_18
 UP BND1      load_2_20_18  30
 BV BND1      arc_2_20_19
 UP BND1      load_2_20_19  30
 BV BND1      arc_2_20_21
 UP BND1      load_2_20_21  30
 BV BND1      arc_2_21_0
 UP BND1      load_2_21_0  30
 BV BND1      arc_2_21_10
 UP BND1      load_2_21_10  30
 BV BND1      arc_2_21_11
 UP BND1      load_2_21_11  30
 BV BND1      arc_2_21_12
 UP BND1      load_2_21_12  30
 BV BND1      arc_2_21_13
 UP BND1      load_2_21_13  30
 BV BND1      arc_2_21_14
 UP BND1      load_2_21_14  30
 BV BND1      arc_2_21_15
 UP BND1      load_2_21_15  30
 BV BND1      arc_2_21_16
 UP BND1      load_2_21_16  30
 BV BND1      arc_2_21_17
 UP BND1      load_2_21_17  30
 BV BND1      arc_2_21_18
 UP BND1      load_2_21_18  30
 BV BND1      arc_2_21_19
 UP BND1      load_2_21_19  30
 BV BND1      arc_2_21_20
 UP BND1      load_2_21_20  30
ENDATA
