* Signature: 0xcaf3b9b608a3780c
NAME R160_physical_neighborhood
ROWS
 N  OBJ
 G  product_lb_0
 L  product_ub_1
 G  product_lb_2
 L  product_ub_3
 G  product_lb_4
 L  product_ub_5
 G  product_lb_6
 L  product_ub_7
 G  product_lb_8
 L  product_ub_9
 G  product_lb_10
 L  product_ub_11
 G  product_lb_12
 L  product_ub_13
 G  product_lb_14
 L  product_ub_15
 G  product_lb_16
 L  product_ub_17
 G  product_lb_18
 L  product_ub_19
 G  product_lb_20
 L  product_ub_21
 G  product_lb_22
 L  product_ub_23
 G  product_lb_24
 L  product_ub_25
 G  product_lb_26
 L  product_ub_27
 G  product_lb_28
 L  product_ub_29
 G  product_lb_30
 L  product_ub_31
 E  onehot_1_32
 E  normalized_mass_1_33
 E  normalized_ratio_1_34
 G  product_lb_35
 L  product_ub_36
 G  product_lb_37
 L  product_ub_38
 E  onehot_2_39
 E  normalized_mass_2_40
 E  normalized_ratio_2_41
 G  product_lb_42
 L  product_ub_43
 G  product_lb_44
 L  product_ub_45
 G  product_lb_46
 L  product_ub_47
 G  product_lb_48
 L  product_ub_49
 G  product_lb_50
 L  product_ub_51
 G  product_lb_52
 L  product_ub_53
 G  product_lb_54
 L  product_ub_55
 G  product_lb_56
 L  product_ub_57
 G  product_lb_58
 L  product_ub_59
 G  product_lb_60
 L  product_ub_61
 G  product_lb_62
 L  product_ub_63
 G  product_lb_64
 L  product_ub_65
 G  product_lb_66
 L  product_ub_67
 G  product_lb_68
 L  product_ub_69
 G  product_lb_70
 L  product_ub_71
 G  product_lb_72
 L  product_ub_73
 E  onehot_18_74
 E  normalized_mass_18_75
 E  normalized_ratio_18_76
 G  product_lb_77
 L  product_ub_78
 G  product_lb_79
 L  product_ub_80
 G  product_lb_81
 L  product_ub_82
 G  product_lb_83
 L  product_ub_84
 G  product_lb_85
 L  product_ub_86
 G  product_lb_87
 L  product_ub_88
 G  product_lb_89
 L  product_ub_90
 G  product_lb_91
 L  product_ub_92
 G  product_lb_93
 L  product_ub_94
 G  product_lb_95
 L  product_ub_96
 G  product_lb_97
 L  product_ub_98
 G  product_lb_99
 L  product_ub_100
 G  product_lb_101
 L  product_ub_102
 G  product_lb_103
 L  product_ub_104
 G  product_lb_105
 L  product_ub_106
 G  product_lb_107
 L  product_ub_108
 G  product_lb_109
 L  product_ub_110
 E  onehot_3_111
 E  normalized_mass_3_112
 E  normalized_ratio_3_113
 G  product_lb_114
 L  product_ub_115
 G  product_lb_116
 L  product_ub_117
 G  product_lb_118
 L  product_ub_119
 G  product_lb_120
 L  product_ub_121
 G  product_lb_122
 L  product_ub_123
 G  product_lb_124
 L  product_ub_125
 G  product_lb_126
 L  product_ub_127
 G  product_lb_128
 L  product_ub_129
 G  product_lb_130
 L  product_ub_131
 G  product_lb_132
 L  product_ub_133
 G  product_lb_134
 L  product_ub_135
 G  product_lb_136
 L  product_ub_137
 G  product_lb_138
 L  product_ub_139
 G  product_lb_140
 L  product_ub_141
 G  product_lb_142
 L  product_ub_143
 G  product_lb_144
 L  product_ub_145
 G  product_lb_146
 L  product_ub_147
 E  onehot_17_148
 E  normalized_mass_17_149
 E  normalized_ratio_17_150
 G  product_lb_151
 L  product_ub_152
 G  product_lb_153
 L  product_ub_154
 G  product_lb_155
 L  product_ub_156
 G  product_lb_157
 L  product_ub_158
 G  product_lb_159
 L  product_ub_160
 G  product_lb_161
 L  product_ub_162
 G  product_lb_163
 L  product_ub_164
 G  product_lb_165
 L  product_ub_166
 G  product_lb_167
 L  product_ub_168
 G  product_lb_169
 L  product_ub_170
 G  product_lb_171
 L  product_ub_172
 G  product_lb_173
 L  product_ub_174
 G  product_lb_175
 L  product_ub_176
 G  product_lb_177
 L  product_ub_178
 G  product_lb_179
 L  product_ub_180
 G  product_lb_181
 L  product_ub_182
 E  onehot_4_183
 E  normalized_mass_4_184
 E  normalized_ratio_4_185
 G  product_lb_186
 L  product_ub_187
 G  product_lb_188
 L  product_ub_189
 G  product_lb_190
 L  product_ub_191
 G  product_lb_192
 L  product_ub_193
 G  product_lb_194
 L  product_ub_195
 G  product_lb_196
 L  product_ub_197
 G  product_lb_198
 L  product_ub_199
 G  product_lb_200
 L  product_ub_201
 G  product_lb_202
 L  product_ub_203
 G  product_lb_204
 L  product_ub_205
 G  product_lb_206
 L  product_ub_207
 G  product_lb_208
 L  product_ub_209
 G  product_lb_210
 L  product_ub_211
 G  product_lb_212
 L  product_ub_213
 G  product_lb_214
 L  product_ub_215
 G  product_lb_216
 L  product_ub_217
 E  onehot_11_218
 E  normalized_mass_11_219
 E  normalized_ratio_11_220
 G  product_lb_221
 L  product_ub_222
 G  product_lb_223
 L  product_ub_224
 G  product_lb_225
 L  product_ub_226
 E  onehot_5_227
 E  normalized_mass_5_228
 E  normalized_ratio_5_229
 G  stock_lb_230
 L  stock_ub_231
 L  parent_nonstrict_scope_232
 G  block_pair_pos_233
 G  block_pair_neg_234
 G  block_pair_pos_235
 G  block_pair_neg_236
 G  block_pair_pos_237
 G  block_pair_neg_238
 G  block_pair_pos_239
 G  block_pair_neg_240
 G  block_pair_pos_241
 G  block_pair_neg_242
 G  block_pair_pos_243
 G  block_pair_neg_244
 G  block_pair_pos_245
 G  block_pair_neg_246
 G  block_pair_pos_247
 G  block_pair_neg_248
 G  block_pair_pos_249
 G  block_pair_neg_250
 G  block_pair_pos_251
 G  block_pair_neg_252
 G  block_pair_pos_253
 G  block_pair_neg_254
 G  block_pair_pos_255
 G  block_pair_neg_256
 G  block_pair_pos_257
 G  block_pair_neg_258
 G  block_pair_pos_259
 G  block_pair_neg_260
 G  block_pair_pos_261
 G  block_pair_neg_262
 G  block_pair_pos_263
 G  block_pair_neg_264
 G  block_pair_pos_265
 G  block_pair_neg_266
 G  block_pair_pos_267
 G  block_pair_neg_268
 G  block_pair_pos_269
 G  block_pair_neg_270
 G  block_pair_pos_271
 G  block_pair_neg_272
 G  block_pair_pos_273
 G  block_pair_neg_274
 G  block_pair_pos_275
 G  block_pair_neg_276
 G  block_pair_pos_277
 G  block_pair_neg_278
 G  block_pair_pos_279
 G  block_pair_neg_280
 G  block_pair_pos_281
 G  block_pair_neg_282
 G  block_pair_pos_283
 G  block_pair_neg_284
 G  block_pair_pos_285
 G  block_pair_neg_286
 G  block_pair_pos_287
 G  block_pair_neg_288
 E  normalization_289
 G  full_original_Gini_290
 E  unique_nonzero_owner_291
 E  unique_nonzero_owner_292
 E  unique_nonzero_owner_293
 E  unique_nonzero_owner_294
 E  unique_nonzero_owner_295
 E  unique_nonzero_owner_296
 E  unique_nonzero_owner_297
 E  unique_nonzero_owner_298
 E  unique_nonzero_owner_299
 E  unique_nonzero_owner_300
 E  unique_nonzero_owner_301
 E  unique_nonzero_owner_302
 E  unique_nonzero_owner_303
 E  unique_nonzero_owner_304
 E  unique_nonzero_owner_305
 E  unique_nonzero_owner_306
 E  unique_nonzero_owner_307
 E  unique_nonzero_owner_308
 E  unique_nonzero_owner_309
 E  unique_nonzero_owner_310
 E  unique_nonzero_owner_311
 E  unique_nonzero_owner_312
 E  unique_nonzero_owner_313
 E  unique_nonzero_owner_314
 E  unique_nonzero_owner_315
 E  unique_nonzero_owner_316
 E  unique_nonzero_owner_317
 E  unique_nonzero_owner_318
 E  unique_nonzero_owner_319
 E  unique_nonzero_owner_320
 E  unique_nonzero_owner_321
 E  unique_nonzero_owner_322
 E  unique_nonzero_owner_323
 E  unique_nonzero_owner_324
 E  unique_nonzero_owner_325
 E  unique_nonzero_owner_326
 E  unique_nonzero_owner_327
 E  unique_nonzero_owner_328
 E  unique_nonzero_owner_329
 E  unique_nonzero_owner_330
 E  unique_nonzero_owner_331
 E  unique_nonzero_owner_332
 E  unique_nonzero_owner_333
 E  unique_nonzero_owner_334
 E  unique_nonzero_owner_335
 E  unique_nonzero_owner_336
 E  unique_nonzero_owner_337
 E  unique_nonzero_owner_338
 E  unique_nonzero_owner_339
 E  unique_nonzero_owner_340
 E  unique_nonzero_owner_341
 E  unique_nonzero_owner_342
 E  unique_nonzero_owner_343
 E  unique_nonzero_owner_344
 E  unique_nonzero_owner_345
 E  unique_nonzero_owner_346
 E  unique_nonzero_owner_347
 E  unique_nonzero_owner_348
 E  unique_nonzero_owner_349
 E  unique_nonzero_owner_350
 E  unique_nonzero_owner_351
 E  unique_nonzero_owner_352
 E  unique_nonzero_owner_353
 E  unique_nonzero_owner_354
 E  unique_nonzero_owner_355
 E  unique_nonzero_owner_356
 E  unique_nonzero_owner_357
 E  unique_nonzero_owner_358
 E  unique_nonzero_owner_359
 E  unique_nonzero_owner_360
 E  unique_nonzero_owner_361
 E  unique_nonzero_owner_362
 E  unique_nonzero_owner_363
 E  unique_nonzero_owner_364
 E  unique_nonzero_owner_365
 E  unique_nonzero_owner_366
 E  unique_nonzero_owner_367
 E  unique_nonzero_owner_368
 E  unique_nonzero_owner_369
 E  unique_nonzero_owner_370
 E  unique_nonzero_owner_371
 E  unique_nonzero_owner_372
 E  unique_nonzero_owner_373
 E  unique_nonzero_owner_374
 E  unique_nonzero_owner_375
 E  unique_nonzero_owner_376
 E  unique_nonzero_owner_377
 E  unique_nonzero_owner_378
 E  unique_nonzero_owner_379
 E  unique_nonzero_owner_380
 E  unique_nonzero_owner_381
 E  unique_nonzero_owner_382
 E  unique_nonzero_owner_383
 E  unique_nonzero_owner_384
 E  unique_nonzero_owner_385
 L  arc_capacity_386
 L  arc_capacity_387
 L  arc_capacity_388
 L  arc_capacity_389
 L  arc_capacity_390
 L  arc_capacity_391
 L  arc_capacity_392
 L  arc_capacity_393
 L  arc_capacity_394
 L  arc_capacity_395
 L  arc_capacity_396
 L  arc_capacity_397
 L  arc_capacity_398
 L  arc_capacity_399
 L  arc_capacity_400
 L  arc_capacity_401
 G  connected_order_arc_402
 L  arc_capacity_403
 G  connected_order_arc_404
 L  arc_capacity_405
 G  connected_order_arc_406
 L  arc_capacity_407
 G  connected_order_arc_408
 L  arc_capacity_409
 G  connected_order_arc_410
 L  arc_capacity_411
 G  connected_order_arc_412
 L  arc_capacity_413
 G  connected_order_arc_414
 L  arc_capacity_415
 G  connected_order_arc_416
 L  arc_capacity_417
 G  connected_order_arc_418
 L  arc_capacity_419
 G  connected_order_arc_420
 L  arc_capacity_421
 G  connected_order_arc_422
 L  arc_capacity_423
 G  connected_order_arc_424
 L  arc_capacity_425
 L  arc_capacity_426
 G  connected_order_arc_427
 L  arc_capacity_428
 G  connected_order_arc_429
 L  arc_capacity_430
 G  connected_order_arc_431
 L  arc_capacity_432
 G  connected_order_arc_433
 L  arc_capacity_434
 G  connected_order_arc_435
 L  arc_capacity_436
 G  connected_order_arc_437
 L  arc_capacity_438
 G  connected_order_arc_439
 L  arc_capacity_440
 G  connected_order_arc_441
 L  arc_capacity_442
 G  connected_order_arc_443
 L  arc_capacity_444
 G  connected_order_arc_445
 L  arc_capacity_446
 G  connected_order_arc_447
 L  arc_capacity_448
 G  connected_order_arc_449
 L  arc_capacity_450
 L  arc_capacity_451
 G  connected_order_arc_452
 L  arc_capacity_453
 G  connected_order_arc_454
 L  arc_capacity_455
 G  connected_order_arc_456
 L  arc_capacity_457
 G  connected_order_arc_458
 L  arc_capacity_459
 G  connected_order_arc_460
 L  arc_capacity_461
 G  connected_order_arc_462
 L  arc_capacity_463
 G  connected_order_arc_464
 L  arc_capacity_465
 G  connected_order_arc_466
 L  arc_capacity_467
 G  connected_order_arc_468
 L  arc_capacity_469
 G  connected_order_arc_470
 L  arc_capacity_471
 G  connected_order_arc_472
 L  arc_capacity_473
 G  connected_order_arc_474
 L  arc_capacity_475
 L  arc_capacity_476
 G  connected_order_arc_477
 L  arc_capacity_478
 G  connected_order_arc_479
 L  arc_capacity_480
 G  connected_order_arc_481
 L  arc_capacity_482
 G  connected_order_arc_483
 L  arc_capacity_484
 G  connected_order_arc_485
 L  arc_capacity_486
 G  connected_order_arc_487
 L  arc_capacity_488
 G  connected_order_arc_489
 L  arc_capacity_490
 G  connected_order_arc_491
 L  arc_capacity_492
 G  connected_order_arc_493
 L  arc_capacity_494
 G  connected_order_arc_495
 L  arc_capacity_496
 G  connected_order_arc_497
 L  arc_capacity_498
 G  connected_order_arc_499
 L  arc_capacity_500
 L  arc_capacity_501
 G  connected_order_arc_502
 L  arc_capacity_503
 G  connected_order_arc_504
 L  arc_capacity_505
 G  connected_order_arc_506
 L  arc_capacity_507
 G  connected_order_arc_508
 L  arc_capacity_509
 G  connected_order_arc_510
 L  arc_capacity_511
 G  connected_order_arc_512
 L  arc_capacity_513
 G  connected_order_arc_514
 L  arc_capacity_515
 G  connected_order_arc_516
 L  arc_capacity_517
 G  connected_order_arc_518
 L  arc_capacity_519
 G  connected_order_arc_520
 L  arc_capacity_521
 G  connected_order_arc_522
 L  arc_capacity_523
 G  connected_order_arc_524
 L  arc_capacity_525
 L  arc_capacity_526
 G  connected_order_arc_527
 L  arc_capacity_528
 G  connected_order_arc_529
 L  arc_capacity_530
 G  connected_order_arc_531
 L  arc_capacity_532
 G  connected_order_arc_533
 L  arc_capacity_534
 G  connected_order_arc_535
 L  arc_capacity_536
 G  connected_order_arc_537
 L  arc_capacity_538
 G  connected_order_arc_539
 L  arc_capacity_540
 G  connected_order_arc_541
 L  arc_capacity_542
 G  connected_order_arc_543
 L  arc_capacity_544
 G  connected_order_arc_545
 L  arc_capacity_546
 G  connected_order_arc_547
 L  arc_capacity_548
 G  connected_order_arc_549
 L  arc_capacity_550
 L  arc_capacity_551
 G  connected_order_arc_552
 L  arc_capacity_553
 G  connected_order_arc_554
 L  arc_capacity_555
 G  connected_order_arc_556
 L  arc_capacity_557
 G  connected_order_arc_558
 L  arc_capacity_559
 G  connected_order_arc_560
 L  arc_capacity_561
 G  connected_order_arc_562
 L  arc_capacity_563
 G  connected_order_arc_564
 L  arc_capacity_565
 G  connected_order_arc_566
 L  arc_capacity_567
 G  connected_order_arc_568
 L  arc_capacity_569
 G  connected_order_arc_570
 L  arc_capacity_571
 G  connected_order_arc_572
 L  arc_capacity_573
 G  connected_order_arc_574
 L  arc_capacity_575
 L  arc_capacity_576
 G  connected_order_arc_577
 L  arc_capacity_578
 G  connected_order_arc_579
 L  arc_capacity_580
 G  connected_order_arc_581
 L  arc_capacity_582
 G  connected_order_arc_583
 L  arc_capacity_584
 G  connected_order_arc_585
 L  arc_capacity_586
 G  connected_order_arc_587
 L  arc_capacity_588
 G  connected_order_arc_589
 L  arc_capacity_590
 G  connected_order_arc_591
 L  arc_capacity_592
 G  connected_order_arc_593
 L  arc_capacity_594
 G  connected_order_arc_595
 L  arc_capacity_596
 G  connected_order_arc_597
 L  arc_capacity_598
 G  connected_order_arc_599
 L  arc_capacity_600
 L  arc_capacity_601
 G  connected_order_arc_602
 L  arc_capacity_603
 G  connected_order_arc_604
 L  arc_capacity_605
 G  connected_order_arc_606
 L  arc_capacity_607
 G  connected_order_arc_608
 L  arc_capacity_609
 G  connected_order_arc_610
 L  arc_capacity_611
 G  connected_order_arc_612
 L  arc_capacity_613
 G  connected_order_arc_614
 L  arc_capacity_615
 G  connected_order_arc_616
 L  arc_capacity_617
 G  connected_order_arc_618
 L  arc_capacity_619
 G  connected_order_arc_620
 L  arc_capacity_621
 G  connected_order_arc_622
 L  arc_capacity_623
 G  connected_order_arc_624
 L  arc_capacity_625
 L  arc_capacity_626
 G  connected_order_arc_627
 L  arc_capacity_628
 G  connected_order_arc_629
 L  arc_capacity_630
 G  connected_order_arc_631
 L  arc_capacity_632
 G  connected_order_arc_633
 L  arc_capacity_634
 G  connected_order_arc_635
 L  arc_capacity_636
 G  connected_order_arc_637
 L  arc_capacity_638
 G  connected_order_arc_639
 L  arc_capacity_640
 G  connected_order_arc_641
 L  arc_capacity_642
 G  connected_order_arc_643
 L  arc_capacity_644
 G  connected_order_arc_645
 L  arc_capacity_646
 G  connected_order_arc_647
 L  arc_capacity_648
 G  connected_order_arc_649
 L  arc_capacity_650
 L  arc_capacity_651
 G  connected_order_arc_652
 L  arc_capacity_653
 G  connected_order_arc_654
 L  arc_capacity_655
 G  connected_order_arc_656
 L  arc_capacity_657
 G  connected_order_arc_658
 L  arc_capacity_659
 G  connected_order_arc_660
 L  arc_capacity_661
 G  connected_order_arc_662
 L  arc_capacity_663
 G  connected_order_arc_664
 L  arc_capacity_665
 G  connected_order_arc_666
 L  arc_capacity_667
 G  connected_order_arc_668
 L  arc_capacity_669
 G  connected_order_arc_670
 L  arc_capacity_671
 G  connected_order_arc_672
 L  arc_capacity_673
 G  connected_order_arc_674
 L  arc_capacity_675
 L  arc_capacity_676
 G  connected_order_arc_677
 L  arc_capacity_678
 G  connected_order_arc_679
 L  arc_capacity_680
 G  connected_order_arc_681
 L  arc_capacity_682
 G  connected_order_arc_683
 L  arc_capacity_684
 G  connected_order_arc_685
 L  arc_capacity_686
 G  connected_order_arc_687
 L  arc_capacity_688
 G  connected_order_arc_689
 L  arc_capacity_690
 G  connected_order_arc_691
 L  arc_capacity_692
 G  connected_order_arc_693
 L  arc_capacity_694
 G  connected_order_arc_695
 L  arc_capacity_696
 G  connected_order_arc_697
 L  arc_capacity_698
 G  connected_order_arc_699
 L  arc_capacity_700
 L  arc_capacity_701
 G  connected_order_arc_702
 L  arc_capacity_703
 G  connected_order_arc_704
 L  arc_capacity_705
 G  connected_order_arc_706
 L  arc_capacity_707
 G  connected_order_arc_708
 L  arc_capacity_709
 G  connected_order_arc_710
 L  arc_capacity_711
 G  connected_order_arc_712
 L  arc_capacity_713
 G  connected_order_arc_714
 L  arc_capacity_715
 G  connected_order_arc_716
 L  arc_capacity_717
 G  connected_order_arc_718
 L  arc_capacity_719
 G  connected_order_arc_720
 L  arc_capacity_721
 G  connected_order_arc_722
 L  arc_capacity_723
 G  connected_order_arc_724
 E  depot_departure_or_bypass_725
 E  depot_return_or_bypass_726
 E  out_degree_727
 E  in_degree_728
 G  order_active_lb_729
 L  order_active_ub_730
 E  segment_load_conservation_731
 G  segment_prefix_lb_732
 L  segment_prefix_ub_733
 E  out_degree_734
 E  in_degree_735
 G  order_active_lb_736
 L  order_active_ub_737
 E  segment_load_conservation_738
 G  segment_prefix_lb_739
 L  segment_prefix_ub_740
 E  out_degree_741
 E  in_degree_742
 G  order_active_lb_743
 L  order_active_ub_744
 E  segment_load_conservation_745
 G  segment_prefix_lb_746
 L  segment_prefix_ub_747
 E  out_degree_748
 E  in_degree_749
 G  order_active_lb_750
 L  order_active_ub_751
 E  segment_load_conservation_752
 G  segment_prefix_lb_753
 L  segment_prefix_ub_754
 E  out_degree_755
 E  in_degree_756
 G  order_active_lb_757
 L  order_active_ub_758
 E  segment_load_conservation_759
 G  segment_prefix_lb_760
 L  segment_prefix_ub_761
 E  out_degree_762
 E  in_degree_763
 G  order_active_lb_764
 L  order_active_ub_765
 E  service_visit_def_766
 E  free_load_conservation_767
 E  out_degree_768
 E  in_degree_769
 G  order_active_lb_770
 L  order_active_ub_771
 E  service_visit_def_772
 E  free_load_conservation_773
 E  out_degree_774
 E  in_degree_775
 G  order_active_lb_776
 L  order_active_ub_777
 E  service_visit_def_778
 E  free_load_conservation_779
 E  out_degree_780
 E  in_degree_781
 G  order_active_lb_782
 L  order_active_ub_783
 E  service_visit_def_784
 E  free_load_conservation_785
 E  out_degree_786
 E  in_degree_787
 G  order_active_lb_788
 L  order_active_ub_789
 E  service_visit_def_790
 E  free_load_conservation_791
 E  out_degree_792
 E  in_degree_793
 G  order_active_lb_794
 L  order_active_ub_795
 E  service_visit_def_796
 E  free_load_conservation_797
 E  out_degree_798
 E  in_degree_799
 G  order_active_lb_800
 L  order_active_ub_801
 E  service_visit_def_802
 E  free_load_conservation_803
 E  out_degree_804
 E  in_degree_805
 G  order_active_lb_806
 L  order_active_ub_807
 E  service_visit_def_808
 E  free_load_conservation_809
 G  fixed_segment_relative_order_810
 G  fixed_segment_relative_order_811
 G  fixed_segment_relative_order_812
 G  fixed_segment_relative_order_813
 L  original_T_including_depot_unload_814
 L  arc_capacity_815
 L  arc_capacity_816
 L  arc_capacity_817
 L  arc_capacity_818
 L  arc_capacity_819
 L  arc_capacity_820
 L  arc_capacity_821
 L  arc_capacity_822
 L  arc_capacity_823
 L  arc_capacity_824
 L  arc_capacity_825
 L  arc_capacity_826
 L  arc_capacity_827
 G  connected_order_arc_828
 L  arc_capacity_829
 G  connected_order_arc_830
 L  arc_capacity_831
 G  connected_order_arc_832
 L  arc_capacity_833
 G  connected_order_arc_834
 L  arc_capacity_835
 G  connected_order_arc_836
 L  arc_capacity_837
 G  connected_order_arc_838
 L  arc_capacity_839
 G  connected_order_arc_840
 L  arc_capacity_841
 G  connected_order_arc_842
 L  arc_capacity_843
 G  connected_order_arc_844
 L  arc_capacity_845
 L  arc_capacity_846
 G  connected_order_arc_847
 L  arc_capacity_848
 G  connected_order_arc_849
 L  arc_capacity_850
 G  connected_order_arc_851
 L  arc_capacity_852
 G  connected_order_arc_853
 L  arc_capacity_854
 G  connected_order_arc_855
 L  arc_capacity_856
 G  connected_order_arc_857
 L  arc_capacity_858
 G  connected_order_arc_859
 L  arc_capacity_860
 G  connected_order_arc_861
 L  arc_capacity_862
 G  connected_order_arc_863
 L  arc_capacity_864
 L  arc_capacity_865
 G  connected_order_arc_866
 L  arc_capacity_867
 G  connected_order_arc_868
 L  arc_capacity_869
 G  connected_order_arc_870
 L  arc_capacity_871
 G  connected_order_arc_872
 L  arc_capacity_873
 G  connected_order_arc_874
 L  arc_capacity_875
 G  connected_order_arc_876
 L  arc_capacity_877
 G  connected_order_arc_878
 L  arc_capacity_879
 G  connected_order_arc_880
 L  arc_capacity_881
 G  connected_order_arc_882
 L  arc_capacity_883
 L  arc_capacity_884
 G  connected_order_arc_885
 L  arc_capacity_886
 G  connected_order_arc_887
 L  arc_capacity_888
 G  connected_order_arc_889
 L  arc_capacity_890
 G  connected_order_arc_891
 L  arc_capacity_892
 G  connected_order_arc_893
 L  arc_capacity_894
 G  connected_order_arc_895
 L  arc_capacity_896
 G  connected_order_arc_897
 L  arc_capacity_898
 G  connected_order_arc_899
 L  arc_capacity_900
 G  connected_order_arc_901
 L  arc_capacity_902
 L  arc_capacity_903
 G  connected_order_arc_904
 L  arc_capacity_905
 G  connected_order_arc_906
 L  arc_capacity_907
 G  connected_order_arc_908
 L  arc_capacity_909
 G  connected_order_arc_910
 L  arc_capacity_911
 G  connected_order_arc_912
 L  arc_capacity_913
 G  connected_order_arc_914
 L  arc_capacity_915
 G  connected_order_arc_916
 L  arc_capacity_917
 G  connected_order_arc_918
 L  arc_capacity_919
 G  connected_order_arc_920
 L  arc_capacity_921
 L  arc_capacity_922
 G  connected_order_arc_923
 L  arc_capacity_924
 G  connected_order_arc_925
 L  arc_capacity_926
 G  connected_order_arc_927
 L  arc_capacity_928
 G  connected_order_arc_929
 L  arc_capacity_930
 G  connected_order_arc_931
 L  arc_capacity_932
 G  connected_order_arc_933
 L  arc_capacity_934
 G  connected_order_arc_935
 L  arc_capacity_936
 G  connected_order_arc_937
 L  arc_capacity_938
 G  connected_order_arc_939
 L  arc_capacity_940
 L  arc_capacity_941
 G  connected_order_arc_942
 L  arc_capacity_943
 G  connected_order_arc_944
 L  arc_capacity_945
 G  connected_order_arc_946
 L  arc_capacity_947
 G  connected_order_arc_948
 L  arc_capacity_949
 G  connected_order_arc_950
 L  arc_capacity_951
 G  connected_order_arc_952
 L  arc_capacity_953
 G  connected_order_arc_954
 L  arc_capacity_955
 G  connected_order_arc_956
 L  arc_capacity_957
 G  connected_order_arc_958
 L  arc_capacity_959
 L  arc_capacity_960
 G  connected_order_arc_961
 L  arc_capacity_962
 G  connected_order_arc_963
 L  arc_capacity_964
 G  connected_order_arc_965
 L  arc_capacity_966
 G  connected_order_arc_967
 L  arc_capacity_968
 G  connected_order_arc_969
 L  arc_capacity_970
 G  connected_order_arc_971
 L  arc_capacity_972
 G  connected_order_arc_973
 L  arc_capacity_974
 G  connected_order_arc_975
 L  arc_capacity_976
 G  connected_order_arc_977
 L  arc_capacity_978
 L  arc_capacity_979
 G  connected_order_arc_980
 L  arc_capacity_981
 G  connected_order_arc_982
 L  arc_capacity_983
 G  connected_order_arc_984
 L  arc_capacity_985
 G  connected_order_arc_986
 L  arc_capacity_987
 G  connected_order_arc_988
 L  arc_capacity_989
 G  connected_order_arc_990
 L  arc_capacity_991
 G  connected_order_arc_992
 L  arc_capacity_993
 G  connected_order_arc_994
 L  arc_capacity_995
 G  connected_order_arc_996
 L  arc_capacity_997
 L  arc_capacity_998
 G  connected_order_arc_999
 L  arc_capacity_1000
 G  connected_order_arc_1001
 L  arc_capacity_1002
 G  connected_order_arc_1003
 L  arc_capacity_1004
 G  connected_order_arc_1005
 L  arc_capacity_1006
 G  connected_order_arc_1007
 L  arc_capacity_1008
 G  connected_order_arc_1009
 L  arc_capacity_1010
 G  connected_order_arc_1011
 L  arc_capacity_1012
 G  connected_order_arc_1013
 L  arc_capacity_1014
 G  connected_order_arc_1015
 E  depot_departure_or_bypass_1016
 E  depot_return_or_bypass_1017
 E  out_degree_1018
 E  in_degree_1019
 G  order_active_lb_1020
 L  order_active_ub_1021
 E  segment_load_conservation_1022
 G  segment_prefix_lb_1023
 L  segment_prefix_ub_1024
 E  out_degree_1025
 E  in_degree_1026
 G  order_active_lb_1027
 L  order_active_ub_1028
 E  segment_load_conservation_1029
 G  segment_prefix_lb_1030
 L  segment_prefix_ub_1031
 E  out_degree_1032
 E  in_degree_1033
 G  order_active_lb_1034
 L  order_active_ub_1035
 E  service_visit_def_1036
 E  free_load_conservation_1037
 E  out_degree_1038
 E  in_degree_1039
 G  order_active_lb_1040
 L  order_active_ub_1041
 E  service_visit_def_1042
 E  free_load_conservation_1043
 E  out_degree_1044
 E  in_degree_1045
 G  order_active_lb_1046
 L  order_active_ub_1047
 E  service_visit_def_1048
 E  free_load_conservation_1049
 E  out_degree_1050
 E  in_degree_1051
 G  order_active_lb_1052
 L  order_active_ub_1053
 E  service_visit_def_1054
 E  free_load_conservation_1055
 E  out_degree_1056
 E  in_degree_1057
 G  order_active_lb_1058
 L  order_active_ub_1059
 E  service_visit_def_1060
 E  free_load_conservation_1061
 E  out_degree_1062
 E  in_degree_1063
 G  order_active_lb_1064
 L  order_active_ub_1065
 E  service_visit_def_1066
 E  free_load_conservation_1067
 E  out_degree_1068
 E  in_degree_1069
 G  order_active_lb_1070
 L  order_active_ub_1071
 E  service_visit_def_1072
 E  free_load_conservation_1073
 E  out_degree_1074
 E  in_degree_1075
 G  order_active_lb_1076
 L  order_active_ub_1077
 E  service_visit_def_1078
 E  free_load_conservation_1079
 G  fixed_segment_relative_order_1080
 L  original_T_including_depot_unload_1081
COLUMNS
    t         normalized_mass_1_33  -1
    t         normalized_mass_2_40  -1
    t         normalized_mass_18_75  -1
    t         normalized_mass_3_112  -1
    t         normalized_mass_17_149  -1
    t         normalized_mass_4_184  -1
    t         normalized_mass_11_219  -1
    t         normalized_mass_5_228  -1
    t         normalization_289  9.4428571428571431e+00
    t         full_original_Gini_290  -3.4785714285714278e+01
    q         OBJ       1
    q         parent_nonstrict_scope_232  1
    q         full_original_Gini_290  20
    MARKER    'MARKER'                 'INTORG'
    x_1_0     OBJ       3.2863847044708572e-02
    x_1_0     product_lb_0  -4.1226319405776264e-02
    x_1_0     product_ub_1  -1.0590015128603633e-01
    x_1_0     onehot_1_32  1
    x_1_0     parent_nonstrict_scope_232  7.6682309770986667e-02
    x_1_0     unique_nonzero_owner_291  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_0     product_lb_0  1
    w_1_0     product_ub_1  1
    w_1_0     normalized_mass_1_33  1
    w_1_0     full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_1     OBJ       2.1909231363139048e-02
    x_1_1     product_lb_2  -4.1226319405776264e-02
    x_1_1     product_ub_3  -1.0590015128603633e-01
    x_1_1     onehot_1_32  1
    x_1_1     stock_lb_230  1
    x_1_1     stock_ub_231  1
    x_1_1     parent_nonstrict_scope_232  6.5727694089417144e-02
    MARKER    'MARKER'                 'INTEND'
    w_1_1     product_lb_2  1
    w_1_1     product_ub_3  1
    w_1_1     normalized_mass_1_33  1
    w_1_1     normalized_ratio_1_34  -1.4285714285714285e-01
    w_1_1     full_original_Gini_290  -8.5857142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_2     OBJ       1.0954615681569524e-02
    x_1_2     product_lb_4  -4.1226319405776264e-02
    x_1_2     product_ub_5  -1.0590015128603633e-01
    x_1_2     onehot_1_32  1
    x_1_2     stock_lb_230  2
    x_1_2     stock_ub_231  2
    x_1_2     parent_nonstrict_scope_232  5.4773078407847620e-02
    x_1_2     unique_nonzero_owner_292  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_2     product_lb_4  1
    w_1_2     product_ub_5  1
    w_1_2     normalized_mass_1_33  1
    w_1_2     normalized_ratio_1_34  -2.8571428571428570e-01
    w_1_2     full_original_Gini_290  -7.7285714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_3     product_lb_6  -4.1226319405776264e-02
    x_1_3     product_ub_7  -1.0590015128603633e-01
    x_1_3     onehot_1_32  1
    x_1_3     stock_lb_230  3
    x_1_3     stock_ub_231  3
    x_1_3     parent_nonstrict_scope_232  4.3818462726278096e-02
    x_1_3     unique_nonzero_owner_293  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_3     product_lb_6  1
    w_1_3     product_ub_7  1
    w_1_3     normalized_mass_1_33  1
    w_1_3     normalized_ratio_1_34  -4.2857142857142855e-01
    w_1_3     full_original_Gini_290  -6.8714285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_4     OBJ       -1.0954615681569524e-02
    x_1_4     product_lb_8  -4.1226319405776264e-02
    x_1_4     product_ub_9  -1.0590015128603633e-01
    x_1_4     onehot_1_32  1
    x_1_4     stock_lb_230  4
    x_1_4     stock_ub_231  4
    x_1_4     parent_nonstrict_scope_232  3.2863847044708572e-02
    x_1_4     unique_nonzero_owner_294  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_4     product_lb_8  1
    w_1_4     product_ub_9  1
    w_1_4     normalized_mass_1_33  1
    w_1_4     normalized_ratio_1_34  -5.7142857142857140e-01
    w_1_4     full_original_Gini_290  -6.0142857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_5     OBJ       -2.1909231363139041e-02
    x_1_5     product_lb_10  -4.1226319405776264e-02
    x_1_5     product_ub_11  -1.0590015128603633e-01
    x_1_5     onehot_1_32  1
    x_1_5     stock_lb_230  5
    x_1_5     stock_ub_231  5
    x_1_5     parent_nonstrict_scope_232  2.1909231363139055e-02
    x_1_5     unique_nonzero_owner_295  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_5     product_lb_10  1
    w_1_5     product_ub_11  1
    w_1_5     normalized_mass_1_33  1
    w_1_5     normalized_ratio_1_34  -7.1428571428571419e-01
    w_1_5     full_original_Gini_290  -5.1571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_6     OBJ       -3.2863847044708572e-02
    x_1_6     product_lb_12  -4.1226319405776264e-02
    x_1_6     product_ub_13  -1.0590015128603633e-01
    x_1_6     onehot_1_32  1
    x_1_6     stock_lb_230  6
    x_1_6     stock_ub_231  6
    x_1_6     parent_nonstrict_scope_232  1.0954615681569527e-02
    x_1_6     unique_nonzero_owner_296  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_6     product_lb_12  1
    w_1_6     product_ub_13  1
    w_1_6     normalized_mass_1_33  1
    w_1_6     normalized_ratio_1_34  -8.5714285714285710e-01
    w_1_6     full_original_Gini_290  -4.4142857142857137e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_7     OBJ       -4.3818462726278096e-02
    x_1_7     product_lb_14  -4.1226319405776264e-02
    x_1_7     product_ub_15  -1.0590015128603633e-01
    x_1_7     onehot_1_32  1
    x_1_7     stock_lb_230  7
    x_1_7     stock_ub_231  7
    x_1_7     unique_nonzero_owner_297  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_7     product_lb_14  1
    w_1_7     product_ub_15  1
    w_1_7     normalized_mass_1_33  1
    w_1_7     normalized_ratio_1_34  -1
    w_1_7     full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_8     OBJ       -3.2863847044708579e-02
    x_1_8     product_lb_16  -4.1226319405776264e-02
    x_1_8     product_ub_17  -1.0590015128603633e-01
    x_1_8     onehot_1_32  1
    x_1_8     stock_lb_230  8
    x_1_8     stock_ub_231  8
    x_1_8     parent_nonstrict_scope_232  1.0954615681569519e-02
    x_1_8     unique_nonzero_owner_298  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_8     product_lb_16  1
    w_1_8     product_ub_17  1
    w_1_8     normalized_mass_1_33  1
    w_1_8     normalized_ratio_1_34  -1.1428571428571428e+00
    w_1_8     full_original_Gini_290  -4.9857142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_9     OBJ       -2.1909231363139058e-02
    x_1_9     product_lb_18  -4.1226319405776264e-02
    x_1_9     product_ub_19  -1.0590015128603633e-01
    x_1_9     onehot_1_32  1
    x_1_9     stock_lb_230  9
    x_1_9     stock_ub_231  9
    x_1_9     parent_nonstrict_scope_232  2.1909231363139037e-02
    x_1_9     unique_nonzero_owner_299  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_9     product_lb_18  1
    w_1_9     product_ub_19  1
    w_1_9     normalized_mass_1_33  1
    w_1_9     normalized_ratio_1_34  -1.2857142857142856e+00
    w_1_9     full_original_Gini_290  -6.4142857142857137e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_10    OBJ       -1.0954615681569538e-02
    x_1_10    product_lb_20  -4.1226319405776264e-02
    x_1_10    product_ub_21  -1.0590015128603633e-01
    x_1_10    onehot_1_32  1
    x_1_10    stock_lb_230  10
    x_1_10    stock_ub_231  10
    x_1_10    parent_nonstrict_scope_232  3.2863847044708558e-02
    x_1_10    unique_nonzero_owner_300  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_10    product_lb_20  1
    w_1_10    product_ub_21  1
    w_1_10    normalized_mass_1_33  1
    w_1_10    normalized_ratio_1_34  -1.4285714285714284e+00
    w_1_10    full_original_Gini_290  -7.8428571428571416e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_11    product_lb_22  -4.1226319405776264e-02
    x_1_11    product_ub_23  -1.0590015128603633e-01
    x_1_11    onehot_1_32  1
    x_1_11    stock_lb_230  11
    x_1_11    stock_ub_231  11
    x_1_11    parent_nonstrict_scope_232  4.3818462726278096e-02
    x_1_11    unique_nonzero_owner_301  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_11    product_lb_22  1
    w_1_11    product_ub_23  1
    w_1_11    normalized_mass_1_33  1
    w_1_11    normalized_ratio_1_34  -1.5714285714285714e+00
    w_1_11    full_original_Gini_290  -9.4142857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_1_12    OBJ       1.0954615681569517e-02
    x_1_12    product_lb_24  -4.1226319405776264e-02
    x_1_12    product_ub_25  -1.0590015128603633e-01
    x_1_12    onehot_1_32  1
    x_1_12    stock_lb_230  12
    x_1_12    stock_ub_231  12
    x_1_12    parent_nonstrict_scope_232  5.4773078407847613e-02
    x_1_12    unique_nonzero_owner_302  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_12    product_lb_24  1
    w_1_12    product_ub_25  1
    w_1_12    normalized_mass_1_33  1
    w_1_12    normalized_ratio_1_34  -1.7142857142857142e+00
    w_1_12    full_original_Gini_290  -1.1128571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_13    OBJ       2.1909231363139034e-02
    x_1_13    product_lb_26  -4.1226319405776264e-02
    x_1_13    product_ub_27  -1.0590015128603633e-01
    x_1_13    onehot_1_32  1
    x_1_13    stock_lb_230  13
    x_1_13    stock_ub_231  13
    x_1_13    parent_nonstrict_scope_232  6.5727694089417130e-02
    x_1_13    unique_nonzero_owner_303  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_13    product_lb_26  1
    w_1_13    product_ub_27  1
    w_1_13    normalized_mass_1_33  1
    w_1_13    normalized_ratio_1_34  -1.8571428571428570e+00
    w_1_13    full_original_Gini_290  -1.2842857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_14    OBJ       3.2863847044708572e-02
    x_1_14    product_lb_28  -4.1226319405776264e-02
    x_1_14    product_ub_29  -1.0590015128603633e-01
    x_1_14    onehot_1_32  1
    x_1_14    stock_lb_230  14
    x_1_14    stock_ub_231  14
    x_1_14    parent_nonstrict_scope_232  7.6682309770986667e-02
    x_1_14    unique_nonzero_owner_304  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_14    product_lb_28  1
    w_1_14    product_ub_29  1
    w_1_14    normalized_mass_1_33  1
    w_1_14    normalized_ratio_1_34  -2
    w_1_14    full_original_Gini_290  -1.4557142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_1_15    OBJ       4.3818462726278096e-02
    x_1_15    product_lb_30  -4.1226319405776264e-02
    x_1_15    product_ub_31  -1.0590015128603633e-01
    x_1_15    onehot_1_32  1
    x_1_15    stock_lb_230  15
    x_1_15    stock_ub_231  15
    x_1_15    parent_nonstrict_scope_232  8.7636925452556191e-02
    x_1_15    unique_nonzero_owner_305  -1
    MARKER    'MARKER'                 'INTEND'
    w_1_15    product_lb_30  1
    w_1_15    product_ub_31  1
    w_1_15    normalized_mass_1_33  1
    w_1_15    normalized_ratio_1_34  -2.1428571428571428e+00
    w_1_15    full_original_Gini_290  -1.6271428571428569e+01
    rho_1     normalized_ratio_1_34  1
    rho_1     block_pair_pos_233  -1
    rho_1     block_pair_neg_234  1
    rho_1     block_pair_pos_235  -1
    rho_1     block_pair_neg_236  1
    rho_1     block_pair_pos_237  -1
    rho_1     block_pair_neg_238  1
    rho_1     block_pair_pos_239  -1
    rho_1     block_pair_neg_240  1
    rho_1     block_pair_pos_241  -1
    rho_1     block_pair_neg_242  1
    rho_1     block_pair_pos_243  -1
    rho_1     block_pair_neg_244  1
    rho_1     block_pair_pos_245  -1
    rho_1     block_pair_neg_246  1
    rho_1     normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_2_0     OBJ       6.3380304899829966e-03
    x_2_0     product_lb_35  -4.1226319405776264e-02
    x_2_0     product_ub_36  -1.0590015128603633e-01
    x_2_0     onehot_2_39  1
    x_2_0     parent_nonstrict_scope_232  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_2_0     product_lb_35  1
    w_2_0     product_ub_36  1
    w_2_0     normalized_mass_2_40  1
    w_2_0     full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_2_1     OBJ       -6.3380304899829966e-03
    x_2_1     product_lb_37  -4.1226319405776264e-02
    x_2_1     product_ub_38  -1.0590015128603633e-01
    x_2_1     onehot_2_39  1
    x_2_1     stock_lb_230  1
    x_2_1     stock_ub_231  1
    x_2_1     unique_nonzero_owner_306  -1
    MARKER    'MARKER'                 'INTEND'
    w_2_1     product_lb_37  1
    w_2_1     product_ub_38  1
    w_2_1     normalized_mass_2_40  1
    w_2_1     normalized_ratio_2_41  -1
    w_2_1     full_original_Gini_290  -3.8428571428571425e+00
    rho_2     normalized_ratio_2_41  1
    rho_2     block_pair_pos_233  1
    rho_2     block_pair_neg_234  -1
    rho_2     block_pair_pos_247  -1
    rho_2     block_pair_neg_248  1
    rho_2     block_pair_pos_249  -1
    rho_2     block_pair_neg_250  1
    rho_2     block_pair_pos_251  -1
    rho_2     block_pair_neg_252  1
    rho_2     block_pair_pos_253  -1
    rho_2     block_pair_neg_254  1
    rho_2     block_pair_pos_255  -1
    rho_2     block_pair_neg_256  1
    rho_2     block_pair_pos_257  -1
    rho_2     block_pair_neg_258  1
    rho_2     normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_18_0    OBJ       3.2863847044708572e-02
    x_18_0    product_lb_42  -4.1226319405776264e-02
    x_18_0    product_ub_43  -1.0590015128603633e-01
    x_18_0    onehot_18_74  1
    x_18_0    parent_nonstrict_scope_232  7.6682309770986667e-02
    MARKER    'MARKER'                 'INTEND'
    w_18_0    product_lb_42  1
    w_18_0    product_ub_43  1
    w_18_0    normalized_mass_18_75  1
    w_18_0    full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_1    OBJ       2.1909231363139048e-02
    x_18_1    product_lb_44  -4.1226319405776264e-02
    x_18_1    product_ub_45  -1.0590015128603633e-01
    x_18_1    onehot_18_74  1
    x_18_1    stock_lb_230  1
    x_18_1    stock_ub_231  1
    x_18_1    parent_nonstrict_scope_232  6.5727694089417144e-02
    x_18_1    unique_nonzero_owner_307  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_1    product_lb_44  1
    w_18_1    product_ub_45  1
    w_18_1    normalized_mass_18_75  1
    w_18_1    normalized_ratio_18_76  -1.4285714285714285e-01
    w_18_1    full_original_Gini_290  -8.5857142857142872e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_2    OBJ       1.0954615681569524e-02
    x_18_2    product_lb_46  -4.1226319405776264e-02
    x_18_2    product_ub_47  -1.0590015128603633e-01
    x_18_2    onehot_18_74  1
    x_18_2    stock_lb_230  2
    x_18_2    stock_ub_231  2
    x_18_2    parent_nonstrict_scope_232  5.4773078407847620e-02
    x_18_2    unique_nonzero_owner_308  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_2    product_lb_46  1
    w_18_2    product_ub_47  1
    w_18_2    normalized_mass_18_75  1
    w_18_2    normalized_ratio_18_76  -2.8571428571428570e-01
    w_18_2    full_original_Gini_290  -7.7285714285714286e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_3    product_lb_48  -4.1226319405776264e-02
    x_18_3    product_ub_49  -1.0590015128603633e-01
    x_18_3    onehot_18_74  1
    x_18_3    stock_lb_230  3
    x_18_3    stock_ub_231  3
    x_18_3    parent_nonstrict_scope_232  4.3818462726278096e-02
    x_18_3    unique_nonzero_owner_309  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_3    product_lb_48  1
    w_18_3    product_ub_49  1
    w_18_3    normalized_mass_18_75  1
    w_18_3    normalized_ratio_18_76  -4.2857142857142855e-01
    w_18_3    full_original_Gini_290  -6.8714285714285710e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_4    OBJ       -1.0954615681569524e-02
    x_18_4    product_lb_50  -4.1226319405776264e-02
    x_18_4    product_ub_51  -1.0590015128603633e-01
    x_18_4    onehot_18_74  1
    x_18_4    stock_lb_230  4
    x_18_4    stock_ub_231  4
    x_18_4    parent_nonstrict_scope_232  3.2863847044708572e-02
    x_18_4    unique_nonzero_owner_310  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_4    product_lb_50  1
    w_18_4    product_ub_51  1
    w_18_4    normalized_mass_18_75  1
    w_18_4    normalized_ratio_18_76  -5.7142857142857140e-01
    w_18_4    full_original_Gini_290  -6.0142857142857151e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_5    OBJ       -2.1909231363139041e-02
    x_18_5    product_lb_52  -4.1226319405776264e-02
    x_18_5    product_ub_53  -1.0590015128603633e-01
    x_18_5    onehot_18_74  1
    x_18_5    stock_lb_230  5
    x_18_5    stock_ub_231  5
    x_18_5    parent_nonstrict_scope_232  2.1909231363139055e-02
    x_18_5    unique_nonzero_owner_311  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_5    product_lb_52  1
    w_18_5    product_ub_53  1
    w_18_5    normalized_mass_18_75  1
    w_18_5    normalized_ratio_18_76  -7.1428571428571419e-01
    w_18_5    full_original_Gini_290  -5.1571428571428575e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_6    OBJ       -3.2863847044708572e-02
    x_18_6    product_lb_54  -4.1226319405776264e-02
    x_18_6    product_ub_55  -1.0590015128603633e-01
    x_18_6    onehot_18_74  1
    x_18_6    stock_lb_230  6
    x_18_6    stock_ub_231  6
    x_18_6    parent_nonstrict_scope_232  1.0954615681569527e-02
    x_18_6    unique_nonzero_owner_312  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_6    product_lb_54  1
    w_18_6    product_ub_55  1
    w_18_6    normalized_mass_18_75  1
    w_18_6    normalized_ratio_18_76  -8.5714285714285710e-01
    w_18_6    full_original_Gini_290  -4.4142857142857137e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_7    OBJ       -4.3818462726278096e-02
    x_18_7    product_lb_56  -4.1226319405776264e-02
    x_18_7    product_ub_57  -1.0590015128603633e-01
    x_18_7    onehot_18_74  1
    x_18_7    stock_lb_230  7
    x_18_7    stock_ub_231  7
    x_18_7    unique_nonzero_owner_313  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_7    product_lb_56  1
    w_18_7    product_ub_57  1
    w_18_7    normalized_mass_18_75  1
    w_18_7    normalized_ratio_18_76  -1
    w_18_7    full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_8    OBJ       -3.2863847044708579e-02
    x_18_8    product_lb_58  -4.1226319405776264e-02
    x_18_8    product_ub_59  -1.0590015128603633e-01
    x_18_8    onehot_18_74  1
    x_18_8    stock_lb_230  8
    x_18_8    stock_ub_231  8
    x_18_8    parent_nonstrict_scope_232  1.0954615681569519e-02
    x_18_8    unique_nonzero_owner_314  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_8    product_lb_58  1
    w_18_8    product_ub_59  1
    w_18_8    normalized_mass_18_75  1
    w_18_8    normalized_ratio_18_76  -1.1428571428571428e+00
    w_18_8    full_original_Gini_290  -4.9857142857142858e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_9    OBJ       -2.1909231363139058e-02
    x_18_9    product_lb_60  -4.1226319405776264e-02
    x_18_9    product_ub_61  -1.0590015128603633e-01
    x_18_9    onehot_18_74  1
    x_18_9    stock_lb_230  9
    x_18_9    stock_ub_231  9
    x_18_9    parent_nonstrict_scope_232  2.1909231363139037e-02
    x_18_9    unique_nonzero_owner_315  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_9    product_lb_60  1
    w_18_9    product_ub_61  1
    w_18_9    normalized_mass_18_75  1
    w_18_9    normalized_ratio_18_76  -1.2857142857142856e+00
    w_18_9    full_original_Gini_290  -6.4142857142857137e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_10   OBJ       -1.0954615681569538e-02
    x_18_10   product_lb_62  -4.1226319405776264e-02
    x_18_10   product_ub_63  -1.0590015128603633e-01
    x_18_10   onehot_18_74  1
    x_18_10   stock_lb_230  10
    x_18_10   stock_ub_231  10
    x_18_10   parent_nonstrict_scope_232  3.2863847044708558e-02
    x_18_10   unique_nonzero_owner_316  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_10   product_lb_62  1
    w_18_10   product_ub_63  1
    w_18_10   normalized_mass_18_75  1
    w_18_10   normalized_ratio_18_76  -1.4285714285714284e+00
    w_18_10   full_original_Gini_290  -7.8428571428571416e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_11   product_lb_64  -4.1226319405776264e-02
    x_18_11   product_ub_65  -1.0590015128603633e-01
    x_18_11   onehot_18_74  1
    x_18_11   stock_lb_230  11
    x_18_11   stock_ub_231  11
    x_18_11   parent_nonstrict_scope_232  4.3818462726278096e-02
    x_18_11   unique_nonzero_owner_317  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_11   product_lb_64  1
    w_18_11   product_ub_65  1
    w_18_11   normalized_mass_18_75  1
    w_18_11   normalized_ratio_18_76  -1.5714285714285714e+00
    w_18_11   full_original_Gini_290  -9.4142857142857128e+00
    MARKER    'MARKER'                 'INTORG'
    x_18_12   OBJ       1.0954615681569517e-02
    x_18_12   product_lb_66  -4.1226319405776264e-02
    x_18_12   product_ub_67  -1.0590015128603633e-01
    x_18_12   onehot_18_74  1
    x_18_12   stock_lb_230  12
    x_18_12   stock_ub_231  12
    x_18_12   parent_nonstrict_scope_232  5.4773078407847613e-02
    x_18_12   unique_nonzero_owner_318  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_12   product_lb_66  1
    w_18_12   product_ub_67  1
    w_18_12   normalized_mass_18_75  1
    w_18_12   normalized_ratio_18_76  -1.7142857142857142e+00
    w_18_12   full_original_Gini_290  -1.1128571428571426e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_13   OBJ       2.1909231363139034e-02
    x_18_13   product_lb_68  -4.1226319405776264e-02
    x_18_13   product_ub_69  -1.0590015128603633e-01
    x_18_13   onehot_18_74  1
    x_18_13   stock_lb_230  13
    x_18_13   stock_ub_231  13
    x_18_13   parent_nonstrict_scope_232  6.5727694089417130e-02
    x_18_13   unique_nonzero_owner_319  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_13   product_lb_68  1
    w_18_13   product_ub_69  1
    w_18_13   normalized_mass_18_75  1
    w_18_13   normalized_ratio_18_76  -1.8571428571428570e+00
    w_18_13   full_original_Gini_290  -1.2842857142857143e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_14   OBJ       3.2863847044708572e-02
    x_18_14   product_lb_70  -4.1226319405776264e-02
    x_18_14   product_ub_71  -1.0590015128603633e-01
    x_18_14   onehot_18_74  1
    x_18_14   stock_lb_230  14
    x_18_14   stock_ub_231  14
    x_18_14   parent_nonstrict_scope_232  7.6682309770986667e-02
    x_18_14   unique_nonzero_owner_320  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_14   product_lb_70  1
    w_18_14   product_ub_71  1
    w_18_14   normalized_mass_18_75  1
    w_18_14   normalized_ratio_18_76  -2
    w_18_14   full_original_Gini_290  -1.4557142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_18_15   OBJ       4.3818462726278096e-02
    x_18_15   product_lb_72  -4.1226319405776264e-02
    x_18_15   product_ub_73  -1.0590015128603633e-01
    x_18_15   onehot_18_74  1
    x_18_15   stock_lb_230  15
    x_18_15   stock_ub_231  15
    x_18_15   parent_nonstrict_scope_232  8.7636925452556191e-02
    x_18_15   unique_nonzero_owner_321  -1
    MARKER    'MARKER'                 'INTEND'
    w_18_15   product_lb_72  1
    w_18_15   product_ub_73  1
    w_18_15   normalized_mass_18_75  1
    w_18_15   normalized_ratio_18_76  -2.1428571428571428e+00
    w_18_15   full_original_Gini_290  -1.6271428571428569e+01
    rho_18    normalized_ratio_18_76  1
    rho_18    block_pair_pos_245  1
    rho_18    block_pair_neg_246  -1
    rho_18    block_pair_pos_257  1
    rho_18    block_pair_neg_258  -1
    rho_18    block_pair_pos_279  -1
    rho_18    block_pair_neg_280  1
    rho_18    block_pair_pos_281  -1
    rho_18    block_pair_neg_282  1
    rho_18    block_pair_pos_283  -1
    rho_18    block_pair_neg_284  1
    rho_18    block_pair_pos_285  -1
    rho_18    block_pair_neg_286  1
    rho_18    block_pair_pos_287  -1
    rho_18    block_pair_neg_288  1
    rho_18    normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_3_0     OBJ       5.0078236648368350e-02
    x_3_0     product_lb_77  -4.1226319405776264e-02
    x_3_0     product_ub_78  -1.0590015128603633e-01
    x_3_0     onehot_3_111  1
    x_3_0     parent_nonstrict_scope_232  1.0015647329673670e-01
    x_3_0     unique_nonzero_owner_322  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_0     product_lb_77  1
    w_3_0     product_ub_78  1
    w_3_0     normalized_mass_3_112  1
    w_3_0     full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_1     OBJ       3.7558677486276261e-02
    x_3_1     product_lb_79  -4.1226319405776264e-02
    x_3_1     product_ub_80  -1.0590015128603633e-01
    x_3_1     onehot_3_111  1
    x_3_1     stock_lb_230  1
    x_3_1     stock_ub_231  1
    x_3_1     parent_nonstrict_scope_232  8.7636914134644611e-02
    x_3_1     unique_nonzero_owner_323  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_1     product_lb_79  1
    w_3_1     product_ub_80  1
    w_3_1     normalized_mass_3_112  1
    w_3_1     normalized_ratio_3_113  -0.125
    w_3_1     full_original_Gini_290  -8.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_2     OBJ       2.5039118324184172e-02
    x_3_2     product_lb_81  -4.1226319405776264e-02
    x_3_2     product_ub_82  -1.0590015128603633e-01
    x_3_2     onehot_3_111  1
    x_3_2     stock_lb_230  2
    x_3_2     stock_ub_231  2
    x_3_2     parent_nonstrict_scope_232  7.5117354972552522e-02
    x_3_2     unique_nonzero_owner_324  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_2     product_lb_81  1
    w_3_2     product_ub_82  1
    w_3_2     normalized_mass_3_112  1
    w_3_2     normalized_ratio_3_113  -0.25
    w_3_2     full_original_Gini_290  -7.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_3     OBJ       1.2519559162092082e-02
    x_3_3     product_lb_83  -4.1226319405776264e-02
    x_3_3     product_ub_84  -1.0590015128603633e-01
    x_3_3     onehot_3_111  1
    x_3_3     stock_lb_230  3
    x_3_3     stock_ub_231  3
    x_3_3     parent_nonstrict_scope_232  6.2597795810460433e-02
    x_3_3     unique_nonzero_owner_325  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_3     product_lb_83  1
    w_3_3     product_ub_84  1
    w_3_3     normalized_mass_3_112  1
    w_3_3     normalized_ratio_3_113  -0.375
    w_3_3     full_original_Gini_290  -7.1928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_4     product_lb_85  -4.1226319405776264e-02
    x_3_4     product_ub_86  -1.0590015128603633e-01
    x_3_4     onehot_3_111  1
    x_3_4     stock_lb_230  4
    x_3_4     stock_ub_231  4
    x_3_4     parent_nonstrict_scope_232  5.0078236648368350e-02
    x_3_4     unique_nonzero_owner_326  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_4     product_lb_85  1
    w_3_4     product_ub_86  1
    w_3_4     normalized_mass_3_112  1
    w_3_4     normalized_ratio_3_113  -0.5
    w_3_4     full_original_Gini_290  -6.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_5     OBJ       -1.2519559162092089e-02
    x_3_5     product_lb_87  -4.1226319405776264e-02
    x_3_5     product_ub_88  -1.0590015128603633e-01
    x_3_5     onehot_3_111  1
    x_3_5     stock_lb_230  5
    x_3_5     stock_ub_231  5
    x_3_5     parent_nonstrict_scope_232  3.7558677486276261e-02
    x_3_5     unique_nonzero_owner_327  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_5     product_lb_87  1
    w_3_5     product_ub_88  1
    w_3_5     normalized_mass_3_112  1
    w_3_5     normalized_ratio_3_113  -0.625
    w_3_5     full_original_Gini_290  -5.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_6     OBJ       -2.5039118324184175e-02
    x_3_6     product_lb_89  -4.1226319405776264e-02
    x_3_6     product_ub_90  -1.0590015128603633e-01
    x_3_6     onehot_3_111  1
    x_3_6     stock_lb_230  6
    x_3_6     stock_ub_231  6
    x_3_6     parent_nonstrict_scope_232  2.5039118324184175e-02
    x_3_6     unique_nonzero_owner_328  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_6     product_lb_89  1
    w_3_6     product_ub_90  1
    w_3_6     normalized_mass_3_112  1
    w_3_6     normalized_ratio_3_113  -0.75
    w_3_6     full_original_Gini_290  -4.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_7     OBJ       -3.7558677486276261e-02
    x_3_7     product_lb_91  -4.1226319405776264e-02
    x_3_7     product_ub_92  -1.0590015128603633e-01
    x_3_7     onehot_3_111  1
    x_3_7     stock_lb_230  7
    x_3_7     stock_ub_231  7
    x_3_7     parent_nonstrict_scope_232  1.2519559162092088e-02
    x_3_7     unique_nonzero_owner_329  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_7     product_lb_91  1
    w_3_7     product_ub_92  1
    w_3_7     normalized_mass_3_112  1
    w_3_7     normalized_ratio_3_113  -0.875
    w_3_7     full_original_Gini_290  -4.3428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_8     OBJ       -5.0078236648368350e-02
    x_3_8     product_lb_93  -4.1226319405776264e-02
    x_3_8     product_ub_94  -1.0590015128603633e-01
    x_3_8     onehot_3_111  1
    x_3_8     stock_lb_230  8
    x_3_8     stock_ub_231  8
    x_3_8     unique_nonzero_owner_330  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_8     product_lb_93  1
    w_3_8     product_ub_94  1
    w_3_8     normalized_mass_3_112  1
    w_3_8     normalized_ratio_3_113  -1
    w_3_8     full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_9     OBJ       -3.7558677486276261e-02
    x_3_9     product_lb_95  -4.1226319405776264e-02
    x_3_9     product_ub_96  -1.0590015128603633e-01
    x_3_9     onehot_3_111  1
    x_3_9     stock_lb_230  9
    x_3_9     stock_ub_231  9
    x_3_9     parent_nonstrict_scope_232  1.2519559162092088e-02
    x_3_9     unique_nonzero_owner_331  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_9     product_lb_95  1
    w_3_9     product_ub_96  1
    w_3_9     normalized_mass_3_112  1
    w_3_9     normalized_ratio_3_113  -1.125
    w_3_9     full_original_Gini_290  -4.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_10    OBJ       -2.5039118324184175e-02
    x_3_10    product_lb_97  -4.1226319405776264e-02
    x_3_10    product_ub_98  -1.0590015128603633e-01
    x_3_10    onehot_3_111  1
    x_3_10    stock_lb_230  10
    x_3_10    stock_ub_231  10
    x_3_10    parent_nonstrict_scope_232  2.5039118324184175e-02
    x_3_10    unique_nonzero_owner_332  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_10    product_lb_97  1
    w_3_10    product_ub_98  1
    w_3_10    normalized_mass_3_112  1
    w_3_10    normalized_ratio_3_113  -1.25
    w_3_10    full_original_Gini_290  -6.0571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_11    OBJ       -1.2519559162092089e-02
    x_3_11    product_lb_99  -4.1226319405776264e-02
    x_3_11    product_ub_100  -1.0590015128603633e-01
    x_3_11    onehot_3_111  1
    x_3_11    stock_lb_230  11
    x_3_11    stock_ub_231  11
    x_3_11    parent_nonstrict_scope_232  3.7558677486276261e-02
    x_3_11    unique_nonzero_owner_333  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_11    product_lb_99  1
    w_3_11    product_ub_100  1
    w_3_11    normalized_mass_3_112  1
    w_3_11    normalized_ratio_3_113  -1.375
    w_3_11    full_original_Gini_290  -7.3071428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_12    product_lb_101  -4.1226319405776264e-02
    x_3_12    product_ub_102  -1.0590015128603633e-01
    x_3_12    onehot_3_111  1
    x_3_12    stock_lb_230  12
    x_3_12    stock_ub_231  12
    x_3_12    parent_nonstrict_scope_232  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_3_12    product_lb_101  1
    w_3_12    product_ub_102  1
    w_3_12    normalized_mass_3_112  1
    w_3_12    normalized_ratio_3_113  -1.5
    w_3_12    full_original_Gini_290  -8.5571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_3_13    OBJ       1.2519559162092082e-02
    x_3_13    product_lb_103  -4.1226319405776264e-02
    x_3_13    product_ub_104  -1.0590015128603633e-01
    x_3_13    onehot_3_111  1
    x_3_13    stock_lb_230  13
    x_3_13    stock_ub_231  13
    x_3_13    parent_nonstrict_scope_232  6.2597795810460433e-02
    x_3_13    unique_nonzero_owner_334  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_13    product_lb_103  1
    w_3_13    product_ub_104  1
    w_3_13    normalized_mass_3_112  1
    w_3_13    normalized_ratio_3_113  -1.625
    w_3_13    full_original_Gini_290  -1.0057142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_14    OBJ       2.5039118324184172e-02
    x_3_14    product_lb_105  -4.1226319405776264e-02
    x_3_14    product_ub_106  -1.0590015128603633e-01
    x_3_14    onehot_3_111  1
    x_3_14    stock_lb_230  14
    x_3_14    stock_ub_231  14
    x_3_14    parent_nonstrict_scope_232  7.5117354972552522e-02
    x_3_14    unique_nonzero_owner_335  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_14    product_lb_105  1
    w_3_14    product_ub_106  1
    w_3_14    normalized_mass_3_112  1
    w_3_14    normalized_ratio_3_113  -1.75
    w_3_14    full_original_Gini_290  -1.1557142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_15    OBJ       3.7558677486276261e-02
    x_3_15    product_lb_107  -4.1226319405776264e-02
    x_3_15    product_ub_108  -1.0590015128603633e-01
    x_3_15    onehot_3_111  1
    x_3_15    stock_lb_230  15
    x_3_15    stock_ub_231  15
    x_3_15    parent_nonstrict_scope_232  8.7636914134644611e-02
    x_3_15    unique_nonzero_owner_336  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_15    product_lb_107  1
    w_3_15    product_ub_108  1
    w_3_15    normalized_mass_3_112  1
    w_3_15    normalized_ratio_3_113  -1.875
    w_3_15    full_original_Gini_290  -1.3057142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_3_16    OBJ       5.0078236648368350e-02
    x_3_16    product_lb_109  -4.1226319405776264e-02
    x_3_16    product_ub_110  -1.0590015128603633e-01
    x_3_16    onehot_3_111  1
    x_3_16    stock_lb_230  16
    x_3_16    stock_ub_231  16
    x_3_16    parent_nonstrict_scope_232  1.0015647329673670e-01
    x_3_16    unique_nonzero_owner_337  -1
    MARKER    'MARKER'                 'INTEND'
    w_3_16    product_lb_109  1
    w_3_16    product_ub_110  1
    w_3_16    normalized_mass_3_112  1
    w_3_16    normalized_ratio_3_113  -2
    w_3_16    full_original_Gini_290  -1.4557142857142857e+01
    rho_3     normalized_ratio_3_113  1
    rho_3     block_pair_pos_235  1
    rho_3     block_pair_neg_236  -1
    rho_3     block_pair_pos_247  1
    rho_3     block_pair_neg_248  -1
    rho_3     block_pair_pos_259  -1
    rho_3     block_pair_neg_260  1
    rho_3     block_pair_pos_261  -1
    rho_3     block_pair_neg_262  1
    rho_3     block_pair_pos_263  -1
    rho_3     block_pair_neg_264  1
    rho_3     block_pair_pos_265  -1
    rho_3     block_pair_neg_266  1
    rho_3     block_pair_pos_279  1
    rho_3     block_pair_neg_280  -1
    rho_3     normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_17_0    OBJ       6.3380304899829959e-02
    x_17_0    product_lb_114  -4.1226319405776264e-02
    x_17_0    product_ub_115  -1.0590015128603633e-01
    x_17_0    onehot_17_148  1
    x_17_0    parent_nonstrict_scope_232  1.2676060979965992e-01
    x_17_0    unique_nonzero_owner_338  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_0    product_lb_114  1
    w_17_0    product_ub_115  1
    w_17_0    normalized_mass_17_149  1
    w_17_0    full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_1    OBJ       4.9295792699867738e-02
    x_17_1    product_lb_116  -4.1226319405776264e-02
    x_17_1    product_ub_117  -1.0590015128603633e-01
    x_17_1    onehot_17_148  1
    x_17_1    stock_lb_230  1
    x_17_1    stock_ub_231  1
    x_17_1    parent_nonstrict_scope_232  1.1267609759969770e-01
    x_17_1    unique_nonzero_owner_339  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_1    product_lb_116  1
    w_17_1    product_ub_117  1
    w_17_1    normalized_mass_17_149  1
    w_17_1    normalized_ratio_17_150  -1.1111111111111110e-01
    w_17_1    full_original_Gini_290  -8.7761904761904770e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_2    OBJ       3.5211280499905531e-02
    x_17_2    product_lb_118  -4.1226319405776264e-02
    x_17_2    product_ub_119  -1.0590015128603633e-01
    x_17_2    onehot_17_148  1
    x_17_2    stock_lb_230  2
    x_17_2    stock_ub_231  2
    x_17_2    parent_nonstrict_scope_232  9.8591585399735490e-02
    x_17_2    unique_nonzero_owner_340  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_2    product_lb_118  1
    w_17_2    product_ub_119  1
    w_17_2    normalized_mass_17_149  1
    w_17_2    normalized_ratio_17_150  -2.2222222222222221e-01
    w_17_2    full_original_Gini_290  -8.10952380952381
    MARKER    'MARKER'                 'INTORG'
    x_17_3    OBJ       2.1126768299943324e-02
    x_17_3    product_lb_120  -4.1226319405776264e-02
    x_17_3    product_ub_121  -1.0590015128603633e-01
    x_17_3    onehot_17_148  1
    x_17_3    stock_lb_230  3
    x_17_3    stock_ub_231  3
    x_17_3    parent_nonstrict_scope_232  8.4507073199773283e-02
    MARKER    'MARKER'                 'INTEND'
    w_17_3    product_lb_120  1
    w_17_3    product_ub_121  1
    w_17_3    normalized_mass_17_149  1
    w_17_3    normalized_ratio_17_150  -3.3333333333333331e-01
    w_17_3    full_original_Gini_290  -7.4428571428571439e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_4    OBJ       7.0422560999811035e-03
    x_17_4    product_lb_122  -4.1226319405776264e-02
    x_17_4    product_ub_123  -1.0590015128603633e-01
    x_17_4    onehot_17_148  1
    x_17_4    stock_lb_230  4
    x_17_4    stock_ub_231  4
    x_17_4    parent_nonstrict_scope_232  7.0422560999811062e-02
    x_17_4    unique_nonzero_owner_341  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_4    product_lb_122  1
    w_17_4    product_ub_123  1
    w_17_4    normalized_mass_17_149  1
    w_17_4    normalized_ratio_17_150  -4.4444444444444442e-01
    w_17_4    full_original_Gini_290  -6.7761904761904761e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_5    OBJ       -0.00704225609998111
    x_17_5    product_lb_124  -4.1226319405776264e-02
    x_17_5    product_ub_125  -1.0590015128603633e-01
    x_17_5    onehot_17_148  1
    x_17_5    stock_lb_230  5
    x_17_5    stock_ub_231  5
    x_17_5    parent_nonstrict_scope_232  5.6338048799848849e-02
    x_17_5    unique_nonzero_owner_342  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_5    product_lb_124  1
    w_17_5    product_ub_125  1
    w_17_5    normalized_mass_17_149  1
    w_17_5    normalized_ratio_17_150  -5.5555555555555558e-01
    w_17_5    full_original_Gini_290  -6.10952380952381
    MARKER    'MARKER'                 'INTORG'
    x_17_6    OBJ       -2.1126768299943317e-02
    x_17_6    product_lb_126  -4.1226319405776264e-02
    x_17_6    product_ub_127  -1.0590015128603633e-01
    x_17_6    onehot_17_148  1
    x_17_6    stock_lb_230  6
    x_17_6    stock_ub_231  6
    x_17_6    parent_nonstrict_scope_232  4.2253536599886642e-02
    x_17_6    unique_nonzero_owner_343  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_6    product_lb_126  1
    w_17_6    product_ub_127  1
    w_17_6    normalized_mass_17_149  1
    w_17_6    normalized_ratio_17_150  -6.6666666666666663e-01
    w_17_6    full_original_Gini_290  -5.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_7    OBJ       -3.5211280499905517e-02
    x_17_7    product_lb_128  -4.1226319405776264e-02
    x_17_7    product_ub_129  -1.0590015128603633e-01
    x_17_7    onehot_17_148  1
    x_17_7    stock_lb_230  7
    x_17_7    stock_ub_231  7
    x_17_7    parent_nonstrict_scope_232  2.8169024399924438e-02
    x_17_7    unique_nonzero_owner_344  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_7    product_lb_128  1
    w_17_7    product_ub_129  1
    w_17_7    normalized_mass_17_149  1
    w_17_7    normalized_ratio_17_150  -7.7777777777777768e-01
    w_17_7    full_original_Gini_290  -4.7761904761904770e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_8    OBJ       -4.9295792699867738e-02
    x_17_8    product_lb_130  -4.1226319405776264e-02
    x_17_8    product_ub_131  -1.0590015128603633e-01
    x_17_8    onehot_17_148  1
    x_17_8    stock_lb_230  8
    x_17_8    stock_ub_231  8
    x_17_8    parent_nonstrict_scope_232  1.4084512199962219e-02
    x_17_8    unique_nonzero_owner_345  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_8    product_lb_130  1
    w_17_8    product_ub_131  1
    w_17_8    normalized_mass_17_149  1
    w_17_8    normalized_ratio_17_150  -8.8888888888888884e-01
    w_17_8    full_original_Gini_290  -4.2873015873015881e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_9    OBJ       -6.3380304899829959e-02
    x_17_9    product_lb_132  -4.1226319405776264e-02
    x_17_9    product_ub_133  -1.0590015128603633e-01
    x_17_9    onehot_17_148  1
    x_17_9    stock_lb_230  9
    x_17_9    stock_ub_231  9
    x_17_9    unique_nonzero_owner_346  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_9    product_lb_132  1
    w_17_9    product_ub_133  1
    w_17_9    normalized_mass_17_149  1
    w_17_9    normalized_ratio_17_150  -1
    w_17_9    full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_10   OBJ       -4.9295792699867738e-02
    x_17_10   product_lb_134  -4.1226319405776264e-02
    x_17_10   product_ub_135  -1.0590015128603633e-01
    x_17_10   onehot_17_148  1
    x_17_10   stock_lb_230  10
    x_17_10   stock_ub_231  10
    x_17_10   parent_nonstrict_scope_232  1.4084512199962219e-02
    x_17_10   unique_nonzero_owner_347  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_10   product_lb_134  1
    w_17_10   product_ub_135  1
    w_17_10   normalized_mass_17_149  1
    w_17_10   normalized_ratio_17_150  -1.1111111111111112e+00
    w_17_10   full_original_Gini_290  -4.7317460317460327e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_11   OBJ       -3.5211280499905545e-02
    x_17_11   product_lb_136  -4.1226319405776264e-02
    x_17_11   product_ub_137  -1.0590015128603633e-01
    x_17_11   onehot_17_148  1
    x_17_11   stock_lb_230  11
    x_17_11   stock_ub_231  11
    x_17_11   parent_nonstrict_scope_232  2.8169024399924410e-02
    x_17_11   unique_nonzero_owner_348  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_11   product_lb_136  1
    w_17_11   product_ub_137  1
    w_17_11   normalized_mass_17_149  1
    w_17_11   normalized_ratio_17_150  -1.2222222222222221e+00
    w_17_11   full_original_Gini_290  -5.7793650793650793e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_12   OBJ       -2.1126768299943331e-02
    x_17_12   product_lb_138  -4.1226319405776264e-02
    x_17_12   product_ub_139  -1.0590015128603633e-01
    x_17_12   onehot_17_148  1
    x_17_12   stock_lb_230  12
    x_17_12   stock_ub_231  12
    x_17_12   parent_nonstrict_scope_232  4.2253536599886628e-02
    x_17_12   unique_nonzero_owner_349  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_12   product_lb_138  1
    w_17_12   product_ub_139  1
    w_17_12   normalized_mass_17_149  1
    w_17_12   normalized_ratio_17_150  -1.3333333333333333e+00
    w_17_12   full_original_Gini_290  -6.8904761904761891e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_13   OBJ       -0.00704225609998111
    x_17_13   product_lb_140  -4.1226319405776264e-02
    x_17_13   product_ub_141  -1.0590015128603633e-01
    x_17_13   onehot_17_148  1
    x_17_13   stock_lb_230  13
    x_17_13   stock_ub_231  13
    x_17_13   parent_nonstrict_scope_232  5.6338048799848849e-02
    x_17_13   unique_nonzero_owner_350  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_13   product_lb_140  1
    w_17_13   product_ub_141  1
    w_17_13   normalized_mass_17_149  1
    w_17_13   normalized_ratio_17_150  -1.4444444444444444e+00
    w_17_13   full_original_Gini_290  -8.0015873015873034e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_14   OBJ       7.0422560999810757e-03
    x_17_14   product_lb_142  -4.1226319405776264e-02
    x_17_14   product_ub_143  -1.0590015128603633e-01
    x_17_14   onehot_17_148  1
    x_17_14   stock_lb_230  14
    x_17_14   stock_ub_231  14
    x_17_14   parent_nonstrict_scope_232  7.0422560999811035e-02
    x_17_14   unique_nonzero_owner_351  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_14   product_lb_142  1
    w_17_14   product_ub_143  1
    w_17_14   normalized_mass_17_149  1
    w_17_14   normalized_ratio_17_150  -1.5555555555555554e+00
    w_17_14   full_original_Gini_290  -9.2238095238095212e+00
    MARKER    'MARKER'                 'INTORG'
    x_17_15   OBJ       2.1126768299943297e-02
    x_17_15   product_lb_144  -4.1226319405776264e-02
    x_17_15   product_ub_145  -1.0590015128603633e-01
    x_17_15   onehot_17_148  1
    x_17_15   stock_lb_230  15
    x_17_15   stock_ub_231  15
    x_17_15   parent_nonstrict_scope_232  8.4507073199773255e-02
    x_17_15   unique_nonzero_owner_352  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_15   product_lb_144  1
    w_17_15   product_ub_145  1
    w_17_15   normalized_mass_17_149  1
    w_17_15   normalized_ratio_17_150  -1.6666666666666665e+00
    w_17_15   full_original_Gini_290  -1.0557142857142853e+01
    MARKER    'MARKER'                 'INTORG'
    x_17_16   OBJ       3.5211280499905517e-02
    x_17_16   product_lb_146  -4.1226319405776264e-02
    x_17_16   product_ub_147  -1.0590015128603633e-01
    x_17_16   onehot_17_148  1
    x_17_16   stock_lb_230  16
    x_17_16   stock_ub_231  16
    x_17_16   parent_nonstrict_scope_232  9.8591585399735476e-02
    x_17_16   unique_nonzero_owner_353  -1
    MARKER    'MARKER'                 'INTEND'
    w_17_16   product_lb_146  1
    w_17_16   product_ub_147  1
    w_17_16   normalized_mass_17_149  1
    w_17_16   normalized_ratio_17_150  -1.7777777777777777e+00
    w_17_16   full_original_Gini_290  -1.1890476190476193e+01
    rho_17    normalized_ratio_17_150  1
    rho_17    block_pair_pos_243  1
    rho_17    block_pair_neg_244  -1
    rho_17    block_pair_pos_255  1
    rho_17    block_pair_neg_256  -1
    rho_17    block_pair_pos_265  1
    rho_17    block_pair_neg_266  -1
    rho_17    block_pair_pos_273  -1
    rho_17    block_pair_neg_274  1
    rho_17    block_pair_pos_275  -1
    rho_17    block_pair_neg_276  1
    rho_17    block_pair_pos_277  -1
    rho_17    block_pair_neg_278  1
    rho_17    block_pair_pos_287  1
    rho_17    block_pair_neg_288  -1
    rho_17    normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_4_0     OBJ       5.0078236648368350e-02
    x_4_0     product_lb_151  -4.1226319405776264e-02
    x_4_0     product_ub_152  -1.0590015128603633e-01
    x_4_0     onehot_4_183  1
    x_4_0     parent_nonstrict_scope_232  1.0015647329673670e-01
    x_4_0     unique_nonzero_owner_354  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_0     product_lb_151  1
    w_4_0     product_ub_152  1
    w_4_0     normalized_mass_4_184  1
    w_4_0     full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_1     OBJ       3.7558677486276261e-02
    x_4_1     product_lb_153  -4.1226319405776264e-02
    x_4_1     product_ub_154  -1.0590015128603633e-01
    x_4_1     onehot_4_183  1
    x_4_1     stock_lb_230  1
    x_4_1     stock_ub_231  1
    x_4_1     parent_nonstrict_scope_232  8.7636914134644611e-02
    x_4_1     unique_nonzero_owner_355  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_1     product_lb_153  1
    w_4_1     product_ub_154  1
    w_4_1     normalized_mass_4_184  1
    w_4_1     normalized_ratio_4_185  -0.125
    w_4_1     full_original_Gini_290  -8.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_2     OBJ       2.5039118324184172e-02
    x_4_2     product_lb_155  -4.1226319405776264e-02
    x_4_2     product_ub_156  -1.0590015128603633e-01
    x_4_2     onehot_4_183  1
    x_4_2     stock_lb_230  2
    x_4_2     stock_ub_231  2
    x_4_2     parent_nonstrict_scope_232  7.5117354972552522e-02
    x_4_2     unique_nonzero_owner_356  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_2     product_lb_155  1
    w_4_2     product_ub_156  1
    w_4_2     normalized_mass_4_184  1
    w_4_2     normalized_ratio_4_185  -0.25
    w_4_2     full_original_Gini_290  -7.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_3     OBJ       1.2519559162092082e-02
    x_4_3     product_lb_157  -4.1226319405776264e-02
    x_4_3     product_ub_158  -1.0590015128603633e-01
    x_4_3     onehot_4_183  1
    x_4_3     stock_lb_230  3
    x_4_3     stock_ub_231  3
    x_4_3     parent_nonstrict_scope_232  6.2597795810460433e-02
    x_4_3     unique_nonzero_owner_357  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_3     product_lb_157  1
    w_4_3     product_ub_158  1
    w_4_3     normalized_mass_4_184  1
    w_4_3     normalized_ratio_4_185  -0.375
    w_4_3     full_original_Gini_290  -7.1928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_4     product_lb_159  -4.1226319405776264e-02
    x_4_4     product_ub_160  -1.0590015128603633e-01
    x_4_4     onehot_4_183  1
    x_4_4     stock_lb_230  4
    x_4_4     stock_ub_231  4
    x_4_4     parent_nonstrict_scope_232  5.0078236648368350e-02
    x_4_4     unique_nonzero_owner_358  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_4     product_lb_159  1
    w_4_4     product_ub_160  1
    w_4_4     normalized_mass_4_184  1
    w_4_4     normalized_ratio_4_185  -0.5
    w_4_4     full_original_Gini_290  -6.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_5     OBJ       -1.2519559162092089e-02
    x_4_5     product_lb_161  -4.1226319405776264e-02
    x_4_5     product_ub_162  -1.0590015128603633e-01
    x_4_5     onehot_4_183  1
    x_4_5     stock_lb_230  5
    x_4_5     stock_ub_231  5
    x_4_5     parent_nonstrict_scope_232  3.7558677486276261e-02
    x_4_5     unique_nonzero_owner_359  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_5     product_lb_161  1
    w_4_5     product_ub_162  1
    w_4_5     normalized_mass_4_184  1
    w_4_5     normalized_ratio_4_185  -0.625
    w_4_5     full_original_Gini_290  -5.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_6     OBJ       -2.5039118324184175e-02
    x_4_6     product_lb_163  -4.1226319405776264e-02
    x_4_6     product_ub_164  -1.0590015128603633e-01
    x_4_6     onehot_4_183  1
    x_4_6     stock_lb_230  6
    x_4_6     stock_ub_231  6
    x_4_6     parent_nonstrict_scope_232  2.5039118324184175e-02
    x_4_6     unique_nonzero_owner_360  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_6     product_lb_163  1
    w_4_6     product_ub_164  1
    w_4_6     normalized_mass_4_184  1
    w_4_6     normalized_ratio_4_185  -0.75
    w_4_6     full_original_Gini_290  -4.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_7     OBJ       -3.7558677486276261e-02
    x_4_7     product_lb_165  -4.1226319405776264e-02
    x_4_7     product_ub_166  -1.0590015128603633e-01
    x_4_7     onehot_4_183  1
    x_4_7     stock_lb_230  7
    x_4_7     stock_ub_231  7
    x_4_7     parent_nonstrict_scope_232  1.2519559162092088e-02
    x_4_7     unique_nonzero_owner_361  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_7     product_lb_165  1
    w_4_7     product_ub_166  1
    w_4_7     normalized_mass_4_184  1
    w_4_7     normalized_ratio_4_185  -0.875
    w_4_7     full_original_Gini_290  -4.3428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_8     OBJ       -5.0078236648368350e-02
    x_4_8     product_lb_167  -4.1226319405776264e-02
    x_4_8     product_ub_168  -1.0590015128603633e-01
    x_4_8     onehot_4_183  1
    x_4_8     stock_lb_230  8
    x_4_8     stock_ub_231  8
    x_4_8     unique_nonzero_owner_362  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_8     product_lb_167  1
    w_4_8     product_ub_168  1
    w_4_8     normalized_mass_4_184  1
    w_4_8     normalized_ratio_4_185  -1
    w_4_8     full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_9     OBJ       -3.7558677486276261e-02
    x_4_9     product_lb_169  -4.1226319405776264e-02
    x_4_9     product_ub_170  -1.0590015128603633e-01
    x_4_9     onehot_4_183  1
    x_4_9     stock_lb_230  9
    x_4_9     stock_ub_231  9
    x_4_9     parent_nonstrict_scope_232  1.2519559162092088e-02
    x_4_9     unique_nonzero_owner_363  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_9     product_lb_169  1
    w_4_9     product_ub_170  1
    w_4_9     normalized_mass_4_184  1
    w_4_9     normalized_ratio_4_185  -1.125
    w_4_9     full_original_Gini_290  -4.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_10    OBJ       -2.5039118324184175e-02
    x_4_10    product_lb_171  -4.1226319405776264e-02
    x_4_10    product_ub_172  -1.0590015128603633e-01
    x_4_10    onehot_4_183  1
    x_4_10    stock_lb_230  10
    x_4_10    stock_ub_231  10
    x_4_10    parent_nonstrict_scope_232  2.5039118324184175e-02
    x_4_10    unique_nonzero_owner_364  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_10    product_lb_171  1
    w_4_10    product_ub_172  1
    w_4_10    normalized_mass_4_184  1
    w_4_10    normalized_ratio_4_185  -1.25
    w_4_10    full_original_Gini_290  -6.0571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_11    OBJ       -1.2519559162092089e-02
    x_4_11    product_lb_173  -4.1226319405776264e-02
    x_4_11    product_ub_174  -1.0590015128603633e-01
    x_4_11    onehot_4_183  1
    x_4_11    stock_lb_230  11
    x_4_11    stock_ub_231  11
    x_4_11    parent_nonstrict_scope_232  3.7558677486276261e-02
    x_4_11    unique_nonzero_owner_365  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_11    product_lb_173  1
    w_4_11    product_ub_174  1
    w_4_11    normalized_mass_4_184  1
    w_4_11    normalized_ratio_4_185  -1.375
    w_4_11    full_original_Gini_290  -7.3071428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_12    product_lb_175  -4.1226319405776264e-02
    x_4_12    product_ub_176  -1.0590015128603633e-01
    x_4_12    onehot_4_183  1
    x_4_12    stock_lb_230  12
    x_4_12    stock_ub_231  12
    x_4_12    parent_nonstrict_scope_232  5.0078236648368350e-02
    MARKER    'MARKER'                 'INTEND'
    w_4_12    product_lb_175  1
    w_4_12    product_ub_176  1
    w_4_12    normalized_mass_4_184  1
    w_4_12    normalized_ratio_4_185  -1.5
    w_4_12    full_original_Gini_290  -8.5571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_4_13    OBJ       1.2519559162092082e-02
    x_4_13    product_lb_177  -4.1226319405776264e-02
    x_4_13    product_ub_178  -1.0590015128603633e-01
    x_4_13    onehot_4_183  1
    x_4_13    stock_lb_230  13
    x_4_13    stock_ub_231  13
    x_4_13    parent_nonstrict_scope_232  6.2597795810460433e-02
    x_4_13    unique_nonzero_owner_366  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_13    product_lb_177  1
    w_4_13    product_ub_178  1
    w_4_13    normalized_mass_4_184  1
    w_4_13    normalized_ratio_4_185  -1.625
    w_4_13    full_original_Gini_290  -1.0057142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_14    OBJ       2.5039118324184172e-02
    x_4_14    product_lb_179  -4.1226319405776264e-02
    x_4_14    product_ub_180  -1.0590015128603633e-01
    x_4_14    onehot_4_183  1
    x_4_14    stock_lb_230  14
    x_4_14    stock_ub_231  14
    x_4_14    parent_nonstrict_scope_232  7.5117354972552522e-02
    x_4_14    unique_nonzero_owner_367  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_14    product_lb_179  1
    w_4_14    product_ub_180  1
    w_4_14    normalized_mass_4_184  1
    w_4_14    normalized_ratio_4_185  -1.75
    w_4_14    full_original_Gini_290  -1.1557142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_4_15    OBJ       3.7558677486276261e-02
    x_4_15    product_lb_181  -4.1226319405776264e-02
    x_4_15    product_ub_182  -1.0590015128603633e-01
    x_4_15    onehot_4_183  1
    x_4_15    stock_lb_230  15
    x_4_15    stock_ub_231  15
    x_4_15    parent_nonstrict_scope_232  8.7636914134644611e-02
    x_4_15    unique_nonzero_owner_368  -1
    MARKER    'MARKER'                 'INTEND'
    w_4_15    product_lb_181  1
    w_4_15    product_ub_182  1
    w_4_15    normalized_mass_4_184  1
    w_4_15    normalized_ratio_4_185  -1.875
    w_4_15    full_original_Gini_290  -1.3057142857142857e+01
    rho_4     normalized_ratio_4_185  1
    rho_4     block_pair_pos_237  1
    rho_4     block_pair_neg_238  -1
    rho_4     block_pair_pos_249  1
    rho_4     block_pair_neg_250  -1
    rho_4     block_pair_pos_259  1
    rho_4     block_pair_neg_260  -1
    rho_4     block_pair_pos_267  -1
    rho_4     block_pair_neg_268  1
    rho_4     block_pair_pos_269  -1
    rho_4     block_pair_neg_270  1
    rho_4     block_pair_pos_273  1
    rho_4     block_pair_neg_274  -1
    rho_4     block_pair_pos_281  1
    rho_4     block_pair_neg_282  -1
    rho_4     normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_11_0    OBJ       5.0078236648368350e-02
    x_11_0    product_lb_186  -4.1226319405776264e-02
    x_11_0    product_ub_187  -1.0590015128603633e-01
    x_11_0    onehot_11_218  1
    x_11_0    parent_nonstrict_scope_232  1.0015647329673670e-01
    x_11_0    unique_nonzero_owner_369  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_0    product_lb_186  1
    w_11_0    product_ub_187  1
    w_11_0    normalized_mass_11_219  1
    w_11_0    full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_1    OBJ       3.7558677486276261e-02
    x_11_1    product_lb_188  -4.1226319405776264e-02
    x_11_1    product_ub_189  -1.0590015128603633e-01
    x_11_1    onehot_11_218  1
    x_11_1    stock_lb_230  1
    x_11_1    stock_ub_231  1
    x_11_1    parent_nonstrict_scope_232  8.7636914134644611e-02
    MARKER    'MARKER'                 'INTEND'
    w_11_1    product_lb_188  1
    w_11_1    product_ub_189  1
    w_11_1    normalized_mass_11_219  1
    w_11_1    normalized_ratio_11_220  -0.125
    w_11_1    full_original_Gini_290  -8.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_2    OBJ       2.5039118324184172e-02
    x_11_2    product_lb_190  -4.1226319405776264e-02
    x_11_2    product_ub_191  -1.0590015128603633e-01
    x_11_2    onehot_11_218  1
    x_11_2    stock_lb_230  2
    x_11_2    stock_ub_231  2
    x_11_2    parent_nonstrict_scope_232  7.5117354972552522e-02
    x_11_2    unique_nonzero_owner_370  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_2    product_lb_190  1
    w_11_2    product_ub_191  1
    w_11_2    normalized_mass_11_219  1
    w_11_2    normalized_ratio_11_220  -0.25
    w_11_2    full_original_Gini_290  -7.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_3    OBJ       1.2519559162092082e-02
    x_11_3    product_lb_192  -4.1226319405776264e-02
    x_11_3    product_ub_193  -1.0590015128603633e-01
    x_11_3    onehot_11_218  1
    x_11_3    stock_lb_230  3
    x_11_3    stock_ub_231  3
    x_11_3    parent_nonstrict_scope_232  6.2597795810460433e-02
    x_11_3    unique_nonzero_owner_371  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_3    product_lb_192  1
    w_11_3    product_ub_193  1
    w_11_3    normalized_mass_11_219  1
    w_11_3    normalized_ratio_11_220  -0.375
    w_11_3    full_original_Gini_290  -7.1928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_4    product_lb_194  -4.1226319405776264e-02
    x_11_4    product_ub_195  -1.0590015128603633e-01
    x_11_4    onehot_11_218  1
    x_11_4    stock_lb_230  4
    x_11_4    stock_ub_231  4
    x_11_4    parent_nonstrict_scope_232  5.0078236648368350e-02
    x_11_4    unique_nonzero_owner_372  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_4    product_lb_194  1
    w_11_4    product_ub_195  1
    w_11_4    normalized_mass_11_219  1
    w_11_4    normalized_ratio_11_220  -0.5
    w_11_4    full_original_Gini_290  -6.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_5    OBJ       -1.2519559162092089e-02
    x_11_5    product_lb_196  -4.1226319405776264e-02
    x_11_5    product_ub_197  -1.0590015128603633e-01
    x_11_5    onehot_11_218  1
    x_11_5    stock_lb_230  5
    x_11_5    stock_ub_231  5
    x_11_5    parent_nonstrict_scope_232  3.7558677486276261e-02
    x_11_5    unique_nonzero_owner_373  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_5    product_lb_196  1
    w_11_5    product_ub_197  1
    w_11_5    normalized_mass_11_219  1
    w_11_5    normalized_ratio_11_220  -0.625
    w_11_5    full_original_Gini_290  -5.6928571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_6    OBJ       -2.5039118324184175e-02
    x_11_6    product_lb_198  -4.1226319405776264e-02
    x_11_6    product_ub_199  -1.0590015128603633e-01
    x_11_6    onehot_11_218  1
    x_11_6    stock_lb_230  6
    x_11_6    stock_ub_231  6
    x_11_6    parent_nonstrict_scope_232  2.5039118324184175e-02
    x_11_6    unique_nonzero_owner_374  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_6    product_lb_198  1
    w_11_6    product_ub_199  1
    w_11_6    normalized_mass_11_219  1
    w_11_6    normalized_ratio_11_220  -0.75
    w_11_6    full_original_Gini_290  -4.9428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_7    OBJ       -3.7558677486276261e-02
    x_11_7    product_lb_200  -4.1226319405776264e-02
    x_11_7    product_ub_201  -1.0590015128603633e-01
    x_11_7    onehot_11_218  1
    x_11_7    stock_lb_230  7
    x_11_7    stock_ub_231  7
    x_11_7    parent_nonstrict_scope_232  1.2519559162092088e-02
    x_11_7    unique_nonzero_owner_375  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_7    product_lb_200  1
    w_11_7    product_ub_201  1
    w_11_7    normalized_mass_11_219  1
    w_11_7    normalized_ratio_11_220  -0.875
    w_11_7    full_original_Gini_290  -4.3428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_8    OBJ       -5.0078236648368350e-02
    x_11_8    product_lb_202  -4.1226319405776264e-02
    x_11_8    product_ub_203  -1.0590015128603633e-01
    x_11_8    onehot_11_218  1
    x_11_8    stock_lb_230  8
    x_11_8    stock_ub_231  8
    x_11_8    unique_nonzero_owner_376  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_8    product_lb_202  1
    w_11_8    product_ub_203  1
    w_11_8    normalized_mass_11_219  1
    w_11_8    normalized_ratio_11_220  -1
    w_11_8    full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_9    OBJ       -3.7558677486276261e-02
    x_11_9    product_lb_204  -4.1226319405776264e-02
    x_11_9    product_ub_205  -1.0590015128603633e-01
    x_11_9    onehot_11_218  1
    x_11_9    stock_lb_230  9
    x_11_9    stock_ub_231  9
    x_11_9    parent_nonstrict_scope_232  1.2519559162092088e-02
    x_11_9    unique_nonzero_owner_377  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_9    product_lb_204  1
    w_11_9    product_ub_205  1
    w_11_9    normalized_mass_11_219  1
    w_11_9    normalized_ratio_11_220  -1.125
    w_11_9    full_original_Gini_290  -4.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_10   OBJ       -2.5039118324184175e-02
    x_11_10   product_lb_206  -4.1226319405776264e-02
    x_11_10   product_ub_207  -1.0590015128603633e-01
    x_11_10   onehot_11_218  1
    x_11_10   stock_lb_230  10
    x_11_10   stock_ub_231  10
    x_11_10   parent_nonstrict_scope_232  2.5039118324184175e-02
    x_11_10   unique_nonzero_owner_378  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_10   product_lb_206  1
    w_11_10   product_ub_207  1
    w_11_10   normalized_mass_11_219  1
    w_11_10   normalized_ratio_11_220  -1.25
    w_11_10   full_original_Gini_290  -6.0571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_11   OBJ       -1.2519559162092089e-02
    x_11_11   product_lb_208  -4.1226319405776264e-02
    x_11_11   product_ub_209  -1.0590015128603633e-01
    x_11_11   onehot_11_218  1
    x_11_11   stock_lb_230  11
    x_11_11   stock_ub_231  11
    x_11_11   parent_nonstrict_scope_232  3.7558677486276261e-02
    x_11_11   unique_nonzero_owner_379  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_11   product_lb_208  1
    w_11_11   product_ub_209  1
    w_11_11   normalized_mass_11_219  1
    w_11_11   normalized_ratio_11_220  -1.375
    w_11_11   full_original_Gini_290  -7.3071428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_12   product_lb_210  -4.1226319405776264e-02
    x_11_12   product_ub_211  -1.0590015128603633e-01
    x_11_12   onehot_11_218  1
    x_11_12   stock_lb_230  12
    x_11_12   stock_ub_231  12
    x_11_12   parent_nonstrict_scope_232  5.0078236648368350e-02
    x_11_12   unique_nonzero_owner_380  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_12   product_lb_210  1
    w_11_12   product_ub_211  1
    w_11_12   normalized_mass_11_219  1
    w_11_12   normalized_ratio_11_220  -1.5
    w_11_12   full_original_Gini_290  -8.5571428571428569e+00
    MARKER    'MARKER'                 'INTORG'
    x_11_13   OBJ       1.2519559162092082e-02
    x_11_13   product_lb_212  -4.1226319405776264e-02
    x_11_13   product_ub_213  -1.0590015128603633e-01
    x_11_13   onehot_11_218  1
    x_11_13   stock_lb_230  13
    x_11_13   stock_ub_231  13
    x_11_13   parent_nonstrict_scope_232  6.2597795810460433e-02
    x_11_13   unique_nonzero_owner_381  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_13   product_lb_212  1
    w_11_13   product_ub_213  1
    w_11_13   normalized_mass_11_219  1
    w_11_13   normalized_ratio_11_220  -1.625
    w_11_13   full_original_Gini_290  -1.0057142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_14   OBJ       2.5039118324184172e-02
    x_11_14   product_lb_214  -4.1226319405776264e-02
    x_11_14   product_ub_215  -1.0590015128603633e-01
    x_11_14   onehot_11_218  1
    x_11_14   stock_lb_230  14
    x_11_14   stock_ub_231  14
    x_11_14   parent_nonstrict_scope_232  7.5117354972552522e-02
    x_11_14   unique_nonzero_owner_382  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_14   product_lb_214  1
    w_11_14   product_ub_215  1
    w_11_14   normalized_mass_11_219  1
    w_11_14   normalized_ratio_11_220  -1.75
    w_11_14   full_original_Gini_290  -1.1557142857142857e+01
    MARKER    'MARKER'                 'INTORG'
    x_11_15   OBJ       3.7558677486276261e-02
    x_11_15   product_lb_216  -4.1226319405776264e-02
    x_11_15   product_ub_217  -1.0590015128603633e-01
    x_11_15   onehot_11_218  1
    x_11_15   stock_lb_230  15
    x_11_15   stock_ub_231  15
    x_11_15   parent_nonstrict_scope_232  8.7636914134644611e-02
    x_11_15   unique_nonzero_owner_383  -1
    MARKER    'MARKER'                 'INTEND'
    w_11_15   product_lb_216  1
    w_11_15   product_ub_217  1
    w_11_15   normalized_mass_11_219  1
    w_11_15   normalized_ratio_11_220  -1.875
    w_11_15   full_original_Gini_290  -1.3057142857142857e+01
    rho_11    normalized_ratio_11_220  1
    rho_11    block_pair_pos_241  1
    rho_11    block_pair_neg_242  -1
    rho_11    block_pair_pos_253  1
    rho_11    block_pair_neg_254  -1
    rho_11    block_pair_pos_263  1
    rho_11    block_pair_neg_264  -1
    rho_11    block_pair_pos_269  1
    rho_11    block_pair_neg_270  -1
    rho_11    block_pair_pos_271  -1
    rho_11    block_pair_neg_272  1
    rho_11    block_pair_pos_277  1
    rho_11    block_pair_neg_278  -1
    rho_11    block_pair_pos_285  1
    rho_11    block_pair_neg_286  -1
    rho_11    normalization_289  1
    MARKER    'MARKER'                 'INTORG'
    x_5_0     OBJ       6.3380304899829966e-03
    x_5_0     product_lb_221  -4.1226319405776264e-02
    x_5_0     product_ub_222  -1.0590015128603633e-01
    x_5_0     onehot_5_227  1
    x_5_0     parent_nonstrict_scope_232  1.2676060979965993e-02
    MARKER    'MARKER'                 'INTEND'
    w_5_0     product_lb_221  1
    w_5_0     product_ub_222  1
    w_5_0     normalized_mass_5_228  1
    w_5_0     full_original_Gini_290  -9.4428571428571431e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_1     OBJ       -6.3380304899829966e-03
    x_5_1     product_lb_223  -4.1226319405776264e-02
    x_5_1     product_ub_224  -1.0590015128603633e-01
    x_5_1     onehot_5_227  1
    x_5_1     stock_lb_230  1
    x_5_1     stock_ub_231  1
    x_5_1     unique_nonzero_owner_384  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_1     product_lb_223  1
    w_5_1     product_ub_224  1
    w_5_1     normalized_mass_5_228  1
    w_5_1     normalized_ratio_5_229  -1
    w_5_1     full_original_Gini_290  -3.8428571428571425e+00
    MARKER    'MARKER'                 'INTORG'
    x_5_2     OBJ       6.3380304899829966e-03
    x_5_2     product_lb_225  -4.1226319405776264e-02
    x_5_2     product_ub_226  -1.0590015128603633e-01
    x_5_2     onehot_5_227  1
    x_5_2     stock_lb_230  2
    x_5_2     stock_ub_231  2
    x_5_2     parent_nonstrict_scope_232  1.2676060979965993e-02
    x_5_2     unique_nonzero_owner_385  -1
    MARKER    'MARKER'                 'INTEND'
    w_5_2     product_lb_225  1
    w_5_2     product_ub_226  1
    w_5_2     normalized_mass_5_228  1
    w_5_2     normalized_ratio_5_229  -2
    w_5_2     full_original_Gini_290  -1.4557142857142857e+01
    rho_5     normalized_ratio_5_229  1
    rho_5     block_pair_pos_239  1
    rho_5     block_pair_neg_240  -1
    rho_5     block_pair_pos_251  1
    rho_5     block_pair_neg_252  -1
    rho_5     block_pair_pos_261  1
    rho_5     block_pair_neg_262  -1
    rho_5     block_pair_pos_267  1
    rho_5     block_pair_neg_268  -1
    rho_5     block_pair_pos_271  1
    rho_5     block_pair_neg_272  -1
    rho_5     block_pair_pos_275  1
    rho_5     block_pair_neg_276  -1
    rho_5     block_pair_pos_283  1
    rho_5     block_pair_neg_284  -1
    rho_5     normalization_289  1
    a_1_2     block_pair_pos_233  1
    a_1_2     block_pair_neg_234  1
    a_1_2     full_original_Gini_290  -1
    a_1_18    block_pair_pos_245  1
    a_1_18    block_pair_neg_246  1
    a_1_18    full_original_Gini_290  -1
    a_1_3     block_pair_pos_235  1
    a_1_3     block_pair_neg_236  1
    a_1_3     full_original_Gini_290  -1
    a_1_17    block_pair_pos_243  1
    a_1_17    block_pair_neg_244  1
    a_1_17    full_original_Gini_290  -1
    a_1_4     block_pair_pos_237  1
    a_1_4     block_pair_neg_238  1
    a_1_4     full_original_Gini_290  -1
    a_1_11    block_pair_pos_241  1
    a_1_11    block_pair_neg_242  1
    a_1_11    full_original_Gini_290  -1
    a_1_5     block_pair_pos_239  1
    a_1_5     block_pair_neg_240  1
    a_1_5     full_original_Gini_290  -1
    a_2_18    block_pair_pos_257  1
    a_2_18    block_pair_neg_258  1
    a_2_18    full_original_Gini_290  -1
    a_2_3     block_pair_pos_247  1
    a_2_3     block_pair_neg_248  1
    a_2_3     full_original_Gini_290  -1
    a_2_17    block_pair_pos_255  1
    a_2_17    block_pair_neg_256  1
    a_2_17    full_original_Gini_290  -1
    a_2_4     block_pair_pos_249  1
    a_2_4     block_pair_neg_250  1
    a_2_4     full_original_Gini_290  -1
    a_2_11    block_pair_pos_253  1
    a_2_11    block_pair_neg_254  1
    a_2_11    full_original_Gini_290  -1
    a_2_5     block_pair_pos_251  1
    a_2_5     block_pair_neg_252  1
    a_2_5     full_original_Gini_290  -1
    a_18_3    block_pair_pos_279  1
    a_18_3    block_pair_neg_280  1
    a_18_3    full_original_Gini_290  -1
    a_18_17   block_pair_pos_287  1
    a_18_17   block_pair_neg_288  1
    a_18_17   full_original_Gini_290  -1
    a_18_4    block_pair_pos_281  1
    a_18_4    block_pair_neg_282  1
    a_18_4    full_original_Gini_290  -1
    a_18_11   block_pair_pos_285  1
    a_18_11   block_pair_neg_286  1
    a_18_11   full_original_Gini_290  -1
    a_18_5    block_pair_pos_283  1
    a_18_5    block_pair_neg_284  1
    a_18_5    full_original_Gini_290  -1
    a_3_17    block_pair_pos_265  1
    a_3_17    block_pair_neg_266  1
    a_3_17    full_original_Gini_290  -1
    a_3_4     block_pair_pos_259  1
    a_3_4     block_pair_neg_260  1
    a_3_4     full_original_Gini_290  -1
    a_3_11    block_pair_pos_263  1
    a_3_11    block_pair_neg_264  1
    a_3_11    full_original_Gini_290  -1
    a_3_5     block_pair_pos_261  1
    a_3_5     block_pair_neg_262  1
    a_3_5     full_original_Gini_290  -1
    a_17_4    block_pair_pos_273  1
    a_17_4    block_pair_neg_274  1
    a_17_4    full_original_Gini_290  -1
    a_17_11   block_pair_pos_277  1
    a_17_11   block_pair_neg_278  1
    a_17_11   full_original_Gini_290  -1
    a_17_5    block_pair_pos_275  1
    a_17_5    block_pair_neg_276  1
    a_17_5    full_original_Gini_290  -1
    a_4_11    block_pair_pos_269  1
    a_4_11    block_pair_neg_270  1
    a_4_11    full_original_Gini_290  -1
    a_4_5     block_pair_pos_267  1
    a_4_5     block_pair_neg_268  1
    a_4_5     full_original_Gini_290  -1
    a_11_5    block_pair_pos_271  1
    a_11_5    block_pair_neg_272  1
    a_11_5    full_original_Gini_290  -1
    MARKER    'MARKER'                 'INTORG'
    service_0_1_0  unique_nonzero_owner_291  1
    service_0_1_0  service_visit_def_766  1
    service_0_1_0  free_load_conservation_767  -1
    service_0_1_0  original_T_including_depot_unload_814  120
    service_0_1_2  unique_nonzero_owner_292  1
    service_0_1_2  service_visit_def_766  1
    service_0_1_2  free_load_conservation_767  1
    service_0_1_3  unique_nonzero_owner_293  1
    service_0_1_3  service_visit_def_766  1
    service_0_1_3  free_load_conservation_767  2
    service_0_1_4  unique_nonzero_owner_294  1
    service_0_1_4  service_visit_def_766  1
    service_0_1_4  free_load_conservation_767  3
    service_0_1_5  unique_nonzero_owner_295  1
    service_0_1_5  service_visit_def_766  1
    service_0_1_5  free_load_conservation_767  4
    service_0_1_6  unique_nonzero_owner_296  1
    service_0_1_6  service_visit_def_766  1
    service_0_1_6  free_load_conservation_767  5
    service_0_1_7  unique_nonzero_owner_297  1
    service_0_1_7  service_visit_def_766  1
    service_0_1_7  free_load_conservation_767  6
    service_0_1_8  unique_nonzero_owner_298  1
    service_0_1_8  service_visit_def_766  1
    service_0_1_8  free_load_conservation_767  7
    service_0_1_9  unique_nonzero_owner_299  1
    service_0_1_9  service_visit_def_766  1
    service_0_1_9  free_load_conservation_767  8
    service_0_1_10  unique_nonzero_owner_300  1
    service_0_1_10  service_visit_def_766  1
    service_0_1_10  free_load_conservation_767  9
    service_0_1_11  unique_nonzero_owner_301  1
    service_0_1_11  service_visit_def_766  1
    service_0_1_11  free_load_conservation_767  10
    service_0_1_12  unique_nonzero_owner_302  1
    service_0_1_12  service_visit_def_766  1
    service_0_1_12  free_load_conservation_767  11
    service_0_1_13  unique_nonzero_owner_303  1
    service_0_1_13  service_visit_def_766  1
    service_0_1_13  free_load_conservation_767  12
    service_0_1_14  unique_nonzero_owner_304  1
    service_0_1_14  service_visit_def_766  1
    service_0_1_14  free_load_conservation_767  13
    service_0_1_15  unique_nonzero_owner_305  1
    service_0_1_15  service_visit_def_766  1
    service_0_1_15  free_load_conservation_767  14
    service_1_1_0  unique_nonzero_owner_291  1
    service_1_1_0  service_visit_def_1036  1
    service_1_1_0  free_load_conservation_1037  -1
    service_1_1_0  original_T_including_depot_unload_1081  120
    service_1_1_2  unique_nonzero_owner_292  1
    service_1_1_2  service_visit_def_1036  1
    service_1_1_2  free_load_conservation_1037  1
    service_1_1_3  unique_nonzero_owner_293  1
    service_1_1_3  service_visit_def_1036  1
    service_1_1_3  free_load_conservation_1037  2
    service_1_1_4  unique_nonzero_owner_294  1
    service_1_1_4  service_visit_def_1036  1
    service_1_1_4  free_load_conservation_1037  3
    service_1_1_5  unique_nonzero_owner_295  1
    service_1_1_5  service_visit_def_1036  1
    service_1_1_5  free_load_conservation_1037  4
    service_1_1_6  unique_nonzero_owner_296  1
    service_1_1_6  service_visit_def_1036  1
    service_1_1_6  free_load_conservation_1037  5
    service_1_1_7  unique_nonzero_owner_297  1
    service_1_1_7  service_visit_def_1036  1
    service_1_1_7  free_load_conservation_1037  6
    service_1_1_8  unique_nonzero_owner_298  1
    service_1_1_8  service_visit_def_1036  1
    service_1_1_8  free_load_conservation_1037  7
    service_1_1_9  unique_nonzero_owner_299  1
    service_1_1_9  service_visit_def_1036  1
    service_1_1_9  free_load_conservation_1037  8
    service_1_1_10  unique_nonzero_owner_300  1
    service_1_1_10  service_visit_def_1036  1
    service_1_1_10  free_load_conservation_1037  9
    service_1_1_11  unique_nonzero_owner_301  1
    service_1_1_11  service_visit_def_1036  1
    service_1_1_11  free_load_conservation_1037  10
    service_1_1_12  unique_nonzero_owner_302  1
    service_1_1_12  service_visit_def_1036  1
    service_1_1_12  free_load_conservation_1037  11
    service_1_1_13  unique_nonzero_owner_303  1
    service_1_1_13  service_visit_def_1036  1
    service_1_1_13  free_load_conservation_1037  12
    service_1_1_14  unique_nonzero_owner_304  1
    service_1_1_14  service_visit_def_1036  1
    service_1_1_14  free_load_conservation_1037  13
    service_1_1_15  unique_nonzero_owner_305  1
    service_1_1_15  service_visit_def_1036  1
    service_1_1_15  free_load_conservation_1037  14
    service_0_2_1  unique_nonzero_owner_306  1
    service_0_2_1  service_visit_def_772  1
    service_0_2_1  free_load_conservation_773  1
    service_1_2_1  unique_nonzero_owner_306  1
    service_1_2_1  service_visit_def_1042  1
    service_1_2_1  free_load_conservation_1043  1
    service_0_18_1  unique_nonzero_owner_307  1
    service_0_18_1  service_visit_def_778  1
    service_0_18_1  free_load_conservation_779  1
    service_0_18_2  unique_nonzero_owner_308  1
    service_0_18_2  service_visit_def_778  1
    service_0_18_2  free_load_conservation_779  2
    service_0_18_3  unique_nonzero_owner_309  1
    service_0_18_3  service_visit_def_778  1
    service_0_18_3  free_load_conservation_779  3
    service_0_18_4  unique_nonzero_owner_310  1
    service_0_18_4  service_visit_def_778  1
    service_0_18_4  free_load_conservation_779  4
    service_0_18_5  unique_nonzero_owner_311  1
    service_0_18_5  service_visit_def_778  1
    service_0_18_5  free_load_conservation_779  5
    service_0_18_6  unique_nonzero_owner_312  1
    service_0_18_6  service_visit_def_778  1
    service_0_18_6  free_load_conservation_779  6
    service_0_18_7  unique_nonzero_owner_313  1
    service_0_18_7  service_visit_def_778  1
    service_0_18_7  free_load_conservation_779  7
    service_0_18_8  unique_nonzero_owner_314  1
    service_0_18_8  service_visit_def_778  1
    service_0_18_8  free_load_conservation_779  8
    service_0_18_9  unique_nonzero_owner_315  1
    service_0_18_9  service_visit_def_778  1
    service_0_18_9  free_load_conservation_779  9
    service_0_18_10  unique_nonzero_owner_316  1
    service_0_18_10  service_visit_def_778  1
    service_0_18_10  free_load_conservation_779  10
    service_0_18_11  unique_nonzero_owner_317  1
    service_0_18_11  service_visit_def_778  1
    service_0_18_11  free_load_conservation_779  11
    service_0_18_12  unique_nonzero_owner_318  1
    service_0_18_12  service_visit_def_778  1
    service_0_18_12  free_load_conservation_779  12
    service_0_18_13  unique_nonzero_owner_319  1
    service_0_18_13  service_visit_def_778  1
    service_0_18_13  free_load_conservation_779  13
    service_0_18_14  unique_nonzero_owner_320  1
    service_0_18_14  service_visit_def_778  1
    service_0_18_14  free_load_conservation_779  14
    service_0_18_15  unique_nonzero_owner_321  1
    service_0_18_15  service_visit_def_778  1
    service_0_18_15  free_load_conservation_779  15
    service_1_18_1  unique_nonzero_owner_307  1
    service_1_18_1  service_visit_def_1048  1
    service_1_18_1  free_load_conservation_1049  1
    service_1_18_2  unique_nonzero_owner_308  1
    service_1_18_2  service_visit_def_1048  1
    service_1_18_2  free_load_conservation_1049  2
    service_1_18_3  unique_nonzero_owner_309  1
    service_1_18_3  service_visit_def_1048  1
    service_1_18_3  free_load_conservation_1049  3
    service_1_18_4  unique_nonzero_owner_310  1
    service_1_18_4  service_visit_def_1048  1
    service_1_18_4  free_load_conservation_1049  4
    service_1_18_5  unique_nonzero_owner_311  1
    service_1_18_5  service_visit_def_1048  1
    service_1_18_5  free_load_conservation_1049  5
    service_1_18_6  unique_nonzero_owner_312  1
    service_1_18_6  service_visit_def_1048  1
    service_1_18_6  free_load_conservation_1049  6
    service_1_18_7  unique_nonzero_owner_313  1
    service_1_18_7  service_visit_def_1048  1
    service_1_18_7  free_load_conservation_1049  7
    service_1_18_8  unique_nonzero_owner_314  1
    service_1_18_8  service_visit_def_1048  1
    service_1_18_8  free_load_conservation_1049  8
    service_1_18_9  unique_nonzero_owner_315  1
    service_1_18_9  service_visit_def_1048  1
    service_1_18_9  free_load_conservation_1049  9
    service_1_18_10  unique_nonzero_owner_316  1
    service_1_18_10  service_visit_def_1048  1
    service_1_18_10  free_load_conservation_1049  10
    service_1_18_11  unique_nonzero_owner_317  1
    service_1_18_11  service_visit_def_1048  1
    service_1_18_11  free_load_conservation_1049  11
    service_1_18_12  unique_nonzero_owner_318  1
    service_1_18_12  service_visit_def_1048  1
    service_1_18_12  free_load_conservation_1049  12
    service_1_18_13  unique_nonzero_owner_319  1
    service_1_18_13  service_visit_def_1048  1
    service_1_18_13  free_load_conservation_1049  13
    service_1_18_14  unique_nonzero_owner_320  1
    service_1_18_14  service_visit_def_1048  1
    service_1_18_14  free_load_conservation_1049  14
    service_1_18_15  unique_nonzero_owner_321  1
    service_1_18_15  service_visit_def_1048  1
    service_1_18_15  free_load_conservation_1049  15
    service_0_3_0  unique_nonzero_owner_322  1
    service_0_3_0  service_visit_def_784  1
    service_0_3_0  free_load_conservation_785  -12
    service_0_3_0  original_T_including_depot_unload_814  1440
    service_0_3_1  unique_nonzero_owner_323  1
    service_0_3_1  service_visit_def_784  1
    service_0_3_1  free_load_conservation_785  -11
    service_0_3_1  original_T_including_depot_unload_814  1320
    service_0_3_2  unique_nonzero_owner_324  1
    service_0_3_2  service_visit_def_784  1
    service_0_3_2  free_load_conservation_785  -10
    service_0_3_2  original_T_including_depot_unload_814  1200
    service_0_3_3  unique_nonzero_owner_325  1
    service_0_3_3  service_visit_def_784  1
    service_0_3_3  free_load_conservation_785  -9
    service_0_3_3  original_T_including_depot_unload_814  1080
    service_0_3_4  unique_nonzero_owner_326  1
    service_0_3_4  service_visit_def_784  1
    service_0_3_4  free_load_conservation_785  -8
    service_0_3_4  original_T_including_depot_unload_814  960
    service_0_3_5  unique_nonzero_owner_327  1
    service_0_3_5  service_visit_def_784  1
    service_0_3_5  free_load_conservation_785  -7
    service_0_3_5  original_T_including_depot_unload_814  840
    service_0_3_6  unique_nonzero_owner_328  1
    service_0_3_6  service_visit_def_784  1
    service_0_3_6  free_load_conservation_785  -6
    service_0_3_6  original_T_including_depot_unload_814  720
    service_0_3_7  unique_nonzero_owner_329  1
    service_0_3_7  service_visit_def_784  1
    service_0_3_7  free_load_conservation_785  -5
    service_0_3_7  original_T_including_depot_unload_814  600
    service_0_3_8  unique_nonzero_owner_330  1
    service_0_3_8  service_visit_def_784  1
    service_0_3_8  free_load_conservation_785  -4
    service_0_3_8  original_T_including_depot_unload_814  480
    service_0_3_9  unique_nonzero_owner_331  1
    service_0_3_9  service_visit_def_784  1
    service_0_3_9  free_load_conservation_785  -3
    service_0_3_9  original_T_including_depot_unload_814  360
    service_0_3_10  unique_nonzero_owner_332  1
    service_0_3_10  service_visit_def_784  1
    service_0_3_10  free_load_conservation_785  -2
    service_0_3_10  original_T_including_depot_unload_814  240
    service_0_3_11  unique_nonzero_owner_333  1
    service_0_3_11  service_visit_def_784  1
    service_0_3_11  free_load_conservation_785  -1
    service_0_3_11  original_T_including_depot_unload_814  120
    service_0_3_13  unique_nonzero_owner_334  1
    service_0_3_13  service_visit_def_784  1
    service_0_3_13  free_load_conservation_785  1
    service_0_3_14  unique_nonzero_owner_335  1
    service_0_3_14  service_visit_def_784  1
    service_0_3_14  free_load_conservation_785  2
    service_0_3_15  unique_nonzero_owner_336  1
    service_0_3_15  service_visit_def_784  1
    service_0_3_15  free_load_conservation_785  3
    service_0_3_16  unique_nonzero_owner_337  1
    service_0_3_16  service_visit_def_784  1
    service_0_3_16  free_load_conservation_785  4
    service_1_3_0  unique_nonzero_owner_322  1
    service_1_3_0  service_visit_def_1054  1
    service_1_3_0  free_load_conservation_1055  -12
    service_1_3_0  original_T_including_depot_unload_1081  1440
    service_1_3_1  unique_nonzero_owner_323  1
    service_1_3_1  service_visit_def_1054  1
    service_1_3_1  free_load_conservation_1055  -11
    service_1_3_1  original_T_including_depot_unload_1081  1320
    service_1_3_2  unique_nonzero_owner_324  1
    service_1_3_2  service_visit_def_1054  1
    service_1_3_2  free_load_conservation_1055  -10
    service_1_3_2  original_T_including_depot_unload_1081  1200
    service_1_3_3  unique_nonzero_owner_325  1
    service_1_3_3  service_visit_def_1054  1
    service_1_3_3  free_load_conservation_1055  -9
    service_1_3_3  original_T_including_depot_unload_1081  1080
    service_1_3_4  unique_nonzero_owner_326  1
    service_1_3_4  service_visit_def_1054  1
    service_1_3_4  free_load_conservation_1055  -8
    service_1_3_4  original_T_including_depot_unload_1081  960
    service_1_3_5  unique_nonzero_owner_327  1
    service_1_3_5  service_visit_def_1054  1
    service_1_3_5  free_load_conservation_1055  -7
    service_1_3_5  original_T_including_depot_unload_1081  840
    service_1_3_6  unique_nonzero_owner_328  1
    service_1_3_6  service_visit_def_1054  1
    service_1_3_6  free_load_conservation_1055  -6
    service_1_3_6  original_T_including_depot_unload_1081  720
    service_1_3_7  unique_nonzero_owner_329  1
    service_1_3_7  service_visit_def_1054  1
    service_1_3_7  free_load_conservation_1055  -5
    service_1_3_7  original_T_including_depot_unload_1081  600
    service_1_3_8  unique_nonzero_owner_330  1
    service_1_3_8  service_visit_def_1054  1
    service_1_3_8  free_load_conservation_1055  -4
    service_1_3_8  original_T_including_depot_unload_1081  480
    service_1_3_9  unique_nonzero_owner_331  1
    service_1_3_9  service_visit_def_1054  1
    service_1_3_9  free_load_conservation_1055  -3
    service_1_3_9  original_T_including_depot_unload_1081  360
    service_1_3_10  unique_nonzero_owner_332  1
    service_1_3_10  service_visit_def_1054  1
    service_1_3_10  free_load_conservation_1055  -2
    service_1_3_10  original_T_including_depot_unload_1081  240
    service_1_3_11  unique_nonzero_owner_333  1
    service_1_3_11  service_visit_def_1054  1
    service_1_3_11  free_load_conservation_1055  -1
    service_1_3_11  original_T_including_depot_unload_1081  120
    service_1_3_13  unique_nonzero_owner_334  1
    service_1_3_13  service_visit_def_1054  1
    service_1_3_13  free_load_conservation_1055  1
    service_1_3_14  unique_nonzero_owner_335  1
    service_1_3_14  service_visit_def_1054  1
    service_1_3_14  free_load_conservation_1055  2
    service_1_3_15  unique_nonzero_owner_336  1
    service_1_3_15  service_visit_def_1054  1
    service_1_3_15  free_load_conservation_1055  3
    service_1_3_16  unique_nonzero_owner_337  1
    service_1_3_16  service_visit_def_1054  1
    service_1_3_16  free_load_conservation_1055  4
    service_0_17_0  unique_nonzero_owner_338  1
    service_0_17_0  service_visit_def_790  1
    service_0_17_0  free_load_conservation_791  -3
    service_0_17_0  original_T_including_depot_unload_814  360
    service_0_17_1  unique_nonzero_owner_339  1
    service_0_17_1  service_visit_def_790  1
    service_0_17_1  free_load_conservation_791  -2
    service_0_17_1  original_T_including_depot_unload_814  240
    service_0_17_2  unique_nonzero_owner_340  1
    service_0_17_2  service_visit_def_790  1
    service_0_17_2  free_load_conservation_791  -1
    service_0_17_2  original_T_including_depot_unload_814  120
    service_0_17_4  unique_nonzero_owner_341  1
    service_0_17_4  service_visit_def_790  1
    service_0_17_4  free_load_conservation_791  1
    service_0_17_5  unique_nonzero_owner_342  1
    service_0_17_5  service_visit_def_790  1
    service_0_17_5  free_load_conservation_791  2
    service_0_17_6  unique_nonzero_owner_343  1
    service_0_17_6  service_visit_def_790  1
    service_0_17_6  free_load_conservation_791  3
    service_0_17_7  unique_nonzero_owner_344  1
    service_0_17_7  service_visit_def_790  1
    service_0_17_7  free_load_conservation_791  4
    service_0_17_8  unique_nonzero_owner_345  1
    service_0_17_8  service_visit_def_790  1
    service_0_17_8  free_load_conservation_791  5
    service_0_17_9  unique_nonzero_owner_346  1
    service_0_17_9  service_visit_def_790  1
    service_0_17_9  free_load_conservation_791  6
    service_0_17_10  unique_nonzero_owner_347  1
    service_0_17_10  service_visit_def_790  1
    service_0_17_10  free_load_conservation_791  7
    service_0_17_11  unique_nonzero_owner_348  1
    service_0_17_11  service_visit_def_790  1
    service_0_17_11  free_load_conservation_791  8
    service_0_17_12  unique_nonzero_owner_349  1
    service_0_17_12  service_visit_def_790  1
    service_0_17_12  free_load_conservation_791  9
    service_0_17_13  unique_nonzero_owner_350  1
    service_0_17_13  service_visit_def_790  1
    service_0_17_13  free_load_conservation_791  10
    service_0_17_14  unique_nonzero_owner_351  1
    service_0_17_14  service_visit_def_790  1
    service_0_17_14  free_load_conservation_791  11
    service_0_17_15  unique_nonzero_owner_352  1
    service_0_17_15  service_visit_def_790  1
    service_0_17_15  free_load_conservation_791  12
    service_0_17_16  unique_nonzero_owner_353  1
    service_0_17_16  service_visit_def_790  1
    service_0_17_16  free_load_conservation_791  13
    service_1_17_0  unique_nonzero_owner_338  1
    service_1_17_0  service_visit_def_1060  1
    service_1_17_0  free_load_conservation_1061  -3
    service_1_17_0  original_T_including_depot_unload_1081  360
    service_1_17_1  unique_nonzero_owner_339  1
    service_1_17_1  service_visit_def_1060  1
    service_1_17_1  free_load_conservation_1061  -2
    service_1_17_1  original_T_including_depot_unload_1081  240
    service_1_17_2  unique_nonzero_owner_340  1
    service_1_17_2  service_visit_def_1060  1
    service_1_17_2  free_load_conservation_1061  -1
    service_1_17_2  original_T_including_depot_unload_1081  120
    service_1_17_4  unique_nonzero_owner_341  1
    service_1_17_4  service_visit_def_1060  1
    service_1_17_4  free_load_conservation_1061  1
    service_1_17_5  unique_nonzero_owner_342  1
    service_1_17_5  service_visit_def_1060  1
    service_1_17_5  free_load_conservation_1061  2
    service_1_17_6  unique_nonzero_owner_343  1
    service_1_17_6  service_visit_def_1060  1
    service_1_17_6  free_load_conservation_1061  3
    service_1_17_7  unique_nonzero_owner_344  1
    service_1_17_7  service_visit_def_1060  1
    service_1_17_7  free_load_conservation_1061  4
    service_1_17_8  unique_nonzero_owner_345  1
    service_1_17_8  service_visit_def_1060  1
    service_1_17_8  free_load_conservation_1061  5
    service_1_17_9  unique_nonzero_owner_346  1
    service_1_17_9  service_visit_def_1060  1
    service_1_17_9  free_load_conservation_1061  6
    service_1_17_10  unique_nonzero_owner_347  1
    service_1_17_10  service_visit_def_1060  1
    service_1_17_10  free_load_conservation_1061  7
    service_1_17_11  unique_nonzero_owner_348  1
    service_1_17_11  service_visit_def_1060  1
    service_1_17_11  free_load_conservation_1061  8
    service_1_17_12  unique_nonzero_owner_349  1
    service_1_17_12  service_visit_def_1060  1
    service_1_17_12  free_load_conservation_1061  9
    service_1_17_13  unique_nonzero_owner_350  1
    service_1_17_13  service_visit_def_1060  1
    service_1_17_13  free_load_conservation_1061  10
    service_1_17_14  unique_nonzero_owner_351  1
    service_1_17_14  service_visit_def_1060  1
    service_1_17_14  free_load_conservation_1061  11
    service_1_17_15  unique_nonzero_owner_352  1
    service_1_17_15  service_visit_def_1060  1
    service_1_17_15  free_load_conservation_1061  12
    service_1_17_16  unique_nonzero_owner_353  1
    service_1_17_16  service_visit_def_1060  1
    service_1_17_16  free_load_conservation_1061  13
    service_0_4_0  unique_nonzero_owner_354  1
    service_0_4_0  service_visit_def_796  1
    service_0_4_0  free_load_conservation_797  -12
    service_0_4_0  original_T_including_depot_unload_814  1440
    service_0_4_1  unique_nonzero_owner_355  1
    service_0_4_1  service_visit_def_796  1
    service_0_4_1  free_load_conservation_797  -11
    service_0_4_1  original_T_including_depot_unload_814  1320
    service_0_4_2  unique_nonzero_owner_356  1
    service_0_4_2  service_visit_def_796  1
    service_0_4_2  free_load_conservation_797  -10
    service_0_4_2  original_T_including_depot_unload_814  1200
    service_0_4_3  unique_nonzero_owner_357  1
    service_0_4_3  service_visit_def_796  1
    service_0_4_3  free_load_conservation_797  -9
    service_0_4_3  original_T_including_depot_unload_814  1080
    service_0_4_4  unique_nonzero_owner_358  1
    service_0_4_4  service_visit_def_796  1
    service_0_4_4  free_load_conservation_797  -8
    service_0_4_4  original_T_including_depot_unload_814  960
    service_0_4_5  unique_nonzero_owner_359  1
    service_0_4_5  service_visit_def_796  1
    service_0_4_5  free_load_conservation_797  -7
    service_0_4_5  original_T_including_depot_unload_814  840
    service_0_4_6  unique_nonzero_owner_360  1
    service_0_4_6  service_visit_def_796  1
    service_0_4_6  free_load_conservation_797  -6
    service_0_4_6  original_T_including_depot_unload_814  720
    service_0_4_7  unique_nonzero_owner_361  1
    service_0_4_7  service_visit_def_796  1
    service_0_4_7  free_load_conservation_797  -5
    service_0_4_7  original_T_including_depot_unload_814  600
    service_0_4_8  unique_nonzero_owner_362  1
    service_0_4_8  service_visit_def_796  1
    service_0_4_8  free_load_conservation_797  -4
    service_0_4_8  original_T_including_depot_unload_814  480
    service_0_4_9  unique_nonzero_owner_363  1
    service_0_4_9  service_visit_def_796  1
    service_0_4_9  free_load_conservation_797  -3
    service_0_4_9  original_T_including_depot_unload_814  360
    service_0_4_10  unique_nonzero_owner_364  1
    service_0_4_10  service_visit_def_796  1
    service_0_4_10  free_load_conservation_797  -2
    service_0_4_10  original_T_including_depot_unload_814  240
    service_0_4_11  unique_nonzero_owner_365  1
    service_0_4_11  service_visit_def_796  1
    service_0_4_11  free_load_conservation_797  -1
    service_0_4_11  original_T_including_depot_unload_814  120
    service_0_4_13  unique_nonzero_owner_366  1
    service_0_4_13  service_visit_def_796  1
    service_0_4_13  free_load_conservation_797  1
    service_0_4_14  unique_nonzero_owner_367  1
    service_0_4_14  service_visit_def_796  1
    service_0_4_14  free_load_conservation_797  2
    service_0_4_15  unique_nonzero_owner_368  1
    service_0_4_15  service_visit_def_796  1
    service_0_4_15  free_load_conservation_797  3
    service_1_4_0  unique_nonzero_owner_354  1
    service_1_4_0  service_visit_def_1066  1
    service_1_4_0  free_load_conservation_1067  -12
    service_1_4_0  original_T_including_depot_unload_1081  1440
    service_1_4_1  unique_nonzero_owner_355  1
    service_1_4_1  service_visit_def_1066  1
    service_1_4_1  free_load_conservation_1067  -11
    service_1_4_1  original_T_including_depot_unload_1081  1320
    service_1_4_2  unique_nonzero_owner_356  1
    service_1_4_2  service_visit_def_1066  1
    service_1_4_2  free_load_conservation_1067  -10
    service_1_4_2  original_T_including_depot_unload_1081  1200
    service_1_4_3  unique_nonzero_owner_357  1
    service_1_4_3  service_visit_def_1066  1
    service_1_4_3  free_load_conservation_1067  -9
    service_1_4_3  original_T_including_depot_unload_1081  1080
    service_1_4_4  unique_nonzero_owner_358  1
    service_1_4_4  service_visit_def_1066  1
    service_1_4_4  free_load_conservation_1067  -8
    service_1_4_4  original_T_including_depot_unload_1081  960
    service_1_4_5  unique_nonzero_owner_359  1
    service_1_4_5  service_visit_def_1066  1
    service_1_4_5  free_load_conservation_1067  -7
    service_1_4_5  original_T_including_depot_unload_1081  840
    service_1_4_6  unique_nonzero_owner_360  1
    service_1_4_6  service_visit_def_1066  1
    service_1_4_6  free_load_conservation_1067  -6
    service_1_4_6  original_T_including_depot_unload_1081  720
    service_1_4_7  unique_nonzero_owner_361  1
    service_1_4_7  service_visit_def_1066  1
    service_1_4_7  free_load_conservation_1067  -5
    service_1_4_7  original_T_including_depot_unload_1081  600
    service_1_4_8  unique_nonzero_owner_362  1
    service_1_4_8  service_visit_def_1066  1
    service_1_4_8  free_load_conservation_1067  -4
    service_1_4_8  original_T_including_depot_unload_1081  480
    service_1_4_9  unique_nonzero_owner_363  1
    service_1_4_9  service_visit_def_1066  1
    service_1_4_9  free_load_conservation_1067  -3
    service_1_4_9  original_T_including_depot_unload_1081  360
    service_1_4_10  unique_nonzero_owner_364  1
    service_1_4_10  service_visit_def_1066  1
    service_1_4_10  free_load_conservation_1067  -2
    service_1_4_10  original_T_including_depot_unload_1081  240
    service_1_4_11  unique_nonzero_owner_365  1
    service_1_4_11  service_visit_def_1066  1
    service_1_4_11  free_load_conservation_1067  -1
    service_1_4_11  original_T_including_depot_unload_1081  120
    service_1_4_13  unique_nonzero_owner_366  1
    service_1_4_13  service_visit_def_1066  1
    service_1_4_13  free_load_conservation_1067  1
    service_1_4_14  unique_nonzero_owner_367  1
    service_1_4_14  service_visit_def_1066  1
    service_1_4_14  free_load_conservation_1067  2
    service_1_4_15  unique_nonzero_owner_368  1
    service_1_4_15  service_visit_def_1066  1
    service_1_4_15  free_load_conservation_1067  3
    service_0_11_0  unique_nonzero_owner_369  1
    service_0_11_0  service_visit_def_802  1
    service_0_11_0  free_load_conservation_803  -1
    service_0_11_0  original_T_including_depot_unload_814  120
    service_0_11_2  unique_nonzero_owner_370  1
    service_0_11_2  service_visit_def_802  1
    service_0_11_2  free_load_conservation_803  1
    service_0_11_3  unique_nonzero_owner_371  1
    service_0_11_3  service_visit_def_802  1
    service_0_11_3  free_load_conservation_803  2
    service_0_11_4  unique_nonzero_owner_372  1
    service_0_11_4  service_visit_def_802  1
    service_0_11_4  free_load_conservation_803  3
    service_0_11_5  unique_nonzero_owner_373  1
    service_0_11_5  service_visit_def_802  1
    service_0_11_5  free_load_conservation_803  4
    service_0_11_6  unique_nonzero_owner_374  1
    service_0_11_6  service_visit_def_802  1
    service_0_11_6  free_load_conservation_803  5
    service_0_11_7  unique_nonzero_owner_375  1
    service_0_11_7  service_visit_def_802  1
    service_0_11_7  free_load_conservation_803  6
    service_0_11_8  unique_nonzero_owner_376  1
    service_0_11_8  service_visit_def_802  1
    service_0_11_8  free_load_conservation_803  7
    service_0_11_9  unique_nonzero_owner_377  1
    service_0_11_9  service_visit_def_802  1
    service_0_11_9  free_load_conservation_803  8
    service_0_11_10  unique_nonzero_owner_378  1
    service_0_11_10  service_visit_def_802  1
    service_0_11_10  free_load_conservation_803  9
    service_0_11_11  unique_nonzero_owner_379  1
    service_0_11_11  service_visit_def_802  1
    service_0_11_11  free_load_conservation_803  10
    service_0_11_12  unique_nonzero_owner_380  1
    service_0_11_12  service_visit_def_802  1
    service_0_11_12  free_load_conservation_803  11
    service_0_11_13  unique_nonzero_owner_381  1
    service_0_11_13  service_visit_def_802  1
    service_0_11_13  free_load_conservation_803  12
    service_0_11_14  unique_nonzero_owner_382  1
    service_0_11_14  service_visit_def_802  1
    service_0_11_14  free_load_conservation_803  13
    service_0_11_15  unique_nonzero_owner_383  1
    service_0_11_15  service_visit_def_802  1
    service_0_11_15  free_load_conservation_803  14
    service_1_11_0  unique_nonzero_owner_369  1
    service_1_11_0  service_visit_def_1072  1
    service_1_11_0  free_load_conservation_1073  -1
    service_1_11_0  original_T_including_depot_unload_1081  120
    service_1_11_2  unique_nonzero_owner_370  1
    service_1_11_2  service_visit_def_1072  1
    service_1_11_2  free_load_conservation_1073  1
    service_1_11_3  unique_nonzero_owner_371  1
    service_1_11_3  service_visit_def_1072  1
    service_1_11_3  free_load_conservation_1073  2
    service_1_11_4  unique_nonzero_owner_372  1
    service_1_11_4  service_visit_def_1072  1
    service_1_11_4  free_load_conservation_1073  3
    service_1_11_5  unique_nonzero_owner_373  1
    service_1_11_5  service_visit_def_1072  1
    service_1_11_5  free_load_conservation_1073  4
    service_1_11_6  unique_nonzero_owner_374  1
    service_1_11_6  service_visit_def_1072  1
    service_1_11_6  free_load_conservation_1073  5
    service_1_11_7  unique_nonzero_owner_375  1
    service_1_11_7  service_visit_def_1072  1
    service_1_11_7  free_load_conservation_1073  6
    service_1_11_8  unique_nonzero_owner_376  1
    service_1_11_8  service_visit_def_1072  1
    service_1_11_8  free_load_conservation_1073  7
    service_1_11_9  unique_nonzero_owner_377  1
    service_1_11_9  service_visit_def_1072  1
    service_1_11_9  free_load_conservation_1073  8
    service_1_11_10  unique_nonzero_owner_378  1
    service_1_11_10  service_visit_def_1072  1
    service_1_11_10  free_load_conservation_1073  9
    service_1_11_11  unique_nonzero_owner_379  1
    service_1_11_11  service_visit_def_1072  1
    service_1_11_11  free_load_conservation_1073  10
    service_1_11_12  unique_nonzero_owner_380  1
    service_1_11_12  service_visit_def_1072  1
    service_1_11_12  free_load_conservation_1073  11
    service_1_11_13  unique_nonzero_owner_381  1
    service_1_11_13  service_visit_def_1072  1
    service_1_11_13  free_load_conservation_1073  12
    service_1_11_14  unique_nonzero_owner_382  1
    service_1_11_14  service_visit_def_1072  1
    service_1_11_14  free_load_conservation_1073  13
    service_1_11_15  unique_nonzero_owner_383  1
    service_1_11_15  service_visit_def_1072  1
    service_1_11_15  free_load_conservation_1073  14
    service_0_5_1  unique_nonzero_owner_384  1
    service_0_5_1  service_visit_def_808  1
    service_0_5_1  free_load_conservation_809  1
    service_0_5_2  unique_nonzero_owner_385  1
    service_0_5_2  service_visit_def_808  1
    service_0_5_2  free_load_conservation_809  2
    service_1_5_1  unique_nonzero_owner_384  1
    service_1_5_1  service_visit_def_1078  1
    service_1_5_1  free_load_conservation_1079  1
    service_1_5_2  unique_nonzero_owner_385  1
    service_1_5_2  service_visit_def_1078  1
    service_1_5_2  free_load_conservation_1079  2
    MARKER    'MARKER'                 'INTEND'
    visit_0_1  out_degree_727  -1
    visit_0_1  in_degree_728  -1
    visit_0_1  order_active_lb_729  -1
    visit_0_1  order_active_ub_730  -13
    order_0_1  connected_order_arc_402  -1
    order_0_1  connected_order_arc_404  -1
    order_0_1  connected_order_arc_406  -1
    order_0_1  connected_order_arc_408  -1
    order_0_1  connected_order_arc_410  -1
    order_0_1  connected_order_arc_412  -1
    order_0_1  connected_order_arc_414  -1
    order_0_1  connected_order_arc_416  -1
    order_0_1  connected_order_arc_418  -1
    order_0_1  connected_order_arc_420  -1
    order_0_1  connected_order_arc_422  -1
    order_0_1  connected_order_arc_424  -1
    order_0_1  connected_order_arc_427  1
    order_0_1  connected_order_arc_452  1
    order_0_1  connected_order_arc_477  1
    order_0_1  connected_order_arc_502  1
    order_0_1  connected_order_arc_527  1
    order_0_1  connected_order_arc_552  1
    order_0_1  connected_order_arc_577  1
    order_0_1  connected_order_arc_602  1
    order_0_1  connected_order_arc_627  1
    order_0_1  connected_order_arc_652  1
    order_0_1  connected_order_arc_677  1
    order_0_1  connected_order_arc_702  1
    order_0_1  order_active_lb_729  1
    order_0_1  order_active_ub_730  1
    order_0_1  fixed_segment_relative_order_810  -1
    visit_0_2  out_degree_734  -1
    visit_0_2  in_degree_735  -1
    visit_0_2  order_active_lb_736  -1
    visit_0_2  order_active_ub_737  -13
    order_0_2  connected_order_arc_402  1
    order_0_2  connected_order_arc_427  -1
    order_0_2  connected_order_arc_429  -1
    order_0_2  connected_order_arc_431  -1
    order_0_2  connected_order_arc_433  -1
    order_0_2  connected_order_arc_435  -1
    order_0_2  connected_order_arc_437  -1
    order_0_2  connected_order_arc_439  -1
    order_0_2  connected_order_arc_441  -1
    order_0_2  connected_order_arc_443  -1
    order_0_2  connected_order_arc_445  -1
    order_0_2  connected_order_arc_447  -1
    order_0_2  connected_order_arc_449  -1
    order_0_2  connected_order_arc_454  1
    order_0_2  connected_order_arc_479  1
    order_0_2  connected_order_arc_504  1
    order_0_2  connected_order_arc_529  1
    order_0_2  connected_order_arc_554  1
    order_0_2  connected_order_arc_579  1
    order_0_2  connected_order_arc_604  1
    order_0_2  connected_order_arc_629  1
    order_0_2  connected_order_arc_654  1
    order_0_2  connected_order_arc_679  1
    order_0_2  connected_order_arc_704  1
    order_0_2  order_active_lb_736  1
    order_0_2  order_active_ub_737  1
    order_0_2  fixed_segment_relative_order_810  1
    order_0_2  fixed_segment_relative_order_811  -1
    visit_0_3  out_degree_741  -1
    visit_0_3  in_degree_742  -1
    visit_0_3  order_active_lb_743  -1
    visit_0_3  order_active_ub_744  -13
    order_0_3  connected_order_arc_404  1
    order_0_3  connected_order_arc_429  1
    order_0_3  connected_order_arc_452  -1
    order_0_3  connected_order_arc_454  -1
    order_0_3  connected_order_arc_456  -1
    order_0_3  connected_order_arc_458  -1
    order_0_3  connected_order_arc_460  -1
    order_0_3  connected_order_arc_462  -1
    order_0_3  connected_order_arc_464  -1
    order_0_3  connected_order_arc_466  -1
    order_0_3  connected_order_arc_468  -1
    order_0_3  connected_order_arc_470  -1
    order_0_3  connected_order_arc_472  -1
    order_0_3  connected_order_arc_474  -1
    order_0_3  connected_order_arc_481  1
    order_0_3  connected_order_arc_506  1
    order_0_3  connected_order_arc_531  1
    order_0_3  connected_order_arc_556  1
    order_0_3  connected_order_arc_581  1
    order_0_3  connected_order_arc_606  1
    order_0_3  connected_order_arc_631  1
    order_0_3  connected_order_arc_656  1
    order_0_3  connected_order_arc_681  1
    order_0_3  connected_order_arc_706  1
    order_0_3  order_active_lb_743  1
    order_0_3  order_active_ub_744  1
    order_0_3  fixed_segment_relative_order_811  1
    order_0_3  fixed_segment_relative_order_812  -1
    visit_0_4  out_degree_748  -1
    visit_0_4  in_degree_749  -1
    visit_0_4  order_active_lb_750  -1
    visit_0_4  order_active_ub_751  -13
    order_0_4  connected_order_arc_406  1
    order_0_4  connected_order_arc_431  1
    order_0_4  connected_order_arc_456  1
    order_0_4  connected_order_arc_477  -1
    order_0_4  connected_order_arc_479  -1
    order_0_4  connected_order_arc_481  -1
    order_0_4  connected_order_arc_483  -1
    order_0_4  connected_order_arc_485  -1
    order_0_4  connected_order_arc_487  -1
    order_0_4  connected_order_arc_489  -1
    order_0_4  connected_order_arc_491  -1
    order_0_4  connected_order_arc_493  -1
    order_0_4  connected_order_arc_495  -1
    order_0_4  connected_order_arc_497  -1
    order_0_4  connected_order_arc_499  -1
    order_0_4  connected_order_arc_508  1
    order_0_4  connected_order_arc_533  1
    order_0_4  connected_order_arc_558  1
    order_0_4  connected_order_arc_583  1
    order_0_4  connected_order_arc_608  1
    order_0_4  connected_order_arc_633  1
    order_0_4  connected_order_arc_658  1
    order_0_4  connected_order_arc_683  1
    order_0_4  connected_order_arc_708  1
    order_0_4  order_active_lb_750  1
    order_0_4  order_active_ub_751  1
    order_0_4  fixed_segment_relative_order_812  1
    order_0_4  fixed_segment_relative_order_813  -1
    visit_0_5  out_degree_755  -1
    visit_0_5  in_degree_756  -1
    visit_0_5  order_active_lb_757  -1
    visit_0_5  order_active_ub_758  -13
    order_0_5  connected_order_arc_408  1
    order_0_5  connected_order_arc_433  1
    order_0_5  connected_order_arc_458  1
    order_0_5  connected_order_arc_483  1
    order_0_5  connected_order_arc_502  -1
    order_0_5  connected_order_arc_504  -1
    order_0_5  connected_order_arc_506  -1
    order_0_5  connected_order_arc_508  -1
    order_0_5  connected_order_arc_510  -1
    order_0_5  connected_order_arc_512  -1
    order_0_5  connected_order_arc_514  -1
    order_0_5  connected_order_arc_516  -1
    order_0_5  connected_order_arc_518  -1
    order_0_5  connected_order_arc_520  -1
    order_0_5  connected_order_arc_522  -1
    order_0_5  connected_order_arc_524  -1
    order_0_5  connected_order_arc_535  1
    order_0_5  connected_order_arc_560  1
    order_0_5  connected_order_arc_585  1
    order_0_5  connected_order_arc_610  1
    order_0_5  connected_order_arc_635  1
    order_0_5  connected_order_arc_660  1
    order_0_5  connected_order_arc_685  1
    order_0_5  connected_order_arc_710  1
    order_0_5  order_active_lb_757  1
    order_0_5  order_active_ub_758  1
    order_0_5  fixed_segment_relative_order_813  1
    visit_0_8  out_degree_762  -1
    visit_0_8  in_degree_763  -1
    visit_0_8  order_active_lb_764  -1
    visit_0_8  order_active_ub_765  -13
    visit_0_8  service_visit_def_766  -1
    order_0_8  connected_order_arc_410  1
    order_0_8  connected_order_arc_435  1
    order_0_8  connected_order_arc_460  1
    order_0_8  connected_order_arc_485  1
    order_0_8  connected_order_arc_510  1
    order_0_8  connected_order_arc_527  -1
    order_0_8  connected_order_arc_529  -1
    order_0_8  connected_order_arc_531  -1
    order_0_8  connected_order_arc_533  -1
    order_0_8  connected_order_arc_535  -1
    order_0_8  connected_order_arc_537  -1
    order_0_8  connected_order_arc_539  -1
    order_0_8  connected_order_arc_541  -1
    order_0_8  connected_order_arc_543  -1
    order_0_8  connected_order_arc_545  -1
    order_0_8  connected_order_arc_547  -1
    order_0_8  connected_order_arc_549  -1
    order_0_8  connected_order_arc_562  1
    order_0_8  connected_order_arc_587  1
    order_0_8  connected_order_arc_612  1
    order_0_8  connected_order_arc_637  1
    order_0_8  connected_order_arc_662  1
    order_0_8  connected_order_arc_687  1
    order_0_8  connected_order_arc_712  1
    order_0_8  order_active_lb_764  1
    order_0_8  order_active_ub_765  1
    visit_0_9  out_degree_768  -1
    visit_0_9  in_degree_769  -1
    visit_0_9  order_active_lb_770  -1
    visit_0_9  order_active_ub_771  -13
    visit_0_9  service_visit_def_772  -1
    order_0_9  connected_order_arc_412  1
    order_0_9  connected_order_arc_437  1
    order_0_9  connected_order_arc_462  1
    order_0_9  connected_order_arc_487  1
    order_0_9  connected_order_arc_512  1
    order_0_9  connected_order_arc_537  1
    order_0_9  connected_order_arc_552  -1
    order_0_9  connected_order_arc_554  -1
    order_0_9  connected_order_arc_556  -1
    order_0_9  connected_order_arc_558  -1
    order_0_9  connected_order_arc_560  -1
    order_0_9  connected_order_arc_562  -1
    order_0_9  connected_order_arc_564  -1
    order_0_9  connected_order_arc_566  -1
    order_0_9  connected_order_arc_568  -1
    order_0_9  connected_order_arc_570  -1
    order_0_9  connected_order_arc_572  -1
    order_0_9  connected_order_arc_574  -1
    order_0_9  connected_order_arc_589  1
    order_0_9  connected_order_arc_614  1
    order_0_9  connected_order_arc_639  1
    order_0_9  connected_order_arc_664  1
    order_0_9  connected_order_arc_689  1
    order_0_9  connected_order_arc_714  1
    order_0_9  order_active_lb_770  1
    order_0_9  order_active_ub_771  1
    visit_0_10  out_degree_774  -1
    visit_0_10  in_degree_775  -1
    visit_0_10  order_active_lb_776  -1
    visit_0_10  order_active_ub_777  -13
    visit_0_10  service_visit_def_778  -1
    order_0_10  connected_order_arc_414  1
    order_0_10  connected_order_arc_439  1
    order_0_10  connected_order_arc_464  1
    order_0_10  connected_order_arc_489  1
    order_0_10  connected_order_arc_514  1
    order_0_10  connected_order_arc_539  1
    order_0_10  connected_order_arc_564  1
    order_0_10  connected_order_arc_577  -1
    order_0_10  connected_order_arc_579  -1
    order_0_10  connected_order_arc_581  -1
    order_0_10  connected_order_arc_583  -1
    order_0_10  connected_order_arc_585  -1
    order_0_10  connected_order_arc_587  -1
    order_0_10  connected_order_arc_589  -1
    order_0_10  connected_order_arc_591  -1
    order_0_10  connected_order_arc_593  -1
    order_0_10  connected_order_arc_595  -1
    order_0_10  connected_order_arc_597  -1
    order_0_10  connected_order_arc_599  -1
    order_0_10  connected_order_arc_616  1
    order_0_10  connected_order_arc_641  1
    order_0_10  connected_order_arc_666  1
    order_0_10  connected_order_arc_691  1
    order_0_10  connected_order_arc_716  1
    order_0_10  order_active_lb_776  1
    order_0_10  order_active_ub_777  1
    visit_0_11  out_degree_780  -1
    visit_0_11  in_degree_781  -1
    visit_0_11  order_active_lb_782  -1
    visit_0_11  order_active_ub_783  -13
    visit_0_11  service_visit_def_784  -1
    order_0_11  connected_order_arc_416  1
    order_0_11  connected_order_arc_441  1
    order_0_11  connected_order_arc_466  1
    order_0_11  connected_order_arc_491  1
    order_0_11  connected_order_arc_516  1
    order_0_11  connected_order_arc_541  1
    order_0_11  connected_order_arc_566  1
    order_0_11  connected_order_arc_591  1
    order_0_11  connected_order_arc_602  -1
    order_0_11  connected_order_arc_604  -1
    order_0_11  connected_order_arc_606  -1
    order_0_11  connected_order_arc_608  -1
    order_0_11  connected_order_arc_610  -1
    order_0_11  connected_order_arc_612  -1
    order_0_11  connected_order_arc_614  -1
    order_0_11  connected_order_arc_616  -1
    order_0_11  connected_order_arc_618  -1
    order_0_11  connected_order_arc_620  -1
    order_0_11  connected_order_arc_622  -1
    order_0_11  connected_order_arc_624  -1
    order_0_11  connected_order_arc_643  1
    order_0_11  connected_order_arc_668  1
    order_0_11  connected_order_arc_693  1
    order_0_11  connected_order_arc_718  1
    order_0_11  order_active_lb_782  1
    order_0_11  order_active_ub_783  1
    visit_0_12  out_degree_786  -1
    visit_0_12  in_degree_787  -1
    visit_0_12  order_active_lb_788  -1
    visit_0_12  order_active_ub_789  -13
    visit_0_12  service_visit_def_790  -1
    order_0_12  connected_order_arc_418  1
    order_0_12  connected_order_arc_443  1
    order_0_12  connected_order_arc_468  1
    order_0_12  connected_order_arc_493  1
    order_0_12  connected_order_arc_518  1
    order_0_12  connected_order_arc_543  1
    order_0_12  connected_order_arc_568  1
    order_0_12  connected_order_arc_593  1
    order_0_12  connected_order_arc_618  1
    order_0_12  connected_order_arc_627  -1
    order_0_12  connected_order_arc_629  -1
    order_0_12  connected_order_arc_631  -1
    order_0_12  connected_order_arc_633  -1
    order_0_12  connected_order_arc_635  -1
    order_0_12  connected_order_arc_637  -1
    order_0_12  connected_order_arc_639  -1
    order_0_12  connected_order_arc_641  -1
    order_0_12  connected_order_arc_643  -1
    order_0_12  connected_order_arc_645  -1
    order_0_12  connected_order_arc_647  -1
    order_0_12  connected_order_arc_649  -1
    order_0_12  connected_order_arc_670  1
    order_0_12  connected_order_arc_695  1
    order_0_12  connected_order_arc_720  1
    order_0_12  order_active_lb_788  1
    order_0_12  order_active_ub_789  1
    visit_0_13  out_degree_792  -1
    visit_0_13  in_degree_793  -1
    visit_0_13  order_active_lb_794  -1
    visit_0_13  order_active_ub_795  -13
    visit_0_13  service_visit_def_796  -1
    order_0_13  connected_order_arc_420  1
    order_0_13  connected_order_arc_445  1
    order_0_13  connected_order_arc_470  1
    order_0_13  connected_order_arc_495  1
    order_0_13  connected_order_arc_520  1
    order_0_13  connected_order_arc_545  1
    order_0_13  connected_order_arc_570  1
    order_0_13  connected_order_arc_595  1
    order_0_13  connected_order_arc_620  1
    order_0_13  connected_order_arc_645  1
    order_0_13  connected_order_arc_652  -1
    order_0_13  connected_order_arc_654  -1
    order_0_13  connected_order_arc_656  -1
    order_0_13  connected_order_arc_658  -1
    order_0_13  connected_order_arc_660  -1
    order_0_13  connected_order_arc_662  -1
    order_0_13  connected_order_arc_664  -1
    order_0_13  connected_order_arc_666  -1
    order_0_13  connected_order_arc_668  -1
    order_0_13  connected_order_arc_670  -1
    order_0_13  connected_order_arc_672  -1
    order_0_13  connected_order_arc_674  -1
    order_0_13  connected_order_arc_697  1
    order_0_13  connected_order_arc_722  1
    order_0_13  order_active_lb_794  1
    order_0_13  order_active_ub_795  1
    visit_0_14  out_degree_798  -1
    visit_0_14  in_degree_799  -1
    visit_0_14  order_active_lb_800  -1
    visit_0_14  order_active_ub_801  -13
    visit_0_14  service_visit_def_802  -1
    order_0_14  connected_order_arc_422  1
    order_0_14  connected_order_arc_447  1
    order_0_14  connected_order_arc_472  1
    order_0_14  connected_order_arc_497  1
    order_0_14  connected_order_arc_522  1
    order_0_14  connected_order_arc_547  1
    order_0_14  connected_order_arc_572  1
    order_0_14  connected_order_arc_597  1
    order_0_14  connected_order_arc_622  1
    order_0_14  connected_order_arc_647  1
    order_0_14  connected_order_arc_672  1
    order_0_14  connected_order_arc_677  -1
    order_0_14  connected_order_arc_679  -1
    order_0_14  connected_order_arc_681  -1
    order_0_14  connected_order_arc_683  -1
    order_0_14  connected_order_arc_685  -1
    order_0_14  connected_order_arc_687  -1
    order_0_14  connected_order_arc_689  -1
    order_0_14  connected_order_arc_691  -1
    order_0_14  connected_order_arc_693  -1
    order_0_14  connected_order_arc_695  -1
    order_0_14  connected_order_arc_697  -1
    order_0_14  connected_order_arc_699  -1
    order_0_14  connected_order_arc_724  1
    order_0_14  order_active_lb_800  1
    order_0_14  order_active_ub_801  1
    visit_0_15  out_degree_804  -1
    visit_0_15  in_degree_805  -1
    visit_0_15  order_active_lb_806  -1
    visit_0_15  order_active_ub_807  -13
    visit_0_15  service_visit_def_808  -1
    order_0_15  connected_order_arc_424  1
    order_0_15  connected_order_arc_449  1
    order_0_15  connected_order_arc_474  1
    order_0_15  connected_order_arc_499  1
    order_0_15  connected_order_arc_524  1
    order_0_15  connected_order_arc_549  1
    order_0_15  connected_order_arc_574  1
    order_0_15  connected_order_arc_599  1
    order_0_15  connected_order_arc_624  1
    order_0_15  connected_order_arc_649  1
    order_0_15  connected_order_arc_674  1
    order_0_15  connected_order_arc_699  1
    order_0_15  connected_order_arc_702  -1
    order_0_15  connected_order_arc_704  -1
    order_0_15  connected_order_arc_706  -1
    order_0_15  connected_order_arc_708  -1
    order_0_15  connected_order_arc_710  -1
    order_0_15  connected_order_arc_712  -1
    order_0_15  connected_order_arc_714  -1
    order_0_15  connected_order_arc_716  -1
    order_0_15  connected_order_arc_718  -1
    order_0_15  connected_order_arc_720  -1
    order_0_15  connected_order_arc_722  -1
    order_0_15  connected_order_arc_724  -1
    order_0_15  order_active_lb_806  1
    order_0_15  order_active_ub_807  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_0  arc_capacity_386  -30
    arc_0_0_0  depot_departure_or_bypass_725  1
    arc_0_0_0  depot_return_or_bypass_726  1
    MARKER    'MARKER'                 'INTEND'
    load_0_0_0  arc_capacity_386  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_1  arc_capacity_387  -30
    arc_0_0_1  depot_departure_or_bypass_725  1
    arc_0_0_1  in_degree_728  1
    arc_0_0_1  original_T_including_depot_unload_814  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_1  arc_capacity_387  1
    load_0_0_1  segment_load_conservation_731  -1
    load_0_0_1  segment_prefix_lb_732  1
    load_0_0_1  segment_prefix_ub_733  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_2  arc_capacity_388  -30
    arc_0_0_2  depot_departure_or_bypass_725  1
    arc_0_0_2  in_degree_735  1
    arc_0_0_2  original_T_including_depot_unload_814  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_2  arc_capacity_388  1
    load_0_0_2  segment_load_conservation_738  -1
    load_0_0_2  segment_prefix_lb_739  1
    load_0_0_2  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_3  arc_capacity_389  -30
    arc_0_0_3  depot_departure_or_bypass_725  1
    arc_0_0_3  in_degree_742  1
    arc_0_0_3  original_T_including_depot_unload_814  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_3  arc_capacity_389  1
    load_0_0_3  segment_load_conservation_745  -1
    load_0_0_3  segment_prefix_lb_746  1
    load_0_0_3  segment_prefix_ub_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_4  arc_capacity_390  -30
    arc_0_0_4  depot_departure_or_bypass_725  1
    arc_0_0_4  in_degree_749  1
    arc_0_0_4  original_T_including_depot_unload_814  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_4  arc_capacity_390  1
    load_0_0_4  segment_load_conservation_752  -1
    load_0_0_4  segment_prefix_lb_753  1
    load_0_0_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_5  arc_capacity_391  -30
    arc_0_0_5  depot_departure_or_bypass_725  1
    arc_0_0_5  in_degree_756  1
    arc_0_0_5  original_T_including_depot_unload_814  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_5  arc_capacity_391  1
    load_0_0_5  segment_load_conservation_759  -1
    load_0_0_5  segment_prefix_lb_760  1
    load_0_0_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_8  arc_capacity_392  -30
    arc_0_0_8  depot_departure_or_bypass_725  1
    arc_0_0_8  in_degree_763  1
    arc_0_0_8  original_T_including_depot_unload_814  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_8  arc_capacity_392  1
    load_0_0_8  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_9  arc_capacity_393  -30
    arc_0_0_9  depot_departure_or_bypass_725  1
    arc_0_0_9  in_degree_769  1
    arc_0_0_9  original_T_including_depot_unload_814  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_9  arc_capacity_393  1
    load_0_0_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_10  arc_capacity_394  -30
    arc_0_0_10  depot_departure_or_bypass_725  1
    arc_0_0_10  in_degree_775  1
    arc_0_0_10  original_T_including_depot_unload_814  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_10  arc_capacity_394  1
    load_0_0_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_11  arc_capacity_395  -30
    arc_0_0_11  depot_departure_or_bypass_725  1
    arc_0_0_11  in_degree_781  1
    arc_0_0_11  original_T_including_depot_unload_814  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_11  arc_capacity_395  1
    load_0_0_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_12  arc_capacity_396  -30
    arc_0_0_12  depot_departure_or_bypass_725  1
    arc_0_0_12  in_degree_787  1
    arc_0_0_12  original_T_including_depot_unload_814  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_12  arc_capacity_396  1
    load_0_0_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_13  arc_capacity_397  -30
    arc_0_0_13  depot_departure_or_bypass_725  1
    arc_0_0_13  in_degree_793  1
    arc_0_0_13  original_T_including_depot_unload_814  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_0_13  arc_capacity_397  1
    load_0_0_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_14  arc_capacity_398  -30
    arc_0_0_14  depot_departure_or_bypass_725  1
    arc_0_0_14  in_degree_799  1
    arc_0_0_14  original_T_including_depot_unload_814  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_14  arc_capacity_398  1
    load_0_0_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_0_15  arc_capacity_399  -30
    arc_0_0_15  depot_departure_or_bypass_725  1
    arc_0_0_15  in_degree_805  1
    arc_0_0_15  original_T_including_depot_unload_814  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_0_15  arc_capacity_399  1
    load_0_0_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_0  arc_capacity_400  -30
    arc_0_1_0  depot_return_or_bypass_726  1
    arc_0_1_0  out_degree_727  1
    arc_0_1_0  original_T_including_depot_unload_814  3.5937232665424995e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_0  arc_capacity_400  1
    load_0_1_0  segment_load_conservation_731  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_2  arc_capacity_401  -30
    arc_0_1_2  connected_order_arc_402  -14
    arc_0_1_2  out_degree_727  1
    arc_0_1_2  in_degree_735  1
    arc_0_1_2  original_T_including_depot_unload_814  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_2  arc_capacity_401  1
    load_0_1_2  segment_load_conservation_731  1
    load_0_1_2  segment_load_conservation_738  -1
    load_0_1_2  segment_prefix_lb_739  1
    load_0_1_2  segment_prefix_ub_740  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_3  arc_capacity_403  -30
    arc_0_1_3  connected_order_arc_404  -14
    arc_0_1_3  out_degree_727  1
    arc_0_1_3  in_degree_742  1
    arc_0_1_3  original_T_including_depot_unload_814  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_3  arc_capacity_403  1
    load_0_1_3  segment_load_conservation_731  1
    load_0_1_3  segment_load_conservation_745  -1
    load_0_1_3  segment_prefix_lb_746  1
    load_0_1_3  segment_prefix_ub_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_4  arc_capacity_405  -30
    arc_0_1_4  connected_order_arc_406  -14
    arc_0_1_4  out_degree_727  1
    arc_0_1_4  in_degree_749  1
    arc_0_1_4  original_T_including_depot_unload_814  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_4  arc_capacity_405  1
    load_0_1_4  segment_load_conservation_731  1
    load_0_1_4  segment_load_conservation_752  -1
    load_0_1_4  segment_prefix_lb_753  1
    load_0_1_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_5  arc_capacity_407  -30
    arc_0_1_5  connected_order_arc_408  -14
    arc_0_1_5  out_degree_727  1
    arc_0_1_5  in_degree_756  1
    arc_0_1_5  original_T_including_depot_unload_814  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_5  arc_capacity_407  1
    load_0_1_5  segment_load_conservation_731  1
    load_0_1_5  segment_load_conservation_759  -1
    load_0_1_5  segment_prefix_lb_760  1
    load_0_1_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_8  arc_capacity_409  -30
    arc_0_1_8  connected_order_arc_410  -14
    arc_0_1_8  out_degree_727  1
    arc_0_1_8  in_degree_763  1
    arc_0_1_8  original_T_including_depot_unload_814  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_8  arc_capacity_409  1
    load_0_1_8  segment_load_conservation_731  1
    load_0_1_8  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_9  arc_capacity_411  -30
    arc_0_1_9  connected_order_arc_412  -14
    arc_0_1_9  out_degree_727  1
    arc_0_1_9  in_degree_769  1
    arc_0_1_9  original_T_including_depot_unload_814  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_9  arc_capacity_411  1
    load_0_1_9  segment_load_conservation_731  1
    load_0_1_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_10  arc_capacity_413  -30
    arc_0_1_10  connected_order_arc_414  -14
    arc_0_1_10  out_degree_727  1
    arc_0_1_10  in_degree_775  1
    arc_0_1_10  original_T_including_depot_unload_814  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_10  arc_capacity_413  1
    load_0_1_10  segment_load_conservation_731  1
    load_0_1_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_11  arc_capacity_415  -30
    arc_0_1_11  connected_order_arc_416  -14
    arc_0_1_11  out_degree_727  1
    arc_0_1_11  in_degree_781  1
    arc_0_1_11  original_T_including_depot_unload_814  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_11  arc_capacity_415  1
    load_0_1_11  segment_load_conservation_731  1
    load_0_1_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_12  arc_capacity_417  -30
    arc_0_1_12  connected_order_arc_418  -14
    arc_0_1_12  out_degree_727  1
    arc_0_1_12  in_degree_787  1
    arc_0_1_12  original_T_including_depot_unload_814  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_12  arc_capacity_417  1
    load_0_1_12  segment_load_conservation_731  1
    load_0_1_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_13  arc_capacity_419  -30
    arc_0_1_13  connected_order_arc_420  -14
    arc_0_1_13  out_degree_727  1
    arc_0_1_13  in_degree_793  1
    arc_0_1_13  original_T_including_depot_unload_814  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_13  arc_capacity_419  1
    load_0_1_13  segment_load_conservation_731  1
    load_0_1_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_14  arc_capacity_421  -30
    arc_0_1_14  connected_order_arc_422  -14
    arc_0_1_14  out_degree_727  1
    arc_0_1_14  in_degree_799  1
    arc_0_1_14  original_T_including_depot_unload_814  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_1_14  arc_capacity_421  1
    load_0_1_14  segment_load_conservation_731  1
    load_0_1_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_1_15  arc_capacity_423  -30
    arc_0_1_15  connected_order_arc_424  -14
    arc_0_1_15  out_degree_727  1
    arc_0_1_15  in_degree_805  1
    arc_0_1_15  original_T_including_depot_unload_814  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_1_15  arc_capacity_423  1
    load_0_1_15  segment_load_conservation_731  1
    load_0_1_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_0  arc_capacity_425  -30
    arc_0_2_0  depot_return_or_bypass_726  1
    arc_0_2_0  out_degree_734  1
    arc_0_2_0  original_T_including_depot_unload_814  5.2774046204590661e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_0  arc_capacity_425  1
    load_0_2_0  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_1  arc_capacity_426  -30
    arc_0_2_1  connected_order_arc_427  -14
    arc_0_2_1  in_degree_728  1
    arc_0_2_1  out_degree_734  1
    arc_0_2_1  original_T_including_depot_unload_814  7.2696582003770027e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_1  arc_capacity_426  1
    load_0_2_1  segment_load_conservation_731  -1
    load_0_2_1  segment_prefix_lb_732  1
    load_0_2_1  segment_prefix_ub_733  1
    load_0_2_1  segment_load_conservation_738  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_3  arc_capacity_428  -30
    arc_0_2_3  connected_order_arc_429  -14
    arc_0_2_3  out_degree_734  1
    arc_0_2_3  in_degree_742  1
    arc_0_2_3  original_T_including_depot_unload_814  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_2_3  arc_capacity_428  1
    load_0_2_3  segment_load_conservation_738  1
    load_0_2_3  segment_load_conservation_745  -1
    load_0_2_3  segment_prefix_lb_746  1
    load_0_2_3  segment_prefix_ub_747  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_4  arc_capacity_430  -30
    arc_0_2_4  connected_order_arc_431  -14
    arc_0_2_4  out_degree_734  1
    arc_0_2_4  in_degree_749  1
    arc_0_2_4  original_T_including_depot_unload_814  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_4  arc_capacity_430  1
    load_0_2_4  segment_load_conservation_738  1
    load_0_2_4  segment_load_conservation_752  -1
    load_0_2_4  segment_prefix_lb_753  1
    load_0_2_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_5  arc_capacity_432  -30
    arc_0_2_5  connected_order_arc_433  -14
    arc_0_2_5  out_degree_734  1
    arc_0_2_5  in_degree_756  1
    arc_0_2_5  original_T_including_depot_unload_814  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_5  arc_capacity_432  1
    load_0_2_5  segment_load_conservation_738  1
    load_0_2_5  segment_load_conservation_759  -1
    load_0_2_5  segment_prefix_lb_760  1
    load_0_2_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_8  arc_capacity_434  -30
    arc_0_2_8  connected_order_arc_435  -14
    arc_0_2_8  out_degree_734  1
    arc_0_2_8  in_degree_763  1
    arc_0_2_8  original_T_including_depot_unload_814  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_8  arc_capacity_434  1
    load_0_2_8  segment_load_conservation_738  1
    load_0_2_8  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_9  arc_capacity_436  -30
    arc_0_2_9  connected_order_arc_437  -14
    arc_0_2_9  out_degree_734  1
    arc_0_2_9  in_degree_769  1
    arc_0_2_9  original_T_including_depot_unload_814  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_9  arc_capacity_436  1
    load_0_2_9  segment_load_conservation_738  1
    load_0_2_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_10  arc_capacity_438  -30
    arc_0_2_10  connected_order_arc_439  -14
    arc_0_2_10  out_degree_734  1
    arc_0_2_10  in_degree_775  1
    arc_0_2_10  original_T_including_depot_unload_814  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_10  arc_capacity_438  1
    load_0_2_10  segment_load_conservation_738  1
    load_0_2_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_11  arc_capacity_440  -30
    arc_0_2_11  connected_order_arc_441  -14
    arc_0_2_11  out_degree_734  1
    arc_0_2_11  in_degree_781  1
    arc_0_2_11  original_T_including_depot_unload_814  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_11  arc_capacity_440  1
    load_0_2_11  segment_load_conservation_738  1
    load_0_2_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_12  arc_capacity_442  -30
    arc_0_2_12  connected_order_arc_443  -14
    arc_0_2_12  out_degree_734  1
    arc_0_2_12  in_degree_787  1
    arc_0_2_12  original_T_including_depot_unload_814  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_2_12  arc_capacity_442  1
    load_0_2_12  segment_load_conservation_738  1
    load_0_2_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_13  arc_capacity_444  -30
    arc_0_2_13  connected_order_arc_445  -14
    arc_0_2_13  out_degree_734  1
    arc_0_2_13  in_degree_793  1
    arc_0_2_13  original_T_including_depot_unload_814  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_13  arc_capacity_444  1
    load_0_2_13  segment_load_conservation_738  1
    load_0_2_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_14  arc_capacity_446  -30
    arc_0_2_14  connected_order_arc_447  -14
    arc_0_2_14  out_degree_734  1
    arc_0_2_14  in_degree_799  1
    arc_0_2_14  original_T_including_depot_unload_814  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_14  arc_capacity_446  1
    load_0_2_14  segment_load_conservation_738  1
    load_0_2_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_2_15  arc_capacity_448  -30
    arc_0_2_15  connected_order_arc_449  -14
    arc_0_2_15  out_degree_734  1
    arc_0_2_15  in_degree_805  1
    arc_0_2_15  original_T_including_depot_unload_814  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_2_15  arc_capacity_448  1
    load_0_2_15  segment_load_conservation_738  1
    load_0_2_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_0  arc_capacity_450  -30
    arc_0_3_0  depot_return_or_bypass_726  1
    arc_0_3_0  out_degree_741  1
    arc_0_3_0  original_T_including_depot_unload_814  7.4412496590753551e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_0  arc_capacity_450  1
    load_0_3_0  segment_load_conservation_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_1  arc_capacity_451  -30
    arc_0_3_1  connected_order_arc_452  -14
    arc_0_3_1  in_degree_728  1
    arc_0_3_1  out_degree_741  1
    arc_0_3_1  original_T_including_depot_unload_814  1.0007616644945284e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_1  arc_capacity_451  1
    load_0_3_1  segment_load_conservation_731  -1
    load_0_3_1  segment_prefix_lb_732  1
    load_0_3_1  segment_prefix_ub_733  1
    load_0_3_1  segment_load_conservation_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_2  arc_capacity_453  -30
    arc_0_3_2  connected_order_arc_454  -14
    arc_0_3_2  in_degree_735  1
    arc_0_3_2  out_degree_741  1
    arc_0_3_2  original_T_including_depot_unload_814  291.965990421835
    MARKER    'MARKER'                 'INTEND'
    load_0_3_2  arc_capacity_453  1
    load_0_3_2  segment_load_conservation_738  -1
    load_0_3_2  segment_prefix_lb_739  1
    load_0_3_2  segment_prefix_ub_740  1
    load_0_3_2  segment_load_conservation_745  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_4  arc_capacity_455  -30
    arc_0_3_4  connected_order_arc_456  -14
    arc_0_3_4  out_degree_741  1
    arc_0_3_4  in_degree_749  1
    arc_0_3_4  original_T_including_depot_unload_814  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_4  arc_capacity_455  1
    load_0_3_4  segment_load_conservation_745  1
    load_0_3_4  segment_load_conservation_752  -1
    load_0_3_4  segment_prefix_lb_753  1
    load_0_3_4  segment_prefix_ub_754  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_5  arc_capacity_457  -30
    arc_0_3_5  connected_order_arc_458  -14
    arc_0_3_5  out_degree_741  1
    arc_0_3_5  in_degree_756  1
    arc_0_3_5  original_T_including_depot_unload_814  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_5  arc_capacity_457  1
    load_0_3_5  segment_load_conservation_745  1
    load_0_3_5  segment_load_conservation_759  -1
    load_0_3_5  segment_prefix_lb_760  1
    load_0_3_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_8  arc_capacity_459  -30
    arc_0_3_8  connected_order_arc_460  -14
    arc_0_3_8  out_degree_741  1
    arc_0_3_8  in_degree_763  1
    arc_0_3_8  original_T_including_depot_unload_814  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_8  arc_capacity_459  1
    load_0_3_8  segment_load_conservation_745  1
    load_0_3_8  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_9  arc_capacity_461  -30
    arc_0_3_9  connected_order_arc_462  -14
    arc_0_3_9  out_degree_741  1
    arc_0_3_9  in_degree_769  1
    arc_0_3_9  original_T_including_depot_unload_814  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_9  arc_capacity_461  1
    load_0_3_9  segment_load_conservation_745  1
    load_0_3_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_10  arc_capacity_463  -30
    arc_0_3_10  connected_order_arc_464  -14
    arc_0_3_10  out_degree_741  1
    arc_0_3_10  in_degree_775  1
    arc_0_3_10  original_T_including_depot_unload_814  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_10  arc_capacity_463  1
    load_0_3_10  segment_load_conservation_745  1
    load_0_3_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_11  arc_capacity_465  -30
    arc_0_3_11  connected_order_arc_466  -14
    arc_0_3_11  out_degree_741  1
    arc_0_3_11  in_degree_781  1
    arc_0_3_11  original_T_including_depot_unload_814  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_11  arc_capacity_465  1
    load_0_3_11  segment_load_conservation_745  1
    load_0_3_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_12  arc_capacity_467  -30
    arc_0_3_12  connected_order_arc_468  -14
    arc_0_3_12  out_degree_741  1
    arc_0_3_12  in_degree_787  1
    arc_0_3_12  original_T_including_depot_unload_814  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_3_12  arc_capacity_467  1
    load_0_3_12  segment_load_conservation_745  1
    load_0_3_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_13  arc_capacity_469  -30
    arc_0_3_13  connected_order_arc_470  -14
    arc_0_3_13  out_degree_741  1
    arc_0_3_13  in_degree_793  1
    arc_0_3_13  original_T_including_depot_unload_814  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_13  arc_capacity_469  1
    load_0_3_13  segment_load_conservation_745  1
    load_0_3_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_14  arc_capacity_471  -30
    arc_0_3_14  connected_order_arc_472  -14
    arc_0_3_14  out_degree_741  1
    arc_0_3_14  in_degree_799  1
    arc_0_3_14  original_T_including_depot_unload_814  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_14  arc_capacity_471  1
    load_0_3_14  segment_load_conservation_745  1
    load_0_3_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_3_15  arc_capacity_473  -30
    arc_0_3_15  connected_order_arc_474  -14
    arc_0_3_15  out_degree_741  1
    arc_0_3_15  in_degree_805  1
    arc_0_3_15  original_T_including_depot_unload_814  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_3_15  arc_capacity_473  1
    load_0_3_15  segment_load_conservation_745  1
    load_0_3_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_0  arc_capacity_475  -30
    arc_0_4_0  depot_return_or_bypass_726  1
    arc_0_4_0  out_degree_748  1
    arc_0_4_0  original_T_including_depot_unload_814  5.9631731642067359e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_0  arc_capacity_475  1
    load_0_4_0  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_1  arc_capacity_476  -30
    arc_0_4_1  connected_order_arc_477  -14
    arc_0_4_1  in_degree_728  1
    arc_0_4_1  out_degree_748  1
    arc_0_4_1  original_T_including_depot_unload_814  8.4376826601758887e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_1  arc_capacity_476  1
    load_0_4_1  segment_load_conservation_731  -1
    load_0_4_1  segment_prefix_lb_732  1
    load_0_4_1  segment_prefix_ub_733  1
    load_0_4_1  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_2  arc_capacity_478  -30
    arc_0_4_2  connected_order_arc_479  -14
    arc_0_4_2  in_degree_735  1
    arc_0_4_2  out_degree_748  1
    arc_0_4_2  original_T_including_depot_unload_814  1.4810770279475858e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_2  arc_capacity_478  1
    load_0_4_2  segment_load_conservation_738  -1
    load_0_4_2  segment_prefix_lb_739  1
    load_0_4_2  segment_prefix_ub_740  1
    load_0_4_2  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_3  arc_capacity_480  -30
    arc_0_4_3  connected_order_arc_481  -14
    arc_0_4_3  in_degree_742  1
    arc_0_4_3  out_degree_748  1
    arc_0_4_3  original_T_including_depot_unload_814  1.5701156446555925e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_3  arc_capacity_480  1
    load_0_4_3  segment_load_conservation_745  -1
    load_0_4_3  segment_prefix_lb_746  1
    load_0_4_3  segment_prefix_ub_747  1
    load_0_4_3  segment_load_conservation_752  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_5  arc_capacity_482  -30
    arc_0_4_5  connected_order_arc_483  -14
    arc_0_4_5  out_degree_748  1
    arc_0_4_5  in_degree_756  1
    arc_0_4_5  original_T_including_depot_unload_814  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_5  arc_capacity_482  1
    load_0_4_5  segment_load_conservation_752  1
    load_0_4_5  segment_load_conservation_759  -1
    load_0_4_5  segment_prefix_lb_760  1
    load_0_4_5  segment_prefix_ub_761  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_8  arc_capacity_484  -30
    arc_0_4_8  connected_order_arc_485  -14
    arc_0_4_8  out_degree_748  1
    arc_0_4_8  in_degree_763  1
    arc_0_4_8  original_T_including_depot_unload_814  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_8  arc_capacity_484  1
    load_0_4_8  segment_load_conservation_752  1
    load_0_4_8  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_9  arc_capacity_486  -30
    arc_0_4_9  connected_order_arc_487  -14
    arc_0_4_9  out_degree_748  1
    arc_0_4_9  in_degree_769  1
    arc_0_4_9  original_T_including_depot_unload_814  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_9  arc_capacity_486  1
    load_0_4_9  segment_load_conservation_752  1
    load_0_4_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_10  arc_capacity_488  -30
    arc_0_4_10  connected_order_arc_489  -14
    arc_0_4_10  out_degree_748  1
    arc_0_4_10  in_degree_775  1
    arc_0_4_10  original_T_including_depot_unload_814  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_10  arc_capacity_488  1
    load_0_4_10  segment_load_conservation_752  1
    load_0_4_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_11  arc_capacity_490  -30
    arc_0_4_11  connected_order_arc_491  -14
    arc_0_4_11  out_degree_748  1
    arc_0_4_11  in_degree_781  1
    arc_0_4_11  original_T_including_depot_unload_814  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_11  arc_capacity_490  1
    load_0_4_11  segment_load_conservation_752  1
    load_0_4_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_12  arc_capacity_492  -30
    arc_0_4_12  connected_order_arc_493  -14
    arc_0_4_12  out_degree_748  1
    arc_0_4_12  in_degree_787  1
    arc_0_4_12  original_T_including_depot_unload_814  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_4_12  arc_capacity_492  1
    load_0_4_12  segment_load_conservation_752  1
    load_0_4_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_13  arc_capacity_494  -30
    arc_0_4_13  connected_order_arc_495  -14
    arc_0_4_13  out_degree_748  1
    arc_0_4_13  in_degree_793  1
    arc_0_4_13  original_T_including_depot_unload_814  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_13  arc_capacity_494  1
    load_0_4_13  segment_load_conservation_752  1
    load_0_4_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_14  arc_capacity_496  -30
    arc_0_4_14  connected_order_arc_497  -14
    arc_0_4_14  out_degree_748  1
    arc_0_4_14  in_degree_799  1
    arc_0_4_14  original_T_including_depot_unload_814  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_14  arc_capacity_496  1
    load_0_4_14  segment_load_conservation_752  1
    load_0_4_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_4_15  arc_capacity_498  -30
    arc_0_4_15  connected_order_arc_499  -14
    arc_0_4_15  out_degree_748  1
    arc_0_4_15  in_degree_805  1
    arc_0_4_15  original_T_including_depot_unload_814  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_4_15  arc_capacity_498  1
    load_0_4_15  segment_load_conservation_752  1
    load_0_4_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_0  arc_capacity_500  -30
    arc_0_5_0  depot_return_or_bypass_726  1
    arc_0_5_0  out_degree_755  1
    arc_0_5_0  original_T_including_depot_unload_814  4.1588440854375170e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_0  arc_capacity_500  1
    load_0_5_0  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_1  arc_capacity_501  -30
    arc_0_5_1  connected_order_arc_502  -14
    arc_0_5_1  in_degree_728  1
    arc_0_5_1  out_degree_755  1
    arc_0_5_1  original_T_including_depot_unload_814  7.2365484333226220e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_1  arc_capacity_501  1
    load_0_5_1  segment_load_conservation_731  -1
    load_0_5_1  segment_prefix_lb_732  1
    load_0_5_1  segment_prefix_ub_733  1
    load_0_5_1  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_2  arc_capacity_503  -30
    arc_0_5_2  connected_order_arc_504  -14
    arc_0_5_2  in_degree_735  1
    arc_0_5_2  out_degree_755  1
    arc_0_5_2  original_T_including_depot_unload_814  2.6178398366762252e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_2  arc_capacity_503  1
    load_0_5_2  segment_load_conservation_738  -1
    load_0_5_2  segment_prefix_lb_739  1
    load_0_5_2  segment_prefix_ub_740  1
    load_0_5_2  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_3  arc_capacity_505  -30
    arc_0_5_3  connected_order_arc_506  -14
    arc_0_5_3  in_degree_742  1
    arc_0_5_3  out_degree_755  1
    arc_0_5_3  original_T_including_depot_unload_814  3.4593676445964553e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_3  arc_capacity_505  1
    load_0_5_3  segment_load_conservation_745  -1
    load_0_5_3  segment_prefix_lb_746  1
    load_0_5_3  segment_prefix_ub_747  1
    load_0_5_3  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_4  arc_capacity_507  -30
    arc_0_5_4  connected_order_arc_508  -14
    arc_0_5_4  in_degree_749  1
    arc_0_5_4  out_degree_755  1
    arc_0_5_4  original_T_including_depot_unload_814  2.2661537412294956e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_4  arc_capacity_507  1
    load_0_5_4  segment_load_conservation_752  -1
    load_0_5_4  segment_prefix_lb_753  1
    load_0_5_4  segment_prefix_ub_754  1
    load_0_5_4  segment_load_conservation_759  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_8  arc_capacity_509  -30
    arc_0_5_8  connected_order_arc_510  -14
    arc_0_5_8  out_degree_755  1
    arc_0_5_8  in_degree_763  1
    arc_0_5_8  original_T_including_depot_unload_814  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_8  arc_capacity_509  1
    load_0_5_8  segment_load_conservation_759  1
    load_0_5_8  free_load_conservation_767  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_9  arc_capacity_511  -30
    arc_0_5_9  connected_order_arc_512  -14
    arc_0_5_9  out_degree_755  1
    arc_0_5_9  in_degree_769  1
    arc_0_5_9  original_T_including_depot_unload_814  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_5_9  arc_capacity_511  1
    load_0_5_9  segment_load_conservation_759  1
    load_0_5_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_10  arc_capacity_513  -30
    arc_0_5_10  connected_order_arc_514  -14
    arc_0_5_10  out_degree_755  1
    arc_0_5_10  in_degree_775  1
    arc_0_5_10  original_T_including_depot_unload_814  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_10  arc_capacity_513  1
    load_0_5_10  segment_load_conservation_759  1
    load_0_5_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_11  arc_capacity_515  -30
    arc_0_5_11  connected_order_arc_516  -14
    arc_0_5_11  out_degree_755  1
    arc_0_5_11  in_degree_781  1
    arc_0_5_11  original_T_including_depot_unload_814  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_11  arc_capacity_515  1
    load_0_5_11  segment_load_conservation_759  1
    load_0_5_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_12  arc_capacity_517  -30
    arc_0_5_12  connected_order_arc_518  -14
    arc_0_5_12  out_degree_755  1
    arc_0_5_12  in_degree_787  1
    arc_0_5_12  original_T_including_depot_unload_814  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_5_12  arc_capacity_517  1
    load_0_5_12  segment_load_conservation_759  1
    load_0_5_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_13  arc_capacity_519  -30
    arc_0_5_13  connected_order_arc_520  -14
    arc_0_5_13  out_degree_755  1
    arc_0_5_13  in_degree_793  1
    arc_0_5_13  original_T_including_depot_unload_814  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_13  arc_capacity_519  1
    load_0_5_13  segment_load_conservation_759  1
    load_0_5_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_14  arc_capacity_521  -30
    arc_0_5_14  connected_order_arc_522  -14
    arc_0_5_14  out_degree_755  1
    arc_0_5_14  in_degree_799  1
    arc_0_5_14  original_T_including_depot_unload_814  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_14  arc_capacity_521  1
    load_0_5_14  segment_load_conservation_759  1
    load_0_5_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_5_15  arc_capacity_523  -30
    arc_0_5_15  connected_order_arc_524  -14
    arc_0_5_15  out_degree_755  1
    arc_0_5_15  in_degree_805  1
    arc_0_5_15  original_T_including_depot_unload_814  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_5_15  arc_capacity_523  1
    load_0_5_15  segment_load_conservation_759  1
    load_0_5_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_0  arc_capacity_525  -30
    arc_0_8_0  depot_return_or_bypass_726  1
    arc_0_8_0  out_degree_762  1
    arc_0_8_0  original_T_including_depot_unload_814  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_0  arc_capacity_525  1
    load_0_8_0  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_1  arc_capacity_526  -30
    arc_0_8_1  connected_order_arc_527  -14
    arc_0_8_1  in_degree_728  1
    arc_0_8_1  out_degree_762  1
    arc_0_8_1  original_T_including_depot_unload_814  1.4558134627196880e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_1  arc_capacity_526  1
    load_0_8_1  segment_load_conservation_731  -1
    load_0_8_1  segment_prefix_lb_732  1
    load_0_8_1  segment_prefix_ub_733  1
    load_0_8_1  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_2  arc_capacity_528  -30
    arc_0_8_2  connected_order_arc_529  -14
    arc_0_8_2  in_degree_735  1
    arc_0_8_2  out_degree_762  1
    arc_0_8_2  original_T_including_depot_unload_814  7.8604521666483390e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_2  arc_capacity_528  1
    load_0_8_2  segment_load_conservation_738  -1
    load_0_8_2  segment_prefix_lb_739  1
    load_0_8_2  segment_prefix_ub_740  1
    load_0_8_2  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_3  arc_capacity_530  -30
    arc_0_8_3  connected_order_arc_531  -14
    arc_0_8_3  in_degree_742  1
    arc_0_8_3  out_degree_762  1
    arc_0_8_3  original_T_including_depot_unload_814  4.9817963927689311e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_3  arc_capacity_530  1
    load_0_8_3  segment_load_conservation_745  -1
    load_0_8_3  segment_prefix_lb_746  1
    load_0_8_3  segment_prefix_ub_747  1
    load_0_8_3  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_4  arc_capacity_532  -30
    arc_0_8_4  connected_order_arc_533  -14
    arc_0_8_4  in_degree_749  1
    arc_0_8_4  out_degree_762  1
    arc_0_8_4  original_T_including_depot_unload_814  6.4057623819624155e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_4  arc_capacity_532  1
    load_0_8_4  segment_load_conservation_752  -1
    load_0_8_4  segment_prefix_lb_753  1
    load_0_8_4  segment_prefix_ub_754  1
    load_0_8_4  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_5  arc_capacity_534  -30
    arc_0_8_5  connected_order_arc_535  -14
    arc_0_8_5  in_degree_756  1
    arc_0_8_5  out_degree_762  1
    arc_0_8_5  original_T_including_depot_unload_814  7.3627521985972965e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_5  arc_capacity_534  1
    load_0_8_5  segment_load_conservation_759  -1
    load_0_8_5  segment_prefix_lb_760  1
    load_0_8_5  segment_prefix_ub_761  1
    load_0_8_5  free_load_conservation_767  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_9  arc_capacity_536  -30
    arc_0_8_9  connected_order_arc_537  -14
    arc_0_8_9  out_degree_762  1
    arc_0_8_9  in_degree_769  1
    arc_0_8_9  original_T_including_depot_unload_814  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_9  arc_capacity_536  1
    load_0_8_9  free_load_conservation_767  1
    load_0_8_9  free_load_conservation_773  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_10  arc_capacity_538  -30
    arc_0_8_10  connected_order_arc_539  -14
    arc_0_8_10  out_degree_762  1
    arc_0_8_10  in_degree_775  1
    arc_0_8_10  original_T_including_depot_unload_814  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_10  arc_capacity_538  1
    load_0_8_10  free_load_conservation_767  1
    load_0_8_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_11  arc_capacity_540  -30
    arc_0_8_11  connected_order_arc_541  -14
    arc_0_8_11  out_degree_762  1
    arc_0_8_11  in_degree_781  1
    arc_0_8_11  original_T_including_depot_unload_814  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_11  arc_capacity_540  1
    load_0_8_11  free_load_conservation_767  1
    load_0_8_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_12  arc_capacity_542  -30
    arc_0_8_12  connected_order_arc_543  -14
    arc_0_8_12  out_degree_762  1
    arc_0_8_12  in_degree_787  1
    arc_0_8_12  original_T_including_depot_unload_814  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_8_12  arc_capacity_542  1
    load_0_8_12  free_load_conservation_767  1
    load_0_8_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_13  arc_capacity_544  -30
    arc_0_8_13  connected_order_arc_545  -14
    arc_0_8_13  out_degree_762  1
    arc_0_8_13  in_degree_793  1
    arc_0_8_13  original_T_including_depot_unload_814  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_13  arc_capacity_544  1
    load_0_8_13  free_load_conservation_767  1
    load_0_8_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_14  arc_capacity_546  -30
    arc_0_8_14  connected_order_arc_547  -14
    arc_0_8_14  out_degree_762  1
    arc_0_8_14  in_degree_799  1
    arc_0_8_14  original_T_including_depot_unload_814  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_14  arc_capacity_546  1
    load_0_8_14  free_load_conservation_767  1
    load_0_8_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_8_15  arc_capacity_548  -30
    arc_0_8_15  connected_order_arc_549  -14
    arc_0_8_15  out_degree_762  1
    arc_0_8_15  in_degree_805  1
    arc_0_8_15  original_T_including_depot_unload_814  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_8_15  arc_capacity_548  1
    load_0_8_15  free_load_conservation_767  1
    load_0_8_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_0  arc_capacity_550  -30
    arc_0_9_0  depot_return_or_bypass_726  1
    arc_0_9_0  out_degree_768  1
    arc_0_9_0  original_T_including_depot_unload_814  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_0  arc_capacity_550  1
    load_0_9_0  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_1  arc_capacity_551  -30
    arc_0_9_1  connected_order_arc_552  -14
    arc_0_9_1  in_degree_728  1
    arc_0_9_1  out_degree_768  1
    arc_0_9_1  original_T_including_depot_unload_814  1.2315777010885340e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_1  arc_capacity_551  1
    load_0_9_1  segment_load_conservation_731  -1
    load_0_9_1  segment_prefix_lb_732  1
    load_0_9_1  segment_prefix_ub_733  1
    load_0_9_1  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_2  arc_capacity_553  -30
    arc_0_9_2  connected_order_arc_554  -14
    arc_0_9_2  in_degree_735  1
    arc_0_9_2  out_degree_768  1
    arc_0_9_2  original_T_including_depot_unload_814  5.6231331158364958e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_2  arc_capacity_553  1
    load_0_9_2  segment_load_conservation_738  -1
    load_0_9_2  segment_prefix_lb_739  1
    load_0_9_2  segment_prefix_ub_740  1
    load_0_9_2  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_3  arc_capacity_555  -30
    arc_0_9_3  connected_order_arc_556  -14
    arc_0_9_3  in_degree_742  1
    arc_0_9_3  out_degree_768  1
    arc_0_9_3  original_T_including_depot_unload_814  2.8072002002622634e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_3  arc_capacity_555  1
    load_0_9_3  segment_load_conservation_745  -1
    load_0_9_3  segment_prefix_lb_746  1
    load_0_9_3  segment_prefix_ub_747  1
    load_0_9_3  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_4  arc_capacity_557  -30
    arc_0_9_4  connected_order_arc_558  -14
    arc_0_9_4  in_degree_749  1
    arc_0_9_4  out_degree_768  1
    arc_0_9_4  original_T_including_depot_unload_814  4.1557375918514475e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_4  arc_capacity_557  1
    load_0_9_4  segment_load_conservation_752  -1
    load_0_9_4  segment_prefix_lb_753  1
    load_0_9_4  segment_prefix_ub_754  1
    load_0_9_4  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_5  arc_capacity_559  -30
    arc_0_9_5  connected_order_arc_560  -14
    arc_0_9_5  in_degree_756  1
    arc_0_9_5  out_degree_768  1
    arc_0_9_5  original_T_including_depot_unload_814  516.598297486096
    MARKER    'MARKER'                 'INTEND'
    load_0_9_5  arc_capacity_559  1
    load_0_9_5  segment_load_conservation_759  -1
    load_0_9_5  segment_prefix_lb_760  1
    load_0_9_5  segment_prefix_ub_761  1
    load_0_9_5  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_8  arc_capacity_561  -30
    arc_0_9_8  connected_order_arc_562  -14
    arc_0_9_8  in_degree_763  1
    arc_0_9_8  out_degree_768  1
    arc_0_9_8  original_T_including_depot_unload_814  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_8  arc_capacity_561  1
    load_0_9_8  free_load_conservation_767  -1
    load_0_9_8  free_load_conservation_773  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_10  arc_capacity_563  -30
    arc_0_9_10  connected_order_arc_564  -14
    arc_0_9_10  out_degree_768  1
    arc_0_9_10  in_degree_775  1
    arc_0_9_10  original_T_including_depot_unload_814  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_10  arc_capacity_563  1
    load_0_9_10  free_load_conservation_773  1
    load_0_9_10  free_load_conservation_779  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_11  arc_capacity_565  -30
    arc_0_9_11  connected_order_arc_566  -14
    arc_0_9_11  out_degree_768  1
    arc_0_9_11  in_degree_781  1
    arc_0_9_11  original_T_including_depot_unload_814  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_11  arc_capacity_565  1
    load_0_9_11  free_load_conservation_773  1
    load_0_9_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_12  arc_capacity_567  -30
    arc_0_9_12  connected_order_arc_568  -14
    arc_0_9_12  out_degree_768  1
    arc_0_9_12  in_degree_787  1
    arc_0_9_12  original_T_including_depot_unload_814  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_9_12  arc_capacity_567  1
    load_0_9_12  free_load_conservation_773  1
    load_0_9_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_13  arc_capacity_569  -30
    arc_0_9_13  connected_order_arc_570  -14
    arc_0_9_13  out_degree_768  1
    arc_0_9_13  in_degree_793  1
    arc_0_9_13  original_T_including_depot_unload_814  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_13  arc_capacity_569  1
    load_0_9_13  free_load_conservation_773  1
    load_0_9_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_14  arc_capacity_571  -30
    arc_0_9_14  connected_order_arc_572  -14
    arc_0_9_14  out_degree_768  1
    arc_0_9_14  in_degree_799  1
    arc_0_9_14  original_T_including_depot_unload_814  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_14  arc_capacity_571  1
    load_0_9_14  free_load_conservation_773  1
    load_0_9_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_9_15  arc_capacity_573  -30
    arc_0_9_15  connected_order_arc_574  -14
    arc_0_9_15  out_degree_768  1
    arc_0_9_15  in_degree_805  1
    arc_0_9_15  original_T_including_depot_unload_814  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_9_15  arc_capacity_573  1
    load_0_9_15  free_load_conservation_773  1
    load_0_9_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_0  arc_capacity_575  -30
    arc_0_10_0  depot_return_or_bypass_726  1
    arc_0_10_0  out_degree_774  1
    arc_0_10_0  original_T_including_depot_unload_814  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_0  arc_capacity_575  1
    load_0_10_0  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_1  arc_capacity_576  -30
    arc_0_10_1  connected_order_arc_577  -14
    arc_0_10_1  in_degree_728  1
    arc_0_10_1  out_degree_774  1
    arc_0_10_1  original_T_including_depot_unload_814  2.4160844235310037e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_1  arc_capacity_576  1
    load_0_10_1  segment_load_conservation_731  -1
    load_0_10_1  segment_prefix_lb_732  1
    load_0_10_1  segment_prefix_ub_733  1
    load_0_10_1  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_2  arc_capacity_578  -30
    arc_0_10_2  connected_order_arc_579  -14
    arc_0_10_2  in_degree_735  1
    arc_0_10_2  out_degree_774  1
    arc_0_10_2  original_T_including_depot_unload_814  2.7957126389480295e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_2  arc_capacity_578  1
    load_0_10_2  segment_load_conservation_738  -1
    load_0_10_2  segment_prefix_lb_739  1
    load_0_10_2  segment_prefix_ub_740  1
    load_0_10_2  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_3  arc_capacity_580  -30
    arc_0_10_3  connected_order_arc_581  -14
    arc_0_10_3  in_degree_742  1
    arc_0_10_3  out_degree_774  1
    arc_0_10_3  original_T_including_depot_unload_814  2.8807002034504962e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_3  arc_capacity_580  1
    load_0_10_3  segment_load_conservation_745  -1
    load_0_10_3  segment_prefix_lb_746  1
    load_0_10_3  segment_prefix_ub_747  1
    load_0_10_3  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_4  arc_capacity_582  -30
    arc_0_10_4  connected_order_arc_583  -14
    arc_0_10_4  in_degree_749  1
    arc_0_10_4  out_degree_774  1
    arc_0_10_4  original_T_including_depot_unload_814  2.7910579461472848e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_4  arc_capacity_582  1
    load_0_10_4  segment_load_conservation_752  -1
    load_0_10_4  segment_prefix_lb_753  1
    load_0_10_4  segment_prefix_ub_754  1
    load_0_10_4  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_5  arc_capacity_584  -30
    arc_0_10_5  connected_order_arc_585  -14
    arc_0_10_5  in_degree_756  1
    arc_0_10_5  out_degree_774  1
    arc_0_10_5  original_T_including_depot_unload_814  2.5651522766561479e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_5  arc_capacity_584  1
    load_0_10_5  segment_load_conservation_759  -1
    load_0_10_5  segment_prefix_lb_760  1
    load_0_10_5  segment_prefix_ub_761  1
    load_0_10_5  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_8  arc_capacity_586  -30
    arc_0_10_8  connected_order_arc_587  -14
    arc_0_10_8  in_degree_763  1
    arc_0_10_8  out_degree_774  1
    arc_0_10_8  original_T_including_depot_unload_814  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_8  arc_capacity_586  1
    load_0_10_8  free_load_conservation_767  -1
    load_0_10_8  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_9  arc_capacity_588  -30
    arc_0_10_9  connected_order_arc_589  -14
    arc_0_10_9  in_degree_769  1
    arc_0_10_9  out_degree_774  1
    arc_0_10_9  original_T_including_depot_unload_814  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_9  arc_capacity_588  1
    load_0_10_9  free_load_conservation_773  -1
    load_0_10_9  free_load_conservation_779  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_11  arc_capacity_590  -30
    arc_0_10_11  connected_order_arc_591  -14
    arc_0_10_11  out_degree_774  1
    arc_0_10_11  in_degree_781  1
    arc_0_10_11  original_T_including_depot_unload_814  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_11  arc_capacity_590  1
    load_0_10_11  free_load_conservation_779  1
    load_0_10_11  free_load_conservation_785  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_12  arc_capacity_592  -30
    arc_0_10_12  connected_order_arc_593  -14
    arc_0_10_12  out_degree_774  1
    arc_0_10_12  in_degree_787  1
    arc_0_10_12  original_T_including_depot_unload_814  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_12  arc_capacity_592  1
    load_0_10_12  free_load_conservation_779  1
    load_0_10_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_13  arc_capacity_594  -30
    arc_0_10_13  connected_order_arc_595  -14
    arc_0_10_13  out_degree_774  1
    arc_0_10_13  in_degree_793  1
    arc_0_10_13  original_T_including_depot_unload_814  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_13  arc_capacity_594  1
    load_0_10_13  free_load_conservation_779  1
    load_0_10_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_14  arc_capacity_596  -30
    arc_0_10_14  connected_order_arc_597  -14
    arc_0_10_14  out_degree_774  1
    arc_0_10_14  in_degree_799  1
    arc_0_10_14  original_T_including_depot_unload_814  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_14  arc_capacity_596  1
    load_0_10_14  free_load_conservation_779  1
    load_0_10_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_10_15  arc_capacity_598  -30
    arc_0_10_15  connected_order_arc_599  -14
    arc_0_10_15  out_degree_774  1
    arc_0_10_15  in_degree_805  1
    arc_0_10_15  original_T_including_depot_unload_814  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_10_15  arc_capacity_598  1
    load_0_10_15  free_load_conservation_779  1
    load_0_10_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_0  arc_capacity_600  -30
    arc_0_11_0  depot_return_or_bypass_726  1
    arc_0_11_0  out_degree_780  1
    arc_0_11_0  original_T_including_depot_unload_814  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_0  arc_capacity_600  1
    load_0_11_0  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_1  arc_capacity_601  -30
    arc_0_11_1  connected_order_arc_602  -14
    arc_0_11_1  in_degree_728  1
    arc_0_11_1  out_degree_780  1
    arc_0_11_1  original_T_including_depot_unload_814  1.1046832181240914e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_1  arc_capacity_601  1
    load_0_11_1  segment_load_conservation_731  -1
    load_0_11_1  segment_prefix_lb_732  1
    load_0_11_1  segment_prefix_ub_733  1
    load_0_11_1  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_2  arc_capacity_603  -30
    arc_0_11_2  connected_order_arc_604  -14
    arc_0_11_2  in_degree_735  1
    arc_0_11_2  out_degree_780  1
    arc_0_11_2  original_T_including_depot_unload_814  4.1346687597344868e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_2  arc_capacity_603  1
    load_0_11_2  segment_load_conservation_738  -1
    load_0_11_2  segment_prefix_lb_739  1
    load_0_11_2  segment_prefix_ub_740  1
    load_0_11_2  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_3  arc_capacity_605  -30
    arc_0_11_3  connected_order_arc_606  -14
    arc_0_11_3  in_degree_742  1
    arc_0_11_3  out_degree_780  1
    arc_0_11_3  original_T_including_depot_unload_814  1.2673640125672841e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_3  arc_capacity_605  1
    load_0_11_3  segment_load_conservation_745  -1
    load_0_11_3  segment_prefix_lb_746  1
    load_0_11_3  segment_prefix_ub_747  1
    load_0_11_3  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_4  arc_capacity_607  -30
    arc_0_11_4  connected_order_arc_608  -14
    arc_0_11_4  in_degree_749  1
    arc_0_11_4  out_degree_780  1
    arc_0_11_4  original_T_including_depot_unload_814  2.6991456262177837e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_4  arc_capacity_607  1
    load_0_11_4  segment_load_conservation_752  -1
    load_0_11_4  segment_prefix_lb_753  1
    load_0_11_4  segment_prefix_ub_754  1
    load_0_11_4  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_5  arc_capacity_609  -30
    arc_0_11_5  connected_order_arc_610  -14
    arc_0_11_5  in_degree_756  1
    arc_0_11_5  out_degree_780  1
    arc_0_11_5  original_T_including_depot_unload_814  4.1180717113418365e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_5  arc_capacity_609  1
    load_0_11_5  segment_load_conservation_759  -1
    load_0_11_5  segment_prefix_lb_760  1
    load_0_11_5  segment_prefix_ub_761  1
    load_0_11_5  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_8  arc_capacity_611  -30
    arc_0_11_8  connected_order_arc_612  -14
    arc_0_11_8  in_degree_763  1
    arc_0_11_8  out_degree_780  1
    arc_0_11_8  original_T_including_depot_unload_814  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_8  arc_capacity_611  1
    load_0_11_8  free_load_conservation_767  -1
    load_0_11_8  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_9  arc_capacity_613  -30
    arc_0_11_9  connected_order_arc_614  -14
    arc_0_11_9  in_degree_769  1
    arc_0_11_9  out_degree_780  1
    arc_0_11_9  original_T_including_depot_unload_814  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_9  arc_capacity_613  1
    load_0_11_9  free_load_conservation_773  -1
    load_0_11_9  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_10  arc_capacity_615  -30
    arc_0_11_10  connected_order_arc_616  -14
    arc_0_11_10  in_degree_775  1
    arc_0_11_10  out_degree_780  1
    arc_0_11_10  original_T_including_depot_unload_814  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_10  arc_capacity_615  1
    load_0_11_10  free_load_conservation_779  -1
    load_0_11_10  free_load_conservation_785  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_12  arc_capacity_617  -30
    arc_0_11_12  connected_order_arc_618  -14
    arc_0_11_12  out_degree_780  1
    arc_0_11_12  in_degree_787  1
    arc_0_11_12  original_T_including_depot_unload_814  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_11_12  arc_capacity_617  1
    load_0_11_12  free_load_conservation_785  1
    load_0_11_12  free_load_conservation_791  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_13  arc_capacity_619  -30
    arc_0_11_13  connected_order_arc_620  -14
    arc_0_11_13  out_degree_780  1
    arc_0_11_13  in_degree_793  1
    arc_0_11_13  original_T_including_depot_unload_814  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_13  arc_capacity_619  1
    load_0_11_13  free_load_conservation_785  1
    load_0_11_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_14  arc_capacity_621  -30
    arc_0_11_14  connected_order_arc_622  -14
    arc_0_11_14  out_degree_780  1
    arc_0_11_14  in_degree_799  1
    arc_0_11_14  original_T_including_depot_unload_814  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_14  arc_capacity_621  1
    load_0_11_14  free_load_conservation_785  1
    load_0_11_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_11_15  arc_capacity_623  -30
    arc_0_11_15  connected_order_arc_624  -14
    arc_0_11_15  out_degree_780  1
    arc_0_11_15  in_degree_805  1
    arc_0_11_15  original_T_including_depot_unload_814  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_11_15  arc_capacity_623  1
    load_0_11_15  free_load_conservation_785  1
    load_0_11_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_0  arc_capacity_625  -30
    arc_0_12_0  depot_return_or_bypass_726  1
    arc_0_12_0  out_degree_786  1
    arc_0_12_0  original_T_including_depot_unload_814  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_0  arc_capacity_625  1
    load_0_12_0  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_1  arc_capacity_626  -30
    arc_0_12_1  connected_order_arc_627  -14
    arc_0_12_1  in_degree_728  1
    arc_0_12_1  out_degree_786  1
    arc_0_12_1  original_T_including_depot_unload_814  1.9791430726365086e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_1  arc_capacity_626  1
    load_0_12_1  segment_load_conservation_731  -1
    load_0_12_1  segment_prefix_lb_732  1
    load_0_12_1  segment_prefix_ub_733  1
    load_0_12_1  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_2  arc_capacity_628  -30
    arc_0_12_2  connected_order_arc_629  -14
    arc_0_12_2  in_degree_735  1
    arc_0_12_2  out_degree_786  1
    arc_0_12_2  original_T_including_depot_unload_814  2.2541698308553673e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_2  arc_capacity_628  1
    load_0_12_2  segment_load_conservation_738  -1
    load_0_12_2  segment_prefix_lb_739  1
    load_0_12_2  segment_prefix_ub_740  1
    load_0_12_2  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_3  arc_capacity_630  -30
    arc_0_12_3  connected_order_arc_631  -14
    arc_0_12_3  in_degree_742  1
    arc_0_12_3  out_degree_786  1
    arc_0_12_3  original_T_including_depot_unload_814  2.4992063774241742e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_3  arc_capacity_630  1
    load_0_12_3  segment_load_conservation_745  -1
    load_0_12_3  segment_prefix_lb_746  1
    load_0_12_3  segment_prefix_ub_747  1
    load_0_12_3  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_4  arc_capacity_632  -30
    arc_0_12_4  connected_order_arc_633  -14
    arc_0_12_4  in_degree_749  1
    arc_0_12_4  out_degree_786  1
    arc_0_12_4  original_T_including_depot_unload_814  2.3958340327791907e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_4  arc_capacity_632  1
    load_0_12_4  segment_load_conservation_752  -1
    load_0_12_4  segment_prefix_lb_753  1
    load_0_12_4  segment_prefix_ub_754  1
    load_0_12_4  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_5  arc_capacity_634  -30
    arc_0_12_5  connected_order_arc_635  -14
    arc_0_12_5  in_degree_756  1
    arc_0_12_5  out_degree_786  1
    arc_0_12_5  original_T_including_depot_unload_814  2.4543912353372671e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_5  arc_capacity_634  1
    load_0_12_5  segment_load_conservation_759  -1
    load_0_12_5  segment_prefix_lb_760  1
    load_0_12_5  segment_prefix_ub_761  1
    load_0_12_5  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_8  arc_capacity_636  -30
    arc_0_12_8  connected_order_arc_637  -14
    arc_0_12_8  in_degree_763  1
    arc_0_12_8  out_degree_786  1
    arc_0_12_8  original_T_including_depot_unload_814  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_8  arc_capacity_636  1
    load_0_12_8  free_load_conservation_767  -1
    load_0_12_8  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_9  arc_capacity_638  -30
    arc_0_12_9  connected_order_arc_639  -14
    arc_0_12_9  in_degree_769  1
    arc_0_12_9  out_degree_786  1
    arc_0_12_9  original_T_including_depot_unload_814  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_9  arc_capacity_638  1
    load_0_12_9  free_load_conservation_773  -1
    load_0_12_9  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_10  arc_capacity_640  -30
    arc_0_12_10  connected_order_arc_641  -14
    arc_0_12_10  in_degree_775  1
    arc_0_12_10  out_degree_786  1
    arc_0_12_10  original_T_including_depot_unload_814  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_10  arc_capacity_640  1
    load_0_12_10  free_load_conservation_779  -1
    load_0_12_10  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_11  arc_capacity_642  -30
    arc_0_12_11  connected_order_arc_643  -14
    arc_0_12_11  in_degree_781  1
    arc_0_12_11  out_degree_786  1
    arc_0_12_11  original_T_including_depot_unload_814  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_11  arc_capacity_642  1
    load_0_12_11  free_load_conservation_785  -1
    load_0_12_11  free_load_conservation_791  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_13  arc_capacity_644  -30
    arc_0_12_13  connected_order_arc_645  -14
    arc_0_12_13  out_degree_786  1
    arc_0_12_13  in_degree_793  1
    arc_0_12_13  original_T_including_depot_unload_814  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_13  arc_capacity_644  1
    load_0_12_13  free_load_conservation_791  1
    load_0_12_13  free_load_conservation_797  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_14  arc_capacity_646  -30
    arc_0_12_14  connected_order_arc_647  -14
    arc_0_12_14  out_degree_786  1
    arc_0_12_14  in_degree_799  1
    arc_0_12_14  original_T_including_depot_unload_814  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_14  arc_capacity_646  1
    load_0_12_14  free_load_conservation_791  1
    load_0_12_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_12_15  arc_capacity_648  -30
    arc_0_12_15  connected_order_arc_649  -14
    arc_0_12_15  out_degree_786  1
    arc_0_12_15  in_degree_805  1
    arc_0_12_15  original_T_including_depot_unload_814  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_12_15  arc_capacity_648  1
    load_0_12_15  free_load_conservation_791  1
    load_0_12_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_0  arc_capacity_650  -30
    arc_0_13_0  depot_return_or_bypass_726  1
    arc_0_13_0  out_degree_792  1
    arc_0_13_0  original_T_including_depot_unload_814  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_0  arc_capacity_650  1
    load_0_13_0  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_1  arc_capacity_651  -30
    arc_0_13_1  connected_order_arc_652  -14
    arc_0_13_1  in_degree_728  1
    arc_0_13_1  out_degree_792  1
    arc_0_13_1  original_T_including_depot_unload_814  1.4485896981484648e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_1  arc_capacity_651  1
    load_0_13_1  segment_load_conservation_731  -1
    load_0_13_1  segment_prefix_lb_732  1
    load_0_13_1  segment_prefix_ub_733  1
    load_0_13_1  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_2  arc_capacity_653  -30
    arc_0_13_2  connected_order_arc_654  -14
    arc_0_13_2  in_degree_735  1
    arc_0_13_2  out_degree_792  1
    arc_0_13_2  original_T_including_depot_unload_814  7.2186296856879846e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_2  arc_capacity_653  1
    load_0_13_2  segment_load_conservation_738  -1
    load_0_13_2  segment_prefix_lb_739  1
    load_0_13_2  segment_prefix_ub_740  1
    load_0_13_2  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_3  arc_capacity_655  -30
    arc_0_13_3  connected_order_arc_656  -14
    arc_0_13_3  in_degree_742  1
    arc_0_13_3  out_degree_792  1
    arc_0_13_3  original_T_including_depot_unload_814  4.7721499161748335e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_3  arc_capacity_655  1
    load_0_13_3  segment_load_conservation_745  -1
    load_0_13_3  segment_prefix_lb_746  1
    load_0_13_3  segment_prefix_ub_747  1
    load_0_13_3  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_4  arc_capacity_657  -30
    arc_0_13_4  connected_order_arc_658  -14
    arc_0_13_4  in_degree_749  1
    arc_0_13_4  out_degree_792  1
    arc_0_13_4  original_T_including_depot_unload_814  6.2279118029742506e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_4  arc_capacity_657  1
    load_0_13_4  segment_load_conservation_752  -1
    load_0_13_4  segment_prefix_lb_753  1
    load_0_13_4  segment_prefix_ub_754  1
    load_0_13_4  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_5  arc_capacity_659  -30
    arc_0_13_5  connected_order_arc_660  -14
    arc_0_13_5  in_degree_756  1
    arc_0_13_5  out_degree_792  1
    arc_0_13_5  original_T_including_depot_unload_814  8.2210727717430609e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_5  arc_capacity_659  1
    load_0_13_5  segment_load_conservation_759  -1
    load_0_13_5  segment_prefix_lb_760  1
    load_0_13_5  segment_prefix_ub_761  1
    load_0_13_5  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_8  arc_capacity_661  -30
    arc_0_13_8  connected_order_arc_662  -14
    arc_0_13_8  in_degree_763  1
    arc_0_13_8  out_degree_792  1
    arc_0_13_8  original_T_including_depot_unload_814  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_8  arc_capacity_661  1
    load_0_13_8  free_load_conservation_767  -1
    load_0_13_8  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_9  arc_capacity_663  -30
    arc_0_13_9  connected_order_arc_664  -14
    arc_0_13_9  in_degree_769  1
    arc_0_13_9  out_degree_792  1
    arc_0_13_9  original_T_including_depot_unload_814  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_9  arc_capacity_663  1
    load_0_13_9  free_load_conservation_773  -1
    load_0_13_9  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_10  arc_capacity_665  -30
    arc_0_13_10  connected_order_arc_666  -14
    arc_0_13_10  in_degree_775  1
    arc_0_13_10  out_degree_792  1
    arc_0_13_10  original_T_including_depot_unload_814  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_10  arc_capacity_665  1
    load_0_13_10  free_load_conservation_779  -1
    load_0_13_10  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_11  arc_capacity_667  -30
    arc_0_13_11  connected_order_arc_668  -14
    arc_0_13_11  in_degree_781  1
    arc_0_13_11  out_degree_792  1
    arc_0_13_11  original_T_including_depot_unload_814  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_11  arc_capacity_667  1
    load_0_13_11  free_load_conservation_785  -1
    load_0_13_11  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_12  arc_capacity_669  -30
    arc_0_13_12  connected_order_arc_670  -14
    arc_0_13_12  in_degree_787  1
    arc_0_13_12  out_degree_792  1
    arc_0_13_12  original_T_including_depot_unload_814  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_13_12  arc_capacity_669  1
    load_0_13_12  free_load_conservation_791  -1
    load_0_13_12  free_load_conservation_797  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_14  arc_capacity_671  -30
    arc_0_13_14  connected_order_arc_672  -14
    arc_0_13_14  out_degree_792  1
    arc_0_13_14  in_degree_799  1
    arc_0_13_14  original_T_including_depot_unload_814  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_14  arc_capacity_671  1
    load_0_13_14  free_load_conservation_797  1
    load_0_13_14  free_load_conservation_803  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_13_15  arc_capacity_673  -30
    arc_0_13_15  connected_order_arc_674  -14
    arc_0_13_15  out_degree_792  1
    arc_0_13_15  in_degree_805  1
    arc_0_13_15  original_T_including_depot_unload_814  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_13_15  arc_capacity_673  1
    load_0_13_15  free_load_conservation_797  1
    load_0_13_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_0  arc_capacity_675  -30
    arc_0_14_0  depot_return_or_bypass_726  1
    arc_0_14_0  out_degree_798  1
    arc_0_14_0  original_T_including_depot_unload_814  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_0  arc_capacity_675  1
    load_0_14_0  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_1  arc_capacity_676  -30
    arc_0_14_1  connected_order_arc_677  -14
    arc_0_14_1  in_degree_728  1
    arc_0_14_1  out_degree_798  1
    arc_0_14_1  original_T_including_depot_unload_814  6.3975035388222534e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_1  arc_capacity_676  1
    load_0_14_1  segment_load_conservation_731  -1
    load_0_14_1  segment_prefix_lb_732  1
    load_0_14_1  segment_prefix_ub_733  1
    load_0_14_1  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_2  arc_capacity_678  -30
    arc_0_14_2  connected_order_arc_679  -14
    arc_0_14_2  in_degree_735  1
    arc_0_14_2  out_degree_798  1
    arc_0_14_2  original_T_including_depot_unload_814  1.2480053261465446e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_2  arc_capacity_678  1
    load_0_14_2  segment_load_conservation_738  -1
    load_0_14_2  segment_prefix_lb_739  1
    load_0_14_2  segment_prefix_ub_740  1
    load_0_14_2  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_3  arc_capacity_680  -30
    arc_0_14_3  connected_order_arc_681  -14
    arc_0_14_3  in_degree_742  1
    arc_0_14_3  out_degree_798  1
    arc_0_14_3  original_T_including_depot_unload_814  3.6114004430677619e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_3  arc_capacity_680  1
    load_0_14_3  segment_load_conservation_745  -1
    load_0_14_3  segment_prefix_lb_746  1
    load_0_14_3  segment_prefix_ub_747  1
    load_0_14_3  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_4  arc_capacity_682  -30
    arc_0_14_4  connected_order_arc_683  -14
    arc_0_14_4  in_degree_749  1
    arc_0_14_4  out_degree_798  1
    arc_0_14_4  original_T_including_depot_unload_814  2.0430160967046345e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_4  arc_capacity_682  1
    load_0_14_4  segment_load_conservation_752  -1
    load_0_14_4  segment_prefix_lb_753  1
    load_0_14_4  segment_prefix_ub_754  1
    load_0_14_4  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_5  arc_capacity_684  -30
    arc_0_14_5  connected_order_arc_685  -14
    arc_0_14_5  in_degree_756  1
    arc_0_14_5  out_degree_798  1
    arc_0_14_5  original_T_including_depot_unload_814  1.7839442696984972e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_5  arc_capacity_684  1
    load_0_14_5  segment_load_conservation_759  -1
    load_0_14_5  segment_prefix_lb_760  1
    load_0_14_5  segment_prefix_ub_761  1
    load_0_14_5  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_8  arc_capacity_686  -30
    arc_0_14_8  connected_order_arc_687  -14
    arc_0_14_8  in_degree_763  1
    arc_0_14_8  out_degree_798  1
    arc_0_14_8  original_T_including_depot_unload_814  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_8  arc_capacity_686  1
    load_0_14_8  free_load_conservation_767  -1
    load_0_14_8  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_9  arc_capacity_688  -30
    arc_0_14_9  connected_order_arc_689  -14
    arc_0_14_9  in_degree_769  1
    arc_0_14_9  out_degree_798  1
    arc_0_14_9  original_T_including_depot_unload_814  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_9  arc_capacity_688  1
    load_0_14_9  free_load_conservation_773  -1
    load_0_14_9  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_10  arc_capacity_690  -30
    arc_0_14_10  connected_order_arc_691  -14
    arc_0_14_10  in_degree_775  1
    arc_0_14_10  out_degree_798  1
    arc_0_14_10  original_T_including_depot_unload_814  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_10  arc_capacity_690  1
    load_0_14_10  free_load_conservation_779  -1
    load_0_14_10  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_11  arc_capacity_692  -30
    arc_0_14_11  connected_order_arc_693  -14
    arc_0_14_11  in_degree_781  1
    arc_0_14_11  out_degree_798  1
    arc_0_14_11  original_T_including_depot_unload_814  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_11  arc_capacity_692  1
    load_0_14_11  free_load_conservation_785  -1
    load_0_14_11  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_12  arc_capacity_694  -30
    arc_0_14_12  connected_order_arc_695  -14
    arc_0_14_12  in_degree_787  1
    arc_0_14_12  out_degree_798  1
    arc_0_14_12  original_T_including_depot_unload_814  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_14_12  arc_capacity_694  1
    load_0_14_12  free_load_conservation_791  -1
    load_0_14_12  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_13  arc_capacity_696  -30
    arc_0_14_13  connected_order_arc_697  -14
    arc_0_14_13  in_degree_793  1
    arc_0_14_13  out_degree_798  1
    arc_0_14_13  original_T_including_depot_unload_814  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_13  arc_capacity_696  1
    load_0_14_13  free_load_conservation_797  -1
    load_0_14_13  free_load_conservation_803  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_14_15  arc_capacity_698  -30
    arc_0_14_15  connected_order_arc_699  -14
    arc_0_14_15  out_degree_798  1
    arc_0_14_15  in_degree_805  1
    arc_0_14_15  original_T_including_depot_unload_814  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_14_15  arc_capacity_698  1
    load_0_14_15  free_load_conservation_803  1
    load_0_14_15  free_load_conservation_809  -1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_0  arc_capacity_700  -30
    arc_0_15_0  depot_return_or_bypass_726  1
    arc_0_15_0  out_degree_804  1
    arc_0_15_0  original_T_including_depot_unload_814  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_0  arc_capacity_700  1
    load_0_15_0  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_1  arc_capacity_701  -30
    arc_0_15_1  connected_order_arc_702  -14
    arc_0_15_1  in_degree_728  1
    arc_0_15_1  out_degree_804  1
    arc_0_15_1  original_T_including_depot_unload_814  1.1702148343313254e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_1  arc_capacity_701  1
    load_0_15_1  segment_load_conservation_731  -1
    load_0_15_1  segment_prefix_lb_732  1
    load_0_15_1  segment_prefix_ub_733  1
    load_0_15_1  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_2  arc_capacity_703  -30
    arc_0_15_2  connected_order_arc_704  -14
    arc_0_15_2  in_degree_735  1
    arc_0_15_2  out_degree_804  1
    arc_0_15_2  original_T_including_depot_unload_814  4.4360641393992279e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_2  arc_capacity_703  1
    load_0_15_2  segment_load_conservation_738  -1
    load_0_15_2  segment_prefix_lb_739  1
    load_0_15_2  segment_prefix_ub_740  1
    load_0_15_2  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_3  arc_capacity_705  -30
    arc_0_15_3  connected_order_arc_706  -14
    arc_0_15_3  in_degree_742  1
    arc_0_15_3  out_degree_804  1
    arc_0_15_3  original_T_including_depot_unload_814  2.0082608212298291e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_3  arc_capacity_705  1
    load_0_15_3  segment_load_conservation_745  -1
    load_0_15_3  segment_prefix_lb_746  1
    load_0_15_3  segment_prefix_ub_747  1
    load_0_15_3  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_4  arc_capacity_707  -30
    arc_0_15_4  connected_order_arc_708  -14
    arc_0_15_4  in_degree_749  1
    arc_0_15_4  out_degree_804  1
    arc_0_15_4  original_T_including_depot_unload_814  3.4037893208114895e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_4  arc_capacity_707  1
    load_0_15_4  segment_load_conservation_752  -1
    load_0_15_4  segment_prefix_lb_753  1
    load_0_15_4  segment_prefix_ub_754  1
    load_0_15_4  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_5  arc_capacity_709  -30
    arc_0_15_5  connected_order_arc_710  -14
    arc_0_15_5  in_degree_756  1
    arc_0_15_5  out_degree_804  1
    arc_0_15_5  original_T_including_depot_unload_814  5.4626430531406254e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_5  arc_capacity_709  1
    load_0_15_5  segment_load_conservation_759  -1
    load_0_15_5  segment_prefix_lb_760  1
    load_0_15_5  segment_prefix_ub_761  1
    load_0_15_5  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_8  arc_capacity_711  -30
    arc_0_15_8  connected_order_arc_712  -14
    arc_0_15_8  in_degree_763  1
    arc_0_15_8  out_degree_804  1
    arc_0_15_8  original_T_including_depot_unload_814  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_8  arc_capacity_711  1
    load_0_15_8  free_load_conservation_767  -1
    load_0_15_8  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_9  arc_capacity_713  -30
    arc_0_15_9  connected_order_arc_714  -14
    arc_0_15_9  in_degree_769  1
    arc_0_15_9  out_degree_804  1
    arc_0_15_9  original_T_including_depot_unload_814  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_9  arc_capacity_713  1
    load_0_15_9  free_load_conservation_773  -1
    load_0_15_9  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_10  arc_capacity_715  -30
    arc_0_15_10  connected_order_arc_716  -14
    arc_0_15_10  in_degree_775  1
    arc_0_15_10  out_degree_804  1
    arc_0_15_10  original_T_including_depot_unload_814  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_10  arc_capacity_715  1
    load_0_15_10  free_load_conservation_779  -1
    load_0_15_10  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_11  arc_capacity_717  -30
    arc_0_15_11  connected_order_arc_718  -14
    arc_0_15_11  in_degree_781  1
    arc_0_15_11  out_degree_804  1
    arc_0_15_11  original_T_including_depot_unload_814  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_11  arc_capacity_717  1
    load_0_15_11  free_load_conservation_785  -1
    load_0_15_11  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_12  arc_capacity_719  -30
    arc_0_15_12  connected_order_arc_720  -14
    arc_0_15_12  in_degree_787  1
    arc_0_15_12  out_degree_804  1
    arc_0_15_12  original_T_including_depot_unload_814  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_0_15_12  arc_capacity_719  1
    load_0_15_12  free_load_conservation_791  -1
    load_0_15_12  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_13  arc_capacity_721  -30
    arc_0_15_13  connected_order_arc_722  -14
    arc_0_15_13  in_degree_793  1
    arc_0_15_13  out_degree_804  1
    arc_0_15_13  original_T_including_depot_unload_814  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_13  arc_capacity_721  1
    load_0_15_13  free_load_conservation_797  -1
    load_0_15_13  free_load_conservation_809  1
    MARKER    'MARKER'                 'INTORG'
    arc_0_15_14  arc_capacity_723  -30
    arc_0_15_14  connected_order_arc_724  -14
    arc_0_15_14  in_degree_799  1
    arc_0_15_14  out_degree_804  1
    arc_0_15_14  original_T_including_depot_unload_814  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_0_15_14  arc_capacity_723  1
    load_0_15_14  free_load_conservation_803  -1
    load_0_15_14  free_load_conservation_809  1
    visit_1_6  out_degree_1018  -1
    visit_1_6  in_degree_1019  -1
    visit_1_6  order_active_lb_1020  -1
    visit_1_6  order_active_ub_1021  -10
    order_1_6  connected_order_arc_828  -1
    order_1_6  connected_order_arc_830  -1
    order_1_6  connected_order_arc_832  -1
    order_1_6  connected_order_arc_834  -1
    order_1_6  connected_order_arc_836  -1
    order_1_6  connected_order_arc_838  -1
    order_1_6  connected_order_arc_840  -1
    order_1_6  connected_order_arc_842  -1
    order_1_6  connected_order_arc_844  -1
    order_1_6  connected_order_arc_847  1
    order_1_6  connected_order_arc_866  1
    order_1_6  connected_order_arc_885  1
    order_1_6  connected_order_arc_904  1
    order_1_6  connected_order_arc_923  1
    order_1_6  connected_order_arc_942  1
    order_1_6  connected_order_arc_961  1
    order_1_6  connected_order_arc_980  1
    order_1_6  connected_order_arc_999  1
    order_1_6  order_active_lb_1020  1
    order_1_6  order_active_ub_1021  1
    order_1_6  fixed_segment_relative_order_1080  -1
    visit_1_7  out_degree_1025  -1
    visit_1_7  in_degree_1026  -1
    visit_1_7  order_active_lb_1027  -1
    visit_1_7  order_active_ub_1028  -10
    order_1_7  connected_order_arc_828  1
    order_1_7  connected_order_arc_847  -1
    order_1_7  connected_order_arc_849  -1
    order_1_7  connected_order_arc_851  -1
    order_1_7  connected_order_arc_853  -1
    order_1_7  connected_order_arc_855  -1
    order_1_7  connected_order_arc_857  -1
    order_1_7  connected_order_arc_859  -1
    order_1_7  connected_order_arc_861  -1
    order_1_7  connected_order_arc_863  -1
    order_1_7  connected_order_arc_868  1
    order_1_7  connected_order_arc_887  1
    order_1_7  connected_order_arc_906  1
    order_1_7  connected_order_arc_925  1
    order_1_7  connected_order_arc_944  1
    order_1_7  connected_order_arc_963  1
    order_1_7  connected_order_arc_982  1
    order_1_7  connected_order_arc_1001  1
    order_1_7  order_active_lb_1027  1
    order_1_7  order_active_ub_1028  1
    order_1_7  fixed_segment_relative_order_1080  1
    visit_1_8  out_degree_1032  -1
    visit_1_8  in_degree_1033  -1
    visit_1_8  order_active_lb_1034  -1
    visit_1_8  order_active_ub_1035  -10
    visit_1_8  service_visit_def_1036  -1
    order_1_8  connected_order_arc_830  1
    order_1_8  connected_order_arc_849  1
    order_1_8  connected_order_arc_866  -1
    order_1_8  connected_order_arc_868  -1
    order_1_8  connected_order_arc_870  -1
    order_1_8  connected_order_arc_872  -1
    order_1_8  connected_order_arc_874  -1
    order_1_8  connected_order_arc_876  -1
    order_1_8  connected_order_arc_878  -1
    order_1_8  connected_order_arc_880  -1
    order_1_8  connected_order_arc_882  -1
    order_1_8  connected_order_arc_889  1
    order_1_8  connected_order_arc_908  1
    order_1_8  connected_order_arc_927  1
    order_1_8  connected_order_arc_946  1
    order_1_8  connected_order_arc_965  1
    order_1_8  connected_order_arc_984  1
    order_1_8  connected_order_arc_1003  1
    order_1_8  order_active_lb_1034  1
    order_1_8  order_active_ub_1035  1
    visit_1_9  out_degree_1038  -1
    visit_1_9  in_degree_1039  -1
    visit_1_9  order_active_lb_1040  -1
    visit_1_9  order_active_ub_1041  -10
    visit_1_9  service_visit_def_1042  -1
    order_1_9  connected_order_arc_832  1
    order_1_9  connected_order_arc_851  1
    order_1_9  connected_order_arc_870  1
    order_1_9  connected_order_arc_885  -1
    order_1_9  connected_order_arc_887  -1
    order_1_9  connected_order_arc_889  -1
    order_1_9  connected_order_arc_891  -1
    order_1_9  connected_order_arc_893  -1
    order_1_9  connected_order_arc_895  -1
    order_1_9  connected_order_arc_897  -1
    order_1_9  connected_order_arc_899  -1
    order_1_9  connected_order_arc_901  -1
    order_1_9  connected_order_arc_910  1
    order_1_9  connected_order_arc_929  1
    order_1_9  connected_order_arc_948  1
    order_1_9  connected_order_arc_967  1
    order_1_9  connected_order_arc_986  1
    order_1_9  connected_order_arc_1005  1
    order_1_9  order_active_lb_1040  1
    order_1_9  order_active_ub_1041  1
    visit_1_10  out_degree_1044  -1
    visit_1_10  in_degree_1045  -1
    visit_1_10  order_active_lb_1046  -1
    visit_1_10  order_active_ub_1047  -10
    visit_1_10  service_visit_def_1048  -1
    order_1_10  connected_order_arc_834  1
    order_1_10  connected_order_arc_853  1
    order_1_10  connected_order_arc_872  1
    order_1_10  connected_order_arc_891  1
    order_1_10  connected_order_arc_904  -1
    order_1_10  connected_order_arc_906  -1
    order_1_10  connected_order_arc_908  -1
    order_1_10  connected_order_arc_910  -1
    order_1_10  connected_order_arc_912  -1
    order_1_10  connected_order_arc_914  -1
    order_1_10  connected_order_arc_916  -1
    order_1_10  connected_order_arc_918  -1
    order_1_10  connected_order_arc_920  -1
    order_1_10  connected_order_arc_931  1
    order_1_10  connected_order_arc_950  1
    order_1_10  connected_order_arc_969  1
    order_1_10  connected_order_arc_988  1
    order_1_10  connected_order_arc_1007  1
    order_1_10  order_active_lb_1046  1
    order_1_10  order_active_ub_1047  1
    visit_1_11  out_degree_1050  -1
    visit_1_11  in_degree_1051  -1
    visit_1_11  order_active_lb_1052  -1
    visit_1_11  order_active_ub_1053  -10
    visit_1_11  service_visit_def_1054  -1
    order_1_11  connected_order_arc_836  1
    order_1_11  connected_order_arc_855  1
    order_1_11  connected_order_arc_874  1
    order_1_11  connected_order_arc_893  1
    order_1_11  connected_order_arc_912  1
    order_1_11  connected_order_arc_923  -1
    order_1_11  connected_order_arc_925  -1
    order_1_11  connected_order_arc_927  -1
    order_1_11  connected_order_arc_929  -1
    order_1_11  connected_order_arc_931  -1
    order_1_11  connected_order_arc_933  -1
    order_1_11  connected_order_arc_935  -1
    order_1_11  connected_order_arc_937  -1
    order_1_11  connected_order_arc_939  -1
    order_1_11  connected_order_arc_952  1
    order_1_11  connected_order_arc_971  1
    order_1_11  connected_order_arc_990  1
    order_1_11  connected_order_arc_1009  1
    order_1_11  order_active_lb_1052  1
    order_1_11  order_active_ub_1053  1
    visit_1_12  out_degree_1056  -1
    visit_1_12  in_degree_1057  -1
    visit_1_12  order_active_lb_1058  -1
    visit_1_12  order_active_ub_1059  -10
    visit_1_12  service_visit_def_1060  -1
    order_1_12  connected_order_arc_838  1
    order_1_12  connected_order_arc_857  1
    order_1_12  connected_order_arc_876  1
    order_1_12  connected_order_arc_895  1
    order_1_12  connected_order_arc_914  1
    order_1_12  connected_order_arc_933  1
    order_1_12  connected_order_arc_942  -1
    order_1_12  connected_order_arc_944  -1
    order_1_12  connected_order_arc_946  -1
    order_1_12  connected_order_arc_948  -1
    order_1_12  connected_order_arc_950  -1
    order_1_12  connected_order_arc_952  -1
    order_1_12  connected_order_arc_954  -1
    order_1_12  connected_order_arc_956  -1
    order_1_12  connected_order_arc_958  -1
    order_1_12  connected_order_arc_973  1
    order_1_12  connected_order_arc_992  1
    order_1_12  connected_order_arc_1011  1
    order_1_12  order_active_lb_1058  1
    order_1_12  order_active_ub_1059  1
    visit_1_13  out_degree_1062  -1
    visit_1_13  in_degree_1063  -1
    visit_1_13  order_active_lb_1064  -1
    visit_1_13  order_active_ub_1065  -10
    visit_1_13  service_visit_def_1066  -1
    order_1_13  connected_order_arc_840  1
    order_1_13  connected_order_arc_859  1
    order_1_13  connected_order_arc_878  1
    order_1_13  connected_order_arc_897  1
    order_1_13  connected_order_arc_916  1
    order_1_13  connected_order_arc_935  1
    order_1_13  connected_order_arc_954  1
    order_1_13  connected_order_arc_961  -1
    order_1_13  connected_order_arc_963  -1
    order_1_13  connected_order_arc_965  -1
    order_1_13  connected_order_arc_967  -1
    order_1_13  connected_order_arc_969  -1
    order_1_13  connected_order_arc_971  -1
    order_1_13  connected_order_arc_973  -1
    order_1_13  connected_order_arc_975  -1
    order_1_13  connected_order_arc_977  -1
    order_1_13  connected_order_arc_994  1
    order_1_13  connected_order_arc_1013  1
    order_1_13  order_active_lb_1064  1
    order_1_13  order_active_ub_1065  1
    visit_1_14  out_degree_1068  -1
    visit_1_14  in_degree_1069  -1
    visit_1_14  order_active_lb_1070  -1
    visit_1_14  order_active_ub_1071  -10
    visit_1_14  service_visit_def_1072  -1
    order_1_14  connected_order_arc_842  1
    order_1_14  connected_order_arc_861  1
    order_1_14  connected_order_arc_880  1
    order_1_14  connected_order_arc_899  1
    order_1_14  connected_order_arc_918  1
    order_1_14  connected_order_arc_937  1
    order_1_14  connected_order_arc_956  1
    order_1_14  connected_order_arc_975  1
    order_1_14  connected_order_arc_980  -1
    order_1_14  connected_order_arc_982  -1
    order_1_14  connected_order_arc_984  -1
    order_1_14  connected_order_arc_986  -1
    order_1_14  connected_order_arc_988  -1
    order_1_14  connected_order_arc_990  -1
    order_1_14  connected_order_arc_992  -1
    order_1_14  connected_order_arc_994  -1
    order_1_14  connected_order_arc_996  -1
    order_1_14  connected_order_arc_1015  1
    order_1_14  order_active_lb_1070  1
    order_1_14  order_active_ub_1071  1
    visit_1_15  out_degree_1074  -1
    visit_1_15  in_degree_1075  -1
    visit_1_15  order_active_lb_1076  -1
    visit_1_15  order_active_ub_1077  -10
    visit_1_15  service_visit_def_1078  -1
    order_1_15  connected_order_arc_844  1
    order_1_15  connected_order_arc_863  1
    order_1_15  connected_order_arc_882  1
    order_1_15  connected_order_arc_901  1
    order_1_15  connected_order_arc_920  1
    order_1_15  connected_order_arc_939  1
    order_1_15  connected_order_arc_958  1
    order_1_15  connected_order_arc_977  1
    order_1_15  connected_order_arc_996  1
    order_1_15  connected_order_arc_999  -1
    order_1_15  connected_order_arc_1001  -1
    order_1_15  connected_order_arc_1003  -1
    order_1_15  connected_order_arc_1005  -1
    order_1_15  connected_order_arc_1007  -1
    order_1_15  connected_order_arc_1009  -1
    order_1_15  connected_order_arc_1011  -1
    order_1_15  connected_order_arc_1013  -1
    order_1_15  connected_order_arc_1015  -1
    order_1_15  order_active_lb_1076  1
    order_1_15  order_active_ub_1077  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_0  arc_capacity_815  -30
    arc_1_0_0  depot_departure_or_bypass_1016  1
    arc_1_0_0  depot_return_or_bypass_1017  1
    MARKER    'MARKER'                 'INTEND'
    load_1_0_0  arc_capacity_815  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_6  arc_capacity_816  -30
    arc_1_0_6  depot_departure_or_bypass_1016  1
    arc_1_0_6  in_degree_1019  1
    arc_1_0_6  original_T_including_depot_unload_1081  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_6  arc_capacity_816  1
    load_1_0_6  segment_load_conservation_1022  -1
    load_1_0_6  segment_prefix_lb_1023  1
    load_1_0_6  segment_prefix_ub_1024  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_7  arc_capacity_817  -30
    arc_1_0_7  depot_departure_or_bypass_1016  1
    arc_1_0_7  in_degree_1026  1
    arc_1_0_7  original_T_including_depot_unload_1081  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_0_7  arc_capacity_817  1
    load_1_0_7  segment_load_conservation_1029  -1
    load_1_0_7  segment_prefix_lb_1030  1
    load_1_0_7  segment_prefix_ub_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_8  arc_capacity_818  -30
    arc_1_0_8  depot_departure_or_bypass_1016  1
    arc_1_0_8  in_degree_1033  1
    arc_1_0_8  original_T_including_depot_unload_1081  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_8  arc_capacity_818  1
    load_1_0_8  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_9  arc_capacity_819  -30
    arc_1_0_9  depot_departure_or_bypass_1016  1
    arc_1_0_9  in_degree_1039  1
    arc_1_0_9  original_T_including_depot_unload_1081  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_9  arc_capacity_819  1
    load_1_0_9  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_10  arc_capacity_820  -30
    arc_1_0_10  depot_departure_or_bypass_1016  1
    arc_1_0_10  in_degree_1045  1
    arc_1_0_10  original_T_including_depot_unload_1081  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_10  arc_capacity_820  1
    load_1_0_10  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_11  arc_capacity_821  -30
    arc_1_0_11  depot_departure_or_bypass_1016  1
    arc_1_0_11  in_degree_1051  1
    arc_1_0_11  original_T_including_depot_unload_1081  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_11  arc_capacity_821  1
    load_1_0_11  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_12  arc_capacity_822  -30
    arc_1_0_12  depot_departure_or_bypass_1016  1
    arc_1_0_12  in_degree_1057  1
    arc_1_0_12  original_T_including_depot_unload_1081  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_12  arc_capacity_822  1
    load_1_0_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_13  arc_capacity_823  -30
    arc_1_0_13  depot_departure_or_bypass_1016  1
    arc_1_0_13  in_degree_1063  1
    arc_1_0_13  original_T_including_depot_unload_1081  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_0_13  arc_capacity_823  1
    load_1_0_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_14  arc_capacity_824  -30
    arc_1_0_14  depot_departure_or_bypass_1016  1
    arc_1_0_14  in_degree_1069  1
    arc_1_0_14  original_T_including_depot_unload_1081  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_14  arc_capacity_824  1
    load_1_0_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_0_15  arc_capacity_825  -30
    arc_1_0_15  depot_departure_or_bypass_1016  1
    arc_1_0_15  in_degree_1075  1
    arc_1_0_15  original_T_including_depot_unload_1081  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_0_15  arc_capacity_825  1
    load_1_0_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_0  arc_capacity_826  -30
    arc_1_6_0  depot_return_or_bypass_1017  1
    arc_1_6_0  out_degree_1018  1
    arc_1_6_0  original_T_including_depot_unload_1081  1.8065333212349267e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_0  arc_capacity_826  1
    load_1_6_0  segment_load_conservation_1022  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_7  arc_capacity_827  -30
    arc_1_6_7  connected_order_arc_828  -11
    arc_1_6_7  out_degree_1018  1
    arc_1_6_7  in_degree_1026  1
    arc_1_6_7  original_T_including_depot_unload_1081  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_7  arc_capacity_827  1
    load_1_6_7  segment_load_conservation_1022  1
    load_1_6_7  segment_load_conservation_1029  -1
    load_1_6_7  segment_prefix_lb_1030  1
    load_1_6_7  segment_prefix_ub_1031  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_8  arc_capacity_829  -30
    arc_1_6_8  connected_order_arc_830  -11
    arc_1_6_8  out_degree_1018  1
    arc_1_6_8  in_degree_1033  1
    arc_1_6_8  original_T_including_depot_unload_1081  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_8  arc_capacity_829  1
    load_1_6_8  segment_load_conservation_1022  1
    load_1_6_8  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_9  arc_capacity_831  -30
    arc_1_6_9  connected_order_arc_832  -11
    arc_1_6_9  out_degree_1018  1
    arc_1_6_9  in_degree_1039  1
    arc_1_6_9  original_T_including_depot_unload_1081  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_9  arc_capacity_831  1
    load_1_6_9  segment_load_conservation_1022  1
    load_1_6_9  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_10  arc_capacity_833  -30
    arc_1_6_10  connected_order_arc_834  -11
    arc_1_6_10  out_degree_1018  1
    arc_1_6_10  in_degree_1045  1
    arc_1_6_10  original_T_including_depot_unload_1081  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_10  arc_capacity_833  1
    load_1_6_10  segment_load_conservation_1022  1
    load_1_6_10  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_11  arc_capacity_835  -30
    arc_1_6_11  connected_order_arc_836  -11
    arc_1_6_11  out_degree_1018  1
    arc_1_6_11  in_degree_1051  1
    arc_1_6_11  original_T_including_depot_unload_1081  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_11  arc_capacity_835  1
    load_1_6_11  segment_load_conservation_1022  1
    load_1_6_11  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_12  arc_capacity_837  -30
    arc_1_6_12  connected_order_arc_838  -11
    arc_1_6_12  out_degree_1018  1
    arc_1_6_12  in_degree_1057  1
    arc_1_6_12  original_T_including_depot_unload_1081  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_6_12  arc_capacity_837  1
    load_1_6_12  segment_load_conservation_1022  1
    load_1_6_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_13  arc_capacity_839  -30
    arc_1_6_13  connected_order_arc_840  -11
    arc_1_6_13  out_degree_1018  1
    arc_1_6_13  in_degree_1063  1
    arc_1_6_13  original_T_including_depot_unload_1081  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_13  arc_capacity_839  1
    load_1_6_13  segment_load_conservation_1022  1
    load_1_6_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_14  arc_capacity_841  -30
    arc_1_6_14  connected_order_arc_842  -11
    arc_1_6_14  out_degree_1018  1
    arc_1_6_14  in_degree_1069  1
    arc_1_6_14  original_T_including_depot_unload_1081  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_14  arc_capacity_841  1
    load_1_6_14  segment_load_conservation_1022  1
    load_1_6_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_6_15  arc_capacity_843  -30
    arc_1_6_15  connected_order_arc_844  -11
    arc_1_6_15  out_degree_1018  1
    arc_1_6_15  in_degree_1075  1
    arc_1_6_15  original_T_including_depot_unload_1081  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_6_15  arc_capacity_843  1
    load_1_6_15  segment_load_conservation_1022  1
    load_1_6_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_0  arc_capacity_845  -30
    arc_1_7_0  depot_return_or_bypass_1017  1
    arc_1_7_0  out_degree_1025  1
    arc_1_7_0  original_T_including_depot_unload_1081  1739.61165920636
    MARKER    'MARKER'                 'INTEND'
    load_1_7_0  arc_capacity_845  1
    load_1_7_0  segment_load_conservation_1029  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_6  arc_capacity_846  -30
    arc_1_7_6  connected_order_arc_847  -11
    arc_1_7_6  in_degree_1019  1
    arc_1_7_6  out_degree_1025  1
    arc_1_7_6  original_T_including_depot_unload_1081  1.3126251897454844e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_6  arc_capacity_846  1
    load_1_7_6  segment_load_conservation_1022  -1
    load_1_7_6  segment_prefix_lb_1023  1
    load_1_7_6  segment_prefix_ub_1024  1
    load_1_7_6  segment_load_conservation_1029  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_8  arc_capacity_848  -30
    arc_1_7_8  connected_order_arc_849  -11
    arc_1_7_8  out_degree_1025  1
    arc_1_7_8  in_degree_1033  1
    arc_1_7_8  original_T_including_depot_unload_1081  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_8  arc_capacity_848  1
    load_1_7_8  segment_load_conservation_1029  1
    load_1_7_8  free_load_conservation_1037  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_9  arc_capacity_850  -30
    arc_1_7_9  connected_order_arc_851  -11
    arc_1_7_9  out_degree_1025  1
    arc_1_7_9  in_degree_1039  1
    arc_1_7_9  original_T_including_depot_unload_1081  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_9  arc_capacity_850  1
    load_1_7_9  segment_load_conservation_1029  1
    load_1_7_9  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_10  arc_capacity_852  -30
    arc_1_7_10  connected_order_arc_853  -11
    arc_1_7_10  out_degree_1025  1
    arc_1_7_10  in_degree_1045  1
    arc_1_7_10  original_T_including_depot_unload_1081  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_10  arc_capacity_852  1
    load_1_7_10  segment_load_conservation_1029  1
    load_1_7_10  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_11  arc_capacity_854  -30
    arc_1_7_11  connected_order_arc_855  -11
    arc_1_7_11  out_degree_1025  1
    arc_1_7_11  in_degree_1051  1
    arc_1_7_11  original_T_including_depot_unload_1081  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_11  arc_capacity_854  1
    load_1_7_11  segment_load_conservation_1029  1
    load_1_7_11  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_12  arc_capacity_856  -30
    arc_1_7_12  connected_order_arc_857  -11
    arc_1_7_12  out_degree_1025  1
    arc_1_7_12  in_degree_1057  1
    arc_1_7_12  original_T_including_depot_unload_1081  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_7_12  arc_capacity_856  1
    load_1_7_12  segment_load_conservation_1029  1
    load_1_7_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_13  arc_capacity_858  -30
    arc_1_7_13  connected_order_arc_859  -11
    arc_1_7_13  out_degree_1025  1
    arc_1_7_13  in_degree_1063  1
    arc_1_7_13  original_T_including_depot_unload_1081  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_13  arc_capacity_858  1
    load_1_7_13  segment_load_conservation_1029  1
    load_1_7_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_14  arc_capacity_860  -30
    arc_1_7_14  connected_order_arc_861  -11
    arc_1_7_14  out_degree_1025  1
    arc_1_7_14  in_degree_1069  1
    arc_1_7_14  original_T_including_depot_unload_1081  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_14  arc_capacity_860  1
    load_1_7_14  segment_load_conservation_1029  1
    load_1_7_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_7_15  arc_capacity_862  -30
    arc_1_7_15  connected_order_arc_863  -11
    arc_1_7_15  out_degree_1025  1
    arc_1_7_15  in_degree_1075  1
    arc_1_7_15  original_T_including_depot_unload_1081  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_7_15  arc_capacity_862  1
    load_1_7_15  segment_load_conservation_1029  1
    load_1_7_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_0  arc_capacity_864  -30
    arc_1_8_0  depot_return_or_bypass_1017  1
    arc_1_8_0  out_degree_1032  1
    arc_1_8_0  original_T_including_depot_unload_1081  1.1473865007565566e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_0  arc_capacity_864  1
    load_1_8_0  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_6  arc_capacity_865  -30
    arc_1_8_6  connected_order_arc_866  -11
    arc_1_8_6  in_degree_1019  1
    arc_1_8_6  out_degree_1032  1
    arc_1_8_6  original_T_including_depot_unload_1081  2.4478438645146789e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_6  arc_capacity_865  1
    load_1_8_6  segment_load_conservation_1022  -1
    load_1_8_6  segment_prefix_lb_1023  1
    load_1_8_6  segment_prefix_ub_1024  1
    load_1_8_6  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_7  arc_capacity_867  -30
    arc_1_8_7  connected_order_arc_868  -11
    arc_1_8_7  in_degree_1026  1
    arc_1_8_7  out_degree_1032  1
    arc_1_8_7  original_T_including_depot_unload_1081  2.4369093744670904e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_7  arc_capacity_867  1
    load_1_8_7  segment_load_conservation_1029  -1
    load_1_8_7  segment_prefix_lb_1030  1
    load_1_8_7  segment_prefix_ub_1031  1
    load_1_8_7  free_load_conservation_1037  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_9  arc_capacity_869  -30
    arc_1_8_9  connected_order_arc_870  -11
    arc_1_8_9  out_degree_1032  1
    arc_1_8_9  in_degree_1039  1
    arc_1_8_9  original_T_including_depot_unload_1081  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_9  arc_capacity_869  1
    load_1_8_9  free_load_conservation_1037  1
    load_1_8_9  free_load_conservation_1043  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_10  arc_capacity_871  -30
    arc_1_8_10  connected_order_arc_872  -11
    arc_1_8_10  out_degree_1032  1
    arc_1_8_10  in_degree_1045  1
    arc_1_8_10  original_T_including_depot_unload_1081  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_10  arc_capacity_871  1
    load_1_8_10  free_load_conservation_1037  1
    load_1_8_10  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_11  arc_capacity_873  -30
    arc_1_8_11  connected_order_arc_874  -11
    arc_1_8_11  out_degree_1032  1
    arc_1_8_11  in_degree_1051  1
    arc_1_8_11  original_T_including_depot_unload_1081  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_11  arc_capacity_873  1
    load_1_8_11  free_load_conservation_1037  1
    load_1_8_11  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_12  arc_capacity_875  -30
    arc_1_8_12  connected_order_arc_876  -11
    arc_1_8_12  out_degree_1032  1
    arc_1_8_12  in_degree_1057  1
    arc_1_8_12  original_T_including_depot_unload_1081  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_8_12  arc_capacity_875  1
    load_1_8_12  free_load_conservation_1037  1
    load_1_8_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_13  arc_capacity_877  -30
    arc_1_8_13  connected_order_arc_878  -11
    arc_1_8_13  out_degree_1032  1
    arc_1_8_13  in_degree_1063  1
    arc_1_8_13  original_T_including_depot_unload_1081  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_13  arc_capacity_877  1
    load_1_8_13  free_load_conservation_1037  1
    load_1_8_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_14  arc_capacity_879  -30
    arc_1_8_14  connected_order_arc_880  -11
    arc_1_8_14  out_degree_1032  1
    arc_1_8_14  in_degree_1069  1
    arc_1_8_14  original_T_including_depot_unload_1081  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_14  arc_capacity_879  1
    load_1_8_14  free_load_conservation_1037  1
    load_1_8_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_8_15  arc_capacity_881  -30
    arc_1_8_15  connected_order_arc_882  -11
    arc_1_8_15  out_degree_1032  1
    arc_1_8_15  in_degree_1075  1
    arc_1_8_15  original_T_including_depot_unload_1081  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_8_15  arc_capacity_881  1
    load_1_8_15  free_load_conservation_1037  1
    load_1_8_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_0  arc_capacity_883  -30
    arc_1_9_0  depot_return_or_bypass_1017  1
    arc_1_9_0  out_degree_1038  1
    arc_1_9_0  original_T_including_depot_unload_1081  9.3133633713881534e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_0  arc_capacity_883  1
    load_1_9_0  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_6  arc_capacity_884  -30
    arc_1_9_6  connected_order_arc_885  -11
    arc_1_9_6  in_degree_1019  1
    arc_1_9_6  out_degree_1038  1
    arc_1_9_6  original_T_including_depot_unload_1081  2.2507610939146793e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_6  arc_capacity_884  1
    load_1_9_6  segment_load_conservation_1022  -1
    load_1_9_6  segment_prefix_lb_1023  1
    load_1_9_6  segment_prefix_ub_1024  1
    load_1_9_6  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_7  arc_capacity_886  -30
    arc_1_9_7  connected_order_arc_887  -11
    arc_1_9_7  in_degree_1026  1
    arc_1_9_7  out_degree_1038  1
    arc_1_9_7  original_T_including_depot_unload_1081  2.2339035809798856e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_7  arc_capacity_886  1
    load_1_9_7  segment_load_conservation_1029  -1
    load_1_9_7  segment_prefix_lb_1030  1
    load_1_9_7  segment_prefix_ub_1031  1
    load_1_9_7  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_8  arc_capacity_888  -30
    arc_1_9_8  connected_order_arc_889  -11
    arc_1_9_8  in_degree_1033  1
    arc_1_9_8  out_degree_1038  1
    arc_1_9_8  original_T_including_depot_unload_1081  2.2655310037545112e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_8  arc_capacity_888  1
    load_1_9_8  free_load_conservation_1037  -1
    load_1_9_8  free_load_conservation_1043  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_10  arc_capacity_890  -30
    arc_1_9_10  connected_order_arc_891  -11
    arc_1_9_10  out_degree_1038  1
    arc_1_9_10  in_degree_1045  1
    arc_1_9_10  original_T_including_depot_unload_1081  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_10  arc_capacity_890  1
    load_1_9_10  free_load_conservation_1043  1
    load_1_9_10  free_load_conservation_1049  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_11  arc_capacity_892  -30
    arc_1_9_11  connected_order_arc_893  -11
    arc_1_9_11  out_degree_1038  1
    arc_1_9_11  in_degree_1051  1
    arc_1_9_11  original_T_including_depot_unload_1081  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_11  arc_capacity_892  1
    load_1_9_11  free_load_conservation_1043  1
    load_1_9_11  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_12  arc_capacity_894  -30
    arc_1_9_12  connected_order_arc_895  -11
    arc_1_9_12  out_degree_1038  1
    arc_1_9_12  in_degree_1057  1
    arc_1_9_12  original_T_including_depot_unload_1081  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_9_12  arc_capacity_894  1
    load_1_9_12  free_load_conservation_1043  1
    load_1_9_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_13  arc_capacity_896  -30
    arc_1_9_13  connected_order_arc_897  -11
    arc_1_9_13  out_degree_1038  1
    arc_1_9_13  in_degree_1063  1
    arc_1_9_13  original_T_including_depot_unload_1081  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_13  arc_capacity_896  1
    load_1_9_13  free_load_conservation_1043  1
    load_1_9_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_14  arc_capacity_898  -30
    arc_1_9_14  connected_order_arc_899  -11
    arc_1_9_14  out_degree_1038  1
    arc_1_9_14  in_degree_1069  1
    arc_1_9_14  original_T_including_depot_unload_1081  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_14  arc_capacity_898  1
    load_1_9_14  free_load_conservation_1043  1
    load_1_9_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_9_15  arc_capacity_900  -30
    arc_1_9_15  connected_order_arc_901  -11
    arc_1_9_15  out_degree_1038  1
    arc_1_9_15  in_degree_1075  1
    arc_1_9_15  original_T_including_depot_unload_1081  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_9_15  arc_capacity_900  1
    load_1_9_15  free_load_conservation_1043  1
    load_1_9_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_0  arc_capacity_902  -30
    arc_1_10_0  depot_return_or_bypass_1017  1
    arc_1_10_0  out_degree_1044  1
    arc_1_10_0  original_T_including_depot_unload_1081  2.3234267380118886e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_0  arc_capacity_902  1
    load_1_10_0  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_6  arc_capacity_903  -30
    arc_1_10_6  connected_order_arc_904  -11
    arc_1_10_6  in_degree_1019  1
    arc_1_10_6  out_degree_1044  1
    arc_1_10_6  original_T_including_depot_unload_1081  3.8283958278492823e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_6  arc_capacity_903  1
    load_1_10_6  segment_load_conservation_1022  -1
    load_1_10_6  segment_prefix_lb_1023  1
    load_1_10_6  segment_prefix_ub_1024  1
    load_1_10_6  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_7  arc_capacity_905  -30
    arc_1_10_7  connected_order_arc_906  -11
    arc_1_10_7  in_degree_1026  1
    arc_1_10_7  out_degree_1044  1
    arc_1_10_7  original_T_including_depot_unload_1081  3.7182308190042463e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_7  arc_capacity_905  1
    load_1_10_7  segment_load_conservation_1029  -1
    load_1_10_7  segment_prefix_lb_1030  1
    load_1_10_7  segment_prefix_ub_1031  1
    load_1_10_7  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_8  arc_capacity_907  -30
    arc_1_10_8  connected_order_arc_908  -11
    arc_1_10_8  in_degree_1033  1
    arc_1_10_8  out_degree_1044  1
    arc_1_10_8  original_T_including_depot_unload_1081  2.9878665461125843e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_8  arc_capacity_907  1
    load_1_10_8  free_load_conservation_1037  -1
    load_1_10_8  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_9  arc_capacity_909  -30
    arc_1_10_9  connected_order_arc_910  -11
    arc_1_10_9  in_degree_1039  1
    arc_1_10_9  out_degree_1044  1
    arc_1_10_9  original_T_including_depot_unload_1081  2.8839695646198670e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_9  arc_capacity_909  1
    load_1_10_9  free_load_conservation_1043  -1
    load_1_10_9  free_load_conservation_1049  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_11  arc_capacity_911  -30
    arc_1_10_11  connected_order_arc_912  -11
    arc_1_10_11  out_degree_1044  1
    arc_1_10_11  in_degree_1051  1
    arc_1_10_11  original_T_including_depot_unload_1081  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_11  arc_capacity_911  1
    load_1_10_11  free_load_conservation_1049  1
    load_1_10_11  free_load_conservation_1055  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_12  arc_capacity_913  -30
    arc_1_10_12  connected_order_arc_914  -11
    arc_1_10_12  out_degree_1044  1
    arc_1_10_12  in_degree_1057  1
    arc_1_10_12  original_T_including_depot_unload_1081  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_12  arc_capacity_913  1
    load_1_10_12  free_load_conservation_1049  1
    load_1_10_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_13  arc_capacity_915  -30
    arc_1_10_13  connected_order_arc_916  -11
    arc_1_10_13  out_degree_1044  1
    arc_1_10_13  in_degree_1063  1
    arc_1_10_13  original_T_including_depot_unload_1081  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_13  arc_capacity_915  1
    load_1_10_13  free_load_conservation_1049  1
    load_1_10_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_14  arc_capacity_917  -30
    arc_1_10_14  connected_order_arc_918  -11
    arc_1_10_14  out_degree_1044  1
    arc_1_10_14  in_degree_1069  1
    arc_1_10_14  original_T_including_depot_unload_1081  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_14  arc_capacity_917  1
    load_1_10_14  free_load_conservation_1049  1
    load_1_10_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_10_15  arc_capacity_919  -30
    arc_1_10_15  connected_order_arc_920  -11
    arc_1_10_15  out_degree_1044  1
    arc_1_10_15  in_degree_1075  1
    arc_1_10_15  original_T_including_depot_unload_1081  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_10_15  arc_capacity_919  1
    load_1_10_15  free_load_conservation_1049  1
    load_1_10_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_0  arc_capacity_921  -30
    arc_1_11_0  depot_return_or_bypass_1017  1
    arc_1_11_0  out_degree_1050  1
    arc_1_11_0  original_T_including_depot_unload_1081  8.2548955430739034e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_0  arc_capacity_921  1
    load_1_11_0  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_6  arc_capacity_922  -30
    arc_1_11_6  connected_order_arc_923  -11
    arc_1_11_6  in_degree_1019  1
    arc_1_11_6  out_degree_1050  1
    arc_1_11_6  original_T_including_depot_unload_1081  2.0979901720969542e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_6  arc_capacity_922  1
    load_1_11_6  segment_load_conservation_1022  -1
    load_1_11_6  segment_prefix_lb_1023  1
    load_1_11_6  segment_prefix_ub_1024  1
    load_1_11_6  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_7  arc_capacity_924  -30
    arc_1_11_7  connected_order_arc_925  -11
    arc_1_11_7  in_degree_1026  1
    arc_1_11_7  out_degree_1050  1
    arc_1_11_7  original_T_including_depot_unload_1081  2.0801782775431307e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_7  arc_capacity_924  1
    load_1_11_7  segment_load_conservation_1029  -1
    load_1_11_7  segment_prefix_lb_1030  1
    load_1_11_7  segment_prefix_ub_1031  1
    load_1_11_7  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_8  arc_capacity_926  -30
    arc_1_11_8  connected_order_arc_927  -11
    arc_1_11_8  in_degree_1033  1
    arc_1_11_8  out_degree_1050  1
    arc_1_11_8  original_T_including_depot_unload_1081  3.7295617536174859e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_8  arc_capacity_926  1
    load_1_11_8  free_load_conservation_1037  -1
    load_1_11_8  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_9  arc_capacity_928  -30
    arc_1_11_9  connected_order_arc_929  -11
    arc_1_11_9  in_degree_1039  1
    arc_1_11_9  out_degree_1050  1
    arc_1_11_9  original_T_including_depot_unload_1081  1.5413712102626312e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_9  arc_capacity_928  1
    load_1_11_9  free_load_conservation_1043  -1
    load_1_11_9  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_10  arc_capacity_930  -30
    arc_1_11_10  connected_order_arc_931  -11
    arc_1_11_10  in_degree_1045  1
    arc_1_11_10  out_degree_1050  1
    arc_1_11_10  original_T_including_depot_unload_1081  2.8834086639088187e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_10  arc_capacity_930  1
    load_1_11_10  free_load_conservation_1049  -1
    load_1_11_10  free_load_conservation_1055  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_12  arc_capacity_932  -30
    arc_1_11_12  connected_order_arc_933  -11
    arc_1_11_12  out_degree_1050  1
    arc_1_11_12  in_degree_1057  1
    arc_1_11_12  original_T_including_depot_unload_1081  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_11_12  arc_capacity_932  1
    load_1_11_12  free_load_conservation_1055  1
    load_1_11_12  free_load_conservation_1061  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_13  arc_capacity_934  -30
    arc_1_11_13  connected_order_arc_935  -11
    arc_1_11_13  out_degree_1050  1
    arc_1_11_13  in_degree_1063  1
    arc_1_11_13  original_T_including_depot_unload_1081  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_13  arc_capacity_934  1
    load_1_11_13  free_load_conservation_1055  1
    load_1_11_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_14  arc_capacity_936  -30
    arc_1_11_14  connected_order_arc_937  -11
    arc_1_11_14  out_degree_1050  1
    arc_1_11_14  in_degree_1069  1
    arc_1_11_14  original_T_including_depot_unload_1081  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_14  arc_capacity_936  1
    load_1_11_14  free_load_conservation_1055  1
    load_1_11_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_11_15  arc_capacity_938  -30
    arc_1_11_15  connected_order_arc_939  -11
    arc_1_11_15  out_degree_1050  1
    arc_1_11_15  in_degree_1075  1
    arc_1_11_15  original_T_including_depot_unload_1081  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_11_15  arc_capacity_938  1
    load_1_11_15  free_load_conservation_1055  1
    load_1_11_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_0  arc_capacity_940  -30
    arc_1_12_0  depot_return_or_bypass_1017  1
    arc_1_12_0  out_degree_1056  1
    arc_1_12_0  original_T_including_depot_unload_1081  2.2866763971369810e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_0  arc_capacity_940  1
    load_1_12_0  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_6  arc_capacity_941  -30
    arc_1_12_6  connected_order_arc_942  -11
    arc_1_12_6  in_degree_1019  1
    arc_1_12_6  out_degree_1056  1
    arc_1_12_6  original_T_including_depot_unload_1081  5.2703432304351884e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_6  arc_capacity_941  1
    load_1_12_6  segment_load_conservation_1022  -1
    load_1_12_6  segment_prefix_lb_1023  1
    load_1_12_6  segment_prefix_ub_1024  1
    load_1_12_6  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_7  arc_capacity_943  -30
    arc_1_12_7  connected_order_arc_944  -11
    arc_1_12_7  in_degree_1026  1
    arc_1_12_7  out_degree_1056  1
    arc_1_12_7  original_T_including_depot_unload_1081  5.5382752177930990e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_12_7  arc_capacity_943  1
    load_1_12_7  segment_load_conservation_1029  -1
    load_1_12_7  segment_prefix_lb_1030  1
    load_1_12_7  segment_prefix_ub_1031  1
    load_1_12_7  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_8  arc_capacity_945  -30
    arc_1_12_8  connected_order_arc_946  -11
    arc_1_12_8  in_degree_1033  1
    arc_1_12_8  out_degree_1056  1
    arc_1_12_8  original_T_including_depot_unload_1081  2.9747397208089205e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_8  arc_capacity_945  1
    load_1_12_8  free_load_conservation_1037  -1
    load_1_12_8  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_9  arc_capacity_947  -30
    arc_1_12_9  connected_order_arc_948  -11
    arc_1_12_9  in_degree_1039  1
    arc_1_12_9  out_degree_1056  1
    arc_1_12_9  original_T_including_depot_unload_1081  2.7766616410403444e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_9  arc_capacity_947  1
    load_1_12_9  free_load_conservation_1043  -1
    load_1_12_9  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_10  arc_capacity_949  -30
    arc_1_12_10  connected_order_arc_950  -11
    arc_1_12_10  in_degree_1045  1
    arc_1_12_10  out_degree_1056  1
    arc_1_12_10  original_T_including_depot_unload_1081  4.1686506413165080e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_10  arc_capacity_949  1
    load_1_12_10  free_load_conservation_1049  -1
    load_1_12_10  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_11  arc_capacity_951  -30
    arc_1_12_11  connected_order_arc_952  -11
    arc_1_12_11  in_degree_1051  1
    arc_1_12_11  out_degree_1056  1
    arc_1_12_11  original_T_including_depot_unload_1081  2.6235983504802839e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_11  arc_capacity_951  1
    load_1_12_11  free_load_conservation_1055  -1
    load_1_12_11  free_load_conservation_1061  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_13  arc_capacity_953  -30
    arc_1_12_13  connected_order_arc_954  -11
    arc_1_12_13  out_degree_1056  1
    arc_1_12_13  in_degree_1063  1
    arc_1_12_13  original_T_including_depot_unload_1081  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_13  arc_capacity_953  1
    load_1_12_13  free_load_conservation_1061  1
    load_1_12_13  free_load_conservation_1067  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_14  arc_capacity_955  -30
    arc_1_12_14  connected_order_arc_956  -11
    arc_1_12_14  out_degree_1056  1
    arc_1_12_14  in_degree_1069  1
    arc_1_12_14  original_T_including_depot_unload_1081  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_14  arc_capacity_955  1
    load_1_12_14  free_load_conservation_1061  1
    load_1_12_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_12_15  arc_capacity_957  -30
    arc_1_12_15  connected_order_arc_958  -11
    arc_1_12_15  out_degree_1056  1
    arc_1_12_15  in_degree_1075  1
    arc_1_12_15  original_T_including_depot_unload_1081  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_12_15  arc_capacity_957  1
    load_1_12_15  free_load_conservation_1061  1
    load_1_12_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_0  arc_capacity_959  -30
    arc_1_13_0  depot_return_or_bypass_1017  1
    arc_1_13_0  out_degree_1062  1
    arc_1_13_0  original_T_including_depot_unload_1081  1.2186896810212775e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_0  arc_capacity_959  1
    load_1_13_0  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_6  arc_capacity_960  -30
    arc_1_13_6  connected_order_arc_961  -11
    arc_1_13_6  in_degree_1019  1
    arc_1_13_6  out_degree_1062  1
    arc_1_13_6  original_T_including_depot_unload_1081  2.1556817566230284e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_6  arc_capacity_960  1
    load_1_13_6  segment_load_conservation_1022  -1
    load_1_13_6  segment_prefix_lb_1023  1
    load_1_13_6  segment_prefix_ub_1024  1
    load_1_13_6  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_7  arc_capacity_962  -30
    arc_1_13_7  connected_order_arc_963  -11
    arc_1_13_7  in_degree_1026  1
    arc_1_13_7  out_degree_1062  1
    arc_1_13_7  original_T_including_depot_unload_1081  2.1641391312462424e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_7  arc_capacity_962  1
    load_1_13_7  segment_load_conservation_1029  -1
    load_1_13_7  segment_prefix_lb_1030  1
    load_1_13_7  segment_prefix_ub_1031  1
    load_1_13_7  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_8  arc_capacity_964  -30
    arc_1_13_8  connected_order_arc_965  -11
    arc_1_13_8  in_degree_1033  1
    arc_1_13_8  out_degree_1062  1
    arc_1_13_8  original_T_including_depot_unload_1081  4.4158457011124148e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_8  arc_capacity_964  1
    load_1_13_8  free_load_conservation_1037  -1
    load_1_13_8  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_9  arc_capacity_966  -30
    arc_1_13_9  connected_order_arc_967  -11
    arc_1_13_9  in_degree_1039  1
    arc_1_13_9  out_degree_1062  1
    arc_1_13_9  original_T_including_depot_unload_1081  4.3257823465305182e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_9  arc_capacity_966  1
    load_1_13_9  free_load_conservation_1043  -1
    load_1_13_9  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_10  arc_capacity_968  -30
    arc_1_13_10  connected_order_arc_969  -11
    arc_1_13_10  in_degree_1045  1
    arc_1_13_10  out_degree_1062  1
    arc_1_13_10  original_T_including_depot_unload_1081  3.3076115257178203e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_10  arc_capacity_968  1
    load_1_13_10  free_load_conservation_1049  -1
    load_1_13_10  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_11  arc_capacity_970  -30
    arc_1_13_11  connected_order_arc_971  -11
    arc_1_13_11  in_degree_1051  1
    arc_1_13_11  out_degree_1062  1
    arc_1_13_11  original_T_including_depot_unload_1081  4.3124580937307496e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_11  arc_capacity_970  1
    load_1_13_11  free_load_conservation_1055  -1
    load_1_13_11  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_12  arc_capacity_972  -30
    arc_1_13_12  connected_order_arc_973  -11
    arc_1_13_12  in_degree_1057  1
    arc_1_13_12  out_degree_1062  1
    arc_1_13_12  original_T_including_depot_unload_1081  2.6797194604092651e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_13_12  arc_capacity_972  1
    load_1_13_12  free_load_conservation_1061  -1
    load_1_13_12  free_load_conservation_1067  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_14  arc_capacity_974  -30
    arc_1_13_14  connected_order_arc_975  -11
    arc_1_13_14  out_degree_1062  1
    arc_1_13_14  in_degree_1069  1
    arc_1_13_14  original_T_including_depot_unload_1081  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_14  arc_capacity_974  1
    load_1_13_14  free_load_conservation_1067  1
    load_1_13_14  free_load_conservation_1073  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_13_15  arc_capacity_976  -30
    arc_1_13_15  connected_order_arc_977  -11
    arc_1_13_15  out_degree_1062  1
    arc_1_13_15  in_degree_1075  1
    arc_1_13_15  original_T_including_depot_unload_1081  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_13_15  arc_capacity_976  1
    load_1_13_15  free_load_conservation_1067  1
    load_1_13_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_0  arc_capacity_978  -30
    arc_1_14_0  depot_return_or_bypass_1017  1
    arc_1_14_0  out_degree_1068  1
    arc_1_14_0  original_T_including_depot_unload_1081  4.0782796387128610e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_0  arc_capacity_978  1
    load_1_14_0  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_6  arc_capacity_979  -30
    arc_1_14_6  connected_order_arc_980  -11
    arc_1_14_6  in_degree_1019  1
    arc_1_14_6  out_degree_1068  1
    arc_1_14_6  original_T_including_depot_unload_1081  1.7671662790958783e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_6  arc_capacity_979  1
    load_1_14_6  segment_load_conservation_1022  -1
    load_1_14_6  segment_prefix_lb_1023  1
    load_1_14_6  segment_prefix_ub_1024  1
    load_1_14_6  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_7  arc_capacity_981  -30
    arc_1_14_7  connected_order_arc_982  -11
    arc_1_14_7  in_degree_1026  1
    arc_1_14_7  out_degree_1068  1
    arc_1_14_7  original_T_including_depot_unload_1081  1.7279728905134273e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_7  arc_capacity_981  1
    load_1_14_7  segment_load_conservation_1029  -1
    load_1_14_7  segment_prefix_lb_1030  1
    load_1_14_7  segment_prefix_ub_1031  1
    load_1_14_7  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_8  arc_capacity_983  -30
    arc_1_14_8  connected_order_arc_984  -11
    arc_1_14_8  in_degree_1033  1
    arc_1_14_8  out_degree_1068  1
    arc_1_14_8  original_T_including_depot_unload_1081  8.2982882938703278e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_8  arc_capacity_983  1
    load_1_14_8  free_load_conservation_1037  -1
    load_1_14_8  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_9  arc_capacity_985  -30
    arc_1_14_9  connected_order_arc_986  -11
    arc_1_14_9  in_degree_1039  1
    arc_1_14_9  out_degree_1068  1
    arc_1_14_9  original_T_including_depot_unload_1081  6.0329604828085382e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_9  arc_capacity_985  1
    load_1_14_9  free_load_conservation_1043  -1
    load_1_14_9  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_10  arc_capacity_987  -30
    arc_1_14_10  connected_order_arc_988  -11
    arc_1_14_10  in_degree_1045  1
    arc_1_14_10  out_degree_1068  1
    arc_1_14_10  original_T_including_depot_unload_1081  2.6728511574036233e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_10  arc_capacity_987  1
    load_1_14_10  free_load_conservation_1049  -1
    load_1_14_10  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_11  arc_capacity_989  -30
    arc_1_14_11  connected_order_arc_990  -11
    arc_1_14_11  in_degree_1051  1
    arc_1_14_11  out_degree_1068  1
    arc_1_14_11  original_T_including_depot_unload_1081  4.6739130846957909e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_11  arc_capacity_989  1
    load_1_14_11  free_load_conservation_1055  -1
    load_1_14_11  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_12  arc_capacity_991  -30
    arc_1_14_12  connected_order_arc_992  -11
    arc_1_14_12  in_degree_1057  1
    arc_1_14_12  out_degree_1068  1
    arc_1_14_12  original_T_including_depot_unload_1081  2.2811398160464278e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_14_12  arc_capacity_991  1
    load_1_14_12  free_load_conservation_1061  -1
    load_1_14_12  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_13  arc_capacity_993  -30
    arc_1_14_13  connected_order_arc_994  -11
    arc_1_14_13  in_degree_1063  1
    arc_1_14_13  out_degree_1068  1
    arc_1_14_13  original_T_including_depot_unload_1081  8.2145202724109538e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_13  arc_capacity_993  1
    load_1_14_13  free_load_conservation_1067  -1
    load_1_14_13  free_load_conservation_1073  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_14_15  arc_capacity_995  -30
    arc_1_14_15  connected_order_arc_996  -11
    arc_1_14_15  out_degree_1068  1
    arc_1_14_15  in_degree_1075  1
    arc_1_14_15  original_T_including_depot_unload_1081  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_14_15  arc_capacity_995  1
    load_1_14_15  free_load_conservation_1073  1
    load_1_14_15  free_load_conservation_1079  -1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_0  arc_capacity_997  -30
    arc_1_15_0  depot_return_or_bypass_1017  1
    arc_1_15_0  out_degree_1074  1
    arc_1_15_0  original_T_including_depot_unload_1081  9.3659929340140741e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_0  arc_capacity_997  1
    load_1_15_0  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_6  arc_capacity_998  -30
    arc_1_15_6  connected_order_arc_999  -11
    arc_1_15_6  in_degree_1019  1
    arc_1_15_6  out_degree_1074  1
    arc_1_15_6  original_T_including_depot_unload_1081  2.0021738809925773e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_6  arc_capacity_998  1
    load_1_15_6  segment_load_conservation_1022  -1
    load_1_15_6  segment_prefix_lb_1023  1
    load_1_15_6  segment_prefix_ub_1024  1
    load_1_15_6  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_7  arc_capacity_1000  -30
    arc_1_15_7  connected_order_arc_1001  -11
    arc_1_15_7  in_degree_1026  1
    arc_1_15_7  out_degree_1074  1
    arc_1_15_7  original_T_including_depot_unload_1081  1.9959569014367933e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_7  arc_capacity_1000  1
    load_1_15_7  segment_load_conservation_1029  -1
    load_1_15_7  segment_prefix_lb_1030  1
    load_1_15_7  segment_prefix_ub_1031  1
    load_1_15_7  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_8  arc_capacity_1002  -30
    arc_1_15_8  connected_order_arc_1003  -11
    arc_1_15_8  in_degree_1033  1
    arc_1_15_8  out_degree_1074  1
    arc_1_15_8  original_T_including_depot_unload_1081  4.5058965368847572e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_8  arc_capacity_1002  1
    load_1_15_8  free_load_conservation_1037  -1
    load_1_15_8  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_9  arc_capacity_1004  -30
    arc_1_15_9  connected_order_arc_1005  -11
    arc_1_15_9  in_degree_1039  1
    arc_1_15_9  out_degree_1074  1
    arc_1_15_9  original_T_including_depot_unload_1081  2.9819555494495978e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_9  arc_capacity_1004  1
    load_1_15_9  free_load_conservation_1043  -1
    load_1_15_9  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_10  arc_capacity_1006  -30
    arc_1_15_10  connected_order_arc_1007  -11
    arc_1_15_10  in_degree_1045  1
    arc_1_15_10  out_degree_1074  1
    arc_1_15_10  original_T_including_depot_unload_1081  3.0726580305165480e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_10  arc_capacity_1006  1
    load_1_15_10  free_load_conservation_1049  -1
    load_1_15_10  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_11  arc_capacity_1008  -30
    arc_1_15_11  connected_order_arc_1009  -11
    arc_1_15_11  in_degree_1051  1
    arc_1_15_11  out_degree_1074  1
    arc_1_15_11  original_T_including_depot_unload_1081  2.0241950709354862e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_11  arc_capacity_1008  1
    load_1_15_11  free_load_conservation_1055  -1
    load_1_15_11  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_12  arc_capacity_1010  -30
    arc_1_15_12  connected_order_arc_1011  -11
    arc_1_15_12  in_degree_1057  1
    arc_1_15_12  out_degree_1074  1
    arc_1_15_12  original_T_including_depot_unload_1081  2.5292035468949002e+03
    MARKER    'MARKER'                 'INTEND'
    load_1_15_12  arc_capacity_1010  1
    load_1_15_12  free_load_conservation_1061  -1
    load_1_15_12  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_13  arc_capacity_1012  -30
    arc_1_15_13  connected_order_arc_1013  -11
    arc_1_15_13  in_degree_1063  1
    arc_1_15_13  out_degree_1074  1
    arc_1_15_13  original_T_including_depot_unload_1081  2.8260257937815851e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_13  arc_capacity_1012  1
    load_1_15_13  free_load_conservation_1067  -1
    load_1_15_13  free_load_conservation_1079  1
    MARKER    'MARKER'                 'INTORG'
    arc_1_15_14  arc_capacity_1014  -30
    arc_1_15_14  connected_order_arc_1015  -11
    arc_1_15_14  in_degree_1069  1
    arc_1_15_14  out_degree_1074  1
    arc_1_15_14  original_T_including_depot_unload_1081  5.3918604589472477e+02
    MARKER    'MARKER'                 'INTEND'
    load_1_15_14  arc_capacity_1014  1
    load_1_15_14  free_load_conservation_1073  -1
    load_1_15_14  free_load_conservation_1079  1
RHS
    RHS1      OBJ       -4.2081376617325034e-01
    RHS1      onehot_1_32  1
    RHS1      onehot_2_39  1
    RHS1      onehot_18_74  1
    RHS1      onehot_3_111  1
    RHS1      onehot_17_148  1
    RHS1      onehot_4_183  1
    RHS1      onehot_11_218  1
    RHS1      onehot_5_227  1
    RHS1      stock_ub_231  29
    RHS1      parent_nonstrict_scope_232  0.587164935444241
    RHS1      normalization_289  1
    RHS1      connected_order_arc_402  -13
    RHS1      connected_order_arc_404  -13
    RHS1      connected_order_arc_406  -13
    RHS1      connected_order_arc_408  -13
    RHS1      connected_order_arc_410  -13
    RHS1      connected_order_arc_412  -13
    RHS1      connected_order_arc_414  -13
    RHS1      connected_order_arc_416  -13
    RHS1      connected_order_arc_418  -13
    RHS1      connected_order_arc_420  -13
    RHS1      connected_order_arc_422  -13
    RHS1      connected_order_arc_424  -13
    RHS1      connected_order_arc_427  -13
    RHS1      connected_order_arc_429  -13
    RHS1      connected_order_arc_431  -13
    RHS1      connected_order_arc_433  -13
    RHS1      connected_order_arc_435  -13
    RHS1      connected_order_arc_437  -13
    RHS1      connected_order_arc_439  -13
    RHS1      connected_order_arc_441  -13
    RHS1      connected_order_arc_443  -13
    RHS1      connected_order_arc_445  -13
    RHS1      connected_order_arc_447  -13
    RHS1      connected_order_arc_449  -13
    RHS1      connected_order_arc_452  -13
    RHS1      connected_order_arc_454  -13
    RHS1      connected_order_arc_456  -13
    RHS1      connected_order_arc_458  -13
    RHS1      connected_order_arc_460  -13
    RHS1      connected_order_arc_462  -13
    RHS1      connected_order_arc_464  -13
    RHS1      connected_order_arc_466  -13
    RHS1      connected_order_arc_468  -13
    RHS1      connected_order_arc_470  -13
    RHS1      connected_order_arc_472  -13
    RHS1      connected_order_arc_474  -13
    RHS1      connected_order_arc_477  -13
    RHS1      connected_order_arc_479  -13
    RHS1      connected_order_arc_481  -13
    RHS1      connected_order_arc_483  -13
    RHS1      connected_order_arc_485  -13
    RHS1      connected_order_arc_487  -13
    RHS1      connected_order_arc_489  -13
    RHS1      connected_order_arc_491  -13
    RHS1      connected_order_arc_493  -13
    RHS1      connected_order_arc_495  -13
    RHS1      connected_order_arc_497  -13
    RHS1      connected_order_arc_499  -13
    RHS1      connected_order_arc_502  -13
    RHS1      connected_order_arc_504  -13
    RHS1      connected_order_arc_506  -13
    RHS1      connected_order_arc_508  -13
    RHS1      connected_order_arc_510  -13
    RHS1      connected_order_arc_512  -13
    RHS1      connected_order_arc_514  -13
    RHS1      connected_order_arc_516  -13
    RHS1      connected_order_arc_518  -13
    RHS1      connected_order_arc_520  -13
    RHS1      connected_order_arc_522  -13
    RHS1      connected_order_arc_524  -13
    RHS1      connected_order_arc_527  -13
    RHS1      connected_order_arc_529  -13
    RHS1      connected_order_arc_531  -13
    RHS1      connected_order_arc_533  -13
    RHS1      connected_order_arc_535  -13
    RHS1      connected_order_arc_537  -13
    RHS1      connected_order_arc_539  -13
    RHS1      connected_order_arc_541  -13
    RHS1      connected_order_arc_543  -13
    RHS1      connected_order_arc_545  -13
    RHS1      connected_order_arc_547  -13
    RHS1      connected_order_arc_549  -13
    RHS1      connected_order_arc_552  -13
    RHS1      connected_order_arc_554  -13
    RHS1      connected_order_arc_556  -13
    RHS1      connected_order_arc_558  -13
    RHS1      connected_order_arc_560  -13
    RHS1      connected_order_arc_562  -13
    RHS1      connected_order_arc_564  -13
    RHS1      connected_order_arc_566  -13
    RHS1      connected_order_arc_568  -13
    RHS1      connected_order_arc_570  -13
    RHS1      connected_order_arc_572  -13
    RHS1      connected_order_arc_574  -13
    RHS1      connected_order_arc_577  -13
    RHS1      connected_order_arc_579  -13
    RHS1      connected_order_arc_581  -13
    RHS1      connected_order_arc_583  -13
    RHS1      connected_order_arc_585  -13
    RHS1      connected_order_arc_587  -13
    RHS1      connected_order_arc_589  -13
    RHS1      connected_order_arc_591  -13
    RHS1      connected_order_arc_593  -13
    RHS1      connected_order_arc_595  -13
    RHS1      connected_order_arc_597  -13
    RHS1      connected_order_arc_599  -13
    RHS1      connected_order_arc_602  -13
    RHS1      connected_order_arc_604  -13
    RHS1      connected_order_arc_606  -13
    RHS1      connected_order_arc_608  -13
    RHS1      connected_order_arc_610  -13
    RHS1      connected_order_arc_612  -13
    RHS1      connected_order_arc_614  -13
    RHS1      connected_order_arc_616  -13
    RHS1      connected_order_arc_618  -13
    RHS1      connected_order_arc_620  -13
    RHS1      connected_order_arc_622  -13
    RHS1      connected_order_arc_624  -13
    RHS1      connected_order_arc_627  -13
    RHS1      connected_order_arc_629  -13
    RHS1      connected_order_arc_631  -13
    RHS1      connected_order_arc_633  -13
    RHS1      connected_order_arc_635  -13
    RHS1      connected_order_arc_637  -13
    RHS1      connected_order_arc_639  -13
    RHS1      connected_order_arc_641  -13
    RHS1      connected_order_arc_643  -13
    RHS1      connected_order_arc_645  -13
    RHS1      connected_order_arc_647  -13
    RHS1      connected_order_arc_649  -13
    RHS1      connected_order_arc_652  -13
    RHS1      connected_order_arc_654  -13
    RHS1      connected_order_arc_656  -13
    RHS1      connected_order_arc_658  -13
    RHS1      connected_order_arc_660  -13
    RHS1      connected_order_arc_662  -13
    RHS1      connected_order_arc_664  -13
    RHS1      connected_order_arc_666  -13
    RHS1      connected_order_arc_668  -13
    RHS1      connected_order_arc_670  -13
    RHS1      connected_order_arc_672  -13
    RHS1      connected_order_arc_674  -13
    RHS1      connected_order_arc_677  -13
    RHS1      connected_order_arc_679  -13
    RHS1      connected_order_arc_681  -13
    RHS1      connected_order_arc_683  -13
    RHS1      connected_order_arc_685  -13
    RHS1      connected_order_arc_687  -13
    RHS1      connected_order_arc_689  -13
    RHS1      connected_order_arc_691  -13
    RHS1      connected_order_arc_693  -13
    RHS1      connected_order_arc_695  -13
    RHS1      connected_order_arc_697  -13
    RHS1      connected_order_arc_699  -13
    RHS1      connected_order_arc_702  -13
    RHS1      connected_order_arc_704  -13
    RHS1      connected_order_arc_706  -13
    RHS1      connected_order_arc_708  -13
    RHS1      connected_order_arc_710  -13
    RHS1      connected_order_arc_712  -13
    RHS1      connected_order_arc_714  -13
    RHS1      connected_order_arc_716  -13
    RHS1      connected_order_arc_718  -13
    RHS1      connected_order_arc_720  -13
    RHS1      connected_order_arc_722  -13
    RHS1      connected_order_arc_724  -13
    RHS1      depot_departure_or_bypass_725  1
    RHS1      depot_return_or_bypass_726  1
    RHS1      segment_load_conservation_731  3
    RHS1      segment_prefix_ub_733  27
    RHS1      segment_load_conservation_738  -1
    RHS1      segment_prefix_lb_739  1
    RHS1      segment_prefix_ub_740  30
    RHS1      segment_load_conservation_745  -1
    RHS1      segment_prefix_lb_746  1
    RHS1      segment_prefix_ub_747  30
    RHS1      segment_load_conservation_752  -3
    RHS1      segment_prefix_lb_753  3
    RHS1      segment_prefix_ub_754  30
    RHS1      segment_load_conservation_759  -1
    RHS1      segment_prefix_lb_760  1
    RHS1      segment_prefix_ub_761  30
    RHS1      fixed_segment_relative_order_810  1
    RHS1      fixed_segment_relative_order_811  1
    RHS1      fixed_segment_relative_order_812  1
    RHS1      fixed_segment_relative_order_813  1
    RHS1      original_T_including_depot_unload_814  4440
    RHS1      connected_order_arc_828  -10
    RHS1      connected_order_arc_830  -10
    RHS1      connected_order_arc_832  -10
    RHS1      connected_order_arc_834  -10
    RHS1      connected_order_arc_836  -10
    RHS1      connected_order_arc_838  -10
    RHS1      connected_order_arc_840  -10
    RHS1      connected_order_arc_842  -10
    RHS1      connected_order_arc_844  -10
    RHS1      connected_order_arc_847  -10
    RHS1      connected_order_arc_849  -10
    RHS1      connected_order_arc_851  -10
    RHS1      connected_order_arc_853  -10
    RHS1      connected_order_arc_855  -10
    RHS1      connected_order_arc_857  -10
    RHS1      connected_order_arc_859  -10
    RHS1      connected_order_arc_861  -10
    RHS1      connected_order_arc_863  -10
    RHS1      connected_order_arc_866  -10
    RHS1      connected_order_arc_868  -10
    RHS1      connected_order_arc_870  -10
    RHS1      connected_order_arc_872  -10
    RHS1      connected_order_arc_874  -10
    RHS1      connected_order_arc_876  -10
    RHS1      connected_order_arc_878  -10
    RHS1      connected_order_arc_880  -10
    RHS1      connected_order_arc_882  -10
    RHS1      connected_order_arc_885  -10
    RHS1      connected_order_arc_887  -10
    RHS1      connected_order_arc_889  -10
    RHS1      connected_order_arc_891  -10
    RHS1      connected_order_arc_893  -10
    RHS1      connected_order_arc_895  -10
    RHS1      connected_order_arc_897  -10
    RHS1      connected_order_arc_899  -10
    RHS1      connected_order_arc_901  -10
    RHS1      connected_order_arc_904  -10
    RHS1      connected_order_arc_906  -10
    RHS1      connected_order_arc_908  -10
    RHS1      connected_order_arc_910  -10
    RHS1      connected_order_arc_912  -10
    RHS1      connected_order_arc_914  -10
    RHS1      connected_order_arc_916  -10
    RHS1      connected_order_arc_918  -10
    RHS1      connected_order_arc_920  -10
    RHS1      connected_order_arc_923  -10
    RHS1      connected_order_arc_925  -10
    RHS1      connected_order_arc_927  -10
    RHS1      connected_order_arc_929  -10
    RHS1      connected_order_arc_931  -10
    RHS1      connected_order_arc_933  -10
    RHS1      connected_order_arc_935  -10
    RHS1      connected_order_arc_937  -10
    RHS1      connected_order_arc_939  -10
    RHS1      connected_order_arc_942  -10
    RHS1      connected_order_arc_944  -10
    RHS1      connected_order_arc_946  -10
    RHS1      connected_order_arc_948  -10
    RHS1      connected_order_arc_950  -10
    RHS1      connected_order_arc_952  -10
    RHS1      connected_order_arc_954  -10
    RHS1      connected_order_arc_956  -10
    RHS1      connected_order_arc_958  -10
    RHS1      connected_order_arc_961  -10
    RHS1      connected_order_arc_963  -10
    RHS1      connected_order_arc_965  -10
    RHS1      connected_order_arc_967  -10
    RHS1      connected_order_arc_969  -10
    RHS1      connected_order_arc_971  -10
    RHS1      connected_order_arc_973  -10
    RHS1      connected_order_arc_975  -10
    RHS1      connected_order_arc_977  -10
    RHS1      connected_order_arc_980  -10
    RHS1      connected_order_arc_982  -10
    RHS1      connected_order_arc_984  -10
    RHS1      connected_order_arc_986  -10
    RHS1      connected_order_arc_988  -10
    RHS1      connected_order_arc_990  -10
    RHS1      connected_order_arc_992  -10
    RHS1      connected_order_arc_994  -10
    RHS1      connected_order_arc_996  -10
    RHS1      connected_order_arc_999  -10
    RHS1      connected_order_arc_1001  -10
    RHS1      connected_order_arc_1003  -10
    RHS1      connected_order_arc_1005  -10
    RHS1      connected_order_arc_1007  -10
    RHS1      connected_order_arc_1009  -10
    RHS1      connected_order_arc_1011  -10
    RHS1      connected_order_arc_1013  -10
    RHS1      connected_order_arc_1015  -10
    RHS1      depot_departure_or_bypass_1016  1
    RHS1      depot_return_or_bypass_1017  1
    RHS1      segment_load_conservation_1022  4
    RHS1      segment_prefix_ub_1024  26
    RHS1      segment_load_conservation_1029  -1
    RHS1      segment_prefix_lb_1030  1
    RHS1      segment_prefix_ub_1031  30
    RHS1      fixed_segment_relative_order_1080  1
    RHS1      original_T_including_depot_unload_1081  4320
BOUNDS
 LO BND1      t         4.1226319405776264e-02
 UP BND1      t         1.0590015128603633e-01
 UP BND1      q         6.9405070034003413e-01
 BV BND1      x_1_0   
 UP BND1      w_1_0     1.0590015128603633e-01
 BV BND1      x_1_1   
 UP BND1      w_1_1     1.0590015128603633e-01
 BV BND1      x_1_2   
 UP BND1      w_1_2     1.0590015128603633e-01
 BV BND1      x_1_3   
 UP BND1      w_1_3     1.0590015128603633e-01
 BV BND1      x_1_4   
 UP BND1      w_1_4     1.0590015128603633e-01
 BV BND1      x_1_5   
 UP BND1      w_1_5     1.0590015128603633e-01
 BV BND1      x_1_6   
 UP BND1      w_1_6     1.0590015128603633e-01
 BV BND1      x_1_7   
 UP BND1      w_1_7     1.0590015128603633e-01
 BV BND1      x_1_8   
 UP BND1      w_1_8     1.0590015128603633e-01
 BV BND1      x_1_9   
 UP BND1      w_1_9     1.0590015128603633e-01
 BV BND1      x_1_10  
 UP BND1      w_1_10    1.0590015128603633e-01
 BV BND1      x_1_11  
 UP BND1      w_1_11    1.0590015128603633e-01
 BV BND1      x_1_12  
 UP BND1      w_1_12    1.0590015128603633e-01
 BV BND1      x_1_13  
 UP BND1      w_1_13    1.0590015128603633e-01
 BV BND1      x_1_14  
 UP BND1      w_1_14    1.0590015128603633e-01
 BV BND1      x_1_15  
 UP BND1      w_1_15    1.0590015128603633e-01
 UP BND1      rho_1     1
 BV BND1      x_2_0   
 UP BND1      w_2_0     1.0590015128603633e-01
 BV BND1      x_2_1   
 UP BND1      w_2_1     1.0590015128603633e-01
 UP BND1      rho_2     1
 BV BND1      x_18_0  
 UP BND1      w_18_0    1.0590015128603633e-01
 BV BND1      x_18_1  
 UP BND1      w_18_1    1.0590015128603633e-01
 BV BND1      x_18_2  
 UP BND1      w_18_2    1.0590015128603633e-01
 BV BND1      x_18_3  
 UP BND1      w_18_3    1.0590015128603633e-01
 BV BND1      x_18_4  
 UP BND1      w_18_4    1.0590015128603633e-01
 BV BND1      x_18_5  
 UP BND1      w_18_5    1.0590015128603633e-01
 BV BND1      x_18_6  
 UP BND1      w_18_6    1.0590015128603633e-01
 BV BND1      x_18_7  
 UP BND1      w_18_7    1.0590015128603633e-01
 BV BND1      x_18_8  
 UP BND1      w_18_8    1.0590015128603633e-01
 BV BND1      x_18_9  
 UP BND1      w_18_9    1.0590015128603633e-01
 BV BND1      x_18_10 
 UP BND1      w_18_10   1.0590015128603633e-01
 BV BND1      x_18_11 
 UP BND1      w_18_11   1.0590015128603633e-01
 BV BND1      x_18_12 
 UP BND1      w_18_12   1.0590015128603633e-01
 BV BND1      x_18_13 
 UP BND1      w_18_13   1.0590015128603633e-01
 BV BND1      x_18_14 
 UP BND1      w_18_14   1.0590015128603633e-01
 BV BND1      x_18_15 
 UP BND1      w_18_15   1.0590015128603633e-01
 UP BND1      rho_18    1
 BV BND1      x_3_0   
 UP BND1      w_3_0     1.0590015128603633e-01
 BV BND1      x_3_1   
 UP BND1      w_3_1     1.0590015128603633e-01
 BV BND1      x_3_2   
 UP BND1      w_3_2     1.0590015128603633e-01
 BV BND1      x_3_3   
 UP BND1      w_3_3     1.0590015128603633e-01
 BV BND1      x_3_4   
 UP BND1      w_3_4     1.0590015128603633e-01
 BV BND1      x_3_5   
 UP BND1      w_3_5     1.0590015128603633e-01
 BV BND1      x_3_6   
 UP BND1      w_3_6     1.0590015128603633e-01
 BV BND1      x_3_7   
 UP BND1      w_3_7     1.0590015128603633e-01
 BV BND1      x_3_8   
 UP BND1      w_3_8     1.0590015128603633e-01
 BV BND1      x_3_9   
 UP BND1      w_3_9     1.0590015128603633e-01
 BV BND1      x_3_10  
 UP BND1      w_3_10    1.0590015128603633e-01
 BV BND1      x_3_11  
 UP BND1      w_3_11    1.0590015128603633e-01
 BV BND1      x_3_12  
 UP BND1      w_3_12    1.0590015128603633e-01
 BV BND1      x_3_13  
 UP BND1      w_3_13    1.0590015128603633e-01
 BV BND1      x_3_14  
 UP BND1      w_3_14    1.0590015128603633e-01
 BV BND1      x_3_15  
 UP BND1      w_3_15    1.0590015128603633e-01
 BV BND1      x_3_16  
 UP BND1      w_3_16    1.0590015128603633e-01
 UP BND1      rho_3     1
 BV BND1      x_17_0  
 UP BND1      w_17_0    1.0590015128603633e-01
 BV BND1      x_17_1  
 UP BND1      w_17_1    1.0590015128603633e-01
 BV BND1      x_17_2  
 UP BND1      w_17_2    1.0590015128603633e-01
 BV BND1      x_17_3  
 UP BND1      w_17_3    1.0590015128603633e-01
 BV BND1      x_17_4  
 UP BND1      w_17_4    1.0590015128603633e-01
 BV BND1      x_17_5  
 UP BND1      w_17_5    1.0590015128603633e-01
 BV BND1      x_17_6  
 UP BND1      w_17_6    1.0590015128603633e-01
 BV BND1      x_17_7  
 UP BND1      w_17_7    1.0590015128603633e-01
 BV BND1      x_17_8  
 UP BND1      w_17_8    1.0590015128603633e-01
 BV BND1      x_17_9  
 UP BND1      w_17_9    1.0590015128603633e-01
 BV BND1      x_17_10 
 UP BND1      w_17_10   1.0590015128603633e-01
 BV BND1      x_17_11 
 UP BND1      w_17_11   1.0590015128603633e-01
 BV BND1      x_17_12 
 UP BND1      w_17_12   1.0590015128603633e-01
 BV BND1      x_17_13 
 UP BND1      w_17_13   1.0590015128603633e-01
 BV BND1      x_17_14 
 UP BND1      w_17_14   1.0590015128603633e-01
 BV BND1      x_17_15 
 UP BND1      w_17_15   1.0590015128603633e-01
 BV BND1      x_17_16 
 UP BND1      w_17_16   1.0590015128603633e-01
 UP BND1      rho_17    1
 BV BND1      x_4_0   
 UP BND1      w_4_0     1.0590015128603633e-01
 BV BND1      x_4_1   
 UP BND1      w_4_1     1.0590015128603633e-01
 BV BND1      x_4_2   
 UP BND1      w_4_2     1.0590015128603633e-01
 BV BND1      x_4_3   
 UP BND1      w_4_3     1.0590015128603633e-01
 BV BND1      x_4_4   
 UP BND1      w_4_4     1.0590015128603633e-01
 BV BND1      x_4_5   
 UP BND1      w_4_5     1.0590015128603633e-01
 BV BND1      x_4_6   
 UP BND1      w_4_6     1.0590015128603633e-01
 BV BND1      x_4_7   
 UP BND1      w_4_7     1.0590015128603633e-01
 BV BND1      x_4_8   
 UP BND1      w_4_8     1.0590015128603633e-01
 BV BND1      x_4_9   
 UP BND1      w_4_9     1.0590015128603633e-01
 BV BND1      x_4_10  
 UP BND1      w_4_10    1.0590015128603633e-01
 BV BND1      x_4_11  
 UP BND1      w_4_11    1.0590015128603633e-01
 BV BND1      x_4_12  
 UP BND1      w_4_12    1.0590015128603633e-01
 BV BND1      x_4_13  
 UP BND1      w_4_13    1.0590015128603633e-01
 BV BND1      x_4_14  
 UP BND1      w_4_14    1.0590015128603633e-01
 BV BND1      x_4_15  
 UP BND1      w_4_15    1.0590015128603633e-01
 UP BND1      rho_4     1
 BV BND1      x_11_0  
 UP BND1      w_11_0    1.0590015128603633e-01
 BV BND1      x_11_1  
 UP BND1      w_11_1    1.0590015128603633e-01
 BV BND1      x_11_2  
 UP BND1      w_11_2    1.0590015128603633e-01
 BV BND1      x_11_3  
 UP BND1      w_11_3    1.0590015128603633e-01
 BV BND1      x_11_4  
 UP BND1      w_11_4    1.0590015128603633e-01
 BV BND1      x_11_5  
 UP BND1      w_11_5    1.0590015128603633e-01
 BV BND1      x_11_6  
 UP BND1      w_11_6    1.0590015128603633e-01
 BV BND1      x_11_7  
 UP BND1      w_11_7    1.0590015128603633e-01
 BV BND1      x_11_8  
 UP BND1      w_11_8    1.0590015128603633e-01
 BV BND1      x_11_9  
 UP BND1      w_11_9    1.0590015128603633e-01
 BV BND1      x_11_10 
 UP BND1      w_11_10   1.0590015128603633e-01
 BV BND1      x_11_11 
 UP BND1      w_11_11   1.0590015128603633e-01
 BV BND1      x_11_12 
 UP BND1      w_11_12   1.0590015128603633e-01
 BV BND1      x_11_13 
 UP BND1      w_11_13   1.0590015128603633e-01
 BV BND1      x_11_14 
 UP BND1      w_11_14   1.0590015128603633e-01
 BV BND1      x_11_15 
 UP BND1      w_11_15   1.0590015128603633e-01
 UP BND1      rho_11    1
 BV BND1      x_5_0   
 UP BND1      w_5_0     1.0590015128603633e-01
 BV BND1      x_5_1   
 UP BND1      w_5_1     1.0590015128603633e-01
 BV BND1      x_5_2   
 UP BND1      w_5_2     1.0590015128603633e-01
 UP BND1      rho_5     1
 UP BND1      a_1_2     1
 UP BND1      a_1_18    1
 UP BND1      a_1_3     1
 UP BND1      a_1_17    1
 UP BND1      a_1_4     1
 UP BND1      a_1_11    1
 UP BND1      a_1_5     1
 UP BND1      a_2_18    1
 UP BND1      a_2_3     1
 UP BND1      a_2_17    1
 UP BND1      a_2_4     1
 UP BND1      a_2_11    1
 UP BND1      a_2_5     1
 UP BND1      a_18_3    1
 UP BND1      a_18_17   1
 UP BND1      a_18_4    1
 UP BND1      a_18_11   1
 UP BND1      a_18_5    1
 UP BND1      a_3_17    1
 UP BND1      a_3_4     1
 UP BND1      a_3_11    1
 UP BND1      a_3_5     1
 UP BND1      a_17_4    1
 UP BND1      a_17_11   1
 UP BND1      a_17_5    1
 UP BND1      a_4_11    1
 UP BND1      a_4_5     1
 UP BND1      a_11_5    1
 BV BND1      service_0_1_0
 BV BND1      service_0_1_2
 BV BND1      service_0_1_3
 BV BND1      service_0_1_4
 BV BND1      service_0_1_5
 BV BND1      service_0_1_6
 BV BND1      service_0_1_7
 BV BND1      service_0_1_8
 BV BND1      service_0_1_9
 BV BND1      service_0_1_10
 BV BND1      service_0_1_11
 BV BND1      service_0_1_12
 BV BND1      service_0_1_13
 BV BND1      service_0_1_14
 BV BND1      service_0_1_15
 BV BND1      service_1_1_0
 BV BND1      service_1_1_2
 BV BND1      service_1_1_3
 BV BND1      service_1_1_4
 BV BND1      service_1_1_5
 BV BND1      service_1_1_6
 BV BND1      service_1_1_7
 BV BND1      service_1_1_8
 BV BND1      service_1_1_9
 BV BND1      service_1_1_10
 BV BND1      service_1_1_11
 BV BND1      service_1_1_12
 BV BND1      service_1_1_13
 BV BND1      service_1_1_14
 BV BND1      service_1_1_15
 BV BND1      service_0_2_1
 BV BND1      service_1_2_1
 BV BND1      service_0_18_1
 BV BND1      service_0_18_2
 BV BND1      service_0_18_3
 BV BND1      service_0_18_4
 BV BND1      service_0_18_5
 BV BND1      service_0_18_6
 BV BND1      service_0_18_7
 BV BND1      service_0_18_8
 BV BND1      service_0_18_9
 BV BND1      service_0_18_10
 BV BND1      service_0_18_11
 BV BND1      service_0_18_12
 BV BND1      service_0_18_13
 BV BND1      service_0_18_14
 BV BND1      service_0_18_15
 BV BND1      service_1_18_1
 BV BND1      service_1_18_2
 BV BND1      service_1_18_3
 BV BND1      service_1_18_4
 BV BND1      service_1_18_5
 BV BND1      service_1_18_6
 BV BND1      service_1_18_7
 BV BND1      service_1_18_8
 BV BND1      service_1_18_9
 BV BND1      service_1_18_10
 BV BND1      service_1_18_11
 BV BND1      service_1_18_12
 BV BND1      service_1_18_13
 BV BND1      service_1_18_14
 BV BND1      service_1_18_15
 BV BND1      service_0_3_0
 BV BND1      service_0_3_1
 BV BND1      service_0_3_2
 BV BND1      service_0_3_3
 BV BND1      service_0_3_4
 BV BND1      service_0_3_5
 BV BND1      service_0_3_6
 BV BND1      service_0_3_7
 BV BND1      service_0_3_8
 BV BND1      service_0_3_9
 BV BND1      service_0_3_10
 BV BND1      service_0_3_11
 BV BND1      service_0_3_13
 BV BND1      service_0_3_14
 BV BND1      service_0_3_15
 BV BND1      service_0_3_16
 BV BND1      service_1_3_0
 BV BND1      service_1_3_1
 BV BND1      service_1_3_2
 BV BND1      service_1_3_3
 BV BND1      service_1_3_4
 BV BND1      service_1_3_5
 BV BND1      service_1_3_6
 BV BND1      service_1_3_7
 BV BND1      service_1_3_8
 BV BND1      service_1_3_9
 BV BND1      service_1_3_10
 BV BND1      service_1_3_11
 BV BND1      service_1_3_13
 BV BND1      service_1_3_14
 BV BND1      service_1_3_15
 BV BND1      service_1_3_16
 BV BND1      service_0_17_0
 BV BND1      service_0_17_1
 BV BND1      service_0_17_2
 BV BND1      service_0_17_4
 BV BND1      service_0_17_5
 BV BND1      service_0_17_6
 BV BND1      service_0_17_7
 BV BND1      service_0_17_8
 BV BND1      service_0_17_9
 BV BND1      service_0_17_10
 BV BND1      service_0_17_11
 BV BND1      service_0_17_12
 BV BND1      service_0_17_13
 BV BND1      service_0_17_14
 BV BND1      service_0_17_15
 BV BND1      service_0_17_16
 BV BND1      service_1_17_0
 BV BND1      service_1_17_1
 BV BND1      service_1_17_2
 BV BND1      service_1_17_4
 BV BND1      service_1_17_5
 BV BND1      service_1_17_6
 BV BND1      service_1_17_7
 BV BND1      service_1_17_8
 BV BND1      service_1_17_9
 BV BND1      service_1_17_10
 BV BND1      service_1_17_11
 BV BND1      service_1_17_12
 BV BND1      service_1_17_13
 BV BND1      service_1_17_14
 BV BND1      service_1_17_15
 BV BND1      service_1_17_16
 BV BND1      service_0_4_0
 BV BND1      service_0_4_1
 BV BND1      service_0_4_2
 BV BND1      service_0_4_3
 BV BND1      service_0_4_4
 BV BND1      service_0_4_5
 BV BND1      service_0_4_6
 BV BND1      service_0_4_7
 BV BND1      service_0_4_8
 BV BND1      service_0_4_9
 BV BND1      service_0_4_10
 BV BND1      service_0_4_11
 BV BND1      service_0_4_13
 BV BND1      service_0_4_14
 BV BND1      service_0_4_15
 BV BND1      service_1_4_0
 BV BND1      service_1_4_1
 BV BND1      service_1_4_2
 BV BND1      service_1_4_3
 BV BND1      service_1_4_4
 BV BND1      service_1_4_5
 BV BND1      service_1_4_6
 BV BND1      service_1_4_7
 BV BND1      service_1_4_8
 BV BND1      service_1_4_9
 BV BND1      service_1_4_10
 BV BND1      service_1_4_11
 BV BND1      service_1_4_13
 BV BND1      service_1_4_14
 BV BND1      service_1_4_15
 BV BND1      service_0_11_0
 BV BND1      service_0_11_2
 BV BND1      service_0_11_3
 BV BND1      service_0_11_4
 BV BND1      service_0_11_5
 BV BND1      service_0_11_6
 BV BND1      service_0_11_7
 BV BND1      service_0_11_8
 BV BND1      service_0_11_9
 BV BND1      service_0_11_10
 BV BND1      service_0_11_11
 BV BND1      service_0_11_12
 BV BND1      service_0_11_13
 BV BND1      service_0_11_14
 BV BND1      service_0_11_15
 BV BND1      service_1_11_0
 BV BND1      service_1_11_2
 BV BND1      service_1_11_3
 BV BND1      service_1_11_4
 BV BND1      service_1_11_5
 BV BND1      service_1_11_6
 BV BND1      service_1_11_7
 BV BND1      service_1_11_8
 BV BND1      service_1_11_9
 BV BND1      service_1_11_10
 BV BND1      service_1_11_11
 BV BND1      service_1_11_12
 BV BND1      service_1_11_13
 BV BND1      service_1_11_14
 BV BND1      service_1_11_15
 BV BND1      service_0_5_1
 BV BND1      service_0_5_2
 BV BND1      service_1_5_1
 BV BND1      service_1_5_2
 FX BND1      visit_0_1  1
 UP BND1      order_0_1  13
 FX BND1      visit_0_2  1
 UP BND1      order_0_2  13
 FX BND1      visit_0_3  1
 UP BND1      order_0_3  13
 FX BND1      visit_0_4  1
 UP BND1      order_0_4  13
 FX BND1      visit_0_5  1
 UP BND1      order_0_5  13
 UP BND1      visit_0_8  1
 UP BND1      order_0_8  13
 UP BND1      visit_0_9  1
 UP BND1      order_0_9  13
 UP BND1      visit_0_10  1
 UP BND1      order_0_10  13
 UP BND1      visit_0_11  1
 UP BND1      order_0_11  13
 UP BND1      visit_0_12  1
 UP BND1      order_0_12  13
 UP BND1      visit_0_13  1
 UP BND1      order_0_13  13
 UP BND1      visit_0_14  1
 UP BND1      order_0_14  13
 UP BND1      visit_0_15  1
 UP BND1      order_0_15  13
 BV BND1      arc_0_0_0
 FX BND1      load_0_0_0  0
 BV BND1      arc_0_0_1
 FX BND1      load_0_0_1  0
 BV BND1      arc_0_0_2
 FX BND1      load_0_0_2  0
 BV BND1      arc_0_0_3
 FX BND1      load_0_0_3  0
 BV BND1      arc_0_0_4
 FX BND1      load_0_0_4  0
 BV BND1      arc_0_0_5
 FX BND1      load_0_0_5  0
 BV BND1      arc_0_0_8
 FX BND1      load_0_0_8  0
 BV BND1      arc_0_0_9
 FX BND1      load_0_0_9  0
 BV BND1      arc_0_0_10
 FX BND1      load_0_0_10  0
 BV BND1      arc_0_0_11
 FX BND1      load_0_0_11  0
 BV BND1      arc_0_0_12
 FX BND1      load_0_0_12  0
 BV BND1      arc_0_0_13
 FX BND1      load_0_0_13  0
 BV BND1      arc_0_0_14
 FX BND1      load_0_0_14  0
 BV BND1      arc_0_0_15
 FX BND1      load_0_0_15  0
 BV BND1      arc_0_1_0
 UP BND1      load_0_1_0  30
 BV BND1      arc_0_1_2
 UP BND1      load_0_1_2  30
 BV BND1      arc_0_1_3
 UP BND1      load_0_1_3  30
 BV BND1      arc_0_1_4
 UP BND1      load_0_1_4  30
 BV BND1      arc_0_1_5
 UP BND1      load_0_1_5  30
 BV BND1      arc_0_1_8
 UP BND1      load_0_1_8  30
 BV BND1      arc_0_1_9
 UP BND1      load_0_1_9  30
 BV BND1      arc_0_1_10
 UP BND1      load_0_1_10  30
 BV BND1      arc_0_1_11
 UP BND1      load_0_1_11  30
 BV BND1      arc_0_1_12
 UP BND1      load_0_1_12  30
 BV BND1      arc_0_1_13
 UP BND1      load_0_1_13  30
 BV BND1      arc_0_1_14
 UP BND1      load_0_1_14  30
 BV BND1      arc_0_1_15
 UP BND1      load_0_1_15  30
 BV BND1      arc_0_2_0
 UP BND1      load_0_2_0  30
 BV BND1      arc_0_2_1
 UP BND1      load_0_2_1  30
 BV BND1      arc_0_2_3
 UP BND1      load_0_2_3  30
 BV BND1      arc_0_2_4
 UP BND1      load_0_2_4  30
 BV BND1      arc_0_2_5
 UP BND1      load_0_2_5  30
 BV BND1      arc_0_2_8
 UP BND1      load_0_2_8  30
 BV BND1      arc_0_2_9
 UP BND1      load_0_2_9  30
 BV BND1      arc_0_2_10
 UP BND1      load_0_2_10  30
 BV BND1      arc_0_2_11
 UP BND1      load_0_2_11  30
 BV BND1      arc_0_2_12
 UP BND1      load_0_2_12  30
 BV BND1      arc_0_2_13
 UP BND1      load_0_2_13  30
 BV BND1      arc_0_2_14
 UP BND1      load_0_2_14  30
 BV BND1      arc_0_2_15
 UP BND1      load_0_2_15  30
 BV BND1      arc_0_3_0
 UP BND1      load_0_3_0  30
 BV BND1      arc_0_3_1
 UP BND1      load_0_3_1  30
 BV BND1      arc_0_3_2
 UP BND1      load_0_3_2  30
 BV BND1      arc_0_3_4
 UP BND1      load_0_3_4  30
 BV BND1      arc_0_3_5
 UP BND1      load_0_3_5  30
 BV BND1      arc_0_3_8
 UP BND1      load_0_3_8  30
 BV BND1      arc_0_3_9
 UP BND1      load_0_3_9  30
 BV BND1      arc_0_3_10
 UP BND1      load_0_3_10  30
 BV BND1      arc_0_3_11
 UP BND1      load_0_3_11  30
 BV BND1      arc_0_3_12
 UP BND1      load_0_3_12  30
 BV BND1      arc_0_3_13
 UP BND1      load_0_3_13  30
 BV BND1      arc_0_3_14
 UP BND1      load_0_3_14  30
 BV BND1      arc_0_3_15
 UP BND1      load_0_3_15  30
 BV BND1      arc_0_4_0
 UP BND1      load_0_4_0  30
 BV BND1      arc_0_4_1
 UP BND1      load_0_4_1  30
 BV BND1      arc_0_4_2
 UP BND1      load_0_4_2  30
 BV BND1      arc_0_4_3
 UP BND1      load_0_4_3  30
 BV BND1      arc_0_4_5
 UP BND1      load_0_4_5  30
 BV BND1      arc_0_4_8
 UP BND1      load_0_4_8  30
 BV BND1      arc_0_4_9
 UP BND1      load_0_4_9  30
 BV BND1      arc_0_4_10
 UP BND1      load_0_4_10  30
 BV BND1      arc_0_4_11
 UP BND1      load_0_4_11  30
 BV BND1      arc_0_4_12
 UP BND1      load_0_4_12  30
 BV BND1      arc_0_4_13
 UP BND1      load_0_4_13  30
 BV BND1      arc_0_4_14
 UP BND1      load_0_4_14  30
 BV BND1      arc_0_4_15
 UP BND1      load_0_4_15  30
 BV BND1      arc_0_5_0
 UP BND1      load_0_5_0  30
 BV BND1      arc_0_5_1
 UP BND1      load_0_5_1  30
 BV BND1      arc_0_5_2
 UP BND1      load_0_5_2  30
 BV BND1      arc_0_5_3
 UP BND1      load_0_5_3  30
 BV BND1      arc_0_5_4
 UP BND1      load_0_5_4  30
 BV BND1      arc_0_5_8
 UP BND1      load_0_5_8  30
 BV BND1      arc_0_5_9
 UP BND1      load_0_5_9  30
 BV BND1      arc_0_5_10
 UP BND1      load_0_5_10  30
 BV BND1      arc_0_5_11
 UP BND1      load_0_5_11  30
 BV BND1      arc_0_5_12
 UP BND1      load_0_5_12  30
 BV BND1      arc_0_5_13
 UP BND1      load_0_5_13  30
 BV BND1      arc_0_5_14
 UP BND1      load_0_5_14  30
 BV BND1      arc_0_5_15
 UP BND1      load_0_5_15  30
 BV BND1      arc_0_8_0
 UP BND1      load_0_8_0  30
 BV BND1      arc_0_8_1
 UP BND1      load_0_8_1  30
 BV BND1      arc_0_8_2
 UP BND1      load_0_8_2  30
 BV BND1      arc_0_8_3
 UP BND1      load_0_8_3  30
 BV BND1      arc_0_8_4
 UP BND1      load_0_8_4  30
 BV BND1      arc_0_8_5
 UP BND1      load_0_8_5  30
 BV BND1      arc_0_8_9
 UP BND1      load_0_8_9  30
 BV BND1      arc_0_8_10
 UP BND1      load_0_8_10  30
 BV BND1      arc_0_8_11
 UP BND1      load_0_8_11  30
 BV BND1      arc_0_8_12
 UP BND1      load_0_8_12  30
 BV BND1      arc_0_8_13
 UP BND1      load_0_8_13  30
 BV BND1      arc_0_8_14
 UP BND1      load_0_8_14  30
 BV BND1      arc_0_8_15
 UP BND1      load_0_8_15  30
 BV BND1      arc_0_9_0
 UP BND1      load_0_9_0  30
 BV BND1      arc_0_9_1
 UP BND1      load_0_9_1  30
 BV BND1      arc_0_9_2
 UP BND1      load_0_9_2  30
 BV BND1      arc_0_9_3
 UP BND1      load_0_9_3  30
 BV BND1      arc_0_9_4
 UP BND1      load_0_9_4  30
 BV BND1      arc_0_9_5
 UP BND1      load_0_9_5  30
 BV BND1      arc_0_9_8
 UP BND1      load_0_9_8  30
 BV BND1      arc_0_9_10
 UP BND1      load_0_9_10  30
 BV BND1      arc_0_9_11
 UP BND1      load_0_9_11  30
 BV BND1      arc_0_9_12
 UP BND1      load_0_9_12  30
 BV BND1      arc_0_9_13
 UP BND1      load_0_9_13  30
 BV BND1      arc_0_9_14
 UP BND1      load_0_9_14  30
 BV BND1      arc_0_9_15
 UP BND1      load_0_9_15  30
 BV BND1      arc_0_10_0
 UP BND1      load_0_10_0  30
 BV BND1      arc_0_10_1
 UP BND1      load_0_10_1  30
 BV BND1      arc_0_10_2
 UP BND1      load_0_10_2  30
 BV BND1      arc_0_10_3
 UP BND1      load_0_10_3  30
 BV BND1      arc_0_10_4
 UP BND1      load_0_10_4  30
 BV BND1      arc_0_10_5
 UP BND1      load_0_10_5  30
 BV BND1      arc_0_10_8
 UP BND1      load_0_10_8  30
 BV BND1      arc_0_10_9
 UP BND1      load_0_10_9  30
 BV BND1      arc_0_10_11
 UP BND1      load_0_10_11  30
 BV BND1      arc_0_10_12
 UP BND1      load_0_10_12  30
 BV BND1      arc_0_10_13
 UP BND1      load_0_10_13  30
 BV BND1      arc_0_10_14
 UP BND1      load_0_10_14  30
 BV BND1      arc_0_10_15
 UP BND1      load_0_10_15  30
 BV BND1      arc_0_11_0
 UP BND1      load_0_11_0  30
 BV BND1      arc_0_11_1
 UP BND1      load_0_11_1  30
 BV BND1      arc_0_11_2
 UP BND1      load_0_11_2  30
 BV BND1      arc_0_11_3
 UP BND1      load_0_11_3  30
 BV BND1      arc_0_11_4
 UP BND1      load_0_11_4  30
 BV BND1      arc_0_11_5
 UP BND1      load_0_11_5  30
 BV BND1      arc_0_11_8
 UP BND1      load_0_11_8  30
 BV BND1      arc_0_11_9
 UP BND1      load_0_11_9  30
 BV BND1      arc_0_11_10
 UP BND1      load_0_11_10  30
 BV BND1      arc_0_11_12
 UP BND1      load_0_11_12  30
 BV BND1      arc_0_11_13
 UP BND1      load_0_11_13  30
 BV BND1      arc_0_11_14
 UP BND1      load_0_11_14  30
 BV BND1      arc_0_11_15
 UP BND1      load_0_11_15  30
 BV BND1      arc_0_12_0
 UP BND1      load_0_12_0  30
 BV BND1      arc_0_12_1
 UP BND1      load_0_12_1  30
 BV BND1      arc_0_12_2
 UP BND1      load_0_12_2  30
 BV BND1      arc_0_12_3
 UP BND1      load_0_12_3  30
 BV BND1      arc_0_12_4
 UP BND1      load_0_12_4  30
 BV BND1      arc_0_12_5
 UP BND1      load_0_12_5  30
 BV BND1      arc_0_12_8
 UP BND1      load_0_12_8  30
 BV BND1      arc_0_12_9
 UP BND1      load_0_12_9  30
 BV BND1      arc_0_12_10
 UP BND1      load_0_12_10  30
 BV BND1      arc_0_12_11
 UP BND1      load_0_12_11  30
 BV BND1      arc_0_12_13
 UP BND1      load_0_12_13  30
 BV BND1      arc_0_12_14
 UP BND1      load_0_12_14  30
 BV BND1      arc_0_12_15
 UP BND1      load_0_12_15  30
 BV BND1      arc_0_13_0
 UP BND1      load_0_13_0  30
 BV BND1      arc_0_13_1
 UP BND1      load_0_13_1  30
 BV BND1      arc_0_13_2
 UP BND1      load_0_13_2  30
 BV BND1      arc_0_13_3
 UP BND1      load_0_13_3  30
 BV BND1      arc_0_13_4
 UP BND1      load_0_13_4  30
 BV BND1      arc_0_13_5
 UP BND1      load_0_13_5  30
 BV BND1      arc_0_13_8
 UP BND1      load_0_13_8  30
 BV BND1      arc_0_13_9
 UP BND1      load_0_13_9  30
 BV BND1      arc_0_13_10
 UP BND1      load_0_13_10  30
 BV BND1      arc_0_13_11
 UP BND1      load_0_13_11  30
 BV BND1      arc_0_13_12
 UP BND1      load_0_13_12  30
 BV BND1      arc_0_13_14
 UP BND1      load_0_13_14  30
 BV BND1      arc_0_13_15
 UP BND1      load_0_13_15  30
 BV BND1      arc_0_14_0
 UP BND1      load_0_14_0  30
 BV BND1      arc_0_14_1
 UP BND1      load_0_14_1  30
 BV BND1      arc_0_14_2
 UP BND1      load_0_14_2  30
 BV BND1      arc_0_14_3
 UP BND1      load_0_14_3  30
 BV BND1      arc_0_14_4
 UP BND1      load_0_14_4  30
 BV BND1      arc_0_14_5
 UP BND1      load_0_14_5  30
 BV BND1      arc_0_14_8
 UP BND1      load_0_14_8  30
 BV BND1      arc_0_14_9
 UP BND1      load_0_14_9  30
 BV BND1      arc_0_14_10
 UP BND1      load_0_14_10  30
 BV BND1      arc_0_14_11
 UP BND1      load_0_14_11  30
 BV BND1      arc_0_14_12
 UP BND1      load_0_14_12  30
 BV BND1      arc_0_14_13
 UP BND1      load_0_14_13  30
 BV BND1      arc_0_14_15
 UP BND1      load_0_14_15  30
 BV BND1      arc_0_15_0
 UP BND1      load_0_15_0  30
 BV BND1      arc_0_15_1
 UP BND1      load_0_15_1  30
 BV BND1      arc_0_15_2
 UP BND1      load_0_15_2  30
 BV BND1      arc_0_15_3
 UP BND1      load_0_15_3  30
 BV BND1      arc_0_15_4
 UP BND1      load_0_15_4  30
 BV BND1      arc_0_15_5
 UP BND1      load_0_15_5  30
 BV BND1      arc_0_15_8
 UP BND1      load_0_15_8  30
 BV BND1      arc_0_15_9
 UP BND1      load_0_15_9  30
 BV BND1      arc_0_15_10
 UP BND1      load_0_15_10  30
 BV BND1      arc_0_15_11
 UP BND1      load_0_15_11  30
 BV BND1      arc_0_15_12
 UP BND1      load_0_15_12  30
 BV BND1      arc_0_15_13
 UP BND1      load_0_15_13  30
 BV BND1      arc_0_15_14
 UP BND1      load_0_15_14  30
 FX BND1      visit_1_6  1
 UP BND1      order_1_6  10
 FX BND1      visit_1_7  1
 UP BND1      order_1_7  10
 UP BND1      visit_1_8  1
 UP BND1      order_1_8  10
 UP BND1      visit_1_9  1
 UP BND1      order_1_9  10
 UP BND1      visit_1_10  1
 UP BND1      order_1_10  10
 UP BND1      visit_1_11  1
 UP BND1      order_1_11  10
 UP BND1      visit_1_12  1
 UP BND1      order_1_12  10
 UP BND1      visit_1_13  1
 UP BND1      order_1_13  10
 UP BND1      visit_1_14  1
 UP BND1      order_1_14  10
 UP BND1      visit_1_15  1
 UP BND1      order_1_15  10
 BV BND1      arc_1_0_0
 FX BND1      load_1_0_0  0
 BV BND1      arc_1_0_6
 FX BND1      load_1_0_6  0
 BV BND1      arc_1_0_7
 FX BND1      load_1_0_7  0
 BV BND1      arc_1_0_8
 FX BND1      load_1_0_8  0
 BV BND1      arc_1_0_9
 FX BND1      load_1_0_9  0
 BV BND1      arc_1_0_10
 FX BND1      load_1_0_10  0
 BV BND1      arc_1_0_11
 FX BND1      load_1_0_11  0
 BV BND1      arc_1_0_12
 FX BND1      load_1_0_12  0
 BV BND1      arc_1_0_13
 FX BND1      load_1_0_13  0
 BV BND1      arc_1_0_14
 FX BND1      load_1_0_14  0
 BV BND1      arc_1_0_15
 FX BND1      load_1_0_15  0
 BV BND1      arc_1_6_0
 UP BND1      load_1_6_0  30
 BV BND1      arc_1_6_7
 UP BND1      load_1_6_7  30
 BV BND1      arc_1_6_8
 UP BND1      load_1_6_8  30
 BV BND1      arc_1_6_9
 UP BND1      load_1_6_9  30
 BV BND1      arc_1_6_10
 UP BND1      load_1_6_10  30
 BV BND1      arc_1_6_11
 UP BND1      load_1_6_11  30
 BV BND1      arc_1_6_12
 UP BND1      load_1_6_12  30
 BV BND1      arc_1_6_13
 UP BND1      load_1_6_13  30
 BV BND1      arc_1_6_14
 UP BND1      load_1_6_14  30
 BV BND1      arc_1_6_15
 UP BND1      load_1_6_15  30
 BV BND1      arc_1_7_0
 UP BND1      load_1_7_0  30
 BV BND1      arc_1_7_6
 UP BND1      load_1_7_6  30
 BV BND1      arc_1_7_8
 UP BND1      load_1_7_8  30
 BV BND1      arc_1_7_9
 UP BND1      load_1_7_9  30
 BV BND1      arc_1_7_10
 UP BND1      load_1_7_10  30
 BV BND1      arc_1_7_11
 UP BND1      load_1_7_11  30
 BV BND1      arc_1_7_12
 UP BND1      load_1_7_12  30
 BV BND1      arc_1_7_13
 UP BND1      load_1_7_13  30
 BV BND1      arc_1_7_14
 UP BND1      load_1_7_14  30
 BV BND1      arc_1_7_15
 UP BND1      load_1_7_15  30
 BV BND1      arc_1_8_0
 UP BND1      load_1_8_0  30
 BV BND1      arc_1_8_6
 UP BND1      load_1_8_6  30
 BV BND1      arc_1_8_7
 UP BND1      load_1_8_7  30
 BV BND1      arc_1_8_9
 UP BND1      load_1_8_9  30
 BV BND1      arc_1_8_10
 UP BND1      load_1_8_10  30
 BV BND1      arc_1_8_11
 UP BND1      load_1_8_11  30
 BV BND1      arc_1_8_12
 UP BND1      load_1_8_12  30
 BV BND1      arc_1_8_13
 UP BND1      load_1_8_13  30
 BV BND1      arc_1_8_14
 UP BND1      load_1_8_14  30
 BV BND1      arc_1_8_15
 UP BND1      load_1_8_15  30
 BV BND1      arc_1_9_0
 UP BND1      load_1_9_0  30
 BV BND1      arc_1_9_6
 UP BND1      load_1_9_6  30
 BV BND1      arc_1_9_7
 UP BND1      load_1_9_7  30
 BV BND1      arc_1_9_8
 UP BND1      load_1_9_8  30
 BV BND1      arc_1_9_10
 UP BND1      load_1_9_10  30
 BV BND1      arc_1_9_11
 UP BND1      load_1_9_11  30
 BV BND1      arc_1_9_12
 UP BND1      load_1_9_12  30
 BV BND1      arc_1_9_13
 UP BND1      load_1_9_13  30
 BV BND1      arc_1_9_14
 UP BND1      load_1_9_14  30
 BV BND1      arc_1_9_15
 UP BND1      load_1_9_15  30
 BV BND1      arc_1_10_0
 UP BND1      load_1_10_0  30
 BV BND1      arc_1_10_6
 UP BND1      load_1_10_6  30
 BV BND1      arc_1_10_7
 UP BND1      load_1_10_7  30
 BV BND1      arc_1_10_8
 UP BND1      load_1_10_8  30
 BV BND1      arc_1_10_9
 UP BND1      load_1_10_9  30
 BV BND1      arc_1_10_11
 UP BND1      load_1_10_11  30
 BV BND1      arc_1_10_12
 UP BND1      load_1_10_12  30
 BV BND1      arc_1_10_13
 UP BND1      load_1_10_13  30
 BV BND1      arc_1_10_14
 UP BND1      load_1_10_14  30
 BV BND1      arc_1_10_15
 UP BND1      load_1_10_15  30
 BV BND1      arc_1_11_0
 UP BND1      load_1_11_0  30
 BV BND1      arc_1_11_6
 UP BND1      load_1_11_6  30
 BV BND1      arc_1_11_7
 UP BND1      load_1_11_7  30
 BV BND1      arc_1_11_8
 UP BND1      load_1_11_8  30
 BV BND1      arc_1_11_9
 UP BND1      load_1_11_9  30
 BV BND1      arc_1_11_10
 UP BND1      load_1_11_10  30
 BV BND1      arc_1_11_12
 UP BND1      load_1_11_12  30
 BV BND1      arc_1_11_13
 UP BND1      load_1_11_13  30
 BV BND1      arc_1_11_14
 UP BND1      load_1_11_14  30
 BV BND1      arc_1_11_15
 UP BND1      load_1_11_15  30
 BV BND1      arc_1_12_0
 UP BND1      load_1_12_0  30
 BV BND1      arc_1_12_6
 UP BND1      load_1_12_6  30
 BV BND1      arc_1_12_7
 UP BND1      load_1_12_7  30
 BV BND1      arc_1_12_8
 UP BND1      load_1_12_8  30
 BV BND1      arc_1_12_9
 UP BND1      load_1_12_9  30
 BV BND1      arc_1_12_10
 UP BND1      load_1_12_10  30
 BV BND1      arc_1_12_11
 UP BND1      load_1_12_11  30
 BV BND1      arc_1_12_13
 UP BND1      load_1_12_13  30
 BV BND1      arc_1_12_14
 UP BND1      load_1_12_14  30
 BV BND1      arc_1_12_15
 UP BND1      load_1_12_15  30
 BV BND1      arc_1_13_0
 UP BND1      load_1_13_0  30
 BV BND1      arc_1_13_6
 UP BND1      load_1_13_6  30
 BV BND1      arc_1_13_7
 UP BND1      load_1_13_7  30
 BV BND1      arc_1_13_8
 UP BND1      load_1_13_8  30
 BV BND1      arc_1_13_9
 UP BND1      load_1_13_9  30
 BV BND1      arc_1_13_10
 UP BND1      load_1_13_10  30
 BV BND1      arc_1_13_11
 UP BND1      load_1_13_11  30
 BV BND1      arc_1_13_12
 UP BND1      load_1_13_12  30
 BV BND1      arc_1_13_14
 UP BND1      load_1_13_14  30
 BV BND1      arc_1_13_15
 UP BND1      load_1_13_15  30
 BV BND1      arc_1_14_0
 UP BND1      load_1_14_0  30
 BV BND1      arc_1_14_6
 UP BND1      load_1_14_6  30
 BV BND1      arc_1_14_7
 UP BND1      load_1_14_7  30
 BV BND1      arc_1_14_8
 UP BND1      load_1_14_8  30
 BV BND1      arc_1_14_9
 UP BND1      load_1_14_9  30
 BV BND1      arc_1_14_10
 UP BND1      load_1_14_10  30
 BV BND1      arc_1_14_11
 UP BND1      load_1_14_11  30
 BV BND1      arc_1_14_12
 UP BND1      load_1_14_12  30
 BV BND1      arc_1_14_13
 UP BND1      load_1_14_13  30
 BV BND1      arc_1_14_15
 UP BND1      load_1_14_15  30
 BV BND1      arc_1_15_0
 UP BND1      load_1_15_0  30
 BV BND1      arc_1_15_6
 UP BND1      load_1_15_6  30
 BV BND1      arc_1_15_7
 UP BND1      load_1_15_7  30
 BV BND1      arc_1_15_8
 UP BND1      load_1_15_8  30
 BV BND1      arc_1_15_9
 UP BND1      load_1_15_9  30
 BV BND1      arc_1_15_10
 UP BND1      load_1_15_10  30
 BV BND1      arc_1_15_11
 UP BND1      load_1_15_11  30
 BV BND1      arc_1_15_12
 UP BND1      load_1_15_12  30
 BV BND1      arc_1_15_13
 UP BND1      load_1_15_13  30
 BV BND1      arc_1_15_14
 UP BND1      load_1_15_14  30
ENDATA
